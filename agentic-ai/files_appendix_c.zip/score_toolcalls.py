"""Scoring for the tool-call experiment. Pure functions, no model, no network.

Run (from the snapshot root):  PYTHONPATH=. python3 -m appendix_c.eval_toolcalls ...

Four outcomes per example, in order of severity, because collapsing them into
one accuracy number hides which defect moved:

    parse_failed   the output was not a tool call at all
    wrong_tool     a valid call to the wrong tool
    wrong_args     right tool, wrong arguments
    correct        right tool, right arguments

`none` is a first-class expected value: "answer without calling a tool" is a
decision, and a model that never abstains has a trivially optimal policy the
positives-only score cannot see (Phase 13's balance rule).
"""
from __future__ import annotations

import json
import re
from typing import Any, Literal, NamedTuple, Sequence

Outcome = Literal["correct", "wrong_args", "wrong_tool", "parse_failed"]

_FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL)


class Prediction(NamedTuple):
    tool: str | None
    arguments: dict[str, Any]


def parse_call(text: str) -> Prediction | None:
    """Pull a {"tool": ..., "arguments": {...}} object out of model text. Pure.

    Accepts a bare object or one inside a fenced block, because both are things
    small models do. Anything else is a parse failure, and a parse failure is
    recorded rather than repaired: a scorer that repairs output measures the
    repair, not the model.
    """
    candidate = text.strip()
    fenced = _FENCE.search(candidate)
    if fenced:
        candidate = fenced.group(1).strip()
    start, end = candidate.find("{"), candidate.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        payload = json.loads(candidate[start : end + 1])
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict) or "tool" not in payload:
        return None
    args = payload.get("arguments", {})
    if not isinstance(args, dict):
        return None
    tool = payload["tool"]
    return Prediction(tool if isinstance(tool, str) else None, args)


def normalise_args(args: dict[str, Any]) -> dict[str, str]:
    """Compare arguments as canonical strings, and say why.

    SQL whitespace and integer-versus-string are differences no user would
    notice and every exact-match scorer would punish. Lowercasing SQL keywords
    is NOT done: a scorer that normalises away case would also hide a model
    that emits a different identifier.
    """
    out: dict[str, str] = {}
    for key, value in args.items():
        text = str(value).strip()
        out[key] = " ".join(text.split())
    return out


def score_one(expected_tool: str, expected_args: dict[str, Any], text: str) -> Outcome:
    prediction = parse_call(text)
    if prediction is None or prediction.tool is None:
        # Expecting `none`, an unparseable answer is still not a tool call, but
        # it is not evidence of correct abstention either: the reference format
        # for abstention is an explicit {"tool": "none"}.
        return "parse_failed"
    if prediction.tool != expected_tool:
        return "wrong_tool"
    if normalise_args(prediction.arguments) != normalise_args(expected_args):
        return "wrong_args"
    return "correct"


def tally(outcomes: Sequence[Outcome]) -> dict[str, int]:
    counts = {k: 0 for k in ("correct", "wrong_args", "wrong_tool", "parse_failed")}
    for outcome in outcomes:
        counts[outcome] += 1
    return counts


def report(outcomes: Sequence[Outcome]) -> str:
    """One block per run: counts, the two headline rates, and their intervals."""
    try:  # noqa: PLC0415 -- Atlas's own, tested in Phase 13
        from evals.stats import min_detectable_effect, wilson_interval
    except ModuleNotFoundError:  # the free-GPU notebook has no Atlas on its path
        from appendix_c._stats import min_detectable_effect, wilson_interval

    counts = tally(outcomes)
    n = len(outcomes)
    correct = counts["correct"]
    tool_ok = correct + counts["wrong_args"]
    full = wilson_interval(correct, n)
    name = wilson_interval(tool_ok, n)
    mde = min_detectable_effect(n, p=max(correct / n, 0.5) if n else 0.5)
    lines = [
        f"n = {n}   " + "  ".join(f"{k}={v}" for k, v in counts.items()),
        f"tool-name accuracy   {tool_ok / n:.3f}  95% CI [{name.low:.3f}, {name.high:.3f}]",
        f"full-call accuracy   {correct / n:.3f}  95% CI [{full.low:.3f}, {full.high:.3f}]",
        f"minimum detectable effect at this n: {mde:.3f}",
    ]
    return "\n".join(lines)
