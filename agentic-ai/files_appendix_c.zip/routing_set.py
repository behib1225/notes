"""Seeded labelled set for the router prompt-optimization pass.

Gold labels are the `atlas.flow.route.Route` values. Templates are written per
route from ROUTE_DESCRIPTIONS, so the label is the template's, not a judgement
call made later -- a set whose labels are assigned after seeing model output is
a set that agrees with the model.
"""
from __future__ import annotations

import random
from typing import Sequence

TEMPLATES: dict[str, tuple[str, ...]] = {
    "chat": (
        "hello, who are you",
        "what can you do for me",
        "thanks for the help",
    ),
    "document": (
        "what does the warranty policy say about returns",
        "where is the onboarding checklist",
        "what does error code E41 mean in the handbook",
    ),
    "data": (
        "how many shipments went to the {region} region",
        "what is the total headcount",
        "average units per order for {product}",
    ),
    "research": (
        "compare claims and shipments for {product} and write a brief",
        "why did {region} deliveries fall and what changed",
        "summarise the trend across regions",
    ),
    "tool_action": (
        "save a note called handover.md with the escalation steps",
        "write the summary to summary.md",
        "schedule the review for Friday",
    ),
}

REGIONS = ("west", "east", "north", "south")
PRODUCTS = ("S400", "S500", "T100")


def build(n: int = 48, seed: int = 7) -> list[dict[str, str]]:
    """`n` examples, balanced across routes, deterministic for a seed."""
    rng = random.Random(seed)
    routes: Sequence[str] = tuple(TEMPLATES)
    rows: list[dict[str, str]] = []
    for index in range(n):
        route = routes[index % len(routes)]
        template = rng.choice(TEMPLATES[route])
        request = template.format(
            region=rng.choice(REGIONS), product=rng.choice(PRODUCTS)
        )
        rows.append({"id": f"r-{index:03d}", "request": request, "route": route})
    return rows


def split(rows: list[dict[str, str]]) -> tuple[list[dict[str, str]], list[dict[str, str]]]:
    """Dev / holdout, interleaved so both halves are balanced across routes.

    Contiguous halves would put the last route classes entirely in one half,
    which is the kind of split that makes a candidate look good for a reason
    that has nothing to do with the prompt.
    """
    dev = [row for index, row in enumerate(rows) if index % 2 == 0]
    holdout = [row for index, row in enumerate(rows) if index % 2 == 1]
    return dev, holdout
