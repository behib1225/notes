"""Run one tool-call eval sweep and print the per-run report and the spread.

The harness takes a `generate` callable, so the same code scores the base
model, the fine-tuned model, and a scripted fixture set. Tier F uses fixtures
and proves the PLUMBING; only Tier A or the notebook produce a measurement,
and that measurement is data (docs/RESULTS.md), never a test assertion.

Run from the snapshot root:

    # Tier F -- no model, no network. Proves the harness is wired correctly.
    PYTHONPATH=. python3 -m appendix_c.eval_toolcalls \
        --split appendix_c/data/toolcalls_test_seen.jsonl \
        --fixtures appendix_c/fixtures/toolcalls_before.json

    # Tier A -- your local Ollama. ATLAS_MODEL is a current-state fact.
    PYTHONPATH=. python3 -m appendix_c.eval_toolcalls \
        --split appendix_c/data/toolcalls_test_unseen.jsonl \
        --model "$ATLAS_MODEL" --runs 3
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable, Iterable, Sequence

from appendix_c.score_toolcalls import Outcome, report, score_one

Generate = Callable[[str], str]

SYSTEM = (
    "You call tools. Reply with one JSON object and nothing else: "
    '{"tool": <name>, "arguments": {...}}. '
    'Use {"tool": "none", "arguments": {}} when no tool is needed.'
)


def load_rows(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def run_once(rows: Sequence[dict], generate: Generate) -> list[Outcome]:
    return [score_one(r["tool"], r["arguments"], generate(r["request"])) for r in rows]


def sweep(rows: Sequence[dict], generate: Generate, runs: int = 3) -> list[list[Outcome]]:
    """`runs` independent passes. One run is not a measurement (Phase 13)."""
    return [run_once(rows, generate) for _ in range(runs)]


def fixture_generator(table: dict[str, str]) -> Generate:
    """Tier F. Replays a committed request -> output map.

    A request with no fixture returns the empty string, which scores as
    `parse_failed`. Deliberate: a silent default of "correct" would make a
    missing fixture look like a passing model.
    """
    def generate(request: str) -> str:
        return table.get(request, "")

    return generate


def ollama_generator(model: str, host: str = "http://localhost:11434") -> Generate:
    """Tier A. Greedy decoding, fixed seed, so two sweeps differ only by the model.

    `OllamaHTTPClient` is the class Atlas actually ships (atlas/llm.py); there
    is no `OllamaClient`, and an earlier draft of this file imported that name
    and would have failed at the first Tier A run.

    # not executed during authoring; verified in companion-repo CI
    """
    from atlas.llm import Message, OllamaHTTPClient  # noqa: PLC0415

    client = OllamaHTTPClient(model=model, host=host)

    def generate(request: str) -> str:
        return client.complete(
            [Message(role="system", content=SYSTEM),
             Message(role="user", content=request)],
            temperature=0.0, seed=7, max_tokens=160, output_mode="json",
        ).text

    return generate


def summarise(runs: Iterable[list[Outcome]]) -> str:
    blocks, rates = [], []
    for index, outcomes in enumerate(runs, start=1):
        blocks.append(f"--- run {index} ---\n{report(outcomes)}")
        rates.append(sum(1 for o in outcomes if o == "correct") / len(outcomes))
    spread = max(rates) - min(rates)
    blocks.append(
        f"full-call accuracy across runs: {[round(r, 3) for r in rates]} "
        f"(spread {spread:.3f})"
    )
    return "\n".join(blocks)


def main() -> None:
    ap = argparse.ArgumentParser(description="Score one arm of the tool-call experiment.")
    ap.add_argument("--split", type=Path,
                    default=Path("appendix_c/data/toolcalls_test_seen.jsonl"))
    ap.add_argument("--fixtures", type=Path, default=None, help="Tier F fixture table")
    ap.add_argument("--model", default=None, help="Tier A model id (Ollama)")
    ap.add_argument("--runs", type=int, default=3)
    args = ap.parse_args()

    rows = load_rows(args.split)
    if args.fixtures is not None:
        table = json.loads(args.fixtures.read_text())
        rows = [r for r in rows if r["request"] in table]
        generate = fixture_generator(table)
        print(f"TIER F: {len(rows)} fixture-backed rows of {args.split.name}. "
              "Plumbing, not a measurement.")
    elif args.model is not None:
        generate = ollama_generator(args.model)
        print(f"TIER A: {len(rows)} rows of {args.split.name}, model={args.model}.")
    else:
        raise SystemExit("pass --fixtures (Tier F) or --model (Tier A)")
    if not rows:
        raise SystemExit("no rows to score: the fixture table matches nothing in this split")
    print(summarise(sweep(rows, generate, runs=args.runs)))


if __name__ == "__main__":
    main()
