"""A standalone copy of the two statistics the scorer needs.

Atlas already has these, tested and argued for, in `evals/stats.py`, and
`score_toolcalls` imports them from there whenever it can. This file exists for
exactly one situation: the free-GPU notebook, which has the appendix scripts
uploaded and does NOT have the Atlas snapshot on its path. Without it, the
measurement cell dies on `ModuleNotFoundError` after the fine-tune has already
been paid for.

A second copy of a formula is a second place for it to be wrong, so:
`appendix_c/check_stats_parity.py` asserts these agree with `evals.stats` to
1e-12 across a grid, and it is run from the snapshot root where both exist.
"""
from __future__ import annotations

import math
from typing import NamedTuple

Z95 = 1.959963984540054


class Interval(NamedTuple):
    low: float
    high: float


def wilson_interval(successes: int, trials: int, *, z: float = Z95) -> Interval:
    """Wilson score interval for a binomial proportion (Wilson, 1927)."""
    if trials < 0 or successes < 0:
        raise ValueError("successes and trials must be non-negative")
    if successes > trials:
        raise ValueError(f"successes ({successes}) exceeds trials ({trials})")
    if trials == 0:
        return Interval(0.0, 1.0)
    p = successes / trials
    denominator = 1 + z * z / trials
    centre = (p + z * z / (2 * trials)) / denominator
    spread = z * math.sqrt(p * (1 - p) / trials + z * z / (4 * trials * trials))
    spread /= denominator
    return Interval(max(0.0, centre - spread), min(1.0, centre + spread))


def min_detectable_effect(n: int, p: float = 0.9, *, z: float = Z95) -> float:
    """Smallest difference in pass rate this many items can resolve.

    delta = z * sqrt(2 p (1-p) / n). An APPROXIMATION, present to answer "is
    this delta worth arguing about?" and not to be quoted to three decimals.
    """
    if n <= 0:
        raise ValueError("n must be positive")
    if not 0.0 <= p <= 1.0:
        raise ValueError("p must be in [0, 1]")
    return z * math.sqrt(2 * p * (1 - p) / n)
