# VERSIONS.md delta — Appendix C

Paste these rows into VERSIONS.md. Every one is a current-state fact and will move;
re-verify before relying on any of them. None of these values appears in the appendix prose.

| fact | value | source URL | checked-on |
|---|---|---|---|
| Free-tier notebook GPU type, session length, idle timeout | Not published; Google states limits, idle timeouts, max VM lifetime and GPU types all vary over time | https://research.google.com/colaboratory/faq.html | 2026-09-15 |
| How to learn the GPU you were actually given | Run `!nvidia-smi` in the first cell of every session and size the run to the result | https://research.google.com/colaboratory/faq.html | 2026-09-15 |
| Base model for the Appendix C fine-tune | Qwen/Qwen3-0.6B (any 0.5–1.5B instruction-capable open model works; the choice is not load-bearing) | https://huggingface.co/Qwen/Qwen3-0.6B | 2026-09-15 |
| transformers (PyPI) latest | 5.17.0 | https://pypistats.org/packages/transformers | 2026-09-15 |
| peft (PyPI) latest | 0.19.1 | https://pypistats.org/packages/peft | 2026-09-15 |
| trl (PyPI) latest | 1.12.0 (bit-identical duplicate of 1.11.0; next feature release 1.13.0) | https://github.com/huggingface/trl/releases/tag/v1.12.0 | 2026-09-15 |
| transformers/peft pinning hazard | peft can break against a new transformers major; pin both in the notebook's first cell | https://github.com/huggingface/peft/issues/2754 | 2026-09-15 |
| τ-bench original board status | Frozen; the repository directs new work to successor benchmarks | https://github.com/sierra-research/tau2-bench | 2026-09-15 |
| GEPA reference implementation / DSPy integration | Available as `dspy.GEPA`; algorithm paper arXiv:2507.19457 | https://dspy.ai/api/optimizers/GEPA/overview/ | 2026-09-15 |
| METR time-horizon paper revision | v4, 10 Jul 2026 | https://arxiv.org/abs/2503.14499 | 2026-09-15 |
| TRL flag for assistant-only loss on a `messages` dataset | `assistant_only_loss=True`; needs a chat template with `{% generation %}` markers (TRL patches known families) | https://huggingface.co/docs/trl/en/sft_trainer | 2026-09-15 |
| TRL flag for prompt-completion datasets | `completion_only_loss` (default True for that format); the appendix notebook uses this route | https://huggingface.co/docs/trl/en/sft_trainer | 2026-09-15 |
| Known TRL hazard | `assistant_only_loss=True` is silently ignored when `use_liger_kernel=True` | https://github.com/huggingface/trl/issues/3781 | 2026-09-15 |
| Kaggle notebooks as the Colab alternative | Durable session path `/kaggle/working` (~20 GB, auto-saved); 12 h execution time per CPU/GPU session | https://www.kaggle.com/docs/notebooks | 2026-09-15 |
| Kaggle weekly GPU quota | Stated as 30 h per week, "or sometimes higher depending on demand and resources"; resets weekly | https://www.kaggle.com/docs/efficient-gpu-usage | 2026-09-15 |
| Appendix C cost | $0.00 — free notebook tier, local Ollama, no paid API | — | 2026-09-15 |
