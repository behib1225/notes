"""Assert the notebook's stats fallback agrees with Atlas's `evals/stats.py`.

Run from the snapshot root, where both modules exist:

    PYTHONPATH=. python3 appendix_c/check_stats_parity.py

A duplicated formula that nothing compares is a formula that will drift.
"""
from __future__ import annotations

from evals.stats import min_detectable_effect as mde_atlas
from evals.stats import wilson_interval as wilson_atlas

from appendix_c._stats import min_detectable_effect as mde_local
from appendix_c._stats import wilson_interval as wilson_local

TOL = 1e-12


def main() -> None:
    checks = 0
    for trials in (1, 5, 24, 30, 90, 200, 1000):
        for successes in range(0, trials + 1, max(1, trials // 7)):
            a, b = wilson_atlas(successes, trials), wilson_local(successes, trials)
            assert abs(a.low - b.low) < TOL and abs(a.high - b.high) < TOL, (successes, trials, a, b)
            checks += 1
        for p in (0.5, 0.6, 0.8, 0.9, 0.95):
            assert abs(mde_atlas(trials, p) - mde_local(trials, p)) < TOL, (trials, p)
            checks += 1
    print(f"stats parity: {checks} comparisons, max difference < {TOL}")


if __name__ == "__main__":
    main()
