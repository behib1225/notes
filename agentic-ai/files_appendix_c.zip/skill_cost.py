"""Print what the skill catalogue costs, per level. No model, no network.

§6.12 quotes these numbers. Phase 13's invariant 73 says a number in prose
that no target prints is an opinion, so this is the target. Run from the
snapshot root:

    PYTHONPATH=. python3 appendix_c/skill_cost.py
"""
from __future__ import annotations

import argparse
from pathlib import Path

from atlas.memory.skills import MIN_TRIGGER_MATCHES, load_skill_catalogue, select_skill

PROBES = (
    "how many units shipped last quarter?",
    "what is our refund policy?",
)


def main() -> None:
    ap = argparse.ArgumentParser(description="Per-level cost of the skill catalogue.")
    ap.add_argument("--root", type=Path, default=Path("atlas/skills"))
    args = ap.parse_args()
    catalogue = load_skill_catalogue(args.root)
    if not len(catalogue):
        raise SystemExit(f"no skills under {args.root}")
    for skill in catalogue:
        print(f"{skill.name:<24} level 1: {skill.summary_tokens:>4} tokens   "
              f"level 2: {skill.instruction_tokens():>4} tokens   "
              f"resources: {list(skill.resources)}")
    print(f"\ncatalogue total (level 1, paid on EVERY request): "
          f"{catalogue.catalogue_tokens} tokens")
    print(f"activation threshold: MIN_TRIGGER_MATCHES = {MIN_TRIGGER_MATCHES}\n")
    for probe in PROBES:
        chosen = select_skill(catalogue, probe)
        print(f"select_skill({probe!r}) -> {getattr(chosen, 'name', None)}")


if __name__ == "__main__":
    main()
