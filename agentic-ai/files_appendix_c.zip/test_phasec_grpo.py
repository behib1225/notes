"""Hidden tests for Appendix C, Assignment 1. Run with `make grade PHASE=c`. Named test_phasec_* so the Makefile glob (tests/hidden/test_phase$(PHASE)_*.py) collects it..

Do not read this file. Reproduce each failure with your own test first.
"""
from __future__ import annotations

import math

import pytest

pytest.importorskip("appendix_c.grpo", reason="Assignment 1 module not written yet")

from appendix_c.grpo import group_is_informative, group_relative_advantages  # noqa: E402


def test_advantages_are_centred_and_scaled():
    adv = group_relative_advantages([0.0, 1.0, 1.0, 0.0])
    assert math.isclose(sum(adv), 0.0, abs_tol=1e-9)
    assert math.isclose(sum(a * a for a in adv) / len(adv), 1.0, rel_tol=1e-6)


def test_all_pass_group_is_zero_not_nan():
    adv = group_relative_advantages([1.0] * 8)
    assert all(a == 0.0 for a in adv)
    assert not any(math.isnan(a) for a in adv)


def test_all_fail_group_is_zero_not_nan():
    assert group_relative_advantages([0.0] * 8) == [0.0] * 8


def test_informativeness_matches_the_zero_variance_case():
    assert not group_is_informative([1.0] * 4)
    assert not group_is_informative([0.0] * 4)
    assert group_is_informative([0.0, 1.0])


def test_ordering_is_preserved():
    adv = group_relative_advantages([0.2, 0.9, 0.5])
    assert adv[1] > adv[2] > adv[0]


def test_shift_invariance_and_scale_invariance():
    a = group_relative_advantages([1.0, 2.0, 3.0])
    b = group_relative_advantages([11.0, 12.0, 13.0])
    c = group_relative_advantages([2.0, 4.0, 6.0])
    assert all(math.isclose(x, y, rel_tol=1e-9) for x, y in zip(a, b))
    assert all(math.isclose(x, y, rel_tol=1e-9) for x, y in zip(a, c))


def test_empty_group_raises():
    with pytest.raises(ValueError):
        group_relative_advantages([])
