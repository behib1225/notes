# Appendix C — code package

Everything here runs at **$0.00**. Nothing modifies Atlas.

## Where to put it

Unzip `atlas_appendix_c.zip` **inside the Atlas snapshot root** (the directory
containing `atlas/`, `evals/` and `Makefile`), so you end up with:

```
atlas_phase_16/
├── atlas/            (unchanged)
├── evals/            (unchanged)
├── appendix_c/       ← this package
└── tests/hidden/     ← two new files added here
```

The appendix code imports `atlas.*` and `evals.stats`, so **every command below
is run from the snapshot root with `PYTHONPATH=.`**. Nothing is installed.

Python 3.11+. No dependencies beyond what Atlas already needs (the laptop side
uses only the standard library plus Pydantic, which Atlas already requires).

## Laptop: run everything offline

```bash
# 1. Generate the four seeded splits (idempotent; seed 7).
python3 appendix_c/gen_toolcall_data.py

# 2. Sanity-check the harness on Tier F fixtures: no model, no network.
PYTHONPATH=. python3 -m appendix_c.eval_toolcalls \
    --split appendix_c/data/toolcalls_test_seen.jsonl \
    --fixtures appendix_c/fixtures/toolcalls_before.json

# 3. Prompt optimization over Atlas's real router prompt (Tier F).
PYTHONPATH=. python3 -m appendix_c.apo.optimize_router \
    --candidates appendix_c/fixtures/router_candidates.json \
    --drafts appendix_c/fixtures/router_drafts.json
PYTHONPATH=. python3 -m appendix_c.apo.optimize_router \
    --candidates appendix_c/fixtures/router_candidates.json \
    --drafts appendix_c/fixtures/router_drafts_scenario2.json

# 4. The skill-catalogue cost numbers quoted in §6.12.
PYTHONPATH=. python3 appendix_c/skill_cost.py

# 5. The duplicated statistics in _stats.py agree with Atlas's own.
PYTHONPATH=. python3 appendix_c/check_stats_parity.py
```

Tier A (your local Ollama) for the same harness, about 150 calls:

```bash
export ATLAS_TIER=A ATLAS_MODEL=...      # model id is a VERSIONS.md fact
PYTHONPATH=. python3 -m appendix_c.eval_toolcalls \
    --split appendix_c/data/toolcalls_test_unseen.jsonl --model "$ATLAS_MODEL" --runs 3
```

## Free GPU notebook: the fine-tune

Open `appendix_c/finetune_lora.ipynb` in Colab or Kaggle and upload four files
into the session: `toolcalls_train.jsonl`, `toolcalls_test_seen.jsonl`,
`toolcalls_test_unseen.jsonl`, and `appendix_c/score_toolcalls.py` together with
`appendix_c/_stats.py` (the scorer falls back to `_stats` when Atlas is absent).

Cell 1 prints the GPU you were actually given and pins the libraries; cell 2
sets a checkpoint directory that survives a dead session (Drive on Colab,
`/kaggle/working` on Kaggle); cell 3 trains; cell 4 measures both arms on both
test sets, three runs each.

Expect roughly 15–40 minutes of training plus 10–20 minutes of download and
evaluation. If your configuration projects longer than an hour, cut epochs.

## Assignments

Create `appendix_c/grpo.py` (Assignment 1) and `appendix_c/skill_library.py`
(Assignment 2), then:

```bash
make grade PHASE=c          # collects tests/hidden/test_phasec_*.py
```

Both hidden files skip themselves with a readable message until the module
exists. Do not read them; reproduce each failure with your own test first.

## What is deliberately absent

No `grpo.py`, no `skill_library.py` (those are yours), no generated data (it is
regenerated from the seed), and no measured accuracy numbers — the fine-tune was
never run by the author, so the tables in §7.7 ship with empty cells.
