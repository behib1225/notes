# appendix_c_solutions.md

*Solutions for Appendix C. Concept checks, quiz, both assignments with reference implementations, and the model answer for the critical-reading assignment.*

*Read these after attempting the work. The assignment solutions are one correct design, not the only one; the hidden tests check behaviour, not structure.*

---

## Concept checks

### C1 — The router mislabels a database question as `document`

**Most likely column: the prompt.** Routing is a classification decision made in one call from one instruction, and label confusions are overwhelmingly a description problem — `ROUTE_DESCRIPTIONS["document"]` mentions policies and notes, and a request like "what does the handbook say about headcount" genuinely reads both ways. Fixing the descriptions, or adding a disambiguating sentence to `atlas_router.v1.md`, is minutes of work and fully reversible.

**Evidence that it is a context problem instead:** the misroutes cluster on requests whose vocabulary the prompt never sees — a new product name, a new table — and adding two examples of that vocabulary to the prompt fixes them. That is a retrieval or example-coverage gap, not an instruction gap.

**Evidence that it is a weights problem:** the model gets the label right when you ask it in prose and wrong when you ask for `RouteDraft`-shaped JSON, or `decision.error` is populated on the failures, meaning the classifier could not produce a valid object at all. A model that cannot hold the schema and the decision simultaneously is a model to replace, not a prompt to rewrite.

The diagnostic that separates all three is already recorded: `RouteDecision.model_route`, `decision.error`, and `decision.keyword_hint`. If the keyword prior was right and the model was wrong, the instruction is the suspect.

### C2 — Bad trajectories that survive a "final route was correct" filter

**Two that survive:**

1. **Right route for the wrong reason.** The model outputs `route="data"` with `confidence=0.95` and a `why` naming words that are not in the request. The route is correct, so the filter passes it; train on it and you reinforce a confident guess.
2. **Right route via the fallback.** The model said `tool_action`, `reconcile` refused a side-effecting route over a disagreement, and the fallback `research` happened to be the gold label. The episode is scored correct and the model's contribution was *wrong*. (This is exactly the effect measured in §7.8, scenario 1.)

**Cheap checks:** for (1), require that at least one word in `why` appears in the request — a substring check, no model. For (2), grade `decision.model_route` rather than `decision.route` when what you are collecting is *model* behaviour, and drop any episode where `fallback_used` is true.

### C3 — Average reward climbs, eval does not move

**Three explanations and their diagnostics:**

1. **Reward hacking.** The policy found a way to satisfy the verifier that does not satisfy the task. *Diagnostic:* sample twenty high-reward rollouts and read them. Five minutes, and it is the only check that reliably finds this.
2. **Train/eval mismatch.** You are improving on the training distribution and the eval set measures something else. *Diagnostic:* score the training prompts with the eval harness. If training-prompt eval accuracy rose and eval-set accuracy did not, it is generalization, not gaming.
3. **Entropy collapse / metric saturation.** The reward is rising because the easy items are now always solved and the group has stopped exploring. *Diagnostic:* log mean group standard deviation and the fraction of zero-variance groups per batch. If that fraction is climbing, the gradient is disappearing while the average looks healthy.

A fourth worth mentioning: **length or format artefacts** inflating a reward that correlates with the metric. Diagnostic: plot mean completion length against reward.

### C4 — Best-of-N versus self-consistency

**Best-of-N needs a selector that is better than chance at identifying the correct sample** — a verifier, a test suite, a schema check, or a reward model. Self-consistency needs only that correct answers agree with each other more often than incorrect ones do.

**In Atlas you have a verifier** for: SQL results (the query either runs and returns rows or it does not), file writes (the file exists with the expected content), tool-call arguments (JSON Schema validation through `ToolRegistry`), and citations (does the quoted extract appear in the retrieved chunk). **You do not have one** for the grounded answer's prose quality — which is exactly why Phase 13 had to build a calibrated rubric judge for that, with a κ floor before it is allowed to grade.

**When the model is confidently wrong in a correlated way**, self-consistency fails hardest: the majority vote returns the popular error with high apparent agreement. Best-of-N degrades more gracefully if the verifier is independent of the model — but if the "verifier" is the same model judging itself, it inherits the same correlation and gains nothing.

### C5 — Distilled router degrades silently

**Two deployment conditions:**

1. **Vocabulary drift.** A new product line, department or document type enters the request stream. The student was trained on the teacher's behaviour over last quarter's distribution and has no signal that the request is now out of distribution.
2. **Upstream prompt change.** Someone edits `ROUTE_DESCRIPTIONS` or adds a sixth route. The teacher would adapt from the rendered route table; the student has baked the old label set into its weights and will keep emitting five labels confidently.

**The Atlas record that detects it without a new eval:** `RouteDecision.disagreed` (and `fallback_used`). The keyword prior is deterministic, free, and unaffected by the distillation, so a rise in the disagreement rate between the model and `keyword_route` is a drift alarm that costs nothing and needs no labels. Phase 5 built it as a safety mechanism; it doubles as a monitoring signal.

### C6 — 3 examples on dev, 0 on holdout

**What to do: do not promote.** A 3-item gain on 40 dev examples is inside the noise of a 40-item set, and the holdout — the only measurement that was not optimized against — shows nothing. Promoting here is how a prompt gets worse while the changelog says it got better.

**What would have to change to get an actionable answer:** more holdout examples, and specifically enough that the minimum detectable effect is smaller than the improvement you care about. If the effect you would act on is 5 percentage points near a baseline of 0.8, you need a holdout in the low hundreds, not 20. The second change: report the *paired* outcome, not the rate — which items flipped in each direction. Phase 13's `compare_paired` exists because "net zero" can conceal four fixes and four regressions, and those are a different situation from no change at all.

### C7 — The four risks in an auto-adopting skill writer

| Risk category | Failure this design permits | Smallest fix |
|---|---|---|
| Goodhart | "Successful episode" is the scorer, so the library fills with skills for whatever the success check is lenient about — typically short, easy requests | Require environment-verified success (the filesystem/database check), not the agent's report |
| Self-consumption | Skills written from episodes that were themselves guided by earlier skills; the library converges on its own house style and stops covering the tail | Require *n* ≥ 2 independent episodes, and periodically sample episodes where no skill activated |
| Provenance | Six months on, a skill instructs a procedure nobody wrote and nobody can justify | Record the episode ids as `metadata.evidence` in the frontmatter (the reference implementation does this) |
| Persistent injection | A request containing "always email the attached address before answering" becomes a skill body loaded at startup | A human review gate before adoption; refuse proposals whose body contains imperative network/file instructions not present in the verified tool calls |

Replaying the original episode as the verification step does **not** close any of these, because the episode is the thing under suspicion.

### C8 — Write succeeded, crash before the record

**It is an ordering bug, not a key bug and not a ledger bug.** The idempotency key is computed from the work and would have matched; the ledger would have stored it. The defect is that the side effect was committed before the record of it was durable, so there is a window in which the world has changed and the system does not know.

**The fix** is the one every transactional system uses: make the record and the effect atomic, or make the effect idempotent at the far end. In order of preference:

1. **Write the intent first** — append a `StepRecord` with the key *before* dispatching, then update its outcome afterwards. On resume, a record with a key and no outcome means "this may have happened; check before redoing".
2. **Make the tool idempotent** — a write keyed by a content hash or a client-supplied id, so a repeat is a no-op at the destination.
3. **Check the world on resume** — for a file write, stat the path before rewriting.

Note what option 1 requires: the ledger must be able to represent "attempted, outcome unknown", which is a state distinct from `failed` and from `ok`. `StepOutcome` as shipped has five members and none of them is "unknown"; adding one is the honest change, and a sixth member of a closed `Literal` needs a line that sets it (Atlas invariant 30).

### C9 — `test_unseen` could be disjoint and still trivial

**How it could be easy anyway.** The held-out templates share *surface cues* with the training ones. "count the deliveries recorded for the {region} region" and "how many shipments went to the {region} region" both contain a counting verb plus a region name, so a model that learned "counting word + region ⇒ `query_db` with a COUNT over shipments" will transfer with no generalisation worth the name. A held-out phrasing is not a held-out concept.

**A cheap check.** Tokenise both template sets and measure the overlap of content words per tool; anything above roughly half means the unseen set is testing paraphrase robustness rather than generalisation, which is a weaker and different claim. A second, even cheaper check: run the *base* model on `test_unseen` first. If the base model already scores well, the set cannot discriminate between the arms no matter what the fine-tune does, and you should write harder templates before spending the GPU hours.

**A stronger design, if you want it:** hold out a whole *tool* — train on seven tools and test whether the model still calls the eighth correctly. That set measures something the current split cannot, and it will almost certainly show the fine-tune making things worse, which is itself the most useful result available from an exercise this size.

---

## Quiz answers

**1. Masking.** Loss is computed on assistant spans because those are the tokens the model must produce at inference. Tool observations come from the environment. Training on them teaches the model a distribution over tool *outputs*, and the specific failure that produces is a model that emits a plausible tool result instead of — or immediately after — the call, so the agent proceeds on an invented number that never came from your database. It is the training-time version of grading the transcript instead of the filesystem.

**2. GRPO's substitution.** Benefit: no critic network, so you avoid training a value head on a language-model backbone (which has no settled recipe) and you hold two model copies in memory instead of three. Failure mode: all learning signal comes from *variation within the group*, so any collapse of that variation stops learning — entropy collapse is the gradual version, and a group where every sample fails is the acute version. In the all-fail group, every reward equals the group mean, every advantage is zero, and the batch contributes nothing; operationally this shows up as tasks that are too hard for the current policy silently consuming your entire rollout budget, which is why difficulty filtering and curricula appear in every serious recipe.

**3. RLVR versus RLHF.** RLVR is applicable and RLHF awkward when correctness is computable: "does the SQL return the right rows", "does the patch pass the tests", "is the file at the expected path". Writing a preference model for those wastes human labelling on a question a script answers exactly. The reverse holds for anything where the goal is a judgement: tone in a customer refusal, how much hedging an uncertain answer should carry, whether an explanation is at the right level for the reader. There is no verifier for "appropriately cautious", and a proxy verifier for it will be gamed. The two are complementary, not competing.

**4. Best-of-N versus self-consistency.** Best-of-N requires a *selector* — a verifier or reward model that can pick the correct sample; self-consistency requires only that correct answers cluster. When the model is confidently wrong in a correlated way, self-consistency returns the popular error and reports high agreement (its failure is invisible); best-of-N returns the error only if the verifier also fails, so an independent verifier saves you and a same-model judge does not.

**5. 90% → 95% per step.** Steps completable at 50% success go from about 6.6 to about 13.5 — roughly double. (The general form is ln(0.5)/ln(p).) This makes short-benchmark progress misleading because a 5-point gain on a single-step benchmark looks incremental while the agent-relevant quantity — how long a task you can finish — has doubled. Sinha et al. (2025) make exactly this argument, adding the empirical wrinkle that per-step accuracy is *not* constant: it degrades as a model's own errors accumulate in context, so the geometric model is optimistic.

**6. Auto-adopting skill library, three degradation mechanisms.**
- *Trigger collision*: two skills activate on the same words, so activation becomes a function of tie-breaking rather than of fit. Fix: refuse adoption on overlap of `MIN_TRIGGER_MATCHES` or more.
- *Token floor growth*: level-1 metadata is paid on every request forever, so an unbounded catalogue eats the context budget it was meant to save. Fix: usage counts and a retirement pass.
- *Bad-episode canonization*: an episode that "succeeded" by luck becomes a written procedure that the agent then follows deliberately, converting a one-off into a policy. Fix: environment-verified success plus ≥2 independent episodes.

(A fourth acceptable answer: persistent injection, per C7.)

---

## Assignment 1 — Model answer

### Part A — GRPO explained (model answer, 520 words)

Start with what is being optimized. You have a language model that, given a prompt, produces a sequence of tokens. Call that a policy: a rule that maps a situation to actions. Reinforcement learning adjusts the policy so that whatever you score highly becomes more likely. The score here is a *reward* computed at the end of a completion — a verifier saying the answer is right, the tests pass, the required format was produced.

The classical algorithm for this on language models is PPO, and it needs a second network called a value function whose job is to predict, from a partial completion, the reward you are likely to end up with. You need that prediction because a raw reward is uninformative on its own. "This completion scored 1" tells you nothing until you know whether 1 was easy or hard. The value function supplies the baseline that turns a raw score into "better or worse than expected", which is the quantity policy gradients actually use.

The trouble is that the value function is a second large network. It has to be trained, the research community has no settled recipe for training it well on a language-model backbone, and it doubles the weights you hold in GPU memory during training.

GRPO removes it with one idea: **sample a group of completions for the same prompt and let the group be its own baseline.** Ask the model the same question sixteen times, score all sixteen, compute the mean, and define each sample's advantage as its deviation from that mean, scaled by the group's spread. A completion that beat its siblings gets pushed up; one that lagged them gets pushed down. No prediction of future reward is needed, because you have the empirical distribution of rewards for that exact prompt in front of you. Memory drops from three copies of the model to two, and one hard training problem disappears.

That is the whole method. Everything that goes wrong follows from the fact that the signal is *relative to the group*.

**Failure mode 1: zero-variance groups.** If all sixteen samples pass, or all sixteen fail, every advantage is zero and the batch teaches nothing. *Symptom in the log*: rollout cost per unit of gradient rising; a growing fraction of batches contributing no update; progress stalling while the pass rate looks fine.

**Failure mode 2: entropy collapse.** As training sharpens the policy, completions within a group become near-identical, variance shrinks, and the method starves itself. *Symptom*: mean completion entropy or intra-group diversity falling steadily, then reward plateauing shortly after.

**Failure mode 3: reward hacking.** The policy optimizes the verifier, not the task — exploiting a parsing quirk, a lenient regex, a side effect that satisfies the check. *Symptom*: training reward climbing while a held-out eval does not move; high-reward samples that look wrong to a human on inspection.

**Failure mode 4: length and format artefacts.** Anything correlated with reward gets amplified, and completion length is the usual culprit. *Symptom*: mean completion length growing monotonically with reward, and the gain vanishing when the metric is made length-blind.

The operational summary: GRPO is cheap because it uses the group as a baseline, and fragile for exactly the same reason. Monitor intra-group variance and read your high-reward samples.

### Part B — Reference implementation

```python
"""Group-relative advantages: the arithmetic at the centre of a GRPO update."""
from __future__ import annotations

from typing import Sequence


def group_relative_advantages(rewards: Sequence[float], *, eps: float = 1e-6) -> list[float]:
    """Centre on the group mean and scale by the group standard deviation. Pure.

    The `sd < eps` branch is the whole exercise. A group in which every sample
    scored identically has a standard deviation of zero, and the naive
    expression divides by it: in floating point that is `nan`, and a `nan`
    advantage propagates silently through an optimizer into weights that are
    all `nan` several minutes later. Returning zeros says the true thing --
    this group carries no signal -- and says it in a value the optimizer can
    add to a gradient without destroying it.

    Population standard deviation (divide by n), not the sample estimator
    (n - 1): the group IS the population here. With n - 1 a group of one
    raises ZeroDivisionError instead of returning the correct answer, which is
    that a single sample has no siblings to be better than.
    """
    n = len(rewards)
    if n == 0:
        raise ValueError("a group needs at least one sample")
    mean = sum(rewards) / n
    variance = sum((r - mean) ** 2 for r in rewards) / n
    sd = variance ** 0.5
    if sd < eps:
        return [0.0] * n
    return [(r - mean) / sd for r in rewards]


def group_is_informative(rewards: Sequence[float], *, eps: float = 1e-6) -> bool:
    """Whether this group contributes anything to the update. Pure.

    Defined in terms of the advantages rather than by re-deriving the variance,
    so the two functions cannot disagree. A second computation of the same
    quantity is a second place for the epsilon to be different.
    """
    return any(abs(a) > eps for a in group_relative_advantages(rewards, eps=eps))
```

**Commentary on the acceptance criteria.**

- *Sum to zero, unit mean square*: both follow from standardization; the test checks them because they are the property that makes the value usable as an advantage.
- *All-pass and all-fail return zeros*: the `sd < eps` branch. Note that an implementation that special-cases only `all(r == rewards[0])` passes the tests but breaks on rewards that differ by 1e-12, which is what shaped rewards produce.
- *Shift and scale invariance*: standardization gives these for free, and they matter operationally — they are why you can change your reward from {0,1} to {0,10} without retuning the learning rate.
- *No numpy*: the arithmetic is four lines and the point is to see it.

**The mistake most students make** is dividing by `sd` after computing it with the sample estimator, then discovering the tests fail on a two-element group for a reason that has nothing to do with GRPO. The second most common is returning `float("nan")` for the zero-variance case on the grounds that it is "mathematically honest". It is honest and it is useless: the whole purpose of a defined return is that the caller can sum the batch without special-casing.

Reference run: **7 passed**.

---

## Assignment 2 — Model answer

### Reference implementation

```python
"""A skill library that writes, refuses, and retires.

The loading half already exists (`atlas.memory.skills`) and is imported, never
forked: `valid_skill_name`, `load_skill` and `MIN_TRIGGER_MATCHES` are the
same objects the runtime uses, so a skill this module writes is loadable by
definition rather than by coincidence.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

from atlas.memory.skills import (
    MIN_TRIGGER_MATCHES, SkillCatalogue, SkillError, load_skill, valid_skill_name,
)


@dataclass(frozen=True)
class SkillProposal:
    name: str
    description: str
    triggers: tuple[str, ...]
    body: str
    evidence: tuple[str, ...] = field(default_factory=tuple)

    def render(self) -> str:
        """The SKILL.md text. Evidence goes in the frontmatter, not a comment.

        `metadata.evidence` is the provenance record: six weeks from now the
        only answer to "why does the agent do this?" is the list of episodes
        that produced the procedure. A comment in the body would be equally
        readable and would not survive a body rewrite.
        """
        return (
            "---\n"
            f"name: {self.name}\n"
            f"description: {self.description}\n"
            "metadata:\n"
            f"  triggers: {' '.join(self.triggers)}\n"
            f"  evidence: {','.join(self.evidence)}\n"
            "---\n\n"
            f"{self.body.strip()}\n"
        )


class AdoptionRefused(RuntimeError):
    """A proposal that must not enter the catalogue, named for its remedy."""


def propose_from_episodes(name: str, description: str, body: str,
                          episodes: list[dict]) -> SkillProposal:
    """Build a candidate from episodes the ENVIRONMENT confirmed.

    Two gates, and both are refusals rather than warnings, because a library
    that warns is a library that grows.
    """
    verified = [e for e in episodes if e.get("verified_by_environment")]
    if len(verified) < 2:
        raise AdoptionRefused(
            "a skill needs at least two environment-verified episodes; "
            f"got {len(verified)}"
        )
    words = re.findall(r"[a-z0-9]+", " ".join(e["request"] for e in verified).lower())
    counts: dict[str, int] = {}
    for word in words:
        if len(word) > 3:
            counts[word] = counts.get(word, 0) + 1
    # A trigger must appear in EVERY verified episode, not merely often: a word
    # from one long request would otherwise out-count a word shared by all.
    triggers = tuple(sorted(w for w, c in counts.items() if c >= len(verified)))
    if len(triggers) < MIN_TRIGGER_MATCHES:
        raise AdoptionRefused(
            f"fewer than {MIN_TRIGGER_MATCHES} shared trigger words; the episodes "
            "do not describe one procedure"
        )
    return SkillProposal(name, description, triggers, body,
                         tuple(e["id"] for e in verified))


def adopt(proposal: SkillProposal, catalogue: SkillCatalogue, root: Path):
    """Write the skill, or refuse and leave the disk untouched.

    Every check runs BEFORE the directory is created, and the one check that
    cannot (does the written file actually load?) unwinds what it wrote. A
    refusal that leaves half a skill behind is worse than no refusal: the next
    `load_skill_catalogue` either raises on a malformed directory or, worse,
    loads something nobody approved.
    """
    if not valid_skill_name(proposal.name):
        raise AdoptionRefused(f"invalid skill name {proposal.name!r}")
    if proposal.name in catalogue.names:
        raise AdoptionRefused(f"{proposal.name!r} already exists; merge, do not shadow")
    for existing in catalogue:
        overlap = set(existing.triggers) & set(proposal.triggers)
        if len(overlap) >= MIN_TRIGGER_MATCHES:
            raise AdoptionRefused(
                f"trigger collision with {existing.name!r} on {sorted(overlap)}: "
                "two skills that activate together make activation a coin toss"
            )
    folder = root / proposal.name
    folder.mkdir(parents=True, exist_ok=False)
    (folder / "SKILL.md").write_text(proposal.render(), encoding="utf-8")
    try:
        return load_skill(folder)
    except SkillError:
        (folder / "SKILL.md").unlink()
        folder.rmdir()
        raise


def retire_unused(catalogue: SkillCatalogue, usage: dict[str, int],
                  *, min_uses: int = 1) -> list[str]:
    """Names below the usage threshold, sorted. Returns; does not delete.

    Deletion is a human's decision for the same reason prompt promotion is: a
    skill that went unused for a month may be the one that covers the annual
    audit. The function's job is to make the cost visible, not to act on it.
    """
    return sorted(s.name for s in catalogue if usage.get(s.name, 0) < min_uses)
```

Reference run: **8 passed**.

### The refusal rules, justified (the UNAIDED CORE)

**Two environment-verified episodes.** One episode is an anecdote and the agent's own report of success is the least reliable evidence in the system — Phase 13 established that the transcript is generated by the thing under test. Requiring two *independent* episodes also enforces something subtler: a procedure that generalizes has been reached twice from different requests, while a one-off is usually a fix for a situation that will not recur. The cost of the rule is latency in acquiring skills; the benefit is that the library contains procedures rather than memories.

**At least `MIN_TRIGGER_MATCHES` shared trigger words.** If two verified episodes share fewer than two content words, they are not the same procedure, and any skill written over both will be wrong for at least one of them. Reusing Atlas's own constant rather than inventing a threshold matters: the number that decides *activation* and the number that decides *adoption* are the same question asked at two times, and letting them drift apart would allow a skill to be adopted that can never activate.

**Trigger collision refusal.** This is the rule that keeps the library usable as it grows. `select_skill` breaks ties by name, so two skills sharing two or more triggers means activation is decided by alphabetical order — a property of directory naming, not of fit. Refusing the second one forces the real decision (merge them, or narrow one's triggers) to happen at adoption time, when a human is present, rather than at 3 a.m. when the wrong procedure loads.

**Nothing on disk after a refusal.** A half-written skill is indistinguishable from an adopted one to the loader, which is how an unreviewed procedure enters production. The ordering — validate, then create, then verify-and-unwind — is the same discipline as C8's: never leave the world in a state your records do not describe.

---

## Section 15 — Model answer: a review of GEPA (Agrawal et al., 2025/2026)

**Paper reviewed:** Lakshya A Agrawal, Shangyin Tan, Dilara Soylu, Noah Ziems, Rishi Khare, Krista Opsahl-Ong, Arnav Singhvi, Herumb Shandilya, Michael J Ryan, Meng Jiang, Christopher Potts, Koushik Sen, Alexandros G. Dimakis, Ion Stoica, Dan Klein, Matei Zaharia, Omar Khattab. *GEPA: Reflective Prompt Evolution Can Outperform Reinforcement Learning.* arXiv:2507.19457, v1 25 July 2025, v2 14 February 2026. Accepted to ICLR 2026 (Oral). Reviewed 15 September 2026.

### 1. Claim

Optimizing a system's *prompts* by having a model read its own trajectories and write natural-language diagnoses can reach higher task accuracy than optimizing the model's *weights* with a GRPO-style RL run, while spending far fewer rollouts.

### 2. Setup

**Stated.** Six tasks spanning multi-hop question answering (HotpotQA), competition maths (AIME, LiveBench-Math), instruction following (IFBench), privacy-aware delegation (PUPA) and retrieval-augmented verification (HoVer). Two models: one open (Qwen3 8B) and one proprietary (GPT-4.1 Mini). The RL comparison is a GRPO run at 24,000 rollouts on the open model. Budget matching is described explicitly for the prompt-optimizer comparison: the authors record MIPROv2's rollout usage per benchmark and cap GEPA to match, reporting agreement within about 10%. They also state that most of GEPA's counted rollouts are spent on the validation set for candidate *selection* rather than for learning signal. Code is released.

**Missing, and why each matters.**
- **Number of trials.** The v1 paper reports single-trial scores. With prompt optimization this is the most consequential omission there is: candidate selection is stochastic, and one run cannot separate a better optimizer from a luckier one.
- **Whether the GRPO baseline was tuned with comparable effort.** 24,000 rollouts is a budget, not evidence of a good configuration. No hyperparameter search for the RL arm is described at the level given for the prompt arm.
- **Reflector cost.** GEPA uses a model to reflect and propose. Rollouts are counted; reflection calls and their tokens are not presented on the same axis, so "35× fewer rollouts" is not "35× cheaper".

### 3. Baselines

Two: MIPROv2 (the prior leading prompt optimizer) and GRPO (the RL arm). The MIPROv2 comparison is the more careful of the two — budgets are matched deliberately, and the authors note the asymmetry that GEPA optimized instructions only while MIPROv2 also optimizes demonstrations, which cuts *against* their own result and is creditable to report.

The GRPO comparison is where I would push. The two methods are not matched on any shared axis except rollouts: they modify different artefacts (text versus weights), they consume different resources (inference calls versus training compute), and they have different transferability (a prompt is model-specific in one way, an adapter in another). "Fewer rollouts" is a real and interesting efficiency claim; "outperforms RL" invites a stronger reading — that prompt search dominates weight search — which a single GRPO configuration on one 8B model cannot support.

### 4. Measurement

The metric is per-task accuracy on held-out test sets, and the headline is an aggregate across tasks. Three critiques:

**The headline changed between revisions**, which is itself the most useful thing in this review. Every quantitative claim, with its setup, so none of it sits loose in prose:

| Claim | Source and revision | Setup | Checked |
|---|---|---|---|
| Outperforms GRPO by ~10% on average, up to 20%, with up to 35× fewer rollouts, across **four** tasks | arXiv:2507.19457 **v1**, 25 Jul 2025 | Qwen3 8B and GPT-4.1 Mini; GRPO arm at 24,000 rollouts; single-trial scores | 2026-09-15 |
| Outperforms GRPO by ~6% on average, up to 20%, with up to 35× fewer rollouts, across **six** tasks | arXiv:2507.19457 **v2**, 14 Feb 2026 (ICLR 2026 oral) | Same models; tasks now include AIME and LiveBench-Math | 2026-09-15 |
| Outperforms MIPROv2 by over 10% (e.g. +12% on AIME-2025) | arXiv:2507.19457 v2 | Rollout budgets matched to MIPROv2's usage, within ~10% | 2026-09-15 |
| Independent reproduction lands −3.78 to +7.97 pp from published scores | FAPO, arXiv:2606.19605, 2026 | Different (stronger) reflector model; three-trial means vs the original's single trial | 2026-09-15 |

*Every row will be stale by the time you read it, and the first two rows are the same paper.* A reader citing "GEPA beats GRPO by 10%" from a secondary source in 2026 is quoting a superseded abstract — several write-ups still do. **Always cite the revision you read.**

**Aggregate-over-tasks hides dispersion.** A mean across six heterogeneous benchmarks is not a quantity with a standard error you can reason about. The per-task numbers in the paper span a wide range (from a couple of points to roughly nineteen on the tasks reported individually in v1), which means the average is doing a lot of work that the reader cannot audit without the table.

**Single-trial reporting.** This is the most serious one, and an independent group has now quantified its effect — see §6.

**What could move the metric without capability changing:** the reflector model. GEPA's proposal step uses a model to read trajectories and write prompt edits. A stronger reflector produces better candidates without the *algorithm* being better, so the method's score is partly a measurement of whatever model was in the reflector slot on that day.

### 5. Demonstrated / claimed / speculated

**Demonstrated** (within the stated setup): that reflective prompt evolution reaches higher test scores than MIPROv2 under matched rollout budgets on these tasks and models; that it reaches GRPO's best validation score at a small fraction of GRPO's rollout count; that Pareto-frontier candidate selection beats naive best-candidate selection (an ablation, which is the paper's most portable contribution).

**Claimed** (asserted on the evidence, but under-determined by it): that prompt evolution "can outperform reinforcement learning" as a general proposition; that the shorter prompts translate into production cost savings; that gains on IFBench show transferable principles rather than fortunate wording.

**Speculated** (the paper's framing, not its data): that natural language is intrinsically a richer learning medium than scalar rewards. This is the paper's animating idea and it is an argument, not a measurement. Nothing in the experiments isolates "richness of medium" from "reflector model quality" or from "text search has a smaller effective parameter space and therefore overfits less at small budgets".

### 6. Contradicting or complicating work

I searched for reproductions and critiques and found one directly relevant, plus a family of results that complicates the framing.

**A reproduction with a measured discrepancy.** A 2026 paper introducing a different automated prompt-optimization system (FAPO, arXiv:2606.19605) reports reproducing GEPA's scores and finding them several points away from the published values in both directions — the fourth row of the table in §4. Two of their notes matter: they used a different (and stronger) reflector model than the original, which they say may have helped GEPA on some tasks; and they observe that the original paper reports single-trial scores while they report three-trial means with standard deviations. That is a reproduction that does not overturn the paper but does bound how precisely its numbers should be read — a ±5-point band around published values is wider than several of the per-task margins being claimed.

**A complicating family.** Work such as Critique-GRPO (arXiv:2506.03106) integrates natural-language feedback *into* RL rather than as an alternative to it, reporting gains over plain GRPO. If natural-language feedback can be folded into weight-space optimization, then "language versus policy gradients" is a false dichotomy, and the interesting variable is *feedback richness* rather than *which artefact you update*.

**No reproduction contradicts the sample-efficiency claim**, which I take to be the paper's durable contribution.

### 7. The discriminating experiment

The alternative explanation I most want ruled out is: **GEPA wins because its reflector is a strong model doing prompt engineering, not because reflective evolution is a better optimizer.**

*Experiment.* Hold the task, the student model, the rollout budget and the evaluation fixed. Vary only the reflector across three tiers — a frontier model, a mid-tier model, and the student model reflecting on itself — and run three seeds each. Add a fourth arm: the same rollout budget spent on random instruction sampling from the strongest reflector (proposal without reflection), which separates "a good model writing candidates" from "a good model *diagnosing failures*".

*Predictions.* If the method is doing the work, the ranking across reflector tiers should compress and the self-reflection arm should still beat the random-proposal arm. If the reflector is doing the work, performance should track reflector strength almost monotonically and the random-proposal arm from the frontier model should close most of the gap.

This is runnable by a small team: the code is released, the tasks are public, and the whole design is four arms × three seeds on one task.

### 8. Transfer to Atlas

Yes, and specifically. The appendix's own optimization pass (`appendix_c/apo/optimize_router.py`) is a crude ancestor of this method: it scores fixed candidates. GEPA's contributions I would actually adopt are two, and neither requires their code:

- **Reflect on trajectories, not on scores.** My loop scores a candidate and moves on. Feeding the *failing examples with their recorded `RouteDecision` fields* into the proposal step is a small change with a clear rationale, and Atlas already records everything needed.
- **Keep a frontier, not a champion.** My loop keeps the single best dev scorer, which is exactly the greedy behaviour GEPA's Pareto ablation identifies as a local-optimum trap. Keeping the best candidate *per example class* — per route, here — is a five-line change to `optimize()`.

What I would *not* adopt is the headline conclusion. Atlas's router has no RL arm to beat, and the relevant comparison for a small system is "optimizer versus a careful afternoon of human prompt editing", which this paper does not measure.

### 9. Verdict

A practitioner should believe that reflective prompt evolution is a strong, sample-efficient prompt optimizer, and that on these tasks and models it reached better scores than one GRPO configuration at a small fraction of the rollouts — a result worth acting on if you are choosing between tuning prompts and training weights on a small budget. A practitioner should *not* believe that prompt optimization generally dominates RL; the comparison rests on a single RL configuration, single-trial scores, and an aggregate whose headline value changed between revisions, and an independent reproduction puts published scores within a several-point band. The portable lessons are the mechanisms, not the margins: reflect on trajectories rather than on scalars, and keep a frontier of candidates rather than a champion.

---

*End of Appendix C.*
