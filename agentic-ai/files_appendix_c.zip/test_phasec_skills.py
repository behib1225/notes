"""Hidden tests for Appendix C, Assignment 2. Do not read this file."""
from __future__ import annotations

import pytest

pytest.importorskip("appendix_c.skill_library", reason="Assignment 2 module not written yet")

from atlas.memory.skills import load_skill_catalogue  # noqa: E402

from appendix_c.skill_library import (  # noqa: E402
    AdoptionRefused,
    SkillProposal,
    adopt,
    propose_from_episodes,
    retire_unused,
)

EPISODES = [
    {"id": "e1", "request": "prepare the quarterly shipment briefing", "verified_by_environment": True},
    {"id": "e2", "request": "prepare a quarterly shipment summary", "verified_by_environment": True},
]


def _proposal(**over):
    base = dict(name="quarterly-briefing", description="Prepare a quarterly briefing.",
                triggers=("quarterly", "shipment"), body="Do step one, then step two.")
    base.update(over)
    return SkillProposal(**base)


def test_unverified_episodes_are_refused():
    episodes = [dict(e, verified_by_environment=False) for e in EPISODES]
    with pytest.raises(AdoptionRefused):
        propose_from_episodes("x-y", "d", "b", episodes)


def test_single_episode_is_refused():
    with pytest.raises(AdoptionRefused):
        propose_from_episodes("x-y", "d", "b", EPISODES[:1])


def test_proposal_has_at_least_two_triggers():
    proposal = propose_from_episodes("quarterly-briefing", "d", "b", EPISODES)
    assert len(proposal.triggers) >= 2
    assert proposal.evidence == ("e1", "e2")


def test_rendered_skill_round_trips_through_the_atlas_loader(tmp_path):
    skill = adopt(_proposal(), load_skill_catalogue(tmp_path), tmp_path)
    assert skill.name == "quarterly-briefing"
    assert set(skill.triggers) == {"quarterly", "shipment"}
    assert "step one" in skill.instructions()


def test_invalid_name_is_refused_and_writes_nothing(tmp_path):
    with pytest.raises(AdoptionRefused):
        adopt(_proposal(name="Quarterly_Briefing"), load_skill_catalogue(tmp_path), tmp_path)
    assert list(tmp_path.iterdir()) == []


def test_trigger_collision_is_refused(tmp_path):
    adopt(_proposal(), load_skill_catalogue(tmp_path), tmp_path)
    catalogue = load_skill_catalogue(tmp_path)
    with pytest.raises(AdoptionRefused):
        adopt(_proposal(name="quarterly-report"), catalogue, tmp_path)


def test_duplicate_name_is_refused(tmp_path):
    adopt(_proposal(), load_skill_catalogue(tmp_path), tmp_path)
    with pytest.raises(AdoptionRefused):
        adopt(_proposal(triggers=("invoices", "ledger")), load_skill_catalogue(tmp_path), tmp_path)


def test_retirement_lists_the_unused(tmp_path):
    adopt(_proposal(), load_skill_catalogue(tmp_path), tmp_path)
    catalogue = load_skill_catalogue(tmp_path)
    assert retire_unused(catalogue, {}) == ["quarterly-briefing"]
    assert retire_unused(catalogue, {"quarterly-briefing": 3}) == []
