"""Automatic prompt optimization over Atlas's real router prompt.

Optimizes `atlas_router` (the file `atlas/prompts/files/atlas_router.v1.md`)
against `atlas.flow.route`'s own decision rules: the candidate prompt changes
only the MODEL's opinion, while `keyword_route` and `reconcile` stay exactly as
Phase 5 wrote them. That is the point -- what is being tuned is one input to a
decision, not the decision.

Three rules the loop enforces in code rather than in prose:

* **The incumbent wins ties.** A candidate must score STRICTLY higher on dev to
  be promoted. An equal score is not evidence, and a loop that swaps on ties
  drifts for free.
* **The holdout is measured once, at the end, for the winner only.** Scoring
  every candidate on the holdout turns it into a second dev set.
* **Nothing is written to `atlas/prompts/files/`.** The loop reports; a human
  promotes, with a CHANGELOG entry naming this measurement. An optimizer with
  write access to the artefact directory is an unreviewed author.

Run from the snapshot root (Tier F: no model, no network):

    PYTHONPATH=. python3 -m appendix_c.apo.optimize_router \
        --candidates appendix_c/fixtures/router_candidates.json \
        --drafts appendix_c/fixtures/router_drafts.json

    # the second scenario, where the fallback cannot rescue the incumbent
    PYTHONPATH=. python3 -m appendix_c.apo.optimize_router \
        --candidates appendix_c/fixtures/router_candidates.json \
        --drafts appendix_c/fixtures/router_drafts_scenario2.json
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Callable, NamedTuple, Sequence

from atlas.flow.route import (
    DEFAULT_THRESHOLD,
    RouteDecision,
    keyword_route,
    reconcile,
    render_route_table,
)
from atlas.llm import FakeLLMClient, Message, structured
from atlas.prompts import checksum_of, load_prompt
from atlas.schemas import RouteDraft

from appendix_c.apo.routing_set import build, split

DraftFn = Callable[[str, str], RouteDraft | None]
"""(candidate_id, request) -> the model's RouteDraft, or None on failure."""


class Candidate(NamedTuple):
    id: str
    text: str

    @property
    def checksum(self) -> str:
        return checksum_of(self.text)


class Scored(NamedTuple):
    candidate: Candidate
    correct: int
    n: int

    @property
    def accuracy(self) -> float:
        return self.correct / self.n if self.n else 0.0


def decide(request: str, draft: RouteDraft | None,
           *, threshold: float = DEFAULT_THRESHOLD) -> RouteDecision:
    """Phase 5's reconciliation, with the model's opinion supplied.

    A fork of `classify_route`'s tail rather than a call to it, for one reason
    worth stating: `classify_route` builds its prompt internally with
    `build_router_prompt()`, so the prompt is not a parameter and a candidate
    cannot be injected. That is a finding about Atlas, not about the optimizer
    -- see the prose. The DECISION RULES are imported, never reimplemented.
    """
    hint, hint_confidence = keyword_route(request)
    if draft is None:
        return RouteDecision(
            request=request, route="research", confidence=0.0, source="fallback",
            fallback_used=True, reason="classifier failed", keyword_hint=hint,
            keyword_confidence=hint_confidence, error="unparseable",
        )
    resolution = reconcile(draft.route, draft.confidence, hint, hint_confidence,
                           threshold=threshold)
    return RouteDecision(
        request=request, route=resolution.route, confidence=resolution.confidence,
        source=resolution.source, fallback_used=resolution.fallback_used,
        reason=resolution.reason, model_route=draft.route,
        model_confidence=draft.confidence, keyword_hint=hint,
        keyword_confidence=hint_confidence, why=draft.why,
    )


def score(candidate: Candidate, rows: Sequence[dict[str, str]],
          draft_fn: DraftFn) -> Scored:
    correct = sum(
        1 for row in rows
        if decide(row["request"], draft_fn(candidate.id, row["request"])).route
        == row["route"]
    )
    return Scored(candidate, correct, len(rows))


def fixture_draft_fn(path: Path) -> DraftFn:
    """Tier F. A committed table of (candidate, request) -> scripted draft.

    The numbers this produces are FIXTURES, invented to exercise the loop's
    selection rule. They are not a measurement of any prompt.
    """
    table = json.loads(path.read_text())

    def draft_fn(candidate_id: str, request: str) -> RouteDraft | None:
        payload = table.get(candidate_id, {}).get(request)
        if payload is None:
            return None
        client = FakeLLMClient([payload])
        try:
            # `structured` returns the validated value WITH its cost evidence;
            # the draft is `.value`. Going through it rather than json.loads is
            # deliberate: the fixture then exercises the same parse and repair
            # path a real call would take.
            return structured(
                client,
                [Message(role="system", content="scripted"),
                 Message(role="user", content=f"Request: {request}")],
                RouteDraft, temperature=0.0, seed=7, max_tokens=160,
            ).value
        except Exception:  # noqa: BLE001 -- a classifier failure is a fallback
            return None

    return draft_fn


def optimize(candidates: Sequence[Candidate], draft_fn: DraftFn,
             *, n: int = 48, seed: int = 7) -> str:
    rows = build(n=n, seed=seed)
    dev, holdout = split(rows)
    scored = [score(c, dev, draft_fn) for c in candidates]
    incumbent = scored[0]
    best = max(scored[1:], key=lambda s: s.accuracy, default=None)
    winner = (
        best if best is not None and best.correct > incumbent.correct else incumbent
    )
    lines = [f"dev n={len(dev)}  holdout n={len(holdout)}", ""]
    for entry in scored:
        mark = "*" if entry.candidate.id == winner.candidate.id else " "
        lines.append(
            f"{mark} {entry.candidate.id:<12} {entry.candidate.checksum}  "
            f"dev {entry.correct}/{entry.n} = {entry.accuracy:.3f}"
        )
    final = score(winner.candidate, holdout, draft_fn)
    base = score(incumbent.candidate, holdout, draft_fn)
    from evals.stats import min_detectable_effect, wilson_interval  # noqa: PLC0415

    interval = wilson_interval(final.correct, final.n)
    lines += [
        "",
        f"winner: {winner.candidate.id} "
        + ("(incumbent kept: no candidate beat it on dev)"
           if winner.candidate.id == incumbent.candidate.id else "(promoted)"),
        f"holdout incumbent {base.correct}/{base.n} = {base.accuracy:.3f}",
        f"holdout winner    {final.correct}/{final.n} = {final.accuracy:.3f}  "
        f"95% CI [{interval.low:.3f}, {interval.high:.3f}]",
        f"minimum detectable effect at holdout n={final.n}: "
        f"{min_detectable_effect(final.n, p=max(base.accuracy, 0.5)):.3f}",
        "",
        "Nothing was written. To adopt: copy the winning text to "
        "atlas/prompts/files/atlas_router.v2.md, update the pinned checksum, "
        "and add a CHANGELOG entry naming this run.",
    ]
    return "\n".join(lines)


def load_candidates(path: Path | None) -> list[Candidate]:
    """Candidate 0 is always the incumbent, read from the real prompt file."""
    incumbent = Candidate(
        "incumbent",
        load_prompt("atlas_router", version=1).render(route_table=render_route_table()),
    )
    if path is None:
        return [incumbent]
    proposals = json.loads(path.read_text())
    return [incumbent] + [Candidate(p["id"], p["text"]) for p in proposals]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidates", type=Path, required=True)
    ap.add_argument("--drafts", type=Path, required=True,
                    help="Tier F fixture table of scripted model drafts")
    ap.add_argument("--n", type=int, default=48)
    args = ap.parse_args()
    print("TIER F: scores below come from committed fixtures, not from a model.")
    print(optimize(load_candidates(args.candidates),
                   fixture_draft_fn(args.drafts), n=args.n))


if __name__ == "__main__":
    main()
