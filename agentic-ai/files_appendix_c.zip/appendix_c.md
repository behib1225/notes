# Appendix C — Training Agents, Self-Improvement, Long-Horizon Tasks, and Open Problems

*Optional. Read this if you want to know why agents got reliable, and how to read new work critically.*

*Per the appendix plan, this appendix omits section 2 (cumulative review), section 8 (debug this trace) and section 11 (capstone increment): it teaches, it does not grow Atlas, and it adds no eval tasks.*

---

## 1. [core] Appendix C | Study hours (read / build / assess): 7 / 4 / 3 | Compute: ~25 min laptop, plus one free-GPU notebook session of ~60–90 min | Tier A calls per sweep: ~150 (0 if you stay on Tier F) | Tier H calls: 0 | Cost: $0.00 | Repo snapshot: atlas_appendix_c.zip

**What runs where.** This appendix has three kinds of material, and it is worth knowing before you start which is which:

| Part | Where it runs | What you need |
|---|---|---|
| Sections 3–6 (all four parts' concepts) | Reading only | Nothing |
| The prompt-optimization pass on one Atlas subtask (Part 3) | Your 16 GB laptop | The Atlas snapshot; Tier F needs no model at all, Tier A needs your local Ollama |
| The LoRA fine-tune and the before/after tool-call measurement (Part 3) | A **free GPU notebook** (Colab or Kaggle), not the laptop | A browser and a free account |
| The dataset generator, the eval harness, the scorer (Part 3) | Your laptop | Python only, no GPU, no network |
| Assignments 1 and 2, the critical-reading assignment (Part 3) | Laptop / reading | Nothing extra |

The fine-tune is sized so a **single free session finishes it**. Everything else is CPU-only or pure reading. Cost stays at $0.00: no paid API, no rented GPU, no subscription. Nothing in this appendix requires Tier H, and nothing requires Appendix B.

**The four parts.** Part 1 covers how agents are *trained*: supervised fine-tuning on trajectories, rejection sampling, reinforcement learning with verifiable rewards, where tool-use datasets come from, why reasoning models changed agent reliability, the economics of test-time compute, and distillation into small models. Part 2 covers systems that improve themselves — automatic prompt optimization, learned tools, skill libraries — plus long-horizon agents and simulation environments. Part 3 is the hands-on, the open problems, and the assessment. Part 4 is the solutions document.

---

## 3. [core] Why this appendix matters

**Read this if** you have finished the core track and one of these is true. You want to know *why* the agents you can build today work better than the ones people were building three years ago, and the honest answer involves training, not prompting. You are reading new agent papers and want a procedure for telling a real result from a press release. Or you are being asked at work whether to fine-tune, and you would like to know what that buys and what it does not.

Everything Atlas does, it does with a frozen model. Sixteen phases changed prompts, context, control flow, tools, permissions and measurement, and never once changed a weight. That was deliberate — the engineering that makes agents reliable is overwhelmingly *outside* the model, and putting it first is the right pedagogical order. But it leaves a gap. When you read that a model is "better at agentic tasks", the improvement came from somewhere, and that somewhere is a training pipeline: trajectories collected, filtered, and optimized against a reward. If you do not know roughly what that pipeline looks like, you cannot predict what will get better next year, you cannot read the papers that claim it has, and you will be vulnerable to the two opposite mistakes: believing a fine-tune will fix a problem that is actually an architecture problem, and believing no training change could ever matter to your system.

There is a second reason, and it is the one the appendix is really organized around. **This is the material with the shortest half-life in the whole book.** Phase 6's retrieval arithmetic will be true in ten years. The claim "method X improves agent reliability" was, in several documented cases, true in one lab's setup and not in another's. So the product of this appendix is not a set of facts about training; it is a *reading protocol*. Every result below comes with the setup it was obtained under, and every contested result is labelled as contested rather than resolved in whichever direction I happen to find convincing.

**Nothing later depends on this appendix.** There is no later. Appendix C does not modify Atlas, does not add eval tasks, and does not change any interface in `ATLAS_INTERFACES.md`. If you read it years after Phase 16, or never, the rest of the book stands.

---

## 4. [core] Learning objectives

By the end of this appendix you will be able to:

1. **Describe** how a tool-use trajectory becomes a supervised training example, including which tokens carry loss and which are masked, and say what that masking choice implies about what the model learns.
2. **Explain** rejection-sampling fine-tuning intuitively, name the filter it depends on, and identify the failure mode that arises when the filter checks outcomes but the training data contains reasoning.
3. **Explain a GRPO-style method** to a colleague in plain words — what replaces the value function, why that is cheaper — and name at least four documented failure modes of RL on verifiable rewards.
4. **Distinguish** RLHF, RLAIF and RLVR by what produces the reward signal, and say which tasks each is and is not applicable to.
5. **State** the contested question about whether RL expands a model's capability or sharpens its sampling, cite at least one primary source on each side, and say what evidence would settle it.
6. **Compute** the cost of a test-time-compute strategy in calls, tokens and wall-clock, and say when best-of-N is available to you and when it is not.
7. **Run** a LoRA fine-tune of a small open model on a seeded synthetic tool-calling dataset in a single free-GPU session, and **measure** tool-call accuracy before and after under a protocol you wrote down first.
8. **Run** an automatic prompt-optimization pass over one real Atlas subtask, with a held-out split, and say what a movement of that size on a set of that size can and cannot support.
9. **Implement** a skill library that writes down what worked and retrieves it later, and **state** three ways such a library degrades if nobody curates it.
10. **Review** a recent agent paper against a written template: separating what was demonstrated, what was claimed, and what was speculation, and naming the experiment that would discriminate between them.

---

## 5. [core] Prerequisites & quick recap

**What this assumes from the core.** You should have finished Phase 16, or at least be comfortable with the Atlas snapshot. Five ideas from earlier phases are used here without re-teaching:

- **Prompts are versioned artifacts** (Phase 3 onward): `atlas/prompts/__init__.py` loads a named prompt at a pinned version and a test pins its checksum, which is exactly the seam an optimizer needs.
- **Routing is a classification subtask with a recorded decision** (Phase 5): `atlas.flow.route.classify_route` returns a `RouteDecision` object rather than dispatching directly, which is what lets us grade a prompt without running a handler.
- **Skills are instructions with progressive disclosure** (Phase 8): `atlas/memory/skills.py` loads a `SKILL.md` per directory, with level-1 metadata paid on every request and the body paid only on activation.
- **An eval is an estimate; a test is a proposition** (Phase 13). Everything in this appendix that touches model behaviour is an estimate, with an interval, from a seeded run.
- **A number in prose that no target prints is an opinion** (Phase 13's invariant 73). That rule is why the measurement tables in Part 3 have blank cells where I could not run the experiment.

**A two-paragraph orientation on fine-tuning vocabulary**, since the core track never needed it. *Fine-tuning* means continuing gradient training on a pretrained model with new data. *Full fine-tuning* updates every weight, which for even a small model means holding the weights, their gradients and the optimizer state in GPU memory simultaneously — several times the model's size, which is why it does not fit in a free notebook. **LoRA** (low-rank adaptation) instead freezes the original weights and trains a small pair of low-rank matrices that are added to selected weight matrices; you train and ship a few million parameters instead of a few billion, and at inference you either keep the adapter separate or merge it back in. That is the only reason the Part 3 hands-on is possible at $0.00.

The second piece of vocabulary is *loss masking*. Training is next-token prediction, so by default the model is penalized for failing to predict every token in the example, including the user's question and the tool's output. That is wrong for agent data: the user's phrasing is an input you never want the model to generate, and a tool result is the environment speaking, not the agent. So you mark which spans carry loss. Concretely, for a trajectory, loss is computed on the **assistant** spans — the tool calls and the final answer — and *not* on the user turn or the tool observations. Appendix A has the PyTorch and tokenizer background if you want it; you will not need it to follow the prose.

---

## 6. [core] Core concepts

### 6.1 [core] Three levers, and where training sits

You have exactly three ways to change what an agent does.

```
                     what you can change
                             |
      +----------------------+----------------------+
      |                      |                      |
  THE PROMPT            THE CONTEXT             THE WEIGHTS
 (instructions,      (retrieval, memory,      (SFT, rejection
  tool schemas,       tools available,         sampling, RL,
  output format)      scaffolding)             distillation)
      |                      |                      |
  seconds to change     minutes to change      hours to days
  free                  cheap                  GPU + data
  fully reversible      fully reversible       a new artifact
  Phases 1-8            Phases 6-15            THIS APPENDIX
```

The core track spent sixteen phases on the first two columns, and the ordering was not arbitrary. The first two levers are faster, cheaper, reversible, and — for the failures you will actually encounter in a small company's assistant — usually the right ones. The third column is where the industry's capability gains came from, and it is mostly not something you do. It is something done for you, by whoever trained the model you call.

The practical value of understanding column three is *diagnostic*. When your agent calls the wrong tool, the fix depends on which column the defect lives in: an ambiguous schema is a prompt problem, a missing example is a context problem, and a model that cannot reliably emit valid JSON at all is a weights problem you solve by changing models, not by adding a third retry.

> **Misconception 1: "Fine-tuning teaches the model facts."** It mostly does not, and treating it as a knowledge-insertion mechanism is the single most expensive mistake teams make. Fine-tuning is very good at teaching *form* — an output shape, a calling convention, a house style, when to reach for a tool. It is unreliable at teaching *content*, because a fact seen a handful of times in fine-tuning data competes with everything seen during pretraining, and the model has no way to mark it as authoritative. Facts belong in retrieval (Phases 6 and 7), where they can be updated without a training run and cited without hallucination.

**Concept check C1.** Atlas's router occasionally labels a database question as `document`. Which column is that defect most likely in, and what evidence would tell you it is in a different one?

---

### 6.2 [core] Supervised fine-tuning on tool-use trajectories

**Intuition.** If you want a model to behave like an agent, show it thousands of episodes of an agent behaving well, and train it to predict what the agent did next. That is all SFT is. The subtlety is entirely in what counts as "the agent did next" — which spans you train on, and which you mask.

**Precise definition.** *Supervised fine-tuning on trajectories* is next-token prediction over serialized episodes, where an episode is the alternating sequence of user request, assistant actions (tool calls and reasoning), tool observations, and final answer, and the loss is computed only over assistant-authored spans.

**Worked example, on Atlas's own types.** Atlas's Phase 1 loop records a `Trajectory` (in `atlas/agents/minimal.py`) with a `task`, a list of `Step`s carrying `action`, `argument` and `observation`, and an `answer`. Turning one into a training example is a pure function. This code runs against the real Atlas classes:

```python
"""Turn one Atlas Trajectory into a masked SFT example. Pure, offline."""
from __future__ import annotations

from atlas.agents.minimal import Step, Trajectory

TRAIN, IGNORE = 1, 0


def to_training_example(traj: Trajectory) -> list[tuple[str, str, int]]:
    """(role, text, mask) triples. mask=1 means 'compute loss on this'."""
    rows: list[tuple[str, str, int]] = [("user", traj.task, IGNORE)]
    for step in traj.steps:
        if step.action == "final":
            rows.append(("assistant", f"FINAL: {step.argument}", TRAIN))
            continue
        rows.append(("assistant", f"ACTION: {step.action}({step.argument})", TRAIN))
        if step.observation is not None:
            rows.append(("tool", step.observation, IGNORE))
    return rows
```

Run on a two-step episode, it prints:

```
0  user      How many people work in the Bristol office?
1  assistant ACTION: headcount(Bristol)
0  tool      41
1  assistant FINAL: 41 people work in Bristol.
```

Four rows, two of which carry loss. Notice what the masking encodes. The model is trained to *produce* `ACTION: headcount(Bristol)` given the question, and to *produce* the final sentence given the question, its own action, and the observation `41`. It is never trained to produce `41` — because in deployment, `41` comes from your database, and a model trained to predict tool outputs is a model that will happily invent them. This is the same idea as Phase 13's "the transcript is the more fluent liar", pushed one layer down into the training data.

**Where the field learned this.** Toolformer (Schick et al., 2023, [arXiv:2302.04761](https://arxiv.org/abs/2302.04761)) showed a model could annotate its own pretraining text with API calls and be fine-tuned on the annotations that measurably reduced perplexity — self-supervised tool learning with a filter. Its tool set was a calculator, a question-answering system, two search engines, a translation system and a calendar. Gorilla (Patil et al., 2023, [arXiv:2305.15334](https://arxiv.org/abs/2305.15334)) fine-tuned on API documentation to reduce invented API calls. ToolLLM (Qin et al., 2023, [arXiv:2307.16789](https://arxiv.org/abs/2307.16789)) scaled the idea to a large corpus of real REST APIs. FireAct (Chen et al., 2023, [arXiv:2310.05915](https://arxiv.org/abs/2310.05915)) fine-tuned on ReAct-style trajectories specifically, and AgentTuning (Zeng et al., 2023, [arXiv:2310.12823](https://arxiv.org/abs/2310.12823)) on a mixture across agent environments. All four are 2023 papers, all four use the masking pattern above, and all four are worth skimming for the shape of the data rather than for their numbers, which are long stale.

**What SFT fixes and what it does not.** It fixes *format compliance* (valid tool-call syntax, the right argument names), *calling conventions* (when to reach for a tool at all), and *style*. It does not fix judgement under distribution shift: a model fine-tuned on trajectories where every tool call succeeds has never seen an error and will handle one badly. If you take one practical rule from this section, take that one — **your trajectory data must contain failure and recovery, or you are training an agent that only works when nothing goes wrong.** That is why Atlas's `FAILURE_LOG.md` would be, if this were a training project, the most valuable file in the repository.

**Your turn (10 min).** Look at `atlas/agents/react.py` in the snapshot. Write down, without coding it, which spans of one of its episodes you would mask if you were building SFT data from Atlas runs. There are at least two judgement calls the example above does not face — what to do with a *refused* action, and what to do with the retry after a parse failure.

---

### 6.3 [core] Rejection-sampling fine-tuning

**Intuition.** You do not have thousands of expert trajectories. But you have a model that succeeds sometimes, and a way of checking whether it succeeded. So: let the model attempt each task many times, keep only the attempts that passed the check, and fine-tune on those. The model writes its own textbook and a grader tears out the wrong pages.

**Precise definition.** *Rejection-sampling fine-tuning* (also expert iteration, RFT, or the sampling half of ReST) is: sample k candidate trajectories per task from the current policy, filter them with a verifier, deduplicate, fine-tune on the survivors, and optionally repeat. The lineage runs through STaR (Zelikman et al., 2022, [arXiv:2203.14465](https://arxiv.org/abs/2203.14465)), RFT (Yuan et al., 2023, [arXiv:2308.01825](https://arxiv.org/abs/2308.01825)), ReST (Gulcehre et al., 2023, [arXiv:2308.08998](https://arxiv.org/abs/2308.08998)) and ReST-EM (Singh et al., 2023, [arXiv:2312.06585](https://arxiv.org/abs/2312.06585)).

**Worked example — illustrative, not a measurement.** Suppose 500 tasks, k = 8 samples each, and a base pass rate of 30%. You get 4,000 candidates, of which roughly 1,200 pass. Deduplicate near-identical solutions and you might keep 700. You have manufactured 700 verified trajectories from 500 unlabelled tasks and one grader, at the cost of 4,000 generations. Notice the shape: **the expensive ingredient is not labels, it is the verifier**, and every arithmetic step here is invented for illustration.

**Why this matters for agents specifically.** For maths, the verifier is answer matching. For code, it is the test suite. For agents, the verifier is an *environment check* — did the file appear, did the record change, did the cited document actually contain the claim. Which is precisely what Phase 13 built for Atlas when it stopped grading transcripts and started grading the filesystem. The lesson transfers exactly: **a rejection-sampling pipeline is only as good as its check, and a check that reads the agent's own account of its work will happily certify a lie.**

> **Misconception 2: "If the final answer is right, the trajectory is good training data."** It is not. A model that reaches the right total by calling the calculator with the wrong expression and then silently correcting it in prose has produced a passing episode that teaches the wrong tool-calling behaviour. Outcome filters admit *false positives at the process level*, and because you then train on those spans, the error is not merely tolerated but reinforced. The defences are the ones Phase 13 already argued for at the eval layer: check intermediate structure as well as outcomes, keep a balanced set that includes negative cases, and look at a sample of survivors by hand before you train on them.

**Concept check C2.** You run rejection sampling on Atlas's routing task, filtering on "the final route was correct". Name two kinds of bad trajectory that would survive this filter, and one cheap check that would catch each.

---

### 6.4 [core] Reinforcement learning for agents

#### What changes when you move from SFT to RL

SFT imitates a fixed dataset. RL optimizes a *score you define* over trajectories the model generates itself, which means it can improve past the best behaviour in any dataset — and can also find behaviour that scores well while being useless, because it is optimizing the score and not your intention.

Three families, distinguished by **where the reward comes from**:

| Family | Reward produced by | Applies to | Seminal reference |
|---|---|---|---|
| RLHF | A learned reward model, trained on human preference comparisons | Subjective quality: helpfulness, tone, safety | Ouyang et al., 2022, [arXiv:2203.02155](https://arxiv.org/abs/2203.02155) |
| RLAIF | A model judging against written principles instead of humans | The same, at lower labelling cost | Bai et al., 2022, [arXiv:2212.08073](https://arxiv.org/abs/2212.08073); Lee et al., 2023, [arXiv:2309.00267](https://arxiv.org/abs/2309.00267) |
| RLVR | A deterministic checker: answer match, unit test, environment state | Anything with a ground truth you can compute | Lambert et al., 2024, [arXiv:2411.15124](https://arxiv.org/abs/2411.15124) |

The Tülu 3 report describes RLVR as keeping the RLHF objective but replacing the learned reward model with a verification function, rewarding the policy only when its answer is verifiably correct. That substitution is the whole idea, and it is why RLVR arrived in agent training so fast: an agent's environment already *is* a verifier. A survey published in 2026 puts the trade-off crisply — verifiable rewards are less noisy than human preferences but sparse, which turns the problem from estimating a latent reward into exploring under rare positive signal, and they capture only a narrow notion of quality, so RLVR complements RLHF rather than replacing it (*Reinforcement Learning from Human Feedback: A Statistical Perspective*, 2026, [arXiv:2604.02507](https://arxiv.org/pdf/2604.02507)).

#### GRPO, in plain words

Classical PPO needs a *value function*: a second network that predicts, from a partial trajectory, how much reward you are likely to end up with. Its job is to provide a baseline, so that "this action got reward 1" becomes the more useful "this action got reward 1 where 0.7 was expected, so it was better than average by 0.3". Training that second network on a language-model backbone is finicky and it doubles your memory.

**Group Relative Policy Optimization** removes it. Sample a *group* of completions for the same prompt — say sixteen — score them all, and use the group's own mean as the baseline. An answer that scored above its siblings gets pushed up; one that scored below gets pushed down. The group is the baseline. GRPO was introduced in DeepSeekMath (Shao et al., 2024, arXiv:2402.03300) as a PPO variant that drops the critic and estimates the baseline from group scores, substantially reducing training resources. It became widely known through DeepSeek-R1, published in *Nature* on 17 September 2025, which reported that reasoning behaviour could be incentivized by reinforcement learning alone, without human-annotated reasoning traces (Guo et al., *Nature* 645:633–638, [doi:10.1038/s41586-025-09422-z](https://www.nature.com/articles/s41586-025-09422-z)).

The intuition is worth holding onto because it explains the failure modes. You are not telling the model what good looks like in absolute terms. You are telling it *which of its own attempts were better than its other attempts*. Everything that can go wrong follows from that.

#### Failure modes of GRPO-style training

These are the ones you should be able to name — assignment 1 asks you to:

1. **Reward hacking.** The policy finds behaviour that scores well and misses the point: emitting a token sequence the checker mis-parses as correct, or calling a tool whose side effect satisfies the verifier without solving the task. The sharper the optimizer, the faster it finds these.
2. **Entropy collapse.** The output distribution narrows early, the group's completions become near-identical, every advantage goes to zero, and learning stops. All the signal in GRPO comes from *variation within the group*, so losing diversity is not a side effect; it is the end of training. ProRL (Liu et al., 2025) names this explicitly and addresses it with KL control and reference-policy resets.
3. **Zero-variance groups.** If all sixteen completions pass, or all sixteen fail, the group mean equals every score and the gradient is zero. Task difficulty has to be *matched to the model*, which is why curriculum and difficulty filtering appear in almost every serious recipe.
4. **Length and format artefacts.** Response length is a notorious free rider: it correlates with reward in many setups without causing it. Phase 13's verbosity-bias lesson, one level down — and the same structural fix applies, which is to make the reward blind to the artefact rather than to instruct against it.
5. **Verifier gaming in multi-turn settings.** With tools, the "environment" is code you wrote. Any bug in it becomes a reward, and the optimizer is extremely good at finding bugs in your grader.
6. **Off-policy drift in the multi-turn case.** The agent's later steps are conditioned on tool outputs your rollout infrastructure produced. If those differ from production, you have optimized for a simulator.

The multi-turn tool setting is now its own subfield, sometimes called *agentic RL with tool use*: a 2025 framework paper notes that RLVR was initially limited to single-turn interactions without tool integration, and that the multi-turn approaches which followed were fragmented, task-specific codebases (VerlTool, 2025, [arXiv:2509.01055](https://arxiv.org/abs/2509.01055)). Representative named systems, if you want primary sources rather than my summary: Search-R1 (Jin et al., 2025, [arXiv:2503.09516](https://arxiv.org/abs/2503.09516)) for retrieval, ReTool (Feng et al., 2025, [arXiv:2504.11536](https://arxiv.org/abs/2504.11536)) for interleaved code execution, and ToolRL (Qian et al., 2025, [arXiv:2504.13958](https://arxiv.org/abs/2504.13958)) for a systematic study of reward design in tool learning.

#### The contested question, and how to hold it

Here is a live disagreement you should know about, because it is the best available example of how to read this literature.

**The sceptical result.** Yue et al. (2025, [arXiv:2504.13837](https://arxiv.org/abs/2504.13837), NeurIPS 2025) probed RLVR-trained models with pass@k at large k across model families, RL algorithms, and maths, coding and visual benchmarks. RLVR models beat their base models at k=1, but the base models recovered more total solutions once many attempts were allowed, and coverage and perplexity analyses indicated the reasoning paths present after RLVR already existed in the base model's distribution; distillation, by contrast, did expand the reachable set. Reading: RLVR improves *sampling efficiency* rather than *capability*.

**The counter-result.** ProRL (Liu et al., 2025, [arXiv:2505.24864](https://arxiv.org/abs/2505.24864), NVIDIA) argues the opposite under a different regime. With prolonged training, KL control, reference-policy resetting and a diverse task suite, they report RL-trained models outperforming base models across a range of pass@k evaluations, including cases where the base model fails regardless of the number of attempts. A third paper (2025, [arXiv:2506.14245](https://arxiv.org/abs/2506.14245)) attacks the measurement itself, arguing that pass@K credits answers reached by faulty reasoning and proposing a metric that requires the intermediate steps to be sound, under which RLVR does extend the boundary.

**How to hold this.** All three are DEMONSTRATED results — each ran real experiments — and they disagree because they differ in training duration, exploration control, task diversity, and, critically, *the metric*. The honest summary in September 2026 is that **the field has no consensus on whether RLVR expands capability or sharpens sampling, and the answer appears to depend on training scale and on how you define capability.** What would settle it is agreement on a metric that distinguishes "found a correct answer" from "reasoned correctly", plus matched compute budgets across the compared arms. When you next read a paper claiming RL "unlocks new abilities", the first two questions are: how long did they train, and at what k did they measure?

> **Misconception 3: "RL is how you get a model to use your tools."** For a small company's assistant, almost never. RL on agent trajectories needs an environment, a verifier, rollout infrastructure and a meaningful compute budget, and it optimizes for the environment you built. The prompt, schema and control-flow levers are hundreds of times cheaper and address the great majority of tool-use defects. Know how RL works so you can read the papers and choose models well; do not reach for it because your agent picked the wrong tool twice.

**Concept check C3.** Your GRPO run's average reward climbs steadily while the eval set does not move at all. Name three explanations consistent with that pattern, and the cheapest diagnostic for each.

---

### 6.5 [core] Where tool-use datasets come from

Three sources, exactly as Phase 13 said for eval datasets — and for the same reasons, since a training set and an eval set are the same object with different jobs.

**Harvested.** Real logs from a deployed system: the highest value per unit effort, and the only source that reflects what users actually ask. The cost is privacy and consent, plus the labelling work of deciding which episodes were good.

**Golden.** Hand-written by people who know the domain. Correct by construction, expensive, and it samples your imagination rather than the world.

**Synthetic, verified by execution.** This is what the field converged on for function calling. APIGen (Liu et al., 2024, [arXiv:2406.18518](https://arxiv.org/abs/2406.18518), NeurIPS 2024) generates candidate function-calling examples and then filters them by *actually executing* the call and checking the result, discarding anything that does not run. APIGen-MT (Prabhakar et al., 2025, [arXiv:2504.03601](https://arxiv.org/abs/2504.03601)) extends the idea to multi-turn data by simulating the human side of the conversation. The pattern to take away: **a synthetic dataset without an execution check is a dataset of plausible-looking calls, and plausible-looking calls are exactly what a language model produces when it is wrong.**

The Part 3 hands-on generates a seeded synthetic dataset in this spirit — with the generator, the seed, the schema and the checks all committed — and is explicit about what it does not represent.

Two hazards worth naming. **Contamination**: if a tool-use benchmark's tasks are in your training mix, your measurement is meaningless, and Phase 13's contamination discussion applies unchanged. **Schema drift**: a dataset teaches a calling convention, and conventions change; a model fine-tuned on one dialect of tool call will not silently adapt when your provider changes theirs. Atlas has already met this in miniature — `atlas/llm.py` carries both an OpenAI-style `tool_call_id` and Ollama's positional `index` because the two dialects identify calls differently.

---

### 6.6 [core] Why reasoning models changed agent reliability

Between late 2024 and 2025 a class of models arrived that spend variable inference compute on an internal reasoning pass before answering: OpenAI's o1 (announced 12 September 2024, [Learning to reason with LLMs](https://openai.com/index/learning-to-reason-with-llms/); system card [arXiv:2412.16720](https://arxiv.org/abs/2412.16720)) and then open models such as DeepSeek-R1 (*Nature*, September 2025, above). Agent builders noticed the difference immediately. Four mechanisms explain most of it, and none of them is mysterious:

1. **Verification before commitment.** A model that checks its own plan before emitting a tool call catches a class of errors that would otherwise become an action with a side effect. Agents fail hardest at irreversible steps, which is exactly where a cheap internal check pays best.
2. **Error recovery mid-episode.** The R1 line reports that self-verification, reflection and strategy revision emerged during RL on rule-based rewards rather than being explicitly taught. Whatever the mechanism, recovering after an unexpected tool result is the behaviour that distinguishes an agent that finishes from one that loops.
3. **Longer coherent plans.** More internal steps before an action means fewer episodes that lose the goal at step four.
4. **Compute allocation on demand.** Hard steps get more thinking than easy ones, which is the test-time-compute idea in §6.7, packaged inside the model.

Two honest caveats. First, this is genuinely *better on average and not uniformly*: a reasoning pass costs latency and tokens, and for short routing or extraction calls it is often a worse trade — which is why Atlas's router caps `max_tokens` at 160 and why a router that costs as much as a handler cannot pay for itself. Second, the strength of the phenomenon is contested: a body of 2025 work argues that apparent reasoning degrades sharply on certain compositional tasks, and the rebuttals argue those experiments confound reasoning with output-length limits. I flag this rather than adjudicating it; Part 2's long-horizon section is where the evidence lives.

---

### 6.7 [core] Test-time compute and its economics

**Intuition.** You can buy accuracy with training compute, or you can buy it at inference by letting the model try more, longer, or in parallel and then picking. The second is available to you *today*, on a frozen model, with no GPU.

**The mechanisms**, cheapest first: longer chains of thought (sequential compute); self-consistency, which samples several answers and takes the majority; best-of-N with a verifier or reward model, which samples N and picks the winner; and tree search over partial solutions.

**What the primary sources say.** Snell et al. (2024, [arXiv:2408.03314](https://arxiv.org/abs/2408.03314)) studied how to spend a fixed inference budget and found that the best strategy depends on question difficulty, such that allocating compute adaptively beats a fixed policy, and that under some conditions inference compute substitutes for a larger model. Large Language Monkeys (Brown et al., 2024, [arXiv:2407.21787](https://arxiv.org/abs/2407.21787)) studied repeated sampling and observed that coverage — the share of problems solved by *at least one* of k samples — keeps climbing with k far beyond where single-sample accuracy plateaus. A 2025 analysis argues that scaling test-time compute **without** a verifier or RL is suboptimal ([arXiv:2502.12118](https://arxiv.org/abs/2502.12118)).

That last one is the load-bearing engineering fact, and it is the same point Phase 13 made about `pass@k` versus `pass^k`. Coverage is only useful if you can *identify* the right sample. If you have a verifier — a test suite, a schema check, a database that either has the row or does not — best-of-N converts coverage into accuracy. If you do not, you are left with majority voting, which fails exactly when the model is confidently wrong in a correlated way.

**The economics, made concrete (illustrative arithmetic, not a measurement).** Take an Atlas research episode: 6 model calls, roughly 3,000 prompt and 700 completion tokens each, about 20 seconds end to end on a laptop. Best-of-5 with a verifier multiplies calls and tokens by five, and — if you run sequentially, which a single Ollama instance does — multiplies wall-clock by five too, to about 100 seconds. If it lifts success from 70% to 85%, you are paying 5× for a 15-point absolute gain. Whether that trade is right depends on a question only you can answer: **what does a failure cost, and is a retry cheap?** For a background research report, 100 seconds is free. For an interactive question, you have destroyed the product. For an irreversible write, the verifier matters more than the sampling.

Three practical constraints the papers do not emphasize. Parallel sampling needs parallel serving capacity, which a single local model does not have. Latency, not cost, is usually what kills test-time scaling in interactive products. And your existing Atlas budget machinery already expresses all of this: `atlas/llm.py` caps calls and tokens and raises `BudgetExceeded`, which is the mechanism that stops a test-time-compute experiment from becoming an unbounded spend.

**Your turn (15 min).** Pick one Atlas task family and write down, before running anything, (a) whether you have a verifier for it, (b) what N you could afford at 20 seconds per call, and (c) what success rate improvement would justify that N. Keep the note; Part 3's prompt-optimization pass asks you to compare it against what you actually observe.

**Concept check C4.** Self-consistency and best-of-N both sample k times. What does best-of-N need that self-consistency does not, and name an Atlas task where you have it and one where you do not.

---

### 6.8 [core] Distilling agent behaviour into small models

**Intuition.** Run a large capable agent over many tasks, keep the episodes that worked, and fine-tune a small model on them. You are not compressing the big model's knowledge; you are compressing *its behaviour on your task distribution*, which is a much smaller thing and therefore fits.

This is rejection-sampling fine-tuning with the teacher and student being different models, and for agents it is the training technique most likely to be relevant to a small team, because the artefact is a model you can run locally at a fraction of the cost and latency.

**What the literature shows.** Agent Distillation (Kang et al., 2025, [arXiv:2505.17612](https://arxiv.org/abs/2505.17612), NeurIPS 2025) is the cleanest reference point: it transfers full task-solving behaviour — not just chain-of-thought — from an LLM agent into small models equipped with retrieval and code tools, and reports that small models fine-tuned this way can match the next tier up trained with chain-of-thought distillation alone. Structured Agent Distillation ([arXiv:2505.13820](https://arxiv.org/abs/2505.13820)) reports gains from segmenting trajectories into reasoning and action spans and applying different losses to each — which is the masking idea from §6.2, refined. Note the setup before you generalize: these are specific student sizes, specific task suites, specific teachers. "A 1.5B model can do this" is a claim about *that* task distribution.

There is also a **position** worth knowing and labelling as such: *Small Language Models are the Future of Agentic AI* (Belcak et al., 2025, [arXiv:2506.02153](https://arxiv.org/abs/2506.02153)) argues that most agent sub-tasks are narrow and repetitive enough that small specialized models should handle them, with a large model reserved for the hard steps. That is an argument, backed by cost reasoning, not a measured result — CLAIMED, not DEMONSTRATED. It also happens to describe the architecture Atlas already has, where a cheap deterministic classifier handles routing and the expensive path is reserved for what needs it.

**What distillation costs you.** Three things, and they are the same three every time. **Tail behaviour**: the student matches the teacher on the distribution it was trained on and degrades off it, often without signalling that it has. **Recovery**: unless failure and recovery episodes are in the data, the student inherits the teacher's happy path only. **Staleness**: your student is frozen against a teacher that will be superseded, and the retraining bill recurs.

**Concept check C5.** You distil Atlas's routing behaviour into a small local model and it matches the teacher on your dev set. Name two deployment conditions under which it would degrade silently, and say which Atlas record — a field on an existing model — would let you detect the degradation without a new eval.

---

### 6.9 [core] What "self-improving" actually means

**Intuition.** A self-improving system is not a system that thinks about itself. It is a loop with four parts, and if any one is missing the loop does not close:

```
      +---------------------------------------------------+
      |                                                    |
      v                                                    |
  CANDIDATE  ---->  SCORER  ---->  SELECTION  ---->  MEMORY
 (a new prompt,   (a metric on   (keep the best,   (the artefact
  tool, skill,     held-out       discard the       that persists
  or weight set)   data)          rest)             to next time)
```

Take away the scorer and you have a system that changes; take away the memory and you have a system that improves for one episode and forgets; take away the selection rule and you have a system that drifts.

**The three levels**, in increasing cost and decreasing reversibility:

| Level | Artefact that changes | Cost of one iteration | Reversible? |
|---|---|---|---|
| Text | A prompt, a rubric, a tool description | Cents; minutes | Yes, it's a file |
| Code and procedure | A tool the agent wrote; a skill document | Minutes to hours | Yes, if you review before adopting |
| Weights | A fine-tuned adapter or model | GPU hours; a dataset | Only by keeping the old checkpoint |

Everything in this section is levels one and two, because those are the ones you can run on a laptop this evening, and because — this is the part that surprises people — the published evidence is that text-level optimization is competitive with weight-level optimization on a surprising range of tasks, at a small fraction of the compute.

> **Misconception 4: "Self-improvement means the model updates itself."** In the systems that actually work today, the model is frozen and the *scaffolding* changes: the prompt, the retrieved examples, the library of procedures. Voyager (2023), the canonical self-improving agent, explicitly does no parameter updates at all — it improves by accumulating executable skills and calling a fixed model with them. When you read a claim that an agent "learns from experience", the first question is *which file changed*.

---

### 6.10 [core] Automatic prompt optimization

**Intuition.** A prompt is a parameter. It happens to be made of words rather than floats, which means you cannot differentiate it — but you can *propose variants and score them*, which is optimization by search rather than by gradient. Everything in this literature is a different answer to two questions: how do you propose the next candidate, and how do you spend your evaluation budget deciding between candidates?

**A short dated history**, so you can see how the proposal mechanism got smarter:

- **APE** (Zhou et al., 2022, [arXiv:2211.01910](https://arxiv.org/abs/2211.01910)) — have a model write candidate instructions from input/output examples, score them, keep the best. Proposal is blind sampling.
- **ProTeGi / "textual gradients"** (Pryzant et al., 2023, [arXiv:2305.03495](https://arxiv.org/abs/2305.03495)) — collect failures, ask a model to write a natural-language criticism of the prompt, and edit in the direction of that criticism. Proposal is now *informed by errors*, which is the analogy to a gradient.
- **OPRO** (Yang et al., 2023, [arXiv:2309.03409](https://arxiv.org/abs/2309.03409)) — give the proposing model a trajectory of previous prompts with their scores, and ask for a better one. Proposal is informed by *history*.
- **DSPy** (Khattab et al., 2023, [arXiv:2310.03714](https://arxiv.org/abs/2310.03714)) — treat a multi-stage LLM pipeline as a program with declared signatures, and compile it: the optimizer chooses instructions and demonstrations for each stage. **MIPROv2** (Opsahl-Ong et al., EMNLP 2024, [arXiv:2406.11695](https://arxiv.org/abs/2406.11695)) is its Bayesian instruction-and-demonstration optimizer.
- **GEPA** (Agrawal et al., 2025, [arXiv:2507.19457](https://arxiv.org/abs/2507.19457), ICLR 2026) — sample whole system trajectories including tool calls and tool outputs, reflect on them in natural language to diagnose what went wrong, propose and test prompt edits, and combine complementary lessons using a Pareto frontier over its own attempts rather than a single best candidate.

GEPA is the one to read if you read one, because its argument is directly relevant to the choice this appendix is about. It claims that reflective prompt evolution can beat reinforcement learning on the same tasks while using far fewer rollouts. Here is that claim stated the way section 4 of this appendix asks you to state results:

| Claim | Reported by | Setup | Status |
|---|---|---|---|
| Reflective prompt evolution outperformed a GRPO baseline on the same tasks, using far fewer rollouts | Agrawal et al., 2025, arXiv:2507.19457 (v1 July 2025; ICLR 2026) | Four to six tasks; two LLMs; rollout-matched comparison; the RL arm is one GRPO configuration, not an exhaustive RL search | DEMONSTRATED for that task set and those models; **not** a general claim that prompt search beats RL |
| The same method beat the previous leading prompt optimizer (MIPROv2) on all reported benchmarks and models | Agrawal et al., 2025, same paper | Same setup; the compared optimizer jointly tunes instructions and demonstrations while GEPA tuned instructions only | DEMONSTRATED, same scope caveat |

*Verified 15 September 2026. Both rows will be stale quickly: prompt optimizers are a fast-moving area and the baselines they beat are chosen by the authors.*

**The four things you must have before you run any of these.** This is the part the papers assume and the part teams skip.

1. **A metric that is a function, not an opinion.** If the score requires a human, you cannot run 200 evaluations.
2. **A split.** Candidates are scored on a development set; the winner is re-measured on a **holdout** that the optimizer never saw. Without this you have not optimized a prompt, you have memorized a dev set.
3. **A budget.** In rollouts, not in "iterations". Every candidate × every dev example is a model call.
4. **A stop rule decided in advance.** Otherwise you stop when the number looks good, which is the same as stopping at your own noise.

The failure mode is overfitting the dev set, and Phase 13 already gave you the tools to see it: at a dev set of 24 items, the minimum detectable effect is enormous, so a candidate that "wins" by two items has won by noise. Atlas's own gate exists for exactly this reason — it blocks on categorical events, never on the rate.

**Where this attaches to Atlas.** The seam already exists, and it was built in Phase 3 for a different reason (`atlas/prompts/CHANGELOG.md` opens with `atlas_system v1 — Phase 3`). `atlas/prompts/__init__.py` gives you `load_prompt(name, version=...)`, the version is in the filename so v2 is a new file rather than an edit, a test pins the checksum, and `atlas/prompts/CHANGELOG.md` requires one entry per version naming the measurement that motivated it. That is precisely the artefact an optimizer needs: a place to write candidates, a way to A/B two of them with a one-argument change, and a human gate before one becomes the default. Part 3's hands-on runs a real optimization pass against `atlas_router.v1.md` using that seam.

> **Misconception 5: "The optimizer found a better prompt."** No: the optimizer found a prompt that scored better on *n* examples under one decoding configuration on one model on one day. Prompts optimized against one model routinely fail to transfer to another, and a prompt tuned at temperature 0 is not tuned for temperature 0.7. Report the model, the decoding parameters, the split sizes and the number of runs, or you have reported nothing. This is Phase 13's provenance rule applied to a new artefact.

**Concept check C6.** You run an optimizer over Atlas's router prompt with 40 dev examples and 5 candidates. The winner beats the incumbent by 3 examples on dev and by 0 on a 20-item holdout. What do you do, and what would you have to change to get an answer you could act on?

---

### 6.11 [core] Learned tool creation

**Intuition.** The strongest form of level-two self-improvement is an agent that notices it keeps doing the same fiddly thing, writes a function for it, tests the function, and adds it to its own toolbox. Next time, one call replaces six.

**What makes it work, and it is one thing: executable verification.** A written tool is a hypothesis; running it against a test is the check. Without that check you have an agent adding untested code to its own action space, which is the worst of both worlds — the unreliability of generated code with the authority of a registered tool. Voyager's version of this check is self-verification against environment feedback and execution errors, iterated until the program runs.

**What Atlas already has that makes this safe to attempt.** Phase 14's sandbox and permission tiers, and Phase 3's `ToolRegistry` with JSON-Schema-described tools. The precondition for any tool-writing experiment is that the written code executes somewhere it cannot hurt you, and that its registration is a reviewable event rather than a side effect.

**The three ways it degrades.**

*Namespace rot.* Twenty generated tools with overlapping purposes and near-identical descriptions produce a selection problem the model cannot solve, because the model's only information about a tool is its description. This is the many-tools registry problem, which the book defers to Appendix F rather than building, and it arrives immediately once tools are generated rather than curated.

*The static floor.* Every tool schema is tokens on every request. Phase 8 measured what that costs. A toolbox that grows monotonically eats the context window it was supposed to save.

*Unreviewed code becomes infrastructure.* A tool written on a Tuesday to work around one API quirk is still being called eighteen months later by something nobody remembers writing. The remedy is not technical: it is that generated tools get the same review, the same test, and the same retirement policy as written ones.

---

### 6.12 [core] Skill libraries: Voyager, 2023

**The paper.** Voyager (Wang et al., 2023, [arXiv:2305.16291](https://arxiv.org/abs/2305.16291), later TMLR) is an LLM-driven agent in Minecraft with three components: an automatic curriculum that proposes tasks suited to the agent's current state, an ever-growing skill library of executable code for storing and retrieving complex behaviours, and an iterative prompting loop that incorporates environment feedback, execution errors and self-verification to improve the programs. It queries a frozen model as a black box, with no parameter updates. The authors report that the resulting skills are temporally extended, interpretable and compositional, that they compound, and that the library transfers to a fresh world where other methods struggled.

Two design decisions in that paper are worth more than its benchmark numbers, which are long stale.

**A skill is executable code, not a memory of a good outcome.** The library stores programs. A program can be *called*, *tested*, and *composed*; a stored anecdote about a past success can only be read and hoped over. This is the same distinction Phase 5 drew when it insisted the model returns a label and Python owns the dispatch table.

**Retrieval is a first-class problem.** With a hundred skills, the question "which skill applies here?" is a retrieval problem whose failure modes are Phase 6's, not Phase 8's. Voyager retrieves by embedding the skill description. Atlas does something cheaper and more auditable, and the difference is instructive.

**Atlas's half of the machinery already exists.** `atlas/memory/skills.py` implements the loading and selection half of a skill library against the published `SKILL.md` format: a directory per skill, YAML frontmatter with `name` and `description` required, a Markdown body, and optional `references/`, `scripts/` and `assets/`. It is deliberately three-level:

- **Level 1** is the name and description, paid on every request for every skill.
- **Level 2** is the body, read from disk only when the skill activates.
- **Level 3** is the supporting files, read per use, through `Skill.resource()` which resolves and then verifies the path is inside the skill directory.

The snapshot ships one skill, `atlas/skills/northwind-quarterly`. `appendix_c/skill_cost.py` runs the real loader against it and prints the arithmetic that justifies the whole design — a script rather than a sentence, because a number in prose that no target prints is an opinion (Phase 13's invariant 73):

```
northwind-quarterly | level 1: 89 tokens | level 2: 565 tokens | resources: ('references/RELATIONS.md',)
catalogue total (level 1, every request): 133 tokens
```

Eighty-nine tokens on every request buys the *option* of 565 more when the request actually concerns quarterly shipments. Selection is `select_skill`, which counts whole-word trigger matches from the skill's own `metadata.triggers` and activates only at `MIN_TRIGGER_MATCHES = 2` or above, breaking ties by name. It returns `None` for "what is our refund policy?" and `northwind-quarterly` for "how many units shipped last quarter?". The threshold of two rather than one is a measured choice: one common word ("quarter") activates on requests the procedure does not cover, and a wrong activation costs the entire level-2 body plus attention diluted over an irrelevant procedure.

**What Atlas does not have is a writer.** Nothing in the repository proposes a new skill from a successful episode, verifies it, or retires one that stopped being used. That gap is Assignment 2 in Part 3, and the point of the assignment is that the *loading* half is the easy half.

**The four operations a skill library needs, and what each requires:**

| Operation | What it does | What it requires to be safe |
|---|---|---|
| Propose | Turn a successful trajectory into a candidate procedure | A trajectory that actually succeeded, by an environment check rather than the agent's account |
| Verify | Confirm the candidate reproduces the result | Re-running it, or at minimum re-running the checks the original passed |
| Merge | Fold into the existing library | Duplicate detection; a trigger set that does not collide with an existing skill's |
| Retire | Remove what no longer earns its tokens | Usage counts per skill — a library with no retirement is a context-window leak |

Most published skill libraries implement the first two and nothing else, which is why they grow monotonically.

---

### 6.13 [core] The risks of improvement from experience

Four, and they are ordered by how quietly they bite.

**1. Goodhart, immediately.** An optimizing loop optimizes the *scorer*, not the goal. Give an automatic prompt optimizer a scorer that rewards answers containing citations, and it will write a prompt that produces citations, including for claims that do not need them. Phase 13's structural defence is the right one here too: remove the field the bias attaches to rather than instructing against it, and hold out a set the optimizer cannot see.

**2. Training on your own output.** Shumailov et al. (*Nature* 631:755–759, 24 July 2024, [doi:10.1038/s41586-024-07566-y](https://www.nature.com/articles/s41586-024-07566-y)) showed that indiscriminate training of generative models on recursively generated data causes irreversible degradation, with the tails of the original distribution disappearing first — demonstrated in language models and also in variational autoencoders and Gaussian mixture models. State the scope precisely, because this result is widely over-claimed: it concerns *indiscriminate recursive* training where synthetic data replaces real data each generation. Subsequent work finds that loops which *accumulate* data, or which mix in a sufficient fraction of human data, behave very differently. The engineering lesson is narrow and solid: if your system writes its own training data, its own examples, or its own skills, and nothing outside the loop ever checks them against reality, the distribution will drift and the rare cases go first.

**3. Provenance loss.** Six weeks after an optimization run, your system prompt says something nobody wrote and nobody can justify. This is precisely the failure `atlas/prompts/CHANGELOG.md` exists to prevent, and the rule scales: **an artefact produced by a loop needs a stronger provenance record than one produced by a person, not a weaker one**, because there is no author to ask. Record the optimizer, the dev set, the split, the score, the date, and the model.

**4. Persistent injection.** A skill written from a trajectory, or a memory written from a conversation, is *content from an untrusted source that becomes an instruction later*. Phase 14 taught this as prompt injection; a self-improving system converts a one-off injection into a permanent one, because the injected instruction is now in a file the agent loads at startup. If you build the writer in Assignment 2, the review gate before adoption is not bureaucracy — it is the security control.

**Concept check C7.** Your skill-writing loop proposes a new skill after every successful episode, verifies it by replaying the episode, and adopts it automatically. Name the failure from each of the four categories above that this design permits, and the smallest change that closes each.

---

### 6.14 [core] Long-horizon agents: horizon versus success decay

**Intuition, and the arithmetic that governs everything else in this section.** If an agent takes *n* steps and each step independently succeeds with probability *p*, the episode succeeds with probability *p^n*. That model is too simple — steps are not independent, and agents recover from some errors — but its shape is the correct one to have in your head:

```
p        steps at 50% success    P(success, n=10)    P(success, n=50)
0.90              6.6                 0.349               0.005
0.95             13.5                 0.599               0.077
0.99             69.0                 0.904               0.605
0.999           692.8                 0.990               0.951
```

*(Arithmetic, not a measurement: computed from p^n for illustration.)*

Read the first column. Going from 90% to 99% per-step reliability — which sounds like a modest engineering improvement, a 9-point gain — multiplies the length of task you can complete by roughly ten. **Horizon is exponential in step reliability.** This is why a model that looks only slightly better on short benchmarks can be dramatically better as an agent, and it is why "our agent is right 95% of the time" tells you almost nothing until you also say how many steps it takes.

**The measured version of this.** METR's time-horizon work (Kwa et al., 2025–2026, [arXiv:2503.14499](https://arxiv.org/abs/2503.14499), latest revision July 2026) proposes a metric designed to make the exponent legible: the **50%-task-completion time horizon**, defined as the length of time human experts typically take on tasks that a model completes with 50% success. They timed domain experts on a task set combining existing benchmarks with 66 new shorter tasks, evaluated models released between 2019 and 2025, and reported that this horizon has been doubling roughly every seven months, attributing the growth mainly to greater reliability and ability to recover from mistakes rather than to raw reasoning. They also measured an 80% horizon and found it several times shorter than the 50% one, which is the number you should care about if you are shipping something.

Read that result carefully, because it models the habit this appendix is teaching. The authors state their own limitations: horizon is always relative to a task distribution and to the skill and context of the human baseliners, it is hard to measure at high success rates, and performance is much worse on less structured, "messier" tasks. Their forward extrapolation to month-long tasks is explicitly conditional on the trend continuing and on these tasks generalizing. So: the **trend measurement** is demonstrated; the **extrapolation** is a labelled projection by its authors and should be repeated as such, not as a forecast.

**Why agents fail on long tasks, and it is not what people assume.** Sinha et al. (2025, [arXiv:2509.09677](https://arxiv.org/abs/2509.09677), ICLR 2026) isolate execution from planning by *giving* the model the knowledge and the plan, then lengthening the task. Three findings matter for your engineering:

1. Marginal gains in single-step accuracy compound into large gains in executable task length — the arithmetic above, measured.
2. Larger models execute substantially more turns correctly even when smaller models have near-perfect single-turn accuracy. Failure on long tasks is dominated by *execution*, not by inability to reason or plan.
3. **Self-conditioning**: per-step accuracy degrades as the context accumulates the model's own earlier errors. They test this by artificially varying the error rate in the history, and accuracy falls as it rises. This is not merely a long-context effect, and it does not go away by scaling model size — though they report that models trained to produce reasoning traces do not show it.

The third finding is the one with immediate consequences, and it should change how you build. **Leaving a failed step's output in the context makes the next step more likely to fail.** Atlas's compaction machinery (Phase 8) and its structured error records were built for token budget and debuggability; self-conditioning is a second, independent reason to summarize failures out of the working context rather than carrying them forward verbatim.

**Three engineering levers**, in the order of expected payoff:

- **Reduce n.** Every step you can remove is multiplicative. A deterministic function that replaces a model call removes a step *and* raises the effective p for that position to 1.
- **Raise p.** Schema-constrained decoding, retries with a different mode, a verifier on each step's output. Phase 2's output-mode ladder is this lever.
- **Break the dependence.** Checkpointing and subgoal isolation mean that a failure at step 12 does not poison steps 13 through 40 — which is both a recovery mechanism and a self-conditioning mitigation.

**Your turn (10 min).** Take one Atlas pipeline — `run_research_pipeline` is a good choice — count the model calls in a typical episode, and compute the per-step reliability you would need for a 90% episode success rate. Then find the one step you could replace with code.

---

### 6.15 [core] Hierarchical planning

**Intuition.** If horizon is exponential in step count, the cheapest structural fix is to stop having one long chain. Decompose the task into subtasks, each with its own short chain and its own check, and the exponent applies to each subtask separately rather than to the whole episode.

**Precise definition.** *Hierarchical planning* is any scheme where a planner emits sub-goals that are executed by a separate process, with the results joined by code. The planner's output is data, not control flow.

**Atlas's version, and what each decision buys.** `atlas/agents/plan.py` states four claims in its own docstring, and they are the ones worth generalizing:

- **The plan is a DAG, not a list.** `depends_on` makes independence explicit, which is what allows a cycle to be refused before anything runs and what allows independent steps to fan out.
- **What the model writes and what the harness executes are different types.** `PlanDraft` (in `atlas/schemas.py`) has five fields per step; `PlanStep` has nine. The extra four — status, result, note, attempts — are the execution record, and they are absent from the draft because a field the model can set is a field the model can lie about.
- **A step declares the kind of result it will produce, and code checks it.** `check_result_kind` is pure, model-free and microseconds, and it exists because a step returning prose where the next step needed a number is a failure that only shows up three steps later.
- **The plan and the ledger are different objects** (see §6.16).

Above that, `atlas/flow/orchestrate.py` fans out workers and joins in code, and `atlas/graph/subgraphs.py` wraps the five routes as subgraphs — with an unusually honest docstring noting that only two of the five are genuine multi-node graphs and three are single-node shims, because claiming otherwise would be a false capability claim.

**Four failure modes of hierarchical planning**, all of which Atlas met in Phases 4, 5 and 10:

1. **Bad decomposition is inherited.** Every sub-agent faithfully executes a plan that cannot work. No amount of sub-agent quality fixes it, and the symptom is a fluent report about the wrong question.
2. **The join loses information.** A branch that produced nothing usable must come back *labelled partial and naming the failed step*, or the synthesis presents partial results as complete. There is an Atlas eval task for exactly this — `p05-fanout-labels-a-dropped-branch` — and its description says a pipeline reporting `partial=false` there has reproduced the phase's headline defect.
3. **Staleness.** A plan written at step 1 is executing at step 9 in a world that has changed. Replanning fixes it and costs calls; never replanning is cheaper and wrong.
4. **Cost inversion.** The planner and synthesizer can cost more than the work. Measure the overhead as a fraction of the episode, or decomposition becomes a ritual.

---

### 6.16 [core] Progress checkpointing

**Intuition.** An agent that cannot resume must redo, and redoing is where side effects duplicate. The second email, the second file, the second refund.

Two distinct mechanisms, often confused:

**Durable state** answers "where was I?" — the graph's state at a node boundary, persisted so a crashed or suspended run can continue. This is what LangGraph's checkpointer gives you, and Phase 10's human-in-the-loop approval depends on it: the interrupt before a risky action is only safe because the state survives the wait.

**Idempotency** answers "have I already done this?" — and it is the one people skip. `atlas/flow/state.py` implements it with three decisions worth copying verbatim into your own systems:

- **The key hashes the work, never the attempt.** `idem_key(step=..., tool=..., inputs=..., version=...)` contains no run id and no attempt number. The module's docstring names the failure directly: a key that identifies an attempt can never match an earlier record, which makes the whole mechanism a no-op that passes every test you thought to write.
- **The handler version is part of the key**, because a cached result from old code is a wrong answer with a valid key.
- **A replay is its own outcome.** `StepOutcome` has five members, and `"replayed"` exists so that a resumed run is not billed as if it had done the work again. Counting it as `"ok"` would make a resumed run look as expensive as the original; counting it as `"skipped"` would lose the payload.

And the structural rule the whole module is built on: **the plan answers "what runs next" and the ledger answers "what did this cost", and a structure mutated to answer the first cannot be trusted to answer the second.** The plan is mutable, small and transient; the `Ledger` is append-only and kept.

**The rule of thumb for long-horizon work:** checkpoint at every boundary where the *world* changed, not at every boundary where the *conversation* changed. Conversational state is cheap to reconstruct; a side effect is not.

**Concept check C8.** An agent writes a file, then crashes before recording the write. On resume, the idempotency check finds no record and the step runs again. Is this a bug in the idempotency key, the ledger, or the ordering — and what is the fix?

---

### 6.17 [core] Simulation environments for training and evaluating agents

**Why simulate.** Three needs converge on the same object. Reinforcement learning needs an environment that can be stepped millions of times. Verifiable rewards need a world whose state can be *checked*, not narrated. And evaluation needs a world that can be **reset**, or your second measurement is not comparable to your first.

**The landscape, with dates.** Read these for their *grading design*, not their leaderboards:

| Environment | Reference | What it simulates | The design idea worth stealing |
|---|---|---|---|
| WebArena | Zhou et al., 2023, [arXiv:2307.13854](https://arxiv.org/abs/2307.13854) | Self-hosted clones of real web applications | The environment is reproducible because it is *hosted*, not scraped |
| SWE-bench | Jimenez et al., 2023, [arXiv:2310.06770](https://arxiv.org/abs/2310.06770) | Real repository issues with real test suites | The verifier already existed: the project's own tests |
| τ-bench | Yao et al., 2024, [arXiv:2406.12045](https://arxiv.org/abs/2406.12045) | Customer-service conversations with tools and written domain policies | Grades the **database state** against an annotated goal state, and introduces `pass^k` for reliability across trials |
| OSWorld | Xie et al., 2024, [arXiv:2404.07972](https://arxiv.org/abs/2404.07972) | A real desktop OS with real applications | Execution-based validation scripts per task |
| τ²-bench | Barres et al., 2025, [arXiv:2506.07982](https://arxiv.org/abs/2506.07982) | Dual control: the *user* can also call tools | Models the case where the agent is not the only actor |

τ-bench deserves a second look because two of its ideas are already in Atlas. Comparing final database state to an annotated goal state is Phase 13's "grade the filesystem, not the transcript". And `pass^k` — the probability that *all* k independent trials succeed — is the metric Phase 13 taught beside `pass@k`, precisely because for an agent that takes actions, the question is usually not "can it ever get this right" but "does it get this right every time".

**The sim-to-real gap, stated plainly.** In these environments the simulated *user* is a language model, the *grader* is code you wrote, and the *world* is your assumption about how the real API behaves. Each of those is a place where you can succeed in simulation and fail in production. The one that catches people is the user simulator: an LLM user is more patient, more consistent and more articulate than a real one, so agents tuned against it are tuned for a customer who does not exist.

**Benchmarks freeze, and that is a reading lesson.** The τ-bench repository now directs new work to its successors, since the original tasks are no longer updated and contained known bugs. Any number you see quoted for a 2026 model against the original board therefore comes from a vendor self-report or a successor benchmark and is not comparable to the original figures. Generalize the habit: **before citing a benchmark number, check whether the benchmark is still maintained and whether the number was produced by the maintainers or by the vendor being measured.**

**Atlas's own simulator, and what it proves.** You have been using one for sixteen phases. The corpora come from a committed seeded generator (`scripts/gen_dataset.py`, via `make data`), model behaviour is replaced by scripted fixtures in `tests/fixtures/` under Tier F, and `evals/run.py` executes 74 tasks with graded checks against recorded decisions and environment state. What that proves is *control flow, parsing, schema conformance, budget enforcement and retrieval arithmetic* — all the things that must hold regardless of what the model says. What it does not prove is anything about model behaviour, which is why Atlas keeps those numbers in `docs/RESULTS.md` with a tier, a model, a seed and a date. A scripted fixture is a statement about your code; it is never a statement about the world.

---

### 6.18 [extended] World models

**Intuition.** A world model is a learned simulator: instead of stepping a real environment, the agent predicts what the environment *would* do and plans against that prediction. If the model is good, you get unlimited cheap experience.

**The reference result.** DreamerV3 (Hafner, Pasukonis, Ba and Lillicrap, *Nature* 640(8059):647–653, 2 April 2025, [doi:10.1038/s41586-025-08744-2](https://www.nature.com/articles/s41586-025-08744-2)) is a general reinforcement-learning algorithm that learns a model of its environment and improves behaviour by imagining future scenarios, reported to outperform specialized methods across more than 150 diverse tasks **with a single fixed configuration**. The headline for an engineer is the last clause: the contribution is the removal of per-domain hyperparameter tuning, which is what made previous model-based RL impractical to apply.

**The frontier, and its evidence status.** Two directions, labelled honestly:

- *Scaling world models to train agents inside them* — Hafner, Yan and Lillicrap, 2025, [arXiv:2509.24527](https://arxiv.org/abs/2509.24527). DEMONSTRATED at research scale.
- *Generated interactive environments* — Genie 3 (Google DeepMind, 2025, [blog announcement](https://deepmind.google/discover/blog/genie-3-a-new-frontier-for-world-models/)). This is a **vendor announcement with demonstrations**, not a peer-reviewed evaluation you can reproduce: CLAIMED. Treat the demos as existence proofs of the rendering, not as evidence about downstream agent training.

**Why a text-agent engineer should care.** Because the same idea is arriving for tool-using agents: using a language model to *simulate the environment* — the API, the database, the user — so that agent training does not require the real system (for example, Li et al., 2025, [arXiv:2511.01824](https://arxiv.org/abs/2511.01824), on simulating environments with reasoning models for agent training). If it works, generating environments means generating curricula, and the data bottleneck in agent RL becomes a compute bottleneck instead.

And here is the risk, which is the same one in a new costume. **A simulated environment is your model's beliefs about your API, and an agent trained against it has learned those beliefs rather than your API.** Every mismatch between the simulator and the real service becomes a systematic, confident failure — and unlike a bug in a hand-written mock, it will be plausible, well-formatted, and distributed across thousands of training examples. Whether LLM-simulated environments can be made faithful enough to train against is, as of September 2026, **SPECULATION with early positive results** and not an engineering practice you should adopt for a production system.

---

### 6.19 [core] Open problems

Six, each stated as the thing that is *unsolved* rather than the thing that is hard.

**Reliability at scale.** §6.14's arithmetic is the problem in one line: nobody knows how to get per-step reliability high enough that hundred-step autonomous tasks work without supervision, and the self-conditioning result says the failure mode compounds rather than staying constant. The current answer in industry is not a better model but a shorter leash: checkpoints, approvals, and humans at the irreversible steps — exactly what Phases 10 and 14 built.

**Evaluation.** We do not have a general way to evaluate open-ended agent work. The field's best tools are environment-state checks (which need an environment), rubric judges (which need calibration, per Phase 13) and human review (which does not scale). Benchmarks saturate, contaminate, and freeze; τ-bench's own maintainers redirected new work to successors because the original tasks contained known bugs. **The honest position is that evaluation is currently the binding constraint on progress, not compute.**

**Security.** Prompt injection has no accepted solution — only mitigations, layered. Phase 14 taught the layering. Agents that browse, read email, or consume MCP tool output are consuming untrusted text and acting with the user's authority, and the attack surface grows with every integration. Self-improving systems make this worse by turning a one-off injection into a persistent one (§6.13).

**Cost.** Per-token prices have fallen steadily, but agent *episodes* cost far more than chat turns, and test-time compute pushes them further. The unresolved question is which economically valuable tasks survive the arithmetic: a task worth $2 of human time cannot absorb a $3 agent episode, however impressive the agent.

**Interpretability.** We cannot reliably say why an agent took an action. Reasoning traces are an output, not a log: a model can produce a trace that does not describe its actual computation, which is why Atlas grades the filesystem and not the transcript. Mechanistic interpretability is advancing but is nowhere near "explain this tool call".

**Economic and labour effects.** Genuinely unsettled, and the honest summary is that the *measurements disagree with each other and with the anecdotes*, that most published studies are short-horizon and industry-specific, and that this is a contested empirical and political question rather than a technical one. I am not going to adjudicate it in a tutorial appendix. What I will say is what the METR work implies methodologically: claims about displacement should be stated relative to *task length and task structure*, because those are what current systems are differentiated on, and a claim about "jobs" that does not decompose into tasks is not a measurable claim.

### 6.20 [core] Where to follow the field

Ordered by signal per hour, and chosen to be robust to the sources themselves changing:

1. **Primary papers, via arXiv listings** (`cs.AI`, `cs.CL`, `cs.LG`) or a paper-alert service. Read abstracts; read the setup section of anything you would cite.
2. **Lab technical reports and model cards**, for what is deployed rather than what is published. Treat them as vendor claims with unusually good access to data.
3. **Benchmark repositories rather than leaderboards.** The repository tells you whether the benchmark is maintained; the leaderboard does not.
4. **Evaluation organizations** that publish methodology — METR's task suites and analysis code are the reference example of a group that ships the thing you would need to reproduce them.
5. **Framework changelogs** for the libraries you actually use. This is where "the field moved" becomes "my code broke".
6. **Reproduction attempts and negative results.** The single highest-value habit in this list: when a result matters to you, search for its title plus "reproduce" or "fails". §6.4's contested RLVR question would have been invisible to anyone reading only the headline paper.

---

## 7. [core] Hands-on: fine-tune a small model on tool calls, and optimize one Atlas prompt

Two experiments. **Experiment A** (free GPU notebook) trains a LoRA adapter on a seeded synthetic tool-calling dataset and measures tool-call accuracy before and after. **Experiment B** (laptop, no GPU) runs an automatic prompt-optimization pass over Atlas's real router prompt. Everything except the GPU training step was executed while writing this appendix, and the outputs below are the real ones.

### 7.0 [core] How to run everything

Unzip `atlas_appendix_c.zip` **inside the Atlas snapshot root** — the directory holding `atlas/`, `evals/` and `Makefile` — so that `appendix_c/` sits beside them and two new files land in `tests/hidden/`. The appendix code imports `atlas.*` and `evals.stats`, so every command runs from that root with `PYTHONPATH=.` and nothing is installed:

```bash
python3 appendix_c/gen_toolcall_data.py                      # 1. the four seeded splits
PYTHONPATH=. python3 -m appendix_c.eval_toolcalls \
    --split appendix_c/data/toolcalls_test_seen.jsonl \
    --fixtures appendix_c/fixtures/toolcalls_before.json      # 2. harness, Tier F
PYTHONPATH=. python3 -m appendix_c.apo.optimize_router \
    --candidates appendix_c/fixtures/router_candidates.json \
    --drafts appendix_c/fixtures/router_drafts.json           # 3. prompt optimization
PYTHONPATH=. python3 appendix_c/skill_cost.py                 # 4. §6.12's numbers
PYTHONPATH=. python3 appendix_c/check_stats_parity.py         # 5. the stats copy agrees
make grade PHASE=c                                            # 6. the two assignments
```

All six are offline: no network, no model, no GPU. Only the fine-tune in §7.6 needs the notebook. `appendix_c/README.md` repeats this with the Tier A variants.

### 7.1 [core] The free-tier reality, before you start

Free notebook GPUs are a real resource with real rules, and the rules are *not published as guarantees*. Google's own Colab FAQ states that usage limits, idle timeouts, maximum VM lifetime and available GPU types vary over time and are not published, precisely because the service is free. So:

- **The GPU you get varies by day and by demand.** Do not design the run around a specific card. Cell 1 of the notebook prints what you were actually given (`!nvidia-smi`); size the batch to that.
- **Sessions end.** There is a maximum lifetime and an idle disconnect, and background execution does not count as interaction. Assume the session can die at any moment.
- **Therefore: checkpoint to durable storage, and keep the run short.** The notebook writes to Drive on Colab and to `/kaggle/working` on Kaggle, saves every fifty steps, and resumes from the latest checkpoint if one exists. That turns a dead session from a lost afternoon into a lost ten minutes.
- **Size the job to finish in one session.** This fine-tune is deliberately small: a sub-1B base model, a LoRA adapter, 279 training examples, short sequences, three epochs. Expect **roughly 15 to 40 minutes of training**, plus 10 to 20 minutes of model download and evaluation. If your configuration projects longer than about an hour, cut epochs rather than hoping.
- **If the session dies mid-run**: reconnect, rerun the setup cells, and resume from the checkpoint. Do not restart from scratch, and do not change hyperparameters between the before and after measurements — that would make the comparison uninterpretable.

The GPU model, its VRAM, the session limits, the base model and the library versions are all current-state facts. They are VERSIONS.md rows in §19 and appear nowhere in this prose, because every one of them will have changed by the time you read it.

### 7.2 [core] The measurement protocol, written before the result

Write the protocol, then run the experiment, then report. Never the reverse.

1. **Two eval sets, because they support different claims.**
   - `toolcalls_test_seen.jsonl` (n=90): the same templates as training, with slot values drawn from a *disjoint* vocabulary. Measures whether the model learned the output format and the tool vocabulary.
   - `toolcalls_test_unseen.jsonl` (n=30): five phrasings that appear in no training example. The only set that can support a claim about generalisation.
2. **Disjointness is enforced, not assumed.** The generator asserts that no request string appears in two splits, and prints `cross-split request overlap: 0`. §7.3 explains why that assertion exists.
3. **Decoding**: greedy (temperature 0), fixed seed, `max_new_tokens=160`, identical for both arms. Change decoding between arms and you have measured decoding.
4. **The only difference between arms** is the LoRA adapter: same base model, same system prompt, same harness, same scorer.
5. **Runs**: three sweeps per arm per set. One number from one run is not a measurement (Phase 13).
6. **Metrics**: four outcomes per example — `correct`, `wrong_args`, `wrong_tool`, `parse_failed` — plus tool-name accuracy, full-call accuracy, and a 95% Wilson interval on each. The four-way split exists because "accuracy fell" and "the model stopped emitting JSON" need different fixes.
7. **Decision rule, fixed in advance**: the fine-tune is worth keeping if full-call accuracy on **`test_unseen`** improves by more than the minimum detectable effect at n=30, *and* `parse_failed` does not rise on either set.

**What a difference of this size on sets of this size can and cannot tell you.** The minimum detectable effect is roughly **0.14 at n=90** and **0.25 at n=30** near a baseline of 0.6. So on the unseen set, a 30-point jump is real and a 10-point jump is indistinguishable from noise. These sets are small because the template space is small; the generator prints the sizes rather than letting you assume them, and if you want a tighter interval the fix is *more templates*, not more rows sampled from the same fifteen.

### 7.3 [core] The dataset: seeded, synthetic, disjoint — and the bug that got here first

**Start with the bug, because it is the lesson.** The first version of this generator drew all splits from one seeded stream and called them disjoint "by construction". They were not. Different draws from one stream are not different examples, and with a small slot space the collision rate is enormous:

```
test rows whose exact request also appears in train: 173 / 200
unique test requests: 71
```

Eighty-seven per cent of the "held-out" set was memorisable, and the reported n of 200 was really an effective n of 71, so every interval printed beside it was too narrow. Nothing in the pipeline complained. **A split is not held out because you called it held out; it is held out because something checked.**

The rewritten generator enforces three things:

- **Partitioned vocabularies.** Every template carries at least one slot, and each slot's value list is split into a training half and an evaluation half. A training request and an eval request cannot coincide because they cannot contain the same words.
- **Global de-duplication with an assertion.** Rejection sampling against a set of every request already emitted, followed by `assert` statements that no split contains a duplicate and that train shares nothing with dev, `test_seen` or `test_unseen`.
- **Honest sizes.** Some templates have a slot space only ten wide, so the generator takes what the space can supply and prints the per-tool distribution instead of looping forever to hit a target count.

```python
# Partitioned vocabularies. A TRAIN value never appears in an evaluation split.
VOCAB: dict[str, dict[str, tuple[str, ...]]] = {
    "region": {
        "train": ("west", "east", "north", "south", "midlands", "highland", ...),
        "eval": ("central", "coastal", "northwest", "southeast", "lakeside", ...),
    },
    ...
}
NUMBERS = {"train": (2, 59), "eval": (60, 99)}   # arithmetic is partitioned too

SEEN_TEMPLATES = [
    ("what is {a} times {b}", "calculate",
     lambda s: {"expression": f"{s['a']}*{s['b']}", "precision": 2}),
    ("how many shipments went to the {region} region", "query_db",
     lambda s: {"sql": f"SELECT COUNT(*) FROM shipments WHERE region = '{s['region']}'"}),
    ("what time is it in {zone}", "current_time",
     lambda s: {"timezone_name": s["zone"]}),
    ("hello, this is {name}, what can you do", "none", lambda s: {}),
    # ... fifteen in total
]

# Never seen in training. Same tools, different phrasing -- the only split that
# can support a claim about generalisation rather than memorisation.
UNSEEN_TEMPLATES = [
    ("could you work out {a} multiplied by {b} please", "calculate", ...),
    ("count the deliveries recorded for the {region} region", "query_db", ...),
    ("pull up whatever we have written about the {topic}", "retrieve_documents", ...),
    ("put a file at {file} recording that we follow the {topic}", "write_file", ...),
    ("nothing else for today, {name}", "none", ...),
]

    # The assertion is the point of this rewrite.
    for other in ("dev", "test_seen", "test_unseen"):
        overlap = requests["train"] & requests[other]
        assert not overlap, f"train/{other} overlap: {sorted(overlap)[:3]}"
```

Executed:

```
appendix_c/data/toolcalls_train.jsonl        n=279  unique=279  calculate=90 current_time=24
                                             list_files=12 none=24 query_db=24 read_file=24
                                             retrieve_documents=24 search_web=12 write_file=45
appendix_c/data/toolcalls_dev.jsonl          n=45   unique=45   ...
appendix_c/data/toolcalls_test_seen.jsonl    n=90   unique=90   ...
appendix_c/data/toolcalls_test_unseen.jsonl  n=30   unique=30   calculate=6 none=6 query_db=6
                                             retrieve_documents=6 write_file=6
cross-split request overlap: 0 (asserted)
```

And the idempotence check, because "seeded" is a claim and claims get checked:

```
$ md5sum appendix_c/data/*.jsonl > /tmp/b && python3 appendix_c/gen_toolcall_data.py && md5sum -c /tmp/b
appendix_c/data/toolcalls_dev.jsonl: OK
appendix_c/data/toolcalls_test_seen.jsonl: OK
appendix_c/data/toolcalls_test_unseen.jsonl: OK
appendix_c/data/toolcalls_train.jsonl: OK
```

Read the printed distribution rather than skipping it. `calculate` has 90 training rows and `list_files` has 12, because arithmetic has a huge slot space and directory names do not. That imbalance is a property of your data you can see *before* training, and it predicts exactly which tools the tuned model will handle worst.

**Three further design decisions.** The tool names and argument names are Atlas's real ones (`calculate`, `query_db`, `retrieve_documents`, `current_time`, `read_file`, `list_files`, `write_file`, `search_web`), taken from the tool modules, so a tuned model can be pointed at the real registry. About a fifth of every split is `none`, because abstention is a decision and a set with no negatives has a trivially optimal policy that always calls something. And the whole corpus is roughly 280 training rows — small, stated, and a deliberate demonstration that a template-generated corpus is smaller than it looks.

**Concept check C9.** The generator asserts disjointness across splits but cannot assert that `test_unseen` is *hard*. Name one way `test_unseen` could be trivially easy despite containing no training phrasing, and one cheap check that would reveal it.

### 7.4 [core] The scorer: four outcomes, not one number

```python
Outcome = Literal["correct", "wrong_args", "wrong_tool", "parse_failed"]


def parse_call(text: str) -> Prediction | None:
    """Pull a {"tool": ..., "arguments": {...}} object out of model text. Pure.

    Accepts a bare object or one inside a fenced block, because both are things
    small models do. Anything else is a parse failure, and a parse failure is
    recorded rather than repaired: a scorer that repairs output measures the
    repair, not the model.
    """
    candidate = text.strip()
    fenced = _FENCE.search(candidate)
    if fenced:
        candidate = fenced.group(1).strip()
    start, end = candidate.find("{"), candidate.rfind("}")
    if start == -1 or end <= start:
        return None
    try:
        payload = json.loads(candidate[start : end + 1])
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict) or "tool" not in payload:
        return None
    args = payload.get("arguments", {})
    if not isinstance(args, dict):
        return None
    tool = payload["tool"]
    return Prediction(tool if isinstance(tool, str) else None, args)


def normalise_args(args: dict[str, Any]) -> dict[str, str]:
    """Compare arguments as canonical strings, and say why.

    SQL whitespace and integer-versus-string are differences no user would
    notice and every exact-match scorer would punish. Lowercasing SQL keywords
    is NOT done: a scorer that normalises away case would also hide a model
    that emits a different identifier.
    """
    return {k: " ".join(str(v).strip().split()) for k, v in args.items()}


def score_one(expected_tool: str, expected_args: dict[str, Any], text: str) -> Outcome:
    prediction = parse_call(text)
    if prediction is None or prediction.tool is None:
        return "parse_failed"
    if prediction.tool != expected_tool:
        return "wrong_tool"
    if normalise_args(prediction.arguments) != normalise_args(expected_args):
        return "wrong_args"
    return "correct"
```

`report()` prints the counts, both accuracies, their Wilson intervals and the minimum detectable effect, using **Atlas's own `evals/stats.py`** — the interval arithmetic was written, tested and argued for in Phase 13 and there is no reason for a second copy:

```python
    try:  # Atlas's own, tested in Phase 13
        from evals.stats import min_detectable_effect, wilson_interval
    except ModuleNotFoundError:  # the free-GPU notebook has no Atlas on its path
        from appendix_c._stats import min_detectable_effect, wilson_interval
```

The fallback is a real trade-off, stated rather than hidden. The notebook runs on a machine that has the appendix scripts and *not* the Atlas snapshot, so without `_stats.py` the measurement cell dies with `ModuleNotFoundError` after the GPU time has already been spent. A duplicated formula is a second place to be wrong, so `appendix_c/check_stats_parity.py` compares the two implementations across a grid and is part of the §7.0 command list:

```
$ PYTHONPATH=. python3 appendix_c/check_stats_parity.py
stats parity: 84 comparisons, max difference < 1e-12
```

Executed on five hand-written cases:

```
['correct', 'wrong_args', 'wrong_tool', 'parse_failed', 'correct']
n = 5   correct=2  wrong_args=1  wrong_tool=1  parse_failed=1
tool-name accuracy   0.600  95% CI [0.231, 0.882]
full-call accuracy   0.400  95% CI [0.118, 0.769]
minimum detectable effect at this n: 0.620
```

Look at that last line. At n=5 the minimum detectable effect is 0.62, which is the scorer telling you, correctly, that it cannot distinguish anything. It is printed on every run for that reason.

### 7.5 [core] The harness: one sweep, three runs, and a tier that cannot lie

```python
def sweep(rows: Sequence[dict], generate: Generate, runs: int = 3) -> list[list[Outcome]]:
    """`runs` independent passes. One run is not a measurement (Phase 13)."""
    return [run_once(rows, generate) for _ in range(runs)]


def fixture_generator(table: dict[str, str]) -> Generate:
    """Tier F. Replays a committed request -> output map.

    A request with no fixture returns the empty string, which scores as
    `parse_failed`. Deliberate: a silent default of "correct" would make a
    missing fixture look like a passing model.
    """
    def generate(request: str) -> str:
        return table.get(request, "")

    return generate


def ollama_generator(model: str, host: str = "http://localhost:11434") -> Generate:
    """Tier A. Greedy decoding, fixed seed, so two sweeps differ only by the model.

    `OllamaHTTPClient` is the class Atlas actually ships (atlas/llm.py); there
    is no `OllamaClient`, and an earlier draft of this file imported that name
    and would have failed at the first Tier A run.

    # not executed during authoring; verified in companion-repo CI
    """
    from atlas.llm import Message, OllamaHTTPClient  # noqa: PLC0415

    client = OllamaHTTPClient(model=model, host=host)

    def generate(request: str) -> str:
        return client.complete(
            [Message(role="system", content=SYSTEM),
             Message(role="user", content=request)],
            temperature=0.0, seed=7, max_tokens=160, output_mode="json",
        ).text

    return generate
```

That docstring records a second real defect from the first draft: the import named a class that does not exist. It cost nothing here because the Tier F path is the one that runs offline — but it would have failed on the student's first Tier A sweep, after the fine-tune. **Every import of a name you did not verify is a scheduled failure.**

The harness takes a `generate` callable, which is what lets the same scorer serve the base model, the fine-tuned model, and a fixture set. Executed on Tier F:

```
TIER F: 16 fixture-backed rows of toolcalls_test_seen.jsonl. Plumbing, not a measurement.
--- run 1 ---
n = 16   correct=4  wrong_args=4  wrong_tool=4  parse_failed=4
tool-name accuracy   0.500  95% CI [0.280, 0.720]
full-call accuracy   0.250  95% CI [0.102, 0.495]
minimum detectable effect at this n: 0.346
--- run 2 ---   [identical]
full-call accuracy across runs: [0.25, 0.25] (spread 0.000)
```

The spread of exactly zero is the tell: fixtures are deterministic, so three Tier F runs prove the harness is wired correctly and nothing else. **On Tier A the spread will not be zero, and the size of that spread is information about the model that a single run destroys.**

### 7.6 [core] The fine-tune, and the one flag that implements §6.2

The notebook is short on purpose. Four decisions carry the weight, and the second is the one worth slowing down for.

**LoRA, not full fine-tuning**, because full fine-tuning does not fit a free GPU.

**Loss on the assistant span only.** This is §6.2's masking rule, and the library gives you two routes to it, which behave differently:

| Dataset format | Flag | What it needs | How it fails |
|---|---|---|---|
| Prompt-completion (`prompt` + `completion` columns) | `completion_only_loss=True` (the default for this format) | Nothing extra; the boundary is structural | Loudly, if you also pass a formatting function |
| Conversational (one `messages` column) | `assistant_only_loss=True` | A chat template carrying `{% generation %}` markers; TRL patches known families automatically | **Silently**, when `use_liger_kernel=True` — the assistant masks are dropped and loss is computed over the whole sequence |

The notebook takes the prompt-completion route, because it has fewer ways to fail quietly. The first draft of this appendix used the conversational format with `completion_only_loss`, which is the wrong pairing: the flag applies to prompt-completion data, so the run would have trained on the full sequence, including the user's request — the exact defect §6.2 says never to ship.

**A durable output directory with `resume_from_checkpoint`**, and **`seed=7`**, Atlas's seed.

```python
# appendix_c/finetune_lora.ipynb, cell 3
# not executed during authoring; verified in companion-repo CI

def to_prompt_completion(r):
    """Conversational prompt-completion: the prompt is masked structurally."""
    target = json.dumps({'tool': r['tool'], 'arguments': r['arguments']}, sort_keys=True)
    return {'prompt': [{'role': 'system', 'content': SYSTEM},
                       {'role': 'user', 'content': r['request']}],
            'completion': [{'role': 'assistant', 'content': target}]}

train = Dataset.from_list([to_prompt_completion(r) for r in rows])

trainer = SFTTrainer(
    model=model,
    train_dataset=train,
    peft_config=LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, task_type='CAUSAL_LM'),
    args=SFTConfig(
        output_dir=OUT, num_train_epochs=3, per_device_train_batch_size=4,
        gradient_accumulation_steps=4, learning_rate=2e-4, max_length=512,
        logging_steps=10, save_steps=50, save_total_limit=2, seed=7, report_to='none',
        completion_only_loss=True,   # prompt-completion format: mask the prompt
    ),
)
resume = any(n.startswith('checkpoint') for n in os.listdir(OUT))
trainer.train(resume_from_checkpoint=resume)
```

**And then check that the masking happened**, because a flag you believe in is not a flag that fired. Cell 3b decodes the tokens the trainer will actually compute loss on:

```python
batch = trainer.data_collator([trainer.train_dataset[0]])
labels = batch['labels'][0]
kept = [int(t) for t, l in zip(batch['input_ids'][0], labels) if int(l) != -100]
print('LOSS IS COMPUTED ON:', repr(tokenizer.decode(kept)))
```

You should see the JSON tool call and nothing else. If the system prompt or the user's request appears in that output, stop: the run is training the model to write user turns, and thirty seconds here saves the session. This check is the hands-on equivalent of Phase 16's rule that a control nothing reads is indistinguishable from an absent one.

### 7.7 [core] The measurement table — with the cells empty

I cannot run a GPU fine-tune while writing this, so the table ships with blanks. **Filling them in is your job, and a table with invented numbers would be worse than no table.**

| Arm | Eval set | Runs | `correct` | `wrong_args` | `wrong_tool` | `parse_failed` | Full-call accuracy (95% CI) |
|---|---|---|---|---|---|---|---|
| Base | `test_seen` (n=90) | 3 | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ |
| Base | `test_unseen` (n=30) | 3 | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ |
| + LoRA | `test_seen` (n=90) | 3 | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ |
| + LoRA | `test_unseen` (n=30) | 3 | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ | \_\_\_\_ |
| Difference | `test_seen` | — | — | — | — | — | \_\_\_\_ vs MDE ≈ 0.14 |
| Difference | `test_unseen` | — | — | — | — | — | \_\_\_\_ vs MDE ≈ 0.25 |

**Illustrative arithmetic, not a measurement.** Suppose the base arm scores 0.30 on `test_seen` and the tuned arm 0.85: the difference of 0.55 clears the 0.14 floor, so format learning happened. Suppose the same arms score 0.27 and 0.40 on `test_unseen`: that difference of 0.13 is *below* the 0.25 floor, so the correct report is "no detectable generalisation to unseen phrasing", not "a smaller improvement".

**What a plausible outcome looks like.** On a task this narrow, a large jump on `test_seen` is the *expected* result. The interesting numbers are elsewhere: whether `parse_failed` goes to near zero (format learning, which SFT is genuinely good at), whether `wrong_args` persists (argument construction, which is harder and where small models stay weak), and whether anything at all moves on `test_unseen`. **A gain on `test_seen` with nothing on `test_unseen` is a real, publishable finding about your experiment: the model learned your fifteen templates.**

**What would make the result meaningless.** Different decoding between arms; a single run per arm; comparing the tuned arm's best run against the base arm's worst; quoting the `test_seen` number alone; or quoting any of it without the generator, the seed and the split sizes.

### 7.8 [core] Experiment B: optimizing Atlas's router prompt

This one runs on the laptop and touches real Atlas code. The subject is `atlas/prompts/files/atlas_router.v1.md`, loaded through `load_prompt("atlas_router", version=1)` and rendered with `render_route_table()`. The labelled set is seeded (`appendix_c/apo/routing_set.py`, 48 examples balanced across the five `Route` values, split into a 24-item dev and a 24-item holdout by interleaving so both halves stay balanced).

The loop's three rules are enforced in code:

```python
"""Automatic prompt optimization over Atlas's real router prompt.

Optimizes `atlas_router` against `atlas.flow.route`'s own decision rules: the
candidate prompt changes only the MODEL's opinion, while `keyword_route` and
`reconcile` stay exactly as Phase 5 wrote them. That is the point -- what is
being tuned is one input to a decision, not the decision.

* **The incumbent wins ties.** A candidate must score STRICTLY higher on dev to
  be promoted. An equal score is not evidence, and a loop that swaps on ties
  drifts for free.
* **The holdout is measured once, at the end, for the winner only.** Scoring
  every candidate on the holdout turns it into a second dev set.
* **Nothing is written to `atlas/prompts/files/`.** The loop reports; a human
  promotes, with a CHANGELOG entry naming this measurement. An optimizer with
  write access to the artefact directory is an unreviewed author.
"""


def decide(request: str, draft: RouteDraft | None,
           *, threshold: float = DEFAULT_THRESHOLD) -> RouteDecision:
    """Phase 5's reconciliation, with the model's opinion supplied.

    A fork of `classify_route`'s tail rather than a call to it, for one reason
    worth stating: `classify_route` builds its prompt internally with
    `build_router_prompt()`, so the prompt is not a parameter and a candidate
    cannot be injected. That is a finding about Atlas, not about the optimizer.
    The DECISION RULES are imported, never reimplemented.
    """
    hint, hint_confidence = keyword_route(request)
    if draft is None:
        return RouteDecision(request=request, route="research", confidence=0.0,
                             source="fallback", fallback_used=True,
                             reason="classifier failed", keyword_hint=hint,
                             keyword_confidence=hint_confidence, error="unparseable")
    resolution = reconcile(draft.route, draft.confidence, hint, hint_confidence,
                           threshold=threshold)
    return RouteDecision(request=request, route=resolution.route, ...)


def optimize(candidates, draft_fn, *, n=48, seed=7) -> str:
    rows = build(n=n, seed=seed)
    dev, holdout = split(rows)
    scored = [score(c, dev, draft_fn) for c in candidates]
    incumbent = scored[0]
    best = max(scored[1:], key=lambda s: s.accuracy, default=None)
    winner = best if best is not None and best.correct > incumbent.correct else incumbent
    ...
```

**Design note worth the two minutes.** Writing `decide()` surfaced a real property of Atlas: `classify_route` calls `build_router_prompt()` internally, so the prompt is not an argument and there is no way to score a candidate through the public function. That is not a defect — Phase 5 had no reason to parameterize it — but it is the exact shape of coupling that makes a system hard to optimize, and you only discover it by trying. The appendix code forks the *tail* of the function and imports the decision rules (`keyword_route`, `reconcile`) rather than copying them, so the thing under test is the prompt and nothing else.

**Scenario 1, executed** (fixture scores, invented to exercise the loop; the scripted "incumbent" mislabels every `research` request as `data`):

```
TIER F: scores below come from committed fixtures, not from a model.
dev n=24  holdout n=24

* incumbent    bf21dba157aa  dev 24/24 = 1.000
  cand-a       d25752b8638f  dev 24/24 = 1.000
  cand-b       2c22e61ab52d  dev 19/24 = 0.792

winner: incumbent (incumbent kept: no candidate beat it on dev)
```

**This is the finding of the exercise, and I did not plan it.** The incumbent scores 24/24 *while getting every research question wrong at the model layer*. Why? `keyword_route` fires on "compare", "brief", "summarise" and says `research`; the model says `data`; `reconcile` sees a disagreement, caps confidence at 0.5, which falls below the 0.6 threshold, and routes to the fallback — and `FALLBACK_ROUTE` is `research`. Phase 5's defence exactly cancels the prompt's error.

The lesson generalizes past Atlas. **An end-to-end score measures the system, not the component, and a system with good defences will hide a bad component from your optimizer.** To optimize a prompt you must also record the component-level signal — here, `decision.model_route` — or you will conclude the prompt is fine while it quietly leans on a safety net built for a different purpose.

**Scenario 2, executed** (the incumbent instead mislabels `data` as `chat`, which the `research` fallback cannot rescue):

```
dev n=24  holdout n=24

  incumbent    bf21dba157aa  dev 19/24 = 0.792
* cand-a       d25752b8638f  dev 24/24 = 1.000
  cand-b       2c22e61ab52d  dev 19/24 = 0.792

winner: cand-a (promoted)
holdout incumbent 19/24 = 0.792
holdout winner    24/24 = 1.000  95% CI [0.862, 1.000]
minimum detectable effect at holdout n=24: 0.230

Nothing was written. To adopt: copy the winning text to
atlas/prompts/files/atlas_router.v2.md, update the pinned checksum, and add a
CHANGELOG entry naming this run.
```

Read the last two numbers together. The holdout improvement is 0.208; the minimum detectable effect at n=24 is 0.230. **The observed gain is smaller than the smallest gain this holdout can detect** — so even a five-item improvement is not sufficient evidence to promote a prompt. The honest next step is more holdout examples, not a changelog entry. That line is printed automatically so you cannot skip it.

To run the same loop on Tier A, replace the fixture draft function with one that calls your local model with the candidate text, set `ATLAS_TIER=A` and `ATLAS_MODEL`, and budget about 150 calls: five candidates × 24 dev items, plus two arms × 24 holdout.

### 7.9 [core] With an assistant

**Safe to delegate.** Boilerplate around the notebook: Drive mounting, checkpoint-resume logic, argparse plumbing, converting the JSONL rows into the trainer's chat format, and writing the *first* draft of table-formatting code for your results. Also: asking it to explain a traceback from a library version mismatch, which is most of what goes wrong in a free notebook.

**Not safe to delegate.** Three things, and they are the three that determine whether your result means anything. The **measurement protocol** — if the assistant picks your splits, your decoding or your decision rule, you will not notice when it picks them to make the number look good. The **scorer**, because a scorer is where a subtle leniency (repairing malformed JSON, normalizing away a wrong identifier) turns a null result into a success. And the **interpretation** — an assistant asked "is this improvement significant?" will tend to agree with the framing in your question.

**A prompt that works:**

> Here is my eval harness and scorer for a tool-calling experiment [paste]. I have not run it yet. Do not improve the metric or the scoring rules. Instead, list every way this setup could produce an improvement that is not a real improvement in tool-calling ability — data leakage, scorer leniency, decoding differences, selection effects — and for each, tell me the smallest check that would detect it.

Asking for attacks on your own experiment is the one request where an assistant's fluency is working for you rather than against you.

---

## 9. [core] Common pitfalls & how professionals avoid them

**Fine-tuning to fix a retrieval problem.** The symptom is "the model doesn't know our product names". The fix is retrieval, not training. Professionals ask "would a person with this document in front of them get it right?" — if yes, it is a context problem.

**Comparing a tuned arm against an untuned prompt.** A fine-tune that beats a badly-prompted baseline has beaten your prompt engineering. Always tune the prompt for the base model *first*, then measure the fine-tune against that.

**Calling a split "held out" without checking.** The first draft of this appendix drew every split from one seeded stream and called them disjoint by construction; 173 of 200 test rows turned out to share their exact request string with training, and the effective n was 71 rather than 200. Professionals assert disjointness in the generator and print the unique count — and hold out *templates*, not just rows, when they want a generalization claim.

**Importing a name you did not verify.** The same draft imported `OllamaClient` from `atlas.llm`, which ships `OllamaHTTPClient`. Offline tests passed because they never touched that path; the failure was scheduled for the student's first Tier A run. Professionals grep the source for every symbol they import from someone else's package, especially on paths their tests cannot reach.

**Trusting a configuration flag to have fired.** A masking flag that applies to a different dataset format is silently ignored, and you discover it in the loss curve if at all. Professionals decode one batch's unmasked tokens and read them before spending the GPU hours.

**Quoting a benchmark number without its setup.** Model, prompt, decoding, harness, date, and who ran it. A number missing any of those is a rumour. (τ-bench's history is the cautionary tale: the original board is frozen, so later numbers under that name come from vendors or from successor benchmarks.)

**Promoting a prompt on a dev-set win.** The optimizer's job is to find dev-set wins; that is what it is for. Only the holdout, compared against the MDE, says anything.

**Letting an optimizer write to the artefact directory.** Then nobody can say what the prompt used to be or why it changed. Optimizers report; humans promote; the changelog names the measurement.

**Treating a reasoning trace as a log.** A trace is generated output. Professionals grade state — the database row, the file on disk, the recorded decision — and use the trace only to form hypotheses.

**Ignoring the spread.** One run is a sample. Professionals report three runs and the spread, and treat a spread larger than the effect they are claiming as a result in itself.

**Carrying failures forward in context.** §6.14's self-conditioning result says an agent that can see its own errors becomes more likely to make more. Summarize the failure, keep the fact, drop the botched attempt.

---

## 10. [extended] Industry perspective

**Who actually fine-tunes.** Very few product teams, and the ones that do usually do it for *cost and latency*, not capability: they have a high-volume narrow subtask (classification, extraction, format conversion), a frozen-model baseline that works, and a bill that makes a small tuned model worth the operational burden. The pattern is almost always distillation — capture the big model's behaviour on your real traffic, filter it, train a small model, keep the big model as the fallback for the hard cases.

**The operational burden nobody budgets for.** A fine-tuned model is a new artefact with a lifecycle: a training dataset that must be versioned, an eval set that must be kept clean, a serving path, a rollback plan, and a re-training obligation every time the base model line moves. Teams routinely underestimate this by an order of magnitude. A prompt change costs a review; a model change costs a release process.

**Where the money is going instead.** Evaluation infrastructure and context engineering. The organizations shipping reliable agents in 2026 are mostly not the ones with the best models — they are the ones who can tell, within a day, whether a change made things better. That is Phase 13's argument, and it is the one that has held up best commercially.

**The small-model thesis.** There is a live argument that most agent sub-tasks should run on small specialized models with a frontier model reserved for the hard steps (Belcak et al., 2025, arXiv:2506.02153 — an argued position, not a measured result). Whether it wins depends on something nobody can currently predict: whether frontier inference prices fall faster than the engineering cost of maintaining a fleet of small models.

**Interview questions** you should be able to answer:

1. A colleague proposes fine-tuning your assistant so it stops getting the product catalogue wrong. Walk me through how you would decide whether that is the right intervention, and what you would try first.
2. Explain GRPO to a backend engineer in two minutes without equations. Then tell me what happens when every sample in a group gets the same reward, and why that matters operationally.
3. You have run a prompt optimizer and the winning candidate is 6 points better on a 50-item dev set. What do you do before shipping it?
4. Your agent succeeds on 92% of steps. A customer workflow takes 30 steps. What do you tell the customer, and what are the two cheapest engineering changes that move the number they care about?
5. How would you design an offline evaluation for an agent that books travel, given that you cannot book real flights in a test?

---

## 12. [core] Mastery checklist

You are ready to move on if you can:

- Explain, without notes, how a tool-use trajectory becomes a training example, and which spans carry loss.
- State what rejection-sampling fine-tuning depends on, and name a bad trajectory that would pass an outcome-only filter.
- Explain a GRPO-style method to a colleague in plain words, and name four of its failure modes.
- Say which of RLHF, RLAIF and RLVR applies to a given task, and why.
- State the contested question about RLVR and capability, cite one source on each side, and say what would settle it.
- Compute what a test-time-compute strategy costs in calls, tokens and wall-clock, and say whether you have the verifier it needs.
- Run the seeded generator, the scorer and the harness on your laptop, and explain what each output line means.
- Complete the LoRA fine-tune in one free session, fill in both halves of the measurement table, and say which of `test_seen` and `test_unseen` supports which claim.
- Verify, before training, that loss is computed only on the assistant span, by decoding one batch.
- Run the router optimization pass, explain why the incumbent wins scenario 1, and say why the scenario-2 winner still should not be promoted.
- Name three ways a skill library degrades without curation, and the operation that fixes each.
- Read an agent paper and separate what was demonstrated, what was claimed, and what was speculated.

---

## 13. [core] Quiz

1. Why is loss computed on assistant spans but not on tool observations, and what specific failure does training on observations produce?
2. GRPO replaces PPO's value function with the mean reward of a sampled group. Name two consequences of that substitution — one benefit, one failure mode — and explain why a group in which every sample fails contributes nothing.
3. RLVR and RLHF differ in where the reward comes from. Give a task for which RLVR is applicable and RLHF is awkward, and one for which the reverse is true, and justify both.
4. Best-of-N and self-consistency both sample k times. What must be true of your task for best-of-N to be usable, and what happens to each method when the model is confidently wrong in a correlated way?
5. An agent's per-step success rate improves from 90% to 95%. Roughly how does the length of task it can complete at 50% success change, and why does this make short-benchmark progress a misleading indicator?
6. A skill library adopts a new skill after every successful episode. Give three distinct mechanisms by which this system gets *worse* over six months, and the smallest change that prevents each.

---

## 14. [core] Coding assignments

### Assignment 1 [fast track: do this one] — Explain and implement the core of a GRPO-style update

**Part A (written, the UNAIDED CORE).** In 400–600 words of your own prose, with no assistant, explain a GRPO-style method to a competent engineer who knows no RL. You must cover: what is being optimized, what the group is, what replaces the value function, and why that saves memory. Then name **four** failure modes and, for each, the operational symptom you would see in a training log.

**Part B (code).** Create `appendix_c/grpo.py` with two pure functions:

```python
def group_relative_advantages(rewards: Sequence[float], *, eps: float = 1e-6) -> list[float]
def group_is_informative(rewards: Sequence[float], *, eps: float = 1e-6) -> bool
```

`group_relative_advantages` returns each sample's reward centred on the group mean and scaled by the group standard deviation. `group_is_informative` says whether the group carries any learning signal.

**Acceptance criteria.**
- Advantages sum to zero and have unit mean square for a group with non-zero variance.
- A group where every sample scores identically — all pass *or* all fail — returns all zeros, never `NaN`, and is reported as uninformative. (This is the zero-variance case from §6.4 and it is the whole point of the exercise.)
- Order is preserved; results are invariant to adding a constant to every reward and to multiplying every reward by a positive constant.
- An empty group raises `ValueError`.
- No numpy. Standard library only, so the arithmetic is visible.

**Hidden test file:** `tests/hidden/test_phasec_grpo.py` — named so that the Makefile's `tests/hidden/test_phase$(PHASE)_*.py` glob collects it, which `test_appendix_c_grpo.py` did not. Run it with `make grade PHASE=c`. Do not read it; when it fails, reproduce the failure with your own test first. Verified against a reference implementation: **7 passed**, and it skips cleanly with "Assignment 1 module not written yet" when the module does not exist.

### Assignment 2 [extended] — A skill library that writes, refuses, and retires

Atlas can *load* skills (`atlas/memory/skills.py`) and cannot *write* them. Build the missing half as `appendix_c/skill_library.py`, on top of the existing loader — do not fork it.

**Required API:**

```python
@dataclass(frozen=True)
class SkillProposal:      # name, description, triggers, body, evidence
    def render(self) -> str: ...            # valid SKILL.md, frontmatter included

class AdoptionRefused(RuntimeError): ...

def propose_from_episodes(name, description, body, episodes) -> SkillProposal
def adopt(proposal, catalogue, root) -> Skill
def retire_unused(catalogue, usage, *, min_uses=1) -> list[str]
```

**Acceptance criteria.**
- `propose_from_episodes` refuses unless at least **two** episodes are marked `verified_by_environment`. An agent's own account of success is not evidence (Phase 13).
- Triggers are derived from words shared by all verified episodes, and a proposal with fewer than `MIN_TRIGGER_MATCHES` shared triggers is refused: the episodes do not describe one procedure.
- `adopt` refuses an invalid skill name, a duplicate name, and — the interesting one — a **trigger collision**: if the proposal shares `MIN_TRIGGER_MATCHES` or more triggers with an existing skill, adoption fails, because two skills that activate on the same words make activation a coin toss.
- A refused adoption leaves **nothing on disk**.
- What is written must load through Atlas's own `load_skill`, with its triggers and body intact.
- `retire_unused` returns the names below the usage threshold, sorted.
- The evidence (episode ids) is recorded in the skill's frontmatter metadata.

**UNAIDED CORE:** the refusal rules. You may use an assistant for the frontmatter rendering and the file plumbing; decide the refusal conditions yourself and write a one-paragraph justification for each, because these are the security and quality gates of the whole design (§6.13).

**Hidden test file:** `tests/hidden/test_phasec_skills.py`, collected by the same `make grade PHASE=c`. Verified against a reference implementation: **8 passed**.

---

## 15. [extended] Critical-reading assignment: review a recent agent paper

This is the assignment the appendix exists for. Pick **one** paper from the last twelve months that claims an improvement in agent capability, reliability or training. Good hunting grounds: recent arXiv `cs.AI`/`cs.CL` listings, an accepted-papers list from a recent conference, or any paper a colleague has cited at you as settled.

Rules: it must be a primary source (not a blog summary), it must make an empirical claim, and it must be new enough that no consensus has formed.

### The review template

Answer all nine. Aim for 1,200–1,800 words.

1. **Claim.** In one sentence, in your own words, what does the paper claim is true that was not known before?
2. **Setup.** Which models, which benchmarks or environments, how many seeds or runs, what compute budget, what decoding parameters? List what is stated and, separately, **what is missing**.
3. **Baselines.** What is the comparison? Was the baseline tuned with comparable effort? Is the comparison budget-matched (rollouts, tokens, wall-clock)?
4. **Measurement.** What exactly is the metric, and what would move it *without* the underlying capability changing? Is a confidence interval or a spread reported? Would the claimed effect survive the minimum detectable effect at their sample size?
5. **Demonstrated / claimed / speculated.** Divide the paper's assertions into these three buckets, with at least two entries in each.
6. **Contradicting work.** Search for it, and report what you find — a replication failure, a contested metric, a paper claiming the opposite. "I searched and found none" is an acceptable answer only if you name the searches.
7. **The experiment that would discriminate.** Design one experiment, runnable by a small team, that would distinguish the paper's explanation from the most plausible alternative explanation.
8. **Transfer.** Would this change anything about how you build Atlas? Name the file you would touch, or say plainly that it would change nothing and why.
9. **Verdict.** In three sentences, what should a practitioner believe after reading this?

### Rubric (30 points)

| Criterion | Points | What full marks looks like |
|---|---|---|
| Claim stated correctly and narrowly | 4 | Neither inflated beyond the paper nor watered down; scope conditions included |
| Setup extracted, including what is **missing** | 5 | Names at least two things the paper does not report and says why each matters |
| Baseline and budget analysis | 4 | Identifies whether the comparison is matched, and on which axis |
| Metric critique | 5 | Names a concrete way the metric could move without capability changing; engages with sample size |
| Demonstrated / claimed / speculated split | 4 | Correct bucketing with at least two items in each; no "claimed" item smuggled into "demonstrated" |
| Contradicting work | 3 | Real search, cited, with the disagreement characterized rather than dismissed |
| Discriminating experiment | 3 | Actually runnable; distinguishes two explanations rather than merely gathering more support for one |
| Transfer and verdict | 2 | Concrete, and willing to conclude "this changes nothing for me" |

A full model answer, reviewing a named recent paper against this template, is in `appendix_c_solutions.md`.

---

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you need it.*

**The three levers are the prompt, the context, and the weights, and the third is mostly not yours.** Sixteen phases of Atlas changed the first two and never touched a weight, which was the right order: the engineering that makes agents reliable is overwhelmingly outside the model. Knowing how the third works is diagnostic rather than operational — it tells you whether the defect in front of you is a prompt problem, a context problem, or a reason to change models.

**Trajectories become training data by masking.** Loss on the assistant spans; never on the user turn, never on the tool observation. A model trained to predict tool outputs is a model that will invent them. And **trajectory data without failure and recovery trains an agent that only works when nothing goes wrong**, which is why a failure log is the most valuable file in a repository that intends to train anything.

**Rejection sampling manufactures data from a verifier, so the verifier is the product.** Outcome-only filters admit process-level false positives and then reinforce them. This is Phase 13's "grade the filesystem, not the transcript", moved upstream into the training set.

**GRPO's group is its own baseline, and every failure mode follows from that.** No value function means less memory and no critic to train; it also means that a group with no variance — all pass or all fail — carries no gradient at all. Reward hacking, entropy collapse, length artefacts and verifier gaming are the named ways an optimizer exploits a scorer you wrote.

**Whether RL expands capability or sharpens sampling is unresolved.** Yue et al. (2025, arXiv:2504.13837) found base models recovering more solutions at large k; ProRL (2025, arXiv:2505.24864) reported the opposite under prolonged training with exploration control; a third paper attacks the metric itself. All three ran real experiments. The field has no consensus, and the answer appears to depend on training scale and on how capability is defined.

**Horizon is exponential in step reliability.** 90% to 99% per-step multiplies the completable task length roughly tenfold. METR's measured horizon trend and the self-conditioning result (arXiv:2509.09677 — models make more errors when their context contains their own earlier errors, and scaling alone does not fix it) together say that long-task failure is an *execution* problem, and that leaving a failed step in the context makes the next step worse.

**Self-improvement is a loop with four parts: candidate, scorer, selection, memory.** Remove any one and it is not a loop. The text-level version — automatic prompt optimization — is competitive with the weight-level version on a surprising range of tasks at a fraction of the compute, and is the one you can run tonight.

**The measured lesson of this appendix's own experiment.** Optimizing Atlas's router prompt against end-to-end accuracy produced a perfect score for a prompt that got every research question wrong at the model layer, because `reconcile` capped the confidence on disagreement and the fallback route happened to be the right answer. **An end-to-end score measures the system, not the component, and a good defence will hide a bad component from your optimizer.** In the scenario where the defence could not rescue it, the winning candidate improved the holdout by 0.208 against a minimum detectable effect of 0.230 — so the honest conclusion was "get more holdout examples", not "ship it".

**A split is held out only if something checked.** This appendix's own first draft shipped a "held-out" test set of which 87% was memorisable, with intervals quoted at an n nearly three times the effective one, and nothing complained. The fix is three lines in a generator: partition the vocabularies, de-duplicate globally, assert the disjointness and print it. The same discipline explains why the corrected hands-on carries two eval sets — one for format, one for unseen phrasing — because only the second can support a claim about tool use.

**Everything in this area goes stale, so sourcing is the skill.** State the model, the benchmark, the budget, the seeds and the date; separate what was demonstrated from what was claimed from what was speculated; and search for the paper that disagrees before you cite the one that agrees.

---

## 17. [core] Further reading

All links checked 15 September 2026, with three exceptions named below. Ordered roughly as the appendix used them.

*Verification status, because in this appendix sourcing is the product:* every arXiv identifier below was checked against the paper's own abstract page or a primary reference list on 15 September 2026, **except** InstructGPT (2203.02155), ReST-EM (2312.06585) and APIGen (2406.18518), which are quoted from memory and are the three you should confirm before citing them yourself. That is an uncomfortable sentence to write and it is the honest one; a list that implies uniform verification when it had none is exactly the failure §15 teaches you to catch.

**Training for agency**
- Schick et al., *Toolformer*, Feb 2023 — [arXiv:2302.04761](https://arxiv.org/abs/2302.04761)
- Patil et al., *Gorilla*, May 2023 — [arXiv:2305.15334](https://arxiv.org/abs/2305.15334)
- Qin et al., *ToolLLM*, Jul 2023 — [arXiv:2307.16789](https://arxiv.org/abs/2307.16789)
- Chen et al., *FireAct*, Oct 2023 — [arXiv:2310.05915](https://arxiv.org/abs/2310.05915)
- Zeng et al., *AgentTuning*, Oct 2023 — [arXiv:2310.12823](https://arxiv.org/abs/2310.12823)
- Liu et al., *APIGen*, Jun 2024 (NeurIPS 2024) — [arXiv:2406.18518](https://arxiv.org/abs/2406.18518); *APIGen-MT*, Apr 2025 — [arXiv:2504.03601](https://arxiv.org/abs/2504.03601)

**Rejection sampling and RL**
- Zelikman et al., *STaR*, Mar 2022 — [arXiv:2203.14465](https://arxiv.org/abs/2203.14465)
- Ouyang et al., *InstructGPT*, Mar 2022 — [arXiv:2203.02155](https://arxiv.org/abs/2203.02155)
- Bai et al., *Constitutional AI*, Dec 2022 — [arXiv:2212.08073](https://arxiv.org/abs/2212.08073)
- Shao et al., *DeepSeekMath* (GRPO), Feb 2024 — [arXiv:2402.03300](https://arxiv.org/abs/2402.03300)
- Lambert et al., *Tülu 3* (RLVR), Nov 2024 — [arXiv:2411.15124](https://arxiv.org/abs/2411.15124)
- Guo et al., *DeepSeek-R1*, *Nature* 645:633–638, 17 Sep 2025 — [doi:10.1038/s41586-025-09422-z](https://www.nature.com/articles/s41586-025-09422-z)
- Yue et al., *Does RL really incentivize reasoning capacity beyond the base model?*, Apr 2025 — [arXiv:2504.13837](https://arxiv.org/abs/2504.13837)
- Liu et al., *ProRL*, May 2025 — [arXiv:2505.24864](https://arxiv.org/abs/2505.24864)
- Qian et al., *ToolRL*, Apr 2025 — [arXiv:2504.13958](https://arxiv.org/abs/2504.13958); Jin et al., *Search-R1*, Mar 2025 — [arXiv:2503.09516](https://arxiv.org/abs/2503.09516)

**Test-time compute and distillation**
- Brown et al., *Large Language Monkeys*, Jul 2024 — [arXiv:2407.21787](https://arxiv.org/abs/2407.21787)
- Snell et al., *Scaling LLM test-time compute optimally*, Aug 2024 — [arXiv:2408.03314](https://arxiv.org/abs/2408.03314)
- *Scaling test-time compute without verification or RL is suboptimal*, Feb 2025 — [arXiv:2502.12118](https://arxiv.org/abs/2502.12118)
- Kang et al., *Distilling LLM agent into small models*, May 2025 (NeurIPS 2025) — [arXiv:2505.17612](https://arxiv.org/abs/2505.17612)
- Belcak et al., *Small language models are the future of agentic AI* (position), Jun 2025 — [arXiv:2506.02153](https://arxiv.org/abs/2506.02153)

**Self-improvement**
- Zhou et al., *APE*, Nov 2022 — [arXiv:2211.01910](https://arxiv.org/abs/2211.01910)
- Pryzant et al., *Automatic prompt optimization with "gradient descent"*, May 2023 — [arXiv:2305.03495](https://arxiv.org/abs/2305.03495)
- Yang et al., *OPRO*, Sep 2023 — [arXiv:2309.03409](https://arxiv.org/abs/2309.03409)
- Khattab et al., *DSPy*, Oct 2023 — [arXiv:2310.03714](https://arxiv.org/abs/2310.03714); Opsahl-Ong et al., *MIPROv2*, EMNLP 2024 — [arXiv:2406.11695](https://arxiv.org/abs/2406.11695)
- Agrawal et al., *GEPA*, Jul 2025 (ICLR 2026) — [arXiv:2507.19457](https://arxiv.org/abs/2507.19457)
- Wang et al., *Voyager*, May 2023 — [arXiv:2305.16291](https://arxiv.org/abs/2305.16291)
- Shumailov et al., *AI models collapse when trained on recursively generated data*, *Nature* 631:755–759, 24 Jul 2024 — [doi:10.1038/s41586-024-07566-y](https://www.nature.com/articles/s41586-024-07566-y) (author correction: *Nature* 640:E6, 2025)

**Long horizons, environments, world models**
- Kwa et al., *Measuring AI ability to complete long tasks*, Mar 2025, rev. Jul 2026 — [arXiv:2503.14499](https://arxiv.org/abs/2503.14499)
- Sinha et al., *The illusion of diminishing returns*, Sep 2025 (ICLR 2026) — [arXiv:2509.09677](https://arxiv.org/abs/2509.09677)
- Zhou et al., *WebArena*, Jul 2023 — [arXiv:2307.13854](https://arxiv.org/abs/2307.13854)
- Yao et al., *τ-bench*, Jun 2024 — [arXiv:2406.12045](https://arxiv.org/abs/2406.12045); Barres et al., *τ²-bench*, Jun 2025 — [arXiv:2506.07982](https://arxiv.org/abs/2506.07982)
- Hafner et al., *Mastering diverse control tasks through world models*, *Nature* 640:647–653, 2 Apr 2025 — [doi:10.1038/s41586-025-08744-2](https://www.nature.com/articles/s41586-025-08744-2)
- Hafner, Yan and Lillicrap, *Training agents inside of scalable world models*, Sep 2025 — [arXiv:2509.24527](https://arxiv.org/abs/2509.24527)

---

## 19. [core] HANDOFF

This appendix changes no interface, so there is no updated `ATLAS_INTERFACES.md`. Two blocks only.

### Appendix C files

```
appendix_c/README.md                     where to unzip it, and every command, in order
appendix_c/gen_toolcall_data.py          seeded generator: 4 disjoint splits, assertion included
appendix_c/score_toolcalls.py            four-outcome scorer; uses evals/stats.py where available
appendix_c/_stats.py                     standalone Wilson/MDE, for the notebook only
appendix_c/check_stats_parity.py         asserts _stats.py agrees with evals/stats.py
appendix_c/eval_toolcalls.py             sweep harness (Tier F fixtures / Tier A OllamaHTTPClient)
appendix_c/skill_cost.py                 prints the per-level skill costs quoted in §6.12
appendix_c/finetune_lora.ipynb           LoRA notebook; free GPU, Colab or Kaggle, resumable
appendix_c/apo/routing_set.py            seeded labelled routing set, dev/holdout split
appendix_c/apo/optimize_router.py        prompt-optimization loop over atlas_router.v1
appendix_c/fixtures/toolcalls_before.json          Tier F fixtures for the harness
appendix_c/fixtures/router_candidates.json         candidate prompts (Tier F)
appendix_c/fixtures/router_drafts.json             scripted router drafts, scenario 1
appendix_c/fixtures/router_drafts_scenario2.json   scripted router drafts, scenario 2
appendix_c/data/toolcalls_{train,dev,test_seen,test_unseen}.jsonl   generated from the seed
tests/hidden/test_phasec_grpo.py         Assignment 1 (7 tests; collected by make grade PHASE=c)
tests/hidden/test_phasec_skills.py       Assignment 2 (8 tests)
```

Distributed as `atlas_appendix_c.zip`. Nothing under `atlas/` is modified.

### VERSIONS.md delta rows

| fact | value | source URL | checked-on |
|---|---|---|---|
| Free-tier notebook GPU type, session length, idle timeout | Not published; Google states limits, idle timeouts, max VM lifetime and GPU types all vary over time | https://research.google.com/colaboratory/faq.html | 2026-09-15 |
| How to learn the GPU you were actually given | Run `!nvidia-smi` in the first cell of every session and size the run to the result | https://research.google.com/colaboratory/faq.html | 2026-09-15 |
| Base model for the Appendix C fine-tune | Qwen/Qwen3-0.6B (any 0.5–1.5B instruction-capable open model works; the choice is not load-bearing) | https://huggingface.co/Qwen/Qwen3-0.6B | 2026-09-15 |
| transformers (PyPI) latest | 5.17.0 | https://pypistats.org/packages/transformers | 2026-09-15 |
| peft (PyPI) latest | 0.19.1 | https://pypistats.org/packages/peft | 2026-09-15 |
| trl (PyPI) latest | 1.12.0 (bit-identical duplicate of 1.11.0; next feature release 1.13.0) | https://github.com/huggingface/trl/releases/tag/v1.12.0 | 2026-09-15 |
| transformers/peft pinning hazard | peft can break against a new transformers major; pin both in the notebook's first cell | https://github.com/huggingface/peft/issues/2754 | 2026-09-15 |
| τ-bench original board status | Frozen; the repository directs new work to successor benchmarks | https://github.com/sierra-research/tau2-bench | 2026-09-15 |
| GEPA reference implementation / DSPy integration | Available as `dspy.GEPA`; algorithm paper arXiv:2507.19457 | https://dspy.ai/api/optimizers/GEPA/overview/ | 2026-09-15 |
| METR time-horizon paper revision | v4, 10 Jul 2026 | https://arxiv.org/abs/2503.14499 | 2026-09-15 |
| TRL flag for assistant-only loss on a `messages` dataset | `assistant_only_loss=True`; needs a chat template with `{% generation %}` markers (TRL patches known families) | https://huggingface.co/docs/trl/en/sft_trainer | 2026-09-15 |
| TRL flag for prompt-completion datasets | `completion_only_loss` (default True for that format); the appendix notebook uses this route | https://huggingface.co/docs/trl/en/sft_trainer | 2026-09-15 |
| Known TRL hazard | `assistant_only_loss=True` is silently ignored when `use_liger_kernel=True` | https://github.com/huggingface/trl/issues/3781 | 2026-09-15 |
| Kaggle notebooks as the Colab alternative | Durable session path `/kaggle/working` (~20 GB, auto-saved); 12 h execution time per CPU/GPU session | https://www.kaggle.com/docs/notebooks | 2026-09-15 |
| Kaggle weekly GPU quota | Stated as 30 h per week, "or sometimes higher depending on demand and resources"; resets weekly | https://www.kaggle.com/docs/efficient-gpu-usage | 2026-09-15 |
| Appendix C cost | $0.00 — free notebook tier, local Ollama, no paid API | — | 2026-09-15 |

*Every row above is a current-state fact and will move. Re-verify before relying on any of them; the prose in this appendix deliberately contains none of these values.*
