"""Seeded synthetic tool-calling data for the Appendix C fine-tune.

WHAT THIS DATA IS: templated requests over Atlas's real tool names, each paired
with the tool call a correct agent would emit. Every template carries at least
one slot, and the slot vocabularies are PARTITIONED: the training split draws
from one half, every evaluation split from the other. So no request string can
appear in two splits, and the generator asserts it.

FOUR FILES, because they support different claims:

    toolcalls_train.jsonl          train templates, train vocabulary
    toolcalls_dev.jsonl            train templates, eval vocabulary  (sanity)
    toolcalls_test_seen.jsonl      train templates, eval vocabulary  (format)
    toolcalls_test_unseen.jsonl    HELD-OUT templates, eval vocabulary (phrasing)

`test_seen` answers "did it learn the output format and the tool vocabulary?"
`test_unseen` answers "does that survive a phrasing it never saw?" The second
number is the one that says anything about tool use; the first is mostly a
memorisation check, and reporting only the first is the mistake this file
exists to prevent.

WHAT IT IS NOT: real user traffic. No typos, no ambiguity the templates did not
put there, no multi-step episodes, no tool errors, and no recovery. The slot
space is small, so the generator PRINTS the per-tool distribution rather than
letting you discover the imbalance after training.

Deterministic for a fixed seed: same seed, same files, byte for byte.

Run:  python3 appendix_c/gen_toolcall_data.py        (from the snapshot root)
"""
from __future__ import annotations

import argparse
import json
import random
from collections import Counter
from pathlib import Path
from typing import Callable

SEED_DEFAULT = 7

# Atlas tool names and argument names, exactly as `build_default_registry`
# registers them (atlas/tools/{calculator,sql,retrieve,clock,files,websearch}.py).
TOOLS: dict[str, tuple[str, ...]] = {
    "calculate": ("expression", "precision"),
    "query_db": ("sql",),
    "retrieve_documents": ("query", "k"),
    "current_time": ("timezone_name",),
    "read_file": ("path",),
    "list_files": ("path",),
    "write_file": ("path", "content"),
    "search_web": ("query", "k"),
    "none": (),
}

# Partitioned vocabularies. A TRAIN value never appears in an evaluation split.
VOCAB: dict[str, dict[str, tuple[str, ...]]] = {
    "region": {
        "train": ("west", "east", "north", "south", "midlands", "highland",
                  "lowland", "seaboard", "inland", "peninsula", "delta", "plateau"),
        "eval": ("central", "coastal", "northwest", "southeast", "lakeside",
                 "riverside", "uplands", "borders", "harbour", "moorland"),
    },
    "product": {
        "train": ("S400", "S500", "T100", "T200", "T300", "S600",
                  "S700", "T400", "T500", "S800", "T600", "S900"),
        "eval": ("U300", "U900", "V110", "V220", "W450", "W470",
                 "X120", "X360", "Y150", "Y700"),
    },
    "topic": {
        "train": ("warranty policy", "onboarding checklist", "error code E41",
                  "expenses policy", "escalation procedure", "travel policy",
                  "shipping policy", "returns policy", "error code E12",
                  "induction checklist", "billing procedure", "holiday policy"),
        "eval": ("refund policy", "security handbook", "error code E77",
                 "handover procedure", "supplier policy", "returns checklist",
                 "incident runbook", "training policy", "payroll checklist",
                 "access procedure"),
    },
    "file": {
        "train": ("notes.md", "summary.md", "handover.md", "checklist.md",
                  "agenda.md", "minutes.md", "report.md", "tasks.md",
                  "status.md", "actions.md", "queries.md", "issues.md"),
        "eval": ("review.md", "brief.md", "digest.md", "plan.md", "log.md",
                 "memo.md", "recap.md", "outline.md", "draft.md", "index.md"),
    },
    "folder": {
        "train": (".", "notes", "reports", "inbox", "working", "shared",
                  "tasks", "status", "queries", "issues", "actions", "team"),
        "eval": ("archive", "drafts", "exports", "scratch", "reviews",
                 "handovers", "minutes", "briefs", "logs", "plans"),
    },
    "zone": {
        "train": ("Europe/London", "America/Toronto", "Asia/Tokyo",
                  "Europe/Berlin", "America/Chicago", "Europe/Madrid",
                  "Europe/Paris", "America/Mexico_City", "Asia/Shanghai",
                  "Europe/Rome", "America/Sao_Paulo", "Asia/Dubai"),
        "eval": ("Australia/Sydney", "America/Denver", "Asia/Singapore",
                 "Europe/Lisbon", "America/Bogota", "Asia/Seoul",
                 "Europe/Oslo", "Africa/Nairobi", "Asia/Kolkata",
                 "Pacific/Auckland"),
    },
    "name": {
        "train": ("Priya", "Marcus", "Ines", "Tomas", "Wei", "Amara",
                  "Jonas", "Leila", "Sofia", "Andre", "Hana", "Petra"),
        "eval": ("Noor", "Diego", "Freya", "Kenji", "Lucia", "Omar",
                 "Sanna", "Rafa", "Mei", "Yusuf"),
    },
}

# Number ranges are partitioned too, so no arithmetic request repeats.
NUMBERS = {"train": (2, 59), "eval": (60, 99)}

Builder = Callable[[dict[str, object]], dict[str, object]]

SEEN_TEMPLATES: list[tuple[str, str, Builder]] = [
    ("what is {a} times {b}", "calculate",
     lambda s: {"expression": f"{s['a']}*{s['b']}", "precision": 2}),
    ("add {a} and {b} for me", "calculate",
     lambda s: {"expression": f"{s['a']}+{s['b']}", "precision": 2}),
    ("how many shipments went to the {region} region", "query_db",
     lambda s: {"sql": f"SELECT COUNT(*) FROM shipments WHERE region = '{s['region']}'"}),
    ("total units shipped for {product}", "query_db",
     lambda s: {"sql": f"SELECT SUM(units) FROM shipments WHERE product = '{s['product']}'"}),
    ("what does the {topic} say about approvals", "retrieve_documents",
     lambda s: {"query": s["topic"], "k": 5}),
    ("find the section on the {topic}", "retrieve_documents",
     lambda s: {"query": s["topic"], "k": 5}),
    ("what time is it in {zone}", "current_time",
     lambda s: {"timezone_name": s["zone"]}),
    ("what is today's date in {zone}", "current_time",
     lambda s: {"timezone_name": s["zone"]}),
    ("show me {file}", "read_file", lambda s: {"path": s["file"]}),
    ("open {file} and tell me what is in it", "read_file",
     lambda s: {"path": s["file"]}),
    ("what files are in the {folder} directory", "list_files",
     lambda s: {"path": s["folder"]}),
    ("save a note called {file} saying to follow the {topic}", "write_file",
     lambda s: {"path": s["file"], "content": f"follow the {s['topic']}"}),
    ("look up recent news about {product}", "search_web",
     lambda s: {"query": f"{s['product']} news", "k": 5}),
    ("hello, this is {name}, what can you do", "none", lambda s: {}),
    ("thanks {name}, that is all for now", "none", lambda s: {}),
]

# Never seen in training. Same tools, different phrasing -- the only split that
# can support a claim about generalisation rather than memorisation.
UNSEEN_TEMPLATES: list[tuple[str, str, Builder]] = [
    ("could you work out {a} multiplied by {b} please", "calculate",
     lambda s: {"expression": f"{s['a']}*{s['b']}", "precision": 2}),
    ("count the deliveries recorded for the {region} region", "query_db",
     lambda s: {"sql": f"SELECT COUNT(*) FROM shipments WHERE region = '{s['region']}'"}),
    ("pull up whatever we have written about the {topic}", "retrieve_documents",
     lambda s: {"query": s["topic"], "k": 5}),
    ("put a file at {file} recording that we follow the {topic}", "write_file",
     lambda s: {"path": s["file"], "content": f"follow the {s['topic']}"}),
    ("nothing else for today, {name}", "none", lambda s: {}),
]


def _slots(rng: random.Random, half: str) -> dict[str, object]:
    low, high = NUMBERS[half]
    slots: dict[str, object] = {"a": rng.randint(low, high), "b": rng.randint(low, high)}
    for key, halves in VOCAB.items():
        slots[key] = rng.choice(halves[half])
    return slots


def generate_split(
    templates: list[tuple[str, str, Builder]],
    *,
    half: str,
    per_template: int,
    rng: random.Random,
    seen: set[str],
    prefix: str,
    tries: int = 400,
) -> list[dict]:
    """Draw up to `per_template` DISTINCT requests per template.

    Rejection sampling against a global `seen` set, with a bounded number of
    tries: some templates have a slot space only ten wide, so a generator that
    insisted on its target count would loop forever. Taking what the space can
    supply, and printing the shortfall, is the honest behaviour -- a synthetic
    corpus is always smaller than it looks.
    """
    rows: list[dict] = []
    index = 0
    for template, tool, build in templates:
        made = 0
        for _ in range(tries):
            if made >= per_template:
                break
            slots = _slots(rng, half)
            request = template.format(**slots)
            if request in seen:
                continue
            seen.add(request)
            rows.append({"id": f"{prefix}-{index:04d}", "request": request,
                         "tool": tool, "arguments": build(slots)})
            index += 1
            made += 1
    return rows


def describe(name: str, rows: list[dict]) -> str:
    counts = Counter(r["tool"] for r in rows)
    unique = len({r["request"] for r in rows})
    tools = " ".join(f"{k}={v}" for k, v in sorted(counts.items()))
    return f"{name:<40} n={len(rows):<4} unique={unique:<4} {tools}"


def main() -> None:
    ap = argparse.ArgumentParser(description="Generate the Appendix C tool-call splits.")
    ap.add_argument("--seed", type=int, default=SEED_DEFAULT)
    ap.add_argument("--out", type=Path, default=Path("appendix_c/data"))
    ap.add_argument("--train-per-template", type=int, default=45)
    ap.add_argument("--dev-per-template", type=int, default=3)
    ap.add_argument("--test-per-template", type=int, default=6)
    args = ap.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)

    rng = random.Random(args.seed)
    seen: set[str] = set()
    splits = {
        "train": generate_split(SEEN_TEMPLATES, half="train",
                                per_template=args.train_per_template,
                                rng=rng, seen=seen, prefix="train"),
        "dev": generate_split(SEEN_TEMPLATES, half="eval",
                              per_template=args.dev_per_template,
                              rng=rng, seen=seen, prefix="dev"),
        "test_seen": generate_split(SEEN_TEMPLATES, half="eval",
                                    per_template=args.test_per_template,
                                    rng=rng, seen=seen, prefix="tseen"),
        "test_unseen": generate_split(UNSEEN_TEMPLATES, half="eval",
                                      per_template=args.test_per_template,
                                      rng=rng, seen=seen, prefix="tuns"),
    }

    # The assertion is the point of this rewrite: the first draft of this file
    # drew every split from one stream and shipped 173 of 200 test rows whose
    # request string also appeared in training.
    requests = {name: {r["request"] for r in rows} for name, rows in splits.items()}
    for name, rows in splits.items():
        assert len(rows) == len(requests[name]), f"{name} contains duplicate requests"
    for other in ("dev", "test_seen", "test_unseen"):
        overlap = requests["train"] & requests[other]
        assert not overlap, f"train/{other} overlap: {sorted(overlap)[:3]}"

    for name, rows in splits.items():
        path = args.out / f"toolcalls_{name}.jsonl"
        path.write_text("".join(json.dumps(r, sort_keys=True) + "\n" for r in rows))
        print(describe(str(path), rows))
    print("cross-split request overlap: 0 (asserted)")


if __name__ == "__main__":
    main()
