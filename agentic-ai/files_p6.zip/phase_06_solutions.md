# phase_06_solutions.md

Worked answers for Phase 6. Read these after attempting, not instead of.

---

## Cumulative review (§2)

**R1.** The distinction is **who can act on the outcome, and whether the outcome is a fact about the world or a fact about your code.** `execute()` returns rather than raises because a tool failure is information the *agent* can use — retry, try another tool, tell the user — and a traceback is information only a developer can use.

An empty retrieval falls on the **return** side, and decisively. "Nothing in the index matched this question" is a true, common, actionable statement about the corpus. Most of the time it means the corpus does not cover the topic, which is exactly what the user needs to hear. Raising would convert the single most valuable answer a retrieval system can give into a 500.

The colleague's premise is also wrong on its own terms: an empty *index* and an empty *retrieval* are different things. An empty index is a configuration error and could reasonably raise at build time. An empty retrieval over a populated index is a normal Tuesday.

**R2.** It is a check on the **product**, and the reasoning matters more than the verdict. Invariant 22's distinction is between what the agent *produced* — the artefact a user receives — and *how it got there*. A citation is part of the artefact: it is printed, the user reads it, and they act on it. So grading "did it cite the document containing the answer" grades the output. Contrast a path check: "did it call `search_web` before `read_file`", which grades a route and would fail a better route.

If the agent reaches the right conclusion from the wrong document, the check should **fail**, and this is the interesting half. The answer text is right and the artefact is defective, because its provenance does not support it. A user who checks the citation finds the claim is not there and now trusts nothing. Phase 3's §8 was exactly this shape, and §8 of this phase is its inverse. A correctness check alone cannot see either.

**R3.** The shared principle: **a model may produce evidence; only code may draw the conclusion the system acts on.** Phase 4's counting rule says count the branches a model's output can reach, because those are branches you own. The mechanical critic's verdict is computed from findings, because a verdict is a conclusion.

The field a model must not be given on a retrieval-answer schema is anything expressing **sufficiency or confidence** — `grounded`, `sufficient`, `confidence`, `accept`. §6.19 forbids all four, and `GroundedDraft` has exactly two fields so the prohibition is enforced by the type rather than requested in prose.

**R4.** Two formulations a fluent non-answer passes:

- `contains "months"` — passed by *"the warranty period is measured in months and varies by product"*, which answers nothing.
- `contains "12"` — passed by *"see clause 12 for the applicable term"*, and also by any answer containing a date, a page number or a quantity of anything.

One it would not: `contains "12 months"` **as a normalised span**, with whitespace and case folded and punctuation *not* stripped. It requires the number adjacent to its unit, which is the smallest fragment that actually asserts the answer. This is why `normalise_for_match` folds whitespace and case and deliberately does neither of the two things that would loosen it.

Better still for a real grader: require the span *and* a resolvable citation to the document that contains it, so a right answer from the wrong source fails (see R2).

**R5.** The predictable answer is **the extraction quality flags** — a chunk knowing nothing about the page it came from. That is invariant 42, and F-06-03 is the defect: the flag propagated correctly through six record types and reached the *prompt* at none of them.

Full credit also for predicting `page` or `heading` being dropped somewhere between chunk and citation, which is the same shape.

---

## Concept checks

**6.1 — 40-page handbook, twice-yearly changes, 30 employees, citations.**
The two deciding axes are **attribution** and **freshness**; volume decides nothing here because 30 employees generate too little traffic for the cost crossover to matter.

The answer is **whole-document prompting**, not retrieval. Forty pages is roughly 20,000 tokens, an order of magnitude inside the ~200,000-token line. You get perfect recall with no ingestion pipeline, no chunker to tune and no index to refresh — you re-upload the file twice a year. Citations still need work: ask the model to quote the clause it relies on, and verify the quote appears in the document, which is a substring check.

Fine-tuning fails both axes: no attribution, and a model that states last year's policy after the update.

The trap is that "with citations" sounds like it forces retrieval. It does not. Retrieval is one way to get attribution; quoting from a document in the prompt is another, and it is cheaper below the token line.

**6.3 — cosine arithmetic.**
$a = [0.6, 0.8]$, $q = [3.0, 4.0]$. Dot product $= 1.8 + 3.2 = 5.0$. $\|a\| = 1.0$, $\|q\| = 5.0$. So $\cos\theta = 5.0 / 5.0 = 1.0$: **identical direction**, maximum similarity. The vectors differ by a factor of 5 in magnitude and cosine does not care, which is scale invariance doing its job.

$q' = [-0.8, 0.6]$. Dot product $= -0.48 + 0.48 = 0$. Both are unit length, so $\cos\theta = 0$: **perpendicular, unrelated**.

Before normalisation, Euclidean distance ranks $q'$ higher (closer): $\|a - q'\| = \|[1.4, 0.2]\| \approx 1.41$, while $\|a - q\| = \|[-2.4, -3.2]\| = 4.0$. So unnormalised Euclidean distance ranks the *unrelated* vector above the *identical-direction* one, purely because of magnitude. That is the argument for cosine in two lines of arithmetic.

**6.5 — switching 768 → 1024 dimensions on 5,000 chunks.**

- **Stored vectors: yes.** Every one. They are positions on a map that no longer exists; there is no conversion.
- **Chunk texts: no.** Text is upstream of embedding. This is why `chunk_id` and `content_hash` survive an embedder change and the vectors do not.
- **BM25 index: no.** It never touched the embedder. This is a quietly valuable property: your sparse retriever keeps working through a re-index, so the system degrades to sparse-only rather than to nothing.
- **Labelled eval set: no.** D-29 — labels are document ids and answer spans, both properties of the corpus. This is the whole point of D-29 and this question is the test of it.
- **Abstention threshold: yes, if you use one.** Cosine values are not calibrated across models (§6.3), so a floor tuned on the old model is meaningless on the new one. Atlas's default mechanism is threshold-free precisely so this box stays unticked.

**6.6 — predicting which retriever finds each chunk.**

- (a) *"what does error 0x33 mean"* — **BM25**, comfortably. `0x33` is a rare exact string; the dense model has no useful position for it.
- (b) *"how often should the source lamp be replaced"* — **dense**. The document says "rated for 2000 operating hours" and never the word "often" or "replaced… how often". Only semantic similarity bridges that.
- (c) *"which SKUs are excluded from the 24-month term"* — **both, badly.** `24` and `SKU` give BM25 something; "excluded" is topically close to the exclusions section for the dense side. But this query turns on **negation**, so a dense retriever will happily return the chunk listing what *is* covered. This is the one to be nervous about.
- (d) *"connector mating cycle rating"* — **both, easily.** The document says "rated for 100 mating cycles", so the terms match exactly and the topic matches too.

The one to be most nervous about even with both is **(c)**, and the reason is that hybrid search fixes *coverage*, not *polarity*. Two retrievers that both ignore negation are two retrievers that both ignore negation.

**6.8 — why "sentences that don't parse" fails.**
Two reasons, both visible in the measured output.

First, **the fused sentences parse fine.** *"The S400 benchtop spectrometer detector recalibration after 6 months of continuous"* is a well-formed noun phrase, and the full fused line reads as grammatical English. That is precisely what makes the defect dangerous: it was assembled from two grammatical fragments, so the seam is invisible to grammar.

Second, **the undamaged text does not parse either.** Extraction produces line-broken fragments everywhere — *"reference drifts beyond 0.4 percent. Field"* is the tail of a correctly-extracted column. A parser would flag most lines of most documents, so the signal has no discriminating power. This is the same finding as §6.9's measurement, arriving from a different direction: a detector must separate the classes, and both of these fail on the *undamaged* class rather than the damaged one.

**6.9 — which repairs must record that they acted.**

- **NFKC normalisation: no.** It restores information — a non-breaking space *is* a space, a ligature codepoint *is* its components. Nothing is decided and nothing can be wrong.
- **De-hyphenating a word broken across lines: yes.** This is a judgement. `co-operate` broken across lines and `co-\noperate` as an intentional hyphen are indistinguishable from the text, so the repair can be wrong, and a reader deserves to know it happened.
- **Dropping a page that extracted empty: yes**, and loudly — it is `empty_extraction`, a blocking flag. The page may be an image with content in it, so dropping it silently means the document is missing material nobody knows about.
- **Lowercasing for the BM25 index: no.** It is not a repair to the document at all; it is a transformation inside a derived index, and the chunk text a citation quotes is untouched. The distinction worth taking away: only changes to the *quotable text* need a flag.

**6.11 — adding an `effective_date` filter six months in.**

- **Extraction: yes**, if the date is in the document body and you never captured it. This is the painful case, and it is why "metadata is a first-class decision" is a section rather than a sentence.
- **Chunking: yes**, because chunks carry metadata and you must re-attach it.
- **Embedding: no**, if the chunk *text* is unchanged. The content hash matches and `refresh` reuses the vector. Metadata is not embedded.
- **BM25 index: no**, same reason.
- **Labelled eval set: no**, unless you want to add queries that exercise the filter — and you should.

The content-hash refresh lets you skip **embedding and the BM25 rebuild**, which are the two expensive steps. That is the payoff for hashing text rather than ids, and it turns a "we can't add that filter" conversation into an afternoon.

**6.13 — IDF for a term in 490 of 500 chunks.**
Smoothed: $\ln(1 + (500-490+0.5)/(490+0.5)) = \ln(1 + 10.5/490.5) = \ln(1.0214) \approx \mathbf{0.0212}$. Small and positive: the term is nearly useless and contributes nearly nothing.

Unsmoothed, $\ln((N-n+0.5)/(n+0.5)) = \ln(0.0214) \approx \mathbf{-3.84}$. **Strongly negative.**

For the query *"the warranty terms"*, if "the" and "terms" are both ubiquitous, their contributions are large negative numbers. A chunk containing them scores *lower* than a chunk that does not — so BM25 ranks the chunks that ignore most of the query above the chunks that match it, and the ranking is roughly inverted. The failure is loud enough to notice in a demo and subtle enough to survive a code review, which is why the `1 +` gets a comment.

**6.17 — recall@5 = 0.91, span recall@5 = 0.62, answers frequently wrong.**
Fix **retrieval**, specifically the **chunker**, not the ranker and not the prompt.

The diagnosis: recall 0.91 says the right *document* reaches the context window nine times in ten. Span recall 0.62 says the right *sentence* arrives only six times in ten. The 0.29 gap is 29% of queries where the generator is handed the correct document and not the passage that answers the question — so it either guesses from surrounding context or abstains. That is `found_document_but_not_answer`, and it is a chunking failure by definition: the ranking found the document, and the chunk boundaries lost the answer.

Try **structure-aware** chunking first. It is the cheapest change, it needs no model calls, and it directly attacks the cause — answers get separated from their qualifiers when a boundary lands mid-section, and headings are the author's own statement of where sections end. If the documents have no headings, try smaller chunks with more overlap next (overlap exists exactly to buy back what boundaries lose), and semantic chunking after that.

What *not* to do: raise $k$. It would lift span recall by brute force while raising cost and diluting the prompt, and it would leave the boundary problem in place for every future query.

**6.20 — which layer fixes each.**

- (a) The answer cites extract 4, which is about a different product → **generation**. The evidence was there and was misused. Fix the prompt, and add a check that cited extracts share a product identifier with the answer.
- (b) A discount rate appearing in no extract → **generation**, and `unsupported_numbers` already catches it. This is the cheap win.
- (c) A correct quotation of a chunk whose numbers came from the wrong table row → **ingestion**. Nothing downstream can detect it; the fix is row-level table extraction (Assignment 2). This is §8's shape with a table instead of a column.
- (d) Confident answers about a document not in the corpus → **the abstention layer**, and F-06-05 says the current mechanism will miss it whenever the question shares vocabulary with the corpus. This one is open, and honestly so.

**8 — after fix 4, which containment fixes to keep.**
**Keep all three**, and the reason is that fix 4 fixed *one document*.

Fix 1 (blocking flags reach the prompt) and fix 2 (the caveat names the defect) are general mechanisms for a general class. The next two-column PDF someone drops in the folder is not covered by having re-extracted this one. Deleting them would mean rebuilding them from a second incident.

Fix 3 (withhold a claim resting only on blocking text) is the one to think hardest about, and the answer is still keep. It is the only mechanism preventing the *published* failure, and after fix 4 it costs nothing: with no blocking documents, it never fires. A guard with zero cost on the happy path and a high cost when absent is exactly the trade Phase 5's gate arithmetic recommends.

For the system to have **noticed** the contradiction — `6 months` and `12 months` both attached to the S400 — you would need a **contradiction check across retrieved extracts**: extract (subject, attribute, value) triples from the top-$k$, and flag when one subject carries two different values for one attribute. Cheap versions exist (regex for a product identifier near a quantity-plus-unit) and catch this case, because both numbers are in the *same chunk*. What it costs: a lot of false positives on any corpus where two documents legitimately state different values for different conditions — "24 months when registered, 12 months otherwise" is a contradiction to a triple extractor and correct to a reader. That is why the phase does not ship it, and why the honest fix is upstream.

---

## Quiz

**1. Scale invariance as virtue and as bug.**
The virtue (§6.3): cosine ignores magnitude, so a long chunk mentioning a term eight times and a short chunk mentioning it once — pointing in nearly the same direction — score as similar. Length tracks how much text there is; direction tracks what it is about. Euclidean distance conflates the two and lets long documents dominate.

The bug (§6.11): the same indifference to magnitude means a 24-character chunk containing only `# Warranty policy (2024)` points in a *purer* direction toward a warranty query than a 90-character chunk that is 30% about warranties and contains the answer. Measured: the title ranked **first**. Cosine is behaving exactly as specified.

What this says about "choose the right metric": **a metric's virtues and its consequences are the same property seen from two sides, and you cannot select the virtue alone.** The engineering response is not to abandon cosine or to add a length penalty — that would reintroduce Euclidean distance's flaw — but to stop putting content-free text in the index. **Fix the inputs, not the metric.** The general lesson: once you understand *why* a metric is right, you know exactly which pathological input it will reward, and you can go and look for that input.

**2. Recall@10 = 0.97 and users unhappy; two numbers.**

Compute **span recall@10** and **the corpus size (with the chunk count)**.

*Span recall* splits the two candidate explanations. If span recall is also ~0.97, retrieval is genuinely delivering the answer sentence and the fault is in generation — the prompt, the citation discipline, or the model ignoring provided evidence. If span recall is much lower, retrieval delivers the right document without the right passage, and the fault is chunking.

*Corpus size* tells you whether 0.97 means anything at all. If the index has 200 chunks, $k=10$ returns 5% of the corpus and 0.97 is a real number. If it has 40 chunks, $k=10$ returns a quarter of the corpus and 0.97 is arithmetic — §6.14's saturation, and the correct next move is to re-measure at $k=1$ and $k=3$ before believing anything.

The four outcome pairs:

| span recall | corpus | Conclusion |
|---|---|---|
| high | large | Retrieval is fine. Fix generation. |
| low | large | Chunking. Try structure-aware first. |
| high | small | You have measured nothing. Re-run at $k=1$. |
| low | small | You have measured nothing *and* chunking looks bad. Re-run at $k=1$, then fix chunking. |

Bonus credit for asking whether the corpus is uniform in quality, since a clean/messy split can hide a 25-point gap inside a 0.97 average.

**3. Two dense retrievers instead of dense + BM25.**

*Their case, at its strongest.* Fusion rewards **decorrelated errors**, not any particular mechanism. Two embedding models trained on different data with different objectives and different tokenisers do make different mistakes: one may handle domain jargon better, another negation, another long chunks. Both are semantic, so both bridge synonyms — meaning the fused system inherits synonym handling on *both* arms, where dense+BM25 has it on only one. And ensembling models of the same type is standard practice everywhere else in ML for exactly this reason.

*The argument against.* Their errors are decorrelated in *degree* and correlated in *kind*, because both share the mechanism's structural limits. Neither can have IDF: an embedding is computed from one text at a time, so **corpus blindness is a property of the interface, not the weights**, and two dense models are both blind. Both suffer on rare exact strings, for the same subword-tokenisation reason. So you have bought a second opinion from a second expert with the same blind spots — §6.16's "echo" problem, one layer up. And you have paid twice: two embedding passes at index time, two vector stores, two dimensions to manage, against BM25's forty lines and no model.

*The query type that decides it.* A **rare exact identifier** — `0x33`, `INV-2026-0417`, `M12-A`. BM25 matches it exactly and instantly; both dense models place it near other short alphanumeric strings. If your users search by identifier — and in an operations assistant they do constantly — the dense-plus-dense system fails a whole query class that a dense-plus-sparse system handles perfectly. Run both configurations on a labelled set stratified by query type and the identifier stratum settles it.

**4. A useless detector, kept, and invariant 41.**

They are reconciled by distinguishing **a mechanism** from **a measurement**. Invariant 41 says a *mechanism* is wired or not shipped — where a mechanism is something that changes what the system does. `interleave_suspicion` is not wired to any decision: no flag derives from it, no branch reads it, no threshold consumes it. It populates one float on a report. It is therefore a *measurement*, and measurements are exactly what D-21 asks for when a judgement cannot be trusted: record the signal as data, let code decide, and here code decides nothing on it.

Keeping it costs one field and one function call, and buys two things. It documents that the approach was tried and measured, so the next engineer does not rediscover it — and it *has* a regression test asserting the negative result, so if somebody improves the detector, the test fails and forces a re-measurement rather than a silent promotion back to a decision.

*When deleting would have been right:* if the number were **never read by anything** — not printed in a report, not on a record, not asserted by a test. An unread field is not a measurement, it is dead weight, and invariant 41 applies with full force. The dividing line is whether a human or a test ever sees the value. A second case: if computing it were expensive. A free useless number is worth keeping as evidence; a useless number costing a model call per document is not.

**5. Catching §8 without fixing the extraction.**

The check: **cross-extract contradiction detection on quantities.** Extract every (subject, quantity, unit) triple from the top-$k$ extracts — a product identifier within some window of a number-plus-unit — and flag when one subject carries two different values for one unit. §8's chunk contains both `S400 … 6 months` and `… 12 months of operation` within four lines, so the flag fires on the retrieval, before generation. The system then withholds and reports the conflict, which is the correct outcome: the evidence is genuinely contradictory.

*What it costs.* Three things, and the third is why the phase does not ship it.

Implementation cost is modest — a windowed regex over identifiers and quantity-unit pairs, deterministic, offline.

Precision is poor. Real corpora contain legitimate multiple values for one subject under different conditions: *"24 months when registered within 30 days, 12 months otherwise"* is one sentence, two values, and entirely correct. A triple extractor sees a contradiction. So does *"stored above 30 degrees, halve the interval."* Northwind's own warranty policy would trip it. Every false positive is a withheld answer to a good question, and §6.15 argued that unexplained refusals are worse than flagged answers.

And it treats a symptom. The chunk is still corrupted; the check just stops one *kind* of corruption from being published. A two-column page whose fusion produces a single plausible value with no contradiction to detect — which is the more common case — passes cleanly.

So the phase ships the containment fixes (which are general and precise) and directs the real effort upstream. The honest summary: **the check is worth building for a corpus of tables and specifications where quantities are dense and conditions are rare, and it is a liability on a corpus of policy prose.** Which corpus you have is a fact you should establish before writing it.

**6. A fused-score threshold of 0.4 instead of the sparse-support check.**

*Two reasons it is worse.*

It is **not comparable across queries.** §6.14: min-max normalisation is computed per result set, so 0.4 means "40% of the way between this query's worst and best hit" — a quantity with no fixed meaning. A query where everything scored badly produces a top fused score near 1.0 by construction. So the threshold does not measure what it appears to, and RRF scores are worse still: they are sums of reciprocal ranks bounded by the number of retrievers, so the top hit's score barely varies with relevance at all.

It **needs recalibration on every change** — every embedding model, every corpus, every fusion method, every $k$. §6.3's misconception with consequences. The sparse-support check needs none, because "no chunk shares a scoring term with the query" is a fact about the corpus and the query, invariant under all of those.

*One thing it would catch that the current mechanism cannot.* A query that shares vocabulary with the corpus but matches nothing well — which is **exactly F-06-05's four missed questions**. *"What is the sodium content of the calibration reference cell"* contains `calibration` and `reference`, so BM25 returns hits and the lexical check passes; but every hit would score weakly against a well-calibrated floor.

Which is the right conclusion to draw: the two mechanisms fail differently, so the answer is not "one or the other" but **both, with the threshold calibrated on Tier A against the unanswerable list and the sparse check retained as the threshold-free floor.** That is `docs/RESULTS.md` rows 10–11, and it is the phase's largest piece of unfinished business.

**7. Why leaf tests miss composition defects.**

Leaf tests miss this class **structurally**, for three compounding reasons.

*A leaf test supplies its own inputs.* `test_chunk_document_semantic` passes `embed_one=` because the test author read the signature. The defect is that `build_index` does *not* pass it — which is a fact about a caller the leaf test never invokes. The leaf module is correct; correctness of a module says nothing about whether anyone can reach it.

*Leaf tests instantiate records directly.* `test_store_filter_runs_before_scoring` builds a `VectorStore` and calls `search` with a predicate. It passes. It cannot see that `DocumentIndex.search` hands the predicate to that store and hands BM25 something else, because it never constructs a `DocumentIndex`. Hand-built records bypass exactly the code that assembles them.

*And composition-layer bugs are the ones that look like nothing.* An unforwarded keyword argument, a filter applied at the wrong moment, a field widened to `Any`. None changes a leaf's behaviour, none raises in a leaf test, and two of the three produced *plausible output* — `n_sparse=0` looks like "nothing matched", and `SKIPPED` looks like an expected limitation.

*The testing rule that catches all three:* **for every closed set, every counter and every refusal condition, write one test that reaches it through the public entry point callers actually use — not through the module that defines it.** Concretely: enumerate `ChunkStrategy` and call `build_index` once per member (catches F-06-06). Assert a filtered search returns a hit from *each* retriever, with a fixture where the answer is genuinely outside the unfiltered top-$k$ (catches F-06-07). Round-trip every record type through `model_validate(model_dump())` **and then use the result** (catches the `Any` regression — the original test dumped and compared fields but never searched the restored index).

The generalisation, which is invariant 46: **a closed set, a wired mechanism and a reachable condition are three different things.** Leaf tests establish the first. Only tests through the composition establish the third.

---

## Assignment 1 — `atlas/rag/quality.py`

### The policy table (the unaided core)

Work flag by flag, with the sentence the assignment asks for.

| Flag | "A document with this flag should/should not be quotable, because…" | Policy | Under `strict` |
|---|---|---|---|
| *(none)* | should be — nothing is wrong with it | `index` | `index` |
| `broken_ligatures` | should be, with a caveat — some *words* are unreadable, but every readable sentence says what the document says | `index_flagged` | `index_flagged` |
| `boilerplate_repetition` | should be, with a caveat — text was *removed* by a judgement that could be wrong, but nothing was fabricated | `index_flagged` | `index_flagged` |
| `ocr_low_confidence` | should be, with a caveat — characters may be wrong, so quote loosely; but the sentence structure is the document's | `index_flagged` | `index_flagged` |
| `flattened_table` | should be, with a caveat — every *value* is genuinely in the document; what is lost is which label it belongs to | `index_flagged` | `index_flagged` |
| `suspect_reading_order` | should be, with a caveat — we could not check, which is not the same as having found a problem | `index_flagged` | `index_flagged` |
| `interleaved_columns` | **should not be** — the text contains sentences the document does not, so a quote can be a fabrication | `index_flagged` | `quarantine` |
| `empty_extraction` | **should not be**, and there is nothing to quote anyway | `quarantine` | `quarantine` |

Two things fall out of the table rather than being decided separately.

**`strict` changes exactly one row.** Only `interleaved_columns` moves, because it is the only flag whose meaning is "this text is not faithful" *and* which leaves text behind to be wrongly quoted. `empty_extraction` was already quarantined; every other flag is a caveat in both modes, because a document with imperfect characters is still a document, and refusing it makes a good question unanswerable for no gain. A `strict` mode that also quarantined OCR'd documents would delete a fifth of a real corpus to avoid a caveat.

**The default is not `quarantine` for blocking flags**, which is D-33 and is the counter-intuitive half. Removal is invisible to the user; a flag is not.

### Reference implementation

```python
"""Per-document indexing policy: the decision §6.9 computes and §6.15 argues about."""

from __future__ import annotations

from typing import Literal, Sequence

from pydantic import BaseModel, Field, computed_field

from atlas.rag.extract import BLOCKING_FLAGS, ExtractedDoc

Policy = Literal["index", "index_flagged", "quarantine"]
POLICIES: tuple[Policy, ...] = ("index", "index_flagged", "quarantine")

# Quarantine regardless of mode: there is no text to quote.
ALWAYS_QUARANTINE: frozenset[str] = frozenset({"empty_extraction"})


class Decision(BaseModel):
    """One document's policy, and the flag that drove it."""

    model_config = {"frozen": True}

    doc_id: str
    policy: Policy
    flags: list[str] = Field(default_factory=list)
    reason: str = ""

    @computed_field  # type: ignore[prop-decorator]
    @property
    def indexable(self) -> bool:
        return self.policy != "quarantine"


def decide(doc: ExtractedDoc, *, strict: bool = False) -> Decision:
    """Which policy applies to `doc`. Pure; the single decision point.

    The order of the branches is the policy table read top to bottom, and the
    `reason` names the flag rather than describing the category -- a reason of
    "quality issues" is a reason nobody can act on (F-06-04's lesson applied
    to a different record).
    """
    flags = list(doc.quality.flags)
    fatal = sorted(set(flags) & ALWAYS_QUARANTINE)
    if fatal:
        return Decision(
            doc_id=doc.doc_id, policy="quarantine", flags=flags,
            reason=f"{fatal[0]}: no text was extracted, so there is nothing to index",
        )
    blocking = sorted(set(flags) & BLOCKING_FLAGS)
    if blocking and strict:
        return Decision(
            doc_id=doc.doc_id, policy="quarantine", flags=flags,
            reason=(
                f"{blocking[0]}: the extracted text contains sentences the "
                "document does not, and strict mode refuses those"
            ),
        )
    if flags:
        lead = blocking[0] if blocking else sorted(flags)[0]
        return Decision(
            doc_id=doc.doc_id, policy="index_flagged", flags=flags,
            reason=f"{lead}: indexed with its flags so a citation carries the caveat",
        )
    return Decision(
        doc_id=doc.doc_id, policy="index", flags=[],
        reason="extraction produced no quality flags",
    )


class QualityReport(BaseModel):
    """The table a human reads BEFORE indexing. §6.7's instruction, automated."""

    decisions: list[Decision] = Field(default_factory=list)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def n_documents(self) -> int:
        return len(self.decisions)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def counts(self) -> dict[str, int]:
        # Every policy appears, including the zeros. A report whose keys depend
        # on the data is a report you cannot diff against yesterday's.
        tally = {policy: 0 for policy in POLICIES}
        for decision in self.decisions:
            tally[decision.policy] += 1
        return tally

    @computed_field  # type: ignore[prop-decorator]
    @property
    def flagged_share(self) -> float:
        if not self.decisions:
            return 0.0
        return round(
            sum(1 for d in self.decisions if d.flags) / len(self.decisions), 4
        )

    @computed_field  # type: ignore[prop-decorator]
    @property
    def indexable_share(self) -> float:
        if not self.decisions:
            return 0.0
        return round(
            sum(1 for d in self.decisions if d.indexable) / len(self.decisions), 4
        )

    @computed_field  # type: ignore[prop-decorator]
    @property
    def quarantined(self) -> list[str]:
        return [d.doc_id for d in self.decisions if not d.indexable]

    def render(self) -> str:
        rows = [
            f"quality: {self.n_documents} documents, "
            f"{self.flagged_share:.0%} flagged, "
            f"{len(self.quarantined)} quarantined"
        ]
        for decision in self.decisions:
            rows.append(f"  {decision.doc_id:34s} {decision.policy:14s} {decision.reason}")
        return "\n".join(rows)


def assess_corpus(
    docs: Sequence[ExtractedDoc], *, strict: bool = False
) -> QualityReport:
    return QualityReport(decisions=[decide(d, strict=strict) for d in docs])


def indexable(
    docs: Sequence[ExtractedDoc], *, strict: bool = False
) -> list[ExtractedDoc]:
    """Filter to indexable documents, preserving order (chunk ids depend on it)."""
    keep = {d.doc_id for d in assess_corpus(docs, strict=strict).decisions if d.indexable}
    return [d for d in docs if d.doc_id in keep]
```

### Why the details are the way they are

**`counts` includes zeros.** A dict whose keys depend on the data cannot be diffed against yesterday's run, so `counts["quarantine"] == 0` must be expressible. This is the same reason invariant 30 wants every `Literal` member reachable.

**`reason` names the flag.** F-06-04's lesson, transplanted: "quality issues" is a reason nobody can act on. Naming `interleaved_columns` tells the reader which page to look at.

**Empty corpus returns 0.0, not a `ZeroDivisionError` and not 1.0.** The hidden test checks this. 1.0 would be defensible arithmetic and terrible reporting: "100% of documents are indexable" on an empty corpus is a green dashboard for a broken pipeline.

**`indexable` preserves input order** rather than returning the decisions' order, because chunk ids are assigned in document order and a citation that changes when the filter changes is not a citation.

### Wiring it in (the step the acceptance criteria imply)

`assess_corpus` should be printed by `make ingest` and called in `build_index` when `strict=True` is requested. Do not make it mandatory: `build_index` indexing everything by default is D-33, and this module makes the *policy* explicit rather than changing it.

---

## Assignment 2 — `atlas/rag/tables.py`

### The header heuristic (the unaided core)

The problem is that three kinds of line look similar: a title, a preamble sentence, and a header row. On the seeded document:

```
CALIBRATION TOLERANCES 2026                                   <- title
Applies to instruments shipped after 2026-01-01. …            <- preamble
SKU / Parameter / Nominal / Tolerance / Interval              <- header (5 lines)
S400 / wavelength accuracy / 0.5 nm / …                       <- data
```

The signal that works, and it is a *structural* one rather than a lexical one: **after the header row of width $w$, the remaining cell lines come in a whole number of groups of $w$.** So do not try to recognise a header. Instead, **hypothesise** a header width and check whether the rest of the document divides by it.

```
for start in candidate start lines:
    for w in 2..8:
        headers = lines[start : start+w]
        body    = lines[start+w :]
        if len(body) % w == 0 and len(body) // w >= 2:
            score this hypothesis
```

Score by two things the alternatives fail: header cells should be **short and non-numeric** (a header is a label), and each *column* of the resulting grid should be **type-consistent** — the `Interval` column is all durations, the `SKU` column all identifiers. A hypothesis that swallows the preamble puts a 60-character sentence in a header cell and destroys column consistency, so it scores worse than the correct one without ever being recognised as a preamble.

**And return `None` when no hypothesis scores well.** That is the part to write first, because it is the part an assistant will omit. Prose has no width $w$ for which the line count divides evenly with type-consistent columns, so prose falls out as `None` for free rather than needing a separate prose detector.

### Reference implementation sketch

```python
_NUMERIC = re.compile(r"^[\s\d.,%+\-/()]*$")


def parse_flattened(text: str, *, max_width: int = 8) -> Table | None:
    """Recover a table from cell-per-line extraction, or None.

    Returns None rather than guessing. A wrong table is worse than no table:
    a value under the wrong heading is §8's failure with a table instead of a
    column, and it retrieves and reads as a fact.
    """
    lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
    best: tuple[float, Table] | None = None
    for start in range(0, min(4, len(lines))):
        for width in range(2, max_width + 1):
            headers = lines[start : start + width]
            body = lines[start + width :]
            if len(headers) < width or not body or len(body) % width:
                continue
            if len(body) // width < 2:
                continue
            if any(_NUMERIC.match(h) or len(h) > 30 for h in headers):
                continue
            rows = [body[i : i + width] for i in range(0, len(body), width)]
            score = _column_consistency(rows) - 0.05 * start
            if best is None or score > best[0]:
                best = (score, Table(headers=headers, rows=rows))
    if best is None or best[0] < 0.5:
        return None
    return best[1]


def _column_consistency(rows: list[list[str]]) -> float:
    """Share of columns whose cells are all numeric-ish or all not."""
    if not rows:
        return 0.0
    consistent = 0
    for column in zip(*rows):
        numeric = [bool(_NUMERIC.match(cell)) for cell in column]
        if all(numeric) or not any(numeric):
            consistent += 1
    return consistent / len(rows[0])
```

`row_text` is where the assignment's whole value sits:

```python
    def row_text(self, index: int) -> str:
        """A row as a self-contained sentence. Headings travel with values."""
        cells = self.rows[index]
        # The FIRST column is the row label and is stated bare; every other
        # cell is stated as "heading value", so a number can never appear
        # without the word that says what kind of number it is.
        head, *rest = zip(self.headers, cells)
        parts = [head[1]] + [f"{name} {value}" for name, value in rest]
        return " | ".join(parts)
```

Which turns row 3 into `T100 | Parameter temperature | Nominal 0.1 C | Tolerance +/- 0.3 C | Interval 6 months`. Now `6 months` cannot be retrieved without `Interval`, and §6.8.2's failure mode — a number with no word saying what it is — is structurally impossible.

`table_chunks` must set `kind="table_row"` (which makes invariant 30 true again for that Literal member) and inherit the document's flags, because §6.8.2's damage class is `flattened_table` and a reader of the row still wants to know the row was reconstructed.

### The measurement

Add the row chunks alongside the prose chunks and report recall@1 on `q23` (*"what is the wavelength accuracy tolerance for the S400"*, gold span `0.2 nm`) and `q24` (*"what is the P900 pressure zero interval"*, gold span `24 months`).

Expect a rise, and expect it to be modest on *recall* and larger on *span recall* — because the flattened chunk already retrieved the right document, so recall@1 was likely already 1.0. The thing that improves is that the retrieved text now contains the value *with its label*, which is what the generator needs. **Report both metrics or you will conclude the change did nothing.** That is §6.17's recall-versus-span-recall gap being useful for the first time on this corpus.

Write the row with tier, seed and date. A structural improvement you did not measure is a structural opinion.
