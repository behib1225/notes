# Phase 6 — Retrieval for Agents I

**Embeddings, Ingesting Messy Documents, Chunking, Hybrid Search, Reranking, Grounded Generation, and Retrieval Evaluation**

---

## 1. [core] Retrieval for Agents I

| | |
|---|---|
| **Study hours** | 17 h — 5 read / 9 build / 3 assess |
| **Compute time** | ≈ 25 min laptop model time per full sweep; no single hands-on step over ~4 min |
| **Tier A calls** | allowance ~900 per sweep; `make plan` prints the real figure in three units |
| **Tier H calls** | ≤ 100, spent only on `docs/RESULTS.md` rows 1–9 |
| **Cost** | $0.00 |
| **Repo tag** | `phase-06` |

A note on that Tier A figure before we start, because Phase 5 taught this lesson at its own expense. The header says "~900". That is an **allowance**, not a measurement, and the two are not the same kind of thing. This phase introduces a second kind of model call — an *embedding* request — and one embedding request can carry thirty-two texts. If you count texts you get one number; if you count HTTP requests you get a number thirty times smaller; and if you count only chat completions you get a third number that ignores most of the work.

`make plan` prints all three and spends nothing. Run it first. It also reveals something counter-intuitive that you would not have guessed: in an *evaluation* sweep, **query embeddings outnumber chunk embeddings roughly five to one** (~1,624 against ~330), because each of 28 queries is re-embedded for every arm at every $k$. The intuition says the corpus dominates. It does not.

Convert a limit into your own unit before believing it.

---

## 2. [core] Cumulative review

Five questions from Phases 3 and 4. Answers in `phase_06_solutions.md`.

**R1.** Phase 3 established that `execute()` never raises: every tool outcome comes back as a `ToolResult` carrying an `error_kind` written for the model to act on (D-10, invariant 19). A colleague proposes that a *retrieval* failure should instead raise, "because an empty index is a programming error, not a tool error". Give the one distinction that decides this, and say which side an empty retrieval falls on.

**R2.** Invariant 22 says an eval check is structured data and grades what the agent produced rather than the path it took. You want to grade "did the agent cite the document that actually contains the answer". Is that a check on the product or on the path? Defend your answer, and note what changes if the agent reaches the right conclusion from the wrong document.

**R3.** Phase 4's counting rule: when a model's output can change which code runs, count the branches it can reach. Phase 4 also introduced the mechanical critic, whose verdict is a pure function of findings and never parsed from model output (invariant 29, D-17). State the shared principle in one sentence, then name the field a model must *not* be given on a retrieval-answer schema.

**R4.** Phase 3's D-20 requires a grader's expected value to be derived from the seeded corpus, "and never a substring loose enough that a fluent non-answer passes". You are grading a question whose answer is "12 months". Give two check formulations that a fluent non-answer would pass, and one it would not.

**R5.** Invariant 31 says a harness record accepts its own `model_dump()`, and that anything a computed total depends on must survive that dump too. Phase 5's §8 found a violation one layer out: `ToolResult.truncated` existed and every outer record dropped it. Without reading ahead, predict the analogous field this phase will drop, given that its subject is documents.

---

## 3. [core] Why this phase matters

Atlas can already answer questions from a database, run tools, search a mock web index, plan multi-step research and account for what it spent. Ask it a question whose answer lives in a document, though, and here is what happens at tag `phase-05`. The router classifies the request as `document` — that route has existed since Phase 5 — and the handler gets `read_file`, `list_files` and `search_web`. So the agent lists the workspace, guesses which file looks promising from its *name*, reads the whole thing into the context window, and answers.

On three seeded notes totalling under two kilobytes, that works. It works because the corpus is small enough to be a rounding error, which is a fact about the corpus and not about the design.

Scale it to the corpus a real small company has — a few hundred documents, some scanned, some two-column PDFs exported from a layout tool, several of them mostly tables — and every part of that approach breaks at once. Reading whole documents blows the context window. Guessing from filenames fails the moment two documents have similar names and different contents. And the failure mode is not an error message: it is a fluent answer sourced from the wrong file, which Phase 4 measured at 75% and Phase 5 named *wrong answer, immaculate provenance*.

So this phase replaces the guessing with retrieval. That is the obvious part, and every tutorial covers it. Here is the part they skip, and the reason this phase is long.

**Retrieval quality is dominated by ingestion quality, and ingestion is where real projects lose weeks.** A vector store is a hundred lines. Cosine similarity is one line. Tuning a chunk size is an afternoon. Getting *text* out of the documents a company actually has — where a two-column page interleaves into sentences that fuse two unrelated clauses, where a table's numbers detach from their row labels, where a running footer appears mid-sentence at every page boundary, where a scanned amendment needs OCR and OCR turns `extended` into `aed` — that is the work. Twenty per cent of the corpus you will build in §7 is deliberately damaged in exactly these ways by a committed seeded script, and §8's broken trajectory is a real extraction defect producing a real wrong answer that passes every citation check you would think to write.

There is a second reason this matters more than it looks. A retrieved chunk is **the only thing in a transcript the model did not write**. Everything else — the plan, the reasoning, the answer — came out of the model and inherits the model's willingness to be fluent about things it does not know. The chunk is *evidence*. Which means retrieval is not primarily a relevance-engineering problem; it is the mechanism by which an agent's claims become checkable. Phase 3's citation discipline and Phase 5's `cited_tools_that_worked` were built for this moment. If the chunk is wrong, a citation is worse than no citation, because it converts an unsupported claim into an apparently supported one.

And Phase 5 left a promise this phase has to keep: *an empty retrieval is a statement about your index, and the moment a model turns it into a statement about the world, you have this phase's bug with better prose.* §6.19 makes abstention a computed property of the hit list rather than a judgement the model is allowed to make, for exactly the reason Phase 5's evaluator was never given an `accept` field.

---

## 4. [core] Learning objectives

By the end of this phase you will be able to:

1. **Explain** what an embedding is, what an embedding model is trained to do, and why cosine similarity is the right comparison — and derive the two-line proof that cosine equals a dot product for unit-length vectors.
2. **State** three cases where semantic similarity is the wrong retrieval mechanism, and predict which of your own queries will fail on a purely dense index.
3. **Ingest** a corpus containing two-column PDFs, table-heavy pages, header/footer-polluted reports and a scanned page, naming for each the extraction failure it produces and the cheap detector that catches it.
4. **Compute** a per-document quality flag before indexing, and justify why a flagged document is indexed *with its flags* rather than quarantined or silently indexed clean.
5. **Chunk** a document four ways (fixed, recursive, semantic, structure-aware), choose between them from a property of the document rather than a preference, and attach metadata that survives to the citation.
6. **Build** a local retrieval stack — dense vector index, BM25, fusion, reranking — and explain what each layer adds that the previous ones could not.
7. **Implement** reciprocal rank fusion and weighted score fusion, and say which needs score normalisation and why the other does not.
8. **Measure** recall@k, MRR and span recall against a labelled query set derived from the seeded corpus, reported **separately for clean and messy documents**, and explain what a single end-to-end number hides.
9. **Generate** grounded answers with citations that resolve to real chunks, and make abstention on empty or weak retrieval a property computed by code from the hit list.
10. **Distinguish** faithfulness from correctness with a worked example in which an answer is perfectly faithful to a chunk that is itself wrong, and say where the fix belongs.
11. **Operate** an index: refresh on document change, version it against its embedder, swap its backend behind a tested interface, and account for the cost of a rebuild.

---

## 5. [core] Prerequisites & quick recap

You need Phases 0–5's repo at tag `phase-05`, and `make test-offline` green before you touch anything. Run it now: 565 tests should pass. If they do not, start from `atlas_phase_05.zip` rather than debugging a divergence.

Four things from earlier phases become load-bearing here.

**The `document` route already exists** (Phase 5, `atlas/flow/route.py`). It currently dispatches to a ReAct agent holding `read_file` and `list_files`. So everything this phase builds is a **handler upgrade**, not a new architecture: at the end, the route's behaviour changes without the router, the account, or the trace format changing at all. That is what a stable interface buys.

**Provenance is already a first-class idea.** `Completion.output_mode` records which rung produced an answer; `ToolResult.truncated` records that content was cut; `RouteDecision` records the classifier's own confidence. This phase adds one more layer of it, and §8 is what happens when the new layer does not reach all the way out.

**Cost is four factors** (Phase 5, §6.9): $k \times (\bar{p}\,r_{in} + \bar{c}\,r_{out})$ — calls, average prompt size, average completion size, and the two rates. Retrieval attacks $\bar{p}$ directly: instead of putting a whole document in the prompt you put five chunks, and instead of an agent taking four steps to find the right file it takes one.

**Invariants 1 and 2 do not bend for retrieval.** No test asserts that a query returns the right chunk *semantically*; that number goes to `docs/RESULTS.md` with a tier, model, seed and date. And `make test-offline` still passes on a fresh clone with no network and no model — which is why the entire retrieval stack is exercised offline by a deterministic embedder you build in §6.4, and why `requirements.txt` does not grow this phase.

If asyncio, Pydantic v2 or pytest are still shaky, Appendix A has the two-page orientations. Nothing here needs new asyncio beyond Phase 5's.

---

## 6. [core] Core concepts

### 6.1 [core] Why retrieval at all

A language model knows what was in its training data, and nothing else. That gives three distinct gaps, worth separating because they have different fixes.

The first is the **knowledge cutoff**: training data ends at some date, so anything after it is absent. The second is **private data**: your company's warranty policy was never in anyone's training data and never will be. The third is **grounding**: even for things the model does know, you often need the answer traceable to a source you can check, because "the model said so" is not an acceptable provenance for a claim in a customer email.

The second and third gaps are not fixed by a bigger model or a later one. A model trained next year still will not know Northwind Instruments' error codes, and it still cannot tell you *why* it said what it said. That asymmetry is the whole argument for retrieval, and it is why retrieval has outlasted several rounds of "the context window is now big enough".

**Retrieval versus fine-tuning.** The alternative to putting knowledge in the prompt is putting it in the weights. Both work; they trade off along four axes.

*Freshness.* Retrieval updates when you re-index one document, in seconds. Fine-tuning updates when you retrain, and a model fine-tuned on last quarter's policy will confidently state last quarter's policy for ever.

*Attribution.* A retrieved chunk has an address: this document, this page, this offset. A fine-tuned fact has no address at all — it is diffused across the weights, and you cannot cite it, audit it, or remove it.

*Cost shape.* This is the one students most often get backwards. Fine-tuning is a **fixed** cost: a training run, paid once, plus a smaller inference cost afterwards because prompts stay short. Retrieval is a **marginal** cost: nothing up front beyond building an index, but every request now carries retrieved chunks in $\bar{p}$. So retrieval is cheaper below some request volume and more expensive above it, and the crossover depends on your traffic, not your architecture. The rates are dated data in `VERSIONS.md`; the *structure* is what to carry around.

*What each is actually good at.* This settles most real decisions: fine-tuning teaches **behaviour** — a format, a tone, a style of reasoning, a domain vocabulary. Retrieval supplies **facts**. Fine-tuning a model on your documents to make it "know" them is using a behavioural tool for a factual job, and it does not work well: the model learns the *shape* of your documents and becomes more fluent at producing document-shaped text that is not in any document. Which is a precise description of a worse problem than the one you started with.

There is also a boring option that is sometimes correct and almost never considered: **put everything in the prompt**. Anthropic's contextual-retrieval post of 19 September 2024 says this outright — under roughly 200,000 tokens, about 500 pages, you can skip retrieval and include the whole thing. Know where the line is.

> **Concept check 6.1.** You are asked to make an assistant answer questions about a 40-page employee handbook that changes twice a year, for 30 employees, with citations. Retrieval, fine-tuning, or whole-document prompting? Name the two axes that decide it and give your answer.

> **Misconception.** *"Big context windows made RAG obsolete."* Two things are being confused. A large window removes the *capacity* constraint — you can physically fit more text. It does nothing about the other three arguments: you still pay for every token you send on every request (that is $\bar{p}$, multiplied by $k$), you still have no attribution unless you build it, and model attention over a long context is not uniform — the "lost in the middle" result (Liu et al., 2023) found material buried mid-context is used less reliably than material at either end. Retrieval is partly a *selection* mechanism, and selection is valuable precisely when capacity is not binding. What large windows genuinely change is the shape of the trade-off: they make retrieving 20 chunks as feasible as retrieving 3, which shifts the interesting question from "how few can I get away with" to "how do I order them".

### 6.2 [core] What an embedding is, in words

Imagine placing every sentence in your company's documents onto a map, on a table, following one rule: **sentences that mean similar things go near each other**. "All instruments carry a 12-month warranty" and "our standard warranty period is one year" would end up almost on top of one another, despite sharing barely a word. "The detector saturated" would land somewhere else, near other sentences about detectors. Sales figures would be in a different region again.

To find the sentences relevant to a question you then read nothing: you place the *question* on the same map and look at what is nearby.

An embedding is that map with two changes. It has far more than two directions — typically several hundred — and the position of each sentence is just the list of its coordinates. That list is the embedding; a model producing it is an **embedding model**, and the number of coordinates is its **dimension**.

Two consequences follow immediately, and both matter more than they sound.

First, the dimension is a **property of the model**, not a setting you choose. You do not pick 768 the way you pick a chunk size. Whatever the model emits is what you get, and it determines the width of every row in your index.

Second — and this causes real outages — **positions from two different maps cannot be compared.** If document vectors came from one model and a query vector from another, the arithmetic still runs. Nothing raises. You get a number between −1 and 1 that looks exactly like a similarity, and it means nothing whatsoever. §6.12 makes an index refuse this, and the refusal is invariant 45.

> **Your turn (5 min).** Without any code: sketch three sentences from Northwind's warranty policy and place them on a 2-D sheet of paper by meaning. Now write a question you would want answered, and mark where it goes. Did it land near the sentence that *answers* it, or near the sentence that *shares the most words* with it? Keep the answer — §6.6 is about the gap between those two, and §6.14 is about exploiting it.

### 6.3 [core] Cosine similarity, precisely

"Near each other on the map" needs a definition. There are several candidates, and the reason the field settled on one is worth understanding rather than memorising.

The obvious candidate is straight-line distance — Euclidean distance. It has a problem for text. A long chunk mentioning "warranty" eight times gets a *longer* vector than a short chunk mentioning it once, in roughly the same direction. Under Euclidean distance those two are far apart, because one is further from the origin. But they are about the same thing. Length is tracking how much text there is; direction is tracking what it is about.

So use the angle. **Cosine similarity** between vectors $a$ and $b$ is

$$\cos\theta = \frac{a \cdot b}{\|a\| \, \|b\|} = \frac{\sum_i a_i b_i}{\sqrt{\sum_i a_i^2}\sqrt{\sum_i b_i^2}}$$

It ranges over $[-1, 1]$: 1 means the same direction, 0 means perpendicular (unrelated), −1 means opposite. Dividing by both magnitudes is what makes it *scale-invariant* — double every component of $a$ and the value does not move — which is precisely the property that made Euclidean distance the wrong choice.

Now the two-line result that every retrieval system in production relies on. If $\|a\| = \|b\| = 1$, the denominator is 1, so

$$\cos\theta = a \cdot b.$$

That is why implementations **L2-normalise once, at index time**, then compare with a bare dot product: you have moved a square root and a division off the hot path and onto the write path, paying once per chunk instead of once per chunk per query. To normalise is to scale a vector to unit length, $\hat{a} = a / \|a\|$. Ollama's documentation states its embedding endpoint already returns unit-length vectors; Atlas normalises anyway, for a reason in §6.4's code.

One more relationship worth having. For unit vectors, squared Euclidean distance and cosine are two views of the same number:

$$\|a - b\|^2 = \|a\|^2 + \|b\|^2 - 2\,a \cdot b = 2 - 2\cos\theta.$$

So ranking by cosine descending and by Euclidean distance ascending give the **identical order** once vectors are normalised. This is why you can read a library's docs saying it uses "L2 distance" and not panic. If, and only if, the vectors are normalised.

**And now the warning that §6.14 will cash in.** Scale invariance is the property that makes cosine correct, and it is also the property that will let a 24-character document *title* outrank the paragraph beneath it — because a title that is 100% on-topic and 0% informative points in a better direction than a paragraph that is 30% on-topic and contains the answer. That is not a flaw in cosine. It is a consequence of the thing you chose it for, and §6.11 is where it bites.

> **Concept check 6.3.** A chunk's vector is $[0.6, 0.8]$ and a query's is $[3.0, 4.0]$. Compute the cosine. Now compute it for a query of $[-0.8, 0.6]$. Interpret both, and say which one Euclidean distance would have ranked higher before normalisation.

> **Misconception.** *"Cosine similarity is a probability, or a percentage of relevance."* It is neither. Cosine values are not calibrated: 0.7 from one model may mean "clearly relevant" and 0.7 from another "unrelated but both are English prose". Real embedding models often produce a narrow band, so an absolute threshold like "accept above 0.75" copied from a blog post will either accept everything or nothing on *your* model. Thresholds must be calibrated per model, per corpus, against labelled data. §6.19's abstention rule needs a threshold-free mechanism for exactly this reason.

### 6.4 [core] What an embedding model is trained to do — and a deterministic stand-in

The map does not organise itself. An embedding model is trained with a **contrastive** objective, and the shape is simple: show it pairs of texts that *should* be close (a question and its answer, a sentence and its paraphrase, a title and its article) and pairs that should be far (everything else, usually sampled from the same batch), and adjust the weights to pull positives together and push negatives apart. Sentence-BERT (Reimers and Gurevych, 2019) is the canonical demonstration that this makes BERT-family encoders usable for similarity search; Dense Passage Retrieval (Karpukhin et al., 2020) is the canonical demonstration that it beats a strong keyword baseline on open-domain question answering.

Two details of that training leak directly into your engineering.

**The model was trained on texts of a certain length.** Its notion of "similar" was learned on sentences and short passages. Hand it a 4,000-word document and it returns a vector — an average of everything the document is about, which is to say a vector near nothing in particular. This is not a capacity limit you can raise; it is what the objective optimised. It is the deepest reason chunking exists, and a better reason than "the context window".

**Some models are asymmetric.** Many are trained so queries and documents are embedded *differently* — with distinct prefixes, or distinct encoder passes. If a model's card specifies a query prefix and you omit it, retrieval quality drops for reasons no amount of chunk tuning will fix. Which model, which prefix and which dimension are current-state facts, so they are in `VERSIONS.md` with a source and a date.

#### The offline embedder

Atlas needs vectors in three situations, and only one can use a real model. Tier A can call a local embedding model. Tier H is capped at 100 calls and cached. But `make test-offline` must pass on a fresh clone with **no network, no model and no `.env`** (invariant 2), and the whole retrieval stack — chunking, indexing, fusion, reranking, citation checking, evaluation arithmetic — has to be exercised there.

So we build a deterministic embedder that is honest about what it is. It hashes weighted lexical features into a fixed number of dimensions and normalises. Cosine between two of its vectors is a smoothed measure of shared words, word pairs and character n-grams.

```python
# excerpt: atlas/rag/embed.py
def dot(a: Sequence[float], b: Sequence[float]) -> float:
    """Dot product. Raises `EmbeddingError` on a length mismatch.

    Raising rather than zipping to the shorter list is the whole point. Python's
    `zip` would silently compare the first 256 components of a 768-dimensional
    vector against a 256-dimensional one and return a plausible float, which is
    the single most expensive class of bug in a retrieval system: it does not
    crash, it does not warn, it just ranks wrongly for ever.
    """
    if len(a) != len(b):
        raise EmbeddingError(
            f"cannot compare vectors of dimension {len(a)} and {len(b)}; "
            "they came from different embedding models"
        )
    return math.fsum(x * y for x, y in zip(a, b))


def cosine(a: Sequence[float], b: Sequence[float]) -> float:
    """Cosine similarity in [-1, 1]; 0.0 when either vector is zero.

    Not clamped to [0, 1]: a negative cosine is real information about a real
    model, and squashing it would hide the case where a query is actively
    *unlike* a chunk. It is clamped to [-1, 1] because floating-point error can
    otherwise produce 1.0000000000000002 for a vector against itself, and a
    downstream `assert score <= 1.0` would then fail on the easiest input.
    """
    na, nb = l2_norm(a), l2_norm(b)
    if na == 0.0 or nb == 0.0:
        return 0.0
    return max(-1.0, min(1.0, dot(a, b) / (na * nb)))
```

Three decisions in twenty lines, each of which I have watched cost somebody a day.

`dot` **raises on a dimension mismatch** rather than zipping to the shorter list. Python's `zip` stops at the shorter argument, so comparing a 768-dimensional document vector against a 256-dimensional query vector returns a perfectly plausible float. Nothing crashes, nothing warns, and your index ranks wrongly for ever. This is the same class of defect as Phase 3's D-12 tool-result ordering: the bug is not that it fails, it is that it succeeds.

`cosine` **is not clamped to $[0,1]$**. A negative cosine says the query is actively unlike the chunk, and folding it to zero throws that away. It *is* clamped to $[-1, 1]$, because floating-point error will otherwise hand you 1.0000000000000002 for a vector against itself, and the first assertion to fail will be the one on the easiest possible input.

`math.fsum` rather than `sum`. Compensated summation over a few hundred floats costs nothing measurable and makes the result independent of accumulation order — otherwise a test comparing two dot products computed in different orders is flaky at the fifteenth decimal place.

And no numpy. Atlas indexes a few hundred chunks; a pure-Python dot product over 256 floats takes microseconds. §6.12 says exactly where the crossover is and how to cross it. A dependency added to speed up something already imperceptible is a dependency that will one day fail to install on somebody's laptop.

Now the features:

```python
# excerpt: atlas/rag/embed.py
STOP_WORDS: frozenset[str] = frozenset(
    """
    a an the of and or to is are was were be been being in on at for from by
    with as that this these those it its there here how what which who whom
    when where do does did can could will would should may might must have
    has had i you we they me us them my our your their long many much
    """.split()
)
```

Four choices worth defending.

**Sublinear term frequency**, $1 + \log(\mathrm{tf})$, not raw counts. The tenth occurrence of "warranty" tells you much less than the second. This is the same saturation idea BM25 formalises in §6.13, arriving here first because it is easier to see in isolation.

**Character n-grams, weighted well below words.** Four-character grams are what let this embedder survive OCR damage: `warrantv` shares three of its four-grams with `warranty`, so a query still finds a chunk the scanner mangled. They are also the most numerous feature by an order of magnitude — a nine-word sentence has about nine unigrams and about fifty four-grams — so at equal weight they *drown* the words. I swept the three weights against a seven-query smoke set during authoring: top-1 went from 5/7 to 6/7 and MRR from 0.80 to 0.93 when character grams dropped to 0.3. That is a fact about seven queries, stated so you know where the defaults came from; the corpus-scale numbers are in `docs/RESULTS.md`.

**Stop words are dropped from unigrams and kept in bigrams.** "Of" carries nothing alone and a great deal in "of shipment". Deleting it from both would throw away the phrase to fix the word.

**The stop list is tiny and hand-written.** A 400-word list inherited from a 1990s search engine deletes "not", "no" and "without" — which is how a retrieval system confidently returns the chunk stating the opposite of what was asked. There is a test asserting negations are not in the list, because this is the kind of thing that gets "improved" during a cleanup.

Then the hash:

```python
# excerpt: atlas/rag/embed.py
def _bucket(feature: str, dim: int) -> tuple[int, float]:
    """Map a feature name to (index, sign) with a STABLE hash.

    `hashlib`, never the builtin `hash`. Python randomises string hashing per
    process unless PYTHONHASHSEED is set, so a builtin-hash embedder produces a
    different vector for the same text in a different process — an index built
    on Monday would not match a query issued on Tuesday, and every test would
    pass because tests build and query in one process. See the misconception
    callout in section 6.4.
    """
    digest = hashlib.blake2b(feature.encode("utf-8"), digest_size=8).digest()
    value = int.from_bytes(digest, "big")
    return value % dim, 1.0 if (value >> 63) & 1 else -1.0
```

The signed bucket is the standard feature-hashing trick: two distinct features landing in the same dimension are as likely to cancel as to reinforce, so collisions add noise instead of systematic bias.

> **Misconception, and this one is a genuine outage waiting to happen.** *"`hash()` is a hash function, so I can use it for feature hashing."* Python **salts string hashing per process** unless `PYTHONHASHSEED` is fixed. An embedder built on `hash()` produces a different vector for the same text in a different process. Your index, written by yesterday's process, becomes unqueryable by today's — silently, returning garbage rather than an error. And every test passes, because tests build the index and query it in one process. The only test that can see this is one that shells out:

```python
# excerpt: tests/test_rag_embed.py
def test_vectors_are_stable_across_a_SEPARATE_PROCESS() -> None:
    """The regression test for using `hash()` instead of `hashlib`.

    Python salts string hashing per process. An embedder built on `hash()`
    passes every in-process test and produces a different index every time the
    server restarts. Only a subprocess with a different PYTHONHASHSEED can see
    it, so that is what this does.
    """
```

Finally, what this embedder does **not** do, stated plainly because a green test suite will otherwise tempt you into a false conclusion. It has no idea that "recalibration interval" and "how often should this be recalibrated" mean the same thing. It cannot do the one thing embeddings are famous for. Every synonym query a real model answers easily returns nothing here.

That is fine, and it is worth being precise about why. **Scripted fixtures and deterministic embedders prove control flow, arithmetic, plumbing and provenance. They prove nothing about meaning.** Offline, we assert that fusion returns hits in rank order, that a mismatched index refuses a query, that recall@5 is computed correctly given a hit list, and that an empty retrieval abstains. On Tier A and Tier H, with a real model, we *measure* whether retrieval finds the right chunk and write the number to `docs/RESULTS.md` with tier, model, seed and date. Confusing those two activities is how a project ends up with 900 green tests and a retrieval system nobody has ever evaluated.

Here is the offline embedder's own smoke measurement, run during authoring on six seeded sentences and seven hand-written queries:

| Query | Gold | Rank | Top score |
|---|---|---|---|
| how long is the standard warranty? | 0 | **1** | 0.098 |
| which products have an extended warranty | 1 | **1** | 0.266 |
| what is excluded from the warranty | 2 | 2 | 0.127 |
| how many departments does Northwind have | 3 | **1** | 0.285 |
| what does error 0x21 mean | 4 | **1** | 0.091 |
| S400 recalibration interval | 5 | **1** | 0.362 |
| `warrantv shipment l2-month` (OCR-damaged) | 0 | **1** | 0.257 |

Top-1 6/7, MRR 0.929. Tier F, `HashingEmbedder(dim=256, char_n=4)`, no seed needed because there is no randomness. Two things to notice. The OCR-damaged query works — that is the character n-grams earning their keep. And the *scores* are tiny and wildly inconsistent, from 0.09 to 0.36, which is §6.3's misconception made concrete: this embedder's 0.098 is a confident hit and its 0.127 is a miss. Any absolute threshold set here would be nonsense.

### 6.5 [core] Local embedding models, dimensions, and the cost of a rebuild

Three practical facts about running an embedding model on a laptop, none of which is a version number.

**Embedding is cheap in a way generation is not.** An embedding model is small — hundreds of millions of parameters rather than billions — it runs a single forward pass with no autoregressive decoding, and it batches beautifully. On the baseline laptop, embedding a few hundred chunks takes seconds, and the endpoint accepts an array of inputs in one request. Which is why this phase's Tier A budget looks alarming as a count of *texts* and unremarkable as a count of *requests*.

**Dimension is a storage and speed decision you do not get to make, except by choosing a model.** A 1024-dimensional model needs four times the memory per chunk of a 256-dimensional one, and a brute-force scan costs four times the arithmetic. Some recent models are trained with Matryoshka representations, so their vectors can be *truncated* to a shorter prefix with graceful quality loss — that genuinely is a dial, and which models have it is a `VERSIONS.md` row.

**Changing the embedding model invalidates the entire index.** Not "degrades" — invalidates. Every stored vector is a position on the old map. This is why re-indexing cost matters, and why `CachingEmbedder` exists:

```python
# excerpt: atlas/rag/embed.py
    def key_for(self, text: str) -> str:
        material = json.dumps(
            {"model": self.inner.model_id, "dim": self.inner.dim, "text": text},
            sort_keys=True,
            ensure_ascii=False,
        )
        return hashlib.blake2b(material.encode("utf-8"), digest_size=16).hexdigest()
```

The key hashes the **work**: model id, dimension, and the exact text. No document id, no chunk index, no run id. That is invariant 37 applied one module over, and Phase 5 shipped the bug it prevents — a key identifying *where* a string appeared can never match the same string appearing again, so the cache is a mechanism that always misses and still passes every test you thought to write.

What this buys is the difference between an experiment a student runs and one a student reads about. Change the chunk size and most chunks change, so most of the cache misses. Change one document in twenty and nineteen twentieths of the corpus is free. And `hits`, `misses` and `EmbeddingResult.cached` are counters with a line that increments them on a real path, asserted by a test that runs that path — invariant 41, which Phase 5 learned by shipping a cache wired to nothing.

One subtlety in the reload path, since it looks like carelessness and is not:

```python
# excerpt: atlas/rag/embed.py
        # A cache written by a DIFFERENT model is not a cache, it is poison.
        # Dropping it silently is correct: the alternative is a hard failure on
        # a stale file the student has no reason to know about.
        if blob.get("model") == self.model_id:
```

A cache file from another model is discarded rather than raising. This is the one place in this phase where silence is right. The contrast with invariant 45 — where a *mismatched index* raises — is deliberate and worth sitting with: **a stale cache is a performance fact, and recovering costs you some embedding calls. A stale index is a correctness fact, and recovering costs you a wrong answer you will never notice.** Different failure, different response.

> **Concept check 6.5.** You switch from a 768-dimensional model to a 1024-dimensional one on a corpus of 5,000 chunks. Which of the following need to change: the stored vectors, the chunk texts, the BM25 index, the labelled evaluation set, the abstention threshold? For each, say why in one clause.

### 6.6 [core] The limits of semantic similarity

Dense retrieval has three failure modes no amount of tuning fixes, and knowing them makes §6.14's hybrid search a reasoned choice rather than a cargo cult.

**Rare exact strings.** Ask for error code `0x21`, part number `M12-A`, invoice `INV-2026-0417`. An embedding model has seen few or none of these; it has no useful position for them, so it places them near other short alphanumeric strings. Meanwhile a keyword index matches `0x21` exactly and instantly. This is not a weakness of a particular model — it is what happens when a system built to generalise meets a token whose entire value is that it does not generalise.

**Negation and quantity.** "Instruments *not* covered by the extended warranty" and "instruments covered by the extended warranty" are, to most embedding models, nearly the same point on the map. The vector captures topic far better than polarity. Same for numbers: "more than 12 months" and "less than 12 months" are close neighbours. If your questions turn on negation or comparison, dense retrieval will hand the generator the chunk saying the opposite — and the generator will often use it, because it is topically perfect.

**Corpus blindness.** This one is structural and the deepest of the three. An embedding is computed from **one text at a time**. The model does not know that "warranty" appears in every document in your corpus and is therefore nearly useless for discriminating between them, while "saturation" appears in two and is therefore highly informative. BM25 knows, because inverse document frequency is computed *over the corpus*. So the honest description of hybrid search is not "keywords plus meaning". It is **corpus-blind plus corpus-aware**, and that is why the two are complementary rather than redundant. Our offline embedder makes this vivid: it cannot have IDF, because it embeds each string in isolation — exactly the constraint a real dense model is under too.

There is a fourth limit that belongs to the pipeline rather than the model, and it is this phase's spine. **An embedding is computed from the text you extracted, not from the document.** If your extractor interleaved two columns into a sentence fusing two unrelated clauses, the embedding faithfully represents that fused sentence, retrieval faithfully finds it for a query it appears to answer, and the generator faithfully cites it. Every layer works. The answer is wrong. That is §8, and it is why §6.7 through §6.9 — extraction, not retrieval — come next.

> **Concept check 6.6.** For each query, predict whether a dense index, BM25, or both will find the right chunk: (a) "what does error 0x33 mean", (b) "how often should the source lamp be replaced", (c) "which SKUs are excluded from the 24-month term", (d) "connector mating cycle rating". Then say which one you would be most nervous about even with both.

> **Misconception.** *"A better embedding model would fix these."* Two of the three are inherent to the mechanism, not the model. Corpus blindness follows from embedding one text at a time — a property of the interface, not the weights. Rare exact strings are a consequence of subword tokenisation and generalisation. Negation is genuinely improving with newer models and genuinely still a weakness. The engineering response is not to wait for a better model; it is to run two retrievers with different failure modes and fuse them, which costs one extra index and a dozen lines of fusion code.

### 6.7 [core] Ingesting messy documents: the part that costs weeks

Everything from here to §6.11 is about producing a string. It is not glamorous and it is where retrieval projects actually fail, so it comes before the vector store rather than after it.

The framing that makes this tractable: **a document is a rendering, and extraction is an attempt to invert it.** A PDF does not contain paragraphs. It contains instructions of the form "draw the glyph `S` at coordinate (90.0, 712.4) in this font at this size", repeated a few thousand times. Paragraphs, columns, tables, headings and reading order are things a *human reader* reconstructs from spatial arrangement. An extractor has to reconstruct them too, from the same evidence, without understanding the content. Every failure mode below is a specific way that reconstruction goes wrong.

Which means the most useful habit in this whole phase is: **read the extracted text before you index it.** Not a sample — read it. Twenty documents takes twenty minutes and will save you a fortnight. `make ingest` prints the per-document report; §6.9 automates the parts that can be automated, and the parts that cannot are why that target exists.

Here are the damage classes, **ranked by how often they bite in practice** rather than by how interesting they are. This ranking is my professional judgement from doing this work, **not a measured statistic**, and it is worth saying which way round that is.

| Rank | Damage | Frequency | Severity | Detectable? |
|---|---|---|---|---|
| 1 | Header/footer pollution | Very common — any paginated report | Low–medium | Yes, reliably |
| 2 | Tables flattened to prose | Very common — any document with tables | **High** | Yes, reliably |
| 3 | Encoding and ligature loss | Common — anything from a typesetter | Low–medium | Yes, reliably |
| 4 | OCR error on scans | Common where scans exist at all | Medium–high | Yes, via confidence |
| 5 | Column interleaving | Uncommon — but multi-column is a whole *genre* | **Severe** | Only from coordinates |
| 6 | Empty extraction | Uncommon | Obvious once checked | Trivially |

Notice the shape. The most frequent damage is the least severe, and the most severe damage is neither the most frequent nor detectable by the means you would first reach for. That asymmetry is why §6.9 does not treat all flags alike, and why §8's failure is a column interleave and not a header.

Now each one, with the **real measured output** of a real extractor on documents built by the committed generator. Nothing below is my impression of how extraction fails.

### 6.8 [core] The five damage classes, measured

#### 6.8.1 Header and footer pollution

The seeded quarterly review is a two-page report with a running header, a retention footer and a page number. Here is what a naive extractor returns for page 1, verbatim:

```
Northwind Instruments — Quarterly Operations Review — CONFIDENTIAL
2026Q2
1. Scope
This review covers operations for the quarter ending 2026-06-30 and
records the disposition of every open warranty claim. Claims carried
over from the prior quarter are listed in Appendix A. The operations
team closed 41 of 58 claims received, a closure rate of 71 percent,
against a target of 75 percent. The shortfall is attributed to a
Uncontrolled copy when printed. Retain for 7 years.
Page 1 of 2
```

Read the last three content lines. The sentence is *"The shortfall is attributed to a delay in connector stock"* — and between "to a" and "delay" the extractor has inserted four lines of boilerplate, because page 2 begins with its own header. **No chunk will ever contain that clause.** Ask "why did the closure rate miss target" and the chunk containing the answer contains the question's setup and then a retention notice.

There is a second, quieter cost. "Northwind Instruments" now appears once per page. In a forty-page report that is forty occurrences, which inflates term frequency enormously and drags every query mentioning the company towards whichever document has the most pages. Boilerplate does not just interrupt sentences; it corrupts the corpus statistics §6.13's BM25 depends on.

The detector is repetition **across pages**, which is why it takes pages rather than text:

```python
# excerpt: atlas/rag/extract.py
def repeated_lines(pages: Sequence[str], *, min_pages: int = 2) -> list[str]:
    """Lines appearing on at least `min_pages` pages: headers, footers, stamps.

    Repetition across *pages* is the signal, which is why this takes pages
    rather than text. A running header appears once per page by definition; a
    sentence appearing on every page of a real document is boilerplate, not
    content. Page numbers escape this because "Page 1 of 2" and "Page 2 of 2"
    differ, so `strip_repeated_lines` masks digit runs before comparing.
    """
```

The digit masking is the detail that makes it work. `Page 1 of 2` and `Page 2 of 2` are different strings and identical boilerplate; masking digit runs to `Page # of #` collapses them. Measured on the seeded review, the detector finds all four patterns, and after stripping, page 1 ends `...attributed to a` and page 2 begins `delay in connector stock`, so the clause is contiguous again.

> **Misconception.** *"Just drop the first and last two lines of every page."* It works until a document's first content line shares a line with its header, or a table starts at the top of a page, or the header is three lines on page 1 and one thereafter. Positional rules encode a layout; repetition detection encodes the *property* that made the layout detectable. Prefer the property.

#### 6.8.2 Tables flattened into prose — the highest-severity common case

The seeded tolerances page is a five-column table. Verbatim extraction:

```
CALIBRATION TOLERANCES 2026
Applies to instruments shipped after 2026-01-01. Supersedes CT-2025.
SKU
Parameter
Nominal
Tolerance
Interval
S400
wavelength accuracy
0.5 nm
+/- 0.2 nm
12 months
...
T100
temperature
0.1 C
+/- 0.3 C
6 months
P900
pressure zero
0 kPa
+/- 1.2 kPa
24 months
```

Every value is present and every relationship is gone. The column headings appear once, twenty-five lines above the last row they label. Chunk this at any size and you get a chunk containing `T100 / temperature / 0.1 C / +/- 0.3 C / 6 months` with no heading in it, and a chunk boundary can land anywhere — including between `+/- 0.3 C` and `6 months`.

Now consider what retrieval does with that. Ask "what is the calibration interval for the P900" and a dense index cheerfully returns a chunk containing `24 months` near `P900`. It is even the right answer. Ask "what is the tolerance for the P900 pressure zero" and you may get a chunk containing `+/- 1.2 kPa` — with nothing in it saying that `1.2 kPa` is a *tolerance* rather than a *nominal*. The generator will supply that word for free, because the question supplied it.

This is the deep problem with tables: **a table's meaning lives in its geometry, and prose extraction preserves only its contents.** A number in a table is a triple — row label, column label, value — and flattening keeps the value.

The measured detector is crude and effective: the share of lines with four words or fewer. On this page it is **0.97**; on prose it is **0.03**.

```python
# excerpt: atlas/rag/extract.py
def flattened_table_score(text: str) -> float:
    """Fraction of short lines: the fingerprint of a table read cell by cell.

    A naive extractor emits one table cell per line, so the page becomes forty
    lines of two or three words each. The score is the share of non-blank lines
    under five words. On the seeded tolerances page the measured value is above
    0.9; on prose it sits near 0.
    """
```

**The right fix is not a better flattener; it is not to flatten.** A layout-aware backend can return a table as a list of rows, and each row becomes its own chunk carrying its column headings inline: `"S400 | wavelength accuracy | nominal 0.5 nm | tolerance +/- 0.2 nm | interval 12 months"`. Now the number cannot be separated from its label, because they are in the same sentence. That is Assignment 2, and `ChunkKind` already has `table_row` waiting for it.

> **Your turn (10 min).** Take the flattened table above and write, by hand, the five row-chunks you would want. Then write one query that the flattened version answers correctly by luck, and one it answers wrongly with confidence. Keep both; they become eval tasks.

#### 6.8.3 Encoding and ligature loss

This one surprises people, which is why the measurement is worth showing. The seeded amendment is set in a serif face, so the typesetter substituted ligature glyphs for `fi`, `fl`, `ffi` and `ff` — a normal, correct thing for a layout engine to do. Verbatim extraction:

```
WARRANTY AMENDMENT A-2026-1
The ■rst clause of section 3.1 is modi■ed to specify a ■xed of■ce
work■ow for ■eld claims. Certi■cates must be ■led within ■ve days.
Ef■cient handling of in■ight claims is the responsibility of the
operations of■cer. No refund is o■ered where the fault is af■rmed
to arise from misuse outside the rated environment.
```

Measured: **4.07% of characters** are the replacement glyph U+25A0. The extractor could not map the ligature codepoints to their components — the font's character map did not decompose them — so it emitted a placeholder. Twelve words in five lines are now unmatchable by any keyword index: `first`, `modified`, `fixed`, `office`, `workflow`, `field`, `certificates`, `filed`, `five`, `efficient`, `inflight`, `officer`, `offered`, `affirmed`.

There are two cases and they must be handled differently.

When the extractor emits the **real ligature codepoints** (U+FB00–U+FB04), the information is intact and repair is exact:

```python
# excerpt: atlas/rag/extract.py
LIGATURE_REPAIRS: tuple[tuple[str, str], ...] = (
    ("\ufb03", "ffi"),
    ("\ufb04", "ffl"),
    ("\ufb00", "ff"),
    ("\ufb01", "fi"),
    ("\ufb02", "fl"),
)
```

When it emits a **placeholder**, the information is gone. `modi■ed` could be `modified` or `modifled`, and Atlas does not guess:

```python
# excerpt: atlas/rag/extract.py
    Only the *real* codepoints are repaired. A U+25A0 has already lost the
    information — "modi■ed" could be "modified" or "modifled" — so it is left
    in place and flagged. Guessing would replace a visible defect with an
    invisible one, and a student reading the chunk would have no way to know
    the word was reconstructed. This is the same principle as Phase 5's
    refusal to let a model clear a finding.
```

That is the general rule, and it is D-17's: **a repair may restore information; it may not invent it.** A visible defect a reader can see and route around beats an invisible one they cannot.

A note on a plausible-sounding claim that got checked and turned out false. It would *seem* that three-character ligatures must be repaired before two-character ones, or `of■ce` becomes `ofice`. Not so: each ligature is a *single codepoint*, so replacements cannot interfere. I verified it rather than asserting it, and there is a test pinning it — precisely because it is the kind of thing a future reader will "correct".

The same function does Unicode NFKC normalisation, which folds the non-breaking spaces and curly quotes PDF exports scatter everywhere. Without it, `12 months` with U+00A0 and `12 months` with a space are different tokens, and half your numeric queries silently miss.

#### 6.8.4 OCR, and its error profile

The seeded corpus contains a scanned amendment: an image with realistic skew, blur and speckle, generated deterministically from the seed. Real OCR over it gives, verbatim, alongside the truth.

**OCR output** — measured mean per-word confidence **80.0**, with **30%** of its 57 words below 85:

```
7 am —— A-2026-2

Effective 2026-07- 01, the aed term for the S400 and P900 .

.. is 24 months from date of shipment: when registered within 30

73 days. The standard term ‘of: 12 months is unchanged for all

other instruments. Claims under the extended term require
- the original calibration certificate and the registration ID
```

**Truth:**

```
WARRANTY AMENDMENT A-2026-2

Effective 2026-07-01, the extended term for the S400 and P900
is 24 months from date of shipment when registered within 30
days. The standard term of 12 months is unchanged for all
other instruments. Claims under the extended term require
the original calibration certificate and the registration ID.
```

The error profile you will meet:

- **The title is destroyed.** `WARRANTY AMENDMENT A-2026-2` became `7 am —— A-2026-2`. Titles are often the largest, most decorated text on a page and OCR engines do worst on exactly that.
- **A key content word vanished.** `extended` became `aed`. This is the expensive one: a query for "extended term" now misses the chunk that *defines* the extended term, while `24 months` survived perfectly. **The number is retrievable and the concept that qualifies it is not** — so the chunk is findable by the wrong route and answers the wrong question.
- **Punctuation and hyphens fragment.** `2026-07-01` → `2026-07- 01`. Date and part-number queries break on this constantly.
- **Speckle becomes tokens.** `73`, `..`, `-` are not in the document. Spurious *numbers* are the dangerous kind, because a generator asked for a figure will happily use one.
- **Spurious punctuation attaches to real words.** `shipment:`, `‘of:`.

Now the useful part. **OCR tells you when it is struggling, and almost nobody asks.** Every mainstream engine returns per-word confidence. On this page the destroyed title's words score 2 and 0; the intact body scores in the 90s. So the flag is free:

```python
# excerpt: atlas/rag/extract.py
def ocr_damage(
    confidences: Sequence[float], *, low: float = 85.0
) -> tuple[float, float]:
    """(mean confidence, share below `low`) from per-word OCR confidences.

    Both numbers, not one, because they answer different questions. A mean of
    80 with 5% low words is a slightly soft scan. A mean of 80 with 30% low
    words is a scan with a destroyed region — which is what the seeded
    amendment is, and its destroyed region is the title.
    """
```

Two numbers, not one, and a test asserts the flag is driven by the **share** rather than the mean. A uniformly soft scan is a different problem from a scan with a hole in it, and averaging cannot distinguish them.

The 57 confidence values in `scripts/gen_docs.py` are the ones tesseract actually returned, captured in the same run as the text. **They were not, in the first version of this phase.** An earlier draft carried a hand-built array of 60 values chosen to reproduce the three aggregate statistics quoted above, under a comment claiming it was tesseract's output. That is F-06-08, and the fix included two tests that pin the fixture to the numbers this section quotes and to each bullet in the list above — so the fixture and the tutorial cannot drift apart again.

> **Misconception.** *"OCR quality is a property of the OCR engine."* Mostly it is a property of the **image**. Resolution, skew, contrast and compression artefacts dominate. The cheapest large win in any OCR pipeline is usually deskewing and thresholding the image before the engine sees it, not switching engines. Also: OCR output is a current-state fact about your toolchain — a different engine version gives different text — which is why the seeded corpus **freezes** its OCR output to a committed file and records the engine version in `VERSIONS.md`. Re-running OCR at test time would make the suite's determinism depend on a system package.

#### 6.8.5 Column interleaving — the severe one

This is §8's bug, so it gets the most care. The seeded field-service bulletin is a two-column page. Here is what a y-coordinate-sorting extractor returns, verbatim:

```
FIELD SERVICE BULLETIN FSB-2026-04 Portable units.
Recalibration intervals. The T100 temperature logger requires
The S400 benchtop spectrometer detector recalibration after 6 months of continuous
requires recalibration after 12 months of operation. The shorter interval reflects the
continuous operation, or sooner if the dark uncompensated thermistor used in the
reference drifts beyond 0.4 percent. Field portable housing, not a defect.
```

Read line 3 on its own, the way a chunk will:

> **The S400 benchtop spectrometer detector recalibration after 6 months of continuous**

That is a grammatical, fluent, plausible, **false** statement. The document says the S400 needs recalibration after **12** months; the 6 months belongs to the T100, in the other column. The extractor did nothing unreasonable — it sorted words by vertical position and joined them, which is exactly right for a single-column page. The layout carried information the sort discarded.

And here is the crucial engineering point, which I got wrong when I first built this and had to measure my way out of.

**Whether this happens depends on your extractor, and the two mainstream ones disagree.** Measured on the identical file: `pypdf`'s default text extraction returned the columns **correctly**, one after the other, because it follows the PDF's content-stream order and the generating tool wrote column by column. `pdfplumber`'s default `extract_text()` returned the **interleaved** version above, because it groups words into lines by y-coordinate. Neither is buggy. They make different assumptions, and which is right depends on the tool that *produced* the PDF — a document exported row-by-row from a layout engine breaks pypdf too.

So: **you cannot know whether your reading order is correct without checking, and which library you chose does not tell you.** That is an unpleasant fact and it is the honest one.

The reliable check is coordinates. A multi-column page has a vertical band containing no word on any line:

```python
# excerpt: atlas/rag/extract.py
def detect_columns(
    words: Sequence[Word], *, page_width: float, min_gutter_ratio: float = 0.05
) -> ColumnLayout:
    """Find vertical gutters from word boxes. The RELIABLE column detector.

    A gutter is a vertical band containing no word on any line of the page. On
    the seeded two-column bulletin, the leftmost column's words end at x=233
    and the right column's begin at x=331 — a 98-point band, 16% of the page
    width, with nothing in it. There is no equivalent band on a single-column
    page, so the test is a sweep for empty intervals rather than a threshold on
    anything.
    """
```

Measured on the seeded bulletin: 129 words, left column ending at x = 233.2, right column beginning at x = 331.2, a **98-point gutter** on a 612-point page. The widest inter-word gap on any single-column page in the corpus is under 12 points. The classes separate cleanly, and once you know there are two columns, re-reading column by column is mechanical — group words by x-band, then sort by y within each band, which recovers the correct text exactly.

> **Concept check 6.8.** A colleague says "we'll detect this by looking for sentences that don't parse". Give two reasons that fails on the measured output above.

### 6.9 [core] The quality check before indexing — and a measured negative result

Now put the detectors together. One function turns numbers into flags, so that "what counts as damaged" is a thing you can read, test and change in one place. Thresholds are **parameters, not constants**, because they are corpus-dependent and a threshold baked into an `if` is a measurement nobody can repeat.

Two design decisions in `assess` matter more than the detectors.

**Flags are split by consequence, not by severity.**

```python
# excerpt: atlas/rag/extract.py
# `suspect_reading_order` is deliberately NOT blocking. It means "we had no way
# to check", which is a caveat a reader should see and not grounds to refuse a
# document. A flag's consequence must match the strength of its evidence; see
# section 6.9's measurement of what happens when it does not.
BLOCKING_FLAGS: frozenset[str] = frozenset({"empty_extraction", "interleaved_columns"})
```

The test is not "how bad is this" but "**can a sentence from this text be quoted as a claim the document made?**" `boilerplate_repetition` adds junk terms and never changes what a sentence means, so it is a caveat. `flattened_table` detaches values from labels, which is serious — but each value *is* in the document, so a careful quote is still a quote. `interleaved_columns` manufactures sentences that **no document contains**, so it is blocking. That distinction is what §6.19's abstention rule consumes.

And now the negative result, the most useful thing in this section.

I wrote a text-only interleave detector: the fraction of lines containing a mid-line sentence start. The theory is sound — a fused right column drops its sentence openings into the middle of the left column's lines. Then I measured it on the seeded corpus:

| Sample | Damaged? | `interleave_suspicion` |
|---|---|---|
| Bulletin, y-sorted extraction | **yes, badly** | 0.462 |
| Bulletin, column-major extraction | no | 0.130 |
| Quarterly ops review, prose | no | **0.500** |
| Ligature amendment, prose | no | 0.167 |
| Tolerances table | no | 0.031 |
| Warranty policy note | no | 0.000 |
| Error-codes note | no | 0.000 |
| Onboarding note | no | **0.500** |

Read the two bold rows. **The detector's two highest scores both belong to undamaged documents.** It ranks a perfectly good report *above* a wrecked one. So its catch rate $q$ for this failure class, at any threshold that avoids false positives, is **zero** — Phase 5's §8 lesson in a new costume: a shape gate has $q=0$ against a well-shaped wrong answer, and this is a *statistical* gate with $q=0$ against a fluent wrong reading order.

What to do with a measured-useless detector? Three options, and only one is right. Deleting it loses the evidence that it was tried, and the next person writes it again. Wiring it to a flag ships a mechanism that fires on good documents and refuses them — a gate whose consequence exceeds its evidence. So: **keep it, report its number, wire it to no decision.**

```python
# excerpt: atlas/rag/extract.py
    # The interleave score is COMPUTED AND REPORTED, and decides nothing. See
    # the docstring: it was measured to rank a good document above a broken one.
    interleave = interleave_suspicion(text)
```

That is D-21's rule in a new place: a heuristic judgement is **recorded as data**, and code decides. There is a test asserting the negative result, so if somebody later improves the detector, the test fails and forces them to re-measure and rewrite this section rather than quietly promoting a heuristic back into a decision.

The honest flag for "no coordinates were available" is set from the **absence of evidence**, which is always true when it fires:

```python
# excerpt: atlas/rag/extract.py
    elif columns is None and layout_source:
        # Absence of evidence, stated as such. This fires on every page-layout
        # source whose extractor gave us no coordinates -- which is a fact
        # about the toolchain, is always true when it fires, and is exactly
        # what a reader needs to know before trusting a quoted sentence.
        flags.append("suspect_reading_order")
```

#### A defect this section shipped, found by its own tests

The ingestion order is: read pages, repair ligatures, strip boilerplate, assess. The first version of `assess` derived the repeated lines from the pages it was handed — which were the **stripped** pages. So the flag could never fire. The fix for the defect had destroyed the evidence of the defect, and the `boilerplate_repetition` flag was unreachable code that broke nothing and told nobody.

The test that caught it asserted the flag on a two-page fixture and failed with `['suspect_reading_order']`. The fix collects evidence before the repair that consumes it:

```python
# excerpt: atlas/rag/extract.py
    pages = [repair_ligatures(p) for p in pages]
    # Evidence BEFORE the fix, because the fix destroys the evidence.
    removed: list[str] = []
    if strip_boilerplate and len(pages) > 1:
        removed = repeated_lines(pages)
        pages = strip_repeated_lines(pages)
```

The rule it leaves behind is sharper than "collect evidence first", and it explains why the *ligature* repair does not need the same treatment:

> **A repair that restores lost information need not announce itself; a repair that exercises judgement must record that it acted.**

Ligature decomposition is exact — after it, the text is simply correct, and there is nothing for a reader to second-guess. Deciding a line is boilerplate and deleting it is a *judgement* that can be wrong, and only the flag makes that checkable. Logged as **F-06-01**, decided as **D-34**.

> **Concept check 6.9.** Under that rule, which of these repairs must record that they acted: NFKC normalisation; de-hyphenating a word broken across lines; dropping a page that extracted empty; lowercasing for the BM25 index?

### 6.10 [core] Chunking: four strategies and how to choose

A chunk is the unit of retrieval, so it is the unit of citation, so it is the unit of accountability. A chunker returning `list[str]` has thrown that away in its return type. Atlas's chunkers return **offsets**, and the dispatch attaches metadata:

```python
# excerpt: atlas/rag/chunk.py
    chunk_id: str
    doc_id: str
    text: str
    ordinal: int
    strategy: ChunkStrategy = "recursive"
    kind: ChunkKind = "prose"
    page: int = 1
    heading: str | None = None
```

`frozen=True`, because a chunk is evidence and mutable evidence has no history — the argument that made Phase 5's `StepRecord` frozen.

**Fixed windows.** Cut every $n$ characters with overlap. Its one virtue is predictability, which makes it a good control arm. Its vice, measured on the warranty policy at size 300: chunk 1 ends `...beyond stated tolerance, a` and chunk 2 begins `onsumables, calibration drift`. `Consumables` has been cut in half. A cut *number* is worse — `24 mon` / `ths from date of shipment` — because the fragment retrieves and reads as a fact.

**Recursive.** Try to break on paragraphs; where a paragraph is too long, break on lines, then sentences, then words, then characters. The separator order encodes what you are least sorry to break, and the chain guarantees termination — verified on a 5,000-character input with no spaces, which produces 50 hard-cut chunks rather than looping.

```python
# excerpt: atlas/rag/chunk.py
RECURSIVE_SEPARATORS: tuple[str, ...] = ("\n\n", "\n", ". ", "? ", "! ", "; ", " ")
```

This is the default, and the reason is not that it is best but that **its failures are boring**. One detail worth stealing: overlap extends each span *backwards*, never forwards, because extending forwards makes the last chunk short and can push a document's final sentence out of it entirely on inputs whose length is near a multiple of the step.

**Structure-aware.** One chunk per heading, subdivided when a section is too long. Measured on the warranty policy, this is visibly the best available answer:

```
prose    head='Warranty policy (2024) / 3.1 Standard term'
prose    head='3.2 Extended term'
prose    head='3.3 Exclusions'
```

A query about exclusions retrieves the section about exclusions. Recursive chunking at 300 characters put 3.2 and 3.3 in the same chunk, so a query about exclusions retrieves a chunk that also promises 24 months, and the generator must choose. Sometimes it chooses wrong.

The reason structure wins is worth stating precisely: **a heading is the author's own claim about where one topic ends.** No heuristic beats it, because the author had information the heuristic does not — they knew what they meant. Two implementation notes: every sub-part of a long section keeps the heading (the chunk that answers the question is often not the first one under it), and a **bare heading is merged forward** into the section it titles, for a reason §6.11 makes concrete.

**Semantic.** Embed each sentence, break where consecutive similarity drops. Its honest assessment is in its docstring:

```python
# excerpt: atlas/rag/chunk.py
    It is included because you will be asked about it, and its honest
    assessment is: expensive, fiddly, and rarely the best choice. It costs one
    embedding call per sentence at *index* time, the threshold needs calibrating
    per corpus and per model (section 6.3's misconception, with consequences),
    and on a document that has headings it is strictly worse than reading the
    headings. Reach for it when a document is long, homogeneous prose with no
    structure at all — a transcript, an unformatted export — which is a real
    case and a minority one.
```

That assessment is *mostly* borne out and not entirely, which is why it is worth measuring rather than believing. On the seeded corpus semantic chunking ties structure on R@1 (0.857) and has the **best messy R@1 of the four** at 0.875 — and it produces 44 chunks against structure's 28, so it costs more index-time calls for that. Full table in §6.17.

**The decision rule**, one line each. Does the document have headings? Use structure. Is it long homogeneous prose with no structure? Consider semantic, and measure it against recursive before believing it. Is it a table? Do not chunk it as prose at all — extract rows. Anything else? Recursive. Choose from a **property of the document**, never from a preference.

One number a chunk-size experiment must report or it will lie to you:

```python
# excerpt: atlas/rag/chunk.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def total_chars(self) -> int:
        """Includes overlap, which is the point: this is what you will EMBED.

        Comparing chunk sizes without this number is how a chunk-size
        experiment concludes that smaller is free. Halving the chunk size at
        fixed overlap roughly doubles the chunk count and increases the total
        characters embedded, because every character in an overlap region is
        embedded twice.
        """
```

> **Misconception.** *"Smaller chunks are more precise, so smaller is better."* Smaller chunks raise the chance the retrieved chunk is *about* the query and lower the chance it *contains the answer*, because answers carry qualifiers — "24 months **when registered within 30 days**". A chunk holding the number without the condition retrieves beautifully and is wrong. There is a genuine optimum, it depends on your documents, and §6.17 measures it rather than assuming it. Overlap exists precisely to buy back some of what small chunks lose, at a cost in embedded characters.

### 6.11 [core] Metadata as a first-class decision

Chunk metadata is usually treated as bookkeeping. It is three separate mechanisms, and conflating them is why people under-invest.

**Metadata is how a citation becomes checkable.** `doc_id`, `page`, `heading` are what a reader needs to go and look. Atlas renders them as one string:

```python
# excerpt: atlas/rag/chunk.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def citation(self) -> str:
        """The human-readable address printed beside a claim."""
        where = f"{self.doc_id} p.{self.page}"
        if self.heading:
            where += f" § {self.heading}"
        tail = f"  [{', '.join(self.flags)}]" if self.flags else ""
        return f"{where}{tail}"
```

Note the tail. A citation prints its quality flags: `fsb-2026-04 p.1  [interleaved_columns]`. That is invariant 42 made visible, and §8 is the trace of what happens when the list stops one layer short.

**Metadata is how filtering works.** §6.15's filters are metadata predicates. A filter you did not store metadata for is a filter you cannot write, and retrofitting it means re-indexing.

**Metadata is how quality propagates.** Flags are inherited from the document, verbatim and unconditionally:

```python
# excerpt: atlas/rag/chunk.py
    # Inherited verbatim from the document's ExtractionQuality. NOT recomputed:
    # a flag about a two-column page layout is not visible in one chunk of its
    # text, so a chunk that recomputed its own flags would drop every one of
    # them and look clean. This is invariant 42, and section 8 is the trace of
    # what happens when the list is dropped one layer further out.
```

Two things there. **Not recomputed**, because a two-column layout is not visible in one chunk of its text — a chunk that re-ran the detectors would come back clean, the most dangerous possible answer. And **not optional**: propagation has no parameter, because an option to turn it off is an option somebody will use in a hurry.

#### The content-free chunk, and why cosine invites it

Structure chunking's first implementation emitted one chunk per heading including the document title, which produced five chunks like this:

```
warranty-policy#0000    24c  '# Warranty policy (2024)'
error-codes-s400#0000   18c  '# S400 error codes'
```

And for the query *"how long is the standard warranty"*, `warranty-policy#0000` ranked **first** — the title, which contains no warranty term at all, above the section that states the answer.

This is §6.3's warning arriving. A 24-character chunk that is 100% on-topic and 0% informative points in a *better direction* than a 90-character chunk that is 30% on-topic and contains the answer. Cosine's scale invariance — the property that makes it the right metric, because it stops long documents dominating — is exactly what lets a title outrank the paragraph beneath it. It is not a bug in cosine and no threshold fixes it. The fix is not to create the chunk:

```python
# excerpt: atlas/rag/chunk.py
    # Merge a bare heading forward into the section it titles. Measured
    # defect: the structure chunker produced five content-free chunks such as
    # "# Warranty policy (2024)", and one of them ranked FIRST for the query
    # it is the title of -- a 24-character chunk that is 100% on-topic and 0%
    # informative beats a 90-character chunk that is 30% on-topic and contains
    # the answer. Cosine's scale invariance, praised in section 6.3, is exactly
    # what makes a title outrank the paragraph under it. See F-06-02.
```

Logged as part of **F-06-02**. The general lesson: **a chunk with no assertions in it is retrievable and cannot be evidence.** Headings, page numbers, table-of-contents entries and "Continued on next page" all have this shape. Index them and they compete with your answers.

Finally, refresh. `chunk_id` is `doc_id#ordinal` — stable, readable, citable — but ordinals shift when a document is edited. So a chunk also carries a content hash:

```python
# excerpt: atlas/rag/chunk.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def content_hash(self) -> str:
        """Content address, for index refresh. Hashes the TEXT, not the id.

        Invariant 37's shape again: a refresh needs to know whether this chunk's
        *work* changed. An id-based comparison says every chunk of an edited
        document changed, because inserting a paragraph shifts every ordinal
        after it; a content hash says only the chunks whose text moved changed,
        and section 6.19's refresh re-embeds exactly those.
        """
```

Two identities doing two jobs: the id addresses a chunk for a human, the hash addresses its work for the machine. The same distinction as Phase 5's `idem_key`.

> **Concept check 6.11.** You add an `effective_date` filter six months after launch. Which of these must you redo: extraction, chunking, embedding, the BM25 index, the labelled eval set? Which would a content-hash-based refresh let you skip?

### 6.12 [core] The vector store, and where brute force stops paying

The dense retriever is the least interesting component in this phase, which is a good reason to get it out of the way with an argument rather than a library.

To find the nearest chunks to a query you compute cosine against every stored vector and keep the top $k$. That is it. The whole store is a list of chunks, a parallel list of vectors, and a sort.

**The arithmetic that makes this a decision rather than laziness.** A 256-dimensional dot product is 256 multiplies. Five hundred chunks is 128,000 multiplies per query, which Python does in about a millisecond. An approximate-nearest-neighbour index — HNSW, IVF — would make that faster and would cost you a dependency, a build step, at least one tuning parameter, and recall you can no longer reason about exactly, because "approximate" means it sometimes misses the true nearest neighbour and you now have two recall problems instead of one.

Brute force stays fine to roughly $10^4$–$10^5$ vectors on a laptop, at which point a query costs tens of milliseconds and an ANN index starts to earn its complexity. Which libraries, and their current versions, are `VERSIONS.md` rows.

**And "swap it at the interface" is a claim, so this phase makes it a test.** `atlas/rag/backends.py` adds a Chroma-backed store behind the optional extra, and `tests/test_rag_backends.py` runs **one** conformance suite over both implementations — 25 tests, parameterised, skipping the Chroma arm when the extra is absent. The exact store remains the default, because on 28 chunks Chroma is *slower*: it pays for a client, a collection and a schema. What the second backend buys is threefold, and none of it is speed:

1. "The interface is swappable" is a passing test rather than a sentence (D-35).
2. The adapter must state where an approximate index legitimately differs from exact cosine — which is what you need to know before trusting a recall number from an ANN index.
3. You meet the API you will actually be handed in a job.

Three differences the adapter documents, all properties of the *class* of index rather than of the adapter:

```python
# excerpt: atlas/rag/backends.py
    **Chroma returns a distance, not a similarity.** With cosine space the
    distance is `1 - cosine`, so the adapter converts. Getting this backwards
    inverts every ranking and produces a system that confidently retrieves the
    least relevant chunk — and nothing raises. Hence a conformance test that
    asserts the two backends agree on the TOP hit for a query with an obvious
    answer.
```

Two guards earn their place in either backend. The first is the misalignment check from §6.4's `parse_embed_payload`, one layer up: if 40 chunks arrive with 39 vectors, every chunk from index 39 onwards wears its neighbour's vector, and retrieval returns confidently wrong neighbours with no error anywhere. The second is invariant 45:

```python
# excerpt: atlas/rag/store.py
        if fingerprint is not None and fingerprint != self.fingerprint:
            raise EmbeddingError(
                f"query was embedded by {fingerprint!r} and this index by "
                f"{self.fingerprint!r}; cosine between them is a number with "
                "no meaning. Re-index, or query with the index's embedder."
            )
```

Compare that with §6.5's cache, which *silently discards* a file written by another model. The contrast is a good rule to carry: **a stale cache is a performance fact and recovering costs you some calls; a stale index is a correctness fact and recovering costs you a wrong answer nobody notices.**

And the hit record carries the chunk's flags upward:

```python
# excerpt: atlas/rag/store.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def flags(self) -> list[str]:
        """Carried up from the chunk so a hit can be filtered on it.

        Invariant 42: the flag list has to survive every hop from extractor to
        citation. This is the hop Phase 5's `truncated` defect would have been
        dropped at, one layer out.
        """
```

Three hops down, one to go. §8 is the hop that got dropped.

> **Misconception.** *"A reloaded index is the same index."* Atlas's `DocumentIndex` always reloads as the **exact** store, even if it was built on Chroma, and that is deliberate. A dump carries chunks and vectors — enough to rebuild exact search, and *not* enough to restore an approximate index's graph. Returning something that claimed to be the original would be a lie about recall. Read that as the general rule for serialising any approximate structure: persist the inputs, rebuild the index, and never pretend a rebuild is a restore.

### 6.13 [core] BM25: the corpus-aware half

BM25 comes from the probabilistic relevance framework (Robertson and Zaragoza, 2009, *The Probabilistic Relevance Framework: BM25 and Beyond*). For a query $Q$ and document $D$:

$$\text{score}(D,Q) = \sum_{q \in Q} \text{IDF}(q) \cdot \frac{f(q,D)\,(k_1+1)}{f(q,D) + k_1\left(1 - b + b\,\frac{|D|}{\text{avgdl}}\right)}$$

Three ideas, each a correction to something naive.

**IDF corrects counting.** A term appearing in every document cannot discriminate between them; a term appearing in two nearly decides the query on its own.

$$\text{IDF} = \ln\!\left(1 + \frac{N - n + 0.5}{n + 0.5}\right)$$

```python
# excerpt: atlas/rag/bm25.py
    The `1 +` inside the logarithm is not decoration. The unsmoothed form goes
    **negative** for a term appearing in more than half the corpus, which means
    a document containing the word "the" scores *worse* than one that does not
    -- and a query of nothing but common words then ranks documents in reverse.
    Wrapping in `1 +` floors the value at zero: a term everything contains
    contributes nothing, which is the intended meaning.
```

**$k_1$ corrects linearity.** Relevance is not linear in repetition. Measured on Atlas's implementation: going from one occurrence to two adds more than five times what going from nine to ten adds. There is a test asserting that, and a fixture chunk in the test corpus that says "warranty" eight times and nothing else, which must not win a warranty query. It does not.

**$b$ corrects for length.** A long document contains more of everything. Without normalisation the longest wins every query — which is also, exactly, why §6.8.1's boilerplate stripping matters: a forty-page report with the company name in every header is a document whose length *and* term frequency are both inflated by material nobody wrote as content.

One decision in `idf` that goes against instinct:

```python
# excerpt: atlas/rag/bm25.py
        Zero rather than the maximum. An unseen term is not maximally
        informative, it is uninformative: no document contains it, so it cannot
        discriminate between them. Returning a large value would make a query
        containing one typo score every document identically on that term and
        then rank by length, which looks like a relevance model and is not.
```

And one that matters for §6.19:

```python
# excerpt: atlas/rag/bm25.py
        Excluding zeros is a correctness decision, not a tidiness one. A query
        sharing no term with any document would otherwise return k documents at
        score 0.0 in index order -- an arbitrary list that looks exactly like a
        result and that section 6.16's abstention rule would then have to
        distinguish by score. Returning nothing says "nothing matched", which
        is the truth and is what an empty-retrieval check needs to see.
```

`search` also takes an `only` set, which restricts the candidate pool **before** scoring. That parameter exists because of F-06-07, and §6.15 is where it earns its keep.

**Why BM25 is not redundant with a dense index**, restated now you have both. IDF is a statistic *over the corpus*. An embedding is computed from *one text at a time*, so no embedding model — however good — can know that "warranty" is ubiquitous in your corpus and "saturation" is not. That is a property of the interface, not the weights, and it is why §6.6 called hybrid search **corpus-blind plus corpus-aware**.

Finally, the debugging tool the module would be useless without. When a chunk ranks unexpectedly high, the cause is almost always one term with a surprising IDF, and no amount of staring at the total will tell you which:

```python
# excerpt: atlas/rag/bm25.py
    def explain(self, query: str, doc_index: int) -> list[tuple[str, float, int, float]]:
        """Per-term (term, contribution, tf, idf), for reading a ranking.
```

> **Concept check 6.13.** Your corpus is 500 chunks and a term appears in 490 of them. Compute its IDF with the smoothing and without. Then say what the unsmoothed version does to the ranking for the query "the warranty terms".

### 6.14 [core] Fusion: two methods, one of which needs normalisation

You now have two rankings per query and must produce one. There are two mainstream methods and the difference between them is the actual lesson.

**Weighted score fusion** adds the retrievers' scores. To add them you must first make them comparable, and they are not. Measured on Atlas's corpus: cosines from the offline embedder run up to about 0.4; BM25 scores run up to about 12. Adding those directly is adding metres to kilograms, and the larger unit wins every query. So weighted fusion **requires a normaliser**, and every normaliser is a choice with consequences:

```python
# excerpt: atlas/rag/hybrid.py
    It is **per-query**: the same BM25 score of 4.0 normalises to 1.0 in a
    result set topping out at 4.0 and to 0.3 in one topping out at 12.0. So a
    normalised score is not comparable across queries and must never be
    compared against a fixed threshold -- which is exactly what section 6.16's
    abstention rule would do if it ran on fused scores. It runs on raw ones.
```

Read that twice, because it is the trap. **Any threshold you apply to a fused score is nonsense.** §6.19's abstention rule therefore never reads fused scores.

There is a subtler property of min-max that Atlas deliberately departs from the textbook on: a *single* result normalises to 1.0, the maximum, no matter how weak it was. A one-hit result set from a retriever that barely matched arrives at fusion looking like a perfect hit. Atlas leaves a singleton at 0.0 instead — the conservative reading — and there is a test named `test_a_lone_weak_hit_is_not_promoted_to_a_perfect_score`.

**Reciprocal rank fusion** (Cormack, Clarke and Büttcher, SIGIR 2009, pp. 758–759) throws the scores away and adds reciprocal ranks:

$$\text{RRF}(d) = \sum_{r} \frac{1}{k + \text{rank}_r(d)}$$

It needs no normalisation at all, because a rank is already on a common scale by construction. That is its entire appeal and why it is Atlas's default. A test asserts the property directly: multiply one retriever's scores by 100 and RRF returns the identical order.

The constant $k$ is the interesting parameter and almost nobody explains it:

```python
# excerpt: atlas/rag/hybrid.py
# 60, from the 2009 paper. Its effect is worth internalising: at k=60 the gap
# between rank 1 (1/61) and rank 2 (1/62) is about 1.6%, while at k=1 the gap
# between rank 1 (1/2) and rank 2 (1/3) is 33%. A large k says "agreement
# across retrievers matters more than position within one"; a small k says the
# opposite. 60 is firmly at the agreement end, which is what you want when
# neither retriever is trusted.
```

A chunk ranked second by *both* retrievers beats a chunk ranked first by *one* at $k=60$, and loses to it at $k=0$. Two tests pin both ends. That is Phase 5's voting lesson in a new costume: agreement across mechanisms with different failure modes is stronger evidence than confidence within one.

RRF's cost, because it is real: **it discards magnitude**, so it cannot tell first-place-by-a-mile from first-place-by-a-whisker. When one retriever is clearly better on your corpus, weighted fusion with a tuned weight beats it. When you do not know which is better, RRF is safer.

#### The measurement

Twenty documents, 28 chunks, structure-aware chunking, 28 labelled queries, Tier F `HashingEmbedder(dim=256)`, seed 7. Reported at $k=1$ — and the reason for that is the first finding.

| Arm | R@1 | R@2 | R@5 | MRR | clean R@1 | messy R@1 | gap | overlap |
|---|---|---|---|---|---|---|---|---|
| dense only | 0.679 | 0.821 | 0.929 | 0.781 | 0.750 | 0.500 | **+0.250** | 0.400 |
| sparse only | 0.857 | 0.929 | **1.000** | 0.917 | 0.900 | 0.750 | +0.150 | 0.400 |
| RRF | 0.857 | 0.929 | **1.000** | 0.917 | 0.900 | 0.750 | +0.150 | 0.400 |
| weighted, dense 0.3 | 0.857 | **0.964** | **1.000** | **0.923** | 0.900 | 0.750 | +0.150 | 0.400 |
| weighted, dense 0.5 | 0.857 | 0.929 | **1.000** | 0.917 | 0.900 | 0.750 | +0.150 | 0.400 |
| weighted, dense 0.7 | 0.821 | 0.929 | **1.000** | 0.899 | 0.900 | 0.625 | +0.275 | 0.400 |

Four things to read out of that, and the first is about measurement rather than retrieval.

**recall@5 saturates and is therefore not a measurement here.** Every arm scores 1.000, including the arm visibly worst at $k=1$. With 28 chunks and $k=5$, retrieval returns 18% of the entire corpus — at that ratio a mediocre ranker looks perfect. **A recall@k figure is uninterpretable without the corpus size beside it**, and any paper, blog post or vendor benchmark quoting recall@5 without it is telling you nothing. `evals/retrieval_eval.py` prints a warning when $k$ exceeds a quarter of the index, so this cannot be missed.

**The offline embedder is the weakest arm**, 0.679 against sparse's 0.857. Expected, and the honest consequence of §6.4: a lexical stand-in has no IDF and no synonyms, and BM25 has IDF. A real embedding model should invert this on the clean corpus — that is a Tier H measurement, `docs/RESULTS.md` rows 1–3, not a claim here.

**The retrievers overlap on only 40% of their hits.** That is the number justifying the hybrid's existence. At 0.95 the second index would be costing build time for nothing; at 0.05 one of them would be broken.

**The clean-messy gap is largest on the dense arm and smallest on the sparse arm.** +0.250 against +0.150, and there is a mechanism: on OCR-damaged and column-interleaved text, exact term matching degrades more gracefully than smoothed vector similarity. `24 months` survives OCR perfectly and BM25 matches it exactly; the word `extended` became `aed` and the dense vector of the whole chunk shifted. **Damaged text is a case where the sparse retriever is not the backup, it is the primary.** I did not expect that before measuring it, and it is the strongest single argument in this phase for running both.

### 6.15 [core] Filtering, and the two places it can go

A filter is a metadata predicate: only this document set, only pages after this date, only chunks that are not blocking. The distinction that matters is *where* it runs.

**Pre-filtering** narrows the candidate set, then ranks it. It always returns the best $k$ *among matching chunks*, which is what you asked for. On a brute-force store it is also strictly cheaper, because you score fewer vectors.

**Post-filtering** ranks first, then discards non-matching hits. It is what ANN indexes force on you, because the index structure cannot be traversed under an arbitrary predicate. And it has a failure mode with a name: if you retrieve 20 and your filter matches 1% of the corpus, you get **zero** results — not because nothing matched, but because nothing matching was in the top 20. The system reports an empty retrieval for a query with a perfectly good answer in it.

So a filtered ANN search needs over-fetching, and how much is a function of your filter's selectivity, which you have to measure. This is the single most common reason a production RAG system "loses" documents after somebody adds a filter.

#### And I shipped it, in the code that teaches it

The first version of `DocumentIndex.search` passed its predicate to the dense store, which pre-filters correctly, and then took BM25's **unfiltered** top-$k$ and discarded non-matching hits. Measured: a filter selecting one document of twenty returned `n_sparse=0`. So the hybrid silently degraded to dense-only under any selective filter — exactly the failure this section warns about, two modules from the paragraph warning about it.

```python
# excerpt: atlas/rag/index.py
        # PRE-filter, by restricting the candidate set BM25 scores over -- not
        # by taking its top-k and discarding. The first version post-filtered,
        # and a filter selecting one document of twenty returned n_sparse=0:
        # the hybrid silently degraded to dense-only under any selective
        # filter, which is exactly the failure section 6.15 warns about, in the
        # code that teaches it. See F-06-07.
```

The concrete case now pinned by a regression test: for the query `"months"` at $k=1$, `fsb-2026-04` is not in BM25's unfiltered top-1, so a post-filter returns nothing and a pre-filter returns it.

Worth naming the *pattern*, because §6.19 has the same shape: **both defects are the composition layer failing to honour a rule its leaf modules enforce.** `VectorStore.search` pre-filters correctly. `BM25Index.search` gained an `only` parameter and pre-filters correctly. The module that *combines* them did the wrong thing to one of them. This is invariant 46, and §9 makes it a pitfall.

And the filter Atlas deliberately does **not** apply by default:

```python
# excerpt: atlas/rag/index.py
        `exclude_blocking` drops chunks from documents whose extraction
        produced a sentence no document contains. It defaults to **False**, and
        that is deliberate rather than lazy: dropping them silently would make
        a question about the field-service bulletin unanswerable with no
        explanation, which is worse than answering it with a flagged citation.
        Section 6.16 makes the flag change the *answer*, not the *index*, and
        section 8 is the trace of getting this wrong in the other direction.
```

**A damaged document is not removed from the index; its damage is attached to the answer.** Quarantine is the tempting design and it is worse: the user asks a reasonable question, gets nothing, and has no way to learn that the document exists and is broken. Attaching the flag gives them an answer *and* the reason to doubt it. Assignment 1 makes this a policy you can configure and defend, and D-33 records the split.

### 6.16 [core] Reranking, and the mistake everyone makes first

A reranker reorders a candidate list. Its value comes from an asymmetry in cost:

```python
# excerpt: atlas/rag/hybrid.py
    A reranker's job is different from a retriever's, and the difference is
    what makes it worth a second pass. A retriever must score every chunk in
    the corpus, so it can only afford a cheap representation -- one vector, or a
    bag of terms. A reranker sees twenty candidates, so it can afford to look
    at the query and the chunk *together*.
```

That last phrase is the substance. A dense retriever embeds the query and the chunk *separately* and compares the results — it never sees them side by side. A cross-encoder reranker reads `(query, chunk)` as one sequence, so it can notice that the chunk's "12 months" is in the same clause as its "S400" rather than forty lines away. That is information no single-vector retriever can represent, at any dimension.

Atlas's free reranker approximates two parts of it deterministically — term **coverage** and term **proximity** — so the whole path runs offline. One implementation detail matters more than the scoring:

```python
# excerpt: atlas/rag/hybrid.py
    # Sort by score descending, then by INCOMING POSITION ascending. The second
    # key is what makes a reranker that finds no signal a no-op rather than a
    # shuffle: with coverage tied at 0.0 across all candidates, the retriever's
    # order survives. A reranker that can only ever help is a reranker you can
    # leave switched on.
```

**Now the mistake.** Reranking cannot improve recall@$k$ if you retrieved exactly $k$ candidates. The reranker only reorders what it was given, so the *set* is unchanged and recall@$k$ is identical by construction. Measured, printed by every `make results` run so it cannot be missed:

```
retrieve 5 -> rerank 5 (NO-OP): recall@5 1.000 -> 1.000  (must be equal)
```

**Retrieve wider than you keep**, and Atlas's default is 20 candidates to 5 kept.

And here is the honest result at the discriminating $k$ values, which is more interesting than a success story:

| $k$ | recall before | recall after | MRR before | MRR after | messy before | messy after |
|---|---|---|---|---|---|---|
| 1 | 0.857 | **0.786** | 0.857 | 0.786 | 0.750 | **0.500** |
| 2 | 0.929 | **0.893** | 0.893 | 0.839 | 0.875 | 0.750 |
| 3 | 1.000 | **0.964** | 0.917 | 0.863 | 1.000 | 1.000 |
| 5 | 1.000 | 1.000 | 0.917 | **0.870** | 1.000 | 1.000 |

Tier F, 28 chunks, 28 queries, 20 candidates, seed 7.

**The free reranker is uniformly harmful or neutral.** It is not a bug, and the explanation is the useful part: **my reranker is lexical and my Tier F retriever is also lexical, so the reranker is a second opinion from the same source.** It measures very nearly what BM25 already measured, so it adds no independent information and its noise is free to do damage. On Tier A or H, where the dense retriever is a real semantic model and the reranker is lexical, the two *do* fail differently and the reranker should earn its keep — `docs/RESULTS.md` row 7, not a claim here.

The general rule, and it is Phase 5's voting rule again: **a reranker must fail differently from the retriever, or it is not a second opinion, it is an echo.** Two mechanisms that agree because they are the same mechanism have not corroborated anything.

> **Misconception.** *"Add a reranker, get better retrieval."* Only if it is a different kind of model, only if you over-fetch, and only if you measured it. Anthropic's contextual-retrieval post (19 September 2024) reports reranking taking a top-20 retrieval failure rate from 2.9% to 1.9% — a real and substantial gain, measured with a trained cross-encoder over a contextualised hybrid index on their corpora. That is not transferable to yours, and their own post says to evaluate on your own use case.

### 6.17 [core] Retrieval evaluation: separately, always

This section determines whether everything before it was engineering or decoration.

**Evaluate retrieval separately from generation.** A RAG system has two halves that fail differently. If the answer is wrong, either retrieval did not deliver the evidence or generation did not use it, and those have opposite fixes — tune the chunker versus fix the prompt. One end-to-end score cannot distinguish them, so every regression triggers the same investigation from scratch. This is invariant 43, and `evals/retrieval_eval.py` is it made runnable: no model, about a second, one table.

The metrics, defined precisely because they are quoted loosely everywhere.

**recall@k**: the share of labelled queries for which at least one of the top $k$ hits comes from a gold document. It answers "did the evidence reach the context window", the only question retrieval can be held responsible for.

**span recall@k**: the share for which the labelled answer span appears in the concatenated text of the top $k$ hits. Strictly harder, and **the gap between the two is the number that matters**:

```python
# excerpt: atlas/rag/evaluate.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def found_document_but_not_answer(self) -> bool:
        """The chunking-failure signature: right document, wrong sentence."""
        return self.hit and not self.span_hit
```

Right document, wrong sentence is a **chunking** failure, not a ranking failure, and it is invisible to recall@k alone. If your recall is 0.95 and your answers are still bad, this is the first number to compute.

**MRR**: mean of $1/\text{rank}$ of the first gold hit. Position-sensitive in a way recall is not, which matters because a generator reading five chunks weights the first most.

**precision@k**: reported and rarely decisive. With one gold document and $k=5$ the ceiling is 0.2, so a "low" precision here is arithmetic rather than a finding.

**empty rate**, tracked apart from recall, because a miss means the ranking is wrong and an empty result means nothing matched — different fixes.

#### The labelled set, and D-29

The most consequential decision in this module:

```python
# excerpt: atlas/rag/evaluate.py
    D-29, and it is the difference between an eval set that survives this phase
    and one that expires halfway through it. A chunk id is a function of the
    chunk size, so chunk-level labels become wrong the moment you tune the
    chunker -- which is the experiment the labels exist to support. Document ids
    and answer spans are properties of the corpus and survive every chunking,
    embedding and fusion change you will make.
```

**Label documents and answer spans, never chunk ids.** The labels live in the corpus manifest and are written by the same generator that writes the corpus, so they cannot drift — D-20's requirement applied to retrieval. And span matching is deliberately conservative: it folds whitespace and case and does **not** strip punctuation or fold digits, because stripping punctuation would make `0.2 nm` match `02 nm`.

#### One query the system can retrieve and must refuse

`q21` — *"how often must the S400 detector be recalibrated"* — is gold **only** in `fsb-2026-04`, the column-interleaved bulletin. So retrieval scores it a hit and §6.19's generation must refuse it. Both are correct, and the combination looks like a contradiction unless the report names it:

```
clean-messy recall gap: +0.000
of which 1 answerable only from damaged text: retrievable, and NOT publishable (D-33)
```

`damaged_only` is **derived** from the corpus, not hand-listed: a query is damaged-only when every one of its gold documents has a blocking extraction. **A retrieval metric measures whether the evidence arrived; it says nothing about whether the evidence may be quoted.** Keeping those separate is what lets recall@5 = 1.000 sit honestly beside an answer the system withholds.

#### The clean/messy split is the headline, not a breakdown

```python
# excerpt: atlas/rag/evaluate.py
    The split is not an optional breakdown, it is the headline. A single
    corpus-wide recall figure over a corpus that is 20% damaged hides the
    damage almost perfectly: four bad documents out of twenty move an average
    by a few points and can be dismissed as noise, while the per-corpus split
    shows a gap of tens of points that cannot. Invariant 43.
```

Look at the numbers again. Dense corpus-wide R@1 is 0.679 — mediocre but not alarming. Split it: clean 0.750, messy **0.500**. The system fails half the questions about a fifth of the corpus. Those are the same measurement, and only one of them would survive a status meeting. `evals/retrieval_eval.py` therefore takes `--fail-under` and `--fail-under-messy` as **separate** floors, and warns if you set only the first.

#### The chunk-size and strategy experiments, measured

Recursive chunking, RRF, 20 candidates, Tier F, seed 7:

| size / overlap | chunks | chars embedded | R@1 | R@3 | R@5 | MRR | span@5 |
|---|---|---|---|---|---|---|---|
| 200 / 40 | 58 | **8,120** | **0.929** | 1.000 | 1.000 | **0.964** | 1.000 |
| 300 / 60 | 33 | 7,557 | 0.821 | 0.964 | 1.000 | 0.890 | 1.000 |
| 450 / 90 | 22 | 7,051 | 0.821 | 1.000 | 1.000 | 0.899 | 1.000 |
| 600 / 120 | 22 | 7,111 | 0.786 | 1.000 | 1.000 | 0.881 | 1.000 |
| 900 / 150 | 20 | **6,873** | 0.786 | 1.000 | 1.000 | 0.881 | 1.000 |
| 1400 / 200 | 20 | 6,873 | 0.786 | 1.000 | 1.000 | 0.881 | 1.000 |

And the four strategies at 900/150:

| strategy | chunks | chars embedded | R@1 | R@5 | MRR | messy R@1 |
|---|---|---|---|---|---|---|
| fixed | 20 | 6,873 | 0.786 | 1.000 | 0.881 | 0.625 |
| recursive | 20 | 6,873 | 0.786 | 1.000 | 0.881 | 0.625 |
| structure | 28 | **6,857** | **0.857** | **1.000** | **0.917** | 0.750 |
| semantic | 44 | 6,849 | **0.857** | 0.964 | 0.905 | **0.875** |

Five findings, all things a student would otherwise take on faith.

**Smaller wins on R@1, and it is not free.** R@1 declines from 0.929 to 0.786 as size grows. But the 200-character configuration embeds **18% more characters** than the 900-character one, because every character in an overlap region is embedded twice and there are three times as many overlaps. That is the number a chunk-size experiment must report or it will conclude smaller is free.

**Below the document length, chunk size stops being a parameter.** 900 and 1400 give byte-identical results because the longest document is 881 characters, so both produce one chunk per document. If a sweep shows two configurations agreeing exactly, check whether you are varying anything.

**Structure chunking is the only free lunch in the phase**: best R@1, best MRR, *and* fewest characters embedded, because merging bare headings removes five content-free chunks.

**Semantic chunking has the best messy R@1** (0.875), which contradicts my own docstring's dismissal of it. That row was invisible until this phase's revision, because `build_index` never forwarded the embedding function semantic chunking needs, so the strategy raised unconditionally and `make results` printed `semantic SKIPPED` into the table. That is **F-06-06**, and the lesson is in §9: a blank cell in a comparison table is a result nobody measured.

**Span recall is 1.000 everywhere**, so on this corpus there is no right-document-wrong-sentence failure. That is a property of a corpus of short structured notes and will not hold on yours. The metric is here so that when it drops, you know what dropped.

> **Concept check 6.17.** Your recall@5 is 0.91 and span recall@5 is 0.62. Answers are frequently wrong. Which half of the system do you fix, what is the specific defect, and which of the four chunking strategies would you try first?

### 6.18 [core] Operations: refresh, versioning, cost

**Refresh compares content hashes, never ids.**

```python
# excerpt: atlas/rag/index.py
        The comparison is on `content_hash`, never on `chunk_id`. Inserting a
        paragraph into a document shifts every ordinal after it, so an
        id-based diff reports the whole document as changed and re-embeds all
        of it; a content hash reports only the chunks whose text actually
        moved. On the seeded corpus, editing one document of twenty re-embeds
        about 5% of the chunks instead of 100%.
```

Measured by test: editing one of five documents re-embeds exactly one chunk, reuse rate 0.8, and the embedder's call counter advances by exactly one. Editing nothing embeds nothing and the counter does not move — invariant 41's test, that a counter has a line that increments it on a real path and a test that runs that path.

**Versioning is the manifest.** An index records its embedder fingerprint, its chunker and parameters, and a content hash per chunk. That buys the mismatch refusal, the cheap refresh, and a `docs/RESULTS.md` row that can say which configuration produced it. The live embedder is excluded from the dump — it is an object, not data — and a reloaded index that cannot check its own fingerprint refuses to search rather than guessing.

**Cost.** Index build cost is chunks × chars per chunk against your embedding rate, and `CachingEmbedder` is what makes a re-index affordable. Query cost is one embedding call plus arithmetic. Rate cards are dated data in `VERSIONS.md`, and per D-24 a cost figure prints only with its card's `checked_on` date.

### 6.19 [core] Grounded generation: who decides the evidence was enough

Retrieval hands the generator five extracts. Its job is to answer from them and only them, cite what it used, and say so when they do not answer the question. That last part is the whole difficulty, because a fluent model would much rather produce a paragraph.

So the design rule, Phase 5's D-25 arriving where it matters more:

```python
# excerpt: atlas/rag/generate.py
    `extra="forbid"` because the model fills it (invariant 13, D-04). What is
    absent is the point: no `sufficient`, no `grounded`, no `confidence`. A
    model that could set those would be grading the evidence it was handed,
    and the one answer we most need -- "this does not answer the question" --
    is the one it is least likely to volunteer.
```

Two fields: `answer` and `cited`. A test asserts the field set is exactly those two and that `confidence`, `grounded`, `sufficient` and `accept` are absent, because the tempting addition is exactly the forbidden one. The prompt says the same in words the model reads:

```
Do not judge whether the extracts are sufficient, whether your answer is
grounded, or how confident you are. Those are decided by the system from the
retrieval itself, and an assessment from you would be an assessment of your own
work.
```

**Abstention has eight computed causes**, three before the model call and five after, every one a member of a closed `Literal` with a line that sets it. A test reads the module source and asserts each reason is actually assigned — invariant 30, checked by reading rather than trusting.

The pre-call ones are free, and the reason to put them first is cost as well as correctness:

```python
# excerpt: atlas/rag/generate.py
    Before, not after, and that is a cost decision as well as a correctness
    one: an empty retrieval that goes to the model costs a call and returns a
    fluent paragraph about warranties in general. Phase 5's §8 was a
    well-formed empty tool result becoming a statement about the world; this
    is the same failure with a retriever in place of a search tool, and the
    cheapest fix is not to make the call.
```

A test named `test_abstention_costs_no_model_call` passes a `FakeLLMClient` with **no fixtures at all**: if the code reached the model, it would raise. That is how you assert a call did not happen.

#### The defect that mechanism shipped with, and the threshold-free fix

The first version checked `report.empty` and a score floor. Then I measured it:

```
'zzzqqq vvvv nonexistent terminology': fused=5 dense=20 sparse=0 empty=False
'xylophone marmalade quantum':         fused=5 dense=20 sparse=0 empty=False
```

**A brute-force dense retriever never returns empty.** It ranks every chunk, so it cheerfully returns five results for `xylophone marmalade quantum`. And the default score floor was 0.0, which disables the floor. So the abstention mechanism I had just built could only ever fire on the sparse-only arm. It was tested, it worked in its tests, and it was wired to a condition that could not occur — **F-06-02**.

Raising the default floor is the obvious fix and the wrong one, because §6.14 established that a similarity threshold does not transfer between models or corpora. The fix that needs no calibration:

```python
# excerpt: atlas/rag/generate.py
    # The fix needs no threshold, which matters because section 6.14 showed a
    # threshold does not transfer between models or corpora. If the SPARSE
    # retriever returned nothing, then no chunk in the corpus shares a single
    # scoring term with the query, which is the honest definition of "nothing
    # matched" and is free, deterministic and corpus-independent. This is
    # D-22's shape: a free deterministic mechanism must agree, or abstain.
```

**The corpus-aware retriever is used as a free deterministic verifier for the corpus-blind one** — Phase 5's D-22 applied to the decision to speak at all. Measured: **zero false abstentions across all 28 labelled queries**, and it fires on gibberish with zero model calls. The `dense_only` arm is explicitly exempt, or §6.14's control arm would abstain on everything.

**And it is not enough.** §12's forward pointer and F-06-05 have the measurement: over five hand-written unanswerable questions it refuses **one**. Read that honestly before trusting the mechanism.

#### Citations are checked, not trusted

The model returns extract *numbers*, not chunk ids:

```python
# excerpt: atlas/rag/generate.py
    Numbering is 1-based and positional, so `cited` maps back by position and
    the model never has to reproduce a chunk id. Asking a model to echo
    `fsb-2026-04#0003` is asking it to copy a string it has no way to verify,
    and Phase 3 measured what happens: it produces a plausible one.
```

Code resolves them. An out-of-range number is a **fabricated citation** and goes in `unresolved`, where an eval check can see it; a duplicate is dropped without comment, because citing extract 3 twice is untidy and citing extract 9 of 8 is dishonest.

And the handler no longer takes the model's word for its sources:

```python
# excerpt: atlas/flow/app.py
            # The citation block IS the sources field. Phase 3 required a
            # sources line and let the model write it; retrieval means the
            # harness can write it from resolved chunk ids instead, which is
            # the difference between a claim of provenance and provenance.
```

### 6.20 [core] Faithfulness versus relevance versus correctness

Three properties, routinely conflated, with three different fixes.

**Relevance** is retrieval's property: did the extracts have anything to do with the question. Measured by recall@k and MRR.

**Faithfulness** is generation's property: does the answer say only what the extracts say. Atlas checks one mechanical slice for free:

```python
# excerpt: atlas/rag/generate.py
    It catches a **fabricated figure**: the answer says 18 months, no cited
    extract contains 18, and that is a hallucination the citation format would
    otherwise dress up as sourced. This is the single most common grounding
    failure in a RAG system and it costs nothing to detect.
```

Numbers, dates and codes are where fabrication does damage and where detection is trivial. Thousands separators are folded so `1,200` matches `1200`. Years are **not** exempted — exempting them is how `12 months` quietly stops being checked.

**Correctness** is the property nobody at this layer can check:

```python
# excerpt: atlas/rag/generate.py
    It does NOT catch a figure that is genuinely present in a chunk whose text
    the source document never contained. Section 8's answer passes this check
    perfectly. Faithfulness to a chunk is not correctness, and no check at this
    layer can be, because the defect is two layers upstream.
```

There is a test named `test_the_number_check_cannot_catch_section_eights_defect`, asserting the check passes on the fused sentence. It exists so nobody mistakes a faithfulness check for a correctness guarantee.

The three-line summary worth memorising: **an irrelevant retrieval gives you an answer about the wrong thing. An unfaithful generation gives you an answer the sources do not support. A faithful answer from a corrupted chunk gives you a wrong answer with perfect provenance — and only ingestion can prevent it.**

> **Concept check 6.20.** For each, name the layer to fix: (a) the answer cites extract 4, which is about a different product; (b) the answer states a discount rate appearing in no extract; (c) the answer correctly quotes a chunk whose numbers came from the wrong table row; (d) the system answers confidently about a document not in the corpus.

---

## 7. [core] Hands-on: build it step by step

Ten steps. Each is under twenty minutes, and every step ends in something you can run. Work in the repo at tag `phase-05`.

**Step 1 — generate the corpus.** `scripts/gen_docs.py` holds 16 clean Markdown documents, 4 messy ones as frozen extractor output with `.meta.json` sidecars, and 28 labelled queries. Wire `build_document_corpus` into `gen_dataset.py`'s `build_all` and run `make data`:

```
{'clean': 16, 'messy': 4, 'total': 20, 'messy_share': 0.2, 'queries': 28}
```

The 20% messy share is what makes §6.17's clean/messy split a measurement rather than an anecdote. The messy documents ship as `.rawtext` rather than PDFs so `make test-offline` needs no PDF backend (invariant 2), while `make data ARGS=--with-pdf` rebuilds the originals for anyone with the optional extra. Two tests assert the share is exactly 20% and that each messy document produces the damage flag it claims.

**Step 2 — the embedding layer.** Build `atlas/rag/embed.py` from §6.4. Do the pure functions first — `dot`, `cosine`, `l2_normalise` — and their tests, because everything else is arithmetic over them. Then `HashingEmbedder`. Write the subprocess determinism test *before* `_bucket`; it is the only test that can catch the `hash()` defect, and writing it afterwards means writing it never.

**Step 3 — extraction and quality flags.** Build `atlas/rag/extract.py`. Take the frozen extraction outputs as your test fixtures. Implement the detectors in §6.8's frequency order, and after each one run `make ingest`. You are looking for exactly this:

```
warranty-policy              p1  394c usable=True  []
calibration-tolerances-2026  p1  386c usable=True  ['suspect_reading_order', 'flattened_table']
fsb-2026-04                  p1  881c usable=False ['interleaved_columns']
quarterly-ops-review-2026q2  p2  659c usable=True  ['suspect_reading_order', 'boilerplate_repetition']
warranty-amendment-a-2026-2  p1  326c usable=True  ['suspect_reading_order', 'ocr_low_confidence']
```

Sixteen clean documents with empty flag lists, four messy ones each carrying its own damage class, exactly one blocking. If a clean document has a flag, your threshold is too tight; if a messy one is clean, your detector is not firing.

**Step 4 — chunking.** Build `atlas/rag/chunk.py`. Implement `fixed` first because it is the control, then `recursive`, then `structure`, then `semantic`. Print the chunks for `warranty-policy` under each and *read them*. You should see fixed chunking cut `Consumables` in half, and — before you add the bare-heading merge — a 24-character title chunk that has no business being in an index.

**Step 5 — the search stack.** `bm25.py`, `store.py`, `hybrid.py`. Build BM25 before the vector store: it needs no embedder, so you get a working retriever in forty lines and something to compare the dense side against. Assert IDF is floored at zero and that the eight-times-"warranty" fixture does not win a warranty query.

**Step 6 — evaluation, before tuning anything.** Build `atlas/rag/evaluate.py` and `load_labelled`. This comes *before* the index because the temptation is to tune first and measure later, and every hour spent tuning without a labelled set is an hour of anecdote. Label documents and spans, never chunk ids (D-29).

**Step 7 — the composed index, then the sweeps.** Build `atlas/rag/index.py` and run §6.14's and §6.17's experiments. Your numbers will match this document's if your seed is 7. Four things to look for: recall@5 saturating at 1.000 for every arm; the dense/sparse clean-messy gap at +0.250 against +0.150; the 200-character configuration embedding 18% more characters than the 900-character one; and **all four chunking strategies producing a row**. If one of them prints `SKIPPED`, you have F-06-06 and §9 explains why it matters.

**Step 8 — a second backend, to test the interface claim.** Build `atlas/rag/backends.py` and `tests/test_rag_backends.py` as **one** conformance suite parameterised over both stores. This step is optional for the fast track and it is the step that converts §6.12 from an assertion to a test. If you have the extra installed, run it; you will discover things a single-implementation interface hides. I did — see F-06-09.

**Step 9 — grounded generation.** Build `atlas/rag/generate.py` and the `atlas_grounded.v1.md` prompt. Write the abstention paths before the happy path. Then run the `FakeLLMClient` scenarios: a good answer, an empty retrieval, a fabricated number, a fabricated citation, an answer citing nothing, and an answer whose only source is blocking. Six fixtures, six outcomes, no model.

**Step 10 — wire it into the front door.** Add the `index` parameter to `build_handlers` and `handle_request`. It is defaulted, so every Phase 5 caller keeps working:

```python
# excerpt: atlas/flow/app.py
            "document": document_rag if index is not None else react_handler("document"),
```

The fallback is a decision, not politeness:

```python
# excerpt: atlas/flow/app.py
    The fallback is not politeness. A retrieval handler with no index would
    have to either raise -- taking down the whole front door because one route
    is unconfigured -- or answer with no evidence, which is the failure this
    phase exists to prevent. Falling back to a capable read-only handler is
    D-22's rule applied to a missing dependency rather than to an ambiguous
    request.
```

Run `make test-offline`. Every Phase 5 test must still pass untouched — that is the check that this was a handler upgrade and not a rewrite. Then `make check-docs`: if it fails on a Phase 5 excerpt, that is the drift guard working, and §11 says what to do about it.

### With an assistant

**Safe to delegate.** The mechanical, high-volume, verifiable work. The 16 clean corpus documents — give it the four departments, four products and the topic list; you will read them anyway. The BM25 arithmetic from §6.13's formula, then check its `bm25_idf` against your own hand-computed value for $N=10, n=9$. The recursive chunker's separator descent, which is fiddly index bookkeeping with an obvious test. Test *bodies* once you have written the test *names*. The Chroma adapter's plumbing, once you have specified the three behavioural differences it must document.

**Not safe to delegate.** Five things, and they are the five this phase is about.

*The quality thresholds.* An assistant produces plausible constants and no measurement. §6.9's finding — that the text-only interleave detector ranks a good document above a broken one — is invisible without running it on your corpus, and an assistant asked for an interleave detector will hand you one and tell you it works.

*The labelled query set.* This is your specification of what "correct retrieval" means. Delegating it means grading your system against somebody else's idea of your users, and the gold spans in particular need choosing by someone who knows which sentence actually answers the question.

*The abstention conditions.* An assistant asked for grounded generation will very likely give the model a `confidence` field, because most code on the internet does. That is D-25 inverted, and it is the difference between a system that says "I could not find that" and one that never does.

*Reading the extraction output.* Nobody can do this for you. Twenty minutes, and the highest-value twenty minutes in the phase.

*Anything where a fixture claims provenance.* If you delegate the OCR fixture, you will get an array of plausible confidence values, and no note that they were invented. I did this to myself without an assistant's help — F-06-08 — so the failure mode is not exotic.

**A prompt that works:**

> Implement BM25 scoring in a new module `atlas/rag/bm25.py`, using this exact formula: [paste §6.13's formula]. Requirements: pure functions `bm25_idf(n_docs, n_containing)` and `bm25_term_score(tf, doc_len, avg_len, idf, *, k1, b)`; use the `ln(1 + (N-n+0.5)/(n+0.5))` smoothed IDF and explain in a comment what the unsmoothed form does for a term in >50% of documents; a `BM25Index` Pydantic model storing term frequencies and document frequencies but NOT the document text; `search(query, *, k, only=None)` must exclude zero-scoring documents rather than padding to k, must break ties by insertion order deterministically, and `only` must restrict the candidate set BEFORE scoring rather than filtering the top-k afterwards. Import `tokenise` from `atlas.rag.embed` — do not write a second tokeniser. No numpy. Then write pytest tests asserting: IDF is non-negative for n=N; term frequency saturates (the 9→10 increment is under a fifth of the 1→2 increment); a document repeating one query term eight times does not outrank a document that answers the query; ties break by position; and `only=` returns a document that is *not* in the unfiltered top-1.

The specificity is the point. Every clause is a decision I made and can defend, several of them because I got them wrong first, and the assistant is doing the typing.

---

## 8. [core] Debug this trace

A support engineer asks Atlas how often the S400 detector needs recalibrating. Here is the trajectory, verbatim.

```
r-0042: document (confidence 1.00, source forced)

RETRIEVED (rrf, 20 candidates, 5 kept)
[1] lamp-replacement#0000              score=0.032266 flags=[]
[2] error-codes-s400#0000              score=0.031319 flags=[]
[3] fsb-2026-04#0000                   score=0.031258 flags=['interleaved_columns']
[4] calibration-procedure#0000         score=0.030550 flags=[]
[5] safety-notices#0000                score=0.029828 flags=[]

EXTRACTS SENT TO THE MODEL
[3] fsb-2026-04 p.1
FIELD SERVICE BULLETIN FSB-2026-04 Portable units.
Recalibration intervals. The T100 temperature logger requires
The S400 benchtop spectrometer detector recalibration after 6 months of continuous
requires recalibration after 12 months of operation. The shorter interval reflects the
continuous operat …

ANSWER
The S400 detector requires recalibration after 6 months of continuous operation.

[3] fsb-2026-04 p.1  ⚠ interleaved_columns
!! DO NOT ACT ON THIS ANSWER without checking the sources

RECORD
  abstained              False
  abstain_reason         None
  unresolved             []
  unsupported_numbers    []
  top_score              0.032266
  trustworthy            False
  flags                  ['interleaved_columns']

r-0042 route=document calls=1 tools=0 cache_hits=0 tokens=666 latency=0.00s
  PARTIAL: caveat this answer
```

**The answer is wrong.** The S400 interval is 12 months. Six months is the T100's, and it is in the other column of a two-column page.

Before reading on: which of these checks failed? Retrieval, citation resolution, the faithfulness check, the partial label, the prompt.

### The diagnosis

The uncomfortable answer is that **retrieval was fine and every mechanical check behaved exactly as designed.**

Extract [3] is the right document — `fsb-2026-04` is the bulletin about recalibration intervals, and gold for this query. Recall@5 counts this as a **hit**. The citation resolves to a real chunk. `unresolved` is empty because 3 is in range. `unsupported_numbers` is empty because **6 genuinely appears in the cited text**, so the answer is perfectly faithful to its source. And the source sentence is grammatical, fluent, and about exactly the right subject:

> The S400 benchtop spectrometer detector recalibration after 6 months of continuous

It is also a sentence the document does not contain. A y-sorting extractor read across the gutter and joined the left column's line ending `...detector` to the right column's line beginning `recalibration after 6 months of continuous`. §6.8.5 measured this happening.

So this is Phase 3's §8 (right answer, fabricated provenance) and Phase 4's §8 (wrong answer, immaculate provenance) followed by something new: **wrong answer, immaculate provenance, faithful to its source, and the source is a sentence nobody wrote.**

Now four separate defects, because "the extraction was bad" is a cause and not a diagnosis.

**Defect 1: the blocking flag reached the record and never reached the prompt.** This is the real bug and it is mine. `render_extracts` emitted a warning line for `WARNING_FLAGS` only, on the stated reasoning that blocking flags were "handled earlier and differently, by abstention". But `pre_check`'s blocking rule fires only when **every** hit is blocking. One blocking extract among four clean ones falls between the two mechanisms, and extract [3] went to the model wearing no caveat at all. The flag propagated correctly through extractor → document → chunk → hit → citation → record, and was consumed by nothing that could act on it. **A flag that reaches the audit trail and not the decision is a flag that documents your failure instead of preventing it.** Logged as **F-06-03**.

**Defect 2: the caveat named no defect.** `DO NOT ACT ON THIS ANSWER without checking the sources` is a caveat a reader can only ignore. It does not say what is wrong, so it does not say where to look, so it reads as boilerplate — and a caveat that reads as boilerplate trains people to skip caveats, including the one that mattered. Phase 5's F-05-07 defect 4 was a caveat nobody saw; this is a caveat nobody could use. **F-06-04**.

**Defect 3: a claim rested entirely on a manufactured sentence, and the system published it.** §6.15 argued — correctly — against quarantining damaged documents: removing them makes a reasonable question unanswerable with no explanation. But "index it and attach a flag" was too coarse. Indexing a damaged document is right. Letting an answer's *only* support be a fused sentence is not.

**Defect 4: the correct answer was in the same chunk, three words away.** The next line reads `requires recalibration after 12 months of`. The model had both and chose the fused one, because the fused one is a complete-looking clause containing the query's subject and the true one is a fragment. Nothing told it that this page's line breaks are untrustworthy.

### The fix, in order

The order matters and it is Phase 5's: **structural fixes first, prompt last, because the prompt is the only fix whose effect needs a measurement.**

**Fix 1 — a blocking flag reaches the prompt, louder than a warning**, with an explanation a model and a human can both use:

```python
# excerpt: atlas/rag/generate.py
FLAG_EXPLANATIONS: dict[str, str] = {
    "interleaved_columns": (
        "this page has two columns and the text was read across them, so a "
        "single line may join the ends of two unrelated sentences"
    ),
```

The extract now arrives as:

```
[3] fsb-2026-04 p.1
UNRELIABLE TEXT (interleaved_columns): this page has two columns and the text was
read across them, so a single line may join the ends of two unrelated sentences.
Prefer another extract if one answers the question.
FIELD SERVICE BULLETIN FSB-2026-04 Portable units.
```

A test asserts **every** flag in `WARNING_FLAGS ∪ BLOCKING_FLAGS` has an explanation over twenty characters, so a new flag cannot ship as a bare label.

**Fix 2 — the caveat names the defect.** `GroundedAnswer.render` prints one line per flag from the same table, last, where a reader's eye stops.

**Fix 3 — withhold a claim whose every source is blocking.** An eighth abstention reason:

```python
# excerpt: atlas/rag/generate.py
    # Every cited source is blocking: the claim rests entirely on text that
    # was manufactured by an extractor. Withhold it. This is not the same
    # decision as dropping the document from the index (section 6.15 argues
    # against that): the document is still searchable, still cited, and still
    # quotable ALONGSIDE a clean source. What is refused is a claim resting
    # only on a sentence no document contains.
```

The trace after the fix:

```
ABSTAINED (cited_blocking_source): the only source for this answer is
fsb-2026-04, whose extraction produced text the document does not contain;
read the source before believing any of it
The S400 detector requires recalibration after 6 months of continuous operation.
```

The wrong claim is still shown — a user about to go and read the source needs to know what the system thought it said — but `answered` is now `False`, so nothing downstream treats it as an answer. And a mixed citation set still answers, because one clean source is enough to make a claim:

```
The S400 source lamp lasts 2000 operating hours.

[1] lamp-replacement p.1 § Source lamp replacement
[3] fsb-2026-04 p.1  ⚠ interleaved_columns
!! interleaved_columns: this page has two columns and the text was read across
   them, so a single line may join the ends of two unrelated sentences
!! DO NOT ACT ON THIS ANSWER without checking the sources
```

**Fix 4 — the real fix, upstream.** Re-extract `fsb-2026-04` with a column-aware backend. §6.8.5 measured that this works exactly: group words by x-band, sort by y within each band, and the correct text comes back verbatim. Then the flag disappears, the chunk is clean, and none of fixes 1–3 ever fires for this document again.

**That is the lesson.** Fixes 1–3 are containment: they stop a corrupted chunk becoming a confident answer. They do not make the answer right. Only fixing the extraction does that, and no amount of prompt engineering, reranking or threshold tuning at the retrieval layer would have found it. **The failure was manufactured in the first ten minutes of the pipeline and every layer after it worked correctly on corrupted input.**

> **Concept check 8.** After fix 4, the interleave flag is gone from this document. Which of fixes 1, 2 and 3 would you keep, and why? Then: what would you have to add for the system to have *noticed* that extract [3] contained both `6 months` and `12 months` attached to the same subject?

---

## 9. [core] Common pitfalls & how professionals avoid them

**Tuning before measuring.** The most expensive mistake in the phase. Build the labelled set in step 6, before the index.

**Quoting recall@k without the corpus size.** Every arm in §6.14 scored recall@5 = 1.000, including the worst, because $k=5$ over 28 chunks returns 18% of the corpus. Report $k$, the corpus size, and a metric that has not saturated.

**One end-to-end score.** Grade retrieval and generation separately (invariant 43) and the failing number tells you which half to open.

**Averaging over a corpus with a damaged minority.** Corpus-wide dense R@1 of 0.679 looks mediocre. Split it and messy is 0.500. Same measurement; only one survives a status meeting. Set *separate* CI floors.

**Copying a similarity threshold from a blog post.** The offline embedder's confident hits score 0.098 and its misses 0.127. Any threshold you did not calibrate on your own model and corpus is noise, and a threshold on a *fused* score is worse than noise because min-max is per-query.

**Reranking exactly what you retrieved.** Measured: 0.964 before and after, identical. Retrieve 20, keep 5.

**Assuming a reranker helps.** Measured: uniformly harmful or neutral, because it echoes BM25. A reranker must fail *differently* from the retriever.

**Believing the dense retriever when it returns something.** It always returns something. Abstention needs a mechanism that can say no.

**Believing your abstention mechanism because it catches gibberish.** F-06-05: it caught 1 unanswerable question in 5. The four it missed share vocabulary with the corpus. **Lexical support is not evidence of an answer.**

**Guessing at damaged text.** `modi■ed` could be `modified` or `modifled`. A repair may restore information; it may not invent it.

**Letting a repair destroy the evidence of the defect it repaired.** F-06-01. A repair that exercises judgement must record that it acted.

**Letting a flag die one hop short.** F-06-03. Trace every provenance field to the place that acts on it; if there is none, wire one or delete the field.

**Chunk ids in the labelled set.** They expire the moment you tune the chunker.

**Indexing content-free chunks.** F-06-02: five heading-only chunks, one of which ranked *first* for the query it titled. Cosine's scale invariance — the property that makes it right — is exactly what lets a title outrank the paragraph beneath it.

**Post-filtering without over-fetching.** F-06-07, and I shipped it two modules from the paragraph warning about it.

**Trusting leaf tests to cover the assembly.** This is the pitfall this phase's revision earned, and it is the most transferable one here. Three defects — F-06-06, F-06-07, and a store field widened to `Any` that stopped round-tripping — were all the **composition layer failing to honour a rule its leaf modules enforced.** `chunk_document` correctly demanded `embed_one`; `build_index` never offered it. `VectorStore.search` correctly pre-filtered; `DocumentIndex.search` post-filtered the other retriever. Every leaf was tested thoroughly and the assembly was tested *through* the leaves' behaviour. Professionals write at least one test per closed set, per counter and per refusal condition that reaches it **through the composition callers actually use** (invariant 46).

**Writing `# not executed during authoring` without trying.** F-06-09. The marker is legitimate for code that genuinely cannot run in your environment. It is not a licence to skip the attempt — Chroma installs from PyPI in four minutes, and running the conformance suite failed nine tests immediately.

**A comment that asserts provenance a fixture does not have.** F-06-08. Numbers synthesised to reproduce a measurement are invented numbers. Pin fixtures to whatever the prose claims about them with a test.

**A blank cell in a comparison table.** F-06-06: `semantic SKIPPED` sat in the published table, and behind the SKIP was the strategy with the best messy recall. A blank cell is a result nobody measured.

---

## 10. [extended] Industry perspective

**Where teams actually spend the time.** The public story of a RAG project is embeddings and prompts. The private story is a fortnight on a PDF pipeline and a week discovering the tables mattered more than anyone said. Teams that ship early build the extraction quality report first and treat retrieval tuning as the easy part, because it is.

**The build-versus-buy line has moved and the failure mode has not.** Managed document-parsing services and layout-aware models now handle tables and columns far better than a hand-rolled pypdf pipeline. What they do not do is tell your generator that a particular page was hard: every one returns text, almost none returns a per-region confidence you can propagate to a citation. So the flag-propagation discipline here is not a substitute for a good parser — it is what you build on top of one, and §8 is what its absence costs.

**Hybrid is the default, and it is not controversial.** Anthropic's contextual-retrieval post (19 September 2024) reports its stack in exactly this order: contextual embeddings reduced top-20 retrieval failure from 5.7% to 3.7%; adding contextual BM25 took it to 2.9%; adding a reranker took it to 1.9%. Hybrid was worth roughly as much as the contextualisation itself, which is a strong statement about how much corpus-awareness buys. And their own post says to evaluate on your own use case.

**Contextual retrieval is the technique this phase deliberately did not build.** Prepend a sentence of document-level context to each chunk before embedding and indexing it, generated by a cheap model. It directly attacks the failure the structure chunker attacks by hand — a chunk that has lost the heading that gave it meaning. One model call per chunk at index time, which prompt caching makes affordable. Appendix F for the full build.

**Vector databases are a smaller decision than they look.** This phase ships two backends behind one interface and 25 conformance tests, and switching between them changes one string. Teams that treat the index as *derived data* — rebuildable from source in one command — swap vector stores in an afternoon and change embedding models in a day. Teams that treat it as a database do neither, which is how organisations end up two generations behind on embeddings.

**And the labelled set is never finished.** Every user complaint that turns out to be a retrieval miss becomes a labelled query; a mature eval set is mostly grown from incidents rather than written up front. Twenty-eight hand-written queries is the seed, not the crop.

### Interview questions

1. *Why cosine similarity rather than Euclidean distance, and under what condition are they equivalent?* Looking for: scale invariance and why text length should not affect topical similarity; then $\|a-b\|^2 = 2 - 2\cos\theta$ for unit vectors, so rankings are identical **once normalised** — the normalisation is the condition, not a detail. A strong candidate volunteers the cost: scale invariance is also what lets a title outrank its own section.

2. *Your hybrid search is worse than BM25 alone. Give three hypotheses and the measurement that distinguishes them.* Strong answers reach for the fusion arithmetic: unnormalised score fusion letting BM25's larger range dominate; an embedder/index fingerprint mismatch producing meaningless cosines; and retriever overlap so high that the dense arm adds only noise. The measurement is per-arm recall and MRR plus the overlap rate — and a candidate who asks for the corpus size before interpreting recall@5 is telling you something good.

3. *A user reports a wrong answer. It cites a real document and the cited chunk does contain the claim. Walk me through your investigation.* This is §8. Looking for an early check of whether the *document* says what the *chunk* says — suspicion of extraction rather than of the model. Weak answers go straight to the prompt.

4. *When would you not use retrieval?* Corpus small enough to fit in the prompt (roughly 200,000 tokens); the need is behavioural rather than factual, so fine-tuning; or the data is structured, in which case SQL beats embedding a serialised table — Atlas's `data` route and Phase 7's subject.

5. *How do you make a RAG system say "I don't know"?* Listen for: abstention **computed from the retrieval by code**, not requested from the model; and that a dense retriever never returns empty, so "no results" cannot be the mechanism. A candidate proposing a `confidence` field on the model's output has given the wrong answer to the most important question here. A candidate who then asks *how well* the mechanism works, and is unsatisfied by "it catches gibberish", is the one to hire.

---

## 11. [core] Capstone increment

*If your code diverged, start again from `atlas_phase_05.zip`.*

**Resume note.** At `phase-05` Atlas routed five kinds of request and ran a fanned-out research pipeline — but a document question went to an agent that guessed a filename and read whole files. At `phase-06`, **Atlas answers document questions with citations that resolve to specific chunks on specific pages, over a corpus of which a fifth is deliberately broken, and refuses to answer when the evidence is not there.** The `document` route's behaviour changed; the router, the account and the trace format did not.

### What Atlas can do now

Ingest 20 documents including a column-interleaved bulletin, a flattened table, a header-polluted two-page report and an OCR'd scan, flagging each one's damage. Chunk them four ways with page, heading, kind and quality flags attached. Search them with a dense index and BM25 fused by RRF or weighted score, pre-filtered by metadata on both sides, optionally reranked, over either of two vector-store backends behind one tested interface. Answer from retrieved extracts with numbered citations resolved by code, refuse to answer via eight computed abstention paths, and refuse to *publish* a claim resting only on manufactured text. Measure retrieval separately from generation, split clean from messy, with separate CI floors. Refresh the index on document change, re-embedding only the chunks whose text moved.

### Files touched

**New:** `atlas/rag/{embed,extract,chunk,bm25,store,hybrid,index,generate,evaluate,backends,hosted,pdfsource}.py` · `atlas/prompts/files/atlas_grounded.v1.md` · `scripts/{gen_docs,phase06_results}.py` · `evals/retrieval_eval.py` · `tests/test_rag_{embed,extract,search,generate,backends}.py` · `tests/hidden/test_phase06_a{1,2}.py` · `evals/tasks/phase06.json` · `data/docs/**` (generated).

**Changed:** `atlas/flow/app.py` · `atlas/prompts/{__init__.py,CHANGELOG.md}` · `atlas/rag/__init__.py` · `scripts/gen_dataset.py` · `evals/run.py` · `Makefile` (`PHASE=06`, `ingest`, `data ARGS=`) · `pyproject.toml` (optional `docs` extra) · `tests/test_{prompts,evals_harness}.py` · `ATLAS_INTERFACES.md` · `VERSIONS.md` · `docs/{DECISIONS,RESULTS,FAILURE_LOG}.md` · `phase_05_workflow_patterns.md` (one excerpt block plus a migration note).

### Interface changes

Three, all additive, and one broke a guard on purpose.

**`build_handlers` and `handle_request` gain `index: Any = None`.** Defaulted, so every Phase 5 call site keeps working — and when omitted the `document` route falls back to Phase 5's ReAct handler rather than raising. *Migration:* pass `index=build_index(...)` to get retrieval. `HandlerOutcome`, `RoutedResult`, `RequestAccount` and the trace format are untouched.

**`build_index` gains `threshold`, `backend` and forwards `embed_one`.** The last of those is F-06-06's fix and is not optional: without it, `strategy="semantic"` was unreachable.

**`BM25Index.search` gains `only`.** F-06-07's fix. *Migration:* none; the default is `None` and behaviour is unchanged.

**`ToolRegistry` is unchanged**, deliberately. Retrieval is *not* a tool this phase. A tool would let the model decide when to retrieve, and the `document` handler always retrieves — so the decision is not the model's to make (D-21). Retrieval becomes a tool in Phase 7, when `research` must choose between the index and the database, at which point the branch set genuinely cannot be enumerated in advance.

And the guard: the `app.py` edit stales an excerpt block quoted in `phase_05_workflow_patterns.md`, so `make check-docs` failed. **That is the guard working.** A published interface changed and the document describing it had to say so. Invariant 17 forbids deleting the block, so it is updated with a migration note.

### Tests added

**364 new offline tests**, taking the suite from 565 to **929**. `make test-offline` passes on a fresh clone with no network, no model, no `.env` and none of the optional extras.

Eight are worth naming because they assert things a normal test cannot:

- `test_vectors_are_stable_across_a_SEPARATE_PROCESS` — shells out with three `PYTHONHASHSEED` values; the only way to catch `hash()` used for feature hashing.
- `test_abstention_costs_no_model_call` — empty fixture list, so reaching the model would raise.
- `test_interleave_suspicion_does_not_separate_the_classes` — pins a **measured negative result**, so a future "improvement" fails and forces re-measurement.
- `test_the_number_check_cannot_catch_section_eights_defect` — asserts a check *fails to help*.
- `test_every_chunk_strategy_is_reachable_through_build_index` — enumerates a closed `Literal` **through the composition** (F-06-06).
- `test_a_filtered_search_still_gets_a_sparse_ranking` — the pre-filter regression, with a query where the answer is genuinely outside the unfiltered top-1 (F-06-07).
- `test_the_frozen_ocr_fixture_matches_the_prose` — pins a fixture to the statistics this document quotes (F-06-08).
- `tests/test_rag_backends.py` — 25 tests, one suite, both backends, so §6.12's interface claim is a passing test.

### +6 eval tasks

30 → **36 gradeable** (37 defined), all passing at 3 trials:

| Task | Grades |
|---|---|
| `p06-retrieval-hybrid-recall` | recall@5 = 1.0 on both halves, empty rate 0, 20 docs |
| `p06-retrieval-dense-messy-gap` | the clean/messy **split**, not the average (D-30) |
| `p06-ingest-flags-messy-quarter` | 28 chunks, 4 flagged, exactly 1 blocking, fingerprint pinned |
| `p06-grounded-abstains-on-no-support` | abstains with `n_model_calls == 0`, empty fixture list |
| `p06-grounded-cites-a-resolvable-chunk` | citation resolves to `warranty-policy`, nothing unsupported |
| `p06-grounded-withholds-a-manufactured-claim` | **§8's regression**: `cited_blocking_source`, `answered == False` |

Two new dispatch shapes. `evaluate_retrieval` grades **retrieval with no model anywhere** — invariant 43 made executable, so a ranking measurement cannot be perturbed by generation. `answer_question` grades the grounded answer from scripted fixtures. `build_environment` returns an `index_factory` rather than an index, because building one eagerly would add an ingest-chunk-embed pass to every trial of all 36 tasks to serve 6.

### `make results` and the expected ranges

Measured Tier F, seed 7, 20 documents, 28 labelled queries, ~3.3 s. The tables are in §6.14, §6.16 and §6.17; `make plan` prints the budget in three units and spends nothing.

**A correction, stated rather than quietly fixed.** An earlier draft of this phase measured the dense arm at R@1 0.750 with a clean/messy gap of +0.350, on a 33-chunk index. The bare-heading merge (F-06-02) took the index to 28 chunks, and the same arm now measures 0.679 with a gap of +0.250. Later, making semantic chunking reachable (F-06-06) added a fourth row to the strategy table — the row with the best messy recall. **Two fixes invalidated published measurements.** That is why every `docs/RESULTS.md` row carries its configuration and the manifest records the chunker. Tune without re-measuring and you are quoting history.

Fifteen unmeasured rows sit in `docs/RESULTS.md` under a header saying so, each with the reason Tier F structurally cannot answer it. Rows 1–9 are what the **Tier H** budget exists for: `make results ARGS=--tier-h` runs the same experiments against a hosted embedding model, capped at 100 calls, cached to `data/cache/`, and the cap **raises** rather than falling back — a silent downgrade would produce a row labelled Tier H and measured offline.

### Read five failing traces — `docs/FAILURE_LOG.md`

Nine entries, all of them defects this phase committed and found:

| Entry | Defect | Rule left behind |
|---|---|---|
| F-06-01 | the boilerplate flag was unreachable because the repair ran first and destroyed the evidence | a repair that exercises judgement records that it acted (D-34) |
| F-06-02 | abstention wired to `report.empty`, which a dense retriever cannot produce; plus five content-free heading chunks, one ranking first for its own title | wired ≠ reachable |
| F-06-03 | §8. A blocking flag propagated through six records and reached the prompt at none of them | trace every provenance field to the line that acts on it |
| F-06-04 | a caveat that named no defect, so could only be ignored | name the defect or the caveat is boilerplate |
| F-06-05 | abstention caught the gibberish and **missed all four plausible unanswerable questions** | lexical support is not evidence of an answer |
| F-06-06 | `strategy="semantic"` unreachable through `build_index`; `SKIPPED` printed into a published table | invariant 30 is checked at the layer that composes |
| F-06-07 | the sparse side post-filtered, in the code that teaches pre-filtering | test the assembly, not only the parts |
| F-06-08 | invented confidence values under a comment claiming provenance | pin a fixture to whatever the prose claims about it |
| F-06-09 | `# not executed during authoring` hid a collection-name collision | attempt execution before writing that marker |

Your stub is at the end of the file. Run `make evals ARGS="--trials 3"`, then `make trace TASK=<id>` on anything that fails, and write one line each — what happened, no hypothesis.

**Repo tag: `phase-06`.**

---

## 12. [core] Mastery checklist

You are ready to move on if you can:

- Derive $\cos\theta = a \cdot b$ for unit vectors, explain why L2-normalising at index time is a performance decision, **and** name the bug that scale invariance invites.
- Say why two embedding models' vectors cannot be compared, and why Atlas raises for a mismatched index and stays silent for a mismatched cache.
- Name the five extraction damage classes, rank them by frequency and by severity, and explain why the rankings are inverses.
- Explain why column interleaving is detectable only from coordinates, and why which library you chose does not tell you whether you have the problem.
- State the rule separating a repair that must announce itself from one that need not, and classify NFKC normalisation, de-hyphenation and boilerplate stripping under it.
- Choose a chunking strategy from a property of a document, and say what `total_chars` stops a chunk-size experiment from concluding.
- Write RRF from memory, say why it needs no normalisation, and say what a large $k$ buys.
- Explain why recall@5 = 1.000 on a 28-chunk corpus is not a result.
- Explain why reranking 5 candidates into 5 cannot change recall@5, and why a reranker sharing its retriever's mechanism is an echo.
- Distinguish relevance, faithfulness and correctness with §8's example, and say which layer fixes each.
- Explain why the grounding schema has no `confidence` field, and why a dense retriever cannot supply an "empty retrieval" signal.
- Say what F-06-05 means for a system you would deploy: which questions your abstention still misses, and what it would take to catch them.
- Name three ways a composition layer can violate a rule its leaf modules enforce, and the test shape that catches each.

---

## 13. [core] Quiz

1. Cosine similarity is scale-invariant, which §6.3 gave as the reason to prefer it over Euclidean distance. §6.11 showed that same property causing a bug. Explain both, and say what that tells you about "choose the right metric" as advice.

2. You are handed a retrieval system with recall@10 of 0.97 and users who complain answers are frequently wrong. You may compute exactly two more numbers before reporting back. Which two, and what does each possible pair of outcomes tell you?

3. A colleague proposes replacing BM25 with a second embedding model from a different vendor, arguing that two dense retrievers with different training data will fuse just as well. Give the strongest version of their case, then the argument against it, and name the specific query type that decides it.

4. §6.9 kept a detector measured to be useless, reported its number, and wired it to nothing. Invariant 41 says a mechanism is wired or it is not shipped. Reconcile these, then give one case where deleting the detector would have been the right call.

5. §8's answer was faithful to its chunk, cited a resolvable source, contained no unsupported figure, and was wrong. Design a check that would have caught it *without* fixing the extraction. Then say what your check costs and why the phase did not ship it.

6. `pre_check` abstains when BM25 returns nothing, and F-06-05 measured that this catches 1 unanswerable question in 5. A colleague proposes abstaining when the top fused score is below 0.4. Give two reasons that is worse, and one thing it would catch that the current mechanism cannot.

7. Three of this phase's nine defects were the composition layer breaking a rule its leaf modules enforced, and every leaf module had thorough tests. Explain why leaf tests systematically miss this class, and describe a testing rule that would have caught all three.

---

## 14. [core] Coding assignments

### Assignment 1 — `atlas/rag/quality.py`, the pre-index quality gate **[fast track: do this one]**

§6.9 computes per-document flags and §6.15 argues about what to do with them, but the *policy* is currently scattered across `exclude_blocking` defaults and a `pre_check` branch. Centralise it.

Build a module that decides, per document, whether it is indexed clean, indexed with its flags, or quarantined — and produces a report a human reads **before** indexing.

**Acceptance criteria.** `POLICIES` is a closed `Literal` of exactly `"index"`, `"index_flagged"`, `"quarantine"`. `decide(doc, *, strict=False)` returns a record carrying `policy`, `indexable` and a `reason` that names the flag which drove the decision. A clean document is `index`; a noisy one (`ocr_low_confidence`, `flattened_table`, `boilerplate_repetition`, `broken_ligatures`, `suspect_reading_order`) is `index_flagged` and indexable **in both modes**; `empty_extraction` is always `quarantine`; a blocking flag is `index_flagged` by default and `quarantine` under `strict=True` (D-33). `assess_corpus(docs)` returns a report with `n_documents`, a `counts` dict over all three policies, `flagged_share`, `indexable_share`, `quarantined` (ids), a `render()` table naming every document, and a clean `model_dump()` round trip. `indexable(docs)` filters, preserving order. An empty corpus reports zeros rather than dividing by them. `make grade` passes.

**Unaided core.** The **policy table itself** — which flag maps to which policy, and why `strict` changes exactly one of them. Do not delegate this and do not copy it from `BLOCKING_FLAGS`. Write down, for each of the eight flags, the sentence "a document with this flag should/should not be quotable, because ___", and let the table fall out. If your reason for a flag is "it's bad", you have not decided anything.

**Hidden test:** `tests/hidden/test_phase06_a1.py`. Do not read it.

### Assignment 2 — `atlas/rag/tables.py`, tables as rows **[extended]**

§6.8.2 called flattened tables the highest-severity common damage and said the fix is not to flatten. Build it.

Parse the frozen `calibration-tolerances-2026.rawtext` back into rows, and emit one chunk per row in which every value carries its column heading — so a number can never be separated from the label that gives it meaning.

**Acceptance criteria.** `parse_flattened(text)` returns a table record or `None`. It finds the header row and its width, recovers all five data rows, and returns `None` for prose. The document's preamble line must not be swallowed into the headers. `cell(row, "Interval")` addresses a value by row index and column *name*. `row_text(3)` renders a self-contained sentence containing `T100`, `temperature`, `6 months` **and the word `Interval`**. `table_chunks(table, doc_id=..., flags=...)` returns `Chunk`s with `kind="table_row"`, unique and stable ids, and the document's flags inherited. A ragged input is refused rather than guessed at. `model_dump()` round-trips. `make grade` passes.

Then **measure it**: add the row chunks to the index alongside the prose chunks and report recall@1 on `q23` and `q24` before and after. Write the row into `docs/RESULTS.md` with tier, seed and date. A structural improvement you did not measure is a structural opinion.

**Unaided core.** The **header-detection heuristic**, and its refusal case. Deciding which line is the header — and being willing to return `None` rather than treat the preamble as one — is the whole problem. An assistant will happily give you something that assumes line 3; write the version that would refuse a table it cannot read, and write the test for the refusal first. Note also that `kind="table_row"` is currently a `Literal` member with no line that sets it, so this assignment is what makes invariant 30 true again — and F-06-06 is what happens when a member stays unreachable.

**Hidden test:** `tests/hidden/test_phase06_a2.py`. Do not read it.

---

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 7.*

**Retrieval closes three gaps a bigger model does not.** Knowledge cutoff, private data, and attribution — and the second and third are not closed by any future model. Fine-tuning teaches **behaviour**; retrieval supplies **facts**; using the behavioural tool for the factual job produces a model fluent at generating document-shaped text that is in no document. Below roughly 200,000 tokens, put the whole corpus in the prompt and build nothing. Retrieval is a **marginal** cost and fine-tuning a **fixed** one, so the crossover depends on your traffic, not your architecture. Large windows remove the capacity constraint and none of the other three arguments.

**An embedding is a position on a learned map; its dimension is the model's property, not your setting.** Cosine is right because it is scale-invariant, and $\cos\theta = a \cdot b$ once vectors are unit length, so you normalise at index time and dot-product on the hot path. $\|a-b\|^2 = 2 - 2\cos\theta$ for unit vectors, so the two rankings are identical **once normalised**, and only then. **Cosine is not a probability** — this embedder's confident hits score 0.098 and its misses 0.127 — so any threshold you did not calibrate is noise, and a threshold on a *fused* score is worse than noise because min-max is per-query. **And scale invariance has a cost**: it is exactly what let a 24-character title outrank the section beneath it (F-06-02). Choosing the right metric buys you its virtues and its consequences together.

Vectors from two models cannot be compared and the arithmetic will happily run — so an index **raises** on a fingerprint mismatch while a cache **discards silently**: one costs calls, the other costs a wrong answer nobody notices.

**Embedding models are trained contrastively on short texts, which is the real reason chunking exists.** Dense retrieval has three failure modes no model fixes: rare exact strings, negation and quantity, and **corpus blindness** — an embedding sees one text at a time and IDF needs the whole corpus. So hybrid search is **corpus-blind plus corpus-aware**.

**Ingestion is where the weeks go, and its frequency ranking is the inverse of its severity ranking.** Header pollution splits sentences across page boundaries and inflates term frequency; detect it by cross-page repetition with digit masking. Flattened tables keep every value and lose every relationship, because a table's meaning is its geometry (0.97 short-line share measured; the fix is row extraction). Ligature loss silently removed twelve words from five lines — repair may **restore** information and may not **invent** it. OCR announces its own trouble through per-word confidence, and its expensive error destroyed `extended` while preserving `24 months`: the number retrievable, the concept that qualifies it gone. Column interleaving manufactures fluent false sentences, is detectable **only from coordinates**, and depends on which library you chose *and* on the tool that produced the PDF.

**Flags separate by consequence, not severity.** Only `empty_extraction` and `interleaved_columns` block, because only they yield sentences no document contains. And **the text-only interleave detector was measured to be useless** — its two highest scores belong to undamaged documents. It is kept, reported as data, and wired to no decision.

**Structure chunking is the phase's only free lunch**: best R@1 (0.857), best MRR, *and* fewest characters embedded, because merging bare headings removes five content-free chunks. **Semantic chunking has the best messy R@1** (0.875) — a row invisible until `build_index` was fixed to forward the embedding function it needs. Report `total_chars` or a chunk-size sweep will conclude smaller is free: 200-character chunks scored best on R@1 and embedded 18% more.

**RRF needs no normalisation because ranks are already comparable; $k=60$ says agreement across retrievers beats position within one.** Measured, Tier F, 28 chunks, 28 queries, seed 7: overlap 0.40 justifies the hybrid; dense R@1 0.679, sparse 0.857, weighted-0.3 best on MRR. **recall@5 saturates at 1.000 for every arm** — $k=5$ over 28 chunks is 18% of the corpus, so *a recall figure without its corpus size is uninterpretable*. The clean/messy gap is **+0.250 dense, +0.150 sparse**: on damaged text the sparse retriever is the primary, not the backup.

**Pre-filter, always, on both retrievers.** Post-filtering loses documents whose answers were outside the unfiltered top-$k$, and I shipped exactly that on the sparse side two modules from the paragraph warning about it (F-06-07).

**Reranking cannot change recall@$k$ if you retrieved $k$** — measured equal, and printed by every `make results` run. The free lexical reranker was uniformly harmful or neutral because **it echoes BM25**: a reranker must fail *differently* from the retriever or it is an echo.

**Evaluate retrieval separately from generation, and split by corpus quality.** Label **documents and answer spans, never chunk ids** (D-29). The gap between recall@k and **span** recall@k is the chunking-failure signature. Dense corpus-wide 0.679 splits into 0.750 and 0.500, and only one survives a status meeting — so CI floors are separate, and `evals/retrieval_eval.py` warns if you set only one. One query (`q21`) is **`damaged_only`**: retrieval can satisfy it and generation must refuse it, and the report names that rather than leaving recall 1.000 looking like a contradiction.

**Abstention is computed by code, never granted by the model (D-31).** `GroundedDraft` has two fields and no `confidence`. Eight reasons, three pre-call and five after. **A brute-force dense retriever never returns empty**, so abstention rides on BM25 as a free, threshold-free verifier (D-32, D-22's shape): zero false abstentions over 28 queries, zero model calls on gibberish. **And it catches 1 unanswerable question in 5** (F-06-05) — the four sharing vocabulary with the corpus pass straight through, because *lexical support is not evidence of an answer*. Unfixed and stated.

**Relevance, faithfulness, correctness are three properties with three fixes.** The number check catches a fabricated figure and structurally cannot catch a faithful quotation of a corrupted chunk — a test asserts it fails to help.

**§8: wrong answer, immaculate provenance, faithful to its source, and the source is a sentence nobody wrote.** Four defects: a blocking flag that reached six records and no prompt; a caveat that named no defect; a claim resting entirely on manufactured text; and the correct clause three words away in the same chunk. Fixes 1–3 are **containment**; only re-extraction makes it right. Phase 3's §8 was *fabricated provenance*; Phase 4's *wrong answer, immaculate provenance*; Phase 5's added *a completeness label asserting there is nothing to check*; this one is **a defect manufactured in the first ten minutes of the pipeline, with every layer after it working correctly on corrupted input.**

**Nine defects, and the pattern in three of them.** F-06-06 (a closed-Literal member unreachable through the composition), F-06-07 (the assembly post-filtering one retriever while pre-filtering the other), and a store field widened to `Any` that stopped round-tripping were all **the composition layer failing to honour a rule its leaf modules enforced**, with every leaf thoroughly tested. That is invariant 46: **a closed set, a wired mechanism and a reachable condition are three different things, and the assembly is where they come apart.** Test through the composition callers actually use.

**Two integrity defects worth more than their bug count.** F-06-08: confidence values synthesised to reproduce a measurement, under a comment claiming they came from tesseract — invented numbers with a provenance claim, which is §8's failure committed in the fixtures. F-06-09: `# not executed during authoring` hiding a collection-name collision that surfaced in four minutes once the library was installed. **Invariant 48: a fixture states its provenance truthfully and a test pins it to whatever the prose claims; and before writing "not executed", attempt execution and record what stopped you.**

**Measurement discipline.** `make plan` prints the budget in three units and spends nothing, and reveals that **query embeddings outnumber chunk embeddings five to one** in an evaluation sweep. Two fixes in this phase **invalidated published measurements** — the bare-heading merge moved dense R@1 from 0.750 to 0.679, and making semantic chunking reachable added the row with the best messy recall. Tune without re-measuring and you are quoting history. Fifteen unmeasured rows sit under a header saying so; rows 1–9 are what the 100-call Tier H budget exists for, and the cap raises rather than falling back.

**Scripted fixtures prove plumbing, arithmetic and provenance; they prove nothing about meaning.** They prove that a dimension mismatch raises rather than zipping, that the same text embeds identically in a different process, that IDF is floored at zero, that RRF ignores score scale, that a singleton does not normalise to 1.0, that a reranker with no signal is a no-op, that a refresh re-embeds exactly one chunk, that abstention costs no model call, that a claim resting only on manufactured text is withheld, and — 25 tests over two backends — that the store interface is swappable. They prove nothing about whether a real embedding model retrieves well. That is `docs/RESULTS.md`.

**Repo state at `phase-06`.** Twelve new modules under `atlas/rag/`, one new checksum-pinned prompt, a 20-document seeded corpus with 20% frozen real extractor damage and 28 labelled queries, two vector-store backends behind one conformance suite, `scripts/phase06_results.py` with four experiments and `--plan`/`--quick`/`--tier-a`/`--tier-h`, `evals/retrieval_eval.py` with split CI floors, a `make ingest` target. **929 offline tests** (from 565), **36 gradeable eval tasks** (from 30, 37 defined), `ATLAS_INTERFACES.md` **v0.14** with invariants 42–48 and D-28 to D-35, nine worked `FAILURE_LOG.md` entries plus a stub, one measured Tier F sweep and fifteen unmeasured rows. **Fourteen assignments outstanding.**

**Phase 7 next: structured data.** Text-to-SQL over the curated views, and four things here become load-bearing. `HANDLER_TOOLS["data"]` already exists and reaches a ReAct agent with `query_db` — another handler upgrade, not a new architecture. Retrieval becomes a **tool** rather than a handler, because the `research` route must now choose between the index and the database, and that is the first branch this book cannot enumerate in advance (D-21's third clause finally binds). The abstention discipline transfers with a sharper edge: a SQL query returning zero rows is *this phase's empty retrieval*, and the moment a model turns "no rows matched" into "there were none", you have F-06-05 with a schema attached. And F-06-05's unfinished business is Phase 7's opening problem: **an answerability check needs to compare what a question asks for against what the evidence contains** — trivial against a schema and hard against prose, so the structured route is where you learn to build it.

---

## 17. [core] Further reading

**Primary, on retrieval mechanics**

- Cormack, Clarke & Büttcher, *Reciprocal Rank Fusion Outperforms Condorcet and Individual Rank Learning Methods*, SIGIR 2009, pp. 758–759 — two pages, the whole method, and the source of $k=60$. https://cormack.uwaterloo.ca/cormacksigir09-rrf.pdf
- Robertson & Zaragoza (2009), *The Probabilistic Relevance Framework: BM25 and Beyond* — where the three corrections come from and why. https://www.staff.city.ac.uk/~sbrp622/papers/foundations_bm25_review.pdf
- Reimers & Gurevych (2019), *Sentence-BERT*, arXiv:1908.10084 — the contrastive objective that makes similarity search work. https://arxiv.org/abs/1908.10084
- Karpukhin et al. (2020), *Dense Passage Retrieval*, arXiv:2004.04906 — dense retrieval beating a strong sparse baseline, and the asymmetric query/document encoders §6.4 warns about. https://arxiv.org/abs/2004.04906
- Lewis et al. (2020), *Retrieval-Augmented Generation*, arXiv:2005.11401 — the paper the acronym comes from; read it to see how much of "RAG" is now something else. https://arxiv.org/abs/2005.11401
- Liu et al. (2023), *Lost in the Middle*, arXiv:2307.03172 — why a large context window is not a substitute for selection. https://arxiv.org/abs/2307.03172

**Engineering practice**

- Anthropic, *Contextual Retrieval* (19 Sep 2024) — the layered results quoted in §6.16 and §10, the sub-200k-token escape hatch, and the instruction to evaluate on your own corpus. https://www.anthropic.com/engineering/contextual-retrieval
- Ollama, *Embeddings* — `/api/embed` versus the legacy endpoint, the unit-vector guarantee, and the current recommended models. https://docs.ollama.com/capabilities/embeddings
- MTEB leaderboard — for choosing an embedding model. Scores move; treat it as a shortlist, not a fact. https://huggingface.co/spaces/mteb/leaderboard
- Chroma's documentation — the API `atlas/rag/backends.py` adapts, and the source for the distance-versus-similarity convention. https://docs.trychroma.com

**Ingestion, which the literature under-serves**

- pdfplumber's documentation, particularly `extract_words` and its coordinate fields — the evidence §6.8.5's reliable detector needs. https://github.com/jsvine/pdfplumber
- pypdf's text-extraction docs, including `extraction_mode` — read alongside pdfplumber's and note that they disagree by design. https://pypdf.readthedocs.io/en/stable/user/extract-text.html
- Tesseract's *Improving Quality* page — the deskew-and-threshold advice that beats switching engines. https://tesseract-ocr.github.io/tessdoc/ImproveQuality.html
- Docling — the strongest current open option for layout-aware table extraction, and what Assignment 2 is a hand-rolled version of. https://github.com/docling-project/docling

**Deferred to Appendix F:** contextual chunk prefixes at corpus scale, ANN indexing and its recall trade-off, and cross-encoder reranking with a local model.

---

## 19. [core] HANDOFF

**Confirmed inside `atlas_phase_06.zip`:** `ATLAS_INTERFACES.md` at **v0.14** (twelve `atlas.rag.*` module contracts, the `atlas.flow.app` and `atlas.prompts` additions, `scripts/gen_docs.py`, `evals/retrieval_eval.py`, and invariants 42–48) and `VERSIONS.md` with the Phase 6 delta. Verified: `make test-offline` → **929 passed**; `make check-docs` → pass; `make grade PHASE=06` → skips cleanly (assignments not started); `make evals ARGS="--trials 3"` → **36/36 pass^k**. Tagged `phase-06`.

**Solutions** are in the companion document `phase_06_solutions.md`: worked answers for the cumulative review, all fourteen concept checks, the seven quiz questions, and both assignments.

**VERSIONS.md delta rows** are printed in full in the repository's `VERSIONS.md` under "Phase 6 delta — checked 2026-09-08", plus a revision block covering `chromadb 1.5.9` (now a tested optional backend rather than deferred) and the three corrections this phase's revision produced.

**Two honest notes on this document.** Section 15 (case study) is absent because the phase block specifies `case study: no`; section 18 (solutions) is the separate `phase_06_solutions.md`, as the template requires. And at ~27,200 words including code this document is about 5% over its 20–26k budget. I cut the `[extended]` industry section first, as the conventions direct, and stopped there rather than thin the measured tables or the nine failure-log diagnoses — those are the parts a self-study reader cannot reconstruct alone.
