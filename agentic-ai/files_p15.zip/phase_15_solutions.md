# phase_15_solutions.md

Worked answers for Phase 15. Read these *after* attempting the questions.

---

## Cumulative review (§2)

**1. Phase 12's traceparent.** The server parsed the trace id out of `_meta` and wrote it into a `CallAudit` record — nothing else. That gives you two logs that mention the same hex string, which is genuinely useful for correlation and is not a trace. It cannot tell you that the server's tool call happened *inside* the model call that requested it, cannot tell you the gap between dispatch and execution, and has no durations at all. Causality and duration are what a distributed failure needs, and an id in two logs carries neither.

**2. The omitted property.** The **audience**. Scope, expiry and subject get implemented; audience binding gets skipped because it appears redundant when there is only one server. An unaudienced bearer token is the confused-deputy attack with no attacker required: a token minted for service A is accepted by service B, so any component that can obtain a token can spend it anywhere. This is why `API_AUDIENCE` in Phase 15 is a constant and not a parameter — an audience a caller can supply is one a caller can talk you out of.

**3. Kappa 0.000 at 87.5% agreement.** The sample was 87.5% passes, and a judge that always says "pass" scores exactly the base rate. Cohen's kappa measures agreement *above chance*, and a constant classifier has none. The lesson: raw agreement on an unbalanced sample measures the sample, not the judge. Report kappa against a deliberately balanced set, report the **worst** criterion rather than the mean, and make the label count part of the gate.

**4. F-13-05's rule.** Invariant 73: **a number in the tutorial that no `make` target prints is an opinion.** Every quantitative claim is printed by that phase's results script or is labelled an estimate. The target is `make results`. The tell worth remembering is that the error ran in the author's favour, which is the direction such errors usually run.

**5. The wrapped GraphInterrupt.** It was classified as a `tool_error`. The run then completed *normally*, reporting that the remote system was unavailable — nothing raised, nothing logged, and the trajectory looked like a successful handling of a real failure. That is why it was indistinguishable from success: the agent's own contract (invariant 19) says a tool error is a normal observation the loop reports, so correct behaviour on a misclassified input produces a confident, wrong, well-formed answer.

---

## Concept checks

**6.1 — why `None` and not `0.0`.** A *dashboard*: p50 latency. An open span at duration zero enters the latency bucket and drags p50 towards zero precisely while requests are hanging, so the graph improves during an outage. An *alert*: "p95 above 5 s". With zeros in the distribution, forty hung requests push p95 *down*, so the alert that exists to catch hanging never fires for the hanging case. `None` forces the caller to decide, and `metrics_from_spans` decides by counting them separately — which makes "p95 is fine and forty spans never closed" expressible.

**6.2 — ambient versus explicit.** What stops being tested is **the propagation itself**. In `make test-offline` the MCP server runs in-process, so Atlas's span is ambient when the server's handler runs; parenting to it produces a tree that is visually identical to the correct one while `_meta["traceparent"]` is never read. Deploy the server to another machine and the tree splits into two traces, in production, with no failing test anywhere.

`test_two_remote_calls_in_one_request_are_siblings_not_a_chain` would still catch it, because it asserts the *parent id* of each server span against a *specific* model span's id. With ambient parenting both server spans would parent to whatever span was innermost at dispatch — which happens to be the same model spans here — so strictly it would still pass. The test that genuinely distinguishes them is one that supplies a traceparent from a *different* tracer: `test_an_explicit_parent_beats_the_ambient_span` in `tests/test_obs_phase15.py`, which opens an ambient span and then asserts the child took the remote trace id. That is the honest answer, and noticing that the first candidate does *not* separate the cases is the point of the question.

**6.3 — prompt text in staging.** Two configuration facts must be true: (a) the staging trace backend must have its **own** retention and access control, shorter and narrower than production's, not the same project with a different tag; and (b) the attribute must be behind an explicit flag that is off in the production configuration file, not merely unset — an unset flag is one deploy away from being set. The thing about staging data that usually is not true: **staging is rarely synthetic.** Teams copy a production snapshot to make staging realistic, at which point "it's only staging" is a statement about the environment and not about the data.

**6.4 — gateway-injected traceparent.** "Was the slowness before my service?" With a gateway-minted trace id you can see the gateway's own span, the queue wait, and any upstream hop in the same tree, so a request that spent 4 s in a load balancer and 800 ms in Atlas is visibly not Atlas's problem. If the API mints its own id per request, the trace begins at the moment Atlas started work, and every second before that is invisible — you would conclude Atlas is fast and the users are wrong.

**6.5 — the list-returning `encode_stream`.** Nothing *breaks* in the sense of an error. The generator is what makes the first frame leave before the last one exists; a list version builds every frame first, then sends them, so the client receives the entire stream at once at the end. Total latency is unchanged, every unit test passes (the frames are identical), and the type checker is happy. Nobody files it as a streaming bug because the symptom is "the model seems slow" — the user waits in silence and then sees the whole answer appear instantly, which reads as a model problem, not a transport one.

**6.6 — the nightly operator-tier job.** *Private data*: the loan/company records the `operator` tier can reach through `query_db` and the document index. *Untrusted content*: whatever the job ingests — a webhook payload, an inbox, a retrieved document. *External communication*: an `operator` tier includes write and remote-append tools, and any answer that can contain a URL is an exfiltration channel. The cheapest leg to remove is the **third**: run the scheduled job under a read-only tier with a deny-all egress policy, and have it write its output to a location a human reads rather than to anything that transmits. That costs nothing, because a nightly digest does not need to send anything itself.

**6.8 — the tracer's retention hazard.** `app.state.tracer` is one unbounded list for the lifetime of the process, so spans accumulate for every subject with no expiry, and `ThreadRegistry.expire_before` does not touch them. Deleting a thread therefore leaves its spans — which is the "deleted the index and left the data" failure with a new noun, and worse because the spans outlive the record that says who owned them. Before real traffic: make the tracer a **bounded ring buffer** flushed to the exporter, keep the retention decision in the backend where it can be configured, and either drop the in-process `/v1/traces/{id}` endpoint or bound it to the same window.

**6.10 — the `tool` event.** Without `ok` and `error_kind`, a user cannot tell **a tool that ran and succeeded from a tool that ran and failed**. An agent that reports "looked up the orders table" and then gives a vague answer looks like a model that is bad at summarising; with `ok=false, error_kind=tool_error` it looks like a database outage, which is a different support ticket and a different emotion.

Emitting the *arguments* would be a mistake because they are the content: a SQL predicate, a file path, a search query. They carry customer identifiers as a matter of course, they would go to the trace backend and to any browser with the stream open, and §6.3's allowlist exists precisely to keep them out. The UI being more informative is the trade being refused — and the alternative that gets most of the benefit is a **human-written description per tool** ("looking up the Q3 orders table"), which is the consequence-renderer discipline from Phase 10.

---

## Quiz (§13)

**1. Parenting by id.** *Makes distributed tracing possible*: two processes that share no memory, no call stack and no machine can each record independently and have their records assemble into one tree at the backend, with no coordination and no ordering requirement. *Makes a failure mode possible*: a parent id that names a span the backend has not received (or will never receive) leaves a child with a dangling reference. Atlas's answer is to make it an **orphan root** rather than a dropped node, because the commonest cause is arrival order and a silently smaller tree is a plausible rendering of half a request.

**2. Two roots, one orphaned.** *Explanation A*: the third service's spans have not arrived yet — a timing artefact, and it resolves itself on refresh. *Explanation B*: a hop dropped or mangled the `traceparent`, so a service started a fresh parent id that nobody will ever emit; it will never resolve. To distinguish: refresh after the export interval. If the orphan attaches, it was A. If not, compare the orphan's trace id to the root's — same trace id with an unresolvable parent means the header survived but a span went missing (sampling, a crash before export); *different* trace ids in what you thought was one trace means the header was dropped, and the service that emitted the orphan is the hop to investigate.

**3. Redactor versus allowlist.** Only the **allowlist** is a security control. The question that separates them is Phase 14's: *what must an attacker do to pass it?* For the redactor the answer is "write the number differently" — base64, homoglyphs, splitting across attributes — so it is a **layer**, and a good one against the accidental case. For the allowlist the answer is "get a new key added to a frozen set in source control and shipped", which is not something the attacker controls at all, so it is a **boundary**. The allowlist holds regardless of encoding, because it never looks at the value.

**4. 404 versus 403.** The argument against: returning 403 for a thread that exists but is not yours makes the endpoint an **oracle**. An attacker with one valid credential can enumerate ids and learn which are real, which turns an unguessability assumption into a membership test — and membership alone is disclosure (that a given customer has a thread about a given topic). Atlas therefore returns a byte-identical 404, asserted by a test that compares both bodies.

Where the instinct is right: **within a trust boundary you already control.** An internal admin tool, where every caller is an employee and the distinction between "typo" and "not your tenant" is an operational cost, is a reasonable place for 403 — because the attacker model is not "somebody with a valid credential is probing", and the debugging cost of an indistinguishable 404 is real.

**5. Open spans at zero.** A scenario: the model backend hangs. Requests arrive, open their `invoke_agent atlas` span, open a `chat` span, and never return. Over five minutes 200 spans open and 5 complete (the ones that arrived before the hang). With open spans included at duration zero, the latency distribution is 200 zeros and 5 real values, so p50 reads **0.0 ms** and p95 reads near zero. The dashboard shows latency improving dramatically at the exact moment nothing is working, and any alert on p95 goes quieter as the outage deepens. Excluding them and reporting `open_spans = 200` instead makes the outage the most visible number on the page.

**6. Streaming with hidden retries.** The stream must show the retries: a `tool` event per attempt (or one carrying an attempt count), so the user sees three attempts and a success rather than one slow tool. The trust consequence of showing nothing is **miscalibration in the dangerous direction**: the user experiences a system that appears to succeed first time, every time, and forms a reliability estimate far above the truth. They then act on a later answer with confidence the system has not earned — and, separately, they cannot explain the bill, because three calls were charged and one was displayed. Invariant 15 has said since Phase 2 that a silent retry loop is an evidence bug; the screen is where that evidence is finally cashed.

---

## Assignment 1 — `atlas/obs/sampling.py`

Reference solution. Two lines are the assignment and are marked in place.

```python
"""Tail-based sampling: decide what to keep AFTER the trace finishes."""

from __future__ import annotations

import hashlib
from typing import Any, Literal, Sequence

from pydantic import BaseModel

from atlas.obs import semconv
from atlas.obs.spans import Span

__all__ = ["KeepReason", "KEEP_REASONS", "SamplingPolicy", "SamplingDecision",
           "sampling_decision", "TailSampler"]

KeepReason = Literal["error", "slow", "egress", "probability", "dropped", "empty"]
KEEP_REASONS: tuple[KeepReason, ...] = (
    "error", "slow", "egress", "probability", "dropped", "empty",
)


class SamplingPolicy(BaseModel):
    """What to keep. Data, so it can be reviewed in a pull request."""

    model_config = {"frozen": True, "extra": "forbid"}

    slow_ms: float = 5_000.0
    probability: float = 0.1


class SamplingDecision(BaseModel):
    keep: bool
    reason: KeepReason
    duration_ms: float = 0.0

    def render(self) -> str:
        verb = "KEEP" if self.keep else "drop"
        return f"{verb:<5s} {self.reason:<12s} {self.duration_ms:8.2f}ms"


def _root(spans: Sequence[Span]) -> Span | None:
    for span in spans:
        if span.parent_id is None:
            return span
    return None


def sampling_decision(
    spans: Sequence[Span], policy: SamplingPolicy
) -> SamplingDecision:
    """Pure. Per TRACE, never per span: half a tree is worse than none."""
    if not spans:
        return SamplingDecision(keep=False, reason="empty")
    root = _root(spans) or spans[0]
    duration = root.duration_ms or 0.0
    if any(span.status == "error" for span in spans):
        return SamplingDecision(keep=True, reason="error", duration_ms=duration)
    if duration >= policy.slow_ms:
        return SamplingDecision(keep=True, reason="slow", duration_ms=duration)
    if any(
        int(span.attributes.get(semconv.ATLAS_EGRESS_REMOVED, 0) or 0) > 0
        for span in spans
    ):
        return SamplingDecision(keep=True, reason="egress", duration_ms=duration)
    # DETERMINISTIC: hash the trace id rather than calling random(). A sampler
    # that flips on re-evaluation cannot be reasoned about, and a replay of the
    # same batch would produce a different corpus.
    digest = hashlib.sha256(root.context.trace_id.encode()).digest()
    draw = int.from_bytes(digest[:8], "big") / float(1 << 64)
    if draw < policy.probability:
        return SamplingDecision(keep=True, reason="probability", duration_ms=duration)
    return SamplingDecision(keep=False, reason="dropped", duration_ms=duration)


class TailSampler:
    """Buffers spans per trace and decides on flush. Never on the first span."""

    def __init__(self, policy: SamplingPolicy, *, exporter: Any) -> None:
        self.policy = policy
        self._exporter = exporter
        self._buffers: dict[str, list[Span]] = {}
        self.kept = 0
        self.dropped = 0

    def offer(self, span: Span) -> None:
        self._buffers.setdefault(span.context.trace_id, []).append(span)

    def flush(self) -> int:
        exported = 0
        for spans in self._buffers.values():
            decision = sampling_decision(spans, self.policy)
            if decision.keep:
                self.kept += 1
                exported += self._exporter.export(spans) or 0
            else:
                self.dropped += 1
        self._buffers.clear()
        return exported
```

**Why determinism, not `random.random()`.** A sampler that draws fresh randomness cannot be reasoned about: re-running a batch produces a different corpus, and a trace re-evaluated after a retry flips. Hashing the trace id gives a uniform draw that is stable for a given trace and independent across traces, which is exactly the property you want and exactly what `random()` does not give you. The grader pins it with `test_the_decision_is_deterministic_for_one_trace`.

**Why per trace, not per span.** Sampling spans independently at p=0.5 keeps roughly half the spans of every trace — so every trace in your backend is a *plausible* tree missing half its nodes. That is worse than keeping no trace at all, because a reader believes it, and it is F-07-06's lesson with a sampler in the middle. `test_probability_is_applied_per_trace_not_per_span` drives sixty traces through and asserts the kept count is roughly half of *traces*.

**Why a drop states its reason.** `SamplingDecision(keep=False, reason="dropped")` reads oddly until you have to answer "why is this trace not in the backend?". `dropped` and `empty` are different answers, and a boolean would give you neither.

**Negative control.** A submission using `random.random()` and omitting the egress check fails exactly two of eleven: `test_a_trace_that_tripped_the_egress_boundary_is_always_kept` and `test_every_keep_reason_is_reachable`. Note that the determinism test happens to pass such a submission when the draws fall the same way — which is why the egress omission is the one that reliably separates them, and why a grader gets run against a realistic wrong answer before it ships (invariant 68's corollary).

**Where this meets §10.** Tail sampling is the reason `SpanExporter.export` takes a finished *batch* rather than one span: the decision point is after the trace completes, so the sampler is a filter you insert between the tracer and the exporter rather than a rewrite of either.

## Assignment 2 — `evals/from_traces.py`

```python
"""Production traces -> candidate eval tasks."""

from __future__ import annotations

import hashlib
from typing import Any, Sequence

from pydantic import BaseModel, Field

from atlas.obs import semconv
from atlas.obs.redact import redact
from atlas.obs.spans import Span, build_tree

__all__ = ["CandidateTask", "tasks_from_spans", "to_task_file"]

# A stop reason or an error is the signal that a trace is worth a task. A
# suite grown from SUCCESSFUL traces measures the cases you already pass.
INTERESTING_STOPS: frozenset[str] = frozenset(
    {"max_steps", "budget_exhausted", "no_progress", "refused", "partial"}
)


class CandidateTask(BaseModel):
    """A task nobody has labelled yet. `needs_review` is True and stays True."""

    id: str
    route: str
    stop_reason: str
    prompt: str
    trace_id: str
    interesting: bool = False
    needs_review: bool = True
    checks: list[dict[str, Any]] = Field(default_factory=list)
    provenance: dict[str, Any] = Field(default_factory=dict)


def tasks_from_spans(spans: Sequence[Span]) -> list[CandidateTask]:
    """One candidate per ROOT span. Pure. Redacts before it returns."""
    out: list[CandidateTask] = []
    for node in build_tree(spans):
        # An orphan is a HALF trace: its parent was not exported, so the
        # request it describes is not reproducible. Skipping is correct;
        # raising would make one dropped span break a whole harvest.
        if node.orphaned or node.span.parent_id is not None:
            continue
        root = node.span
        attributes = root.attributes
        if semconv.GEN_AI_AGENT_NAME not in attributes:
            continue
        group = [s for s in spans if s.context.trace_id == root.context.trace_id]
        stop = str(attributes.get(semconv.ATLAS_STOP_REASON, "unknown"))
        errored = any(s.status == "error" for s in group)
        # REDACT, never drop: a task with no prompt is not reproducible, and
        # a task with a raw prompt is a customer's question in source control.
        prompt = redact(str(attributes.get("atlas.question", ""))).text
        # The id is a digest of the trace id and the REDACTED prompt, so a
        # re-harvest of the same trace produces the same id and the eval file
        # does not churn on every run.
        digest = hashlib.sha256(
            f"{root.context.trace_id}|{prompt}".encode("utf-8")
        ).hexdigest()[:10]
        out.append(
            CandidateTask(
                id=f"trace-{digest}",
                route=str(attributes.get(semconv.ATLAS_ROUTE, "unknown")),
                stop_reason=stop,
                prompt=prompt,
                trace_id=root.context.trace_id,
                interesting=errored or stop in INTERESTING_STOPS,
                provenance={
                    "source": "trace",
                    "trace_id": root.context.trace_id,
                    "note": "redacted; needs a human expectation before it grades",
                },
            )
        )
    return out


def to_task_file(tasks: Sequence[CandidateTask], *, phase: int) -> dict[str, Any]:
    """The harness's file shape, with every task marked for review."""
    return {
        "phase": phase,
        "schema_version": 2,
        "tasks": [
            {
                "id": task.id,
                "kind": "environment",
                "tier": "F",
                "suite": "exploratory",
                "description": (
                    f"Derived from production trace {task.trace_id}; route "
                    f"{task.route}, stop reason {task.stop_reason}. NEEDS REVIEW: "
                    "a trace records what happened, not what should have."
                ),
                "provenance": task.provenance,
                "setup": {
                    "entrypoint": "atlas.flow.app:handle_request",
                    "prompt": task.prompt,
                    "force_route": task.route,
                    "fixtures": [],
                },
                "checks": task.checks,
            }
            for task in tasks
        ],
    }
```

**Why no checks.** A trace records what happened. It contains no statement about what *should* have happened, and the agent's own answer is the worst possible source for one — grading against it certifies whatever the agent did that day, which is a regression test for the bug. So a harvested task ships with `checks: []`, `suite: "exploratory"` so it cannot enter the regression gate, and `needs_review: True`. Invariant 32 is the same rule from the other side: if the expectation cannot be computed, the task is not gradeable yet.

**Why `interesting` matters.** The naive version marks everything interesting, and I checked: the grader fails `test_failing_traces_are_preferred_and_labelled` for exactly that. The substantive reason is the one in the comment — a suite grown from successful traces measures the cases you already pass, and grows without improving anything. Erroring spans and harness-stopped reasons are where the information is.

**Why the id is a digest and not a counter.** A counter renumbers on every harvest, so a re-run produces a diff touching every task and the review becomes worthless. Hashing the trace id and the redacted prompt makes the id stable for the same trace and distinct across traces — and hashing the *redacted* prompt rather than the raw one means the id itself cannot be used to confirm a guess about the original text.

---

## Case study (§15) — a model answer in outline

**Milestone 0 (weeks 1–2): evidence.** OpenTelemetry spans on every model call, tool call and request; a span allowlist with loan identifiers excluded; twenty hand-labelled eval tasks derived from what support actually asks; `make eval-gate` in CI with a committed baseline. *Nothing else ships first*, and the reason is stated to the sponsor in one sentence: the 80% figure is currently unfalsifiable, so no change after this point could be shown to have helped.

**Milestone 1 (weeks 3–5): the service, agent-facing.** FastAPI behind the existing VPN, bearer tokens from the company IdP (not the Phase 12 stand-in), thread ownership enforced from the first commit, per-agent job caps, liveness and readiness separate. Postgres for threads and checkpoints, with the subject filter in the `WHERE` clause. Retention: 90 days for threads, 30 for span content, both configured and both exercised by a scheduled deletion job that a human triggers for the first month.

**Milestone 2 (weeks 6–8): hardening.** Circuit breaker on the SQL replica (§8's lesson, and this team has exactly that dependency). Egress allowlist on rendered answers. Draft-email tool gated with a consequence renderer naming the recipient and the first line. Red-team pass over the three attack families, with success graded from the environment.

**Milestone 3 (weeks 9–12): customer-facing, or not.** Different trifecta configuration: customer email is untrusted input, so the draft-email tool comes **off** that path entirely and the customer-facing agent is read-only with a deny-all egress policy. A calibrated judge (kappa against a balanced hand-labelled set) before any automated quality claim reaches a dashboard.

**Refusal list.** (1) No customer-facing launch while an untrusted-input path can reach a tool that communicates externally. (2) No quality number on a dashboard from an uncalibrated judge. (3) No deploy without the prompts, the graph, the eval baseline and the index manifest versioned together — because rolling back one and not the others produces a system nobody has ever tested.

**Deploy and rollback.** Blue/green at the proxy; rollback is a traffic switch, not a redeploy. Graceful shutdown at 30 s with the orchestrator grace period at 45. Background jobs move to a durable queue before the agent count passes about twenty, because a daemon thread dying on deploy is survivable at twelve users and is a data-loss incident at two hundred.
