# Phase 15 — From Notebook to Service: End-to-End Tracing, Observability, Serving, Long-Running Agents, and Agent UX

## 1. [core] Title and budget

| | |
|---|---|
| **Study hours** | 12 total — 5 read / 5 build / 2 assess |
| **Compute time** | ~6 min on the baseline laptop for `make spans`, `make results`, `make evals`; the Docker stack is optional |
| **Tier A calls per sweep** | ~200, and only for the optional live demos. Every number in this document is Tier F |
| **Tier H calls** | 0 |
| **Cost** | $0.00 |
| **Repo tag** | `phase-15` |

The 200 Tier A calls buy one thing this document cannot: a real Jaeger screenshot with real latencies. Every *assertion* here runs on scripted fixtures in seconds. If you never start Docker you will still finish the phase and pass `make grade`; you will just have taken my word for a picture.

## 2. [core] Cumulative review

From Phases 12 and 13. Answers in `phase_15_solutions.md`.

1. Phase 12 put `traceparent` into the MCP request's `_meta`. Name the one thing it did with the value on the server side, and say why that was not enough to debug a cross-process failure.
2. Invariant 69 lists four properties a credential must have. Three are commonly implemented. Which is the one people omit, and what attack does omitting it enable?
3. Phase 13 measured a judge that agreed with hand labels 87.5% of the time and had a kappa of 0.000. How is that possible, and what does it tell you about reporting raw agreement?
4. F-13-05 published a minimum detectable effect of 8 points that had been computed as 10.6. The error ran in the author's favour. What general rule did that produce, and which `make` target enforces it?
5. Invariant 70 says a sync-over-async bridge must unwrap exception groups before classifying. What did a `GraphInterrupt` arriving wrapped get *misclassified as*, and why was the resulting run indistinguishable from a successful one?

## 3. [core] Why this phase matters

Fourteen phases have made Atlas *work*. None has made it **answerable**.

A user writes at 09:40: "Atlas took a minute and then said it couldn't find the invoice." You have the code, 1,498 passing tests, 66 eval tasks and a red-team report. What you do not have is any way to find out what happened to **that request**, at **that moment**, for **that person** — and every tool built to answer questions about the system in general is useless for a question about one request in particular.

That gap is a category, not an oversight. Tests are propositions about code. Evals are estimates over a sample. A trace is a **record of a particular event**, and nothing built so far produces one. `atlas/trace.py` renders a trajectory beautifully — for a reader who already knows which run failed and has the object in hand. It cannot tell you *which* run failed, and it stops dead at the process boundary: Phase 12 moved three tools into an MCP server, and §8's failing span is inside that server.

Phase 14's handoff named the second gap: **a control that fires correctly and is read by nothing is indistinguishable from an absent control** (invariant 62). Phase 14 built an audit log with a renderer and no aggregation, and an `EgressReport` that names blocked hosts while nothing alerts on them. If the egress filter starts blocking a legitimate host on Tuesday and nobody learns until March, the filter did not protect you for four months — it just did not tell you it had stopped. Tracing and alerting are the mechanism by which every other control becomes real.

And Atlas currently runs when you type `python`. A service that other people use has properties Atlas has never needed: two users whose data must not mix, a request that outlives its HTTP connection, a deploy that must not cut somebody off mid-sentence, a health check a load balancer will act on, and a **person deciding whether to trust the answer**. That last is not a UI detail — Phase 10 built an approval gate, and this phase asks what happens at the thirtieth prompt of the morning, which is ASI09's arithmetic and the reason approval fatigue is a *security* property.

Three things, and they are one thing: instrument it so failures are diagnosable across process boundaries, serve it so it survives more than one user, design the interface so a person can calibrate trust. The connecting thread is **evidence reaching a human**. The fourth thing is the payoff: once every request produces a structured record, production traffic becomes an eval corpus, and the flywheel that fills the suite you have grown by hand since Phase 3 is built here.

## 4. [core] Learning objectives

You will be able to:

1. **Explain** what a span is, what a trace id does that a log line cannot, and why a span names its parent by id rather than by reference.
2. **Instrument** an agent so one request produces a single connected span tree spanning two processes, and **assert** that in a test.
3. **Name** the OpenTelemetry GenAI attributes for a model call, state which are stable, and explain why content capture is opt-in.
4. **Design** span attributes so no prompt, tool argument or customer identifier leaves the process, using an allowlist, and say what that protects against and what it does not.
5. **Serve** an agent over HTTP with streaming, persistent threads and per-subject isolation, and **demonstrate** that a thread id alone does not grant access.
6. **Distinguish** liveness from readiness and explain the outage conflating them produces.
7. **Build** a background-job endpoint that returns immediately, reports terminal state honestly, and tells the truth about cancellation.
8. **Diagnose** a production incident from spans when the failing span is in a service you did not write.
9. **Describe** the production reference architecture and say what each box is for.
10. **Explain**, without building it, how a production inference server differs from a development one: continuous batching, KV cache, quantization, GPU sizing.
11. **Critique** an agent interface against named anti-patterns, and **justify** one choice that reduces approval fatigue without reducing oversight.
12. **Convert** a production trace into a candidate eval task, with the provenance and redaction rules that make that safe.

## 5. [core] Prerequisites and quick recap

Phases 1–14 in the repo, or `atlas_phase_14.zip` unpacked. Confirm before touching anything:

```
make test-offline        # 1,498 passed, 12 skipped
make tiers
make policy
```

Four load-bearing facts.

**Phase 12 put trace context on the wire and had nowhere to put it.** `new_traceparent()` and `trace_id_of()` have existed since then; `TRACE_META_KEYS` names `traceparent`, `tracestate`, `baggage`. The server parses the trace id and writes it into a `CallAudit`. Two logs mentioning one id is not a tree: you cannot see that the server's tool call happened *inside* the model call that asked for it.

**Phase 5 built the cost model and `RequestAccount` is still the record.** Invariant 36: a record stores tokens and calls, never money. This phase derives a `RequestAccount` *from spans* rather than inventing a second cost model — invariant 80.

**Phase 9 introduced the checkpointer; Phase 10 made `durability="sync"` the default.** Both bite in §7: a checkpointer stores messages by thread id and refuses nobody, and `"sync"` requires a checkpointer to exist.

**Phase 14 established the permission tier, the egress boundary and the audit log.** All three produce records. None is read by anything that watches.

### Two orientations

**Asyncio and ASGI.** FastAPI is an ASGI framework: your handler is a coroutine and the server interleaves many requests on one event loop. Consequence one: a module-level global shared by two concurrent requests is a bug that only appears under load, which is why the span stack lives in a `contextvars.ContextVar` — each task gets its own view and the previous value is restored on exit, so two users' spans cannot become each other's parents. Consequence two: **you can test all of it with no socket.** `fastapi.testclient.TestClient` drives the real app through the real ASGI interface in-process, and every HTTP assertion in this phase runs that way. Appendix A has the longer version.

**SSE.** Server-Sent Events is a one-way stream from server to browser over an HTTP response that never ends. The server sets `Content-Type: text/event-stream` and writes frames: an optional `event:` line, an optional `id:` line, a `data:` line, and a **blank line** terminating the frame. That blank line is the protocol's one gotcha — omit it and the browser buffers forever, so a correct server looks hung. SSE rather than WebSockets because agent progress is one-directional and SSE rides on plain HTTP, surviving proxies that mangle WebSocket upgrades; `EventSource` also reconnects and resumes from the last `id`. The cost is that a payload cannot contain a bare newline, which JSON-encoding solves by construction.

## 6. [core] Core concepts

### 6.1 [core] A span, and why a log line is not one

**Intuition.** A log is the cook shouting each thing as it happens; you can reconstruct a timeline if you squint, and the moment a second cook shouts into the same room you cannot. A **span** is a card saying *what* was being done, *when it started*, *when it stopped*, and *which card it belongs inside*. Lay the cards out and the two hours explain themselves — and you can hand the stack to somebody who was not in the kitchen.

**Precisely.** A **span** is one named, timed operation with a status and attributes. A **trace** is every span sharing a trace id. A span records its parent's *span id*, not a reference. A **trace id** is 16 random bytes as 32 lowercase hex characters; a **span id** is 8 bytes as 16 hex characters.

Parenting-by-id is why distributed tracing works. Atlas and the MCP server share no object graph, no call stack and, in production, no machine. They can share 32 characters travelling in `_meta`. Each process records independently, the backend receives two unrelated lists, and the tree assembles by matching ids. Nothing must be coordinated; nothing must arrive in order.

The wire format is W3C Trace Context, one header:

```
traceparent: 00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01
             ^^ ^------------ trace id -------^ ^--- span id --^ ^^
          version                                              flags
```

```python
# excerpt: atlas/obs/spans.py
def parse_traceparent(raw: str | None) -> SpanContext | None:
    """Parse a `traceparent`, or return None. Pure, strict, total.

    Returns None rather than raising because the caller is always "somebody
    sent us a header" and the correct response to a bad one is to start a new
    trace, not to fail the request. Rejects the all-zero trace and span ids,
    which the W3C spec declares invalid -- a permissive parser that accepts
    them files every such request under one trace id, and that trace id ends
    up containing every unrelated request from every buggy client you have.
    """
    if not isinstance(raw, str):
        return None
    match = TRACEPARENT_RE.match(raw.strip())
    if match is None:
        return None
    trace_id, span_id, flags = match.groups()
    if trace_id == _ZERO_TRACE or span_id == _ZERO_SPAN:
        return None
```

Two decisions. It **returns `None` rather than raising**, because the header comes from a caller you do not control and the right response to a malformed one is a fresh trace, not a failed request. And it is **strict**: a permissive parser attributes a stranger's spans to your trace, and buggy clients send all-zero ids constantly — accept them and you acquire one trace id containing every such request forever, which is useless and, once `GET /v1/traces/{id}` exists, a disclosure.

> **Misconception: "structured logging gives me this already."**
> Structured logs give you the *attributes*. They do not give you **causality** or **duration**. Two log lines with one `request_id` tell you both things happened during one request; they do not tell you one happened *inside* the other, and they cannot give you the gap without subtracting timestamps across clock domains. The span tree is exactly the shape "what contained what, for how long". Honest framing: spans are structured logging taken seriously about time and nesting.

```python
# excerpt: atlas/obs/spans.py
        ambient = _CURRENT.get()
        if parent is not None:
            trace_id, parent_id = parent.trace_id, parent.span_id
        elif ambient is not None:
            trace_id, parent_id = ambient.context.trace_id, ambient.context.span_id
```

**Explicit beats ambient**, and not arbitrarily. When the MCP server handles an inbound call an ambient span usually *does* exist — in `make test-offline` the server runs in-process. Parent to the ambient one and you get a correct-looking tree that has silently stopped testing the propagation.

```python
# excerpt: atlas/obs/spans.py
        except BaseException as exc:  # noqa: BLE001 -- re-raised immediately
            span.status = "error"
            span.error_type = type(exc).__name__
            raise
        finally:
            span.end_s = self._now()
```

Closing in `finally` is the point: an exception, an early `return` inside a `with`, and a `GraphInterrupt` — which Phase 10 established is *control flow*, not an error — all leave by this path. A span closing only on success measures the requests that did not need measuring. Invariant 27's shape. Note what the error branch records: the exception **type**, never its message. A message can carry a database row; a type name cannot, and `error.type` is one of the three attributes OpenTelemetry marks Stable.

> **Concept check 6.1.** `duration_ms` returns `None` for an open span rather than `0.0`. Name one dashboard and one alert that would be wrong if it returned `0.0`.

**Your turn (5 min).**

```python
from atlas.obs.spans import Tracer, render_tree
t = Tracer()
with t.start("outer"):
    with t.start("inner"):
        pass
with t.start("second request"):
    pass
print(render_tree(t.spans)); print(t.trace_ids)
```

Two traces, not one. Now construct `Tracer(trace_id="f"*32)` and explain the difference in one sentence.

### 6.2 [core] One request, two processes, one tree

Phase 12 handed the server a business card with a reference number. The server wrote it in its own ledger. Two ledgers, one number. We want the server's entry *filed inside* ours.

```python
# excerpt: atlas/mcp/tools.py
    def _trace() -> str:
        """The traceparent for THIS call, resolved at call time.

        Phase 12 minted one traceparent when the tool was BUILT and reused it
        for every call, which put every remote call of every request under one
        span id -- a tree in which the second call is the first call's sibling
        by accident and nobody's parent. Resolving here means the parent is
        whatever Atlas span is open right now, so `execute_tool` on the server
        lands under the `chat` span that asked for it.
        """
```

That is **F-15-03**: *a value captured in a closure is a value frozen at the wrong scope.* Anything describing "now" is a function, not a variable. It survived three phases because nothing assembled the spans — invariant 72's corollary, an unwired mechanism conceals the bugs in everything it touches.

```python
# excerpt: atlas/mcp/server.py
        parent = parse_traceparent(raw if isinstance(raw, str) else None)
        span_name = semconv.span_name("execute_tool", remote_name or local_name)
        with tracer.start(
            span_name,
            kind="server",
```

`kind="server"` is how a backend knows this process *received* a call rather than made one, and how a trace view draws the boundary between services.

```
$ make spans
trace 0a6c9a1c6a9926e2dbc5680b6ac51f51
    invoke_agent atlas                                               55.65ms
      chat fake                                                      55.61ms
        execute_tool search_company_docs                              0.16ms

distinct trace ids                    1  (should be 1)
spans from the MCP SERVER             1
server span has a parent              True
```

Assembly is order-independent, because two services' spans arrive interleaved. And a span whose parent is absent becomes an **orphan root**, not a dropped node:

```python
# excerpt: atlas/obs/spans.py
        else:
            node.orphaned = True
            roots.append(node)
```

The commonest cause is that the other service's spans have not arrived. Dropping them renders a plausible tree of half a request — F-07-06 with a network in the middle, worse than rendering nothing because a reader believes it. The §11 eval task grades `orphans == 0` for exactly this reason: a span *count* check passes for a tree that is three disconnected roots, which is what F-15-01 produced.

> **Misconception: "the trace id is the request id."**
> Related, not the same. A request id is yours and means "one call to my API". A trace id is *shared*, crosses organisational boundaries, and may cover work beginning before your service and continuing after it. Atlas records both: `atlas.request_id` is what a ticket quotes, `trace_id` is what you paste into Jaeger. Collapse them and you cannot trace a request that arrived with context attached.

> **Concept check 6.2.** The MCP server in `make test-offline` runs in-process, so an ambient Atlas span exists when its handler runs. If `Tracer.start` preferred ambient over explicit, the tree above would look *identical*. What stopped being tested, and which test in `tests/test_service_phase15.py` would still have caught it?

### 6.3 [core] What belongs on a span, and what must never

Ask of every field: *am I willing for this to sit in a third-party system for ninety days, searchable by the whole engineering org?* Token counts yes; the customer's question no.

**Semantic conventions** are an agreed vocabulary so a span from LangChain, a provider SDK and Atlas mean the same thing by "the model". The GenAI ones live under `gen_ai.*`. **Their status is a current-state fact and lives in `VERSIONS.md`** — that row is this phase's one non-negotiable reading assignment, because the conventions are in motion. What to carry in your head is the *shape*, which is stable: a small number of attributes inherited from the core conventions are Stable, everything under `gen_ai.*` is not, and content capture is opt-in.

```python
# excerpt: atlas/obs/semconv.py
GEN_AI_OPERATION_NAME = "gen_ai.operation.name"
GEN_AI_PROVIDER_NAME = "gen_ai.provider.name"
GEN_AI_REQUEST_MODEL = "gen_ai.request.model"
```

A spec rename becomes a diff in one file — worth more than usual precisely *because* the vocabulary is unstable.

```python
# excerpt: atlas/obs/semconv.py
    # `is not None` rather than truthiness at every site: temperature 0.0 and
    # seed 0 are both meaningful and both falsy, and Atlas's default
    # temperature IS 0.0. A truthiness test here drops the attribute from
    # every default call, i.e. from almost every span.
    if temperature is not None:
```

The same applies to token counts: `0` is a **fact** — it is what a cache hit looks like — and an instrumentation omitting zeros makes cache hits invisible in the dashboard built to find them.

**What leaves the process is an allowlist.**

```python
# excerpt: atlas/obs/redact.py
ATTRIBUTE_ALLOWLIST: frozenset[str] = frozenset(
    {
        semconv.GEN_AI_OPERATION_NAME,
        semconv.GEN_AI_PROVIDER_NAME,
        semconv.GEN_AI_REQUEST_MODEL,
```

Absent: `gen_ai.input.messages`, `gen_ai.output.messages`, `gen_ai.system_instructions`. Those exist in the conventions and are opt-in *there* for the reason they are absent *here*. A tool span carries no arguments either — the same refusal `arguments_digest` made in Phase 14, and refusing it there while emitting it here would be a control with a hole. An allowlist because a denylist over an open set of keys is a promise to have thought of every key anyone will add, and the key somebody adds next quarter is `user_email`.

Filtering happens on the way out:

```python
# excerpt: atlas/obs/redact.py
    Returns a NEW dict; the span keeps whatever it was given. That separation
    matters: the span is what a developer reads with `make trace` on their own
    machine, and the exported copy is what leaves the process. Filtering in
```

```python
# excerpt: atlas/obs/redact.py
def luhn_ok(digits: str) -> bool:
    """The Luhn checksum. Pure.

    Used to stop the card pattern from eating every sixteen-digit number in
    the corpus -- order ids, invoice numbers, the Northwind row counts. A
    false positive in a redactor is not harmless: it deletes the field that
    would have explained the failure, and it does so silently.
    """
```

Printed evidence:

```
input    Contact ada@example.com or 416-555-0134. Card 4111 1111 1111 1111.
         Order 1234567890123456 shipped. Authorization: Bearer abcdefgh12345678
output   Contact [email] or [phone]. Card [card]. Order 1234567890123456 shipped.
         Authorization: [bearer]
redactions: bearerx1, emailx1, cardx1, phonex1
order number survived (Luhn)          True
```

**The honest limit.** This protects against *accidentally* logging customer data — a real, common, boring incident. It does **not** protect against an adversary, who chooses the encoding: base64, homoglyphs, splitting a number across two attributes all pass. Phase 14's test applies: ask what the attacker must do to pass. "Write the number differently" → it is a **layer**. The **boundary** is the allowlist, which holds regardless of encoding because the *key* never made the list.

```
attribute keys that survived the allowlist:   13
absent by design (content-carrying, Opt-In in the conventions):
    gen_ai.input.messages              present=False
    gen_ai.output.messages             present=False
    gen_ai.system_instructions         present=False
```

> **Concept check 6.3.** You are asked to add prompt text to spans "just in staging, to debug a prompt regression". Name two things that must be true of the *configuration* for that to be defensible, and one thing about staging data that usually is not.

**Your turn (10 min).** Add `atlas.user_note` to a span and export it; confirm it is absent from the OTLP body. Now add it to `ATTRIBUTE_ALLOWLIST` containing an email address and export again. What appears, and what does that tell you about the *order* of allowlist and scrubber?

### 6.4 [core] The reference architecture

```
                    ┌──────────────┐
   users ─────────► │   gateway    │  TLS, rate limits, auth token check,
                    │              │  request id, traceparent injection
                    └──────┬───────┘
                    ┌──────▼───────┐
                    │  API (this   │  routing, tenancy, SSE, thread
                    │   phase)     │  registry, job submission
                    └──┬────────┬──┘
              sync     │        │   async
                       │        ▼
                       │   ┌─────────┐      ┌──────────┐
                       │   │  queue  │─────►│ workers  │
                       │   └─────────┘      └────┬─────┘
                    ┌──▼─────────────────────────▼──┐
                    │      agent runtime            │
                    │  (graph + checkpointer)       │
                    └──┬─────────────┬──────────┬───┘
                ┌──────▼────┐  ┌─────▼─────┐  ┌─▼──────────┐
                │  model    │  │   tools   │  │ MCP server │
                │  servers  │  │  RAG, SQL │  │ (Phase 12) │
                └───────────┘  └───────────┘  └────────────┘
                       │             │              │
                       └─────────────┴──────────────┘
                                     │ OTLP
                            ┌────────▼─────────┐
                            │  observability   │
                            └──────────────────┘
```

**Gateway.** TLS, rate limiting, the first authentication check, and it mints or forwards the `traceparent` — which is why §6.2's parser must be strict. A system where each service invents its own trace id has as many traces as services.

**API.** Decides *who* is asking, *which* thread this is, and *whether the work happens now or later*. Holds no agent logic: `build_api` takes a `handler` callable and knows nothing about Atlas, because the web layer is where authorization, tenancy and streaming live and none of those needs a model to be wrong.

**Queue and workers.** The boundary between "a person is waiting" and "a person is not". §6.6 is about what changes across it.

**Agent runtime with a checkpointer.** Phase 9's compiled graph plus durable state: what makes a paused approval resumable and a crash lose one step rather than one conversation.

**Model servers.** Plural: a routing model and an answering model are different deployments with different hardware.

**Observability.** Arrows point *in* from every box. A system where only the API is instrumented tells you a request was slow and never which box made it slow.

> **Misconception: "over-engineering for a small company."**
> These are *logical* boxes. Atlas runs all of them in one process in `deploy/docker-compose.yml`. What matters is that the **seams** exist — the job runner is an injected callable, the thread registry is separate from the checkpointer, the exporter is a parameter. A monolith with seams becomes three services in an afternoon; without them it becomes a rewrite.

> **Concept check 6.4.** The gateway injects a `traceparent`. Name one debugging question you can answer with that which you cannot if the API mints its own trace id per request.

### 6.5 [core] Sync, async, and streaming

Three answers to *how long the work takes relative to how long a person will hold still.*

| | sync | streaming (SSE) | async (job) |
|---|---|---|---|
| Connection held | whole answer | whole answer | milliseconds |
| Good up to | ~5 s | ~60 s | hours |
| Survives a deploy | no | no | **only if the queue is durable** |
| Client complexity | trivial | moderate | poll or webhook |
| Partial results | none | yes | progress notes |

Most agent traffic lives in the middle column, for a psychological reason: a first token at 400 ms and a last at 12 s *feels* faster than a silent 6 s wait. Streaming does not reduce total latency at all. It reduces the interval during which the user has no evidence anything is happening, and that interval is what people experience as slowness.

```python
# excerpt: atlas/api/sse.py
    lines: list[str] = []
    if event is not None:
        lines.append(f"event: {event}")
    if event_id is not None:
        lines.append(f"id: {event_id}")
    lines.append("data: " + json.dumps(payload, separators=(",", ":")))
    return "\n".join(lines) + "\n\n"
```

The trailing `\n\n` is the frame delimiter; omit it and the browser buffers forever. The `json.dumps` does more work than it looks: a payload cannot contain a bare newline because `\n` terminates the `data:` line, and JSON escapes its own newlines. That is a correctness fix and a security property at once — a user whose question contained `\n\ndata: ` could otherwise inject frames into their own stream. **An injection defence obtained by choosing an encoding rather than writing a filter** has no bypass to enumerate.

Proxies close idle connections, and an agent thinking for forty seconds looks idle; a comment frame every fifteen seconds keeps the socket warm. And:

```python
# excerpt: atlas/api/app.py
                "Cache-Control": "no-cache",
                "X-Accel-Buffering": "no",
```

`no-cache` stops a CDN serving one user's stream to another — a tenancy bug delivered by infrastructure. `X-Accel-Buffering: no` stops nginx buffering the whole response, which is *the* answer to "streaming works locally and not in production". Neither is discoverable from application logs, which is why both are runbook item one.

```python
# excerpt: atlas/api/sse.py
AgentEventKind = Literal[
    "start",      # the request was accepted; carries request_id and trace_id
    "plan",       # the route and, where there is one, the step list
    "tool",       # a tool call began or ended
    "token",      # a chunk of the answer
    "approval",   # the run is paused and needs a human
    "done",       # terminal, carries the account
    "error",      # terminal, carries an error kind and a human message
]
```

Seven kinds and `parse_sse` raises on anything else. A UI rendering an unknown kind by guessing shows a user something nobody designed. Invariant 30 applied to a protocol.

Every path must terminate. A stream ending without `done` or `error` is a spinner nobody stops — precisely what an unhandled exception inside a generator produces, because the generator stops yielding and the connection closes cleanly. So the endpoint catches and puts the exception **type** on the wire, not its message:

```python
# excerpt: atlas/api/app.py
                yield sse_event(
                    {"error_kind": type(exc).__name__, "message": "the request failed"},
                    event="error",
                    event_id=seq,
                )
```

**Streaming tokens without writing a second agent.** The tempting way to add streaming is a streaming handler beside the synchronous one — at which point routing, tools, the egress filter and the accounting exist twice, and invariant 60 says they will diverge and only an equivalence test will notice. Atlas does the opposite: a client wrapper implements `complete()` **on top of** `stream()`, so the handler is unchanged and the deltas leave through a callback while its `complete()` call is still running.

```python
# excerpt: atlas/obs/instrument.py
    def complete(self, messages: Sequence[Message], **kw: Any) -> Completion:
        inner_stream = getattr(self._inner, "stream", None)
        if not self.enabled or inner_stream is None:
```

One policy, two transports.

**The bound, and why it is on the wire rather than in this paragraph.** Only the **last** model call of a request produces the answer. A route whose handler makes three calls would tee the router's label and the intermediate reasoning straight to the user's screen. So teeing is enabled only for routes whose handler makes exactly one model call:

```python
# excerpt: atlas/api/app.py
STREAMING_ROUTES: frozenset[str] = frozenset({"chat"})
```

and a test **counts the calls** rather than trusting that sentence — mechanism belongs in `tests/`, per the Phase 11 division. Every `token` event then carries `source: "model"` or `source: "replay"`, and `start` carries `streamed`, so a client cannot claim streaming the server did not do and this document cannot either.

> **Concept check 6.5b.** `TeeingClient.complete` raises `LLMTransportError` when the stream ends without a terminal `Completion`, rather than returning a `Completion` built from the text it saw. Name the two fields such an invented `Completion` would have to make up, and which invariant that would break.

> **Concept check 6.5.** `encode_stream` is a generator rather than a function returning a list. A list version type-checks identically and passes every unit test. What breaks, and why would nobody file it as a bug about streaming?

### 6.6 [core] Long-running and event-driven agents

A chat agent is a waiter; a worker agent is a contractor with your key. **The difference is not duration, it is who is waiting** — and that changes three decisions.

**Asking.** A chat agent can pause and ask; Phase 10's gate assumes somebody is there. A worker must decide in advance: refuse and report, queue the question and stop, or run under a tier that cannot reach anything worth asking about. Atlas takes the third — `confirm=None` in `make_remote_tools` means a confirmation request returns `write_refused` rather than being answered on a human's behalf. An agent that auto-approves because nobody is watching has inverted the gate.

**Failing.**

```python
# excerpt: atlas/api/jobs.py
            except Exception as exc:  # noqa: BLE001 -- recorded, not swallowed
                # Broad, and every field of it is written down: invariant 67
                # says a broad `except` converts a programming error into a
                # business outcome, so the type name goes into `error_kind`
                # where an alert can see `KeyError` and page somebody.
```

The clause must be broad — a job runner cannot enumerate what arbitrary work raises — so the discipline moves to what it *records*. `KeyError` is something an alert rule matches; "the research failed" is not. And `JobCancelled` is caught **separately**, producing `cancelled` rather than `failed`: a cancelled job reported as failed sends somebody to read a traceback for a thing that worked, and after the third time they stop reading tracebacks.

**Stopping.**

```python
# excerpt: atlas/api/jobs.py
        self._cancels[job_id].set()
        if record.status == "queued":
            # Never started, so nothing has to notice the flag. This is the
            # only case in which cancel is immediate, and conflating it with
            # the running case is how a UI ends up claiming a running job
            # stopped when it did not.
```

Cancellation is **cooperative**; work that never checks the flag never stops. Atlas says so on the wire:

```json
{"job_id": "…", "status": "running",
 "note": "cancellation is cooperative: work already running stops at its next checkpoint"}
```

Putting that in the response rather than the documentation is the design decision. ASI10 says a stop halts the loop and not the effects; a green "cancelled" tick over a running agent is that truth with a checkmark drawn on it.

```python
# excerpt: atlas/api/jobs.py
def thread_runner(work: Callable[[], None]) -> None:
    """Run the work on a daemon thread. The development runner.

    A daemon thread dies with the process, which is honest about what this
    is: fine for a laptop, wrong for production, where a job must survive a
    deploy. The production shape is a queue and a separate worker process
```

The runner is injected. Tests use `inline_runner`, so the whole lifecycle is covered by `make test-offline` with no concurrency in it — invariant 38 one layer up. It also makes a property visible: with `inline_runner`, `POST /v1/jobs` **blocks**, which is what a job endpoint must not do. Swap the runner, watch the latency move, and you have understood the background-ness.

```python
# excerpt: atlas/api/jobs.py
                    f"{subject!r} already has {len(live)} unfinished jobs "
```

A **per-subject** cap: a global one lets one tenant starve every other, the multi-tenancy failure that presents as an outage and gets debugged as capacity. The endpoint returns **429**, not 500 — the request was well-formed and should be retried later, which is the only part a retry library reads. And `POST /v1/jobs` returns **202**, not 200: a proxy, a retry library and a monitor all read the status code without parsing your body, and 200 makes every one treat an unfinished job as finished.

**Event-driven triggers.** A schedule, a webhook, a notification — all funnel into the same `JobStore`. The security note: a webhook is untrusted input arriving with no human in the loop, so the lethal-trifecta check applies to the *configuration of the job*. A scheduled job holding private data, reading webhook payloads and able to send email is all three legs with nobody watching.

**MCP Tasks.** [reading] The protocol has the same problem one layer down: a *tool call* taking minutes cannot hold a connection. Its answer is the Tasks extension — the server returns a durable task handle, the client polls. Opt-in per request through `_meta`; the server must not return a handle to a caller who did not ask. Identifier, SEP number, required protocol revision and status are in `VERSIONS.md`. Atlas does not implement it: its remote tools are sub-second, the extension needs a protocol revision the SDK pin may not negotiate, and the concept transfers from the background-job build. The takeaway is the **symmetry** — when Atlas's tools become slow, the fix at the protocol boundary and at the HTTP boundary are the same fix, and a system with one and not the other has a queue in front of a blocking call.

> **Concept check 6.6.** A scheduled job runs nightly under a subject with `operator` tier. Name the three legs of the lethal trifecta in that configuration and say which is cheapest to remove.

**Your turn (10 min).** Submit a job with `inline_runner` and time the endpoint; swap to `thread_runner` and time it again. Then make the work sleep two seconds checking the cancel flag in a loop, cancel after one, and watch `status` move `running` → `cancelled`. Note how long the `DELETE` took versus how long the work took to notice.

### 6.7 [extended] Serving open-weight models — reading, not building

You will be asked within a year why the inference server your company runs is slow. Four ideas answer it.

**Development versus production.** Ollama is optimised for one person on one machine. A production server is optimised for many concurrent requests on expensive hardware, and the difference is almost entirely about what happens *between* requests.

**Continuous batching** is the biggest win. Naive batching waits for a batch to fill, runs it, and waits for the slowest sequence — so the GPU idles while one long generation finishes alone. Continuous (iteration-level) batching schedules after every forward pass: a finished sequence frees its slot immediately. Throughput under concurrency is several times a naive loop's on identical hardware. It is on by default, which is why the advice is "do not tune it first".

**KV cache and PagedAttention.** Generating token *n+1* needs keys and values for tokens 1…*n*; recomputing is quadratic, so they are cached. That cache is large, grows with sequence length, and is the actual constraint on concurrency. A naive implementation allocates a contiguous worst-case block per sequence and fragments memory catastrophically. PagedAttention applies virtual-memory paging: fixed-size blocks, a per-sequence block table, non-contiguous storage. The effect raises the concurrency ceiling, not single-request speed.

**Quantization** stores weights at 8 or 4 bits instead of 16. Memory scales roughly with bit width, which is what fits a 12B model on a laptop. It costs accuracy, by an amount that depends on model, method and task in genuinely contested ways — treat any single number as a claim about one benchmark. Quantization is how you fit a model on hardware you have, not how you make it better; measure your own task before and after.

**GPU sizing.** `VRAM ≈ weights + KV cache + activations/overhead`. Weights are parameters × bytes per parameter: 12B at 4-bit ≈ 6 GB, at 16-bit ≈ 24 GB. The KV cache scales with concurrent sequences × context length and at production concurrency is frequently **larger than the weights** — the sizing mistake, because everyone computes weights and stops. If you can fit the weights but not comfortably, your concurrency is one, and one concurrent request on a GPU is an expensive way to be slow.

**For Atlas:** nothing in the code, two things in your head. The router exists partly so a small cheap model classifies while a larger one answers — two deployments, not one. And `/metrics` breaking latency down per operation is what tells "the model got slower" from "we ask it more often", which are the same symptom and different fixes.

### 6.8 [core] State in production

**The checkpointer is not a database of conversations.** It stores graph state by `thread_id`, refuses nobody, and knows nothing about users — correct for a persistence primitive. For an API it means: **a `thread_id` handed straight to `graph.invoke` is a bearer token made of a UUID.**

```python
# excerpt: atlas/api/threads.py
        record = self._records.get(thread_id)
        if record is None or record.subject != subject:
            raise ThreadNotFound(
                f"no thread {thread_id!r} for this caller"
            )
        return record
```

Four decisions. A **separate store**, because ownership is an authorization fact the checkpointer has no opinion about. It **raises rather than returning `None`**, because `-> Record | None` is a design where forgetting one `if` silently authorises everything — and there will be six call sites. The **same refusal** for "no such thread" and "not yours", because distinguishing them is an oracle confirming which ids are real. And the comparison happens *in the lookup*; the runbook records that the Postgres version must put it in the `WHERE` clause, because a fetch-then-check loads the row you were refusing.

The general name is **broken object-level authorization**, near the top of the OWASP API risk list for years. It arrives in agent services through this door: the framework's example passes the thread id through, and the example has one user.

> **Misconception: "we'll use UUIDs, so nobody can guess a thread id."**
> Unguessability is not authorization. Ids leak through screenshots, tickets, history, referrers and shared URLs. Random ids are a reasonable second layer — `new_thread_id` is random, not sequential — but a system relying on them has no authorization, and the first support engineer to paste a thread id into a shared channel demonstrates it.

```python
# excerpt: atlas/api/threads.py
        doomed = [r for r in self._records.values() if r.updated_at < cutoff]
```

Retention is a function somebody calls, not a timer: a timer that deletes customer data should appear in a stack trace. And a warning: `delete` removes the *registry* entry, not the checkpointer rows. Shipping half is a deletion endpoint that deletes the index and leaves the data — worse than none, because you told somebody their data was gone.

**Migrations.** Add fields with defaults so old rows load; never *repurpose* a field, or an old row and a new row mean different things by one name and nothing tells you. Phase 6's index manifest is the pattern: it records the embedder fingerprint and **raises** on mismatch, because a stale cache costs calls and a stale index costs a wrong answer nobody notices.

**Multi-tenancy.** Row-level (one database, a `subject` column, every query filtered — cheap, one missing `WHERE` is a breach), schema-level, or instance-level (expensive, the only one where a query bug cannot cross tenants). Atlas is row-level with the filter in one function. The credential half is what people skip: Phase 12's tokens are minted per call with scopes derived from the route, and Phase 14's tier narrows the registry *before* handlers are built. A service that authenticates at the front door and uses one service account downstream has ASI03's confused deputy with no attacker required — the downstream system cannot tell tenants apart, so it cannot refuse.

> **Concept check 6.8.** Atlas holds *one* tracer per process and `GET /v1/traces/{id}` filters by subject. What retention hazard does that create which does not exist for threads, and what would you do before real traffic?

### 6.9 [core] Cost and latency in production

```python
# excerpt: atlas/obs/metrics.py
class LatencyStats(BaseModel):
    """A latency distribution, summarised honestly."""

    n: int
    p50_ms: float
    p95_ms: float
    max_ms: float
```

**No mean.** Nine 200 ms requests and one 20 s timeout give a mean of 2.2 s — a value nobody experienced and no timeout would catch. p50 is what a typical user feels, p95 what an unlucky one feels, max is what you are paged about. `n` sits beside them so a reader can see that a p95 over four samples is decoration.

**Open spans are counted separately.** Including them at zero drags p50 down **exactly when the process is hanging**, so the dashboard looks healthiest at the worst moment. Counting them apart makes "p95 is fine and forty spans never closed" sayable, and that sentence is the diagnosis.

**Cost is produced, never stored** (invariant 36); `account_from_spans` rebuilds Phase 5's record rather than inventing a second model (invariant 80). `render_metrics` prints `cost: no rate card supplied; see invariant 36` without a dated card.

**Five levers, in the order they pay.** (1) Per-tenant budgets, constructed **once per run outside the loop** (invariant 16) — one rebuilt per request never triggers, and the tell is spend rising while the budget metric reads zero. (2) Tool-result caching, only for tools declared `read_only` *and* `cacheable`, and remembering invariant 83: anything varying per call that reaches a prompt is a cache key you just changed. (3) A small model for routing — classification is a short prompt and a one-word answer, and paying frontier rates for it is the commonest avoidable line on an agent bill. (4) Early exits: an abstention computed by code from the retrieval costs nothing and saves a whole generation. (5) First-token streaming — free, changes no total, moves perceived latency more than the rest; listed last because listing it first encourages treating a perception lever as a performance fix.

**Alerting, which is where Phase 14's loop closes.** A dashboard is read when somebody thinks to look. Phase 14 ended by naming its own gap — the audit log had a renderer and no aggregation, the `EgressReport` named blocked hosts and nothing alerted on them — and concluded that *a control that fires correctly and is read by nothing is indistinguishable from an absent control* (invariant 62). Spans are half of that. `atlas/obs/alerts.py` is the other half, and two one-line properties are its whole design.

```python
# excerpt: atlas/obs/alerts.py
    def fires(self, before: float, after: float, samples: int) -> bool:
        if samples < self.min_samples:
            return False
```

**One-sided comparison**: `after >= before * ratio`, never the symmetric version. A rule firing on any difference is a change feed with a pager attached, and the first week of noise is the last week anybody reads it. **A sample floor**: below it nothing fires, because a p95 over two samples *is* the maximum.

The egress rule is deliberately different:

```python
# excerpt: atlas/obs/alerts.py
EGRESS_RULE = AlertRule(
    metric="egress_blocked", ratio=1.0, severity="critical", min_samples=1
)
```

`ratio=1.0` and `min_samples=1`: this is not a rate that should stay flat, it is an event that should not happen. Under a deny-all policy a blocked URL is either an attacker or a misconfigured allowlist, and both are worth waking somebody. **A threshold here would be a decision that some exfiltration attempts are acceptable.**

`make alerts` prints the loud cases beside the silent ones, which is the part worth reading as prose:

```
latency regression 100ms -> 400ms p95:
  [critical] chat gemma: p95_ms 100.000 -> 400.000 (n=40)
IMPROVEMENT 400ms -> 20ms p95 (must be silent):
  no regressions
same regression at n=2 (below the sample floor):
  no regressions
egress boundary, 2 URLs removed:
  [critical] egress: egress_blocked 0.000 -> 2.000 (n=1) URL(s) removed ...
```

> **Misconception: "alerting is an ops concern, not a security one."**
> Phase 14 built four controls whose only output was a record. A record nobody queries is one refactor away from a record nobody writes, and nothing will tell you when that happens — because the symptom of a security control silently ceasing to fire is that everything works. That is invariant 69's shape: over-permissioning is the only defect whose symptom is success.

**Three shapes.** `chat <model>` p95 up alone → the model backend. `execute_tool <name>` up → that tool's dependency; if it is remote, the failing span is inside the other service. `invoke_agent atlas` up while both are flat → **more steps per request, not slower steps**, which is a behaviour change and `make eval-gate` is the tool, not a profiler. Memorise the third: it is the only one where the instinct is wrong.

### 6.10 [core] Agent UX: designing for calibrated trust

Every interface teaches its user how much to trust it, and the error is not random: interfaces hiding uncertainty teach over-trust, and over-trust produces the incident. The goal is **calibration** — trust that tracks reliability.

**Show the plan before the work.** Phase 4's step list and Phase 10's route are already data. Showing them lets a user abandon a wrong plan at second one instead of minute three, and separates the agent's *understanding* from its *answer*. Most bad answers are bad because the question was misread.

**Show tool calls with names a human chose.** `execute_tool query_db` means nothing to a salesperson; "looking up the Q3 orders table" does. Same discipline as Phase 10's consequence renderers, extended to ungated tools. An agent silent for twenty seconds and then producing a number teaches the user to trust the number, because there is nothing else to trust.

**Stream partial results, labelled partial.** Invariant 35 derives the label from every incompleteness signal; it must reach the screen. "Based on 3 of 5 documents (2 could not be read)" calibrates; the same answer without it over-claims and the user cannot tell from the text.

**Approval without fatigue.** Four fixes, the fourth skipped most: gate **consequences, not calls** (`make policy` prints the exempt set with reasons); **batch**, because a person reads a list and skims a queue; **scope the grant** — "allow file writes in this workspace for this session" is auditable, "always allow" is a permission you stopped tracking; and **make the consequence concrete** — "Append 2 lines to `shared/notes.md`, visible to the whole team" beats "Allow write_file?". Phase 10's `MissingConsequenceRenderer` raises at wiring time precisely so an undescribable gated tool cannot ship.

**Error messages say what happened, what it means, what to do.** "Error: tool_error" versus "I couldn't reach the orders database (it timed out after 30s). Your question needs that data, so I stopped rather than guess. Try again in a minute, or ask me about the documents instead." The second adds no information Atlas lacks — it puts it where a person can act, and it does not apologise at length or offer a guess.

**Approvals are events, not a modal your framework happens to have.** Atlas emits an `approval` event carrying the *consequence* and a `reversible` flag, **before** the token events — because an approval the user meets after the answer has arrived is a rubber stamp. The consequence string comes from Phase 10's renderers, which is why `MissingConsequenceRenderer` raising at wiring time matters here: there is always something to say.

The `[extended]` console (`atlas/api/static/console.html`, served at `/`) is one file with no build step, and its job is to make these decisions visible rather than to be pretty. It maps tool ids to human names, refuses to render an event kind it does not recognise (a UI that guesses shows a user something nobody designed), shows `source: "model"` versus `"replay"` so it cannot overclaim, and renders a `partial` flag in words. A test pins its handled event set against `AGENT_EVENTS`, because a UI and a protocol that drift apart is how an approval goes unrendered.

**Feedback.** A thumb alone tells you something was wrong, not what. A thumb *plus the trace id* is a link to the exact span tree, and the first half of the flywheel.

**Five anti-patterns.** The **confident monolith** (one block, no sources, no uncertainty → uniform over-trust). The **fake progress bar** (percentages an agent cannot know → trust in a timeline, which then breaks trust in everything). The **infinite spinner** (no events, no keep-alive → abandonment and a ticket saying "it's broken" about a working system). The **consent wall** (approval for everything → clicking yes without reading, *worse* than no gate because it manufactures a record of oversight). The **silent retry** (three attempts behind one spinner → a user who believes the system is more reliable than it is, and a bill they cannot explain; invariant 15 has said since Phase 2 that retries are recorded, never hidden, and the screen is where that is cashed).

> **Misconception: "showing errors and uncertainty will make users trust it less."**
> It makes them trust it *correctly*. An interface hiding failures produces users who are confident until the day they are catastrophically wrong, and that day arrives with a decision already made on the agent's output. Calibration is not a tax on adoption; it is what lets adoption survive the first bad answer.

> **Concept check 6.10.** Atlas's stream emits `tool` with `{"name": ..., "phase": "end"}`. Name one thing a user cannot tell from that which they could if it carried `ok` and `error_kind` — and say why emitting the tool's *arguments* would be a mistake even though the UI would be more informative.

**Your turn (10 min).** Take `{"error_kind": "RuntimeError", "message": "the request failed"}` and write the three-part message a user should see. Then say which field the UI must *not* render verbatim, and why the server sends a type name rather than `str(exc)`.

### 6.11 [extended] Optional reading: Postgres, and load testing

**Postgres, for state.** `ThreadRegistry` and `JobStore` are dicts. The production shape is the same three methods over two tables, and exactly three things change. The subject comparison moves **into the query** — `WHERE thread_id = %s AND subject = %s`, never a fetch followed by an `if`, because the row you fetched is the row you were refusing. The `id` columns get a unique index and `subject` gets a plain one, because "list my threads" is the commonest query and a sequential scan over every tenant's rows is a tenancy problem wearing a performance costume. And `expire_before` becomes a `DELETE ... WHERE updated_at < %s` that must be **batched**, because a single unbounded delete over a large table takes a lock somebody will page about.

LangGraph ships a Postgres checkpointer, so the agent state moves with one constructor change. What does *not* move automatically is the pairing: deleting a `ThreadRecord` must delete the checkpointer's rows for that thread in the same transaction, or you have shipped a deletion endpoint that removes the index and leaves the data.

**Load testing, for capacity.** Three things make agent load testing different from web load testing, and all three trip people up.

*Concurrency is the axis, not requests per second.* An agent request takes seconds and holds a model slot for the duration, so "500 rps" is meaningless and "40 concurrent conversations" is the number that decides your GPU bill. Drive a fixed number of virtual users, not a fixed arrival rate.

*Your load generator must use realistic prompts.* Token count drives both latency and cost, and a benchmark of 10-token questions measures a system nobody will run. Draw from the seeded corpus, or better, from redacted production traces — which is the flywheel again.

*The metric is the p95 you already publish.* Run the load test against a deployment with tracing on, and read `/metrics` rather than the load generator's own numbers: the generator measures the client's view, and the per-operation breakdown is what tells you whether the ceiling is the model, a tool, or your own step count. When p95 rises and `chat <model>` p95 is flat, you have found a queue, and the queue is usually yours.

What you are looking for is the **knee**: the concurrency at which p95 starts rising faster than throughput. Past the knee, adding load makes everybody slower and serves no more people, which is the point at which you need another model replica rather than another application container.

## 7. [core] Hands-on: build it step by step

Eight steps. Run `make test-offline` after each.

### 7.1 The span model, and the field that ruined it

Write `atlas/obs/spans.py`: strict `parse_traceparent`, parenting by id, closing in `finally`. Then run two requests through one tracer. I did, and got `spans over 1 trace(s); 0 still open` — for three unrelated requests from two subjects.

```python
# excerpt: atlas/obs/spans.py
            # A PINNED trace id (passed to the constructor) is reused, because
            # pinning is what the caller asked for. A GENERATED one is not.
            # The first version cached the generated id into `_root_trace_id`,
```

`Tracer.start` cached a generated root trace id so a second parentless span joined the first one's trace — correct for a *pinned* id, catastrophic for a service, because `build_api` holds one tracer for the process lifetime. Every request Atlas ever served would have been one trace, and `GET /v1/traces/{id}` would have returned one subject's spans to another.

**Nothing failed.** Every test held a tracer for one request. What caught it was a printed number beside a label saying what it should mean — invariant 71 for the second phase running. That is **F-15-01**: *a field named for the case that motivated it will be read by the case that did not.* Name it for the case it excludes.

```python
# excerpt: tests/test_obs_phase15.py
def test_two_root_spans_on_one_tracer_are_two_traces():
    """F-15-01. One tracer per process must not pool every request."""
```

**Design decision: `contextvars`, not a module global.** A module global works perfectly in a script and interleaves two users' spans the first time two requests overlap — a bug appearing only under load, in production, reading as data corruption.

### 7.2 The vocabulary and the export boundary

`semconv.py` is constants and four builders; `redact.py` the allowlist and scrubber. `export.py` holds the interesting decision:

```python
# excerpt: atlas/obs/export.py
**Why hand-written OTLP rather than the OpenTelemetry SDK.** Two reasons, one
pedagogical and one structural. A student who has written the body once knows
what a span *is* on the wire and will never again be confused about why a trace
id is 32 characters. And invariant 2 requires `make test-offline` to pass on a
fresh clone; the SDK plus an OTLP exporter plus their protobuf dependency is a
large addition to a core install for something the offline suite must not use.
```

This is **not** advice to write your own exporter at work — use the SDK, which handles batching, retry, sampling and shutdown flushing. It is a teaching implementation speaking the real protocol.

```python
# excerpt: atlas/obs/export.py
def anyvalue(value: Any) -> dict[str, Any]:
    """Wrap a Python value in OTLP's `AnyValue`. Pure.

    OTLP is a typed format: every attribute value is a one-key object naming
    its type. `bool` is checked BEFORE `int` because `bool` is a subclass of
    `int` in Python, and a booleanValue arriving as intValue 1 renders in a
    backend as the number one -- true, technically, and useless in a filter.
```

A real trap: `isinstance(True, int)` is `True`, so the obvious ordering turns every boolean into a number and every dashboard filter on `atlas.tool.ok = true` returns nothing.

```python
# excerpt: atlas/obs/export.py
        if not endpoint:
            raise ExporterUnavailable(
                "OTLPExporter needs an endpoint, e.g. "
                "http://localhost:4318/v1/traces. Tracing is either configured "
                "or it is off; there is no third state."
            )
```

Invariant 78 transfers: an exporter with a silent fallback is an exporter on the machine where you tested it and an absence everywhere else. The payoff is in the runbook — "no traces and no errors" now means *the endpoint is not configured*, which halves the search.

### 7.3 Metrics over the same spans

Percentiles, per-operation buckets, open spans separate, and `account_from_spans` rebuilding Phase 5's `RequestAccount`. **Reuse the record, do not invent one** — invariant 80. "Cost accounting" already existed; a second implementation would be F-14-02 with a different noun, and the two would disagree within a phase.

### 7.4 Instrumenting the client

```python
# excerpt: atlas/obs/instrument.py
    Placement in the wrapper stack matters for the same reason it did in
    D-06. This goes **outside** the cache and the budget:
    `TracedClient(CachingClient(BudgetedClient(inner, budget), cache))`. A
    trace is a record of what the *application* asked for, so a cache hit
    must appear in it -- as a span with zero tokens and a duration of
    microseconds, which is the single most useful thing a cost dashboard can
    show you. Put the tracer innermost and cache hits vanish from the trace
```

Put the tracer innermost and cache hits vanish, and you get a graph of model calls that disagrees with the latency your users see and cannot be reconciled with it.

```python
# excerpt: atlas/obs/instrument.py
    def __getattr__(self, name: str) -> Any:
        """Forward anything else to the inner client.

        Invariant 64 says a wrapper forwards every method or it is a hole.
        `complete` and `stream` are overridden because they are instrumented;
        everything else -- `key_for`, `budget`, `hits`, whatever a later phase
        adds -- is forwarded by this one method, so the hole cannot reopen by
        omission. Only reached for attributes this class does not define, so
```

Phase 9's `BudgetedClient` forwarded `complete` and not `stream`. The identical hole is available here and is worse: a budget eventually raises, a missing span never does. `__getattr__` is the structural fix — it closes the hole for methods that do not exist yet.

```python
# excerpt: atlas/obs/instrument.py
                if first and not isinstance(piece, Completion):
                    tracer.event("gen_ai.first_token")
                    first = False
```

The span's duration is time-to-last-token; the number a user feels is time-to-**first**. They differ by the whole generation.

### 7.5 Crossing the process boundary

Server: `build_company_data_server` gains `tracer=None` and `_run_local` opens a span parented on the inbound `_meta`. `None` is byte-for-byte the Phase 12 behaviour, with a test saying so, because 1,498 tests depend on it. Client: `make_remote_tools` resolves the traceparent per call (F-15-03, §6.2).

```python
# excerpt: tests/test_service_phase15.py
def test_two_remote_calls_in_one_request_are_siblings_not_a_chain(tmp_path):
    """F-15-03's regression: one traceparent minted per BUILD, not per call."""
```

A span-count check passes for two server spans sharing one wrong parent. The parent link is the assertion. Verify with `make spans`.

### 7.6 The service

```python
# excerpt: atlas/api/app.py
`build_api(...)` takes every dependency as a parameter and returns an app. No
module-level `app = FastAPI()`, no client constructed at import time, no
registry read from a global. That is invariant 10 and invariant 16 arriving at
```

Invariants 10 and 16 at the web layer, and it buys the thing the phase could not otherwise have: the suite drives a *real* app through a *real* ASGI transport with a `FakeLLMClient` inside it. A module-level app makes that impossible and the tests mock the framework instead.

**`allow_anonymous` defaults to `False`.** Phase 14's `DEFAULT_PRINCIPAL` is a stated compromise for a library; this layer does not inherit it.

```python
# excerpt: atlas/api/app.py
API_AUDIENCE = "atlas-api"
```

A token for the MCP server must not open the API. An audience you can pass in is one a caller can talk you out of — ASI03, and the audience claim is the part people omit. Likewise **one message for every 401**: a 401 explaining which check failed is an oracle for forging the next attempt.

```python
# excerpt: atlas/api/app.py
        Checks no dependency on purpose. A liveness probe that pings the
        model backend restarts your app when the backend is slow, which
        removes capacity from a system that is already struggling -- the
        classic self-inflicted cascade, and Phase 14's ASI08 in an ops
        costume.
```

There is a test asserting liveness stays green while readiness is red, because the point is that they can disagree.

Then `POST /v1/jobs` hit `KeyError: 'duration_s'`. `JobRecord.duration_s` and `.terminal` were bare `@property`, which Pydantic does not serialise — a field the docstring described, the code computed, and the response lacked. **F-15-02**, invariant 11; this phase wrote six models and put bare properties on five. *The invariant easiest to violate is the one about serialisation, because the code is correct and only the edge is wrong — and the edge is where every consumer lives.*

### 7.7 Wiring it to the real Atlas

`make_atlas_handler` adapts Phase 5's `handle_request` or Phase 10's `run_atlas_graph`. The client is wrapped **once, outside the loop** (invariant 16); wrapping per request makes `n_spans` read 0 or 1 forever.

Routing at the graph engine raised `AttributeError: 'SyncPregelLoop' object has no attribute '_put_checkpoint_fut'`. `durability="sync"` waits for the checkpoint write — right for a service, and it *requires* a checkpointer. **F-15-05**, invariant 59: the framework's policy was "which mode is legal", not "which is desirable".

```python
# excerpt: atlas/api/service.py
    durability = "sync" if checkpointer is not None else "exit"
```

Then the wiring gate:

```
AssertionError: these public names have no call site outside their own module
and no written exemption: ['atlas/obs/redact.py::REDACTIONS',
'atlas/obs/export.py::to_otlp_json', 'atlas/api/service.py::make_atlas_handler',
'atlas/api/service.py::build_atlas_api', 'atlas/api/service.py::readiness_probe']
```

`build_atlas_api` — the function assembling the whole service — was called by `scripts/` and `deploy/` and nothing in `atlas/`. Invariant 72 is explicit that the results script does not count. **F-15-04**; the fix is `atlas/api/main.py`, a real ASGI entry point.

```python
# excerpt: tests/test_service_phase15.py
def _public_names(path: pathlib.Path) -> list[str]:
    """Read `__all__` from a module without importing it. Pure."""
```

Five names, none of which would have been on a list I typed. A second test asserts no exemption names something that no longer exists — the gate's own gate.

### 7.8 The stack

One `deploy/docker-compose.yml`: Jaeger, Ollama, Atlas, marked `# not executed during authoring; verified in companion-repo CI` (Docker is absent from the authoring container; invariant 48 says state what stopped you).

Dockerfile decisions: **never root** (a root container mounting a volume writes root-owned files onto the host, and an RCE in the app is an RCE as root); **dependencies before source**; **the health check is liveness**; and

```
CMD ["uvicorn", "atlas.api.main:app", "--host", "0.0.0.0", "--port", "8000", \
     "--timeout-graceful-shutdown", "30"]
```

That flag is the whole graceful-shutdown story. An agent turn takes twenty seconds; the default cuts users off mid-answer on every deploy. Set the orchestrator's grace period *longer*, or it SIGKILLs and you lose exactly the slow turns that were interesting.

In compose, `ATLAS_API_SECRET: "${ATLAS_API_SECRET:?set ATLAS_API_SECRET}"` makes a missing secret a startup failure rather than a service silently accepting tokens signed with an empty key; and `read_only: true` with one tmpfs and one named volume is Phase 3's jail enforced by the kernel rather than a path check.

```
$ make compose
docker compose -f deploy/docker-compose.yml --env-file deploy/.env up --build
  API      http://localhost:8000/docs
  traces   http://localhost:16686   (Jaeger; search service=atlas)
```

Two service names in one trace, because `service.name` is the one resource attribute every backend uses to separate processes.

### 7.9 The second pass — auditing the phase against its own block

Phase 14's lesson was that **the audit is the phase**, and it earned it again. After everything above was green — 1,602 tests, 69 eval tasks, `check-docs` passing — I read the phase back against the block it was written from, and found three things no test could have found.

**`serve_scenario` took a `scenario` argument and ignored it.** Three eval tasks passed three different values; the body never mentioned the parameter again; the docstring said "three scenarios, one per task, because a single scenario graded three ways hides which of the three broke." All three ran the identical probe set. That is **F-15-07**, and the method that found it is five minutes long and needs no tooling: *grep each new function's body for its own parameter names.*

**`approval` was a member of the event vocabulary with no emitter.** The parser validated it, a test constructed one, and no line of production code ever sent one. That is **F-15-09**, and it is F-15-06's cheat committed again in a different file in the same phase. Invariant 30 needs a line in `atlas/` that sets the member; instantiating the enum proves only that the enum exists.

**Two "stable" Makefile targets were broken and a third was silent.** `make plan` and `make record` exited non-zero because the results script implemented neither flag; `make demo` exited **0** having run nothing, because `--only` accepted section names that did not exist. That is **F-15-08**, and the silent half is the worse half: a failing target gets fixed on the day it fails, and a target that prints nothing gets assumed to have nothing to print. `--only` now validates against a closed `SECTIONS` tuple.

Two capabilities were also simply missing against the block: the `[extended]` web console, and regression alerting, which had been parked as an assignment. Leaving alerting as homework left invariant 62 — Phase 14's own closing argument — undischarged in the repo, which is the kind of gap you only see by re-reading the brief rather than the diff.

**The generalisation.** Every one of the three defects was a claim with no assertion behind it: a docstring, a comment in a Makefile, a `Literal` member. Tests assert what you thought to assert. The audit asks a different question — *does the code do what the document says?* — and it is the only question that catches a sentence.

### With an assistant

**Safe to delegate.** The OTLP encoder against a pasted spec example; the SSE parser given the format; FastAPI route signatures and Pydantic models; the Dockerfile's layer ordering; per-branch tests for the redaction patterns once you have written the patterns. All have an external specification the assistant can be checked against.

**Not safe.** Anything where the *policy* is the work: which attributes go on the allowlist; whether cancellation is cooperative and whether you say so; whether liveness checks a dependency; where `TracedClient` sits in the stack. An assistant will add `gen_ai.input.messages` "for better debugging", make `healthz` check the model, and write `resolve(...) -> Record | None`. Each is a defensible general default and none is Atlas's — invariant 59 with a new author.

**Especially not** the wiring audit: its value is that it grades the author's memory, and an assistant asked "is everything wired?" answers from the same reading that produced the gap.

**One prompt that works:**

> Here is `atlas/obs/spans.py` and the OTLP/JSON example from the OpenTelemetry file-exporter spec [paste]. Write `to_otlp_span(span)` mapping my model onto that shape. Constraints: pure function, no network, ids stay lowercase hex, 64-bit integers encode as JSON **strings**, `bool` must be checked before `int`. Then write one pytest per field, plus one asserting an open span is still exported with `endTimeUnixNano == startTimeUnixNano`. Do not add attribute filtering — that is a separate function I will pass in.

The last sentence holds the policy boundary where you want it.

## 8. [core] Debug this trace

09:41, a support ticket: *"Atlas took half a minute and then said it couldn't find the Q3 numbers. It found them yesterday."* You have the trace id from the thumbs-down feedback.

```
trace 7ad11986057e985b45ebe3f0ad4c334c
    invoke_agent atlas                                            31910.00ms
      chat gemma                                                    833.00ms
      execute_tool company_data_query                             30025.00ms
        execute_tool query_company_data                           30016.00ms
          atlas.tool.error_kind=tool_error
          server.address=atlas-company-data
!         db.query                                                30000.00ms
            error: TimeoutError
            server.address=northwind-replica
      chat gemma                                                   1022.00ms
```

Four facts are on the page and none is in Atlas's logs.

**1. The time is in one span.** 30,000 ms of 31,910 ms is `db.query`. The two model calls total 1.8 s. Nobody needs to profile the agent loop.

**2. The failing span is not in Atlas.** `server.address=northwind-replica`, nested inside a span whose `server.address` is `atlas-company-data`. The MCP server made a database call that timed out; Atlas's code did not fail, it *was told* of a failure.

**3. Thirty seconds is suspiciously round.** That is a configured timeout, not a slow query. A slow query is a database problem; a timeout at exactly the limit means the request never got an answer at all — pool exhaustion, a lock, or a replica that stopped responding.

**4. The second model call is the tell.** `chat gemma` runs again for 1,022 ms with a *larger* input. The loop did what Phase 3's `execute()` contract says: the tool returned `ok=False` with a message written for the model to act on, and the model wrote an honest answer. **The agent behaved correctly and the user still had a bad experience** — and with only Atlas's trajectory you would conclude the system worked.

**Diagnosis.** The Northwind read replica became unresponsive; every `query_company_data` call sat on the server's 30-second timeout and returned `tool_error`. The user's "it found them yesterday" is accurate: the data exists, the path does not.

**Confirm in ten seconds.** Filter for `service.name=atlas-company-data` and `span.name=db.query` over the last hour: if p95 is 30,000 ms and the error rate is near 1.0, it is every query. Then `/metrics` shows §6.9's second shape — one `execute_tool` row up, everything else flat.

**Three fixes, in order.** *Fix the replica* — the only one that makes the answer correct. *Shorten the timeout and say so*: thirty seconds is longer than any user will wait and longer than the request budget, and Phase 14's nested-timeout arithmetic applies; five seconds fails just as informatively, twenty-five seconds sooner. *Circuit-break it*: after three consecutive timeouts the breaker opens and the fourth request fails in microseconds naming the outage, which is the right trade when the answer was going to be bad anyway.

**And one that is not on the list.** Do not retry. A retry re-sends an identical query to a replica that is not answering, turning a 30-second failure into 90. Invariant 82: Atlas does not auto-retry a tool, because another loop step lets the model send a *different* call.

> Every fact above came from span *structure* — nesting, duration, `server.address`, `error.type`. Not one came from a log message, and not one was available before this phase. `atlas.trace` would have shown a correct trajectory ending in a truthful answer: the most misleading possible evidence, a picture of a system working.

## 9. [core] Common pitfalls

**Instrumenting only the entry point.** You learn requests are slow and never which box. Cheap test: pick your slowest endpoint and ask which *child* dominates. If the trace cannot answer, the instrumentation is decorative.

**One tracer with cached identity.** F-15-01. Professionals test with **two** requests, always.

**Prompt text in spans "temporarily".** Temporary instrumentation is permanent, and the retention period was set by somebody who thought spans held token counts.

**Redacting with a denylist.** The key somebody adds next quarter is `user_email`.

**A redactor with no false-positive control.** A card pattern with no Luhn check deletes the order id that would have explained the failure, silently — and the commercial version redacts customer identifiers out of the logs support uses.

**Passing `thread_id` straight to `graph.invoke`.** The framework example does it and the example has one user. Make the lookup *raise*.

**Distinguishing "not found" from "not yours".** A 403 versus a 404 is an oracle confirming which ids are real.

**Liveness that checks a dependency.** Cheap test: can your liveness probe fail while the process is healthy? If yes it is a readiness probe with the wrong name.

**Reporting mean latency.** Describes no request that ever happened.

**Counting open spans as zero-duration.** The dashboard looks best at the worst moment. Alert on the open count.

**Streams that end without a terminal event.** What an unhandled exception in a generator produces by default.

**Streaming that works locally.** `X-Accel-Buffering: no`, `proxy_buffering off`.

**Claiming a cancelled job stopped.** Say cooperative on the wire, where the person who will be surprised reads it.

**A global concurrency cap.** One tenant starves every other; presents as an outage, gets debugged as capacity for two days.

**Retrying into a timeout.** 30 seconds becomes 90; against an adversary a retry is another sample.

**Deleting the index and leaving the data.** Worse than no deletion endpoint, because you told somebody their data was gone.

**Believing the trace because it is pretty.** §8's trajectory was correct, complete and truthful, and the user still had a bad experience.

## 10. [extended] Industry perspective

**Everyone instruments to OpenTelemetry, and the GenAI layer is the unsettled part.** The argument is strategic: the LLM-observability vendor landscape has been churning through acquisitions, and a team instrumented to a vendor SDK pays the migration. OTLP makes the backend a configuration line. The trade-off is that the GenAI *vocabulary* is in motion — it moved to its own repository in 2026 and its stability markers are what `VERSIONS.md` tracks — so mature teams do what Atlas does: emit `gen_ai.*` from one module and treat a rename as a diff. Large instrumentations commonly dual-emit legacy and convention names during transitions.

**Content capture splits by industry.** The conventions default prompts and completions to off, opt-in per deployment. Consumer teams turn them on in staging and forget; regulated teams never turn them on and pay in debugging difficulty. The mature middle is §6.3's: content goes to a *separate*, shorter-retention, access-controlled store keyed by trace id, so the trace is safe to share widely and the content requires a reason. Both extremes fail: never capturing means you cannot reproduce a prompt regression; always capturing means your trace backend is a copy of your customer database with worse access controls.

**Sampling: agents break the usual rule.** Web services sample at 1–10% because requests are cheap and numerous. Agent requests are expensive and few, and the interesting ones are failures — hence **tail-based sampling**: buffer the trace, decide after it completes, keep everything that errored or exceeded a latency threshold. Atlas's exporter takes a finished batch precisely so this is a filter you insert rather than a rewrite.

**The traces-to-evals flywheel separates teams that improve from teams that ship.** The mechanism is mundane — thumbs-down plus trace id, cluster, turn clusters into tasks, gate on the suite. The discipline is not: a trace records *what happened*, never *what should have*, so a trace-derived task arrives redacted, marked `needs_review`, carrying `provenance.source = "trace"`, grading nothing until a human writes the expectation. The failure everyone commits once is growing the suite from *successful* traces, producing a suite measuring the cases you already pass.

**Streaming is table stakes for a psychological reason.** Teams measuring time-to-first-token separately from total latency optimise different things and ship better products.

**Approval fatigue is treated as a security control.** Sandboxing designs from major vendors name it explicitly as the motivating problem: a system asking constantly has trained its users to grant constantly, which is worse than one that asks rarely and means it. ASI09 as a design constraint rather than a risk-register entry.

### Interview questions

1. *Walk me through what happens to a `traceparent` from your gateway to a downstream service and back. What breaks if one hop drops it?*
2. *Your p95 doubled and nobody deployed. How do you find out why?*
3. *What goes on an LLM span, and what must never?*
4. *Your agent API takes a `thread_id`. What is the vulnerability and how do you test for it?*
5. *A user cancels a long-running research job. What does your API return, and what is actually true?*
6. *Liveness and readiness — what is the difference and what happens if you conflate them?*

## 11. [core] Capstone increment

*If your code diverged, start again from `atlas_phase_14.zip`.*

**Resume note.** *Instrumented a LangGraph agent end to end with OpenTelemetry-convention spans that cross an MCP process boundary into a single trace tree; shipped it as a containerised FastAPI service with SSE streaming, per-subject thread isolation, background jobs and a cost/latency endpoint. Found and fixed six defects in the instrumentation itself, five of which no test caught.*

**What Atlas can do now.** Answer a question over HTTP — **streaming real model deltas on the `chat` route**, or as a background job — for an authenticated subject who can reach only their own threads; produce one connected span tree per request spanning Atlas and the MCP server; export it as OTLP/JSON with an allowlist that keeps prompts, tool arguments and customer identifiers inside the process; report p50/p95/max latency, tokens and errors per operation; answer liveness and readiness separately; alert on a latency, error-rate, token or **egress** regression while staying silent on improvements and small samples; render all of it in a one-file web console at `/` that refuses to guess at an event kind it does not know; and run under one `docker compose up` beside a model server and a tracing backend.

### Files added

```
atlas/obs/__init__.py  spans.py  semconv.py  redact.py  export.py
                       metrics.py  instrument.py
atlas/obs/alerts.py
atlas/api/sse.py  threads.py  jobs.py  app.py  service.py  main.py
atlas/api/static/console.html
deploy/Dockerfile  docker-compose.yml  env.example
docs/RUNBOOK.md
scripts/phase15_results.py
evals/tasks/phase15.json
tests/test_obs_phase15.py  test_api_phase15.py  test_service_phase15.py
tests/hidden/test_phase15_a1.py  test_phase15_a2.py
```

### Files changed

`atlas/mcp/server.py` (a `tracer=None` keyword; `_run_local` opens a server span parented on `_meta`), `atlas/mcp/tools.py` (per-call traceparent), `atlas/config.py` (five optional keys), `evals/run.py` (the `:serve_scenario` dispatch), `Makefile` (`spans`, `serve`, `compose`; `PHASE ?= 15`), `requirements.txt` and `pyproject.toml` (fastapi core, uvicorn as the `serve` extra), `tests/test_evals_harness.py` (66 → 69).

### Interface changes

Seven, six additive and one behavioural, recorded in full in `ATLAS_INTERFACES.md`. The one that changes a wire: `make_remote_tools` now resolves the traceparent **per call** rather than minting one per build (F-15-03). No signature changed; the bytes on the wire did. Migration note: a caller passing `traceparent=` explicitly still wins, so Phase 12's tests are unaffected, and a caller with no tracer installed gets a fresh trace exactly as before.

The new package `atlas/obs/` is an addition to the stable repo layout. `atlas/trace.py` is untouched: it renders one trajectory for a reader who knows which run failed, and renaming a published module is forbidden by this contract.

### Tests added

120, taking the suite to **1,618 passed, 12 skipped**. The ones worth naming: two roots on one tracer are two traces (F-15-01); `stream` is instrumented (invariant 64); a thread id is not a bearer token; a missing thread and a stranger's thread are byte-identical responses; a handler that raises still terminates the stream; liveness stays green while readiness is red; every job status is reachable *by observation* (F-15-06); the server span's parent is the model span's id, by id; the wiring gate plus the gate's own gate; that the `chat` route emits one token event **per model delta** and a non-streaming route labels its tokens `replay`; that `STREAMING_ROUTES` names only routes making exactly one model call; that an `approval` event arrives **before** the token events and carries a non-empty consequence; that a turn with nothing pending emits none; that the console handles every member of `AGENT_EVENTS`; and that an alert fires on a regression, stays silent on an improvement, and never reaches `critical` at n=2.

### Eval tasks

Three, taking the suite to **69**, each graded from the environment rather than from a record the agent produced:

- `p15-a-thread-id-is-not-a-bearer-token` — five HTTP status codes, positive and negative halves in one task. Negative control run: with the ownership check removed, `stranger_read` and `stranger_append` both become 200 and the task fails 3 of 5 checks.
- `p15-one-request-is-one-trace-with-one-root` — trace ids, roots, orphans, kinds. Graded on tree *shape*, because a span-count check passes for three disconnected roots, which is what F-15-01 produced.
- `p15-no-prompt-text-survives-the-export-boundary` — the serialised OTLP body must contain the usage attributes and must not contain the question or the card number the question carried.

### `make results` and the expected ranges

`make spans`, `make results`, `make results ARGS='--only service'`. Every figure is Tier F arithmetic over scripted fixtures, so `--append-results` **refuses** the sweep (invariant 25) and the `docs/RESULTS.md` section is hand-written and headed TIER F — Phase 14's second-pass correction applied from the start.

| Quantity | Value | Printed by |
|---|---|---|
| distinct trace ids for one cross-service request | 1 | `make spans` |
| MCP server spans in that trace, with a parent | 1, True | `make spans` |
| attribute keys surviving the allowlist | 13 | `make results ARGS='--only otlp'` |
| `gen_ai.input.messages` in the exported body | False | `make results ARGS='--only otlp'` |
| unauthenticated / cross-tenant / owner statuses | 401 / 404 / 200 | `make results ARGS='--only service'` |
| SSE event sequence | `start, plan, token, done` | `make results ARGS='--only service'` |
| alert on a 4x p95 regression / on an improvement | fires / silent | `make alerts` |
| alert on 2 blocked egress URLs | critical | `make alerts` |
| offline suite | 1,618 passed, 12 skipped | `make test-offline` |
| eval tasks | 69, 3/3 trials | `make evals` |

**Unmeasured — author estimate.** Nothing ran on Tier A and nothing ran under Docker (`docker version` → command not found). Expected p95 for a single-turn `chat` route on the baseline laptop: **2–8 s**, dominated entirely by the model. Author estimate, unmeasured; run `make compose` and read your own `/metrics`.

### Read five failing traces — `docs/FAILURE_LOG.md`

Six entries: F-15-01 (one tracer pooled every request into one trace), F-15-02 (`duration_s` was a bare property and never reached the wire), F-15-03 (one traceparent per tool build, not per call), F-15-04 (the wiring gate found the phase's own composition root unwired), F-15-05 (`durability="sync"` with no checkpointer raises from inside the framework), F-15-06 (a reachability test that asserted its own answer).

**Five of the six are defects in the instrument** — the tracer, the serialisation, the wiring gate — and none is in the agent. That is `docs/ERROR_TAXONOMY.md` cluster B for the seventh consecutive phase, which makes it a prediction rather than an observation.

**Repo tag:** `phase-15`.

## 12. [core] Mastery checklist

You are ready to move on if you can:

- [ ] Draw a span tree for a request that crosses into another service, and say which field makes assembly possible.
- [ ] Explain why `parse_traceparent` returns `None` rather than raising, and why it rejects all-zero ids.
- [ ] State why an explicit parent beats an ambient span, and name the case where preferring ambient would produce a correct-looking, untested tree.
- [ ] Name three attributes that belong on a model span and three that must never, and justify the second list without saying "privacy".
- [ ] Explain the difference between a layer and a boundary using redaction and the allowlist.
- [ ] Show, in code, why a thread id is a bearer token unless something raises.
- [ ] Say what liveness must not check, and describe the outage that follows from checking it.
- [ ] Explain why open spans are counted separately from latency, and name the alert that depends on it.
- [ ] Say what is actually true when your API reports a job as cancelled.
- [ ] Diagnose §8's incident from the tree alone, and name the one fix that would make it worse.
- [ ] Name three anti-patterns in agent UX and the trust error each causes.
- [ ] State the two rules that make a trace-derived eval task safe to commit.
- [ ] Explain why streaming through a client wrapper beats a second handler, and state the bound that forces `STREAMING_ROUTES` to be a small set.
- [ ] Say why the egress alert has no threshold.
- [ ] Find a parameter, a `Literal` member or a Makefile flag in your own code that nothing reads — the method takes five minutes and needs no tooling.

## 13. [core] Quiz

1. A span records its parent's *id* rather than holding a reference. Give two consequences of that choice — one that makes distributed tracing possible, and one that makes a specific failure mode possible.
2. Your tracing backend shows a trace containing spans from three services but with two roots, one marked orphaned. Give two different explanations and say how you would distinguish them.
3. Atlas's redactor and Atlas's attribute allowlist both prevent customer data reaching the trace backend. Explain why only one of them is a security control, and what question separates them.
4. A colleague proposes returning `404` for a thread that does not exist and `403` for one belonging to another user, "because it's more honest". Give the argument against, and one situation where their instinct would be right.
5. `metrics_from_spans` counts open spans and excludes them from the latency statistics. Construct a concrete scenario in which including them at duration zero would make a dashboard report improving health during an outage.
6. `TeeingClient` makes the synchronous handler stream without changing it, but Atlas enables it for one route only. State the bound precisely, and explain why the limitation is reported on the wire (`source: "model" | "replay"`) rather than only in the documentation.
7. The egress alert uses `ratio=1.0, min_samples=1` while every latency rule uses a ratio above 1 and a floor of 10. Justify the asymmetry, then give one deployment in which you would add a threshold anyway and say what you would be conceding.
8. Your agent streams tokens and also retries a failed tool call twice before succeeding. Invariant 15 says retries are recorded, never hidden. What must the *stream* show, and what is the trust consequence of showing nothing?

## 14. [core] Coding assignments

### Assignment 1 — tail-based sampling **[fast track: do this one]**

Create `atlas/obs/sampling.py`. §10 says agent traces are expensive and few, and the interesting ones are the failures — so you buffer a trace, decide **after** it completes, and keep what matters.

**Acceptance criteria.** `SamplingPolicy` is a frozen Pydantic model with `slow_ms` and `probability`. `sampling_decision(spans, policy)` returns a `SamplingDecision` with `keep` and a `reason` drawn from a closed `KEEP_REASONS`, and a **drop states its reason too**. A trace that errored, exceeded `slow_ms`, or tripped the egress boundary is kept regardless of probability. The decision is **deterministic** for a given trace. Probability applies **per trace, never per span**. An empty span list is dropped rather than raising. `TailSampler.offer()` buffers and exports nothing; `TailSampler.flush()` decides and exports, reporting `kept` and `dropped`.

**UNAIDED CORE.** Determinism, and per-trace rather than per-span. A `random.random()` call makes the sampler unreasonable-about: re-running a batch produces a different corpus, and a trace re-evaluated flips. Sampling *spans* independently produces half a tree, which is worse than no trace at all because a reader believes it.

**Hidden tests:** `tests/hidden/test_phase15_a1.py`. Run `make grade`; do not read it. *(Validated: a naive submission using `random.random()` and omitting the egress check fails 2 of 11.)*

### Assignment 2 — production traces to eval tasks **[extended]**

Create `evals/from_traces.py`. Turn finished spans into **candidate** eval tasks.

**Acceptance criteria.**
- `tasks_from_spans(spans)` yields one `CandidateTask` per root agent span; an orphaned root yields nothing rather than raising.
- Each task records `route`, `stop_reason`, and `provenance` naming the source as a trace *and* carrying the trace id.
- The user's question is **redacted, not dropped** — the task must remain reproducible.
- `needs_review` is `True` and stays `True`; a task nobody has labelled does not grade.
- Traces that errored or ended in a harness-stopped reason are marked `interesting`; successful ones are not.
- Ids are stable across re-runs over the same trace and distinct across traces.
- `to_task_file(tasks, phase=...)` produces something the harness schema accepts.

**UNAIDED CORE.** The rule for `interesting`, and the decision that a trace-derived task ships with no checks. Both encode "a trace records what happened, never what should have", and that sentence is the assignment.

**Hidden tests.** `tests/hidden/test_phase15_a2.py`.

## 15. [extended] Case study — migrating a fintech support agent to production

**The situation.** A 40-person lender runs a support agent as a Streamlit prototype behind the VPN. It answers questions about a customer's loan using a read-only SQL tool over a replica, searches an internal policy corpus, and drafts (never sends) emails. Twelve agents use it; the head of support wants it available to 200 agents and, within a year, to customers.

Today: one process, one shared `thread_id` space, an API key in a `.env`, prompts edited in place, no tracing, no evals, `print()` for logs. It is right about 80% of the time by the team's informal count, and nobody can say which 20%.

**Your task.** A migration plan, four pages, sequenced, with what you would refuse to ship without.

**What a strong answer contains.** A sequencing argument that puts *evidence before capability*: tracing and an eval baseline first, because every later change is unmeasurable without them, and because the 80% figure is currently unfalsifiable. A tenancy design that treats the customer-facing phase as a different system from the agent-facing one, with the thread-ownership check present from day one rather than retrofitted. An explicit data-handling section: loan data is private data, the policy corpus is trusted, customer email is untrusted input and the draft-email tool is an external communication channel — which is the lethal trifecta, and the agent-facing and customer-facing configurations differ in which leg they remove. A deployment story with blue/green, versioned prompts *and* eval baseline *and* index manifest, and a rollback that is a traffic switch. And a refusal list with reasons.

**Rubric (30 points).**

| Criterion | Points | What earns full marks |
|---|---|---|
| Sequencing | 5 | Tracing and an eval baseline precede feature work, with the reason stated: the 80% claim is currently unfalsifiable and every later change is unmeasurable |
| Tenancy and authorization | 5 | Ownership check on threads and jobs from day one; per-tenant credential scope downstream; names broken object-level authorization and does not rely on unguessable ids |
| Data handling | 5 | Names the trifecta per configuration; states which leg is removed for the agent-facing and customer-facing versions; span allowlist keeps loan data out of the trace backend; separate retention for content |
| Observability | 4 | Spans across the SQL tool and the corpus search; per-operation latency; alert on open spans and on egress blocks; traces-to-evals flywheel with the `needs_review` rule |
| Deployment and rollback | 4 | Blue/green; versions prompts, graph, eval baseline and index manifest *together*; graceful shutdown longer than a turn; states that background jobs must survive a deploy |
| Failure and UX | 4 | Circuit breaker on the replica; approval design that resists fatigue; error messages with what/why/what-next; partial results labelled |
| Refusal list | 3 | At least two things named as blocking, with reasons — e.g. no customer-facing launch without a calibrated judge and a red-team pass on the email tool |

**Deductions.** −3 for any plan whose first milestone is a feature. −3 for "we'll add observability later". −5 for a customer-facing launch that keeps the draft-email tool on the same path as untrusted customer input with no additional control.

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 16.*

**A trace is a record of a particular event, and nothing you had produced one.** Tests are propositions about code; evals are estimates over a sample; a trace answers "what happened to *this* request, at *that* moment, for *that* person". `atlas/trace.py` renders a trajectory for a reader who already knows which run failed and stops dead at the process boundary — which is where, since Phase 12, three of Atlas's tools live.

**Assembly is by id, and everything follows from that.** A span names its parent with sixteen hex characters, so Atlas and the MCP server — sharing no object graph, no process and, in production, no machine — produce two independent lists that become one tree. Hence: an **explicit parent beats the ambient span**, because the server case is exactly the case where an ambient span exists and is wrong; an unresolvable parent becomes an **orphan root** rather than a dropped node, because a silently smaller tree is a plausible rendering of half a request; and **a value describing "now" is a function, never a variable captured in a closure** (F-15-03, three phases old and invisible until something assembled the spans).

**What leaves the process is an allowlist; what stays is everything.** The local span keeps whatever you put on it; the exported span carries only allowlisted names, scrubbed and truncated. A denylist over attribute *keys* is a promise to have thought of every key anyone will add, and the key somebody adds next quarter is `user_email`. The conventions agree by construction — content attributes exist and are opt-in *there* for the reason they are absent *here*. The scrubber beside the allowlist is a **layer**: ask Phase 14's question, and "write the number differently" is the answer. The allowlist is the **boundary**, because the key never made the list. And a redactor without a false-positive control is not neutral — a card pattern with no Luhn check deletes the order id that explains the failure, silently.

**A thread id is a bearer token unless something checks the subject, and the check must raise.** The checkpointer stores messages by id and refuses nobody, which is right for a checkpointer and catastrophic as an API. Ownership lives in a separate store, one function, raising — because `-> Record | None` is a design where one forgotten `if` authorises everything — and "no such thread" and "not yours" are byte-identical, because distinguishing them is an oracle for which ids are real. **Unguessability is not authorization.**

**Liveness and readiness answer different questions.** Liveness failing means restart me; readiness failing means stop sending traffic, I am still here. Wire a model check into liveness and a slow backend restarts every container you have — ASI08 in an ops costume, an outage you manufactured while watching for one.

**A mean latency describes no request that ever happened, and an open span contributes no duration at all.** p50, p95, max, with `n` beside them. Count open spans separately and exclude them, because including them at zero drags p50 down *exactly* when the process is hanging: the dashboard looks healthiest at the worst moment. "p95 is fine and forty spans never closed" must be a sentence the instrument can say.

**A stream terminates on every path, in a closed vocabulary.** An unhandled exception inside a generator produces a clean connection close and an eternal spinner. JSON-encoding every payload means no user's text can forge a frame boundary — an injection defence obtained by choosing an encoding rather than writing a filter. **Cancellation is cooperative**, and an interface implying otherwise is ASI10 with a green tick on it; Atlas says so in the response body, where the person who will be surprised reads it.

**The instrument is the phase.** Five of six failure-log entries are defects in the tracer, the serialisation or the wiring gate; none is in the agent — cluster B for the seventh consecutive phase. F-15-01: one tracer cached a generated trace id and pooled **every request the process ever served** into one trace, caught by reading a printed number beside its own label because no test held a tracer for two requests. F-15-02: five of six new models put derived values on bare `@property`, so a field the docstring described never reached the wire. F-15-04: the wiring gate, rewritten in Phase 14 to enumerate `__all__` from the code, found **the phase's own composition root** had no call site in `atlas/` — five names, none of which would have been on a list I typed.

**Streaming is a transport; it must not become a second policy.** A streaming handler beside the synchronous one duplicates routing, tools, egress and accounting, and invariant 60 says the two diverge. `TeeingClient` implements `complete()` **over** `stream()` instead, so the handler is untouched. The bound is real and lives on the wire rather than in prose: only the last model call produces the answer, so teeing is enabled only for routes making exactly one call — pinned by a test that counts them — and every token event declares `model` or `replay`.

**And the measurement.** One cross-service request → **1 trace id, 1 root, 0 orphans**, with the MCP server's span parented on the model span by id. 13 attribute keys survive the export allowlist and no content attribute does. **1,618 offline tests, 69 gradeable eval tasks, all passing**, `make check-docs` green, no network, no model, no Docker.

**Phase 16 next.** Atlas is now answerable and servable, and the thing to carry across is that it is answerable *about itself* and not yet about its own quality. Every control from Phase 14 now has a record something can read; not one of them yet has an alert that fires. **A record nothing queries is one refactor away from a record nothing writes.**

## 17. [core] Further reading

- **W3C Trace Context** — the `traceparent` and `tracestate` specification. The normative source for the format §6.1 parses. https://www.w3.org/TR/trace-context/ (W3C Recommendation)
- **OpenTelemetry — GenAI semantic conventions repository.** The conventions moved here in 2026; read the status header before relying on any name. https://github.com/open-telemetry/semantic-conventions-genai (checked 2026-09-14)
- **OpenTelemetry — "Inside the LLM Call: GenAI Observability with OpenTelemetry"** (14 May 2026). The project's own walkthrough, including why content capture is opt-in. https://opentelemetry.io/blog/2026/genai-observability/
- **OpenTelemetry — OTLP File Exporter specification.** The JSON encoding §7.2 implements, with a worked example. https://opentelemetry.io/docs/specs/otel/protocol/file-exporter/
- **Model Context Protocol — the 2026-07-28 specification and changelog** (28 July 2026). Stateless core, MRTR, extensions framework. https://blog.modelcontextprotocol.io/posts/2026-07-28/
- **MCP Tasks extension.** The protocol's answer to long-running tool calls (§6.6). https://tasks.extensions.modelcontextprotocol.io/
- **Jaeger v2 documentation.** v1 reached end of life on 2025-12-31; v2 is built on the OpenTelemetry Collector. https://www.jaegertracing.io/docs/2.20/architecture/
- **Kwon et al., "Efficient Memory Management for Large Language Model Serving with PagedAttention", SOSP 2023.** The KV-cache paging idea in §6.7. https://arxiv.org/abs/2309.06180
- **OWASP API Security Top 10 — Broken Object Level Authorization.** The defect §6.8 is about, in its general form. https://owasp.org/API-Security/editions/2023/en/0xa1-broken-object-level-authorization/
- **FastAPI documentation — Custom Response / StreamingResponse.** The mechanics behind §7.6. https://fastapi.tiangolo.com/advanced/custom-response/
- **MDN — Using server-sent events.** The client half: `EventSource`, reconnection, `Last-Event-ID`. https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events

## 18. [core] Solutions

Emitted separately as `phase_15_solutions.md`.

## 19. [core] Handoff

The updated `ATLAS_INTERFACES.md` (v0.30) and `VERSIONS.md` are inside `atlas_phase_15.zip`. See the chat message accompanying this document for the file list, the VERSIONS delta and the download links.
