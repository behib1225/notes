# Appendix F.7–F.8 — the files

Everything here was executed before it was written down. Verification runs are
at the bottom.

These are **overlays**, not standalone repos: copy `f7/` over a Phase 12
snapshot and `f8/` over a Phase 16 snapshot. Running a script directly out of
this directory fails with `ModuleNotFoundError: atlas.graph.state`, which is
correct — the overlay carries only the files the appendix adds or changes.

---

## f7/ — the browser tool and the second-framework port

Copy over `atlas_phase_12.zip`. The port half also runs unchanged on
`atlas_phase_11.zip` (verified): copy `atlas/port/` and
`tests/test_appendix_f7_port.py` only.

| file | what it is |
|---|---|
| `atlas/browser/policy.py` | the allowlist and budgets. Pure. The only security-relevant code in the package |
| `atlas/browser/page.py` | HTML → observation. Pure. Title, capped text, allowlisted links |
| `atlas/browser/driver.py` | `Driver` protocol, `ReplayDriver` (offline), `PlaywrightDriver` (not executed during authoring) |
| `atlas/browser/permissions.py` | Phase 14's four tiers, two phases early; delete after Phase 14 |
| `atlas/browser/tools.py` | `browse_url` (read-only) and `browser_act` (gated) |
| `atlas/browser/approval.py` | registers the consequence sentence and the irreversibility |
| `atlas/browser/__init__.py` | `build_browser_registry`, the one composition root |
| `atlas/port/agents_sdk/model.py` | `AtlasModel` — the adapter goes **under** the framework |
| `atlas/port/agents_sdk/tools.py` | D-48 across the port; Atlas still dispatches |
| `atlas/port/agents_sdk/research.py` | `research` reimplemented: plan → `gather` → aggregate |
| `scripts/gen_browser_fixtures.py` | the seeded replay corpus and the allowlist |
| `scripts/appendix_f7_results.py` | **student version** — experiments 1 and 2; `--injection` is the assignment |
| `tests/test_appendix_f7_browser.py` | 33 tests |
| `tests/test_appendix_f7_port.py` | 8 tests, including the equivalence oracle |
| `tests/hidden/test_appendix_f7_a1.py` | the assignment's hidden test — **do not read it** |
| `tests/fixtures/browser/**` | the replay corpus, committed so a fresh clone is green |
| `evals/tasks/appendix_f7.json` | 4 tasks |
| `evals/run_appendix.py` | one runner for every appendix task file |
| `atlas/graph/approval.py` | **core file changed** — mutable `IRREVERSIBLE`, `register_irreversible`, `IRREVERSIBLE_REASONS` |
| `Makefile` | **core file changed** — `evals-f7`, three lines |

## f8/ — the interview bank

Copy over `atlas_phase_16.zip`.

| file | what it is |
|---|---|
| `docs/interview_bank.json` | the bank as data: 30 questions, 3 prompts, phase index, exemptions with reasons |
| `docs/INTERVIEW_BANK.md` | the prose, carrying the generated headline. Parts 3 and 4 go here |
| `scripts/check_interview_bank.py` | the compiler: seven checks |
| `tests/test_appendix_f8_bank.py` | 8 tests, each planting one defect |
| `evals/tasks/appendix_f8.json` | 3 tasks |
| `evals/run_appendix.py` | same runner as f7 |
| `Makefile` | **core file changed** — `check-bank`, `evals-appendix` |

## solutions/

| file | what it is |
|---|---|
| `injection.py` | the assignment's UNAIDED CORE, `atlas/browser/injection.py` |
| `appendix_f7_results_solved.py` | the results script with `--injection` and `--selftest` |

Both are the reference solution. `tests/hidden/test_appendix_f7_a1.py` passes
against them, 9 passed.

---

## Verification (all run before this file was written)

```
Phase 12 tree + f7 overlay
  pytest tests --ignore=tests/hidden      1421 passed, 12 skipped   (base 1380)
  pytest tests/hidden/test_appendix_f7_a1.py (with solutions)   9 passed
  make evals-f7                           4 tasks x 3 trials, 4 PASS
  rm -rf tests/fixtures/browser && pytest tests/test_appendix_f7_browser.py
                                          33 passed  (the fixture self-heals)

Phase 11 tree + atlas/port/ only
  pytest tests/test_appendix_f7_port.py   8 passed
  pytest tests --ignore=tests/hidden      1318 passed, 12 skipped   (base 1310)

Phase 16 tree + f8 overlay
  make check-bank                         no findings
  pytest tests/test_appendix_f8_bank.py   8 passed
  make evals-appendix                     3 tasks x 3 trials, 3 PASS
```

No network, no model, no browser, no API key, no Docker. $0.00.

## Known limits, stated rather than hidden

* `PlaywrightDriver` was never executed — no browser in the authoring
  container. It carries the marker and its verification is the command in
  F.7.e Step 9.
* The four F.7 eval tasks grade refusals and the approval gate. **Nothing here
  measures browsing.** The build is demo-grade and labelled so.
* The three F.8 eval tasks are deterministic, so by this book's own division
  they are propositions wearing eval clothes. The reasoning for keeping them in
  the eval suite is in F.8.g; moving them to `tests/` loses nothing but a target.
* `docs/RESULTS.md` rows f7-4, f7-5 and f7-6 are empty and stay empty until
  someone runs `--injection` on Tier A.
