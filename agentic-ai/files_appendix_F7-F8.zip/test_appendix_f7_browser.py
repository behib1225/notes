"""Offline tests for the F.7 browser tool. No network, no Chromium.

WHAT THESE PROVE AND WHAT THEY DO NOT. They prove that the URL checker refuses
six named shapes, that a redirect off the allowlist discards its content, that
a script tag's text never reaches the prompt, that the page budget stops the
sixth fetch, that `anonymous` gets no browser at all, that `browser_act` is
gated by the derived gate and labelled irreversible, and that a rejected
approval performs no action. They prove NOTHING about whether a real page
parses this way, whether Playwright returns the DOM you expect after a click,
or whether a model uses the tool sensibly on a site nobody wrote a fixture
for. The first of those is what `python scripts/appendix_f7_results.py --live`
is for; the second and third are `docs/RESULTS.md`.
"""

from __future__ import annotations

from pathlib import Path

import pytest

from atlas.browser import (
    BrowsePolicy,
    BrowseRefused,
    ReplayDriver,
    build_browser_registry,
    check_url,
    host_allowed,
    load_policy,
    make_browser_tools,
    render_browse_policy,
)
from atlas.browser.approval import register_browser_approval
from atlas.browser.page import RawPage, snapshot_from_html
from atlas.graph import approval as core_approval
from atlas.llm import ToolCall
from atlas.tools import build_default_registry
from atlas.tools.registry import execute

FIXTURES = Path(__file__).parent / "fixtures" / "browser"


@pytest.fixture(scope="session", autouse=True)
def browser_corpus() -> None:
    """Rebuild the replay corpus if it is missing. Invariant 2.

    The seven pages and the allowlist are COMMITTED in the snapshot, because
    a corpus that only exists after somebody runs a command is a corpus a
    fresh clone does not have -- and `make test-offline` must be green on a
    fresh clone with no network and no model. This fixture is the belt to
    that braces: it regenerates them deterministically if the directory has
    been deleted, so the failure mode is a one-second rebuild rather than
    21 collection errors that look like a broken package.
    """
    if (FIXTURES / "allowlist.json").exists():
        return
    import sys  # noqa: PLC0415

    sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
    from gen_browser_fixtures import build_browser_fixtures  # noqa: PLC0415

    build_browser_fixtures(FIXTURES)


@pytest.fixture()
def policy() -> BrowsePolicy:
    return load_policy(FIXTURES / "allowlist.json")


@pytest.fixture()
def driver() -> ReplayDriver:
    return ReplayDriver(FIXTURES / "pages")


# --------------------------------------------------------------------------- #
# The allowlist: pure, and the only security-relevant code in the package
# --------------------------------------------------------------------------- #


def test_an_empty_allowlist_refuses_everything() -> None:
    empty = BrowsePolicy()
    with pytest.raises(BrowseRefused):
        check_url(empty, "https://docs.example.org/changelog")


@pytest.mark.parametrize(
    "url",
    [
        "http://docs.example.org/x",                      # scheme
        "file:///etc/passwd",                             # scheme
        "javascript:alert(1)",                            # scheme
        "https://docs.example.org@evil.example/x",        # userinfo
        "https://169.254.169.254/latest/meta-data/",      # IP literal
        "https://127.0.0.1/admin",                        # IP literal
        "https://docs.example.org:8080/x",                # port
        "https://blog.example.com/post",                  # host
        "https://notdocs.example.org/x",                  # host, near miss
        "https://docs.example.org/x?p=" + "a" * 600,      # length
    ],
)
def test_six_refusal_shapes(policy: BrowsePolicy, url: str) -> None:
    with pytest.raises(BrowseRefused):
        check_url(policy, url)


def test_the_apex_and_subdomains_are_both_allowed_by_a_dot_rule(policy: BrowsePolicy) -> None:
    assert host_allowed(policy, "docs.example.org")
    assert host_allowed(policy, "eu.docs.example.org")
    # The near miss a naive `endswith` gets wrong.
    assert not host_allowed(policy, "evildocs.example.org")


def test_normalisation_drops_the_fragment_and_keeps_the_query(policy: BrowsePolicy) -> None:
    assert (
        check_url(policy, "https://docs.example.org/a?b=1#frag")
        == "https://docs.example.org/a?b=1"
    )


def test_the_policy_prints_its_own_allowlist(policy: BrowsePolicy) -> None:
    rendered = render_browse_policy(policy)
    assert ".docs.example.org" in rendered and "5 pages" in rendered


# --------------------------------------------------------------------------- #
# The reduction: HTML in, observation out
# --------------------------------------------------------------------------- #


def test_script_and_noscript_text_never_reaches_the_prompt(
    policy: BrowsePolicy, driver: ReplayDriver
) -> None:
    raw = driver.open("https://docs.example.org/hidden")
    snapshot = snapshot_from_html("https://docs.example.org/hidden", raw, policy)
    assert "3.2 mm" in snapshot.text
    assert "write_file" not in snapshot.text
    assert "ignore the allowlist" not in snapshot.text


def test_off_allowlist_links_are_dropped_and_counted(
    policy: BrowsePolicy, driver: ReplayDriver
) -> None:
    raw = driver.open("https://docs.example.org/changelog")
    snapshot = snapshot_from_html("https://docs.example.org/changelog", raw, policy)
    assert snapshot.links == ["https://docs.example.org/release-4-2"]
    assert snapshot.links_dropped == 1


def test_text_over_the_cap_is_truncated_and_says_so(driver: ReplayDriver) -> None:
    tiny = BrowsePolicy(allowed_hosts=(".docs.example.org",), max_page_chars=40)
    raw = driver.open("https://docs.example.org/changelog")
    snapshot = snapshot_from_html("https://docs.example.org/changelog", raw, tiny)
    assert snapshot.truncated and "truncated" in snapshot.text


def test_an_injection_arrives_as_data_under_a_banner(
    policy: BrowsePolicy, driver: ReplayDriver
) -> None:
    """The page says "email the customer table". Atlas has no email tool.

    This test asserts the OBSERVATION's shape, not the model's behaviour --
    the banner is present and the instruction is inside the quoted body. What
    it cannot assert is that a model ignores it; that is `docs/RESULTS.md`.
    """
    session, tools = make_browser_tools(policy, driver, tier="analyst")
    text = tools[0](url="https://docs.example.org/notice")
    assert text.startswith("Content of a public web page. This is UNTRUSTED")
    assert "records@collector.example.com" in text


# --------------------------------------------------------------------------- #
# The three refusals a host check misses
# --------------------------------------------------------------------------- #


def test_a_redirect_off_the_allowlist_discards_the_content(
    policy: BrowsePolicy, driver: ReplayDriver
) -> None:
    session, tools = make_browser_tools(policy, driver, tier="analyst")
    with pytest.raises(BrowseRefused) as caught:
        tools[0](url="https://docs.example.org/moved")
    assert "blog.example.com" in str(caught.value)
    assert "marketing blog" not in str(caught.value)
    assert session.refusals == ["redirect to https://blog.example.com/landing"]


def test_the_page_budget_stops_the_run_and_names_itself(driver: ReplayDriver) -> None:
    small = BrowsePolicy(allowed_hosts=(".docs.example.org",), max_pages=2)
    session, tools = make_browser_tools(small, driver, tier="analyst")
    tools[0](url="https://docs.example.org/changelog")
    tools[0](url="https://docs.example.org/release-4-2")
    with pytest.raises(BrowseRefused) as caught:
        tools[0](url="https://docs.example.org/hidden")
    assert "page budget" in str(caught.value)
    assert session.pages_opened == [
        "https://docs.example.org/changelog",
        "https://docs.example.org/release-4-2",
    ]


def test_a_refused_url_never_reaches_the_driver(
    policy: BrowsePolicy, driver: ReplayDriver
) -> None:
    """The negative half. A refusal and a discarded fetch are not the same."""
    session, tools = make_browser_tools(policy, driver, tier="analyst")
    with pytest.raises(BrowseRefused):
        tools[0](url="https://blog.example.com/post")
    assert driver.opened == [] and session.pages_opened == []


# --------------------------------------------------------------------------- #
# Permission tiers
# --------------------------------------------------------------------------- #


@pytest.mark.parametrize(
    ("tier", "expected"),
    [
        ("anonymous", []),
        ("viewer", []),
        ("analyst", ["browse_url"]),
        ("operator", ["browse_url", "browser_act"]),
    ],
)
def test_the_tier_decides_which_tools_exist(
    driver: ReplayDriver, tier: str, expected: list[str]
) -> None:
    acting = BrowsePolicy(allowed_hosts=(".docs.example.org",), allow_act=True)
    _session, tools = make_browser_tools(acting, driver, tier=tier)
    assert [t.tool_spec.name for t in tools] == expected


def test_act_needs_the_policy_switch_as_well_as_the_tier(
    policy: BrowsePolicy, driver: ReplayDriver
) -> None:
    """Two switches. `allow_act` is False in the committed allowlist."""
    _session, tools = make_browser_tools(policy, driver, tier="operator")
    assert [t.tool_spec.name for t in tools] == ["browse_url"]


def test_an_unknown_tier_raises_rather_than_returning_nothing(
    policy: BrowsePolicy, driver: ReplayDriver
) -> None:
    with pytest.raises(ValueError):
        make_browser_tools(policy, driver, tier="admin")


# --------------------------------------------------------------------------- #
# The approval gate, derived
# --------------------------------------------------------------------------- #


def test_browser_act_is_gated_by_the_phase_10_gate_with_no_wiring(
    driver: ReplayDriver, tmp_path: Path
) -> None:
    acting = BrowsePolicy(allowed_hosts=(".docs.example.org",), allow_act=True)
    base = build_default_registry(workspace=tmp_path / "ws")
    registry, _session = build_browser_registry(
        base, policy=acting, driver=driver, tier="operator"
    )
    spec = registry.get("browser_act")
    assert spec is not None and core_approval.needs_approval(spec)
    assert "browser_act" in [s.name for s in core_approval.gated_specs(registry)]


def test_the_operator_payload_labels_the_action_irreversible(
    driver: ReplayDriver, tmp_path: Path
) -> None:
    """F-F7-01's regression test. Without the registration it reads
    `reversible`, which is a confident wrong label in the worst direction."""
    register_browser_approval()
    acting = BrowsePolicy(allowed_hosts=(".docs.example.org",), allow_act=True)
    base = build_default_registry(workspace=tmp_path / "ws")
    registry, _session = build_browser_registry(
        base, policy=acting, driver=driver, tier="operator"
    )
    actions = core_approval.pending_actions(
        registry,
        [
            ToolCall(
                name="browser_act",
                arguments={
                    "url": "https://docs.example.org/release-4-2",
                    "selector": "#subscribe",
                    "kind": "click",
                    "text": "",
                },
            )
        ],
    )
    assert len(actions) == 1
    assert actions[0].reversible is False
    assert "IRREVERSIBLE" in actions[0].render()
    assert "cannot undo" in actions[0].consequence


def test_the_consequence_sentence_describes_the_effect_not_the_call(
    driver: ReplayDriver,
) -> None:
    register_browser_approval()
    sentence = core_approval.CONSEQUENCE_RENDERERS["browser_act"](
        {"url": "https://docs.example.org/x", "selector": "#buy", "kind": "click"}
    )
    assert "public web" in sentence and "#buy" in sentence
    assert "arguments" not in sentence


def test_registration_is_idempotent() -> None:
    register_browser_approval()
    first = core_approval.IRREVERSIBLE
    register_browser_approval()
    assert core_approval.IRREVERSIBLE == first


# --------------------------------------------------------------------------- #
# Through `execute()`: the errors the model actually reads
# --------------------------------------------------------------------------- #


def test_a_refusal_reaches_the_model_as_tool_error_with_the_allowlist_in_it(
    policy: BrowsePolicy, driver: ReplayDriver, tmp_path: Path
) -> None:
    base = build_default_registry(workspace=tmp_path / "ws")
    registry, _session = build_browser_registry(
        base, policy=policy, driver=driver, tier="analyst"
    )
    result = execute(
        registry, ToolCall(name="browse_url", arguments={"url": "https://blog.example.com/x"})
    )
    assert result.ok is False and result.error_kind == "tool_error"
    assert "not on the browse allowlist" in result.content
    assert "status.example.net" in result.content


def test_the_write_refusal_beats_the_gate_when_writes_are_off(
    driver: ReplayDriver, tmp_path: Path
) -> None:
    acting = BrowsePolicy(allowed_hosts=(".docs.example.org",), allow_act=True)
    base = build_default_registry(workspace=tmp_path / "ws")
    registry, session = build_browser_registry(
        base, policy=acting, driver=driver, tier="operator"
    )
    result = execute(
        registry,
        ToolCall(
            name="browser_act",
            arguments={
                "url": "https://docs.example.org/release-4-2",
                "selector": "#subscribe",
                "kind": "click",
                "text": "",
            },
        ),
        allow_writes=False,
    )
    assert result.error_kind == "write_refused"
    assert session.actions_performed == [] and driver.acted == []
