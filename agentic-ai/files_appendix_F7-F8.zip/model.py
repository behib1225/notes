"""`AtlasModel`: Atlas's client, under the second framework's `Model` interface.

This is Phase 9's D-47 restated for a different framework, and it is the first
thing to port because everything else depends on it. THE ADAPTER GOES UNDER
THE FRAMEWORK, NEVER OVER. `AtlasChatModel` wraps `atlas.llm.LLMClient` so
that tier provenance, the `cached` flag, the budget/cache ordering and
`FakeLLMClient` all survive the migration; the same argument applies here,
and the consequence is the same: the port's tests run on Tier F with no
network, no key and no account.

The SDK's `Model` protocol has two methods. `get_response` is implemented.
`stream_response` raises, because Atlas's streaming decision is Phase 15's
(`TeeingClient` implements `complete()` OVER `stream()`, enabled only on
routes making exactly one model call) and a second, unmetered streaming path
opened by an appendix would be invariant 64's hole -- a wrapper that forwards
one method and not the other.

WHAT IS LOSSY, STATED RATHER THAN HIDDEN. The SDK's item vocabulary is the
Responses API's, and Atlas's is `Message`/`ToolCall`/`Completion`. Converting
between them loses the SDK's `response_id`/`request_id` (Atlas has no such
identifiers, so they are synthesised as empty) and loses Atlas's `tier`,
`cached` and `latency_s` on the way out (the SDK's `ModelResponse` has
nowhere to put them). The second loss is the one that matters and it is why
`AtlasModel` keeps its own `calls` list: a port that cannot say which tier
answered has given up invariant 25, and provenance is a property of what
happened.
"""

from __future__ import annotations

from typing import Any

from agents import Model, ModelResponse, Usage
from openai.types.responses import ResponseOutputMessage, ResponseOutputText

from atlas.llm import Completion, LLMClient, Message

__all__ = ["AtlasModel", "AtlasModelProvider", "messages_from_sdk_input"]


def messages_from_sdk_input(
    system_instructions: str | None, sdk_input: Any
) -> list[Message]:
    """Convert the SDK's input items into Atlas `Message`s. Pure.

    The SDK hands either a bare string (the first turn) or a list of item
    dicts (every later turn). Both are flattened into Atlas's three-role
    message list, because `atlas.llm` is the seam every model call passes
    through and a second message format inside it would be a second seam.
    """
    messages: list[Message] = []
    if system_instructions:
        messages.append(Message(role="system", content=system_instructions))
    if isinstance(sdk_input, str):
        messages.append(Message(role="user", content=sdk_input))
        return messages
    for item in sdk_input or []:
        raw = item if isinstance(item, dict) else getattr(item, "model_dump", lambda: {})()
        role = raw.get("role")
        content = raw.get("content")
        if isinstance(content, list):
            content = " ".join(
                part.get("text", "")
                for part in content
                if isinstance(part, dict) and part.get("text")
            )
        if role in ("system", "user", "assistant") and content:
            messages.append(Message(role=role, content=str(content)))
        elif raw.get("type") == "function_call_output":
            # A tool result. Atlas's own dialects disagree about how one comes
            # back (Phase 3), and the `user` role is the lowest common
            # denominator that every chat template renders -- which is Phase
            # 2's rule that the usable roles are the roles the template
            # renders, applied to a third dialect.
            messages.append(
                Message(role="user", content=f"TOOL RESULT: {raw.get('output', '')}")
            )
    return messages


def _text_item(text: str) -> ResponseOutputMessage:
    """One assistant message in the SDK's output vocabulary."""
    return ResponseOutputMessage(
        id="atlas-0",
        content=[ResponseOutputText(text=text, type="output_text", annotations=[])],
        role="assistant",
        status="completed",
        type="message",
    )


class AtlasModel(Model):
    """One Atlas client, wearing the SDK's `Model` interface.

    `calls` is a list of the `Completion`s Atlas produced, kept because the
    SDK's `ModelResponse` has nowhere to carry `tier` or `cached`. A test
    asserts against it, and so does the equivalence check: two engines that
    agree on the answer and disagree on the call count have not been shown
    equivalent (invariant 60 -- during a migration an improvement is
    indistinguishable from a bug).
    """

    def __init__(self, client: LLMClient, *, seed: int | None = 7,
                 max_tokens: int | None = None, temperature: float = 0.0) -> None:
        self.client = client
        self.seed = seed
        self.max_tokens = max_tokens
        self.temperature = temperature
        self.calls: list[Completion] = []

    async def get_response(  # noqa: PLR0913 - the protocol's shape, not a choice
        self,
        system_instructions: str | None,
        input: Any,
        model_settings: Any,
        tools: list[Any],
        output_schema: Any,
        handoffs: list[Any],
        tracing: Any,
        *,
        previous_response_id: str | None = None,
        conversation_id: str | None = None,
        prompt: Any = None,
        **_extra: Any,
    ) -> ModelResponse:
        """One model call, through `atlas.llm` and nothing else.

        `**_extra` is not laziness: this protocol has gained keyword arguments
        between minor versions, and an adapter that pins the exact signature
        breaks on an upgrade in a way that reads as a framework bug. The
        arguments Atlas cannot honour are ignored DELIBERATELY and the ones
        that would change behaviour silently -- `output_schema`, `handoffs` --
        are refused below rather than dropped.
        """
        if output_schema is not None:
            raise NotImplementedError(
                "structured output goes through atlas.llm.structured(), which "
                "owns the repair ladder and records the rung used (D-05). A "
                "second schema path here would be a second implementation of "
                "one policy."
            )
        if handoffs:
            raise NotImplementedError(
                "handoffs move control flow into the model's output. Atlas's "
                "D-21 keeps that in code; see F.7's analysis."
            )
        messages = messages_from_sdk_input(system_instructions, input)
        completion = self.client.complete(
            messages,
            seed=self.seed,
            temperature=self.temperature,
            max_tokens=self.max_tokens,
        )
        self.calls.append(completion)
        return ModelResponse(
            output=[_text_item(completion.text or "")],
            usage=Usage(
                requests=1,
                input_tokens=completion.usage.prompt_tokens,
                output_tokens=completion.usage.completion_tokens,
                total_tokens=completion.usage.prompt_tokens
                + completion.usage.completion_tokens,
            ),
            response_id=None,
        )

    def stream_response(self, *args: Any, **kwargs: Any) -> Any:
        raise NotImplementedError(
            "streaming is Phase 15's TeeingClient, which implements complete() "
            "OVER stream() so there is one policy path. A second streaming "
            "path here would be an unmetered side channel (invariant 64)."
        )


class AtlasModelProvider:
    """`ModelProvider`: one model for every agent in the run.

    The SDK offers three places to attach a model -- a global client, a
    provider on the run, an instance on the agent. The provider is the right
    one for Atlas because it is per RUN, which is the same lifetime as a
    `RequestAccount` and a registry: invariant 16 says anything holding a
    counter, budget or cache is constructed once per run and passed in.
    """

    def __init__(self, model: AtlasModel) -> None:
        self.model = model

    def get_model(self, model_name: str | None) -> Model:
        return self.model
