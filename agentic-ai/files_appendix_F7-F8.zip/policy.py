"""What the browser is allowed to reach. Pure, and refusing by default.

Everything security-relevant about the browser tool is in this file, and
none of it touches the network. That is deliberate and it is the same shape
as `atlas/tools/files.py`: the boundary is one pure function that a test can
hammer, not a condition sprinkled through the driver.

THE DEFAULT IS AN EMPTY ALLOWLIST, WHICH REFUSES EVERYTHING. A denylist would
require enumerating the hosts an attacker might use, and there is no end to
that list. An empty allowlist is the only default that is safe when somebody
forgets to configure it -- the inverse of invariant 58, where the capability
you forget to switch on should be the restrictive one.

Six refusals, and each closes a route a page can take that a host check alone
does not:

    scheme     only `https`. A plaintext page can be rewritten in transit,
               and `file://`, `data:` and `javascript:` are not navigation.
    userinfo   `https://user:pass@allowed.example/` -- the part before the
               `@` is not the host, and a reader (or a naive host check
               written against the string) will read it as one.
    literal    an IP address instead of a name. `169.254.169.254` is the
               cloud metadata endpoint and `127.0.0.1` is whatever else is
               listening on this machine; neither can be allowlisted by name,
               so both are refused by shape.
    port       only the default. A hostname you trust on 443 is not a
               hostname you have agreed to reach on 8080.
    host       the allowlist proper, exact or by a declared `.suffix`.
    length     a URL longer than the cap, because a 4 kB URL to an allowed
               host is a data channel, not an address.

The one it does NOT close, stated plainly: DNS rebinding. The name resolves
inside the allowlist when Atlas checks it and somewhere else when the browser
connects. Closing that needs the connection pinned to an address the checker
resolved, which is a network-layer control and not a string function. Phase
14's egress boundary is where that belongs; this is a jail against mistakes
and casual misuse, as `resolve_in_jail` is for the filesystem.
"""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Sequence
from urllib.parse import urlsplit, urlunsplit

from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "BrowsePolicy",
    "BrowseRefused",
    "check_url",
    "host_allowed",
    "load_policy",
]

MAX_URL_CHARS = 512

# An IPv4 literal, or anything bracketed (IPv6). Matching by SHAPE rather than
# trying to resolve: a checker that resolves is a checker that makes a network
# call in a pure function, and one whose answer can differ from the browser's.
_IPV4 = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


class BrowseRefused(ValueError):
    """A URL, action or budget the policy does not permit.

    A `ValueError`, so `execute()` turns it into `tool_error` with the message
    intact -- which is the behaviour we want, because the message is written
    for the model to act on (invariant 19) and says which host WAS allowed.
    """


class BrowsePolicy(BaseModel):
    """The whole configuration of the browser tool. Frozen, and a value.

    A value rather than a module constant for invariant 10's reason one level
    out: the action space is assembled by the caller, and "which hosts" is as
    much a part of the action space as "which tools". A test passes three
    hosts; the demo passes the committed list; a deployment passes its own.
    """

    model_config = ConfigDict(extra="forbid", frozen=True)

    allowed_hosts: tuple[str, ...] = ()
    """Exact hostnames, or entries starting with `.` meaning "and subdomains".

    `docs.example.org` allows exactly that host. `.example.org` allows
    `example.org` and anything under it. Written as two forms rather than
    inferred from a wildcard, because `*.example.org` reads as if it excludes
    the apex and in most implementations does not.
    """

    max_page_chars: int = 3_000
    """The cap on extracted text. Phase 1's arrow: an observation costs tokens
    permanently, and a browser returns the largest observations in Atlas."""

    max_links: int = 15
    max_pages: int = 5
    """Navigation budget for ONE episode. A browsing agent with no page budget
    is a crawler, and a crawler is a cost centre with a step cap it ignores."""

    timeout_s: float = 10.0
    allow_act: bool = False
    """Whether `browser_act` is built at all. Off by default: reading a page
    and changing somebody's state are different capabilities, and an absent
    tool is stronger than a gated one (invariant 20)."""

    label: str = Field(default="unnamed", description="Printed by the policy report.")


def host_allowed(policy: BrowsePolicy, host: str) -> bool:
    """Is this hostname on the allowlist? Pure, case-insensitive."""
    name = host.lower().rstrip(".")
    for entry in policy.allowed_hosts:
        rule = entry.lower()
        if rule.startswith("."):
            apex = rule[1:]
            if name == apex or name.endswith(rule):
                return True
        elif name == rule:
            return True
    return False


def check_url(policy: BrowsePolicy, url: str) -> str:
    """Return the normalised URL, or raise `BrowseRefused`. Pure.

    Normalisation drops the fragment, because a fragment never reaches the
    server and keeping it means two spellings of one page produce two cache
    keys and two audit rows.
    """
    if not url or not url.strip():
        raise BrowseRefused("url is empty")
    url = url.strip()
    if len(url) > MAX_URL_CHARS:
        raise BrowseRefused(
            f"url is {len(url)} characters, over the {MAX_URL_CHARS} limit. A URL "
            "that long is carrying data rather than addressing a page."
        )
    try:
        parts = urlsplit(url)
    except ValueError as exc:  # malformed IPv6 brackets, mostly
        raise BrowseRefused(f"{url!r} is not a URL: {exc}") from exc
    if parts.scheme.lower() != "https":
        raise BrowseRefused(
            f"scheme {parts.scheme or '(none)'!r} is refused; only https is "
            "browsable. Give a full https:// URL."
        )
    if "@" in parts.netloc:
        raise BrowseRefused(
            "credentials in the URL are refused: the text before '@' is not the "
            "host, and reading it as one is how an allowlist is bypassed."
        )
    host = (parts.hostname or "").lower()
    if not host:
        raise BrowseRefused(f"{url!r} has no host")
    if _IPV4.match(host) or ":" in host:
        raise BrowseRefused(
            "IP addresses are refused; name a host on the allowlist. An address "
            "cannot be allowlisted by name, and the useful ones point inside "
            "the machine or at a metadata service."
        )
    try:
        port = parts.port
    except ValueError as exc:
        raise BrowseRefused(f"{url!r} has an unreadable port") from exc
    if port is not None and port != 443:
        raise BrowseRefused(
            f"port {port} is refused; only the default https port is browsable."
        )
    if not host_allowed(policy, host):
        raise BrowseRefused(
            f"{host} is not on the browse allowlist. Allowed: "
            f"{', '.join(policy.allowed_hosts) or '(nothing — the allowlist is empty)'}. "
            "Answer from the documents or the database instead."
        )
    return urlunsplit((parts.scheme.lower(), parts.netloc.lower(), parts.path or "/",
                       parts.query, ""))


def load_policy(path: Path | str, *, label: str | None = None) -> BrowsePolicy:
    """Read a committed allowlist file. Raises a message a student can act on.

    A file rather than an environment variable, for invariant 4: `atlas/config.py`
    is the only module in Atlas that reads the environment, and an appendix does
    not get to be the second one. A path is a parameter; a parameter is a value
    the caller owns.
    """
    target = Path(path)
    if not target.exists():
        raise FileNotFoundError(
            f"no browse allowlist at {target}. Run "
            "`python scripts/gen_browser_fixtures.py` to build it."
        )
    payload = json.loads(target.read_text(encoding="utf-8"))
    hosts: Sequence[str] = payload.get("allowed_hosts", ())
    return BrowsePolicy(
        allowed_hosts=tuple(hosts),
        max_page_chars=int(payload.get("max_page_chars", 3_000)),
        max_links=int(payload.get("max_links", 15)),
        max_pages=int(payload.get("max_pages", 5)),
        allow_act=bool(payload.get("allow_act", False)),
        label=label or str(payload.get("label", target.name)),
    )


def render_browse_policy(policy: BrowsePolicy) -> str:
    """The allowlist and the budgets, printed. `make policy`'s sibling.

    A policy a reader cannot print is a policy nobody audits -- §6.4 rule 3
    applied to hosts instead of to tools.
    """
    lines = [f"browse policy: {policy.label}"]
    if not policy.allowed_hosts:
        lines.append("  (empty allowlist — every URL is refused)")
    for entry in policy.allowed_hosts:
        kind = "host+subdomains" if entry.startswith(".") else "host"
        lines.append(f"  ALLOW  {entry:28s} ({kind})")
    lines.append(f"  budget {policy.max_pages} pages, {policy.max_page_chars} chars/page, "
                 f"{policy.max_links} links/page, {policy.timeout_s}s timeout")
    lines.append(f"  act    {'ENABLED (gated)' if policy.allow_act else 'absent'}")
    return "\n".join(lines)
