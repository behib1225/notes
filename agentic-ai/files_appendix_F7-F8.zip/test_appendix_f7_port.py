"""Offline tests for the F.7 second-framework port. No network, no key.

WHAT THESE PROVE. That Atlas's client runs under the SDK's `Model` interface
on Tier F; that the ported flow returns a byte-identical `outcome` to the
LangGraph one over the same fixtures (the equivalence oracle, with an
absolute assertion beside it because a comparison passes if both engines are
wrong); that a failing branch is recorded rather than cancelling its
siblings; that an empty plan still produces a record; and that a tool call
made by the SDK is dispatched by Atlas's `execute()`, so `allow_writes`,
argument validation and the output cap all still apply.

WHAT THEY DO NOT PROVE. Anything about either framework's behaviour with a
real model, which is the whole point of `docs/RESULTS.md`; and nothing at all
about the port's latency, since a fixture returns instantly.
"""

from __future__ import annotations

import asyncio
import json
from pathlib import Path

import pytest

from atlas.graph.subgraphs import build_research_subgraph
from atlas.llm import FakeLLMClient
from atlas.port.agents_sdk import AtlasModel, run_research_port, sdk_tools_for
from atlas.port.agents_sdk.model import messages_from_sdk_input
from atlas.tools import build_default_registry

FIXTURES = ["Rating is 16 A.", "Clearance is 3.2 mm.", "Tested at 40 C."]
STEPS = ["contact rating", "insulation clearance", "test temperature"]


@pytest.fixture()
def registry(tmp_path: Path):
    return build_default_registry(workspace=tmp_path / "ws")


def _langgraph_outcome(steps: list[str], fixtures: list[str], registry) -> dict:
    """The default path's answer, over one model call per branch."""
    client = FakeLLMClient(list(fixtures))
    graph = build_research_subgraph(
        client,
        registry=registry,
        planner=lambda _request: steps,
        worker=lambda step: client.complete(
            [__import__("atlas.llm", fromlist=["Message"]).Message(role="user", content=step)]
        ).text,
        worker_limit=1,
    )
    state = graph.invoke({"request": "check the relay"}, {"max_concurrency": 1})
    return state["outcome"]


def _port_outcome(steps: list[str], fixtures: list[str], registry) -> dict:
    client = FakeLLMClient(list(fixtures))
    return run_research_port(
        client,
        "check the relay",
        registry=registry,
        planner=lambda _request: steps,
        # ONE at a time, for invariant 38's reason: a fan-out over an ordered
        # fixture list serialises, because a test whose outcome depends on
        # scheduling is not a test (F-05-05).
        worker_limit=1,
        max_turns=2,
    )


def test_the_two_engines_agree_field_for_field(registry) -> None:
    """Phase 9's oracle. Zero diverged fields, plus an absolute assertion."""
    left = _langgraph_outcome(STEPS, FIXTURES, registry)
    right = _port_outcome(STEPS, FIXTURES, registry)
    diverged = [k for k in set(left) | set(right) if left.get(k) != right.get(k)]
    assert diverged == []
    # The absolute half: a comparison passes if BOTH engines are wrong.
    assert right["stop_reason"] == "final" and right["partial"] is False
    assert right["answer"] is not None and "16 A" in right["answer"]
    assert right["n_tool_calls"] == 3


def test_an_empty_plan_still_produces_a_record(registry) -> None:
    outcome = _port_outcome([], [], registry)
    assert outcome["partial"] is True
    assert outcome["stop_reason"] == "step_cap"
    assert outcome["note"] == "0 branch(es), 0 failed"


def test_a_failing_branch_is_recorded_and_its_siblings_survive(registry) -> None:
    """One fixture for three branches: branches 2 and 3 exhaust the queue."""
    outcome = _port_outcome(STEPS, FIXTURES[:1], registry)
    assert outcome["partial"] is True
    assert outcome["note"] == "3 branch(es), 2 failed"
    # The survivor's answer is still there. `gather` with an unguarded
    # exception would have lost it, which is F-05-02 in a second framework.
    assert "16 A" in (outcome["answer"] or "")


def test_the_model_adapter_records_the_calls_atlas_made(registry) -> None:
    client = FakeLLMClient(["one"])
    model = AtlasModel(client)
    response = asyncio.run(
        model.get_response("sys", "hello", None, [], None, [], None,
                           previous_response_id=None, conversation_id=None, prompt=None)
    )
    assert len(model.calls) == 1
    assert model.calls[0].tier == "F"          # provenance survived the port
    assert response.usage.requests == 1


def test_the_adapter_refuses_what_atlas_owns(registry) -> None:
    model = AtlasModel(FakeLLMClient(["one"]))
    with pytest.raises(NotImplementedError):
        asyncio.run(model.get_response("s", "h", None, [], object(), [], None,
                                       previous_response_id=None,
                                       conversation_id=None, prompt=None))
    with pytest.raises(NotImplementedError):
        asyncio.run(model.get_response("s", "h", None, [], None, [object()], None,
                                       previous_response_id=None,
                                       conversation_id=None, prompt=None))
    with pytest.raises(NotImplementedError):
        model.stream_response()


def test_input_conversion_folds_tool_results_into_messages() -> None:
    messages = messages_from_sdk_input(
        "be brief",
        [
            {"role": "user", "content": "rating?"},
            {"type": "function_call_output", "output": "16 A"},
        ],
    )
    assert [m.role for m in messages] == ["system", "user", "user"]
    assert "TOOL RESULT: 16 A" in messages[-1].content


def test_a_tool_call_from_the_sdk_goes_through_atlas_execute(registry) -> None:
    """D-48 across the port: the SDK describes, `execute()` dispatches."""
    tools = {t.name: t for t in sdk_tools_for(registry, allow_writes=False)}
    assert "calculate" in tools and "write_file" in tools
    assert tools["calculate"].description  # generated, not hand-written

    ok = asyncio.run(tools["calculate"].on_invoke_tool(None, json.dumps({"expression": "2+2"})))
    assert ok.strip() == "4.00"

    refused = asyncio.run(
        tools["write_file"].on_invoke_tool(None, json.dumps({"path": "a.md", "content": "x"}))
    )
    assert refused.startswith("ERROR (write_refused)")

    bad = asyncio.run(tools["calculate"].on_invoke_tool(None, json.dumps({"nope": 1})))
    assert bad.startswith("ERROR (bad_arguments)")

    malformed = asyncio.run(tools["calculate"].on_invoke_tool(None, "{not json"))
    assert malformed.startswith("ERROR (bad_arguments)")


def test_the_sdk_tool_order_matches_the_registry(registry) -> None:
    assert [t.name for t in sdk_tools_for(registry)] == registry.names
