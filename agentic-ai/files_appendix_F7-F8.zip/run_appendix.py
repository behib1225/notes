"""The appendix eval runner: F.7's browser tasks and F.8's bank tasks.

Additive -- the core harness is imported, never edited.

`evals/run.py` dispatches on the entrypoint with a chain of `if`s, and the
appendix needs registries and documents it does not build. Rather than edit a
core file -- which every appendix section is forbidden to do, and which would
also make two appendix sections collide inside one function -- this runner
imports the core harness's `Task`, `run_checks` and `summarise` and supplies
its own dispatch.

ONE runner for every appendix section rather than one per section: two
near-identical runners are F-08-02's two-implementations defect waiting for a
divergence, and the grading itself comes from the core harness so the checks
behave identically -- `ci`, `ref`, `len_eq`, partial credit and all.

The core harness globs `phase*.json`, so appendix task files are invisible to
`make evals` and cannot break it.

    make evals-f7
    make evals-appendix FILE=evals/tasks/appendix_f8.json
"""

from __future__ import annotations

import argparse
import json
import shutil
import sys
import tempfile
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))

from evals.run import (  # noqa: E402
    Task,
    TrialResult,
    load_tasks,
    make_client_factory,
    run_checks,
    summarise,
)

from atlas.config import Settings  # noqa: E402

SOURCE = Path(__file__).resolve().parents[1]
BROWSER_FIXTURES = SOURCE / "tests" / "fixtures" / "browser"


# --------------------------------------------------------------------------- #
# F.7 -- the browser tasks
# --------------------------------------------------------------------------- #


def _browser_environment(root: Path, setup: dict[str, Any]) -> dict[str, Any]:
    """A fresh workspace, a replay driver and a registry with the browser in it."""
    from atlas.browser import BrowsePolicy, ReplayDriver, build_browser_registry
    from atlas.browser.policy import load_policy
    from atlas.tools import build_default_registry

    policy = load_policy(BROWSER_FIXTURES / "allowlist.json")
    overrides = setup.get("policy") or {}
    if overrides:
        policy = BrowsePolicy(**{**policy.model_dump(), **overrides})
    driver = ReplayDriver(BROWSER_FIXTURES / "pages")
    base = build_default_registry(workspace=root / "workspace")
    registry, session = build_browser_registry(
        base, policy=policy, driver=driver, tier=setup.get("tier", "analyst")
    )
    return {"registry": registry, "session": session, "driver": driver}


def dispatch_f7(task: Task, *, client: Any, seed: int, root: Path) -> dict[str, Any]:
    """Two shapes: a direct tool call, and a gated run through the core graph."""
    from atlas.llm import ToolCall
    from atlas.tools.registry import execute

    setup = task.setup
    env = _browser_environment(root, setup)
    session, driver = env["session"], env["driver"]

    if setup["entrypoint"].endswith("make_browser_tools"):
        result = execute(
            env["registry"],
            ToolCall(name=setup["tool"], arguments=dict(setup.get("arguments", {}))),
            allow_writes=setup.get("allow_writes", False),
        )
        # A repeat call, for the budget task: the same session, so the counter
        # carries. Expressed as a list of argument dicts rather than a loop
        # count, because a task that repeats one call and a task that walks
        # three pages are different tasks.
        for extra in setup.get("then", []):
            result = execute(
                env["registry"],
                ToolCall(name=setup["tool"], arguments=dict(extra)),
                allow_writes=setup.get("allow_writes", False),
            )
        return {
            "result": result.model_dump(),
            "environment": {
                "pages_opened": session.pages_opened,
                "driver_opened": driver.opened,
                "actions_performed": session.actions_performed,
                "refusals": session.refusals,
            },
        }

    # The gated shape. Modelled on the core harness's `build_core_graph`
    # branch, because a task that grades the gate must drive it the way the
    # gate is actually driven: invoke, expect a suspension, resume with a
    # decision, and grade the NEGATIVE half -- that nothing happened.
    from langchain_core.messages import HumanMessage, SystemMessage
    from langgraph.checkpoint.memory import InMemorySaver
    from langgraph.types import Command

    from atlas.agents.react import build_system_prompt
    from atlas.graph.core import (
        build_core_graph,
        gated_recursion_limit_for,
        reset_core_run_channels,
    )

    registry = env["registry"]
    max_steps = setup.get("max_steps", 3)
    app = build_core_graph(
        client,
        registry=registry,
        max_steps=max_steps,
        allow_writes=True,
        seed=seed,
        checkpointer=InMemorySaver(),
    )
    config = {
        "configurable": {"thread_id": task.id},
        "recursion_limit": gated_recursion_limit_for(max_steps),
    }
    opening = [
        SystemMessage(content=build_system_prompt(registry, "native")),
        HumanMessage(content=setup["prompt"]),
    ]
    state = app.invoke(
        {"messages": opening, "approvals": [], **reset_core_run_channels()}, config
    )
    interrupted = bool(state.get("__interrupt__"))
    if interrupted and setup.get("resume") is not None:
        state = app.invoke(Command(resume=setup["resume"]), config)
    return {
        "interrupted": interrupted,
        "approvals": state.get("approvals") or [],
        "environment": {
            "pages_opened": session.pages_opened,
            "actions_performed": session.actions_performed,
            "driver_acted": [list(a) for a in driver.acted],
        },
    }


# --------------------------------------------------------------------------- #
# F.8 -- the interview-bank tasks
# --------------------------------------------------------------------------- #


def _mutate_bank(tree: Path, mutation: str) -> None:
    """Plant exactly one defect. NAMED mutations, never a free-form patch.

    A task that plants a defect by arbitrary edit is a task whose failure you
    cannot attribute, and the mutation name is what the task file grades
    against.
    """
    path = tree / "docs" / "interview_bank.json"
    bank = json.loads(path.read_text(encoding="utf-8"))
    if mutation == "none":
        return
    if mutation == "drop_one_question":
        bank["questions"] = bank["questions"][:-1]
    elif mutation == "dangling_phase":
        bank["questions"][0]["phases"] = [99]
    else:
        raise ValueError(f"unknown mutation {mutation!r}")
    path.write_text(json.dumps(bank), encoding="utf-8")


def dispatch_f8(task: Task, *, root: Path) -> dict[str, Any]:
    from check_interview_bank import check_bank

    _mutate_bank(root, task.setup.get("mutation", "none"))
    bank = json.loads((root / "docs" / "interview_bank.json").read_text())
    findings = check_bank(root, verbose=False)
    covered = {p for e in bank["questions"] + bank["prompts"] for p in e["phases"]}
    return {
        "result": {
            "findings": findings,
            "joined": " | ".join(findings),
            "exit_code": 1 if findings else 0,
            "n_questions": bank["meta"]["n_questions"],
            "n_prompts": bank["meta"]["n_prompts"],
            "phases_covered": len(covered),
        }
    }


# --------------------------------------------------------------------------- #
# The loop
# --------------------------------------------------------------------------- #


def _is_bank_task(task: Task) -> bool:
    return task.setup.get("entrypoint", "").endswith("check_bank")


def run_trial(task: Task, *, trial: int, seed: int = 7) -> TrialResult:
    """One attempt in a clean temporary tree. Isolation per trial.

    Shared state between trials produces correlated failures that look like
    behaviour and can silently inflate a score, so each trial gets its own
    workspace -- and, for a bank task, its own copy of the documents to
    mutate.
    """
    with tempfile.TemporaryDirectory(prefix="atlas-appendix-") as temporary:
        root = Path(temporary)
        try:
            if _is_bank_task(task):
                shutil.copytree(SOURCE / "docs", root / "docs")
                for document in SOURCE.glob("phase_*.md"):
                    shutil.copy(document, root / document.name)
                payload = dispatch_f8(task, root=root)
            else:
                client = make_client_factory(Settings(tier="F"))(task)
                payload = dispatch_f7(task, client=client, seed=seed, root=root)
        except Exception as exc:  # noqa: BLE001 - a crash is a failed trial, recorded
            return TrialResult(
                task_id=task.id, trial=trial, passed=False,
                error=f"{type(exc).__name__}: {exc}",
            )
    checks = run_checks(payload, task.checks)
    return TrialResult(
        task_id=task.id,
        trial=trial,
        passed=all(c.passed for c in checks),
        checks=checks,
        score=sum(c.passed for c in checks) / max(1, len(checks)),
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--file", default="evals/tasks/appendix_f7.json")
    parser.add_argument("--trials", type=int, default=3)
    parser.add_argument("--seed", type=int, default=7)
    args = parser.parse_args(argv)

    tasks = load_tasks([Path(args.file)])
    results = [
        run_trial(task, trial=n, seed=args.seed)
        for task in tasks
        for n in range(args.trials)
    ]
    print(f"appendix suite — {Path(args.file).name}, {len(tasks)} tasks x "
          f"{args.trials} trials, tier F, seed {args.seed}")
    for row in summarise(results, tasks):
        mark = "PASS" if row.pass_hat_k else ("FAIL" if not row.pass_at_k else "FLAKY")
        print(f"  {mark:5s} {row.task_id:58s} {row.successes}/{row.trials}")
    for result in results:
        for check in result.checks:
            if not check.passed:
                print(f"    {result.task_id}: {check.field} {check.op} "
                      f"expected={check.expected!r} actual={check.actual!r} "
                      f"{check.note}")
        if result.error:
            print(f"    {result.task_id}: {result.error}")
    return 0 if all(r.passed for r in results) else 1


if __name__ == "__main__":
    raise SystemExit(main())
