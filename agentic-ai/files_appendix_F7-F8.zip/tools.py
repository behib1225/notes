"""The two tools, built per episode over a policy, a driver and a tier.

`browse_url` is read-only. `browser_act` is not, so Phase 10's gate picks it
up with no wiring at all: `needs_approval` reads `spec.read_only`, the gate is
derived from the registry, and a write tool registered in a later phase is
gated the moment it is registered. That is the whole reason the gate was built
derived rather than configured, and this appendix is the first thing to test
the claim from outside the core.

THREE REFUSALS THAT ARE NOT THE ALLOWLIST, each of which a host check misses:

  the redirect   the request was allowlisted and the RESPONSE came from
                 somewhere else. Checked again on `final_url`, and the content
                 is withheld rather than returned with a warning, because a
                 warning beside 3,000 characters of attacker-controlled text
                 is a warning that loses.
  the budget     `max_pages` per episode, counted in this closure. A browsing
                 agent with no page budget is a crawler.
  the tier       `browser_act` is not built unless the caller named a tier
                 that permits it AND the policy enables acting. Two switches,
                 because the tier says who may and the policy says whether the
                 capability exists at all (invariant 20: an absent tool beats
                 a gated one).
"""

from __future__ import annotations

from typing import Callable

from atlas.browser.driver import ActKind, Driver, DriverError
from atlas.browser.page import PageSnapshot, render_snapshot, snapshot_from_html
from atlas.browser.permissions import browser_tools_for_tier
from atlas.browser.policy import BrowsePolicy, BrowseRefused, check_url
from atlas.tools.registry import ToolRegistry, ToolSpec, tool

__all__ = ["BrowseSession", "make_browser_tools", "browser_specs"]


class BrowseSession:
    """The per-episode state of the browser: the page budget and the log.

    An object rather than a counter in a closure, so a test and the eval
    harness can read what happened without reaching into function internals --
    invariant 40's shape: the record ships with something that can read it.
    """

    def __init__(self, policy: BrowsePolicy) -> None:
        self.policy = policy
        self.pages_opened: list[str] = []
        self.actions_performed: list[dict[str, str]] = []
        self.refusals: list[str] = []

    @property
    def budget_left(self) -> int:
        return max(0, self.policy.max_pages - len(self.pages_opened))

    def charge_page(self) -> None:
        if self.budget_left <= 0:
            raise BrowseRefused(
                f"the page budget for this episode is spent "
                f"({self.policy.max_pages} pages). Answer from what you have "
                "already read, or say what you could not check."
            )

    def record_refusal(self, reason: str) -> None:
        self.refusals.append(reason)


def make_browser_tools(
    policy: BrowsePolicy,
    driver: Driver,
    *,
    tier: str = "anonymous",
    session: BrowseSession | None = None,
) -> tuple[BrowseSession, list[Callable[..., str]]]:
    """Build the browser tools this tier is permitted, over this driver.

    Returns the session (so a caller can read the log) and the tool functions,
    which may be an EMPTY LIST -- and an empty list is the correct outcome for
    `anonymous`, not an error. A factory that raised on a tier with no browser
    would make "this user may not browse" an exception rather than a
    configuration.

    Args:
        policy: The allowlist and the budgets. Empty allowlist refuses all.
        driver: A `ReplayDriver` offline, a `PlaywrightDriver` live.
        tier: One of Phase 14's four permission tiers.
        session: An existing session, for a caller resuming an episode.
    """
    permitted = browser_tools_for_tier(tier)
    state = session or BrowseSession(policy)

    def _fetch(url: str) -> PageSnapshot:
        """Check, charge, open, check again. The whole read path."""
        target = check_url(policy, url)
        state.charge_page()
        try:
            raw = driver.open(target, timeout_s=policy.timeout_s)
        except DriverError as exc:
            raise ValueError(f"could not open {target}: {exc}") from exc
        state.pages_opened.append(target)
        # The SECOND check, on the response. A redirect is the one way an
        # allowlisted request produces off-allowlist content, and it is
        # invisible to a checker that only sees the request.
        try:
            check_url(policy, raw.final_url)
        except BrowseRefused as exc:
            state.record_refusal(f"redirect to {raw.final_url}")
            raise BrowseRefused(
                f"{target} redirected to {raw.final_url}, which is not on the "
                f"allowlist, so its content was discarded. {exc}"
            ) from exc
        return snapshot_from_html(target, raw, policy)

    @tool(
        name="browse_url",
        read_only=True,
        max_output_chars=4_000,
        examples=["browse_url(url='https://docs.example.org/changelog')"],
    )
    def browse_url(url: str) -> str:
        """Open one page from the browse allowlist and return its visible text.

        Args:
            url: A full https:// URL on the allowlist. Only allowlisted hosts
                can be opened; everything else is refused, including
                redirects that leave the allowlist. Prefer the documents
                index and the company database for anything internal: this
                tool reaches the public web only.
        """
        return render_snapshot(_fetch(url))

    # `cacheable=False` and NOT read_only. Both flags are decisions:
    # `read_only=False` is what makes Phase 10's derived gate fire, and
    # `cacheable=False` is invariant 37 -- a step whose tool is not read-only
    # is never auto-retried, replayed or cached, and a replayed form
    # submission is a second form submission.
    @tool(
        name="browser_act",
        read_only=False,
        cacheable=False,
        max_output_chars=4_000,
        examples=["browser_act(url='https://forms.example.org/ticket', "
                  "selector='#submit', kind='click', text='')"],
    )
    def browser_act(url: str, selector: str, kind: str, text: str = "") -> str:
        """Click an element or type into a field on an allowlisted page.

        Args:
            url: The page to act on. Must be on the browse allowlist.
            selector: A CSS selector naming exactly one element, such as
                '#submit' or 'button.primary'.
            kind: Either 'click' or 'type'.
            text: What to type. Required for 'type', ignored for 'click'.
        """
        if kind not in ("click", "type"):
            raise ValueError(f"kind must be 'click' or 'type', got {kind!r}")
        if kind == "type" and not text:
            raise ValueError("kind='type' needs text")
        target = check_url(policy, url)
        state.charge_page()
        try:
            raw = driver.act(
                target,
                selector=selector,
                kind=kind,  # type: ignore[arg-type]
                text=text,
                timeout_s=policy.timeout_s,
            )
        except DriverError as exc:
            raise ValueError(f"could not {kind} {selector!r} on {target}: {exc}") from exc
        state.pages_opened.append(target)
        state.actions_performed.append({"url": target, "selector": selector, "kind": kind})
        try:
            check_url(policy, raw.final_url)
        except BrowseRefused as exc:
            state.record_refusal(f"redirect to {raw.final_url}")
            raise BrowseRefused(
                f"the action succeeded and landed on {raw.final_url}, which is "
                f"not on the allowlist, so the resulting page was discarded. {exc}"
            ) from exc
        return render_snapshot(snapshot_from_html(target, raw, policy))

    tools: list[Callable[..., str]] = []
    if "browse_url" in permitted:
        tools.append(browse_url)
    if "browser_act" in permitted and policy.allow_act:
        tools.append(browser_act)
    return state, tools


def browser_specs(tools: list[Callable[..., str]]) -> list[ToolSpec]:
    """The specs of built browser tools, for adding to an existing registry."""
    return [t.tool_spec for t in tools]  # type: ignore[attr-defined]


def add_browser_tools(registry: ToolRegistry, tools: list[Callable[..., str]]) -> ToolRegistry:
    """A NEW registry with the browser tools added. Never mutates the input.

    A new object rather than `registry.register(...)` in place, because a
    registry is the action space of an episode and something that can be
    widened after it is built is not one (invariant 10). The caller decides
    which registry the browser is in, and the one it was handed is unchanged.
    """
    return ToolRegistry(list(registry.specs) + browser_specs(tools))
