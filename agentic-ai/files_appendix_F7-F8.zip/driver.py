"""Two drivers behind one protocol: a replay driver and a real browser.

The replay driver is not a mock. It is this appendix's Tier F: a committed
directory of HTML pages with a deterministic action map, so every test, every
eval task and the demo run with no network, no Chromium and no flake. The
argument is Phase 0's, unchanged -- a suite that needs a browser is a suite
that fails on a train -- and it is stronger here than for a model, because a
live page is a moving golden answer.

`PlaywrightDriver` is the real one. It is deliberately the smallest thing that
can be called a browser: one context per episode, no cookies carried in, no
downloads, one page, an explicit timeout on every call, and the context closed
in a `finally`. It cannot run during authoring -- there is no browser in the
authoring container -- so it carries the marker this book uses for that and
its verification is the command in the section text, not a fixture.

WHAT A PRODUCTION DRIVER WOULD ADD, and none of it is here: a per-episode
network interception rule enforcing the allowlist at the request layer rather
than at navigation (which is what closes DNS rebinding and sub-resource
fetches), a hard memory and CPU bound on the browser process, a screenshot
channel with its own redaction, and a proxy that logs every request for the
audit trail. Section F.7's opening paragraph says this build is demo-grade;
this list is what that sentence means concretely.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Literal, Protocol

from atlas.browser.page import RawPage

__all__ = ["ActKind", "Driver", "ReplayDriver", "PlaywrightDriver", "DriverError"]

ActKind = Literal["click", "type"]


class DriverError(RuntimeError):
    """The browser could not do it: navigation failed, timed out, or 404'd."""


class Driver(Protocol):
    """What the tools need from a browser, and nothing more.

    Two methods, both returning a `RawPage`. A protocol rather than a base
    class so the replay driver owes the real one no inheritance, and so a
    reader can see the whole contract in six lines.
    """

    def open(self, url: str, *, timeout_s: float) -> RawPage: ...

    def act(
        self, url: str, *, selector: str, kind: ActKind, text: str, timeout_s: float
    ) -> RawPage: ...


class ReplayDriver:
    """Serves committed pages from a directory. Deterministic, offline.

    The corpus is one JSON file per page: `{"url", "status", "html"}`, plus
    `actions.json` mapping `"<url>|<selector>|<kind>"` to the url that action
    navigates to. Built by `scripts/gen_browser_fixtures.py` from a seed, like
    every other corpus in this book.

    It counts what it served. That counter is how the eval tasks grade the
    negative half -- "the driver was never called" is the check that separates
    a refusal from a fetch whose result was discarded, and a refusal you
    cannot distinguish from a discard is not a refusal.
    """

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root)
        self.pages: dict[str, RawPage] = {}
        self.actions: dict[str, str] = {}
        self.opened: list[str] = []
        self.acted: list[tuple[str, str, str]] = []
        for path in sorted(self.root.glob("*.json")):
            if path.name == "actions.json":
                self.actions = json.loads(path.read_text(encoding="utf-8"))
                continue
            payload = json.loads(path.read_text(encoding="utf-8"))
            self.pages[payload["url"]] = RawPage(
                final_url=payload.get("final_url", payload["url"]),
                status=int(payload.get("status", 200)),
                html=payload["html"],
            )

    def open(self, url: str, *, timeout_s: float = 10.0) -> RawPage:
        self.opened.append(url)
        page = self.pages.get(url)
        if page is None:
            raise DriverError(
                f"no page at {url} in the replay corpus. Available: "
                + ", ".join(sorted(self.pages)[:5])
            )
        return page

    def act(
        self,
        url: str,
        *,
        selector: str,
        kind: ActKind,
        text: str = "",
        timeout_s: float = 10.0,
    ) -> RawPage:
        self.acted.append((url, selector, kind))
        target = self.actions.get(f"{url}|{selector}|{kind}")
        if target is None:
            raise DriverError(
                f"the replay corpus has no {kind} on {selector!r} at {url}"
            )
        return self.open(target, timeout_s=timeout_s)


class PlaywrightDriver:  # pragma: no cover
    # not executed during authoring; verified in companion-repo CI
    """A real browser, one context per episode, closed in a `finally`.

    Constructed with `PlaywrightDriver()` and used as a context manager so the
    browser process has a lifetime the caller can see. An episode-scoped
    context is the browser analogue of a per-episode registry: nothing carries
    between episodes, so a cookie set by one user's page is not present for
    the next.
    """

    def __init__(self, *, headless: bool = True) -> None:
        self.headless = headless
        self._playwright = None
        self._browser = None
        self._context = None

    def __enter__(self) -> "PlaywrightDriver":
        from playwright.sync_api import sync_playwright  # noqa: PLC0415

        self._playwright = sync_playwright().start()
        self._browser = self._playwright.chromium.launch(headless=self.headless)
        # No stored state, no downloads, and a fixed viewport so a page's text
        # does not depend on the machine. `accept_downloads=False` matters:
        # a download is a write to the filesystem performed by a read-only
        # tool, which would put an effect outside the jail and outside the gate.
        self._context = self._browser.new_context(
            accept_downloads=False,
            viewport={"width": 1280, "height": 900},
            java_script_enabled=True,
        )
        return self

    def __exit__(self, *exc: object) -> None:
        try:
            if self._context is not None:
                self._context.close()
            if self._browser is not None:
                self._browser.close()
        finally:
            if self._playwright is not None:
                self._playwright.stop()

    def _page(self):
        if self._context is None:
            raise DriverError(
                "PlaywrightDriver used outside its context manager; "
                "use `with PlaywrightDriver() as driver:`"
            )
        return self._context.new_page()

    def open(self, url: str, *, timeout_s: float = 10.0) -> RawPage:
        page = self._page()
        try:
            response = page.goto(url, timeout=timeout_s * 1000, wait_until="domcontentloaded")
            if response is None:
                raise DriverError(f"no response from {url}")
            return RawPage(final_url=page.url, status=response.status, html=page.content())
        except Exception as exc:  # noqa: BLE001 - every failure is a DriverError
            raise DriverError(f"{type(exc).__name__}: {exc}") from exc
        finally:
            page.close()

    def act(
        self,
        url: str,
        *,
        selector: str,
        kind: ActKind,
        text: str = "",
        timeout_s: float = 10.0,
    ) -> RawPage:
        page = self._page()
        try:
            page.goto(url, timeout=timeout_s * 1000, wait_until="domcontentloaded")
            locator = page.locator(selector).first
            if kind == "click":
                locator.click(timeout=timeout_s * 1000)
            else:
                locator.fill(text, timeout=timeout_s * 1000)
            page.wait_for_load_state("domcontentloaded", timeout=timeout_s * 1000)
            return RawPage(final_url=page.url, status=200, html=page.content())
        except Exception as exc:  # noqa: BLE001
            raise DriverError(f"{type(exc).__name__}: {exc}") from exc
        finally:
            page.close()
