"""Check the interview bank against itself, the repo, and its own prose.

Phase 16's finding is the whole justification for this file. A manifest of 44
rows, written from memory immediately after building the work it described,
had THIRTEEN wrong references -- eleven test names, two entry points, one task
id -- and not one of them would have failed a test, because the suite tested
the mechanism rather than the claim. The fix was to make the claim list DATA
and bind each row to something that must exist.

An interview bank is the same object. Every question claims "taught in Phase
N", which is a reference into the book; the counts in the prose are numbers;
and both rot silently, because prose has no compiler. So the bank is
`docs/interview_bank.json` and this program is its compiler.

Seven checks, each with the defect it would have caught:

  ids          duplicate or missing ids -- a bank you cannot cite by id
  counts       `meta.n_questions` against the rows actually present
  prose        the headline sentence in docs/INTERVIEW_BANK.md against the
               data. THIS IS THE ONE THAT MATTERS: the first draft of this
               appendix said "thirty questions" over a list of forty, which
               is invariant 73 exactly -- a number in the prose that no code
               produced -- in the section that quotes invariant 73.
  phases       every cited phase is in range, and resolves to a real document
               unless it is in the exemption table WITH A REASON
  coverage     every phase 0-16 is reachable from at least one entry, so the
               bank cannot silently stop covering a phase somebody edited out
  difficulty   labels come from a closed set, and the distribution is PRINTED
               rather than asserted, because "enough hard questions" is a
               judgement and a printed number is what lets you make it
  prompts      each design prompt cites at least three phases and carries at
               least five rubric criteria -- a rubric with three rows grades
               presentation

Exit code 1 on any finding. `make check-bank` runs it; no model, no network.
"""

from __future__ import annotations

import argparse
import json
import re
import sys
from collections import Counter
from pathlib import Path

BANK = Path("docs/interview_bank.json")
PROSE = Path("docs/INTERVIEW_BANK.md")
MIN_PROMPT_PHASES = 3
MIN_RUBRIC_CRITERIA = 5


def phase_document(root: Path, phase: int) -> Path | None:
    """The tutorial file for one phase, or None. Globs rather than guesses.

    A hard-coded filename would be a second copy of a name the repo already
    owns -- the drift this whole file exists to prevent, committed inside the
    tool that prevents it.
    """
    hits = sorted(root.glob(f"phase_{phase:02d}_*.md"))
    hits = [h for h in hits if "solutions" not in h.name]
    return hits[0] if hits else None


def headline(n_questions: int, n_prompts: int) -> str:
    """The one sentence the prose must contain. Generated, never typed."""
    return (
        f"This bank holds {n_questions} conceptual questions and "
        f"{n_prompts} system-design prompts."
    )


def check_bank(root: Path = Path("."), *, verbose: bool = True) -> list[str]:
    """Return a list of findings. Empty means the bank is consistent."""
    findings: list[str] = []
    bank = json.loads((root / BANK).read_text(encoding="utf-8"))
    meta = bank["meta"]
    questions = bank["questions"]
    prompts = bank["prompts"]

    ids = [q["id"] for q in questions] + [p["id"] for p in prompts]
    for name, count in Counter(ids).items():
        if count > 1:
            findings.append(f"duplicate id {name!r}")
    if any(not str(i).strip() for i in ids):
        findings.append("an entry has a blank id")

    if len(questions) != meta["n_questions"]:
        findings.append(
            f"meta.n_questions says {meta['n_questions']} and there are "
            f"{len(questions)} questions"
        )
    if len(prompts) != meta["n_prompts"]:
        findings.append(
            f"meta.n_prompts says {meta['n_prompts']} and there are "
            f"{len(prompts)} prompts"
        )

    expected = headline(len(questions), len(prompts))
    prose_path = root / PROSE
    if not prose_path.exists():
        findings.append(f"{PROSE} does not exist, so no prose is checked")
    elif expected not in prose_path.read_text(encoding="utf-8"):
        findings.append(
            f"{PROSE} does not contain the generated headline: {expected!r}"
        )

    low, high = meta["phase_range"]
    exempt = {int(k): v for k, v in meta["phases_without_document"].items()}
    for reason in exempt.values():
        if not reason.strip():
            findings.append("a phase exemption carries no reason")
    cited: set[int] = set()
    for entry in questions + prompts:
        for phase in entry["phases"]:
            cited.add(phase)
            if not low <= phase <= high:
                findings.append(f"{entry['id']} cites phase {phase}, out of range")
            elif phase not in exempt and phase_document(root, phase) is None:
                findings.append(
                    f"{entry['id']} cites phase {phase}, whose document is "
                    "absent and which is not in phases_without_document"
                )

    for phase in range(low, high + 1):
        if phase not in cited:
            findings.append(f"no entry covers phase {phase}")

    allowed = set(meta["difficulties"])
    for question in questions:
        if question["difficulty"] not in allowed:
            findings.append(
                f"{question['id']} has difficulty {question['difficulty']!r}, "
                f"not one of {sorted(allowed)}"
            )

    for prompt in prompts:
        if len(prompt["phases"]) < MIN_PROMPT_PHASES:
            findings.append(
                f"{prompt['id']} cites {len(prompt['phases'])} phases; a design "
                f"prompt spanning fewer than {MIN_PROMPT_PHASES} is a question"
            )
        if prompt["rubric_criteria"] < MIN_RUBRIC_CRITERIA:
            findings.append(
                f"{prompt['id']} has {prompt['rubric_criteria']} rubric criteria; "
                f"fewer than {MIN_RUBRIC_CRITERIA} grades presentation"
            )

    if verbose:
        spread = Counter(q["difficulty"] for q in questions)
        print(f"interview bank: {len(questions)} questions, {len(prompts)} prompts")
        print("  difficulty   " + ", ".join(
            f"{label} {spread.get(label, 0)}" for label in meta["difficulties"]
        ))
        # Counted over the DECLARED range only. The first version printed
        # `len(cited)`, so a bank citing an out-of-range phase reported "18 of
        # 17 covered" -- a summary line that contradicts the finding printed
        # three lines below it. A report that disagrees with its own findings
        # teaches the reader to trust the summary.
        in_range = {p for p in cited if low <= p <= high}
        print(f"  phases cited {min(cited)}-{max(cited)}, "
              f"{len(in_range)} of {high - low + 1} covered")
        print(f"  documents    {sum(1 for p in cited if p not in exempt)} resolved, "
              f"{len(exempt)} exempt with reasons")
        print(f"  headline     {headline(len(questions), len(prompts))!r}")
    return findings


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", default=".")
    args = parser.parse_args(argv)
    findings = check_bank(Path(args.root))
    for finding in findings:
        print(f"  FINDING: {finding}", file=sys.stderr)
    if findings:
        print(f"\n{len(findings)} finding(s). The bank and its prose disagree.",
              file=sys.stderr)
        return 1
    print("  no findings.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
