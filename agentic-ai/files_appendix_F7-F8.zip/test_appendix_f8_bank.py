"""Offline tests for the F.8 interview bank checker. No model, no network.

These are propositions about a program, which is what a test is. They prove
the checker FIRES -- each one plants exactly one defect and asserts the
finding names it. A checker nobody has seen fail is a checker nobody has
tested, and the two most common ways to ship one are a rule that never
matches and a rule that matches everything.
"""

from __future__ import annotations

import json
import shutil
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from check_interview_bank import check_bank, headline  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture()
def tree(tmp_path: Path) -> Path:
    """A minimal copy: the bank, its prose, and the phase documents."""
    shutil.copytree(ROOT / "docs", tmp_path / "docs")
    for document in ROOT.glob("phase_*.md"):
        shutil.copy(document, tmp_path / document.name)
    return tmp_path


def _bank(tree: Path) -> dict:
    return json.loads((tree / "docs" / "interview_bank.json").read_text())


def _write(tree: Path, bank: dict) -> None:
    (tree / "docs" / "interview_bank.json").write_text(json.dumps(bank))


def test_the_committed_bank_is_clean(tree: Path) -> None:
    assert check_bank(tree, verbose=False) == []


def test_a_miscount_in_the_prose_is_a_finding(tree: Path) -> None:
    """F-F8-01's regression test: 'thirty' over a list of forty."""
    bank = _bank(tree)
    bank["questions"] = bank["questions"][:-1]   # 29 rows, meta still says 30
    _write(tree, bank)
    findings = check_bank(tree, verbose=False)
    assert any("meta.n_questions" in f for f in findings)
    assert any("headline" in f for f in findings)


def test_a_dangling_phase_reference_is_a_finding(tree: Path) -> None:
    bank = _bank(tree)
    bank["questions"][0]["phases"] = [99]
    _write(tree, bank)
    assert any("out of range" in f for f in check_bank(tree, verbose=False))


def test_an_uncovered_phase_is_a_finding(tree: Path) -> None:
    """Coverage is the check that notices a phase quietly dropping out."""
    bank = _bank(tree)
    for entry in bank["questions"] + bank["prompts"]:
        entry["phases"] = [pn for pn in entry["phases"] if pn != 15] or [1]
    _write(tree, bank)
    assert any("no entry covers phase 15" in f for f in check_bank(tree, verbose=False))


def test_an_exemption_without_a_reason_is_a_finding(tree: Path) -> None:
    bank = _bank(tree)
    bank["meta"]["phases_without_document"]["0"] = "  "
    _write(tree, bank)
    assert any("no reason" in f for f in check_bank(tree, verbose=False))


def test_a_thin_rubric_is_a_finding(tree: Path) -> None:
    bank = _bank(tree)
    bank["prompts"][0]["rubric_criteria"] = 3
    _write(tree, bank)
    assert any("grades presentation" in f for f in check_bank(tree, verbose=False))


def test_an_unknown_difficulty_label_is_a_finding(tree: Path) -> None:
    bank = _bank(tree)
    bank["questions"][0]["difficulty"] = "medium"
    _write(tree, bank)
    assert any("difficulty" in f for f in check_bank(tree, verbose=False))


def test_the_headline_is_generated_not_typed() -> None:
    assert headline(30, 3) == (
        "This bank holds 30 conceptual questions and 3 system-design prompts."
    )
    assert headline(40, 3) != headline(30, 3)
