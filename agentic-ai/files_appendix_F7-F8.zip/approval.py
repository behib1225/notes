"""The approval gate: layer (a), before dispatch, on a proposal.

Four things in this module are policy decisions rather than mechanism, and
each is here rather than in a configuration file so that a reader can find the
reason beside the rule.

**The gated set is DERIVED, never configured.** `needs_approval` reads
`spec.read_only`, so a write tool registered in a later phase is gated the
moment it is registered. The framework's own gate is an allow-list and
auto-approves anything unlisted -- a defensible general policy, and default-
allow, which is not Atlas's (invariant 20). An allow-list would mean the gate
protects whatever somebody remembered to type, which is invariant 58: a
capability the caller must remember to switch on is off in production.

**The exempt set is enumerated WITH REASONS.** Every non-ask is a decision
(§6.4 rule 3), so `EXEMPT` is a dict of tool name to justification and is
printed by `render_policy()`. An exemption with no reason is indistinguishable
from a forgotten tool.

**The interrupt is the FIRST statement of its node.** `interrupt()` re-executes
its node from the top on resume -- measured, §6.2 -- so anything above it runs
once per resume. Nothing is above it here.

**A malformed decision is a refusal.** `Command(resume=x)` performs no
validation, so `ApprovalDecision` is the validator (invariant 13) and an
unreadable payload becomes a recorded refusal rather than an exception or an
approval. Fail closed, and record that it happened.
"""

from __future__ import annotations

from typing import Any, Sequence

from langchain_core.messages import AIMessage, AnyMessage
from langgraph.types import interrupt

from atlas.graph.state import (
    ApprovalDecision,
    ApprovalRecord,
    PendingAction,
)
from atlas.graph.tools import calls_of
from atlas.llm import ToolCall
from atlas.tools.registry import ToolRegistry, ToolSpec

__all__ = [
    "EXEMPT",
    "IRREVERSIBLE_REASONS",
    "register_irreversible",
    "CONSEQUENCE_RENDERERS",
    "MissingConsequenceRenderer",
    "has_consequence_renderer",
    "IRREVERSIBLE",
    "needs_approval",
    "gated_specs",
    "consequence_for",
    "pending_actions",
    "render_for_operator",
    "render_policy",
    "decision_from_resume",
    "apply_decisions",
]

# Tools that modify state and are NOT gated, each with the reason. Empty at
# the end of this phase, and that is the honest state: every write Atlas has
# is one an operator should see. The dict exists because the NEXT phase will
# want an entry, and an exemption mechanism introduced under time pressure is
# an exemption mechanism with no reason field.
EXEMPT: dict[str, str] = {}

# Tools whose effects cannot be undone by Atlas. Presented first in the
# operator payload and labelled (§6.4 rule 4). Deliberately a small explicit
# set rather than a computed property: "reversible" is a fact about the world,
# not about the signature, and guessing it wrong in the confident direction is
# the worst available error.
# A MUTABLE set with a registration function beside it, matching
# `CONSEQUENCE_RENDERERS`. It was a frozenset until Appendix F.7 tried to add
# a gated tool from outside the core and found that the pair had one
# extension point between them: the sentence could be registered and the
# LABEL could not, so a plug-in supplied half the operator payload and
# inherited `reversible` -- the permissive default -- for the other half. An
# extension point that covers one half of a pair manufactures the other
# half's value. See docs/FAILURE_LOG.md F-F7-01.
IRREVERSIBLE: set[str] = {
    "write_file", "remember", "run_python", "company_note_append"
}

# Why each one cannot be undone. Enumerated for the same reason `EXEMPT` is:
# a set whose entries carry no justification can be trusted and not reviewed,
# and `render_policy` prints these so a reader can disagree with one.
IRREVERSIBLE_REASONS: dict[str, str] = {
    "write_file": "overwrites in place; prior contents are not recoverable",
    "remember": "affects every future session for this user, not one conversation",
    "run_python": "side effects inside the sandbox are not enumerable in advance",
    "company_note_append": "lands in a shared workspace outside Atlas's control",
}


def register_irreversible(name: str, reason: str) -> None:
    """Declare that Atlas cannot undo `name`. Idempotent; a reason is required.

    The reason is not decoration. `IRREVERSIBLE` decides two things an
    operator sees -- the word beside the action and its position in the list,
    since `pending_actions` sorts irreversible actions first -- so an entry
    nobody can argue with is an entry nobody has reviewed.
    """
    if not name or not reason.strip():
        raise ValueError(
            f"register_irreversible({name!r}) needs a reason: the reason is "
            "what makes the entry reviewable, and an unexplained entry is "
            "indistinguishable from a guess."
        )
    IRREVERSIBLE.add(name)
    IRREVERSIBLE_REASONS.setdefault(name, reason)


def needs_approval(spec: ToolSpec) -> bool:
    """Gate anything that is not read-only and not explicitly exempt."""
    return not spec.read_only and spec.name not in EXEMPT


def gated_specs(registry: ToolRegistry) -> list[ToolSpec]:
    """The gated subset of a registry, in the registry's sorted order."""
    return [spec for spec in registry.specs if needs_approval(spec)]


def render_policy(registry: ToolRegistry) -> str:
    """The gated set and the exempt set, both enumerated. §6.4 rule 3.

    A reader who can see only the gated set cannot tell a considered exemption
    from a forgotten tool, so both are printed and the exempt rows carry their
    justification.
    """
    lines = ["approval policy:"]
    for spec in registry.specs:
        if needs_approval(spec):
            if spec.name in IRREVERSIBLE:
                why = IRREVERSIBLE_REASONS.get(spec.name, "(no reason recorded)")
                lines.append(f"  GATED  {spec.name:20s} (IRREVERSIBLE — {why})")
            else:
                lines.append(f"  GATED  {spec.name:20s} (reversible)")
        elif spec.name in EXEMPT:
            lines.append(f"  exempt {spec.name:20s} — {EXEMPT[spec.name]}")
        else:
            lines.append(f"  exempt {spec.name:20s} — read_only")
    return "\n".join(lines)


class MissingConsequenceRenderer(RuntimeError):
    """A gated tool with no way to describe its effect to an operator.

    Raised at WIRING time, not at approval time. §8's trace turns on the
    alternative: `consequence_for` used to fall through to "target state
    unknown: the arguments are shown verbatim", which printed an honest
    warning into an approval prompt that an operator read past. An honest
    warning nobody acts on is invariant 49 misapplied -- that invariant is
    about a signal wired to no DECISION, not about a hole wired to no
    REFUSAL. So the hole refuses: adding a write tool now forces somebody to
    write the sentence an operator will read, before the graph will compile.
    """


def has_consequence_renderer(name: str) -> bool:
    """Is there a consequence sentence for this tool?

    Asks the renderer table rather than duplicating its keys, because a
    second list of the names would be drift (invariant 18's reasoning applied
    to a registry of renderers).
    """
    return name in CONSEQUENCE_RENDERERS


def _write_file_consequence(arguments: dict[str, Any]) -> str:
    path = arguments.get("path", "(no path)")
    size = len(str(arguments.get("content", "")))
    # Deliberately NOT stat()-ing the path: a node body that touches the
    # filesystem to render a prompt is a node body that touches the
    # filesystem once per resume (§6.2), and the answer would be stale by the
    # time the operator reads it anyway.
    return (
        f"Write {size} characters to {path} inside the jailed workspace. "
        "Overwrites the file if it exists; prior contents are not recoverable."
    )


def _remember_consequence(arguments: dict[str, Any]) -> str:
    text = str(arguments.get("text", ""))
    return (
        f"Store a durable memory: {text[:120]!r}. Affects every future "
        "session for this user, not only this conversation."
    )


def _run_python_consequence(arguments: dict[str, Any]) -> str:
    code = str(arguments.get("code", ""))
    return (
        f"Execute {len(code)} characters of Python in the sandbox. "
        "Side effects inside the sandbox are not enumerable in advance."
    )


def _company_note_consequence(arguments: dict[str, Any]) -> str:
    """Phase 12. The effect of a write that leaves this process.

    Three facts the local `write_file` renderer does not have to state, and
    each is the reason a remote write needs its own renderer rather than
    reusing one: the workspace is SHARED, so the audience is the company
    rather than Atlas's scratch directory; the write is APPENDED rather than
    overwriting, so the prior contents survive and the irreversibility is of a
    different kind; and the service will ask its OWN confirmation, so the
    operator should know this approval is the first of two rather than
    wondering why they are asked twice (§7.4's double-gate note).
    """
    path = arguments.get("path", "(no path)")
    size = len(str(arguments.get("content", "")))
    return (
        f"Append {size} characters to {path} in the SHARED company workspace, "
        "via the company-data service. Visible to the whole team; the append "
        "cannot be undone by Atlas. The service will also ask its own "
        "confirmation before writing."
    )


# One renderer per gated tool. The table IS the completeness check: a gated
# tool absent from it cannot be described, so it cannot be approved, so the
# graph refuses to compile (invariant 66).
CONSEQUENCE_RENDERERS: dict[str, Any] = {
    "write_file": _write_file_consequence,
    "remember": _remember_consequence,
    "run_python": _run_python_consequence,
    "company_note_append": _company_note_consequence,
}


def consequence_for(spec: ToolSpec, arguments: dict[str, Any]) -> str:
    """The sentence the operator consents to. §6.4 rule 1.

    Renders the EFFECT, not the call. `write_file(path=..., content=...)` is a
    serialisation; "overwrite an existing 2.1 kB file" is a fact about the
    world that the arguments do not carry.

    Where the effect cannot be established cheaply this says so. "Target state
    unknown" is useful to an operator; a confident wrong sentence is the worst
    available output, which is why nothing here guesses.
    """
    renderer = CONSEQUENCE_RENDERERS.get(spec.name)
    if renderer is None:
        raise MissingConsequenceRenderer(
            f"{spec.name} is gated for approval but has no consequence "
            "renderer, so an operator would be shown its arguments instead of "
            "its effect. Add an entry to CONSEQUENCE_RENDERERS in "
            "atlas/graph/approval.py describing what running it does."
        )
    return renderer(arguments)


def pending_actions(
    registry: ToolRegistry, calls: Sequence[ToolCall]
) -> list[PendingAction]:
    """The gated calls of one batch, irreversible ones first.

    `index` is the call's position in the ORIGINAL batch, not its position
    here. Invariant 21: the native dialect gives a result no call id, so
    position is the only correlation available, and re-indexing for
    presentation would misattribute every decision.
    """
    actions: list[PendingAction] = []
    for index, call in enumerate(calls):
        spec = registry.get(call.name)
        if spec is None or not needs_approval(spec):
            continue
        actions.append(
            PendingAction(
                index=index,
                tool=call.name,
                arguments=dict(call.arguments),
                consequence=consequence_for(spec, call.arguments),
                reversible=call.name not in IRREVERSIBLE,
            )
        )
    return sorted(actions, key=lambda a: (a.reversible, a.index))


def render_for_operator(
    actions: Sequence[PendingAction], *, request: str = ""
) -> str:
    """What a human reads. Refusal is named as plainly as approval."""
    lines = []
    if request:
        lines.append(f"Atlas is working on: {request}")
    n = len(actions)
    lines.append(
        f"{n} action{'s' if n != 1 else ''} need your decision "
        "(approve / edit / reject — rejecting is safe and Atlas will report "
        "what it could not do):"
    )
    lines += [action.render() for action in actions]
    return "\n".join(lines)


def decision_from_resume(payload: Any) -> tuple[ApprovalDecision, bool]:
    """Validate an operator's resume value. Returns (decision, malformed).

    A malformed payload becomes a REFUSAL, not an exception and not an
    approval. Three reasons: an exception inside a node that has already
    interrupted once produces a thread that cannot be driven forward without
    surgery; an approval-by-default turns a typo into a write; and a recorded
    refusal is a fact an operator can see and retry.
    """
    if isinstance(payload, ApprovalDecision):
        return payload, False
    try:
        return ApprovalDecision.model_validate(payload), False
    except Exception:  # noqa: BLE001 - any validation failure is a refusal
        return (
            ApprovalDecision(
                kind="reject",
                reason="the decision payload could not be read; refused",
            ),
            True,
        )


def apply_decisions(
    message: AIMessage,
    actions: Sequence[PendingAction],
    decisions: Sequence[Any],
) -> tuple[list[AnyMessage], list[dict[str, Any]], list[int]]:
    """Turn decisions into (new messages, approval records, refused indices).

    The model's assistant message is NEVER edited. The framework's gate
    assigns the revised calls onto the message and returns it with the same
    id, so `add_messages` upserts and the original proposal is destroyed --
    measured, §6.3, and invariant 15 says repairs are recorded, never hidden.
    An edit is a repair performed by a human.

    So an edit produces a NEW assistant message with a NEW id, carrying
    `additional_kwargs["atlas_authored_by"] = "human"`, and the original
    stands. `refused` carries positions rather than calls, because position is
    the correlation (invariant 21) and the dispatch step needs to know which
    slots to fill with `write_refused` without re-deriving the mapping.
    """
    records: list[dict[str, Any]] = []
    refused: list[int] = []
    edits: dict[int, dict[str, Any]] = {}

    for action, raw in zip(actions, decisions):
        decision, malformed = decision_from_resume(raw)
        final: dict[str, Any] | None = None
        if decision.kind == "edit":
            final = dict(decision.edited_arguments or {})
            if not final:
                # An edit with no arguments is not an edit. Downgraded to a
                # refusal and RECORDED as malformed, rather than silently
                # approving the original -- which is what "apply the edit"
                # would do with an empty dict.
                decision = ApprovalDecision(
                    kind="reject",
                    reason="edit carried no arguments; refused",
                    operator_id=decision.operator_id,
                )
                malformed, final = True, None
            else:
                edits[action.index] = final
        if decision.kind == "reject":
            refused.append(action.index)
        records.append(
            ApprovalRecord(
                tool=action.tool,
                decision=decision.kind,
                proposed_arguments=action.arguments,
                final_arguments=final,
                reason=decision.reason,
                operator_id=decision.operator_id,
                malformed=malformed,
            ).model_dump()
        )

    messages: list[AnyMessage] = []
    if edits:
        revised = []
        for index, call in enumerate(message.tool_calls or []):
            if index in edits:
                revised.append(
                    {
                        "type": "tool_call",
                        "name": call["name"],
                        "args": edits[index],
                        "id": f"{call.get('id') or index}-human",
                    }
                )
            else:
                revised.append(dict(call))
        messages.append(
            AIMessage(
                content="",
                tool_calls=revised,
                additional_kwargs={"atlas_authored_by": "human"},
            )
        )
    return messages, records, refused


def request_decisions(
    actions: Sequence[PendingAction], *, request: str = ""
) -> Any:
    """Suspend and ask. The ONLY statement in the gate node above any logic.

    One interrupt per assistant turn carrying every pending action (§6.4
    rule 4), so an operator evaluating three writes evaluates them together
    rather than clicking through three dialogs.
    """
    return interrupt(
        {
            "kind": "approval",
            "prompt": render_for_operator(actions, request=request),
            "actions": [action.model_dump() for action in actions],
        }
    )
