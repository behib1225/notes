"""Week 0 primer: reference solutions (run: uv run python primer/primer_solutions.py)."""
import asyncio
import json
import time
from typing import Annotated, Literal

from pydantic import BaseModel, Field, ValidationError


# P1. async/await: run three slow "API calls" concurrently and return results in order.
async def fake_call(name: str, delay: float) -> str:
    await asyncio.sleep(delay)          # stands in for an HTTP request
    return f"{name} done"


async def run_all() -> list[str]:
    return await asyncio.gather(fake_call("a", 0.3), fake_call("b", 0.2), fake_call("c", 0.1))


# P2. Blocking code inside async code: move it to a worker thread.
def blocking_call() -> str:
    time.sleep(0.2)                      # e.g. a synchronous SDK call
    return "blocking done"


async def run_mixed() -> list[str]:
    return await asyncio.gather(asyncio.to_thread(blocking_call), fake_call("d", 0.2))


# P3. Pydantic + Annotated: one model gives validation AND a JSON Schema for a tool.
class SearchArgs(BaseModel):
    query: Annotated[str, Field(min_length=2, description="Keywords, not a full question")]
    limit: Annotated[int, Field(ge=1, le=10)] = 5
    lang: Literal["en", "fr", "de"] = "en"


if __name__ == "__main__":
    t0 = time.perf_counter()
    print(asyncio.run(run_all()), f"{time.perf_counter() - t0:.2f}s (about 0.3s, not 0.6s)")
    t0 = time.perf_counter()
    print(asyncio.run(run_mixed()), f"{time.perf_counter() - t0:.2f}s (about 0.2s)")
    print(json.dumps(SearchArgs.model_json_schema(), indent=1))
    print(SearchArgs.model_validate({"query": "BM25"}))
    try:
        SearchArgs.model_validate({"query": "x", "limit": 50})
    except ValidationError as e:
        print("rejected:", [err["loc"][0] for err in e.errors()])
