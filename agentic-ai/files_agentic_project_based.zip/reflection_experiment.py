"""Does the editor (reflection) loop actually improve the brief? Measure it.

Runs each question twice, through the same research notes: once with no editor revisions
(max_revisions=0) and once with up to 2. A judge scores both briefs 1-5 against a rubric
without knowing which is which; a paired bootstrap gives a 95% CI for the mean difference.

Run: uv run --env-file .env python -m p3_langgraph.reflection_experiment
"""
from __future__ import annotations

import random
import statistics
import uuid
from functools import lru_cache
from typing import Callable

from langgraph.types import Command
from pydantic import BaseModel, Field

from p3_langgraph.report_graph import build_graph

RUBRIC = ("Score 1-5: every claim is supported by the notes and cited; the question is fully "
          "answered; no padding. 5 = all three fully met, 1 = none met.")
QUESTIONS = ["How did the invention of the transistor change computing?",
             "Why did the Apollo program end?",
             "What made the printing press spread so quickly in Europe?"]


class Score(BaseModel):
    score: int = Field(ge=1, le=5)
    reason: str


def run_brief(question: str, max_revisions: int, research: Callable[[str], str],
              ask: Callable | None = None) -> str:
    graph = build_graph(ask=ask, research=research, max_revisions=max_revisions)
    cfg = {"configurable": {"thread_id": uuid.uuid4().hex}}
    out = graph.invoke({"question": question}, cfg)
    while "__interrupt__" in out:  # auto-approve: we are measuring the editor, not the human
        out = graph.invoke(Command(resume={"approved": True}), cfg)
    return out["draft"]


def paired_bootstrap(diffs: list[float], n: int = 2000, seed: int = 0) -> tuple[float, float]:
    rng = random.Random(seed)
    means = sorted(statistics.mean(rng.choices(diffs, k=len(diffs))) for _ in range(n))
    return means[int(0.025 * n)], means[int(0.975 * n) - 1]


def experiment(questions: list[str], research: Callable[[str], str],
               judge: Callable[[str, str], Score], ask: Callable | None = None) -> dict:
    cached = lru_cache(maxsize=None)(research)  # identical notes for both conditions
    diffs = []
    for q in questions:
        base = judge(q, run_brief(q, 0, cached, ask)).score
        refl = judge(q, run_brief(q, 2, cached, ask)).score
        diffs.append(refl - base)
    lo, hi = paired_bootstrap(diffs)
    return {"n": len(diffs), "mean_gain": statistics.mean(diffs), "ci95": (lo, hi), "diffs": diffs}


def default_judge(question: str, brief: str) -> Score:
    from agentkit.structured import ask_native
    return ask_native(Score, "You grade research briefs strictly against a rubric.",
                      f"Rubric: {RUBRIC}\n\nQuestion: {question}\n\nBrief:\n{brief}",
                      llm_model="claude-sonnet-5-5")


if __name__ == "__main__":
    from p3_langgraph.researcher import research_subquestion
    print(experiment(QUESTIONS, research_subquestion, default_judge))
