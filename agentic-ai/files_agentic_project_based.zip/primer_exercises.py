"""Week 0 primer exercises. Fill in the TODOs, then run: uv run python primer/primer_exercises.py
Reference solutions: primer/primer_solutions.py in the main repository (and in the course text)."""
import asyncio
import json
import time
from typing import Annotated, Literal

from pydantic import BaseModel, Field, ValidationError


async def fake_call(name: str, delay: float) -> str:
    await asyncio.sleep(delay)
    return f"{name} done"


async def run_all() -> list[str]:
    # TODO P1: run fake_call("a", 0.3), ("b", 0.2), ("c", 0.1) CONCURRENTLY and return results in that order.
    raise NotImplementedError


def blocking_call() -> str:
    time.sleep(0.2)
    return "blocking done"


async def run_mixed() -> list[str]:
    # TODO P2: run blocking_call() and fake_call("d", 0.2) concurrently without blocking the event loop.
    raise NotImplementedError


# TODO P3: define SearchArgs with: query (str, at least 2 chars, described as keywords),
# limit (int 1-10, default 5) and lang (one of "en", "fr", "de", default "en").
class SearchArgs(BaseModel):
    pass


if __name__ == "__main__":
    t0 = time.perf_counter()
    print(asyncio.run(run_all()), f"{time.perf_counter() - t0:.2f}s  (target: about 0.3s)")
    t0 = time.perf_counter()
    print(asyncio.run(run_mixed()), f"{time.perf_counter() - t0:.2f}s  (target: about 0.2s)")
    print(json.dumps(SearchArgs.model_json_schema(), indent=1))
    try:
        SearchArgs.model_validate({"query": "x", "limit": 50})
        print("FAIL: invalid arguments were accepted")
    except ValidationError as e:
        print("rejected:", [err["loc"][0] for err in e.errors()], "(target: ['query', 'limit'])")
