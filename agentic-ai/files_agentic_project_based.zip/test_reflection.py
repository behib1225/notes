import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from p3_langgraph.reflection_experiment import Score, experiment

def fake_ask(system, prompt):
    if "planner" in system:
        return '{"subquestions": ["A?", "B?"]}'
    if "editor" in system:   # always asks for one revision until the draft says "revised"
        return '{"verdict": "pass", "feedback": ""}' if "revised" in prompt.split("Draft:")[-1] else '{"verdict": "revise", "feedback": "cite more"}'
    return "revised brief" if "Revise the previous draft" in prompt else "first brief"

calls = []
def research(q):
    calls.append(q); return f"note on {q}"

judge = lambda q, brief: Score(score=4 if "revised" in brief else 2, reason="")
r = experiment(["Q1?", "Q2?"], research, judge, ask=fake_ask)
assert r["diffs"] == [2, 2] and r["mean_gain"] == 2, r
assert calls == ["A?", "B?"], calls   # research cached by sub-question text, reused across conditions
print("REFLECTION EXPERIMENT OK", r)
