"""Run the real Anthropic SDK against a mock HTTP transport to check the wire format."""
import json, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import anthropic, httpx2 as httpx
from agentkit.agent import run_agent
from agentkit.llm import AnthropicConversation
from p1_research.tools_basic import calculator

bodies = []
def handler(request: httpx.Request):
    body = json.loads(request.content); bodies.append(body)
    usage = {"input_tokens": 50, "output_tokens": 20, "cache_read_input_tokens": 0, "cache_creation_input_tokens": 0}
    if len(bodies) == 1:
        content = [{"type": "thinking", "thinking": "need calc", "signature": "sig123"},
                   {"type": "tool_use", "id": "toolu_1", "name": "calculator", "input": {"expression": "6*7"}}]
        stop = "tool_use"
    else:
        content = [{"type": "text", "text": "6*7 = 42"}]; stop = "end_turn"
    return httpx.Response(200, json={"id": f"msg_{len(bodies)}", "type": "message", "role": "assistant",
        "model": "claude-haiku-5-5", "content": content, "stop_reason": stop, "stop_sequence": None, "usage": usage})

client = anthropic.Anthropic(api_key="test", http_client=httpx.Client(transport=httpx.MockTransport(handler)))
conv = AnthropicConversation("claude-haiku-5-5", "You are helpful.", client=client)
res = run_agent(conv, [calculator], "What is 6*7?")
print(res.answer, res.steps, res.input_tokens)
second = bodies[1]
print(json.dumps(second["messages"], indent=1))
assert second["messages"][1]["content"][0]["type"] == "thinking"
assert second["messages"][1]["content"][0]["signature"] == "sig123"
print("WIRE OK")
