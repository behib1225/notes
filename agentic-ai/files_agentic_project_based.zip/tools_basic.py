"""Project 1 tools: Wikipedia search/read + a safe calculator."""
from __future__ import annotations

import ast
import html
import operator
import re
from typing import Annotated

import httpx
from pydantic import Field

from agentkit.tools import tool

WIKI_API = "https://en.wikipedia.org/w/api.php"
# Wikimedia asks every client to send a descriptive User-Agent.
HEADERS = {"User-Agent": "agentic-course-research-agent/1.0 (learning project; you@example.com)"}


def _clean(snippet: str) -> str:
    return html.unescape(re.sub(r"<[^>]+>", "", snippet))


@tool
def search_wikipedia(
    query: Annotated[str, Field(description="Keywords, e.g. 'Marie Curie Nobel Prize'. Not a full question.")],
    limit: Annotated[int, Field(ge=1, le=10, description="Number of results")] = 5,
) -> list[dict]:
    """Search English Wikipedia. Returns page titles with short snippets.
    Use this first to find the exact page title, then call read_wikipedia_page."""
    r = httpx.get(WIKI_API, params={"action": "query", "list": "search", "srsearch": query,
                                    "srlimit": limit, "format": "json"},
                  headers=HEADERS, timeout=20)
    r.raise_for_status()
    hits = r.json()["query"]["search"]
    if not hits:
        return [{"note": f"No results for '{query}'. Try fewer or different keywords."}]
    return [{"title": h["title"], "snippet": _clean(h["snippet"])} for h in hits]


@tool
def read_wikipedia_page(
    title: Annotated[str, Field(description="Exact page title from search_wikipedia")],
    max_chars: Annotated[int, Field(ge=500, le=8000)] = 4000,
) -> str:
    """Read the plain-text content of a Wikipedia page (the beginning, up to max_chars)."""
    r = httpx.get(WIKI_API, params={"action": "query", "prop": "extracts", "explaintext": 1,
                                    "titles": title, "redirects": 1, "format": "json"},
                  headers=HEADERS, timeout=20)
    r.raise_for_status()
    page = next(iter(r.json()["query"]["pages"].values()))
    if "missing" in page:
        raise ValueError(f"No page titled '{title}'. Use search_wikipedia to find the exact title.")
    return page.get("extract", "")[:max_chars]


_OPS = {ast.Add: operator.add, ast.Sub: operator.sub, ast.Mult: operator.mul,
        ast.Div: operator.truediv, ast.Pow: operator.pow, ast.Mod: operator.mod,
        ast.USub: operator.neg, ast.UAdd: operator.pos}


def _eval(node: ast.AST) -> float:
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _OPS:
        if isinstance(node.op, ast.Pow) and abs(_eval(node.right)) > 100:
            raise ValueError("Exponent too large")
        return _OPS[type(node.op)](_eval(node.left), _eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _OPS:
        return _OPS[type(node.op)](_eval(node.operand))
    raise ValueError("Only numbers and + - * / ** % ( ) are allowed")


@tool
def calculator(expression: Annotated[str, Field(description="Arithmetic only, e.g. '(2024-1867)*12'")]) -> str:
    """Evaluate an arithmetic expression exactly. Use it for any date or number math."""
    return str(_eval(ast.parse(expression, mode="eval").body))
