"""Expose tools from an MCP server to our agent loop."""
from __future__ import annotations

import json
from typing import Any

from agentkit.llm import ToolSpec


class MCPTool:
    def __init__(self, client: Any, mcp_tool: Any, prefix: str = "", requires_approval: bool = False):
        self.client, self.remote_name = client, mcp_tool.name
        self.name = prefix + mcp_tool.name
        self.description = mcp_tool.description or ""
        self.parameters = mcp_tool.input_schema
        self.requires_approval = requires_approval

    def spec(self) -> ToolSpec:
        return ToolSpec(self.name, self.description, self.parameters)

    async def arun(self, arguments: dict[str, Any]) -> tuple[str, bool]:
        try:
            result = await self.client.call_tool(self.remote_name, arguments)
        except Exception as e:  # protocol/transport errors
            return f"MCP call failed: {type(e).__name__}: {e}", True
        parts = [c.text for c in result.content if getattr(c, "type", "") == "text"]
        text = "\n".join(parts)
        if not text and result.structured_content is not None:
            text = json.dumps(result.structured_content)
        return text[:8000], bool(result.is_error)


async def load_mcp_tools(client: Any, prefix: str = "",
                         needs_approval: set[str] | None = None) -> list[MCPTool]:
    listing = await client.list_tools()
    needs_approval = needs_approval or set()
    return [MCPTool(client, t, prefix, t.name in needs_approval) for t in listing.tools]
