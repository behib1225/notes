"""Wraps the Project 1 agent so LangGraph can call it as a sub-agent."""
from agentkit.agent import run_agent
from agentkit.llm import make_conversation
from p1_research.tools_basic import calculator, read_wikipedia_page, search_wikipedia

SYSTEM = ("You are a careful research assistant. Use the tools to answer one sub-question. "
          "Return 3-6 factual bullet points, each ending with its source as (Wikipedia: <title>). "
          "Say 'unknown' rather than guessing.")


def research_subquestion(q: str) -> str:
    res = run_agent(make_conversation(SYSTEM), [search_wikipedia, read_wikipedia_page, calculator],
                    q, max_steps=6)
    return res.answer
