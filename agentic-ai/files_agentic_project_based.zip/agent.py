"""The agent loop, written from scratch (sync in week 1, async in week 2)."""
from __future__ import annotations

import asyncio
import inspect
from dataclasses import dataclass, field
from typing import Any, Callable

from agentkit.llm import Conversation, Turn
from agentkit.tools import Tool
from agentkit.tracing import turn_cost_usd

STOP_NOW = {"refusal", "model_context_window_exceeded"}  # end the run, do not retry
FORCE_FINAL = ("Stop using tools now. Give your best final answer from what you have, "
               "and say clearly what is still uncertain.")


@dataclass
class AgentResult:
    answer: str
    steps: int
    stop: str  # "final" | "max_steps" | "token_budget" | "refusal" | "model_context_window_exceeded"
    tool_log: list[dict[str, Any]] = field(default_factory=list)
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    cost_usd: float = 0.0
    latency_s: float = 0.0


def _account(res: AgentResult, conv: Conversation, turn: Turn, step: int, emit) -> None:
    res.input_tokens += turn.input_tokens
    res.output_tokens += turn.output_tokens
    res.cache_read_tokens += turn.cache_read_tokens
    res.cache_write_tokens += turn.cache_write_tokens
    cost = turn_cost_usd(conv.model, turn.input_tokens, turn.output_tokens,
                         turn.cache_read_tokens, turn.cache_write_tokens)
    res.cost_usd += cost
    res.latency_s += turn.latency_s
    emit("llm", {"step": step, "model": conv.model, "stop_reason": turn.stop_reason,
                 "input_tokens": turn.input_tokens, "cache_read_tokens": turn.cache_read_tokens,
                 "cache_write_tokens": turn.cache_write_tokens, "output_tokens": turn.output_tokens,
                 "cost_usd": round(cost, 6), "latency_s": round(turn.latency_s, 3),
                 "text": turn.text[:500],
                 "tool_calls": [(c.name, c.arguments) for c in turn.tool_calls]})


def run_agent(conv: Conversation, tools: list[Tool], task: str, max_steps: int = 10,
              token_budget: int = 300_000,
              approve: Callable[[str, dict], bool] | None = None,
              on_event: Callable[[str, dict], None] | None = None) -> AgentResult:
    registry = {t.name: t for t in tools}
    specs = [t.spec() for t in tools]
    emit = on_event or (lambda kind, data: None)
    res = AgentResult(answer="", steps=0, stop="final")
    conv.add_user(task)

    for step in range(1, max_steps + 1):
        turn = conv.complete(specs)
        res.steps = step
        _account(res, conv, turn, step, emit)
        if turn.stop_reason in STOP_NOW:
            res.answer, res.stop = turn.text, turn.stop_reason
            return res
        if not turn.tool_calls:
            res.answer = turn.text
            return res

        results = []
        for call in turn.tool_calls:
            t = registry.get(call.name)
            if t is None:
                out, err = f"Unknown tool '{call.name}'. Available: {sorted(registry)}", True
            elif t.requires_approval and not (approve and approve(call.name, call.arguments)):
                out, err = "The action was not approved. Do not retry it; explain instead.", True
            else:
                out, err = t.run(call.arguments)
            res.tool_log.append({"step": step, "tool": call.name, "args": call.arguments,
                                 "is_error": err, "output_preview": out[:200]})
            emit("tool", res.tool_log[-1])
            results.append((call.id, out, err))
        conv.add_tool_results(results)

        if res.input_tokens + res.output_tokens > token_budget:
            res.stop = "token_budget"
            break
    else:
        res.stop = "max_steps"

    # Out of steps or budget: force a final answer with tools disabled.
    conv.add_user(FORCE_FINAL)
    turn = conv.complete(specs, allow_tools=False)
    _account(res, conv, turn, res.steps + 1, emit)
    res.answer = turn.text
    return res


async def arun_agent(conv: Conversation, tools: list[Any], task: str, max_steps: int = 10,
                     token_budget: int = 300_000, tool_timeout_s: float = 60.0,
                     approve: Callable[[str, dict], Any] | None = None,
                     on_event: Callable[[str, dict], None] | None = None) -> AgentResult:
    """Async loop. Tools need .name, .spec(), .requires_approval and async .arun(args).
    Read-only tool calls from one turn run concurrently; calls that need approval
    (side effects) run one at a time, in order. Every call has a timeout."""
    registry = {t.name: t for t in tools}
    specs = [t.spec() for t in tools]
    emit = on_event or (lambda kind, data: None)
    res = AgentResult(answer="", steps=0, stop="final")
    conv.add_user(task)

    async def is_approved(call) -> bool:
        if approve is None:
            return False
        if inspect.iscoroutinefunction(approve):
            return bool(await approve(call.name, call.arguments))
        return bool(await asyncio.to_thread(approve, call.name, call.arguments))  # e.g. input()

    async def execute(call) -> tuple[str, bool]:
        t = registry.get(call.name)
        if t is None:
            return f"Unknown tool '{call.name}'. Available: {sorted(registry)}", True
        if getattr(t, "requires_approval", False) and not await is_approved(call):
            return "The action was not approved. Do not retry it; explain instead.", True
        try:
            return await asyncio.wait_for(t.arun(call.arguments), timeout=tool_timeout_s)
        except asyncio.TimeoutError:
            return f"Tool '{call.name}' timed out after {tool_timeout_s:.0f}s.", True

    for step in range(1, max_steps + 1):
        turn = await asyncio.to_thread(conv.complete, specs)
        res.steps = step
        _account(res, conv, turn, step, emit)
        if turn.stop_reason in STOP_NOW:
            res.answer, res.stop = turn.text, turn.stop_reason
            return res
        if not turn.tool_calls:
            res.answer = turn.text
            return res

        outputs: dict[str, tuple[str, bool]] = {}
        read_only = [c for c in turn.tool_calls
                     if not getattr(registry.get(c.name), "requires_approval", False)]
        side_effects = [c for c in turn.tool_calls if c not in read_only]
        for call, out in zip(read_only, await asyncio.gather(*(execute(c) for c in read_only))):
            outputs[call.id] = out
        for call in side_effects:  # sequential: no two refunds racing each other
            outputs[call.id] = await execute(call)

        results = []
        for call in turn.tool_calls:  # report results in the model's original order
            out, err = outputs[call.id]
            res.tool_log.append({"step": step, "tool": call.name, "args": call.arguments,
                                 "is_error": err, "output_preview": out[:200]})
            emit("tool", res.tool_log[-1])
            results.append((call.id, out, err))
        conv.add_tool_results(results)
        if res.input_tokens + res.output_tokens > token_budget:
            res.stop = "token_budget"
            break
    else:
        res.stop = "max_steps"

    conv.add_user(FORCE_FINAL)
    turn = await asyncio.to_thread(conv.complete, specs, False)
    _account(res, conv, turn, res.steps + 1, emit)
    res.answer = turn.text
    return res
