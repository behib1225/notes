"""Project 1 entry point: uv run python -m p1_research.run "your question" """
import sys

from agentkit.agent import run_agent
from agentkit.llm import make_conversation
from p1_research.tools_basic import calculator, read_wikipedia_page, search_wikipedia

SYSTEM = """You are a research assistant that answers questions using Wikipedia.

How to work:
1. Break the question into the facts you need.
2. Use search_wikipedia to find page titles, then read_wikipedia_page to read them.
3. Use calculator for every arithmetic step, including date differences.
4. Stop searching once you can answer. Prefer 2-6 tool calls in total.

Answer format:
- A direct answer in 1-3 sentences first.
- Then "Sources:" with the Wikipedia page titles you used.
- If sources disagree or a fact is missing, say so. Never invent facts."""


def show(kind: str, data: dict) -> None:
    if kind == "llm" and data["text"]:
        print(f"[step {data['step']}] model: {data['text'][:200]}")
    if kind == "tool":
        flag = " (ERROR)" if data["is_error"] else ""
        print(f"[step {data['step']}] tool {data['tool']}({data['args']}){flag}")


if __name__ == "__main__":
    question = " ".join(sys.argv[1:]) or "How many years passed between the first ascent of Mount Everest and the first crewed Moon landing?"
    result = run_agent(make_conversation(SYSTEM),
                       [search_wikipedia, read_wikipedia_page, calculator],
                       question, max_steps=10, on_event=show)
    print("\n=== ANSWER ===\n" + result.answer)
    print(f"\n[steps={result.steps} stop={result.stop} "
          f"tokens in/out={result.input_tokens}/{result.output_tokens} latency={result.latency_s:.1f}s]")
