"""Download Wikipedia articles into p2_mcp/corpus/ as the knowledge base."""
import re
from pathlib import Path

import httpx

TITLES = ["Large language model", "Transformer (deep learning architecture)",
          "Retrieval-augmented generation", "Reinforcement learning from human feedback",
          "Prompt engineering", "Intelligent agent", "Vector database", "Word embedding",
          "Attention (machine learning)", "BERT (language model)", "Fine-tuning (deep learning)",
          "Hallucination (artificial intelligence)", "Tf–idf", "Okapi BM25", "Knowledge graph"]
OUT = Path(__file__).parent / "corpus"
HEADERS = {"User-Agent": "agentic-course-kb/1.0 (learning project; you@example.com)"}

OUT.mkdir(exist_ok=True)
for title in TITLES:
    r = httpx.get("https://en.wikipedia.org/w/api.php", headers=HEADERS, timeout=30, params={
        "action": "query", "prop": "extracts", "explaintext": 1, "titles": title,
        "redirects": 1, "format": "json"})
    page = next(iter(r.json()["query"]["pages"].values()))
    slug = re.sub(r"[^a-z0-9]+", "_", page["title"].lower()).strip("_")
    (OUT / f"{slug}.md").write_text(f"# {page['title']}\n\n{page.get('extract', '')}", encoding="utf-8")
    print("saved", slug, len(page.get("extract", "")))
