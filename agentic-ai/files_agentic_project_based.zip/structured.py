"""Get JSON that matches a Pydantic model.

On Claude, use native structured outputs (the SDK's messages.parse), which constrain
decoding to the schema. On other providers, fall back to prompt + validate + retry.
Validation with Pydantic happens either way."""
from __future__ import annotations

import json
import os
import re
from typing import Callable, TypeVar

from pydantic import BaseModel, ValidationError

from agentkit.llm import make_conversation

M = TypeVar("M", bound=BaseModel)


def ask_text(system: str, prompt: str) -> str:
    """One-shot call: no tools, no history."""
    conv = make_conversation(system)
    conv.add_user(prompt)
    return conv.complete([]).text


def ask_native(model: type[M], system: str, prompt: str, llm_model: str | None = None,
               client=None) -> M:
    """Claude native structured output via the Anthropic SDK's messages.parse."""
    if client is None:
        import anthropic
        client = anthropic.Anthropic(max_retries=4, timeout=120.0)
    resp = client.messages.parse(
        model=llm_model or os.getenv("LLM_MODEL", "claude-haiku-5-5"), max_tokens=4000,
        system=system, messages=[{"role": "user", "content": prompt}], output_format=model)
    if resp.parsed_output is None:  # e.g. refusal or max_tokens
        raise ValueError(f"No parsed output (stop_reason={resp.stop_reason})")
    return resp.parsed_output


def _extract_json(text: str) -> str:
    fenced = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if fenced:
        return fenced.group(1)
    start = min([i for i in (text.find("{"), text.find("[")) if i != -1], default=-1)
    return text[start:] if start != -1 else text


def ask_model(model: type[M], system: str, prompt: str,
              ask: Callable[[str, str], str] | None = None, retries: int = 2) -> M:
    """Native path when no custom `ask` is given and the provider is Anthropic;
    otherwise prompt for JSON, validate, and retry with the validation error."""
    if ask is None and os.getenv("LLM_PROVIDER", "anthropic") == "anthropic":
        return ask_native(model, system, prompt)
    ask = ask or ask_text
    schema = json.dumps(model.model_json_schema())
    full = f"{prompt}\n\nRespond with ONLY a JSON object matching this JSON Schema:\n{schema}"
    last_err = ""
    for _ in range(retries + 1):
        raw = ask(system, full if not last_err else
                  f"{full}\n\nYour previous reply was invalid: {last_err}\nReturn corrected JSON only.")
        try:
            return model.model_validate_json(_extract_json(raw).strip())
        except (ValidationError, ValueError) as e:
            last_err = str(e)[:500]
    raise ValueError(f"Model never produced valid {model.__name__}: {last_err}")
