# Agentic AI Engineering course: reference solutions

Unit-tested on 2026-11-12 (with scripted fake models, a mock HTTP transport and
in-memory/stdio/HTTP MCP servers; NOT end-to-end against live models) with anthropic 2.8.0, openai 3.49.0, mcp 2.3.0, langgraph 1.2.20,
scikit-learn 1.9.1, pydantic 2.14.3, Python 3.12.

    uv sync
    cp .env.example .env          # add your key, or switch to Ollama
    uv run python -m p2_mcp.fetch_corpus

Run (always from the repo root, as modules):

    uv run --env-file .env python -m p1_research.run "your question"
    uv run --env-file .env python -m p2_mcp.mcp_agent "How does BM25 differ from TF-IDF?"
    uv run --env-file .env python -m p3_langgraph.report_graph "How did the transistor change computing?"
    uv run --env-file .env python -m capstone.support_agent --as dana@example.com "Refund A1001, the tent leaks"
    uv run --env-file .env python -m capstone.evals 5
    uv run python -m p2_mcp.kb_http     # knowledge base over Streamable HTTP at :8000/mcp

Tests (no API key needed; test_week2_server needs a corpus first):

    uv run python tests/test_week1.py
    uv run python tests/test_anthropic_wire.py
    uv run python tests/test_week2_server.py
    uv run python tests/test_week3.py
    uv run python tests/test_capstone.py
    uv run python tests/test_evals.py
    uv run python tests/test_native_structured.py
    uv run python tests/test_reflection.py

Starter workspace: `starter/` is this repository with the key functions replaced by
TODO stubs. Work there and run the same tests (see starter/STARTER.md).
Week 0 primer: primer/primer_solutions.py (exercises in starter/primer/).

Try each step yourself before reading these solutions.
