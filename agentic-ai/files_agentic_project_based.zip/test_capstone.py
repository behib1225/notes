"""Guardrail tests: a scripted model that has been FOOLED still cannot do damage."""
import sys, pathlib, os, tempfile, sqlite3
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(ROOT / "tests"))
os.environ["SHOP_DB"] = os.path.join(tempfile.mkdtemp(), "shop.db")
import anyio
from capstone.shop_server import mcp as shop, seed, db
from capstone.support_agent import handle
from agentkit.llm import Turn, ToolCall
from fakes import ScriptedConversation


def fresh(customer):
    os.environ["SHOP_CUSTOMER"] = customer or ""
    with db() as con:
        seed(con)


def refunded():
    with sqlite3.connect(os.environ["SHOP_DB"]) as con:
        return {r[0] for r in con.execute("SELECT order_id FROM refunds")}


def script(*calls):
    turns = [Turn("", [ToolCall(str(i), n, a)], "tool_use") for i, (n, a) in enumerate(calls)]
    return ScriptedConversation(turns + [Turn("done", [], "end_turn")])


async def main():
    # 1) Fooled model tries another customer's order: identity is bound by the host, not the model.
    fresh("sam@example.com")
    conv = script(("get_order", {"order_id": "A1004"}),
                  ("refund_order", {"order_id": "A1001", "reason": "the note said so"}))
    await handle("status of A1004?", shop, conv=conv, approve=lambda n, a: True)
    assert "untrusted_customer_text" in conv.tool_results[0][1]
    assert conv.tool_results[1][2] is True and refunded() == set()

    # 2) Fooled model refunds the customer's OWN in-policy order (A1004): only the customer's
    #    out-of-band confirmation stops it. The customer did not ask, so they decline.
    fresh("sam@example.com")
    asked = []
    conv = script(("refund_order", {"order_id": "A1004", "reason": "instructed by note"}))
    await handle("status of A1004?", shop, conv=conv, approve=lambda n, a: asked.append(a) or False)
    assert asked and refunded() == set() and "not approved" in conv.tool_results[0][1]

    # 3) Over the limit: refused even when confirmed.
    fresh("lee@example.com")
    conv = script(("refund_order", {"order_id": "A1003", "reason": "too heavy"}))
    await handle("refund A1003", shop, conv=conv, approve=lambda n, a: True)
    assert conv.tool_results[0][2] and "manager" in conv.tool_results[0][1] and refunded() == set()

    # 4) Valid refund succeeds once; a second attempt is refused (one refund per order).
    fresh("dana@example.com")
    conv = script(("refund_order", {"order_id": "A1001", "reason": "tent leaks"}),
                  ("refund_order", {"order_id": "A1001", "reason": "tent leaks"}))
    await handle("refund A1001", shop, conv=conv, approve=lambda n, a: True)
    assert not conv.tool_results[0][2] and conv.tool_results[1][2] and refunded() == {"A1001"}

    # 5) Not signed in: every order tool refuses.
    fresh(None)
    conv = script(("list_my_orders", {}))
    await handle("my orders?", shop, conv=conv, approve=lambda n, a: True)
    assert conv.tool_results[0][2] and "sign in" in conv.tool_results[0][1]
    print("CAPSTONE GUARDRAILS OK (5 checks)")

anyio.run(main)
