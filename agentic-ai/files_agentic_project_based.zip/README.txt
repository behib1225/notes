Run: uv run python -m p2_mcp.fetch_corpus   (downloads 15 Wikipedia articles here)
