import sys, pathlib
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import anyio
from mcp import Client, StdioServerParameters
from p2_mcp.kb_server import mcp as kb


async def main():
    async with Client(kb) as client:                       # in memory
        names = [t.name for t in (await client.list_tools()).tools]
        assert set(names) == {"search_docs", "read_doc", "list_docs"}
        r = await client.call_tool("search_docs", {"query": "attention", "k": 2})
        assert not r.is_error and r.content[0].type == "text"
        r = await client.call_tool("read_doc", {"doc_id": "nope"})
        assert r.is_error and "list_docs" in r.content[0].text
    params = StdioServerParameters(command=sys.executable,
                                   args=[str(ROOT / "p2_mcp" / "kb_server.py")])
    async with Client(params) as client:                   # real subprocess
        r = await client.call_tool("list_docs", {})
        print("stdio OK, protocol", client.protocol_version)

anyio.run(main)
