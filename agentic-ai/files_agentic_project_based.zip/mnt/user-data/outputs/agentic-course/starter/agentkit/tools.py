"""Turn plain Python functions into tools with JSON Schema + validation."""
from __future__ import annotations

import inspect
import json
from typing import Any, Callable, get_type_hints

from pydantic import ValidationError, create_model

from agentkit.llm import ToolSpec

MAX_TOOL_OUTPUT_CHARS = 8000


class Tool:
    def __init__(self, fn: Callable[..., Any], name: str | None = None,
                 description: str | None = None, requires_approval: bool = False):
        self.fn = fn
        self.name = name or fn.__name__
        self.description = description or inspect.getdoc(fn) or ""
        self.requires_approval = requires_approval
        hints = get_type_hints(fn, include_extras=True)
        fields: dict[str, Any] = {}
        for pname, p in inspect.signature(fn).parameters.items():
            default = ... if p.default is inspect.Parameter.empty else p.default
            fields[pname] = (hints.get(pname, str), default)
        self.args_model = create_model(f"{self.name}_args", **fields)
        schema = self.args_model.model_json_schema()
        schema.pop("title", None)
        for prop in schema.get("properties", {}).values():
            prop.pop("title", None)
        self.parameters = schema

    def spec(self) -> ToolSpec:
        return ToolSpec(self.name, self.description, self.parameters)

    def run(self, arguments: dict[str, Any]) -> tuple[str, bool]:
        """Return (output_text, is_error). Never raises: errors go back to the model."""
        # TODO: Week 1 step 1: validate with self.args_model, call self.fn, JSON-encode non-strings, truncate to MAX_TOOL_OUTPUT_CHARS, and return (text, is_error). Never raise.
        raise NotImplementedError("TODO: see the comment above")

    async def arun(self, arguments: dict[str, Any]) -> tuple[str, bool]:
        """Async wrapper, used by the async loop in week 2."""
        import asyncio
        return await asyncio.to_thread(self.run, arguments)


def tool(fn: Callable[..., Any] | None = None, **kwargs: Any):
    """Decorator: @tool or @tool(requires_approval=True)."""
    if fn is None:
        return lambda f: Tool(f, **kwargs)
    return Tool(fn, **kwargs)
