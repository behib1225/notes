r"""Project 3: a research-report pipeline in LangGraph 1.2.x.

plan -> (fan-out) research x N -> write -> review --revise--> write
                                                  \--pass--> human_approval --> END
"""
from __future__ import annotations

import operator
from typing import Annotated, Callable, Literal, TypedDict

from langgraph.checkpoint.memory import InMemorySaver
from langgraph.graph import END, START, StateGraph
from langgraph.types import Command, Send, interrupt
from pydantic import BaseModel, Field

from agentkit.structured import ask_model, ask_text

MAX_REVISIONS = 2


class Plan(BaseModel):
    subquestions: list[str] = Field(min_length=2, max_length=4)


class Review(BaseModel):
    verdict: Literal["pass", "revise"]
    feedback: str


class ReportState(TypedDict, total=False):
    question: str
    subquestions: list[str]
    notes: Annotated[list[str], operator.add]  # reducer: parallel branches append
    draft: str
    feedback: str
    revisions: int
    approved: bool


class ResearchTask(TypedDict):
    subquestion: str


def build_graph(ask: Callable[[str, str], str] | None = None,
                research: Callable[[str], str] | None = None,
                checkpointer=None, max_revisions: int = MAX_REVISIONS):
    if research is None:
        from p3_langgraph.researcher import research_subquestion as research
    write_text = ask or ask_text  # free text; JSON nodes pass `ask` through (None = native)

    def plan(state: ReportState) -> dict:
        p = ask_model(Plan, "You are a research planner.",
                      f"Split this question into 2-4 independent sub-questions "
                      f"that can each be answered from Wikipedia:\n{state['question']}", ask=ask)
        return {"subquestions": p.subquestions, "revisions": 0}

    def fan_out(state: ReportState) -> list[Send]:
        # TODO: Week 3 step 3: return one Send('research', {'subquestion': q}) per sub-question.
        raise NotImplementedError("TODO: see the comment above")

    def research_node(task: ResearchTask) -> dict:
        return {"notes": [f"## {task['subquestion']}\n{research(task['subquestion'])}"]}

    def write(state: ReportState) -> dict:
        fb = state.get("feedback", "")
        draft = write_text("You write concise, well-cited research briefs in Markdown.",
                    f"Question: {state['question']}\n\nResearch notes:\n" + "\n\n".join(state["notes"])
                    + "\n\nWrite a brief of at most 300 words. Keep every source citation from the notes."
                    + (f"\n\nRevise the previous draft to address this feedback:\n{fb}\n\n"
                       f"Previous draft:\n{state.get('draft', '')}" if fb else ""))
        return {"draft": draft}

    def review(state: ReportState) -> dict:
        r = ask_model(Review, "You are a strict editor. Check accuracy against the notes, "
                      "citations for every claim, and that the question is answered.",
                      f"Question: {state['question']}\n\nNotes:\n" + "\n\n".join(state["notes"])
                      + f"\n\nDraft:\n{state['draft']}", ask=ask)
        return {"feedback": r.feedback if r.verdict == "revise" else "",
                "revisions": state.get("revisions", 0) + (r.verdict == "revise")}

    def route_review(state: ReportState) -> str:
        # TODO: Week 3 step 3: go back to 'write' while there is feedback and revisions <= max_revisions, otherwise to 'human_approval'.
        raise NotImplementedError("TODO: see the comment above")

    def human_approval(state: ReportState) -> Command[Literal["write", "__end__"]]:
        # TODO: Week 3 step 3: call interrupt({...draft...}); on approval return Command(goto=END, ...), otherwise Command(goto='write', update={'feedback': comment}).
        raise NotImplementedError("TODO: see the comment above")

    g = StateGraph(ReportState)
    g.add_node("plan", plan)
    g.add_node("research", research_node)
    g.add_node("write", write)
    g.add_node("review", review)
    g.add_node("human_approval", human_approval)
    g.add_edge(START, "plan")
    g.add_conditional_edges("plan", fan_out, ["research"])
    g.add_edge("research", "write")
    g.add_edge("write", "review")
    g.add_conditional_edges("review", route_review, ["write", "human_approval"])
    return g.compile(checkpointer=checkpointer or InMemorySaver())


if __name__ == "__main__":
    import json, sys, uuid
    graph = build_graph()
    config = {"configurable": {"thread_id": str(uuid.uuid4())}}
    q = " ".join(sys.argv[1:]) or "How did the invention of the transistor change computing?"
    out = graph.invoke({"question": q}, config)
    while "__interrupt__" in out:
        print("\n=== DRAFT FOR REVIEW ===\n" + out["__interrupt__"][0].value["draft"])
        ans = input("\nApprove? [y / or type feedback]: ").strip()
        decision = {"approved": True} if ans.lower() in {"y", "yes", ""} else {"approved": False, "comment": ans}
        out = graph.invoke(Command(resume=decision), config)
    print("\n=== FINAL ===\n" + out["draft"])
