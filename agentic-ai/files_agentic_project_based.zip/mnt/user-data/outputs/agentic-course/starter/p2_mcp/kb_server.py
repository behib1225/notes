"""Project 2: a knowledge-base MCP server (MCP Python SDK v2, spec 2026-07-28).

Run standalone:   uv run python p2_mcp/kb_server.py          (stdio transport)
Inspect it:       npx -y @modelcontextprotocol/inspector uv run python p2_mcp/kb_server.py
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path
from typing import Annotated

from mcp.server import MCPServer
from mcp.server.mcpserver.exceptions import ToolError  # message is shown to the model
from pydantic import Field
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel

CORPUS_DIR = Path(os.getenv("KB_DIR", Path(__file__).parent / "corpus"))
CHUNK_CHARS, OVERLAP = 1000, 200


@dataclass
class Chunk:
    doc_id: str
    start: int
    text: str


def chunk_text(doc_id: str, text: str) -> list[Chunk]:
    chunks, i = [], 0
    while i < len(text):
        chunks.append(Chunk(doc_id, i, text[i:i + CHUNK_CHARS]))
        i += CHUNK_CHARS - OVERLAP
    return chunks


class Index:
    def __init__(self, corpus_dir: Path):
        self.docs = {p.stem: p.read_text(encoding="utf-8")
                     for p in sorted(corpus_dir.glob("*")) if p.suffix in {".md", ".txt"}}
        self.chunks = [c for d, t in self.docs.items() for c in chunk_text(d, t)]
        self.vec = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
        self.matrix = self.vec.fit_transform([c.text for c in self.chunks]) if self.chunks else None

    def search(self, query: str, k: int) -> list[dict]:
        # TODO: Week 2 step 2: transform the query with self.vec, score with linear_kernel, return the top k chunks with score > 0 as dicts with doc_id, start, score, text.
        raise NotImplementedError("TODO: see the comment above")


INDEX = Index(CORPUS_DIR)
mcp = MCPServer("knowledge-base", instructions=(
    "Search and read a local document collection. Search first, then read the "
    "most relevant passages. Cite doc_id for every fact you use."))


@mcp.tool()
def search_docs(
    query: Annotated[str, Field(description="Keywords to look for, e.g. 'transformer attention complexity'")],
    k: Annotated[int, Field(ge=1, le=10, description="How many passages to return")] = 5,
) -> list[dict]:
    """Keyword (TF-IDF) search over the knowledge base. Returns the best passages
    with doc_id and start offset. Rephrase with synonyms if results look weak."""
    hits = INDEX.search(query, k)
    return hits or [{"note": "No matches. Try different keywords or call list_docs."}]


@mcp.tool()
def read_doc(
    doc_id: Annotated[str, Field(description="A doc_id from search_docs or list_docs")],
    start: Annotated[int, Field(ge=0, description="Character offset to start reading")] = 0,
    max_chars: Annotated[int, Field(ge=200, le=6000)] = 3000,
) -> str:
    """Read part of one document. Use 'start' from a search hit to read around it."""
    # TODO: Week 2 step 2: raise ToolError for an unknown doc_id (mention list_docs); otherwise return '[doc_id chars a-b of n]' followed by the text slice.
    raise NotImplementedError("TODO: see the comment above")


@mcp.tool()
def list_docs() -> list[dict]:
    """List every document id with its length in characters."""
    return [{"doc_id": d, "chars": len(t)} for d, t in INDEX.docs.items()]


@mcp.resource("kb://docs/{doc_id}")
def doc_resource(doc_id: str) -> str:
    """Full text of a document, for clients that load context directly."""
    return INDEX.docs[doc_id]


if __name__ == "__main__":
    mcp.run()  # stdio by default
