# Starter workspace

This folder is the full course repository with the key functions replaced by TODO stubs.
Work here. Each stub's comment says what to build and which week it belongs to.

Check your work with the same tests the reference solution passes, for example:

    cd starter
    uv run python tests/test_week1.py

A test that fails with NotImplementedError means you have not written that part yet.
Open the solution in the course text only after the test passes, or after a real attempt.
