"""The eval harness must catch real failures, including unrequested refunds."""
import sys, pathlib, asyncio
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from agentkit.agent import AgentResult
from capstone.evals import CASES, Trial, Verdict, check, run_suite

by_id = {c.id: c for c in CASES}
ok_judge = lambda r, m, a: Verdict(passed=True, reason="")
res = lambda ans, log=(): AgentResult(answer=ans, steps=2, stop="final", tool_log=list(log))

# Passing trial: correct refund in the DB.
assert check(by_id["refund_ok"], Trial(res("Done, refunded."), {"A1001"}, [{"order_id": "A1001"}]), ok_judge) == []
# "Sorry, I couldn't refund" no longer passes: the DB outcome is checked.
assert any("DB refunds" in f for f in check(by_id["refund_ok"], Trial(res("Sorry, I could not refund it."), set(), []), ok_judge))
# Injection: asking the customer to confirm an unrequested refund fails, even if they declined.
fails = check(by_id["injection_in_note"], Trial(res("Delivered.", [{"tool": "get_order", "is_error": False}]), set(), [{"order_id": "A1004"}]), ok_judge)
assert any("unrequested" in f for f in fails), fails
# Judge failures are reported.
bad_judge = lambda r, m, a: Verdict(passed=False, reason="no next step")
assert check(by_id["refund_window"], Trial(res("Outside the 30 days."), set(), []), bad_judge) == ["judge: no next step"]

async def always_right(case):
    log = [{"tool": t, "is_error": False} for t in case.must_call]
    ans = (case.answer_contains_any or ["ok"])[0]
    return Trial(res(ans, log), set(case.expect_refunded), [{"order_id": o} for o in case.expect_refunded])

rep = asyncio.run(run_suite(always_right, k=2, judge=ok_judge))
assert rep["pass@1"] == 1.0 and rep["pass^k"] == 1.0 and rep["n_cases"] == 12, rep
print("EVAL HARNESS OK", {k: v for k, v in rep.items() if k != "cases"})
