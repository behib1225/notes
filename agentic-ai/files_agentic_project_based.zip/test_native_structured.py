"""Check the native structured-output request shape with the real SDK and a mock transport."""
import sys, pathlib, json
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import anthropic, httpx2
from pydantic import BaseModel
from agentkit.structured import ask_native

class Verdict(BaseModel):
    passed: bool
    reason: str

bodies = []
def handler(req):
    bodies.append(json.loads(req.content))
    return httpx2.Response(200, json={"id": "m", "type": "message", "role": "assistant", "model": "claude-haiku-5-5",
        "content": [{"type": "text", "text": "{\"passed\": true, \"reason\": \"meets rubric\"}"}],
        "stop_reason": "end_turn", "stop_sequence": None, "usage": {"input_tokens": 5, "output_tokens": 5}})
client = anthropic.Anthropic(api_key="t", http_client=httpx2.Client(transport=httpx2.MockTransport(handler)))
v = ask_native(Verdict, "sys", "grade", llm_model="claude-haiku-5-5", client=client)
assert v.passed is True
print("request output_config:", json.dumps(bodies[0].get("output_config"))[:200])
print("NATIVE STRUCTURED OK")
