"""JSONL tracer + cost accounting. Swap for OpenTelemetry/Langfuse in production."""
from __future__ import annotations

import json
import time
import uuid
from pathlib import Path

# USD per million tokens, checked 2026-11-10 on platform.claude.com (prompt caching page):
# (input, output, 5-minute cache write, cache read). Haiku 5.5 has a higher tier for
# prompts over 100k tokens. Local models cost $0 in this table.
PRICES = {
    "claude-haiku-5-5": {"tiers": [(100_000, (0.10, 0.50, 0.125, 0.01)),
                                   (None, (0.50, 2.50, 0.625, 0.05))]},
    "claude-sonnet-5-5": {"tiers": [(None, (2.00, 10.00, 2.50, 0.10))]},
    "claude-opus-5-5": {"tiers": [(None, (4.00, 20.00, 5.00, 0.20))]},
}


def turn_cost_usd(model: str, input_tokens: int, output_tokens: int,
                  cache_read: int = 0, cache_write: int = 0) -> float:
    """Cost of ONE model call. input_tokens is the total prompt (incl. cache reads/writes)."""
    entry = PRICES.get(model)
    if entry is None:
        return 0.0
    for limit, prices in entry["tiers"]:
        if limit is None or input_tokens <= limit:
            p_in, p_out, p_write, p_read = prices
            break
    uncached = max(input_tokens - cache_read - cache_write, 0)
    return (uncached * p_in + output_tokens * p_out + cache_write * p_write
            + cache_read * p_read) / 1_000_000


class Tracer:
    """Callable that matches the agent's on_event signature and appends JSON lines."""

    def __init__(self, path: str | Path = "traces.jsonl", run_id: str | None = None):
        self.path, self.run_id = Path(path), run_id or uuid.uuid4().hex[:12]
        self.t0 = time.time()

    def __call__(self, kind: str, data: dict) -> None:
        rec = {"run_id": self.run_id, "t": round(time.time() - self.t0, 3), "kind": kind, **data}
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, default=str) + "\n")
