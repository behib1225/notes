import json, os
from datetime import datetime, timezone
from pathlib import Path
from typing import Annotated
from mcp.server import MCPServer
from pydantic import Field
NOTES = Path(os.getenv("NOTES_FILE", "notes.json"))
mcp = MCPServer("notes")
def _load() -> list[dict]:
    return json.loads(NOTES.read_text()) if NOTES.exists() else []
@mcp.tool()
def save_note(text: Annotated[str, Field(max_length=1000, description="A fact worth remembering across sessions")],
              tags: Annotated[list[str], Field(description="1-3 lowercase tags, e.g. ['preferences']")] = []) -> dict:
    """Save a short note to long-term memory. Save stable facts and user preferences, not chit-chat."""
    notes = _load()
    note = {"id": len(notes) + 1, "text": text, "tags": tags, "saved_at": datetime.now(timezone.utc).isoformat()}
    notes.append(note)
    NOTES.write_text(json.dumps(notes, indent=2))
    return note
@mcp.tool()
def search_notes(query: Annotated[str, Field(description="Words to look for")], limit: int = 5) -> list[dict]:
    """Find saved notes whose text or tags contain any of the query words (case-insensitive)."""
    words = {w.lower() for w in query.split()}
    scored = [(sum(w in (n["text"] + " " + " ".join(n["tags"])).lower() for w in words), n) for n in _load()]
    return [n for s, n in sorted(scored, key=lambda x: -x[0]) if s > 0][:limit]


if __name__ == "__main__":
    mcp.run()
