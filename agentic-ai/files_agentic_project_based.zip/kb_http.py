"""Serve the knowledge base over Streamable HTTP (the remote MCP transport).

Local:  uv run python -m p2_mcp.kb_http            -> http://127.0.0.1:8000/mcp
Behind a load balancer this scales horizontally: 2026-07-28 clients send self-describing
requests with no session. Add authentication before exposing it beyond localhost.
"""
import os

from p2_mcp.kb_server import mcp

if __name__ == "__main__":
    mcp.run(transport="streamable-http",
            host=os.getenv("HOST", "127.0.0.1"), port=int(os.getenv("PORT", "8000")))
