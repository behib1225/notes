import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from langgraph.types import Command
from p3_langgraph.report_graph import build_graph

calls = []

def fake_ask(system, prompt):
    calls.append(system[:20])
    if "planner" in system:
        return '```json\n{"subquestions": ["A?", "B?"]}\n```'
    if "editor" in system:
        n = sum(1 for c in calls if c.startswith("You are a strict"))
        return '{"verdict": "revise", "feedback": "add numbers"}' if n == 1 else '{"verdict": "pass", "feedback": ""}'
    return f"DRAFT v{sum(1 for c in calls if c.startswith('You write'))}"

graph = build_graph(ask=fake_ask, research=lambda q: f"fact about {q} (Wikipedia: X)")
cfg = {"configurable": {"thread_id": "t1"}}

out = graph.invoke({"question": "Q?"}, cfg)
assert len(out["notes"]) == 2
assert out["__interrupt__"][0].value["draft"] == "DRAFT v2"
out = graph.invoke(Command(resume={"approved": False, "comment": "shorter"}), cfg)
assert out["draft"] == "DRAFT v3" and "__interrupt__" in out
out = graph.invoke(Command(resume={"approved": True}), cfg)
assert out["approved"] is True and "__interrupt__" not in out
print("week 3 graph OK")
