"""Provider-agnostic LLM conversations.

Each provider keeps its own native message history, because each API
has different rules (Anthropic thinking blocks must be passed back
unchanged; OpenAI tool results use role="tool"). The agent loop only
sees the neutral types below.
"""
from __future__ import annotations

import json
import os
import time
from dataclasses import dataclass
from typing import Any


@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict[str, Any]  # JSON Schema of type "object"


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict[str, Any]


@dataclass
class Turn:
    text: str
    tool_calls: list[ToolCall]
    stop_reason: str
    input_tokens: int = 0        # total prompt tokens, including cache reads and writes
    output_tokens: int = 0
    latency_s: float = 0.0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0


class Conversation:
    """Interface every provider adapter implements."""

    model: str

    def add_user(self, text: str) -> None:
        raise NotImplementedError

    def complete(self, tools: list[ToolSpec], allow_tools: bool = True) -> Turn:
        raise NotImplementedError

    def add_tool_results(self, results: list[tuple[str, str, bool]]) -> None:
        """results = [(tool_call_id, output_text, is_error), ...]"""
        raise NotImplementedError


class AnthropicConversation(Conversation):
    def __init__(self, model: str, system: str, max_tokens: int = 8000,
                 effort: str | None = None, client: Any = None):
        if client is None:
            import anthropic
            # Retries with backoff on 429/5xx/overloaded; reads ANTHROPIC_API_KEY.
            client = anthropic.Anthropic(max_retries=4, timeout=120.0)
        self.client, self.model, self.system = client, model, system
        self.max_tokens, self.effort = max_tokens, effort
        self.messages: list[dict[str, Any]] = []

    def add_user(self, text: str) -> None:
        last = self.messages[-1] if self.messages else None
        if last and last["role"] == "user" and isinstance(last["content"], list):
            last["content"].append({"type": "text", "text": text})  # keep roles alternating
        else:
            self.messages.append({"role": "user", "content": text})

    def complete(self, tools: list[ToolSpec], allow_tools: bool = True) -> Turn:
        kwargs: dict[str, Any] = dict(
            model=self.model, max_tokens=self.max_tokens, system=self.system,
            messages=self.messages,
            cache_control={"type": "ephemeral"},  # automatic prompt caching
        )
        if tools:
            kwargs["tools"] = [{"name": t.name, "description": t.description,
                                "input_schema": t.parameters} for t in tools]
            if not allow_tools:
                kwargs["tool_choice"] = {"type": "none"}
        if self.effort:
            kwargs["output_config"] = {"effort": self.effort}
        t0 = time.perf_counter()
        resp = self.client.messages.create(**kwargs)
        if resp.stop_reason == "max_tokens" and any(b.type == "tool_use" for b in resp.content):
            # A tool call cut off mid-arguments cannot be executed: retry once with more room.
            kwargs["max_tokens"] = self.max_tokens * 2
            resp = self.client.messages.create(**kwargs)
        latency = time.perf_counter() - t0
        # Append the assistant content unchanged (it may contain thinking blocks).
        self.messages.append({"role": "assistant", "content": resp.content})
        text = "".join(b.text for b in resp.content if b.type == "text")
        calls = [ToolCall(b.id, b.name, dict(b.input))
                 for b in resp.content if b.type == "tool_use"]
        u = resp.usage
        read = getattr(u, "cache_read_input_tokens", 0) or 0
        write = getattr(u, "cache_creation_input_tokens", 0) or 0
        # usage.input_tokens counts only tokens after the last cache breakpoint.
        return Turn(text, calls, resp.stop_reason, u.input_tokens + read + write,
                    u.output_tokens, latency, read, write)

    def add_tool_results(self, results: list[tuple[str, str, bool]]) -> None:
        self.messages.append({"role": "user", "content": [
            {"type": "tool_result", "tool_use_id": cid, "content": out, "is_error": err}
            for cid, out, err in results]})


class OpenAICompatConversation(Conversation):
    """Works with OpenAI, Ollama, vLLM, LM Studio, OpenRouter... (Chat Completions)."""

    def __init__(self, model: str, system: str, base_url: str | None = None,
                 api_key: str | None = None, client: Any = None):
        if client is None:
            from openai import OpenAI
            client = OpenAI(base_url=base_url, api_key=api_key, max_retries=4, timeout=120.0)
        self.client, self.model = client, model
        self.messages: list[dict[str, Any]] = [{"role": "system", "content": system}]

    def add_user(self, text: str) -> None:
        self.messages.append({"role": "user", "content": text})

    def complete(self, tools: list[ToolSpec], allow_tools: bool = True) -> Turn:
        kwargs: dict[str, Any] = dict(model=self.model, messages=self.messages)
        if tools:
            kwargs["tools"] = [{"type": "function", "function": {
                "name": t.name, "description": t.description,
                "parameters": t.parameters}} for t in tools]
            if not allow_tools:
                kwargs["tool_choice"] = "none"
        t0 = time.perf_counter()
        resp = self.client.chat.completions.create(**kwargs)
        latency = time.perf_counter() - t0
        choice = resp.choices[0]
        if choice.finish_reason == "length" and choice.message.tool_calls:
            # Truncated tool arguments are unusable: do not execute them.
            self.messages.append({"role": "assistant", "content": choice.message.content or ""})
            return Turn(choice.message.content or "", [], "length", latency_s=latency)
        msg = choice.message
        entry: dict[str, Any] = {"role": "assistant", "content": msg.content or ""}
        calls: list[ToolCall] = []
        if msg.tool_calls:
            entry["tool_calls"] = []
            for tc in msg.tool_calls:
                entry["tool_calls"].append({"id": tc.id, "type": "function", "function": {
                    "name": tc.function.name, "arguments": tc.function.arguments}})
                try:
                    args = json.loads(tc.function.arguments or "{}")
                except json.JSONDecodeError:
                    args = {"__invalid_json__": tc.function.arguments}
                calls.append(ToolCall(tc.id, tc.function.name, args))
        self.messages.append(entry)
        usage = resp.usage
        return Turn(msg.content or "", calls, choice.finish_reason or "",
                    getattr(usage, "prompt_tokens", 0) or 0,
                    getattr(usage, "completion_tokens", 0) or 0, latency)

    def add_tool_results(self, results: list[tuple[str, str, bool]]) -> None:
        for cid, out, err in results:
            self.messages.append({"role": "tool", "tool_call_id": cid,
                                  "content": ("ERROR: " + out) if err else out})


def make_conversation(system: str, provider: str | None = None,
                      model: str | None = None) -> Conversation:
    """Build a conversation from env vars LLM_PROVIDER and LLM_MODEL."""
    provider = provider or os.getenv("LLM_PROVIDER", "anthropic")
    if provider == "anthropic":
        return AnthropicConversation(model or os.getenv("LLM_MODEL", "claude-haiku-5-5"), system)
    if provider == "openai":
        return OpenAICompatConversation(model or os.environ["LLM_MODEL"], system)
    if provider == "ollama":
        return OpenAICompatConversation(
            model or os.getenv("LLM_MODEL", "qwen3:8b"), system,
            base_url=os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1"),
            api_key="ollama")  # Ollama ignores the key but the SDK requires one
    raise ValueError(f"Unknown provider: {provider}")
