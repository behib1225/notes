import json, sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parent))

from agentkit.agent import run_agent
from agentkit.llm import AnthropicConversation, ToolCall, Turn
from agentkit.tools import tool
from p1_research.tools_basic import calculator
from fakes import (ScriptedConversation, FakeAnthropicClient, anth_resp, anth_text, anth_tool)


def test_schema():
    print(json.dumps(calculator.parameters))
    assert calculator.parameters["required"] == ["expression"]


def test_calculator():
    assert calculator.run({"expression": "(2024-1867)*12"}) == ("1884", False)
    out, err = calculator.run({"expression": "__import__('os')"})
    assert err and "Only numbers" in out
    out, err = calculator.run({})
    assert err and "Invalid arguments" in out


def test_loop_scripted():
    conv = ScriptedConversation([
        Turn("", [ToolCall("1", "calculator", {"expression": "2+2"})], "tool_use"),
        Turn("The answer is 4.", [], "end_turn"),
    ])
    res = run_agent(conv, [calculator], "What is 2+2?")
    assert res.answer == "The answer is 4." and res.steps == 2 and res.stop == "final"
    assert conv.tool_results == [("1", "4", False)]


def test_unknown_tool_and_max_steps():
    turns = [Turn("", [ToolCall(str(i), "nope", {})], "tool_use") for i in range(3)]
    turns.append(Turn("best effort", [], "end_turn"))
    conv = ScriptedConversation(turns)
    res = run_agent(conv, [calculator], "x", max_steps=3)
    assert res.stop == "max_steps" and res.answer == "best effort"
    assert conv.tool_results[0][2] is True and "Unknown tool" in conv.tool_results[0][1]
    assert conv.calls_allow_tools[-1] is False


def test_approval():
    @tool(requires_approval=True)
    def delete_file(path: str) -> str:
        """Delete a file."""
        return "deleted"
    conv = ScriptedConversation([
        Turn("", [ToolCall("1", "delete_file", {"path": "/x"})], "tool_use"),
        Turn("I was not allowed.", [], "end_turn")])
    res = run_agent(conv, [delete_file], "delete /x", approve=lambda n, a: False)
    assert conv.tool_results[0][2] is True and "not approved" in conv.tool_results[0][1]


def test_anthropic_adapter():
    client = FakeAnthropicClient([
        anth_resp([anth_text("Let me compute."), anth_tool("tu_1", "calculator", {"expression": "6*7"})], "tool_use"),
        anth_resp([anth_text("42")]),
    ])
    conv = AnthropicConversation("claude-haiku-5-5", "sys", client=client)
    res = run_agent(conv, [calculator], "6 times 7?")
    assert res.answer == "42", res
    req2 = client.requests[1]
    assert req2["messages"][1]["role"] == "assistant"
    tr = req2["messages"][2]["content"][0]
    assert tr["type"] == "tool_result" and tr["tool_use_id"] == "tu_1" and tr["content"] == "42"
    assert req2["tools"][0]["name"] == "calculator"
    assert req2["cache_control"] == {"type": "ephemeral"}


def test_openai_adapter_real_sdk_types():
    from openai.types.chat import ChatCompletion
    from agentkit.llm import OpenAICompatConversation
    r1 = ChatCompletion.model_validate({"id": "a", "object": "chat.completion", "created": 0, "model": "m",
        "choices": [{"index": 0, "finish_reason": "tool_calls", "message": {"role": "assistant", "content": None,
            "tool_calls": [{"id": "c1", "type": "function", "function": {"name": "calculator", "arguments": "{\"expression\": \"1+1\"}"}}]}}],
        "usage": {"prompt_tokens": 3, "completion_tokens": 2, "total_tokens": 5}})
    r2 = ChatCompletion.model_validate({"id": "b", "object": "chat.completion", "created": 0, "model": "m",
        "choices": [{"index": 0, "finish_reason": "stop", "message": {"role": "assistant", "content": "2"}}]})
    class C:
        def __init__(s): s.reqs = []; s.chat = s; s.completions = s; s.rs = [r1, r2]
        def create(s, **kw): s.reqs.append(json.loads(json.dumps(kw))); return s.rs.pop(0)
    c = C()
    conv = OpenAICompatConversation("m", "sys", client=c)
    res = run_agent(conv, [calculator], "1+1")
    assert res.answer == "2" and res.input_tokens == 3
    msgs = c.reqs[1]["messages"]
    assert msgs[2]["tool_calls"][0]["id"] == "c1" and msgs[3] == {"role": "tool", "tool_call_id": "c1", "content": "2"}


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn(); print("PASS", name)

def test_invalid_json_args():
    conv = ScriptedConversation([
        Turn("", [ToolCall("1", "calculator", {"__invalid_json__": "{expression: 2+2"})], "tool_calls"),
        Turn("Sorry, retrying gave 4.", [], "stop")])
    res = run_agent(conv, [calculator], "2+2")
    assert conv.tool_results[0][2] is True
    assert "Invalid arguments" in conv.tool_results[0][1]
    assert res.stop == "final"

if __name__ == "__main__":
    test_invalid_json_args(); print("PASS invalid json")
