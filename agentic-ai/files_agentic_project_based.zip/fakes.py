"""Deterministic fakes so agent logic can be tested without an API key."""
from __future__ import annotations

from types import SimpleNamespace as NS

from agentkit.llm import Conversation, ToolCall, ToolSpec, Turn


class ScriptedConversation(Conversation):
    """Returns pre-written turns in order and records everything it was sent."""

    def __init__(self, turns: list[Turn]):
        self.turns, self.model = list(turns), "scripted"
        self.user_msgs: list[str] = []
        self.tool_results: list[tuple[str, str, bool]] = []
        self.calls_allow_tools: list[bool] = []

    def add_user(self, text: str) -> None:
        self.user_msgs.append(text)

    def complete(self, tools: list[ToolSpec], allow_tools: bool = True) -> Turn:
        self.calls_allow_tools.append(allow_tools)
        return self.turns.pop(0)

    def add_tool_results(self, results):
        self.tool_results.extend(results)


class FakeAnthropicClient:
    """Mimics anthropic.Anthropic().messages.create with canned responses."""

    def __init__(self, responses):
        self.responses, self.requests = list(responses), []
        self.messages = self

    def create(self, **kwargs):
        self.requests.append(kwargs)
        return self.responses.pop(0)


def anth_resp(blocks, stop="end_turn"):
    return NS(content=blocks, stop_reason=stop,
              usage=NS(input_tokens=10, output_tokens=5,
                       cache_read_input_tokens=0, cache_creation_input_tokens=0))


def anth_text(t):
    return NS(type="text", text=t)


def anth_tool(id_, name, inp):
    return NS(type="tool_use", id=id_, name=name, input=inp)
