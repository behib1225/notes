# Phase 1 — From LLM to Agent: Definitions, Anatomy, Autonomy, and When Not to Build an Agent

## 1. [core] Phase 1 at a glance

| | |
|---|---|
| **Study hours** | read 3.5 / build 2.5 / assess 1.5 — **7.5 h total** |
| **Compute time (baseline laptop)** | ~5 min, all of it optional |
| **Tier A calls per full eval sweep** | ≤ 24 (4 tasks × max 6 steps); expect 10–16 in practice |
| **Tier H calls** | 0 required, ≤ 20 optional |
| **Cost** | $0.00 |
| **Repo tag** | `phase-01` |

A *light* phase. You will write about sixty lines of code and spend most of your time on definitions, on one piece of arithmetic that constrains every later design decision, and on a specification for Atlas you will still be consulting in Phase 16.

My Phase 0 hour estimate was 40% low. I have padded these, but not measured them on you — keep timing your sessions, and by Phase 3 trust your own multiplier over mine.

---

## 2. [core] Cumulative review

The template asks for questions from two to three phases back. Only Phase 0 exists, so all five come from there. Write your answers before opening `phase_01_solutions.md`.

**CR1.** Phase 0 built `Completion` with a `tool_calls` field before Atlas had tools. State the principle that justified this, and one cost of leaving it out.

**CR2.** `parse_ollama_chat` computes `tokens_per_s` as `eval_count / (eval_duration / 1e9)`; `parse_openai_chat` uses `completion_tokens / latency_s`. Why do these differ, and which measures the model rather than the network?

**CR3.** You set `ATLAS_TEMPERATURE=0` and `ATLAS_SEED=7`. Name two mechanisms that can still make the same prompt produce different output.

**CR4.** A classmate says "Tier H gives 1,000 requests a day, so 300 calls is comfortable." Name the error and the quantity they should have divided instead.

**CR5.** Invariant 3 says transport and parsing stay separate. Name the test-suite capability this buys, and one thing it does *not* buy.

---

## 3. [core] Why this phase matters

Phase 0 gave you a seam: one function turning a list of messages into a `Completion`. What you do not yet have is any reason to call it twice.

That "twice" is the subject. An agent is not a bigger model or a better prompt — it is a **loop**, and a loop has properties a single call does not. It accumulates context, it compounds error, it can fail to stop, and it can touch the world irreversibly. Retrieval quality, budget enforcement, approval gates, credential scoping, tracing, evaluation: every hard problem in the next fifteen phases exists *because of the loop*.

Three payoffs. **A vocabulary older than LLMs** — Russell and Norvig defined agent, percept, action, environment and rationality precisely, and where their definitions strain is exactly where LLM agents are unusual. **The arithmetic that says how many steps you may have** — at 95% per-step success, a twenty-step task succeeds about 36% of the time, which kills more architectures than any other consideration. **The ability to say no** — Anthropic's own guidance (19 December 2024) opens by recommending the simplest solution that works and warns this may mean not building an agentic system at all. Unusual advice from a model vendor, and correct.

The deliverable is `docs/ATLAS_SPEC.md`: who Atlas serves, what it must do, what it must never do, how success is measured, and on whose authority it acts.

---

## 4. [core] Learning objectives

You will be able to:

1. **State** the Russell & Norvig definitions of agent, percept, percept sequence, agent function, agent program and rational agent, and **map** each onto a concrete part of an LLM agent.
2. **Draw** the four-arrow loop from memory and **name** each arrow's token cost, latency cost and risk profile.
3. **Compute** total prompt tokens across an *n*-step episode from *p₀* and *g*, and **derive** the step at which a given context length overflows.
4. **Place** a system at a level of the autonomy spectrum, **justify** it by naming who chooses the next action, and **argue** for the lowest level that works.
5. **Distinguish** workflow from agent using Anthropic's December 2024 criterion.
6. **Derive** `0.95²⁰ ≈ 0.36` by hand, **invert** it for a target success rate, and **state** three ways its independence assumption fails and the engineering response to each.
7. **Implement** a bounded loop under seventy lines that terminates on a final answer, a step cap, an invalid action and lack of progress, recording a complete trajectory.
8. **Diagnose** a non-terminating trajectory from its verbatim trace and **fix** it in the dispatcher rather than the prompt.
9. **Decide** whether a described process wants an agent, a workflow, or neither, and defend it against a rubric.
10. **Write** a specification covering users, tasks, constraints, metrics, risks and delegated authority.

---

## 5. [core] Prerequisites & quick recap

You need Phase 0's repo, green:

```bash
cd atlas-agent && pip install -r requirements.txt && make test-offline   # 28 passed
```

Carry forward: `Message` and `Completion` as the two types every call moves between; `get_client(settings)` as the only place a tier is chosen; `FakeLLMClient` recording every outbound message list in `.calls`; and the rule that tests assert on parsing and control flow, never on model output.

**A correction to Phase 0's forward pointer.** Phase 0 announced that Phase 1 would cover structured output, JSON Schema and retries. It does not — that is Phase 2. When I drafted the structured-output phase it kept reaching for the word "agent" in explanations, and a term you use before defining is a term you use loosely forever. Two `VERSIONS.md` rows said `tenacity` and `pytest-asyncio` arrive in Phase 1; §19 corrects them. This is the second published claim of mine needing correction in two phases; noticing that pattern in your own notes is worth more than any single fact here.

**Nothing new to install.** This phase adds no dependency.

**Orientation: `pytest.mark.parametrize`.** Nine of this phase's tests use it, so: a parametrized test is one function run once per input tuple. Decorate it with `@pytest.mark.parametrize("a,b,expected", [(1, 2, 3), (0, 0, 0)])`, give the function parameters of those names, and pytest reports two separate results named after their arguments. The value is not brevity — it is that a failure tells you *which input* broke, and adding a case is one line rather than one function.

It matters most for pure functions with many edge cases, which is exactly `parse_action`: write the obvious case, then add the ones you are unsure about — empty input, leading chatter, wrong case, a missing bracket. If a case surprises you, you have learned something and it is now permanently guarded. Appendix A covers fixtures, `pytest.raises` and `approx`. Asyncio waits until Phase 8; this phase's loop is synchronous on purpose, because a loop you can step through in a debugger teaches more than one you cannot.

---

## 6. [core] Core concepts

### 6.1 [core] The classical definitions

**Intuition.** A thermostat perceives (a thermometer) and acts (a relay). Nobody thinks it is intelligent, but it is unambiguously an *agent*. A chess program: same structure. A program that reads your email and drafts replies: same structure. "Agent" in AI has always named this structure, not a level of sophistication — which matters because the current use of the word to mean "impressive" has detached it from anything checkable, and you cannot design against a word that means "good."

**Precisely.** Russell and Norvig, *Artificial Intelligence: A Modern Approach*, 4th ed. (Pearson, 2020), ch. 2. An **agent** is anything that can be viewed as perceiving its environment and acting upon it through actuators. A **percept** is its perceptual input at one instant; a **percept sequence** is the complete history of everything it has ever perceived. The **agent function** maps any percept sequence to an action; the **agent program** implements it — and they insist these stay distinct, because the function is the mathematical object and the program is what you debug at 2am. A **rational agent** selects, for each percept sequence, the action expected to maximise its performance measure given the evidence in that sequence and its built-in knowledge. The **task environment** is described by PEAS: Performance measure, Environment, Actuators, Sensors.

Note what rationality is *not*: not omniscience, not success. Their own example is crossing a street and being hit by a falling cargo door — the crossing was rational, because rationality concerns *expected* success given what was perceived. An agent that fails for reasons it could not have perceived is not irrational. This sounds like philosophy and is the single most useful idea for reading agent traces fairly.

**The mapping.**

| Russell & Norvig | In your Atlas code |
|---|---|
| Agent | The whole process: loop + model + dispatcher |
| Percept | One appended `Message` — a user turn, or a tool result |
| Percept sequence | The `list[Message]` passed to `client.complete()` |
| Action | A tool call with arguments, or a final answer |
| Agent function | The idealised map from message list to next action |
| Agent program | `atlas/agents/*.py` |
| Actuators | The dispatcher that actually executes a tool |
| Sensors | Whatever appends observations back to the message list |
| Performance measure | Your eval suite (`evals/`, built in Phase 3) |
| Task environment | Tools + data + humans, per `docs/ATLAS_SPEC.md` |

Three rows are design consequences in disguise.

**The percept sequence is literally a Python list.** In a classical agent it is a history the agent may or may not store, usually compressed into internal state. In an LLM agent it *is* the state, materialised, in order, in a variable you can print. There is no hidden state at all; the model holds nothing between calls. In R&N's taxonomy this makes an LLM agent a peculiar creature: a **reflex agent with a complete percept history**, re-deriving everything it knows from scratch every step. The gift is total observability — every belief is a string you can point at, which is why the debugging sections keep telling you to print the messages. The curse is that **state and cost become the same variable**, priced by the token, every step. §6.3 does that arithmetic.

**The performance measure is not optional, and you do not have one.** Rationality is defined *relative* to one. Without it, "my agent is behaving rationally" is not false — it has no truth conditions. Hence Phase 3 builds the eval harness before Phase 4 builds retrieval. Any claim about your agent not measured against a stated performance measure is a vibe.

**Actuators are yours, not the model's.** The model emits *text describing an action*; something in your code does the thing. **The model never executes anything.** Every guardrail, approval gate, credential scope and audit record in this book lives in the dispatcher, because the dispatcher is the only place where intention becomes effect.

**Worked example: PEAS for Atlas.** *Performance:* document questions answered correctly *and* correctly cited; data questions whose query returns the right rows; risky actions taken without approval (target zero); tokens and seconds per resolved task. *Environment:* a document store, a read-only SQLite view, the web, a calculator, a calendar, a jailed directory, a code sandbox, and humans who ask and approve. *Actuators:* the tool dispatcher plus the final-answer channel — text is an actuator too, because it changes what people believe and do, which is why a confidently wrong citation is a real failure, not a cosmetic one. *Sensors:* the tool-result channel, the user's turns, later the memory store. The environment is *partially observable*, *stochastic*, *sequential*, *dynamic* and *partly unknown* — each property a difficulty, and naming them tells you which to expect.

> **Misconception.** *"Agent" means autonomous or intelligent.* No. A thermostat is an agent; so is a one-call program with no tools, degenerately. What makes the word useful is the **loop** — repeated action selection conditioned on accumulated observations. When someone says "we built an agent," the only informative follow-up is: who chooses the next action, and how many times?

> **Concept check 1.1.** An LLM agent has no hidden state; the message list is everything. Name one debugging technique this makes trivially easy, and one failure mode it makes *unavoidable* that a system with compressed internal state would not have.

> **Concept check 1.2.** Your agent searched the document store, got no hits because the document was not yet indexed, and told the user the information does not exist. Was it irrational? What precisely is the defect, and where does it live?

> **Your turn (10 min).** Write a PEAS description for something you used this week — a spam filter, a maps app, a code-completion plugin. Force the performance measure to be computable from logs. Most people write something unmeasurable on the first attempt; notice if you do.

### 6.2 [core] Policy, environment, trajectories, episodes

**Intuition.** Reinforcement learning divides labour cleanly: the *environment* receives actions and returns observations; the *policy* receives an observation and returns an action. Keeping them apart is what lets you replace either without rewriting the other. An LLM agent has exactly this shape, and the shape tells you where each line of code belongs.

**Precisely.** A **policy** maps state to action, written π(a | s) when stochastic. Here the **state** is the message list; the **action** is a tool invocation or a terminal answer; and the **policy** is the model *together with* the system prompt and the tool descriptions. That last point matters: the weights alone are not the policy. When you edit a system prompt you are not tweaking a setting, you are changing the policy, and your evals must be re-run. The policy is stochastic even at `temperature=0`, for Phase 0's reasons.

The **environment** is three quite different things, and conflating them is where people go wrong. *Tools* — schema'd functions run by your dispatcher; deterministic-ish, yours. *Data* — documents, tables, the web; not yours, changing while you read, and **potentially authored by an adversary**: when your agent appends a retrieved document, that text enters the policy's input on equal footing with your system prompt. OWASP's 2026 LLM list ranks prompt injection first, and its agentic list makes goal hijacking through malicious content the number-one entry. Phase 1 does not solve this; it gets the architecture right so it is solvable, which mainly means keeping the dispatcher in charge. *Humans* — an approval is an observation, and "ask the human" is an action, so humans are *part of* the environment. Building it that way now is far cheaper than retrofitting in Phase 11.

**Trajectories versus episodes.** An **episode** is a temporal unit: one attempt at one task, from initial percept to termination, with a reason for ending. A **trajectory** is the *record*: the ordered (state, action, observation) triples plus metadata — model, tier, seed, tokens, latency, stop reason. The episode is what happened; the trajectory is what you keep.

The distinction earns its keep because the trajectory does four jobs at once: it **is the state** (truncate it and you change what the agent knows); it is the **debugging artefact** (from Phase 3, five failing trajectories per phase into `docs/FAILURE_LOG.md` — the highest-yield habit in this discipline and the one nobody builds voluntarily); it is the **eval input**; and it is **training data** if you ever fine-tune. Jobs 1 and 2 pull opposite ways — the state wants to be small, the record complete — so mature systems separate them: a trimmed message list to the model, a complete trajectory to disk. At sixty lines we do not need that; by Phase 8 we will. Note the shape of the argument: defining `Trajectory` as a first-class type *now*, when a bare list would do, is Phase 0's reason for defining `tool_calls` before there were tools.

> **Misconception.** *The system prompt is configuration; the model is the agent.* Model plus instructions plus tool descriptions is one object — the policy. Teams that keep prompts in a casually-edited config file discover this via a metric that moved for "no reason."

> **Concept check 1.3.** You implement context trimming by dropping the oldest tool observations past a threshold, and trim the stored trajectory the same way to save disk. Name two things you have just broken.

### 6.3 [core] The loop, and what each arrow costs

**Intuition.** Four moves, the same four whether the agent writes code, books travel or reads a PDF: look at what you know, decide what to do, do it, look at what happened. Repeat until done. Everything else in this book is making those four cheap, safe and terminable.

```mermaid
flowchart TD
    START([task arrives]) --> P
    P["<b>1. PERCEIVE</b><br/>assemble the message list:<br/>system + task + all prior<br/>actions and observations"]
    P -->|"costs: every prompt token,<br/>every step"| R
    R["<b>2. REASON</b><br/>one call through the seam:<br/>client.complete(messages)"]
    R -->|"costs: output tokens,<br/>decode latency"| D{"terminal<br/>answer?"}
    D -->|yes| STOP([return trajectory])
    D -->|no| A
    A["<b>3. ACT</b><br/>YOUR dispatcher validates<br/>and executes the tool"]
    A -->|"costs: tool latency,<br/><b>irreversible effects</b>"| O
    O["<b>4. OBSERVE</b><br/>append the result as a<br/>new message"]
    O -->|"costs: tokens, permanently,<br/>for the rest of the episode"| GUARD{"budget or<br/>progress<br/>guard trips?"}
    GUARD -->|yes| STOP
    GUARD -->|no| P
```

Memorise this. Note what most versions of it omit: there are **two exits, and only one is the model's decision.** The model decides "terminal answer." Your code decides "out of budget" and "not making progress." An agent whose only exit is the model's judgement can run forever — §8 dissects exactly that.

**Arrow 1, perceive, costs the whole prompt every time.** This is the non-obvious one and the source of most surprise bills. The message list grows monotonically and you pay for all of it on every call. Let *p₀* be the initial prompt (system + task) and *g* the average tokens appended per step (assistant action + tool observation). Step *k* sends *p₀ + (k−1)·g*, so the total over *n* steps is an arithmetic series:

$$\text{total prompt tokens} = n \cdot p_0 + g \cdot \frac{n(n-1)}{2}$$

That second term is quadratic in *n*. **Prompt cost grows with the square of the step count, not linearly.** With *p₀* = 600 and *g* = 350 (an 80-token action, a 270-token observation):

| Steps *n* | Prompt at final step | Total prompt tokens |
|---|---|---|
| 1 | 600 | 600 |
| 3 | 1,300 | 2,850 |
| 5 | 2,000 | 6,500 |
| 10 | 3,750 | 21,750 |
| 15 | 5,500 | 45,750 |
| 20 | 7,250 | 78,500 |

Five steps to ten doubles the steps and multiplies prompt tokens by **3.35**. Five to twenty quadruples the steps and multiplies by **12.08**. A budget model assuming "4× the steps costs 4×" is wrong by a factor of three.

Now connect this to context length, because it yields a hard limit. Atlas's default `ATLAS_NUM_CTX` is 4096. The prompt at step *n* is 600 + 350(n−1), which reaches 4,100 at step 11. **Your ten-step budget is not a preference; it is what a 4,096-token context arithmetically permits at those message sizes.** This is why Phase 0 insisted you set context length to what you need: the number is load-bearing, and now you can compute it.

One latency subtlety, stated carefully because I cannot verify it for your hardware. If your runner reuses the key–value cache across calls sharing a prefix, prompt processing costs roughly the *new* tokens and per-step latency stays flat; if not, you pay prefill on the whole prompt every step and latency climbs with the episode. Which regime you are in is measurable and hardware-specific — that is what `make results` is for.

**Arrow 2, reason, costs output tokens and decode time.** Output is the smaller number and the slower one: generation is sequential, so latency ≈ output tokens ÷ tokens-per-second. The risks: a nonexistent tool name, arguments that fail validation, a refusal, or — most insidiously — a plausible answer that skipped a tool it should have used. Each is a *parsing and control-flow* problem, which is why fixtures cover them while the model's *tendency* to commit them stays in `docs/RESULTS.md`.

**Arrow 3, act, costs no tokens and carries all the danger.** Internalise the asymmetry. Executing a tool consumes zero context. Its latency is the tool's — for a web request or SQL query, often dwarfing the model call. And it is the only arrow that changes the world. Risk here ≈ (probability the action is wrong) × (cost of not being able to undo it). Reading a document: near-zero irreversibility. Sending an email: total. **That product, not the model's confidence, is what should decide whether an action needs approval** — and structuring the dispatcher so this decision has somewhere to live is why Phase 11's gate is cheap to add and would have been expensive to retrofit.

**Arrow 4, observe, costs tokens permanently.** A 2,000-token observation appended at step three is re-sent at steps four through *n* — in a ten-step episode, billed eight times. Hence tool outputs should be **summaries designed for a model to read**, not raw dumps: returning 200 useful tokens instead of 2,000 saves you 1,800 *times the remaining step count*. Anthropic's December 2024 guidance makes this point under the heading of the agent–computer interface: tool design deserves as much attention as prompt design.

**One sentence.** Perceiving is expensive and worsens; reasoning is slow; acting is dangerous; observing is expensive forever. A short loop is not merely cheaper — it is cheaper *superlinearly*, faster, and safer at once. There is no trade-off to balance. Fewer steps wins on every axis except capability, and §6.7 shows it usually wins there too.

> **Misconception.** *Adding a step costs one more model call.* It costs one more call, plus re-sending everything before it, plus permanently raising the cost of every later step, plus multiplying the chance the episode fails somewhere. The marginal step is never marginal.

> **Concept check 1.4.** With *p₀* = 800 and *g* = 500, compute total prompt tokens for a 6-step episode and the step at which the prompt exceeds 4,096. Show the arithmetic.

> **Concept check 1.5.** With *p₀* = 600 (of which 400 is the system prompt), *g* = 350, *n* = 10, you may halve exactly one of: the system prompt, the average observation, or the step count. Compute all three and say which wins.

> **Your turn (15 min).** Annotate the loop diagram for a task you would want Atlas to do — "how many people were in support last quarter, and what changed?" For each arrow write what concretely happens and roughly how many tokens move. You will be wrong about the counts. Being wrong on paper is free.

### 6.4 [core] Workflows versus agents, and the autonomy spectrum

**Intuition.** Two companies each build a system that resolves a support email. The first classifies it into four categories, then for a refund looks up the order, checks the return window, and issues or declines; for a technical question it retrieves three articles and answers. Every branch was written by a human. The second gives the model the email, eight tools, and a loop.

Both use an LLM, make several calls, use tools, and may produce identical output. But they are different *kinds* of thing, and the difference is not a matter of degree in any way that matters: **in the first, a human wrote the control flow; in the second, the model chooses it at runtime.**

**Precisely.** Anthropic's post of 19 December 2024 draws this line. It groups everything of the sort under *agentic systems*, then splits it: a **workflow** orchestrates LLM and tool calls along code paths laid down in advance by a developer; an **agent** is a system where the model directs its own process, choosing which tools to use and in what order, retaining control of how the task gets done. Their guidance runs against commercial incentive and is worth stating: find the simplest thing that works and add complexity only when it demonstrably helps; workflows give predictability on well-specified tasks, agents give flexibility when decisions must be made at runtime and at scale; and for many applications a single well-optimised call with retrieval and good examples is enough.

That post now carries an editorial note saying its tooling landscape has changed since December 2024. Notice this: even a good primary source ages, and honest ones tell you. The *distinction* has aged well; the framework recommendations have not, which is why framework state lives in `VERSIONS.md`.

**The augmented LLM.** The post's foundational building block is neither workflow nor agent: a single call with augmentations available — retrieval, tools, memory. One call. The model can generate a query, pick a tool, decide what to keep. Try this first. Phase 4's retrieval work produces an augmented LLM before anything loop-shaped, and for a large share of Atlas's real questions it will be the whole answer.

**The spectrum.** The organising question at every level is the same: **who chooses the next action?**

| Level | Name | Who chooses the next action | Example |
|---|---|---|---|
| **L0** | Single call | Your code; there is one action | Summarise this document |
| **L1** | Augmented LLM | Your code, but the model may invoke retrieval or a tool once within the call | Answer from the docs with a citation |
| **L2** | Chained workflow | Your code, as a fixed sequence | Draft, critique, revise |
| **L3** | Routed workflow | The model classifies once; your code follows a fixed branch | Triage refund / technical / billing |
| **L4** | Bounded agent | The model, from a fixed tool set, under a step cap, risky actions gated | **Atlas** |
| **L5** | Open-ended agent | The model, and it sets subgoals, spawns workers, decides termination | A research orchestrator |
| **L6** | Persistent agent | The model, continuously, no episode boundary, self-set triggers | An always-on monitor |

Two properties do the work. **Autonomy is a cost, not a feature.** Each rung hands one more decision to the model. You gain the ability to handle inputs whose control flow you could not anticipate; you lose predictability, lose exhaustive testability of control flow, gain a superlinear token bill, and acquire failure modes — non-termination, goal drift, tool misuse — that did not previously exist. The right level is the *lowest* that solves the task. **And levels are not a maturity model.** A team running a well-tuned L1 that resolves 90% of queries is doing better engineering than a team running an L5 that resolves 60%. Atlas targets L4 and stops on purpose; Appendix F's deferred builds are largely L5 material, which is why they are deferred.

**Where the levels blur.** L3 versus L4 is the boundary people misjudge. A router that classifies then branches into fixed code is L3 *even if it calls the model six more times*, because a human wrote the six; a system with one tool and a loop is L4 *even though it looks trivial*, because the model decides whether to call again. The test is not call count or apparent sophistication: **could the action sequence have been drawn as a flowchart before the input arrived?**

> **Misconception.** *An agent is a workflow with more steps.* A hundred-step workflow is still a workflow; a two-step agent is still an agent. The variable is who decides.

> **Misconception.** *If the model calls tools, it is an agent.* A single call with one tool is L1. The loop is what makes an agent, because the loop gives the model a second decision.

> **Concept check 1.6.** Classify each and name who chooses next. (a) A nightly job asking the model to summarise each of yesterday's tickets, one call per ticket. (b) A system that asks the model for SQL, runs it, and on error sends the error back for up to three retries. (c) A system offering twelve tools, executing the model's choice, appending the result, repeating until the model says done or fifteen steps elapse. (d) A chatbot with a web-search tool it may use once per turn.

> **Your turn (10 min).** Take (b). It is a retry loop, which sounds agentic. Argue both sides, then commit to a level and write the single sentence that decides it. The argument matters more than the verdict.

### 6.5 [core] One page of history, with dates

Everything below is dated with a primary source. Nothing below is a claim about the present — what is state-of-the-art today lives in `VERSIONS.md`.

| Date | What | The idea, and why it mattered |
|---|---|---|
| **6 Oct 2022** | **ReAct** — Yao et al., arXiv:2210.03629 (ICLR 2023) | Interleave reasoning and actions in one token stream, so a reasoning trace conditions the next action and its result conditions the next reasoning. Pure prompting; no training, no API support. Established that the loop's intermediate reasoning belongs **in the context**, visible and re-readable. Every trajectory you debug owes its legibility to this. |
| **9 Feb 2023** | **Toolformer** — Schick et al., arXiv:2302.04761 (Meta AI) | Train the model to decide which API to call, when, with what arguments, self-supervised from a handful of demonstrations. Its tool set snapshots the era's ambition: calculator, QA system, two search engines, translator, calendar. Tool use became a **trained behaviour** rather than a prompting trick. |
| **30 Mar 2023** | **AutoGPT** — Toran Bruce Richards *(secondary source: Wikipedia, not primary — flagged rather than dressed up)* | Give GPT-4 a goal, a loop, files and browsing, and let it run. Went viral; did not work. It looped, hallucinated progress, and burned money with no budget and no evaluation. **The field's most instructive negative result** — step caps, budgets, progress guards and evals-before-agent are all direct responses to it. |
| **13 Jun 2023** | **Native function calling** — OpenAI | Send JSON Schema descriptions; get back a structured object naming a function and arguments. Unglamorous and enormous: **the parsing problem moved out of your regexes into the provider's contract.** The hand-rolled text parsing in §7 is what everyone did before this date. The announcement also acknowledged untrusted tool output steering the model — injection was visible from day one and is not solved. |
| **22 Oct 2024** | **Computer use** — Anthropic, public beta | Screenshots in, cursor movements and keystrokes out. When the action space is the screen, no per-application integration is needed. The same announcement reported SWE-bench Verified improving from 33.4% to 49.0% — quoted as history, not a current score. **The wider the action space, the weaker your guarantees.** |
| **25 Nov 2024** | **Model Context Protocol** — Anthropic (initial spec revision labelled 2024-11-05) | Define one protocol so tool *servers* and model *clients* are each written once, instead of M×N bespoke glue. The tool catalogue became **infrastructure rather than application code.** Phase 15 both exposes and consumes it. |
| **19 Dec 2024** | **"Building effective agents"** — Anthropic | The workflow/agent distinction, the augmented LLM, five composable workflow patterns, start simple, and prompt-engineer your tools as carefully as your prompts. |

**Coding agents, throughout.** Coding is where agents worked first and best, for a structural rather than accidental reason: a test suite is a cheap, automatic, objective verifier, and version control makes mistakes reversible. Anthropic's December 2024 post says they spent more effort optimising their SWE-bench agent's tools than its overall prompt, and gives a concrete example — switching a file tool from relative to absolute paths eliminated a persistent class of error. That is the most transferable single lesson in the post.

**The thread through all eight.** The field has steadily **relocated the loop's guarantees out of the prompt and into the protocol and the harness.** ReAct put reasoning in the context; function calling put the action schema in the API contract; MCP put the tool catalogue in a protocol; harnesses put the budget, the cap and the gate in code. Each move traded magic for engineering and made the result more testable. **When you find yourself fixing a control-flow problem by rewriting a system prompt, you are working against three years of accumulated evidence about where fixes belong.**

> **Concept check 1.7.** ReAct needed no API support; function calling required provider changes. Both address "get a well-formed action out of the model." Name one thing function calling gives you that a text convention cannot, and one thing the text convention retains that function calling gives up.

### 6.6 [core] The eight components

An agent taken apart is eight things. For the next fifteen phases you will always be working on exactly one, and knowing which keeps you from fixing the wrong thing.

| Component | What it is | Where it lives | Phase |
|---|---|---|---|
| **Model** | Weights plus decoding parameters — half the policy | `atlas/llm.py` | 0 ✔ |
| **Instructions** | System prompt plus tool descriptions — the other half | `atlas/agents/` | 1 ✔ / 2 |
| **Tools** | Schema'd functions, plus the dispatcher that runs them | `atlas/tools/` | 3 |
| **Memory** | Within-episode (the trajectory) and across-session (a store) | `atlas/memory/` | 1 ✔ / later |
| **Orchestration** | The loop, budgets, termination; later the fan-out | `atlas/agents/`, `atlas/graph/` | 1 ✔ / 9 |
| **Guardrails** | Input/output validation, approval gates, sandboxes, jails | `atlas/safety/` | later |
| **Evals** | The performance measure | `evals/` | 3 |
| **Identity** | On whose authority, with what scope, auditably | `atlas/auth/` | later |

Phases 0, 1, 2, 3, 9 and 15 are pinned by the syllabus; "later" is the plan, not a promise, and I would rather say so than invent a number you might quote back at me.

Four observations that are more than bookkeeping. **Instructions are policy, not configuration** — change either, re-measure. **Memory has two halves that are constantly confused:** within-episode is the message list, free to build and expensive to run; across-session is a store with staleness and privacy problems, expensive to build, and it changes what your agent *is*. When someone says "the agent should remember," find out which. **Guardrails and identity are properties of the dispatcher** — one with a single choke point grows an approval gate in twenty lines; one whose tool calls are scattered cannot. **Evals come before capability**: an agent without them is not one you can improve, only one you can have opinions about.

> **Your turn (5 min).** Take the last bug you hit in any software you have written. Which of the eight components was it in? Now do the same for "the agent keeps calling the wrong tool" — and notice that it could plausibly be *three* of them, which is exactly why naming the component first is worth the five seconds.

### 6.7 [core] Compounding error, and how many steps you are allowed

**Intuition.** A twenty-step task where each step works nineteen times in twenty — 95%, a good day for an LLM step involving a tool call. What fraction of attempts complete end to end?

Most guts say "pretty good, maybe eighty percent," reasoning additively. The answer is about **thirty-six percent**: nearly two in three attempts fail. Let us derive it slowly, because this number should live in your bones.

**In words.** If each step succeeds independently with probability 0.95, all twenty succeeding is 0.95 multiplied by itself twenty times. Do it by repeated squaring, on paper.

Two steps: 0.95 × 0.95 = **0.9025**. Four: square that → **0.8145**. Eight: square again → **0.6634** — eight steps at 95% and we are down to two-thirds; the intuition that "95% is basically reliable" has already failed. Sixteen: square → **0.4401**, below a coin flip. Twenty: multiply the sixteen-step figure by the four-step figure, since 16 + 4 = 20 → 0.4401 × 0.8145 = **0.3585**.

**Now invert it, because that is the design question.** You rarely choose your per-step reliability; you do choose your step count. You need *pⁿ ≥ T*, so *n ≤ ln T / ln p*. For a 90% end-to-end target — modest for anything a business depends on:

| Per-step success *p* | Max steps for 90% end-to-end | Check |
|---|---|---|
| 0.999 | 105 | 0.999¹⁰⁵ = 0.900 |
| 0.995 | 21 | 0.995²¹ = 0.900 |
| 0.99 | 10 | 0.99¹⁰ = 0.904 |
| 0.98 | 5 | 0.98⁵ = 0.904 |
| 0.95 | **2** | 0.95² = 0.903 |
| 0.90 | 1 | 0.90¹ = 0.900 |

Sit with the 0.95 row. **At 95% per-step reliability you are allowed two steps.** Not ten. Two. Read it the other way: a design needing twenty steps is asserting each step is 99.5% reliable, because 0.995²⁰ = 0.905. Have you measured 99.5% on anything — on Tier A, on a step requiring tool choice and argument formatting? No. Neither have I.

This is why §7's loop caps at six rather than sixty.

**Three ways this model is wrong, and what each tells you to do.** Leaving the multiplicative model unqualified would be a disservice; the ways it is a caricature are the engineering.

*Steps are not independent.* Errors correlate both ways. Harmfully: one bad observation poisons the context for every later step, so a failure at step three *raises* the failure probability at four through twenty — reality worse than the model. Helpfully: models recover, noticing a nonsensical result and trying something else — reality better than the model. Which dominates is empirical and task-specific, so it belongs in `docs/RESULTS.md`, not in prose.

*"Per-step success" is undefined without a checker.* If you cannot compute it, *p* is a number you made up and the table is decoration. Another argument for Phase 3: the harness turns *p* from rhetoric into a measurement.

*The model assumes failure is terminal, and you can choose otherwise.* Here is the crucial response. If a step's failure can be **detected** and **retried**, its effective reliability rises sharply: two independent attempts at a 0.95 step with a reliable checker gives 1 − 0.05² = **0.9975** — the difference between two allowed steps and twenty-one. **Verification is the lever, and it is a much bigger lever than prompt quality.**

So the honest reading is not "agents are doomed." It is: **long loops only work when failures are cheaply detectable and recoverable.** Which is precisely why coding agents worked first — tests are a free checker, `git` makes failure recoverable — and why an agent that sends email on your behalf does not, because a wrongly sent email is neither detectable nor recoverable by the agent.

**Reach for these in order:** fewer steps; then verification after risky steps; then checkpoints, so a failure at step twelve resumes rather than restarts; *then* better prompting — the response everyone reaches for first, and which moves *p* by a few points at most.

> **Misconception.** *A more capable model fixes this.* It raises *p*, and because the relation is exponential, 0.95 → 0.99 raises your allowance from two steps to ten — real and large. But it does not change the curve's shape, and every capability gain is immediately spent on longer tasks. This is not a temporary limitation of current models; it is a property of composing unreliable steps.

> **Concept check 1.8.** Compute 0.9⁵ by squaring, and say what it implies for a five-step design on a step that works nine times in ten.

> **Concept check 1.9.** A twelve-step design with measured per-step success 0.97. (a) Expected end-to-end rate? (b) You may add a verifier that catches and retries failures on the three riskiest steps, *or* cut to eight steps. Estimate both, and say which you would ship and why.

> **Your turn (10 min).** Take any multi-step automation you have built or used. Write down its step count. Now write the per-step reliability it would need for a 90% end-to-end rate, using *p ≥ T^(1/n)*. For a ten-step process at 90% that is 0.9^0.1 ≈ 0.9895. Ask yourself whether you have ever measured anything at 99%. This is the exercise that changes how you scope work.

### 6.8 [core] What works today, what does not, and the principle behind both

Honestly, in the sense of "I would say this to a client about to spend money."

**Works today.** *Coding agents on a repo with tests* — the verifier is free and automatic, mistakes are reversible through version control, the problem is well-specified. The strongest case in the field, not close. *Customer support with tool access and a resolution signal* — support conversations naturally interleave talking and acting, the tools are well-bounded, and success is measurable because a resolution either happened or did not; several companies price this per successful resolution, a strong signal of confidence. *Document Q&A with citations* — L1, not L4, and it works because a citation is a **checkable** claim a human verifies in seconds. Atlas's first real capability in Phase 4 is this, not a coincidence. *Structured lookup over a read-only view* — read-only makes it safe, a narrow curated view makes it accurate; note the scoping, since full text-to-SQL over an arbitrary schema is deferred to Appendix F precisely because it is much harder than it demos. *Research gathering with a human synthesising* — the agent does the tedious, parallel, verifiable part.

**Does not work today.** *Anything irreversible with no cheap verifier* — wire transfers, unattended customer email, production writes, signatures. Compounding error says you will be wrong some percentage of the time; irreversibility makes that percentage a permanent loss. The response is not a better model, it is a human at the gate. *Long-horizon tasks measurable only weeks later* — no performance measure, no rationality, and certainly no unsupervised running. *Genuinely contested success criteria* — "is this the right strategy?" has no verifier because reasonable humans disagree; a system appearing to decide it is laundering someone's judgement through a plausible paragraph. *High-volume, latency-sensitive, low-margin work* — an agent taking eight seconds and twenty thousand tokens loses to a regex taking eight milliseconds. Check whether a rule, lookup table or small classifier does the job first; this one embarrasses more teams than any technical failure. *Attacker-controlled input plus powerful tools* — injection is unsolved; OWASP's 2026 LLM list still ranks it first and its 2026 agentic list leads with goal hijacking, then tool misuse and privilege abuse. If your agent reads untrusted pages and can also spend money, you have built the thing those lists warn about. The mitigation is architectural — narrow tools, scoped credentials, human gates — not a better system prompt.

**The principle that unifies both lists.** One sentence, and it is the sentence to take from this phase:

> **An agent works where verification is cheaper than generation and mistakes are reversible.**

Every "works" entry satisfies both. Every "does not" violates at least one. Ask these two questions before any question about models, frameworks or prompts. Expensive verification means a human in the loop or a smaller task. Irreversible mistakes mean a gate. Both bad means the honest answer is that this should not be an agent.

> **Your turn (10 min).** Pick a task you have caught yourself thinking "an agent could do this." Apply the two questions: what would a verifier cost, and could a mistake be undone? Many people find their favourite idea does not survive. That is the exercise working.

---

## 7. [core] Hands-on: a minimal agent loop

We write the loop now, with a fake tool, so it is a concrete object before Phase 3 adds real tool calling and a hundred new things to think about. The rule: **every design decision gets a reason.**

Two deliberate simplifications, named so you know what is a teaching device. The tool is a Python dict — deterministic, free, offline. And the action is parsed from plain text rather than read from the `tool_calls` field Phase 0 built; that convention is exactly what everyone did before June 2023, and doing it once by hand teaches you what native function calling buys. Everything else — the record types, the termination logic, token accounting, and the fact that the dispatcher and not the model decides what runs — is real and survives into Phase 3.

Here is the whole module. Read it once, then read the commentary; each numbered note maps to a decision in the file.

```python
# file: atlas/agents/minimal.py
"""A minimal agent loop: the four arrows, and nothing else.

Phase 1. The tool is hard-coded and fake, and the model's chosen action is
parsed out of plain text rather than read from a native tool-call field. Both
of those are replaced in Phase 3. What survives unchanged is the shape of the
loop -- perceive, reason, act, observe -- and the rule that *termination is
owned by this file*, never by the model.
"""

from __future__ import annotations

from typing import Callable, Literal

from pydantic import BaseModel, Field, computed_field

from atlas.llm import LLMClient, Message

# All six values are declared now; Phase 1's shipped loop produces four of them.
# "token_budget" and "cycle" are produced by this phase's Assignment 2. Declaring
# them up front follows Phase 0's rule: adding to a published interface is free,
# changing one is not.
StopReason = Literal[
    "final", "step_cap", "no_progress", "bad_action", "token_budget", "cycle"
]

# The whole environment, such as it is. A dict is a legitimate tool backend for
# teaching the loop: it is deterministic, offline, and costs nothing to call.
# These are Northwind's four departments from docs/ATLAS_SPEC.md, and they add
# to its stated 38 people. Code and spec must agree, or the spec is decoration.
HEADCOUNT: dict[str, int] = {
    "engineering": 14,
    "operations": 9,
    "sales": 6,
    "support": 9,
}


def headcount(department: str) -> str:
    """The one fake tool. Returns a string, because observations are text."""
    key = department.strip().strip("\"'").lower()
    if key not in HEADCOUNT:
        return f"ERROR: unknown department {key!r}; known: {sorted(HEADCOUNT)}"
    return f"{key} headcount = {HEADCOUNT[key]}"


SYSTEM = (
    "You answer questions about company staffing using one tool.\n"
    "Reply with exactly one line, in one of these two forms:\n"
    "  ACTION: headcount(<department>)\n"
    "  FINAL: <your answer>\n"
    "Once a tool result gives you what you need, reply with FINAL.\n"
    f"Known departments: {', '.join(sorted(HEADCOUNT))}."
)


class Step(BaseModel):
    """One turn of the loop, recorded whether or not it succeeded."""

    n: int
    action: str
    argument: str
    observation: str | None = None
    prompt_tokens: int = 0
    completion_tokens: int = 0


class Trajectory(BaseModel):
    """The record of one episode. The state is the message list; this is the log."""

    task: str
    steps: list[Step] = Field(default_factory=list)
    answer: str | None = None
    stop_reason: StopReason = "step_cap"

    # computed_field, not a bare @property: a plain property is invisible to
    # model_dump(), so any consumer that walks the serialised trajectory --
    # the Phase 3 eval harness, a JSON log, a trace viewer -- would silently
    # not find it. If a field is part of the contract, serialise it.
    @computed_field  # type: ignore[prop-decorator]
    @property
    def prompt_tokens(self) -> int:
        return sum(s.prompt_tokens for s in self.steps)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def completion_tokens(self) -> int:
        return sum(s.completion_tokens for s in self.steps)


def parse_action(text: str) -> tuple[str, str]:
    """Pure. Turn model text into (action_name, argument).

    Returns ``("final", answer)`` for a terminal answer and ``("invalid", text)``
    when no recognised directive is present. Unknown *tool* names are returned
    as-is so the caller, not the parser, decides what exists.
    """
    for raw in text.strip().splitlines():
        line = raw.strip()
        if line.upper().startswith("FINAL:"):
            return "final", line[len("FINAL:") :].strip()
        if line.upper().startswith("ACTION:"):
            body = line[len("ACTION:") :].strip()
            name, _, rest = body.partition("(")
            return name.strip(), rest.rsplit(")", 1)[0].strip()
    return "invalid", text.strip()


def run_minimal_agent(
    client: LLMClient,
    task: str,
    *,
    tools: dict[str, Callable[[str], str]] | None = None,
    max_steps: int = 6,
    system: str = SYSTEM,
) -> Trajectory:
    """Run the four-arrow loop until it terminates. Always terminates."""
    tools = {"headcount": headcount} if tools is None else tools
    traj = Trajectory(task=task)
    messages: list[Message] = [                                  # 1. PERCEIVE
        Message(role="system", content=system),
        Message(role="user", content=task),
    ]
    seen: set[tuple[str, str]] = set()
    for n in range(1, max_steps + 1):
        completion = client.complete(messages)                   # 2. REASON
        action, argument = parse_action(completion.text)
        step = Step(
            n=n,
            action=action,
            argument=argument,
            prompt_tokens=completion.usage.prompt_tokens,
            completion_tokens=completion.usage.completion_tokens,
        )
        traj.steps.append(step)
        if action == "final":
            traj.answer, traj.stop_reason = argument, "final"
            return traj
        if action not in tools:
            step.observation = f"ERROR: no tool named {action!r}"
            traj.stop_reason = "bad_action"
            return traj
        if (action, argument) in seen:
            step.observation = f"ERROR: repeated call {action}({argument})"
            traj.stop_reason = "no_progress"
            return traj
        seen.add((action, argument))
        step.observation = tools[action](argument)               # 3. ACT
        messages.append(Message(role="assistant", content=completion.text))
        messages.append(Message(role="tool", content=step.observation))  # 4. OBSERVE
    traj.stop_reason = "step_cap"
    return traj
```

Now the commentary. The file's own comments say *what*; this says *why*, and each note is a decision you will make again in Phase 3.

**Observations are text, so tools return strings.** The *shape* of that string is a design decision with token consequences — an observation is billed once per remaining step. **A bad argument returns an error string rather than raising**, which is the important one: an exception kills the episode, an error string becomes an observation the model can read and respond to. Tools report failure *into* the loop, because the loop is where recovery can happen — "verification is the lever" at the smallest scale. **Arguments are normalised** for whitespace, quotes and case, because models produce `headcount("support")`, `headcount( Support )` and `headcount(support)`, and refusing to fail on a difference that does not matter is what Anthropic's agent–computer-interface advice amounts to: make the tool hard to use wrongly.

**`HEADCOUNT` holds all four of Northwind's departments and sums to its stated 38 people**, and a test asserts it. If the spec says four and the code knows three, the spec is decoration and a student asking about operations gets a spurious "unknown department."

**`StopReason` is a closed `Literal`** because a stop reason is the first thing you read in a failed trajectory and a typo'd string would be invisible. **`Step.action` is a plain `str`**, though, because the model can name a nonexistent tool and recording that is the point of having a trajectory. **`stop_reason` defaults to `"step_cap"`** — the pessimistic value — so a path that forgets to set it reports the safe answer: defaults should fail closed. **Token totals are `computed_field`, not bare `@property`**, because a plain property is absent from `model_dump()`, and two of this phase's eval checks name `trajectory.prompt_tokens`. If a value is part of the contract, serialise it (invariant 11).

**The instructions do four jobs:** state the role, specify the output grammar, specify *when to stop*, and enumerate valid arguments. The third is what most people forget, and §8 is a trace of the consequence. The department list is derived from `HEADCOUNT` rather than typed, so prompt and environment cannot drift.

**`parse_action` is pure** — Phase 0's transport/parsing split one level up, which is why nine tests target it and run in microseconds. It scans *lines* and takes the first directive, because models prepend chatter and a strict parser fails on usable output; and it does not know which tools exist, returning whatever name the model wrote so the loop checks membership — meaning it needs no change when Phase 3 adds tools. The unclosed-bracket case parses because `rsplit(")", 1)[0]` returns the whole string when there is no bracket: an accident of the implementation, now a *test*, which converts an accident into a guarantee.

**It is a `for` loop, not a `while` loop.** The most important line in the file. `for n in range(1, max_steps + 1)` makes non-termination **structurally impossible** — you cannot write a bug that runs forever, because the language will not let you. A `while True` with a break is equivalent in behaviour and strictly worse in guarantee. Prefer constructions where the property you want is enforced by the language rather than by your care.

**The step is appended before we know if it is any good** — build, append, *then* branch. Appending only on success leaves failed trajectories missing their most interesting row: record first, judge second.

**There are four exits and the model controls one.** The model can say `final`; your code owns `bad_action`, `no_progress` and `step_cap`. This is the concrete meaning of "the model never executes anything": it is one voter on termination, with a minority stake.

**Roles interleave: `assistant` then `tool`, in that order.** The percept sequence must pair actions with their results or the model cannot tell which observation answered which action. A test asserts the exact sequence `["system", "user", "assistant", "tool"]` on the second call, because getting this wrong produces plausible output and wrong behaviour.

**`tools` is an injected parameter, not a global** (invariant 10), so a test passes `{"echo": echo}` and asserts what was called with no monkeypatching. **`seen` holds `(action, argument)` pairs, not names** — `headcount("sales")` after `headcount("support")` is progress, the same call twice is not. **`max_steps` defaults to 6**, not fifty, because §6.7 says a longer loop is a slower way to fail; if you raise it to make a task work, the task needs decomposing.

### Run it

```bash
make test-offline        # 53 passed
```

To watch it work, offline:

```python
from atlas.llm import FakeLLMClient
from atlas.agents.minimal import run_minimal_agent

client = FakeLLMClient([
    "ACTION: headcount(support)",
    "ACTION: headcount(sales)",
    "FINAL: Support has 9 people and sales has 6, so support is larger by 3.",
])
traj = run_minimal_agent(client, "How many in support, and is that more than sales?")
for s in traj.steps:
    print(f"step {s.n}: {s.action}({s.argument}) -> {s.observation!r}")
print(traj.stop_reason, "|", traj.answer)
print("prompt tokens per step:", [s.prompt_tokens for s in traj.steps])
```

which prints exactly:

```
step 1: headcount(support) -> 'support headcount = 9'
step 2: headcount(sales) -> 'sales headcount = 6'
step 3: final(Support has 9 people and sales has 6, so support is larger by 3.) -> None
final | Support has 9 people and sales has 6, so support is larger by 3.
prompt tokens per step: [53, 59, 65]
```

That last line is §6.3 in miniature: the prompt grows by six every step — four words of observation plus two of action — and a test asserts the monotonicity. Note these are *word counts*, because `FakeLLMClient` splits on whitespace. They demonstrate the shape, not the magnitude; that is also why `make results` refuses to write Tier F numbers into `docs/RESULTS.md`.

### What scripted fixtures prove, and what they do not

Read this twice; misunderstanding it is the commonest way students misjudge their own progress. Every test in `tests/test_minimal_agent.py` feeds the loop a hand-written script and asserts what the loop does with it. That proves **your code handles that input correctly** — today, after any refactor, on any machine, in a tenth of a second with no network. A real guarantee: a change that breaks the role ordering, drops the progress guard, or forgets to record a failed step is caught immediately by someone not paying attention. What it does **not** prove, in any degree, is that a real model ever produces those strings. `test_loop_stops_when_the_model_repeats_an_action` proves your guard fires on repetition; it says nothing about how often repetition happens. That second question is *model behaviour* — data, not a test — measured by `make results` and recorded with tier, model and seed in `docs/RESULTS.md`. **Confusing "my tests pass" with "my agent works" is the characteristic error of this field.**

### With an assistant

**Safe to delegate.** The test file — thorough parametrised cases for `parse_action` are exactly the mechanical breadth an assistant is good at, and you can verify every case by reading it. Also the JSON round-trip test, docstring polish, and asking it to *critique* your termination logic. That reversal — using it as an adversary rather than an author — is the highest-value way to use one.

**Not safe to delegate.** The loop's control flow. Not because an assistant would write something broken, but because the four exits, their ordering, and record-before-judge *are* the lesson, and code you did not choose is code whose invariants you do not know. In Phase 8, debugging a trajectory that terminated for the wrong reason, you will need to know why `no_progress` is checked *before* `seen.add`. Also not safe: `docs/ATLAS_SPEC.md`. It is a document about *your* judgement, and an assistant will produce a fluent, generic version that commits you to nothing.

**One prompt that works:**

> Here is my agent loop. Do not rewrite it. Instead, list every input sequence — model outputs, tool results, arguments — that would cause it to (a) not terminate, (b) terminate with the wrong `stop_reason`, or (c) lose information a debugger would need. For each, give the shortest `FakeLLMClient` script that triggers it. Then stop; I will write the tests.

Note the shape: it asks for failure modes and reproductions, forbids rewriting, and hands the fix back to you. Compare "write me an agent loop," which produces code you cannot defend.

---

## 8. [core] Debug this trace

A real trajectory, printed verbatim from running `run_minimal_agent` **with the progress guard removed**, on a script where the model returns the same action six times.

```
=== TRAJECTORY ===
step 1: action=headcount(support)  obs='support headcount = 9'  prompt_tokens=55 completion_tokens=2
step 2: action=headcount(support)  obs='support headcount = 9'  prompt_tokens=61 completion_tokens=2
step 3: action=headcount(support)  obs='support headcount = 9'  prompt_tokens=67 completion_tokens=2
step 4: action=headcount(support)  obs='support headcount = 9'  prompt_tokens=73 completion_tokens=2
step 5: action=headcount(support)  obs='support headcount = 9'  prompt_tokens=79 completion_tokens=2
step 6: action=headcount(support)  obs='support headcount = 9'  prompt_tokens=85 completion_tokens=2
stop_reason = step_cap
answer      = None
prompt_tokens total = 420  completion total = 12

=== FINAL PERCEPT SEQUENCE (message list on the 6th call) ===
[0] system: 'You answer questions about company staffing using one tool.\nReply with exactly one line, in one of these two forms:\n  ACTION: headcount(<department>)\n  FINAL: <your answer>\nOnce a tool result gives you what you need, reply with FINAL.\nKnown departments: engineering, operations, sales, support.'
[1] user: 'How many people are in support, and is that more than sales?'
[2] assistant: 'ACTION: headcount(support)'
[3] tool: 'support headcount = 9'
[4] assistant: 'ACTION: headcount(support)'
[5] tool: 'support headcount = 9'
      ... pairs [6]-[7], [8]-[9], [10]-[11] are byte-identical to [4]-[5] ...
```

**Read it before continuing.** What went wrong, and where does the fix belong?

### Diagnosis

**Symptom.** The user got nothing. `answer` is `None`, `stop_reason` is `step_cap`, and 420 prompt tokens across six calls bought exactly zero information the first step had not produced.

**What is *not* the bug.** The loop terminated. Notice how much worse this would be under `while True`: identical output, forever, until someone noticed the process. The step cap converted an unbounded failure into a bounded one — which is what a backstop is for, and *only* what it is for. **Reaching your step cap is never a success and should never be routine.** Also not the bug: the tool worked perfectly, six times.

**The first wrong step is step 2.** In a trace with six identical rows, the interesting one is the *earliest* anomaly, not the last. By step 2 the model had `support headcount = 9` at position [3], had everything it needed for the first half of the question, and re-asked anyway. Everything after step 2 is consequence, not cause.

**Two defects, at different layers.** *In the harness — no progress guard.* The loop had no notion of progress, so it could not distinguish "working through a multi-part question" from "stuck," and kept paying for calls that could not in principle add information: the state at step *k* differed from step *k−1* only by an assistant message and a tool result byte-identical to ones already present. **A step that adds no new information to the percept sequence cannot change the next decision except by noise.** That is a structural property, checkable in code, and the harness was not checking it. *In the policy — stopping was not made easy.* The prompt does say to reply FINAL once a tool result suffices, but the question was two-part and the instructions gave no guidance on multi-part questions, no worked example, and no statement that the tool takes one department at a time. Worse, the repeated action is now in context five times over, and a context full of a pattern is a context that predicts more of that pattern. The trajectory became self-reinforcing.

### Fix

Both defects are real. **Only one is worth fixing first, and it is the harness.** The reasoning generalises to nearly every agent bug.

A prompt fix changes the policy. It might work with this model, at this temperature, on this phrasing. It cannot be tested offline, because testing it requires the model. It needs re-validating on every model change. And decisively, **it does not bound the damage** — a better prompt makes the failure rarer, not cheaper.

A harness fix changes code. It is deterministic, testable with a scripted fixture in milliseconds, holds for every model, and **bounds the damage regardless of how the policy behaves.** Hence: fix control-flow problems in the dispatcher, not the prompt (`docs/DECISIONS.md`, D-02).

The fix is the guard already in the file, placed after the unknown-tool check and before `seen.add`:

```python
# excerpt: atlas/agents/minimal.py
        if (action, argument) in seen:
            step.observation = f"ERROR: repeated call {action}({argument})"
            traj.stop_reason = "no_progress"
            return traj
        seen.add((action, argument))
```

Same script, fixed loop:

```
step 1: headcount(support) -> 'support headcount = 9'
step 2: headcount(support) -> 'ERROR: repeated call headcount(support)'
stop_reason = no_progress | steps = 2 | prompt_tokens = 116
```

Two steps instead of six; 116 prompt tokens instead of 420, a 72% reduction. And far more valuable than either: a `stop_reason` that names the actual problem. Compare debugging `step_cap` ("something went wrong somewhere and I have no idea what") against `no_progress` ("the model repeated itself; look at the instructions or the observation format"). **A well-chosen stop reason is the cheapest diagnostic instrument you will ever build.**

Three things about the ordering, because placement is not arbitrary. The check comes *before* `seen.add`, or the first call of every action would trip its own guard. It comes *after* the unknown-tool check, so a nonexistent tool reports `bad_action` rather than being masked by a later repeat. And the failed step keeps an observation explaining itself, so the trajectory is self-documenting.

**And the prompt fix, second.** With damage bounded, improving the instructions is a cheap optimisation rather than a load-bearing safety measure. Adding "the tool accepts one department at a time" and a two-line example is a reasonable next move — but you would now measure it with `make results` on Tier A, record before-and-after in `docs/RESULTS.md` with model and seed, and know that if it does not help, nothing catastrophic follows.

**Note for later phases.** Returning on the first repeat is deliberately strict for Phase 1. A production dispatcher would more likely feed the error back as an observation and allow a bounded number of repeats, since a model that repeats once often recovers when told so. That is a Phase 3 change; it will be an *addition* to `StopReason`, not a modification, and will arrive with its own fixtures.

> **Concept check 1.10.** The trace shows `completion_tokens=2` constant while `prompt_tokens` climbs 55 → 85. Explain both patterns, and say which dominates cost in a real fifteen-step episode.

> **Concept check 1.11.** Suppose the model had alternated `headcount(support)` and `headcount(sales)` forever with no `FINAL`. Would the `seen` guard catch it? What would stop the loop, and with what `stop_reason`? What does this tell you about the limits of a set-membership progress guard?

---

## 9. [core] Common pitfalls & how professionals avoid them

**Calling it an agent when it is a workflow.** Symptom: a design conversation where nobody can say what the system would do differently on an unforeseen input. Practice: try to draw the flowchart before writing code. If you can, build the workflow — cheaper, faster, testable. Reserve "agent" for when the drawing genuinely fails.

**Budgeting cost linearly in step count.** Symptom: a bill three times your estimate. Practice: use the quadratic formula. Assignment 1 makes it a function you can call.

**Setting `max_steps` by superstition.** Symptom: `max_steps=50` because it "seemed safe." Practice: derive it. Two constraints bound it — context length (§6.3) and reliability target (§6.7) — and the smaller wins. If the derived number is too small, decompose the task.

**Treating the step cap as the progress guarantee.** §8 is this pitfall. Practice: every loop needs at least one *semantic* exit beside the cap, and hitting the cap is logged as an anomaly, never a normal ending.

**Fixing control flow in the prompt.** Symptom: a system prompt grown paragraphs of "do not repeat yourself." Practice: D-02. Bound it in code first; measure prompt changes second.

**Building capability before the performance measure.** Symptom: being unable to answer "is it better than last week?" Practice: Phase 3 before Phase 4, and eval tasks every phase. Rationality is relative to a performance measure, so an agent without one cannot be assessed at all.

**Letting a value live only on a bare `@property`.** Symptom: an eval check that silently never matches. Practice: invariant 11 — anything a check can name must survive `model_dump()`. This bit *this document*, in review, on `trajectory.prompt_tokens`.

---

## 10. [extended] Industry perspective

Three patterns recur in teams that ship agents, all unglamorous.

**They spend effort on the agent–computer interface, not the prompt.** Anthropic's December 2024 post reports spending more time optimising their SWE-bench agent's tools than its overall prompt — the absolute-paths example being the concrete case. The move is *poka-yoke*: change the tool so the mistake becomes impossible rather than discouraged. A better use of a week than prompt iteration.

**They convert model problems into code problems.** A budget, a step cap, schema validation, a repeat detector, an approval gate: each takes an unbounded behavioural risk and gives it a bounded, testable shape. The trade is honest — ceiling on capability for a floor on cost and blast radius. Teams that ship choose the floor.

**They pay for verification.** The strongest agent products all have a cheap automatic checker in the loop: a test suite, a schema, a resolution signal, a citation a human can click. Where none exists, mature teams build one, insert a human, or decline the project.

The main open trade-off, stated as a trade-off rather than an answer: **frameworks.** Anthropic's guidance is to start with the API directly and understand the code under any framework, because abstraction layers obscure the prompts and responses you need to debug. The counter-argument is real — frameworks encode community practice and save weeks of plumbing. This book's framework-free-through-Phase-8 line is a teaching choice, not a claim that hand-rolling wins in production.

**Interview questions.** (1) Distinguish workflow from agent, place a system you have built on the spectrum, and say what moving it up one level would cost. (2) Your agent averages fifteen steps; estimate end-to-end success at 97% per-step and describe two changes that beat a better model. (3) Why is prompt cost quadratic in step count, and what does that imply about tool output design? (4) An agent re-calls the same tool until it exhausts its budget: give a prompt-level fix and a harness-level fix, and say which ships first. (5) You are asked to build an agent that emails customers about late deliveries — what do you ask before agreeing, and when would you refuse?

---

## 11. [core] Capstone increment

**If your code diverged, start again from `atlas_phase_00.zip`.**

**Resume note.** At `phase-00` Atlas was a seam and a skeleton: `atlas/config.py`, `atlas/llm.py`, four tiers, 28 offline tests, three eval definitions, and no reason to call the model twice.

**What Atlas can do now.** Run a bounded agent loop over one fake tool, on any tier, recording a complete trajectory with per-step token accounting, terminating for one of four *named* reasons — three owned by the harness. And it has a written specification: who it serves, what it must never do, which actions need a human, how success is measured, and on whose authority it acts.

### Interface changes

None to any existing name, signature or default. `ATLAS_INTERFACES.md` moves to **v0.4** by *addition*: three new modules; four new invariants (9 termination is owned by the harness; 10 tool maps are injected; 11 anything an eval check names must survive `model_dump()`; 12 the repo is a real git repository with `phase-NN` tags); a contract-documents table; and a `PHASE` variable so `results`/`record`/`demo`/`grade` point at each phase's files without the target names ever changing. **Migration note:** `Trajectory.prompt_tokens` and `.completion_tokens` are now `computed_field`. This is additive at the Python call site — `traj.prompt_tokens` is unchanged — but it *adds two keys* to `model_dump()`. Any consumer asserting an exact key set must be updated; nothing in the repo does.

### Files touched

| File | Change |
|---|---|
| `atlas/agents/minimal.py` | **new** — `StopReason`, `HEADCOUNT`, `headcount`, `SYSTEM`, `Step`, `Trajectory`, `parse_action`, `run_minimal_agent` |
| `atlas/agents/budget.py` | **new** — Assignment 1 stubs, contracts in the docstrings |
| `atlas/agents/guarded.py` | **new** — Assignment 2 stub |
| `tests/test_minimal_agent.py` | **new** — 25 Tier F tests |
| `tests/hidden/test_phase01_a1.py` | **new** — 57 hidden checks |
| `tests/hidden/test_phase01_a2.py` | **new** — 17 hidden checks |
| `evals/tasks/phase01.json` | **new** — 3 tasks (total now 6) |
| `scripts/phase01_results.py` | **new** — `make results`; refuses to append Tier F word counts |
| `scripts/check_docs.py` | generalised from one hard-coded document to every `phase_*.md` |
| `Makefile` | `PHASE ?= 01`; phase-scoped `grade` plus `grade-all`; cumulative `evals` |
| `docs/ATLAS_SPEC.md` | **new** — the specification |
| `docs/DECISIONS.md` | **new** — D-01 to D-03 |
| `docs/FAILURE_LOG.md` | one worked entry, demonstrating the format before Phase 3 requires five |
| `ATLAS_INTERFACES.md` | v0.2 → v0.4 |
| `VERSIONS.md` | Phase 1 delta rows (§19) |
| `README.md` | state at `phase-01`; assignment table |
| `.git/` | **new** — real repository, `phase-00` and `phase-01` tags |

### Tests added

25 offline tests, 28 → **53**. Nine target `parse_action`; six drive one exit each; three check role ordering and monotonic growth; two check that token totals survive serialisation and that the tool covers every department the spec claims. All Tier F, no network.

### +3 eval tasks

`p01-loop-terminates-on-final` — a scripted act-then-answer episode terminates as `final` in exactly two steps with the right observation recorded. `p01-progress-guard-beats-step-cap` — a repeating model is stopped by the guard at step 2, not the cap at step 6, with `trajectory.prompt_tokens < 420`. `p01-prompt-grows-monotonically` — across three steps the prompt count rises, encoding §6.3 as a check rather than a claim. All three `deterministic`/`tier F`, all runnable by the Phase 3 harness.

Two things to notice in the file. `setup.entrypoint` (`module:callable`) and `setup.max_steps` are schema additions documented in v0.4. And 420 is not arbitrary — it is the buggy loop's cost from §8, so the check encodes *the regression the guard prevents*.

### `make results` and the expected ranges

```bash
make record     # run the loop on your configured tier, print ranges
make results    # the same, appending rows to docs/RESULTS.md (Tier A/H only)
```

Four staffing questions with `max_steps=6`. The Tier F run is reproducible for everyone: median 2.5 steps, 104–248 prompt *words*, 4/4 resolved — and it deliberately **refuses** `--append-results`, because writing word counts into `RESULTS.md` would put a non-measurement into the file whose purpose is measurements.

On **Tier A** (the `VERSIONS.md` model, `temperature=0`, `seed=7`, 16 GB no GPU) — **every figure below is an author estimate, unmeasured.**

| Metric | Expected range (Tier A) | Notes |
|---|---|---|
| Steps to terminate, median | 2–4 | Task 3 needs three tool calls plus a `FINAL` |
| Resolved with `FINAL` (of 4) | 2–4 | Task 4, the unknown department, is likeliest to loop or break format |
| `no_progress` / `bad_action` stops | 0–2 of 4 | Format adherence on a small model is the binding constraint, not reasoning |
| Prompt tokens per episode | 400–1,800 | Real tokenization, unlike Tier F's word count |
| Wall-clock per episode | 8–45 s | Dominated by decode; multiply by steps |
| Per-step latency trend | flat or rising | Flat implies your runner reuses the KV cache; rising implies re-prefill |

Two things to watch. Whether task 4 ends in `final` (the model reads the tool's `ERROR:` string and reports honestly), `no_progress` (it re-asks) or `bad_action` (it breaks format) — that comparison tells you more about your model's readiness for Phase 3 than any benchmark. And whether per-step latency is flat, which decides whether quadratic token growth also costs quadratic *time*.

**Tier H** is not needed; no test requires it. `ATLAS_TIER=H make record` costs four episodes, well inside the cap. *[Tier H recommended]* only for the task-4 format comparison.

### `docs/FAILURE_LOG.md`

Phase 3 begins the five-trace requirement; this phase seeds the format with the §8 trace written up properly — task, what it did, the *first* wrong step, hypothesis, fix, and the generalisation into a risk and an eval task. That last line, where a one-off failure becomes a permanent check, is the habit the log exists to build.

**Repo tag:** `phase-01`, a real tag on a real repository: `git ls-tree -r phase-00` shows only an empty `atlas/agents/__init__.py`, while `phase-01` adds `minimal.py`, `budget.py` and `guarded.py`, so Appendix F's deferred builds have somewhere to branch from.

---

## 12. [core] Mastery checklist

You are ready to move on if you can: define the six R&N terms and map each to your own code, unaided; draw the four-arrow loop with both exits and name each arrow's token, latency and risk cost; explain why prompt cost is quadratic and compute both the total and the overflow step for given *p₀* and *g*; derive 0.95²⁰ ≈ 0.36 by squaring and state the step allowance at *p* = 0.95, 0.99 and 0.995; give three reasons the independence assumption fails and the response to each; place any described system on the spectrum by naming who chooses the next action; give an example of a many-step workflow and a two-step agent; name the eight components and say which one a given bug lives in; write the loop from scratch with four correctly ordered exits and explain why `for` beats `while True` and why the step is recorded before it is judged; read a repeating trajectory, identify the earliest anomalous step, and say why the fix belongs in the harness; apply the two-question test to a proposal and reach a defensible verdict; and answer, from your own `docs/ATLAS_SPEC.md`, on whose authority Atlas acts and what it must never do.

---

## 13. [core] Quiz

Questions only; worked answers in `phase_01_solutions.md`.

**Q1.** State the agent function / agent program distinction, explain why an LLM agent makes it unusually visible, and name the one thing an LLM agent has that a classical reflex agent does not.

**Q2.** A colleague's agent "gets slower and slower and then just stops working after about a dozen steps." Give the two most likely causes, say which arrow of the loop each belongs to, and describe the one measurement that distinguishes them.

**Q3.** Both systems make six model calls. A: classify, then follow one of four hand-written branches, each calling the model once more. B: offer three tools and loop until the model says it is done. Which is the agent, why, and which would you expect to be cheaper at the ninety-fifth percentile of latency? Justify the second answer separately from the first.

**Q4.** You measure per-step success at 0.96 and need 85% end-to-end. What is your maximum step count? Your design needs eleven steps. Give three distinct interventions, ranked by expected effect, and say what each costs.

**Q5.** Explain, in terms a project manager would accept, why "we will fix the looping by improving the prompt" is the wrong first move, and what the right first move is. Then name the one circumstance in which the prompt fix genuinely is right first.

**Q6.** The two-question test says an agent works where verification is cheaper than generation and mistakes are reversible. Give one real task satisfying the first but violating the second, and one the other way round. For each, name the design change that makes it shippable.

---

## 14. [core] Coding assignments

Two assignments. Each has acceptance criteria, an UNAIDED CORE you write yourself, and a hidden test file you run with `make grade` (Phase 1 only) and are told not to read. If a hidden test fails, write your own failing test reproducing it *before* changing anything — that habit is worth more than the assignment.

### Assignment 1 — the budget arithmetic **[fast track: do this one]**

Implement the four pure functions in `atlas/agents/budget.py`. The full stub with contracts is in the zip; the signatures are:

```python
# excerpt: atlas/agents/budget.py
def prompt_tokens_for_episode(n: int, p0: int, g: int) -> int:
def max_steps_in_context(num_ctx: int, p0: int, g: int) -> int:
def episode_success(p: float, n: int) -> float:
def max_steps_for_target(p: float, target: float) -> int:
```

Together they turn §6.3 and §6.7 from prose you nodded at into a tool you can point at a design.

**Acceptance criteria.**

1. `make test-offline` still passes (53) — you touched nothing else.
2. `prompt_tokens_for_episode(10, 600, 350) == 21750` and `(20, 600, 350) == 78500`.
3. `max_steps_in_context(4096, 600, 350) == 10` and `(4096, 800, 500) == 7`; `0` when even step 1 overflows; `-1` when `g == 0` and step 1 fits.
4. `max_steps_for_target(0.95, 0.90) == 2`, `(0.99, 0.90) == 10`, `(0.995, 0.90) == 21`, `(0.999, 0.90) == 105`; `-1` when `p == 1.0`.
5. `episode_success(0.95, 20)` within 1e-9 of 0.3584859224085419.
6. Every function raises `ValueError` out of domain.
7. `max_steps_for_target` and `episode_success` agree **exactly**: for the returned *n*, `episode_success(p, n) >= target` and `episode_success(p, n+1) < target`.
8. `max_steps_for_target` runs in **bounded time for every legal input**. `max_steps_for_target(0.9999999, 0.90)` must return 1053605 in well under a second. Iterating from `n = 0` and multiplying satisfies criterion 7 but takes over a million iterations, and is rejected.

**UNAIDED CORE.** `max_steps_for_target`, including its floating-point trap. `int(log(target)/log(p))` is off by exactly one **at the boundaries where `target` is itself a power of `p`** — try `p = 0.9, target = 0.81`: the true answer is 2, because `0.9 ** 2` equals `0.81` and the postcondition is `>=`, but the log ratio evaluates to slightly under 2.0 and truncates to 1. (I measured this: 91 such disagreements for `p ∈ {0.5…0.999}`, `k ≤ 40`, always by one. And note `p = 0.9, target = 0.9` is *not* one of them — an earlier draft of this book used it as the example and was wrong.) So estimate with logarithms in O(1), then correct with a bounded loop comparing `p ** n` against `target` directly — which is also what makes criteria 7 and 8 hold simultaneously. Write the test that catches the off-by-one before you write the fix.

**Hidden tests:** `tests/hidden/test_phase01_a1.py` (57 checks).

### Assignment 2 — two guards the Phase 1 loop lacks **[extended]**

Implement `run_guarded_agent` in `atlas/agents/guarded.py`. It behaves exactly like `run_minimal_agent` and adds two exits.

**`cycle`.** The Phase 1 guard keys on `(action, argument)`, a *proxy* for what we care about: whether the step added information. Two distinct calls can return the same observation — arguments that normalise identically, or two tools that agree. Key on the observation instead: when a step produces an observation byte-identical to an earlier one, stop with `cycle`, leaving the real observation in place unaltered.

**`token_budget`.** After the step completes, if cumulative prompt plus completion tokens reach the budget, stop with `token_budget`. `None` means no budget. This is an *episode* budget — a different mechanism at a different layer from `VERSIONS.md`'s per-phase Tier H quota. Do not conflate them.

**Acceptance criteria.** (1) `make test-offline` still passes (53); `run_minimal_agent` unchanged. (2) Full parity on the four existing exits, with identical observation strings. (3) Two distinct actions on a constant-returning tool stop with `cycle` at step 2, and `steps[1].observation` holds the tool's real output, **not** an error string. (4) Two *different* tools returning the same string also cycle. (5) `no_progress` beats `cycle`. (6) `cycle` never fires on the first observation. (7) `token_budget=None` never fires; a generous budget never fires; `token_budget=0` stops after exactly one step. (8) Check order is exactly `final`, `bad_action`, `no_progress`, *tool runs*, `cycle`, `token_budget`, `step_cap`.

**UNAIDED CORE.** The ordering. Criteria 5, 6 and 8 are all statements about *where* each check sits relative to the others and to the two `seen` sets being mutated. Work it out on paper first — write the seven checks in order and mark, for each, which sets have been mutated by then. An assistant will produce something passing four of the eight criteria and you will not know which four.

**Hidden tests:** `tests/hidden/test_phase01_a2.py` (17 checks).

---

## 15. [extended] Case study: agent or workflow?

### The situation

**Corvus Instruments** is deliberately *not* Northwind: 420 people, three sites, mid-size sensor manufacturer, IT team of four. Scale changes the answer, which is the point of using a different company. Corvus processes **warranty claims** — roughly 2,400 a month by email, handled by five people. The process, timed by the team lead:

1. Read the email; identify product model and serial number. *(~2 min; present in about 85% of emails, phrased freely.)*
2. Look up the serial in the warranty database for purchase date and term. *(~1 min; unambiguous once you have a serial.)*
3. Decide whether the claim is in-warranty. *(~1 min; a date comparison, except three product lines had an extended-term promotion for eight months in 2024.)*
4. Classify the described fault into one of eleven categories. *(~3 min; genuinely judgemental — customers describe symptoms, not causes.)*
5. If in-warranty and the fault is one of four common categories, generate a returns label and send it. *(~2 min.)*
6. Otherwise, or if the customer disputes an out-of-warranty determination, escalate to an engineer with a summary. *(~5 min, about 30% of claims.)*
7. Log the outcome. *(~1 min.)*

Roughly 15 minutes per claim: **600 hours a month across five people.** Errors happen: an in-warranty claim wrongly declined generates an angry escalation about twenty times a month; a label sent to the wrong address perhaps twice a month.

The COO has read about agents and asks you to "build an agent for warranty claims."

### Your task

A design memo of 600–900 words. (1) **Decompose:** for each of the seven steps, is the control flow knowable in advance, does a cheap verifier exist, is the effect reversible? (2) **Assign an autonomy level** per step and to the system, naming who chooses the next action each time. (3) **Identify what should not be automated at all**, and what happens to it instead. (4) **Place every irreversible action** and say what gates it, reconciling your answer with `ATLAS_SPEC.md` §4's prohibition on outbound third-party communication — respect it, or argue for amendment with a `DECISIONS.md`-style entry. (5) **State the performance measure**, with at least one zero-tolerance metric, each computable from a trajectory, baselined on the stated manual error rates. (6) **Estimate compounding-error exposure:** step count, an assumed per-step rate, the end-to-end figure, and a contingency. (7) **Give the honest downside** — something always is.

### Rubric (30 points, plus 3)

| Criterion | Pts | Full marks |
|---|---|---|
| **Decomposition quality** | 5 | Each step assessed on all three axes. Recognises step 2 is a deterministic lookup needing no model, and step 4 is the only step with genuinely unpredictable control flow. Does not treat the process as one blob. |
| **Autonomy placement** | 5 | Per-step levels with "who chooses next" named each time. Full marks require noticing the system is mostly **L1–L3** with at most a narrow loop, and saying so against the COO's framing. |
| **Refusal to automate** | 4 | Explicitly excludes step 6's escalation judgement and step 3's promotion edge case from model determination, with reasons — not merely flagging them as "hard". |
| **Irreversibility and gates** | 5 | Sending the label is correctly identified as the irreversible action. Full marks require engaging with the §4 prohibition rather than ignoring it: either a human sends, or a written amendment argues the case. |
| **Performance measure** | 4 | Metrics computable from a trajectory, with a zero-tolerance one (wrongly-declined in-warranty claims, or ungated sends), baselined against ~20 wrong declines and ~2 misdirected labels a month. |
| **Compounding-error arithmetic** | 4 | Correct arithmetic, stated step count, an explicit assumption about *p*, and a contingency. Full marks require noticing that a *short* design is why the arithmetic is survivable, not a coincidence. |
| **Honest downside** | 3 | A real cost named: latency on the 15% of emails missing a serial; brittleness to email-format change; loss of tacit pattern-spotting; maintenance burden on a four-person IT team. "It might make mistakes" scores 1. |

**Distinction (+3)** if the memo notices the highest-value intervention may not be an LLM at all: steps 2, 3 and 7 are database operations a script has always been able to do, and automating just those removes roughly a third of the 600 monthly hours at essentially zero new risk. Shipping that first, and measuring, is what a senior engineer proposes before building anything agentic. **A further note worth making:** at 2,400 claims a month, per-claim inference cost and latency matter in a way they would not at Northwind's 240 — which is why the company was rescaled.

A worked answer and filled rubric are in `phase_01_solutions.md`.

---

## 16. [core] Summary & key takeaways

*Self-contained. Paste this into the chat or notebook where you start Phase 2.*

**The classical definitions carry over almost intact.** Russell & Norvig (*AIMA* 4th ed., 2020, ch. 2): an agent perceives and acts; a **percept** is one input, the **percept sequence** the whole history, the **agent function** maps percept sequences to actions, the **agent program** implements it. In an LLM agent the percept sequence *is* the message list — **no hidden state whatsoever** — making it a reflex agent with a complete percept history that re-derives everything every step. Gift: total observability. Curse: **state and cost are the same variable.** **Rationality is relative to a performance measure**, so without evals "my agent behaves well" has no truth conditions; and an agent failing for reasons it could not perceive is not irrational, which is how to read traces fairly. The **policy** is model *plus* system prompt *plus* tool descriptions — edit any of the three and re-run evals. The **environment** is tools (yours), data (not yours, possibly adversarial, entering the prompt on equal footing with your instructions) and humans (inside it, not outside). An **episode** is what happened; a **trajectory** is the record, and it is simultaneously the state, the debugging artefact, the eval input and potential training data.

**Four arrows, four different costs.** Perceive costs the *entire* prompt *every* step, so the total over *n* steps is **n·p₀ + g·n(n−1)/2 — quadratic**: at p₀=600, g=350 that is 6,500 tokens for five steps, 21,750 for ten and 78,500 for twenty, and it overflows a 4,096 context at step 11, which is where a step cap actually comes from. Reason costs output tokens and decode latency. Act costs no tokens and carries **all** the irreversibility — risk ≈ probability wrong × cost of not undoing, which is what should decide whether an action needs approval. Observe costs tokens *permanently*, so tool return *shape* is an interface decision. Short loops win on cost, latency and safety at once; there is no trade-off to balance.

**Workflows versus agents (Anthropic, 19 Dec 2024): who wrote the control flow.** Workflows follow code paths laid down in advance; agents let the model direct its own process. The **augmented LLM** — one call with retrieval and tools available — is the base building block and suffices for many applications. The **spectrum L0–L6** is ordered by who chooses the next action, and the test is whether the action sequence could have been flowcharted before the input arrived; a hundred-step workflow is still a workflow, a two-step agent still an agent. **Autonomy is a cost, not a feature**, and the right level is the lowest that solves the task. Atlas is **L4, bounded agent** (D-01), deliberately not L5.

**Compounding error sets your step budget.** 0.95²⁰ = 0.3585, by squaring: 0.9025, 0.8145, 0.6634, 0.4401, then ×0.8145. Inverting *n ≤ ln T / ln p* for a 90% target: **p=0.95 buys 2 steps**, 0.99 buys 10, 0.995 buys 21, 0.999 buys 105 — so a twenty-step design asserts 99.5% per-step, which nobody has measured. Three ways the model is wrong: steps are *not* independent (context poisoning worse, recovery better); "per-step success" is undefined without a checker; and **failure need not be terminal** — a detectable, retriable 0.95 step effectively becomes 0.9975, the difference between 2 allowed steps and 21. **Verification is a far bigger lever than prompt quality.** Reach for fewer steps, then verification, then checkpoints, then prompting.

**The one principle: an agent works where verification is cheaper than generation and mistakes are reversible.** That is why coding agents worked first (tests plus version control) and unattended email does not.

**History, dated.** ReAct (6 Oct 2022) put reasoning in the context; Toolformer (9 Feb 2023) made tool use a trained behaviour; AutoGPT (30 Mar 2023) is the field's most instructive *negative* result; function calling (13 Jun 2023) moved parsing into the API contract; computer use (22 Oct 2024) widened the action space to a screen; MCP (25 Nov 2024) made the tool catalogue a protocol; "Building effective agents" (19 Dec 2024) named the split. The thread: **the field keeps relocating the loop's guarantees out of the prompt and into the protocol and the harness** — which is why control-flow bugs get fixed in code.

**Eight components:** model, instructions, tools, memory, orchestration, guardrails, evals, identity. Memory has two easily-confused halves. Guardrails and identity are properties of the *dispatcher*, so it needs one choke point. Evals come before capability.

**Repo state at `phase-01`.** `atlas/agents/minimal.py` — `Step`, `Trajectory` (token totals as `computed_field`, so they survive `model_dump()`), pure `parse_action`, and `run_minimal_agent`: a `for` loop, never `while True`, so non-termination is structurally impossible; **four named exits, three owned by the harness**; each step recorded *before* it is judged; tool map injected. **53 offline tests**, 6 eval tasks, `docs/ATLAS_SPEC.md`, `docs/DECISIONS.md` (D-01 to D-03), one worked `FAILURE_LOG.md` entry, `ATLAS_INTERFACES.md` v0.4 with twelve invariants, and a real git repo tagged `phase-00` and `phase-01`. Four assignments outstanding: Phase 0's `tier_report()` and `atlas/cache.py`, plus `atlas/agents/budget.py` (fast track) and `atlas/agents/guarded.py` (extended). `make grade` is scoped to one phase; `make grade-all` covers everything.

**Two debugging lessons to carry.** In a repeating trace, read the **earliest** anomalous step. And **fix control flow in the harness, not the prompt** — a prompt fix makes a failure rarer; a harness fix makes it cheaper and is testable offline.

**Phase 2 next:** the model as a reliable component — structured output validated against JSON Schema, retries on malformed output, and the Tier H budget counter that finally raises `BudgetExceeded`.

---

## 17. [core] Further reading

Read the first three; the rest are for when a specific question sends you there.

- **Anthropic, "Building effective agents" (19 December 2024).** <https://www.anthropic.com/engineering/building-effective-agents> — The workflow/agent distinction, the augmented LLM, five workflow patterns, and Appendix 2 on prompt-engineering your tools, which is the most immediately useful part. Note its own caveat that the tooling landscape has changed. **Start here.**
- **Russell & Norvig, *Artificial Intelligence: A Modern Approach*, 4th edition (Pearson, 2020), Chapter 2.** <https://aima.cs.berkeley.edu/> — Twenty-five pages that give you the vocabulary for your whole career. Read §§2.1–2.4. The third edition's chapter 2 is freely available if you cannot get the fourth.
- **Yao et al., "ReAct" (arXiv:2210.03629, 6 October 2022).** <https://arxiv.org/abs/2210.03629> — Use Phase 0's thirty-minute paper protocol. The appendix trajectories are the most valuable part; read them as traces, not results.
- **Schick et al., "Toolformer" (arXiv:2302.04761, 9 February 2023).** <https://arxiv.org/abs/2302.04761> — Skim the method; read §2 and the tool table.
- **OpenAI, "Function calling and other API updates" (13 June 2023).** <https://openai.com/index/function-calling-and-other-api-updates/> — Short. The moment parsing moved into the API contract, and the moment prompt injection was publicly acknowledged as open.
- **Anthropic, "Introducing the Model Context Protocol" (25 November 2024).** <https://www.anthropic.com/news/model-context-protocol> — Read now for the M×N framing; Phase 15 reads the specification.
- **Anthropic, "Introducing computer use…" (22 October 2024).** <https://www.anthropic.com/news/3-5-models-and-computer-use> — How wide an action space can get, and what that does to your guarantees.
- **OWASP GenAI Security Project.** <https://genai.owasp.org/> — The Top 10 for LLM Applications and the Top 10 for Agentic Applications (ASI01–ASI10). Editions and dates pinned in `VERSIONS.md`. Skim the agentic list now for vocabulary; read it properly at Phase 11.
- **Mitchell et al., "Fully Autonomous AI Agents Should Not be Developed" (arXiv:2502.02649, February 2025).** <https://arxiv.org/abs/2502.02649> — [extended] A dissenting position on the top of the spectrum, and a useful survey of how differently "agent" has been defined across five decades. An argument to engage with, not a conclusion to accept.

---

## 18. [core] SOLUTIONS

Full worked answers for the five cumulative review questions, all eleven concept checks, all six quiz questions, both assignments (reference implementations verified against all 74 hidden checks), and the case study with a filled rubric are in the companion document **`phase_01_solutions.md`**. Write your own answers first. The retrieval is the learning; reading a good answer produces the feeling of learning without the substance.

---

## 19. [core] HANDOFF

Confirmed: the updated **`ATLAS_INTERFACES.md` (v0.4)** and **`VERSIONS.md`** are both inside `atlas_phase_01.zip` at the repository root. Verified by extracting the zip to a clean directory and running `make test-offline` there: **53 passed**, with no network, no model and no `.env`. `make check-docs` passes, and it now has teeth: `atlas/agents/minimal.py` and `evals/tasks/phase01.json` appear as `# file:` blocks checked byte for byte against the repo.

**Files changed in the zip this phase:** the seventeen listed in §11's table — ten new modules, tests, eval and doc files plus `.git/`, and seven modified, including `ATLAS_INTERFACES.md` (v0.2 → v0.4).

### VERSIONS.md delta rows

```
## Corrections to Phase 0
| pytest-asyncio | 1.4.0 | Phase 8 (was listed as Phase 1 — corrected) | https://pypi.org/pypi/pytest-asyncio/json | 2026-09-03 |
| tenacity | 9.1.4 | Phase 2 (was listed as Phase 1 — corrected) | https://pypi.org/pypi/tenacity/json | 2026-09-03 |
| Tier H cap enforcement | deferred from Phase 1 to Phase 2 (Phase 1 needs no hosted calls) | ATLAS_INTERFACES.md v0.4 | 2026-09-03 |
| Ollama latest stable | v0.33.2 (2026-08-27) — re-verified, unchanged | https://github.com/ollama/ollama/releases | 2026-09-03 |

## Primary sources cited as history in Phase 1 (dated events, stable)
| Eight rows: ReAct, Toolformer, AutoGPT (secondary), function calling, computer use, MCP, "Building effective agents", AIMA 4th ed. | dates and URLs exactly as printed in section 6.5 and section 17 | see those sections | 2026-09-03 |

## Security guidance — current editions
| OWASP Top 10 for LLM Applications, current edition | 2026 edition, published 4 Aug 2026 | https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/ | 2026-09-03 |
| OWASP Top 10 for Agentic Applications, current edition | 2026 edition, published 9 Dec 2025; entries ASI01-ASI10 | https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/ | 2026-09-03 |
| Agentic entries referenced in Phase 1 | ASI01 agent goal hijack, ASI02 tool misuse, ASI03 identity and privilege abuse | https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/ | 2026-09-03 |
| OWASP Agent Control Standard (ACS) | published 1 Sep 2026 — forward pointer only, not used in this book | https://genai.owasp.org/resource/agent-control-standard-acs/ | 2026-09-03 |

## Anthropic guidance — currency caveat
| Status of "Building effective agents" (Dec 2024) | Still published, but now carries an editorial note that its tooling landscape has changed, pointing to newer managed-agents material | https://www.anthropic.com/engineering/building-effective-agents | 2026-09-03 |

## Phase 1 revision (2026-09-03) — corrections found by review
| Trajectory token totals | computed_field, not bare @property: bare properties are absent from model_dump() and two eval checks named them | ATLAS_INTERFACES.md v0.4, invariant 11 | 2026-09-03 |
| Naive int(log(target)/log(p)) off-by-one | Real, ONLY at target == p**k. Measured: 91 disagreements for p in {0.5..0.999}, k <= 40, always by one. p=0.9,target=0.9 is NOT such a case; an earlier draft used it as the example and was wrong | measured locally | 2026-09-03 |
| Multiply-up loop for max_steps_for_target | Rejected: 1,053,605 iterations at p=0.9999999, target=0.9. Bounded log+correction required | measured locally | 2026-09-03 |
| HEADCOUNT departments | Four (engineering 14, operations 9, sales 6, support 9 = 38), matching docs/ATLAS_SPEC.md. An earlier draft had three and contradicted the spec | docs/ATLAS_SPEC.md | 2026-09-03 |
| Tier F "prompt tokens" | Whitespace word counts from FakeLLMClient, NOT tokens. make results now refuses --append-results on Tier F | scripts/phase01_results.py | 2026-09-03 |
| Git repository | Present. phase-00 and phase-01 tags; phase-00 has only an empty atlas/agents/__init__.py, minimal.py first appears at phase-01 (git ls-tree) | this repo | 2026-09-03 |

## Added to known-unverified
| Per-step success rate of any model on tool selection | Never measured by me; every figure in §6.7 is illustrative arithmetic | Phase 3's eval harness |
| Whether your runner reuses the KV cache between agent steps | Runner- and build-specific; decides whether per-step latency is flat or climbing | make results, watch latency across steps |
| OWASP ASI entry titles | Taken from secondary summaries, not the PDF | Download the PDF |

## Phase 1 re-verification (2026-09-03)
Every pinned package version re-checked against PyPI; none changed since 2026-09-02
(pydantic 2.13.5, httpx 0.28.1, python-dotenv 1.2.3, pytest 9.1.1, pytest-asyncio 1.4.0,
tenacity 9.1.4, langgraph 1.2.11, langchain 1.3.18, mcp 2.1.1, openai 3.7.0, ollama 0.6.2,
uv 0.12.9, ruff 0.16.5). Phase 1 adds no dependency.
```

### Downloads

1. **`atlas_phase_01.zip`** — the complete updated repo, tag `phase-01`.
2. **`phase_01_from_llm_to_agent.md`** — this document.
3. **`phase_01_solutions.md`** — worked answers.

**On length, honestly.** This revision is **16,360 words** against a 14,000 ceiling. The previous draft was 19,645, so the overrun is down from 40% to 17% — but it is still an overrun and I am not going to describe it as compliance. Where the words went, and your route out of it:

- About 900 words are the printed source of `atlas/agents/minimal.py`. It is printed rather than described so `make check-docs` can verify it byte for byte against your repo — a guard the previous draft had but could not enforce, because every block was an excerpt. You already have this file; skim it.
- About 1,300 words are `[extended]`: §10 and §15. The fast track skips both, and nothing in `[core]` depends on them.

So a core-track reader reads roughly **14,200 words of prose**, which is the number the budget was really trying to constrain. Getting the *document* under 14,000 would now mean cutting §6.5 (the dated history), §6.6 (the eight components) or §15 (the case study) — all three explicitly required by this phase's brief. I would rather tell you the number than quietly drop mandated material, and if you would prefer the shorter version, §§6.5 and 6.6 compress to their tables with no loss of reference value.

Nothing was cut from §6.3 or §6.7. Every later phase depends on that arithmetic.

**Corrections made in this revision**, all found by re-reading the phase against its own brief:

| Was | Now | Why it mattered |
|---|---|---|
| `Trajectory.prompt_tokens` a bare `@property` | `computed_field` | It was absent from `model_dump()`, so two eval checks that name it would have silently never matched in the Phase 3 harness |
| Assignment 1's off-by-one example was `p=0.9, target=0.9` | `p=0.9, target=0.81` | The original is *not* an off-by-one case; it resolves correctly. The real cases are `target == p**k`, of which I measured 91 |
| Assignment 1 criterion 8 unsatisfiable by my own reference solution | Criterion restated; reference solution is log + bounded correction | The published solution took 1,053,605 iterations at `p=0.9999999` while the criterion demanded a few hundred |
| `HEADCOUNT` had three departments | Four, summing to the spec's 38 people, with a test | The spec claimed four; a spec the code contradicts is decoration |
| `make grade` ran every phase's hidden tests | Scoped to `PHASE`, with `grade-all` | It reported 69 failures across two phases' four assignments |
| `make results` appended Tier F word counts to `RESULTS.md` | Refuses on Tier F | It was writing non-measurements into the measurements file |
| No git repository | Real repo, `phase-00` and `phase-01` tags | "Repo tag" was aspirational, and Appendix F branches off those tags |
| A test named `..._never_exceeds_the_fixture_script...` asserting the opposite | `test_loop_raises_when_the_fixture_script_runs_out` | The name said the reverse of the assertion |
| Case study set at 38-person Northwind | 420-person Corvus, 2,400 claims/month | The brief asks for a mid-size company, and scale changes the answer |
| All code blocks were `# excerpt:` | `minimal.py` is `# file:` | `make check-docs` could not verify anything byte for byte |
