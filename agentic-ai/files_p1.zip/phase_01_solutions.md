# phase_01_solutions.md

Worked answers for Phase 1, "From LLM to Agent". Write your own first.

---

## Cumulative review (from Phase 0)

**CR1.** The principle: **adding a field to a published interface is free; changing one is not.** `tool_calls` cost a few lines and a fixture in Phase 0; adding it in Phase 3 would have meant touching `Completion`, both parse functions, `FakeLLMClient`, every fixture, and every caller that pattern-matched on the old shape — plus a migration note in `ATLAS_INTERFACES.md`. One concrete cost of omitting it: the two recorded tool-call fixtures (`ollama_chat_toolcall.json`, `openai_chat_toolcall.json`) would not exist, so the day you first needed to parse a real tool call you would be debugging normalisation *and* discovering the two providers disagree (object vs. JSON-string arguments) at the same time. Phase 1 repeats the move deliberately: `StopReason` declares `token_budget` and `cycle` before anything produces them.

**CR2.** They differ because the two providers report different things. Ollama's native response includes `eval_count` and `eval_duration` — the count and duration of *generation specifically*, in nanoseconds — so `eval_count / (eval_duration / 1e9)` isolates decode. The OpenAI-compatible response has no timing fields at all, only token counts, so you must divide by the latency *you* measured with a clock, which includes network transit, queueing at the provider, and prefill. **The Ollama formula measures the model; the OpenAI one measures the round trip.** Consequence: never compare tokens/sec across tiers as though they were the same quantity — a hosted number can look worse than a local one purely because it contains the network.

**CR3.** Any two of: floating-point non-associativity (summation order in matrix kernels varies with hardware and library version, so tiny differences appear and can flip a near-tie between two top candidate tokens); batching (your request being batched with others changes reduction order and therefore results); quantization build differences (the same tag rebuilt with a different quantizer produces different weights); hosted replica variation (different hardware behind one endpoint); and a changed context length or prompt-prefix caching altering the numerics of the prefill. `temperature=0` makes *sampling* greedy; it does not make *arithmetic* identical.

**CR4.** The error is treating requests-per-day as the binding constraint. Free tiers are usually limited on several axes at once and the tightest one governs. With a 200,000-token daily allowance and a typical agent prompt of ~2,000 tokens, you get about **100 calls per day**, not 1,000 — and the 8,000-tokens-per-minute limit caps you at roughly four such calls a minute regardless. They should have divided the **daily token allowance by their typical prompt size**. Phase 1 sharpens this: prompt size in an agent is not constant, it grows quadratically over an episode, so a five-step episode at *p₀*=600, *g*=350 spends 6,500 prompt tokens — about thirty single calls' worth.

**CR5.** It buys **a test suite that runs with no network, no model, no API key and no `.env`** — the parse functions are pure, so a recorded payload plus a number is a complete test input, and `make test-offline` passes on a fresh clone. What it does *not* buy: any assurance that the real endpoint returns the shape your fixture records. If a provider adds a field, renames one, or changes `null` handling, your tests stay green and production breaks. Fixtures are only as good as the day they were recorded, which is why Phase 0 recorded them from real responses and why `VERSIONS.md` dates everything.

---

## Concept checks

**1.1.** *Easy:* dump the message list — `[m.model_dump() for m in messages]` — and you have the agent's complete belief state at that instant, with nothing hidden. Any wrong belief is a wrong string you can point at. This is why §8's diagnosis reads the percept sequence directly. *Unavoidable failure mode:* **the state is the cost.** Because the whole history must be re-sent, context grows quadratically and eventually overflows, and you cannot fix this by "remembering better" — the only levers are fewer steps, smaller observations, or lossy trimming, and trimming *changes what the agent knows*. A system with compressed internal state pays a bounded, constant amount per step and never faces this trade-off. (Second acceptable answer: no hidden state means no way to hold a private commitment across steps, so a plan only persists if it is written into the context, where it also costs tokens and can be overwritten by later observations.)

**1.2.** **Not irrational.** Given its percept sequence — a search that returned nothing — reporting absence was the action with the best expected outcome. Rationality concerns expected success given what was perceived. The defect is real but it is not in the policy: it is a **sensor defect**, in the environment/indexing layer, and secondarily a **specification defect** — the system reported "does not exist" when its evidence only supported "not found in my index." The fix has two parts, neither of them a prompt change: make the index complete (or expose staleness), and make the tool's return string distinguish *empty result* from *unindexed*, so the model can say the honest thing. This is a small instance of the general rule: information the agent cannot perceive cannot be reasoned about, so fix the sensor.

**1.3.** (1) **You have changed the agent's beliefs**, silently and mid-episode. Dropping the observation that contained the answer means the model may re-request it, which is exactly §8's loop; you have manufactured the failure your progress guard exists to catch. (2) **You have destroyed the debugging record** for precisely the episodes most worth debugging — long ones. When that trajectory shows up as a failure you cannot see the dropped step, so you cannot find the earliest anomaly, and you cannot tell whether the model erred or your trimmer did. (Also acceptable: you have broken the eval input, since checks that reference `steps.3.observation` now index a different step; and you have made the trajectory non-reproducible, because replaying it no longer reconstructs the state that produced the next action.) The fix is the separation named in §6.2: trim what goes *to the model*, keep the *record* whole.

**1.4.** *p₀*=800, *g*=500, *n*=6. Total = 6·800 + 500·(6·5/2) = 4,800 + 500·15 = 4,800 + 7,500 = **12,300 prompt tokens**. Overflow: the prompt at step *n* is 800 + 500(n−1). Set 800 + 500(n−1) ≤ 4,096 → 500(n−1) ≤ 3,296 → n−1 ≤ 6.592 → n ≤ 7. So step 7 sends 800 + 3,000 = 3,800 (fits) and **step 8 sends 4,300, which exceeds 4,096.** The design has seven usable steps.

**1.5.** Baseline: 10·600 + 350·45 = 6,000 + 15,750 = **21,750**.
- *Halve the system prompt* (400 → 200, so *p₀* = 400): 10·400 + 350·45 = 4,000 + 15,750 = **19,750**. Saves 2,000.
- *Halve the observation.* Of *g* = 350, the observation is 270 → 135, so *g* = 215: 10·600 + 215·45 = 6,000 + 9,675 = **15,675**. Saves 6,075.
- *Halve the steps* (n = 5): 5·600 + 350·10 = 3,000 + 3,500 = **6,500**. Saves 15,250.

**Halving the steps wins by a wide margin, and halving the observation beats halving the system prompt threefold** — because the system prompt is multiplied by *n* while the observation is multiplied by *n(n−1)/2*. The general lesson: attack the term with the highest power of *n* first. Steps appear in both terms, which is why they dominate.

**1.6.** (a) **L0.** Your code chooses everything; each call is independent and the sequence is a loop *you* wrote over tickets. Many calls, zero model-chosen control flow. (b) **L2, arguably L3.** The retry is a fixed code path — your code decides to retry, your code decides to stop at three — so no decision was handed to the model. Called L2 because it is a chained sequence with a programmatic gate. (c) **L4.** The model chooses which of twelve tools and whether to continue; the harness owns the cap. (d) **L1.** The augmented LLM: one call, one optional tool, no loop.

**Your turn (b) argued both ways.** *For agentic:* it loops, the number of iterations is not known in advance, and the model's output determines whether another iteration happens — that is runtime-determined control flow. *For workflow:* the *branch structure* was written by a human. There is exactly one possible next action at every point ("retry the SQL"), the model never selects among alternatives, and the retry budget is in your code. **The deciding sentence: the model chooses the content of the action, not the identity of the action — so the control flow was knowable in advance and could be drawn as a flowchart before the input arrived. It is a workflow, L2.** Change it so the model may choose between "retry the SQL", "ask the user to clarify" and "give up", and it becomes L4 — because now it is selecting among actions.

**1.7.** *Function calling gives you:* a **machine-checkable contract**. Arguments arrive as structured data validated against a JSON Schema you supplied, so malformed actions are largely eliminated at the provider rather than caught by your regex, and the model has been trained on the format so adherence is far better. (Also: unambiguous multi-call and call-ID handling, and no risk of a tool name colliding with prose.) *The text convention retains:* **portability and legibility**. It works on any model, including one with no tool-calling capability at all, needs no provider support, and puts the action in the *same token stream as the reasoning* — which is the ReAct insight, and it means the model's reasoning conditions the action directly and both are visible in one string when you read the trace. Phase 1 uses the text convention for exactly these reasons: it runs on any Tier A tag, and the trace in §8 is readable without a JSON viewer.

**1.8.** By squaring: 0.9² = 0.81. 0.9⁴ = 0.81² = 0.6561. 0.9⁵ = 0.6561 × 0.9 = **0.59049**. So a five-step design on a step that works nine times in ten succeeds **about 59% of the time** — it fails more than two attempts in five. Implication: a "pretty reliable" step is not reliable enough for five steps. To reach 90% end-to-end you would be allowed **one** step at *p*=0.9 (from §6.7's table). Either raise *p* by adding a verifier, or cut to one or two steps, or accept a 59% product.

**1.9.** (a) 0.97¹² = **0.6938**, about 69%. (Squaring: 0.97²=0.9409, 0.97⁴=0.8853, 0.97⁸=0.7838, ×0.97⁴ = 0.7838×0.8853 = 0.6938.)
(b) *Cut to eight steps:* 0.97⁸ = **0.7838**, about 78%. A 9-point gain, cheap, and it also cuts cost superlinearly — total prompt tokens fall by roughly half.
*Add a verifier to three steps:* those three go from 0.97 to about 1 − 0.03² = 0.9991 each. End-to-end ≈ 0.97⁹ × 0.9991³ = 0.7603 × 0.9973 = **0.7583**, about 76%. Note the verifier costs extra model calls, so cost and latency *rise*.
**Ship the eight-step design.** It wins on success rate, cost and latency simultaneously — and it is available today, whereas the verifier is new code with its own failure modes. The deeper reason: verification helps most when it is *cheap and automatic* (a test suite, a schema check), and helps least when it is another model call, because you are then composing more unreliable steps to patch unreliable steps. Full marks also for noticing you could do both, and for asking the prior question: *is 0.97 measured or assumed?*

**1.10.** *`completion_tokens=2` constant:* the model emits the same 26-character line every step, and Tier F's `FakeLLMClient` counts words — `"ACTION: headcount(support)"` is two whitespace-separated tokens. Output size is set by the *action grammar*, which is fixed and short by design, so it does not grow. *`prompt_tokens` climbing 55 → 85 by 6 each step:* each step appends the assistant line (2 words) and the observation `"support headcount = 9"` (4 words) — 6 words, re-sent on every subsequent call. **In a real fifteen-step episode prompt tokens dominate overwhelmingly**, because output is roughly constant per step (linear in *n*) while the prompt is quadratic. With *p₀*=600, *g*=350, *n*=15: 45,750 prompt tokens against perhaps 1,200 completion tokens — a factor of nearly 40. This is why §6.3 says the observation's *shape* is an interface decision.

**1.11.** **Yes, the `seen` guard catches it** — at step 3. `seen` after step 1 is {(headcount, support)}; after step 2, {(headcount, support), (headcount, sales)}; step 3 requests `headcount(support)` again, which is in `seen`, so the loop returns with `stop_reason = "no_progress"` in three steps. *What this tells you about the limits:* a set-membership guard on `(action, argument)` catches any **exact** repeat, and since the tool set is finite the guard bounds the episode at |tools| × |distinct arguments| steps even with no cap — but it is a **proxy**, and it fails in both directions. It **misses** genuine non-progress when the arguments differ but the *information* does not: `headcount(support)`, `headcount(Support)` and `headcount("support")` are three distinct pairs that produce one identical observation, and the guard lets all three through. And it can **fire wrongly** when a legitimately repeated call would return something new — a clock, a queue read, a paginated search. Assignment 2 addresses the first failure by keying on the observation instead, which is the property §8 actually named. The second failure is why Phase 3's dispatcher will feed the error back rather than terminating, and why non-idempotent tools eventually need to be exempt from the guard.

---

## Quiz

**Q1.** The **agent function** is the mathematical object: a map from every possible percept sequence to an action. The **agent program** is the concrete implementation running on some architecture. The function is what the agent *is*, behaviourally; the program is what you debug. An LLM agent makes the distinction unusually visible because the percept sequence is not an abstraction — it is a literal `list[Message]` you can print, so you can inspect the exact input the function is being applied to at every step, which is almost never true of a classical implementation with compressed internal state. The one thing an LLM agent has that a classical **reflex** agent does not: **the complete percept history in its input.** A pure reflex agent maps only the *current* percept to an action; an LLM agent maps the *whole sequence*, which is why it can do multi-step work at all despite having no internal state. R&N would call it a reflex agent whose percepts happen to include everything that ever happened.

**Q2.** Two most likely causes.
*Cause 1 — context overflow, on the **perceive** arrow.* The prompt grows by *g* every step; once *p₀ + (n−1)g* exceeds the context length, the runner truncates (usually silently, usually from the front, taking the system prompt with it) and behaviour collapses. "About a dozen steps" is exactly where 600 + 350(n−1) crosses 4,096.
*Cause 2 — prefill without KV-cache reuse, also on the **perceive** arrow but a latency rather than a correctness problem.* If the runner re-processes the whole prompt each call, per-step latency rises linearly and total time rises quadratically; the system does not "stop working" but becomes unusable, and a timeout somewhere else may then kill it.
*The one measurement that distinguishes them:* record **`prompt_tokens` per step and per-step latency together** across an episode (this is what `make results` prints). If `prompt_tokens` plateaus or drops at the step where things break, you are being truncated — cause 1. If `prompt_tokens` keeps rising smoothly while latency rises with it and nothing breaks *logically*, it is cause 2. Full marks also for noting that cause 1 is confirmed instantly by comparing the final step's `prompt_tokens` against `ATLAS_NUM_CTX`.

**Q3.** **System B is the agent.** In A, a human wrote all four branches; the model classifies and fills in content but never selects among actions, so the whole path could have been drawn as a flowchart before the input arrived — a **routed workflow, L3**. In B the model chooses which tool and whether to continue, so control flow is determined at runtime — **L4**.
*Which is cheaper at p95 latency?* **System A, and by more than the mean would suggest.** Two separate reasons. First, A's step count is *bounded by construction* — every path is exactly the length its author wrote — so its latency distribution has a hard ceiling, whereas B's tail is set by how often the model fails to terminate early and drifts toward its step cap. The p95 of a workflow is close to its mean; the p95 of an agent is close to its cap. Second, A's prompts do not accumulate across branches in the same way — each downstream call can be given a purpose-built prompt rather than the whole history — so A avoids the *n(n−1)/2* term entirely. The reason this is a separate question from the first is that autonomy level and cost are related but not identical: an L4 agent that reliably answers in two steps can be cheaper than a wasteful six-call L3 workflow. The tail is where the levels diverge, not the mean.

**Q4.** Maximum steps: *n* ≤ ln(0.85)/ln(0.96) = (−0.16252)/(−0.040822) = 3.98, so **3 steps** (0.96³ = 0.8847 ≥ 0.85; 0.96⁴ = 0.8493 < 0.85). Your eleven-step design gives 0.96¹¹ = **0.6382**, about 64% — nowhere near.
Three interventions, ranked:
1. **Decompose the task and cut steps** — split into two or three separately-invoked episodes of three to four steps each, with a human or a deterministic step between them. Largest effect, because it attacks the exponent directly and also cuts cost quadratically. Cost: the task is no longer one button press; someone must design the seams, and the user experience changes.
2. **Add cheap automatic verification after the riskiest steps** — a schema check, a row-count assertion, a re-read of what was written. Raises effective *p* on the guarded steps toward 0.999. Cost: extra latency and code, and the verifier itself can be wrong; if verification requires another model call the benefit shrinks sharply.
3. **Checkpoint so failures resume rather than restart** — does not change the per-attempt success rate at all, but changes the *cost of failure*, so retrying to an acceptable overall rate becomes affordable. Cost: state management, and stale checkpoints are their own bug class.
Improving the prompt is deliberately not on the list: it moves *p* by a point or two, which at eleven steps is worth about 2 percentage points end-to-end. Full marks also for asking whether 0.96 was measured, and for noting that 85% may itself be the wrong target if the failures are cheap to detect.

**Q5.** *For the project manager:* the looping is a **cost and control problem, and a prompt change cannot bound cost.** A better prompt makes the agent loop less often; it does not make looping cheaper when it happens, it works only for the model and phrasing we tested it on, it breaks the next time we change models, and — crucially — **we cannot put it in the test suite**, so nothing stops it regressing silently. A guard in our own code is deterministic, is tested offline in milliseconds, holds for every model, and turns an unbounded failure into a two-step one with a diagnostic label. So: **the right first move is a progress guard and a named stop reason in the harness.** Then we improve the prompt as a measured optimisation, with a before-and-after recorded, knowing that if it fails nothing catastrophic follows.
*The one circumstance where the prompt fix is right first:* when the defect is not control flow at all but **capability or specification** — the model is choosing a *reasonable* action given instructions that are genuinely ambiguous, incomplete, or wrong. If the instructions never told it the tool takes one department at a time, no guard will produce a correct answer; the guard only stops you paying for the wrong one. Diagnostic question: *given only its percept sequence, was the model's action defensible?* If yes, fix the instructions (a specification bug). If no, fix the harness (a control bug). This is Concept check 1.2's rationality test, reused as a triage tool — and note that §8's trace fails it in both directions, which is why it had two defects.

**Q6.** *Cheap verification, irreversible mistakes:* **executing a wire transfer from an approved payments file.** Verifying is trivial — compare the amount and account against the file. But an executed transfer cannot be recalled. *Design change:* a human approval gate showing the exact call and arguments, defaulting to deny, plus a dual-control threshold above some amount. The agent prepares and verifies; a human commits. (Also acceptable: `DELETE` against production, publishing a press release, sending a calendar invite to a client.)
*Reversible mistakes, expensive verification:* **generating a 40-page literature review with citations.** Every claim is individually retractable and nothing irreversible happens — but checking it requires reading forty pages and forty sources, which costs about as much as writing it, so nobody does, and errors ship. *Design change:* make verification cheap rather than trusting the output — require an inline citation with a quoted span for every claim, so a reader can spot-check any sentence in seconds; then sample-audit. That is exactly why `ATLAS_SPEC.md` makes an uncited answer a failure even when correct, and why M2 is zero-tolerance. (Also acceptable: refactoring a large codebase with no tests — reversible via `git`, unverifiable without the tests; the design change is *write the tests first*, which is the whole reason coding agents work where they do.)

---

## Assignment 1 — reference solution

```python
"""Phase 1, Assignment 1: the arithmetic of sections 6.3 and 6.7, as code."""

from __future__ import annotations

import math


def prompt_tokens_for_episode(n: int, p0: int, g: int) -> int:
    if n < 0 or p0 < 0 or g < 0:
        raise ValueError("n, p0 and g must all be non-negative")
    # Arithmetic series: n*p0 + g * (0 + 1 + ... + (n-1)).
    # Integer division is exact because n*(n-1) is always even.
    return n * p0 + g * n * (n - 1) // 2


def max_steps_in_context(num_ctx: int, p0: int, g: int) -> int:
    if num_ctx < 0 or p0 < 0 or g < 0:
        raise ValueError("num_ctx, p0 and g must all be non-negative")
    if p0 > num_ctx:
        return 0                      # not even the first call fits
    if g == 0:
        return -1                     # the prompt never grows: unbounded
    # Largest n with p0 + (n-1)*g <= num_ctx.
    return 1 + (num_ctx - p0) // g


def max_steps_for_target(p: float, target: float) -> int:
    if not 0.0 < p <= 1.0:
        raise ValueError("p must lie in (0, 1]")
    if not 0.0 < target <= 1.0:
        raise ValueError("target must lie in (0, 1]")
    if p == 1.0:
        return -1
    # O(1) estimate...
    n = int(math.log(target) / math.log(p))
    # ...then correct against the SAME expression episode_success uses, so the
    # two functions agree exactly rather than approximately. This loop runs at
    # most once in practice; it must NOT be a multiply-up-from-zero loop, which
    # takes 1,053,605 iterations at p=0.9999999 and violates criterion 8.
    while n > 0 and p**n < target:
        n -= 1
    while p ** (n + 1) >= target:
        n += 1
    return n


def episode_success(p: float, n: int) -> float:
    if not 0.0 <= p <= 1.0:
        raise ValueError("p must lie in [0, 1]")
    if n < 0:
        raise ValueError("n must be non-negative")
    return p ** n
```

**Notes on the UNAIDED CORE.** The whole difficulty of `max_steps_for_target` is the postcondition in acceptance criterion 7: for the *n* returned, `p**n >= target` and `p**(n+1) < target`. The closed form `floor(log(target)/log(p))` is *almost* right, and "almost" is not a property you can ship. `log(0.9)/log(0.9)` is mathematically exactly 1, but the two logarithms are computed independently and their ratio may come out as 0.9999999999999999, whose floor is 0 — a 100% error at *n*=1. Rather than adding an epsilon (which you would then have to tune, and which fails somewhere else), compute an approximate answer and then **repair it against the actual predicate**. Both loops run at most once or twice for any realistic input, so the cost is nothing and the guarantee is exact. The general lesson — *use the closed form to get close, then verify against the property you actually need* — recurs whenever you convert mathematics into code.

Two smaller points. `g == 0` genuinely means unbounded rather than "error": a tool returning an empty observation is a legal, if useless, design, and returning −1 keeps the two "unbounded" cases (here and in `max_steps_for_target`) consistent. And `n * (n-1) // 2` uses integer division deliberately: `n(n−1)` is even for every integer *n*, so this is exact, whereas `n * (n-1) / 2` would return a float and lose precision on large episodes.

---

## Assignment 2 — reference solution

```python
"""Phase 1, Assignment 2 [extended]: two guards the Phase 1 loop does not have."""

from __future__ import annotations

from typing import Callable

from atlas.agents.minimal import SYSTEM, Step, Trajectory, headcount, parse_action
from atlas.llm import LLMClient, Message


def run_guarded_agent(
    client: LLMClient,
    task: str,
    *,
    tools: dict[str, Callable[[str], str]] | None = None,
    max_steps: int = 6,
    token_budget: int | None = None,
    system: str = SYSTEM,
) -> Trajectory:
    tools = {"headcount": headcount} if tools is None else tools
    traj = Trajectory(task=task)
    messages: list[Message] = [
        Message(role="system", content=system),
        Message(role="user", content=task),
    ]
    seen_actions: set[tuple[str, str]] = set()
    seen_observations: set[str] = set()
    for n in range(1, max_steps + 1):
        completion = client.complete(messages)
        action, argument = parse_action(completion.text)
        step = Step(
            n=n,
            action=action,
            argument=argument,
            prompt_tokens=completion.usage.prompt_tokens,
            completion_tokens=completion.usage.completion_tokens,
        )
        traj.steps.append(step)

        if action == "final":                                   # 1
            traj.answer, traj.stop_reason = argument, "final"
            return traj
        if action not in tools:                                 # 2
            step.observation = f"ERROR: no tool named {action!r}"
            traj.stop_reason = "bad_action"
            return traj
        if (action, argument) in seen_actions:                  # 3
            step.observation = f"ERROR: repeated call {action}({argument})"
            traj.stop_reason = "no_progress"
            return traj
        seen_actions.add((action, argument))

        step.observation = tools[action](argument)              # 4 -- the tool runs

        if step.observation in seen_observations:               # 5
            traj.stop_reason = "cycle"                          # real observation kept
            return traj
        seen_observations.add(step.observation)

        messages.append(Message(role="assistant", content=completion.text))
        messages.append(Message(role="tool", content=step.observation))

        if (                                                    # 6
            token_budget is not None
            and traj.prompt_tokens + traj.completion_tokens >= token_budget
        ):
            traj.stop_reason = "token_budget"
            return traj
    traj.stop_reason = "step_cap"                               # 7
    return traj
```

**Notes on the UNAIDED CORE — the ordering.** Six placement decisions, each of which an acceptance criterion tests.

*`no_progress` before `cycle` (criterion 5).* Both would fire on an exact repeat, since the same call returns the same observation. `no_progress` is the more specific diagnosis — the *model* repeated itself — whereas `cycle` says only that information stopped arriving. Checking specific before general keeps the stop reason maximally informative, which is the whole argument of §8.

*`cycle` after the tool runs, `no_progress` before it (criteria 3 and 8).* You cannot know the observation until you have paid for the call, so `cycle` is necessarily post-hoc. `no_progress` can be decided from the request alone, so it should be, and thereby saves the tool call entirely. General principle: **check what you can before you spend, and only what you must after.**

*`seen_actions.add` after its check, `seen_observations.add` after its check (criterion 6).* Add-before-check makes every first occurrence trip its own guard — the single most common bug in this assignment, and the reason criterion 6 exists as a separate line.

*The real observation is preserved on a `cycle` (criterion 3).* Overwriting it with an error string would destroy the evidence for *why* the cycle was detected. The `stop_reason` already carries the diagnosis; the observation should carry the data. Contrast `no_progress`, where the error string is appropriate because the tool never ran and there is no real observation to preserve.

*The budget check comes after appending the messages (criterion 7's `token_budget=0` case).* It must come after `traj.steps.append` — which happened at the top — for the totals to include this step at all; putting it before the model call would make `token_budget=0` return a trajectory with zero steps, which is a less useful artefact than one showing what the first step cost. Checking after also means a `FINAL` on the breaching step still returns an answer, which is the right priority: you would rather pay a few tokens over budget than throw away a completed task.

*`step_cap` outside the loop.* It is the fall-through, and it stays the default value of `Trajectory.stop_reason` so a forgotten assignment fails closed.

**Two things to notice about what you built.** First, `cycle` is not a strict improvement over `no_progress` — it is a different, more semantic guard, and both are worth keeping, which is why the assignment keeps them. Second, an observation-keyed guard has its own false positive: a legitimately repeated read of an unchanged value (a queue length that is still zero, a status that is still "pending") now looks like a cycle. Phase 3 handles this by marking non-idempotent tools exempt. Every guard is a proxy for a property; knowing which proxy you are using, and how it fails, is the skill.

---

## Case study — worked answer and filled rubric

### Design memo: warranty claims at Northwind Instruments (760 words)

**Recommendation up front: this is not an agent. It is three deterministic scripts, one routed workflow, and one narrow bounded loop — and the first version should ship without any loop at all.**

**1–2. Decomposition and autonomy, per step.**

| Step | Control flow knowable in advance? | Cheap verifier? | Reversible? | Level | Who chooses next action |
|---|---|---|---|---|---|
| 1 Extract model + serial | Yes | Yes — regex/checksum the serial against the DB | Yes | **L1** | Code; one model call for extraction |
| 2 Warranty lookup | Yes, fully | Deterministic | Yes | **L0 — no model** | Code |
| 3 In-warranty decision | Yes, but a promotion edge case | Deterministic once encoded | Yes | **L0 — no model** | Code |
| 4 Fault classification | Yes (11 fixed classes) | No — genuinely judgemental | Yes | **L1**, with abstention | Code; model classifies |
| 5 Generate + send label | Yes | Address verifiable; *send* is not | **No** | **L3 + gate** | Code; human commits |
| 6 Escalate with summary | Yes | No | Yes | **L1** draft only | Code; engineer decides |
| 7 Log outcome | Yes, fully | Deterministic | Yes | **L0 — no model** | Code |

**System level: L3, a routed workflow**, with one optional L4 loop confined to step 1 — retrying extraction with a clarifying question when the serial is missing from the email (~15% of cases). That single step is the only place where the next action genuinely depends on what the last one returned. Everything else is a flowchart I have just drawn.

**3. Do not automate.** *Step 3's promotion edge case* is not a model problem — it is eight months of 2024 and three product lines, which is a `WHERE` clause. Encode it in the lookup, with a test per product line. Letting a model infer eligibility from prose is strictly worse than a date comparison and unverifiable. *Step 6's escalation judgement* stays human: the engineer decides. The model may draft the summary, clearly labelled as a draft, because a wrong draft costs a minute of reading and a wrong decision costs a customer. *Step 4's residual*: the model must be permitted to abstain. Force-classifying into eleven buckets converts "I don't know" into a confident wrong answer, which is the failure mode `ATLAS_SPEC.md` M2 exists to forbid.

**4. Irreversible actions.** Exactly one: **sending the returns label** (step 5). Generating it is reversible; transmitting it to a customer is not, and it also creates a return authorisation the company must honour. This collides directly with `ATLAS_SPEC.md` §4, which prohibits outbound communication to third parties. **I do not propose amending it for v1.** The system prepares the label, validates the address against the order record, and queues it; the operations lead approves a batch — twenty seconds of review against two minutes of manual work. If, after three months of logged approve/reject data, the rejection rate is under 1%, that is the evidence for a `DECISIONS.md` entry proposing auto-send below a value threshold, with dual control above it. Amend on evidence, not in advance.

**5. Performance measure.** M-W1 **in-warranty claims wrongly declined: zero-tolerance**, computed by comparing the trajectory's decision field against the deterministic lookup — a disagreement is a bug, not a judgement call. M-W2 **labels sent without approval: zero-tolerance**, from the audit log. M-W3 fault classification accuracy on a held-out set of 100 hand-labelled claims, target ≥75% with abstentions counted as neither right nor wrong, and abstention rate reported separately. M-W4 median handling time, baseline 15 min, target ≤5 min. M-W5 fraction reaching a human, target 35–45% — *deliberately not minimised*, because driving it down is how you get M-W1 failures.

**6. Compounding-error exposure.** The automated path is **four model-touching steps** (extract, classify, draft-or-label, and at most one clarification retry). At an assumed *p*=0.95 per step — unmeasured, and the first thing Phase 3's harness should check — end-to-end is 0.95⁴ = **0.8145**. Acceptable, because steps 2, 3 and 7 are deterministic and contribute *p*=1, and because the two steps that could fail expensively (3 and 5) are not model-decided at all. If measurement came in at 0.90 per step, giving 0.656, I would not add retries: I would move fault classification out of the automated path into the escalation queue for a month and re-measure. **The design is survivable because it is short, and it is short because I refused to let the model own steps 2, 3 and 7.**

**7. Honest downside.** Three real costs. The ~15% of emails without a serial get *slower*, not faster: a clarification round trip adds a day versus a human who often recognises the customer. The extraction step is brittle to email format change — a new distributor's template can silently drop accuracy, and nobody will notice for weeks unless M-W3 is monitored continuously. And we lose the operations lead's tacit pattern-spotting: she notices when three claims from one region cite the same fault, and no part of this design does. Add a weekly aggregate report to compensate, and accept that it is a poor substitute.

### Filled rubric — 31/33

| Criterion | Awarded | Comment |
|---|---|---|
| Decomposition quality | 5/5 | All seven steps assessed on all three axes; correctly isolates steps 2, 3, 7 as needing no model and step 1 as the only genuine loop. |
| Autonomy placement | 5/5 | Per-step levels with the decider named; pushes back on "build an agent" with a specific L3 verdict. |
| Refusal to automate | 4/4 | Excludes step 6's judgement and step 3's promotion logic with reasons, and adds abstention on step 4 — a point the rubric did not require. |
| Irreversibility and gates | 5/5 | Correctly isolates the send; engages the §4 prohibition and declines to amend it, with an evidence threshold for revisiting. |
| Performance measure | 4/4 | Trajectory-computable, two zero-tolerance metrics, baseline from the stated manual error rates, and M-W5 explicitly not minimised. |
| Compounding-error arithmetic | 4/4 | Correct 0.95⁴ = 0.8145, assumption flagged as unmeasured, contingency stated, and the causal link between shortness and survivability made explicit. |
| Honest downside | 3/3 | Three specific costs including the loss of tacit knowledge and the silent-degradation risk. |
| **Distinction** | 2/3 | Identifies steps 2, 3 and 7 as scriptable with no new risk, but does not quantify the saving or explicitly propose shipping that alone as v0 and measuring before building anything else. |

**Where most submissions lose points.** Answering "yes, build an agent" and designing an L4 loop over seven tools — which scores well on mechanics and badly on judgement, because the process is a flowchart the operations lead can already draw. Second most common: ignoring the `ATLAS_SPEC.md` §4 prohibition rather than engaging it. A spec you silently override is not a spec.
