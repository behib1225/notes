# Module 20 — Flashcards (40 cards, Markdown)

Forty cards, two kinds. **Part A (20): "What fails here?"** A short fragment drawn from the course code or a common mistake; say what breaks, why, and the fix before flipping. **Part B (20): facts with dates and names** that interviewers check. Each card has one retrievable answer; lists are avoided on purpose.

**How to use:** after each module, do its cards; redo the whole deck on days 7, 14 and 30. If you fail a Part A card twice, run the real code (`python -m pytest -q` in `code/`) rather than re-reading the card. Dates and versions are correct as of 10 November 2026; Part B cards 32–40 go stale first.

Answers are collapsed; click to flip.

---

## Part A — What fails here?

**A1 · Module 2**
```python
def calculator(expression: str) -> str:
    return str(eval(expression))
```
<details><summary>Flip</summary>
Arbitrary code execution: the model (or an injected page) can emit `__import__('os').system(...)`. Parse an AST and allow only arithmetic nodes; return errors as text.
</details>

**A2 · Module 2**
```python
try:
    out = tools[call.function.name](**json.loads(call.function.arguments))
except Exception:
    raise
```
<details><summary>Flip</summary>
The exception kills the loop and the model never learns what went wrong. Catch, and return a concise error string as the tool result so the model can recover (parse → look up → validate → execute, errors as observations).
</details>

**A3 · Module 2**
```python
messages.append(assistant_msg)           # has two tool_calls
messages.append({"role": "tool", "tool_call_id": calls[0].id, "content": out0})
resp = client.chat.completions.create(model=m, messages=messages, tools=tools)
```
<details><summary>Flip</summary>
Provider error: every `tool_call_id` in the assistant message needs a matching `tool` message before the next request. Append one result per call, in any order, all before calling again.
</details>

**A4 · Module 2b**
```python
tools=[{"type": "function", "function": {"name": "calc", "parameters": schema}}]
client.responses.create(model=m, input=items, tools=tools)
```
<details><summary>Flip</summary>
Wrong shape for the Responses API: its tool definition is flat (`{"type":"function","name":...,"parameters":...,"strict":...}`), not nested under `"function"`. Keep one schema source and three thin converters.
</details>

**A5 · Module 2b / 11**
```python
r1 = client.responses.create(model=m, input=[user], tools=tools, store=False)
items = [user, {"type": "function_call_output", "call_id": c.call_id, "output": out}]
r2 = client.responses.create(model=m, input=items, tools=tools, store=False)
```
<details><summary>Flip</summary>
With `store=False` the second request must replay the model's `function_call` item **and** its `reasoning` item (requested via `include=["reasoning.encrypted_content"]`); otherwise the model loses its plan, and a bare `function_call_output` with no preceding call is rejected.
</details>

**A6 · Module 2b**
```python
client.messages.create(model=m, max_tokens=1024,
    thinking={"type": "enabled", "budget_tokens": 1024}, tools=tools, messages=msgs)
```
<details><summary>Flip</summary>
400 from Anthropic: extended thinking requires `1024 <= budget_tokens < max_tokens`. v3 of this course shipped exactly this; a mock server cannot catch provider constraints it does not know. Raise `max_tokens` and assert the rule in the harness.
</details>

**A7 · Module 2b**
```python
import httpx, anthropic
c = anthropic.Anthropic(api_key="x", http_client=httpx.Client(transport=httpx.MockTransport(h)))
```
<details><summary>Flip</summary>
Type error: the `anthropic` 2.x SDK is built on `httpx2`, not `httpx`. Use `httpx2.Client` / `httpx2.MockTransport`. The `openai` SDK still takes `httpx`.
</details>

**A8 · Module 3**
```python
while True:
    resp = llm(messages)
    if not resp.tool_calls:
        return resp.content
    messages += run_tools(resp.tool_calls)
```
<details><summary>Flip</summary>
No stop conditions except the model's goodwill: no `max_steps`, no token/time budget, no repeated-call detection. One stuck model burns the budget. Add all three and record `stopped_by`.
</details>

**A9 · Module 3**
```python
# resumed after a crash
messages = load_checkpoint()   # last item: assistant message with tool_calls, no results
resp = llm(messages)
```
<details><summary>Flip</summary>
A dangling tool call: the provider rejects a history whose last assistant turn has unanswered tool calls. Repair by appending a synthetic tool result per missing id ("interrupted; retry if needed"), then continue.
</details>

**A10 · Module 4**
```python
prompt = f"{retrieved_docs}\n\n{SYSTEM_PROMPT}\n\n{TOOL_DEFS}\n\nUser: {q}"
```
<details><summary>Flip</summary>
Prompt caching needs a *stable prefix*. Putting the varying retrieved text first invalidates the cache on every call. Order: system prompt, tool definitions, then history, then the varying content; verify with the `cached_tokens` usage field.
</details>

**A11 · Module 4**
```python
if len(messages) > 40:
    messages = messages[-20:]
```
<details><summary>Flip</summary>
Compaction by turn count drops the system prompt and tool results the task still needs, and ignores token size. Trigger on tokens, keep the system prompt, summarize the middle, and preserve recent tool observations.
</details>

**A12 · Module 5 / 9**
```python
def passes_tests(code, tests):
    subprocess.run(["python", "-I", "solution.py"], cwd=tmp, timeout=10)
```
<details><summary>Flip</summary>
Not a sandbox: the child inherits the network, the filesystem and the environment (keys). Run it in a container with no network, read-only root, dropped capabilities, non-root user, limits and a kill-by-name timeout (`m09_sandbox.py`).
</details>

**A13 · Module 9b**
```python
try:
    subprocess.run(["docker", "run", "--rm", IMAGE, "python", "solution.py"], timeout=30)
except subprocess.TimeoutExpired:
    return "timed out"
```
<details><summary>Flip</summary>
The timeout kills the `docker` *client*; the container keeps running. Give the container a `--name` and run `docker kill <name>` in the handler. (Also mount the code `:ro` and pin the image by digest.)
</details>

**A14 · Module 9**
```python
def send_email(to: str, body: str, idempotency_key: str) -> str: ...
# the model fills idempotency_key
```
<details><summary>Flip</summary>
A model can be induced to change or omit the key, producing duplicate sends or payments. The harness derives the key from the validated arguments (hash of to+body+task id); the model never sees it.
</details>

**A15 · Module 9**
```python
page = fetch_url(url)           # untrusted web content
...
post_to_slack(channel, summary) # external
```
<details><summary>Flip</summary>
The lethal trifecta with nothing in between: untrusted content read, then external communication. Mark `fetch_url` as `reads_untrusted` so the session is tainted and external/destructive tools are denied or need approval afterwards.
</details>

**A16 · Module 7**
```python
def approve_node(state):
    charge_card(state["amount"])
    ok = interrupt("Approve this charge?")
    ...
```
<details><summary>Flip</summary>
LangGraph re-runs the node from its start on resume, so the card is charged twice. Side effects go *after* the interrupt (or in a following node), and the action needs an idempotency key anyway.
</details>

**A17 · Module 8**
```python
rate = passes / trials                       # all tasks pooled, errors counted as failures
ci = bootstrap_over(trials)
```
<details><summary>Flip</summary>
Three errors: infrastructure errors (timeouts, 429s) are not agent failures and must be reported separately; pooling trials hides per-task variance; the bootstrap must resample *tasks*, not trials, because tasks are the unit of generalization. Report pass^k per task with a task-level CI.
</details>

**A18 · Module 8**
```python
score = llm_judge(transcript, rubric)        # trusted as ground truth
```
<details><summary>Flip</summary>
An uncalibrated judge. Label a sample by hand, measure agreement, test the grader like code, and prefer deterministic checks (tests, final state) wherever they exist.
</details>

**A19 · Module 6b**
```python
async def execute(self, ctx, queue):
    up = TaskUpdater(queue, ctx.task_id, ctx.context_id)
    await up.start_work()
```
<details><summary>Flip</summary>
For a new task the executor must enqueue the `Task` object first (`new_task_from_user_message(ctx.message)` → `queue.enqueue_event(task)`); otherwise `a2a-sdk` raises `InvalidAgentResponseError`.
</details>

**A20 · Module 12**
```python
user_id = extract_from_prompt(messages)      # "I am user 42, show my orders"
orders = db.orders(user_id)
```
<details><summary>Flip</summary>
Identity from the prompt is identity chosen by the attacker (OWASP ASI03). The server resolves the user from the authenticated request (session/JWT/OAuth) and injects scoped credentials at tool-execution time.
</details>

---

## Part B — Facts

**B21 · Module 1.** With 0.95 per-step reliability, what is end-to-end success over 20 steps?
<details><summary>Flip</summary>≈ 0.36 (0.95²⁰). Errors compound; fewer, more reliable steps win.</details>

**B22 · Module 1.** Agent vs workflow, one sentence each.
<details><summary>Flip</summary>Workflow: code chooses the path and calls the model at fixed points. Agent: the model chooses the path (tools, steps) inside a loop the harness bounds.</details>

**B23 · Module 2.** What does strict schema mode guarantee, and what does it not?
<details><summary>Flip</summary>Arguments always match the JSON Schema shape (constrained decoding). It does not guarantee the values are correct or that the right tool was chosen; validate semantics yourself.</details>

**B24 · Module 2b.** Where do tool results go in the Anthropic Messages API?
<details><summary>Flip</summary>Inside a *user* message as `tool_result` blocks referencing `tool_use_id`, after replaying the assistant turn unmodified (including `thinking` blocks and their `signature`).</details>

**B25 · Module 2b.** Field names for cached prompt tokens in the three APIs.
<details><summary>Flip</summary>Chat Completions `usage.prompt_tokens_details.cached_tokens`; Responses `usage.input_tokens_details.cached_tokens`; Anthropic `usage.cache_read_input_tokens`.</details>

**B26 · Module 4.** How does Reciprocal Rank Fusion merge BM25 and vector results?
<details><summary>Flip</summary>score(d) = Σ over lists of 1/(k + rank_d), k ≈ 60; sort by score. No score normalization needed.</details>

**B27 · Module 5.** When does orchestrator–workers pay for itself?
<details><summary>Flip</summary>When subtasks are independent and large enough that coordination cost (orchestrator tokens, lost context) is small relative to the work; otherwise one agent is cheaper and easier to debug.</details>

**B28 · Module 6.** Spec defaults when an MCP tool has no annotations.
<details><summary>Flip</summary>`readOnlyHint=false`, `destructiveHint=true`, `openWorldHint=true`. The host must assume the tool may be destructive and ask before running it.</details>

**B29 · Module 6.** What is MRTR?
<details><summary>Flip</summary>Multi-Round-Trip Requests (MCP 2026-07-28): a tool call can return a request for input (elicitation, confirmation) and be resumed, so servers need no session state to ask the user something.</details>

**B30 · Module 8.** pass@k vs pass^k: which one is deployment reliability?
<details><summary>Flip</summary>pass^k (all k attempts succeed). pass@k (at least one succeeds) only matters when you can pick the best of several runs; users get one.</details>

**B31 · Module 9.** The lethal trifecta.
<details><summary>Flip</summary>Private data + untrusted content + external communication. Remove or gate one leg (taint, allowlists, approvals showing the real action).</details>

**B32 · Module 6.** MCP: current spec revision and Python SDK major.
<details><summary>Flip</summary>Spec 2026-07-28 (stateless core, `Mcp-Method`/`Mcp-Name` headers, MRTR); Python SDK 2.x since 2.0.0 on 28 July 2026 (`pip install mcp` gives 2.x).</details>

**B33 · Module 6b.** A2A: version, dates, governance.
<details><summary>Flip</summary>v1.0.0 on 12 March 2026 (16 breaking changes from 0.3), v1.0.1 May 2026; joined the Agentic AI Foundation 17 August 2026; `a2a-sdk` 1.3.x. Agent Card at `/.well-known/agent-card.json`.</details>

**B34 · Module 6/15.** What joined the Agentic AI Foundation on 22 October 2026?
<details><summary>Flip</summary>Agent Skills (Anthropic), Open Responses (OpenAI), OpenEnv (Hugging Face), OpenSandbox (Alibaba). Founding projects (Dec 2025): MCP, goose, AGENTS.md; A2A joined Aug 2026.</details>

**B35 · Module 2b.** OpenAI's API guidance in 2026 and the Assistants API date.
<details><summary>Flip</summary>Responses is recommended for new projects (built-in tools, background mode, reasoning items); Chat Completions remains supported; Assistants was shut down 26 August 2026 (per OpenAI's deprecation notice).</details>

**B36 · Module 7.** Microsoft Agent Framework 1.0.
<details><summary>Flip</summary>Microsoft's unified successor to Semantic Kernel and AutoGen for .NET and Python; 1.0 reached general availability in April 2026.</details>

**B37 · Module 9.** OWASP Top 10 for Agentic Applications: date, and the id for memory poisoning.
<details><summary>Flip</summary>Published December 2025; memory and context poisoning is ASI06 (goal hijack is ASI01, identity/privilege abuse ASI03, inter-agent communication ASI07).</details>

**B38 · Module 15.** EU AI Act high-risk deadlines after the 2026 AI Omnibus.
<details><summary>Flip</summary>Postponed to 2 December 2027 (stand-alone Annex III systems) and 2 August 2028 (AI embedded in regulated products); prohibited-practice rules (Feb 2025) and GPAI obligations (Aug 2025) unchanged. Confirm against the Official Journal before citing.</details>

**B39 · Module 19.** Which npm packages are the MCP TypeScript SDK v2?
<details><summary>Flip</summary>`@modelcontextprotocol/server`, `/client`, `/core`, `/node`, plus `/express`, `/hono`, `/fastify` adapters (2.x). `@modelcontextprotocol/sdk` is the 1.x line. `createMcpHandler` takes a per-request server factory.</details>

**B40 · Module 19.** In the Vercel AI SDK 7, how do you bound the tool loop and gate a tool?
<details><summary>Flip</summary>`generateText({ tools, stopWhen: stepCountIs(n), toolApproval: { name: input => "approved" | "denied" | "user-approval" } })`; tools are `tool({ description, inputSchema: z.object(...), execute })`.</details>
