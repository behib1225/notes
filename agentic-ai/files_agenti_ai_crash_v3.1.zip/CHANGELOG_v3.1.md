# Changelog

## v3.1 — 10 November 2026

A self-review of v3 found that it repeated the v2 pattern it had criticized: code that passed mock tests but would fail live, modules outside the course's own offline standard, and dates copied from secondary sources. Fixes:

| Area | v3 problem | v3.1 fix |
|---|---|---|
| `m02b_wire_formats.py` | Demo called Anthropic with `budget_tokens=1024, max_tokens=1024`; the API requires `budget < max_tokens`. Mocks cannot see this. | Default `max_tokens=4096`; harness asserts `1024 <= budget < max_tokens`; regression test |
| `m09_sandbox.py` | `subprocess` timeout killed the Docker *client*, not the container; host dir `chmod 777`; writable code mount; tag-pinned image | `--name` + `docker kill` on timeout (tested with a fake `subprocess.run`); `0o755`; `:ro` mount; digest-pinning note |
| Module 19 | "Checked against type definitions" was partly unverified | Snippets moved to `code/ts/` and **compiled** with `tsc --noEmit` against pinned versions; CI job added. The suspected `toolApproval` error was checked: the option exists in `ai` 7.0; the snippet now uses its real signature |
| Module 15 | OTel date/version, Omnibus regulation number and a marking date rested on secondary summaries | Hedged or removed; Assistants shutdown date re-confirmed from OpenAI's own deprecation notice |
| Scope | ≈ 95 h with nothing cut | **60-hour core** (Modules 0–15, E*.1–E*.2) vs appendices; 5-week part-time path; README states the offline exceptions (2b live, 9b Docker, 18 Node+browser, 19 compile-only) |
| Module 14 | Unsurveyed "what postings list" paragraph | Replaced by a tally-20-postings matrix the learner fills |
| Module 11 | Promised async primer missing | §11.0 added |
| Module 13 | No starting point | `code/capstone_skeleton/` (guarded agent, tasks.jsonl, 3 offline tests, `--eval --json`) |
| Evidence | No path to measured numbers | `m08_evals.py --json`; optional nightly `live-eval` CI job on the Groq free tier gated on a wide band (untested in CI by the authors: no runner, no key) |
| Flashcards | 81 trivia cards; MC sampler always answer A; broken tags | Rebuilt: 40 Markdown cards, 20 of them "what fails here?" code fragments |

Offline suite: 56 passed, 1 skipped (Docker), 1 deselected (live). TypeScript: `tsc --noEmit` passes against `ai` 7.0.166, `@modelcontextprotocol/server` 2.4.0, `zod` 4.6.7.

## v3 — 9 November 2026

A second critical review re-ran the code against current PyPI releases, checked every post-2025 factual claim against primary sources (all held), and found the gaps below. Every new code path has offline tests in `code/tests/test_v3.py`; the suite is now 54 offline tests (+1 Docker-only, +1 live).

### Corrections

| Area | v2 problem | v3 fix |
|---|---|---|
| README | Claimed "researched and tested Nov 2026" while admitting no real model was run; readers had no reference numbers | Explicit "verified / not verified" section; `code/REFERENCE_RUN.md` template for the learner's own numbers; no invented figures |
| M6 A2A | "No A2A code because SDKs were changing" was stale: spec v1.0.1 (May 2026), `a2a-sdk` 1.3.0 | `m06b_a2a.py`: server + client, in-process and over HTTP; agents-as-tools across A2A; E6.4–E6.6 |
| M2/M11 | Course was 100% Chat Completions; Responses and Anthropic Messages described only in prose | `m02b_wire_formats.py`: the same loop in all three formats through the real SDKs (`httpx.MockTransport`); reasoning-state replay asserted by tests; `cache_stats()` |
| M9 | Said "a subprocess is not a sandbox" but never ran one | `m09_sandbox.py` (Docker, locked down); policy unit-tested, live test skipped without Docker; `sandboxed_check` for M5 |
| M9 | Session-global taint presented as the only design | Taint-scoping discussion (per-task, per-item/CaMeL, dual-LLM) and E9.6 |
| M14 | Question numbering jumped A30→A33 | Renumbered; added wire-format and A2A questions; Part E (job market, take-home rubric) |
| M15 | Missed the 22 Oct 2026 AAIF additions; no regulatory context | Agent Skills, Open Responses, OpenEnv, OpenSandbox; EU AI Act with the Omnibus dates (Reg. (EU) 2026/1744) |
| Schedule | 60 h in 14 days assumed a free fortnight | Added a 4-week part-time path |

### New content

- **Module 18 — Browser and computer-use agents**: DOM/accessibility vs pixels, Playwright MCP through the Module 6 host, security controls, state-checked evals.
- **Module 19 — TypeScript appendix**: concept map to the Vercel AI SDK 7, `@openai/agents`, `@langchain/langgraph`, Mastra, the MCP TypeScript SDK v2 packages (`@modelcontextprotocol/server`, `/client`), `@a2a-js/sdk`. Package names verified on npm; snippets illustrative.
- Module 0: optional provider keys; Docker and Node as optional tools.
- Module 13: optional A2A endpoint and provider-agnostic second path; Project C must use the container sandbox.

### Verified on 2026-11-09

openai 3.48.0 · anthropic 2.6.0 · mcp 2.3.0 · a2a-sdk 1.3.0 · langgraph 1.2.20 · langchain-core 1.7.6 · openai-agents 0.24.0 · pydantic 2.14 · fastapi 0.162 · pytest 9.2. Facts checked: MCP 2026-07-28 (stateless, MRTR, `Mcp-Method`/`Mcp-Name`), MCP Python SDK 2.0.0 (28 Jul 2026), A2A v1.0.0 (12 Mar 2026) / v1.0.1 / AAIF (17 Aug 2026), Microsoft Agent Framework 1.0 GA (Apr 2026), OTel GenAI conventions (separate repo since 12 Jun 2026, Development), Agent Skills donation (22 Oct 2026), OpenAI Responses recommended / Assistants shut down 26 Aug 2026, EU AI Omnibus in force 27 Jul 2026.

## v2 — November 2026

v1 was reviewed critically. The bugs below were reproduced by running the code or found by inspection; each now has a regression test in `code/tests/`.

### Correctness and security fixes

| Area | v1 problem | v2 fix |
|---|---|---|
| `common/llm.py` | Rebuilding assistant messages dropped provider fields. Gemini 3 needs its *thought signature* returned on function calls (HTTP 400 otherwise), so the recommended free Gemini path could fail on turn 2. | Tool-call extras (`extra_content`) are preserved. Message-level reasoning fields are kept on request (`LLM_KEEP_REASONING=1`). |
| M9 sandbox | `abspath` didn't resolve symlinks: `sandbox/link -> /etc` escaped. | `realpath` + `commonpath`; test creates a real symlink. |
| M9 taint | After untrusted input, WRITE tools (including memory) were still allowed, leaving memory poisoning open. The final answer could exfiltrate data via markdown images. | Tainted WRITEs need human approval; `sanitize_output()` strips non-allowlisted images and links. |
| M6 host | Unannotated MCP tools were treated as safe, but spec defaults are `readOnlyHint=false` and `destructiveHint=true`. | `needs_confirmation()` follows spec defaults; the server annotates honestly. |
| M10 idempotency | The **model** chose the idempotency key. | The harness derives keys from a scope the model can't influence; stored in SQLite (survives restarts). |
| M6 server | IDs were `len(TASKS)+1`, so delete + create overwrote a task. | Monotonic counter. |
| M5 | Empty plan crashed `orchestrator_workers`. The final revision in `evaluator_optimizer` was never evaluated. `"Yes."` votes were discarded. | All fixed; `evaluator_optimizer` returns `(draft, rounds, passed)`. |
| M7 LangGraph | Stopping at `max_steps` left unanswered tool calls in the checkpointed thread. Plain-dict state couldn't trim messages. | `limit` node closes pending calls. Idiomatic `add_messages` state with `RemoveMessage` trimming; converter preserves provider extras. |
| M3 | `TypeError` inside a tool was reported as bad arguments; arguments weren't validated. | Pydantic validation; error codes `invalid_json`, `unknown_tool`, `invalid_args`, `tool_error`, `loop`. |
| M10 tracing | Tool spans were created after execution (≈0 ms); global stack not thread-safe. | `contextvars`; `traced_tool` wraps real execution. |
| M10 retries | Wrapper (5 attempts) stacked on SDK retries (3); `Retry-After` ignored. | Inner client uses `max_retries=0`; `Retry-After` honoured; non-transient errors not retried. |
| M10 misc | Cache claimed temperature-0 only but didn't enforce it, unbounded; budget clock per instance; checkpoint only at end. | Enforced + LRU; `Budget.start_run()`; per-step checkpoints via `Agent(on_messages=...)`, resume repairs dangling calls. |
| M4 memory | One global file for all users; non-atomic writes; untested. | `MemoryStore`: per-user files, atomic writes, provenance, delete; tools bound to the authenticated user. |
| M2 schemas | No per-parameter descriptions; `$ref` emitted; strict mode recommended but never produced. | `Annotated[..., Field(description=...)]`, `$ref` inlining, `function_to_tool(strict=True)`, native `response_format` option. |
| M8 graders | Graders fitted to the mock's wording (refusal required the literal "don't know"; refund task didn't check yes/no). Infra errors counted as agent failures. | Regex graders with word boundaries, `affirms`, `refuses`; `status` pass/fail/error; bootstrap CI; transcripts saved. |
| M7 Agents SDK | Guardrail counted digits (false positives). Claimed own tracing was needed. | Luhn check; custom `TracingProcessor` (no OpenAI key); native MCP client tested. |
| Docs | Non-determinism answer cited speculative decoding; MCP annotation names shown in Python casing as if they were wire names; unverified A2A security fields; SWE-bench Verified without caveat; `numpy` missing from requirements; several solution snippets never executed. | All corrected. Every solution has a runnable version in `code/solutions/` covered by tests. |

### New content

- **Module 11 — Reasoning models, streaming & async**: preserving reasoning state, stream accumulation (including tool-call fragments), async agent with parallel tools, timeouts, cancellation.
- **Module 12 — Deployment & identity**: FastAPI service, background runs, Server-Sent Events, server-side identity bound into tools, tenant isolation, Dockerfile, GitHub Actions CI.
- **Module 6**: MRTR elicitation with the SDK's `Resolve`/`Elicit` (server asks the user mid-call; works statelessly).
- **Module 4**: hybrid retrieval (BM25 + embeddings + reciprocal rank fusion), tested.
- **Elective 16**: fine-tuning and serving for agents (trajectory export split by task, SFT, RL with verifiable rewards, vLLM/SGLang).
- **Lab 17**: find the v1 bugs yourself.
- Eval and red-team tooling, Agent Skills and AGENTS.md, coding-agent workflows, an optional `pytest -m live` smoke test, a realistic schedule (≈60 h core / ≈90 h full).
