# agent_openai.py
import json, os
from openai import OpenAI
import tools as T
from tools import TOOLS
from agent_anthropic import SYSTEM, FALLBACK, approve_cli

MODEL = os.environ["OPENAI_MODEL"]      # a current tool-capable model ID from the models page

def run_agent(user_msg: str, max_steps: int = 10, approve=approve_cli, client=None) -> str:
    client = client or OpenAI()
    # Function tools in the Responses API default to strict=True, which requires every
    # property to be listed in "required". search_policy has an optional field, so we
    # opt out here (alternative: make max_results required with type ["integer", "null"]).
    tools = [{"type": "function", "name": t.name, "description": t.description,
              "parameters": t.schema, "strict": False} for t in TOOLS]
    items: list = [{"role": "user", "content": user_msg}]

    for _ in range(max_steps):
        resp = client.responses.create(model=MODEL, instructions=SYSTEM,
                                       tools=tools, input=items)
        items += resp.output
        calls = [o for o in resp.output if o.type == "function_call"]
        if not calls:
            return resp.output_text
        for c in calls:
            try:
                args = json.loads(c.arguments)
                content, is_err = T.run_tool(c.name, args, approve)
            except json.JSONDecodeError:
                content, is_err = "Arguments were not valid JSON. Retry.", True
            items.append({"type": "function_call_output", "call_id": c.call_id,
                          "output": ("ERROR: " if is_err else "") + content})
    return FALLBACK
