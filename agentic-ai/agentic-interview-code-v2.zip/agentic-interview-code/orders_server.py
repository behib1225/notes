# orders_server.py  -- wraps the tools from Chapter 4 as an MCP server (MCP Python SDK v2)
from mcp.server import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
import tools as t                     # tools.py from Chapter 4

mcp = MCPServer("orders")

@mcp.tool()
def orders_lookup(order_id: str) -> dict:
    """Look up one order by ID (format 'A' + 4 digits, e.g. A1001).
    Returns customer, item, amount in USD, status and delivered_days_ago."""
    try:
        return t.lookup_order(order_id)
    except t.ToolError as e:
        # Only mcp's ToolError reaches the model with its message; any other
        # exception is treated as a crash and the model sees a generic error.
        raise ToolError(str(e)) from e

@mcp.tool()
def policy_search(query: str, max_results: int = 2) -> list[str]:
    """Search the refund and shipping policy; returns the most relevant lines."""
    return t.search_policy(query, max_results)

@mcp.resource("policy://full")
def full_policy() -> str:
    """The complete refund and shipping policy as plain text."""
    return "\n".join(t.POLICY)

# Deliberately NOT exposing issue_refund: irreversible actions stay behind your
# own approval flow until the client supports a confirmation step you trust.

if __name__ == "__main__":
    mcp.run()                                   # stdio; mcp.run("streamable-http") for HTTP
