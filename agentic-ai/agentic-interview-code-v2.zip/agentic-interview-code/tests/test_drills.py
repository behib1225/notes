import asyncio, time, pytest, numpy as np
import drills as D

def test_parse_react():
    t = 'Thought: x\nAction: lookup_order\nAction Input: {"order_id": "A1"}\nObservation: fake'
    assert D.parse_react(t) == ("action", "lookup_order", {"order_id": "A1"})
    assert D.parse_react("Thought: done\nFinal Answer: 42") == ("final", "42")
    with pytest.raises(ValueError): D.parse_react("hello")

def test_retries():
    n = {"c": 0}; slept = []
    def f():
        n["c"] += 1
        if n["c"] < 3: raise D.RetryableError("429", retry_after=1 if n["c"] == 1 else None)
        return "ok"
    assert D.call_with_retries(f, sleep=slept.append) == "ok" and slept[0] == 1 and len(slept) == 2
    with pytest.raises(D.RetryableError):
        D.call_with_retries(lambda: (_ for _ in ()).throw(D.RetryableError("x")), max_attempts=2, sleep=lambda s: None)

def test_cycle():
    assert D.detect_cycle(["x", "a", "a", "a"]) == 1
    assert D.detect_cycle(["a", "b", "a", "b", "a", "b"]) == 2
    assert D.detect_cycle(["a", "b", "c", "a"]) is None

def test_trim():
    tu = {"role": "assistant", "content": [{"type": "tool_use", "id": "1", "name": "t", "input": {}}]}
    tr = {"role": "user", "content": [{"type": "tool_result", "tool_use_id": "1", "content": "r" * 400}]}
    msgs = [{"role": "user", "content": "goal"}, tu, tr, tu, tr, {"role": "assistant", "content": "a"}]
    out = D.trim_history(msgs, budget=200)
    roles = [m["role"] for m in out]
    assert out[0]["content"] == "goal"
    assert all(roles[i] != roles[i + 1] for i in range(len(roles) - 1))
    for i, m in enumerate(out):     # every tool_result follows its tool_use
        if isinstance(m["content"], list) and m["content"][0].get("type") == "tool_result":
            assert D.is_tool_use(out[i - 1])

def test_parallel():
    async def fast(x): return x
    async def slow(): await asyncio.sleep(1)
    calls = [{"id": "1", "name": "fast", "args": {"x": 1}}, {"id": "2", "name": "slow", "args": {}},
             {"id": "3", "name": "nope", "args": {}}]
    res = asyncio.run(D.run_tools_parallel(calls, {"fast": fast, "slow": slow}, timeout=0.1))
    assert [r["id"] for r in res] == ["1", "2", "3"]
    assert res[0]["content"] == 1 and res[1]["is_error"] and "KeyError" in res[2]["content"]

def test_retrieval():
    docs = ["error E-4021 means disk full", "refund policy thirty days", "shipping times"]
    bm = D.BM25(docs)
    assert bm.rank("what is E-4021")[0] == 0
    vecs = np.array([[1, 0], [0, 1], [1, 1]], dtype=float)
    dr = D.dense_rank(np.array([0, 1.0]), vecs)
    assert dr[0] == 1
    fused = D.rrf([bm.rank("refund days"), dr])
    assert fused[0] == 1

def test_bucket():
    b = D.TokenBucket(rate_per_sec=1000, capacity=100)
    b.acquire(100); t = time.monotonic(); b.acquire(50)
    assert time.monotonic() - t >= 0.04
