import asyncio
from mcp import Client
from orders_server import mcp
import mcp_bridge as B

def test_orders_server_in_process():
    async def go():
        async with Client(mcp) as client:
            tools = await B.mcp_tools_for_anthropic(client)
            names = sorted(t["name"] for t in tools)
            assert names == ["orders_lookup", "policy_search"]
            schema = next(t for t in tools if t["name"] == "orders_lookup")["input_schema"]
            assert schema["required"] == ["order_id"]
            text, err = await B.call_mcp_tool(client, "orders_lookup", {"order_id": "a1001"})
            assert not err and "Headphones" in text
            text, err = await B.call_mcp_tool(client, "orders_lookup", {"order_id": "zz"})
            assert err and "Expected 'A'" in text
            res = await client.read_resource("policy://full")
            assert "30 days" in res.contents[0].text
    asyncio.run(go())
