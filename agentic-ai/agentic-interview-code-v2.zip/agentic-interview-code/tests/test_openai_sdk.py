import json, httpx
from openai import AsyncOpenAI
from agents import Runner, set_default_openai_client, set_tracing_disabled
import tools as T
import agent_openai_sdk as S

def resp(output):
    return {"id": "r", "object": "response", "created_at": 0, "model": "test-model", "status": "completed",
            "output": output, "parallel_tool_calls": True, "tool_choice": "auto", "tools": [],
            "temperature": 1, "top_p": 1, "error": None, "incomplete_details": None,
            "instructions": None, "metadata": {},
            "usage": {"input_tokens": 1, "output_tokens": 1, "total_tokens": 2,
                      "input_tokens_details": {"cached_tokens": 0}, "output_tokens_details": {"reasoning_tokens": 0}}}

def fc(name, args, cid):
    return {"type": "function_call", "id": "fc_" + cid, "call_id": cid, "name": name,
            "arguments": json.dumps(args), "status": "completed"}

def test_handoff_and_refund():
    T.REFUNDS.clear()
    S.approve = lambda n, a: True
    sent = []
    script = [
        resp([fc("transfer_to_refunds_specialist", {}, "h1")]),
        resp([fc("lookup_order", {"order_id": "A1001"}, "c1")]),
        resp([fc("issue_refund", {"order_id": "A1001", "amount": 120.0, "reason": "broken"}, "c2")]),
        resp([{"type": "message", "id": "m", "role": "assistant", "status": "completed",
               "content": [{"type": "output_text", "text": "Refunded $120.", "annotations": []}]}]),
    ]
    def handler(req):
        sent.append(json.loads(req.content))
        return httpx.Response(200, json=script[len(sent) - 1])
    set_tracing_disabled(True)
    set_default_openai_client(AsyncOpenAI(api_key="x", http_client=httpx.AsyncClient(transport=httpx.MockTransport(handler))))
    result = Runner.run_sync(S.triage_agent, "Refund A1001")
    assert result.final_output == "Refunded $120."
    assert result.last_agent.name == "Refunds specialist"
    assert len(T.REFUNDS) == 1
    names = [tl["name"] for tl in sent[0]["tools"]]
    assert "transfer_to_refunds_specialist" in names
