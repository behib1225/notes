import pytest
import dsa as D

def test_schedule():
    w = D.schedule(["fetch", "parse", "summarise", "search", "report"],
                   [("fetch", "parse"), ("parse", "summarise"), ("search", "report"), ("summarise", "report")])
    assert w == [["fetch", "search"], ["parse"], ["summarise"], ["report"]]
    with pytest.raises(ValueError):
        D.schedule(["a", "b"], [("a", "b"), ("b", "a")])

def test_top_k():
    assert D.top_k_errors(["timeout", "401", "timeout", "429", "429", "timeout"], 2) == [("timeout", 3), ("429", 2)]

def test_free_slots():
    busy = [(9, 10), (9.5, 11), (13, 14)]
    assert D.free_slots(busy, 8, 17, 1) == [(8, 9), (11, 13), (14, 17)]
    assert D.free_slots([(8, 17)], 8, 17, 1) == []

def test_ttl_lru():
    t = {"now": 0.0}
    c = D.TTLLRUCache(2, ttl=10, clock=lambda: t["now"])
    c.put("a", 1); c.put("b", 2); c.get("a"); c.put("c", 3)       # evicts b (LRU)
    assert c.get("b") is None and c.get("a") == 1
    t["now"] = 11
    assert c.get("a") is None                                     # expired

def test_sliding_window():
    t = {"now": 0.0}
    lim = D.SlidingWindowLimiter(2, 1.0, clock=lambda: t["now"])
    assert lim.allow() and lim.allow() and not lim.allow()
    t["now"] = 1.0
    assert lim.allow()
