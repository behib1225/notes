"""Run both raw-API agents against the REAL SDKs with a mocked HTTP transport.
This checks request shapes, response parsing and the loop logic without API keys."""
import json
import httpx, httpx2, anthropic, openai
import tools as T
import agent_anthropic as A
import agent_openai as O

def anthropic_msg(content, stop):
    return {"id": "msg_1", "type": "message", "role": "assistant", "model": "test-model",
            "content": content, "stop_reason": stop, "stop_sequence": None,
            "usage": {"input_tokens": 10, "output_tokens": 5}}

def test_anthropic_agent_refund_flow():
    T.REFUNDS.clear()
    script = [
        anthropic_msg([{"type": "tool_use", "id": "t1", "name": "lookup_order", "input": {"order_id": "a1001"}},
                       {"type": "tool_use", "id": "t2", "name": "search_policy", "input": {"query": "refund delivered"}}], "tool_use"),
        anthropic_msg([{"type": "tool_use", "id": "t3", "name": "issue_refund",
                        "input": {"order_id": "A1001", "amount": 120.0, "reason": "broken"}}], "tool_use"),
        anthropic_msg([{"type": "text", "text": "Refunded $120."}], "end_turn"),
    ]
    sent = []
    def handler(req):
        body = json.loads(req.content)
        sent.append(body)
        return httpx2.Response(200, json=script[len(sent) - 1])
    client = anthropic.Anthropic(api_key="x", http_client=httpx2.Client(transport=httpx2.MockTransport(handler)))
    out = A.run_agent("refund A1001", approve=lambda n, a: True, client=client)
    assert out == "Refunded $120."
    assert T.REFUNDS and T.REFUNDS[0]["amount"] == 120.0
    # second request: both tool results in ONE user message, matched by id
    last_user = sent[1]["messages"][-1]
    assert last_user["role"] == "user" and [b["tool_use_id"] for b in last_user["content"]] == ["t1", "t2"]
    assert sent[0]["tools"][0]["input_schema"]["required"] == ["order_id"]

def test_anthropic_max_tokens_returns_fallback():
    def handler(req):
        return httpx2.Response(200, json=anthropic_msg([{"type": "text", "text": "partial"}], "max_tokens"))
    client = anthropic.Anthropic(api_key="x", http_client=httpx2.Client(transport=httpx2.MockTransport(handler)))
    assert A.run_agent("hi", client=client) == A.FALLBACK

def test_loop_guard_blocks_third_identical_call():
    calls = {"n": 0}
    def handler(req):
        calls["n"] += 1
        body = json.loads(req.content)
        if calls["n"] == 4:
            blocks = body["messages"][-1]["content"]
            assert blocks[0]["is_error"] is True and "twice" in blocks[0]["content"]
            return httpx2.Response(200, json=anthropic_msg([{"type": "text", "text": "done"}], "end_turn"))
        return httpx2.Response(200, json=anthropic_msg(
            [{"type": "tool_use", "id": f"t{calls['n']}", "name": "lookup_order", "input": {"order_id": "A1002"}}], "tool_use"))
    client = anthropic.Anthropic(api_key="x", http_client=httpx2.Client(transport=httpx2.MockTransport(handler)))
    assert A.run_agent("where is A1002", client=client) == "done"

def test_openai_agent_flow():
    T.REFUNDS.clear()
    def resp(output):
        return {"id": "resp_1", "object": "response", "created_at": 0, "model": "test-model",
                "status": "completed", "output": output, "parallel_tool_calls": True,
                "tool_choice": "auto", "tools": [], "temperature": 1, "top_p": 1,
                "error": None, "incomplete_details": None, "instructions": None, "metadata": {}}
    script = [
        resp([{"type": "function_call", "id": "fc1", "call_id": "c1", "name": "lookup_order",
               "arguments": "{\"order_id\": \"A1003\"}", "status": "completed"}]),
        resp([{"type": "message", "id": "m1", "role": "assistant", "status": "completed",
               "content": [{"type": "output_text", "text": "Outside 30 days; 50% store credit.", "annotations": []}]}]),
    ]
    sent = []
    def handler(req):
        sent.append(json.loads(req.content))
        return httpx.Response(200, json=script[len(sent) - 1])
    client = openai.OpenAI(api_key="x", http_client=httpx.Client(transport=httpx.MockTransport(handler)))
    out = O.run_agent("refund A1003", client=client)
    assert "store credit" in out
    fco = sent[1]["input"][-1]
    assert fco["type"] == "function_call_output" and fco["call_id"] == "c1" and "delivered_days_ago" in fco["output"]
    assert sent[0]["tools"][0]["strict"] is False
