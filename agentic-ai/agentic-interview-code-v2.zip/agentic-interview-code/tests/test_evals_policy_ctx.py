import httpx2, json, anthropic
import evals, tools as T, policy, context_mgmt as C

def msg(content, stop):
    return {"id": "m", "type": "message", "role": "assistant", "model": "x", "content": content,
            "stop_reason": stop, "stop_sequence": None, "usage": {"input_tokens": 1, "output_tokens": 1}}

def scripted_client(script):
    i = {"n": 0}
    def handler(req):
        i["n"] += 1
        return httpx2.Response(200, json=script[i["n"] - 1])
    return anthropic.Anthropic(api_key="x", http_client=httpx2.Client(transport=httpx2.MockTransport(handler)))

def test_run_case_detects_bad_refund_attempt():
    script = [msg([{"type": "tool_use", "id": "a", "name": "issue_refund",
                    "input": {"order_id": "A1003", "amount": 89.99, "reason": "x"}}], "tool_use"),
              msg([{"type": "text", "text": "ok"}], "end_turn")]
    ok, checks, _ = evals.run_case(evals.CASES[1], client=scripted_client(script))   # too_old
    assert not ok and not checks["outcome"] and not checks["lookup_first"]
    assert T.run_tool.__name__ == "run_tool"          # spy removed

def test_run_case_good_path():
    script = [msg([{"type": "tool_use", "id": "a", "name": "lookup_order", "input": {"order_id": "A1003"}}], "tool_use"),
              msg([{"type": "text", "text": "Over 30 days: 50% store credit."}], "end_turn")]
    ok, checks, _ = evals.run_case(evals.CASES[1], client=scripted_client(script))
    assert ok, checks

def test_wilson():
    lo, hi = evals.wilson(80, 100)
    assert 0.70 < lo < 0.72 and 0.86 < hi < 0.88

def test_policy_gate():
    ctx = policy.RunContext("u")
    ok, why = policy.check(ctx, "issue_refund", {"order_id": "A1001", "amount": 120}, T.lookup_order)
    assert not ok and "first" in why
    ctx.calls += [("lookup_order", {}), ("search_policy", {})]
    assert policy.check(ctx, "issue_refund", {"order_id": "A1001", "amount": 120}, T.lookup_order)[0]
    assert not policy.check(ctx, "issue_refund", {"order_id": "A1001", "amount": 121}, T.lookup_order)[0]
    ctx.tainted = True
    assert policy.check(ctx, "issue_refund", {"order_id": "A1001", "amount": 100}, T.lookup_order)[1].startswith("NEEDS_HUMAN")

def test_compaction_and_memory():
    msgs = [{"role": "user", "content": "goal"}] + [{"role": "assistant", "content": "x" * 400}] * 10
    client = scripted_client([msg([{"type": "text", "text": "SUMMARY"}], "end_turn")])
    out = C.maybe_compact(msgs, "x", limit=100, client=client)
    assert out[0]["content"] == "goal" and "SUMMARY" in out[1]["content"] and out[2]["role"] == "user"
    assert C.maybe_compact(msgs[:1], "x", limit=100) == msgs[:1]
    m = C.FactMemory(); m.write("u", "diet", "vegetarian"); m.write("u", "diet", "pescatarian")
    assert m.render("u") == "- diet: pescatarian"
