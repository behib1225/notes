from langchain_core.messages import AIMessage
from langgraph.types import Command
import tools as T
import agent_langgraph as G

class FakeModel:
    def __init__(self, script): self.script, self.i = script, 0
    def invoke(self, messages):
        self.i += 1
        return self.script[self.i - 1]

def test_interrupt_and_resume():
    T.REFUNDS.clear()
    G.model = FakeModel([
        AIMessage(content="", tool_calls=[{"name": "lookup_order", "args": {"order_id": "A1001"}, "id": "c1"}]),
        AIMessage(content="", tool_calls=[{"name": "issue_refund", "args": {"order_id": "A1001", "amount": 120.0, "reason": "broken"}, "id": "c2"}]),
        AIMessage(content="Refunded."),
    ])
    cfg = {"configurable": {"thread_id": "t1"}, "recursion_limit": 20}
    out = G.app.invoke({"messages": [{"role": "user", "content": "refund A1001"}]}, cfg)
    assert "__interrupt__" in out and out["__interrupt__"][0].value["amount"] == 120.0
    assert not T.REFUNDS                         # nothing happened before approval
    out = G.app.invoke(Command(resume="approve"), cfg)
    assert out["messages"][-1].content == "Refunded." and len(T.REFUNDS) == 1

def test_tool_error_becomes_message():
    G.model = FakeModel([
        AIMessage(content="", tool_calls=[{"name": "lookup_order", "args": {"order_id": "zz"}, "id": "c1"}]),
        AIMessage(content="Please re-check the ID."),
    ])
    out = G.app.invoke({"messages": [{"role": "user", "content": "order zz"}]},
                       {"configurable": {"thread_id": "t2"}})
    tool_msg = out["messages"][2]
    assert tool_msg.type == "tool" and tool_msg.status == "error"
    print(tool_msg.content)
