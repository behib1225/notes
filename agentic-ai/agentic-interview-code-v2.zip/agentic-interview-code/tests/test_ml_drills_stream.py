import json, math
import numpy as np
import httpx2, anthropic
import ml_drills as M
import agent_anthropic as A


def test_attention_matches_reference_and_is_causal():
    rng = np.random.default_rng(0)
    Q, K, V = rng.normal(size=(4, 8)), rng.normal(size=(4, 8)), rng.normal(size=(4, 8))
    out = M.attention(Q, K, V, causal=True)
    # row 0 may only attend to position 0, so it equals V[0]
    assert np.allclose(out[0], V[0])
    # non-causal equals the textbook formula
    ref = M.softmax(Q @ K.T / math.sqrt(8)) @ V
    assert np.allclose(M.attention(Q, K, V, causal=False), ref)


def test_gqa_shares_kv_heads_and_shapes_hold():
    rng = np.random.default_rng(1)
    n, d_model, n_heads, n_kv, d_head = 5, 16, 4, 2, 4
    x = rng.normal(size=(n, d_model))
    Wq = rng.normal(size=(d_model, n_heads * d_head))
    Wk = rng.normal(size=(d_model, n_kv * d_head))
    Wv = rng.normal(size=(d_model, n_kv * d_head))
    Wo = rng.normal(size=(n_heads * d_head, d_model))
    assert M.multi_head_attention(x, Wq, Wk, Wv, Wo, n_heads, n_kv).shape == (n, d_model)


def test_kv_cache_decode_equals_full_attention():
    rng = np.random.default_rng(2)
    q, k, v = rng.normal(size=(6, 8)), rng.normal(size=(6, 8)), rng.normal(size=(6, 8))
    full = M.attention(q, k, v, causal=True)
    cache = M.KVCache()
    steps = [M.decode_step(q[i:i + 1], k[i:i + 1], v[i:i + 1], cache)[0] for i in range(6)]
    assert np.allclose(np.stack(steps), full)
    assert len(cache) == 6
    assert M.kv_cache_bytes(n_layers=32, n_kv_heads=8, d_head=128) == 131072


def test_sampling_controls():
    logits = np.array([2.0, 1.0, 0.1, -3.0])
    assert M.sample(logits, temperature=0) == 0
    rng = np.random.default_rng(3)
    draws = {M.sample(logits, top_k=1, rng=rng) for _ in range(20)}
    assert draws == {0}
    draws = {M.sample(logits, top_p=0.6, rng=rng) for _ in range(200)}
    assert draws <= {0, 1}          # nucleus keeps only the top two here


def test_lora_starts_as_identity_and_counts_params():
    rng = np.random.default_rng(4)
    d, k, r = 6, 5, 2
    x, W, A = rng.normal(size=(3, k)), rng.normal(size=(d, k)), rng.normal(size=(r, k))
    B = np.zeros((d, r))
    assert np.allclose(M.lora_forward(x, W, A, B, alpha=4, r=r), x @ W.T)
    assert M.lora_trainable_params(d, k, r) == 22


def test_loss_mask_covers_only_assistant_tokens():
    msgs = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "refund A1003"},
        {"role": "assistant", "tool_calls": [{"function": {"name": "lookup_order", "arguments": '{"order_id":"A1003"}'}}]},
        {"role": "tool", "content": '{"status":"delivered"}'},
        {"role": "assistant", "content": "Outside the window."},
    ]
    tok = lambda s: [ord(c) for c in s]
    ids, mask = M.assistant_loss_mask(msgs, tok)
    assert len(ids) == len(mask)
    n_assistant = len(tok('<tool_call>lookup_order({"order_id":"A1003"})</tool_call>')) + len(tok("Outside the window."))
    assert sum(mask) == n_assistant
    logits = np.zeros((len(ids), 256))
    assert abs(M.masked_cross_entropy(logits, ids, mask) - math.log(256)) < 1e-9


def test_grpo_advantages_and_pass_hat_k():
    adv = M.grpo_advantages([1, 0, 0, 1])
    assert abs(adv.sum()) < 1e-9 and adv[0] > 0 > adv[1]
    # two tasks, 5 runs each: 5/5 and 3/5 successes
    assert abs(M.pass_hat_k([(5, 5), (5, 3)], k=2) - (1.0 + 3 / 10) / 2) < 1e-12
    lo, hi = M.wilson_interval(80, 100)
    assert 0.70 < lo < 0.72 and 0.86 < hi < 0.87


def _sse(events):
    return "".join(f"event: {e['type']}\ndata: {json.dumps(e)}\n\n" for e in events)


def test_streaming_path_emits_text_and_returns_same_result():
    events = [
        {"type": "message_start", "message": {"id": "msg_1", "type": "message", "role": "assistant", "model": "test-model",
                                              "content": [], "stop_reason": None, "stop_sequence": None,
                                              "usage": {"input_tokens": 10, "output_tokens": 0}}},
        {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": ""}},
        {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "Hello, "}},
        {"type": "content_block_delta", "index": 0, "delta": {"type": "text_delta", "text": "world."}},
        {"type": "content_block_stop", "index": 0},
        {"type": "message_delta", "delta": {"stop_reason": "end_turn", "stop_sequence": None}, "usage": {"output_tokens": 4}},
        {"type": "message_stop"},
    ]
    def handler(req):
        assert json.loads(req.content)["stream"] is True
        return httpx2.Response(200, content=_sse(events), headers={"content-type": "text/event-stream"})
    client = anthropic.Anthropic(api_key="x", http_client=httpx2.Client(transport=httpx2.MockTransport(handler)))
    chunks = []
    out = A.run_agent("hi", client=client, on_text=chunks.append)
    assert out == "Hello, world." and chunks == ["Hello, ", "world."]
