# drills.py -- Chapter 13 solutions
import asyncio, json, math, random, re, threading, time
from collections import Counter
import numpy as np

# Drill 1 ------------------------------------------------------------------
def parse_react(text: str):
    final = re.search(r"Final Answer:\s*(.*)", text, re.S)
    action = re.search(r"Action:\s*([A-Za-z_][\w-]*)\s*\n\s*Action Input:\s*(.*)", text, re.S)
    if final and (not action or final.start() < action.start()):   # whichever comes first wins
        return ("final", final.group(1).strip())
    if not action:
        raise ValueError("No 'Action' or 'Final Answer' found")
    name, raw = action.group(1), action.group(2)
    raw = raw.split("Observation:")[0]              # drop hallucinated observations
    start, end = raw.find("{"), raw.rfind("}")
    if start == -1 or end < start:
        raise ValueError(f"Action {name} has no JSON input")
    return ("action", name, json.loads(raw[start:end + 1]))

# Drill 2 ------------------------------------------------------------------
class RetryableError(Exception):
    def __init__(self, msg, retry_after: float | None = None):
        super().__init__(msg)
        self.retry_after = retry_after

def call_with_retries(fn, *, max_attempts=5, base=0.5, cap=30.0, sleep=time.sleep):
    for attempt in range(1, max_attempts + 1):
        try:
            return fn()
        except RetryableError as e:
            if attempt == max_attempts:
                raise
            if e.retry_after is not None:
                delay = e.retry_after
            else:
                delay = random.uniform(0, min(cap, base * 2 ** (attempt - 1)))   # full jitter
            sleep(delay)

# Drill 3 ------------------------------------------------------------------
def detect_cycle(calls: list[str], max_period: int = 3, min_repeats: int = 3) -> int | None:
    for p in range(1, max_period + 1):
        need = p * min_repeats
        if len(calls) < need:
            continue
        tail = calls[-need:]
        if all(tail[i] == tail[i % p] for i in range(need)):
            return p
    return None

# Drill 4 ------------------------------------------------------------------
def count(msg) -> int:
    return len(json.dumps(msg)) // 4                 # stand-in for a real tokenizer

def is_tool_use(msg) -> bool:
    return (msg["role"] == "assistant" and isinstance(msg["content"], list)
            and any(b.get("type") == "tool_use" for b in msg["content"]))

def trim_history(messages: list[dict], budget: int) -> list[dict]:
    head, rest = messages[0], messages[1:]
    units, i = [], 0
    while i < len(rest):                             # group atomic units
        if is_tool_use(rest[i]) and i + 1 < len(rest):
            units.append(rest[i:i + 2]); i += 2
        else:
            units.append([rest[i]]); i += 1
    kept, used = [], count(head)
    for unit in reversed(units):                     # newest first
        cost = sum(count(m) for m in unit)
        if used + cost > budget:
            break
        kept, used = unit + kept, used + cost
    out = [head] + kept
    if len(out) > 1 and out[1]["role"] == "user":     # keep user/assistant alternation
        out.insert(1, {"role": "assistant", "content": "(Earlier steps omitted to save space.)"})
    return out

# Drill 5 ------------------------------------------------------------------
async def run_tools_parallel(calls, registry, limit: int = 4, timeout: float = 10.0):
    sem = asyncio.Semaphore(limit)

    async def one(call):
        async with sem:
            try:
                fn = registry[call["name"]]
                result = await asyncio.wait_for(fn(**call["args"]), timeout)
                return {"id": call["id"], "content": result, "is_error": False}
            except asyncio.TimeoutError:
                return {"id": call["id"], "content": f"Timed out after {timeout}s", "is_error": True}
            except Exception as e:                    # unknown tool, bad args, tool failure
                return {"id": call["id"], "content": f"{type(e).__name__}: {e}", "is_error": True}

    return await asyncio.gather(*(one(c) for c in calls))   # gather preserves order

# Drill 6 ------------------------------------------------------------------
def tokenize(s: str) -> list[str]:
    return re.findall(r"\w+", s.lower())

class BM25:
    def __init__(self, docs: list[str], k1: float = 1.5, b: float = 0.75):
        self.docs = [tokenize(d) for d in docs]
        self.tfs = [Counter(d) for d in self.docs]
        self.N = len(docs)
        self.avgdl = sum(len(d) for d in self.docs) / self.N
        self.df = Counter(t for d in self.docs for t in set(d))
        self.k1, self.b = k1, b

    def idf(self, t: str) -> float:
        return math.log(1 + (self.N - self.df[t] + 0.5) / (self.df[t] + 0.5))

    def rank(self, query: str) -> list[int]:
        q = tokenize(query)
        scores = []
        for d, tf in zip(self.docs, self.tfs):
            s = 0.0
            for t in q:
                f = tf.get(t, 0)
                if f:
                    norm = f + self.k1 * (1 - self.b + self.b * len(d) / self.avgdl)
                    s += self.idf(t) * f * (self.k1 + 1) / norm
            scores.append(s)
        return sorted(range(self.N), key=lambda i: -scores[i])

def dense_rank(query_vec: np.ndarray, doc_vecs: np.ndarray) -> list[int]:
    q = query_vec / np.linalg.norm(query_vec)
    D = doc_vecs / np.linalg.norm(doc_vecs, axis=1, keepdims=True)
    return [int(i) for i in np.argsort(-(D @ q))]

def rrf(rankings: list[list[int]], k: int = 60) -> list[int]:
    fused = Counter()
    for ranking in rankings:
        for r, doc in enumerate(ranking):
            fused[doc] += 1.0 / (k + r + 1)
    return [doc for doc, _ in fused.most_common()]

# Drill 7 ------------------------------------------------------------------
class TokenBucket:
    def __init__(self, rate_per_sec: float, capacity: float):
        self.rate, self.capacity = rate_per_sec, capacity
        self.tokens, self.t = capacity, time.monotonic()
        self.lock = threading.Lock()

    def acquire(self, n: float) -> None:
        if n > self.capacity:
            raise ValueError("request larger than bucket capacity")
        while True:
            with self.lock:
                now = time.monotonic()
                self.tokens = min(self.capacity, self.tokens + (now - self.t) * self.rate)
                self.t = now
                if self.tokens >= n:
                    self.tokens -= n
                    return
                wait = (n - self.tokens) / self.rate
            time.sleep(wait)                          # sleep outside the lock
