# agent_langgraph.py
import os
from langchain.chat_models import init_chat_model
from langchain_core.tools import tool
from langgraph.graph import StateGraph, MessagesState, START
from langgraph.prebuilt import ToolNode, tools_condition
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import interrupt, Command
import tools as t
from agent_anthropic import SYSTEM

@tool
def lookup_order(order_id: str) -> dict:
    """Look up one order by ID ('A' + 4 digits). Returns customer, item, amount, status."""
    return t.lookup_order(order_id)

@tool
def search_policy(query: str) -> list[str]:
    """Search the refund and shipping policy."""
    return t.search_policy(query)

@tool
def issue_refund(order_id: str, amount: float, reason: str) -> dict:
    """Refund an order. IRREVERSIBLE. Only after policy confirms eligibility."""
    decision = interrupt({"action": "issue_refund", "order_id": order_id, "amount": amount})
    if decision != "approve":
        return {"status": "declined_by_human"}
    return t.issue_refund(order_id, amount, reason)      # idempotent: safe if re-run

TOOLS = [lookup_order, search_policy, issue_refund]
model = init_chat_model(f"anthropic:{os.environ['ANTHROPIC_MODEL']}").bind_tools(TOOLS)

def agent_node(state: MessagesState):
    return {"messages": [model.invoke([{"role": "system", "content": SYSTEM}] + state["messages"])]}

graph = StateGraph(MessagesState)
graph.add_node("agent", agent_node)
graph.add_node("tools", ToolNode(TOOLS, handle_tool_errors=t.ToolError))  # expected errors -> ToolMessage
graph.add_edge(START, "agent")
graph.add_conditional_edges("agent", tools_condition)  # -> "tools" or END
graph.add_edge("tools", "agent")
app = graph.compile(checkpointer=InMemorySaver())      # use a Postgres/SQLite saver in prod

if __name__ == "__main__":
    cfg = {"configurable": {"thread_id": "ticket-42"}, "recursion_limit": 20}
    out = app.invoke({"messages": [{"role": "user",
                      "content": "My headphones (A1001) broke, please refund me."}]}, cfg)
    while "__interrupt__" in out:                          # paused waiting for a human
        print("Approval needed:", out["__interrupt__"][0].value)
        out = app.invoke(Command(resume=input("approve/deny: ").strip()), cfg)
    print(out["messages"][-1].content)
