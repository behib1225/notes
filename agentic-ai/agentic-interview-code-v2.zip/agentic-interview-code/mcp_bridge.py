# mcp_bridge.py -- expose any MCP server's tools to the Chapter 4 Anthropic loop
from mcp import Client

async def mcp_tools_for_anthropic(client: Client) -> list[dict]:
    listed = await client.list_tools()
    return [{"name": tl.name, "description": tl.description or "",
             "input_schema": tl.input_schema} for tl in listed.tools]

async def call_mcp_tool(client: Client, name: str, args: dict) -> tuple[str, bool]:
    result = await client.call_tool(name, args)
    text = "\n".join(c.text for c in result.content if getattr(c, "type", "") == "text")
    return text[:4000], bool(result.is_error)
