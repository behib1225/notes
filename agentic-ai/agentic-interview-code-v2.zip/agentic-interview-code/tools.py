# tools.py
import json, re
from dataclasses import dataclass
from typing import Any, Callable

ORDERS = {
    "A1001": {"customer": "dana@example.com", "item": "Headphones", "amount": 120.00,
              "status": "delivered", "delivered_days_ago": 5},
    "A1002": {"customer": "li@example.com", "item": "Laptop stand", "amount": 45.50,
              "status": "shipped", "delivered_days_ago": None},
    "A1003": {"customer": "sam@example.com", "item": "Keyboard", "amount": 89.99,
              "status": "delivered", "delivered_days_ago": 40},
}
POLICY = [
    "Refunds: items delivered within the last 30 days can be refunded in full.",
    "Refunds: items delivered more than 30 days ago are not refundable; offer 50% store credit.",
    "Shipping: orders still in 'shipped' status cannot be refunded until delivered.",
    "Refunds above $500 always require a human supervisor.",
]
REFUNDS: list[dict] = []

class ToolError(Exception):
    """An error the model should read and recover from."""

def lookup_order(order_id: str) -> dict:
    oid = order_id.strip().upper()
    if not re.fullmatch(r"A\d{4}", oid):
        raise ToolError(f"Invalid order_id '{order_id}'. Expected 'A' + 4 digits, e.g. A1001.")
    if oid not in ORDERS:
        raise ToolError(f"No order {oid}. Ask the customer to re-check the ID.")
    return {"order_id": oid, **ORDERS[oid]}

def search_policy(query: str, max_results: int = 2) -> list[str]:
    words = set(re.findall(r"\w+", query.lower()))
    ranked = sorted(POLICY, key=lambda p: -len(words & set(re.findall(r"\w+", p.lower()))))
    return ranked[: max(1, min(max_results, 5))]

def issue_refund(order_id: str, amount: float, reason: str) -> dict:
    order = lookup_order(order_id)
    if not 0 < amount <= order["amount"]:
        raise ToolError(f"amount must be > 0 and <= {order['amount']}.")
    if any(r["order_id"] == order["order_id"] for r in REFUNDS):   # idempotency
        return {"status": "already_refunded", "order_id": order["order_id"]}
    REFUNDS.append({"order_id": order["order_id"], "amount": amount, "reason": reason})
    return {"status": "refunded", "order_id": order["order_id"], "amount": amount}

@dataclass
class Tool:
    name: str
    description: str
    schema: dict
    fn: Callable[..., Any]
    requires_approval: bool = False
    read_only: bool = True

TOOLS = [
    Tool("lookup_order",
         "Look up one order by ID. Returns customer, item, amount (USD), status and "
         "delivered_days_ago. Call this before discussing any specific order.",
         {"type": "object",
          "properties": {"order_id": {"type": "string", "description": "e.g. A1001"}},
          "required": ["order_id"], "additionalProperties": False},
         lookup_order),
    Tool("search_policy",
         "Search the refund and shipping policy. Returns the most relevant policy lines. "
         "Call this before deciding whether a refund is allowed.",
         {"type": "object",
          "properties": {"query": {"type": "string"},
                         "max_results": {"type": "integer", "minimum": 1, "maximum": 5}},
          "required": ["query"], "additionalProperties": False},
         search_policy),
    Tool("issue_refund",
         "Refund an order to the original payment method. IRREVERSIBLE. Only call after "
         "lookup_order and search_policy confirm the refund is allowed.",
         {"type": "object",
          "properties": {"order_id": {"type": "string"},
                         "amount": {"type": "number", "description": "USD"},
                         "reason": {"type": "string"}},
          "required": ["order_id", "amount", "reason"], "additionalProperties": False},
         issue_refund, requires_approval=True, read_only=False),
]
TOOLS_BY_NAME = {t.name: t for t in TOOLS}

def run_tool(name: str, args: dict, approve: Callable[[str, dict], bool]) -> tuple[str, bool]:
    """Execute a tool call. Returns (content, is_error). Never raises."""
    tool = TOOLS_BY_NAME.get(name)
    if tool is None:
        return f"Unknown tool '{name}'. Available: {sorted(TOOLS_BY_NAME)}", True
    if tool.requires_approval and not approve(name, args):
        return "A human reviewer declined this action. Tell the customer a supervisor will follow up.", True
    try:
        return json.dumps(tool.fn(**args))[:4000], False      # cap output size
    except ToolError as e:
        return str(e), True
    except TypeError as e:                                      # wrong/missing arguments
        return f"Bad arguments for {name}: {e}", True
