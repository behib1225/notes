# policy.py  -- deterministic checks that run before any tool executes
from dataclasses import dataclass, field

@dataclass
class RunContext:
    user_id: str
    calls: list[tuple[str, dict]] = field(default_factory=list)
    tainted: bool = False          # set True once untrusted content entered the context

HIGH_RISK = {"issue_refund", "send_email", "delete_record"}

def check(ctx: RunContext, name: str, args: dict, order_lookup) -> tuple[bool, str]:
    names = [n for n, _ in ctx.calls]
    if name == "issue_refund":
        if "lookup_order" not in names or "search_policy" not in names:
            return False, "Refund requires lookup_order and search_policy first."
        order = order_lookup(args["order_id"])
        if args["amount"] > order["amount"]:
            return False, "Refund exceeds order amount."
        if args["amount"] > 500:
            return False, "Refunds above $500 need a supervisor; escalate instead."
    if name in HIGH_RISK and ctx.tainted:
        return False, "NEEDS_HUMAN: high-risk action after reading untrusted content."
    return True, "ok"
