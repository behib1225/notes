# agent_claude_sdk.py
import asyncio, json, os
from claude_agent_sdk import (tool, create_sdk_mcp_server, ClaudeAgentOptions,
                              ClaudeSDKClient, AssistantMessage, TextBlock, HookMatcher)
from claude_agent_sdk.types import PermissionResultAllow, PermissionResultDeny
import tools as t
from agent_anthropic import SYSTEM

def wrap(fn):
    async def handler(args):
        try:
            return {"content": [{"type": "text", "text": json.dumps(fn(**args))}]}
        except t.ToolError as e:
            return {"content": [{"type": "text", "text": str(e)}], "is_error": True}
    return handler

lookup = tool("lookup_order", "Look up one order by ID.", {"order_id": str})(wrap(t.lookup_order))
policy = tool("search_policy", "Search refund policy.", {"query": str})(wrap(t.search_policy))
refund = tool("issue_refund", "Refund an order. IRREVERSIBLE.",
              {"order_id": str, "amount": float, "reason": str})(wrap(t.issue_refund))

server = create_sdk_mcp_server(name="orders", version="1.0.0", tools=[lookup, policy, refund])

async def can_use_tool(tool_name, tool_input, context):
    if tool_name == "mcp__orders__issue_refund":
        ok = input(f"APPROVE refund {tool_input}? [y/N] ").lower() == "y"
        return PermissionResultAllow(updated_input=tool_input) if ok else PermissionResultDeny(message="Human declined")
    return PermissionResultAllow(updated_input=tool_input)

async def keep_stream_open(input_data, tool_use_id, context):
    # Required in Python: can_use_tool needs streaming mode plus a PreToolUse hook
    # returning {"continue_": True}, otherwise the stream closes before the callback runs.
    return {"continue_": True}

options = ClaudeAgentOptions(
    model=os.environ.get("ANTHROPIC_MODEL"),
    system_prompt=SYSTEM,
    mcp_servers={"orders": server},
    tools=[],                                       # no built-in tools (no shell, files or web)
    allowed_tools=["mcp__orders__lookup_order", "mcp__orders__search_policy"],  # pre-approved
    can_use_tool=can_use_tool,                      # everything else asks this callback
    hooks={"PreToolUse": [HookMatcher(matcher=None, hooks=[keep_stream_open])]},
    max_turns=10,
)

async def main():
    async with ClaudeSDKClient(options=options) as client:   # streaming mode
        await client.query("My headphones (A1001) broke, please refund me.")
        async for msg in client.receive_response():
            if isinstance(msg, AssistantMessage):
                for block in msg.content:
                    if isinstance(block, TextBlock):
                        print(block.text)

if __name__ == "__main__":
    asyncio.run(main())
