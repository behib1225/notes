# agent_openai_sdk.py
import os
from agents import Agent, Runner, function_tool
import tools as t
from agent_anthropic import SYSTEM, approve_cli

MODEL = os.environ["OPENAI_MODEL"]
approve = approve_cli                     # swap for your approval UI

@function_tool
def lookup_order(order_id: str) -> dict:
    """Look up one order by ID ('A' + 4 digits)."""
    return t.lookup_order(order_id)

@function_tool
def search_policy(query: str) -> list[str]:
    """Search the refund and shipping policy."""
    return t.search_policy(query)

@function_tool
def issue_refund(order_id: str, amount: float, reason: str) -> dict:
    """Refund an order. IRREVERSIBLE."""
    if not approve("issue_refund", {"order_id": order_id, "amount": amount}):
        return {"status": "declined_by_human"}
    return t.issue_refund(order_id, amount, reason)

refunds_agent = Agent(
    name="Refunds specialist",
    model=MODEL,
    instructions=SYSTEM + "\nYou handle refund decisions only.",
    tools=[lookup_order, search_policy, issue_refund],
)
triage_agent = Agent(
    name="Support triage",
    model=MODEL,
    instructions="Answer order-status questions with lookup_order. "
                 "Hand off anything about refunds to the Refunds specialist.",
    tools=[lookup_order],
    handoffs=[refunds_agent],
)

if __name__ == "__main__":
    result = Runner.run_sync(triage_agent, "I want my money back for order A1001.")
    print(result.final_output)
    print("Answered by:", result.last_agent.name)
