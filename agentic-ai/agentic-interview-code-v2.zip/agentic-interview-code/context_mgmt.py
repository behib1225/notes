# context_mgmt.py -- drop into the Chapter 4 loop
import json, time
import anthropic

COMPACT_PROMPT = """Summarise this agent transcript for the agent itself to continue the task.
Keep: the user's goal, decisions made and why, facts learned (IDs, amounts, dates),
what is done, what remains, open questions. Drop: raw tool outputs already used.
Write at most 400 words."""

def approx_tokens(messages) -> int:
    return len(json.dumps(messages, default=str)) // 4      # rough; use a tokenizer in prod

def maybe_compact(messages, model, limit=60_000, client=None):
    if approx_tokens(messages) < limit:
        return messages
    client = client or anthropic.Anthropic()
    transcript = json.dumps(messages, default=str)
    summary = client.messages.create(
        model=model, max_tokens=800, system=COMPACT_PROMPT,
        messages=[{"role": "user", "content": transcript}],
    ).content[0].text
    first_user = messages[0]                               # keep the original request verbatim
    return [first_user,
            {"role": "assistant", "content": "Summary of progress so far:\n" + summary},
            {"role": "user", "content": "Continue the task from where you left off."}]

class FactMemory:
    """Per-user semantic memory with supersession and timestamps."""
    def __init__(self):
        self.facts: dict[str, dict[str, dict]] = {}       # user -> key -> {value, ts}
    def write(self, user: str, key: str, value: str):
        self.facts.setdefault(user, {})[key] = {"value": value, "ts": time.time()}
    def render(self, user: str, max_items: int = 20) -> str:
        items = sorted(self.facts.get(user, {}).items(), key=lambda kv: -kv[1]["ts"])
        return "\n".join(f"- {k}: {v['value']}" for k, v in items[:max_items])
