# Agentic-AI Interview Handbook: companion code

Tested code for the handbook (versions pinned in requirements.txt, October 2026).

## Setup
    python -m venv .venv && source .venv/bin/activate
    pip install -r requirements.txt
    python -m pytest -q          # 33 tests, no API key needed (model responses are mocked)

## Run against real models
    export ANTHROPIC_API_KEY=...  ANTHROPIC_MODEL=<current Claude model ID>
    export OPENAI_API_KEY=...     OPENAI_MODEL=<current OpenAI model ID>
    python agent_anthropic.py     # Chapter 4 (pass on_text=print to run_agent for streaming, see 4.7)
    python agent_openai.py        # Chapter 4 (import and call run_agent)
    mcp dev orders_server.py      # Chapter 5, opens the MCP Inspector
    python agent_langgraph.py     # Chapter 7
    python agent_openai_sdk.py    # Chapter 7
    python agent_claude_sdk.py    # Chapter 7 (needs the Claude Code runtime)
    python evals.py               # Chapter 8 (calls the real model k times per case)

## Files
| File | Chapter |
| --- | --- |
| tools.py, agent_anthropic.py, agent_openai.py | 4 |
| orders_server.py, mcp_bridge.py | 5 |
| context_mgmt.py | 6 |
| agent_langgraph.py, agent_openai_sdk.py, agent_claude_sdk.py | 7 |
| evals.py | 8 |
| policy.py | 11 |
| drills.py | 13 |
| dsa.py | Appendix B |
| ml_drills.py | Appendix A.8 (attention, GQA, KV cache, sampling, LoRA, loss masking, GRPO advantages, pass^k, Wilson) |
| tests/ | everything above except agent_claude_sdk.py end to end |

Exercise: break something on purpose (remove the loop guard, raise a plain
Exception in the MCP server) and see which test fails and why.
