# agent_anthropic.py
import json, os
from collections import Counter
import anthropic
import tools as T
from tools import TOOLS, TOOLS_BY_NAME

MODEL = os.environ["ANTHROPIC_MODEL"]   # a current tool-capable model ID from the models page
SYSTEM = """You are a customer-support agent for an online store.
- Look up an order before discussing it. Never invent order details.
- Check the policy before promising or issuing a refund.
- If a tool returns an error, read it, then fix your call or ask the customer.
- Be concise and end with a clear answer to the customer."""
FALLBACK = "I couldn't finish this request automatically; a human agent will follow up."

def approve_cli(name: str, args: dict) -> bool:
    return input(f"\nAPPROVE {name}({args})? [y/N] ").strip().lower() == "y"

def call_model(client, messages, tools, on_text=None):
    """One model call. With on_text, stream text deltas to the UI as they arrive and
    still return the same final Message object the non-streaming path returns."""
    kwargs = dict(model=MODEL, max_tokens=1024, system=SYSTEM, tools=tools, messages=messages)
    if on_text is None:
        return client.messages.create(**kwargs)
    with client.messages.stream(**kwargs) as stream:
        for text in stream.text_stream:      # tool_use blocks arrive after; parse them from the final message
            on_text(text)
        return stream.get_final_message()

def run_agent(user_msg: str, max_steps: int = 10, approve=approve_cli, client=None, on_text=None) -> str:
    client = client or anthropic.Anthropic()
    tools = [{"name": t.name, "description": t.description, "input_schema": t.schema}
             for t in TOOLS]
    messages = [{"role": "user", "content": user_msg}]
    seen = Counter()                      # identical calls since the last state change
    tokens_in = tokens_out = 0

    for step in range(1, max_steps + 1):
        resp = call_model(client, messages, tools, on_text)
        tokens_in += resp.usage.input_tokens
        tokens_out += resp.usage.output_tokens
        messages.append({"role": "assistant", "content": resp.content})

        if resp.stop_reason == "end_turn":
            print(f"[{step} steps, {tokens_in} in / {tokens_out} out tokens]")
            return "".join(b.text for b in resp.content if b.type == "text")
        if resp.stop_reason == "pause_turn":          # server-side tool paused: continue
            continue
        if resp.stop_reason != "tool_use":            # max_tokens, refusal, ...
            print(f"[stopped: {resp.stop_reason}]")
            return FALLBACK

        results = []
        for block in resp.content:
            if block.type != "tool_use":
                continue
            key = (block.name, json.dumps(block.input, sort_keys=True))
            if seen[key] >= 2:                         # loop guard: 3rd identical call
                content, is_err = "You already made this exact call twice; use the earlier result or change approach.", True
            else:
                seen[key] += 1
                content, is_err = T.run_tool(block.name, block.input, approve)
                tool = TOOLS_BY_NAME.get(block.name)
                if tool and not tool.read_only and not is_err:
                    seen.clear()                       # state changed: re-checks are legitimate
            print(f"  -> {block.name}({block.input}) {'ERR ' if is_err else ''}{content[:100]}")
            results.append({"type": "tool_result", "tool_use_id": block.id,
                            "content": content, "is_error": is_err})
        messages.append({"role": "user", "content": results})   # all results in ONE message

    return FALLBACK

if __name__ == "__main__":
    print(run_agent("Hi, my headphones from order a1001 broke. Can I get my money back?"))
