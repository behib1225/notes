# dsa.py -- Appendix B solutions
import heapq, time
from collections import Counter, OrderedDict, defaultdict, deque

# B1. Schedule a plan's steps respecting dependencies (Kahn's algorithm)
def schedule(steps: list[str], deps: list[tuple[str, str]]) -> list[list[str]]:
    """deps: (before, after). Returns 'waves' of steps that can run in parallel.
    Raises ValueError on a cycle."""
    indeg = {s: 0 for s in steps}
    out = defaultdict(list)
    for a, b in deps:
        out[a].append(b)
        indeg[b] += 1
    wave = sorted(s for s in steps if indeg[s] == 0)
    waves, done = [], 0
    while wave:
        waves.append(wave)
        done += len(wave)
        nxt = []
        for s in wave:
            for t in out[s]:
                indeg[t] -= 1
                if indeg[t] == 0:
                    nxt.append(t)
        wave = sorted(nxt)
    if done != len(steps):
        raise ValueError("dependency cycle")
    return waves

# B2. Top-k most frequent tool errors
def top_k_errors(errors: list[str], k: int) -> list[tuple[str, int]]:
    counts = Counter(errors)
    return heapq.nsmallest(k, counts.items(), key=lambda kv: (-kv[1], kv[0]))

# B3. Free meeting slots from busy intervals (merge intervals)
def free_slots(busy: list[tuple[int, int]], start: int, end: int, min_len: int) -> list[tuple[int, int]]:
    merged = []
    for s, e in sorted(busy):
        if merged and s <= merged[-1][1]:
            merged[-1][1] = max(merged[-1][1], e)
        else:
            merged.append([s, e])
    free, cur = [], start
    for s, e in merged:
        if s - cur >= min_len and s > cur:
            free.append((cur, min(s, end)))
        cur = max(cur, e)
        if cur >= end:
            break
    if end - cur >= min_len:
        free.append((cur, end))
    return [(s, e) for s, e in free if e - s >= min_len]

# B4. LRU cache with TTL for tool results
class TTLLRUCache:
    def __init__(self, capacity: int, ttl: float, clock=time.monotonic):
        self.capacity, self.ttl, self.clock = capacity, ttl, clock
        self.data: OrderedDict = OrderedDict()          # key -> (value, expires_at)

    def get(self, key):
        item = self.data.get(key)
        if item is None:
            return None
        value, exp = item
        if self.clock() >= exp:
            del self.data[key]
            return None
        self.data.move_to_end(key)                     # mark as recently used
        return value

    def put(self, key, value):
        self.data[key] = (value, self.clock() + self.ttl)
        self.data.move_to_end(key)
        if len(self.data) > self.capacity:
            self.data.popitem(last=False)              # evict least recently used

# B5. Sliding-window rate limiter: at most n requests per window seconds
class SlidingWindowLimiter:
    def __init__(self, n: int, window: float, clock=time.monotonic):
        self.n, self.window, self.clock = n, window, clock
        self.events: deque = deque()

    def allow(self) -> bool:
        now = self.clock()
        while self.events and now - self.events[0] >= self.window:
            self.events.popleft()
        if len(self.events) < self.n:
            self.events.append(now)
            return True
        return False
