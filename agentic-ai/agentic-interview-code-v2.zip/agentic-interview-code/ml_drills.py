# ml_drills.py -- Appendix A.8: ML coding drills for ML-depth rounds (NumPy only).
# Each function is small enough to write on a whiteboard in 10 minutes.
import math
import numpy as np


def softmax(x, axis=-1):
    x = x - x.max(axis=axis, keepdims=True)          # subtract max for numerical stability
    e = np.exp(x)
    return e / e.sum(axis=axis, keepdims=True)


def attention(Q, K, V, causal=True):
    """Scaled dot-product attention for one head. Q: (n, d), K, V: (m, d)."""
    d = Q.shape[-1]
    scores = Q @ K.T / math.sqrt(d)                     # (n, m)
    if causal:
        n, m = scores.shape
        mask = np.triu(np.ones((n, m), dtype=bool), k=m - n + 1)   # future positions
        scores = np.where(mask, -np.inf, scores)
    return softmax(scores, axis=-1) @ V


def multi_head_attention(x, Wq, Wk, Wv, Wo, n_heads, n_kv_heads=None):
    """GQA-aware MHA. x: (n, d_model). Wq: (d_model, n_heads*d_head),
    Wk/Wv: (d_model, n_kv_heads*d_head), Wo: (n_heads*d_head, d_model)."""
    n_kv_heads = n_kv_heads or n_heads
    n, d_model = x.shape
    d_head = Wq.shape[1] // n_heads
    q = (x @ Wq).reshape(n, n_heads, d_head)
    k = (x @ Wk).reshape(n, n_kv_heads, d_head)
    v = (x @ Wv).reshape(n, n_kv_heads, d_head)
    group = n_heads // n_kv_heads                        # query heads per KV head
    heads = [attention(q[:, h], k[:, h // group], v[:, h // group]) for h in range(n_heads)]
    return np.concatenate(heads, axis=-1) @ Wo


class KVCache:
    """Per-layer cache of past keys and values so decode does not recompute them."""
    def __init__(self):
        self.k = None
        self.v = None

    def append(self, k_new, v_new):
        self.k = k_new if self.k is None else np.concatenate([self.k, k_new], axis=0)
        self.v = v_new if self.v is None else np.concatenate([self.v, v_new], axis=0)
        return self.k, self.v

    def __len__(self):
        return 0 if self.k is None else self.k.shape[0]


def decode_step(q_new, k_new, v_new, cache: KVCache):
    """One decode step: attend the new token's query over all cached keys/values."""
    K, V = cache.append(k_new, v_new)
    return attention(q_new, K, V, causal=False)           # a single new token sees everything before it


def kv_cache_bytes(n_layers, n_kv_heads, d_head, bytes_per_value=2):
    """Bytes of KV cache per token (keys and values, all layers)."""
    return 2 * n_layers * n_kv_heads * d_head * bytes_per_value


def sample(logits, temperature=1.0, top_p=1.0, top_k=0, rng=None):
    """Temperature, top-k and nucleus (top-p) sampling. temperature=0 means argmax."""
    rng = rng or np.random.default_rng()
    logits = np.asarray(logits, dtype=float)
    if temperature == 0:
        return int(np.argmax(logits))
    probs = softmax(logits / temperature)
    order = np.argsort(-probs)
    if top_k > 0:
        order = order[:top_k]
    if top_p < 1.0:
        cum = np.cumsum(probs[order])
        keep = max(1, int(np.searchsorted(cum, top_p) + 1))   # smallest set whose mass >= top_p
        order = order[:keep]
    p = probs[order] / probs[order].sum()
    return int(rng.choice(order, p=p))


def lora_forward(x, W, A, B, alpha, r):
    """LoRA: W' x = W x + (alpha / r) * B A x. A: (r, k), B: (d, r); B starts at zero."""
    return x @ W.T + (alpha / r) * (x @ A.T) @ B.T


def lora_trainable_params(d, k, r):
    return r * (d + k)


def assistant_loss_mask(messages, tokenize):
    """Build (token_ids, loss_mask) so only assistant-generated tokens are trained on.
    tokenize(text) -> list[int]. Tool outputs, system and user turns get mask 0."""
    ids, mask = [], []
    for m in messages:
        if m["role"] == "assistant":
            text = m.get("content") or ""
            for call in m.get("tool_calls", []):
                text += f'<tool_call>{call["function"]["name"]}({call["function"]["arguments"]})</tool_call>'
            toks = tokenize(text)
            ids += toks
            mask += [1] * len(toks)
        else:
            toks = tokenize(m.get("content") or "")
            ids += toks
            mask += [0] * len(toks)
    return ids, mask


def masked_cross_entropy(logits, targets, mask):
    """Mean token cross-entropy over positions where mask == 1."""
    logp = np.log(softmax(logits, axis=-1))
    nll = -logp[np.arange(len(targets)), targets]
    mask = np.asarray(mask, dtype=float)
    return float((nll * mask).sum() / max(mask.sum(), 1.0))


def grpo_advantages(rewards, eps=1e-8):
    """Group-relative advantages: (r - mean) / std within one prompt's group."""
    r = np.asarray(rewards, dtype=float)
    return (r - r.mean()) / (r.std() + eps)


def pass_hat_k(successes_per_task, k):
    """pass^k estimate: for each task with n runs and c successes, the probability that
    k random runs all succeed is C(c,k)/C(n,k); average over tasks."""
    vals = []
    for n, c in successes_per_task:
        if n < k:
            raise ValueError("need at least k runs per task")
        vals.append(math.comb(c, k) / math.comb(n, k))
    return float(np.mean(vals))


def wilson_interval(successes, n, z=1.96):
    """95% Wilson score interval for a success rate; well-behaved near 0 and 1."""
    if n == 0:
        return (0.0, 0.0)
    p = successes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))
