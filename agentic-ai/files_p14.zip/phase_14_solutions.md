# phase_14_solutions.md

Worked answers for Phase 14. Read these **after** attempting the originals; a
solution read before an attempt is a solution you will not remember.

---

## §2 Cumulative review

**CR-1 — why a "no" decision needs reversal criteria.**
Because the cost of the thing you declined changes, and nothing tells you. A
"no" with no reversal criteria decays into folklore: two years later the
architecture has a rule everybody follows and nobody can justify, and the
justification that existed has expired silently. The four measurements in
`docs/MULTI_AGENT_DECISION.md` convert a judgement into a *conditional* — "we
declined because X, Y and Z; here is what would have to be measured for that to
change" — which means the decision can be revisited by evidence rather than by
whoever argues hardest. The failure of an un-reversible "no" is that it is
eventually overturned by *seniority* instead, with no measurement at all.

**CR-2 — the quantity an eval task should grade around a broad handler.**
The **model-call count**. Invariant 67's reasoning: `except Exception: return []`
was the correct response to an unplannable request *and* swallowed an
`ImportError` that made every request unplannable. Both produce an empty plan,
so no check on the plan can separate them. The call count can: "could not do it"
spent a model call deciding, and "could not run" spent zero. The general form is
to grade a quantity that differs between *the domain failure* and *the
programming failure*, and a resource counter is usually the cheapest such
quantity because it is incremented by the code path that did not run.

**CR-3 — what the audience claim prevents.**
Token replay against a different resource server — the confused deputy. Without
`aud`, a token minted so Atlas can read the company database on Priya's behalf
is a valid bearer credential at *every* server that trusts the same issuer,
including the calendar server, the payments server, and any server added next
quarter. The holder does not need to be an attacker for this to be a hole:
Atlas itself is a deputy holding a credential it did not earn, and an
un-audienced token means the deputy's confusion is *already maximal* the moment
it is minted. Hence "the confused-deputy attack with no attacker required" — the
vulnerability exists in the credential's shape, before anybody tries anything.

**CR-4 — the enumerated table.**
Invariant 18: a tool is described once, and a rule inferred from a name changes
meaning when somebody renames a tool. The concrete failure: a rule like
"anything ending `_note` requires `workspace:write`" silently exempts
`append_company_record` the day somebody renames the tool for clarity — and
renaming for clarity is a change nobody reviews as a security change.
`TOOL_SCOPES` is enumerated, and `unscoped_tools` lets the server refuse to
start with a hole in the table (invariant 57: a gate with a hole in it reads as
complete because the other entries are there).

**CR-5 — the carve-out in invariant 19.**
`execute()` never raises means every tool **outcome** is a `ToolResult`. A
framework's suspension exception is not an outcome — it is the runtime asking to
be re-entered later. Converting it into a `ToolResult` turns a pause into a
failure, which is what F-12-06 measured: the run completed normally, reported
`final`, wrote nothing, and a human was never asked. The distinguishing property
is that control-flow exceptions **do not describe the tool's result**; they
describe the *scheduler's* state. They are matched by name from
`CONTROL_FLOW_EXCEPTIONS` rather than by importing a framework, so `atlas.tools`
stays framework-free, and they are re-raised.

---

## §6 Concept checks

**6.1 — `current_time`.**
Both, and the security reading is the interesting one. Reliability: it is
`read_only=True` and `cacheable=False`, and the second flag is the point — it is
the least cacheable read-only function in the codebase, so a cache keyed on
`read_only` alone would serve a stale clock and produce stale-state failures
(mode 7). Security: it is an *oracle*. An injected instruction that cannot
exfiltrate directly can still encode one bit per call by choosing whether to
call it, and more practically it lets an attacker's payload behave differently
inside and outside a test window — "if the date is after the 30th, do X" — which
defeats a red-team suite run today.

**6.2 — a write, a failure, a retried episode, a second write.**
Modes **8 (partial side effects)** and **7 (stale state)**: the second attempt
writes different contents because the model regenerated them, so the file now
holds something no single plan produced. One mechanism addresses both:
**idempotency keys hashing the work** (invariant 37), which makes the second
write recognise itself as the first. And the honest follow-through: if the write
*body* is model-generated, the key must be computed from the **request** rather
than the body, or the two attempts hash differently and the key protects
nothing.

**6.3 — the circuit breaker and the uncited confident answers.**
The breaker (§6.3) and **graceful degradation** failed to compose. The breaker
opened and returned a refusal; the retrieval-abstention path never saw an empty
retrieval, because retrieval was never *reached* — so the answer was generated
without evidence and without the abstention reason that an empty retrieval would
have set. This is invariant 39 exactly: the breaker introduced a new outcome
kind and a branch that classifies outcomes did not enumerate it. One-line fix:
the breaker's refusal maps to a member of the abstention `Literal` (a new one,
deliberately added), so the answer says the corpus was unavailable. The general
rule: **a degradation that does not announce itself is worse than a refusal.**

**6.5 — the step budget that "never fires".**
Three things are wrong. First, the reasoning is backwards: a guard that never
fires under normal load is a guard working as designed, and its value is
entirely in the tail you did not observe. Second, 99.4% over three months on a
99% target means you have *error budget*, not that the mechanism is redundant —
the budget is the argument for shipping features, not for removing controls.
Third, and most importantly, "completes within budget" is measured *with the
budget in place*: the counterfactual is unobserved. What to measure: the
**distribution of steps used**, not the pass rate. If p99 is 4 steps against a
cap of 8, the cap is loose and the colleague has an argument about *sizing*. If
p99 is 7, the cap fires constantly in the tail and its absence is an unbounded
loop.

**6.6 — `search_web` over the seeded corpus.**
Trusted today, untrusted the moment the `fetch` callable is swapped. The corpus
in `data/web/index.json` comes from a committed, seeded generator script, so
every byte is authored by the repository — that is genuinely a trusted surface,
and it is *why* the default backend is the seeded corpus rather than a live
provider. With a live provider injected it becomes the single most exposed
surface Atlas has, because it is content an attacker can author *and* cause to
be retrieved by choosing keywords. The answer changing on a one-line swap is the
lesson: **trust is a property of the wiring, not of the tool.**

**6.8 — the mapping.**
(a) `ScopedToken.audience` → **ASI03**. (b) checksum-pinned `SKILL.md` →
**ASI04**. (c) `unknown_tool_names` batch validation → **ASI02**. (d) the
bounded `for` in every agent loop → **ASI10**. (e) provenance flags on citations
→ **ASI01** (they are what lets a reader see that an assertion came from a
damaged or untrusted source). The entry with **no** Atlas mechanism is
**ASI06** — memory and context poisoning. A memory entry carries no provenance,
so a poisoned fact returns with Atlas's own authority in every later session.
`docs/THREAT_MODEL.md` names it as the largest open gap.

**6.11 — the writable directory.**
The **container rung** did not fail; every flag did its job. What failed is that
the writable path *outlived the container*: the snippet wrote into the agent's
workspace rather than into a tmpfs discarded at exit, so the sandbox's
containment was undone by a mount decision one layer up. The §6.10 layer that
should have caught it is **layer 1, least privilege and capability scoping** —
the executor had no need for a writable path shared with the corpus-reading
route. Secondary catch at **layer 2/ASI06**: the next episode read attacker-
authored content with no provenance. Atlas's implementation uses
`--tmpfs=/work` precisely so that nothing survives.

**6.13 — the one a green suite is least likely to detect.**
**Sycophancy**, and it is the same answer as "which has no closed-set field
anywhere in the codebase" because that is *why*. Every other item has a
structural expression: over-agency has a registry and a tier, corrigibility has
a bounded `for` and a closed `StopReason`, transparency has abstention reasons
and provenance flags, and specification gaming has a holdout split. Sycophancy
lives in the *prose* of the final answer, and Atlas has no closed set describing
prose. A thing with no enumerable representation has nothing for a test to
assert on, which is the general lesson: **the properties your test suite cannot
see are exactly the properties you never gave a type to.**

---

## §13 Quiz

**1. `query_db`, read-only, and still dangerous.**
Read-only removes *corruption*; it does nothing about *disclosure*. In trifecta
terms `query_db` is a pure leg-[A] tool: it is the largest supply of private
data Atlas has, and its results enter the transcript, one step from the
rendering channel. Combine it with any leg-[B] surface on the same route and any
leg-[C] channel and it is an exfiltration engine that never writes a byte.
Removing **[C]** makes it safe, and that is the leg Phase 14 removes by default:
with deny-all egress, a hijacked `data` route can read the whole database and
has nowhere to put it. Note that removing [A] — taking `query_db` away — also
works and costs the entire route.

**2. The classifier instead of the registry.**
*Empirical:* Nasr et al. (arXiv:2510.09023) took twelve published defences,
several of them classifiers, and reported attack success above 90% under
adaptive attack against near-zero as originally published; spotlighting and
prompt sandwiching went from ~1% on static attacks to above 95% under search.
Their own finding is that stacking detectors does not fix the underlying
robustness problem. *Structural:* a classifier is a function of **text**, so the
attacker's move is to write different text — an unbounded search space with a
cheap oracle, since the attacker can query the classifier. Registry scoping is a
function of **the objects in a Python list**, so the attacker's move is to obtain
code execution, which is a different and much harder problem. The classifier
should be wired to a **tightening only** — escalate, log, refuse — and
`require_tightening` should raise if anything tries to use it to grant.

**3. Idempotency keys protecting nothing.**
`write_file(path="summary.md", content=<model-generated>)`. Attempt one and the
retry generate different bodies, so the keys differ, so both writes happen and
the mechanism is inert while appearing present — the worst state a control can
be in. Two things must change. The key must be computed over the **request**
(the task, the target path, the handler version) rather than the produced
content; and the tool's argument model must make that expressible, which means
the unit of work has to be a validated set of fields rather than a free-form
blob. This is why "a tool is described by one pydantic model" turns out to be a
reliability property as well as a prompting one.

**4. Why the §8 trace passed 4/4.**
The check set contained only **positive** assertions: `contains "1.24M"`,
`contains "54"`, a citation check, `n_steps <= 5`. Every one is satisfied by an
answer that *also* contains a beacon, because containment says nothing about
what else is present. General rule: **a check set with no negative half cannot
detect an addition** — which is the same shape as Phase 13's finding that a
refusal mechanism with only positive tasks has a trivially optimal
implementation. The fix is a paired task: the positive half grades the right
thing being present, the negative half grades the wrong thing being absent, and
`not_contains` exists for exactly this.

**5. "We have eliminated the attack."**
*Sentence one, the interval:* the point estimate is 0.000 but the 95% interval
runs to 0.434, because it is five attempts — the honest reading is "we saw no
successes in five tries", which is consistent with a true success rate of up to
about 43%, and halving that interval costs four times the attempts. *Sentence
two, the suite:* the number describes the three attack families we wrote, and
the families we wrote are drawn from our own imagination, so a 0.000 means our
attacks stopped working and says nothing about attacks we did not think of —
the honest next step is harvested payloads and an adversarial search, not a
larger n on the same five.

**6. Arguing for `DEFAULT_PRINCIPAL = operator`.**
*The case for:* a permission system introduced as a breaking change to eleven
phases of call sites will be reverted or bypassed, and a bypassed control is
worth less than an honest permissive default. Shipping it permissive gets the
mechanism into the default path today, where its bugs become visible (which is
invariant 72's corollary: fixing the wiring is how you find the next defect),
and the tightening becomes a one-line change with tests already in place.
*The three artefacts that make it a compromise:* (i) the reason is in the module
docstring beside the constant; (ii) `render_permission_policy()` prints it under
the word `PERMISSIVE` and a test asserts that word appears; (iii) it is item 1
of the numbered residual-risk list in `docs/THREAT_MODEL.md`. *What would change
it:* the first deployment with more than one human subject. The moment two
people share the default, the default is a shared workspace and a shared
authority, and the argument for compatibility is worth less than the argument
for attribution.

---

## §14 Assignment 1 — `atlas/safety/linkcheck.py`

```python
"""Link review: classify, report, and change nothing.

Separate from `atlas.safety.egress` on purpose. `apply_egress_policy` decides
and REDACTS; this decides and REPORTS. A reviewer that also mutates cannot be
used to audit, because its output no longer describes the input.
"""

from __future__ import annotations

from urllib.parse import urlsplit

from pydantic import BaseModel, ConfigDict

ALLOWED_SCHEMES: frozenset[str] = frozenset({"http", "https"})


class LinkPolicy(BaseModel):
    model_config = ConfigDict(frozen=True, extra="forbid")
    allowed_hosts: frozenset[str] = frozenset()


class LinkVerdict(BaseModel):
    model_config = ConfigDict(extra="ignore")
    url: str
    host: str
    scheme: str
    permitted: bool
    reason: str


class LinkReport(BaseModel):
    model_config = ConfigDict(extra="ignore")
    text: str
    verdicts: list[LinkVerdict] = []

    @property
    def refused_hosts(self) -> list[str]:
        return sorted({v.host for v in self.verdicts if not v.permitted and v.host})


def classify_link(url: str, *, policy: LinkPolicy) -> LinkVerdict:
    """Scheme first, then host. Every path returns a reason."""
    try:
        parts = urlsplit(url)
        host = (parts.hostname or "").lower()   # hostname STRIPS userinfo
        scheme = (parts.scheme or "").lower()
    except ValueError as exc:
        return LinkVerdict(url=url, host="", scheme="", permitted=False,
                           reason=f"unparseable URL: {exc}")
    if scheme not in ALLOWED_SCHEMES:
        return LinkVerdict(url=url, host=host, scheme=scheme, permitted=False,
                           reason=f"scheme {scheme!r} is not http or https")
    if not host:
        return LinkVerdict(url=url, host="", scheme=scheme, permitted=False,
                           reason="no host could be parsed from the URL")
    if host not in policy.allowed_hosts:      # EXACT, never endswith
        return LinkVerdict(url=url, host=host, scheme=scheme, permitted=False,
                           reason=f"host {host!r} is not in the allowlist")
    return LinkVerdict(url=url, host=host, scheme=scheme, permitted=True,
                       reason=f"host {host!r} is allowlisted")


def review_answer(text: str, *, policy: LinkPolicy) -> LinkReport:
    from atlas.safety.egress import BARE_URL      # one URL finder, not two

    seen: list[str] = []
    for match in BARE_URL.finditer(text):
        if match.group(0) not in seen:
            seen.append(match.group(0))
    return LinkReport(text=text,
                      verdicts=[classify_link(u, policy=policy) for u in seen])
```

**The two bugs the grader is looking for, and why they are common.**

*Subdomain matching.* The natural implementation is
`host.endswith(allowed)`, which reads correctly in English and accepts
`evil.intranet.local`. An attacker who can register a subdomain — or who
controls any DNS wildcard — owns your allowlist. Exact membership is the only
form that means what it says; a policy that genuinely wants subdomains says so
with a separate field and a `"." + allowed` check.

*Userinfo.* `https://intranet.local@evil.test/x` is a valid URL whose host is
`evil.test`. Any implementation that slices the string between `//` and the
first `/` reads `intranet.local@evil.test` or, worse, splits on `@` the wrong
way. `urlsplit(...).hostname` strips userinfo and lowercases; `.netloc` does
not. This is the reason the solution uses `hostname` and not `netloc`, and it is
worth remembering because `netloc` is the attribute people reach for.

*Why schemes are checked first.* `javascript:alert(1)` has no host, so a
host-first implementation falls through to "no host" and refuses — by accident,
with a misleading reason. `data:` URLs are the sharp case: they embed the
payload and never touch the network, so a filter that only reasons about hosts
has nothing to say about them.

---

## §14 Assignment 2 — `atlas/graph/guard.py`

```python
"""Breaker state derived from the transcript. Pure, and therefore durable."""

from __future__ import annotations

from typing import Any, Sequence

from pydantic import BaseModel, ConfigDict

from atlas.safety.reliability import BreakerState, TRANSIENT_KINDS


class GuardState(BaseModel):
    model_config = ConfigDict(extra="ignore")
    failures: dict[str, int] = {}
    opened: dict[str, float] = {}


def _results(messages: Sequence[Any]) -> list[dict]:
    """Every ToolResult in order, read from the ONE structured key.

    Never by parsing the rendered content: invariant 65 says a renderer's
    output format is never a parser's input contract, and F-09-xx is what
    happens when it is.
    """
    out = []
    for message in messages:
        payload = getattr(message, "additional_kwargs", {}) or {}
        result = payload.get("atlas_tool_result")
        if isinstance(result, dict) and result.get("name"):
            out.append(result)
    return out


def tool_failures_in(messages: Sequence[Any]) -> dict[str, int]:
    """CONSECUTIVE transient failures per tool. Pure."""
    counts: dict[str, int] = {}
    for result in _results(messages):
        name = result["name"]
        if result.get("ok"):
            counts[name] = 0                      # a success RESETS
        elif result.get("error_kind") in TRANSIENT_KINDS:
            counts[name] = counts.get(name, 0) + 1
        # A non-transient failure neither increments nor resets: it is the
        # model's mistake and says nothing about the dependency's health.
    return {k: v for k, v in counts.items() if v}


def breaker_states_in(messages: Sequence[Any], *, threshold: int = 3
                      ) -> dict[str, BreakerState]:
    failures = tool_failures_in(messages)
    names = {r["name"] for r in _results(messages)}
    return {n: ("open" if failures.get(n, 0) >= threshold else "closed")
            for n in sorted(names)}
```

**The design questions, answered.**

*Why consecutive rather than cumulative.* A cumulative count opens a breaker on
any tool used often enough, which converts a long healthy session into an
outage. The reset on success is what makes the count a statement about *the
dependency now* rather than about *the session's history*.

*Why `bad_arguments` neither increments nor resets.* It is not evidence about
the dependency in either direction. Incrementing opens a breaker on a healthy
tool the model is calling wrongly; resetting would let a model with a
malformed-argument habit hold a genuinely failing breaker closed forever.
Ignoring it is the only option that preserves the count's meaning.

*Consecutive within a batch.* A batch containing two calls to the same tool
produces two results in call order (invariant 21), and they are processed in
that order — so a batch of [fail, succeed] resets and a batch of [fail, fail]
counts two. This is a choice, and the argument for it is that the batch is not
an atomic unit for *health* purposes even though it is one for *dispatch*
purposes.

*Criterion 6, the one that fails first.* When `test_engines_agree` goes red, the
question is which engine is now right. The answer, every time, is **the one that
did not change**: invariant 60 says the faithful version lands first, so if
your graph guard alters a healthy episode's `tool_errors` or `stop_reason`, the
guard is wrong — not the loop. The usual cause is refusing *before* the
transcript records the observation that justified the refusal, which changes the
step count. Refuse after, exactly as `no_progress` does, and the diff vanishes.

---

## §15 Case study — model answer sketch

A full-marks review, compressed to its load-bearing claims.

**(a) Threat model.** Assets: the payments credential (the permanent key is the
crown jewel), account balances, vendor details, the standing-instruction memory,
the approval channel. Attackers: an external party who can email the finance
inbox — no account required — and a vendor whose details are attacker-supplied.
Surfaces: inbox contents, vendor lookup results, accounting API responses,
standing instructions, Slack approvals. Out of scope: a compromised payments
provider, a malicious finance manager.

**(b) Three blockers.**
1. **The £250,000 threshold is not a boundary.** It is a per-transfer limit with
   no aggregate, so an attacker issues four transfers of £240,000. A threshold
   an attacker can decompose is arithmetic, not a control. (ASI02, ASI08.)
2. **Standing instructions are durable attacker-writable state with no
   provenance.** Dictated in chat, stored in memory, replayed in every future
   session with the system's own authority — and the chat that dictates them is
   reachable from an email summary the agent wrote. (ASI06.)
3. **An 11-second median approval over 40 daily requests is not oversight.** The
   payload shows amount, accounts and a rationale, and does not show whether
   the destination has ever been paid before, which is the one fact that
   distinguishes a routine sweep from a novel counterparty. (ASI09.)

**(c) Required architecture change.** Split the trifecta across two agents with
no shared session. A *reader* holds the inbox and the read-only accounting API,
produces a **structured, enumerated** reconciliation record, and has no payments
capability. An *executor* holds a short-lived, amount-and-destination-scoped
credential minted per transfer by trusted code from that record, sees no free
text from the inbox, and cannot construct a transfer the record does not
contain. The permanent API key is deleted. This removes leg [A]/[C] from the
agent that holds leg [B], which is the Rule of Two applied at the session
boundary rather than at the prompt. (A CaMeL-style interpreter is the stronger
version of the same idea and costs more than this team will accept.)

**(d) Measurement.** Attack families: injected email, poisoned vendor details,
poisoned standing instruction, and replayed/over-scoped credential. Objectives
that require the capability: *a transfer row exists in the payments sandbox with
a destination the reconciliation record did not name*. Environment-graded, per
family, with intervals and a control arm of legitimate transfers that must still
complete. Plus two SLOs: approval rate per operator per hour (ASI09 becomes
measurable), and the count of transfers whose destination was novel. Before and
after, same seed, same suite version, MDE printed beside the delta.

**Residual after the change.** The reader can still be hijacked into producing a
*wrong but well-formed* reconciliation record; the executor will faithfully pay
it. Destination allowlisting and a novel-counterparty hold are the next control,
and they are not in this change.

---

## Appendix — the second pass, and why it is part of the solutions

The seven defects F-14-06 to F-14-12 were not found by building the phase. They
were found by auditing the finished phase against its own block, one requirement
at a time, and the procedure is short enough to copy.

**1. Read the phase block as a checklist, not as prose.** Every noun in it is a
deliverable. Mine listed "an injection classifier", "output URL filtering",
"permission tiers", "Docker-sandboxed code execution", "a chaos test injecting
tool timeouts", "a reliability before/after report over 30 runs", and
"RESULTS.md". Three of those seven were absent or inert when I declared the
phase finished, and all three were things I had *written code for*.

**2. Grep every public name you added for a call site, from a script.** Not by
hand. My hand-written version of this check listed five names and all five
passed, which is how the containerised executor — the phase's headline security
deliverable — got shipped with no registration. The enumerating version found it
in one run. If you write this gate, write it so that **you cannot choose its
inputs**.

**3. For every mechanism, ask what would be different if you deleted it.** The
answer for `injection_signals` was "nothing", because no prompt contained its
output. The answer for `RetryPolicy` was "nothing", because nothing retried. A
mechanism whose deletion changes no behaviour is not shipped; it is stored.

**4. Run every metric once before you believe it.** The reliability suite's
first execution reported a FAIL for correct behaviour, because its baseline
averaged over runs that are supposed to be no-ops. Metrics are programs, and
invariant 74 applies to them before it applies to anything else.

**5. Diff every published number against the command that prints it, in the
same sitting.** The test count was wrong twice. The compute budget described a
suite that did not exist.

The honest summary for a student: **six of this phase's twelve failure-log
entries are defects in the measuring instrument, and one of those six is the
gate that exists to catch the other five.** That is not a failure of care — the
phase was written slowly and tested at every step. It is what the base rate
looks like when you actually check, and it is the strongest argument in the book
for invariant 74's ordering rule: fix the instrument first, because everything
you would use to prioritise the rest is downstream of it.
