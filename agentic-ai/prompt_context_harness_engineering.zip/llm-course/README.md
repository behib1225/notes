# llm-course: companion repository for "Prompt, Context & Harness Engineering"

This repository holds the full course text and consolidated, tested versions of the course's code.

- **[`course/`](course/README.md)**: the course text, one Markdown file per part (orientation,
  Modules 0–9, appendix, changelog).
- **Repository root**: the code, with file names matching the course text.
- **[`CHANGELOG.md`](CHANGELOG.md)**: every change since the first complete version.

## Setup

Requires Python 3.11 or newer.

```bash
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                     # then edit if you use vLLM or a hosted API
ollama pull qwen3:8b && ollama pull nomic-embed-text     # if you use Ollama (Module 0)
```

## Run the tests (no model needed)

```bash
python -m pytest -q
```

The 38 tests replace the model with a scripted fake (`tests/conftest.py`), so they run anywhere,
including CI (`.github/workflows/ci.yml`, Python 3.11 and 3.12). They check the code's logic:
request construction, validation, retries, truncation handling, retrieval and fusion, compaction,
memory filtering, the agent loop's stop conditions, the policy layer, the harness's path jail and
verifier, the statistics, the evaluation harness and the appendix examples. **They do not measure
model quality, and none of this code has been run against a real model yet.** Results in the
course solutions such as "the model usually…" are expectations, not measurements; record your own
with `evalkit.py`.

## Module-to-file map

| Module | Files |
| --- | --- |
| 0–1 Setup, LLM as a component | `llm.py` |
| 2 Prompt engineering | `tickets.py`, `prompts.py`, `m2_triage.py` |
| 3 Structured outputs | `schemas.py`, `structured.py`, `m3_triage.py` |
| 4 Evaluation | `evalkit.py`, `graders.py`, `stats.py`, `m4_build.py`, `eval/triage.jsonl` |
| 5 Retrieval | `helpcenter.py`, `rag.py`, `eval/rag.jsonl` |
| 6 Memory and context | `context_manager.py`, `memory.py` |
| 7 Tools and agents | `agent.py`, `m7_support_agent.py`, `mcp_helpcenter.py` |
| 8 Harness engineering | `policy.py`, `tracing.py`, `harness.py` |
| Appendix | `appendix_responses.py`, `appendix_async.py`, `appendix_serve.py` |

## Exercise solutions in this code (spoiler warning)

The code here is the finished version, so it already contains the solutions to these exercises.
If you want to do one yourself, do it before opening the listed file.

| Exercise | Where the solution is |
| --- | --- |
| 2.3 Prompt-injection probing | `prompts.sanitize`, applied by `prompts.triage_messages` |
| 4.1 Build a dataset | `m4_build.py`, `eval/triage.jsonl` |
| 4.3 Validate the judge | `graders.JUDGE_MODEL` and `structured.call_structured_once(llm_model=...)` |
| 5.1 Fix the labelling bug | `eval/rag.jsonl` (rag-03 already corrected) |
| 5.2 Text-only index | `rag.Index(use_headers=False)` |
| 6.4 Memory updates and poisoning | `memory.looks_secret`, `memory.user_only_transcript` |
| 7.4 Failure injection, idempotency | `m7_support_agent.create_ticket` |
| 7.5 MCP Inspector, list articles | `mcp_helpcenter.helpcenter_list_articles` |
| 8.2 Attack the jail | `tests/test_agent_policy_harness.py::test_harness_jail` |
| 8.4 Policy and approval | `policy.Policy.guard` (fails closed and logs when the approver errors) |
| 8.5 Traces | `agent.run_agent(tracer=...)`, `tracing.py` |
| A.2 Unit test for compaction | `tests/test_rag_context_memory.py::test_failed_compaction_keeps_full_history` |

Everywhere else, the code matches what the course text teaches, apart from small robustness
improvements described in the changelog.

## Rebuilding the course text

`course/` is generated, not edited by hand. Export each tab of the course document as Markdown into
`tools/raw-exports/` (file names as listed in `tools/build_course_md.py`), then run:

```bash
python tools/build_course_md.py                         # writes course/ and CHANGELOG.md
python tools/check_links.py README.md CHANGELOG.md course   # add --external to check web links
```

The document's diagrams cannot be exported as Markdown, so `tools/diagrams/` holds Mermaid versions
that the build inserts.

## Safety

`harness.py` runs tests on code written by a model. Run it in a container or VM, or set
`HARNESS_SANDBOX=docker` after building the image described in Module 8.4.
