"""context_manager.py: history budget and compaction (Module 6).

The system message never changes, so the cached prefix survives compaction. The summary is
placed after it, as a user/assistant pair, which every chat template accepts.
"""
import json

from pydantic import BaseModel, ConfigDict, Field

from structured import structured_call


def approx_tokens(message: dict) -> int:
    """Rough estimate (about 4 characters per token). Use a real tokenizer when budgets are tight."""
    return len(json.dumps(message, ensure_ascii=False)) // 4 + 4


class ConversationSummary(BaseModel):
    model_config = ConfigDict(extra="forbid")
    user_goal: str
    facts_about_user: list[str] = Field(description="Stable facts: plan, workspace name, role, preferences")
    decisions_and_commitments: list[str] = Field(description="What was decided, promised or already tried")
    open_questions: list[str]
    exact_values: list[str] = Field(description="Ids, numbers, error codes and dates, copied verbatim")


COMPACT_SYSTEM = """You compress a support conversation so it can continue with less context.
Keep everything needed to continue correctly: the user's goal, facts about the user, what was
decided, promised or already tried, open questions, and exact values (ids, numbers, codes, dates)
copied verbatim. Drop greetings, repetition and resolved side topics. If a previous summary is
given, merge it with the new transcript; keep its facts unless the transcript corrects them."""


class ContextManager:
    def __init__(self, system: str, budget: int = 6000, keep_recent: int = 6):
        self.system, self.budget, self.keep_recent = system, budget, keep_recent
        self.summary: ConversationSummary | None = None
        self.turns: list[dict] = []

    def add(self, role: str, content: str) -> None:
        self.turns.append({"role": role, "content": content})

    def messages(self) -> list[dict]:
        msgs = [{"role": "system", "content": self.system}]       # stable: never edited
        if self.summary:
            msgs += [{"role": "user", "content": "<conversation_summary>\n"
                      + self.summary.model_dump_json(indent=1) + "\n</conversation_summary>"},
                     {"role": "assistant", "content": "Understood. I will continue from this summary."}]
        return msgs + self.turns

    def size(self) -> int:
        return sum(approx_tokens(m) for m in self.messages())

    def maybe_compact(self) -> bool:
        if self.size() <= self.budget or len(self.turns) <= self.keep_recent:
            return False
        old, recent = self.turns[:-self.keep_recent], self.turns[-self.keep_recent:]
        while recent and recent[0]["role"] != "user":     # keep the window starting at a user turn
            old.append(recent.pop(0))
        if not old:
            return False
        previous = self.summary.model_dump_json() if self.summary else "none"
        transcript = "\n".join(f"{m['role']}: {m['content']}" for m in old)
        out = structured_call(
            [{"role": "system", "content": COMPACT_SYSTEM},
             {"role": "user", "content": f"<previous_summary>{previous}</previous_summary>\n"
                                         f"<transcript>\n{transcript}\n</transcript>"}],
            ConversationSummary, max_tokens=1500)
        if not out.ok:
            return False        # better to keep the full history than to lose information
        self.summary, self.turns = out.value, recent
        return True
