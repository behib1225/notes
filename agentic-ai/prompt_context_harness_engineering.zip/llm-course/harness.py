"""harness.py: a mini coding-agent harness (Module 8).

WARNING: run_pytest executes code written by the model. By default it runs on your machine
with your permissions. Set HARNESS_SANDBOX=docker (after building the image in Module 8.4)
to run it in a container with no network.
"""
import hashlib, os, pathlib, subprocess, sys, tempfile, textwrap

from pydantic import BaseModel, Field

from agent import Tool, run_agent

FILES = {
    "AGENTS.md": """\
        # AGENTS.md
        Pure-Python money helpers. You may edit only src/money.py. Never edit tests/: tests define done.
        Run run_tests after every edit; you are finished only when all tests pass.
        Money is integer cents, never floats. See docs/pricing.md for discount and rounding rules.
        """,
    "docs/pricing.md": """\
        Annual billing takes 15% off the monthly price. Round half up to the nearest cent
        (858.5 cents becomes 859). Display amounts like $1,234.56.
        """,
    "src/__init__.py": "",
    "src/money.py": '''\
        def annual_price_cents(monthly_cents: int) -> int:
            """Monthly price in cents after the 15% annual discount."""
            raise NotImplementedError

        def format_usd(cents: int) -> str:
            """Format integer cents as US dollars, e.g. 41650 -> '$416.50'."""
            raise NotImplementedError
        ''',
    "tests/test_money.py": """\
        import pytest
        from src.money import annual_price_cents, format_usd

        # type(...) is int / str: an object that overrides __eq__ cannot fake a pass.

        def test_business_annual():
            r = annual_price_cents(3500)
            assert type(r) is int and r == 2975

        def test_rounds_half_up():
            r = annual_price_cents(1010)
            assert type(r) is int and r == 859

        def test_rejects_negative():
            with pytest.raises(ValueError):
                annual_price_cents(-1)

        def test_format():
            s = format_usd(41650)
            assert type(s) is str and s == "$416.50"

        def test_format_thousands():
            s = format_usd(123456)
            assert type(s) is str and s == "$1,234.56"
        """,
}

WRITABLE = {"src/money.py"}          # allow-list: the agent may write nothing else


class Workspace:
    def __init__(self):
        self.root = pathlib.Path(tempfile.mkdtemp(prefix="agent-ws-")).resolve()
        for rel, text in FILES.items():
            path = self.root / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(textwrap.dedent(text))
        self.tests_fingerprint = self.fingerprint("tests")

    def resolve(self, rel: str) -> pathlib.Path:
        path = (self.root / rel).resolve()           # resolves '..' and symlinks
        if not path.is_relative_to(self.root):
            raise PermissionError(f"{rel!r} is outside the workspace")
        return path

    def fingerprint(self, rel: str) -> str:
        h = hashlib.sha256()
        for f in sorted((self.root / rel).rglob("*")):
            if f.is_file() and "__pycache__" not in f.parts:
                h.update(str(f.relative_to(self.root)).encode())
                h.update(f.read_bytes())
        return h.hexdigest()


def _pytest_command(ws: Workspace) -> list[str]:
    if os.getenv("HARNESS_SANDBOX") == "docker":
        return ["docker", "run", "--rm", "--network", "none",
                "--memory", "512m", "--cpus", "1", "--pids-limit", "128",
                "--read-only", "--tmpfs", "/tmp", "-e", "PYTHONDONTWRITEBYTECODE=1",
                "-v", f"{ws.root}:/work:ro", "-w", "/work",
                "agent-sandbox", "python", "-m", "pytest", "-q", "-p", "no:cacheprovider"]
    return [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"]


def run_pytest(ws: Workspace) -> str:
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        r = subprocess.run(_pytest_command(ws), cwd=ws.root, capture_output=True,
                           text=True, timeout=90, env=env)
    except subprocess.TimeoutExpired:
        return "TESTS FAILED: timed out (an infinite loop?)"
    status = "ALL TESTS PASSED" if r.returncode == 0 else f"TESTS FAILED (exit {r.returncode})"
    return f"{status}\n{(r.stdout + r.stderr)[-3000:]}"


class PathArgs(BaseModel):
    path: str = Field(description="Path relative to the workspace root, e.g. 'src/money.py'")


class WriteArgs(PathArgs):
    content: str = Field(description="The complete new content of the file")


class NoArgs(BaseModel):
    pass


def make_tools(ws: Workspace) -> list[Tool]:
    def list_files():
        return sorted(str(p.relative_to(ws.root)) for p in ws.root.rglob("*")
                      if p.is_file() and "__pycache__" not in p.parts)

    def read_file(path):
        return ws.resolve(path).read_text()

    def write_file(path, content):
        target = ws.resolve(path)
        if str(target.relative_to(ws.root)) not in WRITABLE:
            raise PermissionError(f"you may only write {sorted(WRITABLE)}; tests define done and must not change")
        target.write_text(content)
        return f"wrote {len(content)} characters to {path}"

    def run_tests():
        return run_pytest(ws)

    return [
        Tool("list_files", "List all files in the workspace.", NoArgs, list_files),
        Tool("read_file", "Read a file in the workspace.", PathArgs, read_file),
        Tool("write_file", "Replace the whole content of src/money.py.", WriteArgs, write_file),
        Tool("run_tests", "Run the test suite and return a summary with failures.", NoArgs, run_tests),
    ]


def verify(ws: Workspace) -> tuple[bool, str]:
    """The harness's own sensor. The agent's opinion is not consulted."""
    if ws.fingerprint("tests") != ws.tests_fingerprint:
        return False, "Test files were modified. Tests are read-only; restore them."
    report = run_pytest(ws)
    return report.startswith("ALL TESTS PASSED"), report


def solve(task: str, max_rounds: int = 3):
    ws = Workspace()
    tools = make_tools(ws)
    system = ("You are a careful Python engineer working in a sandboxed workspace.\n\n"
              + (ws.root / "AGENTS.md").read_text())
    prompt = task
    for round_no in range(1, max_rounds + 1):
        result = run_agent(system, prompt, tools, max_steps=12)   # fresh context each round
        ok, evidence = verify(ws)
        print(f"round {round_no}: agent stopped with '{result.stop_reason}', verified={ok}")
        if ok:
            return True, ws
        prompt = (f"{task}\n\nThe harness ran the tests after your last attempt. They do not pass:\n"
                  f"{evidence}\nFix the code in src/money.py and run the tests again.")
    return False, ws


if __name__ == "__main__":
    ok, ws = solve("Implement the functions in src/money.py so that all tests pass.")
    print("SOLVED" if ok else "NOT SOLVED", "| workspace:", ws.root)
