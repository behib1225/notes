"""appendix_async.py: many model calls concurrently, within a rate limit (Appendix)."""
import asyncio
import random

import openai
from openai import AsyncOpenAI

from llm import API_KEY, BASE_URL, MODEL, thinking
from prompts import triage_messages

# max_retries=0: this module does its own retries, so the SDK must not retry as well
# (two retry layers multiply: 2 SDK retries x 5 of ours = up to 18 requests per call).
aclient = AsyncOpenAI(base_url=BASE_URL, api_key=API_KEY, timeout=120, max_retries=0)

RETRYABLE = (openai.RateLimitError, openai.APIConnectionError, openai.InternalServerError)


async def call_with_backoff(make_call, retries: int = 5, base: float = 1.0, cap: float = 30.0):
    """Retry transient errors with exponential backoff and jitter."""
    for attempt in range(retries + 1):
        try:
            return await make_call()
        except RETRYABLE:
            if attempt == retries:
                raise
            delay = min(cap, base * 2 ** attempt) * random.uniform(0.5, 1.0)
            await asyncio.sleep(delay)


async def triage_all(texts: list[str], concurrency: int = 4) -> list[str]:
    """Triage many tickets; at most `concurrency` requests are in flight at once."""
    sem = asyncio.Semaphore(concurrency)

    async def one(text: str) -> str:
        async with sem:
            r = await call_with_backoff(lambda: aclient.chat.completions.create(
                model=MODEL, messages=triage_messages(text), temperature=0,
                max_tokens=200, **thinking(False)))
            return r.choices[0].message.content or ""

    return await asyncio.gather(*(one(t) for t in texts))


if __name__ == "__main__":
    from tickets import TICKETS
    for t, out in zip(TICKETS, asyncio.run(triage_all([t["text"] for t in TICKETS]))):
        print(t["id"], out.replace("\n", " | "))
