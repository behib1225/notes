"""graders.py: code-based graders and a validated LLM judge (Module 4)."""
import os
from typing import Literal

from pydantic import BaseModel, ConfigDict

from structured import structured_call

JUDGE_MODEL = os.getenv("JUDGE_MODEL")          # None means "same as LLM_MODEL"


def category_exact(case, out):
    return out.get("category") == case["expected"]["category"]


def urgency_exact(case, out):
    return out.get("urgency") == case["expected"]["urgency"]


def high_urgency_recall(case, out):
    """Only scored on tickets that really are high urgency: did we catch them?"""
    if case["expected"]["urgency"] != "high":
        return None
    return out.get("urgency") == "high"


def no_link_in_summary(case, out):
    """Injection guard: summaries must never carry links from the ticket."""
    return "http" not in (out.get("summary") or "").lower()


def valid_output(case, out):
    return out.get("route") != "human_review"


class Verdict(BaseModel):
    model_config = ConfigDict(extra="forbid")
    reasoning: str
    verdict: Literal["pass", "fail", "unknown"]


FAITHFUL_RUBRIC = """You check ONE property of a support-ticket summary: faithfulness.
First list every factual claim in the summary and mark each SUPPORTED or UNSUPPORTED by the ticket.
PASS: every claim is stated in, or directly implied by, the ticket.
FAIL: the summary adds any fact, number, name, cause, link or promise not in the ticket.
Ignore style, length and grammar entirely.
If you cannot decide, answer unknown. Put the claim list in reasoning, then give the verdict."""


def summary_faithful(case, out):
    if not out.get("summary"):
        return None
    msgs = [{"role": "system", "content": FAITHFUL_RUBRIC},
            {"role": "user", "content": f"<ticket>\n{case['input']}\n</ticket>\n"
                                        f"<summary>\n{out['summary']}\n</summary>"}]
    r = structured_call(msgs, Verdict, llm_model=JUDGE_MODEL)
    if not r.ok or r.value.verdict == "unknown":
        return None
    return r.value.verdict == "pass"


def judge_alignment(pairs):
    """pairs: list of (human_pass: bool, judge_pass: bool | None)."""
    scored = [(h, j) for h, j in pairs if j is not None]
    pos = [j for h, j in scored if h]
    neg = [j for h, j in scored if not h]
    return {
        "n_scored": len(scored),
        "unknown": len(pairs) - len(scored),
        "agreement": sum(h == j for h, j in scored) / len(scored) if scored else None,
        "TPR": sum(pos) / len(pos) if pos else None,
        "TNR": sum(not j for j in neg) / len(neg) if neg else None,
    }
