"""stats.py: error bars and paired comparisons (Module 4)."""
import math


def wilson(passes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    """95% Wilson score interval for a pass rate."""
    p = passes / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return centre - half, centre + half


def sign_test(fixed: int, broken: int) -> float:
    """Two-sided exact sign test (exact McNemar) on the discordant pairs."""
    n, k = fixed + broken, max(fixed, broken)
    if n == 0:
        return 1.0
    tail = sum(math.comb(n, i) for i in range(k, n + 1)) / 2 ** n
    return min(1.0, 2 * tail)
