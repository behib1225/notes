"""helpcenter.py: AcmeCloud help-centre articles (fictional), Module 5."""
DOCS = {
"refunds.md": """# Refund policy
## Eligibility
Annual plans can be refunded in full within 30 days of purchase. Monthly plans are not
refundable, but you can cancel at any time and keep access until the end of the billing period.
## Duplicate charges
If you were charged twice for the same invoice, the duplicate is refunded automatically within
5 business days. If it has not appeared after 5 business days, open a billing ticket with both
transaction IDs.
## How to request
Only workspace owners can request refunds, from Settings > Billing > Request refund. Support
agents cannot issue refunds directly; they forward requests to the billing team.""",

"two_factor.md": """# Two-factor authentication (2FA)
## Setting up
AcmeCloud supports authenticator apps (TOTP) and hardware security keys. SMS codes are not supported.
## Lost device
If you lose your 2FA device, use one of the ten recovery codes shown when you enabled 2FA. If you
have no recovery codes, a workspace owner can reset your 2FA from Settings > Members. If the only
owner is locked out, contact support with ID verification; this takes up to 2 business days.""",

"export.md": """# Exporting data
## CSV export
CSV export is available on all plans. Exports are limited to 1,000,000 rows per file; larger
exports are split into multiple files automatically.
## Parquet export (beta)
Parquet export is available as a beta on the Business plan only. Enable it under Settings > Labs.
Parquet files are typically 5 to 10 times smaller than the equivalent CSV.
## Known issues
Error EXP-207 means the export timed out after 15 minutes. Narrow the date range or use the API
export endpoint instead.""",

"api_limits.md": """# API rate limits
Requests are limited per workspace: 60 requests per minute on Starter, 600 on Team and 3,000 on
Business. When you exceed the limit the API returns HTTP 429 with a Retry-After header in seconds.
Use exponential backoff. Limits reset every minute and are not shared across workspaces.""",

"plans.md": """# Plans and pricing
Starter costs $8 per user per month, Team costs $20 per user per month and Business costs $35 per
user per month, billed monthly. Annual billing gives a 15% discount. Prices exclude VAT where
applicable. Plan changes take effect immediately; upgrades are prorated and downgrades apply
credit to the next invoice.""",

"data_deletion.md": """# Deleting your data
A user can delete their personal account from Profile > Delete account; this removes their
personal data within 30 days. Deleting a workspace requires the workspace owner and permanently
removes all workspace data after a 14-day grace period, during which the deletion can be
cancelled. Backups are purged within 90 days.""",

"status.md": """# Incidents and the status page
Current incidents are posted at status.acmecloud.example. During a major incident support replies
are delayed; there is no need to open a ticket for an issue already listed on the status page.
Business plan customers receive incident updates by email and have a 99.9% monthly uptime
commitment, with service credits if it is missed.""",
}
