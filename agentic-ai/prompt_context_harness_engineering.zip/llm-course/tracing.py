"""tracing.py: one JSON line per span (Module 8)."""
import contextlib, json, time, uuid


class Tracer:
    def __init__(self, path: str = "traces.jsonl"):
        self.path = path

    @contextlib.contextmanager
    def span(self, trace_id: str, kind: str, **attrs):
        record = {"trace_id": trace_id, "span_id": uuid.uuid4().hex[:8], "kind": kind, **attrs}
        start = time.perf_counter()
        try:
            yield record                        # the caller adds attributes, e.g. token counts
            record["status"] = "ok"
        except Exception as e:
            record["status"] = f"error: {e!r}"
            raise
        finally:
            record["duration_s"] = round(time.perf_counter() - start, 3)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=str) + "\n")
