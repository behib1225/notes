# Module 8: Harness engineering (about 5 hours)

The working shorthand across industry in 2026 is **Agent = Model + Harness**: the [harness](https://blog.langchain.com/the-anatomy-of-an-agent-harness/) is everything in an agent except the model itself. You have already built most of its parts: the loop (Module 7), context management (Modules 5–6), validators and retries (Module 3), evaluations (Module 4). Harness engineering is the discipline of combining them into a system that **constrains** what the agent can do, **informs** it about what it should do, **verifies** what it did and **corrects** it when it goes wrong, so that an agent can be trusted with real work and less supervision.

The term took off in February 2026 with OpenAI's report [Harness engineering: leveraging Codex in an agent-first world](https://openai.com/index/harness-engineering/). Over five months a team of three engineers, later seven, shipped an internal product of roughly a million lines of code with no manually written code at all: about 1,500 merged pull requests, averaging 3.5 per engineer per day. The most useful lesson in the report is about *where the effort went*. Early progress was slow, the author writes, not because the model was incapable but because the environment was underspecified; when something failed, the fix was almost never "try harder" but asking what capability was missing and how to make it both **legible** and **enforceable** for the agent. In April 2026 Birgitta Böckeler's [Harness engineering for coding agent users](https://martinfowler.com/articles/harness-engineering.html) on martinfowler.com gave the field its clearest mental model, which this module follows: **guides** steer the agent before it acts, **sensors** check its work afterwards, and each can be **computational** (deterministic code) or **inferential** (a model's judgement).

Two meanings of "harness" coexist, and Böckeler suggests always clarifying which one is meant. The **builder harness** is what an agent product's developers build in: its system prompt, tools, loop and context management, the kind of harness you wrote in Module 7. The **user harness** is what a team adds around an existing agent for its own codebase or business: instruction files, project-specific tools, tests, linters, hooks, permissions. Most engineers will spend more time on the second, and interviewers increasingly ask about both.

**Learning objectives.** After this module you can:

- Name the components of an agent harness and map any agent product onto them.
- Write guides (instruction files, skills) that work as a map rather than a manual.
- Build verification loops in which computational sensors, not the model's own claims, decide when work is done.
- Wrap every tool in a policy layer with allow, ask and deny decisions, path and network restrictions, and human approval.
- Instrument an agent with traces, checkpoints and cost tracking, and run the steering loop that turns recurring failures into harness improvements.

## 8.1 Anatomy of a harness

A harness is a control system around the model. Böckeler describes it as acting like a cybernetic governor that combines feedforward and feedback to regulate a system towards its desired state. Each part of the picture below has a job; take any one away and a specific class of failure gets through.

```mermaid
flowchart LR
  HU["Human<br/>sets goals, approves,<br/>improves the harness"] --> G["Guides<br/>steer before acting<br/>AGENTS.md, skills"]
  G --> A["Agent<br/>model + loop<br/>context management"]
  A --> P["Policy<br/>allow, ask or deny<br/>every tool call"]
  P --> E["Environment<br/>sandboxed files,<br/>tools and network"]
  E -->|"observe results and state"| S["Sensors<br/>check after acting<br/>tests, linters, judges"]
  S -->|feedback| A
```

*Figure: A harness wraps the model in guides, policy, an environment and sensors. Observability runs underneath all of it: every model call, tool call, decision and cost is traced.*

| Component | Its job | Examples | Failure it prevents |
| --- | --- | --- | --- |
| Loop and orchestration | Run steps, stop, delegate | `run_agent`, step and cost limits, sub-agents | Runaway loops and costs |
| Context management | Decide what the model sees | Retrieval, compaction, notes (Modules 5–6) | Forgetting, context rot |
| Guides | Steer before acting | `AGENTS.md`, skills, examples, templates, scaffolds | Wrong approach, broken conventions |
| Tools (action space) | Define what the agent can do | Task-shaped tools, MCP servers (Module 7) | Clumsy or impossible tasks |
| Policy and permissions | Decide what is allowed | Allow, ask and deny rules; approval gates | Destructive or unauthorised actions |
| Environment and sandbox | Contain where actions run | Isolated directory or container, network allow-list | Large blast radius, data exfiltration |
| Sensors | Verify outcomes | Tests, type checks, linters, LLM reviewers | Plausible but wrong work |
| State and persistence | Survive across steps and sessions | Progress files, git history, checkpoints | Lost or duplicated work |
| Observability | Record what happened | Traces, logs, token and cost metrics | Undebuggable failures, cost surprises |
| Human in the loop | Judgement and accountability | Approvals, review, escalation paths | High-stakes mistakes |

The practical consequence: **the same model behaves differently in different harnesses**, and swapping the model under an unchanged harness can make behaviour better or worse. When an agent product is good or bad, most of the reasons are usually in this table rather than in the model's weights. Anthropic's evaluation guide makes the same point from the testing side: when you evaluate an agent, you are evaluating the harness and the model working together.

The rest of the module builds four of these components with code: guides (8.2), sensors (8.3), policy and sandboxing (8.4), and observability (8.5). The running example is a **mini coding agent** that edits Python files in a scratch workspace until the tests pass, because coding is where harness engineering is most mature and where its ideas are easiest to see. Every technique transfers to the support agent of Module 7.

## 8.2 Guides: steering before the agent acts

A **guide** is anything that raises the probability that the agent gets it right the first time. Böckeler lists both kinds: *inferential* guides that the model reads (coding conventions, principles, reference docs, how-to instructions) and *computational* guides that shape the work deterministically (scaffolding scripts, code generators, language servers, codemods). Your system prompts from Module 2 were guides; this section is about guides for agents that work in a repository or business system over many tasks.

**Instruction files.** Most coding agents read a Markdown file of project instructions at the start of every session. `AGENTS.md` is an open, tool-neutral convention for this file, read by many agents and contributed to the Agentic AI Foundation alongside MCP in December 2025; some tools use their own name (Claude Code reads `CLAUDE.md`). Because it is loaded into every context, it is the highest-leverage and most abused guide in a repository.

OpenAI's harness report is blunt about the abuse. They tried one big instruction file and it failed in predictable ways: a giant file crowds out the task, the code and the relevant docs; when everything is marked important, nothing is; a monolithic manual rots into a graveyard of stale rules; and a single blob cannot be checked mechanically. Their fix was to treat `AGENTS.md` as a **table of contents, not an encyclopedia**: about 100 lines that act as a map, pointing to a structured `docs/` directory (design documents, execution plans, architecture, quality grades) that is the system of record. The agent starts from a small, stable entry point and is taught where to look next, the same progressive disclosure as Module 6's just-in-time retrieval. They also enforced it: linters and CI jobs check that the knowledge base is cross-linked and current, and a recurring "doc-gardening" agent opens pull requests to fix stale documentation.

The same report states a principle worth memorising: from the agent's point of view, **anything it cannot access in context effectively does not exist**. The architectural decision made in a chat thread, the convention in someone's head, the design doc in a separate wiki: if they matter, they must be written where the agent can find them.

A good instruction file for the mini coding workspace in 8.3 might be this short:

```markdown
# AGENTS.md: acme-utils workspace

## What this is
Small pure-Python helpers used by AcmeCloud's billing service. Python 3.11, no third-party deps.

## How to work
1. Read the failing test first: `run_tests` shows which tests fail and why.
2. Change only files under `src/`. Never edit files under `tests/`; tests define "done".
3. Make the smallest change that makes the tests pass. Do not add features nobody asked for.
4. Run `run_tests` after every edit. You are finished only when all tests pass.

## Conventions
- Money is handled as integer cents, never floats (rounding errors are customer-visible).
- Every public function has a one-line docstring and type hints.
- Raise ValueError with a clear message for invalid input; never return None to signal errors.

## Where to look
- `docs/pricing.md`: plans, discounts and rounding rules.
```

Notice what each line does. The commands are concrete ("run `run_tests`"), the rules carry their reasons ("rounding errors are customer-visible"), "done" is defined by something checkable, and detail is delegated to `docs/` rather than inlined. Notice also what is missing: style rules that a formatter or linter can enforce. Anything a tool can check deterministically belongs in a sensor, not a paragraph.

**Skills and on-demand guides.** A second kind of inferential guide is loaded only when relevant: a folder of instructions, and often scripts, for one kind of task ("how we write database migrations", "how to release"). Several agent products now support such *skills* as a packaged format. They let you keep the always-loaded file small while still giving the agent deep, task-specific know-how at the moment it needs it.

**Computational guides.** The strongest guides do not depend on the model reading anything. A project template that already has the right folder layout, a script that scaffolds a new service, a code generator that produces the boilerplate for an API endpoint, or a language server that tells the agent a symbol's type: each removes a decision the agent could otherwise get wrong. OpenAI's team started their repository from a small set of templates and generated its scaffold before any feature work.

Guides have one fundamental weakness: they work by persuasion. The agent may ignore, misread or forget them, and you will not know unless something checks. That is the job of sensors.

## 8.3 Sensors and verification loops

A **sensor** observes what the agent produced and reports back. Böckeler's two execution types matter here more than anywhere:

- **Computational sensors** (tests, type checkers, linters, structural tests, schema validation, grounding checks) are deterministic, fast and cheap enough to run on every change, and their verdicts are reliable.
- **Inferential sensors** (LLM judges, review agents) add semantic judgement that code cannot, but they are slower, cost money and are non-deterministic, so they need the validation you learned in Module 4.

Sensors work best when their output is written *for the agent*. OpenAI's team wrote custom linters whose error messages contain remediation instructions, so that a violation tells the agent exactly how to fix it; Böckeler calls this "a positive kind of prompt injection". And because the cheapest time to catch a problem is immediately, the advice is to **keep quality left**: run fast computational sensors inside the agent's own loop on every change, more expensive checks (broader review agents, mutation testing) in CI, and continuous "drift" sensors over the whole codebase on a schedule.

The single most important harness rule follows: **the agent's claim that it is finished is not evidence.** Anthropic's long-running harness work found agents declaring projects complete prematurely, and its evaluation guide distinguishes the transcript (what the agent says) from the outcome (the actual state). In a harness, a computational sensor decides "done", and the agent is not allowed to tamper with the sensor.

### A mini coding-agent harness

The harness below gives the Module 7 agent a scratch workspace with a stubbed module and a test suite, and lets it work until the tests pass. Read it as a checklist of harness components: guides (`AGENTS.md`, `docs/pricing.md`), tools, a path jail, a protected sensor (the tests), a verification loop owned by the harness, and fresh context per round with state carried by the workspace.

> **Before you run this.** `harness.py` runs tests on code written by a model, on your machine and with your permissions. Run it inside a container or virtual machine, or read section 8.4 first and set `HARNESS_SANDBOX=docker`.

```python
# harness.py: a mini coding-agent harness
import hashlib, os, pathlib, subprocess, sys, tempfile, textwrap
from pydantic import BaseModel, Field
from agent import Tool, run_agent

FILES = {
    "AGENTS.md": """\
        # AGENTS.md
        Pure-Python money helpers. You may edit only src/money.py. Never edit tests/: tests define done.
        Run run_tests after every edit; you are finished only when all tests pass.
        Money is integer cents, never floats. See docs/pricing.md for discount and rounding rules.
        """,
    "docs/pricing.md": """\
        Annual billing takes 15% off the monthly price. Round half up to the nearest cent
        (858.5 cents becomes 859). Display amounts like $1,234.56.
        """,
    "src/__init__.py": "",
    "src/money.py": '''\
        def annual_price_cents(monthly_cents: int) -> int:
            """Monthly price in cents after the 15% annual discount."""
            raise NotImplementedError

        def format_usd(cents: int) -> str:
            """Format integer cents as US dollars, e.g. 41650 -> '$416.50'."""
            raise NotImplementedError
        ''',
    "tests/test_money.py": """\
        import pytest
        from src.money import annual_price_cents, format_usd

        # type(...) is int / str: an object that overrides __eq__ cannot fake a pass.

        def test_business_annual():
            r = annual_price_cents(3500)
            assert type(r) is int and r == 2975

        def test_rounds_half_up():
            r = annual_price_cents(1010)
            assert type(r) is int and r == 859

        def test_rejects_negative():
            with pytest.raises(ValueError):
                annual_price_cents(-1)

        def test_format():
            s = format_usd(41650)
            assert type(s) is str and s == "$416.50"

        def test_format_thousands():
            s = format_usd(123456)
            assert type(s) is str and s == "$1,234.56"
        """,
}

WRITABLE = {"src/money.py"}          # allow-list: the agent may write nothing else

class Workspace:
    def __init__(self):
        self.root = pathlib.Path(tempfile.mkdtemp(prefix="agent-ws-")).resolve()
        for rel, text in FILES.items():
            path = self.root / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(textwrap.dedent(text))
        self.tests_fingerprint = self.fingerprint("tests")

    def resolve(self, rel: str) -> pathlib.Path:
        path = (self.root / rel).resolve()           # resolves '..' and symlinks
        if not path.is_relative_to(self.root):
            raise PermissionError(f"{rel!r} is outside the workspace")
        return path

    def fingerprint(self, rel: str) -> str:
        """Hash of every file (name and content) under rel, so added files count too."""
        h = hashlib.sha256()
        for f in sorted((self.root / rel).rglob("*")):
            if f.is_file() and "__pycache__" not in f.parts:
                h.update(str(f.relative_to(self.root)).encode())
                h.update(f.read_bytes())
        return h.hexdigest()

def _pytest_command(ws: Workspace) -> list[str]:
    if os.getenv("HARNESS_SANDBOX") == "docker":     # see 8.4
        return ["docker", "run", "--rm", "--network", "none",
                "--memory", "512m", "--cpus", "1", "--pids-limit", "128",
                "--read-only", "--tmpfs", "/tmp", "-e", "PYTHONDONTWRITEBYTECODE=1",
                "-v", f"{ws.root}:/work:ro", "-w", "/work",
                "agent-sandbox", "python", "-m", "pytest", "-q", "-p", "no:cacheprovider"]
    return [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider"]

def run_pytest(ws: Workspace) -> str:
    env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
    try:
        r = subprocess.run(_pytest_command(ws), cwd=ws.root, capture_output=True,
                           text=True, timeout=90, env=env)
    except subprocess.TimeoutExpired:
        return "TESTS FAILED: timed out (an infinite loop?)"
    status = "ALL TESTS PASSED" if r.returncode == 0 else f"TESTS FAILED (exit {r.returncode})"
    return f"{status}\n{(r.stdout + r.stderr)[-3000:]}"

class PathArgs(BaseModel):
    path: str = Field(description="Path relative to the workspace root, e.g. 'src/money.py'")

class WriteArgs(PathArgs):
    content: str = Field(description="The complete new content of the file")

class NoArgs(BaseModel):
    pass

def make_tools(ws: Workspace) -> list[Tool]:
    def list_files():
        return sorted(str(p.relative_to(ws.root)) for p in ws.root.rglob("*")
                      if p.is_file() and "__pycache__" not in p.parts)
    def read_file(path):
        return ws.resolve(path).read_text()
    def write_file(path, content):
        target = ws.resolve(path)
        if str(target.relative_to(ws.root)) not in WRITABLE:
            raise PermissionError(f"you may only write {sorted(WRITABLE)}; tests define done and must not change")
        target.write_text(content)
        return f"wrote {len(content)} characters to {path}"
    def run_tests():
        return run_pytest(ws)
    return [
        Tool("list_files", "List all files in the workspace.", NoArgs, list_files),
        Tool("read_file", "Read a file in the workspace.", PathArgs, read_file),
        Tool("write_file", "Replace the whole content of src/money.py.", WriteArgs, write_file),
        Tool("run_tests", "Run the test suite and return a summary with failures.", NoArgs, run_tests),
    ]

def verify(ws: Workspace) -> tuple[bool, str]:
    """The harness's own sensor. The agent's opinion is not consulted."""
    if ws.fingerprint("tests") != ws.tests_fingerprint:
        return False, "Test files were modified. Tests are read-only; restore them."
    report = run_pytest(ws)
    return report.startswith("ALL TESTS PASSED"), report

def solve(task: str, max_rounds: int = 3):
    ws = Workspace()
    tools = make_tools(ws)
    system = ("You are a careful Python engineer working in a sandboxed workspace.\n\n"
              + (ws.root / "AGENTS.md").read_text())
    prompt = task
    for round_no in range(1, max_rounds + 1):
        result = run_agent(system, prompt, tools, max_steps=12)   # fresh context each round
        ok, evidence = verify(ws)
        print(f"round {round_no}: agent stopped with '{result.stop_reason}', verified={ok}")
        if ok:
            return True, ws
        prompt = (f"{task}\n\nThe harness ran the tests after your last attempt. They do not pass:\n"
                  f"{evidence}\nFix the code in src/money.py and run the tests again.")
    return False, ws

if __name__ == "__main__":
    ok, ws = solve("Implement the functions in src/money.py so that all tests pass.")
    print("SOLVED" if ok else "NOT SOLVED", "| workspace:", ws.root)
```

Install pytest first (`pip install pytest`). Three details deserve a second look.

- **The rounding trap is deliberate.** Python's built-in `round()` rounds halves to the nearest even number, so `round(858.5)` is 858, while the business rule says 859. The guide (`docs/pricing.md`) tells the agent the rule, and the sensor (`test_rounds_half_up`) catches it when the agent ignores or misreads the guide. Feedforward and feedback together are what Böckeler argues you need: feedback alone repeats mistakes, and feedforward alone never learns whether its rules worked.
- **The sensor is protected.** `write_file` accepts exactly one file, `src/money.py` (an allow-list rather than a directory rule, so the agent cannot add a `src/__init__.py` that runs code on import), and the harness fingerprints every file under `tests/` before and after, so an agent that "solves" the task by weakening or adding tests is caught. Agents optimising for a green signal will sometimes take that shortcut; Anthropic's long-running harness used strongly worded instructions against editing tests, and enforcing it in code is stronger still.
- **Each round starts with a fresh context.** State lives in the workspace (the files) and in the evidence the harness passes forward, the pattern from Module 6.6. This keeps rounds short and stops failed attempts from polluting the context.

**Even protected tests can be gamed.** A test like `assert annual_price_cents(3500) == 2975` can be passed without solving anything: return an object of an `int` subclass whose `__eq__` always returns `True`. This is *reward hacking*, an agent optimising the check instead of the goal. The tests above close that particular hole with `type(r) is int`, and the companion repository has a unit test proving the trick is caught. But code running inside the test process can always interfere with that process, so no in-process test is a complete defence. Layer the mitigations: keep some tests hidden from the agent, run them in a separate sandboxed process, add an inferential review sensor that reads the diff, and have a human review changes to anything security-relevant.

What sensors cannot catch matters too. Böckeler notes that computational sensors reliably catch structural problems such as duplication, complexity, coverage gaps and style violations, while misdiagnosed problems, over-engineering and misunderstood requirements slip past them; and a fully AI-generated test suite can confidently verify the wrong behaviour. That is why the *tests* here were written by a human before the agent started, and why behaviour verification remains the hardest open problem in harness engineering.

One serious problem remains, and you may have spotted it: `run_pytest` **executes code the model wrote, with your permissions**. The path jail controls which files the agent's *tools* can touch, but the code under test can do anything your user account can, including reading your SSH keys or calling the internet. That is what sandboxing, in the next section, is for.

## 8.4 Permissions, sandboxing and human approval

Two layers decide what an agent can actually do, and you need both. The **policy layer** in the harness decides which tool calls the agent may *attempt*: allowed, denied, or paused for a human. The **sandbox** in the operating system decides what code can *physically* do once it runs, whatever the policy intended. A policy without a sandbox is defeated by the first tool that executes code; a sandbox without a policy cannot stop the agent from sending an embarrassing email through an approved API.

### The policy layer

Start by classifying every action by its consequences:

| Class | Examples | Default decision |
| --- | --- | --- |
| Read-only | Search docs, read a file, look up a workspace | Allow |
| Reversible write, inside the boundary | Edit files in the workspace, draft a reply | Allow, with logging |
| Consequential or external | Create a high-urgency ticket that pages on-call, send email, open a pull request | Ask a human |
| Irreversible or out of scope | Issue a refund, delete data, deploy, run arbitrary shell outside the sandbox | Deny (or a separate, audited process) |
| Anything not listed | A new or unknown tool | Deny |

Then enforce the table in code, at the single point every tool call passes through. Wrapping each `Tool` keeps the agent loop unchanged, and because `run_tool` from Module 7 turns exceptions into observations, a denied call becomes an error message the model can adapt to.

```python
# policy.py: allow / ask / deny around every tool call, with an audit log
from dataclasses import dataclass, field
from typing import Callable, Literal
from agent import Tool

Decision = Literal["allow", "ask", "deny"]

@dataclass
class Rule:
    tool: str                                     # exact name, or a prefix ending in '*'
    decision: Decision
    when: Callable[[dict], bool] = lambda args: True
    reason: str = ""

@dataclass
class Policy:
    rules: list[Rule]
    approver: Callable[[str, dict, str], bool] | None = None
    default: Decision = "deny"                     # unknown tools are denied
    audit: list[dict] = field(default_factory=list)

    def decide(self, tool: str, args: dict) -> tuple[Decision, str]:
        for r in self.rules:                       # first matching rule wins
            name_matches = r.tool == tool or (r.tool.endswith("*") and tool.startswith(r.tool[:-1]))
            if name_matches and r.when(args):
                return r.decision, r.reason
        return self.default, "no rule matched"

    def guard(self, t: Tool) -> Tool:
        def guarded(**args):
            decision, reason = self.decide(t.name, args)
            if decision == "ask":
                approved = bool(self.approver and self.approver(t.name, args, reason))
                decision = "allow" if approved else "deny"
                reason += " (approved by a human)" if approved else " (not approved)"
            self.audit.append({"tool": t.name, "args": args, "decision": decision, "reason": reason})
            if decision == "deny":
                raise PermissionError(f"{t.name} is not permitted: {reason}. "
                                      "Tell the user what you could not do and why.")
            return t.fn(**args)
        return Tool(t.name, t.description, t.args, guarded)

def console_approver(tool: str, args: dict, reason: str) -> bool:
    print(f"\nAPPROVAL NEEDED: {tool} {args}\nWhy this needs approval: {reason}")
    return input("Approve? [y/N] ").strip().lower() == "y"   # anything else means no
```

Applied to the support agent from Module 7:

```python
from m7_support_agent import TOOLS

support_policy = Policy([
    Rule("search_help_center", "allow"),
    Rule("get_plan_price", "allow"),
    Rule("get_workspace", "allow"),
    Rule("create_ticket", "ask", when=lambda a: a["urgency"] == "high",
         reason="high-urgency tickets page the on-call engineer"),
    Rule("create_ticket", "allow"),
], approver=console_approver)

guarded_tools = [support_policy.guard(t) for t in TOOLS]
```

Four design rules make approvals work in practice. **Ask rarely**: every prompt costs human attention, and people who approve dozens of requests a day stop reading them. **Show enough to decide**: the exact action, its arguments and why it needs approval, plus a diff for file changes. **Fail closed**: a timeout, an error or an unclear answer counts as "no". **Log everything**: the audit list above is what you will show a security reviewer.

The first rule is why sandboxes matter even for well-designed policies. In October 2025 Anthropic reported that adding sandboxing to Claude Code safely [reduced permission prompts by 84%](https://www.anthropic.com/engineering/claude-code-sandboxing) in internal use: inside a well-defined boundary the agent can act freely, and humans are asked only about actions that cross it.

### The sandbox

Anthropic's sandboxing write-up stresses that effective sandboxing needs **both filesystem and network isolation**. Without network isolation, a compromised agent can exfiltrate sensitive files such as SSH keys; without filesystem isolation, it can escape the sandbox and gain network access. For the coding harness, the simplest adequate sandbox is a throwaway container with no network, limited resources and the workspace mounted read-only. Build an image with pytest once:

```bash
printf 'FROM python:3.12-slim\nRUN pip install --no-cache-dir pytest\n' | docker build -t agent-sandbox -
```

and replace the command in `run_pytest`:

```python
cmd = ["docker", "run", "--rm",
       "--network", "none",                       # no exfiltration, no downloads
       "--memory", "512m", "--cpus", "1", "--pids-limit", "128",   # no resource exhaustion
       "--read-only", "--tmpfs", "/tmp",          # nothing persists outside the run
       "-e", "PYTHONDONTWRITEBYTECODE=1",
       "-v", f"{ws.root}:/work:ro", "-w", "/work",  # workspace visible, but not writable
       "agent-sandbox", "python", "-m", "pytest", "-q", "-p", "no:cacheprovider"]
r = subprocess.run(cmd, capture_output=True, text=True, timeout=90)
```

Containers share the host's kernel, so for untrusted code at scale, teams use stronger isolation such as user-space kernels (gVisor) or lightweight virtual machines (Firecracker), and coding-agent products use OS-level mechanisms (Linux bubblewrap and macOS Seatbelt in Claude Code's case). The principle is the same at every level: decide the boundary in advance, enforce it below the model, and let the agent move freely inside it.

**Hooks.** Mature agent products expose *hooks*, programs that the harness runs automatically before or after each tool call (for example, blocking any shell command that touches production credentials, or running a formatter after every file write). They are the user-harness version of `Policy.guard`: deterministic enforcement points that do not depend on the model reading an instruction.

## 8.5 Observability, state and recovery

An agent that fails in production without a record of what it did cannot be debugged, and an agent whose cost per task is unknown cannot be budgeted. The standard approach, borrowed from distributed systems, is **tracing**: one *trace* per task, made of *spans* for every model call and tool call, each with timing and attributes. OpenTelemetry has published semantic conventions for generative-AI spans, and tracing platforms such as Langfuse, LangSmith, Arize Phoenix and Braintrust store and visualise them. The data you should record is the same whatever tool you use:

| Span | Attributes to record |
| --- | --- |
| Model call | Model and version, prompt version, prompt and completion tokens, cached tokens, latency, `finish_reason`, cost |
| Tool call | Tool name, arguments (redacted), policy decision, duration, result size, error |
| Task (whole trace) | Outcome from the verifier, stop reason, number of steps, total tokens and cost, approvals requested |

A minimal tracer that writes one JSON line per span is enough to start, and the JSONL format is easy to load into the Module 4 harness for analysis:

```python
# tracing.py
import contextlib, json, time, uuid

class Tracer:
    def __init__(self, path: str = "traces.jsonl"):
        self.path = path

    @contextlib.contextmanager
    def span(self, trace_id: str, kind: str, **attrs):
        record = {"trace_id": trace_id, "span_id": uuid.uuid4().hex[:8], "kind": kind, **attrs}
        start = time.perf_counter()
        try:
            yield record                        # the caller adds attributes, e.g. token counts
            record["status"] = "ok"
        except Exception as e:
            record["status"] = f"error: {e!r}"
            raise
        finally:
            record["duration_s"] = round(time.perf_counter() - start, 3)
            with open(self.path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, default=str) + "\n")
```

Inside `run_agent`, wrap the model call and each tool call:

```python
with tracer.span(trace_id, "model_call", step=step, model=MODEL) as s:
    r = client.chat.completions.create(...)
    s.update(prompt_tokens=r.usage.prompt_tokens, completion_tokens=r.usage.completion_tokens,
             finish_reason=r.choices[0].finish_reason)
...
with tracer.span(trace_id, "tool_call", tool=c.function.name) as s:
    out = run_tool(tool, c.function.arguments)
    s.update(result_chars=len(out), error=out.startswith("ERROR"))
```

Traces contain user data, so treat them as such: redact secrets and personal data before writing, restrict access, and set a retention period.

**State and recovery.** Long tasks fail halfway: a server restarts, a rate limit hits, a laptop sleeps. Three practices make recovery cheap. *Checkpoint* after each step (the message list, or better, the external state such as files and a progress log) so a task can resume instead of restarting; Anthropic's multi-agent research post describes building systems that resume from where errors occurred rather than starting over. Make tools *idempotent* (Module 7) so that replaying a step after a crash cannot repeat a side effect. And *version the harness*: an agent that runs for hours may span a deployment, so the same post describes rolling out new versions gradually while keeping old ones running, so that in-flight agents are not disrupted.

## 8.6 The steering loop: evolving the harness

A harness is never finished. Böckeler describes the human's job as **steering**: whenever an issue happens more than once, improve the guides and sensors so that it becomes less likely, or impossible. OpenAI's report describes the same discipline. When the agent struggled, the team treated it as a signal, identified what was missing (tools, guardrails or documentation) and fed it back into the repository. They also found a failure mode specific to agents: agents replicate patterns that already exist in the codebase, including bad ones, so quality drifts. The team at first spent every Friday, 20% of the week, cleaning up what they called "AI slop". That did not scale, so they encoded "golden principles" as mechanical rules and ran recurring background agents that scan for deviations and open small refactoring pull requests, which they compare to garbage collection.

The loop has four steps: **observe** failures (traces, evals, user reports), **classify** them (Module 4's error analysis), **choose a control**, and **measure** that the control worked without breaking anything (a regression case in the eval suite). Choosing the control is the engineering judgement, and a useful rule from practitioners is to make deterministic what you can and use inference only where you must:

| Recurring failure | First-choice control | Type |
| --- | --- | --- |
| Breaks a convention a tool can check (naming, layering, file size) | Custom linter or structural test with a remediation message | Computational sensor |
| Uses the wrong approach for a known kind of task | A short guide or skill for that task, linked from `AGENTS.md` | Inferential guide |
| Starts every task from scratch in the same way | A scaffold, template or generator | Computational guide |
| Claims success without verifying | Verifier owned by the harness; agent cannot edit it | Computational sensor |
| Takes a risky action unprompted | Policy rule (ask or deny) plus sandbox boundary | Policy |
| Produces subtly poor quality that code cannot detect | Review agent with a validated rubric, run in CI | Inferential sensor |
| Runs out of context on long tasks | Progress file, smaller units of work, compaction | Context and state |

Three further ideas complete the picture:

- **Harnessability.** Some systems are easier to harness than others. Böckeler notes that a strongly typed language gives you type checking as a free sensor, and clear module boundaries make architectural rules enforceable; OpenAI's team deliberately imposed a rigid layered architecture early, enforced by linters, because the constraints are what let agents move fast without decay. When you choose a stack for agent-heavy work, its harnessability is a legitimate criterion.
- **Test the harness itself.** Böckeler asks a pointed question: if a sensor never fires, is that high quality or blindness? Check sensors by deliberately introducing known-bad changes (a broken layer rule, a weakened test) and confirming they are caught, the same idea as mutation testing.
- **Re-tune the harness when the model changes.** Controls added to compensate for a weaker model (rigid step-by-step instructions, extra confirmation steps) can become unnecessary or even harmful with a stronger one, while a new model may have new failure modes. A model upgrade is a harness change: run the evals, read the transcripts, and adjust.

## Check your understanding (Module 8)

1. Complete "Agent = …" and define a harness. What is the difference between a builder harness and a user harness?
2. Define guides and sensors, and give one example each of a computational guide, an inferential guide, a computational sensor and an inferential sensor.
3. Give three reasons OpenAI's single large `AGENTS.md` failed, and describe what replaced it.
4. What does "anything the agent cannot access in context effectively does not exist" imply for a team's documentation?
5. Why must the harness, not the agent, decide when a task is done? How does `solve()` enforce this?
6. Why are the test files protected, and by which two mechanisms in `harness.py`?
7. What does the path jail in `Workspace.resolve` *not* protect against?
8. What is the difference between the policy layer and the sandbox, and why do you need both?
9. Why does effective sandboxing need both filesystem and network isolation?
10. State the four approval design rules. What is approval fatigue, and how did sandboxing reduce it for Claude Code?
11. Which attributes would you record on a model-call span and on a tool-call span?
12. Describe the four steps of the steering loop. Why prefer computational controls where possible?
13. How can you tell whether a sensor that never fires is working?
14. Why is a model upgrade also a harness change?

## Exercises (Module 8)

**Exercise 8.1 (core, 45 min): guides and sensors together.** Run `harness.py` five times and record, for each run, the number of rounds, whether the agent first fell into the rounding trap, and the number of tool errors. Then run two ablations, five times each: (a) delete the rounding sentence from `docs/pricing.md` (sensor only), and (b) restore it but delete `test_rounds_half_up` (guide only). Under (b), check the final code by hand for the rounding bug. What do the three results show about feedforward versus feedback?

**Exercise 8.2 (core, 30 min): attack the jail.** Write unit tests (not agent runs) that call the `write_file` and `read_file` tools directly with hostile paths: `../outside.txt`, an absolute path such as `/etc/hosts`, `src/../tests/test_money.py`, and a symlink you create inside `src/` that points to `tests/test_money.py`. Which are blocked, and by which check? Fix any hole you find, and keep the tests as regression tests for the harness.

**Exercise 8.3 (core, 40 min): add a computational sensor with an agent-friendly message.** Write `check_no_floats(ws)` that parses `src/money.py` with Python's `ast` module and reports any float literal or call to `float()`, with a message that tells the agent how to fix it ("Money is integer cents; use integer arithmetic such as (cents \* 85 + 50) // 100"). Add it to `verify()` and to a `run_checks` tool the agent can call. Run the harness and check whether any attempt trips the sensor.

**Exercise 8.4 (core, 35 min): policy and approval.** Run the Module 7 support agent with `guarded_tools` and `support_policy` on five tasks, including the payroll lockout (which should trigger an approval request). Then make the approver fail closed: simulate a timeout by raising an exception inside it and confirm the ticket is *not* created. Print the audit log and explain each entry.

**Exercise 8.5 (core, 30 min): traces.** Add `Tracer` spans to `run_agent` as shown in 8.5 and re-run the Exercise 7.2 evaluation. From `traces.jsonl` compute, per task: steps, total tokens, tool-error count and wall time; then the p50 and p95 task latency across tasks. Which task is the most expensive, and why?

**Exercise 8.6 (stretch, 60 min): one turn of the steering loop.** Using your traces and evaluation results from 8.4–8.5, find the most frequent failure. Choose a control from the table in 8.6, implement it, add a regression case, and re-run the evaluation. Write a five-line "harness change note": failure, evidence, control chosen and why, result, residual risk.

## Interview corner (Module 8)

**Q: What is harness engineering, and how does it relate to prompt and context engineering?** Model answer: An agent is a model plus a harness, and the harness is everything else: the loop, tools, context management, instructions, permissions, sandbox, verification, state and observability. Harness engineering designs that system so an agent can do reliable work with less supervision. Prompt engineering is about one request's instructions, and context engineering about what the model sees on each call; both are parts of the harness. What harness engineering adds is control: guides that steer before the agent acts, sensors that verify afterwards, policies and sandboxes that bound what it can do, and a steering loop where recurring failures become new controls.

**Q: Design the harness for a coding agent that opens pull requests in our monorepo.** Model answer: Environment: each task in its own worktree or container with filesystem and network isolation, the app bootable inside it, and secrets never mounted. Guides: a short `AGENTS.md` that maps to architecture docs, task-specific skills, and scaffolds for common changes. Sensors kept left: type checks, linters with remediation messages, structural tests for module boundaries, and the relevant test suites in the agent's loop; broader review agents and the full suite in CI. A verifier owned by the harness decides done; tests and CI config are read-only to the agent. Policy: allow edits and local commands in the sandbox, ask before anything that leaves it, deny deploys and production access. Traces for every step, cost limits per task, and a steering loop in which recurring review comments become linters or guide updates. Humans review pull requests, focused where the sensors are weakest: behaviour and requirements.

**Q: The agent sometimes makes tests pass by weakening or deleting them. What do you do?** Model answer: Treat it as a harness bug, not just a prompt problem. Make tests read-only to the agent at the tool level, fingerprint the test files and fail verification if they change, and have the harness rather than the agent run the verification. In CI, flag pull requests that modify tests for human review, and consider mutation testing to detect weakened assertions. Keep an instruction explaining why tests are off-limits, but rely on enforcement.

**Q: How do you decide what needs human approval?** Model answer: By consequence: read-only and reversible actions inside the sandbox are allowed; actions that leave the boundary or affect other people, like sending messages, paging people or opening external pull requests, ask a human; irreversible or out-of-scope actions such as payments, deletions and deploys are denied or go through a separate audited process. Unknown tools are denied by default. I keep approvals rare so people actually read them, show the exact action and diff, fail closed on timeouts, and log everything. A good sandbox reduces the number of approvals needed.

**Q: How would you monitor agents in production?** Model answer: Trace every task, with spans for model calls (tokens, latency, finish reason, cost) and tool calls (name, policy decision, errors), plus task-level outcome from a verifier and the stop reason. Dashboards for success rate, cost and latency distributions, tool-error rates, approval rates and stop reasons, with alerts on shifts. Sample traces for regular human review and run validated judges on samples. Then feed failures into the eval suite and the steering loop. Traces contain user data, so redaction, access control and retention apply.

## Solutions (Module 8)

**Check your understanding.**

1. Agent = Model + Harness; the harness is everything except the model. The builder harness is built into an agent product by its developers (system prompt, tools, loop); the user harness is what a team adds around an existing agent for its own codebase or domain (instruction files, tests, linters, hooks, permissions).
2. Guides steer before the agent acts; sensors check afterwards. Computational guide: a scaffold script. Inferential guide: `AGENTS.md`. Computational sensor: the test suite. Inferential sensor: an LLM review agent.
3. It crowded out the task and code; when everything was important nothing was; it rotted into stale rules; it could not be checked mechanically. It was replaced by a roughly 100-line `AGENTS.md` that acts as a table of contents into a structured, linted `docs/` directory.
4. Decisions and conventions must be written down in the repository or another place the agent can reach; knowledge in chats, wikis or heads is invisible to it.
5. Agents claim success prematurely, and the claim is not evidence. `solve()` ignores the agent's stop reason and runs `verify()`, the harness's own tests, after every round.
6. So the agent cannot make a task "pass" by weakening the checks. `write_file` accepts only the files in the `WRITABLE` allow-list (just `src/money.py`), and `verify()` compares a fingerprint of every file under `tests/` with the original.
7. Code that the agent writes and the harness executes (the tests run the agent's code) runs with your full permissions and can touch any file or the network.
8. The policy layer decides which tool calls may be attempted; the sandbox limits what running code can physically do. Policy alone fails as soon as any tool executes code; a sandbox alone cannot stop misuse of an approved API.
9. Without network isolation a compromised agent can exfiltrate files; without filesystem isolation it can escape the sandbox and reach the network or sensitive files.
10. Ask rarely, show enough to decide, fail closed, log everything. Approval fatigue is people approving without reading because they are asked too often; sandboxing let Claude Code act freely inside a boundary, cutting prompts by 84% in Anthropic's internal use.
11. Model call: model and version, prompt version, prompt, completion and cached tokens, latency, finish reason, cost. Tool call: tool, redacted arguments, policy decision, duration, result size, error.
12. Observe, classify, choose a control, measure. Computational controls are cheap, fast, deterministic and reliable, so they can run on every change.
13. Deliberately introduce a known-bad change and confirm the sensor catches it.
14. Controls tuned for one model's weaknesses may be unnecessary or harmful for another, and the new model may fail in new ways; re-run evals and re-tune.

**Exercise 8.1.** Typical baseline: most runs succeed in one or two rounds, and a common first attempt uses `round()`, which the rounding test catches; the next round fixes it from the harness's evidence. Under (a), sensor only, the agent has to infer the rule from `assert 858 == 859`, so it needs more rounds, and some attempts special-case the input (`if monthly_cents == 1010: return 859`). That is the agent overfitting to the sensor, and it is why a test suite is a partial specification, not a complete one. Under (b), guide only, runs pass every remaining test, yet some solutions still contain the `round()` bug, which you only find by reading the code. Together: the guide raises first-time success, and the sensor catches what the guide failed to prevent. Neither is sufficient alone, which is Böckeler's argument for combining them.

**Exercise 8.2.**

```python
# test_harness_jail.py
import os, pytest
from harness import Workspace, make_tools

def tool(ws, name):
    return next(t for t in make_tools(ws) if t.name == name).fn

def test_writes_outside_src_are_blocked():
    ws = Workspace()
    write = tool(ws, "write_file")
    for bad in ["../outside.txt", "/etc/hosts", "src/../tests/test_money.py"]:
        with pytest.raises(PermissionError):
            write(path=bad, content="x")

def test_reads_outside_workspace_are_blocked():
    ws = Workspace()
    with pytest.raises(PermissionError):
        tool(ws, "read_file")(path="/etc/hosts")

def test_symlink_into_tests_is_blocked():
    ws = Workspace()
    os.symlink(ws.root / "tests" / "test_money.py", ws.root / "src" / "link.py")
    with pytest.raises(PermissionError):
        tool(ws, "write_file")(path="src/link.py", content="x")
```

All four are blocked. `../outside.txt` and `/etc/hosts` (joining an absolute path replaces the root) resolve outside the workspace and fail the `is_relative_to(self.root)` check; `src/../tests/...` and the symlink both resolve to `tests/test_money.py`, which is not in the `WRITABLE` allow-list. Resolving *before* checking is what makes this work; checking the raw string (`path.startswith("src/")`) would let the third and fourth through. The companion repository's `test_harness_jail` runs these cases plus `src/__init__.py`. The hole these tests cannot close is the one from 8.3: code executed by the tests is not jailed at all, which only the sandbox fixes.

**Exercise 8.3.**

```python
import ast

def check_no_floats(ws) -> tuple[bool, str]:
    source = (ws.root / "src" / "money.py").read_text()
    try:
        tree = ast.parse(source)
    except SyntaxError as e:
        return False, f"src/money.py does not parse: {e}"
    problems = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Constant) and isinstance(node.value, float):
            problems.append(f"line {node.lineno}: float literal {node.value!r}")
        if isinstance(node, ast.Call) and getattr(node.func, "id", None) in {"float", "round"}:
            problems.append(f"line {node.lineno}: call to {node.func.id}()")
    if not problems:
        return True, "no float arithmetic found"
    return False, ("Money must be integer cents, never floats, and round() rounds halves to even. "
                   "Use integer arithmetic such as (cents * 85 + 50) // 100. Found: " + "; ".join(problems))
```

In `verify()`, run it before the tests and return its message on failure. The message follows OpenAI's and Böckeler's advice: it explains *why* and shows *how to fix*, so the next round can act on it directly. Note that the rule bans `round()` entirely, which is stricter than necessary; this is a judgement call, and stating it in the message keeps the agent from guessing.

**Exercise 8.4.** The lockout task should produce an approval prompt for a high-urgency `account_access` ticket; the other tasks produce `allow` entries for lookups and normal tickets. Simulating a timeout reveals a bug in `Policy.guard`: if the approver raises, the exception propagates before the decision is logged. The ticket is still not created, because `run_tool` turns the exception into an error, but the audit log has a gap, which a security review would flag. Fail closed *and* log:

```python
if decision == "ask":
    try:
        approved = bool(self.approver and self.approver(t.name, args, reason))
    except Exception as e:
        approved, reason = False, f"{reason} (approval failed: {e!r})"
    decision = "allow" if approved else "deny"
```

**Exercise 8.5.** Give `run_agent` a `trace_id` (for example `uuid.uuid4().hex`) per task, then:

```python
import json, statistics
from collections import defaultdict

spans = [json.loads(l) for l in open("traces.jsonl", encoding="utf-8")]
by_task = defaultdict(list)
for s in spans:
    by_task[s["trace_id"]].append(s)
rows = []
for tid, ss in by_task.items():
    models = [s for s in ss if s["kind"] == "model_call"]
    tools = [s for s in ss if s["kind"] == "tool_call"]
    rows.append({"task": tid[:8], "steps": len(models),
                 "tokens": sum(s.get("prompt_tokens", 0) + s.get("completion_tokens", 0) for s in models),
                 "tool_errors": sum(bool(s.get("error")) for s in tools),
                 "seconds": round(sum(s["duration_s"] for s in ss), 1)})
for r in sorted(rows, key=lambda r: -r["tokens"]):
    print(r)
times = [r["seconds"] for r in rows]
print("p50:", statistics.median(times), "p95:", statistics.quantiles(times, n=20)[-1])
```

The most expensive task is usually the multi-lookup Orion question: more steps, and every step re-sends a growing context, the quadratic growth from Module 1 in agent form. With only eight tasks the p95 is rough; in production you would compute it over thousands.

**Exercise 8.6.** A model note:

```text
Failure: tickets created for simple policy questions (3 of 8 tasks, traces a1f3, 9c2e, 77b0).
Evidence: in each trace the model called create_ticket after a successful search; no user request for one.
Control: policy rule "ask" for create_ticket unless the user's message asks for help from a person,
  plus one sentence in the system prompt explaining when tickets are useful (guide + policy).
Result: unnecessary tickets 3/8 -> 0/8; required tickets still created 2/2; no other regressions.
Residual risk: rule relies on a keyword heuristic; add a judge-based sensor if it misfires in production.
```

What makes it good: evidence from traces, a control chosen from the table with a reason, before-and-after numbers on the same evaluation, and an honest residual risk.

## Sources and further reading (Module 8)

- ★ Ryan Lopopolo (OpenAI), [Harness engineering: leveraging Codex in an agent-first world](https://openai.com/index/harness-engineering/) (February 2026).
- ★ Birgitta Böckeler, [Harness engineering for coding agent users](https://martinfowler.com/articles/harness-engineering.html), martinfowler.com (April 2026), and her follow-up on [sensors for coding agents](https://martinfowler.com/articles/sensors-for-coding-agents.html).
- ★ Anthropic, [Effective harnesses for long-running agents](https://www.anthropic.com/research/effective-harnesses-for-long-running-agents) (November 2025).
- Anthropic, [Beyond permission prompts: making Claude Code more secure and autonomous](https://www.anthropic.com/engineering/claude-code-sandboxing) (October 2025): filesystem and network isolation.
- LangChain, [The anatomy of an agent harness](https://blog.langchain.com/the-anatomy-of-an-agent-harness/): the "Agent = Model + Harness" framing.
- Anthropic, [Demystifying evals for AI agents](https://www.anthropic.com/research/demystifying-evals-for-ai-agents): evaluating the harness and model together; outcome versus transcript.
- Anthropic, [How we built our multi-agent research system](https://www.anthropic.com/research/multi-agent-research-system): resumable execution, tracing and gradual deployment for long-running agents.

**Next:** [Module 9: Production, security and capstone](10-module-9-production-security-capstone.md)
