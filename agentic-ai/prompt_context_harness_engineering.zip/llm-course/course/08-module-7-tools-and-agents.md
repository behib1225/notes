# Module 7: Tools and the agent loop (about 5 hours)

So far the model has only produced text. With **tools** it can ask your code to do things: look up an account, search documents, run a calculation, open a ticket. Put tool use inside a loop, and you have what Anthropic's [context engineering article](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents) calls its working definition of an agent: an LLM autonomously using tools in a loop. Every coding assistant, research agent and customer-support agent you will meet in industry is a variation of the loop you build in this module.

Two facts frame everything that follows. First, **the model never executes anything**. It emits a structured request ("call `search_help_center` with this query"); your code decides whether and how to run it and sends back the result. That gap is where safety, permissions and validation live, and Module 8 is largely about engineering it. Second, every tool result becomes context, so tools are also the main channel through which the context fills up and through which untrusted text enters it. Modules 5 and 6 apply here in full.

**Learning objectives.** After this module you can:

- Explain the function-calling round trip and implement it with the OpenAI-compatible API.
- Build an agent loop from scratch with a tool registry, error handling, stop conditions and a transcript.
- Design tools that models use correctly: names, descriptions, parameters, outputs and error messages.
- Decide when a fixed workflow beats an autonomous agent.
- Explain the Model Context Protocol (MCP) and build a minimal MCP server.

## 7.1 Function calling mechanics

With **function calling** (also called tool use), you describe tools to the model as JSON Schemas alongside the messages. The model can then answer with a structured request to call one or more of them instead of, or as well as, text. Your code runs the tool, appends the result to the conversation, and calls the model again so it can use the result.

```mermaid
sequenceDiagram
  participant U as User
  participant H as Your code (harness)
  participant M as Model
  participant T as Tool
  U->>H: 1. question
  H->>M: 2. messages + tool schemas
  M->>H: 3. tool call: name + arguments
  Note over H: validate, check permission
  H->>T: 4. execute the function
  T->>H: 5. result
  H->>M: 6. tool message with call id
  M->>H: 7. final answer
  H->>U: 8. answer
```

*Figure: The model only requests a tool call; your code runs it and returns the result.*

Here is the round trip with one tool, which also fixes a failure you met in Module 5: small models miscalculating the annual Business price. The rule "let code do arithmetic" becomes a tool.

```python
# m7_one_tool.py
import json
from llm import client, MODEL, thinking

PRICES = {"starter": 8.0, "team": 20.0, "business": 35.0}   # USD per user per month

def get_plan_price(plan: str, billing: str) -> dict:
    monthly = PRICES[plan]
    per_month = round(monthly * 0.85, 2) if billing == "annual" else monthly
    return {"plan": plan, "billing": billing, "usd_per_user_per_month": per_month}

TOOLS = [{
    "type": "function",
    "function": {
        "name": "get_plan_price",
        "description": "Price in USD per user per month for an AcmeCloud plan, including the "
                       "15% annual discount when billing is annual. Use for every price question.",
        "parameters": {
            "type": "object",
            "properties": {
                "plan": {"type": "string", "enum": ["starter", "team", "business"]},
                "billing": {"type": "string", "enum": ["monthly", "annual"]},
            },
            "required": ["plan", "billing"],
            "additionalProperties": False,
        },
    },
}]

messages = [
    {"role": "system", "content": "You are AcmeCloud's support assistant. Use tools for prices; "
                                  "never calculate prices yourself."},
    {"role": "user", "content": "What does Business cost per user per month if we pay annually?"},
]

r = client.chat.completions.create(model=MODEL, messages=messages, tools=TOOLS, **thinking(False))
msg = r.choices[0].message
if msg.tool_calls:
    # 1) Append the assistant turn that *requested* the calls, exactly as returned.
    messages.append({"role": "assistant", "content": msg.content or "",
                     "tool_calls": [{"id": c.id, "type": "function",
                                     "function": {"name": c.function.name,
                                                  "arguments": c.function.arguments}}
                                    for c in msg.tool_calls]})
    # 2) Run each call and append its result, linked by tool_call_id.
    for c in msg.tool_calls:
        args = json.loads(c.function.arguments)          # a JSON *string*: parse and validate it
        result = get_plan_price(**args)
        messages.append({"role": "tool", "tool_call_id": c.id, "content": json.dumps(result)})
    # 3) Call the model again so it can use the results.
    r = client.chat.completions.create(model=MODEL, messages=messages, tools=TOOLS, **thinking(False))
print(r.choices[0].message.content)
```

Six details in that code are the ones that cause most function-calling bugs in practice:

- **Arguments arrive as a JSON string**, generated by the model. They can be malformed or contain values outside your enum, so parse and validate them (Pydantic again) before acting.
- **Order matters.** The assistant message containing `tool_calls` must be appended *before* the tool results, and every call id needs exactly one result. Servers reject conversations that break this pairing, which is why Module 6 insisted on trimming at turn boundaries.
- **The model may call several tools at once** (parallel tool calls) or none. Always loop over `tool_calls` and handle the empty case.
- **`tool_choice` controls whether a call is forced**: `"auto"` (model decides), `"required"`, `"none"`, or a specific function. Support varies; Ollama's OpenAI-compatible endpoint currently ignores `tool_choice`, so your code must cope with the model answering in text when you expected a call.
- **The server translates tools through the chat template.** Tool schemas are rendered into the prompt in the model's trained format and the model's output is parsed back into `tool_calls`. On vLLM this needs `--enable-auto-tool-choice` and the right `--tool-call-parser` for the model family (Module 0); if the parser does not match, tool calls arrive as plain text in `content`.
- **Schemas can be strict.** On OpenAI, adding `"strict": true` to a function definition applies the constrained decoding of Module 3 to the arguments, with the same schema rules (all fields required, no additional properties).

## 7.2 The agent loop from scratch

An agent is the round trip from 7.1 repeated until the model stops asking for tools. The idea was popularised by the 2022 [ReAct paper](https://arxiv.org/abs/2210.03629) (Yao et al.), which interleaved reasoning traces with actions and their observations; native function calling is the productionised form of the same loop. The loop itself is short. What makes it production-shaped is everything around it: validated arguments, errors returned as observations instead of crashes, bounded output size, and explicit **stop conditions**.

```python
# agent.py: a minimal, production-shaped agent loop
import json
from dataclasses import dataclass, field
from typing import Callable
from pydantic import BaseModel, ValidationError
from llm import client, MODEL, split_reasoning, thinking

@dataclass
class Tool:
    name: str
    description: str
    args: type[BaseModel]                 # argument schema = validator
    fn: Callable[..., object]

    def schema(self) -> dict:
        return {"type": "function", "function": {
            "name": self.name, "description": self.description,
            "parameters": self.args.model_json_schema()}}

@dataclass
class AgentResult:
    answer: str | None
    stop_reason: str                      # done | max_steps | repeated_call
    steps: int
    transcript: list[dict] = field(default_factory=list)

MAX_RESULT_CHARS = 4000

def run_tool(tool: Tool, raw_args: str) -> str:
    """Validate, execute, and always return text the model can read."""
    try:
        args = tool.args.model_validate_json(raw_args or "{}")
    except ValidationError as e:
        err = e.errors()[0]
        return (f"ERROR: invalid arguments for {tool.name}: field {err['loc']} {err['msg']}. "
                "Fix the arguments and call the tool again.")
    try:
        result = tool.fn(**args.model_dump())
    except Exception as e:                # a failing tool is an observation, not a crash
        return f"ERROR: {tool.name} failed: {e}"
    text = result if isinstance(result, str) else json.dumps(result, ensure_ascii=False)
    if len(text) > MAX_RESULT_CHARS:      # protect the context budget (Module 6)
        text = text[:MAX_RESULT_CHARS] + "\n[truncated: ask for something narrower]"
    return text

def run_agent(system: str, user: str, tools: list[Tool], max_steps: int = 8) -> AgentResult:
    by_name = {t.name: t for t in tools}
    schemas = [t.schema() for t in tools]          # fixed for the whole run (cache-friendly)
    messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
    call_counts: dict[tuple, int] = {}
    for step in range(1, max_steps + 1):
        r = client.chat.completions.create(model=MODEL, messages=messages, tools=schemas,
                                           temperature=0, max_tokens=1500, **thinking(False))
        msg = r.choices[0].message
        _, text = split_reasoning(msg)
        if not msg.tool_calls:                     # stop condition 1: the model is done
            messages.append({"role": "assistant", "content": text})
            return AgentResult(text, "done", step, messages)
        messages.append({"role": "assistant", "content": text, "tool_calls": [
            {"id": c.id, "type": "function",
             "function": {"name": c.function.name, "arguments": c.function.arguments}}
            for c in msg.tool_calls]})
        for c in msg.tool_calls:
            key = (c.function.name, c.function.arguments)
            call_counts[key] = call_counts.get(key, 0) + 1
            if call_counts[key] > 2:               # stop condition 2: stuck in a loop
                return AgentResult(None, "repeated_call", step, messages)
            tool = by_name.get(c.function.name)
            out = (run_tool(tool, c.function.arguments) if tool else
                   f"ERROR: unknown tool {c.function.name!r}. Available tools: {sorted(by_name)}")
            messages.append({"role": "tool", "tool_call_id": c.id, "content": out})
    return AgentResult(None, "max_steps", max_steps, messages)   # stop condition 3: budget
```

Now give it a job. The support agent below has four tools: read-only lookups in the help centre, the pricing table and a (fake) account database, and one tool with a side effect, creating a ticket.

```python
# m7_support_agent.py
from typing import Literal
from pydantic import BaseModel, Field
from agent import Tool, run_agent
from rag import get_index          # builds the index on first use (Module 5)

PRICES = {"starter": 8.0, "team": 20.0, "business": 35.0}
WORKSPACES = {"orion": {"plan": "team", "seats": 14, "status": "active"},
              "vega": {"plan": "business", "seats": 52, "status": "active"}}
CREATED_TICKETS: list[dict] = []

class SearchArgs(BaseModel):
    query: str = Field(description="What to look up, in plain words, e.g. 'refund for a duplicate charge'")

class PriceArgs(BaseModel):
    plan: Literal["starter", "team", "business"]
    billing: Literal["monthly", "annual"]
    seats: int = Field(ge=1, description="Number of users to price; use the workspace's seat count, or 1")

class WorkspaceArgs(BaseModel):
    workspace: str = Field(description="Workspace name as the user wrote it, e.g. 'Orion'")

class TicketArgs(BaseModel):
    category: Literal["billing", "bug", "account_access", "feature_request", "other"]
    urgency: Literal["low", "medium", "high"]
    summary: str = Field(description="One sentence a support engineer can act on")

def search_help_center(query: str):
    return [{"id": c.id, "text": c.text} for c in get_index().hybrid(query, k=3)]

def get_plan_price(plan: str, billing: str, seats: int):
    per_user = round(PRICES[plan] * (0.85 if billing == "annual" else 1.0), 2)
    return {"plan": plan, "billing": billing, "seats": seats,
            "usd_per_user_per_month": per_user, "usd_total_per_month": round(per_user * seats, 2)}

def get_workspace(workspace: str):
    ws = WORKSPACES.get(workspace.strip().lower())
    if ws is None:
        raise ValueError(f"no workspace named {workspace!r}; ask the user to check the name")
    return {"workspace": workspace, **ws}

def create_ticket(category: str, urgency: str, summary: str):
    ticket = {"ticket_id": f"T-{1000 + len(CREATED_TICKETS)}", "category": category,
              "urgency": urgency, "summary": summary, "status": "open"}
    CREATED_TICKETS.append(ticket)
    return ticket

TOOLS = [
    Tool("search_help_center", "Search AcmeCloud's help-centre articles. Returns up to 3 passages "
         "with ids. Use for any question about policies, limits, features or errors.",
         SearchArgs, search_help_center),
    Tool("get_plan_price", "Exact price for a plan, billing period and number of seats, including "
         "the annual discount. Use instead of doing price arithmetic yourself.",
         PriceArgs, get_plan_price),
    Tool("get_workspace", "Look up a workspace's current plan, seat count and status by name.",
         WorkspaceArgs, get_workspace),
    Tool("create_ticket", "Open a ticket for the human support team. Only when the user's problem "
         "needs a person (refunds, account changes, bugs you cannot solve). Returns the ticket id.",
         TicketArgs, create_ticket),
]

SYSTEM = """You are AcmeCloud's support agent. Use tools to look up facts; never guess policies,
prices or account details. Base answers on tool results and cite help-centre ids in brackets.
Create a ticket only when the problem needs a human, and give the user the ticket id. Be concise."""

if __name__ == "__main__":
    result = run_agent(SYSTEM, "Our workspace Orion keeps hitting API rate limits. What is our "
                       "limit, and what would Business cost per month for all our seats if we pay "
                       "annually?", TOOLS)
    for m in result.transcript[2:]:
        print(m["role"], "|", (m.get("content") or "")[:120], "|",
              [c["function"]["name"] for c in m.get("tool_calls", [])])
    print("\nSTOP:", result.stop_reason, "after", result.steps, "steps\n", result.answer)
```

Two details in this file are deliberate. First, `get_plan_price` here extends the 7.1 version with a `seats` argument; the 7.1 file is a standalone first example and is not imported anywhere. Second, `seats` has no default. A Pydantic field with a default is optional in the generated JSON Schema, and OpenAI's strict mode requires every property to be listed as required, so optional fields are a common reason tools fail when you later turn strict mode on. Telling the model what to send ("or 1") is clearer than a hidden default.

A good run looks up the workspace (Team, 14 seats), searches the help centre for rate limits (600 requests per minute on Team, 3,000 on Business), prices Business annually for 14 seats ($29.75 per user, $416.50 per month in total) and answers with citations, in four to five steps. Read the transcript, not only the answer: the transcript is how you debug agents, and it is the input to the evaluations in Module 8.

Notice two design choices you will reuse. The pricing tool takes `seats` and returns the total, moving arithmetic out of the model entirely; Anthropic's tool-writing guidance calls this offloading computation from the agent into the tool. And `get_workspace` raises an error whose message tells the model what to do next ("ask the user to check the name"), which the loop turns into an observation the model can act on.

## 7.3 Designing tools agents can use well

Tool definitions are prompts. Their names, descriptions and parameter schemas sit in the context on every call, and they are the model's only information about what each tool does. Anthropic's [Building effective agents](https://www.anthropic.com/engineering/building-effective-agents) calls this the **agent-computer interface (ACI)** and argues it deserves as much design effort as a human-computer interface. Its follow-up, [Writing effective tools for agents](https://www.anthropic.com/research/writing-tools-for-agents) (September 2025), distils the practice into a handful of principles, summarised here with the triage-and-support examples from this course.

**1. Choose tools for tasks, not for API endpoints.** A tool per REST endpoint forces the agent to chain many calls and hold intermediate data in context. Build tools around the units of work the agent actually performs, and consolidate frequent multi-step sequences into one tool. `get_plan_price(plan, billing, seats)` returning the total is better than `get_price` plus mental arithmetic. Keep the set small and distinct: as Anthropic's context article puts it, if a human engineer cannot say definitively which tool to use in a situation, the agent cannot be expected to do better.

**2. Namespace related tools.** With many tools, especially from several MCP servers, prefixes such as `helpcenter_search` and `billing_get_invoice` make boundaries obvious. Anthropic reports that naming choices measurably affected their tool-use evaluations and that the best scheme varied by model, so test yours. Consistent prefixes also make it easy to allow or block a whole group (Module 8).

**3. Return meaningful, high-signal context.** Return names, titles and human-readable values rather than opaque UUIDs and low-level fields the model must decode. Where callers need different amounts of detail, offer a `response_format` parameter (`concise` or `detailed`); in one of Anthropic's examples the concise form used about a third of the tokens of the detailed one.

**4. Be token-efficient by design.** Add pagination, filters and sensible defaults, and truncate long outputs with a message telling the agent how to get more ("\[truncated: ask for something narrower\]" in `run_tool`). Anthropic notes that Claude Code caps tool responses at 25,000 tokens by default. A tool that can return a 50,000-row table will eventually fill the window.

**5. Write descriptions for a new colleague.** State what the tool does, when to use it, *when not to*, what each parameter means with an example, and what comes back. Make implicit knowledge explicit: query syntax, units, which ids are valid. Use unambiguous parameter names (`workspace_name`, not `name`).

**6. Make errors actionable.** "Invalid input" teaches nothing. "Invalid date format; use YYYY-MM-DD, for example 2026-11-19" lets the agent fix its own call on the next step.

**7. Mistake-proof the arguments.** *Building effective agents* describes the team's coding agent making mistakes with relative file paths after changing directory; requiring absolute paths eliminated the error. Enums instead of free strings, required fields instead of optional ones with surprising defaults, and validation in the tool itself (`seats >= 1`) all apply the same idea, known in manufacturing as *poka-yoke*.

**8. Separate reading from acting.** Keep read-only tools apart from tools with side effects (creating tickets, sending email, issuing refunds), make writes idempotent where possible (an idempotency key prevents a retried call from creating two tickets), and put risky actions behind confirmation. Module 8 turns this into a permission system.

| Weak definition | Better definition | Principle |
| --- | --- | --- |
| `search(q)`: "Searches." | `helpcenter_search(query)`: "Search help-centre articles about policies, limits, features and error codes. Returns up to 3 passages with ids to cite. Not for account-specific data; use get\_workspace." | 2, 5 |
| `get_user(id)` returning `{"uid": "8f3a…", "pl": 2}` | `get_workspace(workspace_name)` returning `{"plan": "team", "seats": 14}` | 3, 5 |
| `list_tickets()` returning every ticket | `list_tickets(status="open", limit=10, page=1)` | 4 |
| Raises `KeyError: 'orion '` | "No workspace named 'orion '; ask the user to check the name" | 6 |
| `price(plan, period)` with free-text period | `billing: "monthly" or "annual"` (enum), `seats` (integer ≥ 1) | 7 |

Finally, **evaluate tools like prompts.** Anthropic recommends tracking, besides task success, the number of tool calls, tool errors, tokens consumed and runtime. Many redundant calls suggest pagination or limits need resizing; many invalid-argument errors suggest unclear descriptions or missing examples. Exercise 7.3 does exactly this.

## 7.4 Workflows or agents?

*Building effective agents* draws the distinction that most teams now use. **Workflows** are systems where LLMs and tools are orchestrated through predefined code paths: the triage chain of Module 2 and the RAG pipeline of Module 5 are workflows. **Agents** are systems where the LLM dynamically directs its own process and tool use, deciding which step comes next, as `run_agent` does. The post's central advice is to find the simplest solution possible and only add complexity when it demonstrably improves results, because agentic systems trade latency and cost for better performance on open-ended tasks, and their errors can compound across steps.

| Question | Points to a workflow | Points to an agent |
| --- | --- | --- |
| Can you write down the steps in advance? | Yes, the path is known | No, steps depend on what is discovered |
| How many steps? | Fixed and few | Varies widely between tasks |
| Cost of a wrong action? | Any; easy to add checks between known steps | Low, or actions are sandboxed and reversible |
| Need for predictable latency and cost? | High | Can tolerate variance |
| Auditing and testing | Each step testable in isolation | Needs transcript-level evals (Module 4) |

In practice the two mix. A workflow can contain an agentic step (an agent that researches a ticket before a fixed reply template), and an agent can be confined to a narrow set of tools with workflow-style checks around risky actions. The triage component should stay a workflow; answering open-ended support questions that may need two or five lookups is a natural fit for an agent.

**Frameworks.** Many libraries implement agent loops, tool registries, memory and orchestration, including LangGraph, the OpenAI Agents SDK, the Claude Agent SDK, Google's Agent Development Kit and Pydantic AI. They save time and are common in job descriptions, so it is worth trying one after this course. But *Building effective agents* recommends starting with the model API directly, because frameworks add layers of abstraction that can obscure the underlying prompts and responses and make debugging harder; if you use one, make sure you understand what it sends. Having written `run_agent` yourself, you can read any framework's loop and recognise the same parts.

**Agents on small local models.** Everything in this module runs on `qwen3:8b`, but expect rougher behaviour than with frontier models: choosing the wrong tool when descriptions overlap, calling tools with invalid arguments, repeating the same call, stopping too early, or writing a tool call as plain text when the server's parser does not recognise the format. The mitigations are the ones you have built: few, distinct, well-described tools; validated arguments with actionable errors; temperature 0; explicit stop conditions; and an evaluation that measures task success and tool errors. Enabling thinking often improves multi-step tool use at a cost in tokens and latency; measure it rather than assuming, and check that tool calls are still parsed correctly when thinking is on.

## 7.5 The Model Context Protocol (MCP)

Every agent needs tools, and every company has the same services to connect: issue trackers, document stores, databases, calendars. Without a standard, each AI application builds its own connector to each service, N applications times M services. The **Model Context Protocol** is an open standard that removes that multiplication: a service is wrapped once as an **MCP server**, and any MCP-capable application (chat assistants, coding agents, IDEs, your own agent) can discover and use its tools. It plays the role for agents that the Language Server Protocol plays for code editors.

**Status, as of November 2026.** Anthropic introduced MCP in November 2024. In December 2025 it was donated to the Agentic AI Foundation, a directed fund under the Linux Foundation co-founded by Anthropic, Block and OpenAI, so it is now governed by a vendor-neutral body. The specification is versioned by date; the current revision, [2026-07-28](https://modelcontextprotocol.io/specification/2026-07-28/changelog), is its largest change since launch: the protocol became stateless, removing the initialisation handshake and protocol-level sessions so that remote servers can run like ordinary stateless HTTP services. Expect tutorials written before mid-2026 to show the older handshake; the concepts below are unchanged.

**Architecture.** A **host** is the application that runs the model (an IDE, a desktop assistant, your agent). Inside it, an MCP **client** manages the connection to each **server**. Messages are JSON-RPC 2.0. Servers expose three kinds of capability:

- **Tools**: functions the *model* decides to call (search, create a ticket). This is the primitive you will use most.
- **Resources**: data the *application* can read and attach to the context (a file, a database row, an article).
- **Prompts**: reusable templates the *user* can invoke (a "summarise this ticket" command).

There are two standard transports. **stdio** runs the server as a local subprocess that talks over standard input and output, with the user's own permissions. **Streamable HTTP** serves remote, shared servers, with an OAuth-based authorization framework; the older HTTP-plus-SSE transport is deprecated.

**How it relates to function calling.** MCP standardises the *tool side*, not the model side. The host asks each server for its tool list, converts the definitions into the function-calling format of whichever model it uses, and when the model requests a call, forwards it to the right server and returns the result as a tool message, exactly the round trip of 7.1. Everything in 7.3 about tool design therefore applies unchanged to MCP servers.

### A minimal MCP server

The official Python SDK turns decorated functions into MCP tools, deriving schemas from type hints and descriptions from docstrings. Install it with `pip install "mcp[cli]"`.

```python
# mcp_helpcenter.py: the help centre as an MCP server
# Official MCP Python SDK v2 (tested with mcp 2.3.0). SDK 1.x called this class FastMCP:
#   from mcp.server.fastmcp import FastMCP as MCPServer      (pin mcp<2 to use 1.x code)
from mcp.server import MCPServer
from helpcenter import DOCS
from rag import get_index

mcp = MCPServer("acme-helpcenter")

@mcp.tool()
def helpcenter_search(query: str, k: int = 3) -> list[dict]:
    """Search AcmeCloud help-centre articles about policies, limits, features and error
    codes. Returns up to k passages (maximum 5), each with an id to cite. Not for
    account-specific data such as a customer's plan or invoices."""
    k = max(1, min(k, 5))
    return [{"id": c.id, "title": f"{c.title} > {c.section}", "text": c.text}
            for c in get_index().hybrid(query, k=k)]

@mcp.resource("helpcenter://articles/{name}")
def article(name: str) -> str:
    """Full text of one help-centre article, for example refunds.md."""
    return DOCS[name]

if __name__ == "__main__":
    mcp.run()      # stdio by default; mcp.run(transport="streamable-http") serves over HTTP
```

The API was checked against the installed SDK: in `mcp` 2.3.0, `from mcp.server import MCPServer` works, `run()` defaults to the stdio transport and accepts `"streamable-http"`, and importing the 1.x module `mcp.server.fastmcp` fails with a message pointing to the migration guide. The index is built on the first search rather than at start-up, so the server starts instantly and nothing is printed to stdout.

Test it interactively with the official **MCP Inspector**: `npx @modelcontextprotocol/inspector python mcp_helpcenter.py` opens a browser UI where you can list and call the tools. Then register it in any MCP host; most use a configuration entry of this shape (file names and locations differ by host):

```json
{"mcpServers": {"acme-helpcenter": {"command": "python", "args": ["/absolute/path/to/mcp_helpcenter.py"]}}}
```

One trap catches almost everyone writing a first stdio server: **standard output is the protocol channel**. A stray `print()` corrupts the stream and the host disconnects. Log to standard error instead.

### MCP security in one paragraph

An MCP server is code you run, and its outputs are text your model reads, so both deserve the scrutiny you would give any dependency and any untrusted input. A stdio server runs with your permissions and can do anything you can. Tool *descriptions* are injected into the model's context, so a malicious or compromised server can hide instructions in them (**tool poisoning**), and a server can change its descriptions after you approved it. Tool *results* can carry injected instructions from the web pages, emails or tickets they contain. Tool annotations such as `readOnlyHint` and `destructiveHint` are hints from the server, not enforcement. Practical rules: install servers only from sources you trust and pin their versions; grant each server the least privilege it needs; prefer read-only servers; require confirmation for destructive tools; and treat every tool result as data, not instructions. Module 9 covers prompt injection in depth.

## Check your understanding (Module 7)

1. Who executes a tool call, and why does that matter for safety?
2. In what order must messages be appended during a tool round trip, and what happens if the order is wrong?
3. Why must tool arguments be validated even when the schema was sent to the model?
4. Name the three stop conditions in `run_agent` and the failure each prevents.
5. Why does `run_tool` return errors as text instead of raising them?
6. Why are the tool schemas computed once and kept fixed for the whole run?
7. State four tool-design principles from 7.3, each with an example.
8. Define workflow and agent in Anthropic's sense. Which should the triage component be, and why?
9. Why does the pricing tool take `seats` and return a total?
10. In MCP, what are the host, client and server? Name the three server primitives and the two transports.
11. What did the 2026-07-28 MCP revision change?
12. Name two security risks specific to using third-party MCP servers.

## Exercises (Module 7)

**Exercise 7.1 (warm-up, 20 min): why tools beat mental arithmetic.** Run `m7_one_tool.py`. Then ask the same question ten times *without* tools and without the "never calculate" rule, and count correct answers ($29.75). Finally, ask "What do Team and Business cost per user per month on annual billing?" with the tool, and check whether the model issues two calls in one turn (parallel calls) or two turns.

**Exercise 7.2 (core, 45 min): evaluate the support agent.** Write at least eight tasks for `run_agent` with checkable outcomes, for example: a refund request should create exactly one `billing` ticket; a simple policy question should create *no* ticket and cite a help-centre id; the Orion upgrade question should mention 416.50; an unknown workspace should lead to asking the user to check the name, with no ticket. Grade **outcomes** (the contents of `CREATED_TICKETS`, the final answer) separately from the **transcript** (number of steps, tool errors, unnecessary calls). Use `evalkit.py` from Module 4 and report task success, mean steps and tool-error rate.

**Exercise 7.3 (core, 30 min): do descriptions matter?** Replace every tool description with a single vague word ("Search.", "Price.", "Workspace.", "Ticket.") and parameter descriptions with nothing. Re-run your Exercise 7.2 evaluation and compare task success, wrong-tool calls and invalid-argument errors.

**Exercise 7.4 (core, 30 min): failure injection.** Make `get_workspace` raise `TimeoutError` on 30% of calls and `search_help_center` occasionally return an empty list. Observe the agent's behaviour in transcripts. Then (a) add an automatic retry with exponential backoff for *transient* errors only, inside the tool wrapper, and (b) make `create_ticket` idempotent so that a retried or repeated call never opens two tickets for the same request. Re-run the evaluation.

**Exercise 7.5 (stretch, 45 min): MCP.** Run `mcp_helpcenter.py` under the MCP Inspector and call the tool by hand. Add a second tool, `helpcenter_list_articles`, that returns article names and titles only. If you have an MCP-capable host (a desktop assistant, coding agent or IDE), register the server and ask it a help-centre question; read how the host displays the tool call. Explain in three sentences how the host turned your Python function into something the model could call.

## Interview corner (Module 7)

**Q: Walk me through how function calling works.** Model answer: The application sends the conversation plus tool definitions, each a name, description and JSON Schema for the arguments. The model may respond with one or more tool calls containing a name and a JSON string of arguments. The application validates the arguments, checks permissions, executes the function, and appends two things: the assistant message with the tool calls, then a tool message per call with the result and the call id. It calls the model again, which either requests more tools or answers. The model never executes anything; the application decides what actually runs, which is where validation and safety controls live.

**Q: How do you stop an agent from looping forever or running up costs?** Model answer: Hard limits in the loop: maximum steps, maximum tokens or spend per task, and a wall-clock timeout. Detection of repeated identical calls. Tool results that are bounded in size and errors that tell the model how to recover, so it isn't stuck retrying blindly. Then monitoring: track steps, tokens and stop reasons per task in production, and alert on outliers. And evaluation: transcript-level metrics like mean steps and redundant calls, so regressions show up before release.

**Q: How do you design tools for an agent?** Model answer: Around tasks rather than API endpoints, few and clearly distinct, with descriptions written like documentation for a new colleague, including when not to use the tool. Typed, constrained parameters such as enums and validation, so mistakes are hard. Returns that are concise and human-meaningful, with pagination or truncation so they can't flood the context, and error messages that say how to fix the call. Computation that code can do goes into the tool. Read-only and side-effecting tools are separated, writes are idempotent, and risky actions need confirmation. Then I evaluate tool use: success, wrong-tool calls, argument errors and tokens.

**Q: When would you not use an agent?** Model answer: When the steps are known in advance. A fixed workflow such as a chain, router or RAG pipeline is cheaper, faster, more predictable and easier to test. I'd also hesitate when actions are high-risk and irreversible without strong guardrails, or when latency and cost need to be tightly bounded. Agents earn their cost on open-ended tasks where the number and order of steps depend on what's discovered along the way.

**Q: What is MCP and why does it matter?** Model answer: An open protocol, now governed by the Linux Foundation's Agentic AI Foundation, that standardises how AI applications discover and call external tools, read resources and use prompt templates. A service implemented once as an MCP server works in any MCP host, which replaces N-by-M custom integrations. The host converts the server's tools into the model's function-calling format, so it complements function calling rather than replacing it. The main concerns are security: servers run code with your permissions, and their descriptions and results are untrusted text that can carry prompt injection, so you vet and pin servers, apply least privilege and require confirmation for destructive tools.

## Solutions (Module 7)

**Check your understanding.**

1. Your code. The model only requests calls, so every safety control (validation, permissions, confirmation, sandboxing) can sit between the request and the execution.
2. The assistant message containing the `tool_calls` first, then one `tool` message per call with the matching `tool_call_id`, then the next model call. Wrong order or missing results makes the server reject the conversation or confuses the model.
3. The model generates arguments as text; they can be malformed, out of range or outside the enum, especially without strict constrained decoding.
4. Done (no tool calls): normal completion. Repeated identical call: stuck loops. Maximum steps: runaway cost and latency.
5. The model can read an error and correct itself (fix arguments, try another tool, ask the user); an exception would end the run with nothing useful.
6. Tool definitions sit near the front of the context, so changing them invalidates the prefix cache and can confuse the model about tools referenced earlier.
7. For example: task-shaped tools (`get_plan_price` with seats); namespacing (`helpcenter_search`); concise, meaningful returns (plan names, not UUIDs); actionable errors ("ask the user to check the name"); poka-yoke arguments (enums, `seats >= 1`); separating reads from writes.
8. Workflow: predefined code paths orchestrate LLM calls and tools. Agent: the LLM directs its own process and tool use. Triage should be a workflow because its steps are fixed and its output feeds code.
9. To remove arithmetic from the model, which small models get wrong, and to finish the task in one call.
10. Host: the application running the model. Client: its connection to one server. Server: exposes capabilities. Primitives: tools, resources, prompts. Transports: stdio and Streamable HTTP.
11. It made the protocol stateless, removing the initialisation handshake and protocol-level sessions so that remote servers can scale like ordinary HTTP services.
12. Any two of: servers run code with your permissions; poisoned tool descriptions; descriptions changed after approval; injected instructions in tool results; over-broad credentials or data access.

**Exercise 7.1.** Without a tool, small models get $29.75 right only some of the time; typical mistakes are applying the discount wrongly, giving the yearly total instead of the monthly price, or rounding oddly. With the tool, the answer is right whenever the call is made with the right arguments. For the two-plan question, `qwen3:8b` often emits two tool calls in a single turn, which your loop must handle; some models make them in sequence instead. Both are valid, which is why code must never assume exactly one call.

**Exercise 7.2.**

```python
# m7_eval.py
from evalkit import run_eval, summarize
from agent import run_agent
from m7_support_agent import SYSTEM, TOOLS, CREATED_TICKETS

CASES = [
    {"id": "t1", "input": "I was charged twice for the same invoice 10 days ago and the duplicate "
     "still hasn't come back.", "expect_ticket": "billing", "must_contain": []},
    {"id": "t2", "input": "What does error EXP-207 mean?", "expect_ticket": None,
     "must_contain": ["15 minutes"]},
    {"id": "t3", "input": "Our workspace Orion keeps hitting API rate limits. What is our limit, and "
     "what would Business cost per month for all our seats if we pay annually?",
     "expect_ticket": None, "must_contain": ["600", "416.5"]},
    {"id": "t4", "input": "What plan is workspace Andromeda on?", "expect_ticket": None,
     "must_contain": []},
    {"id": "t5", "input": "Do you support SAML single sign-on?", "expect_ticket": None,
     "must_contain": []},
    {"id": "t6", "input": "Please add dark mode to the mobile app.", "expect_ticket": "feature_request",
     "must_contain": []},
    {"id": "t7", "input": "What does Team cost per month for 20 users on monthly billing?",
     "expect_ticket": None, "must_contain": ["400"]},
    {"id": "t8", "input": "Our only admin lost her 2FA phone, has no recovery codes, and nobody can "
     "sign in. Payroll runs tomorrow.", "expect_ticket": "account_access", "must_contain": []},
]

def agent_system(text):
    CREATED_TICKETS.clear()                 # isolate trials: no shared state (Module 4)
    res = run_agent(SYSTEM, text, TOOLS)
    tool_errors = sum(1 for m in res.transcript
                      if m["role"] == "tool" and m["content"].startswith("ERROR"))
    return {"answer": res.answer or "", "tickets": list(CREATED_TICKETS), "steps": res.steps,
            "stop": res.stop_reason, "tool_errors": tool_errors}

def ticket_outcome(case, out):           # OUTCOME: the state of the world
    if case["expect_ticket"] is None:
        return len(out["tickets"]) == 0
    return len(out["tickets"]) == 1 and out["tickets"][0]["category"] == case["expect_ticket"]

def answer_contains(case, out):
    if not case["must_contain"]:
        return None
    return all(w.lower() in out["answer"].lower() for w in case["must_contain"])

def finished(case, out):
    return out["stop"] == "done"

run = run_eval(agent_system, CASES, [ticket_outcome, answer_contains, finished], "agent-v1", workers=1)
summarize(run)
res = [r["output"] for r in run["results"]]
print("mean steps:", sum(o["steps"] for o in res) / len(res),
      "| tool errors:", sum(o["tool_errors"] for o in res))
```

Note `workers=1`: the fake ticket store is shared global state, so parallel trials would interfere, which is the isolation problem Anthropic's eval guide warns about. Typical results on small models: lookups and pricing succeed most of the time; ticket judgement is the weakest area, with tickets created for simple questions (t2, t5) or missing for the urgent lockout (t8). The `t4` case shows whether the agent turns a tool error into a sensible question to the user. Read every failing transcript and classify it (Module 4's error analysis) before changing anything.

**Exercise 7.3.** Expect task success to drop and both wrong-tool calls and invalid-argument errors to rise: the model searches the help centre for account data, skips the pricing tool and does arithmetic itself, or passes `"Orion workspace"` where a bare name was expected. The size of the drop is the value of good descriptions, measured.

**Exercise 7.4.**

```python
import random, time

TRANSIENT = (TimeoutError, ConnectionError)

def with_retries(fn, attempts=3, base_delay=0.5):
    """Retry only errors that may succeed on retry; let everything else surface."""
    def wrapped(**kwargs):
        for i in range(attempts):
            try:
                return fn(**kwargs)
            except TRANSIENT:
                if i == attempts - 1:
                    raise
                time.sleep(base_delay * 2 ** i + random.uniform(0, 0.1))   # backoff + jitter
    return wrapped

def create_ticket_idempotent(category: str, urgency: str, summary: str):
    for t in CREATED_TICKETS:            # one ticket per category per conversation
        if t["category"] == category:
            return {**t, "note": "A ticket for this already exists; reuse its id."}
    return create_ticket(category, urgency, summary)
```

Wrap the flaky tool with `with_retries(get_workspace)` when building the `Tool`. Retrying inside the tool hides transient failures from the model, saving steps and tokens; non-transient errors such as an unknown workspace still reach the model as observations it can act on. The idempotent ticket tool shows the principle on a small scale. In production the idempotency key comes from the harness (for example, the conversation or request id), never from the model, so that a retried request, a repeated model call or a restarted agent cannot create duplicates.

**Exercise 7.5.**

```python
@mcp.tool()
def helpcenter_list_articles() -> list[dict]:
    """List all help-centre articles with their titles. Use to discover what topics exist
    before searching or reading an article."""
    return [{"name": name, "title": text.splitlines()[0].lstrip("# ")} for name, text in DOCS.items()]
```

Explanation: the SDK reads each decorated function's name, type hints and docstring and produces an MCP tool definition with a JSON Schema for its parameters. The host's MCP client asks the server for its tool list and converts each definition into the function-calling format its model understands. When the model requests a call, the client sends it to the server over stdio, and the server's result returns to the model as an ordinary tool message.

## Sources and further reading (Module 7)

- ★ Anthropic, [Building effective agents](https://www.anthropic.com/engineering/building-effective-agents) (December 2024): workflows versus agents, the agent-computer interface, poka-yoke tools.
- ★ Anthropic, [Writing effective tools for agents — with agents](https://www.anthropic.com/research/writing-tools-for-agents) (September 2025).
- ★ Model Context Protocol, [specification and changelog for 2026-07-28](https://modelcontextprotocol.io/specification/2026-07-28/changelog) and the [MCP blog](https://blog.modelcontextprotocol.io/) for release and governance news.
- Yao et al., [ReAct: Synergizing Reasoning and Acting in Language Models](https://arxiv.org/abs/2210.03629) (2022).
- Ollama, [OpenAI compatibility](https://docs.ollama.com/api/openai-compatibility) (tool support and the unsupported `tool_choice` field) and vLLM's [OpenAI-compatible server](https://docs.vllm.ai/en/latest/serving/online_serving/openai_compatible_server/) (tool-call parsers).
- Anthropic, [Effective context engineering for AI agents](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents): minimal, unambiguous tool sets.

**Next:** [Module 8: Harness engineering](09-module-8-harness-engineering.md)
