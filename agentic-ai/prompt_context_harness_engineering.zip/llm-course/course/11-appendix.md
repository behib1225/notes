# Appendix: Responses API, testing LLM code, concurrency and serving (about 2 hours)

The modules taught the core ideas with the most portable API and single, synchronous calls. This appendix covers four things you will meet in a real codebase: OpenAI's newer Responses API, unit tests for code that calls models, many calls at once within a rate limit, and serving a component over HTTP. All code is in the companion repository with tests (`appendix_responses.py`, `appendix_async.py`, `appendix_serve.py`, `tests/test_appendix.py`).

## A.1 Chat Completions and the Responses API

This course uses the Chat Completions API (`/v1/chat/completions`) because almost every OpenAI-compatible server implements it, so the same code runs on Ollama, vLLM and hosted APIs. OpenAI's own guidance is different for new projects on its platform: its [migration guide](https://developers.openai.com/api/docs/guides/migrate-to-responses) says Chat Completions remains supported but recommends the Responses API (`/v1/responses`) for all new projects. You should be able to read and write both.

The differences that matter in practice:

| Topic | Chat Completions | Responses |
| --- | --- | --- |
| Input | `messages` list | `instructions` (system prompt) plus `input`, a string or a list of typed items |
| Output | `choices[0].message.content` | a list of output items; the SDK's `output_text` joins the text |
| Structured output | `response_format` | `text={"format": {...}}` |
| Conversation state | you resend the history | you can resend items, chain with `previous_response_id`, or use the Conversations API |
| Storage on OpenAI | stored by default for new accounts | stored by default; pass `store=False` to opt out |
| Multiple generations | `n` parameter | one generation per request |

Support outside OpenAI is uneven. Ollama has supported `/v1/responses` since v0.13.3, but [only the stateless form](https://docs.ollama.com/api/openai-compatibility): there is no `previous_response_id` or `conversation`, so you resend history yourself. vLLM also lists a Responses endpoint. One more reason to know both: OpenAI's guide notes that starting with GPT-5.4, Chat Completions does not support tool calling when reasoning is set to `none`.

The Module 3 triage call, written for the Responses API (the request shape was checked against the installed `openai` 3.55.1 SDK):

```python
# appendix_responses.py
from llm import client, MODEL
from prompts import TRIAGE_SYSTEM_JSON, sanitize
from schemas import Triage

def triage_responses(ticket_text: str) -> Triage:
    r = client.responses.create(
        model=MODEL,
        instructions=TRIAGE_SYSTEM_JSON,                    # the system prompt
        input=f"<ticket>\n{sanitize(ticket_text)}\n</ticket>",
        text={"format": {"type": "json_schema", "name": "Triage",   # not response_format
                         "schema": Triage.model_json_schema(), "strict": True}},
        store=False,                                        # hosted OpenAI stores responses by default
        max_output_tokens=1000,
    )
    return Triage.model_validate_json(r.output_text)      # output_text joins the text output items
```

Notice what did not change: the prompt, the schema and the validation. The engineering you learned is independent of the endpoint.

## A.2 Testing code that calls models

Two kinds of test answer two different questions. **Evaluations** (Module 4) ask how good the model's behaviour is; they need a real model, are slow and statistical, and run on a schedule or before releases. **Unit tests** ask whether *your code* does what you intended: builds the right request, parses and validates output, retries the right way, stops agent loops, enforces policies, computes statistics. They should be fast and deterministic and run on every commit, so they must not need a model.

The technique is a **scripted fake**: replace the client's `create` method with an object that returns pre-written responses in order and records every request. The companion repository's `tests/conftest.py` builds real `ChatCompletion` objects from the `openai` SDK's own types, so the code under test cannot tell the difference:

```python
# a unit test from the companion repository
def test_validation_error_retries_with_feedback(script):
    bad = GOOD.replace("account_access", "login")          # an invalid enum value
    fake = script(completion(bad), completion(GOOD))       # first answer bad, second good
    out = structured_call([{"role": "user", "content": "x"}], Triage)
    assert out.ok and out.attempts == 2
    retry_msgs = fake.calls[1]["messages"]
    assert retry_msgs[-2] == {"role": "assistant", "content": bad}   # model sees its own output
    assert "rejected" in retry_msgs[-1]["content"]
```

This exact test found a real bug in the first version of Module 3's retry loop, which showed the model `(empty)` instead of its rejected output. That is the argument for unit tests in one example: the bug was invisible in normal runs, because the retry usually still worked.

A second technique is **record and replay**: call the real model once, save the responses to files, and replay them in later test runs. HTTP recording libraries such as vcrpy do this generically. Recordings are realistic, but they go stale whenever you change a prompt, so treat them as fixtures you regenerate deliberately, and keep the scripted fakes for logic tests.

What unit tests cannot tell you is whether the model is good at the task. Keep both layers: fakes for the code, evaluations for the behaviour.

## A.3 Many calls at once, within a rate limit

Evaluation runs, batch triage and sub-agents all make many model calls. Running them one after another wastes time; firing them all at once triggers rate limits (HTTP 429) or overloads a local server. The standard pattern combines a **semaphore** that caps how many requests are in flight with **exponential backoff and jitter** for transient errors:

```python
# appendix_async.py
import asyncio, random
import openai
from openai import AsyncOpenAI
from llm import API_KEY, BASE_URL, MODEL, thinking
from prompts import triage_messages

# max_retries=0: this module does its own retries, so the SDK must not retry as well
# (two retry layers multiply: 2 SDK retries x 5 of ours = up to 18 requests per call).
aclient = AsyncOpenAI(base_url=BASE_URL, api_key=API_KEY, timeout=120, max_retries=0)
RETRYABLE = (openai.RateLimitError, openai.APIConnectionError, openai.InternalServerError)

async def call_with_backoff(make_call, retries: int = 5, base: float = 1.0, cap: float = 30.0):
    """Retry transient errors with exponential backoff and jitter."""
    for attempt in range(retries + 1):
        try:
            return await make_call()
        except RETRYABLE:
            if attempt == retries:
                raise
            delay = min(cap, base * 2 ** attempt) * random.uniform(0.5, 1.0)
            await asyncio.sleep(delay)

async def triage_all(texts: list[str], concurrency: int = 4) -> list[str]:
    """Triage many tickets; at most `concurrency` requests are in flight at once."""
    sem = asyncio.Semaphore(concurrency)
    async def one(text: str) -> str:
        async with sem:
            r = await call_with_backoff(lambda: aclient.chat.completions.create(
                model=MODEL, messages=triage_messages(text), temperature=0,
                max_tokens=200, **thinking(False)))
            return r.choices[0].message.content or ""
    return await asyncio.gather(*(one(t) for t in texts))
```

Three details matter. **Jitter** (the random factor) stops many clients that failed together from retrying together. **One retry layer**: the SDK retries by default, so disable it when you add your own, or keep the SDK's and add none. **Pick the concurrency from the server**: a local Ollama instance processes a small number of requests in parallel (configurable), so a high concurrency there only queues requests; hosted APIs publish per-minute limits. For work that can wait hours, hosted batch APIs are cheaper than any of this (Module 9.2).

## A.4 Serving a component over HTTP

A component becomes useful to other teams when it has an API. A minimal service for the Module 3 triage component, with FastAPI:

```python
# appendix_serve.py   (run: uvicorn appendix_serve:app --port 8080)
import openai
from fastapi import FastAPI
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field
from m3_triage import triage_robust

app = FastAPI(title="AcmeCloud triage")

class TriageRequest(BaseModel):
    text: str = Field(min_length=1, max_length=8000)   # bound the input: cost and abuse control

class TriageResponse(BaseModel):
    route: str
    category: str | None = None
    urgency: str | None = None
    summary: str | None = None

@app.post("/triage", response_model=TriageResponse)
async def triage_endpoint(req: TriageRequest) -> TriageResponse:
    try:
        # triage_robust uses the synchronous client; run it in a worker thread so the
        # event loop keeps serving other requests while this one waits for the model.
        result = await run_in_threadpool(triage_robust, req.text)
    except openai.APIError:
        return TriageResponse(route="default_queue")       # graceful degradation (Module 9.2)
    t = result.get("triage")
    if t is None:
        return TriageResponse(route=result["route"])        # validation failed: human review
    return TriageResponse(route=result["route"], category=t.category,
                          urgency=t.urgency, summary=t.summary)

@app.get("/healthz")
def healthz() -> dict:
    return {"ok": True}
```

The service applies ideas from earlier modules at the boundary: inputs are validated and size-limited, the response has a fixed schema, a model outage degrades to a default queue instead of an error, and a health endpoint lets a load balancer check it. Before exposing it beyond your machine, add authentication, per-client rate limits, request logging without personal data, and tracing (Module 8.5). For chat-style features, stream tokens to the client (FastAPI's `StreamingResponse` over the SDK's `stream=True`) so the user sees the first words quickly.

## Exercises (Appendix)

**Exercise A.1 (core, 30 min).** Run `triage_responses` against your server. If you use Ollama, confirm what happens when you pass `previous_response_id`, and explain the result using the compatibility notes above.

**Exercise A.2 (core, 30 min).** Using the `script` fixture from the companion repository, write a unit test proving that `ContextManager.maybe_compact` keeps the full history when the summariser fails three times.

**Exercise A.3 (stretch, 30 min).** HTTP 429 responses often carry a `Retry-After` header. Change `call_with_backoff` to wait for that many seconds when the header is present, and fall back to exponential backoff otherwise. Add a unit test.

## Solutions (Appendix)

**Exercise A.1.** Ollama's compatibility page lists `previous_response_id` and `conversation` as unsupported, because its Responses endpoint is stateless. Depending on the version, the parameter is rejected or ignored; either way the server keeps no conversation, so multi-turn use means resending earlier items yourself, as with Chat Completions.

**Exercise A.2.**

```python
def test_failed_compaction_keeps_full_history(script):
    script(*[completion("not json")] * 3)                 # the summariser fails every attempt
    cm = ContextManager("S", budget=10, keep_recent=2)
    for i in range(4):
        cm.add("user", "u" * 100); cm.add("assistant", "a" * 100)
    assert not cm.maybe_compact()
    assert len(cm.turns) == 8 and cm.summary is None
```

**Exercise A.3.**

```python
async def call_with_backoff(make_call, retries: int = 5, base: float = 1.0, cap: float = 30.0):
    for attempt in range(retries + 1):
        try:
            return await make_call()
        except RETRYABLE as e:
            if attempt == retries:
                raise
            delay = min(cap, base * 2 ** attempt) * random.uniform(0.5, 1.0)
            response = getattr(e, "response", None)
            header = response.headers.get("retry-after") if response is not None else None
            if header and header.isdigit():
                delay = min(cap, float(header))
            await asyncio.sleep(delay)
```

Test it by raising an `openai.RateLimitError` whose `httpx.Response` has `headers={"retry-after": "2"}` and asserting that the stubbed `asyncio.sleep` received 2. `Retry-After` can also be an HTTP date; this version handles only the seconds form, which is what rate limiters usually send.

## Sources (Appendix)

- OpenAI, [Migrate to the Responses API](https://developers.openai.com/api/docs/guides/migrate-to-responses) and [Responses vs. Chat Completions](https://developers.openai.com/api/docs/guides/responses-vs-chat-completions).
- Ollama, [OpenAI compatibility](https://docs.ollama.com/api/openai-compatibility): supported endpoints and the stateless Responses API.
- The companion repository's `tests/` directory: scripted fakes for every module.

**Next:** [Changelog](12-changelog.md)
