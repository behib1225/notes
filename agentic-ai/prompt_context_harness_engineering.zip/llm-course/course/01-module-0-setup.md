# Module 0: Setup (about 2 hours)

By the end of this module you will have a model running on your own machine and a small Python module, `llm.py`, that every later module imports. Switching from a local model to a hosted one will be a one-line change in a `.env` file.

**Learning objectives.** After this module you can:

- Explain what an "OpenAI-compatible API" is and why it makes your code portable.
- Install and run a local model with Ollama (laptop) or vLLM (GPU server).
- Call the model from Python, stream a response, and read token usage.
- Diagnose the five most common setup failures.

## 0.1 Why an OpenAI-compatible API?

An LLM server is just an HTTP service. OpenAI's Chat Completions endpoint (`POST /v1/chat/completions`) became the de facto standard request shape, so most inference servers implement it. [Ollama documents](https://docs.ollama.com/api/openai-compatibility) compatibility with a subset of the OpenAI API at `http://localhost:11434/v1/`, and [vLLM provides](https://docs.vllm.ai/en/latest/serving/online_serving/openai_compatible_server/) an HTTP server that implements OpenAI's Completions and Chat APIs. The official `openai` Python SDK takes a `base_url` argument, so the same client talks to any of them.

Two cautions you should remember from day one. First, "compatible" means *a subset*: for example, Ollama's chat endpoint does not support `tool_choice`, `logit_bias`, `n` or `logprobs` (as of its current docs). Second, the model behind the API changes behaviour far more than the API does. Portable code is not the same as portable quality, which is why Module 4 teaches evaluation.

```mermaid
flowchart LR
  code["Your Python code<br/>llm.py and scripts"] --> sdk["openai Python SDK<br/>base_url, api_key, model"]
  sdk -->|"HTTP POST /v1/chat/completions"| ollama["Ollama<br/>localhost:11434/v1 · laptop"]
  sdk --> vllm["vLLM<br/>localhost:8000/v1 · GPU server"]
  sdk --> hosted["Hosted OpenAI<br/>api.openai.com/v1 · paid"]
```

*Figure: One client, three backends. Set `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL` (and `THINKING_MODE`) in `.env` to pick the backend.*

Your code only ever talks to the SDK; which server answers is decided by configuration, not code.

## 0.2 Pick a path and a model

Use **Path A (Ollama)** if you are on a laptop or desktop (macOS, Windows or Linux), with or without a GPU. Use **Path B (vLLM)** if you have a Linux machine with an NVIDIA GPU, or cloud GPU access; vLLM is what many companies use to serve open models in production, so it is worth recognising.

Model choice depends on memory. The course default is `qwen3:8b`: it supports tool calling and an optional "thinking" mode, both of which later modules need. Sizes below are approximate Ollama download sizes; actual memory use is higher because the context window needs memory too.

| Your machine | Ollama model to start with | Approx. download | Why |
| --- | --- | --- | --- |
| 8 GB RAM, no GPU | `qwen3:4b` | 2.5 GB | Smallest model that still handles tools reasonably |
| 16 GB RAM or 8–12 GB GPU | `qwen3:8b` (course default) | 5.2 GB | Good balance of quality and speed; tools and thinking |
| 32 GB RAM or 16–24 GB GPU | `gpt-oss:20b` | 14 GB | OpenAI's open-weight reasoning model; stronger on multi-step tasks |

Newer families such as Gemma 4 (`gemma4:e4b`, `gemma4:26b`) and Qwen 3.5 are also in the [Ollama library](https://ollama.com/library) with tool support. Because your code reads the model name from a setting, you can try any of them later without changing code. Run `ollama show <model>` to see a model's capabilities (tools, thinking, vision) and its maximum context length.

## 0.3 Path A: Ollama

1. Install Ollama. On macOS and Windows, download the installer from [ollama.com/download](https://ollama.com/download). On Linux, run `curl -fsSL https://ollama.com/install.sh | sh`.
2. Make sure the server is running. The desktop app starts it automatically; on Linux or in a terminal you can run `ollama serve`.
3. Pull the model: `ollama pull qwen3:8b`.
4. Smoke-test from the terminal: `ollama run qwen3:8b "Say hello in five words."`
5. Check where it is running: `ollama ps` shows the model, how much of it is on GPU versus CPU, and the allocated context length.
6. Raise the context length. Ollama [defaults to](https://docs.ollama.com/context-length) a 4k-token context on machines with less than 24 GiB of VRAM, and recommends at least 64,000 tokens for agents and coding tools. 4k is too small for Modules 5–8. Set it in the Ollama app's settings slider, or start the server with `OLLAMA_CONTEXT_LENGTH=16384 ollama serve`. Use 16k on a laptop; go higher only if `ollama ps` still shows 100% GPU and the machine stays responsive.

Step 6 is the single most common source of confusing bugs in local LLM work: if the conversation exceeds the configured context, older content is cut off and the model appears to "forget" instructions. You will measure this yourself in Module 1.

## 0.4 Path B: vLLM (GPU server)

1. On a Linux machine with an NVIDIA GPU, create a separate virtual environment and run `pip install vllm`. vLLM pins specific PyTorch and CUDA versions, so keep it out of your course environment.
2. Start the server with tool calling and reasoning parsing enabled. These flags come from the [Qwen deployment guide](https://qwen.readthedocs.io/en/latest/deployment/vllm.html) and the [vLLM recipe for Qwen3-8B](https://recipes.vllm.ai/Qwen/Qwen3-8B):

```bash
vllm serve Qwen/Qwen3-8B \
  --max-model-len 32768 \
  --enable-auto-tool-choice \
  --tool-call-parser hermes \
  --reasoning-parser qwen3 \
  --api-key local-dev-key
```

3. The server listens on `http://localhost:8000/v1`. The model name you pass in requests is the Hugging Face id, `Qwen/Qwen3-8B`.

Three vLLM facts worth knowing for interviews. Parameters that are not in the OpenAI API, such as `top_k`, go in the SDK's `extra_body` argument. By default the server applies the sampling defaults from the model repository's `generation_config.json`, so your "default temperature" may not be what you think. And `--api-key` only protects some endpoints, so [vLLM's docs](https://docs.vllm.ai/en/latest/serving/online_serving/openai_compatible_server/) warn against relying on it alone to secure a server; put a reverse proxy in front of anything exposed to a network.

## 0.5 The Python project

Create the course repository and environment (Python 3.11 or newer, which the companion repository's pinned dependencies require):

```bash
mkdir llm-course && cd llm-course
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install openai python-dotenv
```

**Companion repository.** The tested reference code for every module is in the `llm-course` repository, distributed with this course as `llm-course.zip`; the course text is also in it, as Markdown files in its `course/` folder. The repository's code includes worked solutions to several exercises (its README lists which), so do those exercises before you open the matching files. Install it with `pip install -r requirements.txt`, which pins the versions it was tested with in November 2026 (including `openai` 3.55.1, `pydantic` 2.14.4 and `mcp` 2.3.0), and run `python -m pytest -q` to check your setup without a model. **Windows:** Ollama has a native Windows installer, so Path A works as written. vLLM does not run natively on Windows; use it inside WSL2 with an NVIDIA GPU, or stay on Path A.

Create a `.env` file. Never commit it; add `.env` to `.gitignore` now, because in a job this file will hold real API keys.

```bash
# .env  (Path A: Ollama)
LLM_BASE_URL=http://localhost:11434/v1
LLM_API_KEY=ollama
LLM_MODEL=qwen3:8b
THINKING_MODE=ollama          # how to switch thinking on/off; see Module 1.6

# Path B: vLLM
# LLM_BASE_URL=http://localhost:8000/v1
# LLM_API_KEY=local-dev-key
# LLM_MODEL=Qwen/Qwen3-8B
# THINKING_MODE=vllm-qwen

# Hosted OpenAI (optional, paid)
# LLM_BASE_URL=https://api.openai.com/v1
# LLM_API_KEY=sk-...
# LLM_MODEL=<a current model name from OpenAI's docs>
# THINKING_MODE=openai-reasoning   # or: none, for models without reasoning
```

Now the shared module. Read the comments; each one anticipates a problem you would otherwise hit later.

```python
# llm.py: the one place that knows how to reach a model.
import os
import re

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

BASE_URL = os.getenv("LLM_BASE_URL", "http://localhost:11434/v1")
# Local servers ignore the key, but the SDK refuses to start without one.
API_KEY = os.getenv("LLM_API_KEY", "ollama")
MODEL = os.getenv("LLM_MODEL", "qwen3:8b")

# timeout: local models can be slow on CPU; fail loudly instead of hanging forever.
# max_retries: the SDK retries connection errors and 429/5xx responses for you.
client = OpenAI(base_url=BASE_URL, api_key=API_KEY, timeout=120, max_retries=2)

_THINK = re.compile(r"<think>(.*?)</think>", re.DOTALL)


def split_reasoning(message):
    """Return (reasoning, answer) from a chat message.

    Servers expose a reasoning model's thinking differently: as a separate
    field (named `reasoning` or `reasoning_content` depending on server and
    version) or inline as <think>...</think> inside `content`. This helper
    handles all three so the rest of the course does not have to care.
    """
    content = message.content or ""
    reasoning = None
    for name in ("reasoning", "reasoning_content"):
        reasoning = reasoning or getattr(message, name, None)
    extra = getattr(message, "model_extra", None) or {}
    reasoning = reasoning or extra.get("reasoning") or extra.get("reasoning_content")
    match = _THINK.search(content)
    if match:
        reasoning = reasoning or match.group(1).strip()
        content = _THINK.sub("", content)
    return reasoning, content.strip()


def ask(prompt, system=None, **kwargs):
    """One-shot helper: send a prompt, return the answer text."""
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    response = client.chat.completions.create(model=MODEL, messages=messages, **kwargs)
    _, answer = split_reasoning(response.choices[0].message)
    return answer
```

## 0.6 Your first calls

Create `m0_first_call.py` and run it. It prints the answer, any reasoning, the token counts and the wall-clock time.

```python
import time
from llm import client, MODEL, split_reasoning

start = time.perf_counter()
response = client.chat.completions.create(
    model=MODEL,
    messages=[
        {"role": "system", "content": "You are a concise teaching assistant."},
        {"role": "user", "content": "In two sentences, what is a context window?"},
    ],
    temperature=0.2,
    max_tokens=1024,
)
elapsed = time.perf_counter() - start

reasoning, answer = split_reasoning(response.choices[0].message)
print("ANSWER:", answer)
print("REASONING:", (reasoning or "(none)")[:300])
print("FINISH REASON:", response.choices[0].finish_reason)
print("USAGE:", response.usage)
print(f"TIME: {elapsed:.1f}s")
```

Three fields deserve attention every time you make a call. `finish_reason` is `"stop"` when the model ended naturally and `"length"` when it hit `max_tokens`; a `"length"` finish means a truncated answer, and for a reasoning model it can mean an *empty* answer because the budget was spent thinking. `usage` reports `prompt_tokens` (what you sent) and `completion_tokens` (what came back), which is how you will reason about cost and latency. And time: measure it from the start, because users notice latency before they notice quality.

Now streaming, which is how every chat product shows text as it is generated:

```python
# m0_stream.py
from llm import client, MODEL

stream = client.chat.completions.create(
    model=MODEL,
    messages=[{"role": "user", "content": "Write a haiku about debugging."}],
    stream=True,
)
for chunk in stream:
    if chunk.choices and chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="", flush=True)
print()
```

Finally, ask the server which models it has: `for m in client.models.list(): print(m.id)`.

**Controlling "thinking".** `qwen3:8b` and `gpt-oss:20b` are reasoning models: they can generate hidden reasoning before the answer. Ollama maps the standard `reasoning_effort` parameter onto each model; [per its docs](https://docs.ollama.com/api/openai-compatibility), for models that only support on/off thinking, `"none"` turns thinking off. For GPT-OSS, Ollama keeps its own conversion: `"none"` requests no thinking output, and other effort names are mapped to the levels GPT-OSS supports. On vLLM with Qwen3, you turn thinking off with `extra_body={"chat_template_kwargs": {"enable_thinking": False}}`. You will compare both modes in Module 1.

## 0.7 Troubleshooting

| Symptom | Likely cause | Fix |
| --- | --- | --- |
| `APIConnectionError` / connection refused | Server not running, or wrong port | Start the Ollama app or `ollama serve`; check `LLM_BASE_URL` (11434 for Ollama, 8000 for vLLM) |
| 404 "model not found" | Model not pulled, or name typo | `ollama list`, then `ollama pull <name>`; on vLLM the name is the Hugging Face id |
| Empty `content`, `finish_reason` is `"length"` | Reasoning model spent `max_tokens` on thinking | Raise `max_tokens`, or turn thinking off |
| Very slow (more than 30 s for a short answer) | Model running on CPU or partly offloaded | `ollama ps`; choose a smaller model or shorter context |
| Model "forgets" earlier instructions in long chats | Context length too small (4k default) | Raise context length (step 6 of Path A) |
| A request parameter seems ignored | Not supported by that server | Check the server's compatibility list (e.g. Ollama ignores `tool_choice`) |

## Check your understanding (Module 0)

1. Why does the `openai` SDK need an `api_key` when talking to Ollama, and what does Ollama do with it?
2. Name two things that "OpenAI-compatible" does *not* guarantee.
3. A response comes back with an empty answer and `finish_reason == "length"`. Give the two most likely fixes.
4. Why does `llm.py` read the base URL and model from environment variables instead of hard-coding them?

## Exercises (Module 0)

**Exercise 0.1 (warm-up, 15 min).** Write `m0_compare.py` that sends the same question to the model three times with `temperature=0` and three times with `temperature=1.0`, and prints each answer on one line. Record in your lab notebook what you observe.

**Exercise 0.2 (core, 30 min).** Write a function `time_to_first_token(prompt)` that streams a response and returns two numbers: seconds until the first content token arrives, and total seconds. Run it on a one-sentence prompt and on a prompt that includes 2,000 words of pasted text. Explain the difference.

## Solutions (Module 0)

**Check your understanding.** (1) The SDK validates that a key is present before sending any request; Ollama's docs say the value is required by the client but ignored by the server. (2) It does not guarantee that every parameter is supported (Ollama ignores `tool_choice`, `n`, `logprobs`), and it does not guarantee equal quality, behaviour or default sampling settings across models and servers. (3) Increase `max_tokens`, or disable or reduce thinking (`reasoning_effort="none"` on Ollama for on/off models; `enable_thinking: False` on vLLM with Qwen3). (4) Configuration should live outside code so that the same code runs against local, staging and production backends, and so that secrets never get committed. This is the [twelve-factor](https://12factor.net/config) "config in the environment" principle you will meet in any backend job.

**Exercise 0.1.** At `temperature=0` the answers will be identical or nearly so; at 1.0 wording varies and occasionally the content does too. "Nearly" matters: even at temperature 0, batching and floating-point effects on GPUs can make outputs differ slightly, so never write tests that assume byte-identical output. You will learn how temperature works in Module 1.

```python
from llm import ask

Q = "Suggest a name for a Python library that parses invoices."
for t in (0, 1.0):
    for i in range(3):
        print(f"T={t} #{i+1}:", ask(Q, temperature=t, max_tokens=512, reasoning_effort="none"))
```

(If your server rejects `reasoning_effort`, remove it; vLLM users use the `extra_body` switch from section 0.6.)

**Exercise 0.2.**

```python
import time
from llm import client, MODEL

def time_to_first_token(prompt):
    start = time.perf_counter()
    first = None
    stream = client.chat.completions.create(
        model=MODEL, messages=[{"role": "user", "content": prompt}], stream=True,
    )
    for chunk in stream:
        if first is None and chunk.choices and chunk.choices[0].delta.content:
            first = time.perf_counter() - start
    return first, time.perf_counter() - start

print(time_to_first_token("Say hi."))
print(time_to_first_token("Summarise this in one line:\n" + "lorem ipsum " * 1500))
```

The long prompt has a much larger time to first token. Before generating anything, the server must process every input token (the "prefill" phase); only then does it produce output tokens one at a time (the "decode" phase). Long inputs make the wait before the first word longer; long outputs make the total time longer. This distinction comes up in system-design interviews, and Module 1 explains it properly. Note that with a thinking model, time to first *content* token also includes the thinking time.

**Next:** [Module 1: The LLM as an engineering component](02-module-1-llm-as-component.md)
