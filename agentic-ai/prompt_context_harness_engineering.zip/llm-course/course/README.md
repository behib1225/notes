# Course text: Prompt, Context & Harness Engineering

The full text of the self-study course, one Markdown file per part, generated from the course
document's exports by `tools/build_course_md.py`. The code shown in each module is the code as
taught; the tested, consolidated versions (including worked solutions to several exercises) are in
the repository root, described in `../README.md`.

| File | Part |
| --- | --- |
| [00-orientation.md](00-orientation.md) | Orientation |
| [01-module-0-setup.md](01-module-0-setup.md) | Module 0: Setup |
| [02-module-1-llm-as-component.md](02-module-1-llm-as-component.md) | Module 1: The LLM as an engineering component |
| [03-module-2-prompt-engineering.md](03-module-2-prompt-engineering.md) | Module 2: Prompt engineering |
| [04-module-3-structured-outputs.md](04-module-3-structured-outputs.md) | Module 3: Structured outputs |
| [05-module-4-evaluation.md](05-module-4-evaluation.md) | Module 4: Evaluating LLM systems |
| [06-module-5-retrieval.md](06-module-5-retrieval.md) | Module 5: Context engineering I, retrieval |
| [07-module-6-memory.md](07-module-6-memory.md) | Module 6: Context engineering II, memory |
| [08-module-7-tools-and-agents.md](08-module-7-tools-and-agents.md) | Module 7: Tools and the agent loop |
| [09-module-8-harness-engineering.md](09-module-8-harness-engineering.md) | Module 8: Harness engineering |
| [10-module-9-production-security-capstone.md](10-module-9-production-security-capstone.md) | Module 9: Production, security and capstone |
| [11-appendix.md](11-appendix.md) | Appendix: Responses API, testing, concurrency, serving |
| [12-changelog.md](12-changelog.md) | Changelog |

## Notes on the Markdown

- **Diagrams** are Mermaid code blocks, redrawn from the course document's diagrams and checked with
  the Mermaid 11 parser (syntax only; layout was not inspected visually). GitHub and GitLab render
  Mermaid natively. VS Code's built-in Markdown preview does not; install a Mermaid extension to see
  them there. Elsewhere they show as readable text.
- **Formulas** are LaTeX in `$$ … $$` display-math blocks, which GitHub and VS Code's preview render.
- **Time estimates** for each module are in its title and in the course map in `00-orientation.md`.
