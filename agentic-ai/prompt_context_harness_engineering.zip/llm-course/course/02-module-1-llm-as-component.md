# Module 1: The LLM as an engineering component (about 4 hours)

An LLM is a function that takes a sequence of tokens and returns a probability for every possible next token; everything else, including "chat", is engineering built on top of that. Engineers who internalise this one sentence debug faster, estimate costs correctly, and give better interview answers than engineers who think of the model as a person.

**Learning objectives.** After this module you can:

- Explain tokens, and count them for a given model.
- Describe how a list of chat messages becomes one token sequence through a chat template.
- Explain why the API is stateless and what a context window limits.
- Choose sampling settings (temperature, top-p, max tokens, stop) for a task and explain why.
- Decide when a reasoning ("thinking") model is worth its extra latency and cost.
- Explain why long contexts degrade quality, and how input length drives latency and cost.

## 1.1 The core loop: predict, sample, append, repeat

A language model is trained to predict the next token in text. To generate, the server runs a loop: feed in the tokens so far, get a probability distribution over the vocabulary (typically 100,000 to 250,000 possible tokens), pick one token from it, append it, and repeat until the model emits an end-of-turn token or a limit is reached. This is called *autoregressive* generation.

Three consequences follow, and you will meet each of them again. The model has no memory outside the tokens you give it. Its output is a sample from a distribution, so variation is normal, not a bug. And each output token costs one full pass of the model, which is why long answers are slow.

```mermaid
flowchart LR
  A["Messages<br/>system, user, assistant"] --> B["Chat template<br/>adds special tokens"] --> C["Token ids<br/>the whole context"] --> D["Model<br/>one forward pass"]
  D --> E["Probabilities<br/>for every next token"] --> F["Sample one token<br/>temperature, top-p"] --> G{"Stop?<br/>end token or max_tokens"}
  G -->|yes| H["Answer text<br/>tokens turned to text"]
  G -->|"no: append the token to the context and run the model again"| D
```

*Figure: Generation is a loop: one model pass per output token.*

Every output token goes once around the loop, which is why output length dominates latency and why the model's own words become part of its input.

## 1.2 Tokens

Models do not read characters or words; they read **tokens**, chunks of text from a fixed vocabulary learned from data. Common English words are often a single token; rare words, code identifiers, numbers and many non-English scripts split into several. Each model family has its own tokenizer, so the same text has a different token count on Qwen, Llama, Gemma and OpenAI models. For OpenAI's English tokenizers a token averages roughly four characters, but treat any such ratio as a rough estimate and measure when it matters.

Tokens matter to you for four practical reasons: context limits are counted in tokens, prices are per token, latency grows with tokens, and some failure modes come from tokenization (models are poor at counting letters inside words because they never see the letters).

You can count tokens for the course model without downloading the model itself; only the small tokenizer files are fetched.

```python
# m1_tokens.py   (pip install transformers)
from transformers import AutoTokenizer

tok = AutoTokenizer.from_pretrained("Qwen/Qwen3-8B")  # tokenizer files only, a few MB

samples = {
    "english": "The invoice total is due within thirty days.",
    "code": "def parse_invoice(path: str) -> dict[str, float]:",
    "number": "Order 4815162342 shipped on 2026-11-19.",
    "german": "Die Rechnungssumme ist innerhalb von dreißig Tagen fällig.",
}
for name, text in samples.items():
    ids = tok.encode(text)
    pieces = tok.convert_ids_to_tokens(ids)
    print(f"{name:8} {len(text):3} chars -> {len(ids):3} tokens  {pieces[:10]}")
```

For a running server, the authoritative count is `response.usage.prompt_tokens`, because it includes everything the server added (chat template tokens, tool definitions). Exercise 1.1 asks you to compare the two numbers.

## 1.3 Chat templates and roles

The API accepts a list of messages with roles: `system` (instructions from the developer), `user` (the end user's input), `assistant` (the model's previous replies) and `tool` (results of tool calls, Module 7). But the model only ever sees *one flat token sequence*. The server converts the message list into that sequence using the model's **chat template**, a small Jinja program shipped with the model that inserts special marker tokens between messages.

```python
messages = [
    {"role": "system", "content": "You are terse."},
    {"role": "user", "content": "Hi!"},
]
print(tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True))
```

For Qwen3 you will see output like this, where the final line is the "generation prompt" that tells the model it is now the assistant's turn:

```
<|im_start|>system
You are terse.<|im_end|>
<|im_start|>user
Hi!<|im_end|>
<|im_start|>assistant
```

Three lessons hide in that output. First, the template is part of the model: the [Hugging Face documentation](https://huggingface.co/docs/transformers/chat_templating) stresses that with the wrong control tokens a model performs drastically worse, which is why servers like Ollama and vLLM apply each model's own template for you. Second, roles are a *training convention*, not a security boundary: the model learned to give the system message more weight, but it is still just text in the same sequence. That is the root cause of prompt injection, covered in Module 9. Third, when you see a "thinking" toggle such as Qwen's `enable_thinking`, it is a variable passed into this template.

## 1.4 Statelessness and the context window

The Chat Completions API is **stateless**: the server keeps nothing between requests. Your chat application only appeared to remember because it re-sent the entire history on every turn. Every agent, assistant and RAG system you will build works the same way, which is why "what do we send this time?" (context engineering) is the central design question.

The **context window** is the maximum number of tokens the model can handle in one request, counting both the input and the generated output. A model's *native* window (for example 32k or 128k tokens) is an upper bound; the *configured* window on your server can be much smaller, as you saw with Ollama's 4k default. When a request exceeds the configured window, servers behave differently: some reject it with an error, others silently cut the oldest tokens. Silent truncation is dangerous because nothing crashes; the model simply stops following instructions it can no longer see. Find out which behaviour your server has (Exercise 1.2) rather than assuming.

Statelessness also explains a cost surprise that catches many teams: in a conversation, turn *n* re-sends all previous turns, so the total number of input tokens grows roughly with the square of the number of turns. Exercise 1.5 makes you compute it.

## 1.5 Sampling: how the next token is chosen

The model outputs a score (a *logit*) for each vocabulary token. The server turns scores into probabilities with a softmax, divided by the **temperature** T:

$$
p_i = \frac{\exp(z_i / T)}{\sum_j \exp(z_j / T)}
$$

Low T sharpens the distribution towards the most likely token; T near 0 approaches *greedy* decoding (always the top token). High T flattens it, so less likely tokens get picked more often. Two filters are usually applied too: **top-p** (nucleus sampling) keeps only the smallest set of tokens whose probabilities add up to p, and **top-k** keeps only the k most likely tokens. Then one token is drawn at random from what remains.

The other generation controls you will use daily:

| Parameter | What it does | Typical use |
| --- | --- | --- |
| `temperature` | Sharpens or flattens the distribution | 0–0.3 for extraction, classification, code; 0.7–1.0 for brainstorming and writing |
| `top_p` | Keeps the top tokens covering probability mass p | Usually leave at the default; change temperature *or* top-p, not both |
| `max_tokens` | Hard cap on generated tokens | Always set it; it bounds cost and latency. Leave room for thinking on reasoning models |
| `stop` | Strings that end generation early | Cut off after a delimiter in completion-style prompts |
| `seed` | Seeds the random sampler | Improves repeatability in tests; does not guarantee it |

Two facts that interviewers like to probe. First, temperature 0 does not guarantee identical outputs: GPU arithmetic, batching with other requests and server implementation details can change results slightly, so tests must tolerate variation. Second, model publishers often recommend specific settings, and they matter: Qwen's [deployment guide](https://qwen.readthedocs.io/en/latest/deployment/vllm.html) uses temperature 0.6, top-p 0.95 and top-k 20 for thinking mode, and some reasoning models ignore or reject sampling parameters entirely. Check the model card before tuning.

## 1.6 Reasoning ("thinking") models

A reasoning model is trained to generate a chain of intermediate reasoning tokens before its final answer. The thinking is billed and timed like any other output token, so it trades latency and cost for accuracy on multi-step problems (maths, planning, debugging, applying complex rules). OpenAI's [reasoning best practices](https://developers.openai.com/api/docs/guides/reasoning-best-practices) describe the two families as different tools rather than better and worse: reasoning models for planning, ambiguity and decisions over complex material; faster non-reasoning models for well-defined execution. Many production systems use both, a reasoning model to plan and a cheaper model to execute.

Prompting differs too. Reasoning models do best with a clear goal, constraints and success criteria, and they work out the steps themselves; telling them to "think step by step" adds little. Non-reasoning models benefit more from explicit steps and examples. Most open models now offer a switch or an effort level, so you can choose per request. Add this helper to `llm.py`; it hides the fact that each server spells the switch differently:

```python
# add to llm.py
THINKING_MODE = os.getenv("THINKING_MODE", "ollama")

def thinking(on: bool, mode: str | None = None) -> dict:
    """Request kwargs that switch thinking on or off. Each server spells this differently."""
    mode = mode or THINKING_MODE
    if mode == "ollama":              # Ollama's OpenAI-compatible API
        return {"reasoning_effort": "medium" if on else "none"}
    if mode == "vllm-qwen":           # vLLM serving Qwen3-style chat templates
        return {"extra_body": {"chat_template_kwargs": {"enable_thinking": on}}}
    if mode == "openai-reasoning":    # hosted OpenAI reasoning models: "low" is not "off"
        return {"reasoning_effort": "medium" if on else "low"}
    if mode == "none":                # models without a thinking switch
        return {}
    raise ValueError(f"unknown THINKING_MODE {mode!r}")

def merge_kwargs(*dicts: dict) -> dict:
    """Merge request kwargs, combining nested extra_body dicts instead of colliding."""
    out = {}
    for d in dicts:
        for k, v in d.items():
            out[k] = {**out[k], **v} if k == "extra_body" and k in out else v
    return out
```

The mode is an explicit setting rather than guessed from the URL, because a port number or host name says nothing reliable about which server, gateway or model is behind it. Two limits are worth knowing. Hosted non-reasoning models reject `reasoning_effort` with an error, so use `THINKING_MODE=none` for them. And not every reasoning model can switch thinking off in the same way: models are trained with different effort levels, and servers map effort values differently (Ollama's compatibility page, for example, documents its own conversion of effort values for GPT-OSS), so check both the server's and the model's documentation. `merge_kwargs` lets later code combine `thinking(...)` with its own `extra_body` without a "multiple values for keyword argument" error.

Usage: `client.chat.completions.create(model=MODEL, messages=msgs, **thinking(False))`. Hosted model names and the effort levels they accept change often, so check the provider's current model page before relying on a specific value.

## 1.7 Long context is not free context

A larger window lets you send more, but it does not mean the model uses all of it equally well. Two findings every LLM engineer should know:

- **Lost in the middle.** [Liu et al.](https://arxiv.org/abs/2307.03172) showed that models retrieve information best when it sits at the beginning or end of the input, and worse when it is buried in the middle.
- **Context rot.** Chroma's July 2025 [technical report](https://trychroma.com/research/context-rot) tested 18 models and found that performance grows increasingly unreliable as input length grows, even on simple tasks and well before the window is full. Distracting, similar-looking content made it worse.

The engineering conclusion is the founding idea of context engineering: treat context as a scarce budget. Send what is relevant, put critical instructions where they are seen best, and measure instead of assuming that "more context" helps. Modules 5 and 6 turn this into techniques.

## 1.8 Latency and cost

Serving a request has two phases. **Prefill** processes all input tokens in parallel and is relatively fast per token; its duration largely sets the *time to first token*. **Decode** then generates output tokens one at a time, each needing a full model pass, so output tokens are the main driver of total time. During prefill the server stores intermediate results for every token in a **KV cache**, and the cache's memory grows with context length, which is why raising the context window on a laptop can push a model off the GPU.

Hosted APIs price input and output tokens separately, and output tokens (including hidden reasoning tokens) usually cost several times more than input tokens:

$$
\text{cost} = N_{\text{in}} \cdot P_{\text{in}} + N_{\text{out}} \cdot P_{\text{out}}
$$

One optimisation has outsized design consequences: **prefix caching**. If consecutive requests start with the same tokens (same system prompt, same tool definitions, same earlier history), servers can reuse the cached computation for that prefix. vLLM supports automatic prefix caching, and hosted providers including OpenAI apply prompt caching automatically and bill cached input tokens at a discount. The design rule: put stable content first and variable content last, and avoid edits to the beginning of a long context (such as a timestamp at the top of the system prompt) that invalidate the cache on every call. You will see this rule again in Module 6.

**Summary: five facts to carry into every later module.** The model sees only the tokens you send. Roles are formatting, not security. The API forgets everything between calls. Output is sampled, so variation is normal and must be tested for. More context costs time and money and can lower quality.

## Check your understanding (Module 1)

Answer from memory first; solutions are at the end of the module.

1. In one sentence, what does an LLM compute on each step of generation?
2. Why might the same 1,000-word document cost a different number of tokens on two models?
3. What is a chat template, and what happens if the wrong one is used?
4. Your chatbot "remembers" the user's name from three turns ago. Where is that memory actually stored?
5. True or false: setting `temperature=0` makes outputs perfectly reproducible. Explain.
6. A reasoning model returns an empty answer. Which field do you check first, and what does it tell you?
7. You double the length of the *input* but keep the output the same. Which latency metric grows most: time to first token, or decode time?
8. Why should a timestamp *not* be the first line of a long system prompt?

## Exercises (Module 1)

**Exercise 1.1 (warm-up, 20 min): tokens and templates.** Using `m1_tokens.py`, (a) find a ten-word English sentence and a ten-word sentence in another language you know, and compare their token counts; (b) print the Qwen3 chat template output for a conversation with a system message, two user turns and one assistant turn; (c) send the same messages to your server and compare `usage.prompt_tokens` with your own count of the template output. Explain any difference.

**Exercise 1.2 (core, 30 min): find your context limit.** Write a script that builds a single user message containing, in order: the sentence "Remember this: the project code name is PURPLE-HERON.", then N lines of filler text, then the question "What is the project code name? Answer with the code name only." Run it for N = 100, 500, 1,000, 2,000 and 4,000 filler lines. For each run, print the answer, `usage.prompt_tokens` and any error. Then raise your server's context length and repeat. Describe what your server does when the input is too long.

**Exercise 1.3 (core, 25 min): temperature in practice.** Ask "Pick a random fruit. Reply with one lowercase word." 20 times at each of `temperature` 0, 0.7 and 1.5 (thinking off). Tally the answers with `collections.Counter`. What does this tell you about using an LLM as a random number generator, and about temperature as a "creativity" knob?

**Exercise 1.4 (core, 40 min): is thinking worth it?** Create eight short arithmetic word problems with known integer answers (for example: "A train leaves at 09:40 and the trip takes 2 h 35 min. At what minute past the hour does it arrive?"). Run all eight with thinking off and with thinking on. For each mode, report accuracy, mean `completion_tokens` and mean seconds per question. Write two sentences recommending a mode for a customer-facing calculator feature.

**Exercise 1.5 (stretch, 30 min): the cost of memory.** A chatbot has a 1,500-token system prompt; each user message is about 60 tokens and each reply about 250 tokens. Every turn re-sends the full history. (a) Derive a formula for total input tokens over N turns. (b) Compute it for N = 10 and N = 50. (c) Assume input costs $1.25 and output $10 per million tokens (illustrative prices only) and compute the total cost of a 50-turn conversation. (d) Propose two context-engineering changes that would reduce the cost, and say what each risks.

## Interview corner (Module 1)

**Q: A user says your assistant "forgot" an instruction from earlier in a long conversation. What could cause that?** Model answer: Three candidates, in the order I'd check them. First, truncation: the conversation exceeded the configured context window and the server dropped the oldest tokens, or our own code trimmed history; I'd check `prompt_tokens` against the configured limit. Second, long-context degradation: even inside the window, models attend less reliably to instructions buried in a long context, so I'd test restating key constraints near the end or summarising history. Third, a conflicting later instruction from the user that the model followed instead. Then I'd add a regression test with a long conversation so it can't silently return.

**Q: Explain temperature and top-p. When would you use temperature 0, and does it make outputs deterministic?** Model answer: Temperature divides the logits before the softmax; lower values concentrate probability on the most likely tokens, higher values spread it out. Top-p keeps the smallest set of tokens covering probability p and samples from those. I use low temperature for extraction, classification and code, where I want the most likely answer, and higher temperature when I want diversity, such as generating test data. Temperature 0 is close to greedy decoding but not guaranteed deterministic, because GPU numerics and request batching can change results, so tests should check properties of the output rather than exact strings.

**Q: What is the difference between prefill and decode, and why does it matter for product design?** Model answer: Prefill processes the whole input in parallel and determines time to first token; decode produces output one token at a time and dominates total time for long answers. So long prompts mainly delay the first token, and long outputs mainly extend the total. For a chat UI I'd stream responses so users see the first tokens early, keep prompts lean, and cap output length; for a batch job I'd care about total throughput and maybe use a cheaper model.

**Q: When would you choose a reasoning model over a standard model?** Model answer: When the task needs multi-step reasoning, planning, or applying complex rules to messy input, and the extra latency and cost are acceptable. For high-volume, well-defined tasks like classification or extraction a faster model is usually better. I'd decide with an eval: run both on a representative test set and compare accuracy against latency and cost per request. A common production pattern is a reasoning model for planning and a cheaper model for execution.

**Q: What is a chat template?** Model answer: The model-specific program that turns a list of role-tagged messages into the single token sequence the model was trained on, inserting special tokens that mark where each message starts and ends and where the assistant should begin. Using the wrong template degrades quality badly. It also shows that system and user messages share one sequence, which is why role separation alone doesn't stop prompt injection.

## Solutions (Module 1)

**Check your understanding.**

1. A probability distribution over the next token, given all tokens so far.
2. Each model family has its own tokenizer and vocabulary, so the same text splits into different numbers of tokens.
3. The model-specific program that converts messages into one token sequence with special marker tokens. With the wrong template the model sees formatting it was not trained on and quality drops sharply; it may ignore roles or never stop generating.
4. In the client: your application re-sent the earlier messages in this request. The server stores nothing between calls.
5. False. Temperature 0 approximates greedy decoding, but numerical effects on GPUs and batching can still change outputs; some servers also apply their own defaults.
6. Check `finish_reason`. If it is `"length"`, the token budget was spent (often on thinking), so raise `max_tokens` or reduce thinking. Then inspect the reasoning field with `split_reasoning`.
7. Time to first token, because input is processed during prefill. Decode time depends mainly on output length.
8. It changes on every request, so the prompt prefix differs every time and prefix caching never hits, raising latency and cost. Put variable content at the end.

**Exercise 1.1.** Non-English text, code and long numbers usually need noticeably more tokens than plain English of the same length. The server's `prompt_tokens` is typically equal to or slightly larger than your template count, because the server may add its own system text, a default thinking block or tool definitions. The lesson: count with the server's numbers when budgets matter.

**Exercise 1.2.**

```python
# m1_context_limit.py
from openai import BadRequestError
from llm import client, MODEL, split_reasoning, thinking

FILLER = "Line {i}: The weather report says it was a calm, unremarkable day."

def probe(n_lines):
    body = "\n".join(FILLER.format(i=i) for i in range(n_lines))
    prompt = ("Remember this: the project code name is PURPLE-HERON.\n\n" + body +
              "\n\nWhat is the project code name? Answer with the code name only.")
    try:
        r = client.chat.completions.create(
            model=MODEL, messages=[{"role": "user", "content": prompt}],
            temperature=0, max_tokens=50, **thinking(False))
        _, answer = split_reasoning(r.choices[0].message)
        return answer, r.usage.prompt_tokens, None
    except BadRequestError as e:
        return None, None, str(e)[:120]

for n in (100, 500, 1000, 2000, 4000):
    print(n, probe(n))
```

Each filler line is roughly 15 tokens, so 500 lines is around 7,500 tokens. Typical results: with Ollama's 4k default, small inputs answer correctly, but once the input exceeds the limit the answer becomes wrong or invented and `prompt_tokens` stops growing, which reveals silent truncation of the start of the prompt (where the code name was). vLLM typically rejects over-long requests with a 400 error naming the maximum length instead. After raising the limit, the larger cases answer correctly again. Whatever you observe, write it down: knowing your server's overflow behaviour is the point.

**Exercise 1.3.**

```python
from collections import Counter
from llm import ask, thinking

for t in (0, 0.7, 1.5):
    answers = [ask("Pick a random fruit. Reply with one lowercase word.",
                   temperature=t, max_tokens=10, **thinking(False)).strip(". \n")
               for _ in range(20)]
    print(t, Counter(answers).most_common())
```

At 0 you get one fruit almost every time. At 0.7 you see a few, still dominated by a favourite (often "apple" or "banana"). At 1.5 you see more variety and sometimes odd outputs. Conclusions: an LLM is not a source of randomness, because its "random" choices follow learned preferences; use Python's `random` when you need randomness. Temperature changes how often less likely tokens are chosen; it does not add knowledge or quality, and high values raise the rate of errors and format violations.

**Exercise 1.4.**

```python
import re, time, statistics
from llm import client, MODEL, split_reasoning, thinking

PROBLEMS = [  # (question, answer); write your own eight
    ("A train leaves at 09:40 and the trip takes 2 h 35 min. "
     "At what minute past the hour does it arrive?", 15),
    ("I buy 3 notebooks at $4 and 2 pens at $1.50 and pay with $20. Change in cents?", 500),
]

def run(on):
    correct, toks, secs = 0, [], []
    for q, expected in PROBLEMS:
        t0 = time.perf_counter()
        r = client.chat.completions.create(
            model=MODEL, max_tokens=4096, temperature=0.6,
            messages=[{"role": "user", "content": q + " End with 'ANSWER: <integer>'."}],
            **thinking(on))
        secs.append(time.perf_counter() - t0)
        toks.append(r.usage.completion_tokens)
        _, text = split_reasoning(r.choices[0].message)
        m = re.search(r"ANSWER:\s*(-?\d+)", text)
        correct += bool(m and int(m.group(1)) == expected)
    return correct / len(PROBLEMS), statistics.mean(toks), statistics.mean(secs)

for on in (False, True):
    print("thinking" if on else "no thinking", run(on))
```

Expect thinking to raise accuracy on the harder problems while multiplying completion tokens and time several-fold. Your recommendation should follow your numbers: for a customer-facing calculator, a wrong answer is costly, so thinking (or, better, letting the model call a real calculator tool, Module 7) is justified if latency stays acceptable. Note the technique of asking for `ANSWER: <integer>`: it makes the output machine-checkable, which is the first step towards the automated evaluation of Module 4.

**Exercise 1.5.** Let s be the system prompt, u a user message and r a reply. Turn k sends s, all k user messages and the k − 1 earlier replies. Summing over N turns:

$$
N_{\text{in}}(N) = N s + u \frac{N(N+1)}{2} + r \frac{N(N-1)}{2}
$$

With s = 1,500, u = 60, r = 250: for N = 10, input is 15,000 + 3,300 + 11,250 = 29,550 tokens; for N = 50, input is 75,000 + 76,500 + 306,250 = 457,750 tokens. Output for N = 50 is 50 × 250 = 12,500 tokens. Cost at the illustrative prices: 0.45775 × $1.25 + 0.0125 × $10 ≈ $0.57 + $0.13 = $0.70 per conversation. Ten turns cost about 4 cents of input; fifty turns cost about 57 cents, roughly 15 times more for five times as many turns. That is the quadratic growth.

Two improvements: (1) keep the system prompt identical and first so prefix caching discounts most of the repeated input (risk: little; just avoid volatile content at the top); (2) once history exceeds a threshold, replace older turns with a running summary (risk: details lost in summarisation, which you must evaluate). A third option is retrieving only relevant past turns (Module 6), at the risk of missing context the retriever didn't rank highly.

## Sources and further reading (orientation, Modules 0 and 1)

Read the starred items in full during the course; they are the primary sources interviewers expect you to know.

**Concepts and definitions**

- ★ Anthropic, [Effective context engineering for AI agents](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents) (September 2025).
- ★ OpenAI (Ryan Lopopolo), [Harness engineering: leveraging Codex in an agent-first world](https://openai.com/index/harness-engineering/) (February 2026).
- ★ Birgitta Böckeler, [Harness engineering for coding agent users](https://martinfowler.com/articles/harness-engineering.html), martinfowler.com (April 2026).
- OpenAI, [Reasoning best practices](https://developers.openai.com/api/docs/guides/reasoning-best-practices).
- Liu et al., [Lost in the Middle: How Language Models Use Long Contexts](https://arxiv.org/abs/2307.03172).
- Hong, Troynikov and Huber, [Context Rot: How Increasing Input Tokens Impacts LLM Performance](https://trychroma.com/research/context-rot), Chroma (July 2025).
- Hugging Face, [Chat templates](https://huggingface.co/docs/transformers/chat_templating).

**Tools and setup**

- Ollama, [OpenAI compatibility](https://docs.ollama.com/api/openai-compatibility) and [Context length](https://docs.ollama.com/context-length).
- vLLM, [OpenAI-compatible server](https://docs.vllm.ai/en/latest/serving/online_serving/openai_compatible_server/) and the [Qwen3-8B serving recipe](https://recipes.vllm.ai/Qwen/Qwen3-8B).
- Qwen, [vLLM deployment guide](https://qwen.readthedocs.io/en/latest/deployment/vllm.html).
- [The Twelve-Factor App: Config](https://12factor.net/config).

**How this course was designed.** The module anatomy (lesson, then hands-on exercises, then solutions) follows the pattern of Anthropic's widely used [interactive prompt engineering tutorial](https://github.com/anthropics/prompt-eng-interactive-tutorial), which is organised as nine chapters each pairing a lesson with exercises. This course extends that pattern beyond prompting to context and harness engineering, runs on free local models, and adds interview practice. The Anthropic tutorial is a good optional companion for Module 2.

**Next:** [Module 2: Prompt engineering](03-module-2-prompt-engineering.md)
