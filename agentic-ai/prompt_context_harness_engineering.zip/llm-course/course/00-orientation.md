# Prompt, Context & Harness Engineering: A Self-Study Course for New Engineers

Last updated: 19 November 2026

## How to use this course

This is a 10-module course of about 43 hours of study, plus an appendix and a 10–15 hour capstone, that takes you from "I built a small chat app" to being able to discuss, design and build production LLM systems in interviews and on the job. The orientation comes first, then Modules 0 to 9 and the appendix in order; each part ends with a link to the next.

**Revisions.** The course was revised twice on 19 November 2026 after critical reviews: code was consolidated and unit-tested, a bug was fixed, claims were re-checked against primary sources, time estimates were raised, and an appendix was added. The **Changelog**, the last part of the course, lists every change.

**Who it is for.** Recent engineering graduates who know Python (functions, classes, dicts, virtual environments, `pip`) and have called an LLM at least once. You do not need machine-learning theory, a GPU, or a paid API key.

**What you will run.** Every example uses the official `openai` Python SDK, but pointed at a model running on your own machine through Ollama (for laptops) or vLLM (for a GPU server). Both expose an OpenAI-compatible HTTP API, so the same code also works against OpenAI's hosted service by changing two settings. This is the most portable skill you can learn: most providers and inference servers in industry speak this API shape.

**How every module is built.** Each module follows the same pattern, chosen because it matches what learning research says works for technical skills (worked examples first, then retrieval practice, then practice with feedback):

1. **Learning objectives**: what you will be able to do, stated as verbs you can test.
2. **Concepts**: short explanations, each followed by a worked code example you should type and run, not just read.
3. **Check your understanding**: quick recall questions. Answer them from memory before looking anything up; retrieving an answer strengthens memory far more than re-reading.
4. **Exercises**: graded from warm-up to stretch. Attempt each one for at least 15 minutes before opening the solution.
5. **Interview corner**: questions that real interviewers ask about the topic, with model answers.
6. **Solutions**: at the end of the module, deliberately separated so you are not tempted. Where a solution describes what a model will do (typical outputs, rough numbers, "usually"), it is an expectation based on how models of this size generally behave, not a measurement made for this course; record what your model actually does, and treat differences as worth investigating.

**Study tips.** Keep a single Git repository (`llm-course/`) with one folder per module; you will reuse code from earlier modules. Keep a "lab notebook" file where you record what you tried and what the model did, because LLM behaviour is probabilistic and your own observations are the best teacher. Spread the course over three to five weeks rather than cramming: spaced practice beats massed practice. When a solution differs from yours, ask *why* before accepting either.

**A note on currency.** This field moves monthly. Facts here are checked against official documentation as of the date at the top. Model names in particular change often, so the course teaches you how to pick a model rather than depending on one.

## Course map

The three disciplines in the title are nested, not competing: each one widens the scope of what you engineer around the same model. Industry vocabulary settled on these terms between 2023 and 2026, so it pays to know exactly what each one means and who coined the current usage.

**Prompt engineering** is writing and organising the instructions for a model call so it produces the outcome you want. It is about one request: the system message, the user message, examples, output format. [Anthropic's definition](https://www.anthropic.com/research/effective-context-engineering-for-ai-agents) is "methods for writing and organizing LLM instructions for optimal outcomes."

**Context engineering** is deciding *everything* that goes into the model's limited context window on every call, not only the instructions: retrieved documents, conversation history, tool definitions, tool results, memory files. Anthropic popularised the term in September 2025 and describes the goal as finding the smallest possible set of high-signal tokens that maximise the chance of the outcome you want. It matters most for agents, where the context is rebuilt on every step of a loop.

**Harness engineering** is designing the whole system around the model so that an agent does reliable work: the loop, the tools, the permissions and sandbox, the checks that verify results, and the feedback that corrects mistakes. The shorthand used across industry is **Agent = Model + Harness**. The term took off after OpenAI's February 2026 post [Harness engineering: leveraging Codex in an agent-first world](https://openai.com/index/harness-engineering/), and Birgitta Böckeler's April 2026 article on [martinfowler.com](https://martinfowler.com/articles/harness-engineering.html) gave it a clean mental model: *guides* steer the agent before it acts, *sensors* check its work afterwards, and each can be *computational* (tests, linters) or *inferential* (an LLM judge).

A simple way to remember the nesting: prompt engineering asks "how do I phrase this request?"; context engineering asks "what should the model see right now?"; harness engineering asks "what should the system allow, check and correct?"

```mermaid
flowchart TB
  subgraph H["Harness engineering · Modules 7–9<br/>loop, tools, permissions, sandbox, checks<br/><i>What should the system allow, check and correct?</i>"]
    subgraph C["Context engineering · Modules 5–6<br/>system prompt, retrieved documents, history, tool results, memory<br/><i>What should the model see on this call?</i>"]
      subgraph P["Prompt engineering · Modules 2–4<br/>instructions, examples and output format for one request<br/><i>How do I phrase this request?</i>"]
        M["The model · Modules 0–1<br/>tokens in, next-token probabilities out<br/><i>What does it compute, and what does that cost?</i>"]
      end
    end
  end
```

*Figure: Each discipline widens what you engineer around the same model.*

Read the picture from the inside out: each ring adds a new question on top of the one inside it, and the course follows the same order.

### The modules

| # | Module | Hours (estimate) | You will be able to |
| --- | --- | --- | --- |
| 0 | Setup: local models behind an OpenAI-compatible API | 2 | Run a local model with Ollama (or vLLM) and call it from Python with the `openai` SDK |
| 1 | The LLM as an engineering component | 4 | Explain tokens, context windows, chat templates, sampling and reasoning models; measure tokens and latency |
| 2 | Prompt engineering foundations | 5 | Write structured system prompts, use examples and delimiters, and iterate prompts systematically |
| 3 | Structured outputs and reliable parsing | 4 | Get schema-valid JSON with Pydantic, validate it, and recover from failures |
| 4 | Evaluating LLM systems | 5 | Build a test set, write code-based and LLM-as-judge graders, and catch regressions |
| 5 | Context engineering I: retrieval (RAG) | 5 | Build a retrieval pipeline with embeddings and chunking, and evaluate retrieval separately from generation |
| 6 | Context engineering II: memory and long-running context | 4 | Manage history, compact context, use structured notes and sub-agents |
| 7 | Tools and the agent loop | 5 | Implement function calling and an agent loop from scratch; explain MCP |
| 8 | Harness engineering | 5 | Add guides, sensors, permissions, sandboxing and verification loops to an agent |
| 9 | Production, security and capstone | 4, plus 10–15 for the capstone | Defend against prompt injection, add observability and cost controls, ship a capstone, rehearse interviews |
| A | Appendix: Responses API, testing LLM code, concurrency and serving | 2 | Use the Responses API, unit-test code that calls models, run calls concurrently within rate limits, and serve a feature over HTTP |
|  | **Total** | **about 45**, plus the capstone |  |

These estimates assume you read every section, answer the check questions and do every core exercise; stretch exercises and the capstone are extra. If you have less time, take the **core path (about 28 hours)**: read all sections, answer the check questions, and do only the first core exercise in each module, then build capstone milestones 1–4. Everyone works at a different pace, so treat the numbers as a planning aid and adjust after Module 2.

The order is deliberate. You cannot engineer context until you understand what a context window is (Module 1) and can write a good prompt (Module 2). You cannot claim a change is an improvement until you can measure it (Module 4), which is why evaluation comes *before* retrieval and agents rather than at the end, as it does in many tutorials. Harness engineering (Module 8) combines everything before it.

**Next:** [Module 0: Setup](01-module-0-setup.md)
