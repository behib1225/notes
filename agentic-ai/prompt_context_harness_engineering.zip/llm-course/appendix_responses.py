"""appendix_responses.py: the triage call written for the Responses API (Appendix).

Works against hosted OpenAI and against servers that implement /v1/responses
(Ollama supports only the stateless form, without previous_response_id).
"""
from llm import client, MODEL
from prompts import TRIAGE_SYSTEM_JSON, sanitize
from schemas import Triage


def triage_responses(ticket_text: str) -> Triage:
    r = client.responses.create(
        model=MODEL,
        instructions=TRIAGE_SYSTEM_JSON,                    # the system prompt
        input=f"<ticket>\n{sanitize(ticket_text)}\n</ticket>",
        text={"format": {"type": "json_schema", "name": "Triage",   # not response_format
                         "schema": Triage.model_json_schema(), "strict": True}},
        store=False,                                        # hosted OpenAI stores responses by default
        max_output_tokens=1000,
    )
    return Triage.model_validate_json(r.output_text)      # output_text joins the text output items
