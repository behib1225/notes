"""policy.py: allow / ask / deny around every tool call, with an audit log (Module 8)."""
from dataclasses import dataclass, field
from typing import Callable, Literal

from agent import Tool

Decision = Literal["allow", "ask", "deny"]


@dataclass
class Rule:
    tool: str                                     # exact name, or a prefix ending in '*'
    decision: Decision
    when: Callable[[dict], bool] = lambda args: True
    reason: str = ""


@dataclass
class Policy:
    rules: list[Rule]
    approver: Callable[[str, dict, str], bool] | None = None
    default: Decision = "deny"                     # unknown tools are denied
    audit: list[dict] = field(default_factory=list)

    def decide(self, tool: str, args: dict) -> tuple[Decision, str]:
        for r in self.rules:                       # first matching rule wins
            name_matches = r.tool == tool or (r.tool.endswith("*") and tool.startswith(r.tool[:-1]))
            if name_matches and r.when(args):
                return r.decision, r.reason
        return self.default, "no rule matched"

    def guard(self, t: Tool) -> Tool:
        def guarded(**args):
            decision, reason = self.decide(t.name, args)
            if decision == "ask":
                try:                               # fail closed AND log if approval breaks
                    approved = bool(self.approver and self.approver(t.name, args, reason))
                except Exception as e:
                    approved, reason = False, f"{reason} (approval failed: {e!r})"
                decision = "allow" if approved else "deny"
                reason += " (approved by a human)" if approved else " (not approved)"
            self.audit.append({"tool": t.name, "args": args, "decision": decision, "reason": reason})
            if decision == "deny":
                raise PermissionError(f"{t.name} is not permitted: {reason}. "
                                      "Tell the user what you could not do and why.")
            return t.fn(**args)
        return Tool(t.name, t.description, t.args, guarded)


def console_approver(tool: str, args: dict, reason: str) -> bool:
    print(f"\nAPPROVAL NEEDED: {tool} {args}\nWhy this needs approval: {reason}")
    return input("Approve? [y/N] ").strip().lower() == "y"   # anything else means no
