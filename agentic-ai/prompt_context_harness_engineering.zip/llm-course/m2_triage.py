"""m2_triage.py: text-format triage (Module 2)."""
import re

from llm import client, MODEL, split_reasoning, thinking
from prompts import triage_messages
from tickets import TICKETS

FIELD = re.compile(r"^\s*(category|urgency|summary)\s*:\s*(.+?)\s*$", re.I | re.M)


def parse_fields(text: str) -> dict:
    return {k.lower(): v for k, v in FIELD.findall(text)}


def triage(text, build=triage_messages):
    r = client.chat.completions.create(
        model=MODEL, messages=build(text), temperature=0, max_tokens=200, **thinking(False))
    _, out = split_reasoning(r.choices[0].message)
    return parse_fields(out), out


if __name__ == "__main__":
    for t in TICKETS:
        fields, _ = triage(t["text"])
        print(t["id"], fields.get("category"), fields.get("urgency"),
              "| expected:", t["category"], t["urgency"])
