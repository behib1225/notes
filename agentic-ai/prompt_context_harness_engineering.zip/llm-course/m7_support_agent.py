"""m7_support_agent.py: the AcmeCloud support agent (Module 7)."""
from typing import Literal

from pydantic import BaseModel, Field

from agent import Tool, run_agent
from rag import get_index

PRICES = {"starter": 8.0, "team": 20.0, "business": 35.0}   # USD per user per month
WORKSPACES = {"orion": {"plan": "team", "seats": 14, "status": "active"},
              "vega": {"plan": "business", "seats": 52, "status": "active"}}
CREATED_TICKETS: list[dict] = []


class SearchArgs(BaseModel):
    query: str = Field(description="What to look up, in plain words, e.g. 'refund for a duplicate charge'")


class PriceArgs(BaseModel):
    plan: Literal["starter", "team", "business"]
    billing: Literal["monthly", "annual"]
    seats: int = Field(ge=1, description="Number of users to price; use the workspace's seat count, or 1")


class WorkspaceArgs(BaseModel):
    workspace: str = Field(description="Workspace name as the user wrote it, e.g. 'Orion'")


class TicketArgs(BaseModel):
    category: Literal["billing", "bug", "account_access", "feature_request", "other"]
    urgency: Literal["low", "medium", "high"]
    summary: str = Field(description="One sentence a support engineer can act on")


def search_help_center(query: str):
    return [{"id": c.id, "text": c.text} for c in get_index().hybrid(query, k=3)]


def get_plan_price(plan: str, billing: str, seats: int):
    per_user = round(PRICES[plan] * (0.85 if billing == "annual" else 1.0), 2)
    return {"plan": plan, "billing": billing, "seats": seats,
            "usd_per_user_per_month": per_user, "usd_total_per_month": round(per_user * seats, 2)}


def get_workspace(workspace: str):
    ws = WORKSPACES.get(workspace.strip().lower())
    if ws is None:
        raise ValueError(f"no workspace named {workspace!r}; ask the user to check the name")
    return {"workspace": workspace, **ws}


def create_ticket(category: str, urgency: str, summary: str):
    for t in CREATED_TICKETS:                  # idempotent per category within a conversation
        if t["category"] == category:
            return {**t, "note": "A ticket for this already exists; reuse its id."}
    ticket = {"ticket_id": f"T-{1000 + len(CREATED_TICKETS)}", "category": category,
              "urgency": urgency, "summary": summary, "status": "open"}
    CREATED_TICKETS.append(ticket)
    return ticket


TOOLS = [
    Tool("search_help_center", "Search AcmeCloud's help-centre articles. Returns up to 3 passages "
         "with ids. Use for any question about policies, limits, features or errors.",
         SearchArgs, search_help_center),
    Tool("get_plan_price", "Exact price for a plan, billing period and number of seats, including "
         "the annual discount. Use instead of doing price arithmetic yourself.",
         PriceArgs, get_plan_price),
    Tool("get_workspace", "Look up a workspace's current plan, seat count and status by name.",
         WorkspaceArgs, get_workspace),
    Tool("create_ticket", "Open a ticket for the human support team. Only when the user's problem "
         "needs a person (refunds, account changes, bugs you cannot solve). Returns the ticket id.",
         TicketArgs, create_ticket),
]

SYSTEM = """You are AcmeCloud's support agent. Use tools to look up facts; never guess policies,
prices or account details. Base answers on tool results and cite help-centre ids in brackets.
Create a ticket only when the problem needs a human, and give the user the ticket id. Be concise."""

if __name__ == "__main__":
    result = run_agent(SYSTEM, "Our workspace Orion keeps hitting API rate limits. What is our "
                       "limit, and what would Business cost per month for all our seats if we pay "
                       "annually?", TOOLS)
    for m in result.transcript[2:]:
        print(m["role"], "|", (m.get("content") or "")[:120], "|",
              [c["function"]["name"] for c in m.get("tool_calls", [])])
    print("\nSTOP:", result.stop_reason, "after", result.steps, "steps\n", result.answer)
