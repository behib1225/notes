"""appendix_serve.py: the triage component as an HTTP service (Appendix).

Run:  uvicorn appendix_serve:app --port 8080
Try:  curl -s localhost:8080/triage -H 'content-type: application/json' -d '{"text": "Login page is down"}'
"""
import openai
from fastapi import FastAPI
from fastapi.concurrency import run_in_threadpool
from pydantic import BaseModel, Field

from m3_triage import triage_robust

app = FastAPI(title="AcmeCloud triage")


class TriageRequest(BaseModel):
    text: str = Field(min_length=1, max_length=8000)   # bound the input: cost and abuse control


class TriageResponse(BaseModel):
    route: str
    category: str | None = None
    urgency: str | None = None
    summary: str | None = None


@app.post("/triage", response_model=TriageResponse)
async def triage_endpoint(req: TriageRequest) -> TriageResponse:
    try:
        # triage_robust uses the synchronous client; run it in a worker thread so the
        # event loop keeps serving other requests while this one waits for the model.
        result = await run_in_threadpool(triage_robust, req.text)
    except openai.APIError:
        return TriageResponse(route="default_queue")       # graceful degradation (Module 9.2)
    t = result.get("triage")
    if t is None:
        return TriageResponse(route=result["route"])        # validation failed: human review
    return TriageResponse(route=result["route"], category=t.category,
                          urgency=t.urgency, summary=t.summary)


@app.get("/healthz")
def healthz() -> dict:
    return {"ok": True}
