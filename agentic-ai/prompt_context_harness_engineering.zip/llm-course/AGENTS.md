# AGENTS.md: llm-course

Companion code and text for the course "Prompt, Context & Harness Engineering". Python 3.11+.

## How to work here
- Run `python -m pytest -q` after every code change. The tests use a scripted fake model and need no server.
- Keep one module per course concept; file names match the course text (see README.md).
- Model calls go through `llm.client`; never create another client.
- Structured outputs go through `structured.structured_call`; never parse model JSON by hand.
- Never edit `course/` or `CHANGELOG.md` by hand: change the course document, re-export it into
  `tools/raw-exports/`, and run `python tools/build_course_md.py`, then `python tools/check_links.py README.md CHANGELOG.md course`.

## Where to look
- README.md: module-to-file map, exercise-solution map, setup, what the tests do and do not check.
