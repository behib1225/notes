"""m3_triage.py: robust, schema-validated triage (Module 3)."""
from prompts import triage_messages, TRIAGE_SYSTEM_JSON
from schemas import Triage
from structured import structured_call


def business_rules(t: Triage) -> None:
    if t.category == "feature_request" and t.urgency == "high":
        raise ValueError("Policy: feature requests are never high urgency. "
                         "Re-check the category or lower the urgency.")


def triage_robust(text: str, **kwargs) -> dict:
    out = structured_call(triage_messages(text, TRIAGE_SYSTEM_JSON), Triage,
                          check=business_rules, **kwargs)
    if not out.ok:
        return {"route": "human_review", "errors": out.errors}
    return {"route": out.value.category, "triage": out.value, "attempts": out.attempts}
