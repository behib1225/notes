import json, os

import pytest

from conftest import completion
from agent import run_agent, run_tool
import m7_support_agent as sa
from policy import Policy, Rule
from tracing import Tracer
from harness import Workspace, make_tools, verify, run_pytest


def test_agent_tool_round_trip(script, tmp_path):
    script(completion(tool_calls=[("get_plan_price", {"plan": "business", "billing": "annual", "seats": 14})]),
           completion("Business annual for 14 seats is $416.50 per month."))
    tracer = Tracer(str(tmp_path / "t.jsonl"))
    r = run_agent(sa.SYSTEM, "price?", sa.TOOLS, tracer=tracer, trace_id="abc")
    assert r.stop_reason == "done" and r.steps == 2
    tool_msg = next(m for m in r.transcript if m["role"] == "tool")
    assert json.loads(tool_msg["content"])["usd_total_per_month"] == 416.5
    spans = [json.loads(l) for l in open(tmp_path / "t.jsonl")]
    assert [s["kind"] for s in spans] == ["model_call", "tool_call", "model_call"]
    assert spans[0]["prompt_tokens"] == 10 and all(s["trace_id"] == "abc" for s in spans)


def test_invalid_args_and_unknown_tool_become_observations(script):
    price = next(t for t in sa.TOOLS if t.name == "get_plan_price")
    assert run_tool(price, '{"plan": "gold", "billing": "annual", "seats": 1}').startswith("ERROR: invalid")
    script(completion(tool_calls=[("delete_everything", {})]), completion("Sorry."))
    r = run_agent(sa.SYSTEM, "x", sa.TOOLS)
    assert "unknown tool" in r.transcript[3]["content"]


def test_repeated_call_stops(script):
    call = completion(tool_calls=[("get_workspace", {"workspace": "Orion"})])
    script(call, call, call)
    assert run_agent(sa.SYSTEM, "x", sa.TOOLS).stop_reason == "repeated_call"


def test_max_steps(script):
    script(*[completion(tool_calls=[("get_workspace", {"workspace": f"w{i}"})]) for i in range(3)])
    assert run_agent(sa.SYSTEM, "x", sa.TOOLS, max_steps=3).stop_reason == "max_steps"


def _policy(approver):
    return Policy([Rule("get_*", "allow"),
                   Rule("create_ticket", "ask", when=lambda a: a["urgency"] == "high", reason="pages on-call"),
                   Rule("create_ticket", "allow")], approver=approver)


def test_policy_allow_ask_deny_and_fail_closed():
    sa.CREATED_TICKETS.clear()
    tools = {t.name: t for t in sa.TOOLS}
    args = '{"category": "account_access", "urgency": "high", "summary": "Locked out"}'
    p = _policy(lambda *a: False)
    assert "not permitted" in run_tool(p.guard(tools["create_ticket"]), args)
    def broken(*a):
        raise TimeoutError("no answer")
    p2 = _policy(broken)
    assert "not permitted" in run_tool(p2.guard(tools["create_ticket"]), args)
    assert p2.audit[-1]["decision"] == "deny" and "approval failed" in p2.audit[-1]["reason"]
    assert sa.CREATED_TICKETS == []
    p3 = _policy(lambda *a: True)
    assert "T-1000" in run_tool(p3.guard(tools["create_ticket"]), args)
    assert Policy([]).decide("anything", {})[0] == "deny"
    sa.CREATED_TICKETS.clear()


REFERENCE = '''def annual_price_cents(monthly_cents: int) -> int:
    """Monthly price in cents after the 15% annual discount, rounded half up."""
    if monthly_cents < 0:
        raise ValueError("monthly_cents must not be negative")
    return (monthly_cents * 85 + 50) // 100

def format_usd(cents: int) -> str:
    """Format integer cents as US dollars, e.g. 41650 -> '$416.50'."""
    return f"${cents // 100:,}.{cents % 100:02d}"
'''


def test_harness_jail():
    ws = Workspace()
    tools = {t.name: t.fn for t in make_tools(ws)}
    for bad in ["../outside.txt", "/etc/hosts", "src/../tests/test_money.py", "src/__init__.py"]:
        with pytest.raises(PermissionError):
            tools["write_file"](path=bad, content="x")
    with pytest.raises(PermissionError):
        tools["read_file"](path="/etc/hosts")
    os.symlink(ws.root / "tests" / "test_money.py", ws.root / "src" / "link.py")
    with pytest.raises(PermissionError):
        tools["write_file"](path="src/link.py", content="x")


def test_harness_verify_reference_cheat_and_trap():
    ws = Workspace()
    assert not verify(ws)[0]                                   # stub fails
    (ws.root / "src/money.py").write_text(REFERENCE)
    assert verify(ws)[0]                                       # correct solution passes
    trap = REFERENCE.replace("(monthly_cents * 85 + 50) // 100", "round(monthly_cents * 0.85)")
    (ws.root / "src/money.py").write_text(trap)
    report = run_pytest(ws)
    assert "test_rounds_half_up" in report and "FAILED" in report  # banker's rounding is caught
    cheat = ("class Yes(int):\n    def __eq__(self, other): return True\n"
             "def annual_price_cents(m):\n    if m < 0: raise ValueError\n    return Yes(0)\n"
             "class S(str):\n    def __eq__(self, other): return True\n"
             "def format_usd(c): return S('')\n")
    (ws.root / "src/money.py").write_text(cheat)
    assert not verify(ws)[0]                                   # __eq__ trick is caught
    (ws.root / "src/money.py").write_text(REFERENCE)
    (ws.root / "tests/test_money.py").write_text("def test_ok(): pass\n")
    ok, why = verify(ws)
    assert not ok and "modified" in why                        # weakened tests are caught


def test_mcp_server_lists_tools():
    import asyncio
    import mcp_helpcenter
    tools = asyncio.run(mcp_helpcenter.mcp.list_tools())
    assert {t.name for t in tools} == {"helpcenter_search", "helpcenter_list_articles"}
