"""Shared test fixtures: a scripted fake LLM and deterministic fake embeddings.

No network or model is needed. Tests check the course code's logic, not model quality.
"""
import json, os, pathlib, re, sys, zlib
from types import SimpleNamespace

import numpy as np
import pytest

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
os.environ.setdefault("THINKING_MODE", "ollama")

from openai.types.chat import ChatCompletion  # noqa: E402

import llm  # noqa: E402


def completion(content=None, tool_calls=None, finish_reason=None, reasoning=None,
               prompt_tokens=10, completion_tokens=5):
    message = {"role": "assistant", "content": content}
    if tool_calls:
        message["tool_calls"] = [
            {"id": f"call_{i}", "type": "function",
             "function": {"name": name, "arguments": args if isinstance(args, str) else json.dumps(args)}}
            for i, (name, args) in enumerate(tool_calls)]
    if reasoning:
        message["reasoning"] = reasoning
    return ChatCompletion.model_validate({
        "id": "fake", "object": "chat.completion", "created": 0, "model": "fake",
        "choices": [{"index": 0, "message": message,
                     "finish_reason": finish_reason or ("tool_calls" if tool_calls else "stop")}],
        "usage": {"prompt_tokens": prompt_tokens, "completion_tokens": completion_tokens,
                  "total_tokens": prompt_tokens + completion_tokens}})


class ScriptedLLM:
    """Returns pre-scripted responses in order and records every request."""
    def __init__(self, responses):
        self.responses, self.calls = list(responses), []

    def __call__(self, **kwargs):
        self.calls.append(kwargs)
        if not self.responses:
            raise AssertionError("ScriptedLLM ran out of responses")
        r = self.responses.pop(0)
        return r(kwargs) if callable(r) else r


@pytest.fixture
def script(monkeypatch):
    def install(*responses):
        fake = ScriptedLLM(responses)
        monkeypatch.setattr(llm.client.chat.completions, "create", fake)
        return fake
    return install


def _vec(text: str, dim: int = 512) -> list[float]:
    v = np.zeros(dim)
    for tok in re.findall(r"\w+", text.lower()):
        if tok in {"search_query", "search_document"}:
            continue
        v[zlib.crc32(tok.encode()) % dim] += 1.0
    v[0] += 1e-3
    return v.tolist()


@pytest.fixture
def fake_embeddings(monkeypatch):
    def create(model, input, **kwargs):
        return SimpleNamespace(data=[SimpleNamespace(embedding=_vec(t)) for t in input])
    monkeypatch.setattr(llm.client.embeddings, "create", create)
    import rag
    rag.get_index.cache_clear()
    yield
    rag.get_index.cache_clear()
