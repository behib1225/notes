import json

import evalkit
from graders import category_exact, high_urgency_recall, judge_alignment
from stats import sign_test, wilson


def test_wilson_values_used_in_module_4():
    lo, hi = wilson(45, 50); assert (round(lo, 3), round(hi, 3)) == (0.786, 0.957)
    lo, hi = wilson(18, 20); assert (round(lo, 3), round(hi, 3)) == (0.699, 0.972)
    lo, hi = wilson(180, 200); assert (round(lo, 3), round(hi, 3)) == (0.851, 0.934)


def test_sign_test_values_used_in_module_4():
    assert sign_test(6, 1) == 0.125
    assert round(sign_test(9, 3), 3) == 0.146
    assert sign_test(0, 0) == 1.0


def test_split_is_stable_and_roughly_30_percent():
    ids = [f"case-{i}" for i in range(2000)]
    first = [evalkit.split_of(i) for i in ids]
    assert first == [evalkit.split_of(i) for i in ids]
    assert 0.25 < first.count("test") / len(ids) < 0.35


def test_run_eval_and_compare(tmp_path):
    cases = evalkit.load_cases("eval/triage.jsonl")
    assert len(cases) == 19
    good = lambda text: {"category": next(c["expected"]["category"] for c in cases if c["input"] == text),
                         "urgency": "high"}
    bad = lambda text: {"category": "other", "urgency": "low"}
    a = evalkit.run_eval(bad, cases, [category_exact, high_urgency_recall], "a", out_dir=tmp_path)
    b = evalkit.run_eval(good, cases, [category_exact, high_urgency_recall], "b", out_dir=tmp_path)
    assert evalkit.rate(b, "category_exact") == 1.0
    fixed, broken = evalkit.compare(a, b, "category_exact")
    assert broken == [] and len(fixed) == sum(c["expected"]["category"] != "other" for c in cases)
    assert json.loads((tmp_path / "b.json").read_text())["label"] == "b"


def test_crashing_system_is_recorded_not_raised(tmp_path):
    def boom(_):
        raise RuntimeError("server down")
    run = evalkit.run_eval(boom, evalkit.load_cases("eval/triage.jsonl")[:2], [category_exact], "c",
                           out_dir=tmp_path)
    assert all(r["error"] and r["scores"]["category_exact"] is None for r in run["results"])


def test_judge_alignment():
    stats = judge_alignment([(True, True), (True, False), (False, False), (False, None)])
    assert stats == {"n_scored": 3, "unknown": 1, "agreement": 2 / 3, "TPR": 0.5, "TNR": 1.0}
