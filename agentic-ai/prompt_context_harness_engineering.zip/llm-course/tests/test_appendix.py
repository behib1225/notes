import asyncio, json

import httpx
import openai
import pytest
from fastapi.testclient import TestClient

from conftest import completion
import appendix_async
import appendix_serve


def _rate_limit_error():
    req = httpx.Request("POST", "http://test/v1/chat/completions")
    return openai.RateLimitError("slow down", response=httpx.Response(429, request=req), body=None)


def test_backoff_retries_then_succeeds(monkeypatch):
    real_sleep = asyncio.sleep
    monkeypatch.setattr(appendix_async.asyncio, "sleep", lambda s: real_sleep(0))
    attempts = []

    async def flaky():
        attempts.append(1)
        if len(attempts) < 3:
            raise _rate_limit_error()
        return "ok"

    assert asyncio.run(appendix_async.call_with_backoff(flaky)) == "ok" and len(attempts) == 3


def test_backoff_gives_up(monkeypatch):
    real_sleep = asyncio.sleep
    monkeypatch.setattr(appendix_async.asyncio, "sleep", lambda s: real_sleep(0))

    async def always():
        raise _rate_limit_error()

    with pytest.raises(openai.RateLimitError):
        asyncio.run(appendix_async.call_with_backoff(always, retries=2))


def test_concurrency_limit(monkeypatch):
    state = {"now": 0, "max": 0}

    async def fake_create(**kwargs):
        state["now"] += 1
        state["max"] = max(state["max"], state["now"])
        await asyncio.sleep(0.01)
        state["now"] -= 1
        return completion("category: bug\nurgency: low\nsummary: s")

    monkeypatch.setattr(appendix_async.aclient.chat.completions, "create", fake_create)
    outs = asyncio.run(appendix_async.triage_all([f"t{i}" for i in range(10)], concurrency=3))
    assert len(outs) == 10 and state["max"] == 3


def test_serve_success_validation_and_degradation(script, monkeypatch):
    client = TestClient(appendix_serve.app)
    good = json.dumps({"reasoning": "r", "category": "bug", "urgency": "high", "summary": "Login down."})
    script(completion(good))
    r = client.post("/triage", json={"text": "Login page is down"})
    assert r.status_code == 200 and r.json()["category"] == "bug" and r.json()["route"] == "bug"
    assert client.post("/triage", json={"text": ""}).status_code == 422      # input validation

    def down(**kwargs):
        raise openai.APIConnectionError(request=httpx.Request("POST", "http://test"))
    import llm
    monkeypatch.setattr(llm.client.chat.completions, "create", down)
    assert client.post("/triage", json={"text": "x"}).json()["route"] == "default_queue"
    assert client.get("/healthz").json() == {"ok": True}


def test_responses_request_shape(monkeypatch):
    from types import SimpleNamespace
    import llm
    import appendix_responses
    seen = {}

    def fake(**kwargs):
        seen.update(kwargs)
        return SimpleNamespace(output_text=json.dumps(
            {"reasoning": "r", "category": "billing", "urgency": "low", "summary": "s"}))

    monkeypatch.setattr(llm.client.responses, "create", fake)
    t = appendix_responses.triage_responses("Invoice address change")
    assert t.category == "billing"
    assert seen["text"]["format"]["type"] == "json_schema" and seen["store"] is False
    assert "response_format" not in seen and seen["instructions"].startswith("# Identity")
