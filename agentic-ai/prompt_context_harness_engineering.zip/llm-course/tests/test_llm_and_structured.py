import json

import pytest

from conftest import completion
import llm
from schemas import Triage
from structured import structured_call, response_format_for
from m3_triage import triage_robust
from m2_triage import parse_fields, triage

GOOD = json.dumps({"reasoning": "One user is blocked.", "category": "account_access",
                   "urgency": "medium", "summary": "User cannot reset password."})


def test_split_reasoning_variants():
    msg = completion("<think>hmm</think> Answer").choices[0].message
    assert llm.split_reasoning(msg) == ("hmm", "Answer")
    msg = completion("Answer", reasoning="field").choices[0].message
    assert llm.split_reasoning(msg) == ("field", "Answer")
    msg = completion("Plain").choices[0].message
    assert llm.split_reasoning(msg) == (None, "Plain")


def test_thinking_modes_and_merge():
    assert llm.thinking(False, "ollama") == {"reasoning_effort": "none"}
    assert llm.thinking(True, "vllm-qwen") == {"extra_body": {"chat_template_kwargs": {"enable_thinking": True}}}
    assert llm.thinking(False, "none") == {}
    with pytest.raises(ValueError):
        llm.thinking(True, "auto")
    merged = llm.merge_kwargs({"extra_body": {"a": 1}}, {"extra_body": {"b": 2}, "x": 3})
    assert merged == {"extra_body": {"a": 1, "b": 2}, "x": 3}


def test_schema_is_strict_compatible():
    schema = response_format_for(Triage)["json_schema"]["schema"]
    assert schema["additionalProperties"] is False
    assert set(schema["required"]) == set(schema["properties"])   # strict mode: all required
    assert list(schema["properties"])[0] == "reasoning"            # reasoning generated first


def test_structured_first_try(script):
    fake = script(completion(GOOD))
    out = structured_call([{"role": "user", "content": "x"}], Triage)
    assert out.ok and out.attempts == 1 and out.value.category == "account_access"
    req = fake.calls[0]
    assert req["response_format"]["type"] == "json_schema" and req["reasoning_effort"] == "none"


def test_validation_error_retries_with_feedback(script):
    bad = GOOD.replace("account_access", "login")
    fake = script(completion(bad), completion(GOOD))
    out = structured_call([{"role": "user", "content": "x"}], Triage)
    assert out.ok and out.attempts == 2 and len(out.errors) == 1
    retry_msgs = fake.calls[1]["messages"]
    assert retry_msgs[-2] == {"role": "assistant", "content": bad}
    assert "rejected" in retry_msgs[-1]["content"]


def test_truncation_retries_without_feedback_and_bigger_budget(script):
    fake = script(completion('{"reasoning": "cut', finish_reason="length"), completion(GOOD))
    out = structured_call([{"role": "user", "content": "x"}], Triage, max_tokens=100)
    assert out.ok and out.attempts == 2
    assert fake.calls[1]["max_tokens"] == 200
    assert fake.calls[1]["messages"] == fake.calls[0]["messages"]   # no feedback added


def test_fallback_after_max_attempts(script):
    script(*[completion("not json")] * 3)
    out = structured_call([{"role": "user", "content": "x"}], Triage)
    assert not out.ok and len(out.errors) == 3


def test_business_rule_rejection_and_routing(script):
    high_fr = json.dumps({"reasoning": "r", "category": "feature_request", "urgency": "high", "summary": "s"})
    script(completion(high_fr), completion(high_fr), completion(high_fr))
    assert triage_robust("dark mode please")["route"] == "human_review"


def test_text_triage_parsing(script):
    script(completion("category: bug\nurgency: high\nsummary: Dashboard blank."))
    fields, _ = triage("dashboard blank")
    assert fields == {"category": "bug", "urgency": "high", "summary": "Dashboard blank."}
    assert parse_fields("**category:** bug") == {}    # markdown bold is not parsed: a known limitation
