"""evalkit.py: a minimal evaluation harness (Module 4)."""
import datetime, hashlib, json, os, subprocess, time
from concurrent.futures import ThreadPoolExecutor


def split_of(case_id: str, test_fraction: float = 0.3) -> str:
    """Stable dev/test assignment from the id, so it never changes between runs."""
    h = int(hashlib.sha256(case_id.encode()).hexdigest(), 16) % 100
    return "test" if h < test_fraction * 100 else "dev"


def load_cases(path, split=None, tag=None):
    with open(path, encoding="utf-8") as f:
        cases = [json.loads(line) for line in f if line.strip()]
    if split:
        cases = [c for c in cases if split_of(c["id"]) == split]
    if tag:
        cases = [c for c in cases if tag in c.get("tags", [])]
    return cases


def _run_one(system, graders, case, trial):
    t0 = time.perf_counter()
    try:
        out, error = system(case["input"]), None
    except Exception as e:                       # a crash is a result, not a reason to stop
        out, error = {}, repr(e)
    latency = time.perf_counter() - t0
    scores = {g.__name__: (None if error else g(case, out)) for g in graders}
    return {"id": case["id"], "trial": trial, "tags": case.get("tags", []),
            "output": out, "error": error, "latency_s": round(latency, 3), "scores": scores}


def run_eval(system, cases, graders, label, trials=1, workers=2, meta=None, out_dir="runs"):
    jobs = [(c, t) for c in cases for t in range(trials)]
    with ThreadPoolExecutor(max_workers=workers) as pool:
        results = list(pool.map(lambda job: _run_one(system, graders, *job), jobs))
    try:
        commit = subprocess.run(["git", "rev-parse", "--short", "HEAD"],
                                capture_output=True, text=True).stdout.strip() or None
    except OSError:
        commit = None
    run = {"label": label, "time": datetime.datetime.now().isoformat(timespec="seconds"),
           "git_commit": commit, "meta": meta or {}, "results": results}
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, f"{label}.json"), "w", encoding="utf-8") as f:
        json.dump(run, f, indent=1, ensure_ascii=False, default=str)
    return run


def rate(run, grader):
    vals = [r["scores"][grader] for r in run["results"] if r["scores"].get(grader) is not None]
    return sum(vals) / len(vals) if vals else None


def summarize(run, by_tag=False):
    results = run["results"]
    groups = {"ALL": results}
    if by_tag:
        for r in results:
            for t in r["tags"]:
                groups.setdefault(t, []).append(r)
    graders = list(results[0]["scores"]) if results else []
    for name, rs in groups.items():
        cells = []
        for g in graders:
            vals = [r["scores"][g] for r in rs if r["scores"].get(g) is not None]
            cells.append(f"{g}={sum(vals)}/{len(vals)}" if vals else f"{g}=n/a")
        lat = sorted(r["latency_s"] for r in rs)
        p50 = lat[len(lat) // 2] if lat else 0
        print(f"{name:22} " + "  ".join(cells)
              + f"  p50={p50:.1f}s  errors={sum(bool(r['error']) for r in rs)}")


def compare(run_a, run_b, grader):
    """Paired comparison: which cases flipped between two runs?"""
    a = {(r["id"], r["trial"]): r["scores"].get(grader) for r in run_a["results"]}
    b = {(r["id"], r["trial"]): r["scores"].get(grader) for r in run_b["results"]}
    keys = [k for k in a if k in b and a[k] is not None and b[k] is not None]
    fixed = [k[0] for k in keys if not a[k] and b[k]]
    broken = [k[0] for k in keys if a[k] and not b[k]]
    return fixed, broken
