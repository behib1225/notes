"""agent.py: a minimal, production-shaped agent loop (Module 7), with optional tracing (Module 8)."""
import contextlib
import json
import uuid
from dataclasses import dataclass, field
from typing import Callable

from pydantic import BaseModel, ValidationError

from llm import client, MODEL, split_reasoning, thinking


@dataclass
class Tool:
    name: str
    description: str
    args: type[BaseModel]                 # argument schema = validator
    fn: Callable[..., object]

    def schema(self) -> dict:
        return {"type": "function", "function": {
            "name": self.name, "description": self.description,
            "parameters": self.args.model_json_schema()}}


@dataclass
class AgentResult:
    answer: str | None
    stop_reason: str                      # done | max_steps | repeated_call
    steps: int
    transcript: list[dict] = field(default_factory=list)


MAX_RESULT_CHARS = 4000


def run_tool(tool: Tool, raw_args: str) -> str:
    """Validate, execute, and always return text the model can read."""
    try:
        args = tool.args.model_validate_json(raw_args or "{}")
    except ValidationError as e:
        err = e.errors()[0]
        return (f"ERROR: invalid arguments for {tool.name}: field {err['loc']} {err['msg']}. "
                "Fix the arguments and call the tool again.")
    try:
        result = tool.fn(**args.model_dump())
    except Exception as e:                # a failing tool is an observation, not a crash
        return f"ERROR: {tool.name} failed: {e}"
    text = result if isinstance(result, str) else json.dumps(result, ensure_ascii=False)
    if len(text) > MAX_RESULT_CHARS:      # protect the context budget (Module 6)
        text = text[:MAX_RESULT_CHARS] + "\n[truncated: ask for something narrower]"
    return text


def run_agent(system: str, user: str, tools: list[Tool], max_steps: int = 8,
              tracer=None, trace_id: str | None = None) -> AgentResult:
    trace_id = trace_id or uuid.uuid4().hex
    span = (lambda kind, **a: tracer.span(trace_id, kind, **a)) if tracer else \
           (lambda kind, **a: contextlib.nullcontext({}))
    by_name = {t.name: t for t in tools}
    schemas = [t.schema() for t in tools]          # fixed for the whole run (cache-friendly)
    messages = [{"role": "system", "content": system}, {"role": "user", "content": user}]
    call_counts: dict[tuple, int] = {}
    for step in range(1, max_steps + 1):
        with span("model_call", step=step, model=MODEL) as s:
            r = client.chat.completions.create(model=MODEL, messages=messages, tools=schemas,
                                               temperature=0, max_tokens=1500, **thinking(False))
            if r.usage:
                s.update(prompt_tokens=r.usage.prompt_tokens,
                         completion_tokens=r.usage.completion_tokens,
                         finish_reason=r.choices[0].finish_reason)
        msg = r.choices[0].message
        _, text = split_reasoning(msg)
        if not msg.tool_calls:                     # stop condition 1: the model is done
            messages.append({"role": "assistant", "content": text})
            return AgentResult(text, "done", step, messages)
        messages.append({"role": "assistant", "content": text, "tool_calls": [
            {"id": c.id, "type": "function",
             "function": {"name": c.function.name, "arguments": c.function.arguments}}
            for c in msg.tool_calls]})
        for c in msg.tool_calls:
            key = (c.function.name, c.function.arguments)
            call_counts[key] = call_counts.get(key, 0) + 1
            if call_counts[key] > 2:               # stop condition 2: stuck in a loop
                return AgentResult(None, "repeated_call", step, messages)
            tool = by_name.get(c.function.name)
            with span("tool_call", tool=c.function.name) as s:
                out = (run_tool(tool, c.function.arguments) if tool else
                       f"ERROR: unknown tool {c.function.name!r}. Available tools: {sorted(by_name)}")
                s.update(result_chars=len(out), error=out.startswith("ERROR"))
            messages.append({"role": "tool", "tool_call_id": c.id, "content": out})
    return AgentResult(None, "max_steps", max_steps, messages)   # stop condition 3: budget
