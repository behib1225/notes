"""Check links in Markdown files.

  python tools/check_links.py README.md course            # relative links and #anchors only
  python tools/check_links.py README.md course --external # also request every http(s) URL

Exit status 1 if any link is broken. Uses only the standard library.
"""
import argparse
import pathlib
import re
import sys
import urllib.error
import urllib.request

LINK = re.compile(r"(?<!!)\[[^\]]*\]\(([^)\s]+)\)")
FENCE = re.compile(r"^\s*```")


def slugify(heading: str) -> str:
    """GitHub-style anchor for a heading."""
    s = re.sub(r"[^\w\- ]", "", heading.strip().lower())
    return s.replace(" ", "-")


def links_and_anchors(path: pathlib.Path):
    links, anchors, in_code = [], set(), False
    for n, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
        if FENCE.match(line):
            in_code = not in_code
            continue
        if in_code:
            continue
        m = re.match(r"^#{1,6} (.*)", line)
        if m:
            anchors.add(slugify(m.group(1)))
        line = re.sub(r"`[^`]*`", "", line)            # ignore links inside inline code
        links += [(n, target) for target in LINK.findall(line)]
    return links, anchors


def check_external(url: str, timeout: float = 20.0) -> str | None:
    headers = {"User-Agent": "Mozilla/5.0 (link checker)"}
    for method in ("HEAD", "GET"):                      # some servers reject HEAD
        try:
            req = urllib.request.Request(url, method=method, headers=headers)
            with urllib.request.urlopen(req, timeout=timeout) as r:
                if r.status < 400:
                    return None
        except urllib.error.HTTPError as e:
            if method == "GET" or e.code not in (403, 405, 429, 501):
                if method == "GET" or e.code >= 500 or e.code == 404:
                    return f"HTTP {e.code}"
        except Exception as e:                          # DNS, TLS, timeout
            if method == "GET":
                return type(e).__name__
    return None


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("paths", nargs="+")
    ap.add_argument("--external", action="store_true")
    args = ap.parse_args()
    files = []
    for p in map(pathlib.Path, args.paths):
        files += sorted(p.rglob("*.md")) if p.is_dir() else [p]
    cache = {f.resolve(): links_and_anchors(f) for f in files}
    broken, external = [], {}
    for f in files:
        for n, target in cache[f.resolve()][0]:
            if target.startswith(("http://", "https://")):
                external.setdefault(target, []).append(f"{f}:{n}")
                continue
            if target.startswith("mailto:"):
                continue
            file_part, _, anchor = target.partition("#")
            dest = (f.parent / file_part).resolve() if file_part else f.resolve()
            if not dest.exists():
                broken.append(f"{f}:{n}: missing file {target}")
            elif anchor and dest.suffix == ".md":
                anchors = cache.get(dest) or links_and_anchors(dest)
                if anchor not in anchors[1]:
                    broken.append(f"{f}:{n}: missing anchor {target}")
    if args.external:
        for url, where in sorted(external.items()):
            err = check_external(url)
            if err:
                broken.append(f"{where[0]}: {err} {url}")
    print(f"checked {len(files)} files, {sum(len(v[0]) for v in cache.values())} links "
          f"({len(external)} distinct external URLs{' checked' if args.external else ' not checked'})")
    for b in broken:
        print("BROKEN", b)
    return 1 if broken else 0


if __name__ == "__main__":
    sys.exit(main())
