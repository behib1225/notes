"""Build course/*.md from the course document's Markdown exports.

Usage:  python tools/build_course_md.py
Input:  tools/raw-exports/*.md  (one export per document tab, as produced by the document's
        Markdown export) and tools/diagrams/*.mmd (Mermaid versions of the document's diagrams)
Output: course/  (one file per part, plus README.md), and CHANGELOG.md at the repository root

What it fixes in the raw export:
  - diagram placeholders ("[embedded content: ...]") become Mermaid blocks with a caption
  - ```latex code blocks become $$ display-math blocks
  - the leftover HTML entity &#91; becomes \\[
  - the orientation tab is split into orientation, Module 0 and Module 1, with Modules 0 and 1
    promoted one heading level so every module file starts with a single top-level heading
  - "Next:" lines become relative links between the generated files
"""
import pathlib
import re
import shutil

ROOT = pathlib.Path(__file__).resolve().parents[1]
RAW = ROOT / "tools" / "raw-exports"
DIAGRAMS = ROOT / "tools" / "diagrams"
OUT = ROOT / "course"

# caption in the document  ->  (Mermaid file, figure text)
FIGURES = {
    "The three disciplines, nested around the model, with the modules that teach each":
        ("course-map", "Each discipline widens what you engineer around the same model."),
    "Course architecture: one SDK, three interchangeable backends":
        ("architecture", "One client, three backends. Set `LLM_BASE_URL`, `LLM_API_KEY`, `LLM_MODEL` "
                         "(and `THINKING_MODE`) in `.env` to pick the backend."),
    "Autoregressive generation · one loop iteration per output token":
        ("generation-loop", "Generation is a loop: one model pass per output token."),
    "The prompt development loop · six steps, one decision":
        ("prompt-loop", "Keep a prompt change only if the whole test set says so."),
    "The validate–retry–fallback loop around a structured call":
        ("retry-loop", "Invalid output never reaches your code: it is retried or routed to a fallback. "
                       "Truncated output is retried with a doubled token budget and no feedback, up to a ceiling."),
    "The evaluation pipeline · from dataset to CI gate and back":
        ("eval-pipeline", "Every change runs the same suite, and failures flow back into the dataset."),
    "The two halves of a RAG pipeline":
        ("rag-pipeline", "Indexing prepares knowledge once; every question retrieves only what it needs."),
    "Layout of a context window for an assistant or agent, oldest token at the top":
        ("context-layout", "Stable content first, changing content last: the layout that keeps the cache warm. "
                           "The first token is at the top."),
    "One tool-call round trip, read top to bottom":
        ("tool-call-sequence", "The model only requests a tool call; your code runs it and returns the result."),
    "Anatomy of an agent harness · guides steer, policy constrains, sensors verify, humans steer the harness":
        ("harness-anatomy", "A harness wraps the model in guides, policy, an environment and sensors. "
                            "Observability runs underneath all of it: every model call, tool call, decision "
                            "and cost is traced."),
}

# output file, title used in links, raw source
PARTS = [
    ("00-orientation.md", "Orientation", None),
    ("01-module-0-setup.md", "Module 0: Setup", None),
    ("02-module-1-llm-as-component.md", "Module 1: The LLM as an engineering component", None),
    ("03-module-2-prompt-engineering.md", "Module 2: Prompt engineering", "module-2.md"),
    ("04-module-3-structured-outputs.md", "Module 3: Structured outputs", "module-3.md"),
    ("05-module-4-evaluation.md", "Module 4: Evaluating LLM systems", "module-4.md"),
    ("06-module-5-retrieval.md", "Module 5: Context engineering I, retrieval", "module-5.md"),
    ("07-module-6-memory.md", "Module 6: Context engineering II, memory", "module-6.md"),
    ("08-module-7-tools-and-agents.md", "Module 7: Tools and the agent loop", "module-7.md"),
    ("09-module-8-harness-engineering.md", "Module 8: Harness engineering", "module-8.md"),
    ("10-module-9-production-security-capstone.md", "Module 9: Production, security and capstone", "module-9.md"),
    ("11-appendix.md", "Appendix: Responses API, testing, concurrency, serving", "appendix.md"),
    ("12-changelog.md", "Changelog", "changelog.md"),
]

PLACEHOLDER = re.compile(r"^&#91;embedded content: (.*)\\\]$")
NEXT = re.compile(r"^\*\*Next:\*\*")


def transform(text: str) -> str:
    lines, out, in_code, i = text.split("\n"), [], False, 0
    while i < len(lines):
        line = lines[i]
        stripped = line.strip()
        if not in_code and stripped == "```latex":
            j = i + 1
            while lines[j].strip() != "```":
                j += 1
            out += ["$$", *lines[i + 1:j], "$$"]
            i = j + 1
            continue
        if stripped.startswith("```"):
            in_code = not in_code
            out.append(line)
            i += 1
            continue
        if not in_code:
            m = PLACEHOLDER.match(stripped)
            if m:
                name, figure = FIGURES[m.group(1)]          # KeyError = unknown diagram: fail loudly
                mermaid = (DIAGRAMS / f"{name}.mmd").read_text().rstrip("\n")
                out += ["```mermaid", mermaid, "```", "", f"*Figure: {figure}*"]
                i += 1
                continue
            if NEXT.match(stripped):                         # rebuilt below with real links
                i += 1
                continue
            line = line.replace("&#91;", "\\[")
            line = re.sub(r"^Nov 19, 2026$", "Last updated: 19 November 2026", line)
        out.append(line)
        i += 1
    return "\n".join(out).rstrip("\n") + "\n"


def promote(text: str) -> str:
    """Raise every heading one level (## -> #) outside code blocks."""
    out, in_code = [], False
    for line in text.split("\n"):
        if line.strip().startswith("```"):
            in_code = not in_code
        if not in_code and re.match(r"^#{2,6} ", line):
            line = line[1:]
        out.append(line)
    return "\n".join(out)


def split_orientation(text: str) -> tuple[str, str, str]:
    lines = text.split("\n")
    def find(prefix):
        hits = [k for k, l in enumerate(lines) if l.startswith(prefix)]
        assert len(hits) == 1, (prefix, hits)
        return hits[0]
    m0, m1 = find("## Module 0:"), find("## Module 1:")
    src = find("## Sources and further reading (orientation, Modules 0–1)")
    orientation = "\n".join(lines[:m0])
    module0 = promote("\n".join(lines[m0:m1]))
    module1 = promote("\n".join(lines[m1:src])) + "\n" + "\n".join(lines[src:]).replace(
        "## Sources and further reading (orientation, Modules 0–1)",
        "## Sources and further reading (orientation, Modules 0 and 1)")
    return orientation, module0, module1


def build() -> None:
    if OUT.exists():
        shutil.rmtree(OUT)
    OUT.mkdir()
    o, m0, m1 = split_orientation(transform((RAW / "orientation-modules-0-1.md").read_text()))
    bodies = [o, m0, m1] + [transform((RAW / raw).read_text()) for _, _, raw in PARTS[3:]]
    for k, ((name, _, _), body) in enumerate(zip(PARTS, bodies)):
        body = body.rstrip("\n") + "\n"
        if k + 1 < len(PARTS):
            nxt_name, nxt_title, _ = PARTS[k + 1]
            body += f"\n**Next:** [{nxt_title}]({nxt_name})\n"
        (OUT / name).write_text(body)
    shutil.copy(OUT / "12-changelog.md", ROOT / "CHANGELOG.md")
    rows = "\n".join(f"| [{name}]({name}) | {title} |" for name, title, _ in PARTS)
    (OUT / "README.md").write_text(INDEX.format(rows=rows))
    print(f"wrote {len(PARTS)} parts to {OUT}")


INDEX = """# Course text: Prompt, Context & Harness Engineering

The full text of the self-study course, one Markdown file per part, generated from the course
document's exports by `tools/build_course_md.py`. The code shown in each module is the code as
taught; the tested, consolidated versions (including worked solutions to several exercises) are in
the repository root, described in `../README.md`.

| File | Part |
| --- | --- |
{rows}

## Notes on the Markdown

- **Diagrams** are Mermaid code blocks, redrawn from the course document's diagrams and checked with
  the Mermaid 11 parser (syntax only; layout was not inspected visually). GitHub and GitLab render
  Mermaid natively. VS Code's built-in Markdown preview does not; install a Mermaid extension to see
  them there. Elsewhere they show as readable text.
- **Formulas** are LaTeX in `$$ … $$` display-math blocks, which GitHub and VS Code's preview render.
- **Time estimates** for each module are in its title and in the course map in `00-orientation.md`.
"""

if __name__ == "__main__":
    build()
