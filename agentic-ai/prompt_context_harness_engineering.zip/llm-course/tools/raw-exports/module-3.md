# Module 3: Structured outputs and reliable parsing (about 4 hours)

When an LLM's output is read by code rather than by a person, "usually the right format" is not good enough: one malformed answer in a thousand becomes an exception, a dropped ticket or a corrupted database row every day at scale. This module turns the triage prompt from Module 2 into a component with a typed contract that either returns valid data or fails in a controlled way.

**Learning objectives.** After this module you can:

- Explain the difference between JSON mode and schema-constrained decoding, and how constrained decoding works inside the server.
- Define an output contract with Pydantic and send it as a JSON Schema to OpenAI, vLLM or Ollama.
- Build a validate–retry–fallback loop that never lets invalid data through.
- Design schemas that are easy for models to fill correctly.
- Check extracted values against the source text, not just against the schema.

### The reliability ladder

There are five rungs between "hope" and "guarantee". Each rung catches a class of failure the one below it misses, and production systems usually stand on the top three at once.

| Rung | Technique | What it guarantees | What it misses |
| --- | --- | --- | --- |
| 1 | Ask for a format in the prompt (Module 2) | Nothing; usually right | Extra prose, missing fields, broken syntax |
| 2 | JSON mode | Syntactically valid JSON | Wrong keys, wrong types, invalid values |
| 3 | Schema-constrained decoding (structured outputs) | Output matches your JSON Schema | Values that are well-formed but wrong |
| 4 | Validation in code (Pydantic plus business rules) | Data your program can trust structurally and by rule | Plausible but false content |
| 5 | Semantic checks (grounding, cross-checks, evals) | Values consistent with the source and with each other | Errors no check was written for |

The central lesson of the module is in the last column of rung 3. A schema guarantees *shape*, never *truth*: a perfectly valid `{"category": "billing"}` can still be the wrong category. Rungs 4 and 5, and the evaluation work of Module 4, exist because of that gap.

## 3.1 JSON mode versus structured outputs

The OpenAI-style API offers two ways to ask for JSON through the `response_format` parameter, and all three servers in this course accept both.

```python
# JSON mode: any syntactically valid JSON object
response_format = {"type": "json_object"}

# Structured outputs: JSON that matches *your* schema
response_format = {
    "type": "json_schema",
    "json_schema": {"name": "triage", "schema": TRIAGE_SCHEMA, "strict": True},
}
```

**JSON mode** guarantees that the output parses as JSON, nothing more. Keys can be misspelled or missing, a number can arrive as a string, and `"urgency": "URGENT!!"` is perfectly valid JSON. Microsoft's Azure OpenAI documentation summarises the difference well: JSON mode guaranteed valid JSON but could not ensure strict adherence to a supplied schema, which is why structured outputs are now recommended for extraction and multi-step workflows.

**Structured outputs** (also called *schema-constrained* or *guided* decoding) guarantee that the output matches a JSON Schema you supply: the right keys, types, enum values and required fields. This is the default choice for any output your code reads. Use JSON mode only when the shape genuinely varies or a server lacks schema support.

On your local servers: Ollama's [structured outputs page](https://docs.ollama.com/capabilities/structured-outputs) says they work through the OpenAI-compatible API via `response_format` (its native API calls the same feature `format`), and vLLM's [structured outputs guide](https://docs.vllm.ai/en/latest/features/structured_outputs/) shows `response_format` with `json_schema` alongside vLLM-specific options in `extra_body`, such as choosing from a fixed list of strings or matching a regular expression.

## 3.2 How constrained decoding works

You already know the mechanism from Module 1. At every step the model produces a score for every token in the vocabulary, the server turns scores into probabilities, and one token is sampled. Constrained decoding adds one step before sampling: **any token that would make the output invalid is masked out**, its probability set to zero.

To know which tokens are invalid, the server compiles your JSON Schema into a grammar, a state machine that tracks where the output currently is (inside a key? after a colon? inside an enum string?) and which characters may come next. After `{"urgency": "` with an enum of `low`, `medium` and `high`, only tokens that start one of those three words survive the mask. The [vLLM project's introduction to structured decoding](https://blog.vllm.ai/2025/01/14/struct-decode-intro.html) explains this in more depth; vLLM's current backends are XGrammar and Guidance, and Ollama converts schemas into a grammar for its llama.cpp engine.

Understanding the mechanism lets you predict four behaviours that surprise people in production:

1. **Truncation still breaks JSON.** The grammar controls *which* tokens can appear, not *how many*. If generation hits `max_tokens` mid-object, you receive incomplete JSON and `finish_reason == "length"`. Always check `finish_reason` and leave a generous token budget, especially with reasoning models.
2. **The model can be forced down a wrong path.** If the schema requires a field the model has no information for, masking leaves it no option but to produce *something* valid. Required fields without an escape hatch (section 3.6) invite fabricated values.
3. **The model still needs to be told.** The mask removes invalid tokens but does not explain the task. If the prompt never mentions JSON or the fields, the model's preferred tokens may all be masked, and quality drops; OpenAI's API reference warns that in JSON mode a model not told to produce JSON may emit an unending stream of whitespace until it hits the token limit, and OpenAI's API rejects JSON-mode requests whose messages never mention JSON. Ollama's documentation likewise recommends also passing the schema as text in the prompt. Describe the fields in the prompt *and* enforce them with the schema.
4. **Reasoning models need care.** Thinking tokens are free text, so servers must decide whether constraints apply to the thinking, the answer, or both. vLLM documents a server setting for combining structured outputs with reasoning parsers, and some local setups put the JSON into the reasoning field instead of `content`. In this course, turn thinking off for structured calls unless you have tested the combination.

## 3.3 Define the contract with Pydantic

Writing JSON Schema by hand is error-prone. In Python the industry standard is to define the contract as a [Pydantic](https://docs.pydantic.dev/latest/) model and generate the schema from it, which gives you three things from one definition: the schema sent to the server, a validator for what comes back, and a typed object for the rest of your code. Install it with `pip install pydantic` (the course uses Pydantic v2).

```python
# schemas.py
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, field_validator

Category = Literal["billing", "bug", "account_access", "feature_request", "other"]
Urgency = Literal["low", "medium", "high"]

class Triage(BaseModel):
    model_config = ConfigDict(extra="forbid")      # schema gets additionalProperties: false

    reasoning: str = Field(description="One or two sentences: what the customer needs "
                                       "and who is affected. Written before the labels.")
    category: Category = Field(description="Team that should handle the ticket.")
    urgency: Urgency = Field(description="See the urgency definitions in the instructions.")
    summary: str = Field(description="One English sentence summarising the ticket.")

    @field_validator("summary")
    @classmethod
    def one_short_sentence(cls, v: str) -> str:
        if len(v.split()) > 30:
            raise ValueError("summary must be at most 30 words")
        return v
```

Run `print(Triage.model_json_schema())` and read the result: the `Literal` types became `enum` lists, the descriptions travel with the schema to the model, and every field is in `required`. Notice what is *not* in the schema: the 30-word rule lives in a Python validator. That split is deliberate and important:

- **Schema constraints** are enforced *during* generation, so the model cannot violate them. Use them for structure: types, enums, required fields.
- **Validator constraints** are checked *after* generation, so they can fail, but they can express any rule you can code: word counts, cross-field consistency, lookups against a database. Failures feed the retry loop in section 3.5.

Keep the schema to features every server supports well (objects, strings, numbers, booleans, arrays, enums, nullable fields). Hosted providers support only a subset of JSON Schema in strict mode; OpenAI's strict mode, for example, requires every property to be listed as required and `additionalProperties` to be false, and it rejects some keywords. Putting complex rules in validators keeps your schema portable.

The `reasoning` field comes **first** on purpose. JSON is generated left to right, just like text, so a field placed before the labels gives the model a short space to reason before committing to them, the same principle as section 2.5. Exercise 3.4 measures whether it helps on your model.

## 3.4 Getting schema-valid output from any backend

Update the prompt so its output section describes JSON instead of three lines; the rest of `TRIAGE_SYSTEM_V1` stays the same.

```python
# prompts.py (add)
TRIAGE_SYSTEM_JSON = TRIAGE_SYSTEM_V1.split("# Output format")[0] + """\
# Output format
Respond with a JSON object with these fields, in this order:
- reasoning: one or two sentences on what the customer needs and who is affected
- category: one of the categories above
- urgency: low, medium or high
- summary: one English sentence, at most 30 words
"""
```

This portable helper works against OpenAI, vLLM and Ollama because it uses only the standard `response_format` field and validates on the client:

```python
# structured.py
from pydantic import BaseModel, ValidationError
from llm import client, MODEL, merge_kwargs, thinking

class TruncatedOutput(ValueError):
    """Generation hit max_tokens, so the JSON is incomplete. Feedback cannot fix this."""

class InvalidOutput(ValueError):
    """The output did not validate. Carries the raw text so a retry can show it to the model."""
    def __init__(self, message: str, raw: str):
        super().__init__(message)
        self.raw = raw

def response_format_for(model: type[BaseModel]) -> dict:
    return {
        "type": "json_schema",
        "json_schema": {"name": model.__name__,
                        "schema": model.model_json_schema(),
                        "strict": True},
    }

def call_structured_once(messages, model: type[BaseModel], temperature: float = 0.0,
                         max_tokens: int = 1000, llm_model: str | None = None, **kwargs):
    """One attempt. Returns (parsed object, raw text). Raises on any failure."""
    request = merge_kwargs(
        {"model": llm_model or MODEL, "messages": messages,
         "response_format": response_format_for(model),
         "temperature": temperature, "max_tokens": max_tokens},
        thinking(False), kwargs)
    r = client.chat.completions.create(**request)
    choice = r.choices[0]
    raw = choice.message.content or ""
    if choice.finish_reason == "length":
        raise TruncatedOutput(f"output truncated at max_tokens={max_tokens}; JSON is incomplete")
    try:
        return model.model_validate_json(raw), raw
    except ValidationError as e:
        raise InvalidOutput(str(e), raw) from e
```

```python
# m3_try.py
from prompts import triage_messages, TRIAGE_SYSTEM_JSON
from schemas import Triage
from structured import call_structured_once
from tickets import TICKETS

for t in TICKETS[:5]:
    result, _ = call_structured_once(triage_messages(t["text"], TRIAGE_SYSTEM_JSON), Triage)
    print(t["id"], result.category, result.urgency, "|", result.summary)
```

`model_validate_json` both parses and validates: it raises `pydantic.ValidationError` if the JSON is malformed, a field is missing, an enum value is wrong or a validator fails. You now hold a `Triage` object whose fields your IDE and type checker understand.

**Convenience APIs.** The `openai` SDK also offers `client.chat.completions.parse(..., response_format=Triage)`, which builds the strict schema from the Pydantic class and returns `message.parsed` (older SDK versions expose it as `client.beta.chat.completions.parse`). On OpenAI's hosted models a safety refusal comes back in `message.refusal` instead of JSON, which your code must handle. Libraries such as [Instructor](https://python.useinstructor.com/) wrap the same ideas, including automatic retries. They are worth knowing, but build the loop yourself once (next section) so you understand what they do.

## 3.5 Validate, retry with feedback, fall back

Constrained decoding removes most format failures, but not all: outputs get truncated, servers lack schema support, validators reject values, and business rules catch combinations the schema allows. A production component therefore wraps the call in a loop with three properties: **every output is validated**, **failures are retried with the error shown to the model**, and **when retries run out, the input goes to a defined fallback** instead of crashing or, worse, passing bad data on.

&#91;embedded content: The validate–retry–fallback loop around a structured call\]

Only the right-hand path delivers data to the rest of your system; every other path either corrects the output or hands the input to a defined fallback.

Retrying *with feedback* matters. Repeating the identical request at temperature 0 usually reproduces the identical mistake; adding the model's bad answer and the validation error to the conversation gives it the information to correct itself, the same way a compiler error helps a programmer.

```python
# structured.py (add)
from dataclasses import dataclass, field
from typing import Callable, Optional

@dataclass
class Outcome:
    ok: bool
    value: Optional[BaseModel] = None
    attempts: int = 0
    errors: list[str] = field(default_factory=list)

def structured_call(messages, model: type[BaseModel], max_attempts: int = 3,
                    check: Optional[Callable] = None, max_tokens: int = 1000,
                    max_tokens_limit: int = 8000, **kwargs) -> Outcome:
    """Validated structured output. Never raises on bad output.

    Validation and business-rule errors are retried WITH feedback; truncation is retried
    WITHOUT feedback and with a doubled token budget, because the model did nothing wrong.
    """
    msgs, errors, budget = list(messages), [], max_tokens
    for attempt in range(1, max_attempts + 1):
        raw = ""
        try:
            value, raw = call_structured_once(msgs, model, max_tokens=budget, **kwargs)
            if check:
                check(value)                 # business rules: raise ValueError to reject
            return Outcome(True, value, attempt, errors)
        except TruncatedOutput as e:
            errors.append(f"attempt {attempt}: {e}")
            if budget >= max_tokens_limit:
                break
            budget = min(budget * 2, max_tokens_limit)
        except ValueError as e:              # InvalidOutput, or a business rule from check()
            raw = getattr(e, "raw", raw)     # show the model its own rejected output
            errors.append(f"attempt {attempt}: {e}")
            msgs = msgs + [
                {"role": "assistant", "content": raw or "(empty)"},
                {"role": "user", "content": "Your previous answer was rejected:\n"
                    f"{e}\nReturn a corrected JSON object that fixes this."},
            ]
    return Outcome(False, None, len(errors), errors)
```

**A bug this version fixes.** The first version of this loop set `raw = ""` and then called `call_structured_once`, which raised before returning when validation failed. So `raw` stayed empty, and the retry showed the model `(empty)` instead of its own rejected output: the feedback said what was wrong but not what had been written. The companion repository's unit test `test_validation_error_retries_with_feedback` caught this. Carrying the raw text on the exception (`InvalidOutput.raw`) fixes it; business-rule rejections already had `raw`, because they happen after a successful parse.

Now the triage component, with one business rule the schema cannot express and an explicit fallback:

```python
# m3_triage.py
from prompts import triage_messages, TRIAGE_SYSTEM_JSON
from schemas import Triage
from structured import structured_call

def business_rules(t: Triage) -> None:
    if t.category == "feature_request" and t.urgency == "high":
        raise ValueError("Policy: feature requests are never high urgency. "
                         "Re-check the category or lower the urgency.")

def triage_robust(text: str) -> dict:
    out = structured_call(triage_messages(text, TRIAGE_SYSTEM_JSON), Triage,
                          check=business_rules)
    if not out.ok:
        return {"route": "human_review", "errors": out.errors}
    return {"route": out.value.category, "triage": out.value, "attempts": out.attempts}
```

Five engineering details separate a toy loop from a production one:

- **Cap attempts.** Each retry costs a full call. Two or three attempts is typical; beyond that the input itself is usually the problem.
- **Treat truncation differently.** Feedback cannot fix an output cut off by `max_tokens`. The loop above therefore retries a truncated output without feedback and with a doubled token budget, up to a ceiling; if outputs keep hitting the ceiling, shorten what you ask for.
- **Choose the fallback deliberately.** A human review queue, a safe default (`other` / `medium`), or escalation to a stronger model are all valid; silently dropping the item is not.
- **Log every failure** with the prompt version, model, raw output and error. These logs become new test cases in Module 4.
- **Monitor the retry rate.** A rising rate of retries or fallbacks is an early warning that a model update, a prompt change or a shift in user inputs has broken something, often before any user complains.

## 3.6 Designing schemas models can fill correctly

A schema is a prompt as much as a contract: field names, descriptions and order all steer the model. Seven rules cover most cases.

1. **Use enums for anything your code branches on.** Free-text labels drift ("Billing", "billing issue", "payments"); enums cannot.
2. **Give every field an honest way out.** Make fields nullable (`str | None`) when the information may be absent, add `unknown` or `other` to enums, and say in the description when to use them. In strict mode a nullable field is still *required*; the model must explicitly write `null`, which is what you want.
3. **Order fields so evidence comes before decisions.** Put `reasoning` or `evidence` fields before the labels they justify, for the left-to-right reason in section 3.3. Drop them if measurement shows no gain, because they cost tokens.
4. **Keep it small and flat.** Every extra field is another decision the model can get wrong, and deep nesting is harder to fill. If a schema grows past a dozen or so fields, consider splitting the extraction into a chain.
5. **Make names and units unambiguous.** `amount_usd`, `due_date` with "ISO 8601, YYYY-MM-DD" in the description, `customer_email` rather than `contact`.
6. **Don't ask the model for what code can compute.** Totals, counts, date arithmetic, IDs and lookups belong in Python. Ask the model for the raw values and calculate the rest.
7. **Be sceptical of self-reported confidence.** A `confidence: 0.92` field produces a number, not a calibrated probability. If you need a confidence signal, use agreement across several samples, a separate verifier, or token log-probabilities where the server provides them (Ollama's OpenAI-compatible endpoint currently does not).

Finally, version schemas like APIs. Downstream services depend on them, so adding an optional field is safe, while renaming a field or an enum value is a breaking change.

## 3.7 Do format constraints hurt answer quality?

This is a live debate and a good interview topic. [Tam et al.](https://arxiv.org/abs/2408.02442) (EMNLP 2024 Industry Track) reported that format restrictions such as JSON mode reduced performance on reasoning tasks, with stricter constraints causing larger drops, while classification tasks often *improved* under constraints. The team behind the Outlines library replied in [Say What You Mean](https://blog.dottxt.ai/say-what-you-mean.html), arguing that much of the measured drop came from prompts that gave the constrained runs too little information and from the paper's use of a second LLM to parse free-text answers, and that with comparable prompts structured generation matched or beat free text.

The practical synthesis, which both sides' findings support:

- For **classification and extraction**, constraints usually help: they remove format errors and restrict the answer to valid labels.
- For **reasoning-heavy** tasks, give the model room to think before the constrained fields: a reasoning field first, thinking mode, or a two-step chain that answers in free text and then converts the answer to JSON (the paper calls this NL-to-Format).
- Always describe the task and fields in the prompt; never rely on the schema alone.
- **Measure on your task and model.** This is exactly the kind of question Module 4's evaluation harness answers in an afternoon.

## 3.8 Extraction with grounding checks

Extraction (pulling fields out of emails, invoices, contracts or tickets) is one of the most common production uses of LLMs, and its characteristic failure is **plausible fabrication**: a well-formed order number that appears nowhere in the email. The schema cannot catch it. A cheap code check often can, by verifying that extracted values actually occur in the source.

```python
# m3_extract.py
import re
from pydantic import BaseModel, ConfigDict, Field
from structured import structured_call

class OrderRef(BaseModel):
    model_config = ConfigDict(extra="forbid")
    evidence: str = Field(description="Verbatim sentence from the email that mentions "
                                      "the order, copied exactly. Empty string if none.")
    order_id: str | None = Field(description="Order id exactly as written, e.g. ACM-12345. "
                                             "null if the email contains none.")
    amount_usd: float | None = Field(description="Amount in US dollars if stated, else null.")

def norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip().lower()

def grounded(source: str):
    def check(o: OrderRef) -> None:
        if o.order_id and norm(o.order_id) not in norm(source):
            raise ValueError(f"order_id {o.order_id!r} does not appear in the email. "
                             "Copy it exactly or use null.")
        if o.evidence and norm(o.evidence) not in norm(source):
            raise ValueError("evidence is not a verbatim quote from the email.")
    return check

email = "Hi, my order ACM-48213 arrived damaged. I paid $129.90. Can you help? - Dana"
msgs = [{"role": "system", "content": "Extract the order reference from the email in <email> "
                                       "tags as JSON with fields evidence, order_id, amount_usd."},
        {"role": "user", "content": f"<email>\n{email}\n</email>"}]
print(structured_call(msgs, OrderRef, check=grounded(email)))
```

This is your first **computational sensor**, in the vocabulary of Module 8: a deterministic check that observes the model's output and feeds a correction back to it. The `evidence` field applies Anthropic's "ground responses in quotes" advice and makes the check stronger, since a verbatim quote is easy to verify. Grounding checks catch invented values, not wrong choices among real ones; if an email mentions two order numbers and the model picks the wrong one, you need an evaluation set (Module 4) to notice.

## Check your understanding (Module 3)

1. What does JSON mode guarantee, what do structured outputs add, and what does neither guarantee?
2. Explain constrained decoding in two sentences, using the words *logits* and *mask*.
3. How can a schema-constrained response still fail to parse?
4. Give one rule you would put in the schema and one you would put in a Pydantic validator, and explain the difference in when each is enforced.
5. Why does placing a `reasoning` field before `category` potentially change the category?
6. Why is retrying with the validation error better than retrying the identical request?
7. Name three acceptable fallbacks for an input that keeps failing validation, and one unacceptable one.
8. In strict mode, why is a nullable field still listed as required, and why is that desirable?
9. What does a grounding check catch, and what kind of error can it never catch?
10. Why should an invoice schema ask for line items but not for the computed total?

## Exercises (Module 3)

**Exercise 3.1 (core, 30 min): format reliability shoot-out.** Run Module 2's text-format triage (v1) and Module 3's JSON triage (`call_structured_once`) on all 14 tickets, three times each, at `temperature=0.7` to stress them. For each approach count format failures and category accuracy. Summarise in a small table and explain the result using section 3.2.

**Exercise 3.2 (core, 30 min): watch the retry loop work.** Add an artificial validator to a copy of `Triage` requiring the summary to start with one of a fixed set of verbs (for example Reports, Requests, Asks, Thanks, Complains), stating the rule in the error message but not in the prompt. Run `structured_call` on the 14 tickets and print `attempts` and `errors` for each. How often does feedback fix the problem on attempt two? Repeat with `max_attempts=1` and compare the fallback rate.

**Exercise 3.3 (core, 45 min): invoice extraction with computational checks.** Define a schema for the invoice below: `vendor`, `invoice_number`, `invoice_date` (YYYY-MM-DD), `line_items` (each with `description`, `quantity`, `unit_price_usd`) and `stated_total_usd`. Add checks that (a) the vendor name and invoice number appear in the text, (b) the date parses, and (c) the line items add up to the stated total within one cent. Then change the stated total to $955.50 and run again. What *should* your system do when the invoice itself is inconsistent?

```text
NORTHWIND OFFICE SUPPLY
Invoice no. NW-2026-0417          Date: 3 November 2026
Bill to: AcmeCloud Ltd.
2 x Ergonomic chair      @ $289.00
5 x Monitor arm          @ $64.50
1 x Delivery             @ $35.00
TOTAL DUE: $935.50
```

**Exercise 3.4 (core, 25 min): does field order matter?** Create three versions of the triage schema: `reasoning` first, `reasoning` last, and no `reasoning` field. Measure urgency accuracy and mean completion tokens on the 14 tickets for each. Is the difference larger than one ticket? What would you need to be confident?

**Exercise 3.5 (stretch, 40 min): parsing without schema support.** Some providers and older servers offer only JSON mode or nothing. Write `extract_json(text) -> dict` that handles: Markdown code fences, prose before and after the object, and braces inside string values. Test it on at least five messy strings you write yourself, then plug it into `structured_call` as an alternative to `response_format`.

## Interview corner (Module 3)

**Q: How do you get reliable structured data out of an LLM?** Model answer: In layers. I define the contract as a Pydantic model and send its JSON Schema using the provider's structured-output or constrained-decoding feature, so the output always has the right shape. I describe the fields in the prompt too, since the schema constrains but doesn't explain. On the client I validate with Pydantic plus business-rule checks, retry up to two or three times with the validation error fed back, and route anything still failing to a defined fallback such as a human queue. I log failures and monitor the retry rate, and I check `finish_reason` because truncation can still break JSON.

**Q: If structured outputs guarantee the schema, why validate at all?** Model answer: Because a schema guarantees shape, not truth or business validity. Truncation can produce incomplete JSON; some servers or models don't fully support strict mode; and many rules can't be expressed in JSON Schema, like cross-field policies or "this value must appear in the source document". Validation is cheap compared with bad data propagating downstream.

**Q: Design an extraction pipeline for a million invoices a month.** Model answer: Ingest and OCR, then a schema-constrained extraction call per invoice with a small, cheap model at temperature 0. Each result passes computational checks: grounding of key fields in the source text, date parsing, and arithmetic that line items sum to the total. Failures retry once with feedback, then escalate to a stronger model, then to a human queue, so cost is concentrated on hard cases. I'd keep a labelled evaluation set from real invoices, track field-level accuracy, sample production outputs for review, and monitor fallback rates per vendor to catch format changes. Schemas are versioned because downstream accounting systems consume them.

**Q: Does forcing JSON output hurt model quality?** Model answer: It can on reasoning-heavy tasks if the model has to answer without thinking, which is what the "Let Me Speak Freely" paper reported, though a rebuttal showed much of that gap came from prompt differences. For classification and extraction, constraints usually help. My approach is to let the model reason first, through a reasoning field, thinking mode or a free-text step followed by conversion, and then measure on my own task rather than rely on either paper.

## Solutions (Module 3)

**Check your understanding.**

1. JSON mode guarantees syntactically valid JSON. Structured outputs add conformance to your schema: keys, types, enums, required fields. Neither guarantees that values are correct or consistent with the source.
2. At each step the server computes logits for every token, then masks (sets to zero probability) every token the compiled grammar says would make the output invalid, and samples from what remains. The grammar is a state machine compiled from the JSON Schema.
3. Generation can stop at `max_tokens` mid-object (`finish_reason == "length"`); some servers or models also support strict mode only partially.
4. Schema: `urgency` is one of `low`, `medium`, `high`, enforced *during* generation, so it cannot be violated. Validator: "summary at most 30 words" or "feature requests are never high urgency", checked *after* generation, so it can fail and must be retried, but it can express any rule you can code.
5. Tokens are generated left to right and each depends on the earlier ones; reasoning tokens written before `category` become context that the category is conditioned on.
6. At temperature 0 an identical request tends to repeat the identical mistake; adding the bad output and the error message changes the context and tells the model exactly what to fix.
7. Acceptable: a human review queue, a documented safe default, escalation to a stronger model. Unacceptable: silently dropping the input or passing unvalidated data downstream.
8. Required-but-nullable forces the model to make an explicit decision (`null`) instead of omitting the key; your code always sees the field, and "absent" is distinguishable from "forgot".
9. It catches values that do not occur in the source (fabrications). It can never catch a wrong choice among values that do occur, such as the wrong one of two real order numbers.
10. Code can compute the total exactly; asking the model invites arithmetic errors, and having both the stated total and the line items lets code detect inconsistencies.

**Exercise 3.1.** First note the fix applied to `call_structured_once` above: it now takes `temperature` and `max_tokens` as parameters. A helper that hard-codes a keyword and also accepts `**kwargs` breaks with "got multiple values for keyword argument" the moment a caller passes the same keyword.

```python
# m3_shootout.py
from llm import client, MODEL, split_reasoning, thinking
from m2_triage import FIELD
from prompts import triage_messages, TRIAGE_SYSTEM_JSON
from schemas import Triage
from structured import call_structured_once
from tickets import TICKETS

CATS = {"billing", "bug", "account_access", "feature_request", "other"}

def text_version(text):
    r = client.chat.completions.create(model=MODEL, messages=triage_messages(text),
                                       temperature=0.7, max_tokens=200, **thinking(False))
    _, out = split_reasoning(r.choices[0].message)
    f = {k.lower(): v.strip().lower() for k, v in FIELD.findall(out)}
    ok = {"category", "urgency", "summary"} <= f.keys() and f["category"] in CATS
    return f["category"] if ok else None

def json_version(text):
    try:
        result, _ = call_structured_once(triage_messages(text, TRIAGE_SYSTEM_JSON),
                                         Triage, temperature=0.7)
        return result.category
    except ValueError:                      # includes pydantic.ValidationError
        return None

for name, fn in (("text", text_version), ("json", json_version)):
    fails = correct = 0
    for _ in range(3):
        for t in TICKETS:
            got = fn(t["text"])
            fails += got is None
            correct += got == t["category"]
    print(f"{name}: format failures {fails}/42, category correct {correct}/42")
```

Typical result on small local models: the text version shows a few format failures at temperature 0.7 (Markdown bold around field names, capitalised or invented labels, extra commentary), while the JSON version shows zero or near zero, because invalid tokens are masked. Category accuracy is usually similar, which illustrates the module's main point: constraints fix *shape*, not *judgement*.

**Exercise 3.2.** A checkable version of the verb rule:

```python
from pydantic import field_validator
from schemas import Triage
from structured import structured_call
from prompts import triage_messages, TRIAGE_SYSTEM_JSON
from tickets import TICKETS

VERBS = ("Reports", "Requests", "Asks", "Thanks", "Complains")

class TriageVerb(Triage):
    @field_validator("summary")
    @classmethod
    def starts_with_verb(cls, v: str) -> str:
        if not v.startswith(VERBS):
            raise ValueError(f"summary must start with one of {VERBS}, "
                             "for example 'Reports that the export fails.'")
        return v

for t in TICKETS:
    out = structured_call(triage_messages(t["text"], TRIAGE_SYSTEM_JSON), TriageVerb)
    print(t["id"], out.ok, out.attempts, out.errors[:1])
```

Because the rule is not in the prompt or the schema, most first attempts fail, and most second attempts succeed once the error message explains the rule. With `max_attempts=1` the same tickets all go to the fallback. Two lessons: feedback retries work well when the error message is specific and actionable; and they are a safety net, not a design strategy. Every retry doubles the cost of that request, so once you know a rule, put it in the prompt.

**Exercise 3.3.**

```python
# m3_invoice.py
from datetime import date
from pydantic import BaseModel, ConfigDict, Field
from structured import structured_call
from m3_extract import norm

class LineItem(BaseModel):
    model_config = ConfigDict(extra="forbid")
    description: str
    quantity: int
    unit_price_usd: float

class Invoice(BaseModel):
    model_config = ConfigDict(extra="forbid")
    vendor: str
    invoice_number: str
    invoice_date: str = Field(description="ISO 8601 date, YYYY-MM-DD")
    line_items: list[LineItem]
    stated_total_usd: float = Field(description="The total exactly as printed")

def transcription_checks(source):
    def check(inv: Invoice) -> None:
        for name in ("vendor", "invoice_number"):
            if norm(getattr(inv, name)) not in norm(source):
                raise ValueError(f"{name} {getattr(inv, name)!r} is not in the invoice text; copy it exactly.")
        date.fromisoformat(inv.invoice_date)        # raises ValueError if malformed
    return check

def process(source: str) -> dict:
    msgs = [{"role": "system", "content": "Transcribe the invoice in <invoice> tags into JSON. "
             "Copy values exactly as printed; do not correct or recompute anything."},
            {"role": "user", "content": f"<invoice>\n{source}\n</invoice>"}]
    out = structured_call(msgs, Invoice, check=transcription_checks(source))
    if not out.ok:
        return {"status": "needs_review", "reason": "extraction failed", "errors": out.errors}
    inv = out.value
    computed = round(sum(li.quantity * li.unit_price_usd for li in inv.line_items), 2)
    if abs(computed - inv.stated_total_usd) > 0.01:
        return {"status": "needs_review", "invoice": inv,
                "reason": f"line items sum to {computed:.2f}, invoice states {inv.stated_total_usd:.2f}"}
    return {"status": "ok", "invoice": inv}
```

With the original invoice the items sum to 2 × 289.00 + 5 × 64.50 + 35.00 = 935.50, matching the stated total, so the status is `ok`. With $955.50 the status is `needs_review`. The key design decision is that the arithmetic check is **outside** the retry loop. If you fed "the totals don't match" back to the model, you would be pressuring it to change a number until they agree, which manufactures a fabrication. The model's job is faithful transcription; code verifies; a human resolves real inconsistencies, which in accounting may be a vendor error worth catching. (In production, represent money with `Decimal`, not `float`.)

**Exercise 3.4.** Define `TriageLast` (reasoning after summary) and `TriageNone` (no reasoning field), and adjust the prompt's field list to match each schema, because a prompt describing fields the schema does not have is another contradiction. Typical findings: reasoning-last behaves like no reasoning for accuracy, since the labels are written before it, but costs tokens; reasoning-first may fix one or two urgency calls on small models. With 14 tickets, though, a one-ticket difference is within noise: the standard error of an accuracy near 80% with n = 14 is about √(0.8 × 0.2 / 14) ≈ 11 percentage points. To be confident you need more cases and repeated runs, which Module 4 provides.

**Exercise 3.5.**

````python
import json, re

FENCE = re.compile(r"```(?:json)?\s*(.*?)```", re.S)

def extract_json(text: str) -> dict:
    """Return the first complete JSON object in text. Raises ValueError if none."""
    fenced = FENCE.search(text)
    if fenced:
        text = fenced.group(1)
    start = text.find("{")
    while start != -1:
        depth, in_str, escaped = 0, False, False
        for i in range(start, len(text)):
            ch = text[i]
            if in_str:
                if escaped:
                    escaped = False
                elif ch == "\\":
                    escaped = True
                elif ch == '"':
                    in_str = False
            elif ch == '"':
                in_str = True
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    try:
                        return json.loads(text[start:i + 1])
                    except json.JSONDecodeError:
                        break
        start = text.find("{", start + 1)
    raise ValueError("no JSON object found in model output")

assert extract_json('Sure! {"a": "has } brace"} hope that helps')["a"] == "has } brace"
assert extract_json('```json\n{"a": 1}\n```')["a"] == 1
````

To use it, call the model with `response_format={"type": "json_object"}` (or none) and replace `model.model_validate_json(raw)` with `model.model_validate(extract_json(raw))`. This works, but every heuristic parser eventually meets an output it cannot handle; prefer constrained decoding whenever the server supports it, and keep this as a fallback.

## Sources and further reading (Module 3)

**Documentation**

- ★ vLLM, [Structured outputs](https://docs.vllm.ai/en/latest/features/structured_outputs/) and the vLLM blog's [introduction to structured decoding](https://blog.vllm.ai/2025/01/14/struct-decode-intro.html).
- ★ Ollama, [Structured outputs](https://docs.ollama.com/capabilities/structured-outputs).
- OpenAI, [Prompt engineering guide](https://developers.openai.com/api/docs/guides/prompt-engineering) (links to the Structured Outputs guide and supported-schema rules).
- Microsoft, [Azure OpenAI structured outputs](https://learn.microsoft.com/azure/ai-foundry/openai/how-to/structured-outputs): a clear comparison with JSON mode and the strict-schema requirements.
- [Pydantic documentation](https://docs.pydantic.dev/latest/) and [Instructor](https://python.useinstructor.com/).

**The format-restriction debate**

- Tam et al., [Let Me Speak Freely? A Study on the Impact of Format Restrictions on Performance of Large Language Models](https://arxiv.org/abs/2408.02442), EMNLP 2024 Industry Track.
- Will Kurt (.txt), [Say What You Mean: A Response to 'Let Me Speak Freely'](https://blog.dottxt.ai/say-what-you-mean.html).

**Next:** Module 4: Evaluating LLM systems
