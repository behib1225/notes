"""mcp_helpcenter.py: the help centre as an MCP server (Module 7).

Written for the official MCP Python SDK v2 (pip install "mcp[cli]", tested with mcp 2.3.0).
On SDK 1.x the class was called FastMCP:  from mcp.server.fastmcp import FastMCP as MCPServer
stdio servers must never print to stdout: it is the protocol channel. Log to stderr.
"""
from mcp.server import MCPServer

from helpcenter import DOCS
from rag import get_index

mcp = MCPServer("acme-helpcenter")


@mcp.tool()
def helpcenter_search(query: str, k: int = 3) -> list[dict]:
    """Search AcmeCloud help-centre articles about policies, limits, features and error
    codes. Returns up to k passages (maximum 5), each with an id to cite. Not for
    account-specific data such as a customer's plan or invoices."""
    k = max(1, min(k, 5))
    return [{"id": c.id, "title": f"{c.title} > {c.section}", "text": c.text}
            for c in get_index().hybrid(query, k=k)]


@mcp.tool()
def helpcenter_list_articles() -> list[dict]:
    """List all help-centre articles with their titles. Use to discover what topics exist
    before searching or reading an article."""
    return [{"name": name, "title": text.splitlines()[0].lstrip("# ")} for name, text in DOCS.items()]


@mcp.resource("helpcenter://articles/{name}")
def article(name: str) -> str:
    """Full text of one help-centre article, for example refunds.md."""
    return DOCS[name]


if __name__ == "__main__":
    mcp.run()      # stdio by default; mcp.run(transport="streamable-http") serves over HTTP
