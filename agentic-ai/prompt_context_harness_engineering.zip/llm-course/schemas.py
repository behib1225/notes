"""schemas.py: Pydantic contracts (Module 3)."""
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

Category = Literal["billing", "bug", "account_access", "feature_request", "other"]
Urgency = Literal["low", "medium", "high"]


class Triage(BaseModel):
    model_config = ConfigDict(extra="forbid")      # schema gets additionalProperties: false

    reasoning: str = Field(description="One or two sentences: what the customer needs "
                                       "and who is affected. Written before the labels.")
    category: Category = Field(description="Team that should handle the ticket.")
    urgency: Urgency = Field(description="See the urgency definitions in the instructions.")
    summary: str = Field(description="One English sentence summarising the ticket.")

    @field_validator("summary")
    @classmethod
    def one_short_sentence(cls, v: str) -> str:
        if len(v.split()) > 30:
            raise ValueError("summary must be at most 30 words")
        return v
