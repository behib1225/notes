"""memory.py: long-term user memory with model-proposed, code-checked updates (Module 6)."""
import datetime, json, os, re, uuid

from pydantic import BaseModel, ConfigDict, Field

from structured import structured_call


class MemoryUpdate(BaseModel):
    model_config = ConfigDict(extra="forbid")
    add: list[str] = Field(description="New durable facts about the user, one short sentence each")
    remove_ids: list[str] = Field(description="Ids of stored memories that are now wrong, or that "
                                              "the user asked to forget")


MEMORY_SYSTEM = """You maintain long-term memory for AcmeCloud's support assistant.
Compare the stored memories in <user_memory> with the user's messages and propose changes.
- Add only durable facts that will help in future conversations: plan, workspace name, role,
  preferences, unresolved issues. Do not add facts already stored.
- Remove memories the messages show are outdated, and any the user asks you to forget.
- Never store passwords, verification codes, payment card numbers or other secrets."""

_SECRET_WORDS = re.compile(r"password|passcode|cvv|verification code|api key", re.I)


def looks_secret(text: str) -> bool:
    """Code-level guard: long digit runs (spaces/dashes removed) or secret keywords."""
    compact = re.sub(r"[\s-]", "", text)
    return bool(re.search(r"\d{12,19}", compact)) or bool(_SECRET_WORDS.search(text))


def user_only_transcript(turns: list[dict]) -> str:
    """Only the user's own statements may create memories (prevents memory poisoning)."""
    return "\n".join(m["content"] for m in turns if m["role"] == "user")


class MemoryStore:
    def __init__(self, path: str = "memory.json"):
        self.path = path
        self.items = json.load(open(path, encoding="utf-8")) if os.path.exists(path) else []

    def render(self) -> str:
        lines = [f"- [{m['id']}] {m['text']}" for m in self.items]
        return "<user_memory>\n" + "\n".join(lines) + "\n</user_memory>"

    def update_from(self, turns: list[dict]):
        transcript = user_only_transcript(turns)
        out = structured_call(
            [{"role": "system", "content": MEMORY_SYSTEM},
             {"role": "user", "content": f"{self.render()}\n<user_messages>\n{transcript}\n</user_messages>"}],
            MemoryUpdate)
        if not out.ok:
            return out.errors
        drop = set(out.value.remove_ids)
        self.items = [m for m in self.items if m["id"] not in drop]
        for text in out.value.add:
            if looks_secret(text):
                continue                           # the prompt asks; the code enforces
            self.items.append({"id": uuid.uuid4().hex[:8], "text": text,
                               "created": datetime.date.today().isoformat()})
        with open(self.path, "w", encoding="utf-8") as f:
            json.dump(self.items, f, indent=1, ensure_ascii=False)
        return out.value
