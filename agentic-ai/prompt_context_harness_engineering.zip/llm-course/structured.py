"""structured.py: schema-constrained calls with validate-retry-fallback (Module 3)."""
from dataclasses import dataclass, field
from typing import Callable, Optional

from pydantic import BaseModel, ValidationError

from llm import client, MODEL, merge_kwargs, thinking


class TruncatedOutput(ValueError):
    """Generation hit max_tokens, so the JSON is incomplete. Feedback cannot fix this."""


class InvalidOutput(ValueError):
    """The output did not validate. Carries the raw text so a retry can show it to the model."""
    def __init__(self, message: str, raw: str):
        super().__init__(message)
        self.raw = raw


def response_format_for(model: type[BaseModel]) -> dict:
    return {
        "type": "json_schema",
        "json_schema": {"name": model.__name__,
                        "schema": model.model_json_schema(),
                        "strict": True},
    }


def call_structured_once(messages, model: type[BaseModel], temperature: float = 0.0,
                         max_tokens: int = 1000, llm_model: str | None = None, **kwargs):
    """One attempt. Returns (parsed object, raw text). Raises on any failure."""
    request = merge_kwargs(
        {"model": llm_model or MODEL, "messages": messages,
         "response_format": response_format_for(model),
         "temperature": temperature, "max_tokens": max_tokens},
        thinking(False), kwargs)
    r = client.chat.completions.create(**request)
    choice = r.choices[0]
    raw = choice.message.content or ""
    if choice.finish_reason == "length":
        raise TruncatedOutput(f"output truncated at max_tokens={max_tokens}; JSON is incomplete")
    try:
        return model.model_validate_json(raw), raw
    except ValidationError as e:
        raise InvalidOutput(str(e), raw) from e


@dataclass
class Outcome:
    ok: bool
    value: Optional[BaseModel] = None
    attempts: int = 0
    errors: list[str] = field(default_factory=list)


def structured_call(messages, model: type[BaseModel], max_attempts: int = 3,
                    check: Optional[Callable] = None, max_tokens: int = 1000,
                    max_tokens_limit: int = 8000, **kwargs) -> Outcome:
    """Validated structured output. Never raises on bad output.

    - Validation and business-rule errors are retried WITH feedback (the error is shown to the model).
    - Truncation is retried WITHOUT feedback, with a doubled token budget, because the model did
      nothing wrong that it could correct.
    """
    msgs, errors, budget = list(messages), [], max_tokens
    for attempt in range(1, max_attempts + 1):
        raw = ""
        try:
            value, raw = call_structured_once(msgs, model, max_tokens=budget, **kwargs)
            if check:
                check(value)                 # business rules: raise ValueError to reject
            return Outcome(True, value, attempt, errors)
        except TruncatedOutput as e:
            errors.append(f"attempt {attempt}: {e}")
            if budget >= max_tokens_limit:
                break
            budget = min(budget * 2, max_tokens_limit)
        except ValueError as e:              # InvalidOutput, or a business rule from check()
            raw = getattr(e, "raw", raw)
            errors.append(f"attempt {attempt}: {e}")
            msgs = msgs + [
                {"role": "assistant", "content": raw or "(empty)"},
                {"role": "user", "content": "Your previous answer was rejected:\n"
                    f"{e}\nReturn a corrected JSON object that fixes this."},
            ]
    return Outcome(False, None, len(errors), errors)
