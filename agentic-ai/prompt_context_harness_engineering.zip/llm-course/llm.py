"""llm.py: the one place that knows how to reach a model (Modules 0-1).

Configuration comes from environment variables (or a .env file):
  LLM_BASE_URL   e.g. http://localhost:11434/v1 (Ollama) or http://localhost:8000/v1 (vLLM)
  LLM_API_KEY    any non-empty value for local servers
  LLM_MODEL      e.g. qwen3:8b (Ollama) or Qwen/Qwen3-8B (vLLM)
  THINKING_MODE  how to switch a model's "thinking" on/off; see thinking() below
"""
import os
import re

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

BASE_URL = os.getenv("LLM_BASE_URL", "http://localhost:11434/v1")
API_KEY = os.getenv("LLM_API_KEY", "ollama")   # the SDK requires a value; local servers ignore it
MODEL = os.getenv("LLM_MODEL", "qwen3:8b")
THINKING_MODE = os.getenv("THINKING_MODE", "ollama")

# timeout: fail loudly instead of hanging; max_retries: the SDK retries connection errors, 429 and 5xx.
client = OpenAI(base_url=BASE_URL, api_key=API_KEY, timeout=120, max_retries=2)

_THINK = re.compile(r"<think>(.*?)</think>", re.DOTALL)


def split_reasoning(message):
    """Return (reasoning, answer) from a chat message.

    Servers expose a reasoning model's thinking as a separate field (named `reasoning`
    or `reasoning_content`, depending on server and version) or inline as <think>...</think>.
    """
    content = message.content or ""
    reasoning = None
    for name in ("reasoning", "reasoning_content"):
        reasoning = reasoning or getattr(message, name, None)
    extra = getattr(message, "model_extra", None) or {}
    reasoning = reasoning or extra.get("reasoning") or extra.get("reasoning_content")
    match = _THINK.search(content)
    if match:
        reasoning = reasoning or match.group(1).strip()
        content = _THINK.sub("", content)
    return reasoning, content.strip()


def thinking(on: bool, mode: str | None = None) -> dict:
    """Request kwargs that switch thinking on or off. Each server spells this differently.

    THINKING_MODE values:
      ollama            Ollama's OpenAI-compatible API: reasoning_effort ("none" asks for no
                        thinking; Ollama maps effort values per model, see its compatibility docs)
      vllm-qwen         vLLM serving Qwen3-style templates: chat_template_kwargs.enable_thinking
      openai-reasoning  hosted OpenAI reasoning models: reasoning_effort ("low" is the minimum we
                        send here; check the model page for the levels a given model accepts)
      none              the model has no thinking switch (e.g. non-reasoning models, which
                        reject reasoning_effort): send nothing
    """
    mode = mode or THINKING_MODE
    if mode == "ollama":
        return {"reasoning_effort": "medium" if on else "none"}
    if mode == "vllm-qwen":
        return {"extra_body": {"chat_template_kwargs": {"enable_thinking": on}}}
    if mode == "openai-reasoning":
        return {"reasoning_effort": "medium" if on else "low"}
    if mode == "none":
        return {}
    raise ValueError(f"unknown THINKING_MODE {mode!r}")


def merge_kwargs(*dicts: dict) -> dict:
    """Merge request kwargs, combining nested extra_body dicts instead of colliding."""
    out: dict = {}
    for d in dicts:
        for k, v in d.items():
            if k == "extra_body" and k in out:
                out[k] = {**out[k], **v}
            else:
                out[k] = v
    return out


def ask(prompt, system=None, **kwargs):
    """One-shot helper: send a prompt, return the answer text."""
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    response = client.chat.completions.create(model=MODEL, messages=messages, **kwargs)
    _, answer = split_reasoning(response.choices[0].message)
    return answer
