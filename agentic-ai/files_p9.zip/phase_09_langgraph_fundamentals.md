# Phase 9 — LangGraph Fundamentals: State, Nodes, Edges, Middleware, Persistence, Streaming — and Migrating the Atlas Core

> **How to read this phase.** Sections 1–10 are the taught material and were
> delivered as Parts 1–4 in the study thread; this file carries the *verifiable*
> core of them — every code claim, marked so `make check-docs` can prove it
> against the tree — followed by sections 11–19 in full. If you are studying
> alone and have only this file, you have everything the repo asserts; the
> thread adds the worked prose, the concept checks and the misconception
> callouts. Repo tag `phase-09`; contract `ATLAS_INTERFACES.md` v0.20.

---

## 0. [core] The five claims this phase makes, and where each is proved

A migration is a set of claims about behaviour. Here are Phase 9's, each with
the artifact that settles it. Read this table first; everything else is the
argument for one of these rows.

| Claim | Proved by | Measured |
|---|---|---|
| The graph and the hand-written loop behave identically | `tests/test_graph_equivalence.py` | **0** diverged fields, 8 scenarios |
| Atlas's batch atomicity survives a framework that lacks it | eval `p09-b`, graded from the filesystem | no write performed |
| Atlas's step cap fires before the framework's fuse | eval `p09-c`, `recursion_limit_for` | `step_cap` at 3 of 3 |
| Every previous test and eval still passes | `make test-offline`, `make evals` | **1,255** tests, **48** evals |
| The new mechanisms are on by default, not switches | `test_the_composition_log_runs_on_the_live_path`, `test_handle_request_routes_the_react_route_through_the_graph` | log entries ≥ 1; `checkpointer is True` |

That last row exists because the first draft of this phase failed it three
times. See F-09-05, F-09-06 and F-09-07 — they are the most instructive
entries in the phase and they are all mine.

---

## 6b. [core] The four differences, as code

Each block below is checked against the tree. §6.10 of the thread gives the
measurements; these are the mechanisms that answer them.

**Difference 1 — the framework's tool node is not atomic, so Atlas dispatches.**

```
# excerpt: atlas/graph/tools.py
def refuse_batch(
    registry: ToolRegistry, calls: Sequence[ToolCall]
) -> list[ToolMessage]:
    """Report the unknown names and run NOTHING. Invariant 24.
```

**Difference 2 — `execute()`'s guarantee is restored by making the tool inert.**

```
# excerpt: atlas/graph/tools.py
@dataclass(frozen=True)
class GraphTool:
    """A `ToolSpec` plus the wire schema, and nothing else.
```

**Difference 3 — the fuse is derived from the policy, never defaulted.**

```
# excerpt: atlas/graph/core.py
SUPERSTEPS_PER_STEP = 3
```

```
# excerpt: atlas/graph/core.py
def recursion_limit_for(max_steps: int) -> int:
    """The fuse, derived from the policy. See §6.5.
```

**Difference 4 — the stop reason is a channel, not a message.**

```
# excerpt: atlas/graph/core.py
class CoreState(TypedDict):
    """The graph's channels.
```

---

## 7b. [core] The build, as checked excerpts

**The adapter that keeps `atlas.llm` underneath the framework (D-47).**

```
# excerpt: atlas/graph/chat.py
class AtlasChatModel(BaseChatModel):
    """A `BaseChatModel` that delegates to an `atlas.llm.LLMClient`.
```

**Token streaming — and note where it delegates, because the first version of
this only worked on fixtures (F-09-06).**

```
# excerpt: atlas/graph/chat.py
    def _stream(
        self,
        messages: list[BaseMessage],
        stop: list[str] | None = None,
        run_manager: CallbackManagerForLLMRun | None = None,
        **kwargs: Any,
    ) -> Iterator[ChatGenerationChunk]:
```

```
# excerpt: atlas/llm.py
    def stream(
        self, messages: Sequence[Message], **kw: Any
    ) -> Iterator[str | Completion]:
        """Forward streaming, and METER it.
```

**The model node — and the one identifier that made streaming reachable
(F-09-02) and the composition log reachable (F-09-05).**

```
# excerpt: atlas/graph/core.py
        messages = state["messages"]
        composition.record(messages, bound.atlas_tools)
        return {"messages": [bound.invoke(messages)]}
```

**The router's one-line change, with persistence derived rather than accepted.**

```
# excerpt: atlas/flow/app.py
            trajectory = run_core(
                client,
                request,
                registry=_scoped(registry, route),
                mode="native",
```

```
# excerpt: atlas/flow/app.py
    def _thread_key() -> str:
        """The conversation identity.
```

**The lossless tool-result payload (invariant 65).**

```
# excerpt: atlas/graph/tools.py
        additional_kwargs={"atlas_tool_result": result.model_dump()},
```

---

## 8b. [core] Debug this trace — the assertion that catches it

F-09-01's bug is in the wiring, and the wiring's only serialisation is the
generated diagram. `make graph` on a healthy tree prints, verbatim:

```
graph TD;
	__start__([<p>__start__</p>]):::first
	model(model)
	decide(decide)
	tools(tools)
	__end__([<p>__end__</p>]):::last
	__start__ --> model;
	decide -.-> __end__;
	decide -. &nbsp;continue&nbsp; .-> tools;
	model --> decide;
	tools -.-> __end__;
	tools -. &nbsp;continue&nbsp; .-> model;
```

On the broken tree, `__end__` does not appear at all — no edge reaches it. That
is the whole diagnosis, from one command, before reading any code.

---

## 11. [core] Capstone increment

*If your code diverged, start again from `atlas_phase_08.zip`.*

### Resume note

Atlas's tool-using core is now a compiled `StateGraph` with a SQLite
checkpointer available, called from the hand-built router through an adapter
that preserves `run_react_agent`'s signature and its `ReactTrajectory` record.
The router, the RAG pipeline, the orchestrator, the data route and the memory
store are untouched — Phase 10 migrates those.

### What Atlas can do now

- Run its ReAct core as a graph, with all seven stop reasons intact and set in
  a state channel rather than in an assistant message.
- Resume a conversation from a checkpoint, on a thread, and reconstruct a full
  `ReactTrajectory` from state the process never ran — **losslessly**, because
  every tool message carries its `ToolResult` as structured data
  (invariant 65).
- Persist automatically whenever `build_handlers(checkpoint_path=...)` is
  configured, with the thread id **derived** as `f"{route}:{user}"` rather than
  accepted, so there is no keyword a composition layer can forget (F-09-07).
- Stream at four granularities, including token-level chunks — on **Tier A**
  via an NDJSON path on the Ollama client and on Tier F via the fixture path,
  metered through `BudgetedClient.stream` so a streamed call is not an
  unmetered side channel (F-09-06, invariant 64).
- Export its own topology (`make graph`), which is how F-09-01 is graded.
- Log what each model call was composed from **on the default path**: the
  compiled app carries `.atlas_composition_log`, written by `model_node` on
  every call, including a `missing_required` fact wired to no refusal
  (F-09-05).
- Enforce invariant 24 — batch validated as a unit — against a framework whose
  own tool node does not.

### Files touched

**Added:** `atlas/graph/messages.py`, `atlas/graph/chat.py`,
`atlas/graph/tools.py`, `atlas/graph/core.py`, `atlas/graph/middleware.py`,
`atlas/graph/adapter.py`, `scripts/export_graph.py`,
`scripts/phase09_results.py`, `tests/test_graph_core.py`,
`tests/test_graph_equivalence.py`, `tests/hidden/test_phase09_a1.py`,
`tests/hidden/test_phase09_a2.py`, `evals/tasks/phase09.json`,
`docs/phase09_core.mermaid`.

**Changed:** `atlas/llm.py` (an optional `stream` capability on
`FakeLLMClient` and on `OllamaHTTPClient`, forwarded and metered by
`BudgetedClient`), `atlas/flow/app.py` (**one identifier** — `run_react_agent`
→ `run_core` — plus `checkpoint_path` and the derived thread key), `evals/run.py` (one dispatch branch, three payload prefixes),
`tests/test_evals_harness.py` (the task count, 45 → 48), `Makefile` (a `graph`
target), `pyproject.toml` and `requirements.txt` (three pinned dependencies,
core rather than optional), `ATLAS_INTERFACES.md`, `VERSIONS.md`,
`docs/RESULTS.md`, `docs/FAILURE_LOG.md`, `docs/DECISIONS.md`.

### Interface changes

Additions are free; there are five, all listed in `ATLAS_INTERFACES.md` v0.19:
`atlas.graph.messages`, `atlas.graph.chat`, `atlas.graph.tools`,
`atlas.graph.core`, `atlas.graph.middleware`, `atlas.graph.adapter`, and one
optional method on `FakeLLMClient`.

**One behavioural change, with a migration note.** `atlas.flow.app`'s ReAct
handler now calls `atlas.graph.adapter.run_core` instead of
`atlas.agents.react.run_react_agent`.

- `run_react_agent` is **unchanged**, byte for byte, and remains the text arm's
  only engine and a supported public entry point. Direct callers need no edits.
- `run_core(mode="native")` routes to the graph; `run_core(mode="text")` routes
  to the loop. There is no `use_graph=` keyword, because invariant 58 says a
  capability the caller must remember to switch on is off in production.
- `HandlerOutcome` is unchanged, so no eval task, no Phase 5/6/7 test and no
  `docs/FAILURE_LOG.md` entry needed editing.
- `run_react_graph(mode="text")` **raises**. The framework's loop has no
  counterpart to the prompt-parsed arm, and emulating it would make the
  two-mechanism comparison measure nothing.
- Two of Atlas's dependencies are now **core** rather than optional, because
  the graph is on the router's default path and invariant 2 does not admit a
  conditional guarantee.

### Tests added

Twenty-nine, in two files. Nine are the equivalence suite: one fixture list per
scenario, both engines, seven graded fields compared. The rest cover the
translation round trip, the derived recursion limit, the fuse firing, the
guards as pure functions, bound tool order against `registry.names`, the
inertness of `GraphTool`, the text-arm refusal, token streaming, thread
persistence, the `stop_reason` reset, trajectory reconstruction from a
hand-built state, and the composition log's `missing_required`.

### Eval tasks added (+3, 45 → 48)

- `p09-a-graph-and-loop-agree-on-every-graded-field` — `engines.diverged`
  empty, plus the stop reason asserted absolutely.
- `p09-b-a-batch-with-an-unknown-name-performs-no-write` — invariant 24, graded
  from the **filesystem**, because a refused batch leaves no trace of the tool
  it did not run.
- `p09-c-end-is-reachable-and-atlas-stops-before-the-fuse` — the topology and
  the derived limit, plus `stop_reason == "step_cap"`.

### `make results` and the expected ranges

Six experiments; five are program facts and reproduce exactly, one is model
behaviour and is a range.

| experiment | measured | tier |
|---|---|---|
| `equivalence` | **0** diverged fields across 8 scenarios | F |
| `defaults` | framework: 3 continued, 1 raised, **write performed** on the mixed batch; Atlas: `bad_action`, no write | F |
| `fuse` | 5 supersteps for one round trip + final; `SUPERSTEPS_PER_STEP=3`; limits 14 (max_steps 4) and 20 (6) | F |
| `streaming` | **5** non-empty chunks with the capability, **1** without | F |
| `composition` | 68 → 261 estimated tokens; tool schemas **73.9%** of the prompt for a three-tool registry | F |
| `latency` | graph vs loop, 3 trials each — **author estimate, unmeasured**: expect the difference to be inside the model's own variance | A |

`make plan` prints the arithmetic in two parts, because `make results` is not
where this phase's Tier A budget goes:

```
  make results   Tier A calls:    24
  make evals     Tier A calls:   864  (48 tasks x 3 trials x <=6 calls)
  TOTAL          Tier A calls:   888
  header ALLOWANCE: 1200   estimate/allowance: 74.0%
```

The first draft reported only the 24 and called the 50× gap to the header "the
allowance doing its job". That was a dodge: the header's ~1,200 is the **eval
suite run at `ATLAS_TIER=A`**, which is where the migrated core actually meets
a model, and a phase that never runs it has not tested the migration against
anything but fixtures. Run `ATLAS_TIER=A make evals` once before moving on.

### Read five failing traces — `docs/FAILURE_LOG.md`

Four new entries, and one of them is invariant 41's sixth appearance:

- **F-09-01** — a conditional edge with no path to `END`, and a fuse that did
  not blow. 218 model calls. The guard fired correctly and nothing read it.
- **F-09-02** — the model node called `client.complete` instead of
  `bound.invoke`, so `_stream` was dead code with a green test beside it.
- **F-09-03** — `stop_reason` survived a checkpoint and made the next turn exit
  before its first model call.
- **F-09-04** — an eval check operator that did not exist; caught by a closed
  `Literal` rather than by a trial scoring zero.
- **F-09-05** — the composition log shipped switched off: reachable from tests
  and from nowhere on the live path, in the module whose docstring cites
  F-08-03. Invariant 41's seventh appearance.
- **F-09-06** — token streaming that only worked on fixtures, because
  `BudgetedClient` forwarded `complete` and not `stream`.
- **F-09-07** — the checkpointer was a parameter, not a capability. Invariant
  58 violated one function from the paragraph quoting it.
- **F-09-08** — a code comment citing a test that did not exist.

**These four share one shape**, and it is the phase's hardest lesson: the
wiring discipline was applied rigorously to the *framework's* defaults and not
at all to the phase's *own* new mechanisms. Hence invariant 63 — a phase audits
its own new modules by grepping every public name across `atlas/` and naming
the call site on the default path. It takes two minutes.

### Repo state

**1,255 offline tests** (from 1,220). **48 gradeable eval tasks** (from 45).
`ATLAS_INTERFACES.md` **v0.20**, with invariants 59–65 and D-47 to D-51.
Eight new `FAILURE_LOG.md` entries. Tagged `phase-09`. **Twenty assignments
outstanding.**

---

## 12. [core] Mastery checklist

You are ready to move on if you can:

- Sort a component of your own system into "infrastructure a framework should
  own" or "policy that stays mine", and defend the placement.
- Build a `StateGraph` from primitives, and explain why a channel without a
  reducer raises on two writers rather than picking one.
- Derive a recursion limit from a step cap and say why the arithmetic is not
  the identity.
- Point at the line in each engine that sets each of the seven stop reasons.
- Write a chat-model adapter over your own client and say which three of your
  invariants it preserves.
- Name the four ways the framework's tool node differs from `execute()`, and
  which of them performs a side effect.
- Explain why `SummarizationMiddleware` does not preserve invariant 55, and
  describe the channel that does.
- Set up a checkpointer and a thread, read a snapshot, walk history, and say
  which non-message channels need resetting per invocation and why.
- Pick a stream mode from what an interface needs to show.
- Debug a non-terminating graph in the order §6.14 prescribes, starting from a
  generated diagram.

---

## 13. [core] Quiz

1. The framework's default recursion limit is large. Explain why raising or
   lowering it is not the fix, in terms of what a fuse can report.
2. `CoreState.stop_reason` has no reducer. What does the runtime do if two
   nodes write it in one superstep, and why is that the behaviour Atlas wants?
3. Distinguish node-style from wrap-style middleware hooks by what each *can*
   do, and give one task that only each kind can perform.
4. A colleague says the checkpointer makes `SessionMemory` redundant. Answer
   them, and name the measurement that settles it.
5. Why is `END`-reachability asserted against a generated diagram rather than
   against the routing function?
6. Why does `tools_node` run the progress guards after dispatch when checking
   them before would be cheaper? Give two reasons.

---

## 14. [core] Coding assignments

### Assignment 1 — invariant 55 across the migration `[fast track: do this one]`

Create `atlas/graph/pin.py` so that Phase 8's guarantee survives a destructive
compaction inside a graph.

**Acceptance criteria.** `PinnedState` is a `TypedDict` with `messages` and
`pinned` channels. `extract_pins(messages)` finds durable statements using
Phase 8's free deterministic detector. `summariser_input(state)` returns the
messages the summariser is shown, and **must not contain any pinned text**.
`request_messages(state, *, token_budget=None)` returns what is actually sent,
with the pinned block **last**, under a header saying it overrides. A pinned
block that exceeds `token_budget` raises `PinOverflow` rather than dropping a
constraint. Reproduce Phase 8's measurement: 0 of 6 constraints survive a
scripted lossy summary without pins, 6 of 6 with.

**UNAIDED CORE.** The decision that `summariser_input` *excludes* the pinned
text rather than instructing the summariser to keep it, and the decision that
overflow refuses rather than truncates. Both are one line of code and the
entire content of invariant 55; an assistant will offer you a prompt that asks
nicely.

`make grade PHASE=09` runs `tests/hidden/test_phase09_a1.py`. Do not read it.

### Assignment 2 — grade the wiring `[extended]`

Create `atlas/graph/topology.py` providing `TopologyError`, `TopologyReport`
and `check_topology(app, *, expect_nodes=(), strict=False)`.

**Acceptance criteria.** `TopologyReport` is a `BaseModel` that round-trips
through `model_dump()`, carries `nodes`, `end_reachable`, `unreachable` and
`missing`, derives `ok` as a `computed_field`, and has a `render()` that names
the field it shows. `check_topology` returns a report by default and raises
`TopologyError` when `strict=True` and the graph is unhealthy. It must catch
F-09-01's graph, report an orphaned node, and accept a healthy graph silently
in strict mode.

**UNAIDED CORE.** Choosing to read `get_graph().edges` rather than parsing the
Mermaid string, and deriving `ok` instead of storing it. The first is the
difference between a report and a parser waiting to break; the second is D-15's
shape.

`make grade PHASE=09` runs `tests/hidden/test_phase09_a2.py`. Do not read it.

---

## 15. [extended] Case study — mapping a company's workflow diagram to a graph

**The scenario.** A forty-person logistics company has an eight-box diagram on
a wall describing how a customer claim is handled: *intake → classify →
pull shipment record → pull carrier terms → compute liability → **approve if
over $5,000** → draft response → **approve before sending** → send → log to
audit*. Two of the boxes are approvals by different people. One path runs
interactively while a customer waits; the same work also runs as a nightly
batch over unattended claims. Every outcome must be reconstructible for seven
years, including who approved what.

**Your task.** Produce a graph design: the state schema with reducers, the
nodes, the edges, the middleware, the persistence configuration, and an
explicit list of which boxes stay as ordinary code. Two pages maximum, plus a
Mermaid diagram. State what you would *not* build.

### Rubric (20 points)

| Criterion | Points | What a full answer does |
|---|---|---|
| Infrastructure/policy split | 4 | Sorts all eight boxes; identifies the two approvals and the liability computation as policy, and persistence, streaming and retry as infrastructure |
| Approvals as one mechanism | 3 | Recognises both approvals as one human-in-the-loop mechanism parameterised by role and threshold, not two nodes; defers the build to Phase 10 |
| State schema | 3 | Declares a channel per fact that must outlive a node; justifies each reducer; puts the audit reason in a channel, not a message |
| Interactive vs batch | 3 | One graph, two thread scopes and two durability settings; says which and why |
| Seven-year audit | 3 | Distinguishes the checkpointer (operational, resumable) from the audit store (immutable, append-only); does not conflate them |
| Restraint | 2 | Names at least two boxes that stay as plain functions; total node count under six |
| Diagram fidelity | 2 | `END` reachable from every conditional edge; the diagram matches the described design |

**Deductions.** −2 for a node per box. −2 for putting an approval decision in
an assistant message. −3 for using the checkpointer as the audit log.

---

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 10.*

**A framework standardises mechanism, never policy.** Atlas's honest inventory
came out six policy rows, three infrastructure, three mixed — which is why this
is a migration of the *core* and not of Atlas. Invariant 59 is the procedure:
for every policy you can name, find the framework's line of code deciding it,
and either accept its choice explicitly or wrap it. The way the failure arrives
in a codebase is a diff that deletes a check without a note.

**Four differences, measured.** Given `[write_note("IRREVERSIBLE"), phantom()]`
the framework's tool node **performed the write** — invariant 24, and Phase 3's
F-03-06 shipped as a default. Of Atlas's four `ErrorKind`s, two survive by
accident, a raising tool body **kills the graph**, and `write_refused` has no
concept. A routing function that never returns `END` ran a thousand-response
fixture without raising. The built-in summariser **replaces state
destructively with no notion of a protected message**, so invariant 55 does not
survive the translation unaided. Each is a defensible general policy; none is
Atlas's. Hence the framework describes tools and **Atlas dispatches them**
(D-48), through a `GraphTool` that is inert by construction — and hence D-51,
which declines `create_agent` itself and says why.

**Termination survived because a fuse is not a policy.** `SUPERSTEPS_PER_STEP
= 3`, so `recursion_limit_for(6) == 20`. A fuse is sized not to fire; a policy
is sized to fire exactly when the episode should stop and to name the reason.
`GraphRecursionError` answers "why did this end?" with "it didn't".

**The stop reason is a channel, not a message (D-49).** The framework's
call-limit middleware ends a run by appending `AIMessage("Model call limits
exceeded: run limit (3/3)")` — a fact in the answer slot, breaking invariant 11
and handing invariant 32's substring graders a fluent non-answer.

**The adapter goes under the framework, never over (D-47).** `AtlasChatModel`
wraps `atlas.llm.LLMClient`, so tier provenance, the `cached` flag, the
budget/cache ordering and `FakeLLMClient` all survive — which is how 1,255
offline tests stay green with no network.

**Three gifts, and one accident.** Usage metadata lives on the message and
therefore in the checkpoint. Forgetting to echo the asking turn is now
*unrepresentable*. State history is a record the runtime kept rather than one
Atlas wrote. And the accident: Phase 3's `seen_calls` and `seen_observations`
were loop locals; in the graph they became **pure functions of the transcript**,
so every guard survives resumption.

**Invariant 60: during a migration an improvement is indistinguishable from a
bug.** So the guards run after dispatch, matching Phase 3, and the only oracle
is an equivalence test — **0 diverged fields across 8 scenarios** — with at
least one absolute assertion beside it, because a comparison passes if both
engines are wrong.

**Invariant 61: persistence changes the lifetime of every channel, including
the ones you were thinking of as locals.** `stop_reason` survived a checkpoint
and made the next turn exit before its first model call (F-09-03). Non-message
channels are reset at the entry point; transcript-derived guards are scoped to
the run, not the thread.

**Invariant 62: a guard that fires correctly and is read by nothing is
indistinguishable from an absent guard.** F-09-01's router ignored a correctly
set `stop_reason` and no node test could fail. A `path_map` declares a
reachable set and nothing verifies `END` is in it, so the topology is asserted
against its own serialisation.

**Invariants 63–65, learned the hard way and worth more than the diffs.** This
phase shipped three of its own mechanisms switched off: a composition log
reachable only from tests, streaming present on one tier, a checkpointer that
was a keyword. **Audit your own new modules by grepping their public names
across the tree and naming the call site on the default path** (63). **A
wrapper forwards every method or it is a hole** — `BudgetedClient` forwarding
`complete` and not `stream` would have made streaming an unmetered side
channel (64). **A renderer's output format is never a parser's input
contract** — `error_kind` was scraped out of a human-readable message, so
editing that message would have changed what the eval harness graded (65).

**Two facts about what the model actually sees.** `create_agent`'s
`system_prompt` never enters state, so editing a prompt changes every replayed
request on an old thread. And `add_messages` is an upsert-by-id with deletion,
not an append: more power than Phase 8's buffer, with protection not among the
powers. Hence **state is not the request** — a snapshot showing the right
messages is compatible with the model having received the wrong prompt, which
is why the composition log is on by default and why tool schemas measured
**73.9%** of a three-tool prompt before the conversation existed.

**Phase 10 next.** Persistence is the mechanism, not a feature:
human-in-the-loop is persistence plus suspension, and `StateSnapshot.interrupts`
is the empty field waiting for it — but persistence makes replay *possible*
while invariant 37 decides what may be replayed. `ModelRequest`'s nine fields
are where the Phase 8 assembler goes, and what does not transfer is the
volatility ordering, the required-block refusal and the drop report. And
`HANDLER_TOOLS` meets subgraphs: the thread key already encodes the route
because the routes have different scoped registries, and the question is
whether that scoping is still a boundary when each route owns its own state
contract.

---

## 17. [core] Further reading

- LangChain and LangGraph 1.0 announcement, LangChain blog, October 2025 —
  the division of labour between the two libraries and the middleware
  rationale. https://www.langchain.com/blog/langchain-langgraph-1dot0
- "LangGraph 1.0 is now generally available", LangChain changelog,
  October 2025 — durable state, built-in persistence, human-in-the-loop, and
  the `langgraph.prebuilt` deprecation.
  https://changelog.langchain.com/announcements/langgraph-1-0-is-now-generally-available
- Custom middleware, LangChain documentation — node-style versus wrap-style
  hooks, `can_jump_to`, and the ordering.
  https://docs.langchain.com/oss/python/langchain/middleware/custom
- "How Middleware Lets You Customize Your Agent Harness", LangChain blog,
  2026 — which built-in middleware implements which hook, and why.
  https://www.langchain.com/blog/how-middleware-lets-you-customize-your-agent-harness
- Migrating from LangGraph v0, LangChain documentation — the
  `create_react_agent` → `create_agent` path.
  https://docs.langchain.com/oss/python/migrate/langgraph-v1
- Subgraphs, LangChain documentation — encapsulation, and the parent/subgraph
  state contract. Read before Phase 10.
  https://docs.langchain.com/oss/python/subgraphs
- Leslie G. Valiant, "A bridging model for parallel computation",
  *Communications of the ACM*, 1990 — the bulk-synchronous parallel model the
  superstep comes from. Worth twenty minutes; it explains the
  one-write-per-step rule better than any framework documentation.
- Grzegorz Malewicz et al., "Pregel: a system for large-scale graph
  processing", SIGMOD 2010 — the direct ancestor of the runtime's execution
  model, and the origin of the name in `langgraph.pregel`.
- OWASP Top 10 for LLM Applications — read LLM06 and LLM08 against §6.10's
  four differences before you deploy a graph with write tools.
  https://owasp.org/www-project-top-10-for-large-language-model-applications/

---

## 18. [core] SOLUTIONS

Emitted separately as `phase_09_solutions.md`.

---

## 19. [core] HANDOFF

`ATLAS_INTERFACES.md` (**v0.20**) and `VERSIONS.md` (Phase 9 delta, checked
2026-09-09) are inside `atlas_phase_09.zip`. The tree is committed and tagged
`phase-09`; `make test-offline` passes at **1,255** tests with no network, no
model and no `.env`; `make check-docs` verifies **12** marked blocks in this
document; and `make evals` scores **48/48** on Tier F.
