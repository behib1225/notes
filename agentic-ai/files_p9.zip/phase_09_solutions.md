# phase_09_solutions.md

Worked answers for Phase 9. Read these only after attempting the questions.

---

## Cumulative review

**CR-9.1.** The property is **whether staleness costs calls or costs a wrong
answer nobody notices**. A stale cache entry produces a *needlessly recomputed*
answer — the cost is money and latency, and discarding it silently is correct
because the recovery is automatic and complete. A stale index produces a
*ranking* over vectors from a different embedding space: the numbers are
well-formed, the ordering is meaningless, and nothing downstream can tell.
Invariant 45 states it directly. The general rule: fail loudly when the failure
mode is silent, and fail silently when the failure mode is loud.

**CR-9.2.** A page layout is invisible in one chunk of its text. An extractor
looking at a whole page can see that it was a two-column scan with interleaved
lines; a detector re-run on a 400-character chunk of the resulting text sees
prose and comes back clean. So recomputing at a hop *upgrades* damaged text to
trustworthy, which is worse than having no flag: the citation now asserts
provenance it does not have. Hence "inherited verbatim", and hence F-06-03.

**CR-9.3.** The 0.750 answerable question used a word that OCR had destroyed,
so the term was genuinely absent from the index while the question was
genuinely answerable. That makes the signal **undecidable rather than noisy**:
noise would mean the same underlying state produces a spread of values, which
more data or a better threshold could tighten. Here two *different* underlying
states — "this is not documented" and "this is documented but the text is
damaged" — produce the same value by the same mechanism. No threshold can
separate states a measurement does not distinguish. Invariant 49.

**CR-9.4.** The principle is **consequence, not confidence**. `no_rows_matched`
and `wrong_relation` block because in both cases the number returned would be
presented as an answer to a question it does not answer — a real figure
answering a question nobody asked (invariant 52). `truncated_result` degrades
the answer without falsifying it: the rows shown are correct rows. It would
join the blocking set if a downstream consumer aggregated the truncated rows
into a total, because then truncation stops being incompleteness and becomes a
wrong number.

**CR-9.5.** Invariant 41 — a mechanism is wired or it is not shipped — in its
third appearance, sharpened by invariant 53. The one-line procedure: **before
writing "X is reconciled against Y", read the call site.** Operationally, grep
the capability claim in the capstone against a test that reaches it through the
public entry point; if there is no such test, it is prose, not a capability.

---

## Concept checks

**9.1.** **Persistence.** State, control flow, streaming and middleware can all
be introduced behind an existing signature — Phase 9 proves it, since
`run_core` has `run_react_agent`'s signature. Persistence cannot, because a
persisted run needs an *identity* — a thread id — and there is nowhere to put
one in a call that did not have it. Every entry point gains a parameter, or
every entry point invents an identity, and inventing one silently is how a
system persists each request to its own thread and appears to have no memory.

**9.2.** `execute()` never raises because the error message is written **for
the model to act on**, and what counts as actionable feedback depends on what
the agent is for. A general runtime cannot know whether a locked database is a
transient condition the model should route around or a bug the operator must
see; Atlas decided the first, and that is a policy about Atlas's users.

**9.3.** State: `messages: Annotated[list[Turn], append]` and
`budget: int`. The reducer can express the *merge* — how a new turn combines
with the existing list. It **cannot express the eviction**, because eviction is
a function of the whole channel plus a budget, and a reducer sees only
`(current, update)`. That is why `select_window` is a node (or a `wrap_model_call`
hook), not a reducer: a reducer is a merge rule and a window is a selection.

**9.4.** `final` is the model's, detected in `decide_node`. `no_output` and
`bad_action`: `decide_node`. `no_progress`, `cycle`, `token_budget`,
`step_cap`: `tools_node`. The one with no natural home is **`step_cap`**, and
that is the phase's point: the framework's nearest equivalent is a recursion
limit (a fuse that reports "it didn't stop") or a call-limit middleware (which
writes the reason into an assistant message). Atlas gives it a home by
declaring a `stop_reason` channel.

**9.5.** Not 6, because a "step" of the policy is **three supersteps** of the
runtime — `model`, `decide`, `tools`. Plus the entry. So
`3 * 6 + 2 = 20`. Measured: one tool round trip followed by a final answer
takes 5 supersteps, which is consistent (`model, decide, tools, model, decide`).
The `+2` is headroom for the entry superstep and the final `decide` that exits
without a `tools` step; sizing it to exactly `3 * max_steps` would blow the
fuse on the last legitimate iteration.

**9.6.** A step counter in state fires *knowing what it is counting*: it can
set `stop_reason="step_cap"`, attach the partial trajectory, and let the eval
harness grade a labelled partial result (invariant 35). The recursion limit
fires knowing only that the runtime executed too many supersteps; it raises,
so the partial trajectory is in a traceback, and its message is "reached
without hitting a stop condition" — a report that a policy was missing rather
than a report of a policy.

**9.7.** The **framework's**, because the role is the class. `AIMessage` with
tool calls and no content is a well-typed object; there is no field to make
optional. Atlas widened `Message.content` from required to defaulted because
one class serves four roles, and the assistant-with-only-tool-calls case needs
an empty content that is distinguishable from a missing one.

**9.8.** It makes **per-node sampling parameters** impossible — a graph in
which a cheap node runs at temperature 0 and a creative node at 0.8, or a
retry that raises the temperature. Atlas does not need it: Phase 4's strategy
comparison depends on a fixed seed per episode, and a temperature that changed
mid-run would make two halves of one trajectory incomparable. When Atlas does
need it (Phase 11's model routing), the mechanism is `wrap_model_call` mutating
`request.model_settings`, not graph state.

**9.9.** *Must reimplement:* the batch pre-validation (invariant 24, and §6.10
measured the cost of not doing it); the `no_progress` and `cycle` guards (no
counterpart, and both are cheap); the seven stop reasons (invariant 11 and 32);
the token budget (the framework's unit is calls, and Phase 8 established turns
and calls are the wrong unit). *Can drop:* the text-arm parser, since the graph
core does not implement that arm at all and `run_core` routes it to the loop;
and the `ReactStep` accumulation, since the transcript plus `usage_metadata`
reconstructs it.

**9.10.** Unrepresentable: **F-03-06**'s sibling, "the assistant turn was
appended but the tool messages were not correlated" — the reducer and the
required `tool_call_id` make an uncorrelated result impossible to construct.
Not made unrepresentable: **F-03-06 itself**, the batch-atomicity bug, which
the framework's own tool node reproduces by default.

**9.11.** **Difference 4**, the summariser, is *not* caught — Atlas does not
use it, so nothing changes. The one caught immediately is **difference 2**: the
`tool_body_raises` scenario is in the equivalence set, and a graph using the
framework's tool node raises `ZeroDivisionError` out of the graph, so the test
errors rather than failing. The other two pass a green suite because
difference 1 requires a *batch* containing both a write and an unknown name
(no pre-existing test constructs one) and difference 3 requires a *routing bug*
(no pre-existing test has one). Both were added this phase.

**9.12.** *"The framework's unknown-tool error names every tool in the scoped
registry. `HANDLER_TOOLS` scopes a registry per route precisely so that a
misroute is visible rather than plausible (Phase 5), so an error string
enumerating the available tools leaks the scope into the transcript and into
the model's next decision. Atlas's `execute()` reports only the unknown name."*

**9.13.** Redaction **first**, composition log second. Before hooks run in list
order and wrap hooks nest first-outermost, so the first middleware sees the
request first. The wrong order silently logs **unredacted** text — and both
middleware pass their own tests, because each is correct about its own job.

**9.14.** `before_model` (a node-style hook returning a state update) is what
*extracts* a constraint out of a turn and writes it into the `pinned` channel,
because only a node can write state. `wrap_model_call` is what *concatenates*
the pinned block into `request.messages`, because only the request hook can
change what the model sees without changing what is stored. Neither alone
suffices: writing to state does not put the block in the prompt, and mutating
the request does not make the pin durable across a compaction that rewrites
`messages`.

**9.15.** Only **`step_cap`** could be reconstructed from `next` alone, and only
indirectly — a run stopped mid-topology with `next` non-empty is a run that ran
out of supersteps. Every other reason (`final`, `no_output`, `bad_action`,
`no_progress`, `cycle`, `token_budget`) leaves `next` empty and identical,
which is the whole argument for D-49.

**9.16.** One thread for everything: turn *n* carries every prior
conversation's transcript, so the prompt grows without bound, the step cap
counted per thread eventually refuses to answer, and one user's stray
constraint applies to an unrelated task forever. A fresh thread per request:
persistence is present and useless — no multi-turn memory, no resumption, and
a checkpoint table that grows one dead row per request.

**9.17.** Progress display: `custom`, written from inside the worker nodes with
`get_stream_writer()`, because the units the user cares about ("searching
documents", "3 of 5 workers done") are *yours* and not the runtime's. Answer:
`messages`, for token-level rendering. `custom` cannot serve the answer because
it carries no model output; `messages` cannot serve the progress display
because it reports model chunks, and a fan-out's progress is precisely the part
where no model is speaking yet.

**9.18.** Roughly **12,400 tokens plus the conversation**, since `values`
re-sends the whole state each superstep and the static prefix is present in
every snapshot. Phase 8's measurement that 90.0% of an assembled research
prompt is byte-identical to the previous request is what makes it obvious: the
same argument that made prompt caching worthwhile makes `values`-mode streaming
wasteful, and for the same reason.

**9.19.** The **state snapshot** (instrument 3). The likely cause is a
tool-call id mismatch: a result whose `tool_call_id` matches no call in the
transcript, which on Atlas's derived-from-index ids means a batch was
dispatched out of order or a result was built with the wrong index. The
snapshot shows the exact `messages` list with ids; `updates` would show the
node ran and tell you nothing about correlation.

---

## Quiz

**Q1.** Because it is a *fuse*, not a policy. It is sized so that it does not
fire in normal operation for a long-running production agent, which means for
an agent under test it does not fire until the budget is gone; and when it does
fire it raises, so the partial trajectory is in a traceback rather than in a
gradeable record. Its message reports that no stop condition was hit — the
absence of a policy, not a reason.

**Q2.** A reducer is the **permission for concurrent writes**. A channel
without one is implicitly single-writer-per-step and the runtime raises
`InvalidUpdateError` rather than picking a winner. `stop_reason` deliberately
has none: two nodes deciding why an episode ended is not a merge problem, it is
a bug, and Atlas wants the exception.

**Q3.** Node-style hooks (`before_agent`, `before_model`, `after_model`,
`after_agent`) *are graph nodes* — they appear in `draw_mermaid()`, run at
superstep boundaries, and return partial state updates. Wrap-style hooks
(`wrap_model_call`, `wrap_tool_call`) are Python wrappers inside the model or
tool node, so they can call the handler zero times (short-circuit) or several
(retry), which a node cannot do. Consequence: state updates need a node hook;
retries and request mutation need a wrap hook.

**Q4.** It replaces the **buffer**, not the memory store. A checkpointer is
scoped to a thread and answers "what happened in this conversation". Cross-
session recall — Phase 8's 7/7 — is scoped to a *user* and must outlive any
thread, which is a store. Deleting `SessionMemory` would lose that capability
and show up as a regression on exactly two eval tasks, which is a thin margin
of protection for an entire capability.

**Q5.** Because a `path_map` declares the reachable set and the framework does
not verify that the routing function can return each key, nor that `END` is
among them. So a graph with no path to `END` compiles, and the only
serialisation of the wiring is the generated diagram — hence
`assert "__end__" in app.get_graph().draw_mermaid()`, and hence invariant 62.

**Q6.** Because during a migration an improvement is indistinguishable from a
bug. The equivalence test is the only available oracle, and it compares against
the old behaviour; a version that guards *better* fails it, and you cannot tell
from the failure whether you improved something or broke something. Land
faithful, prove 0 divergences, then improve in a commit that says so (D-50).
Additionally, a comparison passes if both engines are wrong, so at least one
absolute assertion — the filesystem check that no write occurred — has to sit
beside it.

---

## Assignment 1 — `atlas/graph/pin.py` [fast track]

```python
"""Invariant 55 across the migration: pinned constraints the summariser
never sees."""

from __future__ import annotations

from typing import Annotated, Sequence, TypedDict

import operator

from langchain_core.messages import AnyMessage, HumanMessage, SystemMessage

from atlas.memory.buffer import propose_pin
from atlas.memory.tokens import estimate_tokens

PIN_HEADER = "Standing constraints (these override anything summarised above):"


class PinOverflow(RuntimeError):
    """The pinned block alone exceeds the budget.

    Phase 8, verbatim: a pinned block that overflows must REFUSE, not choose a
    constraint to violate. Dropping the sixth constraint to fit is a decision
    about which rule the user did not mean, and no code is entitled to make it.
    """


class PinnedState(TypedDict):
    messages: Annotated[list[AnyMessage], operator.add]
    pinned: Annotated[list[str], operator.add]


def extract_pins(messages: Sequence[AnyMessage]) -> list[str]:
    """Durable statements, using Phase 8's free deterministic detector."""
    pins: list[str] = []
    for message in messages:
        if not isinstance(message, HumanMessage):
            continue
        text = str(message.content)
        if propose_pin(text) is not None and text not in pins:
            pins.append(text)
    return pins


def summariser_input(state: PinnedState) -> list[AnyMessage]:
    """What the summariser is shown -- WITHOUT the pinned text.

    This is the guarantee. A prompt saying "preserve all constraints" is a
    request; a summariser that cannot see a constraint cannot lose it.
    """
    pinned = {text.strip().lower() for text in state["pinned"]}
    return [
        message
        for message in state["messages"]
        if str(message.content).strip().lower() not in pinned
    ]


def request_messages(
    state: PinnedState, *, token_budget: int | None = None
) -> list[AnyMessage]:
    """The messages actually sent: history, then the pinned block LAST."""
    pinned = list(state["pinned"])
    if not pinned:
        return list(state["messages"])
    block = PIN_HEADER + "\n" + "\n".join(f"- {text}" for text in pinned)
    if token_budget is not None and estimate_tokens(block) > token_budget:
        raise PinOverflow(
            f"pinned block is {estimate_tokens(block)} estimated tokens and the "
            f"budget is {token_budget}; refusing rather than dropping a "
            "constraint"
        )
    return [*state["messages"], HumanMessage(content=block)]
```

**Why the pinned block goes last.** It is the most recent instruction the model
reads. A constraint above a summary competes with the summary for authority;
one below it, with a header saying it overrides, does not.

**Why `pinned` is a channel and not a message.** A channel the summariser's
node does not write is a channel the summariser cannot damage. Putting the pins
in `messages` would put them in the reducer's reach, and the built-in
summariser rewrites `messages` destructively.

**Why the detector is Phase 8's.** `propose_pin` is free, deterministic and
already tested to a known precedence order. A model arm here could only
*tighten* (invariant 50) — and this assignment does not need one.

**Measured:** 0 of 6 constraints survive the scripted lossy summary with no
pins; 6 of 6 with pins; and `summariser_input` shows the summariser none of
them.

---

## Assignment 2 — `atlas/graph/topology.py` [extended]

```python
"""Grade the wiring from its own serialisation. Invariant 62."""

from __future__ import annotations

from typing import Any, Sequence

from pydantic import BaseModel, Field, computed_field


class TopologyError(RuntimeError):
    """Raised by `check_topology(..., strict=True)` on an unhealthy graph."""


class TopologyReport(BaseModel):
    """Structured data, never a string (invariant 22). Round-trips
    (invariant 31)."""

    nodes: list[str] = Field(default_factory=list)
    end_reachable: bool = False
    unreachable: list[str] = Field(default_factory=list)
    missing: list[str] = Field(default_factory=list)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def ok(self) -> bool:
        return self.end_reachable and not self.unreachable and not self.missing

    def render(self) -> str:
        return (
            f"end_reachable={self.end_reachable}  "
            f"unreachable={self.unreachable or '[]'}  "
            f"missing={self.missing or '[]'}  ok={self.ok}"
        )


def check_topology(
    app: Any, *, expect_nodes: Sequence[str] = (), strict: bool = False
) -> TopologyReport:
    drawable = app.get_graph()
    nodes = sorted(n for n in drawable.nodes if not n.startswith("__"))
    edges = list(drawable.edges)
    targets = {edge.target for edge in edges}
    sources = {edge.source for edge in edges}
    report = TopologyReport(
        nodes=nodes,
        end_reachable="__end__" in targets,
        unreachable=sorted(n for n in nodes if n not in targets),
        missing=sorted(set(expect_nodes) - set(nodes)),
    )
    if strict and not report.ok:
        raise TopologyError(report.render())
    return report
```

**Why read the edge list rather than the Mermaid string.** The string works and
the phase's own two-line test uses it, but a report has to name *which* nodes
are unreachable, and parsing a diagram for that is a parser waiting to break on
a rendering change. `drawable.edges` is the same data before serialisation.

**Why `ok` is computed and not stored.** A field the caller can set is a field
the caller can set wrongly (D-15's shape). Three facts, one derived verdict.

**Why `strict` is a parameter rather than a second function.** The report is
the useful thing in a debugging session and the exception is the useful thing in
CI, and they must not be able to disagree — one code path, two presentations.

---

## Case study rubric — worked notes

A strong answer identifies the **three approvals** as one mechanism, not three
nodes, and defers them to a human-in-the-loop middleware rather than modelling
each as an edge; recognises that the **nightly batch** and the **interactive
path** share a graph but differ in thread scope and durability setting;
declares a channel for the **audit reason** rather than writing it into a
message; and states which of the eight boxes in the company's diagram are
*policy* (and therefore stay as their code) versus *infrastructure*. A weak
answer maps each box to a node one-to-one and produces a graph with eleven
nodes, three of which are logging.


---

## Appendix — three corrections to the first cut of this phase

Kept rather than silently fixed, because the corrections teach more than the
original text did.

**The checkpointer was a keyword, not a capability.** Assignment-style
question: `run_react_graph(checkpointer=None)` is a perfectly ordinary Python
default. Why is it a defect? Because the *capstone claimed* persistence, and
`flow/app.py` never passed one — so the claim described a parameter rather
than a behaviour. Invariant 58 is not about keywords being bad; it is about the
default path. The fix derives the thread id (`f"{route}:{user}"`) instead of
accepting it, which removes the keyword entirely from the composition layer.

**Why the route belongs in the thread id.** Because `HANDLER_TOOLS` scopes a
registry per route. One thread shared across routes would replay a
`tool_action` transcript into a `chat` turn whose registry has no tools, and
the model would read tool calls it can no longer make — a prompt that teaches
the model an action space it does not have.

**Why the tool result travels as structured data.** The first version
recovered `error_kind` by scraping `"ERROR (kind): "` out of
`as_observation()`'s output. Two failures: editing a message written for a
human silently changes what the eval harness grades, and `elapsed_s` and
`truncated` were lost with no note. The text fallback is kept only for
messages that entered state some other way — injected by `update_state`, or
replayed from a checkpoint written before the field existed — and it has its
own test, because a fallback that can never fire is dead code (invariant 41).
