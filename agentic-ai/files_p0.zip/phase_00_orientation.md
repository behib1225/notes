# Phase 0 — Orientation, Prerequisite Self-Test, Environment Setup, Working With a Coding Assistant, and How to Study This Book

> **Document status.** This file is assembled in three parts. **Part 1 (sections 1–6) is below.** Part 2 adds sections 7–10 (hands-on build, the broken trace, pitfalls, industry perspective). Part 3 adds sections 11–17 (capstone increment, mastery checklist, quiz, coding assignments, summary, further reading) and the section 19 handoff. Section 18, the worked solutions, ships as a separate document, `phase_00_solutions.md`.

---

## 1. [core] Phase 0: Orientation and Setup

| Field | Value |
|---|---|
| Study hours | 4.0 read / 4.0 build / 2.0 assess (**10.0 total**) |
| Compute time (baseline laptop) | ≈ 15 min of local model time, plus one model download (size: see `VERSIONS.md`) |
| Tier A calls per full eval sweep | 3 (one discarded warm-up + two measured) |
| Tier H calls | ≤ 6 (phase cap: 100 calls / 200K tokens — see `VERSIONS.md`) |
| Cost | $0.00 (Appendix B excluded) |
| Repo tag | `phase-00` |

This is a light phase. Nothing here is conceptually hard; the point is that after these ten hours you have a working machine, a working repo, an honest map of your own gaps, and a study method. Every later phase assumes all four.

A note on that ten. An earlier draft of this phase claimed seven, and it was wrong in the exact way §6.6 warns about: I counted the work I could do quickly rather than the work a student does for the first time. Reading fifteen thousand words of technical prose with code is two to three hours on its own; installing a runner, pulling a multi-gigabyte model, and writing two small modules is not four. If you finish faster, good — record your real time, because §6.6 asks you to recalibrate the whole book against it after Phase 3.

---

## 2. [core] Cumulative review

From Phase 3 onward, this section asks five short questions drawn from the phases two and three back — Phase 5 quizzes you on Phases 2 and 3, Phase 9 on Phases 6 and 7. The mechanism exists because *spaced retrieval* beats rereading: recalling a fact after you have partly forgotten it is what moves it into durable memory, and rereading feels productive while doing much less. Answers live in the separate solutions document, `phase_00_solutions.md`, and you should attempt all five before you open it.

There are no earlier phases yet, so this once the five questions probe the background the book assumes you already have. Write your answers down; you will compare them to the solutions file, and the gaps tell you which Appendix A section to read first.

1. In one sentence each, distinguish a *token*, a *context window*, and a *sampling temperature*.
2. An LLM is called twice with identical input text and `temperature=0`. Name two mechanisms that can still make the two outputs differ.
3. What does `await` do to the coroutine that executes it, and what does it *not* do to the rest of the program?
4. In Python, what is the difference between a function that returns a `dict` and a function that returns a Pydantic model instance, from the caller's point of view?
5. You have `orders(id, customer_id, total)` and `customers(id, name)`. Write the SQL that lists customer names with their order totals, including customers who have never ordered.

---

## 3. [core] Why this phase matters

An agent is a program that decides what to do next. That single property is what makes agentic engineering different from the LLM work you have probably already done. When you write a prompt and read the answer, you own the control flow: you decide what happens, and the model only supplies text. When you build an agent, you hand part of the control flow to a model whose behaviour is stochastic, whose failures are fluent and plausible, and whose mistakes compound across steps. A 90%-reliable step is fine on its own; chained ten times unguarded it produces a correct trajectory about a third of the time. Nearly everything in this book — schemas, budgets, guardrails, checkpoints, evals, traces — exists to keep that compounding under control.

Hence the gap between demos and systems. A demo agent is thirty lines and a good screenshot. A system agent has a typed tool interface, a token budget, a retry policy, an approval gate on anything irreversible, an eval suite that catches regressions, and a trace you can read when a customer complains. The demo takes an afternoon. The system is the job.

The job titles vary and overlap. An **agent engineer** builds the loop, the tools and the evals. An **applied AI engineer** owns a product surface end to end — retrieval quality, prompt assembly, latency, and the fallbacks when the model is wrong. An **AI platform engineer** owns the substrate: gateways, tracing, sandboxes, credential scoping, cost controls. In interviews these roles converge on four probes. Can you explain, without notes, what your agent does on each iteration and where it can stall? Can you show an evaluation that would have caught a regression you introduced? Can you say what happens when a tool call returns garbage, when the model invents a tool, when the same query arrives 200 times an hour? Can you trace a prompt-injection path from a retrieved document to a side effect? Candidates who have only built demos answer with adjectives; candidates who have debugged a loop answer with mechanisms.

Now the honest side. Agentic systems today are useful for bounded, checkable, retry-tolerant work: research and summarization over your own documents, drafting, triage and routing, structured extraction, and code changes a human reviews. They remain unreliable for long-horizon autonomous work where every step must be right and nobody checks. Published agent benchmark numbers are measured on narrow task distributions that rarely resemble your workload, so treat any score as evidence about that benchmark and nothing else. In this book every model-behaviour claim carries the tier, model and seed that produced it, and the unmeasured ones say so. You will be doing the measuring.

> **Misconception:** "Agentic AI is a new model capability." It is mostly a *systems* discipline. Better models raise the ceiling on what a loop can accomplish; they do not supply the loop, the tool contracts, the budget, the approval gate, or the evaluation. Those you write.

---

## 4. [core] Learning objectives

By the end of Phase 0 you will be able to:

1. **Describe** the arc of Phases 0–16 and state, for any phase, which earlier phase it depends on and why.
2. **Explain** what lives in Appendix F and why it was moved out of the core, and name two Appendix F builds you personally want to come back for.
3. **Choose** a track (fast, standard, extended) and defend the choice against your real weekly hours.
4. **Score** yourself on a 12-question prerequisite self-test and map every miss to a specific Appendix A section.
5. **Install and verify** Python 3.11+, a virtual environment, a local model runner, the Atlas repo skeleton, and one coding assistant.
6. **Make the same logical call three ways** — raw HTTP, the vendor client, and an OpenAI-compatible client — and explain which one you would put in production code and why.
7. **Run** `hello-model` and report tokens/sec and end-to-end latency for Tier A and Tier H.
8. **Distinguish** the four tiers (A, H, F, B) by cost, determinism, and permitted use, and state why the test suite may never assert on model output.
9. **Instantiate** `FakeLLMClient` against a scripted fixture and explain in one paragraph what that test does and does not prove.
10. **State** your own rules of engagement for a coding assistant, and identify one task in this phase that is safe to delegate and one that is not.
11. **Run** `make test-offline` and `make grade` on a fresh clone and interpret the output.

---

## 5. [core] Prerequisites & quick recap

I assume you can write ordinary Python — classes, comprehensions, decorators, context managers, exceptions, `pytest`-free scripts — and that you know what a neural network is, what training and inference are, and roughly how a transformer language model turns tokens into a distribution over next tokens. I will not re-teach any of that. I also assume you have used an LLM through a chat interface and have some feel for what prompting does.

I assume you may be shaky on eight things that this book uses constantly but that a typical ML curriculum skips: **asyncio** (concurrency without threads), **Pydantic v2** (runtime-validated data classes), **pytest** (test discovery, fixtures, parametrization), **SQL joins** (from Phase 7), **Docker basics** (from Phase 14), **JSON Schema** (from Phase 1, because it is how you describe a tool to a model), **HTTP and SSE** (streaming responses; Phase 16), and **Git** (from right now). Each gets a two-paragraph orientation at first need, plus a full primer in Appendix A:

| Gap | Appendix A section |
|---|---|
| asyncio | A.1 |
| Pydantic v2 | A.2 |
| pytest | A.3 |
| SQL and SQLite | A.4 |
| Docker | A.5 |
| JSON Schema | A.6 |
| HTTP, SSE, and streaming | A.7 |
| Windows and WSL | A.8 |
| Git for solo projects | A.9 |

The 12-question self-test that tells you which of these you actually need is in section 7 of this phase, immediately before environment setup. Take it cold, before installing anything. A miss is not a failure; it is a reading assignment of about forty minutes.

One recap that matters for Phase 1: a chat model's input is a *list of messages*, each with a role (`system`, `user`, `assistant`, and, once tools appear, `tool`), and its output is one message. Everything an agent does is a transformation on that list. Memory, retrieval, planning, and guardrails are all, mechanically, decisions about what goes into the list and what to do with what comes out.

---

## 6. [core] Core concepts

### 6.1 [core] What an agent is, precisely

**Intuition.** Think of a junior research assistant with a phone, a filing cabinet, and a standing instruction. You give them a question. They decide whether to look in the cabinet, phone someone, do arithmetic on paper, or answer from memory; they look at what came back; they decide again; eventually they hand you an answer with sources. You never told them the order of those steps. That is the whole idea.

**Precise definition.** An **agent** is a program in which a language model, called repeatedly in a loop, selects the next action from a fixed set of **tools** until a stopping condition is met. Four parts, each of which gets its own vocabulary:

The **environment** is everything the agent can affect or observe that is not the model: your documents, a database, an HTTP API, the filesystem, a clock. A **tool** is a named, documented, machine-callable function exposed to the model, described by a schema so the model knows the name, the arguments, and their types. The **loop** (also called the control flow) is your code: it sends messages to the model, parses the reply, dispatches any requested tool call, appends the result, and repeats or halts. The **trajectory** is the resulting sequence of messages, tool calls, and tool results for one task — the thing you read when something goes wrong, and the unit that evals score.

Two consequences follow immediately, and they shape the whole book. First, the model never touches your environment; your dispatcher does. Everything you will later call a guardrail, an approval gate, or a credential scope lives in the dispatcher, because that is the only place with real authority. Second, the loop is ordinary deterministic software with one stochastic subroutine. You can and must test the deterministic parts.

> **Concept check 6.1.** Your agent is asked "what were Q3 travel expenses?", calls a SQL tool, gets a table back, and answers with the correct number. Which parts of that were the model's decisions and which were yours?

> **Misconception:** "The model executes the tool." It does not. It emits a structured request — a name and arguments as text. Your code decides whether to honour it, with what credentials, and what to send back. Forgetting this is the root of most agent security incidents.

### 6.2 [core] The Atlas story

The capstone you build across the book is **Atlas**, a Research & Operations Assistant for a small fictional company: a 60-person industrial-parts distributor with a shared document folder, an operational SQLite database, and a support team that answers the same twenty questions a week.

By Phase 3 Atlas answers questions in a loop with a calculator and a clock, and is scored by an eval harness. By Phase 6 it answers from the company's own documents with citations, and refuses when the documents do not support an answer. By Phase 8 it queries the database read-only and searches the web. By Phase 11 it remembers who you are between sessions. By Phase 13 it plans multi-step research by fanning work out to workers and asks a human before anything irreversible. By Phase 15 it exposes its own tools over MCP, consumes someone else's, and acts on your behalf with scoped credentials rather than a god-mode key. By Phase 16 it is a containerized FastAPI service with end-to-end traces and a 45-task eval suite. It stays small on purpose: roughly the size a competent engineer could maintain alone, which is exactly the size that fits in an interview conversation and on a résumé.

### 6.3 [core] Roadmap: Phases 0–16

**Phase 0 — Orientation and setup (this phase).** Course map, tracks, prerequisite self-test, environment, the four tiers, coding-assistant rules, study method. You end with a repo skeleton, `atlas/config.py`, a Makefile, a smoke test, and the first `ATLAS_INTERFACES.md` and `VERSIONS.md`.

**Phase 1 — The model as a component.** Structured output: JSON validated against a schema, with retries on malformed output, plus token, latency and cost accounting per call. JSON Schema and Pydantic v2 become load-bearing here.

**Phase 2 — Tools and function calling.** Describe a function as a schema, parse the model's call request, dispatch it, feed the result back. Atlas gets a calculator and a clock, and you meet the failure modes that never go away: invented tool names, wrong argument types, plausible arguments that are semantic nonsense.

**Phase 3 — The agent loop and the eval harness.** The pieces become a loop with a step budget and a stop condition; then, before any new capability, you build the eval harness that every later phase extends by three tasks, and start `docs/FAILURE_LOG.md` by reading five failing trajectories. The hinge of the book: after it you can measure, so after it you can improve.

**Phase 4 — Context engineering.** The context window is a budget, not a container. Prompt assembly, trimming and summarizing history, ordering effects, progressive disclosure, and the "skill" pattern of packaging instructions as retrievable units. Atlas gets a context budget it cannot exceed.

**Phase 5 — Retrieval I: index and retrieve.** A seeded generator builds the company corpus; you chunk, embed, store vectors, and test the retrieval math — cosine similarity, top-*k*, a hybrid keyword score — against hand-written fixtures, making retrieval quality measurable rather than a vibe.

**Phase 6 — Retrieval II: cite, ground, refuse.** Returning passages is easy; *traceable* answers are the product. Citation spans, reranking, a grounding check, and an explicit refusal path for unsupported questions. The evals here test citation correctness, not prose quality.

**Phase 7 — Structured data: read-only SQL.** Numeric questions over SQLite through a strictly read-only, schema-scoped path — plus why "let the model write arbitrary SQL" is a decision with a blast radius. The full text-to-SQL agent is deferred to Appendix F.

**Phase 8 — More tools, and tool errors at scale.** Web search, jailed file I/O, a calendar. With five tools instead of two, selection errors appear, descriptions compete, and error handling must become uniform. You build a small registry; the many-tools version is deferred to Appendix F.

**Phase 9 — LangGraph fundamentals.** The first framework, and the first import of LangGraph. You re-express Atlas's loop as an explicit state graph with typed state, nodes, conditional edges and checkpoints, weighing what a framework buys (persistence, resumability, streaming, inspectability) against what it costs (indirection, version churn).

**Phase 10 — `create_agent` and middleware.** LangChain's prebuilt constructor plus middleware for the cross-cutting concerns you hand-rolled — retries, trimming, logging. Atlas moves onto it, and you diff the behaviour against your framework-free version using the eval suite you already own.

**Phase 11 — Memory across sessions.** Short-term state (the checkpointed thread) versus a long-term store (facts that outlive a thread). A user profile, a session summary, a retrieval policy — then the two hard parts: what to write, and when to stop trusting what you wrote.

**Phase 12 — Planning and orchestrator-workers.** For a multi-part research question one loop is the wrong shape. An orchestrator decomposes, fans out to independent workers, and synthesizes — and you learn where that helps, where it multiplies cost for nothing, and how partial failure is handled. Time travel and map-reduce are deferred to Appendix F.

**Phase 13 — Human in the loop.** Some actions are irreversible. Interrupts that pause a run, surface a proposed action, and resume with an approval, rejection or edit. Phase 9's checkpointing pays off here, and you decide what "risky" means as policy rather than vibes.

**Phase 14 — Guardrails and sandboxing.** Input and output filters, prompt-injection defence for retrieved content, jailed file access, sandboxed code execution in a container. You read the OWASP guidance and attack your own agent. CodeAct is deferred to Appendix F.

**Phase 15 — MCP and acting on behalf of a user.** Expose Atlas's tools as an MCP server, consume an external one, then narrow the credentials: per-user scopes with an explicit permission model, so "the agent did it" is always answerable with "as whom, and allowed to?".

**Phase 16 — Production.** Atlas becomes a containerized FastAPI service with streaming responses, structured logs, end-to-end tracing, and the full eval suite in CI. You finish with a demo you can run in front of someone and a written account of the failure modes you know about.

### 6.4 [core] Appendices A–F

**Appendix A — Prerequisite primers.** Nine self-contained primers: asyncio, Pydantic v2, pytest, SQL/SQLite, Docker, JSON Schema, HTTP/SSE, Windows and WSL, and Git for solo projects — each written for someone who can program but has never had a reason to learn this particular thing. The self-test in §7.1 tells you which to read.

**Appendix B — Tier B: paid models.** The only place in the book that spends money. It covers when a frontier model is genuinely the only way to see an effect, how to cap spend before you make a call, and it contains recorded transcripts so that you can read the result of every Tier B exercise without paying for it. Nothing in the core track requires this appendix.

**Appendix C — Reference.** The stable reference material you will look up rather than read: the full `ATLAS_INTERFACES.md` history, every config key, every Makefile target, the eval task file format, and the fixture conventions.

**Appendix D — Operations and troubleshooting.** For when your machine, not your code, is the problem: the runner will not start, RAM is exhausted, the cache is stale, a test is flaky, Docker will not mount a volume, traces are empty.

**Appendix E — Reading list and how to read papers.** An annotated, dated bibliography of the primary sources behind each phase, plus the 30-minute paper protocol from section 7 worked through on one specific paper.

**Appendix F — Deferred topics.** Several substantial builds were deliberately moved out of the core so the core stays finishable in four to five months by someone working ten hours a week. Each Appendix F section is self-contained, states which phase tag it plugs into, and lives on its own branch off that tag: **CodeAct** (agents that write and run code instead of calling tools, off Phase 14), the **full text-to-SQL agent** (schema linking, repair loops, off Phase 7), the **many-tools registry** (dynamic tool retrieval when you have hundreds, off Phase 8), **time travel and map-reduce** in LangGraph (off Phase 12), the **multi-agent supervisor** (off Phase 12), **simulated users and online evaluation** (off Phase 3), the **browser tool** (off Phase 8), the **second-framework port** (off Phase 10), and the **full interview bank**. Read any of them when your curiosity or a job description demands it; none is a prerequisite for anything in the core.

> **Misconception:** "Deferred means unimportant." Two of these — the multi-agent supervisor and CodeAct — are among the most-discussed patterns in the field. They are deferred because they are *large*, and because building them badly teaches less than building the core well. Skipping them costs you nothing until you need them, at which point Appendix F is three hours, not three weeks.

### 6.5 [core] Phase dependency map

```mermaid
graph LR
  P0[0 Setup] --> P1[1 Model as component]
  P1 --> P2[2 Tools]
  P2 --> P3[3 Loop + EVALS]
  P3 --> P4[4 Context eng.]
  P3 --> P5[5 Retrieval I]
  P5 --> P6[6 Retrieval II]
  P3 --> P7[7 Read-only SQL]
  P3 --> P8[8 More tools]
  P4 --> P9
  P6 --> P9
  P7 --> P9
  P8 --> P9[9 LangGraph]
  P9 --> P10[10 create_agent]
  P10 --> P11[11 Memory]
  P10 --> P12[12 Planning/fan-out]
  P9 --> P13[13 Human in the loop]
  P8 --> P14[14 Guardrails]
  P13 --> P14
  P10 --> P15[15 MCP + auth]
  P11 --> P16
  P12 --> P16
  P14 --> P16
  P15 --> P16[16 Production]
```

Read the arrows as "you will be confused without this", not as bureaucracy. Three things are worth noticing. Phase 3 is a bottleneck: everything after it assumes you can measure. Phases 5–8 are four largely independent capabilities hanging off Phase 3, so a student in a hurry can do 5 and 6 and skip 7 or 8 for now (the eval suite will simply have fewer tasks). And Phase 9 is a join point — LangGraph is introduced only once you have felt the need for it, which is the only order in which a framework teaches you anything.

> **Concept check 6.5.** Why is the eval harness built in Phase 3 rather than Phase 16, when the suite is only complete at Phase 16?

### 6.6 [core] Tracks, and honest arithmetic

Every section is tagged `[core]` or `[extended]`. Core sections never depend on extended ones, so the fast track is a real path, not a mutilated one.

| Track | What you do | Planned hours |
|---|---|---|
| **Fast** | `[core]` sections only; one assignment per phase (the one marked "fast track: do this one"); no case studies | ≈ 125 h |
| **Standard** | Everything `[core]`, both assignments, the case studies where a phase has one | ≈ 195 h planned, **≈ 225 h budgeted** |
| **Extended** | Standard plus every `[extended]` section, the industry perspectives, and two Appendix F builds of your choice | ≈ 265 h |

The two numbers for the standard track are the whole point of this subsection. 195 hours is the sum of the per-phase estimates. 225 is what I suggest you put in your calendar, because the difference — about 15% — is the debugging that estimates never contain: the model that will not pull, the flaky test, the day you re-read Phase 5 because Phase 6 exposed that you did not understand it. Plan the 195 and budget the 225.

At 10–12 hours a week the standard track takes **four to five months**. At 5 hours a week it takes most of a year, which is a legitimate choice if you are honest about it up front rather than discovering it in month three. Below about 4 hours a week, forgetting outruns progress and you will spend most of your time re-reading; if that is your budget, do the fast track.

These per-phase numbers are the ones to recalibrate. My Phase 0 estimate was 40% low on the first attempt; assume the later ones carry similar error in the same direction.

**Pick a track now, and write it in your lab notebook.** Not "I'll see how it goes" — that reliably becomes the extended track for two phases and then abandonment. And treat these numbers as what they are: estimates from a book that has not yet been run by a cohort, produced by an author who knows the material and therefore systematically underestimates. **Recalibrate after Phase 3.** By then you will have three phases of your own timing data; multiply the remaining estimates by your personal ratio and re-plan. That single act of arithmetic is the difference between finishing and stalling at Phase 7.

### 6.7 [core] The four tiers

Everything in this book runs at $0 outside Appendix B. That constraint is not austerity for its own sake — it is what makes the eval suite runnable as often as you like, and running your evals often is the single habit that separates people who improve their agents from people who tinker with them. Four tiers make it work.

**Tier A — local model, the default.** A quantized open-weights model served on your own laptop by a local runner with an HTTP API. Free, unlimited, private, and offline. **Every eval sweep runs on Tier A**, precisely because a sweep you can run forty times a day at zero marginal cost is a sweep you will actually run. Tier A is slower and weaker than a hosted frontier model, and that is often an advantage: a weak model fails more, and failures are what you are here to learn to handle. The specific model, its size on disk, and its context length are current-state facts and live in `VERSIONS.md`, not in this prose.

**Tier H — a free hosted API, capped and cached.** A provider with a genuinely free tier and an OpenAI-compatible endpoint, used when an exercise is uninformative on a small local model — for instance, comparing how a stronger model handles a five-step plan. Three rules. Tier H is **capped at 300 calls per phase**, because a free tier is a gift and rate limits are real. Every response is **cached to `data/cache/`** keyed by a hash of the request, so a repeated experiment costs zero calls and your results stay reproducible. And **no test may require Tier H**, so a fresh clone with no API key passes the full suite. The provider, its documented free-tier limits, and the model id are in `VERSIONS.md`.

**Tier F — `FakeLLMClient`, deterministic, no network.** A client that satisfies the same `LLMClient` interface but returns pre-written responses from **scripted fixtures** in `tests/fixtures/`. It is instantaneous, has no dependencies, and produces byte-identical output every run. Tier F is how the test suite works: `make test-offline` runs the entire suite on Tier F, on a plane, with the model runner uninstalled.

**Tier B — paid, Appendix B only.** Never required, never in the core, always accompanied by a recorded transcript.

Now the rule that surprises people, and the reason for Tier F:

> **Tests never depend on model output.**

A test asserts on what your code controls: a malformed tool call raises the right error; a schema rejects a negative quantity; the loop halts after *n* steps; the retriever ranks chunk 7 above chunk 2 for a given query and embedding matrix; the token budget holds; the refusal path fires when no passage supports the question. It never asserts that the model said something. `assert "Paris" in answer` passes today, fails next Tuesday when you bump the model, and teaches you nothing either way.

**What scripted fixtures prove, and what they don't.** A scripted fixture is a hand-written model response — text, a tool-call request, or deliberately malformed JSON — that your code processes as if it had come from a model. Passing proves that *given that input*, your parsing, validation, dispatch, error handling, budgeting and control flow do what you intended; that you handle the malformed case, because you wrote it; and that this still holds in six months, which is what makes refactoring safe. It proves **nothing** about whether a real model would produce that response, how often it produces the good one rather than the bad one, or whether your agent is any good at its job. Fixtures test the machine, not the mind.

The mind is tested by evals, and **model behaviour is data, not a test**. Each phase ships `make results`, which runs that phase's experiments on Tier A and prints ranges; the numbers land in `docs/RESULTS.md` with the tier, model, and seed that produced them. Where this book quotes a number in prose, it is quoted as an expected range and labelled "author estimate, unmeasured" unless `docs/RESULTS.md` says otherwise. When your number disagrees with mine, yours is the real one for your machine — record it and move on.

> **Concept check 6.7.** Your agent's eval score drops from 34/45 to 29/45 after you edit a system prompt, but `make test-offline` still passes 100%. Is that a bug in the tests? What does each signal tell you?

> **Misconception:** "Tier A is the toy and Tier H is the real one." Reversed, for our purposes. Tier A is where you will do 95% of your work, because it is unlimited and private. Tier H is a measuring instrument you use sparingly to check whether a limitation you found is a property of *small models* or a property of *your design*. That distinction — my agent is bad versus my model is small — is one of the most valuable diagnostic skills in the field, and you can only develop it by having both tiers.

### 6.8 [core] Hardware, in words

The baseline machine for this book is **16 GB of RAM and no GPU**. Everything works there. More RAM or a GPU makes Tier A faster; it does not unlock any content.

The arithmetic to internalize: a model's weights must fit in memory, and the memory they need is roughly *parameter count × bytes per parameter*. At full 16-bit precision that is 2 bytes per parameter, so an 8-billion-parameter model needs about 16 GB just for weights — which is your entire baseline machine. **Quantization** stores each weight in fewer bits (commonly around 4 to 5 bits on average for the standard laptop formats), cutting that to roughly half a byte to two-thirds of a byte per parameter and bringing the same 8B model down to something like 5 GB. That is why every model you will pull is a quantized build, and why the file size in `VERSIONS.md` is much smaller than the parameter count would suggest. Quantization costs some accuracy — more for very small models than for large ones — which is one more reason failures are the norm on Tier A.

Weights are not the whole bill. Generating text requires a **KV cache**: for every token in the context, the model stores intermediate values so it does not recompute them. That cache grows linearly with the number of tokens actually in context and can easily reach a gigabyte or more at long context lengths. This is why a model advertising a very large context window will happily crash a 16 GB laptop if you actually fill it: the weights fit, the cache does not. The practical consequence for us is a rule you will meet again in Phase 4 — **set the context length explicitly to what you need, not to the maximum the model supports.** A modest context that leaves the machine breathing beats a huge one that swaps to disk, because once your machine starts swapping, generation speed falls by an order of magnitude and a five-minute eval sweep becomes an hour.

Two more practical notes. Prefer a model with **native tool-calling support**: from Phase 2 onward, models without it force you to parse tool calls out of freeform prose, which is a lesson in string handling rather than in agents. And expect a **cold-start pause** of a few seconds on the first call after the runner loads the model into memory, which is why the latency you measure on call one is not the latency you should report.

### 6.9 [core] Glossary

Every term below is defined again, in context, at first use in a later phase. This is the reference copy.

- **Agent** — a program in which a model, called in a loop, selects the next action from a fixed set of tools until a stopping condition is met.
- **Tool** — a named, schema-described function the model may request; your code, not the model, executes it.
- **Environment** — everything outside the model that the agent can observe or affect: files, databases, APIs, the clock.
- **Trajectory** — the full ordered record of one task attempt: messages, tool calls, tool results, final answer.
- **Orchestration** — the code that decides what runs next, in what order, and with what inputs; the loop and everything above it.
- **State** — the data an agent carries between steps (messages so far, retrieved passages, step count, budget remaining). In Phase 9 this becomes an explicit typed object.
- **Checkpoint** — a persisted snapshot of state at a point in a run, enabling pause, resume, inspection, and human approval.
- **Guardrail** — a deterministic check on input, output, or a proposed action that can block or modify it; enforced in your code, never delegated to the model.
- **Eval** — an automated, repeatable task with a checkable success criterion, used to score agent behaviour; the suite grows from Phase 3 to about 45 tasks.
- **Trace** — the machine-readable record of one run, structured for debugging and analysis.
- **Span** — one timed, attributed unit inside a trace (a model call, a tool call, a retrieval), nestable to show causality.
- **Context engineering** — deciding what information occupies the model's limited context, in what form and order, on each call.
- **Skill** — a packaged unit of instructions (and sometimes resources) that can be loaded into context on demand rather than kept resident.
- **Progressive disclosure** — showing the model only what the current step requires, revealing more as needed, to conserve context and reduce distraction.
- **Sandbox** — an isolated execution environment with restricted filesystem, network, and time, used for running untrusted code or handling untrusted content.
- **Judge** — a model used to score another model's output against a rubric; useful, biased, and never the sole criterion for a test.
- **Fixture** — a hand-written, checked-in input or response used to make tests deterministic; scripted fixtures are how Tier F works.
- **Handle** — an opaque reference to something large or sensitive (a file, a result set) passed around instead of the content itself, so the content never enters the model's context unnecessarily.
- **Credential scope** — the precise set of actions a given credential permits, ideally narrowed per user and per task rather than shared as one all-powerful key.

### 6.10 [core] How to study alone

This subsection is method, not content, and it is the difference between finishing this book and abandoning it at Phase 7. Studying alone removes the two things a classroom supplies for free: a schedule you did not set, and someone who notices when you have stopped understanding. You have to build both yourself.

**Retrieval beats rereading, and it does not feel like it.** The finding that matters most for self-study is that trying to recall something you have partly forgotten strengthens memory far more than reading it again — and that rereading *feels* more productive while doing less. This is why the book is built as it is: the cumulative review quizzes you on material two and three phases back, at roughly the interval where you have begun to forget; the concept checks interrupt reading with a question; the quiz precedes the solutions file. **The rule that makes all of it work: write your answer down before you open the solutions.** An answer you have read is an answer you will believe you could have produced. Writing it first is the only way to find out.

**Keep a lab notebook.** One file, appended every session, with four things: date and hours worked; what you built; what broke and what the cause turned out to be; and one question you could not answer. Three minutes, four jobs. It gives you the real timing data §6.6 asks you to recalibrate against. It turns debugging into a searchable personal corpus — the second time you meet `Connection refused` you will find your own note faster than a web search. The unanswered questions become your reading list. And when an interviewer asks what went wrong in your project, you will have specifics instead of adjectives.

**Read a paper in thirty minutes.** From Phase 3 the further-reading lists include papers, and reading one front to back is usually the wrong move. A workable protocol: **five minutes** on title, abstract and figures — most papers' central claim is legible from the figures alone; **five minutes** on the introduction's last paragraph, which almost always states the contribution as a list, plus the conclusion; **ten minutes** on the method, skipping proofs, reading for the *shape* of the mechanism rather than its details; **five minutes** on the experimental setup only — what was held constant, what was varied, what the baselines were, because that is where you learn whether the result transfers to your case; **five minutes** writing three sentences in your notebook: the claim, the evidence, and what you would have to believe for it to apply to Atlas. If the paper still matters after thirty minutes, read it properly. Most will not, and thirty minutes will have told you so, which is the point.

**Keep your own `VERSIONS.md`.** Copy the one this phase ships and maintain it with your dates and your findings. When a model bump moves your eval scores in Phase 11, that file is the only way to know what changed. The habit is also the most transferable thing in this book: teams that ship LLM systems all maintain some version of it, usually after learning the hard way.

**A working session that fits the method.** Ten minutes on the cumulative review and last session's unanswered question, cold. Forty minutes reading, stopping at each concept check to answer in writing. Then build in the order the hands-on gives you, running the tests after each step rather than at the end. Ten minutes at the close on the notebook entry. A session that ends with nothing written down did not happen.

**Two failure modes to watch for in yourself.** *Tutorial drift*: reading three phases ahead because reading is easier than debugging — the signal is having opinions about LangGraph before you have written an agent loop. *Solution peeking*: opening the solutions "just to check the approach" before attempting. Both feel like studying. Neither produces the thing an interviewer tests for, which is whether you can explain a system you built.

> **Concept check 6.10.** The cumulative review asks about phases two and three back rather than the phase you just finished. Why is the longer interval more useful, and what would be lost by quizzing you immediately?

---
## 7. [core] Hands-on: from an empty machine to three working tiers

This section is a build. Do it at the keyboard, in order. Every design decision is explained where it is made, because a student who reads only the prose should still understand what the system does and why it is shaped this way.

### 7.1 [core] First: the prerequisite self-test

Take this cold, before installing anything. Twelve questions, one to three minutes each. Write your answers in your lab notebook; do not look anything up. The scoring guide follows, and full answers are in `phase_00_solutions.md`.

1. **asyncio.** What is the difference between calling `f()` and `await f()` when `f` is defined with `async def`? What does the first one return?
2. **asyncio.** You have ten independent HTTP requests. Sketch, in two lines, how you would run them concurrently in one process without threads. Name the function you would use.
3. **Pydantic v2.** Given `class Item(BaseModel): qty: int`, what happens at runtime for `Item(qty="3")`, and what happens for `Item(qty="three")`?
4. **Pydantic v2.** What does `model_dump()` do that `dict(model)` does not, and how do you get a JSON Schema out of a model class?
5. **pytest.** How does pytest decide which functions are tests? What is a fixture, and how does a test ask for one?
6. **pytest.** Write the decorator line that runs one test three times with the inputs 1, 2 and 3.
7. **SQL.** `orders` has 100 rows, `customers` has 40, and every order has a valid `customer_id`. How many rows does `SELECT * FROM customers INNER JOIN orders ON customers.id = orders.customer_id` return, and how does that change with `LEFT JOIN` if eight customers have no orders?
8. **SQL.** What does `GROUP BY` require of every column in the `SELECT` list, and what is `HAVING` for?
9. **Docker.** In one sentence each: what is an image, what is a container, and what does a volume do?
10. **JSON Schema.** Write the schema for an object with a required string `city` and an optional integer `days` that must be at least 1.
11. **HTTP/SSE.** What HTTP status means "you are being rate limited", and which response header conventionally tells you how long to wait? How does a server-sent-events response differ from an ordinary one?
12. **Git.** What does `git checkout phase-03` do to your working tree, and what happens to uncommitted changes? How would you get back to where you were?

**Scoring.** One point each; a half point if you got the idea but not the detail.

- **10–12.** You are ready. Skim Appendix A's table of contents and move on.
- **7–9.** Read the Appendix A sections matching your misses before Phase 2. You will not be blocked before then.
- **4–6.** Read the matching sections now, in this order: Pydantic v2, pytest, JSON Schema, then the rest as they come up. Budget three to four hours. This is normal for someone coming straight from coursework.
- **0–3.** Spend a week on Appendix A before Phase 1. Not because the book is hard, but because debugging an agent while also learning what a fixture is means you will not know which of the two is confusing you.

Map each miss to its section: questions 1–2 → A.1 (asyncio), 3–4 → A.2 (Pydantic v2), 5–6 → A.3 (pytest), 7–8 → A.4 (SQL), 9 → A.5 (Docker), 10 → A.6 (JSON Schema), 11 → A.7 (HTTP/SSE), 12 → A.9 (Git).

> **Concept check 7.1.** Why does this book care whether you know JSON Schema, given that you will not be writing a web API until Phase 16?

### 7.2 [core] Environment

**Python.** You need 3.11 or newer; the exact version I checked this against, and the newest stable release, are rows in `VERSIONS.md`. Anything 3.11+ works, so if your system Python already qualifies, do not fight it.

**Project and virtual environment.** Two options, and the choice does not matter much. `uv` is a fast, single-binary Python packager that creates environments and resolves dependencies in seconds; the standard-library `venv` plus `pip` is slower and universally present. Version rows for `uv` are in `VERSIONS.md`.

```bash
# option 1: uv
uv venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
uv pip install -r requirements.txt

# option 2: stdlib
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

The rule that matters more than the tool: **activate the environment in every shell before you run anything.** More than half of "it worked yesterday" reports on a project like this are an unactivated environment.

**Layout.** Create this tree now, empty where noted. It does not change for sixteen phases, which is the point — you will never wonder where something goes.

```
atlas-agent/
├── atlas/
│   ├── __init__.py
│   ├── config.py          # Phase 0
│   ├── llm.py             # Phase 0-1
│   ├── tools/             # Phase 2
│   ├── rag/               # Phase 5
│   ├── memory/            # Phase 11
│   ├── graph/             # Phase 9
│   ├── agents/            # Phase 12
│   ├── safety/            # Phase 14
│   ├── auth/              # Phase 15
│   └── api/               # Phase 16
├── tests/
│   ├── fixtures/          # scripted model responses (Tier F)
│   └── hidden/            # graded tests: run, don't read
├── evals/                 # Phase 3 onward
├── data/
│   └── cache/             # Tier H response cache
├── docs/
│   ├── RESULTS.md         # model behaviour lives here
│   └── FAILURE_LOG.md     # Phase 3 onward
├── scripts/               # hello_model.py, tier_selftest.py, check_docs.py
├── .env.example
├── .gitignore
├── pyproject.toml
├── requirements.txt
└── Makefile
```

Every directory above exists in the `phase-00` skeleton, with a one-line `__init__.py` in the packages that are still empty. Empty directories are usually noise; here they encode the map, so that when Phase 5 says "put the retriever in `atlas/rag/`" there is no ambiguity. A test asserts they are all present, so the tree in this document and the tree on your disk cannot drift.

**Secrets hygiene.** `.env` holds your Tier H key and never enters Git; `.env.example` holds the *names* of the variables with empty values and is committed. Put `.env` in `.gitignore` before you create `.env`, not after — a key that has ever been committed is a key you must rotate, because Git remembers. Three habits worth adopting permanently: never `print()` a key even while debugging, never paste a key into a chat with a coding assistant, and prefer reading configuration through one module (`atlas/config.py`) so there is exactly one place where secrets enter the process.

**Makefile targets.** Seven, stable for the whole book. `make test-offline` runs the full suite on Tier F with no network, excluding `tests/hidden`. `make grade` runs the hidden tests for this phase's assignments and prints pass/fail without showing you the bodies. `make results` measures whichever tiers you have configured and **appends dated rows to `docs/RESULTS.md`** — that write is the point, because a measurement you did not record is a measurement you will redo. `make record` captures a run to `data/`. `make evals` lists this phase's eval task definitions (the harness that runs them arrives in Phase 3). `make demo` prints tier readiness. `make check-docs` compares every code block in this tutorial marked `# file: <path>` against the file on disk and fails on any difference, which is how a sixteen-phase book stays honest about its own listings.

One subtlety that will bite you if you run the scripts by hand: `python scripts/hello_model.py` puts `scripts/` on the import path, not the repo root, so `import atlas` fails. The Makefile exports `PYTHONPATH=.` for exactly that reason, and `pip install -e .` fixes it permanently. I found this by running the script through a subprocess after it had only ever been run in a shell where `PYTHONPATH` was already set — a reminder that "it works on my machine" often means "it works in my shell".

**Git and the tags.** Initialize a repo now and commit after each phase. The companion repository carries one tag per phase — `phase-00`, `phase-01`, and so on — and this is your safety net: if your code diverges badly, `git checkout phase-05` gives you a known-good starting point for Phase 6 rather than a debugging session you did not sign up for. Diverging is not failure; it is what happens when you experiment, which you should. The tags mean experimenting is cheap.

**Windows and WSL, the short version.** Work inside WSL2, not Windows-native Python, and keep your project on the Linux filesystem (`~/atlas-agent`), not under `/mnt/c/`. Three failures account for most Windows pain in this book. First, **path-crossing slowness**: a project on `/mnt/c/...` accessed from WSL runs file operations an order of magnitude slower, which turns a fast test suite into a slow one. Second, **the localhost gap**: if the model runner is installed on Windows and your code runs in WSL, `localhost:11434` may not resolve to the runner — either install the runner inside WSL or point your host variable at the Windows host address. Third, **line endings**: Git converting LF to CRLF will make shell scripts fail with confusing errors; set `git config --global core.autocrlf input`. Full diagnosis and fixes are in **Appendix A.8**.

### 7.3 [core] The local model, and three ways to call it

Install the local runner (rows in `VERSIONS.md`), then pull the Tier A model named there:

```bash
ollama pull "$ATLAS_MODEL"     # size and exact tag: VERSIONS.md
ollama list                     # confirm it is present
```

Now the pedagogically important part. There are three ways to make the same call, and knowing all three is what lets you debug the stack instead of guessing at it.

**Way 1: raw HTTP.** The runner exposes a native HTTP endpoint. You POST a JSON body containing a model name, a list of messages, `stream: false`, and an `options` object holding sampling parameters. What comes back is a JSON object with the assistant message plus timing and token counts — `prompt_eval_count`, `eval_count`, and durations in **nanoseconds**. Learn this shape, because it is the ground truth: when a library misbehaves you will come down here to see what the server actually said.

**Way 2: the vendor client.** The runner ships its own Python package that wraps that endpoint with typed helpers. Convenient and idiomatic, and it locks your code to one runner. Install it only if you want to try this comparison (`pip install -e '.[vendor]'`; version in `VERSIONS.md`) — Atlas itself never imports it, which is the point of the comparison:

```python
# Way 2 — the vendor client. Not used by Atlas; run it once to feel the difference.
# not executed during authoring; needs a live runner
import ollama

reply = ollama.chat(
    model="<your ATLAS_MODEL>",
    messages=[{"role": "user", "content": "Reply with exactly: Atlas is awake."}],
    options={"temperature": 0.0, "seed": 7, "num_ctx": 4096},
)
print(reply["message"]["content"], reply["eval_count"], reply["eval_duration"])
```

Notice that the response keys are the same ones §7.4's parse function reads. The vendor client saves you an `httpx.post` and gives you nothing else — which is why Atlas uses raw HTTP for Tier A and keeps the dependency out of `pyproject.toml`'s default set.

**Way 3: the OpenAI-compatible endpoint.** The runner also serves an OpenAI-shaped API at a `/v1` path, which means the standard OpenAI Python client works against your laptop by pointing `base_url` at it and passing a dummy API key (required by the client, ignored by the server).

**Why the OpenAI shape matters, and it is not fashion.** It is the de facto interchange format: your local runner speaks it, and so does essentially every hosted provider with a free tier, including the Tier H provider in `VERSIONS.md`. That means **one client class serves Tier A and Tier H** — the difference is a base URL and a key. Portability is bought with one indirection instead of two implementations. Two caveats you should know now rather than discover in Phase 2. Compatibility is *partial*: the runner's compatibility page lists exactly which request fields it honours and which it ignores, and at least one field that matters for forcing a tool call is on the unsupported list — the current list is a row in `VERSIONS.md`, and you should read the page yourself before relying on any field. And each surface has its own **dialect**: the native endpoint puts sampling parameters inside an `options` object and caps output with `num_predict`, while the OpenAI shape puts them at the top level and calls the cap `max_tokens` — and has no field for context length at all. That dialect gap is why `OllamaHTTPClient.build_body` and `OpenAICompatClient.build_body` exist as separate pure functions, and why two tests in §7.6 assert on their differences.

**Seeds, temperature, and why output still varies.** Set `temperature: 0` to make sampling greedy — always take the highest-probability token — and set an integer `seed` so that any remaining sampling is reproducible. Both are supported on the native endpoint and the OpenAI shape. And yet identical inputs can still produce different outputs, for reasons that have nothing to do with your code: floating-point addition is not associative, so a change in batching or thread count changes low-order bits and occasionally flips which token was "highest"; a different quantization build, runner version, or hardware backend changes the arithmetic; and on hosted providers you have no control over any of that, or over which replica served you. **Determinism is a goal you approach, not a property you switch on.** This is the single most important reason the test suite runs on Tier F.

> **Misconception:** "`temperature=0` makes the model deterministic." It makes *sampling* deterministic. Everything below sampling — kernels, batching, precision, model build — can still move, and on a hosted endpoint you cannot see any of it. Design tests that do not care.

### 7.4 [core] The seam: `atlas/llm.py`

Here is the first real code in the book, and the most important architectural decision in it. Everything in Atlas that needs a model goes through one interface. The rest of the system never learns which tier answered.

Two design choices deserve explanation.

**Choice 1: transport and parsing are separate.** Each network client is a thin shell that does I/O and hands the raw payload to a *pure* function — `parse_ollama_chat`, `parse_openai_chat` — that takes a dict and returns a `Completion`. Pure means no network, no clock, no globals: same input, same output, always. This is what makes the test suite offline. The risky, format-sensitive logic (Where is the text? What if `choices` is empty? How do I convert nanoseconds to tokens per second?) is exactly the logic that is fully testable against a recorded fixture, and the untestable part shrinks to one `httpx.post` call.

**Choice 2: `Completion` is normalised.** Every tier returns the same object — text, model, tier, tool calls, token usage, latency, tokens per second, and the raw payload for debugging. Callers never branch on tier. When Phase 4 needs a token budget it reads `usage`; when Phase 16 needs a trace span it reads `latency_s`; neither needs to know that one provider reports nanoseconds and another reports nothing at all.

**Choice 3: `tool_calls` and `ToolCall` exist now, two phases before anything uses them.** Atlas has no tools until Phase 2, and an empty list is dead weight until then. It is here anyway, because of an asymmetry worth internalising: **adding a field to an interface is free, and changing one is not.** `ATLAS_INTERFACES.md` freezes these names, so a `Completion` without `tool_calls` would force Phase 2 to make a breaking change to the contract Phase 0 exists to establish. The same reasoning makes `FakeLLMClient` accept `str | dict` rather than just `str`: from Phase 2 you will script tool calls, and `["some text", {"tool_calls": [...]}]` needs no signature change.

The tool-call normalisation also earns its keep immediately, because the two providers disagree. Ollama returns `arguments` as a **JSON object**; the OpenAI shape returns it as a **JSON string** that you must parse — and returns `content: null` rather than `""` when the model only asked for a tool. `_coerce_arguments` absorbs both, and when the JSON is malformed it preserves the raw text under `__unparsed__` instead of discarding it, because in Phase 2 that raw text is your only evidence of what the model actually tried to say. Three tests in §7.6 pin this down, including one asserting that both providers normalise to the *same* `ToolCall`.

> **Misconception:** "Design for what you need now; add fields when you need them." Right for private code, wrong at a published interface. The cost of a field nobody reads is a line of code; the cost of changing a frozen signature is every caller, every test, and a migration note in a later phase.

```python
# excerpt: atlas/llm.py
Role = Literal["system", "user", "assistant", "tool"]
Tier = Literal["A", "H", "F", "B"]


class Message(BaseModel):
    """One turn of a conversation. The unit every agent manipulates."""

    role: Role
    content: str


class ToolCall(BaseModel):
    """A model's *request* to call a tool. Your code decides whether to honour it.

    Present from Phase 0 even though Atlas has no tools until Phase 2: adding a
    field later is free, but changing a frozen interface is not.
    """

    name: str
    arguments: dict[str, Any] = Field(default_factory=dict)
    id: str | None = None


class Usage(BaseModel):
    """Token accounting for a single call."""

    prompt_tokens: int = 0
    completion_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        return self.prompt_tokens + self.completion_tokens


class Completion(BaseModel):
    """The result of one model call, normalised across tiers."""

    text: str
    model: str
    tier: Tier
    tool_calls: list[ToolCall] = Field(default_factory=list)
    usage: Usage = Field(default_factory=Usage)
    latency_s: float = 0.0
    tokens_per_s: float | None = None
    raw: dict[str, Any] = Field(default_factory=dict)


class FixtureExhausted(RuntimeError):
    """Raised when a FakeLLMClient is called more times than it has answers."""


class BudgetExceeded(RuntimeError):
    """Raised when a tier's call or token budget for this phase is spent."""


class LLMClient(Protocol):
    """What the rest of Atlas is allowed to know about a model."""

    tier: Tier
    model: str

    def complete(
        self,
        messages: Sequence[Message],
        *,
        temperature: float = 0.0,
        max_tokens: int | None = None,
        seed: int | None = None,
        stop: Sequence[str] | None = None,
    ) -> Completion: ...


def _coerce_arguments(raw: Any) -> dict[str, Any]:
    """Tool arguments arrive as a dict (Ollama) or a JSON string (OpenAI).

    Normalising here means no caller ever has to know which provider it is
    talking to -- the whole point of the seam.
    """
    if isinstance(raw, dict):
        return raw
    if isinstance(raw, str) and raw.strip():
        try:
            parsed = json.loads(raw)
        except json.JSONDecodeError:
            return {"__unparsed__": raw}
        return parsed if isinstance(parsed, dict) else {"__value__": parsed}
    return {}


def parse_ollama_chat(
    payload: dict[str, Any], latency_s: float, *, tier: Tier = "A"
) -> Completion:
    """Turn an Ollama /api/chat response body into a Completion.

    Pure: no network, no clock, no globals. Ollama reports durations in
    nanoseconds, so generation speed is eval_count / (eval_duration / 1e9).
    """
    message = payload.get("message") or {}
    eval_count = payload.get("eval_count") or 0
    eval_duration_ns = payload.get("eval_duration") or 0
    tps: float | None = None
    if eval_count and eval_duration_ns:
        tps = eval_count / (eval_duration_ns / 1e9)
    calls = [
        ToolCall(
            name=(c.get("function") or {}).get("name", ""),
            arguments=_coerce_arguments((c.get("function") or {}).get("arguments")),
            id=c.get("id"),
        )
        for c in (message.get("tool_calls") or [])
    ]
    return Completion(
        text=message.get("content") or "",
        model=payload.get("model", "unknown"),
        tier=tier,
        tool_calls=calls,
        usage=Usage(
            prompt_tokens=payload.get("prompt_eval_count") or 0,
            completion_tokens=eval_count,
        ),
        latency_s=latency_s,
        tokens_per_s=tps,
        raw=payload,
    )


def parse_openai_chat(
    payload: dict[str, Any], latency_s: float, *, tier: Tier = "H"
) -> Completion:
    """Turn an OpenAI-compatible /v1/chat/completions body into a Completion."""
    choices = payload.get("choices") or []
    if not choices:
        raise ValueError("OpenAI-compatible response contained no choices")
    message = choices[0].get("message") or {}
    usage_raw = payload.get("usage") or {}
    completion_tokens = usage_raw.get("completion_tokens") or 0
    tps = completion_tokens / latency_s if completion_tokens and latency_s else None
    calls = [
        ToolCall(
            name=(c.get("function") or {}).get("name", ""),
            arguments=_coerce_arguments((c.get("function") or {}).get("arguments")),
            id=c.get("id"),
        )
        for c in (message.get("tool_calls") or [])
    ]
    return Completion(
        text=message.get("content") or "",
        model=payload.get("model", "unknown"),
        tier=tier,
        tool_calls=calls,
        usage=Usage(
            prompt_tokens=usage_raw.get("prompt_tokens") or 0,
            completion_tokens=completion_tokens,
        ),
        latency_s=latency_s,
        tokens_per_s=tps,
        raw=payload,
    )


class FakeLLMClient:
    """Tier F. Replays scripted fixtures in order. Deterministic, offline.

    A scripted response is either a string (plain text) or a dict, which may
    carry ``text`` and/or ``tool_calls``. Accepting both from Phase 0 means
    Phase 2 can script tool calls without changing this signature.
    """

    tier: Tier = "F"

    def __init__(
        self, responses: Sequence[str | dict[str, Any]], *, model: str = "fake"
    ) -> None:
        self.model = model
        self._responses = list(responses)
        self._index = 0
        self.calls: list[list[Message]] = []

    def complete(
        self,
        messages: Sequence[Message],
        *,
        temperature: float = 0.0,
        max_tokens: int | None = None,
        seed: int | None = None,
        stop: Sequence[str] | None = None,
    ) -> Completion:
        self.calls.append([Message.model_validate(m) for m in messages])
        if self._index >= len(self._responses):
            raise FixtureExhausted(
                f"fixture had {len(self._responses)} response(s); "
                f"call {self._index + 1} has nothing to return"
            )
        scripted = self._responses[self._index]
        self._index += 1
        if isinstance(scripted, str):
            text, tool_calls = scripted, []
        else:
            text = scripted.get("text") or ""
            tool_calls = [ToolCall.model_validate(c) for c in scripted.get("tool_calls", [])]
        return Completion(
            text=text,
            model=self.model,
            tier="F",
            tool_calls=tool_calls,
            usage=Usage(
                prompt_tokens=sum(len(m.content.split()) for m in messages),
                completion_tokens=len(text.split()),
            ),
            latency_s=0.0,
        )
```

The two network clients (`OllamaHTTPClient`, `OpenAICompatClient`) and the `get_client` factory follow the same pattern and are in the repo: each has a **pure `build_body`** that constructs the request dict, and a `complete` that does nothing but `httpx.post` it and hand the response to a parse function above. `make check-docs` verifies that every line printed here still matches the file, so this excerpt cannot rot.

Notice what `FakeLLMClient` records: `self.calls` keeps every message list it was given. That is not decoration. From Phase 2 onward, the interesting assertion is usually not "what did the model say" but "**what did my code send**" — did the system prompt include the tool schema, did the trimmed history drop the right turns, did the retrieved passages actually reach the prompt. Tier F is how you inspect your own outbound behaviour.

> **Your turn.** Before reading on: `parse_ollama_chat` returns `tokens_per_s=None` when timing fields are absent, rather than raising or returning `0.0`. Write down which of the three you would have chosen and one consequence of each. (Answer in the solutions file.)

### 7.5 [core] `hello-model`: latency and tokens/sec on Tier A and Tier H

The script below makes the same logical call on each usable tier and reports latency, output tokens and generation speed. Three design points, each of which was a correction to an earlier draft.

It goes through `Settings.from_env` and `get_client`, **not** through hand-built request bodies. An earlier version constructed its own JSON and read `os.environ` directly, which meant the phase spent §7.4 arguing for one seam and then shipped a script that walked around it. If the architecture is right, the diagnostic tool should be the shortest possible thing built on top of it.

It **discards a warm-up call on Tier A** and then measures twice. Cold start is model loading, not latency, and reporting one sample of anything is how you end up believing a number that was mostly disk I/O.

It **degrades instead of crashing**. Every tier is attempted independently; a `ConfigError` prints what is unset and moves on, and any other exception prints its type. Run it on a machine with nothing configured and you still get a working Tier F line plus two precise statements about what Tier A and Tier H are missing. That is the difference between a diagnostic and a stack trace.

```python
# excerpt: scripts/hello_model.py
def run_tier(tier: str, env: dict[str, str], warm: bool) -> list[Completion]:
    """Build a client for one tier and call it, optionally after a warm-up."""
    settings = Settings.from_env({**env, "ATLAS_TIER": tier})
    client = get_client(settings, fixtures=["Atlas is awake."] * 3)
    done: list[Completion] = []
    if warm:
        client.complete(WARMUP, temperature=settings.temperature, seed=settings.seed)
        print(f"tier={tier} warm-up done (discarded: cold start is not latency)")
    for _ in range(2):
        done.append(
            client.complete(PROMPT, temperature=settings.temperature, seed=settings.seed)
        )
    return done


def append_results(rows: list[tuple[str, Completion]], path: Path, seed: int | None) -> None:
    """Write measurements to docs/RESULTS.md. Model behaviour lives there, not in tests."""
    today = dt.date.today().isoformat()
    with path.open("a", encoding="utf-8") as fh:
        for metric, c in rows:
            value = (
                f"{c.tokens_per_s:.1f} tok/s"
                if metric == "generation speed" and c.tokens_per_s
                else f"{c.latency_s:.2f} s"
            )
            fh.write(
                f"| 00 | {metric} | {c.tier} | {c.model} | {seed} | {value} | {today} |\n"
            )
    print(f"appended {len(rows)} row(s) to {path}")

# ... (inside main, after probing tier_report) ...

    rows: list[tuple[str, Completion]] = []
    for tier in ("F", "A", "H"):
        status = statuses.get(tier)
        if status is not None and not status.ready:
            print(f"tier={tier} skipped: {status.detail}")
            continue
        try:
            results = run_tier(tier, env, warm=(tier == "A"))
        except ConfigError as exc:
            print(f"tier={tier} not configured: {exc}")
            continue
        except Exception as exc:  # noqa: BLE001 - diagnostic script
            print(f"tier={tier} unavailable: {type(exc).__name__}: {exc}")
            continue
        for c in results:
            print(line(c))
        print(f"  text: {results[-1].text!r}")
        if tier != "F":
            rows.append(("end-to-end latency, warm", results[-1]))
            rows.append(("generation speed", results[-1]))
```

The rest of the script is argument parsing and the `append_results` writer; both are in the repo.

**What to expect, and how to read it.** On the 16 GB no-GPU baseline with a small quantized model, expect **generation in the low tens of tokens per second** and **warm end-to-end latency of a few seconds** for a short reply; the discarded warm-up call will be several seconds slower. On Tier H expect latency dominated by the network round trip rather than generation. All of these are **author estimates, unmeasured** — the real numbers come from `make results`, which appends them to `docs/RESULTS.md` with tier, model, seed and date. Record yours. In Phase 4, when you decide how large a context you can afford, your own tokens-per-second figure is the input to that decision and mine is useless to you.

**Before you spend a Tier H call, do the token arithmetic.** A free tier's binding constraint is almost never requests per day; it is **tokens** per minute and per day. The provider row in `VERSIONS.md` gives both, and dividing the daily token allowance by your typical prompt size gives your real call budget — which for a retrieval-sized prompt can be a small fraction of the request limit. An earlier draft of this book got this wrong in print, asserting that a thousand requests per day "comfortably covers" three hundred calls; it does not, once each call carries a two-thousand-token prompt. That is why the cap in `Settings` is expressed in tokens as well as calls, and why the cache exists before the client that uses it.

**Tier self-test.** Run `make test-offline` with the model runner stopped and no `.env` present. All tests must pass. If any test fails without a model, that test is asserting on model output and is wrong — fix the test, not the model. This is the check that keeps the suite honest for sixteen phases; run it whenever you add tests.

### 7.6 [core] First `FakeLLMClient` call, and the tests it makes possible

Four scripted fixtures go in `tests/fixtures/`: a plain response and a tool-call response for each of the two wire formats. They are *hand-written*, checked in, and never regenerated automatically — that is what makes them fixtures rather than snapshots. Here is the plain native one; the tool-call pair is in the repo.

```json
{
  "model": "MODEL-FROM-VERSIONS-MD",
  "created_at": "2026-09-02T10:15:07.414671Z",
  "message": {"role": "assistant", "content": "Hello. Atlas is awake."},
  "done": true,
  "done_reason": "stop",
  "total_duration": 1854300000,
  "load_duration": 402100000,
  "prompt_eval_count": 24,
  "prompt_eval_duration": 131000000,
  "eval_count": 40,
  "eval_duration": 1280000000
}
```

And the suite. Sixteen tests in this file, no network, no model; all were executed during authoring and pass in about 0.16 s alongside the twelve in `tests/test_config.py`.

```python
# excerpt: tests/test_llm.py
"""Tier F tests. No network, no model, no clock. Run: make test-offline"""
import json
import pathlib

import pytest
from pydantic import ValidationError

from atlas.llm import (
    FakeLLMClient,
    FixtureExhausted,
    Message,
    OllamaHTTPClient,
    OpenAICompatClient,
    parse_ollama_chat,
    parse_openai_chat,
)

FIXTURES = pathlib.Path(__file__).parent / "fixtures"


def load(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text())


def test_message_rejects_unknown_role():
    with pytest.raises(ValidationError):
        Message(role="wizard", content="hi")


def test_parse_ollama_computes_tokens_per_second_from_nanoseconds():
    c = parse_ollama_chat(load("ollama_chat_hello.json"), latency_s=1.85)
    assert c.tokens_per_s == pytest.approx(31.25, rel=1e-3)


def test_parse_ollama_survives_missing_timing_fields():
    c = parse_ollama_chat({"message": {"content": "ok"}}, latency_s=0.5)
    assert c.tokens_per_s is None
    assert c.usage.completion_tokens == 0


def test_parse_openai_raises_on_empty_choices():
    with pytest.raises(ValueError):
        parse_openai_chat({"choices": []}, latency_s=0.4)


def test_fake_client_raises_when_script_runs_out():
    client = FakeLLMClient(["only one"])
    client.complete([Message(role="user", content="hi")])
    with pytest.raises(FixtureExhausted):
        client.complete([Message(role="user", content="hi")])


def test_both_providers_normalise_to_the_same_tool_call():
    a = parse_ollama_chat(load("ollama_chat_toolcall.json"), latency_s=0.9)
    h = parse_openai_chat(load("openai_chat_toolcall.json"), latency_s=0.5, tier="H")
    assert a.tool_calls[0].name == h.tool_calls[0].name
    assert a.tool_calls[0].arguments == h.tool_calls[0].arguments


def test_malformed_tool_arguments_are_preserved_not_dropped():
    payload = {
        "choices": [
            {"message": {"content": None, "tool_calls": [
                {"function": {"name": "calculator", "arguments": "{not json"}}]}}
        ]
    }
    c = parse_openai_chat(payload, latency_s=0.1)
    assert c.tool_calls[0].arguments == {"__unparsed__": "{not json"}


def test_openai_build_body_uses_the_other_dialect():
    client = OpenAICompatClient(model="m", base_url="https://x/v1", api_key="k")
    body = client.build_body(
        [Message(role="user", content="hi")],
        temperature=0.0, max_tokens=64, seed=7, stop=None,
    )
    assert body["max_tokens"] == 64        # not num_predict
    assert "num_ctx" not in body           # no field for context length at all
    assert body["seed"] == 7
```

Eight of the sixteen are shown; the rest follow the same pattern.

Look at what these sixteen tests actually assert: a role enum rejects a bad value; nanoseconds convert to tokens per second correctly (40 tokens over 1.28 s of generation is 31.25 tok/s — arithmetic, not opinion); a missing timing field degrades to `None` instead of crashing; an empty `choices` array raises rather than silently returning `""`; a tool call parses identically from both providers despite one sending a JSON object and the other a JSON string; malformed tool arguments are preserved rather than dropped; `content: null` normalises to `""`; the two `build_body` functions produce the two different dialects; the fake replays in order and can script a tool call; running past the script raises a named error instead of returning stale text; and two identical runs produce identical objects. **Not one of them mentions what a model said.** Every one would have caught a bug I could plausibly write — and the tool-call tests were written two phases before Atlas has tools, precisely so that Phase 2 inherits a tested seam instead of a new one.

> **Concept check 7.6.** `test_fake_client_raises_when_script_runs_out` seems to test a triviality. What real bug in a Phase 3 agent loop would it catch?

### 7.7 [core] With an assistant

You should use an agentic coding assistant throughout this book. Candidates, their cost models, and doc links are rows in `VERSIONS.md`; at least one option runs against your Tier A model, so this stays a $0 course. Install one now and configure it.

**Why the rules matter more than the tool.** An engineer who cannot explain their agent's code fails the interview. Not because using assistants is cheating — every professional uses them — but because the interview question is "walk me through what happens when this tool call returns malformed JSON", and an answer assembled from code you have never read falls apart in one follow-up. The assistant is a typist and a reference; the understanding has to be yours.

**Rules of engagement for this book.**

1. **Every assignment names an UNAIDED CORE.** Write that part with no assistant, no autocomplete of substance. It is small on purpose — usually 20 to 60 lines — and it is always the conceptual heart.
2. **Never delegate what you cannot review.** If you could not tell a correct implementation from a subtly wrong one, you are not ready to accept the code.
3. **Read every line you accept, out loud if it is subtle.** If you cannot say what a line does, delete it and ask for an explanation instead of code.
4. **Never paste secrets.** Not your `.env`, not a key, not a token, not a private corpus.
5. **Never show it `tests/hidden/`.** More on that below.
6. **Prefer explanation over generation when you are confused.** "Why does this fail?" teaches; "write this for me" does not.

**Safe to delegate in this phase.** The Makefile, the `.gitignore`, the directory scaffolding, the `report()` formatting, the argument-parsing boilerplate in `hello_model.py`, and converting the recorded response into a JSON fixture file. All of it is mechanical, all of it is instantly verifiable by running it.

**Not safe to delegate in this phase.** The shape of `atlas/llm.py`. If you let an assistant design the seam, you will get a plausible client that mixes transport with parsing, because that is the most common pattern in its training data — and you will lose the single decision that makes sixteen phases of offline testing possible. Also do not delegate the prerequisite self-test, obviously, or the interpretation of your own `make results` numbers.

**One prompt that works:**

> "Here is my `atlas/llm.py` and my `tests/test_llm.py`. Do not add features or refactor. Find cases where `parse_ollama_chat` or `parse_openai_chat` would raise an unhandled exception or silently return wrong data given a malformed payload. For each, name the malformed payload and the observable symptom. Do not write the fix — I will."

That prompt works because it asks for **adversarial review of code you wrote**, bounded to a file you understand, with output you can verify by writing the fixture yourself. Contrast it with "build me an LLM client with retries and caching", which produces 200 lines you will paste, half-read, and be unable to defend.

**What `make grade` and `tests/hidden/` are.** Each assignment ships a hidden test file. You run it with `make grade` and you are told not to read it. Be clear-eyed about the mechanism: the files are plaintext in your own repo, so the only thing stopping you is you. A course with a grading server would fetch them; a solo student has an honour system, and the person it protects is you. This is not arbitrary. A test you have read becomes a specification you code against, and coding against a specification you can see is a different, easier, less instructive task than making something actually work — you end up satisfying assertions instead of building behaviour. Hidden tests also mimic the real feedback loop: in production, the failing case is one you did not anticipate. If a hidden test fails and you cannot work out why, the honest move is to write your *own* tests until one of them fails too. That skill — turning "something is wrong" into a reproducing case — is most of debugging.

---

## 8. [core] Debug this trace

From Phase 3 this section shows a broken *agent trajectory* — a sequence of model turns and tool calls that went wrong. Phase 0 has no agent, so the honest substitute is the failure you are most likely to hit today, shown verbatim: a student has set up the repo, pulled a model, and run `hello-model`. The reasoning method is the same one you will apply to trajectories later, which is why it is worth doing on a small object first.

```
$ make test-offline
========================= test session starts =========================
collected 9 items

tests/test_llm.py .........                                     [100%]
========================== 9 passed in 0.14s ==========================

$ python scripts/hello_model.py
tier=F model=fake latency=0.00s out_tokens=3 tok/s=n/a
  text: 'Atlas is awake.'
tier A unavailable: [Errno 111] Connection refused

$ ollama list
NAME                    ID              SIZE      MODIFIED
<the Tier A model>      f8a2c1d09b3e    5.3 GB    12 minutes ago

$ echo $ATLAS_MODEL
<the Tier A model>
```

**The reasoning.** Start with what is *not* broken, because it is more than it looks. Nine tests pass, so parsing, validation, and the fake client are fine. Tier F prints, so the package imports and the seam works. `ollama list` shows the model, so the pull succeeded. `ATLAS_MODEL` is set, so configuration reached the process. The failure is narrow: `Connection refused` on `localhost:11434`.

`Connection refused` is a specific error and worth reading precisely. It means a TCP connection reached the host and **nothing was listening on that port** — as distinct from a timeout (something is there but not answering) or a DNS failure (the name did not resolve) or a 404 (something is listening and rejected the path). So the client, the URL, and the model are all fine; the *server* is not running where the client is looking.

That splits into two candidates. Either the runner process is not started at all, or it is running somewhere the client cannot reach — which is the WSL case from §7.2: runner installed on Windows, code running in WSL, `localhost` inside WSL not resolving to the Windows host. Note that `ollama list` succeeding does **not** distinguish these, because the CLI may be talking to a runner the Python process cannot see, or may be reading the local model store without needing the server.

**The diagnosis.** Ask the server directly, at the same address the Python code uses:

```
$ curl -sS http://localhost:11434/api/version
curl: (7) Failed to connect to localhost port 11434 after 0 ms: Connection refused
```

Same error from a different client, so it is not a Python problem. The runner is not serving on that address. In this student's case the runner had been installed but never started as a service.

**The fix.** Start the runner (`ollama serve`, or start the desktop application, depending on install method), then confirm the endpoint answers *before* re-running anything:

```
$ curl -sS http://localhost:11434/api/version
{"version":"<see VERSIONS.md>"}

$ python scripts/hello_model.py
tier=F model=fake latency=0.00s out_tokens=3 tok/s=n/a
  text: 'Atlas is awake.'
tier=A model=<the Tier A model> latency=6.41s out_tokens=6 tok/s=12.3
  text: 'Atlas is awake.'
```

Note the 6.41 s on a six-token reply: that is cold start, not generation speed. The tokens-per-second figure is computed from the runner's own generation duration and so excludes model loading, which is exactly why the two numbers disagree so wildly and why `hello-model` reports both.

**Three transferable lessons.** First, **read the error class, not just the message** — refused, timed out, unresolved, and rejected are four different bugs with four different fixes. Second, **reproduce outside your code** before debugging your code; one `curl` moved this from "my client is broken" to "the server is down" in five seconds. Third, notice that the offline suite passing while Tier A was dead is the system working as designed, not a gap in coverage. Being able to develop and test with no model available is the point.

---

## 9. [core] Common pitfalls & how professionals avoid them

**Skipping the environment discipline because it feels like overhead.** The unactivated virtual environment, the key in `.env` that was never in `.gitignore`, the project on `/mnt/c/`. Each costs an hour when it bites, and each bites during a phase where you are also learning something hard, so you will misattribute the confusion. Professionals front-load this because they have paid for it before.

**Writing a test that asserts on model output.** It will pass today and haunt you for a year, failing on model bumps and giving you no signal about your own code either way. The habit that prevents it: before writing an assertion, ask *whose behaviour* is being checked. If the answer is "the model's", it belongs in `evals/` and `docs/RESULTS.md`, not in `tests/`.

**Treating `temperature=0` as a determinism switch.** People build reproducibility strategies on this and are baffled when CI flakes. Professionals design so that determinism is not required for correctness: fixtures where they need exactness, ranges and thresholds where they need behaviour.

**Mixing transport and parsing.** The most common shape in the wild is one class that builds a request, sends it, and digs the text out of the response, all in one method. It works, and it is untestable without a network. The habit: **push the format-sensitive logic into a pure function** and keep the I/O boring. This applies far beyond LLM clients.

**Measuring latency on the first call.** Cold start inflates it by seconds. Professionals discard a warm-up call and report the distribution, not one sample — and they report generation speed separately from end-to-end latency, because those two numbers answer different questions.

**Filling the context because the model advertises room for it.** On a 16 GB machine this is the fastest route to swapping and a tenfold slowdown. Set the context explicitly to what the task needs.

**Burning the Tier H budget on exploration.** Three hundred calls sounds like plenty until you run a fifty-task eval sweep twice. Professionals cache by default and treat a hosted call as a deliberate act, which is why the cache is in the design from Phase 0 rather than added in Phase 8 after a rate limit ends a study session.

**Accepting assistant-generated architecture.** Delegating the *shape* of a module is how you end up unable to explain your own system. Delegate mechanical work, review everything, and write the conceptual core yourself.

**Planning a hosted budget in requests rather than tokens.** The published request-per-day number is the friendliest and usually the least binding of a free tier's four limits. Divide the daily *token* allowance by your real prompt size before you believe any call count — and redo it when retrieval arrives, because a prompt that doubles halves your budget. I got this wrong in print in an earlier draft of this very phase.

**Designing an interface for what you need today.** Right for private code, wrong at a published boundary. Adding a field costs a line; changing a frozen signature costs every caller, every test, and a migration note. Professionals ask "what will depend on this in two months?" before freezing a name — which is how `tool_calls` came to exist two phases before Atlas has tools.

**Trusting a listing in a document.** Code printed in prose drifts from code on disk within weeks, and a student who copies a stale listing debugs the author's history instead of their own program. The mechanical answer is a checker in CI; `make check-docs` is this book's.

**Studying by reading.** Rereading feels like progress and produces very little retention. The cumulative reviews, the concept checks, and the attempt-before-solutions rule exist to force retrieval instead. Which brings us to the last part of the method, in §10.

---

## 10. [extended] Industry perspective: how real teams set this up

Teams that ship agents converge on a small number of practices, and it is worth seeing them now so that the book's structure looks like preparation rather than pedagogy for its own sake.

**A gateway or seam in front of every model call.** Sometimes a service (an internal proxy handling keys, retries, rate limits, caching, logging), sometimes a library boundary like our `LLMClient`. Either way application code never calls a provider directly, because providers, models and prices change several times a year and a codebase with 200 direct call sites cannot follow. The trade-off is real: a seam hides provider-specific features, and eventually someone needs a field the abstraction does not expose. Mature teams keep an escape hatch — expose the raw payload, as `Completion.raw` does — rather than pretending the abstraction is complete.

**Deterministic tests and behavioural evals on different cadences.** Unit tests run on every commit and must never flake; evals run nightly or pre-release and are read as distributions. Skip the split and you get either a flaky CI everyone ignores or no behavioural signal at all. Evals cost money and time, which is why the tiering question — cheap local model for sweeps, strong model for spot checks — is a live engineering decision, not a student's compromise.

**Pinned versions and a changelog of model swaps**, because a prompt tuned against one build is not portable and "we upgraded the model and quality dropped" is a conversation every team has had. That is what the `VERSIONS.md` habit trains.

**Heavy assistant use with aggressive review.** The norm is not "don't use it" but "you own what you merge". Teams that skip review accumulate code nobody can explain — survivable in a CRUD app, dangerous in a system with tool access and credentials.

**Interview questions worth being ready for.**

1. Walk me through your agent's loop, one iteration at a time. Where can it fail to terminate, and what stops it?
2. Your test suite passes but your eval score dropped five points after a prompt change. What do you do first, and what does each of those two signals actually tell you?
3. How do you test code whose central dependency is non-deterministic? What does your approach prove, and what does it not prove?
4. You need to cut cost by 60% without a quality regression you can measure. What do you change, and how do you know it worked?
5. Why would you put an abstraction in front of a model provider, and when has that abstraction cost you something?

Good answers to these are mechanical and specific, and by Phase 3 you will be able to give them about your own code — which is worth considerably more in a conversation than an opinion about the field.

---
## 11. [core] Capstone increment

**Resume note.** There is no previous tag to fall back to — Phase 0 creates the repository. From Phase 1 onward this section opens with "If your code diverged, `git checkout phase-<NN-1>` and start from there." Today you are the one making `phase-00`.

**What Atlas can do now.** Nothing agentic, and that is correct. What exists is the foundation everything else hangs from: one seam through which every future model call passes, one place where configuration enters the process, a test suite that runs with no network and no model, an empty results file waiting for your first measurement, and a versioned contract so that Phase 1 cannot silently rename what Phase 0 established. Atlas can be configured for four tiers, can tell you which of them are actually usable on your machine, and can complete a call on Tier F deterministically. That is a day's honest work.

**Files touched this phase.** All new; nothing to diff against.

```
atlas/__init__.py                        new
atlas/{tools,rag,memory,graph,agents,     new   one-line __init__.py placeholders so the
       safety,auth,api}/__init__.py             layout in §7.2 is real, not aspirational
atlas/config.py                          new   Settings, from_env, require_usable,
                                               _parse_seed, tier_report stub
atlas/llm.py                             new   Message, ToolCall, Usage, Completion,
                                               LLMClient, parse_ollama_chat,
                                               parse_openai_chat, _coerce_arguments,
                                               FakeLLMClient, OllamaHTTPClient,
                                               OpenAICompatClient, get_client
scripts/hello_model.py                   new   latency + tokens/sec per tier; --append-results
scripts/tier_selftest.py                 new   `make demo`; uses Assignment 1
scripts/check_docs.py                    new   guards tutorial-vs-repo drift
tests/test_llm.py                        new   16 tests
tests/test_config.py                     new   12 tests (smoke)
tests/fixtures/*.json                    new   4 recorded responses: plain + tool-call,
                                               in both wire formats
tests/hidden/test_phase00_a{1,2}.py      new   graded; do not read
evals/tasks/phase00.json                 new   3 task definitions, schema_version 2
docs/RESULTS.md, docs/FAILURE_LOG.md     new   empty, with headers/template
Makefile, pyproject.toml, requirements.txt   new
.env.example, .gitignore, README.md      new
ATLAS_INTERFACES.md (v0.2), VERSIONS.md  new
```

**Code.** `atlas/llm.py` is excerpted in §7.4 and its tests in §7.6. Here are the two decisions in `atlas/config.py` worth defending, both of which were bugs before they were decisions. **`require_usable()` does not call `tier_report()`.** Configuration validates itself, so a fresh clone passes `make test-offline` before you have done either assignment — I got this wrong on the first attempt and the smoke test failed on the skeleton, which is exactly the bug this separation prevents. **An absent `ATLAS_SEED` means "use the default", not "no seed".** Treating absence as `None` silently discards reproducibility for anyone who never set the variable; disabling the seed requires saying so explicitly (`none`, `null`, or `off`). This one was also a real bug, caught by a hidden test while I was writing it.

```python
# excerpt: atlas/config.py
def _parse_seed(raw: str | None) -> int | None:
    """Absence means "use the default seed"; only an explicit opt-out disables it.

    Treating a missing variable as None would silently discard the default and
    make runs non-reproducible for anyone who never set ATLAS_SEED.
    """
    if raw is None or not raw.strip():
        return 7
    if raw.strip().lower() in {"none", "null", "off"}:
        return None
    return int(raw)

# ... (Settings fields and from_env are in the repo) ...

    def require_usable(self) -> None:
        """Raise ConfigError if the selected tier cannot actually run.

        Deliberately does not call tier_report(): configuration must validate
        itself so that a fresh clone passes `make test-offline` before any
        assignment is done.
        """
        if self.tier == "A" and not self.model:
            raise ConfigError(
                "tier A needs ATLAS_MODEL. Set it to the Tier A model in VERSIONS.md."
            )
        if self.tier == "H":
            missing = [
                name
                for name, value in (
                    ("ATLAS_H_BASE_URL", self.h_base_url),
                    ("ATLAS_H_MODEL", self.h_model),
                    ("ATLAS_H_API_KEY", self.h_api_key),
                )
                if not value
            ]
            if missing:
                raise ConfigError("tier H needs " + ", ".join(missing))
        if self.tier == "B":
            raise ConfigError(
                "tier B is paid and Appendix B only; nothing in the core needs it."
            )
```

The full module — the `Settings` field list and `from_env` — is in the repo; the whole of it is thirteen environment keys read in one place and validated once.

**Tests added.** Twenty-eight visible tests, all executed during authoring, all passing in about 0.16 s with no network and no model: sixteen in `tests/test_llm.py` (§7.6) and twelve in `tests/test_config.py` covering tier rejection with a helpful message, Tier A requiring a model, Tier H naming *every* missing variable rather than the first, Tier B refused outside Appendix B, the seed default and its explicit opt-out, case-insensitive tier letters, the API key staying out of `repr()`, the token cap alongside the call cap, `get_client` returning a fake on Tier F, and the declared package directories existing. Plus two hidden files, fifteen tests between them, verified to pass against the reference solutions printed in `phase_00_solutions.md` — I pasted the published answers back into a clean checkout and ran the graded suite, which is the only way to know the answers and the tests agree.

**+3 eval tasks** in `evals/tasks/phase00.json`. The harness is built in Phase 3; the definitions land now so the suite grows from the first phase rather than starting at 42. `p00-fake-client-replays-script` asserts the fake replays a one-item script, reports tier F, and produces no tool calls. `p00-parse-ollama-usage` asserts the recorded payload parses to 24 prompt and 40 completion tokens at 31.25 tok/s. `p00-tier-a-reachable` is an environment task: the runner answers and returns a non-empty completion inside 60 s.

The task **checks are structured data**, not strings — `{"field": "completion.usage.prompt_tokens", "op": "eq", "value": 24}` rather than `"usage.prompt_tokens == 24"`. An earlier draft used strings, which reads nicely and is a trap: a stringly-typed check cannot be type-checked or refactored, silently rots when a field is renamed, and forces the Phase 3 harness to call `eval()` on data from a file. Choosing the format now, before a harness exists, costs nothing; choosing it in Phase 3 with fifteen tasks already written costs a migration.

**`make results` and the expected ranges.** Run it after setting `ATLAS_MODEL`. It reports four numbers, and all four of my figures below are **author estimates, unmeasured** — `docs/RESULTS.md` is where *your* measurements live, and yours supersede mine on your hardware. Tier A, baseline 16 GB no-GPU laptop, seed 7, temperature 0, short reply: generation speed in the **low tens of tokens per second**; warm end-to-end latency **1–5 s**; cold-start end-to-end latency **5–15 s** on the first call after the model loads. Tier H: end-to-end latency **under 2 s**, dominated by the network round trip rather than generation.

**"Read five failing traces" — `docs/FAILURE_LOG.md`.** This practice starts in Phase 3, because Phase 0 has no agent to fail. The file ships empty with its entry template so the habit has somewhere to go. The one entry worth making now, if you hit it, is your own environment failure: what the error class was, what you checked first, and what it actually turned out to be. That is the same skill applied to a smaller object.

**Interface changes.** None — Phase 0 creates the contract. For the record, `ATLAS_INTERFACES.md` ships as **v0.2** rather than v0.1 because writing §7 exposed three gaps in my first draft: `Completion` had no `tool_calls`, `FakeLLMClient` accepted only `str`, and the Tier H cap was expressed only in calls. All three would have forced a *breaking* change in Phase 1 or 2. Fixing them before the tag is why this subsection is empty, and the general lesson is worth more than the specific fixes: **the cheapest moment to change an interface is before anyone depends on it, and the way you find the gaps is by writing the code that will use it.**

**Repo tag.** Commit and tag:

```bash
git add -A && git commit -m "phase 0: repo skeleton, config, llm seam, tiers, tests"
git tag phase-00
```

---

## 12. [core] Mastery checklist

You are ready to move on if you can:

- Name every phase from 0 to 16 in order and state what each adds to Atlas, without looking.
- Explain what Appendix F is for and name two builds in it you intend to come back for.
- State your chosen track and the weekly hours that justify it.
- Report your prerequisite self-test score and name the Appendix A sections you owe.
- Run `make test-offline` on a fresh clone, with the model runner stopped and no `.env`, and see everything pass.
- Run `hello-model` and read off tokens/sec and latency for every tier you have configured.
- Explain, without notes, why the test suite may not assert on model output, and where model behaviour is recorded instead.
- State what a scripted fixture proves and what it does not, in your own words.
- Explain why transport and parsing are separate functions in `atlas/llm.py`, and what breaks if you merge them.
- Say why `temperature=0` does not make a model deterministic, giving two mechanisms.
- Estimate whether a given model will fit your RAM, given its parameter count and quantization.
- Name one task in this phase you would delegate to an assistant and one you would not, with reasons.
- Explain why you are told not to read `tests/hidden/`.
- Compute your real Tier H budget from a provider's token limits and a typical prompt size, and say why the request-per-day figure is usually the wrong number to plan against.
- Explain why `Completion` carries `tool_calls` two phases before Atlas has tools.
- Run `make check-docs` and say what class of bug it prevents.

---

## 13. [core] Quiz

Questions only; answers in `phase_00_solutions.md`.

1. Atlas's eval suite reaches roughly 45 tasks by Phase 16, yet the harness is built in Phase 3 when only three tasks exist. Give two distinct reasons that ordering is deliberate, one about engineering and one about learning.
2. A classmate proposes running every eval sweep on Tier H because the model is stronger and the free tier is generous. Give the two strongest objections, and one circumstance in which they are right.
3. `parse_ollama_chat` computes tokens per second from the runner's reported generation duration rather than from the wall-clock latency your code measured. Explain the difference between those two numbers and name a situation where they diverge by more than a factor of two.
4. You add a test asserting that your agent's answer to "what is 17 × 23?" contains "391". Explain what is wrong with this test on three separate grounds, and say where the check belongs instead.
5. The four tiers differ along three axes: cost, determinism, and capability. Place A, H, F and B on each axis, and explain why no single tier can replace the other three.
6. `require_usable()` deliberately does not call `tier_report()`, even though both check the same conditions. What concrete failure does that duplication prevent, and what is the cost of the duplication?
7. A provider's free tier documents 30 requests/minute, 1,000 requests/day, 8,000 tokens/minute and 200,000 tokens/day. Your agent's average prompt is 2,500 tokens and it replies with 300. How many calls per day can you actually make, how many per minute, and which of the four published limits binds first? Then say what changes when Phase 5 adds retrieved passages to every prompt.

---

## 14. [core] Coding assignments

Exactly two. Each names an UNAIDED CORE — the part you write with no assistant — and ships a hidden test file you run with `make grade` and do not read.

### Assignment 1 — `tier_report()` [fast track: do this one]

Implement `tier_report(settings) -> dict[str, TierStatus]` in `atlas/config.py`, replacing the stub. It reports, for all four tiers, whether that tier could run right now and why or why not. `make demo` uses it.

**Acceptance criteria.**

1. Returns a dict whose keys are exactly `{"A", "H", "F", "B"}`, always, regardless of configuration.
2. Every `TierStatus.detail` is a non-empty string, including for ready tiers.
3. Tier F is always ready — it needs nothing.
4. Tier B is never ready, and its detail says so and mentions Appendix B.
5. Tier A is ready if and only if `settings.model` is set. When not ready, the detail tells the reader to set `ATLAS_MODEL` and points at `VERSIONS.md`.
6. Tier H is ready if and only if all three of base URL, model and key are present. When not ready, the detail **names every missing environment variable** by its `ATLAS_*` name, not just the first one found.
7. `make test-offline` still passes. `make demo` prints four readiness lines.

**UNAIDED CORE:** the readiness logic itself — the conditions, and the construction of the detail strings. It is about 25 lines. Do not delegate it; the whole point is that you can state what your own system needs in order to run. You may delegate the `make demo` output formatting.

**Hint on criterion 6:** collect the missing names into a list and join them, rather than returning at the first one. A user with three unset variables should learn all three from one run, not discover them one at a time across three runs. That is a small kindness that separates tools people like from tools people tolerate.

Hidden test: `tests/hidden/test_phase00_a1.py`.

### Assignment 2 — `atlas/cache.py` [extended]

Create `atlas/cache.py` implementing the Tier H response cache declared in `ATLAS_INTERFACES.md`. Nothing in Atlas calls it yet; Phase 1 wires it into the Tier H client. You are building the thing that makes a 300-call budget survive contact with a repeated experiment.

**Acceptance criteria.**

1. `request_key(payload)` returns a 64-character lowercase hex sha256 digest.
2. The key is **insensitive to dict ordering**: `{"model": "m", "temperature": 0}` and `{"temperature": 0, "model": "m"}` hash identically.
3. The key changes when any value changes.
4. `ResponseCache(root)` creates `root`, including missing parents.
5. `get` returns `None` on a miss, and the stored dict after a `put`.
6. Entries persist across process boundaries — a fresh `ResponseCache` on the same directory sees them.
7. A corrupt or truncated entry on disk is treated as a **miss**, not an exception.
8. `len(cache)` counts stored entries; `key in cache` works.
9. `make test-offline` still passes.

**UNAIDED CORE:** `request_key`, plus the durability decision in `put` and the miss-on-corrupt behaviour in `get`. About 25 lines. The canonicalization in `request_key` is the conceptual heart — get it wrong and your cache silently misses, your token budget evaporates, and nothing appears broken until it is expensive. The `put`/`get` pair is the other half: criterion 7 tests the read side, but the write side is where corruption comes from, so treat them as one decision.

**Hint on criterion 7:** think about what happens if the process is killed mid-write, then about whether `put` should write directly to its final path. There is a two-line technique that makes a half-written entry impossible rather than merely survivable.

Hidden test: `tests/hidden/test_phase00_a2.py`.

---

## 15. [extended] Case study

Phase 0 has no case study; the design exercises begin in Phase 3, where there is a system to make decisions about. The block for this phase does not call for one.

---

## 16. [core] Summary & key takeaways

*Self-contained. Paste this into the chat or notebook where you start Phase 1.*

Phase 0 established the ground rules and the skeleton for **Atlas**, a Research & Operations Assistant built across Phases 0–16.

**An agent** is a program in which a model, called repeatedly in a loop, selects the next action from a fixed set of tools until a stopping condition is met. Four pieces: the environment (what can be observed or affected), tools (named, schema-described functions), the loop (your deterministic code), and the trajectory (the record of one attempt). The model never executes anything; your dispatcher does, which is why every guardrail, approval gate and credential scope later lives in the dispatcher.

**Four execution tiers.** Tier A is a quantized local model — the default, free and unlimited, and the tier every eval sweep runs on. Tier H is a free hosted API, capped at 300 calls per phase, cached to `data/cache/`, and never required by any test. Tier F is `FakeLLMClient` replaying scripted fixtures — deterministic, offline, and how the test suite works. Tier B is paid and confined to Appendix B. The specific model, provider and quotas are rows in `VERSIONS.md`, never in prose.

**Tests never assert on model output.** They assert on parsing, schema validation, control flow, budgets and retrieval math against hand-written fixtures in `tests/fixtures/`. Fixtures prove your code handles a given input correctly, today and after a refactor; they prove nothing about how often a real model produces that input. Model behaviour is data, not a test: `make results` measures it on Tier A and `docs/RESULTS.md` records it with tier, model and seed.

**The architecture so far.** `atlas/config.py` is the only module that reads the environment; `Settings.from_env` validates the selected tier and refuses to start on a configuration that cannot work. `atlas/llm.py` is the single seam through which every model call passes, and inside it **transport is separate from parsing**: network clients are thin shells whose pure `build_body` constructs the request and whose response goes straight to `parse_ollama_chat` or `parse_openai_chat`. That split is precisely what makes the suite runnable offline. `Completion` normalises text, model, tier, **tool calls**, token usage, latency and tokens/sec across all tiers, with `raw` as an escape hatch; `ToolCall` absorbs the two providers' disagreement (object vs. JSON-string arguments, `null` vs. `""` content) so no caller ever branches on provider. `get_client(settings)` is the only place a tier is chosen. `tool_calls` and `str | dict` fixtures exist now, unused, because **adding a field to a published interface is free and changing one is not.**

**Practical facts to carry forward.** The baseline machine is 16 GB with no GPU; weights cost roughly parameter-count × bytes-per-parameter, quantization cuts that to well under a byte per parameter, and the KV cache grows with tokens actually in context — so set context length to what you need, not to the model's maximum. Verify with `ollama show` that your model lists `tools`; Phase 2 needs it and library capability badges are published per family, not per tag. `temperature=0` makes sampling greedy but not the system deterministic: floating-point non-associativity, batching, quantization builds and hosted-replica differences all still move outputs. The OpenAI-compatible shape matters because one client serves Tier A and Tier H, differing only by base URL and key — but compatibility is partial and the dialects differ (`options`/`num_predict` versus top-level/`max_tokens`, and no context-length field at all). **A hosted free tier is a token budget, not a call budget:** divide the daily token allowance by your typical prompt size to get your real call count.

**Working method.** Pick a track (fast ≈125 h, standard ≈195 planned / 225 budgeted, extended ≈265 h) and recalibrate after Phase 3 against your own timing data — my Phase 0 estimate was 40% low, so assume the rest lean the same way. Use a coding assistant, but write every UNAIDED CORE yourself, review every accepted line, never paste secrets, and never read `tests/hidden/`. Study by retrieval, not rereading: write your answer to every cumulative review and concept check before opening the solutions, keep a lab notebook with hours, causes and one unanswered question per session, use the thirty-minute protocol on papers, and maintain your own `VERSIONS.md`.

**Repo state at `phase-00`.** `atlas/{config.py, llm.py}` plus placeholder packages for every later phase, `scripts/{hello_model.py, tier_selftest.py, check_docs.py}`, **28 passing offline tests**, two hidden test files, three eval task definitions with structured checks, empty `docs/RESULTS.md` and `docs/FAILURE_LOG.md`, a seven-target Makefile (`test-offline`, `grade`, `results`, `record`, `evals`, `demo`, `check-docs`), `pyproject.toml`, and `ATLAS_INTERFACES.md` v0.2 with `VERSIONS.md`. Two assignments outstanding: `tier_report()` and `atlas/cache.py`. Note that `make demo` prints a "finish Assignment 1" message until you do — that is expected, not broken.

**Phase 1 next:** the model as a component — structured output validated against JSON Schema, retries on malformed output, and per-call token, latency and cost accounting through the seam you just built.

---

## 17. [core] Further reading

Reputable primary sources only, dated. Read none of these to finish Phase 0; read them when the corresponding phase arrives.

- **Ollama documentation** — the native chat API, OpenAI compatibility (including the list of unsupported request fields), context length, tool calling, structured outputs, CLI, and install notes per platform. https://docs.ollama.com · https://docs.ollama.com/api/openai-compatibility (accessed 2 September 2026)
- **Ollama release notes** — skim before blaming your code for a behaviour change. https://github.com/ollama/ollama/releases (accessed 2 September 2026)
- **Groq rate-limit documentation** — a worked example of what a documented free tier looks like: RPM, RPD, TPM, TPD, org-level scoping, and the `retry-after` and `x-ratelimit-*` headers. Read it once even if you pick another provider; it is where the token-vs-request lesson in §7.5 comes from. https://console.groq.com/docs/rate-limits (accessed 2 September 2026)
- **Gemini API rate limits** — the same concepts from a second vendor, plus usage tiers and spend-based limits. https://ai.google.dev/gemini-api/docs/rate-limits (accessed 2 September 2026)
- **Pydantic** — validation, `model_dump`, JSON Schema generation; Phase 1 leans on all three. https://docs.pydantic.dev (accessed 2 September 2026)
- **pytest** — fixtures, parametrization, `tmp_path`. https://docs.pytest.org (accessed 2 September 2026)
- **JSON Schema specification** — the vocabulary you will use to describe every tool to every model from Phase 2 onward. https://json-schema.org/specification (accessed 2 September 2026)
- **Python developer's guide, version status** — which Python versions are current, in security-fix mode, or end of life. https://devguide.python.org/versions/ (accessed 2 September 2026)
- **OWASP Top 10 for LLM Applications** — the shared vocabulary for prompt injection, insecure output handling and excessive agency; the reference for Phase 14. https://owasp.org/www-project-top-10-for-large-language-model-applications/ (accessed 2 September 2026)
- **Model Context Protocol specification** — read at Phase 15, not now; the revision this book pins is recorded in that phase. https://modelcontextprotocol.io/specification (accessed 2 September 2026)
- **LangGraph documentation** — do not open before Phase 9. Reading it early tends to replace understanding of the loop with familiarity with an API. https://langchain-ai.github.io/langgraph/ (accessed 2 September 2026)

---
## 19. [core] HANDOFF

### ATLAS_INTERFACES.md (complete, v0.2)

````markdown
# ATLAS_INTERFACES.md — v0.2 (Phase 0)

The contract. Nothing listed here is renamed or changed in a later phase except
in an explicit "Interface changes" subsection of that phase's capstone, with a
migration note. Additions are free; changes are not.

## Config keys (environment)

| Key | Type | Default | Meaning |
|---|---|---|---|
| `ATLAS_TIER` | `A` \| `H` \| `F` \| `B` | `A` | Which execution tier to use. Case-insensitive. |
| `ATLAS_MODEL` | str | — | Tier A model tag. No default by design; see VERSIONS.md. |
| `ATLAS_OLLAMA_HOST` | str | `http://localhost:11434` | Local runner base URL. |
| `ATLAS_H_BASE_URL` | str | — | Tier H OpenAI-compatible base URL (ends in `/v1`). |
| `ATLAS_H_MODEL` | str | — | Tier H model id. |
| `ATLAS_H_API_KEY` | str | — | Tier H key. Never logged, excluded from `repr`. |
| `ATLAS_TEMPERATURE` | float | `0.0` | Sampling temperature. |
| `ATLAS_SEED` | int \| `none` | `7` | Sampling seed. Absent means default; `none`/`null`/`off` disables. |
| `ATLAS_MAX_TOKENS` | int | — | Output cap. |
| `ATLAS_NUM_CTX` | int | `4096` | Context length for Tier A. |
| `ATLAS_DATA_DIR` | path | `data` | Root for generated data. |
| `ATLAS_CACHE_DIR` | path | `data/cache` | Tier H response cache. |
| `ATLAS_TIER_H_CALL_CAP` | int | `100` | Per-phase Tier H call cap. Convention in Phase 0; enforced from Phase 1. |
| `ATLAS_TIER_H_TOKEN_CAP` | int | `200000` | Per-day Tier H token cap — the binding constraint, not calls. |

## `atlas.config`

```python
Tier = Literal["A", "H", "F", "B"]
VALID_TIERS: tuple[str, ...]

class ConfigError(RuntimeError): ...

class TierStatus(BaseModel):
    ready: bool
    detail: str

class Settings(BaseModel):
    tier: Tier
    model: str | None
    ollama_host: str
    h_base_url: str | None
    h_model: str | None
    h_api_key: str | None            # repr=False
    temperature: float
    seed: int | None
    max_tokens: int | None
    num_ctx: int
    data_dir: Path
    cache_dir: Path
    tier_h_call_cap: int
    tier_h_token_cap: int

    @classmethod
    def from_env(cls, env: Mapping[str, str] | None = None) -> "Settings": ...
    def require_usable(self) -> None: ...          # raises ConfigError

def tier_report(settings: Settings) -> dict[str, TierStatus]: ...
    # keys are exactly {"A", "H", "F", "B"}; every detail is non-empty
```

## `atlas.llm`

```python
Role = Literal["system", "user", "assistant", "tool"]

class Message(BaseModel):
    role: Role
    content: str

class Usage(BaseModel):
    prompt_tokens: int
    completion_tokens: int
    @property
    def total_tokens(self) -> int: ...

class Completion(BaseModel):
    text: str                        # "" when the model only asked for tools
    model: str
    tier: Tier
    tool_calls: list[ToolCall]        # empty until Phase 2 uses it
    usage: Usage
    latency_s: float
    tokens_per_s: float | None
    raw: dict[str, Any]

class ToolCall(BaseModel):
    name: str
    arguments: dict[str, Any]        # dicts (Ollama) and JSON strings (OpenAI) normalise here
    id: str | None

class FixtureExhausted(RuntimeError): ...
class BudgetExceeded(RuntimeError): ...

class LLMClient(Protocol):
    tier: Tier
    model: str
    def complete(
        self,
        messages: Sequence[Message],
        *,
        temperature: float = 0.0,
        max_tokens: int | None = None,
        seed: int | None = None,
        stop: Sequence[str] | None = None,
    ) -> Completion: ...

# pure parse functions — no network, no clock, no globals
def parse_ollama_chat(payload: dict, latency_s: float, *, tier: Tier = "A") -> Completion: ...
def parse_openai_chat(payload: dict, latency_s: float, *, tier: Tier = "H") -> Completion: ...

class FakeLLMClient:                  # tier "F"
    # a scripted response is a str, or a dict with "text" and/or "tool_calls"
    def __init__(self, responses: Sequence[str | dict[str, Any]], *,
                 model: str = "fake") -> None: ...
    calls: list[list[Message]]         # every outbound message list, in order

class OllamaHTTPClient:               # tier "A"
    def __init__(self, model: str, host: str = "http://localhost:11434",
                 num_ctx: int = 4096, timeout_s: float = 120.0) -> None: ...
    def build_body(self, messages, *, temperature, max_tokens, seed, stop) -> dict: ...
        # pure; sampling goes in "options", max output is "num_predict"

class OpenAICompatClient:             # tier "H" (or "A" via /v1)
    def __init__(self, model: str, base_url: str, api_key: str,
                 tier: Tier = "H", timeout_s: float = 120.0) -> None: ...
    def build_body(self, messages, *, temperature, max_tokens, seed, stop) -> dict: ...
        # pure; "max_tokens", and no field for context length

def get_client(settings: Settings, *,
               fixtures: Sequence[str | dict[str, Any]] | None = None) -> LLMClient: ...
```

## `atlas.cache` — created by Phase 0 Assignment 2

```python
def request_key(payload: dict[str, Any]) -> str: ...      # 64-char sha256 hex, order-insensitive

class ResponseCache:
    def __init__(self, root: Path | str) -> None: ...      # creates root
    def get(self, key: str) -> dict[str, Any] | None: ...  # None on miss or corrupt entry
    def put(self, key: str, value: dict[str, Any]) -> None: ...
    def __len__(self) -> int: ...
    def __contains__(self, key: str) -> bool: ...
```

## Repo layout

```
atlas/{config.py, llm.py, cache.py, tools/, rag/, memory/, graph/, agents/, safety/, auth/, api/}
tests/{fixtures/, hidden/}
evals/tasks/
data/cache/
docs/{RESULTS.md, FAILURE_LOG.md}
scripts/
Makefile
pyproject.toml
scripts/{hello_model.py, tier_selftest.py, check_docs.py}
```

## Makefile targets

`test-offline` (Tier F, excludes `tests/hidden`) · `grade` (runs `tests/hidden`,
continues past collection errors) · `results` (`--append-results` writes
`docs/RESULTS.md`) · `record` · `evals` · `demo` · `check-docs`

## Eval task file format (`evals/tasks/phase<NN>.json`)

```json
{"phase": 0, "schema_version": 2, "tasks": [
  {"id": "p00-...", "kind": "deterministic|environment", "tier": "A|H|F",
   "description": "...",
   "setup": {"fixtures": ["..."], "prompt": "..."},
   "checks": [{"field": "completion.usage.prompt_tokens", "op": "eq", "value": 24},
              {"field": "completion.tokens_per_s", "op": "approx", "value": 31.25,
               "tolerance": 0.01}]}
]}
```

`op` is one of `eq`, `gt`, `lt`, `len_eq`, `approx` (with `tolerance`), `contains`.
Checks are **structured data, never strings passed to `eval()`**: a stringly-typed
check cannot be type-checked or refactored safely, and it pushes `eval()` into the
Phase 3 harness.

## Invariants

1. `tests/` never asserts on model output. Model behaviour goes to `docs/RESULTS.md`.
2. `make test-offline` passes on a fresh clone with no network, no model, no `.env`.
3. Transport and parsing stay separate: network clients are shells over pure parse functions.
4. No module outside `atlas/config.py` reads `os.environ`.
5. No default anywhere names a model. Model ids live in `VERSIONS.md`.
6. Tier H is capped and cached; no test requires it. The cap is in **tokens** first.
7. Nothing in `atlas/` or `scripts/` builds a request outside `atlas/llm.py`.
8. `make check-docs` must pass: every `# file:`-marked block in the tutorial
   matches the repo byte for byte.
````

### VERSIONS.md delta rows (all new this phase)

````markdown
# VERSIONS.md

Current-state facts only. Every row carries a source URL and a checked-on date.
Prose in the tutorial never states these; it points here. Re-verify before you
start, and keep your own copy updated as you go — that habit is the point.

## Runtime

| Fact | Value | Source | Checked |
|---|---|---|---|
| Python floor for this book | 3.11 | https://devguide.python.org/versions/ | 2026-09-02 |
| Newest stable Python | 3.14.7 (released 2026-08-05) | https://www.python.org/downloads/ | 2026-09-02 |
| Python 3.15 status | 3.15.0rc2 (2026-09-01) — release candidate, PRE-RELEASE | https://www.python.org/downloads/source/ | 2026-09-02 |
| uv | 0.12.9 | https://pypi.org/pypi/uv/json | 2026-09-02 |
| ruff (optional lint) | 0.16.5 | https://pypi.org/pypi/ruff/json | 2026-09-02 |

Forward pointer: Python 3.15 is a release candidate, not a release. Nothing in
this book uses it; stay on 3.14 or your working 3.11+ until it ships.

## Pinned Python packages (Phase 0 `requirements.txt`)

| Package | Version | Source | Checked |
|---|---|---|---|
| pydantic | 2.13.5 | https://pypi.org/pypi/pydantic/json | 2026-09-02 |
| httpx | 0.28.1 | https://pypi.org/pypi/httpx/json | 2026-09-02 |
| python-dotenv | 1.2.3 | https://pypi.org/pypi/python-dotenv/json | 2026-09-02 |
| pytest (dev extra) | 9.1.1 | https://pypi.org/pypi/pytest/json | 2026-09-02 |

## Later-phase packages (do not install yet)

| Package | Version | First used | Source | Checked |
|---|---|---|---|---|
| pytest-asyncio | 1.4.0 | Phase 1 | https://pypi.org/pypi/pytest-asyncio/json | 2026-09-02 |
| tenacity | 9.1.4 | Phase 1 | https://pypi.org/pypi/tenacity/json | 2026-09-02 |
| ollama (Python client) | 0.6.2 | Phase 0 §7.3, way 2 | https://pypi.org/pypi/ollama/json | 2026-09-02 |
| openai | 3.7.0 | Phase 0 §7.3, way 3 | https://pypi.org/pypi/openai/json | 2026-09-02 |
| langgraph | 1.2.11 | Phase 9 — NOT BEFORE | https://pypi.org/pypi/langgraph/json | 2026-09-02 |
| langchain | 1.3.18 | Phase 10 | https://pypi.org/pypi/langchain/json | 2026-09-02 |
| mcp (Python SDK) | 2.1.1 | Phase 15 | https://pypi.org/pypi/mcp/json | 2026-09-02 |

Forward pointer: the MCP *specification* revision is pinned in Phase 15, not
here, because that is where the book first depends on it.

## Tier A — local runner and model

| Fact | Value | Source | Checked |
|---|---|---|---|
| Runner | Ollama, latest release v0.33.2 (2026-08-27) | https://github.com/ollama/ollama/releases | 2026-09-02 |
| Runner pre-release (do not use) | v0.33.3-rc0 (2026-09-02) | https://github.com/ollama/ollama/releases | 2026-09-02 |
| Native chat endpoint | `POST http://localhost:11434/api/chat` | https://docs.ollama.com/api/chat | 2026-09-02 |
| OpenAI-compatible base URL | `http://localhost:11434/v1/`, api_key `ollama` (required, ignored) | https://docs.ollama.com/api/openai-compatibility | 2026-09-02 |
| Unsupported in OpenAI-compat mode | `tool_choice`, `logit_bias`, `n`, `logprobs` | https://docs.ollama.com/api/openai-compatibility | 2026-09-02 |
| **`ATLAS_MODEL` (default choice)** | **`gemma4:12b`** — 7.6 GB, 256K context, family badged `tools`/`thinking` | https://ollama.com/library/gemma4 | 2026-09-02 |
| Low-RAM alternative (< 12 GB) | `granite4.2:3b` — 2.2 GB, 128K context | https://ollama.com/library/granite4.2 | 2026-09-02 |
| Mid alternative | `granite4.2:8b` — 5.3 GB, 128K context, Apache 2.0. Card claims tool use, but the library page shows no `tools` capability badge — verify with `ollama show` before relying on it in Phase 2. | https://ollama.com/library/granite4.2 | 2026-09-02 |
| Larger alternative (multimodal) | `gemma4:e4b` — 9.6 GB, 128K context | https://ollama.com/library/gemma4 | 2026-09-02 |
| **Mandatory local check** | `ollama show $ATLAS_MODEL` must list `tools` under Capabilities | https://docs.ollama.com/cli | 2026-09-02 |

Chosen because it fits the 16 GB no-GPU baseline with room for a KV cache and
because the Ollama library page badges the family `tools`, which Phase 2 needs.
Two honest caveats. The badges are published per *family*, not per tag, so the
`ollama show` row above is not optional — run it before Phase 2 and switch tags
if `tools` is absent. And Gemma 4's own card recommends `temperature=1.0`,
`top_p=0.95`, `top_k=64`; this book overrides temperature to 0 for
reproducibility, which trades some output quality for stable evals. If your
Phase 1 structured-output pass rate is poor, that trade-off is the first thing
to test.

## Tier H — free hosted API candidates (budget in TOKENS, cached to `data/cache/`)

| Candidate | Endpoint | Free-tier quota | Source | Checked |
|---|---|---|---|---|
| **Groq (candidate 1)** | `https://api.groq.com/openai/v1` | Free plan, `openai/gpt-oss-20b`: 30 RPM, 1,000 RPD, **8K TPM, 200K TPD**. Same for `qwen/qwen3.8-27b`. Org-level, not per key. | https://console.groq.com/docs/rate-limits | 2026-09-02 |
| Groq OpenAI compatibility | as above | documented as mostly OpenAI-client compatible | https://console.groq.com/docs/openai | 2026-09-02 |
| Groq rate-limit headers | as above | `retry-after`, `x-ratelimit-remaining-requests`, `x-ratelimit-remaining-tokens` | https://console.groq.com/docs/rate-limits | 2026-09-02 |
| **Google AI Studio (candidate 2)** | `https://generativelanguage.googleapis.com` | Free tier exists (no spend limit applies); per-model RPM/TPM/RPD are published per project in AI Studio, not in the docs table — read your own limits there before relying on a number | https://ai.google.dev/gemini-api/docs/rate-limits | 2026-09-02 |

**The budget is tokens, not calls.** Do the arithmetic before you trust a call
count: 200,000 tokens/day ÷ a 2,000-token agent prompt ≈ **100 calls/day**, and
8,000 tokens/minute ≈ 4 such calls/minute. An earlier draft of this book claimed
1,000 RPD "comfortably covers 300 calls" — wrong, because requests per day is
not the binding constraint. Hence `ATLAS_TIER_H_CALL_CAP=100` and
`ATLAS_TIER_H_TOKEN_CAP=200000`. From Phase 5 a retrieval prompt can exceed
4,000 tokens, which halves the call budget again; cache accordingly.

**Enforcement status:** both caps are declared in `Settings` and honoured by
convention in Phase 0. Automatic enforcement (a counter that raises
`BudgetExceeded`) arrives in Phase 1 with the Tier H client wiring.

## Coding-assistant candidates

| Candidate | Cost model | Runs against Tier A? | Source | Checked |
|---|---|---|---|---|
| OpenCode | see vendor terms | Yes — documented Ollama integration | https://docs.ollama.com/integrations/opencode | 2026-09-02 |
| Goose | see vendor terms | Yes — documented Ollama integration | https://docs.ollama.com/integrations/goose | 2026-09-02 |
| Cline CLI | see vendor terms | Yes — documented Ollama integration | https://docs.ollama.com/integrations/cline-cli | 2026-09-02 |
| Claude Code | Requires a paid Claude plan or API credits — check current terms at the source | Yes — documented Ollama integration | https://docs.claude.com/en/docs/claude-code/overview · https://docs.ollama.com/integrations/claude-code | 2026-09-02 |

Any of these can be pointed at your Tier A model, which is what keeps the course
at $0. I have not independently verified each vendor's current pricing or
licence; check the source before you sign up.

## Known-unverified facts (do not treat as checked)

| Fact | Why unverified | What to do |
|---|---|---|
| Per-tag `tools` capability for any Ollama model | Library badges are family-level; only your machine is authoritative | Run `ollama show $ATLAS_MODEL` |
| Current pricing/licence terms of any coding assistant | Vendor pages change; I did not test each signup flow | Read the vendor page before signing up |
| Gemini per-model free-tier RPM/TPM/RPD | Published per project in AI Studio, not in public docs | Read your own limits page |
| Tier A/H latency and tokens/sec on your hardware | Hardware-specific; my figures are estimates | `make results` |
````

---

*End of Phase 0. Solutions: `phase_00_solutions.md`. Repo skeleton: `atlas_phase_00.zip`, tag `phase-00`. Verified before publication: `make test-offline` 28 passed, `make check-docs` clean, and the solutions file's own code passes the graded suite.*
