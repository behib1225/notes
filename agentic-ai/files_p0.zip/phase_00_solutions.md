# phase_00_solutions.md

Worked answers for Phase 0. Attempt everything before reading. An answer you have read is an answer you will believe you could have produced.

---

## Cumulative review (§2)

**1. Token, context window, temperature.** A *token* is the unit the model reads and emits — a subword fragment, so "unbelievable" may be several tokens and " the" is usually one. The *context window* is the maximum number of tokens the model can attend to in one call, counting the prompt and the generated output together. *Temperature* scales the logits before sampling: at 0 the highest-probability token is always chosen, and as it rises lower-probability tokens become likelier.

**2. Two mechanisms that break determinism at `temperature=0`.** Any two of: floating-point addition is not associative, so a change in batch size, thread count, or kernel selection changes low-order bits and can flip which token was highest when two are nearly tied; a different quantization build, runner version, or hardware backend (CPU vs Metal vs CUDA) computes different arithmetic for the same weights; on a hosted provider you cannot control which replica, hardware generation, or server version handled your request; and system-prompt or template changes on the provider's side alter the actual input without altering yours. Note that all four are outside your code, which is the lesson.

**3. `await`.** It suspends *the coroutine that executes it* until the awaited thing completes, and yields control back to the event loop. It does **not** block the rest of the program: other tasks on the same loop continue running during the suspension. The common misconception is that `await` means "wait here", making async code sequential — it means "I can be paused here", which is what allows concurrency.

**4. `dict` vs Pydantic model, from the caller's view.** With a `dict` the caller gets no guarantee that a key exists or that its value has the expected type, and any typo surfaces as a `KeyError` far from the cause. With a model instance the caller gets validated fields with known types, attribute access with editor and type-checker support, a clear error at construction time rather than at use time, and useful extras — `model_dump()`, `model_dump_json()`, `model_json_schema()`. In this book the last one matters most: the schema a model generates is how a tool is described to an LLM.

**5. SQL.**

```sql
SELECT c.name, o.total
FROM customers AS c
LEFT JOIN orders AS o ON o.customer_id = c.id;
```

`LEFT JOIN` is the point: an `INNER JOIN` would silently drop customers with no orders, which is exactly the population the question asks about. Customers with no orders appear with `NULL` in `total`. If you wanted one row per customer with a summed total, you would add `SELECT c.name, COALESCE(SUM(o.total), 0) ... GROUP BY c.id, c.name`.

---

## Concept checks

**6.1 — whose decisions were they?** The model decided: that a tool was needed at all rather than answering directly; which tool (SQL rather than the calculator); what arguments to pass (which table, which date range, how to phrase the query); when it had enough information to stop and answer; and the wording of the final answer. You decided: that a SQL tool existed and what its schema was; that it was read-only and scoped to certain tables; that the result was returned as a table rather than prose; the step budget that bounded the loop; what happens on a malformed query; and whether the answer required a citation. The model chose *within* a space you defined. Widening that space is the same act as widening your blast radius.

**6.5 — why the harness at Phase 3?** Because after Phase 3 every phase changes behaviour, and a behaviour change you cannot measure is indistinguishable from a behaviour change you did not intend. Concretely: adding retrieval in Phase 5 can degrade answers on questions that were fine without it, and without a suite predating Phase 5 you will not notice. The pedagogical reason is that building the harness with three trivial tasks is easy and teaches the design; building it at Phase 16 against 45 tasks is a large, unpleasant job you would be tempted to skip, and you would spend thirteen phases developing by impression. A harness built early is also a harness you trust, because you watched it catch things.

**6.7 — evals down, tests green.** Not a bug in the tests; the two signals are answering different questions and both are working. `make test-offline` passing says your parsing, control flow, budgets and error handling are unchanged — the machinery is intact, so you have not broken the plumbing. The eval drop says the *behaviour* got worse: your prompt edit changed what the model does with that intact machinery. This is the system working as designed. What to do: diff the prompt, look at the five tasks that newly fail, and read their trajectories. If the tests *had* failed too, you would be looking for a code bug instead. Being able to tell those two situations apart in one glance is most of the value of the split.

**7.1 — why JSON Schema before Phase 16?** Because JSON Schema is how you describe a tool to a model. From Phase 2 onward, every tool is exposed as a name, a description, and a `parameters` object that is a JSON Schema — that is the wire format the model sees. It is also how you constrain structured output in Phase 1: the runner accepts a schema in its `format` field and will shape the response to match. So the schema is not a web-API concern here; it is the interface language between your code and the model, and a shaky grasp of it shows up as tools the model calls with the wrong argument types.

**7.6 — what does the exhaustion test catch?** A Phase 3 agent loop that runs more iterations than you expected. Suppose you script two responses — a tool call, then a final answer — and your loop has an off-by-one in its stop condition, or fails to recognize the final answer and asks again. Without `FixtureExhausted` the fake might return the last response repeatedly (or an empty string), your test would pass, and you would ship a loop that never terminates against a real model. The named exception converts a silent behavioural bug into a loud, located failure. Generalize the principle: **make your test doubles fail loudly on unexpected use.** A permissive mock hides exactly the bugs you built it to find.

**6.10 — why quiz two and three phases back?** Because retrieval strengthens memory in proportion to how hard it was, and material from the phase you just finished is still in working memory — recalling it is easy, so it does little. Two or three phases back is roughly the interval at which you have begun to forget but can still reconstruct with effort, which is where the gain is largest. There is a second, book-specific reason: a two-phase lag tests material you have since *used*, so a wrong answer is diagnostic — it means you built on a concept you did not actually hold. Quizzing the immediately preceding phase would mostly measure short-term recall and reward cramming, missing the decay it exists to catch. What is lost is timeliness: an error introduced in Phase 8 is not surfaced by review until Phase 10, which is why the mastery checklist covers the current phase while the cumulative review covers older ones. The two mechanisms are complementary, not redundant.

---

## "Your turn" (§7.4) — `None` vs `0.0` vs raising

**`None`** (what the code does) says "not measured", which is the truth when the payload has no timing fields. Consequence: every consumer must handle `None`, which is mild friction — the `report()` function prints `n/a` — but no consumer is ever misled.

**`0.0`** would be a lie: it asserts a measurement of zero tokens per second. Consequence: it silently poisons any average, and a `docs/RESULTS.md` row of "0.0 tok/s" is indistinguishable from a genuinely stalled run. This is the worst of the three, because it fails quietly.

**Raising** says "this payload is unacceptable". Consequence: parsing becomes brittle against a provider that legitimately omits optional telemetry, and a missing performance metric — which is not needed for correctness — would abort a call whose *text* arrived perfectly well. Reserve exceptions for cases where you cannot produce a usable result at all, which is why `parse_openai_chat` *does* raise on empty `choices`: with no choices there is no answer, so there is nothing to return.

The general rule: distinguish "the data I need is absent" (raise) from "an optional extra is absent" (represent the absence honestly, never fabricate a value).

---

## Quiz (§13)

**1. Why the harness at Phase 3, twice over.** *Engineering:* it establishes the regression baseline before the system starts changing, so every later phase can answer "did that help?" with evidence rather than impression; retrofitting it at Phase 16 means thirteen phases of unmeasured drift and no way to attribute a quality change to the phase that caused it. *Learning:* building a harness against three trivial tasks is small enough to understand completely, so you learn the design — task format, scoring, reporting — while it is cheap; and running it repeatedly for thirteen phases builds the habit that separates engineers who improve agents from those who tinker with them. A secondary point: the harness shapes how you build. Knowing a task will be scored changes what you consider "done".

**2. Objections to Tier H for every sweep.** First, the **cap**: a free tier has hard daily limits, and a 45-task sweep run a few times a day will exhaust them, so your ability to measure becomes rationed exactly when you most want to iterate — and the rationing arrives mid-session, as a 429. Second, **reproducibility and dependence**: you do not control the provider's model version, replicas, or availability, so a score change may reflect their silent update rather than your edit, and your development loop now requires a network and a live third party. A third, weaker objection: a strong model masks design flaws that a small model exposes, so you learn less. **When they are right:** for a deliberate, cached, small-N comparison to answer "is this limitation my design or my model's size?" — which is exactly what Tier H is for.

**3. Generation duration vs wall-clock latency.** The runner's `eval_duration` measures only the token-generation phase. Your wall-clock `latency_s` includes everything: HTTP overhead, prompt evaluation (`prompt_eval_duration`), model loading (`load_duration`), queueing, and generation. They diverge by more than 2× whenever a non-generation cost dominates — most obviously **cold start**, where loading a multi-gigabyte model from disk can take seconds while generating six tokens takes a fraction of one (the trace in §8 shows 6.41 s wall-clock against 12.3 tok/s of generation). Long prompts do it too: a large retrieved context can make prompt evaluation exceed generation. This is why `hello-model` reports both, and why you should never quote tokens/sec as if it were latency.

**4. What is wrong with `assert "391" in answer`.** *Ground one — it asserts on model output*, so it will flake or fail on any model, runner, quantization, or prompt change, and its failure tells you nothing about whether your code is correct. *Ground two — it is a weak check even of the behaviour it targets*: "391" appears in "3915", in "391st", and in a wrong answer that happens to contain the digits; and the test passes if the model says "the answer is not 391". *Ground three — it tests the wrong component*: arithmetic is the calculator tool's job, so this test conflates "my dispatcher passed the arguments correctly" with "the model chose to use the tool" with "the model transcribed the result". Where it belongs: an **eval task** in `evals/`, scored with an exact-match or numeric-tolerance check, with the result in `docs/RESULTS.md`. What belongs in `tests/` is a fixture-driven test that a scripted tool-call request for `multiply(17, 23)` is dispatched to the calculator with those integer arguments and that its result is appended as a `tool` message.

**5. The four tiers on three axes.** *Cost:* F = 0 and no quota; A = 0 but bounded by your hardware and time; H = 0 in money but hard-capped in calls; B = real money. *Determinism:* F is fully deterministic by construction; A is reproducible-ish (you control seed, model build, and hardware, but not floating-point non-associativity); H is worse (you control neither replica nor silent model updates); B same as H. *Capability:* F has none — it only replays what you wrote; A is a small quantized model; H is mid-to-strong; B is frontier. No tier replaces the others because the axes trade off against each other: F is the only one that can be *required* by a test, since only it is free, offline and deterministic; A is the only one that is both real and unlimited, so it is the only one a sweep can run on; H is the only free way to see whether a failure is your design or your model's size; B is the only way to observe frontier behaviour, which is why it is quarantined in an appendix rather than removed.

**6. Why `require_usable()` duplicates `tier_report()`.** The concrete failure prevented: if `require_usable()` called `tier_report()`, then `Settings.from_env` would depend on Assignment 1, and a fresh clone would fail `make test-offline` before the student had written any code — the smoke test would be asserting on unfinished homework. (I hit exactly this while writing the phase; two tests failed on the skeleton.) More generally it is a layering violation: configuration validation is a *precondition* for the program running, while `tier_report` is a *presentation* concern for a diagnostic command, and making the former depend on the latter means a UI helper can break startup. The cost is real: two expressions of the same rules that can drift, so that Tier H might gain a fourth required variable in `require_usable` and not in `tier_report`. Mitigations a professional would consider: extract the shared predicate into one private function that both call (the clean fix, and a good refactor for you to do after Assignment 1), or add a test asserting the two agree for a matrix of settings. The lesson is that "don't repeat yourself" is not absolute — it loses to layering when a dependency would point the wrong way.

**7. Token arithmetic on a free tier.** Per call: 2,500 prompt + 300 completion = **2,800 tokens**.

*Per day:* 200,000 ÷ 2,800 ≈ **71 calls**. The published 1,000 requests/day is therefore irrelevant — you exhaust the token allowance at about 7% of the request allowance, so **TPD binds first**.

*Per minute:* 8,000 ÷ 2,800 ≈ 2.86, so **2 calls per minute** sustained. Against a 30 RPM limit, **TPM binds** by roughly a factor of ten. The two interact awkwardly: at the per-minute ceiling you would reach the daily ceiling in about 35 minutes of continuous use, so the practical shape is short bursts, not a steady trickle.

*After Phase 5:* retrieval adds passages to every prompt. At 5,000 tokens in and 300 out, the daily budget falls to 200,000 ÷ 5,300 ≈ **37 calls** and the per-minute figure to 1. A prompt that doubles halves your budget, linearly and without warning — which is why the cache exists before the client that uses it, and why `Settings` carries `tier_h_token_cap` alongside `tier_h_call_cap`.

The transferable habit: when a provider publishes four limits, compute all four against your real prompt size and plan against the smallest. The friendliest number is almost never the binding one.

---

## Assignment 1 — `tier_report()`

Replace the stub in `atlas/config.py`:

```python
def tier_report(settings: Settings) -> dict[str, TierStatus]:
    """Report readiness for every tier, and why or why not."""
    report: dict[str, TierStatus] = {}

    if settings.model:
        report["A"] = TierStatus(ready=True, detail=f"local model {settings.model}")
    else:
        report["A"] = TierStatus(
            ready=False, detail="set ATLAS_MODEL (see VERSIONS.md)"
        )

    missing = [
        name
        for name, value in (
            ("ATLAS_H_BASE_URL", settings.h_base_url),
            ("ATLAS_H_MODEL", settings.h_model),
            ("ATLAS_H_API_KEY", settings.h_api_key),
        )
        if not value
    ]
    if missing:
        report["H"] = TierStatus(ready=False, detail="missing " + ", ".join(missing))
    else:
        report["H"] = TierStatus(
            ready=True,
            detail=f"hosted {settings.h_model}, cap {settings.tier_h_call_cap} calls",
        )

    report["F"] = TierStatus(ready=True, detail="scripted fixtures, no network")
    report["B"] = TierStatus(ready=False, detail="paid tier is Appendix B only")
    return report
```

**Why it is shaped this way.** The three Tier H variables are collected into a list and joined, satisfying criterion 6: a reader with nothing configured learns all three names from one run instead of discovering them across three runs. The pairs are written as a tuple of `(env_var_name, value)` so the *user-facing* name appears in the message — the reader needs `ATLAS_H_API_KEY`, not `h_api_key`, because the former is what they can act on. Ready tiers still carry a detail, which is what makes `make demo` output informative rather than four bare booleans. Tier B's detail names the appendix, so a student who set `ATLAS_TIER=B` learns where to look instead of just being refused.

**Common mistakes.** Returning early on the first missing Tier H variable (fails criterion 6). Leaving `detail=""` for ready tiers (fails criterion 2). Building the dict conditionally so that a key is absent when a tier is unavailable (fails criterion 1 — callers then need `.get()` and a `KeyError` waits for someone). Reading `os.environ` inside the function instead of taking it from `settings`, which breaks invariant 4 in `ATLAS_INTERFACES.md` and makes the function untestable without monkeypatching. Using the internal attribute names in the message, which is technically informative and practically useless.

**The follow-up refactor worth doing.** Extract the Tier H missing-variable list into a module-level helper and call it from both `tier_report` and `require_usable`. That removes the duplication discussed in quiz question 6 without inverting the dependency, because the helper sits below both.

---

## Assignment 2 — `atlas/cache.py`

```python
"""Tier H response cache: hash a request, store the response, never pay twice."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


def request_key(payload: dict[str, Any]) -> str:
    """Stable sha256 hex digest of a request payload.

    Canonical JSON (sorted keys, no incidental whitespace) so that two
    logically identical requests hash alike regardless of dict ordering.
    """
    canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


class ResponseCache:
    """A flat, human-readable JSON file cache keyed by request hash."""

    def __init__(self, root: Path | str) -> None:
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        return self.root / f"{key}.json"

    def get(self, key: str) -> dict[str, Any] | None:
        path = self._path(key)
        if not path.exists():
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            return None

    def put(self, key: str, value: dict[str, Any]) -> None:
        tmp = self._path(key).with_suffix(".tmp")
        tmp.write_text(json.dumps(value, indent=2, sort_keys=True), encoding="utf-8")
        tmp.replace(self._path(key))

    def __len__(self) -> int:
        return len(list(self.root.glob("*.json")))

    def __contains__(self, key: str) -> bool:
        return self._path(key).exists()
```

**Why it is shaped this way.** `sort_keys=True` is what makes the key order-insensitive (criterion 2) — without it, two dicts built in different orders serialize differently and hash differently, so your cache misses constantly and your call budget disappears with no visible symptom. `separators=(",", ":")` removes incidental whitespace so formatting choices cannot change a key. `default=str` keeps the function from exploding on a stray non-serializable value such as a `Path`; it is a deliberate leniency, and the trade-off is that two different objects with the same `str()` would collide — acceptable here because payloads are JSON-shaped by construction.

`put` writes to a temporary file and then calls `Path.replace`, which is atomic on the same filesystem. This is the answer to the hint on criterion 7: if you write JSON directly to the final path and the process dies halfway, you have a truncated file at a valid cache key, and every future run reads a corrupt entry. Writing then renaming means a reader sees either the old complete file or the new complete file, never a partial one. `get` still tolerates corruption, because the file may have been damaged some other way, and a cache that raises on a bad entry is worse than one that re-fetches.

`indent=2` on write and hex-named files make the cache greppable, which matters more than you would think when you are debugging why an experiment did not reproduce.

**Common mistakes.** Hashing `str(payload)` or `repr(payload)` — Python's dict repr preserves insertion order, so criterion 2 fails. Hashing the *response* instead of the request. Using `pickle`, which is opaque, version-fragile, and unsafe to load. Letting `get` raise `JSONDecodeError` (criterion 7). Writing directly to the final path (the cause of the corruption in criterion 7). Building the key from only some fields — omit `temperature` or `seed` and two genuinely different requests share a key, so you will serve a cached answer for a call you meant to vary, which is the most confusing possible bug in an experiment.

**What this does not do, on purpose.** No expiry, no size limit, no locking. Those are real needs in a shared service and unnecessary for a single-student cache whose whole job is to make a repeated experiment free. Phase 16 revisits caching when Atlas becomes a service.

---

## A note on this solutions file

Every code block above was pasted back into a clean `phase-00` checkout and run against the graded suite before publication: **43 tests pass** — the 28 visible ones plus the 15 hidden. If a block fails for you, the difference is in your environment or in an edit you made; start with `make test-offline`, which must pass on the untouched skeleton.

Three of the answers above describe mistakes I made while writing this phase rather than hypotheticals: the seed default in `from_env`, `require_usable` depending on unfinished homework (quiz 6), and the token-versus-request budget, which appeared as a wrong sentence in an earlier draft of §7.5 (quiz 7). They are kept as teaching material because a corrected mistake instructs better than an example that was never wrong.
