# phase_13_solutions.md

Worked answers for Phase 13. Attempt the material first; the quiz answers in
particular are written to be checked against, not studied from.

---

## Cumulative review (§2)

**1. Interrupt placement.** LangGraph re-executes an interrupted node from its
first line, because there is no way to freeze a Python frame into a database —
the framework re-runs the function and hands a different value to one call
inside it. Two rules follow. (a) `interrupt()` is the *first* statement of its
node, so the amount of work re-run is minimal and nothing before it can have a
side effect. (b) Anything that must happen exactly once lives in a *different*
node, because a node body runs an unbounded number of times while only its
committed output runs once. Measured in Phase 10 as
`['before-interrupt', 'before-interrupt', 'after-interrupt']`.

**2. Recursion limit.** It is inherited by subgraphs, not divided among them,
so the minimum that lets the whole composition finish is
`max(level_supersteps) + 1` — the deepest single level, not the sum. The wrong
formula is adding the levels' superstep counts, which over-provisions and, more
dangerously, makes a reader think the budget is being shared when it is not.

**3. Cost split.** At `n = 3` a supervisor spends roughly 3,108 extra tokens
against Atlas's pipeline: **2,688 are the extra model calls and 420 are shared
traces.** So context sharing is 13% of the overhead and re-deciding after each
result is 87% — and the published multi-agent debate is mostly about the 13%.
The question that matters is "how often is our plan wrong mid-flight", which is
measurable and was unmeasured, which is why D-59 declines the build.

**4. The separating quantity.** The **model-call count**. "Could not do it"
still spends calls on planning; "could not run" spends zero. Every research
test injected its own planner, so the assembly was never graded — invariant 46:
test the assembly, not only the parts.

**5. The division.** `evals/tasks/*.json` grade **outcomes** (branches, partial
labels, stop reasons, answers, environment state); `tests/` grade **mechanism**
(call counts, call order, wiring). The invariant is 22: an eval check grades
what the agent produced rather than the path it took. A check on
`client.n_calls` is a path metric, so it violates the interface even while
passing — and a passing violation is worse, because nothing will tell you.

---

## Concept checks

**13.1.** *Outcome check:* after the run, `notes/daily.md` exists in the jailed
workspace and contains today's headcount. *Transcript check:* the trajectory's
`tools_called` includes `write_file` and no `write_refused` appears in the
error kinds. Only the **transcript** check would still pass if `write_file`
logged its argument and returned success without touching the disk. That is the
whole argument for Phase 13's `workspace` payload.

**13.2.** **Latency owns it**, jointly with whoever owns the product's
speed budget — and the decision is only data-driven if you were recording
latency per trial *before* the change, on the same hardware. Atlas records
`latency_s` on every `TrialResult` and no eval check has ever named it, which
is why `make results` prints "efficiency / cost graded: 0 task(s)".

**13.3.** Three non-agent explanations: (a) the ten new tasks are harder than
the existing ones, so the suite got harder rather than the agent worse — check
by computing the rate over the *old* 58 only; (b) one or more new tasks has a
broken check (a bad field path, an over-fitted expectation) — check with the
whole-suite field-path test and by reading a failing trace; (c) the new tasks
share an environment dependency that fails in a correlated way. Cheapest
distinguishing evidence: **re-run the old subset alone.** If it is unchanged,
the agent did not get worse.

**13.4.** *Worthless:* the trace was failing for an environmental reason you did
not reproduce — a stale cache, a race, a data state — so the task exercises
nothing. *Most valuable:* the failure was real and intermittent, and a task that
passes on run 1 and fails on run 7 is the only kind of evidence that
distinguishes "fixed" from "rare". Run it thirty times before deciding which
you have.

**13.5.** A grader whose expected value is derived from the corpus can be
derived *wrongly* — computing the expectation with the same off-by-one the
implementation has, for instance — and because both sides move together when
the seed changes, the check stays green forever. The practice that catches it is
the **reference solution**: a known-good answer, produced independently of the
code under test, asserted to pass every grader. If your grader passes a
reference answer you wrote by hand from the document, it is grading the
document; if it only passes output from your own pipeline, it is grading itself.

**13.6.** (a) rung 1 — a set membership test against the corpus manifest.
(b) rung 2 — a program can check the cited document is the one containing the
fact, given a labelled corpus. (c) rung 4 — genuinely a judgement. (d) rung 3 —
a structural check over the trajectory (or better, rung 1 over the workspace).
(e) rung 4, and note it is the hardest of the five: absence of an omission
cannot be decided by a parser.

**13.7.** **Quadratic-weighted kappa**, which weights a disagreement by
`((a−b)/max)²` so a 0-vs-2 costs four times a 1-vs-2. Plain kappa on ordinal
data makes an almost-right judge look random, because it throws away the
ordering: a judge that is systematically one point low scores the same as one
answering at random. `evals.agree.weighted_kappa` is the implementation, and
`test_weighted_kappa_forgives_a_near_miss_that_nominal_kappa_does_not` is the
executable form of this answer.

**13.8.** Both numbers changed for the same reason — you changed the judge —
so the second is not a measurement of the agent at all. A judged pass rate is
only comparable across runs that used **the same rubric fingerprint and the
same judge prompt version**, which is why `JudgeReport` carries both and why
`atlas_judge.v1.md` is checksum-pinned. The correct report is: "judge agreement
improved from κ 0.55 to 0.74; the agent's judged rate under the new judge is
78%, and there is no comparable prior number."

**13.9.** Wilson 95% for 3/3 is **[0.439, 1.000]**. To a manager: "three
successes out of three is consistent with a true success rate anywhere from
44% to 100%, so 'this task passes' is a statement about three samples, not
about the agent."

**13.10.** Twenty near-duplicates contribute roughly one task's worth of
independent information, so the *effective* sample size is closer to 39 than
58. Everything computed from `n` becomes a lie: the Wilson interval is too
narrow, the minimum detectable effect is understated, and — worst — a single
underlying defect flips twenty tasks at once and looks like a catastrophic
regression. De-duplicate, or cluster the duplicates and count the cluster once.

**13.11.** (a) the scaffold and harness, since agent scores swing with the
harness and not only the model; (b) the hardware and resource configuration,
which the infrastructure-noise result shows can alone exceed a three-point gap
at p < 0.01 — this is the urgent one; (c) contamination and the benchmark's age.
Bonus: cost per task, since an unmetered accuracy comparison is often a
comparison of spend.

**13.12.** A pass on re-run after a block means one of the gate's conditions
fired on a *flaky* task, which is a per-task rate somewhere strictly between 0
and 1 — the outcome flipped because it was always going to flip. The change
that prevents the ritual: raise the trial count for tasks the gate has seen
flip, and treat "became flaky" as a finding requiring a written note rather
than a re-run. A gate you can clear by pressing a button is a gate you have
already lost.

**13.13.** The mechanism is the `split: "holdout"` field, `holdout_ids()`, and
`make results` printing the count. Honestly: **none of that stops you.** It
makes the lapse visible — a reader can see the count fall — and visibility is
the whole of what tooling can offer here. The real mechanism in a team is a
different owner for the holdout file. Note also the size: the first draft of
this phase held out **one** task, which is theatre — a holdout of n=1 cannot
detect overfitting at any sample size, and its Wilson interval spans almost the
whole unit interval. Six tasks across five phases is roughly 10% of the suite
and is the smallest split that can move at all; a test now asserts both the
floor and that the holdout is drawn from at least three phases.

**13.14.** *Ship:* +0.02 across ten pairs is within the run-to-run noise of a
model judge, the prompt states the rule, the field is absent, and a judge that
is very slightly length-sensitive is still usable for relative comparisons at
fixed length. *Do not ship:* the effect is in the direction that inflates your
numbers, and inflating biases are protected from discovery by everyone's
incentives. **The number that settles it:** the run-to-run standard deviation
of the same probe on the same judge — re-run the probe five times without
changing anything. If the spread is ±0.05, +0.02 is nothing; if it is ±0.005,
+0.02 is a real effect four standard deviations out.

---

## Quiz (§13)

**Q1.** *Both `pass@k` and `pass^k` are computed from the same `(n, c)`. Why is
it wrong to compute `pass^k` as `p**k` where `p = c/n`?* — `p**k` treats the
observed rate as the true rate and then compounds it, which double-counts your
uncertainty and is biased at small `n`. The combinatorial estimator
`C(c,k)/C(n,k)` is the probability that a `k`-subset drawn from the trials you
actually ran is all successes, which is what you can estimate from `n` trials.
At `n=10, c=6, k=3`: the estimator gives 0.167, `p**k` gives 0.216.

**Q2.** *Your judge and your agent use the same model. Name the bias, and say
why the mitigation is structural rather than procedural.* — Self-enhancement
bias. Procedural mitigation ("remember to use a different model") is a
capability the caller must remember to switch on, and is therefore off in
production (invariant 58). `judge_answer` takes `agent_model` as a *required*
keyword and raises `JudgeModelCollision`, so the mistake is unrepresentable
rather than discouraged.

**Q3.** *Why does an abstention leave both sides of the fraction rather than
scoring zero?* — Because "the answer is ungrounded" and "I could not tell
whether it is grounded" call for different actions, and collapsing them creates
an optimiser that prefers a confident wrong answer to an honest one. It is
invariant 23's skip rule one layer down: a criterion the judge could not run is
not a criterion the agent failed.

**Q4.** *Your eval gate blocks on three conditions, none of which is the pass
rate. Defend that.* — Measured: a real defect moved the suite rate by 1.6
points against a minimum detectable effect of 7.7, so a rate gate would have
seen nothing. And a rate gate fires on noise, which teaches a team to re-run CI
until it passes and destroys the signal permanently. Categorical events about
named tasks are visible at sample sizes where aggregate rates are not, and they
are actionable because they name the task.

**Q5.** *A colleague reports 91% agreement between their judge and their human
labels. What do you ask, and what is the worst case consistent with that
number?* — Ask for the class balance and Cohen's κ. Worst case: the labels are
91% "pass" and the judge always says "pass" — 91% agreement, κ = 0.000, zero
information. Also ask how many labels (a κ over eight items is not evidence)
and whether the balance was constructed or sampled.

**Q6.** *Give two reasons a public benchmark score can be too high that have
nothing to do with the model being good.* — Contamination: the answers leak
onto the web through papers and repositories, and a web-enabled agent can find
them — 9 of 1,266 BrowseComp problems, with two further cases where the model
identified the benchmark and decrypted its answer key. And configuration:
infrastructure alone moved Terminal-Bench 2.0 by 6 points at p < 0.01, more
than the gap between leaderboard neighbours. A third acceptable answer: no
holdout, so the agent is overfitted to the benchmark's particulars.

**Q6b (bonus, from the revision).** *An eval check grades `judge.answer_path`
and every trial passes. What could still be wrong?* — The value may not be part
of the record at all. `apply_judge` originally wrote
`payload["judge"]["answer_path"] = ...` *after* `JudgeReport.model_dump()`, so
the key existed in the dict the harness graded and in no contract anywhere: it
was neither a field nor a computed field and did not survive `model_validate`.
Invariant 11 exists for precisely this, and nothing failed because every check
passed. The general tell, free and requiring no test: **any line that mutates a
`model_dump()` result is adding a value to the grader's namespace and not to the
record's.** See F-13-08.

**Q7.** *What does a green `make test-offline` prove about Atlas's answer
quality?* — Nothing whatsoever. Fixtures replace the model with strings you
wrote, so the offline suite proves the code *around* the model behaves:
parsing, schemas, arithmetic, control flow, budgets, refusals, field paths,
wiring, round-trips. Every claim about a model needs Tier A or H, provenance on
the result, and an interval.

---

## Assignment 1 — ATLAS-BROKEN [fast track]

**The four defects, and how each is reachable from evidence.**

**D1 — `atlas/tools/files.py`: `read_file`'s description lies.** It claims the
complete contents are always returned and that "a single call is enough",
while the tool truncates at `spec.max_output_chars`. *Evidence path:* run a
document task over a long file and read the trace — `ToolResult.truncated` is
`True` while the answer is stated without qualification. Or, faster: read
`ToolSpec.prompt_description` beside `ToolSpec.max_output_chars` and notice
they contradict each other. *Fix:* say the true thing. Deleting the overclaim
is half — the grader also asks that the description *state* that long files are
truncated, because the model cannot hedge about a limit nobody told it about.
The reference tree gained that sentence in this phase for the same reason.

**D2 — `atlas/flow/app.py`: the composition layer stopped forwarding
`max_steps`.** The `run_core(...)` call in the react handler no longer passes
it, so every route silently runs on the component default instead of the
configured budget. *Evidence path:* `build_handlers(max_steps=1)` and count the
model calls — you get the default's worth, not one. This is invariant 58's
shape: a capability the caller must remember to pass is off in production.
*Fix:* restore `max_steps=max_steps`. *Prevention:* the two hidden tests are
the prevention — one asserting the budget is honoured, one asserting a smaller
budget produces a smaller run, because a hard-coded value passes the first.

**D3 — `atlas/prompts/files/atlas_judge.v1.md`: the Rules section rewards
length.** "Reward thoroughness… a confident, well-developed answer should
score above a terse one." *Evidence path:* the padding probe. `L01/L02` and
`L03/L04` hold content fixed and vary only padding; a mean delta above +0.05 is
verbosity bias measured directly. *Fix:* restore a statement that length is not
quality. **And restore the deleted assertion** — the prompt edit was
accompanied by the removal of the test line that would have caught it, and the
checksum pin was quietly updated with no CHANGELOG entry. A fix that leaves the
check deleted fixes this instance and not the next one; invariant 59's tell is
"a diff that DELETES a check without a note".

**D4 — `atlas/flow/app.py`: the write route grants itself authority.**
`allow_writes=True if route == "tool_action" else allow_writes` ignores the
caller's refusal. *Evidence path:* `make eval-gate` blocks on
`p13-refused-write-leaves-no-file`, the negative control written in §7.4 — this
is the one defect the suite catches for you, and it is worth noticing that it
is caught by an *eval task grading the filesystem*, not by any unit test. *Fix:*
`allow_writes=allow_writes and route == "tool_action"`. *Prevention:* both
halves need a test — one proving an unauthorised write does not happen, one
proving an authorised one still does, because a gate that can never open is a
second defect (invariant 57).

**Acceptance criteria.** `make test-offline` green; `make eval-gate` passing;
`make grade` green; `docs/BROKEN_DIAGNOSIS.md` with one section per defect
covering symptom, evidence, hypothesis, proof, fix, prevention; and at least one
*new* regression test of your own per defect, written **before** the fix.

**Unaided core.** The diagnosis. Do not paste the repository into an assistant
and ask it to find the bugs. The whole value is the procedure — reproduce, read
traces before code, one hypothesis at a time, prove with a failing test — and
an assistant that hands you four answers has removed the exercise. Delegating
the *fixes* once you have proved them is fine.

**The thing most people miss.** `make test-offline` is **green** on
`atlas-broken`. All 1,433 tests pass. Three of the four defects produce no red
anywhere, and the fourth is caught only by an eval task that grades the
environment. If your instinct was to run the test suite and conclude the tree
was fine, that instinct is precisely what this assignment exists to correct.

---

## Assignment 2 — your own error-analysis pass [extended]

**What good looks like.** A `docs/ERROR_TAXONOMY_MINE.md` that a stranger could
act on: the sampling rule and its bias stated *before* the results; one open
code per trace in your own words; clusters formed after coding, not before;
counts per cluster; a fix-cost judgement written down so it can be disagreed
with; the chosen cluster with its reason; and a re-measurement, even when the
answer is "unchanged".

**The three most common failures.**

*Clustering before coding.* You walk in with categories — "prompt issues",
"retrieval issues", "model issues" — and every trace lands in one. The give-away
is a cluster containing a third of everything. Force yourself to write the
one-clause description before you have any categories at all.

*Counting occurrences instead of traces.* One defect that fires in twelve
traces is one defect. Count the distinct causes, then note how many traces each
accounts for; those are two different numbers and both matter.

*Fixing the most interesting cluster.* Priority is frequency × cost-of-missing
÷ cost-of-fixing, and the most intellectually interesting defect is rarely the
best value. Phase 13's own pass chose the *dullest* cluster — checks naming
field paths that do not exist — because it was frequent, cheap to close, and
upstream of every other decision.

**Harvesting.** Three tasks minimum, each with `source: "harvested"` and a
`derived_from` that **cites the trace or log entry**, so a reader who disagrees
can go and read it. If the expectation cannot be derived from the seeded corpus,
the task is not gradeable yet (invariant 32) — say so in the taxonomy and move
on rather than hard-coding a value.

**Unaided core.** The open coding and the clustering. An assistant will produce
a taxonomy that is fluent, plausible and yours in no sense at all, and you will
not be able to defend it when someone asks why cluster C is worth fixing.

---

## Case study (§15): the evaluation program for a support agent before launch

A strong answer is a *plan with dates and owners*, not a list of good ideas.
The rubric below is what I would grade against; the weights are the argument.

| Dimension | Weight | What full marks looks like |
|---|---|---|
| Axes chosen and justified | 15 | All seven named; outcome and safety given launch-blocking status; satisfaction acknowledged as unmeasurable offline with a plan to measure it after launch. Naming axes without saying which block a launch scores half. |
| Dataset design | 20 | Golden set from the product spec; **harvested** set from the existing human support queue, which is the highest-value source and is sitting there; a balanced set covering both "should escalate" and "should not"; provenance and a holdout with a named owner. |
| Grader design | 20 | Deterministic where possible (did the refund get processed, is the ticket state right, did it stay under N turns — all rung 1–3); a judge only for the residue that is genuinely a judgement (tone, did it explain the resolution); criteria scored independently; an abstention path. |
| Judge calibration | 15 | Hand labels before launch, deliberately balanced; Cohen's κ per criterion; a stated floor below which the judge reports and does not gate; a re-calibration schedule tied to agent changes rather than to the calendar. |
| Statistics and the launch bar | 15 | The bar is stated as `pass^k`, not `pass@k`, with a reason — a customer cannot retry your agent and cannot tell success from failure. Sample size justified against the effect they need to detect. Intervals on every reported rate. |
| Release process | 10 | An eval gate on pull requests blocking on categorical events; a scheduled full sweep; a canary with operational metrics chosen for speed of signal; explicit statement that A/B and online evaluation come after launch and why. |
| Honesty about limits | 5 | Says what the program cannot catch: anything outside the harvested distribution, anything about satisfaction, anything requiring a real customer. A submission claiming the suite establishes readiness loses all five. |

**The trap in this case study.** Support is the domain where simulated users
are most tempting, and a strong answer notices that the simulated user becomes
part of the system under test — its failures are attributed to your agent, and
the evidence that LLM-simulated users are unreliable proxies for real ones is
growing. Use them for coverage, never for the launch bar.

**The second trap.** A refund agent's safety axis is asymmetric: a missed
refund costs a complaint and an unauthorised one costs money and possibly a
regulator. Any answer that treats the two directions symmetrically — one
combined accuracy number — has designed a program that will be overruled the
first time it matters.
