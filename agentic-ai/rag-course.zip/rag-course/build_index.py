# build_index.py
from minirag.loader import load_markdown
from minirag.chunker import chunk_documents
from minirag.index import VectorIndex

chunks = chunk_documents(load_markdown("corpus"), max_tokens=200)
idx = VectorIndex(); idx.add(chunks); idx.save("index")
print(f"Indexed {len(chunks)} chunks")
