import re
from dataclasses import dataclass, field
from pathlib import Path

@dataclass
class Document:
    doc_id: str
    title: str
    text: str
    metadata: dict = field(default_factory=dict)

def load_markdown(root: str = "corpus") -> list[Document]:
    docs = []
    for p in sorted(Path(root).rglob("*.md")):
        text = p.read_text(encoding="utf-8")
        m = re.search(r"^#\s+(.+)$", text, flags=re.M)
        title = m.group(1).strip() if m else p.stem
        status = "superseded" if re.search(r"Status:\s*SUPERSEDED", text) else "current"
        rel = p.relative_to(root).as_posix()
        docs.append(Document(doc_id=rel, title=title, text=text,
                             metadata={"source": rel, "title": title, "folder": p.parent.name, "status": status}))
    return docs
