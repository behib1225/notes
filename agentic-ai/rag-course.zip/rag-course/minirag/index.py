import json
from dataclasses import asdict
from pathlib import Path
import numpy as np
import llm
from .chunker import Chunk

class VectorIndex:
    """Brute-force exact search. Fine up to roughly 100k chunks; Module 3 covers ANN indexes."""

    def __init__(self):
        self.chunks: list[Chunk] = []
        self.X = np.zeros((0, 0), dtype=np.float32)
        self.embed_model = f"{llm.EMBED_PROVIDER}:{llm.EMBED_MODELS[llm.EMBED_PROVIDER]}"

    def add(self, chunks: list[Chunk]) -> None:
        vecs = llm.embed([c.embed_text for c in chunks], kind="doc")
        self.X = vecs if not self.chunks else np.vstack([self.X, vecs])
        self.chunks.extend(chunks)

    def search_by_vector(self, q: np.ndarray, k: int = 5, where: dict | None = None):
        scores = self.X @ q
        results = []
        for i in np.argsort(-scores):
            c = self.chunks[i]
            if where and any(c.metadata.get(key) != val for key, val in where.items()):
                continue  # post-filtering: simple, but can return fewer than k results
            results.append((c, float(scores[i])))
            if len(results) == k:
                break
        return results

    def search(self, query: str, k: int = 5, where: dict | None = None) -> list[tuple[Chunk, float]]:
        return self.search_by_vector(llm.embed([query], kind="query")[0], k, where)

    def save(self, path: str = "index") -> None:
        p = Path(path); p.mkdir(exist_ok=True)
        np.save(p / "vectors.npy", self.X)
        with open(p / "chunks.jsonl", "w", encoding="utf-8") as f:
            for c in self.chunks:
                f.write(json.dumps(asdict(c)) + "\n")
        (p / "meta.json").write_text(json.dumps({"embed_model": self.embed_model}))

    @classmethod
    def load(cls, path: str = "index") -> "VectorIndex":
        p, idx = Path(path), cls()
        saved = json.loads((p / "meta.json").read_text())["embed_model"]
        if saved != idx.embed_model:  # the silent bug from Module 1, made loud
            raise ValueError(f"Index built with {saved}, but current embedder is {idx.embed_model}")
        idx.X = np.load(p / "vectors.npy")
        with open(p / "chunks.jsonl", encoding="utf-8") as f:
            idx.chunks = [Chunk(**json.loads(line)) for line in f]
        return idx
