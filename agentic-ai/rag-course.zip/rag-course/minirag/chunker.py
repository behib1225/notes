import hashlib, re
from dataclasses import dataclass, field
import tiktoken
from .loader import Document

class _WordPieces:
    """Offline fallback: roughly one 'token' per word. tiktoken downloads its vocabulary on first use,
    so fresh machines without internet (or locked-down CI) need this or a pre-filled TIKTOKEN_CACHE_DIR."""
    def encode(self, text): return re.findall(r"\s*\S+", text)
    def decode(self, pieces): return "".join(pieces)

try:
    ENC = tiktoken.get_encoding("cl100k_base")   # a good-enough token counter for any model
except Exception:
    ENC = _WordPieces()

def n_tokens(text: str) -> int:
    return len(ENC.encode(text))

@dataclass
class Chunk:
    chunk_id: str
    text: str          # what the LLM reads
    embed_text: str    # what gets embedded (text + contextual header)
    metadata: dict = field(default_factory=dict)

def split_fixed(text: str, size: int = 200, overlap: int = 40) -> list[str]:
    """Fixed-size token windows with overlap. Simple baseline."""
    ids, step = ENC.encode(text), size - overlap
    return [ENC.decode(ids[i:i + size]) for i in range(0, max(len(ids) - overlap, 1), step)]

def split_recursive(text: str, max_tokens: int = 200,
                    seps: tuple = ("\n\n", "\n", ". ", " ")) -> list[str]:
    """Split on the coarsest separator that works, packing pieces up to max_tokens."""
    if n_tokens(text) <= max_tokens:
        return [text]
    for i, sep in enumerate(seps):
        parts = text.split(sep)
        if len(parts) > 1:
            break
    else:  # no separator at all: hard split by tokens
        return split_fixed(text, max_tokens, 0)
    chunks, cur = [], ""
    for part in parts:
        candidate = cur + sep + part if cur else part
        if n_tokens(candidate) <= max_tokens:
            cur = candidate
            continue
        if cur:
            chunks.append(cur)
        if n_tokens(part) > max_tokens:
            chunks.extend(split_recursive(part, max_tokens, seps[i + 1:]))
            cur = ""
        else:
            cur = part
    if cur:
        chunks.append(cur)
    return chunks

def chunk_documents(docs: list[Document], max_tokens: int = 200, header: bool = True) -> list[Chunk]:
    out = []
    for d in docs:
        for j, piece in enumerate(split_recursive(d.text, max_tokens)):
            piece = piece.strip()
            if not piece:
                continue
            cid = hashlib.sha1(f"{d.doc_id}|{piece}".encode()).hexdigest()[:16]
            embed_text = f"{d.title}\n{piece}" if header else piece
            out.append(Chunk(cid, piece, embed_text, {**d.metadata, "chunk_index": j}))
    return out
