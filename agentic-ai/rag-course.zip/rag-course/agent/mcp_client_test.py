import asyncio
from fastmcp import Client

async def main():
    async with Client("agent/mcp_server.py") as client:     # launches the server over stdio
        print([t.name for t in await client.list_tools()])
        result = await client.call_tool("search", {"query": "E204"})
        print(result.data)

asyncio.run(main())
