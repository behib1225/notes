import sqlite3

def build_db(path="drones.db"):
    con = sqlite3.connect(path)
    con.execute("CREATE TABLE IF NOT EXISTS drones(model TEXT PRIMARY KEY, flight_time_min REAL, payload_kg REAL, "
                "range_km REAL, ip_rating TEXT, weight_kg REAL, price_usd REAL)")
    con.executemany("INSERT OR REPLACE INTO drones VALUES (?,?,?,?,?,?,?)",
                    [("Falcon X2", 42, 2.5, 12, "IP54", 3.1, 8900), ("Falcon X3", 55, 4.0, 18, "IP55", 3.6, 12400)])
    con.commit(); con.close()

def query_specs(sql: str, path="drones.db") -> str:
    s = sql.strip().rstrip(";")
    if not s.lower().startswith("select") or ";" in s:
        return "ERROR: only a single SELECT statement is allowed."
    ro = sqlite3.connect(f"file:{path}?mode=ro", uri=True)   # read-only connection: the real safeguard
    try:
        cur = ro.execute(s)
        cols = [d[0] for d in cur.description]
        return "\n".join([" | ".join(cols)] + [" | ".join(map(str, r)) for r in cur.fetchmany(50)])
    except sqlite3.Error as e:
        return f"ERROR: {e}"
    finally:
        ro.close()
