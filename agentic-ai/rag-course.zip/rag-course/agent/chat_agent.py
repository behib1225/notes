# agent/chat_agent.py  - create_agent + checkpointer memory
from langchain.agents import create_agent
from langchain_core.tools import tool
from langgraph.checkpoint.memory import InMemorySaver
from frameworks.lc_models import lc_chat
from agent import tools as T

@tool
def search_docs(query: str, folder: str | None = None) -> str:
    """Search Northwind internal documents. folder may be handbook, product, org or faq."""
    return T.search_docs(query, folder)

@tool
def calculator(expression: str) -> str:
    """Evaluate an arithmetic expression such as '3.6 + 4.0'."""
    return T.calculator(expression)

def build_agent(model=None):
    return create_agent(model or lc_chat(), tools=[search_docs, calculator], system_prompt=T.AGENT_SYSTEM,
                        checkpointer=InMemorySaver())

def ask(agent, text: str, thread: str = "demo") -> str:
    result = agent.invoke({"messages": [{"role": "user", "content": text}]},
                          config={"configurable": {"thread_id": thread}})
    return result["messages"][-1].text

if __name__ == "__main__":
    agent = build_agent()
    print(ask(agent, "What is the hotel cap in Tokyo?"))
    print(ask(agent, "And in Lisbon?"))   # needs the previous turn to make sense
