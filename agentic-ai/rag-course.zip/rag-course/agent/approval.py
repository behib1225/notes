# agent/approval.py  - human-in-the-loop: pause before a side effect, resume with a decision
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import interrupt, Command

class State(TypedDict, total=False):
    ticket: str
    status: str

def draft(s: State) -> dict:
    return {"ticket": f"Escalate E204 case to Battery Systems: {s['ticket']}"}

def approve_and_send(s: State) -> dict:
    decision = interrupt({"action": "create_ticket", "ticket": s["ticket"]})   # pauses the graph here
    if decision != "approve":
        return {"status": "cancelled by reviewer"}
    return {"status": "ticket created"}          # a real tool call (with an idempotency key) goes here

g = StateGraph(State)
g.add_node("draft", draft); g.add_node("approve_and_send", approve_and_send)
g.add_edge(START, "draft"); g.add_edge("draft", "approve_and_send"); g.add_edge("approve_and_send", END)
app = g.compile(checkpointer=InMemorySaver())   # interrupts need a checkpointer

if __name__ == "__main__":
    cfg = {"configurable": {"thread_id": "t1"}}
    first = app.invoke({"ticket": "customer 4411, battery still imbalanced after 2 charges"}, cfg)
    print("paused for review:", first["__interrupt__"][0].value)
    print(app.invoke(Command(resume="approve"), cfg)["status"])
