# agent/crag.py  - corrective RAG as an explicit LangGraph workflow
from typing import TypedDict
from langgraph.graph import StateGraph, START, END
import llm
from minirag.rag import SYSTEM
from agent.tools import HYBRID

GRADE_SCHEMA = {"type": "object", "properties": {"verdict": {"type": "string", "enum": ["sufficient", "insufficient", "not_in_corpus"]}},
                "required": ["verdict"], "additionalProperties": False}

class State(TypedDict, total=False):
    question: str
    query: str
    passages: list[str]
    verdict: str
    attempts: int
    answer: str

def retrieve(s: State) -> dict:
    hits = [f"[{c.metadata['source']}] {c.text}" for c, _ in HYBRID.search(s["query"], k=5)]
    merged = list(dict.fromkeys(s.get("passages", []) + hits))   # keep evidence from earlier rounds
    return {"passages": merged[:10]}

def grade(s: State) -> dict:
    out = llm.chat([{"role": "user", "content":
        "Can the question be fully answered from these passages? Answer 'sufficient', 'insufficient' "
        "(more searching may help) or 'not_in_corpus' (the topic is clearly absent).\n\n"
        f"Question: {s['question']}\n\nPassages:\n" + "\n".join(s["passages"])}], schema=GRADE_SCHEMA)
    return {"verdict": out.get("verdict", "insufficient")}

def rewrite(s: State) -> dict:
    q = llm.chat([{"role": "user", "content":
        f"The search query '{s['query']}' did not find enough information to answer: {s['question']}\n"
        "Write one better search query (different keywords, or the missing sub-question). Reply with the query only."}])
    return {"query": q.strip().strip('"'), "attempts": s.get("attempts", 0) + 1}

def generate(s: State) -> dict:
    sources = "\n\n".join(f'<source id="{i}">\n{p}\n</source>' for i, p in enumerate(s["passages"], 1))
    return {"answer": llm.chat([{"role": "user", "content": f"{sources}\n\nQuestion: {s['question']}"}], system=SYSTEM)}

def route(s: State) -> str:
    if s["verdict"] == "insufficient" and s.get("attempts", 0) < 2:
        return "rewrite"
    return "generate"            # sufficient, not_in_corpus (the prompt then abstains), or out of retries

g = StateGraph(State)
for name, fn in [("retrieve", retrieve), ("grade", grade), ("rewrite", rewrite), ("generate", generate)]:
    g.add_node(name, fn)
g.add_edge(START, "retrieve")
g.add_edge("retrieve", "grade")
g.add_conditional_edges("grade", route, {"generate": "generate", "rewrite": "rewrite"})
g.add_edge("rewrite", "retrieve")
g.add_edge("generate", END)
app = g.compile()

if __name__ == "__main__":
    q = "Who leads the team that handles persistent E204 escalations?"
    print(app.invoke({"question": q, "query": q, "attempts": 0})["answer"])
