# agent/loop.py  - one tool-calling loop, three provider formats
import json
import llm

def call_tool(impls, name, args) -> str:
    if name not in impls:
        return f"ERROR: unknown tool '{name}'"
    try:
        return str(impls[name](**args))[:6000]          # bound the output size
    except Exception as e:                               # errors go back to the model as text
        return f"ERROR: {type(e).__name__}: {e}"

def _parse_args(raw):
    try:
        args = json.loads(raw or "{}")
        return (args, None) if isinstance(args, dict) else ({}, "ERROR: arguments must be a JSON object")
    except json.JSONDecodeError:
        return {}, "ERROR: arguments were not valid JSON"

def run_agent(question, tools, impls, system, max_steps=6) -> dict:
    runner = {"openai": _run_openai_responses, "anthropic": _run_anthropic}.get(llm.LLM_PROVIDER, _run_chat_completions)
    return runner(question, tools, impls, system, max_steps)

def _run_openai_responses(question, tools, impls, system, max_steps):
    """OpenAI Responses API: works for every GPT-6 model (Chat Completions tool calls do not)."""
    client = llm._openai_compatible("openai")
    rs_tools = [{"type": "function", "name": t["name"], "description": t["description"],
                 "parameters": t["parameters"], "strict": False} for t in tools]   # strict needs all fields required
    items, trace = [{"role": "user", "content": question}], []
    for _ in range(max_steps):
        resp = client.responses.create(model=llm.CHAT_MODELS["openai"], instructions=system, input=items,
                                       tools=rs_tools, reasoning={"effort": llm.OPENAI_REASONING})
        calls = [o for o in resp.output if o.type == "function_call"]
        if not calls:
            return {"answer": resp.output_text, "trace": trace}
        items += resp.output                              # keep reasoning items and the calls in the history
        for c in calls:
            args, err = _parse_args(c.arguments)
            result = err or call_tool(impls, c.name, args)
            trace.append({"tool": c.name, "args": args, "result": result})
            items.append({"type": "function_call_output", "call_id": c.call_id, "output": result})
    return {"answer": "Stopped: step limit reached.", "trace": trace}

def _run_chat_completions(question, tools, impls, system, max_steps):
    """OpenAI-compatible Chat Completions format (Ollama and many other servers)."""
    client = llm._openai_compatible(llm.LLM_PROVIDER)
    oa_tools = [{"type": "function", "function": {"name": t["name"], "description": t["description"],
                                                   "parameters": t["parameters"]}} for t in tools]
    msgs, trace = [{"role": "system", "content": system}, {"role": "user", "content": question}], []
    for _ in range(max_steps):
        msg = client.chat.completions.create(model=llm.CHAT_MODELS[llm.LLM_PROVIDER], messages=msgs,
                                             tools=oa_tools).choices[0].message
        if not msg.tool_calls:
            return {"answer": msg.content or "", "trace": trace}
        msgs.append({"role": "assistant", "content": msg.content or "",
                     "tool_calls": [{"id": tc.id, "type": "function",
                                     "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                                    for tc in msg.tool_calls]})
        for tc in msg.tool_calls:
            args, err = _parse_args(tc.function.arguments)
            result = err or call_tool(impls, tc.function.name, args)
            trace.append({"tool": tc.function.name, "args": args, "result": result})
            msgs.append({"role": "tool", "tool_call_id": tc.id, "content": result})
    return {"answer": "Stopped: step limit reached.", "trace": trace}

def _run_anthropic(question, tools, impls, system, max_steps):
    client = llm._anthropic()
    an_tools = [{"name": t["name"], "description": t["description"], "input_schema": t["parameters"]} for t in tools]
    msgs, trace = [{"role": "user", "content": question}], []
    for _ in range(max_steps):
        resp = client.messages.create(model=llm.CHAT_MODELS["anthropic"], max_tokens=4096, system=system,
                                      tools=an_tools, messages=msgs, output_config={"effort": "low"})
        msgs.append({"role": "assistant", "content": resp.content})   # keep thinking + tool_use blocks intact
        if resp.stop_reason != "tool_use":
            return {"answer": "".join(b.text for b in resp.content if b.type == "text"), "trace": trace}
        results = []
        for b in resp.content:
            if b.type == "tool_use":
                out = call_tool(impls, b.name, b.input)
                trace.append({"tool": b.name, "args": b.input, "result": out})
                results.append({"type": "tool_result", "tool_use_id": b.id, "content": out})
        msgs.append({"role": "user", "content": results})
    return {"answer": "Stopped: step limit reached.", "trace": trace}

if __name__ == "__main__":
    from agent.tools import TOOLS, IMPLS, AGENT_SYSTEM
    out = run_agent("Who leads the team that handles persistent E204 escalations?", TOOLS, IMPLS, AGENT_SYSTEM)
    for step in out["trace"]:
        print("->", step["tool"], step["args"])
    print(out["answer"])
