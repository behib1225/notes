# agent/mcp_server.py
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))   # so imports work when a client launches this file

from fastmcp import FastMCP
from agent.tools import search_docs, get_document, list_documents

mcp = FastMCP("northwind-docs")

@mcp.tool
def search(query: str, folder: str | None = None) -> str:
    """Search Northwind Drones internal documents (handbook, product, org, faq).
    Returns up to 5 passages, each prefixed with its source file and status."""
    return search_docs(query, folder)

@mcp.tool
def read_document(source: str) -> str:
    """Return the full text of one document, e.g. 'org/teams.md'."""
    return get_document(source)

@mcp.resource("northwind://documents")
def documents() -> str:
    """Index of all documents with title and status."""
    return list_documents()

if __name__ == "__main__":
    mcp.run()   # stdio transport by default; never print() to stdout in a stdio server
