# finetune/baselines.py
import numpy as np
from rank_bm25 import BM25Okapi
from finetune.beir_data import download, load
from retrieval.bm25 import tokenize
from evals.metrics import ndcg_at_k, recall_at_k

corpus, queries, qrels = load(download("scifact"), "test")
ids = list(corpus)
bm25 = BM25Okapi([tokenize(corpus[i]) for i in ids])
nd, rc = [], []
for qid, q in queries.items():
    top = [ids[i] for i in np.argsort(-bm25.get_scores(tokenize(q)))[:10]]
    nd.append(ndcg_at_k(top, qrels[qid], 10)); rc.append(recall_at_k(top, qrels[qid], 10))
print(f"BM25 nDCG@10={np.mean(nd):.3f} recall@10={np.mean(rc):.3f}")
