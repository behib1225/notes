# finetune/train_embedder.py - fine-tune a small embedding model on SciFact train, evaluate on SciFact test
from datasets import Dataset
from sentence_transformers import SentenceTransformer, SentenceTransformerTrainer, SentenceTransformerTrainingArguments
from sentence_transformers.base.sampler import BatchSamplers
from sentence_transformers.sentence_transformer.losses import MultipleNegativesRankingLoss
from sentence_transformers.sentence_transformer.evaluation import InformationRetrievalEvaluator
from sentence_transformers.util import mine_hard_negatives
from finetune.beir_data import download, load

BASE = "BAAI/bge-small-en-v1.5"
QUERY_PROMPT = "Represent this sentence for searching relevant passages: "   # BGE v1.5 query instruction

path = download("scifact")
corpus, train_q, train_rel = load(path, "train")
_, test_q, test_rel = load(path, "test")

model = SentenceTransformer(BASE)
evaluator = InformationRetrievalEvaluator(test_q, corpus, test_rel, name="scifact-test", query_prompt=QUERY_PROMPT)
before = evaluator(model)
print("before:", {k: round(v, 4) for k, v in before.items() if "ndcg@10" in k or "recall@10" in k})

pairs = Dataset.from_dict({"anchor": [QUERY_PROMPT + train_q[q] for q in train_rel for _ in train_rel[q]],
                           "positive": [corpus[d] for q in train_rel for d in train_rel[q]]})
# Hard negatives: passages the base model ranks highly that are NOT labelled relevant.
# relative_margin skips "negatives" scoring almost as high as the positive (often unlabelled positives).
triplets = mine_hard_negatives(pairs, model, corpus=list(corpus.values()), range_min=10, range_max=50,
                               relative_margin=0.05, num_negatives=1, sampling_strategy="random", batch_size=64)

args = SentenceTransformerTrainingArguments(
    output_dir="models/bge-small-scifact", num_train_epochs=1, per_device_train_batch_size=32,
    learning_rate=2e-5, warmup_ratio=0.1, batch_sampler=BatchSamplers.NO_DUPLICATES,   # in-batch negatives must differ
    logging_steps=10, save_strategy="no", report_to="none")
trainer = SentenceTransformerTrainer(model=model, args=args, train_dataset=triplets,
                                     loss=MultipleNegativesRankingLoss(model))
trainer.train()

after = evaluator(model)
print("after: ", {k: round(v, 4) for k, v in after.items() if "ndcg@10" in k or "recall@10" in k})
model.save_pretrained("models/bge-small-scifact/final")
