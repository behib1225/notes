# finetune/beir_data.py - load a BEIR dataset (corpus.jsonl, queries.jsonl, qrels/{split}.tsv)
import csv, io, json, urllib.request, zipfile
from pathlib import Path

def download(name: str = "scifact", root: str = "datasets") -> Path:
    out = Path(root) / name
    if not out.exists():
        url = f"https://public.ukp.informatik.tu-darmstadt.de/thakur/BEIR/datasets/{name}.zip"
        with urllib.request.urlopen(url, timeout=120) as r:
            zipfile.ZipFile(io.BytesIO(r.read())).extractall(root)
    return out

def load(path: Path, split: str = "test"):
    corpus = {}
    with open(path / "corpus.jsonl", encoding="utf-8") as f:
        for line in f:
            d = json.loads(line)
            corpus[d["_id"]] = (d.get("title", "") + "\n" + d["text"]).strip()
    queries = {}
    with open(path / "queries.jsonl", encoding="utf-8") as f:
        for line in f:
            q = json.loads(line)
            queries[q["_id"]] = q["text"]
    qrels = {}
    with open(path / "qrels" / f"{split}.tsv", encoding="utf-8") as f:
        for row in csv.DictReader(f, delimiter="\t"):
            if int(row["score"]) > 0:
                qrels.setdefault(row["query-id"], set()).add(row["corpus-id"])
    queries = {qid: queries[qid] for qid in qrels}          # keep only queries labelled in this split
    return corpus, queries, qrels
