# parsing/parse_pdf.py - naive text extraction versus layout-aware extraction
import re
import pdfplumber
from pypdf import PdfReader

PATH = "corpus_pdf/service_bulletin_sb07.pdf"

def naive(path: str) -> str:
    return "\n".join(page.extract_text() for page in PdfReader(path).pages)

def table_to_markdown(rows) -> str:
    head, *body = [[(c or "").strip() for c in r] for r in rows]
    return "\n".join(["| " + " | ".join(head) + " |", "|" + " --- |" * len(head)] +
                     ["| " + " | ".join(r) + " |" for r in body])

def layout_aware(path: str) -> list[dict]:
    """One record per page: prose outside tables, tables as Markdown, footers removed, page number kept."""
    pages = []
    with pdfplumber.open(path) as pdf:
        for i, page in enumerate(pdf.pages, start=1):
            tables = page.find_tables()
            outside = page
            for t in tables:                                    # crop table areas out of the prose
                outside = outside.outside_bbox(t.bbox)
            prose = outside.extract_text() or ""
            prose = "\n".join(l for l in prose.splitlines() if not re.search(r"Confidential - page \d+", l))
            md_tables = [table_to_markdown(t.extract()) for t in tables]
            pages.append({"page": i, "text": "\n\n".join([prose.strip(), *md_tables]).strip()})
    return pages

if __name__ == "__main__":
    print("=== naive (pypdf) ===\n" + naive(PATH))
    print("\n=== layout-aware (pdfplumber) ===")
    for p in layout_aware(PATH):
        print(f"--- page {p['page']} ---\n{p['text']}")
