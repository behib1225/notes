# parsing/load_pdfs.py
from pathlib import Path
from minirag.loader import Document
from parsing.parse_pdf import layout_aware

def load_pdfs(root: str = "corpus_pdf") -> list[Document]:
    docs = []
    for p in sorted(Path(root).rglob("*.pdf")):
        title = p.stem.replace("_", " ")
        for page in layout_aware(str(p)):
            src = f"{p.relative_to(root).as_posix()}#page={page['page']}"
            docs.append(Document(doc_id=src, title=title, text=page["text"],
                                 metadata={"source": src, "title": title, "folder": "pdf",
                                           "status": "current", "page": page["page"]}))
    return docs
