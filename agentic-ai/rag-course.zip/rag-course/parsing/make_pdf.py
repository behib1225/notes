# parsing/make_pdf.py - a two-page PDF with prose, a table and a footer, like real company documents
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer, PageBreak

def footer(canvas, doc):
    canvas.setFont("Helvetica", 8)
    canvas.drawString(40, 20, f"Northwind Drones - Confidential - page {doc.page}")

styles = getSampleStyleSheet()
story = [Paragraph("Battery Service Bulletin SB-07", styles["Title"]),
         Paragraph("Applies to Falcon X2 and X3 batteries manufactured before January 2026. "
                   "Batteries in the affected range must be inspected at the next service visit.", styles["BodyText"]),
         Spacer(1, 12),
         Table([["Battery model", "Affected serials", "Action", "Deadline"],
                ["NB-4000", "4000-0001 to 4000-5000", "Replace", "31 March 2026"],
                ["NB-5500", "5500-0001 to 5500-1200", "Firmware update", "30 June 2026"]],
               style=TableStyle([("GRID", (0, 0), (-1, -1), 0.5, colors.grey)])),   # ruled table
         PageBreak(),
         Paragraph("Customers who already replaced an NB-4000 battery under warranty need no further action.",
                   styles["BodyText"])]
SimpleDocTemplate("corpus_pdf/service_bulletin_sb07.pdf", pagesize=A4).build(story, onFirstPage=footer, onLaterPages=footer)
print("wrote corpus_pdf/service_bulletin_sb07.pdf")
