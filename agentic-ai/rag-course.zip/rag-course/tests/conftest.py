# tests/conftest.py - offline tests: a deterministic fake embedder and a scripted fake LLM
import hashlib, re, sys
from pathlib import Path
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

def fake_embed(texts, kind="doc", batch=64, dim=256):
    """Hashed bag of words: similar wording -> similar vectors. Good enough to test plumbing, not quality."""
    X = np.zeros((len(texts), dim), dtype=np.float32)
    for i, t in enumerate(texts):
        for w in re.findall(r"[a-z0-9]+", t.lower()):
            X[i, int(hashlib.md5(w.encode()).hexdigest(), 16) % dim] += 1.0
    X += 1e-6
    return X / np.linalg.norm(X, axis=1, keepdims=True)

@pytest.fixture(autouse=True)
def offline(monkeypatch, tmp_path):
    import llm
    monkeypatch.setattr(llm, "embed", fake_embed)
    monkeypatch.chdir(ROOT)
    yield
