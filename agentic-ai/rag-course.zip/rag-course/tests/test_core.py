import math, sqlite3
import pytest
from minirag.loader import load_markdown
from minirag.chunker import chunk_documents, split_fixed, split_recursive, n_tokens
from minirag.index import VectorIndex

def test_loader_status_and_posix_paths():
    docs = {d.doc_id: d for d in load_markdown()}
    assert len(docs) == 11
    assert docs["handbook/remote_work_policy_v1.md"].metadata["status"] == "superseded"
    assert docs["handbook/remote_work_policy_v2.md"].metadata["status"] == "current"

def test_chunkers_respect_limits():
    text = " ".join(f"word{i}." for i in range(1000))
    assert all(n_tokens(c) <= 50 for c in split_recursive(text, 50))
    pieces = split_fixed(text, 100, 20)
    assert all(n_tokens(p) <= 100 for p in pieces) and len(pieces) > 1
    assert split_fixed("short", 100, 20) == ["short"]

def test_chunk_ids_are_stable():
    a = [c.chunk_id for c in chunk_documents(load_markdown(), 60)]
    b = [c.chunk_id for c in chunk_documents(load_markdown(), 60)]
    assert a == b and len(set(a)) == len(a)

def test_index_save_load_and_filter(tmp_path):
    chunks = chunk_documents(load_markdown(), 60)
    idx = VectorIndex(); idx.add(chunks); idx.save(tmp_path / "ix")
    idx2 = VectorIndex.load(tmp_path / "ix")
    assert idx2.X.shape == idx.X.shape
    res = idx2.search("remote work days", k=3, where={"status": "current"})
    assert res and all(c.metadata["status"] == "current" for c, _ in res)

def test_bm25_finds_error_code_and_hybrid_runs():          # Module 3
    pytest.importorskip("retrieval.hybrid")
    from retrieval.bm25 import BM25Retriever
    from retrieval.hybrid import HybridRetriever
    chunks = chunk_documents(load_markdown(), 60)
    bm = BM25Retriever(chunks)
    assert bm.search("E317", 1)[0][0].metadata["source"] == "product/troubleshooting.md"
    dense = VectorIndex(); dense.add(chunks)
    h = HybridRetriever(dense, bm).search("E204 battery", 3, where={"folder": "product"})
    assert h and all(c.metadata["folder"] == "product" for c, _ in h)

class C:
    def __init__(self, cid): self.chunk_id = cid

def test_rrf_matches_hand_calculation():                   # Module 3
    pytest.importorskip("retrieval.hybrid")
    from retrieval.hybrid import rrf
    A, B, Cc, D, E, F = (C(x) for x in "ABCDEF")
    fused = rrf([[(A, 0), (B, 0), (Cc, 0), (D, 0)], [(Cc, 0), (E, 0), (A, 0), (F, 0)]], top=6)
    scores = {c.chunk_id: s for c, s in fused}
    assert math.isclose(scores["A"], 1/61 + 1/63) and math.isclose(scores["C"], 1/63 + 1/61)
    assert [c.chunk_id for c, _ in fused[:2]] == ["A", "C"]          # tie broken by id

def test_metrics_hand_example():                          # Module 5
    pytest.importorskip("evals.metrics")
    from evals.metrics import hit_at_k, recall_at_k, precision_at_k, reciprocal_rank, ndcg_at_k
    ret, rel = ["B", "A", "D", "C", "E"], {"A", "C"}
    assert hit_at_k(ret, rel, 1) == 0 and hit_at_k(ret, rel, 3) == 1
    assert recall_at_k(ret, rel, 3) == 0.5 and recall_at_k(ret, rel, 5) == 1
    assert math.isclose(precision_at_k(ret, rel, 3), 1/3) and reciprocal_rank(ret, rel) == 0.5
    assert math.isclose(ndcg_at_k(ret, rel, 5), 0.651, abs_tol=1e-3)

def test_calculator_is_safe():                            # Module 6
    pytest.importorskip("agent.tools")
    from agent.tools import calculator
    assert calculator("3.6 + 4.0") == "7.6"
    for bad in ["__import__('os')", "2**10000", "open('x')", "a+1"]:
        with pytest.raises(ValueError):
            calculator(bad)

def test_tools_validate_inputs():                         # Module 6
    pytest.importorskip("agent.tools")
    from agent.tools import get_document, search_docs
    assert get_document("../../.env").startswith("Unknown source")
    assert search_docs("x", folder="secrets").startswith("Unknown folder")
    assert "troubleshooting.md" in search_docs("E204", folder="product")

def test_sql_tool_is_read_only(tmp_path):                 # Module 6
    pytest.importorskip("agent.sql_tool")
    from agent.sql_tool import build_db, query_specs
    db = str(tmp_path / "d.db"); build_db(db)
    assert "Falcon X3" in query_specs("SELECT model FROM drones WHERE flight_time_min > 50 AND price_usd < 15000", db)
    assert query_specs("DROP TABLE drones", db).startswith("ERROR")
    assert query_specs("SELECT 1; DROP TABLE drones", db).startswith("ERROR")
    assert query_specs("WITH x AS (SELECT 1) DELETE FROM drones", db).startswith("ERROR")
