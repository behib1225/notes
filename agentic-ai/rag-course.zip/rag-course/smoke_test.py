# smoke_test.py
from llm import chat, embed, LLM_PROVIDER, EMBED_PROVIDER
print(LLM_PROVIDER, "->", chat([{"role": "user", "content": "Reply with exactly: OK"}]))
v = embed(["drone battery", "battery for a drone", "expense policy"])
print(EMBED_PROVIDER, v.shape, "sim(0,1) =", round(float(v[0] @ v[1]), 3),
      "sim(0,2) =", round(float(v[0] @ v[2]), 3))
