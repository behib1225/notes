# frameworks/li_rag.py
from llama_index.core import Document, VectorStoreIndex
from llama_index.core.node_parser import MarkdownNodeParser
from llama_index.core.postprocessor import SentenceTransformerRerank
from minirag.loader import load_markdown
from frameworks.li_models import li_setup

li_setup()
docs = [Document(text=d.text, metadata=d.metadata, id_=d.doc_id) for d in load_markdown("corpus")]
index = VectorStoreIndex.from_documents(docs, transformations=[MarkdownNodeParser()])
index.storage_context.persist("li_storage")

engine = index.as_query_engine(
    similarity_top_k=10,   # stage 1: recall
    node_postprocessors=[SentenceTransformerRerank(model="cross-encoder/ms-marco-MiniLM-L6-v2", top_n=4)],  # stage 2
)

if __name__ == "__main__":
    resp = engine.query("How many days a week can I work remotely?")
    print(resp.response)
    for n in resp.source_nodes:
        print(round(n.score or 0, 3), n.metadata["source"])
