# frameworks/claude_search_results.py - your retrieval, Claude's native citations
import llm
from minirag.index import VectorIndex

idx = VectorIndex.load("index")
question = "How many days a week can I work remotely?"
blocks = [{"type": "search_result", "source": c.metadata["source"], "title": c.metadata["title"],
           "content": [{"type": "text", "text": c.text}], "citations": {"enabled": True}}
          for c, _ in idx.search(question, k=4)]
resp = llm._anthropic().messages.create(
    model=llm.CHAT_MODELS["anthropic"], max_tokens=2048, output_config={"effort": "low"},
    messages=[{"role": "user", "content": blocks + [{"type": "text", "text": question}]}])
for b in resp.content:
    if b.type == "text":
        print(b.text, [getattr(c, "source", None) for c in (b.citations or [])])
