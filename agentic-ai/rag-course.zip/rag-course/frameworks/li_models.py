# frameworks/li_models.py
import os
from llama_index.core import Settings
import llm

def li_setup():
    if llm.LLM_PROVIDER == "openai":
        # OpenAILike works with any OpenAI-compatible model name, even ones newer than the package.
        # It uses Chat Completions: fine for a query engine (no tools) with reasoning effort "none".
        from llama_index.llms.openai_like import OpenAILike
        Settings.llm = OpenAILike(model=llm.CHAT_MODELS["openai"], api_base="https://api.openai.com/v1",
                                  api_key=os.environ["OPENAI_API_KEY"], is_chat_model=True,
                                  context_window=1_000_000,
                                  additional_kwargs={"reasoning_effort": llm.OPENAI_REASONING})
    elif llm.LLM_PROVIDER == "anthropic":
        from llama_index.llms.anthropic import Anthropic
        Settings.llm = Anthropic(model=llm.CHAT_MODELS["anthropic"], max_tokens=2048)
    else:
        from llama_index.llms.ollama import Ollama
        Settings.llm = Ollama(model=llm.CHAT_MODELS["ollama"], request_timeout=120.0)

    if llm.EMBED_PROVIDER == "openai":
        from llama_index.embeddings.openai import OpenAIEmbedding
        Settings.embed_model = OpenAIEmbedding(model=llm.EMBED_MODELS["openai"])
    elif llm.EMBED_PROVIDER == "ollama":
        from llama_index.embeddings.ollama import OllamaEmbedding
        Settings.embed_model = OllamaEmbedding(model_name=llm.EMBED_MODELS["ollama"])
    else:
        from llama_index.embeddings.huggingface import HuggingFaceEmbedding
        Settings.embed_model = HuggingFaceEmbedding(model_name=llm.EMBED_MODELS["local"])
