# frameworks/openai_file_search.py - managed retrieval in about 15 lines
from pathlib import Path
from openai import OpenAI

client = OpenAI()
store = client.vector_stores.create(name="northwind")
for p in sorted(Path("corpus").rglob("*.md")):
    with open(p, "rb") as f:
        client.vector_stores.files.upload_and_poll(vector_store_id=store.id, file=f)

resp = client.responses.create(
    model="gpt-6-luna", reasoning={"effort": "none"},
    input="How many days a week can I work remotely?",
    tools=[{"type": "file_search", "vector_store_ids": [store.id], "max_num_results": 5}])
print(resp.output_text)
