# frameworks/lc_models.py
import llm

def lc_chat():
    if llm.LLM_PROVIDER == "openai":
        from langchain_openai import ChatOpenAI
        # Responses API: needed for tool calling on GPT-6.1 Terra/Sol and GPT-6 Astra, fine for Luna.
        return ChatOpenAI(model=llm.CHAT_MODELS["openai"], use_responses_api=True,
                          reasoning={"effort": llm.OPENAI_REASONING}, max_retries=llm.MAX_RETRIES)
    if llm.LLM_PROVIDER == "anthropic":
        from langchain_anthropic import ChatAnthropic
        return ChatAnthropic(model=llm.CHAT_MODELS["anthropic"], max_tokens=2048, max_retries=llm.MAX_RETRIES)
    from langchain_ollama import ChatOllama
    return ChatOllama(model=llm.CHAT_MODELS["ollama"])  # native Ollama API on localhost:11434

def lc_embeddings():
    if llm.EMBED_PROVIDER == "openai":
        from langchain_openai import OpenAIEmbeddings
        return OpenAIEmbeddings(model=llm.EMBED_MODELS["openai"])
    if llm.EMBED_PROVIDER == "ollama":
        from langchain_ollama import OllamaEmbeddings
        return OllamaEmbeddings(model=llm.EMBED_MODELS["ollama"])   # note: adds no query/doc prefixes
    from langchain_huggingface import HuggingFaceEmbeddings
    return HuggingFaceEmbeddings(model_name=llm.EMBED_MODELS["local"], encode_kwargs={"normalize_embeddings": True})
