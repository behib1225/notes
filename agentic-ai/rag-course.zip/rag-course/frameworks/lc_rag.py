# frameworks/lc_rag.py
from langchain_chroma import Chroma
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda, RunnablePassthrough
from langchain_text_splitters import MarkdownHeaderTextSplitter, RecursiveCharacterTextSplitter
from minirag.loader import load_markdown
from minirag.rag import SYSTEM
from frameworks.lc_models import lc_chat, lc_embeddings

# 1. Load and split: by Markdown heading first, then by size. chunk_size is in CHARACTERS here.
by_header = MarkdownHeaderTextSplitter([("#", "h1"), ("##", "h2")], strip_headers=False)
by_size = RecursiveCharacterTextSplitter(chunk_size=400, chunk_overlap=60)
docs = []
for d in load_markdown("corpus"):
    for piece in by_size.split_documents(by_header.split_text(d.text)):
        piece.metadata.update(d.metadata)
        docs.append(piece)

# 2. Embed and store in a persistent local vector database.
#    Re-running adds duplicates; see exercise 4.4 for deterministic IDs.
vectorstore = Chroma.from_documents(docs, lc_embeddings(), collection_name="northwind",
                                    persist_directory="chroma_db")
retriever = vectorstore.as_retriever(search_kwargs={"k": 4})

# 3. Prompt + model as an LCEL chain.
def format_docs(found) -> str:
    return "\n\n".join(f'<source id="{i}" file="{d.metadata["source"]}">\n{d.page_content}\n</source>'
                       for i, d in enumerate(found, 1))

prompt = ChatPromptTemplate.from_messages([
    ("system", SYSTEM),
    ("human", "{sources}\n\nQuestion: {question}"),
])
chain = ({"sources": retriever | RunnableLambda(format_docs), "question": RunnablePassthrough()}
         | prompt | lc_chat() | StrOutputParser())

if __name__ == "__main__":
    print(chain.invoke("How many days a week can I work remotely?"))
