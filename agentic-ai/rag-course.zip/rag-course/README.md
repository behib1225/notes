# RAG for Agentic AI Engineers: course code

Companion code for the "RAG for Agentic AI Engineers" crash course (November 2026 edition).

## Setup
```bash
python -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env        # then add your API key(s) and choose providers
python make_corpus.py       # writes the fictional Northwind Drones corpus to ./corpus
python -m pytest -q tests   # 10 offline tests, no API key needed
python smoke_test.py        # checks your chat and embedding providers
```
Run every script from this folder, e.g. `python -m agent.loop`.

## Layout
| Folder / file | Module | What it holds |
|---|---|---|
| `llm.py` | Setup | Switchable client: OpenAI (Responses API), Anthropic, Ollama; structured output; embeddings |
| `minirag/`, `build_index.py`, `ask.py` | 2 | Framework-free RAG: loader, chunker, vector index, generation with citations |
| `tests/` | 2+ | Offline tests with a fake embedder; later-module tests skip until those modules exist |
| `retrieval/` | 3 | BM25, hybrid RRF, cross-encoder reranker, query condensing, test set |
| `parsing/` | 3A | PDF generation, layout-aware parsing, PDF loader with page citations |
| `frameworks/` | 4 | LangChain and LlamaIndex versions; OpenAI file search; Claude search-result citations |
| `evals/` | 5 | Golden set (26 questions), metrics, structured-output judge, eval runner |
| `finetune/` | 5A | BEIR SciFact loader, BM25 baseline, embedding fine-tuning |
| `agent/` | 6 | Tools, three-format agent loop, corrective-RAG graph, approval interrupt, chat agent, MCP server, SQL tool |
| `prod/` | 7 | Tracer and cost ledger, FastAPI service |

## What was tested
All code that needs no API key passes the offline test suite with the pinned versions; the agent loops were
run against a mock server using the real OpenAI and Anthropic SDKs. Model behaviour, the SciFact fine-tuning run
and code that downloads models were not executed. See the course for details.
