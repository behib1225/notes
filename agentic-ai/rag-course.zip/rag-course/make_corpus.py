# make_corpus.py
from pathlib import Path

DOCS = {
"handbook/remote_work_policy_v2.md": """# Remote Work Policy (version 2)
Effective: 1 February 2026. Supersedes version 1.
Employees may work remotely up to 3 days per week with their manager's approval.
Fully remote arrangements require approval from both the manager and the VP of People.
Each employee receives a home-office equipment stipend of USD 600 per calendar year.
Core collaboration hours are 10:00 to 15:00 in the employee's local time zone.""",

"handbook/remote_work_policy_v1.md": """# Remote Work Policy (version 1)
Effective: 1 March 2024. Status: SUPERSEDED by version 2 on 1 February 2026.
Employees may work remotely up to 2 days per week with their manager's approval.
Each employee receives a home-office equipment stipend of USD 400 per calendar year.""",

"handbook/expenses.md": """# Expense Policy
Meal allowance: USD 45 per day for domestic travel and USD 70 per day for international travel.
Receipts are required for any single expense above USD 25.
Submit expense claims in Ledgerly within 30 days of the expense date. Claims older than 90 days are rejected.
Alcohol is not reimbursable. Client dinners need prior approval from a director.""",

"handbook/travel.md": """# Travel Policy
All travel is booked through TripDesk.
Flights under 6 hours: economy class. Flights of 6 hours or more: premium economy.
Hotel cap: USD 220 per night, raised to USD 300 per night in London, New York and Tokyo.
Travel to a new country needs a security briefing from the Security team at least 5 working days before departure.""",

"handbook/security.md": """# Information Security Policy
Multi-factor authentication is mandatory for all company systems.
All laptops must use full-disk encryption.
Passwords must be passphrases of at least 14 characters. Periodic password rotation is not required.
Report any suspected security incident to security@northwind.example within 1 hour of discovery.""",

"product/falcon_x2_specs.md": """# Falcon X2 Specifications
Released: June 2024. Status: still sold.
| Spec | Value |
| --- | --- |
| Flight time | 42 minutes |
| Max payload | 2.5 kg |
| Range | 12 km |
| Ingress protection | IP54 |
| Weight | 3.1 kg |
| List price | USD 8,900 |""",

"product/falcon_x3_specs.md": """# Falcon X3 Specifications
Released: March 2026. The Falcon X3 is our newest and flagship drone.
| Spec | Value |
| --- | --- |
| Flight time | 55 minutes |
| Max payload | 4.0 kg |
| Range | 18 km |
| Ingress protection | IP55 |
| Weight | 3.6 kg |
| List price | USD 12,400 |""",

"product/troubleshooting.md": """# Falcon Troubleshooting Guide (X2 and X3)
E101 - GPS lock lost: move to an open area away from buildings and recalibrate the compass.
E204 - Battery cell imbalance: stop using the battery immediately and run a balance charge in BAL mode.
If E204 persists after two balance charges, Support escalates the case to the Battery Systems team.
E317 - Motor overheat: land immediately and wait at least 10 minutes before the next flight.""",

"org/teams.md": """# Teams Directory
Flight Software: led by Priya Raman. Owns autopilot, GPS and compass firmware.
Battery Systems: led by Aiko Tanaka. Owns battery hardware, charging and battery error codes.
Customer Support: led by Marco Delgado, based in the Lisbon office.
Security: led by Femi Adeyemi.""",

"org/oncall.md": """# On-call Policy
Engineering teams run a weekly on-call rotation.
On-call compensation is USD 350 per week.
Pages must be acknowledged within 15 minutes. Unacknowledged pages escalate to the team lead after 30 minutes.""",

"faq/warranty.md": """# Warranty FAQ
Falcon X3: 24-month limited warranty. Falcon X2: 12-month limited warranty.
Batteries are covered for 6 months on both models.
Water damage is not covered when the drone was used beyond its ingress protection rating.""",
}

if __name__ == "__main__":
    for path, text in DOCS.items():
        p = Path("corpus") / path
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text.strip() + "\n", encoding="utf-8")
    print(f"Wrote {len(DOCS)} documents to ./corpus")
