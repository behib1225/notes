# ask.py   usage: python ask.py "How many days a week can I work remotely?"
import sys, json
from minirag.index import VectorIndex
from minirag.rag import answer

idx = VectorIndex.load("index")
out = answer(idx, " ".join(sys.argv[1:]))
out.pop("sources_text")
print(json.dumps(out, indent=2))
