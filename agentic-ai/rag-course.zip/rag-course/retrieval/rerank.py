import numpy as np

class Reranker:
    def __init__(self, model: str = "cross-encoder/ms-marco-MiniLM-L6-v2"):   # 22M params, CPU-friendly
        from sentence_transformers import CrossEncoder
        self.model = CrossEncoder(model)

    def rerank(self, query: str, results, top: int = 5):
        if not results:
            return []
        scores = self.model.predict([(query, c.embed_text) for c, _ in results])
        order = np.argsort(-scores)[:top]
        return [(results[i][0], float(scores[i])) for i in order]
