import llm

CONDENSE = """Rewrite the user's last message as a standalone search query, using the conversation for context.
Keep names, codes and numbers exactly. Reply with the query only.

Conversation:
{history}

Last message: {question}"""

def condense(history: list[dict], question: str) -> str:
    """Turn a follow-up like 'and in London?' into 'What is the hotel cap in London?'."""
    if not history:
        return question                                   # single-turn: no extra LLM call
    convo = "\n".join(f"{m['role']}: {m['content']}" for m in history[-6:])
    return llm.chat([{"role": "user", "content": CONDENSE.format(history=convo, question=question)}],
                    max_tokens=100).strip().strip('"')
