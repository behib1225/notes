# retrieval/testset.py  (question, file that must be retrieved)
TESTS = [
    ("E204 battery error what do I do", "product/troubleshooting.md"),
    ("Can I work from home on Fridays?", "handbook/remote_work_policy_v2.md"),
    ("hotel cap Tokyo", "handbook/travel.md"),
    ("who leads Flight Software", "org/teams.md"),
    ("how much does the X2 weigh", "product/falcon_x2_specs.md"),
    ("are batteries covered by warranty", "faq/warranty.md"),
    ("do I need a receipt for a 20 dollar lunch", "handbook/expenses.md"),
    ("how long must my password be", "handbook/security.md"),
    ("how much extra pay for being on call", "org/oncall.md"),
    ("can I fly premium economy to Tokyo", "handbook/travel.md"),
]

def hit_at_k(search_fn, k: int = 3) -> float:
    """search_fn(query, k) -> list[(chunk, score)]; fraction of tests whose file is in the top k."""
    hits = sum(any(c.metadata["source"] == src for c, _ in search_fn(q, k)) for q, src in TESTS)
    return hits / len(TESTS)
