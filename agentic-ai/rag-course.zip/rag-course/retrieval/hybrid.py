def rrf(result_lists, k: int = 60, top: int = 5):
    scores, by_id = {}, {}
    for results in result_lists:
        for rank, (chunk, _) in enumerate(results, start=1):
            scores[chunk.chunk_id] = scores.get(chunk.chunk_id, 0.0) + 1.0 / (k + rank)
            by_id[chunk.chunk_id] = chunk
    best = sorted(scores, key=lambda cid: (-scores[cid], cid))[:top]   # deterministic tie-break
    return [(by_id[cid], scores[cid]) for cid in best]

class HybridRetriever:
    def __init__(self, dense_index, bm25, fetch: int = 20):
        self.dense, self.bm25, self.fetch = dense_index, bm25, fetch

    def search(self, query: str, k: int = 5, where: dict | None = None):
        dense = self.dense.search(query, self.fetch, where=where)
        sparse = [(c, s) for c, s in self.bm25.search(query, self.fetch)
                  if not where or all(c.metadata.get(key) == val for key, val in where.items())]
        return rrf([dense, sparse], top=k)
