import re
import numpy as np
from rank_bm25 import BM25Okapi

def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())   # keeps codes like "e204" intact

class BM25Retriever:
    def __init__(self, chunks):
        self.chunks = chunks
        self.bm25 = BM25Okapi([tokenize(c.embed_text) for c in chunks])

    def search(self, query: str, k: int = 5):
        scores = self.bm25.get_scores(tokenize(query))
        top = [i for i in np.argsort(-scores)[:k] if scores[i] > 0]   # drop zero-score "matches"
        return [(self.chunks[i], float(scores[i])) for i in top]
