import json, time
from pathlib import Path
import numpy as np
from evals.golden import GOLDEN
from evals.metrics import dedupe, hit_at_k, recall_at_k, reciprocal_rank
from evals.judge import judge

def bootstrap_ci(values, n=2000, seed=0):
    v = np.array([x for x in values if x is not None], dtype=float)
    if len(v) == 0:
        return (float("nan"), float("nan"))
    rng = np.random.default_rng(seed)
    means = [rng.choice(v, len(v)).mean() for _ in range(n)]
    lo, hi = np.percentile(means, [2.5, 97.5])
    return (round(float(lo), 3), round(float(hi), 3))

def run_eval(pipeline, name: str, k: int = 3, golden=GOLDEN, use_judge: bool = True) -> dict:
    """pipeline(question) -> dict with 'answer', 'retrieved' [(source, score)], 'abstained', 'sources_text'."""
    rows = []
    for g in golden:
        t0 = time.perf_counter()
        out = pipeline(g["question"])
        row = {"id": g["id"], "category": g["category"], "latency_s": round(time.perf_counter() - t0, 2),
               "answer": out["answer"]}
        ret = dedupe(src for src, _ in out["retrieved"])
        if g["sources"]:
            row |= {"hit": hit_at_k(ret, g["sources"], k), "recall": recall_at_k(ret, g["sources"], k),
                    "rr": reciprocal_rank(ret, g["sources"])}
        if g["answer"] is None:
            row |= {"correct": float(out["abstained"]), "faithful": None}
        elif use_judge:
            v = judge(g["question"], g["answer"], out.get("sources_text", ""), out["answer"])
            row |= {"correct": None if v["correct"] is None else float(v["correct"] and not out["abstained"]),
                    "faithful": None if v["faithful"] is None else float(v["faithful"]),
                    "judge_reasoning": v["reasoning"]}
        rows.append(row)

    def mean(key, rs=rows):
        vals = [r[key] for r in rs if r.get(key) is not None]
        return round(float(np.mean(vals)), 3) if vals else None

    summary = {m: mean(m) for m in ("hit", "recall", "rr", "correct", "faithful", "latency_s")}
    summary["correct_95ci"] = bootstrap_ci([r.get("correct") for r in rows])
    summary["judge_errors"] = sum(1 for r in rows if str(r.get("judge_reasoning", "")).startswith("JUDGE_ERROR"))
    summary["by_category"] = {c: mean("correct", [r for r in rows if r["category"] == c])
                              for c in sorted({r["category"] for r in rows})}
    Path("evals").mkdir(exist_ok=True)
    with open(f"evals/results_{name}.json", "w", encoding="utf-8") as f:
        json.dump({"name": name, "summary": summary, "rows": rows}, f, indent=2)
    return summary
