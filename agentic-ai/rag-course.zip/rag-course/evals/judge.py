import llm

JUDGE = """You are grading a company Q&A assistant. Be strict and literal.

Question: {question}
Reference answer: {reference}

Retrieved sources:
{sources}

Assistant answer: {answer}

Criteria:
- correct: true if the answer states the key facts of the reference answer. Different wording is fine; extra correct detail is fine; any contradiction or missing key fact is false.
- faithful: true if every factual claim in the answer is supported by the retrieved sources (not by outside knowledge).
Write the reasoning first, then the verdicts."""

SCHEMA = {
    "type": "object",
    "properties": {"reasoning": {"type": "string"}, "correct": {"type": "boolean"}, "faithful": {"type": "boolean"}},
    "required": ["reasoning", "correct", "faithful"],
    "additionalProperties": False,
}

def judge(question, reference, sources_text, answer) -> dict:
    prompt = JUDGE.format(question=question, reference=reference, sources=sources_text, answer=answer)
    try:
        out = llm.chat([{"role": "user", "content": prompt}], max_tokens=600,
                       model=llm.JUDGE_MODEL, schema=SCHEMA)    # use a different, stronger judge model
        return {"correct": bool(out["correct"]), "faithful": bool(out["faithful"]),
                "reasoning": out.get("reasoning", "")}
    except Exception as e:                                      # keep the run going; count failures
        return {"correct": None, "faithful": None, "reasoning": f"JUDGE_ERROR: {type(e).__name__}: {e}"}
