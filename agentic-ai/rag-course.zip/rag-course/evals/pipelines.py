# evals/pipelines.py
from minirag.index import VectorIndex
from minirag.rag import answer

idx = VectorIndex.load("index")

def minirag_pipeline(q: str) -> dict:
    return answer(idx, q, k=4)    # already returns answer, retrieved, sources_text and abstained

if __name__ == "__main__":
    from evals.run_eval import run_eval
    print(run_eval(minirag_pipeline, "baseline"))
