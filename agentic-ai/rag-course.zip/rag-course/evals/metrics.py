import math

def dedupe(xs): return list(dict.fromkeys(xs))

def hit_at_k(ret, rel, k):       return float(any(r in rel for r in ret[:k]))
def recall_at_k(ret, rel, k):    return len(set(ret[:k]) & set(rel)) / len(rel)
def precision_at_k(ret, rel, k): return len(set(ret[:k]) & set(rel)) / k
def reciprocal_rank(ret, rel):   return next((1 / i for i, r in enumerate(ret, 1) if r in rel), 0.0)

def ndcg_at_k(ret, rel, k):
    dcg = sum(1 / math.log2(i + 1) for i, r in enumerate(ret[:k], 1) if r in rel)
    idcg = sum(1 / math.log2(i + 1) for i in range(1, min(len(rel), k) + 1))
    return dcg / idcg if idcg else 0.0
