# llm.py  - one switchable client for chat, structured output and embeddings
import json, os, re
from functools import lru_cache
import numpy as np
from dotenv import load_dotenv

load_dotenv()
LLM_PROVIDER = os.getenv("LLM_PROVIDER", "openai")        # openai | anthropic | ollama
EMBED_PROVIDER = os.getenv("EMBED_PROVIDER", "openai")    # openai | ollama | local
OLLAMA_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
# GPT-6 Luna, GPT-6.1 Terra and GPT-6 Sol accept "none"; GPT-6 Astra and GPT-6.1 Sol need "low" or higher.
OPENAI_REASONING = os.getenv("OPENAI_REASONING_EFFORT", "none")
TIMEOUT_S, MAX_RETRIES = 60.0, 3   # the SDKs retry 429 and 5xx errors with exponential backoff

CHAT_MODELS = {
    "openai": os.getenv("OPENAI_CHAT_MODEL", "gpt-6-luna"),
    "anthropic": os.getenv("ANTHROPIC_CHAT_MODEL", "claude-haiku-5-5"),
    "ollama": os.getenv("OLLAMA_CHAT_MODEL", "qwen3.5:4b"),
}
JUDGE_MODEL = os.getenv("JUDGE_MODEL") or None   # e.g. gpt-6.1-terra or claude-sonnet-5-5 (Module 5)
EMBED_MODELS = {
    "openai": "text-embedding-3-small",
    "ollama": "nomic-embed-text",
    "local": "BAAI/bge-small-en-v1.5",
}
# Some embedding models are trained with different prefixes for queries and documents.
PREFIXES = {
    "openai": {"query": "", "doc": ""},
    "ollama": {"query": "search_query: ", "doc": "search_document: "},
    "local": {"query": "Represent this sentence for searching relevant passages: ", "doc": ""},
}
USAGE_HOOK = None   # Module 7 sets this to record tokens and cost: fn(model, input_tokens, output_tokens)

@lru_cache(maxsize=None)
def _openai_compatible(provider: str):
    from openai import OpenAI
    if provider == "ollama":
        return OpenAI(base_url=OLLAMA_URL, api_key="ollama", timeout=TIMEOUT_S * 3, max_retries=MAX_RETRIES)
    return OpenAI(timeout=TIMEOUT_S, max_retries=MAX_RETRIES)            # reads OPENAI_API_KEY

@lru_cache(maxsize=None)
def _anthropic():
    import anthropic
    return anthropic.Anthropic(timeout=TIMEOUT_S, max_retries=MAX_RETRIES)  # reads ANTHROPIC_API_KEY

def _report(model, inp, out):
    if USAGE_HOOK:
        USAGE_HOOK(model, inp or 0, out or 0)

def parse_json(text: str) -> dict:
    """Fallback parser for providers without guaranteed structured output."""
    text = text.strip().removeprefix("```json").removeprefix("```").removesuffix("```").strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, flags=re.S)
        return json.loads(m.group(0)) if m else {}

def chat(messages: list[dict], system: str | None = None, max_tokens: int = 1024,
         model: str | None = None, schema: dict | None = None):
    """messages = [{"role": "user" | "assistant", "content": str}, ...].
    Returns the reply text, or a dict if `schema` (a JSON Schema object) is given."""
    model = model or CHAT_MODELS[LLM_PROVIDER]
    if LLM_PROVIDER == "anthropic":
        cfg = {"effort": "low"}                                   # low effort = faster, cheaper
        if schema:
            cfg["format"] = {"type": "json_schema", "schema": schema}
        # Adaptive thinking spends output tokens before the visible text, so never go below 1024.
        kwargs = dict(model=model, max_tokens=max(max_tokens, 1024), messages=messages, output_config=cfg)
        if system:
            kwargs["system"] = system
        resp = _anthropic().messages.create(**kwargs)
        _report(model, resp.usage.input_tokens, resp.usage.output_tokens)
        text = "".join(b.text for b in resp.content if b.type == "text")   # skip thinking blocks
    elif LLM_PROVIDER == "openai":                                # Responses API, OpenAI's primary API
        kwargs = dict(model=model, input=messages, reasoning={"effort": OPENAI_REASONING},
                      max_output_tokens=max_tokens)
        if system:
            kwargs["instructions"] = system
        if schema:
            kwargs["text"] = {"format": {"type": "json_schema", "name": "output", "schema": schema, "strict": True}}
        resp = _openai_compatible("openai").responses.create(**kwargs)
        _report(model, resp.usage.input_tokens, resp.usage.output_tokens)
        text = resp.output_text
    else:                                                         # Ollama: OpenAI-compatible Chat Completions
        msgs = ([{"role": "system", "content": system}] if system else []) + messages
        kwargs = {"max_tokens": max_tokens}
        if schema:
            kwargs["response_format"] = {"type": "json_schema", "json_schema": {"name": "output", "schema": schema}}
        resp = _openai_compatible("ollama").chat.completions.create(model=model, messages=msgs, **kwargs)
        if resp.usage:
            _report(model, resp.usage.prompt_tokens, resp.usage.completion_tokens)
        text = re.sub(r"<think>.*?</think>", "", resp.choices[0].message.content or "", flags=re.S).strip()
    return parse_json(text) if schema else text

@lru_cache(maxsize=None)
def _sentence_transformer():
    from sentence_transformers import SentenceTransformer
    return SentenceTransformer(EMBED_MODELS["local"])

def embed(texts: list[str], kind: str = "doc", batch: int = 64) -> np.ndarray:
    """Returns an (n, d) float32 array of L2-normalised vectors. kind = 'query' or 'doc'."""
    texts = [PREFIXES[EMBED_PROVIDER][kind] + t for t in texts]
    if EMBED_PROVIDER == "local":
        X = _sentence_transformer().encode(texts, batch_size=batch)
    else:
        client, vecs = _openai_compatible(EMBED_PROVIDER), []
        for i in range(0, len(texts), batch):
            resp = client.embeddings.create(model=EMBED_MODELS[EMBED_PROVIDER], input=texts[i:i + batch])
            vecs.extend(d.embedding for d in resp.data)
        X = np.array(vecs)
    X = np.asarray(X, dtype=np.float32)
    return X / np.linalg.norm(X, axis=1, keepdims=True)
