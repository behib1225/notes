# prod/telemetry.py  - minimal tracer and cost ledger
import json, time, uuid
from contextlib import contextmanager
from contextvars import ContextVar
from pathlib import Path

PRICES = {  # USD per 1M tokens (input, output), list prices checked Nov 2026; verify before relying on them
    "gpt-6-luna": (0.10, 0.50), "claude-haiku-5-5": (0.10, 0.50), "qwen3.5:4b": (0.0, 0.0),
}
_trace: ContextVar[dict | None] = ContextVar("trace", default=None)

@contextmanager
def trace(name: str, path: str = "prod/traces.jsonl", **attrs):
    t = {"trace_id": uuid.uuid4().hex[:12], "name": name, "attrs": attrs, "spans": [], "usage": []}
    token, start = _trace.set(t), time.perf_counter()
    try:
        yield t
    finally:
        t["total_ms"] = round((time.perf_counter() - start) * 1000, 1)
        t["cost_usd"] = round(sum(u["cost_usd"] for u in t["usage"]), 6)
        _trace.reset(token)
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        with open(path, "a", encoding="utf-8") as f:
            f.write(json.dumps(t) + "\n")

@contextmanager
def span(name: str, **attrs):
    start = time.perf_counter()
    try:
        yield attrs                      # callers can add attrs, e.g. attrs["sources"] = [...]
    finally:
        t = _trace.get()
        if t is not None:
            t["spans"].append({"name": name, "ms": round((time.perf_counter() - start) * 1000, 1), **attrs})

def record_usage(model: str, input_tokens: int, output_tokens: int):
    p_in, p_out = PRICES.get(model, (0.0, 0.0))
    t = _trace.get()
    if t is not None:
        t["usage"].append({"model": model, "in": input_tokens, "out": output_tokens,
                           "cost_usd": (input_tokens * p_in + output_tokens * p_out) / 1e6})

def install():
    """Route every llm.chat() call's token usage into the active trace."""
    import llm
    llm.USAGE_HOOK = record_usage
