# prod/app.py   run: uvicorn prod.app:app --reload
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from minirag.index import VectorIndex
from minirag.rag import answer
from prod import telemetry
from prod.telemetry import trace, span

telemetry.install()
app = FastAPI()
INDEX = VectorIndex.load("index")

class Ask(BaseModel):
    question: str = Field(min_length=3, max_length=1000)
    user_groups: list[str] = []          # in reality: derived from the authenticated user, never from the client

@app.post("/ask")
def ask(req: Ask):
    with trace("ask", question=req.question) as t:
        try:
            with span("rag"):
                out = answer(INDEX, req.question, k=4, where={"status": "current"})
        except Exception as e:
            raise HTTPException(status_code=502, detail=f"upstream error: {type(e).__name__}")
        out.pop("sources_text")
        return {"trace_id": t["trace_id"], **out}
