# phase_03_solutions.md

Worked answers for Phase 3: cumulative review, concept checks, quiz, both
assignments, and the case study. Read these *after* attempting the originals.
Where an answer is a judgement rather than a fact, I say so and give the
reasoning rather than a verdict.

---

## Cumulative review (§2)

**CR-1.** A missing `ATLAS_SEED` means "use the default seed", which is `7`;
`ATLAS_SEED=none` (or `null`, or `off`) means "send no seed at all". If a
missing variable were treated as "no seed", then everyone who never set the
variable — which is everyone, on a fresh clone — would get non-reproducible
sampling, and the default would exist only in the docstring. The general rule:
absence of configuration must mean the *documented default*, and only an
explicit value may disable a default. A silent opt-out is a default you do not
have.

**CR-2.** `final`, `step_cap`, `no_progress`, `bad_action`. The model owns only
`final`. The other three are produced by the harness: a bounded `for` over
`range(max_steps)`, a `(action, argument)` seen-set, and a tool-name lookup.
That split is D-02 in one sentence.

**CR-3.** The second term is quadratic because the *whole message list* is
re-sent on every step, and it grows by `g` tokens each step. Step 1 sends `p0`;
step 2 sends `p0 + g`; step *n* sends `p0 + (n-1)g`. Summing gives
`n·p0 + g·n(n-1)/2`. The marginal cost of step 8 is `p0 + 7g` versus step 2's
`p0 + g`, so with `g` comparable to `p0` step 8 costs roughly four times step 2.
The practical consequence: an agent that fails at step 8 has spent far more than
four times an agent that fails at step 2, which is one of three independent
arguments for a step cap.

**CR-4.** The offline suite can assert the exact **request body** —
`build_body` is pure, so a test pins that sampling parameters land in
`options`, that the output cap is `num_predict` and not `max_tokens`, that
`think` is top-level, and (new this phase) that `tools` is top-level. It can
also assert the **response parse** against a committed fixture, including
derived values like `tokens_per_s`. If the HTTP call and the parsing lived in
one function, none of that would be reachable without a network: every test
would need a live server or a mocking library, and a mock of the wire format is
a second description of the wire format that drifts.

**CR-5.** The eval harness breaks, and so does any JSON log or trace viewer. A
bare `@property` is absent from `model_dump()`, so a check naming
`trajectory.prompt_tokens` resolves to "field not present". Two Phase 1 eval
checks named exactly that. Generalised as invariant 11: if a value is part of
the contract, serialise it.

---

## Concept checks (§6)

**6.1.** Two reasons for `search_documents(query, max_results)`. *Context:* the
list-and-read tool set forces the agent to spend its scarcest resource reading
documents to discover which one is relevant — the address-book-by-brute-force
problem. The search tool moves that work into the tool, where it costs no
context at all. *Citations:* metric M1 requires the source document *and
location*. A tool returning matching passages with their document and section
hands the agent the citation as data; a `read_document(id)` tool returns a wall
of text from which the agent must *infer* which part supported its answer,
which is precisely the step where a citation gets fabricated. Note the general
shape: the tool that returns less returns more of what matters.

**6.2.** *Why tags rather than a JSON schema:* Atlas's own `VERSIONS.md`
records that on the hosted candidate, structured outputs are documented as not
supported together with tool use. A final answer arrives from a call that also
advertised tools, so requesting schema-constrained output on that call may be
refused outright. Tags cost nothing and compose with everything. *Why that
stops applying by Phase 9:* once there is an orchestrator, the final synthesis
step is a *separate* call that needs no tools, so it can be schema-constrained
while the tool-using steps are not. The general lesson is that "which
guarantee can I have" is a property of a *call*, not of a system.

**6.3.** (b) is better. Three specific defects in (a): it does not say the path
is *relative to a workspace root*, so the model will send absolute paths and
burn a step; it does not say what happens on failure, so a missing file becomes
a dead end rather than a prompt to list the directory; and it does not say the
output may be truncated, so the model cannot distinguish a short file from a
clipped one. A fourth, if you want it: "Reads a file" does not distinguish this
tool from a hypothetical `read_document` or `query_db`, so it gives the model
nothing to *select* on — and selection is most of the error rate.

**6.5.** The model sees a `tool` message with no preceding assistant turn that
asked for anything. Two likely behaviours: it re-requests the same tool call
(the transcript contains no record of having asked, so asking is the natural
next move), or it produces prose treating the tool result as an unexplained
user utterance. Phase 1's stop reasons: the first is caught by `no_progress`,
once the identical call repeats. The second is caught by nothing — it exits
`final` with an answer that may be fine or may be nonsense, which is why this
bug is more dangerous than it looks and why the fix is a test on message roles
rather than a guard.

**6.6a.** *Testing consequence:* every tool stays an ordinary callable, so
`assert calculate("(14+9)/2") == "11.50"` is a real test needing no registry,
no agent, no client and no model. A wrapper object would have made the tools
reachable only through the machinery that consumes them, which inverts the
testing pyramid. *What a wrapper could do:* intercept every call — timing,
logging, retry, caching, an approval prompt — without the caller's cooperation.
Atlas does not need it, because `execute()` is already the single choke point
and it is a better place for those concerns: it is one function rather than one
per tool, and it can see the registry, the arguments and the authority
decision together.

**6.7.** Two causes of `bad_action`: the model invented a plausible-but-absent
tool name (`search_documents` when the registry has `search_web`), or it
misspelled a real one (`querydb`). The distinguishing field is
`steps[-1].calls[0].name` compared against `tools_offered` — a near-miss by
edit distance is a typo, and a well-formed name for a capability you do not
have is a wrong mental model of the action space. They need different fixes:
the first is arguably a tolerance question, the second is a description or
namespacing question.

**6.9.** A defensible answer:

```text
quarter | region | units
2026Q1  | east   | 121
2026Q1  | north  | 78
2026Q1  | south  | 108
2026Q1  | west   | 56
(4 rows)
```

Deliberately left out: `revenue`, even though the view has it. The question
asked about units. Including revenue invites the model to mention a figure
nobody asked for, in an answer that will go into a board pack, sourced to a
query that was not about money. "Return only what was asked" is a citation
discipline, not just a token one.

**6.11.** *Hypothesis A, your prompt:* the text arm's prompt renders the full
tool list including every parameter description, so the model is better briefed
on the text arm than on the native arm — where the same information arrives in
a `tools` field the model's chat template may render sparsely or not at all.
*Hypothesis B, your tag:* the tag's `tools` capability is implemented by
prompt-guided parsing with a *worse* prompt than yours, so the native arm is
the text arm with someone else's less careful wording. *The distinguishing
measurement:* run the native arm with the tool descriptions ALSO rendered into
the system prompt (`--ablate` in reverse). If native then matches or beats
text, it was A — an information-delivery difference. If native stays behind, it
was B, and you are looking at a template problem. `ollama show --template` is
the follow-up.

**6.13.** Both are trivially reversible, so the difference is not severity, it
is **category**. `read_only` answers "does this modify anything?", and Phase
11's approval gate must answer that question from the tool's identity alone,
before arguments are validated and before anything runs. A tool that
under-declares itself because its writes are cheap has silently opted out of
every future policy that keys on the declaration — including the per-user
authority intersection in Phase 13. The Phase 11 mechanism is the approval
gate; the Phase 3 mechanism that already consumes it is `allow_writes` in
`execute()`.

**6.14.** *Model:* sampling variance — even at `temperature=0`, `T=0` is not
determinism, and a tool-selection step with a 0.7/0.3 split will flip. *Grader:*
a brittle check, most likely a `contains` on a number that the model formatted
differently ("38" vs "38 people" vs "thirty-eight"), or an over-specified
`n_steps eq`. *Environment:* leakage between trials, or an unfrozen clock, or a
corpus rebuilt with a different seed. **Look at the transcript first** — the
saved trajectory for the failing trial. It distinguishes all three in about
fifteen seconds, and no amount of re-running does.

**8.** `stop_reason` is **`final`**. That is the most dangerous possible answer
because the episode reports success: exit code 0, an answer present, a
`sources` block populated, no error kind anywhere in the trajectory. The pass
rate goes up. Every guard stayed silent because none of them was watching for
this — the guards watch for *not finishing*, and this failure finishes
beautifully. And the citation makes it worse than an uncited answer, because
`- calculate: engineering + sales` invites the user to believe a tool produced
the number, so they do not check. This is metric M2 violated by an answer that
is *correct*, which is the shape of failure that a pass rate can never surface
and a citation audit can.

**6.16 (few-shot).** A per-tool `examples` field beats a few-shot block in the
system prompt for three reasons. *Locality:* the example sits next to the tool
it demonstrates, so it is read when that tool is being considered rather than
competing for attention at the top of a long prompt. *Survival:* it travels in
the tool definition, so it reaches the native arm where a system-prompt block
would be the only channel. *Maintenance:* it lives in the decorator call next
to the signature, so a renamed parameter breaks the example in review rather
than silently in production. The cost is tokens on every step, so one or two
examples on the tools that actually get misused — not on all seven. And the
sharp warning from this phase: an `examples` field that nothing renders is
worse than no field, because a tool author writes examples and they vanish.

**6.17 (replay).** `load_trajectory` restores the *record*; `replay_trajectory`
re-executes the *loop* against the recorded model replies; `ReplayClient`
re-executes the loop **and** the parse functions against recorded raw payloads.
Only the third gives coverage of `parse_ollama_chat`, because only the third
stores what the provider actually sent. The practical rule: use
`replay_trajectory` to test a harness change with the model held fixed, and
`ReplayClient` to test a dialect change. Believing the first covers the second
means believing you have test coverage of a parser you never called.

---

## Quiz (§13)

**Q1.** Because the model's entire knowledge of a tool is its name, its
parameter schema and its description, and the schema can only constrain
*shape*. Which tool to pick, and what to put in the fields, are decided almost
entirely by the prose. A schema cannot express "do not append the current year
to this query", "this wants a department name not a person's name", or "prefer
three narrow searches to one broad one" — and those are the failures that
dominate real tool-use error rates. The dated evidence: Anthropic reported
reaching state of the art on SWE-bench Verified through precise refinements to
tool descriptions (6 Jan 2025), and reported that their own web search tool was
appending `2025` to queries until the description was improved.

**Q2.** The assistant turn that *requested* the call, and one `tool` message
per call. Two messages per call, minimum. Omitting the assistant turn is the
top cause of a loop repeating one call forever: from the model's point of view
nothing in the transcript records that it ever asked, so asking again is the
correct next move. Atlas pins this with a test asserting the second request's
roles are exactly `["system", "user", "assistant", "tool"]`.

**Q3.** `tool_name` identifies the *tool*; `tool_call_id` identifies the
*call*. They come apart the instant two calls go to one tool. Ollama's native
dialect has only `tool_name`, so result **order** is the sole correlation, and
a loop that collects parallel results as they complete will misattribute them
— silently, without an error, and intermittently. Hence D-12: sequential
dispatch in call order until Phase 8 can make the ordering a test.

**Q4.** Because a validator's security is exactly its completeness, and SQL is
large. My own `is_read_only_sql` passed `SELECT * FROM shipment`, which is
read-only and reads a base table that `ATLAS_SPEC.md` §4 forbids. The right
move was not a better regex but a *second database* containing only the curated
relations, so the base tables produce `no such table` from SQLite. The general
principle: put the guarantee where you do not own it — a read-only connection,
a database role, a file lacking the table, an absent tool. Your own check is
then an error-message optimisation rather than a security boundary, which is a
much more comfortable thing for it to be.

**Q5.** A **scripted fixture** is a response you wrote, so it proves things
about *your* code — parsing, validation, control flow, guards, budgets,
accounting — and nothing whatever about any model. It also tests a *unit* and
is silent about assembly, which is how Phase 2 shipped a per-call `CallBudget`
with 163 green tests. A **measurement** is what a real model did, on a stated
tier and model tag, at a stated seed, on a stated date. Phase 3's Tier F eval
suite reads 20/20; that number says the loop and the guards work. The same
twenty tasks on Tier A are the measurement, and they will not read 20/20.
Invariant 1 keeps the two apart: `tests/` never asserts model output.

**Q6.** Five ways, and at least three should be in your answer. (a) *Broken
graders* — a failing agent and a broken check produce the identical number; two
of my own graders were wrong on their first real run. (b) *Failure class rather
than failure instance* — one trace gives a bug, five give a pattern, and a
pattern is what a guard can be written against. (c) *Fairness calibration* —
you only learn what a fair failure looks like by reading many, and if a score
will not climb you need confidence it is the agent and not the eval. (d) *It
finds the dangerous successes* — §8's hallucinated variant passes every guard
and shows up as a pass. (e) *It tells you which layer to fix*, which a scalar
cannot. The discipline that makes it work is writing the factual account
**before** any hypothesis, because the first plausible explanation arrives
before the evidence does and then you stop collecting.

**Q7.** Because `pass@k` rises with *k* and `pass^k` falls, and they answer
different product questions. `pass@k` is the probability of at least one
success in *k* attempts — right when one success suffices and a human picks
the winner. `pass^k` is the probability that all *k* succeed: at a 75%
per-trial rate, three trials pass together with probability 0.75³ ≈ 42%. Atlas
answers questions a support engineer quotes to a customer, so consistency is
the requirement and **pass^k is the honest metric**. A task passing two runs in
three is not a passing task, and the harness names the tasks that flipped
rather than averaging them away.

**Q8.** Two orthogonal facts got one field. A task's `tier` originally meant
"the lowest tier that can run this"; the harness reused it as a routing key, so
`if settings.tier == "F" or task.tier == "F"` sent every fixture-carrying task
to `FakeLLMClient` **regardless of the requested tier**. Since every Phase 3
task carries fixtures so the suite works offline, the twenty-task golden set
could never reach a model, and `--append-results` — which checked the requested
tier rather than what happened — would have written a fixture-derived 100% pass
rate into `docs/RESULTS.md`. The fix is that `tier` states a minimum, the
client is chosen by `settings.tier` alone, and provenance is recorded per trial
so the append refuses whenever *any* trial replayed. The general lesson, which
is the sharpest in the phase: **provenance is a property of what happened, not
of what was requested** — the same rule Phase 2 reached when it stamped the
output-mode rung onto every `Completion`.

**Q9.** Nothing in the batch should run. The shipped version called `execute()`
over every call and only then set `bad_action`, so a batch of
`[write_file(...), phantom()]` performed the write and then abandoned the
episode — a side effect from a trajectory that was thrown away, which is the
worst of both outcomes. Validate the whole batch (`unknown_tool_names`), then
dispatch the whole batch. Note how the defect hid: for a *single* call,
"execute then report" and "report without executing" are indistinguishable, and
the single-call case is the one you test by habit.

---

## Assignment 1 — `atlas/safety/citations.py` (fast track)

**Full solution.**

```python
"""Audit a finished trajectory for a citation that no tool result supports.

The §8 failure: an answer that names a tool in its `sources` block when that
tool never returned a successful result. Right answer, fabricated provenance --
worse than a wrong answer, because the citation makes it look checkable.

This is a HARNESS fix, which is why it is the first of the three layers in §8's
fix order. It needs no model, it is deterministic, and it fails closed.
"""

from __future__ import annotations

import re

from pydantic import BaseModel, ConfigDict

from atlas.agents.react import ReactTrajectory

# A source line is `- tool_name: what you looked at`, per atlas_system.v1.md.
# The bullet is optional because models drop it; the colon is not, because
# without it there is no tool name to extract.
_SOURCE_LINE = re.compile(r"^\s*[-*]?\s*([a-z_][a-z0-9_]*)\s*:", re.IGNORECASE)


class CitationAudit(BaseModel):
    """The verdict. A BaseModel so an eval check can name its fields."""

    model_config = ConfigDict(extra="forbid")

    ok: bool
    fabricated: list[str] = []
    uncited: bool = False
    reason: str = ""


def parse_cited_tools(sources: str | None) -> list[str]:
    """Extract the tool names cited, in order, deduplicated. Pure.

    Only names that look like identifiers are returned, which is how
    `- general knowledge: no tool needed` correctly yields nothing: two words
    with a space is not an identifier, so it is prose rather than a claim
    about a tool.
    """
    if not sources or not sources.strip():
        return []
    found: list[str] = []
    for line in sources.splitlines():
        match = _SOURCE_LINE.match(line)
        if match:
            name = match.group(1)
            if name not in found:
                found.append(name)
    return found


def audit_citations(trajectory: ReactTrajectory) -> CitationAudit:
    """Check every cited tool against the trajectory's successful results.

    Fails closed in three ways, and the ordering of the checks matters:

      1. No answer at all -> `uncited`. Nothing was claimed, so nothing is
         verifiable; a step_cap exit is not a citation failure but it is not a
         pass either.
      2. An answer with no source lines -> `uncited`. ATLAS_SPEC.md M2.
      3. A cited tool with no successful ToolResult -> `fabricated`.

    Note what is NOT checked: whether the answer is correct. That needs a
    grader or a human. This checks whether the answer's provenance is real,
    which is a strictly weaker and entirely mechanical question -- and it is
    the one that catches §8.
    """
    if trajectory.answer is None or not trajectory.answer.strip():
        return CitationAudit(
            ok=False, uncited=True,
            reason=f"no answer to audit (stop_reason={trajectory.stop_reason})",
        )

    cited = parse_cited_tools(trajectory.sources)
    succeeded = {
        result.name
        for step in trajectory.steps
        for result in step.results
        if result.ok
    }

    if not cited:
        # An answer that used no tools and cites none is legitimate -- the
        # balanced case. An answer that DID use tools and cites none is not.
        if not trajectory.tools_called:
            return CitationAudit(ok=True, reason="no tools used, none cited")
        return CitationAudit(
            ok=False, uncited=True,
            reason=(
                "answer cites no source, but the episode called "
                f"{sorted(set(trajectory.tools_called))}"
            ),
        )

    fabricated = [name for name in cited if name not in succeeded]
    if fabricated:
        return CitationAudit(
            ok=False, fabricated=fabricated,
            reason=(
                f"answer cites {fabricated}, which returned no successful "
                f"result. Tools that did succeed: {sorted(succeeded) or 'none'}"
            ),
        )
    return CitationAudit(ok=True, reason=f"all {len(cited)} citation(s) supported")
```

**One test case worth writing that the hidden file does not cover.** An answer
citing a tool that succeeded *and* a tool that was refused with
`write_refused`. Should that fail? Argue it either way and pick: I would fail
it, because the answer is claiming provenance from an action that did not
happen. But it is a judgement, and the hidden tests deliberately do not decide
it for you.

**Why `parse_cited_tools` is separate and pure.** It is the part with all the
string handling and therefore all the edge cases: bullets, whitespace, prose
lines, duplicates, `None`. Isolating it means eleven small tests instead of
eleven trajectory constructions, and it means the audit logic reads as logic.

**Acceptance criteria recap.** `make grade PHASE=03` green on
`test_phase03_a1.py`; `audit_citations` never mutates its argument;
`CitationAudit` survives `model_dump()`; and the three fail-closed paths are
distinguishable by field, not by parsing `reason`.

---

## Assignment 2 — `atlas/tools/calendar.py` [extended]

**Full solution.**

```python
"""Calendar read and gated single-event create. The first approval-gated tool.

`docs/ATLAS_SPEC.md` §5 classifies a calendar event as reversible but
**visible outside the requesting user**, which puts it in the approval column
rather than the free column. Phase 3 has no approval gate yet, so this tool
declares `requires_approval=True` and Phase 11 is what starts honouring it.
Declaring it now is the point: the declaration lives next to the code, and a
line drawn in a spec but not in a type is a line nothing enforces.

Design decisions, each of which the hidden tests pin:

* **Two tools, not one with a `mode` parameter.** A tool that switches between
  reading and writing is two tools wearing one name and it defeats every
  read/write distinction downstream, including the gate.
* **The clock is injected**, exactly as in atlas/tools/clock.py, so "reject a
  start time in the past" is assertable rather than flaky.
* **`create_event` is idempotent.** Retrying is the loop's normal behaviour, so
  the same title at the same start is the same event, not a second one.
* **An overlap is reported, not silently accepted.** A double booking is a
  wrong answer that looks like a right one.
* **JSON on disk**, so the store survives a reload and a human can read it.
"""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Callable

from atlas.tools.registry import tool

MAX_DURATION_MINUTES = 24 * 60
_FORMAT = "%Y-%m-%dT%H:%M"


def _parse_start(raw: str) -> datetime:
    """Parse a naive local ISO timestamp, or raise with the exact format."""
    try:
        return datetime.strptime(raw.strip(), _FORMAT).replace(tzinfo=timezone.utc)
    except ValueError as exc:
        raise ValueError(
            f"{raw!r} is not a valid start time. Use ISO 8601 minutes, "
            "for example '2026-09-04T10:00'. Call current_time first if you "
            "need today's date."
        ) from exc


def make_calendar_tools(
    store: Path | str, *, now: Callable[[], datetime]
) -> tuple[Callable[..., str], ...]:
    """Build `list_events` and `create_event` over one JSON store."""
    path = Path(store)
    path.parent.mkdir(parents=True, exist_ok=True)

    def load() -> list[dict[str, object]]:
        if not path.exists():
            return []
        try:
            return list(json.loads(path.read_text(encoding="utf-8")))
        except (json.JSONDecodeError, TypeError):
            # A corrupt store is treated as empty rather than fatal: the tool
            # is more useful degraded than absent, and the alternative is an
            # episode that dies on a file the model cannot fix.
            return []

    def save(events: list[dict[str, object]]) -> None:
        path.write_text(json.dumps(events, indent=2, sort_keys=True), encoding="utf-8")

    @tool(name="list_events", read_only=True, max_output_chars=1_200)
    def list_events(date: str) -> str:
        """List the calendar events on one day.

        Args:
            date: The day to list, as 'YYYY-MM-DD', for example '2026-09-04'.
        """
        try:
            datetime.strptime(date.strip(), "%Y-%m-%d")
        except ValueError as exc:
            raise ValueError(
                f"{date!r} is not a date. Use 'YYYY-MM-DD'."
            ) from exc
        same_day = sorted(
            (e for e in load() if str(e["start"]).startswith(date.strip())),
            key=lambda e: str(e["start"]),
        )
        if not same_day:
            return f"{date}: no events."
        return "\n".join(
            f"{str(e['start'])[11:]} ({e['duration_minutes']} min)  {e['title']}"
            for e in same_day
        )

    @tool(name="create_event", read_only=False, requires_approval=True,
          max_output_chars=400)
    def create_event(
        title: str, start: str, duration_minutes: int, dry_run: bool = False
    ) -> str:
        """Create one calendar event. Visible to other people, so it is gated.

        Args:
            title: A short description of the event, as it will appear to
                everyone who can see the calendar.
            start: When it begins, as 'YYYY-MM-DDTHH:MM', for example
                '2026-09-04T10:00'. Must be in the future.
            duration_minutes: How long it lasts, from 1 to 1440.
            dry_run: When true, report what would be created without creating
                anything. Use this to confirm the time before committing.
        """
        if not title.strip():
            raise ValueError("title is empty; an event needs a description")
        if not 1 <= duration_minutes <= MAX_DURATION_MINUTES:
            raise ValueError(
                f"duration_minutes must be between 1 and "
                f"{MAX_DURATION_MINUTES}, got {duration_minutes}"
            )
        begins = _parse_start(start)
        if begins <= now():
            raise ValueError(
                f"{start} is in the past (it is now "
                f"{now().strftime(_FORMAT)}). Choose a future time."
            )
        ends = begins + timedelta(minutes=duration_minutes)

        events = load()
        for existing in events:
            other_start = datetime.strptime(
                str(existing["start"]), _FORMAT
            ).replace(tzinfo=timezone.utc)
            other_end = other_start + timedelta(
                minutes=int(existing["duration_minutes"])
            )
            if str(existing["title"]) == title.strip() and other_start == begins:
                # Idempotent: the same event, asked for twice.
                return f"'{title}' already exists at {start}; nothing changed."
            if begins < other_end and other_start < ends:
                raise ValueError(
                    f"conflicts with '{existing['title']}' at "
                    f"{existing['start']} ({existing['duration_minutes']} min). "
                    "Choose another time, or list_events first."
                )

        if dry_run:
            return (
                f"dry run: would create '{title.strip()}' at {start} for "
                f"{duration_minutes} min. Nothing was created."
            )
        events.append({
            "title": title.strip(),
            "start": begins.strftime(_FORMAT),
            "duration_minutes": duration_minutes,
        })
        save(events)
        return f"created '{title.strip()}' at {start} for {duration_minutes} min."

    return list_events, create_event
```

**Two things students commonly get wrong here.**

*Making `create_event` idempotent by ignoring duplicates silently.* The version
above *reports* that the event already exists, which is different: the model
learns that its retry was unnecessary and does not conclude that its first
attempt failed. Silence would leave it uncertain, and an uncertain agent
retries.

*Putting the approval logic in the tool.* It does not belong here. The tool
*declares* `requires_approval=True`; the decision to prompt belongs to the
dispatch layer, because that is where the human, the audit log and the episode
identity live. A tool that prompts is a tool you cannot use in a batch, cannot
test offline, and cannot reuse under a different policy.

---

## Case study (§15) — worked answer and rubric application

**A defensible tool set for a customer-support agent.**

| Tool | Expose? | R/W | Gate | Reasoning |
|---|---|---|---|---|
| `search_help_articles(query)` | yes | R | none | The highest-volume need, and search-not-list for the context reason |
| `get_ticket(ticket_id)` | yes | R | none | Scoped to one ticket; no `list_all_tickets` |
| `search_tickets(query, customer_id)` | yes | R | none | Scoped by customer, so it cannot become a fishing tool |
| `get_customer_context(customer_id)` | yes | R | none | One consolidated call instead of three chained ones |
| `get_order_status(order_id)` | yes | R | none | Read-only, high value, trivially reversible |
| `add_ticket_note(ticket_id, note)` | yes | W | none | Internal, reversible, invisible to the customer |
| `set_ticket_status(ticket_id, status)` | yes | W | none | Reversible, `status` a `Literal` so the state machine is in the schema |
| `escalate_ticket(ticket_id, reason)` | yes | W | **approval** | Consumes a human's time and is visible to colleagues |
| `issue_refund(order_id, amount)` | yes | W | **approval** + cap | Money. Gated, capped, and the cap is in the schema not the prompt |
| `send_customer_email(...)` | **no** | W | — | Irreversible and externally visible. There is no gate that makes an already-sent email un-sent |
| `apply_account_credit`, `cancel_subscription` | **no** | W | — | Financial and contractual; a human does these |
| `run_sql(query)` | **no** | — | — | Unbounded read of everything, including data the requester may not see |
| `delete_ticket`, `merge_customers` | **no** | W | — | Destructive and not reversible from the agent's side |
| `read_internal_wiki(path)` | qualified | R | none | Only if the wiki excludes HR and security content at the *source*, not by filtering answers |

**The three answers that carry the most weight, and why.**

*No `send_customer_email`.* This is the one most teams get wrong, because it is
the most obviously useful. The test in §6.12 is whether an approval gate is
sufficient, and for outbound email it is not: a gate protects against the agent
acting wrongly, but the failure mode here is a *human approving quickly* on the
fiftieth prompt of the day. Draft-only — the agent writes, a human sends from
their own client — keeps the capability and removes the risk, at the cost of
some latency. That trade is the answer, and stating the cost is part of it.

*No `run_sql`.* Not because SQL is dangerous — the read-only guard handles that
— but because an unbounded read has no natural scope, and a support agent
acting on behalf of one customer must not be able to read another's data. This
is the confused-deputy risk, R4, and the fix is scoped tools
(`search_tickets(customer_id=...)`) rather than a general query tool plus a
filter.

*`issue_refund` gated **and** capped in the schema.* A gate alone puts the
entire amount range in front of a human who will approve most of them.
`amount: float` with a documented maximum, validated in the tool, means the
agent cannot even *propose* a five-figure refund — the prompt is only ever for
amounts within policy. Constraining the action space beats reviewing the
actions.

**Applying the rubric to a common weak answer.** A student who exposes a
`run_sql` tool with a read-only guard and calls it safe scores full marks on
*mechanism* (the guard is real) and loses most of *scoping* and *authority*:
the tool is read-only and still lets a support agent reach every customer's
data. The correction is not a better guard, it is a narrower tool — the same
lesson as F-03-04, arriving in a different domain. That symmetry is the reason
this case study is in this phase rather than a later one.
