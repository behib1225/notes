# appendix_e_solutions.md

Solutions for Appendix E — *Governance, Regulation, and Professional Obligations for Agent Builders*. Work the exercises before reading. The two assignments have model answers **and** rubrics; grade your own against the rubric first, then read the model, because the gap between them is the lesson.

Regulatory status below is as of 15 September 2026 and carries exactly the standing set out in §1 of the appendix.

---

## Concept check answers

### 6.1 — the gated file write

**It changes "what does the system do", and only barely; it leaves the other three untouched.**

The write is an *effect on the operator's own workspace*, authorised per episode by the intersection of route and tier, and stopped for a human who is shown a rendered consequence before deciding. It moves Atlas from "answers questions" to "answers questions and makes a small, reversible change inside a jail" — which matters for internal change control and for the audit trail, and approaches no Annex III category, because it produces no decision *about a person*.

Unchanged: the user is still authenticated staff; where those users are is a deployment fact the code cannot affect; building-and-running still makes the operator both provider and deployer.

The trap is assuming that "can take an action" is the regulated property. It is not. **Consequence-to-a-person is the regulated property.** A write to your own workspace has almost none; a purely read-only system that ranks job applicants and emits no side effect at all sits in a far heavier tier than Atlas's `tool_action` route. Capability and regulatory weight are close to orthogonal, which is why §2 of the system card does more regulatory work than §4.

### 6.8 — the injection signal's two wrong answers

*(This check appeared in the first draft's [extended] section, which the revision cut. The answer is kept because the distinction it teaches is load-bearing.)*

**Yes, mention it — under "Safeguards and their limits" (§9 of the card), not under "Known failure modes" (§8).**

A failure mode is something that went wrong and was fixed or logged as a defect. The injection signal scoring 1 on `rt-doc-03` (a benign document that *discusses* injection) and 0 on `rt-skill-01` (a genuinely poisoned skill) is not a defect: it is the measured behaviour of a free, deterministic detector, published beside the mechanism so that nobody mistakes it for a decision procedure. That is why `atlas/safety/trust.py` wires it to a warning line and to no decision, and why `require_tightening` raises if you try to use a signal to *grant* rather than to *tighten*.

Putting it in §9 also forces the sentence that makes the whole card credible: a false positive on document one and a false negative on document four, on the suite the authors wrote themselves. A reviewer who reads that stops looking for the thing you hid.

Half credit for "§8". Full credit only if you also said what the measurement licenses: the detector is a **layer** — the attacker passes it by writing different words — and the **boundaries** are the registry, the permission tier and the absent network interface.

### "Your turn" exercises — how to mark your own

**§6.1 (four answers for your own system).** A good answer has no technology nouns in it. "A FastAPI service with pgvector" fails; "answers support agents' questions over our ticket history, for 12 internal agents, all in Ontario, built and run by us" passes. If your "what does it do" line could describe three different products, it is not specific enough to scope.

**§6.7 (your weakest of the five).** A good answer names a *mechanism*, not an intention. "Be careful with PII in logs" fails; "an allowlist over exported attribute keys, with scrubbing after it, and eval fixtures built from a seeded generator" passes. The residual sentence is the one most people skip and the one a reviewer reads first — if you cannot state a residual, you have not understood the mechanism.

---

## Quiz answers

**1. Fine-tune, rebrand, sell to three customers.**

*Who is the user* changes (external customers, not internal staff) and *what role you play* changes: placing a system on the market under your own name makes you a provider of it, and substantially modifying or rebranding someone else's system can make you its provider too. *Where they are* usually changes as a consequence — three customers are three jurisdictions until proven otherwise. *What it does* may not change at all, which is the trap: same artefact, same prompts, now carrying provider duties, a contract per customer, and a support obligation when it is wrong.

The consequence students miss: you now owe your customers the information they need to be competent deployers — what it is for, what it must not be used for, what it cannot do. That is a system card, and it has become a deliverable rather than a portfolio nicety.

**2. What the Digital Omnibus moved, and what it did not.**

Regulation (EU) 2026/1744 deferred the high-risk obligations in Chapter III, Sections 1–3, to **2 December 2027** (Annex III stand-alone) and **2 August 2028** (Annex I embedded). It left the **2 August 2026** general application date alone, so Article 50 transparency duties apply, with only a four-month transitional window for the Article 50(2) marking obligation for generative systems already on the market. It softened Article 4 into a duty of effort and added two Article 5 prohibitions.

Why the distinction beats the headline: "the AI Act was delayed" produces two opposite errors. A team hearing "delayed" stops preparing and misses the transparency duties that bind now. A team hearing "unchanged" spends a year on a conformity-assessment programme sixteen months early instead of on controls it would have built anyway. The accurate sentence: **the paperwork moved, the disclosure did not, and the requirements arriving in 2027 are the ones a competent team builds regardless.**

**3. Boundary vs layer, applied to the approval gate.**

The test: *what must the attacker do to pass it?* If the answer is "write different words", it is a layer. If passing requires an object the attacker cannot obtain — a tool absent from the registry, a scope absent from the token, a network interface that does not exist — it is a boundary. The export allowlist is a boundary because the key never made the list, whatever the value says; the redaction patterns are a layer, because base64, a homoglyph, or splitting a number across two attributes all pass.

The approval gate is **a boundary against the model and a layer against the human.** No token sequence the model emits reaches `write_file`, `remember`, `run_python` or `company_note_append` without a recorded human decision — there is no phrasing that bypasses it. But that decision is a person reading one rendered sentence, and persuading a person is exactly "write different words". This is ASI09's arithmetic: the thirtieth prompt of the hour is not read. Hence the card's limit line (*does not scale; approval rate unmeasured*) and residual risk 6, accepted rather than claimed away.

**4. Evidence for "the audit log records every consequential action against the subject who caused it."**

Show three things:

1. The **entry point** — `atlas.safety.audit:AuditLog` — whose constructor requires `subject`, so an entry without one cannot be built.
2. The **test** reaching that refusal: `tests/test_safety_phase14.py::test_an_audit_entry_without_a_subject_is_refused`.
3. The **eval task** grading it on the default path: `p14-every-audited-action-names-a-subject`. This is the one that matters, because 1 and 2 prove the mechanism works *when called*, and only 3 speaks to whether it is called.

What the evidence still does not prove: **that the set of actions classed as consequential is the right set.** The manifest verifier resolves entry points, parses tests and looks up task ids — it does not run them, and nothing checks the audited-action set against the *gated* set or against the tool registry. A fifth gated tool added next quarter with no audit call site passes all three artefacts silently. Say so in card §3, which does: *verification proves a claim is attached to evidence that exists, never that the evidence is good.*

**5. Adding `gen_ai.input.messages` for one week.**

*For:* the bug is probably visible only in the assembled prompt — which chunks, in what order, inside what budget. Reproducing from fixtures may cost days the export would cost minutes, and every live hour produces bad answers.

*Against:* the allowlist is the only boundary. The moment content keys are on it, every downstream consumer has received user text and cannot un-receive it; retention is the collector's, not yours. It is one line to add and a quarter to undo — and the test asserting the absence of content attributes would have to be edited to land it, which is the system telling you something.

*Decision:* **no.** Local spans keep whatever you put on them; the allowlist is a boundary *at the export*, not at the span. Attach the full prompt locally, reproduce under `ATLAS_TIER=F` against the seeded corpus, and if that genuinely cannot reproduce it, add a **derived, non-content** key instead: chunk ids, chunk count, token totals, an order hash. Record the decision and the reviewer in `docs/DECISIONS.md`, because the next person under deadline will propose it again and deserves to find the argument rather than re-run it.

Naming the local/exported distinction is required for full credit. "No, privacy" is half an answer; the point is that the debugging need is real and has a cheaper solution than a boundary change.

**6. Why seven stated residual risks beats none.**

Because a threat model with no residual risks is a wish, and every reviewer knows it. The list is the only section that costs its author something, so it is the only section carrying information. A card with no limitations says either that nobody looked or that somebody looked and edited; either way the reviewer's next move is to hunt for the omission, and the whole document is under suspicion. A numbered, owned, unmitigated list converts the reviewer's job from *find the lie* to *decide whether I accept these seven* — a conversation you can have, and the one you want.

---

## Assignment 1 — model answer and rubric

### Model note (one page)

```markdown
# Readiness note — Atlas for <Practice>, internal staff deployment
Prepared by <name>, 2026-09-15. Decision requested from <managing partner> by 2026-09-29.

**1. Scoping.** Three distinct uses, assessed separately.
  A (proposed): answers staff questions over project documents and the job-costing
    database, with citations; gated file write and note append. Users: 40 employees,
    authenticated, 38 in Canada and 2 working from Lisbon. Role: provider and deployer.
  B (marketing): the same system answering prospective clients on the public website.
    Users: anonymous members of the public, location unknown. Role unchanged, exposure not.
  C (HR): ranking incoming portfolio submissions. Users: the submitters, who can be
    refused something. Role unchanged.

**2. Obligations this opens.**
| Regime | Status as of 2026-09-15 | Turns on |
|---|---|---|
| AI Act Art. 4 (AI literacy) — duty of effort, not tiered by risk | applies now | whether our Lisbon staff make us a deployer in the Union, or their use makes output "used in the Union" (Art. 2). **Unresolved — counsel.** |
| AI Act Art. 50(1) (tell a person they are dealing with an AI) | applies since 2 Aug 2026 | same question; engaged immediately for use B regardless, since the public includes EU residents |
| AI Act Annex III §4 (employment: recruitment, filtering applications, evaluating candidates) → high-risk regime | applies from 2 Dec 2027 | **use C only**, and on whether the portfolios are job applications rather than client submissions. If they are, this is a different system class, not a feature. |
| GDPR (employee data; for B, visitor data) | applies now | the Lisbon staff; any EU visitor under B |
| Canadian private-sector privacy law | applies now | our province, and whether employee data is covered there — PIPEDA's employee reach is limited to federal works and undertakings. **Unresolved — counsel.** |
Primary sources in the working notes.

**3. What we already have.**
| Obligation | Artefact |
|---|---|
| Per-subject authority | `atlas/safety/permissions.py`; four tiers intersected with the route table; `tests/test_safety_phase14.py::test_the_permitted_set_is_an_intersection_never_a_union` |
| Approval before consequential action | `atlas/graph/approval.py`; four gated tools (`write_file`, `remember`, `run_python`, `company_note_append`); task `p10-a-a-refused-write-touches-nothing-and-is-recorded` |
| Attributable record | `atlas/safety/audit.py` (subject required; argument digests, not bytes); task `p14-every-audited-action-names-a-subject` |
| No content leaves the process | `atlas/obs/redact.py` `ATTRIBUTE_ALLOWLIST`; task `p15-no-prompt-text-survives-the-export-boundary` |
| Exfiltration channel closed | `atlas/safety/egress.py`, deny-all default; task `p14-no-outbound-url-survives-the-answer` |
| Thread ownership checked, not assumed | `tests/test_api_phase15.py::test_a_thread_id_is_not_a_bearer_token` |
| Evaluation with dated, tiered figures | `evals/`, `docs/RESULTS.md`, `docs/ENGINEERING_SUMMARY.md` |
| Stated residual risk | `docs/THREAT_MODEL.md`, seven numbered items |

**4. Gaps.**
| Gap | Who is exposed | Effort | Blocks launch? |
|---|---|---|---|
| Model tier, provider, regional endpoint, retention and training-use settings unrecorded | every user; residency unanswerable | 0.5 d to pin in `Settings` + 1 d to confirm terms | **Yes** (use A) |
| Confirm `unsafe_code=False` in the deployed registry (it swaps the container for a subprocess) | anyone whose request reaches `run_python` | 0.5 d | **Yes** |
| `DEFAULT_PRINCIPAL` is permissive (residual risk 1) | anyone reaching a path that sets no principal | 1 d to deny by default | Yes for B, no for A |
| Alerts exist (`atlas/obs/alerts.py`, `GET /v1/alerts`); nobody is on the other end | everyone, silently | 0.5 d to route to a rota | No — condition |
| Memory entries carry no provenance (residual risk 2, largest gap) | any user whose preferences were written from untrusted text | 3–5 d | No — condition |
| No documented retention/deletion procedure for threads and memory | staff; any access or erasure request | 1 d of writing | Yes if the Lisbon question resolves against us |
| No anonymous-access design; `search_web` is a seeded local corpus, not the web | marketing's expectations | — | **B is not a configuration change; it is a different system.** |

**5. Data flow.** Enters: staff questions, project documents, job-costing rows,
durable preferences. Stored: index and database on our infrastructure; threads in
the checkpointer keyed by subject-owned id; preferences in the per-subject memory
store. Sent to the model: question, retrieved extracts, database results — **tier,
provider, endpoint and region TBD, see gap 1**. Exported: allowlisted attribute
keys only, scrubbed; no prompt or answer text. Trace readers: <named rota>.

**6. Residual risk accepted.** The seven in `docs/THREAT_MODEL.md`, accepted by
<managing partner>, with items 1 and 2 re-reviewed before any change of use.

**7. Recommendation.**
**GO WITH CONDITIONS** for use A: pin and record model tier, endpoint and retention
settings, and confirm `unsafe_code=False`, before first non-pilot use (2026-09-26);
route alerts to a named person (2026-09-26); obtain counsel's view on the Lisbon
question before adding any EU-located user (2026-10-31); write the deletion procedure.
**NO-GO** for use B: no anonymous-access design, permissive default principal, seeded
rather than live web corpus — a new build, not a toggle.
**NO-GO pending scoping** for use C: if the portfolios are job applications, this is
an Annex III use with obligations from 2 Dec 2027 and a conformity programme we do
not have. Do not pilot it "to see how it does".
```

### Rubric (40 points)

| Criterion | Pts | Full marks |
|---|---|---|
| Three uses scoped separately | 6 | A, B and C each get all four questions. Collapsing them scores 0 here — the whole exercise is that one system has three regulatory identities. |
| Primary sources, dated | 6 | Every regime cited to EUR-Lex or the official text with a checked-on date. **Minus 3 for any law-firm or vendor page cited as authority for a date or obligation.** |
| No assertion that an act applies | 4 | Lisbon and the Canadian employee-data question flagged *unresolved, turns on facts, counsel*. Deciding either confidently scores 0 here, however defensible. |
| "What we have" rows name artefacts | 6 | Module path, test name or task id. "We have an approval gate" with no names scores 2 of 6; naming all four gated tools is expected. |
| Gaps have owners and effort | 6 | At least one launch-blocking gap with a date. The `unsafe_code` confirmation is the one most students miss. |
| Data flow, including the unknown | 4 | Full marks require saying tier/endpoint/retention is unknown **and** that this blocks — not leaving the row blank. |
| Recommendation | 6 | One verdict per use, conditions dated, one sentence of reasoning. Full marks require B to be identified as a different system rather than a setting. |
| Fits on one page | 2 | Working notes are page two. Three pages scores 0 here; re-cut. |

**The failure seen every time:** treating use C as "Atlas with a new prompt". If your note proposes piloting C to gather data, you have proposed running an unassessed high-risk-class use on real applicants in order to decide whether it is high-risk.

---

## Assignment 2 — model answer and rubric

### Model incident report (load-bearing parts)

**Timeline.** Poisoned PDF arrives by email 07:xx Tue; ingested by the nightly job 02:00 Wed — *the corpus was poisoned roughly twelve hours before the first bad answer and nothing noticed*. First affected answer 14:05; the user clicks at 14:05. Second report 15:40. Containment: allowlist reverted to deny-all 15:58, both supplier domains removed; the affected document withdrawn from the index 16:20. **Detection was a user, not an instrument**; the gap between 02:00 and 15:40 is the finding.

**Scope, and how we know it.** The audit log names the subject of every consequential action. The trace shows the poisoned extract entering at retrieval, one trace id per request. Both reported requests were on the `document` route; no write occurred, and the route/tier intersection would have refused one anyway.

**What the records cannot tell us:**

- The egress report names *blocked* hosts. An allowlisted host passes without producing a finding, so **we have no record of how many answers contained the URL** — only the two humans reported. The true count is unbounded by our own telemetry.
- Prompt and answer text is never exported and local spans are not retained, so the answers themselves cannot be re-read. That is the export boundary working as designed, and it costs us precisely here.
- We cannot know what the attacker's server logged on the click: referrer, IP and any query string left our control at that moment.

**Root cause, distinguished from trigger.** The trigger was a prompt injection in a supplier PDF. The root cause is a decision: three weeks earlier an allowlist — the boundary that removes the third leg of the lethal trifecta — was widened for convenience, with no consequence analysis and no threat-model diff. Two contributing causes: the allowlist matched *subdomains*, so control of any subdomain the supplier does not own defeated it; and the ingest path admits email attachments into the corpus with no quarantine and no provenance, which is residual risk 2's shape applied to documents rather than memory.

**Durable changes.**

| Change | Type |
|---|---|
| Allowlist returns to deny-all; the `document` route emits no URLs at all, its inputs being untrusted by construction | **boundary** |
| Exact host matching; no wildcard subdomains, ever | **boundary** |
| Any egress-allowlist change requires a diff to `docs/THREAT_MODEL.md` and a second reviewer | **boundary (process)** |
| Every URL *emitted* produces an egress record, not only every URL blocked | **layer (detection)** |
| Alert on any answer containing an outbound URL, routed to the on-call rota — closing the "control that fires and is read by nothing" gap | **layer (detection)** |
| Externally-sourced documents quarantined, with provenance carried into the extract | **boundary for the corpus, layer for the answer** |

Not proposed: any instruction to the model about ignoring injected text. That is not a fix; it is a wish with a temperature setting.

**Draft failure-log entry, house style:**

```markdown
### F-E-01 — an allowlist widened for convenience matched a subdomain the supplier does not control

**Symptom.** Two answers on the `document` route rendered an attacker-chosen URL.
One user clicked it. No write occurred.

**Cause.** The egress allowlist — the boundary, not the layer — was widened three
weeks earlier to admit two supplier domains, matching subdomains, with no
threat-model diff. A poisoned PDF entered the corpus through an unquarantined
email-attachment ingest.

**Fix.** Deny-all restored; exact-host matching; the `document` route emits no
URLs; allowlist changes require a threat-model diff and a second reviewer; emitted
URLs are now recorded and alerted, not only blocked ones.

**Lesson.** A boundary widened for a convenience is a boundary deleted for an
attacker, and the change that deletes it will be titled after the convenience.
Detection that records only refusals is blind to the case where the control said yes.
```

**Notification.** Whether any obligation is engaged turns on facts to establish rather than assume: what was in the URL's path or query string, whose data it was, where those people are, and what the customer contracts require. Establish those, then take advice; do not settle the question inside the incident channel.

### Rubric (40 points)

| Criterion | Pts | Full marks |
|---|---|---|
| Timeline separates occurrence from detection | 5 | The ~12-hour poisoned-corpus window and "detected by a user, not an instrument" both appear. |
| Scope cites specific records | 6 | Audit log, trace, route — named, not gestured at. |
| Scope states what records **cannot** say | 7 | Requires the egress asymmetry (blocked hosts recorded, allowed hosts not) plus one further honest limit. The hardest seven points and the most valuable. |
| Root cause ≠ trigger | 6 | "Prompt injection" as root cause scores 0. The cause is the widening decision; subdomain matching and unquarantined ingest are contributing. |
| ≥1 boundary and ≥1 detection change, labelled | 6 | Mislabelling a detector as a boundary loses 3 — that is the distinction the book turns on. |
| Failure-log entry in house style | 5 | Id, one-line title, symptom, cause, fix, lesson. The lesson is general, not a restatement of the fix. |
| Notification without over-claiming | 3 | Names the facts it turns on; neither asserts an act applies nor waves it away. |
| No prompt-only fix | 2 | Any "instruct the model to ignore injected instructions" as a *fix* forfeits both. Listing it as a discarded option is fine. |

**Two failures to watch for in your own draft.** First, a scope section that sounds complete — "two users affected" — when your telemetry cannot establish the denominator; the honest sentence is that two were reported and the true count is unbounded by what we log. Second, proposing six detection improvements and no boundary, which is the comfortable direction: detection is cheap, reversible and never blocks a feature request, and that is exactly why the allowlist got widened in the first place.
