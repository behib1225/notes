# Atlas — system card

**Version** 1.1 · **Covers** the code in `atlas_phase_16.zip` · **Owner** &lt;name, role&gt;
**Approved by** &lt;name&gt; · **Problems to** &lt;address&gt; · **Next review** &lt;date, ≤6 months&gt;
or on any change to the tool registry, the permission tiers, the gated-tool set,
the egress allowlist, or the model tier.

> Written as the hands-on deliverable of Appendix E. It supersedes the shorter
> card inside the snapshot (`atlas/docs/SYSTEM_CARD.md`), which is left untouched.
> Angle brackets are deployment facts you fill in before anyone reads this.

## 1. Intended use

Answering questions for staff of one small company over that company's own
documents and its operational database, with citations, and performing a small
set of low-consequence actions behind a human approval gate. Users are
authenticated staff holding one of four permission tiers. Authentication is a
shared bearer secret (`Settings.api_secret`); there is no per-user login, so
"who" is asserted by the calling client, not proved by the API.

## 2. Out-of-scope use

Not for: decisions with legal, medical, financial or safety consequences;
anonymous or public access; customer-facing use of any kind; autonomous action
without the gate; any workflow where being wrong 5% of the time is unacceptable;
any use that scores, ranks, screens or filters people.

**Changing the corpus or the prompt set can move this system into a different
regulatory tier without changing a line of code. Re-read §1 before any such
change.**

## 3. Capabilities, and what is not built

The authoritative list is `atlas/capabilities.py`: each row binds one sentence
Atlas may say about itself to an entry point that imports, at least one test that
names it, and — where gradeable — an eval task. Counts are in the generated
`docs/ENGINEERING_SUMMARY.md` and are not restated here, because a number in two
places is a number that disagrees.

Verification resolves entry points, parses test files for the named functions and
looks up task ids. **It does not run them.** A green report therefore proves a
claim is *attached* to evidence that exists, never that the evidence is good.

Eight capabilities are listed as deferred, with no entry point and no tests, and
are **not built**: CodeAct, a text-to-SQL agent, a many-tools retrieval registry,
time travel, a multi-agent supervisor, online/simulated-user evaluation, a
browser tool, a second-framework port.

Atlas has no email, no calendar, no outbound network from its tools, and no image
or document generation.

## 4. Tools, what each reaches, and which are gated

| Tool | Reaches | Constraint | Approval |
|---|---|---|---|
| `retrieve_documents` | local document index | read-only | no |
| `query_db` | `data/atlas_query.db`, curated relations | read-only SQL; relations named in the answer | no |
| `search_web` | a committed, seeded local corpus — **not the internet** | read-only | no |
| `read_file` / `list_files` | a jailed workspace directory | traversal escapes refused and reported | no |
| `write_file` | the same jail | jail | **yes** |
| `remember` | per-subject memory store | write passes a refusal gate with redaction inside it | **yes** |
| `run_python` | a container with **no network** | **off by default**; refuses outright when Docker is absent | **yes** |
| `company_note_append` | the shared note, over MCP | scoped token | **yes** |
| `recall` | per-subject memory store | read-only | no |
| `calculator`, `current_time` | nothing outside the process | arithmetic only; injected clock | no |
| remote MCP tools | another team's company-data server | called as the user, with a scoped, audience-bound, short-lived token | per tool |

The four gated tools are exactly the keys of `CONSEQUENCE_RENDERERS` in
`atlas/graph/approval.py`; wiring refuses to gate a tool that has no renderer.

**Caveat.** `build_default_registry(unsafe_code=True)` substitutes Phase 3's
resource-bounded subprocess for the container. It exists only to keep Phase 3's
measurements reproducible, is never a fallback for missing Docker, and must be
off in any deployment. Confirm it here: `unsafe_code = <false>`.

The permitted set for an episode is the **intersection** of the route's tools and
the subject's tier — never a union, because a rule that can widen is a rule an
escalation can travel through.

## 5. Data handling

| Data | Where it goes | Retention |
|---|---|---|
| Request text | model prompt; local span attributes | in-process; local spans are not exported |
| Retrieved extracts | model prompt; cited in the answer | as above |
| Database results | model prompt; relations named in the answer | as above |
| Durable preferences | per-subject memory store | until deleted; see `docs/RUNBOOK.md` |
| Conversation threads | checkpointer, keyed by thread id, owned by a subject | see `docs/RUNBOOK.md` |
| Exported telemetry | allowlisted, scrubbed attribute keys only | per collector |
| Audit entries | subject, action, decision, reason, argument **digest** | append-only in the API |

```
        UNTRUSTED IN                    PROCESS                    OUT
  docs, DB rows, web corpus  ->  prompt + local spans  ->  answer  -> user
        (fenced as data)          (full text, kept          |
                                   in-process only)         +-> egress filter
                                          |                      (deny-all
                                          |                       allowlist)
                                          +-> EXPORT BOUNDARY
                                              allowlisted keys only,
                                              then scrubbed
                                              (no prompt or answer text)
                                                     |
                                                     v
                                                 collector
```

**No prompt or answer text leaves the process.** The export carries attribute
*names* from an allowlist; no content-bearing convention attribute is on it, and
a test asserts the absence. Surviving values are scrubbed for bearer tokens, API
keys, emails, Luhn-checked card-like runs and a deliberately narrow phone
pattern.

**Who can read what:** audit entries &lt;role&gt;; traces and collector data
&lt;role&gt;; the memory store &lt;role&gt;. Fill these in; "everyone with repo
access" is an answer, just not a good one.

**Which model, and where** — fill before anyone reads this card:

| Tier in use | Model | Provider | Endpoint / region | Provider retention | Training use |
|---|---|---|---|---|---|
| &lt;A / H&gt; | | | | | |

## 6. Human in the loop

A gated action stops before it happens, is described in one sentence of
consequence rendered from its **effect** rather than its arguments, and resumes
only on a recorded decision. The gated set is the four tools in §4.

**Limits.** The gate does not scale — approval rate is unmeasured, and the
thirtieth prompt of an hour is not read (ASI09). Cancellation is cooperative, so
a cancelled job keeps spending until it next checks the flag, and the API says so
in the response body. A stop halts the loop, not effects already committed.

## 7. Evaluation

The suite in `evals/` — task grading, a calibrated judge, red-team objectives,
reliability probes, retrieval and memory probes — runs over 3 trials and is
reported as `pass^k` (every trial must pass), because a user meets one trial. The
judge is calibrated against hand labels with Cohen's kappa, reported by its worst
criterion, and may not grade below a floor enforced in code. The offline tests
assert parsing, schema, control flow, budgets and retrieval arithmetic against
scripted fixtures; **no test asserts model output.** Counts:
`docs/ENGINEERING_SUMMARY.md`.

**Measured.** Pooled red-team attack success rate **0.600 [0.231, 0.882] before
controls → 0.000 [0.000, 0.434] after**, delta −0.600 against a minimum
detectable effect of 0.372 at n = 5. Tier F scripted fixtures, seed 7, with the
model removed as a variable. Source: the `make redteam` rows in `VERSIONS.md`,
repeated in `ATLAS_INTERFACES.md`. A real result, and a small one.

**Reader beware.** The Phase 14 section of `docs/RESULTS.md` records a traceback
where that measurement should be. Treat the file of record as incomplete until
`scripts/phase14_results.py` is rerun.

**Estimated, and not quoted here.** `docs/RESULTS.md` carries Tier A ranges for
attack success, approval rate and latency labelled *author estimate, unmeasured*,
with the instruction: do not quote it; run it.

**Determinism.** Temperature 0 is argmax, not reproducibility: floating-point
reduction order flips ties, and ties cluster at exactly the ambiguous decisions
you wanted stable. Two identical requests may differ.

## 8. Known failure modes (from `docs/FAILURE_LOG.md`)

1. **Configuration read under two disjoint names.** Tier H was configured twice —
   environment reads matching no settings field — for ten phases, invisible to the
   entire suite (F-16-01).
2. **Claims without evidence.** Thirteen manifest references were wrong on first
   verification: eleven test names, two entry points, one task id (F-16-02).
3. **Instrumentation that changes what it measures.** A cached trace id pooled
   every request the process served into one trace (F-15-01); a derived field
   declared as a bare property never reached the wire (F-15-02).
4. **Identity lost from the trail.** A user id written only when a thread id was
   supplied attributed everyone's actions to one shared name (F-12-01); a
   combined handler recorded an empty subject for refusals (F-12-02).
5. **A defence measured against the wrong objective.** The first red-team suite
   reported 1.000 before and 1.000 after, because the objectives did not require
   the capability the defences remove (F-14-03).
6. **A classifier tested 24/24, wired to nothing, and described as wired**
   (F-07-05).

Across the last eight phases the majority of logged defects were in the
instrument — grader, tracer, check, wiring — and none in the agent.

## 9. Safeguards and their limits

| Safeguard | Limit |
|---|---|
| Permission tiers | the default principal is permissive |
| Approval gate (4 tools) | does not scale; approval rate unmeasured |
| Egress allowlist, deny-all default, images refused even from allowed hosts | closes the answer channel, not every channel |
| Container sandbox, no network | kernel-level escape out of scope; `unsafe_code` must be off |
| Scoped, audience-bound, short-lived tokens | a teaching stand-in for an authorization server: symmetric key, minted and verified by the same party |
| Audit log | records; prevents nothing |
| Injection signal | free and deterministic; scored 1 on a benign document *discussing* injection and 0 on a genuinely poisoned skill — **wired to a warning line and to no decision** |
| Redaction | an accident control, not an adversary control |
| `read_only` tool flag | an unverified declaration |

Published work on prompt-injection defences reports stacked detectors collapsing
under adaptive attack, so every detector here is a **layer**; the registry, the
permission tier and the absent network interface are the **boundaries**.

## 10. Accepted residual risk

Seven, numbered and unmitigated, in `docs/THREAT_MODEL.md`: permissive default
principal; memory entries with no provenance (**largest gap**); no signature or
change-alarm on skills and remote tool descriptions; container escape; no
compensation for partial work; unmeasured approval rate; `read_only` unverified.

Accepted by &lt;name&gt;, &lt;date&gt;.

## 11. Status

Never run against production traffic. Seeded corpora. Laptop-scale model;
frontier behaviour differs, sometimes in both directions. Retrieval over the
deliberately damaged fifth of the corpus is materially worse than over the clean
part, and the split is reported rather than averaged. A domain swap needs zero
code edits on the retrieval path and touches ten other files — prompt text, tool
descriptions, time zones, id formats.
