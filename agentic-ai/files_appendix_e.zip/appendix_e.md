# Appendix E — Governance, Regulation, and Professional Obligations for Agent Builders

## 1. [core] Title | Study hours | Compute | Tiers | Cost | Snapshot

**Appendix E — Governance, Regulation, and Professional Obligations for Agent Builders**
Study hours: 2.0 read / 2.5 build (writing, not coding) / 1.0 assess · Compute time: none · Tier A calls per sweep: 0 · Tier H calls: 0 · Cost: $0.00 · **Repo snapshot: `atlas_phase_16.zip` (read-only; this appendix adds no code)**

**Read this if** you are about to put an agent in front of someone who is not you: a colleague, a client, a pilot group of ten people in another department. Read it also if a procurement questionnaire has landed on your desk, or if you are writing the "Responsible AI" paragraph of a portfolio and want it to survive one follow-up question.

**What it assumes from the core.** Phase 10 (approval gate, escalation), Phase 12 (scoped credentials), Phase 14 (permission tiers, egress filtering, audit log, threat model), Phase 15 (tracing, export allowlist, redaction), Phase 16 (capability manifest, eval suite, failure log). With those, this appendix is mostly *writing down what you already built*. Without them, read the summary at the head of each; I cross-reference rather than re-teach. **No later material depends on this appendix**, and it ships no gradeable test: its outputs are prose, graded by the rubrics in the solutions file.

**This is an engineer's orientation to the obligations that shape design, written by an engineer.** It teaches the questions that decide whether a rule applies to a system, and works those questions against Atlas. It is not legal advice, it does not tell you that any particular law applies to your project, and a real deployment needs counsel admitted where your users are. That is the whole disclaimer; I will not repeat it, because a page of hedges hides the two sentences that matter.

**Deliverables of this appendix.** `docs/SYSTEM_CARD.md` (written end to end in §7.1, saved beside the repo) and `docs/READINESS_NOTE.md` (template in §7.2, written for a scenario in §14). Neither modifies the snapshot.

---

## 3. [core] Why this appendix matters

Three things happen in a student's first professional year, in this order. Procurement sends a ninety-row spreadsheet of which eleven rows are about AI, due Friday. Legal asks what personal data goes to which model provider and where that provider runs. Support asks why the assistant sent a customer a figure that exists in none of your systems.

All three are **evidence** requests, not opinion requests, and the evidence is a build artefact. The approval gate answers "which actions need a human". The audit log answers "who did this". The export allowlist answers "what leaves the process". `docs/FAILURE_LOG.md` answers "what do you know goes wrong" — thirty-seven entries of it, which is thirty-seven more than most systems can produce.

The asymmetry is the argument. Writing these down now costs an afternoon. Adding a human-approval point to a live system that never had one costs a re-architecture of the action path, plus an explanation of why the previous six months of actions have no recorded decision behind them.

---

## 4. [core] Learning objectives

You will be able to: **(1)** run the four scoping questions on any system and say what they open and close, without asserting that an act applies; **(2)** state the EU AI Act's risk tiers and today's application dates, including which moved in 2026 and which did not, citing primary sources; **(3)** say what the NIST AI RMF and ISO/IEC 42001 each are for and what each asks you to produce; **(4)** write a system card in which every line names a module, test, task or log entry, and measured figures are typographically distinct from estimates; **(5)** write a one-page readiness note ending in go / go-with-conditions / no-go; **(6)** answer the five practical questions, naming the Atlas mechanism that addresses each *and the residual risk it leaves*; **(7)** write an incident report that separates what happened from what you did about it.

---

## 5. [core] Prerequisites & quick recap

You need `atlas_phase_16.zip` unpacked and readable. Nothing needs to run.

Four facts carry this appendix. **A prohibition is an absent tool** — the registry is the security model, and `atlas/safety/permissions.py` intersects the tier's tools with the route's, never unions them. **A consequential action stops for a human** — `atlas/graph/approval.py` refuses at wiring time to gate a tool with no consequence renderer. **What leaves the process is an allowlist** — `ATTRIBUTE_ALLOWLIST` in `atlas/obs/redact.py` carries no content-bearing key, and a test asserts the absence. **A claim needs evidence** — `atlas/capabilities.py` binds 45 claims to entry points, tests and, where gradeable, eval tasks.

> **Glossary** (terms this appendix uses from the core, defined once).
>
> **Provider / deployer** — the two AI Act supply-chain roles that matter here: one places a system on the market or puts it into service under its own name; the other uses it under its own authority. Build-and-run makes you both.
>
> **Boundary vs layer** — a control is a *boundary* if passing it requires something the attacker cannot obtain (an absent tool, a missing scope, a key that is not on the allowlist); it is a *layer* if passing it only requires writing different words. Both are useful; only one is load-bearing.
>
> **Lethal trifecta** — private data + untrusted content + an outbound channel, in one context. Remove any leg and the exfiltration path closes; Atlas removes the third with egress filtering.
>
> **ASI01–ASI10** — OWASP's agentic-security entries, the organising spine of `docs/THREAT_MODEL.md`.
>
> **pass^k** — every one of k trials must pass, as opposed to pass@k where any one may. A user meets one trial, so Atlas reports pass^k.
>
> **Cohen's kappa** — agreement between a model judge and hand labels, corrected for agreement by chance. A judge that always says "pass" scores high raw agreement and near-zero kappa.
>
> **MDE** — minimum detectable effect: the smallest difference your sample size could have distinguished from noise. A delta smaller than the MDE is not a result.

---

## 6. [core] Core concepts

### 6.1 The four scoping questions

No obligation attaches to "an AI system" in the abstract. Four facts decide nearly everything, and you can answer them in ten minutes.

**What does it do?** Not what it is built from — what decision or effect it produces. "A RAG assistant" is not an answer; "ranks job applicants" and "answers staff questions over internal documents" are, and they land in different tiers of every framework.

**Who is the user?** Employees of the operator, external customers, the public, children, people who can be *refused* something. Each step outward adds duties and removes your ability to fix a problem by walking to someone's desk.

**Where are they?** Not where your servers are. Where the affected people are, and whose market you placed the thing on. The AI Act reaches providers established outside the Union where the system's output is used in the Union.

**What role do you play?** Provider, deployer, or both. Fine-tuning or rebranding someone else's system can make you its provider.

> **Misconception.** "We just call an API, so the vendor is responsible." The vendor provides the *model*. You provide the *system*: the prompts, the tool registry, the approval policy, the egress filter. Nobody else has ever seen your `HANDLER_TOOLS` table.

**Concept check 6.1.** Atlas's `tool_action` route can write a file behind an approval gate. Which of the four answers does that change, and which does it leave untouched?

**Your turn (5 min).** Write the four answers for the last system you built, in one line each. If any line names a technology rather than an effect, a user, a place or a role, rewrite it.

### 6.2 The EU AI Act: the shape, and the dates as they stand

The Act is Regulation (EU) 2024/1689, in force since 1 August 2024, and it regulates by risk rather than technique: prohibited practices (Article 5); a high-risk tier carrying the full compliance programme (Articles 8–27), defined by Annex I (AI as a safety component of a regulated product) and Annex III (stand-alone uses such as biometrics, employment, credit, essential services); transparency duties for systems that interact with people and for generated content (Article 50); a separate regime for general-purpose AI models (Articles 51–56); and beyond a duty to support AI literacy (Article 4), no tier-specific obligations for anything else.

**The dates moved in 2026, and not all of them.** Regulation (EU) 2026/1744, the Digital Omnibus on AI, was adopted on 8 July 2026, published in the Official Journal on 24 July 2026, and entered into force three days later. Its recitals state the reason: delayed harmonised standards, common specifications and guidance, and delayed establishment of national competent authorities. So Chapter III, Sections 1–3 now apply from **2 December 2027** for Annex III stand-alone systems and **2 August 2028** for Annex I embedded ones. The general application date of **2 August 2026** was left alone, so the Article 50 transparency duties already apply, with a four-month transitional window for the Article 50(2) marking obligation for generative systems already on the market. Article 4 was rewritten into a duty to *take measures to support* AI literacy, explicitly without guaranteeing any level for any individual, and two prohibitions were added to Article 5(1) covering non-consensual intimate material and child sexual abuse material. Those two carry their own application date in the amended Article 113(3)(a) — widely reported as 2 December 2026, which I did not verify in the primary text; check the consolidated version before relying on it.

Three things to carry, rather than the dates. **The tier is decided by use, not capability**: the same retrieval agent is unregulated for internal document Q&A and high-risk pointed at applicant screening, with no code change. **A delay is not a repeal**: the requirements arriving in 2027 are risk management, data governance, technical documentation, logging, human oversight, accuracy and robustness — what a competent team builds anyway. **The dates are fixed calendar dates in Article 113**, movable only by a further amending regulation, so treat any pre-2026 timeline you find online as wrong until checked.

> **Misconception.** "We are under the threshold, so the Act does nothing to us." Articles 4 and 50 are not tiered by risk. Scope out of high-risk if you can; do not scope out of the Act in your head.

### 6.3 Worked example: Atlas against the questions

*What does it do?* Retrieval, read-only SQL, a jailed file write, a note append. It makes no decision about a person, which keeps it clear of every Annex III category — **as configured**. Point `retrieve_documents` at a CV corpus and add a "shortlist five" prompt and that changes in an afternoon, which is why §2 of the system card is a control and not a courtesy.

*Who is the user?* Authenticated staff of the operator, holding one of four permission tiers.

*Where are they?* Unanswerable from the archive, because it is a deployment fact. That is the first line of the readiness note.

*What role?* The company builds it and switches it on: provider and deployer at once. It is not a provider of a general-purpose AI model; it uses one, so Chapter V duties sit with whoever placed that model on the market.

The obligations plausibly touching a system of this shape are the unexciting ones: tell people it is an AI, help staff understand what it is good and bad at, keep the records. Atlas already ships records nobody asked it for.

### 6.4 The NIST AI Risk Management Framework

NIST published AI RMF 1.0 in January 2023 and the Generative AI Profile, NIST-AI-600-1, on 26 July 2024; the Profile adds twelve generative-specific risk categories, including confabulation, to the framework's four functions — **Govern, Map, Measure, Manage**. It is voluntary, it is not a certification, and it is the vocabulary most US enterprise questionnaires are written in. NIST's own page states that 1.0 is being revised under the White House AI Action Plan, so check the publication page before quoting a version.

Read as an order of operations, Atlas maps on almost too neatly. *Govern*: `docs/DECISIONS.md`, the capability manifest. *Map*: `docs/THREAT_MODEL.md`, by ASI entry, seven numbered residual risks. *Measure*: `evals/`, `docs/RESULTS.md`, every figure with tier, model, seed and date. *Manage*: permission tiers, approval gate, egress filter, audit log, circuit breakers. The gap it exposes is the one Phase 15's handoff named: `atlas/obs/alerts.py` exists and is wired to `GET /v1/alerts`, and **nobody is on the other end**. Manage with no operator is Map with extra steps.

### 6.5 ISO/IEC 42001

ISO/IEC 42001 is the international standard for AI management systems, and certification against ISO/IEC 42001:2023 is voluntary, performed by independent certification bodies. Where the NIST RMF is a framework you apply, 42001 is a management system you *operate* and an auditor inspects: scope, AI policy, roles, risk and impact assessment, objectives, controls with justification, internal audit, management review, corrective action. The nearest analogy is ISO/IEC 27001, deliberately, because most organisations bolt the AI system onto the security one.

What an auditor asks for is unglamorous: the register of AI systems; who owns this one; the risk assessment and its date; evidence the claimed controls operate; the last review and what changed because of it. Four of those five are files in `docs/`. The fifth is a name and a date at the top of the card.

### 6.6 Incident reporting

Three regimes, three clocks, and they are not the same event.

**Personal-data breach.** Under the GDPR a controller notifies its supervisory authority without undue delay and, where feasible, within 72 hours of *becoming aware*; individuals are told separately where the risk to them is high. The clock starts at awareness, which is why telemetry that bounds the affected set is worth more than a belief that it was probably small.

**Serious incident under the AI Act.** Article 73 obliges providers of high-risk systems to report serious incidents to market-surveillance authorities. It arrives with the high-risk regime, and it is worth reading now because its *definition* of a serious incident is a design brief: the harms you are expected to detect are the ones you should be logging for.

**Contractual.** Your enterprise customers' notification clauses will have a shorter deadline than either statute, and theirs is the one that actually fires.

For a small team the operational answer is one paragraph in `docs/RUNBOOK.md`: who declares an incident, who is told in the first hour, and what you can reconstruct. Atlas can name the subject of every consequential action, can render one request as one span tree across the MCP boundary, and stores argument **digests** rather than bytes — so it can show *that* a call carried a given payload without retaining it.

### 6.7 The five practical questions students get wrong

**Terms of service and scraping.** *The mistake:* treating a page's visibility as a licence. *Why it is tempting:* copying is trivial and everyone's favourite dataset was built this way. *What to do:* public accessibility, the site's terms, copyright in the content and personal data on the page are four separate questions; prefer an API or licensed feed, honour robots directives and rate limits, and record where each document came from and when, because that question arrives a year later. *In Atlas:* every corpus comes from a committed seeded generator, `atlas/rag/sources.py` carries provenance into the citation, and `search_web` runs over a seeded local corpus rather than the internet. The real browser tool is deferred to Appendix F.7 deliberately.

**PII in prompts, logs, traces and eval sets.** *The mistake:* guarding the database and forgetting the four places the same data lands on the way through. *Why tempting:* prompts feel ephemeral and traces feel like debug output. They are not — traces are retained, exported and read by more people than the database; eval sets are copied into repos and live forever. *What to do:* allowlist what leaves, scrub what survives, generate fixtures. *In Atlas:* no content-bearing convention attribute is on the export allowlist and a test asserts it; `REDACTIONS` scrubs bearer tokens, API keys, emails, card-like digit runs (Luhn-checked, because an unchecked redactor deletes the order id that explains the failure) and a deliberately narrow phone pattern; the memory store redacts *inside* the write gate. *Residual:* this stops accidents, not adversaries — an adversary picks the encoding.

**Data residency.** *The mistake:* answering from the vendor's marketing page instead of from configuration. *Why tempting:* "EU region available" reads like "we are in the EU region". *What to do:* pin the endpoint, record it per call, treat "which region served this" as a field rather than a belief. *In Atlas:* `Settings` carries `h_base_url` explicitly and nothing reads the environment behind its back — a rule enforced after F-16-01, where three `ATLAS_TIER_H_*` names were read from the environment that matched no settings field, no `.env.example` and no `VERSIONS.md`, for ten phases, invisible to the whole suite of the time (1,618 tests). **A configuration key is a name shared between code, a file, a docs table and a person, and nothing type-checks a shared name.** That defect has the exact shape of a residency incident.

**Who is liable when an agent acts for a user.** *The mistake:* treating it as a novel question. *Why tempting:* the agent feels like an actor. *What to do:* decompose it — whose credentials, what authority did they carry, was the effect authorised, which human decided, can you prove it. The sharp edge students meet first is an agent that *forms a commitment*: accepting terms, placing an order, sending a binding quote. Atlas cannot; if yours can, that action belongs behind an approval gate before it belongs in a prompt. *In Atlas:* tokens name a subject, carry only the scopes the task needs, expire, and are audience-bound, so a token minted for the company-data server is refused elsewhere; the gate renders the consequence in a sentence before a human decides; the audit log refuses an entry with no subject. Together: *a named person authorised this specific effect at this time.* *Residual:* `DEFAULT_PRINCIPAL` is permissive, and a stop halts the loop without unwinding committed effects.

**Retention and training-use opt-outs.** *The mistake:* assuming defaults. Providers differ, tiers within a provider differ, and the setting is usually account- or endpoint-level rather than per-request. *What to do:* record per tier what is retained, for how long, whether inputs may be used for training, and the date you checked; re-check at renewal. Appendix B holds the paid-tier detail — do not copy numbers out of it into prose, including your own.

**Your turn (10 min).** Pick the one of these five your current project handles worst. Write the mistake, the Atlas-equivalent mechanism you would need, and the residual risk that mechanism leaves. Three sentences.

---

## 7. [core] Hands-on: write the Atlas system card, then the readiness note

### 7.1 What a card must contain, and how each heading fails

The card is graded against this table; it is also the reusable skeleton for any other system. Copy the left column, fill it, then check yourself against the right.

| # | Heading | Must contain | Fails when |
|---|---|---|---|
| 1 | Intended use | the effect, the users, the authority model | it describes the architecture instead |
| 2 | Out-of-scope use | uses that would change the risk tier | it lists only uses nobody wanted |
| 3 | Capabilities / cannot do | the evidence binding, and what is *not* built | deferred work reads as shipped |
| 4 | Tools and reach | per tool: what it touches, what constrains it, whether it is gated | a mode that swaps the constraint is omitted |
| 5 | Data handling | what is stored, where, how long, what is sent to which model at which endpoint | the model row is left blank rather than marked unknown |
| 6 | Human in the loop | *which* actions require approval, and the gate's limits | "there is an approval gate" with no list |
| 7 | Evaluation | which suites, which tier, measured vs estimated | one number appears in two documents |
| 8 | Known failure modes | drawn from the failure log, not from imagination | only generic LLM caveats |
| 9 | Safeguards **and limits** | one limit per safeguard | a limits column that is absent |
| 10 | Residual risk | numbered, accepted, owned | "none identified" |
| 11 | Version, owner, review | a name and a date | undated |

Two rules make it survive contact with a repository. **Numbers live in one place** — the generated `docs/ENGINEERING_SUMMARY.md` — because a number in two places is a number that disagrees, and this repository proves it: the hand-written Phase 16 section of `docs/RESULTS.md` says 44 capabilities claimed and 36 supported, while the manifest and generated summary say 45 and 37. Neither is lying on purpose. **Measured and estimated are typographically distinct**, because the reader who most needs the difference is the one least likely to ask.

**The filled card for Atlas is `docs/SYSTEM_CARD.md`, saved beside the repo.** It supersedes the shorter card inside the snapshot, which is left untouched. Read it now, alongside the table above, and check each heading against its failure mode; the three most instructive lines in it are the `unsafe_code` caveat under §4, the "reader beware" note under §7, and the limits column of §9.

### 7.2 The one-page readiness note — template

Save as `docs/READINESS_NOTE.md`. One page, or it is not read.

```markdown
# Readiness note — <system> for <deployment>
Prepared by <name>, <date>. Decision requested from <name> by <date>.

1. **Scoping.** Does: … · Users: … · Where they are: … · Our role(s): …
2. **Obligations this opens.** Per regime: status as of <date>, primary-source URL,
   and the fact it turns on. Mark anything unresolved as unresolved. Max five.
3. **What we already have.** One row per obligation naming the artefact — module,
   test, eval task, doc. Not the intention.
4. **Gaps.** What is missing, who is exposed, effort, blocks launch yes/no.
   A gap with no owner is a wish.
5. **Data flow in five lines.** What personal data enters; where stored; what is
   sent to which model at which endpoint; retention; who reads the traces.
6. **Residual risk accepted.** Numbered, each with the name accepting it.
7. **Recommendation.** GO / GO WITH CONDITIONS (dated) / NO-GO. One sentence. Sign.
```

### 7.3 With an assistant

**Safe to delegate:** extracting the tool inventory from `atlas/tools/` and the gated set from `CONSEQUENCE_RENDERERS`; listing capability rows with their tests; pulling the seven residual risks out of the threat model; checking that every module, test and task id you cite exists.

**Not safe:** any regulatory date or obligation — assistants reproduce superseded timelines with total confidence, and the 2 August 2026 high-risk date is now wrong and is all over the training data. Also not: the out-of-scope section, the limits column, the residual-risk list, the recommendation line.

**A prompt that works:** *"Read `atlas/capabilities.py` and `tests/`. For each capability row, report whether every named test function exists in the named file. Output a table of capability id and missing test names, and nothing else. Do not fix anything."*

---

## 9. [core] Common pitfalls & how professionals avoid them

**Writing the card from memory right after building.** It feels like the moment you know most; Phase 16 measured the result at thirteen wrong references out of forty-five. Generate what can be generated, grep the rest.

**Safeguards without limits.** A safeguards table with no limits column reads as a claim of completeness, and the first reviewer to find an uncovered limit discounts the whole document.

**Confusing a policy with a control.** "Staff are instructed not to paste customer data in" is a policy; the export allowlist is a control. Auditors ask which you have; users answer with their behaviour.

**Letting the card drift.** Pin what you can with a test — `make check-docs` parses the Makefile and asserts every target the prose names exists, and it fired on its first run — and give the rest an owner and a review date.

**Treating a deferred obligation as a cancelled one.** Sixteen extra months is a budget, not a reprieve.

**Answering residency from the vendor's homepage.** Answer from configuration, and let configuration name the endpoint in exactly one place. F-16-01 is what the other arrangement looks like from inside.

---

## 12. [core] Mastery checklist

You are ready to move on if you can: scope an unfamiliar system in ten minutes with the four questions; state the Act's tiers and today's dates with the amending regulation named and a primary link; say in one sentence each what the NIST RMF and ISO/IEC 42001 ask you to produce; write a card where every safeguard has a limit and every number is generated or labelled an estimate; name for each of the five practical questions the Atlas mechanism *and* the residual risk it leaves; and write an incident report separating what happened from what you did.

---

## 13. [core] Quiz

1. A team fine-tunes a vendor's model, rebrands the assistant and sells it to three customers. Which scoping answers change, and which role do they now occupy?
2. Which AI Act obligations did the 2026 Digital Omnibus move, and which did it leave? Why does the distinction beat the headline?
3. Restate the boundary/layer test and apply it to the approval gate.
4. Your card claims the audit log records every consequential action against its subject. Name the three things you would show, and the one thing they still do not prove.
5. Someone proposes adding `gen_ai.input.messages` to the export allowlist for one week to debug retrieval. Strongest argument for, strongest against, and the decision you would write down.
6. Why is a card listing seven accepted residual risks trusted more than one listing none?

---

## 14. [core] Assignments — two written deliverables

Neither adds code; neither modifies the snapshot. **This appendix ships no hidden test and no `make grade` target** — prose is graded by the rubrics in `appendix_e_solutions.md`. Self-check against the criteria below, then grade yourself against the rubric, then read the model answer.

### Assignment 1 — the compliance readiness note **[fast track: do this one]**

**Scenario.** A 40-person Canadian architecture practice wants Atlas for its own staff, over its project documents and job-costing database. Two of the forty work from Lisbon. Marketing then asks whether the same deployment could answer prospective clients on the public website; HR asks whether it could rank incoming portfolio submissions.

**Deliverable.** One page on the §7.2 template, plus one page of working notes citing primary sources with checked-on dates.

**Acceptance criteria.** (a) All four scoping questions answered separately for all three uses. (b) Every obligation carries a primary-source URL and a status-as-of date; no law-firm or vendor page cited as authority. (c) Every "what we have" row names a module, test, task or doc in the snapshot. (d) At least one gap has an owner and an effort estimate. (e) The data-flow section names tier, endpoint and retention, or states they are unknown and that this blocks. (f) One recommendation line per use.

**UNAIDED CORE:** the scoping table for all three uses and the recommendation with its reasoning. Use an assistant for source-hunting and formatting only.

### Assignment 2 — the incident write-up **[extended]**

**Scenario.** Tuesday 14:05: a staff user asks Atlas to summarise a supplier PDF that arrived by email that morning and was ingested overnight. The answer contains a sentence urging the reader to "verify the invoice at" a URL on an unfamiliar host. The user clicks. 15:40: a second user reports the same sentence. Three weeks earlier the egress allowlist was widened, in a change titled "allow supplier docs to link to supplier sites", to admit two supplier domains; the unfamiliar host is a subdomain of one. The audit log shows both requests; the trace shows the poisoned extract entering at retrieval. No write occurred; both were on the `document` route.

**Deliverable.** Two pages: timeline, scope (and how you know), root cause distinguished from trigger, immediate action, durable change with owners — plus one `docs/FAILURE_LOG.md` entry in house style.

**Acceptance criteria.** (a) Timeline separates occurrence from detection. (b) Scope cites the specific records that bound it **and** states what they cannot say. (c) Root cause is not "prompt injection" — that is the trigger. (d) At least one boundary change and one detection change, labelled. (e) Notification handled by naming the facts it turns on, without asserting that an act applies. (f) No fix that is only prompt text.

**UNAIDED CORE:** the root-cause paragraph and the boundary/layer classification.

---

## 16. [core] Summary & key takeaways

*Self-contained. Paste this wherever you start your own system's governance work.*

**Compliance is an evidence problem, and the evidence is a build artefact.** The approval gate answers "which actions need a human", the audit log "who did this", the export allowlist "what leaves the process", the capability manifest "what do you claim", the failure log "what do you know goes wrong". Writing them down costs an afternoon; adding any of them to a live system costs a re-architecture plus an explanation of the preceding six months.

**Four scoping questions decide almost everything**: what it does, who the user is, where they are, what role you play. They decide it by **use, not capability** — the same retrieval agent is unregulated for internal Q&A and lands in a different tier pointed at applicant screening, with no code change. That is what an out-of-scope section is for.

**The dates moved, and not all of them.** Regulation (EU) 2026/1744 deferred high-risk obligations to 2 December 2027 (Annex III) and 2 August 2028 (Annex I), left 2 August 2026 alone so the Article 50 transparency duties bind now, softened AI literacy into a duty of effort and added two prohibitions. **A delay is not a repeal.** Verify every date against the consolidated text; pre-2026 timelines are everywhere and all wrong.

**NIST's RMF is a vocabulary; ISO/IEC 42001 is a management system.** Govern–Map–Measure–Manage maps onto `DECISIONS.md`, `THREAT_MODEL.md`, `evals/` and the safety package. 42001 asks a different question: show me the register, the owner, the last review, and what changed because of it. Four of five are files; the fifth is a date at the top of the card.

**A safeguard without a stated limit is a claim of completeness**, and one uncovered limit discounts the document. So: the default principal is permissive, the gate does not scale, the injection signal produced a false positive on document one and a false negative on document four and therefore decides nothing, redaction stops accidents not adversaries, `read_only` is unverified, a stop does not unwind. Seven numbered residual risks read as more trustworthy than none, because that list is the only section that could embarrass its author.

**Write the card from the repository, not from memory.** The manifest binding 45 claims to evidence reported thirteen wrong references on its first verification, none of which would have failed a test — and this same archive still holds two counts of the same thing that disagree by one. **A number in two places is a number that disagrees.** Generate what can be generated, pin it with a test, keep the judgement hand-written.

**And the five questions students get wrong** are not exotic. "It is public" settles nothing about terms, copyright or personal data. PII leaks through prompts, logs, traces and eval sets rather than the database you guarded. Residency is a configuration fact, and F-16-01 shows what it looks like when configuration lives under two names. Liability decomposes into whose credentials, what scope, which human decided, can you prove it — and the sharp edge is an agent that forms a commitment. Retention and training-use settings are never what you assumed. For each, Atlas already ships most of the answer; the rest is a sentence, an owner and a date.

---

## 17. [core] Further reading

**Primary — law.** AI Act consolidated text as amended: `https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng`. Digital Omnibus on AI, Regulation (EU) 2026/1744: `https://eur-lex.europa.eu/eli/reg/2026/1744/oj` — recitals 38 and 40 for the transitional period and the new high-risk dates, Article 1 point 40 for the changes to Article 113. GDPR, Articles 33–34: `https://eur-lex.europa.eu/eli/reg/2016/679/oj`.

**Primary — frameworks.** NIST AI RMF 1.0 (January 2023) and NIST-AI-600-1 (26 July 2024), with current revision status: `https://www.nist.gov/itl/ai-risk-management-framework`. ISO/IEC 42001:2023 catalogue entry: `https://www.iso.org/standard/81230.html`.

**Security vocabulary.** OWASP's ASI01–ASI10, the spine of `docs/THREAT_MODEL.md`; and Nasr et al., arXiv:2510.09023 (October 2025), the measured collapse of published prompt-injection defences under adaptive attack, which is where this book's layer/boundary distinction comes from.

**In the snapshot.** `docs/THREAT_MODEL.md` (residual risks first), `docs/FAILURE_LOG.md`, `docs/RESULTS.md` (note which sections say *author estimate, unmeasured*), `atlas/capabilities.py`, `atlas/obs/redact.py`, `atlas/graph/approval.py`, `atlas/safety/`, `atlas/auth/`.

---

## 18. [core] Solutions

Emitted separately as `appendix_e_solutions.md`: worked answers for the concept checks and quiz, and model answers plus rubrics for both assignments.

---

## 19. [core] HANDOFF — VERSIONS.md delta rows

No `ATLAS_INTERFACES.md` is emitted: this appendix adds no code and changes no interface. The rows below are appended to `VERSIONS.md`.

```markdown
## Appendix E — regulatory and framework status (the most perishable rows in this book)

| Fact | Value | Source | Checked |
|---|---|---|---|
| EU AI Act, base instrument | Regulation (EU) 2024/1689; in force 1 Aug 2024 | https://eur-lex.europa.eu/eli/reg/2024/1689/oj | 2026-09-15 |
| EU AI Act, amending instrument | Regulation (EU) 2026/1744 (Digital Omnibus on AI), adopted 8 Jul 2026, OJ 24 Jul 2026, in force 27 Jul 2026 | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| Consolidated text in force | consolidated as of 2026-07-27 | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| Prohibited practices (Art. 5), original list | applies since 2 Feb 2025 | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| GPAI model obligations (Ch. V) | apply since 2 Aug 2025 | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| General date of application (Art. 113 §2) | 2 Aug 2026 — NOT moved by the Omnibus | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| Art. 50(2) marking, systems on the market before 2 Aug 2026 | 4-month transitional period (recital 38) | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| High-risk, Annex III (stand-alone) | 2 Dec 2027 (was 2 Aug 2026) — recital 40 | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| High-risk, Annex I (embedded) | 2 Aug 2028 (was 2 Aug 2027) — recital 40 | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| New Art. 5(1)(ba),(bb) prohibitions (NCII, CSAM) | added by Reg. 2026/1744; application date in amended Art. 113(3)(a) — reported as 2 Dec 2026, NOT verified in primary text; VERIFY | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| AI literacy (Art. 4) | rewritten into a duty to take measures to SUPPORT development; no guaranteed level required | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| Penalty ceilings (Art. 99) | read the current Article 99 in the consolidated text before quoting any figure; ceilings differ by infringement type, and the lower of the two figures applies to SMEs | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| National AI regulatory sandboxes | operational by 2 Aug 2027 (amended Art. 57(1)) | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| NIST AI RMF | 1.0 (Jan 2023); page states 1.0 is being revised under the White House AI Action Plan | https://www.nist.gov/itl/ai-risk-management-framework | 2026-09-15 |
| NIST Generative AI Profile | NIST-AI-600-1, released 26 Jul 2024 | https://www.nist.gov/itl/ai-risk-management-framework | 2026-09-15 |
| NIST critical-infrastructure profile | concept note, 7 Apr 2026 — PRE-RELEASE; nothing here depends on it | https://www.nist.gov/itl/ai-risk-management-framework | 2026-09-15 |
| ISO/IEC 42001 | 42001:2023 current edition (catalogue record 81230); certification voluntary, by independent bodies | https://www.iso.org/standard/81230.html | 2026-09-15 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-15 |

**What could change these.** AI Act dates are fixed calendar dates in Article 113
and move only by a further amending regulation — but guidelines, harmonised
standards and delegated acts change *how* obligations are met without moving a
date. The NIST rows change when the RMF revision publishes. The ISO row changes
on a new edition; watch also ISO/IEC 42006 (requirements for bodies auditing AI
management systems), which affects who may certify you rather than what you must do.
```
