# VERSIONS.md

Current-state facts only. Every row carries a source URL and a checked-on date.
Prose in the tutorial never states these; it points here. Re-verify before you
start, and keep your own copy updated as you go — that habit is the point.

## Runtime

| Fact | Value | Source | Checked |
|---|---|---|---|
| Python floor for this book | 3.11 | https://devguide.python.org/versions/ | 2026-09-02 |
| Newest stable Python | 3.14.7 (released 2026-08-05) | https://www.python.org/downloads/ | 2026-09-02 |
| Python 3.15 status | 3.15.0rc2 (2026-09-01) — release candidate, PRE-RELEASE | https://www.python.org/downloads/source/ | 2026-09-02 |
| uv | 0.12.9 | https://pypi.org/pypi/uv/json | 2026-09-02 |
| ruff (optional lint) | 0.16.5 | https://pypi.org/pypi/ruff/json | 2026-09-02 |

Forward pointer: Python 3.15 is a release candidate, not a release. Nothing in
this book uses it; stay on 3.14 or your working 3.11+ until it ships.

## Pinned Python packages (Phase 0 `requirements.txt`)

| Package | Version | Source | Checked |
|---|---|---|---|
| pydantic | 2.13.5 | https://pypi.org/pypi/pydantic/json | 2026-09-02 |
| httpx | 0.28.1 | https://pypi.org/pypi/httpx/json | 2026-09-02 |
| python-dotenv | 1.2.3 | https://pypi.org/pypi/python-dotenv/json | 2026-09-02 |
| pytest (dev extra) | 9.1.1 | https://pypi.org/pypi/pytest/json | 2026-09-02 |

## Later-phase packages (do not install yet)

| Package | Version | First used | Source | Checked |
|---|---|---|---|---|
| pytest-asyncio | 1.4.0 | Phase 8 (was listed as Phase 1 — corrected) | https://pypi.org/pypi/pytest-asyncio/json | 2026-09-03 |
| tenacity | 9.1.4 | Phase 2 (was listed as Phase 1 — corrected) | https://pypi.org/pypi/tenacity/json | 2026-09-03 |
| ollama (Python client) | 0.6.2 | Phase 0 §7.3, way 2 | https://pypi.org/pypi/ollama/json | 2026-09-02 |
| openai | 3.7.0 | Phase 0 §7.3, way 3 | https://pypi.org/pypi/openai/json | 2026-09-02 |
| langgraph | 1.2.11 | Phase 9 — NOT BEFORE | https://pypi.org/pypi/langgraph/json | 2026-09-02 |
| langchain | 1.3.18 | Phase 10 | https://pypi.org/pypi/langchain/json | 2026-09-02 |
| mcp (Python SDK) | 2.1.1 | Phase 15 | https://pypi.org/pypi/mcp/json | 2026-09-02 |

Forward pointer: the MCP *specification* revision is pinned in Phase 15, not
here, because that is where the book first depends on it.

## Tier A — local runner and model

| Fact | Value | Source | Checked |
|---|---|---|---|
| Runner | Ollama, latest release v0.33.2 (2026-08-27) — re-verified, unchanged | https://github.com/ollama/ollama/releases | 2026-09-03 |
| Runner pre-release (do not use) | v0.33.3-rc0 (2026-09-02) | https://github.com/ollama/ollama/releases | 2026-09-02 |
| Native chat endpoint | `POST http://localhost:11434/api/chat` | https://docs.ollama.com/api/chat | 2026-09-02 |
| OpenAI-compatible base URL | `http://localhost:11434/v1/`, api_key `ollama` (required, ignored) | https://docs.ollama.com/api/openai-compatibility | 2026-09-02 |
| Unsupported in OpenAI-compat mode | `tool_choice`, `logit_bias`, `n`, `logprobs` | https://docs.ollama.com/api/openai-compatibility | 2026-09-02 |
| **`ATLAS_MODEL` (default choice)** | **`gemma4:12b`** — 7.6 GB, 256K context, family badged `tools`/`thinking` | https://ollama.com/library/gemma4 | 2026-09-02 |
| Low-RAM alternative (< 12 GB) | `granite4.2:3b` — 2.2 GB, 128K context | https://ollama.com/library/granite4.2 | 2026-09-02 |
| Mid alternative | `granite4.2:8b` — 5.3 GB, 128K context, Apache 2.0. Card claims tool use, but the library page shows no `tools` capability badge — verify with `ollama show` before relying on it in Phase 2. | https://ollama.com/library/granite4.2 | 2026-09-02 |
| Larger alternative (multimodal) | `gemma4:e4b` — 9.6 GB, 128K context | https://ollama.com/library/gemma4 | 2026-09-02 |
| **Mandatory local check** | `ollama show $ATLAS_MODEL` must list `tools` under Capabilities | https://docs.ollama.com/cli | 2026-09-02 |

Chosen because it fits the 16 GB no-GPU baseline with room for a KV cache and
because the Ollama library page badges the family `tools`, which Phase 2 needs.
Two honest caveats. The badges are published per *family*, not per tag, so the
`ollama show` row above is not optional — run it before Phase 2 and switch tags
if `tools` is absent. And Gemma 4's own card recommends `temperature=1.0`,
`top_p=0.95`, `top_k=64`; this book overrides temperature to 0 for
reproducibility, which trades some output quality for stable evals. If your
Phase 1 structured-output pass rate is poor, that trade-off is the first thing
to test.

## Tier H — free hosted API candidates (budget in TOKENS, cached to `data/cache/`)

| Candidate | Endpoint | Free-tier quota | Source | Checked |
|---|---|---|---|---|
| **Groq (candidate 1)** | `https://api.groq.com/openai/v1` | Free plan, `openai/gpt-oss-20b`: 30 RPM, 1,000 RPD, **8K TPM, 200K TPD**. Same for `qwen/qwen3.8-27b`. Org-level, not per key. | https://console.groq.com/docs/rate-limits | 2026-09-02 |
| Groq OpenAI compatibility | as above | documented as mostly OpenAI-client compatible | https://console.groq.com/docs/openai | 2026-09-02 |
| Groq rate-limit headers | as above | `retry-after`, `x-ratelimit-remaining-requests`, `x-ratelimit-remaining-tokens` | https://console.groq.com/docs/rate-limits | 2026-09-02 |
| **Google AI Studio (candidate 2)** | `https://generativelanguage.googleapis.com` | Free tier exists (no spend limit applies); per-model RPM/TPM/RPD are published per project in AI Studio, not in the docs table — read your own limits there before relying on a number | https://ai.google.dev/gemini-api/docs/rate-limits | 2026-09-02 |

**The budget is tokens, not calls.** Do the arithmetic before you trust a call
count: 200,000 tokens/day ÷ a 2,000-token agent prompt ≈ **100 calls/day**, and
8,000 tokens/minute ≈ 4 such calls/minute. An earlier draft of this book claimed
1,000 RPD "comfortably covers 300 calls" — wrong, because requests per day is
not the binding constraint. Hence `ATLAS_TIER_H_CALL_CAP=100` and
`ATLAS_TIER_H_TOKEN_CAP=200000`. From Phase 5 a retrieval prompt can exceed
4,000 tokens, which halves the call budget again; cache accordingly.

**Enforcement status:** both caps are declared in `Settings` and honoured by
convention. Phase 1 needs no hosted calls at all, so enforcement is deferred
again: automatic enforcement (a counter that raises `BudgetExceeded`) arrives
with the Tier H client wiring in **Phase 2**. Phase 1 does build the
*episode-level* token budget, in Assignment 2 — a different mechanism at a
different layer, and worth not confusing with the per-phase quota.

## Primary sources cited as history in Phase 1 (dated events, stable)

These are historical facts, not current-state facts. They are recorded here only
so you can check them; they are safe to quote in prose *with their dates*.

| Event | Date | Source | Checked |
|---|---|---|---|
| ReAct (Yao et al., arXiv:2210.03629) | 6 Oct 2022; ICLR 2023 | https://arxiv.org/abs/2210.03629 | 2026-09-03 |
| Toolformer (Schick et al., arXiv:2302.04761) | 9 Feb 2023 | https://arxiv.org/abs/2302.04761 | 2026-09-03 |
| AutoGPT initial release (**secondary source** — Wikipedia, not primary) | 30 Mar 2023 | https://en.wikipedia.org/wiki/AutoGPT | 2026-09-03 |
| OpenAI function calling in Chat Completions | 13 Jun 2023 | https://openai.com/index/function-calling-and-other-api-updates/ | 2026-09-03 |
| Anthropic computer use, public beta | 22 Oct 2024 | https://www.anthropic.com/news/3-5-models-and-computer-use | 2026-09-03 |
| Model Context Protocol open-sourced (initial spec revision 2024-11-05) | 25 Nov 2024 | https://www.anthropic.com/news/model-context-protocol | 2026-09-03 |
| Anthropic, "Building effective agents" | 19 Dec 2024 | https://www.anthropic.com/engineering/building-effective-agents | 2026-09-03 |
| Russell & Norvig, *AIMA* 4th ed. (Ch. 2, Intelligent Agents) | 2020 (Pearson, © 2021) | https://aima.cs.berkeley.edu/ | 2026-09-03 |

## Security guidance — current editions

| Fact | Value | Source | Checked |
|---|---|---|---|
| OWASP Top 10 for LLM Applications, current edition | **2026 edition, published 4 Aug 2026** | https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/ | 2026-09-03 |
| OWASP Top 10 for Agentic Applications, current edition | **2026 edition, published 9 Dec 2025**; entries numbered ASI01–ASI10 | https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/ | 2026-09-03 |
| Agentic entries referenced in Phase 1 | ASI01 agent goal hijack, ASI02 tool misuse, ASI03 identity and privilege abuse | https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/ | 2026-09-03 |
| OWASP Agent Control Standard (ACS) | published 1 Sep 2026 — not used in this book; forward pointer only | https://genai.owasp.org/resource/agent-control-standard-acs/ | 2026-09-03 |

Note on the ASI names: the publication date and numbering scheme come from the
OWASP page above; the individual entry *titles* I took from secondary summaries,
not from the PDF itself. Download the PDF and check them yourself before quoting
them anywhere it matters. Phase 11 reads the list properly.

## Anthropic guidance — currency caveat

| Fact | Value | Source | Checked |
|---|---|---|---|
| Status of "Building effective agents" (Dec 2024) | Still published, but now carries an editorial note that the tooling landscape it describes has changed, pointing to Anthropic's newer managed-agents material | https://www.anthropic.com/engineering/building-effective-agents | 2026-09-03 |

The workflow/agent *distinction* in that post is what Phase 1 relies on, and it
has aged well. Its framework recommendations have not, which is exactly why
framework state lives in this file.

## Coding-assistant candidates

| Candidate | Cost model | Runs against Tier A? | Source | Checked |
|---|---|---|---|---|
| OpenCode | see vendor terms | Yes — documented Ollama integration | https://docs.ollama.com/integrations/opencode | 2026-09-02 |
| Goose | see vendor terms | Yes — documented Ollama integration | https://docs.ollama.com/integrations/goose | 2026-09-02 |
| Cline CLI | see vendor terms | Yes — documented Ollama integration | https://docs.ollama.com/integrations/cline-cli | 2026-09-02 |
| Claude Code | Requires a paid Claude plan or API credits — check current terms at the source | Yes — documented Ollama integration | https://docs.claude.com/en/docs/claude-code/overview · https://docs.ollama.com/integrations/claude-code | 2026-09-02 |

Any of these can be pointed at your Tier A model, which is what keeps the course
at $0. I have not independently verified each vendor's current pricing or
licence; check the source before you sign up.

## Known-unverified facts (do not treat as checked)

| Fact | Why unverified | What to do |
|---|---|---|
| Per-tag `tools` capability for any Ollama model | Library badges are family-level; only your machine is authoritative | Run `ollama show $ATLAS_MODEL` |
| Current pricing/licence terms of any coding assistant | Vendor pages change; I did not test each signup flow | Read the vendor page before signing up |
| Gemini per-model free-tier RPM/TPM/RPD | Published per project in AI Studio, not in public docs | Read your own limits page |
| Tier A/H latency and tokens/sec on your hardware | Hardware-specific; my figures are estimates | `make results` |
| Per-step success rate of any model on tool selection | Never measured by me; every figure in Phase 1 §6.7 is illustrative arithmetic | Phase 3's eval harness |
| Whether your runner reuses the KV cache between agent steps | Runner- and build-specific; determines whether per-step latency is flat or climbing | `make results`, and watch latency across steps |
| OWASP ASI entry titles | Taken from secondary summaries, not the PDF | Download the PDF |

## Phase 1 re-verification (2026-09-03)

Every pinned package version in this file was re-checked against PyPI on
2026-09-03 and **none had changed** since 2026-09-02: pydantic 2.13.5, httpx
0.28.1, python-dotenv 1.2.3, pytest 9.1.1, pytest-asyncio 1.4.0, tenacity
9.1.4, langgraph 1.2.11, langchain 1.3.18, mcp 2.1.1, openai 3.7.0, ollama
0.6.2, uv 0.12.9, ruff 0.16.5. Ollama's latest stable release is still v0.33.2.
Phase 1 adds no dependency.

## Phase 1 revision (2026-09-03) — corrections found by review

| Fact | Value | Source | Checked |
|---|---|---|---|
| `Trajectory` token totals | `computed_field`, not bare `@property` — bare properties are absent from `model_dump()` and two Phase 1 eval checks named them | ATLAS_INTERFACES.md v0.4, invariant 11 | 2026-09-03 |
| Naive `int(log(target)/log(p))` off-by-one | Real, and only at `target == p**k`. Verified: 91 disagreements across `p ∈ {0.5…0.999}`, `k ≤ 40`; always by exactly 1; one correction iteration suffices. **`p=0.9, target=0.9` is NOT such a case** — an earlier draft used it as the example and was wrong | measured locally, 2026-09-03 | 2026-09-03 |
| Multiply-up loop for `max_steps_for_target` | Rejected: 1,053,605 iterations at `p=0.9999999, target=0.9`. Bounded log+correction required | measured locally | 2026-09-03 |
| `HEADCOUNT` departments | Four (engineering 14, operations 9, sales 6, support 9 = 38), matching `docs/ATLAS_SPEC.md` §1. An earlier draft had three and contradicted the spec | docs/ATLAS_SPEC.md | 2026-09-03 |
| Tier F "prompt tokens" | Whitespace word counts from `FakeLLMClient`, **not** tokens. `make results` now refuses `--append-results` on Tier F | scripts/phase01_results.py | 2026-09-03 |
| Git repository | Present. `phase-00` and `phase-01` tags; `phase-00` has only an empty `atlas/agents/__init__.py`; `minimal.py` first appears at `phase-01`, verified with `git ls-tree` | this repo | 2026-09-03 |

## Phase 2 delta (checked 2026-09-03)

### Re-verification of everything Phase 1 pinned

| Fact | Value | Source | Checked |
|---|---|---|---|
| pydantic | 2.13.5 — unchanged | https://pypi.org/pypi/pydantic/json | 2026-09-03 |
| httpx | 0.28.1 — unchanged | https://pypi.org/pypi/httpx/json | 2026-09-03 |
| pytest | 9.1.1 — unchanged | https://pypi.org/pypi/pytest/json | 2026-09-03 |
| tenacity | 9.1.4 — unchanged | https://pypi.org/pypi/tenacity/json | 2026-09-03 |
| Ollama latest stable | v0.33.2 (2026-08-27) — unchanged | https://github.com/ollama/ollama/releases | 2026-09-03 |
| Ollama pre-release (do not use) | **v0.33.3-rc2 (2026-09-02)** — corrected from rc0. GitHub's release API was unreachable from the authoring sandbox; taken from a tag mirror, so treat as **secondary** | https://mise-versions.jdx.dev/tools/ollama | 2026-09-03 |

### Structured outputs — Tier A (local runner)

| Fact | Value | Source | Checked |
|---|---|---|---|
| JSON mode | `"format": "json"` on `/api/chat` | https://docs.ollama.com/capabilities/structured-outputs | 2026-09-03 |
| Schema-constrained mode | `"format": <JSON Schema object>` — bare, no envelope, **no `strict` flag** | https://docs.ollama.com/capabilities/structured-outputs | 2026-09-03 |
| Recommended practice | pass the schema as text in the prompt as well, to ground the reply; lower temperature (e.g. 0) for determinism | https://docs.ollama.com/capabilities/structured-outputs | 2026-09-03 |
| Cloud models | Ollama's Cloud does **not** currently support structured outputs | https://docs.ollama.com/capabilities/structured-outputs | 2026-09-03 |
| Also reachable via | the OpenAI-compatible `/v1` path using `response_format` | https://docs.ollama.com/capabilities/structured-outputs | 2026-09-03 |

### Structured outputs — Tier H (Groq, candidate 1)

| Fact | Value | Source | Checked |
|---|---|---|---|
| Strict mode | `response_format.json_schema.strict = true` uses **constrained decoding**; documented as never producing invalid JSON and 100% schema-adherent | https://console.groq.com/docs/structured-outputs | 2026-09-03 |
| Strict-mode schema requirements | **all** properties in `required`; `additionalProperties: false` on every object; optional fields as a union with `null` | https://console.groq.com/docs/structured-outputs | 2026-09-03 |
| Models supporting `strict: true` | `openai/gpt-oss-20b`, `openai/gpt-oss-120b`, `qwen/qwen3.8-27b` | https://console.groq.com/docs/structured-outputs | 2026-09-03 |
| Best-effort mode (`strict: false`, the default) | valid JSON but schema adherence **not** guaranteed; may return HTTP 400 `Generated JSON does not match the expected schema` | https://console.groq.com/docs/structured-outputs | 2026-09-03 |
| Models supporting best-effort | the three above plus `openai/gpt-oss-safeguard-20b` | https://console.groq.com/docs/structured-outputs | 2026-09-03 |
| JSON object mode | `response_format={"type":"json_object"}`; all models; **requires** an explicit JSON instruction in the messages; no schema enforcement | https://console.groq.com/docs/structured-outputs | 2026-09-03 |
| Feature composition | **streaming and tool use are NOT supported with structured outputs** | https://console.groq.com/docs/structured-outputs | 2026-09-03 |
| Supported schema subset | primitives, object, array, enum, `anyOf`, `$defs`/`$ref`, root recursion via `#` | https://console.groq.com/docs/structured-outputs | 2026-09-03 |
| Vendor's own caveat | structured outputs give **schema compliance, not semantic accuracy** | https://console.groq.com/docs/structured-outputs | 2026-09-03 |

### Thinking / reasoning modes

| Fact | Value | Source | Checked |
|---|---|---|---|
| Tier A toggle | top-level `"think"` on `/api/chat`; boolean or a level (`low`/`medium`/`high`/`max`), model-dependent | https://docs.ollama.com/capabilities/thinking | 2026-09-03 |
| Where the trace lands | `message.thinking` (chat) — separate from `message.content` | https://docs.ollama.com/capabilities/thinking | 2026-09-03 |
| Models that ignore booleans | GPT-OSS requires `low`/`medium`/`high`; `true`/`false` are ignored and the trace cannot be fully disabled | https://docs.ollama.com/capabilities/thinking | 2026-09-03 |
| Tier H toggle | provider-specific reasoning configuration on the OpenAI-compatible body; Atlas sends `reasoning_effort`. **Verify against your provider before relying on it** | https://console.groq.com/docs/reasoning | 2026-09-03 |

### Dependency decision reversed

| Fact | Value | Source | Checked |
|---|---|---|---|
| tenacity | **Not adopted.** Phase 1's file listed it as "first used Phase 2". Phase 2 instead ships `RetryPolicy`, `is_retryable_status`, `retry_after_seconds` and `backoff_delay` as ~20 lines of pure, offline-testable code. A retry decorator hides control flow, and this phase's whole subject is making control flow assertable. Earliest realistic reconsideration: Phase 13, for HTTP-level concerns in the FastAPI service | https://pypi.org/pypi/tenacity/json | 2026-09-03 |
| Phase 2 dependency additions | **none.** `requirements.txt` and `pyproject.toml` are unchanged | this repo | 2026-09-03 |

### Historical facts cited in Phase 2 prose (dated, stable)

| Event | Date | Source | Checked |
|---|---|---|---|
| Liu et al., "Lost in the Middle" (arXiv:2307.03172) | submitted 6 Jul 2023; published *TACL* vol. 12, 2024, pp. 157–173 | https://aclanthology.org/2024.tacl-1.9/ | 2026-09-03 |
| Hong, Troynikov & Huber, "Context Rot" (Chroma technical report; 18 models evaluated) | July 2025 | https://research.trychroma.com/context-rot | 2026-09-03 |
| OpenAI, "Introducing Structured Outputs in the API" (constrained sampling / CFG; 93% trained vs 100% constrained on their own schema-following benchmark) | 6 Aug 2024 | https://openai.com/index/introducing-structured-outputs-in-the-api/ | 2026-09-03 |
| Anthropic, "Effective context engineering for AI agents" (defines compaction) | 29 Sep 2025 | https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents | 2026-09-03 |
| Ollama template variables (`.System`, `.Prompt`, `.Response`, `.Messages`, `.Tools`, `.Suffix`); default template is `{{ .Prompt }}` | current docs | https://docs.ollama.com/template | 2026-09-03 |

### Measured locally during Phase 2 authoring (this machine, not yours)

| Fact | Value | Source | Checked |
|---|---|---|---|
| Pydantic **lax** coercion accepts a stringified bool | `{"b":"yes"}` validates as `True`; also `"true"`, `1`, `0`, and numeric strings for `int`. `ConfigDict(strict=True)` rejects all of them. Found by this phase's own test suite, not by reading docs | measured locally, pydantic 2.13.5 | 2026-09-03 |
| `additionalProperties: false` does not make Pydantic reject extra keys | Confirmed: extra keys are silently ignored unless `ConfigDict(extra="forbid")`. The schema flag and the validator flag are two separate switches | measured locally | 2026-09-03 |
| Wrapper-order bug | `BudgetedClient(CachingClient(...))` with `max_calls=1` raises `BudgetExceeded` on a request the cache would have served free. Reproduced and pinned by two tests | measured locally | 2026-09-03 |
| Generic Pydantic `BaseModel` for `StructuredResult[T]` | Works on pydantic 2.13.5, including `model_dump()` and `model_validate` | measured locally | 2026-09-03 |
| pytest exit code for an all-skipped file | 5 ("nothing collected"), which the Phase 1 `grade` target misreported as failure. Fixed | measured locally, pytest 9.1.1 | 2026-09-03 |
| Offline suite | 153 tests, ~0.2 s, no network, no model, no `.env` | this repo | 2026-09-03 |

### Still unverified (do not treat as checked)

| Fact | Why unverified | What to do |
|---|---|---|
| Whether **your** Tier A tag does real constrained decoding | Family-level badges again; and a runner may accept `format` while falling back to prompt-guided JSON | `make results`: at `mode=schema` the temperature row should be nearly flat. If it is not, suspect a fallback |
| Tier H `reasoning_effort` field name and accepted values | I did not exercise a live hosted reasoning call | Read your provider's reasoning page before trusting it |
| First-try validity, repair rate, thinking cost | Never measured by me; every figure in `docs/RESULTS.md` for Phase 2 is an author estimate | `make results --thinking` |
| Whether `strict: true` model lists have changed | Provider model lists move weekly | Re-read the provider's supported-models table |

## Phase 2 revision (2026-09-03) — defects found by self-review

| Fact | Value | Source | Checked |
|---|---|---|---|
| `extract_json_object` and top-level arrays | An earlier version searched only for `{`, silently reducing `[{"a":1}]` to `{"a":1}` — valid JSON, wrong data, no error. Fixed: the opener is chosen by position. 5 regression tests | measured locally | 2026-09-03 |
| `x-ratelimit-reset` as a retry delay | **Removed.** Provider-specific header whose units I never verified; guessing is worse than ignoring, because the fallback backoff schedule is at least known to be sane | measured locally | 2026-09-03 |
| Per-phase Tier H cap in `make results` | **Was broken.** `get_client` was called inside the per-call helper, so every call got a fresh `CallBudget` and the cap could never fire across a sweep. Verified: 3 calls → 3 distinct budget objects. Fixed by `build_sweep_client()`; see D-07 | measured locally | 2026-09-03 |
| `make record` recording loss | **Was broken.** Same root cause: `RecordingClient` rebuilt per call restarted its counter, so 6 prompts per grid cell wrote 1 filename. Fixed; regression test asserts monotonic numbering | measured locally | 2026-09-03 |
| `ConfigDict(extra="forbid")` on `TaskUnderstanding` | **Added.** `additionalProperties: false` constrains the model; Pydantic's default silently drops unknown keys. Two switches. Side effect: with `extra="forbid"` Pydantic emits `additionalProperties: false` into the schema itself, so a well-defined model is already strict-mode-legal | measured locally, pydantic 2.13.5 | 2026-09-03 |
| `make check-docs` false assurance | A drifting block used to be removable — delete it and the guard reported success. `docs/DOC_BLOCKS.json` now pins a minimum block count per document; verified to fail at 31 when 32 are expected | measured locally | 2026-09-03 |
| `make results` Tier coverage | Tier H now has its own experiment (`--strict-compare`), tagged **[Tier H recommended]**, because the native dialect has no `strict` flag and both arms would be identical on Tier A | scripts/phase02_results.py | 2026-09-03 |
| Makefile `ARGS` | Added, so the documented `make results ARGS=--thinking` actually passes the flag. It previously did not | this repo | 2026-09-03 |
| Offline suite | **163** tests (was 153), including 4 regression tests for the three shipped bugs | this repo | 2026-09-03 |

## Phase 3 delta (checked 2026-09-03)

### Re-verification of every pinned package

| Fact | Value | Source | Checked |
|---|---|---|---|
| pydantic | 2.13.5 — unchanged | https://pypi.org/pypi/pydantic/json | 2026-09-03 |
| httpx | 0.28.1 — unchanged | https://pypi.org/pypi/httpx/json | 2026-09-03 |
| python-dotenv | 1.2.3 — unchanged | https://pypi.org/pypi/python-dotenv/json | 2026-09-03 |
| pytest | 9.1.1 — unchanged | https://pypi.org/pypi/pytest/json | 2026-09-03 |
| langgraph | 1.2.11 — unchanged (Phase 9, NOT BEFORE) | https://pypi.org/pypi/langgraph/json | 2026-09-03 |
| mcp (Python SDK) | 2.1.1 — unchanged (Phase 15) | https://pypi.org/pypi/mcp/json | 2026-09-03 |
| ollama (Python client) | 0.6.2 — unchanged | https://pypi.org/pypi/ollama/json | 2026-09-03 |
| **langchain** | **1.4.0 — CHANGED from 1.3.18** (Phase 10) | https://pypi.org/pypi/langchain/json | 2026-09-03 |
| **openai** | **3.8.0 — CHANGED from 3.7.0** | https://pypi.org/pypi/openai/json | 2026-09-03 |
| Ollama runner, latest stable | v0.33.2 (2026-08-27) — unchanged | https://github.com/ollama/ollama/releases | 2026-09-03 |
| Phase 3 dependency additions | **none.** `requirements.txt` and `pyproject.toml` unchanged; everything this phase adds is standard library plus pydantic | this repo | 2026-09-03 |

Neither changed package is used before Phase 9, so nothing in Phases 0–8 moves.
Re-verify both when you reach the framework phases; a minor bump in a
1.x framework is not automatically compatible with the code in this book.

### Tool calling — Tier A (Ollama native `/api/chat`)

| Fact | Value | Source | Checked |
|---|---|---|---|
| Where tool definitions go | top-level `tools` array, entries `{"type":"function","function":{name, description, parameters}}` | https://docs.ollama.com/capabilities/tool-calling | 2026-09-03 |
| Response shape | `message.tool_calls[].function.{index, name, arguments}` | https://docs.ollama.com/capabilities/tool-calling | 2026-09-03 |
| `arguments` type | a JSON **object** | https://docs.ollama.com/capabilities/tool-calling | 2026-09-03 |
| Tool call identifier | **`function.index`** (positional). There is **no** `id` field | https://docs.ollama.com/capabilities/tool-calling | 2026-09-03 |
| Tool result message | `{"role":"tool", "tool_name": <name>, "content": <text>}` — **`tool_name`**, and no `tool_call_id` field exists in this dialect | https://docs.ollama.com/capabilities/tool-calling | 2026-09-03 |
| Parallel tool calling | documented and supported; results are matched by **order**, since there is no per-call id | https://docs.ollama.com/capabilities/tool-calling | 2026-09-03 |
| Tool calling with streaming | documented: accumulate `thinking`, `content` and `tool_calls` chunks and send them back together | https://docs.ollama.com/capabilities/tool-calling | 2026-09-03 |
| Roles accepted | `system`, `user`, `assistant`, `tool` | https://docs.ollama.com/api/chat | 2026-09-03 |
| **Conflicting older claim** | A mirrored copy of the API reference states tools "requires stream to be set to false". The current docs have a dedicated streaming section, so treat the mirror as **stale**. Atlas sends `stream=false` regardless, so this does not affect the code | https://ollama.readthedocs.io/en/api/ (secondary/stale) vs https://docs.ollama.com/capabilities/tool-calling | 2026-09-03 |

### Tool calling — Tier H (OpenAI-compatible)

| Fact | Value | Source | Checked |
|---|---|---|---|
| Where tool definitions go | top-level `tools` array, **identical envelope** to the native dialect | https://console.groq.com/docs/tool-use | 2026-09-03 |
| `arguments` type | a JSON-encoded **string**; must be `json.loads`'d | https://console.groq.com/docs/tool-use | 2026-09-03 |
| Tool call identifier | `id` on each call | https://console.groq.com/docs/tool-use | 2026-09-03 |
| Tool result message | `{"role":"tool", "tool_call_id": <id>, "name": <name>, "content": <text>}` | https://console.groq.com/docs/tool-use | 2026-09-03 |
| Parallel tool calls | `parallel_tool_calls` parameter; `tool_choice` controls whether a tool is used | https://console.groq.com/docs/api-reference | 2026-09-03 |
| `tool_choice` on Tier A's `/v1` path | listed as **unsupported** in Ollama's OpenAI-compatibility mode, along with `logit_bias`, `n` and `logprobs`. Atlas does not send it | https://docs.ollama.com/api/openai-compatibility | 2026-09-02 |
| Feature composition | structured outputs are documented as **not** supported together with tool use or streaming. This is the concrete reason Atlas keeps a prompt-based arm | https://console.groq.com/docs/structured-outputs | 2026-09-03 |

**The one difference to internalise.** A `tool_name` identifies the *tool*; a
`tool_call_id` identifies the *call*. They stop being interchangeable the
moment two calls go to one tool. See `docs/DECISIONS.md` D-12.

### Web search providers — VOLATILE, and why Atlas ships a local mock

| Fact | Value | Source | Checked |
|---|---|---|---|
| Brave Search API, vendor's own plans page | Postpaid plans, each described as including **$5 in free credits every month**. The word "free tier" does not appear as a plan | https://api-dashboard.search.brave.com/app/plans | 2026-09-03 |
| Secondary trackers, in direct conflict | Some state a 2,000-query/month free plan still exists; others state the free tier was removed in Feb 2026 and replaced with $5 monthly credits (~1,000 queries). These cannot all be true | multiple secondary trackers | 2026-09-03 |
| **What Atlas does** | Default search backend is the committed seeded corpus `data/web/index.json`. A live provider is a single injected `fetch` callable, Tier H, capped and cached, and **no test requires it** | this repo | 2026-09-03 |

**Do not take a query quota from this book.** Read the provider's own pricing
page on the day you sign up. The conflict above is exactly why a current-state
fact never appears in prose.

### Historical facts cited in Phase 3 prose (dated, stable)

| Event | Date | Source | Checked |
|---|---|---|---|
| ReAct (Yao et al., arXiv:2210.03629) | 6 Oct 2022; ICLR 2023 | https://arxiv.org/abs/2210.03629 | 2026-09-03 |
| Toolformer (Schick et al., arXiv:2302.04761) | 9 Feb 2023 | https://arxiv.org/abs/2302.04761 | 2026-09-03 |
| OpenAI function calling in Chat Completions | 13 Jun 2023 | https://openai.com/index/function-calling-and-other-api-updates/ | 2026-09-03 |
| Anthropic, "Raising the bar on SWE-bench Verified with Claude 3.5 Sonnet" (tool-description refinements) | 6 Jan 2025 | https://www.anthropic.com/engineering/swe-bench-sonnet | 2026-09-03 |
| Anthropic, "The 'think' tool" | 20 Mar 2025 | https://www.anthropic.com/engineering/claude-think-tool | 2026-09-03 |
| Anthropic, "Writing effective tools for agents — with agents" | 11 Sep 2025 | https://www.anthropic.com/engineering/writing-tools-for-agents | 2026-09-03 |
| Anthropic, "Beyond permission prompts: making Claude Code more secure and autonomous" (sandboxing; forward pointer to Phase 14) | 20 Oct 2025 | https://www.anthropic.com/engineering/claude-code-sandboxing | 2026-09-03 |
| Anthropic, "Introducing advanced tool use on the Claude Developer Platform" | 24 Nov 2025 | https://www.anthropic.com/engineering/advanced-tool-use | 2026-09-03 |
| Anthropic, "Demystifying evals for AI agents" | 9 Jan 2026 | https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents | 2026-09-03 |
| Anthropic, "Quantifying infrastructure noise in agentic coding evals" | 5 Feb 2026 | https://www.anthropic.com/engineering/infrastructure-noise | 2026-09-03 |
| τ-bench (arXiv:2406.12045) and τ²-bench (arXiv:2506.07982) | 2024 / 2025 | https://arxiv.org/abs/2406.12045 · https://arxiv.org/abs/2506.07982 | 2026-09-03 |

### Measured locally during Phase 3 authoring (this machine, not yours)

| Fact | Value | Source | Checked |
|---|---|---|---|
| A `subprocess` "sandbox" does **not** contain filesystem reads | `open('/etc/hostname').read()` from a child with `cwd=jail` and a scrubbed `env` **succeeded** | measured locally | 2026-09-03 |
| It does **not** contain the network | `socket.create_connection(('1.1.1.1', 80))` from the same child **succeeded** | measured locally | 2026-09-03 |
| What it does contain | `while True: pass` → `TimeoutExpired`; 900 MB allocation under `RLIMIT_AS=512MB` → `MemoryError`; `python -I` leaves zero `site-packages` entries on `sys.path` | measured locally | 2026-09-03 |
| `resource` and `preexec_fn` | `resource` is Unix-only; `preexec_fn` is documented unsafe with threads. Atlas guards the first and Phase 13 replaces the second | Python docs + measured | 2026-09-03 |
| `strict_json_schema` on a generated tool schema | puts a defaulted parameter in `required` while keeping its `"default"`, which is strict-mode-legal and what D-04's reasoning wants | measured locally | 2026-09-03 |
| Pydantic auto `title` keys | emitted for the model and every property; stripped recursively by `schema_for` | measured locally, pydantic 2.13.5 | 2026-09-03 |
| Read-only guard gap | `is_read_only_sql("select * from shipment")` returned `(True, "ok")` and the tool returned base-table rows. Fixed with a second database, not a better regex | measured locally | 2026-09-03 |
| Symlink jail escape | `resolve_in_jail` blocks a link inside the jail pointing at `/etc`, because it uses `Path.resolve()`; `os.path.normpath` would have allowed it | measured locally | 2026-09-03 |
| Seeded generator determinism | two runs at `seed=7` produced byte-identical `atlas.db` and `web/index.json` (SHA-256 digests equal) | measured locally | 2026-09-03 |
| Eval harness first run | 12/21, all nine inherited tasks failing for harness reasons; 19/21 after `dispatch()`; 20/20 with 1 honest skip after `tier_skip_reason()` | measured locally | 2026-09-03 |
| Grader defect | `p01-prompt-grows-monotonically` failed at exactly `60` against `gt 60` — a threshold check penalising the target being hit | measured locally | 2026-09-03 |
| Offline suite | **389** tests (was 163), ~2.1 s, no network, no model, no `.env` | this repo | 2026-09-03 |
| Text-arm prompt size | ~1.8× the native arm on the same probes (median 1,487 vs 802 by `FakeLLMClient` accounting — **whitespace word counts, not tokens**) | measured locally | 2026-09-03 |

### Still unverified (do not treat as checked)

| Fact | Why unverified | What to do |
|---|---|---|
| Whether **your** Tier A tag does native tool calling at all | Capability badges are family-level | `ollama show $ATLAS_MODEL`, look for `tools` |
| Whether your tag's tool calling is constrained decoding or prompt-guided parsing | Not stated in any documentation I could find | `make results`: if the native and text arms land within a couple of points, suspect the latter |
| Every Phase 3 number in `docs/RESULTS.md` | Never measured by me; all are author estimates | `make results`, then `make evals ARGS=--append-results` |
| Per-step tool-selection reliability for any model | The figure Phase 1 §6.7 built its arithmetic on, still unmeasured by me | `make results`, `right_tool` column |
| How much of tool-call accuracy the descriptions carry | The ablation arm is shipped but I have not run it against a model | `make results --ablate`, ideally on Tier H |
| Current free quota of any web search provider | Vendor page and secondary trackers disagreed on the day I checked | Read the provider's pricing page yourself |
| OWASP ASI entry titles | Still taken from secondary summaries, not the PDF | Download the PDF; Phase 11 reads the list properly |

## Phase 3 revision (2026-09-03) — defects found by reviewing the shipped phase

| Fact | Value | Source | Checked |
|---|---|---|---|
| Eval suite reachability | **Was broken.** Every Phase 3 task declares `tier: "F"` (it carries offline fixtures), and the client factory read `settings.tier == "F" or task.tier == "F"`, so `ATLAS_TIER=A make evals` replayed fixtures and the 20-task golden set could never reach a model. Fixed: the factory keys on `settings.tier` alone; `tier` is documented as a minimum requirement (D-14) | measured locally | 2026-09-03 |
| `--append-results` provenance check | **Was broken.** Refused only when `settings.tier == "F"`, so a Tier A sweep could append a fixture-derived 100% pass rate to `docs/RESULTS.md`. Fixed: `TrialResult.replayed_fixtures` per trial, and the append refuses if **any** trial replayed. The report header now states the source | measured locally | 2026-09-03 |
| Batch dispatch with an unknown tool | **Was broken.** The unknown-tool branch called `execute()` over the whole batch before ending the episode, so `[write_file(...), phantom()]` performed the write and then exited `bad_action`. Verified with an auditing tool. Fixed by `unknown_tool_names()` and validate-then-dispatch | measured locally | 2026-09-03 |
| `ToolSpec.examples` | **Was dead.** Accepted by `@tool`, stored, rendered nowhere. Now rendered into `to_wire()` via `prompt_description` and into `describe_for_prompt()`, which is what makes per-tool few-shot examples real rather than advertised | measured locally | 2026-09-03 |
| Trajectory replay | **Was missing** (a listed deliverable I declined and justified). Added `trajectory_as_fixtures` and `replay_trajectory`: differential debugging with the model held fixed. Honest limit: it bypasses the parse functions, so `atlas.record.ReplayClient` remains the tool that covers those | measured locally | 2026-09-03 |
| `ErrorKind` | Was `str`, giving no type safety while a comment claimed three kinds and the code shipped four. Now a closed `Literal` of the four, with the loop's response to each documented | measured locally | 2026-09-03 |
| `max_tokens=640` | Was an undefended literal in a phase whose own pitfall list forbids magic thresholds. Now `DEFAULT_MAX_OUTPUT_TOKENS`, with the derivation in a comment | measured locally | 2026-09-03 |
| `python evals/run.py` | **Did not run.** The harness's own report prints that command, and it raised `ModuleNotFoundError` without `PYTHONPATH`. Fixed with a `sys.path` shim; `make trace` and the bare invocation both work | measured locally | 2026-09-03 |
| `make_file_tools` signature | Annotated as returning two callables, returned three, silenced with `# type: ignore`. Annotation corrected | measured locally | 2026-09-03 |
| `make_sql_tool` dead substitution | The `SCHEMA_PLACEHOLDER` replacement on `description` never fired (the summary contains no placeholder). Only the `properties["sql"]` path does work | measured locally | 2026-09-03 |
| `COMMON_ZONES` comment | Claimed "the four zones Northwind operates in"; `ATLAS_SPEC.md` §1 says one office. Reworded to customer/supplier zones | measured locally | 2026-09-03 |
| Offline suite | **402** tests (was 389), including 13 regression tests for the defects above | this repo | 2026-09-03 |
| Eval suite size | **22 gradeable offline** (was 20), +2 regression tasks for F-03-06 and the §8 citation failure; 23 total with the Tier A task | this repo | 2026-09-03 |
| `make check-docs` status for this phase | The phase document must be saved next to the repo for the guard to run. `docs/DOC_BLOCKS.json` pins 28 blocks. Until the document is on disk, invariant 8 is **unverified for Phase 3** — spot-checked by hand during the revision, and the guard correctly caught a deliberately drifted block and a short block count | measured locally | 2026-09-03 |

## Phase 4 delta — checked 2026-09-04

| fact | value | source URL | checked on |
|---|---|---|---|
| `langchain` latest release (Phase 10 dependency; NOT imported before Phase 9) | 1.4.0, uploaded 2026-09-03 | https://pypi.org/pypi/langchain/json | 2026-09-04 |
| `langgraph` latest release (Phase 9 dependency; NOT imported before Phase 9) | 1.2.11, uploaded 2026-08-11 | https://pypi.org/pypi/langgraph/json | 2026-09-04 |
| `mcp` Python SDK latest release (Phase 15) | 2.1.1, uploaded 2026-08-25 | https://pypi.org/pypi/mcp/json | 2026-09-04 |
| `pydantic` pin — re-verified, unchanged | 2.13.5, uploaded 2026-08-28 | https://pypi.org/pypi/pydantic/json | 2026-09-04 |
| `pytest` pin — re-verified, unchanged | 9.1.1, uploaded 2026-06-19 | https://pypi.org/pypi/pytest/json | 2026-09-04 |
| `httpx` pin — re-verified, unchanged | 0.28.1, uploaded 2024-12-06 | https://pypi.org/pypi/httpx/json | 2026-09-04 |
| `python-dotenv` pin — re-verified, unchanged | 1.2.3, uploaded 2026-08-16 | https://pypi.org/pypi/python-dotenv/json | 2026-09-04 |
| Anthropic's *Building Effective Agents* now carries a banner saying much of the tooling landscape it describes has changed since Dec 2024, and points to Claude Managed Agents for the current approach | banner present; the five workflow patterns (incl. orchestrator-workers, evaluator-optimizer) are unchanged | https://www.anthropic.com/engineering/building-effective-agents | 2026-09-04 |
| Anthropic reported token reduction from having an agent write code that calls tools, vs. loading all definitions and piping results through context | ~150,000 → ~2,000 tokens on one example workflow (98.7%) | https://www.anthropic.com/engineering/code-execution-with-mcp | 2026-09-04 |
| Anthropic reported token reduction from on-demand tool loading alone | 85%; tool definitions + results can consume 50,000+ tokens before the agent reads the request | https://www.anthropic.com/news/advanced-tool-use | 2026-09-04 |
| Which model to use for Tier A / Tier H this phase | unchanged from the Phase 3 rows above; re-run `ollama show $ATLAS_MODEL` and check the `thinking` capability before enabling `think` | (see the Tier A / Tier H rows above) | 2026-09-04 |
| New dependencies added by Phase 4 | **none.** The plot is `atlas/report.py`, pure Python; see its docstring for why matplotlib was refused | (this repo) | 2026-09-04 |

### Corrections made during Phase 4 review

| fact | value | source URL | checked on |
|---|---|---|---|
| `atlas.agents.plan.check_result_kind` counted as the fifth Atlas verifier (section 6.6 said four, the mastery checklist said five) | five: calculator AST whitelist, `@tool` args model, query database, `resolve_in_jail`, `check_result_kind` | (this repo) | 2026-09-04 |
| Seed-dependence of the sweep's expected answers | headcounts are spec-fixed (38 total, 14 engineering at any seed); shipment totals are NOT (363 at seed 7, 305 at seed 8), which is why `Problem.answer_sql` queries rather than hard-codes | `scripts/gen_dataset.py`, verified by running both seeds | 2026-09-04 |

### Pre-release APIs referenced but NOT used in code

None new this phase. Phase 4 is framework-free plain Python plus the Phase 2
client, as the stack rule requires for Phases 1–8.

### Forward pointers (concept taught, build deferred)

* **CodeAct / code-as-action** (§6.12): taught as concept, built in Appendix
  F.1 on a branch off `phase-04`. The Phase 3 sandbox stays in the tree because
  `run_python` uses it, and §6.12 is explicit that a resource-bounded
  subprocess is not a container — real containment is Phase 14.
* **Tree of Thoughts and search** (§6.10): reading only, never built. Search
  needs a free undo and side-effecting tools do not have one.
* **Parallel execution of a level set**: `ready_steps` returns the whole level
  set and Phase 4's executor takes `[0]`. Phase 8 makes the fan-out real, where
  ordering can be a test rather than a convention.


## Phase 5 delta — checked 2026-09-04

| fact | value | source URL | checked on |
|---|---|---|---|
| `pydantic` / `httpx` / `python-dotenv` / `pytest` pins | unchanged from the Phase 4 rows; Phase 5 adds **no new dependency** | (this repo; PyPI rows above) | 2026-09-04 |
| Anthropic's five workflow patterns (chaining with gates, routing, parallelization by sectioning and by voting, orchestrator-workers, evaluator-optimizer) | still exactly as published 19 Dec 2024, including the sectioning/voting split and the "subtasks are not pre-defined" line that separates orchestrator-workers from parallelization | https://www.anthropic.com/engineering/building-effective-agents | 2026-09-04 |
| That post's editorial banner | present: says much of the tooling landscape it describes has changed since Dec 2024 and points to Anthropic's managed-agents material for the current approach | https://www.anthropic.com/engineering/building-effective-agents | 2026-09-04 |
| That post's framework list (current contents) | Claude Agent SDK, Strands Agents SDK (AWS), Rivet, Vellum — i.e. edited since publication, which is why framework state lives in this file and never in prose | https://www.anthropic.com/engineering/building-effective-agents | 2026-09-04 |
| Anthropic managed agents (referenced as a forward pointer only, never used in code) | linked from the banner above; treated as a pre-release/hosted product for this book's purposes | https://www.anthropic.com/engineering/managed-agents | 2026-09-04 |
| Provider prompt caching — MECHANISM (method only, no prices in prose) | prefix resumption: a `cache_control` breakpoint (or a single top-level automatic breakpoint) caches everything up to that block; a later request whose prefix matches byte for byte reads it instead of reprocessing it. Consequences: cacheable material must come FIRST, and one byte of drift near the top invalidates everything after it | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-04 |
| Provider prompt caching — RATES AND LIMITS (volatile; read the source, do not quote this row) | the docs' pricing table lists a cache-write premium and a much cheaper cache read against base input, a default short TTL with a longer opt-in TTL, a per-model minimum cacheable prefix, and a small maximum number of breakpoints per request with a limited look-back window. All of these change per model generation | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-04 |
| `asyncio.TaskGroup` and the `asyncio.timeout` context manager | available from Python 3.11, which is this book's floor; `asyncio.Semaphore` and `asyncio.gather(..., return_exceptions=...)` are older. Atlas uses `timeout`, `Semaphore` and `gather`; `TaskGroup` is taught in section 6.10 and not used, because a fan-out must not cancel siblings by default | https://docs.python.org/3/library/asyncio-task.html | 2026-09-04 |
| Tier A calls for `make results` (default, 3 trials) | **222**, printed by `make plan` rather than estimated in prose. `--quick` is 1 trial over 8 requests ≈ 80 calls. The phase header's "~800 per sweep" is the *allowance*, and 222 + `make evals --trials 3` on Tier A (~360) ≈ 580 is the realistic upper end | (this repo: `scripts/phase05_results.py --plan`) | 2026-09-04 |
| Offline suite | **743** tests (was 536 at `phase-04`); 16 of them the regression suite added by the review below | this repo | 2026-09-04 |
| Eval suite size | **30** gradeable offline (was 26) out of 31 defined, +4 Phase 5 tasks, two of them regression tasks for F-05-01 and D-22 | this repo | 2026-09-04 |
| New prompts, checksums pinned | `atlas_router.v1.md` (`0fd5d8de11c3`), `atlas_evaluator.v1.md` (`40dc755fe60d`) | this repo | 2026-09-04 |

### Pre-release APIs referenced but NOT used in code

Anthropic's managed-agents platform (row above) is referenced once, as a
forward pointer from the banner on the 2024 post. Nothing in Phase 5 depends
on it, and Phases 1–8 remain framework-free plain Python.

### Forward pointers (concept taught, build deferred)

* **Provider-side prompt caching** (section 6.9): mechanism taught, not
  implemented, because Tier A has no such endpoint and Atlas's Tier H budget
  is spent on correctness rather than on latency. The design property that
  makes Atlas *ready* for it -- checksummed prompt files with no clock in them
  -- is already true, and section 6.9 says why that is luck worth keeping.
* **`asyncio.TaskGroup`** (section 6.10): taught, deliberately unused. A
  `TaskGroup` cancels siblings when one task raises, which is the
  `all_or_nothing` policy hard-coded; Atlas's default is `partial`.
* **Multi-agent supervisor** (section 6.5): workers that talk to each other
  stay in Appendix F, off the `phase-05` tag.
* **The dict-of-adapters refactor of `evals.run.dispatch`** (now eight `if`s):
  deferred to Phase 9, which touches every one of them for the graph port.
  Refactoring twice is worse than refactoring late.


### Phase 5 revision (2026-09-04) — defects found by reviewing the shipped phase

| fact | value | source URL | checked on |
|---|---|---|---|
| `run_research_pipeline` branch-kind hole | **Real bug, reproduced.** Only `kind == "timeout"` advanced a step, so a worker whose model call raised froze its step at 0 attempts and burned the level budget, exiting `level_cap` with `failed_steps == []`. Fixed; pinned by 3 tests; F-05-06 | (this repo) | 2026-09-04 |
| Dead defensive branches | `except (StructuredOutputError, Exception)` plus an unreachable `KeyboardInterrupt` guard in `route.classify_route` and `optimize.evaluate`. Removed | (this repo) | 2026-09-04 |
| Tool-result cache | Was built, tested and **wired nowhere**; `RequestAccount.cache_hits` could only read zero. Now threaded through `_run_worker` → `ResearchResult.cache_hits` → `HandlerOutcome` → `RequestAccount`, one cache per request | (this repo) | 2026-09-04 |
| `atlas.trace` reader | Seven new record types shipped with no reader, breaking Phase 4's own rule. Added `format_research_trajectory`, `format_worker`, `save/load_research_trajectory`, `format_routed_result` | (this repo) | 2026-09-04 |
| Evaluator-optimizer wiring | Was a rubric plus a loop over a caller-supplied producer, with nothing producing an Atlas report section. Added `context_from_research` and `report_section_producer`, and a real `measure_optimizer` experiment with four `RESULTS.md` rows | (this repo) | 2026-09-04 |
| `--plan` honesty | Billed 12 evaluator calls the script never spent. Now 21, matching the experiment that exists. Total: **231** Tier A calls for the default 3-trial sweep | (this repo: `make plan`) | 2026-09-04 |
| Rate cards | `data/rate_cards/tier_a.json` now ships (all-zero rates, dated, with a `source` explaining why a local model has no per-token charge) plus `tier_h.example.json`; `cost_line` writes a dated template when the card is missing | (this repo) | 2026-09-04 |
| Streaming | The phase block asked for it in the async orientation and the first draft omitted it. Section 6.10 now covers it in two paragraphs, with the reason Atlas does not stream: a fan-out's reduce needs whole payloads, and a token stream cannot be gated until it ends | (this repo; https://docs.python.org/3/library/asyncio-task.html) | 2026-09-04 |
| Section 8 trace | Rewritten to match the phase block: the **dropped failure** (a swallowed branch) is now the trace the student debugs, and the empty-branch/truncation failure is the second half that survives the first fix | (this repo) | 2026-09-04 |
| Interface version | **v0.12**, adding invariants 39–41 and the `atlas.trace` Phase 5 section | (this repo) | 2026-09-04 |

## Phase 6 delta — checked 2026-09-08

Re-verified from the package indexes and vendor docs on the date shown. Every
row is a CURRENT-STATE fact and appears nowhere in the phase prose.

### Embedding models and the endpoint

| Fact | Value | Source | Checked |
|---|---|---|---|
| Ollama embedding endpoint | `POST /api/embed`, body `{"model":…, "input": str \| [str]}` | https://docs.ollama.com/capabilities/embeddings | 2026-09-08 |
| Legacy endpoint (do not use) | `/api/embeddings` — superseded; the usual source of a 404 | https://docs.ollama.com/capabilities/embeddings | 2026-09-08 |
| Vector normalisation | `/api/embed` returns L2-normalised (unit-length) vectors | https://docs.ollama.com/capabilities/embeddings | 2026-09-08 |
| Ollama's own recommended embedding models | `embeddinggemma`, `qwen3-embedding`, `all-minilm` | https://docs.ollama.com/capabilities/embeddings | 2026-09-08 |
| **`ATLAS_EMBED_MODEL` (default choice)** | **`embeddinggemma`** — 768 dimensions | https://ollama.com/library/embeddinggemma | 2026-09-08 |
| Low-RAM alternative | `all-minilm` — 384 dimensions, ~45 MB | https://ollama.com/library/all-minilm | 2026-09-08 |
| Multilingual / long-context alternative | `qwen3-embedding` | https://ollama.com/library/qwen3-embedding | 2026-09-08 |
| Widely-used prior default | `nomic-embed-text` — 768 dimensions; Ollama card lists 2048 context although the model's native window is 8192, so `num_ctx` must be set explicitly | https://ollama.com/library/nomic-embed-text | 2026-09-08 |
| Typical dimension range across the library | 384–1024 | https://docs.ollama.com/capabilities/embeddings | 2026-09-08 |
| Cross-provider quality leaderboard | MTEB, on Hugging Face Spaces. Scores move; do not quote one in prose. | https://huggingface.co/spaces/mteb/leaderboard | 2026-09-08 |

Forward pointer: some current embedding families are trained with Matryoshka
representations, so their vectors can be truncated to a shorter prefix with
graceful quality loss. That genuinely is a dimension dial rather than a fixed
property. Atlas does not use it; check your chosen model's card.

Forward pointer: several models are **asymmetric** and specify a query prefix
distinct from the document prefix. Omitting it costs retrieval quality that no
amount of chunk tuning recovers. `OllamaEmbedder` sends no prefix, which is
correct for a symmetric model and wrong for an asymmetric one — check the card
before you index 5,000 chunks.

### Optional `docs` extra — the PDF and OCR toolchain

Not in `requirements.txt`. Needed only for `make data ARGS=--with-pdf`; the
messy corpus ships as frozen extractor output so `make test-offline` needs none
of it (invariant 2).

| Package | Version | Source | Checked |
|---|---|---|---|
| reportlab | 5.0.1 (2026-08-20) | https://pypi.org/pypi/reportlab/json | 2026-09-08 |
| pypdf | 6.17.0 (2026-09-04) | https://pypi.org/pypi/pypdf/json | 2026-09-08 |
| pdfplumber | 0.11.10 (2026-06-15) | https://pypi.org/pypi/pdfplumber/json | 2026-09-08 |
| pdfminer.six (pdfplumber's engine) | 20260107 | https://pypi.org/pypi/pdfminer.six/json | 2026-09-08 |
| pillow | 12.3.0 (2026-07-01) | https://pypi.org/pypi/pillow/json | 2026-09-08 |
| pytesseract | 0.3.13 (2024-08-16) | https://pypi.org/pypi/pytesseract/json | 2026-09-08 |
| tesseract (system binary) | 5.5.3, released 2026-07-24 — value read from the Wikipedia infobox; re-verify on the releases page before quoting | https://en.wikipedia.org/wiki/Tesseract_(software) | 2026-09-08 |
| tesseract releases (primary source) | check here for the current tag | https://github.com/tesseract-ocr/tesseract/releases | 2026-09-08 |
| pymupdf (alternative extractor, AGPL) | 1.28.2 | https://pypi.org/pypi/pymupdf/json | 2026-09-08 |

**Licence note, because it decides this for some readers:** pymupdf is AGPL and
often the best pure-Python extractor. reportlab, pypdf, pdfplumber and
tesseract are permissively licensed. Atlas uses the permissive set.

### Deferred — libraries this phase deliberately did NOT adopt

Atlas's vector store is brute-force pure Python because the corpus is a few
hundred chunks (section 6.12). These are what you switch to past roughly
10^4–10^5 vectors, and the interface to change is `VectorStore.search`.

| Package | Version | Why not yet | Source | Checked |
|---|---|---|---|---|
| chromadb | 1.5.9 | a server, a schema and a dependency for 28 chunks | https://pypi.org/pypi/chromadb/json | 2026-09-08 |
| faiss-cpu | 1.15.0 | ANN indexing; approximate recall you must then also measure | https://pypi.org/pypi/faiss-cpu/json | 2026-09-08 |
| sentence-transformers | 6.0.1 | runs embedding models in-process; Ollama already serves them | https://pypi.org/pypi/sentence-transformers/json | 2026-09-08 |
| rank-bm25 | 0.2.2 (last released 2022-02-16) | 40 lines of arithmetic you should be able to read; note the release date | https://pypi.org/pypi/rank-bm25/json | 2026-09-08 |
| bm25s | 0.3.11 | faster BM25 with a sparse-matrix backend; worth it at scale | https://pypi.org/pypi/bm25s/json | 2026-09-08 |
| langchain-text-splitters | 1.1.2 | the recursive splitter, packaged; Phase 10 territory | https://pypi.org/pypi/langchain-text-splitters/json | 2026-09-08 |
| unstructured | 0.27.5 | a managed document-parsing pipeline; heavy, and it returns text without per-region confidence | https://pypi.org/pypi/unstructured/json | 2026-09-08 |
| docling | 2.126.0 | layout-aware document conversion; the strongest current option for tables | https://pypi.org/pypi/docling/json | 2026-09-08 |
| marker-pdf | 2.0.0 | model-based PDF conversion; needs a GPU to be pleasant | https://pypi.org/pypi/marker-pdf/json | 2026-09-08 |
| tiktoken | 0.14.0 | token-accurate chunk sizing; Atlas chunks by characters and says so | https://pypi.org/pypi/tiktoken/json | 2026-09-08 |
| numpy | 2.5.2 (requires Python ≥ 3.12) | not needed at this corpus size; note the Python floor exceeds this book's 3.11 | https://pypi.org/pypi/numpy/json | 2026-09-08 |

### Historical sources used as dated facts in the prose

These are dated events and stable citations, not current-state facts, so they
appear in the text with their dates.

| Fact | Source | Checked |
|---|---|---|
| Reciprocal rank fusion, Cormack, Clarke & Büttcher, SIGIR 2009, pp. 758–759, DOI 10.1145/1571941.1572114 | https://dl.acm.org/doi/10.1145/1571941.1572114 | 2026-09-08 |
| RRF author's PDF, including the constant k=60 | https://cormack.uwaterloo.ca/cormacksigir09-rrf.pdf | 2026-09-08 |
| Contextual Retrieval (Anthropic, 19 Sep 2024): top-20 retrieval failure 5.7% → 3.7% (contextual embeddings) → 2.9% (+ contextual BM25) → 1.9% (+ reranking) | https://www.anthropic.com/engineering/contextual-retrieval | 2026-09-08 |
| Robertson & Zaragoza (2009), *The Probabilistic Relevance Framework: BM25 and Beyond* | https://www.staff.city.ac.uk/~sbrp622/papers/foundations_bm25_review.pdf | 2026-09-08 |
| Sentence-BERT, Reimers & Gurevych (2019), arXiv:1908.10084 | https://arxiv.org/abs/1908.10084 | 2026-09-08 |
| Dense Passage Retrieval, Karpukhin et al. (2020), arXiv:2004.04906 | https://arxiv.org/abs/2004.04906 | 2026-09-08 |
| RAG, Lewis et al. (2020), arXiv:2005.11401 | https://arxiv.org/abs/2005.11401 | 2026-09-08 |
| Lost in the Middle, Liu et al. (2023), arXiv:2307.03172 | https://arxiv.org/abs/2307.03172 | 2026-09-08 |

### Corrections to earlier deltas

| Row | Was | Now | Checked |
|---|---|---|---|
| Phase 5 `tier_h_call_cap` | 300 (master conventions) | **100** for this phase, per the Phase 6 block; `Settings.tier_h_call_cap` already defaults to 100 | 2026-09-08 |
| Extraction damage attribution | "naive extractors interleave two-column pages" | **depends on the library AND on the tool that produced the PDF**: measured, `pypdf` 6.x read the seeded two-column page correctly (content-stream order) and `pdfplumber` 0.11.x interleaved it (y-coordinate grouping). Neither is buggy. | 2026-09-08 |
| Ligature repair order | plausible claim that three-character ligatures must be repaired first | **false**, verified: each ligature is a distinct codepoint, so replacement order cannot matter | 2026-09-08 |

### Unverified, and flagged as such

| Claim | Status |
|---|---|
| tesseract 5.5.3 / 2026-07-24 | read from a Wikipedia infobox, not from the GitHub releases page. Treat as indicative. |
| The damage-frequency ranking in section 6.7 | **professional judgement, not a measured statistic.** Stated as such in the text. |
| Reranker gain on Tier A | author estimate, unmeasured. `docs/RESULTS.md` row 7. |

## Phase 7 delta — checked 2026-09-08

### Re-verification of everything earlier phases pinned

| Fact | Value | Source | Checked |
|---|---|---|---|
| pydantic | 2.13.5 — unchanged | https://pypi.org/pypi/pydantic/json | 2026-09-08 |
| httpx | 0.28.1 — unchanged | https://pypi.org/pypi/httpx/json | 2026-09-08 |
| python-dotenv | 1.2.3 — unchanged | https://pypi.org/pypi/python-dotenv/json | 2026-09-08 |
| pytest | 9.1.1 — unchanged | https://pypi.org/pypi/pytest/json | 2026-09-08 |
| Ollama runner | v0.33.2 (2026-08-27) — unchanged | https://github.com/ollama/ollama/releases | 2026-09-08 |
| `ATLAS_MODEL` default | `gemma4:12b` — unchanged | https://ollama.com/library/gemma4 | 2026-09-08 |
| Tier H cap for this phase | **150 calls**, per the Phase 7 block; token cap 200,000/day unchanged and still the binding constraint | https://console.groq.com/docs/rate-limits | 2026-09-08 |
| Coding assistant | unchanged from the Phase 3 row | — | 2026-09-08 |

No new runtime dependency. Phase 7 adds five modules and three prompts and
imports nothing that was not already pinned. `sqlite3` is in the standard
library; `describe_schema` and the read-only URI were both shipped in Phase 3.

### SQLite behaviour relied on by the sanity checks

These are behaviours of the engine, verified locally against the seeded
database rather than read from a document, because the checks depend on them.

| Fact | Verified value | Source | Checked |
|---|---|---|---|
| `sum()` over an empty row set | returns **one row containing NULL**, not zero rows | https://sqlite.org/lang_aggfunc.html#sumunc | 2026-09-08 |
| `count(*)` over an empty row set | returns one row containing **0** | https://sqlite.org/lang_aggfunc.html#count | 2026-09-08 |
| `file:...?mode=ro&immutable=1` | opens read-only and takes no lock | https://sqlite.org/uri.html | 2026-09-08 |
| Multiple statements in one `execute` | refused by the Python driver | https://docs.python.org/3/library/sqlite3.html | 2026-09-08 |
| SQLite version on the authoring machine | 3.45.1 (Ubuntu 24.04 system Python 3.12) | `sqlite3.sqlite_version` | 2026-09-08 |

The first two are the pair the `no_rows_matched` check turns on, and collapsing
them would turn a true zero into a refusal.

### Historical sources used as dated facts in the prose

Dated events and stable citations, safe to quote in prose with their dates.

| Fact | Source | Checked |
|---|---|---|
| Self-RAG, Asai et al., arXiv:2310.11511 (17 Oct 2023); ICLR 2024 | https://arxiv.org/abs/2310.11511 | 2026-09-08 |
| CRAG (Corrective Retrieval-Augmented Generation), Yan et al., arXiv:2401.15884 (29 Jan 2024) | https://arxiv.org/abs/2401.15884 | 2026-09-08 |
| IRCoT, Trivedi et al., arXiv:2212.10509 (20 Dec 2022); ACL 2023 | https://arxiv.org/abs/2212.10509 | 2026-09-08 |
| FLARE (active retrieval), Jiang et al., arXiv:2305.06983 (11 May 2023); EMNLP 2023 | https://arxiv.org/abs/2305.06983 | 2026-09-08 |
| GraphRAG, Edge et al. (Microsoft), arXiv:2404.16130 (24 Apr 2024) | https://arxiv.org/abs/2404.16130 | 2026-09-08 |
| Spider text-to-SQL benchmark, Yu et al., arXiv:1809.08887 (24 Sep 2018); EMNLP 2018 | https://arxiv.org/abs/1809.08887 | 2026-09-08 |
| BIRD text-to-SQL benchmark, Li et al., arXiv:2305.03111 (4 May 2023) | https://arxiv.org/abs/2305.03111 | 2026-09-08 |
| Lost in the Middle, Liu et al., arXiv:2307.03172 (6 Jul 2023) — re-cited from Phase 6 | https://arxiv.org/abs/2307.03172 | 2026-09-08 |
| OWASP Top 10 for LLM Applications — LLM01 Prompt Injection, LLM02 Sensitive Information Disclosure | https://genai.owasp.org/llm-top-10/ | 2026-09-08 |

### Deferred — taught in this phase, built elsewhere

| Topic | Where it is built | Length here |
|---|---|---|
| Full text-to-SQL agent: schema linking, few-shot selection, self-correction, verifier query | **Appendix F.2**, branch off `phase-07` | one section (§7.10–7.12) |
| GraphRAG: entity extraction, community detection, community summaries, global/local search | not built anywhere in this book; the alternative is Phase 5's fan-out | one page (§7.7) |
| Document-borne prompt injection defences | **Phase 14** | two sentences (§7.13) |
| Routing across several indexes | not built; Atlas has one index and metadata pre-filtering | one section (§7.6) |
| Contextual retrieval (per-chunk document context before embedding) | not built; named as the cheap thing to try before GraphRAG | one paragraph (§7.7) |

### Pre-release APIs referenced but NOT used in code

None this phase. No alpha, beta or RC library is imported anywhere in Phase 7.

### Corrections to earlier deltas

| Row | Was | Now | Checked |
|---|---|---|---|
| Phase 6 `docs/RESULTS.md` row 11 | "abstention catch rate with a calibrated floor: 0.4–0.8 of the 5" | **measured on Tier F: 4 of 5 (0.80) with chunk grading at drop floor 0.5, zero false abstentions over 28 answerable queries.** The estimate's range was right and its mechanism was wrong — the gain came from grading, not from a score threshold. | 2026-09-08 |
| Phase 6 precision figure | not reported | **precision@5 = 0.279** on the same sweep that reported recall@5 = 1.000. Both numbers existed in Phase 6; only one was printed. | 2026-09-08 |
| `atlas.rag.grade` default floors | `DEFAULT_KEEP_FLOOR=0.5`, `DEFAULT_PARTIAL_FLOOR=0.25` | **0.75 / 0.5.** The floor that filters is `partial_floor`, and the published calibration was quoted against the other one. See F-07-03. | 2026-09-08 |
| "never raises" on `answer_question` and `run_agentic_rag` | stated unconditionally | **corrected**: a transport failure, `BudgetExceeded` and `FixtureExhausted` propagate by design. See F-07-04. | 2026-09-08 |

### Unverified, and flagged as such

| Claim | Status |
|---|---|
| Source-rule accuracy 24/24 | **an upper bound, not an estimate.** The same author wrote the questions and the cue lists; two of the first twenty-four misfired before the cues were narrowed. Stated as such in §7.9 and in the `make results` output. |
| The coverage floor 0.5 transferring to your corpus | **it will not.** Coverage is comparable across queries by construction and not across corpora, because the IDF is the corpus's. `docs/RESULTS.md` row 1. |
| Every Tier A row in `docs/RESULTS.md` for Phase 7 | author estimate, unmeasured. Fifteen rows, under a header saying so. |
| The claim that demote-only grading costs "approximately nothing" | true **on this corpus**, where queries and documents share vocabulary. Rows 4 and 8 are what the 150-call Tier H budget exists for. |

### Phase 7 revision (2026-09-08) — defects found by reviewing the shipped phase

| Row | Was | Now | Checked |
|---|---|---|---|
| `atlas.rag.sources` | built, tested to 24/24, and called from nothing in `atlas/`; §7.9 claimed a `reconcile` integration that did not exist | **wired**: `SOURCE_ROUTES`, `route_hint`, `combine_hints`, and one line in `handle_request`. F-07-05, D-41, invariant 53 | 2026-09-08 |
| `make trace` on a Phase 6/7 task | ran `run_react_agent` regardless of entrypoint, printing a plausible rendering of the wrong record | `--show` routed through the grader's own `dispatch`; each record's `render()` prints it. F-07-06, invariant 54 | 2026-09-08 |
| `GradingReport.render()` caption | printed `keep_floor` ("floor 0.75") over a filter dropping below 0.50 | prints both, labelled: `drop below 0.50, relevant at 0.75` | 2026-09-08 |
| Tier H arm | **absent** from `scripts/phase07_results.py`, while the header, the phase block and `docs/RESULTS.md` all promised ≤150 calls | `--tier-h` restored, capped at 150, cached to `data/cache/phase07_embeddings_tier_h.json` | 2026-09-08 |
| Model-path measurement | none — all four experiments made 0 chat completions, so rows 5–9 and 12–14 were unanswerable by the shipped tooling | fifth experiment `loop`, which **skips on Tier F with a stated reason** (D-13) and measures rounds, echo rate, demotions and SQL validity on A/H | 2026-09-08 |
| Tier A call figure | header claimed "~1,000 … roughly 120 chat completions", unbacked | **measured by `make plan --tier-a`: ~493 embedding requests + 92 completions** | 2026-09-08 |
| Embedding cache path | `embeddings.json`, unnamespaced, so one phase's sweep could reuse another's vectors | `phase07_embeddings.json`, matching Phase 6's convention | 2026-09-08 |
| `# not executed during authoring` markers | absent from the Ollama and Tier H paths, which cannot run on this machine | present on both, each recording what was attempted and what stopped it (invariant 48) | 2026-09-08 |
| `make record` / `make plot` for PHASE=07 | crashed with `unrecognized arguments: --record` (also broken in Phase 6) | both flags accepted; `--svg` documented as ignored for a table-only phase | 2026-09-08 |
| `build_handlers(index=…)` with a registry built without it | silent: the research route was offered `retrieve_documents` and the scoped registry had none | raises at wiring time, with the one-argument fix in the message | 2026-09-08 |
| Hidden test `test_phase07_a2` composition check | accepted `wrong_relation` as a pass, so a stub `population_check` returning `[]` graded green | rewritten so no other check can fire; a stub now fails | 2026-09-08 |
| `evals/run.py` comment on the labelled set | claimed the set "lives in the TASK's environment" — it lives in the test module | corrected, and a test pins the results script's second copy to it | 2026-09-08 |

## Phase 8 delta — checked 2026-09-08

Pinned dependency versions re-verified against PyPI on 2026-09-08 and all
unchanged from the Phase 7 rows: `pydantic 2.13.5`, `pytest 9.1.1`,
`httpx 0.28.1`, `python-dotenv 1.2.3`. Phase 8 adds **no new dependency**.

### Agent Skills format

| fact | value | source | checked |
|---|---|---|---|
| Spec name and status | Agent Skills, an open standard; developed by Anthropic and released as an open specification | https://agentskills.io/specification | 2026-09-08 |
| Required frontmatter fields | `name`, `description` | https://agentskills.io/specification | 2026-09-08 |
| Optional frontmatter fields | `license`, `compatibility`, `metadata`, `allowed-tools` (experimental) | https://agentskills.io/specification | 2026-09-08 |
| `name` constraints | 1–64 chars; lowercase letters, digits and hyphens; no leading/trailing hyphen; no consecutive hyphens; must match the parent directory name | https://agentskills.io/specification | 2026-09-08 |
| `description` constraints | 1–1024 chars | https://agentskills.io/specification | 2026-09-08 |
| `compatibility` constraint | ≤500 chars | https://agentskills.io/specification | 2026-09-08 |
| Recommended `SKILL.md` body ceiling | keep under ~500 lines; move detail into bundled resources | https://agentskills.io/specification | 2026-09-08 |
| Level-1 metadata cost, per skill | ~100 tokens loaded at startup for every installed skill | https://agentskills.io/specification | 2026-09-08 |
| Level-2 instruction guidance | under ~5k tokens when the skill is activated | https://agentskills.io/specification | 2026-09-08 |
| Conventional resource directories | `scripts/`, `references/`, `assets/` | https://agentskills.io/specification | 2026-09-08 |
| Validation tooling | `skills-ref validate` | https://agentskills.io/specification | 2026-09-08 |

Atlas's loader implements the required fields, the name rule and the directory
match, refuses unknown keys, and does **not** implement `allowed-tools`
enforcement (parsed and stored only) because it is marked experimental.

### Prompt caching (Anthropic; the provider whose mechanics are documented in enough detail to teach from)

| fact | value | source | checked |
|---|---|---|---|
| Prefix assembly order | tools → system → messages; a change at one level invalidates that level and everything after it | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |
| Explicit cache breakpoints | up to 4 per request | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |
| Cache-read lookback window | 20 content blocks before an explicit breakpoint | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |
| Minimum cacheable prompt length | model-dependent: 1024 or 2048 tokens depending on the model | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |
| Default cache lifetime | 5 minutes, refreshed on use; a 1-hour option exists | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |
| Cache read price | 0.1× base input tokens | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |
| Cache write price | 1.25× base input (5-minute), 2× (1-hour) | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |
| Matching | exact; one character's difference in the prefix is a miss, not a partial hit | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |
| Usage fields reported | `cache_creation_input_tokens`, `cache_read_input_tokens`, `input_tokens` (post-breakpoint only) | https://platform.claude.com/docs/en/build-with-claude/prompt-caching | 2026-09-08 |

**Not measurable on Tier A**: Ollama has no prefix cache of this kind, so Phase
8 teaches the layout for $0 and Appendix B measures it.

### Memory tool (generally available)

| fact | value | source | checked |
|---|---|---|---|
| Tool type string | `memory_20250818` | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 2026-09-08 |
| Availability | generally available; no beta header; Claude 4 and later | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 2026-09-08 |
| Execution | client-side: the developer implements storage; the API only issues commands | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 2026-09-08 |
| Commands | `view`, `create`, `str_replace`, `insert`, `delete`, `rename` | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 2026-09-08 |
| Path constraint | all paths must begin with `/memories`; traversal must be rejected | https://platform.claude.com/docs/en/agents-and-tools/tool-use/memory-tool | 2026-09-08 |

### Tool search (scaling to many tools; generally available)

| fact | value | source | checked |
|---|---|---|---|
| Tool type strings | `tool_search_tool_regex_20251119`, `tool_search_tool_bm25_20251119` | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool | 2026-09-08 |
| Deferral flag | `defer_loading: true` per tool definition | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool | 2026-09-08 |
| Reported token reduction | typically >85% of tool-definition tokens | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool | 2026-09-08 |
| Onset of accuracy degradation, flat registry | in the region of 30–50 tools | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool | 2026-09-08 |
| Recommended adoption threshold | ≥10 tools, or >10k tokens of tool definitions | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool | 2026-09-08 |
| Maximum deferred tools | 10,000 | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool | 2026-09-08 |
| Interaction with caching | discovered definitions are appended in the conversation, leaving the system-prompt prefix intact, so prompt caching is preserved | https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool | 2026-09-08 |

### PRE-RELEASE — appears in no code in this repository

| fact | value | source | checked |
|---|---|---|---|
| Context editing (tool-result clearing) | `clear_tool_uses_20250919`, behind beta header `context-management-2025-06-27` | https://platform.claude.com/docs/en/build-with-claude/context-editing | 2026-09-08 |
| Thinking-block clearing | `clear_thinking_20251015`, same beta header; must be first in the `edits` array | https://platform.claude.com/docs/en/build-with-claude/context-editing | 2026-09-08 |
| Interaction with caching | clearing content invalidates the cached prefix from the cleared point onward; `clear_at_least` exists so the trade is worth taking | https://platform.claude.com/docs/en/build-with-claude/context-editing | 2026-09-08 |

Forward pointer: when context editing leaves beta, `atlas.memory` gains a
`prune_tool_results` wrapper over it rather than an implementation of it, and
the tension named in §8.10 becomes a measured parameter rather than a taught
one.

### Historical references used in Phase 8 (dated; safe in prose)

| work | date | identifier |
|---|---|---|
| Liu et al., *Lost in the Middle* | 6 July 2023 | arXiv:2307.03172 |
| Zhong et al., *MemoryBank* | 17 May 2023; AAAI 2024 pp. 19724–19731 | arXiv:2305.10250, doi:10.1609/aaai.v38i17.29946 |
| Park et al., *Generative Agents* | UIST 2023 | arXiv:2304.03442 |
| Packer et al., *MemGPT* | 12 October 2023 | arXiv:2310.08560 |
| Chroma, *Context Rot* | 2025 | https://research.trychroma.com/context-rot |
| Anthropic, *Effective context engineering for AI agents* | 29 September 2025 | https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents |
| Anthropic, *Advanced tool use* | 2025 | https://www.anthropic.com/engineering/advanced-tool-use |

### Phase 8 measured facts about Atlas (not volatile; here for cross-reference)

| fact | value | source | checked |
|---|---|---|---|
| Offline test count | 1205 passed, 12 skipped | `make test-offline` | 2026-09-08 |
| Gradeable eval tasks | 44 (45 defined) | `python evals/run.py --trials 1` | 2026-09-08 |
| Tier A requests per full sweep | 60 (12 completions, 48 embeddings) | `make plan` | 2026-09-08 |
| `northwind-quarterly` skill checksum | `cd6752e1cc34` | `tests/test_memory_assemble.py` | 2026-09-08 |
| `atlas_compact.v1.md` checksum | `49e06fc8f98a` | `tests/test_prompts.py` | 2026-09-08 |

## Phase 8 REVISION delta — checked 2026-09-09

| fact | value | source | checked |
|---|---|---|---|
| Offline test count | 1220 passed, 12 skipped | `make test-offline` | 2026-09-09 |
| Gradeable eval tasks | 45 (46 defined) | `python evals/run.py --trials 1` | 2026-09-09 |
| Tier A requests per full sweep | 190 (52 completions, 138 embeddings) | `make plan` | 2026-09-09 |
| Tier H cap, this phase | 200, enforced in `HostedEmbedder` and in `TIER_H_CAP` | `scripts/phase08_results.py` | 2026-09-09 |
| `northwind-quarterly` skill checksum | `cd6752e1cc34` | `tests/test_memory_assemble.py` | 2026-09-09 |
| `ATLAS_INTERFACES.md` version | v0.18, invariants 57–58, D-45 to D-46 | repo | 2026-09-09 |
| `DEFAULT_CONTEXT_BUDGET` | 3072 (0.75 × 4096) | `atlas/memory/session.py` | 2026-09-09 |

## Phase 9 delta — checked 2026-09-09

| fact | value | source URL | checked-on |
|---|---|---|---|
| `langgraph` version pinned | 1.2.11 | https://pypi.org/project/langgraph/ | 2026-09-09 |
| `langchain` version pinned | 1.4.0 | https://pypi.org/project/langchain/ | 2026-09-09 |
| `langchain-core` resolved | 1.6.2 | https://pypi.org/project/langchain-core/ | 2026-09-09 |
| `langgraph-checkpoint-sqlite` pinned | 3.1.1 | https://pypi.org/project/langgraph-checkpoint-sqlite/ | 2026-09-09 |
| `langgraph-checkpoint` resolved | 4.2.0 | https://pypi.org/project/langgraph-checkpoint/ | 2026-09-09 |
| `langgraph-prebuilt` resolved | 1.1.0 | https://pypi.org/project/langgraph-prebuilt/ | 2026-09-09 |
| LangChain 1.0 / LangGraph 1.0 release date | October 2025 | https://www.langchain.com/blog/langchain-langgraph-1dot0 | 2026-09-09 |
| Stability commitment | no breaking changes until 2.0 | https://www.langchain.com/blog/langchain-langgraph-1dot0 | 2026-09-09 |
| `langgraph.prebuilt.create_react_agent` status | deprecated in favour of `langchain.agents.create_agent`; removal planned for 2.0 | installed docstring, `langgraph/prebuilt/chat_agent_executor.py` | 2026-09-09 |
| Migration guide URL | https://docs.langchain.com/oss/python/migrate/langgraph-v1 | installed docstring | 2026-09-09 |
| LangGraph default `recursion_limit` | 10007, overridable by env `LANGGRAPH_DEFAULT_RECURSION_LIMIT` | `langgraph/_internal/_config.py:32` (installed) | 2026-09-09 |
| `langchain_core` default `recursion_limit` | 25 (NOT what a graph gets) | `langchain_core.runnables.config.ensure_config` (installed) | 2026-09-09 |
| Stream modes available | values, updates, checkpoints, tasks, debug, messages, custom | `langgraph.types.StreamMode` (installed) | 2026-09-09 |
| Durability modes available | sync, async, exit | `langgraph.types.Durability` (installed) | 2026-09-09 |
| Middleware hooks available | before_agent, before_model, after_model, after_agent, wrap_model_call, wrap_tool_call | `langchain.agents.middleware.AgentMiddleware` (installed) | 2026-09-09 |
| `ModelRequest` fields | model, messages, system_message, tool_choice, tools, response_format, state, runtime, model_settings | installed dataclass fields | 2026-09-09 |
| `SummarizationMiddleware` trigger API | `trigger=("messages"\|"tokens"\|"fraction", n)`, `keep=("messages", 20)` default | installed `__init__` signature | 2026-09-09 |
| `PIIMiddleware` strategies | block, redact, mask, hash | installed `__init__` signature | 2026-09-09 |
| `ModelCallLimitMiddleware` exit behaviours | `end` (appends an AIMessage naming the limit) \| `error` (raises) | installed signature + measured | 2026-09-09 |
| Tool-node default error handling | returns a message for `ToolInvocationError`; re-raises anything else | `langgraph/prebuilt/tool_node.py:_default_handle_tool_errors` | 2026-09-09 |
| Batch atomicity in the framework's tool node | NOT atomic: recognised calls run, unknown ones error | measured, `docs/RESULTS.md` Phase 9 experiment 2 | 2026-09-09 |
| Tracing product | LangSmith — separate, commercial, hosted; not required to run a graph | https://www.langchain.com/blog/langchain-langgraph-1dot0 | 2026-09-09 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-09 |

**Pre-release APIs used in code: none.** `langgraph.prebuilt.create_react_agent`
is shown once, in a fenced block marked DEPRECATED, and is never imported by
`atlas/`.

## Phase 10 delta — checked 2026-09-10

| fact | value | source URL | checked-on |
|---|---|---|---|
| `langgraph` version pinned | 1.2.11 — unchanged, re-verified | https://pypistats.org/packages/langgraph | 2026-09-10 |
| `langchain` version pinned | 1.4.0 — unchanged | https://pypi.org/project/langchain/ | 2026-09-10 |
| `langgraph-checkpoint-sqlite` pinned | 3.1.1 — unchanged | https://pypi.org/project/langgraph-checkpoint-sqlite/ | 2026-09-10 |
| Durability modes available | `sync`, `async`, `exit`; `async` is the DEFAULT | `langgraph.types.Durability` (installed) | 2026-09-10 |
| Completed supersteps preserved after `os._exit(9)` | sync 1/1 · async 0/1 · exit unresumable (`EmptyInputError`) | measured, `docs/RESULTS.md` Phase 10 exp. 4 | 2026-09-10 |
| Node re-execution on resume | in-flight node runs twice; committed nodes replayed | measured, `tests/test_graph_phase10.py` | 2026-09-10 |
| `interrupt()` re-execution semantics | node restarts from its FIRST line; resume values matched by order within the task | installed docstring, `langgraph/types.py` | 2026-09-10 |
| Default fan-out concurrency, `max_concurrency` unset | host-derived: 5 on a 1-vCPU box = `min(32, cpu_count + 4)` | measured | 2026-09-10 |
| `Send` result order under concurrency | argument order, not completion order | measured, exp. 3 | 2026-09-10 |
| `recursion_limit` across a subgraph boundary | inherited, not divided: minimum is `max(level_supersteps) + 1` | measured | 2026-09-10 |
| `Command(goto=...)` without `destinations=` | node drawn as `--> __end__` in `draw_mermaid()`; topology serialisation is wrong | measured | 2026-09-10 |
| Undeclared state-channel write | discarded silently; no exception, no warning; reads back `None` | measured | 2026-09-10 |
| `HumanInTheLoopMiddleware.__init__` signature | `interrupt_on: dict[str, bool \| InterruptOnConfig]`, `description_prefix="Tool execution requires approval"` | installed signature | 2026-09-10 |
| Framework HITL default for an unlisted tool | auto-approved (default-allow) | installed docstring | 2026-09-10 |
| Framework HITL decision vocabulary | approve, edit, reject, respond | installed `_process_decision` | 2026-09-10 |
| Framework HITL hook | `after_model` (single interrupt carrying every gated call of the turn) | installed source | 2026-09-10 |
| Framework HITL edit behaviour | assigns revised calls onto the `AIMessage` and returns it with the SAME id, so `add_messages` upserts and the original proposal is destroyed | measured, exp. 1 | 2026-09-10 |
| Framework HITL rejection message | prose `ToolMessage`, `status="error"`, no error kind | installed source | 2026-09-10 |
| `RetryPolicy` defaults | `initial_interval=0.5`, `backoff_factor=2.0`, `max_interval=128.0`, `max_attempts=3`, `jitter=True` | installed signature | 2026-09-10 |
| `default_retry_on` behaviour | `ConnectionError` → True; `ValueError` → False | measured | 2026-09-10 |
| `CachePolicy` signature | `key_func=default_cache_key`, `ttl=None`; key derived from the node's whole input state | installed signature + measured | 2026-09-10 |
| Store API | `put/get/search/list_namespaces`; namespaces are tuples; `search(limit=10)` default | installed signatures | 2026-09-10 |
| Store `search(query=...)` without an index | returns the namespace in insertion order, `score=None`, no error raised | measured | 2026-09-10 |
| MCP multi-round-trip → LangGraph interrupt adapter | first-party adapter is PRE-RELEASE; not imported by `atlas/`; Phase 12 wires the translation by hand | installed package survey | 2026-09-10 |
| Offline test count | 1299 passed, 12 skipped | `make test-offline` | 2026-09-10 |
| Gradeable eval tasks | 51 (52 defined) | `python evals/run.py --trials 1` | 2026-09-10 |
| Tier A requests per full sweep | ~1300 | `make plan` | 2026-09-10 |
| Tier H cap, this phase | 50 | `scripts/phase10_results.py` | 2026-09-10 |
| `ATLAS_INTERFACES.md` version | v0.21, invariant 66, D-52 to D-56 | repo | 2026-09-10 |
| `GATED_SUPERSTEPS_PER_STEP` | 4 (model, decide, gate, tools) | `atlas/graph/core.py` | 2026-09-10 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-10 |

**Pre-release APIs used in code: none.** The MCP multi-round-trip interrupt
adapter is named in prose with a forward pointer only (§6.11) and is never
imported.

## Phase 11 delta — checked 2026-09-10

A reading phase: nothing new is installed, nothing new is imported, and the
only code change is a bug fix. The rows below exist because §6.4's argument
rests on published figures and §6.9's rubric names packages Atlas does not use.

| fact | value | source URL | checked-on |
|---|---|---|---|
| `langgraph` version pinned | 1.2.11 — unchanged, re-verified | https://pypi.org/project/langgraph/ | 2026-09-10 |
| `langchain` version pinned | 1.4.0 — unchanged | https://pypi.org/project/langchain/ | 2026-09-10 |
| `langgraph-supervisor` latest | 0.0.31 — NOT a dependency of Atlas; named in §6.9 prose only | https://pypi.org/project/langgraph-supervisor/ | 2026-09-10 |
| `langgraph-swarm` latest | 0.1.0 — NOT a dependency of Atlas; named in §6.9 prose only | https://pypi.org/project/langgraph-swarm/ | 2026-09-10 |
| Swarm library / 1.x agent API compatibility | library supports LangChain 1.0 but is documented as untested against the new agents; only the prebuilt ReAct agent is supported | https://reference.langchain.com/javascript/langchain-langgraph-swarm | 2026-09-10 |
| Multi-agent gain, orchestrator-worker vs single agent | +90.2% over single-agent Opus 4 on Anthropic's internal research eval (lead Opus 4, subagents Sonnet 4) | https://www.anthropic.com/engineering/multi-agent-research-system | 2026-09-10 |
| Share of BrowseComp variance explained by token usage alone | 80% (three factors together: 95%) | https://www.anthropic.com/engineering/multi-agent-research-system | 2026-09-10 |
| Token multiple vs a chat interaction | agents ~4x, multi-agent systems ~15x | https://www.anthropic.com/engineering/multi-agent-research-system | 2026-09-10 |
| Anthropic's stated effort-scaling rule | 1 agent / 3–10 tool calls (simple fact-finding); 2–4 subagents / 10–15 calls each (comparisons); >10 subagents (complex research) | https://www.anthropic.com/engineering/multi-agent-research-system | 2026-09-10 |
| MAST taxonomy size | 14 failure modes in 3 categories (system design, inter-agent misalignment, task verification) | https://arxiv.org/abs/2503.13657 | 2026-09-10 |
| MAST provenance | taxonomy from 150 traces, κ = 0.88, 6 expert annotators; MAST-Data 1,600+ annotated traces across 7 frameworks | https://arxiv.org/abs/2503.13657 | 2026-09-10 |
| MAST paper version | arXiv v3, last revised 26 Oct 2025 (v1 17 Mar 2025) | https://arxiv.org/abs/2503.13657 | 2026-09-10 |
| Matched-budget SAS vs MAS result | single-agent matches or beats all 5 MAS variants on FRAMES and MuSiQue 4-hop at equal thinking-token budgets, across Qwen3, DeepSeek-R1-Distill-Llama and Gemini 2.5 | https://arxiv.org/abs/2604.02460 | 2026-09-10 |
| Matched-budget crossover condition | MAS overtakes at heavy context corruption: substitution α=0.7, Sequential 0.225 vs SAS 0.200 (MuSiQue 4-hop, Qwen3-30B-A3B, 1k-token budget) | https://arxiv.org/abs/2604.02460 | 2026-09-10 |
| Matched-budget paper version | arXiv 2604.02460 v2, 11 Apr 2026, preprint under review (Tran & Kiela, Stanford) | https://arxiv.org/abs/2604.02460 | 2026-09-10 |
| Cognition's 2025 position | two principles: share full agent traces; actions carry implicit decisions. Default to ruling out architectures that violate them | https://cognition.com/blog/dont-build-multi-agents | 2026-09-10 |
| Cognition's 2026 revision | parallel-writer swarms still declined; the class that works keeps writes single-threaded and adds intelligence rather than actions | https://cognition.com/blog/multi-agents-working | 2026-09-10 |
| Clean-context reviewer yield | ~2 bugs per PR on agent-written PRs, ~58% severe; works best with NO shared context beforehand | https://cognition.com/blog/multi-agents-working | 2026-09-10 |
| OWASP Agentic Top 10 | ASI01–ASI10, announced 9 Dec 2025 by the OWASP GenAI Security Project (Agentic Security Initiative) | https://genai.owasp.org/2025/12/09/owasp-top-10-for-agentic-applications-the-benchmark-for-agentic-security-in-the-age-of-autonomous-ai/ | 2026-09-10 |
| ASI07 / ASI08 / ASI09 titles | Insecure Inter-Agent Communication / Cascading Failures / Human-Agent Trust Exploitation | https://genai.owasp.org/2025/12/09/owasp-top-10-for-agentic-applications-the-benchmark-for-agentic-security-in-the-age-of-autonomous-ai/ | 2026-09-10 |
| Research route model calls | `1 + n` for an n-step plan (2 at n=1, 4 at n=3); the join adds none | measured, `make results PHASE=11` exp. 1 | 2026-09-10 |
| Supervisor / pipeline token ratio | 1.59x at n=1 rising to 3.03x at n=12; 87% of the n=3 overhead is the extra calls, 13% is shared traces | arithmetic, `scripts/phase11_results.py` exp. 2 | 2026-09-10 |
| Offline test count | 1310 passed, 12 skipped | `make test-offline` | 2026-09-10 |
| Gradeable eval tasks | 54 (55 defined) | `python evals/run.py --trials 1` | 2026-09-10 |
| Rubric display under `make grade` | pytest captures stdout on PASSING tests, so `print()` in a passing test is never shown | measured, F-11-03 | 2026-09-10 |
| Tier A requests per full sweep | 0 | `make plan` | 2026-09-10 |
| Tier H cap, this phase | 0 | `scripts/phase11_results.py --plan` | 2026-09-10 |
| `ATLAS_INTERFACES.md` version | v0.24, invariants 67 and 68, D-59 and D-60 | repo | 2026-09-10 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-10 |

**Pre-release APIs used in code: none.** `langgraph-supervisor` and
`langgraph-swarm` are named in §6.9 and in Appendix F.5's forward pointer and
are installed by neither `requirements.txt` nor `pyproject.toml`.

## Phase 12 delta — checked 2026-09-10

| fact | value | source URL | checked-on |
|---|---|---|---|
| Current MCP specification revision | `2026-07-28`, final, published 28 July 2026 | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| MCP Python SDK | 2.2.0 — **used in code this phase**; `FastMCP` renamed to `MCPServer`, fields are snake_case and alias to the wire's camelCase | https://pypi.org/pypi/mcp/json | 2026-09-10 |
| MCP SDK phase assignment | **CORRECTED**: was listed as "Phase 15" and pinned at 2.1.1; MCP arrives in Phase 12 | this repo | 2026-09-10 |
| Protocol version this SDK negotiates in-process | `2026-07-28` | measured, `scripts/phase12_results.py` exp. 1 | 2026-09-10 |
| Statelessness SEP | SEP-2575 — removes `initialize`/`initialized`, `Mcp-Session-Id`, `ping`, `logging/setLevel`, SSE resumability; adds `server/discover`, `subscriptions/listen` | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Cross-call state SEP | SEP-2567 — explicit server-minted handles as ordinary tool arguments | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| MRTR SEP | SEP-2322 — `InputRequiredResult`, `resultType: "input_required"`, `inputRequests`, `inputResponses`, `requestState`; `resultType` required on all results | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Routing headers SEP | SEP-2243 — `Mcp-Method`, `Mcp-Name` required on Streamable HTTP POST; `x-mcp-header` for custom headers from tool parameters | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Cacheable lists SEP | SEP-2549 — `ttlMs` and `cacheScope` (`public`/`private`) required via `CacheableResult` | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Trace context SEP | SEP-414 — OpenTelemetry propagation conventions for `_meta` keys `traceparent`, `tracestate`, `baggage` | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Deprecations SEP | SEP-2577 — Roots, Sampling, Logging deprecated; migrations are tool params/resource URIs/server config, direct provider APIs, and stderr or OpenTelemetry | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Deprecation policy | SEP-2596 — Active/Deprecated/Removed, **minimum twelve-month window**, public registry of deprecated features | https://modelcontextprotocol.io/community/feature-lifecycle | 2026-09-10 |
| Renumbered error codes | `HeaderMismatch` −32020, `MissingRequiredClientCapability` −32021, `UnsupportedProtocolVersion` −32022; resource-not-found moved −32002 → −32602 | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Authorization hardening | RFC 9207 `iss` validation (SEP-2468); credentials keyed by issuer (SEP-2352); `application_type` on DCR (SEP-837) | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Client registration | Dynamic Client Registration (RFC 7591) **deprecated** in favour of Client ID Metadata Documents (PR #2858) | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| Official extensions | Tasks (`io.modelcontextprotocol/tasks`), MCP Apps, Enterprise Managed Authorization; `extensions` field on client and server capabilities | https://blog.modelcontextprotocol.io/posts/2026-07-28/ | 2026-09-10 |
| Tier 1 SDKs | TypeScript, Python, Go, C# — shipped 2026-07-28 support on release day; Go v1.7.0 | https://developers.googleblog.com/scaling-ai-agent-infrastructure-with-the-mcp-stateless-updates/ | 2026-09-10 |
| Skills over MCP — closed predecessor | SEP-2076 (convention-only proposal) closed; superseded by the Extensions-Track SEP below | https://github.com/modelcontextprotocol/modelcontextprotocol/pull/2640 | 2026-09-10 |
| Skills over MCP — current | **SEP-2640 is a DRAFT** Extensions-Track SEP; extension id `io.modelcontextprotocol/skills`; `skill://` URIs, `skill://index.json` catalogue, `skills/list`, `skills/get`, optional `resources/directory/read`; v1 baseline pinned at commit 0eb05fe (2026-08-05) | https://github.com/modelcontextprotocol/modelcontextprotocol/pull/2640 | 2026-09-10 |
| What Atlas depends on from SEP-2640 | **the convention only** — `skill://` URIs plus `resources/list`/`resources/read`. No draft method is called. Forward pointer: when the SEP lands, `skills/list` and `skills/get` replace the index read | this repo | 2026-09-10 |
| `langchain` MCP adapter | **CORRECTED since 2 Sept**: `langchain==1.4.0` shipped **3 Sept 2026** (final, not the 1.4.0a3 alpha), and it contains the first-party `langchain.mcp` namespace — but the namespace itself is documented as **beta**, so it stays out of Atlas's code | https://github.com/langchain-ai/langchain/releases/tag/langchain%3D%3D1.4.0 | 2026-09-10 |
| `langchain.mcp` shape | `MCPAdapter`, `list_tools(cache_mode=...)` honouring SEP-2549 TTLs, `elicitation="interrupt"` surfacing MRTR as LangGraph interrupts, resume via `Command(resume={"responses": {key: answer}})` | https://www.langchain.com/blog/mcp-in-langchain-stateless-protocol-elicitation-and-more | 2026-09-10 |
| `langchain.mcp` dependency | requires the `mcp` extra and `fastmcp>=4.0.0` — a DIFFERENT package from the official `mcp` SDK. Not installed: `import langchain.mcp` raises `ModuleNotFoundError: fastmcp` on this tree | measured, this repo | 2026-09-10 |
| `langchain.mcp` sampling/roots | not answered; a tool call returning either raises `NotImplementedError`. FastMCP 4 removed `ctx.sample()` and `ctx.list_roots()` from every era | https://docs.langchain.com/oss/python/migrate/langchain-mcp-adapters | 2026-09-10 |
| OWASP MCP Top 10 | **beta** (Phase 3, pilot testing); MCP01:2025–MCP10:2025; next release October 2026; lead Vandana Verma Sehgal; CC BY-NC-SA 4.0 | https://owasp.org/www-project-mcp-top-10/ | 2026-09-10 |
| OWASP MCP Top 10 — internal inconsistency | the project page lists MCP06 as *Intent Flow Subversion* in the summary and *Prompt Injection via Contextual Payloads* in the body. Cite categories, not rankings | https://owasp.org/www-project-mcp-top-10/ | 2026-09-10 |
| A2A protocol | v1.0 released 9 April 2026 under Linux Foundation governance; 150+ supporting organisations; production deployments reported in supply chain, financial services, insurance, IT ops | https://www.linuxfoundation.org/press/a2a-protocol-surpasses-150-organizations-lands-in-major-cloud-platforms-and-sees-enterprise-production-use-in-first-year | 2026-09-10 |
| A2A — the honest caveat | the one-year announcement reported organisations and integrations, not deployment counts or usage metrics; a March 2026 critique of A2A rested on *"MCP servers are inherently stateful"*, which the 2026-07-28 revision made false. **Check the date on every architectural comparison** | https://agentndx.ai/blog/a2a-protocol-adoption-mid-2026/ | 2026-09-10 |
| Per-request token verification cost | ~11–13 µs (HMAC-SHA256, 2,000 trials, this container) | measured, `scripts/phase12_results.py` exp. 2 | 2026-09-10 |
| Authorisations per confirmed MRTR write | **2** — one per round; statelessness means round 2 is a new request, checked again | measured, `scripts/phase12_results.py` exp. 2 | 2026-09-10 |
| `GraphInterrupt` nesting depth through the SDK client | 2 levels of `ExceptionGroup` | measured, this phase; invariant 70 | 2026-09-10 |
| Scopes per route (least privilege, computed) | chat `()`; document `documents:read`; data `company_data:read`; research `company_data:read, documents:read`; tool_action `workspace:write` | measured, `scripts/phase12_results.py` exp. 3 | 2026-09-10 |
| Offline test count | 1366 passed, 12 skipped | `make test-offline` | 2026-09-10 |
| Gradeable eval tasks | 57 | `python evals/run.py --trials 1` | 2026-09-10 |
| Tier A requests per full sweep | 0 (experiments 1–3 need no model) | `make plan PHASE=12` | 2026-09-10 |
| Tier H cap, this phase | ≤50, opt-in via `--tier-h`, spent 0 | `scripts/phase12_results.py --plan` | 2026-09-10 |
| `ATLAS_INTERFACES.md` version | v0.25, invariants 69–71, D-61 and D-62 | repo | 2026-09-10 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-10 |

**Pre-release APIs used in code: none.** SEP-2640 is a draft and Atlas calls
none of its methods; `langchain.mcp` is a beta namespace and is not imported;
the `mcp` SDK at 2.2.0 is a final release of a final specification revision.

## Phase 12 revision — checked 2026-09-10 (wiring pass)

| fact | value | source URL | checked-on |
|---|---|---|---|
| Offline test count | 1380 passed, 12 skipped (was 1366 before the wiring pass) | `make test-offline` | 2026-09-10 |
| Gradeable eval tasks | 57; `p12-a` now runs through `run_atlas_graph` on the default path | `python evals/run.py --trials 1` | 2026-09-10 |
| `p12-a` negative check | 0/1 with the `HANDLER_TOOLS["data"]` line removed, 1/1 with it | measured, both directions | 2026-09-10 |
| Authorisations per confirmed write THROUGH THE GRAPH | **3**, not 2: round 1, then round 1 again after `interrupt()` re-drives the loop, then round 2 | measured, `tests/test_mcp_phase12.py` | 2026-09-10 |
| Gates on the remote write path | 2 — Atlas's approval gate, then the service's MRTR. Different questions; both kept (D-63) | measured, `tests/test_mcp_phase12.py` | 2026-09-10 |
| `list_tools` and `_meta` | no `meta=` keyword; on a paginated request the `_meta` object lives on `PaginatedRequestParams` | measured, MCP Python SDK | 2026-09-10 |
| Lint status of the phase's new modules | `ruff --select F401,F811,ARG` clean on `atlas/mcp` and `atlas/auth`; 38 pre-existing findings elsewhere in `atlas/`, mostly legitimate `__init__` re-exports and framework-shaped signatures — NOT fixed this phase | `python -m ruff check` | 2026-09-10 |
| `ATLAS_INTERFACES.md` version | v0.26, invariants 69–72, D-61 to D-64 | repo | 2026-09-10 |

## Phase 13 delta — checked 2026-09-11

| fact | value | source URL | checked-on |
|---|---|---|---|
| Anthropic's agent-eval guidance | *Demystifying evals for AI agents*, published 9 Jan 2026 — the vocabulary (task/trial/grader/transcript/outcome/harness/suite), capability-vs-regression suites, partial credit, "grade what the agent produced, not the path it took" | https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents | 2026-09-11 |
| Infrastructure noise in agentic evals | Terminal-Bench 2.0: 6 percentage points between most- and least-resourced setups (p < 0.01); SWE-bench crossover, 227 problems × 10 samples, scores rose monotonically with RAM, +1.54 pts at 5× | https://www.anthropic.com/engineering/infrastructure-noise | 2026-09-11 |
| Eval contamination, measured | BrowseComp, Opus 4.6 multi-agent: 9 straightforward contaminations across 1,266 problems; 2 eval-aware cases that identified the benchmark and decrypted its answer key; 18 runs attempted it; adjusted score 86.81% → 86.57% | https://www.anthropic.com/engineering/eval-awareness-browsecomp | 2026-09-11 |
| Multi-agent amplification of contamination | 0.87% unintended solutions multi-agent vs 0.24% single-agent (3.7×) | https://www.anthropic.com/engineering/eval-awareness-browsecomp | 2026-09-11 |
| SWE-bench Verified saturation | reported as progressing from ~40% to >80% in one year; treat any specific figure as dated — read the official leaderboard | https://www.swebench.com/SWE-bench/ | 2026-09-11 |
| τ-bench | arXiv:2406.12045 (17 Jun 2024); introduced pass^k; SOTA function-calling agents <50%, pass^8 <25% in retail. Successor τ²-bench arXiv:2506.07982 | https://arxiv.org/abs/2406.12045 | 2026-09-11 |
| pass@k estimator | Chen et al., arXiv:2107.03374 (2021): `1 − C(n−c,k)/C(n,k)` | https://arxiv.org/abs/2107.03374 | 2026-09-11 |
| LLM-as-judge biases | Zheng et al., arXiv:2306.05685 (NeurIPS 2023): position, verbosity, self-enhancement; GPT-4 judges >80% agreement with humans, the same level as human-human | https://arxiv.org/abs/2306.05685 | 2026-09-11 |
| Criteria drift | Shankar et al., arXiv:2404.12272 (UIST '24): users need criteria to grade outputs, and grading outputs is how they define criteria | https://arxiv.org/abs/2404.12272 | 2026-09-11 |
| Cost as a first-class eval metric | Kapoor et al., arXiv:2407.01502 (Jul 2024; TMLR 2025): accuracy-only benchmarking, conflated developer needs, inadequate holdouts, no standardisation | https://arxiv.org/abs/2407.01502 | 2026-09-11 |
| Holistic Agent Leaderboard | Kapoor et al., ICLR 2026 — nine benchmarks, the current cross-benchmark reference | https://openreview.net/forum?id=vUaY1t64ZZ | 2026-09-11 |
| Kappa interpretation bands | Landis & Koch, *Biometrics* 33(1), 1977: 0.41–0.60 moderate, 0.61–0.80 substantial, >0.81 almost perfect. A convention, not a law | doi:10.2307/2529310 | 2026-09-11 |
| Eval framework landscape | Harbor, Braintrust, LangSmith, Langfuse, Arize Phoenix — named in Anthropic's appendix; Atlas uses none of them and the reasoning is in §10 | https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents | 2026-09-11 |
| `ATLAS_JUDGE_MODEL` | new config key; must differ from `ATLAS_MODEL` or `judge_answer` raises `JudgeModelCollision`. Use a second Tier A model or a Tier H model | this repo | 2026-09-11 |
| Minimum detectable effect, this suite | **0.106** at n=61, p=0.9 — about six tasks flipping. Corrects the "about 8 points" estimate in this phase's own §6.7 (F-13-05) | measured, `make results` | 2026-09-11 |
| Offline test count | 1433 passed, 12 skipped | `make test-offline` | 2026-09-11 |
| Gradeable eval tasks | 61 (62 defined); suite version `51defc1a6f34` | `python evals/run.py --trials 1` | 2026-09-11 |
| Tasks with provenance | 62/62 — golden 48, harvested 14; 1 held out | `make results ARGS="--only inventory"` | 2026-09-11 |
| Tier A calls for `make results` | 84 (72 calibration + 12 padding probe); full eval sweep ≈1,400, a separate overnight job | `make plan` | 2026-09-11 |
| Tier H cap, this phase | ≤300, spent 0 during authoring | `make plan` | 2026-09-11 |
| Judge-vs-human kappa | **NOT MEASURED.** Tier F reports +1.000 against a scripted stand-in and refuses to append it. Author estimate for Tier A small model: 0.35–0.65; Tier H frontier: 0.60–0.85 | author estimate, unmeasured | 2026-09-11 |
| `atlas-broken` | branch off `phase-13` carrying four planted defects for Assignment 1; `make test-offline` is GREEN on it and `make eval-gate` blocks | this repo | 2026-09-11 |
| `ATLAS_INTERFACES.md` version | v0.27, invariants 73–75 | repo | 2026-09-11 |

**Pre-release APIs used in code: none.** Phase 13 adds no dependency: `evals/`
is standard library plus Pydantic, which was already pinned.

## Phase 14 delta — checked 2026-09-11

Security-standard rows re-verified against **primary** sources this phase. The
Phase 1 note admitted the ASI entry titles came from secondary summaries and
promised "Phase 11 reads the list properly"; Phase 11 was multi-agent systems
and did not. The titles below are taken from the OWASP GenAI Security Project's
own announcement, authored by the Agentic Top 10 chair — better than a vendor
blog, still not the PDF. Download the PDF before quoting them anywhere it
matters.

| Fact | Value | Source | Checked |
|---|---|---|---|
| OWASP Top 10 for Agentic Applications, entry titles (primary) | ASI01 Agent Goal Hijack · ASI02 Tool Misuse · ASI03 Identity & Privilege Abuse · ASI04 Agentic Supply Chain Vulnerabilities · ASI05 Unexpected Code Execution · ASI06 Memory & Context Poisoning · ASI07 Insecure Inter-Agent Communication · ASI08 Cascading Failures · ASI09 Human-Agent Trust Exploitation · ASI10 Rogue Agents | https://genai.owasp.org/2025/12/09/owasp-top-10-for-agentic-applications-the-benchmark-for-agentic-security-in-the-age-of-autonomous-ai/ | 2026-09-11 |
| ASI architectural principle | "Least agency" — autonomy is granted per task, not by default | same as above | 2026-09-11 |
| OWASP Top 10 for LLM Applications 2026, full ordering | LLM01 Prompt Injection · LLM02 Sensitive Information Disclosure · LLM03 Excessive Agency · LLM04 Supply Chain · LLM05 Data and Model Poisoning · LLM06 Unbounded Consumption · LLM07 Misinformation · LLM08 Hidden Context Exposure · LLM09 Vector and Embedding Weaknesses · LLM10 Improper Output Handling | https://genai.owasp.org/resource/owasp-genai-llm-top-10-2026/ | 2026-09-11 |
| Most consequential 2026 LLM change | Excessive Agency 6th → 3rd; Improper Output Handling 5th → 10th; System Prompt Leakage renamed Hidden Context Exposure | https://genai.owasp.org/2026/09/01/owasp-genai-security-project-unveils-2026-top-10-for-llm-applications-new-agent-control-standard-and-sponsors-as-community-tops-30000-members/ | 2026-09-11 |
| OWASP MCP Top 10 status | **BETA (Phase 3, pilot testing)**, entries MCP01:2025–MCP10:2025, next release listed for October 2026. PRE-RELEASE: named in prose, never relied on in code | https://owasp.org/www-project-mcp-top-10/ | 2026-09-11 |
| MCP entries Phase 14 cites | MCP01 Token Mismanagement & Secret Exposure · MCP02 Privilege Escalation via Scope Creep · MCP03 Tool Poisoning · MCP05 Command Injection & Execution · MCP07 Insufficient Authentication & Authorization | https://owasp.org/www-project-mcp-top-10/ | 2026-09-11 |
| OWASP Agent Control Standard (ACS) | Donated to the OWASP GenAI project; announced 2026-09-01. Forward pointer only; nothing in this book uses it | https://genai.owasp.org/resource/agent-control-standard-acs/ | 2026-09-11 |
| Coding assistant | unchanged from the Phase 3 row | — | 2026-09-11 |
| Tier A / Tier H models | unchanged from the Phase 3 rows; re-run `ollama show $ATLAS_MODEL` before this phase's sweeps | (see the Tier A / Tier H rows above) | 2026-09-11 |
| Tier H cap, this phase | **50 calls**, per the Phase 14 block; the 200,000 token/day cap is unchanged and still the binding constraint | https://console.groq.com/docs/rate-limits | 2026-09-11 |
| Docker image used by the sandboxed executor | `python:3.12-slim` (a TAG, pinned in `atlas/tools/sandbox.py`; pin a digest in production) | https://hub.docker.com/_/python | 2026-09-11 |

### Papers and posts cited as dated history in Phase 14

| Fact | Value | Source | Checked |
|---|---|---|---|
| "Lethal trifecta" coinage | Simon Willison, 16 June 2025 | https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/ | 2026-09-11 |
| Agents Rule of Two | Meta, 31 October 2025; ≤2 of {untrusted input, sensitive data, change state / communicate externally} per session | https://ai.meta.com/blog/practical-ai-agent-security/ | 2026-09-11 |
| Adaptive attacks vs published defences | Nasr et al., *The Attacker Moves Second*, arXiv:2510.09023, October 2025. 12 defences, ASR >90% for most; spotlighting and prompt sandwiching >95% under search attack against ~1% on the benchmark's static attacks | https://arxiv.org/abs/2510.09023 | 2026-09-11 |
| CaMeL | Debenedetti et al., *Defeating Prompt Injections by Design*, arXiv:2503.18813 (v2, June 2025). 77% of AgentDojo tasks with provable security vs 84% undefended | https://arxiv.org/abs/2503.18813 | 2026-09-11 |
| Dual LLM pattern | Simon Willison, April 2023 | https://simonwillison.net/2023/Apr/25/dual-llm-pattern/ | 2026-09-11 |
| EchoLeak | CVE-2025-32711, Aim Labs vs Microsoft 365 Copilot, disclosed June 2025; data embedded in a Markdown link URL | https://simonwillison.net/2025/Jun/16/the-lethal-trifecta/ | 2026-09-11 |
| Claude Code sandboxing design | OS primitives (Seatbelt / bubblewrap), network via a proxy outside the sandbox with a domain allowlist, scoped to the Bash tool; approval fatigue named as the motivating problem | https://code.claude.com/docs/en/sandboxing · https://github.com/anthropic-experimental/sandbox-runtime | 2026-09-11 |

### Known-unverified, this phase (do not treat as checked)

| Claim | Why it is unverified | What to do |
|---|---|---|
| ASI list updated to "v2.01 on 1 June 2026" | One secondary vendor blog says so; the OWASP project page I read does not state a revision date | Download the PDF and read its version page before citing a revision |
| Exact publication date of the LLM Top 10 2026 | Secondary sources give 3 August and 4 August 2026; the OWASP press release is dated 2 September 2026 | Cite "2026 edition" and the resource URL, not a day |
| MCP06's title | The OWASP MCP page gives BOTH "Intent Flow Subversion" and "Prompt Injection via Contextual Payloads" for MCP06, in two places on one page | Do not cite MCP06 by title. This is why a beta list gets a VERSIONS row and never a line of code |
| Every Docker flag's effect on a non-Linux host | Docker is absent from the authoring container; `docker version` → command not found | Run `make redteam` with Docker installed and read `docker inspect` on a live container |

### Measured this phase (Tier F, scripted fixtures, seed 7, 2026-09-11)

| Quantity | Value | Printed by |
|---|---|---|
| Offline suite | 1,494 passed, 12 skipped | `make test-offline` |
| Eval tasks | 66 gradeable (63 + 3) | `make evals` |
| Pooled attack success rate, before | 0.600 [0.231, 0.882] | `make redteam` |
| Pooled attack success rate, after | 0.000 [0.000, 0.434] | `make redteam` |
| Minimum detectable effect at n=5 | 0.372 | `make redteam` |
| Controls passing, after | 3/3 | `make redteam` |
| Injection signal on its own benign control | score 1 — a FALSE POSITIVE | `make results ARGS='--only signals'` |
| Injection signal on a real poisoned skill | score 0 — a FALSE NEGATIVE | `make results ARGS='--only signals'` |

### Phase 14 SECOND PASS — corrections found by auditing the phase against its own block (2026-09-11)

| Was published | Is | Why it moved |
|---|---|---|
| Offline suite 1,494 | **1,498** | four tests added for `evals/reliability.py` |
| "2 × 30-run reliability suites (~18 min each)" in the header | `make reliability`, 30 runs, seconds on Tier F | the suite did not exist when the budget was written. Invariant 73, in a header |
| `docs/RESULTS.md` Phase 14 section: absent | present, headed **TIER F, SCRIPTED FIXTURES** | `--append-results` correctly refuses a scripted sweep; the correct response was a labelled hand-written section, not silence |
| Retry: `atlas.safety.reliability.RetryPolicy` | deleted; retry is `atlas.llm.RetryPolicy` + new `full_jitter` | third copy of one policy; and the transport retry had NO jitter for eleven phases (F-14-07) |
| `run_python`: Phase 3 subprocess | **containerised by default**; `unsafe_code=True` to opt out | `make_sandboxed_code_tool` had no call site anywhere in `atlas/` (F-14-10) |
| `fence` nonce: `secrets.token_hex(4)` | `content_nonce`, a digest | a random nonce changes the prompt on every render, i.e. the cache key (F-14-08) |
| Injection classifier: wired to nothing | called in `render_extracts`, adds a warning line, drops nothing | it was built, tested, printed and never called (invariant 72) |
| Failure-log entries, this phase: 5 | **12** | seven found by the audit, six of twelve in `ERROR_TAXONOMY` cluster B |

Measured after the second pass, Tier F, seed 7: **1,498 tests / 12 skipped**,
66 gradeable eval tasks, `make check-docs` green, pooled ASR **0.600 → 0.000**
(MDE 0.372, n=5), reliability suite **PASS** (0 duplicated side effects, 30/30
within budget).

## Phase 15 delta — checked 2026-09-14

Two standards matter to this phase and **neither is stable in the same sense**:
MCP's 2026-07-28 revision is a released specification, and OpenTelemetry's
GenAI semantic conventions are not released at all. The phase relies on the
first in code and on the second only as a *vocabulary*, which is why every
`gen_ai.*` name lives in one module (`atlas/obs/semconv.py`) and a spec rename
is a diff there rather than a migration.

| Fact | Value | Source | Checked |
|---|---|---|---|
| OTel GenAI semantic conventions, where they live | Moved OUT of `open-telemetry/semantic-conventions` and into `open-telemetry/semantic-conventions-genai` with core v1.42.0 (12 June 2026). The old `docs/gen-ai/` pages are redirect stubs. | https://github.com/open-telemetry/semantic-conventions/releases · https://github.com/open-telemetry/semantic-conventions-genai | 2026-09-14 |
| OTel GenAI conventions, release status | **No tagged release.** The repository's Releases section is empty and its README's "Schema URL" section reads `TODO`. Conventions ship from `main`. Status on the documents: **Development** | https://github.com/open-telemetry/semantic-conventions-genai | 2026-09-14 |
| What "Development" means in OTel's maturity ladder | Below Alpha; a component SHOULD NOT be used in production and MAY be removed without prior notice | https://opentelemetry.io/docs/specs/otel/versioning-and-stability/ | 2026-09-14 |
| Stable attributes on a GenAI span | `error.type`, `server.address`, `server.port` — and all three are **inherited from the core conventions**, not written by the GenAI group. Nothing under `gen_ai.*` is Stable | https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans | 2026-09-14 |
| GenAI span attributes Atlas emits | `gen_ai.operation.name` (Required) · `gen_ai.provider.name` · `gen_ai.request.model` · `gen_ai.response.model` · `gen_ai.request.temperature` · `gen_ai.request.seed` · `gen_ai.response.finish_reasons` · `gen_ai.usage.input_tokens` · `gen_ai.usage.output_tokens` · `gen_ai.conversation.id` · `gen_ai.agent.name` · `gen_ai.tool.name` · `gen_ai.tool.type` · `gen_ai.data_source.id` | https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans | 2026-09-14 |
| Recommended GenAI span name | `{gen_ai.operation.name} {gen_ai.request.model}` | https://opentelemetry.io/docs/specs/semconv/gen-ai/gen-ai-spans | 2026-09-14 |
| Content capture default | OFF. Messages are Opt-In attributes (`gen_ai.input.messages`, `gen_ai.output.messages`, `gen_ai.system_instructions`) precisely because they carry prompts, outputs, PII and secrets | https://opentelemetry.io/blog/2026/genai-observability/ | 2026-09-14 |
| MCP semantic conventions (`mcp.*`) | Moved into the **same** GenAI repository as part of the June 2026 split; also Development, also unreleased | https://github.com/open-telemetry/semantic-conventions-genai | 2026-09-14 |
| MCP specification, current revision | **2026-07-28, stable**, released 28 July 2026. Stateless core; `initialize` handshake and `Mcp-Session-Id` removed; Multi Round-Trip Requests; extensions framework; deprecation policy with a ≥12-month window | https://blog.modelcontextprotocol.io/posts/2026-07-28/ · https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-14 |
| MCP Tasks | An **official extension**, identifier `io.modelcontextprotocol/tasks`, SEP-2663. Opt-in per request via `_meta`; the server may return a task handle instead of the result and the client polls `tasks/get`. Requires protocol 2026-07-28+ | https://tasks.extensions.modelcontextprotocol.io/ | 2026-09-14 |
| OTLP/JSON trace body shape | `resourceSpans[].scopeSpans[].spans[]`; ids are lowercase base16 (32 / 16 chars); 64-bit integers and timestamps are encoded as **strings**; attribute values are typed `AnyValue` objects | https://opentelemetry.io/docs/specs/otel/protocol/file-exporter/ | 2026-09-14 |
| Local tracing backend used by `deploy/` | Jaeger **v2**, image `cr.jaegertracing.io/jaegertracing/jaeger:2.20.0`. UI 16686, OTLP/HTTP 4318, OTLP/gRPC 4317. Jaeger v1 reached **end of life 2025-12-31**; v2 is built on the OpenTelemetry Collector | https://www.jaegertracing.io/docs/2.20/architecture/ | 2026-09-14 |
| FastAPI | 0.141.1 (resolved by `pip install fastapi` on this date; pulls Starlette 1.6.0) | https://pypi.org/pypi/fastapi/json | 2026-09-14 |
| uvicorn (the `serve` extra, not core) | 0.42.0 | https://pypi.org/pypi/uvicorn/json | 2026-09-14 |
| Base image for `deploy/Dockerfile` | `python:3.12-slim` — a TAG. Pin a digest in production | https://hub.docker.com/_/python | 2026-09-14 |
| Everything pinned in earlier phases | re-verified unchanged: pydantic 2.13.5, httpx 0.28.1, pytest 9.1.1, langgraph 1.2.11, langchain 1.4.0, mcp 2.2.0 | (see the rows above) | 2026-09-14 |
| Coding assistant | unchanged from the Phase 3 row | — | 2026-09-14 |
| Tier A / Tier H models | unchanged from the Phase 3 rows | (see the Tier A / Tier H rows above) | 2026-09-14 |
| Tier H cap, this phase | **0 calls.** Nothing in Phase 15 needs a hosted model | — | 2026-09-14 |

### Reading, not building — serving open-weight models

| Fact | Value | Source | Checked |
|---|---|---|---|
| PagedAttention and continuous batching | Introduced by vLLM; the PagedAttention paper is Kwon et al., SOSP 2023 | https://docs.vllm.ai/en/latest/ | 2026-09-14 |
| Version to install | **Check the docs before installing.** Deliberately not pinned here: nothing in Phases 0–16 runs vLLM, and a version row nobody depends on is a row nobody updates | https://docs.vllm.ai/ | 2026-09-14 |

### Known-unverified, this phase (do not treat as checked)

| Claim | Why it is unverified | What to do |
|---|---|---|
| Any behaviour of `deploy/docker-compose.yml` or `deploy/Dockerfile` | Docker is absent from the authoring container: `docker version` → command not found, exactly as in Phase 14 | Run `make compose`, then read `docker inspect` and the Jaeger UI yourself |
| That Jaeger renders Atlas's OTLP body correctly | No collector was reachable during authoring. The body is asserted against the OTLP spec's documented shape, which is not the same as a backend accepting it | Run the stack and look at http://localhost:16686 |
| Latency figures on a real model | Nothing in this phase ran on Tier A | `make results` on your own machine; `docs/RESULTS.md` labels the estimate |
| `uvicorn` 0.42.0 in particular | Installed only inside `deploy/Dockerfile`, which was not built | Re-resolve before you rely on the pin |

### Measured this phase (Tier F, scripted fixtures, seed 7, 2026-09-14)

| Quantity | Value | Printed by |
|---|---|---|
| Offline suite | **1,602 passed, 12 skipped** | `make test-offline` |
| New tests | 104 | `make test-offline` |
| Gradeable eval tasks | **69** (66 + 3) | `make evals` |
| Distinct trace ids for one cross-service request | **1** | `make spans` |
| MCP server spans inside that trace | 1, with a parent | `make spans` |
| Attribute keys surviving the export allowlist | 13 | `make results ARGS='--only otlp'` |
| `gen_ai.input.messages` in the exported body | **False** | `make results ARGS='--only otlp'` |
| Public names added with no call site, before the audit | **5** (including `build_atlas_api`) | `tests/test_service_phase15.py` |

### Phase 15 SECOND PASS — corrections found by auditing the phase against its own block (2026-09-14)

| Was published | Is | Why it moved |
|---|---|---|
| Offline suite 1,602 | **1,618** | 16 tests for `TeeingClient`, real streaming, approval events, the console and the alert rules |
| `/v1/chat/stream` chunks a finished answer | streams real model deltas on `STREAMING_ROUTES`; other routes replay and label it | the block asks for SSE streaming; `atlas.llm.stream` already existed |
| regression alerting deferred to Assignment 1 | `atlas/obs/alerts.py` ships, wired to `/v1/alerts` and `make alerts` | Phase 14 called alerting a security requirement (invariant 62) |
| Assignment 1: regression alerting | **tail-based sampling** (`atlas/obs/sampling.py`) | the phase now ships alerting; §10 discussed sampling and nothing implemented it |
| no web UI | `atlas/api/static/console.html` at `/` | listed under Hands-on in the phase block |
| `make plan`, `make record` broken; `make demo` silent | all three exit 0 | F-15-08 |
| Failure-log entries, this phase: 6 | **9** | three found by the second-pass audit |

## Phase 16 — re-verification and the personal VERSIONS.md

Phase 16 introduces no new dependency. Its job is to re-verify, and to hand the
habit over.

| Fact | Value | Source | Checked |
|---|---|---|---|
| Everything pinned in earlier phases | re-verified unchanged: pydantic 2.13.5, httpx 0.28.1, pytest 9.1.1, langgraph 1.2.11, langchain 1.4.0, mcp 2.2.0, fastapi 0.141.1 | (see the rows above) | 2026-09-14 |
| Current MCP specification revision | `2026-07-28`, final, published 28 July 2026 — unchanged since the Phase 12 check | https://modelcontextprotocol.io/specification/2026-07-28 | 2026-09-14 |
| **MCP roadmap, updated** | a new roadmap was published **22 Aug 2026**, after the Phase 12 check: stateless core landed, Contributor Ladder adopted, Working Groups triage SEPs, CIMD now the preferred client registration path | https://blog.modelcontextprotocol.io/posts/mcp-roadmap/ | 2026-09-14 |
| OWASP Top 10 for Agentic Applications | 2026 edition, ASI01–ASI10, published 9 Dec 2025 by the OWASP GenAI Security Project — unchanged | https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/ | 2026-09-14 |
| Tier A / Tier H models | unchanged from the Phase 3 rows | (see the Tier A / Tier H rows above) | 2026-09-14 |
| Coding assistant | unchanged from the Phase 3 row | — | 2026-09-14 |
| Tier H cap, this phase | **0 calls.** Nothing in Phase 16 needs a hosted model | — | 2026-09-14 |
| **New config key** | `ATLAS_H_EMBED_MODEL` → `Settings.h_embed_model`. Added by F-16-01; the Tier H embedding model is a different model from `ATLAS_H_MODEL` at every provider | `.env.example`, `atlas/config.py` | 2026-09-14 |

### Sources worth watching, and what each is good for

| Source | Good for | Checked |
|---|---|---|
| https://modelcontextprotocol.io/specification/ — the changelog page | the only authoritative record of what changed between revisions | 2026-09-14 |
| https://blog.modelcontextprotocol.io/ | roadmap posts, which say what will break before it breaks | 2026-09-14 |
| https://genai.owasp.org/ | the agentic threat taxonomy and its updates | 2026-09-14 |
| https://www.anthropic.com/engineering | agent design write-ups from people running agents at scale | 2026-09-14 |
| https://opentelemetry.io/docs/specs/semconv/gen-ai/ | the GenAI semantic conventions, still moving | 2026-09-14 |
| PyPI JSON API (`https://pypi.org/pypi/<pkg>/json`) | the only version number worth pasting into a pin | 2026-09-14 |

### Your own VERSIONS.md

Copy this file's format, not its contents. Four columns — fact, value, source
URL, checked-on date — and one rule: **a current-state fact never appears in
your prose, only here.** Re-verify before you start anything, and when a row
turns out to be stale, note what it cost you. That note is what turns a
maintenance chore into a habit you keep.

### Measured this phase (Tier F, seed 7, 2026-09-14)

| Quantity | Value | Printed by |
|---|---|---|
| Offline suite | **1,687 passed, 12 skipped** | `make test-offline` |
| Eval tasks | **74** | `make evals` |
| Capabilities supported / deferred / unsupported | **36 / 8 / 0** | `make capabilities` |
| Capability claims unsupported on the first run | **15 of 44** | — |
| Review findings unexplained / explained | **0 / 10** | `make review` |
| Capabilities exercised by `make demo` / by nothing | **36 / 0** | `make demo` |
| Files under `atlas/` naming the old domain | **10**, all with a written reason | `make swap` |

## Appendix E — regulatory and framework status (the most perishable rows in this book)

| Fact | Value | Source | Checked |
|---|---|---|---|
| EU AI Act, base instrument | Regulation (EU) 2024/1689; in force 1 Aug 2024 | https://eur-lex.europa.eu/eli/reg/2024/1689/oj | 2026-09-15 |
| EU AI Act, amending instrument | Regulation (EU) 2026/1744 (Digital Omnibus on AI), adopted 8 Jul 2026, OJ 24 Jul 2026, in force 27 Jul 2026 | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| Consolidated text in force | consolidated as of 2026-07-27 | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| Prohibited practices (Art. 5), original list | applies since 2 Feb 2025 | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| GPAI model obligations (Ch. V) | apply since 2 Aug 2025 | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| General date of application (Art. 113 §2) | 2 Aug 2026 — NOT moved by the Omnibus | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| Art. 50(2) marking, systems on the market before 2 Aug 2026 | 4-month transitional period (recital 38) | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| High-risk, Annex III (stand-alone) | 2 Dec 2027 (was 2 Aug 2026) — recital 40 | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| High-risk, Annex I (embedded) | 2 Aug 2028 (was 2 Aug 2027) — recital 40 | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| New Art. 5(1)(ba),(bb) prohibitions (NCII, CSAM) | added by Reg. 2026/1744; application date in amended Art. 113(3)(a) — reported as 2 Dec 2026, NOT verified in primary text; VERIFY | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| AI literacy (Art. 4) | rewritten into a duty to take measures to SUPPORT development; no guaranteed level required | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| Penalty ceilings (Art. 99) | read the current Article 99 in the consolidated text before quoting any figure; ceilings differ by infringement type, and the lower of the two figures applies to SMEs | https://eur-lex.europa.eu/eli/reg/2024/1689/2026-07-27/eng | 2026-09-15 |
| National AI regulatory sandboxes | operational by 2 Aug 2027 (amended Art. 57(1)) | https://eur-lex.europa.eu/eli/reg/2026/1744/oj | 2026-09-15 |
| NIST AI RMF | 1.0 (Jan 2023); page states 1.0 is being revised under the White House AI Action Plan | https://www.nist.gov/itl/ai-risk-management-framework | 2026-09-15 |
| NIST Generative AI Profile | NIST-AI-600-1, released 26 Jul 2024 | https://www.nist.gov/itl/ai-risk-management-framework | 2026-09-15 |
| NIST critical-infrastructure profile | concept note, 7 Apr 2026 — PRE-RELEASE; nothing here depends on it | https://www.nist.gov/itl/ai-risk-management-framework | 2026-09-15 |
| ISO/IEC 42001 | 42001:2023 current edition (catalogue record 81230); certification voluntary, by independent bodies | https://www.iso.org/standard/81230.html | 2026-09-15 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-15 |

**What could change these.** AI Act dates are fixed calendar dates in Article 113
and move only by a further amending regulation — but guidelines, harmonised
standards and delegated acts change *how* obligations are met without moving a
date. The NIST rows change when the RMF revision publishes. The ISO row changes
on a new edition; watch also ISO/IEC 42006 (requirements for bodies auditing AI
management systems), which affects who may certify you rather than what you must
do.
