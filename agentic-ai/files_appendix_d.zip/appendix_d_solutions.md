# appendix_d_solutions.md

Worked answers for Appendix D — *Voice, Realtime, and Multimodal Agents*. Concept checks, the "Your turn" exercise, the quiz, and both assignments in full.

There is no cumulative review and no case study: an appendix that does not grow the agent has neither. Every code block below was executed; where output is shown it is verbatim.

---

## Concept checks

### CC-1 — where the email address gets stripped

The two places are **the text going into the model** and **the text coming out of it**. Phase 14 occupies the second: `apply_egress_policy` strips outbound links and identifiers from the rendered answer, and it is an *output* control because its threat model is a poisoned document trying to exfiltrate through the answer channel.

The first place — scrubbing the transcript before it reaches the agent — is not occupied, and in a voice client it is newly attractive, because the transcript is now produced inside *your* process rather than typed by the user. That is a tempting place to put a redactor and a bad place to put the only one: an input scrubber cannot stop a model from reconstructing an identifier from retrieved documents, which is precisely the case Phase 14 built for.

The answer worth giving in an interview adds the third observation: in a cascade both places exist because both artefacts are text. Move to a native speech-to-speech model and the second one evaporates — the output is audio, the egress filter has no string to operate on, and the only text available is a transcription produced *after* the audio was generated and possibly after it was played. That is §6.2's argument in one concrete instance.

### CC-2 — "it sounds like it's buffering"

They are reporting **underruns**: the speaker ran out of audio mid-answer and stalled. The segment is `speech_synthesis`, specifically its *sustained* rate rather than its latency — the synthesiser is not producing audio faster than the speaker consumes it, so each sentence arrives slightly later than the last until a gap opens.

Optimising time-to-first-audio makes it worse because the cheapest way to start speaking sooner is to buffer less: begin playback after a shorter prefix, and you begin with less slack against a synthesiser that is only just keeping up. The two metrics pull in opposite directions, which is why `render_breakdown` prints `underruns` — with the dead air beside it — on the same line as the interrupted count.

The fix is a sustained-rate problem, not a latency problem: a synthesiser whose real-time factor is above one cannot stream an answer of any length, whatever its first-sentence latency looks like. Measure it on a paragraph, not on a sentence.

In this client the detection is `SpeechHandle.ends_at()`: if the next utterance is handed to the speaker after the previous one finished playing, the user heard a gap, and `LoopTimer.underrun(gap_ms)` records both the event and its size. That is the only definition available to a client that cannot see inside the audio device — and note that the first version of this appendix had the counter with no caller at all, so it printed zero forever and an eval check asserted a zero that could not move.

### CC-3 — why `truncated` is not a kind of `speech_end`

They mean the same thing to the *audio* and opposite things to the *user*. `speech_end` says the person finished; `truncated` says your cap fired while they were still going, so the utterance you are about to transcribe is a fragment of a question. The agent will answer the fragment, confidently, and nothing downstream will ever know that it was one.

Collapsing them costs three things: the ability to tell the user (which `voice/cli.py` does), the ability to count the event as a turn-taking error rather than as a normal turn, and the ability to notice a stuck microphone at all — a detector jammed at high probability produces an unbroken run of perfectly ordinary-looking `speech_end`s.

This is invariant 30's shape applied to an event vocabulary, and the same reasoning produced `TERMINAL_OUTCOMES` in `voice/loop.py`: an interrupted turn and a hung stream are two states with opposite remedies, and the first version of this client reported both as `""`.

### CC-4 — what to commit after two of five sentences

Commit **both spoken sentences**, joined, with the second truncated at the word the audio reached, marked as truncated, and rendered into the text the next turn's model sees:

```
{"role": "assistant", "content": "The March invoice is disputed. I can open the —"}
```

with `Utterance.truncated=True` on the record and `discarded_chars` counting the rest.

Three wrong answers are worth naming, because this appendix shipped two of them.

*Commit all five.* The model's context then contains three sentences the user never heard and cannot distinguish them from two the user did. On the next turn it says "as I mentioned", declines to repeat an offer it never made audible, and if one of those sentences asked a question it treats the user's next utterance as the answer. §8 is this failure with the trace.

*Commit only the prefix of sentence two.* This is the subtle one. Sentence one played in full and the user heard it; dropping it from the record means the agent will repeat itself, or will fail to build on something both parties know. `test_an_interruption_in_a_later_sentence_keeps_the_earlier_ones` exists because the first fix for the first bug was this bug.

*Commit a partial word.* If the cut lands inside the first word of sentence two, commit nothing from it — `Revenu` is a token nobody said and no tokenizer expects. The turn is still recorded and still marked truncated, so the record says "cut off before a word got out", which is true and useful.

The subtlest half of all: the truncation marker has to survive into the *prompt*, not just into the record. A boolean on a Pydantic model is invisible to the consumer that most needs it, which is why `committed_context()` renders the mark into the string.

### CC-5 — one boolean, four consequences

A tool mislabelled `read_only=True` when it writes:

* **approval** — the write happens with no human decision, and the audit trail records an action nobody authorised;
* **retry** — a transient failure causes the write to happen twice, which for a non-idempotent operation is two refunds;
* **caching** — a write is *replayed* from cache, or its stale result is served as though the write had happened when it had not;
* **speculative execution** — the write is performed on a **partial transcript**, i.e. on a sentence the user had not finished saying.

The fourth is worst, and not because the effect is bigger. The first three require the user to have actually asked for the thing. Speculation performs an action derived from a hypothesis that later words were expected to revise, so the triggering input may be a sentence that was never uttered: "cancel the—" becomes "cancel the meeting? no, the reminder", and the meeting is already gone. It also has the worst forensics, because the transcript in the record is the *final* one, which does not contain the words the speculation acted on.

Hence the rule in §6.6: speculate on read-only tools only, and hold invariant 66's line — the flag is unverified unless something verifies it.

### CC-6 — headphones fine, speakers catastrophic

The missing component is **acoustic echo cancellation**. Without it the microphone hears the loudspeaker, the VAD sees speech, the monitor returns `True`, and the agent barge-ins on its own voice roughly one word into every answer.

It belongs at the boundary between segments 8 and 1 — the loop back from the speaker into capture — which is why a browser or WebRTC client usually has it and a hand-rolled Python client usually does not: AEC is one of the things WebRTC bundles, along with jitter buffering and packet loss concealment.

It is invisible in the breakdown because **nothing about it is slow**. Every segment records a healthy duration; time-to-first-audio is excellent, because the agent reliably produces audio and then immediately stops. The metric that shows it is `interrupted turns`, which is why that count is printed in the same block as the percentiles. A breakdown with a good p50 and an interruption rate near 100% is the signature, and the diagnosis is not a latency diagnosis at all.

---

## "Your turn" (§6.4) — making the machine end a turn mid-sentence

The sequence is someone reading out a number and pausing between groups. At 30 ms frames with a 600 ms hangover, any silent run of 20 frames or more ends the turn, so 22 frames of silence inside the utterance is enough:

```python
track = [0.9] * 40 + [0.02] * 22 + [0.9] * 20 + [0.02] * 25
```

Fed to `Endpointer(EndpointPolicy(frame_ms=30, hangover_ms=600, min_speech_ms=120))`, verbatim:

```
600ms:  [(3, 'speech_start'), (59, 'speech_end'), (65, 'speech_start'), (101, 'speech_end')]
```

Two turns where the speaker intended one. The agent answers "my account number is four two", which is not a question, and the remaining digits arrive as a second utterance.

The one parameter change is a longer hangover. At 1,000 ms:

```
1000ms: [(3, 'speech_start')]
```

— the mid-utterance pause no longer ends anything, and the machine is still mid-utterance when the track runs out, which is itself worth noticing.

**The cost, measured on the same machine.** A genuinely finished turn — 30 frames of speech, then silence — ends at frame 49 under the 600 ms policy and at frame 62 under the 1,000 ms one: thirteen frames, 390 ms, added to *every* turn in the conversation, including the ninety per cent that never needed it. That is the trade in one line, and it is the entire motivation for Assignment 1: a guard that spends the extra time only when the words look unfinished pays the cost on the turns that need it and not on the others.

---

## Quiz answers

**1. Why does a single VAD threshold produce three events where two belong, and what does the second threshold buy that a longer minimum-speech window does not?**

A probability hovering at the boundary crosses it repeatedly within a few frames — real speech does this constantly at word boundaries, on unvoiced consonants, and in any background noise — so a single threshold emits `speech_end` and then `speech_start` inside a quarter of a second, and the transcriber receives three fragments of one word. The second threshold creates a band in which the machine *holds its current state*: you must be clearly above to enter speech and clearly below to leave it. A longer minimum-speech window does not help, because `min_speech_ms` only gates the *entry* into an utterance; the flapping happens after entry, on the exit path, where that parameter has no say at all.

**2. A team reduces its hangover from 800 ms to 300 ms and reports a 500 ms latency improvement. What have they actually traded, and which metric would show the cost?**

They have traded cut-off errors for latency, and the reported number is half the story. The metric that shows the cost is the **turn-taking error count, broken into its three buckets** — specifically the cut-off bucket, which counts turns the system ended while the user was still speaking. It will rise, and it will rise unevenly: most on speakers who pause mid-utterance, which correlates with non-native speakers, older users, people reading information off a screen, and anyone nervous. A single aggregate latency figure cannot show any of that, and neither can an aggregate error rate; you need the buckets, and ideally the buckets by speaker.

**3. Explain why speculative execution on a partial transcript is a constraint on your *tool design* rather than on your speech stack.**

Speculation means starting work on a hypothesis that may be retracted. That is safe only if the work can be thrown away, which means **no side effect may occur before the input is committed**. Nothing about the transcriber decides that; it is decided by whether your tools are read-only, whether your writes are idempotent, and whether your agent performs effects during planning. If any tool on the speculative path writes, speculation is unavailable no matter how good your ASR is — and if every tool on that path is verifiably read-only, speculation is available even with a mediocre one. It is Phase 10's rule again: a node body runs an unbounded number of times while only its committed output runs once.

**4. Your voice client closes the SSE stream when the user interrupts. Describe the state of the system one second later, on the server, if the agent was mid-way through a gated write.**

The agent is still running. Closing the stream stops *your process reading*; it does not signal the server, and Phase 15's own cancellation endpoint says in its response body that cancellation is cooperative — work already running stops at its next checkpoint. So one second later: the write is proceeding or has completed, the thread has been touched, the audit entry names the subject, and the spans for the turn will close normally and appear in `/metrics` and in the trace. From the user's side, the agent went quiet and they believe they stopped it. The correct client behaviour is to say otherwise; the correct system behaviour is that the write was gated in the first place, because an approval granted before interrupting is still an approval, and one never granted means the write should not have been in flight at all.

**5. A native speech-to-speech model removes the transcript from the critical path. Name two Atlas controls that depended on it and say what would have to replace each.**

Any two of: **the egress filter** (Phase 14 strips links and identifiers from rendered answer *text*) — replaced by constraining the model's output at generation time, or by a transcription-and-review step that necessarily runs after the audio exists, which is a weaker control and should be described as one; **the rubric judge** (Phase 13 grades a sentence a human reads) — replaced by grading a transcription of the output, which introduces the judge's own recognition error into every score, plus voice-specific graders for what the transcription loses; **the approval gate's consequence renderer** — which survives, but its *delivery* becomes audio, so "the user read the consequence before deciding" must be re-established by construction rather than assumed; and **the eval suite's tool-choice tasks**, which grade a serialised plan a native model may never emit.

**6. Why does `render_breakdown` print `____` for a segment with no samples instead of `0.0`, and what error would the zero cause in a p50?**

Because "did not happen" and "took no time" are different facts, and a zero merges them. A zero pulls the p50 of that segment towards zero and, if the renderer summed segments, would make a stack look faster than it is. Worse, it converts a *missing instrument* into a flattering *measurement*: a segment that never records because the timing call is on a path that never runs prints 0.0 ms and reads as the fastest part of your system, so nobody investigates. `____` says "you have not measured this", which is a statement somebody can act on. It is `Span.duration_ms` returning `None` for an open span, one layer up — and it is the exact defect this appendix shipped in its first version, in five segments at once.

---

## Assignment 1 — a semantic end-of-turn guard **[fast track]**

Reference solution. Passes 9 of 9 hidden assertions; a submission implementing the word rules but omitting the cap fails 2 of 9 (`test_the_cap_beats_every_other_rule`, `test_extra_never_exceeds_what_is_left_of_the_cap`).

```python
# voice/eou.py
"""A semantic end-of-turn guard: extend the wait when the words are unfinished.

The VAD-and-hangover policy in `voice/endpoint.py` knows how long the silence
has been and nothing about what was said, so it treats "my account number is
four two" and "that's all, thanks" identically. This module is the second
opinion: it looks at the partial transcript and decides whether to hold the
turn open a little longer.

Three design commitments.

**It returns a decision, not a duration.** `WaitDecision` carries the reason,
drawn from a closed set, so a log line says WHY the agent waited. A function
returning `int` would make "waited 700 ms because the user said um" and
"waited 700 ms because the model is slow" the same observation.

**The cap beats every other rule.** A user who ends every clause with "and"
must still be answered, and a guard whose extension can be re-granted forever
is a loop whose symptom is "the agent ignores me". `silence_ms >=
max_wait_ms` short-circuits before any text is inspected.

**`extra_ms` is clamped to what is left of the cap**, so the guard cannot
spend budget it does not have. Returning `policy.extra_ms` unconditionally
gives you a cap that is never reached, which is the same bug wearing the
opposite hat.

Pure, so a test is a table of strings and numbers. It deliberately holds no
model: a learned end-of-turn model is the production answer (see VERSIONS.md)
and it plugs in behind this same signature.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel

__all__ = [
    "Reason",
    "REASONS",
    "HOLD_WORDS",
    "FILLERS",
    "WaitPolicy",
    "WaitDecision",
    "should_wait",
]

Reason = Literal[
    "complete",
    "trailing_conjunction",
    "trailing_number",
    "filler",
    "cap_reached",
    "no_text",
]
REASONS: tuple[Reason, ...] = (
    "complete",
    "trailing_conjunction",
    "trailing_number",
    "filler",
    "cap_reached",
    "no_text",
)

HOLD_WORDS = frozenset(
    {
        "and", "but", "so", "because", "or", "the", "a", "to", "for", "my",
        "is", "of", "with", "at", "in", "then",
    }
)
"""Words that cannot end an English sentence: conjunctions, prepositions,
determiners, copulas. If the transcript stops here, the speaker has not. A
small hand list rather than a part-of-speech tagger, because the tagger is a
dependency and the list is the ninety per cent."""

FILLERS = frozenset({"um", "uh", "er", "erm", "like", "well"})
"""Disfluencies. A filler is the strongest available evidence that somebody is
still composing, and it is the case a pure-silence policy gets most reliably
wrong."""


class WaitPolicy(BaseModel):
    """How much longer, and never more than. Frozen."""

    model_config = {"frozen": True, "extra": "forbid"}

    extra_ms: int = 700
    max_wait_ms: int = 2500


class WaitDecision(BaseModel):
    """Wait or do not, how long, and why. Frozen; the reason is closed."""

    model_config = {"frozen": True}

    wait: bool
    extra_ms: int
    reason: Reason


def should_wait(
    partial_text: str,
    silence_ms: float,
    policy: WaitPolicy = WaitPolicy(),
) -> WaitDecision:
    """Whether to hold the turn open, given the words so far. Pure."""
    # FIRST, before anything reads the text. A guard that checks the cap last
    # can be talked out of it by a sentence.
    if silence_ms >= policy.max_wait_ms:
        return WaitDecision(wait=False, extra_ms=0, reason="cap_reached")

    text = (partial_text or "").strip()
    if not text:
        # No transcript: nothing for THIS guard to have an opinion about, so
        # the endpointing policy's own decision stands.
        return WaitDecision(wait=False, extra_ms=0, reason="no_text")

    budget = int(min(policy.extra_ms, max(0.0, policy.max_wait_ms - silence_ms)))
    last = text.split()[-1].strip(",;:")

    if text[-1] in ".!?":
        return WaitDecision(wait=False, extra_ms=0, reason="complete")
    if last.lower() in FILLERS:
        return WaitDecision(wait=True, extra_ms=budget, reason="filler")
    if last.lower() in HOLD_WORDS:
        return WaitDecision(wait=True, extra_ms=budget, reason="trailing_conjunction")
    if last[-1].isdigit():
        # Somebody reading out an account number, a date or a quantity pauses
        # between groups, and that pause is longer than the one between words.
        return WaitDecision(wait=True, extra_ms=budget, reason="trailing_number")
    return WaitDecision(wait=False, extra_ms=0, reason="complete")
```

Executed against the default policy (`extra_ms=700`, `max_wait_ms=2500`):

```
'that is all thanks.'              600 -> wait=False extra=   0 complete
'I want the Q3 report and'         600 -> wait=True  extra= 700 trailing_conjunction
'the number is um'                 600 -> wait=True  extra= 700 filler
'account 4 2'                      600 -> wait=True  extra= 700 trailing_number
'I want the report and'           2100 -> wait=True  extra= 400 trailing_conjunction
'I want the report and'           2500 -> wait=False extra=   0 cap_reached
'   '                              600 -> wait=False extra=   0 no_text
'show me the March invoice'        600 -> wait=False extra=   0 complete
```

**The three lines worth reading twice.** Rows five and six are the same text at different silences: at 2,100 ms the guard still wants to wait but may only grant 400 ms, and at 2,500 ms it declines regardless of what the words say. That is the cap doing its job, and a submission missing either half has a guard that can extend forever on one sentence.

Row eight catches over-eager implementations. "show me the March invoice" ends in a noun and no terminal punctuation — partial transcripts usually have none — so a guard that waits whenever punctuation is absent waits on *every* turn and has silently lengthened the hangover for everybody. The default must be not to wait; the rules are exceptions.

**How you would take this further**, and what the hidden tests deliberately do not require: a learned end-of-utterance model in place of the word lists (the current open ones are VERSIONS.md rows), the same guard applied to the *interruption* decision rather than only the turn-end decision, and — the honest one — measuring the guard on recordings of people who are not you, because `HOLD_WORDS` is a hypothesis about English and nothing else.

---

## Assignment 2 — diagnose the breakdown **[extended]**

Reference solution. Passes 7 of 7 hidden assertions; a version that ranks every measured segment fails 2 of 7 (`test_capture_is_not_a_candidate`, `test_the_response_after_first_audio_is_not_a_candidate`).

```python
# voice/budget.py
"""Reading the breakdown: which segment to fix, or a refusal to guess.

`render_breakdown` prints a table; this turns the table into an instruction.
Two decisions carry the whole assignment.

**Only segments on the path to first audio are candidates.** `capture` is the
user talking and is always the largest number in the table; `full_agent_
response` continues after the audio started and costs the user nothing they
experience as waiting. A diagnoser that ranks every measured segment says
"capture" forever, which is a `max()` with a job title. `ON_PATH` is the
closed set, and it is closed for `SEGMENTS`' reason -- a new segment is a
deliberate edit here and in `FIXES` together.

**Below the sample floor it refuses.** Phase 13's rule, one layer down: a p50
over three turns is a number, not a measurement, and a tool that names a
dominant segment from it sends somebody to optimise noise for an afternoon.
The refusal carries the count, so the answer is "come back with five" rather
than a shrug.

Percentiles come from `atlas.obs.metrics`, for the reason `voice/timing.py`
gives: the appendix does not get a second definition of p50.
"""

from __future__ import annotations

from typing import Sequence

from pydantic import BaseModel

from atlas.obs.metrics import percentile
from voice.timing import TurnTiming

__all__ = ["ON_PATH", "FIXES", "Diagnosis", "diagnose"]

ON_PATH: tuple[str, ...] = (
    "endpointing",
    "transcription",
    "first_agent_token",
    "speech_synthesis",
    "first_audio_out",
)
"""The segments a user waits through before hearing anything. `capture` and
`full_agent_response` are deliberately absent."""

FIXES: dict[str, str] = {
    "endpointing": (
        "a semantic end-of-turn model, or a shorter hangover accepted with "
        "its interruption cost"
    ),
    "transcription": (
        "a smaller or streaming-native model; transcribe partials during speech"
    ),
    "first_agent_token": (
        "shorter prompt, fewer retrieved chunks, smaller model, prompt caching"
    ),
    "speech_synthesis": (
        "synthesise sentence by sentence rather than the whole answer"
    ),
    "first_audio_out": "a smaller playback buffer, accepting the underrun risk",
}
"""One fix per segment, and none of them is 'a faster machine'. The mapping is
data rather than an `if` chain so that a reader can see the whole policy at
once and so a test can assert that every candidate segment has one."""


class Diagnosis(BaseModel):
    """What to fix, how sure, and the arithmetic behind it. Frozen."""

    model_config = {"frozen": True}

    dominant: str | None
    share: float | None
    fix: str
    confident: bool
    note: str


def diagnose(timings: Sequence[TurnTiming], *, min_samples: int = 5) -> Diagnosis:
    """Name the dominant segment on the path to first audio, or decline."""
    usable = [t for t in timings if t.time_to_first_audio_ms is not None]
    if len(usable) < min_samples:
        return Diagnosis(
            dominant=None,
            share=None,
            fix="",
            confident=False,
            note=(
                f"{len(usable)} turn(s) with both anchors; {min_samples} needed "
                "before a p50 means anything"
            ),
        )

    reference = percentile(
        [t.time_to_first_audio_ms for t in usable], 0.5  # type: ignore[arg-type]
    )
    best_name: str | None = None
    best_p50 = -1.0
    for name in ON_PATH:
        values = [t.segments[name] for t in usable if name in t.segments]
        if not values:
            continue
        p50 = percentile(values, 0.5)
        if p50 > best_p50:
            best_name, best_p50 = name, p50

    if best_name is None:
        # Every turn was anchored and no segment on the path was recorded:
        # the instrument is broken, not the stack. Saying so beats naming a
        # segment at random.
        return Diagnosis(
            dominant=None,
            share=None,
            fix="",
            confident=False,
            note="no segment on the path to first audio was measured",
        )

    return Diagnosis(
        dominant=best_name,
        share=round(best_p50 / reference, 4) if reference else None,
        fix=FIXES[best_name],
        confident=True,
        note=(
            f"p50 {best_p50:.1f} ms of {reference:.1f} ms to first audio, "
            f"n={len(usable)}"
        ),
    )
```

Executed on three turns:

```
{'dominant': None, 'share': None, 'fix': '', 'confident': False,
 'note': '3 turn(s) with both anchors; 5 needed before a p50 means anything'}
```

and on six turns carrying a large `capture` and a large `full_agent_response` alongside the path segments:

```
dominant : transcription
share    : 0.4934
confident: True
note     : p50 1500.0 ms of 3040.0 ms to first audio, n=6
fix      : a smaller or streaming-native model; transcribe partials during speech
```

**Why `capture` had to be excluded, concretely.** In that fixture `capture` is 9,000 ms and `full_agent_response` is 4,000 ms — both far larger than anything on the path. A diagnoser built as `max(segments)` returns `capture` and tells you to fix the user talking. It is not a subtle bug and it is the one almost every first implementation ships, because ranking everything is the obvious reading of "find the dominant segment". The lesson generalises: a diagnostic tool needs a domain of candidates as much as it needs an ordering, and the candidates are a design decision that belongs in a named constant beside the fixes.

**Why the floor is a refusal rather than a hedge.** Returning a best guess with `confident=False` attached is almost the same object, and worse in practice: somebody reads `dominant` and ignores the flag. Returning `dominant=None` makes the absence unignorable and forces the caller to handle it — the same argument `ThreadRegistry.resolve` makes by raising instead of returning `None`. The note carries the count so the next action is obvious rather than being a refusal with no remedy.

**Extensions worth doing, none required by the grader.** Report the *second* place segment too, because the fix for first place often moves the bottleneck rather than removing it. Compare against a stored previous diagnosis so the tool can say "you fixed transcription and endpointing is now dominant, which is expected". And refuse a second way: if the top two are within noise of each other, say so instead of naming one, because a diagnosis that picks arbitrarily between two equal candidates spends somebody's afternoon on a coin flip.

---

## A closing note for the self-studying reader

This appendix's first version contained ten defects of one family: a report built before its callers, rendering identically whether they existed or not. Five of eight segments were unmeasurable, an underrun counter had no caller, a barge-in monitor could not fire, and a client that claimed to join one trace across two processes sent no header at all. None of it was caught by reading; all of it was caught by running the code and checking whether the printed parts reached the printed total.

That is the transferable habit, and it is worth more than anything specific to voice: **run your own instrument on your own work, and check its arithmetic, before you publish a number from it.**
