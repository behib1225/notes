# Appendix D — Voice, Realtime, and Multimodal Agents

**Read this if** you want Atlas to be something a person talks to — over a laptop microphone, a browser, or eventually a phone line — and you want to know why that is a harder engineering problem than bolting a transcriber onto the front of `/v1/chat` and a speech synthesiser onto the back. Read it also if you will never build a voice agent but want the sharpest available lesson in latency budgeting, because a conversation is the only interface that makes every millisecond audible.

**What it assumes from the core.** Chiefly Phase 15: the FastAPI service in `atlas/api/`, its `/v1/chat/stream` endpoint, its closed SSE event vocabulary, its per-subject thread registry and its span tracer. Everything built here is a **client** of that service. It also leans on Phase 10's human-in-the-loop gate and Phase 13's eval harness, each in a sentence rather than a re-teaching. If you have finished Phase 16 you have everything; if you finished Phase 15 and stopped, you have everything too.

**Nothing later depends on this appendix.** It adds no capability to Atlas, changes no file under `atlas/`, and can be deleted without breaking a test, an eval task or a `make` target. Appendix D is removable by construction, and §7.1 states the one place where that was nearly untrue and what was done instead.

The book's section template has nineteen slots. An appendix that does not grow the agent has no cumulative review (2), no capstone increment (11) and no case study (15), so those are omitted and the remaining numbers are unchanged. That is why §1 is followed by §3.

---

## 1. [core] Title and budget

| | |
|---|---|
| **Study hours** | 11 total — 5 read / 4 build / 2 assess |
| **Compute time** | ~25 min on the baseline laptop, dominated by downloading two speech models once and by your own speaking. Every assertion in this appendix runs on fixtures in under a second |
| **Tier A calls per sweep** | 0 required. The voice loop drives the Atlas API, and the API's engine is whatever tier you configured; the appendix's own eval tasks are Tier F |
| **Tier H calls** | 0 |
| **Cost** | $0.00. Hosted realtime APIs are taught as concept and comparison; nothing here requires one |
| **Repo snapshot** | `atlas_appendix_d.zip` |

The 16 GB laptop with no GPU is the target, and the honest statement of what it can do is §7.4, not a footnote. The short version: it can run voice-activity detection and a small streaming transcriber comfortably, it can run a small speech synthesiser faster than playback, and it cannot run a native speech-to-speech model.

**If local recognition turns out too slow to feel conversational**, in order: shorten your utterances, drop to the next model size down and re-measure, or run the client with `--text` and type for the rest of the exercise. The last is not a defeat — the ledger, the tracing and the entire latency breakdown still run, and the table will then show you a stack with transcription at zero, which is a legitimate baseline to compare against.

---

## 3. [core] Why this appendix matters

Sixteen phases built an agent that reads, retrieves, queries, calls tools, asks permission, remembers, traces itself and serves over HTTP. Every one of those phases assumed a **turn boundary that somebody else drew**. A user typed and pressed Enter. That keystroke is an oracle: it says "the input is complete, the answer may begin, and nothing more is coming until I decide."

Voice deletes the oracle, and four things fall out of the hole.

**Nobody tells you the turn ended.** A stream of audio arrives; whether the person has finished a sentence, paused mid-thought, or stopped to breathe is a guess your system makes, on every turn, from evidence that is genuinely ambiguous. The guess costs time whether or not it is right, and that time is added to every single answer before any model runs.

**The input is provisional.** Text arrives correct and final. Transcription arrives as a hypothesis that later words revise — the transcriber's best guess at second three is frequently not its guess at second four, because the later audio changed its mind about the earlier audio. An agent whose contract is "take a string, return an answer" has no way to express "here is a string that might change."

**The user can talk over you.** Not queue a message behind yours — *over* yours, while your sentence is physically in the air. The system now holds two beliefs that can disagree: what the assistant said, and what the user heard. Getting that wrong produces the single most characteristic voice-agent bug, in which the agent refers back to a sentence the user was never allowed to hear.

**Silence is not nothing.** In a chat window a spinner means "working". On a phone line, dead air means "the call dropped", and after about two of them a person hangs up. An agent that thinks for eight seconds in text is thoughtful; the same agent in voice is broken. That changes what the system owes the user *while* it works, which means the progress events Phase 15 invented for a web console stop being decoration and become the only thing keeping the line alive.

None of those four is a speech problem. They are all **control-loop** problems, and they are the reason this appendix exists: the moment your channel is continuous, the request-response shape that has carried Atlas since Phase 1 stops being free. The failure modes it produces are not in your text evals, they are not in your unit tests, and they do not show up in word error rate.

There is a second reason. Voice is where the safety work of Phases 10 and 14 gets tested for real. An approval dialogue in a browser is read at leisure; an approval spoken aloud is met with "yeah sure" before the consequence clause finishes, and the approval channel itself — speech recognition — has an error rate that your button did not have. Mishearing "no" as "go" is not a UX regression. Working out which of Atlas's gated actions may be approved by voice at all is a design decision with a defensible answer, and §6.6 gives it.

---

## 4. [core] Learning objectives

You will be able to:

1. **Draw** the realtime voice loop as eight named segments, and say which segments can overlap and which are strictly serial.
2. **Explain** why a streaming voice agent is not speech-to-text plus an agent plus text-to-speech, citing partial transcripts, endpointing, barge-in and in-flight tool calls as four independent reasons.
3. **Distinguish** a cascaded pipeline from a native speech-to-speech model, and state what each costs you in inspectability, gating and evaluation.
4. **Implement** an endpointing policy as a pure state machine, name each of its four parameters with the failure it prevents, and explain why its silence threshold is a latency you *chose* rather than one you measured.
5. **Specify**, for an interruption, exactly which state is discarded and which is kept — and justify why the assistant's committed transcript is what the speaker got through rather than what the model generated.
6. **Design** a tool-calling policy under a conversational deadline, including which Atlas tools may be approved by voice and which may not, with the reason.
7. **Build** a local push-to-talk client over the existing Atlas API that reuses its real routes and event names, and **instrument** it so every segment of the loop is timed by something that actually calls it.
8. **Read** a latency breakdown: check that its parts reach its total, identify the dominant segment on the path to first audio, and name the fix that applies to that segment and not to the others.
9. **Evaluate** a voice agent with the Phase 13 harness on task success, interruption handling, turn-taking errors and latency percentiles, and **state** what each metric misses.
10. **Diagnose** a realtime failure from the span tree Phase 15 already produces, distinguishing a barge-in that corrupted turn state from a tool call that blew the budget.
11. **Describe** at a high level what WebRTC and telephony add, and why a raw audio WebSocket that works at your desk fails on hotel Wi-Fi and on a phone line.
12. **State** the honest limitations: whom accent, noise and code-switching failures fall on, which latency floors cannot be designed away, and why voice cloning is a misuse surface rather than a feature.

---

## 5. [core] Prerequisites and quick recap

Unpack `atlas_phase_16.zip` (or use your own working copy) and confirm before touching anything:

```
make test-offline      # the suite is green before you add a client to it
make serve             # needs ATLAS_API_SECRET
```

`make serve` is the only prerequisite that matters, because **everything in this appendix is a client of the running Phase 15 service.** The five facts you need from it, quoted from `atlas/api/app.py` and `atlas/api/sse.py` rather than remembered:

* `POST /v1/chat/stream` takes `{"message": ..., "thread_id": ..., "route": ...}` and returns `text/event-stream`. `thread_id` absent means "open a new thread".
* The event vocabulary is closed: `start`, `plan`, `tool`, `token`, `approval`, `done`, `error`. `done` and `error` are the terminal pair, and a stream that ends in neither is a hung client.
* A `token` event carries `{"text": ..., "source": ...}`, and `source` is `"model"` when the tokens were teed live from the model and `"replay"` when the answer was chunked after the fact. Your voice client must read that field, for the same reason the web console renders it.
* A `tool` event carries `{"name": ..., "phase": "end", "ok": ...}` — **end only**. There is no start event, and §7.6 says what that costs you.
* Every endpoint resolves a principal from a bearer token first; there is no anonymous mode unless the app was built with `allow_anonymous=True`. `POST /v1/jobs` returns 202 with a poll URL, and `DELETE /v1/jobs/{id}` says in its response body that cancellation is cooperative. Both matter in §6.6.

From Phase 10 you need one sentence: an approval gate exists, the proposal is immutable and the decision is additive. From Phase 14: the egress filter strips outbound links from rendered answers. From Phase 15's tracer: a span names its parent by id, so a client in a different process can join the same trace by sending a `traceparent` header. From Phase 13: an eval task is a JSON object with `setup`, `checks` and `provenance`, and a check is structured data, never a string passed to `eval()`.

**Two paragraphs on digital audio, for the shaky.** A microphone produces a voltage; an analogue-to-digital converter samples it at a fixed rate and stores each sample as an integer. Three numbers describe the result, and every speech tool you touch will demand specific values for all three: the **sample rate** (samples per second; speech models overwhelmingly want 16,000, and telephone networks deliver 8,000, which is a different and worse signal rather than the same signal cheaper), the **sample width** (16-bit signed integers are the universal default, sometimes called `int16` or `PCM_S16LE`), and the **channel count** (one — stereo is for music, and every speech model will silently average or take the left channel anyway). "Raw PCM at 16 kHz, mono, 16-bit" is the lingua franca; anything else is a conversion waiting to be forgotten.

Audio is processed in **frames**, a frame being a fixed slice of time — 10, 20 or 30 milliseconds are the common sizes. Frames matter for one reason: they are the quantum of latency. A component that needs 30 ms of audio before it can do anything adds at least 30 ms, and a chain of four such components adds four of them before a single model has run. When you see `1536 samples at 16 kHz` in a voice-activity library's documentation, that is a 96 ms frame, and when you see 480, that is 30 ms. Appendix A has the fuller orientation, including why resampling is lossy and why you should capture at the rate your models want rather than converting later. You need nothing more than this to finish the appendix.

---

## 6. [core] Core concepts

### 6.1 [core] The loop, drawn

Eight segments, named, in the order they occur for one turn of a **cascaded** voice agent — the architecture you will build, in which separate components transcribe, think and speak.

```
     user speaks                                      user hears
         │                                                 ▲
         ▼                                                 │
  ┌─────────────┐                                  ┌──────────────┐
  │ 1  capture  │  mic → frames (16 kHz mono)      │ 8 first audio│
  └──────┬──────┘                                  │    out       │
         ▼                                         └──────▲───────┘
  ┌─────────────┐                                         │
  │ 2 endpoint- │  VAD per frame + a policy               │
  │    ing      │  "the turn ended"                ┌──────┴───────┐
  └──────┬──────┘                                  │ 7  speech    │
         ▼                                         │  synthesis   │
  ┌─────────────┐                                  └──────▲───────┘
  │ 3 transcrip-│  audio → text (partials, then           │
  │    tion     │  a final)                               │
  └──────┬──────┘                                  ┌──────┴───────┐
         ▼                                         │ 5 full agent │
  ┌─────────────┐        ┌──────────────┐          │   response   │
  │ 4 first     │───────▶│ 6  tool call │─────────▶│  (done)      │
  │ agent token │        │  (0..n)      │          └──────────────┘
  └─────────────┘        └──────────────┘
```

Segments 4, 5 and 6 are the Atlas request you already have: `start`, `plan`, `tool`, `token`, `done` are literally the events `/v1/chat/stream` emits, and the voice client's job is to turn them into sound and into timestamps. Segments 1, 2, 3, 7 and 8 are new, local, and none of them involves a large language model.

Two observations to carry through the rest of the appendix. First, **the user's experience is the time from their last word to segment 8**, not to segment 5. The full response can take as long as it likes provided speech starts promptly and never stalls. Second, **segment 2 is not compute**. It is a delay you configured. It will frequently be one of the largest items in your breakdown, and no faster model shortens it by a microsecond.

The alternative architecture, **native speech-to-speech**, collapses 3 through 7 into a single model that takes audio and emits audio. That is what the major hosted realtime APIs offer, and their design is worth understanding even though you will not run one locally; §6.2 compares them, and the VERSIONS.md rows in §19 name what currently exists and what it costs.

### 6.2 [core] Why this is not speech-to-text plus an agent

The tempting mental model is a sandwich: transcriber on the bottom, Atlas in the middle, synthesiser on top. It is wrong in four independent ways, and each one breaks a different thing you have already built.

**One: the input is provisional, and your agent's contract says it is not.** A streaming transcriber emits *partial hypotheses* — its current best guess at what has been said so far — and revises them as more audio arrives. "I want to cancel" can become "I want to cancel" plus three more words, and it can also become a different four words, because later audio disambiguated the earlier. A non-streaming transcriber avoids the problem by refusing to emit anything until the utterance is over, which is why batch transcription models feel accurate and are useless for conversation: they add the whole utterance duration to your budget.

So you choose. Wait for the final, and pay. Or act on a partial, and accept that you may have started work on a sentence the user did not say. The second is real — speculative execution on a stable prefix is a genuine technique — but notice what it demands of the agent: **the work must be discardable until it is committed**, which is precisely Phase 10's rule about node bodies, arrived at from a different direction. A node body runs an unbounded number of times while only its committed output runs once. In Phase 10 the cause was `interrupt()` re-executing its node; here the cause is a transcript that changed its mind. If any part of your agent performs a side effect before commitment, speculation is not available to you, and that is a property of your tool design rather than of your speech stack.

**Two: endpointing is a decision, and text never made it.** Covered in §6.4. It is enough here to notice that the sandwich model has no component that owns it: the transcriber does not know whether you are finished, and the agent is not listening.

**Three: barge-in makes the transcript a claim rather than a fact.** This is the deep one. When the user speaks over the agent, you stop the audio — easy, one flag — and then you must answer a question that has no analogue in text: *what did the assistant say?* It generated four sentences. The speaker emitted one and a half. The user heard one and a half.

If you append the generated text to the conversation history, the next turn's context contains three sentences the user never heard, and the model will refer back to them: "as I mentioned, the invoice is disputed" — about something nobody said out loud. Users experience this as the agent lying about the conversation, and it is unfalsifiable from the agent's side, because from the agent's side it *did* say it. The correct rule is that **the committed assistant message is what the speaker got through**, truncated at the word the audio reached, marked as truncated. §6.5 makes that precise and §8 is the trace of getting it wrong.

**Four: a tool call was in flight when they interrupted.** The user says "actually, no —" while `write_file` is executing. Phase 15 already told you the truth about this on the wire: cancellation is cooperative, work already running stops at its next checkpoint. Voice makes that sentence expensive rather than philosophical, because now the user believes they stopped it. What you do next depends entirely on a property Atlas already records — whether the tool was read-only — and §6.6 turns that into a policy.

**And the architectural fork.** A native speech-to-speech model dissolves problems one and three by construction: there is no transcript to revise because the model consumes audio directly, and it can hear you interrupt while it is speaking because it is listening and speaking at once. That is genuinely better conversation, and the published benchmarks for full-duplex behaviour exist precisely to measure it (Lin et al., *Full-Duplex-Bench*, ASRU 2025, and its 2026 successors — see §17). What it costs you is everything this book has spent sixteen phases building around text.

Ask where Phase 14's egress filter goes. Atlas strips outbound links from rendered answers because a poisoned document must not be able to exfiltrate through the answer channel. That filter operates on **text**. If the model emits audio directly, there is no text for it to operate on — the filter can inspect a transcription of the output, which is a lossy derivative produced after the audio was already generated, and possibly after it was already played. The same question applies to your approval gate (what exactly is being approved when the plan was never serialised?), to your eval suite (what does `p14-no-outbound-url-survives-the-answer` assert against?), and to your judge (Phase 13's rubric grades a sentence). None of those is unanswerable, and all of them are *unasked* by a team that adopts a native model because the demo sounded better.

This is the trade to hold in your head:

| | Cascade (what you will build) | Native speech-to-speech |
|---|---|---|
| Turn-taking, overlap, prosody | your problem, in your code | the model's, and it is better at it |
| Latency floor | sum of components, minus what you overlap | one model's response time |
| Inspectability | every stage has a text artefact you can log, gate and grade | the transcript is a derived artefact, not the thing the model used |
| Reuse of Phases 10–15 | total: it is the same agent | partial: gates and filters need re-siting |
| Cost and hardware | runs on your laptop for nothing | hosted, per minute, network required |
| Swapping a component | one module | a provider migration |

Neither is the right answer. The cascade is the right answer *for learning*, because every seam is visible, and it is the right answer for any system whose text-side controls are load-bearing.

> **Misconception.** *"Native speech-to-speech is just the cascade with the seams hidden."* No. A cascade cannot represent overlap at all: its transcriber owns the microphone during the user's turn and its synthesiser owns the speaker during the agent's turn, and the architecture has no state in which both are true. Full-duplex models are a different shape, not a tidier one.

> **Concept check CC-1.** Your voice agent uses a cascade. A user asks a question containing a spoken email address, and the answer must not contain it. Name the two places you could enforce that, and say which one Phase 14 already occupies.

### 6.3 [core] Latency budgets: proportions, not milliseconds

This appendix will not tell you how many milliseconds anything takes. Two reasons, and the second is the important one. The first is that any number I published would be a fact about my hardware; the second is that **the shape of your breakdown is the diagnosis, and the absolute numbers are not.** A stack where transcription is 15% of the budget and one where it is 60% need different work, and both can have the same total.

**The metric is time-to-first-audio**, measured from the user's last word — not from the end of endpointing, which would be measuring your own system's convenience, and not to the end of the answer, which the user does not wait for. Beside it sits a second metric with equal weight: **underruns**, the number of times the speaker ran out of audio mid-answer, and how much dead air that was. A stack optimised only for first-audio will happily start talking and then stall, which is worse than starting later, because a stall in the middle of a sentence reads as a fault rather than as thinking.

**Budget in proportions.** Take your measured time-to-first-audio and ask what fraction each segment holds. The healthy shape for a local cascade, stated as an ordering rather than as numbers:

* **Endpointing should be the largest single segment you control, and you should be able to say so out loud.** It is a policy, it is spent on every turn, and when it dominates the breakdown that is not a problem to fix — it is the system working as configured. The fix, if you want one, is a better turn-detection model, not a faster laptop.
* **Transcription should cost less than the hangover you chose.** If it costs more, the transcriber is too big for the machine, and every turn pays twice for the same decision. This is the single cleanest sizing rule in the appendix.
* **First agent token should dominate the compute**, because that is where the actual work is, and if it does not, something upstream is misconfigured.
* **Synthesis of the first sentence should be the smallest segment in the chain.** If it is not, you are synthesising the whole answer before playing any of it — the commonest self-inflicted wound in the list, and it is an architecture bug, not a model choice.

**Segments overlap, and the budget is only a sum if you built it as one.** Transcription can run on partials while the user is still speaking, so most of segment 3 can be hidden behind segment 1. Synthesis can start on the first complete sentence while the model is still generating the third, so most of segment 7 hides behind segment 5. A pipeline that waits for each stage to complete before starting the next has *chosen* to add its latencies, and no component in it is at fault.

**The human anchor.** Conversation analysis has measured the gap between turns in spontaneous speech across ten languages and found the modal gap clustered close to zero, on the order of a fifth of a second, with remarkable cross-linguistic stability (Stivers et al., PNAS, 2009). No local cascade will approach that, and it is still the right anchor, because it tells you what users are unconsciously comparing you against and why a delay that seems trivial on a stopwatch feels like a hesitation to a person.

Which fix applies to which segment — the table to consult when your breakdown comes back lopsided:

| Dominant segment | What actually fixes it | What does not |
|---|---|---|
| Endpointing | a semantic turn-detection model; a shorter hangover accepted with its interruption cost | a faster machine; a bigger model |
| Transcription | a smaller or streaming-native model; partials during speech | more RAM; a faster agent |
| First agent token | shorter prompt, fewer retrieved chunks, smaller model, prompt caching | anything in the speech stack |
| Full response | sentence-level streaming to the synthesiser | making the model terser, which changes the answer |
| Tool call | §6.6: narrate, defer, or precompute | waiting harder |
| Synthesis | stream sentence by sentence; a smaller voice model | a faster transcriber |
| First audio out | a smaller playback buffer, accepting underrun risk; a wired headset instead of Bluetooth | everything above |

> **Misconception.** *"We need a faster model."* Usually said when the breakdown has never been taken. In a local cascade the model is frequently not the dominant segment, and in the case where endpointing dominates, replacing the model changes the total by nothing at all.

> **Concept check CC-2.** Your time-to-first-audio is acceptable but users complain the agent "sounds like it's buffering". Which metric are they reporting, which segment produces it, and why would optimising time-to-first-audio make it worse?

### 6.4 [core] Turn-taking and endpointing

**Voice activity detection** (VAD) answers "is somebody speaking in this frame?" — a per-frame classification, cheap, and available as a tiny model that runs on one CPU thread. **Endpointing** answers "has this person finished their turn?", which is a different question that VAD cannot answer, because the evidence for "finished" and the evidence for "thinking" are the same evidence: silence.

Three errors, and they trade against each other along one axis:

* **Cut-off.** You decided the turn ended during a mid-sentence pause. The user is talking into a system that has stopped listening, and the agent answers half a question.
* **Dead air.** You waited too long. The user has finished, the agent is silent, and the user starts repeating themselves — which restarts the utterance and doubles the delay.
* **False trigger.** A cough, a door, a colleague. You began a turn that was never a turn, and depending on your loop you may have sent it to an agent that has tools.

The axis is your silence threshold, and this is the crucial framing: **it is not a constant, it is a bet about a distribution.** Pause length varies by speaker, by language, by whether the person is reading a number off a screen, by age, and by whether they are nervous. Any single value is wrong for somebody, and the people it is most wrong for are disproportionately those who pause more: non-native speakers, people who stammer, older users, and anyone reading an account number aloud. This is the first place in the appendix where a latency parameter is also a fairness parameter, and §7.10 returns to it.

The better answer, where you can afford it, is a **semantic end-of-turn model**: a small model that looks at the partial transcript as well as the silence and predicts whether the utterance is syntactically and pragmatically complete. "My account number is four two" plus 400 ms of silence is not a finished turn; "thanks, that's all" plus 400 ms is. These exist as open weights, the voice-agent frameworks ship them, and the VERSIONS.md rows in §19 name the current ones. You will not build one here; you will build the policy layer that either would plug into, and Assignment 1 builds the rule-based guard that approximates it.

Here is that layer, complete.

```python
# voice/endpoint.py
"""Endpointing: deciding that the person has stopped talking.

A voice agent cannot answer until it believes the turn is over, and nothing in
the audio says so. What arrives is a stream of frames and, per frame, a
probability that somebody is speaking. Turning that into "the turn ended at
frame 412" is a POLICY, and every millisecond of it is added to the latency of
every turn, whether or not any model is slow.

Four parameters, each with the failure it prevents.

  `speech_threshold` / `silence_threshold`   Two thresholds, not one, because a
      single threshold flaps: a probability hovering at the boundary produces
      speech_start / speech_end / speech_start within a quarter of a second,
      and the transcriber is handed three fragments of one word. Hysteresis --
      enter high, leave low -- is the standard fix and costs one number.

  `min_speech_ms`   A cough, a door, a chair. Below this, a burst is discarded
      rather than becoming an utterance, because an utterance becomes a request
      and a request may reach a tool.

  `hangover_ms`   How much silence ends a turn. THIS IS THE ONE THAT MATTERS.
      It is a latency you chose rather than one you measured: it is spent on
      every single turn, before the transcriber, the model or the speaker has
      done anything. Set it short and you interrupt anybody who pauses to
      think; set it long and every answer feels sluggish. It is also the number
      people try to fix by buying a faster model, which does not move it at
      all.

  `max_utterance_ms`   A hard cap. A VAD stuck at 0.9 -- a fan, a television,
      a held mic button -- otherwise produces a turn that never ends, and the
      agent looks hung while the audio buffer grows without limit.

The machine is deliberately PURE over probabilities: no audio, no model, no
clock. It takes a number per frame and returns an event or None. That is what
makes it testable from a hand-written list, and the reason this module has
tests while the microphone does not.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field

__all__ = [
    "EndpointEvent",
    "EndpointPolicy",
    "Endpointer",
    "DEFAULT_POLICY",
]

EndpointEvent = Literal["speech_start", "speech_end", "truncated"]
"""A closed vocabulary, for `atlas.api.sse`'s reason: a caller that switches on
these must be able to switch exhaustively. `truncated` is NOT a kind of
`speech_end` -- an utterance cut off by the cap is a different thing from one
that ended, and a loop that treats them alike will answer half a sentence
without ever saying that it did."""


class EndpointPolicy(BaseModel):
    """The four knobs, frozen, with the defaults stated rather than implied.

    Frozen because a policy that can be mutated mid-conversation is a policy
    whose recorded value did not apply to the turn you are looking at. Change
    it by constructing a new one, which is visible in a trace.
    """

    model_config = {"frozen": True, "extra": "forbid"}

    frame_ms: int = Field(default=30, gt=0)
    """Milliseconds per frame. 30 ms is not arbitrary: it is what the common
    small VAD models are trained on, and feeding a model frames of a length it
    never saw degrades it silently rather than loudly. Your VAD's own
    documentation states its supported frame sizes; see VERSIONS.md."""

    speech_threshold: float = Field(default=0.5, ge=0.0, le=1.0)
    silence_threshold: float = Field(default=0.35, ge=0.0, le=1.0)
    min_speech_ms: int = Field(default=120, ge=0)
    hangover_ms: int = Field(default=600, ge=0)
    max_utterance_ms: int = Field(default=20_000, gt=0)

    def model_post_init(self, _context: object) -> None:
        if self.silence_threshold > self.speech_threshold:
            raise ValueError(
                "silence_threshold must be <= speech_threshold. Inverted "
                "thresholds are not a stricter policy; they are a machine that "
                "can enter speech and leave it on the same frame."
            )

    @property
    def hangover_frames(self) -> int:
        return max(1, round(self.hangover_ms / self.frame_ms))

    @property
    def min_speech_frames(self) -> int:
        return max(1, round(self.min_speech_ms / self.frame_ms))

    @property
    def max_frames(self) -> int:
        return max(1, round(self.max_utterance_ms / self.frame_ms))


DEFAULT_POLICY = EndpointPolicy()


class Endpointer:
    """Frames in, events out. One utterance at a time; reusable across turns.

    `feed` returns at most one event per frame, which is what lets a caller
    write `if event == "speech_end": transcribe()` without a queue. The
    alternative -- returning a list -- invites a caller to handle the first
    element and drop the rest, and the dropped one is always `truncated`.
    """

    def __init__(self, policy: EndpointPolicy = DEFAULT_POLICY) -> None:
        self.policy = policy
        self._in_speech = False
        self._speech_frames = 0
        self._silence_frames = 0
        self._utterance_frames = 0
        self._started = False

    @property
    def in_utterance(self) -> bool:
        """True between `speech_start` and the event that ends the turn."""
        return self._started

    @property
    def trailing_silence_ms(self) -> int:
        """Silence accumulated since the last speech frame, in milliseconds.

        Exposed because it is a LATENCY SEGMENT the loop must be able to
        report. When a turn ends, this is exactly `hangover_ms` of dead air
        that the user experienced and no component spent computing, and a
        breakdown that hides it inside "transcription" sends you optimising
        the wrong thing.
        """
        return self._silence_frames * self.policy.frame_ms

    def feed(self, speech_probability: float) -> EndpointEvent | None:
        """Advance one frame. Pure in everything but `self`."""
        policy = self.policy
        if self._started:
            self._utterance_frames += 1

        if speech_probability >= policy.speech_threshold:
            self._speech_frames += 1
            self._silence_frames = 0
            if not self._in_speech and self._speech_frames >= policy.min_speech_frames:
                self._in_speech = True
                if not self._started:
                    self._started = True
                    self._utterance_frames = policy.min_speech_frames
                    return "speech_start"
        elif speech_probability <= policy.silence_threshold:
            # Below the LOWER threshold: unambiguously silence.
            if self._in_speech:
                self._silence_frames += 1
                if self._silence_frames >= policy.hangover_frames:
                    self._reset()
                    return "speech_end"
            else:
                # Never reached min_speech_ms: a cough, discarded.
                self._speech_frames = 0
        else:
            # BETWEEN the thresholds. Deliberately neither: hold the current
            # state. This band is the whole point of having two numbers, and a
            # machine that resolves it to silence has one threshold with extra
            # steps.
            if self._in_speech:
                self._silence_frames = 0

        if self._started and self._utterance_frames >= policy.max_frames:
            self._reset()
            return "truncated"
        return None

    def _reset(self) -> None:
        self._in_speech = False
        self._started = False
        self._speech_frames = 0
        self._silence_frames = 0
        self._utterance_frames = 0
```

Run against hand-written probability sequences at the default policy (30 ms frames, 600 ms hangover, 120 ms minimum speech), the machine produces: twenty frames of speech followed by silence → `speech_start` at frame 3 and `speech_end` at frame 39; two frames of speech followed by silence → nothing at all; a 450 ms mid-utterance pause → still one utterance, ending only after the real pause; probabilities parked in the hysteresis band → speech held, not flapped; a detector stuck high with a short cap → `truncated`, repeatedly, which is the honest behaviour for a microphone nobody released.

Two details worth pausing on. `_utterance_frames` is seeded to `min_speech_frames` at `speech_start` rather than to zero, because the utterance began when the speech began and not when the machine became confident about it. And `trailing_silence_ms` exists so the loop can *report* the hangover as its own line in the latency breakdown rather than burying it inside transcription — the segment you declared, printed beside the segments you measured.

> **Your turn (10 minutes).** Before reading §6.5: write down the probability sequence that would make this machine produce `speech_end` in the middle of a sentence, and then write down the one parameter change that prevents it and the cost of that change. Then check yourself by feeding both sequences to the machine. The answer is in the solutions document, but the exercise is the writing-down.

> **Concept check CC-3.** Why does `EndpointEvent` distinguish `truncated` from `speech_end`, when both mean "stop collecting audio and go transcribe"?

### 6.5 [core] Interruption: what to discard and what to keep

Barge-in has an easy half and a hard half, and almost every tutorial ships the easy half.

The easy half: when the user starts speaking while the agent is speaking, stop the speaker. One flag, one buffer flush. Note the prerequisite that catches people — **you must not detect your own voice as the user's**. Without acoustic echo cancellation, the microphone hears the loudspeaker, the VAD fires, and the agent interrupts itself one word into every answer. On a laptop with headphones this never happens and the bug is invisible; on a laptop with speakers it happens always. §6.7 says where echo cancellation comes from.

The hard half is the state ledger. At the moment of interruption, six things exist, and each needs an explicit decision:

| State | Decision | Why |
|---|---|---|
| Audio queued in the playback buffer | **discard** | it is the thing the user is asking you to stop |
| Generated text not yet spoken | **discard** | the user never heard it; keeping it is the lie in §6.2 |
| Utterances the speaker got through | **keep, and mark the turn truncated** | they are what both parties witnessed |
| Tool results already obtained | **keep** | they cost time and money and are still true |
| A tool call in flight | **§6.6** | depends entirely on whether it can be undone |
| The thread id and trace id | **keep** | the conversation did not end; one turn did |

The rule that falls out: **the committed assistant message is every utterance the speaker got through**, with the last one truncated at the word the audio reached, recorded in a form that says so. When the next turn's context reads `assistant: "The invoice from March is disputed —" [interrupted]`, the model has what it needs to behave sensibly; when it reads the full four sentences, the model has been handed a false premise that it will confidently build on.

Two traps inside that sentence, both of which this appendix fell into and both of which now have a test.

*The prefix is not the last sentence.* If the cut arrives during sentence three, sentences one and two were heard in full and belong in the record. Committing only the prefix of the current utterance erases them, and the model then behaves as though it never said things it did say.

*A cut inside the first word commits nothing.* Audio stops mid-phoneme; text does not have to. Committing `Revenu` puts a token in the transcript that nobody said and no tokenizer expects. The turn is still recorded and still marked truncated — the record says "cut off before a word got out", which is true and useful.

This is a *representation* decision, not a speech decision, and it is the same shape as Phase 10's finding that the framework's approval gate destroyed the record of what was overseen. There the record was rewritten to show a proposal that was never made; here it would be rewritten to show a sentence that was never heard. In both cases the fix is the same: the record is append-only and the modification is a new, marked entry.

> **Misconception.** *"Barge-in means stopping the audio."* Stopping the audio is the part the user can see working. The part that determines whether the next three turns make sense is what you wrote down about the turn you stopped.

> **Concept check CC-4.** An interruption arrives after the agent has spoken two of five generated sentences. Give the assistant message you commit to the thread, and say what the model would do differently if you committed all five.

### 6.6 [core] Tool calls under a conversational deadline

A tool call has no idea it is in a conversation. `query_db` takes as long as it takes; a web search takes longer; Phase 11's research fan-out takes much longer. In text, that is a spinner. In voice, it is dead air, and dead air past a couple of seconds is indistinguishable from a dropped call.

There are exactly three honest strategies, and one dishonest one that is extremely popular.

**Narrate, then work.** Speak a real sentence that tells the user what you are about to do, *then* make the call. "Let me look that up in the sales database" is not filler: it is the `plan` event, spoken. This is the highest-value reuse of Phase 15's event vocabulary in the whole appendix — the events were designed so a person could see a misread question at second one rather than at minute three. The constraint that makes it honest: the sentence must be derived from the `plan` or `tool` event rather than drawn from a list of soothing noises.

**Defer to a job.** Atlas already has this: `POST /v1/jobs` returns 202 with a poll URL, and the conversation continues. "That's a big one — I'll dig through the quarterly reports and tell you when I have it" is a legitimate answer for work that cannot fit in a pause. The discipline it requires is that you must actually deliver.

**Precompute, for read-only tools only.** Start the likely lookup during the user's pause, on the partial transcript, and throw it away if you guessed wrong. Eligibility is exactly `spec.read_only`, the same flag Phase 10 used to grant approval exemption, retry eligibility and cache eligibility from one unverified boolean — and invariant 66's warning applies unchanged and with more force. A mislabelled tool here does not merely bypass a gate; it executes speculatively, on a sentence the user had not finished saying.

**The dishonest one** is the filler phrase disconnected from the work: "Sure, one moment!" emitted before the agent has decided anything, or worse, while the tool call is failing. It buys you two seconds the first time and costs the user's trust the third time.

**Approval by voice is a special case, and it is the sharpest safety point in the appendix.** Phase 10 gates writes behind a human decision and requires every gated tool to have a consequence renderer. A voice client turns that into a spoken consequence and a spoken answer — and the spoken answer arrives through a channel with a *measured error rate*, which the button did not have. Three consequences:

1. The consequence must be spoken **in full, before** the system will accept a decision, and the decision must not be accepted from audio that overlapped the consequence. An approval given before the user heard what they were approving is Phase 10's rubber stamp with a microphone on it.
2. "Yes" and "no" are short, acoustically weak, and confusable — and the errors are *asymmetric*, because a false "yes" performs an action and a false "no" merely asks again. Require a higher-entropy confirmation for anything gated, and treat a non-match as a repeat rather than as a refusal.
3. **Irreversible actions should not be approvable by voice alone.** `IRREVERSIBLE` already names them in Phase 10. The right voice behaviour is to describe the action, decline to take the approval through the audio channel, and hand off — to the console, to a link, to a confirmation in another medium. This costs a demo moment and buys the one property the audio channel cannot provide: an approval whose evidence is not a transcription.

**What Atlas's client actually implements, stated rather than implied.** Rule 1 only, and half of it: on an `approval` event it speaks the consequence and sets `approval_required` on the turn record; it cannot *collect* a decision, because Phase 15's API has no approval-response endpoint. Closing that gap is one additive `POST /v1/threads/{id}/approvals` plus a resume path through the checkpointer — named here and not built, because inventing the endpoint would make this appendix a change to the core. A client that silently carried on instead of recording the gap would be manufacturing exactly the consent this section is about.

> **Concept check CC-5.** Atlas's `read_only` flag governs approval exemption, retry, caching and now speculative execution. State the failure a mislabelled tool causes in each of the four, and say which one is worst in a voice loop and why.

### 6.7 [extended] Telephony and WebRTC, at a high level

You will build over a local microphone and the loopback HTTP service, which means audio never touches a network. Everything in this section is what changes when it does.

**WebRTC exists because networks are hostile.** A raw WebSocket carrying PCM works beautifully on your desk and degrades in specific, user-visible ways on real connections: packets arrive late, out of order, or not at all, and nothing in TCP-over-WebSocket helps, because retransmitting audio that should have played 300 ms ago is worse than dropping it. WebRTC bundles the countermeasures that decades of telephony engineering produced — a **jitter buffer** that trades a little latency for smooth playback, **packet loss concealment**, **adaptive bitrate**, **NAT traversal**, and — the one that matters most for §6.5 — **acoustic echo cancellation**, which is why a browser-based voice agent can use laptop speakers and a hand-rolled Python client generally cannot. The open frameworks are either WebRTC-native media servers with agent SDKs layered on, or transport-agnostic pipeline frameworks you attach one to; the current names and licences are VERSIONS.md rows.

**Telephony is a different signal, not a different pipe.** A phone call delivers narrowband audio — half the sample rate of what your speech models were trained on, through codecs designed for intelligibility rather than fidelity. Word error rates measured on clean 16 kHz audio do not transfer, and the gap is largest for exactly the speakers who were already worst served. Phone calls also carry **DTMF** keypad tones, worth supporting precisely because they are the one input channel with no recognition error at all: "press 1 to confirm" is not a retreat from voice, it is the high-reliability path for the decisions §6.6 said should not go through the microphone. Connectivity arrives either through a provider's real-time media streaming product or through **SIP**, which the major realtime APIs now accept directly.

**Where Atlas's boundary sits.** The transport terminates in the client. Atlas continues to speak HTTP and SSE, authenticates a bearer token, and knows nothing about audio — which is why Appendix D adds no route to `atlas/api/`. If you later put a media server in front, the thing that changes is which process holds the microphone; the thing that does not change is that the agent receives a string and returns events. That separation is invariant 60's argument arriving one layer further out.

> **Concept check CC-6.** Your laptop client works perfectly with headphones and interrupts itself constantly with speakers. Name the component that is missing, say which of the eight segments it belongs to, and explain why the bug is invisible in your latency breakdown.

---

## 7. [core] Hands-on: a local push-to-talk voice front end over the Atlas API

### 7.1 [core] What you are building, and the one thing that nearly changed the core

A new top-level package, `voice/`, sibling to `atlas/`. Nothing under `atlas/` is touched. The client talks to the running service over HTTP, authenticates with a bearer token, and consumes the SSE vocabulary that already exists.

```
voice/
  endpoint.py            the policy layer          (§6.4)
  timing.py              the measurement harness   (§7.2)
  speech.py              ASR/TTS protocols, fixtures and adapters (§7.4)
  atlas_client.py        the wire                  (§7.5)
  loop.py                the turn loop and ledger  (§7.6)
  cli.py                 the only file with a microphone (§7.3)
  evalscore.py           the eval entrypoint       (§7.8)
  run_appendix_evals.py  a twenty-line driver      (§7.8)
  tests/                 twenty-seven offline tests
tests/hidden/test_appendix_d_a1.py, _a2.py   the assignment graders
evals/tasks/appendix_d.json                  four tasks in the Phase 13 format
```

**The one thing that nearly changed the core.** The obvious place for the tests is `tests/`. Doing that turned `tests/test_demo_phase16.py` red: Phase 16 generates `docs/ENGINEERING_SUMMARY.md` from a `--collect-only` count, and a test pins the generated table against the file. New tests moved the count and the appendix broke a core assertion *by existing*. The fix is not to regenerate the summary — that edits the core on the appendix's behalf, and the number would then be wrong for every reader who never installed this. The fix is that the appendix's own tests live in `voice/tests/`, outside the collection path.

The *hidden* graders are a different case and stay in `tests/hidden/`, because `scripts/phase16_results.py` already passes `--ignore=tests/hidden` to its count. They are picked up by `make grade-all` and skip themselves until you start the assignment. The commands:

```
ATLAS_TIER=F PYTHONPATH=. python -m pytest voice/tests -q                      # 27 passed
ATLAS_TIER=F PYTHONPATH=. python -m pytest tests/hidden/test_appendix_d_a1.py -q
ATLAS_TIER=F PYTHONPATH=. python voice/run_appendix_evals.py --trials 3        # 4 tasks
```

There is no new `make` target, because the Makefile is core and this appendix does not edit it. With `voice/` present, `make test-offline` reports **1,687 passed, 12 skipped** — the same figures `VERSIONS.md` records for Phase 16, which is the removability claim made checkable rather than asserted.

**A note on how this appendix was built, because it is the lesson.** The first version of these files shipped a latency report whose callers did not exist: five of the eight segments could never be measured, `underruns` had no caller at all, and the barge-in monitor in the CLI could not fire. The report rendered identically either way. Everything below is the second version, and each fix carries the defect it repairs in its docstring, because that is more useful to you than a clean file.

### 7.2 [core] Step 1 — the measurement harness, first

Build the instrument before the thing it measures. Phase 13's finding was that a third of recent defects were in the measuring instrument; building it first at least means you look at it. Note `record(..., accumulate=False)`, `has_anchor`, and the fact that `underrun` takes a *gap* rather than being a bare counter — all three exist because of a specific defect named in the docstrings.

```python
# voice/timing.py
"""Timing the voice loop: eight segments, measured, declared, or absent.

The point of this appendix is the BREAKDOWN, so the breakdown gets a module
rather than a stopwatch scattered through the loop. Three commitments.

**A segment is measured or DECLARED, never both, and the report says which.**
Endpointing is not compute: it is a silence you configured, spent on every
turn. Printing it in the same column as transcription invites somebody to
"optimise" it by buying a faster machine. `declare()` records it and the
renderer marks it `chosen`.

**The anchor is the user's last word, not the start of processing.** Time to
first audio is measured from the moment the person stopped talking, because
that is when they started waiting. Measuring from the end of endpointing
produces a number that improves when you make the user wait longer.

**No second observability mechanism.** Segments become events on the ambient
Phase 15 span when there is one, and the percentile arithmetic is imported
from `atlas.obs.metrics` rather than rewritten. A voice client with its own
private latency store is a dashboard nobody joins to a trace.
"""

from __future__ import annotations

import time
from contextlib import contextmanager
from typing import Any, Callable, Iterator, Literal, Sequence

from pydantic import BaseModel, Field

from atlas.obs.metrics import percentile

__all__ = [
    "Segment",
    "SEGMENTS",
    "ANCHORS",
    "TurnTiming",
    "LoopTimer",
    "render_breakdown",
]

Segment = Literal[
    "capture",              # the user speaking; not latency, but it sets scale
    "endpointing",          # declared: the silence policy, spent every turn
    "transcription",        # audio -> text
    "first_agent_token",    # request sent -> first `token` event
    "full_agent_response",  # request sent -> `done`
    "tool_call",            # sum of `tool` events, which may overlap the above
    "speech_synthesis",     # text -> audio, SUMMED over the turn's utterances
    "first_audio_out",      # the device's own latency, if it reports one
]
SEGMENTS: tuple[Segment, ...] = (
    "capture",
    "endpointing",
    "transcription",
    "first_agent_token",
    "full_agent_response",
    "tool_call",
    "speech_synthesis",
    "first_audio_out",
)

ANCHORS: tuple[str, ...] = ("user_last_word", "first_audio")
"""Instants, not durations. The interval between them is the number that
decides whether this feels like a conversation."""


class TurnTiming(BaseModel):
    """One turn's segments, in milliseconds. Absent is absent, never 0.0.

    A missing segment is left OUT of the dict rather than defaulted to zero,
    for `Span.duration_ms`'s reason: a zero that means "did not happen" and a
    zero that means "was instantaneous" average into the same misleading p50.
    """

    turn: int
    segments: dict[str, float] = Field(default_factory=dict)
    declared: list[str] = Field(default_factory=list)
    anchors: dict[str, float] = Field(default_factory=dict)
    interrupted: bool = False
    underruns: int = 0
    underrun_ms: float = 0.0

    @property
    def time_to_first_audio_ms(self) -> float | None:
        """From the user's last word to the first sound. None if unanchored."""
        if not {"user_last_word", "first_audio"} <= set(self.anchors):
            return None
        return round(
            (self.anchors["first_audio"] - self.anchors["user_last_word"]) * 1000.0, 3
        )


class LoopTimer:
    """One turn's clock. Injected `now`, so tests do not sleep.

    `time.perf_counter` rather than `time.time`: a monotonic clock cannot go
    backwards when NTP corrects the system clock mid-call, and a negative
    segment duration in a latency report is the kind of thing that gets
    explained as "a glitch" for a year.
    """

    def __init__(
        self,
        *,
        turn: int = 0,
        now: Callable[[], float] = time.perf_counter,
        tracer: Any = None,
    ) -> None:
        self.turn = turn
        self._now = now
        self._tracer = tracer
        self._segments: dict[str, float] = {}
        self._declared: list[str] = []
        self._anchors: dict[str, float] = {}
        self._open: set[str] = set()
        self.underruns = 0
        self.underrun_ms = 0.0
        self.interrupted = False

    @contextmanager
    def segment(self, name: Segment) -> Iterator[None]:
        """Time a segment on every path, including the raising one.

        Closing in `finally` is Phase 15's rule with a new noun: a segment that
        only records on success measures the turns that did not need measuring.
        A turn that raised inside transcription still spent that time, and the
        user still waited for it.
        """
        if name not in SEGMENTS:
            raise ValueError(f"unknown segment {name!r}; SEGMENTS is closed")
        started = self._now()
        self._open.add(name)
        try:
            yield
        finally:
            elapsed = (self._now() - started) * 1000.0
            self._segments[name] = round(self._segments.get(name, 0.0) + elapsed, 3)
            self._open.discard(name)
            self._event(name, elapsed)

    def record(self, name: Segment, ms: float, *, accumulate: bool = True) -> None:
        """Record a MEASURED duration whose start and end are not a block.

        `first_agent_token` is the case: it starts when the request is written
        and ends inside an event loop several frames away. A context manager
        there would have to be entered and exited by hand across a generator
        boundary, and the version of this file that did so leaked an open
        segment on the error path -- which the renderer then reported as "no
        samples", i.e. as a measurement nobody took.

        `accumulate=False` REPLACES the value instead of adding to it, which
        is what a running total needs: the tool segment is measured as "from
        the plan to the latest tool event", so each new observation supersedes
        the last rather than being added to it. Adding would report the sum of
        a sequence of prefixes, which is a number with no meaning at all.
        """
        if name not in SEGMENTS:
            raise ValueError(f"unknown segment {name!r}; SEGMENTS is closed")
        base = self._segments.get(name, 0.0) if accumulate else 0.0
        self._segments[name] = round(base + float(ms), 3)
        self._event(name, ms)

    def declare(self, name: Segment, ms: float) -> None:
        """Record a segment that was CONFIGURED rather than measured."""
        if name not in SEGMENTS:
            raise ValueError(f"unknown segment {name!r}; SEGMENTS is closed")
        self._segments[name] = round(float(ms), 3)
        if name not in self._declared:
            self._declared.append(name)
        self._event(name, ms, chosen=True)

    def anchor(self, name: str, *, offset_ms: float = 0.0) -> float:
        """Stamp an instant, optionally BACKDATED. Returns it.

        `offset_ms` exists for one case and it is not a convenience: the
        endpointer cannot tell you the user stopped talking until the hangover
        has already elapsed, so `now()` at that moment is not when the user
        stopped -- it is `hangover_ms` later. Anchoring at `now()` measures
        time-to-first-audio from a moment the user did not experience, and it
        produces a latency report that IMPROVES when you make the person wait
        longer. Backdating is the honest anchor and it costs one subtraction.
        """
        if name not in ANCHORS:
            raise ValueError(f"unknown anchor {name!r}; ANCHORS is closed")
        at = self._now() - (offset_ms / 1000.0)
        self._anchors[name] = at
        return at

    def has_anchor(self, name: str) -> bool:
        """Whether `name` has already been stamped, so a later caller can
        decline to overwrite it. The microphone loop knows when the user
        stopped talking; `VoiceSession` only knows when it was told."""
        return name in self._anchors

    def underrun(self, gap_ms: float) -> None:
        """The speaker ran dry mid-answer: counted, and the gap kept.

        Called by `VoiceSession` when the next utterance is handed to the
        speaker AFTER the previous one finished playing -- i.e. when there was
        a silence the user heard in the middle of an answer. Taking the gap as
        an argument rather than being a bare counter means the report can
        distinguish "stalled by 30 ms twice" from "stalled by two seconds",
        which are a rounding error and an outage.
        """
        self.underruns += 1
        self.underrun_ms = round(self.underrun_ms + float(gap_ms), 3)

    def _event(self, name: str, ms: float, *, chosen: bool = False) -> None:
        if self._tracer is None:
            return
        self._tracer.event(
            f"voice.{name}", duration_ms=round(float(ms), 3), chosen=chosen
        )

    def finish(self) -> TurnTiming:
        """Close the turn. Open segments are DROPPED and reported by absence."""
        return TurnTiming(
            turn=self.turn,
            segments=dict(self._segments),
            declared=list(self._declared),
            anchors=dict(self._anchors),
            interrupted=self.interrupted,
            underruns=self.underruns,
            underrun_ms=self.underrun_ms,
        )


def render_breakdown(timings: Sequence[TurnTiming]) -> str:
    """The table this appendix refuses to fill in for you. Pure.

    Percentiles come from `atlas.obs.metrics.percentile`, and `n` is printed
    beside every one of them for the same reason Phase 15 prints it: at four
    turns a p95 is the maximum wearing a hat. A segment with no samples prints
    `____`, which is a measurement you have not taken rather than a zero.
    """
    lines = [
        f"{'segment':<20s} {'n':>3s} {'p50 ms':>9s} {'p95 ms':>9s} "
        f"{'share':>7s}  source"
    ]
    totals = [t.time_to_first_audio_ms for t in timings]
    measured_totals = [t for t in totals if t is not None]
    reference = percentile(measured_totals, 0.5) if measured_totals else None

    for name in SEGMENTS:
        values = [t.segments[name] for t in timings if name in t.segments]
        chosen = any(name in t.declared for t in timings)
        source = "chosen" if chosen else "measured"
        if not values:
            lines.append(
                f"{name:<20s} {0:>3d} {'____':>9s} {'____':>9s} {'____':>7s}  "
                f"{source} (no samples)"
            )
            continue
        p50 = percentile(values, 0.5)
        p95 = percentile(values, 0.95)
        share = "—" if not reference else f"{100.0 * p50 / reference:5.1f}%"
        lines.append(
            f"{name:<20s} {len(values):>3d} {p50:>9.1f} {p95:>9.1f} {share:>7s}  "
            f"{source}"
        )

    lines.append("")
    if measured_totals:
        lines.append(
            f"time to first audio   n={len(measured_totals):<3d} "
            f"p50={percentile(measured_totals, 0.5):.1f}ms "
            f"p95={percentile(measured_totals, 0.95):.1f}ms "
            f"max={max(measured_totals):.1f}ms"
        )
    else:
        lines.append("time to first audio   n=0    p50=____  p95=____  max=____")
    stalls = sum(t.underruns for t in timings)
    lines.append(
        f"interrupted turns {sum(1 for t in timings if t.interrupted)}"
        f"/{len(timings)}   underruns {stalls}"
        + (f" ({sum(t.underrun_ms for t in timings):.0f} ms of dead air)" if stalls else "")
    )
    lines.append(
        "shares are of p50 time-to-first-audio and do not sum to 100%: "
        "segments overlap, and `full_agent_response` continues after it."
    )
    return "\n".join(lines)
```

The backdated anchor is not a nicety. The first version anchored at `now()`, which made the 600 ms hangover free — the breakdown got *better* as the policy got slower. That defect is the provenance of one of the four eval tasks in §7.8.

### 7.3 [core] Step 2 — capture, detection, endpointing, and the client that runs them

Capture is `sounddevice.InputStream(samplerate=16_000, channels=1, dtype="int16")` and a loop reading `frame_samples = 16_000 * frame_ms / 1000` samples at a time. Detection is a small ONNX voice-activity model behind a one-function adapter, named in the VERSIONS.md rows in §19 — a few megabytes, an ordinary CPU, well under a millisecond per frame. The policy is §6.4's `Endpointer`.

Three things in this file are there because they were once wrong, and they are the three worth reading closely: the timer is created **before** the microphone opens and handed to `ask`, so capture and transcription are inside the measured region; barge-in goes through **one** `BargeInMonitor` for the life of the process, because a fresh endpointer per frame can never confirm speech and so can never interrupt anything; and a **pre-roll buffer** keeps the audio from before speech was confirmed, because otherwise the first syllable of every utterance is discarded — an accuracy fix and, per §7.10, a fairness one.

```python
# voice/cli.py
"""Push to talk, over the running Atlas service. `python voice/cli.py`.

# not executed during authoring; verified in companion-repo CI
This is the only file in the appendix that touches a microphone, and it is
deliberately the thinnest: everything decidable -- the endpointing policy, the
barge-in monitor, the ledger, the timing -- lives in modules a test can reach
without a device. What is left is plumbing and a `while True`.

PUSH TO TALK rather than always-on. An always-listening client on a laptop
with speakers hears itself (§6.5), records your colleagues, and has no consent
story; a turn you start on purpose is an auditable signal that this utterance
was meant for the agent. §7.10 and Appendix E say more about the second
reason, which is the more important one.

**Where the timer is created matters.** `LoopTimer` is built HERE, before the
microphone opens, and handed to `VoiceSession.ask`. Capture and transcription
happen in this file; a timer created inside `ask` cannot see either, and the
first version of this appendix shipped exactly that -- a breakdown with two
permanently empty rows, in the appendix about the breakdown.
"""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path
from typing import Any

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from atlas.obs import semconv  # noqa: E402
from atlas.obs.spans import Tracer, use_tracer  # noqa: E402
from voice.endpoint import DEFAULT_POLICY, Endpointer  # noqa: E402
from voice.loop import BargeInMonitor, VoiceSession  # noqa: E402
from voice.speech import AdaptedSpeaker, AdaptedTranscriber  # noqa: E402
from voice.timing import render_breakdown  # noqa: E402


def build_backends(args: argparse.Namespace) -> tuple[Any, Any, Any]:
    """Bind YOUR packages to the three protocols. The only place they appear.

    # not executed during authoring; verified in companion-repo CI
    Three bindings, each a few lines, each naming a model id that is a
    current-state fact (VERSIONS.md) and must not be hard-coded:

        vad(frame_float32) -> probability
        recognise(pcm_float32) -> text
        synthesise(text) -> (samples, sample_rate);  play(samples, rate)

    They are gathered in one function so that swapping a model is one edit in
    one place, and so that the rest of this file cannot accidentally depend on
    which package you chose.
    """
    raise NotImplementedError(
        "Bind the packages named in VERSIONS.md here and return "
        "(vad, transcriber, speaker). §7.4 gives the shape of all three; the "
        "companion snapshot ships one working binding per model family."
    )


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8000")
    parser.add_argument("--asr-model", default="", help="see VERSIONS.md")
    parser.add_argument("--tts-voice", default="", help="see VERSIONS.md")
    parser.add_argument("--hangover-ms", type=int, default=DEFAULT_POLICY.hangover_ms)
    parser.add_argument(
        "--text",
        action="store_true",
        help="type instead of speaking: the fallback when local recognition "
             "is too slow to feel like a conversation. Every other part of "
             "the loop, including the ledger and the breakdown, still runs.",
    )
    args = parser.parse_args(argv)

    token = os.environ.get("ATLAS_VOICE_TOKEN")
    if not token:
        print(
            "Set ATLAS_VOICE_TOKEN to a bearer token for this service. There "
            "is no anonymous mode: /v1/chat resolves a principal first, and "
            "every thread is filed under it."
        )
        return 2

    import httpx  # noqa: PLC0415

    from voice.atlas_client import AtlasVoiceClient  # noqa: PLC0415

    policy = DEFAULT_POLICY.model_copy(update={"hangover_ms": args.hangover_ms})
    frame_samples = int(16_000 * policy.frame_ms / 1000)
    preroll_frames = 5  # ~150 ms kept BEFORE speech is confirmed; see below

    http = httpx.Client(base_url=args.url, timeout=httpx.Timeout(60.0, read=None))
    client = AtlasVoiceClient(http, token=token, base_url="")

    # ONE tracer for the process, published for the duration of each turn, so
    # `AtlasVoiceClient` finds a traceparent and the service's spans become
    # children of this client's. Without it the request carries no header and
    # §8's single tree is two trees -- which is what the first version shipped.
    tracer = Tracer(service_name="atlas-voice")

    stream = None
    if args.text:
        vad = transcriber = None
        speaker: Any = _TextSpeaker()
    else:
        import sounddevice  # noqa: PLC0415 -- the only device dependency

        vad, transcriber, speaker = build_backends(args)
        stream = sounddevice.InputStream(
            samplerate=16_000, channels=1, dtype="int16"
        )
        stream.start()

    monitor = BargeInMonitor(lambda: _probability(stream, vad, frame_samples), policy)
    session = VoiceSession(
        client, speaker, monitor=monitor, tracer=tracer,
        endpointing_ms=policy.hangover_ms,
    )
    endpointer = Endpointer(policy)

    def record_utterance(timer) -> bytes:
        """Frames until the endpointer ends the turn. Keeps a pre-roll.

        The pre-roll matters more than it looks: speech is confirmed only
        after `min_speech_ms`, so without a rolling buffer the first syllable
        of every utterance is thrown away. Clipped onsets degrade recognition,
        and they degrade it most for the speakers §7.10 says are already
        served worst -- which makes a five-frame `deque` a fairness fix as
        well as an accuracy one.
        """
        from collections import deque  # noqa: PLC0415

        endpointer.__init__(policy)  # one utterance per turn; no leaked state
        pre = deque(maxlen=preroll_frames)
        chunks: list[bytes] = []
        with timer.segment("capture"):
            while True:
                frame, _overflow = stream.read(frame_samples)
                event = endpointer.feed(_probability_of(frame, vad))
                if endpointer.in_utterance:
                    if not chunks:
                        chunks.extend(pre)
                    chunks.append(bytes(frame))
                else:
                    pre.append(bytes(frame))
                if event in ("speech_end", "truncated"):
                    if event == "truncated":
                        print("  (utterance hit the length cap; answering what I have)")
                    return b"".join(chunks)

    print("Speak when ready; 'q' to quit.  (--text to type instead)")
    try:
        while True:
            timer = session.new_timer()
            if args.text:
                text = input("you> ").strip()
                # Typed input has no hangover and no capture to charge for:
                # the user "stopped talking" when they pressed Enter.
                timer.anchor("user_last_word")
                timer.declare("endpointing", 0.0)
            else:
                audio = record_utterance(timer)
                # Anchored HERE, backdated by the hangover, because this is
                # the moment the endpointer fired and the user stopped
                # speaking `hangover_ms` before it. Transcription is then
                # charged to the user's wait, which is where it belongs.
                timer.anchor("user_last_word", offset_ms=policy.hangover_ms)
                timer.declare("endpointing", policy.hangover_ms)
                with timer.segment("transcription"):
                    text = transcriber.transcribe(audio).text
                print(f"you> {text}")
            if text.lower() in {"q", "quit", ""}:
                break
            with use_tracer(tracer):
                with tracer.start(
                    "voice.turn", kind="client",
                    attributes={semconv.ATLAS_ROUTE: "chat"},
                ):
                    record = session.ask(text, timer=timer)
            print(f"  [{record.route}] {record.spoken}")
            if record.approval_required:
                print("  (this needs an approval the voice channel cannot take; "
                      "open the console)")
            if record.interrupted:
                print(f"  (interrupted; {record.discarded_chars} chars discarded)")
            if record.terminal_event not in ("done", "interrupted"):
                print(f"  (stream ended with {record.terminal_event or 'nothing'})")
    finally:
        if stream is not None:
            stream.close()
    print()
    print(render_breakdown(session.timings))
    return 0


def _probability_of(frame, vad) -> float:
    """One frame -> speech probability, or 0.0 in --text mode."""
    return 0.0 if vad is None else float(vad(frame))


def _probability(stream, vad, frame_samples: int) -> float:
    """Read one frame for the barge-in monitor. Never transcribes.

    Deciding to STOP SPEAKING must not wait on a model, or the interruption
    lands after the sentence it was meant to stop.
    """
    if stream is None or vad is None:
        return 0.0
    frame, _overflow = stream.read(frame_samples)
    return float(vad(frame))


class _TextSpeaker:
    """The --text mode speaker: prints, and reports its own timing honestly."""

    device_latency_ms = 0.0

    def __init__(self) -> None:
        self.current = None

    def say(self, text: str):
        import time  # noqa: PLC0415

        from voice.speech import SpeechHandle  # noqa: PLC0415

        print(f"atlas> {text}")
        self.current = SpeechHandle(
            text=text, started_s=time.perf_counter(), chars_per_second=1e9
        )
        return self.current

    def stop(self):
        handle, self.current = self.current, None
        return handle


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
```

### 7.4 [core] Step 3 — transcription and synthesis, and what a laptop with no GPU can do

`voice/speech.py` defines two protocols, two fixture backends and two real adapters. The protocols are one method each. The fixtures are the Tier F of speech — no test in this appendix may depend on a microphone or a model. The adapters take *your* callable and do the part people get wrong: sample-format conversion, refusing a rate the model was not trained on, and deriving the speaking rate from the audio rather than from a guessed words-per-minute constant.

```python
# voice/speech.py
"""Speech in and speech out: two protocols, two fixture backends, two notes.

The protocols are narrow on purpose. A `Transcriber` turns audio into a
`Transcript`; a `Speaker` turns text into a `SpeechHandle` that can be stopped
and can say how much of itself was heard. Everything the loop needs is in
those two sentences, which is why swapping the local models for hosted ones is
a constructor argument rather than a rewrite.

The fixture backends are the Tier F of speech, and they exist for the reason
`FakeLLMClient` exists: **no test in this appendix may depend on a
microphone, a speaker, or a speech model.** A scripted transcriber proves that
the loop routes a transcript correctly, terminates on every path, and commits
the right text after an interruption. It proves nothing whatever about whether
a model would have produced that transcript from that audio -- that is a
measurement, it lives in §7.7, and it is not a test.

`FixtureSpeaker` simulates playback against an injected clock at a configured
speaking rate. That is what makes barge-in testable: "the user interrupts
after 40 characters" becomes a deterministic fact rather than a race.
"""

from __future__ import annotations

import time
from typing import Any, Callable, Protocol, Sequence

from pydantic import BaseModel, Field

__all__ = [
    "Transcript",
    "Transcriber",
    "SpeechHandle",
    "Speaker",
    "FixtureTranscriber",
    "FixtureSpeaker",
    "AdaptedTranscriber",
    "AdaptedSpeaker",
]


class Transcript(BaseModel):
    """What the transcriber currently believes was said.

    `final` is the field the loop must branch on and the one a sandwich
    architecture forgets exists. A partial is a HYPOTHESIS: acting on it is
    allowed, committing to it is not.
    """

    text: str
    final: bool = True
    confidence: float | None = None
    """None means the backend does not report one. A default of 1.0 would let
    a caller threshold on a number nobody computed."""


class Transcriber(Protocol):
    """Audio in, text out. The one method the loop calls."""

    def transcribe(self, audio: bytes, *, sample_rate: int = 16_000) -> Transcript:
        ...


class SpeechHandle(BaseModel):
    """One utterance being spoken, and the only honest record of what was heard.

    `spoken_text` is computed from elapsed playback time, not from what was
    handed to the synthesiser. That distinction is the whole of §6.5: the
    generated text is a claim, the spoken prefix is the event.
    """

    model_config = {"arbitrary_types_allowed": True}

    text: str
    started_s: float
    chars_per_second: float = 15.0
    stopped_s: float | None = None

    def spoken_chars(self, now_s: float) -> int:
        end = self.stopped_s if self.stopped_s is not None else now_s
        elapsed = max(0.0, end - self.started_s)
        return min(len(self.text), int(elapsed * self.chars_per_second))

    def ends_at(self) -> float:
        """When playback of the whole utterance finishes. Used to spot stalls.

        A speaker that is handed the next sentence after this moment has
        already gone silent, and the user heard the silence. That is the only
        definition of an underrun available to a client that cannot see inside
        the audio device, and it is enough.
        """
        return self.started_s + (len(self.text) / max(self.chars_per_second, 1e-9))

    def spoken_text(self, now_s: float) -> str:
        """The prefix, trimmed to a WHOLE word. Empty if no word completed.

        Audio stops mid-phoneme; text does not have to. Committing half a word
        puts a token in the transcript that nobody said and no tokenizer
        expects, and the next turn's model will try to make sense of it. So a
        cut that lands inside the first word commits NOTHING -- the turn is
        still recorded, still marked truncated, and `discarded_chars` still
        counts every character, so the record says "the assistant was cut off
        before it got a word out" rather than inventing `Revenu`.
        """
        count = self.spoken_chars(now_s)
        if count >= len(self.text):
            return self.text
        head, sep, _tail = self.text[:count].rpartition(" ")
        return head.rstrip() if sep else ""


class Speaker(Protocol):
    def say(self, text: str) -> SpeechHandle: ...
    def stop(self) -> SpeechHandle | None: ...

    @property
    def device_latency_ms(self) -> float:
        """How long the device takes to turn submitted audio into sound.

        A property rather than a constant because it is a property OF THE
        DEVICE: a laptop's is small, a Bluetooth headset's is not, and a
        telephony leg's is a different number again. `LoopTimer` records it as
        the `first_audio_out` segment, and a backend that does not know it
        should report 0.0 so the segment reads as measured-and-negligible
        rather than as a hole.
        """
        ...


class FixtureTranscriber:
    """A scripted queue of transcripts. Deterministic; no audio is read.

    Raises when exhausted rather than returning empty text, because a loop
    that silently transcribes silence into `""` will send an empty message to
    an agent and blame the model for the answer.
    """

    def __init__(self, transcripts: Sequence[Transcript | str]) -> None:
        self._queue = [
            t if isinstance(t, Transcript) else Transcript(text=t) for t in transcripts
        ]
        self.calls: list[int] = []

    def transcribe(self, audio: bytes, *, sample_rate: int = 16_000) -> Transcript:
        self.calls.append(len(audio))
        if not self._queue:
            raise RuntimeError(
                "FixtureTranscriber exhausted: the loop asked for more speech "
                "than the fixture scripted. Add a transcript or fix the loop."
            )
        return self._queue.pop(0)


class FixtureSpeaker:
    """Playback simulated against an injected clock. One utterance at a time.

    `synthesis_ms` advances the clock inside `say`, which is what lets the
    timing harness produce a deterministic breakdown offline: the fake speaker
    is slow in exactly the way a real one is, by a number you chose.
    """

    def __init__(
        self,
        *,
        now: Callable[[], float] = time.perf_counter,
        advance: Callable[[float], None] | None = None,
        chars_per_second: float = 15.0,
        synthesis_ms: float = 0.0,
        device_ms: float = 0.0,
    ) -> None:
        self._now = now
        self._advance = advance
        self.chars_per_second = chars_per_second
        self.synthesis_ms = synthesis_ms
        self.device_ms = device_ms
        self.spoken: list[SpeechHandle] = []
        self.current: SpeechHandle | None = None
        self._busy_until = 0.0

    @property
    def device_latency_ms(self) -> float:
        return self.device_ms

    def say(self, text: str) -> SpeechHandle:
        if self._advance is not None and self.synthesis_ms:
            self._advance(self.synthesis_ms)
        # A speaker is a QUEUE. Handing it the next sentence while the last
        # one is still playing does not make two sentences play at once, and a
        # fixture that started every utterance at `now` would report the user
        # as having heard sentence three while sentence one was still in the
        # air -- flattering the ledger in exactly the case the ledger exists
        # for.
        start = max(self._now(), self._busy_until)
        self._busy_until = start + len(text) / max(self.chars_per_second, 1e-9)
        handle = SpeechHandle(
            text=text,
            started_s=start,
            chars_per_second=self.chars_per_second,
        )
        self.current = handle
        self.spoken.append(handle)
        return handle

    def stop(self) -> SpeechHandle | None:
        """Flush the buffer. Idempotent, because a barge-in can arrive twice."""
        handle = self.current
        if handle is not None and handle.stopped_s is None:
            handle.stopped_s = self._now()
        self.current = None
        return handle


class AdaptedTranscriber:
    """Any speech-recognition callable, behind the `Transcriber` protocol.

    `recognise` takes float32 samples in [-1, 1] and returns text. Binding
    your package to that is two or three lines and they are the only lines
    that change when you swap models, which is why they are yours and not
    mine: the package name and the model id are current-state facts (see
    VERSIONS.md) and this file must not contain either.

        from voice.speech import AdaptedTranscriber
        asr = load_your_asr(model_id)                       # your package
        transcriber = AdaptedTranscriber(lambda pcm: asr(pcm)["text"])

    The adapter's own job is the part people get wrong: converting int16
    bytes to the float32 the models want, and REFUSING a sample rate the
    model was not trained on instead of silently resampling badly.
    """

    def __init__(
        self,
        recognise: Callable[[Any], str],
        *,
        expects_sample_rate: int = 16_000,
        to_float: Callable[[bytes], Any] | None = None,
    ) -> None:
        self._recognise = recognise
        self._rate = expects_sample_rate
        self._to_float = to_float or _int16_to_float32

    def transcribe(self, audio: bytes, *, sample_rate: int = 16_000) -> Transcript:
        if sample_rate != self._rate:
            raise ValueError(
                f"this model expects {self._rate} Hz and was handed "
                f"{sample_rate} Hz. Capture at the model's rate rather than "
                "resampling here: a bad resample costs accuracy silently, and "
                "the loss lands hardest on the speakers already served worst."
            )
        text = self._recognise(self._to_float(audio))
        return Transcript(text=str(text).strip(), final=True)


class AdaptedSpeaker:
    """Any synthesiser plus any player, behind the `Speaker` protocol.

    `synthesise(text) -> (samples, sample_rate)` and `play(samples, rate)`
    which returns immediately. The adapter derives the SPEAKING RATE from the
    audio it was given -- `len(samples) / rate` seconds for `len(text)`
    characters -- so `SpeechHandle` can answer "how much of this had been
    heard" without the caller guessing at a words-per-minute constant.
    """

    def __init__(
        self,
        synthesise: Callable[[str], tuple[Any, int]],
        play: Callable[[Any, int], None],
        *,
        stop_playback: Callable[[], None] | None = None,
        now: Callable[[], float] = time.perf_counter,
        device_ms: float = 0.0,
    ) -> None:
        self._synthesise = synthesise
        self._play = play
        self._stop = stop_playback
        self._now = now
        self.device_ms = device_ms
        self.current: SpeechHandle | None = None

    @property
    def device_latency_ms(self) -> float:
        return self.device_ms

    def say(self, text: str) -> SpeechHandle:
        samples, rate = self._synthesise(text)
        seconds = max(len(samples) / max(rate, 1), 1e-6)
        self._play(samples, rate)
        handle = SpeechHandle(
            text=text,
            started_s=self._now(),
            chars_per_second=max(len(text), 1) / seconds,
        )
        self.current = handle
        return handle

    def stop(self) -> SpeechHandle | None:
        handle = self.current
        if handle is not None and handle.stopped_s is None:
            handle.stopped_s = self._now()
        if self._stop is not None:
            self._stop()
        self.current = None
        return handle


def _int16_to_float32(audio: bytes) -> Any:
    """int16 PCM bytes -> float32 in [-1, 1]. numpy if present, else stdlib."""
    try:
        import numpy  # noqa: PLC0415

        return numpy.frombuffer(audio, dtype="<i2").astype("float32") / 32768.0
    except ImportError:  # pragma: no cover - numpy is present in practice
        import array  # noqa: PLC0415

        values = array.array("h")
        values.frombytes(audio)
        return [sample / 32768.0 for sample in values]
```

Binding your packages is three short functions in `build_backends`, and the model ids belong in VERSIONS.md rather than in code:

```python
def build_backends(args):
    asr = load_your_asr(args.asr_model)              # your package
    tts = load_your_tts(args.tts_voice)              # your package
    vad = load_your_vad()                            # your package
    return (
        lambda frame: vad(frame),
        AdaptedTranscriber(lambda pcm: asr(pcm)["text"]),
        AdaptedSpeaker(
            synthesise=lambda text: tts(text),       # -> (samples, sample_rate)
            play=your_player.play,
            stop_playback=your_player.stop,
            device_ms=your_player.latency_ms,
        ),
    )
```

**What the baseline machine can and cannot do, plainly.** It can run the VAD with no measurable cost. It can run a small streaming-capable transcriber in the tens-of-megabytes class comfortably on CPU; the candidates, their sizes and their licences are VERSIONS.md rows, and the licence matters — several of the best non-English models are non-commercial. It can run a small CPU-class synthesiser faster than playback, which is the requirement that actually matters: a synthesiser slower than real time cannot stream without underrunning, whatever its latency looks like on one sentence. It **cannot** run a native speech-to-speech model, and it cannot run the large batch transcription models at conversational speed — those are the ones that produce the impressive accuracy numbers and take many seconds per utterance.

### 7.5 [core] Step 4 — the wire

```python
# voice/atlas_client.py
"""A streaming client for Atlas's existing `/v1/chat/stream`. No new routes.

Everything here is a consumer of Phase 15's wire format. The event kinds are
IMPORTED from `atlas.api.sse` rather than copied, so the closed vocabulary has
one definition and a new kind is a compile-time-ish failure in both places at
once -- the console's `KINDS` array is the mistake this avoids, made once in
JavaScript where nothing could check it.

Two things this module does that `parse_sse` cannot.

**It decodes incrementally.** `atlas.api.sse.parse_sse` takes a whole stream
and returns a list, which is exactly right for a test and useless for a voice
loop: the entire benefit is that frame one arrives before frame twelve exists.
`SSEDecoder` holds a buffer and yields complete frames as the bytes land.

**It propagates the trace.** The request carries a `traceparent` built from
the ambient span, so the voice turn and the agent's spans land in ONE trace
that `/v1/traces/{trace_id}` will render. That is the entire reason §8 can
diagnose a barge-in from a span tree instead of from print statements.
"""

from __future__ import annotations

import json
from typing import Any, Iterable, Iterator

from atlas.api.sse import AGENT_EVENTS, AgentEvent
from atlas.obs.spans import current_traceparent

__all__ = ["SSEDecoder", "AtlasVoiceClient", "sentences"]


class SSEDecoder:
    """Bytes in, `AgentEvent`s out. Pure over its buffer; no I/O.

    The blank line is the frame delimiter and a partial frame is KEPT, not
    guessed at. A decoder that parses what it has so far will hand a caller
    half a JSON payload the first time a chunk boundary lands mid-frame, which
    on a fast local loopback happens approximately never and in production
    happens all day.
    """

    def __init__(self) -> None:
        self._buffer = ""

    def feed(self, chunk: str) -> Iterator[AgentEvent]:
        self._buffer += chunk
        while "\n\n" in self._buffer:
            frame, _, self._buffer = self._buffer.partition("\n\n")
            event = self._parse(frame)
            if event is not None:
                yield event

    @staticmethod
    def _parse(frame: str) -> AgentEvent | None:
        if not frame.strip() or frame.lstrip().startswith(":"):
            return None  # keep-alive comment
        kind: str | None = None
        seq = 0
        payload: Any = None
        for line in frame.splitlines():
            if line.startswith("event: "):
                kind = line[len("event: ") :].strip()
            elif line.startswith("id: "):
                seq = int(line[len("id: ") :].strip())
            elif line.startswith("data: "):
                payload = json.loads(line[len("data: ") :])
        if kind is None:
            return None
        if kind not in AGENT_EVENTS:
            raise ValueError(
                f"unknown SSE event kind {kind!r}. A voice client that guesses "
                "at an unknown kind will either speak something nobody "
                "designed or stay silent forever waiting for a terminal event."
            )
        return AgentEvent(kind=kind, data=payload or {}, seq=seq)  # type: ignore[arg-type]


class AtlasVoiceClient:
    """One turn over `POST /v1/chat/stream`. Yields events as they arrive.

    `http` is any object with httpx's `.stream(method, url, ...)` context
    manager -- a real `httpx.Client` against `make serve`, or Starlette's
    `TestClient` against an app built in-process. Injected rather than
    constructed for invariant 10's reason, and it is what lets the eval task
    in §7.7 drive the REAL app with no socket.
    """

    def __init__(
        self,
        http: Any,
        *,
        token: str,
        base_url: str = "",
        route: str | None = "chat",
    ) -> None:
        self._http = http
        self._token = token
        self._base = base_url.rstrip("/")
        self._route = route
        self.thread_id: str | None = None

    def stream(self, message: str, *, thread_id: str | None = None) -> Iterator[AgentEvent]:
        """Send one turn. The caller MUST consume to a terminal event or close.

        Closing the iterator early stops this process reading; it does not
        stop the agent. Phase 15 says so in the body of its own cancellation
        endpoint, and a voice client that treats a hung-up stream as a
        cancelled run will report work as abandoned while it is still
        running -- and, for a write tool, still writing.
        """
        body: dict[str, Any] = {"message": message}
        target = thread_id or self.thread_id
        if target:
            body["thread_id"] = target
        if self._route:
            body["route"] = self._route
        headers = {"authorization": f"Bearer {self._token}"}
        traceparent = current_traceparent()
        if traceparent:
            headers["traceparent"] = traceparent

        decoder = SSEDecoder()
        with self._http.stream(
            "POST", f"{self._base}/v1/chat/stream", json=body, headers=headers
        ) as response:
            if response.status_code != 200:
                response.read()
                yield AgentEvent(
                    kind="error",
                    data={
                        "error_kind": f"http_{response.status_code}",
                        "message": "the service refused the request",
                    },
                )
                return
            for chunk in response.iter_text():
                for event in decoder.feed(chunk):
                    if event.kind == "start":
                        self.thread_id = event.data.get("thread_id") or self.thread_id
                    yield event
                    if event.terminal:
                        return


def sentences(chunks: Iterable[str]) -> Iterator[str]:
    """Split a token stream into speakable units. Pure and lazy.

    A synthesiser wants a sentence, not a token and not a paragraph. Feeding
    it tokens produces chopped prosody; feeding it the whole answer means no
    audio until the model finishes, which is the self-inflicted wound in
    §6.3's table. The split is deliberately crude -- terminal punctuation
    followed by a space -- because a good sentence splitter is a dependency
    and a bad one is two lines, and the failure mode of the bad one is a
    slightly long sentence.
    """
    buffer = ""
    for chunk in chunks:
        buffer += chunk
        while True:
            cut = -1
            for index, character in enumerate(buffer):
                if character in ".!?" and index + 1 < len(buffer) and buffer[index + 1] == " ":
                    cut = index + 1
                    break
            if cut < 0:
                break
            head, buffer = buffer[:cut], buffer[cut:].lstrip()
            if head.strip():
                yield head.strip()
    if buffer.strip():
        yield buffer.strip()
```

A non-200 becomes an `error` event rather than an exception, because the loop's contract is "every turn terminates in the closed vocabulary" and a 401 is a thing the user needs said to them, not a stack trace.

### 7.6 [core] Step 5 — the loop and the ledger

Four things in this file repay a slow read: `TERMINAL_OUTCOMES` (an interrupted turn and a hung stream are different states with opposite remedies); the tool timing, which is an **upper bound** because Phase 15's stream emits `phase: "end"` only; the underrun detection, which is the only definition available to a client outside the audio device; and the ledger, which commits *every* utterance the speaker got through rather than the prefix of the last one.

```python
# voice/loop.py
"""One turn of a voice conversation, with the ledger that survives barge-in.

This is §6.5 as code. The rules, restated where they are enforced:

  * the committed assistant message is the SPOKEN PREFIX, marked truncated;
  * generated-but-unspoken text is discarded, and counted so the discard is
    visible in a record rather than being a silence;
  * tool results already obtained are kept -- they cost money and are true;
  * the thread id survives, because a turn ended and a conversation did not.

The loop is synchronous. A real client runs capture on one thread and this on
another, and asyncio would be the obvious alternative; a generator over a
blocking stream is used instead because the thing being taught is the ORDER of
the decisions, and an event loop in the middle of it would be scaffolding a
reader has to unpick before they can see the ledger.
"""

from __future__ import annotations

import time
from typing import Any, Callable, Iterator, Literal

from pydantic import BaseModel, Field

from atlas.api.sse import AgentEvent
from voice.atlas_client import sentences
from voice.speech import SpeechHandle, Speaker
from voice.timing import LoopTimer, TurnTiming

__all__ = ["TERMINAL_OUTCOMES", "BargeInMonitor", "Utterance", "TurnRecord", "VoiceSession"]

TERMINAL_OUTCOMES: tuple[str, ...] = ("done", "error", "interrupted", "")
"""How a turn ended, as a closed set. `""` means the stream stopped without
saying anything -- a hung connection -- and it is LAST because it is the one
that must stay distinguishable. An earlier version reported an interrupted
turn as `""` too, which merged "the user cut me off" with "the service went
away mid-sentence": two states with opposite remedies."""


class BargeInMonitor:
    """Is the user talking while the agent is? One persistent endpointer.

    It exists as a class for one reason, and that reason is a real defect this
    file shipped: `voice/cli.py` built a FRESH `Endpointer` on every frame, so
    `_speech_frames` never reached `min_speech_ms` and barge-in could not fire
    at all -- 50 consecutive loud frames produced zero events. A per-frame
    closure looks stateless and is exactly the thing that must not be.

    `reset()` is called at the start of each agent turn, because speech
    detected during the PREVIOUS turn is not an interruption of this one.
    """

    def __init__(self, frames: Callable[[], float], policy: Any = None) -> None:
        from voice.endpoint import DEFAULT_POLICY, Endpointer  # noqa: PLC0415

        self._frames = frames
        self._policy = policy or DEFAULT_POLICY
        self._machine = Endpointer(self._policy)
        self.fired = 0

    def reset(self) -> None:
        from voice.endpoint import Endpointer  # noqa: PLC0415

        self._machine = Endpointer(self._policy)

    def __call__(self) -> bool:
        """One frame through the SAME machine. True once speech is confirmed."""
        if self._machine.feed(self._frames()) == "speech_start":
            self.fired += 1
            return True
        return False


class Utterance(BaseModel):
    """One line of the conversation as both parties experienced it."""

    role: Literal["user", "assistant"]
    text: str
    truncated: bool = False
    """True when the speaker was stopped mid-utterance. Carried into the
    record rather than implied by a short string, because "short" and "cut
    off" are different facts and only one of them means the user did not
    hear the rest."""


class TurnRecord(BaseModel):
    """What happened, as observations rather than as claims."""

    thread_id: str = ""
    trace_id: str = ""
    route: str = ""
    tools: list[str] = Field(default_factory=list)
    generated: str = ""
    spoken: str = ""
    discarded_chars: int = 0
    interrupted: bool = False
    terminal_event: str = ""
    """One of `TERMINAL_OUTCOMES`. `""` means the stream stopped without a
    terminal event -- a hung connection, which a client that cannot express it
    will experience as a warm microphone and no explanation."""
    approval_required: bool = False
    """The agent paused for a human decision. The client SPEAKS the
    consequence and cannot collect the answer: Phase 15's API has no
    approval-response endpoint, so there is nothing to send a decision to.
    Stated on the record rather than implied, because a client that silently
    carried on would be manufacturing the consent of §6.6."""
    token_source: str = ""
    timing: TurnTiming | None = None


class VoiceSession:
    """A conversation over one Atlas thread, spoken.

    `monitor` is polled between speakable units and returns True when the user
    has started talking. The real client backs it with the endpointer over
    microphone frames; a test backs it with a script. Polling between units
    rather than continuously is a deliberate limitation of a cascade and is
    stated in §6.2: this architecture cannot listen and speak at once, so the
    granularity of its barge-in is one sentence.
    """

    def __init__(
        self,
        client: Any,
        speaker: Speaker,
        *,
        monitor: Callable[[], bool] = lambda: False,
        now: Callable[[], float] = time.perf_counter,
        tracer: Any = None,
        endpointing_ms: float = 600.0,
    ) -> None:
        self._client = client
        self._speaker = speaker
        self._monitor = monitor
        self._now = now
        self._tracer = tracer
        self._endpointing_ms = endpointing_ms
        self.transcript: list[Utterance] = []
        self.timings: list[TurnTiming] = []

    def new_timer(self) -> LoopTimer:
        """A timer for the turn that is ABOUT to be captured.

        Capture and transcription happen in the caller (the microphone loop),
        before `ask` is reached, so the timer has to be created there and
        passed in. The first version created it inside `ask`, which is why
        `capture` and `transcription` could never appear in the breakdown --
        two of the eight segments were unmeasurable by construction, in the
        appendix whose subject is the breakdown.
        """
        return LoopTimer(turn=len(self.timings), now=self._now, tracer=self._tracer)

    def ask(self, text: str, *, timer: LoopTimer | None = None) -> TurnRecord:
        """One turn: send the transcript, speak the answer, keep the ledger."""
        timer = timer if timer is not None else self.new_timer()
        if not timer.has_anchor("user_last_word"):
            # Backdated: the endpointer only told us the turn ended AFTER the
            # hangover elapsed, and the user has been waiting since before
            # that. Skipped when the CAPTURE LOOP already anchored it -- that
            # caller knows the moment precisely and has transcription to
            # account for in between, and an anchor stamped here would move
            # the user's last word forward past a segment they waited through.
            timer.anchor("user_last_word", offset_ms=self._endpointing_ms)
            timer.declare("endpointing", self._endpointing_ms)
        self.transcript.append(Utterance(role="user", text=text))

        if hasattr(self._monitor, "reset"):
            self._monitor.reset()  # speech in the last turn is not this turn's

        record = TurnRecord()
        handles: list[SpeechHandle] = []
        handle: SpeechHandle | None = None
        generated: list[str] = []
        first_audio_done = False
        plan_at: float | None = None
        previous_ends_at: float | None = None

        def token_texts() -> Iterator[str]:
            nonlocal handle, first_audio_done, plan_at
            sent_s = self._now()
            first_token_seen = False
            for event in self._client.stream(text):
                if event.kind == "start":
                    record.thread_id = str(event.data.get("thread_id", ""))
                    record.trace_id = str(event.data.get("trace_id", ""))
                elif event.kind == "plan":
                    record.route = str(event.data.get("route", ""))
                    record.tools = [str(t) for t in event.data.get("tools", [])]
                    plan_at = self._now()
                elif event.kind == "tool":
                    # An UPPER BOUND, and labelled one: Phase 15's stream emits
                    # `phase: "end"` only, so the earliest moment this client
                    # can attribute tool work to is the `plan` event. Each new
                    # tool event REPLACES the value (accumulate=False) -- adding
                    # them would sum a sequence of prefixes, which measures
                    # nothing. The first version of this branch waited for a
                    # `phase: "start"` the server never sends, so `tool_call`
                    # was silently unmeasurable against the real service.
                    if plan_at is not None:
                        timer.record(
                            "tool_call",
                            (self._now() - plan_at) * 1000.0,
                            accumulate=False,
                        )
                elif event.kind == "approval":
                    record.approval_required = True
                    # Spoken before any answer, and never answered from audio
                    # that overlapped it. §6.6.
                    self._speaker.say(
                        f"Before I do that: {event.data.get('consequence', 'an action')}."
                    )
                elif event.kind == "token":
                    if not first_token_seen:
                        timer.record("first_agent_token", (self._now() - sent_s) * 1000.0)
                        first_token_seen = True
                    record.token_source = str(event.data.get("source", ""))
                    chunk = str(event.data.get("text", ""))
                    generated.append(chunk)
                    yield chunk
                elif event.kind in ("done", "error"):
                    record.terminal_event = event.kind

        with timer.segment("full_agent_response"):
            for sentence in sentences(token_texts()):
                if self._monitor():
                    record.interrupted = True
                    break
                with timer.segment("speech_synthesis"):
                    handle = self._speaker.say(sentence)
                handles.append(handle)
                if previous_ends_at is not None and handle.started_s > previous_ends_at:
                    # The speaker finished the last sentence before this one
                    # arrived: the user heard a gap in the middle of an answer.
                    # This is the only underrun a client outside the audio
                    # device can observe, and an uncounted one is a stall the
                    # report calls healthy.
                    timer.underrun((handle.started_s - previous_ends_at) * 1000.0)
                previous_ends_at = handle.ends_at()
                if not first_audio_done:
                    device_ms = float(getattr(self._speaker, "device_latency_ms", 0.0))
                    timer.record("first_audio_out", device_ms)
                    # Stamped FORWARD by the device latency (a negative
                    # offset): submitting audio is not the same event as the
                    # user hearing it, and the metric is named for the second.
                    timer.anchor("first_audio", offset_ms=-device_ms)
                    first_audio_done = True
                if self._monitor():
                    record.interrupted = True
                    break

        if record.interrupted:
            timer.interrupted = True
            record.terminal_event = "interrupted"
            # Stop FIRST, then read: `stop()` stamps `stopped_s`, and a prefix
            # computed before the speaker was stopped keeps growing while the
            # ledger is being written.
            self._speaker.stop()

        record.generated = "".join(generated)
        if not handles:
            record.spoken = ""
        elif record.interrupted:
            # EVERY utterance the speaker got through, not just the last one.
            # Taking the prefix of the final handle alone silently dropped the
            # sentences the user had already heard -- so an interruption
            # during sentence three committed a fragment of sentence three and
            # erased one and two from the conversation. The tests could not
            # see it because their fixture always cut in during sentence one.
            now = self._now()
            heard = [part for part in (h.spoken_text(now) for h in handles) if part]
            record.spoken = " ".join(heard)
        else:
            record.spoken = record.generated.strip()

        # DISCARDED, counted. A silent discard is a turn whose record says the
        # assistant produced 400 characters and the user heard 90, with no
        # field anywhere saying that the two differ.
        record.discarded_chars = max(0, len(record.generated.strip()) - len(record.spoken))
        self.transcript.append(
            Utterance(
                role="assistant", text=record.spoken, truncated=record.interrupted
            )
        )
        record.timing = timer.finish()
        self.timings.append(record.timing)
        return record

    def committed_context(self) -> list[dict[str, str]]:
        """The conversation as the NEXT turn's model should see it.

        A truncated assistant turn is marked in the text itself rather than
        only in a boolean, because the boolean does not survive the trip into
        a prompt and the model is the consumer that most needs to know.
        """
        return [
            {
                "role": item.role,
                "content": item.text + (" —" if item.truncated else ""),
            }
            for item in self.transcript
        ]
```

### 7.7 [core] Step 6 — run it, and read your own breakdown

```
export ATLAS_API_SECRET=$(openssl rand -hex 32)
make serve                                   # terminal 1
export ATLAS_VOICE_TOKEN=...                 # a token for your subject
python voice/cli.py --asr-model ... --tts-voice ...    # terminal 2
```

Ask it six things. Interrupt it twice. Then read the table it prints on exit. **Here is that table with the cells you must fill in yourself**, because I cannot run a microphone and will not invent numbers:

```
segment                n    p50 ms    p95 ms   share  source
capture                _      ____      ____    ____  measured
endpointing            _      ____      ____    ____  chosen
transcription          _      ____      ____    ____  measured
first_agent_token      _      ____      ____    ____  measured
full_agent_response    _      ____      ____    ____  measured
tool_call              _      ____      ____    ____  measured
speech_synthesis       _      ____      ____    ____  measured
first_audio_out        _      ____      ____    ____  measured

time to first audio   n=__   p50=____  p95=____  max=____
interrupted turns __/__   underruns __
```

**You can see seven of the eight rows without a microphone.** This is the harness's real output from `pd-c`, driving the actual service on a virtual clock:

```
segment                n    p50 ms    p95 ms   share  source
capture                1    1500.0    1500.0  151.8%  measured
endpointing            1     600.0     600.0   60.7%  chosen
transcription          1     260.0     260.0   26.3%  measured
first_agent_token      1       0.0       0.0    0.0%  measured
full_agent_response    1     360.0     360.0   36.4%  measured
tool_call              0      ____      ____    ____  measured (no samples)
speech_synthesis       1     360.0     360.0   36.4%  measured
first_audio_out        1       8.0       8.0    0.8%  measured

time to first audio   n=1   p50=988.0ms p95=988.0ms max=988.0ms
interrupted turns 0/1   underruns 0
```

Read it as a worked example of the *procedure*, not as a measurement: every duration is one the fixture chose, and `first_agent_token` is 0.0 because a `FakeLLMClient` is instantaneous. What is real is the arithmetic — 600 + 260 + 0 + 120 + 8 = 988 — and the two things it demonstrates. `capture` shows 151.8%, above 100%, which is correct and is why it is not a candidate for the dominant segment: the user talking is not the user waiting. And `tool_call` is `____` because the `chat` route calls no tools, which is what an honestly empty row looks like next to seven full ones.

**How to read your own table.**

1. **Check that the parts reach the total.** Sum endpointing, transcription, first agent token, the first sentence of synthesis, and first audio out; compare with time to first audio. If they disagree, stop and fix the instrument — a breakdown whose parts do not reach its total is measuring two different things and telling you about neither.
2. **Find the largest row on the path to first audio** — which excludes `capture` and excludes `full_agent_response`, since that continues after the audio started.
3. **Apply exactly one fix** from §6.3's table and re-measure. Two changes at once produce a number you cannot attribute.
4. **Check `underruns`.** Non-zero means stop optimising first-audio entirely and fix the streaming: a stall is worse than a wait.
5. **Compare p95 with p50.** A large gap means something occasional is very slow, and the occasional thing is almost always the tool call or the first request after an idle period.

**Illustrative arithmetic, not a measurement.** If your endpointing is 600, transcription 300, first agent token 700 and first sentence of synthesis 200, time to first audio is 1,800 and the shares are 33%, 17%, 39% and 11%. That is arithmetic over four numbers I chose to demonstrate the reasoning; it is not a claim about any machine.

### 7.8 [core] Evaluating a voice agent: word error rate is not enough

Word error rate measures transcription. It is the right metric for a transcriber and close to irrelevant for an agent, because it is blind to every failure this appendix is about: it cannot see that the agent answered before the user finished, that it kept talking over an interruption, that it committed words nobody heard, or that the answer arrived four seconds late. A stack with excellent WER and a 3-second hangover is a bad voice agent with a good number.

So the appendix ships **four tasks in the Phase 13 format**, in `evals/tasks/appendix_d.json`, graded by the existing harness. They fit without editing it because the entrypoint is named `serve_scenario`, which is the branch `evals/run.py` already dispatches for Phase 15 — `(client, registry=, scenario=, prompt=, route=)` in, `(payload, stop_reason)` out. The appendix file is **not** named `phase*.json`, so the core suite's task count, baseline and published numbers are untouched; `voice/run_appendix_evals.py` passes the path to the harness's own `load_tasks`.

| Task | What it grades | What it misses |
|---|---|---|
| `pd-a-barge-in-commits-the-spoken-prefix-not-the-generated-text` | the speaker stopped; the committed message is a prefix of what was generated; it is marked truncated; `discarded_chars > 0`; the thread survived | whether the interruption was *detected* at the right moment — the monitor is scripted |
| `pd-b-a-thinking-pause-is-not-a-turn-and-a-cough-is-not-either` | one utterance ends once; a 450 ms mid-utterance pause does not end it; a two-frame burst never starts one; a stuck detector truncates | whether a real VAD emits those probabilities for a real speaker — the part that varies by accent and by room |
| `pd-c-every-turn-reports-a-breakdown-and-endpointing-is-declared` | both anchors, **seven** segments including `capture` and `transcription`, endpointing declared not measured, time-to-first-audio ≥ hangover + transcription, zero underruns, terminal event `done`, tokens live rather than replayed | every millisecond. The task asserts the *shape* of the measurement, never a value — a latency assertion in a test is a flaky test with a stopwatch |
| `pd-d-the-answer-survives-the-voice-path` | task success, read from what the **speaker emitted**: the answer's facts, the route, a surviving thread, no approval pending, no underruns | whether the answer was *good* — that is Phase 13's judge, and it grades text this task only checks arrived |

`pd-d` is the complement of `pd-a`: `pd-a` proves the agent stops when it should, `pd-d` proves it finishes when it should. A suite with only the first has a trivially optimal implementation that never speaks — invariant 76, in a new channel. `pd-c`'s provenance block says plainly that it was harvested twice from this appendix's own defects: an anchor stamped at the wrong moment, and a timer created where it could not see two of its segments.

The harness's own output, Tier F, seed 7, three trials:

```
  pd-a-barge-in-commits-the-spoken-prefix-not-the-generated-text ...   3/3  [reg]
  pd-b-a-thinking-pause-is-not-a-turn-and-a-cough-is-not-either  ...   3/3  [reg]
  pd-c-every-turn-reports-a-breakdown-and-endpointing-is-declared ...  3/3  [reg]
  pd-d-the-answer-survives-the-voice-path                        ...   3/3  [reg]
pass^k (all 3 trials)   4/4 = 100%      pass@k (any trial)  4/4 = 100%
```

**The four metrics a voice suite needs, and what each misses.** *Task success* — did the user get what they asked for — misses everything about how it felt. *Interruption handling* — did the speaker stop, and is the ledger right — misses whether interrupting was easy. *Turn-taking errors*, counted in three separate buckets (cut off the user, dead air, false trigger), misses that the three fall on different people: the cut-off bucket is concentrated in speakers who pause more. *Latency percentiles*, reported as p50/p95 with n, miss the tail shape and say nothing about underruns, which is why underruns are counted separately with their dead air beside them. Report all four, never one, and never a mean.

**And the published benchmarks exist.** Full-Duplex-Bench (Lin et al., ASRU 2025) evaluates turn-taking, pause handling, backchannelling and interruption; its v1.5, v2 and v3 add overlap handling, an automated examiner and multi-step tool use under real disfluent speech; VoiceBench evaluates voice-assistant capability broadly. They are the right place to learn what to measure and — per Phase 13's rule — they compare systems and do not predict yours.

### 7.9 [core] Vision inputs and document understanding as agent capabilities

Voice and vision arrive in the same conversation because they are the same architectural question: **a new modality is either a tool the agent calls or a channel the model consumes directly**, and that choice determines where every one of your controls sits.

Atlas already treats documents as a *tool* problem. Phase 6's ingest pipeline extracts text from PDFs, grades the extraction, and refuses to index what it could not read; Phase 7 queries structured data. A vision-language model changes what the extractor can do — layout, tables, checkboxes, handwriting, charts, screenshots — and changes nothing about the shape: it is still an extractor whose output goes through the same quality gate before it reaches the index. That is the cheap, safe integration, it composes with everything from Phase 6 onward, and for a laptop it is realistic: small open-weight document models in the sub-billion-parameter class now do structured document parsing, and the general small VLMs handle invoices and forms; the current names, sizes and licences are VERSIONS.md rows.

The expensive integration is making the *agent* multimodal — the user shows it a photo mid-conversation and the model reasons over the pixels. Three things to hold onto if you go there. **Your prompt-injection surface is now an image**: text rendered inside a picture is instructions the model will read, and Phase 14's input defences operate on strings. **Your egress filter still operates on text**, so an answer derived from an image is filtered, but a model that emits an image is not. And **your eval suite grades sentences**: a vision capability with no vision tasks is Phase 16's unsupported claim with a camera.

The pragmatic rule, and it is the same one §6.2 reached for audio: treat the new modality as an extractor feeding your existing text pipeline until you have a measured reason not to. You keep your gates, your judge, your filters and your regression suite, and you give up capability you can add later with evidence.

### 7.10 [core] Honest limitations

This is a section, not a caveat, and none of it is solved.

**Accent, dialect, noise and code-switching.** Recognition error is not distributed evenly across people. It is higher for speakers whose accent, dialect or age is underrepresented in training data, higher in noise, and higher still when a speaker switches languages mid-sentence, which multilingual households do constantly and almost no pipeline handles. The consequences compound: worse recognition means more repetition, more repetition means longer sessions, longer sessions mean more endpointing errors. Measure WER **by speaker group on your own audio** rather than quoting a benchmark; a single aggregate number hides exactly the population you are failing. And when the agent can act, a recognition error is not a typo — it is a wrong action.

**Latency floors you cannot design away.** Some of the budget is physics and policy rather than engineering: the frame size your detector needs, the silence you must wait through to know a turn ended, the network round trip if anything is hosted, the jitter buffer if anything is WebRTC, the device latency if the headset is Bluetooth. You can move a hangover from 800 ms to 400 ms; you cannot move it to zero, because at zero you interrupt everyone who breathes. Semantic turn detection shifts the trade — it does not remove it.

**A tool call longer than a conversational pause.** There is no silent solution. §6.6's three strategies are narrate, defer, or precompute, and all three change what the user experiences. The failure to avoid is the fourth option, which is to say nothing and hope, because dead air past a few seconds reads as a dropped call and the user hangs up or starts talking — at which point you also have a barge-in you did not plan for, in the middle of a tool call you cannot cancel.

**Consent and recording.** Recording a person's voice is regulated, the rules differ by jurisdiction and sometimes require all parties to consent, and "the agent needs it for context" is not a legal basis. This is why the client here is push-to-talk: a turn you start on purpose is an unambiguous, auditable signal that this utterance was meant for the agent, and an always-listening microphone in an office records people who never agreed to anything. Retention is a second decision — audio is biometric-adjacent data in several regimes and Atlas's own `expire_before` is the shape of the answer. **Appendix E covers the legal and policy side; this appendix does not duplicate it**, and you should read it before you point a microphone at a colleague.

**Voice cloning and impersonation.** A few seconds of a person's speech is enough for current cloning models to produce convincing synthetic speech in their voice. That is a misuse surface with three faces: an agent that *sounds* like a specific real person, an agent that sounds convincingly human and does not say it is not, and an authentication system that accepted a voice as a credential. Three rules follow. Do not clone a voice without that person's explicit, specific and revocable consent. Disclose synthetic speech — some jurisdictions now require it, and it is right regardless. And never accept a voiceprint as an authentication factor for anything that matters: Atlas's approval gate is deliberately tied to a verified bearer token and a subject, not to a voice, and §6.6's rule that irreversible actions are not approvable by voice alone is the same principle one layer up. Provenance watermarking of generated audio is being deployed by the major providers and is worth tracking; it is a mitigation, not a solution, because it tells you what a system produced and not what a person authorised.

### 7.11 [core] With an assistant

**Safe to delegate.** The device plumbing in `build_backends` — stream setup, the three bindings, PCM conversion. Additional test cases for the endpointer, once you have written the first three yourself. Converting the breakdown table into a chart.

**Not safe to delegate.** The ledger in `loop.py`. Assistants confidently write the version that appends `record.generated` to the transcript, because that is what every tutorial in their training data does, and the bug is invisible until turn three. Also not safe: the endpointing parameters (an assistant will pick numbers that read well and interrupt every slow speaker), and anything about which actions may be approved by voice.

**A prompt that works.** "Here is `voice/speech.py`, which defines an `AdaptedTranscriber` taking a callable from float32 samples to text, and here is the model card for the ASR package I have installed. Write only the binding — do not touch the class, do not add a method, and do not change any other file. Raise, with a message naming the expected value, if the audio is not 16 kHz mono int16."

---

## 8. [core] Debug this trace

A user reports: *"I asked about the March invoice, I cut it off to say something, and then it told me it had already offered to open the ledger entry. It never said that."*

The trace, verbatim, from a fixture run of the client against the real service — one clock throughout, so the tree and the segment list are arithmetically consistent:

```
trace 88349eaa7027a268ca67b10c9e1cfd5f
    voice.turn                                                     4552.27ms
      atlas.route=chat
      invoke_agent atlas                                            553.62ms
        atlas.route=chat
        chat fake                                                     0.12ms

    voice.capture                1400.2 ms  measured
    voice.endpointing             900.0 ms  chosen
    voice.transcription           280.2 ms  measured
    voice.first_agent_token       571.0 ms  measured
    voice.speech_synthesis          0.0 ms  measured
    voice.first_audio_out          12.0 ms  measured
    voice.full_agent_response    2871.5 ms  measured

    time to first audio          1763.5 ms

spoken   : 'The March invoice is disputed.'
generated: 'The March invoice is disputed. I can open the ledger entry.'
committed: The March invoice is disputed. I can open the ledger entry.
terminal : interrupted   discarded: 29
```

**Read the tree first.** One trace, one root, no orphans, and the server's `invoke_agent` span is a *child of the client's* `voice.turn` — two processes, one tree, because the client opened a span and sent a `traceparent` built from it. Phase 15's design working across a boundary it was never tested against.

**Check the arithmetic before you trust anything.** 900 + 280 + 571 + 0 + 12 = 1763.5, which is the reported time to first audio. When those two disagree, stop and fix the instrument. (`speech_synthesis` is 0.0 because this fixture's speaker is instantaneous; `capture` is outside the total because the user talking is not the user waiting.)

**Now the three lines under it.** `spoken` is 29 characters, `generated` is 58, `committed` is 58. There is the bug, and it is not in the agent: the agent behaved correctly, the stream terminated correctly, the latency was unremarkable. The client committed what it *produced* rather than what the user *heard*, so the next turn's context contains a sentence that was synthesised, never played, and is now a premise the model will build on — hence "I already offered to open the ledger entry."

**Note `terminal: interrupted`.** In the first version of this client that field read `""` — the same value a hung connection produces — so the trace could not distinguish "the user cut me off" from "the service vanished mid-sentence", which have opposite remedies.

**Why no test caught it.** Every text-level assertion passes: the answer is correct, the route is right, the token accounting is right, the thread is right. The only artefact that disagrees with itself is the pair (`spoken`, `committed`), and nothing looked at both until `pd-a` did. This is Phase 13's outcome-versus-transcript lesson in new clothing: the transcript is generated by the thing under test, and here it is generated by the thing under test *about itself*.

**The fix** is at the end of `VoiceSession.ask`: commit every utterance the speaker got through, joined, with the last truncated at the word the audio reached; mark it; count the difference; render the truncation into the text that reaches the model. **The checks that keep it fixed** are `committed_is_prefix_of_generated` *with* `discarded_chars > 0` — a client that never generates more than it speaks satisfies the first trivially — plus `test_an_interruption_in_a_later_sentence_keeps_the_earlier_ones`, which exists because the first fix was itself wrong: it committed the prefix of the last handle only, and silently erased the sentences the user had already heard.

**One more reading.** `voice.endpointing` is 900 ms and marked `chosen`. If this user's complaint had been "it's slow" rather than "it lied", the trace already says where to look, and it is not the model.

---

## 9. [core] Common pitfalls and how professionals avoid them

**Committing generated text instead of spoken text.** §8. The professional habit is to treat the assistant's transcript as an *observation of the channel* rather than a copy of the output buffer, and to make the two different types so they cannot be confused.

**Shipping a latency report before its callers.** The report renders identically whether or not anything calls it: four blank rows and a zero that cannot move read as "fast". Run the instrument on your own work and check that the parts reach the total before you publish a table.

**Tuning the hangover on yourself.** You speak your own product fluently, in a quiet room, in your first language. A parameter tuned on the author interrupts everybody else. Collect a small set of recordings from people who are not you — including one nervous person, one who reads numbers aloud, one who pauses to think — and check the three turn-taking buckets separately before shipping a change.

**Detecting your own voice as the user's.** No echo cancellation, speakers instead of headphones, and the agent interrupts itself one word into every answer. Invisible in development, universal in the field; the fix is a transport that does AEC, not a cleverer VAD.

**Stateless state.** The barge-in monitor written as a per-frame closure looks tidy and cannot confirm speech, so it never fires. Anything with a minimum-duration rule must own its machine across frames, and a test must drive it with a frame source.

**Optimising time-to-first-audio into underruns.** Buffer less and the speaker runs dry mid-sentence. Report both numbers together and treat a non-zero underrun count as a blocker, not a trade.

**Synthesising the whole answer before playing any of it.** The commonest self-inflicted latency wound, and an architecture bug rather than a model choice. Stream at sentence granularity from day one; retrofitting it means rewriting the loop.

**Treating a closed SSE stream as a cancelled run.** The client stopped reading; the agent kept working, and if a write tool was in flight it kept writing. Surface it to the user rather than quietly reporting the turn as abandoned.

**Accepting "yeah" as approval for an irreversible action.** The approval channel has an error rate the button did not have, and the errors are asymmetric. Route irreversible approvals to a channel with no recognition step.

**Measuring the agent and calling it measuring the experience.** Server-side latency is the segment you happen to own. Measure from the user's last word, in the client, and publish the breakdown.

---

## 10. [extended] Industry perspective

Teams shipping voice agents in 2026 make four recurring decisions.

**Cascade or native.** Teams with load-bearing text-side controls — compliance filters, approval gates, judge-graded evals — keep the cascade and accept the latency, because moving to a model that emits audio directly means re-siting every one of those controls. Teams optimising for conversational feel move to native models and rebuild the controls around them. A visible hybrid has emerged: a full-duplex model handling the conversation while delegating reasoning and tool execution to a separate backend agent, which is architecturally the cascade admitting that turn-taking is a specialist job.

**Build the transport or buy it.** The open frameworks split along the same line: one family owns the media layer (a WebRTC server with rooms, native SIP trunking, an agents SDK on top), the other stays transport-agnostic and orchestrates a pipeline you assemble. The first is less work for telephony; the second is less lock-in. Almost nobody hand-rolls RTP any more, and the teams that did all rediscovered jitter buffers.

**Latency is a product spec, not an engineering aspiration.** Mature teams publish a budget per segment and gate deploys on the p95 of time-to-first-audio, as a web team gates on page load. The discipline that distinguishes them is that they measure in the client and attribute by segment, so "the model got slower" is a claim somebody can check.

**Evaluation is where the field is youngest.** Production practice is converging on scripted conversational scenarios replayed through the real stack, with graders for task success, turn-taking and latency — what §7.8 is a miniature of — plus sampled human review, because no automatic grader currently catches "technically correct and infuriating to talk to".

**Interview questions.**

1. A user reports the agent "talks over them". Name four distinct root causes, one from each of: endpointing, echo, architecture, and the network.
2. Your p50 time-to-first-audio is acceptable and p95 is three times p50. What do you look at first, and what would make you conclude the model is not the problem?
3. You are asked to move from a cascade to a native speech-to-speech model. Name three controls that must be re-sited and say where each one goes.
4. Design the approval flow for a voice agent that can issue refunds. State explicitly what you refuse to do through the audio channel and why.
5. Your WER is 6% overall and the product is failing for one customer's staff. What do you measure next, and what would you do if the answer is what you suspect?

---

## 12. [core] Mastery checklist

You are ready to move on if you can:

* name the eight segments, say which two are not on the path to first audio, and explain why the anchor is backdated;
* give four independent reasons a voice agent is not STT plus an agent plus TTS, one of which is about your Phase 14 egress filter;
* write the endpointing state machine from the four parameters, and say which failure each prevents;
* state the interruption ledger from memory — what is discarded, what is kept, what is marked — including why the prefix is not the last sentence;
* take a breakdown table, check that its parts reach its total, name the dominant segment on the path to first audio, and give the fix that applies to it and one that does not;
* explain why `discarded_chars > 0` is in the eval task beside the prefix check;
* say which Atlas actions may be approved by voice, defend the line you drew, and name the endpoint that would have to exist to collect the decision;
* name three things WER cannot see and the metric that sees each;
* say who recognition errors fall on hardest and what you would measure to find out.

---

## 13. [core] Quiz

1. Why does a single VAD threshold produce three events where two belong, and what does the second threshold buy that a longer minimum-speech window does not?
2. A team reduces its hangover from 800 ms to 300 ms and reports a 500 ms latency improvement. What have they actually traded, and which metric would show the cost?
3. Explain why speculative execution on a partial transcript is a constraint on your *tool design* rather than on your speech stack.
4. Your voice client closes the SSE stream when the user interrupts. Describe the state of the system one second later, on the server, if the agent was mid-way through a gated write.
5. A native speech-to-speech model removes the transcript from the critical path. Name two Atlas controls that depended on it and say what would have to replace each.
6. Why does `render_breakdown` print `____` for a segment with no samples instead of `0.0`, and what error would the zero cause in a p50?

---

## 14. [core] Coding assignments

### Assignment 1 — a semantic end-of-turn guard **[fast track: do this one]**

Create `voice/eou.py`. The VAD-plus-hangover policy in §6.4 cannot tell a finished sentence from a person reading out an account number. Add a guard that looks at the partial transcript and decides whether to *extend* the wait.

**Acceptance criteria.** `WaitPolicy` is a frozen Pydantic model with `extra_ms` and `max_wait_ms`. `should_wait(partial_text, silence_ms, policy)` returns a frozen `WaitDecision` with `wait`, `extra_ms` and a `reason` drawn from a closed `REASONS`. A sentence ending in terminal punctuation does not wait. A trailing conjunction, preposition or filler waits. A trailing digit waits. Empty text does not wait. **The cap beats every other rule**: once `silence_ms >= max_wait_ms`, the decision is not to wait, whatever the text says. `extra_ms` never exceeds what is left of the cap. The function is pure.

**UNAIDED CORE.** The cap, and its precedence. Without it a user who says "and" is never answered, and the bug presents as "the agent ignores me" rather than as a loop. Second: `extra_ms` clamped to the remaining budget rather than returned as a constant — a guard that can always add its full extension has no cap at all.

**Hidden tests:** `tests/hidden/test_appendix_d_a1.py`; run `ATLAS_TIER=F PYTHONPATH=. python -m pytest tests/hidden/test_appendix_d_a1.py -q`, or `make grade-all`. Do not read it. *(Validated: the reference passes 9 of 9; a submission with the word rules but no cap fails 2 of 9.)*

### Assignment 2 — diagnose the breakdown **[extended]**

Create `voice/budget.py`. Turn a list of `TurnTiming` into an answer to "what do I fix?"

**Acceptance criteria.** `FIXES` maps each segment on the path to first audio to its remedy. `diagnose(timings, *, min_samples=5)` returns a frozen `Diagnosis` with `dominant`, `share`, `fix`, `confident` and `note`. Below `min_samples` usable turns it returns `confident=False` with a note saying how many it had — **and it does not guess**. A usable turn is one with both anchors. `capture` and `full_agent_response` are never the dominant segment. A declared segment can be dominant. `share` is a fraction of p50 time-to-first-audio. Percentiles come from `atlas.obs.metrics`.

**UNAIDED CORE.** Excluding `capture` and `full_agent_response` from candidacy, and the refusal below the sample floor. The first is the difference between a diagnoser and a `max()`: capture is the user talking and will win every time. The second is Phase 13's floor — a p50 over three turns is a number, not a measurement.

**Hidden tests:** `tests/hidden/test_appendix_d_a2.py`. *(Validated: the reference passes 7 of 7; a version ranking every measured segment fails 2 of 7.)*

---

## 16. [core] Summary and key takeaways

*Self-contained. This appendix is optional and nothing after it depends on it.*

**Voice deletes the turn-boundary oracle, and four things fall out of the hole.** Nobody tells you the turn ended; the input is provisional; the user can talk over you; and silence is a message rather than an absence. None is a speech problem — all four are control-loop problems, which is why "speech-to-text plus an agent plus text-to-speech" is not an architecture but a sandwich.

**Endpointing is a latency you chose, not one you measured.** It is spent on every turn before any model runs, and no faster machine shortens it. Two thresholds rather than one, a minimum-speech window so a cough is not a request, a hangover that is a bet about a distribution of pause lengths, and a hard cap so a stuck detector truncates instead of hanging. The parameter is also a fairness parameter: the people a short hangover cuts off are disproportionately those who pause more.

**The committed assistant message is what the speaker got through, not what the model generated.** This is the one idea to carry away. At the moment of interruption the system holds two beliefs — what it produced and what the user heard — and writing down the wrong one produces an agent that refers back to sentences nobody was allowed to hear. Every utterance that played, the last one truncated at a word boundary, marked truncated, with the discard counted; tool results kept; thread kept. And two traps inside that: the prefix is not the last sentence, and a cut inside the first word commits nothing.

**Budget in proportions, measure from the user's last word, and check that the parts reach the total.** Time to first audio is the metric, underruns sit beside it with equal weight, and the anchor is backdated by the hangover — anchoring at the moment the endpointer fired makes silence free and produces a report that improves as the policy gets slower. Segments overlap, so the budget is a sum only if you built it as one. Find the dominant segment on the path to first audio, apply the one fix that belongs to it, re-measure.

**Build the instrument, then run it on your own work.** This appendix's first version shipped a breakdown with five unmeasurable segments, an underrun counter with no caller, and a barge-in monitor that could not fire — and the report looked the same as a working one. A metric that cannot move is worse than a missing metric, because it reads as evidence. Every one of those now has a test named after the defect.

**A tool call longer than a conversational pause has three honest answers** — narrate from the real `plan` event, defer to the job endpoint that already exists, or precompute for read-only tools only — and one dishonest one. Speculative execution is a constraint on tool design rather than on the speech stack: it requires that work be discardable until committed, which is Phase 10's rule from a new direction. **Irreversible actions are not approvable by voice alone**, because the approval channel has an error rate the button did not have and the errors are asymmetric; Atlas's client speaks the consequence, records `approval_required`, and says plainly that it cannot collect the decision.

**WER measures the transcriber and is blind to everything else.** Four metrics: task success, interruption handling, turn-taking errors in three buckets, and latency percentiles with n beside them. The four tasks here run in the Phase 13 harness without editing it, because the entrypoint matches a dispatch branch that already exists and the task file is deliberately not named `phase*.json`.

**The appendix is removable, and that was checked rather than claimed.** Its own tests live outside `tests/` because Phase 16 counts collected tests into a generated document. With `voice/` present, `make test-offline` is unchanged at 1,687 passed and 12 skipped.

**And the measurement.** One voice turn produces **1 trace, 1 root, 0 orphans** spanning the client process and the service, with the client's `voice.*` segment events on the root span and the server's `invoke_agent` span as its child. 27 offline tests, 16 hidden-test assertions across two assignments, 4 eval tasks at 4/4 pass^k on Tier F, 7 of 8 segments measurable end to end, no network, no model, no microphone. Every cell of your latency table is yours to fill in, and that is the exercise.

---

## 17. [core] Further reading

* **Full-Duplex-Bench**, Lin et al., ASRU 2025 (arXiv:2503.04721), with **v1.5** (arXiv:2507.23159), **v2** (arXiv:2510.07838) and **v3** (arXiv:2604.04847) adding overlap handling, an automated examiner, and tool use under real disfluent speech. The benchmark family to read before designing your own turn-taking metrics. Code and data: https://github.com/DanielLin94144/Full-Duplex-Bench *(checked 2026-09-15.)*
* **VoiceBench: Benchmarking LLM-Based Voice Assistants**, Chen et al. (arXiv:2410.17196), TACL. Capability evaluation for voice assistants rather than for transcribers. *(2026-09-15.)*
* **Stivers et al., "Universals and cultural variation in turn-taking in conversation"**, PNAS, 2009. The human anchor for §6.3: turn gaps measured across ten languages. *(2026-09-15.)*
* **OpenAI, Realtime API documentation** — session model, client and server events, WebRTC/WebSocket/SIP connection methods: https://developers.openai.com/api/docs/guides/realtime-conversations *(2026-09-15.)*
* **Google, Gemini Live API** — a stateful bidirectional WebSocket API with native audio output, ephemeral tokens for client-to-server use, and explicit VAD configuration: https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket *(2026-09-15.)*
* **Silero VAD** — MIT, a two-megabyte ONNX model, 8 and 16 kHz, sub-millisecond per frame on one CPU thread. Read the README for supported frame sizes before choosing `frame_ms`: https://github.com/snakers4/silero-vad *(2026-09-15.)*
* **LiveKit Agents — turn detection and VAD**: https://docs.livekit.io/agents/build/turns/vad, and **Pipecat's speech-to-speech services**: https://docs.pipecat.ai/api-reference/server/services/s2s/openai. The two dominant open framework philosophies, described by their own documentation. *(2026-09-15.)*
* **Microsoft, Azure OpenAI realtime audio** — the clearest vendor-neutral description of why a realtime API is not meant to connect directly to end-user devices, and what terminates the media: https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/realtime-audio *(2026-09-15.)*
* **Appendix E** for consent, recording and retention obligations; **Appendix B** for key handling and spend limits if you try a hosted realtime API.

---

## 19. [core] HANDOFF

### Appendix D additions

No file under `atlas/`, `scripts/`, `docs/` or `Makefile` is modified, and no existing test is changed.

```
voice/__init__.py                              (empty; marks the package)
voice/endpoint.py                              §6.4  — EndpointPolicy, Endpointer
voice/timing.py                                §7.2  — Segment, TurnTiming, LoopTimer,
                                                       render_breakdown
voice/cli.py                                   §7.3  — the push-to-talk client
voice/speech.py                                §7.4  — Transcript, Transcriber, SpeechHandle,
                                                       Speaker, FixtureTranscriber,
                                                       FixtureSpeaker, AdaptedTranscriber,
                                                       AdaptedSpeaker
voice/atlas_client.py                          §7.5  — SSEDecoder, AtlasVoiceClient, sentences
voice/loop.py                                  §7.6  — TERMINAL_OUTCOMES, BargeInMonitor,
                                                       Utterance, TurnRecord, VoiceSession
voice/evalscore.py                             §7.8  — SCENARIOS, serve_scenario
voice/run_appendix_evals.py                    §7.8  — driver over evals/run.py
voice/tests/test_voice_appendix_d.py           27 offline tests
tests/hidden/test_appendix_d_a1.py             Assignment 1 grader
tests/hidden/test_appendix_d_a2.py             Assignment 2 grader
evals/tasks/appendix_d.json                    4 tasks, NOT matched by the phase*.json glob
```

Commands (no new `make` target; the Makefile is core):

```
ATLAS_TIER=F PYTHONPATH=. python -m pytest voice/tests -q
ATLAS_TIER=F PYTHONPATH=. python -m pytest tests/hidden/test_appendix_d_a1.py -q
ATLAS_TIER=F PYTHONPATH=. python voice/run_appendix_evals.py --trials 3
PYTHONPATH=. python voice/cli.py --asr-model ... --tts-voice ...
```

**Interfaces consumed, not changed:** `POST /v1/chat/stream`; the `start`/`plan`/`tool`/`token`/`approval`/`done`/`error` vocabulary, the `source` field on `token` and the `phase: "end"` on `tool`; `atlas.api.sse.AGENT_EVENTS` and `AgentEvent`; `atlas.obs.spans.{Tracer, use_tracer, current_traceparent}`; `atlas.obs.metrics.percentile`; `atlas.obs.semconv`; `atlas.api.service.build_atlas_api`; `atlas.auth.tokens.issue_token`; `evals.run.{load_tasks, run_trial, summarise, format_report, make_client_factory, judge_client_for}` and its `:serve_scenario` dispatch branch.

**One gap named and not closed:** there is no approval-response endpoint, so the client can speak a consequence and cannot collect a decision. The smallest additive fix would be `POST /v1/threads/{thread_id}/approvals` plus a resume through the checkpointer; it is not built here because Appendix D does not change the core.

### VERSIONS.md delta rows

| Fact | Value | Source | Checked |
|---|---|---|---|
| Hosted realtime API — connection methods | WebRTC, WebSocket, or SIP; the API is not designed to connect directly to end-user devices, so a client integration terminates the media | https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/realtime-audio | 2026-09-15 |
| OpenAI Realtime API — current guide | speech-to-speech conversations over WebRTC or WebSocket, client/server event model, remote MCP servers and image input | https://developers.openai.com/api/docs/guides/realtime-conversations | 2026-09-15 |
| OpenAI full-duplex voice model, in the API | **GPT-Live-1**, released **10 Sep 2026**; listens and speaks simultaneously; **$0.05 per minute for the voice layer only**, backend reasoning model and tools billed separately; supports telephony | https://openai.com/index/introducing-gpt-live-1-in-the-api/ | 2026-09-15 |
| OpenAI realtime audio model line | GPT-Realtime-2, GPT-Realtime-Translate, GPT-Realtime-Whisper, announced **7 May 2026** | https://openai.com/index/advancing-voice-intelligence-with-new-models-in-the-api/ | 2026-09-15 |
| Google Gemini Live API | stateful bidirectional WebSocket; audio/video/text in, native audio out; explicit VAD toggle; ephemeral tokens required for client-to-server use | https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket | 2026-09-15 |
| **VAD for `voice/cli.py`** | **Silero VAD** — MIT, ONNX ≈2 MB, 8/16 kHz, trained on 30 ms chunks, <1 ms per chunk on one CPU thread. **Read its README for supported frame sizes before setting `frame_ms`** | https://github.com/snakers4/silero-vad | 2026-09-15 |
| Semantic end-of-turn models (Assignment 1's real-world counterpart) | Pipecat Smart Turn v2 model card; LiveKit recommends VAD plus a turn-detector model together | https://huggingface.co/pipecat-ai/smart-turn-v2 · https://docs.livekit.io/agents/build/turns/vad | 2026-09-15 |
| Streaming ASR for a no-GPU laptop | Moonshine streaming variants — variable-length encoder, sliding-window attention for lower time-to-first-token; English weights MIT, non-English under a community licence (check before commercial use) | https://huggingface.co/Synaptics/moonshine-streaming-tiny-torq | 2026-09-15 |
| ASR landscape survey (vendor blogs — orientation, not measurement) | Whisper large-v3 as the multilingual default; Parakeet TDT and Canary-Qwen for English streaming; Moonshine for edge. **Benchmark two on your own audio before choosing** | https://www.assemblyai.com/blog/top-open-source-stt-options-for-voice-applications · https://northflank.com/blog/best-open-source-stt-model-in-2026-benchmarks | 2026-09-15 |
| CPU-class TTS | Kokoro-82M — Apache-2.0, 82 M parameters, runs on CPU, faster than real time; linked from its model card | https://github.com/hexgrad/kokoro | 2026-09-15 |
| WebRTC / telephony frameworks | LiveKit (WebRTC SFU + agents SDK + native SIP) and Pipecat (transport-agnostic pipeline); third-party SIP/RTP transports exist as drop-in plugins for both | https://docs.livekit.io/agents/build/turns/vad · https://docs.pipecat.ai/api-reference/server/services/s2s/openai · https://pypi.org/project/agent-transport/ | 2026-09-15 |
| Voice-agent benchmarks | Full-Duplex-Bench v1–v3 (turn-taking, overlap, automated examiner, tool use under disfluency); VoiceBench (assistant capability) | https://github.com/DanielLin94144/Full-Duplex-Bench · https://arxiv.org/abs/2410.17196 | 2026-09-15 |
| Local VLMs for document understanding (§7.9) | small general VLMs and sub-billion-parameter document-parsing VLMs both viable on a laptop; licences vary per model | https://tinyweights.dev/posts/best-local-vision-language-models-2026/ · https://blog.roboflow.com/best-open-source-ocr-models/ | 2026-09-15 |
| Appendix D extra Python packages | `sounddevice`, `numpy`, `onnxruntime`, plus your chosen ASR/TTS packages. **Deliberately unpinned here** — install them, then record the versions you actually got in your own VERSIONS.md | https://pypi.org/pypi/&lt;package&gt;/json | 2026-09-15 |
| Tier H calls, this appendix | **0.** Nothing here needs a hosted model; the hosted realtime rows above are comparison material | — | 2026-09-15 |
| Audio provenance watermarking | being deployed on generated audio by major providers alongside public verification tooling; a mitigation for §7.10's impersonation surface, not a solution | https://openai.com/index/introducing-gpt-live-1-in-the-api/ | 2026-09-15 |

### Measured this appendix (Tier F, seed 7, 2026-09-15)

| Quantity | Value | Printed by |
|---|---|---|
| Appendix offline tests | **27 passed** (17 behavioural + 10 regression tests, one per defect found) | `pytest voice/tests -q` |
| Hidden-test assertions | **16 passed** against the references; 4 fail against the naive submissions | `pytest tests/hidden/test_appendix_d_a*.py -q` |
| Appendix eval tasks | **4**, pass^k 4/4, pass@k 4/4 | `python voice/run_appendix_evals.py` |
| Core suite with `voice/` present | **1,687 passed, 12 skipped** — unchanged | `make test-offline` |
| One voice turn, cross-process | **1 trace, 1 root, 0 orphans** | §8 |
| Segments measurable end to end | **7 of 8**; `tool_call` needs a tool-calling route | `pd-c` |
| Every latency cell in §7.7 | **yours** | your laptop |
