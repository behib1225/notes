# VERSIONS.md — Appendix D delta rows

Paste these into your own VERSIONS.md. Current-state facts only: every row
carries a source URL and a checked-on date, and none of them appears in the
prose of appendix_d.md. Re-verify before you start — realtime APIs and
open-weight speech models move faster than anything else in this book.

| Fact | Value | Source | Checked |
|---|---|---|---|
| Hosted realtime API — connection methods | WebRTC, WebSocket, or SIP; the API is not designed to connect directly to end-user devices, so a client integration terminates the media | https://learn.microsoft.com/en-us/azure/foundry/openai/how-to/realtime-audio | 2026-09-15 |
| OpenAI Realtime API — current guide | speech-to-speech conversations over WebRTC or WebSocket, client/server event model, remote MCP servers and image input | https://developers.openai.com/api/docs/guides/realtime-conversations | 2026-09-15 |
| OpenAI full-duplex voice model, in the API | **GPT-Live-1**, released **10 Sep 2026**; listens and speaks simultaneously; **$0.05 per minute for the voice layer only**, backend reasoning model and tools billed separately; supports telephony | https://openai.com/index/introducing-gpt-live-1-in-the-api/ | 2026-09-15 |
| OpenAI realtime audio model line | GPT-Realtime-2, GPT-Realtime-Translate, GPT-Realtime-Whisper, announced **7 May 2026** | https://openai.com/index/advancing-voice-intelligence-with-new-models-in-the-api/ | 2026-09-15 |
| Google Gemini Live API | stateful bidirectional WebSocket; audio/video/text in, native audio out; explicit VAD toggle; ephemeral tokens required for client-to-server use | https://ai.google.dev/gemini-api/docs/live-api/get-started-websocket | 2026-09-15 |
| **VAD for `voice/cli.py`** | **Silero VAD** — MIT, ONNX ≈2 MB, 8/16 kHz, trained on 30 ms chunks, <1 ms per chunk on one CPU thread. **Read its README for supported frame sizes before setting `frame_ms`** | https://github.com/snakers4/silero-vad | 2026-09-15 |
| Semantic end-of-turn models (Assignment 1's real-world counterpart) | Pipecat Smart Turn v2 model card; LiveKit recommends VAD plus a turn-detector model together | https://huggingface.co/pipecat-ai/smart-turn-v2 · https://docs.livekit.io/agents/build/turns/vad | 2026-09-15 |
| Streaming ASR for a no-GPU laptop | Moonshine streaming variants — variable-length encoder, sliding-window attention for lower time-to-first-token; English weights MIT, non-English under a community licence (check before commercial use) | https://huggingface.co/Synaptics/moonshine-streaming-tiny-torq | 2026-09-15 |
| ASR landscape survey (vendor blogs — orientation, not measurement) | Whisper large-v3 as the multilingual default; Parakeet TDT and Canary-Qwen for English streaming; Moonshine for edge. **Benchmark two on your own audio before choosing** | https://www.assemblyai.com/blog/top-open-source-stt-options-for-voice-applications · https://northflank.com/blog/best-open-source-stt-model-in-2026-benchmarks | 2026-09-15 |
| CPU-class TTS | Kokoro-82M — Apache-2.0, 82 M parameters, runs on CPU, faster than real time; linked from its model card | https://github.com/hexgrad/kokoro | 2026-09-15 |
| WebRTC / telephony frameworks | LiveKit (WebRTC SFU + agents SDK + native SIP) and Pipecat (transport-agnostic pipeline); third-party SIP/RTP transports exist as drop-in plugins for both | https://docs.livekit.io/agents/build/turns/vad · https://docs.pipecat.ai/api-reference/server/services/s2s/openai · https://pypi.org/project/agent-transport/ | 2026-09-15 |
| Voice-agent benchmarks | Full-Duplex-Bench v1–v3 (turn-taking, overlap, automated examiner, tool use under disfluency); VoiceBench (assistant capability) | https://github.com/DanielLin94144/Full-Duplex-Bench · https://arxiv.org/abs/2410.17196 | 2026-09-15 |
| Local VLMs for document understanding (§7.9) | small general VLMs and sub-billion-parameter document-parsing VLMs both viable on a laptop; licences vary per model | https://tinyweights.dev/posts/best-local-vision-language-models-2026/ · https://blog.roboflow.com/best-open-source-ocr-models/ | 2026-09-15 |
| Appendix D extra Python packages | `sounddevice`, `numpy`, `onnxruntime`, plus your chosen ASR/TTS packages. **Deliberately unpinned here** — install them, then record the versions you actually got in your own VERSIONS.md | https://pypi.org/pypi/&lt;package&gt;/json | 2026-09-15 |
| Tier H calls, this appendix | **0.** Nothing here needs a hosted model; the hosted realtime rows above are comparison material | — | 2026-09-15 |
| Audio provenance watermarking | being deployed on generated audio by major providers alongside public verification tooling; a mitigation for §7.10's impersonation surface, not a solution | https://openai.com/index/introducing-gpt-live-1-in-the-api/ | 2026-09-15 |

## Re-verification checklist

Before you build, check these four in this order, because each one can
invalidate the work below it:

1. **Your VAD's supported frame sizes.** `EndpointPolicy.frame_ms` defaults to
   30 because that is what the common small models are trained on. Feeding a
   model a frame length it never saw degrades it silently.
2. **Your ASR's expected sample rate and licence.** `AdaptedTranscriber`
   refuses a mismatch rather than resampling; several of the best non-English
   models are non-commercial.
3. **Your TTS's real-time factor on a paragraph, not a sentence.** A
   synthesiser slower than real time cannot stream without underrunning.
4. **Whether the hosted realtime rows still describe one product.** They are
   comparison material for §6.2 and nothing here depends on them.
