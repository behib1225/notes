# phase_05_solutions.md

Worked answers for Phase 5 — Agentic Workflow Patterns and the Cost Model.
Read these after attempting the questions; the value is in the gap between
your answer and this one, not in this one.

---

## Section 2 — Cumulative review (Phases 2 and 3)

**1. `choose_output_mode("schema", "json")` → `"json"`; `UnsupportedOutputMode`
is degrade-not-retry.** The function picks the *highest rung of the ladder both
the caller wanted and the backend supports*, so asking for a JSON Schema from a
backend that only offers JSON mode returns `"json"` — the request is downgraded
rather than refused. `UnsupportedOutputMode` means the *capability is absent*,
so retrying the identical request cannot change the outcome; the remedy is to
try a lower rung. Retry and degrade must be different remedies because they
recover from different things: a transport error is a fact about this moment
(retry), a missing capability is a fact about the backend (degrade). One generic
error forces the caller to guess, and the usual guess is a retry loop that
spends a budget re-asking a question that has already been answered.

**2. `structured()` as a module-level function.** It makes the *repair loop*
testable with `FakeLLMClient`: script an invalid payload followed by a valid
one, call `structured()`, and assert that exactly two calls were made, that the
second carried the validation error, and that `repairs == 1` — with no network
and no subclass. As a method on `LLMClient` it would exist once per client
implementation, so testing the loop would mean either instantiating a real
client or writing a fake that reimplements the loop being tested.

**3. `execute()`'s four checks, in order: existence, arguments, authority,
dispatch.** In a batch of three where the first names a nonexistent tool,
**none of the three runs.** `unknown_tool_names()` validates the whole batch
before anything dispatches — invariant 24 — because a side effect from an
episode that is about to be abandoned is the worst available outcome.

**4. `data/atlas_query.db` versus `data/atlas.db`.** The query database
contains only the curated read-only views (`v_departments`, `v_shipments`,
`v_warranty`); the base tables do not exist in it. This implements
**invariant 20**: a prohibition is implemented as an absent capability wherever
it can be. The SQL tool cannot read a table that is not in the file it is
pointed at, which is a stronger guarantee than any query inspection, and
`is_read_only_sql` is then the second line rather than the only one. See D-08
and F-03-04.

**5. `--append-results` refuses a sweep containing a replayed trial.** What is
protected is the *meaning of the numbers in `docs/RESULTS.md`*: that file
claims to record model behaviour on a tier, and a replayed fixture is Atlas's
own recorded past, not the model's present behaviour. "The tier I asked for" is
the wrong thing to record because provenance is a property of **what happened**,
not of what was requested — an `ATLAS_TIER=A` run that fell back to a recording
produced Tier F numbers under a Tier A label, which is the one error a results
file cannot survive. See D-14, invariant 25.

---

## Concept checks

**5.1 — Seven exits, one model-owned.** The stop reason records *who decided the
episode was over*, and six of the seven are decided by the harness (a cap, a
budget, a guard, a parse failure). So "one model-owned exit" says the model
controls termination in exactly one way — by producing a well-formed final
answer — and every other way out is a line of Python. It is a statement about
control-flow ownership rather than safety because a *safety* claim would need to
say what the model can *do* (the registry, `allow_writes`), whereas this says
only who gets to stop.

**5.2 — What "90% accurate" does not tell you.** It does not tell you *which*
10% is wrong, and the errors are not equally expensive: a `chat`→`research`
misroute costs tokens, a `data`→`chat` misroute costs a fluent unsourced
answer, and a `document`→`tool_action` misroute could write a file. The extra
number you need is the **confusion matrix** — specifically the rate of
misroutes *into* cheaper and side-effecting handlers. (A good second answer:
the traffic mix, because 90% accuracy on a set that is 80% `chat` may mean the
classifier has learned to say `chat`.)

**5.3 — `validate_plan` on an orchestrator's output.** Two it gives free: a
step naming a tool that is not in the registry, and a dependency cycle (it runs
`topological_order`). Also available: a `depends_on` pointing at a step id that
does not exist, and a step count over the cap. What it does **not** produce is
an *edge compatibility* complaint — that step `s4`, which consumes `s3`, wants
a kind of input `s3` does not produce. `expects` describes what a step
*produces* and nothing describes what a step *consumes*, so the check verifies
each edge's tail and never its head. That is Phase 4's §8 failure and Phase 4
Assignment 1.

**5.4 — Two `query_db` calls with the same SQL.** With the ledger and key: the
first step runs (one model call for the worker plus one database query); the
second finds a completed record under the same idempotency key and **replays**
it — zero model calls attributable to the work, zero database queries, and a
`"replayed"` record with no token counts. So: two worker model calls only if
the *steps* differ in their prompts; one database query either way. Change the
tool to `current_time` and the cache must **refuse**: the answer changes over
time, so a replay returns a stale value. The property the answer depends on is
**determinism**, which is different from `read_only`, and D-26 puts it on the
spec as `cacheable`.

**5.5 — Cascade at $c_s/c_l = 1/5$, $f = 0.3$.** (a) Break-even is $f > 0.2$
and $0.3 > 0.2$, so yes: expected cost is $1 + 0.7 \times 5 = 4.5$ against 5,
a 10% saving. Thin. (b) If the escalation test misses one third of the cheap
tier's failures, then of the 70% the cheap tier got wrong, 23.3% are *not*
escalated and ship as-is. Accuracy relative to always-capable falls by roughly
that 23 points, and cost falls further (you escalate less), which is the trap:
**a worse verifier looks like a bigger saving.** Report accuracy first — a 10%
saving that costs 23 points of accuracy is not a saving, and the honest headline
is cost per *successful* request, which got worse.

**5.6 — Four branches, timeout 20 s, deadline 30 s, limit 2.** Branches 1 and 2
start at $t=0$; say branch 1 hangs and branch 2 finishes at 3 s, letting
branch 3 start; branch 3 finishes at 6 s and branch 4 starts, finishing at 9 s.
Branch 1 is still hanging. At $t=20$ its **per-branch timeout** fires, and it
comes back `kind="timeout"`. The whole fan-out returns at ~20 s, so the
**deadline never fires**. The reduce receives four `BranchResult`s in argument
order: three `ok`, one `timeout`, with `failures == ["b1:timeout"]` and
`partial == True`. Change the hang to 40 s and the deadline fires at 30 s, the
hung task is cancelled, and it is recorded as a deadline timeout — the three
completed payloads are still returned, which is the property the deadline path
was written to preserve.

---

## Section 13 — Quiz

**1. Which question.** *What runs next?* In a workflow the answer is in the
code and identical on every request, so it can be asserted in a test: dependency
order, exits, budgets. In an agent the answer comes from a model, so it can only
be *bounded* in a test (a step cap, a closed `StopReason`, a scoped registry)
and *measured* in `docs/RESULTS.md`. This is why invariant 1 exists: the tests
own the part that is code, and the results file owns the part that is a model.

**2. "Double-check your answer before responding."** The mechanism is not a
gate: a gate is code, a different model with a new signal, or a tool. Asking the
same model to inspect its own output adds no information, and Huang et al.
(arXiv:2310.01798) measured the result — intrinsic self-correction *lowered*
accuracy, with 8.8% of correct answers becoming incorrect against 7.6% the
other way. So the true $q$ may be negative and §6.2's arithmetic does not apply.
The measurement is also wrong twice over: nothing changed the *call count*, so
by Phase 4's counting rule this is a prompt change and belongs in a measured
A/B with a fixed token cap; and "reliability improved" on an unstated sample
with one run per arm cannot distinguish an effect from noise (at a true rate of
0.6, eight problems give a standard error of ~17 points).

**3. Sectioning versus voting.** Sectioning requires **independence** — no
branch's input depends on another's output. Voting requires **comparability** —
an extractor that turns a completion into a countable value, plus temperature
above zero and $k\times$ the tokens. A task satisfying neither: "read these six
notes and write a single narrative brief where each section depends on what the
previous one concluded." Dependencies rule out sectioning; a prose brief has no
extractable answer to vote on. That is a chain.

**4. $c_s/c_l = 1/8$, $f = 0.2$.** Break-even is $f > 0.125$, and $0.2 > 0.125$,
so on cost alone: $1 + 0.8 \times 8 = 7.4$ against 8, about 7.5% saved. Ship it?
No — not on that number alone. The margin is thin enough that any verifier
leakage erases it, and the arithmetic assumes escalation is *free and perfect*.
The single measurement that changes the answer is the **escalation test's miss
rate**: what fraction of the cheap tier's failures pass verification. If it is
near zero the cascade is fine and you should also test raising $f$ with a better
cheap prompt; if it is 20% you are shipping wrong answers to buy 7.5%.

**5. `return_exceptions=False` in cost terms, and what the trace looks like.** The first raising branch
propagates out of `gather` immediately, but the other three tasks are **not
cancelled** — they run to completion in the background with nobody awaiting
their results. So you pay for four branches, receive one exception, and discard
three completed answers. Worse, the caller's `except` typically retries the
whole fan-out, so the bill is eight branches for four branches' worth of
information. In correctness terms it is a lost result; in cost terms it is a
doubling with no signal that anything was wasted.

And the trace is the part worth memorising: **nothing in it is wrong — a line
is missing.** The fan-out reports three branches where the plan had four, no
failure, no timeout, no note, and `partial: False`, because that flag was
computed from the branches that survived the filter. A label derived from a
filtered collection is a label about the filter. The cheapest guard is an
assertion nobody thinks to write: a fan-out whose branch count differs from its
input count is a bug, unconditionally.

**6. Three redundant fields.** `model_route`, `keyword_hint` and `confidence`
are not needed to execute — `route` alone selects the handler. They are recorded
because: `model_route` is what the *classifier* said, which is the only way to
grade the classifier separately from the resolution rule (the routing-accuracy
eval task reads it); `keyword_hint` plus its confidence is what makes
`disagreed` computable, and the disagreement rate is the diagnostic that tells
you whether your threshold is doing anything; and `confidence` is what makes the
threshold auditable — without it you cannot plot accuracy against confidence,
and a threshold you have not plotted is a random number. Together they implement
**corollary 1 of the hard-code rule: a delegated decision must be recorded as
data**, or it cannot be graded, measured, or regression-tested.

---

## Section 8 — the two failures, and why part one is easier

Part one (the dropped failure) is a *harness* bug: one keyword, one structure,
and a test that scripts branch two to raise and asserts branches one and three
still appear. It is easy to fix and hard to *see*, because the evidence is an
absence.

Part two (the branch that succeeded and said nothing) is the opposite: easy to
see once you read the payload, and hard to fix, because the fix requires
deciding what "evidence" means. `(no results)` is well-formed text; a truncated
table is a well-formed table. No shape check can separate them from real
results, which is §6.2's arithmetic restated — for that failure class, q = 0
for any gate that checks shape. Assignment 1 is where you decide the predicate.

The pedagogical point of pairing them: **a fixed harness can still be misused,
and the second bug is invisible until the first is fixed.** If you debug the
empty-branch failure while `gather` is still dropping exceptions, you will
conclude the pipeline is fine and the model is bad.

## Assignment 1 — Close the §8 gap

**The predicate.** The core is a pure function with an explicit list of
markers. The design decision worth defending is that the marker list is
*Atlas's own* — the strings its tools actually emit — rather than a general
"looks empty" heuristic:

```python
NO_RESULT_MARKERS = frozenset({
    "", "none", "n/a", "na", "null", "no results", "(no results)",
    "0 rows", "no rows", "empty", "nothing found",
})

def usable_payload(payload: str) -> tuple[bool, str]:
    """Whether a SUCCESSFUL result actually constitutes evidence. Pure."""
    text = (payload or "").strip()
    if not text:
        return False, (
            "the tool succeeded and returned nothing. Treat this step as "
            "having no result: do not describe the absence as a finding."
        )
    flat = text.lower().strip(".!() ")
    if flat in NO_RESULT_MARKERS:
        return False, (
            f"the tool succeeded and returned {text!r}, which is an empty "
            "result. Say that the data is unavailable rather than reporting "
            "an absence as a finding."
        )
    lines = [ln for ln in text.splitlines() if ln.strip()]
    if len(lines) == 1 and "|" in lines[0] and not any(ch.isdigit() for ch in lines[0]):
        return False, (
            "the result is a header row with no data rows. Re-run the query "
            "or report that the table is empty."
        )
    return True, ""
```

Note what is *not* here: a length threshold. "363" is three characters and is a
complete answer, so any minimum-length rule rejects correct results. And note
that `"0 rows"` is rejected here while D-16's `check_result_kind` **accepts** it
— those are different questions and the difference is the whole assignment.
`check_result_kind` asks *is this the right shape*, and an empty result set is
a well-formed table; `usable_payload` asks *is this evidence*, and it is not.
Two predicates, two questions, and conflating them is what produced §8.

**Wiring.** In `_run_worker`, after the shape check:

```python
    shape_ok, complaint = check_result_kind(step.expects, content or "")
    has_content, empty_note = usable_payload(content or "")
    result.truncated = any(r.truncated for r in results)   # from ToolResult
    result.shape_ok = shape_ok
    result.payload = (content or "").strip()
    result.ok = shape_ok and has_content and not (
        result.truncated and step.expects == "rows"
    )
    if not result.ok:
        result.note = complaint or empty_note or (
            "the result was truncated, so a total computed from it would be "
            "wrong. Narrow the query and try again."
        )
```

The `expects == "rows"` condition on truncation is the judgement call: a
truncated table is a *wrong total*, whereas a truncated prose summary is merely
a shorter summary. Making truncation fail every step would send the pipeline
into retries on `text` steps that were fine.

**`partial`, widened:**

```python
    @computed_field
    @property
    def truncated_steps(self) -> list[str]:
        return [w.step_id for w in self.workers if w.truncated]

    @computed_field
    @property
    def partial(self) -> bool:
        return bool(
            self.failed_steps
            or self.truncated_steps
            or (self.plan is not None and not self.plan.is_complete)
        )
```

`truncated_steps` includes truncated `text` steps that *passed*, which is
deliberate: a truncated result is a caveat on the answer even when it did not
fail the step. That is the difference between "this step failed" and "this
answer rests on incomplete evidence", and `partial` is the second question.

**Why `p05-fanout-labels-a-dropped-branch` still passes.** Its second worker
returns prose where a number was required, so it fails on *shape* as before;
the new predicate adds a path, it does not change that one. A student whose
change breaks that task has usually made `usable_payload` reject ordinary prose.

---

## Assignment 2 — The cascade

**The escalation test is the assignment.** A defensible `verify` for Atlas's
`data` route: the payload parses as a number *and* the step's arithmetic
recomputes (via `calculate`) *and* the figure appears in a tool result rather
than only in prose. What it cannot catch: a correct-looking figure computed from
the wrong rows — which is Phase 4's §8 failure, and the docstring must say so.

**Skeleton, with the accounting that the hidden tests check:**

```python
CascadeStopReason = Literal["cheap_accepted", "capable_accepted", "both_failed"]

class CascadeResult(BaseModel):          # no extra="forbid" (D-19)
    task: str
    payload: str | None = None
    tier_used: Literal["cheap", "capable"] | None = None
    escalated: bool = False
    stop_reason: CascadeStopReason = "both_failed"      # fail closed
    notes: list[str] = Field(default_factory=list)
    ledger: Ledger
    @computed_field
    @property
    def total_tokens(self) -> int:
        return self.ledger.total_tokens

def run_cascade(task, cheap, capable, *, verify, run_id="cascade") -> CascadeResult:
    ledger = Ledger(run_id=run_id)
    for name, produce in (("cheap", cheap), ("capable", capable)):
        output = produce(StageInput(task=task, payload="", complaint=note))
        ledger.append(StepRecord(run_id=run_id, step=name, ...))   # billed either way
        if output.ok:
            accepted, note = verify(output.payload)
            if accepted:
                return CascadeResult(
                    task=task, payload=output.payload, tier_used=name,
                    escalated=(name == "capable"),
                    stop_reason=f"{name}_accepted", ledger=ledger, notes=notes,
                )
    return CascadeResult(task=task, stop_reason="both_failed", ledger=ledger, notes=notes)
```

Two things the hidden tests are looking for. **Both tiers are billed on an
escalation** — the cheap attempt's tokens stay in the ledger, because the whole
point of the break-even condition is that you paid for it. And `escalated` is
`True` whenever the capable tier ran, *including* when the cheap tier errored
rather than failed verification; those are different causes with the same
accounting consequence, and the cause belongs in `notes`.

**`cascade_report`:**

```python
def cascade_report(results: Sequence[CascadeResult]) -> dict[str, float]:
    n = len(results) or 1
    escalations = sum(r.escalated for r in results)
    cheap = [r.ledger.records[0].total_tokens for r in results if r.ledger.records]
    capable = [r.ledger.records[1].total_tokens for r in results
               if len(r.ledger.records) > 1]
    c_s = sum(cheap) / len(cheap) if cheap else 0.0
    c_l = sum(capable) / len(capable) if capable else 0.0
    return {
        "escalation_share": escalations / n,
        "observed_f": 1.0 - escalations / n,
        "break_even_f": cascade_break_even(c_s, c_l) if c_l else 1.0,
    }
```

`observed_f` is `1 − escalation_share` **as measured by your verifier**, and
that is the caveat to write in `docs/RESULTS.md`: it is the fraction the
verifier *accepted*, not the fraction that was *right*. If your verifier is
lenient, `observed_f` is optimistic and the cascade looks better than it is —
which is the same failure as §6.9's, restated in your own numbers.

---

## Section 15 — Case study: one defensible design

**Shape.** Ingest → **route on format** (text body / native-text PDF / scanned
image) and **on supplier** (regular twelve / everything else). Each route runs a
**chain with gates**: extract → validate → PO-match → post. **Sectioning** only
inside the scanned route, where OCR of page $n$ is independent of page $m$. An
**evaluator-optimizer** only on the anomaly queue's summaries, which a human
reads. **No voting anywhere**: the extraction targets are numbers with an
arithmetic check available, and a check beats an ensemble at a fraction of the
cost (Phase 4's §6.6).

**Cost.** With $C$ tokens/month and 4,000 invoices, the ceiling is $C/4000$ per
invoice, and a 30% December spike means designing to $C/5200$. The twelve
regular suppliers get a **template-first** path: a deterministic parser tried
before any model call, so ~70% of volume can cost *zero* model tokens on the
happy path, with the model as the fallback when the parser's checks fail. That
is a cascade whose cheap tier is not a model at all, and it is the single
highest-leverage decision in the design — it changes $k$, not $\bar{p}$. The
remaining 30% runs a cheap-model-then-capable cascade with $f$ measured, not
assumed; break-even is computed from the measured token ratio. December is
absorbed by **deferral**: non-urgent invoices from irregular suppliers queue to
the next billing period, which is a mechanism with a stated cost (later posting)
rather than a hope.

**Escalation test.** Line items sum to the subtotal; tax recomputes at the
supplier's rate; the total matches; the PO exists and its remaining balance
covers the invoice; the invoice number is not already posted for that supplier
(the duplicate check, which is an idempotency key on `(supplier_id,
invoice_number)`). Any failure escalates; two failures route to the human
queue. **What it cannot catch:** a well-formed invoice for goods never received,
and a supplier bank-detail change — the second is a fraud vector no arithmetic
check sees, and it belongs in a separate always-human rule.

**Failure policy per stage.** Extraction: partial, labelled (a missing line item
is a queue item, not a failure). Validation: all-or-nothing (a subtotal that
does not reconcile is not partially usable). PO-match: partial (an unmatched
invoice queues). Posting: **all-or-nothing, last, idempotent, and gated** — no
compensation, because a reversing journal entry is a second transaction that an
auditor sees, and "we undid it" is not the same as "it did not happen".

**Dashboard.** (1) Cost per **successfully posted** invoice, which resists
gaming — a route that abandons work looks good on cost-per-call and honest here.
(2) Mis-post rate, measured by sampling 50 posted invoices a month against
source documents, *not* by counting complaints, because complaints are a lower
bound. (3) Human-queue rate with its own cost, since the queue is the fallback
and a design that hits the ceiling by queueing 40% of invoices has moved the
cost rather than removed it.

**Build first, in a week.** The template parser plus the arithmetic verifier for
the twelve regular suppliers — no model in the loop at all. It removes ~70% of
volume from the token budget, it produces the labelled dataset that lets you
measure everything else, and it is the component whose failure mode is a
parse error rather than a plausible wrong number. Every model decision after
that is made with data instead of with intuition.
