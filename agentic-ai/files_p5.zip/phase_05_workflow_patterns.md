# Phase 5 — Agentic Workflow Patterns: Chaining, Routing, Parallelization, Orchestrator-Workers, Evaluator-Optimizer — and the Cost Model

`standard · 13 h (5 read / 5 build / 3 assess) · Tier A: 231 calls per default sweep (run `make plan`) · Tier H: ≤100 · $0.00 · case study: yes`

---

## 1. [core] Phase header

| | |
|---|---|
| Study hours | 13 h — 5 read / 5 build / 3 assess |
| Compute time (baseline laptop: 16 GB RAM, no discrete GPU) | `make test-offline`: seconds, no model, no network. `make results ARGS=--quick`: ~15 min. Full sweep: 25–45 min, unattended. *Author estimate, unmeasured.* |
| Tier A calls per full eval sweep | **231** for the default 3-trial sweep; ~80 with `--quick`. The script prints its own budget before spending anything: `make plan`. |
| Tier H calls | ≤100, cached to `data/cache/`, never required by any test |
| Cost | $0.00 outside Appendix B |
| Repo tag at the end | `phase-05` |

**Confirm your starting state before reading on.** Unzip `atlas_phase_04.zip`, then:

```
make test-offline        # expect: 536 passed
make evals-list          # expect: 27 tasks defined, 26 gradeable offline
```

If those numbers differ you have diverged, and §11 opens with the instruction that covers it. Everything in this phase is additive: no interface listed in `ATLAS_INTERFACES.md` v0.10 is renamed, and exactly one is widened by an addition that §11 documents with a migration note.

---

## 2. [core] Cumulative review

Five questions from Phases 2 and 3. Answers in `phase_05_solutions.md`. Do them first — this phase composes what those two built, and a shaky answer here becomes a confusing hour in §7.

1. `choose_output_mode("schema", "json")` returns `"json"`, and `UnsupportedOutputMode` is documented as *degrade, do not retry*. Explain both in one sentence each, then say why "degrade" and "retry" must be different remedies rather than one generic error.
2. `structured()` is a module-level function, not a method on `LLMClient`. Name the one test this makes possible that would otherwise need a network or a subclass.
3. `execute()` never raises; it performs four checks in a fixed order. List them in order, then say what happens to the other two calls in a batch of three when the first names a tool that does not exist — and name the invariant that answers it.
4. `make_sql_tool` is pointed at `data/atlas_query.db`, not `data/atlas.db`. What is the difference between the two files, and which invariant is the choice implementing?
5. `--append-results` refuses to write `docs/RESULTS.md` when any trial replayed a recorded fixture, even when the tier was requested as `A`. What exactly is being protected, and why is "the tier I asked for" the wrong thing to record?

---

## 3. [core] Why this phase matters

Phase 4 gave you four ways to spend model calls and one honest measurement of them. It also left you uncomfortable: the elaborate arm did not obviously win, the arm with *no database access* scored 75% on database questions until the grader was fixed, and the phase's most useful output was a rule — a strategy that has not been compared to the cheapest thing that could work has not been measured.

This phase is what you do with that discomfort. It adds no new agent loop. It contains the five shapes production systems are actually made of, and the arithmetic that decides between them.

Three things change in Atlas.

**Atlas stops treating every request the same way.** Today, whatever a user asks, Atlas runs whichever strategy the calling script chose. "What is our warranty window?" and "Compare shipment volume across regions and write me a brief" cost the same. From this phase a **router** classifies the request into one of five kinds and *code* — not the model — dispatches to a handler sized for that kind. That is the highest-leverage change available to a system like this, and it is also where most teams introduce their first silent failure, so §6.3 and §8 spend real time on it.

**Cost becomes a number Atlas reports rather than something you find out about.** By the end, every episode carries a per-request cost estimate derived from measured token counts and a rate card *you* fill in with a checked-on date. No prices appear in this document. The method does: token accounting, model tiering with the algebra worked out, early exits, tool-result caching, and a cascade break-even condition that fits on one line and settles arguments.

**Atlas learns to do several things at once without lying about it.** Section 6.4 is parallelization; §7.5 builds an async fan-out with a measured speed-up; §8 debugs a fan-out that lost a branch and produced a confident, cheap, wrong report. That is the reason this phase sits here: parallelism is the first pattern where the *harness*, not the model, is the liar.

There is a fourth reason, about Phase 9. Every pattern here is a fixed arrangement of nodes, edges and state, hand-written in plain Python. LangGraph will not teach you anything new about the *shapes*; it will give you a runtime for them. Students who meet the graph framework before hand-rolling a fan-out with a semaphore, a gate that early-exits and an append-only ledger tend to learn the framework's vocabulary instead of the ideas. Section 6.12 makes the mapping explicit so Phase 9 is a port, not a revelation.

---

## 4. [core] Learning objectives

By the end of this phase you will be able to:

1. **Name and draw** the five composable workflow patterns (chaining with gates, routing, parallelization by sectioning and by voting, orchestrator-workers, evaluator-optimizer) and state, for each, the condition under which it is the right choice.
2. **Apply a decision rule** that says whether a decision belongs in code or in the model, and defend the answer with the branch-set test rather than with taste.
3. **Compute the reliability of a gated chain** from a per-step success rate and a gate catch rate, and say how many steps a chain carries before it needs a gate.
4. **Derive and use the cascade break-even condition** — a cheap-then-escalate arrangement pays iff the cheap tier's success rate exceeds its price ratio — and identify the assumption that makes it false.
5. **Estimate the cost of one request** from measured token counts and a dated rate card, and explain why a cost figure without that date is not a number.
6. **Write an async fan-out** with a bounded concurrency ceiling, per-branch timeouts and typed per-branch failures, and demonstrate a measured speed-up against the sequential version.
7. **Detect a dropped branch** in a parallel workflow's trace, explain the library default that causes it, and write the test that would have caught it.
8. **Build an append-only step ledger** with idempotency keys, and say precisely which retries it makes safe and which it does not.
9. **Route a request** through a classifier with a confidence threshold and a fallback, and justify why the fallback handler must never have side effects.
10. **Map each pattern onto nodes, edges and state**, and predict which parts of your hand-written harness a graph runtime would replace.

---

## 5. [core] Prerequisites & quick recap

You need Phases 2, 3 and 4 in the tree, not just in memory.

From **Phase 2**: `structured()` and its bounded repair loop; `CallBudget`, which meters calls and tokens and raises `BudgetExceeded`; `CachingClient` and `BudgetedClient` and the wrapper-order rule — a wrapper that can return without calling inward goes *outside* the one that meters inward calls (invariant 14, D-06). This phase uses all four, and §6.9 finally explains what that wrapper order buys in money rather than in tidiness.

From **Phase 3**: the tool registry as an injected value that *is* the security model (invariant 20); `ToolSpec.read_only`, which becomes load-bearing in §6.8 and §6.11; `execute()`, which never raises and returns a typed `ToolResult`; and the eval harness, which grows by four tasks here.

From **Phase 4**: `Plan` as a DAG the harness owns; `ready_steps`, whose length *is* the available parallelism — a fact that has been sitting unused for a whole phase and that §6.5 finally cashes in; the critic's add-never-clear rule (D-17); and `StrategyResult`, the thin comparable record the router's handlers now produce.

**One thing you do not need yet:** asyncio. This is the first place the book requires it, and §6.10 gives the orientation, with Appendix A for the rest. If you have never written `async def`, pre-read nothing; the orientation is written for exactly that starting point.

**Where this phase sits.** Phase 4's closing note pointed at documents and retrieval. The syllabus puts patterns and cost here and retrieval immediately after, deliberately: the orchestrator-workers pipeline you build in §7.6 is the thing that will *consume* retrieval, and it is far easier to add a good retriever to a pipeline that already accounts for its own cost than to retrofit cost accounting onto a pipeline that already works. Nothing in Phase 4's forward pointer is wasted — its central claim, that a retrieved chunk is the one thing in a transcript the model did not write, will apply word for word to a worker's output in §6.5.

---

## 6. [core] Core concepts

### 6.1 [core] One axis, two owners: who decides what runs next

Start with the distinction that organises everything else. In Anthropic's *Building effective agents* (published 19 December 2024), agentic systems split in two: **workflows** are systems in which LLMs and tools are orchestrated through predefined code paths, and **agents** are systems in which LLMs dynamically direct their own processes and tool usage, keeping control over how they accomplish a task. The same post recommends finding the simplest solution possible and increasing complexity only when needed — which, it says plainly, might mean not building an agentic system at all.

That post now carries an editorial note saying much of the tooling landscape it describes has changed since 2024, pointing to Anthropic's newer managed-agents material. The *distinction* has aged well; the framework recommendations have not, which is why framework state lives in your `VERSIONS.md` and not in this paragraph.

Here is the distinction in the terms this book has used since Phase 1. Every agentic system answers *what runs next?* many times per request, and the only interesting question about an architecture is **who answers it**:

```mermaid
graph LR
    subgraph "Code decides"
      A[chaining] --> B[routing]
      B --> C[parallelization]
    end
    subgraph "Model decides, code bounds"
      D[orchestrator-workers] --> E[ReAct loop]
    end
    C -.->|"the model chooses the shape,<br/>not the steps"| D
```

On the left, a human wrote the transitions and they are identical on every request. On the right, the model's output determines which code runs, and the harness's job is to bound the damage. Phase 3's ReAct loop is the far right: the model picks the next tool every step. Phase 4's plan-and-execute is one step left: the model picks the shape once, then `ready_steps` — a pure function over a graph — decides.

The five patterns in this phase are all on the left or straddling the middle, and that is the point. They are what you reach for when you have measured an agent loop and found you are paying for flexibility you do not use.

**Misconception.** *"Workflows are the beginner version; real systems are agents."* The reverse is closer to true in production. An agent loop is correct when you genuinely cannot enumerate the steps — and Phase 4's own measurement shows what happens when you use one for a task whose shape you *could* have written down: you pay the flexibility premium on every request and collect the reliability discount too. The skill is not building the most autonomous thing that works; it is knowing which decisions you are delegating, and why.

**Concept check 5.1.** Atlas's Phase 3 ReAct loop offers seven tools and terminates on one of seven stop reasons, exactly one of which is model-owned. In two sentences, explain why "one model-owned exit out of seven" is a statement about control-flow ownership rather than about safety.

---

### 6.2 [core] Pattern 1: chaining with gates

**Intuition.** You have a task that is hard in one shot and easy in three. Write an outline; check the outline; write the document from the outline. Each call gets an easier job than the monolith would have had, and between calls you get a place to *look at what came out* before spending the next call.

Anthropic's framing: prompt chaining decomposes a task into a sequence of steps where each call processes the previous one's output, and you can add programmatic checks — the "gate" in their diagram — on intermediate steps to make sure the process is still on track. The trade is explicit: you spend latency to buy accuracy by making each call an easier task.

**Precise definition.** A chain is a sequence of *stages* $s_1 \dots s_n$, each a function from the previous stage's output to its own, together with a set of **gates**: pure predicates over a stage's output, evaluated before the next stage runs. A gate has three actions — pass, retry this stage with the gate's complaint appended, or abort the chain with a stated reason. The number of stages is fixed at design time. If it depends on the input, you have an orchestrator (§6.5), not a chain.

The word *pure* is doing work. You have already built four gates without calling them that: `check_result_kind` (Phase 4, D-16), the `@tool` argument model, `is_read_only_sql`, and `resolve_in_jail`. A gate is the cheapest reliability mechanism in this book because it is deterministic, free, has tests, and — Phase 4's hard-won lesson — **is not the model**.

**Worked example: what a gate is worth.** Phase 1 gave you `episode_success(p, n) = p**n`. Take a four-stage chain with per-stage success $p = 0.8$:

$$0.8^4 = 0.4096$$

Two requests in five come out wrong. Now put a gate after each stage that catches a bad output with probability $q = 0.9$ and allows one retry. A stage ends up correct if it succeeded outright, *or* if it failed, the gate caught it, and the retry succeeded:

$$p' = p + (1-p)\,q\,p = 0.8 + (0.2)(0.9)(0.8) = 0.944 \qquad 0.944^4 = 0.794$$

From 41% to 79%, with no model in the mechanism. The cost is one extra call per caught failure — in expectation $n(1-p)q = 4 \times 0.2 \times 0.9 = 0.72$ calls per request — and **zero** extra calls on the happy path, which is what makes gates cheap in a way voting (§6.4) never is.

Two features deserve a stare. The formula is **linear in $q$**, so a mediocre gate is much better than none: at $q = 0.5$ the per-stage rate is 0.88 and the chain is at 0.60. And it does nothing about failures the gate cannot see: if your gate checks shape and the failure is a wrong number in a well-shaped table, then $q = 0$ for that failure class and the arithmetic above is a fantasy. Phase 4's §8 failure was exactly that — immaculate shape, wrong value — which is why §6.7's rule insists you name the failure class a gate catches before claiming credit for it.

**Your turn (5 minutes, no code).** Atlas's `plan_execute` arm has a gate: `check_result_kind`. Write down the failure class it catches (one sentence) and one it provably does not. Then say what $q$ you would use for "a step that produced a plausible number from the wrong inputs". You will implement `gated_success(p, q, retries)` in §7.2, and your answer here is its docstring.

**Misconception.** *"A gate is a validation step, so put it in the prompt: 'check your work before answering'."* A gate the model performs is not a gate; it is a longer prompt. Phase 4 settled this with Huang et al. (arXiv:2310.01798, 3 October 2023), whose answer-change table showed intrinsic self-correction moving 8.8% of correct answers to incorrect against 7.6% the other way. A gate must be code, a different model with an external signal, or a tool. If it is the same model looking at its own output with no new information, the arithmetic does not apply and the true $q$ may be negative.

---

### 6.3 [core] Pattern 2: routing

**Intuition.** A support inbox does not answer every message with the same procedure. Something reads it, decides which kind it is, and hands it to the right desk. Anthropic's description: routing classifies an input and directs it to a specialised follow-up task, which allows separation of concerns and more specialised prompts — and it names the cost of *not* doing it: optimising for one kind of input can hurt performance on the others. Their second example matters for this phase's budget section: send easy and common questions to a smaller, cheaper model and hard or unusual ones to a more capable one.

**Precise definition.** A router is a triple: a **closed label set** $L$; a **classifier** $c:\text{request} \to (\ell, \text{confidence})$ with $\ell \in L$; and a **dispatch table** $d: L \to \text{handler}$, written in code. The classifier may be a model, a keyword rule, a trained classifier, or a coin. The dispatch table may not be a model, ever.

That last clause is the whole pattern, and it is this phase's first decision.

> **D-21 (recorded in §11).** The model may return a **label**, never a **callable**. Control flow lives in code unless the branch set cannot be enumerated at design time. A router's classifier produces data — a member of a `Literal` plus a confidence — and a Python dict maps that data to a function. The model never names a function, a module, or a tool to dispatch.

Atlas's label set, fixed here and unchanged for the rest of the book:

| Route | What it means | Handler |
|---|---|---|
| `chat` | Conversational or meta, no corpus needed | one direct call, **no tools at all** |
| `document` | Answerable from the internal document corpus | file/search handler; becomes retrieval-backed next phase |
| `data` | Answerable by a read-only SQL query | ReAct over a database-only registry |
| `research` | Needs several sources combined | the orchestrator-workers pipeline of §7.6 |
| `tool_action` | Wants something *done* — a write, a file, a scheduled item | ReAct with writes, plus a human gate in Phase 12 |

Five labels, five handlers of very different price. That table is the cost lever: a `chat` request costs one call, a `research` request costs seven or more, and today Atlas charges every request the same because it has no idea which is which.

**The confidence threshold, and the part everybody gets wrong.** A classifier that must always commit will sometimes commit wrongly, so the router carries a threshold $\tau$: below it, the request goes to a **fallback** handler. The universal instinct is to make the fallback the *cheapest* handler, because an unsure request feels like one not worth spending money on. That instinct is backwards, and it produces the most expensive class of bug in this architecture: an unsure request routed to `chat` gets answered from the model's prior, fluently, with no corpus and no tool call to audit. Phase 4 measured what that looks like — the no-tool arm scoring 75% on database questions until the grader was fixed.

> **D-22.** A low-confidence route selects the **most capable read-only** handler, never the cheapest, and **never** one with side effects. `tool_action` is unreachable by fallback: a write performed because the router was unsure is the worst available outcome. The decision is recorded as `fallback_used: bool`, because a route you cannot audit is a route you cannot measure.

The justification is one line: routing a `chat` question to `research` costs tokens; routing a `data` question to `chat` costs a wrong answer that looks right. Those are not comparable quantities, and a threshold that treats them as comparable was chosen by convenience.

**Concept check 5.2.** The classifier is a model call, so it can be wrong. Suppose it is 90% accurate over five labels. Write down what "90% accurate" fails to tell you about the system's behaviour, and name the one additional number you would need to predict the damage.

**Misconception.** *"Routing adds a call, so it costs more."* Sometimes. The router call is small — short system prompt, the request, a five-way enum, a 160-token cap — and the handler it selects may be an order of magnitude cheaper than the default. Section 6.9 does the arithmetic, including the case where routing loses. What is not in doubt is the reliability argument: with one handler you have one prompt that must be good at five jobs, and Anthropic's framing names the failure mode — tuning it for one input class degrades the others. That cost is invisible in a token count and shows up in an eval suite.

---

### 6.4 [core] Pattern 3: parallelization, in two flavours that are not variants of each other

Anthropic splits parallelization in two. **Sectioning** breaks a task into independent subtasks run in parallel. **Voting** runs the same task several times to get diverse outputs. They appear side by side in one diagram, and it is worth being blunt: they are different patterns with different preconditions, different cost curves and different reasons to exist. Treating them as one is how people end up running five copies of a task whose subtasks were independent all along.

**Sectioning.** *n* different jobs, *n* results, one programmatic reduce. Sectioning buys **latency**: the work was going to happen anyway and the calls do not depend on each other, so wall clock becomes the slowest branch instead of the sum. Token cost is unchanged, or slightly worse if each branch re-sends shared context. Anthropic's examples include a guardrail arrangement where one instance handles the query while another screens it — which, they note, performs better than asking one call to do both.

Atlas's sectioning case is §7.5's parallel summariser: eight documents, eight independent summaries, one reduce. And note what the reduce is: a *program*, wherever the reduce is expressible as one. Concatenation, a max, a majority, a sum, a sorted table — all free. A model call to "combine these eight summaries" is a ninth branch's cost plus a new failure mode.

**Voting.** *n* copies of the *same* job, one aggregation, and the aggregation is where the reliability comes from. Phase 4 covered the evidence (Wang et al., 21 March 2022, self-consistency on GSM8K; Huang et al.'s Table 7, where multi-agent debate at matched response count *loses* to plain voting). Phase 4 also established that Atlas fails two of the three preconditions by design: temperature zero and a fixed seed make its samples identical, and a vote among identical samples is theatre. Voting is therefore a mechanism you switch on for a specific extractable-answer subtask, not a default.

```mermaid
graph TD
    R[request] --> S1[branch A]
    R --> S2[branch B]
    R --> S3[branch C]
    S1 --> RED{{"reduce (a program)"}}
    S2 --> RED
    S3 --> RED
    RED --> OUT[result + n_failed]
```

The `n_failed` on that output node is the whole of §8. Hold onto it.

**The precondition that decides between them.** Sectioning requires **independence** — no branch's input depends on another's output. Voting requires **comparability** — an extractor that turns a completion into a countable value. If neither holds you do not have a parallel workflow: you have a chain (dependencies) or a report (incomparable outputs), and forcing it into a fan-out gets the worst of both.

**Your turn.** For each, say sectioning, voting, or neither, in one line: (a) summarise each of six notes files, then produce a combined brief; (b) decide whether one support message is a refund request, using three differently-worded prompts; (c) compute Q3 revenue, then the year-on-year change; (d) check one SQL query for read-only-ness with three prompts. If you answered "voting" to (d), reread invariant 20 and reconsider.

---

### 6.5 [core] Pattern 4: orchestrator-workers — and how it differs from what you already built

**Intuition.** A research request arrives: "How are we doing on warranty claims for the products that shipped late last quarter?" You cannot write the subtasks down in advance because they depend on what the data says. So one call looks at the request and *decides what the subtasks are*; each goes to a worker; a final call combines the results.

Anthropic's definition: a central LLM dynamically breaks down tasks, delegates them to worker LLMs and synthesises the results. And the sentence that pins the distinction from parallelization: the two are topographically similar, but the orchestrator's subtasks are not pre-defined — they are determined from the specific input. Their named example is what Atlas is: search tasks that gather and analyse information from several sources.

**So what is the difference from Phase 4's plan-and-execute?** This matters more than the taxonomy, because you have already built something matching the description. The honest answer: plan-and-execute *is* an orchestrator-workers pipeline with three properties removed, and those three are what this phase adds.

1. **Fan-out.** Phase 4's executor runs one ready step per iteration even when `ready_steps` returns four. That function's docstring has said since Phase 4 that its length *is* the available parallelism, and the loop has been ignoring it. Section 7.6 stops ignoring it.
2. **Worker isolation.** A Phase 4 executor call uses the same client, the same registry and the same episode budget. A *worker* gets its own scoped registry, its own timeout and its own typed record — which is what makes a worker's failure survivable and its cost attributable.
3. **A synthesis that sees provenance.** Phase 4 synthesises from `summarise_results`, a text blob. A worker returns a structured record saying which tools ran, what they returned and whether the shape check passed — so the synthesis prompt is given *citable* facts, and §11's eval task can check that every claim traces to a worker that actually succeeded.

Put differently: Phase 4 built the orchestrator. This phase builds the workers.

```mermaid
graph TD
    Q[request] --> O["orchestrator: 1 call<br/>→ a DAG"]
    O --> V{{"validate_plan + shape checks<br/>(code, free)"}}
    V -->|complaints| O
    V -->|ok| L["ready_steps → level set"]
    L --> W1[worker: scoped registry]
    L --> W2[worker: scoped registry]
    L --> W3[worker: scoped registry]
    W1 --> LED[("append-only ledger")]
    W2 --> LED
    W3 --> LED
    LED --> L
    LED --> SY["synthesis: 1 call<br/>sees provenance"]
```

**The cost shape, because it is not obvious.** This pipeline pays two calls unconditionally — orchestrator and synthesis — before any work happens. On a one-hop request that is pure overhead, which is Phase 4's measured result restated. What changes here is that the *router* stands in front, so one-hop requests never reach the pipeline. That is the composition this phase is about: **routing is what makes an expensive pattern affordable, because it stops the expensive pattern from seeing cheap requests.**

**Misconception.** *"Orchestrator-workers means multiple agents."* No. A worker is a call, or a small bounded loop, with a scoped tool set. It has no persona, no memory of its own and no ability to talk to its siblings. The multi-agent supervisor — workers that negotiate and address each other — is deferred to Appendix F and is a different animal with worse failure modes. Anthropic's own framing keeps workers as *calls*, and Huang et al.'s Table 7 is the empirical reason to be slow about upgrading them: at matched budget, the elaborate arrangement lost to the plain one.

**Concept check 5.3.** The orchestrator emits a DAG that Phase 4's `validate_plan` can already check. Name two complaints it produces for free, and one it does not produce that a worker-based pipeline needs. (Hint: Phase 4's §8 failure lives on an edge.)

---

### 6.6 [core] Pattern 5: evaluator-optimizer

**Intuition.** Write a draft. Have something else grade it against stated criteria and say what is wrong. Revise. Stop when it passes or when the allowance runs out.

Anthropic's version: one call generates a response while another provides evaluation and feedback in a loop. Two signs of good fit — responses demonstrably improve when a human articulates feedback, and the model can produce such feedback — and one precondition: clear evaluation criteria, with iterative refinement providing measurable value.

**Precise definition.** A bounded loop over two roles. The **optimizer** produces a candidate. The **evaluator** produces a structured verdict against a **rubric** — a fixed, written-down set of criteria, each with a score and a required action. The loop exits on acceptance, on a round cap, or on a *non-improving* round. The artifact returned is the **best** candidate by score, not the last.

That last clause is not a detail. A loop returning the final candidate assumes monotone improvement, and Phase 4's evidence says otherwise: revision without an external signal moves answers in both directions. Keeping the best requires keeping a score, which requires the evaluator's output to be a schema rather than a paragraph.

**Where this differs from Phase 4's critic.** Phase 4's critic judges an *execution record*: did steps fail, are shapes wrong, is a claim uncited. Mechanical findings first, and a model critic may add findings but never clear one (D-17). Phase 5's evaluator judges an *artifact* — a paragraph of a report — against a rubric, and its output decides whether another expensive call happens. So D-17's asymmetry gets a sibling rather than a repeal:

> The evaluator may **withhold acceptance** and may **never grant** it. Acceptance requires the rubric's mechanical criteria to pass *and* the evaluator not to object. A model that can say "good enough" has been handed the exit condition, and invariant 9 says the harness owns termination.

Concretely, §7.7's report-section rubric has mechanical criteria (every numeric claim appears in the worker results; length within bounds; no claim cites a tool whose step did not succeed) and judgement criteria (does it answer the question asked; is the ordering sensible). The mechanical ones are gates in the §6.2 sense. The judgement ones can only block.

**When *not* to use it.** When you have no rubric. A refinement loop with vague criteria is a token multiplier with a plausible narrative attached: the evaluator always finds something to say, the optimizer always changes something, and your measurement shows more tokens and no accuracy change. **If you cannot write the rubric down before you build the loop, build the rubric instead.** That is the entire content of "clear evaluation criteria", and it is the most-skipped precondition in this pattern's short history.

**Your turn.** Write three rubric criteria for the one-paragraph "Findings" section of an Atlas research brief such that each is *mechanically checkable* against the worker records. If you find yourself writing "is well-written", move it to the judgement list and notice how much smaller the mechanical list is than you expected.

---

### 6.7 [core] The central tension, and a decision rule you can apply

Every pattern above is a place where you decided *not* to let the model choose. Here is the rule, stated so it settles arguments rather than starting them.

> **The hard-code rule.** Delegate a decision to the model only if **all three** hold:
> **(a) Unbounded branch set** — you cannot enumerate the outcomes at design time. If you can write the `Literal`, code owns the dispatch.
> **(b) Irreducible run-time information** — the decision needs something that appears only at run time *and* that no cheap deterministic function can summarise. If a keyword rule, a schema check or a SQL query gets you 95% of the way, that is the decision-maker.
> **(c) Recoverable error** — a wrong branch is detectable and affordable within the budget. If a wrong branch writes a file, sends a message, or produces an unauditable answer, (c) fails however elegant the delegation looks.
>
> If any of the three fails, **code owns the decision and the model produces data the code branches on.**

Apply it to the router: (a) fails outright — five labels, written down. So the model classifies; it does not dispatch. Apply it to a ReAct loop over a research question: (a) holds (you cannot enumerate tool sequences), (b) holds (the next tool depends on the last observation), (c) holds *only because* the registry is scoped read-only and `allow_writes` is False in sweeps. Notice that (c) is not a property of the model or the task — it is a property of the harness, and Phase 3's invariant 20 is what makes delegation permissible at all.

Two corollaries worth as much as the rule.

**Corollary 1: a delegated decision must be recorded as data.** If the only evidence of what the model decided is which function happened to run, you cannot measure the decision, grade it, or regression-test it. Hence `RouteDecision` carries the label, the confidence and `fallback_used` — and hence §11's eval task grades routing accuracy against labelled requests, which is only possible because the label is a field.

**Corollary 2 (the counting rule, Phase 5's version).** Phase 4 gave you: *if the number of model calls does not change, you changed a prompt.* Its sibling: **if a model's output can change which code runs, you have delegated control flow — count the branches it can reach, and make sure each is one you would accept.** That count belongs in a code review. An output that can reach two branches is a design; one that can reach an unbounded set through dispatch-by-name is a vulnerability, and OWASP's agentic list (2026 edition, pinned in your `VERSIONS.md`) names the family it belongs to.

**Misconception.** *"Hard-coding control flow means the system can't adapt."* It means *this* system does not adapt along *this* axis, which is a choice you can measure and reverse. The dangerous version of adaptability is the one you did not decide to have: a prompt saying "choose the appropriate handler and call it" has delegated dispatch by accident, and the delegation is invisible in review because it looks like English.

---

### 6.8 [core] State between steps: an immutable ledger, and what idempotency buys

Every pattern here passes data between steps, and every one can be retried. Those two facts together are why workflow state deserves a design rather than a dictionary that gets mutated as things go.

**The problem, concretely.** Phase 4's `PlanStep` is mutable: the loop sets `status`, `result`, `note`, `attempts` as execution proceeds. That is correct for a *plan* — the plan is the working set, and `ready_steps` reads its current state to decide what runs next. But it means the record of what happened is destroyed by the thing that happened next. If step `s3` failed once, was retried and succeeded, the plan says `status="done"` and the first attempt's error is gone. You cannot bill it, count it, or read it in a failure log.

**Definition.** A **step ledger** is an append-only sequence of immutable `StepRecord`s. Each carries: which run it belongs to, which step, which attempt number, the inputs' idempotency key, the outcome (`ok` / `failed` / `timeout` / `skipped` / `replayed`), the payload or error, the token counts and the wall clock. Records are `frozen=True`. A retry appends; it never edits. The plan remains the working set; the ledger is the account of what was done.

The one-line justification: **the plan answers "what runs next", the ledger answers "what did this cost and what happened" — and a structure mutated to answer the first cannot be trusted to answer the second.**

**Idempotency, without hand-waving.** An operation is idempotent if performing it twice has the same effect as once. Retries are only safe over idempotent operations, and most of Atlas's are: a `SELECT`, a document read, a calculation, a search. One is not: `write_file`. This is why `ToolSpec.read_only` — a flag you wrote in Phase 3 for authority reasons — turns out to decide retry safety too.

An **idempotency key** makes that mechanical rather than a matter of remembering. Define it as a hash over the *work*, not the *attempt*:

```
idem_key = sha256(canonical_json({
    "step": step_name,
    "tool": tool_name_or_null,
    "inputs": inputs,        # canonicalised: sorted keys
    "version": handler_version,
}))
```

Three details, each a bug if you get it wrong. **The run id and attempt number are not in the key**, because a key identifying an *attempt* can never match anything — which makes the whole mechanism a no-op that looks like it works. **The handler version is in the key**, because when the code changes, the cached result of the old code is a wrong answer with a valid key. And **the inputs are canonicalised**, because `{"a":1,"b":2}` and `{"b":2,"a":1}` are the same work and a key that disagrees is a cache with a 0% hit rate. Phase 0's `request_key` made the same choice for model calls, for the same reason.

What the key buys is one sentence: **before performing a step, look for a completed record with the same key; if there is one, replay it and charge zero.** That single rule is simultaneously the retry-safety mechanism, the tool-result cache of §6.9, and the reason a crashed workflow can resume without re-paying.

What it does **not** buy: it does not make `write_file` safe to retry. A completed write is idempotent in effect only if the content is identical, and if the content is identical you did not need the retry. Atlas's rule, enforced in code in §7.2, is that a step whose tool is not `read_only` is **never** auto-retried and never served from cache; a failed write escalates to Phase 12's human gate or fails the workflow with a stated reason.

**Concept check 5.4.** A worker runs `query_db` with the same SQL twice in one run because the orchestrator's plan named it twice. With the ledger and key above, how many model calls and how many database queries happen? Now change the tool to `current_time` and answer again — then say which property of `current_time` your answer depends on. (Section 6.11 turns your answer into a one-field interface change.)

**Misconception.** *"Immutable records mean copying everything, which is slow."* The records are a few hundred bytes plus the payload, and there are single digits of them per request. The cost that matters here is model calls and tokens, and an append-only ledger of dataclasses is invisible next to one 800-token prompt. Pay it. The version that mutates records in place is the version where §8's dropped branch is undebuggable.

---

### 6.9 [core] Cost engineering: four levers, and the arithmetic for each

The longest subsection in the phase and the one with the most transferable content. No prices appear in it. Prices are the most volatile numbers in this stack, so they live in a data file you fill in with a checked-on date, and everything below is arithmetic over whatever you put there.

Start with the only cost model you need. Every request's spend decomposes into exactly four factors:

$$\text{cost} \;=\; \underbrace{k}_{\text{calls}} \;\times\; \big(\underbrace{\bar{p}}_{\text{avg prompt tokens}} \times r_{\text{in}} \;+\; \underbrace{\bar{c}}_{\text{avg completion tokens}} \times r_{\text{out}}\big)$$

Four levers: reduce $k$, reduce $\bar{p}$, reduce $r$ (a cheaper model for some of the $k$), or make some of the $k$ free. Every technique in this phase is one of those four, and knowing which one a technique pulls is how you predict whether it will help *you*.

Two facts about the shape matter more than any tactic.

**Prompt tokens dominate, and they dominate quadratically.** Phase 1 derived it: an agent loop resending the growing transcript bills $n p_0 + g\,n(n-1)/2$ prompt tokens across an episode. Completion tokens grow linearly at worst. So on any agent-shaped workload $\bar{p} \gg \bar{c}$, and the arithmetic says attack the transcript before anything the model writes. Phase 4's plan-and-execute broke the quadratic term by passing each step only what its `depends_on` declared; this phase's chain does the same by construction, which is why `StageInput` has three content fields and none of them is "the transcript".

**Output rates are typically higher per token than input rates**, so the cheap-looking lever — "make the model write less" — is not always the small one. Whether it is worth pulling in your setup is a question about your rate card, which is exactly why the rate card is data.

#### Lever 1: fewer calls (early exits)

An early exit is a gate whose verdict is `abort`, and its value is exact. If a fraction $\alpha$ of requests can be rejected after stage $j$, and the stages after $j$ cost $C_{>j}$, the saving per request is $\alpha \cdot C_{>j}$. The consequence is where to put the gate: **as early as the cheapest sufficient check allows**, because the saving is proportional to what is *downstream*. A validity check at the end of a five-stage pipeline saves nothing.

Atlas's routing decision is itself an early exit for `chat`: a greeting never reaches the research pipeline, and the saving is the whole pipeline.

#### Lever 2: smaller prompts (and the trap in "just summarise it")

Three honest mechanisms: pass less (declared dependencies), truncate tool output (Phase 3's `max_output_chars`, already on every `ToolSpec`), and compress history. Be careful with the third: summarising costs a model call, so you have traded $\bar{p}$ against $k$, and whether it wins depends on how many *future* calls carry the smaller prompt. Compress once then make one more call: you lost. Compress once then make eight: you won. There is a real crossover point, and Phase 7's memory work is where Atlas faces it.

#### Lever 3: model tiering, with the algebra done

Two arrangements, and people mix them up.

**Routing** sends each request to *one* tier chosen up front. Cost is the mix-weighted average plus the classifier: $r + \sum_\ell s_\ell c_\ell$, which is `routed_cost` in `atlas/cost.py`. Routing wins when the traffic mix is skewed towards cheap handlers by more than the classifier costs — an empirical question about your traffic, which is why `route_mix` computes shares from recorded decisions instead of letting you assume them.

**Cascading** sends every request to the cheap tier *first* and escalates the failures:

$$C_{\text{cascade}} = c_s + (1-f)\,c_l$$

where $f$ is the fraction the cheap tier handles acceptably. Set that below $c_l$ and solve:

$$c_s + (1-f)c_l < c_l \;\Longleftrightarrow\; c_s < f\,c_l \;\Longleftrightarrow\; \boxed{f > \dfrac{c_s}{c_l}}$$

> **A cascade pays if and only if the cheap tier's success rate exceeds its price ratio.**

One line, no simulation. If the cheap tier is a tenth of the price, it needs to work on more than 10% of requests — a *low* bar, which is why cascades are popular. Two cases with $c_s = 1$, $c_l = 10$: at $f = 0.7$ you pay $1 + 3 = 4$ instead of $10$ (60% saved); at $f = 0.05$ you pay $10.5$ — *more* than never cascading, because you paid the cheap fee on everything and escalated almost all of it anyway.

Now the part that makes this a reliability lesson. **The algebra assumes you can tell when the cheap tier failed.** The escalation decision is a verifier, and Phase 4 spent a section on what happens when the verifier is the model judging its own work: 8.8% correct→incorrect against 7.6% the other way. With an unsound verifier you get the worst of both — you pay both tiers *and* ship the cheap tier's mistakes, because the cases it got wrong and was confident about are exactly the ones that do not escalate. So:

> **A cascade is only as good as its escalation test, and the escalation test must not be the cheap tier's own opinion of itself.** Atlas's escalation tests are gates: a shape check, a citation check, an empty-result check. All code, all free, all with a known catch rate for a named failure class.

**Concept check 5.5.** Your cheap tier costs one fifth of your capable tier and handles 30% of requests acceptably. (a) Does the cascade pay? (b) Now suppose the escalation test also misses one third of the cheap tier's failures. Write down the new *accuracy* relative to always using the capable tier, and say which number — cost or accuracy — you would report to a manager first.

#### Lever 4: making calls free (two different caches)

Atlas has two caches and they are not the same mechanism.

**The response cache** (Phase 0 Assignment 2, wired in Phase 2) is keyed on the whole call signature and short-circuits an identical request. It is why `CachingClient` goes *outside* `BudgetedClient` (invariant 14): a hit must not consume the budget, because it did not consume the provider. That wrapper order is the difference between a cache that saves money and one that only saves latency.

**The tool-result cache** (this phase) is keyed on the *tool call*, using §6.8's idempotency key. The lookup is the same three lines that make retries safe, which is the point of building it that way. Two conditions, and the second is the one people miss:

1. The tool must be `read_only`. A cached write is a write that did not happen.
2. The tool must be **deterministic**. `current_time` is `read_only=True` and is the least cacheable function in the codebase.

Read-only and deterministic are different properties, and Phase 3 recorded only the first. So Phase 5 adds one field — `ToolSpec.cacheable`, defaulting to `True`, set `False` on the clock — and §11 documents it as an interface addition with a migration note. A default-`True` addition keeps every existing call site valid, which is the only kind of interface change that is free.

**Provider-side prompt caching** is a third thing, worth knowing even though Tier A has no such endpoint. Per Anthropic's prompt-caching documentation the mechanism is prefix resumption: you mark a stable prefix, the provider stores it, and a later request whose prefix matches reads it instead of reprocessing. Two consequences follow from the word "prefix", and they are the whole engineering content: cacheable material must come **first** (system prompt, tool definitions, long documents — before anything per-request), and the match is on the prefix, so **one byte of drift near the top invalidates everything after it.** The classic own-goal is a timestamp or request id rendered into the system prompt: the prefix never repeats, the hit rate is zero, and the writes cost slightly more than not caching at all. Atlas is immune by accident — `atlas.prompts` loads a checksummed file with no clock in it — and that is worth noticing as a design property rather than luck. The write premium, read discount, TTLs and per-model minimum cacheable length are current-state facts and live in your `VERSIONS.md`.

**Misconception.** *"Caching is an optimisation, so add it last."* Caching changes what your measurements mean, so add the *accounting* first. A sweep in which half the calls were cache hits and the report does not say so has published a token count no future run will reproduce. Phase 2 built `Completion.cached` and `CachingClient.hits` for this (invariant 15); this phase adds `cache_hits` to `RequestAccount` for the same reason — and note that a counter is only worth having if a real execution path increments it, which is invariant 41 and a defect this phase committed before catching (F-05-07).

#### The per-request estimate, and the rule about dates

Measure the tokens, multiply by a dated rate card, print both. `atlas/cost.py` makes the second half unavoidable:

```python
# excerpt: atlas/cost.py
    checked_on: str = Field(description="ISO date (YYYY-MM-DD) you read these rates.")
    source: str = Field(description="URL or note saying where the rates came from.")
```

`checked_on` is required, validated against an ISO date pattern, and appears in every rendering. A card whose `source` still contains the template's `REPLACE` marker is flagged as a placeholder in the output, so a zero-cost report caused by an unfilled file is loud rather than encouraging. The repo ships `data/rate_cards/tier_a.json` with all-zero rates and a `source` explaining why (a local model has no per-token charge), so the path is exercised on a fresh clone, plus `tier_h.example.json` for you to fill in.

> **D-24.** A cost figure is printed only with the rate card's name and `checked_on` date beside it. Prices are data with provenance; the code that multiplies them is code with tests. This is D-14 (a number carries its provenance) applied to money.

#### The Tier H cap as a lived rate limit

You have been inside one of these arithmetic problems since Phase 2. Your `VERSIONS.md` pins the free-tier token quota, and the derivation there is the model above solved for $k$: daily token quota ÷ tokens per call ≈ calls per day. That is why the config carries `ATLAS_TIER_H_TOKEN_CAP` *and* `ATLAS_TIER_H_CALL_CAP`, and why tokens bind first — an earlier draft of this book reasoned from requests per day, concluded the budget was three times larger than it was, and was wrong because requests-per-day was not the binding constraint.

This phase makes it worse instructively. An orchestrator-workers request makes an orchestrator call, three or four worker calls and a synthesis call, each carrying its own context. So one *request* can be six calls, and the per-request token figure is what the quota divides by — not the per-call figure. Next phase, retrieved chunks push prompts up again and halve the call budget a second time. The habit to build now: **when someone tells you a rate limit in requests, convert it to your own unit before believing anything about it.**

---

### 6.10 [core] Async Python, in three parts

You need enough asyncio to fan out four model calls and not enough to have opinions about event loops. Appendix A has the rest.

**What it is.** A normal function runs to completion before the caller's next line executes. A coroutine — `async def` — can *suspend* at an `await` and hand control to a scheduler called the event loop, which runs other coroutines while this one waits. That is the entire benefit and the entire limitation. Async buys nothing on CPU-bound work, because nothing suspends; it buys almost everything on I/O-bound work, because a model call spends 99% of its life waiting for bytes. Atlas is I/O-bound to an almost comical degree. One event loop, one thread: `asyncio.run(main())` starts it, `await` suspends inside it, and a *blocking* call inside a coroutine — `time.sleep`, a synchronous HTTP request, a large `read()` — stalls every other coroutine on that loop. That is the most common async bug and the reason §7.5 wraps the synchronous client in `asyncio.to_thread` rather than calling it directly.

**The four constructs this phase uses.** `asyncio.gather(*coros)` runs coroutines concurrently and returns results **in argument order** — always, which is what makes it safe to index results against inputs. Its `return_exceptions` parameter decides whether a raising branch propagates immediately (`False`, the default) or comes back as an exception object in the results list (`True`); §8 is about a system that got that choice wrong. `asyncio.TaskGroup` (Python 3.11+) is structured concurrency: on exit it waits for every task, and if one raises it cancels the siblings and raises an `ExceptionGroup`. `asyncio.Semaphore(n)` bounds how many coroutines hold a resource at once — the rate-limit mechanism, and without it a fan-out over 50 documents opens 50 concurrent requests and gets you throttled. `asyncio.timeout(seconds)` (also 3.11+) is a context manager that cancels what it wraps, which is how a branch that hangs becomes a branch that fails.

Atlas uses `gather`, `Semaphore` and `timeout`, and deliberately **not** `TaskGroup`: a task group cancels siblings when one task raises, which is the `all_or_nothing` policy hard-coded into a language construct, and Atlas's default is `partial`. Read its documentation anyway, and note *why* it cancels — that reasoning is the policy question of §6.11 in library form.

**Streaming, and why Atlas does not.** A streaming response yields tokens as they are produced instead of one payload at the end (`stream=True` on the OpenAI-compatible dialect, `"stream": true` on Ollama's native endpoint; both deliver server-sent events, which are covered in Appendix A and used for real in Phase 16's FastAPI service). Streaming changes exactly one thing worth having: **time to first token**, which is a user-experience property, not a throughput property. It changes nothing about total tokens, total cost or reliability, and it costs you two things that this phase depends on. A gate cannot run on a partial payload — `check_result_kind` on half a table is meaningless — so a streamed stage cannot be gated until it has finished streaming, at which point you have a payload and the stream bought you nothing. And a fan-out's reduce needs *whole* branch payloads, so a streamed branch must be accumulated before the reduce sees it. Hence Atlas accumulates: `Completion` is a complete answer, and streaming arrives in Phase 16 where it belongs, at the boundary where a human is watching. The one place streaming *would* pay before then is a long `research` answer rendered to a user; that is a Phase 16 interface concern, and putting it in the client now would mean two code paths through every gate in this chapter.

**Misconception.** *"Async makes it faster."* Async makes *waiting* overlap. Eight sequential 3-second calls take 24 seconds; eight concurrent ones take about 3. But your Tier A model is one process on one laptop, so eight concurrent local calls **do not** take 3 seconds — they queue in the runner and may take longer than 24 under memory pressure. Concurrency helps when the bottleneck is elsewhere, and on Tier A the bottleneck is your GPU-less laptop. This is why §7.5's speed-up is designed to be measured on both tiers, and why the expected ranges differ in *sign*, not just size.

---

### 6.11 [core] Workflow-level failure handling: partial, compensated, timed out

Individual failures you have handled since Phase 3: `execute()` returns a typed `ToolResult` and never raises. Workflow-level failure is a different question — *what does the workflow do when part of it did not work?* — and there are exactly three answers, which should be a parameter rather than an accident.

**All-or-nothing.** Any branch fails, the workflow fails, nothing is reported. Correct when the deliverable is meaningless without every part: a reconciliation, a financial total, an "all clear".

**Partial, labelled.** Report what succeeded, name what did not, let the caller decide. Correct for research and summarisation, where three sources out of four is genuinely useful — *provided the answer says so*. An unlabelled partial result is the most dangerous outcome in this phase, because it is indistinguishable from a complete one and reads as *more* confident for being shorter.

**Compensated.** Undo the side effects of the parts that succeeded, then fail. Correct when steps mutate the world and a half-applied change is worse than none.

Atlas can do the first two and mostly cannot do the third, for a reason you have met. Phase 4 refused to search over tool calls because search needs a free undo and side-effecting tools do not have one. Compensation is that constraint wearing a different hat: you can only compensate for an action whose inverse you can perform. Atlas's writes go through `resolve_in_jail` into a workspace, so a *narrow* compensation exists — delete a file this run created — and even that has the classic trap: if the file already existed, "delete" is not an inverse but a second, worse mutation. The honest engineering position, and what Phase 12's human gate implements, is: **prefer workflows whose side effects happen last, in one step, after everything read-only has succeeded.** A workflow ordered that way needs no compensation, because there is nothing to undo when a read fails.

**Timeouts, and the two you need.** A **per-branch** timeout turns a hung call into a typed failure, so the fan-out completes and labels itself partial. A **whole-workflow deadline** bounds the request. You need both and they are not substitutes: per-branch timeouts alone let $n$ sequential retries exceed any deadline, and a deadline alone lets one hung branch consume the budget while its finished siblings wait. The rule that follows: **a timeout must produce a record, not just an exception.** A branch that timed out and left nothing behind is the same evidence problem as a mutated step record.

That is also the answer to Concept check 5.4's second half. `current_time` is read-only, so retry-safe, and non-deterministic, so not cacheable — one property Phase 3 recorded and one it did not:

> **D-26.** Cacheability is a property of the tool, declared once on `ToolSpec` beside `read_only`, never a list of tool names maintained elsewhere. Invariant 18's reasoning applies unchanged: a second description of a tool's properties, kept next to the first, is drift waiting to happen.

**Concept check 5.6.** A four-branch fan-out has a per-branch timeout of 20 s, a whole-workflow deadline of 30 s, and a concurrency limit of 2. One branch hangs. Sketch the timeline, say which limit fires, and say what the reduce function receives.

---

### 6.12 [core] Bridge to graphs: what Phase 9 will and will not give you

Every pattern here is a graph. Naming the correspondence now makes Phase 9 a port.

| This phase, in plain Python | As a graph |
|---|---|
| `Stage` | a node: state in, state out |
| the gate's `pass` / `retry` / `abort` | a conditional edge with three targets |
| `run_chain`'s stage list | the edge set, fixed at build time |
| `ChainResult.payload` threaded stage to stage | the state object, and its reducer |
| `Ledger` | the checkpointer's append-only history |
| `reconcile` + `dispatch_table` | a router node plus conditional edges |
| `gather_bounded` (§7.5) | fan-out edges plus a join node |
| the orchestrator's `ready_steps` level set | dynamic fan-out — a `Send`-style construct |
| the evaluator's bounded loop | a cycle with a max-iterations guard |

Read it in both directions. Left to right, a graph runtime gives you persistence and resume for free (your ledger becomes a checkpointer), streaming of intermediate state, a picture you can render, and standard machinery for the fan-out/join that §7.5 hand-rolls. Right to left it gives you **nothing** about which shape is correct, what a gate should check, where the confidence threshold goes, or why the fallback must be read-only. Those are design decisions, and they are the same decisions in every framework.

One thing to watch for in Phase 9: a graph runtime makes it *easy* to add a node, and adding a node is adding a model call. The counting rule still applies, and it applies harder when the addition is one line of `add_node`.

**Your turn.** Draw the router plus five handlers as a graph, with the fallback edge included. Count nodes, edges and conditional edges. Then answer: how many of those edges could a model's output choose between? If the number is not 5 (one per label) plus 1 (the fallback), reread D-21.

---

## 7. [core] Hands-on: build the patterns

Nine modules in dependency order. Everything in §7.1–§7.4 is offline-testable with no model, which is not a coincidence: the modules that decide control flow are the ones with no network in them.

```
atlas/cost.py           arithmetic: gates, cascades, mixes, rate cards, accounting
atlas/flow/state.py     immutable step records, append-only ledger, idem keys
atlas/flow/chain.py     chaining with gates
atlas/flow/route.py     the router
atlas/flow/parallel.py  the async fan-out; sectioning and voting
atlas/flow/orchestrate.py  orchestrator-workers
atlas/flow/optimize.py  evaluator-optimizer against a rubric
atlas/flow/app.py       Atlas's front door: route, dispatch, account
atlas/tools/cache.py    the tool-result cache
```

Work in the tree from `atlas_phase_04.zip`: `mkdir atlas/flow`, add an `__init__.py`, and run `make test-offline` after each module.

### 7.1 [core] The ledger, and why the key excludes the attempt

The whole idempotency mechanism is one function, and its parameter list is the design:

```python
# excerpt: atlas/flow/state.py
def idem_key(
    *,
    step: str,
    tool: str | None,
    inputs: Mapping[str, Any],
    version: str = "1",
) -> str:
    payload = canonical_json(
        {"step": step, "tool": tool, "inputs": dict(inputs), "version": version}
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
```

Read what is *absent*: no run id, no attempt number, no timestamp. Include any of them and every lookup misses, the mechanism becomes a no-op, and — the part that makes this a bug worth naming — every test you thought to write still passes, because "cache miss" is indistinguishable from "cache correctly cold". The test that catches it runs the same chain twice with the same ledger and asserts the stage function was called **twice in total, not four times**, and that the token total did not move.

`version` is present for the opposite reason. Change a handler and yesterday's cached result is a wrong answer with a valid key; no amount of input hashing detects it. Bumping the string is a one-character deliberate invalidation.

The record itself:

```python
# excerpt: atlas/flow/state.py
class StepRecord(BaseModel):
    model_config = ConfigDict(frozen=True)

    run_id: str
    step: str
    attempt: int = 1
    key: str = ""
    outcome: StepOutcome = "failed"  # fail closed, exactly as StopReason does
```

Two decisions in five lines. `frozen=True`, so a retry cannot overwrite the evidence of the attempt it is retrying — the reason §8's lost branch is diagnosable at all. And `outcome` defaults to `"failed"`, the same fail-closed default as every `StopReason` since Phase 1: a record constructed and never completed reads as a failure, which is the interpretation that cannot flatter you.

`StepOutcome` has five members and the fifth looks like padding. `"replayed"` exists because an idempotency hit did real work once and no work this time. Score it `"ok"` and a resumed run looks exactly as expensive as the original, destroying the only measurement that says whether the cache is worth having; score it `"skipped"` and you lose the payload. So there is a fifth outcome, and exactly one line sets it (invariant 30):

```python
# excerpt: atlas/flow/state.py
        record = StepRecord(
            run_id=self.run_id,
            step=step or previous.step,
            attempt=self.attempts(step or previous.step) + 1,
            key=previous.key,
            outcome="replayed",
            payload=previous.payload,
```

Note what `replay` does *not* copy: the token counts. They were charged to the original attempt, and charging them again is precisely the error that makes a working cache look worthless. `StepRecord.billable` is `False` for a replay, and `Ledger.attempts()` counts billable records only — so a replay does not consume a retry allowance either, which it should not, since it did not try anything.

Two computed fields make the ledger evidence rather than data:

```python
# excerpt: atlas/flow/state.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def failures(self) -> list[str]:
        return [f"{r.step}:{r.outcome}" for r in self.records if not r.ok]

    @computed_field  # type: ignore[prop-decorator]
    @property
    def partial(self) -> bool:
        return bool(self.failures)
```

`failures` is a list of names, not a count — the fix for §8's failure, a system that knew *how many* branches failed and not *which*. `partial` is the label every degraded result must carry. Both are `computed_field` rather than bare properties so they survive `model_dump()` and an eval check can name them (invariant 11).

### 7.2 [core] The chain: three verdicts, five exits, and a write that is never retried

`run_chain` is two nested bounded `for` loops — stages, then attempts — so invariant 9 holds by construction. The interesting code is where a gate's verdict meets a stage's authority:

```python
# excerpt: atlas/flow/chain.py
            verdict = stage.gate(output.payload) if stage.gate else PASS

            # A gate may not ask for a retry of a write. Downgraded to an
            # abort, loudly, rather than silently obeyed or silently ignored.
            if verdict.action == "retry" and not stage.read_only:
                verdict = GateVerdict(
                    action="abort",
                    complaint=(
                        f"{verdict.complaint} (a non-read-only stage is never "
                        f"retried; aborting instead)"
                    ),
                )
```

Three decisions worth stating.

**A missing gate is `PASS`, not an error.** Not every stage needs one, and forcing a gate everywhere produces the gate everybody writes when forced: `lambda x: PASS` with a docstring. An ungated stage is honest about being ungated.

**A write is never auto-retried, and the rule beats both the config and the gate.** `read_only=False` clamps `max_attempts` to 1 regardless of what the caller passed, and a gate asking to retry a write has its verdict rewritten to `abort` with the reason appended. The alternatives are both worse: silently obeying performs a second write, and silently ignoring leaves a rejected write reported as success. Downgrading it *and saying so in the record* is the only option that leaves a reader able to reconstruct what happened.

**A stage that errored is not gated at all.** There is no payload to inspect, so there is nothing for a predicate to say. Errors are the caller's business through `max_attempts`; gates are for outputs that arrived and are wrong. Keeping the paths separate is what stops `attempt_cap` and `stage_failed` from becoming one indistinguishable exit — and a misattributed exit, per Phase 4's first defect, is worse than a missing one because it is actionable in the wrong direction.

The five exits are `complete`, `gate_abort`, `stage_failed`, `attempt_cap`, `token_budget`, each with a line that sets it. There is deliberately no `no_progress` and no `cycle`: a chain cannot revisit a stage, because the stage list is a list and the loop is a `for` over it. That is the structural version of Phase 4's point about `ready_steps` — when the harness owns the order, whole classes of guard become unnecessary rather than merely unused.

**The gate arithmetic, in code.** `atlas/cost.py` holds §6.2's formula, and its test asserts the prose's numbers so the two cannot drift:

```python
# excerpt: tests/test_cost.py
def test_gated_success_matches_the_worked_example() -> None:
    """Section 6.2's numbers, asserted so the prose cannot drift from them."""
    assert gated_success(0.8, 0.9, retries=1) == pytest.approx(0.944)
    assert chain_success(0.8, 0.9, 4, retries=1) == pytest.approx(0.7941, abs=1e-4)
    assert chain_success(0.8, 0.0, 4) == pytest.approx(0.4096)
```

The third assertion matters: with `q=0`, `chain_success` collapses to Phase 1's `episode_success(p, n) = p**n`. That is the relationship the module docstring claims, and a claim in a docstring that no test checks is a comment.

Why this arithmetic lives in `atlas/cost.py` and not in `atlas/agents/budget.py`, where the notation belongs: `budget.py` is Phase 1 Assignment 1 and ships as `NotImplementedError` stubs, and **[core] code may never depend on an assignment.** The functions moved; the notation stayed.

### 7.3 [core] The router: two weak classifiers beat one confident one

The shape of the module is the argument. There is no function that takes a string and returns a callable. The model returns a `RouteDraft` — a label from a closed `Literal`, a confidence, a fifteen-word reason — and `dispatch_table` maps labels to handlers, refusing at wiring time to build a table with a missing or unknown key. That refusal is the closest thing in Atlas to dispatch-by-name, and note what it will not accept: a string.

The second classifier is free. `keyword_route` scores cue words per route and returns a route plus a confidence built from the **margin** rather than the raw count, because two cues for one route and none for another is a signal, while two each for two routes is the absence of one. It is weak on purpose: strong enough to disagree usefully, not strong enough to be trusted alone.

Then the load-bearing sixteen lines, pure, with eleven tests:

```python
# excerpt: atlas/flow/route.py
    has_opinion = keyword_confidence >= KEYWORD_MIN_CONFIDENCE
    disagreed = has_opinion and keyword_hint != model_route
    confidence = min(model_confidence, disagreement_cap) if disagreed else model_confidence

    if disagreed and model_route in SIDE_EFFECTING_ROUTES:
        return RouteResolution(
            route=FALLBACK_ROUTE,
            confidence=confidence,
            source="fallback",
            fallback_used=True,
            reason=(
                f"model chose {model_route} (a side-effecting route) but the "
                f"keyword prior said {keyword_hint}; a write is never taken "
                f"over a disagreement"
            ),
        )
```

Four things are happening and only the first is obvious.

**A disagreement caps the confidence rather than overriding the route.** The keyword prior does not get to win; it gets to introduce doubt. Two independent classifiers disagreeing is evidence that the request is ambiguous, and a capped confidence usually falls below the threshold and lands on the fallback — which is the handler you want for an ambiguous request. Note what agreement does: *nothing*. It leaves the number alone. Corroboration is not licence to inflate a self-report.

**The side-effecting guard is written separately even though rule 4 usually covers it.** With `DEFAULT_THRESHOLD = 0.6` and `DISAGREEMENT_CAP = 0.5`, a capped confidence always falls below the threshold, so this branch looks redundant. It is not: someone will lower the threshold, and the property "a write is never taken over the objection of a free deterministic classifier" must hold at *any* threshold. The test states it as a property over every route pair and five confidences rather than as an example, which is how you test an invariant instead of a case.

**The failure mode is the safe one, and it is measurable.** A genuine write request whose topic words outvote its verb gets sent to a read-only handler; the user gets an answer instead of an action. That is the conservative failure and it is not free — §9 lists it as a pitfall whose remedy is measurement rather than loosening the rule. The `_ACTION_BONUS` weight in `keyword_route` exists for exactly this case: "save the warranty policy document" scores three document cues against one action cue, so the prior would confidently call a write a lookup and then block it. Weighting an imperative verb above a topic word makes that request a *tie*, and the prior reports a tie as no opinion, handing the decision to the model. The comment names the request that motivated the constant, because a tuning constant without a named motivating case is a number nobody can safely change.

**Every input is recorded, not just the outcome.** `RouteDecision` carries the model's route and confidence, the keyword hint and its confidence, the resolved route, the source, `fallback_used` and the reason. That is Corollary 1 made concrete: §11's routing-accuracy eval task grades `route` against a labelled request set *without running a handler*, and a disagreement rate is computable from the same records.

One more design note, a failure-handling decision hiding in a classifier:

```python
# excerpt: atlas/flow/route.py
        return RouteDecision(
            request=request,
            route=FALLBACK_ROUTE,
            confidence=0.0,
            source="fallback",
            fallback_used=True,
            reason=f"classifier failed: {type(exc).__name__}",
```

A classifier that produced unparseable output, hit a budget refusal, or got a 400 has failed three ways with one remedy: send the request to the safe handler. So the control flow does not branch on the exception type — but the type is *recorded*, so a sweep can tell a truncation from a budget refusal without the code caring. Same split as Phase 3's `error_kind`: one code path, typed evidence. And the handler catches `Exception`, not `BaseException`, with no `KeyboardInterrupt` guard inside it — the first draft had one, and it was unreachable, which is Phase 4's dead stop reason in coverage-report shape (F-05-07).

### 7.4 [core] The cost estimator

Three pieces, and the discipline is in how they are separated.

**`RateCard` is data with provenance**, validated on load: an ISO `checked_on`, a `source`, non-negative rates, and `extra="forbid"` so `prompt_per_mtoken` — a typo I made writing the tests — fails loudly instead of silently defaulting. This is *not* the D-19 case. D-19 says a record the harness writes must accept its own dump; a file a *human* fills in is the opposite situation, and `extra="forbid"` is right for exactly that reason. The switch is the same; the argument for it differs, and knowing which argument applies is what stops you applying either everywhere.

**`estimate_cost` is arithmetic** over two ints and a card. Ints rather than a `Usage`, so it works over a completion, a trajectory, a ledger, a whole sweep, or a hand-written what-if with no adapter.

**`RequestAccount` is the per-request record**, and money is deliberately not a field:

```python
# excerpt: atlas/cost.py
class RequestAccount(BaseModel):
    request_id: str
    route: str = ""
    model_calls: int = 0
    tool_calls: int = 0
    cache_hits: int = 0
    prompt_tokens: int = 0
    completion_tokens: int = 0
```

Tokens and calls are facts about the request; a price is a fact about a provider on a date. Store the second on the record and every archived account silently claims a price that has since changed. So `RequestAccount.estimate(card)` produces cost on demand, and `render(card=None)` prints units only — which is also what makes `make results` legitimate at $0.00 on Tier A with the shipped all-zero local card.

`account_from_parts` sums plain mappings and *ignores* unknown keys — a deliberate asymmetry with the rate card. A summing function that rejects extra fields cannot consume a record from a later phase, and this one has to survive eleven more. Rejecting unknown keys protects you where a typo means a lost value; ignoring them protects you where a new field means a new phase.

**Your turn (10 minutes).** Copy `data/rate_cards/tier_h.example.json` to `tier_h.json`, fill it in from your provider's published pricing with today's date and the URL, then compute what your last Phase 4 `make results` run would have cost at those rates. Write the number in `docs/RESULTS.md` with the date. If it is uncomfortably large, you have found why this phase exists — and note it would have been larger before Phase 2's cache.

---

### 7.5 [core] The async fan-out, and a speed-up you can measure

Three files change: `atlas/llm.py` gains async, `atlas/flow/parallel.py` is new, nothing else moves.

**The decision not to write an async HTTP client.** The obvious move is `AsyncOllamaHTTPClient` beside `OllamaHTTPClient`. I did not write it, and the reasoning is worth more than the code would have been. Invariant 7 says nothing outside `atlas/llm.py` builds a request; a second transport means a second `build_body` call site, a second retry path, and two places a header can go missing. A model call is I/O-bound, and a blocking call parked in a worker thread overlaps *exactly as well* as a non-blocking one on an event loop. So:

```python
# excerpt: atlas/llm.py
    async def acomplete(self, messages: Sequence[Message], **kwargs: Any) -> Completion:
        import asyncio

        def call() -> Completion:
            if not self.serialize:
                return self.inner.complete(messages, **kwargs)
            with self._lock:
                return self.inner.complete(messages, **kwargs)

        return await asyncio.to_thread(call)
```

Nine lines instead of a transport, and every existing client — Ollama, OpenAI-compatible, budgeted, cached, recording — becomes async for free. `to_async(client)` returns the client unchanged if it already has `acomplete`, so the adapter is idempotent. That is **D-27**.

The `serialize` flag is the one subtlety, and it is a testing decision with teeth. `FakeLLMClient`'s fixture cursor is not thread-safe, and more importantly **a fixture list is an ordered resource**: two workers pulling from one cursor makes which branch gets which scripted reply depend on thread scheduling. So `to_async` turns serialisation on for tier F and off everywhere else. Tier F gives up nothing — there is no I/O to overlap — and the four Phase 5 eval tasks stop being a race that passes on my machine (F-05-05). `FakeAsyncLLMClient` also records `max_concurrent`, the high-water mark of calls in flight, which is how the semaphore's ceiling gets *asserted* instead of hoped for.

**The fan-out.** `gather_bounded` takes `Branch` objects — a name plus a factory returning a fresh awaitable. The factory rather than a coroutine is a small decision with a real reason: a coroutine object can be awaited only once, so storing one would make a branch un-retryable, and it starts nothing until gathered anyway. The three guards live here:

```python
# excerpt: atlas/flow/parallel.py
        try:
            if timeout_s is None:
                payload = await branch.make()
            else:
                async with asyncio.timeout(timeout_s):
                    payload = await branch.make()
        except asyncio.CancelledError:
            raise
        except TimeoutError:
            return BranchResult(
                name=branch.name,
                kind="timeout",
                error=f"exceeded {timeout_s}s",
                latency_s=round(time.perf_counter() - started, 4),
            )
```

Read the `except` clauses in order, because their order is the design. `CancelledError` is caught **only to re-raise it**: swallowing a cancellation breaks `fail_fast` and the whole-workflow deadline, because a task that refuses to be cancelled cannot be cancelled. (It inherits from `BaseException`, so the broad `except Exception` below would not catch it anyway; the clause is there so a future reader does not "tidy" the broad handler upward.) Then a timeout becomes a `BranchResult` **next to the `except` that produced it** — a timeout must produce a record, and the way to guarantee that is to build the record where the exception is caught rather than three frames away.

Then the line §8 is about:

```python
# excerpt: atlas/flow/parallel.py
            raw = await asyncio.gather(*tasks, return_exceptions=True)
```

Required, not stylistic. With the default, the first raising branch propagates out of `gather` and its siblings are left running with nobody reading their results — the work happens, is paid for, and is discarded. And because `_run_one` already converts a branch's own failure into a value, anything arriving as an exception in `raw` is a bug in the *harness* rather than in a branch. It is still recorded rather than raised, for the same reason: a harness bug that hides three good branches costs more than one that reports itself.

**`FanoutResult` is where labelling lives.** `failures` is a list of `name:kind` strings, not a count. `partial` is a boolean the caller cannot miss. `usable` counts branches that produced a payload and is the denominator for `vote_reduce` — dividing agreement by the *branch* count would report a timeout as a dissenting vote, which understates agreement and makes a fan-out look like it disagreed with itself when in fact it fell over. And `satisfied` is deliberately not "nothing failed": under `partial` one usable payload satisfies the fan-out, under `all_or_nothing` nothing less than all of them does, and the policy is a parameter because this module cannot know whether three sources out of four is a research brief or a botched reconciliation.

**The measured speed-up.** `summarise_texts` fans out one summary per document with a `limit`, a per-branch timeout and an optional deadline. `gather_sequential` runs the identical branches one at a time and lives in the library rather than in the measurement script, so the two arms differ by one function call instead of two implementations. The offline test asserts the ordering property over scripted sleeps with generous margins; the real numbers go to `docs/RESULTS.md` via `make results`.

Expected ranges, **author estimate, unmeasured**, 8 documents, `limit=3`, seed 7:

| Tier | Sequential wall clock | Concurrent wall clock | Speed-up |
|---|---|---|---|
| A (local, 16 GB, no GPU) | 8 × 6–12 s ≈ 50–95 s | 40–90 s | **0.9–1.3×** |
| H (hosted) | 8 × 1–3 s ≈ 10–25 s | 3–9 s | **2.5–4×** |

The Tier A row is not a typo. A local runner is one process on one machine: eight concurrent requests queue behind the same weights, and under memory pressure the concurrent arm can be *slower*. Concurrency overlaps waiting, and on Tier A there is little waiting to overlap. This is why the speed-up experiment is tagged **[Tier H recommended]**, while everything about *correctness* — ordering, ceilings, timeouts, partial labelling — is Tier F and free. What Tier A shows you is the useful thing: the pattern's cost model depends on where the bottleneck is, and "add concurrency" is not a synonym for "faster".

**Your turn.** Run `make results ARGS=--quick` and read the two wall clocks. Then set `limit=1` and run again. If the three numbers are within noise of each other, you have measured your own hardware rather than the pattern — and that is worth a `docs/RESULTS.md` row.

### 7.6 [core] The orchestrator-workers pipeline

`atlas/flow/orchestrate.py` reuses Phase 4 wholesale: `make_plan` for the orchestrator call, `validate_plan` for the free structural check, `ready_steps` for the level set, `check_result_kind` for the shape gate, `critique_plan` for the mechanical critic. What is new is §6.5's three properties.

**Fan-out per level.** A bounded `for` over levels; each level is one `gather_bounded` over `ready_steps(plan)`. `ResearchResult.max_parallelism` records the widest level actually run, and a value of 1 tells you the planner wrote a chain and the fan-out bought nothing. That diagnostic is worth having, because "we parallelised the pipeline" and "the plans have no independent steps" look identical from outside.

**Worker isolation, which is invariant 20 applied per step.**

```python
# excerpt: atlas/flow/orchestrate.py
        scoped = scoped_registry(registry, [step.tool] if step.tool else [])
```

One line, and the most security-relevant line in the phase. A step that declared `query_db` gets a registry containing `query_db` and nothing else; a step that declared no tool gets an **empty** registry. Phase 3 said the registry is the security model and a prohibition is best implemented as an absent tool; this narrows the action space from per-episode to per-step, the strongest version available without a sandbox. And the reporting consequence is nicer than I expected: when a worker calls a tool that exists in the episode but not in its own scope, the batch is refused by invariant 24's existing check and the note says *outside this step's scope*. The isolation reports itself as data, so a `make results` row can tell you how often the planner's `tool` declaration and the worker's actual choice disagree.

Tool dispatch inside a worker stays **synchronous**. The tools are local — SQLite, files, an in-process index — so there is nothing to overlap, and an async tool layer would be a second dispatch path for no measured gain. Concurrency goes where the waiting is. What dispatch *did* gain is the cache: `cached_execute` in place of `execute`, so identical work across levels is served from the run's cache and `WorkerResult.cache_hits` records it.

**Provenance into the synthesis.**

```python
# excerpt: atlas/flow/orchestrate.py
    if bad:
        lines.append("")
        lines.append(
            "These steps produced nothing usable, so say what is missing "
            "rather than filling the gap: "
            + ", ".join(f"{w.step_id} ({w.note or 'no result'})" for w in bad)
        )
```

The synthesiser is *told what failed*. A model that does not know a branch failed will write around the gap fluently — that is not a defect, it is what a coherent-text generator does with an incomplete list — and the resulting brief is confident, cheap, and missing a quarter of its evidence with nothing in the output to say so. A test asserts this line reaches the prompt, and it is one of the few tests in this repo protecting a *prompt* property rather than a control-flow one.

Alongside it, the audit list:

```python
# excerpt: atlas/flow/orchestrate.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def cited_tools_that_worked(self) -> list[str]:
        return sorted(
            {name for w in self.workers if w.ok for name in w.tools_called}
        )
```

Two conditions again: the tool ran, *and* its worker passed the shape check. Phase 3's §8 failure was an answer citing a tool that errored; Phase 4's was a step that "succeeded" with the wrong input. The difference between this list and `tools_called` is exactly the set of tools that ran and proved nothing.

**The retry is still the graph — and this is where I got it wrong.** A worker whose shape check fails leaves its step `pending`, so the next level's `ready_steps` offers it again. No retry loop in this module, and there could not be one without creating a second owner for "what runs next". Under a fan-out that needs one extra thing: a branch that produced no worker record at all must still have its step advanced. My first version handled `kind == "timeout"` and nothing else:

```python
# excerpt: atlas/flow/orchestrate.py
        filed = {worker.step_id for worker in level_workers}
        for branch in fanout.branches:
            if branch.ok or branch.name in filed:
                continue
            step = plan.get(branch.name)
            if step is None or step.status != "pending":
                continue
            note = branch.error or f"branch ended {branch.kind} with no result"
            step.attempts += 1
```

A worker whose *model call raised* — transport error, exhausted fixtures — filed nothing, so its step stayed `pending` with **zero attempts**, `ready_steps` offered it again every level, and the episode ran four empty levels before exiting `level_cap` with `failed_steps == []`. Four attempts, no records, the wrong exit, and a green 727-test suite. That is invariant 27 broken in the phase that teaches invariant 27, and Phase 4's defect 1 recommitted one pattern over. It is `F-05-06`, and the rule it leaves behind is sharper than the one it broke:

> **When a unit's state is advanced by a classifier over outcomes — a branch kind, an error kind, a stop reason — enumerate that classifier's whole domain in code rather than matching the case you had in mind. A `Literal` with four members and one `if` is a bug waiting for the other three.** That is invariant 39.

A second defect in the same loop: when a later level came back with nothing usable, my first version set `level_failed` and skipped synthesis, discarding an earlier level's working findings. That is `all_or_nothing` applied by accident to a pipeline whose stated policy is `partial, labelled` (F-05-04).

> **A workflow's failure policy must be enforced where the workflow *ends*, not only where a branch fails. Every early exit is a policy decision, and an exit that skips the reporting step has chosen `all_or_nothing` whether or not anybody wrote that word.**

Six exits, closed, each with a line that sets it: `final`, `no_plan`, `bad_plan`, `level_failed`, `level_cap` (the default; fail closed), `token_budget`. No `replan_cap` — this pipeline does not replan, because a fan-out that replans has two control-flow owners. Replanning stays in `planexec`, which owns it.

### 7.7 [core] The evaluator-optimizer for one report section

`atlas/flow/optimize.py`, and the design is almost entirely the rubric.

`Rubric` is a tuple of `Criterion`, each **mechanical** (it carries a pure `check`) or **judgement** (it does not). `report_section_rubric()` ships three mechanical and two judgement criteria, and the ratio is the lesson: writing the rubric down forces you to notice how much of "is this any good" is checkable for free. Each mechanical criterion names one failure class — `numbers_are_grounded` catches a figure that appears in the answer and nowhere in the evidence, `within_length` catches truncation *and* the short answer that hides a gap, and `cites_only_working_tools` is the citation audit wearing a rubric's interface.

The acceptance rule is the whole of D-25:

```python
# excerpt: atlas/flow/optimize.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def accepted(self) -> bool:
        return (
            not self.mechanical_failures
            and not self.objections
            and self.score >= self.min_score
        )
```

Three conditions, and the model participates in exactly one, in one direction. `EvaluationDraft` has **no `accept` field** — no value the model can emit finishes a draft, because "good enough" is a termination decision and invariant 9 says the harness owns termination. The model's score is clamped to the rubric's bar rather than above it, so consulting a model can only ever *lower* the outcome relative to the mechanical verdict. D-17's asymmetry, one pattern over, with the same argument: let the model push in the direction where being wrong is recoverable.

`evaluate(payload, rubric=..., client=None)` with no client is a **complete evaluator** — the mechanical criteria decide, and the score is set to the bar because a check that was not performed must not be scored as a failure. That default lets the eval harness grade this pipeline with no model in the critic seat, exactly as Phase 4's `critique_plan(plan)` does.

**Wiring it to real findings, which is what makes the rubric non-vacuous.** A rubric is three checks with nothing to check against unless something supplies the evidence. `context_from_research(result)` is that join: `facts` is the successful workers' payloads with their tools attributed, `tools_ok` is `cited_tools_that_worked`, `tools_all` is every tool that ran. Then `report_section_producer(client, facts=...)` is the optimizer — a closure, so the *loop* stays testable with a plain function and this factory is the only place a model appears. Without the join, `numbers_are_grounded` compares the draft against an empty string and passes everything, which is a rubric that always accepts and a measurement worth nothing.

Two loop properties, both tested:

**The best round is returned, not the last.** `run_evaluator_optimizer` keeps a running best ranked by `(accepted, score − objections − mechanical failures)`. A revision that makes things worse cannot become the answer — which matters because Phase 4's evidence says revision moves answers in both directions, and this loop's justification is that an *external* signal makes the movement mostly upward. Mostly is not always. The test scripts round two to invent a number and asserts `best_round == 1`.

**A non-improving round stops the loop.** If round two does not beat round one, the signal is exhausted and a third round costs two calls to learn the same thing again. `max_rounds` defaults to **2**, and the docstring says what would justify raising it: a `make results` row showing round three earning its call. A default of 4 with no such row is a token multiplier with a plausible narrative attached.

Four exits: `accepted`, `round_cap` (the default), `no_improvement`, `producer_failed`. The producer is `Callable[[StageInput], StageOutput]` — the *same* two types the chain uses, so a stage drops into either pattern unchanged.

### 7.8 [core] The front door, and the tool-result cache

`atlas/flow/app.py` is the composition. `HANDLER_TOOLS` is the per-route action space — `chat` gets **no tools at all**, because a conversational answer that reached for the database was misrouted and taking the tools away makes that visible instead of plausible. `handle_request` classifies, dispatches through a validated table, and produces a `RequestAccount` summing **the router's tokens and the handler's**. Counting only the handler is the accounting error that makes routing look free, and it is the same error as counting only a plan-and-execute arm's executor steps.

One defect worth showing, because the fix is a general rule:

```python
# excerpt: atlas/flow/app.py
    table = (
        dispatch_table(handlers)
        if handlers
        else build_handlers(
            registry=registry, aclient=aclient, allow_writes=allow_writes, seed=seed
        )
    )
```

The first version was `handlers or build_handlers(...)`, so `dispatch_table`'s missing-route check ran on the table Atlas builds itself — the one that was already correct — and never on a caller-supplied one. A missing route surfaced as an `AttributeError` three frames later instead of a named `ValueError` here. **Validate at the boundary the value crosses, not at the one you happen to control** (F-05-03).

`atlas/tools/cache.py` closes §6.9's loop. The lookup is `idem_key`; the guard is two conditions:

```python
# excerpt: atlas/tools/cache.py
    spec = registry.get(call.name)
    if spec is None or not spec.read_only or not spec.cacheable:
        cache.refusals += 1
        return execute(registry, call, allow_writes=allow_writes), False
```

`write_file` ships with `cacheable=True` and is never cached anyway, and leaving it that way is deliberate belt-and-braces: the two flags answer different questions — authority and determinism — and a cache inferring one from the other would be wrong the first time somebody adds a non-deterministic read-only tool. `current_time` is the standing counterexample and is `cacheable=False` at its definition.

Two accounting decisions worth copying. A **refusal is not a lookup**, so a workflow calling the clock a lot does not look like a workflow with a broken cache: `hit_rate` answers "is the cache working", `refusals` answers "how much of my traffic is cacheable at all". And a **failed result is never stored**, because caching a transient tool error makes it a permanent wrong answer for the rest of the run — and these error messages are written for the model to act on, which it cannot do if the retry hands back the same message from memory.

The cache is in-memory and **per request**, not per process: a research plan repeats work across levels often enough to pay for itself (a shipment total queried once for the count and again for the average), while a cache outliving the request would serve yesterday's corpus. And it does no in-flight de-duplication: two steps in the *same* level doing identical work may both miss, because neither has finished when the other looks. The regression test says exactly that, and asserts what must always hold — `hits + misses` equals the number of cacheable calls — rather than asserting a scheduling detail, which was F-05-05's mistake.

**A defect worth naming, because a green suite hid it.** The cache above was built, tested, and for one draft **wired nowhere**: `RequestAccount.cache_hits` could only ever read zero. Nine passing tests exercised the mechanism and none exercised the system.

> **Invariant 41: a mechanism is wired or it is not shipped.** Every counter on a record has a line that increments it in a real execution path, asserted by a test that runs that path.

### With an assistant

**Safe to delegate.** The pure arithmetic in `atlas/cost.py` given §6.9's formulas (they are stated exactly, so output is checkable line by line); the `_CUES` keyword table, which is data entry you should then *test*; the boilerplate `computed_field` blocks; and repetitive test bodies once you have hand-written the first three of a family.

**Not safe to delegate.** Five things, and they are the five this phase is about. The **fallback route** — an assistant asked for "a router with a confidence threshold" will route low confidence to the cheapest handler, because that is what most published examples do; that is D-22 inverted and it is the expensive bug. The **`return_exceptions` and `CancelledError` handling**, where §8's defect lives. The **acceptance rule**, because the natural design is an `accept: bool` on the model's schema, which hands the exit condition to the model. The **branch-kind enumeration** of §7.6, since matching the one case you were thinking about is what an assistant will happily do. And any **default you cannot defend** — `worker_limit`, `max_rounds`, `DISAGREEMENT_CAP`, the token caps — because a tuning constant with no named motivating case is a number nobody can safely change later.

**A prompt that works:**

> Here is `atlas/cost.py` (attached). Add a pure function `sectioning_speedup(n_branches, limit, per_call_s, overhead_s)` returning the expected wall-clock ratio of a sequential fan-out to a bounded concurrent one, assuming constant per-call latency. Include the ceiling-division behaviour when `n_branches` is not a multiple of `limit`. Raise `ValueError` on out-of-domain input, matching the style of `cascade_break_even` exactly. Then write the pytest cases, including `limit=1` (ratio 1.0), `limit >= n_branches`, and `n=7, limit=3`. Do not touch any other function. Do not add a dependency.

It works because the specification is complete, the domain errors are named, an in-repo function is the style target, the awkward test case is enumerated, and the blast radius is fenced. Compare "add cost estimation to Atlas", which gets you a rate card with hard-coded prices, no date, and a docstring asserting they are current.

---

## 8. [core] Debug this trace: the fan-out that dropped a branch

Two failures, one trace. The first is the one the phase brief names — a fan-out that silently dropped a branch's failure — and it is the bug my own first draft of `gather_bounded` shipped. The second survives the fix for the first, and is the more interesting of the two.

### Part one: the dropped failure

A `research` request, run against the first draft, which called `asyncio.gather(*tasks)` with the default `return_exceptions`:

```
task: Compare warranty claim volume across our four product lines and flag
      anything unusual for the ops review.
route: research (confidence 0.88, source model, fallback_used False)

plan (4 steps, 1 level):
  s1 [query_db]   claims by product line          expects rows
  s2 [query_db]   shipments by product line       expects rows
  s3 [read_file]  warranty policy window          expects text
  s4 [search_web] recent supplier notices         expects text

fan-out: 3 branch(es), limit 4, 4.10s wall clock, policy partial
  s1               ok       product_line | claims\nAtlas-100 | 41\nAtlas-2...
  s3               ok       Warranty covers 24 months from shipment date...
  s4               ok       (no results)

critique: no findings. verdict accept.

answer:
  Claims are concentrated in Atlas-100 (41) and Atlas-400 (38), with the
  24 month warranty window meaning claims continue to arrive well after a
  unit ships. No supplier-side issues were found.

request account: r-0912 route=research calls=5 tools=3 cache_hits=0
                 tokens=4,102 latency=6.4s
partial: False
```

**Read it before the diagnosis, and count.** The plan has four steps. The fan-out reports **three branches**. There is no `s2` line, no failure, no timeout, no note — and `partial` says `False`.

What happened: `s2`'s worker raised. The query hit the base-table restriction (D-08) and `_run_worker` propagated the client's error, so `gather` — with `return_exceptions` at its default — propagated the first exception it saw. The surviving three tasks kept running in the background, their results were collected by nobody, and the enclosing code caught the exception, logged it at debug level, and continued with whatever had been collected. Then everything downstream behaved *correctly on the data it was given*: the shape gate saw three well-formed payloads, the mechanical critic found no failed steps because there were no failed step records, and the synthesis wrote a brief about claims with no shipment denominator anywhere in it.

**Four things to notice, because each is a general lesson.**

1. **The absence is the evidence.** Nothing in that trace is *wrong*; a line is *missing*. This is the hardest class of bug to see in a log, and it is why `FanoutResult` reports `n_branches` at all — a fan-out whose branch count differs from its input count is a bug, unconditionally, and it is one assertion.
2. **`partial: False` is a lie told by an honest mechanism.** It was computed from the branches present, and the branch that failed was not present. A label derived from a filtered collection is a label about the filter.
3. **The critique passing is not a second opinion.** `mechanical_findings` walks the plan's steps; `s2` was still `pending` with no record, and "pending" is not "failed". Two mechanisms, one blind spot, because both read the same incomplete data.
4. **The cost account looks *good*.** Five calls instead of six, 4,102 tokens instead of ~5,400. A dropped branch is a saving, right up until you notice what you bought.

**The fix, and it is one keyword plus two structures.** `return_exceptions=True`, so a raising branch comes back as a value in argument order; `_run_one` converting the branch's own failure into a `BranchResult` next to the `except` that caught it; and `FanoutResult.failures` naming what failed rather than counting it. The test that pins it scripts branch two to raise and asserts branches one and three still appear in the output — which is the test I did not have when I wrote the draft. `F-05-02`.

Then, because a fixed harness can still be misused, one more: the level loop must advance the *step* for a branch that filed no worker record. Handling only `kind == "timeout"` there produced `F-05-06` and invariant 39, which is §7.6's story.

### Part two: the branch that succeeded and said nothing

Re-run the same request against the fixed fan-out and you get a trace where every branch is present and every branch is `ok`:

```
fan-out: 4 branch(es), limit 4, 11.90s wall clock, policy partial
  s1               ok       product_line | claims\nAtlas-100 | 41\nAtlas-2...
  s2               ok       product_line | units\nAtlas-100 | 1240 ... [truncated]
  s3               ok       Warranty covers 24 months from shipment date...
  s4               ok       (no results)

answer:
  Claim rates are broadly consistent across the range, at roughly 3 claims
  per 100 units shipped, with Atlas-400 slightly above the others. The 24
  month warranty window means claims continue to arrive well after a unit
  ships, so the recent uptick on Atlas-400 is within normal seasonality.
  No supplier-side issues were found.

partial: False
```

Two wrong claims, and this time nothing is missing from the trace.

**`s4` returned `(no results)`.** The web index has no supplier notices for the seeded corpus, so `search_web` succeeded and returned nothing — and `check_result_kind("text", "(no results)")` **passes**, because `(no results)` is well-formed text. The worker was `ok`. And the synthesis, given `- [s4] (via search_web) (no results)` among its findings, wrote **"No supplier-side issues were found."** That sentence is not in the evidence. The evidence says *we looked and the index had nothing*, which is a statement about the index; the brief makes a statement about the world.

**`s2`'s table was truncated** at `max_output_chars`, with the marker at the *end* of the table where `format_rows` puts it. The shape gate saw a well-formed table and passed it. The synthesis divided a four-line claims table by a one-line shipments table, got a plausible ratio for `Atlas-100`, and generalised it to the range.

### The diagnosis, in the order the causes matter

**Cause 1: `ok` conflates "the tool ran" with "the step produced its evidence."** Phase 3's §8 (right answer, fabricated provenance) and Phase 4's §8 (wrong answer, immaculate provenance) meeting in a third place. Phase 4's `expects` separates "returned" from "worked" — for *shape*. `(no results)` and a truncated table are both correctly shaped. **A shape gate cannot catch an emptiness or a completeness failure, and §6.2's arithmetic says so in advance: for that failure class, $q = 0$.**

**Cause 2: an empty result and a missing result take different paths and need the same treatment.** The pipeline handles a *failed* branch well — `failures`, `partial`, and the "say what is missing" line into the synthesis prompt. An empty-but-successful branch bypasses every one of those. The fix is not a new mechanism; it is routing an empty result into the mechanism that already exists.

**Cause 3: truncation is invisible at the workflow layer.** `ToolResult.truncated` has existed since Phase 3 and is `True` on that `s2` result. Nothing in `WorkerResult`, `BranchResult` or `ResearchResult` carries it. A field that exists on the inner record and is dropped by the outer one is Phase 4's private-accumulator defect exactly (invariant 31): the total is there, the thing it depends on is not.

**Cause 4, and the one to sit with: `partial: False` was the most confident lie in the trace.** Every other error above is recoverable by a suspicious reader. That flag *tells* the reader not to be. A label reporting completeness must be derived from the strongest available evidence of incompleteness, and here it was derived from branch status alone.

### The fix, smallest first

1. **Make emptiness a first-class outcome** (code, free, catches the whole class). A pure predicate: a payload that is empty, is a known no-result marker, or is a header row with no data is not a usable result, and its step goes to `failed` with a note saying *the tool succeeded and returned nothing*. That reuses the existing partial-result machinery, and one test asserts `(no results)` reaches the synthesis prompt in the "say what is missing" list rather than among the findings.
2. **Propagate `truncated`** from `ToolResult` to `WorkerResult`, `BranchResult` and `ResearchResult.truncated_steps`, and fail a step on truncation **when its `expects` is `rows`** — a truncated table is a wrong total, whereas a truncated prose summary is merely shorter.
3. **Derive `partial` from every available signal**: any failed branch, any incomplete plan step, any truncated `rows` result, any empty result. Two lines in a computed field, and the highest-value lines in the fix.
4. **Only then, the prompt.** Forbid the synthesis from turning an absence into a negative finding: an empty search means *we found no record of X*, never *there is no X*. It goes **last**, because it is the one fix whose effect you cannot verify without a `make results` run, while the first three are deterministic.

Steps 1–3 are Assignment 1.

**What not to do.** Do not raise `worker_limit`, do not lower the timeout, and do not add a model critic to look for this. The critic *did* run and found nothing, and would find nothing on a second pass, because judging "is this table complete?" requires the row count of a table nobody kept. The signal exists in `ToolResult.truncated` and in the payload's shape. **When a verifier missed something, ask what evidence it was given before you ask for a better verifier** — Phase 4 said reflection is a transport mechanism for a verifier's output, and this is what happens when the verifier had nothing to transport.

`docs/FAILURE_LOG.md` records part one as `F-05-02` and part two as `F-05-01`, with the four causes and the fix order. Note what the phase inherits: Phase 3's §8 was *right answer, fabricated provenance*; Phase 4's was *wrong answer, immaculate provenance*; part two here is **wrong answer, immaculate provenance, and a completeness label asserting there is nothing to check.** Each phase's failure has been one layer further out than its predecessor's verifier, which is a pattern worth expecting rather than being surprised by.

**How to read your own traces.** `atlas.trace.format_research_trajectory(result)` renders one episode top to bottom — plan, then each level's fan-out with its workers, then the critique, then the answer, then the labels. The `PARTIAL:` line is printed **last**, because that is where a reader's eye stops and this section's failure was a caveat nobody saw. `save_research_trajectory` / `load_research_trajectory` round-trip it by value, so a failing episode becomes a fixture you can argue about.

---

## 9. [core] Common pitfalls & how professionals avoid them

**Routing an unsure request to the cheapest handler.** The universal first design, and it converts an ambiguity into a fluent unsourced answer. Professionals make the fallback the most capable read-only handler and record `fallback_used`, so the cost of ambiguity is a number in a report rather than a mystery in an inbox.

**A confidence you did not calibrate.** A model's self-reported confidence is a self-report; treating it as a probability makes a threshold theatre. Two defences: reconcile it against an independent classifier and cap on disagreement, and — the one that settles it — plot route accuracy against reported confidence over a labelled set. If accuracy at 0.9 is no better than at 0.6, your threshold is a random number and you should replace it with a rule about which routes are permitted at all.

**`asyncio.gather` with the default `return_exceptions`.** §8, part one. One raising branch propagates, siblings run unread, the work is paid for and discarded, and the trace shows a *missing line* rather than an error. Professionals use `return_exceptions=True` with per-branch records, or a `TaskGroup` when the whole set genuinely must succeed together — and they write the test where branch two raises and one and three still appear.

**A fan-out with no ceiling.** Fifty documents, fifty concurrent requests, a rate limit, and a retry storm. The semaphore is one line and its absence is invisible until the input list gets longer.

**Matching one case of a closed set.** Invariant 39. `if kind == "timeout"` where four kinds exist froze a step at zero attempts for a whole phase. Professionals enumerate the domain — or write the `else` that raises.

**Silent partial success.** Professionals label it (`partial`, `failures` by name), tell the *synthesiser* what is missing, and make the completeness flag depend on every incompleteness signal they have rather than the one easiest to compute.

**Compensation invented after the fact.** "We'll undo it if a later step fails" is a design for a system whose writes have inverses. Most do not. The professional move is ordering: reads first, one write last, human gate in front — the shape Phase 12 formalises.

**A retry that re-pays for completed work.** Without an idempotency key a resumed workflow re-runs everything, and the tell is a cost report where a resume costs the same as a cold start. With one, check that the key excludes the attempt and includes the handler version; the second mistake is subtler and produces confidently stale answers.

**An evaluator that can approve.** Give a model an `accept` field and the loop's stopping behaviour becomes a model behaviour. Professionals compute acceptance from mechanical criteria and let the model only object.

**A refinement loop with no rubric.** More tokens, more motion, no measured improvement — and, because the drafts do change, a strong subjective sense that it is working. Write the rubric first; if you cannot, you have discovered that you do not yet know what "better" means, which is more useful than a loop.

**A rubric with nothing to check against.** The subtler version: three mechanical criteria and an empty evidence block, so everything passes. Professionals assert that the *criteria fire* on a known-bad draft before trusting a clean run.

**Cost numbers with no date.** A price from an unknown week is not a number. Professionals keep rates in a dated file and print the date with every figure, which also makes the annual "why did our estimate stop matching the invoice" conversation take five minutes.

**Measuring a speed-up on the wrong bottleneck.** Concurrency overlaps waiting. On a laptop model there is little to overlap, so a local speed-up near 1× is a fact about hardware. State where the bottleneck is *before* reporting a ratio.

**A mechanism wired nowhere.** Invariant 41, and I shipped it: a cache with nine passing tests and no caller, whose `cache_hits` counter could only read zero. Professionals assert the counter moves in a test that runs the *system*, not the unit.

**Adding a pattern because it is in the taxonomy.** Every pattern costs at least one extra call and one new failure mode. The discipline: if the model's output can change which code runs, count the branches it can reach; if a pattern does not change the call count, you changed a prompt; and if you cannot say which of §6.9's four levers a change pulls, you are not optimising, you are rearranging.

---

## 10. [extended] Industry perspective

**Routing is where the money is, and it is usually a small model or no model at all.** Teams running production assistants generally find a large share of traffic is trivial, and that the difference between charging every request at the top tier and charging most at the bottom is the difference between a viable unit economic and a demo. Anthropic's framing names it: send easy and common questions to a smaller, cheaper model and hard or unusual ones to a more capable one. What the taxonomy does not tell you, and teams learn expensively, is that the classifier is usually the cheapest component and the *most* worth investing in — because its errors are not distributed evenly. A misroute from cheap to expensive costs tokens; from expensive to cheap it costs a wrong answer, and those show up in different quarters and on different dashboards.

**Nobody's production pipeline is one pattern.** In practice a request goes through routing, then a chain with gates inside the chosen handler, then a fan-out somewhere in the middle, with an evaluator-optimizer on the one artifact a human will read. Anthropic's post is explicit that the blocks are not prescriptive and that complexity should be added only when it demonstrably improves outcomes. The composition to watch is the one Atlas now has: **a cheap classifier in front of an expensive pattern is what makes the expensive pattern affordable**, and teams that add the pipeline before the router tend to conclude the pipeline is too expensive to ship.

**Parallelism destroys the transcript, and nobody warns you.** A ReAct trace reads top to bottom, and a debugging session is a reading session. A fan-out produces four interleaved traces and a reduce, so "why did the brief say that" now requires correlating records by name. That is why the immutable ledger is not fussiness — a shop that adds concurrency without adding per-branch records loses its ability to debug at exactly the moment its failure modes get more interesting. It is also the strongest practical argument for the graph frameworks in Phase 9: what they mainly sell is not the fan-out, which is twenty lines, but the persistence, replay and inspection around it. And it is why §8's second half needed a *reader* before it needed a fix.

**Cost engineering is an organisational practice, not a code change.** Teams that keep costs flat while traffic grows have a per-request cost figure in standard telemetry from week one, a dated rate card in version control, and a habit of reporting cost per *successful* request rather than per call. That last metric resists gaming: an early exit that abandons work looks like a saving on cost-per-call and shows up honestly on cost-per-success. It also makes §6.2's and §6.9's arithmetic speak the same language as the finance conversation, which is much of why an engineer who can do both is disproportionately useful.

**Where the field is moving, stated carefully.** Two published directions, both from Anthropic's engineering writing, both pinned with their numbers in your `VERSIONS.md` rather than here: loading tool definitions on demand instead of all at once, and having the model write code that calls tools instead of piping every tool result back through the context window. Both attack the same term in §6.9's formula — $\bar{p}$ — and the reported reductions are large. Read them as evidence that prompt-size engineering is where the next order of magnitude is, and read the second alongside Phase 4's decision to defer CodeAct to Appendix F: the technique is real, and it moves your security perimeter from a tool registry to a sandbox, which is a Phase 14 conversation.

### Interview questions

1. **You have a five-way router at 88% accuracy and your PM wants 95%. What do you ask before agreeing this is a classifier problem?** (Strong answers reach the confusion matrix rather than the headline, distinguish expensive misroutes from cheap ones, ask what the fallback currently is, and notice that accuracy gains in the cheap-to-expensive direction may be worth nothing.)
2. **Derive the condition under which a cheap-then-escalate cascade saves money, then tell me the assumption in your derivation that breaks in practice.** ($f > c_s/c_l$; the assumption is a sound escalation test. Reaching the second half unprompted shows the candidate understands that cost and reliability are one problem here.)
3. **A four-branch parallel summarisation ships a report every morning. One branch has been failing for three weeks and nobody noticed. Walk me through every place that should have caught it.** (Per-branch records; a `partial` label on the artifact; the synthesiser being told what is missing; an alert on the failure *rate* rather than the error; the branch count differing from the input count; and the cost report, where three weeks of one fewer call is visible if anyone reads it.)
4. **When would you hard-code a decision a model could make?** (The branch-set, run-time-information and recoverability tests — plus the corollary that a delegated decision must be recorded as data to be measurable at all.)
5. **Your evaluator-optimizer improves outputs in every manual spot-check but shows no improvement in the eval suite. Three most likely explanations, in order?** (The rubric is not measuring what the eval measures; the loop returns the last candidate rather than the best; the spot-checks are on cases where the loop *changed* something, which is a biased sample. Mentioning that the evaluator and the eval grader may share a blind spot is thinking properly.)

---

## 11. [core] Capstone increment: the Atlas Router

*If your code diverged, start again from `atlas_phase_04.zip`.*

**Resume note.** Atlas answers questions with tools (Phase 3), plans multi-step work as a DAG it owns (Phase 4), and now **decides what kind of request it is before spending anything on it.** A greeting costs one call over an empty registry; a database question costs three or four over a two-tool registry; a research request fans out workers over a registry scoped per step, caches repeated tool work within the request, and comes back labelled if any worker produced nothing. Every request carries an account of what it cost, and a cost in money only if you supplied a dated rate card.

**Files touched.** New: `atlas/cost.py`, `atlas/flow/{__init__,state,chain,route,parallel,orchestrate,optimize,app}.py`, `atlas/tools/cache.py`, `atlas/prompts/files/{atlas_router,atlas_evaluator}.v1.md`, `scripts/phase05_results.py`, `evals/tasks/phase05.json`, `data/rate_cards/{tier_a.json,tier_h.example.json}`, nine `tests/test_*.py` (including `test_phase05_regressions.py`), two `tests/hidden/*`. Changed: `atlas/llm.py` (async), `atlas/schemas.py`, `atlas/tools/registry.py`, `atlas/tools/clock.py`, `atlas/trace.py`, `atlas/prompts/__init__.py`, `evals/run.py`, `tests/test_{prompts,llm_client,evals_harness}.py`, `Makefile`, `phase_03_tools_and_evals.md` (one excerpt, dated note — see below), and the five contract documents.

### Interface changes

Two additions and no renames.

```
# excerpt: ATLAS_INTERFACES.md
`ToolSpec.cacheable: bool = True` and `tool(..., cacheable=True)`. Additive
with a safe default; `current_time` sets it `False`. See D-26 and the Phase 5
capstone's interface-changes note.
```

**Migration note.** `ToolSpec` is a frozen dataclass and `cacheable` is appended with a default of `True`, so every existing construction, `@tool` decoration and third-party spec keeps working untouched. The one behavioural consequence: a tool that is read-only but non-deterministic will be cached by `cached_execute` unless you declare it, so if you have added such a tool since Phase 3, set `cacheable=False` now.

**And a cross-phase note worth reading, because the guard earned its keep.** Adding `cacheable=False` to the clock changed a line that the *Phase 3 document* quotes in a `# excerpt:` block, and `make check-docs` failed immediately. That is invariant 8 working: a cross-phase change must be **loud, not forbidden**. The resolution is in the tree — the Phase 3 document's block is updated and carries a dated note saying which phase changed it and why. Deleting the block, or pinning the manifest down to hide it, would have been the failure mode invariant 17 exists to prevent.

The second addition is `run_research_pipeline(..., cache=ToolResultCache())` plus `ResearchResult.cache_hits`, `WorkerResult.cache_hits` and `HandlerOutcome.cache_hits`, all defaulted, all additive.

```python
# excerpt: atlas/flow/app.py
HANDLER_TOOLS: dict[Route, tuple[str, ...]] = {
    "chat": (),
    "document": ("read_file", "list_files", "search_web"),
    "data": ("query_db", "calculate"),
    "research": ("query_db", "calculate", "read_file", "list_files", "search_web"),
    "tool_action": ("write_file", "read_file", "list_files", "current_time"),
}
```

### Tests added: 207 (536 → 743)

All Tier F, no network, no model. Families worth naming: eleven tests on `reconcile`, one asserting D-22 as a **property** over every route pair and five confidences rather than as an example; the fan-out ceiling test, which reads `FakeAsyncLLMClient.max_concurrent` rather than timing anything; the resume test, which asserts the stage function ran twice in total and the token total did not move; round-trip tests on all seven new records asserting **value equality on the totals** (invariant 31); and a 16-test `tests/test_phase05_regressions.py` that reads as a list of this phase's own mistakes.

```python
# excerpt: tests/test_flow_route.py
def test_a_write_is_refused_over_a_disagreement_at_any_threshold() -> None:
    """Rule 5 exists because rule 4 only covers threshold > cap."""
    r = reconcile("tool_action", 1.0, "data", 0.9, threshold=0.1)
    assert r.route == FALLBACK_ROUTE
    assert r.fallback_used is True
    assert "side-effecting" in r.reason
```

```python
# excerpt: tests/test_phase05_regressions.py
def test_a_raising_worker_call_advances_its_step(registry) -> None:
    """Invariant 27. Before the fix: 4 empty levels, step pending at 0 attempts."""
```

### Eval tasks: +4 (26 → 30 gradeable, 31 defined)

| Task | Suite | What it pins |
|---|---|---|
| `p05-route-accuracy-data` | capability | A database question reaches `data`, both classifiers agree, no fallback. Grades the classifier with **no handler run**. |
| `p05-route-refuses-unsure-write` | regression | D-22: the model says `tool_action` at 0.99, the prior disagrees, the route becomes `research` and the reason names "side-effecting". |
| `p05-fanout-labels-a-dropped-branch` | regression | §8's failure as a graded task: `partial` is `True`, `failed_steps` names `s2`, and the first worker's finding still ships. |
| `p05-account-counts-the-router` | capability | The account is 2 calls and 372 tokens — the classifier's 138 plus the handler's 234. |

The routing tasks are the one place where a hand-written expectation is legitimate ground truth, and it is worth saying why D-20 does not apply: **a route is a design decision, not a fact about the corpus**, so there is nothing to query. The moment an expectation *is* a fact about the data — a shipment total, a headcount — D-20 applies with full force, and `scripts/phase05_results.py` still queries those.

### `make results`, and a correction to the phase header

`make plan` prints the budget before spending anything: **231 Tier A calls** for the default three-trial sweep (39 routing + 123 handler + 48 summariser + 21 optimizer), ~80 with `--quick`. The phase block's "~800 per sweep" is an allowance, not a measurement; 231 plus `make evals --trials 3` on Tier A (~360) is the realistic upper end. That row is in `VERSIONS.md` with the command that produced it, because a budget you did not compute is a budget you will exceed — and because an earlier draft of `--plan` billed evaluator calls the script never made, which is a budget that lies in the flattering direction.

Fifteen `docs/RESULTS.md` rows are written and **unmeasured**, with labels byte-identical to the strings the script prints. Read five first:

- **`speed-up`** (0.9–1.3 Tier A, 2.5–4.0 Tier H). The Tier A number is your hardware, not the pattern.
- **`fallback share`** (0.10–0.35). Every fallback runs the research pipeline, so this is a budget line, and the cheapest attack on it is the label set rather than the model.
- **`disagreement share` against `routing accuracy`**. Low accuracy with *low* disagreement is the bad case: both classifiers agreeing and both wrong, which no threshold fixes.
- **`mechanical failures per section`**. Zero on every round means the rubric is vacuous against your output — most likely an empty findings block, so check `context_from_research` produced facts before concluding the writer is good.
- **`partial share`**, which **should not be zero**: three of the eight quick requests touch a corpus that cannot fully answer them, and `partial: False` on all eight reproduces F-05-01.

### Read five failing traces

`docs/FAILURE_LOG.md` gains seven worked entries — F-05-01 (the empty branch and the truncated table), F-05-02 (`gather`'s default: §8 part one), F-05-03 (a validation that ran only on the default path), F-05-04 (a level failure that discarded a usable partial result), F-05-05 (a fan-out over an ordered fixture list is a race), F-05-06 (the branch kind that froze its step — invariant 39), F-05-07 (the four defects the phase's own review found, including a mechanism wired nowhere) — plus **F-05-08, which is yours.** Run `make results` on Tier A, render five failing episodes with `atlas.trace.format_research_trajectory`, and write up the worst: the request, the route and confidence, the ledger, what each branch returned, which label was wrong, and the smallest deterministic change that would have caught it.

**Repo tag: `phase-05`.**

---

## 12. [core] Mastery checklist

You are ready to move on if you can:

* Draw all five patterns from memory and state, for each, the condition that makes it right and the failure mode it introduces.
* Apply the hard-code rule to a decision you have not seen before and defend the answer with the branch-set, run-time-information and recoverability tests.
* Compute a gated chain's success rate from $p$, $q$ and $n$, and say what $q$ means for a *specific* failure class.
* Derive $f > c_s/c_l$ on paper and name the assumption that breaks it.
* Explain why a router's fallback must be capable and read-only, and why that follows from the costs being incomparable rather than from caution.
* Write a bounded async fan-out with per-branch timeouts and a whole-workflow deadline, and say what each guard does that the others cannot.
* Look at a fan-out trace and notice a branch that is *missing*, then one that is present, `ok`, and empty.
* Say what an idempotency key must exclude, and why including it produces a mechanism that passes every test and does nothing.
* Explain why an evaluator gets no `accept` field.
* State what a cost figure needs beside it to be a number.
* Say why streaming is a Phase 16 concern and not a Phase 5 one.

---

## 13. [core] Quiz

1. A workflow and an agent differ in who answers one question. Which question, and how does the answer change what you can test?
2. A colleague adds a "verification step" to a chain by appending *"double-check your answer before responding"* to the stage's prompt, and reports that reliability improved. Using §6.2's arithmetic and Phase 4's evidence, say what is wrong with both the mechanism and the measurement.
3. Sectioning and voting appear in one diagram in the taxonomy. Give the precondition each requires that the other does not, and describe a task that satisfies neither.
4. Your cheap tier costs one eighth of your capable tier and handles 20% of requests acceptably. Compute the cascade's expected cost per request and say whether to ship it. Then say what single measurement would change your answer.
5. `asyncio.gather` has a `return_exceptions` parameter with a default. Explain, in cost terms rather than correctness terms, what the default costs you in a four-branch fan-out where one branch raises — and say what the *trace* looks like.
6. Atlas's router records `route`, `model_route`, `keyword_hint`, `confidence`, `source` and `fallback_used`. Three are strictly redundant for *executing* the request. Say why each is recorded anyway, and name the corollary they implement.

---

## 14. [core] Coding assignments

### Assignment 1 — Close the §8 gap **[fast track: do this one]**

Implement fixes 1–3 from §8, in `atlas/flow/orchestrate.py`.

**UNAIDED CORE:** `usable_payload(payload: str) -> tuple[bool, str]` — the pure predicate deciding whether a *successful* tool result actually constitutes evidence. Write it yourself, including the decision about what counts as an empty result, before touching anything else.

**Acceptance criteria.**

1. `usable_payload` is pure and returns a complaint written for the model to act on. It rejects the empty string, whitespace, the no-result markers Atlas's tools emit, and a table that is a header row with no data. It accepts a one-line table with data, a bare number, and ordinary prose.
2. A worker whose payload fails it is **not `ok`**, its step's note says the tool succeeded and returned nothing, and the step follows the existing retry-then-fail path.
3. The synthesis prompt lists an empty-result step in the "produced nothing usable" list, not in the findings.
4. `WorkerResult.truncated` and `ResearchResult.truncated_steps` exist and are populated from `ToolResult.truncated`; a truncated result **fails its step when `expects == "rows"`** and does not when `expects == "text"`.
5. `ResearchResult.partial` is `True` if *any* of: a failed step, an incomplete plan, a truncated `rows` result, an empty result.
6. `make test-offline` stays green, including `p05-fanout-labels-a-dropped-branch` and all 16 regression tests.
7. Add at least three tests of your own before running `make grade PHASE=05`.

**Hidden tests:** `tests/hidden/test_phase05_a1.py`. Do not read it.

### Assignment 2 — The cascade **[extended]**

Build `atlas/flow/cascade.py`: run the cheap tier, verify, escalate on failure.

**UNAIDED CORE:** the escalation decision. `run_cascade(task, cheap, capable, *, verify)` where `verify` is `Callable[[str], tuple[bool, str]]` — and the design constraint you must honour is that **the verifier is not the cheap model's opinion of itself**. Write down, in the module docstring, what your verifier checks and what it cannot.

**Acceptance criteria.**

1. `CascadeResult` records `payload`, `tier_used`, `escalated`, `stop_reason` (a closed `Literal` including `both_failed`), a `Ledger` with one record per tier attempted, and `total_tokens` that **bills both tiers on an escalation**.
2. A verified cheap answer never calls the capable tier. A cheap tier that errors escalates. Both failing yields no payload and `stop_reason == "both_failed"`.
3. `cascade_report(results)` returns `escalation_share`, `observed_f` and `break_even_f`, computed with `cascade_break_even` from the *measured* token ratio between tiers — not a constant you typed.
4. The record round-trips its own `model_dump()` with value equality on the totals.
5. Add a `make results` row for `observed_f` against `break_even_f`, and one sentence in `docs/RESULTS.md` saying whether your cascade pays.

**Hidden tests:** `tests/hidden/test_phase05_a2.py`.

---

## 15. [extended] Case study: invoice processing under a fixed monthly ceiling

**The situation.** A 40-person distributor receives about 4,000 supplier invoices a month by email: PDFs, scanned images, a few plain-text bodies. Finance needs, per invoice: supplier identity matched to the vendor master, line items with quantities and prices, totals and tax, a purchase-order match, and a flag for anything anomalous. Roughly 70% come from twelve regular suppliers in stable formats; about 15% are scanned; about 3% contain something genuinely odd (a credit note posing as an invoice, a duplicate submission, a currency mismatch).

Two hard constraints. **A fixed monthly cost ceiling**, given in tokens per month rather than currency, which will not rise. And **no invoice may be silently mis-posted**: a wrong figure reaching the ledger is far more expensive than an invoice landing in a human queue.

**Your task.** Design the pipeline. Deliver: (a) a diagram naming every pattern used and every gate; (b) the cost model, with arithmetic showing you fit under the ceiling, including what you do when volume spikes 30% in December; (c) the routing and cascade design with the escalation test named explicitly; (d) the failure-handling policy per stage — all-or-nothing, partial, or compensated — and the justification for each; (e) the three metrics you would put on a dashboard, one of which must be cost per *successfully posted* invoice; (f) the one thing you would build first given a week, and why.

**Rubric (100 points).**

| Criterion | Points | What full marks look like |
|---|---|---|
| Pattern selection and justification | 20 | Routing on format and supplier; chaining with gates inside each handler; sectioning only where subtasks are genuinely independent; an evaluator-optimizer confined to anomaly cases. Each choice tied to a stated precondition, and at least one pattern **rejected** with a reason. |
| Cost arithmetic | 20 | The four-factor model with named unknowns; a cascade break-even computed, not asserted; the December spike answered with a mechanism rather than a hope. Explicit statement of which lever each choice pulls. |
| The escalation test | 15 | A verifier that is **not** the cheap model's self-assessment: arithmetic checks, a PO match, a vendor-master lookup, a confidence-independent duplicate check. Full marks require naming what it cannot catch. |
| Failure handling and idempotency | 15 | Per-stage policy with justification; posting last and gated; an idempotency key on invoice identity so a retried email does not double-post; a statement of what compensation is and is not available. |
| Human-in-the-loop design | 10 | A queue sized against the anomaly rate and the ceiling; a target for what fraction of invoices a human sees; recognition that the queue *is* the fallback and its cost is real. |
| Measurement | 10 | Cost per successfully posted invoice; a mis-post rate with a stated measurement method; a partial/queued rate. Full marks note that a mis-post rate measured from complaints is a lower bound. |
| Honesty about scanned documents | 10 | OCR quality is the dominant uncertainty, acknowledged as a measurement question, with a plan to quantify the 15% before designing around it. |

**Deductions.** −10 for a fallback that posts to the ledger. −10 for any cost figure without a dated source. −5 for a fan-out with no concurrency ceiling. −5 for an evaluator that can approve.

A worked answer is in `phase_05_solutions.md`, deliberately as *one* defensible design with its trade-offs named rather than as the answer.

---

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 6.*

**Five patterns, one axis, and the axis is who answers "what runs next".** Chaining with gates (a fixed sequence, programmatic checks between steps), routing (classify then dispatch in code), parallelization in two unrelated flavours (sectioning buys latency and needs independence; voting buys reliability and needs comparability), orchestrator-workers (the model chooses the *shape*, the harness chooses the order), evaluator-optimizer (a bounded loop around a written rubric). Anthropic's taxonomy (19 Dec 2024) is the source; its own advice is to find the simplest thing that works and add complexity only when it demonstrably helps. The post now carries a banner saying its tooling landscape has changed, which is exactly why framework state lives in `VERSIONS.md`.

**The hard-code rule.** Delegate to the model only if all three hold: the branch set cannot be enumerated, the decision needs run-time information no cheap function can summarise, and a wrong branch is recoverable. Otherwise **code owns the decision and the model produces data the code branches on** (D-21). Two corollaries carry as much weight: a delegated decision must be **recorded as data** or it cannot be graded, and — Phase 4's counting rule's sibling — **if a model's output can change which code runs, count the branches it can reach.**

**A gate is the cheapest reliability lever in the book, and its value is computable.** $p' = p + (1-p)qp$. At $p=0.8$, $q=0.9$, one retry: 0.944 per stage, and a four-stage chain goes from **0.41 to 0.79** with no model in the mechanism. Linear in $q$, so a mediocre gate beats none; free on the happy path, costing $n(1-p)q$ extra calls in expectation, which is why gates are cheap in a way voting never is. And $q$ is the catch rate *for a named failure class*: a shape gate has $q=0$ against a well-shaped wrong number, which is §8.

**Cost is four factors and nothing else.** $k \times (\bar{p}r_{in} + \bar{c}r_{out})$. Fewer calls (early exits, whose saving is proportional to what is *downstream*), smaller prompts (declared dependencies, truncation, compression — and compression trades $\bar{p}$ against $k$, so it has a crossover), cheaper models (routing or cascading), free calls (caching). **A cascade pays iff $f > c_s/c_l$** — the cheap tier's success rate must exceed its price ratio — and the assumption that breaks it is not in the algebra: the escalation decision is a verifier, and with an unsound verifier you pay both tiers and ship the cheap tier's mistakes, because the confident errors are exactly the ones that do not escalate.

**The fallback must be capable and read-only (D-22).** Routing an unsure request to the cheapest handler converts an ambiguity into a fluent unsourced answer — the 75% shape Phase 4 measured. The costs are not comparable: a misroute upward costs tokens, downward costs a wrong answer with nothing to audit. `tool_action` is unreachable by fallback, and a side-effecting route additionally requires that a free deterministic classifier agree or abstain, **at any threshold** — which is why that rule is written separately from the one the default threshold already covers. Two weak classifiers that agree beat one confident one; disagreement caps the confidence, and agreement does *not* inflate it.

**State: the plan is the working set, the ledger is the account (D-23).** Frozen `StepRecord`s, append-only, one per attempt. An `idem_key` hashes the *work* — step, tool, canonicalised inputs, handler version — and **never the attempt or the run**, because a key identifying an attempt is a mechanism that never matches and still passes every test you thought to write. One lookup is simultaneously retry safety, the tool-result cache and crash recovery. A step whose tool is not `read_only` is never auto-retried, replayed or cached, and **read-only is not the same as deterministic**: `current_time` is the standing counterexample and declares `cacheable=False` (D-26).

**Async is an adapter, not a second transport (D-27).** `to_async` runs the existing client in a thread; every client became async for free and invariant 7 held. Three guards on every fan-out, none optional: a semaphore, a per-branch timeout, a whole-workflow deadline. `return_exceptions=True` is required, not stylistic. `CancelledError` is caught only to re-raise. A timeout produces a **record**, built next to the `except` that caught it. A fan-out over an ordered fixture list **serialises**, because a test whose outcome depends on thread scheduling is not a test (F-05-05). And **streaming is a Phase 16 concern**: it improves time to first token, changes nothing about cost or reliability, and cannot be gated until it ends — a gate on half a table is meaningless, and a reduce needs whole payloads.

**Concurrency overlaps waiting.** Expected speed-up on Tier A **0.9–1.3×**, Tier H **2.5–4×** (author estimate, unmeasured, 8 docs, limit 3, seed 7). A local speed-up near 1.0 is a fact about your laptop. State where the bottleneck is before reporting a ratio.

**The evaluator may withhold and may never grant (D-25).** No `accept` field on the model's schema; acceptance is computed from mechanical criteria, absence of objections, and a score clamped to the rubric's bar, so consulting a model can only lower the outcome. Return the **best** candidate, not the last. `max_rounds=2`, and raising it needs a `make results` row showing round three earning its call. Two preconditions: **if you cannot write the rubric down before you build the loop, build the rubric instead** — and a rubric needs *evidence*, which is what `context_from_research` supplies. Three mechanical criteria against an empty findings block is a rubric that always accepts.

**The failures this phase leaves you (§8).** Part one: `gather` at its default `return_exceptions` propagated one branch's exception, left three siblings running unread, and produced a trace whose defect was a **missing line** and a `partial: False` computed from the branches that survived the filter. Part two, which survives that fix: `search_web` returned `(no results)` — well-formed text, shape check passed, worker `ok` — and the synthesis wrote *"No supplier-side issues were found"*, turning a statement about an index into a statement about the world; meanwhile a truncated table passed the `rows` check and became a ratio computed from one product line. Four causes: `ok` conflates "the tool ran" with "the step produced its evidence"; an empty result bypasses the partial-result machinery a *failed* one goes through; `ToolResult.truncated` exists and every outer record drops it (invariant 31, one layer out); and **`partial: False` was the most confident lie in the trace.** Fix order: emptiness predicate, propagate truncation, derive `partial` from every signal, then the prompt — prompt last, because it is the only fix whose effect needs a measurement. Phase 3's §8 was *right answer, fabricated provenance*; Phase 4's was *wrong answer, immaculate provenance*; this is **wrong answer, immaculate provenance, and a completeness label asserting there is nothing to check.**

**Seven defects this phase committed, each with the rule it leaves behind.** (1) `gather`'s default lost siblings — F-05-02. (2) A validation ran on the table Atlas builds and never on the one a caller injects: **validate at the boundary the value crosses, not the one you control** — F-05-03. (3) A `level_failed` exit skipped synthesis and threw away a usable partial result: **a failure policy must be enforced where the workflow ends; every early exit is a policy decision** — F-05-04. (4) Two threads pulling from one fixture cursor made four eval tasks a race that passed on my machine — F-05-05. (5) `if kind == "timeout"` where four branch kinds exist froze a step at zero attempts, burned four levels and reported `level_cap` with `failed_steps == []`: **invariant 39, enumerate the classifier's domain** — F-05-06. (6) A cache built, tested and wired nowhere, whose counter could only read zero: **invariant 41, a mechanism is wired or it is not shipped** — F-05-07. (7) Seven new record types and no reader, while the failure log told students to read traces: **invariant 40, a record ships with its reader in the same commit** — F-05-07.

**Measurement discipline.** `make plan` prints the budget before spending: **231 Tier A calls** for the default sweep, ~80 with `--quick`; the header's ~800 was an allowance, and an earlier `--plan` billed calls the script never made. Fifteen unmeasured `RESULTS.md` rows whose labels are byte-identical to the script's. Routing labels are hand-written and that is legitimate — **a route is a design decision, not a fact about the corpus** — so D-20 does not apply to them and applies with full force to everything else. A cost figure prints only with its rate card's `checked_on` date (D-24), and `RequestAccount` stores tokens and calls but never money.

**Scripted fixtures prove control flow and nothing about models.** They prove results return in argument order, the semaphore's ceiling holds, a failing branch does not lose its siblings, a raising branch still advances its step, a write is never retried, a resumed chain charges zero, a side-effecting route is refused over a disagreement at any threshold, and the synthesiser is told what is missing. They prove nothing about whether a real classifier routes well. That is `docs/RESULTS.md`, with a tier, model, seed and date.

**Repo state at `phase-05`.** `atlas/cost.py`, `atlas/flow/{state,chain,route,parallel,orchestrate,optimize,app}.py`, `atlas/tools/cache.py`, async and a research reader in `atlas/llm.py` and `atlas/trace.py`, two checksum-pinned prompts, two rate cards, `scripts/phase05_results.py` with `--plan`/`--quick` and four experiments. **743 offline tests** (from 536), **30 gradeable eval tasks** (from 26, 31 defined), `ATLAS_INTERFACES.md` **v0.12** with invariants 33–41 and D-21 to D-27, seven worked `FAILURE_LOG.md` entries plus a stub for yours, fifteen unmeasured `RESULTS.md` rows. **Twelve assignments outstanding.**

**Phase 6 next: documents.** Chunking, embeddings, and the retrieval that turns document search from a keyword scorer into something that finds the answer — at which point four things here become load-bearing. The `document` route already exists and currently reaches a keyword scorer, so retrieval is a *handler upgrade* rather than a new architecture. A retrieved chunk is the one thing in a transcript the model did not write, so Phase 3's citation discipline and this phase's `cited_tools_that_worked` are what make retrieval trustworthy rather than merely impressive. Retrieval pushes $\bar{p}$ up hard, halving your Tier H call budget again and making §6.9's arithmetic a daily tool rather than a lesson. And §8 has a retrieval-shaped twin waiting: **an empty retrieval is a statement about your index, and the moment a model turns it into a statement about the world, you have this phase's bug with better prose.**

---

## 17. [core] Further reading

* **Anthropic, "Building effective agents"** (19 Dec 2024) — the source of the five-pattern taxonomy, the workflow/agent distinction, and the sectioning/voting split. Read the appendix on tool design, and note the editorial banner. https://www.anthropic.com/engineering/building-effective-agents
* **Anthropic, prompt-caching documentation** — the mechanism (prefix resumption, breakpoints, minimum cacheable length, the look-back window). Method there; multipliers and TTLs in your `VERSIONS.md`. https://platform.claude.com/docs/en/build-with-claude/prompt-caching
* **Python standard library, `asyncio` — Coroutines and Tasks** — `gather`'s `return_exceptions`, `TaskGroup` (3.11+), `timeout` (3.11+), `Semaphore`. Read the `TaskGroup` section even though Atlas does not use it, and note *why* it cancels siblings. https://docs.python.org/3/library/asyncio-task.html
* **Huang et al., "Large Language Models Cannot Self-Correct Reasoning Yet"** (arXiv:2310.01798, 3 Oct 2023) — the evidence behind D-25 and behind the cascade's verifier warning. https://arxiv.org/abs/2310.01798
* **OWASP Top 10 for Agentic Applications** (2026 edition, published 9 Dec 2025) — ASI01–ASI03 are the entries the hard-code rule's corollary 2 speaks to. Read the PDF rather than a summary. https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/
* **Anthropic, "Code execution with MCP"** and **"Advanced tool use"** — both attacks on $\bar{p}$, with reported reductions pinned in `VERSIONS.md`. Read alongside Phase 4's decision to defer CodeAct to Appendix F. https://www.anthropic.com/engineering/code-execution-with-mcp

---

## 18. [core] Solutions

Emitted separately as **`phase_05_solutions.md`**: worked answers for the cumulative review, the six concept checks, the six quiz questions, both assignments (including a full `usable_payload` implementation and the cascade skeleton), and one defensible design for the invoice case study.

---

## 19. [core] Handoff

The updated `ATLAS_INTERFACES.md` (v0.12) and `VERSIONS.md` (Phase 5 delta plus the revision block) are inside `atlas_phase_05.zip`, alongside this document and the solutions file. Verified before packaging:

```
make test-offline     743 passed
make evals            30/30 gradeable on Tier F, 1 honest tier skip
make grade PHASE=05   both assignments report "not started"
make check-docs       green (24 marked blocks in this document)
make plan             231 Tier A calls for the default sweep
```
