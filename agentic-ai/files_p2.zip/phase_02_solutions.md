# phase_02_solutions.md

Worked answers for Phase 2. Read these *after* attempting the questions; the
cumulative review and the concept checks are worth more wrong than looked up.

---

## Cumulative review

**CR-1.** A bare `@property` is absent from `model_dump()`. Anything that walks the *serialised* trajectory therefore cannot see it: the Phase 3 eval harness (whose `field` paths index into `model_dump()` with dots), a JSON log, a trace viewer. Two Phase 1 eval checks name `trajectory.prompt_tokens`, so those checks would silently fail to find the field rather than failing loudly — the worst outcome. This is `ATLAS_INTERFACES.md` invariant 11, and Phase 2 had to apply the identical correction to `Usage.total_tokens` (IC-1), which is the argument for the invariant existing.

**CR-2.** `5·600 + 350·5·4/2 = 3000 + 3500 = 6500` tokens. The **quadratic** term (`g·n(n−1)/2`) is what kills you: the linear term grows with `n`, the quadratic with `n²`, so at n=20 the quadratic term is 66,500 of the 78,500 total. Below about five steps the fixed prompt dominates and the growth looks harmless, which is exactly why people extrapolate wrongly from short demos.

**CR-3.** Because treating a missing variable as `None` would silently discard the default and make runs non-reproducible for everyone who never set `ATLAS_SEED` — the majority. Absence means "I have no opinion", which should get the safe, reproducible default; only an explicit `none`/`null`/`off` means "I want unseeded sampling". The general rule: absence of configuration should select the safest behaviour, not the most permissive.

**CR-4.** The model owns only `"final"`. Since the other three (`step_cap`, `no_progress`, `bad_action`) belong to the harness, **non-termination is structurally impossible**: the loop is a bounded `for`, and no output the model can produce prevents it exiting. Termination is a property of the code, provable by reading it, and testable offline — not a hope about instruction-following (D-02).

**CR-5.** Any of the parse tests, e.g. `test_parse_ollama_computes_tokens_per_second_from_nanoseconds`. If parsing were inlined into `complete()`, exercising it would require an HTTP response, so the test would need a live runner or a mocked transport — slower, flakier, and testing the mock as much as the code. Because `parse_ollama_chat` is pure, the test is a dict in, an assertion out.

---

## Concept checks

**6.1.** The chat endpoint applies the model's chat template, producing role-delimited blocks and, crucially, a trailing **generation prompt** (`<|im_start|>assistant\n` or equivalent) that leaves the string in a state whose highest-probability continuation is a single assistant reply. The completion endpoint with templating disabled sends your text with no delimiters and no generation prompt, so the model sees an undifferentiated transcript and continues it the only way it knows — by writing more transcript, including further "User:" turns. To confirm in ten seconds: print the **resolved prompt string** actually sent to the model (run the server in debug mode and read the logged prompt, or `ollama show --template` to see what the chat path would apply). Comparing the two strings settles it immediately; comparing outputs does not.

**6.2.** *Classifier:* `temperature=0` (or the lowest available), no top-k/top-p, and `output_mode="schema"`. Its output is consumed by code, so you want the modal answer every time and you want reruns comparable for evals. *Summary:* a warmer setting is defensible — a human reads it, nothing parses it, and the model card's recommended configuration is a reasonable starting point. The observation that would make me revisit the classifier's setting: a measured `mode=schema` first-try validity or intent accuracy that is *worse* at `T=0` than at the model card's recommended temperature. That would mean greedy decoding is putting this model off-distribution, and the trade-off `VERSIONS.md` flags has gone the wrong way. `make results` is where you would see it.

**6.3.** Two explanations. **(a) Silent truncation at the hard wall.** Around step six the prompt exceeds `num_ctx`; the runner drops the oldest messages, taking the system prompt and the early observations with them, so the model no longer knows it has already called that tool. **(b) The soft slope.** No truncation occurs, but the step-3 observation is now in the middle of the window — the least-attended region per Liu et al. and context rot — so the model behaves as if it had not seen it. The field to inspect first is **`usage.prompt_tokens`** on each step's completion (or `Trajectory.prompt_tokens`). If it plateaus or falls while the message list keeps growing, the runner is truncating and you have (a); if it keeps climbing normally and stays under `num_ctx`, nothing was dropped and you have (b). The two need different fixes — a step cap or larger context versus shorter observations and task re-statement — which is why distinguishing them is worth one field lookup.

**6.5.** **(a)** First, **schema-invalid but syntactically valid JSON** — a well-formed object with a wrong type, a bogus enum value, or a missing key, which reaches your validator and raises `ValidationError`. Second, **HTTP 400** from the provider's own schema check (`Generated JSON does not match the expected schema`), which arrives as `LLMBadRequestError` and must *not* be retried, because it is structural. Strict mode with constrained decoding eliminates both by construction. **(b)** `Optional[str] = None` gives the field a Python default, so Pydantic omits it from the JSON Schema's `required` list — which strict mode rejects outright, and which in best-effort mode means a model may simply not emit the key. You then cannot distinguish **"the model considered the request answerable and deliberately chose `null`"** from **"the model forgot the field"**, because both arrive as `clarifying_question is None`. Those call for opposite responses — proceed versus repair — so collapsing them destroys the signal. Keep the field required and express optionality in the type. A related trap in the same family: setting `additionalProperties: false` in the schema constrains the *model*, but Pydantic's default is to **drop** unknown keys silently, so a best-effort backend can invent a field and your validator will discard it without complaint. `TaskUnderstanding` therefore sets `ConfigDict(extra="forbid")` as well — two switches, both needed, and the pleasant side effect is that Pydantic then emits `additionalProperties: false` into the generated schema itself.

**6.7.** **(a)** `tests/` (fixture). The fixture is the string `` ```json\n{"intent":"lookup",...}\n``` `` handed to `FakeLLMClient`; the assertion is that `extract_json_object` unwraps the fence and validation succeeds. A claim about my code. **(b)** `docs/RESULTS.md`. A frequency claim about a model at a temperature — it will change with the model tag and cannot be asserted stably. **(c)** `tests/` (fixture). `CallBudget(max_calls=100, ...)`, 100 scripted responses, assert the 101st raises. Pure arithmetic in my code. **(d)** `tests/` (fixture). The fixture is `{"text": "...", "finish_reason": "length"}`; assert `OutputTruncated` and that the client was called once. **(e)** `docs/RESULTS.md`. A measured rate. *Replay-based* would be the right home for a fourth kind of claim, e.g. "our parser still extracts the same fields from this real captured response" — anchored to reality, gating code changes rather than model changes.

**8.** A **false positive**: *"Show me the headcount by department and add a total row to the output table."* A model might reasonably set `has_write_intent=True` — "add" looks like a mutation — even though the "write" is to a rendered table, not to any system of record. With `intent='aggregate'` and no clarifying question, the validator fires, a repair is spent, and if the model holds its position the request is refused. **Cost:** one wasted repair (a full extra prompt) and, in the worst case, a user told Atlas cannot do something it easily can — friction and an erosion of trust. **Why it is cheaper than a false negative:** the false positive's failure mode is *visible and recoverable* — the user sees a refusal naming the clause and can rephrase — whereas the false negative's failure mode is *invisible and unrecoverable*: the user is told the write succeeded, believes the headcount was changed, and may not discover otherwise for weeks. This is the risk formula from Phase 1 (`risk ≈ probability wrong × cost of not undoing`) applied to a validator rather than an action: when one error direction is silent and the other is loud, bias the design toward loud.

---

## Quiz

**Q1.** `priority` was passed to the client library and then **silently dropped by the chat template**, which reads only `.Role` and `.Content` (or `.System`/`.Prompt`). The model never received it: the field had no slot in the envelope. It is not that the model ignored the instruction — the instruction was never in the string. The command that settles it: `ollama show --template $ATLAS_MODEL`, which prints the template and shows exactly which variables it references. (Running the server in debug mode and reading the logged resolved prompt is the even more direct version.) The fix is to put the information in the message *content*, where the template will render it.

**Q2.** Two mechanisms, neither a bug. **(a) Numerical non-determinism below the sampler:** floating-point addition is not associative, and the reduction order in an attention or matmul kernel can vary with batch size, with which other requests are in flight, or with the kernel the runtime selects for the current shape; a tie or near-tie in the top-2 logits then resolves differently. **(b) State outside the seed:** KV-cache reuse across requests, a model reload between calls, a changed runner build, or a context length that caused truncation in one call and not the other — all change the effective input or the computation without touching the sampler. What it implies: **`temperature=0` and a seed are best-effort reproducibility, not a guarantee**, so determinism requirements must live on *your* code, where you can actually meet them. That is `ATLAS_INTERFACES.md` invariant 1 — tests assert parsing, validation, control flow and budgets, never model output — and it is why `make results` reports *ranges*.

**Q3.** At `num_ctx=2048` the prompt overflows around step nine and the runner **truncates from the oldest end**, dropping the system prompt. The model no longer has the instructions defining the `ACTION:`/`FINAL:` grammar, the tool list, or its role, so it reverts to general chat behaviour — which is exactly what the symptom describes. "Strengthen the system prompt" is wrong because **the system prompt is not present**; a stronger one is dropped just as completely, and a *longer* one makes overflow happen sooner. The right responses are structural: derive `max_steps` from `num_ctx` (`max_steps_in_context(num_ctx, p0, g)`), add a `token_budget` exit, shorten observations to slow `g`, or raise `num_ctx`. Confirm the diagnosis by watching `usage.prompt_tokens` per step: a plateau while the message list grows is truncation. This is D-02 in miniature — a control-flow defect fixed in the harness, not the prompt.

**Q4.** In ascending severity. **(1) Timing.** A regex validates *after* generation, so a rejection costs the full prompt and completion and must be paid again; a constraint acts *during* generation, so bad output never occurs. Inefficiency. **(2) Expressiveness of shape.** A regex can find a JSON-ish blob but cannot enforce "exactly these keys, this enum, these types", so every constraint you care about stays uncaught. Incompleteness. **(3) Drift.** A regex is a second description of a shape whose first description is your Pydantic model; add a field, forget the pattern, and nothing notices the disagreement. Maintenance hazard — and the reason for invariant 13. **(4) JSON is not a regular language.** Matching balanced, arbitrarily nested brackets requires a stack, which regular expressions do not have. **This is the one that makes the regex silently wrong**: your pattern will match the flat case correctly all through development and then return a truncated or wrong substring the first time an entity list contains an object — no error, just the wrong data, reproducibly. Note that `extract_json_object` in this repo is a **bracket-matching scan**, not a regex, precisely because of (4), and it refuses to guess when there is no balanced object. It is also a cautionary tale: the first version searched only for `{`, so a top-level array `[{"a":1}]` was silently reduced to `{"a":1}` — its first element, valid JSON, wrong data, no error, and capable of *validating successfully* against a single-object schema with the rest of the list gone. Having a stack is necessary but not sufficient; you also have to look for the right opener. Five regression tests now pin the array cases.

**Q5.** **Diagnosis:** a repair loop is masking a bad schema or a poorly matched model. **The 98% success rate is the symptom** — specifically a *misleading* one, because it is the success rate of `structured()`, not of the model; it is high *because* nearly half of all calls are being repaired. **The 45% repair rate is the disease**, and the tripled token spend is its price: each repair pays the original prompt again plus the failed output plus the error list, so a 45% repair rate is roughly a 2–2.5× token multiplier before you count the larger repair prompts. **First change:** re-run `make results` with `max_repairs=0` to get the *unassisted* first-try validity. That number, not the 98%, tells you what you are dealing with. Then, in order: check whether you are actually getting constrained decoding (if the temperature row is not flat at `mode=schema`, you are not, and that alone could explain 45%); simplify or flatten the schema; check for truncation being misclassified as malformed output; and only then consider the model tag. D-05's revisit trigger is exactly this: a repair rate above 30% means the schema is too hard, not the cap too low — so the schema changes, not the number of retries.

**Q6.** **Strongest version of their argument:** recordings are real model output, so they cannot embed my mistaken assumptions about what a model emits; they exercise more code (the parser, which fixtures bypass); and maintaining two sets of test inputs is duplicated effort with a drift risk of its own. Every one of those points is true, and the unrealism weakness of fixtures is real. **Two things that break.** *Coverage:* many behaviours have no naturally-occurring recording, because you cannot make a real model produce them on demand — a response truncated at exactly the wrong byte, an `LLMTransportError` at the third attempt, a budget crossing on the 101st call, a stringified boolean, a schema-invalid enum. Those cases are *only* reachable by writing them, and they are precisely the error paths where bugs live. You would delete the tests for everything that goes wrong and keep the tests for everything that goes right. *What a test is for:* a test needs to run for a new contributor on a fresh clone with no network, no model and no credentials — which is invariant 2, and `make test-offline` satisfies it in 0.2 s. Recordings must be *obtained* before they exist, so a recordings-only suite cannot be run by someone who has not yet set up a model, and it silently becomes a suite that only its author can regenerate. The correct answer is both, with distinct roles: fixtures own the error paths and the control flow, recordings own realism and parser coverage, and neither is a model test. Worth adding: fixtures have a *second* weakness their advocate should concede, distinct from unrealism — they test a unit and are silent about how units are assembled. Every budget test in this repo passed while the one place the budget was actually wired up reset it on every call. Recordings do not fix that either; only an assertion about accumulation does (see Q7).

**Q7.** **Cause:** the budget object is being **constructed inside the loop it is supposed to measure**, so it is reset on every call. Each call sees a fresh `CallBudget` with `calls=0`, `check()` never finds the cap exceeded, and the `except BudgetExceeded` handler is dead code. This is exactly what happened in `scripts/phase02_results.py`: `get_client(settings)` sat inside the per-call helper, and a three-call simulation produced three distinct budget objects. **The assertion that would have caught it** must test *accumulation*, not the single-call property:

```python
budget = CallBudget(max_calls=3, max_tokens=10**6)
client = BudgetedClient(FakeLLMClient([ok] * 9), budget)
client.complete(ask)
client.complete(ask)
assert budget.calls == 2          # <- the missing assertion
```

The three original unit tests all constructed `BudgetedClient` directly and spent the cap in one place, so they could only ever prove "this object raises when its own counter passes the cap" — a true statement that says nothing about whether the object survives being handed round a run. **Two other vulnerable object types** in a typical agent: a **response cache** (rebuilt per call it is always empty, so the hit rate is silently zero and you pay for every request twice over), and a **conversation or trajectory accumulator** (rebuilt per step, so the agent loses its own history and every step looks like step one). Rate limiters, retry-attempt counters, sequence numbers and dedupe sets have the identical shape. The general rule is D-07: **stateful wrappers must outlive the calls they are meant to measure.**

---

## Assignment 1 — reference implementation

```python
"""atlas/degrade.py -- explicit, visible degradation down the output-mode ladder.

Section 6.5 concluded that a client must degrade deliberately and record what it
actually got. The pure helper (choose_output_mode) and the exception
(UnsupportedOutputMode) shipped with Phase 2; this is the wrapper.
"""

from __future__ import annotations

from typing import Any, Sequence

from atlas.llm import (
    MODE_LADDER,
    Completion,
    LLMBadRequestError,
    LLMClient,
    Message,
    OutputMode,
    UnsupportedOutputMode,
)

# The only two failures that mean "this rung is unavailable". A transport error
# means "try again", not "use a weaker guarantee": degrading on a 503 would
# silently weaken your contract because of a network blip.
REFUSALS = (UnsupportedOutputMode, LLMBadRequestError)


def mode_sequence(requested: OutputMode, floor: OutputMode = "text") -> list[OutputMode]:
    """The rungs to try, strongest first, from `requested` down to `floor`.

    Pure. Raises ValueError on an unknown mode rather than silently producing an
    empty sequence, because an empty sequence would make complete() return None.
    """
    try:
        top = MODE_LADDER.index(requested)
        bottom = MODE_LADDER.index(floor)
    except ValueError as exc:
        raise ValueError(
            f"unknown output mode; expected one of {MODE_LADDER}"
        ) from exc
    if bottom > top:          # a floor stronger than the request constrains nothing
        return [requested]
    return list(reversed(MODE_LADDER[bottom : top + 1]))


class DegradingClient:
    """An LLMClient that walks down the ladder when a backend refuses a rung.

    Records what it tried, in order, on `.attempted`: a degradation must be
    visible, because a best-effort result is different evidence from a
    constrained one and docs/RESULTS.md has to be able to tell.
    """

    def __init__(self, inner: LLMClient, floor: OutputMode = "text") -> None:
        self._inner = inner
        self.floor = floor
        self.attempted: list[OutputMode] = []

    @property
    def tier(self):  # type: ignore[override]
        return self._inner.tier

    @property
    def model(self) -> str:  # type: ignore[override]
        return self._inner.model

    def complete(
        self,
        messages: Sequence[Message],
        *,
        output_mode: OutputMode = "text",
        schema: dict[str, Any] | None = None,
        **kw: Any,
    ) -> Completion:
        self.attempted = []
        last: Exception | None = None
        for mode in mode_sequence(output_mode, self.floor):
            self.attempted.append(mode)
            try:
                completion = self._inner.complete(
                    messages,
                    output_mode=mode,
                    # The schema goes only with the rung that can enforce it.
                    # Sending it alongside format="json" would misrepresent the
                    # guarantee actually in force.
                    schema=schema if mode == "schema" else None,
                    **kw,
                )
            except REFUSALS as exc:
                last = exc
                continue
            completion.output_mode = mode      # report what worked, not what was asked
            return completion
        assert last is not None
        raise last
```

**Notes on the parts that are easy to get wrong.**

*Criterion 6 is the one an assistant will fail.* The natural implementation catches `Exception`, which degrades on a 503 and quietly abandons your schema guarantee because of a transient network fault. `REFUSALS` is a named tuple of exactly two classes, and the comment says why — the exception taxonomy in `atlas/llm.py` exists so this decision can be made precisely.

*Criterion 4* is one conditional, and it is a correctness issue rather than tidiness: a `Completion` whose `output_mode` says `json` while a schema was sent is a record that cannot be interpreted.

*Criterion 10* falls out for free because `structured()` counts repairs by attempt index in its own loop and knows nothing about modes. A degradation happens *inside* one `complete()` call, so `repairs` stays 0 — which is right: a degradation is a change of guarantee, a repair is a second try at the same guarantee. Conflating them would make the repair-rate metric meaningless.

*`mode_sequence` raising rather than returning `[]`* matters because an empty sequence would fall through the `for` to the `assert`, giving an `AssertionError` for what is really a typo in a caller's argument.

Run `PHASE=02 make grade` for the 14 hidden tests.

---

## Assignment 2 — reference implementation

```python
"""atlas/understand.py -- the section 8 fix, all three layers.

Layer 1: a schema that can represent a multi-clause request.
Layer 2: a validator that makes an incoherent representation invalid.
Layer 3: a dispatcher that fails closed rather than routing a write to a read
         path. Prompt wording is deliberately NOT one of the layers (D-02).
"""

from __future__ import annotations

from typing import Sequence

from pydantic import BaseModel, Field, model_validator

from atlas.llm import LLMClient, Message, structured
from atlas.schemas import Intent

SYSTEM = (
    "You analyse a request about company staffing and return one JSON object.\n"
    "First split the request into clauses: every distinct thing the user asked "
    "for, copied verbatim. Then classify.\n"
    "Set has_write_intent to true if ANY clause asks to change, add, remove, "
    "update or send something -- even when it is not the main point of the "
    "request. If has_write_intent is true and intent is not \"act\", you MUST "
    "supply a clarifying_question naming the clause that would change something."
)


class UnhandledWriteIntent(RuntimeError):
    """A request that would change something, on a path that cannot change things.

    Raised instead of routing. Until Phase 11's approval gate exists, refusing
    loudly is the correct behaviour: a refused write is recoverable by the user,
    a dropped write is not (docs/FAILURE_LOG.md F-02-01).
    """


class RequestUnderstanding(BaseModel):
    """TaskUnderstanding plus the two fields that make section 8's failure representable."""

    intent: Intent = Field(description="The dominant category for the request.")
    entities: list[str] = Field(description="Names, departments, metrics, copied verbatim.")
    needs_tools: bool = Field(description="True if answering requires a lookup.")
    clarifying_question: str | None = Field(
        description="A question to ask the user, or null if the request is answerable."
    )
    clauses: list[str] = Field(
        description="Every distinct request in the input, copied verbatim. Never empty."
    )
    has_write_intent: bool = Field(
        description=(
            "True if ANY clause asks to change, add, remove, update or send "
            "something. Independent of `intent`: a write can hide inside a "
            "request whose dominant intent is a comparison."
        )
    )

    @model_validator(mode="after")
    def _clauses_must_not_be_empty(self) -> "RequestUnderstanding":
        if not self.clauses:
            raise ValueError("clauses must list at least one clause")
        return self

    @model_validator(mode="after")
    def _write_intent_must_be_flagged(self) -> "RequestUnderstanding":
        # Section 8's object -- intent='compare', has_write_intent=True,
        # clarifying_question=None -- must not validate. Enforcing this in a
        # validator rather than in the prompt makes it testable offline against
        # a hand-written fixture, which is the whole argument of D-02.
        if self.has_write_intent and self.intent != "act" and self.clarifying_question is None:
            raise ValueError(
                "clarifying_question is required when has_write_intent is true "
                "and intent is not 'act': name the clause that would change something"
            )
        return self


def _write_clauses(obj: RequestUnderstanding) -> list[str]:
    """Best effort at naming the offending clauses, for the refusal message."""
    verbs = ("add", "remove", "delete", "update", "change", "set", "send", "create")
    hits = [c for c in obj.clauses if any(v in c.lower() for v in verbs)]
    return hits or obj.clauses


def understand_request(
    client: LLMClient, text: str, *, max_repairs: int = 1
) -> RequestUnderstanding:
    """Extract a validated understanding, and fail closed on any write intent."""
    messages: Sequence[Message] = [
        Message(role="system", content=SYSTEM),
        Message(role="user", content=text),
    ]
    result = structured(client, messages, RequestUnderstanding, max_repairs=max_repairs)
    obj = result.value
    if obj.has_write_intent or obj.intent == "act":
        raise UnhandledWriteIntent(
            "this request would change something and no approval gate exists yet; "
            f"unhandled clause(s): {_write_clauses(obj)}"
        )
    return obj
```

**Notes on the parts that are easy to get wrong.**

*Two separate validators, not one.* An empty `clauses` list and an unflagged write are different defects with different remedies, and a combined validator produces one error message covering both, which makes the repair prompt vaguer. Pydantic's error list is what the repair loop shows the model, so error granularity is a feature.

*Criterion 7 — the message names `clarifying_question`* — is not cosmetic. `structured()` puts `exc.json()` into the repair prompt, so a message that names the field and says what is required is the difference between a repair that fixes the problem and a repair that guesses.

*Criterion 9 checks `intent == "act"` as well as `has_write_intent`.* A model that correctly identifies a pure mutation sets `intent='act'` and may legitimately leave `has_write_intent` false or unset in spirit; failing closed on either is the conservative reading, and conservative is right when one error direction is silent (see concept check 8).

*The temptation to "handle" the write.* Both an assistant and your own instincts will suggest routing writes to a stub, logging them, or returning a partial answer with a note. All three reintroduce F-02-01 in a new place, because all three let the episode end with the user believing something happened. Refuse, name the clause, and let Phase 11 build the gate.

*What is deliberately absent:* any attempt to fix this by making `SYSTEM` more emphatic. The system prompt here exists to make the *correct* answer likely; the validator exists to make the *incorrect* answer impossible to accept. Only the second is testable offline, and only the second survives a model change.

Run `PHASE=02 make grade` for the 16 hidden tests.

---

## Case study

None in this phase; the phase block does not call for one.
