"""A.5.2 + A.5.3: audit the deployment files as text. No Docker required."""
from __future__ import annotations

import re
import sys
from pathlib import Path

DEPLOY = Path("deploy")
COMPOSE = (DEPLOY / "docker-compose.yml").read_text(encoding="utf-8")
DOCKERFILE = (DEPLOY / "Dockerfile").read_text(encoding="utf-8")

IMAGE = re.compile(r"^\s*image:\s*(\S+)", re.M)
FROM = re.compile(r"^FROM\s+(\S+)", re.M)


def classify(ref: str) -> str:
    if "@sha256:" in ref:
        return "digest"
    last = ref.rsplit("/", 1)[-1]
    tag = last.rsplit(":", 1)[-1] if ":" in last else None
    return "floating" if tag in (None, "latest") else "pinned tag"


def main() -> int:
    refs = IMAGE.findall(COMPOSE) + FROM.findall(DOCKERFILE)
    for ref in refs:
        print(f"  {ref:52} {classify(ref)}")

    checks: list[tuple[str, bool, str]] = [
        ("no image uses a floating tag",
         all(classify(r) != "floating" for r in refs),
         "pin a version tag, or better a digest"),
        ("the image declares a non-root USER",
         bool(re.search(r"^USER\s+(?!root\b)\S+", DOCKERFILE, re.M)),
         "add `RUN useradd ...` and `USER <name>` before CMD"),
        ("the atlas service has a read-only root filesystem",
         "read_only: true" in COMPOSE,
         "add `read_only: true` and a tmpfs for /tmp"),
        ("no service points a host variable at localhost",
         not re.search(r"ATLAS_\w*HOST:\s*\"?http://localhost", COMPOSE),
         "use the compose service name, e.g. http://ollama:11434"),
    ]
    failed = 0
    for name, ok, fix in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
        if not ok:
            print(f"      fix: {fix}")
            failed += 1
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
