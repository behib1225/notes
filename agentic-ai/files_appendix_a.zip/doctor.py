#!/usr/bin/env python3
"""A.8.3 — environment triage before Phase 1. Runs anywhere, changes nothing.

Every check prints PASS or FAIL and, on failure, the exact command that fixes
it. Exit code is the number of failures, so `python scripts/doctor.py && make
test-offline` does the sensible thing.
"""
from __future__ import annotations

import os
import platform
import sys
from pathlib import Path

SKIP_DIRS = {".git", ".venv", "node_modules", "__pycache__", "data", ".pytest_cache"}
TEXT_SUFFIXES = {".py", ".md", ".txt", ".toml", ".cfg", ".yml", ".yaml",
                 ".json", ".sh", ".example", ""}
FAILURES: list[str] = []


def check(name: str, ok: bool, detail: str = "", fix: str = "") -> None:
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  [{detail}]" if detail else ""))
    if not ok:
        FAILURES.append(name)
        if fix:
            print(f"      fix: {fix}")


def crlf_files(root: Path) -> list[Path]:
    """Every text-ish file under `root` containing a CRLF pair."""
    found: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        if SKIP_DIRS & set(path.parts):
            continue
        try:
            if b"\r\n" in path.read_bytes():
                found.append(path)
        except OSError:
            continue
    return found


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    release = platform.release()
    in_wsl = "microsoft" in release.lower()

    print(f"platform: {platform.system()} {release}")
    print(f"python:   {sys.executable}  {sys.version.split()[0]}")
    print(f"cwd:      {Path.cwd()}")
    print()

    check("python is 3.11 or newer", sys.version_info >= (3, 11),
          ".".join(map(str, sys.version_info[:3])),
          "install 3.11+ and recreate the virtual environment")

    if in_wsl:
        check("project is on the Linux filesystem, not /mnt",
              not str(root).startswith("/mnt/"), str(root),
              "move the project to ~/ and reopen your shell")
        check("python3 is a Linux executable, not a Windows one",
              not sys.executable.startswith("/mnt/"), sys.executable,
              "set [interop] appendWindowsPath=false in /etc/wsl.conf, then wsl --shutdown")
    else:
        print("note  not running under WSL; the /mnt and PATH checks do not apply")

    try:
        import atlas  # noqa: F401
        importable = True
    except ModuleNotFoundError:
        importable = False
    check("`import atlas` works", importable, "",
          "run through `make`, or `pip install -e .`, or export PYTHONPATH=.")

    offenders = crlf_files(root)
    check("no source file has CRLF line endings", not offenders,
          f"{len(offenders)} file(s)",
          "sed -i 's/\\r$//' <file>   (check first with: file <file>)")
    for path in offenders[:5]:
        print(f"      {path.relative_to(root)}")

    model = os.environ.get("ATLAS_MODEL")
    if model is None:
        print("note  ATLAS_MODEL is not set; Tier A will refuse to start (that is correct)")
    else:
        clean = all(ch.isprintable() and not ch.isspace() for ch in model)
        check("ATLAS_MODEL has no stray whitespace or control characters",
              clean, repr(model),
              "your .env has CRLF endings; convert it, then re-source the environment")

    print()
    print(f"{len(FAILURES)} failure(s)")
    return len(FAILURES)


if __name__ == "__main__":
    sys.exit(main())
