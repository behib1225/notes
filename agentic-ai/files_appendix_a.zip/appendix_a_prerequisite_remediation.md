# Appendix A — Prerequisite Remediation

**Study hours: read 4.0 / exercises 4.5 · Compute time: none · Tiers used: none (no model of any tier is called) · Cost: $0.00 · Repo snapshot: `atlas_phase_16.zip` (and `atlas_phase_04.zip` where noted)**

Nothing in this appendix needs a model, a network connection, a GPU, or Docker. Every example runs on the 16 GB baseline laptop with Python 3.11+, `pydantic`, and `pytest` installed. Section A.5 (Docker) is the one exception and says so where it applies.

Answers to every in-text **concept check** and **Your turn**, and full worked solutions to all twenty-four exercises, are in the companion document `appendix_a_solutions.md`. Do not read it until you have written an answer down.

---

## A.0 [core] How to use this appendix

These are **orientations, not tutorials**. Each section teaches the fraction of a large topic that this book's code actually uses, shows you that fraction inside a real Atlas file you can open, and then points you at the canonical documentation for everything else. Reading a whole section should take about forty minutes; doing its three exercises should take about thirty more.

You are here because you took the twelve-question prerequisite self-test in Phase 0 §7.1 and missed something. Phase 0 already scored you and told you the order to read in. This table is the map from a specific miss to a specific section, so you can read only what you owe.

| Phase 0 self-test question | Section that remediates it |
|---|---|
| 1. asyncio. What is the difference between calling `f()` and `await f()` when `f` is defined with `async def`? What does the first one return? | **A.1** |
| 2. asyncio. You have ten independent HTTP requests. Sketch, in two lines, how you would run them concurrently in one process without threads. Name the function you would use. | **A.1** |
| 3. Pydantic v2. Given `class Item(BaseModel): qty: int`, what happens at runtime for `Item(qty="3")`, and what happens for `Item(qty="three")`? | **A.2** |
| 4. Pydantic v2. What does `model_dump()` do that `dict(model)` does not, and how do you get a JSON Schema out of a model class? | **A.2** |
| 5. pytest. How does pytest decide which functions are tests? What is a fixture, and how does a test ask for one? | **A.3** |
| 6. pytest. Write the decorator line that runs one test three times with the inputs 1, 2 and 3. | **A.3** |
| 7. SQL. `orders` has 100 rows, `customers` has 40, and every order has a valid `customer_id`. How many rows does the `INNER JOIN` return, and how does that change with `LEFT JOIN` if eight customers have no orders? | **A.4** |
| 8. SQL. What does `GROUP BY` require of every column in the `SELECT` list, and what is `HAVING` for? | **A.4** |
| 9. Docker. In one sentence each: what is an image, what is a container, and what does a volume do? | **A.5** |
| 10. JSON Schema. Write the schema for an object with a required string `city` and an optional integer `days` that must be at least 1. | **A.6** |
| 11. HTTP/SSE. What HTTP status means "you are being rate limited", and which response header conventionally tells you how long to wait? How does a server-sent-events response differ from an ordinary one? | **A.7** |
| 12. Version control: what does restoring an earlier state do to your working tree, what happens to uncommitted changes, and how would you get back to where you were? | **No section.** See the note below. |

> **Note on question 12.** Phase 0's twelfth question is phrased in terms of a version-control tool, and its scoring guide sends a miss to an "A.9". There is no A.9. The companion code for this book is distributed as one ZIP snapshot per phase — `atlas_phase_00.zip` through `atlas_phase_16.zip` — and every instruction in this book that used to say "check out the tag" means "unzip the snapshot into a fresh directory and work there." You need no version-control knowledge to finish this book. You should still learn it before you work on a team, and the reason Phase 0 asks is that the habit of being able to return to a known-good state is the real skill; snapshots give you the same safety net with a `cp -r` instead of a command set.

Section A.8 is not keyed to any self-test question. It is a symptom → cause → fix table for Windows and WSL, and it exists because that is where self-learners most often stop.

### A.0.1 How each section is shaped, and how to work it

Every section runs (a) what it is, (b) the 20% you need, (c) a worked example from a real Atlas file, (d) three exercises, (e) canonical documentation. Three things are scattered through the prose and are the parts that actually do the teaching:

- **Concept check** — two per section, in the text, at the point where the idea has just been stated. Write an answer before you read on. Answers are in the solutions file.
- **Your turn** — one per section, a two-minute prediction you make *before* running anything. Predicting and being wrong is what makes the correct answer stick; reading the correct answer first does not.
- **Misconception** — the wrong model of the topic that professionals actually see in code review, named so you can check whether you hold it.

Working a section without doing these is reading, not studying, and reading a reference document is how people arrive at Phase 3 still unable to write a fixture.

### A.0.2 With an assistant

You are expected to be using an agentic coding assistant (named in `VERSIONS.md`). This appendix is the one place in the book where delegating defeats the purpose, so the rule is sharper than usual.

**Safe to delegate.** Mechanical expansion once you know the shape: turning six cases you wrote out into a `parametrize` table; converting a hand-written JSON Schema into the Pydantic model that generates it; adding type hints to a script you wrote; drafting the boring half of `doctor.py` after you have decided what it should check.

**Not safe to delegate.** Every concept check, every Your turn, and the *prediction* half of every exercise. The whole value of A.1.1 is the gap between the number you guessed and 0.20 s; an assistant closes that gap for you and you learn nothing. Also do not delegate reading your own `doctor.py` output, or the diagnosis step in A.8 — the skill being built is "which layer am I in", and an assistant cannot see your machine.

**One prompt that works**, after you have done the thinking:

> I have written six cases for `is_read_only_sql`: a plain SELECT, a lowercase select, a WITH query, a DELETE, two statements separated by a semicolon, and a PRAGMA. Turn them into a single `pytest.mark.parametrize` decorator with the argument names `sql, ok, fragment`, where `fragment` is a distinctive substring of the expected reason. Do not add cases I did not list, and do not change the expected values.

The two constraints at the end matter. Without them an assistant will helpfully invent cases whose expected values it guessed, and you will have a green test suite asserting something you never checked.

---

## A.1 [core] asyncio and structured concurrency

**Deliberately left out:** writing your own event loop or protocol, `loop.run_in_executor`, subprocess transports, async generators and `async for` beyond one mention, `contextvars`, async context-manager authoring, and the `async` database and HTTP client ecosystems. The Python documentation linked at the end of this section covers all of it. Atlas uses roughly eight names from `asyncio` and nothing else.

### (a) What it is

Your agent spends almost all of its wall-clock time waiting. A local model takes seconds to answer. An HTTP request takes hundreds of milliseconds. A disk read takes microseconds but is still a wait. During every one of those waits the CPU has nothing to do.

`asyncio` is a way of writing single-threaded code that, whenever it hits a wait, hands control back to a scheduler which finds some *other* piece of waiting work to advance. One thread, one CPU core, many outstanding waits. The analogy that actually holds: a short-order cook with four pans. The cook is not four times as fast, and cannot chop two onions at once. But while pan one simmers, the cook stirs pan two. The speedup comes entirely from overlapping the simmering, which is exactly what network latency is.

This buys you nothing for CPU-bound work. Two coroutines that each compute a hash for ten seconds take twenty seconds together, because there is one cook. If you remember one thing from this section, remember that `async` is for waiting, not for computing.

**Misconception: "`async` makes my code faster."** It makes *waiting* overlap. Phase 5 fans out four research workers with `asyncio` because those four workers are each blocked on a model that is thinking. If they were each blocked on a `for` loop, `asyncio` would make the program slower, by adding scheduling overhead to work that was never going to overlap.

### (b) The 20% you need for this book

A function declared `async def` is a **coroutine function**. Calling it does not run it; it returns a **coroutine object**, which is a description of work not yet started. You start it by awaiting it, or by handing it to the scheduler. This is the single most common beginner surprise, and it is Phase 0's question 1:

```python
async def fetch(n): ...
c = fetch(1)        # <coroutine object fetch at 0x...>; NOTHING has run
result = await c    # now it runs, and you get the value
```

Forgetting the `await` is not a crash. It is a function that silently does nothing and returns an object you then put in a list. Python emits a `RuntimeWarning: coroutine ... was never awaited` when the object is garbage collected, which may be long after the damage.

`await` may only appear inside an `async def`. To get from ordinary synchronous Python into async Python you call **`asyncio.run(coro)`** exactly once, at the top of your program. It creates an event loop, runs the coroutine to completion, and shuts the loop down.

`await` on its own is *sequential*. `await a(); await b()` waits for `a` to finish before starting `b`. To overlap, you need a function that hands several coroutines to the loop at once. The one Phase 0 question 2 is asking for is **`asyncio.gather`**:

```python
results = await asyncio.gather(*(fetch(i) for i in range(10)))
```

Measured in this appendix's workspace: five coroutines that each `await asyncio.sleep(0.2)` take **1.00 s** awaited one at a time and **0.20 s** under `gather`. Results come back in *argument order*, never completion order, which matters enormously when you are zipping them back against the inputs that produced them.

`gather` has one default that will burn you. If any coroutine raises, `gather` propagates that exception immediately to the caller — and the siblings keep running with nobody reading their results. Passing **`return_exceptions=True`** changes this: you get a list the same length as your inputs, where a failed slot holds the exception object instead of a value. Verified:

```
default gather:            raised ValueError bad
return_exceptions=True:    [1, 'ValueError', 3]
```

Three more names complete the set. **`asyncio.Semaphore(n)`**, used as `async with semaphore:`, caps how many coroutines are inside a region at once — this is how you avoid opening fifty concurrent requests against a model server that will start refusing them. **`asyncio.timeout(seconds)`**, an async context manager available since Python 3.11 (this book's floor), raises `TimeoutError` if the body has not finished in time. And **`asyncio.CancelledError`**, which is what the machinery raises *inside* a coroutine it wants to stop.

`CancelledError` deserves its own paragraph, because it is the one piece of asyncio etiquette that is counterintuitive and that Atlas comments on explicitly. It inherits from `BaseException`, not `Exception`, precisely so that a bare `except Exception:` does not catch it. If you do catch it, you must re-raise it. A coroutine that swallows cancellation cannot be cancelled, and since both `asyncio.timeout` and task cancellation are *implemented with* `CancelledError`, swallowing it breaks them. Verified in this workspace: a coroutine that catches `CancelledError` and returns a value defeats `asyncio.timeout` so completely that `TimeoutError` is never raised at all — the timeout silently does nothing and the caller gets a normal-looking result.

> **Concept check 1.1.** You write `results = [fetch(i) for i in range(5)]` with no `await` anywhere. What is in `results`, how long does the line take, and what will Python eventually print to stderr?

> **Concept check 1.2.** `gather_bounded` accepts both `timeout_s` (per branch) and `deadline_s` (the whole fan-out). Name one failure the per-branch timeout catches that the deadline does not, and one the deadline catches that the per-branch timeout does not.

One name you will meet but Atlas does not use: **`asyncio.TaskGroup`** (also 3.11+). A task group cancels every sibling as soon as one member raises. That is the right default for work that is worthless unless all of it succeeds, and the wrong default for a research fan-out, where three good documents plus one failure is a useful answer. You will meet the argument for that choice again in Phase 5.

### (c) Worked example — `atlas/flow/parallel.py`, in `atlas_phase_16.zip`

Phase 5 fans out several independent research jobs and reduces their results. The whole concurrency story lives in two functions. Here is the inner one, verbatim from `atlas/flow/parallel.py`:

```python
async def _run_one(
    branch: Branch,
    *,
    semaphore: asyncio.Semaphore,
    timeout_s: float | None,
) -> BranchResult:
    """Run one branch under the concurrency limit and its own timeout.

    Never raises for a branch's own failure: a timeout becomes `kind="timeout"`
    and an exception becomes `kind="error"` with the type name in `error`. A
    timeout that leaves no record is the same evidence problem as a mutated
    step record, so the record is produced here, next to the `except`.

    `asyncio.CancelledError` is re-raised, always. Swallowing it breaks
    `fail_fast` and the whole-workflow deadline, because a task that refuses
    to be cancelled cannot be cancelled.
    """
    started = time.perf_counter()
    async with semaphore:
        try:
            if timeout_s is None:
                payload = await branch.make()
            else:
                async with asyncio.timeout(timeout_s):
                    payload = await branch.make()
        except asyncio.CancelledError:
            raise
        except TimeoutError:
            return BranchResult(
                name=branch.name,
                kind="timeout",
                error=f"exceeded {timeout_s}s",
                latency_s=round(time.perf_counter() - started, 4),
            )
        except Exception as exc:  # noqa: BLE001 -- a branch failure is a value
            return BranchResult(
                name=branch.name,
                kind="error",
                error=f"{type(exc).__name__}: {exc}",
                latency_s=round(time.perf_counter() - started, 4),
            )
    return BranchResult(
        name=branch.name,
        kind="ok",
        payload=payload,
        latency_s=round(time.perf_counter() - started, 4),
    )
```

Read the `except` clauses in order, because the order is the lesson. `CancelledError` first and re-raised, for the reason the docstring gives. `TimeoutError` next, converted into a *value* — a `BranchResult` with `kind="timeout"` — rather than an exception. Then any other exception, also converted into a value, with the exception's type name preserved so that a reader of the trace can tell a `ValueError` from a `ConnectionError`. The `# noqa: BLE001` is there because a linter is right to be suspicious of `except Exception` and this is one of the few places it is correct.

Notice that `branch.make()` is called, not awaited-from-storage. `Branch.make` is a *factory* that returns a fresh awaitable each time, and the class docstring in the same file explains why: a coroutine object can only be awaited once, so storing one would make the branch un-retryable.

The outer function assembles these into tasks and gathers them. The part you need:

```python
    semaphore = asyncio.Semaphore(limit)
    started = time.perf_counter()
    tasks = [
        asyncio.ensure_future(_run_one(b, semaphore=semaphore, timeout_s=timeout_s))
        for b in branches
    ]

    async def _await_all() -> list[BranchResult]:
        if policy != "fail_fast":
            # return_exceptions=True is REQUIRED here, not stylistic: with the
            # default, the first raising branch propagates and its siblings are
            # left running with nobody reading their results. See §8.
            raw = await asyncio.gather(*tasks, return_exceptions=True)
```

One semaphore object shared by every branch — that is what makes it a global cap rather than a per-branch one. `asyncio.ensure_future` schedules each coroutine as a task immediately, so they are all in flight before the `gather`. And `return_exceptions=True`, with a comment saying it is required rather than stylistic, for exactly the behaviour measured above.

Here is `gather_bounded` running in this appendix's workspace against four hand-written branches — one fast, one that raises, one that hangs for ten seconds, one fast — with `limit=2` and `timeout_s=0.2`:

```
wall 0.21
  a  ok       a done
  b  error    ValueError: no such document
  c  timeout  exceeded 0.2s
  d  ok       d done
failures: ['b:error', 'c:timeout'] usable: 2
```

Four branches, three outcomes, nothing lost, nothing raised, and the results in argument order. The hung branch cost 0.2 seconds instead of ten. That is the entire value proposition of the three guards together.

> **Your turn.** Reading `_run_one` only, predict the `kind` field for each of these three branches: one that returns the empty string; one that raises `KeyError("sku")`; one that a sibling's failure cancels under `policy="fail_fast"`. Write the three words down before you look at the solution.

### (d) Exercises

**A.1.1 (easy).** In a scratch file, write `async def fetch(n)` that awaits `asyncio.sleep(0.2)` and returns `n * 2`. Outside any `async def`, call `fetch(1)` without awaiting it and print `type(...).__name__` and `repr(...)`. Then write an `async def main()` that times two things: five `fetch` calls awaited one at a time in a list comprehension, and the same five under `asyncio.gather`. Run it with `asyncio.run(main())` and report both timings. Predict the two numbers before you run it.

**A.1.2 (medium).** Unzip `atlas_phase_16.zip`, and from its root run a script that imports `Branch` and `gather_bounded` from `atlas.flow.parallel` and builds four branches that each sleep 0.1 s and return their name. Run `gather_bounded` three times with `limit=1`, `limit=2` and `limit=4`, printing `result.wall_clock_s` each time. Explain, in two sentences, why the three numbers differ and why the *order* of `result.branches` does not. You will need `PYTHONPATH=.` or an editable install for the import to work.

**A.1.3 (hard).** Write a coroutine `stubborn()` that does `await asyncio.sleep(5)` inside a `try`, catches `asyncio.CancelledError`, prints a message, and **returns a string instead of re-raising**. Call it inside `async with asyncio.timeout(0.2):`. Predict what happens, then run it. Now fix `stubborn` to re-raise, and run it again. Write one paragraph explaining what the first version did to the timeout, and connect it to the `except asyncio.CancelledError: raise` line in `_run_one`.

### (e) Canonical documentation

- Coroutines and Tasks — `https://docs.python.org/3/library/asyncio-task.html` (the whole of what you need: `run`, `gather`, `TaskGroup`, `timeout`, cancellation semantics)
- Synchronization primitives (`Semaphore`) — `https://docs.python.org/3/library/asyncio-sync.html`

---

## A.2 [core] Pydantic v2

**Deliberately left out:** custom validators (`@field_validator`, `@model_validator`), serializers, `TypeAdapter`, generics beyond one mention, discriminated unions, `RootModel`, settings management via `pydantic-settings`, and performance tuning. Atlas uses none of these in Phases 0–8 except a single generic model, and the Pydantic documentation linked below covers all of them properly.

### (a) What it is

A language model returns text. Your program needs an object. Pydantic is the layer in between: you declare the shape you want as an ordinary Python class with type annotations, and Pydantic gives you a constructor that parses, coerces and checks input against that shape, raising a structured error when it cannot.

The thing that makes it *the* library for agent work, rather than one of several data-validation options, is that the same class produces two artefacts from one definition. `model_json_schema()` gives you a JSON Schema you can send to the model to constrain what it generates; `model_validate()` gives you a checker for what actually came back. One declaration, one source of truth, no drift between what you asked for and what you accept. Atlas's `atlas/schemas.py` opens by saying exactly that: *"One class per shape. Each is used twice — once to constrain decoding, once to validate the answer — so the constraint and the validator cannot drift apart."*

### (b) The 20% you need for this book

A model is a class inheriting `BaseModel` with annotated attributes. Instantiate it with keyword arguments, or with `Model.model_validate(some_dict)`, or with `Model.model_validate_json(some_string)` — use the last one when the input is JSON text, because it parses and validates in one pass in Rust rather than calling `json.loads` first.

**Coercion is lax by default**, which is Phase 0's question 3. `Item(qty="3")` succeeds and gives you `qty == 3`, an `int`. `Item(qty="three")` raises `ValidationError`. Pydantic's guarantee is about the *output* types, not the input: after validation the field is an `int`, whatever plausible thing you handed it. Verified against Atlas's own schema in this workspace: `TaskUnderstanding(needs_tools="yes")` produces `needs_tools=True`, a real `bool`. If you want the strict behaviour, `model_config = ConfigDict(strict=True)` refuses all of it.

**`ValidationError` is data, not just a message.** `exc.errors()` returns a list of dicts, each with a `type` (`"literal_error"`, `"missing"`, `"extra_forbidden"`, `"int_parsing"`) and a `loc` tuple naming the offending field. That is what lets Atlas hand a model a *specific* complaint about a *specific* field instead of a traceback.

**`model_dump()` versus `dict(model)`** is question 4. `dict(model)` iterates the model's fields shallowly and gives you a dict whose values are still model objects where nested models are involved. `model_dump()` recurses, converting nested models to dicts all the way down, applies field aliases and exclusion rules, and — this is the part that bites people — includes `@computed_field` properties while excluding bare `@property` ones. Verified here:

```
BranchResult(...).model_dump() keys:
  ['completion_tokens', 'error', 'kind', 'latency_s', 'name',
   'ok', 'payload', 'prompt_tokens', 'total_tokens']
a plain @property named `total`:  in dump? False
```

`model_dump_json()` does the same and gives you a JSON string. This matters beyond tidiness: Atlas's `VERSIONS.md` records a real defect where `Trajectory`'s token totals were bare properties, so they were absent from `model_dump()`, so two eval checks that named them could never pass. The fix was `computed_field`.

**Three config switches are worth knowing.** `model_config = ConfigDict(extra="forbid")` makes Pydantic raise on unexpected keys instead of silently dropping them — and, as a side effect, emits `additionalProperties: false` into the generated schema. `ConfigDict(frozen=True)` makes instances immutable and hashable. `ConfigDict(strict=True)` turns off coercion.

**Two field-level tools.** `Field(description="...")` attaches prose that lands in the generated JSON Schema, which means it lands in the model's prompt — the cheapest instruction channel there is. `Field(default=None, repr=False)` keeps a value out of `repr()`, which is how Atlas keeps API keys out of logs.

**Misconception: "Pydantic validated it, so the data is correct."** It validated the *types and the shape*. `TaskUnderstanding(intent="lookup", entities=["Mars"], needs_tools=False, clarifying_question=None)` is a perfectly valid object describing a request about a region that does not exist. Every verifier Atlas builds from Phase 3 onward exists because validation stops at the shape, and the shape was never the hard part.

> **Concept check 2.1.** `x: str | None` with no default, versus `x: str | None = None`. Both accept null. Which one lets the model omit the key entirely, and which list in the generated JSON Schema changes between the two?

> **Concept check 2.2.** A model returns `{"intent":"lookup","entities":[],"needs_tools":true,"clarifying_question":null,"confidence":0.91}`. Describe what happens with `extra="forbid"` set and with it unset — and say which of the two failures you would rather be debugging at two in the morning.

**Optionality lives in the type, not the default.** `x: str | None` with no default is a *required* field that may be null. `x: str | None = None` is an *optional* field. Those are different things, and Atlas insists on the first, because a field with a default is omitted from the schema's `required` list, and then "the model chose null" and "the model forgot the field" become indistinguishable.

### (c) Worked example — `atlas/schemas.py`, in `atlas_phase_16.zip`

This is the first schema Atlas defines, from Phase 2. Every design rule above is visible in it:

```python
class TaskUnderstanding(BaseModel):
    """What Atlas believes the user is asking, before it does anything about it.
    ...
    """

    # The second of the two switches. See the module docstring.
    model_config = ConfigDict(extra="forbid")

    intent: Intent = Field(
        description="The single closest category for what the user wants."
    )
    entities: list[str] = Field(
        description=(
            "Names, departments, dates, metrics or identifiers the request "
            "mentions, copied verbatim from the request. Empty list if none."
        )
    )
    needs_tools: bool = Field(
        description=(
            "True if answering requires looking something up rather than "
            "reasoning from the request alone."
        )
    )
    clarifying_question: str | None = Field(
        description=(
            "One question to ask the user if the request cannot be answered as "
            "stated. Null when the request is answerable."
        )
    )
```

`Intent` is defined just above it as a `Literal` of six strings. Run `TaskUnderstanding.model_json_schema()` and you can watch the translation happen — output from this workspace, abridged:

```json
{
  "additionalProperties": false,
  "properties": {
    "intent": {
      "description": "The single closest category for what the user wants.",
      "enum": ["lookup", "compare", "aggregate", "explain", "act", "unclear"],
      "title": "Intent",
      "type": "string"
    },
    "entities": { "description": "Names, departments, ...",
                  "items": {"type": "string"}, "type": "array" },
    "needs_tools": { "description": "True if answering requires ...",
                     "type": "boolean" }
  }
}
```

A Python `Literal` became a JSON Schema `enum`, which a constrained decoder can actually enforce; a free `str` could not have been enforced at all. `ConfigDict(extra="forbid")` became `additionalProperties: false`. Every `description=` came through verbatim.

And the same class rejects three different defects with three different, nameable errors — verified here:

```
TaskUnderstanding(intent="lookup_thing", ...)   -> [('literal_error',   ('intent',))]
model_validate({..., "confidence": 0.9})        -> [('extra_forbidden', ('confidence',))]
TaskUnderstanding(needs_tools="yes", ...)       -> accepted, needs_tools is True
```

The third line is the one to sit with. `additionalProperties: false` in the schema constrains the *model*; `extra="forbid"` in the config constrains *Pydantic*. They are two separate switches for two separate audiences, and the module docstring in `atlas/schemas.py` says so in as many words. Turning on only the first means a best-effort backend can invent a field and your validator will discard it without telling you.

> **Your turn.** Predict the `type` string and the `loc` tuple that `exc.errors()` reports for `TaskUnderstanding(intent="lookup", entities=[1, 2], needs_tools=True, clarifying_question=None)`. There are two errors, not one. Write both down, then run it.

A second file worth opening is `atlas/config.py`, whose `Settings` class is the only place configuration enters an Atlas process. It shows `Literal` used as a type alias (`Tier = Literal["A", "H", "F", "B"]`), `Path` fields that coerce from strings automatically, and `h_api_key: str | None = Field(default=None, repr=False)` — the secret-hiding trick, with a test in `tests/test_config.py` that asserts `"supersecret" not in repr(Settings(h_api_key="supersecret"))`.

### (d) Exercises

**A.2.1 (easy).** From the `atlas_phase_16.zip` root, import `TaskUnderstanding` from `atlas.schemas`. Predict, then check, what each of these does: `needs_tools="yes"`, `needs_tools="maybe"`, `entities="support"` (a bare string, not a list), and `intent="LOOKUP"`. For each `ValidationError`, print `[(e["type"], e["loc"]) for e in exc.errors()]` and write down the error type in your lab notebook.

**A.2.2 (medium).** `atlas/schemas.py` also defines `RouteDraft`, with a `route: Route` field, a `confidence: float`, and a `why: str`. Print `RouteDraft.model_json_schema()` and identify the three things `ConfigDict(extra="forbid")` and the `Literal` contributed. Then define your own two-field copy of the class *without* `extra="forbid"`, validate a dict containing an extra `"handler": "shell"` key against both, and write two sentences on what the difference would mean for an agent whose model invented that key.

**A.2.3 (hard).** Import `BranchResult` from `atlas.flow.parallel` and confirm that `model_dump()` includes `ok` and `total_tokens` even though neither is a declared field. Now write a minimal model of your own with two int fields and a derived total, first as a bare `@property` and then as a `@computed_field` over a property, and show that only the second survives `model_dump()`. Then explain, in three sentences, why an eval check that reads `trial["total_tokens"]` out of a dumped record would silently fail against the first version — and why that is a worse failure than a crash.

### (e) Canonical documentation

- Models — `https://docs.pydantic.dev/latest/concepts/models/`
- Fields — `https://docs.pydantic.dev/latest/concepts/fields/`
- JSON Schema generation — `https://docs.pydantic.dev/latest/concepts/json_schema/`
- Configuration (`ConfigDict`) — `https://docs.pydantic.dev/latest/api/config/`

---

## A.3 [core] pytest: fixtures, parametrize, monkeypatch

**Deliberately left out:** writing plugins and hooks, `conftest.py` scoping subtleties beyond directory inheritance, marks other than `parametrize` and `skip`, fixture scopes other than the default, `xfail`, doctests, coverage integration, and `pytest-asyncio` (which this book does not need until Phase 8). The pytest documentation linked below covers all of it.

### (a) What it is

pytest runs functions whose names start with `test_`, in files whose names start with `test_`, and reports which ones raised. That is nearly the whole model. Its two genuinely clever features are that a plain `assert` statement produces a good failure message, and that a test declares what it needs by *naming it as a parameter*.

The second idea is the one that takes a moment. In most test frameworks you write setup code in a `setUp` method and hope the right things got set up. In pytest you write setup code once, as a function decorated `@pytest.fixture`, and any test that wants the result names it as an argument. pytest matches by name and calls the fixture for you. A test's signature therefore *is* its dependency list, which is a nice property when you come back to a suite of 1,600 tests after a month.

### (b) The 20% you need for this book

**Discovery**, which is Phase 0's question 5: by default pytest collects files matching `test_*.py` or `*_test.py`, functions in them named `test_*`, and methods named `test_*` inside classes named `Test*` that have no `__init__`. Run `pytest --collect-only -q` to see exactly what it decided, which is the fastest way to answer "why isn't my test running."

**Assertions.** Just write `assert`. pytest rewrites the bytecode to capture the operands, so a failure shows you both sides:

```
>       assert sum(u for _, u in rows) == 751
E       assert 750 == 751
```

**`pytest.raises`** asserts that something *does* fail, and gives you the exception to inspect:

```python
with pytest.raises(ConfigError) as exc:
    Settings.from_env({"ATLAS_TIER": "X"})
assert "ATLAS_TIER" in str(exc.value)
```

Asserting on the message, not just the type, is what keeps error messages useful — a test that only checks the type lets the message rot into "error".

**Fixtures** are functions decorated `@pytest.fixture` whose return value is injected into any test naming them. Put shared ones in `conftest.py`, which pytest imports automatically for every test in that directory and below; you never import it yourself. A fixture that `yield`s instead of returning runs the code after the `yield` as teardown.

Two built-in fixtures carry most of the load in this book. **`tmp_path`** gives each test a fresh empty `pathlib.Path` directory, so tests that touch the filesystem cannot see each other's mess. **`monkeypatch`** sets attributes, dict items, and environment variables, and undoes every change when the test ends. `monkeypatch.setenv("ATLAS_TIER", "F")`, `monkeypatch.setattr(obj, "name", value)`, `monkeypatch.delenv(...)`. The automatic undo is the whole point: a test that sets `os.environ` by hand leaks into every test that runs after it, and you will spend an afternoon on it.

**`@pytest.mark.parametrize`** runs one test body once per input tuple. Phase 0's question 6 wants this line:

```python
@pytest.mark.parametrize("n", [1, 2, 3])
def test_runs_three_times(n):
    ...
```

For several arguments, name them comma-separated in one string and pass a list of tuples. Each case becomes a separately named, separately reported test — `test_pairs[3-3]`, `test_pairs[ 4 -4]` — so a failure tells you *which* input broke without any printing on your part.

**Running it.** `pytest -q` for quiet output, `-x` to stop at the first failure, `-k expr` to select by substring of the test name, and a path or `path::test_name` to run one thing. In Atlas, `make test-offline` runs the whole suite with `ATLAS_TIER=F` and `--ignore=tests/hidden`.

**One exit code worth knowing:** pytest exits **5** when it collected nothing at all. Atlas's `Makefile` special-cases it, because "you have not written the assignment module yet" and "your code is broken" are different situations and should not look alike.

> **Concept check 3.1.** `tests/test_config.py` uses the `load_fixture` and `dict_cache` helpers from `tests/conftest.py` without importing them, and without `conftest` appearing anywhere in the file. By what mechanism do they arrive, and what would break if you renamed `conftest.py` to `fixtures.py`?

> **Concept check 3.2.** Atlas's `Makefile` special-cases pytest exit code **5**. What state does 5 describe, and why would reporting it as a failure send a student hunting for a bug that does not exist?

**Misconception: "a passing test means the model behaved."** In this book it never does. Every test in `tests/` asserts on parsing, schema, control flow, budgets and arithmetic, against hand-written scripted responses in `tests/fixtures/`. Note the unfortunate collision of vocabulary, which `tests/conftest.py` flags in its own docstring: a *pytest fixture* is test plumbing, a *scripted fixture* is a canned model reply stored as JSON. When this book says "fixture" unqualified it means the second.

### (c) Worked example — `tests/conftest.py` and `tests/test_config.py`, in `atlas_phase_16.zip`

Atlas's `tests/conftest.py` opens by teaching the concept to the same reader this appendix is for:

```python
"""Shared pytest fixtures. Everything here is offline, deterministic, and free.

A *pytest fixture* is a function decorated with `@pytest.fixture` whose return
value is injected into any test that names it as a parameter. It exists so that
setup is written once and so that a test's signature declares its dependencies.
Two of pytest's own fixtures are used below: `tmp_path`, a fresh empty directory
per test, and `monkeypatch`, which undoes its own changes at teardown.
"""
```

The simplest fixture in the file returns a constant; the interesting one returns a *function*, which is a pattern worth stealing:

```python
@pytest.fixture
def load_fixture():
    """Read a scripted payload from tests/fixtures/ by filename."""

    def _load(name: str) -> dict[str, Any]:
        return json.loads((FIXTURE_DIR / name).read_text())

    return _load
```

A test that names `load_fixture` gets a loader it can call several times with different filenames — a fixture that returns data can only give you one thing.

Now `tests/test_config.py`, which is Atlas's first test file and is entirely readable after the paragraphs above:

```python
def test_unknown_tier_is_rejected_with_a_helpful_message():
    with pytest.raises(ConfigError) as exc:
        Settings.from_env({"ATLAS_TIER": "X"})
    assert "ATLAS_TIER" in str(exc.value)


def test_tier_h_names_every_missing_variable():
    with pytest.raises(ConfigError) as exc:
        Settings.from_env({"ATLAS_TIER": "H", "ATLAS_H_MODEL": "m"})
    assert "ATLAS_H_API_KEY" in str(exc.value)
    assert "ATLAS_H_BASE_URL" in str(exc.value)


def test_api_key_is_not_in_repr():
    assert "supersecret" not in repr(Settings(h_api_key="supersecret"))
```

Note that `Settings.from_env` takes a mapping, so these tests never touch the real environment and need no `monkeypatch`. Designing for testability like that is cheaper than mocking around an untestable design — a theme that recurs for the whole book.

For `parametrize`, open `tests/test_llm_client.py`:

```python
@pytest.mark.parametrize("status", [408, 429, 500, 502, 503, 504])
def test_retryable_statuses(status):
    assert is_retryable_status(status) is True


@pytest.mark.parametrize("status", [200, 400, 401, 403, 404, 422])
def test_non_retryable_statuses(status):
    assert is_retryable_status(status) is False


@pytest.mark.parametrize(
    "headers,expected",
    [
        ({"retry-after": "2"}, 2.0),
        ({"Retry-After": "0.5"}, 0.5),
        ({"retry-after-ms": "1500"}, 1.5),
        ({"retry-after": "not-a-number"}, None),
        ({"retry-after": "-3"}, None),
        ({}, None),
        (None, None),
    ],
)
def test_retry_after_seconds(headers, expected):
    assert retry_after_seconds(headers) == expected
```

Twelve status codes and seven header shapes, nineteen reported test cases, three test bodies. Writing that as nineteen functions would be nineteen places to update when the rule changes; writing it as one loop inside one function would report one failure instead of naming the input that caused it.

Running the three files this appendix leaned on, offline, in this workspace: **72 passed in 0.29 s**, with no network, no model and no `.env`.

> **Your turn.** Write, from memory, the single decorator line that runs one test body three times over the pairs `(1, 2)`, `(2, 4)` and `(3, 6)`, with the two arguments named `n` and `expected`. Then check the spacing and quoting against the `retry_after_seconds` example above — the argument-name string is the part people get wrong.

### (d) Exercises

**A.3.1 (easy).** From the `atlas_phase_16.zip` root, run `python -m pytest tests/test_config.py --collect-only -q` and count the tests. Then run `python -m pytest tests/test_llm_client.py -q -k retry --collect-only` and explain why the count is larger than the number of `def test_` lines matching "retry" in the file. Finally, run one single test by its full node id.

**A.3.2 (medium).** Write a new file `tests/test_appendix_a.py` containing one parametrized test over `atlas.tools.sql.is_read_only_sql`, with at least six cases covering: a plain `SELECT`, a lowercase `select`, a `WITH` query, a `DELETE`, two statements separated by `;`, and a `PRAGMA`. Assert on the boolean *and* on a distinctive substring of the reason string. Run it with `ATLAS_TIER=F python -m pytest tests/test_appendix_a.py -q`.

**A.3.3 (hard).** Add to the same file a fixture that uses `tmp_path` to write a two-line `.env`-style mapping, and a test that uses `monkeypatch.setenv` to set `ATLAS_TIER`, `ATLAS_MODEL` and `ATLAS_DATA_DIR` (pointing at `tmp_path`), then asserts that `Settings.from_env()` — called with *no* argument, so it reads the real environment — picks all three up and that `settings.data_dir` is the temporary directory. Add a second test, defined *after* it, asserting that `ATLAS_MODEL` is no longer in `os.environ`. Explain in two sentences what that second test is actually testing, and why it would pass vacuously if you had used `os.environ[...] = ...` in a fixture with no teardown.

### (e) Canonical documentation

- How to parametrize — `https://docs.pytest.org/en/stable/how-to/parametrize.html`
- How to monkeypatch/mock — `https://docs.pytest.org/en/stable/how-to/monkeypatch.html`
- How to use fixtures — `https://docs.pytest.org/en/stable/how-to/fixtures.html`
- Temporary directories (`tmp_path`) — `https://docs.pytest.org/en/stable/how-to/tmp_path.html`
- Fixtures reference — `https://docs.pytest.org/en/stable/reference/fixtures.html`
- Built-in fixtures (`tmp_path`, `monkeypatch`, …) — `https://docs.pytest.org/en/stable/builtin.html`

---

## A.4 [core] SQL joins and read-only access patterns

**Deliberately left out:** window functions, CTEs beyond the one-line syntax, indexing and query planning, transactions and isolation levels, `UPSERT`, full-text search, and every difference between SQLite and PostgreSQL. SQLite is this book's default; Postgres is optional reading. The SQLite documentation linked below is unusually good and covers the rest.

### (a) What it is

A join reads two tables in one query and pairs up rows whose values match. That is the entire idea. Everything else is a question about what happens to a row that finds no partner.

Atlas needs SQL for one reason: a company's structured facts — shipments, warranty claims, headcounts — live in a database, and an agent that can only read prose documents cannot answer "how many units shipped to the north region." From Phase 3 onward Atlas has a `query_db` tool. The interesting engineering is not the SQL; it is making absolutely certain the agent cannot write.

### (b) The 20% you need for this book

**`SELECT … FROM … WHERE …`** you already know. Four things beyond it matter here.

**Join arithmetic**, Phase 0's question 7. An `INNER JOIN` emits one row per matching pair and drops anything unmatched on either side. With 100 orders, 40 customers, and every order carrying a valid `customer_id`, the join returns **100** rows — one per order, with the customer's columns repeated as needed. A `LEFT JOIN` keeps every row of the left table regardless; eight customers with no orders add eight rows whose order columns are all `NULL`, giving **108**. Two consequences worth internalising: a join is not "40 plus 100", it is "however many pairs match", and `LEFT JOIN` never returns *fewer* rows than the `INNER JOIN` of the same tables.

SQLite has supported `RIGHT` and `FULL OUTER JOIN` since version 3.39.0, released 25 June 2022. Before that you wrote a `RIGHT JOIN` as a `LEFT JOIN` with the tables swapped. You will not need either in this book.

**The `ON` versus `WHERE` trap.** In a `LEFT JOIN`, a condition on the right-hand table belongs in the `ON` clause. Move it to `WHERE` and you have silently converted your `LEFT JOIN` back into an `INNER JOIN`, because the unmatched rows have `NULL` in that column and `NULL = '2025Q4'` is not true. This is the single most common SQL bug in reporting code, and part (c) demonstrates it on real Atlas data.

**`GROUP BY` and `HAVING`**, Phase 0's question 8. `GROUP BY` collapses rows into one row per distinct value of the grouping expression. Every column in your `SELECT` list must then be either one of the grouping columns or wrapped in an aggregate (`count`, `sum`, `avg`, `min`, `max`); anything else has no single well-defined value for the group. SQLite is unusually permissive here and will pick an arbitrary row rather than erroring, which makes the mistake *harder* to find, not easier. `WHERE` filters rows before grouping; `HAVING` filters groups after, so `HAVING sum(units) > 1000` is legal and `WHERE sum(units) > 1000` is not.

**Misconception: "`LEFT JOIN` means I keep every row of the left table."** You keep every row *until a `WHERE` clause touches a right-hand column*. At that moment the unmatched rows, whose right-hand columns are all `NULL`, fail the comparison and vanish, and you have written an `INNER JOIN` with extra words. Part (c) shows this happening on real data.

> **Concept check 4.1.** `SELECT region, quarter, sum(units) FROM v_shipments GROUP BY region` names `quarter` in the select list but not in the `GROUP BY`. Does SQLite accept it? If so, what value does `quarter` hold, and why is being accepted worse for you than being rejected?

> **Concept check 4.2.** Atlas refuses writes twice: a regular-expression guard in Python, and `mode=ro&immutable=1` on the connection. If the guard had a hole in it tomorrow, which of the two still protects the database? Which of the two gives a model an error it can act on?

**Aggregates over an empty set.** `count(*)` over zero rows returns one row containing `0`. `sum(x)` over zero rows returns one row containing **`NULL`**, not `0`. Verified here against Atlas's own database: `select sum(units) from v_shipments where region='Mars'` → `[(None,)]`, while `count(*)` on the same filter → `[(0,)]`. That asymmetry is the difference between an agent reporting "zero units" and an agent reporting "no data," and Phase 7 builds a sanity check that turns on exactly it.

**Read-only access** is a design pattern, not a syntax feature, and it has two layers. The first is a guard in your code that refuses anything that is not a single `SELECT` or `WITH`. The second is opening the database so that the engine itself refuses writes. SQLite does this with a URI filename: `sqlite3.connect("file:path.db?mode=ro&immutable=1", uri=True)`. `mode=ro` is read-only; `immutable=1` additionally promises the file will not change, so SQLite takes no lock at all and your agent's query cannot block anyone else's writes. Python's `sqlite3` driver also refuses to run two statements in one `execute()`, which is a third, free layer.

One more SQLite-specific tool this book leans on: a **view** is a stored query you can `SELECT` from as though it were a table. Exposing views rather than base tables is how Atlas controls what the agent can even see.

### (c) Worked example — `atlas/tools/sql.py` and `data/atlas.db`, in `atlas_phase_16.zip`

The seeded database ships in the snapshot. Its schema, as read from the file:

```sql
CREATE TABLE product (sku TEXT PRIMARY KEY, descr TEXT NOT NULL,
                      list_price INTEGER NOT NULL);
CREATE TABLE warranty_claim (id INTEGER PRIMARY KEY,
                      sku TEXT NOT NULL REFERENCES product(sku),
                      failure_mode TEXT NOT NULL, quarter TEXT NOT NULL,
                      resolved INTEGER NOT NULL);

CREATE VIEW v_shipments AS
  SELECT s.quarter AS quarter, s.region AS region, s.sku AS sku,
         p.descr AS product, s.units AS units,
         s.units * p.list_price AS revenue
  FROM shipment s JOIN product p ON p.sku = s.sku;
```

`v_shipments` is itself a join, which is a good first thing to notice: the agent never writes that join, because it is already baked into the view it is allowed to query.

Now the `LEFT JOIN` lesson, run against this database. Four products; 43 warranty claims across four quarters. Ask for claims per product in 2025Q4:

```sql
SELECT p.sku, count(w.id) AS claims
FROM product p
LEFT JOIN warranty_claim w ON w.sku = p.sku AND w.quarter = '2025Q4'
GROUP BY p.sku ORDER BY p.sku;
```
```
[('P900', 6), ('S200', 2), ('S400', 0), ('T100', 4)]
```

Change `LEFT JOIN` to `JOIN`, and S400 disappears:

```
[('P900', 6), ('S200', 2), ('T100', 4)]
```

Now keep the `LEFT JOIN` but move the quarter predicate into a `WHERE` clause — the trap — and S400 disappears again:

```
[('P900', 6), ('S200', 2), ('T100', 4)]
```

Three queries; one of them answers the question a product manager asked, and the other two quietly answer a different one. Note also `count(w.id)` rather than `count(*)`: `count(*)` counts the joined rows, and S400's single all-`NULL` row would have counted as 1.

> **Your turn.** `product` has 4 rows and `shipment` has 64, and every shipment names a real SKU. Predict the row count of `SELECT * FROM product p JOIN shipment s ON s.sku = p.sku` before you run it. If you reached for 4 × 64 or 4 + 64, re-read the join-arithmetic paragraph — the answer is neither.

The read-only design is in `atlas/tools/sql.py`, whose module docstring states the architecture before any code runs:

```python
"""Read-only SQL against curated views. Two layers, and the outer one is not mine.
...
**Layer 1, mine: a statement guard.** `is_read_only_sql` rejects anything that
is not a single `SELECT` or `WITH`. It is pure, it is tested, and I do not
trust it. SQL is a large language, my whitelist is small, and a validator whose
completeness is the only thing between a model and a `DELETE` is a validator
that will eventually be wrong.

**Layer 2, not mine: an immutable connection.** The database is opened with the
URI `file:...?mode=ro&immutable=1`, so SQLite itself refuses writes. When that
refuses a statement, the guarantee comes from someone else's C code that has
been read by more people than my whitelist ever will be.
"""
```

Both layers, exercised here:

```
SELECT 1                                  -> (True, 'ok')
select * from v_shipments                 -> (True, 'ok')
WITH t AS (SELECT 1) SELECT * FROM t      -> (True, 'ok')
DELETE FROM shipment                      -> (False, "only SELECT and WITH queries are allowed; this one starts with 'DELETE'. ...")
SELECT 1; DELETE FROM shipment            -> (False, "only one statement is allowed; ...")
SELECT 1; /* x */ DELETE FROM shipment    -> (False, "only one statement is allowed; ...")
PRAGMA table_info(product)                -> (False, "... this one starts with 'PRAGMA'. ...")
```

and layer 2, on a connection opened the way `make_sql_tool` opens it:

```
>>> conn.execute("CREATE TABLE x (a)")
sqlite3.OperationalError: attempt to write a readonly database
```

The comment-stripping case is the one to dwell on. `strip_sql_comments` runs *before* the guard, because `SELECT 1; /* */ DELETE FROM shipment` hides a write behind a comment, and a guard that scans the raw string can be walked past. The guard sees the statements the database will see.

Two things neither layer stops, which the docstring is honest about: a `SELECT` that reads a column it should not, and a `SELECT` heavy enough to be a denial of service. The first is handled by exposing only curated views — the query database `data/atlas_query.db` literally contains nothing but `v_departments`, `v_shipments` and `v_warranty`, so a base table the model does not know about cannot be queried. The second is handled by a row cap and a busy timeout.

### (d) Exercises

**A.4.1 (easy).** Open `data/atlas.db` from the snapshot read-only with `sqlite3.connect("file:data/atlas.db?mode=ro", uri=True)`. Report `count(*)` for `product` and `warranty_claim`. Then report the row count of `product JOIN warranty_claim ON w.sku = p.sku AND w.quarter = '2025Q4'` and of the same query with `LEFT JOIN`. Predict both numbers from the per-product claim counts before you run them, and say in one sentence which product accounts for the difference.

**A.4.2 (medium).** Against `v_shipments`, write one query returning total units per region, ordered by units descending. Then add a `HAVING` clause that keeps only regions above 1,000 units and explain the result you get. Finally, run `SELECT sum(units) FROM v_shipments WHERE region = 'Mars'` and `SELECT count(*) FROM v_shipments WHERE region = 'Mars'`, and write two sentences on why an agent that renders the first result naively would tell a user something false.

**A.4.3 (hard).** Reproduce all three claims-per-product queries from part (c) — `LEFT JOIN` with the quarter in `ON`, `INNER JOIN`, and `LEFT JOIN` with the quarter in `WHERE` — and confirm the outputs. Then build the tool: call `make_sql_tool("data/atlas_query.db")` from `atlas.tools.sql` and pass it your correct query as `tool(sql=...)`. Try to pass it `UPDATE v_shipments SET units = 0` and record the exact error. Then open the same file with `mode=ro&immutable=1` and attempt a `CREATE TABLE` directly, bypassing the guard entirely, and record that error too. Write a paragraph explaining which of the two errors you would rather rely on if you had to pick one, and why `atlas/tools/sql.py` keeps both.

### (e) Canonical documentation

- `SELECT`, including the join clause and `GROUP BY`/`HAVING` — `https://sqlite.org/lang_select.html`
- Aggregate functions (including `sum` over an empty set) — `https://sqlite.org/lang_aggfunc.html`
- URI filenames (`mode=ro`, `immutable=1`) — `https://sqlite.org/uri.html`
- Python's `sqlite3` module — `https://docs.python.org/3/library/sqlite3.html`

---

## A.5 [core] Docker and Compose

**Deliberately left out:** multi-stage build optimisation beyond one sentence, BuildKit cache mounts, registries and pushing, networks beyond the default one Compose creates, `docker exec`/`logs`/`inspect` as a debugging discipline, orchestration of any kind, and rootless mode. Docker's documentation, linked at the end, covers all of it. This book runs a container in exactly one place, and you need about eight concepts to read that file.

**One honesty note before anything else.** Docker was absent from the machine this appendix was authored on — `docker version` returns *command not found*, the same condition `atlas/tools/sandbox.py` and `deploy/Dockerfile` record for themselves. Every claim below about what Docker *does* is read from the primary documentation or from the Atlas files; every claim about what Atlas's own files *contain* was verified by reading and parsing them. Anything I could not run is marked.

### (a) What it is

An **image** is a filesystem plus a default command, built once and byte-identical wherever it lands. A **container** is one running process tree started from an image, with its own filesystem view, process table and network stack. A **volume** is a piece of storage that lives outside any container, so that data survives the container being deleted and recreated — which happens on every deploy.

That is Phase 0's question 9, and the one-sentence versions are worth memorising because the distinction between the first two is where almost all confusion starts. An image is a noun you build and ship; a container is a verb you run and throw away. If you find yourself wanting to "save your work in the container," you want a volume.

Why an agent project cares: your agent runs untrusted-ish code and talks to services. By Phase 14, Atlas's `run_python` tool executes model-written code inside a container rather than a bare subprocess, because a subprocess with resource limits is *not* isolation — Phase 3 measured that a scrubbed subprocess could still read `/etc/hostname` and open a socket to the internet. By Phase 15, Atlas runs as a service alongside a model server and a tracing backend, and Compose is how three processes become one command.

### (b) The 20% you need for this book

A **Dockerfile** is a recipe read top to bottom. Each instruction produces a layer, layers are cached by content, and a layer is rebuilt only if it or something above it changed. That single fact dictates the ordering rule: **put the things that change rarely above the things that change constantly.** Dependencies before source code, always.

The instructions you will meet: `FROM` (the base image), `WORKDIR` (the directory subsequent commands run in), `COPY src dest` (host file into image), `RUN cmd` (execute at *build* time, baking the result into a layer), `ENV`, `EXPOSE` (documentation, not a firewall rule), `USER` (who the process runs as), `HEALTHCHECK`, and `CMD` (what runs at *container start* time). `RUN` versus `CMD` is the other classic confusion: `RUN pip install` happens once when the image is built; `CMD ["uvicorn", ...]` happens every time a container starts.

**Tags are moving pointers.** `python:3.12-slim` means "whatever the maintainers last published under that name." A digest — `python@sha256:...` — is immutable. Pinning a tag gives you reproducibility for a few months; pinning a digest gives it to you permanently, at the cost of never getting a security patch without an edit. Atlas pins tags and says in a comment that production should pin digests.

**Compose** describes several containers in one YAML file, conventionally `compose.yaml` or `docker-compose.yml`, and starts them with `docker compose up`. The keys you need: `services` (one entry per container), `image` or `build`, `ports` (`"host:container"`), `environment`, `volumes`, `depends_on`, and a top-level `volumes` block declaring named volumes. If you have seen older files that begin with a `version:` key, check the Compose-format row in the VERSIONS.md delta at the end of this appendix before copying that habit forward; the format's current state is a volatile fact and does not belong in prose.

**The networking rule that saves the most time:** inside a Compose network, a service reaches another service by its *service name*, not by `localhost`. `localhost` inside a container means that container. A containerised app configured to call `http://localhost:11434` cannot see a model server running in a sibling container, even though both are plainly running. This is the single most common "but it works outside Docker" report.

> **Concept check 5.1.** `RUN pip install ...` and `CMD ["uvicorn", ...]` look similar and run at completely different times. Which runs when the image is *built* and which when a container *starts*? What happens if you write `RUN uvicorn ...` instead?

> **Concept check 5.2.** You edit one line of `requirements.txt`. Which instructions in `deploy/Dockerfile` come from cache and which re-run? Now answer the same question for editing one line of `atlas/schemas.py`.

**Misconception: "a volume mount and a `COPY` do the same thing."** `COPY` bakes a snapshot into the image at build time; the container cannot change what the host sees. A volume is live shared storage; writes inside the container land outside it. If your agent writes files you want to keep, you need the second.

### (c) Worked example — `deploy/Dockerfile` and `deploy/docker-compose.yml`, in `atlas_phase_16.zip`

These are the only Docker files in the repository, and they arrive at Phase 15, so they are later than this appendix would ideally use. There is no earlier Docker example in Atlas to fall back on. The good news is that they are short and every line carries a comment explaining itself.

```dockerfile
FROM python:3.12-slim AS base

# Never root. A container that runs as root and mounts a volume writes
# root-owned files onto the host, and an RCE in the app is an RCE as root.
RUN useradd --create-home --uid 10001 atlas
WORKDIR /app

# Dependencies in their own layer, BEFORE the source. Source changes on every
# commit and dependencies change monthly; putting them in one layer rebuilds
# the whole install for a one-character fix.
COPY requirements.txt /app/requirements.txt
RUN pip install --no-cache-dir -r /app/requirements.txt \
 && pip install --no-cache-dir "uvicorn[standard]==0.42.0"

COPY atlas /app/atlas
COPY data /app/data

USER atlas
ENV PYTHONUNBUFFERED=1 PYTHONDONTWRITEBYTECODE=1 PYTHONPATH=/app
EXPOSE 8000
```

Read it as three decisions. First, `useradd` then `USER atlas`, with the comment giving both reasons — root-owned files leaking onto the host through a volume, and privilege escalation if the app is compromised. Second, `COPY requirements.txt` on its own line above `COPY atlas`, which is the caching rule made concrete: editing one character of `atlas/llm.py` rebuilds two cheap layers instead of reinstalling every dependency. Third, `USER` appears *after* the `RUN pip install`, because installing packages needs root and running the app does not.

The `HEALTHCHECK` and `CMD` carry the two operational decisions:

```dockerfile
HEALTHCHECK --interval=30s --timeout=3s --start-period=20s --retries=3 \
  CMD python -c "import urllib.request,sys; sys.exit(0 if urllib.request.urlopen('http://localhost:8000/healthz',timeout=2).status==200 else 1)"

CMD ["uvicorn", "atlas.api.main:app", "--host", "0.0.0.0", "--port", "8000", \
     "--timeout-graceful-shutdown", "30"]
```

Note `--host 0.0.0.0`. Binding to `127.0.0.1` inside a container makes the port unreachable from outside it, which produces a container that is running, healthy by its own lights, and answers nothing. And note the comment above `CMD`: an agent turn can take twenty seconds, so a graceful-shutdown window of thirty is the difference between a deploy that finishes in-flight answers and one that cuts every user off mid-sentence.

The Compose file wires three services. The abridged shape:

```yaml
services:
  jaeger:
    image: cr.jaegertracing.io/jaegertracing/jaeger:2.20.0
    ports:
      - "16686:16686"   # the UI
      - "4318:4318"     # OTLP/HTTP -- the port atlas.obs.export POSTs to

  ollama:
    image: ollama/ollama:latest
    volumes:
      - ollama-models:/root/.ollama

  atlas:
    build:
      context: ..
      dockerfile: deploy/Dockerfile
    depends_on:
      jaeger:
        condition: service_healthy
    environment:
      ATLAS_MODEL: "${ATLAS_MODEL:?set ATLAS_MODEL, see VERSIONS.md}"
      ATLAS_OLLAMA_HOST: "http://ollama:11434"
    read_only: true
    tmpfs:
      - /tmp:size=64m
    volumes:
      - atlas-workspace:/app/data/workspace
    security_opt:
      - no-new-privileges:true

volumes:
  ollama-models:
  atlas-workspace:
```

Two words in that file are worth defining, since neither is obvious. A **tmpfs** is a filesystem that lives in RAM and disappears when the container stops; mounting one at `/tmp` is how you give a read-only container the one scratch directory Python expects. **OTLP** is the OpenTelemetry Protocol, the wire format a program uses to ship traces to a collector — here, to the Jaeger container on port 4318. Neither is needed before Phase 15; they are named so the file reads as English.

Four things to take from this. `ATLAS_OLLAMA_HOST: "http://ollama:11434"` is the service-name rule, and the file's own comment calls it *"the single most common reason a containerised app cannot reach a model that is plainly running."* `${ATLAS_MODEL:?message}` makes a missing variable a startup failure with a message rather than a service that boots with a broken default. `ollama-models:/root/.ollama` is a named volume, so the multi-gigabyte model download survives `docker compose down`. And `read_only: true` plus one `tmpfs` plus one named volume means the only directory the agent can write to is the jailed workspace — Phase 3's path check, re-enforced by the kernel.

> **Your turn.** The compose file sets `ATLAS_OLLAMA_HOST: "http://ollama:11434"`. Suppose instead the model runner is a Windows process on your laptop and the Atlas container is in Docker. Write the value that variable would need, and then say in one sentence why plain `localhost` is wrong in *both* arrangements, for two different reasons.

I parsed the two files here rather than guessing, and the audit turns up something worth noticing:

```
cr.jaegertracing.io/jaegertracing/jaeger:2.20.0      pinned tag
ollama/ollama:latest                                 floating
FROM lines: ['python:3.12-slim']
USER lines: ['atlas']
read_only: true present
```

Two of three images are pinned to a tag and one is `:latest` — the weakest form there is, since it can change under you between one `docker compose pull` and the next with no record of what changed. The Dockerfile's own first comment says a tag is a moving pointer and production should pin a digest; that advice is followed unevenly in the file that gives it. Exercise A.5.2 has you reproduce this audit.

### (d) Exercises

**A.5.1 (easy).** Open `deploy/Dockerfile` from the snapshot. Without running anything, answer in writing: (i) if you edit one line of `atlas/llm.py`, which instructions are re-executed and which come from cache; (ii) what would break if `USER atlas` were moved to just below `WORKDIR /app`; (iii) why `EXPOSE 8000` does not make the port reachable from your laptop, and which line in the Compose file does.

**A.5.2 (medium).** Write a short Python script (standard library only, no Docker needed) that reads `deploy/docker-compose.yml` and `deploy/Dockerfile` as text, extracts every image reference with a regular expression, and prints each one classified as `digest`, `pinned tag`, or `floating`. Confirm you get the three references listed above. Then write two sentences on what you would change, and what that change would cost you.

**A.5.3 (hard).** Still without Docker, write the assertions you would want in a test that guards this deployment: no image is `:latest`; the Dockerfile contains a `USER` instruction that is not `root`; the Compose file sets `read_only: true` on the `atlas` service; and no service points `ATLAS_OLLAMA_HOST` at `localhost`. Implement them against the file text and run them. Then explain in a paragraph why a test that greps a Dockerfile is worth writing even though it proves nothing about a running container. *If you have Docker installed*, additionally run `docker compose -f deploy/docker-compose.yml config` and compare the resolved output to the file you read. `# not executed during authoring; verified by the author on the target platform`

### (e) Canonical documentation

- Dockerfile reference — `https://docs.docker.com/reference/dockerfile/`
- Compose file reference (the Compose Specification) — `https://docs.docker.com/reference/compose-file/`
- Compose volumes — `https://docs.docker.com/reference/compose-file/volumes/`
- Getting started with Compose — `https://docs.docker.com/get-started/workshop/08_using_compose/`

---

## A.6 [core] JSON Schema

**Deliberately left out:** `$id` and reference resolution across documents, `$dynamicRef`/`$dynamicAnchor`, vocabularies and meta-schemas, `unevaluatedProperties`, `patternProperties`, `format` as assertion versus annotation, and everything about bundling. json-schema.org covers all of it. Atlas uses perhaps a dozen keywords, and almost never writes one by hand.

### (a) What it is

JSON Schema is a JSON document that describes what other JSON documents are allowed to look like. It is the lingua franca between your program and a language model: you send the schema, the provider constrains generation so the tokens can only form a conforming document, and you validate what comes back against the same schema.

The reason it matters more in agent work than in ordinary API work is that your counterparty is not a well-behaved client library. It is a model that will, given the chance, return `{"intent": "lookup_thing"}` or add a helpful `"confidence"` field nobody asked for. A schema is how you narrow what it is even *able* to emit.

### (b) The 20% you need for this book

A schema is an object of **keywords**. The ones this book uses:

`"type"` — one of `"object"`, `"array"`, `"string"`, `"integer"`, `"number"`, `"boolean"`, `"null"`.
`"properties"` — a map from property name to a subschema.
`"required"` — an array of property *names*. A property that is not listed may be absent entirely.
`"additionalProperties": false` — no properties beyond those named.
`"enum"` — a closed list of allowed values.
`"description"` — annotation only, no constraint, and the single most valuable keyword you have, because it is what the model reads.
`"items"` — the subschema every array element must satisfy.
`"minimum"` / `"maximum"`, `"minLength"` / `"maxLength"` — bounds.
`"anyOf"` — a list of subschemas, at least one of which must match. This is how "an integer or null" is expressed.
`"$defs"` and `"$ref"` — a place to put named subschemas and a pointer to one, used whenever a model nests another model.

Phase 0's question 10 asks for a schema with a required string `city` and an optional integer `days` of at least 1. Written by hand:

```json
{
  "type": "object",
  "properties": {
    "city": {"type": "string"},
    "days": {"type": "integer", "minimum": 1}
  },
  "required": ["city"],
  "additionalProperties": false
}
```

The whole answer is in the `required` array: `city` is in it, `days` is not. Optionality in JSON Schema is not a keyword on the property; it is absence from `required`.

**Two rules that only bite when a model is the producer.** First, `required` and *nullable* are different axes. A field can be required and still permitted to be null, which is what `anyOf: [{"type":"integer"},{"type":"null"}]` plus membership in `required` expresses — and it is the shape Atlas prefers, because it keeps "the model said null" distinguishable from "the model omitted the field." Second, several providers' **strict** constrained-decoding modes require that *every* property appear in `required` and that `additionalProperties: false` appear on *every* object. A schema that is perfectly legal can still be rejected by a strict-mode endpoint.

> **Concept check 6.1.** Against the hand-written schema above, is `{"city": "Lisbon", "days": null}` valid? Is `{"city": "Lisbon"}`? Is `{"city": "Lisbon", "days": 0}`? Three answers, and the reasons differ.

> **Concept check 6.2.** Name one thing `additionalProperties: false` does that `ConfigDict(extra="forbid")` cannot, and one thing `extra="forbid"` does that `additionalProperties: false` cannot. If you cannot name both, re-read the last paragraph of A.2(c).

**You will rarely write one by hand.** Pydantic generates them, and that is the point of A.2: one class, one schema, one validator. What you need to be able to do is *read* the generated schema and notice when it is not what you meant.

**Misconception: "the schema validates the answer."** It validates the *shape* of the answer. A schema cannot tell you that `{"region": "north", "units": 377}` is the wrong region. Constrained decoding buys schema compliance, not semantic accuracy — a caveat the providers themselves publish. Every verifier Atlas builds from Phase 3 onward exists because the schema stopped at the shape.

### (c) Worked example — `atlas/tools/registry.py` as it stood in `atlas_phase_04.zip`

This file grows substantially in later phases; the Phase 4 snapshot is the clearest version to learn from, and the Phase 16 version has the same core functions. Its module docstring states the whole design in four lines:

```
    signature + docstring  ->  pydantic model  ->  JSON Schema  (sent to model)
                                              \->  model_validate (checks args)
```

The generator is `schema_for`:

```python
def schema_for(fn: Callable[..., Any], *, arg_docs: Mapping[str, str] | None = None,
               strict: bool = True) -> dict[str, Any]:
    """The JSON Schema that goes in the `parameters` field of a tool definition.

    `strict=True` runs Phase 2's `strict_json_schema`, which lists every
    property in `required` and sets `additionalProperties: false` throughout.
    ...
    The honest cost: a tool parameter with a Python default is now *required* in
    the schema, so the model must supply it every time.
    """
    schema = args_model_for(fn, arg_docs=arg_docs).model_json_schema()
    schema = _strip_titles(schema)
    return strict_json_schema(schema) if strict else schema
```

Point it at the simplest tool in the repository, `calculate` in `atlas/tools/calculator.py`, whose signature is `calculate(expression: str, precision: int = 2)` — a required string and an optional bounded integer, the same shape as the self-test question. With `strict=False`, verified output:

```json
{
  "additionalProperties": false,
  "properties": {
    "expression": {
      "description": "An arithmetic expression using only numbers, parentheses, and the operators + - * / // % **. For example '(14 + 9) / 2'. Names, variables and function calls are rejected -- look values up with another tool first and pass the numbers in.",
      "type": "string"
    },
    "precision": {
      "default": 2,
      "description": "Number of decimal places to round the result to, 0 to 10.",
      "type": "integer"
    }
  },
  "required": ["expression"],
  "type": "object"
}
```

Every `description` came out of the function's Google-style docstring, parsed by `parse_docstring`. Nobody typed a schema. Rename `expression` in the code and the prompt renames itself on the next run.

Now the same call with `strict=True`:

```json
  "required": ["expression", "precision"]
```

`precision` has joined `required` while keeping `"default": 2`. That is exactly the trade the docstring warns about, and it is worth sitting with: the model must now always supply a precision, and in exchange you can never confuse "it chose 2" with "it forgot." The whole transformation is one small recursive function in `atlas/llm.py` — 24 non-blank lines including its docstring — and these three lines are the part that does the work:

```python
    if isinstance(out.get("properties"), dict):
        out["required"] = sorted(out["properties"])
        out["additionalProperties"] = False
```

recursing through `properties`, `$defs`, `items` and `anyOf` on the way down.

Two more observations from running this. `_strip_titles` removes Pydantic's auto-generated `"title": "Expression"` keys, which say nothing the property name did not and are re-sent on every step of every episode; on the small `Forecast` model I built to check, stripping titles took the schema from 370 to 315 characters, and the effect compounds across a six-tool registry. And nesting works the way you would hope: `PlanDraft.model_json_schema()` puts `PlanDraftStep` under `$defs` and refers to it with `$ref`, and `strict_json_schema` reaches inside — verified, the nested object's `required` came back as `['depends_on', 'description', 'expects', 'id', 'tool']`.

One small thing to know, verified by running it: Pydantic's `model_json_schema()` emits no `$schema` key at all. The dialect it targets is therefore implicit — see the Pydantic row in the VERSIONS.md delta for which dialect that currently is. Implicit is fine for a provider endpoint, which knows what it accepts, and not fine if you hand the document to a general-purpose validator that expects to be told.

> **Your turn.** Write the one-line change to `Forecast` that puts `days` into the schema's `required` array while still letting the model decline to give a number. There is more than one way; name the one that keeps "the model declined" distinguishable from "the model forgot."

### (d) Exercises

**A.6.1 (easy).** Write, by hand, the schema for Phase 0's question 10: an object with a required string `city` and an optional integer `days` of at least 1, forbidding extra properties. Then write the Pydantic model that generates it — `city: str` and `days: int | None = Field(default=None, ge=1)` with `model_config = ConfigDict(extra="forbid")` — print `model_json_schema()`, and list every difference between your hand-written version and the generated one. There are at least three.

**A.6.2 (medium).** From the `atlas_phase_04.zip` root, call `schema_for(calculate)` with `strict=False` and `strict=True` and diff the two outputs. Then write a one-paragraph answer to this: if a provider's strict mode requires every property in `required`, and your tool has a genuinely optional parameter, what are your two options and what does each cost? Name which one Atlas took.

**A.6.3 (hard).** Import `strict_json_schema` from `atlas.llm` and `PlanDraft` from `atlas.schemas`. Generate the schema, confirm it contains `$defs` and a `$ref`, and confirm that `strict_json_schema` rewrote `required` on both the outer object and the nested one. Now write a small schema of your own containing an `anyOf` with a nested object inside one branch, pass it through `strict_json_schema`, and check whether the nested object inside the `anyOf` branch was reached. Report what you found, and say whether that behaviour is correct for strict-mode purposes and why.

### (e) Canonical documentation

- Getting started, step by step — `https://json-schema.org/learn/getting-started-step-by-step`
- Draft 2020-12 specification and release notes — `https://json-schema.org/draft/2020-12`
- Pydantic's JSON Schema generation — `https://docs.pydantic.dev/latest/concepts/json_schema/`

---

## A.7 [core] HTTP, SSE, and streaming

**Deliberately left out:** HTTP/2 and HTTP/3 framing, TLS, cookies and sessions, CORS, caching semantics, WebSockets beyond one comparison, connection pooling, and the `httpx` API surface beyond two calls. MDN and the RFCs cover all of it. You need roughly: what a POST body and a response envelope look like, five status codes, two headers, and the SSE frame format.

### (a) What it is

Every model call in this book is an HTTP POST with a JSON body. Everything else — the vendor SDK, the framework's chat model class — is a wrapper over that POST. Learning the raw shape is what lets you debug the stack instead of guessing at it, which is why Phase 0 §7.3 makes you call the endpoint three ways.

**Server-sent events** are the other half. An ordinary HTTP response arrives as one payload after the server has finished thinking. An SSE response is a response that never ends: the server sets `Content-Type: text/event-stream` and writes framed text messages as they become available, and the client reads them incrementally. That is how a chat UI shows words appearing instead of a spinner.

### (b) The 20% you need for this book

**The request.** A POST with `Content-Type: application/json`, a JSON body, and usually an `Authorization: Bearer <key>` header. The body's shape is the provider's business; Atlas builds it in one pure function per dialect so the wire format is testable without a server.

**Status codes**, and the only classification that matters for a client: is retrying this worth anything? `2xx` succeeded. `4xx` means *your request* was wrong, and sending it again will be wrong again — except for two. `408` is a timeout, and `429` is rate limiting, both of which may pass. `5xx` is the server's problem and may pass. That is the entire rule, and Atlas encodes it in one line:

```python
def is_retryable_status(status: int) -> bool:
    """Pure retry decision for an HTTP status code.

    429 and 5xx are the server's problem and may pass; 408 is a timeout. Every
    other 4xx is our request being wrong, and retrying it just spends budget.
    """
    return status in (408, 429) or 500 <= status <= 599
```

Phase 0's question 11 asks for the rate-limit status and the header that tells you how long to wait: **429**, defined in RFC 6585 §4 (April 2012), and **`Retry-After`**, defined in RFC 9110 §10.2.3. `Retry-After` is optional on a 429, but it is the only field that generic tooling actually reads, so honour it when it is there.

**Backoff.** When you must retry, wait longer each time, capped, and add randomness. The exponential part stops you hammering a struggling server; the **jitter** stops every client that hit the same outage from retrying at the same instants and recreating it. Atlas's `backoff_delay` produces a deterministic ceiling — verified as `[0.5, 1.0, 2.0, 4.0, 8.0]` for the default policy — and `full_jitter` draws uniformly from zero to that ceiling. The docstring on `full_jitter` is worth reading in full, because it records that for eleven phases `backoff_delay`'s own comment said "jitter belongs to the caller" and no caller ever added any. A comment naming a responsibility is not the same as somebody holding it.

**The response envelope.** Parse it into your own type immediately, in a pure function, and keep the raw payload. Atlas's `parse_ollama_chat` takes a response body and a measured latency and returns a `Completion`; it touches no network, no clock and no globals, which is why it can be tested against a JSON file. Run it on the scripted fixture `tests/fixtures/ollama_chat_hello.json` and you get:

```
Hello. Atlas is awake. | MODEL-FROM-VERSIONS-MD | tier A | 24 prompt / 40 completion tokens | 31.2 tok/s
```

Note the detail its docstring flags: *"Ollama reports durations in nanoseconds, so generation speed is eval_count / (eval_duration / 1e9)."* Unit mistakes in timing fields are extremely common and produce numbers that are wrong by a factor of a billion while looking plausible in a log.

**Misconception: "HTTP 200 means it worked."** 200 means the *transport* worked. The body can still be truncated JSON, an HTML error page from a proxy, or a perfectly well-formed answer to a question you did not ask. `is_retryable_status` deliberately says nothing about any of that: it answers one narrow question, "is sending this again worth anything," and everything else is the parser's job. Keeping those two decisions in separate functions is why both can be tested without a server.

> **Concept check 7.1.** A provider returns HTTP 200 with a body that is not valid JSON. What does `is_retryable_status(200)` say, and is it wrong? What should the client do instead, and where in Atlas does that decision live?

**SSE format.** A frame is one or more lines followed by a **blank line**:

```
event: token
id: 7
data: {"text":"377"}

```

`data:` carries the payload, `event:` names the type (the browser's `EventSource` dispatches it as a named event; without it you get a generic `message`), `id:` sets the last-event id the browser replays from on reconnect, and a line starting with `:` is a comment that the client ignores. **The blank line is the frame delimiter**, and forgetting it is the classic SSE bug: the client buffers your message forever waiting for the terminator, so the server looks hung while sending perfectly good bytes.

The format's one sharp edge: a payload cannot contain a bare newline, because `\n` ends the line. JSON-encoding every payload removes the problem entirely, since a JSON string escapes its own newlines.

> **Concept check 7.2.** `sse_comment` emits `: text` and every client is specified to ignore it. Why would you ever send one, and what goes wrong on a long agent turn if you never do?

**Streaming a model response** is the same idea one layer down: the provider sends chunks over a connection that stays open, in a format usually called **NDJSON** — newline-delimited JSON, one complete JSON object per line, with no enclosing array. You accumulate them, and the final chunk carries the token counts. The design rule Atlas applies is that a streamed reply must carry the same provenance as a non-streamed one, so the stream yields text deltas and then exactly one terminal `Completion` object.

### (c) Worked example — `atlas/api/sse.py`, in `atlas_phase_16.zip`

`atlas/api/sse.py` arrives in Phase 15 with the HTTP service, so it is later in the book than most examples here; nothing in it requires FastAPI or any Phase 15 idea to read. It is five pure functions and no server, which makes it unusually good to learn from: you can exercise the whole protocol offline. Its docstring opens with a two-paragraph orientation written for exactly the reader of this appendix, including why SSE rather than WebSockets — *"a stream of agent progress is one-directional, and SSE rides on plain HTTP, so it survives proxies, load balancers and corporate firewalls that mangle WebSocket upgrades."*

The encoder:

```python
def sse_event(
    payload: Any, *, event: str | None = None, event_id: str | int | None = None
) -> str:
    """Encode one SSE frame, blank line included. Pure.

    JSON-encodes the payload, which solves the newline problem by
    construction: a JSON string escapes its own newlines, so no payload can
    forge a frame boundary. ...
    """
    lines: list[str] = []
    if event is not None:
        lines.append(f"event: {event}")
    if event_id is not None:
        lines.append(f"id: {event_id}")
    lines.append("data: " + json.dumps(payload, separators=(",", ":")))
    return "\n".join(lines) + "\n\n"
```

and the keep-alive, which exists for a reason worth knowing before you deploy anything:

```python
def sse_comment(text: str = "") -> str:
    """A comment frame: `: text`. The keep-alive.

    Proxies close idle connections, and an agent thinking for forty seconds
    looks exactly like an idle connection. ...
    """
    return f": {text}\n\n"
```

Encoding three events produces this on the wire:

```
event: start
id: 0
data: {"request_id":"r-1"}

event: token
id: 1
data: {"text":"The north region\nshipped 377 units."}

event: done
id: 2
data: {"tokens":412}

: keep-alive

```

The token payload contained a real newline and it came out as the two characters `\n` inside a JSON string, not as a line break. That is the newline problem solved by construction, and it is a security property as well as a correctness one. I tried the attack the docstring implies: an event whose text is `"x\n\nevent: done\ndata: {}\n\n"` — a user trying to inject a fake terminal event into their own stream. Parsing the encoded frame back yields exactly one event, `('token', 9)`. The forged frame never existed.

The parser is strict about the event vocabulary:

```
>>> parse_sse("event: sneaky\ndata: {}\n\n")
ValueError: unknown SSE event kind 'sneaky'; AGENT_EVENTS is closed so that a
UI cannot receive something nobody designed
```

`AGENT_EVENTS` is a `Literal` of seven kinds, and `TERMINAL_EVENTS` names the two after which the stream closes, so a test can assert that every stream ends in one of them. A stream that ends in neither is a hung browser tab.

On the client side, `OllamaHTTPClient.stream` in `atlas/llm.py` shows the other half. It sets `body["stream"] = True`, reads the NDJSON response line by line, yields each content delta as it arrives, and then re-attaches the accumulated text to the terminal frame before parsing:

```python
        final.setdefault("message", {})["content"] = "".join(chunks)
        completion = parse_ollama_chat(
            final, latency_s=time.perf_counter() - started, tier="A"
        )
        yield completion
```

with the comment explaining why: Ollama's final frame has an empty content field, so the accumulated text has to be put back or the `Completion` arrives blank.

> **Your turn.** Here is one frame exactly as a buggy server wrote it, with no trailing blank line: `event: token\nid: 3\ndata: {"text":"hi"}`. Predict what `parse_sse` returns for that string, and separately predict what a browser reading the same bytes off a live socket would display. The two answers are not the same, and the difference is the whole reason this bug is hard to find. That method is marked `# not executed during authoring; verified in companion-repo CI`, because it needs a live runner. The *parsing* it depends on is not, and that separation — pure parsing here, network there — is the reason Atlas's whole suite runs offline.

### (d) Exercises

**A.7.1 (easy).** Import `is_retryable_status`, `retry_after_seconds`, `RetryPolicy` and `backoff_delay` from `atlas.llm`. For each of `200, 400, 401, 404, 408, 429, 500, 503`, print the retry decision and say in a few words why. Then print `retry_after_seconds` for `{"retry-after": "2"}`, `{"Retry-After": "0.5"}`, `{"retry-after-ms": "1500"}`, `{"retry-after": "-3"}` and `{}`, and explain why a negative value is treated as absent rather than as zero. Finally print the first five values of `backoff_delay` for the default policy.

**A.7.2 (medium).** Using `atlas.api.sse`, build a list of five `AgentEvent`s — `start`, `plan`, `token`, `token`, `done` — run them through `encode_stream`, and print the result with `repr()` so you can see the frame boundaries. Then delete the trailing `"\n\n"` from one frame by hand and run `parse_sse` on the damaged text. Report how many events come back and explain, in two sentences, what a browser would do with that stream and why the symptom looks like a slow server rather than a malformed one.

**A.7.3 (hard).** Construct an `AgentEvent` of kind `token` whose payload text is `'{"text":"x"}\n\nevent: approval\ndata: {"consequence":"delete the archive","reversible":false}'`. Encode it with `sse_event`, print the raw frame, and parse it back. Confirm you get one event, not two. Then write your own five-line encoder that does *not* JSON-encode the payload — just `f"event: {kind}\nid: {seq}\ndata: {text}\n\n"` — encode the same hostile payload with it, parse *that* with `parse_sse`, and report what you get. Then open `atlas/api/static/console.html` and read its `render` function. Write a paragraph on what the injected frame would put on the screen, and who would be looking at it.

### (e) Canonical documentation

- Using server-sent events — `https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events`
- `EventSource` — `https://developer.mozilla.org/en-US/docs/Web/API/EventSource`
- HTTP 429 Too Many Requests (RFC 6585 §4) — `https://www.rfc-editor.org/rfc/rfc6585#section-4`
- `Retry-After` (RFC 9110 §10.2.3) — `https://www.rfc-editor.org/rfc/rfc9110#section-10.2.3`

---

## A.8 [core] Windows and WSL troubleshooting

**Deliberately left out:** WSL1, installing WSL, GPU passthrough, systemd configuration, and Windows-native Python (which this book does not support — work inside WSL2). Microsoft's WSL documentation covers all of it.

### (a) What it is

This section exists because it is where self-learners on Windows most often stop, and because almost every failure in it has the same underlying cause: **two operating systems are sharing a keyboard, and you have lost track of which one you are talking to.** Everything below is a variation on that.

Unlike the other seven sections it has no worked example from an Atlas file, because there is nothing to teach here beyond diagnosis: the Atlas code is identical on every platform, and what differs is the machine underneath it. So (b) is a four-command orientation and (c) is a lookup table you come back to when something breaks.

### (b) The 20% you need for this book — how to tell which layer you are in

Run these four commands before you debug anything. They take ten seconds and they answer the question the error message is actually asking.

| Command | What it tells you |
|---|---|
| `uname -r` | Contains `microsoft-standard-WSL2` if you are inside WSL2. If the command does not exist, you are in PowerShell or `cmd`. |
| `echo $WSL_DISTRO_NAME` | The distro name if you are inside WSL; empty otherwise. |
| `pwd` | A path starting `/mnt/c/` means your files live on the **Windows** filesystem, seen through a translation layer. A path under `/home/` means the **Linux** filesystem. |
| `which python3` / `which node` | A result under `/mnt/c/...` means you are running a **Windows** executable from inside WSL. That is almost never what you want, and it is the cause of a whole family of confusing errors. |

Two configuration files, often confused. `%USERPROFILE%\.wslconfig` is a **Windows** file that configures the WSL2 virtual machine globally — memory, processors, networking mode. `/etc/wsl.conf` is a **Linux** file inside one distro that configures that distro — mount options, whether the Windows `PATH` is appended. Both require `wsl --shutdown` from PowerShell and a restart of the distro to take effect. Editing the wrong one and concluding the setting does not work is a common half-hour.

**Misconception: "turning on mirrored networking fixes WSL networking."** It fixes one class of problem — reaching a Windows service from inside the distro on `localhost` — and is a known source of another, publishing container ports back out to the Windows host. It is a trade, not an upgrade, and the table below marks both directions. If your only problem is reaching the model runner, installing the runner inside WSL solves it with no trade at all.

> **Concept check 8.1.** You edited `/etc/wsl.conf`, reopened your terminal, and the setting has no effect. Give the two likeliest reasons, one of which is not "you edited it wrong."

> **Concept check 8.2.** `echo $ATLAS_MODEL` prints exactly the model name you expect, and the runner still returns 404 for it. What is the next thing you print, and what are you looking for?

One rule that prevents more problems than any fix below: **keep the project on the Linux filesystem.** `~/atlas-agent`, not `/mnt/c/Users/you/atlas-agent`. Phase 0 §7.2 says this and it is worth repeating, because a project under `/mnt/c` pays a translation cost on every file operation, which turns a two-second test suite into a slow one, and it inherits the permission and line-ending problems in the table below for free.

### (c) Symptom → cause → fix

**Verification status.** Items marked **[reproduced]** were run in this appendix's Linux workspace and the exact output is quoted. Items marked **[reported, unverified]** come from primary vendor documentation or from issue reports; no Windows machine and no Docker daemon were available during authoring (`docker version` → command not found), so I could not exercise them myself.

#### Ollama and the model runner

| Symptom (exact text) | Cause | Fix |
|---|---|---|
| `curl: (7) Failed to connect to localhost port 11434: Connection refused`, from inside WSL, while Ollama is plainly running in the Windows system tray | The runner is a **Windows** process listening on the Windows loopback. Under WSL2's default NAT networking, `localhost` inside the distro is the distro's own loopback, not Windows'. **[reported, unverified]** | Easiest: install Ollama **inside** WSL and stop using the Windows build. Alternative: enable mirrored networking — add `[wsl2]` / `networkingMode=mirrored` to `%USERPROFILE%\.wslconfig`, then `wsl --shutdown`. Mirrored mode makes Windows' loopback reachable as `localhost` from WSL; it requires Windows 11 22H2 or later. |
| Connection refused from another machine, or from a container, even though `curl localhost:11434` works | The runner binds to loopback only by default. | Set `OLLAMA_HOST=0.0.0.0:11434` in the runner's environment before starting it, and understand that you have just exposed it to your network. **[reported, unverified]** |
| The app in a container cannot reach the model, but `curl` on the host can | `localhost` inside a container is that container. | Use the Compose service name: `ATLAS_OLLAMA_HOST=http://ollama:11434`, exactly as `deploy/docker-compose.yml` does. |

#### Docker Desktop and WSL2

| Symptom | Cause | Fix |
|---|---|---|
| `The command 'docker' could not be found in this WSL 2 distro. We recommend to activate the WSL integration in Docker Desktop settings.` | Docker Desktop's WSL integration is **per-distro and off by default** for distros you added later. The message is Docker Desktop's own shim telling you exactly this. | Docker Desktop → Settings → Resources → WSL Integration → enable your distro → Apply & Restart. Then reopen the WSL shell. **[reported, unverified]** — error text quoted from a report filed against the official WSL-backend page linked below |
| `Cannot connect to the Docker daemon at unix:///var/run/docker.sock. Is the docker daemon running?` | Either Docker Desktop is not running, or integration is enabled but the distro was started before Docker Desktop. | Start Docker Desktop first, then `wsl --shutdown` and reopen the shell. **[reported, unverified]** |
| `docker compose up` succeeds but `http://localhost:8000` from the Windows browser shows nothing | Port publishing crossed a boundary it was not configured for; this is a known rough edge under mirrored networking in particular. | Confirm the `ports:` mapping is `"8000:8000"` and not `"8000"` alone. If you enabled mirrored networking, try reverting to NAT — port-binding regressions under mirrored mode are a recurring report. **[reported, unverified]** |
| Builds are very slow and `COPY` takes minutes | The build context is on `/mnt/c`, so every file crosses the translation layer. | Move the project to `~/`. |
| Files written by a container are owned by `root` on the host and you cannot edit them | The container ran as root and wrote through a bind mount. | Run as a non-root user, as `deploy/Dockerfile` does with `useradd --uid 10001 atlas` and `USER atlas`. |

#### Playwright

Playwright appears nowhere in the Atlas source — I checked, and the browser tool is a deferred build in Appendix F. You will meet it if you attempt that build or if your coding assistant pulls it in. The failures are worth two rows because they are opaque the first time.

| Symptom (exact text) | Cause | Fix |
|---|---|---|
| `Host system is missing dependencies to run browsers.` followed by a boxed list of missing libraries — `libnss3.so`, `libatk-1.0.so.0`, `libgbm.so.1`, `libasound.so.2` and about twenty more | A bare WSL distro is a minimal server image with none of a desktop's shared libraries. The browser binaries downloaded fine; they cannot link. **[reported, unverified]** | Run the command the error itself prints: `sudo npx playwright install-deps` (or `sudo playwright install-deps` for the Python package). The Ubuntu images WSL ships are supported targets. |
| The same error persists on a non-Debian distro, or `E: Unable to locate package ...` during `install-deps` | `install-deps` knows Debian and Ubuntu package names only. | Install the listed libraries with your distro's own package manager, or switch to an Ubuntu distro for this work. **[reported, unverified]** |
| Browsers launch but nothing is visible | There is no display server. | Run headless, which is the default and the correct choice for an agent. A visible browser needs WSLg or an X server and is a debugging convenience, not a requirement. **[reported, unverified]** |

#### File permissions across `/mnt/c`

| Symptom | Cause | Fix |
|---|---|---|
| `chmod 600 file` reports success, and `stat --format '%a' file` still prints `777` | Windows drives are mounted as **DrvFs** — the driver WSL uses to present an NTFS volume to Linux — without the `metadata` option, so there is nowhere to store Unix permission bits. The `chmod` is silently discarded. **[reported, unverified]** | Add to `/etc/wsl.conf`: `[automount]` / `options = "metadata,umask=022,fmask=011"`, then `wsl --shutdown`. Microsoft documents this at the File Permissions page linked below. |
| `Permissions 0777 for 'id_rsa' are too open` from `ssh`, or a similar refusal from another tool | Same cause: the key lives under `/mnt/c` and its mode cannot be tightened. | Enable `metadata` as above, or — better — keep keys on the Linux filesystem under `~/.ssh`. |
| Everything under `/mnt/c` appears executable | Default DrvFs behaviour without `fmask`. | The `fmask=011` in the options above. |

#### Line endings

This is the family I could reproduce directly, and the error messages are misleading enough to be worth quoting exactly.

| Symptom (exact text) | Cause | Fix |
|---|---|---|
| `./script.sh: not found` — or on other systems `/bin/bash^M: bad interpreter: No such file or directory` — for a script that plainly exists | The shebang line ends `#!/bin/bash\r`, so the kernel looks for an interpreter whose name ends in a carriage return. **[reproduced]** — exit code 127. | `sed -i 's/\r$//' script.sh`, or install and run `dos2unix`. Confirm first with `file script.sh`, which prints `... with CRLF line terminators`. **[reproduced]** |
| `script.sh: line 2: $'ls\r': command not found` | Every command in a CRLF-terminated shell script has an invisible `\r` appended to its last argument. **[reproduced]** | Same fix. The `$'...\r'` in the message is the diagnostic: bash is telling you the byte is there. |
| Your `.env` sets `ATLAS_MODEL` correctly, the value prints correctly, and the runner returns a 404 for a model you can see in `ollama list` | The `.env` has CRLF line endings, so the value is `"gemma4:12b\r"` — eleven characters where you see ten, and a terminal prints it identically. **[reproduced]**: `repr(settings.model)` → `'gemma4:12b\r'`, `len` 11. | Convert the file. Then make the class of bug visible: print `repr()`, not the value, whenever a string comparison fails for no reason. |
| A `make` target fails with a bizarre parse error | `Makefile` has CRLF endings; `make` is stricter about whitespace than almost anything else. | Convert it, and configure your editor to write LF for this project. |

The general prevention: set your editor to LF for the whole project, and keep the project out of `/mnt/c` so that Windows tools are not editing it in the first place.

#### `PATH` and path separators

| Symptom | Cause | Fix |
|---|---|---|
| `python` inside WSL starts a **Windows** Python, or `node --version` reports the Windows version | By default WSL appends the entire Windows `PATH` to the Linux one, so Windows executables are on your path and can shadow or precede Linux ones. **[reported, unverified]** | Diagnose with `which -a python3`. To stop it entirely, add to `/etc/wsl.conf`: `[interop]` / `appendWindowsPath = false`, then `wsl --shutdown`. Be aware this also removes convenient access to `code`, `explorer.exe` and `docker.exe`. |
| `PYTHONPATH` set in PowerShell has no effect inside WSL, or vice versa | Environment variables do not cross the boundary except through `WSLENV`, and the two systems use different path separators — `;` on Windows, `:` on Linux. | Set variables in the shell you are actually running in. Atlas's `Makefile` exports `PYTHONPATH := .` itself for exactly this reason. |
| `ModuleNotFoundError: No module named 'atlas'` when running a script directly, on any platform | `python scripts/hello_model.py` puts `scripts/` on the import path, not the repo root. Phase 0 §7.2 documents this. | Run through `make`, or `pip install -e .`, or export `PYTHONPATH=.`. |
| A path you built with `os.path.join` works on Linux and breaks on Windows, or a hard-coded `/` path fails | String concatenation of paths is not portable. | Use `pathlib.Path` and the `/` operator. Atlas's `Settings` declares `data_dir: Path` and `cache_dir: Path`, so a string from the environment is coerced once, at the boundary. |

> **Your turn.** Run `file Makefile` in your project directory right now, before you read the line-endings table above again. Write down what it says. If the words "CRLF line terminators" appear, you have already found the bug that was going to cost you an evening in Phase 1.

### (d) Exercises

**A.8.1 (easy).** Run the four orientation commands from the preamble on your own machine and write the output in your lab notebook. Then answer: is your Atlas project on the Linux filesystem or under `/mnt/c`, and which Python is first on your path? If you are not on Windows, run them anyway and note what each one reports, so that you recognise the WSL answers when you help someone else.

**A.8.2 (medium).** Reproduce the line-ending family deliberately, on any platform. Create `crlf.sh` containing `#!/bin/bash` and `echo hello` with CRLF terminators (`printf '#!/bin/bash\r\necho hello\r\n' > crlf.sh`), make it executable, and run it. Record the exact error and the exit code. Run `file crlf.sh` and record the output. Fix it with `sed -i 's/\r$//' crlf.sh` and confirm. Then do the `.env` version: build a `Settings` object with `ATLAS_MODEL` set to a value ending in `\r`, print both `str` and `repr`, and write one sentence on why the printed form is so misleading.

**A.8.3 (hard).** Write a `scripts/doctor.py` that a student on any platform could run before Phase 1 to diagnose their own environment. It should report, without crashing on any platform: whether it is running under WSL; whether the current working directory is under `/mnt/`; the Python executable path and version; whether `atlas` is importable; whether any file in the repository has CRLF terminators (walk the tree, read bytes, look for `\r\n` outside binary files); and whether `ATLAS_MODEL`, if set, contains any whitespace or control characters. Print one line per check with a clear pass/fail and, for each failure, the exact fix command from the tables above. Run it on your own machine and fix whatever it finds.

### (e) Canonical documentation

- Advanced settings configuration in WSL (`.wslconfig`, `/etc/wsl.conf`) — `https://learn.microsoft.com/en-us/windows/wsl/wsl-config`
- File permissions for WSL (the `metadata` mount option) — `https://learn.microsoft.com/en-us/windows/wsl/file-permissions`
- Docker Desktop WSL backend — `https://docs.docker.com/desktop/features/wsl/`
- Playwright browsers and system dependencies on Linux, including `install-deps` — `https://playwright.dev/python/docs/browsers`

---

## VERSIONS.md delta — Appendix A, checked 2026-09-14

Read alongside the existing file: every package pin in the Phase 0–16 sections was re-verified and none is contradicted here. These rows are additions and confirmations only.

### Re-verification of existing rows

| Fact | Value | Source | Checked |
|---|---|---|---|
| pydantic | 2.13.5 — unchanged; **installed and exercised** in the appendix workspace | https://pypi.org/pypi/pydantic/json | 2026-09-14 |
| pytest | 9.1.1 — unchanged; **installed and exercised** | https://pypi.org/pypi/pytest/json | 2026-09-14 |
| Newest stable Python | 3.14.7 — unchanged; `docs.python.org/3` currently serves 3.14.7 | https://www.python.org/downloads/ | 2026-09-14 |
| Python floor for this book | 3.11 — unchanged. `asyncio.timeout` and `asyncio.TaskGroup` both require it | https://docs.python.org/3/library/asyncio-task.html | 2026-09-14 |
| Base image `python:3.12-slim` | unchanged — a TAG; pin a digest in production | https://hub.docker.com/_/python | 2026-09-14 |

### New rows for this appendix

| Fact | Value | Source | Checked |
|---|---|---|---|
| JSON Schema current stable specification | **Draft 2020-12**. Still the current stable draft; nothing newer has been released | https://json-schema.org/draft/2020-12 | 2026-09-14 |
| JSON Schema IETF standardisation — **PRE-RELEASE, not used** | `draft-ietf-jsonschema-json-schema-00` is an Internet-Draft in the IETF process. Nothing in this book depends on it; Pydantic emits 2020-12. Forward pointer only | https://www.ietf.org/archive/id/draft-ietf-jsonschema-json-schema-00.html | 2026-09-14 |
| Pydantic docs canonical URL | `https://docs.pydantic.dev/latest/` resolves. A second mirror at `https://pydantic.dev/docs/validation/latest/` also resolves and reported a version one patch behind the pin on the day checked; prefer the first | https://docs.pydantic.dev/latest/concepts/models/ | 2026-09-14 |
| pytest docs canonical URL | `https://docs.pytest.org/en/stable/` — the `how-to/` and `reference/` trees are current | https://docs.pytest.org/en/stable/how-to/parametrize.html | 2026-09-14 |
| Docker Compose file format | The **Compose Specification** is current; legacy 2.x and 3.x were merged into it and implemented from Compose CLI 1.27.0 (Compose v2). A top-level `version:` key is obsolete | https://docs.docker.com/reference/compose-file/ | 2026-09-14 |
| MDN server-sent events page location | `https://developer.mozilla.org/en-US/docs/Web/API/Server-sent_events/Using_server-sent_events` (updated within the last two weeks) | as listed | 2026-09-14 |
| WSL mirrored networking | `networkingMode=mirrored` in `%USERPROFILE%\.wslconfig`; requires Windows 11 22H2 or later; not the default. Makes Windows' `localhost` reachable from the distro | https://learn.microsoft.com/en-us/windows/wsl/wsl-config | 2026-09-14 |
| WSL `metadata` mount option | `[automount] options = "metadata,..."` in `/etc/wsl.conf` is what makes `chmod` on `/mnt/c` persist | https://learn.microsoft.com/en-us/windows/wsl/file-permissions | 2026-09-14 |
| Docker Desktop WSL 2 backend | Integration is enabled **per distro**; the docs page states the minimum WSL version and the uninstall-Docker-Engine-first prerequisite | https://docs.docker.com/desktop/features/wsl/ | 2026-09-14 |
| Playwright system dependencies | `install-deps` is documented on the Browsers page, which also states that only Debian/Ubuntu package names are known to it | https://playwright.dev/python/docs/browsers | 2026-09-14 |
| Pydantic JSON Schema dialect | `model_json_schema()` emits no `$schema` key; the dialect targeted is documented on the page below rather than in the output. Do not assert a dialect in code that reads Pydantic output — read `$schema` if you need one, and add it yourself if a downstream validator requires it | https://docs.pydantic.dev/latest/concepts/json_schema/ | 2026-09-14 |
| **Link audit** | all 46 canonical-documentation links in this appendix re-checked on this date; `playwright.dev/docs/intro` replaced by `playwright.dev/python/docs/browsers` (the intro page does not document `install-deps`), and two better pytest how-to pages added | (this appendix) | 2026-09-14 |

### Historical facts cited in this appendix's prose (dated, stable)

| Fact | Date | Source | Checked |
|---|---|---|---|
| HTTP 429 Too Many Requests defined | RFC 6585 §4, April 2012 | https://www.rfc-editor.org/rfc/rfc6585#section-4 | 2026-09-14 |
| `Retry-After` header defined | RFC 9110 §10.2.3 | https://www.rfc-editor.org/rfc/rfc9110#section-10.2.3 | 2026-09-14 |
| SQLite gained `RIGHT` and `FULL OUTER JOIN` | 3.39.0, released 2022-06-25 | https://sqlite.org/releaselog/3_39_0.html | 2026-09-14 |

### Measured while authoring this appendix (this container, not your machine)

| Quantity | Value | How |
|---|---|---|
| Offline subset run from `atlas_phase_16.zip` | **72 passed in 0.29 s** (`tests/test_config.py`, `test_llm.py`, `test_tool_registry.py`), no network, no model, no `.env` | `ATLAS_TIER=F python -m pytest` |
| `gather_bounded`, 4 branches, `limit=2`, `timeout_s=0.2` | 2 ok, 1 error, 1 timeout; wall clock 0.21 s; results in argument order | run in workspace |
| Sequential vs `gather` over five 0.2 s sleeps | 1.00 s vs 0.20 s | run in workspace |
| A coroutine that swallows `CancelledError` | **defeats `asyncio.timeout` entirely** — no `TimeoutError` is raised and the caller receives a normal return value | run in workspace |
| `computed_field` vs bare `@property` in `model_dump()` | `BranchResult.model_dump()` contains `ok` and `total_tokens`; a bare `@property` named `total` is absent | run in workspace |
| `product LEFT JOIN warranty_claim … AND quarter='2025Q4'` | S400 appears with 0 claims; `INNER JOIN` drops it; `LEFT JOIN` with the predicate moved to `WHERE` also drops it | `data/atlas.db` |
| `sum()` vs `count(*)` over an empty row set | `[(None,)]` vs `[(0,)]` | `data/atlas.db` |
| SQLite version in the authoring container | 3.45.1 | `sqlite3.sqlite_version` |
| `schema_for(calculate, strict=True)` | moves the defaulted `precision` into `required` while keeping `"default": 2` | `atlas_phase_04.zip` |
| `_strip_titles` saving on a two-field model | 370 → 315 characters | run in workspace |
| Pydantic `model_json_schema()` and `$schema` | not emitted; the 2020-12 dialect is implicit | run in workspace |
| SSE frame-forgery attempt | a payload containing `\n\nevent: done\ndata: {}\n\n` encodes to **one** frame and parses back as one event | `atlas/api/sse.py` |
| CRLF shell script | `./crlf.sh: not found`, exit 127; `file` reports `with CRLF line terminators`; a sourced script gives `line 2: $'ls\r': command not found` | run in workspace |
| CRLF `.env` value | `Settings.model` becomes `'gemma4:12b\r'`, length 11, and prints identically to the correct value | run in workspace |

### Corrections made to this appendix after review (2026-09-14)

| Was published | Is | How it was found |
|---|---|---|
| A.7.3 said *"Atlas's front end closes the stream on a `done` event"* | **Wrong.** `atlas/api/static/console.html` renders `done` as a summary line; its read loop ends when the HTTP body ends (`const {value, done} = await reader.read(); if(done) break;` — a different `done`). The exercise now sends the reader to that file, and the injection payload forges an `approval` frame, which the console renders with Approve and Decline buttons | the file was never opened before the claim was written; opened during review |
| A.6 said `strict_json_schema` is *"thirteen lines"* | **24 non-blank lines** including its docstring; the quoted excerpt is 3 | counted with a script |
| Compose format supersession, and Pydantic's default schema dialect, stated in prose | moved to rows in this delta; prose now points here | volatile-facts rule audit |
| 10 of 43 canonical links never search-verified | all verified; one replaced, two added | link audit |
| No concept checks, no "Your turn" prompts, no "With an assistant" note; Misconception callouts in 4 sections of 8 | 16 concept checks, 8 "Your turn" prompts, an assistant note at A.0.2, Misconception callouts in all 8 | audit against Block A's retained pedagogy |
| NDJSON, DrvFs, tmpfs and OTLP used undefined | defined at first use | "define every term on first use" |

### Finding in the shipped repository

| Fact | Value | Source | Checked |
|---|---|---|---|
| Image pinning in `deploy/docker-compose.yml` | `cr.jaegertracing.io/jaegertracing/jaeger:2.20.0` is a pinned tag; **`ollama/ollama:latest` is floating**, which is weaker than the advice `deploy/Dockerfile` gives in its own first comment. Not a defect in anything this appendix teaches; worth pinning in your copy | parsed from the archive | 2026-09-14 |

### Known-unverified in this appendix (do not treat as checked)

| Claim | Why it is unverified | What to do |
|---|---|---|
| Every Docker and Docker Desktop behaviour in A.5 and A.8 | Docker is absent from the authoring container: `docker version` → command not found, the same condition Phases 14 and 15 recorded | Run `docker compose config`, then `docker inspect`, on your own machine |
| Every Windows- and WSL-specific row in A.8 not marked **[reproduced]** | No Windows machine was available; rows are taken from Microsoft's own documentation or from issue reports | Reproduce on your machine and correct the row in your own VERSIONS.md |
| All Playwright rows | Playwright is not a dependency of Atlas and was not installed; error text is quoted from upstream issue reports, which are secondary | Run `playwright install-deps` on your target distro before relying on the fix |
| Ollama's behaviour across the WSL boundary | Not exercised; no runner and no Windows host | Test with `curl http://localhost:11434/api/tags` from inside WSL before assuming either fix |

---

**End of Appendix A.** Solutions to all twenty-four exercises are in `appendix_a_solutions.md`.
