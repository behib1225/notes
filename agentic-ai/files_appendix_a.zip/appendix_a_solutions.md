# appendix_a_solutions.md

**Solutions to Appendix A — Prerequisite Remediation**

Part 1 answers the sixteen **concept checks** and the eight **Your turn** prompts that sit inside the appendix prose. Part 2 works the twenty-four end-of-section **exercises** in order.

Every command and every output here was run against `atlas_phase_16.zip` (or `atlas_phase_04.zip` where stated) unzipped into a working directory, with Python 3.12.3, `pydantic 2.13.5` and `pytest 9.1.1`. Run everything from the snapshot root with `PYTHONPATH=.` set, or after `pip install -e .`.

Where your numbers differ from mine, the timings are the ones allowed to differ. The row counts, schema shapes and error types are not.

---

# Part 1 — In-text checks

## A.1 asyncio

**Concept check 1.1.** `results` holds five **coroutine objects**, not five integers. The line takes microseconds, because nothing ran: no sleep happened and no multiplication happened. When those five objects are garbage collected Python prints, to stderr, five copies of `RuntimeWarning: coroutine 'fetch' was never awaited`. The warning may arrive much later than the line that caused it, which is why the symptom people report is "my results are empty" rather than "I forgot an await."

**Concept check 1.2.** `timeout_s` catches a *single branch that hangs*: one document server stops responding, that branch is recorded as `kind="timeout"` after its own allowance, and its three healthy siblings keep their results. A whole-fan-out `deadline_s` would not distinguish which branch was at fault and would arrive only after the total budget was gone. `deadline_s` catches the case `timeout_s` cannot: *many branches each finishing just inside their allowance*. Twenty branches at 9 seconds each with a 10-second per-branch timeout never trip a timeout and can still take three minutes. One bounds a call, the other bounds a request; they are not substitutes, and `gather_bounded`'s docstring says so.

**Your turn.** `ok`, `error`, `cancelled`. The empty string is a perfectly good payload — `_run_one` never inspects the value, so falsiness is not failure. `KeyError` is caught by the broad `except Exception` and converted to a value with `error="KeyError: 'sku'"`. Cancellation re-raises out of `_run_one` and is recorded as `kind="cancelled"` by the `fail_fast` branch of the caller, which is the difference between "we stopped it" and "it never happened."

## A.2 Pydantic v2

**Concept check 2.1.** `x: str | None = None` is the one that lets the model omit the key. The list that changes is **`required`**: with no default, `x` appears in it; with a default, it does not. Both forms accept `null` as a value — that comes from the *type*, not the default. This is why Atlas writes `clarifying_question: str | None = Field(description=...)` with no default: the model must emit the key, and may emit null, so "answerable" and "forgot to answer" stay distinguishable.

**Concept check 2.2.** With `extra="forbid"` (the Atlas setting) you get `ValidationError`, one error, `type="extra_forbidden"`, `loc=("confidence",)`. Without it Pydantic silently drops `confidence` and hands you a clean-looking object. You would rather be debugging the first. A loud failure names the field and the file; a silent drop produces a system that has been discarding a field the model has been emitting for weeks, and the only evidence is that some downstream number is subtly wrong.

**Your turn.** Two errors, both `string_type`, at `('entities', 0)` and `('entities', 1)`. The `loc` tuple carries the **list index**, not just the field name — which is what lets an error message say "element 0 of entities" rather than "entities is wrong." Note also what did *not* happen: Pydantic's lax mode coerces `"3"` to `3`, but it does not coerce `1` to `"1"`. Coercion is not symmetric, and guessing which direction works is how people get surprised.

## A.3 pytest

**Concept check 3.1.** pytest imports `conftest.py` automatically for every test in its directory and below, and registers the fixtures it defines; the name is the mechanism. Rename it to `fixtures.py` and pytest stops looking at it, every test naming `load_fixture` or `dict_cache` fails at collection with `fixture 'load_fixture' not found`, and adding an `import fixtures` line does not help — the decorator has to run during pytest's own collection for the fixture to be registered.

**Concept check 3.2.** Exit code 5 means **no tests were collected**. In Atlas that is the normal state of a hidden test file for an assignment the student has not started: the file skips itself, nothing is collected, and pytest exits 5. Reporting that as a failure tells a student their code is broken when they have not written any code, and sends them looking for a bug in a module that does not exist yet. The `Makefile` therefore prints "No Phase NN hidden tests ran" instead.

**Your turn.**

```python
@pytest.mark.parametrize("n,expected", [(1, 2), (2, 4), (3, 6)])
```

The part people get wrong is the first argument: it is **one string containing comma-separated names**, not a list of strings and not a tuple. `parametrize(["n", "expected"], ...)` also works but is rarer in the wild; `parametrize("n", "expected", ...)` is a `TypeError`.

## A.4 SQL

**Concept check 4.1.** SQLite **accepts it.** Verified on the seeded database, the query returns one row per region and `quarter` holds `'2025Q3'` for every one of them — a value picked from some arbitrary row in each group. Being accepted is worse than being rejected because there is no error to notice: a report ships with a quarter column that is real-looking, consistent, and meaningless. PostgreSQL rejects the same query outright. When you move a query between engines, this is the class of difference that bites.

**Concept check 4.2.** If the guard had a hole, **`mode=ro&immutable=1` still protects the database** — the refusal comes from SQLite's own C code and does not depend on your whitelist being complete. The guard is the one that gives a model something to act on: `only SELECT and WITH queries are allowed; this one starts with 'UPDATE'` names the problem and the fix, where `attempt to write a readonly database` only says the world is wrong. Layer 1 exists for the message; layer 2 exists for the guarantee.

**Your turn.** **64.** One row per shipment, because every shipment matches exactly one product. Not 4 × 64 (that is a cross join, which is what you get if you forget the `ON` clause) and not 4 + 64 (which is not a thing any join does). A join's row count is the number of matching *pairs*; the sizes of the two tables only bound it.

## A.5 Docker and Compose

**Concept check 5.1.** `RUN` executes when the **image is built**, and its result is baked into a layer. `CMD` is the default command executed when a **container starts**, and it runs nothing at build time. Writing `RUN uvicorn ...` starts a web server during the build, which never returns, so the build hangs until it is killed — and even if it did return, nothing would have been saved, because a running process is not a filesystem change.

**Concept check 5.2.** Editing `requirements.txt` invalidates `COPY requirements.txt`, so that and everything below it re-runs: the `pip install`, both source copies, and the trailing configuration. That is the expensive case, and it is correct — the dependencies genuinely changed. Editing `atlas/schemas.py` invalidates only `COPY atlas /app/atlas` and below; `FROM`, `useradd`, `WORKDIR`, the requirements copy and the `pip install` all come from cache. Getting the second case cheap is the entire reason the two `COPY` lines are separated.

**Your turn.** It would need the Windows host's address rather than a name — under WSL2's mirrored networking `http://localhost:11434` may work from the distro, but from inside a *container* you need the host gateway, conventionally `http://host.docker.internal:11434` on Docker Desktop. `localhost` is wrong in both arrangements for two different reasons: inside a container `localhost` is that container's own loopback and nothing is listening there; inside WSL under default NAT networking `localhost` is the distro's loopback, not Windows'. Same word, two different wrong answers. `# not executed during authoring; verified by the author on the target platform`

## A.6 JSON Schema

**Concept check 6.1.** `{"city": "Lisbon", "days": null}` is **invalid** — `days` is declared `{"type": "integer"}`, and `null` is not an integer. Absence and null are different things, and only absence is permitted here. `{"city": "Lisbon"}` is **valid**, because `days` is not in `required`. `{"city": "Lisbon", "days": 0}` is **invalid**, because `minimum: 1` excludes it. Three different mechanisms, which is why the exercise asks for three answers.

**Concept check 6.2.** `additionalProperties: false` travels to the *model*: it is part of the document a constrained decoder reads, and it is what stops the tokens from ever forming an unlisted key. `ConfigDict(extra="forbid")` cannot do that, because Pydantic is not in the room while the model is generating. Conversely `extra="forbid"` makes *Pydantic* raise when an unlisted key arrives anyway — from a best-effort backend, a cache, a replayed fixture — and the schema flag cannot do that, because a schema is a document and does not execute. Two switches, two audiences.

**Your turn.** Remove the default and keep the union:

```python
days: int | None = Field(ge=1, description="How many days ahead, at least 1. Null if the user did not say.")
```

With no Python default, `days` joins `required`; with `int | None` it may still be `null`. That is the option that keeps "the model declined" distinguishable from "the model forgot" — the alternative, `Field(default=None)`, drops it out of `required` and collapses the two cases. Note the description now tells the model when null is the right answer, which is the cheap half of making this work.

## A.7 HTTP, SSE, and streaming

**Concept check 7.1.** `is_retryable_status(200)` returns `False`, and it is **not wrong** — it was asked whether the status code justifies sending the request again, and a 200 does not. The malformed body is a *parsing* failure, and it belongs to `parse_ollama_chat` / `extract_json_object` and the structured-output repair path, not to the transport. Atlas keeps them apart deliberately: transport decisions live in `_post_with_retry`, parse decisions live in pure functions that a test can drive from a JSON file. Merging them would mean you could not test either without a server.

**Concept check 7.2.** You send comment frames so the connection does not look idle. Proxies and load balancers close connections with no traffic, and an agent that is thinking for forty seconds produces exactly no traffic. A comment every fifteen seconds keeps the socket warm, is ignored by `EventSource` by specification, and doubles as the cheapest possible liveness signal for a human watching a spinner. Without it, long turns die at the proxy and the user sees a connection error with no server-side trace of anything going wrong.

**Your turn.** `parse_sse` on that string returns **one event**, `('token', 3)`. It splits on `"\n\n"`, and a final block with no trailing delimiter is still a block as far as `str.split` is concerned. A browser reading the same bytes off a live socket displays **nothing at all**: `EventSource` dispatches only on the blank line, so it holds the frame in its buffer indefinitely, waiting for a terminator that has not been sent yet. A test on `parse_sse` therefore passes on a stream that hangs a browser, which is why `atlas/api/sse.py` always appends `"\n\n"` in the encoder rather than relying on the caller.

## A.8 Windows and WSL

**Concept check 8.1.** First, the change needs `wsl --shutdown` from PowerShell and a restart of the distro; reopening a terminal reattaches to the same running VM and changes nothing. Second — the reason that is not "you edited it wrong" — you may have edited the wrong file: `%USERPROFILE%\.wslconfig` on Windows configures the WSL2 *virtual machine* (memory, processors, networking mode) and `/etc/wsl.conf` inside the distro configures *that distro* (mount options, PATH interop). Putting `networkingMode=mirrored` in `/etc/wsl.conf` is silently ignored.

**Concept check 8.2.** Print `repr()` and `len()`. You are looking for an invisible character — a trailing `\r` from a CRLF `.env`, or a trailing space from a copy-paste. `'gemma4:12b\r'` has length 11 and prints identically to the correct ten-character value in every terminal, and `echo` cannot show you the difference. This is the single highest-yield habit in the whole appendix: when a string comparison fails for no visible reason, stop looking at the string and start looking at its bytes.

**Your turn.** If `file Makefile` says `with CRLF line terminators`, run `sed -i 's/\r$//' Makefile` and then set your editor to write LF for this project — otherwise the next save puts them back. `make` is stricter about whitespace than almost any other tool, and a CRLF `Makefile` fails with parse errors that name a line number and nothing useful about the cause.

---

# Part 2 — Exercises

---

## A.1 asyncio

### A.1.1 — coroutine objects, and what `gather` buys

```python
import asyncio, time

async def fetch(n: int) -> int:
    await asyncio.sleep(0.2)
    return n * 2

c = fetch(1)
print(type(c).__name__, repr(c)[:45])
c.close()                       # suppresses the "never awaited" warning

async def main() -> None:
    t0 = time.perf_counter()
    [await fetch(i) for i in range(5)]
    seq = time.perf_counter() - t0

    t0 = time.perf_counter()
    await asyncio.gather(*(fetch(i) for i in range(5)))
    par = time.perf_counter() - t0
    print(f"sequential {seq:.2f}s  concurrent {par:.2f}s")

asyncio.run(main())
```

```
coroutine <coroutine object fetch at 0x7f18cdbdd840>
sequential 1.00s  concurrent 0.20s
```

`fetch(1)` returns a **coroutine object**. Nothing ran: no sleep happened, no value was produced. The object is a description of work, and it stays inert until something awaits it or hands it to the loop.

The timings are the whole point of the section. Five 0.2-second waits awaited one after another cost 1.00 s, because each `await` finishes before the next begins. The same five under `gather` cost 0.20 s, because all five waits overlap. The CPU did the same negligible amount of work either way — only the waiting was shared.

If you predicted 0.04 s for the concurrent case (0.2 ÷ 5), that is the CPU-bound intuition talking. Concurrency does not divide a wait; it overlaps waits. The floor is the longest single wait, not the total divided by the count.

### A.1.2 — the semaphore, and why order is stable

```python
import asyncio
from atlas.flow.parallel import Branch, gather_bounded

async def work(name: str) -> str:
    await asyncio.sleep(0.1)
    return name

def branches():
    return [Branch(name=n, make=(lambda n=n: work(n))) for n in ("a", "b", "c", "d")]

async def main() -> None:
    for limit in (1, 2, 4):
        r = await gather_bounded(branches(), limit=limit)
        print(f"limit={limit}  wall={r.wall_clock_s:.2f}s  "
              f"order={[b.name for b in r.branches]}")

asyncio.run(main())
```

```
limit=1  wall=0.40s  order=['a', 'b', 'c', 'd']
limit=2  wall=0.20s  order=['a', 'b', 'c', 'd']
limit=4  wall=0.10s  order=['a', 'b', 'c', 'd']
```

**Why the timings differ.** `limit` is the size of the `asyncio.Semaphore` that `_run_one` acquires before doing anything. At `limit=1` the four branches run strictly one at a time, so the wall clock is four sleeps. At `limit=2` they run in two waves. At `limit=4` all four overlap and the wall clock is one sleep.

**Why the order does not.** `gather_bounded` builds `tasks` as a list comprehension over `branches` and either `gather`s that list or, in `fail_fast` mode, reassembles results into the original sequence by name. `asyncio.gather` returns results in *argument* order regardless of which coroutine finished first, and Atlas documents that in the return clause: *"A `FanoutResult` with one entry per branch, **in argument order**."* That is what lets a caller zip results back against the inputs that produced them without carrying correlation ids.

One trap in writing this exercise: the `lambda n=n:` default-argument binding. Writing `lambda: work(n)` would give all four branches the last value of `n`, because the closure captures the variable, not its value. Using a factory at all is deliberate — `Branch`'s docstring explains that `make` returns a *fresh* awaitable each call, because a coroutine object can only be awaited once and storing one would make the branch un-retryable.

### A.1.3 — swallowing `CancelledError` disables the timeout

```python
import asyncio, time

async def stubborn_bad() -> str:
    try:
        await asyncio.sleep(5)
    except asyncio.CancelledError:
        print("  stubborn_bad: swallowed the cancellation")
        return "I finished anyway"
    return "slept the full five"

async def stubborn_good() -> str:
    try:
        await asyncio.sleep(5)
    except asyncio.CancelledError:
        print("  stubborn_good: cleaning up, then re-raising")
        raise
    return "slept the full five"

async def run(coro_fn, label: str) -> None:
    t0 = time.perf_counter()
    try:
        async with asyncio.timeout(0.2):
            out = await coro_fn()
        print(f"{label}: NO TimeoutError; returned {out!r} after {time.perf_counter()-t0:.2f}s")
    except TimeoutError:
        print(f"{label}: TimeoutError raised after {time.perf_counter()-t0:.2f}s")

async def main() -> None:
    await run(stubborn_bad, "bad ")
    await run(stubborn_good, "good")

asyncio.run(main())
```

```
  stubborn_bad: swallowed the cancellation
bad : NO TimeoutError; returned 'I finished anyway' after 0.20s
  stubborn_good: cleaning up, then re-raising
good: TimeoutError raised after 0.20s
```

**What the first version did.** `asyncio.timeout` does not have a separate mechanism for stopping work. When the deadline passes it *cancels the task*, which means raising `CancelledError` inside the coroutine, and then it converts that cancellation into `TimeoutError` at the `async with` boundary. Swallow the `CancelledError` and there is nothing left for the context manager to convert: the coroutine returns a perfectly ordinary value, the `async with` block exits normally, and **no `TimeoutError` is raised at all**.

That is worse than a timeout that fails to fire. A timeout that fired late would at least be visible. This one is silent: the caller believes the work completed inside the budget, and the value it received is a value the coroutine invented on its way out.

The fixed version re-raises, and the timeout behaves. This is precisely why `atlas/flow/parallel.py` puts

```python
        except asyncio.CancelledError:
            raise
```

*above* the `except TimeoutError` and `except Exception` clauses, with a docstring saying *"a task that refuses to be cancelled cannot be cancelled."* Order matters: `CancelledError` inherits from `BaseException` rather than `Exception`, so a bare `except Exception` will not catch it — but `except BaseException` or a bare `except:` will, and either would break `fail_fast` and the whole-workflow deadline.

---

## A.2 Pydantic v2

### A.2.1 — four inputs, three error types

```python
from atlas.schemas import TaskUnderstanding
from pydantic import ValidationError

base = dict(intent="lookup", entities=["support"],
            needs_tools=True, clarifying_question=None)

def show(label, **over):
    try:
        m = TaskUnderstanding(**{**base, **over})
        print(f"{label:24} OK   -> {m.model_dump()}")
    except ValidationError as exc:
        print(f"{label:24} FAIL -> {[(e['type'], e['loc']) for e in exc.errors()]}")

show('needs_tools="yes"',   needs_tools="yes")
show('needs_tools="maybe"', needs_tools="maybe")
show('entities="support"',  entities="support")
show('intent="LOOKUP"',     intent="LOOKUP")
```

```
needs_tools="yes"        OK   -> {'intent': 'lookup', 'entities': ['support'], 'needs_tools': True, 'clarifying_question': None}
needs_tools="maybe"      FAIL -> [('bool_parsing', ('needs_tools',))]
entities="support"       FAIL -> [('list_type', ('entities',))]
intent="LOOKUP"          FAIL -> [('literal_error', ('intent',))]
```

`"yes"` is accepted and coerced to `True` — lax mode recognises a fixed set of boolean-ish strings. `"maybe"` is not in that set, so you get `bool_parsing`. A bare string is not coerced to a one-element list, which is a deliberate and good decision: `list_type` catches a model that returned `"support"` where the schema said array.

`literal_error` on `"LOOKUP"` is worth dwelling on. Pydantic does not case-fold a `Literal`. The model must emit exactly one of the six lowercase strings, which is the behaviour you want when the same `Literal` is also the JSON Schema `enum` constraining generation — a case-insensitive validator would silently accept output the constrained decoder could never have produced, hiding the fact that constraint had stopped working.

Each `loc` is a tuple naming the field, which is what lets Atlas hand the model a complaint about a specific field rather than a traceback.

### A.2.2 — the two switches, seen from the outside

```python
import json
from typing import Literal
from pydantic import BaseModel, ValidationError
from atlas.schemas import RouteDraft

print(json.dumps({k: v for k, v in RouteDraft.model_json_schema().items()
                  if k != "description"}, indent=2))

class LooseRoute(BaseModel):                       # no extra="forbid"
    route: Literal["chat", "document", "data", "research", "tool_action"]
    confidence: float
    why: str

payload = {"route": "data", "confidence": 0.8,
           "why": "asks for units", "handler": "shell"}

print("loose accepted; fields kept:", LooseRoute.model_validate(payload).model_dump())
try:
    RouteDraft.model_validate(payload)
except ValidationError as exc:
    print("strict rejected:", [(e["type"], e["loc"]) for e in exc.errors()])
```

Abridged schema, and the two outcomes:

```
  "additionalProperties": false,
  "route": { "enum": ["chat","document","data","research","tool_action"], "type": "string", ... }
  "required": ["route", "confidence", "why"]

loose accepted; fields kept: {'route': 'data', 'confidence': 0.8, 'why': 'asks for units'}
strict rejected: [('extra_forbidden', ('handler',))]
```

**The three contributions.** The `Literal` became an `enum`, which a constrained decoder can enforce. `ConfigDict(extra="forbid")` became `"additionalProperties": false` at the top level. And all three fields are in `required`, because none of them has a Python default — Atlas's rule that optionality lives in the type, never in a default.

**What the difference means.** The loose model accepted the payload and returned a clean-looking object with `handler` silently gone. Nothing raised, nothing logged, and if a model had started emitting a `handler` field because some prompt edit invited it, you would find out from a support ticket rather than from a validator. The strict model raises `extra_forbidden` naming the exact key.

`RouteDraft`'s own docstring explains why this schema in particular has no field that could name code: *"a field that can name a tool, a module, or a step ... is a control-flow decision that has left the code review."* `extra="forbid"` is what stops the model adding one anyway.

### A.2.3 — `computed_field` versus a bare property

```python
from pydantic import BaseModel, computed_field
from atlas.flow.parallel import BranchResult

b = BranchResult(name="docs", kind="ok", payload="x",
                 prompt_tokens=120, completion_tokens=30)
print("declared fields:", sorted(BranchResult.model_fields))
print("dumped keys:    ", sorted(b.model_dump()))

class WithProperty(BaseModel):
    prompt: int
    completion: int
    @property
    def total(self) -> int:
        return self.prompt + self.completion

class WithComputed(BaseModel):
    prompt: int
    completion: int
    @computed_field  # type: ignore[prop-decorator]
    @property
    def total(self) -> int:
        return self.prompt + self.completion
```

```
declared fields: ['completion_tokens', 'error', 'kind', 'latency_s', 'name', 'payload', 'prompt_tokens']
dumped keys:     ['completion_tokens', 'error', 'kind', 'latency_s', 'name', 'ok', 'payload', 'prompt_tokens', 'total_tokens']

property  -> attribute 3 | dump {'prompt': 1, 'completion': 2} | json {"prompt":1,"completion":2}
computed  -> attribute 3 | dump {'prompt': 1, 'completion': 2, 'total': 3} | json {"prompt":1,"completion":2,"total":3}
a check reading record['total'] would raise: KeyError 'total'
```

`ok` and `total_tokens` are not declared fields and are in the dump, because both carry `@computed_field` in `atlas/flow/parallel.py`. The minimal pair shows the rule cleanly: both classes expose `.total` as an attribute with the same value; only the `computed_field` version survives serialisation, in `model_dump()` and in `model_dump_json()` alike.

**Why the silent version is worse than a crash.** An eval check that reads `trial["total_tokens"]` out of a serialised record is running against a dict, not against the model object. With a bare property the key is absent, so the check either raises `KeyError` inside the harness — where it looks like a harness bug, not a schema bug — or, if the harness is defensive and uses `.get()`, reads `None` and grades the trial against a missing value. In the second case the suite goes green while measuring nothing.

This is not hypothetical. Atlas's `VERSIONS.md` carries a Phase 1 revision row recording exactly this: `Trajectory` token totals were bare properties, they were absent from `model_dump()`, and two Phase 1 eval checks named them. The fix was `computed_field`, and the general rule it produced is invariant 11 — anything a check can name must survive `model_dump()`.

---

## A.3 pytest

### A.3.1 — discovery, and where the extra tests come from

```
$ python -m pytest tests/test_config.py --collect-only -q
12 tests collected in 0.05s

$ python -m pytest tests/test_llm_client.py -q -k retry --collect-only
tests/test_llm_client.py::test_retryable_statuses[408]
tests/test_llm_client.py::test_retryable_statuses[429]
...
tests/test_llm_client.py::test_retry_after_seconds[headers0-2.0]
...
tests/test_llm_client.py::test_retry_after_ignores_headers_whose_units_are_unverified
20/105 tests collected (85 deselected) in 0.20s

$ grep -n "def test_.*retry" tests/test_llm_client.py
192:def test_retryable_statuses(status):
197:def test_non_retryable_statuses(status):
223:def test_retry_after_seconds(headers, expected):
632:def test_retry_after_ignores_headers_whose_units_are_unverified():
```

Four function definitions, twenty collected tests. `@pytest.mark.parametrize` expands one function into one test *per case* at collection time: six status codes, six more, seven header shapes, plus one unparametrized test. Each gets its own node id, its own pass/fail line, and its own entry in the summary, which is why a failure tells you `test_retry_after_seconds[headers3-None]` rather than "something in the retry tests."

Note how pytest names the cases. Scalars go in literally (`[408]`); dict arguments cannot be rendered readably, so they become positional (`headers0`, `headers1`). If you want better names, `parametrize(..., ids=[...])` takes them.

Running a single test:

```
$ python -m pytest "tests/test_llm_client.py::test_retry_after_seconds[headers2-1.5]" -q
```

Quote it — the square brackets are shell glob characters.

### A.3.2 and A.3.3 — `tests/test_appendix_a.py`

Both exercises live in one file. Run with `ATLAS_TIER=F python -m pytest tests/test_appendix_a.py -q`.

```python
"""Appendix A exercises A.3.2 and A.3.3. Offline, deterministic, free."""
from __future__ import annotations

import os

import pytest

from atlas.config import Settings
from atlas.tools.sql import is_read_only_sql


# --- A.3.2 ----------------------------------------------------------------
@pytest.mark.parametrize(
    "sql,ok,fragment",
    [
        ("SELECT 1", True, "ok"),
        ("select region from v_shipments", True, "ok"),
        ("WITH t AS (SELECT 1) SELECT * FROM t", True, "ok"),
        ("DELETE FROM shipment", False, "only SELECT and WITH"),
        ("SELECT 1; DELETE FROM shipment", False, "only one statement"),
        ("PRAGMA table_info(product)", False, "'PRAGMA'"),
        ("", False, "empty"),
        ("SELECT 1; /* hi */ DELETE FROM shipment", False, "only one statement"),
    ],
)
def test_read_only_guard(sql, ok, fragment):
    got_ok, reason = is_read_only_sql(sql)
    assert got_ok is ok
    assert fragment in reason


# --- A.3.3 ----------------------------------------------------------------
@pytest.fixture
def env_file(tmp_path):
    """A two-line .env-shaped file, and the directory it lives in."""
    path = tmp_path / ".env"
    path.write_text("ATLAS_TIER=A\nATLAS_MODEL=model-from-versions-md\n",
                    encoding="utf-8")
    return path


def test_settings_reads_the_real_environment(monkeypatch, tmp_path, env_file):
    values = dict(
        line.split("=", 1) for line in env_file.read_text().splitlines() if line
    )
    for name, value in values.items():
        monkeypatch.setenv(name, value)
    monkeypatch.setenv("ATLAS_DATA_DIR", str(tmp_path))

    settings = Settings.from_env()  # no argument: reads os.environ

    assert settings.tier == "A"
    assert settings.model == "model-from-versions-md"
    assert settings.data_dir == tmp_path


def test_monkeypatch_undid_every_change():
    # ATLAS_TIER is deliberately NOT checked: `make test-offline` exports
    # ATLAS_TIER=F for the whole run, so monkeypatch correctly RESTORES it
    # rather than removing it. Asserting its absence fails for the right
    # reason, which is worth seeing once.
    for name in ("ATLAS_MODEL", "ATLAS_DATA_DIR"):
        assert name not in os.environ, f"{name} leaked out of the previous test"
```

```
10 passed in 0.06s
```

Two notes on the assertions in A.3.2. `assert got_ok is ok` uses `is`, not `==`, because `is_read_only_sql` returns a real `bool` and `1 == True` in Python — `is` catches a refactor that starts returning truthy integers. And asserting a fragment of the *reason*, not just the boolean, is what keeps the messages useful: a guard that refuses everything with the text "error" would pass a type-only test and be worthless to a model trying to fix its query.

**A.3.3 has a deliberate trap, and I walked into it while writing this.** My first version asserted that all three of `ATLAS_TIER`, `ATLAS_MODEL` and `ATLAS_DATA_DIR` were absent afterwards, and it failed:

```
FAILED tests/test_appendix_a.py::test_monkeypatch_undid_every_change
```

`monkeypatch` does not *delete* variables at teardown; it **restores the previous value**. `make test-offline` exports `ATLAS_TIER=F` for the whole run, so `ATLAS_TIER` was set before the test, was temporarily `A` during it, and went back to `F` afterwards. That is monkeypatch working exactly as documented. The two variables that genuinely did not exist before are removed.

**What the second test is actually testing.** Not `Settings`, and not really `monkeypatch` either — it is testing *the first test's hygiene*. It asserts that a test which manipulated global state left none of it behind for whatever runs next. If you had instead written `os.environ["ATLAS_MODEL"] = ...` inside a fixture with no teardown, the first test would still pass, this one would fail, and without this one you would have a suite whose results depend on file ordering — the kind of bug that appears only when someone adds a test in the middle and something unrelated starts failing.

---

## A.4 SQL

### A.4.1 — counting a join before you run it

```python
import sqlite3
c = sqlite3.connect("file:data/atlas.db?mode=ro", uri=True)
q = lambda s: c.execute(s).fetchall()
```

```
product         4
warranty_claim  43
per-sku, 2025Q4 [('P900', 6), ('S200', 2), ('T100', 4)]
INNER rows      12
LEFT rows       13
```

**The prediction.** Three of the four products have claims in 2025Q4: 6 + 2 + 4 = **12 matching pairs**, which is the `INNER JOIN` count. The `LEFT JOIN` keeps every product row regardless, so the one product with no claims that quarter contributes exactly one extra row with all the `warranty_claim` columns null: **13**.

The product accounting for the difference is **S400**, the benchtop spectrometer. It has 8 claims in the table overall but none in 2025Q4.

Note the general shape: a join's row count is the number of matching *pairs*, not a function of either table's size. Four products and 43 claims produced 12 rows, and there is no arithmetic on 4 and 43 that predicts it.

### A.4.2 — grouping, and the `NULL` that is not zero

```
group by : [('north', 377), ('east', 373), ('south', 328), ('west', 320)]
having   : []
sum empty: [(None,)]
cnt empty: [(0,)]
coalesce : [(0, 0)]
```

```sql
SELECT region, sum(units) AS u FROM v_shipments GROUP BY region ORDER BY u DESC;
SELECT region, sum(units) AS u FROM v_shipments GROUP BY region HAVING sum(units) > 1000;
```

**The `HAVING` result.** Empty, and that is correct: the largest region total is 377, so no group clears 1,000. `HAVING` filters *groups* after aggregation, which is why `sum(units) > 1000` is legal there and illegal in `WHERE` — at `WHERE` time the groups do not exist yet. An empty result from `HAVING` is the normal way to say "no group qualified," and it is different from an error.

**The dangerous pair.** `sum(units)` over a filter matching nothing returns **one row containing `NULL`**; `count(*)` over the same filter returns **one row containing `0`**. Both queries "succeed" and both return exactly one row.

An agent that renders the first naively tells the user something false. Formatted through Atlas's `format_rows`, `NULL` becomes the literal string `NULL` and a model summarising it will reach for whatever reading fits the question — most often "zero units shipped to Mars," which asserts a fact about Mars that the database does not contain. The truthful answer is "there is no region called Mars in this data." The two are different claims, and the difference is precisely the difference between `sum` and `count` over an empty set.

This is why Phase 7 builds a `no_rows_matched` sanity check that consults both aggregates rather than collapsing them. `coalesce(sum(units), 0)` is the right fix *only* when you have independently established that zero is the true answer; used blindly it converts "no such region" into "zero units" and destroys the very distinction the check exists to preserve.

### A.4.3 — the `WHERE` trap, and two layers of refusal

```sql
-- correct: predicate in ON, LEFT JOIN
SELECT p.sku, count(w.id) AS claims
FROM product p
LEFT JOIN warranty_claim w ON w.sku = p.sku AND w.quarter = '2025Q4'
GROUP BY p.sku ORDER BY p.sku;
```
```
[('P900', 6), ('S200', 2), ('S400', 0), ('T100', 4)]
```

```sql
-- INNER JOIN: S400 vanishes
[('P900', 6), ('S200', 2), ('T100', 4)]

-- LEFT JOIN with the predicate moved to WHERE: S400 vanishes again
[('P900', 6), ('S200', 2), ('T100', 4)]
```

The third query is the trap. `LEFT JOIN` dutifully produced a row for S400 with every `warranty_claim` column null, and then `WHERE w.quarter = '2025Q4'` evaluated `NULL = '2025Q4'`, which is not true, and discarded it. The `LEFT` was silently downgraded to an `INNER`. Two of these three queries answer a question nobody asked, and all three look reasonable in a code review.

Note also `count(w.id)` rather than `count(*)`. `count(*)` counts joined rows, so S400's single all-null row would have counted as 1, turning a correct zero into a wrong one.

Now the tool and the two layers:

```python
from atlas.tools.sql import make_sql_tool
tool = make_sql_tool("data/atlas_query.db")
print(tool(sql="SELECT region, sum(units) AS u FROM v_shipments GROUP BY region ORDER BY u DESC"))
```
```
region | u
----------
north | 377
east | 373
south | 328
west | 320
(4 rows)
```

Layer 1, the statement guard:

```
>>> tool(sql="UPDATE v_shipments SET units = 0")
ValueError: only SELECT and WITH queries are allowed; this one starts with
'UPDATE'. The database is read-only.
```

Layer 2, the engine, reached by bypassing the guard entirely:

```python
conn = sqlite3.connect("file:data/atlas_query.db?mode=ro&immutable=1", uri=True)
conn.execute("CREATE TABLE x (a)")
```
```
sqlite3.OperationalError: attempt to write a readonly database
```

**Which one would you rather rely on.** Layer 2, without hesitation. It is enforced by SQLite's own C code, it has been read and attacked by orders of magnitude more people than any regular expression you will write, and its completeness does not depend on your having thought of `ATTACH` or `PRAGMA` or whatever the next construct turns out to be. The module docstring says as much and says it about its own work: *"It is pure, it is tested, and I do not trust it. SQL is a large language, my whitelist is small, and a validator whose completeness is the only thing between a model and a `DELETE` is a validator that will eventually be wrong."*

**So why keep layer 1.** Because the two produce different *messages*, and the message is an input to the next model step. `attempt to write a readonly database` tells the model that something is wrong with the world; `only SELECT and WITH queries are allowed; this one starts with 'UPDATE'. The database is read-only.` tells it what to do differently. Layer 1 exists to produce a good error early; layer 2 exists to be correct. Deleting layer 1 costs you a recoverable agent. Deleting layer 2 costs you the guarantee.

---

## A.5 Docker and Compose

### A.5.1 — reading the Dockerfile

**(i) Editing one line of `atlas/llm.py`.** Docker invalidates the cache at the first instruction whose inputs changed, and everything below it. `FROM`, `RUN useradd`, `WORKDIR`, `COPY requirements.txt` and the `RUN pip install` are all unaffected — none of their inputs changed — so all five come from cache. `COPY atlas /app/atlas` is re-executed, and so is everything after it: `COPY data`, `USER`, `ENV`, `EXPOSE`, `HEALTHCHECK`, `CMD`. Those are cheap. The expensive layer, the dependency install, is untouched, which is the entire reason `COPY requirements.txt` sits on its own line above the source copy.

Invert the order and every one-character fix reinstalls `pydantic`, `langgraph`, `langchain`, `mcp` and `fastapi` from the network.

**(ii) Moving `USER atlas` up.** `RUN pip install --no-cache-dir -r /app/requirements.txt` would run as the unprivileged `atlas` user and fail, because it writes to the system `site-packages` directory. The build would break with a permissions error. The ordering in the file is the standard shape: do the privileged setup as root, then drop privileges for everything that runs at container start. `USER` is the last thing before the runtime configuration for exactly that reason.

**(iii) `EXPOSE 8000` and what actually publishes the port.** `EXPOSE` is documentation. It records the port the image intends to serve on, and tools can read it, but it opens nothing — a container built from this image and started with plain `docker run` is unreachable from the host. The line that publishes it is in the Compose file:

```yaml
    ports:
      - "8000:8000"
```

host port on the left, container port on the right. The second necessary condition is in `CMD`: `--host 0.0.0.0`. Binding to `127.0.0.1` inside the container would make the process reachable only from inside that container, so you would have a published port connected to a socket nothing is listening on from outside.

### A.5.2 and A.5.3 — auditing the deployment as text

One script covers both. No Docker required; it reads the files.

```python
"""A.5.2 + A.5.3: audit the deployment files as text. No Docker required."""
from __future__ import annotations

import re
import sys
from pathlib import Path

DEPLOY = Path("deploy")
COMPOSE = (DEPLOY / "docker-compose.yml").read_text(encoding="utf-8")
DOCKERFILE = (DEPLOY / "Dockerfile").read_text(encoding="utf-8")

IMAGE = re.compile(r"^\s*image:\s*(\S+)", re.M)
FROM = re.compile(r"^FROM\s+(\S+)", re.M)


def classify(ref: str) -> str:
    if "@sha256:" in ref:
        return "digest"
    last = ref.rsplit("/", 1)[-1]          # strip the registry host first
    tag = last.rsplit(":", 1)[-1] if ":" in last else None
    return "floating" if tag in (None, "latest") else "pinned tag"


def main() -> int:
    refs = IMAGE.findall(COMPOSE) + FROM.findall(DOCKERFILE)
    for ref in refs:
        print(f"  {ref:52} {classify(ref)}")

    checks: list[tuple[str, bool, str]] = [
        ("no image uses a floating tag",
         all(classify(r) != "floating" for r in refs),
         "pin a version tag, or better a digest"),
        ("the image declares a non-root USER",
         bool(re.search(r"^USER\s+(?!root\b)\S+", DOCKERFILE, re.M)),
         "add `RUN useradd ...` and `USER <name>` before CMD"),
        ("the atlas service has a read-only root filesystem",
         "read_only: true" in COMPOSE,
         "add `read_only: true` and a tmpfs for /tmp"),
        ("no service points a host variable at localhost",
         not re.search(r"ATLAS_\w*HOST:\s*\"?http://localhost", COMPOSE),
         "use the compose service name, e.g. http://ollama:11434"),
    ]
    failed = 0
    for name, ok, fix in checks:
        print(f"{'PASS' if ok else 'FAIL'}  {name}")
        if not ok:
            print(f"      fix: {fix}")
            failed += 1
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
```

```
  cr.jaegertracing.io/jaegertracing/jaeger:2.20.0      pinned tag
  ollama/ollama:latest                                 floating
  python:3.12-slim                                     pinned tag
FAIL  no image uses a floating tag
      fix: pin a version tag, or better a digest
PASS  the image declares a non-root USER
PASS  the atlas service has a read-only root filesystem
PASS  no service points a host variable at localhost
exit=1
```

Two implementation notes. `classify` strips the registry host before looking for a tag, because `cr.jaegertracing.io/...` contains no colon in the host here but a registry with a port (`localhost:5000/img`) would fool a naive `":" in ref`. And the `USER` check uses a negative lookahead so that an explicit `USER root` fails rather than passes.

**What I would change, and what it costs.** Pin `ollama/ollama` to a released version tag, and in a real deployment pin all three to digests. The cost of a digest is that you stop receiving security patches silently — every update becomes an edit, a review and a redeploy. That is the correct trade for production and an annoying one for a laptop, which is why the Dockerfile's own comment puts digests in the "production" column and the repository ships tags.

**Why grepping a Dockerfile is worth doing even though it proves nothing about a running container.** It proves something about the *intent recorded in the repository*, and intent is what drifts. A container inspected once and found to run as non-root tells you about that container; a test on the file fails the moment somebody deletes the `USER` line, in the pull request that deletes it, before anything is built. It is a cheap, fast, offline guard against a class of regression that is otherwise caught only in production. It is the same argument Atlas makes for `make check-docs`: a guard that compares an artefact to its stated intent catches drift that no runtime check is watching for.

---

## A.6 JSON Schema

### A.6.1 — hand-written versus generated

Hand-written:

```json
{
  "type": "object",
  "properties": {
    "city": {"type": "string"},
    "days": {"type": "integer", "minimum": 1}
  },
  "required": ["city"],
  "additionalProperties": false
}
```

Generated from:

```python
class Forecast(BaseModel):
    model_config = ConfigDict(extra="forbid")
    city: str = Field(description="City to forecast, as the user wrote it.")
    days: int | None = Field(default=None, ge=1,
                             description="How many days ahead, at least 1.")
```

```json
{
  "additionalProperties": false,
  "properties": {
    "city": {"description": "City to forecast, as the user wrote it.",
             "title": "City", "type": "string"},
    "days": {"anyOf": [{"minimum": 1, "type": "integer"}, {"type": "null"}],
             "default": null,
             "description": "How many days ahead, at least 1.",
             "title": "Days"}
  },
  "required": ["city"],
  "title": "Forecast",
  "type": "object"
}
```

**The differences, and there are five.**

1. **`days` is a union, not an integer.** The annotation `int | None` produced `anyOf: [integer, null]`. The hand-written version says `days` is an integer or absent; the generated one says it is an integer, or null, or absent. These accept different documents, and the generated behaviour is the one you want from a model — "I considered it and there is no answer" is expressible.
2. **`"default": null` appears.** A default in the schema is a hint to the reader and, at some providers, a reason the property may be omitted from `required`.
3. **`title` keys everywhere** — on the model and on each property. Pydantic generates them from the field names; they say nothing the property name did not, and Atlas strips them with `_strip_titles` before sending. On the two-field `Forecast`, stripping took the document from 370 to 315 characters.
4. **`description` on both properties.** Absent from mine because I did not write any. This is the field the model actually reads, and omitting it is the most common way to make a tool or schema harder to use than it needs to be.
5. **Key order and `$schema`.** The generated document is alphabetised by Pydantic's serialiser, and there is no `$schema` key: the 2020-12 dialect is implicit. Fine for a provider endpoint, not fine if you hand the document to a general-purpose validator that expects to be told which dialect to apply.

What is *the same* is the thing the exercise is really about: `required` contains `city` and not `days`, in both. Optionality is membership in that array, in every version of the spec.

### A.6.2 — the strict-mode trade

The only difference between `strict=False` and `strict=True` on `calculate`:

```
strict=False   "required": ["expression"]
strict=True    "required": ["expression", "precision"]
```

Everything else is byte-identical, including `"default": 2` on `precision`, which survives into the strict version. `additionalProperties: false` is present in *both*, because it comes from `args_model_for`'s `ConfigDict(extra="forbid")` rather than from `strict_json_schema` — the strict pass would have added it, but it was already there.

**Your two options for a genuinely optional parameter, under a provider whose strict mode requires every property in `required`.**

*Option one: make it required and keep the default in the schema.* The model must supply a value on every call, and your code still has a Python default if it somehow arrives absent. You pay a few tokens per call and you pay the risk that the model picks a worse value than your default would have been. You gain the ability to distinguish "the model chose 2" from "the model forgot the field," and you gain compatibility with constrained decoding, which is the thing actually preventing malformed calls.

*Option two: make it required and nullable* — `precision: int | None` — with `null` meaning "use the default." The model must still emit the key, but it has an explicit way to decline, and the decision remains visible in the trace. This costs an `anyOf` in the schema and a null check in the code.

**Atlas took option one**, and says so in `schema_for`'s docstring: *"The honest cost: a tool parameter with a Python default is now required in the schema, so the model must supply it every time. That is the same trade Phase 2 made for output schemas and for the same reason."* The measured behaviour of the generated schema is recorded in `VERSIONS.md` as strict-mode-legal and as what the design reasoning wanted.

### A.6.3 — recursion into `$defs`, `items` and `anyOf`

```python
from atlas.llm import strict_json_schema
from atlas.schemas import PlanDraft

s = PlanDraft.model_json_schema()
print("$defs:", list(s["$defs"]))
print("steps.items:", s["properties"]["steps"]["items"])
st = strict_json_schema(s)
print("outer required:", st["required"])
print("nested required:", st["$defs"]["PlanDraftStep"]["required"])
print("nested additionalProperties:", st["$defs"]["PlanDraftStep"]["additionalProperties"])
```

```
$defs: ['PlanDraftStep']
steps.items: {'$ref': '#/$defs/PlanDraftStep'}
outer required: ['goal', 'steps']
nested required: ['depends_on', 'description', 'expects', 'id', 'tool']
nested additionalProperties: False
```

The nested model is hoisted into `$defs` and referenced by `$ref`; `steps.items` is a pure pointer with no inline schema. `strict_json_schema` reaches the definition because its loop treats `$defs` the same as `properties` and recurses into each value.

The `anyOf` probe:

```python
hand = {
    "type": "object",
    "properties": {
        "target": {
            "anyOf": [
                {"type": "object",
                 "properties": {"sku": {"type": "string"},
                                "quarter": {"type": "string"}}},
                {"type": "null"},
            ]
        }
    },
}
```

```json
{
  "type": "object",
  "properties": {
    "target": {
      "anyOf": [
        {"type": "object",
         "properties": {"sku": {"type": "string"}, "quarter": {"type": "string"}},
         "required": ["quarter", "sku"],
         "additionalProperties": false},
        {"type": "null"}
      ]
    }
  },
  "required": ["target"],
  "additionalProperties": false
}
```

**It was reached.** The object inside the first `anyOf` branch gained both `required` and `additionalProperties: false`; the `null` branch gained neither, correctly, since it has no `properties` and the function's final block is guarded by `isinstance(out.get("properties"), dict)`.

**Is that correct for strict-mode purposes? Yes**, and it has to be. The rule those endpoints enforce is not "the root object must be closed" but "every object in the document must be closed." A union branch that is an open object is an escape hatch through which a model can emit unlisted keys while still satisfying the schema, which defeats the point. Tightening only the root would produce a document that passes a shallow inspection and fails at the endpoint, or worse, is accepted and does not constrain.

The one thing to check in your own version: `strict_json_schema` recurses into `anyOf`, `oneOf`, `allOf` and `prefixItems` as lists and into `items` as a single schema. If you write your own, those five keywords are the minimum, and `$defs` is the one people forget because nothing in a small hand-written schema uses it — until the first nested model appears.

---

## A.7 HTTP, SSE, and streaming

### A.7.1 — retry decisions

```
  200  retryable=False  success
  400  retryable=False  our request is malformed
  401  retryable=False  our credentials are wrong
  404  retryable=False  the route or model does not exist
  408  retryable=True   server-side timeout, may pass
  429  retryable=True   rate limited, may pass
  500  retryable=True   server fault, may pass
  503  retryable=True   server unavailable, may pass

  {'retry-after': '2'}               -> 2.0
  {'Retry-After': '0.5'}             -> 0.5
  {'retry-after-ms': '1500'}         -> 1.5
  {'retry-after': '-3'}              -> None
  {'retry-after': 'not-a-number'}    -> None
  {}                                 -> None
  None                               -> None

  policy: {'attempts': 3, 'base_delay_s': 0.5, 'max_delay_s': 8.0}
  ceilings: [0.5, 1.0, 2.0, 4.0, 8.0]
```

The classification is the rule from the section: `2xx` succeeded, `5xx` and the two special `4xx` codes may pass, everything else is your request being wrong and retrying it just spends budget. `404` is the one people argue about — on a model endpoint it usually means the model name is wrong, which no amount of waiting fixes.

`Retry-After` lookup is case-tolerant (`retry-after` and `Retry-After` both work) and unit-aware (`retry-after-ms` is divided by 1000).

**Why a negative value is treated as absent rather than as zero.** Returning `0.0` would be a *usable* delay, so `_post_with_retry`'s `if hinted is not None` branch would fire and retry immediately, skipping the backoff entirely. Returning `None` falls through to the exponential schedule, which is known to be sane. A server that sends `Retry-After: -3` is malfunctioning, and the safe reading of a malfunctioning instruction is "no instruction," not "go now." The same reasoning covers `not-a-number`. The function's comment records that an earlier version also read `x-ratelimit-reset`, and that it was removed because its units were never verified: *"guessing at a header's meaning is worse than ignoring it, because the fallback schedule is at least known to be sane."*

The ceilings double from `base_delay_s` and cap at `max_delay_s`. Note these are ceilings, not delays — `_post_with_retry` sleeps `full_jitter(backoff_delay(attempt, policy))`, drawing uniformly from zero to the ceiling, so that clients recovering from a shared outage do not retry in lockstep.

### A.7.2 — the blank line is the frame delimiter

```python
from atlas.api.sse import AgentEvent, encode_stream, parse_sse

events = [
    AgentEvent(kind="start", data={"request_id": "r-42"}, seq=0),
    AgentEvent(kind="plan",  data={"route": "data"},      seq=1),
    AgentEvent(kind="token", data={"text": "377 "},       seq=2),
    AgentEvent(kind="token", data={"text": "units."},     seq=3),
    AgentEvent(kind="done",  data={"tokens": 412},        seq=4),
]
wire = "".join(encode_stream(events))
print(repr(wire))
print("intact:", [(e.kind, e.seq) for e in parse_sse(wire)])

frames = wire.split("\n\n")
damaged = frames[0] + "\n" + "\n\n".join(frames[1:])   # drop ONE blank line
print("damaged:", [(e.kind, e.seq) for e in parse_sse(damaged)])
```

```
'event: start\nid: 0\ndata: {"request_id":"r-42"}\n\nevent: plan\nid: 1\ndata: {"route":"data"}\n\nevent: token\nid: 2\ndata: {"text":"377 "}\n\nevent: token\nid: 3\ndata: {"text":"units."}\n\nevent: done\nid: 4\ndata: {"tokens":412}\n\n'

intact:  [('start', 0), ('plan', 1), ('token', 2), ('token', 3), ('done', 4)]
damaged: [('plan', 1), ('token', 2), ('token', 3), ('done', 4)]   count 4
```

Removing one blank line merged the `start` and `plan` frames into a single block. `parse_sse` walks the block's lines and lets the last `event:` and `id:` and `data:` it sees win, so the `start` event is **silently swallowed** and its payload replaced by `plan`'s. Five events in, four out, and no error.

**What a browser does with that stream.** `EventSource` buffers until it sees the delimiter. With the delimiter missing it holds the first frame's bytes in memory and dispatches nothing, then dispatches the merged frame only when the *next* blank line arrives. So the `start` event — the one carrying the request id and trace id, the one a UI uses to stop showing a spinner — never fires on its own, and the first thing the user sees arrives one event late.

**Why it looks like a slow server.** Every byte was sent correctly and on time. The connection is open, the server is writing, the network is fine, and there is no error anywhere to log. From the user's side the symptom is indistinguishable from a model that is thinking, which is why this bug survives so long: the first person to investigate profiles the model. The diagnostic is to `curl -N` the endpoint and look at the raw bytes for the blank lines, which is exactly what `parse_sse` exists to let a test do without a browser.

### A.7.3 — frame injection, and the one line that prevents it

```python
from atlas.api.sse import sse_event, parse_sse

# What a user could type into a chat box, if the server writes `data: ` + text.
hostile = '{"text":"x"}\n\nevent: done\ndata: {"tokens":0}'

safe = sse_event({"text": hostile}, event="token", event_id=9)
print(repr(safe))
print("parsed:", [(e.kind, e.seq, e.terminal) for e in parse_sse(safe)])

def naive(kind, text, seq):
    return f"event: {kind}\nid: {seq}\ndata: {text}\n\n"

bad = naive("token", hostile, 9)
print(repr(bad))
print("parsed:", [(e.kind, e.seq, e.terminal) for e in parse_sse(bad)])
```

```
--- sse_event, JSON-encoded ---
'event: token\nid: 9\ndata: {"text":"{\\"text\\":\\"x\\"}\\n\\nevent: done\\ndata: {\\"tokens\\":0}"}\n\n'
parsed: [('token', 9, False)]

--- naive encoder, payload written raw ---
'event: token\nid: 9\ndata: {"text":"x"}\n\nevent: done\ndata: {"tokens":0}\n\n'
parsed: [('token', 9, False), ('done', 0, True)]
```

One event became two. The attacker's text contained a blank line and a complete second frame, and the naive encoder wrote it through untouched. `parse_sse` — and a browser's `EventSource`, which is stricter about nothing here — reads two frames, and the second has `terminal=True`.

**What the injected frame puts on the screen.** Read `render()` in `atlas/api/static/console.html`. An `approval` event renders as:

> **Needs your approval** · *delete the archive* · NOT reversible · `[Approve] [Decline]`

Two buttons, a consequence string, and a reversibility flag, all taken verbatim from the payload — and in the injected case all of it was typed by whoever wrote the question, not produced by Atlas. The console is honest about unknown kinds (`if(!KINDS.includes(kind))` prints *"Unrecognised event — this page will not guess"*) but it has no way to tell a forged known kind from a real one, because on the wire they are byte-identical.

**And who would be looking at it.** This is the part that makes it more than a self-inflicted annoyance. If the stream were only ever read by its author, forging frames in it would be a strange way to lie to yourself. The exposure is every case where a transcript is *shared*: a support agent watching a customer's session, a colleague opening a replayed trace from an eval report, a screenshot in a ticket. There a forged `approval` is a fabricated request for a human decision, a forged `error` is a fabricated system message ("Nothing was changed" — the console's exact wording), and a forged `tool` event claims something ran which did not. None of it requires an exploit, only a chat box and a newline.

**One correction to an earlier draft of this appendix.** It stated that the front end *closes the stream* on `done`. It does not: the read loop ends when the HTTP body ends (`const {value, done} = await reader.read(); if(done) break;` — a different `done`), and the `done` event kind merely renders a summary line. The claim was written without opening `console.html`. The security argument is unaffected and the mechanism was wrong, which is a good reminder that "I am confident about how this works" and "I have read the file" are different states.

`sse_event` prevents the entire class by construction rather than by filtering. `json.dumps` escapes the payload's newlines into the two characters `\n`, so no payload can produce a byte sequence that looks like a frame boundary — there is no blocklist to keep up to date and no encoding trick to get around. Its docstring states the property directly: *"a JSON string escapes its own newlines, so no payload can forge a frame boundary."* The defence is one function call, and the reason it is worth a paragraph in a docstring is that the version without it also works perfectly in every test you would think to write.

---

## A.8 Windows and WSL

### A.8.1 — knowing which layer you are in

Run on the Linux machine this appendix was authored on, which is not WSL:

```
uname -r            -> 6.18.44-fc-v24
WSL_DISTRO_NAME     -> ''
pwd                 -> /home/claude/work/p16/atlas
which -a python3    -> /usr/bin/python3 /bin/python3
```

**How to read it.** `uname -r` does not contain `microsoft-standard-WSL2`, and `WSL_DISTRO_NAME` is empty, so this is ordinary Linux and the `/mnt` and `PATH` rows of the section-8 table do not apply. The project is under `/home`, not `/mnt/c`. Both Python candidates are under `/usr`, so no Windows executable is shadowing the Linux one.

On WSL2 the same four commands would report something like:

```
uname -r            -> 5.15.167.4-microsoft-standard-WSL2
WSL_DISTRO_NAME     -> Ubuntu-24.04
pwd                 -> /home/you/atlas-agent          (good)  or  /mnt/c/Users/you/...  (bad)
which -a python3    -> /usr/bin/python3               (good)  or  /mnt/c/Python312/...  (bad)
```
`# not executed during authoring; verified by the author on the target platform`

The two "bad" readings are the ones to act on. A project under `/mnt/c` pays a translation cost on every file operation and inherits the permission and line-ending problems for free; move it to `~`. A `python3` under `/mnt/c` means you are running the Windows interpreter from a Linux shell, which will find none of your Linux packages and will report Windows paths to a project that expects POSIX ones.

If you are not on Windows at all, run the commands anyway and keep the output. Recognising the WSL answers is most useful when you are helping somebody else and cannot see their screen.

### A.8.2 — reproducing the line-ending family

```bash
$ printf '#!/bin/bash\r\necho hello\r\n' > crlf.sh && chmod +x crlf.sh
$ ./crlf.sh
/bin/sh: 1: ./crlf.sh: not found
exit=127

$ file crlf.sh
crlf.sh: Bourne-Again shell script, ASCII text executable, with CRLF line terminators
```

```bash
$ printf 'echo hi\r\nls\r\n' > crlf3.sh && bash crlf3.sh
hi
crlf3.sh: line 2: $'ls\r': command not found
exit=127
```

```bash
$ sed -i 's/\r$//' crlf.sh && ./crlf.sh
hello
after fix exit=0
$ file crlf.sh
crlf.sh: Bourne-Again shell script, ASCII text executable
```

Two different messages from one cause. In the first case the shebang reads `#!/bin/bash\r`, so the kernel looks for an interpreter whose filename ends in a carriage return; the "not found" refers to the *interpreter*, not to your script, which is why the message is so misleading. (Some systems phrase it `/bin/bash^M: bad interpreter: No such file or directory`, which is clearer.) In the second, every command carries an invisible `\r`, and bash tells you so with the `$'ls\r'` quoting — that `$'...\r'` is the diagnostic, and once you have seen it once you never misread it again.

`file` is the fastest check, because it names the condition in plain words.

Now the `.env` version:

```python
from atlas.config import Settings
s = Settings.from_env({"ATLAS_TIER": "A", "ATLAS_MODEL": "gemma4:12b\r"})
print(s.model)        # gemma4:12b
print(repr(s.model))  # 'gemma4:12b\r'
print(len(s.model))   # 11
```

**Why the printed form is so misleading.** A carriage return moves the cursor to the start of the line and prints nothing. In a terminal the eleven-character value is visually identical to the ten-character one, and so is anything you paste out of the terminal into a bug report. Every string comparison against the correct name fails, and every attempt to check by eye succeeds. `repr()` is the only cheap way to see it, which generalises into a habit worth keeping: when a string comparison fails for no reason you can see, print `repr()` and `len()` before you print anything else.

### A.8.3 — `scripts/doctor.py`

```python
#!/usr/bin/env python3
"""A.8.3 — environment triage before Phase 1. Runs anywhere, changes nothing.

Every check prints PASS or FAIL and, on failure, the exact command that fixes
it. Exit code is the number of failures, so `python scripts/doctor.py && make
test-offline` does the sensible thing.
"""
from __future__ import annotations

import os
import platform
import sys
from pathlib import Path

SKIP_DIRS = {".git", ".venv", "node_modules", "__pycache__", "data", ".pytest_cache"}
TEXT_SUFFIXES = {".py", ".md", ".txt", ".toml", ".cfg", ".yml", ".yaml",
                 ".json", ".sh", ".example", ""}
FAILURES: list[str] = []


def check(name: str, ok: bool, detail: str = "", fix: str = "") -> None:
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f"  [{detail}]" if detail else ""))
    if not ok:
        FAILURES.append(name)
        if fix:
            print(f"      fix: {fix}")


def crlf_files(root: Path) -> list[Path]:
    """Every text-ish file under `root` containing a CRLF pair."""
    found: list[Path] = []
    for path in root.rglob("*"):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        if SKIP_DIRS & set(path.parts):
            continue
        try:
            if b"\r\n" in path.read_bytes():
                found.append(path)
        except OSError:
            continue
    return found


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    release = platform.release()
    in_wsl = "microsoft" in release.lower()

    print(f"platform: {platform.system()} {release}")
    print(f"python:   {sys.executable}  {sys.version.split()[0]}")
    print(f"cwd:      {Path.cwd()}\n")

    check("python is 3.11 or newer", sys.version_info >= (3, 11),
          ".".join(map(str, sys.version_info[:3])),
          "install 3.11+ and recreate the virtual environment")

    if in_wsl:
        check("project is on the Linux filesystem, not /mnt",
              not str(root).startswith("/mnt/"), str(root),
              "move the project to ~/ and reopen your shell")
        check("python3 is a Linux executable, not a Windows one",
              not sys.executable.startswith("/mnt/"), sys.executable,
              "set [interop] appendWindowsPath=false in /etc/wsl.conf, then wsl --shutdown")
    else:
        print("note  not running under WSL; the /mnt and PATH checks do not apply")

    try:
        import atlas  # noqa: F401
        importable = True
    except ModuleNotFoundError:
        importable = False
    check("`import atlas` works", importable, "",
          "run through `make`, or `pip install -e .`, or export PYTHONPATH=.")

    offenders = crlf_files(root)
    check("no source file has CRLF line endings", not offenders,
          f"{len(offenders)} file(s)",
          "sed -i 's/\\r$//' <file>   (check first with: file <file>)")
    for path in offenders[:5]:
        print(f"      {path.relative_to(root)}")

    model = os.environ.get("ATLAS_MODEL")
    if model is None:
        print("note  ATLAS_MODEL is not set; Tier A will refuse to start (that is correct)")
    else:
        clean = all(ch.isprintable() and not ch.isspace() for ch in model)
        check("ATLAS_MODEL has no stray whitespace or control characters",
              clean, repr(model),
              "your .env has CRLF endings; convert it, then re-source the environment")

    print(f"\n{len(FAILURES)} failure(s)")
    return len(FAILURES)


if __name__ == "__main__":
    sys.exit(main())
```

Clean run, from the snapshot root:

```
platform: Linux 6.18.44-fc-v24
python:   /usr/bin/python3  3.12.3
cwd:      /home/claude/work/p16/atlas

PASS  python is 3.11 or newer  [3.12.3]
note  not running under WSL; the /mnt and PATH checks do not apply
PASS  `import atlas` works
PASS  no source file has CRLF line endings  [0 file(s)]
note  ATLAS_MODEL is not set; Tier A will refuse to start (that is correct)

0 failure(s)
exit=0
```

**Both failure modes, provoked deliberately.** With a CRLF-contaminated model name in the environment:

```
FAIL  ATLAS_MODEL has no stray whitespace or control characters  ['gemma4:12b\r']
      fix: your .env has CRLF endings; convert it, then re-source the environment
1 failure(s)  exit=1
```

With one CRLF file planted under `docs/`:

```
FAIL  no source file has CRLF line endings  [1 file(s)]
      fix: sed -i 's/\r$//' <file>   (check first with: file <file>)
      docs/_crlf_probe.md
```

Four design decisions worth defending, because a diagnostic tool that crashes or lies is worse than none.

**It never crashes on any platform.** `platform.release()` works everywhere; the WSL-only checks are behind a conditional and print an explicit note when skipped rather than silently passing. An unconditional `assert not str(root).startswith("/mnt/")` would fail confusingly on macOS, where `/mnt` means nothing.

**The CRLF scan is by suffix and skips generated trees.** Reading every byte of `.git`, `.venv` and `node_modules` would take minutes and report files you do not control. `data/` is skipped because the seeded corpora are generated artefacts. The `OSError` guard covers broken symlinks and permission errors, which are exactly the conditions a diagnostic is likeliest to meet.

**It prints `repr(model)`, not `model`.** For the reason A.8.2 established: the failing value is invisible when printed normally, so the one place that reports it must show the escapes.

**A missing `ATLAS_MODEL` is a note, not a failure.** `atlas/config.py` deliberately ships no default model — *"a model id is a current-state fact and belongs in VERSIONS.md, so the student must set ATLAS_MODEL explicitly; a wrong default baked into code is worse than a clear error."* Grading its absence as a failure would contradict the design and would fail on every fresh clone, which is how a diagnostic teaches people to ignore it.

The exit code is the failure count, so `python scripts/doctor.py && make test-offline` refuses to run the suite on a broken environment — the only sensible thing to do with a number nobody is going to read.

---

**End of Appendix A solutions.**
