"""Appendix A exercises A.3.2 and A.3.3. Offline, deterministic, free."""
from __future__ import annotations

import os

import pytest

from atlas.config import Settings
from atlas.tools.sql import is_read_only_sql


# --- A.3.2 ----------------------------------------------------------------
@pytest.mark.parametrize(
    "sql,ok,fragment",
    [
        ("SELECT 1", True, "ok"),
        ("select region from v_shipments", True, "ok"),
        ("WITH t AS (SELECT 1) SELECT * FROM t", True, "ok"),
        ("DELETE FROM shipment", False, "only SELECT and WITH"),
        ("SELECT 1; DELETE FROM shipment", False, "only one statement"),
        ("PRAGMA table_info(product)", False, "'PRAGMA'"),
        ("", False, "empty"),
        ("SELECT 1; /* hi */ DELETE FROM shipment", False, "only one statement"),
    ],
)
def test_read_only_guard(sql, ok, fragment):
    got_ok, reason = is_read_only_sql(sql)
    assert got_ok is ok
    assert fragment in reason


# --- A.3.3 ----------------------------------------------------------------
@pytest.fixture
def env_file(tmp_path):
    """A two-line .env-shaped file, and the directory it lives in."""
    path = tmp_path / ".env"
    path.write_text("ATLAS_TIER=A\nATLAS_MODEL=model-from-versions-md\n", encoding="utf-8")
    return path


def test_settings_reads_the_real_environment(monkeypatch, tmp_path, env_file):
    values = dict(
        line.split("=", 1) for line in env_file.read_text().splitlines() if line
    )
    for name, value in values.items():
        monkeypatch.setenv(name, value)
    monkeypatch.setenv("ATLAS_DATA_DIR", str(tmp_path))

    settings = Settings.from_env()  # no argument: reads os.environ

    assert settings.tier == "A"
    assert settings.model == "model-from-versions-md"
    assert settings.data_dir == tmp_path


def test_monkeypatch_undid_every_change():
    # ATLAS_TIER is deliberately NOT checked: `make test-offline` exports
    # ATLAS_TIER=F for the whole run, so monkeypatch correctly RESTORES it
    # rather than removing it. Asserting its absence fails for the right
    # reason, which is worth seeing once.
    for name in ("ATLAS_MODEL", "ATLAS_DATA_DIR"):
        assert name not in os.environ, f"{name} leaked out of the previous test"
