# Phase 8 — Memory and Context Engineering: Managing What the Model Sees, Long-Term Memory, Skills, and Cache-Friendly Layout

## 1. [core] Title | budget

| | |
|---|---|
| **Study hours** | 13 h — 5 read / 6 build / 2 assess |
| **Compute time** | `make test-offline` on Tier F: under 10 s. `make results` on Tier F: under a minute, and it is the default. `make results ARGS=--tier-a`: 25–35 min on the 16 GB no-GPU baseline, runnable one experiment at a time with `--only`. |
| **Tier A calls per full eval sweep** | **190** (52 chat completions, 138 embedding requests), as reported by `make plan`. The block allowed ~1,100; §11 explains the two revisions this number went through. Five of the eight experiments need no model at all, because they measure Atlas and not a model. |
| **Tier H calls** | ≤200, capped in `HostedEmbedder` **and** in `TIER_H_CAP`, cached to `data/cache/phase08_embed_h.json`, never required by a test. **Experiment 7, context size versus answer quality, is tagged [Tier H recommended]**: Tier A's 4,096-token window cannot hold the top two budgets of the sweep, so on Tier A that measurement becomes a measurement of truncation. |
| **Cost** | $0.00 outside Appendix B |
| **Repo tag** | `phase-08` |
| **Revision** | This is the **revised** Phase 8. The first cut shipped three defects that a capability audit caught, and they are taught here rather than hidden: a skill loader reachable from nothing on the live path (F-08-07), two abstention gates that could not fire (F-08-08), and a probe that passes at one layer and fails at another (F-08-09). §11 has the before/after table. |

Prerequisite phases: **3** (tool registry and generated schemas, the prompt package, the eval harness), **5** (the front door, per-route tool scoping, `RequestAccount`), **6** (embeddings, the document index, computed abstention), **7** (chunk grading, IDF coverage, the source decision rule).

## 2. [core] Cumulative review

Five questions from Phases 5 and 6. Answers in `phase_08_solutions.md`.

1. Phase 6's index **raises** on a query embedded by a different model but **discards a stale response cache silently**. State the rule that distinguishes the two cases in one sentence, then say what each mistake costs.
2. Phase 6 reports recall@k split into clean and messy halves and calls the split the headline. Explain why, using the fact that exactly 20% of the corpus is damaged.
3. Phase 5's fan-out returns one record per branch, in argument order, failures included. Name two distinct things that break if you drop failed branches, and say which a green suite would not catch.
4. Phase 6's extraction quality flags are inherited verbatim by every chunk rather than recomputed. Give the concrete reason a chunk that re-ran the detectors would come back clean.
5. `RequestAccount` stores tokens and calls and never money. Say why, and name the one thing that must be printed alongside any cost figure.

## 3. [core] Why this phase matters

Atlas has been meticulous about one resource and blind to another. It meters calls with `CallBudget`, refuses to exceed a token cap, and prints a `RequestAccount` per request. All of that is **accounting** — what was spent, after it was spent. Nothing in the repository decides *what to send*.

Here is what eight phases of accretion cost, measured from the repo at `phase-07`:

```
route          tools   schema chars   + system prompt   static floor (est tokens)
chat                 0             0           2,024                ~506
data                 2         1,403           2,024                ~856
document             3         1,532           2,024                ~889
tool_action          4         2,018           2,024              ~1,010
research             5         2,935           2,024              ~1,239
```

`ATLAS_NUM_CTX` defaults to **4,096**. So on `research`, before the user's question exists, Atlas has committed roughly **30% of its window** to text identical on every request. A real grounded prompt for *how long is the standard warranty* is 3,538 characters — about **884 estimated tokens** — with 1,621 of those characters being five retrieved extracts. Add a plan and a few observations and the route is not comfortably inside the window; it is near the wall, and near the wall is where behaviour gets strange in ways that look like model stupidity.

That is the first problem: **the window is a budget nobody has been writing down.**

The second is that Atlas has no memory. Three sessions, three strangers. The operations lead who explains on Monday that "shipped" means *left the warehouse* explains it again on Tuesday. Phase 7's source rule had three members — a sentence in a document, a computation over records, something outside the company — and there is a fourth no phase has admitted: **some answers exist only because this user told you.**

The third problem Phase 7 handed over deliberately. Grading a chunk was nearly free because IDF coverage is arithmetic — bounded, normalised by the *question*, thresholdable. That required a corpus. A single user's history is not a corpus, so **the one mechanism that made abstention free is unavailable here.** Phase 8 opens by asking what you can compute for nothing when there is nothing to compute a statistic over, and the answer turns out to be *time*.

Two more topics belong here and nowhere else. **Skills**: a skill is a directory with a `SKILL.md`, and it is a context-engineering technique first — load a hundred tokens of summary for every skill and pay for the full instructions only when one is relevant, because the alternative is a system prompt that grows a paragraph per capability. **Cache-friendly layout**: providers cache repeated prompt *prefixes*, so the order in which you concatenate blocks has a price, and — the part most treatments skip — context *pruning* and prompt *caching* pull in opposite directions.

One scope note. **Scaling to many tools** is taught here as concept and token arithmetic and is not built; the 60-tool `search_tools` registry is Appendix F.3, and Phase 12 covers gateways.

## 4. [core] Learning objectives

You will be able to:

1. **Compute** the static context floor of an agent configuration and state what fraction of the window it consumes before the request arrives.
2. **Implement** a character-based token estimator, state its systematic error, and **calibrate** it against a provider's reported `prompt_tokens`.
3. **Build** a conversation buffer that evicts by **token budget** rather than turn count, and explain the concrete failure of a turn-count window.
4. **Implement compaction** with a summariser whose output schema cannot drop a pinned constraint, and state what compaction is guaranteed to lose.
5. **Classify** a memory as episodic, semantic or procedural and as user- or org-scoped, and place every write into exactly one cell.
6. **Implement** a retrieval score over recency, relevance and importance after Park et al. (2023), explain why recency must be normalised, and say why an unbounded model-supplied importance destabilises the ranking.
7. **State a write policy as a deterministic gate**, and explain why "let the model decide what to remember" reproduces the D-25 failure.
8. **Package** instructions as a skill with progressive disclosure, validate `SKILL.md` against the published format, and **measure** what each disclosure level costs.
9. **Lay out** an assembled prompt so a prefix cache can hit it, name what invalidates a cached prefix, and explain why tool-result pruning and caching are in direct conflict.
10. **Do the arithmetic** that says when a flat tool registry stops working, and describe the `search_tools`/`execute_tool` indirection without implementing it.
11. **Design a cross-session recall probe**, and say what a passing probe does and does not prove.

## 5. [core] Prerequisites & quick recap

The repo at tag `phase-07`, green at **1,074 passed, 12 skipped**, with `make data` run. Nothing in the [core] path requires a model.

> **If your code diverged, start again from `atlas_phase_07.zip`.**

You build on: Phase 3's `atlas.prompts` (a versioned file, a pinned checksum, a changelog entry naming the measurement — all four now apply to a *skill*) and `ToolRegistry.names`, which is **sorted** with a comment reading "order stability = cache key" that has waited five phases for §8.10 to explain it. Phase 5's `HANDLER_TOOLS` (the reason the floor table has five numbers), `RequestAccount`, and invariant 16 — a stateful wrapper is constructed once per run and passed in, which matters enormously when a store built inside the loop that reads it remembers nothing. Phase 6's `HashingEmbedder` and cosine machinery, reused verbatim as the *relevance* term, and invariant 45's versioned-index refusal. Phase 7's `grade_hits` asymmetry, and `classify_source`, whose three-member rule is about to gain a fourth member and become ambiguous.

### A two-paragraph orientation on tokenizers [core]

You know a tokenizer maps text to integer ids and that models bill in those ids. The narrower fact this phase needs: **you cannot count tokens correctly without the specific tokenizer the specific model uses.** Byte-pair encodings differ between families, between versions within a family, and sometimes between a base model and its instruction-tuned sibling. There is no universal answer to "how many tokens is this string", and a library that gives you one is giving you *a* tokenizer's answer.

The consequence is that a locally enforced token budget is always enforced against an **estimate**, and the estimate's error has a direction. English prose runs roughly 3.5–4.5 characters per token for most modern BPE vocabularies; JSON, code and long identifiers run *lower* — more tokens per character — because braces, quotes and snake_case split aggressively. So a 4-characters-per-token estimate systematically **undercounts** a prompt full of tool schemas, which is exactly the prompt whose size you most want to control. Atlas's estimator ships with a stated constant, a stated direction of error, and a free calibration path: every completion already returns the true `prompt_tokens`. Appendix A has fifteen minutes on BPE if you want the mechanism; you do not need the mechanism, you need the humility.

## 6. [core] Core concepts

### 8.1 [core] The window as a budgeted resource

**Intuition.** A brilliant consultant who works only from a single sheet of A4 you hand them per question. They cannot ask for another. Everything — who you are, what tools they may use, the relevant excerpt, the four things you said last Tuesday, and the question — must fit, and anything in the margins pushes something off. **The page is the constraint, and you hold the pen.**

*Context* is the set of tokens present when the model is sampled; *context engineering* is deciding which tokens those are. Anthropic's **"Effective context engineering for AI agents" (29 September 2025)** framed it as the successor to prompt engineering, with the goal worth memorising: find the **smallest set of high-signal tokens** that makes the desired outcome likely.

Two things make this engineering rather than tidiness. The window is finite, which is obvious. And **utility per token declines well before the window is full**, which is not: Liu et al., *Lost in the Middle* (arXiv:2307.03172, 6 July 2023) showed accuracy depending on *where* a needed fact sat, with a dip in the middle; Chroma's *Context Rot* (2025) generalised it across models with different slopes. Anthropic's post names the mechanism: attention is an **n² relationship over n tokens**, models see shorter sequences far more often in training, and the result is a *gradient* rather than a cliff.

> **A token that does not raise the probability of a correct answer has a negative expected value.** It costs money, it costs latency, and it dilutes attention over everything else.

That has an uncomfortable corollary for Phase 6: **101 of 140** chunks reaching the generator came from documents that could not answer the question. Those were not merely wasteful — they were *competing* for attention with the 39 that mattered.

> **Misconception: "a bigger window makes this go away."** It moves the wall and nothing else. Utility per token still declines; cost and latency scale with what you *send*, so a 200,000-token prompt for a question answerable in 2,000 is a hundredfold overpayment for a worse answer; and a larger window changes no *decision*. The analogy is not a bigger hard disk. It is a bigger desk — helpful, and not a filing system.

**Concept check 8.1.** Atlas's `chat` route has a ~506-token static floor and no tools; `research` has ~1,239 and five. Someone proposes shortening `atlas_system.v1.md` (2,024 chars, shared by every route). Say how many estimated tokens a 30% cut returns **to `research`**, then why that is the wrong place to start.

### 8.2 [core] The five claimants

```
┌─────────────────────────────────────────────────────────────────────────┐
│ 1. INSTRUCTIONS      system prompt, role, rules, output shape           │
│                      grows: by EDIT. Atlas: 2,024 chars, ~506 est tok.  │
├─────────────────────────────────────────────────────────────────────────┤
│ 2. TOOL SCHEMAS      one JSON Schema per available tool                 │
│                      grows: LINEARLY in tool count.                     │
│                      Atlas: 7 tools = 4,116 chars, ~1,029 est tok       │
│                              (mean ~588 chars, ~147 est tok per tool)   │
├─────────────────────────────────────────────────────────────────────────┤
│ 3. RETRIEVED DATA    extracts, query results, file contents, web text   │
│                      grows: with k, and per tool call.                  │
│                      Atlas: 5 extracts = 1,621 chars, ~405 est tok      │
├─────────────────────────────────────────────────────────────────────────┤
│ 4. HISTORY           prior turns of this conversation                   │
│                      grows: MONOTONICALLY, forever, if unmanaged.       │
│                      Atlas: unbounded. The one with no policy.          │
├─────────────────────────────────────────────────────────────────────────┤
│ 5. SCRATCHPAD        the plan, the todo list, findings, notes-to-self   │
│                      grows: with task complexity; rewritten in place.   │
└─────────────────────────────────────────────────────────────────────────┘
```

**Worked example: `research` at request three.** Instructions ~506. Five scoped schemas ~733. A four-step plan ~150. Two capped observations ~200. Two prior exchanges at ~120 each, ~480. The new question ~30. Total ≈ **2,100 estimated tokens of 4,096**, with the answer still to generate. One more round of observations and you are over.

Notice the structure: **instructions and tool schemas are 1,239 of it, byte-identical to the previous request.** That is 59% of the prompt re-sending text the provider has already seen — the fact §8.10 turns into money, and the reason the *order* of these blocks is a design decision.

**The growth rates are the design.** Instructions grow by human edit. Retrieved data grows by a parameter you chose. Scratchpad is rewritten, so it is bounded by task shape. Tool schemas grow linearly in a number that tends to grow monotonically. And **history grows without bound and without a policy**, which makes it the only claimant that will consume the window on its own. That asymmetry is why "context engineering" means, four times out of five, "what do we do about history".

> **Misconception: "the history is the conversation, so trimming it is lossy and therefore wrong."** A transcript is a lossy record already. What matters is not whether trimming loses information — it always does — but *which*, and whether the loss is bounded and visible. The failure to avoid is not lossy compression; it is **silent** lossy compression, which is the whole content of §8's debug trace.

**Concept check 8.2.** Exactly one claimant can shrink *between* two consecutive requests with no code change. Name it, name the circumstance, and say why that makes it dangerous to use as slack in a budget.

### 8.3 [core] Measuring context health

You cannot budget in a currency you cannot count. Three numbers, none needing a model.

**First, size.** `CHARS_PER_TOKEN = 4.0` and `estimate_tokens`. Four things, all said out loud in the code. **It is an estimate, and the name says so** — a function called `count_tokens` that returns an estimate is a lie with a type signature (invariant 51's shape: name a value for what it does). **Its error has a direction**: JSON is denser, so 4.0 undercounts schemas, and undercounting is the dangerous direction because many runners truncate from the *oldest* end, where the system prompt lives. **It is calibratable for free**: every completion returns `usage.prompt_tokens`, the model's own count. **It does not become a dependency**: `tiktoken` gives a precise count of the *wrong* vocabulary, which is worse than a labelled estimate because it invites trust.

**Second, composition.** Knowing a prompt is 2,100 tokens is not actionable. Knowing it is 35% tool schemas is. So the assembler logs block name, tokens, share.

**Third, what you dropped.** This is the phase's rhyme with invariant 52:

> **A context budget that cannot be exceeded does not make the right things present.** Enforcement and adequacy are different questions. A budget answers the first. Only the composition log and a recall probe answer the second.

**Concept check 8.3.** The estimator undercounts JSON; the assembler enforces its budget with it; the largest JSON block is the tool schemas. Name the specific failure, and say which fix — raising `CHARS_PER_TOKEN`, or reserving the schema block outside the budget — is safer.

### 8.4 [core] Short-term memory: turns are the wrong unit

**A window measured in turns is a budget denominated in a unit that does not track the resource.** Ten short exchanges and ten exchanges each carrying a 2,000-character file read are the same length in turns and differ by an order of magnitude in tokens.

```
(a) keep last N TURNS    simple, and the budget floats freely
(b) keep last N TOKENS   the budget is the actual resource; evicts oldest-first
(c) (b) + PINNING        some turns are exempt, because they carry constraints
```

Atlas implements (c). Consider: turn 2 says *"For anything you write, use the ops workspace — never the shared drive."* Turns 3–16 are ordinary work. Turn 17 asks Atlas to save a summary. Under (b) with a 1,500-token window, turn 2 was evicted around turn 9, and Atlas writes to the shared drive — confidently, with no error, and with a trace in which nothing looks wrong, because the constraint is not *contradicted* anywhere in the surviving context. It is absent.

**Turns are not interchangeable.** A turn establishing a constraint has a different half-life from one reporting an intermediate number. Oldest-first eviction treats them identically because recency is its only signal. A second signal costs one boolean.

**Who sets the boolean?** Not the model alone. D-25 → invariant 29 → invariant 44 → invariant 50: a model that can mark a turn "safe to drop" has been handed the ability to discard the thing it must not discard. So a deterministic rule proposes pins; an optional model arm may propose *additional* pins; nothing can remove one.

Measured, on nine turns of 40, 55, 30, 620, 45, 610, 35, 50, 40 tokens (plus 4 framing each) against a 400-token budget:

```
contiguous, no pin:  kept [6,7,8]          = 137 tok   constraint at t1: GONE
contiguous, pin t1:  kept [1,6,7,8]        = 196 tok   constraint: PRESENT
greedy,     no pin:  kept [0,1,2,4,6,7,8]  = 323 tok   holes at 3 and 5
```

Pinning retained four turns where plain eviction retained three — and note what it bought. Not slack: pinning *spends* 59 tokens. It bought **reachability**, because with a 614-token turn between turn 1 and the recent run, no budget under the contiguous policy could have reached turn 1.

> **Misconception: "pinning is just a priority queue — score every turn and keep top-k."** A score is a continuum, and a continuum under budget pressure will eventually drop your highest-scored item, because when everything competes on one axis *nothing* is guaranteed. A pin is a different kind of thing: a boolean that removes a turn from the competition. If pinned turns alone exceed the budget, the right behaviour is to **refuse and say so** — a session whose constraints do not fit cannot be run safely.

**Concept check 8.4.** Turn 4 is a 620-token file read; turn 5 is a 45-token answer summarising it. Oldest-first drops 4 and keeps 5. Say why that is desirable, then name the situation where it is a bug.

### 8.5 [core] Compaction, and what you have promised to lose

Compaction compresses rather than discards: summarise the span you were about to drop. You trade fidelity for length at a ratio you choose and at a *selection* you do not control, because a model did the selecting.

Anthropic's post describes Claude Code's implementation, and what it *names as preserved* is the instructive part: architectural decisions, unresolved bugs, implementation details, while discarding redundant tool outputs — with the agent continuing from that summary plus the five most recently accessed files. Two design choices are visible. The summary is **not** a neutral précis; it has a priority list. And the recent-files carve-out is a **pin**. Their tuning guidance is about *evaluation*: tune on complex real traces, **maximise recall first**, and only then improve precision. A prompt tuned for brevity first looks excellent on every trace whose dropped constraint never comes up again.

```
FLAT           summarise(1..12) -> S; next: summarise(1..24) -> S'
               O(n) per compaction, O(n²) per session. Best fidelity.
PROGRESSIVE    summarise(S + 13..24) -> S'
               O(window) per compaction. Fidelity DEGRADES and compounds.
               MemGPT's recursive summarisation (arXiv:2310.08560, 12 Oct 2023).
HIERARCHICAL   level-1 per span + level-2 over the level-1s; recompute from
               ORIGINALS when it matters. Bounded, and recoverable.
```

Atlas uses progressive summarisation for the live buffer and hierarchical *storage*: the original turns are written to the session log before compaction runs, so a summary is never the only copy. That turns "compaction lost the constraint" from unrecoverable into reproducible.

> **Invariant 55.** **Compaction is lossy by design, so what must survive it is extracted BEFORE it runs and pinned OUTSIDE it.** A summariser prompt saying "preserve all constraints" is a request. A pinned block the summariser never sees, concatenated after the summary by code, is a guarantee. `SummaryDraft` therefore has no field naming a constraint, no field marking one droppable, and no field reporting that it kept them — because a field reporting compliance can report compliance falsely.

Fifth appearance of the same pattern: Phase 4's critic, Phase 6's `GroundedDraft`, Phase 7's `GradeDraft`, and now `SummaryDraft` and `WriteDraft`. Each time: **remove the field rather than filtering it.**

**The cost, stated.** Pinning outside compaction means pinned tokens are permanent. Forty pinned constraints is a monotonically growing floor no compaction reduces — §8.2's problem relocated rather than solved. So the block is capped, and at the cap the buffer **refuses and reports** rather than silently evicting the oldest pin.

**One thing compaction is not.** Clearing a consumed tool result is *targeted deletion* of a block whose usefulness expired when the model read it — nearly free, nearly safe. Compaction is *lossy rewriting* of narration whose usefulness has not expired — a model call that can lose a constraint. The correct lever order, cheapest and safest first: clear consumed tool results → evict unpinned narration by budget → compact what remains → consider a sub-agent with its own window.

**Concept check 8.5.** A colleague argues flat summarisation is strictly better at Atlas's session lengths. Give their strongest argument, the one measurement that settles it, and which `docs/RESULTS.md` row would contain it.

**Concept check 8.6.** Invariant 55 means the summariser cannot resolve a pronoun in turn 20 referring to a constraint in turn 2. Say what is genuinely lost, and why the trade is still correct.

### 8.5b [core] The other three levers, and the scratchpad

Compaction is the third of four levers and the loudest, so it crowds out the others. All four, with what each costs and what it cannot do.

**Lever 1 — clear consumed tool results.** §8.17 builds it. Nearly free, nearly safe, because a tool result the model has already read and acted on is information that was *consumed*, not stored. Its only cost is the cached prefix, which is why it takes a minimum-clearance parameter. **It cannot help** with narration, plans, or anything the model has not finished using.

**Lever 2 — just-in-time retrieval.** Do not pre-load what the agent might need; give it the means to fetch what it turns out to need. Atlas has done this since Phase 3 without the name: `read_file` and `query_db` are lazy loads, and `retrieve_documents` is a lazy load the model chooses. The pattern generalises to *identifiers* — a file path, a query, a URL, a memory id — held in context as a cheap handle that can be resolved on demand, which is why Anthropic's post describes agents that keep file paths rather than file contents. **Its cost is a round trip and a model decision**: a lazy load the model does not think to perform is information you did not have. Compare §8.8.4's paging limit — this is the same trade-off with a different noun, and it is why Atlas assembles memories as a pre-step *and* offers `recall` as a tool.

**Lever 3 — sub-agent isolation.** Give a long sub-task its own window. A worker researching one sub-question accumulates twenty tool results, a plan, and a great deal of narration, and the orchestrator needs **none of it** — it needs the finding. Atlas already does this and Phase 5 built it: `run_research_pipeline` fans out to workers, each with its own budget and its own trajectory, and only `Finding` records come back. That is context isolation, and the reason it is the strongest lever is arithmetic: n workers × a full window each, compressed to n findings, is a compression ratio nothing in this phase can approach. **Its cost is that the orchestrator cannot see the work.** A worker that misunderstood the sub-question returns a confident finding, and the orchestrator has no context in which to doubt it — which is why Phase 5's `Finding` carries provenance and why the critic exists. Phase 11 pushes this further.

**Lever 4 — the filesystem as memory.** Write notes, plans and findings to files; keep only an index in the window. Unbounded, and *inspectable*: you can read the agent's notes, which is worth more than it sounds. Two costs. File contents are **unvalidated input the agent later trusts**, which is memory poisoning with a filesystem attached (§8.12). And an agent that must decide to read a file **can decline to** — lever 2's cost, again. Atlas's jailed `write_file`/`read_file` (Phase 3) plus this phase's session log is a small version of the pattern; the provider-side version is the memory tool in §10.

**And the scratchpad, which is not a lever but a claimant.** Claimant 5 in §8.2 is the plan, the todo list and the findings — state the agent maintains *about its own work*. It differs from history in the one way that matters for budgeting: **it is rewritten in place rather than appended to**, so it is bounded by task shape rather than by conversation length. Atlas's scratchpad is `PlanDraft` plus the `Finding` list from Phase 4, and it needs no new mechanism here precisely because rewriting is already a bound. The failure to watch for is a scratchpad that grows by accretion — a findings list nothing ever prunes — at which point it has become history under another name and needs history's policy. Invariant 29 is what keeps it honest: a model may add a finding and may never clear one, so pruning is a code decision, made deliberately, in one place.

**The ordering is cost-and-safety, and it is worth memorising.** Clear consumed results (free, safe) → retrieve just in time (a round trip) → compact (a model call, and lossy) → isolate in a sub-agent (a whole extra agent, and the orchestrator loses sight of the work). Reach in that order, and stop as soon as the window fits.

**Concept check 8.23.** Lever 3 has the best compression ratio and is listed last. Give the two reasons, and say which of them is about tokens.

### 8.6 [core] Long-term memory: three kinds, two scopes

**A taxonomy earns its place in code only when it changes a policy.**

| Kind | What it is | Atlas example | Policy it changes |
|---|---|---|---|
| **Episodic** | A thing that happened, at a time | *"On 2026-03-04 Priya asked for Q1 S400 shipments."* | **Retention.** Decays; newest wins |
| **Semantic** | A fact believed true, not tied to an occasion | *"'Shipped' means left the warehouse."* | **Conflict.** Superseded explicitly |
| **Procedural** | How to do something here | *"Quarterly questions go to `v_shipments`."* | **Delivery.** Belongs in a **skill** |

```
                    │ scope = USER                  │ scope = ORG
────────────────────┼───────────────────────────────┼──────────────────────────────
 episodic           │ "Priya asked X on Mar 4"      │ (rare; an audit log)
 semantic           │ "Priya prefers tables"        │ "'shipped' = left the warehouse"
 procedural         │ (rare; a personal macro)      │ "quarterly qs -> v_shipments"
```

**Most rows are episodic-user, and most *value* is in the other cells.** Episodic-user rows accumulate at the rate the user talks and are the least reusable. Semantic-org and procedural-org accumulate slowly and are worth an order of magnitude more per row. Hence a **gate**, not a firehose, and hence `kind` and `scope` as closed `Literal`s — a field whose values you cannot enumerate is a field you cannot write a retention policy against.

**Scope is an authorisation question wearing a storage costume.** Atlas filters by scope **in the query**, not after retrieval: a filter after ranking silently reduces `k` (F-06-07), and a filter after *rendering* is not a filter.

**The fourth member of the source rule** makes the first ambiguous, because "does the answer exist as a sentence" is now true of both a reviewed document and an unreviewed remark. The difference is provenance:

> A document was **authored and reviewed**. A remembered sentence is **one person's unreviewed statement on one day**, and the only thing that makes it trustworthy is knowing whose, and when.

So invariant 42 extends: a memory-sourced claim renders with the user, session and date — `[memory u=priya s=s-0003 2026-03-04 semantic/org]` — always, exactly as a data answer prints `read:` always (D-39).

> **Misconception: "long-term memory is just RAG over the conversation log."** Three differences change the engineering. **The corpus is tiny**, so corpus statistics are unavailable — no IDF, no coverage floor, so Phase 7's free abstention does not transfer. **The corpus mutates**, so a memory can be superseded, expired or deleted. And **the corpus is written by the system under test**: a retrieval bug returns the wrong document, whereas a write-policy bug *manufactures* a false document and then retrieves it correctly forever.

**Concept check 8.7.** A semantic-org memory says *"'shipped' means left the warehouse."* Three months later: *"actually, from Q3 we're counting invoiced."* Give two representations of the update and say which the `docs/DECISIONS.md` convention chooses.

### 8.7 [core] Storage: key-value, SQLite, vector — "or" is the wrong conjunction

```
KEY-VALUE     get(key) -> value.  "what is X's Y?"  Not "what is like X?"
              Atlas: the user PROFILE.
RELATIONAL    SELECT ... WHERE ... ordering, filtering, constraints.
              Atlas: the SYSTEM OF RECORD.
VECTOR        nearest(embedding, k). "what is like X?"  Not "which are Priya's?"
              Atlas: an INDEX, not a store.
```

**SQLite is the system of record** — one file, ships with Python, no server, and `make test-offline` works on a fresh clone with no network (invariant 2). **The vector part is an index over that table, not a second store** (D-43): the embedding is a column, and there is deliberately no code path that can return a memory id the table does not contain. Two systems means two truths, and they diverge the first time a delete succeeds in one and fails in the other — at which point a deleted memory is still retrievable, which is not a bug but a compliance incident. **Key-value holds the profile**, because the user's name must be present *every time*, not when it happens to rank in the top four.

**Invariant 45 applies unchanged**, with one wrinkle: a document index can be rebuilt from its corpus, so a mismatch there is an inconvenience; a memory store's rows *are* its originals, so the repair is re-embedding in place. Atlas ships the refusal *and* `reembed()`, and the refusal is the default because a silent partial re-embed is the worst of the three options.

### A two-paragraph orientation on SQLite DDL and upserts [core]

**DDL** is the subset of SQL that creates schema: `CREATE TABLE IF NOT EXISTS memories (id TEXT PRIMARY KEY, user_id TEXT NOT NULL, ...)`. `PRIMARY KEY` makes a column unique and indexed; `NOT NULL` refuses a missing value at write time rather than at read time; `CREATE INDEX IF NOT EXISTS ix_mem_user ON memories(user_id, scope)` makes the scope-filtered query fast and is the one index this table needs. The `IF NOT EXISTS` clauses make schema creation **idempotent**, which is what lets Atlas call `ensure_schema()` on every open instead of maintaining migration state — the same property `make data` has.

**Upsert** writes a row that may already exist: `INSERT INTO memories (...) VALUES (...) ON CONFLICT(id) DO UPDATE SET last_used_at=excluded.last_used_at, uses=uses+1`. The `excluded` pseudo-table holds the row you tried to insert. This matters because recording a *use* is a read followed by a write, and two statements is a race — two concurrent recalls both read `uses=3` and both write 4. `uses=uses+1` inside the upsert is atomic. You need nothing beyond this for the phase; Appendix A's SQL section covers it in twenty minutes.

**Concept check 8.8.** A colleague suggests moving embeddings to a dedicated vector database for speed, keeping rows in SQLite as the record. Name the failure no unit test of either component would catch, and the invariant it violates.

### 8.8 [core] Memory operations

**8.8.1 Writing: a gate, not a firehose.**

```
should_write(turn) -> WriteDecision(write, kind, scope, reason)
  1. role == "user"                        else no  (never remember your own claims)
  2. length within [min, max] chars        else no
  3. matches a DURABLE-STATEMENT cue       else no
  4. not near-duplicate of an existing row else no  (cosine >= dedup_floor)
  5. no PII pattern matched                else REDACT then write
```

Clause 1 is the cheapest safeguard in the phase and it is one `if`: **Atlas never remembers its own output.** Storing an assistant turn and later retrieving it as a memory is how a system launders a hallucination into a remembered fact.

Clause 3 has no free normalisation available, so it is a hand-written cue set — and it inherits `atlas.rag.sources`' caveat verbatim: **the author wrote both the cues and the test questions, so a reported accuracy is an upper bound, not an estimate.**

The model arm receives one field, `not_durable: bool`, and may only **veto**.

> **Misconception: "the model is better than a cue list at spotting what matters."** Probably true on average, and irrelevant, because the failure modes are not symmetric. A missed durable statement costs one memory you add later. A fabricated memory costs a false fact retrieved confidently for as long as the row lives, with a provenance line saying the user said it. **The asymmetry, not the accuracy, decides who holds the pen.**

**8.8.2 Retrieving: recency, relevance, importance.** Cosine alone is wrong here in a way it was not in Phase 6: a document does not get less true with age, and a remark does. *"I'm working on the warranty review this month"*, said in March, is actively misleading in September and *just as semantically similar* to a warranty question.

Park et al., ***Generative Agents*, UIST 2023**: score = α_rec·recency + α_rel·relevance + α_imp·importance, each min-max normalised to [0,1], all α = 1, recency an exponential decay of 0.995 per hour, relevance cosine, importance a model rating 1–10. **MemoryBank** (Zhong et al., arXiv:2305.10250, 17 May 2023; AAAI 2024 pp. 19724–19731) shapes decay on the Ebbinghaus curve so retrieval *reinforces*.

Four deliberate deviations. **Recency decays on `last_used_at`, not `created_at`** — decaying on creation means a memory consulted daily fades as fast as one nobody has read, which is backwards — **and the clock is injected**, because a scoring function that reads the wall clock has tests that expire. **Normalisation is per-query min-max**, which makes the score *incomparable across queries*, so it **ranks and never gates**: there is no `score_floor` anywhere, because a threshold on a per-query-normalised quantity is a threshold on the shape of the candidate set. **Importance is bounded, deterministic by default, and clamped** — an unbounded model-set term is one the model can use to promote anything to the top of every future ranking. **Abstention is computed from staleness and scope, not coverage**: `stale` and `out_of_scope` gate; `thin` is computed, printed and wired to nothing (invariant 49), because a sparse result set is what a new user's first week looks like and a signal that cannot tell "nothing relevant" from "nothing yet" refuses correct answers to the people least able to diagnose why.

**8.8.3 Consolidation, forgetting, conflict.** **Consolidation** turns many episodic rows into one semantic row; Park et al. call the analogous operation *reflection* and fire it on cumulative importance rather than a schedule. Atlas ships it as an **explicit command**, because it *writes* semantic rows and an automatic path would walk around the gate. **Forgetting** has three non-interchangeable mechanisms: **expiry** (a per-kind TTL evaluated at read time — no job to schedule, no sweeper deleting rows a running session holds), **pruning** (physical deletion, a command), and **deletion on request** (§8.12, a legal obligation). **Conflict resolution** is append-only supersession, exactly as `docs/DECISIONS.md` has worked since Phase 1.

**8.8.4 Paging, and memory as tools.** **MemGPT** supplies the metaphor: context as main memory, everything else as disk, with the agent paging via function calls. Its three tiers map onto three Atlas components — *main context* (read-only instructions, a FIFO queue, a writable scratchpad) is §8.1's instructions, §8.4's buffer and the plan; *recall storage* is the session log; *archival storage* is the memory table. Its honest limit: an OS page fault is **transparent and correct**, while an agent's page-in is a *model decision* that can be declined, forgotten or done badly. Paging relocates the policy into a place where a model makes it. So Atlas assembles the profile and top memories **unconditionally** as a pre-step, and `recall` exists **as a tool** for what the pre-step's query could not anticipate.

```
recall(query, k)      read_only=True,  cacheable=True
remember(text)        read_only=False, cacheable=False
```

`remember` being non-read-only routes it through five mechanisms Phases 3 and 5 built: `execute()`'s `allow_writes`, `cached_execute`'s never-cache/never-replay (D-23, D-26), `HANDLER_TOOLS`, and Phase 12's future gate.

**Concept check 8.9.** `remember` is a tool the model can call, and the model has no authority to create memories. Reconcile those precisely, then say what `remember` must do with rejected text and why success would be a reporting bug.

### 8.9 [core] Skills and progressive disclosure

**Intuition.** A new colleague gets a one-page index of *what manuals exist and when each applies*, and fetches the chapter when the situation arises. The index costs a page; the manuals cost nothing until needed.

A **skill** is a directory with a `SKILL.md` — YAML frontmatter plus a Markdown body — and optional supporting files in `scripts/`, `references/`, `assets/`. Frontmatter requires `name` and `description`. The format is a published open standard; the field list, character limits and recommended token ceilings are **VERSIONS.md rows**, because they are current-state facts about a live spec.

```
LEVEL 1  METADATA      name + description, for EVERY skill, at startup
LEVEL 2  INSTRUCTIONS  the SKILL.md body, when activated
LEVEL 3  RESOURCES     references/, scripts/, assets/, read on demand
```

| | Loaded when | Arrives as | Chosen by | Right for |
|---|---|---|---|---|
| **System prompt** | always | whole | you, at build time | rules for every request |
| **Tool** | schema always; result on call | a schema and a return value | model, at call time | *doing* something |
| **RAG document** | on retrieval | a ranked fragment | a retriever | facts you cannot enumerate |
| **Skill** | summary always; body on activation | whole, in order | model, from the summary | *procedures* you can enumerate |

Atlas ships **one** skill, `northwind-quarterly`, chosen to answer a real failure: Phase 7 §8's query was legal, cheap, read-only, against the wrong relation, and returned 71 where the truth was 5.

> **Misconception: "a skill is just a prompt template with extra steps."** The difference is *who decides when it loads, and on what information*. A template is selected by your code before the model runs; a skill is selected by the model, from a hundred-token description, mid-task. That relocation has a cost: skill selection is a **model-owned branch**, and invariant 33 permits it only because a growing library of procedures cannot be enumerated in a router — but the loading decision must be **recorded as data** or it cannot be measured.

**Concept check 8.10.** If a skill's L2 is 800 tokens and its L1 is 100, at what activation rate does progressive disclosure stop saving tokens versus the system prompt? Then say why the token break-even is not the whole decision.

### 8.10 [core] Cache-friendly layout

Providers cache prompt *prefixes*: the leading run up to a marked point is hashed, and a later request with an identical prefix reads the processed form. Anthropic's implementation has four structural properties worth internalising, with every *number* in VERSIONS.md.

**The prefix is assembled tools → system → messages**, and a change at one level invalidates that level and everything after. Change a tool definition and you have invalidated the system prompt you did not touch. This is why `ToolRegistry.names` is **sorted**: a registry iterating a `set` would emit schemas in a different order per process and never hit a cache in its life, and nothing would look wrong.

**Cache writes happen only at a marked breakpoint; reads look backwards for entries that *earlier requests wrote*.** The lookback does not find stable content behind your marker and cache it — it finds *prior writes*. So the correct placement is the **last block identical across the requests you want to share a cache**, and marking the volatile block writes a fresh entry every time and reads none.

**Matching is exact.** One character's difference is a miss, not a partial hit.

**Cache reads are dramatically cheaper than fresh input; writes cost slightly more.** Caching is a bet that you read more often than you write, and a prefix rewritten every request loses twice.

Atlas orders blocks by **volatility**, not importance:

```
 first  tool_schemas (sorted)                    static     ✓ reuse
        instructions (checksum-pinned)           static     ✓ reuse
        skill catalogue (sorted)                 static     ✓ reuse
        --- cache marker belongs HERE ---
        org memories + user profile              slow       partial
        activated skill body (level 2)           slow       partial
        retrieved extracts                       volatile   ✗
        summary + buffer turns                   volatile   ✗
 last   the question                             volatile   ✗
```

Note the cost: the *most* relevant content sits at the end, where *Lost in the Middle* says a model attends well. Here recency of position and cache-friendliness agree. When they disagree, **correctness wins and the cache loses**, because a cheap wrong answer is not a saving.

**And the conflict this section exists to name.** Anthropic's `clear_tool_uses_20250919` context edit is currently behind a beta header, so it appears in **no code here** (the pre-release rule); the forward pointer is that when it leaves beta, Atlas's pruner becomes a wrapper over it. Its documented consequence is the lesson:

> **Clearing content from the middle of a prompt changes the prefix, so it invalidates the cached prefix from that point on.** Pruning and caching are in direct opposition. Every token reclaimed by deletion costs a cache write on everything after it.

That is why the feature has a minimum-clearance parameter. On Tier A there is no prefix cache to measure, so this phase teaches the layout for $0, measures nothing about it, and says so.

**Concept check 8.11.** A colleague proposes moving org memories into the static band to improve cache hits, since they change only on a write. Give the strongest argument, then the failure, then the field on `MemoryRecord` that makes the failure unavoidable.

### 8.11 [core] Scaling to many tools [concept; build in Appendix F.3]

From this repository: 7 tools = 4,116 characters, mean ~588 chars or **~147 estimated tokens per tool**.

```
 tools    est. tokens of schema   % of a 4,096 window   % of a 200,000 window
     7            ~1,030                  25.1                     0.5
    20            ~2,940                  71.8                     1.5
    60            ~8,820                 215.4  (impossible)        4.4
   200           ~29,400                    —                     14.7
```

Two failures arrive at different points. **The window failure** is loud: at 60 small tools the schemas do not fit in 4,096 tokens. **The selection failure** is quiet and arrives much earlier — published guidance puts degradation in the region of a few tens of tools (figures in VERSIONS.md) — and the mechanism is that overlapping tools make the decision genuinely ambiguous. The sharpest diagnostic to keep: **if a human engineer cannot definitively say which tool should be used in a situation, an agent cannot be expected to do better.** So the *first* fix for a large tool set is deleting and merging tools until the ambiguity is gone. `HANDLER_TOOLS` is a primitive version of this already.

```mermaid
flowchart LR
    A[request] --> B{"search_tools(query)"}
    B --> C["3-5 matching schemas<br/>expanded into context"]
    C --> D["execute_tool(name, args)"]
    D --> E[result]
    F[("catalogue<br/>200 tools<br/>names + descriptions")] -.searched.-> B
```

Three instructive details about the server-side implementation. It offers a **regex** variant and a **BM25** variant — and BM25 should feel familiar, because a tool catalogue is a small corpus of short documents. The **full definitions still cross the wire** on every request: deferral controls what enters the *context*, not what is sent. And discovered definitions are appended **inline in the conversation**, leaving the system-prompt prefix intact, *specifically so prompt caching survives* — §8.10 and §8.11 turning out to be the same problem.

The cost is a round trip, paid on requests that would have selected correctly from a flat list. **The decision rule is the arithmetic**: small definitions plus most tools used most requests means a flat registry is correct and indirection is overhead.

**Concept check 8.12.** At 200 tools, schemas are ~14.7% of a 200k window, which sounds survivable. Give two reasons to adopt tool search anyway, only one of which is about tokens.

### 8.12 [core] Privacy, PII, deletion — and two sentences on poisoning

**Minimise at the boundary.** The PII clause runs *before* insertion; redaction is recorded on the row. Redacting at read time leaves the raw value on disk, in backups and in every dump, while the code looks careful. Detection is regex over enumerable formats, and the docstring says plainly that this catches formats and not meanings — the honest limit of every PII regex ever written.

**Scope is enforced in the query.** **Deletion is real and it is a command**: `delete_user` removes rows and returns the count, and a test asserts the row is *absent* rather than flagged. Expiry makes a memory stop being a candidate; deletion makes it stop existing, and **a system implementing only the first and calling it deletion has a documentation defect with legal consequences.** **Provenance makes deletion auditable**: `source_session` turns "delete everything from March 4th" into a query.

**Memory poisoning, in two sentences.** Because memories are written from conversation text and later retrieved as trusted context, an attacker who can get text into a conversation — through a document, a web result, or a tool output — can attempt to write a durable instruction that steers every future session, which is prompt injection with persistence and therefore strictly worse. Atlas's structural mitigations are that only *user* turns are eligible, `remember` is non-read-only and subject to `allow_writes`, and the gate is deterministic — **Phase 14 treats injection and memory poisoning properly**, including when the user is the adversary.

**Concept check 8.13.** A user can paste a poisoned document's text into their own message, which *is* a user turn. Say what the rule bought.

### 8.13 [core] Evaluating memory: the cross-session recall probe

A memory system's unit tests can all pass while it remembers nothing useful, because unit tests exercise the mechanism and the question is about the *system* (invariant 41). The check that cannot be faked: state a fact in session 1, end the session, and in session 3 ask a question requiring it.

A **recall probe** is a *plant*, a *probe*, and an *expectation derived from the plant* (D-20, invariant 32) — a probe whose answer is typed in passes when the corpus changes underneath it. It grades what the system **produced**, never the path it took (invariant 22): "did the answer use the remembered definition" is checkable; "did it call `recall`" would pass for a system that called `recall`, got nothing, and answered from priors. And **a failure is attributable**, because the record carries the candidate set and the three score components, so a failed probe distinguishes *not written* from *written but not retrieved* from *retrieved but not used* — three different fixes a single boolean cannot separate.

**What a passing probe proves**: the write, the store, the retrieval and the assembly compose end to end through the code callers use (invariant 46). **What it does not**: that the write policy generalises (the plants and cues share an author), or anything about **precision** — a system that assembles *every* memory into every prompt passes every recall probe and is a context-engineering disaster. So recall probes ship **paired** with a precision measurement, and neither number is reported alone. Phase 6 printed recall and not precision and it cost the book a phase.

**Concept check 8.14.** Design a probe that a system with working retrieval and a **broken write gate that stores every user turn** would *fail*. Then say which of the two numbers catches it.

## 7. [core] Hands-on: build it step by step

Eleven steps. Each module depends only on the ones before it, so `make test-offline` is green after every step. `git checkout -b phase-08 phase-07`; you start at **1,074 passed** and finish at **1,220 passed, 12 skipped**.

```
atlas/memory/
  tokens.py     STEP 1   the unit. Nothing can be budgeted until this exists.
  buffer.py     STEPS 2-4  short-term: eviction, pinning, compaction, pruning.
  store.py      STEPS 5-7  long-term: schema, gate, score, forgetting.
  assemble.py   STEP 8   the cache-ordered assembler with a composition log.
  skills.py     STEP 9   SKILL.md loading, and deterministic activation.
  tools.py      STEP 10  remember / recall.
  session.py    STEP 11  the once-per-run holder, the pre-step, the wiring.
```

### 8.14 [core] Step 1 — the estimator, and why it is called `estimate_`

```python
# excerpt: atlas/memory/tokens.py
CHARS_PER_TOKEN = 4.0

MESSAGE_OVERHEAD_TOKENS = 4


def estimate_tokens(text: str, *, chars_per_token: float = CHARS_PER_TOKEN) -> int:
    """Estimate the token count of `text`. Pure; never a measurement.

    Named `estimate_` and not `count_` on purpose: a function called
    `count_tokens` that returns an estimate is a lie with a type signature.

    Rounds UP, so the empty string costs 0 and a single character costs 1. A
    budget that rounds down accumulates a fractional token per block and
    overshoots on a prompt with many blocks.
    """
    if chars_per_token <= 0:
        raise ValueError(f"chars_per_token must be positive, got {chars_per_token}")
    if not text:
        return 0
    return int((len(text) + chars_per_token - 1) // chars_per_token)
```

**Why the constant is one module-level name and not a `// 4` at five call sites.** Five places in this phase divide characters by tokens. Inlined, `make results`' calibration row would be interesting and not actionable — you would have to find and change five numbers to act on it. One name means the whole phase's budgets move together.

**Why `MESSAGE_OVERHEAD_TOKENS` exists.** Every message costs more than its content: the role, the delimiters the runner inserts, sometimes a name field. Four per message is the conventional crude allowance, and it earns its place because a forty-turn buffer of short turns is 160 tokens of pure framing that a content-only estimator reports as almost nothing — and the buffer's whole job is to be right about the size of a forty-turn history.

**Why `fits` takes a fraction rather than a token reserve.**

```python
# excerpt: atlas/memory/tokens.py
def fits(tokens: int, budget: int, *, margin: float = 0.0) -> bool:
    """Does `tokens` fit in `budget` with `margin` held back? Pure.

    `margin` is a FRACTION of the budget, not a token count, so a caller who
    changes `num_ctx` does not have to remember to change a second number. A
    margin of 0.1 on a 4096 budget holds back 409 tokens for the estimator's
    own error -- see the module docstring on why the reserve exists at all.
    """
```

A reserve in tokens silently becomes wrong when someone raises `ATLAS_NUM_CTX` from 4,096 to 32,768: 400 tokens was a 10% cushion and is now 1%. As a fraction it tracks.

**And calibration, which is the point of the module.** `usage.prompt_tokens` is the model's own tokenizer counting the prompt Atlas actually sent, and Atlas has been receiving it since Phase 0 without comparing it to anything.

```python
# excerpt: atlas/memory/tokens.py
def calibrate(
    samples: Sequence[tuple[str, int]],
    *,
    chars_per_token: float = CHARS_PER_TOKEN,
) -> TokenCalibration:
    """Compare `estimate_tokens` against reported truth. Pure.

    `samples` is a sequence of (prompt_text, reported_prompt_tokens). Raises on
    an empty sequence rather than returning a zero-sample calibration: a ratio
    computed from nothing is a number that will be quoted.
    """
```

`ratio` is `actual / estimated` and `undercounts` is `ratio > 1.0` — **direction**, not just magnitude, because the two errors have opposite remedies: overcounting wastes window, undercounting truncates your system prompt.

**Test note.** Nothing in `tests/test_memory_tokens.py` asserts that 4.0 is *correct* — that is model behaviour (invariant 1). It asserts monotonicity, rounding up, refusal of a non-positive constant, per-message framing, and that `calibrate` gets the direction right on a hand-computed example: 400 characters reported as 140 tokens is an estimate of 100, a ratio of 1.4, `undercounts is True`.

**Concept check 8.15.** `estimate_tokens("")` is 0 and `estimate_tokens("a")` is 1. Explain why rounding *down* would produce a worse failure than rounding up, in terms of which end of the prompt the provider truncates.

### 8.15 [core] Step 2 — the buffer, and a correction to §8.4

```python
# excerpt: atlas/memory/buffer.py
class Turn(BaseModel):
    """One message in a conversation, with its budget cost and its pin.

    Frozen: a turn whose content can be mutated after its tokens were counted
    is a turn whose cost is a lie. Same argument as `Prompt` being frozen in
    `atlas.prompts` -- the whole value of measuring something is that the thing
    in the process is the thing that was measured.
    """

    model_config = ConfigDict(frozen=True)

    index: int
    role: Literal["system", "user", "assistant", "tool"]
    content: str
    pinned: bool = False
    pin_reason: PinReason | None = None

    @computed_field  # type: ignore[prop-decorator]
    @property
    def tokens(self) -> int:
```

`tokens` is a `computed_field` rather than a bare `@property` because an eval check naming `trajectory.turns.3.tokens` has to survive `model_dump()` (invariant 11).

```python
# excerpt: atlas/memory/buffer.py
def propose_pin(text: str) -> PinReason | None:
    """Which kind of durable statement is this, if any? Pure.

    Deterministic, free, and checked in precedence order. Returns None for the
    ordinary case, which is most turns: a session in which everything is pinned
    has a pinned block equal to the whole history and no budget mechanism at
    all.
    """
    lowered = " " + text.lower().strip() + " "
    for reason in ("prohibition", "definition", "preference"):
        for cue in PIN_CUES[reason]:  # type: ignore[index]
            if cue in lowered:
                return reason  # type: ignore[return-value]
    return None
```

**Precedence is load-bearing.** "Always use ops, and never the shared drive" matches a preference cue (`always `) and a prohibition cue (`never `). Checking preference first would file the strongest kind of constraint under the weakest, which matters because kind sets base importance downstream. One test pins the order. And the cue set carries `atlas.rag.sources`' caveat verbatim: **the author wrote both the cues and the test sentences, so a reported accuracy is an upper bound, not an estimate.**

> **Correction to §8.4 (F-08-02).** The first draft of this tutorial gave nine turns of 40, 55, 30, 620, 45, 610, 35, 50, 40 tokens against a 400-token budget, and claimed policy (b) keeps three turns while policy (c) keeps six. **Those two claims assume different eviction policies and cannot both be true.** Writing the test exposed it. When the walk reaches the 610-token turn and it does not fit, there are two possible behaviours: *stop*, giving a contiguous window of the three most recent turns; or *skip and continue*, filling the budget greedily and giving seven turns with holes. Policy (b) assumed stop, policy (c) assumed skip.

```python
# excerpt: atlas/memory/buffer.py
    pinned = [t for t in turns if t.pinned]
    pinned_tokens = sum(t.tokens for t in pinned)
    if pinned_tokens > pin_token_cap:
        raise PinCapExceeded(
            f"{len(pinned)} pinned turn(s) cost {pinned_tokens} est tokens, over "
            f"the cap of {pin_token_cap}. Raise pin_token_cap, or drop a pin "
            "explicitly -- this function will not choose which constraint to "
            "violate."
        )

    kept_ids = {id(t) for t in pinned}
    remaining = budget - pinned_tokens
    # Newest-first, so the most recent narration survives. Ties cannot occur:
    # `index` is unique per buffer.
    for turn in sorted((t for t in turns if not t.pinned), key=lambda t: -t.index):
        if turn.tokens <= remaining:
            kept_ids.add(id(turn))
            remaining -= turn.tokens
        elif contiguous:
            break
```

The `contiguous` parameter exists because of that correction, and its default is argued in the docstring:

```python
# excerpt: atlas/memory/buffer.py
    * `contiguous=True` (default) STOPS. The unpinned window is a genuine
      sliding window: a contiguous run of the most recent turns. One oversized
      turn -- a 600-token file read -- therefore truncates the history at that
      point, and everything older is unreachable however much budget remains.
      That is the correct default, because a window with holes is a
      conversation the model misreads: it sees turn 3 then turn 5, and turn 5's
      "that number" refers to something that is no longer there.
```

The four combinations, measured:

```
sizes 40 55 30 620 45 610 35 50 40  (+4 framing each), budget 400

contiguous, no pin:  kept [6,7,8]          = 137 tok   constraint at t1: GONE
contiguous, pin t1:  kept [1,6,7,8]        = 196 tok   constraint: PRESENT
greedy,     no pin:  kept [0,1,2,4,6,7,8]  = 323 tok   holes at 3 and 5
greedy,     pin t1:  kept [0,1,2,4,6,7,8]  = 323 tok   (t1 already fitted)
```

So the corrected claim, which the test now pins: **under the contiguous policy, pinning retains four turns where plain eviction retains three, and it is the only reason the constraint is reachable at all.** Note what the pin actually bought. Not slack — pinning *spends* 59 tokens of a 400-token budget. It bought **reachability**: with a 614-token turn between turn 1 and the recent run, no budget under the contiguous policy could have reached turn 1.

```python
# excerpt: atlas/memory/buffer.py
class PinCapExceeded(RuntimeError):
    """The pinned block alone exceeds its cap. Named for its remedy.

    Raised rather than resolved, because every available resolution is worse.
    Dropping the oldest pin silently violates the constraint the pin existed to
    protect. Scoring pins and dropping the lowest turns a hard guarantee back
    into a continuum, and a continuum under pressure eventually drops your
    highest-scored item. So: refuse, loudly, with the count in the message.
    """
```

Two tests cover it, and the second is worth copying: the cap is checked **before** any eviction, so a generous budget still raises. Discovering at the end that the pinned survivors do not fit — after dropping narration to make room — wastes the narration *and* reports the wrong failure.

**Your turn (10 minutes).** `select_window` returns `kept` in **original order**, not in the newest-first order the loop walked. Delete the reordering and see which test catches it. Then write down what the symptom would look like in production if no test had — the failure is not an exception, and that is the point.

### 8.16 [core] Step 3 — compaction, and what a scripted fixture can prove

`compact` is the only function in the module that can call a model, and its shape is entirely about what it does *not* do:

```python
# excerpt: atlas/memory/buffer.py
    selection = buffer.window()
    to_summarise = [t for t in selection.dropped if not t.pinned]
    before = buffer.total_tokens
```

That is invariant 55 in three lines. The summariser's input is `selection.dropped` **minus the pinned turns**, so a pinned constraint is not in the prompt, so the model cannot drop it. **The guarantee is a filter in Python, not a sentence in a prompt.**

```python
# excerpt: atlas/memory/buffer.py
    fallback = mechanical_summary(to_summarise, max_chars=max_chars)
    previous = f"{buffer.summary}\n" if buffer.summary else ""
    summary, consulted, error = f"{previous}{fallback}".strip(), False, ""
```

The mechanical summary is computed **first and unconditionally**. If the model arm succeeds its output replaces the fallback; if it fails, raises, or returns empty, the fallback stands and the failure is recorded in `error` — the `grade_hits` contract transplanted. And the fallback labels itself:

```python
# excerpt: atlas/memory/buffer.py
    joined = "; ".join(parts)
    if len(joined) > max_chars:
        joined = joined[: max_chars - 1].rstrip() + "…"
    return f"(extractive, no model) {joined}"
```

**The session, run.** Eleven turns of realistic operations chat, budget 300:

```
t 0 user       19 tok
t 1 assistant  11 tok
t 2 user       22 tok  PIN[prohibition]     "...never the shared drive."
t 3 assistant  21 tok
t 4 user       25 tok  PIN[definition]      "We count a unit as shipped when..."
t 5 assistant  18 tok
t 6 user       18 tok
t 7 assistant  17 tok
t 8 user       14 tok
t 9 assistant  14 tok
t10 user       22 tok                       "Save a one-page summary somewhere..."

buffer: 11 turns, 201 est tok, 2 pinned (47 tok)
window: 11 turn(s), 201/300 est tok (fill 67%), pinned 47, dropped none
```

Two pins fired from the deterministic rule with no model. Squeeze the budget and compaction engages, and at every budget `pinned present after compaction: [2, 4]`:

```
budget 300: window kept [0..10];        compaction: 0 turns   201 -> 201 tok
budget 120: window kept [2,4,7,8,9,10]; compaction: 5 turns   201 -> 161 tok (0.80)
budget  80: window kept [2,4,10];       compaction: 8 turns   201 -> 159 tok (0.79)
```

**But the honest part, and it is the most important paragraph in this section.** Run the budget-80 case with pinning *disabled* — the counterfactual that should exhibit the failure — and the constraint **still survives**, because `mechanical_summary` is extractive: it copies the first sentence of each dropped turn, and t2's first sentence *is* the constraint. **A first-sentence extractor cannot lose a constraint.** So on Tier F the failure this phase exists to prevent is unreachable.

That is not a bug in the fallback. It is the boundary of what a mechanical component can demonstrate, and the fix is a **scripted fixture**:

```
LOSSY = ("The user asked for Q1 2026 S400 shipment figures. Total is 71 units, split "
         "North 22, South 18, East 16, West 15. Warranty claims: 43 in total, 11 in "
         "Q1 2026. The user then asked for a written summary.")
```

That summary is *good*. It keeps every number, names the open request, and reads like competent work. It simply does not mention the ops workspace, because nothing in it was wrong and nothing asked it to. Both arms:

```
pinning=False: model summary used, 201->117 tok
   'shared drive' survives: False
   'invoiced' survives:     False
   summariser was shown the constraint: True

pinning=True:  model summary used, 201->119 tok
   'shared drive' survives: True
   'invoiced' survives:     True
   summariser was shown the constraint: False
```

Two constraints lost in the first arm, both retained in the second, at a cost of **two tokens**. The third line of each block is the invariant, measured: in the pinned arm the summariser was never shown the constraint, which is why it could not lose it.

> **What scripted fixtures prove, and what they do not.** A scripted fixture is a hand-written model reply that `FakeLLMClient` returns instead of calling a model. It proves things about *your code's response to a given output*: that `compact` retains pinned turns when the summary omits them, that a `FixtureExhausted` leaves the mechanical summary standing, that the summariser's prompt does not contain a pinned turn. Those are properties of control flow, filtering and record-keeping, and they are exactly what a test should own — deterministic, fast, unchanged when you switch models. What a fixture cannot prove is **that a real summariser drops constraints at any particular rate**, or that this one drops them at all. The `LOSSY` fixture is a hypothesis about model behaviour, written by the author, and only as representative as the author's judgement. So the fixture establishes that the *mechanism* works if the risk is real, and `make results` on Tier A/H establishes how often the risk is real — which is why the compaction rows live in `docs/RESULTS.md` and none of it lives in a test (invariant 1). **A fixture is evidence about your program. It is never evidence about a model.**

**Concept check 8.16.** Someone concludes Atlas should never use the model arm. Give the two things the extractive summary loses that the model summary keeps, and say which `docs/RESULTS.md` row settles the trade.

### 8.17 [core] Step 4 — tool-result pruning, the cheapest lever

§8.5 ranked the levers cheapest and safest first: clear consumed tool results, then evict unpinned narration, then compact. Only the second and third existed in the first cut of this phase, and the first is the one you should reach for.

```python
# excerpt: atlas/memory/buffer.py
    `clear_at_least` is the reason this is a wrapper-shaped function rather than
    an unconditional loop, and it comes straight from §8.10's tension: clearing
    content from the MIDDLE of a prompt changes the prefix, so it invalidates
    every cached block after the cleared point. Reclaiming 40 tokens by
    destroying a 1,500-token cached prefix is a loss. So the prune is all-or-
    nothing: if the candidates together free less than `clear_at_least`, nothing
    is cleared and 0 is returned.
```

Three decisions, each with a reason you can check.

**`keep_recent` protects the newest results**, because the model may still be reasoning over them; only older ones are candidates.

**A cleared turn is replaced by a stub, not removed.** Removing it would leave the model's own tool call answered by nothing, which reads as a tool that failed silently — and a reader of the trace must be able to see that a result was *cleared* rather than *never obtained* (invariant 15).

**The prune is all-or-nothing.** Measured:

| `clear_at_least` | tokens freed | before | after |
|---|---|---|---|
| 0 | 208 | 717 | 509 |
| 200 | 208 | 717 | 509 |
| 5,000 | **0** | 717 | 717 |

A prune too small to justify breaking the cached prefix frees **nothing**. That is §8.10's tension as a measured behaviour rather than a warning, and it is why the provider feature has the same parameter. When `clear_tool_uses_20250919` leaves beta this function becomes a thin wrapper over it — see the VERSIONS.md pre-release row — and the parameter names are chosen to match.

**Concept header note.** Pruning is *targeted deletion of consumed information*; compaction is *lossy rewriting of information whose usefulness has not expired*. That is why one is nearly free and the other costs a model call and can lose a constraint, and it is why they are two functions rather than one.

### 8.18 [core] Steps 5–7 — the long-term store

Nine lines of DDL and one index:

```python
# excerpt: atlas/memory/store.py
CREATE TABLE IF NOT EXISTS memories (
    id             TEXT PRIMARY KEY,
    user_id        TEXT NOT NULL,
    scope          TEXT NOT NULL,
    kind           TEXT NOT NULL,
    text           TEXT NOT NULL,
    created_at     TEXT NOT NULL,
    last_used_at   TEXT NOT NULL,
    uses           INTEGER NOT NULL DEFAULT 0,
    importance     REAL    NOT NULL DEFAULT 0.0,
    source_session TEXT    NOT NULL DEFAULT '',
    superseded_by  TEXT,
    expires_at     TEXT,
    redactions     TEXT    NOT NULL DEFAULT '',
    embedding      TEXT    NOT NULL DEFAULT ''
);
CREATE INDEX IF NOT EXISTS ix_memories_user ON memories(user_id, scope);
```

`embedding` is a column of the row it belongs to — D-43 made concrete: there is no code path here that can return a memory id the table does not contain. `IF NOT EXISTS` everywhere makes `ensure_schema()` safe on every open, so there is no migration state.

```python
# excerpt: atlas/memory/store.py
def memory_id(*, user_id: str, scope: str, text: str) -> str:
    """A content-addressed id: 16 hex over (scope, user, text).

    Hashes the WORK, not the attempt -- no timestamp, no session id, no
    counter. Exactly `atlas.flow.state.idem_key`'s rule (D-23), and it buys the
    same thing: writing the same statement twice is idempotent, so a retried
    session does not double the store. The user is in the key because the same
    sentence from two people is two memories; the scope is in the key because
    promoting a user memory to org scope is a new row, not an edit.
    """
```

**The gate.** Five clauses, in order, all free. Clause 1 is the cheapest safeguard in the phase and it is one `if`:

```python
# excerpt: atlas/memory/store.py
    if role != "user":
        return WriteDecision(
            write=False,
            refusal="not_user_turn",
            reason=f"role {role!r}: Atlas never remembers its own output or a tool's",
        )
```

It covers `role == "tool"` too, which a test pins: tool output is Phase 14's injection surface and is not eligible for durable storage.

```python
# excerpt: atlas/memory/store.py
            reason=(
                f"{len(stripped)} chars, ceiling {MAX_TEXT_CHARS}: a statement this "
                "long is a document, and belongs in the document corpus where it "
                "can be chunked, graded and cited"
            ),
```

**The cue table is a tuple of ordered rows, not a dict**, and the comment records why:

```python
# excerpt: atlas/memory/store.py
# A TUPLE OF ROWS, not a dict keyed by (kind, scope) -- and the change is worth
# recording, because the dict version silently deleted a cell. F-08-04's fix
# added a prohibition group that is also semantic/org but carries a higher base
# importance, and as a second entry under the same dict key it was overwritten
# by the existing one at import time, with no error and no test failure. A
# mapping cannot express two cue groups for one cell; an ordered sequence can,
# and its order is the precedence, visibly, in the source.
```

Measured, the gate on eight turns:

```
user      We count a unit as shipped when it leaves the wareho... -> write: semantic/org  0.90
user      Call me Pri, not Priya.                                -> write: semantic/user 0.60
user      I'm working on the warranty review this month.         -> write: episodic/user 0.30
user      hi                                                     -> no write: too_short
assistant We define shipped as left the warehouse.               -> no write: not_user_turn
user      What were Q1 shipments?                                -> no write: no_durable_cue
user      The way we do quarterly numbers is to read v_shipmen... -> write: procedural/org 0.95
user      Email me at priya.n@example.com when it's ready...     -> no write: no_durable_cue
count: 4
```

Four rows from eight turns, one per cell of the taxonomy. Note the last line: the PII-bearing turn was refused for **no durable cue**, before redaction was reached — a statement not worth remembering is not worth redacting either.

**F-08-01, the defect this step produced.** `decide()` embedded the *raw* text while `write` stored the *redacted* text:

```python
# excerpt: atlas/memory/store.py
        # Embed `cheap.text`, which is the REDACTED form, and not the raw input.
        # The first version of this line embedded the raw text while `write`
        # stored the redacted one, so the duplicate check compared a vector of
        # "...priya.n@example.com" against a stored vector of "...[email
        # redacted]", scored 0.673 (measured, HashingEmbedder dim=256), and
        # reported a write for a statement already
        # in the table. Redaction defeated deduplication. There must be exactly
        # ONE canonical text per memory, and it is the redacted one, because
        # that is the one on disk. See F-08-01.
        vector = self._embed_one(cheap.text)
```

```
verbatim           cosine 1.000
paraphrase         cosine 0.751
raw-vs-redacted    cosine 0.673      <- the defect
unrelated          cosine 0.068
```

The damage was subtle: the upsert meant no duplicate *row* appeared, so the table stayed correct and the *decision record* lied.

> **There must be exactly one canonical form of a memory, and it is the one on disk.** Any transformation on the write path — redaction, normalisation, truncation, case folding — happens before anything that compares, hashes or embeds. A cosine between vectors from two different *texts* is as meaningless as one between vectors from two different *embedders*.

Honest limitation, stated rather than discovered: the paraphrase row is 0.751, so dedup at this floor catches literal repeats and not paraphrases. Lowering it would start refusing genuinely distinct statements. That is calibration, it depends on the embedder, and §11 sweeps it.

**The three-term score.**

```python
# excerpt: atlas/memory/store.py
def recency_score(age_hours: float, *, decay: float = DEFAULT_DECAY_PER_HOUR) -> float:
    """Park et al.'s exponential freshness: decay ** hours. Pure.

    Takes AGE rather than two timestamps so it can be tested without a clock,
    and so the caller is forced to decide which timestamp the age is measured
    from. Atlas measures from `last_used_at`, not `created_at`: decaying on
    creation means a memory consulted daily fades at the same rate as one
    nobody has read since it was written, which is exactly backwards.
    """
```

Negative ages clamp to 1.0: a clock skew is not a freshness bonus.

```python
# excerpt: atlas/memory/store.py
def minmax(values: Sequence[float]) -> list[float]:
    """Scale to [0, 1] over the candidate set. Pure.

    Makes three terms on different scales comparable, and in doing so makes the
    resulting score INCOMPARABLE ACROSS QUERIES -- exactly the property Phase
    6's min-maxed fusion scores had, and the reason Phase 7 could not threshold
    them. So the score ranks and never gates: there is no `score_floor`
    anywhere in this module, because a threshold on a per-query-normalised
    quantity is a threshold on the shape of the candidate set.

    A degenerate set (all equal, or one element) maps to 1.0 rather than 0.0:
    zero would silently delete a whole term from the sum whenever a user's
    memories happen to be the same age.
    """
```

The degenerate-set choice matters more than it looks: three memories written in the same session have identical `last_used_at`, so raw recency is identical and min-max is a division by zero. Mapping to 0.0 would zero out the recency term for the whole query, silently, only when a user has just started.

And the no-threshold rule is asserted over **signatures**, not source text:

```python
# excerpt: tests/test_memory_store.py
def test_no_public_entry_point_accepts_a_score_threshold() -> None:
    """The score RANKS and never gates, because min-max is per-query.

    Asserted over SIGNATURES rather than by grepping the source: the first
    version of this test searched the module text and failed on the docstring
    explaining why there is no threshold, which is a test asserting that its
    own rationale is unwritten.
    """
```

Measured, four memories, *"what do we count as shipped?"*, frozen clock:

```
recall for priya: 4 of 4 candidate(s), k=4, thin 1.00, max cos 0.25
  #1 2.923 (rec 1.00 rel 1.00 imp 0.92) [semantic/org] We count a unit as shipped...
  #2 2.000 (rec 1.00 rel 0.00 imp 1.00) [procedural/org] The way we do quarterly...
  #3 1.716 (rec 1.00 rel 0.25 imp 0.46) [semantic/user] Call me Pri, not Priya.
  #4 1.071 (rec 1.00 rel 0.07 imp 0.00) [episodic/user] I'm working on the warranty...
```

Recency is **1.00 on all four**, because all four were written at the frozen clock — the degenerate case doing its job, and a reminder that this example measures nothing about recency.

**And the hazard.** After a supersession the candidate set drops to two and the composite becomes **{3.000, 0.000}** — as it would for *any* two candidates, however close their raw values:

```python
# excerpt: tests/test_memory_store.py
def test_minmax_on_two_candidates_forces_a_zero_and_a_one() -> None:
    """The documented small-corpus hazard (§11 reports its frequency).

    With two candidates every term is 0.0 for one row and 1.0 for the other, so
    the composite is always {3.0, 0.0} and the three terms carry no information
    at all. Memory corpora are small enough for this to happen in a real
    session, unlike Phase 6's document candidate sets.
    """
    assert minmax([0.90, 0.89]) == [1.0, 0.0]
    assert minmax([0.90, 0.01]) == [1.0, 0.0]
```

A 0.01 gap and a 0.89 gap normalise identically. This is min-max used on a candidate set too small for it, and it is **specific to memory**: a document corpus produces twenty candidates, a user's first week produces two. Atlas does not fix it, because every available fix introduces a threshold on the shape of the candidate set. So it is documented, tested and reported — and §11's experiment 8 shows it costing a real probe.

**The two gates, and F-08-08.** The first cut of this phase claimed `stale` and `out_of_scope` gate. Neither could fire. `out_of_scope` was a literal `False`; `stale` was computed against `STALENESS_DAYS`, *the same constant `expires_at` uses*, so every row old enough to be stale had already been dropped as expired one step earlier. Verified: at 44 days `stale=False`, at 46 days the row is gone.

```python
# excerpt: atlas/memory/store.py
# The SOFT horizon: old enough to doubt, not old enough to drop. Strictly
# shorter than the hard TTL above, and that is the whole point -- the first
# version computed `stale` against `STALENESS_DAYS`, the same constant that
# `expires_at` uses, so every row old enough to be stale had already been
# filtered out as expired and the flag could never be True. A gate that cannot
# fire is worse than an absent one, because it reads as protection. See
# F-08-08 and invariant 30.
SOFT_STALENESS_DAYS: dict[MemoryKind, int] = {
    "episodic": 21,
    "semantic": 180,
    "procedural": 365,
}
```

`out_of_scope` now requires **both** halves — a first-person cue in the query *and* every hit org-scoped — because either alone fires constantly:

```python
# excerpt: atlas/memory/store.py
        padded = " " + query.lower().strip() + " "
        personal = any(cue in padded for cue in PERSONAL_CUES)
        out_of_scope = bool(hits) and personal and all(
            h.record.scope == "org" for h in hits
        )
```

> **Invariant 57.** **A gate ships with a test that makes it fire.** Invariant 30 says a closed-set member needs a line of code that sets it; the same holds for any boolean a branch reads. **A gate that cannot fire is worse than an absent one, because it reads as protection.** Corollary: when a soft warning and a hard cutoff are derived from one constant, the warning is dead. Give them separate constants and assert the ordering.

**Forgetting, supersession, deletion.** Expiry is a **read-time filter** and a test asserts the row is still on disk — the distinction is the point. Supersession is **append-only**, so after superseding the new row is a candidate, the old one is not, and `count()` is 2. Deletion **deletes**, asserted three ways: rows gone, retrieval empty, `count(user_id=...)` zero. Asserting only the empty retrieval would pass for a system that flagged and filtered.

```python
# excerpt: atlas/memory/store.py
    def delete_user(self, user_id: str) -> int:
        """Delete every row belonging to `user_id`. Real deletion, not a flag.

        Expiry (`prune`) makes a memory stop being a candidate; this makes it
        stop existing. A system that implements only the first and calls it
        deletion has a documentation defect with legal consequences. Because the
        vector index IS a column of the row, there is no second system to keep
        in step -- which is the whole reason for §8.7's storage decision.
```

One deliberate asymmetry: `delete_user("priya")` on three of her rows deletes **one**, because it filters `scope='user'`. The others are org-scoped — the company's vocabulary, stated by Priya but not *about* Priya — and an erasure that silently removed the company's definitions would be a different incident, one where the next person's answers change and nobody knows why. `delete_session` is the tool for the case where the statement itself must go. Whether that is the right default is a policy question, and §15 asks you to decide it under real constraints; what the engineering owes you is that **both operations exist, both are commands, and the distinction is in the docstring rather than discovered in an audit.**

### 8.19 [core] Step 8 — the assembler, and a drop that was not survivable

```python
# excerpt: atlas/memory/assemble.py
    1. Empty blocks are discarded silently. A heading with nothing under it
       costs tokens and teaches the model that a section can be empty.
    2. REQUIRED blocks are reserved first, in volatility order. If they alone
       exceed the usable budget, raise `BudgetTooSmall` -- there is no correct
       way to choose which non-negotiable block to omit.
    3. Optional blocks are then added in volatility order, so a static block
       wins a tie against a volatile one. Within a volatility band, input order
       is preserved, so the caller's priority is respected.
    4. An optional block that does not fit is DROPPED BY NAME and the walk
       CONTINUES -- unlike the buffer's contiguous eviction, because context
       blocks are independent sections rather than a conversation, so a gap
       between two of them misleads nobody.
```

Clause 4 *contradicts* §8.15's default, deliberately. The buffer stops at the first turn that does not fit because a conversation with a hole misleads; context blocks are labelled independent sections, so dropping `extracts` does not make `history` confusing. **Same problem, opposite answer, and the difference is whether the items are a sequence or a set.**

```python
# excerpt: atlas/memory/assemble.py
        """Tokens in the leading STATIC run: what a prefix cache could reuse.

        Computed from the leading run rather than from every static block,
        because a cache hit is a property of a PREFIX. One volatile block
        placed early would make every static block after it uncacheable, and
        this number is what makes that mistake visible instead of theoretical.
        """
```

**Atlas's context, assembled and printed for real** — the `data` route through `handle_request`, skill activated, budget 3,072:

```
context: 1637/2611 est tok (budget 3072, margin 15%, fill 63%), cacheable prefix 990 tok
  static   tool_schemas             351 tok   21.4%  [required]
  static   instructions             506 tok   30.9%  [required]
  static   skill_catalogue          133 tok    8.1%
  slow     profile                   10 tok    0.6%
  slow     memories                  35 tok    2.1%
  slow     skill_body               573 tok   35.0%
  volatile history                   16 tok    1.0%
  volatile question                  13 tok    0.8%  [required]
```

Read the composition. **60% of this prompt is static**, byte-identical to the previous request, and the history and question together are 1.8%. On the `research` route with five tools the static share is 90%.

**F-08-03, the defect.** `tool_schemas` was optional. At a 1,400-token budget the assembler reported, honestly, `DROPPED (did not fit): tool_schemas, skill_body` — and handed a ReAct handler a prompt with **no action space at all**.

```python
# excerpt: atlas/memory/session.py
                # F-08-03. This was optional in the first version, and at a
                # 1,400-token budget the assembler dropped it -- reporting the
                # drop honestly, and handing the research route a prompt with
                # no action space at all. The handler would then emit tool
                # calls against schemas the model never saw, or none, and the
                # trace would show a competent-looking failure to use tools.
                # An EMPTY schema block is discarded before the required check
                # runs, so `chat` (which has no tools) is unaffected. Invariant
                # 52's shape for the third time: reporting a drop is not the
                # same as the drop being survivable.
                required=True,
```

With the fix, the same budget refuses:

```
required blocks (tool_schemas, instructions, question) cost 1410 est tokens and
the usable budget is 1190 of 1400. Raise the budget, shorten a required block,
or make one optional -- this function will not choose which non-negotiable
block to omit.
```

> **Invariant 56.** **A context budget that cannot be exceeded does not make the right things present.** Corollary: **reporting a drop is not the same as the drop being survivable.** Classify every block by whether its absence *degrades the answer* or *breaks the mechanism*, and mark the second kind required.

**Concept check 8.19.** `skill_body` is optional. Is that right by invariant 56's test? Argue both sides, then say what the model actually does when the catalogue advertises a skill whose body never arrives — and why that failure mode is *better* than the tool-schema one.

### 8.20 [core] Step 9 — the skill, its triggers, and the wiring nobody switched on

Level 1 is the frontmatter, and it is what every request pays for:

```markdown
---
name: northwind-quarterly
description: Answer questions about Northwind quarterly shipment and warranty figures. Use when a request mentions a quarter (Q1, Q2, Q3, Q4, "last quarter", "this quarter") together with shipments, units shipped, deliveries, warranty claims or returns. Covers which relation to read, how quarter labels are written, and what "shipped" counts as.
license: internal
metadata:
  phase: "8"
  owner: operations
  triggers: quarter quarterly q1 q2 q3 q4 shipments shipped units deliveries warranty claims returns
---
```

The description does three things a careless one would not: says **what**, says **when**, and does so in **words a user would actually type**. "Northwind quarterly reporting conventions" is shorter, cheaper and never activates.

Measured: L1 **89**, L2 **565**, L3 **370** estimated tokens; catalogue preamble plus summaries **133** paid every request. **Break-even 84.2%**, from `p = (L2 − L1)/L2`. Progressive disclosure **saves tokens unless the skill fires on more than 84% of requests**, and the crossover *rises* with L2 — a 2,000-token body breaks even at 95.5%. **The technique wins by a bigger margin the longer the instructions are**, which is why it is for procedures and not one-line rules.

The parser **refuses** unknown keys, and one test names the symptom rather than the rule:

```python
# excerpt: tests/test_memory_assemble.py
def test_an_unknown_frontmatter_key_is_refused_not_ignored() -> None:
    # Refused loudly so a typo is discoverable: `descripton` in a permissive
    # loader produces a skill with an empty description that never activates.
    with pytest.raises(SkillError, match="unknown frontmatter key"):
        parse_frontmatter("---\nname: demo\ndescription: d\ndescripton: oops\n---\nbody\n")
```

Level 3 gets the jail check from `atlas.tools.files` unchanged: **resolve, then verify the result is inside the root — never inspect the input for `..` and hope.** And a skill gets a pinned checksum (`cd6752e1cc34`) exactly like a prompt.

**Now the defect that mattered most in this phase, F-08-07.** The first cut had all of the above, 45 passing tests, a pinned checksum — and **nothing that selected a skill from a request.** `SessionMemory.blocks` took `skill=` as a keyword and `handle_request` never passed one. §11 claimed "loads one skill progressively" and the running system could not.

Three halves, and each is a separate lesson.

**One: nothing selected.** So `atlas.memory.skills` was invariant 41's fifth appearance — a module tested to 45/45 and reachable from nothing on the live path.

**Two: the budget made it impossible anyway.** `DEFAULT_CONTEXT_BUDGET` was 0.6 of `num_ctx`, chosen so the seeded demos would exercise the drop path. That is starving the prompt in order to demonstrate a feature, and `skill_body` (573 est tok) fitted at no realistic composition. `make results` printed `dropped: skill_body` and I read it as a demonstration rather than as a defect.

**Three: the pre-step assembled a prompt nobody sent.** It passed neither `instructions` nor `tool_schemas`, so the composition log described a prompt with no system text and no tools — F-07-06 with a new record type.

The fix, and the design decisions in it:

```python
# excerpt: atlas/memory/skills.py
def select_skill(catalogue: SkillCatalogue, request: str) -> Skill | None:
    """Which skill, if any, this request should load in full. Pure.

    Deterministic and free. The alternative — asking a model which skill to
    load — is a model-owned branch over a set Atlas can enumerate, which
    invariant 33 forbids while a catalogue is this small. When the catalogue
    grows past what a router can enumerate, this function is the place the
    model arm attaches, and it may only NARROW the selection (D-44's direction
    again).

    Returns None below `MIN_TRIGGER_MATCHES`, because "no skill" is the common
    and correct answer: a selector that always activates something has moved
    every skill body into the static floor by another route.

    Ties break by name, so activation is a function of the data and not of
    directory order (invariant 22).
    """
```

**Triggers are written down, not inferred.**

```python
# excerpt: atlas/memory/skills.py
        """The words that activate this skill, from `metadata["triggers"]`.

        Explicit rather than inferred from the description, and the reason is
        the one §8.9 gives: level 1 is a retrieval problem with a MODEL as the
        retriever, and Atlas's selector is a cheap deterministic stand-in for
        that model. Inferring triggers by stripping stop-words from a
        description would make a wording change silently change activation
        behaviour, which is the same class of defect as a stale schema block
        (F-07-01). Written down, they are reviewable and diffable.
```

**A count is thresholded, not a normalised share** — the one place in this phase where a threshold is defensible, and the docstring says why:

```python
# excerpt: atlas/memory/skills.py
    A COUNT, not a normalised share, and that is deliberate. Phase 7 spent a
    section establishing that a threshold on a per-query-normalised quantity is
    a threshold on the shape of the query; a count of matched trigger words is
    normalised by nothing and comparable across requests, so
    `MIN_TRIGGER_MATCHES` is a threshold you can reason about.
```

Two rather than one, and measured:

```
matches  activated              request
      2  northwind-quarterly    What were Q1 shipments for the S400 line?
      1  None                   How long is the standard warranty?
      0  None                   Who is the head of support?
      3  northwind-quarterly    warranty claims last quarter
```

The second row is the reason for two: "warranty" alone is a *document* question, and activating a data procedure on it would cost 565 tokens and dilute attention over an irrelevant set of steps.

**And selection lives inside the component.**

```python
# excerpt: atlas/memory/session.py
        The skill is selected HERE rather than by the caller, because a
        capability the caller has to remember to switch on is a capability that
        is off in production. The first version of this method took `skill` as
        a keyword and `handle_request` never passed one, so `atlas.memory.skills`
        was a module tested to 45/45 and reachable from nothing on the live
        path -- invariant 41's FIFTH appearance, in the phase that names it.
        See F-08-07.
```

> **Invariant 58.** **A capability the caller must remember to switch on is off in production.** Selection, activation and defaulting belong inside the component, reached from the public entry point, not in a keyword the composition layer forgets to pass. **The last step of a phase is grepping every capability claim in the capstone against a test that reaches it through that entry point** — and if a claim has no such test, it is not a capability, it is prose.

**Concept check 8.20.** The catalogue preamble plus one summary is 133 tokens, of which the summary is 89. Compute the level-1 cost of twenty skills, then say why the preamble is *not* multiplied — and what that implies about the marginal cost of the twenty-first skill.

**Concept check 8.22.** `select_skill` returns `None` below two trigger matches, and `MIN_TRIGGER_MATCHES` is a threshold on a count. Explain why that threshold is defensible where a `score_floor` on the memory score is not. Then name the one thing that would make the trigger count non-transferable in the way the IDF was.

### 8.21 [core] Steps 10–11 — the tools, the pre-step, and the wiring guard

```python
# excerpt: atlas/memory/tools.py
    recall(query, k)   read_only=True,  cacheable=True
    remember(text)     read_only=False, cacheable=False
```

```python
# excerpt: atlas/memory/tools.py
    A factory over an injected store, like every other tool in this package
    (invariant 10). The user id is bound HERE, at construction, and is not a
    tool parameter -- because a `user_id` argument the model fills in is an
    authorisation decision the model makes, and §8.6 established that scope is
    an authorisation question wearing a storage costume. The model cannot ask
    for somebody else's memories because there is no field in which to ask.
```

A test asserts `set(signature(remember).parameters) == {"text"}`. `remember` reports refusals verbatim rather than claiming success:

```
>>> remember(text="We count a unit as shipped when it leaves the warehouse.")
stored semantic/org — [memory u=priya s=s-1 2026-09-03 semantic/org]
>>> remember(text="What were Q1 shipments?")
not stored (no_durable_cue): no durable-statement cue fired; treated as conversation, not fact
```

**The wiring.** `HANDLER_TOOLS` gains two appends with the reasoning beside them:

```python
# excerpt: atlas/flow/app.py
# Phase 8, on the same principle and with the same reasoning as D-37. `recall`
# goes to `research` ONLY, because the pre-step in `SessionMemory.assemble`
# already puts the top-scoring memories in every route's context
# unconditionally -- so a second, model-chosen lookup is worth a tool slot only
# on the one route whose branch set cannot be enumerated at design time
# (invariant 33). Giving `document` a `recall` tool would pay a model call to
# decide something the pre-step already did. `remember` goes to `tool_action`
# ONLY, because it is the sole non-read-only tool this phase adds and
# `tool_action` is the route that already requires `allow_writes`. See D-42.
HANDLER_TOOLS["research"] += ("recall",)
HANDLER_TOOLS["tool_action"] += ("remember",)
```

An advertised tool that does not exist is F-07-05, so the Phase 7 guard gains a sibling — **invariant 41's fourth appearance, which is the honest measure of how easy the mistake is**:

```python
# excerpt: atlas/flow/app.py
    if memory is not None and "recall" not in registry.names:
        raise ValueError(
            "a memory was supplied to build_handlers but the registry has no "
            "`recall` tool, so the research route would be offered a capability "
            "that does not exist. Build the registry with "
            "build_default_registry(..., memory=memory)."
        )
```

And the pre-step, with the fix for F-08-07's third half:

```python
# excerpt: atlas/flow/app.py
    assembled = None
    if memory is not None:
        memory.observe("user", request)
        # The instructions and the scoped tool schemas are passed IN, not left
        # for the assembler to guess. The first version omitted both, so the
        # composition log described a prompt with no system text and no tools
        # -- a plausible rendering of something nobody sent, which is F-07-06's
        # defect with a new record type (invariant 54). The route is known here
        # because classification has already happened, so the schemas are the
        # ones this request's handler will actually be given.
        scoped = _scoped(registry, decision.route)
        assembled = memory.assemble(
            request,
            instructions=load_prompt("atlas_system").text,
            tool_schemas=json.dumps(scoped.to_wire()) if scoped.specs else "",
        )
```

The assembled context lands on `RoutedResult`, not only on `SessionMemory`, and a test asserts **object identity** — two equal-but-separate assemblies is exactly the F-07-06 bug:

```python
# excerpt: tests/test_memory_assemble.py
def test_a_skill_activates_through_handle_request(tmp_path) -> None:
    """F-08-07. The capability nobody switches on is off in production.

    The first version took `skill=` as a keyword on `blocks` and
    `handle_request` never passed one, so `atlas.memory.skills` was tested to
    45/45 and unreachable on the live path -- invariant 41's fifth appearance.
    This test reaches selection through the public entry point.
    """
```

### 8.22 [core] The three-session demo, and why it had to exist

`evals/memory_probes.py` is a committed seeded generator: nine probes over three sessions, six cross-session positives, one same-session control, two negatives, with expectations **derived** from the plants:

```python
# excerpt: evals/memory_probes.py
def probe_expectation(probe: Probe) -> str:
    """Derive the expected evidence substring from the probe's plant.

    Not typed alongside the probe. `PROBES` names a plant key; the expectation
    is looked up from `PLANTS`. Change a plant's wording and the expectation
    follows automatically, which is the whole content of invariant 32.
    """
```

The **same-session control** (`p7`) exists so the suite can tell a working buffer with a broken store from a working store. The **negatives** exist because a recall suite with no negatives measures only how eager the retriever is.

And then `make results --only sessions`, which runs three *real* sessions through `handle_request`:

```python
# excerpt: scripts/phase08_results.py
    It exists because the first version of this phase did not have it, and two
    defects survived as a direct result: the skill selector was never called on
    the live path (F-08-07) and the pre-step assembled a prompt with no
    instructions and no tool schemas (also F-08-07). Both are invisible to a
    unit test of any single module and obvious in the first line of this
    experiment's output. Invariant 46, paid for twice.
```

That is the pedagogical point of the whole section. Every module in this phase had thorough unit tests and the composition had none, and **the two worst defects in the phase lived exactly in the gap.**

### With an assistant [core]

**Safe to delegate.** The SQLite plumbing in `store.py` — the DDL string, `_to_record`, the upsert. The frontmatter parser, given `KNOWN_FRONTMATTER_KEYS`, the name regex, and the instruction to *refuse* unknown keys. The `render()`/`report()` formatting. Test scaffolding, once you have written the first three tests yourself so it has a house style.

**Not safe to delegate.** Every asymmetry in this phase, without exception. An assistant asked for "a memory system" will give you a `WriteDraft` with `should_remember: bool`, `importance: float` and `kind: str` — a model with full write authority, because that is what the training data is full of. It will give `SummaryDraft` a `preserved_constraints: list[str]` field, which is the exact field invariant 55 forbids. It will add a `min_score` to `retrieve`, because thresholds look like rigour. It will not know `tool_schemas` must be `required=True`. And it will happily write `select_skill` as a keyword argument nobody passes, because that is what the surrounding code did. **The direction a model may not move a decision in is the part you write yourself**, and it is about twenty lines.

**One prompt that works:**

> Here is `atlas/memory/store.py` with `MemoryRecord`, `WriteDecision` and `should_write` already written. Write `MemoryStore.retrieve` only. Requirements: filter by `user_id OR scope='org'` and drop `superseded_by IS NOT NULL` **in the SQL**, not after; drop rows whose `expires_at` is past `self.now()`; compute recency from `last_used_at` using the supplied `recency_score`, relevance as cosine, importance from the column; min-max each of the three over the candidate set using the supplied `minmax`; sum with `self.weights`; sort by `(-score, id)`. Do not add any threshold, floor, or `min_score` parameter — the score ranks and never gates, and I will reject a diff that adds one. Return `MemoryRetrieval` with `n_candidates` and per-hit components stored separately from the composite.

The specificity is the point: the constraints that matter are stated as prohibitions, and "I will reject a diff that adds one" is worth including because it survives the assistant's helpfulness.

**And one thing to do yourself, after the assistant has finished.** Take every capability sentence in your own §11 and grep for a test that reaches it through the public entry point. This phase shipped three claims that had no such test, and an assistant will not find them for you — it wrote the code that satisfied the unit tests.


## 8. [core] Debug this trace

```
r-0042: tool_action (confidence 1.00, source forced)
  buffer: 17 turns, 1,284 est tok -> compaction fired at turn 15
  compaction: 12 turn(s) -> model summary, 1284 -> 402 est tok (compression 0.31),
              0 pinned turn(s) untouched
  context: 1102/2088 est tok (budget 2457, margin 15%, fill 53%), cacheable prefix 1011 tok
    static   tool_schemas             505 tok   45.8%  [required]
    static   instructions             506 tok   45.9%  [required]
    slow     memories                   0 tok    0.0%
    volatile history                    69 tok    6.3%
    volatile question                   22 tok    2.0%

  # Earlier in this session
  The user asked for Q1 2026 S400 shipment figures. Total is 71 units, split
  North 22, South 18, East 16, West 15. Warranty claims: 43 in total, 11 in Q1
  2026. The user then asked for a written summary.

  # Conversation
  user: Fine. Save a one-page summary of all of that somewhere I can find it.

  step 1  write_file(path="shared/q1-summary.md", content="# Q1 2026 S400 ...")
          -> ok, wrote 412 bytes to shared/q1-summary.md
  answer: Saved to shared/q1-summary.md. Let me know if you'd like the regional
          split broken out by month.
  read: (none)
```

Turn 2, seventeen turns earlier, was: *"For anything you write, use the ops workspace — never the shared drive."*

**Pass 1: the answer is not wrong.** Nothing in the trace is false. No error, no retry, no repair. This is the failure §8.4 predicted: not a violated constraint the model argued past, but a constraint **absent** from the surviving context and therefore contradicted nowhere. A reviewer sees a competent agent doing what it was asked.

**Pass 2: `0 pinned turn(s) untouched`.** The whole bug in six characters. Compaction ran with nothing pinned, so the constraint went into the summariser's input, and the summariser — correctly, competently — summarised *the work*. Constraints are not work. It kept every number and dropped the one sentence that was not a finding. Note the summary is not wrong, lazy, or badly written; tuning the prompt harder would not catch this reliably, which is why invariant 55 makes the guarantee structural.

**Pass 3: why was nothing pinned?** `propose_pin` on that turn returns `'prohibition'`. So the rule was never consulted — the turn did not arrive through `append`. Three candidates: a `Turn` constructed directly, `append(..., pin=False)`, or a buffer reconstructed per request. The composition line distinguishes them: `history 69 tok` with the summary present means the buffer *did* accumulate seventeen turns, so it was not reconstructed. The remaining cause is a caller bypassing `append`.

**Pass 4: `memories 0 tok`, the deeper failure.** The constraint was also never *stored*. Had it been, the pre-step would have retrieved it into the `memories` block on this very request and the compaction loss would not have mattered. Both layers missed the same sentence — and before F-08-04's fix that empty block was **guaranteed**, because `DURABLE_CUES` had no prohibition cell.

**The fixes, ranked.** *Weakest*: add "preserve any standing constraint" to `atlas_compact`. It helps sometimes; it is a request to a model about its own fidelity, unverifiable from the output. *Stronger*: make the bypass impossible — `append` as the only documented path, plus a test asserting a session assembled through `handle_request` has non-zero `pinned_tokens` whenever a prohibition was said. *Strongest*: **two independent layers**. A prohibition is now `semantic/org` at importance 0.98, so it is stored and retrieved on every later request in every session, and compaction can lose it freely. **The general rule: a constraint that matters should survive by two mechanisms whose failure modes are unrelated** — pinning fails when a caller bypasses `append`, retrieval fails when the cue table has a hole, and neither implies the other.

*Also required and cheap: print `read:` always, and print the pin count.* The diagnosis took four passes and no re-running because both numbers were in the record.

**Concept check 8.21.** Say why a `write:` line naming the path *and the reason it was permitted* would have made this diagnosable in one pass, and which existing invariant that line instantiates.

## 9. [core] Common pitfalls & how professionals avoid them

1. **Counting turns instead of tokens.** A ten-turn window is 200 to 8,000 tokens. Budget in the unit the resource is denominated in, and name the function `estimate_` if it estimates.
2. **Letting the model decide what to remember.** A missed write costs one memory; a fabricated write costs a false fact retrieved confidently with a provenance line saying the user said it. Give the model the **veto**. And notice the same argument run backwards is why it may **add** a pin and never remove one.
3. **Storing the assistant's own turns.** One `if`, and it is the difference between a memory system and a hallucination laundry. Extend it to tool output.
4. **Thresholding a per-query-normalised score.** Min-max makes terms comparable and the composite incomparable. And with two candidates it maps to `{0, 1}` regardless of the raw gap.
5. **Believing a separation because a boolean says so.** Print the **margin, the sample size, and the embedder** next to any separation claim, or you will ship a floor tuned on nine examples.
6. **Two representations of the same value in a comparison neither owns.** Redaction defeated deduplication at cosine 0.673. Transform first, then compare.
7. **Confusing expiry with deletion.** Test both, and assert on `count()` rather than only on an empty retrieval.
8. **Editing a memory in place.** Supersede. The history of what the system believed and when is what answers "why did March differ from August".
9. **Assuming an honest drop report means a survivable drop.** F-08-03.
10. **Pruning and caching without noticing they fight.** Do not reclaim a hundred tokens by breaking a 1,500-token cached prefix.
11. **A dict where the domain has duplicate keys.** Two cue groups for one cell, and the later literal silently won at import time. When precedence matters, use an ordered sequence.
12. **Two hand-written rule sets that were supposed to agree.** Do not merge them — they answer different questions — **print the disagreement on every run**.
13. **Reporting recall without precision.** Every recall probe passes for a system that assembles every memory into every prompt.
14. **Building the store inside the loop that reads it.** Invariant 16. Neither failure raises.

## 10. [extended] Industry perspective

**Everyone converges on the same four levers, in this order**: clear consumed tool results; retrieve just in time; compact when the window fills; isolate long sub-tasks in their own windows. That ordering is cost-and-safety, not preference: clearing a consumed result is nearly free and nearly safe, and compaction costs a model call and can lose a constraint.

**Provider platforms have absorbed all four**, which changes what you build. The memory tool is a client-side file interface — the model issues `view`, `create`, `str_replace`, `insert`, `delete`, `rename` against a `/memories` directory *you* implement and therefore control. Context editing clears stale tool results server-side. Server-side compaction summarises automatically. The trade is explicit: a well-tested mechanism, and no ability to inspect the policy. **Atlas builds its own because the policy is the pedagogy**; a team shipping next quarter should probably use the platform's and spend its effort on the write gate, which no platform can supply because it encodes what *your* users say.

**Filesystem-as-memory is the pattern behind all of it.** Context becomes an index into storage rather than the storage itself. Attractive because it is unbounded and *inspectable*. Dangerous because file contents are unvalidated input the agent later trusts — memory poisoning with a filesystem attached — and because an agent that must decide to read a file can decline to.

**Trade-off 1: pre-step versus tool.** Pre-steps are reliable and pay on every request. Tools pay only when used and can be skipped by a model that does not think to look. Atlas does both, split by route (D-42). High-value memory leans pre-step; broad shallow memory leans tool.

**Trade-off 2: extract-then-store versus store-then-search.** Extraction costs precision at write time and buys a small clean corpus; raw storage costs nothing then and pushes the whole problem onto retrieval over an unbounded corpus. The industry has largely converged on extraction, for pitfall 2's asymmetry.

**Trade-off 3: how much to trust decay.** Curves are elegant and their parameters are unmeasurable without longitudinal data most teams lack. A hard horizon per kind is crude, explicable to a customer, and testable with a frozen clock.

**Trade-off 4: cache-friendly layout versus fresh context.** When they disagree, correctness wins, and the decision gets written down.

**Interview questions.**

1. *A colleague proposes a `min_relevance` floor on memory retrieval. The score is a min-max-normalised sum of three terms. What do you say, and what do you propose instead?*
2. *Your agent forgot a constraint stated twenty turns earlier. Walk me through the diagnosis.*
3. *When is a flat tool registry the right choice, and what number tells you?*
4. *You add server-side tool-result clearing and your cache hit rate collapses. Why?*
5. *A regulated customer asks you to delete a user's data. What in your memory design makes that answerable, and what would make it unanswerable?*

## 11. [core] Capstone increment

*Resume note.* **If your code diverged, start again from `atlas_phase_07.zip`.**

### What Atlas can do now

It remembers users across sessions: a definition stated on Monday is retrieved into Wednesday's prompt with a provenance line naming who said it and when. It compacts a long session without losing a stated constraint, because constraints are pinned outside the summariser's reach. It exposes `remember` and `recall` as tools with the read-only asymmetry that routes them through five existing mechanisms. It loads one skill progressively — 89 tokens of summary always, 565 of instructions on activation, 370 of reference on demand. It assembles every prompt in cache-friendly order and **prints its own composition**, so "what the model was allowed to see" is a recorded fact. It deletes a user's data on request, for real, and can prove it in three assertions. And it can now tell you that 90% of a research prompt is text the provider has already seen.

### Interface changes

**Additions only; nothing renamed.** `ATLAS_INTERFACES.md` goes to **v0.17** with seven new module sections (`atlas.memory.{tokens,buffer,store,assemble,session,skills,tools}`) and invariants **55** and **56**.

Three existing interfaces gain **defaulted, additive** parameters, so every Phase 5–7 caller keeps working unchanged:

| Interface | Addition | Migration |
|---|---|---|
| `build_default_registry` | `memory: object \| None = None` | Omit it and `recall`/`remember` do not exist and no prompt mentions them — exactly `index=`'s contract from Phase 7. |
| `build_handlers` / `handle_request` | `memory: Any = None` | Omit it and `RoutedResult.context` is `None` and `render()` prints no context line. |
| `RoutedResult` | `context: AssembledContext \| None = None` | Defaulted, so existing constructions validate. |
| `HANDLER_TOOLS` | `+= ("recall",)` on `research`; `+= ("remember",)` on `tool_action` | Appends, not literal edits, so the Phase 5 value stays in the source verbatim and `make check-docs` keeps the Phase 5 document honest. |

One **shape** change inside a Phase 8 module, recorded because it happened during the phase: `DURABLE_CUES` went from `dict[(kind, scope), (importance, cues)]` to `tuple[(kind, scope, importance, cues), ...]`. No migration is owed — the name is new this phase — but the reason is contract-relevant: **a mapping cannot express two cue groups for one cell, and the dict version silently deleted one at import time.**

### Files touched

**Added (11):** `atlas/memory/__init__.py` (repopulated), `tokens.py`, `buffer.py`, `store.py`, `assemble.py`, `session.py`, `skills.py`, `tools.py`; `atlas/prompts/files/atlas_compact.v1.md`; `atlas/skills/northwind-quarterly/SKILL.md` and `references/RELATIONS.md`.

**Added (tests and harness, 6):** `tests/test_memory_tokens.py`, `test_memory_buffer.py`, `test_memory_store.py`, `test_memory_assemble.py`; `tests/hidden/test_phase08_a1.py`, `test_phase08_a2.py`.

**Added (evals and scripts, 3):** `evals/memory_probes.py`, `evals/tasks/phase08.json`, `scripts/phase08_results.py`.

**Changed (10):** `atlas/flow/app.py` (two `HANDLER_TOOLS` appends, the wiring guard, the pre-step, `RoutedResult.context`, `render()`), `atlas/tools/__init__.py` (`memory=`), `atlas/prompts/__init__.py` (`REQUIRED_SECTIONS`), `atlas/prompts/CHANGELOG.md`, `evals/run.py` (three dispatch shapes, `_hashing_embedder`, three environment keys), `tests/test_prompts.py` (checksum pin, two new tests), `tests/test_evals_harness.py` (41 → 44), `Makefile` (`PHASE ?= 08`), `ATLAS_INTERFACES.md`, `VERSIONS.md`, plus `docs/RESULTS.md`, `docs/FAILURE_LOG.md`, `docs/DECISIONS.md`.

### Tests added

**1,074 → 1,220 passed, 12 skipped.** 146 new tests: 13 on the estimator, 35 on the buffer, 39 on the store, 55 on the assembler, skills, tools and wiring, plus 4 on the new prompt. Two hidden test files skip cleanly until their assignment exists (`make grade` says so rather than reporting a failure).

The three worth reading as models rather than as coverage: `test_a_pinned_constraint_survives_eviction_and_compaction` reaches §8's defect through the composition a caller uses (invariants 46, 47); `test_redaction_does_not_defeat_deduplication` asserts on `"1.000" in decision.reason` rather than merely on the refusal, because a duplicate detected at 0.93 would pass a boolean check while hiding that the vectors no longer match; and `test_handle_request_assembles_context_and_puts_it_on_the_result` asserts **object identity** between `memory.last_context` and `result.context`, because two equal-but-separate assemblies is exactly what F-07-06 was.

### +3 eval tasks

**41 → 45 gradeable (46 defined).** All four run on Tier F and none grades a model's words.

| id | grades |
|---|---|
| `p08-research-context-is-cache-ordered-and-complete` | The **layout**: block 0 is static, is `tool_schemas`, is required; `cache_prefix_tokens ≥ 1000`; nothing dropped. A volatile block anywhere in the prefix fails it. |
| `p08-pinning-survives-a-scripted-lossy-summary` | Invariant 55: the summary omits "shared drive", the rendered prompt contains it, and `summariser_saw == false`. |
| `p08-cross-session-recall-hits-and-does-not-gate` | `recall == 1.0` over seven positive probes, `n_written == 6`, and **`false_positives == 2`** — asserted as a *fact*, so an accidental threshold fails the suite. |
| `p08-a-quarterly-question-activates-the-skill-through-the-front-door` | **Wiring**: a quarterly question routed through `handle_request` activates the skill and puts `skill_body`, `instructions` and `tool_schemas` in the prompt, and an unrelated question activates nothing. Added because the first cut of this phase shipped a skill loader reachable from nothing (F-08-07). |

That third check deserves emphasis. Asserting the false-positive count as a **fact rather than a goal** is how you stop a future contributor from "improving" recall by adding the floor §8.8.2 forbids: the suite would go red, and the failure message points at the design decision rather than at a number.

### `make results` and the expected ranges

`make results` runs eight experiments, five of which need no model. Full tables in `docs/RESULTS.md`; the ranges to expect:

| measurement | tier | value | status |
|---|---|---|---|
| `research` static floor | F | 1,240 est tok, 30.3% of 4,096 | **measured** |
| research prompt: static share / cacheable prefix | F | 90.0% / 1,523 est tok | **measured** |
| constraint survival, scripted-lossy summary, no pinning | F | **0 / 6** | **measured** |
| constraint survival, scripted-lossy summary, with pinning | F | **6 / 6** | **measured** |
| mean compaction ratio, model arm | F | 0.71 | **measured** |
| cross-session recall, 7 positive probes | F | **7 / 7** | **measured** |
| false positives, 2 negative probes | F | **2 / 2** | **measured** |
| raw-cosine separation margin | F | **+0.005** | **measured, and worthless** |
| skill break-even activation rate | F | 84.2% | **measured** |
| write gate accuracy | F | 1.000 on 14 sentences | **measured, UPPER BOUND** |
| greedy vs contiguous retention, oversized turn | F | 36 vs 27 turns; 3/3 vs 2/3 reachable | **measured** |
| real summariser drops a shown constraint | A | 30–70% for an 8B-class model | **author estimate, unmeasured** |
| `estimate_tokens` error on a schema-heavy prompt | A | undercounts by 10–25% | **author estimate, unmeasured** |
| evidence survives at 1,530 usable tokens | F | **5 / 6** probes | **measured** |
| evidence survives at 2,088 usable and above | F | **6 / 6** probes | **measured** |
| required blocks at a 1,200 budget | F | **refused** (`BudgetTooSmall`) | **measured** |
| end-to-end recall through `handle_request` | F | **6 / 7** (store-level: 7/7) | **measured**, gap is F-08-09 |
| skill activations per quarterly question | F | 1; zero on unrelated questions | **measured** |
| tool-result prune below `clear_at_least` | F | **0 tokens freed** | **measured** |
| answer quality across the budget sweep | H | — | **[Tier H recommended]**, unmeasured |
| prompt-cache read share | B | — | not measurable on Tier A; Appendix B |

**And the budget, twice corrected.** The block allowed ~1,100 Tier A requests. My §1 arithmetic said ~950. The first cut's `make plan` reported **60**. The revised sweep reports **190** — 52 completions and 138 embeddings.

Read that sequence rather than the final number. The ~950 was wrong because *the arithmetic priced a design that had not been built*: four of six experiments turned out to need no model. Then 60 was wrong because *the design was incomplete* — the two experiments that most needed building, the quality sweep and the three-session run, were the two that were missing, and they are where the model calls live. Phase 7's header was over by 40%; this phase's was over by 1,500% and then under by 200%. Same cause each time: **an allowance converted into an estimate before the thing being estimated exists.** The remedy is not better arithmetic. It is writing the budget row **last**, from `make plan`, after the experiments exist.

### `docs/FAILURE_LOG.md` — read five failing traces

Nine entries this phase. The fourth is worth more than its diff, and the seventh is worth more than the rest put together.

**F-08-01** — redaction defeated deduplication at cosine 0.673, and the upsert hid it: the table stayed correct while the decision record lied.
**F-08-02** — the tutorial's prose and the code implemented two different eviction policies; a test found it, reading the prose twice had not.
**F-08-03** — the assembler honestly reported dropping the model's entire action space.
**F-08-04** — `PIN_CUES` had a prohibition group and `DURABLE_CUES` did not, so a standing prohibition survived compaction *inside* a session and was forgotten *between* sessions. Found by `make results`, not by a test, because each cue set was internally consistent and only their **disagreement** was wrong. The fix exposed a second defect: the new group, added as a second entry under the same dict key, was silently overwritten at import time. The `fiscal` disagreement remains **on purpose**, printed on every run — the two sets answer different questions and may legitimately differ; what must not happen is that they differ by accident. **The danger is never the divergence; it is the divergence nobody measured.**
**F-08-05** — the eval harness could not build a memory store: a lambda closing over a lazily-imported name.
**F-08-06** — the header's call budget was wrong by a factor of sixteen.
**F-08-07** — the skill loader was reachable from nothing on the live path: nothing selected a skill from a request, the default budget made the body unfittable anyway, and the pre-step assembled a prompt with neither instructions nor tool schemas. Three halves of one defect, all invisible to every unit test, all obvious in the first line of an experiment that did not exist. **Invariant 41's fifth appearance, and the count is the finding.**
**F-08-08** — both abstention gates were dead code. `out_of_scope` was a literal `False`; `stale` was computed against the same constant that had already filtered away its own trigger. The phase's central claim — *no corpus statistic is available, so what is free instead is time and identity* — was unimplemented while the interface file, the results file and a tool's help text all described it as protection.
**F-08-09** — a probe that passes against the store and fails end to end, 7/7 versus 6/7, because one experiment advances a clock and the other does not. **Not fixed**: two measurements of the same thing at two layers is a diagnostic; one of them tuned to match the other is a lost diagnostic.

### Repo tag

`phase-08`. `make test-offline` → **1,220 passed, 12 skipped**. `python evals/run.py --trials 1` → **45/45**. `make check-docs` → clean. `make plan` → 190 requests. `make grade` → 2 skipped, with the message saying the assignment modules do not exist yet.

### The audit that should have run first

Three of this phase's nine defects — F-08-07's three halves — were found by one procedure, applied late:

> **Take every capability sentence in §11 and find the test that reaches it through the public entry point.** If there is none, the sentence is prose, not a capability.

"Loads one skill progressively" had 45 passing tests and no such test. "`stale` and `out_of_scope` gate" had a rendered field and no test that made either fire. Neither is a subtle bug; both are one grep away, and both survived a green suite of 1,205 tests because **every module was tested and the composition was not.** Run that audit before you tag, not after.

## 12. [core] Mastery checklist

You are ready to move on if you can:

- [ ] Compute your agent's static context floor from its system prompt and tool schemas, and say what fraction of the window it is.
- [ ] Explain why a token estimator must be named `estimate_`, which direction its error runs on a schema-heavy prompt, and where the free ground truth comes from.
- [ ] Say what a turn-count window gets wrong, and give the concrete number that shows it.
- [ ] State invariant 55 from memory and explain why a filter in Python is a guarantee where a prompt instruction is a request.
- [ ] Explain, in one sentence each, why the model may **veto** a write and may **add** a pin.
- [ ] Place any statement into one cell of the 3×2 taxonomy and name the policy that cell changes.
- [ ] Explain why the Park score ranks and never gates, and what happens to it with two candidates.
- [ ] Name the three forgetting mechanisms and say which one satisfies a deletion request.
- [ ] Compute a skill's break-even activation rate and say which direction the answer runs.
- [ ] Name the order in which a prefix is assembled, and explain why clearing a mid-prompt tool result costs you a cache.
- [ ] Do the tool-count arithmetic, and name the failure that arrives *before* the window failure.
- [ ] Say what a passing recall probe proves and what it does not, and name the number that must be reported beside it.
- [ ] Look at a trace with `0 pinned turn(s) untouched` and `memories 0 tok` and diagnose it without re-running anything.

## 13. [core] Quiz

1. A colleague adds `min_score=1.5` to `MemoryStore.retrieve` so the agent stops surfacing irrelevant memories. The score is a min-max-normalised sum of three terms. Explain precisely what that parameter means in practice, and name the one quantity in the record that *could* legitimately carry a threshold.
2. The extractive compaction fallback cannot lose a constraint, and a real summariser can. Explain what follows for how you must test compaction, and state exactly what your test then proves and does not prove.
3. `remember` is declared `read_only=False`. List the mechanisms that declaration reaches, and state the general principle in one sentence.
4. Phase 7's IDF coverage made abstention free. Why is that mechanism unavailable for memory, and what replaces it?
5. A standing constraint must survive a long session. Name two mechanisms with **unrelated** failure modes that together guarantee it, and say why adding a third that shares a failure mode with one of them buys nothing.
6. You enable server-side tool-result clearing and your cache hit rate collapses. Explain the mechanism, and say what the correct clearing policy looks like as a result.

## 14. [core] Coding assignments

### Assignment 1 — `atlas/memory/health.py` **[fast track: do this one]**

Write `context_health(assembled: AssembledContext) -> ContextHealth`: one report that grades an assembled prompt and names its problems by block.

**Acceptance criteria.** `ContextHealth` is a `BaseModel` that round-trips its own `model_dump()`. `HealthStatus` is a closed `Literal` with three members and `HEALTH_STATUSES` lists them; every member is reachable. A **drop is never healthy**, whatever the fill says. A nearly empty window reports `healthy` with no findings. Findings **name blocks** (`"extracts did not fit and was dropped"`), never describe them abstractly. A block at or above `DOMINANT_SHARE` of the prompt is flagged by name. A prompt with no cacheable prefix is flagged. `cacheable_share` is a fraction of the *assembled* tokens. `render()` contains the status and every finding. The function is **pure** — no clock, no client, no store, no mutation of its argument. Thresholds are **named module constants**, not literals in branches.

**UNAIDED CORE.** The decision of *which conditions are findings and in what order they are checked*, and the derivation of `status` **from** `findings` rather than in parallel with it. That last point is the assignment: the commonest wrong shape is a `status` branch and a `findings` list that each independently decide what a problem is, and then disagree.

`make grade` runs `tests/hidden/test_phase08_a1.py`. Do not read it.

### Assignment 2 — `atlas/memory/consolidate.py` **[extended]**

Turn many episodic memories into one semantic memory, as a two-phase command.

**Acceptance criteria.** `plan_consolidation(store, *, user_id, client=None) -> ConsolidationPlan` groups **episodic** memories only, by mutual cosine, and **writes nothing**. Groups below `MIN_GROUP_SIZE` are not proposed. `apply_consolidation(store, plan) -> ConsolidationResult` writes the semantic rows **and then** supersedes the members, in that order, and reports `n_written` and `n_superseded`. A superseded episode stops being retrievable. `ConsolidationDraft` has exactly one field, `extra="forbid"`, and the model arm can only *drop* a group — a plan with a client has no more candidates than one without. `apply_consolidation` takes **no `user_id`**. An empty plan applies as a no-op. `MIN_GROUP_SIZE` and `GROUP_SIMILARITY_FLOOR` are named constants. A model failure is recorded in `plan.error` and the mechanical plan stands. `proposed_text` is non-empty and within `MAX_TEXT_CHARS`, and it goes through `store.write` — consolidation is **not** a privileged write path.

**UNAIDED CORE.** The two-phase split and the ordering inside `apply`. Write down, before you code, what goes wrong if `apply` supersedes before it writes, and what goes wrong if `plan` and `apply` are one function. Both answers are in this phase's prose.

`make grade` runs `tests/hidden/test_phase08_a2.py`. Do not read it.

## 15. [extended] Case study — memory policy for a healthcare scheduling assistant

**The situation.** A clinic group deploys a scheduling assistant. It books, moves and cancels appointments; answers questions about clinic hours, locations and preparation instructions; and talks to patients directly. It has no access to clinical records and must never acquire any. Patients are told it "remembers your preferences". The group operates in a jurisdiction with a statutory right to erasure and a data-minimisation duty, and is subject to audit.

**Deliverable.** A memory policy of at most 1,200 words with: (a) a filled 3×2 taxonomy grid naming what Atlas may store in each cell and what it may not; (b) a retention horizon per cell with a justification; (c) the write gate's clauses, in order, adapted to this domain; (d) what a provenance line shows a **patient**, and separately a **clinician**; (e) the exact deletion operations you support, what each removes, and how you would demonstrate compliance to an auditor; (f) three failure modes you would specifically test for, with the probe for each; and (g) one question you would refuse to answer alone, and who you would take it to.

**Rubric — 20 marks.**

| | Criterion | Marks |
|---|---|---|
| 1 | **Taxonomy discipline.** Every listed item is in exactly one cell, and each cell's horizon follows from the *policy* that cell changes, not from a general sense of sensitivity. | 3 |
| 2 | **Clinical exclusion is structural, not aspirational.** A rule at the gate — a refused cue set, a length ceiling, a scope restriction — rather than an instruction in a prompt. Full marks require naming the mechanism and the test. | 3 |
| 3 | **Deletion versus expiry.** Both mechanisms named, the difference stated, and the auditor demonstration concrete (a count, a query, a test). Loses marks for describing expiry as deletion. | 3 |
| 4 | **The org-scope tension surfaced, not resolved.** A patient states something that is arguably clinic policy. Whose is it? Full marks for identifying this as a decision requiring the customer, and proposing a default with its risk stated. | 3 |
| 5 | **Provenance for two audiences.** What a patient sees and what a clinician sees differ, and the difference is argued. | 2 |
| 6 | **The write gate adapted, with the asymmetry intact.** Model may veto, never create. Marks lost for any design where the model sets kind, scope or importance. | 2 |
| 7 | **Three testable failure modes with probes**, at least one of which is a negative probe or a precision measurement rather than a recall probe. | 2 |
| 8 | **The refused question**, correctly identified as a policy rather than engineering question, with the right escalation. | 2 |

**Marking note.** An answer that is thorough about storage and silent about deletion caps at 12. An answer that lets the model decide what is clinical caps at 10, however well written — that is the one error in this domain with an unbounded downside.

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 9.*

**Atlas metered what it spent for eight phases and never decided what to send.** Accounting is not budgeting. Measured, at `phase-07`: the `research` route's static floor is **1,240 estimated tokens, 30.3% of a 4,096-token window**, before the question exists. In a real assembled research prompt, **90.0% is static** — byte-identical to the previous request — and the history and question together are **3.4%**. Five claimants compete for the window and only one, **history**, grows without bound and without a policy, which is why "context engineering" means, four times out of five, "what do we do about history".

**Turns are the wrong unit and pinning is not a priority queue.** Ten turns is 200 to 8,000 tokens. A token budget with **oldest-first eviction among unpinned turns** is the policy; a pin is a *boolean that removes a turn from the competition*, not a high score — because when everything competes on one axis nothing is guaranteed, and a pinned block that overflows must **refuse**, not choose a constraint to violate. Measured on nine turns at budget 400: contiguous eviction keeps 3 turns, contiguous-plus-one-pin keeps 4, greedy keeps 7 *with holes at 3 and 5*. Pinning did not buy slack — it spends 59 tokens — it bought **reachability**, because a 614-token turn made turn 1 unreachable at any budget. Contiguous is the default because **a window with holes is a conversation the model misreads**.

**Invariant 55: compaction is lossy by design, so what must survive it is extracted before it runs and pinned outside it.** Measured against a scripted lossy summary: **0 of 6 constraints survive without pinning, 6 of 6 with it, at a cost of two tokens** — and the summariser was never shown the pinned turn, which is why it could not lose it. `SummaryDraft` has one field and no field for what it omitted, because *a field reporting compliance can report compliance falsely*. Fifth and sixth appearance of D-25's shape (`SummaryDraft`, `WriteDraft`), and the fix is the same every time: **remove the field rather than filtering it** (D-44).

**Tier F could not exhibit the failure the phase is about**, because `mechanical_summary` copies sentences verbatim and *a first-sentence extractor cannot lose a constraint*. Hence a scripted fixture — and hence the paragraph that matters: **a fixture is evidence about your program, never about a model.** It proves the mechanism works if the risk is real; `docs/RESULTS.md` establishes how often the risk is real.

**Memory has no corpus IDF, so what is free instead is time and identity.** `stale` and `out_of_scope` gate; `thin` and `max_raw_relevance` are computed, printed and wired to nothing — invariant 49's **fourth** appearance. The Park score (UIST 2023) ranks over min-max-normalised recency, relevance and importance and **never gates**, because a threshold on a per-query-normalised quantity is a threshold on the shape of the candidate set. Four deviations: decay on `last_used_at` not `created_at`; an injected clock; importance mechanical and clamped; and no floor anywhere, asserted over **signatures** rather than by grepping source. The hazard specific to memory: with two candidates `minmax` maps to `{0, 1}` regardless of the raw gap, so `[0.90, 0.89]` and `[0.90, 0.01]` normalise identically and the three-term score carries **no information at all**.

**Cross-session recall is 7/7 and false-positive control does not exist: 2/2.** That second number is a *consequence* of the ranking rule, and the eval task asserts `false_positives == 2` **as a fact**, so an accidental threshold turns the suite red. Raw cosine does separate positives (0.069–0.248) from negatives (0.023–0.064) — margin **+0.005** on nine probes from one embedder over six memories. **Read the margin, not the boolean.** `separated: True` is technically correct and epistemically worthless, and printing the margin beside the boolean is the point: a boolean invites a threshold and a margin refuses one.

**A skill is context engineering first.** Measured: L1 **89**, L2 **565**, L3 **370** estimated tokens; break-even activation rate **84.2%**, from `(L2 − L1)/L2`. Progressive disclosure *saves* tokens unless the skill fires on more than 84% of requests, and the crossover **rises with L2** — so the technique wins by a bigger margin the longer the instructions are, which is why it is for procedures and not one-line rules. And **level 1 is a retrieval problem with a model as the retriever**, so the description must contain words a user would actually type.

**Cache-friendly layout is free to teach and unmeasurable on Tier A.** Prefix order is tools → system → messages; a change at one level invalidates that level and everything after; matching is exact; writes happen only at breakpoints and reads find *prior writes*, not stable content. `ToolRegistry.names` has been sorted since Phase 3 with a comment reading "order stability = cache key", and this phase finally explains it. **Pruning and caching are in direct opposition**: clearing a mid-prompt tool result changes the prefix and invalidates from that point, which is why the provider feature has a minimum-clearance parameter and why the correct policy is *clear a lot at once, rarely*.

**Invariant 56: a context budget that cannot be exceeded does not make the right things present** — invariant 52's sentence with one noun changed. Corollary, learned expensively: **reporting a drop is not the same as the drop being survivable.** F-08-03 was the assembler correctly and clearly reporting that it had dropped `tool_schemas`, having handed a ReAct loop a prompt with no action space.

**Four defects worth more than their diffs.** F-08-01: redaction defeated deduplication at cosine **0.673**, and the upsert hid it — *there must be exactly one canonical form of a memory, and it is the one on disk.* F-08-02: the tutorial's prose and the code implemented two different eviction policies, and a test found it where re-reading had not. F-08-04: `PIN_CUES` had a prohibition group and `DURABLE_CUES` did not, so **a standing prohibition survived compaction inside a session and was forgotten between sessions** — found by `make results`, because each set was internally consistent and only their *disagreement* was wrong; and the fix exposed a dict silently dropping a duplicate-keyed cell at import time. The `fiscal` disagreement stays, printed every run: **the danger is never the divergence, it is the divergence nobody measured.** F-08-06: the header's Tier A budget was wrong by 16×, because an allowance was converted into an estimate before the thing being estimated existed.

**Repo state at `phase-08`.** Seven new modules, one checksum-pinned prompt (`atlas_compact`, `49e06fc8f98a`), one checksum-pinned skill (`northwind-quarterly`, `cd6752e1cc34`), `scripts/phase08_results.py` with eight experiments and `--only`/`--quick`/`--tier-a`/`--tier-h`/`--plan`, four new eval dispatch shapes. **1,220 offline tests** (from 1,074), **45 gradeable eval tasks** (from 41, 46 defined), `ATLAS_INTERFACES.md` **v0.18** with invariants 55-58 and D-42 to D-46, nine new `FAILURE_LOG.md` entries. **Eighteen assignments outstanding.** `make plan` reports **190** Tier A requests for a full sweep; `make demo` runs the two composition experiments on Tier F for nothing.

**Phase 9 next: LangGraph.** Three things here become load-bearing. The **context assembler is about to become a framework's job**, and the exercise is to find out which of its decisions the framework makes for you and which it silently makes *differently* — the volatility ordering, the required-block refusal, and the drop report are three places to look first. The **buffer is a state object with a reducer**, which is exactly LangGraph's model, so `ConversationBuffer.append` and `select_window` are about to be rewritten as a channel and a reducer, and the question is whether invariant 55 survives the translation. And **`SessionMemory` is the first object in Atlas that must be threaded through a graph rather than passed to a function**, so invariant 16 — constructed once per run and passed in — meets a framework whose whole purpose is managing what gets passed where. Phase 9 opens by asking what a framework can and cannot enforce about the things this phase proved you have to enforce yourself.

## 17. [core] Further reading

**Context engineering.**
- Anthropic, *Effective context engineering for AI agents*, 29 September 2025 — https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents. The source of this phase's lever ordering and of the compaction-tuning guidance ("maximise recall first").
- Liu, N. F. et al., *Lost in the Middle: How Language Models Use Long Contexts*, arXiv:2307.03172, 6 July 2023.
- Hong, K., Troynikov, A., Huber, J., *Context Rot: How Increasing Input Tokens Impacts LLM Performance*, Chroma technical report, 2025 — https://research.trychroma.com/context-rot.

**Memory.**
- Park, J. S. et al., *Generative Agents: Interactive Simulacra of Human Behavior*, UIST 2023, arXiv:2304.03442. The recency/relevance/importance score, min-max normalisation, and reflection.
- Packer, C. et al., *MemGPT: Towards LLMs as Operating Systems*, arXiv:2310.08560, 12 October 2023. Main versus external context, and the paging metaphor with its limits.
- Zhong, W. et al., *MemoryBank: Enhancing Large Language Models with Long-Term Memory*, arXiv:2305.10250 (17 May 2023); AAAI 2024, pp. 19724–19731, doi:10.1609/aaai.v38i17.29946. Ebbinghaus-curve decay, and retrieval as reinforcement.

**Skills and tools at scale.**
- *Agent Skills specification* — https://agentskills.io/specification. The authoritative field list, name rules and progressive-disclosure guidance; the numeric limits are VERSIONS.md rows.
- Anthropic, *Advanced tool use*, 2025 — https://www.anthropic.com/engineering/advanced-tool-use. The `search_tools` indirection and the "if a human engineer cannot say which tool applies" diagnostic.
- Anthropic docs, *Tool search tool* and *Memory tool* — https://platform.claude.com/docs/en/agents-and-tools/tool-use/tool-search-tool and `.../memory-tool`.

**Caching.**
- Anthropic docs, *Prompt caching* — https://platform.claude.com/docs/en/build-with-claude/prompt-caching. Prefix order, breakpoints, the lookback window, and invalidation.

## 17b. [core] A procedure to keep

One page, and it is the transferable output of this phase's mistakes.

**Before you tag a phase, for every capability sentence in your capstone:**

1. Name the test that proves it. If you cannot, the sentence is prose.
2. Check where that test calls in. A test that constructs the component directly proves the component; only a test that goes through the public entry point proves the *system*. Both are worth having and they are not interchangeable.
3. For every boolean a branch reads, find the test that makes it `True`. A gate with no such test is decoration.
4. For every threshold, find the constant it is compared against, and check that nothing upstream has already filtered away the values that would trip it.
5. Write the budget row **last**, from `make plan`.

Five greps, ten minutes, and they would have caught F-08-06, F-08-07 and F-08-08 before any of them reached a document.

## 18. [core] SOLUTIONS

Emitted separately as **`phase_08_solutions.md`**: worked answers for the cumulative review, all twenty-one concept checks, the six quiz questions, both assignments (Assignment 1 in full, Assignment 2 as a sketch with the five load-bearing decisions argued), and the case-study rubric applied to one worked response.

## 19. [core] HANDOFF

The updated `ATLAS_INTERFACES.md` (**v0.17**) and `VERSIONS.md` (with the Phase 8 delta) are inside `atlas_phase_08.zip`, at the repository root. Repo tagged `phase-08`. Verified in the tree: `make test-offline` → **1,220 passed, 12 skipped**; `python evals/run.py --trials 1` → **45/45**; `make check-docs` → clean; `make plan` → 190 requests; `make grade` → 2 skipped.
