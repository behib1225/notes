# phase_08_solutions.md

Worked answers for Phase 8: cumulative review, concept checks, quiz, both
assignments, and the case study rubric applied to one worked response.

---

## Cumulative review (§2)

**1. Raise on a mismatched query embedder, discard a stale cache silently.**
The rule: *raise when the mismatch can produce a wrong answer nobody notices;
discard silently when it can only cost money.* A stale response cache costs a
duplicate call — recoverable, visible in `RequestAccount`. A mismatched index
returns cosines between vectors from two different embedders, which are
meaningless numbers that still rank, so the search returns plausible wrong
chunks and the answer is confidently wrong. Invariant 45. Phase 8 applies the
same rule to `MemoryStore.ensure_schema`, with one wrinkle: a document index can
be rebuilt from its corpus, but a memory store's rows *are* the originals, so
the repair is `reembed()` in place.

**2. Why the clean/messy split is the headline.** 20% of the corpus is damaged,
so a corpus-wide average is 0.8×clean + 0.2×messy. A system that fails
completely on damaged documents still reports ~0.8 of the clean figure, which
looks like "slightly worse" rather than "does not work on a fifth of your
files". The average is a weighted blend whose weight is a property of the
generator, not of the retriever, so it moves when the corpus composition moves
and tells you nothing about either half. Invariant 43.

**3. Two things that break if failed branches are dropped.** (a) The
**accounting**: a dropped branch's tokens and calls vanish, so
`RequestAccount` under-reports and the fan-out looks cheaper than it is. (b)
**Positional alignment**: results returned in argument order let a caller zip
them against inputs; drop one and every subsequent result is attributed to the
wrong question. A green suite would not catch (b) if the tests only assert on
result *contents* — the mis-attribution is silent, and it is why the invariant
is "in argument order, failures included" rather than "all successes".

**4. Why a chunk cannot recompute its quality flags.** The detectors are
whole-document detectors. `interleaved_columns` is inferred from word x-positions
across a page; `boilerplate_repetition` from the same string recurring across
pages; `suspect_reading_order` from the sequence of blocks. A 900-character chunk
contains neither the coordinate data nor enough repetitions to see any of it, so
a re-run comes back **clean** — not because the text is clean but because the
evidence is absent. Inheriting verbatim is the only honest option, and it is why
`ExtractionQuality` travels to the citation (invariant 42).

**5. Why `RequestAccount` stores no money.** Prices are volatile facts that go
stale in the repository and cannot be tested; tokens and calls are what Atlas
actually observed. Money is computed at *render* time from an injected
`RateCard`. Whenever a cost is printed, the **rate card's identity and date**
must be printed with it — a number without the card that produced it is not
checkable, and it is the same rule as `read:` on a data answer (D-39).

---

## Concept checks

**8.1.** A 30% cut to `atlas_system` (2,024 chars ≈ 506 est tok) returns about
**152 est tokens** to every route, `research` included. Wrong place to start
because on `research` the tool schemas are 734 est tokens — bigger than the whole
system prompt — and they grow linearly in the tool count while the system prompt
grows only by human edit. Also: cutting the system prompt trades window for
*behaviour*, and the prompt's own changelog records which sentences were added
because a measurement demanded them.

**8.2.** **History.** It shrinks between requests when compaction fires. It is
dangerous as slack because the shrink is not a function of the next request: you
cannot know at planning time whether this request's history is 1,200 tokens or
180, so a budget that assumes the compacted size will overflow on the request
before compaction and a budget that assumes the uncompacted size wastes the
window on every request after.

**8.3.** The estimator undercounts JSON, and the tool schemas are the biggest
JSON block, so `assemble_context` can report a comfortable fill while the real
prompt exceeds `num_ctx` — and many runners truncate from the oldest end, which
is where the schemas and the system prompt live. Of the two fixes, **reserving
the tool-schema block outside the budget** (i.e. `required=True`, which is what
F-08-03 forced anyway) is safer: raising `CHARS_PER_TOKEN` globally makes every
block pessimistic, which wastes window on the prose blocks where 4.0 is roughly
right, and it hides the error rather than removing the block from the
competition.

**8.4.** Turn 4 (620 tokens, a file read) goes and turn 5 (45 tokens, a summary
of it) stays: **desirable**, because the summary is the *consumed* form of the
raw output — the model already read the file and wrote down what mattered, so
the tokens in turn 4 are pure redundancy. It is a **bug** when turn 5 does not
in fact contain what a later turn needs: "here are the first ten rows" summarised
as "I read the file" retains the framing and discards the content. The general
rule: eviction is safe when the later turn is a *lossless-enough* summary of the
earlier one for the task at hand, and nothing in the buffer can verify that.

**8.5.** Strongest form of the colleague's argument: Atlas sessions are 10–20
turns, so `n` never exceeds the window, so flat and progressive cost the same
number of tokens per compaction while flat has strictly better fidelity —
progressive's degradation is a cost paid for a saving that never materialises at
this scale. The measurement that settles it: **compaction fidelity as a function
of the number of compactions**, i.e. `docs/RESULTS.md` Phase 8 experiment 4 run
with 1, 2 and 3 successive compactions on the same session. If fidelity does not
degrade across generations at this session length, flat wins and progressive is
premature optimisation.

**8.6.** Genuinely lost: cross-boundary reference resolution. If turn 20 says
"use that workspace" and the constraint naming it is pinned outside the
summariser's view, the summariser writes "the user asked to use that workspace"
with a dangling referent. The trade is still correct because (a) the pinned turn
is *concatenated into the final prompt*, so the model answering the request sees
both and can resolve the referent — only the *summariser* could not; and (b) the
alternative trades a guaranteed property for a probabilistic one, and a dangling
referent in a summary is a legibility cost while a lost prohibition is a
correctness cost.

**8.7.** Two representations of the update: (a) edit the row's text; (b) insert a
new row and set `superseded_by` on the old one. The `docs/DECISIONS.md`
convention — append-only, entries superseded and never edited — chooses (b). The
reason is not tidiness: "the definition changed in Q3" is the fact that explains
why March's answers differ from August's, and (a) destroys it.

**8.8.** The failure: a delete that succeeds in SQLite and fails in the vector
database leaves the embedding retrievable, so `retrieve` returns a hit whose
`record` lookup finds nothing — or, worse, returns the stale text. Neither
component's unit tests catch it because each behaves correctly in isolation;
the defect lives in the **assembly layer** (invariant 46). It also violates
invariant 45's spirit and D-43 directly: one system of record, and the index is
a column of it.

**8.9.** Reconciling them: `remember` lets the model *propose*; the gate
*decides*. The model's tool call is an input to `should_write`, exactly as a
user's turn is, and it is subject to every clause — including `role="user"`,
which is passed by the tool because the text is the user's statement, not the
model's. What `remember` must do with rejected text: return the refusal string
with its reason (`not stored (no_durable_cue): …`). Returning a successful
`ToolResult` would be a reporting bug because the model would believe the fact
is now durable and would stop repeating it to the user — invariant 15: repairs,
retries and refusals are recorded, never hidden.

**8.10.** Break-even: progressive disclosure costs `L1 + p·L2`; system-prompt
inclusion costs `L2`. Equal when `p = (L2 − L1)/L2 = (800 − 100)/800 = **87.5%**`.
Not the whole decision because the system-prompt version also occupies the window
on the 12.5% of requests where it is irrelevant, diluting attention over
everything else (§8.1's declining utility per token) — a cost the token
arithmetic does not price. And the skill body is *reviewable and versioned
separately* from the system prompt, which matters operationally.

**8.11.** For the move: memories change only on a write, so most requests would
see an identical block, extending the cacheable prefix by ~92 tokens. The
failure: memories are **retrieved per query** — `_render_memories(request)`
returns the top-k for *this* request — so the block is not stable across
requests at all, and marking it static would put a volatile block inside the
prefix and destroy the cache for everything after it. The field that makes this
unavoidable is `MemoryRecord.last_used_at`: every retrieval bumps it, so even
the same query's rendered block changes between requests. (An org-memory block
retrieved by a *fixed* query would be a legitimate static block; that is a
different design.)

**8.12.** At 200 tools ≈ 14.7% of a 200k window. Adopt tool search anyway
because: (1) the **selection failure** arrives at a few tens of tools and is
about discrimination between similar descriptions, not about tokens — the model
picks the wrong tool long before the window is a problem; and (2) that 14.7% is
paid on *every* request including the ones using one tool, and cache writes,
latency and cost all scale with it. Only (2) is about tokens.

**8.13.** What the rule bought: it removes the *automatic* path. Poisoned text
arriving in a document or a tool result cannot become a memory on its own — a
human has to read it and retype or paste it, which is a person choosing to
assert it. That converts a silent machine-speed attack into one requiring user
participation, and it makes the provenance line true (`u=priya` really did say
it). What it does not buy: protection from a user who is careless or hostile,
which is Phase 14.

**8.14.** A probe that a broken write gate fails: state a durable fact in session
1, then in session 3 ask a question whose answer requires it — **and assert on
the number of memories written**. A gate storing every turn passes the recall
check and fails `n_written == 6` (it would be 28). Of the two numbers, the
**precision** measurement catches it: share of assembled memory tokens the
answer actually used collapses when the store is full of "And the regional
split?".

**8.15.** Rounding down would let a block that costs 1.9 tokens be charged 1, and
across twenty blocks the assembler under-charges by up to twenty tokens while
believing it fits. Because runners truncate from the **oldest** end, the tokens
lost are the tool schemas and the system prompt — the two `required=True` blocks
— so the failure is silent removal of the exact content the required flag exists
to protect.

**8.16.** The extractive summary loses (a) **compression** — 0.99 versus 0.71
measured, so it barely reclaims anything — and (b) **synthesis**: it cannot merge
"North 22" and "South 18" into "regional split totalling 71", so a long session
becomes a long list of first sentences. `docs/RESULTS.md` Phase 8 experiment 4's
`mean compression` column is the row that settles the trade, read alongside
experiment 4's survival column: the model arm buys 0.28 of compression and, with
pinning, costs nothing in survival.

**8.17.** Buys: idempotence across trivial variation — capitalisation, trailing
punctuation, extra whitespace — so a user restating a fact does not create a
second row. Costs: two genuinely different statements that normalise to the same
word sequence collide, and the second silently upserts onto the first.
**Unreachable in practice** given the other clauses, because two statements with
identical word sequences differing only in punctuation are the same statement;
and the dedup clause would refuse a near-identical one anyway. The residual risk
is negation-by-punctuation, which English does not have.

**8.18.** An automatic prune inside `retrieve` would delete rows while a session
holds them: a `MemoryRetrieval` returned before the prune references records that
no longer exist, so a later `record_use` silently updates zero rows and a trace
reader resolving a memory id finds nothing. Relates to invariant 16 because
`retrieve` is called inside the request loop and pruning is a whole-store
lifecycle operation — a stateful operation performed inside the loop that reads
the state, which is the same class of error as constructing the store there.

**8.19.** By invariant 56's test, `skill_body` **is** correctly optional: its
absence *degrades the answer* (the model may query the wrong relation) but does
not *break the mechanism* (the model still has tools, a question, and
instructions). What the model does when the catalogue advertises a skill whose
body never arrives: it knows a procedure exists, knows it is relevant, and cannot
read it — so it either answers without it or says it cannot follow the procedure.
That is better than the tool-schema failure because the *model can tell*. A
missing action space is invisible to the model; a missing procedure it was just
told about is not.

**8.20.** Twenty skills at 89 tokens each is 1,780, plus the 44-token preamble
(133 − 89) once = **1,824 est tok**. The preamble is not multiplied because it
is one instruction about how to use the catalogue, not per-skill metadata. So
the marginal cost of the twenty-first skill is exactly its own summary, ~89
tokens — which means the *fixed* cost of having skills at all is trivial and the
*variable* cost is linear in the count. That is the same growth curve as tool
schemas (§8.11), 40% cheaper per item, and it hits the same wall eventually.

**8.21.** A `write:` line naming the path and the reason the write was permitted
would have shown `write: shared/q1-summary.md (allow_writes=True, no constraint
in context)` — one line containing both the action and the absence. It is an
instance of **invariant 42** (provenance travels to the output) and of **D-39**
(print the provenance always, not only when it is interesting): the diagnosis
took four passes because the trace recorded the write and the constraint's
absence in two different places, and a reader had to connect them.

---

## Quiz answers (§13)

**Q1.** Because min-max normalises over the *candidate set*, so the same raw
values produce different normalised values depending on which other memories
happened to be candidates. A floor of 1.5 means "above the midpoint of whatever
this query returned", which on a two-candidate set means "the better of two" and
on a fifty-candidate set means something else entirely. The only thresholdable
quantity is one normalised by something *outside* the candidate set — Phase 7's
IDF coverage was normalised by the *question*, which is why it worked there and
why raw cosine is the only candidate here.

**Q2.** The extractive fallback copies sentences verbatim, so it cannot omit a
sentence that was in its input — the failure mode under test is *unreachable*.
Testing the mechanism therefore requires a scripted fixture: a hand-written
summary that omits the constraint. That fixture proves Atlas's filtering works
*if* a real summariser behaves that way, and proves nothing about whether it
does. Separating those two claims is the whole discipline: fixtures are evidence
about your program, `docs/RESULTS.md` is evidence about a model.

**Q3.** `remember` is `read_only=False`, which routes it through: `execute()`'s
`allow_writes` refusal, `cached_execute`'s never-cache and never-replay rules
(D-23, D-26), `HANDLER_TOOLS`' per-route scoping, and Phase 12's future human
gate. A plain function call bypasses all four. The general principle: **declare
a capability's properties next to the code, in a type, so that every mechanism
keyed on those properties applies automatically** — the alternative is four
places that each have to remember this one function is special.

**Q4.** Because there is no corpus. IDF coverage is normalised by the question's
own IDF mass, and IDF is a corpus statistic: a single user's twenty remembered
sentences give no document frequencies worth the name. What is free instead is
**time** (exact, available before any model runs) and **identity** (the scope
filter). Hence `stale` and `out_of_scope` gate, and `thin` and
`max_raw_relevance` are printed and gate nothing.

**Q5.** Two mechanisms with unrelated failure modes: **pinning** keeps it in the
window (fails when a caller bypasses `append`), and **long-term storage plus the
retrieval pre-step** puts it back (fails when the cue table has a hole — which
F-08-04 was). Neither failure implies the other, which is exactly what makes the
pair worth having. A third mechanism that shares a failure mode with one of these
— for example a second cue list written by the same author — adds cost and no
independence.

**Q6.** The prefix. Clearing a tool result from the middle of the messages array
changes the byte sequence from that point onward, so every cached block after the
cleared one misses. You reclaimed the cleared tokens and paid a full cache write
on everything below. Providers expose a minimum-clearance parameter so the trade
is only taken when the reclaimed amount justifies the lost prefix; the correct
lever ordering is therefore *clear a lot at once, rarely* rather than *clear a
little, often*.

---

## Assignment 1 — `atlas/memory/health.py` (fast track)

```python
"""Context health: one report, three statuses, no thresholds in branches."""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, Field, computed_field

from atlas.memory.assemble import AssembledContext

HealthStatus = Literal["healthy", "tight", "degraded"]
HEALTH_STATUSES: tuple[HealthStatus, ...] = ("healthy", "tight", "degraded")

# Named, because a float in a branch is a number nobody can tune (invariant 48).
FILL_WARN = 0.85
DOMINANT_SHARE = 0.70


class ContextHealth(BaseModel):
    """What is wrong with this prompt, named by block. Pure arithmetic."""

    status: HealthStatus
    fill: float
    cacheable_share: float
    n_dropped: int
    findings: list[str] = Field(default_factory=list)

    def render(self) -> str:
        head = (
            f"context health: {self.status} (fill {self.fill:.0%}, "
            f"cacheable {self.cacheable_share:.0%}, dropped {self.n_dropped})"
        )
        return "\n".join([head] + [f"  - {f}" for f in self.findings])


def context_health(assembled: AssembledContext) -> ContextHealth:
    """Grade an assembled prompt. No clock, no client, no store.

    Order matters: a DROP is never healthy, whatever the fill says, because
    invariant 56's corollary is that a reported drop is not a survivable one.
    """
    findings: list[str] = []
    for name in assembled.dropped:
        findings.append(f"{name} did not fit and was dropped")
    for name, share in assembled.composition.items():
        if share >= DOMINANT_SHARE:
            findings.append(f"{name} is {share:.0%} of the prompt")
    if assembled.tokens and assembled.cache_prefix_tokens == 0:
        findings.append("no cacheable prefix: a volatile block leads the prompt")
    if assembled.fill >= FILL_WARN and not assembled.dropped:
        findings.append(f"fill {assembled.fill:.0%} leaves little room to grow")

    if assembled.dropped:
        status: HealthStatus = "degraded"
    elif findings:
        status = "tight"
    else:
        status = "healthy"
    total = assembled.tokens
    return ContextHealth(
        status=status,
        fill=assembled.fill,
        cacheable_share=round(assembled.cache_prefix_tokens / total, 4) if total else 0.0,
        n_dropped=assembled.n_dropped,
        findings=findings,
    )
```

**Notes on the marking criteria.** `status` is derived from `findings` rather
than computed in parallel with them, so the two cannot disagree — the commonest
way this assignment goes wrong is a `status` branch and a `findings` list that
each independently decide what a problem is. `context_health` never mutates its
argument and never reads a clock, which is what makes the purity test pass.
`cacheable_share` divides by the *assembled* tokens, not the budget, because the
question is "what fraction of what I sent is reusable", not "how full is the
window". And the drop check runs first because a drop dominates: a prompt at 20%
fill that dropped `extracts` is not healthy.

---

## Assignment 2 — `atlas/memory/consolidate.py` [extended]

Sketch, with the load-bearing decisions spelled out; the full module is about
150 lines.

```python
MIN_GROUP_SIZE = 3
GROUP_SIMILARITY_FLOOR = 0.55


class ConsolidationDraft(BaseModel):
    """The model arm. ONE field, and it can only REFUSE a group."""
    model_config = ConfigDict(extra="forbid")
    unrelated: bool


class ConsolidationGroup(BaseModel):
    members: list[MemoryRecord]
    proposed_text: str
    @computed_field
    def n_members(self) -> int: return len(self.members)


class ConsolidationPlan(BaseModel):
    user_id: str
    candidates: list[ConsolidationGroup] = Field(default_factory=list)
    n_considered: int = 0
    consulted_model: bool = False
    error: str = ""
    def render(self) -> str: ...


class ConsolidationResult(BaseModel):
    n_written: int = 0
    n_superseded: int = 0
    errors: list[str] = Field(default_factory=list)


def plan_consolidation(store, *, user_id, client=None) -> ConsolidationPlan:
    """Group episodic memories by mutual cosine. Writes NOTHING."""
    episodes = [r for r in store._rows_for(user_id=user_id) if r.kind == "episodic"]
    groups = _single_link_groups(episodes, floor=GROUP_SIMILARITY_FLOOR)
    groups = [g for g in groups if len(g) >= MIN_GROUP_SIZE]
    candidates = [
        ConsolidationGroup(members=g, proposed_text=_mechanical_generalisation(g))
        for g in groups
    ]
    # The model arm may only DROP a group.
    ...


def apply_consolidation(store, plan) -> ConsolidationResult:
    """Write the semantic rows, then supersede the episodes. Append-only."""
```

**The five decisions that matter.**

**`plan` and `apply` are separate functions.** Consolidation *writes* high-
importance, long-lived semantic rows, and §8.8.1 spent a page establishing that
writes are gated. A single `consolidate()` that grouped and wrote would walk
around the gate it sits behind. Separating them also makes the plan inspectable
before anything happens, which is what makes `make record ARGS=--consolidate`
safe to run.

**No `user_id` parameter on `apply_consolidation`.** The plan already names the
user; a second, independently-supplied id is an opportunity for the two to
disagree and write one user's consolidation into another's history. The hidden
test asserts the parameter's absence.

**`proposed_text` is mechanical by default.** Take the members' common
substring, or the most-central member's text, prefixed with a count. A model arm
may *replace* it, and the resulting text is passed through `store.write` — so it
goes through the ordinary gate, including the length ceiling and the PII
redaction. Consolidation is not a privileged write path.

**Grouping is single-link over cosine, with a named floor.** Not k-means, not a
model: grouping is arithmetic and must be deterministic under the eval harness.
Single-link is chosen over complete-link because episodic memories about the same
topic arrive as a chain ("Q1", "Q2", "again this week"), and complete-link
splits chains.

**Supersede, never delete.** `apply` writes the semantic row first, then sets
`superseded_by` on each member. In that order: if the write fails, nothing has
been superseded and the store is unchanged; the reverse order can orphan four
episodes behind a row that was never created.

---

## Case study rubric applied (§15)

A worked answer scoring 17/20 would: place appointment history as
**episodic/user with a short horizon**, clinical preferences as
**semantic/user**, and clinic policy as **semantic/org**; state that no clinical
content is eligible for the memory store at all and route it to the record
system with its own access control; make deletion a **hard requirement with a
named operation and a test**, distinguishing it from expiry; note that
`source_session` is what makes a targeted erasure a query; and identify the
**org-scope erasure tension** as a policy question requiring the customer's
decision rather than resolving it unilaterally.

The three marks it loses: not addressing **who else sees an org-scoped memory a
patient stated** (the hardest question in the study), not specifying what the
provenance line shows a **clinician** as opposed to an engineer, and treating the
model's role as "extract facts" without naming the veto-only asymmetry.

---

## Revision addendum — answers for the concept checks and quiz added in the revision

**Concept check 8.22.** `MIN_TRIGGER_MATCHES` is defensible because a **count of matched trigger words is normalised by nothing**: two matches means two matches whatever the request's length and whatever else is in the catalogue, so the number is comparable across requests and a threshold on it is a statement about the world. The memory score is min-max-normalised *over the candidate set*, so "1.5" means "above the midpoint of whatever this query happened to return" — a statement about the shape of the candidate set, not about relevance. The one thing that would make the trigger count non-transferable in the way Phase 7's IDF was: **deriving the triggers from the corpus or the description rather than writing them down.** An IDF-weighted trigger score would be normalised by *this company's document frequencies*, and it would not transfer to another company's Atlas. A hand-written list of thirteen words transfers because it is not a statistic.

**Concept check 8.23.** Sub-agent isolation has the best compression ratio — n full windows down to n `Finding` records — and is listed last for two reasons. **The token reason**: it costs a whole extra agent, so every worker pays its own static floor (§3's table: 1,240 estimated tokens on the `research` route before its sub-question exists), and for a task that would have fitted in one window that is pure overhead. **The non-token reason, which is the real one**: the orchestrator loses sight of the work. A worker that misunderstood its sub-question returns a confident finding, and the orchestrator has no context in which to doubt it — which is why Phase 5's `Finding` carries provenance and why the critic exists. Only the first reason is about tokens.

**Quiz 7.** What is wrong: `stale` is a boolean a caller branches on, computed against the same constant that the expiry filter uses, so every row old enough to trip it has already been removed one step earlier and the flag is **unreachable**. The `usable` property that reads it is therefore equivalent to `bool(hits)`, and the `recall` tool's stale branch is dead code. Why no test caught it: every test asserted what the flag *was* on realistic inputs (always `False`, correctly), and none asserted that it could ever be `True`. Invariant 30 asks for a line of code that sets each member of a closed set; nothing asked for a line of code that sets a `bool`. **The general rule (invariant 57): a gate ships with a test that makes it fire, and when a soft warning and a hard cutoff derive from one constant the warning is dead — give them separate constants and assert the ordering (D-46).** And the sharper version: **a gate that cannot fire is worse than an absent one, because it reads as protection** in the interface file, in the results file, and in a tool's help text.

**Mastery item — "given a capstone claim, name the test that would prove it".** The marking answer is not a test but a *location*: the test must call the **public entry point** the claim is about. "Atlas remembers users across sessions" is proved by a probe that goes through `handle_request` in session 3, not by `MemoryStore.retrieve`. "Loads one skill progressively" is proved by asserting `memory.activated` after `handle_request`, not by `load_skill`. A test that constructs the component directly proves the component; both kinds are worth having and they are not interchangeable, and this phase shipped three claims that had only the first kind.

**Assignment 1, revision note.** The hidden tests now also require that `context_health` be **pure** and that `HEALTH_STATUSES` members all be reachable. Both are invariant 57's shape applied to your own code: a status nothing can produce is a status that reads as coverage. Before you submit, construct one `AssembledContext` per status and check you can.

**Assignment 2, revision note.** `apply_consolidation` takes no `user_id`, and the hidden test asserts the parameter's absence. The reason is F-08-07's family: a second, independently-supplied identifier is an opportunity for two sources of truth to disagree, and the failure — one user's consolidation written into another's history — is invisible until an audit.
