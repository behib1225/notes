# phase_12_solutions.md

Worked answers for Phase 12. Attempt each item and write your answer down
before reading. Where an answer names a measured figure, the measurement is in
`docs/RESULTS.md` or reproducible with `make results PHASE=12`.

## Cumulative review

**CR-1.** The check belongs at the composition layer because *that is the layer
that grants authority*. `build_core_graph` can only derive what it can see — it
knows it has gated tools — whereas `build_atlas_graph` is the caller that
decided `allow_writes=True`, and a composition handing out write permission owes
the caller a place to suspend. The property that makes this a wiring error is
that the approval gate is implemented with `interrupt()`, which persists the
pause in the checkpointer: with no checkpointer there is nowhere to pause, so
the gate cannot suspend, so it is not a gate. A gate that cannot fire reads as
protection (invariant 57), which is worse than an absent one — so it is refused
at wiring time rather than discovered three levels down in a trace.

**CR-2.** The write is **silently discarded**: no exception, no warning, and the
channel reads back `None`. The implication is the sharp half of invariant 66's
corollary: a guard can fire correctly, compute a correct refusal record, write
it to an undeclared channel, and be read by nothing — while the action it
refused proceeds. That is invariant 62 (a guard read by nothing is
indistinguishable from an absent guard) *plus manufactured evidence of
oversight*, which is worse than having no gate, because a reviewer finds the
record and believes it.

**CR-3.** **Inherited, not divided.** The subgraph gets the parent's full limit,
so the effective bound is `max(level_supersteps) + 1` rather than a budget split
across levels. And it is a fact about **one framework** — specifically it is a
*policy* that framework chose, not a property of graphs. This is invariant 59's
eight-question rubric in miniature: find the line of the framework's code that
decides the policy, then accept its choice explicitly or wrap it.

**CR-4.** Invariant 58: *a capability the caller must remember to switch on is
off in production*, so selection, activation and defaulting belong inside the
component, reached from the public entry point. The measurement is Phase 10's
durability experiment under a hard `os._exit(9)`: the framework's default lost a
completed superstep and afterwards reported `next=()`, which is exactly what a
successfully finished run looks like; `"exit"` left the thread unresumable with
`EmptyInputError`; only `"sync"` gave the property the phrase "durable
execution" describes. A default that silently reports a lost run as a finished
one is not a safe default, so the entry point sets it.

**CR-5.** It creates a **new message with a new id**, carrying
`additional_kwargs["atlas_authored_by"] = "human"` — so the two markers are the
new id and the authorship key. The model's original assistant message is never
mutated. The alternative — upsert-by-id, which is what the framework's own
human-in-the-loop middleware does — was measured to make the original proposal
unrecoverable after an edit: 5/5 recoverable with Atlas's gate, 0/5 with
upsert-by-id. An audit trail that cannot show what the model *proposed* cannot
answer the only question an approval record exists to answer.

## Concept checks

**CC-1.** Direct integration: 3 × 5 = **15** artefacts. A protocol: 3 + 5 = **8**.
For the two systems used by exactly one host each, direct integration is
*correct* when the protocol's fixed costs exceed its savings — and at N=1 the
saving is zero by construction (one host, one system, one artefact either way,
and the protocol adds a wire schema, a process to operate and a trust boundary
to reason about). The condition to state explicitly: **direct integration is
right when the integration is not expected to be reused and the trust boundary
buys you nothing** — i.e. when the tool is host-shaped anyway, and when you do
*not* need the server's refusal to be independent of the client getting a flag
right. If either changes (a second host appears, or a write path needs
process-level enforcement), the calculation flips.

**CC-2.** A **tool**, and the control column says why: the query is written by
the model, so the invocation decision is the model's, and a resource is fetched
by the *application*. If retrieval did **not** involve a model-written query —
say the host always attaches the same three policy documents — then it is a
resource, because the host decided. So the answer does change, and the dividing
line is not "is it data?" but "who decides to bring it in?". Worth noting the
hybrid Atlas actually uses: `SessionMemory.assemble` puts top-scoring memories
in context as a pre-step (resource-like, application-controlled) *and* `research`
gets `recall` as a tool (model-controlled), for D-42's reason — the pre-step
covers the enumerable case and the tool covers the one route whose branch set
cannot be enumerated at design time.

**CC-3.** `begin_export` must return an **explicit server-minted handle** — an
`export_id` — which the client then passes as an ordinary argument to
`poll_export` and `download_export`. Two properties it needs that a session id
did not: (1) **it must be unguessable and authorization-bound**, because it now
travels through an untrusted party and appears in ordinary tool arguments, so a
sequential integer would let one caller poll another's export; and (2) **it must
carry or reference its own lifetime** — an expiry the server enforces — because
there is no connection whose closure implicitly ends it. A third, if you want
it: it must be resolvable by *any* instance, so the state behind it belongs in
shared storage rather than in one process's memory.

**CC-4.** *Improves:* the confirmation now describes the **actual** consequence,
because the server is the only party that knows which store the file lands in,
whether the write is reversible, and who else can see it. Atlas's own
`consequence_for` has to guess at that from a tool name and arguments.
*Makes worse:* the server does not know the **user**, the conversation, or
whether a human is even reachable — and worse still, a host with no confirmation
path must either refuse or invent an answer. **Invariant 66** speaks to it: a
gate's coverage is the set of effects it wraps, not the set of calls it
inspects, and splitting the gate across a process boundary means neither side
wraps the whole effect. The practical resolution is the one Atlas implements:
the server asks about the *effect* and the host decides whether to ask a *human*,
so `call_remote_tool` refuses with `write_refused` when `confirm is None` rather
than answering on the human's behalf.

**CC-5.** `initialize` returns `-32601` method-not-found; the client either fails
(good) or logs and continues (the common bug). Then `tools/list` **succeeds**,
because lists need no session — and this is the confusing part: the client's own
logs now show a successful discovery, which is the strongest available evidence
that the connection is fine. The first `tools/call` then fails with an
unsupported-protocol-version error, because no `_meta` was sent. The failure is
confusing rather than clean because **only the requests that need per-request
metadata broke**, so the evidence points at the tool while the error points at
the version — two different systems to go and read. A clean failure would have
been *everything* breaking at connect time.

**CC-6.** Nothing happens, and the two independent mechanisms are: **(1) the
scope** — the token carries only `documents:read`, so the server's per-tool check
refuses the delete and returns `scope_refused`, which escalates as
`authority_missing`; and **(2) the absent tool** — Atlas's registry for the route
does not contain a delete tool at all, so the model has no name to call
(invariant 20: a prohibition is an absent tool wherever it can be). Which would
still be standing if the other were misconfigured? **The scope**, and this is
the point of the phase: the absent tool is enforced by *Atlas*, so a bug in
Atlas's scoping (a tool added to `HANDLER_TOOLS`, a registry passed unscoped)
removes it. The scope is enforced by the *server*, in a different process, and
survives every bug on Atlas's side. That asymmetry is the whole argument of
§6.1's "trust boundary you can enforce" — and it is also why the answer is not
"both equally": one is a policy and the other is a boundary.

## Your turn

**§6.1 — system-shaped or host-shaped.** `query_db` **system-shaped** as a
capability, host-shaped as currently written (fixed text rendering chosen for
Atlas's prompt). `search_web` system-shaped (the corpus is the company's).
`read_file`/`write_file`/`list_files` **system-shaped** if the workspace is
shared, host-shaped if it is Atlas's scratch space — and the honest answer is
that this depends on a fact about deployment, not about code. `calculate`
**host-shaped**: exposing arithmetic over a protocol adds a round trip to
something every host already has. `current_time` host-shaped, same reason.
`retrieve_documents` system-shaped as a capability but currently returns Atlas's
citation structures. `recall`/`remember` **host-shaped**: they are about the
host's relationship with its user, and the `user_id` closure that makes them
safe does not survive a wire.

**§6.5 — one MRTR round.** Request 1 (abbreviated: `_meta` as in §6.3):

```json
{"jsonrpc":"2.0","id":11,"method":"tools/call",
 "params":{"name":"schedule_meeting",
   "arguments":{"with":"Chen","when":"Thursday 14:00"}}}
```

Interim result:

```json
{"jsonrpc":"2.0","id":11,"result":{
  "resultType":"input_required",
  "inputRequests":{"which_chen":{
    "method":"elicitation/create",
    "params":{"message":"Two people match \"Chen\". Which did you mean?",
      "requestedSchema":{"type":"object",
        "properties":{"person_id":{"type":"string",
          "enum":["u-4471","u-9002"]}},
        "required":["person_id"]}}}},
  "requestState":"<opaque>"}}
```

The key is `which_chen` — chosen by the server, and the client must echo it as
the key in `inputResponses`. **In `requestState`**: the disambiguation question's
own identifier, the candidate set (so round 2 can reject an answer naming
somebody who was never offered), and the original arguments' digest. **Kept out**:
the candidates' names, emails or any personal data, because the state crosses
the trust boundary and comes back — and anything in it has been disclosed to the
client and can be read by anything that logs the payload. Also kept out: any
authorization decision. If the state said `may_book: true`, an attacker who
could tamper with it would grant themselves the booking; authority is re-derived
from the token on round 2. (In practice the SDK seals this, but "the SDK seals
it" is not a reason to put a secret in it — §6.5's note about which bindings are
live in *your* deployment.)

**§6.7 — the research workers' token.**

```python
token = issue_token(
    subject=user_id,
    audience=COMPANY_DATA_AUDIENCE,
    scopes=granted_scopes(HANDLER_TOOLS["research"]),
    secret=secret,
)   # -> ("company_data:read", "documents:read")
```

If somebody later adds a write tool to `HANDLER_TOOLS["research"]`, **the token
widens automatically** — and **no, that is not what you want**, which is the
interesting half of the question. `granted_scopes` is derived from the tool set
precisely so the two cannot drift, and the cost of that is that a change to the
tool set silently changes the authority. The mitigation is not to abandon the
derivation (a hand-maintained second list is invariant 13's drift) but to
**assert the invariant you actually care about**, which is what
`test_the_research_route_can_never_mint_a_write_scope` does: `"workspace:write"
not in granted_scopes(HANDLER_TOOLS["research"])`. Now the addition fails a
test that names the policy, rather than quietly widening a credential. General
form: when you derive a value to prevent drift, you must separately assert the
*property* the value was supposed to have.

## Quiz

**Q1.** Features that existed only to manage the session: the
`initialize`/`initialized` handshake; the `Mcp-Session-Id` header; `ping` (a
liveness check for a session); `logging/setLevel` (set the level *for this
session*); per-connection variation in list endpoints; `resources/subscribe`
plus the standalone HTTP GET endpoint; and SSE stream resumability with
`Last-Event-ID`. Any three. **Newly necessary because it was removed:** the
Tasks extension — once a broken stream loses the in-flight request, long-running
work needs a handle and a polling method rather than a held connection. Also
acceptable: `server/discover` (something had to take over the handshake's
discovery role) and explicit server-minted handles (something had to take over
the session's state-carrying role).

**Q2.** The property that changed is that **list results no longer vary per
connection** — they are properties of the server, not of who is asking. A cache
is only sound if two callers asking the same question must get the same answer;
under per-connection variation they need not, so no cache was safe and no shared
intermediary could be trusted. Removing the variation made caching *sound*, and
`ttlMs`/`cacheScope` are the hints that let clients and intermediaries exploit
it. Note the direction: a removal enabled an optimisation. (A full-credit answer
also notes `cacheScope: "private"` exists because *some* results still vary by
caller, so the property is not universal — it is guaranteed for list endpoints
and declared per result elsewhere.)

**Q3.** The mechanism is an **explicit server-minted handle**, returned by the
first call and passed back by the client as an **ordinary tool argument**. Two
properties it has that a session id did not: it is **visible in the payload**,
so it is inspectable in a trace and attributable to a specific call rather than
being an invisible property of a TCP connection; and its **lifetime is an
explicit decision by the server** rather than being inherited from the
connection's. Also creditable: it must be resolvable by any instance; it must be
unguessable and authorization-bound, because it now passes through the client.

**Q4.** Atlas keeps the pause in the **checkpointer** — server-side state under
its own control. MRTR keeps it in **`requestState`, in the payload**, held by the
client between rounds. The security requirement follows directly: because the
continuation is held by a party the server does not trust, it must be
**integrity-protected and rejected when verification fails**, and bound to a
time window, the originating request (method, tool name, argument digest) and
the authenticated principal — so state minted for one user cannot be redeemed by
another and a token replayed against a different tool or different arguments
fails. And every rejection returns **one frozen message** for every cause, so
the wire does not reveal which check failed.

**Q5.** **Workload identity** = which program (Atlas, this version, this
deployment). **User identity** = on whose behalf (Priya, employee 4471). With
workload identity alone you can rate-limit, quota, meter and **revoke a
compromised deployment without locking out any user** — none of which user
identity gives you, because revoking Priya to contain an Atlas compromise
punishes the wrong party. With user identity alone you can **make an
authorization decision and produce an attributable audit record** — neither of
which workload identity gives you, because every request looks identical, so
"Priya may see her team's data" is unenforceable at the boundary and the audit
trail names a program. Collapsing them loses one capability in each direction,
which is why on-behalf-of flows carry both.

**Q6.** What is wrong: it **enumerates what the token holds**, which makes the
refusal a **scope-discovery oracle** — an attacker who can trigger refusals maps
the credential's full authority for free, and learns which scopes exist. It
should name only **what is missing and what would fix it**: e.g. *"refused:
requires `workspace:write`. This is an authority limit, not a retryable error.
Report what you could not do; do not call this tool again."* Note the three
things that message does that the bad one does not: it names the missing scope
(actionable, and not a secret — the caller is asking for it), it classifies the
failure as non-retryable so the loop does not burn its step budget, and it tells
the model what to do instead. Phase 3's rule, unchanged: a tool's failure is
part of its interface, and the message is written for the model to act on.

**Q7 (the double gate).** *Correct:* the two gates ask different questions and
sit either side of a trust boundary. Atlas's gate asks an operator whether
**Atlas** may take this action; the service's MRTR asks whether **this
subject** may, and the service is the party that owns the effect, knows the
workspace is shared and knows whether the write is reversible. Removing either
one removes a check that the other cannot make: drop Atlas's and an operator
never sees the action in the context of the request that produced it; drop the
service's and the service is trusting a client's assertion that a human agreed.
Invariant 66's framing — a gate's coverage is the set of effects it wraps —
says neither side wraps the whole effect alone.

*Defect:* it is one action and the human is asked twice, which is precisely the
approval-fatigue mechanism Phase 10 measured. The second prompt carries almost
no new information for the operator who has just read a consequence line saying
"append to the SHARED company workspace", so its marginal value is low and its
marginal cost — attention, and the habit of clicking through — is not.

*Which would I act on, and what would I need first:* act on neither yet, and
measure the thing the argument turns on — **the rate at which the second gate's
answer differs from the first's.** If it is ~0%, the second prompt is
ceremony and should be answered from the first decision; if it is not, the two
gates are catching different mistakes and both earn their place. That
measurement needs one field neither side currently has: a **shared identifier
for "this action"**, so a decision recorded at the host can be matched to the
question asked by the service. Without it, collapsing them means the host
answering a question it cannot prove is the same question — which is why the
stretch goal asks for the identifier and not just the collapse.

## Assignment 1 — model answer notes

The reference implementation is not printed here, because the point is to write
it; these are the decisions a good submission makes and the traps a weak one
falls into.

**The audience must be a distinct constant.** `CALENDAR_AUDIENCE =
"atlas-calendar"`. The trap is reusing `COMPANY_DATA_AUDIENCE` "because it is
all Atlas" — which is exactly the confused-deputy hole, and the first hidden
test is a company-data token presented to the calendar server.

**The scope check reuses `verify_token` and `require_scope`; the *audience* is
this server's.** A submission that writes its own HMAC verification has two
implementations of one policy (F-08-02) and will drift.

**The three-value action domain.** The write tool's second round must
distinguish `accept`-with-`approve: true` from everything else, and the
"everything else" branch covers `decline`, `cancel`, and `accept`-with-
`approve: false`. The trap — and the defect the reference server itself shipped
first — is testing `answer.content is None`, which is true both when nobody has
been asked *and* when the caller declined, so declining re-asks. It fails
safely, which is why it survives.

**Scope before question.** `auth()` runs before `ctx.input_responses` is
consulted, so a caller without `calendar:write` never causes a human to be
interrupted.

**Storage may be a dict, and should be created inside the factory** so two
servers in one test do not share a calendar. A module-level dict is the same
mistake as a module-global tool map (invariant 10).

**`now` injectable.** The expiry test cannot sleep.

**A refusal names the missing scope and not the held ones.**

**The stretch goal, if you attempt it.** Collapsing the double gate needs a
shared action identifier — a digest of (tool, arguments, thread) minted by the
host, sent in `_meta`, and echoed by the service in its `inputRequests` — so
the host can prove the decision it holds answers the question being asked. Two
things to get right: the read routes must still refuse rather than answering
(they have no human whose decision could be reused), and the identifier must
cover the **arguments**, or an approved write to `a.md` silently authorises one
to `b.md`. That second point is `requestState`'s argument-binding rediscovered
from the host's side, which is the sign it is the right shape.

## Assignment 2 — model answer notes

The reference audit that validated the grader is 330 words plus a nine-entry
findings file. Its classification, which is the graded judgement:

**Removed:** the `initialize`/`initialized` handshake; `Mcp-Session-Id`;
`logging/setLevel`. Also removed, if you spotted them: `ping`, SSE
resumability/`Last-Event-ID`, `resources/subscribe` and the standalone GET
endpoint. **Deprecated but working:** Roots, Sampling, the HTTP+SSE transport,
Dynamic Client Registration. **Works unchanged:** `tools/call`,
`resources/read`, `tools/list` — with additions to honour (`_meta`,
`resultType`, `ttlMs`/`cacheScope`) rather than changes to make.

The distinction the assignment exists for: **Roots and Sampling are Deprecated,
not Removed**, and a plan that treats a twelve-month window as an emergency
while treating an actual removal as optional has the urgency exactly inverted.
The client in the brief is *already broken* on the handshake, the session header
and `logging/setLevel`; it is *fine for now* on Roots and Sampling.

**The risks a full-credit answer names, with controls.** The single long-lived
service-account token for three backends: it is over-permissioned (MCP01/MCP02),
un-audienced so replayable across all three, and unattributable — controls are
per-user scoped short-lived tokens with an audience per backend. `requestState`
becoming client-supplied input once the interactive tool moves to MRTR — control
is integrity protection with binding to principal, request and expiry. And the
per-user tool list served with a public cache hint — control is
`cacheScope: "private"`.

**Migration order, and the reasoning that earns the marks:** replace the
transport with the current SDK *first*, because that single change deletes the
handshake, the session header and the resumability code at once and is the only
item that is currently *failing*; then move identity onto `_meta`, because
everything else depends on the caller being identifiable; then convert the one
interactive tool to MRTR; then schedule Roots and Sampling. An answer that
starts with Roots has optimised for the item with the longest deadline.

## The wiring exercise (§7.8)

There is no question set for §7.8, and it is the most important section in the
phase, so here is what to take from it.

**The command.** `grep -rn "atlas.mcp\|atlas.auth" --include=*.py atlas/ | grep
-v "^atlas/mcp/\|^atlas/auth/"`. Run the equivalent for every module you add,
in every phase, before you write the summary. If the only hits are the
definition, the tests and a results script, you have written a library and are
about to claim a capability.

**Why tests do not catch it.** Every test supplied the composition the code
expected. That is not a bad test; it is the *only* kind of test a leaf module
can have. The gap is structural, which is why the remedy is a grep and not more
unit tests — and why invariant 46 keeps saying *test the assembly*.

**The tell in the prose.** A capstone sentence containing the word *every* —
"every tool call carries user identity" — is a claim about the default path. So
it needs a test that starts at the entry point. Scan your own summary for
universals and check each one has such a test; that scan takes a minute and
would have caught this.

**And the reason it matters beyond bookkeeping.** Fixing the wiring immediately
exposed F-12-06: `execute()` was catching the graph's `GraphInterrupt` and
grading it as a tool failure, so a run that should have paused for a human
completed instead, reported `final`, wrote nothing, and said nothing was wrong.
That bug was unreachable while the tools were unwired. **An unwired mechanism
does not merely lack proof; it conceals the bugs in everything it touches.**

## Case study — marking notes

The full rubric is in §15. Three observations from marking it.

**Criterion 3 is where answers separate.** The correct architecture is that the
*server* holds the single Ledger key and the *clients* hold per-user scoped
tokens — which means the server is, unavoidably, a deputy. A full-credit answer
says so explicitly and names what stops it being *confused*: the server checks
the caller's scope per operation before using its own credential, and the scope
set is derived from what that user may do in Ledger, not from what the key can
do. An answer that hands Atlas the shared key has reproduced the most common
real-world failure while writing a document about avoiding it.

**Criterion 4 rewards noticing the organisational half.** The N×M argument's
force is that the system's owners write the server. Here they cannot — no Python,
no capacity — so the saving is partly illusory: the platform team writes a server
against a 40-page Word document for a system it does not understand. That does
not defeat the recommendation, but an answer that does not notice it has taken
the arithmetic and skipped the condition (§6.1).

**A common near-miss on criterion 2.** Proposing search-and-execute over 200
operations is good, and Phase 8 is the right reference — but a full-credit
answer also notes that a searchable catalogue of 200 *write-capable* operations
is a worse artefact than a fixed list of 10 read-only ones, because the search
tool's action space is the thing you were trying to bound. Read-only v1 is not
timidity; it is the only version whose action space you can enumerate.
