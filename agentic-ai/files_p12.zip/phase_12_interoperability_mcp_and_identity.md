# Phase 12 — Agent Interoperability: the Model Context Protocol, Skills over MCP, Acting on Behalf of a User, and How Computer-Use and Coding Agents Work

> Assembled document. Sections 1–6.6 are Part 1, 6.7–9 are Part 2, 10–19 are Part 3.
> Every measured figure in this document was produced by `make results PHASE=12`
> or by `make test-offline` on the repository shipped as `atlas_phase_12.zip`.
> Current-state facts (versions, SDK names, spec status) are NOT in this prose:
> they are rows in `VERSIONS.md`, each with a source URL and a checked-on date.

## 1. [core] Phase header

| | |
|---|---|
| Title | Agent Interoperability: MCP, Skills over MCP, Acting on Behalf of a User, and How Computer-Use and Coding Agents Work |
| Weight | Light phase · 3 parts |
| Study hours | 11 h — 4 read / 5 build / 2 assess |
| Compute time | ~2 min wall-clock. The phase block budgeted ~25 min; nothing here needs a model, so the figure is corrected rather than copied |
| Tier A calls per sweep | **0.** The phase block said ~1,400; re-verified and corrected, because every claim here is about a protocol and a credential, both deterministic. `make plan PHASE=12` prints this. |
| Tier H calls | ≤ 50, opt-in via `--tier-h`; 0 spent |
| Cost | $0.00 outside Appendix B |
| Repo tag | `phase-12` |

Everything built this phase runs offline. The MCP server and client are
exercised in-process by `make test-offline` with no socket and no subprocess,
which is possible only because of the protocol change this phase is about.

## 2. [core] Cumulative review

Five questions from Phases 9 and 10. Answers in `phase_12_solutions.md`.

**CR-1.** `build_atlas_graph` raises when `allow_writes=True` and
`checkpointer is None`. Why does this check belong at the composition layer,
and what property of the approval gate makes a missing checkpointer a wiring
error rather than a runtime degradation?

**CR-2.** A node returns a key the state schema does not declare. What happens,
and what does that imply about a guard that writes a correct refusal to an
undeclared channel?

**CR-3.** A parent with `recursion_limit=20` invokes a subgraph. Divided,
inherited, or negotiated? Is your answer a fact about graphs or about one
framework?

**CR-4.** `run_atlas_graph` sets `durability="sync"` inside the entry point.
State the invariant that requires this and the measurement that shows the
framework's default was not acceptable.

**CR-5.** When an operator edits a proposed tool call, Atlas does not mutate
the model's message. What does it do, what two markers does the replacement
carry, and which failure did the alternative produce?

## 3. [core] Why this phase matters

Everything Atlas can do, it can do because you wrote the implementation. The
registry is an injected value and since Phase 3 it *is* the security model: a
prohibition is an absent tool, enforced by the absence of a Python object to
call. Three things break when a capability lives elsewhere.

**The integration cost stops being linear.** A wrapper per system is a week of
work you repeat for the next assistant, and the team that owns the system will
not write it, because they do not know your codebase.

**"Who is asking" becomes a wire-level question.** Inside one process,
identity is ambient: `make_memory_tools(store, user_id="priya")` closes over
the user and the model has no field in which to ask for anyone else. Across a
boundary the closure is gone. The far side receives a JSON object and must
decide from its contents whether this caller may do this.

**Phase 11's decision has an appointment here.** D-59 declined a supervisor
with four reversal conditions. The third was privilege separation: the moment
one step needs an authority another must be denied. Up to now Atlas got
separation free by handing research workers a registry with no write tools. A
remote server does not accept a registry. It accepts a credential.

Fourth, and more personal: you have used a coding assistant since Phase 0 as a
black box. It is built from pieces you now own, and by the end of this phase
you should be able to predict most of its behaviour from first principles.

## 4. [core] Learning objectives

You will be able to:

1. Explain the N×M problem in concrete numbers; name three things a protocol
   buys over a function call and two things it costs.
2. Name the three MCP participants and three core primitives, and say which
   party controls each primitive's invocation.
3. Describe what protocol statelessness removes, what replaces each removed
   thing, and enumerate four observable operational consequences.
4. Distinguish protocol statelessness from application statelessness, and
   explain how a server that must remember something now does so.
5. Implement a Multi Round-Trip Request that confirms before acting, and wire
   it by hand to Phase 10's `interrupt()`.
6. Distinguish user identity from workload identity, explain the confused
   deputy with a worked example, and say why "the agent has the admin token"
   is the most common real failure.
7. Issue a scoped short-lived credential, carry it across an MCP boundary,
   check it per tool, and refuse an over-scope call so the refusal reaches
   escalation.
8. Build an MCP server over Atlas's tools, consume a third-party server, and
   propagate W3C trace context in `_meta`.
9. Explain the `skill://` convention and why Resources were chosen over a new
   primitive.
10. Audit a deployment against a checklist and map your Phase 3–10 mechanisms
    onto the OWASP MCP Top 10.
11. Explain how computer-use and coding agents work and why coding suits
    agents.
12. Read a tutorial written against an older revision and classify every
    construct as works, deprecated, or gone.

## 5. [core] Prerequisites & quick recap

**Where Atlas is.** `START → router → {chat | document | data | research |
tool_action} → critic → persist → respond → END`, with approval before every
write, escalation, a bounded fan-out on `research`, and crash-safe runs.

**What you need.** Phase 3's `ToolSpec`/`execute` contract and the closed
`ErrorKind`. Phase 8's progressive disclosure and the `Skill` loader. Phase
10's `interrupt()`, `request_decisions`, `decision_from_resume`,
`apply_decisions`. Phase 11's D-59.

**JSON-RPC, in two paragraphs.** MCP speaks JSON-RPC 2.0: a request is
`jsonrpc`, `method`, `params`, `id`; a response echoes the `id` and carries
`result` or `error`; an error has an integer `code` and a `message`. The one
thing to internalise is that JSON-RPC has no notion of a session, a connection
or an order — an `id` correlates one response to one request and nothing more.
Everything stateful MCP used to have, it built on top.

The second thing is `params._meta`: an open map where keys under
`io.modelcontextprotocol/` are reserved for the specification and anything
else is yours provided you namespace it (reverse-DNS). Much of the current
design lives here, and you will use it three times this phase.

**OAuth vocabulary, in two paragraphs.** The **resource server** holds the
data (an MCP server). The **authorization server** issues tokens. The
**client** asks for one. A **scope** names a permission; an **access token**
carries a set of them; the **subject** (`sub`) is who it is about; the
**issuer** (`iss`) is who minted it; the **audience** (`aud`) is which
resource server may accept it.

Three properties matter here. The audience stops a token for one server being
replayed against another. The subject makes an action attributable to a person
rather than a program. The lifetime is the only thing bounding damage from a
leak — which is why "short-lived" is in every recommendation and why a
long-lived credential in a config file is the most common real failure.
Appendix A has the RFCs.

## 6. [core] Core concepts

### 6.1 [core] The N×M problem, and what a protocol buys over a function call

**Intuition.** Four assistants, six systems, every assistant needing every
system: twenty-four integrations, each somebody's Python, in somebody's repo,
tested against nobody's staging. A seventh system costs four more adapters. And
the work grows in the *wrong organisation*: the team that understands the
warehouse writes none of it. A protocol makes the warehouse team write one
server and each assistant author one client. Twenty-four becomes ten.

**Precisely.** Direct integration is O(|H|·|S|) artefacts owned by host
authors; a protocol is O(|H|+|S|) owned by whoever owns the thing integrated.
The reduction is conditional, and the condition is the interesting part: **the
interface must be expressive enough that a system's server can be written once
without knowing which host will call it.** If the warehouse server must know
Atlas wants Markdown tables and the coding assistant wants JSON, you have moved
twenty-four integrations into six servers with four code paths each.

**Worked example.** Atlas's `query_db` is both a good and a bad candidate.
Good: "run a read-only query against curated relations" is system-shaped. Bad:
`format_rows` returns a fixed rendering chosen for Atlas's prompt and
`describe_schema` exists because Atlas's planner needs it. A server for
everyone returns structured rows and lets each host render — which is why the
current revision loosened output schemas to arbitrary JSON Schema and
structured content to any JSON value. The spec's evolution is largely a record
of the expressiveness condition failing in practice.

**What a protocol buys.** *Runtime discovery*: a host learns capabilities at
connection time, so a system adds a tool without any host shipping a release.
This is the property that justifies the trouble and also creates the security
problems in §6.10 — a tool description arriving at runtime from a party you do
not control is an instruction arriving from a party you do not control. *A
trust boundary you can enforce*: in-process, `read_only=True` is a boolean
somebody set (invariant 66 exists because a mislabelled boolean makes a
side-effecting tool replayable); across a protocol the boundary is a process
boundary and the server's refusal does not depend on the client getting a flag
right. This is a genuine strengthening of a guarantee and the main reason to
prefer a protocol even when N and M are both one. *Independent versioning and
deployment.*

**What it costs.** Latency and serialisation — nanoseconds become milliseconds,
twenty times per request. Less obviously, **a wire schema is a second
description of a shape**, and invariant 13 has said for ten phases that a
second description is drift waiting to happen. Atlas generates JSON Schema from
one Pydantic model precisely so this cannot happen internally; crossing a
boundary re-introduces it in the one place generation cannot fix it, because
the far side's schema is written by someone else. And a new trust boundary is a
cost even when nobody attacks you, because you must now think about it.

> **Misconception.** *"MCP is a REST API standard for AI."* A REST API is called
> by code that decided to call it. An MCP tool is called by a **model**, from a
> description in prose, chosen against other tools described in prose. The
> description is part of the interface in a way an OpenAPI `summary` is not —
> Phase 3 measured this, which is why `prompt_description` and not
> `description` goes on the wire. It also makes the tool *list* part of the
> prompt, which is why deterministic ordering and cacheable lists appear in a
> transport specification. A protocol whose client is a language model is a
> different object from one whose client is a program.

> **Concept check 1.** Three hosts, five systems, two systems used by exactly
> one host each. How many artefacts each way, and under what condition is
> direct integration *correct* for those two?

**Your turn (5 min).** List Atlas's eight tools; mark each system-shaped or
host-shaped with one sentence. Keep the list — §7 builds a server from the
system-shaped ones and §15 argues about a borderline case.

### 6.2 [core] Architecture and primitives

```
┌──────────────────────── HOST ────────────────────────┐
│  the application: Atlas, an editor, a chat product   │
│  owns the model loop, the user, and the policy       │
│   ┌────────── CLIENT ──────────┐  ┌──── CLIENT ────┐ │
│   │ one connection to one      │  │                │ │
│   │ server; speaks MCP         │  │                │ │
│   └────────────┬───────────────┘  └───────┬────────┘ │
└────────────────┼──────────────────────────┼──────────┘
                 │  MCP over stdio or HTTP  │
        ┌────────▼────────┐        ┌────────▼────────┐
        │     SERVER      │        │     SERVER      │
        │ warehouse tools │        │  calendar tools │
        └─────────────────┘        └─────────────────┘
```

The **host** owns the model, the conversation, the user's trust and every
policy decision — which is why the approval gate lives there and why a server
can never decide whether a human should be asked. The **client** is one
connector to one server. The **server** exposes capabilities and may be a local
subprocess or a remote service.

| Primitive | Controlled by | Shape | Atlas analogue |
|---|---|---|---|
| Tools | the **model** | named, schema'd, side-effecting | `ToolSpec`, `execute()` |
| Resources | the **application** | addressable read-only content at a URI | the RAG corpus, `Skill.resource()` |
| Prompts | the **user** | parameterised message templates | `atlas.prompts` files |

That column is the whole design. Tools are model-controlled, so they need
descriptions written for a model and a gate before the dangerous ones.
Resources are application-controlled: the host decides what enters context, so
a resource is *fetched*, not *called*, and is read-only. Prompts are
user-controlled — a slash command — which is why they are the primitive you
have probably never used.

Two consequences. Resources being application-controlled is why Skills over MCP
chose Resources (§6.8): a skill is know-how the host loads, not an action the
model takes. And resources being read-only by definition puts the read/write
asymmetry Atlas has enforced since Phase 3 in the protocol's type system rather
than in a boolean, for that primitive.

> **Concept check 2.** Should Atlas's RAG index be a tool or a resource? Does
> your answer change if retrieval involves a query the model writes?

### 6.3 [core] Statelessness, and what it actually means

**What it was.** A connection opened with `initialize`, the server replied with
capabilities, the client sent `notifications/initialized`, and the server
issued a session id echoed in an `Mcp-Session-Id` header on every request.
Capabilities were negotiated once for the session's life, and a server could
return different tools to different connections. Server-to-client requests
travelled back down the open connection.

Fine for one process on a laptop. It falls apart when the server is remote and
replicated, because the session pins a client to one instance: sticky routing,
a load balancer that must understand MCP, a restart that drops live
conversations, and scaling out that does not help existing clients.

**What it is now.** The handshake is gone. `Mcp-Session-Id` is gone. Every
request stands alone:

```json
{"jsonrpc":"2.0","id":7,"method":"tools/call",
 "params":{"name":"query_company_data","arguments":{"sql":"select 1"},
  "_meta":{
   "io.modelcontextprotocol/protocolVersion":"2026-07-28",
   "io.modelcontextprotocol/clientInfo":{"name":"atlas","version":"0.1.0"},
   "io.modelcontextprotocol/clientCapabilities":{},
   "traceparent":"00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
   "com.atlas/token":"…"}}}
```

Version, client identity and capabilities ride in `_meta` on every request.
Servers identify themselves in each result's `_meta`. An unsupported version is
its own error. In place of the handshake there is `server/discover`, which
servers **must** implement and clients **may** call — up front to pick a
version, or as a compatibility probe. And list endpoints no longer vary per
connection: they are properties of the server, not of who is asking.

**Four operational consequences**, worth being able to recite:

1. **Any instance serves any request.** No session store, no sticky routing.
   Round-robin is correct.
2. **Restarts and scale-out stop being outages**, because there is no transport
   state to drop.
3. **Lists are cacheable and shareable** (§6.4) — sound *because* they no
   longer vary per connection. The removal enabled the optimisation.
4. **A broken stream loses the in-flight request and nothing else.** SSE
   resumability and redelivery are gone; a client re-issues with a **new
   request id**. A real trade, and the reason the Tasks extension exists.

> **Misconception, the one that trips everybody.** *"Stateless means the server
> cannot remember anything."* It means the **protocol** carries no session. Your
> application may hold as much state as it likes; what changed is how a client
> refers to it. A server needing cross-call state mints an **explicit handle**
> and returns it, and the client passes it back as an ordinary tool argument —
> a `cursor`, a `draft_id`, a `checkout_id`. State moved from an invisible
> property of the connection to a visible value in the payload: inspectable,
> attributable, and with a lifetime somebody decided rather than inherited from
> TCP.

Compare invariant 61: persistence changes the lifetime of every channel,
including the ones you thought were locals, and the fix was to reset every
non-message channel explicitly. The protocol made the same move in the other
direction — it deleted the implicit lifetime and made every caller name what it
wants to persist. *Implicit lifetime is where bugs live.*

> **Concept check 3.** A server exposes `begin_export`, `poll_export`,
> `download_export`. Previously it keyed all three off the session. Now, what
> must `begin_export` return, and name two properties that value needs which a
> session id did not.

### 6.4 [core] Four small changes that follow from one big one

**Routing headers.** Streamable HTTP POSTs carry `Mcp-Method` and `Mcp-Name`
duplicating the body, and tool parameters can contribute custom headers. Not
redundant: **a gateway can authorize and route without parsing a JSON body**,
so "deny `tools/call` for `delete_repository` to this token" is a header match
at the edge. The headers must agree with the body — a gateway authorizing on a
header while the server dispatches on a body is a bypass with a name.

**Cacheable lists.** List and read results carry `ttlMs` (a freshness hint) and
`cacheScope` (`public`/`private`, controlling shared intermediaries). HTTP
caching semantics, sound only because lists no longer vary per connection.
`private` is the default a naive server emits; marking a per-user list `public`
is a cross-tenant leak in one word.

**Deterministic tool order.** Servers *should* return tools deterministically,
and the stated reason is upstream **prompt cache hit rates**. Phase 8 measured
why, and `ToolRegistry.names` has been sorted since Phase 3 with the comment
*order stability is a cache key*. When your own justification turns up in
someone else's specification, that is the strongest available evidence you
understood the constraint rather than the workaround.

**Per-request logging, and two removals.** `ping` and `logging/setLevel` are
gone; log level travels per request in `_meta`, and a server must not emit log
notifications for a request that did not ask. Correct for a stateless world,
where "set the level for this session" has no referent. The error range was
also partitioned, with the draft's codes renumbered, and resource-not-found
moved to Invalid Params to align with JSON-RPC. Exact codes: `VERSIONS.md`.

The through-line: **remove the session and a dozen features that existed to
manage it become unnecessary or expressible in ordinary HTTP terms.** A
specification that shrinks is usually one that found its abstraction.

### 6.5 [core] Multi Round-Trip Requests: "the tool needs to ask the user"

**Intuition.** A tool is halfway through and needs something only the caller
has — a confirmation, a choice between two matching records, a credential.
Previously the server opened its own request back to the client and waited.
That is the natural way to write it and the first thing statelessness breaks,
because there is no connection to ask down. Verbatim, from a server run while
writing this section:

```
mcp.shared.exceptions.NoBackChannelError: Cannot send 'elicitation/create':
this transport context has no back-channel for server-initiated requests.
```

Copy a mid-call elicitation out of an older tutorial and that is your error. It
is a good error: it names the missing thing rather than hanging.

**The replacement inverts the direction: the server returns.** Every result
carries a required `resultType` — `"complete"` ordinarily, `"input_required"`
for an interim result carrying two fields. **`inputRequests`**: what the server
needs, as a map keyed by names *the server chose*, each value one of the same
three payloads the old back-channel used. **`requestState`**: an opaque token
the client echoes verbatim, which only the server reads.

The client fulfils each request and **re-issues the same call** — same method,
same name, same arguments — with answers in `inputResponses` under the matching
keys and `requestState` echoed. The retry is an independent request with a new
id. It may land on a different instance, or be sent by a different process. It
may repeat. Nothing ever flows server-to-client outside a response. For
compatibility, a client **must** treat a result omitting `resultType` as
complete.

One round, as a sequence. Notice that every arrow points the same way:

```mermaid
sequenceDiagram
    participant H as Host (Atlas)
    participant S as Server
    H->>S: tools/call  append_company_note(path, content)
    S-->>H: resultType "input_required"<br/>inputRequests{approve}<br/>requestState (opaque)
    Note over H: the host asks a human<br/>(Atlas: interrupt(), a checkpoint)
    H->>S: tools/call  SAME name, SAME arguments<br/>+ inputResponses{approve}<br/>+ requestState echoed
    S-->>H: resultType "complete"
```

**Same idea as Phase 10's interrupt; here is where the analogy stops.** Both
replace "block and wait" with "return and be re-entered", so both need
somewhere to keep the pause. Atlas keeps it in the checkpointer, which is why
`allow_writes=True` without one is refused at wiring time. MCP keeps it **in
the payload** — and that is the difference: Atlas's pause is server-side state
under Atlas's control, and MRTR's pause is a token held by a party the server
does not trust.

That is MRTR's whole security story. `requestState` is a **continuation token
handed to an untrusted party and asked for back**: it can be modified, kept
past usefulness, or lifted from another call. The specification requires
servers to integrity-protect it and reject the round when verification fails,
wherever the state can influence authorization, resource access or business
logic. A well-built server binds each token to a time window, to the
originating request (method, tool name, a digest of arguments) and to the
authenticated principal, so state minted for one user cannot be redeemed by
another and a token replayed against a different tool fails. Every failure —
tampered, expired, replayed, or sealed under an unknown key — returns *one*
frozen message, so the wire never reveals which check failed while the real
reason goes to the log.

Two of those are old friends: "bind the token to the work, not the attempt" is
invariant 37's idempotency rule with new nouns, and "one frozen message" is the
same discipline as a refusal written for the model rather than the diagnostician.
The third, binding to the principal, is §6.7 — which is why identity must be
settled before any of this can be built safely.

**Tasks, and how to choose.** MRTR handles "I need something before I can
finish". It does not handle "this will take four minutes": that is the **Tasks**
extension, which moved out of the core into an official extension and was
redesigned around polling.

The shape, so you can recognise it in the wild. A server may answer
`tools/call` with a **task handle** instead of a result — and, in the current
design, it may do so *unsolicited*, without the client having opted in on that
request, so a client must be prepared for a handle wherever it expects a
result. The client then drives the work with three methods: `tasks/get` to
poll, `tasks/update` to send input the server asked for mid-flight, and
`tasks/cancel` to abandon it. The blocking "give me the result when it is
ready" method was removed, and so was `tasks/list` — which is worth a moment's
thought: a task list is a query over server state, and a stateless protocol has
no place to answer it from, so enumerating your own outstanding tasks is now
the client's bookkeeping, not the server's.

Atlas does not use Tasks and this phase does not build it, for a reason worth
stating rather than leaving implicit: every Atlas tool completes inside one
model step, and a step that takes four minutes would blow the step budget long
before it blew a timeout. When Atlas grows a genuinely long-running action —
Phase 16's containerised service is the first place it plausibly might — the
handle is the mechanism, and it will look exactly like §6.3's server-minted
handle with a polling protocol attached.

| Situation | Mechanism |
|---|---|
| The current request cannot proceed without an answer | **MRTR** |
| The work must continue while the client is away | **Tasks** |
| The state is large, sensitive, or belongs in your database | a **server-minted handle** |

Notice why Tasks became necessary at the same moment resumability was removed:
once a broken stream loses the in-flight request, "hold the connection for four
minutes" stops being a design. The removals and additions are one decision seen
from two sides.

> **Concept check 4.** Suppose the file store moves behind an MCP server and the
> *server* asks for confirmation via MRTR. Name one thing this improves and one
> it makes worse. Which invariant speaks to the second?

**Your turn (10 min).** Write the two JSON-RPC messages of one MRTR round for a
`schedule_meeting` tool that must ask which of two people named "Chen" was
meant. Choose the `inputRequests` key; write down what you would put in
`requestState` and what you would deliberately keep out.

### 6.6 [core] Extensions, the deprecation policy, and reading an older tutorial

**Extensions.** Client and server capabilities gained an `extensions` field,
and capabilities beyond the core live in named extensions under a formal
framework — Tasks joined the ones already there. This is how a protocol grows
without its core growing: an extension is discoverable, optional,
independently versioned, and its absence is a normal condition rather than an
error. Your client should behave correctly against a server that does not
advertise one.

**A deprecation policy with a number in it.** Three feature states — Active,
Deprecated, Removed — a **minimum twelve-month window**, and a public registry.
Under it:

| Deprecated | Still works? | Use instead |
|---|---|---|
| **Roots** (the client telling a server which local paths it may reach) | Yes, during the window | directories/files as **tool parameters**, **resource URIs**, or server configuration |
| **Sampling** (the server asking the client to run a completion) | Yes, during the window | integrate **directly with an LLM provider API** |
| **Logging** | the feature is deprecated; the level-setting method is already removed | **stderr** on stdio, or **OpenTelemetry** |

Also reclassified: the old HTTP+SSE transport, and two `includeContext` values.
On the authorization side, Dynamic Client Registration is deprecated in favour
of Client ID Metadata Documents.

**Do not use any of the three in new code.** A twelve-month window is a promise
about a removal date, not a recommendation. And note the shape of every
migration: each replaces a *protocol* mechanism with something outside it.
Roots becomes an argument; Sampling becomes your own provider call; Logging
becomes stderr or an existing telemetry standard. The protocol is shedding
responsibilities that were only there because it had a session to hang them on.

Sampling deserves a sentence, because its deprecation removes something people
liked: a server borrows the host's model, so the server author needs no API key
and the user pays for their own tokens. Elegant, and unimplementable without a
back-channel. Take the general lesson: **a feature that requires an
architectural property is only as durable as that property.**

#### If you read an older tutorial, here is what changed and why

| If the tutorial says… | Status now | Why |
|---|---|---|
| `initialize`/`initialized` handshake | **Gone**; version, client info, capabilities in `_meta` per request | the handshake *was* the session |
| `Mcp-Session-Id` | **Gone** | same |
| "the server returns different tools per connection" | **No** | required for cacheable, shareable lists |
| nothing about `server/discover` | **Servers must implement it** | replaces the handshake's discovery role |
| `ping` | **Removed** | a liveness check for a session |
| `resources/subscribe`, the HTTP GET endpoint | **Replaced** by one long-lived POST-response stream with per-type opt-in | one mechanism instead of three |
| `Last-Event-ID`, SSE ids, resumability | **Removed**; re-issue with a new id | recovery is Tasks' job now |
| `ctx.elicit(...)` mid-call, any server→client request | **Return an input-required result** | §6.5 |
| elicitation completion notifications and ids | **Removed** | the client learns by retrying; encode your own id in `requestState` |
| Dynamic Client Registration as *the* way to register | **Deprecated** | §6.7 |

Rows the table omits because §6.6 already states them: per-request capability
negotiation, `logging/setLevel`, the three deprecated features, Tasks becoming
an extension, and the HTTP+SSE transport.

One entry deserves a warning rather than a row. A widely-cited critique of a
competing protocol, written in early 2026, rested on the claim that *MCP
servers are inherently stateful*. True when written; false now. **Check the date
on every architectural comparison you read**, including §6.11, and including
this document.

> **Concept check 5.** A pull request sends `initialize`, stores the returned
> session id, and includes it as a header on every later request against a
> current server. Predict what happens — and why the failure is *confusing*
> rather than clean.

### 6.7 [core] Identity and delegated authorization: who is the agent acting as?

**Intuition.** A new colleague needs the warehouse system. Nobody gives them
the administrator password: they get their own account with the permissions
their job needs, disabled when they leave. So obvious it is invisible — and
almost every agent deployment gets it wrong, because an agent is a program, and
programs historically got a service account with broad permissions.

That worked when the program did one thing. An agent does whatever a user asked,
and the set of things a user might ask is not enumerable at design time. So
*who is the agent acting as* has a real answer for the first time, and getting
it wrong has a name.

**Two identities, and you need both.** A **workload identity** — this is Atlas,
this version, this deployment — answers "which program?" and is what you use
for rate limits, quotas, telemetry and revoking a compromised deployment. A
**user identity** — this is Priya, employee 4471 — answers "on whose behalf?"
and is what authorization and audit run on.

The common failure is collapsing them. A token saying only *this is Atlas*
leaves the far side unable to enforce anything user-specific: every request
looks identical and "Priya may see her team's data" is unenforceable at the
boundary. A token saying only *this is Priya* means you cannot revoke Atlas
without revoking Priya, and cannot tell her own browsing from an agent acting
for her in the log. **On-behalf-of** flows carry both.

**The confused deputy, precisely.** A confused deputy holds authority and is
tricked into exercising it for someone who lacks it. The deputy is not
compromised — it is doing exactly what it was built to do, using its own
credentials to serve a request — and the bug is that it never checked whether
*this requester* was entitled to *this effect*.

Concretely: Atlas holds a credential for the document store, because it needs
one to answer questions about documents. Sam asks Atlas to summarise
`/hr/reviews/2026.md`. Atlas does not know `/hr/` is restricted; it has a
credential that can read it; retrieval succeeds; Atlas summarises Priya's
salary for Sam. No attacker, no injection, no exploit. Atlas was the deputy, its
authority was real, and the missing thing was the question "may Sam read this?"

The structural fix is the one thing to remember: **the deputy must act with the
requester's authority, not its own.** Not "read the file, then check whether Sam
should have seen it" — that check is a filter over data already in the context
window, and by then the model has read it. The credential presented must *be*
Sam's, scoped to what Sam may do, so the store's own refusal is the enforcement.

This is why `issue_token` has no default for `scopes` and refuses an empty
`audience`, and why the token names a `subject`. The audience matters
particularly: a credential for the document store must not be replayable
against payroll, because a deputy holding one all-purpose credential can be
confused in as many ways as it has downstream systems.

**Why "the agent has the admin token" is the most common real failure.** A chain
of individually reasonable steps. The agent needs access, so a credential is
created. Scoping it requires knowing what it will need, which nobody knows yet,
so it gets broad permissions "for now". It goes in an environment variable. It
is long-lived, because rotation means coordinating a deploy. And then it works,
and nothing forces a revisit — a broad credential produces no error, no log line
and no failing test. **Over-permissioning is the only security defect whose
symptom is that everything works.**

The consequences compound. A long-lived broad token in an environment variable
is readable by any code in the process, including a sandboxed `run_python` tool.
It appears in debug traces, which is where compaction and tracing put things.
And a prompt injection reaching an agent holding an admin token has escalated to
an admin — OWASP's agentic list files this as **ASI03, identity and privilege
abuse**, and Phase 14 builds the defences.

**What the current spec provides.** MCP authorization is OAuth 2.0 and OpenID
Connect, tightened in three ways worth knowing. **Issuer validation**: a client
must validate a present `iss` against the recorded issuer before redeeming an
authorization code, closing a class of mix-up attack. **Credentials bound to
their issuer**: keyed by issuer identifier, never reused across authorization
servers, re-registered when the server changes. **Registration moved**: the
client's identity becomes a URL serving a metadata document, so there is no
registration call and no per-server client record — with an explicit trade-off,
since a URL-based client identity is shared by *every user of that software*,
which is why a state seal binding only to the client and not the subject is
weaker than it looks. Exact SEP numbers and RFCs: `VERSIONS.md`.

> **Misconception.** *"We authenticate the connection, so we know who is
> calling."* There is no connection. Authorization is per request, on every
> request, or it is nowhere. The spec did not add this burden — it was always
> there, hidden by a session that made one check look like many.

> **Concept check 6.** Atlas issues Priya a read-only token and passes it to the
> document server, which also exposes a delete tool requiring a write scope. An
> injection in a retrieved document instructs Atlas to delete a file. Trace what
> happens, name the *two* independent mechanisms that stop it, and say which
> would still be standing if the other were misconfigured.

**Your turn (10 min).** Write the `granted_scopes` call that mints the research
workers' token. Then write down what happens if somebody later adds a write tool
to `HANDLER_TOOLS["research"]`. Does the token widen automatically, and is that
what you want?

### 6.8 [core] Skills over MCP: shipping the manual with the product

Phase 8 built skills and the token arithmetic that justifies them: level 1
(name and description) paid on every request forever, level 2 (the procedure)
on activation, level 3 (references) per use.

An MCP server gives an agent tools. Tools say *what* each one does and nothing
says *how to orchestrate several of them* — the gap skills fill. So: ship the
know-how down the same channel as the capability.

The design serves skills as **Resources** under a `skill://` scheme rather than
adding a fourth primitive, and the reason is §6.2's control column. A skill is
content the *host* decides to load: application-controlled, addressable,
read-only. Making it a tool would hand the model a "load the procedure" action,
turning a context-engineering decision into a model-controlled branch, which
invariant 33 forbids while the catalogue is enumerable. Making it a new
primitive would require every client and SDK to change to carry something the
existing primitive already expresses.

The convention: a catalogue at `skill://index.json`, each manifest at
`skill://<name>/SKILL.md` with the final path segment equal to the frontmatter
name, supporting files under their relative paths. There is no host in a
`skill://` URI — the connection supplies the server, the way a relative link's
page supplies the site.

**This is a draft.** Atlas depends on none of its methods: no skills-specific
RPCs, no capability advertisement. What §7.6 adopts is the *convention*,
expressible entirely in `resources/list` and `resources/read`, which would
remain valid if the SEP were withdrawn. `VERSIONS.md` carries the row and the
forward pointer.

And the design has a property I did not plan: **the authorization boundary lands
exactly on Phase 8's level boundary, because the SDK forces it there.** A static
resource handler cannot receive a request context, so it cannot see `_meta`, so
it cannot see the token, so it *cannot be scope-checked*. A URI-template handler
can. So the index — level 1, no company data — is static and open, and the
bodies and references are behind a template requiring a scope. Two independent
lines of reasoning, one from token cost and one from an SDK's injection rules,
producing the same partition.

### 6.9 [core] Gateways: the Phase 8 pattern at the protocol layer

Phase 8 established that a large tool catalogue is a retrieval problem, and the
answer was search-and-execute. A **gateway** is that pattern at the protocol
layer, plus policy: one MCP endpoint in front of many servers, doing four
things a client cannot.

**Authorization as a policy enforcement point** — one place knowing which
subjects may call which tools, which is what §6.4's routing headers are *for*,
provided it also rejects a header disagreeing with the body or the enforcement
point becomes the bypass. **Rate limiting per subject and per workload** — the
concrete reason you want workload identity too. **Federation and a catalogue** —
forty servers as a searchable catalogue rather than four hundred schemas.
**Audit in one place**, which is why `CallAudit` is a structured record per
decision rather than a log line.

The trade-off is honest: a gateway is a single point of failure, a single point
of compromise, and a party that sees every request. Right for a company with
many servers; wrong for a laptop with two.

### 6.10 [core] MCP security: the threats, the list, and a checklist

**Tool poisoning.** A tool description is prose reaching the model at runtime
from a party you do not control, so it is an *instruction channel*. The
sub-techniques have names: **rug pulls** (a trusted tool updated maliciously),
**schema poisoning** (a corrupted interface definition that misleads the model),
**tool shadowing** (a fake or duplicate tool intercepting calls). The general
form is why §6.1's misconception matters: a protocol whose client is a language
model has made its documentation part of its attack surface.

**Over-permissioned servers** — §6.7 from the server's side: a server holding
one broad credential to its backend is a confused deputy waiting for a request,
however carefully its clients scope their own tokens. **Supply chain** —
servers are packages with dependencies, and a compromised one can alter agent
behaviour or introduce backdoors.

The **OWASP MCP Top 10** names these and seven more. It is a community
framework in **beta** whose categories are stable enough to cite while rankings
and descriptions may shift:

| | Category | Atlas's existing answer |
|---|---|---|
| MCP01 | Token Mismanagement & Secret Exposure | short-lived scoped tokens; secrets excluded from `repr` since Phase 0; no `os.environ` outside config |
| MCP02 | Privilege Escalation via Scope Creep | exact scope membership, no wildcards; `granted_scopes` derived from the tool set |
| MCP03 | Tool Poisoning | Phase 7's untrusted-content framing; defences in Phase 14 |
| MCP04 | Supply Chain & Dependency Tampering | pinned versions with dated provenance |
| MCP05 | Command Injection & Execution | read-only SQL boundary, path jail, code sandbox |
| MCP06 | Intent Flow Subversion | the approval gate; consequence renderers |
| MCP07 | Insufficient Authentication & Authorization | per-request verification, per-tool scope checks |
| MCP08 | Lack of Audit and Telemetry | `CallAudit`, the cross-thread audit trail, trace context |
| MCP09 | Shadow MCP Servers | a gateway and a catalogue; nothing in Atlas yet |
| MCP10 | Context Injection & Over-Sharing | per-user memory namespaces, `cacheScope` discipline |

One detail is worth noticing rather than glossing: the project's own page names
MCP06 differently in its summary and its body. That is what beta means, and it
is a better argument for reading the primary source than any warning here.

**The checklist.** Ten questions, each answerable yes or no about a real
deployment.

1. Does every request carry a **subject**, or only a workload identity?
2. Is every token **audience-bound** to the server it is presented to?
3. Is every token **short-lived**, with the ceiling enforced in code?
4. Is the scope **required by the server** per tool, from an enumerated table?
5. Does a refused call produce an **actionable observation** that reaches
   escalation, rather than an exception or silence?
6. Does a refusal avoid **enumerating what the caller does hold**?
7. Is `requestState` **integrity-protected**, and do you know which of its
   bindings are live in your deployment?
8. Is `cacheScope` **private** for anything user-specific — checked, not assumed?
9. Is there a **structured audit record** per decision that a test asserts on?
10. Are **tool and skill descriptions** reviewed as published text, given that
    they are served to everyone who can reach the endpoint?

### 6.11 [core] Agent-to-agent protocols: when does this matter yet?

**A2A** addresses a different problem from MCP: not an agent calling a tool, but
an agent delegating to another agent with its own model, loop and opinions.
Originated at Google, transferred to the Linux Foundation with vendor-neutral
governance, v1.0 released in April 2026 alongside an announcement of 150+
supporting organisations and production deployments across several verticals.

The honest answer to "when does this matter yet" is: **probably not to you, this
year, and you should know why rather than be told.** The announcement reported
organisations and integrations rather than deployment counts or usage metrics,
and independent analysis pointed out the asymmetry with a protocol having
thousands of public servers and measurable developer adoption; a contemporary
critique attributed A2A's thinner uptake to use cases and implementation burden.

Read that critique carefully and its central technical claim was *MCP servers are
inherently stateful* — true when written, false four months later. Which is the
point to take from this section more than any fact about A2A: **an architectural
comparison is a snapshot, and this field invalidates snapshots quarterly.**

Phase 11's D-59 is the connection. A protocol for agents talking to agents is
worth adopting once you have decided you need agents talking to agents, and D-59
declined that with four measured reversal conditions. Interoperability does not
change the calculation; it changes what it costs once you have made it.

### 6.12 [core] Computer-use and browser agents: reading only

*Reading, not building — the build is Appendix F.7 — but [core], because
objective 11 is core and the fast track must not miss it.*

A computer-use agent runs Phase 3's ReAct loop with one substitution: the
observation is a **screenshot** and the action is a **mouse or keyboard event**.
Screenshot, send to a vision model with the goal and history, receive an action
with coordinates, execute, screenshot again.

Two representations compete. **Pixels** work on anything — legacy desktop
software, a canvas, a video — which makes the technique general, and are
expensive (an image per step), imprecise (a predicted coordinate can miss a
button) and fragile (a redesign invalidates everything). An **accessibility
tree**, the structured representation browsers already expose for screen
readers, gives named elements instead of coordinates: cheaper, more reliable,
immune to restyling, and incomplete, because elements without accessibility
metadata are invisible. Serious systems use both.

The reliability limit compounds: per-step success p over n steps gives p^n if
failures are independent, and Phase 1's arithmetic on exactly this quantity is
why a twenty-step task at 95% per-step succeeds about a third of the time.
Failures also do not partition into recoverable and fatal — a click on the wrong
element can navigate away from a form holding twenty minutes of state.

The safety case rests on a **domain allowlist**, and it is worth understanding
why that control specifically. A browser agent's action space is the entire
internet and its observation space is attacker-controlled content: every page is
an injection vector aimed at an agent that can click. An allowlist converts an
unbounded action space into an enumerable one, which is invariant 20 with a URL
instead of a tool — *a prohibition is an absent capability wherever it can be*.
The build is Appendix F.7.

## 7. [core] Hands-on: build it

Full file text is in `atlas_phase_12.zip`; §11 lists what changed. This section
is the decisions.

### 7.1 The scope vocabulary

`atlas/auth/scopes.py` holds a closed `Scope` literal and an **enumerated**
table from tool to required scope:

```python
# excerpt: atlas/auth/scopes.py
TOOL_SCOPES: dict[str, Scope] = {
    "query_company_data": "company_data:read",
    "search_company_docs": "documents:read",
    "append_company_note": "workspace:write",
}
```
 It is tempting to derive it — anything named
`append_*` needs a write scope — and that is invariant 18's mistake relocated:
a rule inferred from a name changes meaning when somebody renames a tool.
`unscoped_tools()` lets a server refuse to start while any exposed tool has no
entry, which is `MissingConsequenceRenderer`'s argument one layer out: a tool
whose authority nobody described does not get a permissive default, because the
permissive default is the one nobody notices.

### 7.2 Tokens

`atlas/auth/tokens.py` mints and verifies. Four properties carry the lesson —
subject, scopes, expiry, audience — and the audience is the one people leave
out, so it has no default and an empty one raises. Verification order is
**signature first**, because every claim below it is attacker-controlled until
the signature is checked; a verifier reading the audience from an unverified
payload has already branched on a value somebody else chose. Comparison is
constant-time. Every failure returns one message with the real reason on
`.detail`:

```
TokenError: invalid or expired token | token audience 'atlas-company-data' is not 'other'
TokenError: invalid or expired token | subject 'priya' holds ['company_data:read'], needs 'workspace:write'
```

Four causes, four distinct `.detail` strings, one identical message. A verifier
that tells you *which* check failed is an oracle; a test asserts the details
differ and the messages do not.

Note the split of exception types. A bad *issuance* request — no subject, empty
audience, unknown scope, a ttl over the ceiling — raises `ValueError`, not
`TokenError`. Invariant 67 is the reason: an `except TokenError` that also
caught "you asked for a scope that does not exist" would convert a typo into an
authorization outcome, which is Phase 11's defect somewhere it would be a
security bug rather than a wrong answer.

### 7.3 The server

Three tools under system-shaped names, each **delegating to
`atlas.tools.registry.execute`** rather than calling a tool body: one dispatch
path, one order of checks, one output cap, one guarantee nothing raises. A
server with its own dispatch is F-08-02's defect at a process boundary.

The wire carries Atlas's `ToolResult` as **structured content**, not text. The
temptation is real — a tool error produces a readable message and the client
could scrape `error_kind` from it, after which editing that message would
silently change what the eval harness grades. Invariant 65 forbids it.

A refused scope is a **result, not a transport error**. MCP's error flag means
"could not be processed"; a scope refusal means "processed, and the answer is
no", which the agent can act on — Phase 3's argument for `write_refused` over
an exception, unchanged. Which is why the client's converter consults structured
content first and the error flag only on the text path: treating the flag as
authoritative would relabel every refusal as a tool error and escalation would
stop seeing `authority_missing`.

### 7.4 MRTR, wired to the Phase 10 interrupt by hand

`append_company_note` returns an input-required result first and writes only
after confirmation. The client owns the loop:

```python
# excerpt: atlas/mcp/client.py
                result = await client.session.call_tool(
                    name,
                    arguments,
                    meta=meta or None,
                    input_responses=responses,
                    request_state=state,
                    allow_input_required=True,
                )
                if isinstance(result, CallToolResult):
                    out = _as_tool_result(name, result)
                questions = _questions_from(result, tool=name)
                answers = confirm(questions)
```

The SDK will run the loop for you if you register a callback, and **a callback
cannot suspend a graph run**: it must answer synchronously, inside the call,
inside the event loop. Atlas's answer comes from a human via `interrupt()`,
which unwinds the whole invocation. So `confirm` is injected, and
`interrupt_confirmer()` is the one that raises.

Two consequences. First, `interrupt()` destroys the loop mid-round, so on resume
the call is **re-driven from the top**: the server is asked again, returns the
same question, and this time `interrupt()` returns the answer. Safe *only
because round 1 of an MRTR flow has no side effect by construction* — a
requirement on the server, not a property of the protocol. Against a server you
did not write, check it: if round 1 bills a card and then asks whether you meant
it, an interrupt bills it twice.

Second, the async bridge cost a real defect. `confirm` raises inside
`anyio.run`, inside the SDK client's task group, and a task group re-raises what
escaped it **wrapped** — measured, two levels deep as
`ExceptionGroup(ExceptionGroup(GraphInterrupt))`. The first draft checked the
outer exception's type name, never matched, and converted the pause into a tool
error. The fix walks the group tree; the generalisation is invariant 70, and
§7.8 shows the same mistake one layer further out.

Verified end to end through a real graph:

```
PAUSED: True
ASKED:  Append to the shared company note? This is visible t...
file mid-pause: False
RESUMED: ok=True kind=None :: created n.md (2 characters)
file after: True
```

All six resume shapes resolve without re-pausing, with unrecognised input
declining: `True` / `{"approve": True}` / `{"answers": {...}}` write; `False` /
`{"approve": False}` / `"nonsense"` give `write_refused` and write nothing.

### 7.5 Testing the server: the Inspector, and what it is for

Before wiring anything into Atlas, run the server against the **MCP
Inspector** — the official interactive client, and the fastest way to answer
"is my server wrong, or is my client wrong?" It connects to a server over
stdio or HTTP, lists the tools, resources and prompts it advertises, and lets
you call them by hand with arguments you type.

Three things it tells you that a Python test does not, and they are the reason
to spend ten minutes on it before writing the client:

**What your tool descriptions actually look like.** You wrote them for a model
and you have never read them as a stranger would. The Inspector shows the
rendered list, and this is where you discover that `path` has no description
or that two tools sound identical.

**Whether the failure is yours.** An in-process test exercises your handler
through the SDK's own dispatcher. The Inspector is a *separate process* with
an independent implementation of the client half, so if it can call your tool
and your client cannot, the bug is in your client — which halves the search
space at the moment you most need it halved (§8.1 is that bug).

**What the wire really carries.** It shows the raw JSON-RPC, so `_meta`,
`resultType`, `ttlMs` and `cacheScope` stop being things you read about and
become things you have seen.

Invoke it with `npx` against the stdio entry point, or point it at a URL for
an HTTP server; the exact command and package name are current-state facts and
live in `VERSIONS.md`.

`# not executed during authoring; verified in companion-repo CI` — the
Inspector needs Node and a browser, neither of which the authoring environment
has. What *was* executed here is the in-process equivalent: `mcp.Client(server)`
speaking the real protocol with no socket, which is what every test in this
phase uses and what makes `make test-offline` possible. The two are
complementary and neither replaces the other: the in-process client proves your
handler logic, and the Inspector proves your transport and your prose.

### 7.6 Scope enforcement, refused when exceeded

Measured, in order, against one server (`make results PHASE=12`, experiment 2):

```
granted read    (documents:read)   ok=True   kind=None
missing scope   (documents:read)   ok=False  kind=scope_refused
wrong audience  (atlas-calendar)   ok=False  kind=scope_refused
bad signature                      ok=False  kind=scope_refused
no token                           ok=False  kind=scope_refused
granted write   (workspace:write)  ok=True   kind=None
declined write  (workspace:write)  ok=False  kind=write_refused
files written by refused calls: []
```

The refusal is checked **before** the question is asked — never interrupt a
human about a call that cannot succeed — and names what is missing without
enumerating what the token holds, because a refusal that lists your scopes is a
scope-discovery oracle. Both are tests.

Adding `scope_refused` to `ErrorKind` widened a closed literal, which is an
interface change (§11). It also required a line in `should_escalate`, and
invariant 39 made that part of the same commit:

```python
# excerpt: atlas/graph/escalate.py
AUTHORITY_ERROR_KINDS: frozenset[str] = frozenset({"write_refused", "scope_refused"})
    if AUTHORITY_ERROR_KINDS & set(error_kinds):
        return "authority_missing"
```

Without it, a scope-refused run would spend its whole step budget retrying a
call that can never succeed, then escalate as `no_progress_exhausted` — a
handoff asking the operator the wrong question.

Least privilege, computed per route rather than intended:

```
chat         (none)
document     documents:read
data         company_data:read
research     company_data:read, documents:read
tool_action  workspace:write
```

That table is D-59's reversal condition 3, satisfied: the read routes and the
write route now hold different credentials, derived from the registry scoping
that already existed.

### 7.7 One skill as `skill://` resources, and trace context

The index is static and open; bodies sit behind `skill://{name}/{+path}` and
require a scope. `{+path}` is RFC 6570 reserved expansion, and plain `{path}`
**does not match a slash** — so the manifest worked and a nested reference came
back as "Unknown resource": a level-3 hole every level-2 test would have missed.

Trace context propagates as `traceparent` in `_meta` — bare, not namespaced,
because these are the W3C names your HTTP infrastructure already understands.
`new_traceparent()` mints a fresh span per call; the server records the trace id
rather than the whole header, because the span id changes per hop and the trace
id is the join key. A malformed value yields `""` and does not break the call.
Measured: 9/9 audit records carried the client's trace id. Phase 15 owns the
tracer; the id has to exist now, because a trace context you start propagating
later cannot be joined to calls you already made.

### 7.8 Wiring it into Atlas — and why this subsection exists

Everything above is a library. A library is not a capability, and the first
draft of this phase shipped one while the capstone claimed the other.

```
$ grep -rn "atlas.mcp\|atlas.auth" --include=*.py atlas/ | grep -v "^atlas/mcp/\|^atlas/auth/"
(nothing)
```

Four modules, 53 green tests, and no module in `atlas/` importing either
package. `granted_scopes` was called only by the results script. No registry
held an MCP-backed tool; no Atlas request carried a subject anywhere. That is
**invariant 41's seventh appearance**, committed in the phase that added
invariant 71 about exactly this — and it is F-12-05, worth reading before you
build your own, because the failure is invisible from inside: every test
passed, because every test supplied the composition the code expected.

The audit that catches it is mechanical (invariant 63): grep every public name
the phase added across `atlas/`, and name the call site on the default path.
Three pieces do it.

```python
# excerpt: atlas/mcp/tools.py
    scopes = remote_scopes_for(wanted)
        return issue_token(
            subject=user_id,
            audience=COMPANY_DATA_AUDIENCE,
            scopes=scopes,
            secret=secret,
```

**One, the tools are ordinary tools.** `atlas/mcp/tools.py` builds `ToolSpec`s
through `@tool`, so the schema and the validator come from one signature and
the model cannot tell local from remote. It should not be able to: "this tool
lives in another process" is not a fact a model can act on, and a marker in the
description would invite it to reason about transport.

**Two, the route table grants them.** `HANDLER_TOOLS` gets three appends, and
the shape of the grant is the privilege separation:

```python
# excerpt: atlas/flow/app.py
HANDLER_TOOLS["data"] += ("company_data_query",)
HANDLER_TOOLS["research"] += ("company_data_query", "company_docs_search")
HANDLER_TOOLS["tool_action"] += ("company_note_append",)
```

`research` gets two reads and no write. So `remote_scopes_for` — which reads
this very list — *cannot* mint `workspace:write` for a research worker, because
there is no write tool to derive it from. That is **D-59's reversal condition 3
satisfied as a derivation rather than an intention**, and it is the sentence
this whole phase existed to be able to write.

**Three, the entry point builds the service.** `run_atlas_graph` constructs an
in-process company-data server with a per-process random secret when the caller
supplies none — the same choice it already makes for `store`, for invariant
58's reason. A registry with no database and no search index simply has no
remote path, refused by a narrow `except ValueError` (the only thing the
builder raises), so a bare configuration is a legitimate one rather than a
crash.

Measured, through `run_atlas_graph`:

```
DATA    stop=final  audit=[('query_company_data',  'priya', 'company_data:read', granted)]
RESRCH  stop=final  audit=[('search_company_docs', 'priya', 'documents:read',    granted)]
WRITE   (allow_writes=False) stop=escalated  audit=[]   file written: False
```

The third line is the one to look at twice. A write attempt without episode
authority produced **no audit records at all** — Atlas's own `execute()` refused
locally, before any token was minted or any socket touched. Cheapest refusal
first: never spend a credential, or a human's attention, on a call that cannot
succeed.

**The write path has two gates, and that is deliberate.** With
`allow_writes=True`, the run pauses twice:

```
GATE 1 kind: approval             <- Atlas's operator gate (Phase 10)
GATE 2 kind: mcp_input_required   <- the service's MRTR
stop: final | file written: True
```

Two gates wrapping one effect looks like a bug and is not, because they ask
**different questions**: Atlas's gate asks an operator whether *Atlas* may do
this, and the service's asks whether *this subject* may. Collapsing them means
the host answering on the service's behalf — which §7.4 forbids for a route
with no human, and which is arguably fine for one with a human who has just
approved this exact action. Assignment 1's stretch goal is to collapse them and
defend it; the consequence renderer already warns the operator that a second
question is coming, because an unexplained second prompt is how approval
fatigue starts.

**And fixing the wiring immediately found the next defect.** With the tools
actually dispatched, `execute()` caught the `GraphInterrupt` the service's MRTR
raised, graded it as `tool_error: GraphInterrupt: (Interrupt(...))`, and the
run **completed normally, reported `final`, wrote nothing and asked nobody**.
Invariant 70 one layer out. The fix is one narrow carve-out — invariant 19 now
has exactly one stated exception, because a suspension is not a tool *outcome*
— and the lesson is invariant 72's corollary: **an unwired mechanism does not
merely lack proof, it conceals the bugs in everything it touches.**

### 7.9 With an assistant

**Safe to delegate:** the base64/HMAC plumbing; the parametrised token-failure
tests; converting the second and third server tools once you have written the
first; the exception-group walk.

**Not safe to delegate:** the `HANDLER_TOOLS` grants — which route gets which
remote tool is the privilege-separation decision and an assistant will give
`research` the write tool because the request mentioned writing; the scope
table and `Scope` literal — a policy
decision, and an assistant will cheerfully invent `workspace:*`; what a refusal
message may reveal; and anything about which round of an MRTR flow has side
effects.

A prompt that works:

> In `atlas/mcp/client.py`, `_reraise_control_flow` walks a possibly-nested
> `ExceptionGroup` looking for control-flow exceptions by type name. Write
> pytest tests that build the nesting by hand — a bare exception, one level, two
> levels, and a group containing both a control-flow exception and an `OSError`
> — and assert which one escapes. Do not change the implementation.

## 8. [core] Debug this trace

### 8.1 The client that assumed the old handshake

```
[client] POST /mcp
         {"jsonrpc":"2.0","id":1,"method":"initialize",
          "params":{"protocolVersion":"2025-11-25",
                    "capabilities":{},"clientInfo":{"name":"atlas"}}}
[server] 200 {"jsonrpc":"2.0","id":1,
              "error":{"code":-32601,"message":"Method not found: initialize"}}
[client] WARN  initialize failed, continuing without session id
[client] POST /mcp   {"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
[server] 200 {"jsonrpc":"2.0","id":2,"result":{
              "tools":[{"name":"query_company_data", ...}],
              "resultType":"complete","ttlMs":0,"cacheScope":"private",
              "_meta":{"io.modelcontextprotocol/serverInfo":{"name":"atlas-company-data"}}}}
[client] POST /mcp
         {"jsonrpc":"2.0","id":3,"method":"tools/call",
          "params":{"name":"query_company_data","arguments":{"sql":"select 1"}}}
[server] 200 {"jsonrpc":"2.0","id":3,
              "error":{"code":-32022,"message":"Unsupported protocol version"}}
[client] ERROR tool call failed; falling back to local tools
```

**Diagnosis.** `initialize` returning *method not found* is the first and
largest clue, and the client's response to it is the actual bug: it logged a
warning and carried on. The handshake is gone, so a server without `initialize`
is not broken — it is current.

`tools/list` then **succeeded**, which is why this is confusing rather than
clean. Lists need no session, so a stateless server answers them from a client
that has established nothing. The client's own logs therefore show successful
discovery — the strongest possible evidence that the connection is fine. It is
not fine; it is *absent*, and absence is the normal condition.

`tools/call` fails, and the code is the answer: unsupported protocol version.
Not "no session", not "unauthorized". The client never sent `_meta`, so the
request carried no protocol version — and the version it *would* have
advertised, from the dead handshake, was the older one.

**The fix** is to delete the handshake and put the version on every request:

```python
"_meta": {
    "io.modelcontextprotocol/protocolVersion": "2026-07-28",
    "io.modelcontextprotocol/clientInfo": {"name": "atlas", "version": "0.1.0"},
    "io.modelcontextprotocol/clientCapabilities": {},
}
```

In practice a current SDK does this for you, so the real remedy is *stop
hand-rolling the transport*. Two follow-ups the review should demand: call
`server/discover` up front and select a version deliberately instead of
discovering the mismatch on the first tool call; and **delete the "continuing
without session id" warning**, because that line is the defect. A client that
treats a protocol-level "this method does not exist" as a degradation it can
proceed through produces exactly this trace, where discovery works, the first
real call fails, and the log blames the network.

> **The transferable lesson.** The partial success is what makes this expensive.
> Had statelessness broken *everything*, diagnosis would take a minute. It broke
> only the requests needing per-request metadata — which is the ones that do
> work — so the client's evidence pointed at the tool and the error pointed at
> the version, and those are two different systems to go and read.

### 8.2 The tool that ran with the wrong user's scope

```
[graph]  run_atlas_graph(request="note the Q3 limit in limits.md",
                         user_id="priya", force_route="tool_action")
[auth]   issue_token(subject="priya", scopes=("workspace:write",))     -> tok_a1
[mcp]    tools/call append_company_note  _meta{com.atlas/token: tok_a1}
[server] AUDIT  target=append_company_note subject=priya granted=True
[server] -> resultType=input_required  requestState=append:priya:limits.md
[graph]  interrupt(...)  -> suspended, thread=t-9
--- operator approves 40 seconds later ---
[graph]  resume(True) -> node re-driven from the top
[auth]   issue_token(subject="priya", scopes=("workspace:write",))     -> tok_a2
[mcp]    tools/call append_company_note  _meta{com.atlas/token: tok_a2}
         input_responses={"approve": accept}  request_state=append:priya:limits.md
[server] AUDIT  target=append_company_note subject=priya granted=True
[server] -> ok=True  "created limits.md"
[store]  put(("atlas","handoffs","default"), ...)          <-- ?
```

Everything about the *authorization* is right: two rounds, two independent
checks, correct subject both times, state bound to subject and path. The tool
did not run with the wrong user's scope.

The **audit trail** did. The last line files a record for `priya` under
`default`, because `run_atlas_graph` wrote `user_id` into `configurable` inside
the `if thread_id is not None:` block, so a caller passing a user and no thread
had their identity silently discarded and `persist` fell back to the default.
Reproduced:

```
stop: escalated
under priya:   []
under default: ['-']
```

One existing test passed `user_id` — and passed `thread_id` alongside it, so
nothing was placed to notice.

This is F-12-01, and it is invariant 58 **with the sign flipped**: not a
capability the caller must remember to switch on, but one they switched on and
the code dropped, on a condition unrelated to identity. The fix makes identity
unconditional and the thread the optional half, because that is the real
dependency structure — an audit record is a fact about a person, and a run
without a conversation still has one.

Note which way the bug pointed. It granted nobody access they should not have
had. It produced a **complete, well-formed audit trail attributing every user's
actions to one shared name**, which is worse than a missing trail, because a
missing trail is obviously missing. Compare invariant 66's corollary:
manufactured evidence of oversight is worse than an absent gate.

The regression test fails on the pre-fix tree and passes after — verified both
ways, because a regression test never seen to fail is a test of nothing.

## 9. [core] Common pitfalls & how professionals avoid them

**Treating a protocol-level "method not found" as a degradation.** §8.1's root
cause. A missing method is a fact about the protocol version; continuing past it
produces a failure three requests later in a different subsystem.

**Scraping a message for structured data across a process boundary.** Invariant
65's fifth appearance, most tempting at a protocol boundary because the far
side's error text is right there. Structured data travels as structured data;
the renderer runs where the human is.

**Conflating "declined" with "not yet asked".** The domain of an elicitation
action is three values, not two. A declined answer legitimately carries no
content, so a `content is None` test matches both and the flow re-asks a
question the human already refused. It failed *safely* — the write did not
happen — which is precisely why it would have survived to production.

**A wildcard scope.** `workspace:*` is MCP02 with a syntax: granted once for a
good reason, silently covering the write tool somebody adds next quarter. The
same trap one level up is a route grant: giving `research` a write tool widens
its derived scope automatically, which is why a test asserts the property
rather than trusting the derivation.

**Assuming round 1 of an MRTR flow is side-effect-free on a server you did not
write.** A convention, not a guarantee, and an interrupt makes the retry
unavoidable — three authorisations for one write, measured.

**Any design sentence containing "once, at connection time".** There is no
connection.

**An audit record that cannot name its subject.** F-12-02. Verifying and
scope-checking in one `except` is tidy and records an empty subject for both
failures — so a trail whose purpose is answering "who was refused what?" answers
it for no refusal at all.

**Not unwrapping exception groups in a sync-over-async bridge.** Invariant 70.
Control flow that arrives wrapped gets classified as an error. And one layer
out, the same mistake with a different classifier — a dispatcher that promises
never to raise:

```python
# excerpt: atlas/tools/registry.py
CONTROL_FLOW_EXCEPTIONS: frozenset[str] = frozenset(
    {"GraphInterrupt", "GraphBubbleUp", "ParentCommand"}
)
        if is_control_flow(exc):
```

**Marking a per-user list publicly cacheable.** A cross-tenant leak in one word,
and the failure mode is somebody "optimising".

**Trusting a remote `inputSchema` as your validator.** It is attacker-controlled;
using it as your validation means the server chooses your validation. Declare
the shape you will send.

## 10. [core] Industry perspective: coding agents, and how real teams do this

**[core] through "What this explains about your assistant"; the interview
questions are [extended].** Objectives 11 and 12 are core, so this section is:
a fast-track reader who skipped it would be unable to meet a stated objective,
which is the one thing the tagging rule forbids.

Coding agents are the flagship product category of this technology, and they are
built entirely from pieces you now own. Naming them makes your assistant's
behaviour predictable rather than mysterious.

**The architecture.** *Repo tools* — read, write, grep, glob, run a command —
which is Phase 3's registry with a jail and a workspace. *Tests as verifiers*,
which is the load-bearing piece. *Planning*, which is Phase 4. *Permissions*,
which is Phase 10's approval gate: a prompt before a write, a prompt before a
command, and a per-project allowlist so the second identical prompt does not
appear. *Sandboxing*, so a wrong command cannot leave the workspace.

**Why coding suits agents better than almost anything else: verifiability.**
Phase 3's eval harness exists because a natural-language answer has no automatic
grader — you need a rubric, a corpus and a human, and you get a noisy number.
Code has a free, deterministic, unambiguous grader that the agent can run itself,
as often as it likes: the test suite. That changes the economics of the loop.
An agent that can check its own work can afford to be wrong, because being wrong
costs a retry rather than a wrong answer delivered confidently. Phase 1's
per-step success arithmetic is the formal version — a verifier converts a p^n
compounding failure into something closer to a bounded search, because a failed
step is *detected* rather than propagated.

Which is exactly why coding agents feel more capable than they are. The model
is not better at code than at prose; the *loop* is better, because the loop has
an oracle. Take that as the design lesson: **when you want an agent to be
reliable at something, spend your effort building the verifier, not the prompt.**

**What transfers, and what does not.** Transfers: the verifier principle
(Atlas's result checks and abstention logic are attempts at one), the
permission model, the sandbox. Does not transfer: the assumption that a failed
attempt is cheap. `git checkout` undoes a bad edit; nothing undoes an email,
which is why Atlas's write path is gated and its research path read-only.

**What this explains about your assistant.** It asks before writing because the
gate is a policy decision the host owns and cannot delegate. It re-reads a file
you told it about two turns ago because context is compacted and a re-read is
cheaper than being wrong (Phase 8). It runs the tests unprompted because the
verifier is the loop's oracle. It withholds tool schemas until needed, because
four hundred schemas in a prompt is Phase 8's static-floor problem. And it
sometimes forgets a constraint you stated once — because a summariser is a
request, not a guarantee, which is invariant 55.

**Interview questions.** *[extended]*

1. When would you write an MCP server for an internal service, and when four
   direct integrations? What changes your answer?
2. Your agent acts on a user's behalf against three internal systems. Describe
   the credentials it holds and defend the number.
3. A protocol removes its session layer. Name three features that become
   unnecessary and one that becomes newly necessary.
4. How would you test an integration with a remote service without a network,
   and what would that testing *not* prove?

## 11. [core] Capstone increment

**If your code diverged, start again from `atlas_phase_11.zip`.**

**Resume note.** Phase 11 left Atlas honest about its capabilities and unchanged
in them. Phase 12 gives it a second way to be reached and a first way to act as
somebody in particular.

**What Atlas can do now** — and every clause below has a test that starts at
`run_atlas_graph`, because invariant 72 says a capstone sentence containing
"every" is a claim about the default path. Everything it could, plus: call its
company-data service over MCP from the `data` and `research` routes, and write
to it from `tool_action`, with the calling user's subject and a trace id on
every request; expose those tools over MCP on the current specification; ask a caller to confirm before a
write, via MRTR, suspended through Phase 10's interrupt and resumed by a human;
issue a per-user, per-audience, short-lived, scoped credential derived from the
route's tool set; refuse a call whose scope is exceeded, with the refusal
reaching escalation as `authority_missing`; consume a server it did not write;
serve one skill as `skill://` resources with the level boundary as the
authorization boundary; and carry W3C trace context on every hop.

**Files added.** `atlas/auth/scopes.py`, `atlas/auth/tokens.py`,
`atlas/mcp/{__init__,server,client,bridge,tools,demo}.py`,
`tests/test_mcp_phase12.py`, `tests/hidden/test_phase12_assignment{1,2}.py`,
`evals/tasks/phase12.json`, `scripts/phase12_results.py`.

**Files changed.** `atlas/auth/__init__.py` (exports),
`atlas/tools/registry.py` (`ErrorKind` widened; the control-flow carve-out),
`atlas/graph/escalate.py` (`AUTHORITY_ERROR_KINDS`), `atlas/graph/app.py`
(F-12-01, and the service wiring), `atlas/flow/app.py` (`HANDLER_TOOLS`),
`atlas/graph/approval.py` (a consequence renderer for the remote write),
`evals/run.py` (one entrypoint), `tests/test_evals_harness.py` (task count),
`Makefile` (`PHASE=12`), `requirements.txt`, `pyproject.toml`,
`docs/{RESULTS,FAILURE_LOG,DECISIONS}.md`, `ATLAS_INTERFACES.md`, `VERSIONS.md`.

**Tests added.** 70 in `tests/test_mcp_phase12.py`. Eleven of them are the
wiring audit made permanent — each capstone clause reached through
`run_atlas_graph` rather than through a hand-built server — and the rest cover: token round-trip
and `model_dump` equality; wrong audience; wrong key; expiry against an injected
clock; tampered payload; one frozen message with four distinct details;
`ValueError` for four bad issuance requests; least privilege per route; no
wildcards; every scope required by something; server refusing to start on an
absent local tool or unscoped exposed tool; discovery with cache hints; granted
and refused calls; subject on refusal; empty subject when unverifiable; refusal
reaching escalation; refusal not enumerating held scopes; trace id across the
hop, child spans, malformed input; MRTR complete, declined, no-confirmer, and
scope-before-question; per-round authorization; replayed state refused; the
interrupt suspending and surviving the exception group; six resume shapes; the
skill index open and bodies scoped; nested `{+path}`; traversal refused; a
non-Atlas server wrapped as text; an unreachable server as an observation; a
sampling request refused by name; F-12-01's regression; the `execute()` carve-out with both branches fired; a
declined confirmation through the graph; the two-gate write path; the
re-drive's third authorisation; and a service built by the entry point when
the caller supplies none.

**Interface changes.** `execute()` now re-raises exceptions in
`CONTROL_FLOW_EXCEPTIONS` — the one stated carve-out in invariant 19, since a
suspension is not a tool outcome (D-64). `ErrorKind` gains `"scope_refused"` — a change to a
published closed literal, with the migration note in `ATLAS_INTERFACES.md`.
`atlas/mcp/` is added to the repo layout with its import direction stated.
`run_atlas_graph` writes `user_id` unconditionally (no signature change).

**+3 eval tasks** (57 total): `p12-a` **the default path** — a `data` request
reaches the service over MCP through `run_atlas_graph` and completes, verified
failing 0/1 with the `HANDLER_TOOLS` grant removed; `p12-b` an exceeded scope refuses and
`files_created` is empty — the negative check is the load-bearing one, because
grading the label alone would pass a tree where enforcement moved after
dispatch; `p12-c` a declined confirmation is final, `write_refused` rather than
`scope_refused`, and one trace id across every round. Verified: `p12-c` fails on
the pre-fix decline logic (2/3) and passes after (3/3).

**`make results PHASE=12`** — expected ranges. Every row is [Tier F, measured]
because this phase's claims are about a protocol and a credential, both
deterministic; experiment 4 is `[Tier H recommended]` and spends nothing unless
asked. Notable values: 3 tools advertised; `cacheScope` private; 0 requests
needing a prior handshake; 5 of 7 authorization cases refused; 0 files written
by refused calls; 9/9 audit records carrying the client's trace id; **2
authorisations for ONE confirmed write** (one per round — the number that
surprises people); token verification ~11–13 µs; scopes per route as in §7.5;
level 1 vs level 2 skill cost 486 vs 2,259 characters.

**`docs/FAILURE_LOG.md` — read five failing traces.** F-12-01 identity
conditional on an unrelated parameter; F-12-02 a refusal record that could not
name its subject; F-12-03 a least-privilege function wired to an impossible
input, found by `make results` printing a value beside its label; F-12-04 two
grader bugs found by running the grader against a plausible submission. Plus
the two defects fixed during the build and recorded in code comments: the
declined-elicitation loop and the exception-group conversion of an interrupt
into a failure.

**Repo tag** `phase-12`. `make test-offline`: **1380 passed, 12 skipped**.
`make check-docs`: passes, with six marked blocks pinned in
`docs/DOC_BLOCKS.json` — the first draft had none, so nothing prevented 1,900
new lines of code drifting from the document that explains them.

## 12. [core] Mastery checklist

You are ready to move on if you can:

- State what protocol statelessness removed and what replaced each removed thing,
  without looking.
- Explain why `tools/list` succeeding is *not* evidence that a client is
  correctly configured.
- Implement an MRTR round from memory, and say what `requestState` must be bound
  to and why.
- Explain the confused deputy with a worked example and name the field that
  prevents it.
- Say what "the agent has the admin token" costs, and why nothing tells you.
- Derive a route's scope set from its tool set, and say what happens when
  somebody adds a tool.
- Explain why a scope refusal is a result and not an exception, and name the
  invariant.
- Say why a static resource handler cannot be scope-checked, and what that
  forced.
- Classify any construct from an older tutorial as works, deprecated or gone.
- Explain why coding suits agents, in one sentence about verifiers.
- Name, for any mechanism you have just built, the call site on the default
  path — or say honestly that there is not one yet.
- Explain why `execute()` must re-raise a suspension while grading every other
  exception, and what goes wrong if it does not.

## 13. [core] Quiz

1. Protocol statelessness removed the session. Name three features that existed
   only to manage it and one that became newly necessary because it was removed.
2. Why can list endpoints now carry cache hints when previously they could not?
   Your answer should name a property that changed, not a feature that was added.
3. A server needs to remember something between two tool calls. Describe the
   mechanism, and name two properties the value has that a session id did not.
4. MRTR and Phase 10's `interrupt()` solve the same shape of problem. Where does
   each keep the pause, and what security requirement follows from the
   difference?
5. Distinguish user identity from workload identity, and give one thing you can
   do with each that you cannot do with the other.
6. A refusal message says "you hold `documents:read` but need `workspace:write`".
   What is wrong with it, and what should it say?
7. Atlas's approval gate and the service's MRTR both wrap one write, so a run
   pauses twice. Argue that this is correct, then argue that it is a defect.
   Which argument would you act on, and what would you need to know first?

## 14. [core] Coding assignments

### Assignment 1 — a scoped calendar server **[fast track: do this one]**

Build `atlas/mcp/calendar_server.py` exposing two tools over MCP: `list_events`
(read) and `book_event` (write, confirming via MRTR before acting). Add
`calendar:read` and `calendar:write` to `Scope`, `SCOPES` and `TOOL_SCOPES`.
Define `CALENDAR_AUDIENCE`, distinct from the company-data audience, and
`CALENDAR_TOOLS` mapping each exposed tool to its scope. Accept `secret`,
optional `audit`, and an injectable `now`. Storage may be an in-memory dict.

**Acceptance criteria.** A token minted for the company-data audience is refused
here. A read scope does not authorise the write tool. The write tool asks
exactly once before acting, and a decline is final and books nothing. Scope is
checked before a human is asked. The server audits subject and trace id on
success and the subject on refusal. A refusal does not name the scopes the token
holds. An expired token is refused. No `os.environ` or `getenv` in the module.

**UNAIDED CORE.** The scope table, the audience constant, and the branch that
distinguishes accepted-and-approved from declined, cancelled, and
accepted-but-false. Write those three yourself, before any assistant touches the
file. They are the parts where an assistant's plausible answer is wrong in a way
tests do not always catch.

**Stretch goal, ungraded.** Collapse the double gate on the write path: when
Atlas's operator gate has already approved a specific call, answer the
service's confirmation from that decision instead of interrupting again. Then
write down why the *read* routes must still refuse rather than answering — and
what identifier the two gates would need to share for the collapse to be
sound rather than merely convenient.

`make grade PHASE=12` runs `tests/hidden/test_phase12_assignment1.py`. Do not
read it.

### Assignment 2 — an MCP migration audit **[extended]**

You inherit an internal MCP client written against an earlier revision. It opens
with `initialize`, stores and echoes a session id, registers via Dynamic Client
Registration, calls `logging/setLevel` at startup, uses Roots to tell servers
which directories it can see, uses Sampling so one server can summarise without
its own key, relies on `Last-Event-ID` to resume long streams, and holds one
long-lived service-account token for three backends.

Produce `docs/MCP_MIGRATION_AUDIT.md` (roughly 400–1200 words) and
`docs/mcp_migration_findings.json` with a `findings` list, each entry carrying
`construct`, `status` (`works` / `deprecated` / `removed`) and `remedy`.
Classify at least six constructs, use all three statuses, cite the specification
or a SEP, and state a checked-on date. The prose must establish statelessness,
the MRTR replacement for the back-channel, per-request identity, and at least two
named risks with named controls. Finish with a migration order and say what you
would do first.

**Acceptance criteria.** As above; the grader accepts several phrasings for each
required conclusion and asserts its own examples match.

**UNAIDED CORE.** The status column. Deciding what is deprecated-but-working
versus removed is the judgement this assignment exists for, and an assistant
will conflate them — the failure mode is a migration plan that treats a
twelve-month window as an emergency and an actual removal as optional.

`make grade PHASE=12` runs `tests/hidden/test_phase12_assignment2.py`.

## 15. [extended] Case study: integrating an agent with a legacy internal API

**The brief.** A 14-year-old internal service, "Ledger", exposes a SOAP-ish XML
API over HTTP with 200-odd operations, no OpenAPI description, a 40-page Word
document as its specification, and one shared API key. Two teams maintain it
part-time. Three assistants want access, including Atlas. Finance says a wrong
write is a regulatory incident. The Ledger team has no Python and no capacity.

**Your task.** A two-page recommendation: MCP server, direct tools, or
something else. Cover the operations you expose, where the credential lives and
what identity it carries, who writes and operates the server, how you test
without Ledger, and what you tell Finance about writes. Name what would change
your recommendation.

**Rubric (20 points).**

| | Criterion | Points |
|---|---|---|
| 1 | **Counts N and M** rather than asserting a protocol is better. Notices M=1 today and 3 hosts, so the saving is real but modest, and identifies the *other* reason a protocol wins here (the trust boundary, §6.1). | 4 |
| 2 | **Exposes a subset and says how it was chosen.** 200 operations is Phase 8's catalogue problem; a good answer names the ~10 the assistants need, or proposes search-and-execute, and refuses to expose writes in v1. | 3 |
| 3 | **Solves the shared-key problem honestly.** The server holds the Ledger key; the *clients* hold per-user scoped tokens; the server is therefore a deputy and the answer says so and says what stops it being confused (§6.7). An answer that gives Atlas the shared key scores 0 here. | 4 |
| 4 | **Assigns ownership realistically.** The Ledger team cannot maintain a Python server; a good answer proposes ownership by the platform team with a Ledger-team review of the operation list, and notes the cost: the server's authors do not understand Ledger, which is the N×M problem's *organisational* half reappearing. | 3 |
| 5 | **Testing without Ledger.** Recorded fixtures plus an in-process server, and states what that does not prove (invariant 48's habit). | 2 |
| 6 | **The write story for Finance.** Read-only v1; writes behind approval *and* a scoped credential *and* an audit record naming the subject; names which of the three is the enforcement and which are evidence. | 3 |
| 7 | **States what would change the recommendation.** E.g. if only one assistant ever needs it, direct tools win; if Ledger gains an OpenAPI description, generation beats hand-writing. | 1 |

An answer scoring above 15 without mentioning the shared key has misread the
question.

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 13.*

**A protocol converts an O(N·M) integration surface into O(N+M), but the
conditional matters more than the arithmetic**: the interface must be
expressive enough that a server is written once without knowing which host will
call it, and the current specification's evolution is largely a record of that
condition failing — which is why output schemas were loosened to arbitrary JSON
Schema. The reason to prefer a protocol even at N=M=1 is different and stronger: the
server's refusal does not depend on the client getting a flag right. And a protocol whose
client is a **language model** is a different object from one whose client is a
program — the description is part of the interface, the tool *list* is part of
the prompt, and that is why deterministic ordering and cache hints appear in a
transport spec.

**Statelessness is the change that makes older material misleading.** The
handshake and the session header are gone; version, client identity and
capabilities ride in `_meta` on every request; `server/discover` replaces the
handshake's discovery role; lists no longer vary per connection, which is what
made them cacheable. Four consequences: any instance serves any request, deploys
stop being outages, lists are shareable, and a broken stream loses only the
in-flight request. **It does not mean the server cannot remember** — cross-call
state became an explicit server-minted handle passed as an ordinary argument, so
an implicit lifetime became a visible value. Same lesson as invariant 61 from
the other direction: *implicit lifetime is where bugs live.*

**MRTR is the interrupt pattern at the protocol layer, and the difference is
where the pause lives.** The server returns `input_required` with
`inputRequests` and an opaque `requestState`; the client answers and re-issues
the same call. Atlas keeps its pause in a checkpointer it controls; MRTR keeps
it in a token held by a party the server does not trust — so it must be
integrity-protected and bound to a time window, the originating request, and the
principal. Choosing: MRTR when the current request needs an answer, Tasks when
work continues while the client is away, a handle when the state belongs in your
database. **`interrupt()` unwinds the stack, so the MRTR round is re-driven on
resume, not resumed** — safe only because round 1 has no side effect, which is a
requirement on the server, not a property of the protocol.

**Identity is two things and you need both.** Workload identity answers "which
program" and carries rate limits and revocation; user identity answers "on whose
behalf" and carries authorization and audit. The **confused deputy** is a
program with real authority that never asked whether *this requester* was
entitled to *this effect*, and the fix is that the deputy acts with the
requester's authority, not its own — not "read the file then filter", because by
then the model has read it. **"The agent has the admin token" is the most common
real failure because over-permissioning is the only security defect whose
symptom is that everything works.** Four properties are therefore asserted, not
intended: subject, scopes, expiry-by-ceiling, and audience — and audience is the
one people omit, which makes an unaudienced bearer token the confused-deputy
attack with no attacker required (invariant 69).

**Measured, and the number that surprises people: one confirmed write costs two
authorisations — three through the graph.** Statelessness means round 2 is a new
request, checked again; and because `interrupt()` unwinds the stack rather than
resuming it, round 1 runs a second time after the pause. Three authorisations
for one write, safe only because round 1 has no effect.
Least privilege is now computed rather than intended — `chat ()`, `document
documents:read`, `data company_data:read`, `research company_data:read +
documents:read`, `tool_action workspace:write` — which is **D-59's reversal
condition 3, satisfied**: the read routes and the write route hold different
credentials, derived from the registry scoping that already existed.

**Skills over MCP ride the Resources primitive, and the SDK put the
authorization boundary exactly on Phase 8's level boundary.** A static resource
handler cannot receive a request context, so it cannot be scope-checked; a URI
template can. The index is level 1, open; the bodies are levels 2–3, scoped.
Two independent lines of reasoning — token cost and an SDK's injection rules —
producing one partition. (`{+path}`, not `{path}`: plain `{path}` cannot match a
slash, and that level-3 hole passes every level-2 test.)

**Four defects, and three are about identity.** F-12-01: `user_id` was written
only when `thread_id` was given, so every user's actions were attributed to one
shared name — **invariant 58 with the sign flipped**, and note the direction, a
complete well-formed audit trail that is wrong is worse than a missing one.
F-12-02: verifying and scope-checking in one `except` recorded an empty subject
for both, so a trail whose purpose is "who was refused what" answered it for no
refusal at all. F-12-03: `granted_scopes` was keyed by remote tool names and
called only with local ones, so least privilege was computed for nothing while
the interface file called it policy — **found by `make results` printing a value
beside its label**, which is invariant 71. F-12-04: two grader bugs found by
running the grader against a plausible submission, which is invariant 68's
corollary nearly skipped for the second phase running.

**Invariant 70, and it cost a silent failure.** A `GraphInterrupt` raised inside
the SDK client's task group reaches a synchronous caller as
`ExceptionGroup(ExceptionGroup(GraphInterrupt))`. A type-name check on the outer
exception never matched, the interrupt became a `tool_error`, and the graph
completed normally reporting the remote system unavailable — **the pause silently
became a failure.** Any sync-over-async bridge unwraps exception groups before
classifying, because a task group turns your exception taxonomy into a tree.

**Coding agents are the flagship category, and the reason is verifiability.**
The model is not better at code than at prose; the *loop* is better, because the
loop has a free deterministic oracle it can run itself. A verifier converts p^n
compounding failure into a bounded search, because a failed step is detected
rather than propagated. Design lesson: **when you want an agent reliable at
something, build the verifier, not the prompt.** What does not transfer is the
assumption that a failed attempt is cheap — `git checkout` undoes a bad edit;
nothing undoes an email.

**Read the date on every architectural comparison**, including this one. A
widely-cited 2026 critique of a competing protocol rested on "MCP servers are
inherently stateful", which was true when written and false four months later.

**The lesson that cost the most, and it is not about protocols.** The first
draft of this phase built four modules, tested them to 53 green tests, and
wired them to nothing: `grep -rn "atlas.mcp" atlas/` returned nothing while the
capstone claimed "every tool call carries user identity and trace context".
Invariant 41's **seventh** appearance, in the phase that added invariant 71
about it. Hence **invariant 72**: a phase is finished not when its tests pass
but when each of its new public names has a call site on the default path,
named out loud — and a capstone sentence containing *every* is a claim about
the default path, so it needs a test that starts at the entry point. The
corollary is the part to carry forward: **an unwired mechanism does not merely
lack proof, it conceals the bugs in everything it touches.** Fixing the wiring
immediately exposed F-12-06 — `execute()` catching the graph's `GraphInterrupt`
under invariant 19 and grading it as a tool failure, so a run that should have
paused for a human instead completed, reported `final`, wrote nothing and said
nothing. Invariant 19 now has exactly one carve-out, because a suspension is
not an outcome.

**Atlas now.** `START → router → {chat | document | data | research |
tool_action} → critic → persist → respond → END`, and three of those routes now
reach a company-data service over MCP carrying the calling user's subject, a
route-derived scope and a trace id — `data` and `research` read-only, and
`tool_action` writing behind two gates that ask different questions. Plus one
skill served as `skill://` resources, a committed third-party server consumed,
and refusals reaching escalation as `authority_missing`. **1,380 offline tests,
57 gradeable eval tasks, all passing**, `make check-docs` green, no network, no
model.

**Phase 13 next.** Atlas becomes evaluable and observable at the level a team
would demand — and the trace ids planted this phase are the join key that makes
an end-to-end trace possible rather than a diagram.

## 17. [core] Further reading

All URLs and dates are also rows in `VERSIONS.md` with checked-on dates.

- **MCP specification, 2026-07-28 changelog** — the primary source for
  everything in §6.3–6.6. Read the Major changes list top to bottom once.
  `https://modelcontextprotocol.io/specification/2026-07-28/changelog` (28 July
  2026)
- **"The 2026-07-28 Specification"**, MCP blog, David Soria Parra and Den
  Delimarsky — the rationale, which the changelog omits.
  `https://blog.modelcontextprotocol.io/posts/2026-07-28/` (28 July 2026)
- **"The Future of MCP Transports"** and the release candidate post — how the
  stateless plan was laid out and locked.
  `https://blog.modelcontextprotocol.io/posts/2026-07-28-release-candidate/`
  (21 May 2026)
- **Feature lifecycle and deprecation policy** — the three states and the
  twelve-month window. `https://modelcontextprotocol.io/community/feature-lifecycle`
- **MCP Python SDK, "Multi-round-trip requests"** — the best short treatment of
  `requestState` bindings anywhere.
  `https://py.sdk.modelcontextprotocol.io/v2/handlers/multi-round-trip/`
- **Skills Over MCP working group charter and SEP-2640** — the convention, and a
  live example of a draft SEP. `https://modelcontextprotocol.io/community/working-groups/skills-over-mcp`
  and `https://github.com/modelcontextprotocol/modelcontextprotocol/pull/2640`
- **OWASP MCP Top 10** — beta; read the categories and ignore the rankings.
  `https://owasp.org/www-project-mcp-top-10/`
- **OWASP Top 10 for Agentic Applications** — ASI03 is §6.7's failure mode.
  `https://genai.owasp.org/2025/12/09/owasp-top-10-for-agentic-applications-the-benchmark-for-agentic-security-in-the-age-of-autonomous-ai/`
  (9 December 2025)
- **RFC 9207**, OAuth 2.0 Authorization Server Issuer Identification — the
  issuer-validation requirement, in its own words.
  `https://datatracker.ietf.org/doc/html/rfc9207`
- **W3C Trace Context** — `traceparent` and `tracestate`, which Phase 15 builds
  on. `https://www.w3.org/TR/trace-context/`
- **Hou, Zhao, Wang & Wang, "Model Context Protocol (MCP): Landscape, Security
  Threats, and Future Research Directions"**, arXiv:2503.23278 — the first
  systematic academic study: a four-phase server lifecycle decomposed into 16
  activities, and a threat taxonomy across four attacker types (malicious
  developers, external attackers, malicious users, and the fourth). The
  tool-description manipulation section is worth it alone. Note the version: v1
  30 March 2025, v3 last revised 7 October 2025, so it predates the stateless
  revision — read it for the threat model, not the architecture.
  `https://arxiv.org/abs/2503.23278`
- **A2A protocol** — read the spec's task state machine, then the one-year
  announcement, then a sceptical analysis, in that order and with the dates in
  view. `https://a2a-protocol.org`

## 18. [core] Solutions

Worked answers to the cumulative review, the concept checks, the "Your turn"
exercises, the quiz, both assignments and the case study are in
**`phase_12_solutions.md`**. Attempt each one and write your answer down first.

## 19. [core] HANDOFF

**Confirmed inside `atlas_phase_12.zip`:** the updated `ATLAS_INTERFACES.md`
(v0.25, invariants 69–71, D-61 and D-62, and the "Interface changes — Phase 12"
subsection) and the updated `VERSIONS.md` (the Phase 12 delta, checked
2026-09-10). The repository is committed and tagged `phase-12`.

**Verification at the point of shipping.**

```
make test-offline        1380 passed, 12 skipped
python evals/run.py      57/57 gradeable tasks, pass^k 100%
make check-docs          passes; 6 marked blocks pinned for this document
make grade PHASE=12      2 skipped (both assignments unstarted, as intended)
make results PHASE=12    27 rows, all Tier F, 0 model calls, $0.00
ruff --select F401,ARG   clean on atlas/mcp and atlas/auth
```

Negative checks, both directions: `p12-a` fails 0/1 with the `HANDLER_TOOLS`
grant removed; `p12-c` fails on the pre-fix decline logic; F-12-01's regression
test fails on the pre-fix tree. A test never seen to fail is a test of nothing.

**Files changed in the zip this phase.** Enumerated in §11 (added and
changed, separately) and not repeated here.

**VERSIONS.md delta rows added this phase** (abridged to the rows a reader must
re-verify first; the full delta is in the file, every row with a source URL and
a checked-on date):

```
| fact | value | source URL | checked-on |
|---|---|---|---|
| Current MCP specification revision | 2026-07-28, final, published 28 July 2026 | https://modelcontextprotocol.io/specification/2026-07-28/changelog | 2026-09-10 |
| MCP Python SDK | 2.2.0 — used in code; FastMCP renamed to MCPServer | https://pypi.org/pypi/mcp/json | 2026-09-10 |
| MCP SDK phase assignment | CORRECTED: was "Phase 15" at 2.1.1; MCP arrives in Phase 12 | this repo | 2026-09-10 |
| Statelessness SEP | SEP-2575 (handshake, session id, ping, logging/setLevel, SSE resumability removed; server/discover, subscriptions/listen added) | .../changelog | 2026-09-10 |
| MRTR SEP | SEP-2322 — InputRequiredResult, resultType, inputRequests, inputResponses, requestState | .../changelog | 2026-09-10 |
| Deprecations SEP | SEP-2577 — Roots, Sampling, Logging | .../changelog | 2026-09-10 |
| Deprecation policy | SEP-2596 — Active/Deprecated/Removed, minimum 12-month window | https://modelcontextprotocol.io/community/feature-lifecycle | 2026-09-10 |
| Skills over MCP | SEP-2640 is a DRAFT; skill:// convention adopted, NO draft method called | https://github.com/modelcontextprotocol/modelcontextprotocol/pull/2640 | 2026-09-10 |
| langchain MCP adapter | CORRECTED since 2 Sept: langchain 1.4.0 final shipped 3 Sept 2026 containing langchain.mcp, but the NAMESPACE is beta -> not in Atlas's code | https://github.com/langchain-ai/langchain/releases/tag/langchain%3D%3D1.4.0 | 2026-09-10 |
| Authorisations per confirmed MRTR write | 2 — one per round | measured, scripts/phase12_results.py exp. 2 | 2026-09-10 |
| GraphInterrupt nesting through the SDK client | 2 levels of ExceptionGroup | measured, this phase; invariant 70 | 2026-09-10 |
| Offline test count | 1366 passed, 12 skipped | make test-offline | 2026-09-10 |
| Gradeable eval tasks | 57 | python evals/run.py --trials 1 | 2026-09-10 |
| ATLAS_INTERFACES.md version | v0.25, invariants 69-71, D-61 and D-62 | repo | 2026-09-10 |
```

Eight further rows are in `VERSIONS.md` and not reprinted here: SEP-2567
(handles), SEP-2243 (headers), SEP-2549 (cache hints), SEP-414 (trace context),
the DCR deprecation, the OWASP list's status, A2A's v1.0, and the per-route
scope table.

**Pre-release APIs used in code: none.** SEP-2640 is a draft and Atlas calls
none of its methods; `langchain.mcp` is a beta namespace and is not imported;
the SDK version pinned is a final release of a final specification revision.

**Three corrections to the phase brief, all re-verified.** The header's
budget: the block said ~1,400 Tier A calls and ~25 minutes of compute, and the
measured figures are **0 and about two minutes**, because every claim this
phase makes is about a protocol and a credential rather than about a model.
`make plan PHASE=12` prints it, and a header contradicting a Makefile target in
the same repository is the drift `make check-docs` exists to prevent. The brief stated the
first-party LangChain MCP adapter was an alpha as of 1 September 2026; the 1.4.0
line shipped **final on 3 September 2026** and contains the `langchain.mcp`
namespace, though the namespace itself is documented as beta — so the outcome is
unchanged (a VERSIONS.md row and a forward pointer, no code) but the reason is
different, and Atlas already pinned that langchain version. The brief also
attributed statelessness and MRTR loosely; the SEP numbers above come from the
specification's own changelog. Both are why the currency rule exists.

**Downloads.**

1. `atlas_phase_12.zip` — the complete updated repository, tagged `phase-12`.
2. `phase_12_interoperability_mcp_and_identity.md` — this document.
3. `phase_12_solutions.md` — full worked answers.
