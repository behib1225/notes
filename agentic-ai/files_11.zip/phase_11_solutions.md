# phase_11_solutions.md

Worked answers for Phase 11 — Multi-Agent Systems. Read these after attempting the questions, not instead.

---

## Cumulative review (section 2)

**1. Why "preserve all constraints" does not work, and why the schema has no compliance field.**

A prompt instruction is a request; a summariser that drops a constraint is not violating a type, it is producing plausible prose. Phase 8 measured the gap: 0 of 6 constraints survived a scripted lossy summary, 6 of 6 survived once they were extracted before summarisation and concatenated after it by code. The mechanism that works is the one the summariser cannot reach.

The schema has no field reporting that constraints were kept, because **a field reporting compliance is a field that can report compliance falsely**. If the summariser emits `kept_constraints: true` and drops one, you now have a wrong answer plus an audit record saying it is right, which is worse than the wrong answer alone. This is D-44 and invariant 55; the same reasoning removes `sufficient`, `grounded` and `confidence` from every model-facing schema (invariant 44), and the same reasoning is why Phase 10's approval decision is additive rather than an edit in place.

**2. What a context budget does not answer.**

A budget answers *enforcement*: does the assembled prompt fit. It says nothing about *adequacy*: are the right things in it. Phase 8 added two mechanisms for the second question — the **composition log**, which records which blocks were included and which were dropped, and the **recall probe**, which asks whether a fact known to be in the corpus is reachable from the assembled context. Invariant 56, plus the corollary that cost Phase 8 an entry: reporting a drop is not the same as the drop being survivable. An honest `DROPPED: tool_schemas` line handed a ReAct loop a prompt with no action space, so blocks are now classified by whether their absence degrades the answer or breaks the mechanism, and the second kind is marked required.

**3. `3 * max_steps + 2`.**

Three supersteps per step because one agent step is `model → decide → tools`: the model node produces a turn, the routing function decides whether to continue, and the tool node executes. The `+ 2` pays for the entry superstep and the terminal one — reaching the first model node, and the final transition to `END` after the last model turn produces an answer rather than a tool call. Phase 10 pinned this by measurement and added `GATED_SUPERSTEPS_PER_STEP = 4` for the gated arm, where `gate` is a fourth superstep per step. The general fact it rests on: `recursion_limit` is inherited by subgraphs rather than divided, and the minimum is `max(level_supersteps) + 1`, never the sum.

**4. F-09-01's rule and the graded artefact.**

The rule is invariant 62: **a guard that fires correctly and is read by nothing is indistinguishable from an absent guard.** F-09-01's routing function ignored a correctly-set `stop_reason`, and no test of any node could fail, because every node was right — the wiring was wrong, and wiring is not a node.

The artefact is the **topology diagram**. The graph's only serialisation is `draw_mermaid()`, so `END`-reachability is now asserted against that string and exported by `make graph`. Phase 10 then found the oracle's own limit: `Command(goto=...)` without `destinations=` prints `a --> __end__` for a node that jumps to `b`, so invariant 62's oracle can be turned against invariant 62 — hence "a conditional edge wherever one suffices".

**5. The `stream` hole.**

In the trace, a streamed call looks exactly like a completed call: same request, same response, same tokens, indistinguishable. In the budget it looks like nothing at all — `calls` and `tokens` never increment, because `BudgetedClient.__getattr__` did not forward `stream`, so the call went straight to the inner client. So every streamed call was an unmetered side channel: a `CallBudget` with `max_calls=50` would allow unbounded streamed spend while reporting 0/50. Invariant 64: a wrapper forwards every method of the thing it wraps, or it is a hole; when a capability is optional the wrapper forwards it conditionally and says so.

---

## Concept checks

**6.1 — Is `critic` a second agent?**

**No.** The deciding criterion from 6.1 is not "does it make its own model call with its own prompt" — that is true of `critic` and of every stage in a chain. The criterion is: **can two loops each take actions the other cannot observe?**

`critic` makes exactly one call, has no tool set, runs no loop, and its entire effect on the world is the findings it returns into one shared state. It cannot act. Under 6.1's deflation it is closer to an expensive validator than to a colleague — and Cognition's revised position says this is exactly the shape of multi-agent that works, which is why the honest description of Atlas is "one agent with a verifier" rather than "a two-agent system".

Two things sharpen the answer. First, `critic`'s verdict is a pure function of its findings and a model may add a finding but never clear one (invariant 29), so its authority is bounded by code rather than by its prompt — a colleague's authority is not. Second, if you gave `critic` a tool set, the answer would change, and that is the useful test to remember: **the moment a component can act, it becomes an agent whose actions somebody has to be able to observe.**

**6.4 — The one question about the `data` route.**

Ask: **does a single context comfortably hold everything a `data` answer needs?**

The crossover condition is that multi-agent structure helps when the single agent's effective use of its context degrades — when it becomes hard to separate relevant from misleading material, not merely when there is a lot of it. The `data` route has two tools, a measured static floor of 857 estimated tokens, and answers built from a read-only SQL result set. Nothing about that is a degraded-context problem, so the 90.2% figure — measured against a single agent drowning in hundreds of search results across many independent directions — does not transfer.

What would change my mind: if the route's schema grew to the point where the *relation-selection* step routinely picked the wrong table because the schema description no longer fit usefully in one prompt. That is genuine context confusion and it is measurable — Phase 7's `relations_read` field plus the result checks already record which relation each answer used, so you can count wrong-relation answers directly. Note the alternative fix that would come first: retrieval over the schema, which is one agent with a better tool.

**6.6 — Load-bearing versus decoration.**

The **tool set plus the output schema is load-bearing**; the role prompt is decoration.

The prompt asks the model not to estimate. The tool set removes every way to obtain a number other than `query_db`, and the schema makes a numeric field un-emittable without a `source_relation` — so a fabricated figure is not discouraged, it is *unrepresentable in the output type*. That is invariant 44's shape: abstention and grounding are computed by code from the retrieval, never granted by the model, and no model-facing schema carries a field the model could fill falsely. The Phase 7 invariant to connect it to is **52**: a boundary that cannot be crossed does not make an answer correct, and security checks and correctness checks are different mechanisms. So the honest full answer has three layers, not two — the schema makes fabrication unrepresentable, the tool set makes it unobtainable, and a result check still has to confirm the relation answered the question that was asked.

The role prompt is not *harmful*; it is just unmeasurable, and 6.6's five-minute experiment settles it: delete the persona line and see whether anything changes.

**6.9 — Documentation versus running code.**

Answerable from documentation, usually: 1 (termination), 3 (bad batch, if the docs are honest about it), 4 (tool exceptions), 5 (approval semantics, partially).

Requires running code: **2** (the durability default — Phase 10 measured that `async` loses the completed superstep *and* reports `next=()`, which no changelog states), **6** (the concurrency bound, because `min(32, cpu_count + 4)` is a property of the host and not of the library), **7** (whether the serialised topology tells the truth), and **8** (what a search API does with no index). Note that 5 also belongs here in practice: the docs describe the four decision kinds, and only a measurement shows that an edit destroys the original proposal.

**Smallest experiment for question 2.** Build a two-node graph where node A returns a state update and node B calls `os._exit(9)`. Run it under a real checkpointer with the default durability, then resume the same thread and print `StateSnapshot.next` and the channel A wrote. Two things to check, not one: whether A's write survived, and whether the resumed snapshot correctly reports that work remains. The second is the dangerous one — a thread that reports `next=()` after losing a superstep is indistinguishable from a finished run, so a retry loop will not retry it.

---

## Quiz

**1. What settles whether a system is multi-agent.**

Ask: **can any two of those four prompts take actions the other cannot observe?** Running four prompts is a fact about your bill, not about your architecture. If every prompt's entire effect on the world is the string it returns to a single coordinating loop, you have one agent with four expensive tools — a good design, and one with no coordination protocol to get wrong.

It is the right question because it is the question that predicts which *costs* you pay. Coordination overhead, error propagation across boundaries, conflict between implicit decisions, distributed traces, and inter-agent trust are all consequences of unobserved action, not of prompt count. A system with four prompts and one writer has none of them.

**2. Follows and does not follow from "token usage explained 80% of the variance".**

**Follows:** if your architecture's benefit is that it lets you spend more tokens on a problem than one context window holds, then it will help exactly where the token ceiling is the binding constraint — and you should compare it against a single agent *given the same token budget* before crediting the architecture. It also follows that upgrading the model may dominate the architecture change, which the same source reports.

**Does not follow:** that spending more tokens causes better answers, or that any architecture which burns 15× will get research-system results. The finding is that variance in performance tracked variance in tokens across systems that were all trying to answer the question; it is not a licence to spend. Section 8's trace burned 12 calls and returned nothing. Tokens are the resource the architecture buys access to, not the mechanism that produces the answer.

**3. Where the DPI guarantee stops applying.**

The guarantee is about the *ideal* estimator over the full context `C`. It says no function of messages derived from `C` can carry more information about the answer than `C` itself. Real models are not ideal estimators over `C`; they operate on an effective context that degrades under length, noise, distractors and corruption. Formally, the inequality compares `Pe(C)` with `Pe(M)`, but the single agent you can actually build achieves `Pe(C̃α)` for some degradation level α — and nothing in the argument guarantees `Pe(C̃α) ≤ Pe(M)`.

So the guarantee stops applying exactly when a well-structured decomposition recovers task-relevant information more reliably than one degraded pass. The measured version: under token substitution at α=0.7 the sequential pipeline reached 0.225 against the single agent's 0.200, while under mild degradation and under distractor injection the single agent stayed ahead. Corruption, not length, is the trigger — which is why "our context is getting long" is not a reason to go multi-agent and "our context is getting confusing" might be.

**4. Why a free join makes one linear and the other quadratic.**

Two separate facts compose. The **call count**: the pipeline plans once and joins in code, so `calls = 1 + n`, while a supervisor decides before each step and synthesises after, so `calls = 2n + 1`. That alone is a constant factor of about two, not a change of order.

The order change comes from the **context per call**. Each pipeline worker sees instructions, its scoped tool schemas and one step — a quantity independent of `n`. So total tokens is `n × O(1) = O(n)`. The supervisor's turn `t` must see the `t` reports that came back before it, because that is what it re-decides on; summed over turns that is `O(n²)`. The free join is what makes this possible: because `aggregate` is Python, no stage in the pipeline ever needs to read all `n` results through a model. **A supervisor is quadratic because re-deciding requires reading the history, and reading the history is what a code join does for free.**

**5. The distinction that makes both Cognition findings consistent.**

Share context between **collaborators**; withhold it from **verifiers**.

Principle 1 exists to stop two agents making conflicting implicit decisions about the same artefact — they need the same priors because they are both building. A reviewer is not building. Its job is to reach an independent verdict, and shared context imports the exact assumptions it is supposed to test: without the spec it must reason backward from the implementation and can question things the author took as given. There is a mechanical half too — a clean context is a short context, and models decide better on short ones, so the reviewer that skips hours of accumulated exploration is simply sharper on the diff.

The generalisation worth keeping: **ask whether the second agent's value comes from agreement or from independence.** Share context for the first, withhold it for the second. And note the third requirement their post names: the *bridge* back matters, because a reviewer with no shared context will report findings that are out of scope, and something with the full context has to filter them.

**6. What `[151, 376, 310, 376, 310, 376]` tells you.**

**Concludable, without reading a message:** the supervisor's input is periodic with period 2 from turn 2 onward. Its context is therefore not accumulating — it is a function of a bounded window, almost certainly the last worker report — so it has no record of its own prior delegations. A deterministic policy over a period-2 input produces a period-2 output, so this loop cannot terminate by the supervisor's own decision at any temperature, and only the turn cap will stop it. That is a coordination bug, diagnosable from six integers.

**Not concludable:** *why*, and therefore what to fix. The sizes cannot tell you whether the workers are returning useful results, whether the roster can cover the task at all, or whether the decomposition made sense. Section 8's trace has all three problems and only the first is visible here. In particular the sizes are consistent both with a memory bug alone and with the infeasible-allocation root cause, and those have different fixes — one detects, the other prevents. The prompt-size sequence is a smoke alarm: reliable about *that something is wrong*, silent about the fire.

---

## Assignment 1 — `docs/A1_SUPERVISOR_DESIGN.md`

A model answer in outline. Yours should differ; what should not differ is the presence of each element.

**The design.** `proposer` holds `read_file`, `list_files`, `current_time` and proposes writes as structured data. `executor` holds `write_file` and nothing else. Handoff is one-way: `proposer → executor`, never back.

**The trap, addressed.** This split already exists in Atlas, with a **human** as the executor: the approval gate is a proposer whose writes are performed only after a different party clears them. So the honest framing is not "should we add an executor" but "should we replace the human executor with a model one, or insert a model one before the human". A model executor adds throughput and removes the thing the gate exists for. Phase 10's finding applies directly and is the strongest single argument in this assignment: a gate whose approver is fluent and always agrees manufactures evidence of oversight that did not occur. If the model executor auto-approves, the write path has lost its gate while keeping its paperwork.

The defensible version is therefore **executor as a second check, not as a replacement**: it verifies what it can verify mechanically and escalates everything else, with the human gate still last. Which prompts the interesting question the hints point at.

**What the executor can verify about a proposal it did not produce.** Mechanically: that the path is inside the jail; that the proposal names an existing target for an overwrite; that the content is well-formed for its extension; that the diff against current content is non-empty; that the proposal's stated target matches the tool arguments. Not mechanically: whether the content is *correct*, or whether the user wanted this write. A clean-context executor can catch a class of error the proposer cannot see — the analogue of Cognition's review loop — and cannot catch intent errors at all. So the boundary table's cost column writes itself: what does not cross is the proposer's reasoning, and the cost is that the executor can check form and not purpose.

**Boundaries.** At least: request → proposer; proposer → executor; executor → human gate; executor → answer. The `proposer → executor` row is the one to get right — what crosses is a structured proposal, what does not is the transcript that produced it, and the cost is that the executor cannot tell a deliberate overwrite from a mistaken one.

**Termination.** The proposer keeps the existing `max_steps` cap. The executor gets no loop at all: one verification pass per proposal, so its termination is structural rather than bounded. Say this explicitly, and say how a violation fails loudly — if the executor could hand back to the proposer, you would need a closed stop-reason set and a `no_progress` guard, which is a reason not to allow it.

**Cost.** `proposer` calls are unchanged; the executor adds one call per proposed write, plus the proposal payload in its prompt. For a `tool_action` episode with `w` proposed writes, `calls = existing + w` — linear in the writes, and note that this is a *relation*, which is what rubric item 4 asks for. Any of the three phrasings works: the algebra, the per-unit rate, or the growth class. Measured floor for the route: 1,011 estimated tokens (`docs/RESULTS.md` Phase 8 experiment 1), of which 505 is four tool schemas — so a two-tool executor's floor is roughly `506 + 2×147 = 800`. Label each figure.

**Decision and reversal.** A defensible decision either way. Reversal conditions must name thresholds: for example, "if more than 15% of writes cleared by the human gate are later reverted, a mechanical pre-check is buying something" or "if median approvals per session exceeds 5, approval fatigue is the binding risk and a pre-filter that refuses obviously-bad proposals reduces the human's load". Both are countable from the audit trail Phase 10 writes to the store.

**Common failure in this assignment.** Writing a cost column that restates the omission ("the executor does not see the transcript, so it does not have the transcript"). The column must name a wrong answer a user receives.

---

## Assignment 2 — `docs/A2_FRAMEWORK_REVIEW.md`

No single correct answer; the framework is yours to pick. What a strong submission looks like:

- **Version and date on every current-state claim.** A framework review without a version reviews whatever was on the index the day you read it.
- **Sourcing per answer, not per document.** "Docs say X; the source at `foo/bar.py:118` does Y; I ran Z and observed W" is the shape. Where documentation and source disagree, that disagreement *is* a finding and belongs in the review.
- **At least one defensible-but-wrong-for-Atlas default, both positions stated fairly.** If you cannot find one, you probably read the tutorial rather than the framework. Every framework serving many applications must pick a general policy, and a general policy is rarely any specific application's. Phase 10 found four in one component: a batch with an unknown name partially executed, a tool exception re-raised, no typed refusal, no output cap.
- **What you would wrap, and what the wrapper costs.** This is the half of invariant 59 that changes code. "I would wrap the tool node to validate the batch as a unit" is an answer; note that a wrapper you must remember to install is off in production (invariant 58), so say where it is installed.
- **A verdict with a blocking condition.** "I would adopt it for X but not until Y" beats a score out of ten.

The three unaided questions and why they are the unaided ones: documentation reliably misstates the durability default's *failure* behaviour, reliably omits what an approval edit does to the record of what was proposed, and describes termination in terms of what the model is instructed to do rather than what the harness enforces. All three took a measurement in Phase 10 and none of them appear in a changelog.

**Scoring note.** A submission can be green on `make grade PHASE=11` and still score 4/10. The structural checks confirm you addressed eight questions and pointed at real symbols; the rubric in section 14 of the phase document is where the judgement lives, and item 3 scoring zero is the usual outcome of reading about a framework instead of into it. Record your total as a `Self-score:` line — the hidden test checks the line exists, not what it says, because a grader that scored your self-assessment would just be another thing to write for.

---

## Case study

None this phase. Section 7 is the design exercise; section 11's `docs/MULTI_AGENT_DECISION.md` is the artefact and its rubric is the two hidden-test checklists.
