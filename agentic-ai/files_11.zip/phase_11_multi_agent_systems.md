# Phase 11 — Multi-Agent Systems: Architectures, Coordination, and When They Actually Help

## 1. [core] Phase 11 | Study hours 3 read / 0 build / 1 assess | Compute time 0 min | Tier A calls per sweep 0 | Tier H calls 0 | Cost $0.00 | Repo tag `phase-11`

*Length note: this document runs about 12,900 words against a planned 8–10,000. The overrun is deliberate and itemised, because a reader on a fixed schedule deserves to know what to skip. The `[extended]` tags mark 6.5's last two architectures, section 10 and Assignment 2 — about 1,400 words the fast track can skip outright. Roughly 700 more words are the information-theory orientation in 6.4 and the provenance and baseline caveats in 7.3 and 8, all added after an audit found the document was under-specified without them. Given a choice between a word count and a self-study reader who can check my arithmetic, the count loses; the honest move is to say so rather than to trim the caveats and look disciplined.*

*Hours note: the 1 assessment hour covers the quiz, the mastery checklist and Assignment 1. Assignment 2 is `[extended]` and needs 3–4 hours on its own, because three of its eight questions can only be answered by running experiments. The fast track skips it.*

This is the only phase in the book with a build budget of zero. You will write one document, `docs/MULTI_AGENT_DECISION.md`, and three eval tasks that grade the claims it rests on. No new module enters `atlas/`.

That is a deliberate design decision about the book, and it is the phase's first lesson. Atlas already has an orchestrator-workers research pipeline (Phase 5), fanned out over real concurrent branches (Phase 10). The obvious next move is to promote it to a supervisor with named specialist agents that hand off to each other. This phase is where you work out, on paper and with arithmetic, what that would cost and what it would buy — and then decide not to do it. The supervisor and handoff implementations live in Appendix F.5, on a branch off `phase-11`, for readers who want them. The core track skips them because the core track's job is to finish a working assistant in four months, and this particular upgrade does not pay for itself at Atlas's scale.

Deciding not to build something, in writing, with a number attached and a stated condition under which you would change your mind, is a senior engineering skill. It is also the hardest thing to practise alone, because there is no one to argue with. Sections 7 and 11 are that practice.

## 2. [core] Cumulative review

From Phases 8 and 9. Answers in `phase_11_solutions.md`.

1. Phase 8 measured that 0 of 6 constraints survived a scripted lossy summary, and 6 of 6 survived once they were pinned. Why does adding "preserve all constraints" to the summariser's prompt not fix this, and why does the summariser's output schema have no field reporting that it kept them?
2. A context budget guarantees the assembled prompt fits. Name the question it does not answer, and name the two mechanisms Phase 8 added to answer that second question.
3. Phase 9's `recursion_limit_for(max_steps)` returns `3 * max_steps + 2`. Where do the three supersteps per step come from, and what does the `+ 2` pay for?
4. F-09-01 was a guard that fired correctly and changed nothing. State the general rule Phase 9 extracted from it, and name the artefact that is now graded against `draw_mermaid()`.
5. `BudgetedClient` forwarded `complete` and not `stream`. Describe the resulting hole precisely: what would a streamed call have looked like in the trace, and what would it have looked like in the budget?

## 3. [core] Why this phase matters

Every framework you will touch ships a multi-agent story on its front page, and the story is a good one: give each agent a role, a narrow tool set and its own context window, wire them to a supervisor, and the system decomposes into parts you can reason about one at a time. It reads like the microservices argument, and the microservices argument was largely right.

The trouble is that the evidence, once people measured instead of demoing, splits down the middle. One team reports a multi-agent research system beating its own single-agent version by 90.2%. Another, at a company whose product is an autonomous coding agent, publishes *Don't Build Multi-Agents* — then, ten months later, a follow-up saying a narrow class does work, but only that class. A Berkeley-led group collects sixteen hundred traces from seven frameworks and finds the gains on public benchmarks often small enough to need explaining. A Stanford pair holds the reasoning-token budget constant and finds single agents match or beat every multi-agent architecture they test, with an information-theoretic argument for why.

All four are true at once, and the reason they are compatible is this phase's content: they measure different things under different constraints, and once you know which constraint you are under, the choice stops being a matter of taste.

You need this before Phase 12, which gives Atlas scoped credentials — because with a second agent the credential question becomes "which one holds it, and who may ask it to act". You need it before Phase 14, because a multi-agent system has its own OWASP entries. And you need it now, because the honest answer for Atlas is "one agent with better tools", and a negative decision has to be made *before* you have sunk three weeks into the positive one.

## 4. [core] Learning objectives

By the end of this phase you will be able to:

1. Define a multi-agent system precisely enough to say which of Atlas's existing components are and are not agents, and explain why a read-only subagent is closer to a tool call than to a colleague.
2. Name the four benefits that multi-agent architectures actually deliver (context isolation, specialisation, parallelism, privilege separation) and, for each, state the cheaper single-agent mechanism that delivers most of it.
3. Summarise the published evidence on both sides — including at least one paper measuring under matched compute — and say which measurement conditions produce which result.
4. Draw and distinguish seven architectures (supervisor, hierarchical, network, handoff/swarm, pipeline, debate, blackboard) and pick the simplest one that meets a stated requirement.
5. Annotate a message boundary with what crosses it, what does not, and what that omission costs.
6. Estimate the token cost of a proposed architecture from measured per-route floors, and show how the estimate scales in the number of steps.
7. Read a multi-agent trace, classify its failure using a published taxonomy, and distinguish the symptom from the root cause.
8. Separate the concepts that are universal across agent frameworks from the vocabulary of one framework, and apply a written rubric to a framework you have never used.
9. Write a design decision that a colleague could disagree with productively: the design, the cost, the decision, and the conditions that would reverse it.

## 5. [core] Prerequisites & quick recap

You need Phases 5, 9 and 10. Nothing new is installed; the pinned `langgraph==1.2.11` and `langchain==1.4.0` from Phase 9 are all this phase refers to, and it refers to them only in prose.

Three things from earlier phases carry the whole argument, so pin them now.

**Phase 5 gave Atlas an orchestrator-workers pipeline.** `run_research_pipeline` plans, fans work out to workers with per-step scoped registries, and joins. The scoping matters: `scoped_registry(registry, names)` means a worker's action space is a parameter, which is invariant 20 applied one level down from the episode.

**Phase 10 made the fan-out real.** `build_research_subgraph` is `plan → Send fan-out → aggregate`. Read the shape carefully, because section 7 compares against it: `plan` is one model call, each `worker` branch is one model call, and **`aggregate` is not a model call at all**. It is nine lines of Python that sort findings by index, join the successful ones and set a `partial` flag. The join is free.

**Phase 10 also fixed the per-route action space.** `HANDLER_TOOLS` gives `chat` no tools, `data` two, `research` six. A route's tool set is the security model for that route.

So Atlas today is `START → router → {chat | document | data | research | tool_action} → critic → persist → respond → END`, with an approval gate before every write, bounded fan-out on the default path, and crash-safe checkpointing. One model, one system prompt per route, one transcript.

If you are shaky on where "agent" stops and "workflow" starts, that boundary is the first thing section 6 nails down, and it is the reason this phase can be short.

## 6. [core] Core concepts

### 6.1 [core] What counts as an agent, and why the answer deflates the question

An **agent** is a language model using tools in a loop, where the model — not the code around it — decides which tool to call next and when to stop. A **workflow** is the same components with the control flow written in code. Phase 5 made this distinction and Phase 9 made it structural: Atlas's `research` route is a workflow whose steps are chosen by a model, and its `tool_action` route is an agent with a bounded step cap.

A **multi-agent system** is then two or more such loops, each with its own context, exchanging messages.

That definition immediately deflates a lot of marketing. If a "subagent" is a read-only searcher that receives a question, does some retrieval and returns text, it has no persistent context of its own across the parent's run and it makes no decisions the parent cannot see the consequences of. Cognition puts this bluntly: subagents of that kind mostly resemble tool calls rather than genuine multi-agent collaboration. That is not a criticism of them. It is a statement about which costs you are paying. A tool call costs you a schema in the prompt and a result in the transcript. A colleague costs you a coordination protocol.

> **Misconception.** "We have a multi-agent system, we use three subagents." You may have one agent with three expensive tools. The test is not how many prompts you run; it is whether two loops can each take actions the other cannot observe. If every subagent's entire effect on the world is the string it returns to its parent, you have a single-agent system with a compression layer — which, as 6.2 shows, is a genuinely good design and the one Atlas already has.

**Concept check 6.1.** Atlas's `critic` node makes a model call with a different prompt from the handler that produced the answer it reviews. Is `critic` a second agent? Give the deciding criterion, not just the verdict.

### 6.2 [core] The four real benefits, each with its cheaper substitute

**Context isolation.** A subtask can generate thousands of tokens of intermediate junk, of which the parent needs two sentences. Anthropic frames search itself this way — "the essence of search is compression" — with subagents compressing by working in parallel in their own context windows before condensing what matters for the lead agent. This is the strongest of the four, and it is strongest exactly when the subtask is high-volume and low-yield. *The substitute:* Phase 8's compaction plus a structured worker return type. Atlas's workers already return a `WorkerResult`, not a transcript.

**Specialisation.** Different subtasks want different tool sets, output schemas and instructions. *The substitute:* `HANDLER_TOOLS` and per-step `scoped_registry`. A route with two tools and a route-specific prompt is specialisation. It just does not have a name and a face.

**Parallelism.** Three independent lookups take one lookup's wall-clock. Real, and not available any other way. *The substitute:* none, which is why Phase 10 built the fan-out. Note what Phase 10 measured: `Send` results arrive in argument order regardless of completion order, so Atlas gets parallelism without a second control loop. Parallelism is a property of the *executor*, not of having multiple agents.

**Privilege separation.** If only one loop holds the write credential, a compromised or confused reader cannot write. This becomes the centre of the phase, because it is where Cognition's follow-up lands after ten months of production data. Their formulation: the setups that work keep writes single-threaded, and the extra agents supply *intelligence* rather than *actions*. *The substitute:* Atlas's approval gate, which already makes writes single-threaded by routing them through one node a human must clear.

Three of the four have a cheap substitute Atlas has already built, and the fourth is about the executor rather than the architecture. That is the mechanical reason the honest answer is so often "one agent with better tools".

### 6.3 [core] The three real costs

**Coordination overhead** is tokens and calls. Anthropic's measurement is the one to memorise: agents use roughly 4× the tokens of a chat interaction, and multi-agent systems roughly 15×. Section 7 derives the same shape from Atlas's own measured floors and finds where the overhead actually sits, which is not where most arguments about it assume.

**Error propagation** is the compounding problem. Every message boundary is a lossy channel. Cognition's example is the clearest in the literature: a task to clone a well-known game is split in two, one worker builds a background in the wrong game's visual style, the other builds a sprite that moves wrongly, and the final agent is left combining two miscommunications. Their second principle generalises it: actions carry implicit decisions, and conflicting implicit decisions produce bad results.

**Debugging difficulty** costs your time rather than your budget. Anthropic's account is worth taking literally: users reported agents failing to find obvious information, and the team could not see why until full production tracing was added. In a single-agent loop, one transcript contains the whole story. In a multi-agent system the story is distributed across n transcripts plus the messages between them, and nothing assembles it unless you built the assembler. Invariant 40 already applies: a new record type ships with its reader. A multi-agent system needs a *cross-agent* reader, and that is a component nobody budgets for.

> **Misconception.** "Coordination overhead is the price and correctness is the prize." Sometimes the coordination overhead *is* the correctness problem. Section 8's trace burns twelve model calls and returns no answer at all, and the cause is a coordination bug, not a model failure.

### 6.4 [core] The evidence, both sides, and why both are right

**For.** Anthropic's Research system uses an orchestrator-worker architecture, and a lead agent on their larger model with subagents on their mid-sized model beat the single-agent version of the larger model by 90.2% on their internal research eval. The mechanism is the important part: three factors explained 95% of performance variance on BrowseComp, and token usage alone explained 80%. Their reading is that multi-agent architectures work largely because they are a way to spend more tokens on a problem than one context window can hold. They also name the shape of task it suits — breadth-first queries pursuing several independent directions at once — and the counterexample: most coding tasks have fewer genuinely parallelisable parts than research does.

**Against, with a mechanism.** *(If information theory is unfamiliar, read the box below first.)* Tran and Kiela hold the *thinking-token budget* constant and compare a single agent against five multi-agent architectures across three model families on two multi-hop benchmarks. Their theoretical claim applies the Data Processing Inequality: if the messages `M` passed between agents are a function of the context `C` a single agent would have had, then `I(Y; C) ≥ I(Y; M)`, so the single agent with full access to the context is information-theoretically guaranteed to do at least as well. Empirically the single agent matches or beats every multi-agent variant under matched budgets, while spending fewer thinking tokens. Their crossover condition is the useful part: multi-agent designs become competitive when the single agent's effective use of its own context degrades — shown by injecting corruption. Under token substitution at 70%, the sequential multi-agent pipeline overtakes the single agent (0.225 against 0.200). Their summary deserves to be a design rule: multi-agent structure helps not simply when context is longer, but when it becomes harder to tell relevant from misleading information.

Put the two together and the contradiction evaporates. Anthropic's 90.2% is measured against a single agent that *could not hold the material*. That is the degraded-context regime. Tran and Kiela measure where one context holds everything comfortably. The two agree on the mechanism and disagree only about which regime is normal.

> **Orientation: mutual information, the Data Processing Inequality, and Cohen's κ.** Two pieces of machinery show up in this section's sources and nowhere else in the book. Appendix A has fuller notes; this is the working minimum.
>
> **Mutual information** `I(Y; X)` measures how much knowing `X` tells you about `Y`, in bits: zero if they are independent, large if `X` nearly determines `Y`. The **Data Processing Inequality** says that if you can only reach `Y` through `X` — formally, if `Y → X → M` forms a Markov chain, meaning `M` is computed from `X` and never touches `Y` directly — then `I(Y; X) ≥ I(Y; M)`. In plain words: **processing cannot create information.** Summarising, filtering, rephrasing or splitting up `X` can only lose ground relative to `X` itself. That is why the inequality is the natural tool here: messages passed between agents are computed from the context a single agent would have had, so they are exactly the `M` in that chain, and no clever protocol over them can beat perfect use of `X`. The escape hatch, which is the whole empirical story, is the phrase *perfect use*: real models do not use `X` perfectly, and the theorem says nothing about how well they use it.
>
> **Cohen's κ** measures agreement between two annotators after discounting the agreement you would expect from chance alone. It runs from 0 (chance) to 1 (perfect); above about 0.8 is conventionally treated as strong. It matters here for one reason: a taxonomy of failure modes is only as trustworthy as the consistency with which humans can apply it, and κ = 0.88 across independent annotators is the evidence that MAST's fourteen categories mean something outside the heads of the people who wrote them. A taxonomy with κ = 0.4 would be one team's vocabulary.

**How they fail.** Cemri and colleagues built the first empirical failure taxonomy for these systems. MAST comes from 150 traces analysed with expert annotators at Cohen's κ = 0.88, yielding 14 failure modes in three categories — system design issues, inter-agent misalignment, and task verification — over a dataset of 1,600-plus annotated traces from seven frameworks. Their framing motive matters: enthusiasm has outpaced the gains on popular benchmarks. Read the mode names and you notice something uncomfortable: step repetition and being unaware of termination conditions are not model-capability failures. They are the failures of a badly run team. Termination in particular is a thing this book has owned in code since invariant 9 — and a supervisor architecture hands it back to a model unless you stop it.

**And the ten-month update.** Cognition's 2025 position was that parallel-writer architectures are fragile enough to rule out by default. Their 2026 follow-up keeps that and adds the narrow class that works. Two of their three working patterns are worth knowing. A generator-verifier loop: on pull requests written by their own agent, the reviewer finds an average of 2 bugs per PR, roughly 58% of them severe — and, counterintuitively, this works *better* when the two agents share no context beforehand, because the reviewer must reason backward from the implementation without the spec, and a shorter context makes it sharper. Note what that does to their own principle 1: shared context is the rule for *collaborating* agents and the wrong rule for an *adversarial* one. And on the unstructured end: arbitrary networks of agents negotiating with each other are mostly a distraction; the practical shape is a manager that splits work, children that execute, and a manager that synthesises.

Which is orchestrator-workers. Which Atlas has.

**Concept check 6.4.** A colleague cites the 90.2% figure to justify rebuilding Atlas's `data` route as three specialist agents. Using the crossover condition above, state the one question you would ask about the `data` route before agreeing, and say what answer would change your mind.

### 6.5 [core] Seven architectures

Roughly increasing coordination cost. Stop at the first one that meets your requirement.

**Pipeline.** Fixed sequence, each stage feeding the next, control flow in code. Included first because it is the baseline every other architecture must beat. Its failure mode is that it cannot adapt: a stage that discovers the plan was wrong has nowhere to put that information.

```
request → [extract] → [analyse] → [write] → answer
```

**Orchestrator-workers (fan-out/fan-in).** One planner decomposes, n workers execute independently in their own contexts, code joins the results. The workers do not see each other. This is Atlas's `research` route and Anthropic's Research system, and it is Cognition's "map-reduce-and-manage" minus the manager's mid-flight steering. Its failure mode is the conflicting-implicit-decisions problem.

```
                 ┌→ [worker 1] ─┐
request → [plan] ─┼→ [worker 2] ─┼→ [join] → answer
                 └→ [worker 3] ─┘
```

**Supervisor.** A single coordinating loop that decides, *after seeing each result*, which specialist to invoke next. The difference from orchestrator-workers is one word: iterative. The plan is not fixed up front, so the supervisor can adapt — and pays one model call per delegation decision for the privilege. Its failure modes are the two MAST modes named above, and section 8 is a supervisor.

```mermaid
graph LR
    U[request] --> S[supervisor]
    S -->|delegate| A[retriever]
    S -->|delegate| B[analyst]
    S -->|delegate| C[writer]
    A --> S
    B --> S
    C --> S
    S -->|done| O[answer]
```

**Hierarchical.** A supervisor of supervisors. Each mid-level node coordinates its own team and reports upward as if it were a single worker. This is how you scale past the point where one supervisor's context can hold the roster and the accumulated reports. Cognition are running it: a manager agent breaks a large task into pieces, spawns child agents, and coordinates them through an internal MCP — with the honest note that making it feel coherent took more context engineering than expected. Its failure mode is that information needed at the leaves has to survive two lossy hops.

```
                 [top supervisor]
                  /            \
        [research lead]      [writing lead]
         /     |     \          /      \
      [w1]  [w2]  [w3]      [draft]  [edit]
```

**Handoff / swarm.** No coordinator. Each agent can transfer control to another by calling a handoff tool, and the system remembers who is active so the next turn resumes there. Attractive for customer-service routing. Its failure mode is that with no coordinator, nobody owns termination, and a handoff cycle is exactly as easy to write as a handoff chain.

```
[triage] ⇄ [billing]
   ⇅          ⇅
[tech]  ⇄  [refunds]
```

**Debate / critique.** Two or more loops produce answers or criticism over the same problem, and a judge selects or synthesises. In Tran and Kiela's matched-budget sweep, debate was the most consistently strong multi-agent variant — it still generally did not beat the single agent, but it is the one that most nearly holds up under equal compute. Cognition's review loop is this pattern with an asymmetry: the verifier is deliberately given a clean context. Its failure mode is that a judge with no ground truth can only pick the more fluent answer.

```
        ┌→ [proposer] ─┐
problem ─┤              ├→ [judge] → answer
        └→ [critic]   ─┘
```

**[extended] Network.** Any agent may message any other — the general case. Coordination cost grows with the square of the roster and the trace becomes a graph rather than a sequence, which is why Cognition call unstructured swarms a distraction.

**[extended] Blackboard.** No messages at all: agents read and write a shared store and act when they see something actionable. Decouples the roster from the protocol; nobody owns the shared state's consistency. Phase 10 has the mechanism (the cross-thread store) and measured its limit — `search(query=...)` with no index returns the whole namespace in insertion order with `score=None`. A blackboard needs retrieval; the store persists.

> **Misconception.** "Supervisor and orchestrator-workers are two names for the same thing." They differ in exactly one property, and it is the expensive one. Orchestrator-workers plans once and joins in code. A supervisor decides again after every result, which costs one model call per step and makes the supervisor's context grow with the number of steps. Section 7 puts numbers on the difference.

### 6.6 [core] Communication: what crosses the boundary

**Message passing versus shared state.** In message passing, an agent knows only what it was told. In shared state, agents read a common structure. LangGraph's subgraph mechanism sits in between, and Phase 10 measured where: subgraph state maps by *name*, and a child cannot read a key it does not declare — which is why `ChatState` omits `messages` and the `chat` route cannot see the transcript. The asymmetry that bites in multi-agent designs: a child cannot read an undeclared key, but nothing stops it *writing* one the parent declares.

**Full history versus summaries versus structured results.** Cognition's principle 1 says share context, and share full agent traces rather than individual messages. That is the correctness-maximising choice and it is quadratic in the number of steps. Summaries are cheaper and lossy in the way Phase 8 measured: 0 of 6 constraints survived a lossy summary without pinning. Structured results are cheapest and least lossy *for the fields you thought of*, which is why `WorkerResult` has named fields rather than a text blob. Phase 8's rule transfers directly: whatever must survive the boundary is extracted before the boundary and pinned outside it, not requested in a prompt.

**Role prompts: what changes behaviour and what is decoration.** Cognition names the theatrical version: "you're a senior software engineer" is a gimmick. What changes behaviour is anything that changes the model's *action space or its evidence*: the tool set, the output schema, the specific documents in context, and an explicit statement of task boundary and deliverable. Anthropic's second prompting principle is precisely this — each subagent needs an objective, an output format, tool guidance and clear task boundaries, and without them agents duplicate work, leave gaps, or miss what they needed to find. Their concrete failure: one subagent explored a four-year-old chip crisis while two others duplicated each other on current supply chains.

So: a persona is decoration; a tool set is architecture. Atlas already encodes the architecture in `HANDLER_TOOLS`.

**Concept check 6.6.** You are designing a worker that must not fabricate figures. Two candidate mechanisms: a role prompt saying "you are a rigorous analyst who never estimates", and a `read_only` tool set containing only `query_db` plus an output schema whose numeric fields require a `source_relation`. Which is load-bearing and which is decoration? Connect your answer to an invariant from Phase 7.

### 6.7 [core] Allocation, termination, conflict, and the global budget

**Task allocation.** The failure that matters is not a suboptimal split; it is an *infeasible* one. If the union of your workers' tool sets does not cover the task, no allocation succeeds, and the system will not tell you — it will loop. Section 8 is exactly this. Anthropic's mitigation is to make effort scale with complexity explicitly in the prompt: one agent with three to ten tool calls for simple fact-finding, two to four subagents for comparisons, more than ten for complex research. That is a *policy* expressed in a prompt, which by invariant 59's logic is a policy you can and should move into code.

**Termination.** Invariant 9 says termination is owned by the harness, never by the prompt. A supervisor architecture is a direct assault on that invariant, because the natural implementation is "the supervisor decides when it is done". MAST lists unawareness of termination conditions among its fourteen modes. The rule survives translation: a supervisor gets a bounded turn cap in code, a closed `Literal` of stop reasons, and a line of code setting each one.

**Conflict resolution.** Two workers return incompatible answers. There are only four honest policies: last-writer-wins, a fixed precedence order, escalate to a human, or refuse and report both. Anything cleverer is a judge with no ground truth. Atlas's existing choice is the fourth: invariant 35 labels a partial result rather than papering over it, and invariant 29 lets a model add a finding but never clear one.

**Global token budgets.** Phase 5 gave Atlas `CallBudget`, constructed once per run and passed in (invariant 16). In a multi-agent system the budget must be *shared* across agents, which means a single mutable object crossing every boundary. If each agent gets its own budget, your global cap is the sum and you have no global cap.

### 6.8 [core] Inter-agent trust

A message from another agent is untrusted input. That sounds obvious and is almost universally violated, because the natural implementation puts a peer's message straight into a context that has tools attached.

OWASP's Top 10 for Agentic Applications, announced on 9 December 2025 by the OWASP GenAI Security Project's Agentic Security Initiative, gives three of its ten entries to this territory: ASI07 Insecure Inter-Agent Communication, where agents exchange messages without adequate authentication, integrity or policy controls; ASI08 Cascading Failures, where one error or compromise spreads across connected agents; and ASI09 Human-Agent Trust Exploitation, where persuasive output moves a person to approve something unsafe. Phase 14 works through these with Atlas's threat model. Two consequences for a design now.

First, ASI07 is a reason a multi-agent architecture needs a security review that a single-agent one does not, and the controls named are the boring ones from distributed systems: authenticated identities, message integrity, and an explicit policy about which agent may speak to which.

Second, ASI09 is Phase 10's problem in new clothes. Phase 10 established that a rubber-stamped approval transfers accountability without transferring scrutiny. A multi-agent system generates more approval requests, each with a plausible rationale written by a fluent model, and the approval rate is the design parameter.

### 6.9 [core] Universal concepts, framework vocabulary, and a rubric

**Universal.** These exist in every agent framework because they are forced by the problem, and if a framework hides one, that is a finding: **state** (what persists between steps, and its lifetime), **tools** (a described capability plus the schema that constrains it), **handoffs** (transfer of control, however spelled), **checkpoints** (durable state, which is what makes resumption and time travel possible), and **interrupts** (a suspension point where control leaves the system and comes back). Phases 9 and 10 taught all five under LangGraph's names; Phase 8 taught state's lifetime problem before any framework was involved.

**Vocabulary.** `Send`, `Command`, `StateGraph`, superstep, reducer, `durability`, `recursion_limit`, `create_agent`, middleware. Each is one framework's spelling of something universal, or one framework's *policy* about something universal. `recursion_limit` is the second kind: Phase 10 measured that it is inherited by subgraphs rather than divided, and that the minimum is `max(level_supersteps) + 1` rather than the sum. That is a fact about LangGraph, not about agents.

**A rubric for a framework you have never used.** Eight questions, each a phase of this book turned into a probe.

1. **Where is termination decided?** Find the line. If the answer is "the model stops when it says it's done", you own the fix. (Invariant 9)
2. **What is the default for durability, and is the default the safe value?** Phase 10 measured that it was not: under a hard kill, `async` lost the completed superstep *and reported the thread as finished*.
3. **What happens to a batch containing one unknown tool name?** Phase 10 measured the framework's tool node running the known write anyway. (Invariant 24)
4. **What happens when a tool body raises?** A re-raise that kills the run is a defensible general policy and it is not Atlas's. (Invariant 19)
5. **Does the approval mechanism preserve what was approved?** Phase 10's measurement: 0 of 5 original proposals recoverable after an edit, against 5 of 5 for Atlas's additive record.
6. **What is the default concurrency bound, and what is it derived from?** Measured at 5 on a one-vCPU box, because it is `min(32, cpu_count + 4)` — a number with no relationship to your rate limit that changes when you deploy.
7. **Can the topology be serialised, and does the serialisation tell the truth?** Phase 10 measured `Command` without `destinations=` printing an edge to `END` for a node that jumps elsewhere.
8. **Does a search API without an index return an error or a ranking?** Phase 10's answer for the store: the whole namespace, in insertion order, with `score=None`, and no error.

Every question has the same shape, and it is invariant 59: a framework standardises mechanism, never policy, and every policy you can name has a line of the framework's code deciding it. Find the line, then accept its choice explicitly or wrap it.

Two current-state notes live in `VERSIONS.md` rather than here: the separate supervisor and swarm packages that sit on top of the graph library, and their compatibility caveats against the 1.x agent API. Neither is imported anywhere in Atlas.

**Concept check 6.9.** Of the eight rubric questions, which can you answer by reading documentation, and which require running code? For one that requires running code, describe the smallest experiment that answers it.

## 7. [core] Hands-on (on paper): redesign the research pipeline as a supervisor

No code this phase. You will produce three artefacts, all of which go into `docs/MULTI_AGENT_DECISION.md` in section 11: a diagram, a boundary table, and a cost estimate. Budget about ninety minutes.

### 7.1 The design

Atlas's `research` route today is `plan → Send fan-out → aggregate`, with the join in Python. Redesign it as a supervisor over three named specialists:

- `retriever` — tools: `retrieve_documents`, `read_file`, `list_files`
- `analyst` — tools: `query_db`, `calculate`
- `writer` — tools: none; produces the final prose

The supervisor holds no tools except the three handoffs. A coordinator with tools is a coordinator that will do the work itself.

```
              ┌───────────────┐
request ─────→│  supervisor   │───────→ answer
              └───┬───┬───┬───┘
        delegate  │   │   │  report
              ┌───▼┐ ┌▼──┐ ┌▼─────┐
              │ret.│ │ana│ │writer│
              └────┘ └───┘ └──────┘
```

### 7.2 Annotate every boundary

For each arrow, write down three things: what crosses, what does not, and what the omission costs. Do not skip the third column; it is where the design decisions are.

| Boundary | What crosses | What does not | Cost of the omission |
|---|---|---|---|
| request → supervisor | user request, worker roster, tool descriptions per worker | user's profile and memories (Phase 8), prior turns | supervisor may re-ask something already established |
| supervisor → retriever | one instruction, the original request | the analyst's findings, the plan's other steps | retriever cannot know a figure was already found |
| retriever → supervisor | structured findings + citations | which queries were tried and failed | supervisor cannot detect repetition |
| supervisor → analyst | one instruction, the original request | retriever's document findings | analyst cannot join a document figure to a DB figure |
| analyst → supervisor | structured result + relations read | the SQL it ran | supervisor cannot check the query answered the question (invariant 52) |
| supervisor → writer | all findings, the request | tool-error notes, partial flags | writer produces a confident report over incomplete evidence |
| supervisor → answer | prose + citations | which specialists failed | invariant 35's partial label is lost |

Now the design work: pick the three omissions that most endanger correctness and say how you would fix each. My picks, for comparison after you have made yours. The retriever's failed queries should cross, because that is what makes step repetition detectable in code rather than by a model noticing. The partial flag must cross to the writer *and* to the answer, because Atlas has an invariant about it and losing it would be a regression, not a trade-off. And the analyst–retriever gap is not a message-passing problem at all — it is an allocation problem, which section 8 is about.

**Your turn.** Add a fourth column: "who would notice if this omission caused a wrong answer, and how". If the answer is "nobody", you have found a missing record type, and invariant 40 says it ships with its reader.

### 7.3 Estimate the cost

Do not guess a multiplier. Compute one from numbers you already have.

**First, name your baseline, out loud.** The comparison below is against Phase 10's `research` subgraph: one level, `plan → fan-out → aggregate`. It is *not* Phase 5's full `run_research_pipeline`, which also carries up to four levels, a critic pass and a ledger. That simplification **understates what Atlas already spends, and therefore overstates the supervisor's disadvantage** — it runs in the direction of the conclusion I am about to reach, which is the direction that should make you suspicious. So check it: adding Phase 5's per-level critic call makes the pipeline `1 + n + levels`, and at two levels the n=3 ratio falls from 1.90× to roughly 1.5×. The conclusion survives; the honest move is to name the baseline and show the correction rather than pick the flattering one and stay quiet. **Every cost comparison you will ever read has a baseline choice buried in it, and it is almost always chosen by whoever wanted the answer.**

`docs/RESULTS.md` records, measured offline at `CHARS_PER_TOKEN=4.0` with seed 7 on 2026-09-08: the instructions block is **506** estimated tokens on every route, the mean tool schema costs **147**, and the research question itself is **20**. Those three are measurements. The rest are stated assumptions: a plan step reads as 40 tokens, a worker report as 120, a roster plus delegation schema as 60, a delegation decision as 40 out, a synthesised answer as 150 out, the planner emits 20 tokens per step, and each worker sees 2 scoped tool schemas. All eight live as named constants at the top of `scripts/phase11_results.py`, so a reader who disagrees edits one line and re-runs:

```python
# excerpt: scripts/phase11_results.py
INSTRUCTIONS = 506   # measured
TOOL_SCHEMA = 147    # measured, mean per tool
QUESTION = 20        # measured, research route
STEP_TOKENS = 40     # assumed
REPORT_TOKENS = 120  # assumed
ROSTER_TOKENS = 60   # assumed
PLAN_OUT_PER_STEP = 20  # assumed
DELEGATION_OUT = 40  # assumed
SYNTHESIS_OUT = 150  # assumed
```

The `# measured` / `# assumed` comment on every line is not decoration. It is the difference between an estimate and a guess, and it is the first thing a reviewer should look for in anybody's cost model.

Count calls first, because that is where the surprise is. The pipeline is `1 + n`, and the join is **free** — `aggregate` is Python. The supervisor is `2n + 1`. At n=3 that is seven model calls against four. Measured, through the composition callers actually use:

```
[1] model calls on the research route, MEASURED on Tier F
    n | expected 1+n | measured | branches | partial
    1 |            2 |        2 |        1 | False
    2 |            3 |        3 |        2 | False
    3 |            4 |        4 |        3 | False
```

Then count tokens. The pipeline's per-worker context is *constant* in n: instructions, two tool schemas, one step. The supervisor's context *grows* with n, because turn t sees t prior reports. So the pipeline is linear in n and the supervisor is quadratic.

| n | pipeline | supervisor | ratio |
|---|---|---|---|
| 1 | 1,506 | 2,402 | 1.59× |
| 2 | 2,486 | 4,368 | 1.76× |
| 3 | 3,466 | 6,574 | 1.90× |
| 5 | 5,426 | 11,706 | 2.16× |
| 8 | 8,366 | 21,204 | 2.53× |
| 12 | 12,286 | 37,228 | 3.03× |

*Arithmetic over measured static floors plus the stated assumptions; author estimate, unmeasured against a model. Reproduce with `make results PHASE=11`.*

Two findings, and the second is the point of the exercise.

**The multiplier is not a constant.** It runs from 1.59× to 3.03× over a plausible range of plan lengths. Anyone who quotes a single number for "the multi-agent tax" has not asked how many steps. Anthropic's 15× is measured against a *chat*, not against a fanned-out pipeline, and their tasks are much longer than three steps.

**The expensive part is not the part everyone argues about.** Decompose the n=3 overhead: of the 3,108 extra tokens, **2,688 are the delegation turns and the synthesis call**, and only **420** are the cost of sharing full traces between workers. The context-sharing debate — Cognition's principle 1, the thing the literature fights about — is 13% of the overhead here. The other 87% buys the *ability to re-decide after each result*.

That reframes the decision completely. You are not choosing whether to pay for shared context; that is cheap. You are choosing whether adaptive re-planning after each step is worth roughly doubling the token bill, and Atlas's answer depends on how often its plans turn out to be wrong mid-flight — a measurable quantity, and section 11 names the measurement.

> **A note on these numbers, which is itself the lesson.** The table above was drafted in a throwaway script that held the planner's output at a per-*plan* constant of 60 tokens instead of a per-*step* 20. At n=3 those are the same number, so the row the whole argument rests on came out exactly right and five of the other six were wrong by 1–3%. The error was invisible precisely at the value that had been checked by hand. Invariant 51 covers it and so does the fix: the arithmetic ships as a committed script, `make results` prints it, and the document quotes the script. See F-11-02.

**Your turn.** Recompute the table with one change: the workers return 400-token reports instead of 120. Which of the two findings survives, and which reverses? Now do it again with a supervisor that summarises the accumulated reports to a fixed 200 tokens before each delegation turn. What did you buy, and what did Phase 8 measure that it costs you?

### 7.4 [core] With an assistant

Safe to delegate this phase: rendering your boundary table into the document; turning your cost assumptions into a small parametrised script and checking the arithmetic; generating the Mermaid for your supervisor diagram; drafting the "conditions under which we would switch" list from bullet points you supply.

Not safe to delegate: the boundary table's third and fourth columns, the choice of which architecture to recommend, and the cost *assumptions*. An assistant asked to estimate multi-agent overhead will reproduce a number from the literature — most likely 15× — and that number is measured against a different baseline than yours. It will look authoritative and it will be wrong for your system by a factor of five.

A prompt that works: *"Here are three measured token figures from my repo: instructions 506, mean tool schema 147, question 20. Here are my six assumptions about message sizes, each labelled as an assumption. Write a Python script that computes total prompt and completion tokens for (a) plan-then-fan-out with a code join and (b) a supervisor with one delegation call per step, parametrised on n, and print the ratio for n in 1..12. Do not add any figures I have not given you; if you think an assumption is missing, ask instead of choosing one."*

That last sentence is the one that matters. The failure mode of delegating an estimate is not bad arithmetic; it is an invented input that arrives looking like a measurement.

## 8. [core] Debug this trace

A supervisor that ping-ponged between two workers for six turns and returned nothing. Read it before reading the diagnosis.

**Provenance:** every line below is the verbatim output of `make results PHASE=11 ARGS="--only pingpong"`, which runs experiment 3 in `scripts/phase11_results.py` — a committed 40-line supervisor loop over `atlas.llm.FakeLLMClient`. It is deterministic and offline, so you can regenerate it, edit the loop, and watch the symptom change. An earlier draft of this phase generated the trace from a throwaway script that was never committed *and* printed different numbers in `make results`, so the document claimed a reproduction that reproduced the finding and not the trace. Invariant 48 covers it: a committed fixture states its own provenance truthfully.

The supervisor loop is not part of Atlas — it is a deliberately broken teaching artefact. The worker *replies* are scripted fixtures, so what follows demonstrates a control-flow bug, not a model failure. That distinction is the whole diagnosis.

```
task: How many days of runway do we have at the current burn rate, and which
      policy document sets the reserve floor?
workers: {"retriever": ["search_documents"], "analyst": ["calculate"]}
supervisor turn cap: 6

[turn 1] supervisor -> retriever: Find the runway and the reserve floor.
           supervisor saw 151 chars (no history)
[turn 1] retriever -> supervisor: Found Finance Policy v3 section 4: the reserve floor is 6 months of oper...
           tools available to retriever: ['search_documents']

[turn 2] supervisor -> analyst: Compute days of runway.
           supervisor saw 376 chars (task + 1 report)
[turn 2] analyst -> supervisor: I cannot compute days of runway: I have no cash balance and no monthly b...
           tools available to analyst: ['calculate']

[turn 3] supervisor -> retriever: Find the runway and the reserve floor.
           supervisor saw 310 chars (task + 1 report)
[turn 3] retriever -> supervisor: Found Finance Policy v3 section 4: the reserve floor is 6 months of oper...
           tools available to retriever: ['search_documents']

[turn 4] supervisor -> analyst: Compute days of runway.
           supervisor saw 376 chars (task + 1 report)
[turn 4] analyst -> supervisor: I cannot compute days of runway: I have no cash balance and no monthly b...
           tools available to analyst: ['calculate']

[turn 5] supervisor -> retriever: Find the runway and the reserve floor.
           supervisor saw 310 chars (task + 1 report)
[turn 5] retriever -> supervisor: Found Finance Policy v3 section 4: the reserve floor is 6 months of oper...
           tools available to retriever: ['search_documents']

[turn 6] supervisor -> analyst: Compute days of runway.
           supervisor saw 376 chars (task + 1 report)
[turn 6] analyst -> supervisor: I cannot compute days of runway: I have no cash balance and no monthly b...
           tools available to analyst: ['calculate']

stop: turn cap reached after 6 supervisor turns
model calls: 12   est tokens: 627
answer returned to user: none
```

### 8.1 What the trace proves before you interpret anything

Look at the `supervisor saw` line. After turn 1, the prompt size takes exactly two values, forever: 376, 310, 376, 310, 376. That is not a coincidence and it is not the model being stupid. The supervisor's prompt is built from the task plus **the last worker report only**, so its input has exactly two states, and it alternates between them with period 2.

A deterministic function of a period-2 input is a period-2 output. The supervisor cannot escape this loop no matter how capable the model is, because from turn 3 onward it has literally never seen a state it did not already respond to.

**In a supervisor loop, the sequence of prompt sizes is a cheap oracle for a coordination bug.** A healthy supervisor's context grows monotonically. A supervisor whose context oscillates has lost its history; one whose context is constant never had one.

### 8.2 Classifying it

In MAST's vocabulary this is two system-design modes at once: step repetition — the retriever re-runs an identical search three times — and unawareness of termination conditions, in the sense that nothing in the system can recognise that it is not making progress. Both are in MAST's first category, and neither is a model-capability failure.

Note what saved this run from being much worse: the turn cap. Invariant 9 put termination in the harness, so the loop cost 12 calls and stopped. A supervisor that terminates when the model says it is done would still be running.

### 8.3 The three bugs, in order of depth

**Bug 1, the visible one: the supervisor has no memory of its own decisions.** It is a Markov machine on the last message. Phase 9 has a name for what is missing — `seen_signatures`, the pure function over the transcript that Atlas's core loop uses to detect a repeated tool call. The fix is not "give the supervisor a better prompt". The fix is a delegation ledger in state, and a `no_progress` guard in code that fires when a `(worker, instruction)` pair repeats. Phase 10's F-10-02 is a warning about exactly this guard: when a second producer of messages exists, the guard must filter to the turns it is meant to count, or it fires on the wrong thing.

**Bug 2: no worker can see the other's output.** The retriever found the reserve floor and reported that the runway figure lives elsewhere. The analyst reported it cannot compute without a cash balance. Both reports are correct and each is useless alone, because the two halves of the answer never sit in one context. This is Cognition's principle 1 stated as a bug rather than as advice: sharing only the parent's last message is not sharing context.

**Bug 3, the root cause: the allocation is infeasible.** Look at the tool sets. `retriever` has `search_documents`. `analyst` has `calculate`. Neither has a database tool. The task requires a *current burn rate*, which lives in structured data, and **no worker in the roster can obtain it**. Their union does not cover the task.

So no amount of fixing bugs 1 and 2 produces a correct answer. A supervisor with a perfect memory and full context sharing would notice the deadlock faster and then report failure — better, but not an answer. The ping-pong is a *symptom*; the disease is a roster assembled without checking coverage.

This is invariant 20 read in the other direction. Atlas says a prohibition is implemented as an absent tool; the corollary is that **a capability the roster lacks is a prohibition nobody declared.** In a single-agent system with `HANDLER_TOOLS["research"]`, the missing `query_db` would be visible in one table on one line. Distributed across three worker definitions in three files, it is visible nowhere.

### 8.4 The fixes, and what each one is worth

1. **Coverage check at wiring time.** Assert that the union of the workers' tool sets covers the route's declared `HANDLER_TOOLS`, and fail at build time. This is D-57's shape — `build_core_graph` already refuses to compile a gated tool with no consequence renderer — applied to rosters. It is the only one of these fixes that prevents the failure rather than detecting it.
2. **A delegation ledger plus a `no_progress` stop reason,** as a closed `Literal` member with a line of code that sets it (invariant 30).
3. **A shared findings channel** the workers write and read, rather than reports that travel only through the supervisor.
4. **A labelled partial,** so a run that ends on the turn cap returns "here is the reserve floor, the burn rate is unavailable" rather than nothing. Invariant 35 already requires this and the trace violates it: `answer returned to user: none` is an early exit that skipped the reporting step.

Fix 1 is worth more than the other three combined, and it is the cheapest.

**Contrast with Atlas — the point of eval task `p11-c`.** Given the same condition, Atlas produces one record per branch with failures included, a `partial` label, a note naming the count, and an escalation: `3 branch(es), 1 failed`, `partial: true`, `escalated`. Terminating is not enough on its own — a run that terminates while reporting `partial: false` has manufactured a complete answer out of two thirds of one.

**Your turn.** The trace's supervisor made six delegation decisions and every one of them was locally reasonable. Write two sentences explaining why "make the supervisor's prompt better" is the wrong first response, in terms of what the supervisor could and could not observe.

## 9. [core] Common pitfalls & how professionals avoid them

**Counting agents instead of counting effects.** The question is never how many prompts you run; it is how many independent loops can take actions the others cannot observe. Professionals count *writers*. Cognition's whole revised position reduces to keeping that count at one.

**Quoting a token multiplier without its baseline.** 15× is measured against a chat. Section 7's 1.90× is measured against an already-fanned-out pipeline at n=3, and it becomes 3.03× at n=12. State the baseline and the n, or state nothing.

**Letting the supervisor own termination.** It is the natural implementation and it is a MAST failure mode. A turn cap in code, a closed stop-reason set, and a progress guard. Every time.

**Assembling a roster without a coverage check.** Section 8's root cause, and the one that survives every other fix. Derive the roster's tool sets from the route's declared tool set and assert the coverage at build time, so the failure is a build error and not a loop.

**Treating a peer's message as trusted input.** It arrives from your own system, so it feels internal. It is a model's output entering a context that has tools attached. ASI07 exists because this is the default.

**Giving each agent its own budget.** Your global cap becomes the sum of the local caps, which is not a cap. One `CallBudget`, constructed once, passed everywhere (invariant 16). The same mistake, one level up: budget for the cross-agent trace reader *before* you build the agents, because invariant 40 says a record ships with its reader and nobody costs that in.

**Sharing context by default because a blog post said to.** Shared context is right for collaborators and wrong for verifiers — Cognition's review loop works *better* with none. Ask whether the second agent's value comes from agreement or from independence.

**Mistaking a persona for a specialisation.** A role prompt changes tone; a tool set, an output schema and a scoped document set change behaviour. Delete every persona line and see whether anything moves. Five minutes, and it settles the argument.

**Redesigning before measuring the thing the redesign fixes.** The crossover condition names a measurement: multi-agent structure helps when one context can no longer separate relevant from misleading material. That is testable on your own corpus. Measure, then decide.

## 10. [extended] Industry perspective

Three postures exist, and each is coherent given what that team ships.

**The research-product posture** (Anthropic's Research feature): breadth-first, read-only, high-value tasks where one context cannot hold the material. Multi-agent wins, because it is a way to spend more tokens than one window allows. Their unexpected operational lessons — synchronous subagents create an information bottleneck so the lead cannot steer mid-flight; deployment needs rainbow releases because agents may be anywhere in their process when you ship; and having an agent rewrite a bad tool description cut task completion time by 40% for later agents.

**The coding-product posture** (Cognition): one writer, extra agents supplying intelligence. The patterns that pay are the review loop and the capability router. Their negative result is worth as much as the positives — a cheap primary consulting an expensive model failed when the primary was much weaker, which they read as a training problem rather than a prompting one.

**The platform posture** (framework vendors): ship supervisor, swarm and hierarchical as libraries and let the application decide. This is why invariant 59 exists — a library serving every application picks the general policy, and the general policy is rarely yours.

The trade-off that unites them: **multi-agent architectures convert a context problem into a communication problem.** If your bottleneck is context, that is a good trade. If it is not, you have bought a coordination protocol you did not need.

**Interview questions.**

1. Anthropic report +90.2%; a matched-budget study finds single agents win. Both are correct. Reconcile them, then tell me which regime our system is in and how you would check.
2. You inherit a supervisor that loops. Walk me through your first three diagnostic steps, in order, and say what each rules out.
3. Where would you put termination in a supervisor architecture, and what would you do to make a violation of that choice fail loudly?
4. Two workers return contradictory figures. Enumerate your options, then pick one and defend it against the objection that it is unhelpful to the user.
5. A colleague wants role prompts for each agent. Which parts of that proposal change behaviour and which are decoration? Design a cheap experiment that tells the difference.

## 11. [core] Capstone increment

**If your code diverged, start again from `atlas_phase_10.zip`.**

**Resume note.** Atlas keeps its single-agent orchestrator-workers pipeline, and now says so in writing, with the cost, the alternative design, and the four measurements that would reverse the decision. One real defect from Phase 10 is fixed: the research route had never planned anything.

**What Atlas can do now.** Everything it could do at the end of Phase 10, plus: the `research` route actually plans. That is not a new capability, it is the capability Phase 10 claimed. Stated precisely, `research` is `plan → Send fan-out → aggregate`, the planner runs, the fan-out spends one model call per branch, and the join spends none.

**Files touched.**

| file | change |
|---|---|
| `atlas/graph/app.py` | F-11-01: the planner closure's import and return-unpacking |
| `docs/MULTI_AGENT_DECISION.md` | **new** — the design, the cost, the decision, the reversal conditions |
| `evals/tasks/phase11.json` | **new** — 3 tasks grading the claims that decision rests on |
| `tests/test_graph_phase11.py` | **new** — the two tests F-11-01 should have had |
| `scripts/phase11_results.py` | **new** — `make results`: the call relation, the arithmetic, §8's periodicity |
| `tests/hidden/test_phase11_a1.py`, `_a2.py` | **new** — structural checks plus self-graded rubrics |
| `tests/test_evals_harness.py` | gradeable task count 51 → 54 |
| `Makefile` | `PHASE ?= 11` |
| `docs/DECISIONS.md` | D-59, D-60 |
| `docs/FAILURE_LOG.md` | F-11-01, F-11-02, the five-trace exercise |
| `ATLAS_INTERFACES.md`, `VERSIONS.md` | v0.23, invariant 67, the Phase 11 delta |

**Code.** The whole code change this phase, and the reason it was invisible:

```python
# excerpt: atlas/graph/app.py
        from atlas.agents.planexec import make_plan  # noqa: PLC0415

        try:
            plan, _complaints, _p_tok, _c_tok, _latency = make_plan(
                client, request, registry=_scoped(registry, "research"), seed=seed
            )
            if plan is None:
                return []
            return [step.description for step in plan.steps][:research_levels]
        except Exception:  # noqa: BLE001 - an unplannable request fans out to nothing
            return []
```

The previous version imported `make_plan` from `atlas.agents.plan`, where it does not exist, and treated the return value as an object with `.steps` when it is a five-tuple. Both errors sat inside the `try`, so the `ImportError` was swallowed, `fan` received an empty list, F-10-04's fix correctly routed the empty case to `aggregate`, and invariant 35 correctly labelled the result `partial` — a well-formed, truthfully-labelled partial answer on every request since Phase 10 shipped, with 1,306 tests green.

**Tests added.** Four, in one file. The parametrised one is the one that matters:

```python
# excerpt: tests/test_graph_phase11.py
    assert len(client.calls) == 1 + n, (
        f"{len(client.calls)} model calls for a {n}-step plan; expected {1 + n} "
        "(one planner call, one per branch, and a join that is Python)"
    )
```

The second test generalises the defect rather than the fix: it walks every function-local `from X import Y` in `atlas/` with `ast` and asserts the name resolves, against an exempt set of two modules each carrying its reason. A deferred import has no load-time check, and inside a `try` it has no run-time symptom either.

**+3 eval tasks** (51 → 54, all passing), each grading an *outcome* rather than a path:

- `p11-a-every-branch-reports-once-and-the-join-is-code` — 3 branches for a 3-step plan, `partial: false`, `final`.
- `p11-b-a-one-step-plan-produces-exactly-one-branch` — the same relation at a second point. Two points make a relation; one makes a number.
- `p11-c-a-step-that-cannot-complete-is-a-labelled-partial-not-a-loop` — §8's counterexample on Atlas. Three properties graded together, because any one alone is satisfiable by a wrong system:

```json
# excerpt: evals/tasks/phase11.json
     "field": "outcome.n_tool_calls",
     "op": "eq",
     "value": 3
     "field": "outcome.partial",
     "op": "eq",
     "value": true
     "field": "outcome.note",
     "op": "contains",
     "value": "1 failed"
     "field": "state.stop_reason",
     "op": "eq",
     "value": "escalated"
```

(Braces and commas elided so `make check-docs` can match each line against the task file in order; the shape is the standard four-key check object.)

Measured: **0/3 on the pre-fix tree, 3/3 after** (`git show phase-10:atlas/graph/app.py` if you want to reproduce it). That is the argument for writing the task before trusting the summary.

The **call counts** are asserted in `tests/test_graph_phase11.py`, not here, and the split is deliberate: invariant 22 reserves an eval check for what the agent produced rather than the path it took, and `client.n_calls` is a path metric. The first draft of `phase11.json` graded it and was green — green while grading a trajectory through an interface that promises not to. From this phase on: **evals grade outcomes, tests grade mechanism.**

**`make results`.** Experiment 1 measures `calls = 1 + n` at n=1,2,3 (exact, also asserted by tests). Experiment 2 prints the token arithmetic and moves when you edit its assumption constants, which is the intended use — ratio 1.59× at n=1 to 3.03× at n=12, and the n=3 overhead split 2,688 tokens of extra calls against 420 of shared traces. Experiment 3 prints §8's trace verbatim, so the teaching artefact is regenerable. Tier A calls: 0, and `--append-results` refuses because nothing here measured a model (invariant 25).

**Interface changes.** None. `planner` is a closure private to `build_atlas_graph`; no published name changed. `ATLAS_INTERFACES.md` gains a Phase 11 section recording the fix and the phase's four artefacts, invariant 67, and `docs/MULTI_AGENT_DECISION.md` as a contract document.

**"Read five failing traces" entry.** No new traces; nothing new runs. Re-read the five most recent `research` entries in `docs/FAILURE_LOG.md` with this phase's question: would a second agent have helped? For each, one line: was the failure a wrong plan, a wrong step, or a wrong join, and would a supervisor that could re-decide after step 1 have changed the outcome? The count of yeses is the input to reversal condition 1.

**Repo tag.** `phase-11`.

## 12. [core] Mastery checklist

You are ready to move on if you can:

- State the test for whether a component is a second agent, and apply it to Atlas's `critic`.
- Name the four benefits and, for three of them, the Atlas mechanism that already delivers it.
- Reconcile the +90.2% result with the matched-budget result in three sentences, naming the regime each measures.
- Draw all seven architectures from memory and name one failure mode each.
- Say what a supervisor buys that orchestrator-workers does not, and what it costs per step in calls.
- Compute `calls` for both architectures as a function of `n` without looking it up, say which is linear and which quadratic, and say why.
- Annotate a message boundary with the cost of an omission, phrased as a wrong answer a user would receive.
- Given a looping supervisor trace, distinguish the memory bug, the sharing bug and the coverage bug, and say which fix prevents rather than detects.
- Name the five universal concepts, and apply at least four of the eight rubric questions to a framework you have not used.
- Explain why a broad `except` around a correct fallback is a good hiding place for a typo, and what makes the difference visible.

## 13. [core] Quiz

1. A colleague says their system is multi-agent because it runs four different prompts. What single question settles whether they are right, and why is that the right question?
2. Anthropic report that token usage alone explained 80% of performance variance on a browsing benchmark. Give one architectural conclusion that follows and one that does not.
3. The Data Processing Inequality argument says a single agent with the full context is guaranteed to do at least as well as a multi-agent system over messages derived from it. Multi-agent systems nonetheless win in some measured settings. Explain where the guarantee stops applying.
4. Atlas's `aggregate` node adds nothing to the model-call count. Explain why this makes the pipeline's cost linear in the plan length while a supervisor's is quadratic.
5. Cognition report that a code-review loop works better when the two agents share *no* context, while their own first principle says to share full traces. Both are their findings. State the distinction that makes them consistent.
6. A supervisor's prompt size sequence is `[151, 376, 310, 376, 310, 376]`. What can you conclude before reading a single message, and what can you not conclude?

## 14. [core] Coding assignments

Both are **design** assignments. Neither adds a module; both ship a Markdown document under `docs/`.

**How they are graded, which is half structural and half yours.** `make grade PHASE=11` checks *structure* — the things a machine can verify without understanding your argument: is there a decision, does the boundary table have a "does not cross" column, is a threshold stated with a unit, is termination addressed. The other half is the five-item rubric printed below for each assignment. Score yourself against it and record the result in your own document as a `Self-score:` line with the per-item breakdown; the hidden test checks that the line is there, not what it says. **A green `make grade` means the shape is right. It does not mean the design is good, and only the rubric tells you which.**

*(An earlier version of these files printed the rubrics from a passing test. pytest captures stdout on passing tests, so the rubrics were never displayed — a mechanism built, tested and wired to nothing, in the file that lectures about it. Invariant 41 does not exempt the grader. They live here now, where they can be read before you start, which is also where a rubric belongs.)*

### Assignment 1 — `docs/A1_SUPERVISOR_DESIGN.md` **[fast track: do this one]**

Redesign the `tool_action` route as a two-agent system: a `proposer` that reads and proposes writes, and an `executor` that holds the only write capability and performs approved writes. Then decide whether to build it.

**Acceptance criteria.** The document contains: a diagram; a table of at least three annotated boundaries with a "does not cross" column and a cost column; a call-count relation in `n` for both architectures; an explicit statement of who owns termination and how a violation fails loudly; a token estimate that separates measured figures from assumptions, per figure; a decision; and at least two reversal conditions, one of which names a threshold with a unit.

**UNAIDED CORE.** The boundary table's "cost of the omission" column, and the reversal conditions. Write both with no assistant. Everything else — rendering, arithmetic, the Mermaid — you may delegate.

Two hints, because this design has a trap. First, the `proposer`/`executor` split is *already* what Atlas's approval gate is, with a human as the executor; say what a model executor adds and what it removes. Second, the write capability is a tool, so the split is enforced by `scoped_registry` and not by a prompt — which means the interesting question is what the executor can verify about a proposal it did not produce.

Run `make grade PHASE=11`.

**Rubric — Assignment 1 (2 points each, 10 total).**

1. **Coverage.** Does the union of your agents' tool sets cover the route's declared `HANDLER_TOOLS` entry, and did you say where that is asserted? *0 = not mentioned; 1 = mentioned; 2 = asserted at build time, with the failure mode named.*
2. **The third column.** For each boundary, is the cost of the omission a consequence a *user* would experience, or a restatement of the omission? *0 = restatement; 1 = vague harm; 2 = a specific wrong answer a user receives.*
3. **Provenance.** Can a reader tell, line by line, which figures you measured and which you assumed? *0 = no; 1 = a general disclaimer; 2 = per figure.*
4. **The relation.** Does your cost estimate scale in the size of the work, and did you say which architecture is linear and which quadratic, and why? *0 = one number; 1 = a table; 2 = a table plus the structural reason.*
5. **The reversal.** Could a colleague who disagreed settle it by running a measurement you named? *0 = no; 1 = with effort; 2 = you named the measurement and the threshold.*

Eight or more with no zeros is a pass. **A zero on item 5 is a fail whatever the total:** a decision nobody can overturn with evidence is not a decision, it is a preference with a document.

### Assignment 2 — `docs/A2_FRAMEWORK_REVIEW.md` [extended]

Apply section 6.9's eight questions to one agent framework Atlas does not use. Pick anything with public source. Answer all eight, and for each, say whether your answer came from documentation, from reading source, or from running something — and pin the framework's version and your checked-on date.

**Acceptance criteria.** All eight questions addressed; at least four references to a specific symbol, file or line; explicit use of the mechanism/policy distinction; at least one default that is defensible in general and wrong for Atlas, with both positions stated fairly; a statement of what you would wrap; at least one answer established by running code; and a verdict with a blocking condition.

**UNAIDED CORE.** Questions 1, 2 and 5 (termination, durability default, approval-record preservation), including the experiments. These are the three that documentation reliably gets wrong, and finding that out yourself is the assignment.

Run `make grade PHASE=11`.

**Rubric — Assignment 2 (2 points each, 10 total).**

1. **Coverage.** All eight questions answered, none padded with a restatement of the question. *0 / 1 / 2.*
2. **Evidence.** For each question, is the answer sourced to documentation, to source code, or to something you ran — and do you say which? *0 = unsourced; 1 = mixed and unlabelled; 2 = labelled per answer.*
3. **The disagreements.** Did you find at least one policy whose default is defensible in general and wrong for Atlas? *0 = none found; 1 = found, unexplained; 2 = found, both positions stated fairly.*
4. **Consequences.** For each disagreement, what you would wrap and what the wrapper costs. *0 = neither; 1 = wrap named; 2 = wrap named and cost stated.*
5. **The verdict.** Adopt it or not, for which part of Atlas, and what one thing would stop you? *0 = no verdict; 1 = a verdict; 2 = a verdict with a blocking condition.*

Eight or more with no zeros is a pass. **Item 3 scoring zero usually means you read about the framework rather than into it**: every framework has at least one default that is wrong for somebody, and finding it is the exercise.

## 15. [extended] Case study

None this phase. Section 7 is the design exercise and section 11 is its rubric.

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 12.*

**The two results that look contradictory measure different regimes, and the regime is the design input.** A lead-and-subagents research system beat its single-agent equivalent by 90.2% on an internal eval, and token usage alone explained 80% of the variance on BrowseComp — multi-agent architectures are largely a way to spend more tokens than one window holds. A matched-thinking-token study across three model families and five architectures found the single agent matching or beating all of them, with a Data Processing Inequality argument: messages between agents are computed from the context a single agent would have had, so `I(Y; C) ≥ I(Y; M)` and processing cannot create information. The escape hatch is the phrase *perfect use of C*, and the crossover is measured: under token substitution at α=0.7 the sequential pipeline reached 0.225 against the single agent's 0.200, while under mild degradation and distractor injection the single agent stayed ahead. **Multi-agent structure helps when context is corrupted, not merely when it is long.**

**Three of the four benefits already have cheaper substitutes in Atlas, and the fourth belongs to the executor.** Context isolation → structured `WorkerResult` returns plus Phase 8 compaction. Specialisation → `HANDLER_TOOLS` and `scoped_registry`; a persona is decoration, a tool set is architecture. Privilege separation → the approval gate, plus `allow_writes=False` on `research` unconditionally. Parallelism → `Send`, which Phase 10 got without a second control loop. Cognition's position after ten months in production: keep writes single-threaded and let extra agents supply intelligence rather than actions.

**The cost multiplier is a function of plan length, and the expensive half is not the one the literature argues about.** Measured: `calls = 1 + n` on Atlas's route, because `aggregate` is Python; a supervisor is `2n + 1`. Each pipeline worker's context is constant in `n` and a supervisor's turn `t` must read `t` prior reports, so one is linear and the other quadratic — ratio 1.59× at n=1, 3.03× at n=12. At n=3, of 3,108 extra tokens, **2,688 are the extra calls and 420 are shared traces**: context sharing is 13% of the overhead and re-deciding after each result is 87%. So the question is not "should agents share context" but "how often is our plan wrong mid-flight" — measurable, and unmeasured, which is why D-59 declines the build with four reversal conditions attached. **Name your baseline out loud**: this comparison is against Phase 10's single-level subgraph, not Phase 5's full pipeline, and that choice flatters the conclusion (adding a per-level critic call drops the n=3 ratio to about 1.5×, and the conclusion survives).

**A looping supervisor is three bugs deep and only the deepest one matters.** Measured, from a committed scripted run: after turn 1 the supervisor's prompt size took exactly two values forever — `151, 376, 310, 376, 310, 376` — so its input was periodic with period 2 and no model could escape. Bug 1, no memory of its own delegations. Bug 2, no worker could see the other's output. Bug 3, the root cause: the union of the workers' tool sets did not cover the task, so **no allocation could succeed**. Invariant 20 read backwards: *a capability the roster lacks is a prohibition nobody declared.* The fix that prevents rather than detects is a coverage assertion at wiring time. The cheap oracle to remember: a healthy supervisor's context grows monotonically, so an oscillating one has lost its history and a constant one never had one.

**Invariant 67, and the defect that produced it.** Phase 10's research route had never planned anything. `planner` imported `make_plan` from the wrong module and mis-unpacked its return, both inside `try: ... except Exception: return []`. The ImportError was swallowed, the empty fan-out reached the reporting step exactly as F-10-04's fix intended, and invariant 35 labelled the result `partial` with a truthful note — so **the route returned a well-formed, correctly-labelled partial answer on every request, with 1,306 tests green.** Every research test injected its own planner, so the assembly was never graded (invariant 46, third appearance). **An `except` broad enough to catch a programming error will convert one into a business outcome, and the correct handling of a real condition is the best hiding place there is.** Where a broad `except` must stay, grade a quantity that separates "could not do it" from "could not run" — usually the model-call count. Corollary: a function-local import has no load-time check and, inside a `try`, no run-time symptom, so every deferred import in `atlas/` is now resolved by an `ast` walk against an enumerated exempt set. Found by writing an eval task for a claim the previous phase's summary made.

**Where a cost claim is graded, from now on.** Invariant 22 reserves eval checks for what the agent *produced*, and a model-call count is a path metric. So: `evals/tasks/*.json` grade outcomes — branches, partial labels, stop reasons; `tests/` grade mechanism — call counts, call order, wiring. The first draft of `phase11.json` graded `client.n_calls` and was green while grading a trajectory through an interface that promises not to.

**Two smaller lessons, both about checks.** F-11-02: the published cost table came from a draft holding a per-plan constant where a per-step one belonged, so n=3 — the row the argument rests on — was exactly right and five of six others were wrong by 1–3%. *The error was invisible precisely where it had been checked by hand.* And the hidden tests shipped two over-fitted checks: a threshold regex whose trailing `\b` could never match after `%`, and a relation check requiring the letter `n` that rejected the solutions file's own model answer. **A check over-fitted to one phrasing of the right idea is worse than no check, because it teaches the student to write for the grader.** Both patterns now have a test that fires each branch (invariant 57).

**Five concepts are universal and the rest is vocabulary.** State, tools, handoffs, checkpoints, interrupts. `Send`, `Command`, superstep, reducer, `durability`, `recursion_limit` are one framework's spelling or one framework's *policy* — `recursion_limit` is inherited by subgraphs rather than divided, which is a fact about LangGraph. The eight-question rubric is invariant 59 made portable: find the line that decides each policy, then accept its choice explicitly or wrap it.

**Atlas now.** Unchanged in capability and finally honest about it: `START → router → {chat | document | data | research | tool_action} → critic → persist → respond → END`, approval before every write, escalation with an actionable handoff, bounded fan-out on the default path with a planner that runs, per-user audit trail, crash-safe runs. **1,310 offline tests, 54 gradeable eval tasks all passing**, no network, no model, and one decision recorded with the measurements that would overturn it.

**Phase 12 next.** Atlas acts on a user's behalf with scoped credentials, and reversal condition 3 is waiting there: the moment one step needs an authority another step must be denied, privilege separation stops being a bonus and becomes the requirement — the one condition in D-59 that a future phase, rather than a measurement, is likely to trip.

## 17. [core] Further reading

- Anthropic, *How we built our multi-agent research system*, 13 June 2025. The orchestrator-worker architecture, the +90.2% figure, the 4×/15× token multiples, eight prompting principles, and the production lessons on state, deployment and synchronous bottlenecks. https://www.anthropic.com/engineering/multi-agent-research-system
- Walden Yan (Cognition), *Don't Build Multi-Agents*, 12 June 2025. The two context-engineering principles and the Flappy Bird decomposition failure. https://cognition.com/blog/dont-build-multi-agents
- Walden Yan (Cognition), *Multi-Agents: What's Actually Working*, 22 April 2026. The ten-month revision: single-threaded writes, the clean-context review loop (~2 bugs/PR, ~58% severe), the smart-friend negative result, map-reduce-and-manage. https://cognition.com/blog/multi-agents-working
- Cemri et al., *Why Do Multi-Agent LLM Systems Fail?*, arXiv:2503.13657 (v1 17 Mar 2025, v3 26 Oct 2025). MAST: 14 failure modes in 3 categories, κ = 0.88, 1,600+ annotated traces across 7 frameworks. https://arxiv.org/abs/2503.13657
- Tran and Kiela, *Single-Agent LLMs Outperform Multi-Agent Systems on Multi-Hop Reasoning Under Equal Thinking Token Budgets*, arXiv:2604.02460 (v2, 11 Apr 2026). The Data Processing Inequality argument, the matched-budget sweep, and the context-degradation crossover. https://arxiv.org/abs/2604.02460
- OWASP GenAI Security Project, *Top 10 for Agentic Applications*, announced 9 December 2025. ASI01–ASI10; ASI07, ASI08 and ASI09 are this phase's territory and Phase 14's material. https://genai.owasp.org/2025/12/09/owasp-top-10-for-agentic-applications-the-benchmark-for-agentic-security-in-the-age-of-autonomous-ai/
- Hong, Troynikov and Huber (Chroma), *Context Rot: How Increasing Input Tokens Impacts LLM Performance*, July 2025. The mechanism behind the clean-context finding. https://www.trychroma.com/research/context-rot

## 18. [core] Solutions

Emitted separately as `phase_11_solutions.md`.

## 19. [core] Handoff

See the handoff section of the Phase 11 chat response for the download links, the changed-file list, and the `VERSIONS.md` delta rows.
