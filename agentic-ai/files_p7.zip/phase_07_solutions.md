# phase_07_solutions.md

Worked answers for Phase 7 — Retrieval for Agents II. Read after attempting.

## Cumulative review (§2)

**1. Plan-and-execute's own `StopReason`.** The property is that a `Literal` is a **closed set whose members are part of the published interface**, so adding an exit is a deliberate contract change rather than a new string appearing in a field. Reusing ReAct's would have meant either widening ReAct's Literal (changing a published interface for an unrelated agent) or having plan-and-execute report exits that could not occur — a member nothing can reach, which is invariant 30's target because it breaks nothing and therefore nothing reports it. The test is the reachability test D-18 requires: for each member, a line of code that sets it, asserted by exercising every exit.

**2. `CachingClient(BudgetedClient(inner, budget), cache)`.** The rule is invariant 14: **a wrapper that can return without calling inward goes outside any wrapper that meters inward calls.** A cache hit returns without calling inward, so it must sit outside the meter. Reversed, `BudgetedClient` would charge the budget on every request including the hundred cache hits, so after a hundred hits it would report a hundred calls and their tokens spent while the provider saw zero — a budget that "ran out" without any money being spent, and, worse, a `CallBudget` whose figures cannot be reconciled with a provider invoice.

**3. Add-but-never-clear.** The shape is: **when a model is consulted about a decision, identify the direction in which its error is dangerous, and remove the field that would let it move the decision that way.** A critic asked to certify quality can only be asked to withhold certification. You have seen it in Phase 4 (`merge_findings`, invariant 29), Phase 5 (`EvaluationDraft` has no `accept` field, D-25), Phase 6 (`GroundedDraft` has no `sufficient`/`confidence`, D-31) and now Phase 7 (`GradeDraft` has no `relevant` list, D-36).

**4. `("chat", 0.0)`.** Because `reconcile` implements five rules over *two* opinions, and a weak opinion and an absent opinion require different rules. With a genuine low-confidence keyword hint, `reconcile` must decide whether the disagreement is evidence against the model's label; with no hint at all, there is nothing to disagree with and the correct behaviour is to defer to the model at its own threshold. A fabricated best-guess-at-0.2 would enter the disagreement arithmetic and could pull a correct model label below threshold on the strength of no evidence. Explicit absence is a value `reconcile` can branch on; weak evidence is a value it must weigh.

**5. `idem_key`.** No **run id**, so the same work in a later run replays instead of re-executing — which is what makes a chain resumable at all. No **attempt number**, so retrying a step looks up the same key and a completed step is not redone. The **handler version** is included so that changing what a step *does* invalidates its cached results. Get the third wrong and the ledger replays a result produced by code that no longer exists — silently, at zero cost, reported as `ok` and `replayed` — which is the worst of the three failures because the record positively asserts the work was done.

## Concept checks

**7.1.** Two reasons. First, one correct answer from the model's own weights is indistinguishable from a lucky guess about a fact that happens to be common knowledge; the warranty term is a private fact, and answering it correctly without retrieval would be alarming rather than reassuring. Second, the tool shape's characteristic failure is *not retrieving*, so a request that skipped retrieval is an instance of the risky path, not evidence against it — you cannot learn "the model retrieves when it should" from a case where it did not. The field you need is a record of **whether retrieval was attempted and with what query** — `AgenticAnswer.rounds` here, or `tools_called` on a trajectory. Without it, "answered correctly" and "answered correctly from evidence" are the same string.

**7.3.** IDF is a function of the whole corpus: `ln(1 + (N - n + 0.5)/(n + 0.5))`. On 28 chunks a term in one chunk has IDF ≈ 2.96 and a term in fourteen has IDF ≈ 0.62; on 280,000 chunks a term in one has IDF ≈ 12.8 and the *same relative rarity* produces a very different absolute weight. Coverage is a ratio so the scale largely cancels — but which terms have nonzero IDF does not, because a term absent from 28 chunks may be common in 280,000. So the same coverage number is computed over a different set of weighted terms. After a large ingest you must re-run the floor calibration (Assignment 1), and you should expect the floor to move down, because more terms become weighted and a chunk matching a fixed number of them covers a smaller share.

**7.8.** The false-abstention rate is 0/28 on a query set whose gold documents are known to exist and whose wording was written by the same person who wrote the documents. Production questions are typed by users who do not know the corpus's vocabulary, so the coverage distribution over real questions is shifted lower and the same floor refuses more of them. The measurement that replaces it is a **logged sample of real questions, labelled by someone who can check whether the corpus does contain the answer** — and the number to report is not the abstention rate but the share of abstentions that were *wrong*, split by whether the answer existed.

**7.9.** (a) **database** — an average over shipment rows; getting it wrong sends it to documents, where retrieval returns the shipping-regions policy and generation produces a plausible ratio from a sentence about depots. (b) **documents** — 24 months, a tolerance in `calibration-tolerances-2026`; getting it wrong sends it to SQL, which has no interval column, so the best case is `no_sql` and the worst is a number from `v_shipments`. (c) **database** — a count over `v_warranty`; getting it wrong sends it to documents, which contain no claim records at all, and the honest outcome is an abstention that looks like a system failure. (d) **web** — the Helion X9 is a competitor; getting it wrong sends it to documents, where `warranty-policy` says "12 months" about *Northwind's* instruments and generation attributes Northwind's term to a competitor. (d) is the dangerous one, because the wrong answer is a correct sentence about the wrong subject.

**7.12.** **None of the five fires.** `count(*)` over no matching rows returns one row containing 0, which is not zero rows and not an all-NULL row, so `all_null_row` is False by design. And that is correct: the right thing to say is **"there were zero claims in 2027Q1"**, not "nothing matched" — because `count` over an empty set is a *genuine measurement* of an empty set, whereas `sum` over an empty set is the absence of a measurement. The difference is that a count's domain includes zero and a sum's does not: "how many claims" has the answer 0, while "what was the total units" over no shipments has no answer, and NULL is SQLite saying so. Collapsing them turns a true zero into a refusal, which is why `test_all_null_row_is_the_check_people_leave_out` asserts `all_null_row([(0,)]) is False`.

## Quiz

**1.** A grader can **remove** a result, changing the size of the set the generator sees, including to zero. The exact identity from Phase 6: reranking `k` retrieved results down to `k` cannot change recall@k, because recall@k is a property of the *set* of k results and a reranker is a permutation of that set — measured and printed by every `make results` run as `retrieve 5 -> rerank 5 (NO-OP)`. A permutation preserves membership; a filter does not.

**2.** With a `relevant` list, first, **the model could rescue a chunk the floor rejected**, which is the direction the asymmetry exists to forbid and which would make the floor advisory. Second, and worse, **the two lists could disagree** — an extract in both, or in neither — so the code would need a reconciliation rule for a conflict that carries no information, and whichever way that rule falls it is a decision nobody deliberately made. The second is worse: the first is a known risk you could bound with a policy, while the second is an undefined behaviour discovered in production by whoever reads the code next.

**3.** Coverage is `matched_idf / total_weighted_idf`. A term the corpus has never contained has IDF 0.0, so it adds nothing to the numerator **and nothing to the denominator** — it is not counted as missing, it is not counted at all. A question whose only corpus-known terms are present therefore scores 1.000 regardless of how many unknown terms it also has. Counting the unknown terms does not fix it because the signal does not separate: it reaches 0.750 on the *answerable* `q27` ("when does amendment A-2026-2 take effect"), and it does so because the OCR-damaged amendment extracted its title as `7 am —— A-2026-2`, so the word "amendment" is absent from the corpus. The extractor's damage and a genuinely undocumented topic produce the identical signal.

**4.** The `research` route's steps are written by a planner at run time, so the set of tools any given step needs **cannot be enumerated at design time** — a step might need the index, the database, or both, and nobody knows which when the plan is drafted. That is the escape clause in invariant 33: control flow lives in code *unless* the branch set cannot be enumerated at design time. Every other route's need is known from its label, so the tool choice is a fixed pre-step and giving the model a decision would be paying twice for the same one.

**5.** `sum(units)` over no rows returns one row containing NULL, which is SQLite reporting the **absence of a measurement**; rendering it produces "0" or "none" and states as a fact about 2027Q1 something the data cannot support, so it must block. `count(*)` over no rows returns one row containing 0, which is a **genuine measurement of an empty set** — there really were zero claims — so blocking it would refuse a true and useful answer. The rule is not "one row" or "a falsy value" but whether the aggregate's domain includes the empty case.

**6.** It tells you they are **orthogonal mechanisms answering different questions**: the boundary answers "may this statement run", and nothing in it answers "does the result answer the question that was asked". A system with only the first is fully secure and can still report a real number that answers a different question — which is the failure a reader is least equipped to catch, because everything about the answer looks right. One design consequence: **every answer carries the provenance of what it read**, so a mismatch between the question's subject and the answer's source is visible to a human and checkable by a test. A second acceptable answer: result checks are separate from statement checks, and their blocking subset is defined by consequence rather than by severity.

## Assignment 1 — `calibrate_floor`

**Shape.** `FloorRow(floor, retrieved, kept, precision, precision_clean, precision_messy, recall, recall_clean, recall_messy, emptied)`; `FloorReport(rows, floors, chosen, cliff)` with `render()`. Both Pydantic models, round-tripping their own dumps.

**The selection rule, which is the unaided core.**

```python
safe = [
    row.floor
    for row in rows
    if row.emptied == 0
    and row.recall_clean >= baseline.recall_clean
    and row.recall_messy >= baseline.recall_messy
]
chosen = max(safe) if safe else 0.0
fell = [row.floor for row in rows if row.recall_clean < baseline.recall_clean]
cliff = min(fell) if fell else None
```

Three things to get right. **`max`, not `min`**: 0.0 is always safe, so "a safe floor" is worth nothing and the value of the calibration is the *last* safe one. **Compare against the baseline, not against 1.0**: on a corpus where ungraded recall is 0.93, requiring 1.0 chooses 0.0 forever, and the question is whether grading *loses* recall, not whether recall is perfect. **`or 0.0`**: fail closed, so a corpus where nothing is safe gets no grading rather than the least-bad floor.

**The split, which is the other half of the unaided core.** Compute precision and recall per half **over the same retrieval**, not by re-searching per half. Re-searching is not wrong here but it is twice the work and it invites the mistake of applying a half-specific floor. One search per query, then partition the survivors by `labelled.corpus`.

**Why the monotonicity tests exist.** Raising the drop floor can only remove chunks, so `kept` cannot rise and precision cannot fall. If either does, your "filter" is adding or reordering hits — most commonly because the sweep re-searched with different parameters per floor, or because `grade_hits` was called with `keep_floor` instead of `partial_floor` (F-07-03, and the reason those two tests are in the hidden file).

**Why no model call.** A calibration that needs a model cannot run in CI (invariant 2), cannot be re-run cheaply after an ingest, and would make the chosen floor a function of model variance. The hidden test greps the source for `client`, `complete(` and `structured(` — a crude check, and adequate, because the module has no legitimate reason to contain any of those strings.

## Assignment 2 — the population check

**`outer_aggregate`, the unaided core.** The difficulty is that `count(` appears in subqueries and `HAVING` clauses where it says nothing about the shape of the result. Without writing a parser, the workable approach is: take the text between the outermost `SELECT` and its matching `FROM`, tracking parenthesis depth so a nested `SELECT ... FROM` is skipped, then look for a leading `name(` at depth zero in that projection. A regex over the whole statement cannot do this — `SELECT sum(units) ... HAVING count(*) > 2` would match `count`, which is exactly the case the hidden test pins.

A sketch, with the depth tracking that matters:

```python
def outer_aggregate(sql: str) -> str | None:
    """The aggregate wrapping the outermost select item, or None. Pure."""
    text = strip_sql_comments(sql).strip()
    lowered = text.lower()
    start = lowered.find("select")
    if start < 0:
        return None
    depth, cursor = 0, start + len("select")
    for index in range(cursor, len(text)):
        char = text[index]
        if char == "(":
            depth += 1
        elif char == ")":
            depth -= 1
        elif depth == 0 and lowered.startswith("from", index):
            projection = text[cursor:index]
            match = re.match(r"\s*(?:distinct\s+)?([a-z_]+)\s*\(", projection, re.I)
            return match.group(1).lower() if match else None
    return None
```

**Wiring, which the hidden tests check separately.** `sanity_checks` gains an optional `db_path` and forwards to `population_check`; `answer_data_question` passes it. A check only its own caller invokes is wired to nothing (invariant 41), and the hidden file has a test for the forwarding as well as for the check.

**`population_check`.** Five abstention conditions before any probe, and each one is a case where "the population" is not a single number: a non-`count` outer aggregate (a sum of units is not bounded by a row count); more than one relation read (with a join the population is a product, not a count); more than one result row (one row per group is not one number to bound); a relation the schema does not advertise; and an empty or NULL result. Only after all five does it open the database read-only and run `SELECT count(*) FROM <relation>`.

**Why it is worth having despite `wrong_relation` existing.** `wrong_relation` catches §8 by **vocabulary** — it works because "claims" happens to be in `SUBJECT_RELATIONS` — and abstains on any question whose subject it does not recognise. `impossible_magnitude` catches a class of the same failure by **arithmetic**, with no word list and no knowledge of what the question was about. Two independent mechanisms failing differently is the reranker lesson from Phase 6 inverted: a second check that fails the same way as the first is an echo, and a second check that fails differently is worth its cost.

**Why blocking.** A count exceeding its own population is not a caveat about precision; it is a statement that cannot be true of any database. There is no reading of it a user could act on safely.

**Two traps the hidden tests set.** `population_check("SELECT count(*) FROM v_warranty", [(43,)], ...)` must produce no finding — equal is not exceeding, and an off-by-one refuses the most obviously correct query in the corpus. And the composition test uses a question whose subject *matches* the relation read and whose filter *is* carried, so no other check can fire; an earlier draft of that test accepted `wrong_relation` as a pass, which made it satisfiable by a `population_check` that always returned `[]`. If a graded test can be passed by a stub, it is grading nothing.

## The source rule, wired (§7.17)

Students sometimes ask why the fold returns *no opinion* on disagreement rather than the more confident hint. Three reasons, in increasing order of importance. Two free classifiers that contradict each other have, between them, produced no information — averaging or picking a winner manufactures a number from nothing. `reconcile` already has a rule for "no opinion" (defer to the model) and no rule for "contested", so returning 0.0 reuses a tested path instead of adding an untested one. And `reconcile`'s rule 5 refuses a side-effecting route over a hint disagreement — it reads whatever the fold returns, so turning a classifier argument into confidence would let a keyword list authorise a write. The cost is real and worth naming: a case where both heuristics are individually right about different aspects of a question falls back to the model alone.

`keyword_hint` keeps its Phase 5 meaning — the raw keyword verdict — and the folded value gets its own field. Overwriting it would have broken a Phase 5 eval task, and worse, made a *disagreement* indistinguishable from *two silent classifiers*, because the fold renders both as confidence 0.0. Two different situations collapsing to one recorded value is the shape of an evidence bug.

## Case study — marking notes

The three answers that separate a 25 from a 15.

**Citation enforcement must be subtractive.** The insurer's condition cannot be met by a prompt instruction or by asking the model to cite. It is met by resolving every citation against the retrieved chunks in code and **withholding** any answer whose citations do not resolve — Phase 6's `citations_unresolved`, which exists precisely because an unresolvable citation is a fabricated one. A strong answer also notes that the model's schema must carry no self-assessment field, because a model that can assert "well grounded" will, and the insurer's condition is about traceability rather than confidence.

**Supersession is the domain-specific failure and most designs miss it.** Retrieval ranks by similarity, and an original clause and its amendment are near-identical text, so the original frequently outranks the amendment that voids it. This is Atlas's `warranty-amendment-a-2026-2` at scale. The mechanism has to be structural: effective dates in the index, an amendment relation between documents, and a rule that an answer citing a superseded clause either cites the amendment too or refuses. No amount of reranking fixes it, because both documents are relevant.

**The confidentiality boundary belongs in the capability, not the filter.** A metadata filter at query time is one bug away from disclosure, and the bug is F-06-07 — a filter applied to one retriever and not the other. The strong answer builds a per-matter-team index or a per-team scoped registry, so a lawyer outside the team is not filtered out of the results but has no path to them: an absent capability rather than a rule that is followed (invariant 20).

Full marks additionally require a stated list of what the system will not do — no corpus-level assertions from top-k, no answer from a single low-confidence OCR page, no cross-matter retrieval — and the argument that this is what the insurer is buying.
