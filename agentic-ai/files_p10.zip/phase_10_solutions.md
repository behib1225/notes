# phase_10_solutions.md

Worked answers for Phase 10 — *Advanced Orchestration: Finishing the Migration, Human-in-the-Loop, Escalation, Subgraphs, Fan-Out, and Durable Execution*.

---

## Cumulative review (§2)

**CR-1.** A signal is useful for a *decision* only if its distributions separate. One answerable question at 0.750 sits inside the unanswerable range 0.400–1.000, so any threshold that would refuse the unanswerable cases also refuses that answerable one. The reason the overlap exists is the killer: OCR destroyed the word the query used, so a high `unknown_term_share` means either "undocumented" or "damaged" and the signal cannot tell them apart. Invariant 49 — a measured non-separating signal is computed, printed, and wired to no decision. Deleting it is how the next person re-discovers it; acting on it is a threshold producing false refusals.

**CR-2.** "Is this query permitted?" and "does this answer the question?" are different questions. The read-only boundary answers the first, and it refused nothing because there was nothing to refuse — the query was legal, cheap, read-only, and against the wrong relation. A system with only a security check reports a real number answering a question nobody asked. Atlas now runs both: every data answer carries `relations_read` (so provenance is printable and checkable, invariant 42) and passes **result checks** whose blocking subset is defined by consequence (D-39, D-40, invariant 52).

**CR-3.** A field reporting compliance is a field that can report compliance *falsely*. The first two omissions prevent the summariser from naming or de-prioritising a constraint; the third prevents it from *claiming it kept them*, which would be worse than either, because a downstream check reading that field would pass on the summariser's word. The guarantee is structural: constraints are extracted before compaction and concatenated after the summary by code, so the summariser never sees them and has nothing to report about (D-44, invariant 55).

**CR-4.** The second gate was computed against the very constant that had already filtered its own trigger away — so the condition it tested could never be true downstream of the filter, while the interface file, the results file, and a tool's help text all described it as protection. A gate that cannot fire is worse than an absent one, because it reads as protection (invariant 57). Corollary: when a soft warning and a hard cutoff are derived from one constant, the warning is dead; give them separate constants and assert the ordering.

**CR-5.** Enforcement and adequacy are different questions. A budget answers "can this be exceeded?"; only a composition log and a recall probe answer "are the right things present?" The honest `DROPPED: tool_schemas` line reported truthfully and handed a ReAct loop a prompt with no action space — so the report was accurate and the system was broken. The assembler now classifies every block by whether its absence *degrades the answer* or *breaks the mechanism*, and marks the second kind `required=True`; required blocks over budget raise (invariant 56, F-08-03).

---

## Concept checks

**6.1.a.** The parent's transcript contains **one** message with id `ai-7`: the child's. `add_messages` is an upsert-by-id with deletion, not an append (Phase 9), and the reducer that applies on the way back up is the *parent's*. The pre-existing message is replaced, silently.

**6.1.b.** Compile time: nothing. Run time: `state.get("escalation")` returns `None`, because a child receives only the keys its own schema declares — the key is invisible to it, not empty. This is invariant 62's class: a value produced correctly and read by nothing, or here, a read that silently returns a default. It is the mirror of F-10-03, and the reason `test_every_run_scoped_channel_is_reset` is structural rather than a hand-written list.

**6.2.a.** Two rows if keyed by autoincrement; one if keyed by a hash of the pending action. The count is a bug in the first case and correct in the second — and this is invariant 37 in miniature: the key must hash *the work*, not the attempt. Note that "two rows" here is not a harmless duplicate: an audit table with two "approval requested" rows and one approval implies a request that was never answered.

**6.2.b.** Because the runtime must *not* let the node's local state continue to exist. A sentinel return would leave the frame alive and the node mid-execution, and there is no way to serialise a live Python frame into a checkpoint. Raising unwinds the frame, which lets the runtime write a checkpoint describing a node that has not started and re-enter it later — possibly in a different process. The exception is not error signalling; it is how the frame gets discarded.

**6.3.a.** (1) The co-occurring `read_file` call — auto-approved, absent from the payload, so the operator cannot see the full batch they are effectively permitting. (2) The *consequence*: the payload renders `Tool: write_file / Args: {...}`, which is a serialisation of a call, not a fact about the world. The first touches invariant 24 (a batch is validated and dispatched as a unit — an operator approving one member of a unit should see the unit); the second is §6.4 rule 1, and untreated it produces the "target state unknown" blind spot §8's trace turns on.

**6.3.b.** Prevents: a write tool added in a later phase being ungated because nobody remembered to add a line (invariant 58). Introduces: the gate now inherits the correctness of every `read_only` flag, and a mislabelled flag silently shrinks coverage — while *also* granting that tool retry and cache eligibility. That is F-10-05 and invariant 66. Deriving from metadata moves the trust from a list to a boolean; it does not remove the trust, and the boolean is checked by nothing until Assignment 1.

**6.4.a.** (1) The gated set is too broad — Atlas is asking about routine, low-consequence writes, and the operator has correctly learned they are all fine. Fix: narrow the gated set, move the routine tier to asynchronous review. (2) The gated set is right and the operator has stopped reading — approval fatigue, and the next genuinely bad write will be approved too. Fix: reduce the *rate*, add friction on the irreversible subset. The distinguishing measurement is the **refusal rate on deliberately-injected bad proposals**: seed a small fraction of synthetic requests that should be refused and measure how many are. Everything else is unfalsifiable.

**6.4.b.** Gained: refusal stays exactly as cheap as approval, so the price does not push operators toward approving; and `reason=None` is *recorded*, so "refused without comment" is a visible fact rather than the string `"n/a"` that a mandatory field produces. It follows invariant 49's reasoning — record the honest absence rather than manufacturing a value — and D-25's shape for closed-set reasons.

**6.5.a.** A reader: `HandoffPackage.render()`. Invariant 40 — a new record type ships with its reader in the same commit, because a record nothing can render is a failure log entry telling somebody to read a trace that does not exist.

**6.5.b.** Because the model may receive `write_refused` and then *answer anyway*, producing `stop_reason="final"`. A stop-reason-based detector would see a successful episode and never escalate, while the user's actual request went unperformed. The `error_kind` is the durable evidence that authority was missing regardless of how the episode ended — which is also why it is read from `additional_kwargs["atlas_tool_result"]` and not from prose (invariant 65).

**6.6.a.** Satisfied for free: invariant 35's "one record per branch, in argument order". Still **not** given: "failures included". A worker that raises kills the superstep and takes its siblings with it, so Atlas's `run_worker` catches and records — and the partial label is derived from *every* incompleteness signal (failed branches *and* an empty plan, which is F-10-04).

**6.7.a.** With `durability="sync"`: **two** emails. The node was in flight, so resume re-executes it from the top. With `"async"`: also two (and possibly the whole chain re-runs). With `"exit"`: one, then the thread is unresumable and the run is lost — which is not better, merely differently broken. No durability mode fixes this; only idempotency does, which is the point.

**6.7.b.** `OutputTruncated`. The framework's default predicate is a heuristic over exception *types* it knows; `OutputTruncated` is neither a `ConnectionError` nor a `ValueError`, and `default_retry_on` would have to guess. Atlas's remedy for it is *raise `max_tokens`*, and retrying unchanged reproduces the truncation at full cost. The direction is "would retry when it must not."

**6.8.a.** The topology's serialisation has stopped matching the topology. `draw_mermaid()` now claims the node reaches `END` when it jumps elsewhere, so any `END`-reachability assertion passes against a diagram that is wrong, and `make graph` prints a confident lie. Invariant 62 — the topology is asserted against its own serialisation — defeated by the mechanism it was written to protect.

**6.8.b.** Unchanged: `max(level_supersteps) + 1`. Nesting does not accumulate, because each Pregel level checks the inherited value against its own count. So a grandchild needing `3 * max_steps + 2` sets the floor for the whole tree, and adding levels costs nothing *unless* a level is deeper than the current worst. The trap is the reverse of the intuitive one: people budget the sum and over-provision, then a single deep child blows a fuse they thought was generous.

**6.9.a.** Redundant: the per-user filtering that `MemoryStore.retrieve` does in SQL — namespacing gives isolation by construction. **Not** redundant, though it looks it: `search(filter=...)`. It is an exact-match filter over value fields with no ranking, so it cannot replace the recency/relevance/importance blend, the min-max normalisation, or the staleness windows. And `search(query=...)` looks like the replacement and is the trap — measured, it returns the whole namespace unranked with `score=None` and raises nothing.

---

## Quiz

**1.** The write is discarded silently — no exception, no warning — and the downstream `state.get("verdict")` returns `None`, so the branch takes its default path. The tests say nothing: a unit test of the producing node passes (it returns the right dict) and a unit test of the consuming node passes (given a state that *has* the key). Only a test through the composition fails, and only if one exists. An auditor reading the thread concludes that a refusal was recorded *and* the refused action proceeded — so the system has produced evidence of oversight that did not take effect, which is strictly worse than having no gate, because the record is what an audit trusts. Invariant 62, sharpened by invariant 66's corollary; F-10-03.

**2.** The two guards are `seen_signatures` (the unedited calls in the batch now appear in both the model's message and the human's, so `no_progress` fires) and `model_calls_this_run` (the human's `AIMessage` is counted as a model turn, so the step cap is charged for a turn no model produced). The fix must filter before slicing because `seen_signatures` excludes the *last turn* by slicing `messages[:-1]`; with a gate in the loop the last message is the human's revision, so slicing first removes the human's copy and *retains* the model's original — every unedited call still counts twice. Filter to model turns, then take `[:-1]`. The principle is invariant 60: during a migration an improvement is indistinguishable from a bug, so the faithful version lands first and the only oracle is an equivalence test with an absolute assertion beside it.

**3.** The strongest case *for*: a framework's job is to hand the tool node a list of calls that are authorised, and mutating-in-place with a stable id is the minimal, allocation-free way to express "this is the call now." It keeps exactly one assistant message per model turn, which keeps the transcript shape identical whether or not a gate is installed — so every downstream consumer written for the ungated case keeps working, including message counters, providers that require strict alternation, and token accounting. That is a real and defensible design goal. Atlas cannot accept it because Atlas's transcript is *evidence*: invariant 15 requires repairs to be recorded and never hidden, invariant 11 requires anything a check can name to survive `model_dump()`, and the eval task `p10-b` grades the presence of both proposals. Atlas pays the cost the framework avoided — one extra message per edit, and the F-10-02 guard fix — in exchange for a transcript that can answer "what did the model want?" separately from "what was allowed?"

**4.** Losing the work is recoverable: a resumed run redoes it, and the only cost is duplicated side effects, which idempotency handles. `next=()` is a *lie about completion*. It is indistinguishable from a successfully finished run, so anything that decides "is this thread done?" by inspecting `next` — a supervisor, a sweeper, a retry scheduler, a dashboard — concludes the refund was processed. Nothing retries it, nothing alerts, and the failure is silent and permanent. The general form: a failure mode that mimics success defeats every monitor that checks for success.

**6.** A grep proved that the name `build_research_subgraph` appears in two files: a test module and an experiment script. It did **not** prove that any production code path calls it — and in fact none did, because `build_atlas_graph` registered `research` as a single-node shim. The reviewer's question should have been the one invariant 63 actually asks: *name the call site on the default path.* No grep answers that, and neither does a green test suite, because "the builder works" passes for "the system does it". The check that does answer it asserts the child's node names appear in the compiled parent's topology (`get_graph(xray=1)`), which is a claim about wiring rather than about existence. See F-10-08.

**5.** `read_only` says "performs no effects"; `cacheable` says "returns the same output for the same input." Neither implies the other. **Read-only but not cacheable:** `current_time` — writes nothing, and a cached answer is wrong. **Cacheable but not read-only:** an idempotent `ensure_ledger_row(order_id)` — it writes, so it must never be auto-retried or replayed, yet its result for a given order is stable and safely memoisable *if* the write has already landed. Conflating them is a security problem rather than a performance one because `read_only` grants **three** privileges from one boolean — exemption from approval, retry eligibility, cache eligibility — so a tool mislabelled read-only does not merely bypass the gate; the wrong write becomes retryable and replayable. Invariant 66.

**7.** *Working:* the `tool_action` route exists to perform writes, so a high rate is expected; every write is now recorded with an operator identity and a timestamp, which is a real audit trail that did not exist before; and no refusals may simply mean the routing and the model are good, which is what the previous nine phases were for. *Not working:* an 85% ask rate on a route whose whole purpose is writing means the gate is asking about the *default* case, which is precisely the condition under which evaluation is replaced by a reflex; three weeks of zero refusals is consistent with an operator who has stopped reading, and the gate is now manufacturing consent records for writes nobody examined. The settling measurement is the injected-bad-proposal refusal rate (see 6.4.a). Regardless of the outcome, change the payload first: group by reversibility and put the irreversible subset behind separate, higher-friction confirmation, so that the 15% that matters stops arriving with the same weight as the 85% that does not.

---

## Assignment 1 — reference solution

`atlas/safety/coverage.py`. The bucket rule is the assignment; here is the reasoning that was asked to be unaided, then the shape.

**What counts as an effect.** Three candidate definitions. (a) *Any filesystem mtime change* — rejected: too sensitive, and a tool that reads a file updates its atime on some mounts, so this produces false positives that train people to ignore the report. (b) *No exception raised* — rejected outright; this is the defect the assignment exists to catch, since a successful upload raises nothing. (c) **A change in the set of (path, size, content-hash) triples under the workspace, plus any call reaching a stubbed network boundary.** Chosen. It catches creation, deletion, and in-place modification, and it is insensitive to metadata churn.

**Its blind spot, stated because the assignment requires it:** an effect outside the workspace and outside the stubbed boundary is invisible — a write to `/tmp`, a subprocess, a message to a local daemon on a unix socket. So `effect_free` returning `True` means "no effect *observed through two channels*", and the report says exactly that rather than "verified effect-free". The honest name for the bucket is therefore `read_only_verified` with the two channels documented, and the next phase's sandbox is what narrows the gap.

**The hard case named in the assignment** — a tool that reads a file and updates its own cache — is resolved by *where the cache lives*. A cache under the workspace is an effect and the tool is not read-only; a cache in a process-local dict is not observable and the tool is. This is a real decision with a real consequence (the tool becomes cacheable and retryable), so it belongs in the tool's docstring, not in `coverage.py`.

```python
class CoverageReport(BaseModel):
    model_config = ConfigDict(extra="ignore")   # invariant 31; F-10-01
    read_only_verified: list[str] = Field(default_factory=list)
    gated_rendered: list[str] = Field(default_factory=list)
    unverified: list[str] = Field(default_factory=list)
    notes: dict[str, str] = Field(default_factory=dict)

    @computed_field
    @property
    def clean(self) -> bool:
        return not self.unverified

    def render(self) -> str:
        lines = ["tool coverage (invariant 66):"]
        for name in self.read_only_verified:
            lines.append(f"  read-only, effect-free   {name}")
        for name in self.gated_rendered:
            lines.append(f"  gated, renderer present  {name}")
        for name in self.unverified:
            lines.append(f"  UNVERIFIED               {name} — {self.notes.get(name, '')}")
        return "\n".join(lines)


def _snapshot(root: Path) -> dict[str, str]:
    out = {}
    for path in sorted(root.rglob("*")):
        if path.is_file():
            out[str(path.relative_to(root))] = hashlib.sha256(path.read_bytes()).hexdigest()
    return out


def effect_free(spec: ToolSpec, *, workspace: Path) -> tuple[bool, str]:
    """Observed effect-free through two channels. NEVER raises: returns data."""
    before = _snapshot(workspace)
    try:
        spec.fn(**_plausible_arguments(spec))
    except Exception as exc:            # a tool that fails still may have written
        note = f"raised {type(exc).__name__}"
    else:
        note = ""
    after = _snapshot(workspace)
    if before != after:
        changed = sorted(set(before) ^ set(after)) or [
            k for k in after if before.get(k) != after[k]
        ]
        return False, f"workspace changed: {changed[:3]}"
    return True, note


def coverage_report(registry: ToolRegistry, *, workspace: Path) -> CoverageReport:
    report = CoverageReport()
    for spec in registry.specs:
        if spec.read_only:
            ok, note = effect_free(spec, workspace=workspace)
            (report.read_only_verified if ok else report.unverified).append(spec.name)
            if not ok:
                report.notes[spec.name] = note or "declared read_only but wrote"
        elif has_consequence_renderer(spec.name):
            report.gated_rendered.append(spec.name)
        else:
            report.unverified.append(spec.name)
            report.notes[spec.name] = "gated with no consequence renderer (§6.4 rule 1)"
    return report
```

`has_consequence_renderer` is a membership test against the names `consequence_for` handles explicitly — and the honest implementation asks `consequence_for` itself, checking whether the returned sentence is the fall-through. Making that a separate constant is drift (invariant 18's reasoning): the renderer and the registry of renderers must be one description.

**Grading note.** The most common wrong answer treats "no exception" as "no effect". The second most common snapshots only the top level of the workspace, so a write into a subdirectory passes. The third produces `effect_free` that *raises* on a tool with required arguments it cannot synthesise — a check that raises is a check that gets caught and ignored; return `(False, "arguments not synthesisable")` and let the report carry it.

---

## Assignment 2 — reference solution

The five lines of hashing, then the part that matters.

```python
HANDLER_VERSION = "v1"

def work_key(tool: str, arguments: dict, *, handler_version: str = HANDLER_VERSION,
             **ignored: Any) -> str:
    """Hashes the WORK. Invariant 37: no run id, no attempt number.

    `**ignored` is deliberate and load-bearing: a caller passing `attempt=3`
    gets the same key. Accepting and discarding is safer than rejecting,
    because the failure mode of rejecting is an exception in a retry path,
    and the failure mode of accepting-into-the-hash is a duplicate charge.
    """
    payload = json.dumps(
        {"tool": tool, "arguments": arguments, "handler_version": handler_version},
        sort_keys=True, separators=(",", ":"),
    )
    return hashlib.sha256(payload.encode()).hexdigest()[:32]
```

**The ordering question, which was the UNAIDED CORE.**

*Run-then-claim.* Run the effect, then write the key. Failure mode: the process dies between the effect and the claim, and the effect happens **twice** on resume — exactly §6.7's measurement, where the in-flight node re-executed. This is the ordering that looks obviously correct and is wrong for the case the assignment is about.

*Claim-then-run.* Write the key, then run the effect. Failure mode: the process dies between the claim and the effect, and the effect happens **zero** times while the key says done — a *lost* charge, silently, forever.

Neither is safe alone, and the choice is a choice about which failure you can detect. **Chosen: claim-then-run, with the claim carrying a state.** The key is written as `{"state": "claimed", "at": ...}` before the effect and updated to `{"state": "done", "value": ...}` after. `already_done` returns a value only for `state == "done"`. A key stuck in `claimed` is then a *detectable* anomaly — a reconciliation job lists claimed-but-not-done keys older than a timeout and escalates — whereas a duplicate charge is detectable only by the customer.

That is the honest answer to the case study's "state one thing your design cannot guarantee": it cannot guarantee the effect happened, only that it happened at most once, and the residual risk is moved to a place where a sweeper can see it.

```python
def run_once(store, key: str, effect: Callable[[], Any]) -> OnceResult:
    done = already_done(store, key)
    if done is not None:
        return OnceResult(key=key, value=done, replayed=True)
    store.put(_NS, key, {"state": "claimed", "at": time.time()})
    try:
        value = effect()
    except Exception:
        store.delete(_NS, key)      # release: a failure leaves the key unclaimed
        raise
    mark_done(store, key, value)
    return OnceResult(key=key, value=value, replayed=False)
```

The `except` releasing the claim is what the hidden test's "a failed effect is not marked done" checks, and it is the compromise that makes claim-then-run usable: a *clean* failure releases, and only a *crash* leaves the detectable `claimed` state.

**The version-change-in-flight case** (asked by the case study, and the reason `handler_version` is in the key): changing `HANDLER_VERSION` changes every key, so a charge claimed under `v1` and resumed under `v2` will be **charged again**. This is correct — the handler is different work now — and it is also a live foot-gun on deploy. The mitigation is procedural, not clever: drain claimed keys before shipping a handler version change, and the release checklist says so.

---

## Case study — worked answer sketch

**The five sources of a duplicate charge.** (1) The approval gate's node re-executes from the top on resume, so a charge above the `interrupt()` fires once per resume. (2) A `RetryPolicy` on the charging node re-runs the whole body per attempt. (3) A `CachePolicy` does *not* duplicate but is worse — it may return a stale receipt for a charge that never landed, and invariant 37 forbids it on a non-read-only node. (4) Crash resume re-runs the in-flight node — measured, 2 executions. (5) A resumed thread presented to a second operator who approves again: the interrupt is re-raised because the gate node restarts, and nothing in the graph knows the first approval existed. Source (5) is the one most designs miss, and it is why the `approvals` channel is thread-scoped with an `operator.add` reducer — the gate can read its own history.

**Durability:** `sync`. 40 approvals/day against a synchronous checkpoint write per superstep is a rounding error; `async` risks a charge with no record of the charge, and `exit` loses the run.

**Node boundaries:** the charge is alone in its own node. Not for tidiness — the replay unit *is* the node, so anything sharing a node with the charge re-runs when the charge re-runs. The ledger write may share only if it is idempotent on the same key; the email must not, because an idempotent email is a harder problem than an idempotent charge and the customer notices.

**Escalation for four 503s:** distinct from approval — nobody has a decision to make, Atlas has run out of ways to proceed. Package: order id, amount, the four attempt timestamps with response codes, the idempotency key used, one question ("has this charge landed on the provider's side? check key `abc123`"), and the thread id. The question is answerable in the provider's dashboard in thirty seconds, which is the standard a blocking question should meet.
