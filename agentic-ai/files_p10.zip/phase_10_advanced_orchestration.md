# Phase 10 — Advanced Orchestration: Finishing the Migration, Human-in-the-Loop, Escalation, Subgraphs, Fan-Out, and Durable Execution

## 1. [core] Phase 10

| | |
|---|---|
| **Study hours** | 12 h — 4 read / 5 build / 3 assess |
| **Compute time** | Full `make results` sweep ≈ 50–70 min, unattended. No interactive step exceeds ~8 min of model time. |
| **Tier A calls per sweep** | ~1,300 |
| **Tier H calls** | ≤ 50, cached to `data/cache/`, never required by a test |
| **Cost** | $0.00 outside Appendix B |
| **Repo tag** | `phase-10` |

Every measurement in this phase was taken on the pinned framework version. The version itself is a current-state fact and lives in `VERSIONS.md`, never in this prose.

## 2. [core] Cumulative review

Five questions from Phases 7 and 8. Answers in `phase_10_solutions.md`.

**CR-1.** Phase 7 computed `unknown_term_share`, printed it everywhere, and wired it to no decision. Its range on unanswerable questions was 0.400–1.000, and one *answerable* question scored 0.750. Why is that single overlapping point enough to keep the signal unwired? Name the invariant.

**CR-2.** The Phase 7 data route ran a query that was legal, cheap, read-only, and against the wrong relation, and the read-only boundary refused nothing. Explain why "the security check passed" and "the answer is correct" answer different questions, and name the two mechanisms Atlas now runs instead of one.

**CR-3.** Phase 8 measured 0 of 6 constraints surviving a lossy summary without pinning and 6 of 6 with it. The summariser's schema has no field naming a constraint, none marking one droppable, and none reporting that it kept them. Give the reason for the *third* omission specifically.

**CR-4.** Two gates in `MemoryRetrieval` could not fire. One was a literal `False`. Describe the shape of the second — the subtler one, and the one you are likelier to write — and give the corollary about soft warnings and hard cutoffs.

**CR-5.** Phase 8's assembler printed an honest `DROPPED: tool_schemas` line and handed a ReAct loop a prompt with no action space. Why is reporting a drop not the same as the drop being survivable? State the classification the assembler now applies to every block.

## 3. [core] Why this phase matters

Phase 9 moved Atlas's *core* into a graph and left the rest of Atlas in front of it. The router still dispatched through a Python dict, the five subflows were ordinary function calls, and `run_core` was a seam hiding a graph from a caller that did not know it was talking to one. That was the right size for one phase — the equivalence test could only be written because so little moved — but it left Atlas a graph wearing a function's clothes, with every capability that justified the migration on the other side of the clothes.

Persistence is the mechanism, and Phase 9 wired it. What persistence *buys* is this phase. An agent that can be checkpointed can be suspended; one that can be suspended can ask a human a question and stop until it is answered; one that can stop can be resumed on a different process after a crash. `StateSnapshot.interrupts` was the empty tuple at the end of Phase 9 — the field waiting for its mechanism. Human-in-the-loop is not a feature bolted onto persistence, it *is* persistence plus a place to suspend.

The second reason will cost you more time. Phase 9's whole discipline was invariant 59: a framework standardises mechanism, never policy, and every policy you can name has a line of the framework's code deciding it. That discipline found four policies in four components. This phase adopts five more mechanisms — subgraphs, interrupts, `Send` fan-out, retry and cache policies, and the cross-thread store — and every one arrives with defaults. Some are harmless. One is not: the framework's approval gate, measured here, **applies a human's edit to a tool call and destroys the record of what the model actually asked for**, which is invariant 15 broken by the very mechanism you installed to increase oversight. An approval gate that silently rewrites history is worse than no gate, because the transcript reads as consent.

The third reason is that this is where an agent stops being a program and becomes an *operation*. Approval, escalation, retry, and idempotency are not agent techniques; they are the techniques of any system that takes real actions for someone. The case study in §15 is a durable order-processing agent that must never double-charge, and it is a case study rather than a build because the hard part is not the graph, it is the four ways a retry can charge a card twice.

## 4. [core] Learning objectives

You will be able to:

1. **Compose a graph from subgraphs**, saying for any key whether it is shared, private, or needs a translation node — and which of the three the framework does for you.
2. **Suspend a run for human input** with `interrupt()`, resume with `Command(resume=...)`, and predict which lines of the suspended node run twice.
3. **Place an approval gate so it cannot be bypassed**, and demonstrate the bypass that survives even correct placement.
4. **Map every decision type of `HumanInTheLoopMiddleware`** onto Atlas's gate, naming the Atlas policy each would have overridden.
5. **Design an approval prompt** that shows what is being consented to, makes refusal as cheap as approval, and states a measured reason for not asking about a given action.
6. **Distinguish escalation from approval** on three axes, and build a handoff package a human can act on without reading the transcript.
7. **Fan out with a bound you chose**, explaining why the out-of-the-box concurrency bound is a property of your hardware.
8. **Make a node safe to re-run**, deriving an idempotency key that hashes the work, and name what must never be retried, replayed, or cached.
9. **Choose between `Command` and a conditional edge**, stating what `Command` costs Phase 9's topology assertion.
10. **Recover a crashed run** from a checkpoint on a fresh process, and name the state that does not survive.
11. **Audit your own new modules for wiring** before shipping — and this phase is the worked example of what happens when you don't.

## 5. [core] Prerequisites & quick recap

Phase 9 finished and green. If your tree diverged, start again from `atlas_phase_09.zip`.

Carried in: `build_core_graph` (`START → model → decide → tools → model`, Phase 3's seven stop reasons and check *order*, guards after dispatch, `stop_reason` as a channel); `atlas.graph.tools.dispatch` (Atlas dispatches, the framework only describes; `GraphTool` inert by construction; every `ToolMessage` carries its whole `ToolResult` under `additional_kwargs["atlas_tool_result"]`; atomic batches); `run_core` (selects the engine *inside* the component, so no keyword to forget); `atlas.flow.app` (the hand-built front door, which is what gets migrated); persistence via one `SqliteSaver` per `build_handlers`; and **the guards as pure functions of the transcript** — Phase 9's accident and this phase's foundation, because a guard that is a pure function of `messages` survives a suspension, a crash, and a resume in another process.

Two things you may be shaky on:

**Threads and thread pools.** The framework runs one superstep's independent tasks concurrently on a thread pool. You need two consequences: a node body that mutates a module-level object is a race, and a node body that blocks holds a worker. Appendix A §A.7 has the short version. Tests stay deterministic because a fan-out over an ordered fixture list serialises (invariant 38).

**Idempotency.** An operation is idempotent when doing it twice has the same effect as doing it once. Reading a file is; appending a line is not; writing a *specific* line to a *specific* path is again. This is invisible in Phases 0–9 because nothing ever ran twice. From here, nodes run twice routinely — on resume, on retry, on crash recovery — and the gap between "idempotent" and "read-only" is the gap between the two properties invariant 37 keeps separate.

## 6. [core] Core concepts

### 6.1 [core] Subgraphs and state mapping

Atlas has five routes, and they do not merely do different work — they have different *shapes*. `chat` is one model call with no tools. `tool_action` is a ReAct loop. `research` is a plan, a fan-out, and an aggregation. `document` is retrieve-grade-generate with a reformulation and a conditional web fallback. Expressing all five in one flat graph gives you a node set that is the union of five vocabularies and an edge set where most edges are guarded by "am I on the route this edge belongs to". That graph compiles, is unreadable, and — worse — its `path_map` declares a reachable set that is a lie for every individual request.

**Intuition.** A subgraph is a compiled graph used as a node in another graph. The parent does not see inside. It sends state, the child runs its own supersteps to completion, and it returns state. If you have written a function you have the intuition; what you lack is the intuition for *how arguments get passed*, because they are not passed positionally and there is no signature.

**Precise definition.** A compiled `StateGraph` can be given directly to `add_node`. On entry, the framework copies in every key the *child's* schema declares that also exists in the parent's state. On exit it copies back every key the child returned that the *parent's* schema declares, applying the parent's reducer. Keys the child does not declare are invisible to it; keys the child declares and the parent does not are private and vanish.

Three consequences you should be able to state before writing code:

1. **Shared keys are shared by name, not by declaration.** There is no `inputs=` or `outputs=`. A typo in the child's `TypedDict` does not fail — it produces a key the parent never fills and never reads.
2. **The reducer applied on the way up is the parent's.** A child returning `{"messages": [msg]}` gets `add_messages`, an upsert-by-id with deletion. A child returning a message whose id already exists **replaces** it.
3. **Two genuinely different contracts need a translation node**, and that node is ordinary Python. If the parent holds `request: str` and the child wants `question: str`, nothing maps them.

```mermaid
graph TD
    START([START]) --> router[router]
    router -.-> chat[[chat]]
    router -.-> document[[document]]
    router -.-> data[[data]]
    router -.-> research[[research]]
    router -.-> tool_action[[tool_action]]
    chat --> critic[critic]
    document --> critic
    data --> critic
    research --> critic
    tool_action --> critic
    critic --> persist[persist]
    persist --> respond[respond]
    respond --> END([END])
```

Double brackets are subgraphs. Note what the diagram does *not* show: the inside of any of them. `make graph` prints this and each child's topology separately, because a diagram that inlined all five would be the flat graph we just rejected.

**Why the routes are not five identical shims.** Two of the five — `document` and `data` — are already single-entry pipelines with their own internal control flow from Phases 6 and 7. Wrapping those in a one-node subgraph gains no interrupt point, no fan-out, no retry boundary a plain call did not have. Wrapping them anyway and then claiming "Atlas is fully a `StateGraph`" would make four fifths of the claim a shim.

So, stated in exactly these words in §11: `chat`, `document`, and `data` become **single-node subgraphs whose node is a translation shim over the existing pipeline**; `tool_action` and `research` become **real multi-node subgraphs**, because the first needs an interrupt point before every write and the second needs a fan-out — the two capabilities a function call cannot express. They are all subgraphs so the parent's topology is uniform and so §6.7's retry and cache policies have somewhere to attach.

> **Misconception.** *"A subgraph is a function call with extra steps."* It is not, in one way that will bite: **a subgraph has its own recursion budget.** Phase 9 derived `recursion_limit_for(max_steps) == 3 * max_steps + 2` from `SUPERSTEPS_PER_STEP = 3`, counting the *core*'s supersteps. §6.8 measures what happens across a boundary, and the answer is not the one most people guess.

> **Misconception.** *"If parent and child both have `messages`, the child sees the whole conversation."* It sees whatever is in the parent's `messages` when it starts — on a persisted thread, every previous turn. Usually right for `tool_action`, almost never right for `chat`. The fix is not filtering inside the child; it is giving the child a contract that does not declare `messages` at all. **A capability a child does not declare is a capability it cannot misuse** — invariant 20's "a prohibition is an absent tool", applied to state.

**Worked example.** Parent holds `request`, `messages`, `stop_reason`. The `chat` child declares only `request` and `outcome`. On entry it receives `request` and nothing else — no transcript, no stop reason, no path to a tool. On exit it returns `outcome`, which the parent declares. Now: if the child returned `messages`, would that be discarded? **No — it would be accepted**, because the parent declares `messages`. Read that again. The child cannot *read* a key it does not declare, but nothing stops it *writing* one the parent declares. The asymmetry is real; the guard is that the node function is typed against the child's `TypedDict`, so writing an undeclared key is a type error your checker catches and the runtime does not.

**Your turn (5 min).** Take the `data` route. It needs the request and the database path; it produces an answer, the relations read, and a schema fingerprint. Write the *child's* `TypedDict`, then answer: which keys must the parent also declare, and which must it *not*? Justify the "must not" using the asymmetry above.

**Concept check 6.1.a.** A child returns `{"messages": [AIMessage(content="done", id="ai-7")]}` and the parent's transcript already contains id `ai-7`. What does the parent contain afterwards, and which Phase 9 fact makes this answerable without running it?

**Concept check 6.1.b.** You add `escalation` to the parent's schema and forget it in the `tool_action` child's, whose body reads `state.get("escalation")`. What happens at compile time, at run time, and which invariant names the class of defect?

### 6.2 [core] Interrupt and resume: the mechanism

**Intuition.** You want the graph to stop mid-node, hand a question to whoever is driving it, and continue later — possibly much later, possibly in another process. The naive build is a callback: the node calls `ask_human(...)`, which blocks. That works for a CLI and fails for everything else, because a blocked thread is not durable state and a process that dies while blocked has lost the run.

The framework makes the pause a *checkpoint*. `interrupt(value)` raises; the runtime catches it, writes the checkpoint, and surfaces `value` to whoever called `invoke`. The run is now suspended state in a database, not a blocked thread. You resume by invoking again with `Command(resume=answer)`.

**Precise definition.** `interrupt(value)` requires a checkpointer. On its first invocation within a task it raises `GraphInterrupt` carrying `value`. The invocation returns with an `__interrupt__` entry holding an `Interrupt` (a value and an id); afterwards `app.get_state(config)` reports the suspended node in `snapshot.next` and the pending interrupt in `snapshot.interrupts`. `Command(resume=x)` restarts the run; **the suspended node re-executes from its first line**, and this time `interrupt()` returns `x`. Multiple interrupts in one node match resume values by order.

The bold clause is worth measuring rather than reading. Measured this phase, Tier F, no model:

```python
SIDE_EFFECTS = []

def gate(state):
    SIDE_EFFECTS.append("before-interrupt")
    verdict = interrupt({"action": "write_file", "args": {"path": "a.txt"}})
    SIDE_EFFECTS.append("after-interrupt")
    return {"approved": bool(verdict.get("approve"))}
```

After the first `invoke`, `SIDE_EFFECTS == ["before-interrupt"]`. After `invoke(Command(resume={"approve": True}))`:

```
['before-interrupt', 'before-interrupt', 'after-interrupt']
```

**Everything above the `interrupt()` ran twice.** Not "may under some configuration" — did, deterministically, in the simplest possible graph.

> **Misconception, and the most expensive in this phase.** *"`interrupt()` suspends at the line I called it, so the node resumes at the next line."* No. It suspends the *node* and resumes the node, from the top. The framework cannot freeze a Python frame into a database. What it can do is re-run a function and hand a different value to one call inside it. Consequence: **any side effect above an `interrupt()` executes once per resume**, and a node with two interrupts executes its opening twice, then three times. A node that increments a counter, appends to a log, sends an email, or charges a card above its gate has a bug no single-run test can find.

Three rules follow, applied without re-argument for the rest of the phase:

1. **The interrupt goes first.** In a node whose purpose is to ask, `interrupt()` is the first statement, so nothing precedes it and re-execution is free.
2. **Anything that must happen once goes in a different node from anything that interrupts.** The gate asks; the dispatch node acts. Not decomposition for tidiness — the framework's replay unit is the node, so that is the only place the boundary can go.
3. **A node that both interrupts and acts must be idempotent in the acting part** — §6.7's subject and the case study's whole difficulty.

**Worked example — what the driver sees.** Three places, three readers:

| Where | What it holds | Who reads it |
|---|---|---|
| the return value's `__interrupt__` | the `Interrupt` for *this* invocation | the caller that just invoked |
| `snapshot.interrupts` | the pending interrupts on the thread | a process that did not do the invoking |
| `snapshot.next` | the node the thread will re-enter | a human asking "where is this stuck?" |

The middle row is what Phase 14's FastAPI service needs, and why the empty `StateSnapshot.interrupts` was worth pointing at. A pause visible only to the caller who caused it is not a durable pause.

**On resuming with the wrong shape.** `Command(resume=x)` hands `x` to the interrupt whatever `x` is. No schema, no validation. This is what invariant 13 exists for, and this phase applies it: Atlas defines an `ApprovalDecision` model, validates the resume value *inside* the node, and treats a malformed decision as a **refusal** rather than an approval or an exception. Fail closed, and record that it happened.

**Your turn (10 min).** Add a second `interrupt()` after the first. Predict `SIDE_EFFECTS` after (a) the first invoke, (b) one resume, (c) two resumes. Then run it. If (c) was wrong, write down which of the three rules you had not internalised.

**Concept check 6.2.a.** A node calls `interrupt()` and, above the call, writes an audit row recording that approval was requested. The operator approves. How many rows exist, and is the count a bug? Answer for a row keyed by a hash of the pending action, and for one keyed by an autoincrement id.

**Concept check 6.2.b.** Why does `interrupt()` raise rather than return a sentinel the node could check? Ground the answer in what the runtime must do with the node's state, not in API taste.

### 6.3 [core] The approval gate: where it goes, and what the framework's one does

An **approval gate** suspends an episode before an action with consequences and requires a human decision. Atlas has needed one since Phase 3, when `allow_writes` first appeared on `execute()`, and Phase 5 said out loud that reaching the write handler is a *routing* decision while performing the write is an *authority* decision a later phase would own.

**Where the gate goes is the entire design.** Four candidate layers; three are wrong.

```
   model proposes a tool call
        │
   (a)  ├─ gate here: after the model, before dispatch     ← correct
   tools node
   (b)  ├─ gate here: inside dispatch, per call
   execute()
   (c)  ├─ gate here: inside the tool function body
   the side effect
   (d)  └─ gate here: at the filesystem / API boundary
```

Layer (a), and not because it is earliest: **(a) is the only layer where the thing being approved is still a proposal.** At (b) the batch is already committed to as a unit, and invariant 24 says a batch is validated and dispatched as a unit — a gate inside dispatch must either break that atomicity or ask about a batch it cannot partially refuse. At (c) the gate lives in code the tool author wrote, so every new tool is a chance to forget it, and a forgotten gate is an absent gate that reads as protection (invariant 57). At (d) the gate is a filesystem mock, which is a test technique and not an authority model.

Layer (c) is also §8's broken trace. Hold that.

**Now the framework's version.** `HumanInTheLoopMiddleware`'s `after_model` hook inspects the last assistant message's tool calls, interrupts on the ones it is configured for, and applies the human's decisions. Its vocabulary is `approve`, `edit`, `reject`, `respond`, and its payload is a single request carrying one action per gated call. Good design, correct layer. Under invariant 59, that is the beginning of the question: find the line deciding each policy, and either accept it explicitly or wrap it.

Three lines, measured (`docs/RESULTS.md` Phase 10 experiment 1):

**Policy 1 — an unlisted tool is auto-approved.** Its own documentation says so. Defensible for a general component, and default-allow. Atlas's authority model is default-deny for anything not `read_only`: the registry *is* the security model (invariant 20), `allow_writes` defaults to `False` even for `tool_action`, and a state-modifying tool gets `write_refused` unless the episode permits it. A gate configured by allow-list means a tool added in Phase 12 is gated only if someone remembers a line — invariant 58 verbatim. **Atlas derives the gated set from `spec.read_only`**, so a new write tool is gated the moment it is registered, and the allow-list is for *exceptions*, recorded with reasons.

**Policy 2 — the rejection is prose and carries no error kind.** On `reject` the middleware appends a `ToolMessage` with `status="error"` whose content names the tool and reason. Atlas already has a closed `ErrorKind` with four members, one of which is `write_refused` and exists for exactly this — a valid call the episode forbids, phrased so the model reports rather than retries. Phase 9 established that structured data travels as structured data because a renderer's output format is never a parser's input contract (invariant 65). A rejection arriving as prose is one the eval harness must grade by substring.

**Policy 3 — and this changes the design.** On `edit`, the middleware constructs a new tool call with the human's arguments and the *original call's id*, then assigns it onto the assistant message and returns that message. Because `add_messages` is an upsert-by-id, the edit **replaces** the original. Measured:

```
model asked for : write_file(path="report.md", content="DRAFT")
human edited to : write_file(path="report.md", content="APPROVED-TEXT")

final transcript: HumanMessage  "write the report"
                  AIMessage  ai-1  [write_file(path="report.md",
                                               content="APPROVED-TEXT"),
                                    read_file(path="notes.md")]
```

One assistant message, saying the model proposed the approved text. The `DRAFT` it actually proposed is **not in the transcript, not in the checkpoint, and not recoverable** — and every reader Atlas has, from `trajectory_from_state` to `FAILURE_LOG.md` to the eval graders, reads the transcript.

Sit with that. A gate exists for oversight. This one increases the operator's control and *decreases* the record of what was overseen. An auditor reading the thread sees a model that proposed exactly what a human approved — the one conclusion the evidence cannot support. Invariant 15 has said since Phase 1 that repairs, retries, and cache hits are recorded and never hidden, because a silent retry loop is an evidence bug. **An edit is a repair performed by a human.**

So Atlas keeps the mechanism and inverts the record. **The proposal is immutable; the decision is a separate, additive record.** The model's message is never edited. A human's edit produces a *new* assistant message with a *new* id whose `additional_kwargs["atlas_authored_by"] = "human"`, plus an `ApprovalRecord` — appended to its own channel with an `operator.add` reducer — carrying the original arguments, the final arguments, the decision, the reason, and the operator. The transcript then answers both questions a reader can ask: what did the model want, and what was allowed.

| Framework decision | What it does | Atlas's gate | Policy overridden |
|---|---|---|---|
| *(no entry)* | auto-approve | **gated** if `not spec.read_only`; allow-list for exceptions, with reasons | default-allow → default-deny (inv. 20, 58) |
| `approve` | proceeds unchanged | same, plus an `ApprovalRecord` | none; the record is added |
| `edit` | new args, **same message id** | new message, new id, `authored_by="human"`; original preserved | destructive edit → additive record (inv. 15) |
| `reject` | prose `ToolMessage`, `status="error"` | `ToolResult(ok=False, error_kind="write_refused")`, structured under `atlas_tool_result` | untyped error → closed `ErrorKind` (inv. 65) |
| `respond` | human answers *as* the tool, `status="success"` | **not adopted** — see below | — |
| malformed resume | `ValueError` from the middleware | treated as **refusal**, recorded | exception → fail closed (inv. 13) |

**Why `respond` is not adopted.** It lets a human supply the tool's output, marked successful, without the tool running. Every downstream mechanism then treats a human's sentence as an observation: `seen_observations` deduplicates against it, `no_progress` compares signatures against a call that never happened, the data route's `relations_read` provenance is absent from an answer that claims a source, and invariant 42's chain has nothing to travel. A human answering for a tool is a legitimate product feature and is not a *tool result*; it is a human turn. Phase 12 gives it an explicit role, and the reason is written down (D-52) so nobody re-derives it.

> **Misconception.** *"A gate at layer (a) covers everything, because every tool call goes through the model."* Every tool call *the model makes* does. A write performed by a pipeline the handler calls directly — a cache entry, a memory commit, a script the code tool runs — never appears as a tool call and is never seen. That is §8's trace, and the general form is invariant 41's: the gate was wired, tested, and covered a smaller set than its name implied.

**Concept check 6.3.a.** The framework's gate interrupts on `write_file` and auto-approves `read_file` in the same batch. Name two things the operator cannot see in the payload, and which invariant each omission touches.

**Concept check 6.3.b.** Atlas derives its gated set from `spec.read_only` rather than a configured list. Give the failure mode this prevents, and then the one it *introduces* — there is one, and naming it is the point.

### 6.4 [core] Approval UX: what to show, making refusal cheap, and approval fatigue

A gate is a mechanism. Whether it produces oversight is a question about a human, and it is answerable — badly — by anyone who has clicked "Allow" without reading.

**The failure mode has a name.** *Approval fatigue*: when the rate of requests exceeds the rate at which a human can meaningfully evaluate them, evaluation is replaced by a reflex. The result is worse than no gate, and precisely so: a rubber-stamped approval **transfers accountability without transferring scrutiny**. Before the gate, an incorrect write was a system failure. After it, the same write is an operator's decision, recorded with their identity, in a log saying they consented. The gate has manufactured evidence of oversight that did not occur — the same shape as Policy 3, one layer up.

The design target is therefore not "ask about everything risky". It is **maximise the fraction of requests that receive real attention**, which usually means asking about fewer things.

**Rule 1 — show the effect, not the call.** `write_file(path="q3/report.md", content="…4kB…")` is a serialisation of a function call. The operator needs the sentence they are consenting to: *"Overwrite `q3/report.md` with 4.1 kB of new content; prior contents are not recoverable."* The difference is the word *overwrite*, a fact about the world the arguments do not carry. A gate that renders arguments makes the operator do the inference; one that renders consequences does it for them and is auditable when it gets it wrong. Where the consequence cannot be computed, say so — and §8 is what happens when "say so" is where it stops.

**Rule 2 — refusal must be exactly as cheap as approval, and never quieter.** If approving is one keystroke and refusing requires typing a reason, you have priced refusal above approval and the price is paid in approvals. Atlas makes the reason optional and *records its absence* as `reason=None`, because a mandatory field produces the string `"n/a"` and a mandatory field is how you learn that. Refusal must also not be a dead end: `write_refused` is phrased so the model reports what it could not do, so a refusal yields a usable answer rather than a stalled episode. An operator who has learned that refusing kills the run is an operator who approves.

**Rule 3 — every non-ask is a decision with a stated reason.** The set Atlas does *not* ask about is a policy and lives in code with a comment per entry, not in the absence of a configuration line. `make policy` prints both halves:

```
approval policy:
  exempt calculate            — read_only
  exempt current_time         — read_only
  exempt list_files           — read_only
  exempt read_file            — read_only
  GATED  write_file           (IRREVERSIBLE)
```

A reader who sees only the gated set cannot tell a considered exemption from a forgotten tool. This is invariant 30's shape applied to a policy rather than a literal.

**Rule 4 — batch what a human would evaluate together, and never batch what they would not.** The framework gets this half right: one interrupt carrying all gated calls from a turn, which is correct — an operator evaluating "write these three files" once does better work than approving three dialogs. What it does not do is separate by consequence. Atlas groups by *reversibility*, so a batch containing one irreversible action presents that action first, labelled.

**The measurement.** Phase 3's F-03-06 and Phase 9's experiment 2 both turned on `[write_note("IRREVERSIBLE"), phantom()]`. Add a gate at layer (a) and ask whether it saves you. It does not, and the reason is arithmetic. If the gate fires on every write and 90% of an episode's writes are routine, then in a hundred episodes the operator sees ninety that should be approved and ten that should not, and the ten arrive with the same weight as the ninety. `make results` measures the approval *rate* per route for exactly this reason: **the rate is the design parameter, and a gate whose rate you have not measured is a gate whose fatigue you have not measured.** Author estimate, unmeasured: `tool_action` asks on 60–90% of episodes, `research` on 0% (it is read-only by construction — see §7.5).

> **Misconception.** *"Approval fatigue is a training problem — the operator should read more carefully."* It is a rate problem. The variable you control is the request rate, not the operator's diligence.

**Your turn (10 min).** Take Atlas's tools plus `remember` and `run_python`. For each, one line: gated or exempt, and why. For the gated ones, write the Rule 1 consequence sentence. Keep it — §7.4's `CONSEQUENCE_RENDERERS` is graded against it.

**Concept check 6.4.a.** An operator approves 47 write requests and refuses none. Give two hypotheses consistent with that observation that call for *opposite* changes, and the measurement that distinguishes them.

**Concept check 6.4.b.** Atlas records `reason=None` on an unexplained refusal rather than requiring a reason. What is gained, and whose reasoning does this follow?

### 6.5 [core] Escalation: what it is, and why it is not approval

Approval and escalation both stop an agent and involve a human, which is why they get conflated — and conflating them builds a system that asks permission when it should ask for help. Three axes separate them.

**Who holds the decision.** In approval, Atlas has decided *what to do* and needs authority. The proposal is Atlas's; the permission is the human's. In escalation, Atlas does not know what to do; the question is the human's to answer and Atlas proposes nothing.

**What the agent is admitting.** Approval admits nothing — asking before a write is working correctly. Escalation admits a limit: *I cannot finish this.* That changes what the human must be given: an approval needs one sentence about consequences, an escalation needs everything the human would otherwise reconstruct.

**What the resume path looks like.** Approval resumes with a decision from a three-member closed set. Escalation resumes with *content* — a fact, an authorisation, a corrected assumption — which is unbounded, arrives on a human timescale, and may never arrive. That is why escalation is a suspension rather than a termination: a discarded escalated run threw away established facts, and the human now repeats work Atlas already paid for.

**Detecting out-of-depth.** The temptation is to ask the model. Do not: invariant 44 says abstention is computed by code from the evidence, never granted by the model, and no model-facing schema in Atlas carries `sufficient`, `grounded`, or `confidence`. Escalation is the same decision one level up, computed the same way:

| `EscalationReason` | Computed from | Why this is the boundary |
|---|---|---|
| `no_progress_exhausted` | `stop_reason` in `{no_progress, cycle, step_cap, token_budget}` | The episode ended on a guard, not an answer. Four of Phase 3's seven stop reasons *are* the detector. |
| `authority_missing` | any `ToolResult` with `error_kind == "write_refused"` | The work needed a permission the episode did not hold. This is why `write_refused` earned a closed-set member. |
| `evidence_insufficient` | the document route abstained **and** the data route abstained | One abstention is a routing miss; two is an evidence problem. |

Every row is a pure function of a record Atlas already writes. Nothing new is measured, nothing is asked of a model, each member has one line that sets it (invariant 30).

**Choosing the moment.** Escalate on the *first* reason that fires. The instinct to try everything first is expensive in the wrong currency: a run that spends its full budget before escalating has burned model calls to produce a *worse* handoff package, because the transcript is now long enough that the human reads it instead of the package. `authority_missing` escalates immediately — retrying a forbidden write cannot succeed, and `write_refused` already tells the model to report rather than retry.

**Packaging context.** The constraint is that **a human should be able to act without reading the transcript.** `HandoffPackage` has four content fields and the ordering is the design: `established` first, because a human who reads three confirmed facts does not redo the work that produced them; `attempted` second, so they do not retry a dead end; `blocking_question` third and *singular*, because a handoff with three questions gets one answered; `thread_id` last, because that field makes it a suspension.

```
ESCALATION (authority_missing) on route tool_action
  request: raise the PO limit
  established:
    - query_db: limit is 5000
  tried:
    - write_file -> write_refused: nope
  NEEDS FROM YOU: Atlas needs permission to perform a write it is not
                  authorised for. Grant it for this action, or tell Atlas
                  what to do instead.
  resume: thread tool_action:u1
```

`actionable` returns `False` when `blocking_question` is empty — deliberate, and invariant 57's shape: a package with no question is a complaint, and a mechanism that cannot tell a handoff from a complaint will ship complaints.

> **Misconception.** *"Escalation is what you do when approval is refused."* A refusal is a completed decision — the operator said no, and `write_refused` tells the model to report. That is a successful episode with a negative outcome. Escalation is for when nobody has decided anything because Atlas cannot frame the decision.

**Concept check 6.5.a.** Atlas escalates with four facts in `established`. Name the reader that must exist in the same commit, and the invariant requiring it.

**Concept check 6.5.b.** Why is `authority_missing` detected from a `ToolResult.error_kind` rather than a `stop_reason`? Consider what happens when the model receives `write_refused` and answers anyway.

### 6.6 [core] Dynamic fan-out with bounded concurrency

Phase 5 built a fan-out with a `worker_limit`. The framework's version is `Send`.

A node's return value is normally a state update. If instead it returns a list of `Send(node_name, payload)`, the runtime schedules one task per `Send`, each executing `node_name` against *that payload* rather than the graph state. The count is decided at runtime — a four-step plan fans out to four workers, and nothing in the topology knew the number. Results come back through the target key's reducer, so aggregation is `Annotated[list[...], operator.add]` and there is no join node to write.

**Measurement one: order.** Eight workers, deliberately staggered sleeps, slowest first, so completion order reversed argument order:

```
items  = [0.30, 0.25, 0.20, 0.15, 0.10, 0.05, 0.01, 0.01]   # seconds
result = [0, 1, 2, 3, 4, 5, 6, 7]                            # argument order
```

The reducer applies in **task order, not completion order.** A genuine gift: invariant 35 requires one record per branch in argument order, and Phase 5 had to sort. Here it falls out, and invariant 38 holds without effort — a fan-out over an ordered fixture list is deterministic, so the tests stay tests.

**Measurement two: the bound, and this is not a gift.** With no configuration, eight tasks ran at most **five** concurrent. Five is not a considered number: `os.cpu_count()` on the authoring box is 1, and `ThreadPoolExecutor`'s default `max_workers` is `min(32, cpu_count + 4)` — also 5. The framework's concurrency bound is **a property of your hardware**, and it moves when you deploy.

Hold that against what the bound is *for*. Atlas's `worker_limit` exists because a free hosted tier has a requests-per-minute ceiling and a laptop running Ollama has one model loaded. Neither has anything to do with the core count of the machine scheduling the work. A fan-out tuned on a 1-vCPU laptop and deployed to a 16-core box issues 20 concurrent requests against a limit sized for 3, and the symptom is 429s attributed to the provider.

The fix is one config key, measured: with `max_concurrency=2`, peak concurrency was 2 and order was still `[0..7]`. So Atlas passes `worker_limit` — the number Phase 5 already chose for the reason Phase 5 already wrote down — and does not inherit the host's.

> **Misconception.** *"`max_concurrency` unset means unbounded."* It means *host-derived*, which is worse than unbounded because it looks stable. An unbounded fan-out fails loudly on the first large plan; a host-derived one passes every test on your laptop and changes behaviour on deploy with no diff.

**Your turn (5 min).** Atlas's research route caps at `worker_limit=3`. Write the one-sentence justification you would put beside `max_concurrency`. It must name what the 3 protects — and "the CPU" is the wrong answer.

**Concept check 6.6.a.** A fan-out returns argument order even under concurrency. Which invariant does this satisfy for free, and which part of that invariant does `Send` still *not* give you?

### 6.7 [core] Durable execution: crashes, idempotency, retries, and node caching

**What durable execution means.** A checkpointed run can be resumed after the process holding it dies. Attractive and imprecise, and the imprecision is where the bugs live. The precise questions: *when* is a checkpoint written, *which* node re-executes on resume, and *what* does re-execution do twice.

**Measurement: the crash.** A three-node chain over a real `SqliteSaver`, killed with `os._exit(9)` inside node `b` — no unwinding, no `atexit`, the closest thing to a power cut — then inspected from a *fresh* process. Everything depends on one keyword:

| `durability` | State after the crash | Resumable? |
|---|---|---|
| `"async"` *(default)* | `next=()`, `log=[]` — node `a`'s work **lost** | yes, but re-runs from the start |
| `"sync"` | `next=('b',)`, `log=['a']` — node `a`'s work **survived** | yes, resumes at `b` |
| `"exit"` | `values={}` — nothing at all | **no**: `EmptyInputError` |

Read the first row again. Under the default, a hard crash lost a completed superstep and the thread afterwards reported `next=()` — which is what a *successfully finished* run looks like. Under `"exit"` the run is unrecoverable. Only `"sync"` gives the property the phrase describes.

**Crash-safety is a keyword, and its default is not the safe value.** Invariant 58 verbatim, and invariant 59's line-of-code exercise with an answer that costs latency. Atlas passes `durability="sync"` from inside `run_atlas_graph`, and the interface file records the cost: a synchronous write per superstep.

**Measurement: what re-executes.** With `"sync"`, counting real side effects by appending to a file:

```
after the crash : a-ran, b-ran
after resume    : a-ran, b-ran, b-ran
```

Node `a` ran **once**: its output was checkpointed, and resume replayed the value instead of the function. Node `b` ran **twice**. The rule is exact:

> **Resume re-executes precisely the node that was in flight, and replays every node that had already committed.**

So a node that performs its side effect and dies before its checkpoint lands **performs that side effect again.** Combine with §6.2's finding, and one rule covers both: **a node body runs an unbounded number of times; only its committed output runs once.**

**Idempotent nodes.** A node is safe to re-run when re-running has the same effect as running once. Atlas already has the tool, from Phase 4: invariant 37 says an idempotency key **hashes the work, not the attempt** — no run id, no attempt number, handler version included. That invariant was written for a retry loop and is exactly what crash-resume needs, for the same reason: a key containing the attempt number produces a different key per attempt, so every retry is fresh work and the mechanism protects nothing.

Invariant 37's second half is the harder one and this phase enforces it: **a step whose tool is not `read_only` is never auto-retried, replayed, or cached.** Cacheability is declared beside `read_only`, because read-only and deterministic are different properties. Hence Atlas's policy: retry and cache attach to read-only routes only, and `tool_action` gets neither.

**Retry policies.** `RetryPolicy` attaches per node with `max_attempts`, an interval and backoff factor, jitter, and `retry_on`. Its default predicate decides for you, so know it precisely: measured, `default_retry_on(ConnectionError(...)) is True` and `default_retry_on(ValueError(...)) is False`. A good default — transport faults retry, programming errors do not — and nearly Atlas's own `is_retryable_status`. The mismatch is that Atlas's exception vocabulary is more specific than a generic predicate can know: `LLMTransportError` retries, `LLMBadRequestError` must not, `OutputTruncated` must not (raise `max_tokens`, do **not** repair). Each name encodes its remedy, so Atlas supplies an explicit `retry_on` naming its own exceptions:

```python
# excerpt: atlas/graph/subgraphs.py
ATLAS_RETRY = RetryPolicy(
    max_attempts=3,
    initial_interval=0.5,
    backoff_factor=2.0,
    max_interval=8.0,
    retry_on=(LLMTransportError, ConnectionError, TimeoutError),
)
```

Note what is *absent*: `LLMBadRequestError` and `OutputTruncated`. That absence **is** the mechanism. An earlier draft also declared a `_NEVER_RETRY` tuple listing them, which nothing read — a constant that documents an omission is not the omission, it is invariant 41's accounting field with a comment. Deleted (F-10-07).

**Node caching.** `CachePolicy` plus a cache on `compile()` memoises a node against its input. Measured: two invocations with identical input state ran the body once; a third with different input ran it again. The key derives from the node's **whole input state** by default, with a consequence to design around — a node whose input carries a request id, a timestamp, or a freshly-assembled context can never hit. Not a flaw; the reason `key_func` exists. But a node cache installed without choosing a key is a mechanism that reads zero hits forever, and a green suite will not tell you (invariant 41).

> **Misconception.** *"Checkpointing makes my agent crash-safe."* It makes your agent *resumable*. Crash-*safe* additionally requires that resuming does no harm, which is a property of your node bodies. And the default durability mode is not even resumable-without-loss.

**Concept check 6.7.a.** A node sends an email and then returns `{"sent": True}`. The process is killed between the send and the checkpoint. How many emails does the recipient get, and which durability mode changes the answer?

**Concept check 6.7.b.** Atlas declines the framework's default `retry_on` even though they agree about `ConnectionError` and `ValueError`. Name the Atlas exception the default classifies wrongly, and in which direction.

### 6.8 [core] `Command` versus conditional edges, config, and recursion limits

**Two ways to move.** A conditional edge separates the decision from the transition: a routing function returns a label, and a `path_map` turns labels into destinations. `Command(goto=..., update=...)` fuses them.

`Command` is more expressive — the only way to update state and jump in one step, the only way for a subgraph node to direct the *parent* (`Command(graph=Command.PARENT, ...)`), and it composes with `Send`. It is also, measured, the thing that breaks Phase 9's oracle. Invariant 62 says wiring is graded from its own serialisation, so `END`-reachability is asserted against `draw_mermaid()`. Here is a two-node graph where `a` returns `Command(goto="b")`:

```
graph TD;
	__start__ --> a;
	a --> __end__;          ← a LIE. `a` goes to `b`.
```

The diagram claims `a` terminates, and `b` is drawn as an orphan. Declaring the destination fixes it:

```python
graph.add_node("a", a, destinations=("b",))
```
```
	a -.-> b;               ← correct, and dashed to mark it dynamic
```

The trade is explicit: **`Command` moves a topology fact from the graph definition into a node body, where the serialiser cannot see it, and `destinations=` is optional.** An assertion reading `draw_mermaid()` therefore passes against a wrong diagram — invariant 62's failure mode turned on invariant 62. Atlas's rule: a conditional edge wherever one suffices; `Command` only where it is the only mechanism, and never without `destinations=`.

**Runtime config** carries three distinct things, worth keeping apart. `configurable` holds values your nodes may read — `thread_id`, and from §6.9 the user's namespace. `recursion_limit` and `max_concurrency` are runtime fuses, not application data. `durability` is a keyword on `invoke`, not a config key. Only the first is yours; Atlas sets all of them explicitly at one entry point.

**Recursion limits across a subgraph boundary.** Phase 9 derived `3 * max_steps + 2` counting the core's supersteps, and the core is now a child. Divided between levels, or inherited by each? Measured, with two graphs of deliberately opposite shape:

```
long parent (11 supersteps) / short child ( 2)  -> minimum workable limit = 12
short parent ( 3 supersteps) / long  child (10)  -> minimum workable limit = 11
```

Neither is the sum. In each case the minimum is `deepest_level_supersteps + 1`. The limit is **inherited, not divided**: the same value propagates into every subgraph and each Pregel level checks it against its own count independently. The binding constraint is `max(parent_supersteps, worst_child_supersteps) + 1`.

Good news for Phase 9's formula — it survives, because the child needs `3 * max_steps + 2` and the parent needs only five supersteps (`router`, one subgraph, `critic`, `persist`, `respond`), which fits under the same number for any `max_steps ≥ 1`. But it survives **by accident of the parent being shallow**, and a fuse that holds by accident is a fuse of unknown rating, so §7 pins it with a test.

The gated arm adds a fourth superstep per step, and it gets its **own function** rather than a keyword:

```python
# excerpt: atlas/graph/core.py
GATED_SUPERSTEPS_PER_STEP = 4
```

Why a separate name matters is a defect this phase shipped and reverted. Adding `gated: bool = False` to `recursion_limit_for` changed its signature, which the Phase 9 document pins as an excerpt — so `make check-docs` failed (invariant 8) while every unit test stayed green, because a widened signature is invisible to callers and visible to the documentation contract. **"Additions are free, changes are not" applies to a signature the same way it applies to an interface** (F-10-06).

**Concept check 6.8.a.** You replace a conditional edge with `Command(goto=...)` and forget `destinations=`. The suite stays green and `make graph` still prints a diagram. What has silently stopped being true, and which invariant?

**Concept check 6.8.b.** Given inheritance, what happens to the fuse if a future phase nests a subgraph inside a subgraph, each needing `3 * max_steps + 2`? Answer with the formula.

### 6.9 [core] The cross-thread store

A checkpointer is scoped to a thread. Everything Phase 9 persisted was per-conversation — correct for a transcript, wrong for a memory, since Phase 8's whole point was that a fact learned in one session is available in the next. The framework's answer is a **store**, passed to `compile(store=...)`, reachable from any node, and namespaced rather than threaded.

The API is small: `put(namespace, key, value)`, `get`, `search(namespace_prefix, *, filter=, limit=)`, `list_namespaces()`. Namespaces are tuples, so `("atlas", "memories", user_id)` gives per-user isolation by construction, and a value written on thread `a` is readable on thread `b`.

Now the invariant-59 exercise, with a sharp answer. `search` accepts `query=`. Called with `query="item 2"` against three items:

```
[('k0', None), ('k1', None), ('k2', None)]     # insertion order, score=None
```

**No error, no ranking, everything returned.** Without a configured index, semantic search degrades silently to "return the namespace". A mechanism that reads as retrieval and performs none is invariant 57's shape: a gate that cannot fire is worse than an absent one because it reads as protection — and a search that cannot rank is worse than an absent one because it reads as relevance.

So Atlas's policy is stated, not defaulted: **the store is a persistence mechanism, not a retrieval mechanism.** Phase 8's `MemoryStore` already owns retrieval — a recency/relevance/importance blend, min-max normalised per query, filtering user and scope in the SQL, with a documented refusal to expose any `score_floor`. None of that moves. What moves in is what the store is genuinely better at: durable, namespaced, cross-thread key-value persistence reached from inside a node without threading a connection through every call site.

**And this is where the first version of this section was a lie.** It described the store as holding "the approval history, handoff packages, the session profile" — and `grep -rn "store=" atlas/` returned nothing. Invariant 53's exact shape: a prose claim about wiring is worth exactly as much as the test that reaches it through the composition, and the careful argument above became cover for not integrating the store at all. §7.6 builds the `persist` node that makes the sentence true, and §11 lists it as F-10-09 rather than quietly fixing it. Two persistence layers is a cost, and the reason is written down: one of them can rank.

> **Misconception.** *"The store replaces `atlas.memory.store`."* It replaces the *connection plumbing*. It cannot replace the scoring, the dedup floor, the staleness windows, the redaction-before-insertion, or the content-addressed `memory_id`.

**Concept check 6.9.a.** Atlas namespaces store entries as `("atlas", "approvals", user_id)`. Which Phase 8 mechanism does this make redundant, and which does it *not*, even though it looks like it should?

### 6.10 [core] Deferred to Appendix F.4

**Time travel.** Because every superstep writes a checkpoint, the runtime holds a thread's complete history, and `get_state_history` returns it. Passing an older checkpoint's id back in `configurable` re-enters the graph at that point; combining that with `update_state` lets you rewrite a value and run *forward from the past*, producing an alternative trajectory that branches off the original. A genuinely powerful debugging tool — "what would this run have done if retrieval had returned the right chunk?" becomes answerable rather than arguable — and a full mechanism with its own failure modes: a fork is a new thread lineage, side effects on the original branch are not undone by forking away from them, and an "alternative trajectory" whose tool results came from the original branch is a trajectory nobody ran. **Appendix F.4a** builds it on a branch off `phase-10`, with the fork-safety rules and a `make timetravel` target. Do not build it here; the concept is what Phase 10 needs, because it is what makes §6.7's replay comprehensible.

**Map-reduce over documents.** `Send` generalises to a document analyser: fan out one worker per document, summarise each, reduce into an answer. The canonical shape, and tempting because §6.6 has the primitive. Deferred for an Atlas-specific reason: a per-document map step discards the cross-document ranking Phase 6's hybrid retrieval exists to produce, and the reduce step is a summariser, which Phase 8 measured as destroying 6 of 6 pinned constraints without protection. Doing it correctly means re-deriving abstention and citation provenance for a pipeline where every chunk arrives from a different worker — a phase's work, not a section's. **Appendix F.4b**, on a branch off `phase-10`.

### 6.11 [core] Forward pointer: an MCP tool that asks a question

In Phase 12 Atlas both exposes and consumes MCP servers, and one capability interacts directly with this phase: a server can ask the *user* a question mid-tool-call — a multi round-trip request, where the tool suspends, the client collects an answer, and the call resumes. Structurally identical to §6.2's interrupt, one process boundary further out, and the natural implementation turns the server's question into a LangGraph `interrupt()`. The framework's first-party adapter for that translation is **pre-release as of writing** (`VERSIONS.md` row, with its stage and source), so it does not appear in Atlas's code. Phase 12 wires it by hand — four lines, with the incidental benefit of making the seam visible: the resume value crossing that boundary is untrusted input from a third-party server, which is why Atlas has an `ApprovalDecision` model rather than a dict.

### 6.12 [extended] Studio and platform tooling

The framework ships a visual debugger and a hosted platform. Both are useful and both are strictly optional here, for the reason Phase 9 gave about the tracing product: a separate, commercial, hosted tool cannot sit on the default path of a book whose constraint is $0 and offline.

The local alternative is what Atlas has, and it is not a downgrade in every dimension. `make graph` exports both topologies as Mermaid, generated rather than hand-drawn. `make trace TASK=...` prints one trajectory through the same dispatch the grader uses (invariant 54). `stream_mode="updates"` prints each node's state delta as it happens — a debugger you can pipe. `get_state_history` is the data a time-travel UI renders; the record exists locally whether or not anything draws it. What hosted tooling adds is a rendered timeline and click-to-fork; what it costs is an account, a network dependency, and your traces on someone else's machine. If you have the account, use it. Nothing here requires it, and every capability it visualises is asserted by a test.

## 7. [core] Hands-on: build it step by step

Seven steps, in dependency order. Work in the tree from `atlas_phase_09.zip`, and confirm `make test-offline` is green before touching anything — a migration whose starting point you have not verified has no oracle.

### 7.1 The parent state contract

The migration needs a schema before a graph, because §6.1's rule makes the parent's schema the vocabulary every child draws from: a key added here is a key some child may now read.

Create `atlas/graph/state.py`. Four decisions worth arguing.

**`request` is a channel, separate from `messages`.** Looks redundant — the request is the last human message. It is separate so a child needing only the question can declare `request` and *not* `messages`, and therefore cannot see the transcript. `chat` is exactly that case.

**`outcome` is a `dict`, not a `HandlerOutcome`.** Channels are serialised into checkpoints, and a Pydantic model round-tripping through a checkpointer written by a different version of your code is a compatibility problem Atlas does not need. Invariant 31 already guarantees `model_dump()` round-trips, so the dump crosses the boundary and validation happens on the far side.

**`approvals` has an `operator.add` reducer; the other new channels have none.** Appending is right for an audit trail and wrong for everything else. `pending` is a single slot because the gate emits one interrupt per turn (§6.4 rule 4), and a channel with no reducer is last-write-wins with a single writer per superstep — enforced by the runtime raising rather than merging.

**Every run-scoped channel is reset at the entry point, by name.** Invariant 61. A function, not a literal, so there is one place to add a channel and a test can assert coverage:

```python
# excerpt: atlas/graph/state.py
_RUN_SCOPED: tuple[str, ...] = ("route", "stop_reason", "outcome", "pending", "handoff")


def reset_run_channels() -> dict[str, Any]:
    """The explicit reset applied on every invocation of the parent graph.
    return {name: None for name in _RUN_SCOPED}
```

`approvals` is deliberately absent: it is thread-scoped *on purpose*, because the approval history of a conversation is the audit trail, and resetting it per run produces a record that forgets what it recorded.

The same reasoning applies one level down, and Phase 9 did it for one channel only. `CoreState` gained `pending` this phase and it was **not** reset — benign only because `tools_node` happens to clear it, and "benign because another node clears it" is not a guarantee. So the core gets the same treatment:

```python
# excerpt: atlas/graph/core.py
CORE_RUN_SCOPED: tuple[str, ...] = ("stop_reason", "pending")


def reset_core_run_channels() -> dict[str, Any]:
    """The reset applied on every invocation of the core graph."""
    return {name: None for name in CORE_RUN_SCOPED}
```

### 7.2 The records, and a defect found while writing them

`ApprovalDecision`, `PendingAction`, `ApprovalRecord`, and `HandoffPackage` go in the same file. Two things happened while writing them that are worth more than the code.

**`ApprovalDecision` is the validator, and a malformed decision is a refusal.** `Command(resume=x)` performs no validation, so invariant 13 applies: one Pydantic class per output shape, serving as both the decoding constraint and the validator, checked *inside* the node. An unreadable payload becomes an `ApprovalRecord` with `decision="reject"` and `malformed=True` — a separate boolean rather than a fourth decision kind, because "the operator refused" and "the operator's message was unreadable" are different facts about the world.

**The defect (F-10-01).** I gave `ApprovalRecord` `extra="forbid"` out of habit and a `computed_field` named `edited`, then wrote the round-trip test the repo has required since Phase 4:

```
ValidationError: 1 validation error for ApprovalRecord
edited
  Extra inputs are not permitted [input_value=True, input_type=bool]
```

A `computed_field` is emitted by `model_dump()`, and `extra="forbid"` then rejects the record's own output. Invariant 31 says this in advance and in these words: `forbid` is for schemas the **model** fills; a record the **harness** writes must accept its own dump. `ApprovalDecision` keeps `forbid` — an operator's payload is external input with no computed field; `ApprovalRecord` and `HandoffPackage` do not.

Verify the round-trip *and an absolute assertion beside it* (invariant 60):

```python
assert ApprovalRecord.model_validate(r.model_dump()) == r          # comparison
assert r.model_dump()["proposed_arguments"] == {"content": "DRAFT"}  # absolute
```

The second line is not redundant. A round-trip passes if both sides are equally wrong.

### 7.3 The five route subgraphs

Create `atlas/graph/subgraphs.py`. The design is §6.1's rule turned into five `TypedDict`s, and the honest part is which are real. The `chat` child's contract is the one to study, because it is a security boundary:

```python
# excerpt: atlas/graph/subgraphs.py
class ChatState(TypedDict, total=False):
    """No `messages` key, on purpose. The child cannot read the transcript."""

    request: str
    outcome: dict[str, Any] | None
```

Phase 5 gave `chat` no tools because a conversational answer that reached for the database was misrouted, and taking the capability away makes that visible instead of plausible. §6.1 lets Atlas do the same to *state*.

`tool_action` does **not** rebuild the core. `build_core_graph` already owns the check order, the seven stop reasons, the atomic batch, and now the gate; a second implementation is F-08-02 waiting to happen. The subgraph is three nodes around it — `enter` seeds the system turn on the first turn only, `core` is the Phase 9 graph, `leave` rebuilds the trajectory through Phase 9's adapter.

And it gets **no** `retry_policy` and **no** `cache_policy`. The omission is the point: *a retry policy on a node that can call `write_file` is a policy that writes the file twice.* The constant encoding this is asserted:

```python
# excerpt: atlas/graph/subgraphs.py
READ_ONLY_ROUTES: frozenset[Route] = frozenset({"chat", "document", "data"})
```

With the `chat` shim, note where the cache key comes from: `CachePolicy` keys off the node's whole input state, and this child's entire input is `request`. That is why the shim earns its keep — the *parent's* state carries a request id and an assembled context, and a cache keyed on that could never hit.

**Your turn (10 min).** `document` gets a cache policy and `tool_action` does not. Now consider `research`: its scoped registry has no write tool, yet it is absent from `READ_ONLY_ROUTES`. Write the one-sentence justification. Hint: invariant 37 distinguishes two properties, and only one is about writing.

### 7.4 The approval gate, derived rather than configured

`atlas/graph/approval.py`, then a change to `atlas/graph/core.py`.

The gated set is **derived**: `needs_approval(spec)` reads `spec.read_only`, so a write tool registered in Phase 12 is gated the moment it is registered. `EXEMPT` is a dict of tool name to *justification*, empty at the end of this phase — the honest state, since every write Atlas has is one an operator should see. It exists because the next phase will want an entry, and an exemption mechanism introduced under time pressure is one with no reason field.

The gate node's body is one rule made structural: **`request_decisions` is its first statement.** `consequence_for` deliberately does not `stat()` the path — a node body that touches the filesystem to render a prompt touches it once per resume, and the answer would be stale by the time the operator read it.

The renderers are a **table, and the table is the completeness check**:

```python
# excerpt: atlas/graph/approval.py
CONSEQUENCE_RENDERERS: dict[str, Any] = {
    "write_file": _write_file_consequence,
    "remember": _remember_consequence,
    "run_python": _run_python_consequence,
}
```

A gated tool absent from it cannot be described, so it cannot be approved, so `build_core_graph` **refuses to compile** (D-57). The earlier version fell through to "target state unknown: the arguments are shown verbatim" — an honest sentence, printed into an approval prompt, read past. §8 is that trace. Invariant 49 is about a *signal* wired to no decision; a *hole* wired to no refusal is invariant 57's dead gate.

Now the topology change, and the interesting part is where the guard lives. The gate is derived from three facts already present:

```python
# excerpt: atlas/graph/core.py
    gate_required = bool(allow_writes and gated_specs(registry) and checkpointer)
```

I first put the wiring guard here — *raise if writes are allowed and there is no checkpointer* — and it broke Phase 9's eight equivalence fixtures. **It was right to break them.** Phase 3's engine has no gate, so the faithful comparison is against the *ungated* graph, and the gate gets its own tests (invariant 60). The guard belongs one layer up, in `build_atlas_graph`, because *granting write authority* is that layer's decision:

```python
# excerpt: atlas/graph/app.py
    if allow_writes and checkpointer is None:
        raise ValueError(
            "allow_writes=True requires a checkpointer: the approval gate "
            "suspends the run with interrupt(), which has nowhere to persist "
            "the pause without one. Pass checkpointer=, or leave writes off."
        )
```

Note also what the derivation buys: when `allow_writes` is False the write is refused anyway, so gating it would ask an operator to approve something that cannot happen — approval fatigue manufactured by the gate itself.

Refusal reaches dispatch as a *position*, not a skip. Refused indices travel in `pending`, and `tools_node` dispatches that call with writes disabled, so it returns Atlas's own `write_refused` — a closed `ErrorKind` with a message written for the model, structured under `atlas_tool_result`.

**Measured, all five paths, against the real filesystem:**

```
APPROVE  stop=final  dec=approve malformed=False  files=['r.md']  (5 chars, DRAFT)
EDIT     stop=final  dec=edit    malformed=False  files=['r.md']  (8 chars, APPROVED)
REJECT   stop=final  dec=reject  malformed=False  files=[]        ERROR (write_refused)
GARBAGE  stop=final  dec=reject  malformed=True   files=[]        ERROR (write_refused)
EMPTYED  stop=final  dec=reject  malformed=True   files=[]        ERROR (write_refused)
```

The last two rows are the fail-closed policy reaching the filesystem. The edit row is §6.3's design made real — after the edit, *both* proposals are in the transcript:

```
AIMessage        [write_file(content='DRAFT'),    list_files()]
AIMessage human  [write_file(content='APPROVED'), list_files()]
```

Two things went wrong getting there, and both are worth more than the diff.

**F-10-02: the gate broke two Phase 9 guards.** The first end-to-end edit ended `stop_reason="no_progress"`. Phase 9's guards are pure functions of the transcript and all counted assistant messages. The gate is a *second producer* of `AIMessage`, so `list_files({})` appeared twice and `seen_signatures` correctly concluded the model had repeated itself. It had not; a human had. The same message inflated `model_calls_this_run`, charging the step cap for a turn no model produced. Invariant 60 exactly. The fix is a predicate:

```python
# excerpt: atlas/graph/core.py
def is_model_turn(message: AnyMessage) -> bool:
```

There is a subtlety. `seen_signatures` excludes the last turn by slicing `messages[:-1]`. Filtering *after* the slice drops the wrong element: with a gate in the loop the last message is the human's revision, so the slice retains the model's original and every unedited call counts twice. **Filter first, slice second.**

The same defect had a third home nobody found until the eval traces were read: `trajectory_from_state` also counted every `AIMessage` as a step, so `n_steps` → `HandlerOutcome.n_model_calls` → `RequestAccount`, and **an edited approval billed the user for a model call nobody made** (F-10-11). Invisible to every unit test, because they asserted on `stop_reason`. That is the argument for having unit tests *and* traces.

**F-10-03, the phase's sharpest lesson.** With the refusal path wired, REJECT recorded `decision="reject"` — and wrote the file. Approval record and refused file, side by side. The cause: `pending` was written by the gate and **not declared in `CoreState`**. Measured, in nine lines:

```python
graph.add_node("w", lambda s: {"declared": "ok", "undeclared": [1, 2]})
graph.add_node("r", lambda s: {"declared": repr(s.get("undeclared"))})
# -> {'declared': 'None'}
```

**A node returning a key the state schema does not declare is discarded silently.** No exception, no warning; `state.get(key)` reads `None` downstream. So the gate fired correctly, produced a correct record, and was read by nothing — invariant 62 in its purest form, *except* that this one also manufactures evidence of oversight. An auditor would find a refusal beside the file it refused to create.

The declaration is one line. The test that pins the mechanism is nine, and it is in the suite so nobody re-discovers it.

### 7.5 Bounded fan-out in the research pipeline

`build_research_subgraph` is `plan → Send fan-out → aggregate`. `planner` and `worker` are injected, not imported — invariant 10 one level up: a fan-out whose worker is a module global is a fan-out whose action space the caller no longer controls. The `worker` runs `run_core` with `allow_writes=False` unconditionally, so no branch can reach the gate: a fan-out that could suspend would need one interrupt and one operator decision *per branch*, which is §6.4's fatigue argument at its worst. The research route is read-only by construction; the write path stays on `tool_action` where a human is already in the loop.

A worker never raises. Invariant 35 requires one record per branch, failures included, and a worker that raised would kill the superstep and take its siblings with it — the framework's tool-node policy Atlas already declined. Measured with one branch raising:

```
branch records: [(0, True), (1, True), (2, False), (3, True)]
outcome:        partial=True, "4 branch(es), 1 failed"
```

And with staggered delays, slowest first, `max_concurrency=3`: `[0, 1, 2, 3, 4, 5]`. Argument order, under concurrency, with no sort and no lock.

**F-10-04**, found by a test that existed only because invariant 35 says to write it. An empty plan returned `[]` from `fan`, no worker ran, `aggregate` was never entered, and `outcome` came back `None` — an unplannable request produced *no record at all* rather than a labelled partial. Invariant 35: every early exit is a failure-policy decision, and an exit that skips the reporting step has chosen `all_or_nothing` whether or not anyone wrote it. The fix routes the empty case to `aggregate`, which is added to the conditional edge's declared reachable set.

**F-10-08**, and this one shipped. `build_research_subgraph` was built, measured, given three tests — and `build_atlas_graph` then registered `research` as a shim alongside `document` and `data`. The fan-out was reachable from tests and from `scripts/phase10_results.py`, and from **nothing on the default path**, while §11 claimed it as a capability. Invariant 63 verbatim, committed in the phase that teaches invariant 63. The fix wires it, and the test asserts it through `get_graph(xray=1)` rather than by importing the builder — because "the function exists" was already true when the defect shipped.

### 7.6 The store, and the sentence that was not true

`build_atlas_graph` gains `store=`, and a `persist` node between `critic` and `respond`:

```
router → {subgraph} → critic → persist → respond → END
```

`persist` writes `("atlas", "approvals", user_id)` and `("atlas", "handoffs", user_id)`. It reads the store and the identity through `get_store()` and `get_config()` rather than injected parameters, because the framework injects by parameter **name** and **annotation** — so a rename or a loose `Any` annotation silently changes what a node receives (it warns for `config`, and not for the rest). A helper call cannot be got wrong by renaming an argument.

Why the store and not the checkpointer: **an approval history is a fact about a user, not about a conversation.** An operator asking "what has this user been approved for?" is asking across threads, and a checkpointer cannot answer it. Namespacing gives isolation by construction rather than by a `WHERE` clause (D-58).

`run_atlas_graph` **constructs** an in-memory store when the caller supplies none, so `get_store()` is non-None on every path and the writer is exercised by every test rather than by the one that remembered (invariant 58). A durable store is a Phase 14 deployment concern.

This step exists because §6.9's first version described records nothing wrote (F-10-09). The test that closes it goes through `run_atlas_graph` and reads the store back through the same namespace:

```python
handoffs = store.search(("atlas", "handoffs", "u7"))
assert [item.key for item in handoffs] == ["t1"]
assert handoffs[0].value["reason"] == "authority_missing"
assert store.search(("atlas", "handoffs", "someone-else")) == []
```

### 7.7 Crash and resume, and the escalation path

`run_atlas_graph` passes `durability="sync"` from inside the entry point, `max_concurrency=worker_limit`, and an explicit `recursion_limit`. The crash test is real: a subprocess killed with `os._exit(9)`, a fresh process that inspects, a third that resumes. It asserts the return code is 9 (the crash must be a *hard* kill or the test proves nothing), that `snapshot.next == ('b',)`, that resume completes — and then the idempotency lesson as an assertion:

```python
assert ran.count("a") == 1, "a committed, so it is replayed not re-executed"
assert ran.count("b") == 2, "the in-flight node re-executes on resume"
```

A second test resumes an interrupt through a **different compiled app** over the same SQLite file, checking `snapshot.interrupts` is non-empty — because a pause visible only to the caller who caused it is not a durable pause, and an API handler resuming somebody else's approval is exactly this.

`atlas/graph/escalate.py` is pure functions over records Atlas already writes. `GUARD_STOPS` is a frozenset rather than an `if`, because a `Literal` with seven members and one `if` is a bug waiting for the other six (invariant 39). `should_escalate` checks `authority_missing` first. `error_kinds_in` reads `additional_kwargs["atlas_tool_result"]`, and there is a test asserting a prose-only `ToolMessage` yields *no* kinds — invariant 65 stated as a negative. `blocking_question_for` is a mapping with no fallback branch, so every member of the `Literal` must produce a question.

**With an assistant.** Safe to delegate: the mechanical parts of the migration (five `TypedDict`s from a list of keys, shim node bodies, `render()` methods), test parametrisation across decision kinds, docstring polish. **Not safe:** anything deciding *which layer* a guard belongs at, the gated/exempt split and its reasons, and `is_model_turn` — an assistant asked to "fix the `no_progress` failure" will very plausibly relax the guard rather than notice a human authored the duplicate turn, and you would have deleted a check without a note, which is invariant 59's stated arrival mechanism. One prompt that works:

> Here is `atlas/graph/state.py`. Write me a pytest test that, for `AtlasState`, computes the set of keys that are neither in `reset_run_channels()` nor `Annotated` with a reducer, and asserts it is empty except for `request`. Use `typing.get_type_hints(..., include_extras=True)`. Do not change any source file.

A structural assertion an assistant writes well, and the test that would have caught F-10-03 one layer up.

## 8. [core] Debug this trace

A `tool_action` episode. `allow_writes=True`, gate present and verified firing. The operator rejected.

*Provenance, because this book's own invariant 48 requires it: this trace is **constructed** to the shape of F-10-03 and F-10-05. `archive_report` and `read_report` are illustrative and are not in the repo — the defect they demonstrate is real and its fix is shipped, but no run produced these exact lines.*

```
[thread tool_action:u1 · step 1]
AI  tool_calls=[archive_report(quarter="Q3", destination="s3://reports/q3")]

[gate]
INTERRUPT approval
  1 action needs your decision (approve / edit / reject — rejecting is safe...):
  [0] archive_report (IRREVERSIBLE)
      Run archive_report with {'quarter': 'Q3', 'destination': 's3://reports/q3'}.
      Target state unknown: this tool has no consequence renderer, so the
      arguments are shown verbatim.

RESUME {"decisions": [{"kind": "reject", "reason": "wrong destination bucket"}]}

[tools]
TOOL archive_report -> ERROR (write_refused): archive_report modifies state
     and writes are disabled for this episode. Report what you would have
     changed instead of retrying.

[step 2]
AI  FINAL ANSWER: I was not able to archive the Q3 report — the archive
    action was declined. Nothing was changed.
    SOURCES: workspace

approvals: [{"tool": "archive_report", "decision": "reject",
             "reason": "wrong destination bucket", "malformed": false}]
stop_reason: final
```

The record is clean, the refusal typed, the model reported rather than retried. And **`s3://reports/q3` contains a copy of the Q3 report.**

**Diagnose it.** The gate is at layer (a), it fired, it refused correctly. Every mechanism did its job — so the write did not happen through a tool call.

The tell is the one line quietly admitting something: *"this tool has no consequence renderer, so the arguments are shown verbatim."* That is not the bug; it is the *symptom that was printed and read past*.

Here is the tool:

```python
@tool(name="archive_report", read_only=False)
def archive_report(quarter: str, destination: str) -> str:
    """Archive a quarterly report to long-term storage."""
    report = read_report(quarter)          # read_only, fine
    upload(report, destination)            # <-- the side effect
    return f"archived {quarter} to {destination}"
```

Now the trace makes sense — except it does not, because `write_refused` means `execute()` returned *before* calling the body. `upload` was never called from here.

It was called from `read_report`. Two phases ago somebody added an upload-cache default to `read_report`, which is registered `read_only=True`. The gate derives its set from `spec.read_only`, so `read_report` is exempt, ungated, and — because it is read-only — eligible for the node cache and the retry policy. It performed the write on a path the gate does not wrap.

**Three failures, and they are the general form.**

1. **The gate wraps tool *calls*, not *effects*.** §6.3's misconception realised: a write inside a tool the gate believes is read-only never appears. The gate's coverage is exactly as good as the `read_only` flags.
2. **`read_only` is a claim, not a property.** Nothing verifies it. Invariant 20 says the registry *is* the security model, and a mislabelled spec corrupts it silently — while the same label grants the tool a retry policy and a cache, so the wrong write can now happen *twice* and be *replayed*.
3. **The honest "target state unknown" line was the warning.** A tool with no consequence renderer is a tool nobody has thought about the consequences of.

**The fix, in three parts, and two of them are shipped.** First, `consequence_for` now **raises** `MissingConsequenceRenderer`, and `build_core_graph` checks every gated spec before compiling — the printed warning has become a build failure (D-57, §7.4). Second, the coverage claim becomes a test: `test_the_gated_set_is_derived_from_read_only` asserts the gated set equals the not-read-only set, joined by `test_every_gated_default_tool_is_describable`. Third, and this is **Assignment 1** rather than shipped code: `read_only` gets an assertion rather than a comment — every read-only tool is run against a temporary workspace and a stubbed network boundary, and the report fails if anything is written.

This becomes **invariant 66**:

> **A gate's coverage is the set of effects it wraps, not the set of calls it inspects, and the mapping between them is a claim that needs a test.** `read_only` grants exemption from approval, eligibility for retry, and eligibility for caching from one unverified boolean — so a mislabelled tool does not merely bypass the gate, it becomes replayable. Every tool is either read-only *and* proven effect-free, or gated *and* supplied with a consequence renderer; "unverified" is not a third state. Corollary: a node returning an undeclared channel is discarded silently, so a guard can fire correctly, record correctly, and be read by nothing while the action it refused proceeds. F-10-03, F-10-05.

## 9. [core] Common pitfalls & how professionals avoid them

**A side effect above an `interrupt()`.** The node re-runs from the top, measured. Keep the interrupt first and put anything that must happen once in a different node — the framework's replay unit is the node, so that is the only boundary available.

**Trusting the default durability mode.** The default lost a completed superstep under a hard kill and then reported `next=()`, which looks like success. Set it explicitly, at the entry point, and write down the latency cost.

**Letting the host choose your concurrency.** Unset `max_concurrency` is host-derived, not unbounded — worse, because it looks stable and changes on deploy.

**Retrying a node that writes.** The in-flight node re-executes. A `RetryPolicy` on a node that can write is a policy that writes twice. Attach retry and cache to read-only nodes only, and derive "read-only" from something tested.

**Writing an undeclared channel.** Silently dropped. This is the one that costs a day, because the producer works perfectly and the consumer sees `None`. Habit: add the declaration in the same edit, and keep a structural test that every channel is either reset or reduced.

**Reaching for `Command` because it is more powerful.** It moves a topology fact where the serialiser cannot see it, and `destinations=` is optional.

**Asking about everything.** The rate is the design parameter. Treat a rate above ~20% on a routine route as a bug in the gated set, not as diligence.

**Treating a transcript as a handoff package.** A human given a trajectory reads the trajectory. Give them established facts, dead ends, one question, and a resume path.

**Assuming a migration that passes is faithful.** Invariant 60. The gate arrived looking like two guard failures, and only Phase 9's absolute fixtures made that visible in minutes rather than weeks.

**Auditing the framework's defaults and not your own modules.** This phase applied invariant 59 rigorously to five framework mechanisms and shipped five wiring defects of its own (F-10-06 to F-10-10) — a broken `check-docs`, a dead constant, a fan-out wired to a shim, a store described and never written, and three eval tasks that scored 0/3. Phase 9 shipped three of this shape and *wrote invariant 63 about them*. **Run the audit on your own diff, last, before you tag.** It is mechanical and takes two minutes.

## 10. [extended] Industry perspective

**Approval is a workflow-engine problem, solved before.** Temporal, Step Functions, Azure Durable Functions, Airflow sensors — all implement human approval as *a task waiting on an external signal*, and all arrive at three rules: the wait must be durable, the waiting task must be idempotent because it will be replayed, and the signal must be validated. `interrupt()` is the same shape with a different vocabulary. Teams who have run workflow engines port their instincts cleanly; teams who have only written request handlers build the blocking-callback version first and discover §6.2 the hard way.

**Approval fatigue is the most common production failure of an oversight mechanism**, and the fix is *risk tiering* rather than better UX: a small set gated hard, a large set logged and reviewed asynchronously, nothing between. That asynchronous tier is what Atlas's `approvals` channel and the store namespace are for — a reviewable-after-the-fact trail is the only affordable oversight at volume.

**Escalation is usually under-built.** The common failure is an agent that fails silently and a support queue filling with "the assistant didn't work". Teams that measure it report escalation *quality* — the fraction of handoffs a human resolved without redoing the agent's work — a direct argument for the `established` field.

**Idempotency keys are the boring answer and the correct one.** Payments infrastructure settled this a decade ago: the client generates a key hashing the *work*, the server deduplicates, the key is stable across retries. Invariant 37 is that practice.

**Trade-offs.** Synchronous durability costs a write per superstep, which for a chat route may dominate latency; teams commonly run `sync` for write-capable graphs and the async default for read-only ones, which is defensible as long as it is written down. Subgraphs cost readability at the parent level and buy it at the child level; past roughly seven children, teams introduce a second parent.

**Interview questions.**

1. An agent must never send an email twice. Walk me through every place a duplicate can be introduced in a checkpointed graph, and what you would do about each.
2. Your approval gate inspects tool calls. Describe a write it cannot see, and how you would find out whether one exists in your codebase today.
3. What is the difference between `read_only` and `cacheable` for a tool, and why does conflating them cause a security problem rather than a performance one?
4. `max_concurrency` is unset and everything works. What happens on a larger instance, and what would you measure before deploying?
5. An operator has approved 200 consecutive requests. Is your gate working? What would you change first?

## 11. [core] Capstone increment

**If your code diverged, start again from `atlas_phase_09.zip`.**

**Resume note.** *Built Atlas's full request graph on LangGraph: a router dispatching to five route subgraphs, converging on a critic, an audit-trail writer and a single terminal node. Added a human approval gate that suspends before every write, deriving the gated set from tool metadata rather than a configured allow-list, refusing to compile for a write tool whose effect cannot be described to an operator, and preserving the model's original proposal when an operator edits a call — the framework's own gate destroys it. Added an escalation path packaging established facts, dead ends and one blocking question, leaving the thread resumable. Added bounded fan-out with a concurrency limit chosen against provider rate limits rather than inherited from the host, a cross-thread audit trail, and crash-safe execution verified by killing a process mid-run and resuming from a third. 1,306 offline tests, no network, no model.*

**What Atlas can do now**, stated precisely because a capability claim with no test is prose: answer over documents with citations; query structured data read-only with the relations it read; run tools; remember across sessions; plan and fan out research with a bound it chose, **on the default path**; **pause and ask a human before any write, showing the consequence rather than the arguments**; **record what was proposed and what was allowed as separate facts**; **hand off to a human with an actionable package**; **write a per-user audit trail readable across threads**; **survive a crash and resume on another process**; and run all of it as one compiled `StateGraph` whose topology `make graph` generates.

The *topology* is fully a `StateGraph`. `tool_action` and `research` are real multi-node graphs, both on the default path. `chat`, `document` and `data` are single-node shims over Phase 5–7 pipelines, and their internals were not migrated.

Not yet true, and named rather than implied: there is no email tool in Atlas, so "approval for emails" is a Phase 11+ claim; `run_python` and `remember` have consequence renderers but are not in the default registry, so `IRREVERSIBLE` names two tools an out-of-the-box Atlas does not have.

**Files touched.**

| File | Change |
|---|---|
| `atlas/graph/state.py` | **new** — `AtlasState`, the four records, `reset_run_channels` |
| `atlas/graph/approval.py` | **new** — derived gated set, `CONSEQUENCE_RENDERERS`, operator prompt, fail-closed decisions |
| `atlas/graph/escalate.py` | **new** — detection, fact/dead-end extraction, packaging |
| `atlas/graph/subgraphs.py` | **new** — five subgraphs, retry/cache policies, `Send` fan-out |
| `atlas/graph/app.py` | **new** — `build_atlas_graph`, `run_atlas_graph`, `persist`, the authority guard |
| `atlas/graph/core.py` | `approvals`/`pending` channels, derived gate, `is_model_turn`, `CORE_RUN_SCOPED`, `gated_recursion_limit_for` |
| `atlas/graph/adapter.py` | `reset_core_run_channels`; skip human-authored turns (F-10-11) |
| `evals/run.py` | two new dispatch branches so the Phase 10 tasks run (F-10-10) |
| `scripts/export_graph.py` | exports both levels |
| `tests/test_graph_phase10.py` | **new** — 51 tests |
| `tests/hidden/test_phase10_a1.py`, `_a2.py` | **new** |
| `evals/tasks/phase10.json` | **new** — 3 tasks |
| `scripts/phase10_results.py` | **new** — `make results` |
| `Makefile` | `PHASE ?= 10`; new `policy` target |
| `ATLAS_INTERFACES.md`, `VERSIONS.md`, `docs/{RESULTS,FAILURE_LOG,DECISIONS}.md` | updated |

**Tests added: 51.** The load-bearing ones are those that would have caught this phase's own defects: `test_each_decision_reaches_the_filesystem_correctly` (five decisions, asserting against the *filesystem*), `test_an_edit_preserves_the_original_proposal`, `test_an_undeclared_channel_is_dropped_silently`, `test_every_run_scoped_channel_is_reset` (structural, over `get_type_hints`), `test_a_hard_crash_leaves_a_resumable_thread` (three processes), `test_the_research_fan_out_is_on_the_default_path`, `test_the_store_is_written_on_the_default_path`, `test_the_gate_does_not_bill_a_model_call_for_a_human_edit`, and `test_every_capstone_claim_has_a_test`.

That last one deserves a note, because its first version was wrong in a way worth keeping. It tried to grep every `__all__` entry across `atlas/` and fail on any name referenced only in its own file. That test flagged twenty legitimately module-internal exports *and would have passed on F-10-08*, because `build_research_subgraph` was referenced by tests and a script while wired to nothing. **"Is this name used anywhere?" is not the question invariant 63 asks.** The question is "name the call site on the default path", and no grep answers it. What can be checked is that every capstone claim maps to a named test that exists; the judgement about whether the test reaches the default path stays human, which is the reviewer's job.

**+3 eval tasks** (48 → 51 gradeable), and this time **they run: 3/3, mean partial credit 1.00**:

- `p10-a-a-refused-write-touches-nothing-and-is-recorded` — graded on `environment.files_created` being empty, an `ApprovalRecord` with `decision="reject"`, `write_refused` in the transcript's error kinds, and a `final` answer.
- `p10-b-an-edit-preserves-what-the-model-proposed` — graded on **both** proposals being present, both argument sets on the record, and the file containing the operator's text. Fails if anyone adopts the framework's destructive edit.
- `p10-c-a-missing-authority-escalates-with-an-actionable-package` — graded on `stop_reason="escalated"`, `handoff.reason`, `handoff.actionable`, exactly one `established` fact (derived from the fixture list, not a loose lower bound — invariant 32), and no file created.

The first version of these three passed *schema* validation and scored **0/3**, because the harness had no branch for `gated`, `resume`, `force_route`, or the new check fields. They counted as gradeable, inflating the suite 48 → 51, and the count assertion was then edited to make the suite green. Invariant 23 exists to forbid exactly that: a task the harness cannot run is skipped with a stated reason, not scored zero, because a permanently-red row trains people to ignore red (F-10-10).

**`make results` and expected ranges.** Tier A, seed 7, model in `VERSIONS.md`. **Author estimate, unmeasured** unless `docs/RESULTS.md` says otherwise:

| Experiment | Metric | Expected range |
|---|---|---|
| 1. Framework gate vs Atlas gate | proposal recoverable after an edit | framework 0/5 · Atlas 5/5 *(measured, Tier F)* |
| 2. Approval rate by route | episodes reaching the gate | `tool_action` 60–90% · others 0% |
| 3. Fan-out order under load | branches in argument order | 6/6 at `max_concurrency` ∈ {1,2,3,5} *(measured)* |
| 4. Durability under a hard crash | supersteps preserved | `sync` 1/1 · `async` 0/1 · `exit` unresumable *(measured)* |
| 5. Escalation quality | handoffs with ≥1 established fact | 70–95% |
| 6. Gated fuse headroom | `GraphRecursionError` occurrences | 0 across the sweep |

Rows 1, 3 and 4 are facts about the framework and Atlas, not about a model, so they live in a test *and* in `RESULTS.md`.

**Interface changes.** Three, all additive:

1. **`gated_recursion_limit_for(max_steps)` is NEW; `recursion_limit_for` is unchanged.** The first attempt added a `gated=` keyword to the existing function, which broke `make check-docs` because the Phase 9 document pins that line (F-10-06). **Migration:** none.
2. **`CoreState` gains `approvals`** (`operator.add`, thread-scoped) **and `pending`** (no reducer, run-scoped), with `CORE_RUN_SCOPED` and `reset_core_run_channels()`. **Migration:** a caller invoking the compiled core directly should pass `{"approvals": [], **reset_core_run_channels()}`. `run_react_graph` and `run_core` do it for you; the eight Phase 9 equivalence fixtures pass unchanged.
3. **`build_atlas_graph` gains `store=`, `worker_limit=`, `research_levels=`; `run_atlas_graph` gains `store=`, `user_id=`.** All defaulted. `build_core_graph` now raises `MissingConsequenceRenderer` for an undescribable gated tool — a new failure mode, not a signature change, and it fires only when `allow_writes` is on.

**`docs/FAILURE_LOG.md` — twelve entries this phase, seven of them from auditing my own diff after declaring the phase finished.** F-10-01 (`extra="forbid"` broke a record's own round-trip), F-10-02 (the gate's human turn tripped `no_progress`), F-10-03 (refusal recorded, write performed), F-10-04 (empty fan-out skipped the reporting step), F-10-05 (§8's gate bypass → invariant 66), F-10-06 (widened signature broke `check-docs`), F-10-07 (`_NEVER_RETRY` documented an omission), F-10-08 (fan-out wired to a shim), F-10-09 (store described, never written), F-10-10 (three eval tasks at 0/3), F-10-11 (the gate billed a model call for a human edit), F-10-12 (a filename in a check's field path).

**Decisions added.** D-52 (decline `respond`), D-53 (additive record, immutable proposal), D-54 (derived gated set; authority guard at the granting layer), D-55 (runtime fuses inside the entry point), D-56 (retry and cache on read-only routes only), D-57 (an undescribable gated tool is a build failure), D-58 (the audit trail goes in the store).

**Repo tag:** `phase-10`.

## 12. [core] Mastery checklist

You are ready to move on if you can:

- [ ] Given a parent state schema and a child's `TypedDict`, say for every key whether the child can read it, write it, both, or neither — and explain the asymmetry in the "write only" case.
- [ ] Predict the contents of a side-effect log for a node that appends above an `interrupt()` and is resumed twice, without running it.
- [ ] Name the four candidate layers for an approval gate, say which one Atlas uses, and give a concrete write that even the correct layer cannot see.
- [ ] Map all four of the framework's HITL decisions onto Atlas's gate, naming the Atlas policy each would have overridden, and justify declining `respond`.
- [ ] Write the consequence sentence an operator should read for a tool you have just invented, and say what your gate should do if you cannot.
- [ ] State the three escalation reasons, the record each is computed from, and why `authority_missing` is checked first.
- [ ] Explain why an unset `max_concurrency` is worse than an unbounded one.
- [ ] Say which durability mode leaves a thread unresumable, which one lies about having finished, and what the safe one costs.
- [ ] Derive an idempotency key for "charge order o-1 for 4200 cents" and say what must not be in it.
- [ ] Explain why `read_only` grants three different privileges from one boolean, and why that makes a mislabelled tool a security problem rather than a performance one.
- [ ] Say what `Command(goto=...)` costs the topology assertion, and the one-word fix.
- [ ] Compute the minimum workable `recursion_limit` for a parent of 5 supersteps containing a child that needs 20.
- [ ] Run the invariant-63 wiring audit on a diff of your own and say what it can and cannot detect.

## 13. [core] Quiz

1. A node writes `{"verdict": "refused"}` to a channel the state schema does not declare, and a downstream node branches on `state.get("verdict")`. Describe exactly what happens, what the tests will say, and what an auditor reading the resulting thread will conclude. Name the invariant.

2. Atlas's approval gate produces a second `AIMessage` when an operator edits a call. Two Phase 9 guards broke as a result. Identify both, explain why the fix must filter *before* slicing off the last turn, and state the general principle about migrations that this illustrates.

3. The framework's HITL middleware is at the correct layer, emits one interrupt per turn, and has a four-member decision vocabulary. Give the strongest argument *for* its edit behaviour from the point of view of a general-purpose framework, and then say why Atlas cannot accept it.

4. `durability="sync"` preserves a completed superstep across a hard crash and `durability="async"` does not. Yet after the crash, the async thread reported `next=()`. Explain why that specific symptom is more dangerous than losing the work, and what a supervisor process would wrongly conclude.

5. Invariant 37 says an idempotency key hashes the work and not the attempt, and that a non-read-only step is never auto-retried, replayed, or cached. Explain why "read-only" and "cacheable" are separate declarations, and construct a tool that is one but not the other in each direction.

6. A phase ships a fan-out subgraph that is built, measured, covered by three passing tests, and registered in the parent graph as a single-node shim. A reviewer greps the codebase, finds the builder referenced in two files, and concludes it is wired. Explain precisely what the grep proved, what it did not, and what question the reviewer should have asked instead.

7. Your approval rate on the `tool_action` route is 85% and your operators have refused nothing in three weeks. Argue that the gate is working. Then argue that it is not. State the measurement that would settle it, and what you would change first regardless.

## 14. [core] Coding assignments

### Assignment 1 — Make invariant 66 real  `[fast track: do this one]`

§8's trace turned on an unverified boolean. Build the mechanism that verifies it.

Create `atlas/safety/coverage.py`:

```python
class CoverageReport(BaseModel):
    read_only_verified: list[str]
    gated_rendered: list[str]
    unverified: list[str]
    notes: dict[str, str]
    @computed_field
    @property
    def clean(self) -> bool: ...
    def render(self) -> str: ...

def has_consequence_renderer(name: str) -> bool: ...
def effect_free(spec: ToolSpec, *, workspace: Path) -> tuple[bool, str]: ...
def coverage_report(registry: ToolRegistry, *, workspace: Path) -> CoverageReport: ...
```

`effect_free` invokes a read-only tool against a scratch workspace with plausible arguments synthesised from its JSON Schema, snapshots the directory tree before and after, and returns `(False, what_it_observed)` if anything changed. `coverage_report` classifies every spec into exactly one of three buckets: read-only *and* proven effect-free; gated *and* possessing a consequence renderer; or **unverified**. Then wire `make coverage` to print it.

**Acceptance criteria.**
- Every spec in the default registry lands in exactly one bucket, and the three buckets partition `registry.names`.
- `unverified == []` and `clean is True` for the default registry.
- A tool registered `read_only=True` whose body writes a file is detected, appears in `unverified`, and `notes` says what was observed.
- A tool registered `read_only=False` with no consequence renderer appears in `unverified`.
- `CoverageReport` accepts its own `model_dump()` (invariant 31 — and F-10-01 is why this line is here).
- A failing check never raises; it records. The report is data.

**UNAIDED CORE.** The bucket definition and the `effect_free` observation strategy. Specifically: decide for yourself what counts as an "effect" — you will be tempted by filesystem mtimes, and you should reason about why a tool that reads a file and updates its own cache is a hard case, then write down the decision you made and its blind spot. Do not delegate this; an assistant will produce a plausible three-bucket function that treats "no exception raised" as "no effect", which is the exact defect you are building this to catch.

Delegate freely: the argument synthesis from JSON Schema, the `render()` formatting, the Makefile target.

Hidden test: `tests/hidden/test_phase10_a1.py`. Run `make grade`. Do not read it.

### Assignment 2 — An idempotent effect  `[extended]`

Create `atlas/graph/idempotent.py`:

```python
HANDLER_VERSION: str

class OnceResult(BaseModel):
    key: str
    value: Any
    replayed: bool

def work_key(tool: str, arguments: dict, *, handler_version: str = HANDLER_VERSION,
             **ignored: Any) -> str: ...
def already_done(store, key: str) -> Any | None: ...
def mark_done(store, key: str, value: Any) -> None: ...
def run_once(store, key: str, effect: Callable[[], Any]) -> OnceResult: ...
```

`work_key` hashes the tool name, the arguments (order-independently), and the handler version — and **nothing else**. `run_once` checks the store, runs the effect if unclaimed, marks it done, and returns `OnceResult`. Use the framework's cross-thread store, so the claim outlives the thread.

**Acceptance criteria.**
- Argument order does not change the key; a different argument value does; the handler version does; an `attempt=` keyword does **not**.
- Across two calls with the same key, the effect runs once and both results carry the same value, with `replayed` False then True.
- An effect that raises leaves the key **unclaimed**, and a subsequent call runs it again.
- `mark_done` is idempotent.
- Different work does not collide.

**UNAIDED CORE.** The ordering inside `run_once`, and the failure semantics. There is a race and a correctness question hiding here — claim-then-run versus run-then-claim — and each choice has a distinct failure mode under §6.7's measured "the in-flight node re-executes". Write both orderings down, name the failure each admits, choose one, and put your reasoning in the module docstring. This is the assignment's whole content; the hashing is five lines.

Hidden test: `tests/hidden/test_phase10_a2.py`.

## 15. [extended] Case study: a durable order-processing agent that must never double-charge

**The system.** A small company's Atlas instance processes refund requests. On approval it must: (1) validate the order, (2) charge or refund a card through a payment provider, (3) write a ledger row, (4) email the customer. Steps 2, 3 and 4 have external effects. Step 2 is the one that must never happen twice.

**The constraints.** The payment provider's API is HTTP, occasionally returns 503, and supports an `Idempotency-Key` header. The graph runs with a checkpointer and a human approval gate before step 2. Operators approve about 40 refunds a day. The process is restarted on deploy, roughly twice a week, and has been OOM-killed twice this quarter.

**Your task.** Produce a design document of 900–1,400 words plus a topology diagram. It must:

1. Locate **every** place a duplicate charge can be introduced. There are at least five, and four of them come from mechanisms in this phase rather than from the payment code. Consider: the approval gate's re-execution, retry policy, node caching, crash resume, and a resumed thread whose operator approves twice.
2. Choose a durability mode and justify the latency cost against 40 approvals a day.
3. Derive the idempotency key. State what is in it, what is deliberately out, and what happens when the handler version changes while a charge is in flight.
4. Decide the node boundaries. Say which steps share a node and which cannot, with the reason grounded in the replay unit.
5. Specify the approval payload — the consequence sentence, and how you avoid fatigue at 40/day.
6. Specify the escalation path for "the provider returned 503 four times."
7. State one thing your design cannot guarantee, and how you would detect it in production.

**Rubric (30 points).**

| Criterion | Points | Full marks looks like |
|---|---|---|
| Duplicate-charge inventory | 7 | Five or more sources, each traced to a specific mechanism; identifies that the gate's node re-executes and that a crash re-runs the in-flight node |
| Durability choice | 3 | Names the mode, quantifies the cost against the stated volume, and says what the other two modes would lose |
| Idempotency key | 5 | Hashes the work; excludes run id and attempt; handles the version-change-in-flight case explicitly rather than ignoring it |
| Node boundaries | 5 | Charge isolated in its own node; reasoning refers to the replay unit, not to tidiness; says why the ledger write may or may not share it |
| Approval UX | 4 | Consequence sentence names the amount and irreversibility; a stated fatigue strategy (tiering, batching, or a threshold) with a number |
| Escalation | 3 | Distinguishes it from approval; package contains the order, the attempts, one question, and a resume path |
| Stated limitation | 3 | A real gap honestly named — not a hedge — with a concrete detection method (reconciliation job, provider-side dedup report, alert on key collisions) |

**Deductions.** −4 if any design puts the charge above an `interrupt()`. −4 if a retry policy is attached to the charging node. −3 if the idempotency key contains an attempt number or a timestamp. −3 if "the operator approves twice on a resumed thread" is not addressed.

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 11.*

**Persistence was the mechanism; this phase spent it.** Human-in-the-loop is persistence plus a place to suspend, and `StateSnapshot.interrupts` — the empty field at the end of Phase 9 — is now the channel an approval travels on. Escalation is the same mechanism with a different owner of the decision.

**`interrupt()` re-executes its node from the first line.** Measured: `['before-interrupt', 'before-interrupt', 'after-interrupt']`. There is no way to freeze a Python frame into a database, so the framework re-runs the function and hands a different value to one call inside it. Hence: the interrupt is the first statement of its node, anything that must happen once lives in a different node, and **a node body runs an unbounded number of times while only its committed output runs once.**

**Subgraph state maps by NAME, and a child cannot read a key it does not declare.** So `ChatState` omits `messages` and the `chat` route cannot see the transcript — invariant 20's "a prohibition is an absent tool", applied to a channel. The asymmetry to remember: a child cannot *read* an undeclared key but nothing stops it *writing* one the parent declares.

**`recursion_limit` is inherited, not divided.** Measured on two graphs of opposite shape: the minimum is `max(level_supersteps) + 1`, never the sum. Phase 9's `3 * max_steps + 2` survives — by accident of the parent being four supersteps deep, which is now pinned by a test. The gated arm needs a fourth superstep per step, so `GATED_SUPERSTEPS_PER_STEP = 4`.

**The framework's approval gate destroys the record of what was overseen.** On `edit` it assigns revised calls onto the `AIMessage` and returns it with the same id, so `add_messages` upserts: **0 of 5 original proposals recoverable**, against 5/5 for Atlas's. The purpose of a gate is oversight, and that one increases control while manufacturing a transcript in which the model proposed exactly what a human approved. So the proposal is immutable and the decision is additive (D-53). Its other two policies are default-allow for unlisted tools and untyped prose for rejections; Atlas derives the gated set from `spec.read_only` and refuses with its own `write_refused`.

**Fan-out gives argument order for free and a concurrency bound that is the host's.** `Send` results arrive in task order even when workers finish backwards, so invariant 35 holds without a sort and invariant 38 without a lock. But an unset `max_concurrency` is `min(32, cpu_count + 4)` — measured at 5 on a 1-vCPU box — which has nothing to do with a rate limit and changes on deploy. Pass the number you chose.

**Crash-safety is a keyword and its default is not the safe value.** Under `os._exit(9)`: `sync` preserved the completed superstep, `async` lost it *and then reported `next=()`* — indistinguishable from a finished run — and `exit` left the thread unresumable. On resume, the in-flight node ran twice and the committed node once. That single measurement is why retry and cache attach to read-only routes only (D-56): a `RetryPolicy` on a node that can write is a policy that writes twice.

**`Command` moves a topology fact where the serialiser cannot see it.** Without `destinations=`, `draw_mermaid()` prints `a --> __end__` for a node that jumps to `b`. Invariant 62's oracle turned against invariant 62. A conditional edge wherever one suffices.

**The store persists; it does not retrieve.** `search(query=...)` with no index returned the whole namespace in insertion order with `score=None` and no error — a mechanism that reads as relevance and performs none. Phase 8's `MemoryStore` keeps the scoring; the store keeps the plumbing.

**The count is the finding, for the second phase running.** This phase applied invariant 59 rigorously to five framework mechanisms and shipped **seven wiring defects of its own** — a `check-docs` break from a widened signature, a constant that documented an omission instead of being one, a fan-out wired to a shim, a store described in prose and written nowhere, three eval tasks that passed schema validation and scored 0/3, a gate that billed a model call for a human edit, and a filename in a check's field path. Phase 9 shipped three of this shape and wrote invariant 63 about them. **Run the audit on your own diff, last, before you tag** — and know what it can detect: "is this name used anywhere?" is not the question, because `build_research_subgraph` was used in two files and wired to nothing.

**Invariant 66, and the three defects that produced it.** A gate's coverage is the set of effects it wraps, not the calls it inspects. `read_only` grants exemption from approval, eligibility for retry *and* eligibility for caching from one unverified boolean, so a mislabelled tool does not merely bypass the gate — it becomes replayable. Corollary, and the most expensive thing in this phase: **a node returning an undeclared key is discarded silently**, so the first gate recorded `decision="reject"` beside the file it refused to create. That is invariant 62 plus manufactured evidence of oversight. Three others: `extra="forbid"` broke a record's own round-trip (F-10-01, invariant 31's fourth appearance); the gate's human-authored `AIMessage` tripped `no_progress` and inflated the step cap (F-10-02, invariant 60 — an improvement is indistinguishable from a bug); an empty fan-out skipped the reporting step (F-10-04, invariant 35).

**The rate is the design parameter.** An agent that asks about everything gets rubber-stamped, and a rubber-stamped approval transfers accountability without transferring scrutiny — the gate manufactures evidence of oversight that did not occur, one layer up from the edit problem. Refusal must be exactly as cheap as approval; the exempt set is enumerated with reasons; `make policy` prints both halves.

**Atlas now.** `START → router → {chat | document | data | research | tool_action} → critic → persist → respond → END`, with approval before every write, escalation with an actionable handoff, bounded fan-out **on the default path**, a per-user audit trail in the cross-thread store, and crash-safe runs. Stated precisely: the *topology* is fully a `StateGraph`; `tool_action` and `research` are real multi-node graphs; `chat`, `document` and `data` are single-node shims whose Phase 5–7 internals were not migrated. 1,306 offline tests, 51 gradeable eval tasks all passing, no network, no model.

**Phase 11 next.** Atlas takes real actions on a human's behalf and needs the sandbox to be a boundary rather than a directory name. The `run_python` tool has been gated and never built; `IRREVERSIBLE` names it already. And the case study's unanswered question is Phase 11's: an idempotency key protects one provider, and Atlas has no way to prove that a tool declared `read_only` is — which Assignment 1 starts and invariant 66 will not let you leave unverified.

## 17. [core] Further reading

- **LangGraph — Human-in-the-loop** and **Durable execution** conceptual guides, docs.langchain.com/oss/python. The primary source for `interrupt`, `Command`, and the durability modes. Read the re-execution note carefully; §6.2 is that note made empirical. *(Accessed 2026-09-10.)*
- **LangGraph — Persistence** (checkpointers, the store, `get_state_history`), docs.langchain.com. The basis for §6.9 and Appendix F.4a. *(2026-09-10.)*
- **`langchain.agents.middleware`** installed source, particularly `HumanInTheLoopMiddleware.after_model`. Reading the twenty lines that assign `last_ai_msg.tool_calls` is worth more than any secondary description of them; it is where §6.3's measurement came from. *(Pinned version in VERSIONS.md.)*
- **Stripe, "Idempotent Requests"**, stripe.com/docs/api/idempotent_requests. The canonical statement of the practice invariant 37 encodes, from the industry that had to get it right first. *(2026-09-10.)*
- **Temporal, "Workflow Determinism" / replay documentation**, docs.temporal.io. Human approval as a durable wait, from a workflow engine rather than an agent framework. The clearest available account of why replay forces idempotency. *(2026-09-10.)*
- **Google SRE Book**, ch. 6 ("Monitoring Distributed Systems") and ch. 11 on alerting, sre.google/sre-book. Not about agents; the best free treatment of why alert rate, not operator diligence, is the variable you control. §6.4's rule 1 is this chapter applied to approvals. *(2026-09-10.)*
- **Pregel: A System for Large-Scale Graph Processing** (Malewicz et al., SIGMOD 2010). LangGraph's acknowledged inspiration. Read it for the superstep model — it makes the recursion-limit arithmetic and the per-superstep checkpoint obvious rather than arbitrary.
- **OWASP Top 10 for LLM Applications** — "Excessive Agency" (LLM06 in the 2025 revision), owasp.org. The vulnerability class invariant 66 belongs to, and useful vocabulary for arguing the case study's rubric to a security reviewer. *(2026-09-10.)*

## 18. [core] SOLUTIONS

Emitted as a separate document, `phase_10_solutions.md`: full worked answers for the cumulative review, every concept check, the quiz, both assignments, and the case study. Do not read it before attempting the material; the quiz answers in particular are written to be checked against, not studied from.

## 19. [core] HANDOFF

**Confirmed:** the updated `ATLAS_INTERFACES.md` (**v0.22** — invariant 66, D-52 to D-58, and interface blocks for `atlas.graph.state`, `atlas.graph.approval`, `atlas.graph.escalate`, `atlas.graph.subgraphs`, `atlas.graph.app`, plus the Phase 10 additions to `atlas.graph.core`) and the updated `VERSIONS.md` (Phase 10 delta, checked 2026-09-10) are both **inside `atlas_phase_10.zip`**, at the repo root. The tree is committed and tagged `phase-10`.

**Final verification, run in this session:**

```
make test-offline   ->  1306 passed, 12 skipped
make check-docs     ->  green (invariant 8; broken once this phase, see F-10-06)
evals --phase 10    ->  3/3, pass^k 100%, mean partial credit 1.00
make grade          ->  2 skipped (both assignments unstarted, as intended)
make policy         ->  1 gated tool, 4 exempt, each with its reason
make graph          ->  2 topologies exported (front door + core)
evals (all)         ->  52 tasks defined, 51 gradeable
```

**Files changed in the zip this phase.**

*Added:* `atlas/graph/state.py`, `atlas/graph/approval.py`, `atlas/graph/escalate.py`, `atlas/graph/subgraphs.py`, `atlas/graph/app.py`, `tests/test_graph_phase10.py`, `tests/hidden/test_phase10_a1.py`, `tests/hidden/test_phase10_a2.py`, `evals/tasks/phase10.json`, `scripts/phase10_results.py`.

*Modified:* `atlas/graph/core.py` (approval channels, derived gate node, `is_model_turn`, `CORE_RUN_SCOPED`, `gated_recursion_limit_for`, the consequence-renderer completeness check), `atlas/graph/adapter.py` (channel reset; human turns are not model steps), `evals/run.py` (two dispatch branches so the Phase 10 tasks run), `scripts/export_graph.py` (both levels), `tests/test_evals_harness.py` (task count 48 → 51, deliberately), `Makefile` (`PHASE ?= 10`, new `policy` target), `ATLAS_INTERFACES.md`, `VERSIONS.md`, `docs/RESULTS.md`, `docs/FAILURE_LOG.md`, `docs/DECISIONS.md`.

**VERSIONS.md delta rows added this phase:**

```
| fact | value | source URL | checked-on |
|---|---|---|---|
| `langgraph` version pinned | 1.2.11 — unchanged, re-verified | https://pypistats.org/packages/langgraph | 2026-09-10 |
| `langchain` version pinned | 1.4.0 — unchanged | https://pypi.org/project/langchain/ | 2026-09-10 |
| `langgraph-checkpoint-sqlite` pinned | 3.1.1 — unchanged | https://pypi.org/project/langgraph-checkpoint-sqlite/ | 2026-09-10 |
| Durability modes available | `sync`, `async`, `exit`; `async` is the DEFAULT | `langgraph.types.Durability` (installed) | 2026-09-10 |
| Completed supersteps preserved after `os._exit(9)` | sync 1/1 · async 0/1 · exit unresumable (`EmptyInputError`) | measured, docs/RESULTS.md Phase 10 exp. 4 | 2026-09-10 |
| Node re-execution on resume | in-flight node runs twice; committed nodes replayed | measured, tests/test_graph_phase10.py | 2026-09-10 |
| `interrupt()` re-execution semantics | node restarts from its FIRST line; resume values matched by order within the task | installed docstring, langgraph/types.py | 2026-09-10 |
| Default fan-out concurrency, `max_concurrency` unset | host-derived: 5 on a 1-vCPU box = min(32, cpu_count + 4) | measured | 2026-09-10 |
| `Send` result order under concurrency | argument order, not completion order | measured, exp. 3 | 2026-09-10 |
| `recursion_limit` across a subgraph boundary | inherited, not divided: minimum is max(level_supersteps) + 1 | measured | 2026-09-10 |
| `Command(goto=...)` without `destinations=` | node drawn as `--> __end__`; topology serialisation is wrong | measured | 2026-09-10 |
| Undeclared state-channel write | discarded silently; no exception, no warning; reads back None | measured | 2026-09-10 |
| `HumanInTheLoopMiddleware.__init__` signature | interrupt_on: dict[str, bool | InterruptOnConfig], description_prefix="Tool execution requires approval" | installed signature | 2026-09-10 |
| Framework HITL default for an unlisted tool | auto-approved (default-allow) | installed docstring | 2026-09-10 |
| Framework HITL decision vocabulary | approve, edit, reject, respond | installed _process_decision | 2026-09-10 |
| Framework HITL hook | after_model (single interrupt carrying every gated call of the turn) | installed source | 2026-09-10 |
| Framework HITL edit behaviour | assigns revised calls onto the AIMessage and returns it with the SAME id, so add_messages upserts and the original proposal is destroyed | measured, exp. 1 | 2026-09-10 |
| Framework HITL rejection message | prose ToolMessage, status="error", no error kind | installed source | 2026-09-10 |
| `RetryPolicy` defaults | initial_interval=0.5, backoff_factor=2.0, max_interval=128.0, max_attempts=3, jitter=True | installed signature | 2026-09-10 |
| `default_retry_on` behaviour | ConnectionError -> True; ValueError -> False | measured | 2026-09-10 |
| `CachePolicy` signature | key_func=default_cache_key, ttl=None; key derived from the node's whole input state | installed signature + measured | 2026-09-10 |
| Store API | put/get/search/list_namespaces; namespaces are tuples; search(limit=10) default | installed signatures | 2026-09-10 |
| Store `search(query=...)` without an index | returns the namespace in insertion order, score=None, no error raised | measured | 2026-09-10 |
| MCP multi-round-trip -> LangGraph interrupt adapter | first-party adapter is PRE-RELEASE; not imported by atlas/; Phase 12 wires it by hand | installed package survey | 2026-09-10 |
| Offline test count | 1306 passed, 12 skipped | `make test-offline` | 2026-09-10 |
| Gradeable eval tasks | 51 (52 defined) | `python evals/run.py --trials 1` | 2026-09-10 |
| Tier A requests per full sweep | ~1300 | `make plan` | 2026-09-10 |
| Tier H cap, this phase | 50 | `scripts/phase10_results.py` | 2026-09-10 |
| `ATLAS_INTERFACES.md` version | v0.22, invariant 66, D-52 to D-58 | repo | 2026-09-10 |
| `GATED_SUPERSTEPS_PER_STEP` | 4 (model, decide, gate, tools) | `atlas/graph/core.py` | 2026-09-10 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-10 |
```

**Pre-release APIs used in code: none.** The MCP multi-round-trip interrupt adapter appears only as the §6.11 forward pointer.
