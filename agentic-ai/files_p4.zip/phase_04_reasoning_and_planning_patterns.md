# Phase 4 — Reasoning and Planning Patterns: Chain-of-Thought, ReAct, Plan-and-Execute, and Reflection

> Solutions: `phase_04_solutions.md`. Repository: `atlas_phase_04.zip`.
> Code blocks marked `# excerpt:` are verified byte-for-byte against the tree
> by `make check-docs`; files are complete in the zip.
>
> **Provenance convention used throughout.** A number is either *measured* (it
> carries a tier, model, seed and date, and lives in `docs/RESULTS.md`),
> *published* (it carries a paper and a date), or *illustrative* (it is
> labelled as such). Nothing in this document is presented as a measurement I
> did not take. §8's trace is labelled reconstructed, because no Tier A model
> was available while this phase was written.

---

## 1. [core] Title · Budget · Repo tag

| | |
|---|---|
| **Phase** | 4 — Reasoning and Planning Patterns |
| **Study hours** | read 4 h · build 6 h · assess 3 h |
| **Compute (baseline laptop)** | ≈ 35 min Tier A for one full `make results`; ≈ 4 min for `ARGS=--quick` |
| **Tier A calls per full eval sweep** | ≈ 90 for the strategy comparison, ≈ 235 for the 26-task suite at 3 trials |
| **Tier H calls** | ≈ 90 (8 problems × 4 strategies × 1 run), cached to `data/cache/`; cap 300 |
| **Cost** | $0.00 |
| **Repo tag** | `phase-04` |

The one step that could blow the laptop budget is the strategy comparison: plan-and-execute makes five to seven calls per problem, and there are eight problems and four arms. Eight is what fits. §7.10 explains what a 32-cell grid with one run per cell can and cannot tell you, which is more useful than a bigger number would be.

---

## 2. [core] Cumulative review

Five questions from Phases 1 and 2. Answers in the solutions file.

1. Phase 1 gave `prompt_tokens_for_episode(n, p0, g) = n·p0 + g·n·(n−1)/2`. The second term is quadratic in `n`. Say *why* — what is paid for repeatedly — and name one consequence for a phase about to add a planner, an executor and a critic to the same episode.
2. Phase 2 called `extra="forbid"` and `additionalProperties: false` "the two switches". Which constrains the model and which constrains your Python, and what silently goes wrong if you set only the second?
3. `structured()` is a module-level function taking a client, not a method. Give the concrete testing capability that buys, and name the class it depends on.
4. Invariant 14: a wrapper that can return without calling inward goes *outside* one that meters inward calls. You add a `RetryingClient`. Inside or outside `BudgetedClient`, and what does the wrong order do to your Tier H quota?
5. `extract_json_object` chooses its opening bracket by position, not preference. An earlier version searched for `{` only. Describe the input that broke it and what the caller saw.

---

## 3. [core] Why this phase matters

Phase 3 gave Atlas a loop with seven exits and a set of tools, and that loop has exactly one shape: ask what to do next, do it, report back, repeat. That shape was a decision, and it has been unexamined until now.

It matters because **the shape of the loop determines which failures are possible**, which is a stronger property than which are likely. A ReAct loop cannot make a step-4 mistake that depends on step 2's result being stale, because there is no step 4 until step 3 returns; it *can* forget by step 5 what it was doing at step 1, because everything it knows sits in a transcript whose middle it attends to least. Plan-and-execute has the mirror profile: the goal survives, because it is written once and re-read, and the plan is stale from the first observation that contradicts it. Neither is a model defect. Both are consequences of where you put the deliberation.

There is a second, less comfortable reason. This literature is unusually full of results that did not survive a fair baseline. Reflexion (Shinn et al., 20 Mar 2023) reported large gains from self-reflection; Huang et al. (3 Oct 2023) showed those gains came from using ground-truth labels to decide when to stop, and that without labels — your situation — accuracy *falls*. Multi-agent debate looked like critique and turned out to be a worse implementation of voting. Tree of Thoughts turned 4% into 74% on one task and spent about a hundred chain-of-thought samples per problem doing it. None of this is scandal; each paper is honest about its setup, and two of them are why the correction was findable. But it means "the community found that X helps" is not a sentence you can act on, and a phase teaching four strategies must teach the accompanying skill: **run the cheap baseline at the same budget, or you have measured nothing.**

So the aim is not more machinery. It is a defensible answer to a question you will be asked in every design review: *why is this a loop and not a plan?* And one layer down: why is the critic in this pipeline thirty lines of Python rather than a prompt?

---

## 4. [core] Learning objectives

You will be able to:

1. **State the axis** the four practical strategies lie on and place each on it, with the failure mode its *shape* makes possible.
2. **Explain what CoT buys**, quote the dated evidence for where it helps and where it does not, and name two conditions under which it makes a small local model worse.
3. **Distinguish self-consistency from self-correction**, cost each, and explain why Atlas's `temperature=0` makes one unavailable.
4. **Describe what reasoning models changed** — which layer the deliberation moved to — and what they do *not* relieve you of.
5. **Implement a plan-and-execute agent** whose plan is a validated DAG, whose executor runs in dependency order, and whose exits are a closed `Literal` owned by the harness.
6. **Implement a two-tier critic** in which mechanical findings need no model and a model critic may add findings but never clear them, and justify the asymmetry.
7. **Build a replan loop** with a cap, and state the three conditions that should trigger a replan and the two that should not.
8. **Write a cheap verifier** for a step's output shape, and explain why a typed expectation checked in Python beats a critic prompt.
9. **Make a harness record survive its own serialisation**, and say why "the key is present" is the wrong test.
10. **Measure four strategies** on a seeded problem set for accuracy, tokens and latency, grade them without a model, and state what one run per cell licenses you to conclude.
11. **Explain code-as-action** — why it cuts step count, why it needs a sandbox, when JSON calls are safer — without building it.
12. **Read a benchmark skeptically**, naming contamination and instantiation fragility with dated evidence, and explain why a seeded corpus generator is the local answer.

---

## 5. [core] Prerequisites & quick recap

You need `atlas_phase_03.zip` unpacked and green:

```bash
cd atlas-agent
make test-offline      # expect 402 passed
make evals ARGS="--trials 1"
```

Fix any red before reading on; every build step in §7 edits code these tests cover, and you want to know which failures you caused.

Four things from Phase 3 are load-bearing.

**The registry is an injected value (invariant 10, D-08).** Every agent this phase adds takes `registry` as a required keyword, for the same reason `run_react_agent` does: a loop with a default action space can act when you thought it could not.

**Termination is owned by the harness (invariant 9, D-02).** `ReactStopReason` is a closed `Literal` of seven, the loop is a bounded `for`, and `step_cap` is the default so an episode that falls off the end never looks successful. Plan-and-execute gets its own closed `Literal` and fails closed the same way.

**Errors are part of the interface (invariant 19, D-10).** `execute()` never raises; it returns a `ToolResult` with an `error_kind` from a closed set of four. The executor never sees a tool exception, which is what makes the critic's job "read a typed result" rather than "parse a traceback".

**Provenance is a property of what happened (invariant 25, D-14).** `--append-results` refuses a sweep in which any trial replayed a fixture, and the critic carries a `from_model` flag, because "the critic accepted this" means two different things.

One number to carry forward: Phase 3's §8 trace ended with a *correct* answer citing a tool that had returned an error. Exit code 0, `stop_reason="final"`, sources present, and none of the seven guards fired, because all seven watch for not finishing and that episode finished beautifully. That is why §6.6 is about verifiers and not about critics.

---

## 6. [core] Core concepts

### 6.1 [core] One axis: where does the deliberation happen?

**Intuition.** You are handed a multi-step question: *how many units did we ship in Q1 per head of engineering?* You could blurt an answer; think it through on paper first; look one thing up, see what it says, decide what to look up next; or write down the three lookups you need, do them, and combine. Four places to put the thinking: nowhere, in a scratch pad, in the feedback from each lookup, in a written plan. Those are the four strategies, and they differ not because one is smarter but because **each commits to its structure at a different moment**.

**Precisely.** A **reasoning strategy** is a control-flow policy over model calls: how many to make, what each is given, and what decides whether there is another.

- **Direct**: one call. Deliberation inside one forward pass, unlogged.
- **CoT**: one call, with an instruction or exemplars that produce intermediate tokens first. Deliberation in the output tokens, therefore visible.
- **ReAct**: *n* calls; call *k* sees calls 1…*k*−1 and their observations, and *n* is decided at runtime by the model stopping or a guard firing. Deliberation between calls, informed by the environment.
- **Plan-and-execute**: one planning call producing a structure, one call per step, then a synthesis call, with the structure — not the model's per-step whim — deciding what happens next.

```mermaid
flowchart LR
    subgraph Direct
      D1[task] --> D2[one call] --> D3[answer]
    end
    subgraph CoT
      C1["task + 'show your work'"] --> C2[one call:<br/>tokens then answer] --> C3[answer]
    end
    subgraph ReAct
      R1[task] --> R2[call k]
      R2 -->|tool call| R3[observation]
      R3 --> R2
      R2 -->|final| R4[answer]
    end
    subgraph PlanExec
      P1[task] --> P2[plan call] --> P3[DAG of steps]
      P3 --> P4[execute in<br/>dependency order] --> P5[critic]
      P5 -->|accept| P6[answer]
      P5 -->|replan| P2
    end
```

The axis explains the trade-offs with no appeal to model quality. Left: fewer tokens, less grounding. Right: more calls, more structure that survives context growth. The **commitment moment** is the sharpest distinction: ReAct never commits, so it adapts freely and can wander forever; plan-and-execute commits in call one, so it stays on task and can execute a plan the second observation already invalidated.

> **Misconception: "these are prompting techniques."** Only CoT is, and only in its 2022 form. ReAct and plan-and-execute are *control flow*. You cannot get plan-and-execute by asking a model to plan and then execute in one call — that is Plan-and-Solve prompting (Wang et al., arXiv:2305.04091, 6 May 2023, ACL 2023), a different thing with different costs. **If the number of model calls does not change, you changed a prompt.**

**Concept check 6.1.** A task needs three independent database lookups then one arithmetic combination. Which strategy makes the fewest model *calls*, and which the fewest sequential *round trips*? These are different questions; say why.

### 6.2 [core] Chain-of-thought

**Intuition.** A transformer computes a fixed number of layers per token. Whatever a problem needs beyond that cannot happen inside one token position, but it *can* happen across many, because each generated token is appended and re-read. Output tokens are scratch space; "show your work" is a request for scratch space.

**Precisely.** CoT elicits intermediate reasoning before the answer, via exemplars containing such steps (Wei et al., arXiv:2201.11903, 28 Jan 2022; NeurIPS 2022) or a zero-shot instruction to think step by step (Kojima et al., NeurIPS 2022, 35:22199–22213). Same mechanism both ways: the answer is conditioned on a longer prefix the model produced.

**Worked example.** Ask for `(engineering) × 3 − (sales)` with engineering 14, sales 6. Direct: the model must produce `36` with no intermediate position to hold `42`. CoT: it emits `14 × 3 = 42`, then `42 − 6 = 36`. The second has somewhere to put 42 — and it is *auditable*, so you can see which operation went wrong. That second benefit is the one that matters for Atlas.

**The dated evidence, and its shape.** The 2022 papers established gains on arithmetic, commonsense and symbolic reasoning at sufficient scale. The most useful later result narrows this sharply: Sprague et al. ran a meta-analysis over 100 CoT papers plus their own evaluations of 20 datasets across 14 models, and found CoT gives strong benefits primarily on math or logic, with much smaller gains elsewhere; on MMLU, generating the answer directly is almost identically accurate unless the question or response contains an equals sign (arXiv:2409.12183, 18 Sep 2024; ICLR 2025). Their explanation is the sentence to memorise: most of the gain is attributed to tracing intermediate steps, which symbolic solvers are better suited for, so **CoT rarely outperforms them.**

Read that twice. It is the most actionable sentence in this literature for an agent builder: **where CoT helps most, a tool helps more.** Atlas ships the tool — `calculate` walks an AST against a whitelist — and Phase 3's §8 failure was a model doing arithmetic in its head *after* that tool refused. For Atlas, CoT is not the answer to arithmetic; it is what makes the model decide to call the calculator.

**When to use it.** As a one-line addition to a strategy already making a call: try it whenever the task involves multi-step numeric or logical composition, and measure before keeping it.

**Failure modes.**

*It costs output tokens and your cap is finite.* `DEFAULT_MAX_OUTPUT_TOKENS = 640` was sized at ~50% headroom over a cited answer. A CoT instruction eats that headroom. The symptom is `finish_reason="length"` — Phase 2's `OutputTruncated`, which raises rather than repairing because it is a configuration problem. **A CoT prompt with an unchanged token cap does not reason worse; it produces a truncated answer, which grades as zero.**

*It can be unfaithful.* A chain of thought is text the model produced, and that is not a log of the computation that produced it. Turpin et al. (arXiv:2305.04388, NeurIPS 2023) established this; Anthropic quantified it on reasoning models. Across six kinds of planted hint, models revealed their use of the hint in at least 1% of examples where they used it, but the reveal rate is often below 20% (Chen et al., arXiv:2505.05410, 8 May 2025). The detail that kills the obvious excuse: unfaithful chains were on average substantially *longer* than faithful ones.

*On a small model it can hurt.* Two independent reasons: the model may be weak at the *format*, with a `Thought:` line eating the budget a well-formed `Action Input:` needed; and a longer self-generated prefix is more room to accumulate an error it then conditions on confidently.

> **Misconception: "the thought is the reason."** It is a *sample* from a distribution over plausible-looking justifications, conditioned on the same prompt that produced the answer. Use it as a debugging aid — Atlas records `thought` on every `ReactStep` for exactly that — never as evidence about *why*. To learn why, change one thing and re-run; that is what `replay_trajectory` is for.

**Concept check 6.2.** You add "think step by step" to the system prompt and `resolved` drops. Name the two measurements to take before touching the prompt again, and which field of `Completion` to read first.

### 6.3 [core] Self-consistency

**Intuition.** If a hard problem has many routes to the same right answer and many routes to *different* wrong ones, sampling several routes and taking the commonest endpoint beats taking one. Wrong answers disagree with each other; right answers agree.

**Precisely.** Replace greedy decoding of one chain with: sample *k* chains at temperature > 0, extract the final answer from each, return the plurality, marginalising over reasoning paths. Wang et al. report gains across arithmetic and commonsense benchmarks including GSM8K +17.9%, SVAMP +11.0%, AQuA +12.2%, StrategyQA +6.4%, ARC-challenge +3.9% (arXiv:2203.11171, 21 Mar 2022; ICLR 2023).

**Algorithm in words.** The prompt does not change. Call *k* times at non-zero temperature, run an extractor over each reply, discard replies the extractor cannot read, count the survivors, return the mode. Cost is exactly *k* CoT calls — linear, predictable, fully parallelisable, which makes it the cheapest wall-clock accuracy gain here if you have the tokens.

**Three preconditions, and Atlas fails two by design.** It needs (a) a discrete *extractable* answer, so a mode exists; (b) temperature above zero, so samples differ; (c) *k*× the token budget. Atlas's answers are prose with citations, so (a) fails in general — there is no mode over paragraphs. Atlas pins `ATLAS_TEMPERATURE=0.0` and `ATLAS_SEED=7` for reproducible evals, so (b) fails by configuration. State the trade-off plainly: **Atlas bought reproducibility with the currency self-consistency spends.** Where it *can* apply is the narrow numeric sub-questions, which is Assignment 2.

**The result that generalises furthest.** Huang et al. re-ran multi-agent debate — several model instances critiquing each other — against self-consistency at matched response counts on GSM8K: standard prompting 76.7 at 1 response; self-consistency 82.5 at 3, 85.3 at 6, 88.2 at 9; debate 83.2 after round 1 (6 responses) and 83.0 after round 2 (9) (arXiv:2310.01798, Table 7). At six responses debate loses to voting; at nine it loses badly. The authors' reading is the one to keep: **the improvement is consistency across generations, not critique.**

> **Misconception: "self-consistency is a kind of self-correction."** They are opposites. Self-consistency never shows the model its own previous answer; that independence *is* the mechanism, exactly as in an ensemble. Self-correction introduces a dependence, and §6.9 is about what that does. If you feed sample *i* into sample *i+1* to "improve consistency", you have converted an ensemble into a Markov chain and thrown away the variance reduction.

**Concept check 6.3.** You have exactly nine model calls for one hard numeric question. Rank by expected accuracy and say what the ranking depends on: nine-sample self-consistency; one CoT call plus four rounds of self-critique (two calls each); a three-step ReAct episode with a calculator, run three times with voting.

### 6.4 [core] Reasoning models, and what they changed

**Intuition.** Everything in §6.2 is a user-space workaround for a model that answers as fast as it can. Instead *train* the model to spend a variable, self-determined amount of computation before answering, rewarding it on whether the answer was right rather than how it got there, and the scratch pad moves inside the product.

**Precisely.** A **reasoning model** is post-trained so inference emits an extended internal chain of thought before the visible answer, typically via reinforcement learning on outcome correctness. The recipe was published in the open by DeepSeek (DeepSeek-R1, arXiv:2501.12948, Jan 2025); the interface pattern is the one Phase 2 already wired in — a `think` parameter, a separate `thinking` field, and billing for tokens you often do not get back. *Which* models are reasoning models today, whether your Tier A tag is one, and what it costs are current-state facts: see the `VERSIONS.md` delta in §19, and run `ollama show $ATLAS_MODEL`.

**What actually changed, precisely, because the marketing is not precise.**

*The deliberation moved down a layer.* Composition that needed three ReAct steps can happen in one call. Phase 1's `p^n` improves not because *p* rose but because *n* fell — and *n* is the exponent, so that is the larger lever. This is the real gain and it is substantial.

*Per-call cost and latency rose; per-episode cost may fall.* One call takes far longer and emits many more billed tokens. Whether the episode is cheaper depends entirely on steps saved. Atlas's `CallBudget` counts calls and tokens separately for this reason (invariant 6: the cap is in tokens first), shipped in Phase 2 before it mattered.

*Nothing about the harness became optional.* This is the part people get wrong. A reasoning model still emits a tool call your code must decide whether to honour, still names tools that do not exist, still stops making progress. The seven exits, the batch validation, the step cap and the write refusal are unchanged by a better model, because none was compensating for weak reasoning. They compensate for a **non-deterministic caller on the other end of a contract**, and a better model is still one.

**Failure modes specific to them.** The visible chain is *less* trustworthy, not more, precisely because it is longer and looks more like work — recall the sub-20% reveal rate and the longer unfaithful chains. They fail differently under length: a model that has decided to reason for two thousand tokens inside a 640-token cap produces no answer at all. And overthinking is real — asked a one-lookup question, a reasoning model can spend a paragraph deciding whether to look it up.

> **Misconception: "with a reasoning model I don't need plan-and-execute."** Sometimes true, and it is the honest first thing to test. But the reason to write a plan down is not that the model cannot hold one; it is that a plan in a `Plan` object is **inspectable, checkable, and re-enterable by your code**, and a plan in a thinking trace is none of those. §6.11 is about what you can do to a DAG that you cannot do to a paragraph.

**Concept check 6.4.** Atlas's step cap is 6 and its output cap is 640 tokens. You switch to a tag with `thinking` and enable it. Which cap is now more likely to bind, and which trajectory field tells you it bound?

### 6.5 [core] ReAct, in depth

You built this in Phase 3. Now the argument for it.

**Intuition.** CoT lets a model condition on its own tokens. Everything in that loop came out of the model, so an error at token 50 is happily built upon at token 200 — nothing in the transcript disagrees. ReAct interleaves a second kind of content: an observation produced by the world. **That is the only text in the episode the model did not write, and the only text that can contradict it.**

**Precisely.** ReAct (Yao et al., arXiv:2210.03629, 6 Oct 2022; ICLR 2023) interleaves reasoning traces and task-specific actions: thought, action, observation, repeat. The reasoning updates the plan and handles exceptions; the actions gather information externally. Phase 3 implements both dialects — native tool calling and text `Thought/Action/Action Input` — over one loop differing in one pure function, because two loops would have made the comparison measure two loops.

**Why grounding is the whole point.** The mechanism is not "the model plans better". It is that every second turn injects a fact the model is not free to invent. Which is also why prompt injection is a ReAct problem specifically: the one trustworthy channel is the one an attacker wants to write to. Atlas's prompts say tool output is data rather than instructions, and Phase 3 shipped two eval tasks and two seeded injection fixtures for it — that instruction being the third line of defence, behind an absent tool and a dispatch-time check.

**When ReAct is right.** When the step count is unknown until you start; when the next action genuinely depends on the last observation; when tools are cheap and reversible; and when you want the reasoning in the transcript, because a text transcript is the thing you can stare at.

**When it is not.** Three cases, each an argument for a different strategy. *The plan is known* — "look up these three numbers and add them" spends a full call per lookup deciding the obvious, each carrying the whole transcript, so Phase 1's quadratic cost is paid for a decision nobody needed. *The subtasks are independent* — ReAct is inherently serial, so three independent lookups take three round trips. *The horizon is long* — by step 9, step 3's observation sits in the least-attended region, which is the third of the step cap's three justifications (reliability, cost, context rot).

**Failure modes in Atlas's vocabulary.** Every exit but `final` is a named ReAct failure: `no_progress` is the same call twice, `cycle` is two calls telling the agent what the other already told it, `bad_action` is a phantom tool, `no_output` a degenerate reply. Two that no guard catches, both motivating this phase: **the loop can finish successfully with a fabricated citation** (Phase 3 §8), and **the loop can spend its whole cap gathering facts and never combine them**, showing up as `step_cap` with a transcript of successful observations and no answer.

> **Misconception: "ReAct means the model plans."** ReAct means the model chooses one action at a time. There is no plan anywhere in the system — not in a variable, not in a field, not in a check. To assert anything about the agent's plan you must first create one, which is §6.7.

**Concept check 6.5.** An episode ends `step_cap` with six steps, six successful tool results, `tool_errors` empty, and `answer is None`. Which of ReAct's three structural weaknesses does this point at, and which single number would you change first? (Phase 3's pitfall list has an opinion about that number.)

### 6.6 [core] Verifiers: the cheapest reliability lever in existence

This comes before reflection deliberately. Reflection is what you do when you have no verifier, and you should know how good the alternative is before settling.

**Intuition.** Some problems are far cheaper to check than to solve. Factoring is hard; multiplying the factors back is trivial. Writing a function is hard; running its tests is trivial. Wherever that asymmetry exists you can buy reliability at *checking* prices — and buy it **deterministically**, with code that behaves the same every time and can be unit tested, which is true of nothing else in this book.

**Precisely.** A **verifier** maps a candidate output to a judgement and is (i) cheaper than producing the output, (ii) more reliable than the producer on the property checked, and (iii) *not the model*. Condition (iii) is what separates a verifier from a critic.

**The evidence is unusually clean, and it comes from the paper most negative about reflection.** Having shown intrinsic self-correction degrades reasoning, Huang et al. spend their conclusion on what does work, and the list is all verifiers: code-generation improves markedly through self-debugging when execution results are in the feedback prompt; a code executor is a perfect verifier when the problem specifies behaviour via unit tests, with error messages as informative feedback; and models verify and correct more effectively when interacting with external tools such as search engines and calculators. Sprague et al. reach the same place from the other side: CoT rarely beats a symbolic solver on the tasks where CoT helps most. Tree of Thoughts' entire advantage over sampling is a state-evaluation function. Three unrelated lines of work, one conclusion: **the reliability comes from the checker, not from the thinking.**

**Atlas has five verifiers, and you should be able to name them.** The calculator's AST whitelist (a parser is a verifier for "is this arithmetic"). The pydantic args model generated by `@tool` — the same object that advertised the shape (invariant 18). The query database, which returns `no such table` for a base table, so the guarantee lives somewhere you do not own (D-08). `resolve_in_jail`, which uses `Path.resolve()` and so catches a symlink `os.path.normpath` would wave through. And, new this phase, `check_result_kind` (§7.2).

**The one it most needed.** Phase 3's §8 episode cited `calculate` for a number `calculate` had refused to produce. Checking that claim needs no model: every tool named in `sources` must appear in `tools_called` and must have returned `ok=True` at least once. A dozen lines of pure Python over a trajectory, microseconds, cannot hallucinate, and it catches a failure a 100% pass rate hid. Phase 3 set the full audit as Assignment 1 (`atlas/safety/citations.py`); this phase ships the floor version in the critic (§7.4) so the tree is never without it, and generalises the move.

**The generalisation, which is Phase 4's central engineering claim.** Wherever a step is supposed to produce a particular *kind* of thing — a number, rows, a path, a yes/no — say so in a typed field, and check it in Python when the step returns. Not "does this look right", which needs a model; just: does this contain a parseable number? Does it have more than one line and a separator? That check beats a critic prompt on four counts — deterministic, so a test pins it; free, so it runs on every step; *specific*, so the complaint is actionable; and reproducible at 3 a.m. without a model.

> **Misconception: "a verifier has to be complete to be useful."** Phase 3 learned the hard version: a validator's *security* is exactly its completeness, which is why the SQL guard was replaced by a second database. *Reliability* is different. A shape check catching 60% of malformed step outputs has bought you 60%. The discriminator is **whether an adversary chooses the input**: for a hostile input, incomplete means useless; for a model's own sloppiness, incomplete means cheap.

**Your turn (5 minutes, no code).** Open `docs/ATLAS_SPEC.md`, pick three Atlas tasks, and for each write one sentence naming a property of the answer you could check *without a model* and without knowing the right answer. If you cannot find one, write down why. "The output is prose and any check is a keyword match" is a legitimate and important finding, and it is the answer for roughly half of them. That ratio is the honest scope of this lever.

**Concept check 6.6.** A teammate proposes replacing the mechanical citation audit with "ask the model whether the answer's sources are supported". Give two failure modes the mechanical version does not have, and one thing the model version can do that it cannot.

### 6.7 [core] Plan-and-execute

**Intuition.** Before a plumber opens a wall they write down what they need. They do not re-derive the shopping list at the hardware store. Writing it down costs five minutes and buys three things: the list can be checked before any wall is opened, the trip can be batched, and if the list is wrong that is a *visible event* rather than a slow drift into a bathroom you did not intend.

**Precisely.** Three phases. **Plan**: one call over the task and tool list produces a structure — steps, the tool each needs, the dependencies between them. **Execute**: for each step in dependency order, one call given the step's description and the results of exactly the steps it declared it depends on. **Synthesise**: one call over the collected results produces the answer.

The dated ancestor is Plan-and-Solve prompting (Wang et al., 6 May 2023; ACL 2023), worth reading because it is *not* what we are building — it is one call whose prompt asks the model to plan then execute, and its contribution is a diagnosis. The authors name three pitfalls of zero-shot CoT: calculation errors, missing-step errors, semantic misunderstanding errors, and address the middle one. That taxonomy is the useful part: **planning targets missing steps specifically**, and if your failures are calculation errors you should reach for a calculator. Anthropic's *Building Effective Agents* (Dec 2024) names the multi-call version orchestrator-workers: a central model breaks down tasks, delegates, and synthesises, recommended where you cannot predict the subtasks in advance.

**Worked example.** *Units shipped in Q1 per head of engineering?* ReAct: four calls, each carrying everything before it. Plan-and-execute: one plan (`s1` shipments, `s2` headcount, `s3` divide, depending on both), three execution calls, one synthesis — **five** calls. Plan-and-execute is not cheaper in calls on a short task, and anyone who says it is has not counted the planning call.

It wins on what each call *carries*. The `s1` call sees its step and nothing else; `s3` sees its step plus two numbers. ReAct's call 4 sees the whole transcript. Phase 1's `n·p0 + g·n·(n−1)/2` is a statement about transcript growth, and plan-and-execute breaks the quadratic term by refusing to give every step everything: the data-flow edges say what each step needs.

**When to use it.** Subtasks predictable from the question; several independent, so writing the independence down buys future parallelism; a horizon long enough that context rot is real; you need to *show a user what the agent intends* before it acts (Phase 12's approval gate, impossible without a plan object); or you want to assert something about intentions in a test.

**Failure modes — the mirror image of ReAct's.** *The plan is stale from the first observation* (§6.8). *A step's output does not fit the next step's assumption* — §8's trace, and `expects` plus `check_result_kind` is the fix. *The plan is a list wearing a graph's clothes*: five steps each depending on the previous is a planning call spent on a sequence. *Over-decomposition*: a three-step plan for a one-lookup question costs four calls where one would do.

> **Misconception: "planning makes the agent smarter."** Planning changes *what the model is asked at each moment*. Its whole leverage is that "find the Q1 shipment total" is an easier question than "answer this, here is everything that has happened". If your task does not decompose into easier questions, planning adds a call and removes context.

**Concept check 6.7.** Plan-and-execute costs five calls to ReAct's four above. Give the task property under which the ordering reverses, and a second under which plan-and-execute wins *while making more calls*.

### 6.8 [core] Replanning: a static plan is a lie about the world

**Intuition.** The plan was written by something that had not yet looked at the data. The first execution step is the first time the system learns anything, so the plan's expiry date is the first observation.

**Precisely.** A bounded loop: execute until something says the plan is wrong, then produce a new plan *given the old plan and what happened*. Two things make it defensible rather than a while-true.

**The triggers are enumerated.** Three should replan: a step failed in a way retrying will not fix; a step succeeded and its result contradicts the plan's premise (`0 rows` where rows were assumed); the plan completed but synthesis cannot answer the goal. Two should *not*: a step whose result failed its shape check on the first attempt — that is a **retry**, one call, same step, complaint attached — and a transport error, which belongs to the retry policy. **Confusing a retry with a replan throws away every completed step to fix one.**

**The cap is the harness's.** `max_replans=1`. Same argument as the step cap one level up: each replan multiplies the episode by roughly the cost of a plan. And it fails closed — exhausting replans exits `replan_cap`, never `final`.

The subtle part is what the replanner is *given*. Hand it only the task and it returns the same plan, deterministically at `temperature=0`, burning the allowance re-deriving a plan that already failed. Hand it the old plan plus the per-step notes and it is "this failed here, plan around it". That is where reflection genuinely earns its keep, and §6.9 explains why this case works when the general one does not.

**Concept check 6.8.** Your replan loop is entered, and at `temperature=0` with `seed=7` the new plan is byte-identical to the old. Name the input you forgot to pass, and the exit that should have fired instead of a second identical execution.

### 6.9 [core] Reflexion and evaluator loops — with the counter-evidence

This is where the literature disagrees with itself, and reading that disagreement is worth more than either result.

**Intuition.** People improve by failing, thinking about why, and writing the lesson down. An agent keeping a note saying "last time I searched for the wrong term" starts the next attempt better informed. No weights change; the improvement lives in text.

**Precisely.** Reflexion (Shinn et al., arXiv:2303.11366, 20 Mar 2023; NeurIPS 2023) converts binary or scalar feedback **from the environment** into verbal feedback — a textual summary in an episodic memory buffer — added as context for the next episode, acting as a semantic gradient signal. Note that phrase: in the paper's design, something outside the model says whether it succeeded. Self-Refine (Madaan et al., NeurIPS 2023) is the sibling where the model critiques and revises with no external signal. Anthropic's *Building Effective Agents* names the productionised version evaluator-optimizer, recommended specifically when there are clear evaluation criteria and iterative refinement provides measurable value. Both conditions in that sentence are doing work.

**The counter-evidence, decisive for the version without a verifier.** Huang et al. (arXiv:2310.01798, 3 Oct 2023; ICLR 2024, Google DeepMind and UIUC) define **intrinsic self-correction** as revision based solely on the model's own capabilities, and report accuracy dropping across every model and benchmark they tried. On GSM8K: GPT-4 95.5 → 91.5 after one round → 89.0 after two; GPT-3.5 75.9 → 75.1 → 74.7; **Llama-2-70b-chat 62.0 → 43.5 → 36.5**. On CommonSenseQA, GPT-3.5 falls 75.8 → 38.1. Call counts are in the same table: standard 1 call, round 1 is 3, round 2 is 5.

Three things to take.

*Not noise, not one bad prompt.* They tried several feedback prompts; all decreased performance without oracle labels.

*The mechanism is legible.* Answer-change analysis, GSM8K, GPT-3.5: 74.7% unchanged, **8.8% correct→incorrect, 7.6% incorrect→correct**, 8.9% incorrect→incorrect. The stated reason is the sentence to memorise: **models cannot properly judge the correctness of their reasoning.** Their intuition is worth having too — a feedback prompt is an *additional* prompt, biasing the model away from the response that was optimal for the original.

*The published gains came from a label.* Their Table 1 lists Reflexion and RCI under "use of oracle labels". With oracle labels, GPT-3.5 on GSM8K goes 75.9 → 84.3 — a real gain, obtained by using ground truth to decide when to stop, so the loop only ever revises answers already known to be wrong. That is not self-correction; it is filtering with an answer key. As the authors put it, if you have the ground truth there is little reason to deploy the model.

**The Llama-2 row is the one that matters for you.** Atlas runs on a small local model. 62 → 36.5 is a 25-point loss for two rounds of self-critique and four extra calls. Install a naive model critic and watch your pass rate fall, and you have reproduced a published result — recognise it rather than debug it.

**What survives** is exactly the cases with an external signal, which is §6.6's list. Huang et al.'s own conclusion says so. Reflection is not useless: **reflection is a transport mechanism for a verifier's output.** Give it a signal and it turns "test 3 failed with IndexError" into a targeted revision. Give it nothing and it turns a correct answer into a plausible one.

**Which produces Atlas's design rule — the sharpest thing this phase adds.** The critic has two tiers. `mechanical_findings` is a pure function, no model, no network. A model critic may then run and may **add** findings; it may **never clear** one. A mechanical `retry_step` cannot become `accept` because a model said it looks fine. The justification is the 8.8%-versus-7.6% row: a model asked to review is likelier to break a correct thing than to fix a broken one, so let it **raise** concerns, where a false positive costs one retry, and never let it **dismiss** them, where a false negative costs the answer.

> **Misconception: "more reflection rounds, more accuracy."** The published curve for intrinsic self-correction is monotonically *down* over two rounds on three of four models. Cap it at one; treat a second round as an experiment you must justify with a measurement. And note where the Anthropic post's "clear evaluation criteria" precondition gets cashed out: **if you cannot write the criterion in Python, you probably do not have one.**

**Concept check 6.9.** A colleague proposes: after Atlas answers, ask the model "is this well supported? If not, revise." Using the numbers above, predict the effect on `resolved` on Tier A and on tokens per episode, and name the one modification that would make the loop worth running.

### 6.10 [extended] Tree of Thoughts and search — reading only

*Nothing here is built and nothing in the fast track depends on it. Read it for the cost model.*

CoT commits to one path token by token; a wrong turn at step 2 is unrecoverable. Generate several candidate next steps, score them, keep the promising ones and abandon the rest, and you have converted reasoning into search.

**The algorithm in words.** Tree of Thoughts (Yao et al., arXiv:2305.10601, 17 May 2023; NeurIPS 2023) needs four things: a decomposition into *thoughts* (coherent intermediate units), a **generator** proposing candidate next thoughts, an **evaluator** scoring a state's promise, and a **search strategy**. BFS keeps the best *b* states per level; DFS commits and backtracks when the evaluator condemns; MCTS-style methods use rollouts to estimate value. LATS (Zhou et al., arXiv:2310.04406, Oct 2023) applies the idea to agent trajectories rather than reasoning steps.

**Where the cost pays off.** On Game of 24, GPT-4 with CoT solved 4% and ToT reached 74%. Enormous, and real. Game of 24 has the three properties search needs: a *cheap accurate state evaluator* (given four numbers and a partial expression, "can 24 still be reached" is nearly checkable), a *small branching factor*, and **free undo** — abandoning a branch costs nothing because nothing happened in the world.

**Where it is theatre.** The same paper's cost analysis: one Game of 24 problem with ToT takes about 5.5k completion tokens, close to 100 CoT trials at 6.7k. So the honest comparison is ToT versus a *hundred* samples — and the paper reports ToT still ahead. Two more details from the authors: GPT-3.5 with ToT reached 19% against GPT-4's 74%, and a generation/evaluation swap showed the bottleneck is thought *generation*, so ToT on a small model is mostly cost. And the project's own repository notes a post-paper re-run scoring **69% rather than 74%** from decoding randomness — a five-point swing on the headline number, disclosed by the authors, in a paper reporting one run per configuration. Phase 3's rule about pass^k did not come from nowhere.

**Why Atlas will never search over tool calls, stated once.** Search requires that expanding a node and abandoning it be free. `write_file` is not free. **Search needs an undo button, and side-effecting tools do not have one.** Where you *can* search is in a simulator, or over *plans* rather than executions — generate three candidate plans, score them with a cheap checker, execute one. That is a real technique, available in an afternoon once `validate_plan` exists, and it is out of the core because the scoring function is the hard part and Atlas has none.

**Concept check 6.10.** Atlas must draft a customer email and pick the best of several versions. Does ToT apply? Check the three properties and say which one decides it.

### 6.11 [core] Task decomposition, dependency graphs, DAG planners

**Orientation: DAGs, in two paragraphs.** A **directed acyclic graph** is nodes with one-way edges and no way to follow edges back to where you started. Here nodes are plan steps and an edge `s1 → s3` means "s3 needs s1's result". "Acyclic" is the interesting part: if `s2` needs `s3` and `s3` needs `s2`, no order lets both run — that is not a hard case to handle well, it is a case with *no* correct answer, which is why `topological_order` raises rather than complaining.

A **topological order** is any linear sequence in which every node appears after all its dependencies. Kahn's algorithm computes one by repeatedly taking the nodes with no unsatisfied dependencies, emitting them, and removing their edges; if nothing has zero unsatisfied dependencies but nodes remain, the remainder contains a cycle. The set emitted together in one round is a **level set**, and its size is the available parallelism — three steps ready at once means three calls could be in flight. Atlas's `ready_steps` returns the whole set even though Phase 4's executor takes only the first element, because that is the one place parallelism is cheap to compute and Phase 8 needs it.

**Why a graph rather than a list.** A list records the order *somebody chose*; a DAG records the constraint that forced it, and everything useful follows from having the constraint. You can detect an impossible plan before running any of it. You can pass each step exactly the results it declared — breaking the quadratic transcript term. You can fan out (Phase 8). You can show a user the shape of what is about to happen (Phase 12). And you can write an eval check asserting that execution respected the dependencies, which is a check about the *harness* and therefore legitimate under invariant 22, unlike a check scripting which tool step 2 uses.

**What a DAG planner is not.** Not a classical planner: no goal state, no action preconditions and effects, no search over plan space, no optimality guarantee. A model emits a candidate graph and code checks it for structural coherence. That is much weaker than STRIPS-style planning and it is the right weakness — Atlas's action space is seven tools with human-readable descriptions, and the interesting failures are semantic ("looked up the wrong department") rather than structural, which is precisely why the structural check should be cheap, total, and out of the way.

**Failure modes.** *Fake dependencies*, where a planner chains independent steps because it wrote them in an order, silently costing all the parallelism. *A plan of one step*, which is ReAct with ceremony. *Dependencies on steps that do not exist*, which `validate_plan` catches by name — the complaint lists the known ids, because a planner told only "s9 is unknown" will invent s10.

**Your turn (10 minutes).** Take three tasks from `docs/ATLAS_SPEC.md` §2 and write each as a DAG on paper: ids, tool per step, edges, `expects` kind. Count the level sets. If every task is a chain, either the tasks are genuinely serial or you are writing lists — check by asking, for each edge, *which specific value flows along it*. **An edge with no value flowing along it is a fake dependency.**

### 6.12 [core] Code as action, in one page [concept only]

*Concept only. The build is Appendix F.1, on a branch off `phase-04`. The Phase 3 sandbox stays because `run_python` uses it.*

**The idea.** Instead of one JSON tool call per step, the model emits a **program** whose function calls are the tools; the harness runs it and returns stdout. The action space stops being "one of seven functions" and becomes "any composition of seven functions, with loops, conditionals and variables".

**Why it cuts step count.** Control flow and data flow come free with a language. CodeAct (Wang et al., arXiv:2402.01030, 1 Feb 2024; ICML 2024) argues that compared to JSON or text with a pre-defined format, code inherently supports control and data flow, letting intermediate results be stored as variables for reuse and multiple tools be composed in one piece of code. Their example is the one to hold: applying a tool sequence to every element of a list is one `for` loop in code and one action per element in JSON. Across 17 LLMs on API-Bank and their own M3ToolEval (82 human-curated tasks typically needing multiple calls to multiple tools), CodeAct achieves up to a **20% absolute improvement in success rate while requiring up to 30% fewer actions**, with gains widening as capability rises. A secondary finding worth knowing: on *atomic* single-tool calls, with control flow ablated, CodeAct is merely comparable — so the advantage is composition, not formatting.

The token argument is now larger than the step argument. Anthropic's *Code execution with MCP* (Nov 2025) reports an example workflow falling from ~150,000 tokens to ~2,000 (98.7%) by having the agent write code that calls tools on demand rather than loading every definition and piping every intermediate result through context. The companion platform post (24 Nov 2025) reports 85% reduction from on-demand tool loading alone, and notes definitions plus results can consume 50,000+ tokens before the agent reads the request. Phase 3's registry already generates every description from one source of truth, so Atlas is well positioned; Phase 15 does it.

**Why it needs a real sandbox.** In JSON tool calling the action space is the intersection of what you exposed and what your validators accept; the model cannot express `open('/etc/passwd')` because there is no tool for it. In CodeAct the action space is the language, so the **only** boundary is the execution environment. Phase 3 measured Atlas's environment and published the result: `open('/etc/hostname')` succeeded and a socket to a public address succeeded from inside `run_python`. A `cwd` is not a jail and a scrubbed `env` is not a network policy. Atlas ships a resource-bounded subprocess; building the core loop on it would make a deliberately opt-in capability mandatory. Real containment is Phase 14.

**When JSON calls are safer**, in order of how often it decides. **Enumerable blast radius**: seven tools with generated schemas is an action space you can list in review; "arbitrary Python" is not. **Approval gates work**: showing a user `write_file(path=..., content=...)` is a gate; showing them a twenty-line program and asking if it is safe is a quiz. **Attribution survives**: one program calling four tools is one action with four effects, so the citation audit and per-tool authority both blur. **Weak models write bad code**, and a syntax error costs a whole step where a malformed argument costs a validation message.

**The rule.** Reach for code as action when the tools are read-only, the composition is real, the model can write correct code, and you have a container. Keep JSON calls when any single call must be individually approved, attributed, or refused.

**Concept check 6.12.** Atlas gains `send_email` behind an approval gate. Give the specific reason code-as-action and the gate are hard to combine, and one design recovering most of CodeAct's benefit without breaking it.

### 6.13 [core] What "reasoning" does and does not mean; benchmark contamination

**The honest position.** "Reasoning" here is a *behavioural* term: a model reasons if producing intermediate tokens improves accuracy on problems requiring composition. That is measurable and true. It is not a claim about mechanism, and three findings should stop you upgrading it into one.

*The visible chain is not the mechanism* — sub-20% reveal rates, longer unfaithful chains (§6.2, §6.4).

*Performance is fragile to instantiation.* GSM-Symbolic (Mirzadeh et al., Apple, arXiv:2410.05229, 7 Oct 2024) generates many instances of one problem from symbolic templates and reports that all models decline when only the numerical values change, that performance deteriorates as clauses accumulate, and — the striking one — that adding a single clause that *appears* relevant but contributes nothing causes drops of **up to 65%** across state-of-the-art models. Their hypothesis is that models replicate reasoning steps seen in training rather than reasoning formally. Read the critiques too: independent commentary has argued much of the reported variance falls inside the confidence interval you would expect from 100-question subsets — a lesson about reading error bars, not a refutation of the clause-insertion result.

*Some reported progress was memorisation.* Scale AI commissioned GSM1k, 1,000 fresh grade-school problems matched to GSM8K on solve rate, solution length and answer magnitude, and found drops of **up to 13%**, with the Phi and Mistral families showing systematic overfitting across almost all sizes while frontier families showed minimal signs (Zhang et al., arXiv:2405.00332, 1 May 2024). The mechanism is legible in their own statistic: a positive relationship (Spearman's r² = 0.32) between a model's probability of *generating* a GSM8K example and its GSM8K-to-GSM1k gap. **A model that can recite the test has partially memorised it.**

**Why this is an engineering section.** Three things you act on this week.

**A published number does not transfer.** It transfers to that benchmark, on that model, with that harness, on that date — which is why every measured number in this book carries tier, model, seed and date.

**A seeded corpus generator is the local answer to contamination.** `scripts/gen_dataset.py` produces byte-identical corpora from a seed, and Northwind Instruments does not exist, so no model has memorised its shipment table. Change the seed and you have a fresh instantiation of the same distribution — GSM-Symbolic's methodology, available as `ATLAS_SEED=8 make data`. **But this only works if your graders are computed rather than hard-coded**, which is D-20 and §7.9: my first draft's graders were substrings, three of them were seed-hedged into vacuity, and the sweep then reported 75% for an arm with no database access. A seed sweep over hard-coded expectations measures nothing.

**Fragility to irrelevant clauses is a design constraint on retrieval.** A single plausible irrelevant sentence costing up to 65% is a fact about *tool output* as much as about benchmarks: a `search_web` result returning three relevant snippets and one plausible irrelevant one is that experiment, run on your users. It argues for tight retrieval (Phase 5), for `max_output_chars`, and for the truncation notice Phase 3 insisted on announcing.

> **Misconception: "if it's fragile, it isn't reasoning."** Not a claim this book will adjudicate and not one you need. The engineering question is never *does it reason* but *what is the measured pass rate on my distribution, and what does the failure distribution look like*. Both are answerable; neither requires the word.

**Concept check 6.13.** A model scores 91% on a public agentic benchmark and 43% on your eval suite. Give three explanations that do not involve the vendor lying, and say which you can rule out first and how.

---

## 7. [core] Hands-on: build it step by step

### 7.1 [core] What we are building, and the six decisions

```mermaid
flowchart TB
    T[task] --> PL["make_plan()<br/>1 call, structured()"]
    PL --> V{"validate_plan()<br/>pure, no model"}
    V -->|complaints| PL
    V -->|ok| EX["execute ready step<br/>1 call + tools"]
    EX --> SC{"check_result_kind()<br/>pure, no model"}
    SC -->|fails, attempt 1| EX
    SC -->|ok| EX
    EX -->|no steps ready| CR["critique_plan()<br/>mechanical, then optional model"]
    CR -->|accept| SY["synthesise<br/>1 call"]
    CR -->|replan| PL
    CR -->|give_up| GU[stop_reason set, fail closed]
    SY --> A[answer + sources]
```

| File | Role |
|---|---|
| `atlas/schemas.py` (+) | `ResultKind`, `PlanDraftStep`, `PlanDraft` — what the model writes |
| `atlas/agents/plan.py` | `Plan`, `PlanStep`, DAG order, readiness, `check_result_kind`, `validate_plan` |
| `atlas/agents/critic.py` | findings, verdict, model critic, and the ReAct-side critic |
| `atlas/agents/planexec.py` | `run_plan_execute_agent`, `PlanExecTrajectory`, seven exits |
| `atlas/agents/strategies.py` | `run_direct`, `run_cot`, one `StrategyResult` for all four arms |
| `atlas/report.py` | `bar_chart`, `bar_chart_svg` — pure, dependency-free |
| `atlas/trace.py` (+) | the same render/save/load/replay set for the new record |
| four prompt files | versioned, checksummed, with changelog entries |

Six decisions worth arguing about before any code. Four are design; two are corrections of defects this build actually shipped, and they are in the list because **the mistakes are more instructive than the design.**

**D-15. The model's plan and the harness's plan are different types.** Two pydantic classes, which looks like a violation of invariant 13 until you ask which shape each describes. `PlanDraft` is the *output shape* — five fields, all things a planner can know. `Plan` is the *execution record* — nine fields per step, four written by the harness. Not two descriptions of one shape; two shapes, meeting only in `plan_from_draft`. The reason to insist: **a field the model can set is a field the model can lie about**, and a planner able to emit `status="done"` is a planner able to skip the work.

**D-16. A step declares the kind of result it will produce, and Python checks it.** §6.6 in code, and the phase's cheapest reliability lever.

**D-17. Mechanical findings first; a model critic may add, never clear.** §6.9's asymmetry, enforced in code rather than recommended in a docstring.

**D-18. Plan-and-execute gets its own closed `StopReason`.** `no_plan` and `replan_cap` are meaningless for ReAct; `no_progress` is meaningless here because the plan, not the model, decides what runs next.

**D-19. `extra="forbid"` is for schemas the model fills, not for records the harness writes.** I copied Phase 2's rule onto `PlanExecTrajectory` and every nested type, and the record could then not read its own file (§7.6). The narrower rule, with the discriminator being *who writes the object*: a model-facing schema forbids extras, so an invented key is a complaint; a harness record ignores them, so save → load → replay works.

**D-20. A grader's expected value is queried from the corpus, never hard-coded.** My first graders were substrings, and because shipment totals are seed-dependent I hedged three of eight into near-vacuity, at which point the sweep reported 75% for an arm with no database access (§7.9).

### 7.2 [core] The plan: types and pure functions

Everything in `atlas/agents/plan.py` is pure — no client, no clock, no I/O — so every claim in §6.11 is unit-testable with no model, and `make test-offline` covers the DAG logic completely.

```python
# excerpt: atlas/agents/plan.py
StepStatus = Literal["pending", "done", "failed", "skipped"]

MAX_PLAN_STEPS = 6

class PlanStep(BaseModel):
    """One step, plus the record of what happened when it ran."""

    id: str
    description: str
    tool: str | None = None
    depends_on: list[str] = Field(default_factory=list)
    expects: ResultKind = "text"

    # The execution record. Harness-owned; see the module docstring.
    status: StepStatus = "pending"
    result: str | None = None
    note: str | None = None
    """Why this step is in the status it is in. Read by the critic and the
    replanner, so it is written for a model to act on, not for a log grep."""
    attempts: int = 0
```

Three things. `status="done"` means *attempted, produced a result, and the result passed its shape check* — not "the tool returned without an error", which is the definition that let Phase 3's §8 episode succeed. `MAX_PLAN_STEPS = 6` is a named constant with a derivation: at Atlas's system-prompt size a six-step plan already costs more prompt tokens than Phase 3's whole default episode. And the prompt asks for two to five steps while the harness accepts six — deliberate, because **a limit stated only in a prompt is a preference; a limit in the harness is a limit.**

`Plan` is mostly `computed_field`s (invariant 11: an eval check can only name what survives `model_dump()`). The one with an argument in it:

```python
# excerpt: atlas/agents/plan.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def is_complete(self) -> bool:
        """Every step reached a terminal status AND none of them failed.

        Note what this is not: "nothing is pending". A plan whose last two
        steps were skipped because step 1 failed has nothing pending and is
        not complete. Fail closed, exactly as `stop_reason` defaults to
        `step_cap`.
        """
        return bool(self.steps) and all(s.status == "done" for s in self.steps)
```

Kahn's algorithm is four lines of idea and two details that matter more than the algorithm:

```python
# excerpt: atlas/agents/plan.py
def topological_order(plan: Plan) -> list[str]:
    """Step ids in an order that respects `depends_on`. Pure.

    Kahn's algorithm. Two details that matter more than the algorithm.

    It is **deterministic**: among the steps that are currently ready, it takes
    the one that appears earliest in `plan.steps`. An order that depended on
    set iteration would make an eval task pass or fail by dict ordering, which
    is the sort of flake that gets blamed on the model for a week.

    It **raises** rather than returning a complaint, because a cycle is the one
    plan defect with no execution order at all. The message names the steps
    still stuck, since "there is a cycle" is not actionable and
    "s2 and s3 depend on each other" is.
    """
    indegree = {step.id: 0 for step in plan.steps}
    for step in plan.steps:
        for dependency in step.depends_on:
            if dependency in indegree:
                indegree[step.id] += 1

    order: list[str] = []
    remaining = dict(indegree)
    while remaining:
        ready = [step.id for step in plan.steps
                 if step.id in remaining and remaining[step.id] == 0]
        if not ready:
            stuck = ", ".join(sorted(remaining))
            raise PlanError(
                f"plan has a dependency cycle among these steps: {stuck}. "
                "Every step must depend only on steps that come before it."
            )
        for step_id in ready:
            order.append(step_id)
            del remaining[step_id]
        for step in plan.steps:
            if step.id in remaining:
                remaining[step.id] = sum(
                    1 for d in step.depends_on if d in remaining
                )
    return order
```

`while remaining` is not a `while True`: every iteration removes at least one id or raises, so it terminates in at most `n` rounds. Invariant 9 applied to a helper — **if you cannot see the decrement, do not write the loop.**

And the verifier the rest of the phase leans on, two of five branches:

```python
# excerpt: atlas/agents/plan.py
    text = content.strip()
    if not text:
        return False, "the step produced no output at all."
    if kind == "text":
        return True, ""
    if kind == "number":
        if _NUMBER.search(text):
            return True, ""
        return False, (
            "this step must produce a number and its result contains none: "
            f"{text[:80]!r}. Re-run the step so that it returns a quantity, "
            "or fix the arguments if a tool refused."
        )
    if kind == "rows":
        lines = [line for line in text.splitlines() if line.strip()]
        if _EMPTY_ROWS.match(text) or _ROW_COUNT.search(text):
            return True, ""
        if len(lines) >= 2 and any(("|" in line or "\t" in line) for line in lines):
            return True, ""
        return False, (
            "this step must produce a table of rows and its result is not "
            f"tabular: {text[:80]!r}. Query the data again and return the rows."
        )
```

Two notes. **`"0 rows"` passes the `rows` check**, which surprises people: an empty result set is a well-formed table, "the query returned nothing" is an answer, and treating it as a shape failure sends the executor back to re-run a query that correctly found nothing. Distinguishing *malformed* from *empty* is the difference between a shape checker and a wishful one. And every complaint follows `execute()`'s D-10 house style — what was rejected, why, what to do — because the complaint is handed straight to the model on the retry, and "wrong shape" spends a call on nothing.

`validate_plan` returns a list and never stops at the first defect, for the reason Phase 3 found in `_explain_validation`: a model told only "sql is required" resends the invented key. On the deliberately awful plan in the solutions file it emits five complaints in one pass, including the available tool list — because a planner that hears "`email_ceo` does not exist" without being told what does exist will invent `mail_ceo`.

### 7.3 [core] The critic: mechanical first, and a model may add but never clear

```python
# excerpt: atlas/agents/critic.py
FindingKind = Literal[
    "step_failed",
    "wrong_shape",
    "no_result",
    "unmet_dependency",
    "unreached",
    "uncited_claim",
    "model_concern",
]

Verdict = Literal["accept", "retry_step", "replan", "give_up"]

MAX_STEP_ATTEMPTS = 2
```

Six mechanical kinds and one model kind. `MAX_STEP_ATTEMPTS = 2` is derived: Phase 3's tool contract already gives the model one corrected-arguments attempt inside `execute()`, so a second harness-level retry is the third bite at the same cherry.

`mechanical_findings` is pure over a `Plan`: a failed step, a step that never ran, a step marked done with no result, a step whose result its `expects` kind rejects, and — the interesting one — a step marked `done` whose dependency is not. That last is not about the model at all; it can only happen if the *executor* ran things out of order, making it a harness-bug detector living in the critic. One note worth more than it looks:

> The shape check runs again in the critic even though the executor already ran it. Not redundancy: the executor checks in order to *retry*, the critic checks in order to *report*, and the second must work on a `Plan` loaded from disk where no executor exists. **A verifier that only runs inline is a verifier you cannot use on a saved failure** — which is exactly when you need it.

The verdict is pure, and no model is consulted about what to *do*:

```python
# excerpt: atlas/agents/critic.py
    attempts = attempts_by_step or {}
    blocking = [f for f in findings if f.kind != "model_concern"]
    if not blocking:
        return "accept"
    retryable = [
        f
        for f in blocking
        if f.kind == "wrong_shape"
        and f.step_id is not None
        and attempts.get(f.step_id, 0) < MAX_STEP_ATTEMPTS
    ]
    if retryable and len(retryable) == len(blocking):
        return "retry_step"
    if replans_used < max_replans:
        return "replan"
    return "give_up"
```

Read `len(retryable) == len(blocking)` carefully: it encodes §6.8's retry/replan distinction. A retry fixes *one step*, so it is only right when every blocking finding is a retryable shape failure. One shape failure plus one step that never ran is a replan, because retrying the first will not reach the second.

The merge rule is three lines and the most important three in the module:

```python
# excerpt: atlas/agents/critic.py
    kept = [f for f in from_model if f.kind == "model_concern"]
    return [*mechanical, *kept]
```

Model findings are appended and filtered to `model_concern` on the way in, so a model emitting a `step_failed`-shaped finding cannot smuggle a blocking kind into the list. `verdict_for` treats `model_concern` as non-blocking. Together: **a model may raise a concern and may not settle one.** A test pins both directions, because this is the kind of property that survives in a docstring for about one refactor:

```python
# excerpt: tests/test_critic.py
def test_a_model_critic_cannot_clear_a_mechanical_finding() -> None:
    """§6.9's design, as a test. A happy model changes nothing."""
    plan = Plan(goal="g", steps=[done("s1", "I could not find it")])
    without = critique_plan(plan)
    with_happy_model = critique_plan(plan, client=FakeLLMClient(["NONE"]))
    assert without.verdict == with_happy_model.verdict
    assert with_happy_model.blocking
    assert with_happy_model.consulted_model is True
```

`consulted_model` is separate from "the model found something", per invariant 25: a sweep reporting no model concerns must distinguish *the model looked and was happy* from *no model looked*. And `critique_plan(plan)` with no client is the default, not a degraded mode. The eval harness leaves it off, because a model critic is a source of variance the suite must not inherit silently.

### 7.4 [core] The same critic over a Phase 3 episode

The phase brief asked for reflection layered onto the Phase 3 agent, and my first draft critiqued only plans — which quietly changed the scope from *add a critic to Atlas* to *add a critic to the new agent*. A ReAct transcript has no `expects` declarations, so three of the mechanical kinds have no analogue. What is left still needs no model:

```python
# excerpt: atlas/agents/critic.py
    succeeded = {
        call.name
        for step in trajectory.steps
        for call, result in zip(step.calls, step.results)
        if result.ok
    }
```

Three findings follow. `no_result` when the episode ended without an answer. `step_failed` when *every* call to a tool errored — note "every", because one error followed by a success is not a failed tool, and a test pins that. And `uncited_claim` when the answer cites a tool that never succeeded, which is **Phase 3 §8's failure caught with no model**:

```python
# excerpt: tests/test_critic.py
def test_phase_3_section_8_is_caught_with_no_model() -> None:
    """Right answer, fabricated provenance: cited a tool that only errored."""
    from atlas.agents.critic import mechanical_findings_for_react

    traj = react_episode(
        answer="20", sources="- calculate: engineering + sales",
        steps=[react_step("calculate", ok=False)],
    )
    kinds = {f.kind for f in mechanical_findings_for_react(traj)}
    assert "uncited_claim" in kinds
    assert "step_failed" in kinds
```

Both entry points feed the same `verdict_for`, so there is **one policy for two agents** — which is the whole reason the critic is its own module rather than a method on either trajectory. Citation matching is against the *offered* tool list rather than by parsing prose, because "which words here are tool names" is undecidable and "which of these seven strings appear" is not. This is the floor, not the ceiling: if you built Phase 3's Assignment 1 (`atlas.safety.citations`), prefer it — but the floor now ships in the tree, so Atlas is never without the check.

The harness attaches it to any task setting `setup.critique: true`, with no client, exposing a `critique.` field prefix. Eval task 4 grades exactly the §8 episode: answer present, `stop_reason="final"`, and `critique.verdict == "give_up"`.

### 7.5 [core] Four prompts, and what each is not allowed to say

Four versioned files, all checksum-pinned with changelog entries. Their section sets deliberately differ, which is itself a design statement:

```python
# excerpt: atlas/prompts/__init__.py
    "atlas_planner": ("Role", "Goal", "Tools", "Output", "Rules"),
    "atlas_executor": ("Role", "Goal", "Constraints", "How to work"),
    "atlas_synth": ("Role", "Goal", "Your answer"),
    "atlas_critic": ("Role", "Goal", "Output"),
```

The planner has `Output` and no `Constraints`, because it cannot act — the constraint that matters for a planner is a rule about what to plan. The executor has `Constraints` (it acts, so it needs the injection rule and the read-only rule) and no `Output`. The synthesiser alone owns the answer shape. Uniform lists would have hidden all of that.

Four contract tests state what each prompt is *forbidden* to contain, and those are the interesting ones:

```python
# excerpt: tests/test_prompts.py
def test_the_critic_prompt_does_not_ask_the_model_for_a_verdict() -> None:
    """§6.9: the model is asked what it noticed, never what to do. The verdict
    is `verdict_for`, a pure function."""
    critic = load_prompt("atlas_critic", version=1).text.lower()
    assert "not going to fix it" in critic
    assert "do not propose a new plan" in critic
    for word in ("accept", "replan", "give up", "retry"):
        assert word not in critic
```

That is a prompt test enforcing an *architectural* decision. `accept` and `replan` are banned because if they appear, someone will eventually parse them, and the moment the model's word becomes the verdict, `verdict_for` is decoration and invariant 9 is gone.

The critic prompt also does something worth copying: it tells the model there is a *second reviewer* — a program that has already checked which steps failed, which never ran, and which returned the wrong kind — and asks it to look only for what a program cannot see (a result answering a different question than its step asked, units that do not match, a gap the results paper over). Division of labour in the prompt, so it does not spend its 256 tokens re-deriving findings the mechanical critic has.

Two pinned prohibitions carry §8 forward: the synthesiser is told a tool that returned an error produced nothing and must not appear in the sources, and that a `NOT AVAILABLE` step result must not be filled in from its own knowledge. Both are the *third* line of defence, behind the shape check and the tool's own refusal — in the prompt because they are cheap there, not because they are reliable there.

### 7.6 [core] The loop, its exits, and two defects it shipped

Two nested loops, so termination is stated rather than assumed: the outer is a `for` over `range(max_replans + 1)`, the inner a `for` over the remaining step budget, decremented on every executor call. No `while True` anywhere.

```python
# excerpt: atlas/agents/planexec.py
PlanExecStopReason = Literal[
    "final",
    "no_plan",
    "bad_plan",
    "step_failed",
    "replan_cap",
    "step_cap",
    "token_budget",
]

DEFAULT_MAX_EXEC_STEPS = 8
DEFAULT_MAX_REPLANS = 1
DEFAULT_PLAN_TOKENS = 768
```

Three constants, three derivations. `DEFAULT_MAX_EXEC_STEPS = 8` exceeds `MAX_PLAN_STEPS = 6` because retries and replans both draw on it: one number caps the whole episode however the failure unfolds. `DEFAULT_PLAN_TOKENS = 768` exceeds the executor's 640 because a truncated plan is unrecoverable (`OutputTruncated` raises rather than repairing) while a truncated step result fails its shape check and retries.

**I drafted eight exits and deleted one.** `plan_cycle` was in the first version, with a `try/except PlanError` around `ready_steps`. But `validate_plan` calls `topological_order` *before* execution, so a cyclic plan is already a `bad_plan` and nothing downstream could set the new reason. The exit was dead, the handler was an untested branch that looked like coverage, and both survived a first draft *and* a passing test suite — because **a stop reason that never fires breaks nothing**. Replaced by a comment and a test asserting the exact set.

The executor's inner loop is short and every line is a decision:

```python
# excerpt: atlas/agents/planexec.py
            pending = ready_steps(plan)
            if not pending:
                break
            step = pending[0]
            steps_used += 1
            executed = _execute_step(
                client,
                plan,
                step.id,
                registry=registry,
                n=steps_used,
                plan_index=plan_index,
                allow_writes=allow_writes,
                complaint=step.note if step.attempts else None,
                temperature=temperature,
                seed=seed,
                max_tokens=max_tokens,
            )
            traj.steps.append(executed)
```

`ready_steps(plan)[0]` is where the graph, not the model, chooses — which is why there is no `no_progress` guard: **the model cannot repeat a call because it is not choosing.** `complaint=step.note if step.attempts else None` is the retry channel, so the second attempt is told *"this step must produce a number and its result contains none: 'I was unable to work that out'"* rather than "try again".

The retry itself is not code. A shape-failed step is left `pending`, so `ready_steps` offers it again. One place decides what runs next and it is the graph, which is why a `retry_step` verdict after the loop routes straight to `step_cap`:

```python
# excerpt: atlas/agents/planexec.py
        if critique.verdict == "retry_step":
            # Only reachable when the step budget ran out part-way through a
            # retry: a retry with budget left is performed by the inner loop,
            # because `ready_steps` offers a shape-failed step again while it
            # is still pending. One place decides what runs next, and it is the
            # graph -- a second retry mechanism here would be a second answer
            # to the same question.
            traj.stop_reason = "step_cap"
            return traj
```

**Defect one: an early return that did not advance state.** The phantom-tool branch in `_execute_step` fires `unknown_tool_names`, dispatches nothing (invariant 24, one loop over), records the note, returns. It did not touch `step.attempts`. So the step stayed pending with zero attempts, `ready_steps` offered it again, the model named the phantom tool again, and the episode burned its whole step budget on one step — exiting `step_cap` rather than `step_failed`, pointing a debugger at the wrong number. **A misattributed exit is worse than a missing one, because it is actionable in the wrong direction.** Caught by `FixtureExhausted: fixture had 3 response(s); call 4 has nothing to return`, which is a nice property of scripted fixtures: an unexpected extra call is a loud failure, not a slow one. The rule: **every path out of a retryable unit must advance that unit's state, or the retry guard is not a guard.**

**Defect two: the record could not read its own file, and then under-reported its cost.** `PlanExecTrajectory` and every nested type shipped with `extra="forbid"`, copied from Phase 2's schema rule. `model_validate(traj.model_dump())` raised 22 errors, because the dump carries every `computed_field` (invariant 11) and on the way back those keys look like extras. So a saved episode could not be reloaded and the whole `atlas.trace` path was dead for the new agent.

Relaxing the config exposed the worse half. The planning, critique and synthesis token counters were pydantic *private* attributes, on the reasoning that a field a caller can set is a field a caller can forge. Private attributes are absent from `model_dump()`, so a reloaded episode reported **281 tokens instead of 866 and 1 model call instead of 3** — silently, no error, in the direction that flatters the arm whose whole cost story is overhead. They are now ordinary fields:

```python
# excerpt: atlas/agents/planexec.py
    overhead_prompt_tokens: int = 0
    overhead_completion_tokens: int = 0
    overhead_calls: int = 0
    """Planning + critique + synthesis calls. Named `overhead` because that is
    what it is: the price plan-and-execute pays before any step runs."""
    overhead_latency_s: float = 0.0
```

Two rules fall out. **D-19**: `extra="forbid"` is for schemas the *model* fills; a record the *harness* writes must accept its own dump. And **invariant 31, which widens invariant 11 by one level**: anything a computed total *depends on* must itself survive `model_dump()`, not just the total. The test I had written asserted the keys were *present* and passed throughout; the test that catches this asserts value equality after a real round trip:

```python
# excerpt: tests/test_planexec.py
def test_every_computed_total_survives_a_round_trip(registry) -> None:
    """Not just "the key is present": the VALUE must be the same value.

    The weaker assertion passed while `total_tokens` came back a third of its
    real size, because the fields it is computed FROM were private.
    """
    from atlas.agents.planexec import PlanExecTrajectory

    client = FakeLLMClient([
        CHAIN, tool_call("calculate", expression="14+6"),
        tool_call("calculate", expression="20*3"), FINAL,
    ])
    traj = run_plan_execute_agent(client, "task", registry=registry)
    back = PlanExecTrajectory.model_validate(json.loads(json.dumps(traj.model_dump())))
    assert back.total_tokens == traj.total_tokens > 0
    assert back.n_model_calls == traj.n_model_calls == 4
    assert back.latency_s == traj.latency_s
    assert back.executed_order == traj.executed_order
    assert back.plan is not None and back.plan.step_ids == traj.plan.step_ids
```

The same review found `token_budget` checked only *inside* the step loop, making it a soft cap: a planning call on a long tool list can exceed the whole allowance on its own, and the episode could still return `final`. It is now checked after planning and before synthesis too, with a test that the budget can bind before any step runs.

Finally, `make_plan` returns a five-tuple rather than raising, and the parameters that make a replan different from a retry of the planner:

```python
# excerpt: atlas/agents/planexec.py
    if previous is not None:
        user = (
            f"Request: {task}\n\n"
            "Your previous plan was carried out and did not answer the "
            "request. Here it is, with what happened:\n\n"
            f"{render_plan(previous)}\n\n"
            "Problems found:\n"
            + "\n".join(f"- {f.detail}" for f in findings)
            + "\n\nWrite a different plan that avoids these problems. Keep the "
            "steps that produced usable results and change the ones that did "
            "not."
        )
```

Without `previous` and `findings`, a second planning call at `temperature=0` with `seed=7` returns the byte-identical plan. This is also the one place Atlas uses reflection as §6.9 permits: **the findings it reflects on come from a verifier, not from a model's opinion.**

**Concept check 7.6.** `DEFAULT_MAX_EXEC_STEPS = 8`, `MAX_PLAN_STEPS = 6`, `MAX_STEP_ATTEMPTS = 2`, `DEFAULT_MAX_REPLANS = 1`. Construct the worst-case episode: how many executor calls, how many planning calls, how many total model calls, and which exit fires?

### 7.7 [core] Making the failure readable: `atlas.trace` for the new record

Phase 3's `atlas.trace` is typed entirely to `ReactTrajectory`, and my first draft added a second agent without extending it. The result: a phase whose `FAILURE_LOG.md` told you to *open five failing plan-and-execute trajectories* while `make trace` could not render one. **A ritual with no tool behind it is a ritual nobody performs**, so this is not a nice-to-have.

Four functions mirror the Phase 3 set: `format_plan_trajectory`, `save_plan_trajectory`, `load_plan_trajectory`, `plan_trajectory_as_fixtures`. Kept separate rather than made polymorphic — the two records genuinely differ, and one formatter branching on `hasattr` would render both badly to avoid rendering either specially.

The layout answers, in order, the three questions you have when you open a failure — *what did it intend, what did it actually run, what did the critic make of it* — and it prints superseded plans, because "what did it try first" is the question a replanning episode raises. Actual output, Tier F fixtures:

```text
──────────────────────────────────────────────────────────────────────────────
TASK  How many units per head?
STOP  final
COST  3 step(s) + 2 overhead call(s) = 5 model call(s), 1530 tokens, 0.00s
PLANS 1 (0 replan(s))
──────────────────────────────────────────────────────────────────────────────
PLAN 0
  Goal: g
    s1. add 14 and 6 [tool: calculate] [expects: number] [done]
        result: 20.00
    s2. triple it [tool: calculate] [needs: s1] [expects: number] [done]
        result: 60.00

STEP 1  s1  (plan 0)  shape: REJECTED
  <- I could not work that out
  !! this step must produce a number and its result contains none: 'I could
     not work that out'. Re-run the step so that it returns a quantity, or
     fix the arguments if a tool refused.

STEP 2  s1  (plan 0)  shape: ok
  -> calculate(expression='14+6')
  <- 20.00

STEP 3  s2  (plan 0)  shape: ok
  -> calculate(expression='20*3')
  <- 60.00

CRITIQUE 0 (mechanical)  ->  accept
  (no findings)
──────────────────────────────────────────────────────────────────────────────
ANSWER   60
SOURCES  - calculate: s1 and s2
SHAPE FAILURES   s1
──────────────────────────────────────────────────────────────────────────────
```

Note `3 step(s) + 2 overhead call(s)`. The overhead is printed *separately* because it is what plan-and-execute paid to plan, and a reader who cannot see it cannot compare the arms honestly. `plan_trajectory_as_fixtures` closes the loop: a saved failure becomes a `FakeLLMClient` fixture list, so you can replay it with the model held fixed and attribute any difference to your change. One honest caveat, in its docstring: the planner reply is re-serialised from the *parsed* plan, so a `no_plan` episode cannot be turned into a fixture this way — use `make record`, which freezes raw payloads.

### 7.8 [core] Four arms, one result type

`atlas/agents/strategies.py` exists so §7.10's grid measures the strategies rather than four harnesses. One entry point, one result type, one place where temperature, seed, `max_tokens` and the registry are set. The single most important line:

```python
# excerpt: atlas/agents/strategies.py
COT_SUFFIX = (
    "\n\nWork through this step by step before answering. Show each step, "
    "then give the answer."
)
```

A suffix on the *user* message, not an edit to the system prompt. In a second prompt file the arms would differ in ~800 tokens of instructions and the measured difference would be that. A test pins it:

```python
# excerpt: tests/test_strategies.py
def test_direct_and_cot_share_a_byte_identical_system_prompt(registry) -> None:
    """The arms must differ in one variable or the comparison measures two."""
    direct_client = FakeLLMClient([FINAL])
    cot_client = FakeLLMClient([FINAL])
    run_direct(direct_client, "t")
    run_cot(cot_client, "t")
    assert direct_client.calls[0][0].content == cot_client.calls[0][0].content
    assert cot_client.calls[0][1].content.endswith(COT_SUFFIX)
    assert direct_client.calls[0][1].content != cot_client.calls[0][1].content
```

The token cap is held fixed across the arms, deliberately. §6.2's second failure mode says a CoT arm at an unchanged cap can lose purely by truncation; holding the cap fixed *is* the experiment, and the result belongs in `docs/RESULTS.md`, not in a cap `run_cot` quietly raises.

Two more. `n_model_calls` on the plan-execute arm counts planning, critique and synthesis as well as steps — counting only steps would let it report four calls for an episode that made seven, **the accounting error that makes a strategy look cheap**, and the same error the private-attribute defect committed by accident. And `allow_writes` defaults to `False` here while the agent loops default to `True`: a sweep runs the same eight problems dozens of times, and a sweep that can write files is a sweep whose corpus changes under it. **The default belongs to the caller's purpose, and this caller's purpose is measurement.**

`StrategyResult` carries `answered`, and it is not `correct`:

```python
# excerpt: atlas/agents/strategies.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def answered(self) -> bool:
        """Produced an answer at all. NOT "produced a correct answer".

        Kept separate on purpose. Whether the answer is right is graded by the
        eval suite's programmatic checkers against a known value; whether the
        episode terminated with something to grade is a property of the
        control flow, and conflating them is how a strategy that always says
        something scores well.
        """
        return bool(self.answer and self.answer.strip())
```

### 7.9 [core] The grader, and how I got it wrong

This is the section to read twice, because the defect it describes is the one this phase's own quiz asks you to diagnose.

The first draft graded by substring: each `Problem` carried `must_contain`, and a cell passed if the answer contained those strings. Shipment totals are seed-dependent — verified, 363 units at seed 7 and 305 at seed 8 — so rather than *compute* the expectation I hedged three of eight graders down to `"units"`, `"per"` and `"engineering"`. Strings almost any reply contains. The `direct` arm, which has no tools and cannot see the database, then scored **75%**, and I printed the chart.

The tell was in the output the whole time: **an arm with no database access was passing database questions.** A too-lax grader and a genuinely capable agent produce the identical number, which is exactly why quiz 6 exists and exactly why I failed it.

The fix is D-20. The expected value is *queried from the corpus the sweep just built*:

```python
# excerpt: scripts/phase04_results.py
    answer_sql: str
    """A read-only query against the seeded corpus returning ONE cell: the
    value the answer must contain. Written against the same curated views the
    agent is allowed to query, so a task the agent cannot answer is a task the
    grader cannot grade either -- which is the property you want."""
    tolerance: float = 0.51
    """How close a number must be. Default half a unit, so an answer rounded
    to the nearest integer passes and one that is out by one does not."""
```

and `grade` matches *numerically* against every number in the reply rather than by substring, so `"about 7.14 units"` and `"7.1"` both pass for 7.14 and `"81.9"` does not. Four properties this buys: it survives a seed change, making `ATLAS_SEED=8` a real re-instantiation (§6.13's contamination control); it cannot be satisfied by a fluent non-answer; a task the *agent* cannot answer is a task the *grader* cannot grade, because both are limited to the curated relations; and a reply containing no numbers fails however confident it sounds.

One more change came with it. The no-tool arms' fixtures now **guess confidently** rather than politely declining. On Tier A, a model asked a question it cannot look up usually answers anyway, and **a grid whose direct arm declines every question measures nothing about direct answering.** Whether the guess is right is then the grader's business, which is the point.

After the fix, on Tier F fixtures: `direct` 12%, `cot` 25%, both tool arms 100%. The `cot` figure includes one *honest* pass — on "how many more people are in engineering than in sales", the scripted chain reasons from wrong premises (16 and 8) to the right answer (8). Which is the eval suite's rule working as designed: **it grades what the agent produced, not the path it took**, and a lucky right answer is a right answer.

### 7.10 [core] `make results`: eight problems, four strategies, one run each

```bash
make plot                              # Tier F, offline, ~2 s: exercises the path
ATLAS_TIER=A make results              # the real sweep, ~35 min
ATLAS_TIER=A make results ARGS=--quick # three 1-hop problems, ~4 min
ATLAS_TIER=H make results              # [Tier H recommended] ~90 calls, cached
make plot SVG=docs/phase04.svg         # same figure, as a diffable SVG
```

**The problem set is chosen so the elaborate arm can lose.** Three of eight are 1-hop, two are 2-hop, three are 3-hop, and `hops` is recorded per problem because **a strategy comparison in which the elaborate arm wins every row is a comparison whose problem set was chosen to make it win.** One problem — 17% of 2400 — has an answer the no-tool arms should get right, because without at least one such problem the grid cannot show a cost with no benefit.

**No model grades anything.** A judge model would add a second variance source to a 32-cell grid, and §6.9's numbers are what happens when you trust a model to say whether work is good.

**Expected ranges — author estimate, unmeasured.** Tier A, `gemma4:12b`-class, seed 7, one run per cell:

| arm | correct | median calls | median tokens | median seconds |
|---|---|---|---|---|
| direct | 5–25% | 1 | 300–700 | 3–12 |
| cot | 10–35% | 1 | 500–1,100 | 6–20 |
| react | 40–70% | 2–4 | 1,200–3,000 | 25–70 |
| plan_execute | 35–70% | 4–7 | 2,000–4,500 | 45–120 |

I have measured **none** of these, and the two no-tool rows are lower than my first draft's precisely because the grader is now real. If your numbers disagree, your numbers are the data and this table is a paragraph in a book.

**Five diagnostic rows are computed for you**, and they are the ones that answer the phase's question rather than restate it: the plan-execute-minus-react delta at 1 hop and at 3 hops, and the share of plan-execute episodes with a replan, with a shape failure, and exiting `no_plan` or `bad_plan`. In the first draft these were placeholder rows in `RESULTS.md` that no code produced — and worse, the placeholders were labelled `median tokens, react` while the script wrote `tokens, react`, so a real sweep would have appended twenty rows beside seventeen orphans. The metric names now come from one `METRICS` tuple used to compute *and* to report: **invariant 18's "one description, generated", applied to a results table.**

**What Tier A shows and what it hides.** Honest: it is the tier Atlas ships on, it is free, and improvements measured on a small model are real rather than masked by a stronger model's slack. Misleading: the plan-execute arm needs the planner to emit valid JSON against a strict schema, and Phase 2 found structured output the shakiest capability in the stack on a small local model. So a low `plan_execute` on Tier A is ambiguous between *planning does not help here* and *this model cannot write a plan* — and those call for opposite actions. **Read the `no_plan` + `bad_plan` share first**; if it is large, you are measuring the second thing. Hence **[Tier H recommended]**: 32 episodes at ~90 calls sits well inside the 300 cap, is cached, and separates the strategy question from the structured-output question.

**And what one run per cell licenses.** Almost nothing about two arms within a few points of each other; the sweep says so in its own footer. At a true per-cell rate of 0.6, eight problems give a standard error of about 17 percentage points, so 62% versus 50% is entirely consistent with the arms being identical. Recall ToT's own repository noting 69% on a re-run of a published 74%. What 32 cells *can* separate is direct-versus-ReAct on tool-dependent problems, where the gap should be enormous — and if it is not, that is a fact about your problem set or your grader, and no other conclusion from the grid is safe until you have explained it.

One Tier F note that looks like a bug and is not: `ATLAS_SEED=8 make plot` shows the tool arms *failing* the shipment problems. The fixtures encode the seed-7 corpus (363), the grader queries the seed-8 corpus (305), and the mismatch is the grader working. **Under Tier F, a red cell means "this fixture is stale"** — which is worth knowing about a fixture set.

### 7.11 [core] What scripted fixtures prove, and what they do not

Every one of the 134 tests added this phase runs against hand-written fixtures.

A fixture proves things about **Atlas's code**: that a two-lookup-then-arithmetic plan executes `s1, s2, s3` and not `s3, s1, s2`; that a shape-failed step is offered again and the complaint reaches the retry prompt; that two shape failures mark the step `failed` and its dependents `skipped`; that a replan is handed the old plan and the findings; that a phantom name dispatches nothing; that seven exits exist and no eighth is reachable; that planning tokens are inside the total and survive a round trip. Each is a control-flow property, decidable, and it either holds or it does not.

A fixture proves **nothing** about whether a real model writes good plans — whether the planner picks `query_db` for a headcount question, fakes a dependency between independent steps, declares `expects: "number"` for a step that will obviously return rows, or whether plan-and-execute beats ReAct on your distribution. Those are facts about model behaviour; they go to `docs/RESULTS.md` with a tier, model, seed and date (invariant 1). The 100% pass rate on 26 eval tasks is a Tier F number and the report says so in its own header: *source: SCRIPTED FIXTURES — measures Atlas's code, not any model.*

One failure mode specific to fixtures, which bit me twice. **A fixture encodes my expectation of the call sequence**, so a change in call count surfaces as `FixtureExhausted` rather than a wrong answer. Mostly a gift — it is how the phantom-tool bug surfaced — but it also means a test can pass for a reason you did not intend if your fixture list happens to line up with different control flow. The defence is asserting on `executed_order` and `n_model_calls` rather than only on the answer, which is why nearly every test in `test_planexec.py` does. **And the deeper lesson from the round-trip defect: a test asserting that a key is present is not a test that the value is right.**

### With an assistant

**Safe to delegate.** Parametrised test grids once you have specified the rules — `(kind, content, expected)` tuples are exactly the tedium an assistant is good at and you can check each row by reading it. Extra `Problem` entries from a template. Translating `bar_chart` into `bar_chart_svg`. Changelog entries. Drafting the prompt files from the section lists — then read every line yourself.

**Not safe to delegate.** The `verdict_for` policy and the merge rule. An assistant asked to "add a critic" will write a model critic whose verdict is parsed from its reply, because that is what the training data is full of; it will look reasonable and it will reproduce §6.9's Llama-2 row. Same for the retry/replan boundary: the natural code has a retry loop *and* a replan loop with no rule about which fires. And — new to this list after the defects in §7.6 and §7.9 — **the serialisation config and the grader's expected value**. Both are one-line decisions an assistant gets wrong by default (it will copy `extra="forbid"` everywhere and write a substring grader), both are invisible in a passing smoke test, and both fail in the direction that flatters your results.

**One prompt that works:**

> In `atlas/agents/plan.py` I have `check_result_kind(kind, content) -> tuple[bool, str]` handling five `ResultKind` values. Write tests as two `@pytest.mark.parametrize` blocks, accept and reject. Constraints: (1) every reject case must assert the complaint is longer than 25 characters and starts lowercase, because complaints follow `execute()`'s D-10 style; (2) include `"0 rows"` as an *accept* case for `rows` — an empty result set is a well-formed table; (3) do not test any behaviour not already in the function, and if you think a case *should* pass but does not, tell me instead of changing the function. Show only the test code.

The third constraint earns its keep. Without it an assistant will helpfully "fix" the function to match a test it invented, and you will have a verifier whose behaviour was chosen by autocomplete.

---

## 8. [core] Debug this trace: the plan was fine and step 3's format broke step 4

> **Reconstructed, illustrative — not a captured run.** No Tier A model was available while this phase was written, and `format_plan_trajectory` did not exist when the failure was found. The *class* is real and `edge_complaints` exists because of it; treat the digits as illustrative and reproduce it yourself with `make trace`. My first draft labelled this "verbatim, Tier A", which was the phase breaking its own provenance rule one section after stating it.

```text
task: How many units shipped in 2026Q1 per person in engineering, and how does
      that compare with last quarter?
STOP  step_failed     PLANS 2 (1 replan)

PLAN 0
  s1. units shipped in 2025Q4        [tool: query_db]  [expects: number]
  s2. engineering headcount          [tool: query_db]  [expects: number]
  s3. total units shipped in 2026Q1  [tool: query_db]  [expects: rows]
  s4. divide s3 by s2                [tool: calculate] [needs: s3, s2]
                                                       [expects: number]

STEP 1  s1  (plan 0)  shape: ok
  -> query_db(sql="SELECT sum(units) AS units FROM v_shipments
                   WHERE quarter='2025Q4'")
  <- units / ----- / 341 / (1 row)

STEP 2  s2  (plan 0)  shape: ok
  -> query_db(sql="SELECT headcount FROM v_departments
                   WHERE department='engineering'")
  <- headcount / --------- / 14 / (1 row)

STEP 3  s3  (plan 0)  shape: ok          <-- the shape check PASSED
  -> query_db(sql="SELECT region, sum(units) AS units FROM v_shipments
                   WHERE quarter='2026Q1' GROUP BY region")
  <- region | units
     -------------------
     north  | 138
     south  | 121
     east   | 104
     (3 rows)

STEP 4  s4  (plan 0)  shape: ok          <-- and so did this one
  results you were given:
    - s3 (total units shipped in 2026Q1): region | units ... (3 rows)
    - s2 (engineering headcount): headcount ... 14 (1 row)
  -> calculate(expression="138 + 121 + 104 / 14")
  <- 266.43

CRITIQUE 0 (mechanical)  ->  accept   (no findings)

synthesis
  <- <answer>About 266 units per person in engineering, up sharply from
     2025Q4.</answer>
     <sources>
     - query_db: v_shipments and v_departments
     - calculate: the division
     </sources>
```

**Read the trace before hypothesising, one line each, no hypotheses (§6.15).**

1. The plan is correct. Four steps, right tools, right dependencies, no fake edges.
2. `s1` and `s2` declared `number` and returned one-row tables containing numbers. Passed.
3. `s3` declared `expects: "rows"` and returned rows. Passed — the result *was* rows.
4. `s4` was given `s3` and `s2` as text and emitted `calculate("138 + 121 + 104 / 14")`.
5. `calculate` returned a number. `s4` declared `number`. Passed.
6. The mechanical critic found nothing. Every step `done`, no unmet dependencies, no shape failures.
7. The answer cites `query_db` and `calculate`, both of which really ran and really succeeded.

**Only now, the hypotheses.**

The arithmetic is wrong: under precedence `138 + 121 + 104 / 14` is 266.4, not `363 / 14 = 25.9`. But the deeper error is that `s4` had to *reconstruct a total* from three regional rows, which the plan never asked anyone to do. There is a missing step: sum the regions.

**The first wrong step is step 3, and it is not the SQL.** It is the *plan's own declaration*: `s3` says it produces `rows` while `s4` needs a scalar. `GROUP BY region` is a defensible reading of "total units", and the shape check on `s3` did its job perfectly. Every guard fired correctly and the episode produced a confidently wrong number.

**The class of failure.** `expects` describes what a step *produces*. Nothing describes what a step *consumes*. So `check_result_kind` verifies each edge's **tail** and never its **head**, and the mismatch lives on the edge — which is precisely where a DAG was supposed to make things checkable. Phase 3's §8 was *right answer, fabricated provenance*; this is **wrong answer, immaculate provenance**, which is arguably worse because there is nothing for a citation audit to find. Note also what *did* work: `s1`'s result is never used, and the answer's "up sharply from 2025Q4" is a comparison against a number the arithmetic never touched — a second, quieter defect that only reading the trace top-to-bottom reveals.

**The fix, in order.**

1. **Harness, mechanical, no model.** A step's `expects` must be compatible with what its dependents *need*: if a dependent's tool is `calculate`, every dependency must declare `expects` in `{"number", "boolean"}`. A pure function over the graph, run by `validate_plan` before anything executes. **Assignment 1.**
2. **Tool.** Verify `calculate("138 + 121 + 104 / 14")` on your own build. If the AST walker is right, the trace's arithmetic is the model's transcription and that is a different bug, at `make record` level.
3. **Prompt, measured.** The planner prompt says one subject per step and arithmetic in its own step. It does not say *a step feeding `calculate` must produce a single number*. That is a v2, with a changelog entry and a `make results` row — third, because it is the least reliable of the three.

**Not on the list:** raising `max_replans` (plan 0 finished *successfully* with a wrong answer, so no replan was reachable — the critic had accepted); adding a model critic (it might have caught this and might equally have written "the calculation looks correct" — a `make results` experiment, per D-17).

**Concept check 8.** Fix (1) is a compatibility rule between a step's `expects` and its dependents' needs. Give one *false positive* it produces on a legitimate plan, and say whether you would ship it anyway.

---

## 9. [core] Common pitfalls & how professionals avoid them

**Comparing a new strategy to no baseline.** The commonest error here and the one the literature made repeatedly: Reflexion beat nothing; against the same call budget spent on voting it did not. *Avoid it:* every comparison has a `direct` arm and matches on **total model calls**, which is why `n_model_calls` counts planning and synthesis.

**A grader loose enough that a fluent non-answer passes.** §7.9, committed by this phase. *Avoid it:* compute the expected value from your corpus, compare numerically, and treat "an arm with no tools is passing tool questions" as a grader bug until proven otherwise.

**A test that checks a key is present rather than a value is right.** §7.6. Under-reported an arm's cost by 3× while passing. *Avoid it:* round-trip assertions use equality, and anything a computed total depends on must survive the dump (invariant 31).

**Copying a schema config onto a record.** `extra="forbid"` is right for what the model fills and wrong for what the harness writes. *Avoid it:* ask *who writes this object* before setting the switch (D-19).

**Adding a model critic before a mechanical one.** An assistant will do this for you. *Avoid it:* write down what a program can check first; the mechanical findings are also what keep the model critic's prompt short.

**Confusing a retry with a replan.** They differ by an order of magnitude in cost. *Avoid it:* two named constants, two verdicts, and one condition — `len(retryable) == len(blocking)` — saying when a retry is even applicable.

**Letting "the tool returned" mean "the step worked".** *Avoid it:* make success a predicate you wrote, not the absence of an exception.

**A stop reason nothing can set.** A dead exit breaks nothing, so nothing tells you. *Avoid it:* a test asserting the exact exit set, and for each member, name the line that sets it.

**An early return that does not advance state.** *Avoid it:* audit each `return` in a retryable unit for "does this touch attempts/status".

**A plan that is a list.** *Avoid it:* for each edge ask which specific *value* flows along it; no value, no edge. Then count level sets.

**Passing the whole transcript to every step.** Silently reintroduces the quadratic cost plan-and-execute exists to avoid. *Avoid it:* `dependency_context` passes only declared dependencies, and a test asserts a root step's context is empty.

**Shipping tooling for one agent and a ritual for two.** §7.7. *Avoid it:* when you add a second record type, extend the reader in the same commit — or the failure log's instructions are fiction.

**Reporting a single run as a measurement.** *Avoid it:* pass^k across three trials, and in a one-run sweep, a footer saying what it cannot distinguish.

**Believing a benchmark transfers.** *Avoid it:* generate from a seed, sweep the seed, and put every number in a file that demands tier, model, seed and date.

---

## 10. [extended] Industry perspective

**Most teams ship neither ReAct nor plan-and-execute.** They ship a *workflow* — a fixed pipeline with fixed control flow — with a small agentic loop at one step. Anthropic's *Building Effective Agents* (Dec 2024) makes this the central recommendation: find the simplest solution and add complexity only when needed, since agentic systems trade latency and cost for task performance. (The current page carries a banner noting the tooling landscape has changed since; the five patterns have not.) A workflow's failure modes are enumerable in review; a loop's are not.

**The plan object rarely earns its money on accuracy.** It earns it as the **approval surface** (you cannot approve a paragraph of thinking; a DAG with named tools is scannable in four seconds — Phase 12), the **observability surface** (`plans[0]` versus `plans[1]` plus `executed_order` plus `shape_failures` narrows a support ticket to one step; a 9,000-token transcript narrows it to an afternoon), and the **parallelism** (`ready_steps` returning three means three calls in flight; on a 40-second local model a three-way fan-out is 15 seconds versus 45, and teams under a latency SLA reach for a DAG for that alone).

**The trade-off nobody writes down.** Plan-and-execute concentrates risk in one call: if the planner is wrong, everything downstream is wasted, whereas ReAct degrades gracefully because each step is a fresh decision. So the sensible production shape is often *hybrid* — a plan whose steps are each a small bounded ReAct loop, which is Atlas's executor minus the loop, and Phase 9's orchestrator. If that sounds like it doubles the failure surface, it does, which is why you measure it rather than adopt it.

**Reasoning models changed the calculus without settling it.** Where the model holds the whole task, the scaffolding is overhead and teams have been deleting it. Where you need approval, attribution or fan-out, the plan is required for reasons unrelated to capability. The honest 2026 position: reach for a reasoning model first, add a plan when you need the plan as an *artifact* rather than as a crutch.

**Verifiers are where the serious engineering went.** Every team that got a coding agent working did it by wiring the test suite into the loop, not by improving the prompt. Unglamorous generalisation: your leverage is how cheaply you can check, and most "agent reliability" projects are secretly verifier-construction projects. If your domain has no cheap checker, that is the finding, and the response is to build one — a golden-set grader, a schema, a reconciliation query — not to add a critic.

**Interview questions** (model answers in the solutions file, §10).

1. A plan-and-execute agent has fine accuracy and unacceptable p95 latency, averaging five steps. What do you look at first, and what change has the largest expected effect?
2. A colleague adds a reflection loop and accuracy drops. Explain why, and say what would have made it work.
3. Design the planner/executor interface for a system with fifteen tools. Name three fields and defend each.
4. When would you choose code-as-action over JSON tool calls, and what must be true of your infrastructure first?
5. A vendor reports 91% on a benchmark; you get 43% internally. Give three non-dishonest explanations and say which you rule out first.

---

## 11. [core] Capstone increment: the Atlas Planner, Executor and Critic

*If your code diverged, start again from `atlas_phase_03.zip`.*

**Resume note.** Atlas has a second control-flow shape. It decomposes a request into a validated DAG with declared tools, dependencies and output kinds; executes in dependency order, passing each step only what it declared it needs; verifies each step's output shape with a pure function and retries with the specific complaint; skips a failed step's dependents; critiques mechanically and, optionally, with a model that may add concerns but never clear them; replans once with the old plan and the findings in hand; and synthesises a cited answer. Seven exits, one owned by the model. The **same critic also runs over a Phase 3 ReAct episode** and catches that phase's §8 failure with no model. Four strategies run behind one comparable result type, graded against values queried from the seeded corpus, with the comparison rendered as a chart and no new dependency. And every plan-and-execute episode can be printed, saved, reloaded and replayed.

**Files added (19).** `atlas/agents/{plan,critic,planexec,strategies}.py`, `atlas/report.py`, four prompt files, `scripts/phase04_results.py`, `evals/tasks/phase04.json`, `tests/{test_plan,test_critic,test_planexec,test_strategies,test_report,test_trace_planexec}.py`, `tests/hidden/test_phase04_a{1,2}.py`.

**Files changed (13).** `atlas/schemas.py`, `atlas/prompts/__init__.py`, `atlas/prompts/CHANGELOG.md`, `atlas/trace.py`, `evals/run.py`, `tests/test_prompts.py`, `tests/test_evals_harness.py`, `Makefile`, `docs/{DECISIONS,RESULTS,FAILURE_LOG}.md`, `ATLAS_INTERFACES.md`, `VERSIONS.md`.

**Interface changes.** All additive; nothing renamed or removed. Five worth a migration note:

- `evals.run.dispatch` gains a plan-execute branch and, on ReAct tasks, an opt-in `setup.critique: true` that attaches a model-free critique under a `critique.` field prefix. Existing tasks are untouched — the critique is opt-in *because* attaching it to every inherited task would change what those tasks measure.
- The check vocabulary gains `contains_all`; `ref` is now documented.
- `atlas.prompts.REQUIRED_SECTIONS` has six entries with **deliberately different** section sets; anything iterating it must not assume a common list.
- **`extra="forbid"` was removed** from `Plan`, `PlanStep`, `ExecutedStep`, `Critique`, `Finding` and `PlanExecTrajectory` (D-19). If you subclassed any of them expecting strict validation, they now ignore unknown keys — the model-facing schemas in `atlas.schemas` still forbid extras and always will.
- `FindingKind` gains `uncited_claim`, so an exhaustive `match` over it needs a new arm.

**Tests added: 134.** 402 → **536**, green under `make test-offline`. Plus 38 hidden tests across two assignment files, skipping cleanly until you start.

**+4 eval tasks.** 22 → **26** gradeable, plus one honest Tier A skip.

- `p04-plan-executes-in-dependency-order` [regression] — `executed_order == ["s1","s2","s3"]`, no replans, no shape failures, `plan.is_complete`, both tools cited, and `n_model_calls > n_steps` by `ref`: the accounting check.
- `p04-wrong-shape-is-retried-not-accepted` [capability] — prose where `number` was declared is rejected, retried, then succeeds: `shape_failures == ["s1"]`, `executed_order == ["s1","s1"]`, `attempts == 2`.
- `p04-replan-after-a-failed-step-keeps-the-episode-alive` [capability] — two shape failures fail `s1` and skip `s2`, critic returns `replan`, second plan succeeds: `n_replans == 1`, `plans.0.failed_ids == ["s1"]`, findings contain `step_failed` and `unreached`.
- `p04-react-episode-with-a-fabricated-citation-is-flagged` [regression] — Phase 3 §8 exactly: answer present, `stop_reason="final"`, and `critique.verdict == "give_up"` with `uncited_claim` and `step_failed`, `consulted_model` false.

Every one grades the **harness** (invariant 22). None asserts which tool the model picks.

**`make results` and the ranges.** Twenty-five `docs/RESULTS.md` rows, all `—`, with labels matching exactly what `--append-results` writes. The ranges are §7.10's table — **author estimate, unmeasured**. Read the `no_plan`/`bad_plan` share first, then the two hop-count deltas, then `correct` against `answered`.

**"Read five failing traces" — `docs/FAILURE_LOG.md`.** Five worked entries now: §8's edge-format defect; the phantom-tool early return that misattributed the exit; the eighth stop reason nothing could set; the saved episode that reported a third of its real cost; and my grader that a fluent non-answer could pass. The sixth entry is a stub with your name on it — and unlike the first draft, `make trace` can now render the trajectories it asks you to read. Three questions to hold: did the planner emit a chain where a level set was available; did `expects` match what the step's *consumer* needed; and is a `no_plan` exit a strategy result or a structured-output result?

**Repo tag: `phase-04`.**

---

## 12. [core] Mastery checklist

You are ready to move on if you can:

- Place all four strategies on the deliberation axis and name, for each, one failure mode its *shape* makes possible.
- State where CoT helps and where it does not, with the dated evidence, and two conditions under which it makes a small model worse.
- Explain why `temperature=0` makes self-consistency unavailable, and why voting beat debate at matched budget.
- Name three things a reasoning model does *not* make optional.
- Explain why `PlanDraft` and `Plan` are different types, and what a planner able to emit `status="done"` could do.
- Write `check_result_kind` for a new `ResultKind` with a D-10-style complaint, and say why `"0 rows"` passes.
- State the retry/replan boundary and the condition that decides it.
- Explain the critic's add-never-clear asymmetry and cite the number motivating it.
- Say which pydantic types in Atlas forbid extra keys and which must not, and why.
- Name the two questions a round-trip test must ask, and why "the key is present" is not enough.
- Reproduce §8's failure class in one sentence and say why no citation audit finds it.
- Look at a strategy grid and say whether the grader is trustworthy, using one arm as the tell.
- Say what one run per cell in a 32-cell grid does and does not license, with a number.
- Explain why code-as-action cuts step count, why it needs a container, and two cases where JSON calls are safer.
- Name Atlas's five verifiers, and one Atlas task for which no cheap verifier exists.

---

## 13. [core] Quiz

1. Plan-and-execute makes *more* model calls than ReAct on a three-hop task, yet its per-episode prompt cost grows more slowly. Explain both with reference to one formula and one function.
2. `is_complete` returns `all(status == "done")` rather than `not any(status == "pending")`. Construct the plan on which they differ, and name the Atlas principle the choice follows.
3. A model critic is shown a plan in which one step returned prose where a number was required, and replies `NONE`. What verdict does `critique_plan` return, and what exactly in the code makes it so?
4. Atlas's plan loop has no `no_progress` guard though ReAct's does. Give the structural reason, and name the guard whose absence that reason does *not* explain.
5. You raise `MAX_STEP_ATTEMPTS` from 2 to 4; pass rate is unchanged and median tokens rise 30%. Give two explanations and the trajectory field that distinguishes them.
6. A sweep reports `direct` at 70% on eight problems, four needing database access. What is the first conclusion, and what is it a fact about?
7. `PlanExecTrajectory.total_tokens` is a `computed_field`, so it appears in `model_dump()`. Explain how a saved episode could nonetheless report a third of its real cost, and give the one-line rule that prevents it.

---

## 14. [core] Coding assignments

### Assignment 1 — Edge compatibility: what a step *consumes* [fast track: do this one]

`expects` says what a step produces; nothing says what a step consumes, which is §8's defect. Add to `atlas/agents/plan.py`:

```python
def edge_complaints(plan: Plan) -> list[str]:
    """Every dependency edge whose tail cannot supply what its head needs."""
```

and call it from `validate_plan`.

**Acceptance criteria.** (1) Pure: `plan` is the only required parameter; no client, no registry, no I/O. (2) Returns complaints, never raises — including on a dangling dependency, which `validate_plan` already reports and which you must neither duplicate nor `KeyError` on. (3) A dependency of a `calculate` step must declare `expects` in `{"number", "boolean"}`; `rows`, `text` and `path` are all reported. (4) A step with `tool=None`, or a non-arithmetic tool, is unconstrained. (5) Every incompatible edge is reported, not just the first. (6) Each complaint names *both* ids and the offending kind, says what would be accepted, exceeds 60 characters, and starts lowercase. (7) `validate_plan` includes them, so a bad plan never executes — **a check that is not called is a comment**. (8) `make test-offline` stays green.

**UNAIDED CORE.** The **compatibility rule itself** — which tools require scalars, which kinds count as scalar, what happens on a dangling edge — and the choice to report rather than raise. Write those three as prose before writing a line. Delegate the parametrised tests; do not delegate the rule, because an assistant will produce a plausible one that quietly constrains every tool and breaks your `search_web` steps.

Hidden test: `tests/hidden/test_phase04_a1.py`. Run `make grade PHASE=04`. Do not read it.

**Stretch (ungraded).** What changes if a step declares a *consumed* kind explicitly rather than having it inferred from its tool? Argue both ways in three sentences; one of them is Phase 9's answer.

### Assignment 2 — Self-consistency over a numeric step [extended]

§6.3's preconditions fail for prose and hold for numeric sub-answers. Create `atlas/agents/vote.py`:

```python
class VoteResult(BaseModel): ...   # value, votes, usable, samples, total_tokens
                                   # + computed: agreement, tied
def extract_number(text: str) -> float | None: ...
def majority_number(samples, *, total_tokens=0) -> VoteResult: ...
def self_consistent_number(client, messages, *, k=3, temperature=0.7,
                           seed=7, max_tokens=256) -> VoteResult: ...
```

**Acceptance criteria.** (1) `extract_number` reads the first number, handles thousands separators (`1,412` is one number), signs and decimals, and returns `None` rather than guessing. (2) Unreadable samples are **discarded, not counted as a vote**; `usable` records the survivors. (3) `agreement` is `votes / usable`, never `votes / samples` — a garbled reply must not dilute confidence in a unanimous vote. (4) One-vote-each reports `tied is True`; a clear plurality `False`. (5) `self_consistent_number` makes exactly `k` calls, samples above temperature zero, and **varies the seed per sample** — a fixed seed with a fixed prompt makes every sample identical on a seeded backend and the vote is theatre. (6) `k < 1` raises `ValueError`; `k == 1` works. (7) `total_tokens` sums all `k` samples. (8) Every reported field survives `model_dump()` — and, per invariant 31, so does anything a computed field depends on.

Then answer with a measurement: **does `k=3` voting on the numeric steps of §7.10's problem set beat one sample at the same total call budget?** Matched budget means 3-sample voting on one problem against three problems solved once. Write the finding into `docs/RESULTS.md` with tier, model, seed and date, and note honestly whether eight problems can distinguish the two.

**UNAIDED CORE.** The **`agreement` denominator** and the **per-sample seed**. Both are one-line decisions determining whether the technique works at all, both are things an assistant gets wrong by default, and both are invisible in a passing smoke test.

Hidden test: `tests/hidden/test_phase04_a2.py`.

---

## 15. [extended] Case study: choosing a reasoning strategy for three business tasks

Northwind Instruments wants Atlas to handle three recurring jobs. For each, choose a strategy, justify it against this phase's evidence, and say what you would measure to find out you were wrong. 600–900 words. Do not write one answer three times; the interesting result is that all three differ.

**Task A — weekly ops digest.** Every Monday at 07:00: units shipped last week by region, open service tickets by age bucket, and the three commonest error codes in last week's notes. Identical shape every week. No latency budget. The numbers must be right or the digest is worse than nothing.

**Task B — answer a customer's technical question.** A support agent pastes a customer email. Atlas must find the relevant internal documentation, check whether the customer's device model is affected, and draft a cited reply. Every question differs. 30-second budget, because a human is waiting. A human reviews before sending.

**Task C — reconcile the quarterly shipment report.** Given a finance spreadsheet, check every line against the shipment database, list discrepancies, and classify each as a timing difference or a genuine mismatch. ~200 lines. Quarterly. Hours available. A missed discrepancy is a material error.

**Rubric (30 points).**

| | Criterion | Pts |
|---|---|---|
| 1 | **A** is a *workflow*, not an agent: fixed shape, so a plan is redundant and a planning call is pure cost. Credit for naming what stays agentic (nothing, or a bounded loop in the error-code step) and for noting a fixed pipeline's failure modes are enumerable in review. | 5 |
| 2 | **B** is ReAct's home case: unknown step count, next action depends on the last observation, tools cheap and reversible, and a 30-second budget a plan-plus-synthesis pair would consume. Credit for noting the reviewer changes the risk calculus in one direction only. | 5 |
| 3 | **C** is the decomposition case *and* the verifier case. Full marks require seeing that the interesting design is the **checker**: line-by-line reconciliation is a program, and a model is needed only for the timing-versus-mismatch classification. A 200-step DAG loses points; map-reduce with a deterministic diff and a model on the residue gains them. | 6 |
| 4 | **Evidence used correctly and dated**, at least three of: Sprague et al. 2024; Huang et al. 2023 on intrinsic self-correction *and* on external feedback; voting beating debate at matched budget; the ToT cost ratio; CodeAct's 20%/30%; GSM1k or GSM-Symbolic. No invented numbers. | 5 |
| 5 | **Cost and latency reasoned explicitly** per task, in calls and tokens, noting plan-and-execute pays planning and synthesis unconditionally. | 3 |
| 6 | **Verifier identified per task, or its absence stated honestly.** A: totals reconcile against a differently-shaped second query. B: citations must resolve to real documents (mechanical); "is this reply good" has no verifier and the reviewer *is* it. C: the reconciliation is the verifier. An answer that finds none for B and says so scores better than one inventing a judge model. | 4 |
| 7 | **Falsification named** per task, with the field or `stop_reason` distribution to read. "I would measure accuracy" scores zero; "a `bad_plan` share above 20% on C means I am measuring structured output, not strategy" scores full. | 2 |

**Automatic deductions.** −3 for a model critic without a mechanical one first. −3 for any undated or invented number. −3 for a grader that a fluent non-answer would pass. −2 for one strategy across all three without an argument that the tasks are secretly one task.

---

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start Phase 5.*

**A reasoning strategy is a control-flow policy, not a prompting trick.** Four strategies on one axis — *where the deliberation happens*: nowhere (direct), in one call's output tokens (CoT), between calls informed by the environment (ReAct), or once up front in a structure the harness owns (plan-and-execute). The distinction that predicts behaviour is the **commitment moment**: ReAct never commits, so it adapts and can wander; plan-and-execute commits in call one, so it stays on task and can execute a plan the second observation already invalidated. **If the number of model calls does not change, you changed a prompt.**

**CoT buys scratch space, and the evidence has narrowed.** Wei et al. (28 Jan 2022) established it; Sprague et al. (arXiv:2409.12183, 18 Sep 2024) — 100+ papers, 20 datasets, 14 models — found the benefit is primarily math and logic, with MMLU direct ≈ CoT unless an equals sign is present, because the gain is in tracing intermediate steps, **which symbolic solvers do better, so CoT rarely outperforms them.** Where CoT helps most, a tool helps more. Failure modes: it eats the output cap (`finish_reason="length"` grades as zero); it can be unfaithful (Chen et al., arXiv:2505.05410, 8 May 2025 — reveal rates often below 20%, and unfaithful chains were *longer*); and on a small model a longer self-generated prefix is more room to accumulate an error it then conditions on.

**Self-consistency is an ensemble; self-correction is a Markov chain.** Sample *k* above temperature zero, extract, take the mode (Wang et al., 21 Mar 2022: GSM8K +17.9%). Three preconditions — discrete extractable answer, temperature > 0, *k*× tokens — and **Atlas fails two by design**, having bought reproducibility with the currency self-consistency spends. Huang et al.'s Table 7 is the result that travels: multi-agent debate at matched response count *loses* to voting (9 responses: 88.2 vs 83.0). The gain was consistency across generations, not critique.

**Reasoning models moved the deliberation down a layer and made nothing optional.** `p^n` improves because *n* fell, and *n* is the exponent. But the seven exits, the batch validation, the step cap and the write refusal are unchanged, because none compensated for weak reasoning — they compensate for a **non-deterministic caller on the other end of a contract**, and a better model is still one.

**Verifiers are the cheapest reliability lever, and the evidence comes from the paper most negative about reflection.** A verifier is cheaper than the producer, more reliable on the property checked, and *not the model*. Huang et al. (arXiv:2310.01798, 3 Oct 2023) show intrinsic self-correction *degrades* accuracy — GPT-4 on GSM8K 95.5 → 91.5 → 89.0; **Llama-2-70b-chat 62.0 → 43.5 → 36.5** — with the mechanism in the answer-change table: **8.8% correct→incorrect against 7.6% incorrect→correct**, because models cannot judge the correctness of their own reasoning. The published Reflexion-style gains used **oracle labels**, which is filtering with an answer key. What survives is the cases with an external signal: code execution, unit tests, calculators, search. **Reflection is a transport mechanism for a verifier's output.** Give it a signal and it targets a revision; give it nothing and it turns a correct answer into a plausible one. Atlas's five verifiers: the calculator's AST whitelist, the `@tool` args model, the query database, `resolve_in_jail`, and `check_result_kind`.

**Tree of Thoughts is real and expensive [reading only].** Game of 24: 4% → 74%. Also: ~5.5k completion tokens per problem, close to *100* CoT trials; GPT-3.5 with ToT reached 19%; the bottleneck is thought generation; and the authors' repo notes a re-run at 69% against a published 74%. Search needs a cheap evaluator, a small branching factor, and **free undo** — and side-effecting tools have no undo, which is why Atlas will never search over tool calls.

**The plan is a DAG the harness owns.** A list records the order somebody chose; a DAG records the constraint that forced it, and everything follows: refuse a cycle before running anything; pass each step *only* what it declared (breaking `n·p0 + g·n·(n−1)/2`); fan out later; show a user what is about to happen; assert in a test that execution respected the dependencies. `ready_steps` returns the whole **level set** because its length *is* the parallelism. For every edge, ask which value flows along it — no value, no edge.

**Six decisions, four by design and two after defects.** **D-15:** `PlanDraft` (what the model writes) and `Plan` (the execution record) are different types, because **a field the model can set is a field the model can lie about.** **D-16:** a step declares `expects` and `check_result_kind` verifies it — pure, free, testable, with a D-10-style complaint, and `"0 rows"` *passes* because an empty result set is a well-formed table. **D-17:** mechanical findings first; a model critic may **add** and may **never clear**, enforced by a three-line `merge_findings` and a pure `verdict_for`, with `accept` and `replan` banned by test from the critic prompt. **D-18:** seven exits of its own, no `no_progress` guard, because `ready_steps` — not the model — chooses. **D-19:** `extra="forbid"` is for schemas the *model* fills; a record the *harness* writes must accept its own `model_dump()`. **D-20:** a grader's expected value is *queried from the corpus*, never hard-coded.

**Five defects this phase committed, each with the rule it leaves behind.**

1. **The phantom-tool early return** did not touch `attempts`, so a bounded retry became a budget-consuming loop that exited `step_cap` instead of `step_failed`. **A misattributed exit is worse than a missing one, because it is actionable in the wrong direction.** Rule: every path out of a retryable unit advances that unit's state.
2. **An eighth stop reason, `plan_cycle`, that nothing could set**, plus a defensive `except` for an impossible case. Both survived a first draft and a 500-test suite, because a dead exit breaks nothing. Rule: for each member of a closed literal, name the line that sets it.
3. **`extra="forbid"` on a harness record** meant it could not read its own file, and the private token accumulators meant a reloaded episode reported **281 tokens instead of 866 and 1 call instead of 3** — silently, in the direction that flatters the arm whose whole cost story is overhead. Rule (invariant 31): **anything a computed total depends on must survive `model_dump()`, not just the total** — and a round-trip test asserts *value equality*, not key presence.
4. **`atlas.trace` was not extended** to the new record, so the failure log instructed you to read trajectories nothing could render. Rule: when you add a record type, extend the reader in the same commit.
5. **My own grader could be satisfied by a fluent non-answer.** Substring graders, three hedged into vacuity because shipment totals are seed-dependent, and the `direct` arm — no tools, no database — scored **75%** and I published the chart. The tell was in the output: an arm with no database access passing database questions. Rule: D-20, and treat that pattern as a grader bug until proven otherwise.

**The failure the phase leaves you (§8).** A four-step plan, entirely correct. `s3` declared `expects: "rows"` and returned rows — passed. `s4` was handed it as text, emitted `calculate("138 + 121 + 104 / 14")`, got a number — passed. Mechanical critic: no findings. `accept`. Answer cited two tools that really ran and really succeeded. **`expects` describes what a step produces and nothing describes what a step consumes**, so the check verifies each edge's tail and never its head — and the mismatch lives on the edge, exactly where a DAG was supposed to make things checkable. Phase 3's §8 was *right answer, fabricated provenance*; this is **wrong answer, immaculate provenance**, and no citation audit finds it. Fix order: `edge_complaints` in `validate_plan` (Assignment 1), then verify the calculator, then a *measured* prompt change. Not raising `max_replans` — plan 0 finished successfully.

**Measurement discipline.** 8 problems × 4 strategies × 1 run, graded against values *queried from the seeded corpus* and matched numerically. Three problems are 1-hop and one is answerable with no tools, so the elaborate arm *can* lose. The arms share a byte-identical system prompt and token cap, differing by `COT_SUFFIX` alone. `n_model_calls` counts planning, critique and synthesis. `allow_writes` is `False` in the sweep and `True` in the loops, because a sweep must not change the corpus it measures. Five diagnostic rows are computed, not left for you, and the row labels come from one `METRICS` tuple used to compute and to report. **One run per cell distinguishes almost nothing at close margins:** at a true rate of 0.6, eight problems give a standard error of ~17 points. No matplotlib — a pure function has tests and a rendered PNG does not.

**Scripted fixtures prove control flow and nothing about models.** They prove the execution order, that a complaint reaches the retry prompt, that a phantom name dispatches nothing, that seven exits exist and no eighth is reachable, that the totals survive a round trip. They prove nothing about whether a planner picks the right tool. That is `docs/RESULTS.md`, with a tier, model, seed and date. And: **a test asserting a key is present is not a test that the value is right.**

**Repo state at `phase-04`.** `plan.py` (all pure), `critic.py` (two tiers, add-never-clear, two entry points, one policy), `planexec.py` (seven exits, two bounded loops, hard token cap), `strategies.py`, `report.py`, plus `atlas.trace` extended to render/save/load/replay the new record. Four checksum-pinned prompts. `scripts/phase04_results.py` with `--quick`, `--svg`, SQL graders and computed diagnostics. **536 offline tests** (from 402), **26 gradeable eval tasks** (from 22, plus 1 honest skip), `ATLAS_INTERFACES.md` **v0.10** with invariants 26–32 and D-15 to D-20, five worked `FAILURE_LOG.md` entries plus a stub for yours, and **25 unmeasured `docs/RESULTS.md` rows** whose labels match the script exactly. **Ten assignments outstanding.**

**Phase 5 next:** documents. Chunking, embeddings, and the retrieval that turns `search_documents` from a keyword scorer into something that finds the answer — at which point three things here become load-bearing. GSM-Symbolic's up-to-65% clause result is a fact about *tool output* as much as about benchmarks, so tight retrieval is a reliability requirement rather than an aesthetic one. A retrieved chunk is the one thing in a transcript the model did not write, so Phase 3's citation discipline and this phase's shape verifier are what make retrieval trustworthy rather than merely impressive. And D-20 is the rule that will decide whether your retrieval evaluation means anything: a relevance grader you hard-coded is a relevance grader that measures your expectations.

---

## 17. [core] Further reading

Dated, linked, and every claim in this phase traces to one of these.

- **Wei et al., "Chain-of-Thought Prompting Elicits Reasoning in LLMs"** — arXiv:2201.11903, 28 Jan 2022; NeurIPS 2022. <https://arxiv.org/abs/2201.11903>
- **Kojima et al., "Large Language Models are Zero-Shot Reasoners"** — NeurIPS 2022, 35:22199–22213.
- **Wang et al., "Self-Consistency Improves Chain of Thought Reasoning"** — arXiv:2203.11171, 21 Mar 2022; ICLR 2023. <https://arxiv.org/abs/2203.11171>
- **Yao et al., "ReAct"** — arXiv:2210.03629, 6 Oct 2022; ICLR 2023. <https://arxiv.org/abs/2210.03629>
- **Shinn et al., "Reflexion"** — arXiv:2303.11366, 20 Mar 2023; NeurIPS 2023. Read *with* Huang et al. <https://arxiv.org/abs/2303.11366>
- **Wang et al., "Plan-and-Solve Prompting"** — arXiv:2305.04091, 6 May 2023; ACL 2023, 2609–2634. <https://arxiv.org/abs/2305.04091>
- **Yao et al., "Tree of Thoughts"** — arXiv:2305.10601, 17 May 2023; NeurIPS 2023. Read the cost analysis as carefully as the Game of 24 result. <https://arxiv.org/abs/2305.10601>
- **Huang et al., "Large Language Models Cannot Self-Correct Reasoning Yet"** — arXiv:2310.01798, 3 Oct 2023; ICLR 2024. **The most useful paper in this phase.** Tables 2, 3 and 7 and Figure 1. <https://arxiv.org/abs/2310.01798>
- **Zhou et al., "Language Agent Tree Search"** — arXiv:2310.04406, Oct 2023. <https://arxiv.org/abs/2310.04406>
- **Wang et al., "Executable Code Actions Elicit Better LLM Agents" (CodeAct)** — arXiv:2402.01030, 1 Feb 2024; ICML 2024. <https://arxiv.org/abs/2402.01030>
- **Zhang et al., GSM1k** — arXiv:2405.00332, 1 May 2024. <https://arxiv.org/abs/2405.00332>
- **Sprague et al., "To CoT or not to CoT?"** — arXiv:2409.12183, 18 Sep 2024; ICLR 2025. <https://arxiv.org/abs/2409.12183>
- **Mirzadeh et al., "GSM-Symbolic"** — arXiv:2410.05229, 7 Oct 2024, rev. 27 Aug 2025. <https://arxiv.org/abs/2410.05229> — read alongside the critique that much of the reported variance sits inside the confidence interval expected from 100-question subsets: <https://www.lakera.ai/blog/gsm-symbolic> (accessed 2026-09-04). A lesson in error bars, not a refutation of the clause-insertion result.
- **Chen et al., "Reasoning Models Don't Always Say What They Think"** — arXiv:2505.05410, 8 May 2025. <https://arxiv.org/abs/2505.05410> · Predecessor: Turpin et al., arXiv:2305.04388, NeurIPS 2023.
- **DeepSeek-AI, "DeepSeek-R1"** — arXiv:2501.12948, Jan 2025. The open recipe. <https://arxiv.org/abs/2501.12948>
- **Anthropic, "Building Effective Agents"** — December 2024. The five workflow patterns; note the current banner. <https://www.anthropic.com/engineering/building-effective-agents>
- **Anthropic, "Code execution with MCP"** — November 2025. <https://www.anthropic.com/engineering/code-execution-with-mcp>
- **Anthropic, "Introducing advanced tool use"** — 24 November 2025. <https://www.anthropic.com/news/advanced-tool-use>

---

## 18. [core] SOLUTIONS

Emitted separately as **`phase_04_solutions.md`**: worked answers for the cumulative review, all fifteen concept checks, the seven quiz questions, both assignments with reference implementations and the reasoning behind each UNAIDED CORE decision, the five interview questions, and a model answer for the case study.

---

## 19. [core] HANDOFF

**Confirmed inside `atlas_phase_04.zip`:** `ATLAS_INTERFACES.md` at **v0.10** — new sections for `atlas.agents.{plan,critic,planexec,strategies}`, `atlas.report`, `atlas.trace`'s four additions, and `atlas.agents.vote` as an assignment stub; `atlas.schemas` extended; the eval format documenting `contains_all`, `ref`, the new entrypoint and the `critique.` prefix; `plot` in the targets; `PHASE ?= 04`; invariants **26–32** — and `VERSIONS.md` with the Phase 4 delta and a corrections table.

**Verified in the zip before packaging:**

```
make test-offline            536 passed
make evals ARGS="--trials 3" 26/26 pass^k, 1 honest skip
make check-docs              every marked block matches the tree
make grade PHASE=04          2 skipped (assignments not started) — correct
make plot                    renders; --svg writes a diffable SVG
ATLAS_SEED=8 make plot       tool arms fail the shipment problems — the
                             grader working against stale fixtures
```

**VERSIONS.md delta rows:**

```
| fact | value | source URL | checked on |
|---|---|---|---|
| langchain latest (Phase 10 dep; NOT imported before Phase 9) | 1.4.0, uploaded 2026-09-03 | https://pypi.org/pypi/langchain/json | 2026-09-04 |
| langgraph latest (Phase 9 dep; NOT imported before Phase 9) | 1.2.11, uploaded 2026-08-11 | https://pypi.org/pypi/langgraph/json | 2026-09-04 |
| mcp Python SDK latest (Phase 15) | 2.1.1, uploaded 2026-08-25 | https://pypi.org/pypi/mcp/json | 2026-09-04 |
| pydantic pin — re-verified, unchanged | 2.13.5, uploaded 2026-08-28 | https://pypi.org/pypi/pydantic/json | 2026-09-04 |
| pytest pin — re-verified, unchanged | 9.1.1, uploaded 2026-06-19 | https://pypi.org/pypi/pytest/json | 2026-09-04 |
| httpx pin — re-verified, unchanged | 0.28.1, uploaded 2024-12-06 | https://pypi.org/pypi/httpx/json | 2026-09-04 |
| python-dotenv pin — re-verified, unchanged | 1.2.3, uploaded 2026-08-16 | https://pypi.org/pypi/python-dotenv/json | 2026-09-04 |
| Anthropic "Building Effective Agents" now carries a banner: much of the
  tooling landscape has changed since Dec 2024. The five workflow patterns
  are unchanged. | banner present |
  https://www.anthropic.com/engineering/building-effective-agents | 2026-09-04 |
| Token reduction from an agent writing code that calls tools, vs. loading
  all definitions and piping results through context | ~150,000 -> ~2,000
  tokens on one example workflow (98.7%) |
  https://www.anthropic.com/engineering/code-execution-with-mcp | 2026-09-04 |
| Token reduction from on-demand tool loading alone | 85%; definitions +
  results can consume 50,000+ tokens before the agent reads the request |
  https://www.anthropic.com/news/advanced-tool-use | 2026-09-04 |
| Which model for Tier A / Tier H this phase | unchanged from the Phase 3
  rows; re-run `ollama show $ATLAS_MODEL` and check the `thinking`
  capability before enabling `think` | (see Tier A / H rows above) | 2026-09-04 |
| New dependencies added by Phase 4 | none. The plot is atlas/report.py,
  pure Python | (this repo) | 2026-09-04 |
| Atlas verifier count (section 6.6 said four; the mastery checklist said
  five) | FIVE: calculator AST whitelist, @tool args model, query database,
  resolve_in_jail, check_result_kind | (this repo) | 2026-09-04 |
| Seed-dependence of the sweep's expected answers | headcounts are
  spec-fixed (38 total, 14 engineering at any seed); shipment totals are NOT
  (363 at seed 7, 305 at seed 8), which is why Problem.answer_sql queries
  rather than hard-codes | scripts/gen_dataset.py, both seeds run | 2026-09-04 |
```

*Pre-release APIs referenced but not used in code:* none new. Phase 4 is framework-free plain Python plus the Phase 2 client, per the Phases 1–8 stack rule. *Forward pointers:* CodeAct → Appendix F.1 (branch off `phase-04`); Tree of Thoughts and search → reading only, never built; parallel execution of a level set → Phase 8 (`ready_steps` already returns the whole set; the executor takes `[0]`).

**A note on length.** This document is about 21,000 words against a 14–17k budget, and the overrun is a real cost to you rather than a rounding error. The fast track is §1–§9 and §11–§14 plus §16, which is roughly 15,000 words; §6.10, §10 and §15 are tagged `[extended]` and nothing in `[core]` depends on them. Where the overrun is concentrated — §6.9's numbers, §7.6's and §7.9's defect write-ups — I judged the alternative worse: the phase's central design decision rests on those numbers, and a phase that hides the mistakes it made while lecturing you about reading failures would be teaching the wrong lesson twice.

**Downloads:** `atlas_phase_04.zip` · `phase_04_reasoning_and_planning_patterns.md` · `phase_04_solutions.md`
