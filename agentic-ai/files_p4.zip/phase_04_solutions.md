# phase_04_solutions.md

Worked answers for Phase 4 — *Reasoning and Planning Patterns: Chain-of-Thought,
ReAct, Plan-and-Execute, and Reflection*.

Read these **after** attempting the item. Several answers are longer than the
question deserves, because the reasoning is the point.

---

## §2 Cumulative review (Phases 1–2)

**1. Why `g·n·(n−1)/2` is quadratic, and one consequence for Phase 4.**

Every model call re-sends the entire conversation, so a transcript that grows by
`g` tokens per step is re-transmitted on every subsequent step; summing
`g·k` for `k = 0…n−1` gives `g·n·(n−1)/2`. You are paying repeatedly for the
*same* history.

Consequence for a phase adding a planner, executor and critic: those three
roles must **not** share one growing transcript, or the quadratic term is paid
three times per step. Which is exactly why `dependency_context(plan, step)`
passes only the results a step's `depends_on` names, and why the executor
prompt contains the goal, the step, and nothing else. Plan-and-execute's real
saving is not fewer calls — it usually makes more — it is that each call
carries `O(1)` history rather than `O(n)`.

**2. The two switches.**

`additionalProperties: false` in the emitted JSON Schema constrains the
**model** (strict-mode constrained decoding will not produce a key outside the
schema). `extra="forbid"` on the pydantic model constrains **your Python** — it
makes `model_validate` *raise* on an unexpected key.

Setting only the schema switch: pydantic's default is to silently **drop**
unknown keys. So a best-effort backend that is not doing constrained decoding
invents a field, your validator discards it without a word, and the object
validates. You get a silent partial parse rather than a complaint. (In pydantic
v2, setting `extra="forbid"` is also what *makes* pydantic emit
`additionalProperties: false`, which is why the two look like one switch until
you use a hand-written schema.)

**3. Why `structured()` is a function, not a method.**

Because it takes any object satisfying the `LLMClient` protocol, so a test can
pass a `FakeLLMClient` and assert on the whole repair path — the initial call,
the assistant echo, the repair message, the second call — with no network and no
subclassing. The capability depends on **`FakeLLMClient`** (and, structurally,
on `LLMClient` being a `Protocol` rather than a base class). A method on a
concrete client would have forced test doubles to inherit from it, and a
`structured` that only exists on `OllamaClient` cannot be tested at all offline.

**4. `RetryingClient` in or out of `BudgetedClient`?**

**Inside.** Invariant 14 governs wrappers that can return *without* calling
inward — a cache. A retrier is the opposite: it calls inward *more*. Put the
retrier inside the budget (`Budgeted(Retrying(base))`) and every retry is
metered, so three attempts cost three calls against your quota, which is the
truth. Put it outside (`Retrying(Budgeted(base))`) and each retry re-enters the
budget from the top; worse, a retry triggered by the budget's own
`BudgetExceeded` would be retried against an exhausted budget, spinning
`max_retries` times per call and reporting a transport failure. Your Tier H
quota then drains at up to `max_retries ×` the rate you believe, with no record
of it.

**5. The input that broke `{`-only search.**

A reply whose JSON payload is a **top-level array** — `[{"intent": "lookup"}]`
— or, more commonly, prose containing a brace-free bracketed list before the
object. Searching for `{` finds the *inner* object and returns it, so a caller
expecting a list gets the first element and never learns there were three; or,
if the array is the payload, the scan finds a `{` inside it and returns a
fragment. The caller saw either a `ValidationError` naming a field that *was*
present in the full payload, or — worse — a valid object built from part of the
answer. Choosing the opening bracket by **position** (whichever of `{` or `[`
comes first) fixes both, because the first bracket in the text is the start of
the payload whatever type it is.

---

## Concept checks

**6.1** — Fewest **model calls**: `direct` and `cot`, one each; among the
tool-using arms, ReAct (4: three lookups plus a final) beats plan-and-execute
(5: plan + three steps + synthesis). Fewest **sequential round trips**: only
plan-and-execute can be fewer than four, because the three lookups are declared
independent, so a fan-out gives plan (1) + lookups (1 round) + combine (1) +
synthesis (1) = 4 rounds against ReAct's 4 — and with the combine folded into
synthesis, 3. The two questions differ because a *call* is a unit of cost and a
*round trip* is a unit of latency, and independence converts one into the other.
Atlas at Phase 4 is sequential, so this advantage is latent; `ready_steps`
returning a list of length 3 is where it is recorded.

**6.2** — Two measurements before touching the prompt again. (1) The
distribution of `finish_reason` over the sweep — if `"length"` rose, the CoT
instruction is eating the 640-token cap and you have measured truncation, not
reasoning. (2) `completion_tokens` per episode, median and max, against
`DEFAULT_MAX_OUTPUT_TOKENS`. **Look at `Completion.finish_reason` first**,
because it distinguishes "reasoned worse" from "ran out of room", and those
call for opposite fixes (revert the prompt vs. raise the cap). A third worth
adding: `stop_reason` distribution, since a truncated answer often surfaces as
`no_output` rather than a wrong answer.

**6.3** — Ranking, and what it depends on:

1. **Nine-sample self-consistency.** Wang et al. and Huang et al.'s Table 7
   both put voting at the top for a discrete numeric answer at fixed budget
   (GSM8K, GPT-3.5: 88.2 at nine responses).
2. **Three ReAct episodes with a calculator, voted.** Close, and it *wins* if
   the question needs a fact the model does not have — nine samples of a
   hallucination vote for the hallucination. The calculator is an external
   verifier, which §6.6 says is the strongest lever available.
3. **One CoT plus four rounds of self-critique.** Last, and by the published
   numbers it may be *below* one CoT call: intrinsic self-correction over two
   rounds drops GPT-4 95.5 → 89.0 and Llama-2-70b 62.0 → 36.5, and four rounds
   is further along the same curve.

The ranking depends on exactly one thing: **whether the answer is computable
from the prompt or requires grounding.** If grounding is needed, (2) first; if
not, (1). Nothing makes (3) first.

**6.4** — The **output cap** (640 tokens) becomes the binding constraint, not
the step cap. A reasoning model spends its long chain in the *completion*, so a
single call can exhaust 640 tokens before emitting an answer, and it does so on
step 1 rather than step 6. The field that tells you: `Completion.finish_reason
== "length"` on individual steps, surfacing as `OutputTruncated` from
`structured()` or as a `no_output` exit from the loop. Note the trap: `step_cap`
is the *default* stop reason, so a superficial read of the exit distribution
will not show you this — you have to look at `finish_reason`.

**6.5** — It points at the **third** structural weakness, long horizon: six
successful observations and no answer is an agent that gathered facts and never
combined them, with step 1's result sitting in the least-attended region by
step 6. The single number to change first is **not** the step cap. Phase 3's
pitfall list is explicit that raising the cap is the wrong instinct: it buys
more gathering, which is what already failed. Change the number that governs
*combining* — either force a synthesis step (which is plan-and-execute) or,
staying in ReAct, reduce `max_steps` so the model runs out of room to keep
looking and must answer. Counter-intuitive and correct: a tighter budget can
raise the resolved rate by removing the option to keep browsing.

**6.6** — Two failure modes the mechanical version does not have: it can
**hallucinate support** (say the sources are fine when the cited tool errored,
which is the exact Phase 3 §8 failure it was written to catch), and it is
**non-deterministic**, so the same trajectory audits differently on two runs
and no test can pin it. Add a third if you like: it costs a model call per
episode. One thing the model version *can* do: judge whether the cited tool's
output actually **supports the specific claim** — that `query_db` returned rows
about *engineering* rather than about sales. The mechanical check only knows
that the tool ran and succeeded. Which is the general shape: use the program
for existence and success, and a model only for semantic relevance, with the
program's findings unclearable (D-17).

**6.7** — Ordering reverses when the subtasks are **independent** and you fan
out: three independent lookups are one round trip in plan-and-execute and three
in ReAct, so latency crosses over even though calls do not. Second property
under which plan-and-execute wins *while making more calls*: **long horizon
with a large per-step observation.** ReAct's call *k* carries every prior
observation, so at four steps with 800-token tool results it is sending ~3,200
tokens of history; plan-and-execute's step 4 sends only what its `depends_on`
names. More calls, fewer total tokens, and — because the relevant fact is not
buried in a transcript's middle — better accuracy.

**6.8** — The input you forgot is the **previous plan plus the findings**. At
`temperature=0` with a fixed seed and an identical prompt, the planner is a
deterministic function, so "plan this task" returns the same bytes. The exit
that should have fired instead of executing an identical plan: a
`no_progress`-equivalent at the *plan* level — concretely, if the new plan's
step ids and tools equal the old plan's, that is not a replan and the episode
should exit `replan_cap` immediately rather than paying for the second
execution. Atlas does not ship that guard; adding it is a good unprompted
exercise, and the honest note is that `make_plan` passing `previous` and
`findings` makes it rare rather than impossible.

**6.9** — Predicted effect on `resolved` on Tier A: **down**, plausibly a lot.
The closest published analogue is Llama-2-70b-chat on GSM8K falling 62.0 → 43.5
after one round of intrinsic self-correction, and Atlas's Tier A model is
smaller. Tokens per episode: **up by roughly 2×** for one round (the review call
plus the revision call, each carrying the answer), and the review call's prompt
includes the full answer so it is not cheap. The one modification that would
make it worth running: give the loop an **external signal** — run the citation
audit (or `mechanical_findings`) first and only invoke the model when a
verifier has already found something, with the verifier's specific complaint in
the prompt. That converts self-correction into verifier transport, which is the
version the evidence supports.

**6.10** — Check the three properties. *Cheap accurate state evaluator*: no —
"is this draft email good" is exactly the judgement a model is unreliable at,
and it is the property ToT's whole advantage rests on. *Small branching factor*:
yes, if you cap candidates. *Free undo*: yes — drafting has no side effects.
**The evaluator decides it, and it decides against.** Without a cheap accurate
scorer, tree search degenerates into sampling with extra steps, and the cheaper
correct move is best-of-*n* with a human choosing — or, if you must automate,
a *checklist* verifier (does it name the product, does it avoid a promise, is
it under 200 words) which is mechanical and therefore not ToT at all.

**6.12** — The specific reason: an approval gate approves **one action with one
effect**, and a program is one action with *n* effects. Showing the user
`send_email(to=..., subject=...)` is a gate; showing them a twenty-line script
that calls `send_email` inside a loop over a list computed three lines earlier
is a quiz, and the user cannot answer it — they would have to evaluate the
program to know what it will send. Attribution breaks the same way: one
`tool_call_id` for four effects.

A design that recovers most of the benefit: **split the action space by
reversibility.** Read-only tools go into the code sandbox and compose freely
(that is where the loops and joins are, and it is where CodeAct's token and
step savings actually come from); write and send tools stay as individual JSON
calls behind the gate. The program's *output* becomes the arguments for a gated
call. You keep composition over reads, which is the bulk of the benefit, and
every irreversible act stays individually approvable, attributable and
refusable.

**6.13** — Three honest explanations: **contamination** (the public benchmark
is in training data — GSM1k measured up to 13% of exactly this); **distribution
mismatch** (their tasks are not your tasks; a seeded synthetic company is not
in anyone's pretraining); **harness difference** (their scaffold retries,
offers more tools, has a laxer grader, uses a longer output cap, or runs
best-of-*n*). Rule out the **harness** first, because it is the only one you
control: re-run their published benchmark through *your* harness. If you
reproduce ~91%, the difference is your harness or your tasks; if you get 60%,
their scaffold is doing work theirs does not describe. Then hand-grade twenty of
your own failures to check the grader — a broken grader and a failing agent
produce the identical number.

**7.3** — If `merge_findings` did not filter, a model could emit a finding with
`kind="step_failed"`. `verdict_for` counts anything not `model_concern` as
**blocking**, and `step_failed` is not retryable, so the verdict becomes
**`replan`** on a mechanically clean plan — the model has acquired a veto. The
episode outcome that becomes possible: a correct, complete plan is thrown away
and replanned on a model's unease, spending a planning call plus every step
again, and on exhausting `max_replans` it exits `replan_cap` with `answer=None`.
A perfectly good answer replaced by a failure, at 2× the cost. That is the
false-negative direction D-17 exists to make unreachable.

**7.5** — Worst case: the outer loop runs `max_replans + 1 = 2` times, so **2
planning calls**. The step budget is `DEFAULT_MAX_EXEC_STEPS = 8` and it is
shared across plans, so **8 executor calls** total (e.g. plan 0 spends 4 — two
steps × two attempts — and plan 1 spends 4). With `critic_client=None` the
critic costs nothing. Synthesis is not reached, because exhausting the budget
returns before it. So **10 model calls**, and the exit is **`step_cap`** if the
budget runs out with steps still pending, or **`step_failed`** if the last event
was a step exhausting `MAX_STEP_ATTEMPTS` with no replan left. Both fail closed;
neither is `final`. Worth noticing that `MAX_PLAN_STEPS = 6` never binds here —
6 steps × 2 attempts is 12, so the *step* budget is the real cap, which is why
it is the larger-looking number.

**7.6** — Worst case: the outer loop runs `max_replans + 1 = 2` times, so **2
planning calls**; the step budget of 8 is shared across plans, so **8 executor
calls**; with `critic_client=None` the critic costs nothing; synthesis is never
reached because exhausting the budget returns first. So **10 model calls**, and
the exit is **`step_cap`** if the budget ran out with steps pending, or
**`step_failed`** if the last event was a step exhausting `MAX_STEP_ATTEMPTS`
with no replan left. Both fail closed. Note that `MAX_PLAN_STEPS = 6` never
binds: 6 steps × 2 attempts is 12, so the *step* budget is the real cap.

**8** — A false positive on a legitimate plan: a step that returns rows and a
`calculate` step that legitimately consumes *one cell* of them — e.g. `s1`
returns `region | units` for a single region and `s2` computes `units * 1.08`.
The rule flags it, and the plan would have worked. Another: `expects: "text"`
for a step returning `"38"` because the planner was conservative. **Ship it
anyway.** The cost of the false positive is one complaint and one replanning
call, and the complaint tells the planner exactly what to do (declare `number`,
or add a reducing step) — so the recovery is cheap and directed. The cost of the
false negative is §8's trace: a confidently wrong number with immaculate
citations. Asymmetric costs, and the rule is a reliability guard rather than a
security guard, so incompleteness in the *permissive* direction is what you
cannot afford. Log the complaint rate; if it exceeds ~20% of plans on your
model, the planner needs a prompt change, not the rule relaxed.

**7.3** — Without the filter a model could emit a finding with
`kind="step_failed"`. `verdict_for` counts anything not `model_concern` as
**blocking**, and `step_failed` is not retryable, so the verdict on a
mechanically clean plan becomes **`replan`** — the model has acquired a veto.
The episode outcome: a correct, complete plan is thrown away and replanned on a
model's unease, spending a planning call plus every step again, and on
exhausting `max_replans` it exits `replan_cap` with `answer=None`. A good
answer replaced by a failure at 2× the cost — the false-negative direction D-17
exists to make unreachable.

---

## §10 Interview questions

**1. Fine accuracy, unacceptable p95, five steps.** Look at **level sets before
step count**: five sequential steps and five *independent* steps have identical
accuracy and a 5× latency difference. Then ask, for each edge, which specific
value flows along it — a planner that chains independent steps has cost you all
the parallelism, and `ready_steps` returning length 1 every time is the tell.
The largest expected effect is making the fan-out real (Phase 8), not shortening
the plan. Second-order: `dependency_context` already keeps each call small, so
latency is round trips, not tokens.

**2. A reflection loop drops accuracy.** Intrinsic self-correction, Huang et al.
2023: with no external signal, accuracy falls across every model tried, because
models cannot judge the correctness of their own reasoning — 8.8%
correct→incorrect against 7.6% the other way. The published gains used oracle
labels to decide when to stop, which is filtering with an answer key. What would
make it work: an **external signal**. Run a mechanical check first and invoke the
model only when a verifier has already found something, with the verifier's
specific complaint in the prompt. That converts self-correction into verifier
transport, which is the version the evidence supports.

**3. Planner/executor interface, fifteen tools, three fields.** `tool` (a name
validated against the registry *before* execution, so a phantom tool is a plan
defect rather than a runtime surprise); `depends_on` (makes data flow explicit,
which gives cycle detection, per-step context, and visible parallelism);
`expects` (a declared result kind, so the harness can verify a step mechanically
and retry with a specific complaint). Strong answers add that **execution state
must not be in the planner's type** — a field the model can set is a field it
can lie about. The strongest add that a step's *consumed* kind is also needed,
which is §8's defect, and that it should be derived from the tool's own
signature rather than a hand-maintained set (invariant 18 applied to edges).

**4. Code-as-action over JSON.** When the composition is real — loops, filters,
joins over tool output — rather than atomic calls: CodeAct reports up to 20%
higher success with up to 30% fewer actions across 17 LLMs (ICML 2024), and
explicitly finds it merely *comparable* on atomic single-tool calls. The token
argument is now larger (Anthropic, Nov 2025: ~150k → ~2k on one workflow).
Infrastructure prerequisite: **a real container**, because the action space
becomes the language and the execution environment is the only boundary left.
Counter-cases: per-call approval (a twenty-line program is a quiz, not a gate),
per-call attribution, and weak models producing syntax errors that cost a whole
step.

**5. 91% published, 43% internal.** (a) **Contamination** — GSM1k measured up to
13% of exactly this, with Phi and Mistral families showing systematic
overfitting. (b) **Distribution mismatch** — their tasks are not yours. (c)
**Harness difference** — their scaffold may retry, offer more tools, use a
longer output cap, run best-of-*n*, or grade more loosely. Rule out the
**harness first**, because it is the only one you control: re-run their
published benchmark through your harness. Reproduce ~91% and the difference is
your tasks; get 60% and their scaffold is doing undocumented work. Then
hand-grade twenty of your own failures, because a broken grader and a failing
agent produce the identical number — and if you have read §7.9 you will check
whether an arm that *cannot* answer is passing.

---

## §13 Quiz

**1.** More calls, slower prompt growth. *More calls*: plan-and-execute pays a
planning call and a synthesis call unconditionally, so a three-hop task costs
1 + 3 + 1 = 5 against ReAct's 4 (three tool steps plus a final). *Slower prompt
growth*: the formula is Phase 1's `n·p0 + g·n·(n−1)/2`, whose quadratic term
comes from re-sending a growing transcript. The function that removes it is
`dependency_context(plan, step)`, which passes a step only the results its
`depends_on` names — so each executor prompt is `p0 + O(1)` rather than
`p0 + g·k`. ReAct's step 4 carries three observations; plan-and-execute's `s3`
carries two numbers because it declared two dependencies.

**2.** They differ on a plan where step 1 **failed** and steps 2 and 3 were
**skipped**: nothing is `pending`, so `not any(pending)` is `True`, while
`all(done)` is `False`. The chosen definition follows **fail closed** — the same
principle that makes `step_cap` the default `stop_reason` (D-02, invariant 9).
An episode that ran out of ways to proceed must never present as complete;
`is_complete` is read by the caller to decide whether to synthesise, and the
permissive definition would synthesise an answer from one failed step and two
skipped ones.

**3.** Verdict: **`retry_step`** (or `replan`, if the step has already used
`MAX_STEP_ATTEMPTS`). Never `accept`. What makes it so, in three places:
`mechanical_findings` produced a `wrong_shape` finding without consulting the
model; `merge_findings` **appends** model output and filters it to
`kind="model_concern"`, so `NONE` contributes an empty list and removes
nothing; and `verdict_for` computes `blocking = [f for f in findings if f.kind
!= "model_concern"]`, which is non-empty. The model's reply is *recorded*
(`consulted_model=True`) and has no causal path to the verdict.

**4.** Structural reason: **`ready_steps` — not the model — chooses what runs
next.** `no_progress` catches a model repeating a call, and here the model
cannot repeat a call because it is not choosing; the graph offers exactly one
pending step whose dependencies are met, and a repeat only happens as a
*deliberate* retry the harness ordered. The guard whose absence is **not**
explained by that reason is **`bad_action`**. Nothing about the graph stops a
model from naming a phantom tool inside a step — it happens, and
`unknown_tool_names` catches it at dispatch. `bad_action` is absent instead
because a step's *declared* tool is validated against the registry by
`validate_plan` before anything runs, so the phantom-tool-in-the-plan case is a
`bad_plan`; the phantom-tool-at-execution case is folded into `shape_ok=False`
and handled as a step failure. That is a defensible choice and arguably the
weakest of D-18's four, because a phantom tool and a badly-shaped number now
share one signal.

**5.** Two explanations. (a) **The extra attempts are being consumed and
failing**: the model cannot satisfy the shape check for these steps at all, so
attempts 3 and 4 are pure cost. (b) **The extra attempts are never reached**:
almost no step needs more than two, and the 30% token rise came from somewhere
else entirely — a longer complaint accumulating in `step.note`, or more
episodes surviving to synthesis. The field that distinguishes them:
**`shape_failures`** (and `plan.steps[i].attempts`). Under (a), the count of
shape failures per episode rises with the cap and `attempts` reaches 3–4; under
(b), `shape_failures` is unchanged and `attempts` never exceeds 2. If (a),
revert — you have bought nothing; if (b), find the real cost before you touch
anything.

**6.** First conclusion: **the problem set is largely answerable from the
model's prior**, and therefore no other conclusion from this grid is safe. The
`direct` arm has no tools; it cannot see the database. 70% on eight problems of
which four need database access means it is guessing right, which for a seeded
synthetic company means either the checkers are too lax (`must_contain` matching
a substring that appears in a non-answer) or the numbers are guessable (a
38-person company's departments have small round headcounts). It is a fact about
**your problem set and your grader**, not about the model or the strategies.
Fix it before reading any other row: hand-check the four `direct` passes on
tool-dependent problems, and tighten `must_contain`.

**7.** `total_tokens` is a `computed_field`, so it *is* in the dump — but it is
computed from `steps` **plus** four accumulators for the planning, critique and
synthesis calls, and in the first draft those four were pydantic *private*
attributes. Private attributes are absent from `model_dump()`, so on reload the
computed field recomputed itself from a third of its inputs: 281 tokens instead
of 866, 1 model call instead of 3, silently, with no validation error. (The
same object also could not be reloaded at all until `extra="forbid"` came off,
because the dump's other computed fields looked like extra keys — D-19.)

The one-line rule is invariant 31: **anything a computed total depends on must
itself survive `model_dump()`, not just the total.** And the corollary about
testing: the test that missed this asserted the *key was present* after a dump;
the test that catches it asserts *value equality* after a real
`json.loads(json.dumps(dump))` round trip. Bonus credit for noticing the
direction — it under-reported the arm whose entire cost story is overhead, so
the strategy comparison would have flattered plan-and-execute in exactly the
place the phase claims to be careful.

---

## §14 Assignment 1 — `edge_complaints`

The rule, written as prose *first* (the UNAIDED CORE):

> A step whose `tool` performs arithmetic requires each of its dependencies to
> yield a single quantity. `calculate` is the only such tool in Atlas today.
> The kinds that are single quantities are `number` and `boolean`. A dependency
> that does not exist is not this function's problem — `validate_plan` already
> reports a missing step and duplicating it would produce two complaints for
> one defect. Every incompatible edge is reported, and each complaint names both
> ends, the offending kind, and the two ways to fix it.

```python
# atlas/agents/plan.py

_SCALAR_TOOLS: frozenset[str] = frozenset({"calculate"})
_SCALAR_KINDS: frozenset[str] = frozenset({"number", "boolean"})


def edge_complaints(plan: Plan) -> list[str]:
    """Every dependency edge whose tail cannot supply what its head needs.

    `expects` describes what a step PRODUCES. Nothing described what a step
    CONSUMES, so `check_result_kind` verified each edge's tail and never its
    head -- which is the §8 defect: `s1` declared `rows`, `s3` used
    `calculate`, every guard passed, and the answer was wrong.
    """
    complaints: list[str] = []
    for step in plan.steps:
        if step.tool not in _SCALAR_TOOLS:
            continue
        for dependency in step.depends_on:
            found = plan.get(dependency)
            if found is None:
                continue  # validate_plan already reports a missing step
            if found.expects in _SCALAR_KINDS:
                continue
            complaints.append(
                f"step {step.id!r} uses {step.tool} on the result of "
                f"{dependency!r}, but {dependency!r} declares "
                f"expects={found.expects!r}. Arithmetic needs a single "
                f"quantity, so {dependency!r} must declare expects='number', "
                f"or add a step between them that reduces its result to one "
                f"number."
            )
    return complaints
```

Wired in, at the end of `validate_plan`, **before** the cycle check:

```python
    complaints.extend(edge_complaints(plan))

    if not complaints:
        try:
            topological_order(plan)
        except PlanError as exc:
            complaints.append(str(exc))
    return complaints
```

Four decisions worth defending.

*Two frozensets rather than an `if step.tool == "calculate"`.* The rule is
"tools requiring scalars", and there will be more of them (a `chart` tool, a
`compare_numbers` tool). A named set makes adding one a one-line change in the
place the rule lives, and it makes the rule *readable as the rule*.

*`continue` on a dangling dependency, not a complaint.* `validate_plan` already
emits `step 's3' depends on 's9', which is not a step in this plan`, and two
complaints for one defect trains a planner to fix the wrong thing. The hidden
test checks specifically that you do not duplicate it and do not `KeyError`.

*Placed before the cycle check.* Same reasoning as Phase 3's ordering: a
confusing cycle report on a plan whose real problem is an edge is a message
that sends the planner in the wrong direction. And since `edge_complaints` is
pure and cheap, running it unconditionally costs nothing.

*Every edge, not the first.* Phase 3's `_explain_validation` lesson: a model
told only about its first defect resends a plan with the second.

**Test you should have written yourself** before running `make grade`:

```python
def test_the_phase_8_trace_is_now_rejected_before_it_runs(registry) -> None:
    plan = Plan(goal="units per engineer", steps=[
        PlanStep(id="s1", description="units in Q1", tool="query_db",
                 expects="rows"),
        PlanStep(id="s2", description="headcount", tool="query_db",
                 expects="number"),
        PlanStep(id="s3", description="divide", tool="calculate",
                 depends_on=["s1", "s2"], expects="number"),
    ])
    complaints = edge_complaints(plan)
    assert len(complaints) == 1          # s2 is fine; only s1 is reported
    assert "s1" in complaints[0] and "s3" in complaints[0]
```

**The stretch, both ways.** *Infer the consumed kind from the tool* (what we
did): zero extra fields for the model to get wrong, and the rule lives in code
where it is testable — but it only knows about tools whose contracts you
hard-coded, and a step with `tool=None` that combines results is unconstrained.
*Have the step declare `consumes: list[ResultKind]`*: expressive enough to
constrain combining steps and to let one tool accept two shapes — but it is a
second field the model can get wrong, and a wrong `consumes` is undetectable
(unlike a wrong `expects`, which the result itself contradicts). Phase 9's
answer is the first, generalised: the *tool's own signature* already says its
parameters are numbers, so the compatibility rule should be derived from
`tool_spec.parameters` rather than from a hand-maintained set — which is
invariant 18 (one description, generated) applied to edges.

---

## §14 Assignment 2 — `atlas/agents/vote.py`

```python
"""Self-consistency over a single numeric answer.

§6.3's three preconditions, satisfied by narrowing the problem until they hold:
(a) the answer is a number, so a mode exists; (b) temperature is above zero and
the seed varies per sample, so the samples differ; (c) the caller pays k times
and can see the bill in `total_tokens`.
"""

from __future__ import annotations

import re
from collections import Counter
from typing import Sequence

from pydantic import BaseModel, ConfigDict, computed_field

from atlas.llm import LLMClient, Message

_NUMBER = re.compile(r"-?\d[\d,]*(?:\.\d+)?")


class VoteResult(BaseModel):
    model_config = ConfigDict(extra="forbid")

    value: float | None
    votes: int
    usable: int
    samples: int
    total_tokens: int = 0

    @computed_field  # type: ignore[prop-decorator]
    @property
    def agreement(self) -> float:
        """Votes over USABLE samples, never over total.

        A sample the extractor could not read is not evidence against the
        winner; dividing by `samples` would report low confidence for a
        unanimous vote that happened alongside one garbled reply.
        """
        return self.votes / self.usable if self.usable else 0.0

    @computed_field  # type: ignore[prop-decorator]
    @property
    def tied(self) -> bool:
        return self.usable > 1 and self.votes == 1


def extract_number(text: str) -> float | None:
    """The first number in `text`, or None. Pure, and never guesses."""
    match = _NUMBER.search(text or "")
    if match is None:
        return None
    try:
        return float(match.group(0).replace(",", ""))
    except ValueError:  # pragma: no cover
        return None


def majority_number(samples: Sequence[str], *,
                    total_tokens: int = 0) -> VoteResult:
    """The plurality number across `samples`. Pure."""
    readings = [extract_number(s) for s in samples]
    usable = [value for value in readings if value is not None]
    if not usable:
        return VoteResult(value=None, votes=0, usable=0,
                          samples=len(samples), total_tokens=total_tokens)
    counts = Counter(usable)
    value, votes = counts.most_common(1)[0]
    return VoteResult(value=value, votes=votes, usable=len(usable),
                      samples=len(samples), total_tokens=total_tokens)


def self_consistent_number(
    client: LLMClient,
    messages: Sequence[Message],
    *,
    k: int = 3,
    temperature: float = 0.7,
    seed: int | None = 7,
    max_tokens: int | None = 256,
) -> VoteResult:
    """Sample k times and vote. Cost is exactly k calls."""
    if k < 1:
        raise ValueError("k must be at least 1")
    texts: list[str] = []
    tokens = 0
    for index in range(k):
        completion = client.complete(
            messages,
            temperature=temperature,
            max_tokens=max_tokens,
            # Per-sample seed: a fixed seed with a fixed prompt makes every
            # sample identical on a seeded backend and the vote is theatre.
            seed=None if seed is None else seed + index,
        )
        texts.append(completion.text or "")
        tokens += (completion.usage.prompt_tokens
                   + completion.usage.completion_tokens)
    return majority_number(texts, total_tokens=tokens)
```

**The two UNAIDED CORE decisions, explained.**

*`agreement = votes / usable`.* Suppose `k=3` and the samples are `"38"`,
`"38"`, `"the query failed"`. Two readable samples, both saying 38 —
unanimous among the evidence. Dividing by `samples` gives 0.67 and understates
it; if you then threshold on `agreement > 0.7` to decide whether to trust the
vote, you have thrown away a unanimous result because of an unrelated error.
Dividing by `usable` gives 1.0. The general principle: **a sample you could not
read is not evidence against anything.** The counter-argument is real and worth
holding — a high `usable` failure rate is itself a signal — which is why
`samples` and `usable` are both reported rather than collapsed.

*The per-sample seed.* `Settings.seed` defaults to 7 and Atlas passes it
everywhere for reproducibility. Pass the *same* seed with the *same* prompt to
a backend that honours seeds, and all `k` samples are byte-identical: the vote
is unanimous by construction, `agreement` is always 1.0, and you have paid `k`
times for one sample. `seed + index` keeps the sweep reproducible (run it twice,
get the same `k` samples) while making the samples differ, which is exactly what
you want. Note the honest caveat: whether your backend honours a seed at all is
a `VERSIONS.md` question, and if it does not, temperature alone is doing the
work.

**The measurement.** Matched-budget comparison. `k=3` voting on one numeric step
costs three calls and answers one problem; the baseline is three *problems*
answered once each. So the comparison is "voting on 1/3 of the problems" versus
"single-sample on all of them" — and on eight problems that is 2.67 versus 8,
which is not a comparison eight problems can settle. Say so in `RESULTS.md`.
The defensible version: run both on the same eight problems and report **tokens
per correct answer**, which at least normalises the cost. Expected finding
(unmeasured): voting helps on the arithmetic-heavy problems where the model's
single sample is unstable, and does nothing on the lookup problems where the
answer comes from a tool and all three samples are identical anyway. If that is
what you see, the actionable conclusion is that self-consistency belongs on the
`calculate` steps and nowhere else — which is a much narrower and more useful
result than "self-consistency helps".

---

## §15 Case study — model answer sketch

**Task A, weekly ops digest: a workflow, not an agent.** The shape is fixed, so
a planning call spends tokens re-deriving a plan you already know. Three
hard-coded `query_db` calls, one model call to write prose around the numbers,
done — four calls, no loop, no plan, and the failure modes are enumerable in a
design review because there is no branch a model controls. The error-code step
is the only candidate for anything agentic (it needs `search_documents` over
last week's notes), and even there a bounded 2-step loop is enough. Verifier:
the digest's totals reconcile against a second, differently-shaped query
(`sum(units) GROUP BY region` versus `sum(units)`), which is a program and
catches the one failure that matters. Falsification: if the digest is wrong more
than rarely, read `stop_reason` — but for a workflow there is no `stop_reason`
worth reading, which is the point; a wrong number is a SQL bug and you fix SQL.

**Task B, customer question: ReAct.** Unknown step count (does this device model
appear in the affected list? only the first lookup tells you), next action
depends on the last observation, tools cheap and reversible, 30-second budget
that a planning call plus a synthesis call would eat. Plan-and-execute is wrong
here specifically because the *branching* is the task. The human reviewer
changes the risk calculus in one direction only: a wrong draft costs the
reviewer's time rather than the customer's trust, so you can accept a lower
accuracy in exchange for latency — which is another argument for ReAct.
Verifier: **citations must resolve to real documents**, mechanical, and Phase 3
Assignment 1 already wrote it. No verifier exists for "is this reply good",
and the honest answer is to say so rather than to add a judge model; the
reviewer *is* the verifier. Falsification: `stop_reason` distribution — a
`step_cap` share above ~15% means the loop is browsing rather than answering,
and the fix is a *lower* cap (see quiz 4's counter-intuitive result), not a
higher one.

**Task C, quarterly reconciliation: decomposition, and mostly not a model.**
The trap is building a 200-step DAG; 200 steps is 200 model calls for work a
`JOIN` does. The right shape is map-reduce with the model on the residue: a
deterministic diff of the spreadsheet against the database produces, say, 12
discrepancies, and *then* one model call per discrepancy classifies it as
timing or genuine — a 12-step fan-out, which is where `ready_steps` returning a
level set of 12 earns its keep. **The reconciliation is the verifier**, so this
is the task where §6.6 applies most completely: the expensive, reliable part is
a program, and the model is used only for the judgement a program cannot make.
Latency budget is hours, so you could afford ToT or self-consistency here — and
self-consistency is actually appropriate on the classification, because it is a
discrete answer with a mode. Falsification: a `bad_plan` share above 20% means
you are measuring structured output rather than strategy (`RESULTS.md`'s last
row), and a missed discrepancy is caught by re-running the deterministic diff
with the totals compared both ways.

**What the three answers have in common, and it is the phase's thesis:** in none
of them is the interesting decision "which reasoning strategy". It is *where
the verifier is*, and the strategy falls out of that.
