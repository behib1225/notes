from edit import *
p, s = load("02")

s = setup_line(s, '!pip install -q -U "transformers>=4.56" "sentence-transformers>=6.2" accelerate', 'accelerate pillow')

# Lab 1: per-model max length
s = rep(s, '''def manual_embed(model_name, texts, pooling, use_mask=True):
    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name).to(DEVICE).eval()
    batch = tok(texts, padding=True, truncation=True, max_length=512,
                return_tensors="pt").to(DEVICE)''',
'''def manual_embed(model_name, texts, pooling, use_mask=True, max_length=512):
    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name).to(DEVICE).eval()
    batch = tok(texts, padding=True, truncation=True, max_length=max_length,   # match model.max_seq_length
                return_tensors="pt").to(DEVICE)''')
s = rep(s, '''for name, pooling in [("BAAI/bge-small-en-v1.5", "cls"),
                      ("sentence-transformers/all-MiniLM-L6-v2", "mean")]:
    mine = manual_embed(name, texts, pooling)
    lib = SentenceTransformer(name, device=DEVICE).encode(texts, normalize_embeddings=True)
    wrong = manual_embed(name, texts, "mean" if pooling == "cls" else "cls")''',
'''for name, pooling, max_len in [("BAAI/bge-small-en-v1.5", "cls", 512),
                               ("sentence-transformers/all-MiniLM-L6-v2", "mean", 256)]:   # the library truncates MiniLM at 256
    mine = manual_embed(name, texts, pooling, max_length=max_len)
    lib = SentenceTransformer(name, device=DEVICE).encode(texts, normalize_embeddings=True)
    assert lib.shape[1] == mine.shape[1]
    wrong = manual_embed(name, texts, "mean" if pooling == "cls" else "cls", max_length=max_len)''')
s = rep(s, '''for use_mask in (False, True):
    alone = manual_embed(MINILM, [s], "mean", use_mask)[0]
    batched = manual_embed(MINILM, [s, long_text], "mean", use_mask)[0]''',
'''for use_mask in (False, True):
    alone = manual_embed(MINILM, [s], "mean", use_mask, max_length=256)[0]
    batched = manual_embed(MINILM, [s, long_text], "mean", use_mask, max_length=256)[0]''')
s = rep(s, "Re-implement CLS and mean pooling with plain `transformers` and check that you reproduce sentence-transformers exactly.",
"Re-implement CLS and mean pooling with plain `transformers` and check that you reproduce sentence-transformers exactly. One detail matters for an exact match: use the same maximum length as the library (`model.max_seq_length`), which is 512 for bge-small but 256 for all-MiniLM-L6-v2; a different truncation length changes the vectors of long inputs.")

# tokenizer_kwargs attribution
s = rep(s, '''                           processor_kwargs={"padding_side": "left"})   # sentence-transformers 6; 5.x called it tokenizer_kwargs''',
'''                           processor_kwargs={"padding_side": "left"})   # renamed from tokenizer_kwargs in sentence-transformers 5.4''')

# ColBERT libraries
s = rep(s, "The same idea powers ColPali-style retrieval over page images (Part 8). Libraries such as PyLate and RAGatouille make ColBERT models usable from Python.",
"The same idea powers ColPali-style retrieval over page images (Part 8). Since version 6.0, sentence-transformers ships a fourth model class, `MultiVectorEncoder`, which absorbed the modelling, training and evaluation code of PyLate (text ColBERT models) and colpali-engine (visual document models): one class loads `lightonai/GTE-ModernColBERT-v1` or `vidore/colqwen2-v1.0`, exposes `encode_query` and `encode_document`, and scores with MaxSim through `model.similarity`. Indexing at scale (PLAID) is still done with PyLate or a vector database that supports multi-vector fields; Lab 8 uses the new class.")

# Comparison table row
s = rep(s, "| Late interaction | ColBERTv2, Jina-ColBERT, answerai-colbert-small | Higher precision, larger indexes |",
"| Late interaction | ColBERTv2, GTE-ModernColBERT, Jina-ColBERT, answerai-colbert-small; loadable with sentence-transformers' `MultiVectorEncoder` (6.0+) | Higher precision, larger indexes |")

# Gemini Embedding 2 citation
s = rep(s, "Google gemini-embedding-001 and Gemini Embedding 2 (`gemini-embedding-2-preview`, public preview since 10 March 2026, natively multimodal: text, images, video, audio and PDFs in one space; [report](https://itbrief.co.uk/story/google-debuts-gemini-embedding-2-multimodal-ai-model))",
"Google gemini-embedding-001 and Gemini Embedding 2 (`gemini-embedding-2-preview`, public preview since 10 March 2026, natively multimodal: text, images, video, audio and PDFs in one space, Matryoshka dimensions from 128 to 3,072; [Google's announcement](https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-embedding-2/))")
s = rep(s, "Gemini Embedding 2 public preview (Google, 10 March 2026; [news report](https://itbrief.co.uk/story/google-debuts-gemini-embedding-2-multimodal-ai-model)); check Google's Gemini API documentation for current model IDs.",
"Google (10 March 2026), [Gemini Embedding 2: Our first natively multimodal embedding model](https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-embedding-2/); check Google's Gemini API documentation for current model IDs.")

# Benchmarks: BRIGHT
s = rep(s, "- **RTEB** (Retrieval Embedding Benchmark, launched on Hugging Face in late 2025) focuses on retrieval and keeps part of its evaluation data private, to reduce the risk that models were trained on the test sets.",
"""- **RTEB** (Retrieval Embedding Benchmark, launched on Hugging Face in late 2025) focuses on retrieval and keeps part of its evaluation data private, to reduce the risk that models were trained on the test sets.
- **BRIGHT** (Su et al., 2024) tests **reasoning-intensive** retrieval: queries from coding, maths and science forums whose relevant documents share few keywords with the query and must be found by reasoning about the problem. Strong models that score above 0.7 nDCG@10 on classic BEIR datasets score around 0.2 to 0.3 here, and LLM query rewriting or reasoning-trained retrievers help far more than on keyword-friendly benchmarks. If your users ask "how do I solve X" rather than "where is fact Y", look at BRIGHT-style results, not only MTEB averages.""")
s = rep(s, "- Muennighoff et al. (2022). [MTEB](https://arxiv.org/abs/2210.07316); Enevoldsen et al. (2025). [MMTEB](https://arxiv.org/abs/2502.13595).",
"- Muennighoff et al. (2022). [MTEB](https://arxiv.org/abs/2210.07316); Enevoldsen et al. (2025). [MMTEB](https://arxiv.org/abs/2502.13595); Su et al. (2024). [BRIGHT: A Realistic and Challenging Benchmark for Reasoning-Intensive Retrieval](https://arxiv.org/abs/2407.12883).")
s = rep(s, "- Library: [sentence-transformers v5.0 release notes](https://newreleases.io/project/github/huggingface/sentence-transformers/release/v5.0.0) (SparseEncoder, encode\\_query and encode\\_document).",
"- Library: [sentence-transformers migration guide](https://www.sbert.net/docs/migration_guide.html) (v5.0: SparseEncoder, encode\\_query and encode\\_document; v5.4: `tokenizer_kwargs` renamed to `processor_kwargs`, new import paths; v6.0: `MultiVectorEncoder`, requires transformers 5).")

# Lab 8: MultiVectorEncoder
s = rep(s, """## Interview questions with model answers

These 25 questions cover how embedding models work""",
"""### Lab 8. Late interaction with `MultiVectorEncoder` (sentence-transformers 6)

This cell was checked against the sentence-transformers 6 documentation but not executed on a GPU. It loads a ColBERT-style text model and scores the hard set with MaxSim; compare the result with the single-vector models from Lab 3.

```python
from sentence_transformers import MultiVectorEncoder
colbert = MultiVectorEncoder("lightonai/GTE-ModernColBERT-v1", device=DEVICE)   # a PyLate checkpoint loads directly
q_multi = colbert.encode_query([ex["question"] for ex in HARD_SET])            # one matrix of token vectors per query
d_multi = colbert.encode_document(chunk_texts)                                 # one matrix per chunk
S = colbert.similarity(q_multi, d_multi)                                       # MaxSim, shape (n_queries, n_chunks)
S = S.float().cpu().numpy() if hasattr(S, "cpu") else np.asarray(S, dtype=np.float32)
print("GTE-ModernColBERT:", metrics_from_scores(S, HARD_SET))
print("vectors per chunk:", [len(m) for m in d_multi[:3]], "| dims:", d_multi[0].shape[-1])
```

The last line shows the storage cost from Chapter 4.3 directly: one 128-dimensional vector per token instead of one per chunk. The same class loads visual document models (`MultiVectorEncoder("vidore/colqwen2-v1.0")`, Part 8), so late interaction over text and over page images now share one API.

## Interview questions with model answers

These 25 questions cover how embedding models work""")

s = rep(s, "**Q14. Compare bi-encoders, cross-encoders, ColBERT and SPLADE.** Bi-encoder: one vector per text, fast ANN search, least precise. Cross-encoder: joint encoding, most precise, one forward pass per candidate, so only for reranking. ColBERT: one vector per token with MaxSim late interaction, near cross-encoder precision with precomputed passages but large indexes. SPLADE: learned sparse term weights with expansion, served from an inverted index, strong on exact terms and interpretable.",
"**Q14. Compare bi-encoders, cross-encoders, ColBERT and SPLADE.** Bi-encoder: one vector per text, fast ANN search, least precise. Cross-encoder: joint encoding, most precise, one forward pass per candidate, so only for reranking. ColBERT: one vector per token with MaxSim late interaction, near cross-encoder precision with precomputed passages but large indexes. SPLADE: learned sparse term weights with expansion, served from an inverted index, strong on exact terms and interpretable. In sentence-transformers these are the four model classes: `SentenceTransformer`, `CrossEncoder`, `MultiVectorEncoder` and `SparseEncoder`.")

save(p, s)
print("Part 2 ok")
