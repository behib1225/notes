from edit import *

def img(name, caption):
    return f"![{caption}](../diagrams/{name}.svg)\n\n*{caption}*"

# placeholders -> images
PH = {
 "01": ("> **Diagram:** RAG architecture · indexing and query pipelines around one index. The diagram is included in the PDF version of this part.", "p01_rag_architecture", "RAG architecture: the indexing and query pipelines around one index"),
 "02": ("> **Diagram:** Relevance architectures · bi-encoder, late interaction, cross-encoder. The diagram is included in the PDF version of this part.", "p02_relevance_architectures", "Relevance architectures: bi-encoder, learned sparse, late interaction, cross-encoder"),
 "03": ("> **Diagram:** Hybrid retrieval pipeline · sparse and dense in parallel, fused, then reranked. The diagram is included in the PDF version of this part.", "p03_hybrid_pipeline", "Hybrid retrieval pipeline: sparse and dense in parallel, fused, then reranked"),
 "04": ("> **Diagram:** Ingestion pipeline · eight stages with versioned stores beside them. The diagram is included in the PDF version of this part.", "p04_ingestion_pipeline", "Ingestion pipeline: eight stages with versioned stores beside them"),
 "05": ("> **Diagram:** Query pipeline · six stages with typical latencies. The diagram is included in the PDF version of this part.", "p05_query_pipeline", "Query pipeline: six stages with typical latencies"),
 "06": ("> **Diagram:** Evaluation layers · component, end-to-end, online, with the feedback loop. The diagram is included in the PDF version of this part.", "p06_evaluation_layers", "Evaluation layers: component, end-to-end, online, with the feedback loop"),
 "07": ("> **Diagram:** Deciding what to train · checks in pipeline order, cheapest fix first. The diagram is included in the PDF version of this part.", "p07_decide_what_to_train", "Deciding what to train: checks in pipeline order, cheapest fix first"),
 "08": ("> **Diagram:** The agent loop · model proposes tool calls, the runtime validates and executes. The diagram is included in the PDF version of this part.", "p08_agent_loop", "The agent loop: the model proposes tool calls, the runtime validates and executes"),
 "09": ("> **Diagram:** Production RAG reference architecture · online path, offline path, supporting services. The diagram is included in the PDF version of this part.", "p09_reference_architecture", "Production RAG reference architecture: online path, offline path, supporting services"),
 "11": ("> **Diagram:** System-design time budget · seven steps in a 45-minute round. The diagram is included in the PDF version of this part.", "p11_design_time_budget", "System-design time budget: seven steps in a 45-minute round"),
}
for part, (old, name, cap) in PH.items():
    p, s = load(part)
    s = rep(s, old, img(name, cap))
    save(p, s)

# new diagrams at anchors (inserted after the anchor paragraph)
NEW = {
 "01": [("This order follows the data flow, so each check assumes everything before it worked. It also matches the probabilistic view of Chapter 3: generation quality is bounded by retrieval recall.",
         "p01_debug_order", "The debugging order: stop at the first \"no\"")],
 "02": [("Passage token vectors are precomputed, so queries stay fast, while token-level matching recovers much of the cross-encoder's precision and generalises well to new domains.",
         "p02_maxsim", "MaxSim on the vectors of Exercise 7: each query token keeps its best-matching passage token")],
 "03": [("**Weaknesses.** Needs a training step; clusters drift as data changes (retrain periodically); recall drops for queries near boundaries.",
         "p03_ivf", "IVF: the query is compared with the centroids, and only the nprobe nearest lists are scanned"),
        ("**IVF-PQ** combines both: IVF picks the lists, and the vectors in the lists are stored as PQ codes of their **residuals** (the vector minus its centroid), which are smaller and quantise better. Since PQ distances are approximate, systems usually **re-rank** the top few hundred candidates with full-precision vectors, often stored on disk.",
         "p03_pq", "Product quantisation: split the vector, quantise each piece with its own codebook, keep the codes"),
        ("**Knobs.** M (typically 16 to 64): more links give higher recall and more memory. efConstruction (100 to 500): better graph quality, slower build. efSearch (at least k, commonly 64 to 512): the recall-latency knob at query time. Search cost grows roughly logarithmically with N in practice.",
         "p03_hnsw", "HNSW: greedy descent through sparse upper layers, then a beam search on layer 0")],
 "04": [("So with no overlap the probability is 1 − e/C, and **overlap of at least e guarantees containment**. For C = 512 and e = 100: no overlap gives 0.80; o = 50 gives 0.89 (11% more storage); o = 100 gives 1.0 (24% more storage). A simulation of random positions agrees with these figures to within half a percentage point. Overlap of 10 to 20% of the chunk size is a common default; structure-aware splitting reduces the need for it, because facts rarely cross section boundaries.",
         "p04_chunk_overlap", "Fixed windows with overlap: evidence A fits in one chunk, evidence B is cut"),
        ("The cost is prompt budget: parents are big, so you can afford fewer of them. Measure answer quality, not only retrieval metrics, when you tune this.",
         "p04_parent_child", "Parent-child retrieval: index small children, return the parent section")],
 "07": [("B is initialised to zero, so training starts exactly from the base model. Trainable parameters per matrix drop from d·k to r(d + k): for d = k = 4,096 and r = 16, from 16.8 million to 131,072, under 1%. After training, BA can be **merged** into W₀, so inference has no extra latency; or adapters can be kept separate and swapped per task or tenant.",
         "p07_lora", "LoRA: a frozen weight matrix plus a trainable low-rank update")],
 "08": [("4. **Local search**: for entity-specific questions, find the entities mentioned in the query, then gather their neighbours, relations, community reports and source chunks into the context.",
         "p08_graphrag", "GraphRAG: build the graph and its community summaries once; answer global questions by map-reduce and local questions by traversal"),
        ("It reads text, layout, tables and figures together, and it led the ViDoRe visual-document retrieval benchmark introduced with it.",
         "p08_colpali", "ColPali-style retrieval: query tokens against page patches, scored with MaxSim")],
 "09": [("That is why long RAG prompts limit concurrency, and why shorter contexts raise throughput.",
         "p09_kv_budget", "GPU memory budget on a T4 for Qwen3-4B: weights, overhead and the KV cache that limits concurrency")],
}
for part, items in NEW.items():
    p, s = load(part)
    for anchor, name, cap in items:
        s = insert_after(s, anchor, "\n\n" + img(name, cap))
    save(p, s)
print("diagrams placed")
