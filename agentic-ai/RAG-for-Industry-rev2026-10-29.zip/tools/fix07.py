from edit import *
p, s = load("07")

s = rep(s, '!pip install -q -U "sentence-transformers[train]>=6.2" "transformers>=5.21" datasets accelerate "peft>=0.21" "trl>=1.16" bm25s pandas',
'!pip install -q -U "sentence-transformers[train]>=6.0,<7" "transformers>=5.0,<6" datasets accelerate "peft>=0.18" "trl>=0.24" bm25s pandas')

s = rep(s, """**Version check (October 2026).** The training code in this part was checked against the source code of sentence-transformers 6.2, transformers 5.21, TRL 1.16 and PEFT 0.21; it has not been executed on a GPU. Two changes matter if you have older notebooks: transformers 5 removed the `warmup_ratio` training argument (pass `warmup_steps` with a value below 1 to mean a ratio, as below), and sentence-transformers 6 renamed `tokenizer_kwargs` to `processor_kwargs`. The old import paths used here (`sentence_transformers.losses`, `sentence_transformers.training_args`, `sentence_transformers.evaluation`) still work in version 6 through compatibility shims.""",
"""**Version check (October 2026).** The training code in this part was checked against the source code and documentation of sentence-transformers 6.x, transformers 5.x, TRL and PEFT; it has not been executed on a GPU. Three changes matter if you have older notebooks. First, transformers 5 removed the `warmup_ratio` training argument: pass `warmup_steps` with a value below 1 to mean a fraction of the total steps, as below. Second, sentence-transformers **5.4** renamed `tokenizer_kwargs` to `processor_kwargs` and renamed the trainers' `tokenizer` argument to `processing_class` (the version 6.0 release then added `MultiVectorEncoder` and made transformers 5 a requirement). Third, since 5.4 the canonical import paths are per model type (`sentence_transformers.sentence_transformer.losses`, `.training_args`, `.evaluation`); the shorter paths used below still work but emit deprecation warnings, so switch when you pin a version.""")

s = rep(s, "With sentence-transformers (version 3 onward, current 5.x), training uses a Hugging Face-style trainer:",
"With sentence-transformers (version 3 onward; version 6 at the time of writing), training uses a Hugging Face-style trainer:")

s = rep(s, "- Mix sources (BM25 negatives look lexically similar, dense negatives look semantically similar).",
"""- Mix sources (BM25 negatives look lexically similar, dense negatives look semantically similar).
- You do not have to write the miner yourself: `sentence_transformers.util.mine_hard_negatives` takes a dataset of (anchor, positive) pairs, an embedding model and optionally a cross-encoder, and implements the rank window (`range_min`, `range_max`), the number of negatives per query and the false-negative filters of 2.4 (`relative_margin`, `absolute_margin`, `max_score`). Lab 2 shows both the hand-written version (so you understand it) and the one-call version.""")

s = rep(s, """Inspect a few dropped negatives: some will be genuinely relevant abstracts that the labels missed. That is the false-negative problem of Chapter 2.4 made visible.""",
"""Inspect a few dropped negatives: some will be genuinely relevant abstracts that the labels missed. That is the false-negative problem of Chapter 2.4 made visible.

The same mining in one call with the library utility (`relative_margin=0.05` drops negatives scoring above 95% of the positive, as above; `range_min` skips the top ranks where unlabelled positives concentrate):

```python
from sentence_transformers.util import mine_hard_negatives
pairs = Dataset.from_dict({"anchor": [qtext[q] for q in train_q for _ in rel_train[q]],
                           "positive": [id2text[d] for q in train_q for d in rel_train[q]]})
mined = mine_hard_negatives(pairs, base_model, corpus=doc_texts, cross_encoder=CrossEncoder("BAAI/bge-reranker-v2-m3", device=DEVICE),
                            range_min=10, range_max=50, num_negatives=1, relative_margin=0.05,
                            sampling_strategy="random", output_format="triplet", batch_size=64)
print(mined)   # columns: anchor, positive, negative
```

One difference from the hand-written loop: the utility treats every passage in `corpus` that is not the row's own positive as a candidate negative, so when a query has several labelled positives, pass them as separate rows (as above) and expect the other positives to be filtered by the cross-encoder margin rather than by the labels.""")

s = rep(s, "This lab teaches a 0.5B-parameter instruct model to answer from the right source among distractors, cite it, and abstain when no source answers. Paste Part 1's `CORPUS`, `split_sentences` and `chunk_document`. Step 1",
"This lab teaches a 0.5B-parameter instruct model to answer from the right source among distractors, cite it, and abstain when no source answers. The Nimbus corpus comes from `ragkit`. Step 1")
s = rep(s, "```python\nfrom transformers import AutoTokenizer, AutoModelForCausalLM\nchunks = [c for d in CORPUS for c in chunk_document(d)]\nTEACHER",
"```python\nfrom ragkit import CORPUS, split_sentences, chunk_document\nfrom transformers import AutoTokenizer, AutoModelForCausalLM\nchunks = [c for d in CORPUS for c in chunk_document(d)]\nTEACHER")
save(p, s)
print("Part 7 ok")
