from edit import *
p, s = load("09")
s = setup_line(s, '!pip install -q -U "sentence-transformers>=5.0" "transformers>=4.56" accelerate opentelemetry-sdk', 'accelerate opentelemetry-sdk')
s = rep(s, "- **FP8** weights and activations on GPUs that support it (Hopper and newer) give large speedups with little loss; T4s support neither FP8 nor fast bfloat16.",
"- **FP8** weights and activations on GPUs that support it (NVIDIA Ada Lovelace such as the L4 and RTX 40 series, Hopper such as the H100, Blackwell, and AMD MI300-class parts) give large speedups with little loss; the T4 (Turing) supports neither FP8 nor fast bfloat16, which is why the labs use float16 there.")
s = rep(s, "Paste Part 1's `CORPUS`, `split_sentences` and `chunk_document`. Then:\n\n```python\nimport numpy as np, re, json, time, hashlib, torch\n",
"The Nimbus corpus comes from `ragkit`:\n\n```python\nfrom ragkit import CORPUS, split_sentences, chunk_document, EVAL_SET\nimport numpy as np, re, json, time, hashlib, torch\n")
s = rep(s, "The SQL below was run on PostgreSQL 16 with pgvector 0.6 (the Ubuntu package): for the same query, an engineering user got the engineering-only chunk first, and a sales user did not get it at all.",
"The SQL below was run on PostgreSQL 16 with pgvector 0.6 (the version in the sandbox's Ubuntu packages; it uses only features available since pgvector 0.5, so it also runs on the current 0.8.x releases, which you should use in production for the iterative index scans discussed in Part 3). For the same query, an engineering user got the engineering-only chunk first, and a sales user did not get it at all.")
save(p, s)

p, s = load("10")
s = rep(s, "Paste Part 1's `CORPUS`, `split_sentences`, `chunk_document` and `EVAL_SET`, and Part 2's `HARD_SET`. Then:\n\n```python\nimport numpy as np, re, torch, warnings\n",
"The Part 1 and Part 2 objects come from `ragkit`:\n\n```python\nfrom ragkit import CORPUS, split_sentences, chunk_document, EVAL_SET, HARD_SET\nimport numpy as np, re, torch, warnings\n")
s = rep(s, "Haystack provides agent components with tools, routers for conditional branches (Part 5), evaluators, and Hayhooks for exposing pipelines as REST endpoints or MCP tools (Part 8). Its explicit typing and serialisation make it a common choice when RAG pipelines are maintained by platform teams.",
"Haystack provides an `Agent` component with tools and **hooks** (callbacks before and after tool calls and model calls, which is where you put approval, logging and guardrails), routers for conditional branches (Part 5), evaluators, and Hayhooks for exposing pipelines as REST endpoints or MCP tools (Part 8). Two Haystack 3 details matter in production: components and pipelines have a symmetric lifecycle (`warm_up` acquires models and connections, `close` releases them, so long-running services do not leak GPU memory or connections), and the heavy optional components (Sentence Transformers embedders and rankers, Whisper, Tika, the Hugging Face API components) now live in separately released integration packages, which keeps the core dependency set small but means one more package to pin. Its explicit typing and serialisation make it a common choice when RAG pipelines are maintained by platform teams.")
save(p, s)

p, s = load("11")
s = rep(s, "The field moves quickly: models, frameworks and protocols changed several times while this guide was written (for example the MCP Python SDK's 2.0 rename, Haystack 3, LangChain's package moves, sentence-transformers 6 renaming tokenizer\\_kwargs, transformers 5 removing warmup\\_ratio, and the EU AI Act's 2026 amendments).",
"The field moves quickly: models, frameworks and protocols changed several times while this guide was written (for example the MCP Python SDK's 2.0 rename of `FastMCP` to `MCPServer`, Haystack 3 moving its Sentence Transformers components into integration packages, LangChain's package moves, sentence-transformers 5.4 renaming `tokenizer_kwargs` to `processor_kwargs` and 6.0 adding `MultiVectorEncoder`, transformers 5 removing `warmup_ratio`, Gemma 4 and Gemini Embedding 2 arriving, and the EU AI Act's 2026 Digital Omnibus amendments).")
save(p, s)
print("Parts 9-11 ok")
