from edit import *

p, s = load("04")
s = setup_line(s, '!pip install -q -U "sentence-transformers>=5.0" "transformers>=4.56" pypdf pymupdf pdfplumber reportlab pandas', 'pypdf pymupdf pdfplumber reportlab pandas')
save(p, s)

p, s = load("02")
s = rep(s, "The lab in Chapter 7 reuses `CORPUS`, `split_sentences`, `chunk_document` and `EVAL_SET` from Part 1 Chapter 5, so paste those cells at the top of the Part 2 notebook first; everything else is defined in the lab.",
"The lab in Chapter 7 reuses `CORPUS`, `split_sentences`, `chunk_document` and `EVAL_SET` from Part 1 Chapter 5; the notebook imports them from `ragkit`, so upload `code/ragkit.py` first. Everything else is defined in the lab.")
s = rep(s, "Paste `CORPUS`, `split_sentences`, `chunk_document` and `EVAL_SET` from Part 1 Chapter 5, then run:\n\n```python\nimport re, numpy as np, torch\nimport torch.nn.functional as F\nfrom sentence_transformers import SentenceTransformer\n",
"Import the Part 1 objects from `ragkit`, then run:\n\n```python\nfrom ragkit import CORPUS, split_sentences, chunk_document, EVAL_SET   # Part 1, Chapter 5\nimport re, numpy as np, torch\nimport torch.nn.functional as F\nfrom sentence_transformers import SentenceTransformer\n")
save(p, s)

p, s = load("03")
s = rep(s, "Index the Part 1 Nimbus chunks (paste `CORPUS`, `split_sentences` and `chunk_document` from Part 1) with permission metadata, then query with a filter:\n\n```python\nfrom qdrant_client import QdrantClient, models\n",
"Index the Part 1 Nimbus chunks with permission metadata, then query with a filter:\n\n```python\nfrom ragkit import CORPUS, split_sentences, chunk_document\nfrom qdrant_client import QdrantClient, models\n")
save(p, s)

p, s = load("05")
s = setup_line(s, '!pip install -q -U "sentence-transformers>=5.0" "transformers>=4.56" accelerate bm25s pandas pydantic', 'accelerate bm25s pandas pydantic scikit-learn')
s = rep(s, "Compare against the hybrid row from Lab 0. Recall@10 after reranking can never exceed the first stage's recall@50, because the reranker only reorders those 50 candidates.",
"Compare against the hybrid row from Lab 0. Recall@10 after reranking can never exceed the first stage's recall@50, because the reranker only reorders those 50 candidates. A note on the scores: for single-output rerankers such as these, `CrossEncoder.predict` applies a sigmoid by default (since sentence-transformers 4), so scores lie in \\[0, 1\\] and the thresholds used in Lab 8 and Exercise 6 are on that scale; pass `activation_fn=None` if you want raw logits. Since version 6 the sigmoid is computed in float32 even for float16 models, which avoids ties at the top of the list.")
s = rep(s, "Using the Part 1 Nimbus corpus (paste `CORPUS`, `split_sentences` and `chunk_document`), build one function that traces each stage:\n\n```python\nchunks = [c for doc in CORPUS for c in chunk_document(doc)]\n",
"Using the Part 1 Nimbus corpus, build one function that traces each stage:\n\n```python\nfrom ragkit import CORPUS, split_sentences, chunk_document, EVAL_SET\nchunks = [c for doc in CORPUS for c in chunk_document(doc)]\n")
save(p, s)

p, s = load("06")
s = setup_line(s, '!pip install -q -U "sentence-transformers>=5.0" "transformers>=4.56" accelerate bm25s pandas scipy scikit-learn', 'accelerate bm25s pandas scipy scikit-learn')
s = rep(s, "Run Part 5's Lab 0 cell (SciFact, `doc_ids`, `query_ids`, `rel`, bge-small with `embed_docs` and `embed_queries`, BM25, `S_dense`, `S_bm25`, `S_hybrid`, the Qwen3-4B `chat` function). Then paste Part 1's `CORPUS`, `split_sentences` and `chunk_document`.\n\n```python\nimport numpy as np, re, json\n",
"Run Part 5's Lab 0 cell (SciFact, `doc_ids`, `query_ids`, `rel`, bge-small with `embed_docs` and `embed_queries`, BM25, `S_dense`, `S_bm25`, `S_hybrid`, the Qwen3-4B `chat` function); the notebook for this part includes a copy of that cell. The Nimbus corpus comes from `ragkit`.\n\n```python\nfrom ragkit import CORPUS, split_sentences, chunk_document\nimport numpy as np, re, json\n")
save(p, s)
print("Parts 2-6 ok")
