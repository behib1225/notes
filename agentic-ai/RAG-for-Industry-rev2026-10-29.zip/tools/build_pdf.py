import re, subprocess, sys, pathlib, tempfile, shutil
ROOT = pathlib.Path("/home/claude/rag2"); MD = ROOT/"tutorial/markdown"; OUT = ROOT/"tutorial/pdf"; OUT.mkdir(exist_ok=True)
TOOLS = pathlib.Path("/home/claude/tools")
def build(src):
    s = src.read_text()
    title = s.splitlines()[0].lstrip("# ").strip()
    s = re.sub(r"```latex\n(.*?)\n```", lambda m: "$$" + m.group(1) + "$$", s, flags=re.S)
    s = s.replace("](../diagrams/", "](" + str(ROOT/"tutorial/diagrams") + "/").replace(".svg)", ".pdf)")
    # the italic caption line after each image duplicates pandoc's figure caption: drop it
    s = re.sub(r"(!\[[^\]]*\]\([^)]*\))\n\n\*[^\n]*\*\n", r"\1\n", s)
    s = s.replace("𝓛", "$\\mathcal{L}$").replace("𝓜", "$\\mathcal{M}$")
    tmp = src.with_suffix(".build.md"); tmp.write_text(s)
    out = OUT/(src.stem + ".pdf")
    cmd = ["pandoc", str(tmp), "-o", str(out), "-f", "markdown-raw_html", "--pdf-engine=xelatex",
           "-V", "mainfont=DejaVu Sans", "-V", "monofont=DejaVu Sans Mono", "-V", "sansfont=DejaVu Sans",
           "-V", "geometry:margin=2.0cm", "-V", "fontsize=10pt", "-V", "colorlinks=true", "-V", "linkcolor=blue",
           "-V", "urlcolor=blue", "-V", f"header-includes=\\newcommand{{\\doctitle}}{{{title}}}",
           "-H", str(TOOLS/"header.tex"), "--highlight-style=tango", "--toc", "--toc-depth=2",
           "-M", f"title={title}", "-M", "date=Revised 29 October 2026"]
    r = subprocess.run(cmd, capture_output=True, text=True, env={**__import__('os').environ, "TEXINPUTS": f"{TOOLS}/tex//:"})
    tmp.unlink()
    if r.returncode: print(src.name, "FAILED\n", r.stderr[-3000:]); return False
    print(src.name, "->", out.name); return True
parts = sys.argv[1:] or [p.name[5:7] for p in sorted(MD.glob("Part-*.md"))]
ok = all(build(next(MD.glob(f"Part-{n}-*.md"))) for n in parts)
sys.exit(0 if ok else 1)
