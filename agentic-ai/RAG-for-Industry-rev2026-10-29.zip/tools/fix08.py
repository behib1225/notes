from edit import *
p, s = load("08")

s = setup_line(s, '!pip install -q -U "sentence-transformers>=5.0" "transformers>=4.56" accelerate bm25s networkx langgraph mcp matplotlib', 'accelerate bm25s networkx "langgraph>=1.0" "mcp>=2.0" matplotlib pillow')

s = rep(s, "Paste Part 1's `CORPUS`, `split_sentences` and `chunk_document`, then add two documents that link facts across the corpus:\n\n```python\nimport json, re, time, numpy as np, torch\n",
"Import the Part 1 corpus from `ragkit`, then add two documents that link facts across the corpus:\n\n```python\nfrom ragkit import CORPUS, split_sentences, chunk_document\nimport json, re, time, numpy as np, torch\n")

# Agentic search RL paragraph after 2.6 deep research
s = rep(s, "That trade-off is typical: breadth and quality bought with cost, so these systems fit high-value questions, not every query.",
"""That trade-off is typical: breadth and quality bought with cost, so these systems fit high-value questions, not every query.

**Training the search behaviour itself.** A 2025 research line trains the model to interleave reasoning and search calls with reinforcement learning rather than prompting: Search-R1 (Jin et al., 2025) rewards the final answer's correctness and lets the policy learn when to issue `<search>` queries and how to use the returned passages; ReSearch, R1-Searcher and later work follow the same recipe, and the commercial deep-research products are widely assumed to be trained this way. For an engineer the consequence is practical: the quality of an agent's search behaviour is a property of the model's training, not only of your prompt, so compare models on your own multi-step evaluation set (Chapter 2.7) before tuning the loop around them.""")

s = rep(s, "| LlamaIndex Workflows, Pydantic AI, CrewAI, smolagents, Strands Agents, Mastra | Varied: event workflows, typed agents, role-based crews, code agents, AWS-oriented, TypeScript | Specific ecosystems and styles |",
"| Haystack 3 Agent (with hooks and typed pipelines, Part 10) | Agent component inside Haystack's pipeline model | Teams already on Haystack |\n| LlamaIndex Workflows, Pydantic AI, CrewAI, smolagents, Strands Agents, Mastra | Varied: event workflows, typed agents, role-based crews, code agents, AWS-oriented, TypeScript | Specific ecosystems and styles |")

# ColPali via MultiVectorEncoder
s = rep(s, "Production systems therefore combine compression (binarisation, pooling of similar patch vectors) with a cheap first stage: a single-vector index or a fixed-size encoding of the multi-vector set (for example MUVERA, Google, 2024) retrieves candidates, and full MaxSim reranks them.",
"""Production systems therefore combine compression (binarisation, pooling of similar patch vectors) with a cheap first stage: a single-vector index or a fixed-size encoding of the multi-vector set (for example MUVERA, Google, 2024) retrieves candidates, and full MaxSim reranks them.

Tooling has converged: since sentence-transformers 6.0 the `MultiVectorEncoder` class (Part 2, Chapter 4.3) loads the `vidore` ColPali and ColQwen checkpoints, encodes page images with `encode_document` and text queries with `encode_query`, scores with MaxSim through `similarity`, and offers `HierarchicalTokenPooling` for the patch pooling in the table above. Lab 6 includes an optional cell.""")

s = rep(s, "CLIP should match the chart types because they are what the images depict. Now try a query about a value printed in a chart title or an axis label: CLIP-style models rarely read text in images reliably, which is the gap ColPali-style models and VLM descriptions fill (Chapter 5).",
"""CLIP should match the chart types because they are what the images depict. Now try a query about a value printed in a chart title or an axis label: CLIP-style models rarely read text in images reliably, which is the gap ColPali-style models and VLM descriptions fill (Chapter 5).

**Optional: the same images with a ColPali-style model.** Checked against the sentence-transformers 6 documentation, not executed; a ColQwen2 model needs a GPU with several gigabytes free, so run it after unloading the 4B generator.

```python
from sentence_transformers import MultiVectorEncoder
colqwen = MultiVectorEncoder("vidore/colqwen2-v1.0", device=DEVICE)          # visual document retriever
page_embs = colqwen.encode_document([Image.open(f"{k}.png") for k in kinds])   # one matrix of patch vectors per image
for query in ["a pie chart", "the chart titled QL", "a scatter plot"]:
    q_emb = colqwen.encode_query([query])
    scores = colqwen.similarity(q_emb, page_embs)                              # MaxSim over patches
    scores = scores.float().cpu().numpy() if hasattr(scores, "cpu") else np.asarray(scores)
    print(f"{query:<24} ->", kinds[int(np.argmax(scores[0]))])
print("patch vectors per page:", [len(e) for e in page_embs])                 # about a thousand, as in Chapter 5.3
```

The query about the title ("QL") is the one CLIP cannot answer; a model that encodes the page as patches and matches query tokens against them can read it.""")

s = rep(s, "- Yao et al. (2024). [τ-bench", "- Jin et al. (2025). [Search-R1: Training LLMs to Reason and Leverage Search Engines with Reinforcement Learning](https://arxiv.org/abs/2503.09516).\n- Yao et al. (2024). [τ-bench")
save(p, s)
print("Part 8 ok")
