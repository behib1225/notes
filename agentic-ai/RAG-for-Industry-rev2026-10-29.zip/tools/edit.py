"""Tiny, strict find/replace helper: every target must occur exactly once."""
import re, sys, pathlib

MD = pathlib.Path("/home/claude/rag2/tutorial/markdown")

CORE = '"sentence-transformers>=6.0,<7" "transformers>=5.0,<6"'


def load(name):
    p = next(MD.glob(f"Part-{name}-*.md"))
    return p, p.read_text()


def save(p, s):
    p.write_text(s)


def rep(s, old, new, count=1):
    n = s.count(old)
    if n != count:
        print(f"!!! expected {count} occurrence(s), found {n} for:\n{old[:200]}", file=sys.stderr)
        sys.exit(1)
    return s.replace(old, new)


def setup_line(s, old_line, extras=""):
    new = f'!pip install -q -U {CORE} {extras}'.rstrip()
    return rep(s, old_line, new)


def insert_before(s, anchor, text):
    return rep(s, anchor, text + anchor)


def insert_after(s, anchor, text):
    return rep(s, anchor, anchor + text)
