import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
import numpy as np, pathlib

OUT = pathlib.Path("/home/claude/rag2/tutorial/diagrams")
OUT.mkdir(parents=True, exist_ok=True)

C = {"blue": "#dbe8f7", "blue_e": "#4f7fb5", "green": "#dff2e1", "green_e": "#4a9460",
     "orange": "#fde9d2", "orange_e": "#d08a3a", "grey": "#eeeeee", "grey_e": "#888888",
     "red": "#f9dcdc", "red_e": "#c0504d", "purple": "#e9e1f5", "purple_e": "#7a5aa8",
     "yellow": "#fbf3cf", "yellow_e": "#c9a227", "white": "#ffffff"}

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})


def fig(w=10, h=4):
    f, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w); ax.set_ylim(0, h); ax.axis("off")
    return f, ax


def box(ax, x, y, w, h, title, sub=None, color="blue", fs=9, bold=True, lw=1.2):
    face, edge = C[color], C.get(color + "_e", "#666666")
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02,rounding_size=0.08",
                                fc=face, ec=edge, lw=lw))
    if sub:
        ax.text(x + w / 2, y + h * 0.62, title, ha="center", va="center", fontsize=fs,
                fontweight="bold" if bold else "normal")
        ax.text(x + w / 2, y + h * 0.3, sub, ha="center", va="center", fontsize=fs - 1.5, color="#444")
    else:
        ax.text(x + w / 2, y + h / 2, title, ha="center", va="center", fontsize=fs,
                fontweight="bold" if bold else "normal")
    return (x, y, w, h)


def arrow(ax, p1, p2, label=None, color="#555", style="-|>", lw=1.3, ls="-", lpos=0.5, dy=0.12, fs=7.5):
    ax.add_patch(FancyArrowPatch(p1, p2, arrowstyle=style, mutation_scale=12, color=color, lw=lw,
                                 linestyle=ls, shrinkA=2, shrinkB=2))
    if label:
        x = p1[0] + (p2[0] - p1[0]) * lpos; y = p1[1] + (p2[1] - p1[1]) * lpos
        ax.text(x, y + dy, label, ha="center", va="bottom", fontsize=fs, color="#333",
                bbox=dict(fc="white", ec="none", pad=0.5))


def right(b): return (b[0] + b[2], b[1] + b[3] / 2)
def left(b): return (b[0], b[1] + b[3] / 2)
def top(b): return (b[0] + b[2] / 2, b[1] + b[3])
def bottom(b): return (b[0] + b[2] / 2, b[1])


def label(ax, x, y, text, fs=8, color="#333", ha="center", **kw):
    ax.text(x, y, text, ha=ha, va="center", fontsize=fs, color=color, **kw)


def save(f, name, title=None):
    if title:
        f.suptitle(title, fontsize=10.5, fontweight="bold", y=0.995, x=0.01, ha="left")
    for ext in ("svg", "pdf", "png"):
        f.savefig(OUT / f"{name}.{ext}", bbox_inches="tight", dpi=170 if ext == "png" else None,
                  facecolor="white")
    plt.close(f)
    print("saved", name)
