from diag import *

# 1 ---------------------------------------------------------------- RAG architecture
f, ax = fig(11, 4.6)
label(ax, 2.6, 4.3, "Indexing pipeline (offline, when documents change)", fs=9.5, fontweight="bold")
label(ax, 8.4, 4.3, "Query pipeline (online, per request)", fs=9.5, fontweight="bold")
idx = ["Load", "Parse &\nclean", "Chunk\n+ metadata", "Embed", "Store"]
bs = []
for i, t in enumerate(idx):
    bs.append(box(ax, 0.2 + i * 1.02, 3.1, 0.9, 0.8, t, color="green", fs=8))
    if i: arrow(ax, right(bs[i - 1]), left(bs[i]))
index = box(ax, 4.2, 1.1, 2.4, 1.3, "INDEX", "vectors + text + metadata\n(+ keyword index)", color="yellow", fs=11)
arrow(ax, bottom(bs[4]), (5.0, 2.4))
q = ["Process\nquery", "Retrieve\n(filters)", "Rerank", "Augment\n(prompt)", "Generate\n(cite)", "Post-\nprocess"]
qs = []
for i, t in enumerate(q):
    qs.append(box(ax, 5.6 + i * 0.9, 3.1, 0.8, 0.8, t, color="blue", fs=7.5))
    if i: arrow(ax, right(qs[i - 1]), left(qs[i]))
arrow(ax, (5.9, 2.4), bottom(qs[1]), label="top-k", lpos=0.4, dy=0.0)
label(ax, 1.9, 2.0, "writes", fs=8, color="#4a9460"); label(ax, 7.3, 2.0, "reads", fs=8, color="#4f7fb5")
box(ax, 0.2, 0.2, 2.2, 0.6, "Documents", "files, wikis, tickets, DBs", color="grey", fs=8)
arrow(ax, (1.3, 0.8), bottom(bs[0]), ls="--")
box(ax, 8.6, 0.2, 2.2, 0.6, "User + identity", "question, groups, tenant", color="grey", fs=8)
arrow(ax, (9.7, 0.8), bottom(qs[0]), ls="--")
label(ax, 5.4, 0.5, "Permission filters come from the identity, never from the prompt", fs=8, color="#c0504d")
save(f, "p01_rag_architecture", "RAG architecture: two pipelines around one index")

# 2 ---------------------------------------------------------------- debug order
f, ax = fig(11, 2.6)
steps = [("1. In the corpus?", "search raw documents", "Missing content\n(failure point 1)"),
         ("2. Retrieved?", "in the candidate list", "Not retrieved\n(point 2)"),
         ("3. In the prompt?", "survived rerank/budget", "Not in context\n(point 3)"),
         ("4. Used correctly?", "answer matches evidence", "Generation\n(points 4 to 7)")]
bs = []
for i, (t, s, fail) in enumerate(steps):
    bs.append(box(ax, 0.3 + i * 2.7, 1.3, 2.2, 0.9, t, s, color="blue"))
    if i: arrow(ax, right(bs[i - 1]), left(bs[i]), label="yes", dy=0.05)
    fb = box(ax, 0.3 + i * 2.7, 0.15, 2.2, 0.7, fail, color="red", fs=8)
    arrow(ax, bottom(bs[i]), top(fb), label="no", color="#c0504d", lpos=0.5, dy=-0.02)
label(ax, 10.6, 1.75, "all yes:\nnot a RAG\nbug", fs=8, ha="left")
save(f, "p01_debug_order", "Debugging a wrong answer: stop at the first \"no\"")

# 3 ---------------------------------------------------------------- relevance architectures
f, ax = fig(11, 4.2)
cols = [("Bi-encoder", "blue", "interaction: one dot product\nprecompute: 1 vector / passage"),
        ("Learned sparse (SPLADE)", "purple", "interaction: shared terms\nprecompute: sparse vector"),
        ("Late interaction (ColBERT)", "orange", "interaction: token MaxSim\nprecompute: 1 vector / token"),
        ("Cross-encoder", "red", "interaction: every layer\nprecompute: nothing")]
for i, (t, c, s) in enumerate(cols):
    x0 = 0.2 + i * 2.7
    label(ax, x0 + 1.15, 3.95, t, fs=9.5, fontweight="bold")
    if i < 3:
        box(ax, x0, 2.4, 1.0, 1.1, "Encoder", "query q", color=c, fs=8)
        box(ax, x0 + 1.3, 2.4, 1.0, 1.1, "Encoder", "passage p", color=c, fs=8)
        if i == 0:
            box(ax, x0 + 0.65, 1.3, 1.0, 0.6, "q · p", color="grey", fs=9)
            arrow(ax, (x0 + 0.5, 2.4), (x0 + 1.0, 1.9)); arrow(ax, (x0 + 1.8, 2.4), (x0 + 1.3, 1.9))
        elif i == 1:
            box(ax, x0 + 0.65, 1.3, 1.0, 0.6, "Σ wq·wp", "over terms", color="grey", fs=8)
            arrow(ax, (x0 + 0.5, 2.4), (x0 + 1.0, 1.9)); arrow(ax, (x0 + 1.8, 2.4), (x0 + 1.3, 1.9))
        else:
            for k in range(3):
                ax.plot([x0 + 0.25 + k * 0.25], [2.1], "o", color=C["orange_e"], ms=5)
            for k in range(5):
                ax.plot([x0 + 1.4 + k * 0.2], [2.1], "s", color=C["orange_e"], ms=5)
            box(ax, x0 + 0.65, 1.3, 1.0, 0.6, "Σ max", "per query token", color="grey", fs=8)
            arrow(ax, (x0 + 0.5, 2.05), (x0 + 1.0, 1.9)); arrow(ax, (x0 + 1.8, 2.05), (x0 + 1.3, 1.9))
    else:
        box(ax, x0, 2.4, 2.3, 1.1, "One encoder", "[CLS] q [SEP] p [SEP]", color=c, fs=8)
        box(ax, x0 + 0.65, 1.3, 1.0, 0.6, "score", "one logit", color="grey", fs=8)
        arrow(ax, (x0 + 1.15, 2.4), (x0 + 1.15, 1.9))
    label(ax, x0 + 1.15, 0.7, s, fs=7.5)
ax.annotate("", xy=(10.7, 0.15), xytext=(0.3, 0.15), arrowprops=dict(arrowstyle="-|>", color="#555"))
label(ax, 5.5, 0.3, "more precise, slower, less precomputable  →", fs=8)
save(f, "p02_relevance_architectures", "Four ways to score a query against a passage")

# 4 ---------------------------------------------------------------- MaxSim
f, ax = fig(10, 3.2)
S = np.array([[0.8, 0.6, 1.0], [0.6, 0.8, 0.0]])
x0, y0, cw, ch = 1.6, 0.6, 1.1, 0.8
for i in range(2):
    for j in range(3):
        best = j == S[i].argmax()
        ax.add_patch(FancyBboxPatch((x0 + j * cw, y0 + (1 - i) * ch), cw - 0.05, ch - 0.05, boxstyle="square,pad=0",
                                    fc=C["orange"] if best else C["grey"], ec=C["orange_e"] if best else "#aaa", lw=2 if best else 1))
        ax.text(x0 + j * cw + cw / 2, y0 + (1 - i) * ch + ch / 2, f"{S[i, j]:.1f}", ha="center", va="center",
                fontsize=11, fontweight="bold" if best else "normal")
label(ax, 0.8, y0 + 1.5 * ch, "q1 = (1, 0)", fs=9); label(ax, 0.8, y0 + 0.5 * ch, "q2 = (0, 1)", fs=9)
for j, t in enumerate(["(0.8, 0.6)", "(0.6, 0.8)", "(1, 0)"]):
    label(ax, x0 + j * cw + cw / 2, y0 + 2 * ch + 0.2, f"passage token {j+1}\n{t}", fs=8)
label(ax, 5.6, y0 + 1.5 * ch, "max = 1.0", fs=10, ha="left", color=C["orange_e"], fontweight="bold")
label(ax, 5.6, y0 + 0.5 * ch, "max = 0.8", fs=10, ha="left", color=C["orange_e"], fontweight="bold")
label(ax, 7.3, y0 + ch, "MaxSim score\n= 1.0 + 0.8 = 1.8", fs=10.5, ha="left", fontweight="bold")
label(ax, 5.0, 0.15, "Each query token keeps only its best-matching passage token; the maxima are summed (Part 2, Exercise 7, passage A).", fs=8)
save(f, "p02_maxsim", "ColBERT late interaction: the MaxSim grid")

# 5 ---------------------------------------------------------------- IVF
rng = np.random.default_rng(3)
f, ax = fig(10, 4)
cent = np.array([[2, 3], [4.5, 2.2], [3.2, 0.9], [6.5, 3.1], [7.6, 1.2], [5.8, 1.0], [1.3, 1.1]])
pts = np.vstack([c + rng.normal(scale=0.42, size=(28, 2)) for c in cent])
q = np.array([5.2, 2.0])
d = np.linalg.norm(cent - q, axis=1); probe = np.argsort(d)[:2]
assign = np.argmin(((pts[:, None, :] - cent[None]) ** 2).sum(-1), axis=1)
for k in range(len(cent)):
    m = assign == k
    ax.scatter(pts[m, 0], pts[m, 1], s=12, color=C["blue_e"] if k in probe else "#bbb", alpha=0.9)
    ax.scatter(*cent[k], marker="X", s=90, color=C["red_e"] if k in probe else "#666", zorder=5)
    ax.text(cent[k, 0] + 0.15, cent[k, 1] + 0.18, f"c{k+1}", fontsize=8)
ax.scatter(*q, marker="*", s=220, color=C["yellow_e"], zorder=6, edgecolor="k")
ax.text(q[0] + 0.15, q[1] - 0.3, "query", fontsize=9, fontweight="bold")
for k in probe:
    ax.plot([q[0], cent[k, 0]], [q[1], cent[k, 1]], "--", color=C["red_e"], lw=1)
label(ax, 8.9, 3.6, "nlist = 7 centroids (k-means)\nnprobe = 2: only the blue\nlists are scanned exactly;\ngrey points are never touched.\n\nA true neighbour in a grey\ncell near a boundary is the\nrecall you lose.", fs=8, ha="left")
ax.set_xlim(0, 10); ax.set_ylim(0, 4)
save(f, "p03_ivf", "IVF: partition the space, search only the nearest lists")

# 6 ---------------------------------------------------------------- PQ
f, ax = fig(11, 3.6)
label(ax, 0.2, 3.2, "Vector x, d = 768 float32 (3,072 bytes)", fs=9, ha="left", fontweight="bold")
m = 8
for j in range(m):
    box(ax, 0.2 + j * 1.1, 2.4, 1.02, 0.55, f"sub-vector {j+1}", "96 dims", color="blue", fs=7.5, bold=False)
label(ax, 0.2, 1.95, "k-means with 256 centroids per sub-space → codebook j", fs=8.5, ha="left", bbox=dict(fc="white", ec="none", pad=1))
for j in range(m):
    box(ax, 0.2 + j * 1.1, 1.3, 1.02, 0.5, f"codebook {j+1}", "256 × 96 floats", color="purple", fs=7, bold=False)
    arrow(ax, (0.2 + j * 1.1 + 0.51, 2.4), (0.2 + j * 1.1 + 0.51, 1.8), lw=0.9)
label(ax, 0.2, 0.95, "code(x): m = 8 one-byte centroid ids (8 bytes instead of 3,072; the text's example uses m = 96 for a 32× saving)", fs=8.5, ha="left", bbox=dict(fc="white", ec="none", pad=1))
codes = rng.integers(0, 256, m)
for j in range(m):
    box(ax, 0.2 + j * 1.1, 0.25, 1.02, 0.5, str(codes[j]), color="orange", fs=10)
    arrow(ax, (0.2 + j * 1.1 + 0.51, 1.3), (0.2 + j * 1.1 + 0.51, 0.75), lw=0.9)
label(ax, 9.6, 1.55, "Query time (ADC):\nT[j, c] = ‖q_j − centroid_c‖²\n(m × 256 table), then\ndist(x) ≈ Σ_j T[j, code_j(x)]\n= m lookups per vector", fs=8, ha="left")
save(f, "p03_pq", "Product quantisation: split, quantise each piece, store the codes")

# 7 ---------------------------------------------------------------- HNSW
f, ax = fig(10, 4.4)
rng = np.random.default_rng(7)
base = rng.uniform([0.3, 0.1], [6.5, 1.2], size=(40, 2))
layers = [(base, 0.0, "Layer 0: every vector, up to 2M links"), (base[::4], 1.5, "Layer 1: ~1/M of the vectors"), (base[::16], 3.0, "Layer 2: entry point")]
def proj(p, dz): return (p[0] + 0.35 * dz, p[1] + dz)
qpt = np.array([5.6, 0.75])
for pts_l, dz, t in layers:
    poly = np.array([proj((0.1, 0.0), dz), proj((6.8, 0.0), dz), proj((6.8, 1.35), dz), proj((0.1, 1.35), dz)])
    ax.fill(poly[:, 0], poly[:, 1], color=C["blue"], alpha=0.5, ec=C["blue_e"], lw=0.8)
    P = np.array([proj(p, dz) for p in pts_l])
    # a few neighbour links
    for i in range(len(pts_l)):
        dd = np.linalg.norm(pts_l - pts_l[i], axis=1); nb = np.argsort(dd)[1:3]
        for jn in nb: ax.plot([P[i, 0], P[jn, 0]], [P[i, 1], P[jn, 1]], color="#9ab", lw=0.5)
    ax.scatter(P[:, 0], P[:, 1], s=10, color=C["blue_e"], zorder=4)
    ax.text(7.0 + 0.35 * dz, 0.9 + dz, t, fontsize=8, va="center")
# greedy path: entry (top) -> closest at each layer -> descend
path = []
for pts_l, dz, _ in reversed(layers):
    start = pts_l[np.argmin(np.linalg.norm(pts_l - (path[-1][0] if path else pts_l[0]), axis=1))] if path else pts_l[0]
    near = pts_l[np.argmin(np.linalg.norm(pts_l - qpt, axis=1))]
    path.append((near, dz))
    ax.plot([proj(start, dz)[0], proj(near, dz)[0]], [proj(start, dz)[1], proj(near, dz)[1]], color=C["red_e"], lw=1.8, zorder=5)
    ax.scatter(*proj(near, dz), s=40, color=C["red_e"], zorder=6)
for (p1, z1), (p2, z2) in zip(path, path[1:]):
    a, b = proj(p1, z1), proj(p2, z2)
    ax.plot([a[0], b[0]], [a[1], b[1]], color=C["red_e"], lw=1.3, ls="--", zorder=5)
ax.scatter(*proj(qpt, 0), marker="*", s=200, color=C["yellow_e"], ec="k", zorder=7)
ax.text(proj(qpt, 0)[0] + 0.1, proj(qpt, 0)[1] - 0.25, "query", fontsize=8.5, fontweight="bold")
label(ax, 7.0, 0.35, "Greedy descent through sparse upper layers (long jumps),\nthen a beam search of width efSearch on layer 0.", fs=8, ha="left")
ax.set_xlim(0, 10); ax.set_ylim(-0.3, 4.4)
save(f, "p03_hnsw", "HNSW: a layered graph searched from the top")

# 8 ---------------------------------------------------------------- hybrid pipeline
f, ax = fig(11, 3)
qb = box(ax, 0.2, 1.1, 1.3, 0.9, "Query", "+ user identity", color="grey")
bm = box(ax, 2.2, 1.9, 2.0, 0.85, "BM25 or SPLADE", "exact terms, codes\nACL filter inside", color="purple", fs=8)
de = box(ax, 2.2, 0.35, 2.0, 0.85, "Dense ANN", "paraphrase, meaning\nACL filter inside", color="blue", fs=8)
arrow(ax, right(qb), left(bm)); arrow(ax, right(qb), left(de))
fu = box(ax, 4.9, 1.1, 1.6, 0.9, "RRF fusion", "Σ 1/(60 + rank)", color="yellow")
arrow(ax, right(bm), left(fu), label="top 50 to 100", dy=0.08); arrow(ax, right(de), left(fu), label="top 50 to 100", dy=-0.3)
rr = box(ax, 7.2, 1.1, 1.6, 0.9, "Rerank", "cross-encoder or LLM", color="orange")
arrow(ax, right(fu), left(rr), label="top 20 to 100", dy=0.08)
pr = box(ax, 9.5, 1.1, 1.3, 0.9, "Prompt", "top 3 to 10", color="green")
arrow(ax, right(rr), left(pr))
save(f, "p03_hybrid_pipeline", "Hybrid retrieval: two retrievers in parallel, fused, then reranked")

# 9 ---------------------------------------------------------------- ingestion pipeline
f, ax = fig(11, 3.8)
st = ["Connect", "Parse", "Clean", "Dedup &\nfilter", "Chunk", "Enrich", "Embed", "Index"]
bs = []
for i, t in enumerate(st):
    bs.append(box(ax, 0.2 + i * 1.33, 2.2, 1.15, 0.85, t, color="green", fs=8.5))
    if i: arrow(ax, right(bs[i - 1]), left(bs[i]))
stores = {1: "raw files\n(versioned)", 2: "parsed docs\n(versioned)", 5: "chunks\n(content ids)", 6: "embedding\ncache", 7: "vector +\nkeyword index"}
for i, t in stores.items():
    sb = box(ax, 0.2 + i * 1.33, 0.7, 1.15, 0.8, t, color="yellow", fs=7.5, bold=False)
    arrow(ax, bottom(bs[i]), top(sb), lw=0.9)
label(ax, 0.2, 3.55, "events: create / update / delete / permission change  →  queue  →  idempotent workers", fs=8.5, ha="left")
label(ax, 5.5, 0.25, "Because every intermediate is stored, a new chunker replays from the parsed documents and a new embedding model replays from the chunks.", fs=8)
save(f, "p04_ingestion_pipeline", "Ingestion pipeline with versioned stores")

# 10 --------------------------------------------------------------- chunk overlap
f, ax = fig(10, 3.2)
Cn, o, e = 512, 50, 100
scale = 9.0 / 1500
def X(t): return 0.4 + t * scale
ax.plot([X(0), X(1500)], [2.6, 2.6], color="#999", lw=1); label(ax, X(0), 2.85, "tokens 0", fs=7.5); label(ax, X(1500), 2.85, "1,500", fs=7.5)
starts = list(range(0, 1500 - Cn + 1, Cn - o))
for i, s0 in enumerate(starts):
    y = 2.0 - (i % 2) * 0.45
    ax.add_patch(FancyBboxPatch((X(s0), y), Cn * scale, 0.35, boxstyle="square,pad=0", fc=C["blue"], ec=C["blue_e"], alpha=0.85))
    ax.text(X(s0) + 0.05, y + 0.17, f"chunk {i}", fontsize=7, va="center")
    if i:
        ax.add_patch(FancyBboxPatch((X(s0), y), o * scale, 0.35, boxstyle="square,pad=0", fc=C["orange"], ec="none"))
ev1 = (700, 800); ev2 = (880, 980)
for (a, b), col, txt, yy in [(ev1, C["green_e"], "evidence A (100 tok): inside chunk 1 ✓", 0.9), (ev2, C["red_e"], "evidence B (100 tok): split between chunks 1 and 2 ✗", 0.55)]:
    ax.add_patch(FancyBboxPatch((X(a), yy), (b - a) * scale, 0.22, boxstyle="square,pad=0", fc=col, ec="none"))
    ax.text(X(b) + 0.1, yy + 0.11, txt, fontsize=8, va="center")
label(ax, 5.0, 0.15, f"C = {Cn}, o = {o}: P(evidence of e = {e} tokens fits one chunk) ≈ (C − e)/(C − o) = {(Cn-e)/(Cn-o):.2f}; with o ≥ e it is 1.", fs=8.5)
save(f, "p04_chunk_overlap", "Fixed windows with overlap, and why a fact can still be cut")

# 11 --------------------------------------------------------------- parent-child
f, ax = fig(10, 3.2)
par = box(ax, 0.3, 1.2, 3.6, 1.6, "Parent: section (1,000 to 2,000 tokens)", color="yellow", fs=9)
ch = []
for i in range(4):
    ch.append(box(ax, 0.45 + i * 0.85, 1.35, 0.75, 0.7, f"child {i+1}", "100 to 300", color="blue", fs=7.5, bold=False))
label(ax, 2.1, 0.75, "index only the children", fs=8.5, color=C["blue_e"])
qb = box(ax, 5.0, 2.2, 1.6, 0.7, "Query", color="grey")
arrow(ax, (5.0, 2.55), top(ch[2]), label="matches child 3", color=C["blue_e"], lpos=0.6, dy=0.1)
out = box(ax, 5.0, 0.6, 4.6, 1.0, "Prompt receives the whole parent", "deduplicated when several children hit the same parent", color="green", fs=9)
arrow(ax, right(par), left(out), label="return the parent", dy=0.1)
label(ax, 7.3, 0.25, "Small units decide where to look; large units decide what the model reads. Cost: fewer parents fit the budget.", fs=8)
save(f, "p04_parent_child", "Parent-child (small-to-big) retrieval")

# 12 --------------------------------------------------------------- query pipeline
f, ax = fig(11, 3.2)
st = [("Understand", "rewrite, route,\nfilters", "0.2 to 1 s (LLM)\n< 5 ms (rules)"), ("Retrieve", "hybrid + ACL\n50 to 200 cand.", "10 to 100 ms"),
      ("Rerank", "cross-encoder\nor LLM", "30 to 300 ms\n(LLM: seconds)"), ("Assemble", "order, dedup,\ncompress, label", "< 5 ms"),
      ("Generate", "stream answer\nwith citations", "TTFT 0.2 to 1.5 s\nfull: 2 to 15 s"), ("Verify", "ids exist, quotes\nmatch, entailment", "ms to 1 s")]
bs = []
for i, (t, sub, lat) in enumerate(st):
    col = "blue" if i in (1, 4) else "grey"
    bs.append(box(ax, 0.2 + i * 1.8, 1.4, 1.6, 1.1, t, sub, color=col, fs=9))
    if i: arrow(ax, right(bs[i - 1]), left(bs[i]))
    label(ax, 1.0 + i * 1.8, 0.75, lat, fs=7.5)
label(ax, 5.5, 0.2, "Blue stages are mandatory; the others must pay for their latency with a measured quality gain. Generation usually dominates.", fs=8.5)
save(f, "p05_query_pipeline", "The query pipeline and where the time goes")

# 13 --------------------------------------------------------------- evaluation layers
f, ax = fig(10, 3.6)
l1 = box(ax, 0.3, 2.4, 9.4, 0.9, "Component evaluation", "parser, chunker, retriever (recall@k, nDCG), reranker, router, judge: fast, locates the problem", color="blue")
l2 = box(ax, 0.3, 1.3, 9.4, 0.9, "End-to-end offline evaluation", "fixed, versioned test set: correctness, faithfulness, citations, abstention, latency, cost: decides releases", color="green")
l3 = box(ax, 0.3, 0.2, 9.4, 0.9, "Online evaluation", "feedback, implicit signals, A/B tests, shadow traffic, monitoring: confirms with real users", color="orange")
arrow(ax, (9.0, 2.4), (9.0, 2.2)); arrow(ax, (9.0, 1.3), (9.0, 1.1))
ax.annotate("", xy=(0.6, 2.4), xytext=(0.6, 1.1), arrowprops=dict(arrowstyle="-|>", color=C["red_e"], lw=1.5, connectionstyle="arc3,rad=0.4"))
label(ax, 1.25, 1.75, "failures become\nnew test cases", fs=7.5, color=C["red_e"])
save(f, "p06_evaluation_layers", "Three evaluation layers and the feedback loop")

# 14 --------------------------------------------------------------- decide what to train
f, ax = fig(11, 3.4)
checks = [("Answer in corpus?", "no: add content\n(training cannot help)", "grey"),
          ("recall@50 low?", "cheaper: hybrid, chunking,\nbetter model → then\nfine-tune embedder", "blue"),
          ("recall ok, nDCG@10 low?", "cheaper: off-the-shelf\nreranker → then train\nor distil a reranker", "purple"),
          ("Evidence present,\nanswer wrong/uncited?", "cheaper: prompt, order,\nfewer chunks → then\nRAFT-style LoRA", "orange")]
bs = []
for i, (t, fix, col) in enumerate(checks):
    bs.append(box(ax, 0.3 + i * 2.7, 2.0, 2.3, 0.9, t, color=col))
    if i: arrow(ax, right(bs[i - 1]), left(bs[i]), label="no", dy=0.05)
    fb = box(ax, 0.3 + i * 2.7, 0.35, 2.3, 1.2, fix, color="yellow", fs=8, bold=False)
    arrow(ax, bottom(bs[i]), top(fb), label="yes", lpos=0.5, dy=-0.02)
label(ax, 5.5, 3.2, "Follow the data flow; in every branch training is the second step, after the cheaper fix has been measured.", fs=8.5)
save(f, "p07_decide_what_to_train", "Deciding what to train: cheapest fix first, in pipeline order")

# 15 --------------------------------------------------------------- LoRA
f, ax = fig(10, 3.4)
box(ax, 0.4, 0.8, 2.2, 2.2, "W₀", "d × k, frozen\n(16.8 M params for 4,096²)", color="grey", fs=12)
label(ax, 3.0, 1.9, "+", fs=16)
label(ax, 3.9, 1.9, "α/r ·", fs=11)
box(ax, 4.5, 0.8, 0.55, 2.2, "B", "d × r\ninit 0", color="orange", fs=11)
box(ax, 5.25, 2.45, 2.2, 0.55, "A", color="blue", fs=11)
label(ax, 6.35, 2.2, "r × k", fs=8)
label(ax, 6.4, 1.3, "trainable: r(d + k)\n= 16 × 8,192 = 131,072\n(0.8% of W₀)", fs=9)
arrow(ax, (4.5, 0.4), (7.5, 0.4), style="<->", color="#999", lw=1); label(ax, 6.0, 0.2, "merge BA into W₀ after training: no extra latency", fs=8)
label(ax, 8.9, 1.9, "QLoRA: W₀ stored\nin 4-bit NF4,\nadapters in 16-bit", fs=9)
save(f, "p07_lora", "LoRA: a frozen matrix plus a trainable low-rank update")

# 16 --------------------------------------------------------------- agent loop
f, ax = fig(11, 4.2)
llm = box(ax, 0.3, 2.6, 2.6, 1.2, "LLM", "reads messages + tool schemas\nreplies with text OR tool calls", color="blue", fs=10)
rt = box(ax, 4.2, 1.0, 4.0, 2.8, "", color="orange", fs=10)
label(ax, 6.2, 3.55, "Runtime (your code)", fs=10, fontweight="bold")
v1 = box(ax, 4.4, 2.75, 1.7, 0.6, "validate args", "schema, bounds", color="white", fs=8, bold=False)
v2 = box(ax, 6.3, 2.75, 1.7, 0.6, "permission check", "identity from session", color="white", fs=8, bold=False)
v3 = box(ax, 4.4, 1.9, 1.7, 0.6, "limits", "steps, tokens, time", color="white", fs=8, bold=False)
v4 = box(ax, 6.3, 1.9, 1.7, 0.6, "run tool", "search_docs, get_document", color="white", fs=8, bold=False)
v5 = box(ax, 4.4, 1.1, 3.6, 0.6, "evidence store", "id → text of all retrieved chunks; citations checked against it", color="yellow", fs=8, bold=False)
arrow(ax, right(llm), (4.2, 3.2), label="tool call(s)", dy=0.1)
arrow(ax, (4.2, 1.6), (2.0, 2.6), label="tool result (truncated)", lpos=0.55, dy=0.1)
tools = box(ax, 9.0, 2.0, 1.8, 1.4, "Tools / MCP\nservers", "index, DB, APIs", color="purple", fs=9)
arrow(ax, right(v4), left(tools)); arrow(ax, (9.0, 2.3), (8.0, 2.1))
ans = box(ax, 0.3, 0.6, 2.6, 0.9, "Final answer", "when no tool calls, or forced\nat the step limit", color="green", fs=9)
arrow(ax, bottom(llm), top(ans), label="text", dy=0.0)
label(ax, 5.5, 0.3, "The model proposes; the runtime decides. Everything that makes the agent safe lives in the orange box.", fs=8.5)
save(f, "p08_agent_loop", "The agent loop")

# 17 --------------------------------------------------------------- GraphRAG
f, ax = fig(11, 3.6)
b1 = box(ax, 0.2, 2.2, 1.8, 1.0, "Chunks", "documents", color="grey")
b2 = box(ax, 2.5, 2.2, 1.9, 1.0, "LLM extraction", "entities, relations\n(1+ call per chunk)", color="blue", fs=8.5)
b3 = box(ax, 4.9, 2.2, 1.9, 1.0, "Entity graph", "resolution merges\n'NX-7' = 'the NX-7'", color="purple", fs=8.5)
b4 = box(ax, 7.3, 2.2, 1.6, 1.0, "Leiden\ncommunities", "hierarchical", color="orange", fs=8.5)
b5 = box(ax, 9.3, 2.2, 1.5, 1.0, "Community\nsummaries", "LLM reports", color="yellow", fs=8.5)
for a, b in [(b1, b2), (b2, b3), (b3, b4), (b4, b5)]: arrow(ax, right(a), left(b))
g = box(ax, 6.6, 0.3, 4.2, 1.2, "Global question → map-reduce over summaries", "each report answers partially (map); best partials combined (reduce)", color="green", fs=8.5)
l = box(ax, 0.2, 0.3, 6.0, 1.2, "Local / multi-hop question → graph traversal", "query entities → neighbours, relations, source chunks; or personalized PageRank seeded at the query's entities (HippoRAG)", color="green", fs=8.5)
arrow(ax, bottom(b5), (8.7, 1.5)); arrow(ax, bottom(b3), (5.85, 1.5))
save(f, "p08_graphrag", "GraphRAG: build a graph once, answer two kinds of question")

# 18 --------------------------------------------------------------- ColPali
f, ax = fig(10, 3.6)
# page as patch grid
x0, y0 = 0.4, 0.5
for i in range(8):
    for j in range(6):
        ax.add_patch(FancyBboxPatch((x0 + j * 0.3, y0 + i * 0.3), 0.27, 0.27, boxstyle="square,pad=0", fc=C["blue"] if (i, j) not in [(5, 2), (2, 4)] else C["orange"], ec="#ccc", lw=0.5))
label(ax, x0 + 0.9, 3.1, "page image → ~1,030 patch vectors (128 d)", fs=8.5)
# query tokens
for k, t in enumerate(["what", "payload", "NX-7", "?"]):
    box(ax, 4.0, 2.4 - k * 0.55, 1.3, 0.45, t, color="green", fs=8.5, bold=False)
label(ax, 4.65, 3.1, "query → 1 vector per token", fs=8.5)
arrow(ax, (4.0, 1.5), (x0 + 2 * 0.3 + 0.15, y0 + 5 * 0.3 + 0.15), color=C["orange_e"], lw=1.2)
arrow(ax, (4.0, 0.95), (x0 + 4 * 0.3 + 0.15, y0 + 2 * 0.3 + 0.15), color=C["orange_e"], lw=1.2)
label(ax, 7.5, 2.2, "score(q, page) = Σ over query tokens of\nmax over patches of (token · patch)\n= MaxSim, exactly as in ColBERT", fs=9, ha="left")
label(ax, 7.5, 1.0, "Storage per page (float16): ~264 KB\nbinarised: ~16.5 KB; pooled to 1/3: ~88 KB\nvs 4 KB for one 1,024-d float32 vector", fs=8.5, ha="left")
save(f, "p08_colpali", "ColPali-style visual document retrieval")

# 19 --------------------------------------------------------------- reference architecture
f, ax = fig(11, 5.0)
label(ax, 0.3, 4.75, "Online path", fs=9.5, ha="left", fontweight="bold")
gw = box(ax, 0.3, 3.6, 1.4, 0.9, "API gateway", "auth, rate limits", color="grey", fs=8)
orc = box(ax, 2.0, 3.6, 1.8, 0.9, "Orchestrator", "rewrite, route,\nprompt, verify", color="blue", fs=8)
ret = box(ax, 4.1, 3.6, 1.9, 0.9, "Retrieval service", "hybrid + ACL filters\nfrom identity", color="blue", fs=8)
rer = box(ax, 6.3, 3.6, 1.4, 0.9, "Reranker", "GPU, batched", color="blue", fs=8)
lgw = box(ax, 8.0, 3.6, 1.4, 0.9, "LLM gateway", "routing, budgets,\nfallbacks, logs", color="orange", fs=8)
llm = box(ax, 9.7, 3.6, 1.1, 0.9, "Models", "vLLM / APIs", color="orange", fs=8)
for a, b in [(gw, orc), (orc, ret), (ret, rer), (rer, lgw), (lgw, llm)]: arrow(ax, right(a), left(b))
cache = box(ax, 2.0, 2.4, 4.0, 0.8, "Caches", "embeddings, retrieval results, verified answers\n(scoped by permission + versions), prompt prefixes", color="yellow", fs=8)
idx = box(ax, 6.3, 2.4, 3.1, 0.8, "Indexes", "vector + keyword with ACL fields,\nblue-green collections", color="yellow", fs=8)
arrow(ax, bottom(ret), (5.0, 3.2), style="<->", lw=0.9); arrow(ax, (5.9, 3.6), (7.0, 3.2), style="<->", lw=0.9)
label(ax, 0.3, 2.0, "Offline path", fs=9.5, ha="left", fontweight="bold")
con = box(ax, 0.3, 0.9, 1.6, 0.8, "Connectors", "content, ACLs,\ndeletes", color="green", fs=8)
qu = box(ax, 2.2, 0.9, 1.2, 0.8, "Queue", "fast ACL lane", color="green", fs=8)
wk = box(ax, 3.7, 0.9, 2.1, 0.8, "Ingestion workers", "parse, chunk, enrich,\nembed (GPU batches)", color="green", fs=8)
for a, b in [(con, qu), (qu, wk)]: arrow(ax, right(a), left(b))
arrow(ax, right(wk), (6.5, 2.4), label="upsert / reconcile", lpos=0.5, dy=0.05)
sup = box(ax, 6.3, 0.8, 4.5, 1.0, "Supporting services", "observability (traces, metrics) · evaluation in CI + online judges\nregistries (prompts, models, indexes) · feedback store · secrets", color="purple", fs=8)
label(ax, 5.5, 0.35, "Content reaches a prompt only through the retrieval service; models are reached only through the gateway.", fs=8.5, color="#c0504d")
save(f, "p09_reference_architecture", "Production RAG reference architecture")

# 20 --------------------------------------------------------------- KV budget
f, ax = fig(10, 3.2)
parts = [("model weights (fp16)", 8.0, "grey"), ("overhead", 1.5, "red"), ("KV cache", 6.5, "blue")]
x = 0.5; scale = 7.5 / 16
for t, v, c in parts:
    ax.add_patch(FancyBboxPatch((x, 1.6), v * scale, 0.8, boxstyle="square,pad=0", fc=C[c], ec=C[c + "_e"]))
    ax.text(x + v * scale / 2, 2.0, f"{t}\n{v} GB", ha="center", va="center", fontsize=8)
    x += v * scale
label(ax, 4.25, 2.75, "T4: 16 GB, Qwen3-4B (36 layers, 8 KV heads, head dim 128, fp16)", fs=9, fontweight="bold")
label(ax, 0.5, 1.2, "KV per token = 2 × 36 × 8 × 128 × 2 B = 144 KiB  →  6.5 GiB holds about 47,000 tokens in total", fs=8.5, ha="left")
rows = [(2000, 23), (8000, 5), (32000, 1)]
for i, (ctx, n) in enumerate(rows):
    label(ax, 0.6, 0.75 - i * 0.28, f"prompts of {ctx:,} tokens → at most {n} concurrent request{'s' if n > 1 else ''}", fs=8.5, ha="left")
label(ax, 8.7, 0.5, "prompt length is\na capacity decision", fs=9, color="#c0504d", fontweight="bold")
save(f, "p09_kv_budget", "GPU memory budget: weights, overhead, KV cache")

# 21 --------------------------------------------------------------- design time budget
f, ax = fig(11, 2.2)
steps = [("Clarify", 5, "grey"), ("Define success", 4, "green"), ("Estimate", 3, "yellow"), ("Architecture", 8, "blue"),
         ("Deep dives (2 to 3)", 15, "orange"), ("Safety & failures", 5, "red"), ("Operate & iterate", 5, "purple")]
x = 0.3; scale = 10.4 / 45
for t, m, c in steps:
    ax.add_patch(FancyBboxPatch((x, 0.8), m * scale, 0.8, boxstyle="square,pad=0", fc=C[c], ec=C[c + "_e"]))
    ax.text(x + m * scale / 2, 1.2, (t if m > 4 else t.replace(" & ", " &\n").replace("Define success", "Define\nsuccess").replace("Operate & iterate","Operate &\niterate")) + f"\n{m} min", ha="center", va="center", fontsize=7.5 if m > 4 else 6.5)
    x += m * scale
ax.plot([0.3, 10.7], [0.6, 0.6], color="#999", lw=0.8)
for mm in (0, 15, 30, 45):
    ax.plot([0.3 + mm * scale] * 2, [0.52, 0.68], color="#999", lw=0.8); label(ax, 0.3 + mm * scale, 0.35, f"{mm} min", fs=7.5)
label(ax, 5.5, 1.9, "The first 12 minutes (clarify, success, estimate) are what make the deep dives credible.", fs=8.5)
save(f, "p11_design_time_budget", "A 45-minute RAG system-design round")
