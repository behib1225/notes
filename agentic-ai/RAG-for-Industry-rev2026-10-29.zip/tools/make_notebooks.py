import re, json, base64, pathlib

ROOT = pathlib.Path("/home/claude/rag2")
MD = ROOT / "tutorial/markdown"
NB = ROOT / "notebooks"
DI = ROOT / "tutorial/diagrams"
FENCE = re.compile(r"```python\n(.*?)\n```", re.S)
IMG = re.compile(r"!\[([^\]]*)\]\(\.\./diagrams/([\w\-]+)\.svg\)")


def md_cell(text):
    return {"cell_type": "markdown", "metadata": {}, "source": text}


def code_cell(text):
    return {"cell_type": "code", "metadata": {}, "execution_count": None, "outputs": [], "source": text}


def embed_images(text):
    def sub(m):
        data = base64.b64encode((DI / f"{m.group(2)}.png").read_bytes()).decode()
        return f"![{m.group(1)}](data:image/png;base64,{data})"
    return IMG.sub(sub, text)


def split(md):
    cells, pos = [], 0
    for m in FENCE.finditer(md):
        txt = md[pos:m.start()].strip()
        if txt:
            cells.append(md_cell(embed_images(txt)))
        cells.append(code_cell(m.group(1)))
        pos = m.end()
    tail = md[pos:].strip()
    if tail:
        cells.append(md_cell(embed_images(tail)))
    return cells


def part5_lab0():
    md = next(MD.glob("Part-05-*.md")).read_text()
    for m in FENCE.finditer(md):
        if m.group(1).startswith("import numpy as np, pandas as pd, re, json, time, torch, bm25s"):
            return m.group(1)
    raise RuntimeError("Part 5 Lab 0 not found")


SETUP = '''# Setup check: run this cell first (after the pip cell below has run once and the runtime restarted if asked).
# Upload code/ragkit.py from the bundle into the notebook's working directory (Colab: Files panel, drag and drop).
import os
assert os.path.exists("ragkit.py"), "Upload code/ragkit.py to the working directory first (see README.md)."
from ragkit import *          # Nimbus corpus, chunkers, metrics, statistics, loaders shared by all parts
import ragkit
print("ragkit loaded:", len(ragkit.CORPUS), "documents in the Nimbus corpus")'''

for src in sorted(MD.glob("Part-*.md")):
    md = src.read_text()
    num = src.name[5:7]
    title = src.name[:-3].replace("-", " ")
    intro = (f"*Notebook generated from **{title}** of the RAG for Industry guide (revised 29 October 2026). "
             "Cells follow the text in order. Run the pip cell first, then the ragkit setup cell. Lab cells are meant to be run in order "
             "on a GPU runtime (Runtime → Change runtime type → T4 GPU); exercise solutions and short illustrative snippets depend on "
             "earlier cells or are deliberate fragments. Model-downloading cells have not been executed by the authors; expected results "
             "are expectations, not measurements. Exact package versions: `requirements/part" + num + ".txt`.*")
    cells = split(md)
    # place the ragkit setup cell right after the first code cell (the pip install)
    first_code = next(i for i, c in enumerate(cells) if c["cell_type"] == "code")
    cells.insert(first_code + 1, code_cell(SETUP))
    if num == "06":
        for i, c in enumerate(cells):
            if c["cell_type"] == "code" and c["source"].startswith("from ragkit import CORPUS, split_sentences, chunk_document\nimport numpy as np, re, json"):
                cells.insert(i, md_cell("**Copied from Part 5, Lab 0** (SciFact, bge-small, BM25, hybrid scores and the `chat` function), so this notebook is self-contained:"))
                cells.insert(i + 1, code_cell(part5_lab0()))
                break
        else:
            raise RuntimeError("Part 6 Lab 0 anchor not found")
    nb = {"cells": [md_cell(intro)] + cells,
          "metadata": {"accelerator": "GPU", "colab": {"provenance": []},
                       "kernelspec": {"display_name": "Python 3", "name": "python3"},
                       "language_info": {"name": "python"}},
          "nbformat": 4, "nbformat_minor": 5}
    out = NB / (src.name[:-3] + ".ipynb")
    out.write_text(json.dumps(nb, ensure_ascii=False, indent=1))
    n_code = sum(c["cell_type"] == "code" for c in cells)
    print(out.name, len(cells) + 1, "cells,", n_code, "code")
