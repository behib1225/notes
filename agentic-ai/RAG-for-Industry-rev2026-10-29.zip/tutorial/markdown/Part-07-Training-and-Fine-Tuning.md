# RAG for Industry, Part 7: Training and Fine-Tuning

Oct 28, 2026 · @Behi · revised 29 October 2026 (see CHANGELOG.md)

## How Part 7 fits

Everything so far used models off the shelf. Training your own components is the ML-track core of RAG, and application engineers increasingly do it too because the tooling has become simple. But training is also the most over-used fix: it costs data, compute and maintenance, and it only helps when the failure it targets is real and measured. This part teaches both how to train each component and how to decide whether to.

**After this part you will be able to:**

1. Decide, from a measured failure analysis, whether to fine-tune and which component.
2. Build retrieval training data from logs, labels or synthetic queries, mine hard negatives, filter false negatives, and split without leakage.
3. Fine-tune an embedding model with contrastive losses, including Matryoshka training, and measure the gain with paired statistics.
4. Train a cross-encoder reranker with pointwise, pairwise or listwise losses, or by distilling a stronger teacher.
5. Fine-tune a small generator for RAG behaviours (grounded answers, citations, abstention, robustness to distractors) with RAFT-style data and LoRA, and explain the LoRA and QLoRA arithmetic.
6. Evaluate, version, deploy and retrain fine-tuned models responsibly.

**Setup.** The same free Colab or Kaggle T4 notebook. The lab adds the training libraries:

```python
!pip install -q -U "sentence-transformers[train]>=6.0,<7" "transformers>=5.0,<6" datasets accelerate "peft>=0.18" "trl>=0.24" bm25s pandas
```

**Version check (October 2026).** The training code in this part was checked against the source code and documentation of sentence-transformers 6.x, transformers 5.x, TRL and PEFT; it has not been executed on a GPU. Three changes matter if you have older notebooks. First, transformers 5 removed the `warmup_ratio` training argument: pass `warmup_steps` with a value below 1 to mean a fraction of the total steps, as below. Second, sentence-transformers **5.4** renamed `tokenizer_kwargs` to `processor_kwargs` and renamed the trainers' `tokenizer` argument to `processing_class` (the version 6.0 release then added `MultiVectorEncoder` and made transformers 5 a requirement). Third, since 5.4 the canonical import paths are per model type (`sentence_transformers.sentence_transformer.losses`, `.training_args`, `.evaluation`); the shorter paths used below still work but emit deprecation warnings, so switch when you pin a version.

The lab trains on SciFact's training split (809 queries with labelled relevant abstracts) and evaluates on its test split, so you can measure real gains on held-out queries. Embedding and reranker fine-tuning take minutes on a T4; the generator exercise uses a small model so LoRA training also fits.

**Track notes.** Chapters 1 and 6 are for everyone: deciding whether to train and how to operate trained models are senior-engineer questions in any interview. Chapters 2 to 5 and the lab are the ML-track core.

## Chapter 1. Deciding what to train

Train a component only when evaluation shows that it is the bottleneck, cheaper fixes have been tried, and you have the data and the people to maintain the result. When those hold, train the cheapest component that fixes the failure: usually the reranker first, then the embedding model, and the generator only for behaviour problems.

![Deciding what to train: checks in pipeline order, cheapest fix first](../diagrams/p07_decide_what_to_train.svg)

*Deciding what to train: checks in pipeline order, cheapest fix first*

The checks follow the data flow, as in the debugging order of Part 1; in each branch, training is the second step, after the cheaper fix has been tried and measured.

### 1.1 Start from the failure analysis

Use the failure taxonomy from Part 1 (Chapter 6) and the metrics from Part 6 to find where answers go wrong:

| Symptom (measured) | Likely bottleneck | Cheaper fixes to try first | Training option |
| --- | --- | --- | --- |
| Answer not in the corpus | Content | Add or fix documents | None: training cannot invent content |
| Low recall@50 on domain queries (jargon, codes, internal names) | Embedding model | Hybrid search, better parsing and chunking, a stronger or domain-suited embedding model, query rewriting | Fine-tune the embedder |
| Good recall@50, poor nDCG@10 | Ranking | Off-the-shelf reranker, instruction-aware reranker, more candidates | Fine-tune or distil a reranker |
| Evidence in the prompt, answer ignores or misreads it | Generator reading | Fewer, cleaner chunks; ordering; prompt; a stronger model | Fine-tune the generator (RAFT-style) |
| Wrong format, missing citations, poor abstention despite good prompts | Generator behaviour | Structured output, examples in the prompt, validation | Fine-tune the generator |
| Quality fine, but too slow or costly | Model size | Caching, shorter context, smaller off-the-shelf models | Distil into a smaller model |

### 1.2 Why the reranker is usually first

- **No re-indexing**: a new reranker only changes query-time scoring, so you can deploy, A/B test and roll back in minutes.
- **Small data goes far**: a few thousand labelled (query, passage) judgements can noticeably improve ranking in a narrow domain.
- **Easy distillation**: a strong but slow teacher (a large LLM judge or reranker) can label candidates for a small student offline.

Fine-tuning the embedder is more powerful for recall but forces you to re-embed the whole corpus and keep the old index for rollback (Part 3, blue-green indexing). Fine-tuning the generator changes behaviour broadly and carries the most risk of side effects.

### 1.3 Prerequisites before any training

1. A **held-out evaluation set** that the training data cannot leak into (Chapter 2.5), with a baseline measured on it.
2. **Training data** of the right kind and quantity: real pairs from logs or labels, or synthetic pairs whose quality you have checked.
3. A **target**: the metric and the minimum gain that justify the cost, with paired statistics (Part 6) to tell whether you reached it.
4. **Ownership**: someone to retrain when documents, products or base models change. A fine-tuned model that is never refreshed slowly becomes worse than the next off-the-shelf release.

### 1.4 What gains to expect

Domain fine-tuning of embedders and rerankers commonly produces gains of a few points of nDCG@10 or recall on in-domain queries, sometimes much more when the domain vocabulary is far from web text (internal codes, specialised science, legal or medical terms), and sometimes nothing when the off-the-shelf model already fits. Gains measured on synthetic queries tend to overstate gains on real ones. Plan for a pilot: a small training run evaluated on a held-out set before committing to a pipeline.

## Chapter 2. Training data for retrieval

Retrieval models learn from (query, relevant passage) pairs, ideally with hard negatives. The quality of these pairs, especially whether the negatives are truly irrelevant, matters more than the training recipe. Build the data from real signals where you can, generate it synthetically where you cannot, and split it so evaluation stays honest.

### 2.1 Where pairs come from

- **Interaction logs**: queries paired with the documents users clicked, copied from or cited. Abundant once you have traffic, but noisy: clicks are biased towards top positions (users click what they see first), and a click is not proof of relevance. Stronger signals are long dwell, a cited passage that the user then copied, or a support ticket closed with that article.
- **Existing structures**: FAQ question and answer, ticket and the knowledge-base article an agent linked, title and body, a code comment and its function. Often free and clean.
- **Human labels**: expensive but the best for small, high-value domains; also needed for evaluation anyway.
- **Synthetic queries**: an LLM writes queries for passages. Research systems such as InPars (Bonifacio et al., 2022) and Promptagator (Dai et al., 2022) showed that LLM-generated queries can train strong domain retrievers; GPL (Wang et al., 2022) adds negatives mined from the corpus and soft labels from a cross-encoder.

### 2.2 Generating synthetic training queries

The recipe: sample passages across the corpus; prompt an LLM for one to three realistic queries per passage in the styles your users write (questions, keyword queries, error messages); deduplicate; then filter. A common filter for **training** data is **round-trip consistency**: keep a generated query only if a retriever ranks its source passage highly, which removes vague or wrong queries. Note the contrast with Part 6: for **evaluation** sets we avoided retriever-based filters because they bias the test towards easy questions; for training data, the bias is acceptable because the goal is clean signal, not an unbiased estimate.

### 2.3 Hard negatives

As Part 2 showed, the contrastive gradient concentrates on negatives the model finds confusing, so training needs **hard negatives**: passages similar to the query that do not answer it. Mine them by retrieving the top results for each training query with BM25 and/or the current embedder and removing the labelled positives. Practical settings:

- Sample negatives from a rank window, for example ranks 10 to 50, rather than the very top, where unlabelled positives concentrate.
- Use 1 to 7 negatives per query; more raises cost with diminishing returns.
- Mix sources (BM25 negatives look lexically similar, dense negatives look semantically similar).
- You do not have to write the miner yourself: `sentence_transformers.util.mine_hard_negatives` takes a dataset of (anchor, positive) pairs, an embedding model and optionally a cross-encoder, and implements the rank window (`range_min`, `range_max`), the number of negatives per query and the false-negative filters of 2.4 (`relative_margin`, `absolute_margin`, `max_score`). Lab 2 shows both the hand-written version (so you understand it) and the one-call version.

### 2.4 Filtering false negatives

Mined negatives are often unlabelled positives, especially in corpora with near-duplicate or overlapping documents. Filter them before training:

- **Score margin with a cross-encoder**: drop a negative whose cross-encoder score exceeds, for example, 95% of the positive's score (positive-aware mining, as in NV-Retriever).
- **Absolute threshold**: drop negatives above a calibrated relevance probability.
- **LLM verification** for small, high-value sets.
- **Guided in-batch filtering** during training: GISTEmbed (Solatorio, 2024) uses a guide model to ignore in-batch negatives that the guide considers more similar to the query than the positive; sentence-transformers implements it as GISTEmbedLoss.

### 2.5 Splits without leakage

The most common way to fool yourself in retrieval fine-tuning is leakage between training and evaluation.

- **Split by document (or topic, or time), not by query.** If two synthetic queries about the same passage land in train and test, the model memorises the passage and test scores soar without real generalisation.
- **Check near-duplicates across splits** with the MinHash tools from Part 4.
- **Never generate training queries from evaluation passages**, or remove evaluation passages from the pool used for synthetic generation.
- **Keep a real-query test set** if you train on synthetic queries; synthetic-on-synthetic results are optimistic.
- When the benchmark provides splits (as SciFact does), still check how many test-relevant documents also appear as training positives; the lab measures this.

### 2.6 Formats

Most training code accepts: pairs (anchor, positive) for in-batch-negative losses; triplets or n-tuples (anchor, positive, negative 1 … negative n) for hard-negative training; and scored pairs (query, passage, score) for distillation and regression losses. Keep the mining parameters and the source of each example with the dataset so that you can reproduce and debug it.

## Chapter 3. Fine-tuning an embedding model

Fine-tuning an embedder continues the contrastive training of Part 2 on your domain's pairs: start from a good pre-trained model, train for one to three epochs with in-batch and hard negatives at a small learning rate, evaluate retrieval on held-out queries every few hundred steps, and keep the checkpoint that wins. Then re-embed the corpus.

### 3.1 The standard recipe

With sentence-transformers (version 3 onward; version 6 at the time of writing), training uses a Hugging Face-style trainer:

1. **Model**: load a pre-trained embedder (for example bge-small, a Qwen3-Embedding size, or whatever your evaluation picked).
2. **Data**: a dataset whose columns are (anchor, positive) or (anchor, positive, negative\_1 … negative\_n), in that order.
3. **Loss**: `MultipleNegativesRankingLoss` (InfoNCE with in-batch negatives plus any hard-negative columns); wrap it in `MatryoshkaLoss` to train nested dimensions; use `CachedMultipleNegativesRankingLoss` for large effective batches on small GPUs, or `GISTEmbedLoss` to filter in-batch false negatives with a guide model.
4. **Arguments**: learning rate around 1e-5 to 5e-5 (smaller for larger models), 1 to 3 epochs, warm-up for about 10% of steps, the largest batch that fits, mixed precision, and the `NO_DUPLICATES` batch sampler.
5. **Evaluator**: `InformationRetrievalEvaluator` with held-out queries, the corpus and relevance labels, reporting nDCG@10, MRR, recall and MAP during training.
6. **Select** the best checkpoint by the evaluator's metric, then confirm on the test set with paired statistics (Part 6).

### 3.2 Batches matter

With in-batch negatives, every other passage in the batch is a negative for each query. Two consequences:

- **Bigger batches give more and harder negatives**, so they usually help (Part 2, Chapter 3.4).
- **Duplicates in a batch become false negatives**: if two training pairs share the same positive passage, one query is pushed away from its own correct answer. The `NO_DUPLICATES` batch sampler prevents identical texts from appearing twice in a batch. For corpora with many near-duplicates, deduplicate the training data as well.

### 3.3 Keep the model's conventions

If the base model expects query instructions or prefixes (Part 2, Chapter 2.5), train with them too, or the fine-tuned model and its inference code disagree. The sentence-transformers training arguments accept a `prompts` mapping from column name to prefix for exactly this purpose. Keep normalisation and pooling unchanged.

### 3.4 Matryoshka fine-tuning

`MatryoshkaLoss` applies the base loss at several truncated dimensions (for example 384, 256, 128 and 64) and sums them (Part 2, Chapter 5.1). Use it when you plan to store truncated vectors; it costs little extra training time and makes short embeddings much better than truncating a model trained without it.

### 3.5 Catastrophic forgetting

A model tuned hard on one domain can get worse on everything else, including queries in your product that the training set did not cover. Mitigations:

- Use a small learning rate and few epochs; stop when the held-out metric plateaus.
- Mix in general-purpose pairs (for example 10 to 30% of the batches) if users ask broad questions.
- Evaluate on a general benchmark subset as well as the domain set, and compare with the base model.
- **Weight interpolation**: average the fine-tuned and original weights, θ = α·θ\_fine-tuned + (1 − α)·θ\_base, and pick α on the development set. Interpolating weights in this way (as in WiSE-FT, Wortsman et al., 2022) often keeps most of the domain gain while recovering general performance.

### 3.6 Larger embedders

For billion-parameter embedders on limited GPUs, combine parameter-efficient fine-tuning (LoRA adapters, Chapter 5.3), gradient caching for large batches, gradient checkpointing and mixed precision. sentence-transformers can attach PEFT adapters to a model and train only them.

### 3.7 Deploying a fine-tuned embedder

A new embedder means a new vector space: re-embed the whole corpus into a new collection, evaluate it end to end, switch the alias, and keep the old collection for rollback (Part 3, Chapter 4.5). Record the base model, training data version, hyperparameters and evaluation results in a model card, and pin the exact checkpoint used for both queries and documents.

## Chapter 4. Training a reranker

A reranker learns a score s(q, p) for each query-passage pair. You can train it on individual pairs (pointwise), on pairs of passages (pairwise) or on whole candidate lists (listwise), from human labels or from a stronger teacher's scores. Whatever the loss, train it on the **candidates your first stage will actually give it**, because that is the distribution it must sort.

### 4.1 Pointwise: binary cross-entropy

Treat each (query, passage) pair as a binary classification with label y ∈ {0, 1} (or a soft label from a teacher):

```latex
\mathcal{L}_{\text{BCE}} = -\big[\, y \log \sigma(s) + (1 - y) \log(1 - \sigma(s)) \,\big]
```

Simple and robust; the scores come out roughly calibrated, which helps thresholds (Part 5, Chapter 4.5). Balance positives and hard negatives, for example one positive to several negatives, with a positive-class weight if needed.

### 4.2 Pairwise: RankNet and margins

Pairwise losses only care about order. RankNet (Burges et al., 2005) models the probability that the positive outranks the negative as σ(s⁺ − s⁻):

```latex
\mathcal{L}_{\text{RankNet}} = -\log \sigma\big(s(q, p^+) - s(q, p^-)\big)
```

Margin-MSE (Part 2, Chapter 3.8) is the distillation version: match the student's margin s⁺ − s⁻ to a teacher's.

### 4.3 Listwise: softmax over candidates

Score one positive and n negatives for the same query and apply softmax cross-entropy, which is InfoNCE applied to a cross-encoder:

```latex
\mathcal{L}_{\text{list}} = -\log \frac{e^{s(q, p^+)}}{e^{s(q, p^+)} + \sum_{j=1}^{n} e^{s(q, p_j^-)}}
```

With graded labels or teacher scores, **ListNet** minimises the cross-entropy between the teacher's and student's softmax distributions over the list, and **LambdaLoss** (Wang et al., 2018) weights pairwise errors by their effect on nDCG, optimising the ranking metric more directly.

### 4.4 Tooling

Since version 4, sentence-transformers provides a `CrossEncoderTrainer` with losses including `BinaryCrossEntropyLoss`, `MultipleNegativesRankingLoss` (listwise softmax with in-batch and hard negatives), `RankNetLoss`, `LambdaLoss`, `ListNetLoss`, `MarginMSELoss` and `MSELoss`, and evaluators that rerank candidate lists and report nDCG and MRR. The workflow mirrors Chapter 3: dataset, loss, arguments, evaluator, trainer.

### 4.5 Distillation from an LLM teacher

Large LLM rerankers are accurate but slow and costly (Part 5). Distil them:

1. Retrieve candidates for many training queries (real or synthetic) with your production first stage.
2. Score each (query, candidate) with the teacher, for example an LLM's P(yes) or a listwise ranking converted to scores.
3. Train a small cross-encoder to reproduce the teacher with MSE on scores, Margin-MSE on pairs, or ListNet on lists.

The student inherits much of the teacher's judgement at a fraction of the latency, and the teacher's scores double as labels for evaluation (after you validate the teacher against humans, Part 6).

### 4.6 Practical notes

- Starting from a reranker already trained on MS MARCO or similar data usually beats starting from a raw encoder.
- Keep the input format identical at training and inference: the same title-plus-chunk text, the same maximum length.
- Evaluate as you deploy: rerank the same top-n candidates and report nDCG@10 and MRR against the first stage alone, with paired statistics.
- LLM-based pointwise rerankers such as the Qwen3-Reranker family can also be fine-tuned, as instruction-following yes/no classifiers, with the generator techniques of Chapter 5.

## Chapter 5. Fine-tuning the generator for RAG

Fine-tune the generator to change **behaviour**, not to store facts: reading the provided documents carefully, ignoring distractors, citing, abstaining, and following an output format. The standard approach is supervised fine-tuning on (question, retrieved documents, ideal answer) examples, with parameter-efficient methods such as LoRA so that it fits on modest hardware.

### 5.1 What fine-tuning can teach a RAG generator

- **Grounding**: answer from the context, not from memory, even when they disagree.
- **Robustness to distractors**: find the one relevant passage among several plausible ones.
- **Citations** in your exact format, pointing to the passages actually used.
- **Abstention** when no passage answers the question, with your fixed wording.
- **Domain reading skills**: tables, clause numbering, error-code conventions, internal jargon.
- **Format and style**: length, structure, language, tone.

Facts that change (prices, policies) belong in the index, not in weights: weights go stale and cannot be cited.

### 5.2 RAFT: training with distractors

**Retrieval-Augmented Fine-Tuning** (RAFT; Zhang et al., 2024) builds each training example from a question, its "oracle" document and several **distractor** documents, mimicking imperfect retrieval. The target answer is a chain of reasoning that **quotes** the relevant passage before giving the final answer. In a fraction of examples the oracle document is left out entirely, so the model learns not to depend blindly on whatever is retrieved. The paper reported gains over plain fine-tuning and over RAG with the base model on several domain QA benchmarks.

For enterprise assistants that must be auditable, a common adaptation changes the no-oracle case: instead of answering from memory (which the original recipe allows, to build domain knowledge into the model), the target is the fixed abstention message. Choose deliberately: original RAFT for knowledge-heavy domains where memory helps; the abstention variant where every answer must be supported by a cited source.

### 5.3 LoRA and QLoRA

Full fine-tuning updates every weight and needs optimiser state for each: with mixed-precision Adam, roughly 16 bytes per parameter, about 64 GB for a 4-billion-parameter model before activations. **LoRA** (Hu et al., 2021) freezes the pre-trained weight matrix W₀ ∈ ℝ^(d×k) and learns a low-rank update:

```latex
W = W_0 + \frac{\alpha}{r}\, B A, \qquad B \in \mathbb{R}^{d \times r},\; A \in \mathbb{R}^{r \times k},\; r \ll \min(d, k)
```

B is initialised to zero, so training starts exactly from the base model. Trainable parameters per matrix drop from d·k to r(d + k): for d = k = 4,096 and r = 16, from 16.8 million to 131,072, under 1%. After training, BA can be **merged** into W₀, so inference has no extra latency; or adapters can be kept separate and swapped per task or tenant.

![LoRA: a frozen weight matrix plus a trainable low-rank update](../diagrams/p07_lora.svg)

*LoRA: a frozen weight matrix plus a trainable low-rank update*

**QLoRA** (Dettmers et al., 2023) also stores the frozen base model in 4-bit NormalFloat (NF4) quantisation, with double quantisation of the quantisation constants and paged optimisers to absorb memory spikes, while the LoRA adapters train in 16-bit. A 4-billion-parameter model's weights shrink from about 8 GB in 16-bit to about 2 GB, so fine-tuning fits on a single consumer or free-tier GPU, at some cost in speed and, sometimes, a little quality.

Typical starting hyperparameters: rank r of 8 to 64, α around 2r, dropout 0.05, adapters on all linear projections of attention and MLP layers, learning rate 1e-4 to 2e-4, 1 to 3 epochs, and loss computed **only on the answer tokens** (not on the prompt and documents).

### 5.4 Building the training data

1. Take questions from logs, experts or synthetic generation (Part 6, Chapter 2), each with its relevant passage.
2. For each, assemble a context like production would: the relevant passage plus distractors retrieved for the same question, in random order; and for some examples only distractors.
3. Write the target answers with a strong teacher model (distillation) and **verify** them: citations exist and support the claims (Part 5's checks), abstentions are correct. Review a sample by hand.
4. Hold out documents, not just questions, for evaluation (Chapter 2.5).
5. Check the teacher model's licence and terms; some providers restrict using outputs to train other models.

A few hundred to a few thousand high-quality examples often suffice to change behaviour; quality and coverage of edge cases (abstention, conflicts, distractors) matter more than volume.

### 5.5 Risks to measure

- **Forgetting** general abilities: evaluate on general tasks as well as RAG tasks.
- **Over-refusal**: too many abstention examples make the model refuse answerable questions; track the false-refusal rate (Part 6).
- **Format overfitting**: perfect citations in the training format, broken behaviour on slightly different inputs.
- **Safety regression**: fine-tuning can weaken a model's safety behaviour even with benign data (Qi et al., 2023), so re-run safety and prompt-injection tests after every fine-tune.
- **Staleness**: anything the model memorised from training documents will age; keep facts in the index.

### 5.6 Preference tuning

When you can produce pairs of better and worse answers (for example grounded versus ungrounded, correctly abstaining versus hallucinating), direct preference optimisation (DPO; Rafailov et al., 2023) trains the model to prefer the better one without a separate reward model. It is a natural second step after supervised fine-tuning for faithfulness and abstention, using the judges of Part 6 to build the pairs.

## Chapter 6. Evaluating and operating fine-tuned models

A fine-tuned model is a long-lived asset with a maintenance cost, not a one-off experiment. Ship it only if it beats the baseline on held-out data with paired statistics and without regressions elsewhere, document exactly how it was made, and schedule its re-evaluation against new off-the-shelf models.

### 6.1 The evaluation protocol

1. **Same test set, same pipeline**: compare the base and fine-tuned models on the held-out set with everything else fixed (chunking, candidates, prompt).
2. **Paired statistics**: confidence interval of the per-question difference, as in Part 6. Report per question type.
3. **Out-of-domain check**: a general benchmark subset and real queries outside the training distribution, to detect forgetting.
4. **Guardrails**: latency, memory, cost; safety and prompt-injection tests for generators; false-refusal rate.
5. **End to end**: a better retriever or reranker must also improve answers, measured with Part 6's generation metrics, before it is worth shipping.
6. **Ablations**: which data helped? Training once without synthetic data, or without hard negatives, tells you where to invest next.

### 6.2 Lineage and reproducibility

Record in a model card: base model and revision; training data versions and how they were built (prompts, teacher model, mining settings, filters); hyperparameters and random seeds; code commit; evaluation results with confidence intervals; known limitations. Store checkpoints in a model registry. Without this, nobody can retrain the model when the corpus changes, or explain a regression six months later.

### 6.3 Deployment patterns

- **Embedders**: new collection, re-embed, blue-green switch (Chapter 3.7).
- **Rerankers**: drop-in replacement behind a flag; A/B test directly.
- **Generators**: merged LoRA weights for simplicity, or separate adapters loaded on a shared base model. Serving engines such as vLLM can serve many LoRA adapters on one base model, which suits per-tenant or per-task adapters.

### 6.4 When to retrain

- The corpus or product changes enough that evaluation scores drift down.
- New query types appear in logs that the training data did not cover.
- A new base model is released: re-run your evaluation on the new off-the-shelf model, and on the new model fine-tuned with your existing data. A strong new base model sometimes beats your old fine-tuned model without any training.

Automate the pipeline (data build, training, evaluation, model card) so that retraining is routine rather than a project.

### 6.5 Cost-benefit

| Cost item | Embedder | Reranker | Generator (LoRA) |
| --- | --- | --- | --- |
| Data | Pairs and negatives; synthetic is cheap | Labelled or teacher-scored candidates | Verified answers with contexts; most expensive |
| Training compute | Minutes to hours | Minutes to hours | Hours |
| Deployment cost | Full re-embedding of the corpus | None beyond serving | Serving a custom model or adapters |
| Risk | Moderate (forgetting; index rebuild) | Low (easy rollback) | Highest (behaviour and safety side effects) |
| Typical win | Recall on domain vocabulary | Top-k precision | Grounding, citations, abstention, format |

The decision rule: estimate the business value of the measured gain (fewer escalations, fewer wrong answers, lower serving cost) and compare it with the total cost of data, compute, deployment and ongoing retraining. Stop when the next increment of quality is worth less than its maintenance.

## Chapter 7. Hands-on lab

You will fine-tune bge-small on SciFact's training queries with mined, filtered hard negatives; train a cross-encoder reranker on your own first stage's candidates; and LoRA-tune a small generator RAFT-style on the Nimbus corpus. Each step is measured against its baseline on held-out data with the paired statistics of Part 6.

### Lab 0. Data with real train and test splits

```python
import numpy as np, pandas as pd, random, re, json, torch
from huggingface_hub import hf_hub_download
from datasets import Dataset
from sentence_transformers import SentenceTransformer, CrossEncoder
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
random.seed(0); np.random.seed(0)

def load_scifact_splits():
    get = lambda f: hf_hub_download("mteb/scifact", f, repo_type="dataset")
    corpus = pd.read_json(get("corpus.jsonl"), lines=True, dtype={"_id": str})
    queries = pd.read_json(get("queries.jsonl"), lines=True, dtype={"_id": str})
    def qrels(split):
        q = pd.read_csv(get(f"qrels/{split}.tsv"), sep="\t", dtype={"query-id": str, "corpus-id": str})
        return q[q["score"] > 0].groupby("query-id")["corpus-id"].apply(set).to_dict()
    return corpus, queries, qrels("train"), qrels("test")

corpus, queries, rel_train, rel_test = load_scifact_splits()
doc_ids = corpus["_id"].tolist()
doc_texts = (corpus["title"].fillna("") + "\n" + corpus["text"].fillna("")).tolist()
id2text = dict(zip(doc_ids, doc_texts))
qtext = dict(zip(queries["_id"], queries["text"]))
train_q = [q for q in rel_train if q in qtext]
test_q = [q for q in rel_test if q in qtext]
print(len(train_q), "train queries,", len(test_q), "test queries,", len(doc_ids), "documents")

# Leakage check: how many test-relevant documents are also training positives?
train_pos = set().union(*rel_train.values())
shared = sum(any(d in train_pos for d in rel_test[q]) for q in test_q)
print(f"test queries whose relevant document is also a training positive: {shared}/{len(test_q)}")
```

If the qrels file names in the dataset repository have changed, list its files on the Hugging Face page and adjust. The leakage line matters: if many test queries share relevant documents with training queries, part of any gain could come from memorising those documents rather than from better generalisation. Report the gain separately on the two groups (Exercise 7).

### Lab 1. Baseline with per-query scores

```python
PREFIX = "Represent this sentence for searching relevant passages: "
BASE = "BAAI/bge-small-en-v1.5"

def per_query_ndcg(model, qids, rel, k=10):
    E = model.encode(doc_texts, normalize_embeddings=True, batch_size=64, convert_to_numpy=True)
    Q = model.encode([qtext[q] for q in qids], prompt=PREFIX, normalize_embeddings=True, convert_to_numpy=True)
    S = Q @ E.T
    out = []
    for i, q in enumerate(qids):
        top = np.argsort(-S[i])[:k]
        gains = [1.0 if doc_ids[j] in rel[q] else 0.0 for j in top]
        dcg = sum(g / np.log2(r + 2) for r, g in enumerate(gains))
        idcg = sum(1.0 / np.log2(r + 2) for r in range(min(len(rel[q]), k)))
        out.append(dcg / idcg)
    return np.array(out), S

def bootstrap_ci(x, B=10_000, seed=0):
    x = np.asarray(x, float); rng = np.random.default_rng(seed)
    m = x[rng.integers(0, len(x), size=(B, len(x)))].mean(axis=1)
    return x.mean(), np.quantile(m, 0.025), np.quantile(m, 0.975)

base_model = SentenceTransformer(BASE, device=DEVICE)
ndcg_base, S_base = per_query_ndcg(base_model, test_q, rel_test)
print("base nDCG@10: %.3f [%.3f, %.3f]" % bootstrap_ci(ndcg_base))
```

### Lab 2. Mine hard negatives and filter false negatives

Use the base model to retrieve candidates for each training query, sample negatives from ranks 10 to 50, and drop any the cross-encoder thinks are nearly as relevant as the positive.

```python
E_base = base_model.encode(doc_texts, normalize_embeddings=True, batch_size=64, convert_to_numpy=True)
Q_train = base_model.encode([qtext[q] for q in train_q], prompt=PREFIX, normalize_embeddings=True, convert_to_numpy=True)
S_train = Q_train @ E_base.T
judge = CrossEncoder("BAAI/bge-reranker-v2-m3", device=DEVICE, max_length=512)

rows, dropped = {"anchor": [], "positive": [], "negative": []}, 0
for i, q in enumerate(train_q):
    ranked = [doc_ids[j] for j in np.argsort(-S_train[i])[:60] if doc_ids[j] not in rel_train[q]]
    window = ranked[10:50]
    for pos in rel_train[q]:
        cand = random.sample(window, min(5, len(window)))
        scores = judge.predict([(qtext[q], id2text[pos])] + [(qtext[q], id2text[c]) for c in cand])
        pos_score, neg_scores = scores[0], scores[1:]
        keep = [c for c, s in zip(cand, neg_scores) if s < 0.95 * pos_score]   # positive-aware filter
        dropped += len(cand) - len(keep)
        if keep:
            rows["anchor"].append(qtext[q]); rows["positive"].append(id2text[pos]); rows["negative"].append(id2text[keep[0]])
train_ds = Dataset.from_dict(rows)
print(len(train_ds), "training triplets;", dropped, "candidate negatives dropped as possible false negatives")
del judge; torch.cuda.empty_cache()
```

Inspect a few dropped negatives: some will be genuinely relevant abstracts that the labels missed. That is the false-negative problem of Chapter 2.4 made visible.

The same mining in one call with the library utility (`relative_margin=0.05` drops negatives scoring above 95% of the positive, as above; `range_min` skips the top ranks where unlabelled positives concentrate):

```python
from sentence_transformers.util import mine_hard_negatives
pairs = Dataset.from_dict({"anchor": [qtext[q] for q in train_q for _ in rel_train[q]],
                           "positive": [id2text[d] for q in train_q for d in rel_train[q]]})
mined = mine_hard_negatives(pairs, base_model, corpus=doc_texts, cross_encoder=CrossEncoder("BAAI/bge-reranker-v2-m3", device=DEVICE),
                            range_min=10, range_max=50, num_negatives=1, relative_margin=0.05,
                            sampling_strategy="random", output_format="triplet", batch_size=64)
print(mined)   # columns: anchor, positive, negative
```

Check two things in your version's documentation before trusting the output: how anchors with several labelled positives are handled (pass one row per positive, as above, and confirm that the other positives of the same anchor are not sampled as negatives), and whether the query prompt is applied (pass `query_prompt_name` or `query_prompt` for models that need a prefix, otherwise the mined ranks come from an untypical query embedding).

### Lab 3. Fine-tune the embedder

```python
from sentence_transformers import SentenceTransformerTrainer, SentenceTransformerTrainingArguments, losses
from sentence_transformers.training_args import BatchSamplers
from sentence_transformers.evaluation import InformationRetrievalEvaluator

# Validation: hold out 15% of the TRAINING queries for checkpoint selection; keep the test set untouched.
val_q = set(random.sample(train_q, int(0.15 * len(train_q))))
val_texts = {qtext[q] for q in val_q}
train_ds = train_ds.filter(lambda r: r["anchor"] not in val_texts)
val_eval = InformationRetrievalEvaluator(
    queries={q: qtext[q] for q in val_q}, corpus=dict(zip(doc_ids, doc_texts)),
    relevant_docs={q: rel_train[q] for q in val_q}, name="val", query_prompt=PREFIX, show_progress_bar=False)

model = SentenceTransformer(BASE, device=DEVICE)
loss = losses.MultipleNegativesRankingLoss(model)             # in-batch + the mined hard negative
args = SentenceTransformerTrainingArguments(
    output_dir="bge-small-scifact", num_train_epochs=3, per_device_train_batch_size=32,
    learning_rate=3e-5, warmup_steps=0.1, fp16=(DEVICE == "cuda"),   # warmup_steps below 1 is a ratio of total steps
    batch_sampler=BatchSamplers.NO_DUPLICATES,                # no duplicate texts within a batch
    prompts={"anchor": PREFIX},                                # keep the model's query prefix
    eval_strategy="steps", eval_steps=20, save_strategy="steps", save_steps=20,
    load_best_model_at_end=True, metric_for_best_model="eval_val_cosine_ndcg@10",
    save_total_limit=2, logging_steps=20, report_to="none", seed=0)
trainer = SentenceTransformerTrainer(model=model, args=args, train_dataset=train_ds, loss=loss, evaluator=val_eval)
trainer.train()

ndcg_ft, S_ft = per_query_ndcg(model, test_q, rel_test)
print("fine-tuned nDCG@10: %.3f [%.3f, %.3f]" % bootstrap_ci(ndcg_ft))
print("paired difference:   %+.3f [%+.3f, %+.3f]" % bootstrap_ci(ndcg_ft - ndcg_base))
```

The metric name passed to `metric_for_best_model` is "eval\_" plus the evaluator's key, which combines its name and the similarity function; print `val_eval(model)` once to see the exact keys in your version. Expect a gain that is clearly larger than the paired interval's width if fine-tuning helps on this domain; whatever you get, the paired interval is the honest summary.

### Lab 4. Train a reranker on your own candidates

```python
from sentence_transformers.cross_encoder import CrossEncoderTrainer, CrossEncoderTrainingArguments
from sentence_transformers.cross_encoder.losses import BinaryCrossEntropyLoss

RERANK_BASE = "cross-encoder/ms-marco-MiniLM-L6-v2"
E_ft = model.encode(doc_texts, normalize_embeddings=True, batch_size=64, convert_to_numpy=True)

def candidates(qids, k):
    Q = model.encode([qtext[q] for q in qids], prompt=PREFIX, normalize_embeddings=True, convert_to_numpy=True)
    return {q: [doc_ids[j] for j in np.argsort(-(Q[i] @ E_ft.T))[:k]] for i, q in enumerate(qids)}

train_cands = candidates([q for q in train_q if q not in val_q], 20)
ce_rows = {"query": [], "passage": [], "label": []}
for q, cands in train_cands.items():
    for d in rel_train[q]:                                      # all positives
        ce_rows["query"].append(qtext[q]); ce_rows["passage"].append(id2text[d]); ce_rows["label"].append(1.0)
    for d in [c for c in cands if c not in rel_train[q]][:7]:   # hard negatives from OUR first stage
        ce_rows["query"].append(qtext[q]); ce_rows["passage"].append(id2text[d]); ce_rows["label"].append(0.0)
ce_ds = Dataset.from_dict(ce_rows).shuffle(seed=0)

def rerank_ndcg(ce, qids, rel, n_cand=50, k=10):
    cands = candidates(qids, n_cand)
    out = []
    for q in qids:
        scores = ce.predict([(qtext[q], id2text[d]) for d in cands[q]], batch_size=64)
        top = [cands[q][j] for j in np.argsort(-scores)[:k]]
        gains = [1.0 if d in rel[q] else 0.0 for d in top]
        dcg = sum(g / np.log2(r + 2) for r, g in enumerate(gains))
        out.append(dcg / sum(1.0 / np.log2(r + 2) for r in range(min(len(rel[q]), k))))
    return np.array(out)

ce = CrossEncoder(RERANK_BASE, device=DEVICE, max_length=512)
ndcg_ce_base = rerank_ndcg(ce, test_q, rel_test)
ce_args = CrossEncoderTrainingArguments(
    output_dir="minilm-scifact", num_train_epochs=1, per_device_train_batch_size=32,
    learning_rate=2e-5, warmup_steps=0.1, fp16=(DEVICE == "cuda"),
    save_strategy="no", logging_steps=50, report_to="none", seed=0)
CrossEncoderTrainer(model=ce, args=ce_args, train_dataset=ce_ds, loss=BinaryCrossEntropyLoss(ce)).train()
ndcg_ce_ft = rerank_ndcg(ce, test_q, rel_test)

for name, x in [("fine-tuned embedder only", ndcg_ft), ("+ off-the-shelf reranker", ndcg_ce_base),
                ("+ fine-tuned reranker", ndcg_ce_ft)]:
    print(f"{name:<26} %.3f [%.3f, %.3f]" % bootstrap_ci(x))
print("reranker gain (paired):    %+.3f [%+.3f, %+.3f]" % bootstrap_ci(ndcg_ce_ft - ndcg_ce_base))
```

The reranker was trained on candidates from the same fine-tuned embedder it will rerank in production, as Chapter 4 recommends. Unlabelled relevant abstracts among the "negatives" are a source of noise; Exercise 9 adds the cross-encoder false-negative filter to this data.

### Lab 5. RAFT-style LoRA fine-tuning of a small generator

This lab teaches a 0.5B-parameter instruct model to answer from the right source among distractors, cite it, and abstain when no source answers. The Nimbus corpus comes from `ragkit`. Step 1 generates question-answer pairs with the 4B teacher; step 2 builds RAFT examples; step 3 trains the student with LoRA; step 4 compares base and tuned student on held-out documents.

```python
from ragkit import CORPUS, split_sentences, chunk_document
from transformers import AutoTokenizer, AutoModelForCausalLM
chunks = [c for d in CORPUS for c in chunk_document(d)]
TEACHER = "Qwen/Qwen3-4B-Instruct-2507"
t_tok = AutoTokenizer.from_pretrained(TEACHER)
teacher = AutoModelForCausalLM.from_pretrained(TEACHER, dtype=torch.float16, device_map="auto")

def teacher_chat(prompt, max_new_tokens=400):
    inp = t_tok.apply_chat_template([{"role": "user", "content": prompt}], add_generation_prompt=True,
                                    return_dict=True, return_tensors="pt").to(teacher.device)
    with torch.no_grad():
        out = teacher.generate(**inp, max_new_tokens=max_new_tokens, do_sample=False)
    return t_tok.decode(out[0, inp["input_ids"].shape[1]:], skip_special_tokens=True)

QA_PROMPT = ("Passage:\n{text}\n\nWrite 3 different questions an employee might ask that this passage answers, "
             "each with a one-sentence answer using only the passage. Return a JSON list of objects with keys "
             "'question' and 'answer'.")
qa = []
for c in chunks:
    m = re.search(r"\[.*\]", teacher_chat(QA_PROMPT.format(text=c["text"])), flags=re.S)
    try:
        for item in json.loads(m.group(0)) if m else []:
            if item.get("question") and item.get("answer"):
                qa.append({**item, "chunk_id": c["chunk_id"], "doc_id": c["doc_id"]})
    except json.JSONDecodeError:
        pass
print(len(qa), "question-answer pairs")
del teacher; torch.cuda.empty_cache()
```

Review a sample of `qa` by hand before training, as in Part 6. Now build RAFT examples: the oracle chunk plus two distractors in random positions, or, in 25% of examples, three distractors and an abstention target. Hold out two whole documents for testing.

```python
emb = SentenceTransformer(BASE, device=DEVICE)
E_c = emb.encode([c["text"] for c in chunks], normalize_embeddings=True, convert_to_numpy=True)
by_id = {c["chunk_id"]: i for i, c in enumerate(chunks)}
REFUSAL = "I don't know based on the provided documents."
SYSTEM = ("Answer using only the sources. Cite the source id like [S2] after the answer. "
          f"If no source answers the question, reply exactly: {REFUSAL}")
HELD_OUT = {"eng-oncall", "company-about"}

def raft_example(item, p_no_oracle=0.25):
    q_vec = emb.encode([item["question"]], prompt=PREFIX, normalize_embeddings=True, convert_to_numpy=True)[0]
    oracle = by_id[item["chunk_id"]]
    others = [j for j in np.argsort(-(E_c @ q_vec)) if chunks[j]["doc_id"] != item["doc_id"]]   # similar, but wrong
    with_oracle = random.random() > p_no_oracle
    picked = ([oracle] + others[:2]) if with_oracle else others[:3]
    random.shuffle(picked)
    ctx = "\n".join(f"[S{n}] {chunks[j]['text']}" for n, j in enumerate(picked, 1))
    target = f"{item['answer']} [S{picked.index(oracle) + 1}]" if with_oracle else REFUSAL
    return {"prompt": [{"role": "system", "content": SYSTEM},
                       {"role": "user", "content": f"{ctx}\n\nQuestion: {item['question']}"}],
            "completion": [{"role": "assistant", "content": target}],
            "has_oracle": with_oracle, "doc_id": item["doc_id"]}

examples = [raft_example(x) for x in qa]
train_ex = [e for e in examples if e["doc_id"] not in HELD_OUT]
test_ex = [e for e in examples if e["doc_id"] in HELD_OUT]
print(len(train_ex), "train examples;", len(test_ex), "held-out examples")
```

Train the student with LoRA. With prompt-completion data, TRL computes the loss only on the completion (the answer), as Chapter 5.3 recommends.

```python
from peft import LoraConfig
from trl import SFTConfig, SFTTrainer
STUDENT = "Qwen/Qwen2.5-0.5B-Instruct"
s_tok = AutoTokenizer.from_pretrained(STUDENT)
student = AutoModelForCausalLM.from_pretrained(STUDENT, dtype=torch.float32).to(DEVICE)

def student_answer(m, ex, max_new_tokens=80):
    inp = s_tok.apply_chat_template(ex["prompt"], add_generation_prompt=True,
                                    return_dict=True, return_tensors="pt").to(m.device)
    with torch.no_grad():
        out = m.generate(**inp, max_new_tokens=max_new_tokens, do_sample=False)
    return s_tok.decode(out[0, inp["input_ids"].shape[1]:], skip_special_tokens=True).strip()

def score(m, exs):
    abst, cite, n_o, n_no = 0, 0, 0, 0
    for ex in exs:
        ans = student_answer(m, ex)
        gold = ex["completion"][0]["content"]
        if ex["has_oracle"]:
            n_o += 1
            cite += re.search(r"\[S\d\]", gold).group(0) in ans        # cites the oracle's id
        else:
            n_no += 1
            abst += REFUSAL.lower()[:20] in ans.lower()                # abstains when it should
    return {"cites_correct_source": round(cite / max(n_o, 1), 2), "abstains_correctly": round(abst / max(n_no, 1), 2)}

print("base student:", score(student, test_ex))

cfg = SFTConfig(output_dir="qwen05-raft", num_train_epochs=3, per_device_train_batch_size=4,
                gradient_accumulation_steps=2, learning_rate=2e-4, warmup_steps=0.1, lr_scheduler_type="cosine",
                logging_steps=10, save_strategy="no", max_length=1024, fp16=(DEVICE == "cuda"),
                report_to="none", seed=0)
lora = LoraConfig(r=16, lora_alpha=32, lora_dropout=0.05, target_modules="all-linear", task_type="CAUSAL_LM")
train_rows = Dataset.from_list([{"prompt": e["prompt"], "completion": e["completion"]} for e in train_ex])
trainer = SFTTrainer(model=student, args=cfg, train_dataset=train_rows, peft_config=lora, processing_class=s_tok)
trainer.train()
tuned = trainer.model.merge_and_unload()                          # fold LoRA into the weights
print("tuned student:", score(tuned, test_ex))
```

What to look for: the base 0.5B model often answers without citing, cites the wrong source, or answers anyway when no source fits; after a few minutes of LoRA training it should cite the right source and abstain far more reliably on documents it never saw during training, because it learned a behaviour, not the facts. With only a few dozen held-out examples the numbers are noisy, so treat this as a working pipeline to scale up, not as a result. Also test a few answerable questions without an oracle in the training mix to check for over-refusal.

## Interview questions with model answers

These 22 questions cover deciding, data, embedder, reranker and generator training, and operations. ML-track interviews go deep here; application-track interviews usually ask Q1 to Q4 and Q18 to Q22.

### Deciding

**Q1. When would you fine-tune a component of a RAG system, and which one first?** Only when evaluation pins the failure on that component, cheaper fixes have been tried, and I have data and an owner. Usually the reranker first (no re-indexing, easy rollback, small data goes far), then the embedder for recall problems on domain vocabulary, and the generator only for behaviour problems such as grounding, citations, abstention or format.

**Q2. A product manager says "let's fine-tune the LLM on our documents so it knows them". Your response?** Facts belong in the index: they change, need citations and permissions, and weights cannot be updated or audited easily. Fine-tuning helps behaviour, not knowledge storage. I would check whether failures are retrieval or reading problems first, and fine-tune the generator only for reading and answering behaviours, with RAG kept in place.

**Q3. What do you need before starting any fine-tuning project?** A leakage-free held-out evaluation set with a baseline; training data of known quality; a target gain with a paired statistical test; guardrail metrics; and a plan and owner for retraining.

**Q4. Why can a fine-tuned model end up worse than an off-the-shelf one six months later?** The corpus, products and queries drift while the fine-tuned model stays frozen, and new base models improve; without scheduled re-evaluation and retraining, the custom model falls behind.

### Data

**Q5. How do you get training pairs for a domain retriever with no labelled data?** Use existing structures (FAQ pairs, ticket-to-article links), interaction logs once available, and synthetic queries generated by an LLM from passages (InPars, Promptagator, GPL style), filtered for quality, for example by round-trip consistency, with a hand-reviewed sample.

**Q6. Why is round-trip filtering acceptable for training data but not for evaluation data?** For training we want clean signal and accept bias towards answerable, retrievable queries; for evaluation we need an unbiased estimate, and filtering with the current retriever would remove exactly the hard queries we need to measure.

**Q7. How do you mine hard negatives, and what can go wrong?** Retrieve top candidates for each training query with BM25 and/or the current embedder, drop labelled positives, and sample from a rank window such as 10 to 50. The risk is false negatives: unlabelled relevant passages that teach the model to push away correct answers. Filter with a cross-encoder margin (for example drop negatives scoring above 95% of the positive), an LLM check, or guided in-batch filtering such as GISTEmbed.

**Q8. How do you split data to avoid leakage in retrieval fine-tuning?** By document, topic or time, not by query; check near-duplicates across splits; never generate training queries from test passages; and keep a real-query test set if training data is synthetic.

### Embedders

**Q9. Describe how you would fine-tune an embedding model.** Start from a strong pre-trained embedder; build (anchor, positive, hard negatives) data; train with InfoNCE (MultipleNegativesRankingLoss) with a no-duplicates batch sampler, learning rate around 2e-5, 1 to 3 epochs, warm-up, mixed precision, the model's original query prompts; evaluate nDCG@10 on held-out queries during training; pick the best checkpoint; confirm with paired statistics; re-embed the corpus and deploy blue-green.

**Q10. Why does the batch sampler matter for in-batch negative losses?** Every other passage in a batch is a negative. Larger batches give more negatives; duplicate passages in a batch become false negatives that push a query away from its own answer, so a no-duplicates sampler and deduplicated data matter.

**Q11. How do you limit catastrophic forgetting when fine-tuning an embedder?** Small learning rate and few epochs with early stopping; mix in general-domain pairs; evaluate on general queries as well; and interpolate fine-tuned and base weights, choosing the mixing weight on a development set.

**Q12. What does MatryoshkaLoss do?** It applies the base loss to several truncated prefixes of the embedding and sums them, so short prefixes remain good embeddings and you can store truncated vectors cheaply.

### Rerankers

**Q13. Compare pointwise, pairwise and listwise losses for rerankers.** Pointwise (binary cross-entropy) learns calibrated relevance per pair, good for thresholds. Pairwise (RankNet, Margin-MSE) learns orderings between positive and negative. Listwise (softmax over one positive and many negatives, ListNet, LambdaLoss) optimises the ranking of the whole candidate list and often aligns best with nDCG.

**Q14. How would you distil an LLM reranker into a small cross-encoder?** Retrieve candidates with the production first stage for many queries, score them with the LLM teacher (P(yes) or listwise ranks), validate the teacher on human labels, and train the student with MSE, Margin-MSE or ListNet on the teacher's scores; evaluate on held-out queries against both the teacher and the old reranker.

**Q15. Why train a reranker on your own first stage's candidates?** Because that is the distribution it must sort at inference; training on random or differently retrieved negatives teaches it easier distinctions than it will face.

### Generators

**Q16. Explain RAFT.** Retrieval-augmented fine-tuning: training examples contain a question, the oracle document and distractor documents (and sometimes only distractors), with target answers that quote the relevant passage before answering. It teaches the model to find and use relevant evidence among distractors. For auditable systems, the no-oracle examples can target abstention instead of answering from memory.

**Q17. Explain LoRA and compute its savings.** Freeze W₀ and learn ΔW = (α/r)BA with B ∈ ℝ^(d×r), A ∈ ℝ^(r×k), B initialised to zero. Trainable parameters fall from dk to r(d + k): for 4,096 × 4,096 and r = 16, from 16.8 million to 131 thousand (0.8%). Adapters can be merged after training, so inference cost is unchanged.

**Q18. What does QLoRA add?** The frozen base model is stored in 4-bit NormalFloat with double quantisation and paged optimisers, while LoRA adapters train in 16-bit, cutting base-weight memory about fourfold relative to 16-bit and making single-GPU fine-tuning of larger models possible.

**Q19. What are the risks of fine-tuning the generator, and how do you check for them?** Forgetting general skills, over-refusal, format overfitting, citation hallucination in the trained format, and safety regressions even with benign data. Evaluate general tasks, false-refusal rate, citation validity, and re-run safety and prompt-injection tests after every fine-tune.

### Operations

**Q20. How do you deploy a fine-tuned embedder safely?** Re-embed into a new collection, evaluate end to end, switch an alias, keep the old collection for rollback, and pin the same checkpoint for queries and documents.

**Q21. What goes in a model card for a fine-tuned RAG component?** Base model and revision, data versions and construction details, hyperparameters, seeds, code commit, evaluation results with confidence intervals and per-type breakdowns, out-of-domain and safety results, and known limitations.

**Q22. Your fine-tuned reranker gained 3 points nDCG@10 offline. What else must be true before you ship it?** The gain is significant in a paired test on held-out queries; it holds per important query type; end-to-end answer quality improves or at least does not regress; latency and cost stay within budget; and an online test or shadow run confirms no surprises.

## Exercises with solutions

Twelve exercises: one decision, four mathematical, four coding, two debugging and one design. Coding exercises reuse the Chapter 7 lab.

### Exercise 1. What would you train?

On your evaluation set: first-stage recall@50 = 0.95, nDCG@10 = 0.55, faithfulness = 0.92, 15% of answers have a citation pointing to the wrong source, and 20% of unanswerable questions get an answer instead of an abstention. Prompting has been iterated. What do you train, in which order, and what do you not train?

**Solution.** Recall@50 is high, so the embedder is not the bottleneck: do not fine-tune it. nDCG@10 is low relative to recall@50, so ranking is weak: first try an off-the-shelf reranker; if still weak, fine-tune or distil one on your candidates (cheap, reversible). Citation and abstention errors are generator behaviour problems that prompting did not fix: RAFT-style LoRA fine-tuning with distractors, correct citation targets and no-oracle abstention examples, then measure the false-refusal rate to make sure abstention does not overshoot.

### Exercise 2. LoRA parameter and memory budget

A decoder has 32 layers with hidden size 3,072 and MLP size 8,192. Each layer has four attention projections of 3,072 × 3,072 and three MLP projections (two of 3,072 × 8,192 and one of 8,192 × 3,072). You add rank-16 LoRA adapters to all seven. How many trainable parameters, what fraction of those matrices' parameters, and roughly how much memory do the adapters need for training with Adam at 16 bytes per parameter?

**Solution.** Per attention projection: r(d + k) = 16 × 6,144 = 98,304; four of them: 393,216. Per MLP projection: 16 × (3,072 + 8,192) = 180,224; three: 540,672. Per layer: 933,888; × 32 layers ≈ 29.9 million trainable parameters. The adapted matrices hold (4 × 3,072² + 3 × 3,072 × 8,192) × 32 ≈ 3.62 billion parameters, so LoRA trains about 0.83% of them. Adapter training state: 29.9 million × 16 bytes ≈ 0.48 GB, on top of the frozen base weights and activations.

### Exercise 3. How many negatives does each query see?

You train with MultipleNegativesRankingLoss, batch size 32, and one hard negative per row. How many negatives does each query's softmax contain, and how does that change at batch size 128?

**Solution.** The candidate passages are all positives and all hard negatives in the batch: 32 + 32 = 64, of which one is the query's positive, so 63 negatives (31 other positives, 32 hard negatives, including its own). At batch size 128: 255 negatives. This is why larger batches (or gradient caching) help contrastive training, and why duplicate passages in a batch hurt.

### Exercise 4. Leakage from splitting by query

You generated three synthetic queries per passage and split queries randomly, 80% train and 20% test. For a test query, what is the probability that at least one other query about the same passage is in the training set? What should you do instead?

**Solution.** Each of the other two queries is in training with probability 0.8, so the probability that neither is equals 0.2² = 0.04, and at least one is in training with probability 0.96. Almost every test query's passage has been seen in training, so test scores measure memorisation. Split by passage or document (all queries for a passage go to the same side), and check near-duplicate passages across the split.

### Exercise 5. Choosing an interpolation weight

You interpolate fine-tuned and base embedder weights, θ = α·θ\_ft + (1 − α)·θ\_base, and measure on development sets:

| α | Domain nDCG@10 | General nDCG@10 |
| --- | --- | --- |
| 0.0 (base) | 0.62 | 0.55 |
| 0.5 | 0.68 | 0.54 |
| 0.8 | 0.70 | 0.51 |
| 1.0 (fine-tuned) | 0.71 | 0.46 |

Which α would you choose if general queries are 30% of traffic?

**Solution.** Weight the two scores by traffic share: α = 0 gives 0.7 × 0.62 + 0.3 × 0.55 = 0.599; α = 0.5 gives 0.7 × 0.68 + 0.3 × 0.54 = 0.638; α = 0.8 gives 0.643; α = 1.0 gives 0.635. α = 0.8 is best by a small margin over 0.5, and both beat the fully fine-tuned model; confirm the choice on the test sets with paired statistics. Interpolation recovered most of the general performance lost to fine-tuning while keeping most of the domain gain.

### Exercise 6 (coding). Separate memorisation from generalisation

Using Lab 0's leakage check, split the test queries into those whose relevant documents were training positives and those whose were not, and report the paired gain of the fine-tuned embedder on each group.

**Solution.**

```python
seen = np.array([any(d in train_pos for d in rel_test[q]) for q in test_q])
for name, mask in [("relevant doc seen in training", seen), ("relevant doc unseen", ~seen)]:
    if mask.sum():
        print(f"{name:<30} n={mask.sum():<4}", "gain %+.3f [%+.3f, %+.3f]" % bootstrap_ci(ndcg_ft[mask] - ndcg_base[mask]))
```

If most of the gain sits in the "seen" group, the model learned those specific documents rather than the domain, and production gains on new documents will be smaller. A real gain on the "unseen" group is the result that generalises.

### Exercise 7 (coding). Matryoshka fine-tuning

Retrain Lab 3 with `MatryoshkaLoss` at dimensions \[384, 256, 128, 64\], and compare nDCG@10 at each truncation with the base model truncated the same way.

**Solution.**

```python
def ndcg_at_dim(m, dim, qids=test_q, rel=rel_test, k=10):
    E = m.encode(doc_texts, normalize_embeddings=True, batch_size=64, convert_to_numpy=True)[:, :dim]
    Q = m.encode([qtext[q] for q in qids], prompt=PREFIX, normalize_embeddings=True, convert_to_numpy=True)[:, :dim]
    E /= np.linalg.norm(E, axis=1, keepdims=True); Q /= np.linalg.norm(Q, axis=1, keepdims=True)   # re-normalise
    S = Q @ E.T
    vals = []
    for i, q in enumerate(qids):
        top = np.argsort(-S[i])[:k]
        gains = [1.0 if doc_ids[j] in rel[q] else 0.0 for j in top]
        vals.append(sum(g / np.log2(r + 2) for r, g in enumerate(gains)) /
                    sum(1.0 / np.log2(r + 2) for r in range(min(len(rel[q]), k))))
    return np.mean(vals)

mat_model = SentenceTransformer(BASE, device=DEVICE)
mat_loss = losses.MatryoshkaLoss(mat_model, losses.MultipleNegativesRankingLoss(mat_model),
                                 matryoshka_dims=[384, 256, 128, 64])
mat_args = SentenceTransformerTrainingArguments(          # same settings as Lab 3, new output directory
    output_dir="bge-small-scifact-mrl", num_train_epochs=3, per_device_train_batch_size=32,
    learning_rate=3e-5, warmup_steps=0.1, fp16=(DEVICE == "cuda"),
    batch_sampler=BatchSamplers.NO_DUPLICATES, prompts={"anchor": PREFIX},
    eval_strategy="steps", eval_steps=20, save_strategy="steps", save_steps=20,
    load_best_model_at_end=True, metric_for_best_model="eval_val_cosine_ndcg@10",
    save_total_limit=2, logging_steps=20, report_to="none", seed=0)
SentenceTransformerTrainer(model=mat_model, args=mat_args, train_dataset=train_ds, loss=mat_loss,
                           evaluator=val_eval).train()
for dim in [384, 256, 128, 64]:
    print(dim, "base %.3f" % ndcg_at_dim(base_model, dim), "| MRL fine-tuned %.3f" % ndcg_at_dim(mat_model, dim))
```

Expect the Matryoshka-trained model to lose much less quality at 128 and 64 dimensions than the base model, which was not trained for truncation (Part 2, Chapter 5).

### Exercise 8 (coding). Filter false negatives in reranker data

Lab 4 labels every non-positive candidate as a negative. Add the positive-aware filter from Lab 2 (using bge-reranker-v2-m3 as judge) and compare the resulting reranker's test nDCG@10 with Lab 4's.

**Solution.** Replace the negative loop in Lab 4 with a filtered version, then retrain from `RERANK_BASE` and evaluate with `rerank_ndcg`:

```python
judge = CrossEncoder("BAAI/bge-reranker-v2-m3", device=DEVICE, max_length=512)
ce_rows = {"query": [], "passage": [], "label": []}
for q, cands in train_cands.items():
    pos_scores = judge.predict([(qtext[q], id2text[d]) for d in rel_train[q]])
    best_pos = float(np.max(pos_scores))
    for d in rel_train[q]:
        ce_rows["query"].append(qtext[q]); ce_rows["passage"].append(id2text[d]); ce_rows["label"].append(1.0)
    negs = [c for c in cands if c not in rel_train[q]][:10]
    neg_scores = judge.predict([(qtext[q], id2text[d]) for d in negs])
    for d, s in list(zip(negs, neg_scores)):
        if s < 0.95 * best_pos:                                       # keep only confident negatives
            ce_rows["query"].append(qtext[q]); ce_rows["passage"].append(id2text[d]); ce_rows["label"].append(0.0)
del judge; torch.cuda.empty_cache()
```

Compare the two rerankers with a paired bootstrap on their per-query nDCG. On a corpus with few unlabelled positives the difference may be small; on corpora with many near-duplicates (support articles, policies with versions) false-negative filtering often matters more.

### Exercise 9 (coding). Weight interpolation for an embedder

Implement θ = α·θ\_ft + (1 − α)·θ\_base for the Lab 3 model and evaluate test nDCG@10 for α in {0, 0.25, 0.5, 0.75, 1}.

**Solution.**

```python
import copy
base_sd = SentenceTransformer(BASE, device=DEVICE).state_dict()
ft_sd = model.state_dict()
for alpha in [0.0, 0.25, 0.5, 0.75, 1.0]:
    mixed = copy.deepcopy(model)
    mixed.load_state_dict({k: alpha * ft_sd[k] + (1 - alpha) * base_sd[k] if ft_sd[k].is_floating_point() else ft_sd[k]
                           for k in ft_sd})
    print(alpha, "nDCG@10 %.3f" % per_query_ndcg(mixed, test_q, rel_test)[0].mean())
```

In practice choose α on development data (domain and general sets, as in Exercise 5), not on the test set; here the loop shows the shape of the trade-off.

### Exercise 10 (debugging). Great validation, flat test

During embedder fine-tuning, validation nDCG@10 climbs from 0.70 to 0.95, but test nDCG@10 moves from 0.70 to 0.71 and production feedback does not change. What happened?

**Solution.** Most likely leakage between training and validation: the validation queries were split by query from synthetic data, so their passages were seen in training (Exercise 4), and validation measured memorisation. Other contributors: synthetic validation queries that copy passage wording; training for too many epochs on a small set; and test or production queries with a different style from the synthetic training queries. Fix the split (by document), add real queries to validation, and stop training earlier.

### Exercise 11 (debugging). The assistant refuses too much after RAFT

After RAFT-style fine-tuning, correct abstentions on unanswerable questions rose from 60% to 97%, but false refusals on answerable questions rose from 3% to 25%. Diagnose and fix.

**Solution.** The training mix taught abstention too strongly: too many no-oracle examples, distractors so similar to the oracle that the model learned "when in doubt, refuse", or oracle passages where the answer was implicit or required combining two sentences. Fixes: lower the no-oracle share (for example from 40% to 15 to 25%); add hard answerable examples where the oracle answers indirectly; check that no-oracle examples truly lack an answer (a distractor may contain it); retrain and track both rates; and consider preference tuning with pairs that reward answering when evidence exists. Choose the final checkpoint by the risk-coverage trade-off the product needs (Part 5, Chapter 6.5).

### Exercise 12 (design). A fine-tuning programme for a claims assistant

An insurance company's claims assistant uses hybrid search, an off-the-shelf reranker and a hosted LLM. Evaluation shows weak retrieval for policy clause numbers and internal claim codes, and inconsistent citation of clauses. Data: 2 years of claims-handler search logs with clicked documents, 3,000 policy documents, and handlers willing to label 500 items. Design the programme.

**Solution (one good answer).**

1. **Evaluation first**: 400 real handler questions with clause-level labels from the 500-label budget (pooled from several retrievers), reference answers, key facts; 100 labels reserved to validate LLM judges.
2. **Quick wins**: a clause-code field with an exact-match analyzer in BM25; chunking by clause with the clause number and policy title in every chunk.
3. **Reranker** (first training step): candidates from production hybrid search for logged queries; labels from clicks with position-bias correction plus LLM-teacher scores validated on human labels; train a cross-encoder with a listwise loss; ship behind a flag, A/B test.
4. **Embedder** (if recall@50 on clause codes stays low): fine-tune on (query, clicked clause) pairs plus synthetic queries per clause, hard negatives from the same policy family, false-negative filtering, split by policy document; Matryoshka training if storage matters; blue-green re-index.
5. **Generator behaviour**: if the hosted LLM can be fine-tuned, LoRA on RAFT-style examples teaching clause citation format and abstention; otherwise improve prompts and add structured output with citation validation.
6. **Operations**: model cards, quarterly re-evaluation against new off-the-shelf models, automated retraining when policies change, and a weekly review of handler-flagged answers feeding the evaluation set.

## Summary, cheat sheet and references

The one-sentence summary of Part 7: **train only the component that measured failures point to, starting with the cheapest to deploy and roll back, on leakage-free data with filtered hard negatives, and prove the gain with paired statistics before paying the cost of owning a custom model.**

### Ten things you should now be able to do

1. Map measured failures to the right component and the cheapest fix.
2. Explain why rerankers are usually trained first and generators last.
3. Build retrieval training data from logs, structures, labels and synthetic queries.
4. Mine hard negatives from a rank window and filter false negatives with a positive-aware cross-encoder margin.
5. Split data by document to avoid leakage, and detect memorisation in results.
6. Fine-tune an embedder with InfoNCE, a no-duplicates sampler, preserved prompts and optional Matryoshka loss; limit forgetting with weight interpolation.
7. Train rerankers with pointwise, pairwise or listwise losses, or distil an LLM teacher.
8. Build RAFT-style generator data with distractors and abstention targets, and train with LoRA or QLoRA.
9. Compute LoRA parameter counts and memory budgets.
10. Evaluate, document, deploy and schedule retraining for fine-tuned models.

### Cheat sheet

| Item | Rule or formula |
| --- | --- |
| Train order | Reranker → embedder → generator (behaviour only) |
| Hard negatives | Ranks about 10 to 50 from BM25 or dense; 1 to 7 per query |
| False-negative filter | Drop negatives with cross-encoder score ≥ 0.95 × positive |
| Splits | By document, topic or time; never by query |
| Embedder recipe | InfoNCE, lr 1e-5 to 5e-5, 1 to 3 epochs, warm-up 10%, no-duplicates batches, same prompts |
| Negatives per query in MNRL | 2B − 1 with batch B and one hard negative per row |
| Forgetting | Low lr, general data mix, weight interpolation θ = αθ\_ft + (1 − α)θ\_base |
| Reranker losses | BCE (pointwise), RankNet and Margin-MSE (pairwise), softmax, ListNet, LambdaLoss (listwise) |
| RAFT | Oracle + distractors; some examples without oracle; quote then answer |
| LoRA | W = W₀ + (α/r)BA; trainable r(d + k) per matrix; merge after training |
| QLoRA | 4-bit NF4 base + 16-bit adapters |
| Generator risks | Forgetting, over-refusal, format overfitting, safety regression |
| Shipping | Paired gain on held-out data, no guardrail regressions, model card |

### References

- Bonifacio et al. (2022). [InPars: Data Augmentation for Information Retrieval using Large Language Models](https://arxiv.org/abs/2202.05144).
- Dai et al. (2022). [Promptagator: Few-shot Dense Retrieval From 8 Examples](https://arxiv.org/abs/2209.11755).
- Wang et al. (2022). [GPL: Generative Pseudo Labeling for Unsupervised Domain Adaptation of Dense Retrieval](https://arxiv.org/abs/2112.07577).
- Moreira et al. (2024). [NV-Retriever: Improving Text Embedding Models with Effective Hard-Negative Mining](https://arxiv.org/abs/2407.15831).
- Solatorio (2024). [GISTEmbed: Guided In-sample Selection of Training Negatives for Text Embedding Fine-tuning](https://arxiv.org/abs/2402.16829).
- Wortsman et al. (2022). [Robust Fine-Tuning of Zero-Shot Models](https://arxiv.org/abs/2109.01903) (weight interpolation, WiSE-FT).
- Kusupati et al. (2022). [Matryoshka Representation Learning](https://arxiv.org/abs/2205.13147).
- Burges et al. (2005). Learning to Rank using Gradient Descent (RankNet). ICML 2005; Cao et al. (2007). Learning to Rank: From Pairwise Approach to Listwise Approach (ListNet). ICML 2007; Wang et al. (2018). The LambdaLoss Framework for Ranking Metric Optimization. CIKM 2018.
- Hu et al. (2021). [LoRA: Low-Rank Adaptation of Large Language Models](https://arxiv.org/abs/2106.09685).
- Dettmers et al. (2023). [QLoRA: Efficient Finetuning of Quantized LLMs](https://arxiv.org/abs/2305.14314).
- Zhang et al. (2024). [RAFT: Adapting Language Model to Domain Specific RAG](https://arxiv.org/abs/2403.10131).
- Rafailov et al. (2023). [Direct Preference Optimization](https://arxiv.org/abs/2305.18290).
- Qi et al. (2023). [Fine-tuning Aligned Language Models Compromises Safety, Even When Users Do Not Intend To!](https://arxiv.org/abs/2310.03693)

### Coming in Part 8: Advanced architectures

Part 8 moves beyond the fixed pipeline. You will build agentic RAG, where an LLM decides when and what to retrieve with tool calls, and implement it with a plain loop and with LangGraph; learn GraphRAG and knowledge-graph retrieval for questions that span many documents; retrieve over images and page screenshots with multimodal embeddings and ColPali-style models; expose retrieval through the Model Context Protocol; and connect RAG to long-term agent memory.
