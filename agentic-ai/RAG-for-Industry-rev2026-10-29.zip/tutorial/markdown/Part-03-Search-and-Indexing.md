# RAG for Industry, Part 3: Search and Indexing

Oct 28, 2026 · @Behi · revised 29 October 2026 (see CHANGELOG.md)

## How Part 3 fits

Part 2 turned text into vectors; Part 3 is about finding the right ones fast. In Part 1 retrieval was one NumPy line, `E @ q`, over 17 chunks. Production indexes hold millions to billions of chunks, must answer in tens of milliseconds, must respect filters such as permissions and dates, and must combine keyword and vector search. This part covers the algorithms and systems that do that.

**After this part you will be able to:**

1. Derive BM25, explain its two parameters, and implement it from scratch.
2. Explain exact search cost and measure an approximate index with recall, latency, throughput and memory.
3. Explain IVF, product quantisation, HNSW and DiskANN well enough to tune them and to whiteboard them in an interview.
4. Handle metadata filtering, updates, deletes, sharding and multi-tenancy, and know their failure modes.
5. Choose a vector database or search engine for a given set of constraints.
6. Combine dense and sparse retrieval with reciprocal rank fusion and score fusion, and measure the gain.

**Setup.** Same free Colab or Kaggle T4 notebook. The lab adds FAISS (Meta's similarity-search library), a fast BM25 library and the Qdrant client:

```python
!pip install -q -U "sentence-transformers>=6.0,<7" "transformers>=5.0,<6" faiss-cpu bm25s "qdrant-client>=1.12" pandas

import numpy as np, time, torch
import faiss
print("FAISS", faiss.__version__, "| GPU:", torch.cuda.is_available())
```

We use the CPU build of FAISS because it installs reliably everywhere; the algorithms are identical on GPU. The lab's main dataset is SciFact (5,183 abstracts, 300 test queries), loaded exactly as in Part 2, Exercise 9, plus a larger synthetic set for speed benchmarks.

**Track notes.** Chapters 1, 4, 5 and 6 are core for application engineers; Chapters 2 and 3 are core for both tracks and are favourite whiteboard topics in ML and search-engineering interviews.

## Chapter 1. Lexical search and BM25

BM25 is still the default keyword-ranking function of Lucene, Elasticsearch and OpenSearch, and a strong baseline that dense models must beat. It scores a document by summing, over the query terms it contains, a rarity weight (IDF) times a saturating, length-normalised term-frequency weight.

### 1.1 The inverted index

An **inverted index** maps each term to a **postings list**: the documents containing it, with the term frequency and often the positions. To answer a query, the engine reads only the postings of the query's terms, so cost depends on how common those terms are, not on corpus size. Positions enable phrase queries ("battery overheating"). Top-k pruning algorithms such as WAND and Block-Max WAND skip documents that cannot enter the top k, which makes keyword search fast even over billions of documents.

### 1.2 Analyzers

Before indexing and querying, text passes through an **analyzer**: tokenisation, lowercasing, optional stop-word removal, stemming or lemmatisation ("passwords" → "password"), and sometimes synonyms or n-grams. **The same analyzer must run at index time and query time.** Part 1, Exercise 7 showed the cost of skipping stemming: "password" did not match "Passwords". Language-specific analyzers matter for non-English text, and identifier-heavy content (error codes, SKUs) often needs a separate field with a gentler analyzer so "E-212" is not split or stemmed away.

### 1.3 BM25, derived

BM25 comes from the probabilistic relevance framework of Robertson and Spärck Jones. Rank documents by the odds that they are relevant to the query. Under the **binary independence model** (terms occur independently, given relevance), the log-odds decompose into a sum of per-term weights. With no relevance labels, the weight for term t reduces to an IDF-like quantity, where N is the number of documents and n\_t the number containing t:

```latex
w_t = \log \frac{N - n_t + 0.5}{n_t + 0.5}
```

This is negative for terms in more than half the documents, so Lucene uses a variant that is always positive:

```latex
\mathrm{IDF}(t) = \ln\!\left(1 + \frac{N - n_t + 0.5}{n_t + 0.5}\right)
```

Robertson and colleagues then added two empirical corrections, motivated by the 2-Poisson "eliteness" model. First, **term frequency saturates**: the 10th occurrence of a word adds less evidence than the 1st. Second, **long documents are penalised**, because they contain more occurrences of everything by chance. The result is Okapi BM25:

```latex
\mathrm{BM25}(q, d) = \sum_{t \in q} \mathrm{IDF}(t) \cdot \frac{f(t,d)\,(k_1 + 1)}{f(t,d) + k_1\left(1 - b + b\,\dfrac{|d|}{\mathrm{avgdl}}\right)}
```

Here f(t, d) is the count of t in d, |d| the document length, and avgdl the average length in the corpus.

- **k₁** controls saturation. With k₁ = 0 the term-frequency part is a constant 1 (only presence matters); as f → ∞ it approaches k₁ + 1. Typical values are 1.2 to 2.0; Lucene's default is 1.2.
- **b** controls length normalisation, from 0 (none) to 1 (full). The default is 0.75.

### 1.4 A worked example

Take N = 1,000 documents, a query term in n\_t = 10 of them, avgdl = 100, k₁ = 1.2 and b = 0.75. IDF = ln(1 + 990.5 / 10.5) = ln(95.33) = 4.557.

| Term count f | Document length | Length factor (1 − b + b·\|d\|/avgdl) | TF part | Term score |
| --- | --- | --- | --- | --- |
| 1 | 100 | 1.000 | 1.000 | 4.557 |
| 3 | 50 | 0.625 | 1.760 | 8.021 |
| 3 | 150 | 1.375 | 1.419 | 6.469 |
| 10 | 100 | 1.000 | 1.964 | 8.952 |
| 100 | 100 | 1.000 | 2.174 | 9.907 |

Read it as: tripling the count raises the score a lot, but going from 10 to 100 occurrences barely helps (saturation towards k₁ + 1 = 2.2); the same three occurrences count for more in a short document than in a long one. A very common term (in 900 of 1,000 documents) gets IDF = ln(1 + 100.5 / 900.5) ≈ 0.106, so it contributes almost nothing.

### 1.5 Practical extensions

- **Field weighting**: titles usually deserve more weight than bodies. Engines support per-field boosts, and BM25F combines fields inside the saturation function rather than after it.
- **Tuning**: k₁ and b can be tuned on an evaluation set, but defaults are hard to beat by much; better analyzers usually matter more.
- **Variants**: BM25+ and BM25L fix edge cases for very long documents. Libraries differ slightly in IDF and normalisation, so the same query can produce slightly different scores in Lucene, rank\_bm25 and bm25s.
- **Learned sparse retrieval** (SPLADE, Part 2) keeps the inverted index but replaces BM25's hand-made weights with learned ones plus expansion terms.

### 1.6 Why BM25 survives in RAG systems

BM25 needs no GPU or training, is strong on rare terms, names, codes and exact phrases, is explainable term by term, and generalises to new domains better than many dense models did before about 2022. On the BEIR zero-shot benchmark it remained a hard baseline for years. That is why hybrid search (Chapter 6) is the standard production design.

## Chapter 2. Exact search and how to measure approximate search

Exact (brute-force) search compares the query with every vector and is the right choice more often than people expect; approximate search trades a measurable amount of recall for large gains in speed and memory. You must be able to estimate the first and measure the second.

### 2.1 The cost of exact search

For N vectors of dimension d, one query costs N·d multiply-adds plus a top-k selection (O(N) with `argpartition`, or O(N log k) with a heap). In practice exact search is limited by **memory bandwidth**, not arithmetic: every query must read all N·d·bytes of the index. That gives a quick lower bound on latency:

```latex
t_{\text{query}} \gtrsim \frac{N \cdot d \cdot \text{bytes per value}}{\text{memory bandwidth}}
```

Example: 1 million 768-dimensional float16 vectors are 1.5 GB. A T4 GPU reads memory at about 300 GB/s, so one query takes at least about 5 ms; a server CPU at roughly 50 to 100 GB/s needs 15 to 30 ms. Batching many queries into one matrix-matrix product reuses each loaded vector across the batch, which is why GPU brute force reaches very high throughput for batch workloads.

### 2.2 When exact search is enough

- Up to roughly a few hundred thousand vectors, or a few million on a GPU, if latency budgets allow.
- When a strict filter already narrows candidates to a small set (one tenant's documents, one product line).
- When you need **ground truth** to evaluate an approximate index.
- When perfect recall is required (some legal or compliance searches).

Start exact, measure, and move to ANN only when latency, throughput or memory force you to.

### 2.3 Measuring an approximate index

ANN quality has its own metric, distinct from relevance:

```latex
\text{ANN recall@}k = \frac{\big|\,\text{ANN top-}k \;\cap\; \text{exact top-}k\,\big|}{k}
```

It asks "did the index return the same neighbours exact search would?", not "were the results relevant?". Keep the two apart: an index can have ANN recall@10 = 1.0 with a poor embedding model, and a small loss in ANN recall often costs little end-to-end relevance because the missed neighbours are near-ties.

A complete benchmark reports five things together:

| Measure | What it captures | Typical way to report |
| --- | --- | --- |
| ANN recall@k | Fidelity to exact search | At k = 10, averaged over 1,000+ queries |
| Latency | User-facing speed | p50, p95, p99 in milliseconds at a given load |
| Throughput | Capacity | Queries per second (QPS) per machine |
| Memory | Cost | Bytes per vector including index overhead |
| Build and update time | Operability | Minutes to build; cost of inserts and deletes |

Every ANN method has parameters that trade recall for speed (nprobe for IVF, efSearch for HNSW). Plot recall against QPS while sweeping them and compare indexes by their **Pareto curves**, never by a single point. Public comparisons such as ann-benchmarks.com and the big-ann-benchmarks competitions report results this way.

### 2.4 The end-to-end view

What users experience is relevance, so finish every index experiment with the retrieval metrics from Parts 1 and 2 (recall@k against labelled relevant documents, MRR, nDCG). An index setting is acceptable when the relevance metrics stay within your tolerance (for example, less than 1 point of nDCG@10 lost) at the latency and cost you need.

## Chapter 3. Approximate nearest-neighbour algorithms

Three ideas power almost every production vector index: **partition** the space and search only a few partitions (IVF), **compress** vectors so more fit in memory and distances are cheap (product quantisation), and **navigate a graph** of neighbours towards the query (HNSW, DiskANN). Most real indexes combine two of them.

### 3.1 IVF: inverted file with a coarse quantiser

**Build.** Run k-means on (a sample of) the vectors to get nlist centroids. Assign every vector to its nearest centroid; each centroid owns an **inverted list** of its vectors. This is the same inverted-index idea as BM25, with clusters in place of words.

**Search.** Compare the query with all nlist centroids, pick the nprobe nearest, and search only the vectors in those lists exactly. The approximate cost per query is:

```latex
\text{cost} \approx n_{\text{list}}\, d \;+\; n_{\text{probe}} \cdot \frac{N}{n_{\text{list}}} \cdot d
```

With nprobe = 1, the two terms balance at nlist = √N. FAISS's guidance is nlist between about 4√N and 16√N, trained on at least 30 to 40 vectors per centroid. For 1 million vectors that means roughly 4,000 to 16,000 lists.

**The knob.** nprobe trades recall for speed. Recall is lost when a true neighbour sits in a cluster whose centroid is not among the nprobe nearest, typically near cluster boundaries. Larger nprobe searches more lists; nprobe = nlist is exact search with extra overhead.

**Weaknesses.** Needs a training step; clusters drift as data changes (retrain periodically); recall drops for queries near boundaries.

![IVF: the query is compared with the centroids, and only the nprobe nearest lists are scanned](../diagrams/p03_ivf.svg)

*IVF: the query is compared with the centroids, and only the nprobe nearest lists are scanned*

### 3.2 Product quantisation (PQ)

PQ (Jégou, Douze and Schmid, 2011) compresses each vector to a few bytes. Split the d dimensions into m sub-vectors of d/m dimensions. For each sub-space, run k-means with 256 centroids, a **codebook**. Encode each sub-vector as the index of its nearest centroid (one byte). A vector becomes m bytes.

Distances are computed without decompressing, by **asymmetric distance computation (ADC)**: the query stays in full precision. For each sub-space j, precompute the squared distance from the query's sub-vector q\_j to all 256 centroids, a lookup table T of size m × 256. Then each database vector's distance is m table lookups and additions:

```latex
\lVert q - x \rVert^2 \approx \sum_{j=1}^{m} \lVert q_j - c_j\big(x\big) \rVert^2 = \sum_{j=1}^{m} T\big[j,\, \text{code}_j(x)\big]
```

Example: d = 768 float32 is 3,072 bytes; with m = 96 the code is 96 bytes, a 32× saving, so 1 billion vectors fit in about 96 GB. More sub-spaces (larger m) means better accuracy and more bytes. **OPQ** first applies a learned rotation so information spreads evenly across sub-spaces, improving accuracy for free at query time.

**IVF-PQ** combines both: IVF picks the lists, and the vectors in the lists are stored as PQ codes of their **residuals** (the vector minus its centroid), which are smaller and quantise better. Since PQ distances are approximate, systems usually **re-rank** the top few hundred candidates with full-precision vectors, often stored on disk.

![Product quantisation: split the vector, quantise each piece with its own codebook, keep the codes](../diagrams/p03_pq.svg)

*Product quantisation: split the vector, quantise each piece with its own codebook, keep the codes*

### 3.3 HNSW: hierarchical navigable small-world graphs

HNSW (Malkov and Yashunin, 2016) is the most widely used ANN index in vector databases. It builds a graph where each vector links to nearby vectors, arranged in layers like a skip list: the bottom layer contains every vector, and each higher layer contains an exponentially smaller random subset, giving long-range "highways".

**Insertion.** Each new vector draws a top layer l = ⌊−ln(U) · m\_L⌋ with U uniform on (0, 1) and m\_L = 1 / ln(M), so the probability of reaching each higher layer shrinks by a factor of M. Starting from the global entry point at the top layer, the algorithm greedily descends to layer l + 1, then on each layer from l down to 0 runs a beam search of width **efConstruction** and connects the new vector to up to **M** neighbours (2M on layer 0), chosen by a heuristic that prefers diverse directions over clumped neighbours.

**Search.** Greedy descent through the upper layers with a beam of 1, then a beam search of width **efSearch** on layer 0, returning the best k found:

```python
# Pseudocode: min_heap, max_heap, dist and neighbours stand for priority queues, the distance
# function and the graph's adjacency lists; the lab implements a runnable version.
def search_layer(q, entry_points, ef, layer):
    visited = set(entry_points)
    candidates = min_heap((dist(q, e), e) for e in entry_points)   # to expand, closest first
    results = max_heap((dist(q, e), e) for e in entry_points)      # best ef found so far
    while candidates:
        d_c, c = candidates.pop_closest()
        if d_c > results.furthest_distance():
            break                                  # nothing left can improve the results
        for n in neighbours(c, layer):
            if n not in visited:
                visited.add(n)
                d_n = dist(q, n)
                if len(results) < ef or d_n < results.furthest_distance():
                    candidates.push((d_n, n))
                    results.push((d_n, n))
                    if len(results) > ef:
                        results.pop_furthest()
    return results
```

**Knobs.** M (typically 16 to 64): more links give higher recall and more memory. efConstruction (100 to 500): better graph quality, slower build. efSearch (at least k, commonly 64 to 512): the recall-latency knob at query time. Search cost grows roughly logarithmically with N in practice.

![HNSW: greedy descent through sparse upper layers, then a beam search on layer 0](../diagrams/p03_hnsw.svg)

*HNSW: greedy descent through sparse upper layers, then a beam search on layer 0*

**Memory.** Full vectors plus links. With M = 16, layer 0 stores up to 32 neighbour ids of 4 bytes, about 128 bytes per vector, plus a little for upper layers. For 768-dimensional float32 vectors (3,072 bytes) the links are a modest overhead, but the vectors themselves must normally sit in RAM, which is HNSW's main cost. Many databases now pair HNSW with scalar, binary or product quantisation and re-rank with full vectors.

**Weaknesses.** RAM-hungry; slow to build at large scale; deletions leave holes that degrade the graph until it is repaired or rebuilt; restrictive filters can disconnect the traversable part of the graph (Chapter 4).

### 3.4 DiskANN and SSD-resident indexes

DiskANN (Subramanya et al., 2019) builds a single-layer graph called **Vamana** whose pruning rule (with a parameter α > 1) deliberately keeps some long-range edges, so searches need few hops. The graph and full vectors live on SSD; only PQ-compressed vectors stay in RAM to guide the search, and full vectors are read from disk to re-rank the final candidates. This made billion-scale search practical on a single machine with modest RAM. Variants support streaming inserts and deletes (FreshDiskANN) and filters (Filtered-DiskANN), and DiskANN-style indexes appear in several products, for example pgvectorscale's StreamingDiskANN for PostgreSQL and Microsoft's Azure databases.

### 3.5 ScaNN and anisotropic quantisation

Google's ScaNN (Guo et al., 2020) observes that for maximum inner product search, quantisation error **parallel** to a data point changes its score more than error orthogonal to it. Its anisotropic quantisation loss penalises the parallel component more heavily, improving ranking accuracy at the same code size. ScaNN underlies Google's Vertex AI Vector Search and AlloyDB's vector index.

### 3.6 Choosing an index type

| Situation | Good default | Why |
| --- | --- | --- |
| Under about 1 million vectors, memory available | Flat (exact) or HNSW | Exact is simple and perfect; HNSW if latency demands |
| 1 to 100 million vectors, RAM available, low latency | HNSW, optionally with int8 or binary quantisation plus re-ranking | Best recall-latency trade-off in RAM |
| Hundreds of millions to billions, RAM-limited | IVF-PQ (with re-ranking) or DiskANN | Compression or SSD residency |
| Heavy, frequent filtering | Engine with filter-aware graph search, or partition by the filter key | Plain HNSW degrades under restrictive filters |
| Batch, offline similarity jobs | GPU brute force or GPU IVF | Throughput over latency |

Whatever you choose, sweep the knobs and pick a point on the measured recall-QPS curve; the lab does exactly this with FAISS.

## Chapter 4. Real-world indexes: filters, updates, scale and tenants

Benchmarks measure an index on a static set of vectors with no conditions. Production indexes must also apply metadata filters, absorb continuous inserts and deletes, spread across machines, and isolate customers. Each of these interacts badly with ANN structures if handled naively.

### 4.1 Metadata filtering

Real queries come with conditions: `tenant_id = 42`, `date >= 2025-01-01`, `allowed_groups ∋ engineering`, `language = de`. There are three strategies.

**Post-filtering** runs the ANN search for k′ candidates, then discards those failing the filter. If a fraction s of documents passes the filter (its **selectivity**), you expect only s·k′ survivors, so returning k results needs about:

```latex
k' \approx \frac{k}{s}
```

For k = 10 and s = 0.001 (one document in a thousand passes), that is 10,000 candidates, far beyond normal search settings. Post-filtering silently returns too few results, or none, for selective filters.

**Pre-filtering** first finds the set of allowed documents (using an ordinary database index on the metadata), then searches only them. With a small allowed set, exact search over it is fast and perfect. With a large allowed set, you still need an ANN structure that respects the filter.

**Filtered (in-traversal) search** walks the ANN graph but only admits allowed nodes into the results. It works well when many nodes pass, but restrictive filters can leave the allowed nodes poorly connected, so the search gets stuck and recall collapses. Remedies used by current engines include: estimating the filter's cardinality and switching to exact search over the allowed set when it is small (Qdrant's query planner does this); adding extra graph edges for frequently filtered values; ACORN (Patel et al., 2024), which builds a denser graph and expands neighbours-of-neighbours during filtered search; and "iterative" scans that keep fetching more candidates until enough pass the filter (pgvector 0.8 added these).

**Practical rules.** Index the metadata fields you filter on. Test recall under your real filter distribution, especially the most selective filters. For filters that split data into large, stable groups (tenant, language), consider separate partitions instead of filters.

### 4.2 Updates and deletes

- **Inserts**: HNSW supports online insertion. IVF can add vectors to existing lists, but its centroids slowly stop matching the data, so retrain and rebuild periodically.
- **Deletes**: graph indexes usually mark deleted nodes as **tombstones**, still traversed but never returned. Many tombstones slow search and hurt recall until a compaction or rebuild repairs the graph.
- **Updates** are a delete plus an insert. Give every chunk a stable id derived from its source document and position, so re-indexing a changed document can find and replace its old chunks.
- **Segments**: many engines (Lucene-based ones, Milvus and others) write data into immutable segments, each with its own index, and merge segments in the background. Searches fan out over segments and merge results. This makes writes cheap and explains the delay between writing a document and seeing it in results (**index freshness**).

### 4.3 Sharding and replication

- **Sharding** splits the index across machines. With **document sharding**, every query goes to all shards, each returns its local top k, and a coordinator merges them (**scatter-gather**). Latency is then set by the slowest shard, so tail latency grows with shard count. With **tenant or key sharding**, a query goes only to the shard holding its tenant.
- **Replication** copies each shard to several machines for throughput and availability; replicas are added to handle more queries per second, shards to handle more data.

### 4.4 Multi-tenancy

SaaS products serve many customers whose data must never mix.

| Pattern | How it works | Strengths | Risks |
| --- | --- | --- | --- |
| Index (collection) per tenant | Separate index for each customer | Strong isolation, easy deletion of a customer | Overhead with thousands of small tenants |
| Shared index with a tenant filter | One index, every query filtered by tenant\_id | Efficient for many small tenants | A missing filter leaks data; filtered-search recall for small tenants |
| Partitions or namespaces | Engine-level grouping inside one collection | A middle ground supported by several databases | Engine-specific limits |

Whichever pattern you use, apply the tenant and permission filter **on the server side**, derived from the authenticated identity, never from text the LLM or the user can influence. Test for cross-tenant leaks explicitly.

### 4.5 Versioning and safe re-indexing

Embedding-model upgrades, chunking changes and index-parameter changes all require rebuilding. The standard pattern is **blue-green indexing**: build the new collection alongside the old one, evaluate it, then switch an **alias** that queries point to, keeping the old collection for rollback. Store the embedding model name and revision, chunker version and index parameters as metadata of each collection.

## Chapter 5. Vector databases and search engines in October 2026

There is no single best vector database. The right choice depends mostly on what your organisation already runs, how many vectors you have, how much filtering and keyword search you need, and who will operate it. Learn the categories; products inside each change quickly.

### 5.1 Libraries versus databases

A **library** such as FAISS, hnswlib, ScaNN, USearch or DiskANN gives you index algorithms in your process. It does not give you persistence, replication, metadata filtering, access control, or an API. A **database** wraps indexes with storage, a write path, filters, sharding, backups and security. Libraries are ideal for research, offline jobs and learning (the lab uses FAISS); production RAG almost always needs a database or search engine.

### 5.2 The landscape

| Category | Examples | Typical strengths | Typical trade-offs |
| --- | --- | --- | --- |
| Vectors inside PostgreSQL | pgvector (HNSW and IVFFlat; half-precision, binary and sparse vector types; iterative index scans for filtered search since 0.8), pgvectorscale (StreamingDiskANN), managed Postgres services, Google AlloyDB (ScaNN-based index) | One system for data, metadata, permissions and vectors; SQL joins and transactions | Single-node scale limits; tuning Postgres memory for vectors |
| Dedicated open-source vector databases | Qdrant, Milvus (managed as Zilliz Cloud), Weaviate, Chroma, LanceDB | Purpose-built filtering, quantisation, hybrid sparse plus dense, horizontal scale | Another system to operate, secure and keep in sync |
| Search engines with vector support | Elasticsearch, OpenSearch, Vespa, Solr | Mature BM25, analyzers, aggregations and hybrid ranking in one engine | Heavier to operate; vector features vary by version |
| Managed and serverless services | Pinecone, turbopuffer, Amazon S3 Vectors, Google Vertex AI Vector Search, Azure AI Search, MongoDB Atlas Vector Search, Redis | No servers to manage; usage-based pricing; some store data on object storage for low cost | Vendor lock-in, data residency, less control over tuning |
| ANN libraries | FAISS, hnswlib, ScaNN, USearch, DiskANN | Fast, flexible, ideal for experiments and batch jobs | No persistence, filters or operations |

Two trends worth naming in interviews. First, **object-storage-backed** vector search (turbopuffer, LanceDB, Amazon S3 Vectors) keeps most data in cheap storage and caches hot parts, trading some latency for much lower cost at large scale. Second, **convergence**: general databases (PostgreSQL, MongoDB, Redis, Elasticsearch) added vector search, while vector databases added keyword search, sparse vectors and richer filtering, so feature lists overlap more each year.

### 5.3 Selection criteria

1. **What do you already run?** If your documents and permissions live in PostgreSQL and you have up to tens of millions of vectors, pgvector is often the simplest correct answer. If you already run Elasticsearch or OpenSearch for search, add vectors there.
2. **Scale and cost model**: vectors × bytes per vector (Part 2, Chapter 5) and whether they must sit in RAM, on SSD, or can live on object storage.
3. **Filtering**: how selective and how frequent; test filtered recall, not just unfiltered benchmarks.
4. **Hybrid search**: native BM25 or sparse-vector support and built-in fusion (Chapter 6).
5. **Multi-tenancy and security**: tenant isolation features, role-based access, encryption, audit logs, data residency.
6. **Write pattern and freshness**: bulk nightly loads versus continuous streaming updates.
7. **Operations**: managed or self-hosted, backups, upgrades, monitoring, and your team's experience.
8. **Licence and lock-in**: open-source licence, export paths, and how hard it would be to migrate.

> Interview tip: when asked "which vector database would you use?", do not name a product first. State the constraints you would check (scale, existing stack, filters, hybrid, tenancy, ops), then give a reasoned default, for example "pgvector if we are already on Postgres below about 50 million vectors, otherwise a dedicated engine such as Qdrant or Milvus, or a managed service if we have no one to run it."

## Chapter 6. Hybrid search

Hybrid search runs a lexical retriever (BM25 or learned sparse) and a dense retriever in parallel and fuses their ranked lists. Because the two fail on different queries (exact codes and rare names versus paraphrases), fusion usually beats either alone, and **reciprocal rank fusion (RRF)** is the robust default because it needs no score calibration.

![Hybrid retrieval pipeline: sparse and dense in parallel, fused, then reranked](../diagrams/p03_hybrid_pipeline.svg)

*Hybrid retrieval pipeline: sparse and dense in parallel, fused, then reranked*

The same permission filter applies inside both retrievers, so forbidden documents never enter the fused list; each stage then narrows the candidates until only a handful reach the prompt.

### 6.1 Why fusion is not trivial

The two retrievers produce scores on incompatible scales. BM25 is unbounded and depends on query length and term rarity; cosine similarity lives in \[−1, 1\] and, for many models, is compressed into a narrow band (Part 2). Adding raw scores lets whichever scale is larger dominate.

### 6.2 Score fusion

Normalise each retriever's scores **per query**, then combine with a weight α:

```latex
s(d) = \alpha \cdot \hat{s}_{\text{dense}}(d) + (1 - \alpha) \cdot \hat{s}_{\text{sparse}}(d), \qquad \hat{s} = \frac{s - \min s}{\max s - \min s}
```

Variants use z-scores or, as in Qdrant's distribution-based score fusion, scale by the mean ± 3 standard deviations. Score fusion uses score magnitudes, which can help when one retriever is very confident, but it is sensitive to outliers and to the candidate set, and α should be tuned on an evaluation set.

### 6.3 Reciprocal rank fusion

RRF (Cormack, Clarke and Büttcher, 2009) ignores scores and uses only ranks. For a set of ranked lists R:

```latex
\mathrm{RRF}(d) = \sum_{r \in R} \frac{1}{k + \mathrm{rank}_r(d)}, \qquad k = 60
```

A document missing from a list contributes 0 for that list. The constant k damps the advantage of the very top ranks, so a document ranked well by both retrievers beats one ranked first by only one. k = 60 comes from the original paper and is the default in most engines.

**Worked example.** Dense ranks A, B, C, D; BM25 ranks C, A, E.

| Document | Dense rank | BM25 rank | RRF score | Fused rank |
| --- | --- | --- | --- | --- |
| A | 1 | 2 | 1/61 + 1/62 = 0.03252 | 1 |
| C | 3 | 1 | 1/63 + 1/61 = 0.03227 | 2 |
| B | 2 | none | 1/62 = 0.01613 | 3 |
| E | none | 3 | 1/63 = 0.01587 | 4 |
| D | 4 | none | 1/64 = 0.01563 | 5 |

Documents found by both retrievers rise to the top. **Weighted RRF** multiplies each list's term by a weight when one retriever is known to be stronger.

### 6.4 Practical settings

- **Candidate depth**: let each retriever return 50 to 100 candidates before fusing; fusing only the top 10 of each wastes the method's strength.
- **Fuse, then rerank**: the standard pipeline is lexical + dense → RRF → cross-encoder reranking of the top 20 to 100 → top 3 to 10 into the prompt (Part 5).
- **Measure**: on some corpora one retriever is so much stronger that fusion adds little or even hurts. Always compare fused results with each retriever alone on your evaluation set.
- **Learning to rank**: with enough labelled or click data, train a model (for example gradient-boosted trees such as LambdaMART) on features from both retrievers plus metadata. This can beat fixed fusion but needs data and maintenance.

### 6.5 Hybrid search in common engines

Most engines now fuse natively: Elasticsearch offers an RRF retriever; OpenSearch's hybrid query uses a search pipeline with score normalisation or RRF; Qdrant's Query API runs prefetch queries over dense and sparse vectors and fuses them with RRF or distribution-based fusion; Weaviate's hybrid search takes an α parameter; Milvus's hybrid search accepts RRF or weighted rankers; Vespa expresses fusion in rank profiles; with PostgreSQL you can combine pgvector with full-text search (tsvector) and compute RRF in SQL. Exact syntax changes between versions, so check current documentation.

## Chapter 7. Hands-on lab

You will implement BM25, IVF and product quantisation from scratch, benchmark FAISS indexes on a recall-versus-speed curve, build hybrid search with RRF on a real benchmark, and run filtered search in a vector database. Every from-scratch component is checked against a library or against exact search.

The ANN benchmarks use a synthetic set of 100,000 clustered unit vectors, large enough to show speed differences and small enough for a free notebook. Clustered synthetic data is easier for ANN than real embeddings, so treat the absolute recall numbers as optimistic; the **shape** of each trade-off is what transfers. Expect timings to vary by machine.

### Lab 0. Data and helpers

```python
import numpy as np, pandas as pd, re, time, faiss, torch
import scipy.sparse as sp
from collections import Counter
from huggingface_hub import hf_hub_download
from sentence_transformers import SentenceTransformer
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# --- SciFact (as in Part 2, Exercise 9) ---
def load_scifact():
    get = lambda f: hf_hub_download("mteb/scifact", f, repo_type="dataset")
    corpus = pd.read_json(get("corpus.jsonl"), lines=True, dtype={"_id": str})
    queries = pd.read_json(get("queries.jsonl"), lines=True, dtype={"_id": str})
    qrels = pd.read_csv(get("qrels/test.tsv"), sep="\t", dtype={"query-id": str, "corpus-id": str})
    rel = qrels[qrels["score"] > 0].groupby("query-id")["corpus-id"].apply(set).to_dict()
    queries = queries[queries["_id"].isin(rel)].reset_index(drop=True)
    return corpus, queries, rel

corpus, queries, rel = load_scifact()
doc_ids = corpus["_id"].tolist()
doc_texts = (corpus["title"].fillna("") + "\n" + corpus["text"].fillna("")).tolist()
query_ids, query_texts = queries["_id"].tolist(), queries["text"].tolist()

def ir_metrics(S, k=10):
    """Relevance metrics from a (n_queries, n_docs) score matrix."""
    rec = mrr = ndcg = 0.0
    for i, qid in enumerate(query_ids):
        top = np.argpartition(-S[i], k)[:k]
        top = top[np.argsort(-S[i][top])]
        gains = [1.0 if doc_ids[j] in rel[qid] else 0.0 for j in top]
        R = len(rel[qid])
        rec += sum(gains) / R
        mrr += next((1.0 / (r + 1) for r, g in enumerate(gains) if g), 0.0)
        dcg = sum(g / np.log2(r + 2) for r, g in enumerate(gains))
        idcg = sum(1.0 / np.log2(r + 2) for r in range(min(R, k)))
        ndcg += dcg / idcg
    n = len(query_ids)
    return {"recall@10": round(rec / n, 3), "MRR@10": round(mrr / n, 3), "nDCG@10": round(ndcg / n, 3)}

# --- Synthetic clustered vectors for ANN speed tests ---
def make_data(n=100_000, d=128, n_clusters=500, n_queries=500, spread=0.6, seed=0):
    rng = np.random.default_rng(seed)
    centers = rng.normal(size=(n_clusters, d)).astype(np.float32)
    def sample(m):
        X = centers[rng.integers(0, n_clusters, size=m)] + spread * rng.normal(size=(m, d)).astype(np.float32)
        return X / np.linalg.norm(X, axis=1, keepdims=True)
    return sample(n), sample(n_queries)

X, Q = make_data()
k = 10
exact = np.argsort(-(Q @ X.T), axis=1)[:, :k]          # ground truth for ANN recall

def ann_recall(found, exact):
    return np.mean([len(set(f) & set(e)) / len(e) for f, e in zip(found, exact)])
```

### Lab 1. BM25 from scratch

Because BM25 is a sum over query terms, all document-side work can be precomputed into a sparse matrix W of per-(document, term) contributions. A query is then a sparse 0/1 vector over its unique terms, and scoring every document is one sparse matrix product.

```python
STOP = set("a an and are as at be by for from has have in is it its of on or that the to was were will with".split())
def tokenize(text):
    return [t for t in re.findall(r"[a-z0-9]+(?:-[a-z0-9]+)*", text.lower()) if t not in STOP]

class BM25:
    def __init__(self, k1=1.2, b=0.75):
        self.k1, self.b = k1, b

    def fit(self, docs):
        self.vocab, rows, cols, vals = {}, [], [], []
        for i, d in enumerate(docs):
            for t, c in Counter(tokenize(d)).items():
                j = self.vocab.setdefault(t, len(self.vocab))
                rows.append(i); cols.append(j); vals.append(c)
        N, V = len(docs), len(self.vocab)
        tf = sp.csr_matrix((vals, (rows, cols)), shape=(N, V), dtype=np.float32)
        dl = np.asarray(tf.sum(axis=1)).ravel()                       # document lengths
        df = np.bincount(tf.indices, minlength=V)                      # document frequencies
        self.idf = np.log(1 + (N - df + 0.5) / (df + 0.5)).astype(np.float32)
        tf = tf.tocoo()
        norm = self.k1 * (1 - self.b + self.b * dl[tf.row] / dl.mean())
        w = self.idf[tf.col] * tf.data * (self.k1 + 1) / (tf.data + norm)
        self.W = sp.csr_matrix((w, (tf.row, tf.col)), shape=(N, V))   # (docs, terms)
        return self

    def scores(self, queries):
        rows, cols = [], []
        for i, q in enumerate(queries):
            for j in sorted({self.vocab[t] for t in tokenize(q) if t in self.vocab}):
                rows.append(i); cols.append(j)
        Qm = sp.csr_matrix((np.ones(len(rows), np.float32), (rows, cols)),
                           shape=(len(queries), len(self.vocab)))
        return np.asarray((Qm @ self.W.T).todense())                  # (queries, docs)

bm25 = BM25().fit(doc_texts)
S_bm25 = bm25.scores(query_texts)
print("BM25 (ours) ", ir_metrics(S_bm25))
```

Compare with the bm25s library. Its tokenizer and stop-word list differ from ours, so expect close but not identical numbers:

```python
import bm25s
retriever = bm25s.BM25(k1=1.2, b=0.75)
retriever.index(bm25s.tokenize(doc_texts, stopwords="en"))
idx, sc = retriever.retrieve(bm25s.tokenize(query_texts, stopwords="en"), k=100)
S_lib = np.full((len(query_texts), len(doc_texts)), -np.inf)
for i in range(len(query_texts)):
    S_lib[i, idx[i]] = sc[i]
print("BM25 (bm25s)", ir_metrics(S_lib))
```

BM25 is known to be strong on SciFact relative to many dense models, which is a good reminder to always run it as a baseline.

### Lab 2. IVF from scratch

```python
def kmeans(X, n_centroids, n_iter=10, seed=0):
    rng = np.random.default_rng(seed)
    C = X[rng.choice(len(X), n_centroids, replace=False)].copy()
    for _ in range(n_iter):
        assign = np.argmin((C ** 2).sum(1)[None, :] - 2 * X @ C.T, axis=1)   # nearest centroid (L2)
        sums = np.zeros_like(C)
        np.add.at(sums, assign, X)
        counts = np.bincount(assign, minlength=n_centroids)
        nonempty = counts > 0
        C[nonempty] = sums[nonempty] / counts[nonempty, None]
    return C, assign

class IVF:
    def __init__(self, nlist):
        self.nlist = nlist
    def fit(self, X, train_size=20_000):
        rng = np.random.default_rng(1)
        sample = X[rng.choice(len(X), min(train_size, len(X)), replace=False)]
        self.C, _ = kmeans(sample, self.nlist)
        self.c_sq = (self.C ** 2).sum(1)
        assign = np.argmin(self.c_sq[None, :] - 2 * X @ self.C.T, axis=1)
        self.lists = [np.where(assign == j)[0] for j in range(self.nlist)]
        self.X = X
        return self
    def search(self, q, k, nprobe):
        probe = np.argsort(self.c_sq - 2 * self.C @ q)[:nprobe]       # nprobe nearest centroids
        cand = np.concatenate([self.lists[j] for j in probe])
        top = np.argsort(-(self.X[cand] @ q))[:k]                     # exact search inside lists
        return cand[top], len(cand)

ivf = IVF(nlist=int(4 * np.sqrt(len(X)))).fit(X)                    # about 1,265 lists
for nprobe in [1, 4, 16, 64]:
    out = [ivf.search(q, k, nprobe) for q in Q]
    scanned = np.mean([n for _, n in out])
    print(f"nprobe={nprobe:<3} recall@10={ann_recall([f for f, _ in out], exact):.3f} "
          f"scanned={scanned:,.0f} vectors ({scanned / len(X):.1%} of the index)")
```

You should see recall climb steeply with nprobe while the fraction of vectors scanned stays small: on this data, a few probes already reach recall near 1 while scanning well under 1% of the index.

### Lab 3. Product quantisation from scratch

```python
class PQ:
    def __init__(self, m, n_codes=256):
        self.m, self.ks = m, n_codes
    def fit(self, X, train_size=20_000):
        self.ds = X.shape[1] // self.m                                  # dims per sub-vector
        sample = X[np.random.default_rng(2).choice(len(X), train_size, replace=False)]
        self.codebooks = [kmeans(sample[:, j*self.ds:(j+1)*self.ds], self.ks)[0] for j in range(self.m)]
        return self
    def encode(self, X):
        codes = np.empty((len(X), self.m), dtype=np.uint8)              # m bytes per vector
        for j, C in enumerate(self.codebooks):
            sub = X[:, j*self.ds:(j+1)*self.ds]
            codes[:, j] = np.argmin((C ** 2).sum(1)[None, :] - 2 * sub @ C.T, axis=1)
        return codes
    def adc_scores(self, q, codes):
        # lookup table: query sub-vector . every centroid, shape (m, 256)
        T = np.stack([C @ q[j*self.ds:(j+1)*self.ds] for j, C in enumerate(self.codebooks)])
        return T[np.arange(self.m), codes].sum(axis=1)                  # approximate q . x for all x

for m in [8, 16, 32]:
    pq = PQ(m).fit(X)
    codes = pq.encode(X)
    found, found_rr = [], []
    for q in Q[:200]:
        approx = pq.adc_scores(q, codes)
        found.append(np.argsort(-approx)[:k])
        cand = np.argsort(-approx)[:100]                                # re-rank top 100 exactly
        found_rr.append(cand[np.argsort(-(X[cand] @ q))[:k]])
    print(f"m={m:<3} bytes/vector={m:<3} (vs {X.shape[1] * 4} float32)  "
          f"recall@10={ann_recall(found, exact[:200]):.3f}  with re-rank: {ann_recall(found_rr, exact[:200]):.3f}")
```

Expected pattern: PQ alone has modest recall@10 that improves with m, and re-ranking 100 candidates with full vectors recovers most of it (with m = 32, close to 1). This is why compressed indexes nearly always re-rank.

### Lab 4. FAISS indexes on a recall-speed curve

```python
d = X.shape[1]
nlist = int(4 * np.sqrt(len(X)))

def bench(index, name, setter=None, values=(None,)):
    for v in values:
        if setter: setter(v)
        t0 = time.perf_counter()
        _, I = index.search(Q, k)
        dt = time.perf_counter() - t0
        print(f"{name:<16} {str(v):<5} recall@10={ann_recall(I, exact):.3f}  QPS={len(Q) / dt:,.0f}")

flat = faiss.IndexFlatIP(d); flat.add(X)
bench(flat, "Flat (exact)")

quant1 = faiss.IndexFlatIP(d)                     # keep a Python reference to the quantiser
ivf_f = faiss.IndexIVFFlat(quant1, d, nlist, faiss.METRIC_INNER_PRODUCT)
ivf_f.train(X); ivf_f.add(X)
bench(ivf_f, "IVF-Flat nprobe", lambda v: setattr(ivf_f, "nprobe", v), [1, 4, 16, 64])

quant2 = faiss.IndexFlatIP(d)
ivfpq = faiss.IndexIVFPQ(quant2, d, nlist, 16, 8, faiss.METRIC_INNER_PRODUCT)   # m=16, 8 bits
ivfpq.train(X)
refined = faiss.IndexRefineFlat(ivfpq)            # stores full vectors for re-ranking
refined.add(X)
ivfpq.nprobe = 16
bench(refined, "IVF-PQ k_factor", lambda v: setattr(refined, "k_factor", v), [1, 4, 10, 30])

hnsw = faiss.IndexHNSWFlat(d, 32, faiss.METRIC_INNER_PRODUCT)   # M = 32
hnsw.hnsw.efConstruction = 200
t0 = time.perf_counter(); hnsw.add(X); print(f"HNSW build: {time.perf_counter() - t0:.1f} s")
bench(hnsw, "HNSW efSearch", lambda v: setattr(hnsw.hnsw, "efSearch", v), [16, 32, 64, 128, 256])
```

What to look for:

- **Flat** has recall 1.0 and the lowest throughput; it is the ground truth.
- **IVF-Flat** gains one to two orders of magnitude in throughput; recall rises with nprobe as throughput falls.
- **IVF-PQ** without re-ranking (k\_factor = 1) has low recall because 16-byte codes are coarse; re-ranking 10 to 30 times k candidates brings recall close to 1 while keeping most of the speed. Its memory for codes is 16 bytes per vector instead of 512.
- **HNSW** reaches high recall at high throughput with no training step, but takes the longest to build and keeps full vectors plus links in memory.

Optionally plot recall (x-axis) against QPS (y-axis, log scale) for each family: these are the Pareto curves of Chapter 2.

### Lab 5. Hybrid search on SciFact

```python
bge = SentenceTransformer("BAAI/bge-small-en-v1.5", device=DEVICE)
PREFIX = "Represent this sentence for searching relevant passages: "
E = np.asarray(bge.encode(doc_texts, normalize_embeddings=True, batch_size=64), dtype=np.float32)
Qv = np.asarray(bge.encode(query_texts, prompt=PREFIX, normalize_embeddings=True), dtype=np.float32)
S_dense = Qv @ E.T

def rrf(score_matrices, k=60, depth=100, weights=None):
    n_q, n_d = score_matrices[0].shape
    fused = np.zeros((n_q, n_d))
    for w, S in zip(weights or [1.0] * len(score_matrices), score_matrices):
        for i in range(n_q):
            top = np.argsort(-S[i])[:depth]
            fused[i, top] += w / (k + np.arange(1, len(top) + 1))    # ranks 1..depth
    return fused

def minmax_fusion(S_a, S_b, alpha):
    def mm(S):
        lo, hi = S.min(axis=1, keepdims=True), S.max(axis=1, keepdims=True)
        return (S - lo) / np.maximum(hi - lo, 1e-9)                   # per-query normalisation
    return alpha * mm(S_a) + (1 - alpha) * mm(S_b)

print("BM25         ", ir_metrics(S_bm25))
print("Dense        ", ir_metrics(S_dense))
print("RRF (k=60)   ", ir_metrics(rrf([S_dense, S_bm25])))
for alpha in [0.3, 0.5, 0.7]:
    print(f"min-max a={alpha}", ir_metrics(minmax_fusion(S_dense, S_bm25, alpha)))
```

Compare the fused rows with each retriever alone. On many corpora RRF beats both components without any tuning; min-max fusion can do slightly better or worse depending on α, which is exactly why α must be tuned on held-out queries rather than on the test set. If one retriever is much weaker on a dataset, fusion gains shrink: always measure.

### Lab 6. Filtered search in a vector database

Qdrant can run in-process with `":memory:"`, which is ideal for learning its API. Index the Part 1 Nimbus chunks with permission metadata, then query with a filter:

```python
from ragkit import CORPUS, split_sentences, chunk_document
from qdrant_client import QdrantClient, models

chunks = [c for doc in CORPUS for c in chunk_document(doc)]
ACL = {"prod-nx7-errors": ["support", "engineering"], "eng-oncall": ["engineering"]}
vecs = bge.encode([f"{c['title']}\n{c['text']}" for c in chunks], normalize_embeddings=True)

client = QdrantClient(":memory:")
client.create_collection("nimbus", vectors_config=models.VectorParams(
    size=vecs.shape[1], distance=models.Distance.COSINE))
client.upsert("nimbus", points=[
    models.PointStruct(id=i, vector=vecs[i].tolist(),
                       payload={"chunk_id": c["chunk_id"],
                                "allowed_groups": ACL.get(c["doc_id"], ["all"])})
    for i, c in enumerate(chunks)])

def search(question, user_groups, limit=3):
    q = bge.encode(PREFIX + question, normalize_embeddings=True).tolist()
    allowed = models.Filter(must=[models.FieldCondition(
        key="allowed_groups", match=models.MatchAny(any=list(user_groups) + ["all"]))])
    hits = client.query_points("nimbus", query=q, query_filter=allowed, limit=limit).points
    return [(h.payload["chunk_id"], round(h.score, 3)) for h in hits]

print(search("How fast must I respond to a SEV-1 page?", ["sales"]))        # no eng-oncall chunks
print(search("How fast must I respond to a SEV-1 page?", ["engineering"]))  # eng-oncall first
```

In a server deployment you would also create a **payload index** on `allowed_groups` (`client.create_payload_index`) so the engine can plan filtered searches efficiently. The filter is built from the caller's groups inside your service, never from model output, as Chapter 4.4 requires.

## Interview questions with model answers

These 24 questions cover lexical search, ANN algorithms, production indexing and hybrid search. Several are classic whiteboard prompts ("explain HNSW", "design filtered search"); practise drawing while you talk.

### Lexical search

**Q1. Write BM25 and explain each part.** BM25(q, d) = Σ\_{t∈q} IDF(t) · f(t,d)(k₁+1) / (f(t,d) + k₁(1 − b + b|d|/avgdl)). IDF rewards rare terms; the fraction saturates term frequency (towards k₁ + 1) so repeated words add diminishing evidence; b normalises by document length relative to the average. Defaults k₁ ≈ 1.2, b = 0.75.

**Q2. Where does the IDF in BM25 come from?** From the Robertson–Spärck Jones relevance weight in the binary independence model: with no relevance information it reduces to log((N − n\_t + 0.5)/(n\_t + 0.5)). Lucene adds 1 inside the log to keep it positive for very common terms.

**Q3. What do k₁ and b control, and what happens at their extremes?** k₁ = 0 makes BM25 ignore term frequency (presence only); large k₁ approaches raw term frequency. b = 0 disables length normalisation; b = 1 fully normalises by length. Tuning helps a little; analyzers usually matter more.

**Q4. Why is keyword search fast on huge corpora?** The inverted index stores postings per term, so a query touches only documents containing its terms, and top-k pruning (WAND, Block-Max WAND) skips documents that cannot enter the top k.

**Q5. Why would a RAG system still use BM25 in 2026?** No training or GPU; strong on exact identifiers, names, codes and rare terms; explainable; robust across domains; and complementary to dense retrieval, so hybrid search usually beats either alone.

### Approximate nearest neighbours

**Q6. Distinguish ANN recall from retrieval recall.** ANN recall@k is the overlap between the index's top k and exact search's top k: index fidelity. Retrieval recall@k is the fraction of labelled relevant documents found: relevance. A perfect index over a poor embedding model has ANN recall 1 and bad retrieval recall.

**Q7. Explain IVF and its main knob.** k-means partitions vectors into nlist clusters with inverted lists. A query compares against the centroids, searches the nprobe nearest lists exactly, and returns the best k. nprobe trades recall for speed; neighbours across cluster boundaries are the main source of misses. A common heuristic is nlist ≈ 4√N to 16√N.

**Q8. Why is nlist ≈ √N a natural choice?** Cost per query ≈ nlist·d (centroids) + nprobe·(N/nlist)·d (list scan). With nprobe = 1, minimising nlist + N/nlist gives nlist = √N, balancing the two terms.

**Q9. Explain product quantisation and asymmetric distance computation.** Split vectors into m sub-vectors, learn 256 centroids per sub-space, and store each vector as m one-byte codes. For a query, precompute an m × 256 table of distances (or dot products) between query sub-vectors and centroids; each database vector's distance is then m table lookups and additions. The query is not quantised, which is what makes it asymmetric and more accurate.

**Q10. Why do PQ-based indexes re-rank?** PQ distances are approximate, so the true top k is often ranked a little lower. Retrieving a multiple of k (for example 10× to 30×) and re-scoring with full vectors restores recall at small cost.

**Q11. Explain HNSW.** A multi-layer proximity graph. Every vector is on layer 0; each is promoted to higher layers with geometrically decreasing probability, creating long-range highways. Search starts at the top entry point, greedily descends layer by layer, then runs a beam search of width efSearch on layer 0. Insertion runs a similar search with efConstruction and links each node to M diverse neighbours. Search cost grows roughly logarithmically with N.

**Q12. What are HNSW's parameters and trade-offs?** M (links per node): recall and memory. efConstruction: graph quality and build time. efSearch: query-time recall versus latency (must be at least k). Weaknesses: full vectors in RAM, slow builds, tombstoned deletes degrade quality, restrictive filters break connectivity.

**Q13. When would you choose IVF-PQ or DiskANN over HNSW?** When the data does not fit in RAM: hundreds of millions to billions of vectors. IVF-PQ compresses vectors to tens of bytes; DiskANN keeps the graph and full vectors on SSD with compressed vectors in RAM. Both re-rank with full precision.

**Q14. How would you benchmark a vector index?** Compute exact top-k ground truth for a representative query set; sweep the index's knobs; report ANN recall@k, p50/p95/p99 latency at target load, QPS, memory per vector and build or update time; compare Pareto curves; then confirm end-to-end relevance (nDCG, recall against labels) on the chosen setting.

### Production indexing

**Q15. A filter matches 0.1% of documents and users get fewer than k results. Why, and how do you fix it?** Post-filtering returns about s·k′ results, so with s = 0.001 you need k′ ≈ 1,000k candidates. Fixes: pre-filter and search the allowed set exactly when it is small; use an engine with filter-aware graph search or cardinality-based planning; use iterative scans; partition by the filter key if it is stable (tenant, language).

**Q16. How do deletes affect an HNSW index?** Deleted nodes are usually tombstoned: still traversed but never returned. As they accumulate, search wastes work and recall falls. Engines repair or compact the graph in the background, or you rebuild periodically.

**Q17. Document-sharding versus tenant-sharding?** Document sharding spreads every collection across shards; queries scatter to all shards and gather top-k, so tail latency follows the slowest shard. Tenant sharding routes each query to one shard, which is efficient but can produce hot shards for large tenants.

**Q18. How do you design multi-tenant vector search safely?** Choose index-per-tenant for strong isolation and few large tenants, shared index with a tenant filter for many small tenants, or engine partitions in between. Always derive the tenant and permission filters server-side from the authenticated identity, index those fields, and test for cross-tenant leaks and filtered recall for the smallest tenants.

**Q19. How do you change embedding models or index parameters without downtime?** Blue-green indexing: build a new collection in parallel, evaluate offline, shadow or A/B test, then switch an alias; keep the old collection for rollback. Record model revision, chunker version and index parameters with each collection.

**Q20. How do you choose a vector database?** Start from constraints: existing stack, vector count and memory model, filtering selectivity, need for BM25 or sparse vectors, multi-tenancy and security, write and freshness pattern, operations capacity and licence. A defensible default: pgvector when already on PostgreSQL at moderate scale; a dedicated engine (Qdrant, Milvus, Weaviate) or a search engine (Elasticsearch, OpenSearch, Vespa) for larger scale or richer search; managed services when no one can operate infrastructure.

### Hybrid search

**Q21. Why not just add BM25 and cosine scores?** They are on incompatible scales that vary per query, so the larger scale dominates. You must normalise per query (min-max, z-score, distribution-based) and tune a weight, or use rank-based fusion.

**Q22. Write reciprocal rank fusion and explain k.** RRF(d) = Σ\_r 1/(k + rank\_r(d)), summing over retrievers, with 0 for documents absent from a list. k (60 by default) damps the top ranks, so agreement between retrievers beats a single first place. It needs no score calibration, which makes it a robust default.

**Q23. When can hybrid search fail to help?** When one retriever is much weaker on the corpus, fusion can dilute the stronger one; when candidate depth is too shallow; or when the bottleneck is elsewhere (chunking, reranking, generation). Always compare the fused system with each component on an evaluation set.

**Q24. Where does a reranker fit relative to hybrid search?** After fusion: retrieve 50 to 100 candidates from each retriever, fuse with RRF, rerank the top 20 to 100 with a cross-encoder or LLM reranker, and put the top 3 to 10 in the prompt.

## Exercises with solutions

Twelve exercises: six mathematical, four coding, one debugging and one design. Coding exercises reuse the Chapter 7 lab variables.

### Exercise 1. BM25 by hand

A corpus has N = 500 documents with avgdl = 100; use k₁ = 1.2 and b = 0.75. The query is "battery overheat". "battery" occurs in 50 documents and "overheat" in 5. Document A has 80 words with "battery" twice and "overheat" once. Document B has 200 words with "battery" six times and no "overheat". Which ranks higher?

**Solution.** IDF(battery) = ln(1 + 450.5/50.5) = 2.2946; IDF(overheat) = ln(1 + 495.5/5.5) = 4.5119.

Document A: length factor 1 − 0.75 + 0.75 × 0.8 = 0.85, so k₁ × 0.85 = 1.02. TF part for battery = 2 × 2.2 / (2 + 1.02) = 1.457; for overheat = 2.2 / 2.02 = 1.089. Score = 2.2946 × 1.457 + 4.5119 × 1.089 = 8.257.

Document B: length factor 1.75, so k₁ × 1.75 = 2.1. TF part for battery = 6 × 2.2 / 8.1 = 1.630. Score = 2.2946 × 1.630 = 3.739.

A wins clearly: it contains the rare term, it is shorter, and B's six repetitions of a common term saturate.

### Exercise 2. BM25 limits

(a) Show that the term-frequency part approaches k₁ + 1 as f → ∞. (b) What does BM25 reduce to when k₁ = 0? (c) With b = 1, show that a document that is the original document repeated twice gets the same term-frequency part as the original.

**Solution.** (a) f(k₁+1)/(f + c) → k₁ + 1 as f → ∞ for any fixed c ≥ 0. (b) The TF part becomes f/f = 1 for any f > 0, so BM25 = sum of IDFs of query terms present: a weighted Boolean match. (c) With b = 1 the denominator is f + k₁|d|/avgdl. Doubling the document doubles both f and |d|: 2f(k₁+1)/(2f + 2k₁|d|/avgdl) = f(k₁+1)/(f + k₁|d|/avgdl), the same value. Full length normalisation makes BM25 depend on term density rather than raw counts.

### Exercise 3. Size an IVF index

Show that if every query probes nprobe lists, the per-query cost nlist·d + nprobe·(N/nlist)·d is minimised at nlist = √(nprobe·N). Evaluate it for N = 10 million and nprobe = 16, and give the fraction of vectors scanned.

**Solution.** Minimise f(L) = L + nprobe·N/L (dropping the common factor d). f′(L) = 1 − nprobe·N/L² = 0 gives L = √(nprobe·N). For N = 10⁷ and nprobe = 16: L = √(1.6 × 10⁸) ≈ 12,650 lists. Each list holds about 790 vectors, so a query scans about 16 × 790 ≈ 12,650 vectors plus 12,650 centroids, about 0.25% of the data. This is consistent with FAISS's 4√N to 16√N guideline (12,650 to 50,600 for 10 million).

### Exercise 4. Product quantisation budget

For 100 million 1,024-dimensional vectors encoded with PQ using m = 64 sub-quantisers of 256 centroids each, compute: code memory; codebook memory; the size of the per-query lookup table in float32; and the arithmetic per vector compared with an exact float32 dot product.

**Solution.** Codes: 64 bytes per vector × 10⁸ = 6.4 GB (versus 409.6 GB for float32). Codebooks: 64 sub-spaces × 256 centroids × 16 dims × 4 bytes = 256 × 1,024 × 4 = 1 MB, negligible. Lookup table: 64 × 256 × 4 bytes = 64 KB per query, small enough to stay in CPU cache. Per vector: 64 table lookups and additions instead of 1,024 multiply-adds, plus far less memory traffic, which is what really makes PQ fast.

### Exercise 5. HNSW layers and link memory

In HNSW, a node reaches layer l or above with probability M^(−l). For N = 100 million and M = 16: (a) estimate the number of layers; (b) estimate link memory per node if layer 0 stores up to 2M neighbour ids and each upper layer up to M, with 4-byte ids; (c) compare with the memory of 768-dimensional float32 vectors.

**Solution.** (a) The top layer is where about one node remains: N·M^(−L) ≈ 1, so L ≈ log\_M N = ln(10⁸)/ln(16) ≈ 6.6, about 7 layers. (b) Layer 0: 2 × 16 × 4 = 128 bytes. Upper layers, in expectation: Σ\_{l≥1} M^(−l) × M × 4 = 4M/(M − 1) ≈ 4.3 bytes. Total about 132 bytes per node, about 13 GB for 10⁸ nodes. (c) Vectors: 768 × 4 = 3,072 bytes per node, about 307 GB. The graph is cheap; the vectors dominate, which is why quantising them (or moving them to SSD, as DiskANN does) matters at scale.

### Exercise 6. How deep must post-filtering go?

A filter passes s = 2% of documents and you need k = 10 results. (a) If the ANN index returns k′ = 100 candidates and passing is independent of rank, what is the expected number of survivors, and roughly how likely is it to get all 10? (b) How large must k′ be to get at least 10 survivors with 95% probability?

**Solution.** (a) Survivors follow a Binomial(100, 0.02) distribution with mean 2. The probability of at least 10 is about 3 × 10⁻⁵: practically never. (b) Solve P(Binomial(k′, 0.02) ≥ 10) ≥ 0.95 numerically:

```python
from scipy.stats import binom
next(n for n in range(10, 5000) if binom.sf(9, n, 0.02) >= 0.95)   # 790
```

k′ ≈ 790, well above the naive k/s = 500, because you need a safety margin. In reality relevant-looking documents and filter values are often correlated, which can make things better or much worse. The lesson: post-filtering does not scale to selective filters.

### Exercise 7. RRF with three retrievers

BM25 ranks D, A, B. A dense model ranks A, C, D. A learned sparse model ranks A, D, E. Compute RRF with k = 60 and give the fused order.

**Solution.** A: 1/62 + 1/61 + 1/61 = 0.04892. D: 1/61 + 1/63 + 1/62 = 0.04839. B: 1/63 = 0.01587. C: 1/62 = 0.01613. E: 1/63 = 0.01587. Fused order: A, D, C, then B and E tied. A wins because all three retrievers rank it highly, even though BM25 put D first.

### Exercise 8 (coding, ML track). Why HNSW needs long-range links

Build an exact 16-nearest-neighbour graph over 20,000 of the synthetic vectors, run the beam search of Chapter 3.3 from a random entry point, and measure ANN recall@10 for several ef values. Then add a few random long-range edges per node and repeat. Explain the difference.

**Solution.**

```python
import heapq
Xs, Qs = make_data(n=20_000, n_queries=200)
exact_s = np.argsort(-(Qs @ Xs.T), axis=1)[:, :k]

def build_knn_graph(X, degree=16, batch=2000):
    nbrs = [set() for _ in range(len(X))]
    for s in range(0, len(X), batch):
        S = X[s:s + batch] @ X.T
        np.fill_diagonal(S[:, s:s + batch], -np.inf)          # no self-loops
        top = np.argpartition(-S, degree, axis=1)[:, :degree]
        for i, row in enumerate(top):
            for j in row:
                nbrs[s + i].add(int(j)); nbrs[int(j)].add(s + i)  # undirected
    return [np.fromiter(n, dtype=np.int64) for n in nbrs]

def add_long_range_links(graph, n_random=4, seed=0):
    rng = np.random.default_rng(seed)
    g = [set(map(int, nb)) for nb in graph]
    for i in range(len(g)):
        for j in rng.integers(0, len(g), size=n_random):
            if j != i:
                g[i].add(int(j)); g[int(j)].add(i)
    return [np.fromiter(nb, dtype=np.int64) for nb in g]

def beam_search(q, X, graph, entry, ef, k):
    d0 = -float(X[entry] @ q)                       # distance = negative similarity
    visited, candidates, results = {entry}, [(d0, entry)], [(-d0, entry)]
    n_dist = 1
    while candidates:
        d_c, c = heapq.heappop(candidates)          # closest unexpanded candidate
        if d_c > -results[0][0]:                    # worse than the furthest kept result
            break
        new = [n for n in graph[c] if n not in visited]
        visited.update(new)
        if not new:
            continue
        n_dist += len(new)
        for d_n, n in zip(-(X[new] @ q), new):
            if len(results) < ef or d_n < -results[0][0]:
                heapq.heappush(candidates, (float(d_n), int(n)))
                heapq.heappush(results, (-float(d_n), int(n)))
                if len(results) > ef:
                    heapq.heappop(results)           # drop the furthest
    return [n for _, n in sorted((-nd, n) for nd, n in results)[:k]], n_dist

entry = int(np.random.default_rng(0).integers(len(Xs)))
for name, g in [("k-NN graph", build_knn_graph(Xs))]:
    g_sw = add_long_range_links(g)
    for gname, graph in [(name, g), ("+ long-range links", g_sw)]:
        for ef in [10, 50, 100]:
            out = [beam_search(q, Xs, graph, entry, ef, k) for q in Qs]
            print(f"{gname:<20} ef={ef:<4} recall@10={ann_recall([o[0] for o in out], exact_s):.3f} "
                  f"distances/query={np.mean([o[1] for o in out]):,.0f}")
```

On this clustered data the pure k-NN graph gives recall near 0 whatever ef is, after only a few dozen distance computations: every node's neighbours lie in its own cluster, so the graph is disconnected between clusters and a search that starts in the wrong cluster can never leave. Adding a few random long-range edges makes the graph a navigable small world: recall then rises steadily with ef (to roughly 0.8 at ef = 100 in our run) while still computing only a few percent of all distances. HNSW gets these long-range links systematically from its upper layers and from its diversity-preferring neighbour selection, which is why it does much better than this toy.

### Exercise 9 (coding). Tune fusion without cheating

In Lab 5 you tried several α values on the full SciFact test set and could pick the best, which overstates real performance. Split the queries into a development half and a test half, choose α on development, and report test results for BM25, dense, RRF and the tuned min-max fusion.

**Solution.**

```python
rng = np.random.default_rng(0)
perm = rng.permutation(len(query_ids))
dev, test = perm[: len(perm) // 2], perm[len(perm) // 2:]

def metrics_on(S, rows):
    global query_ids
    saved = query_ids
    query_ids = [saved[i] for i in rows]          # ir_metrics reads query_ids
    try:
        return ir_metrics(S[rows])
    finally:
        query_ids = saved

alphas = np.linspace(0, 1, 11)
best_alpha = max(alphas, key=lambda a: metrics_on(minmax_fusion(S_dense, S_bm25, a), dev)["nDCG@10"])
print("chosen alpha:", best_alpha)
for name, S in [("BM25", S_bm25), ("Dense", S_dense), ("RRF", rrf([S_dense, S_bm25])),
                (f"min-max a={best_alpha:.1f}", minmax_fusion(S_dense, S_bm25, best_alpha))]:
    print(f"{name:<14} test:", metrics_on(S, test))
```

The tuned fusion's test score is the honest estimate. With only 150 test queries, differences of about one nDCG point are within noise; Part 6 shows how to compute confidence intervals with the bootstrap. RRF needs no tuning at all, which is a real advantage when labelled queries are scarce.

### Exercise 10 (coding). Measure the post-filtering failure

On 20,000 synthetic vectors, give each vector a random attribute that passes a filter with probability s = 1%. Compare post-filtering an HNSW search at k′ = 10, 100 and 1,000 with exact pre-filtering, reporting the average number of results and recall against filtered exact search.

**Solution.**

```python
rng = np.random.default_rng(0)
s = 0.01
allowed = rng.random(len(Xs)) < s
exact_f = np.argsort(-np.where(allowed[None, :], Qs @ Xs.T, -np.inf), axis=1)[:, :k]

hnsw_s = faiss.IndexHNSWFlat(Xs.shape[1], 32, faiss.METRIC_INNER_PRODUCT)
hnsw_s.hnsw.efConstruction = 100
hnsw_s.add(Xs)
for kp in [10, 100, 1000]:
    hnsw_s.hnsw.efSearch = max(kp, 64)
    _, I = hnsw_s.search(Qs, kp)
    kept = [[j for j in row if j >= 0 and allowed[j]][:k] for row in I]
    print(f"post-filter k'={kp:<5} avg results={np.mean([len(r) for r in kept]):.1f} "
          f"recall={ann_recall(kept, exact_f):.3f}")

ids = np.where(allowed)[0]                         # about 200 allowed vectors
pre = ids[np.argsort(-(Qs @ Xs[ids].T), axis=1)[:, :k]]
print(f"pre-filter exact over {len(ids)} vectors: recall={ann_recall(pre, exact_f):.3f}")
```

In our run post-filtering returned on average about 0.1 results at k′ = 10, about 1 at k′ = 100 and about 8.5 at k′ = 1,000, matching the s·k′ estimate, while exact pre-filtering over the roughly 200 allowed vectors returned all 10 with recall 1.0 at trivial cost. When a filter is that selective, brute force over the allowed set is both correct and fast; engines with cost-based planners make exactly this choice automatically.

### Exercise 11 (debugging). Three production incidents

Diagnose each and propose a fix. (a) After a month of heavy updates (many documents replaced daily), HNSW recall measured against exact search fell from 0.98 to 0.90 and latency rose 40%, with no configuration change. (b) A newly onboarded small tenant reports that search "finds nothing" although its documents are indexed; large tenants are fine. (c) p99 latency doubled after the cluster grew from 4 to 16 shards, while p50 barely changed.

**Solution.** (a) Tombstones from deletes and replacements: the graph still traverses deleted nodes and has lost good links. Run the engine's compaction or optimisation, or rebuild; schedule it based on the fraction of deleted points. (b) Shared index with post-filtering on tenant\_id: the tiny tenant's documents almost never appear among the unfiltered top candidates (Exercise 6). Use filter-aware search with a payload index, exact search for small allowed sets, or a separate partition or collection for that tenant. (c) Scatter-gather: every query now waits for the slowest of 16 shards, so tail latency grows with fan-out. Use fewer, larger shards, more replicas with hedged requests, route by tenant when possible, and investigate the slow shards (garbage collection, hot segments, uneven shard sizes).

### Exercise 12 (design). A two-billion-vector index

Design retrieval for 2 billion 768-dimensional chunks, 500 queries per second, a p95 latency budget of 50 ms for retrieval, about 10,000 tenants filtered on every query, and about 1% of documents changing per day. Estimate memory and justify the index.

**Solution (one good answer).**

- **Memory arithmetic.** float32 vectors: 2 × 10⁹ × 3,072 bytes ≈ 6.1 TB, too much RAM. float16: 3.1 TB. PQ with 96 bytes: 192 GB. Binary codes: 96 bytes, also 192 GB. So keep compressed codes in RAM and full vectors on SSD or object storage for re-ranking.
- **Index.** A DiskANN-style SSD graph or IVF-PQ with re-ranking, sharded across machines, for example 16 to 32 shards each holding 60 to 125 million vectors with replicas sized for 500 QPS plus headroom. Alternatively a managed service whose architecture matches these numbers.
- **Tenants.** With 10,000 tenants, shard or partition by tenant where possible, so most queries hit one shard and search only their tenant's data; this also fixes filtered-recall problems and isolation. Large tenants get their own shards; small tenants share partitions with filter-aware search or exact search over their few vectors.
- **Updates.** 1% per day is 20 million changes: use segment-based ingestion with background merges or a streaming-capable graph index, and schedule compaction to control tombstones. Track index freshness as a metric.
- **Hybrid.** Add a BM25 or learned-sparse index sharded the same way and fuse with RRF before reranking.
- **Validation.** Ground-truth exact search on a sampled subset to monitor ANN recall continuously; latency SLOs per shard; per-tenant leak tests; blue-green rebuilds for parameter or model changes.

## Summary, cheat sheet and references

The one-sentence summary of Part 3: **keep BM25 next to your vectors, start with exact search, move to an ANN index only when measurements demand it, tune it on a recall-versus-speed curve, and test it under your real filters, updates and tenants.**

### Ten things you should now be able to do

1. Derive and compute BM25, and explain k₁, b and IDF.
2. Explain why inverted indexes make keyword search fast, and why analyzers must match at index and query time.
3. Estimate exact-search latency from memory bandwidth and decide when exact search is enough.
4. Distinguish ANN recall from retrieval recall and benchmark an index properly.
5. Explain and size IVF (nlist, nprobe), PQ (m, codebooks, ADC) and HNSW (M, efConstruction, efSearch).
6. Explain when to use IVF-PQ or DiskANN instead of HNSW.
7. Diagnose and fix filtered-search failures, tombstone degradation and scatter-gather tail latency.
8. Choose a multi-tenancy pattern and enforce filters safely.
9. Choose a vector database from stated constraints.
10. Implement and evaluate RRF and score fusion without tuning on the test set.

### Cheat sheet

| Item | Formula or rule |
| --- | --- |
| BM25 | Σ IDF(t) · f(k₁+1) / (f + k₁(1 − b + b·\|d\|/avgdl)) |
| BM25 IDF (Lucene) | ln(1 + (N − n\_t + 0.5)/(n\_t + 0.5)) |
| Defaults | k₁ = 1.2, b = 0.75 |
| Exact search latency bound | N · d · bytes / memory bandwidth |
| ANN recall@k | \|ANN top-k ∩ exact top-k\| / k |
| IVF cost | nlist·d + nprobe·(N/nlist)·d; nlist ≈ 4√N to 16√N |
| PQ code size | m bytes (256 centroids per sub-space); ADC table m × 256 |
| HNSW levels | P(level ≥ l) = M^(−l); about log\_M N layers |
| HNSW knobs | M 16 to 64, efConstruction 100 to 500, efSearch ≥ k (64 to 512) |
| Post-filter depth | k′ ≈ k / selectivity, plus a margin |
| RRF | Σ 1/(60 + rank) over retrievers |
| Hybrid pipeline | BM25 + dense (50 to 100 each) → RRF → rerank → top 3 to 10 |
| Safe re-indexing | Blue-green build, evaluate, switch alias, keep rollback |

### References

- Robertson and Zaragoza (2009). The Probabilistic Relevance Framework: BM25 and Beyond. Foundations and Trends in Information Retrieval.
- Jégou, Douze and Schmid (2011). Product Quantization for Nearest Neighbor Search. IEEE TPAMI.
- Malkov and Yashunin (2016). [Efficient and Robust Approximate Nearest Neighbor Search Using Hierarchical Navigable Small World Graphs](https://arxiv.org/abs/1603.09320).
- Johnson, Douze and Jégou (2017). [Billion-Scale Similarity Search with GPUs](https://arxiv.org/abs/1702.08734); Douze et al. (2024). [The Faiss Library](https://arxiv.org/abs/2401.08281).
- Aumüller, Bernhardsson and Faithfull (2018). [ANN-Benchmarks](https://arxiv.org/abs/1807.05614).
- Subramanya et al. (2019). DiskANN: Fast Accurate Billion-Point Nearest Neighbor Search on a Single Node. NeurIPS 2019.
- Guo et al. (2020). [Accelerating Large-Scale Inference with Anisotropic Vector Quantization](https://arxiv.org/abs/1908.10396) (ScaNN).
- Thakur et al. (2021). [BEIR: A Heterogeneous Benchmark for Zero-shot Evaluation of Information Retrieval Models](https://arxiv.org/abs/2104.08663).
- Cormack, Clarke and Büttcher (2009). Reciprocal Rank Fusion Outperforms Condorcet and Individual Rank Learning Methods. SIGIR 2009.
- Patel et al. (2024). [ACORN: Performant and Predicate-Agnostic Search Over Vector Embeddings and Structured Data](https://arxiv.org/abs/2403.04871).

### Coming in Part 4: Ingestion and chunking

Part 4 moves upstream to the data. You will parse PDFs, tables, HTML and scanned documents; compare fixed, recursive, structure-aware and semantic chunking; attach metadata; implement parent-child retrieval, contextual retrieval and late chunking; handle deduplication, versioning and incremental re-indexing; and measure every choice with the evaluation tools from Parts 1 to 3.
