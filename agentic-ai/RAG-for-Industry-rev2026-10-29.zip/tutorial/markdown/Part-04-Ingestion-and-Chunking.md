# RAG for Industry, Part 4: Ingestion and Chunking

Oct 28, 2026 · @Behi · revised 29 October 2026 (see CHANGELOG.md)

## How Part 4 fits

Ingestion decides what the retriever can ever find. If a table was flattened into nonsense, a fact was split across two chunks, a chunk lost the context that says what "it" refers to, or yesterday's policy update never reached the index, no embedding model, reranker or prompt can recover. In industry, a large share of RAG quality work is ingestion work, and it is under-taught.

**After this part you will be able to:**

1. Design an ingestion pipeline with connectors, parsing, cleaning, enrichment, chunking, embedding and indexing, and choose between full and incremental sync.
2. Choose a parser for PDFs, scanned pages, tables, HTML and Office documents, and know how each fails.
3. Deduplicate, clean and filter content, and handle personal data.
4. Implement fixed, recursive, structure-aware and semantic chunking, and pick a strategy and size by measurement.
5. Make chunks self-explanatory with metadata, contextual retrieval and late chunking, and use parent-child retrieval to return more context than you index.
6. Keep an index correct as documents change, get deleted or change permissions.

**Setup.** The same free Colab or Kaggle T4 notebook. Install the PDF tools used in the lab:

```python
!pip install -q -U "sentence-transformers>=6.0,<7" "transformers>=5.0,<6" pypdf pymupdf pdfplumber reportlab pandas
```

The lab builds a long-document benchmark from SciFact (loaded as in Parts 2 and 3) so that you can measure how chunking changes retrieval, and uses the Nimbus Robotics corpus from Part 1 for the incremental-indexing exercise.

**Track notes.** This part is core for application engineers, who own ingestion pipelines in most teams. ML-track readers should focus on Chapters 4 and 5 and the evaluation method in the lab, which is how chunking choices are justified.

## Chapter 1. The ingestion pipeline

A production ingestion pipeline is a data pipeline: it pulls documents from source systems, converts them to clean structured text, splits and enriches them, embeds them, and writes them to one or more indexes, then keeps doing this as sources change. Design it so that each stage's output is stored and versioned, because you will re-run later stages many times.

![Ingestion pipeline: eight stages with versioned stores beside them](../diagrams/p04_ingestion_pipeline.svg)

*Ingestion pipeline: eight stages with versioned stores beside them*

Changes flow in at the top as events; because parsed documents, chunks and embeddings are stored, a new chunker or embedding model replays only the stages below the store it starts from.

### 1.1 Stages and their jobs

| Stage | Job | Typical output | Common failure |
| --- | --- | --- | --- |
| Connect | Fetch documents and their metadata and permissions from source systems | Raw files plus source id, URL, timestamps, ACL | Missing permissions; API rate limits; partial syncs |
| Parse | Turn files into text with structure (headings, lists, tables, pages) | Markdown or JSON elements | Lost tables, merged columns, no text in scans |
| Clean | Remove boilerplate, fix encoding, normalise whitespace, detect language | Clean structured text | Repeated headers and footers in every chunk |
| Deduplicate and filter | Drop exact and near duplicates, empty or low-quality pages, sensitive content | Fewer, better documents | Old and new versions both indexed |
| Chunk | Split into retrievable units on natural boundaries | Chunks with positions | Facts split across chunks; chunks without context |
| Enrich | Add metadata, context, summaries, questions | Chunks ready to embed | Missing dates or versions for filtering |
| Embed | Compute dense and sparse vectors | Vectors | Truncation, wrong prefixes (Part 2) |
| Index | Upsert into vector and keyword indexes with metadata | Searchable collection | Stale or orphaned chunks after updates |

### 1.2 Store every intermediate

Keep the raw file, the parsed document and the chunks, each with a version. Then a new chunking strategy needs no re-parsing, a new embedding model needs no re-chunking, and a parser bug can be fixed and replayed for the affected documents only. Parsing complex PDFs can be the slowest and most expensive step, so you do not want to repeat it casually.

### 1.3 Connectors and permissions

Enterprise RAG pulls from file stores (SharePoint, Google Drive, S3), wikis (Confluence, Notion), ticketing and CRM (Jira, Zendesk, Salesforce), chat (Slack, Teams), email, databases and websites. For each source you need content, metadata (title, author, created and modified dates, URL) and **access control lists**. Permissions must be captured at ingestion and kept in sync, so that retrieval can filter by the user's identity (Part 3, Chapter 4). A connector that ignores permissions turns your assistant into a data-leak tool.

### 1.4 Sync patterns

- **Full rebuild**: re-ingest everything on a schedule. Simple and self-healing, but slow and expensive for large corpora; fine for small or static collections.
- **Incremental polling**: ask each source for items modified since the last run and process only those, plus a periodic check for deletions.
- **Event-driven**: webhooks or change-data-capture streams push create, update, delete and permission-change events into a queue; workers process them within seconds or minutes.

Most production systems combine event-driven or incremental updates with an occasional full reconciliation to catch missed events. Chapter 6 covers the mechanics.

### 1.5 Engineering the pipeline

- Run stages as **idempotent** jobs keyed by document id and content hash, so retries and replays never create duplicates.
- Put a **queue** between stages, with retries and a dead-letter queue for documents that keep failing (corrupt files, password-protected PDFs).
- Make embedding a **batch** job that saturates the GPU or respects API rate limits.
- **Monitor** counts per stage (documents fetched, parsed, failed, chunks produced, vectors written), parse error rates by file type, and index freshness (time from source change to searchable).

## Chapter 2. Parsing documents

Parsing converts files into clean text that keeps the document's structure: headings, paragraphs in reading order, lists, tables and captions. The right parser depends on the file: cheap text extraction is enough for simple born-digital files, while complex layouts, tables and scans need layout models, OCR or vision-language models.

### 2.1 Why PDFs are hard

A PDF is a set of drawing instructions: "place these glyphs at these coordinates on page 3". It usually has no notion of paragraphs, columns, reading order or tables. Parsers must reconstruct them, and common failures follow from that:

- **Reading order**: two-column papers come out interleaved line by line.
- **Running headers, footers and page numbers** repeat inside the text, polluting every chunk.
- **Hyphenation and ligatures**: "retrie-" / "val" across lines, or "ﬁ" as one glyph.
- **Tables** become runs of numbers with no column headers attached.
- **Fonts without a Unicode mapping** extract as gibberish.
- **Scanned pages** have no text layer at all, only images, so text extraction returns nothing and you need OCR.

A cheap detector for the last case: count extracted characters per page; pages with almost none but with a large image likely need OCR.

### 2.2 Three families of parsers

| Family | Examples (October 2026) | Strengths | Weaknesses |
| --- | --- | --- | --- |
| Text-layer extraction | pypdf, PyMuPDF (and PyMuPDF4LLM for Markdown output), pdfplumber, pdfminer.six | Very fast and cheap, deterministic, runs anywhere | No OCR; weak on columns and tables; little structure |
| Layout-model pipelines | Docling (IBM, open source, also offers the small Granite-Docling vision model), MinerU, Marker, Unstructured | Detect layout regions, reading order, tables and formulas; output Markdown or JSON; OCR when needed | Slower; GPU helps; quality varies by document type |
| Vision-language models and document AI services | Open models such as olmOCR, PaddleOCR-VL, DeepSeek-OCR, dots.ocr; services such as Mistral OCR, LlamaParse, Reducto, AWS Textract, Azure AI Document Intelligence, Google Document AI, and general multimodal LLMs | Best on scans, complex layouts, handwriting and tables; one model per page | Cost per page; GPU or API needed; a generative model can drop, reorder or invent text |

Two cautions. First, the tools above change versions, licences and rankings often (for example, MinerU's licence has changed over time), so check the current licence before shipping. Second, vision-language parsers are generative: on rare pages they may silently "correct" numbers or hallucinate content, which is unacceptable for contracts or financial reports unless you verify against the text layer.

Public benchmarks such as OmniDocBench and olmOCR-Bench compare parsers on text, tables, formulas and reading order; use them to build a shortlist, then test on your own documents.

### 2.3 Tables

Tables are where naive parsing hurts most, because answers often live in one cell and are meaningless without row and column headers. Options, from simplest:

1. **Keep the table as Markdown or HTML** in its own chunk, with its caption and the section heading. Works for small tables.
2. **Linearise rows**: one line or chunk per row with headers repeated, for example "Model: NX-7; Payload: 150 kg; Battery: 8 h". Each row becomes independently retrievable.
3. **Summarise and link**: embed an LLM-written description of what the table contains, and return the full table when it is retrieved (multi-representation indexing, Chapter 5).
4. **Route to a structured store**: for spreadsheets and large tables, load them into a database and let the model query them with SQL (Part 1, Chapter 4). Embeddings are a poor tool for aggregations.

### 2.4 Other formats

- **HTML**: strip navigation, ads and cookie banners with a content extractor (for example trafilatura), and keep headings (h1 to h6) as structure.
- **Word documents**: libraries such as python-docx expose headings, paragraphs and tables directly, which is cleaner than converting to PDF first.
- **Slides**: treat each slide as a unit, include its title and speaker notes, and caption important images.
- **Email and chat**: remove quoted replies and signatures, keep thread structure and participants as metadata.
- **Source code**: split along functions and classes using a parser (for example tree-sitter), and keep file path and symbol names as metadata.
- **Images and figures**: generate captions with a vision model, or embed images directly with a multimodal embedding model (Part 8).

### 2.5 Choosing a parser

1. Sample 50 to 100 documents that represent your corpus, including the ugliest ones.
2. Run two or three candidate parsers and **look at the outputs side by side**. Most parser problems are obvious to a human in seconds.
3. Check the things your users ask about: tables, numbers, headings, footnotes.
4. Measure end-to-end retrieval on questions about those documents, not just parser benchmarks.
5. Consider **routing**: a fast text-layer parser for simple born-digital files, a layout pipeline for complex ones, and OCR or a VLM only for pages without usable text. Routing can cut parsing cost by an order of magnitude.

## Chapter 3. Cleaning, deduplication, personal data and quality

Clean, deduplicated input makes every later stage better and cheaper: duplicates waste prompt budget and crowd out other evidence, stale versions cause contradictory answers, and boilerplate dilutes embeddings. Personal data adds legal obligations that the pipeline must meet.

### 3.1 Normalisation and boilerplate

- **Unicode normalisation** (NFKC) folds ligatures and full-width characters; fix encoding errors.
- **Whitespace and line breaks**: join lines inside paragraphs, remove hyphenation at line ends ("retrie-\\nval" → "retrieval").
- **Repeated headers and footers**: a line that appears on most pages of a document (company name, "Confidential", page numbers) is almost certainly boilerplate. Detect it by frequency across pages and remove it.
- **Web boilerplate**: navigation, cookie notices and footers, handled by content extraction (Chapter 2.4).
- **Language detection**: tag each document's language (for example with fastText's language-identification model) for routing to the right analyzer and embedding model, and for filtering.

### 3.2 Exact and near-duplicate detection

**Exact duplicates**: hash the normalised text (for example SHA-256) and keep one copy. This also powers change detection in Chapter 6.

**Near duplicates** (the same policy with a new date, a forwarded email, a page copied into two wikis) need similarity. The standard tool is **MinHash**. Represent each document as a set of shingles (for example all 5-word sequences). The Jaccard similarity of two sets is J(A, B) = |A ∩ B| / |A ∪ B|. For a random hash function h, the probability that the minimum hash over A equals the minimum over B is exactly J(A, B), so the fraction of agreeing minimums over n hash functions estimates J.

Comparing every pair is quadratic, so **locality-sensitive hashing (LSH)** splits the n minhashes into b bands of r rows and only compares documents that agree on all rows of at least one band. Two documents with Jaccard similarity s become candidates with probability:

```latex
P(\text{candidate}) = 1 - \left(1 - s^{r}\right)^{b}, \qquad \text{threshold} \approx \left(\tfrac{1}{b}\right)^{1/r}
```

| Bands b × rows r (n = 128) | Threshold | s = 0.3 | s = 0.5 | s = 0.7 | s = 0.8 | s = 0.9 |
| --- | --- | --- | --- | --- | --- | --- |
| 16 × 8 | 0.71 | 0.001 | 0.061 | 0.613 | 0.947 | 1.000 |
| 32 × 4 | 0.42 | 0.229 | 0.873 | 1.000 | 1.000 | 1.000 |

Choose b and r so the S-shaped curve rises near the similarity you consider "duplicate", then verify candidates with the exact Jaccard estimate. SimHash (Part 2, Chapter 5.3) is an alternative for near-duplicate detection at web scale.

**What to do with duplicates.** Keep one canonical copy, record the other locations as metadata (so permissions and links still work), and for versions of the same document keep only the latest or mark older ones as superseded with dates, so the model does not mix old and new rules.

### 3.3 Personal and sensitive data

Indexes and prompts copy whatever they ingest. Decide per source what may be indexed:

- **Detect** personal data (names, emails, phone numbers, account and card numbers, health data) with patterns plus named-entity recognition, for example Microsoft Presidio, and detect secrets such as API keys in code and tickets.
- **Act**: exclude, redact, mask with consistent placeholders, or keep but restrict access with ACLs, depending on policy.
- **Honour deletion**: regulations such as the GDPR give people a right to erasure, so you must be able to remove a person's data from raw stores, chunks, vectors, caches and logs. Stable ids from source to chunk (Chapter 6) make this possible.
- **Remember the prompt path**: anything retrieved is sent to the LLM, possibly a third-party API, so data-residency and vendor terms apply to the index content too.

### 3.4 Quality filters

Drop or flag documents that would only add noise: empty or near-empty pages, auto-generated logs, extraction failures (gibberish from unmapped fonts, detectable by a high share of non-dictionary tokens), and extremely short fragments. Keep the filtered items in a review queue: a sudden spike in rejections usually means a parser or connector broke.

## Chapter 4. Chunking strategies

A chunk is the unit you embed, retrieve and (usually) put in the prompt. Good chunks are **self-contained** (understandable alone), **focused** (about one thing) and **bounded** (small enough to embed well and to fit several in the prompt). Split on the document's own structure where possible, and choose the size by measurement at a fixed prompt-token budget.

### 4.1 The size trade-off

- **Small chunks** (for example 100 to 200 tokens) give sharp embeddings and precise retrieval, but lose surrounding context and are more likely to cut a fact in half.
- **Large chunks** (for example 800 to 1,500 tokens) keep context but blur the embedding (one vector averages many topics, Part 2 Chapter 1.5) and use more of the prompt per chunk, so fewer distinct sources fit.
- **Hard limits**: chunks must fit the embedding model's maximum input (Part 2, Chapter 2.2), measured in that model's tokens.

Typical starting points are 256 to 512 tokens for question answering over prose, smaller for FAQs and short records, larger for narrative or legal text, but the right answer comes from your evaluation set.

### 4.2 How much overlap?

Overlap repeats the end of one chunk at the start of the next. With chunk size C and overlap o, windows start every s = C − o tokens. An evidence passage of e tokens starting at a random position lies entirely inside some window with probability approximately:

```latex
P(\text{evidence fully inside one chunk}) \approx \min\!\left(1, \frac{C - e}{C - o}\right), \qquad \text{storage factor} = \frac{C}{C - o}
```

So with no overlap the probability is 1 − e/C, and **overlap of at least e guarantees containment**. For C = 512 and e = 100: no overlap gives 0.80; o = 50 gives 0.89 (11% more storage); o = 100 gives 1.0 (24% more storage). A simulation of random positions agrees with these figures to within half a percentage point. Overlap of 10 to 20% of the chunk size is a common default; structure-aware splitting reduces the need for it, because facts rarely cross section boundaries.

![Fixed windows with overlap: evidence A fits in one chunk, evidence B is cut](../diagrams/p04_chunk_overlap.svg)

*Fixed windows with overlap: evidence A fits in one chunk, evidence B is cut*

### 4.3 Strategies

1. **Fixed-size windows**: split every C tokens with overlap o. Simple, predictable, structure-blind: it cuts mid-sentence and mid-table.
2. **Recursive splitting**: try to split on the strongest boundary first (blank lines between paragraphs), and only if a piece is still too big fall back to weaker ones (line breaks, then sentences, then words). This is the default in popular frameworks and a strong baseline.
3. **Structure-aware splitting**: split on headings (Markdown, HTML or the parser's layout elements), keep lists and tables whole, and record the **heading path** (for example "Leave Policy > Parental Leave > Eligibility") as metadata and as a prefix to the chunk text. Usually the best choice for well-structured documents such as manuals, policies and documentation.
4. **Sentence packing**: pack whole sentences up to the size limit (what you built in Part 1).
5. **Semantic chunking**: embed each sentence, compute the cosine similarity between neighbouring sentences, and start a new chunk where similarity drops sharply (for example below a percentile of all neighbour similarities). It adapts to topic shifts but costs an embedding per sentence, and evaluations are mixed: Qu et al. (2024) found its benefits inconsistent and often not worth the cost compared with simpler fixed or structural splitting.
6. **LLM-based chunking and propositions**: ask an LLM to split text into self-contained units, or to rewrite it into atomic factual statements ("propositions", Chen et al., 2023). High quality, high cost; worth it for small, high-value corpora.
7. **Domain-specific**: code by function or class via a syntax tree; conversations by turn or topic; spreadsheets by row with headers; legal documents by clause numbering.

### 4.4 Rules that hold across strategies

- Never split inside a table row, a code block or a list item; keep a list together with the sentence that introduces it.
- Attach the document title and heading path to every chunk (Chapter 5).
- Measure length in the embedding model's tokens, not characters or words.
- Give each chunk a stable id and its character offsets in the parsed document, so you can show citations, highlight evidence and update incrementally.
- **Compare strategies at an equal token budget**: k small chunks versus fewer large ones that fill the same prompt space. Comparing top-5 small chunks against top-5 large chunks unfairly favours large ones, since they simply show the model more text.
- Evaluate with metrics that see chunk boundaries: did the retrieved chunks cover the evidence (recall), and how much irrelevant text came with it (precision)? The lab implements these.

## Chapter 5. Making chunks retrievable

The text you **index** does not have to be the text you **return** to the model. You can add context to what you index (metadata, a document summary, an LLM-written situating sentence), index several representations of one chunk, or index small units while returning their larger parents. These techniques fix the most common chunking failure: a chunk that is relevant but does not say so.

### 5.1 Metadata

Attach to every chunk: document id and title, heading path, source system and URL, created and modified dates, version, author or owner, document type, language, and access-control fields (tenant, groups). Metadata serves four purposes:

1. **Filtering**: permissions, product, date ranges, language (Part 3, Chapter 4).
2. **Ranking**: boost recent documents or official sources.
3. **Citations**: show the user where an answer came from, with a link and section.
4. **Retrieval text**: prefix the title and heading path to the chunk before embedding and BM25 indexing, the cheap trick from Part 1 Chapter 5.

### 5.2 Contextual retrieval

Introduced by Anthropic in September 2024, **contextual retrieval** asks an LLM, for each chunk, to write a short statement situating the chunk within its whole document (for example, "This section of Nimbus Robotics' 2026 travel policy covers meal limits during business trips."). That statement is prepended to the chunk before both embedding (contextual embeddings) and BM25 indexing (contextual BM25). In Anthropic's evaluation across codebases, fiction, scientific papers and financial documents, contextual embeddings alone cut the top-20 retrieval failure rate from 5.7% to 3.7% (about 35%); adding contextual BM25 brought it to 2.9% (about 49%); and adding a reranker brought it to 1.9% (about 67%) ([Anthropic, "Introducing Contextual Retrieval"](https://www.anthropic.com/news/contextual-retrieval)).

Cost and practicalities: it needs one LLM call per chunk with the whole document in the prompt. **Prompt caching** makes this affordable, because every chunk of a document shares the same long prefix. With an open model you can get the same effect from prefix caching in a serving engine such as vLLM. For very long documents, pass the relevant section instead of the whole document. The lab implements it with the Part 1 generator.

### 5.3 Late chunking

**Late chunking** (Günther et al., Jina AI, 2024) gets context into chunk embeddings without any LLM call. Instead of embedding each chunk separately, run a long-context embedding model over the **whole document once**, keep the per-token hidden states, and mean-pool them within each chunk's token span. Each chunk vector is then computed from tokens that attended to the rest of the document, so "It carries 150 kg" is embedded knowing "it" is the NX-7. Requirements: an embedding model with a long input window and token-level outputs, ideally trained with mean pooling; documents longer than the window are processed in overlapping macro-windows.

### 5.4 Index small, return big

Small units match queries precisely; large units give the model enough context to answer. You can have both:

- **Parent-child (small-to-big) retrieval**: split documents into parents (sections of 1,000 to 2,000 tokens) and children (100 to 300 tokens). Index only children; when a child is retrieved, put its parent in the prompt, deduplicating parents hit by several children.
- **Sentence-window retrieval**: index single sentences; return each hit with n sentences on either side.
- **Auto-merging**: if several children of the same parent are retrieved, replace them with the parent.

The cost is prompt budget: parents are big, so you can afford fewer of them. Measure answer quality, not only retrieval metrics, when you tune this.

![Parent-child retrieval: index small children, return the parent section](../diagrams/p04_parent_child.svg)

*Parent-child retrieval: index small children, return the parent section*

### 5.5 Multiple representations of one chunk

You can index several vectors that all point to the same chunk:

- **Summaries**: an LLM summary of a long section or table, which often matches broad questions better than the raw text.
- **Hypothetical questions** (doc2query-style; Nogueira et al., 2019): generate questions that the chunk answers and index them. Because user queries are questions, question-to-question matching can work better than question-to-passage matching, especially for FAQs and support content.
- **Captions** for figures and descriptions for tables (Chapter 2.3).

At query time, search all representations, map hits back to chunk ids, deduplicate, and return the original chunk text.

### 5.6 Which technique when?

| Problem you observe | Technique to try first |
| --- | --- |
| Relevant chunks do not mention their subject ("it", "this policy") | Title and heading prefix; then contextual retrieval or late chunking |
| Retrieved chunk is right but too short to answer | Parent-child or sentence-window retrieval |
| Users ask in very different words from the documents | Hypothetical questions; hybrid search (Part 3) |
| Answers live in tables | Table-specific chunks, row linearisation, summaries, or a SQL tool |
| Broad "overview" questions fail | Section or document summaries as extra representations |

## Chapter 6. Keeping the index fresh

An index is correct only if it matches its sources: new documents appear, changed documents replace their old chunks completely, deleted documents disappear, and permission changes take effect quickly. Content hashing and stable ids make this cheap and safe.

### 6.1 Stable identifiers

- **Document id**: use the source system's permanent id (a Confluence page id, a file's drive id), not its path or title, which change on rename or move.
- **Chunk id**: two common choices. Position-based ids (doc\_id#0, doc\_id#1, …) are simple but shift when text is inserted early in a document, so every later chunk looks new. **Content-based ids** (a hash of the chunk's normalised text, scoped by document) stay the same for unchanged chunks wherever they move.
- **Embedding cache**: key cached vectors by hash(model name and revision, prefix, chunk text). Unchanged chunks then never need re-embedding, even across full rebuilds.

### 6.2 Change detection

For each source item, record a fingerprint: modification time, an ETag or version from the source API, and a hash of the parsed content. On each sync, process only items whose fingerprint changed. Hashing the parsed content (not the raw file) avoids re-indexing when only irrelevant bytes changed, such as metadata inside a PDF.

### 6.3 Updating a changed document

1. Parse and chunk the new version.
2. Compute content ids for the new chunks.
3. Compare with the chunk ids currently stored for that document.
4. Embed only the new ids (using the cache), insert them, and delete ids that are no longer present.
5. Update document-level metadata (version, modified date) on all its chunks.

Do the insert-then-delete for one document as close to atomically as your store allows, or version it (write the new chunk set under version v+1, then switch), so queries never see a document with half old and half new chunks or with no chunks at all.

### 6.4 Deletions and reconciliation

Sources do not always send delete events. Periodically **reconcile**: list all document ids in the source, list all document ids in the index, and delete index entries whose source no longer exists. Without this, deleted or archived documents keep answering questions, which is both a quality and a compliance problem (Chapter 3.3).

### 6.5 Permission changes

Permission changes must propagate faster than content changes: a revoked user should lose access within minutes, not at the next nightly rebuild. Most vector databases can update payload metadata without re-embedding, so treat ACL updates as a separate, high-priority event stream. Some teams also check permissions again at query time against the source system for the final retrieved documents, as a second line of defence.

### 6.6 Costs and backfills

Estimate before you commit. Tokens to embed = number of chunks × average tokens per chunk, multiplied by (1 + overlap factor) and by the number of representations per chunk (Chapter 5.5). For example, 10 million chunks of 400 tokens is 4 billion tokens per full re-embedding. Multiply by your API price per token, or divide by your measured GPU throughput, and add the LLM cost of contextual retrieval or question generation, which is usually far larger than embedding cost. These numbers determine whether full rebuilds are a weekly routine or a quarterly project.

### 6.7 Monitoring freshness

Track **freshness lag** (time from a source change to searchability), per-stage failure counts, and the share of documents whose latest version is indexed. A simple, effective test is a **canary document**: an automated job edits a test page in each source and alerts if the change is not searchable within the target time.

## Chapter 7. Hands-on lab

You will see a PDF parser fail and fix it, build four chunkers that return character spans, construct a long-document benchmark from SciFact, measure evidence recall and precision for each chunking strategy at a fixed prompt-token budget, add contextual headers, and build an incremental indexer that embeds only changed text. The parsing, chunking, metric and incremental-indexing code was tested on synthetic data; the SciFact cells need Hugging Face access.

### Lab 1. Parsing a two-column PDF

Generate a small test PDF with a running header, page numbers, two columns drawn line by line in alternation (as many PDF writers do), and a table:

```python
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

PAGES = [
    (["The NX-7 carries a maximum payload", "of 150 kilograms. Its battery lasts", "up to 8 hours of operation."],
     ["Error E-212 means the battery is", "overheating. Move the robot to a", "cooler area and wait."]),
    (["Charging uses the NX Dock and", "reaches 80 percent in 45", "minutes from empty."],
     ["Error E-104 means the lidar is", "obstructed. Clean the sensor", "window with a dry cloth."]),
    (["Maximum speed is 2.0 metres per", "second, limited to 1.2 near", "people on the floor."],
     ["Error E-330 means a wheel motor", "has stalled. Check for debris", "before resetting the robot."]),
]

def make_test_pdf(path="nimbus_manual.pdf"):
    c = canvas.Canvas(path, pagesize=A4)
    W, H = A4
    for page, (left, right) in enumerate(PAGES, start=1):
        c.setFont("Helvetica", 9)
        c.drawString(72, H - 40, "Nimbus Robotics - Confidential")       # running header
        c.drawString(W / 2, 30, f"Page {page}")                          # page number
        c.setFont("Helvetica-Bold", 14)
        c.drawString(72, H - 80, f"Section {page}")
        c.setFont("Helvetica", 11)
        for i, (l, r) in enumerate(zip(left, right)):                    # columns drawn alternately
            c.drawString(72, H - 120 - 16 * i, l)
            c.drawString(320, H - 120 - 16 * i, r)
        if page == 2:                                                    # a small ruled table
            rows = [["Model", "Payload (kg)", "Battery (h)"], ["NX-5", "90", "6"], ["NX-7", "150", "8"]]
            y = H - 200
            for r in rows:
                for j, cell in enumerate(r):
                    c.drawString(72 + 130 * j, y, cell)
                y -= 18
            for j in range(4):
                c.line(66 + 130 * j, H - 186, 66 + 130 * j, y + 4)
            for i in range(4):
                c.line(66, H - 186 - 18 * i, 456, H - 186 - 18 * i)
        c.showPage()
    c.save()
    return path

path = make_test_pdf()

from pypdf import PdfReader
import pymupdf, pdfplumber
print(PdfReader(path).pages[0].extract_text())
print(pymupdf.open(path)[0].get_text("text"))
with pdfplumber.open(path) as pdf:
    print(pdf.pages[1].extract_tables())
```

Both text extractors return the header and page number inside the content and **interleave the two columns line by line** ("…maximum payload / Error E-212 means… / of 150 kilograms…"), so a chunk would mix the payload spec with an error code. pdfplumber, in contrast, recovers the ruled table as rows and cells.

Now fix reading order and boilerplate using line positions:

```python
import re
from collections import Counter

def page_lines(page):
    mid, height = page.rect.width / 2, page.rect.height
    out = []
    for block in page.get_text("dict")["blocks"]:
        for line in block.get("lines", []):                       # image blocks have no lines
            x0, y0, x1, y1 = line["bbox"]
            text = "".join(span["text"] for span in line["spans"]).strip()
            if text:
                column = 0 if (x0 < mid or x0 < mid < x1) else 1      # full-width lines count as left
                out.append({"text": text, "column": column, "y": y0, "x": x0, "rel_y": y0 / height})
    return out

def parse_pdf(path, margin=0.06, min_fraction=0.6):
    doc = pymupdf.open(path)
    pages = [page_lines(p) for p in doc]
    norm = lambda t: re.sub(r"\d+", "#", t)                       # "Page 2" and "Page 3" match
    in_margin = lambda l: l["rel_y"] < margin or l["rel_y"] > 1 - margin
    counts = Counter(n for lines in pages for n in {norm(l["text"]) for l in lines if in_margin(l)})
    boiler = {n for n, c in counts.items() if c / len(pages) >= min_fraction}
    texts = []
    for lines in pages:
        body = [l for l in lines if not (in_margin(l) and norm(l["text"]) in boiler)]
        body.sort(key=lambda l: (l["column"], l["y"], l["x"]))      # left column, then right
        texts.append("\n".join(l["text"] for l in body))
    return texts

for i, t in enumerate(parse_pdf(path), 1):
    print(f"--- page {i} ---\n{t}")
```

Three lessons from this small example. First, page 1 now reads correctly, with the header and page number gone and "Section 1" kept. Second, restricting boilerplate detection to the page margins matters: an earlier version without the margin rule also deleted the real headings, because "Section #" repeats on every page once digits are masked. Third, look at page 2: the column heuristic **scatters the full-width table** into separate lines ("Model", "Payload (kg)", "NX-5", "90" …). Heuristics that fix one layout break another, which is why production pipelines detect tables separately (as pdfplumber did) or use layout models.

### Lab 2. Four chunkers that return spans

All chunkers return **character spans** (start, end) into the parsed text, so you can measure exactly which text each chunk covers. Token counts use the embedding model's tokenizer.

```python
import numpy as np, re, hashlib
from transformers import AutoTokenizer
tok = AutoTokenizer.from_pretrained("BAAI/bge-small-en-v1.5")
def n_tokens(text):
    return len(tok(text, add_special_tokens=False)["input_ids"])

def fixed_chunks(text, max_tokens=256, overlap=32):
    offs = tok(text, return_offsets_mapping=True, add_special_tokens=False)["offset_mapping"]
    spans, step = [], max_tokens - overlap
    for i in range(0, len(offs), step):
        window = offs[i:i + max_tokens]
        spans.append((window[0][0], window[-1][1]))
        if i + max_tokens >= len(offs):
            break
    return spans

SEPARATORS = ["\n\n", "\n", ". ", " "]
def recursive_chunks(text, max_tokens=256, start=0, end=None, seps=SEPARATORS):
    end = len(text) if end is None else end
    if n_tokens(text[start:end]) <= max_tokens:
        return [(start, end)] if text[start:end].strip() else []
    if not seps:                                                  # last resort: fixed windows
        return [(start + s, start + e) for s, e in fixed_chunks(text[start:end], max_tokens, 0)]
    sep, rest = seps[0], seps[1:]
    cuts = [m.end() for m in re.finditer(re.escape(sep), text[start:end])]
    if not cuts:
        return recursive_chunks(text, max_tokens, start, end, rest)
    bounds = [start] + [start + c for c in cuts] + [end]
    pieces = [(a, b) for a, b in zip(bounds, bounds[1:]) if b > a]
    out, cur_s, cur_e = [], None, None
    for a, b in pieces:
        if n_tokens(text[a:b]) > max_tokens:                      # too big: split it deeper,
            s0 = a if cur_s is None else cur_s                    # carrying pending small pieces
            cur_s = None                                          # (e.g. a heading) along with it
            out.extend(recursive_chunks(text, max_tokens, s0, b, rest))
        elif cur_s is None:
            cur_s, cur_e = a, b
        elif n_tokens(text[cur_s:b]) <= max_tokens:               # merge neighbouring pieces
            cur_e = b
        else:
            out.append((cur_s, cur_e)); cur_s, cur_e = a, b
    if cur_s is not None:
        out.append((cur_s, cur_e))
    return [(s, e) for s, e in out if text[s:e].strip()]

def markdown_chunks(text, max_tokens=256):
    """Split at Markdown headings, recurse inside long sections; return (start, end, heading_path)."""
    heads = [(m.start(), len(m.group(1)), m.group(2).strip())
             for m in re.finditer(r"^(#{1,6})\s+(.*)$", text, flags=re.M)]
    if not heads or heads[0][0] != 0:
        heads = [(0, 0, "")] + heads
    out, path = [], []
    for i, (s, level, title) in enumerate(heads):
        e = heads[i + 1][0] if i + 1 < len(heads) else len(text)
        if level:
            path = path[:level - 1] + [title]
        for cs, ce in recursive_chunks(text, max_tokens, s, e):
            if re.fullmatch(r"#{1,6}\s+.*", text[cs:ce].strip()):
                continue                                          # a heading with no body
            out.append((cs, ce, " > ".join(path)))
    return out

def sentence_spans(text):
    return [(m.start(), m.end()) for m in re.finditer(r"[^.!?\n]+(?:[.!?]+|$)", text) if m.group().strip()]

def semantic_chunks(text, embed, max_tokens=256, percentile=85):
    """Cut where neighbouring sentences are least similar (bottom 15% by default)."""
    sents = sentence_spans(text)
    if len(sents) < 2:
        return sents
    E = embed([text[s:e] for s, e in sents])
    sims = (E[:-1] * E[1:]).sum(axis=1)
    cut_after = set(np.where(sims < np.percentile(sims, 100 - percentile))[0])
    out, cur = [], [sents[0]]
    for i in range(1, len(sents)):
        too_big = n_tokens(text[cur[0][0]:sents[i][1]]) > max_tokens
        if (i - 1) in cut_after or too_big:
            out.append((cur[0][0], cur[-1][1])); cur = []
        cur.append(sents[i])
    out.append((cur[0][0], cur[-1][1]))
    final = []
    for s, e in out:                                              # one huge sentence: split it
        final.extend(recursive_chunks(text, max_tokens, s, e) if n_tokens(text[s:e]) > max_tokens else [(s, e)])
    return final
```

The recursive splitter has one subtle rule: when a piece is too big, any small pending piece (typically a heading) is carried into the deeper split instead of being emitted alone. Without it you get useless heading-only chunks; we found that bug while testing.

### Lab 3. A long-document benchmark with evidence spans

SciFact abstracts are short, so chunking barely matters on them. We concatenate them into long "collections" of 20 abstracts, each abstract a Markdown section, and record where every abstract's text lies. A query's **evidence** is the text span of its relevant abstracts.

```python
import pandas as pd
from huggingface_hub import hf_hub_download
from sentence_transformers import SentenceTransformer

def load_scifact():
    get = lambda f: hf_hub_download("mteb/scifact", f, repo_type="dataset")
    corpus = pd.read_json(get("corpus.jsonl"), lines=True, dtype={"_id": str})
    queries = pd.read_json(get("queries.jsonl"), lines=True, dtype={"_id": str})
    qrels = pd.read_csv(get("qrels/test.tsv"), sep="\t", dtype={"query-id": str, "corpus-id": str})
    rel = qrels[qrels["score"] > 0].groupby("query-id")["corpus-id"].apply(set).to_dict()
    queries = queries[queries["_id"].isin(rel)].reset_index(drop=True)
    return corpus, queries, rel

def build_long_docs(corpus, per_doc=20, seed=0):
    order = np.random.default_rng(seed).permutation(len(corpus))
    docs, where = [], {}                  # where[abstract_id] = (doc index, start, end)
    for g in range(0, len(order), per_doc):
        text = f"# Collection {g // per_doc}\n\n"
        for i in order[g:g + per_doc]:
            row = corpus.iloc[i]
            header = f"## {str(row['title']).strip()}\n\n"
            body = str(row["text"]).strip()
            start = len(text) + len(header)
            text += header + body + "\n\n"
            where[row["_id"]] = (len(docs), start, start + len(body))
        docs.append(text)
    return docs, where

corpus, queries, rel = load_scifact()
long_docs, where = build_long_docs(corpus)
query_texts = queries["text"].tolist()
gold = [[where[a] for a in rel[q] if a in where] for q in queries["_id"]]
print(len(long_docs), "long documents; mean tokens:", int(np.mean([n_tokens(d) for d in long_docs[:20]])))
```

Now the metrics. For each query we take retrieved chunks in rank order until a **prompt-token budget** is filled, then measure at character level: **evidence recall** (share of the gold text covered by the retrieved chunks), **precision** (share of the retrieved text that is gold) and **IoU**.

```python
def merge(intervals):
    out = []
    for s, e in sorted(intervals):
        if out and s <= out[-1][1]:
            out[-1][1] = max(out[-1][1], e)
        else:
            out.append([s, e])
    return out

def overlap_len(a, b):
    i = j = total = 0
    while i < len(a) and j < len(b):
        lo, hi = max(a[i][0], b[j][0]), min(a[i][1], b[j][1])
        total += max(0, hi - lo)
        if a[i][1] < b[j][1]: i += 1
        else: j += 1
    return total

def evidence_scores(retrieved, gold_spans):
    """retrieved, gold_spans: lists of (doc, start, end)."""
    docs = {d for d, _, _ in retrieved} | {d for d, _, _ in gold_spans}
    inter = ret_len = gold_len = 0
    for d in docs:
        R = merge([(s, e) for dd, s, e in retrieved if dd == d])
        G = merge([(s, e) for dd, s, e in gold_spans if dd == d])
        inter += overlap_len(R, G)
        ret_len += sum(e - s for s, e in R)
        gold_len += sum(e - s for s, e in G)
    union = ret_len + gold_len - inter
    return {"recall": inter / gold_len if gold_len else 0.0,
            "precision": inter / ret_len if ret_len else 0.0,
            "iou": inter / union if union else 0.0}

def take_within_budget(ranked, budget):
    out, used = [], 0
    for c in ranked:
        if out and used + c["n_tokens"] > budget:
            break
        out.append(c); used += c["n_tokens"]
    return out
```

### Lab 4. Compare chunking strategies

```python
import torch
bge = SentenceTransformer("BAAI/bge-small-en-v1.5", device="cuda" if torch.cuda.is_available() else "cpu")
embed = lambda texts: np.asarray(bge.encode(texts, normalize_embeddings=True, batch_size=128), dtype=np.float32)
Qv = np.asarray(bge.encode(query_texts, prompt="Represent this sentence for searching relevant passages: ",
                           normalize_embeddings=True), dtype=np.float32)

def build_chunks(strategy, size, add_heading=False):
    chunks = []
    for d, text in enumerate(long_docs):
        if strategy == "fixed":
            spans = [(s, e, "") for s, e in fixed_chunks(text, size, size // 8)]
        elif strategy == "recursive":
            spans = [(s, e, "") for s, e in recursive_chunks(text, size)]
        elif strategy == "markdown":
            spans = markdown_chunks(text, size)
        elif strategy == "semantic":
            spans = [(s, e, "") for s, e in semantic_chunks(text, embed, size)]
        for s, e, path in spans:
            body = text[s:e]
            chunks.append({"doc": d, "start": s, "end": e, "n_tokens": n_tokens(body),
                           "index_text": f"{path}\n{body}" if add_heading and path else body})
    return chunks

def evaluate_chunks(chunks, budget=512):
    E = embed([c["index_text"] for c in chunks])
    S = Qv @ E.T
    scores = []
    for i, g in enumerate(gold):
        ranked = [chunks[j] for j in np.argsort(-S[i])[:100]]
        picked = take_within_budget(ranked, budget)
        scores.append(evidence_scores([(c["doc"], c["start"], c["end"]) for c in picked], g))
    return {m: round(float(np.mean([s[m] for s in scores])), 3) for m in ("recall", "precision", "iou")}

results = []
for strategy in ["fixed", "recursive", "markdown", "semantic"]:
    for size in [128, 256, 512]:
        chunks = build_chunks(strategy, size)
        r = evaluate_chunks(chunks, budget=512)
        results.append({"strategy": strategy, "size": size, "n_chunks": len(chunks), **r})
        print(results[-1])

for size in [128, 256]:                                  # structure as context
    r = evaluate_chunks(build_chunks("markdown", size, add_heading=True), budget=512)
    print({"strategy": "markdown + heading prefix", "size": size, **r})

print(pd.DataFrame(results).to_string(index=False))
```

What to look for, and why the budget matters. All rows spend the same 512 prompt tokens, so smaller chunks mean more distinct places retrieved, larger chunks mean more context per place. Expect: structure-aware chunks to beat fixed windows (fixed windows straddle two abstracts and mix topics); precision to fall as chunks grow; the heading prefix to raise recall for small chunks, because each piece of an abstract now carries its title; and semantic chunking to cost far more compute (one embedding per sentence) for a gain that may be small or absent, consistent with Qu et al. (2024). Your exact numbers will depend on the embedding model; the comparison method is the deliverable.

### Lab 5. Contextual retrieval with an open model (optional, GPU time)

Generating a situating sentence for every chunk with the 4B model from Part 1 takes too long for the full benchmark on a T4, so run it on a subset: the first 10 collections and the queries whose evidence lies in them.

```python
import torch
from transformers import AutoModelForCausalLM
LLM = "Qwen/Qwen3-4B-Instruct-2507"
llm_tok = AutoTokenizer.from_pretrained(LLM)
llm = AutoModelForCausalLM.from_pretrained(LLM, dtype=torch.float16, device_map="auto")

CONTEXT_PROMPT = ("Here is a document:\n<document>\n{doc}\n</document>\n"
                  "Here is one chunk from it:\n<chunk>\n{chunk}\n</chunk>\n"
                  "Write one or two sentences that situate this chunk within the document, "
                  "to improve search retrieval of the chunk. Answer with only those sentences.")

def situate(doc_text, chunk_text, max_new_tokens=60):
    msgs = [{"role": "user", "content": CONTEXT_PROMPT.format(doc=doc_text, chunk=chunk_text)}]
    inputs = llm_tok.apply_chat_template(msgs, add_generation_prompt=True,
                                         return_dict=True, return_tensors="pt").to(llm.device)
    with torch.no_grad():
        out = llm.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
    return llm_tok.decode(out[0, inputs["input_ids"].shape[1]:], skip_special_tokens=True).strip()

SUBSET = set(range(10))
sub_q = [i for i, g in enumerate(gold) if g and all(d in SUBSET for d, _, _ in g)]
base = [c for c in build_chunks("fixed", 128) if c["doc"] in SUBSET]
ctx = [dict(c, index_text=situate(long_docs[c["doc"]], c["index_text"]) + "\n" + c["index_text"])
       for c in base]                                 # minutes on a T4; cache the results

def evaluate_subset(chunks, budget=512):
    E = embed([c["index_text"] for c in chunks])
    S = Qv[sub_q] @ E.T
    sc = []
    for row, i in enumerate(sub_q):
        picked = take_within_budget([chunks[j] for j in np.argsort(-S[row])[:100]], budget)
        sc.append(evidence_scores([(c["doc"], c["start"], c["end"]) for c in picked], gold[i]))
    return {m: round(float(np.mean([s[m] for s in sc])), 3) for m in ("recall", "precision", "iou")}

print(len(sub_q), "queries")
print("fixed-128           ", evaluate_subset(base))
print("fixed-128 + context ", evaluate_subset(ctx))
```

We deliberately use **fixed** chunks here, the case where chunks most often lack their subject, so the effect of added context is easiest to see. Each long document is several thousand tokens, so every call re-reads it; in production you would enable prefix caching (vLLM, or prompt caching in an API) so the shared document prefix is computed once per document.

### Lab 6. Incremental indexing with content hashes

```python
class IncrementalIndex:
    """Content-hash chunk ids plus an embedding cache: only new text is ever embedded."""
    def __init__(self, embed, chunker):
        self.embed, self.chunker = embed, chunker
        self.cache, self.chunks, self.by_doc, self.n_embedded = {}, {}, {}, 0
    @staticmethod
    def h(text):
        return hashlib.sha256(text.encode()).hexdigest()[:16]
    def upsert(self, doc_id, text):
        new_ids, todo = {}, []
        for s, e in self.chunker(text):
            t = text[s:e]
            new_ids[f"{doc_id}:{self.h(t)}"] = t
            if self.h(t) not in self.cache:
                todo.append(t)
        if todo:
            for t, v in zip(todo, self.embed(todo)):
                self.cache[self.h(t)] = v
            self.n_embedded += len(todo)
        old = self.by_doc.get(doc_id, set())
        for cid in set(new_ids) - old:                    # insert new chunks first...
            t = new_ids[cid]
            self.chunks[cid] = {"doc_id": doc_id, "text": t, "vector": self.cache[self.h(t)]}
        for cid in old - set(new_ids):                    # ...then remove stale ones
            del self.chunks[cid]
        self.by_doc[doc_id] = set(new_ids)
        return {"added": len(set(new_ids) - old), "removed": len(old - set(new_ids)),
                "unchanged": len(set(new_ids) & old)}
    def delete(self, doc_id):
        for cid in self.by_doc.pop(doc_id, set()):
            del self.chunks[cid]
    def reconcile(self, source_ids):
        for d in set(self.by_doc) - set(source_ids):
            self.delete(d)

idx = IncrementalIndex(embed, lambda t: recursive_chunks(t, 128))
doc0 = long_docs[0]
print(idx.upsert("collection-0", doc0), "embedded so far:", idx.n_embedded)
edited = doc0.replace("\n\n## ", "\n\n## [Revised] ", 1)       # edit one heading
print(idx.upsert("collection-0", edited), "embedded so far:", idx.n_embedded)
print(idx.upsert("collection-0", edited), "embedded so far:", idx.n_embedded)  # no-op re-sync
idx.upsert("retired-page", "## Old\n\nThis page was deleted at the source.")
idx.reconcile(["collection-0"])
print(sorted(idx.by_doc))                                # the retired page is gone
```

In our test on synthetic text, editing one heading changed exactly one chunk: one added, one removed, everything else unchanged and **not re-embedded**, and a repeated sync embedded nothing. With position-based ids instead, any edit that shifted chunk boundaries would have re-embedded everything after it.

## Interview questions with model answers

These 22 questions cover pipeline design, parsing, chunking, enrichment and freshness. Ingestion questions are where interviewers separate people who have shipped RAG from people who have only read about it, so tie answers to failure modes and measurements.

### Pipeline and parsing

**Q1. Walk me through an ingestion pipeline for enterprise documents.** Connectors fetch content, metadata and ACLs; parsers produce structured text; cleaning removes boilerplate and duplicates and handles personal data; chunking splits on structure; enrichment adds metadata and context; embedding runs in batches; indexing upserts into vector and keyword indexes. Each stage is idempotent, queued, monitored, and stores its output so later stages can be re-run without repeating earlier ones.

**Q2. Why store parsed documents and chunks rather than only vectors?** So you can re-chunk without re-parsing, re-embed without re-chunking, fix parser bugs by replaying only affected documents, show citations with exact text, and support deletion requests. Parsing is often the most expensive step.

**Q3. What makes PDFs hard to parse, and how do you handle it?** PDFs store positioned glyphs, not paragraphs, so reading order, columns, headers and footers, hyphenation and tables must be reconstructed; scans have no text layer. Use a text-layer parser for simple born-digital files, a layout-model pipeline for complex layouts and tables, and OCR or a vision-language model only where the text layer is missing, routing by a cheap per-page check.

**Q4. What are the risks of vision-language-model parsers?** They are generative: they can drop, reorder or alter text, including numbers, and they cost more per page. For high-stakes documents, verify against the text layer, sample outputs for human review, and keep page-level provenance.

**Q5. How do you handle tables in RAG?** Detect them separately; keep small tables whole with caption and section heading; linearise rows with repeated headers for row-level questions; add summaries for broad questions; and for large or numeric tables, load them into a database and use a SQL tool rather than embeddings.

**Q6. How do you choose a parser?** Sample representative and difficult documents, run candidates, inspect outputs side by side, check tables and numbers, and measure end-to-end retrieval on questions about those documents. Use public benchmarks only to shortlist; check licences and cost per page.

### Cleaning and data handling

**Q7. How do you detect near-duplicate documents at scale?** Shingle each document, compute MinHash signatures (the probability two minhashes match equals Jaccard similarity), and use LSH banding to find candidate pairs without comparing every pair; then verify and keep a canonical copy, recording other locations and marking older versions as superseded.

**Q8. How do you handle personal data in a RAG index?** Decide per source what may be indexed; detect personal data and secrets; exclude, redact, mask or restrict by ACL; remember that retrieved text goes to the LLM provider; and support erasure across raw stores, chunks, vectors, caches and logs using stable ids.

### Chunking

**Q9. How do you choose a chunk size?** Start around 256 to 512 tokens for prose question answering, respect the embedding model's limit, then tune on an evaluation set at a fixed prompt-token budget, measuring evidence recall and precision and final answer quality. Smaller chunks sharpen retrieval but lose context; larger ones keep context but blur embeddings and use more prompt space.

**Q10. Why compare chunk sizes at a fixed token budget?** Top-5 chunks of 1,000 tokens show the model four times as much text as top-5 chunks of 250 tokens, so large chunks look better for an unfair reason. Holding the prompt budget fixed compares how well each strategy uses the same space.

**Q11. How much overlap should you use?** With chunk size C, overlap o and an evidence span of e tokens, the chance the evidence fits wholly in one chunk is about min(1, (C − e)/(C − o)), so overlap of at least e guarantees it, at a storage cost of C/(C − o). Ten to twenty percent is a common default, and structure-aware splitting reduces the need.

**Q12. Compare fixed, recursive, structure-aware and semantic chunking.** Fixed is simple but cuts mid-sentence and mid-table. Recursive splits on the strongest available boundary and is a strong baseline. Structure-aware splits on headings, keeps tables and lists whole, and records the heading path; usually best for structured documents. Semantic splits at drops in neighbouring-sentence similarity; it adapts to topic shifts but costs an embedding per sentence and published evaluations show inconsistent gains.

**Q13. How would you chunk source code?** Along syntax: functions, classes and methods via a parser such as tree-sitter, with the file path, symbol names and imports as metadata, and the enclosing class signature added as context for methods.

### Enrichment

**Q14. What is contextual retrieval?** For each chunk, an LLM writes a short statement situating it within its document, which is prepended before embedding and BM25 indexing. Anthropic reported top-20 retrieval failures falling about 35% with contextual embeddings, about 49% adding contextual BM25, and about 67% with a reranker on top. The cost is one LLM call per chunk, made affordable with prompt or prefix caching.

**Q15. What is late chunking, and how does it differ from contextual retrieval?** Late chunking runs a long-context embedding model over the whole document once and mean-pools token states within each chunk span, so chunk vectors are conditioned on the document without any LLM calls. Contextual retrieval adds explicit text, which also helps BM25, at a higher cost.

**Q16. What is parent-child retrieval and when does it help?** Index small child chunks for precise matching, but return their larger parent sections to the model, deduplicating parents. It helps when retrieved chunks are correct but too short to answer. The trade-off is prompt budget.

**Q17. Why index hypothetical questions or summaries?** Users ask questions; question-to-question matching can beat question-to-passage matching, and summaries match broad queries. Several representations map back to one chunk id, so the model still receives the original text.

**Q18. Which metadata do you attach to chunks and why?** Document id, title, heading path, source and URL, dates, version, owner, type, language and ACL fields: for filtering, ranking (recency, authority), citations, and as retrieval text prefixes.

### Freshness and operations

**Q19. How do you update the index when a document changes?** Detect the change by fingerprint, re-parse and re-chunk, compute content-hash chunk ids, embed only new ids using an embedding cache, insert new chunks and delete removed ones atomically or via versioning, and update document metadata.

**Q20. How do you make sure deleted documents disappear?** Process delete events, and periodically reconcile the list of source ids with the list of indexed ids, deleting orphans. Without reconciliation, missed delete events leave stale or non-compliant content searchable.

**Q21. A user's access was revoked. How fast does that take effect, and how?** Within minutes: treat permission changes as a separate high-priority stream that updates ACL metadata in place without re-embedding, and optionally re-check access against the source at query time for the final results.

**Q22. How do you estimate the cost of re-indexing?** Chunks × average tokens × (1 + overlap) × representations per chunk gives embedding tokens; multiply by API price or divide by measured GPU throughput; add LLM costs for contextual retrieval or question generation, which usually dominate; and use an embedding cache to avoid paying again for unchanged text.

## Exercises with solutions

Twelve exercises: three mathematical, one conceptual, five coding, two debugging and one design. Coding exercises reuse the Chapter 7 lab.

### Exercise 1. Overlap arithmetic

Chunks are 300 tokens and typical answer evidence is 80 tokens long. For overlaps of 0, 40 and 80 tokens, compute the probability that a randomly placed evidence span fits wholly inside one chunk, and the storage (and embedding cost) factor.

**Solution.** P ≈ min(1, (C − e)/(C − o)) and storage factor C/(C − o).

| Overlap o | P(evidence inside one chunk) | Storage factor |
| --- | --- | --- |
| 0 | 220 / 300 = 0.733 | 1.00 |
| 40 | 220 / 260 = 0.846 | 1.15 |
| 80 | 220 / 220 = 1.000 | 1.36 |

Guaranteeing containment costs 36% more storage and embedding here. Whether that pays depends on whether split evidence actually hurts your answers, which only your evaluation set can tell.

### Exercise 2. MinHash banding

With n = 100 minhashes split into b = 20 bands of r = 5 rows: (a) what is the approximate similarity threshold; (b) what is the probability that documents with Jaccard similarity 0.6 become candidates; (c) for similarities 0.3 and 0.9; (d) how would you raise the threshold?

**Solution.** (a) (1/20)^(1/5) ≈ 0.55. (b) 1 − (1 − 0.6⁵)²⁰ = 1 − (1 − 0.0778)²⁰ ≈ 0.80. (c) For 0.3: about 0.048; for 0.9: about 1.0. (d) Use more rows per band and fewer bands, for example b = 10, r = 10 gives a threshold of (1/10)^(1/10) ≈ 0.79. More rows sharpen and shift the S-curve to the right.

### Exercise 3. Budget a re-index with contextual retrieval

A corpus has 2 million documents averaging 3,000 tokens. You chunk at 400 tokens with 60 tokens of overlap, and add contextual retrieval: one LLM call per chunk with the whole document plus the chunk as input and about 60 output tokens. Using illustrative prices of 0.02 dollars per million embedding tokens, 0.10 dollars per million LLM input tokens (0.01 for cached input) and 0.40 dollars per million output tokens, estimate the number of chunks, embedding cost, and contextualisation cost with and without prompt caching.

**Solution.**

- Chunks: each new chunk advances 400 − 60 = 340 tokens, so about 3,000 / 340 ≈ 8.8 chunks per document, about 17.6 million chunks.
- Embedding tokens: 2 × 10⁶ × 3,000 × 400/340 ≈ 7.1 billion, so about 141 dollars. Cheap.
- Contextualisation without caching: input ≈ 17.6 × 10⁶ × 3,400 ≈ 60 billion tokens, about 6,000 dollars, plus output 17.6 × 10⁶ × 60 ≈ 1.06 billion tokens, about 424 dollars. Total about 6,400 dollars.
- With caching: the 3,000-token document is written once per document (6 billion tokens at the full price, about 600 dollars) and read from cache for every chunk (about 53 billion tokens at 0.01, about 529 dollars); the chunk text itself is about 7.1 billion fresh tokens (about 706 dollars); output stays about 424 dollars. Total about 2,260 dollars.

Lessons: LLM enrichment, not embedding, dominates cost; caching cuts it by roughly two-thirds here; and with an embedding cache plus incremental updates you pay this once, not at every rebuild. Always redo this arithmetic with current prices.

### Exercise 4. Choose a chunking approach

Pick a chunking approach and any enrichment for: (a) an HR policy handbook with numbered headings; (b) a customer-support knowledge base of short FAQ entries; (c) a 200-page legal contract; (d) a Python code repository; (e) monthly sales spreadsheets.

**Solution.** (a) Structure-aware splitting on headings, heading path as prefix and metadata, effective date and version for filtering. (b) One FAQ entry per chunk (question plus answer), no further splitting; optionally index extra paraphrased questions. (c) Clause-aware splitting by clause numbering, parent-child retrieval (clause → section), defined-terms context added to chunks, and strict provenance with page numbers for citations. (d) Syntax-aware chunks per function or class with file path, symbol and class signature; add a repository map summary. (e) Do not embed rows for numeric questions: load into a database and use SQL; optionally embed column descriptions and sheet summaries so the system knows which table to query.

### Exercise 5 (coding). Route pages to OCR

Write `needs_ocr(page)` for PyMuPDF that flags pages with almost no extractable text but a large image area. Test it on a two-page PDF whose second page is an image of text.

**Solution.**

```python
from PIL import Image, ImageDraw
img = Image.new("RGB", (1200, 400), "white")
ImageDraw.Draw(img).text((40, 40), "Scanned form: Expense claim 2026-114, amount 412.50 EUR", fill="black")
img.save("scan.png")
c = canvas.Canvas("mixed.pdf", pagesize=A4); W, H = A4
c.drawString(72, H - 72, "This page has a normal text layer with plenty of characters on it."); c.showPage()
c.drawImage("scan.png", 40, H - 400, width=W - 80, height=300); c.showPage(); c.save()

def needs_ocr(page, min_chars=50, min_image_share=0.3):
    n_chars = len(page.get_text("text").strip())
    page_area = page.rect.width * page.rect.height
    image_area = 0.0
    for img in page.get_images(full=True):
        for rect in page.get_image_rects(img[0]):
            image_area += rect.width * rect.height
    return n_chars < min_chars and image_area / page_area >= min_image_share

print([needs_ocr(p) for p in pymupdf.open("mixed.pdf")])     # [False, True]
```

In production, send only flagged pages to the OCR or VLM path, log the decision, and tune the thresholds on a labelled sample (some text pages contain large photos; some scans include a thin text layer of headers).

### Exercise 6 (coding). Linearise a table

Turn the table that pdfplumber extracted in Lab 1 into one self-contained line per row, prefixed by a caption.

**Solution.**

```python
def linearise(table, caption=""):
    header, *rows = table
    prefix = f"{caption}: " if caption else ""
    return [prefix + "; ".join(f"{h}: {v}" for h, v in zip(header, row)) for row in rows]

with pdfplumber.open("nimbus_manual.pdf") as pdf:
    table = pdf.pages[1].extract_tables()[0]
print(linearise(table, "NX robot specifications"))
# ['NX robot specifications: Model: NX-5; Payload (kg): 90; Battery (h): 6',
#  'NX robot specifications: Model: NX-7; Payload (kg): 150; Battery (h): 8']
```

Each row now carries its own headers and caption, so "What is the NX-7's payload?" can match one short, unambiguous chunk.

### Exercise 7 (coding). MinHash from scratch

Implement 5-word shingling and a 128-function MinHash with universal hashing. Compare estimated and true Jaccard similarity for two versions of the remote-work policy (one with "three days" changed to "two days" and the stipend changed) and for an unrelated document.

**Solution.**

```python
P = (1 << 61) - 1                                       # a large prime

def shingles(text, k=5):
    w = re.findall(r"\w+", text.lower())
    return {" ".join(w[i:i + k]) for i in range(max(1, len(w) - k + 1))}

def minhash(sh, n=128, seed=0):
    rng = np.random.default_rng(seed)
    a = rng.integers(1, P, n, dtype=np.uint64)
    b = rng.integers(0, P, n, dtype=np.uint64)
    x = [int.from_bytes(hashlib.blake2b(s.encode(), digest_size=8).digest(), "little") % P for s in sh]
    # h_i(x) = (a_i x + b_i) mod P; Python ints avoid overflow
    return np.array([min((int(ai) * xi + int(bi)) % P for xi in x) for ai, bi in zip(a, b)], dtype=object)

jaccard = lambda A, B: len(A & B) / len(A | B)
v1 = ("Employees may work remotely up to three days per week subject to manager approval. "
      "Core hours are 10:00 to 15:00 Eastern Time. Every employee receives a one-time home office "
      "stipend of 600 dollars. Employees also receive 50 dollars per month toward internet costs. "
      "Fully remote arrangements require approval from a vice president.")
v2 = v1.replace("three days", "two days").replace("600 dollars", "750 dollars")
other = "The NX-7 carries a maximum payload of 150 kilograms and its battery lasts up to eight hours."
A, B, C = shingles(v1), shingles(v2), shingles(other)
mA, mB, mC = minhash(A), minhash(B), minhash(C)
print("v1 vs v2:   true", round(jaccard(A, B), 3), "estimated", round(np.mean(mA == mB), 3))
print("v1 vs other: true", round(jaccard(A, C), 3), "estimated", round(np.mean(mA == mC), 3))
```

In our run the two versions had true Jaccard 0.67 and estimate 0.62 (the standard error with 128 hashes is about √(J(1 − J)/128) ≈ 0.04, so this is within normal error), and the unrelated pair was 0 for both. Note that two small edits removed a third of the shingles: version changes in short documents produce moderate, not tiny, Jaccard values, so the duplicate threshold must be chosen with real examples. Detecting the pair is half the job; the pipeline must then keep only the current version.

### Exercise 8 (coding). Parent-child retrieval on the long-document benchmark

Index 128-token children inside each Markdown section, retrieve children, return their parent sections deduplicated within a 512-token budget, and compare evidence recall and precision with plain 128- and 512-token Markdown chunks from Lab 4.

**Solution.**

```python
def build_parent_child(child_tokens=128):
    parents, children = [], []
    for d, text in enumerate(long_docs):
        heads = [m.start() for m in re.finditer(r"^#{1,6}\s+.*$", text, flags=re.M)]
        bounds = (heads if heads and heads[0] == 0 else [0] + heads) + [len(text)]
        for ps, pe in zip(bounds, bounds[1:]):
            if not text[ps:pe].strip():
                continue
            pid = len(parents)
            parents.append({"doc": d, "start": ps, "end": pe, "n_tokens": n_tokens(text[ps:pe])})
            for cs, ce in recursive_chunks(text, child_tokens, ps, pe):
                if not re.fullmatch(r"#{1,6}\s+.*", text[cs:ce].strip()):
                    children.append({"parent": pid, "text": text[cs:ce]})
    return parents, children

parents, children = build_parent_child(128)
S = Qv @ embed([c["text"] for c in children]).T
scores = []
for i, g in enumerate(gold):
    picked, seen, used = [], set(), 0
    for j in np.argsort(-S[i])[:200]:
        pid = children[j]["parent"]
        if pid in seen:
            continue                                   # several children, one parent
        p = parents[pid]
        if picked and used + p["n_tokens"] > 512:
            break
        seen.add(pid); picked.append(p); used += p["n_tokens"]
    scores.append(evidence_scores([(p["doc"], p["start"], p["end"]) for p in picked], g))
print("parent-child:", {m: round(float(np.mean([s[m] for s in scores])), 3) for m in ("recall", "precision", "iou")})
for size in (128, 512):
    print(f"markdown-{size}:", evaluate_chunks(build_chunks("markdown", size), budget=512))
```

What you should find: parent-child behaves like the small chunks when choosing where to look (precise matching) and like large chunks in what it returns (whole sections), so evidence recall should be at least as high as markdown-128 when the matching parent is found, at some cost in precision because entire sections are returned. In this benchmark each parent is exactly one abstract, the ideal case; in real documents, sections vary in size, so cap parent length or fall back to a window around the child.

### Exercise 9 (debugging). Five ingestion bugs

For each symptom, name the likely cause and fix. (a) Answers sometimes include "Confidential, do not distribute". (b) After a policy update, the assistant gives both the old and new limits in one answer. (c) The assistant cites a page that was deleted from the wiki last month. (d) Questions about German documents retrieve poorly while English is fine. (e) Answers about a pricing table give numbers from the wrong row.

**Solution.** (a) Running headers or footers not removed during cleaning; add margin-based repeated-line removal (Lab 1) and re-process. (b) Old chunks were not deleted on update, or both versions exist as separate documents; use content-hash diffing with delete-on-update, and mark superseded versions. (c) Missing delete events with no reconciliation; add periodic source-versus-index reconciliation. (d) An English-only embedding model or English analyzer for BM25; detect language at ingestion and use a multilingual embedding model and language-specific analyzers. (e) Table flattened by the parser so values lost their row and column headers; use table extraction and row linearisation (Exercise 6), or a SQL tool.

### Exercise 10 (debugging). Duplicate chunks after every sync

After each nightly sync, the index grows by roughly the corpus size and answers show the same passage several times. What is wrong, and how do you fix and clean up?

**Solution.** Upserts are not idempotent: chunk ids are probably random UUIDs or include a timestamp, so each sync inserts new copies instead of replacing. Fix by deriving ids deterministically from document id and chunk content (Lab 6), and by deleting a document's previous chunk set on update. Clean up by rebuilding into a new collection with the fixed pipeline and switching the alias (blue-green), rather than trying to deduplicate in place. Add a monitor on total chunk count versus document count to catch it next time.

### Exercise 11 (conceptual). Contextual retrieval or late chunking?

You have 50 million chunks, a modest budget and an open embedding model with a 512-token limit. Which technique would you use to add document context, and why?

**Solution.** Contextual retrieval would need 50 million LLM calls, which is costly even with caching. Late chunking needs a long-context embedding model, which the current 512-token model is not. The cheap first step is to prefix each chunk with its document title and heading path (and a short document-level summary generated once per document, not per chunk). Measure that; then consider switching to a long-context embedding model to enable late chunking, or apply contextual retrieval only to the highest-value collections.

### Exercise 12 (design). A bank's document pipeline

Design ingestion for a bank: 5 million documents across SharePoint and Confluence, about 20,000 changes per day, strict per-document permissions, personal data in many documents, and 15% scanned PDFs (forms).

**Solution (one good answer).**

- **Connectors**: change events (webhooks or change APIs) for content and permissions into a queue, plus a weekly full reconciliation; capture ACLs as group ids.
- **Parsing with routing**: text-layer parsing for born-digital files; a layout pipeline for complex documents; page-level OCR or VLM only for flagged scanned pages (about 15%), with output checks on numbers in forms.
- **Personal data**: detection on every document; policy-based handling per source (exclude, redact or restrict); an erasure workflow that deletes across stores, vectors and logs using stable ids.
- **Chunking and enrichment**: structure-aware chunks of about 300 to 500 tokens, heading path prefix, document summary prefix, metadata for business unit, document type, effective date and version.
- **Indexing**: hybrid (BM25 plus dense) with ACL fields filtered server-side; content-hash chunk ids and an embedding cache so 20,000 daily changes only re-embed changed chunks; permission updates as fast metadata-only writes.
- **Operations**: freshness lag SLO (for example under 15 minutes for permission changes, under 2 hours for content), canary documents, parse-failure dashboards by file type, and a dead-letter queue reviewed daily.

## Summary, cheat sheet and references

The one-sentence summary of Part 4: **parse faithfully, clean and deduplicate, split on the document's own structure, give every chunk the context it lacks, keep stable ids so updates and deletions are exact, and judge every choice by evidence recall and precision at a fixed prompt budget.**

### Ten things you should now be able to do

1. Design an ingestion pipeline with stored, versioned intermediates and idempotent stages.
2. Explain why PDFs are hard and route pages between text extraction, layout models and OCR or VLMs.
3. Handle tables by structure-preserving chunks, row linearisation, summaries or a SQL tool.
4. Remove boilerplate safely and detect near-duplicates with MinHash and LSH.
5. Handle personal data and support erasure.
6. Implement fixed, recursive, structure-aware and semantic chunkers that return spans.
7. Compute the overlap needed to contain evidence and its storage cost.
8. Apply heading prefixes, contextual retrieval, late chunking, parent-child retrieval and multiple representations, and know which problem each solves.
9. Update, delete and re-permission content incrementally with content-hash ids and reconciliation.
10. Evaluate chunking with character-level evidence metrics under a token budget.

### Cheat sheet

| Item | Rule or formula |
| --- | --- |
| Store intermediates | Raw file → parsed document → chunks, each versioned |
| Parser routing | Text layer for simple files; layout model for complex; OCR or VLM only for pages without text |
| Scanned-page check | Few extractable characters and a large image area |
| Boilerplate | Lines repeated on most pages, restricted to page margins |
| MinHash | P(minhashes equal) = Jaccard; LSH threshold ≈ (1/b)^(1/r) |
| Chunk size start | 256 to 512 tokens for prose QA, measured in the embedding model's tokens |
| Overlap | P(evidence inside one chunk) ≈ min(1, (C − e)/(C − o)); storage C/(C − o) |
| Fair comparison | Same prompt-token budget across strategies |
| Evidence metrics | Character-level recall, precision, IoU against gold spans |
| Cheap context | Title and heading path prefix on every chunk |
| Contextual retrieval | LLM situating sentence per chunk; reported −35% / −49% / −67% top-20 failures |
| Index small, return big | Children for matching, parents for the prompt |
| Stable ids | Source document id; chunk id = hash of content; embedding cache by text hash |
| Freshness | Change events + reconciliation; ACL changes as fast metadata updates |

### References

- Anthropic (September 2024). [Introducing Contextual Retrieval](https://www.anthropic.com/news/contextual-retrieval).
- Günther et al. (2024). [Late Chunking: Contextual Chunk Embeddings Using Long-Context Embedding Models](https://arxiv.org/abs/2409.04701).
- Qu, Tu and Bao (2024). [Is Semantic Chunking Worth the Computational Cost?](https://arxiv.org/abs/2410.13070)
- Chen et al. (2023). [Dense X Retrieval: What Retrieval Granularity Should We Use?](https://arxiv.org/abs/2312.06648) (propositions).
- Nogueira et al. (2019). [Document Expansion by Query Prediction](https://arxiv.org/abs/1904.08375) (doc2query).
- Auer et al. (2024). [Docling Technical Report](https://arxiv.org/abs/2408.09869).
- Ouyang et al. (2024). [OmniDocBench](https://arxiv.org/abs/2412.07626), a benchmark for document parsing.
- Broder (1997). On the Resemblance and Containment of Documents (MinHash); Leskovec, Rajaraman and Ullman, Mining of Massive Datasets, chapter 3 (locality-sensitive hashing).
- Microsoft Presidio, an open-source toolkit for detecting and anonymising personal data.

### Coming in Part 5: The query side

Part 5 turns from documents to questions. You will implement query rewriting, multi-query and HyDE, query decomposition for multi-part questions, routing between indexes and tools, and filter extraction from natural language; rerank with cross-encoders and LLM rerankers; build prompts with ordering, compression and citations; handle conversations and follow-up questions; and measure each technique's gain and latency cost.
