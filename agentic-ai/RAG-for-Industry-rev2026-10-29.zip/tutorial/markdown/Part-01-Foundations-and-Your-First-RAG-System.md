# RAG for Industry, Part 1: Foundations and Your First RAG System

Oct 28, 2026 · @Behi · revised 29 October 2026 (see CHANGELOG.md)

## How to use this guide

This is Part 1 of an 11-part, self-study guide to Retrieval-Augmented Generation (RAG). By the end of Part 1 you will understand why RAG exists, how every component fits together, and you will have built and evaluated a working RAG system from scratch on a free GPU.

**Who it is for.** Recent engineering graduates who know classical machine learning (train/test splits, overfitting, logistic regression, precision and recall) and linear algebra (vectors, dot products, norms, matrix multiplication). You do not need prior experience with large language models (LLMs). Everything you need about LLMs is taught in Chapter 2.

**Two career tracks, one guide.** Industry hires for RAG under two broad titles. Both tracks share Parts 1 to 6 and 8 to 11; Part 7 goes deeper for the ML track.

| Track | Typical titles | What you do day to day | Where this guide focuses |
| --- | --- | --- | --- |
| Application track | AI engineer, LLM engineer, applied AI engineer, software engineer (GenAI) | Build pipelines, choose models and databases, write prompts, evaluate, ship and monitor | Parts 4, 5, 6, 8, 9, 10 |
| ML track | ML engineer, applied scientist, search/relevance engineer | Train and fine-tune retrievers and rerankers, design evaluation, optimise indexes | Parts 2, 3, 6, 7 |

**The 11 parts.**

1. Foundations and your first RAG system (this part)
2. Embeddings: the representation layer
3. Search and indexing: BM25, approximate nearest neighbours, hybrid search
4. Ingestion and chunking
5. The query side: rewriting, routing, reranking, prompting, citations
6. Evaluation of retrieval and generation
7. Training and fine-tuning retrievers, rerankers and generators
8. Advanced architectures: agentic RAG, GraphRAG, multimodal RAG
9. Production: latency, cost, security, observability
10. Frameworks: LangChain/LangGraph, LlamaIndex, and others
11. Interview preparation: system design, question bank, portfolio project

**How to study each part.** Read a chapter, run its code, then close the guide and explain the chapter aloud in two minutes as if to an interviewer. Attempt every exercise before reading its solution. The interview questions are written the way real interviewers ask them; practise answering out loud with a timer.

**Fast track (about four weeks, 12 to 15 hours a week).** The full guide is a 120 to 160 hour course. If you have an interview in a month, read these chapters first and come back for the rest: Part 1 (all); Part 2 Chapters 1, 2, 4, 6 and Lab 3; Part 3 Chapters 1, 3, 4, 6 and Labs 1, 4, 5; Part 4 Chapters 2, 4, 5 and Lab 4; Part 5 Chapters 1, 2, 4, 5, 6 and Lab 8; Part 6 Chapters 2, 3, 4, 5, 6 and Labs 1, 2; Part 7 Chapters 1 and 6 only (ML track: all of Part 7); Part 8 Chapters 1, 2, 6 and Lab 1; Part 9 Chapters 1, 2, 3, 5 and Lab 2; Part 10 Chapters 1 and 6; Part 11 (all). Every part's interview questions and cheat sheet are short enough to read in full.

**Conventions.** Vectors are written as lower-case letters (q for a query vector, d for a document vector) and matrices as upper-case letters (E for the embedding matrix). The symbol k means "how many results we retrieve". Code is Python 3.10 or later. Prose uses British spelling (normalise, optimise); code keeps each library's own names (`normalize_embeddings`).

**What has been verified, and what has not.** Every pure-Python cell in the guide (metrics, BM25, RRF, IVF and PQ from scratch, chunkers, caches, statistics, agent loops with a scripted model, MCP, LangGraph, the deployment service, text-to-SQL and the PostgreSQL hybrid query) was executed in a sandbox. Cells that download models or datasets from Hugging Face have **not** been executed on a GPU; their APIs were checked against the libraries' source code and documentation (sentence-transformers 6.x, transformers 5.x, TRL, PEFT, and the framework versions listed in Part 10), and the Qwen chat template was rendered from its published configuration. Expected results in those labs are therefore stated as expectations, not measurements: record your own numbers, and if a cell fails, check the library's migration guide first, because renames are the most common cause. The `CHANGELOG.md` in the bundle lists exactly which claims were re-verified on 29 October 2026.

**Companion code and versions.** A shared module, `ragkit.py`, contains the Nimbus corpus, evaluation sets, chunkers, retrieval helpers, metrics, statistics and data loaders used across the parts. Every notebook starts with a cell that imports it (`from ragkit import *`), so you never have to paste cells from an earlier part; upload `code/ragkit.py` to the notebook's working directory first. The `requirements/` folder holds one requirements file per part with the version ranges the code was written against; all parts use the same core pair, **sentence-transformers 6.x with transformers 5.x** (sentence-transformers 6.0 requires transformers 5), so that the libraries do not change from one part to the next. After you have run a part successfully, freeze the exact versions with `pip freeze` and keep that file with your notes.

**Lab guide.** Times are rough estimates for a first pass on a free T4.

| Part | GPU needed? | Time | Without a GPU |
| --- | --- | --- | --- |
| 1 | For generation (Qwen3-4B, about 8 GB) | 1 hour | Retrieval runs on CPU; use Qwen2.5-1.5B-Instruct for generation, slowly |
| 2 | For Qwen3-Embedding and full SciFact runs | 1.5 to 2 hours | bge-small only, on a SciFact subset |
| 3 | No | 1.5 hours | Everything runs on CPU |
| 4 | Only Lab 5 (contextual retrieval) | 2 hours | Skip Lab 5 |
| 5 | For LLM steps (rewriting, HyDE, LLM reranking) | 2 hours | Cross-encoder reranking and the pure-Python parts |
| 6 | For the LLM judges | 2 hours | Metrics and statistics labs |
| 7 | Yes | 2 to 3 hours | Not practical beyond data preparation |
| 8 | For the real agent | 2 hours | MCP, LangGraph wiring and graph algorithms with a scripted model |
| 9 | For the injection and tracing labs | 1.5 hours | Calculators, caches and the three appendices |
| 10 | Recommended | 2 hours | Retrieval pipelines run slowly on CPU; DSPy needs an LLM |
| 11 | No | Varies | Everything |

### Environment setup (Google Colab or Kaggle)

All code in this guide runs on a free Colab or Kaggle notebook with an NVIDIA T4 GPU (16 GB of memory). In Colab choose Runtime → Change runtime type → T4 GPU. In Kaggle choose Settings → Accelerator → GPU T4.

Run this cell first in every new notebook:

```python
!pip install -q -U "sentence-transformers>=6.0,<7" "transformers>=5.0,<6" accelerate

import torch
print("GPU available:", torch.cuda.is_available())
if torch.cuda.is_available():
    print(torch.cuda.get_device_name(0))
```

### The models we use, and why

We use free, open-weight models downloaded from the Hugging Face Hub, so you need no API keys and pay nothing.

| Role | Default model | Size | Why this one |
| --- | --- | --- | --- |
| Embedding (retriever) | [BAAI/bge-small-en-v1.5](https://huggingface.co/BAAI/bge-small-en-v1.5) | 33M parameters, 384 dimensions | Tiny, fast even on CPU, well understood; ideal for learning |
| Embedding (upgrade) | [Qwen/Qwen3-Embedding-0.6B](https://huggingface.co/Qwen/Qwen3-Embedding-0.6B) | 0.6B parameters, 1024 dimensions, 32K context | Much stronger, multilingual, uses a query instruction |
| Generator (LLM) | [Qwen/Qwen3-4B-Instruct-2507](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507) | 4B parameters, about 8 GB in float16 | Fits a T4, Apache 2.0 licence, follows instructions well, no hidden "thinking" output |
| Generator (CPU fallback) | Qwen/Qwen2.5-1.5B-Instruct | 1.5B parameters | Runs slowly but acceptably without a GPU |
| Generator (upgrade, 24 GB GPU) | [google/gemma-4-E4B-it](https://huggingface.co/google/gemma-4-E4B-it) | about 4B effective parameters (about 8B stored, with per-layer embeddings), text, image and audio input | Google's small Gemma 4 model (released 2 April 2026, Apache 2.0). It is trained in bfloat16 and loads through `AutoModelForMultimodalLM` with an `AutoProcessor`; vLLM's recipe lists a 24 GB GPU for bfloat16 serving, so use it on an L4 or A100 rather than the free T4 |

Open models move fast. Newer small families released in 2026, such as Qwen3.5 and Google's Gemma 4, are stronger than the Qwen3-4B default used in the labs. We keep Qwen3-4B-Instruct-2507 as the default for three practical reasons: it is a text-only causal LM with the standard `AutoModelForCausalLM` loader, it runs in float16 on the T4 (which has no fast bfloat16), and its tool-calling chat template is the one the Part 8 agent parser was written for. Every code cell keeps the model name in one variable, so you can swap models by changing one line. When you swap, always read the new model's Hugging Face card: some models need a specific loader class (Gemma 4 does), a query prefix, or a flag to turn off a "thinking" mode (Chapter 2.9).

> Interview tip: interviewers rarely care which exact model you used. They care that you can justify the choice on quality, latency, memory, licence and cost, and that you measured it.

## Chapter 1. The problem RAG solves

Retrieval-Augmented Generation (RAG) means: before an LLM answers, a retriever fetches relevant text from an external knowledge source, and that text is inserted into the LLM's input so the answer is grounded in it. It turns a closed-book exam into an open-book exam.

### 1.1 Why a plain LLM is not enough

An LLM stores what it learned during training inside its weights. Researchers call this **parametric memory**. Parametric memory has six limitations that matter in industry.

1. **Knowledge cutoff.** The model knows nothing after its training data was collected. Prices, policies and news change daily.
2. **No private data.** The model never saw your company's wiki, tickets, contracts or code.
3. **Hallucination.** When the model lacks knowledge, it often produces fluent, confident, wrong text instead of saying "I don't know".
4. **No provenance.** You cannot ask the weights where a fact came from, so users and auditors cannot verify answers.
5. **Expensive updates.** Changing a fact in the weights requires fine-tuning, which is slow, costly, and can damage other abilities.
6. **No access control.** Everything in the weights is visible to every user. You cannot hide salary data from one employee and show it to another.

RAG adds **non-parametric memory**: an external index you can read, update, delete from and permission at any time. Each limitation above maps to a RAG answer: fresh index, private documents, grounding, citations, cheap re-indexing, and per-user filtering at retrieval time.

### 1.2 A one-paragraph definition you can say in an interview

"RAG is an architecture where a retrieval system selects the most relevant pieces of an external corpus for a user query, and a generative model conditions on those pieces to produce the answer. It separates knowledge, which lives in an updatable index, from reasoning and language ability, which live in the model. That gives fresher, more verifiable answers with access control, without retraining the model."

### 1.3 A short history

The idea of combining retrieval with a reader is older than LLMs (open-domain question answering systems retrieved Wikipedia passages in the 2010s). The modern term comes from 2020.

| Year | Milestone | Why it matters |
| --- | --- | --- |
| 2020 | REALM (Google) and DPR, Dense Passage Retrieval (Facebook AI) | Showed learned dense vectors can beat keyword search for question answering |
| 2020 | RAG paper by Lewis et al. (Facebook AI), "Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks" | Coined the name; trained a DPR retriever and a BART generator end to end |
| 2020 to 2022 | Fusion-in-Decoder, RETRO (DeepMind), Atlas (Meta) | Showed small models plus retrieval can match much larger models on knowledge tasks |
| 2023 | ChatGPT-era "naive RAG": chunk, embed, store in a vector database, retrieve top-k, prompt | Became the default way companies put LLMs on their own data |
| 2024 | "Advanced RAG": hybrid search, rerankers, query rewriting; Microsoft GraphRAG; Anthropic's Contextual Retrieval; Model Context Protocol (MCP) | Quality engineering of each stage became the job |
| 2025 to 2026 | Agentic RAG and deep-research agents; million-token context windows; "context engineering" | Retrieval became a tool an agent calls repeatedly, not a single fixed step |

Note a change in meaning. The 2020 paper trained retriever and generator jointly. In industry today, "RAG" almost always means a **pipeline** of separately chosen components (an off-the-shelf embedding model, a search index, a prompted LLM) with no joint training. Interviewers expect you to know both.

### 1.4 Where RAG is used in industry

- **Customer support assistants** answer from help-centre articles and past tickets.
- **Enterprise search and copilots** answer employees from wikis, drives, chat and email, respecting permissions.
- **Coding assistants** retrieve relevant files, functions and documentation from large repositories.
- **Regulated domains** (legal, finance, healthcare) need citations to the exact clause or guideline.
- **Research agents** search the web or internal databases in many rounds and write a cited report.

### 1.5 Is RAG obsolete now that context windows hold a million tokens?

No, and you will be asked this. Long context and RAG are complementary. A corpus of millions of documents does not fit in any window; putting everything in the window costs money and latency on every query; models get less accurate as you add irrelevant text; and you still need permissions and citations. What has changed is that retrieval can now be coarser (whole documents instead of small chunks) and that agents often decide when and what to retrieve. Chapter 4 gives the full decision framework.

## Chapter 2. LLM essentials a RAG engineer must know

You do not need to train an LLM to build RAG, but you must understand eight properties of LLMs, because each one drives a design decision in your pipeline.

### 2.1 Tokens

LLMs read and write **tokens**, not characters or words. A tokenizer (usually byte-pair encoding, BPE) splits text into frequent sub-word pieces: "retrieval" may be one token, "Nimbus-7X" may be four. A rough rule for English is 1 token ≈ 4 characters ≈ 0.75 words. Code, numbers and non-English text use more tokens per word.

Tokens matter for RAG because chunk sizes, context budgets, cost and latency are all measured in tokens. Always count with the tokenizer of the model you actually use:

```python
from transformers import AutoTokenizer
tok = AutoTokenizer.from_pretrained("Qwen/Qwen3-4B-Instruct-2507")
text = "Retrieval-Augmented Generation grounds answers in documents."
ids = tok(text)["input_ids"]
print(len(ids), tok.convert_ids_to_tokens(ids))
```

### 2.2 Autoregressive generation

A decoder-only LLM generates one token at a time. Given input x and the tokens generated so far, it outputs a probability distribution over its vocabulary and picks the next token. The probability of a whole answer y = (y1, ..., yT) factorises as:

```latex
p(y \mid x) = \prod_{t=1}^{T} p(y_t \mid x, y_{<t})
```

The model produces a score (logit) z\_i for every vocabulary token i. Temperature T rescales the logits before the softmax:

```latex
p_i = \frac{\exp(z_i / T)}{\sum_j \exp(z_j / T)}
```

T → 0 approaches greedy decoding (always the most likely token). T = 1 samples from the model's raw distribution. Top-p (nucleus) sampling keeps only the smallest set of tokens whose probabilities sum to p. For RAG question answering, use greedy decoding or a low temperature (0 to 0.3): you want faithful, repeatable answers, not creativity.

### 2.3 Attention and why long prompts cost more

Inside each Transformer layer, self-attention lets every token look at every earlier token:

```latex
\mathrm{Attention}(Q, K, V) = \mathrm{softmax}\!\left(\frac{QK^\top}{\sqrt{d_k}}\right) V
```

For a sequence of n tokens, QKᵀ is an n × n matrix, so attention compute grows as O(n²) in the prompt length. During generation the model stores every past token's keys and values (the **KV cache**), whose memory grows linearly in n. This is the mechanism that lets the model read your retrieved documents, and also the reason every extra retrieved chunk costs compute and memory.

### 2.4 Prefill and decode: the two phases of inference

Serving an LLM request has two phases with different costs.

- **Prefill** processes the whole prompt (system prompt, retrieved context, question) in parallel. It is compute-bound and determines **time to first token (TTFT)**. More retrieved context means longer prefill.
- **Decode** generates output tokens one by one. It is memory-bandwidth-bound and determines **time per output token (TPOT)**.

A useful latency model is:

```latex
\text{latency} \approx \text{TTFT} + n_{\text{out}} \times \text{TPOT}
```

API pricing mirrors this: you pay per input token and per output token, with output tokens usually several times more expensive. Many providers and serving engines also offer **prompt caching**, which makes a repeated prompt prefix (for example a fixed system prompt) much cheaper and faster. Put stable content first and variable content (retrieved chunks, the question) last to benefit from it.

### 2.5 Context window and the token budget

The **context window** is the maximum number of tokens (input plus output) a model can handle in one request: commonly 32K to 256K for open models and up to about 1M or more for some frontier models in 2026. In RAG you allocate this budget explicitly:

```latex
k_{\max} = \left\lfloor \frac{W - S - Q - R}{C} \right\rfloor
```

where W is the window, S the system prompt, Q the question, R the tokens reserved for the answer, and C the tokens per chunk. With W = 32,000, S = 500, Q = 100, R = 1,000 and C = 400, k\_max = 76. In practice you use far fewer (often 3 to 20), for the reasons in 2.8.

### 2.6 Chat templates and roles

Instruction-tuned ("chat" or "instruct") models are fine-tuned on conversations with roles: **system** (standing instructions), **user**, and **assistant**. Each model family wraps these roles in its own special tokens, called a **chat template**. If you format the prompt by hand and get the template wrong, quality drops silently. Always use the tokenizer's template:

```python
messages = [
    {"role": "system", "content": "Answer only from the context."},
    {"role": "user", "content": "Context: ...\n\nQuestion: ..."},
]
prompt_text = tok.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
print(prompt_text)  # shows the exact special tokens the model expects
```

A **base** model (not instruction-tuned) only continues text and does not follow instructions reliably. Use instruct models for RAG generation.

### 2.7 In-context learning and knowledge conflicts

LLMs can use information that appears in the prompt even if they never saw it in training. This **in-context learning** is the entire mechanism RAG relies on: we place facts in the prompt and the model uses them.

It is not perfect. When the retrieved context contradicts what the model "believes" from training, the model may ignore the context (over-trusting parametric memory) or follow a wrong document (over-trusting context). These **knowledge conflicts** are why RAG prompts tell the model explicitly to prefer the context and to say when the context is insufficient, and why retrieval quality matters so much.

### 2.8 Hallucination and long-context degradation

An LLM is trained to produce plausible next tokens, not true ones. When it lacks information it tends to produce plausible-sounding fabrications: a **hallucination**. In RAG we care about a specific kind: an answer that is not supported by the retrieved context, called an **unfaithful** or **ungrounded** answer. RAG reduces hallucination but does not remove it; Part 6 shows how to measure it.

More context is not automatically better. The "Lost in the Middle" study (Liu et al., 2023; published in TACL 2024) found that models used relevant information best when it sat at the start or end of a long prompt and worst when it sat in the middle, giving a U-shaped accuracy curve. Later work, including Chroma's 2025 "context rot" report, found that accuracy tends to fall as input length grows, even on simple tasks. Practical consequences for RAG:

- Retrieve fewer, better chunks; precision beats volume.
- Put the most relevant chunks first (or first and last).
- Remove near-duplicate chunks; they waste budget and distract.
- Test long-context behaviour on your own data, because simple "needle in a haystack" benchmarks overstate it.

### 2.9 Reasoning ("thinking") models and RAG

Many 2025 and 2026 models can emit a hidden or visible chain of reasoning before the answer (Qwen3's thinking mode, Gemma 4's thinking mode, DeepSeek-R1-style models, and the reasoning tiers of the commercial APIs). Four things matter for RAG:

- **Cost and latency.** Thinking tokens are output tokens: they are billed at the output price and generated one at a time, so a reasoning model can take several times longer to start the visible answer. For single-hop lookup questions, thinking rarely improves grounded answers and often doubles cost; turn it off (most templates have an `enable_thinking=False` flag or a non-thinking model variant, which is why this guide uses the `-Instruct-2507` variant of Qwen3) or route only hard, multi-step questions to a reasoning model (Part 5, routing; Part 9, cascades).
- **Where thinking helps.** Multi-hop questions, questions that need arithmetic over retrieved numbers, conflict resolution between sources, and agentic retrieval where the model must decide what to search next (Part 8). Measure it on your evaluation set like any other component.
- **Parsing.** Strip the reasoning block (for example `<think>...</think>`) before citation checks and before showing the answer, and never treat text inside it as a citation.
- **Faithfulness still needs checking.** A visible chain of thought is not a proof that the answer was derived from the retrieved sources; apply the same verification as for any model (Parts 5 and 6).

## Chapter 3. Anatomy of a RAG system

Every RAG system is two pipelines that share one index: an offline **indexing pipeline** that turns documents into searchable units, and an online **query pipeline** that turns a question into a grounded answer. Quality problems almost always trace back to one specific stage, so learn the stages by name.

![RAG architecture: the indexing and query pipelines around one index](../diagrams/p01_rag_architecture.svg)

*RAG architecture: the indexing and query pipelines around one index*

The index is the only thing the two pipelines share: the left side writes to it whenever documents change, and the right side reads from it on every request.

### 3.1 The two pipelines

**Indexing pipeline (offline, runs when documents change):**

1. **Load** documents from their sources (files, databases, web pages, APIs).
2. **Parse and clean**: extract text, tables and structure; drop boilerplate such as navigation menus.
3. **Chunk**: split documents into retrievable units (for example 200 to 800 tokens) and attach metadata (source, title, date, permissions).
4. **Embed**: map each chunk to a vector with an embedding model.
5. **Store**: write vectors, text and metadata into an index (a vector database, a search engine, or both).

**Query pipeline (online, runs per request):**

1. **Process the query**: optionally rewrite, expand, or route it.
2. **Retrieve**: embed the query and fetch the top-k most similar chunks, applying metadata filters such as permissions.
3. **Rerank** (optional but common): rescore the candidates with a more accurate, slower model and keep the best few.
4. **Augment**: build the prompt from instructions, the selected chunks, and the question.
5. **Generate**: the LLM writes the answer, ideally with citations to chunk ids.
6. **Post-process**: validate citations, apply safety checks, log everything for evaluation.

### 3.2 Vocabulary

| Term | Meaning |
| --- | --- |
| Corpus | The whole collection of documents you can retrieve from |
| Chunk (passage, node) | A retrievable piece of a document; the unit you index and put in the prompt |
| Embedding | A fixed-length vector representing the meaning of a text |
| Index | A data structure that makes search fast (inverted index for keywords, vector index for embeddings) |
| Retriever | The component that returns candidate chunks for a query |
| Reranker | A slower, more accurate scorer applied to the retriever's candidates |
| Generator | The LLM that writes the answer |
| Grounding | The degree to which an answer is supported by the retrieved context |
| Top-k | The number of chunks returned at a stage |

### 3.3 The probabilistic view

Treat the retrieved document z as a latent variable. A retrieval-augmented model answers x with y by marginalising over documents:

```latex
p(y \mid x) = \sum_{z \in \mathcal{Z}} p_\eta(z \mid x)\, p_\theta(y \mid x, z)
```

Here p\_η(z | x) is the retriever and p\_θ(y | x, z) is the generator. Summing over the whole corpus is impossible, so we approximate the sum with the top-k documents. In the original RAG paper, the retriever is a softmax over similarity scores:

```latex
p_\eta(z \mid x) \propto \exp\big(s(x, z)\big), \qquad s(x, z) = E_q(x)^\top E_d(z)
```

where E\_q and E\_d are query and document encoders. Lewis et al. defined two variants. **RAG-Sequence** uses the same document for the whole answer and marginalises at the end. **RAG-Token** can draw on a different document for each generated token.

Industry pipelines usually do something simpler: they concatenate the top-k chunks into one prompt and generate p\_θ(y | x, z\_1, ..., z\_k). The model then decides internally which chunks to use. This view still teaches two key lessons. First, if the right document is not in the top-k, the generator cannot recover it, so **retrieval recall bounds answer quality**. Second, the answer can only be as faithful as the generator's use of the context, so **generation faithfulness** is a separate quality to measure.

### 3.4 Retrieval as nearest-neighbour search

Dense retrieval scores every chunk vector d against the query vector q and returns the k highest. Three similarity functions are common:

```latex
\text{dot}(q,d) = q^\top d, \qquad \cos(q,d) = \frac{q^\top d}{\lVert q\rVert\,\lVert d\rVert}, \qquad \text{L2}(q,d) = \lVert q - d\rVert_2
```

If all vectors are normalised to unit length, the three give the **same ranking**, because:

```latex
\lVert q - d\rVert^2 = \lVert q\rVert^2 + \lVert d\rVert^2 - 2\,q^\top d = 2 - 2\cos(q,d)
```

This is why most systems normalise embeddings and then use the cheap dot product. If vectors are not normalised, dot product rewards long vectors. Worked example with q = (0.6, 0.8), d1 = (1, 0), d2 = (0.8, 0.6), d3 = (0, 2):

| Chunk | Dot product | Cosine | Rank by dot | Rank by cosine |
| --- | --- | --- | --- | --- |
| d1 = (1, 0) | 0.60 | 0.60 | 3 | 3 |
| d2 = (0.8, 0.6) | 0.96 | 0.96 | 2 | 1 |
| d3 = (0, 2) | 1.60 | 0.80 | 1 | 2 |

The rankings disagree only because d3 has length 2. Always check whether your embedding model expects normalisation; its model card will say.

In matrix form, with all N chunk vectors stacked as rows of E (N × d), the scores for one query are a single matrix-vector product, s = Eq, costing O(N·d). For N = 10 million chunks and d = 1,024 dimensions this is about 10 billion multiply-adds per query, and storing E in 32-bit floats takes about 41 GB. That is why large systems use approximate nearest neighbour (ANN) indexes and vector quantization, covered in Part 3. Below roughly a few hundred thousand vectors, exact search with NumPy or a GPU is often fast enough.

### 3.5 Sparse, dense and hybrid retrieval

**Sparse (lexical) retrieval** represents text as weighted word counts over a large vocabulary, for example TF-IDF or BM25. It excels at exact matches: product codes, names, error messages, rare terms. **Dense (semantic) retrieval** uses learned embeddings and excels at paraphrase: "How do I get my money back?" matches "refund policy". Each fails where the other succeeds, so production systems typically combine them (**hybrid search**). Part 3 derives BM25 and fusion methods.

### 3.6 Bi-encoders and cross-encoders

An embedding model is a **bi-encoder**: it encodes query and document separately, so document vectors can be computed once, offline. A **cross-encoder** reads the query and a document together and outputs one relevance score. It is more accurate, because every query token can attend to every document token, but it must run for every (query, document) pair at query time. The standard pattern is therefore **retrieve-then-rerank**: a bi-encoder (plus keyword search) narrows millions of chunks to about 50 to 200 candidates, then a cross-encoder picks the best 3 to 10. Part 2 covers the training math; Part 5 covers reranking in practice.

### 3.7 Naive, advanced, modular and agentic RAG

The 2023 survey by Gao et al. popularised three labels, and practitioners added a fourth:

- **Naive RAG**: chunk, embed, retrieve top-k, prompt. The system you build in Chapter 5.
- **Advanced RAG**: adds pre-retrieval steps (query rewriting) and post-retrieval steps (reranking, compression) around the same linear flow.
- **Modular RAG**: treats each stage as a swappable module, with routing and branching between them.
- **Agentic RAG**: an LLM agent decides whether to retrieve, which tool or index to query, and whether the evidence is sufficient, looping until done. Part 8 covers it.

## Chapter 4. RAG vs fine-tuning vs long context vs tools

The rule of thumb interviewers want to hear: **RAG gives a model knowledge; fine-tuning changes its behaviour.** Long context and tool calls are two further ways to get information into the model, and real systems usually combine several.

### 4.1 The options

- **Prompting alone**: write better instructions and a few examples. Always try this first; it is free and fast to iterate.
- **RAG**: retrieve relevant text per query and put it in the prompt.
- **Long context ("stuff it all in")**: put the whole corpus, or whole documents, in the prompt, often with prompt caching.
- **Fine-tuning**: update model weights on examples (full fine-tuning or parameter-efficient methods such as LoRA).
- **Tools / function calling**: let the model call an API, a SQL database, or a search engine and read the result. Retrieval is itself one kind of tool.

### 4.2 Comparison

| Need | RAG | Long context | Fine-tuning | Tools (API, SQL) |
| --- | --- | --- | --- | --- |
| Fresh or frequently changing facts | Strong: re-index in minutes | Strong if the corpus is small | Weak: retrain for each change | Strong: queries live data |
| Very large corpus (millions of docs) | Strong | Impossible beyond the window | Weak: cannot memorise reliably | Depends on the system |
| Citations and auditability | Strong | Moderate | Weak | Strong |
| Per-user access control | Strong: filter at retrieval | Weak: everyone sees the prompt | None | Strong |
| New output format, style, tone, or domain jargon | Weak | Weak | Strong | Weak |
| A new skill (e.g. a domain-specific classification) | Weak | Moderate (few-shot) | Strong | Weak |
| Exact numbers from structured data ("Q3 revenue by region") | Weak: tables embed poorly | Weak | Weak | Strong: text-to-SQL or API |
| Per-query cost and latency | Low to moderate | High for large contexts unless cached | Lowest at inference | Moderate |
| Upfront engineering effort | Moderate | Lowest | High (data, training, evaluation) | Moderate |

### 4.3 A decision procedure

1. Is the problem missing **knowledge** or wrong **behaviour**? Knowledge points to RAG, long context or tools. Behaviour (format, tone, following a schema, a narrow skill) points to prompting, then fine-tuning.
2. Is the knowledge **structured** (rows, metrics, inventory)? Use a tool that queries the system of record, not embeddings.
3. Does the relevant corpus fit comfortably in the context window, change rarely, and serve few queries? Try long context with prompt caching first; it is the simplest baseline.
4. Otherwise use RAG. Add permissions filtering if users have different access rights.
5. If RAG answers are grounded but badly formatted, or the model misuses context, consider fine-tuning the generator on RAG-style examples (Part 7 covers RAFT, Retrieval-Augmented Fine-Tuning).
6. If retrieval misses domain-specific matches, consider fine-tuning the embedding model or a reranker (Part 7).

### 4.4 Three quick scenarios

- A bank wants a chatbot that answers from 40,000 policy documents updated weekly, with different access per department. **RAG with metadata filtering**, because the corpus is large, changes often, and needs permissions and citations.
- A startup wants its model to always reply in a fixed JSON schema in its brand voice. **Prompting, then fine-tuning**, because this is behaviour, not knowledge.
- A sales team asks "What were last month's top 5 customers by revenue?" **A text-to-SQL tool** against the data warehouse, because the answer is an aggregation over structured rows that no retrieved text chunk contains.

> Interview tip: never answer "RAG or fine-tuning?" with one word. State the knowledge-versus-behaviour distinction, ask what changes and how often, mention access control and citations, and say you would start with the cheapest baseline and measure.

## Chapter 5. Build a minimal RAG system from scratch

In this chapter you build a complete RAG system in about 150 lines of plain Python, with no RAG framework, and measure it. Building it by hand first is what lets you debug framework-based systems later, and "walk me through how you would build RAG from scratch" is a very common interview question.

The knowledge base is a fictional company, Nimbus Robotics. Because the company does not exist, the LLM cannot know the answers from training, so you will see clearly what retrieval adds.

Run each step as its own notebook cell, in order, after the setup cell from "How to use this guide".

### Step 1. Configuration

```python
import re, time
import numpy as np
import torch

EMBED_MODEL = "BAAI/bge-small-en-v1.5"
QUERY_PREFIX = "Represent this sentence for searching relevant passages: "  # from the bge model card
LLM_MODEL = "Qwen/Qwen3-4B-Instruct-2507"  # CPU only? use "Qwen/Qwen2.5-1.5B-Instruct"
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
```

Some embedding models are trained with an instruction prefix on queries (not on documents). bge-small-en-v1.5 recommends the prefix above for short retrieval queries. Qwen3-Embedding uses `prompt_name="query"` instead. Getting this wrong silently lowers retrieval quality, so always check the model card.

### Step 2. The corpus

In real projects this comes from loaders and parsers (Part 4). Here it is inline so the notebook is self-contained.

```python
CORPUS = [
    {"doc_id": "hr-leave", "title": "Paid Time Off and Leave Policy",
     "text": ("Full-time employees at Nimbus Robotics accrue 1.75 days of paid time off (PTO) per month, which is 21 days per year. "
              "PTO accrual starts on the first day of employment. "
              "Up to 5 unused PTO days can be carried over into the next calendar year. "
              "Carried-over days expire if they are not used by March 31. "
              "Requests for PTO must be submitted in Workday at least two weeks in advance for absences longer than three days. "
              "Primary caregivers receive 16 weeks of fully paid parental leave. "
              "Secondary caregivers receive 6 weeks of fully paid parental leave. "
              "Sick days are separate from PTO: every employee receives 8 paid sick days per year, and they do not carry over.")},
    {"doc_id": "hr-remote", "title": "Remote and Hybrid Work Policy",
     "text": ("Employees may work remotely up to three days per week, subject to manager approval. "
              "Core collaboration hours are 10:00 to 15:00 Eastern Time, Monday to Friday. "
              "Every employee receives a one-time home office stipend of 600 dollars to buy a desk, chair or monitor. "
              "Employees also receive 50 dollars per month toward home internet costs. "
              "Fully remote arrangements require approval from a vice president. "
              "Working from another country for more than 30 days in a year requires approval from the legal team because of tax rules.")},
    {"doc_id": "fin-expense", "title": "Travel and Expense Policy",
     "text": ("Expenses must be submitted in Expensify within 30 days of the purchase. "
              "An itemised receipt is required for any expense above 25 dollars. "
              "When travelling for work, meals are reimbursed up to 75 dollars per day. "
              "Book economy class for flights shorter than six hours. "
              "For flights of six hours or longer, premium economy is allowed. "
              "Any single expense above 500 dollars requires written approval from your manager before purchase. "
              "Alcohol is not reimbursable except at approved client events.")},
    {"doc_id": "it-security", "title": "Information Security Standards",
     "text": ("Passwords must be at least 14 characters long and must not be reused across systems. "
              "Multi-factor authentication with a hardware security key is required for any access to production systems. "
              "All company laptops use full-disk encryption, which must never be disabled. "
              "Suspected phishing emails must be reported to security@nimbus-robotics.example within one hour. "
              "Use the company VPN whenever you connect from a public network. "
              "Lost or stolen devices must be reported to the IT help desk immediately so they can be wiped remotely.")},
    {"doc_id": "prod-nx7", "title": "Nimbus NX-7 Warehouse Robot: Technical Specifications",
     "text": ("The Nimbus NX-7 is an autonomous mobile robot for warehouse picking and transport. "
              "It carries a maximum payload of 150 kilograms. "
              "Its battery lasts up to 8 hours of continuous operation. "
              "The battery recharges from 0 to 80 percent in 45 minutes using the NX Dock. "
              "Maximum travel speed is 2.0 metres per second, limited to 1.2 metres per second near people. "
              "Navigation uses a 360-degree lidar and two stereo cameras. "
              "The current firmware version is 4.2. "
              "The robot is rated for operating temperatures between 0 and 40 degrees Celsius.")},
    {"doc_id": "prod-nx7-errors", "title": "Nimbus NX-7 Troubleshooting Guide",
     "text": ("Error E-104 means the lidar is obstructed: clean the sensor window with a dry microfibre cloth and restart navigation. "
              "Error E-212 means the battery is overheating: stop the robot, move it to a cooler area, and contact support if the error persists for more than 30 minutes. "
              "Error E-330 means a wheel motor has stalled: check for debris around the wheels before resetting. "
              "Error E-415 means the robot lost its map localisation: drive it manually to a docking station to relocalise. "
              "For any error not listed here, collect the robot logs from the NX Console and open a support ticket.")},
    {"doc_id": "eng-oncall", "title": "Engineering On-Call Policy",
     "text": ("On-call duty rotates weekly, with handoff every Monday at 09:00 Eastern Time. "
              "The on-call engineer must acknowledge a SEV-1 page within 15 minutes. "
              "SEV-2 pages must be acknowledged within one hour. "
              "Engineers receive 400 dollars of extra compensation for each week of on-call duty. "
              "If you are paged between midnight and 06:00, you may start work late the next day. "
              "Every incident must have a written post-incident review within five business days.")},
    {"doc_id": "company-about", "title": "About Nimbus Robotics",
     "text": ("Nimbus Robotics was founded in 2019 in Waterloo, Ontario. "
              "The company builds autonomous robots for warehouses and logistics centres. "
              "It has about 450 employees across offices in Waterloo, Montreal and Boston. "
              "The chief executive officer is Dana Whitfield. "
              "The company's mission is to make warehouse work safer by automating heavy and repetitive tasks.")},
]
print(len(CORPUS), "documents")
```

### Step 3. Chunking

We split each document into sentences, then pack whole sentences into chunks of at most about 60 words, repeating the last sentence of one chunk at the start of the next (**overlap**) so a fact that spans a boundary is not lost. Real systems use 200 to 800 tokens; our documents are tiny, so we use small chunks to force the retriever to choose. Each chunk keeps its document id and title as **metadata**.

```python
def split_sentences(text):
    # Split after . ! or ? followed by whitespace. "1.75" is safe: no space after the dot.
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]

def chunk_document(doc, max_words=60, overlap_sentences=1):
    sentences = split_sentences(doc["text"])
    groups, current = [], []
    for sent in sentences:
        n_words = sum(len(s.split()) for s in current) + len(sent.split())
        if current and n_words > max_words:
            groups.append(current)
            # carry the last sentence(s) over; note current[-0:] would copy the whole list
            current = current[-overlap_sentences:] if overlap_sentences > 0 else []
        current.append(sent)
    if current:
        groups.append(current)
    return [{"chunk_id": f"{doc['doc_id']}#{i}", "doc_id": doc["doc_id"],
             "title": doc["title"], "text": " ".join(sents)}
            for i, sents in enumerate(groups)]

chunks = [c for doc in CORPUS for c in chunk_document(doc)]
print(len(chunks), "chunks")      # 17 with the corpus above
for c in chunks[:3]:
    print(c["chunk_id"], "|", c["text"][:80])
```

This chunker has a deliberate limitation: `max_words` is a target, not a guarantee. A single sentence longer than the limit, or an overlap sentence plus a long new sentence, produces an oversized chunk. Exercise 8 asks you to find and fix it.

### Step 4. Embed and index the chunks

We prepend each chunk's title before embedding. This cheap trick gives every chunk context it would otherwise lack (a chunk saying "It carries 150 kilograms" does not say what "it" is). Part 4 generalises this into contextual retrieval.

```python
from sentence_transformers import SentenceTransformer

embedder = SentenceTransformer(EMBED_MODEL, device=DEVICE)
chunk_texts = [f"{c['title']}\n{c['text']}" for c in chunks]
E = embedder.encode(chunk_texts, normalize_embeddings=True,
                    convert_to_numpy=True, batch_size=32)
print(E.shape)   # (17, 384): 17 chunks, 384 dimensions
print(np.linalg.norm(E, axis=1)[:3])   # all 1.0: unit vectors, so dot product = cosine
```

Our "vector database" is the NumPy matrix E plus the list `chunks`, aligned by row index. That is all a vector store fundamentally is; production systems add persistence, ANN indexes, filtering and replication.

### Step 5. Retrieve

```python
def retrieve(query, k=3):
    q = embedder.encode([QUERY_PREFIX + query], normalize_embeddings=True,
                        convert_to_numpy=True)[0]
    scores = E @ q                       # cosine similarity with every chunk, O(N*d)
    top = np.argsort(-scores)[:k]        # for large N use np.argpartition, O(N)
    return [(chunks[i], float(scores[i])) for i in top]

def show(results):
    for c, s in results:
        print(f"{s:.3f}  {c['chunk_id']:<20} {c['text'][:70]}")

show(retrieve("Who runs the company?"))
show(retrieve("The robot shows E-212. What should I do?"))
```

The first query shares no keywords with "The chief executive officer is Dana Whitfield", yet dense retrieval should find it. Build the habit of printing what was retrieved for every query you debug; most RAG bugs are visible right here.

### Step 6. Load the generator

```python
from transformers import AutoTokenizer, AutoModelForCausalLM

if DEVICE == "cuda" and torch.cuda.get_device_capability()[0] >= 8:
    dtype = torch.bfloat16   # A100, L4, H100 and newer
elif DEVICE == "cuda":
    dtype = torch.float16    # T4 on free Colab/Kaggle has no fast bfloat16
else:
    dtype = torch.float32    # CPU

tok = AutoTokenizer.from_pretrained(LLM_MODEL)
llm = AutoModelForCausalLM.from_pretrained(LLM_MODEL, dtype=dtype, device_map="auto")

def generate(messages, max_new_tokens=300):
    inputs = tok.apply_chat_template(messages, add_generation_prompt=True,
                                     return_dict=True, return_tensors="pt").to(llm.device)
    with torch.no_grad():
        out = llm.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)  # greedy
    new_tokens = out[0, inputs["input_ids"].shape[1]:]   # drop the prompt tokens
    return tok.decode(new_tokens, skip_special_tokens=True).strip()
```

The 4B model needs about 8 GB of GPU memory in 16-bit precision, which fits a T4. On a CPU, switch `LLM_MODEL` to the 1.5B fallback. If you see a warning that sampling parameters such as temperature are ignored, that is expected: greedy decoding ignores them.

### Step 7. Augment: the prompt

The prompt does four jobs: restrict the model to the context, label each passage with an id, require citations, and define what to do when the answer is missing.

```python
SYSTEM_PROMPT = """You are an assistant for Nimbus Robotics employees.
Answer the question using ONLY the context passages provided.
After each claim, cite the passage id(s) you used in square brackets, for example [hr-leave#0].
If the context does not contain the answer, reply exactly:
"I don't know based on the provided documents."
Be concise."""

def build_messages(question, retrieved):
    context = "\n\n".join(f"[{c['chunk_id']}] (from: {c['title']})\n{c['text']}"
                          for c, _ in retrieved)
    user = f"Context passages:\n{context}\n\nQuestion: {question}"
    return [{"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user}]

def rag_answer(question, k=3):
    retrieved = retrieve(question, k)
    answer = generate(build_messages(question, retrieved))
    return answer, retrieved
```

The context goes in the user message after the instructions, and the question goes last, close to where generation starts. Fixed content first and variable content last also suits prompt caching (Chapter 2.4).

### Step 8. Closed-book versus RAG

```python
def closed_book(question):
    return generate([{"role": "user", "content": question}])

for q in ["How many PTO days do Nimbus Robotics employees get per year?",
          "What does error E-212 mean on the Nimbus NX-7 robot?"]:
    print("Q:", q)
    print("Closed book:", closed_book(q)[:300])
    t0 = time.time()
    answer, retrieved = rag_answer(q)
    print("RAG:", answer)
    print(f"({time.time() - t0:.1f} s)\n")
```

Without retrieval, the model can only guess about a company it has never seen: expect either an admission that it does not know or a confident invention (a hallucination). With retrieval, expect the correct figures with citations such as \[hr-leave#0\]. Exact wording varies by model and library version.

### Step 9. Measure it

Never ship a RAG system you have not measured. Even ten labelled questions catch most regressions. We measure two things separately, because they fail separately: **retrieval** (did the right document come back?) and **generation** (did the answer cite real, retrieved passages, and abstain when it should?).

**Retrieval metrics.** For each question we know the gold document. **Hit rate@k** (often called recall@k when there is one relevant document) is the fraction of questions whose gold document appears in the top k. **MRR@k** (mean reciprocal rank) averages 1/rank of the first correct result, or 0 if it is missing, so it rewards ranking the right document first. Part 6 covers these and nDCG in depth.

```python
EVAL_SET = [
    {"question": "How many vacation days do I get per year?", "gold_doc": "hr-leave"},
    {"question": "Can I carry unused PTO into next year?", "gold_doc": "hr-leave"},
    {"question": "How much money do I get to set up my home office?", "gold_doc": "hr-remote"},
    {"question": "What is the daily food allowance on a business trip?", "gold_doc": "fin-expense"},
    {"question": "Do I need a receipt for a 20 dollar taxi ride?", "gold_doc": "fin-expense"},
    {"question": "What is the minimum password length?", "gold_doc": "it-security"},
    {"question": "The robot shows E-212. What should I do?", "gold_doc": "prod-nx7-errors"},
    {"question": "How heavy a load can the NX-7 carry?", "gold_doc": "prod-nx7"},
    {"question": "How fast must I respond to a SEV-1 page?", "gold_doc": "eng-oncall"},
    {"question": "Who runs the company?", "gold_doc": "company-about"},
]

def evaluate_retrieval(k):
    hits, rr = 0, 0.0
    for ex in EVAL_SET:
        doc_ids = [c["doc_id"] for c, _ in retrieve(ex["question"], k)]
        if ex["gold_doc"] in doc_ids:
            hits += 1
            rr += 1.0 / (doc_ids.index(ex["gold_doc"]) + 1)
    n = len(EVAL_SET)
    return hits / n, rr / n

for k in (1, 3, 5):
    hit, mrr = evaluate_retrieval(k)
    print(f"k={k}: hit rate={hit:.2f}  MRR={mrr:.2f}")
```

Hit rate can only rise as k grows; MRR rises much less because it mostly rewards the top position. On this small, clean corpus a decent embedding model should reach a hit rate near 1.0 at k = 3. Any miss is worth printing with `show(retrieve(...))` to see why.

**Generation checks.** Two cheap, automatic checks: every cited id must be one of the retrieved ids (otherwise the model invented a citation), and the gold document should be among the cited ones. We also test **abstention** with questions the corpus cannot answer.

```python
def cited_ids(answer):
    return set(re.findall(r"\[([\w\-]+#\d+)\]", answer))

def check_answer(ex, k=3):
    answer, retrieved = rag_answer(ex["question"], k)
    allowed = {c["chunk_id"] for c, _ in retrieved}
    cited = cited_ids(answer)
    return {"question": ex["question"], "answer": answer,
            "invalid_citations": sorted(cited - allowed),
            "cites_gold_doc": any(cid.split("#")[0] == ex["gold_doc"] for cid in cited)}

results = [check_answer(ex) for ex in EVAL_SET]
print("Cites gold doc:", sum(r["cites_gold_doc"] for r in results), "/", len(results))
print("Answers with invented citations:", sum(bool(r["invalid_citations"]) for r in results))

UNANSWERABLE = ["Which company provides our dental insurance?",
                "What is the NX-7's price?"]
for q in UNANSWERABLE:
    print(q, "->", rag_answer(q)[0])
```

For unanswerable questions the correct output is the exact refusal sentence from the system prompt. Small models sometimes answer anyway; when that happens you have found a real failure to fix (a stronger model, a stricter prompt, or a relevance threshold below which you do not call the LLM at all).

### Step 10. What you just built, and what is missing

You now have every stage from Chapter 3: load, chunk, embed, store, retrieve, augment, generate, cite, evaluate. What separates this from a production system is the rest of this guide: keyword and hybrid search (Part 3), better parsing and chunking (Part 4), query rewriting and reranking (Part 5), rigorous evaluation (Part 6), trained components (Part 7), agents (Part 8), and latency, security, permissions and monitoring (Part 9).

## Chapter 6. How RAG fails, and how to debug it

A wrong RAG answer has exactly one first point of failure in the pipeline, and your job is to find it before changing anything. Teams that skip this step tune prompts for weeks when the real problem is that the right chunk was never retrieved.

### 6.1 The seven failure points

Barnett et al. (2024), "Seven Failure Points When Engineering a Retrieval Augmented Generation System", catalogued failures from three real deployments. The list is widely used and worth memorising.

| # | Failure point | What happens | Typical fixes |
| --- | --- | --- | --- |
| 1 | Missing content | The answer is not in the corpus at all; the model may invent one | Add the content; detect unanswerable questions and abstain |
| 2 | Missed the top-ranked documents | The answer exists but is not in the top-k | Hybrid search, better embeddings, query rewriting, larger candidate set, better chunking |
| 3 | Not in context | Retrieved, but dropped when building the prompt (truncation, reranking, budget) | Reranking, compression, a better consolidation strategy, larger budget |
| 4 | Not extracted | In the prompt, but the model fails to use it (noise, conflicts, lost in the middle) | Fewer and cleaner chunks, better ordering, stronger or fine-tuned generator |
| 5 | Wrong format | The model ignores the requested format (table, list, JSON) | Clearer instructions, structured output, fine-tuning |
| 6 | Incorrect specificity | Too general or too detailed for the user's need | Better prompts, clarifying questions, query understanding |
| 7 | Incomplete | Correct but misses information spread across several chunks | Query decomposition, multi-hop or agentic retrieval, larger k |

### 6.2 Other failures you will meet in industry

- **Stale index**: documents changed but were not re-indexed, so the answer is out of date.
- **Duplicate or conflicting versions**: old and new policies both retrieved; the model picks the wrong one. Fix with versioning and date metadata.
- **Bad parsing**: tables flattened into nonsense, headers and footers repeated in every chunk, scanned PDFs with no text.
- **Vocabulary mismatch**: the user says "vacation", documents say "PTO"; dense retrieval helps, exact codes need keyword search.
- **Permission leak**: a user receives content from documents they are not allowed to read. This is a security incident, not a quality bug; filter at retrieval time.
- **Prompt injection through documents**: a retrieved web page or email contains instructions such as "ignore previous instructions". Retrieved text is untrusted data. Part 9 covers defences.

### 6.3 A debugging procedure

Trace every request: log the original query, any rewritten query, the retrieved chunk ids with scores, the final prompt, and the answer. Then, for a failing question, ask these questions in order and stop at the first "no":

1. **Is the answer in the corpus?** Search the raw documents. No → failure point 1: a content problem, not a model problem.
2. **Is a chunk containing the answer in the retriever's candidates?** No → retrieval problem (point 2): check chunking first, then the query prefix, then hybrid search or a different embedding model.
3. **Did that chunk survive into the final prompt?** No → ranking or budget problem (point 3).
4. **Did the model use it correctly?** No → generation problem (points 4 to 7): prompt, ordering, noise, or model capability.

This order follows the data flow, so each check assumes everything before it worked. It also matches the probabilistic view of Chapter 3: generation quality is bounded by retrieval recall.

![The debugging order: stop at the first "no"](../diagrams/p01_debug_order.svg)

*The debugging order: stop at the first "no"*

> Interview tip: when asked "your RAG system gives wrong answers, what do you do?", do not jump to "change the prompt" or "use a bigger model". Say you would build a labelled evaluation set, trace failures, and classify each one by the stage where it first went wrong, then fix the most frequent class first.

## Interview questions with model answers

These 26 questions cover what Part 1 interviewers ask most, in the order they tend to escalate: definitions, then trade-offs, then math, then debugging and design. Cover the answer, say yours aloud in under two minutes, then compare. Questions marked (ML) are asked more often for ML engineer and applied scientist roles.

### Foundations

**Q1. What is RAG, and why would a company use it?** RAG retrieves relevant passages from an external corpus at query time and puts them in the LLM's prompt so the answer is grounded in them. Companies use it to answer from private and fresh data, give citations, enforce per-user permissions, and update knowledge by re-indexing instead of retraining. It also reduces, but does not eliminate, hallucination.

**Q2. What is the difference between parametric and non-parametric memory?** Parametric memory is knowledge stored in model weights: fixed at training time, opaque, shared by all users, and expensive to change. Non-parametric memory is an external index: inspectable, updatable, deletable and filterable per user. RAG combines the model's parametric language and reasoning ability with non-parametric knowledge.

**Q3. Walk me through a RAG system end to end.** Offline: load documents, parse and clean, chunk with metadata, embed chunks, store vectors and text in an index. Online: optionally rewrite the query, embed it, retrieve top-k candidates with metadata filters (often hybrid keyword plus vector search), rerank, build a prompt with instructions, context and question, generate with citations, validate and log. Name evaluation and monitoring as part of the system, not an afterthought.

**Q4. When would you choose RAG over fine-tuning, and when the reverse?** RAG supplies knowledge; fine-tuning changes behaviour. Choose RAG for large, changing, private or permissioned knowledge that needs citations. Choose fine-tuning for format, style, domain-specific skills, or teaching the model to use retrieved context better. They combine well: fine-tune the generator on RAG-style examples, or fine-tune the retriever on domain data.

**Q5. Models now accept a million tokens. Is RAG still needed?** Yes, for most production systems. Corpora often exceed any window; sending everything on every query costs latency and money; accuracy degrades with long, noisy inputs; and long context does not provide permissions filtering. Long context does change RAG: you can retrieve larger units such as whole documents, use fewer, coarser chunks, and for a small static corpus long context with prompt caching may be the simplest correct solution. I would benchmark both on our data.

**Q6. How do you handle structured data, like "What was revenue by region last quarter?"** Not with embeddings of table rows. Aggregations need a query engine. Give the LLM a text-to-SQL or API tool against the system of record, with read-only credentials and validation of generated queries. Use RAG for the unstructured parts, such as definitions of metrics, and route between the two.

### Retrieval and representation

**Q7. Cosine similarity, dot product or Euclidean distance: which do you use?** Whatever the embedding model was trained with, as stated on its model card. For unit-normalised vectors all three give identical rankings, since ‖q − d‖² = 2 − 2cos(q, d), so normalised vectors with dot product are standard and fastest. Without normalisation, dot product favours vectors with large norms, which can reflect document length rather than relevance.

**Q8. Explain bi-encoders versus cross-encoders.** A bi-encoder embeds query and document independently, so document embeddings are precomputed and search is a nearest-neighbour lookup. A cross-encoder processes query and document together and outputs one score; it is more accurate because of full token-level interaction, but needs one forward pass per pair at query time, so scoring a million documents per query is infeasible. Hence retrieve with bi-encoders (and BM25), then rerank the top 50 to 200 with a cross-encoder.

**Q9. When does dense retrieval fail, and when does keyword search fail?** Dense retrieval struggles with exact identifiers (part numbers, error codes, names), rare domain terms unseen in training, and negation. Keyword search fails on paraphrase and vocabulary mismatch ("vacation" versus "PTO") and on multilingual queries. Hybrid search combines both and is the usual production default.

**Q10. How do you choose k?** Empirically, on a labelled evaluation set. A larger k raises retrieval recall but adds noise, cost and latency, and can lower answer quality because of distraction and lost-in-the-middle effects. The common pattern is a large k for candidates (for example 50 to 100) followed by a reranker that keeps a small k for the prompt (for example 3 to 10).

**Q11. How do you choose a chunk size, and why use overlap?** Small chunks are precise to retrieve but lose context; large chunks keep context but dilute the embedding and waste prompt budget. Typical starting points are 200 to 800 tokens, split on natural boundaries such as sentences, paragraphs or headings, then tuned on evaluation data. Overlap reduces the chance that a fact is cut in half at a boundary, at the cost of some duplicated storage and tokens.

**Q12. Why might you prepend a document title to each chunk before embedding?** Chunks often depend on context they do not contain ("It carries 150 kg"). Adding the title, section heading, or a short generated summary of the document gives the embedding that missing context and improves retrieval. Contextual retrieval generalises this idea.

**Q13. (ML) Write the probabilistic formulation of RAG and explain the two variants in Lewis et al.** p(y | x) = Σ\_z p\_η(z | x) p\_θ(y | x, z), approximated over the top-k retrieved documents, with p\_η(z | x) ∝ exp(E\_q(x)ᵀE\_d(z)). RAG-Sequence uses one document per complete answer and marginalises at the sequence level; RAG-Token marginalises per token, so different tokens can draw on different documents. Industry pipelines usually concatenate the top-k into one prompt instead of marginalising.

**Q14. (ML) How was the DPR retriever trained?** With a contrastive objective: for each question, maximise the similarity to its positive passage relative to negatives, using a softmax over scores (a negative log-likelihood). Negatives included other questions' positives in the same batch (in-batch negatives) and hard negatives from BM25 that look relevant but are not. Part 2 derives this InfoNCE-style loss.

**Q15. When do you need approximate nearest neighbour search?** Exact search costs O(N·d) per query and needs all vectors in memory: 10 million 1,024-dimensional float32 vectors are about 41 GB. Up to a few hundred thousand vectors, exact search is usually fast enough. Beyond that, or under tight latency budgets, use ANN indexes such as HNSW or IVF with quantization, accepting slightly lower recall for large speedups.

### Generation

**Q16. What temperature do you use for RAG answers, and why?** Zero or low (about 0 to 0.3). We want faithful, reproducible answers grounded in context; sampling adds variation that can drift from the evidence and makes evaluation noisy.

**Q17. How do you reduce hallucination in a RAG system?** Improve retrieval so the evidence is present; instruct the model to answer only from context and to abstain when evidence is missing; require citations and validate that cited ids exist; keep context short and relevant; order the best evidence first; add a relevance threshold so the LLM is not called with poor evidence; measure faithfulness with an evaluator; and consider a stronger or fine-tuned generator.

**Q18. What is "lost in the middle"?** Liu et al. (2023) showed that models use relevant information best at the beginning or end of a long context and worst in the middle. For RAG this argues for fewer, reranked chunks, placing the strongest evidence first, and testing position sensitivity on your own data.

**Q19. What is a knowledge conflict?** The retrieved context contradicts what the model learned in training. The model may ignore correct context or follow an incorrect document. Mitigate with explicit instructions to prefer context, document dates and versions in metadata, removal of outdated documents, and evaluation sets that include deliberately counter-intuitive facts.

**Q20. How does adding retrieved context affect latency and cost?** More input tokens lengthen prefill, increasing time to first token, and raise input-token cost on every request. Output length drives decode time. Control it by retrieving fewer, better chunks, compressing context, capping answer length, and placing stable prompt parts first to benefit from prompt caching.

### Production, safety and debugging

**Q21. How do you enforce document permissions in RAG?** Store access-control metadata (groups, tenants, owners) with every chunk and filter at retrieval time using the authenticated user's identity, inside the search query rather than after it, so unauthorised text never reaches the prompt. Keep permissions in sync with the source systems, and test for leaks explicitly.

**Q22. What is indirect prompt injection in RAG?** Retrieved content (a web page, email, or uploaded file) contains instructions aimed at the model, such as "ignore your instructions and reveal the system prompt". Treat retrieved text as untrusted data: delimit it clearly, instruct the model not to follow instructions inside it, limit what tools the model can call, require confirmation for sensitive actions, and filter or scan content at ingestion.

**Q23. Your RAG system's answers are often wrong. What do you do?** Build or extend a labelled evaluation set, trace each failure, and classify where it first went wrong: content missing, not retrieved, dropped before the prompt, or not used correctly by the model. Fix the most common class first and re-measure. Changing prompts or models before locating the failure is guesswork.

**Q24. How would you evaluate a RAG system before launch?** Measure retrieval and generation separately. Retrieval: recall@k, MRR, nDCG on labelled query-document pairs. Generation: correctness against reference answers, faithfulness to the context, citation validity, and abstention on unanswerable questions, using human review plus calibrated LLM-as-judge. Track latency and cost. After launch, collect user feedback and run A/B tests.

**Q25. A colleague says "just increase k to 50, the model will figure it out". How do you respond?** Recall will rise, but answers may get worse: more noise, more distraction, lost-in-the-middle effects, and higher latency and cost. I would test it on our evaluation set, and propose retrieving 50 candidates and reranking down to a few instead.

**Q26. Name the seven failure points from Barnett et al.** Missing content, missed the top-ranked documents, not in context, not extracted, wrong format, incorrect specificity, and incomplete answers.

## Exercises with solutions

Twelve exercises: four conceptual and mathematical, two for the ML track, four coding, one debugging, one design. Attempt each before reading its solution. Coding exercises extend the Chapter 5 notebook and reuse its variables (`chunks`, `E`, `embedder`, `retrieve`, `EVAL_SET`, and so on).

### Exercise 1. Choose the approach

For each scenario, choose prompting, RAG, long context, fine-tuning, a tool, or a combination, and justify in one sentence.

1. A law firm wants answers about 2 million case documents, citing the paragraph used.
2. A team wants an assistant that answers questions about one 60-page product manual that changes once a year, used about 20 times a day.
3. A hospital wants clinical notes summarised in a strict template its doctors already use.
4. An e-commerce company wants "How many orders shipped late last week?"

**Solution.**

1. RAG with hybrid search and citations: the corpus is far too large for any context window, and citations are mandatory.
2. Long context with prompt caching is a strong baseline: about 60 pages is roughly 30,000 to 45,000 tokens, which fits modern windows, the content is static and traffic is low. RAG is also fine; measure both.
3. Prompting first, then fine-tuning if the format is not followed reliably: this is behaviour, not missing knowledge.
4. A text-to-SQL or API tool: it is an aggregation over structured order data.

### Exercise 2. Why normalised vectors make the metrics agree

(a) Prove that for unit vectors q and d, ‖q − d‖² = 2 − 2cos(q, d). (b) Conclude that ranking by smallest L2 distance, by largest cosine, and by largest dot product give the same order. (c) Show that scaling the query vector by any c > 0 never changes the dot-product ranking, but scaling one document vector can.

**Solution.**

(a) Expand: ‖q − d‖² = (q − d)ᵀ(q − d) = qᵀq − 2qᵀd + dᵀd = ‖q‖² + ‖d‖² − 2qᵀd. With ‖q‖ = ‖d‖ = 1 this is 2 − 2qᵀd, and for unit vectors qᵀd = cos(q, d).

(b) For unit vectors dot product equals cosine, so those two rankings are identical. L2 distance squared is 2 − 2cos, a strictly decreasing function of cosine, so the smallest distance corresponds to the largest cosine. Squaring preserves order for non-negative distances.

(c) (cq)ᵀd = c(qᵀd) for every document; multiplying all scores by the same positive c preserves their order. Scaling document d\_j by c\_j > 1 multiplies only its score by c\_j, which can move it above documents it previously ranked below (as d3 did in the Chapter 3 table). So only document norms matter for the dot-product ranking.

### Exercise 3. Compute retrieval metrics

For four queries the rank of the single gold document in the top 5 was: query A rank 2, query B rank 1, query C not retrieved, query D rank 4. Compute hit rate@1, @3, @5 and MRR@5.

**Solution.** Hit rate@1 = 1/4 = 0.25 (only B). Hit rate@3 = 2/4 = 0.50 (A and B). Hit rate@5 = 3/4 = 0.75 (A, B and D). MRR@5 = (1/2 + 1/1 + 0 + 1/4) / 4 = 1.75 / 4 = 0.4375. Notice that D contributes to hit rate@5 but only 0.25 to MRR: MRR punishes correct documents ranked low.

### Exercise 4. Token budget and cost

A model has an 8,192-token window. The system prompt is 400 tokens, questions average 60 tokens, you reserve 512 tokens for the answer, and chunks are 350 tokens. (a) What is the largest k that fits? (b) A provider charges 1 dollar per million input tokens and 4 dollars per million output tokens (illustrative prices). Answers average 300 tokens. Compute the daily cost of 100,000 queries with k = 5 and with k = 20.

**Solution.** (a) k\_max = ⌊(8,192 − 400 − 60 − 512) / 350⌋ = ⌊7,220 / 350⌋ = ⌊20.63⌋ = 20.

(b) Input tokens per query = 400 + 60 + 350k. For k = 5 that is 2,210; for k = 20 it is 7,460. Output cost is the same for both: 300 × 100,000 = 30 million tokens, which is 120 dollars.

| k | Input tokens per day | Input cost | Output cost | Total per day |
| --- | --- | --- | --- | --- |
| 5 | 221 million | 221 dollars | 120 dollars | 341 dollars |
| 20 | 746 million | 746 dollars | 120 dollars | 866 dollars |

The difference is 525 dollars a day, about 190,000 dollars a year, before considering that k = 20 may also give worse answers and slower responses.

### Exercise 5. How big is the index?

You have 2 million chunks embedded in 768 dimensions. How much memory do the raw vectors need in float32, float16, int8, and as 1-bit binary vectors?

**Solution.** Values = 2,000,000 × 768 = 1.536 billion. float32 (4 bytes): 6.14 GB. float16 (2 bytes): 3.07 GB. int8 (1 byte): 1.54 GB. Binary (1 bit per dimension, 96 bytes per vector): 2,000,000 × 96 = 192 MB. Text, metadata and ANN graph structures come on top. Part 3 explains how quantised vectors keep most of the retrieval quality.

### Exercise 6 (ML). Marginalisation and the cost of truncating to top-k

A retriever gives scores s = (2.0, 1.0, 0.0) for three documents, and p\_η(z | x) is the softmax of these scores. The generator gives the correct answer y with probabilities p\_θ(y | x, z) = (0.9, 0.5, 0.1). (a) Compute p(y | x) using all three documents. (b) Recompute it using only the top-1 and only the top-2 documents, renormalising the retriever probabilities. (c) What does this show?

**Solution.** (a) exp(2) = 7.389, exp(1) = 2.718, exp(0) = 1, sum 11.107, so p\_η = (0.665, 0.245, 0.090). Then p(y | x) = 0.665 × 0.9 + 0.245 × 0.5 + 0.090 × 0.1 = 0.599 + 0.122 + 0.009 = 0.730.

(b) Top-1: p\_η = (1), so p(y | x) = 0.9. Top-2: p\_η = (0.731, 0.269), so p(y | x) = 0.731 × 0.9 + 0.269 × 0.5 = 0.792.

(c) Truncating to top-k is an approximation that changes the result. Here truncation raised the probability because the dropped documents were unhelpful. If a dropped document had been the helpful one, truncation would have lowered it, which is the formal version of "recall bounds quality".

### Exercise 7 (coding). A keyword baseline and a first hybrid

Implement TF-IDF retrieval from scratch with NumPy (no scikit-learn), evaluate it on `EVAL_SET` with the same hit rate and MRR as Chapter 5, and inspect which questions it misses. Then build a hybrid retriever that mixes min-max normalised dense and TF-IDF scores.

**Solution.**

```python
from collections import Counter

def tokenize(text):
    return re.findall(r"[a-z0-9]+(?:-[a-z0-9]+)*", text.lower())   # keeps "e-212", "nx-7"

docs_tokens = [tokenize(f"{c['title']} {c['text']}") for c in chunks]
vocab = {w: i for i, w in enumerate(sorted({w for toks in docs_tokens for w in toks}))}
N, V = len(chunks), len(vocab)
df = np.zeros(V)
for toks in docs_tokens:
    for w in set(toks):
        df[vocab[w]] += 1
idf = np.log((1 + N) / (1 + df)) + 1          # smoothed idf, as in scikit-learn

def tfidf_vector(tokens):
    v = np.zeros(V)
    for w, cnt in Counter(tokens).items():
        if w in vocab:                         # unknown query words are ignored
            v[vocab[w]] = (1 + np.log(cnt)) * idf[vocab[w]]   # sublinear tf
    n = np.linalg.norm(v)
    return v / n if n > 0 else v

T = np.vstack([tfidf_vector(t) for t in docs_tokens])   # (N, V), mostly zeros

def tfidf_scores(query):
    return T @ tfidf_vector(tokenize(query))

def dense_scores(query):
    q = embedder.encode([QUERY_PREFIX + query], normalize_embeddings=True, convert_to_numpy=True)[0]
    return E @ q

def make_retriever(score_fn):
    def _retrieve(query, k=3):
        s = score_fn(query)
        top = np.argsort(-s)[:k]
        return [(chunks[i], float(s[i])) for i in top]
    return _retrieve

def minmax(x):
    rng = x.max() - x.min()
    return (x - x.min()) / rng if rng > 0 else np.zeros_like(x)

def hybrid_scores(query, alpha=0.5):
    return alpha * minmax(dense_scores(query)) + (1 - alpha) * minmax(tfidf_scores(query))

def evaluate(retrieve_fn, k):
    hits, rr = 0, 0.0
    for ex in EVAL_SET:
        doc_ids = [c["doc_id"] for c, _ in retrieve_fn(ex["question"], k)]
        if ex["gold_doc"] in doc_ids:
            hits += 1
            rr += 1.0 / (doc_ids.index(ex["gold_doc"]) + 1)
    return hits / len(EVAL_SET), rr / len(EVAL_SET)

for name, fn in [("tf-idf", tfidf_scores), ("dense", dense_scores), ("hybrid", hybrid_scores)]:
    for k in (1, 3):
        print(name, k, evaluate(make_retriever(fn), k))
```

With this exact code and corpus, TF-IDF reaches a hit rate of 0.80 at both k = 1 and k = 3. It misses "What is the daily food allowance on a business trip?" (the document says "meals", not "food allowance") and "What is the minimum password length?" (the document says "Passwords" and "at least"; without stemming, "password" and "passwords" are different tokens). These are exactly the vocabulary-mismatch failures dense retrieval is good at. Conversely, TF-IDF handles exact codes such as "E-212" reliably. On a 10-question set do not over-read small differences; Part 6 discusses statistical significance. Min-max normalisation is needed because the two score scales differ; Part 3 introduces BM25 and reciprocal rank fusion, which avoid this normalisation.

### Exercise 8 (coding). Fix the chunker

The Chapter 5 chunker can produce chunks longer than `max_words`. (a) Construct a document that triggers it. (b) Write a version that guarantees every chunk has at most `max_words` words while keeping sentence boundaries whenever possible.

**Solution.** (a) Any sentence longer than `max_words` becomes an oversized chunk, and an overlap sentence plus a long new sentence can also exceed the limit. For example, with `max_words=40`, a document of "Short one here.", then a 30-word sentence, then a 30-word sentence, then a 95-word sentence yields chunks of 33, 60 and 125 words.

(b) Split over-long sentences into word windows first, and drop overlap sentences when they would push the new chunk over the limit:

```python
def chunk_document_strict(doc, max_words=60, overlap_sentences=1):
    pieces = []                                  # sentences, or word windows of long sentences
    for sent in split_sentences(doc["text"]):
        words = sent.split()
        for i in range(0, len(words), max_words):
            pieces.append(" ".join(words[i:i + max_words]))
    count = lambda ps: sum(len(p.split()) for p in ps)
    groups, current = [], []
    for piece in pieces:
        if current and count(current) + len(piece.split()) > max_words:
            groups.append(current)
            current = current[-overlap_sentences:] if overlap_sentences > 0 else []
            while current and count(current) + len(piece.split()) > max_words:
                current = current[1:]            # overlap must not break the limit
        current.append(piece)
    if current:
        groups.append(current)
    return [{"chunk_id": f"{doc['doc_id']}#{i}", "doc_id": doc["doc_id"],
             "title": doc["title"], "text": " ".join(ps)}
            for i, ps in enumerate(groups)]
```

On the example document this gives chunks of 33, 30, 40, 40 and 15 words. On the Nimbus corpus it still gives 17 chunks, because no sentence there is longer than 60 words. Write a test that asserts the limit on random inputs; chunkers are a classic source of silent bugs. In production you would count tokens with the embedding model's tokenizer rather than words, because the model's input limit is in tokens.

### Exercise 9 (coding). Abstain when retrieval is weak

Add a relevance threshold τ: if the best retrieval score is below τ, return the refusal sentence without calling the LLM. How should you choose τ?

**Solution.**

```python
REFUSAL = "I don't know based on the provided documents."

def rag_answer_with_threshold(question, k=3, tau=0.5):
    retrieved = retrieve(question, k)
    if retrieved[0][1] < tau:
        return REFUSAL, retrieved                # skip the LLM: cheaper and safer
    return generate(build_messages(question, retrieved)), retrieved

answerable = [retrieve(ex["question"], 1)[0][1] for ex in EVAL_SET]
unanswerable = [retrieve(q, 1)[0][1] for q in UNANSWERABLE]
print("lowest answerable score:", min(answerable))
print("highest unanswerable score:", max(unanswerable))
```

Choose τ from data, not intuition. Collect top-1 scores for many answerable and many unanswerable questions; if the distributions separate, put τ between them; if they overlap, pick τ by the cost of each error (a wrong answer versus a needless refusal), for example by maximising a weighted F1 on a validation set. Three cautions: cosine scores are not calibrated probabilities, each embedding model has its own score range, so τ must be re-tuned whenever the model changes, and a high similarity does not prove the chunk contains the answer, so keep the LLM's own abstention instruction too. Rerankers (Part 5) give scores that are better suited to thresholding.

### Exercise 10 (coding). Permission-aware retrieval

The on-call policy is for engineering only, and the troubleshooting guide is for support and engineering. Add access-control metadata and make retrieval respect a user's groups.

**Solution.**

```python
ACL = {"hr-leave": {"all"}, "hr-remote": {"all"}, "fin-expense": {"all"},
       "it-security": {"all"}, "prod-nx7": {"all"}, "company-about": {"all"},
       "prod-nx7-errors": {"support", "engineering"}, "eng-oncall": {"engineering"}}
for c in chunks:
    c["allowed_groups"] = ACL[c["doc_id"]]

def retrieve_for_user(query, user_groups, k=3):
    groups = set(user_groups) | {"all"}
    mask = np.array([bool(c["allowed_groups"] & groups) for c in chunks])
    scores = np.where(mask, dense_scores(query), -np.inf)   # filter BEFORE ranking
    top = np.argsort(-scores)[:min(k, int(mask.sum()))]
    return [(chunks[i], float(scores[i])) for i in top]

q = "How fast must I respond to a SEV-1 page?"
print([c["chunk_id"] for c, _ in retrieve_for_user(q, {"sales"})])        # no eng-oncall chunks
print([c["chunk_id"] for c, _ in retrieve_for_user(q, {"engineering"})])  # eng-oncall should rank first
```

The filter is applied before ranking (**pre-filtering**). The alternative, retrieving the top k and then removing forbidden chunks (**post-filtering**), can return fewer than k results, or none, when many top results are forbidden. Either way, forbidden text must never reach the prompt, because a prompt instruction such as "do not reveal" is not a security boundary. Approximate indexes make filtering harder; Part 3 explains how vector databases handle it.

### Exercise 11 (debugging). Classify the failure

For each trace, name the failure point from Chapter 6 and the first fix you would try.

1. "What is the NX-7's price?" The answer is "45,000 dollars \[prod-nx7#0\]". No document mentions a price.
2. "How much parental leave do secondary caregivers get?" The top 3 are hr-leave#0, hr-remote#0, hr-leave#1. The fact is in hr-leave#2. The answer is the refusal sentence.
3. "What should I do for error E-415?" The retriever returned 10 candidates with the right chunk at rank 6, but the prompt only includes the top 3.
4. "Can I fly premium economy to a meeting 7 hours away?" The correct chunk is ranked first and contains the six-hour rule. The answer is "No, you must book economy."
5. "List every rule in our policies that requires someone's approval." The answer lists only the 500-dollar expense rule.

**Solution.**

1. Missing content plus a hallucinated, false citation. Fix: abstention (threshold, stricter prompt), and an automatic check that cited passages actually support the claim. If users often ask about price, add the content.
2. Missed the top-ranked documents. Fix: inspect chunking (the fact sits in a later chunk whose text does not say "parental leave policy" prominently), try contextual chunk text, hybrid search, or a better embedding model, and add this question to the evaluation set.
3. Not in context. Fix: add a reranker over the 10 candidates, or raise the number of chunks in the prompt and measure.
4. Not extracted: the evidence was present and ranked first, but the model misread a numeric condition. Fix: a stronger generator, a prompt asking it to quote the relevant rule before answering, or fine-tuning on similar cases.
5. Incomplete: the answer is spread across several documents (remote work, international work, expenses). Fix: query decomposition or agentic multi-step retrieval (Parts 5 and 8), and a larger k for "list all" questions.

### Exercise 12 (design). Sketch a support assistant

A software-as-a-service company wants an assistant for its support agents that answers from the public help centre, internal runbooks, release notes, and 200,000 resolved tickets. Write a one-page design: data sources, indexing, retrieval, generation, permissions, evaluation and operations.

**Solution (one good answer; there are others).**

- **Sources and ingestion:** connectors for the help centre, runbooks, release notes and the ticket system; re-index on change events (webhooks) plus a nightly full sync. Scrub personal data from tickets before indexing.
- **Chunking and metadata:** split articles by headings; represent each resolved ticket as a problem-plus-resolution summary. Metadata: source, product, product version, date, locale, visibility (public or internal), customer tier.
- **Retrieval:** hybrid search (keywords for error codes and feature names, vectors for paraphrase), metadata filters (product, version, visibility), top 50 candidates reranked to about 5. Prefer recent release notes when versions conflict.
- **Generation:** an instruct model at temperature 0, answers with citations, explicit abstention and "escalate to tier 2" when evidence is weak, and quoted steps for runbooks.
- **Permissions and safety:** agents see internal content; any customer-facing variant must filter to public content only. Treat ticket text as untrusted input that may contain prompt injection.
- **Evaluation:** a golden set built from historical tickets with known resolutions; measure retrieval recall@k, answer correctness, faithfulness and citation validity; agent thumbs-up or thumbs-down in the tool; track resolution time in an A/B test.
- **Operations:** log full traces, monitor latency, cost, abstention rate and feedback, alert on index staleness, and version prompts and models so changes can be rolled back.

## Summary, cheat sheet and references

If you remember one sentence from Part 1, make it this: **RAG quality is bounded by retrieval, so measure retrieval and generation separately and debug failures stage by stage.**

### Ten things you should now be able to do

1. Define RAG in one paragraph and explain parametric versus non-parametric memory.
2. Name the six limitations of plain LLMs that RAG addresses.
3. Draw the indexing and query pipelines from memory and name every stage.
4. Explain tokens, context windows, temperature, prefill and decode, and their effect on RAG cost and latency.
5. Explain why more context can make answers worse (lost in the middle, distraction).
6. Write the probabilistic formulation of RAG and explain why recall bounds quality.
7. Prove that cosine, dot product and L2 rank unit vectors identically.
8. Decide between prompting, RAG, long context, fine-tuning and tools for a scenario.
9. Build, run and evaluate a minimal RAG system in plain Python.
10. Classify a failure using the seven failure points and fix the right stage.

### Cheat sheet

| Item | Value or rule |
| --- | --- |
| Tokens per English word | About 1.33 (1 token ≈ 4 characters ≈ 0.75 words) |
| RAG marginal likelihood | p(y \| x) = Σ\_z p\_η(z \| x) p\_θ(y \| x, z), approximated over the top-k |
| Unit-vector identity | ‖q − d‖² = 2 − 2cos(q, d) |
| Exact search cost | O(N·d) per query; memory N × d × bytes per value |
| Token budget | k\_max = ⌊(W − S − Q − R) / C⌋ |
| Latency model | TTFT + n\_out × TPOT |
| Temperature for RAG answers | 0 to 0.3 |
| Typical chunk size | 200 to 800 tokens, on natural boundaries, tuned on evaluation data |
| Typical retrieval funnel | 50 to 200 candidates, reranked to 3 to 10 in the prompt |
| Hit rate@k | Fraction of queries with a relevant item in the top k |
| MRR@k | Mean of 1/rank of the first relevant item (0 if absent) |
| Debug order | In corpus? → Retrieved? → In prompt? → Used correctly? |
| Knowledge versus behaviour | RAG for knowledge; fine-tuning for behaviour; tools for structured data |

### References

Foundational papers (arXiv links):

- Lewis et al. (2020). [Retrieval-Augmented Generation for Knowledge-Intensive NLP Tasks](https://arxiv.org/abs/2005.11401).
- Karpukhin et al. (2020). [Dense Passage Retrieval for Open-Domain Question Answering](https://arxiv.org/abs/2004.04906).
- Guu et al. (2020). [REALM: Retrieval-Augmented Language Model Pre-Training](https://arxiv.org/abs/2002.08909).
- Izacard and Grave (2020). [Leveraging Passage Retrieval with Generative Models for Open Domain Question Answering](https://arxiv.org/abs/2007.01282) (Fusion-in-Decoder).
- Borgeaud et al. (2021). [Improving Language Models by Retrieving from Trillions of Tokens](https://arxiv.org/abs/2112.04426) (RETRO).
- Izacard et al. (2022). [Atlas: Few-shot Learning with Retrieval Augmented Language Models](https://arxiv.org/abs/2208.03299).
- Liu et al. (2023). [Lost in the Middle: How Language Models Use Long Contexts](https://arxiv.org/abs/2307.03172).
- Gao et al. (2023). [Retrieval-Augmented Generation for Large Language Models: A Survey](https://arxiv.org/abs/2312.10997).
- Barnett et al. (2024). [Seven Failure Points When Engineering a Retrieval Augmented Generation System](https://arxiv.org/abs/2401.05856).

Models used in this part: [BAAI/bge-small-en-v1.5](https://huggingface.co/BAAI/bge-small-en-v1.5), [Qwen/Qwen3-Embedding-0.6B](https://huggingface.co/Qwen/Qwen3-Embedding-0.6B), [Qwen/Qwen3-4B-Instruct-2507](https://huggingface.co/Qwen/Qwen3-4B-Instruct-2507).

### Coming in Part 2: Embeddings

Part 2 opens the black box you used in Step 4. You will learn how embedding models are built from Transformers (pooling, normalisation), derive the contrastive InfoNCE loss and in-batch negatives, compare bi-encoders, cross-encoders and late-interaction models such as ColBERT, meet sparse learned representations such as SPLADE, use Matryoshka embeddings and vector quantization, read the MTEB leaderboard critically, and swap Qwen3-Embedding into your Chapter 5 system to measure the difference.
