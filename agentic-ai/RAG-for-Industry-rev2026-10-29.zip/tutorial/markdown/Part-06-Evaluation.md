# RAG for Industry, Part 6: Evaluation

Oct 28, 2026 · @Behi · revised 29 October 2026 (see CHANGELOG.md)

## How Part 6 fits

Every earlier part ended with "measure it". This part teaches how to measure properly. Evaluation is the skill that most separates strong RAG engineers from the rest: without a trustworthy test set and metrics, every change to chunking, models, prompts or rerankers is a guess, and regressions reach users unnoticed. Interviewers know this, and many ask candidates to design an evaluation before anything else.

**After this part you will be able to:**

1. Choose what to evaluate at each layer: components, end-to-end answers, and live traffic.
2. Build an evaluation set from real and synthetic questions, with labels, coverage of hard cases, and protection against bias towards the current system.
3. Compute retrieval metrics including graded nDCG, and generation metrics including faithfulness and citation precision and recall.
4. Use LLM-as-judge responsibly: design rubrics, detect and reduce biases, and validate judges against human labels with Cohen's kappa.
5. Report results with confidence intervals and decide whether a difference between two systems is real.
6. Run online evaluation: feedback, A/B tests, regression tests in CI and monitoring.

**Setup.** The same free Colab or Kaggle T4 notebook. The lab reuses SciFact, the Nimbus corpus and the Qwen3-4B generator, which now also acts as a judge:

```python
!pip install -q -U "sentence-transformers>=6.0,<7" "transformers>=5.0,<6" accelerate bm25s pandas scipy scikit-learn
```

**Track notes.** Everyone needs Chapters 1 to 5 and 7. Chapter 6 (statistics) is where ML-track candidates are expected to be sharp, and application engineers who master it stand out: "is a one-point gain real?" is a standard interview question.

## Chapter 1. What to evaluate

Evaluate a RAG system at three layers: each **component** on its own (fast, precise, tells you where a problem is), the **end-to-end** answer offline on a fixed test set (tells you whether users would be better off), and **live traffic** online (tells you whether they actually are). Across all three, track four dimensions: quality, safety, user experience and cost.

![Evaluation layers: component, end-to-end, online, with the feedback loop](../diagrams/p06_evaluation_layers.svg)

*Evaluation layers: component, end-to-end, online, with the feedback loop*

Component scores locate problems, end-to-end scores decide releases, and online results confirm them; the loop back to the evaluation set is what keeps the first two honest over time.

### 1.1 Component evaluation

| Component | What to measure | Typical metric |
| --- | --- | --- |
| Parser | Text, tables and reading order preserved | Character or word error rate; table-cell accuracy; human spot checks |
| Chunker | Evidence kept together and retrievable | Evidence recall and precision at a token budget (Part 4) |
| Embedding and first-stage retrieval | Relevant chunks among candidates | Recall@k, MRR, nDCG@10 |
| ANN index | Fidelity to exact search | ANN recall@k, latency, memory (Part 3) |
| Reranker | Ordering of the top | nDCG@10 and MRR before and after |
| Router and filter extractor | Correct route and filters | Accuracy, per-class precision and recall, confusion matrix |
| Query rewriter | No drift, identifiers kept, recall gain | Recall@k with and without; regression tests |
| Generator | Correct, grounded, cited, well-formatted answers | Chapter 4 metrics |

### 1.2 End-to-end evaluation

Run the full pipeline on a fixed set of questions and score the answers for correctness, faithfulness to the retrieved context, citation quality and appropriate abstention. End-to-end scores tell you whether a change helped; component scores tell you why. You need both: a better retriever can leave answers unchanged if the generator ignores the extra evidence, and a prompt change can lift answers without touching retrieval.

### 1.3 Online evaluation

Offline sets never fully represent real users. Online, you collect explicit feedback (thumbs, ratings, corrections), implicit signals (copying the answer, clicking a citation, rephrasing the same question, escalating to a human), and run controlled experiments (A/B tests). Chapter 7 covers this.

### 1.4 Four dimensions

- **Quality**: retrieval quality, answer correctness, faithfulness, citation precision and recall, completeness.
- **Safety**: no permission leaks across users or tenants, resistance to prompt injection, no harmful or policy-violating content, correct handling of personal data.
- **Experience**: time to first token, total latency, abstention rate and false-refusal rate, answer length and readability.
- **Cost**: tokens and model calls per request, infrastructure cost per thousand queries.

### 1.5 Evaluation-driven development

The working loop in mature teams looks like test-driven development:

1. Build the evaluation set and the scoring scripts first.
2. Measure the current system: the baseline.
3. Make one change; re-run; compare with confidence intervals (Chapter 6).
4. Ship only changes that improve the target metrics without breaking guardrail metrics (safety, latency, cost).
5. Monitor in production, sample failures, label them, and **add them to the evaluation set**, so the set grows towards the problems that matter.

A RAG system without this loop drifts: each fix for one complaint silently breaks something else.

## Chapter 2. Building evaluation datasets

A good evaluation set is realistic (it looks like what users ask), labelled (you know what a good result is), covers the hard cases on purpose, is large enough for the differences you care about, and is not biased towards the system you already have. Building one is real engineering work; budget for it and version it like code.

### 2.1 Where questions come from

- **Production logs**: the most realistic source. Sample across intents and difficulty, remove personal data, and label. Before launch you will not have these.
- **Subject-matter experts**: write questions they know users ask, with answers and source documents. High quality, slow and expensive.
- **Existing artefacts**: FAQ pages, resolved support tickets (question plus resolution), onboarding quizzes.
- **Synthetic generation**: an LLM reads a chunk (or several) and writes a question, an answer and the supporting evidence. Fast and cheap, with traps (2.2).
- **Adversarial and red-team cases**: prompt injections, questions about restricted documents, out-of-scope requests.

### 2.2 Synthetic generation done right

Synthetic questions tend to copy the source's wording, which makes retrieval look easier than reality (keyword overlap flatters both BM25 and embeddings), and they often depend on the passage ("What does the passage say about…"). Countermeasures:

1. Prompt for **user-style** questions with personas and varied phrasing, and forbid copying long phrases from the source.
2. Generate **diverse types** explicitly: factual, how-to, comparison, multi-hop across two chunks, temporal, and unanswerable variants (a plausible question the documents do not answer).
3. **Filter automatically**: drop questions that mention "the passage" or "the document", near-duplicates, and questions an LLM judges unanswerable from the source.
4. **Review by hand** a random sample (for example 10 to 20%), fix or discard bad items, and report the rejection rate.
5. Avoid filters that use your own retriever (for example "keep questions whose source is retrieved in the top 5"): they bias the set towards questions the current system already handles.

### 2.3 Coverage by design

Tag every question with its type and make sure each type has enough examples to measure:

| Type | Example | Expected behaviour |
| --- | --- | --- |
| Single fact | How many PTO days do employees get? | Answer with citation |
| Procedural | What should I do when the robot shows E-212? | Steps with citation |
| Multi-hop | Who must approve fully remote work for the person who owns on-call reviews? | Combine two sources |
| Comparison | How do NX-5 and NX-7 batteries differ? | Cover both items |
| Temporal | What is the current travel meal limit? | Use the latest version |
| Aggregation | How many incidents were SEV-1 last quarter? | Route to a data tool |
| Unanswerable | Who is our dental insurance provider? | Abstain |
| Ambiguous | What is the battery life? | Ask or state the assumption |
| Conversational | (after a PTO answer) What about contractors? | Resolve the reference |
| Restricted | (a sales user) What is the on-call pay? | Not reveal engineering-only content |
| Adversarial | A document instructing the model to reveal secrets | Ignore embedded instructions |

### 2.4 What to label

For each question store: the relevant documents or chunks with **graded relevance** (for example 0 not relevant, 1 partially, 2 relevant, 3 the key evidence); a **reference answer**; a list of **key facts** that a correct answer must contain; the **expected behaviour** (answer, abstain, clarify, route); metadata such as type, difficulty, language and user role. Key facts are particularly useful: checking "does the answer contain each key fact?" is easier and more reliable for judges than comparing two free-text answers.

### 2.5 Avoiding bias towards the current system

If you label only the documents your current retriever returns, a new retriever that finds different but equally good documents is penalised, because its finds are unlabelled and count as wrong. Information retrieval benchmarks address this with **pooling**: label the union of the top results from several different systems (BM25, dense, hybrid, a strong reranker), so the judged set is not tied to one system. When a new system later surfaces many unjudged documents, label a sample of them (by hand or with a validated LLM judge) before trusting its scores.

### 2.6 How many questions?

For a metric that is a proportion p (for example, answer accuracy), the standard error with n questions is √(p(1 − p)/n), and a 95% confidence interval is about ±1.96 standard errors:

| n questions | Margin at p = 0.8 | Margin at p = 0.5 |
| --- | --- | --- |
| 50 | ± 11.1 points | ± 13.9 points |
| 100 | ± 7.8 points | ± 9.8 points |
| 200 | ± 5.5 points | ± 6.9 points |
| 400 | ± 3.9 points | ± 4.9 points |
| 1,000 | ± 2.5 points | ± 3.1 points |

With 100 questions you cannot reliably see a 3-point improvement by comparing two independent scores. Paired comparisons on the same questions are far more sensitive (Chapter 6), which is one reason to always evaluate competing systems on the same set. A practical target is a few hundred questions for a first serious set, growing over time, with at least 30 to 50 per question type you report separately.

### 2.7 Splits, versions and freshness

- Keep a **development set** for tuning and a **held-out test set** you look at rarely, to avoid tuning to the test.
- **Version** the set (and the corpus snapshot it refers to); results are only comparable on the same version.
- **Refresh**: documents change, so reference answers go stale. Re-validate labels when the corpus changes, and keep adding real failures from production.

## Chapter 3. Retrieval metrics

Retrieval metrics compare a ranked list with relevance labels. Use **recall@k** for the first stage (did the candidates include the evidence?), **nDCG@k** or **MRR** for the final ranking (is the best evidence near the top?), and report them at the k values your pipeline actually uses.

### 3.1 Definitions

For one query, let rel\_i be the relevance of the item at rank i (binary or graded) and R the number of relevant items in the collection.

- **Precision@k**: relevant items in the top k, divided by k.
- **Recall@k**: relevant items in the top k, divided by R.
- **Hit rate@k**: 1 if any relevant item is in the top k, else 0 (equal to recall@k when R = 1).
- **Reciprocal rank**: 1 / (rank of the first relevant item), 0 if none; its mean over queries is **MRR**.
- **Average precision (AP)**: the mean of precision@i over the ranks i where relevant items appear, divided by R overall; its mean over queries is **MAP**.

```latex
\mathrm{AP} = \frac{1}{R} \sum_{i=1}^{n} \mathrm{P@}i \cdot \mathbb{1}[\text{item } i \text{ relevant}]
```

- **nDCG@k** handles graded relevance and rewards putting the most relevant items first:

```latex
\mathrm{DCG@}k = \sum_{i=1}^{k} \frac{2^{\mathrm{rel}_i} - 1}{\log_2(i + 1)}, \qquad \mathrm{nDCG@}k = \frac{\mathrm{DCG@}k}{\mathrm{IDCG@}k}
```

where IDCG@k is the DCG of the ideal ordering. Some libraries use rel\_i instead of 2^rel\_i − 1 as the gain; both are common, so state which one you use.

### 3.2 A worked example

A system returns five documents with graded relevance (0 to 3) of 3, 0, 2, 1, 0, and the collection has exactly three relevant documents (the ones graded 3, 2 and 1).

| Metric | Calculation | Value |
| --- | --- | --- |
| Precision@5 | 3 relevant / 5 | 0.60 |
| Recall@5 | 3 found / 3 relevant | 1.00 |
| Reciprocal rank | first relevant at rank 1 | 1.00 |
| Average precision | (1/1 + 2/3 + 3/4) / 3 | 0.806 |
| DCG@5 (exponential gain) | 7/1 + 0 + 3/2 + 1/2.322 + 0 | 8.931 |
| IDCG@5 (order 3, 2, 1, 0, 0) | 7/1 + 3/1.585 + 1/2 | 9.393 |
| nDCG@5 | 8.931 / 9.393 | 0.951 |

With linear gain instead the nDCG@5 is 0.931. The score is below 1 only because the grade-2 document sits at rank 3 behind an irrelevant one.

### 3.3 Context metrics used by RAG frameworks

RAG evaluation libraries often report two retrieval-side metrics defined with respect to the final context given to the generator:

- **Context precision**: are the relevant chunks ranked above the irrelevant ones in the context? Typically computed like average precision over the retrieved chunks, with relevance judged by an LLM against the question or reference answer.
- **Context recall**: what fraction of the statements in the reference answer can be attributed to the retrieved context? This measures whether the context contained everything needed, without needing chunk-level labels.

They are convenient when you have reference answers but no chunk labels, at the cost of depending on an LLM judge (Chapter 5).

### 3.4 Practical choices

- **Choose k to match the pipeline**: recall@50 or @100 for the first stage feeding a reranker; nDCG@5 or @10 and MRR for the final list that fills the prompt.
- **Document versus chunk level**: decide whether a hit is any chunk of a relevant document or a specific chunk; chunk-level is stricter and better for diagnosing chunking.
- **Macro-average** over queries (each query counts once), and also report **per question type**, because averages hide where a system fails.
- **Unjudged documents** are counted as non-relevant by default, which penalises systems that find new relevant items (Chapter 2.5). Report the share of unjudged documents in each system's top k; if it is high, label more before trusting the comparison.
- **Do not over-optimise** a retrieval metric whose labels are thin: a single labelled relevant document per question (as in SciFact) makes nDCG behave much like MRR.

The library `ranx` and the TREC tool `trec_eval` implement these metrics with well-tested conventions; implementing them yourself once (as in the lab) is still the best way to understand them.

## Chapter 4. Generation metrics

An answer can fail in independent ways: it can be wrong, unsupported by its sources, off-topic, badly cited, or it can answer when it should have abstained. Measure these separately, because each points to a different fix. The most informative metrics decompose the answer into small claims and check each one.

### 4.1 Correctness against a reference

- **Exact match** works only for short, canonical answers (a number, a code, a name).
- **Token F1** (from extractive QA) compares word overlap with the reference: precision = overlap / answer tokens, recall = overlap / reference tokens, F1 their harmonic mean. Example: reference "21 days per year", answer "Employees get 21 days": overlap {21, days}, precision 2/4, recall 2/4, F1 = 0.5 for a correct answer. Token overlap punishes paraphrase and rewards verbose answers that happen to share words.
- **Embedding similarity** to the reference is smoother but cannot tell "21 days" from "12 days".
- **Key-fact coverage** is the practical standard: for each labelled key fact, a judge decides whether the answer states it (and states nothing contradicting it). Correctness = facts covered / facts required. It is interpretable, robust to wording, and supports partial credit.
- **Pairwise preference** against a baseline system ("which answer is better?") is useful when no reference exists, but needs bias controls (Chapter 5).

### 4.2 Faithfulness (groundedness)

Faithfulness asks whether everything the answer claims is supported by the retrieved context, regardless of whether it is true in the world. The usual recipe: split the answer into atomic claims, check each against the context with an NLI model or an LLM judge, and report:

```latex
\text{faithfulness} = \frac{\text{claims supported by the context}}{\text{claims in the answer}}
```

Faithfulness and correctness diverge in two informative ways. **Faithful but wrong**: the context itself was wrong or outdated, so fix retrieval or content. **Correct but unfaithful**: the model answered from its own memory, which happened to be right; that is still a defect in a system that promises cited, auditable answers, and it will be wrong on private or changed facts.

### 4.3 Answer relevance

Does the answer address the question asked, rather than a related one? Measure it with an LLM judge, or with the trick some libraries use: generate questions that the answer would answer, embed them, and compare with the original question. Low relevance often comes from retrieval that pulled the model towards a neighbouring topic.

### 4.4 Citation precision and recall

Following the ALCE benchmark (Gao et al., 2023):

- **Citation recall**: the fraction of answer statements that are fully supported by the union of their cited sources. Statements with no citation count as unsupported.
- **Citation precision**: the fraction of citations that are actually needed: a citation is counted as irrelevant if it does not support the statement on its own and removing it does not change whether the remaining citations support the statement.

Both are computed with an NLI model or LLM judge per statement. Add the deterministic checks from Part 5 (every cited id exists).

### 4.5 Abstention

With answerable and unanswerable questions in the set, build a confusion matrix:

|  | System answered | System abstained |
| --- | --- | --- |
| Answerable question | Score correctness | **False refusal** |
| Unanswerable question | **False answer** (hallucination risk) | Correct abstention |

Report the false-refusal rate (abstained on answerable questions), the false-answer rate (answered unanswerable questions), and accuracy on answered questions. Moving the abstention threshold trades the two error types (Part 5, Chapter 6.5).

### 4.6 Everything else worth checking

- **Completeness** for multi-part questions (every part addressed).
- **Format and instruction adherence**: language, length, required structure, valid JSON.
- **Safety**: no restricted content for users without access (test with role-specific questions), prompt-injection success rate on adversarial documents, policy compliance.
- **Efficiency**: tokens in and out, latency, cost per answer.

### 4.7 Evaluation frameworks

You will meet these tools in job descriptions; as of October 2026 the commonly used ones include **Ragas** (a library of RAG metrics such as faithfulness, answer relevancy, context precision and context recall), **DeepEval** (pytest-style LLM tests with RAG and agent metrics), **TruLens** (feedback functions, including the "RAG triad" of context relevance, groundedness and answer relevance), **Arize Phoenix** and **Langfuse** (open-source tracing with evaluation), **LangSmith** (LangChain's tracing, datasets and experiments), and **Braintrust** (a hosted evaluation and observability platform). Each project's own documentation is the reference for its current metric definitions. Three cautions: most of their metrics are LLM judges underneath, so they inherit judge biases and must be validated against human labels; definitions differ between libraries and versions, so numbers from different tools are not comparable; and none of them replaces a well-built evaluation set. Implement the core metrics yourself once (the lab does) so you know what the libraries compute.

## Chapter 5. LLM-as-judge

An LLM judge scores outputs at a fraction of the cost of human review, which makes large, frequent evaluations possible. It is also a model with biases and errors, so treat it like any classifier: design it carefully, measure its agreement with human labels, and only then trust its numbers.

### 5.1 Judge designs

- **Pointwise with a rubric**: score one answer against explicit criteria. Binary pass/fail or a small number of well-defined levels is more reliable than a 1-to-10 scale, whose middle values judges use inconsistently.
- **Reference-based**: check the answer against the reference answer or, better, against each labelled key fact.
- **Claim-level verification**: decompose the answer into claims and check each against the context (faithfulness) or the reference (correctness). Small, concrete judgements are easier to get right than one holistic score.
- **Pairwise**: show two answers and ask which is better. Good for comparing systems without references; most prone to position and length bias.

Zheng et al. (2023) found that strong LLM judges agreed with human preferences at roughly the level humans agree with each other on their benchmarks, while documenting the biases below. That result is encouraging, not a guarantee for your domain.

### 5.2 Known biases

- **Position bias**: in pairwise comparisons, a preference for whichever answer appears first (or second).
- **Verbosity bias**: longer answers look more thorough and win more often.
- **Self-preference**: a judge may favour outputs from its own model family.
- **Leniency**: judges tend to pass borderline answers, so they miss failures, which are exactly what you want to catch.
- **Surface sensitivity**: formatting, confident tone and the presence of citations can sway scores regardless of substance.

### 5.3 Mitigations

1. **Swap positions** in pairwise judging and count a win only if the verdict is consistent in both orders (or average the two).
2. **Use narrow, concrete rubrics**, ideally binary questions per criterion ("Does the answer state the 75-dollar meal limit?").
3. **Ask for evidence before the verdict**: the judge quotes the supporting text from the context, then decides. Unsupported quotes can be checked in code.
4. **Prefer a different, strong model family** for judging than for generating, at temperature 0.
5. **Control length** in comparisons, or report length alongside win rates.
6. **Include calibration examples** in the judge prompt: a clear pass, a clear fail, and a borderline case with the intended verdict.

### 5.4 Validate the judge against humans

Label 100 to 200 representative items by hand (ideally two annotators, with disagreements resolved), run the judge on them, and compute agreement. Raw accuracy is misleading when one class dominates, so use **Cohen's kappa**, which corrects for chance agreement:

```latex
\kappa = \frac{p_o - p_e}{1 - p_e}, \qquad p_e = \sum_{c} p_{\text{human}}(c)\, p_{\text{judge}}(c)
```

where p\_o is the observed agreement and p\_e the agreement expected by chance from each rater's label frequencies.

**Worked example.** On 100 answers:

|  | Human: pass | Human: fail |
| --- | --- | --- |
| Judge: pass | 60 | 12 |
| Judge: fail | 8 | 20 |

p\_o = (60 + 20) / 100 = 0.80. The human passes 68%, the judge 72%, so p\_e = 0.68 × 0.72 + 0.32 × 0.28 = 0.579, and κ = (0.80 − 0.579) / (1 − 0.579) = 0.52, conventionally described as moderate agreement. More importantly, the judge caught only 20 of the 32 human-labelled failures: a **failure recall of 62.5%**. A judge that misses more than a third of real failures will make a system look better than it is, and that is the number to improve first (narrower rubric, evidence-first prompting, a stronger judge). Also measure human-human agreement on a subset; it is the ceiling you can expect.

### 5.5 Correcting a judge's bias in aggregate

If the judge's sensitivity (share of truly passing answers it passes) and specificity (share of truly failing answers it fails) are known from the validation set, you can correct an observed pass rate on new data:

```latex
\hat{p}_{\text{true}} = \frac{p_{\text{observed}} + \text{specificity} - 1}{\text{sensitivity} + \text{specificity} - 1}
```

In the example, sensitivity = 60/68 = 0.882 and specificity = 20/32 = 0.625. If the judge passes 75% of answers from a new system, the corrected estimate is (0.75 + 0.625 − 1) / (0.882 + 0.625 − 1) ≈ 0.74. The correction is only as good as the validation set it came from, and the uncertainty in sensitivity and specificity widens the confidence interval.

### 5.6 Practicalities

- **Re-validate** whenever the judge model, its prompt, or the type of answers changes.
- **Cost**: claim-level judging can need several calls per answer; cache judgements keyed by (judge version, input), and use cheaper models for simple checks such as "is this a refusal?".
- **Do not judge with the system under test** if you can avoid it, and never tune a system on the same judged set you report on.

## Chapter 6. Statistics for evaluation

Every evaluation score is an estimate from a sample of questions, and a difference between two systems is real only if it is larger than the noise. Report confidence intervals, compare systems with **paired** tests on the same questions, size your test set for the effects you care about, and guard against fooling yourself with many comparisons.

### 6.1 Per-question scores

Keep a score per question (1 or 0 for correct, a value for nDCG, the faithfulness fraction), not only the average. Everything below works on these per-question vectors, and they let you inspect which questions changed.

### 6.2 Bootstrap confidence intervals

The bootstrap works for any metric without formulas:

1. From the n per-question scores, draw n with replacement.
2. Compute the metric on that resample.
3. Repeat B times (for example 10,000).
4. The 2.5th and 97.5th percentiles of the B values form a 95% confidence interval.

For a simple mean the interval is close to ±1.96 × s/√n, matching Chapter 2.6; the bootstrap's value is that it works equally for nDCG, medians, ratios and judge-based scores.

### 6.3 Paired comparisons

Two systems evaluated on the **same** questions have correlated per-question scores: hard questions are hard for both. Compare them through per-question differences d\_i = a\_i − b\_i. The variance of the mean difference is:

```latex
\mathrm{Var}(\bar{d}) = \frac{\sigma_a^2 + \sigma_b^2 - 2\,\mathrm{Cov}(a, b)}{n}
```

Positive covariance shrinks it. For example, with per-question standard deviations of 0.4 for both systems, correlation 0.7 and n = 200, the standard error of the difference is 0.022 when paired, against 0.040 if you treated the scores as independent: the paired analysis can detect differences about half the size.

Tools for paired comparisons:

- **Paired bootstrap**: resample question indices, compute the mean difference each time, and read off a confidence interval for the difference. If it excludes 0, the difference is significant at that level.
- **Paired t-test** on the d\_i: fine for averages over a few hundred questions.
- **Sign-flip permutation test**: randomly flip the sign of each d\_i many times to build the null distribution of the mean difference. Distribution-free and simple.
- **McNemar's test** for binary outcomes (correct or not): only the **discordant** questions matter, where one system is right and the other wrong. With b questions that only A gets right and c that only B gets right:

```latex
\chi^2 = \frac{(|b - c| - 1)^2}{b + c}
```

with one degree of freedom, or an exact binomial test of c successes in b + c trials with p = 0.5.

**Worked example.** On 400 questions, system A is right and B wrong on 30, and B right and A wrong on 15. χ² = (15 − 1)² / 45 = 4.36, p ≈ 0.037; the exact binomial test gives p ≈ 0.036. A is better at the 5% level, and the 355 questions where both agree contribute nothing to the test.

### 6.4 How many questions do you need?

To detect a mean paired difference δ with per-question standard deviation of differences σ\_d, at two-sided significance α = 0.05 and power 80%, approximately:

```latex
n \approx \left( \frac{(z_{1-\alpha/2} + z_{1-\beta})\,\sigma_d}{\delta} \right)^2 = \left( \frac{2.80\,\sigma_d}{\delta} \right)^2
```

| σ\_d | Difference to detect δ | Questions needed |
| --- | --- | --- |
| 0.30 | 0.05 (5 points) | about 280 |
| 0.30 | 0.03 (3 points) | about 785 |
| 0.20 | 0.03 (3 points) | about 350 |

Estimate σ\_d from a pilot comparison. If the change you want to detect is small, you need hundreds of questions even with pairing, which is why a 50-question set can tell you only about large effects.

### 6.5 Many comparisons

If you try 20 configurations and test each at the 5% level, you expect about one "significant" improvement by chance alone. Defences: decide the primary metric before experimenting; tune on the development set and confirm the winner once on the held-out test set; and for formal claims, correct the threshold (for example Bonferroni: α divided by the number of comparisons).

### 6.6 Run-to-run variance

LLM outputs vary between runs when sampling is on, and even at temperature 0 some serving stacks are not fully deterministic. Judges vary too. Measure this: run the same system twice and compare; if two runs of the same system differ by two points, a two-point gain from a change means nothing. Fix seeds where possible, use temperature 0 for evaluation, and average several runs when variance is high.

### 6.7 How to report a result

A good result statement contains: the evaluation set and its version; n; each system's score with a 95% confidence interval; the paired difference with its confidence interval and test; a breakdown by question type; and latency and cost. For example: "On eval-set v3 (n = 412), hybrid + reranker scored nDCG@10 0.712 \[0.684, 0.739\] versus 0.671 \[0.641, 0.699\] for hybrid alone; paired difference +0.041 \[+0.024, +0.058\]; gains concentrated in multi-hop (+0.09) with no change on single-fact questions; added p95 latency 140 ms."

## Chapter 7. Online evaluation

Offline evaluation predicts; online evaluation confirms. In production you combine user feedback and behavioural signals, controlled experiments for changes that matter, regression tests that block bad releases, and monitoring that catches drift and content gaps. Every production failure you find should become a new offline test case.

### 7.1 Feedback signals

- **Explicit**: thumbs up or down, ratings, free-text reasons, corrections. Valuable but sparse, and biased towards strong reactions; only a small fraction of users give it.
- **Implicit**: copying the answer, clicking a citation, asking the same question again in different words shortly after (a reformulation suggests failure), escalating to a human or opening a ticket, abandoning the session. Plentiful but ambiguous: a user who does not click citations may simply trust the answer.

Validate implicit signals against labelled samples before using them as success metrics, and log them with the full trace (query, retrieved ids, prompt version, answer) so each signal can be traced to its cause.

### 7.2 A/B tests

Randomly assign **users** (not individual requests, which would mix experiences within a conversation) to the current system or the candidate, and compare a pre-chosen **primary metric**, for example escalation rate, resolution rate or thumbs-up rate, while watching **guardrail metrics** such as p95 latency, cost per request, abstention rate and safety incidents.

The sample size per arm needed to detect a change δ in a proportion p, at α = 0.05 and 80% power, is approximately:

```latex
n_{\text{per arm}} \approx \frac{2\,(z_{1-\alpha/2} + z_{1-\beta})^2\, p(1 - p)}{\delta^2}
```

| Baseline rate p | Change to detect δ | Users per arm |
| --- | --- | --- |
| 0.30 | 5 points | about 1,300 |
| 0.30 | 2 points | about 8,200 |
| 0.10 | 1 point | about 14,100 |

Operational checks: confirm the traffic split matches the design (a **sample ratio mismatch** signals a bug in assignment or logging), run long enough to cover weekly cycles and let novelty effects fade, and decide the stopping rule in advance rather than stopping when the result looks good.

### 7.3 Interleaving

For ranking changes with click feedback, **interleaving** merges the two systems' result lists into one list shown to the same user (for example with team-draft interleaving) and credits clicks to the system that contributed each result. Because each user compares both systems at once, interleaving usually needs far fewer users than an A/B test to detect a ranking difference. It suits search interfaces where users see and click result lists, less so pure chat answers.

### 7.4 Shadow traffic and gradual rollout

- **Shadow mode**: run the candidate pipeline on real queries without showing its answers; compare outputs with LLM judges and check latency and cost under real load. Catches crashes, slowdowns and obvious regressions with zero user risk.
- **Canary and gradual rollout**: release to 1%, then 10%, then everyone, with automatic rollback if guardrails break.

### 7.5 Regression tests in CI

Treat prompts, models, retrieval settings and chunking configurations as code. On every change, run:

1. **Must-pass cases**: a small set of behaviours that must never break (abstain on known unanswerable questions, never reveal restricted content, keep product codes intact in rewriting, cite only real ids).
2. **A fast evaluation subset** (for example 100 to 200 questions) with thresholds set from the confidence intervals of Chapter 6, so normal noise does not fail builds but real regressions do.
3. **The full evaluation** nightly or before release.

### 7.6 Monitoring

Dashboards and alerts for: retrieval score distributions (a drop suggests broken indexing or new topics), abstention and false-refusal rates, citation-check failure rate, latency and cost, feedback rates, and index freshness. Cluster incoming queries regularly: a cluster of new questions with low retrieval scores is a **content gap** (documentation that does not exist yet), which is often more valuable to fix than any model change. Sample traces into a human review queue each week, label them, and add the failures to the evaluation set. Apply the same privacy rules to logs as to the index.

## Chapter 8. Hands-on lab

You will implement retrieval metrics and the statistics of Chapter 6 from scratch and use them to compare two SciFact retrievers properly; generate and filter a synthetic test set from the Nimbus corpus; build key-fact, faithfulness and abstention judges; and validate a judge against known labels, including a position-bias test. Metrics, statistics, answer corruption and parsing code were tested in a sandbox (the kappa function matches scikit-learn exactly); model cells need Hugging Face access.

### Lab 0. Setup

Run Part 5's Lab 0 cell (SciFact, `doc_ids`, `query_ids`, `rel`, bge-small with `embed_docs` and `embed_queries`, BM25, `S_dense`, `S_bm25`, `S_hybrid`, the Qwen3-4B `chat` function); the notebook for this part includes a copy of that cell. The Nimbus corpus comes from `ragkit`.

```python
from ragkit import CORPUS, split_sentences, chunk_document
import numpy as np, re, json
from collections import Counter
from scipy.stats import binomtest
```

### Lab 1. Retrieval metrics from scratch

```python
def precision_at_k(rels, k): return sum(1 for r in rels[:k] if r > 0) / k
def recall_at_k(rels, k, n_rel): return sum(1 for r in rels[:k] if r > 0) / n_rel if n_rel else 0.0
def reciprocal_rank(rels): return next((1.0 / (i + 1) for i, r in enumerate(rels) if r > 0), 0.0)

def average_precision(rels, n_rel):
    hits, total = 0, 0.0
    for i, r in enumerate(rels):
        if r > 0:
            hits += 1
            total += hits / (i + 1)
    return total / n_rel if n_rel else 0.0

def dcg(gains): return sum(g / np.log2(i + 2) for i, g in enumerate(gains))

def ndcg_at_k(rels, judged_rels, k, exponential=True):
    """rels: graded relevance of the returned list; judged_rels: grades of all relevant items."""
    gain = (lambda r: 2 ** r - 1) if exponential else (lambda r: r)
    idcg = dcg([gain(r) for r in sorted(judged_rels, reverse=True)[:k]])
    return dcg([gain(r) for r in rels[:k]]) / idcg if idcg > 0 else 0.0

rels = [3, 0, 2, 1, 0]                     # the Chapter 3 worked example
print(precision_at_k(rels, 5), recall_at_k(rels, 5, 3), reciprocal_rank(rels),
      round(average_precision(rels, 3), 3), round(ndcg_at_k(rels, [3, 2, 1], 5), 3))
# 0.6 1.0 1.0 0.806 0.951

def per_query(S, metric="ndcg", k=10):
    """Per-query scores on all SciFact test queries (binary relevance, grade 1)."""
    out = []
    for i, qid in enumerate(query_ids):
        top = np.argsort(-S[i])[:k]
        rels_i = [1 if doc_ids[j] in rel[qid] else 0 for j in top]
        n_rel = len(rel[qid])
        out.append(ndcg_at_k(rels_i, [1] * n_rel, k) if metric == "ndcg" else float(rels_i[0] == 1))
    return np.array(out)

ndcg_dense, ndcg_hybrid = per_query(S_dense), per_query(S_hybrid)
print("mean nDCG@10  dense:", ndcg_dense.mean().round(3), " hybrid:", ndcg_hybrid.mean().round(3))
```

### Lab 2. Is the difference real?

```python
def bootstrap_ci(scores, B=10_000, alpha=0.05, seed=0):
    rng = np.random.default_rng(seed)
    scores = np.asarray(scores, float)
    means = scores[rng.integers(0, len(scores), size=(B, len(scores)))].mean(axis=1)
    return scores.mean(), np.quantile(means, alpha / 2), np.quantile(means, 1 - alpha / 2)

def paired_bootstrap(a, b, **kw):
    return bootstrap_ci(np.asarray(a, float) - np.asarray(b, float), **kw)

def sign_flip_test(a, b, n_perm=20_000, seed=0):
    rng = np.random.default_rng(seed)
    d = np.asarray(a, float) - np.asarray(b, float)
    null = np.abs((rng.choice([-1.0, 1.0], size=(n_perm, len(d))) * d).mean(axis=1))
    return (1 + (null >= abs(d.mean())).sum()) / (1 + n_perm)

def mcnemar(a_ok, b_ok):
    a_ok, b_ok = np.asarray(a_ok, bool), np.asarray(b_ok, bool)
    only_a, only_b = int((a_ok & ~b_ok).sum()), int((~a_ok & b_ok).sum())
    p = binomtest(only_b, only_a + only_b, 0.5).pvalue if only_a + only_b else 1.0
    return only_a, only_b, p

fmt = lambda t: f"{t[0]:.3f} [{t[1]:.3f}, {t[2]:.3f}]"
print("dense      ", fmt(bootstrap_ci(ndcg_dense)))
print("hybrid     ", fmt(bootstrap_ci(ndcg_hybrid)))
print("difference ", fmt(paired_bootstrap(ndcg_hybrid, ndcg_dense)),
      " sign-flip p =", round(sign_flip_test(ndcg_hybrid, ndcg_dense), 4))
print("hit@1 McNemar (only hybrid right, only dense right, p):",
      mcnemar(per_query(S_hybrid, "hit1"), per_query(S_dense, "hit1")))
```

Compare the overlap of the two systems' individual intervals with the paired interval for the difference. In our sandbox test on synthetic per-question scores (400 questions, systems differing by 0.03), the individual intervals overlapped substantially (\[0.525, 0.586\] and \[0.495, 0.556\]), yet the paired interval for the difference was \[0.011, 0.047\] with a permutation p of about 0.002. **Overlapping individual intervals do not mean "no difference"** when the comparison is paired; always test the difference directly.

### Lab 3. Generate a synthetic test set

```python
chunks = [c for doc in CORPUS for c in chunk_document(doc)]

def extract_json(text):
    m = re.search(r"\{.*\}|\[.*\]", text, flags=re.S)
    try:
        return json.loads(m.group(0)) if m else None
    except json.JSONDecodeError:
        return None

GEN_PROMPT = ("You write test questions for an employee help assistant.\n"
              "Source passage (from '{title}'):\n{text}\n\n"
              "Write ONE question an employee might really ask that this passage answers. Use everyday "
              "wording, do not copy phrases longer than three words, and do not mention 'the passage'. "
              'Return JSON: {{"question": ..., "answer": ..., "key_facts": [short facts the answer must contain]}}')

BANNED = re.compile(r"\b(passage|document|text above|according to)\b", re.I)
test_set, rejected = [], Counter()
for c in chunks:
    item = extract_json(chat([{"role": "user", "content": GEN_PROMPT.format(title=c["title"], text=c["text"])}], 200))
    if not isinstance(item, dict) or not item.get("question") or not item.get("key_facts"):
        rejected["unparseable"] += 1; continue
    if BANNED.search(item["question"]):
        rejected["mentions the source"] += 1; continue
    if item["question"].lower() in {t["question"].lower() for t in test_set}:
        rejected["duplicate"] += 1; continue
    test_set.append({**item, "gold_chunk": c["chunk_id"], "gold_doc": c["doc_id"], "type": "answerable"})

UNANSWERABLE = ["Which company provides our dental insurance?", "What is the NX-7's list price?",
                "How many parking spaces does the Montreal office have?", "Does Nimbus match 401(k) contributions?"]
test_set += [{"question": q, "answer": None, "key_facts": [], "type": "unanswerable"} for q in UNANSWERABLE]
print(len(test_set), "items; rejected:", dict(rejected))
for t in test_set[:3]:
    print(json.dumps(t, indent=1))
```

Now do the step that automation cannot replace: **read every generated item** (there are only about 20 here) and fix or delete bad ones. Typical problems: questions that only make sense with the passage in view, answers that add facts not in the passage, key facts that are too vague ("the policy applies"). In a real project you would review a sample and report the rejection rate. The unanswerable questions were written by hand on purpose: an LLM asked to invent unanswerable questions often produces ones that the corpus does answer.

### Lab 4. The system under test and three judges

```python
E_n = embed_docs([f"{c['title']}\n{c['text']}" for c in chunks])
REFUSAL = "I don't know based on the provided documents."
RAG_SYSTEM = ("Answer using only the sources. Cite source ids like [S1]. If the sources do not contain "
              f"the answer, reply exactly: \"{REFUSAL}\"")

def rag(question, k=3):
    top = np.argsort(-(E_n @ embed_queries([question])[0]))[:k]
    sources = {f"S{n}": chunks[j]["text"] for n, j in enumerate(top, 1)}
    ctx = "\n".join(f'<source id="{sid}">\n{t}\n</source>' for sid, t in sources.items())
    ans = chat([{"role": "system", "content": RAG_SYSTEM},
                {"role": "user", "content": f"{ctx}\n\nQuestion: {question}"}], 200)
    return {"answer": ans, "sources": sources, "retrieved": [chunks[j]["chunk_id"] for j in top]}

def yes_no(prompt):
    out = chat([{"role": "user", "content": prompt}], 5).strip().lower()
    return out.startswith("yes")

def judge_key_facts(answer, facts):
    """Share of key facts the answer states without contradiction."""
    ok = [yes_no(f"ANSWER:\n{answer}\n\nFACT: {f}\n\nDoes the answer state this fact with the same "
                 "meaning and without contradicting it? Reply only yes or no.") for f in facts]
    return sum(ok) / len(ok) if ok else None

def judge_faithfulness(answer, sources):
    """Split the answer into claims, then check each claim against the retrieved context."""
    claims = extract_json(chat([{"role": "user", "content":
        f"Split this answer into short, self-contained factual claims. Return a JSON list of strings.\n\n{answer}"}], 200))
    if not isinstance(claims, list) or not claims:
        return None, []
    context = "\n".join(sources.values())
    verdicts = [yes_no(f"CONTEXT:\n{context}\n\nCLAIM: {c}\n\nIs the claim fully supported by the context? "
                       "Reply only yes or no.") for c in claims]
    return sum(verdicts) / len(verdicts), list(zip(claims, verdicts))

is_refusal = lambda a: REFUSAL.lower().rstrip(".") in a.lower()

rows = []
for t in test_set:
    out = rag(t["question"])
    row = {"type": t["type"], "refused": is_refusal(out["answer"]),
           "retrieval_hit": t.get("gold_chunk") in out["retrieved"] if t["type"] == "answerable" else None}
    if t["type"] == "answerable" and not row["refused"]:
        row["correctness"] = judge_key_facts(out["answer"], t["key_facts"])
        row["faithfulness"], _ = judge_faithfulness(out["answer"], out["sources"])
    rows.append(row)

import pandas as pd
df = pd.DataFrame(rows).reindex(   # the columns exist even if every answer was a refusal
    columns=["type", "refused", "retrieval_hit", "correctness", "faithfulness"])
ans = df[df.type == "answerable"]
print("retrieval hit@3:      ", round(ans.retrieval_hit.astype(float).mean(), 3))
print("false refusals:       ", round(ans.refused.astype(float).mean(), 3))
print("key-fact correctness: ", round(ans.correctness.astype(float).mean(), 3))
print("faithfulness:         ", round(ans.faithfulness.astype(float).mean(), 3))
print("correct abstentions:  ", round(df[df.type == "unanswerable"].refused.astype(float).mean(), 3))
```

Here the judge is the same model as the generator, which Chapter 5 warns against (self-preference); we accept it because it is the only LLM in a free notebook. With more resources, judge with a different, stronger model. Read the per-claim verdicts for a few answers: judges explain more than their averages.

### Lab 5. Validate a judge with known labels

Human labels are the gold standard, but you can test a correctness judge cheaply with **known-wrong answers**: take the reference answers (correct by construction) and corrupt every number in them (wrong by construction).

```python
def corrupt_numbers(text, seed=0):
    rng = np.random.default_rng(seed)
    def repl(m):
        x = float(m.group())
        new = x + rng.choice([-1, 1]) * max(1, round(abs(x) * 0.3))
        return str(int(new)) if m.group().isdigit() else f"{new:.2f}".rstrip("0").rstrip(".")
    out = re.sub(r"\d+(?:\.\d+)?", repl, text)
    return out if out != text else None                 # None: no number to corrupt

items = []
for t in test_set:
    if t["type"] != "answerable":
        continue
    items.append((t["question"], t["answer"], t["answer"], 1))           # correct
    bad = corrupt_numbers(t["answer"])
    if bad:
        items.append((t["question"], t["answer"], bad, 0))                # wrong

def judge_correct(question, reference, candidate):
    return int(yes_no(f"QUESTION: {question}\nREFERENCE ANSWER: {reference}\nCANDIDATE ANSWER: {candidate}\n\n"
                      "Is the candidate answer correct and consistent with the reference? Reply only yes or no."))

def cohen_kappa(h, j):
    h, j = np.asarray(h), np.asarray(j)
    po = (h == j).mean()
    pe = sum((h == c).mean() * (j == c).mean() for c in np.union1d(h, j))
    return (po - pe) / (1 - pe)

truth = np.array([y for *_, y in items])
pred = np.array([judge_correct(q, r, c) for q, r, c, _ in items])
print("items:", len(items), "| agreement:", (truth == pred).mean().round(3),
      "| kappa:", round(cohen_kappa(truth, pred), 3),
      "| failure recall:", ((pred == 0) & (truth == 0)).sum() / max((truth == 0).sum(), 1))
```

The failure recall is the number to watch: how many of the known-wrong answers did the judge catch? Number corruption is an easy test (a careful judge should catch nearly all); real failures, such as subtly wrong conditions or missing caveats, are harder, which is why a human-labelled validation set is still needed before you trust a judge in production.

### Lab 6. Test a pairwise judge for position bias

```python
def pairwise(question, ans_1, ans_2):
    out = chat([{"role": "user", "content":
        f"QUESTION: {question}\n\nANSWER 1: {ans_1}\n\nANSWER 2: {ans_2}\n\n"
        "Which answer is more accurate? Reply only 1 or 2."}], 3).strip()
    return 1 if out.startswith("1") else 2

consistent, first_wins, n = 0, 0, 0
for t in test_set:
    if t["type"] != "answerable" or not corrupt_numbers(t["answer"]):
        continue
    good, bad = t["answer"], corrupt_numbers(t["answer"])
    v1 = pairwise(t["question"], good, bad)            # correct answer shown first
    v2 = pairwise(t["question"], bad, good)            # correct answer shown second
    consistent += (v1 == 1 and v2 == 2)
    first_wins += (v1 == 1) + (v2 == 1)
    n += 1
print(f"consistent and correct in both orders: {consistent}/{n}")
print(f"share of verdicts for position 1: {first_wins / (2 * n):.2f} (0.50 means no position bias)")
```

Without a reference answer, the judge must recognise the right numbers from its own knowledge, which it cannot do for a fictional company; so the interesting output here is the position statistic. If verdicts lean towards one position, swap-and-require-agreement (Chapter 5.3) is essential for any pairwise evaluation you run.

## Interview questions with model answers

These 22 questions cover evaluation design, metrics, judges, statistics and online measurement. "How would you evaluate this?" follows almost every RAG design question, so practise answering it in layers: components, end-to-end, online.

### Design and datasets

**Q1. How would you evaluate a new RAG assistant before launch?** Build a versioned evaluation set of a few hundred questions covering factual, procedural, multi-hop, temporal, unanswerable, ambiguous, conversational, restricted and adversarial cases, with graded relevant chunks, reference answers and key facts. Measure retrieval (recall@50 for candidates, nDCG@10 and MRR for the final list), generation (key-fact correctness, faithfulness, citation precision and recall, abstention errors), safety (leak and injection tests), latency and cost. Validate any LLM judge against human labels, report confidence intervals, and plan an A/B test and monitoring for launch.

**Q2. You have no users yet. Where do evaluation questions come from?** Subject-matter experts, existing FAQs and resolved tickets, and LLM-generated questions from the corpus with filtering and human review of a sample, plus hand-written unanswerable and adversarial cases. After launch, sample real queries continuously.

**Q3. What goes wrong with synthetic evaluation questions, and how do you fix it?** They copy the source's wording (flattering retrieval), reference "the passage", cluster on easy fact types, and miss real user phrasing. Prompt for user-style, varied question types; forbid copying long phrases; filter automatically; review a sample by hand; avoid filters that use your own retriever; and mix in real questions as soon as possible.

**Q4. What labels do you store for each question?** Graded relevant documents or chunks, a reference answer, key facts the answer must contain, the expected behaviour (answer, abstain, clarify, route), and metadata such as type, difficulty, language and user role.

**Q5. How do you avoid an evaluation set that favours your current system?** Pool relevance judgements from several different retrieval systems, label unjudged documents surfaced by new systems before trusting comparisons, and report the share of unjudged documents in each system's results.

**Q6. How many evaluation questions do you need?** It depends on the effect size: the 95% margin for a proportion near 0.8 is about ±8 points with 100 questions and ±4 with 400. Paired comparisons need fewer, but detecting a 3-point change with σ\_d ≈ 0.3 still needs roughly 800. Start with a few hundred and grow; ensure 30 to 50 per reported subgroup.

### Metrics

**Q7. Define nDCG and explain why it is used.** DCG sums gains (often 2^rel − 1) discounted by log₂(rank + 1); nDCG divides by the ideal DCG so scores lie in \[0, 1\]. It handles graded relevance and rewards placing the most relevant items first, which matches how a generator mostly uses the top chunks.

**Q8. When do you use recall@k versus MRR versus nDCG?** Recall@k for the candidate stage (did we fetch the evidence at all?); MRR when one relevant item is enough and position of the first matters; nDCG@k for the final ranked list, especially with graded labels.

**Q9. What is the difference between faithfulness and correctness?** Correctness compares the answer with the truth (reference or key facts); faithfulness checks that every claim is supported by the retrieved context. Faithful-but-wrong points to bad or outdated content or retrieval; correct-but-unfaithful means the model answered from memory, which is unverifiable and fails on private or changed facts.

**Q10. How do you measure faithfulness?** Split the answer into atomic claims, check each against the context with an NLI model or an LLM judge, and report supported claims divided by total claims, with per-claim verdicts kept for inspection.

**Q11. Define citation precision and recall.** Citation recall: share of answer statements fully supported by their cited sources. Citation precision: share of citations that are needed, a citation counting as irrelevant if it does not support the statement alone and removing it does not change support. Both use an NLI or LLM judge per statement.

**Q12. How do you evaluate abstention?** Include unanswerable questions; build the answered/abstained by answerable/unanswerable confusion matrix; report false-refusal rate, false-answer rate, and accuracy on answered questions; plot risk versus coverage across thresholds.

### LLM-as-judge

**Q13. What are the main biases of LLM judges?** Position bias in pairwise comparisons, verbosity bias, self-preference for the judge's own model family, leniency (missing failures), and sensitivity to tone, formatting and citations regardless of substance.

**Q14. How do you make an LLM judge reliable?** Narrow, concrete (ideally binary) criteria; decomposition into claims or key facts; evidence quoted before the verdict; a different, strong model family at temperature 0; swapped positions for pairwise judging; calibration examples; and validation against human labels, re-run whenever the judge or its prompt changes.

**Q15. How do you validate a judge, and which number matters most?** Label 100 to 200 items by hand, run the judge, and compute Cohen's kappa (agreement beyond chance) plus the judge's recall on human-labelled failures. Failure recall matters most: a lenient judge hides problems. Compare with human-human agreement as the ceiling.

**Q16. Compute Cohen's kappa for 80% observed agreement when both raters label 50% positive.** p\_e = 0.5 × 0.5 + 0.5 × 0.5 = 0.5, so κ = (0.8 − 0.5)/(1 − 0.5) = 0.6.

### Statistics

**Q17. System B beats A by 1.5 points nDCG@10 on 200 questions. Do you ship it?** Not on that number alone. Compute a paired bootstrap confidence interval or a permutation test on per-question differences; check run-to-run variance; look at per-type changes and guardrails (latency, cost, safety); and confirm on the held-out set if B was tuned on the development set.

**Q18. Why use paired tests?** Both systems answer the same questions, whose difficulty varies; per-question scores are positively correlated, so the variance of the difference is smaller than treating them as independent: Var(d̄) = (σ\_a² + σ\_b² − 2Cov)/n. Paired tests detect smaller real differences with the same data.

**Q19. Explain McNemar's test in this context.** For binary correctness, only discordant questions matter: b where only A is right and c where only B is right. Test whether b and c differ more than chance with χ² = (|b − c| − 1)²/(b + c) or an exact binomial test on c out of b + c with p = 0.5.

**Q20. You tried 30 prompt variants and the best is 2 points better on the dev set. What is the risk?** The winner's curse: with many comparisons, the best one is likely partly lucky. Fix the primary metric in advance, then confirm once on a held-out test set (or correct for multiple comparisons); expect some of the gain to disappear.

### Online

**Q21. How would you A/B test a RAG change?** Randomise by user; pick one primary metric (for example escalation or resolution rate) and guardrails (p95 latency, cost, abstention, safety incidents); size the test (about 8,200 users per arm to detect a 2-point change from 30%); check the traffic split for sample-ratio mismatch; run full weekly cycles; decide stopping rules in advance.

**Q22. What do you monitor in production?** Retrieval score distributions, abstention and false-refusal rates, citation-check failures, feedback and implicit signals, latency and cost, index freshness, and clusters of new queries with low retrieval scores (content gaps); sample traces for weekly human review and add failures to the evaluation set.

## Exercises with solutions

Twelve exercises: six mathematical, three coding, two debugging and one design. Coding exercises reuse the Chapter 8 lab.

### Exercise 1. Metrics with graded labels

A query has four relevant documents with grades 3, 2, 1 and 1. The system returns five documents with grades 0, 2, 3, 0, 1 (one relevant document of grade 1 is missing). Compute precision@5, recall@5, reciprocal rank, average precision and nDCG@5 with exponential gain.

**Solution.** Precision@5 = 3/5 = 0.60. Recall@5 = 3/4 = 0.75. Reciprocal rank = 1/2 (first relevant item at rank 2). AP = (1/2 + 2/3 + 3/5) / 4 = 0.442 (divide by all four relevant documents, including the missed one). DCG@5 = 0 + 3/1.585 + 7/2 + 0 + 1/2.585 = 1.893 + 3.5 + 0.387 = 5.780. IDCG@5 uses the ideal order 3, 2, 1, 1: 7 + 1.893 + 0.5 + 0.431 = 9.824. nDCG@5 = 5.780 / 9.824 = 0.588. The best document sat at rank 3 and a relevant one was missed, so all rank-sensitive metrics are moderate even though precision looks reasonable.

### Exercise 2. Why accuracy misleads for judges

On 200 answers, humans marked 180 as pass and 20 as fail. A lazy judge passes everything. Compute its accuracy, Cohen's kappa and failure recall.

**Solution.** Accuracy = 180/200 = 0.90. Chance agreement p\_e = 0.9 × 1.0 + 0.1 × 0.0 = 0.9, so κ = (0.9 − 0.9)/(1 − 0.9) = 0. Failure recall = 0/20 = 0. A 90%-accurate judge that catches no failures is useless for evaluation, which is why you report kappa and failure recall rather than accuracy.

### Exercise 3. Correct a judge's pass rate

A judge's validation gave sensitivity 0.95 (passes 95% of truly passing answers) and specificity 0.70 (fails 70% of truly failing answers). On a new system it passes 80% of answers. Estimate the true pass rate.

**Solution.** p̂ = (0.80 + 0.70 − 1) / (0.95 + 0.70 − 1) = 0.50 / 0.65 ≈ 0.77. The judge inflates the pass rate by about 3 points because it lets 30% of failures through. Report the corrected estimate with a wider interval, and improve the judge's specificity.

### Exercise 4. McNemar on real-looking counts

On 500 questions, only system A is correct on 22 and only system B is correct on 38. Is B significantly better at the 5% level?

**Solution.** χ² = (|22 − 38| − 1)² / (22 + 38) = 225 / 60 = 3.75, p ≈ 0.053; the exact binomial test gives p ≈ 0.052. Not significant at 5%, though suggestive. Options: add questions (especially of the types where the systems disagree), or accept B on other grounds (cost, latency) knowing it is at least not worse.

### Exercise 5. Size a test set

A pilot comparison gives a per-question standard deviation of differences in nDCG@10 of σ\_d = 0.25. How many questions do you need to detect a 2-point difference with 80% power at α = 0.05?

**Solution.** n ≈ (2.80 × 0.25 / 0.02)² = 35² ≈ 1,225. If that is too many, decide whether a 2-point difference matters; detecting a 4-point difference needs only about a quarter as many questions (about 306).

### Exercise 6. Size an A/B test

The current thumbs-up rate among users who give feedback is 60%. How many feedback-giving users per arm do you need to detect a 3-point change with 80% power at α = 0.05?

**Solution.** n ≈ 2 × 2.80² × 0.6 × 0.4 / 0.03² ≈ 4,190 per arm. Since only a small share of users give feedback, the total number of users exposed must be many times larger, which is why teams often choose a more frequent primary metric (escalations, reformulations) or interleaving for ranking changes.

### Exercise 7 (coding). Break down results by question type

Extend Lab 4 to report correctness and faithfulness with bootstrap confidence intervals per question type, and refusal rates for unanswerable questions.

**Solution.**

```python
for qtype, g in df.groupby("type"):
    if qtype == "answerable":
        for col in ["retrieval_hit", "correctness", "faithfulness"]:
            vals = g[col].dropna().astype(float).values
            if len(vals):
                m, lo, hi = bootstrap_ci(vals)
                print(f"{qtype:<13} {col:<14} {m:.2f} [{lo:.2f}, {hi:.2f}] (n={len(vals)})")
    else:
        print(f"{qtype:<13} correct abstention rate {g.refused.mean():.2f} (n={len(g)})")
```

With about 20 generated questions the intervals will be very wide, which is the lesson: a small synthetic set is enough to build and debug the harness, not to make decisions. Tag real evaluation sets with types (Chapter 2.3) so this breakdown is always available.

### Exercise 8 (coding). Citation precision and recall

Implement ALCE-style citation recall and precision for answers produced by Lab 4's `rag`, using `yes_no` as the support judge.

**Solution.**

```python
def supports(sources, ids, claim):
    ctx = "\n".join(sources[i] for i in ids if i in sources)
    return bool(ctx) and yes_no(f"CONTEXT:\n{ctx}\n\nCLAIM: {claim}\n\nIs the claim fully supported by the context? "
                                "Reply only yes or no.")

def citation_scores(answer, sources):
    sentences = [s for s in re.split(r"(?<=[.!?])\s+", answer.strip()) if s]
    rec_hits, prec_hits, n_cites = 0, 0, 0
    for s in sentences:
        ids = re.findall(r"\[(S\d+)\]", s)
        claim = re.sub(r"\s*\[S\d+\]", "", s).strip()
        full = supports(sources, ids, claim) if ids else False     # uncited sentences count as unsupported
        rec_hits += full
        for c in ids:
            n_cites += 1
            alone = supports(sources, [c], claim)
            needed = full and not supports(sources, [i for i in ids if i != c], claim)
            prec_hits += (alone or needed)
    recall = rec_hits / len(sentences) if sentences else None
    precision = prec_hits / n_cites if n_cites else None
    return recall, precision

out = rag(test_set[0]["question"])
print(out["answer"]); print("citation recall, precision:", citation_scores(out["answer"], out["sources"]))
```

This needs about one judge call per sentence plus up to two per citation, so cache verdicts and run it on a sample when budgets are tight. Sentences without factual content (greetings, "Here is what I found") should be excluded in a real implementation, for example by asking the judge whether a sentence makes a factual claim.

### Exercise 9 (coding). A regression gate for CI

Write `gate(new_scores, baseline_scores, tolerance)` that fails if the lower bound of the paired 95% interval for (new − baseline) is below −tolerance, and a must-pass check for unanswerable questions.

**Solution.**

```python
def gate(new_scores, baseline_scores, tolerance=0.02):
    diff, lo, hi = paired_bootstrap(new_scores, baseline_scores)
    passed = lo >= -tolerance
    print(f"difference {diff:+.3f} [{lo:+.3f}, {hi:+.3f}] -> {'PASS' if passed else 'FAIL'}")
    return passed

def must_pass(system, unanswerable_questions):
    failures = [q for q in unanswerable_questions if not is_refusal(system(q)["answer"])]
    print("must-pass abstentions:", "PASS" if not failures else f"FAIL on {failures}")
    return not failures

ok = gate(ndcg_hybrid, ndcg_dense) and must_pass(rag, UNANSWERABLE)
```

The gate is noise-aware: it blocks only changes that are likely worse than the tolerance, rather than any change whose point estimate dips. Choose the tolerance with the product owner; it encodes how much regression you accept in exchange for other gains such as lower cost.

### Exercise 10 (debugging). High faithfulness, unhappy users

Your dashboard shows faithfulness 0.97, yet users complain that answers are often wrong. Give three explanations and how you would check each.

**Solution.** (1) **Faithful but wrong**: answers faithfully repeat retrieved content that is outdated, wrong, or about the wrong product version; check key-fact correctness against current references and inspect retrieved documents' dates and versions. (2) **Lenient judge**: the faithfulness judge misses unsupported claims; measure its failure recall on human-labelled or corrupted answers (Lab 5). (3) **Wrong retrieval with answerable-looking context**: the model answers the question as interpreted from a near-miss document (answer relevance is low even if faithfulness is high); add answer-relevance and retrieval metrics on the complaint cases, which should also be added to the evaluation set.

### Exercise 11 (debugging). Better offline, flat online

A new reranker improved offline nDCG@10 by 4 points with a significant paired test, but the A/B test shows no change in escalation rate. Why might that be?

**Solution.** The offline set may not represent live traffic (synthetic questions, different mix of types); nDCG gains may be on positions or questions that rarely change the final answer (the generator already found the evidence at rank 3 instead of 1); escalation may be driven by other causes (missing content, policy questions that need a human); the test may be underpowered for the true effect; or the online system differs from the offline one (different candidates, truncation, latency timeouts dropping the reranker). Check by evaluating answers (not just rankings) on a sample of live queries, segmenting the A/B results by query type, and comparing offline and online pipelines' logs for the same queries.

### Exercise 12 (design). Evaluate a legal contract assistant

Design the evaluation for an assistant that answers lawyers' questions about a firm's contracts with clause-level citations.

**Solution (one good answer).**

- **Dataset**: 300 to 500 questions written with lawyers from real matters, across clause lookup, comparison across contracts, obligations with conditions, dates and deadlines, definitions, multi-document questions, unanswerable and ambiguous questions; labels are clause-level evidence spans (graded), reference answers and key facts; pooled from several retrievers; versioned with the contract corpus snapshot.
- **Metrics**: recall@50 and nDCG@10 at clause level; key-fact correctness; faithfulness; citation precision and recall at clause level; false-answer rate on unanswerable questions as the primary safety metric; latency.
- **Judges**: claim-level and key-fact judges validated on 200 lawyer-labelled items, with failure recall above an agreed threshold (for example 0.9) before use; quotes verified by exact string match.
- **Statistics**: paired comparisons with bootstrap intervals; held-out test set touched only for release decisions.
- **Online**: lawyers rate answers and flag wrong citations in the tool; weekly review of flagged items; every confirmed error becomes a test case; shadow testing before any model change.
- **Operating point**: choose the abstention threshold so the error rate on answered questions is at most the level the firm accepts (for example 1%), and report coverage alongside it.

## Summary, cheat sheet and references

The one-sentence summary of Part 6: **build a versioned, labelled, deliberately diverse test set; measure retrieval, generation, safety, latency and cost separately; trust LLM judges only after validating them against humans; compare systems with paired statistics; and keep feeding production failures back into the set.**

### Ten things you should now be able to do

1. Lay out component, end-to-end and online evaluation for a RAG system.
2. Build an evaluation set from logs, experts and filtered synthetic questions, with coverage by question type.
3. Label graded relevance, reference answers, key facts and expected behaviour, and avoid bias towards the current system with pooling.
4. Compute precision, recall, MRR, AP and graded nDCG by hand and in code.
5. Measure key-fact correctness, faithfulness, answer relevance, citation precision and recall, and abstention errors.
6. Design LLM judges, list their biases, and mitigate them.
7. Validate a judge with Cohen's kappa and failure recall, and correct pass rates for judge error.
8. Report bootstrap confidence intervals and test paired differences with the bootstrap, permutation tests or McNemar.
9. Size evaluation sets and A/B tests for a target effect.
10. Set up regression gates in CI and production monitoring that grows the test set.

### Cheat sheet

| Item | Formula or rule |
| --- | --- |
| Proportion margin (95%) | ±1.96 √(p(1 − p)/n): ±7.8 points at n = 100, p = 0.8 |
| Average precision | (1/R) Σ precision@i over ranks of relevant items |
| nDCG@k | Σ (2^rel − 1)/log₂(i + 1), divided by the ideal |
| Faithfulness | Supported claims / all claims |
| Citation recall / precision | Statements supported by their citations / citations that are needed |
| Abstention | Report false-refusal and false-answer rates |
| Cohen's kappa | (p\_o − p\_e)/(1 − p\_e) |
| Judge correction | (p\_obs + spec − 1)/(sens + spec − 1) |
| Paired variance | (σ\_a² + σ\_b² − 2Cov)/n |
| McNemar | (\|b − c\| − 1)²/(b + c), discordant pairs only |
| Paired sample size | n ≈ (2.80 σ\_d / δ)² for 80% power at α = 0.05 |
| A/B sample size per arm | 2 × 2.80² × p(1 − p)/δ² |
| Many comparisons | Fix the primary metric; confirm once on held-out data |
| The loop | Baseline → change → paired test → ship with guardrails → monitor → add failures |

### References

- Järvelin and Kekäläinen (2002). Cumulated Gain-Based Evaluation of IR Techniques. ACM TOIS (nDCG).
- Voorhees and Harman (eds., 2005). TREC: Experiment and Evaluation in Information Retrieval. MIT Press (pooling).
- Es et al. (2023). [RAGAS: Automated Evaluation of Retrieval Augmented Generation](https://arxiv.org/abs/2309.15217).
- Saad-Falcon et al. (2023). [ARES: An Automated Evaluation Framework for Retrieval-Augmented Generation Systems](https://arxiv.org/abs/2311.09476).
- Gao et al. (2023). [Enabling Large Language Models to Generate Text with Citations](https://arxiv.org/abs/2305.14627) (ALCE).
- Zheng et al. (2023). [Judging LLM-as-a-Judge with MT-Bench and Chatbot Arena](https://arxiv.org/abs/2306.05685).
- Angelopoulos et al. (2023). [Prediction-Powered Inference](https://arxiv.org/abs/2301.09016) (combining a few human labels with many model judgements, with valid confidence intervals).
- Cohen (1960). A Coefficient of Agreement for Nominal Scales; Landis and Koch (1977) for interpretation bands.
- Rogan and Gladen (1978). Estimating Prevalence from the Results of a Screening Test.
- Efron and Tibshirani (1993). An Introduction to the Bootstrap.
- Dror et al. (2018). The Hitchhiker's Guide to Testing Statistical Significance in Natural Language Processing. ACL 2018.
- Kohavi, Tang and Xu (2020). Trustworthy Online Controlled Experiments. Cambridge University Press.
- Chapelle et al. (2012). Large-Scale Validation and Analysis of Interleaved Search Evaluation. ACM TOIS.
- Tools named in Chapter 4: the official documentation of Ragas, DeepEval, TruLens, Arize Phoenix, Langfuse, LangSmith and Braintrust (metric definitions change between versions; cite the version you used).

### Coming in Part 7: Training and fine-tuning

Part 7 is the ML-track deep dive. You will fine-tune an embedding model on domain data with hard negatives (and measure the gain with Part 6's paired statistics), generate synthetic training pairs, mine and filter negatives, train and distil a cross-encoder reranker, fine-tune the generator for RAG with retrieval-augmented fine-tuning (RAFT) and LoRA, and decide when fine-tuning is worth its cost compared with better prompting, retrieval or data.
