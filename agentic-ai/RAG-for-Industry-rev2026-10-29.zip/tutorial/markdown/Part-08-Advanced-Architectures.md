# RAG for Industry, Part 8: Advanced Architectures

Oct 28, 2026 · @Behi · revised 29 October 2026 (see CHANGELOG.md)

## How Part 8 fits

Parts 1 to 7 built and tuned a **fixed pipeline**: one retrieval, one generation. Many real questions break that shape: they need several searches whose queries depend on earlier results, an overview of a whole corpus rather than a few passages, evidence locked in images and scanned pages, or tools beyond search. This part covers the architectures that handle those cases, which dominate senior RAG job descriptions in 2026, and keeps asking the question every interviewer asks: is the extra complexity worth it here?

**After this part you will be able to:**

1. Place a system on the spectrum from fixed pipeline to autonomous agent, and justify the choice.
2. Build an agentic RAG loop with tool calling, step limits, citations and trajectory evaluation, from scratch and with LangGraph.
3. Explain and implement GraphRAG ideas: LLM-built knowledge graphs, community summaries, local and global search, and personalized PageRank.
4. Retrieve over images and page screenshots with multimodal embeddings and late-interaction models such as ColPali, and estimate their storage.
5. Expose retrieval as a Model Context Protocol server and reason about its security.
6. Design memory for assistants and decide between long context and retrieval.

**Setup.** The same free Colab or Kaggle T4 notebook:

```python
!pip install -q -U "sentence-transformers>=6.0,<7" "transformers>=5.0,<6" accelerate bm25s networkx "langgraph>=1.0" "mcp>=2.0" matplotlib pillow
```

The lab uses the Qwen3-4B-Instruct generator from earlier parts as the agent's brain (it supports tool calling through its chat template) and the Nimbus corpus, extended with a few documents that require multi-step reasoning.

**Track notes.** Chapters 1, 2, 6 and 7 are core for application engineers; agentic RAG and MCP questions are now routine in interviews. Chapters 4 and 5 are expected knowledge for both tracks, with the ML track asked to explain the algorithms (community detection, PageRank, late interaction) in more depth.

## Chapter 1. From pipelines to agents

In a pipeline, your code decides every step; in an agent, the LLM decides which step comes next, typically by calling tools in a loop until it can answer. Agents handle questions that need several dependent retrievals or several kinds of tools, at the cost of latency, money, predictability and harder evaluation. Use the least autonomy that solves the measured problem.

### 1.1 A spectrum of control

| Level | Who decides the steps | Example | Typical latency |
| --- | --- | --- | --- |
| Fixed pipeline | Code | Retrieve top 5, generate (Part 1) | One LLM call |
| Routed pipeline | Code with a classifier | Route to HR index or SQL tool (Part 5) | One or two calls |
| Fixed iterative workflow | Code, with LLM judgements inside | Retrieve, grade, rewrite, retrieve again (CRAG-style, Part 5) | Two to four calls |
| Agent | The LLM, within limits | Search, read, decide what to search next, answer when enough | Many calls, variable |
| Multi-agent | Several LLM roles coordinating | A planner delegating to researcher agents | Many calls, highly variable |

Anthropic's widely cited guide "Building effective agents" (December 2024) draws the same line between **workflows** (LLMs and tools orchestrated through predefined code paths) and **agents** (LLMs dynamically directing their own process and tool use), and recommends starting with the simplest solution and adding autonomy only when it demonstrably helps.

### 1.2 The ReAct loop

ReAct (Yao et al., 2022) interleaves reasoning and acting: the model thinks about what it needs, takes an action (a tool call), observes the result, and repeats until it can answer. Modern models implement this with native **tool calling**:

1. Your code describes each tool to the model: a name, a description, and a JSON Schema for its arguments.
2. The model either answers in text or emits a structured tool call, for example `search_docs(query="fully remote approval", k=3)`.
3. Your code validates the arguments, executes the tool, and appends the result to the conversation as a tool message.
4. The model reads the result and decides again, until it produces a final answer or a step limit is reached.

The model never executes anything itself; your runtime does, which is where permissions, validation and limits are enforced.

![The agent loop: the model proposes tool calls, the runtime validates and executes](../diagrams/p08_agent_loop.svg)

*The agent loop: the model proposes tool calls, the runtime validates and executes*

Everything that makes an agent safe and debuggable sits in the highlighted runtime: argument validation, permission checks, limits, and the evidence store that final citations are checked against.

### 1.3 When an agent helps

- **Multi-hop questions**, where the second search depends on the first answer ("Who must approve fully remote work for the person who owns incident reviews?").
- **Exploration** when the right query is not obvious and the model must try, read and refine.
- **Heterogeneous sources**: documents, databases, APIs and calculators in one task.
- **Research tasks** that produce long, cited reports from many searches (deep-research agents, Chapter 2.6).

### 1.4 When it hurts

- **Latency and cost** grow with every step; a five-step agent can be ten times slower than a pipeline.
- **Unpredictability**: the same question can take different paths, which complicates testing and support.
- **Error compounding**: a wrong early search can steer every later step.
- **Security surface**: every tool is a capability that prompt injection can try to trigger (Part 9).
- **Harder evaluation**: you must evaluate trajectories, not just answers (Chapter 2.7).

A useful habit: before building an agent, write down which measured failures of the pipeline it will fix, and check them on the evaluation set afterwards. Many "agentic" gains turn out to come from one extra retrieval step that a fixed workflow could do more cheaply.

## Chapter 2. Building agentic RAG

An agentic RAG system is a loop around an LLM with a small set of well-designed retrieval tools, hard limits on steps and context, an evidence store that makes citations possible, and an evaluation that looks at the path taken as well as the final answer. Most of the engineering is in the tools and the limits, not in the prompt.

### 2.1 Designing tools

- **Few and distinct**: for example `search_docs` (hybrid search with optional filters, returns short snippets with ids and titles) and `get_document` (full text of one document or section by id). Overlapping tools confuse the model.
- **Descriptions are prompts**: say what the tool does, when to use it, and what it returns. Put examples of good queries in the description.
- **Constrained arguments**: enums for collections or filters, bounded integers for k, required fields marked as required. Validate in code before executing.
- **Compact, citable outputs**: return ids, titles and snippets rather than whole documents, so context grows slowly and the final answer can cite ids.
- **Errors as messages**: return "no results; try broader terms" rather than raising, so the model can recover.
- **Read before write**: retrieval tools are safe to call freely; tools that change anything (send email, update a record) need explicit user confirmation.

### 2.2 The loop

```text
messages = [system prompt with tool rules, user question]
evidence = {}                                   # id -> text of everything retrieved
for step in 1..MAX_STEPS:
    reply = llm(messages, tools)
    if reply has no tool calls: return reply    # final answer, cites ids from evidence
    for call in reply.tool_calls:               # may be several, run in parallel
        validate arguments; result = run(call); add results to evidence
        append result (truncated) as a tool message
append "Answer now with the evidence you have, or abstain"; return llm(messages)
```

The forced final step matters: without it, an agent that keeps searching never answers. Typical limits are 3 to 8 steps for question answering and much higher for research tasks, plus a token and time budget.

### 2.3 Managing context growth

Every observation is appended to the conversation, so context grows with each step and quality degrades (Part 1, lost in the middle). Truncate tool outputs to snippets; keep full texts in the evidence store and let the model fetch them by id when needed; summarise or drop older observations once they have been used; and keep the system prompt and tool definitions stable at the start so prompt caching works.

### 2.4 Loops, stalls and stopping

Detect repeated identical tool calls and stop or nudge ("you already searched for this; try different terms or answer"). Stop when consecutive steps add no new evidence ids. Always log the full trajectory: when an agent fails, the trace shows whether it chose the wrong tool, wrote a bad query, ignored good evidence, or stopped too early.

### 2.5 Planning patterns

- **Plan and execute**: first ask for a list of sub-questions, retrieve for them in parallel, then answer. More predictable and cheaper than open-ended ReAct when the decomposition is clear up front.
- **Reflection**: after drafting an answer, a check step asks whether each claim is supported and whether anything is missing, and triggers one more search if so (compare Part 5, Chapter 6).
- **Routing to sub-agents**: a coordinator hands specialised questions to agents with their own tools and prompts. Useful when tool sets are large or permissions differ; adds overhead.

### 2.6 Deep-research agents

Research agents plan, search broadly, read many sources, iterate on gaps and write long cited reports. Production examples from several AI labs became mainstream in 2025. Anthropic's description of its multi-agent research system (June 2025) reported that a lead agent coordinating parallel sub-agents outperformed a single agent on its internal research evaluation, while using many times more tokens than ordinary chat. That trade-off is typical: breadth and quality bought with cost, so these systems fit high-value questions, not every query.

**Training the search behaviour itself.** A 2025 research line trains the model to interleave reasoning and search calls with reinforcement learning rather than prompting: Search-R1 (Jin et al., 2025) rewards the final answer's correctness and lets the policy learn when to issue `<search>` queries and how to use the returned passages; ReSearch, R1-Searcher and later work follow the same recipe, and the commercial deep-research products are widely assumed to be trained this way. For an engineer the consequence is practical: the quality of an agent's search behaviour is a property of the model's training, not only of your prompt, so compare models on your own multi-step evaluation set (Chapter 2.7) before tuning the loop around them.

### 2.7 Evaluating agents

Evaluate the final answer with Part 6's metrics, and the trajectory with:

- **Task success rate** on a set of multi-step questions with known answers.
- **Steps and tool calls per task**, and their cost and latency distributions (p50 and p95).
- **Tool-call validity**: share of calls with valid arguments; share of redundant calls.
- **Evidence recall across steps**: did the union of everything retrieved contain the needed evidence?
- **Failure categories** from traces: wrong tool, poor query, premature stop, loop, ignored evidence.
- **Reliability across runs**: agents are stochastic, so run each task several times. τ-bench (Yao et al., 2024) popularised pass^k, the probability that all k independent attempts succeed, which exposes inconsistency that a single run hides.

## Chapter 3. Agent frameworks

A plain Python loop (Chapter 2.2) is enough to learn agents and to ship simple ones. Frameworks earn their place when you need durable state across turns and restarts, human approval steps, branching workflows, streaming, tracing and team-wide conventions. LangGraph is the most widely used independent framework for this; provider SDKs are convenient if you are committed to one model vendor.

### 3.1 LangGraph's model

LangGraph represents an agent or workflow as a **state graph**:

- **State**: a typed dictionary shared by all steps, for example the message list, the evidence store and a step counter. Fields can have **reducers** that say how updates combine (for messages, append rather than overwrite).
- **Nodes**: plain functions that read the state and return updates, for example `call_model` and `run_tools`.
- **Edges**: fixed transitions, and **conditional edges** whose function inspects the state and picks the next node, for example "if the last message has tool calls, go to run\_tools, otherwise END".
- **Compile and run**: the compiled graph is invoked with an initial state, or streamed step by step.
- **Checkpointing**: with a checkpointer, the state is saved after every step under a thread id, so conversations resume after restarts, you can inspect or replay any step, and a graph can pause for **human-in-the-loop** approval (an interrupt) before a sensitive tool runs, then continue when a person approves.

The same ReAct loop becomes two nodes and one conditional edge; the lab builds it. LangGraph reached 1.0 in late 2025, and LangChain's higher-level agent constructors are built on it.

### 3.2 The landscape (October 2026)

| Framework | Shape | Good fit |
| --- | --- | --- |
| LangGraph (with LangChain, and DeepAgents for long-running agents) | Explicit state graphs, checkpointing, interrupts | Complex, stateful, controllable production workflows; any model |
| OpenAI Agents SDK | Agents, tools, handoffs, guardrails, tracing | Lightweight multi-agent apps, especially on OpenAI models |
| Claude Agent SDK (renamed from the Claude Code SDK) | The agent harness behind Claude Code: tools, subagents, hooks | Agents on Anthropic models, coding and file-system agents |
| Google ADK | Code-first agents, evaluation, deployment to Vertex AI; A2A support | Google Cloud teams |
| Microsoft Agent Framework | Merger of AutoGen and Semantic Kernel | .NET and Azure enterprises |
| Haystack 3 Agent (with hooks and typed pipelines, Part 10) | Agent component inside Haystack's pipeline model | Teams already on Haystack |
| LlamaIndex Workflows, Pydantic AI, CrewAI, smolagents, Strands Agents, Mastra | Varied: event workflows, typed agents, role-based crews, code agents, AWS-oriented, TypeScript | Specific ecosystems and styles |

Versions and APIs move quickly, so check each framework's official documentation and repository before choosing (for example [LangGraph](https://github.com/langchain-ai/langgraph), the [Claude Agent SDK](https://github.com/anthropics/claude-agent-sdk-python) and [Google ADK](https://github.com/google/adk-python)).

### 3.3 Two interoperability protocols

- **Model Context Protocol (MCP)** standardises how an application exposes tools and data to models, so one retrieval server works with many agents and assistants (Chapter 6).
- **Agent2Agent (A2A)**, introduced by Google in 2025, standardises how agents discover each other's capabilities ("agent cards") and delegate tasks across systems and vendors.

Most frameworks now support MCP, and several support A2A.

### 3.4 How to choose

1. Simple tool-calling QA with a few tools: your own loop or a thin SDK, fully traced.
2. Durable conversations, approvals, branching, retries, many developers: LangGraph or an equivalent graph framework.
3. Committed to one model provider and its hosting: that provider's SDK.
4. In all cases: keep retrieval, permissions and evaluation in your own code and data, so you can change frameworks without rebuilding the parts that make your system correct.

## Chapter 4. GraphRAG and knowledge graphs

Vector retrieval finds passages that look like the question. It struggles with two kinds of question: **global** ones that need an overview of a whole corpus ("What are the recurring causes across all incident reports?") and **connective** ones whose answer is spread across documents linked by shared entities. Graph-based RAG builds an explicit network of entities and relations, then retrieves by traversing or summarising it. It is powerful for those questions and expensive to build, so use it where they matter.

### 4.1 Knowledge graph basics

A knowledge graph stores **entities** (nodes, such as people, products, policies) and **relations** (edges, such as "approves", "part of", "caused"), each with properties. A fact is often written as a triple (subject, predicate, object), for example (NX-7, has error code, E-212). Property-graph databases (Neo4j, Memgraph, Amazon Neptune and others) store them and are queried with Cypher or the ISO standard GQL; RDF stores use SPARQL. Many companies already have structured graphs (product catalogues, org charts, CRM relations) that an agent can query directly with validated, read-only text-to-Cypher tools.

### 4.2 Building a graph from documents with an LLM

1. **Extract** from each chunk the entities (name, type, short description) and relations (source, target, description, strength) with an LLM and a strict output schema.
2. **Resolve entities**: merge different mentions of the same thing ("NX-7", "Nimbus NX-7", "the NX-7 robot") with normalisation rules, embedding similarity and, for hard cases, an LLM decision. Poor resolution fragments the graph.
3. **Link back**: keep, for every node and edge, the chunks it came from, so answers can cite sources.

Extraction needs at least one LLM call per chunk, often more, which is the main cost of graph-based RAG.

### 4.3 Microsoft GraphRAG: communities and summaries

Microsoft's GraphRAG (Edge et al., 2024, "From Local to Global") adds a hierarchy on top of the extracted graph:

1. **Community detection**: the Leiden algorithm partitions the entity graph into communities of densely connected entities, recursively, giving levels from broad themes to narrow topics.
2. **Community summaries**: an LLM writes a report for each community at each level.
3. **Global search** (map-reduce): to answer a corpus-wide question, each community report produces a partial answer with a helpfulness score (map), and the best partial answers are combined into one response (reduce).
4. **Local search**: for entity-specific questions, find the entities mentioned in the query, then gather their neighbours, relations, community reports and source chunks into the context.

![GraphRAG: build the graph and its community summaries once; answer global questions by map-reduce and local questions by traversal](../diagrams/p08_graphrag.svg)

*GraphRAG: build the graph and its community summaries once; answer global questions by map-reduce and local questions by traversal*

On global "sensemaking" questions over corpora of around a million tokens, the paper reported that LLM judges preferred GraphRAG's answers to vector RAG's on comprehensiveness and diversity. Indexing cost is high, so Microsoft later described LazyGraphRAG, which defers most LLM summarisation to query time.

Community detection algorithms such as Louvain and Leiden maximise **modularity**, the fraction of edges inside communities minus the fraction expected at random given node degrees:

```latex
Q = \frac{1}{2m} \sum_{i,j} \left[ A_{ij} - \frac{k_i k_j}{2m} \right] \delta(c_i, c_j)
```

where A is the adjacency matrix, k\_i the degree of node i, m the number of edges, and δ(c\_i, c\_j) is 1 when i and j are in the same community. Leiden improves on Louvain by guaranteeing that communities are internally connected.

### 4.4 HippoRAG: personalized PageRank for multi-hop retrieval

HippoRAG (Gutiérrez et al., 2024), inspired by models of human memory, builds a graph from passages and their extracted entities, then answers a query by running **personalized PageRank** seeded at the entities the query mentions. Scores spread along edges to related entities, and passages are ranked by the scores of the entities they contain, finding multi-hop evidence in one step rather than several retrieval rounds. With transition matrix P (each node's out-edges normalised), damping α and a seed distribution s over the query's entities, the scores r satisfy:

```latex
\mathbf{r} = \alpha\, P^\top \mathbf{r} + (1 - \alpha)\, \mathbf{s}
```

The random walker follows edges with probability α and jumps back to the query's entities with probability 1 − α, so nodes close to several query entities score highest. A follow-up, HippoRAG 2 (2025), extends the approach.

### 4.5 Other variants

- **LightRAG** (Guo et al., 2024) combines graph structure with vector retrieval at two levels, specific entities and broader themes, and supports incremental updates without rebuilding the whole graph.
- **Graph-assisted hybrid retrieval**: run ordinary hybrid search, then expand results along graph edges (documents mentioning the same entities), and rerank.
- **Agents with graph tools**: give the agent of Chapter 2 a tool that returns an entity's neighbours or runs a validated graph query.

### 4.6 When to use graph-based RAG

Use it when evaluation shows that global or connective questions matter and fail with a strong hybrid-plus-reranker baseline: investigations, research literature reviews, supply-chain and dependency questions, compliance across many linked documents. Budget for extraction cost, entity resolution quality, graph updates as documents change, and an evaluation that includes global questions (judged pairwise with the bias controls of Part 6). For ordinary factual lookup, graph RAG usually adds cost without benefit.

## Chapter 5. Multimodal RAG

Much enterprise knowledge lives in charts, slides, diagrams, scanned forms, screenshots, recorded calls and videos. There are three ways to make it retrievable: convert it to text and reuse the text stack; embed images and text into one shared vector space; or retrieve page images directly with late-interaction vision models. Then a vision-language model reads the retrieved images to answer.

### 5.1 Convert to text

- **Pages and scans**: OCR or a vision-language parser (Part 4, Chapter 2).
- **Images, charts, diagrams**: a vision-language model writes a description ("bar chart of monthly NX-7 sales, peaking at 412 in March"), indexed as text alongside a link to the image.
- **Audio and video**: speech recognition (for example Whisper-family models) with timestamps, plus keyframe captions for video; chunk by time and speaker.

This reuses everything in Parts 2 to 7, but it is lossy: a description captures what the captioner thought was important, and visual detail (a specific value on a chart axis, the layout of a form) can disappear. Captioning every image also costs a VLM call each.

### 5.2 Shared multimodal embeddings

**CLIP** (Radford et al., 2021) trains an image encoder and a text encoder together with a symmetric InfoNCE loss over image-caption pairs, the same contrastive idea as Part 2, Chapter 3, so that an image and its description land close together. **SigLIP** (Zhai et al., 2023) replaces the batch softmax with an independent sigmoid loss per image-text pair, which scales better with batch size. Text queries can then retrieve images directly.

CLIP-style models are good at what an image depicts (a pie chart, a damaged part, a warehouse robot) and weak at reading text inside images. Newer commercial and open embedding models are natively multimodal and handle documents much better, for example Google's Gemini Embedding 2 (text, images, video, audio and PDFs in one space, preview from March 2026; see Part 2), Voyage's multimodal models and Cohere's Embed v4.

### 5.3 Visual document retrieval with late interaction

**ColPali** (Faysse et al., 2024) retrieves page images without any OCR. A vision-language model (PaliGemma in the original, Qwen2-VL-based ColQwen variants later) encodes a page screenshot into about a thousand patch embeddings (around 1,030 vectors of 128 dimensions), the query into one vector per token, and scores with ColBERT's MaxSim (Part 2, Chapter 4.3): every query token finds its best-matching image patch. It reads text, layout, tables and figures together, and it led the ViDoRe visual-document retrieval benchmark introduced with it.

![ColPali-style retrieval: query tokens against page patches, scored with MaxSim](../diagrams/p08_colpali.svg)

*ColPali-style retrieval: query tokens against page patches, scored with MaxSim*

The cost is storage, as with ColBERT:

| Representation per page | Bytes per page | 1 million pages |
| --- | --- | --- |
| 1,030 × 128 float16 vectors | about 264 KB | about 264 GB |
| Same, binarised (1 bit per dimension) | about 16.5 KB | about 16.5 GB |
| Token pooling to about one third of the vectors (float16) | about 88 KB | about 88 GB |
| One 1,024-dimensional float32 vector (single-vector model) | 4 KB | about 4 GB |

Production systems therefore combine compression (binarisation, pooling of similar patch vectors) with a cheap first stage: a single-vector index or a fixed-size encoding of the multi-vector set (for example MUVERA, Google, 2024) retrieves candidates, and full MaxSim reranks them.

Tooling has converged: since sentence-transformers 6.0 the `MultiVectorEncoder` class (Part 2, Chapter 4.3) loads the `vidore` ColPali and ColQwen checkpoints, encodes page images with `encode_document` and text queries with `encode_query`, scores with MaxSim through `similarity`, and offers `HierarchicalTokenPooling` for the patch pooling in the table above. Lab 6 includes an optional cell.

### 5.4 Answering from images

After retrieval, pass the page images (or crops) to a vision-language model together with the question, and require page-level citations. Image inputs are expensive in tokens, so retrieve few pages and downscale when the detail allows. Open models in the Qwen-VL family and commercial multimodal models all support this pattern.

### 5.5 Choosing an approach

| Content | First choice | Why |
| --- | --- | --- |
| Born-digital text documents | Text pipeline | Cheapest, best tooling |
| Slides, reports with charts, scanned forms | Visual retrieval (ColPali-style) or multimodal embeddings, plus text for exact terms | Layout and visuals carry the meaning |
| Photo collections (products, damage, inspections) | Multimodal embeddings | Depiction matters, not embedded text |
| Calls, meetings, videos | Transcripts with timestamps, plus keyframe captions | Speech carries most information |

Mixed corpora often use both a text index and a visual index, fused with RRF (Part 3). Evaluate with page-level relevance labels; ViDoRe and similar benchmarks help choose models, and your own labelled pages decide.

## Chapter 6. The Model Context Protocol

The Model Context Protocol (MCP) is an open standard for connecting AI applications to tools and data. For RAG engineers it means you can write your retrieval service once, as an MCP server, and every MCP-capable assistant, IDE or agent framework can use it. It also means retrieval is now reachable by agents you do not control, so authentication, permissions and injection defences belong in the server.

### 6.1 What MCP is

- **Roles**: a **host** (an AI application such as a chat assistant or IDE) runs one **client** per connection to an MCP **server**, which exposes capabilities. Messages use JSON-RPC 2.0.
- **Capabilities a server exposes**: **tools** (actions the model can call, with JSON Schema arguments, such as `search_docs`), **resources** (data the application can load into context, such as a document by URI), and **prompts** (reusable templates a user can select).
- **Transports**: **stdio** for a local server launched as a subprocess, and **Streamable HTTP** for remote servers. Remote servers use an OAuth-based authorisation flow defined by the specification.
- **Governance and versions**: Anthropic introduced MCP in November 2024 and in December 2025 donated it to the Agentic AI Foundation, a fund under the Linux Foundation co-founded with Block and OpenAI. The specification is versioned by date; the revision finalised on 28 July 2026 made the protocol stateless at the protocol layer, carrying version and capability information with each request instead of in a session. The [official site](https://modelcontextprotocol.io) hosts the current specification, its changelog and the SDKs. Use an official SDK and it handles these details.

### 6.2 Why MCP matters for RAG

- **One retrieval service, many consumers**: the same `search_docs` tool serves your chat assistant, an IDE assistant, and an internal agent.
- **Connectors**: many SaaS products now ship MCP servers, so agents can retrieve from ticketing, wikis and drives without custom integrations.
- **Agentic RAG**: the tools of Chapter 2 map one-to-one onto MCP tools.

### 6.3 Designing a retrieval MCP server

1. **Small tool set**: `search_docs(query, filters, k)` returning ids, titles, snippets and URLs; `get_document(id)` returning full text; optionally resources for documents by URI.
2. **Permissions from identity, never from arguments**: the server knows who the caller is from the authenticated connection and applies the same ACL filters as Part 3. The model must not be able to widen access by passing a different tenant or group.
3. **Bounded outputs**: cap k and snippet length; paginate.
4. **Rate limits, logging and audit** of every call, with the caller's identity.
5. **Clear descriptions** with when-to-use guidance, because the descriptions are what the model reads.

### 6.4 Security

MCP widens the attack surface of RAG, and several risk patterns are now well known:

- **Prompt injection through tool results**: retrieved documents, tickets or web pages can contain instructions for the model (Part 5, Chapter 5.6).
- **Tool poisoning**: a malicious or compromised server describes its tools with hidden instructions, or changes them after approval.
- **Over-broad permissions**: a server holding an admin token can act as a "confused deputy" for any user who reaches it.
- **Exfiltration through combinations**: an agent with access to private data, exposure to untrusted content, and a way to send data out (an email or HTTP tool) can be manipulated into leaking. Simon Willison named this combination the "lethal trifecta" in 2025; removing any one of the three breaks the attack.
- **Supply chain**: community servers run with your credentials.

Mitigations: allow-list and pin the servers you use; give each server least-privilege credentials scoped per user; keep read and write tools separate and require human confirmation for writes and external sends; avoid combining untrusted content and outbound tools in the same agent where possible; route traffic through a gateway that logs and rate-limits; and test with injected documents (Part 9).

## Chapter 7. Memory, long context and context engineering

All the techniques in this guide answer one question: what should be in the model's context window right now? Memory systems decide what to remember from past interactions; long-context models change how much can be included; **context engineering** is the practice of curating instructions, tools, retrieved knowledge, memory and history at every step so that the model sees what it needs and little else.

### 7.1 Kinds of memory

- **Working memory**: the current context window.
- **Short-term memory**: the current conversation; long histories are trimmed or summarised.
- **Long-term memory** across sessions, often split into **semantic** (facts: "the user manages the Montreal warehouse"), **episodic** (past interactions: "last week we diagnosed error E-330 on robot 14") and **procedural** (preferences and learned instructions: "answer in French; include part numbers").

### 7.2 Long-term memory is RAG over the user's history

A memory system has the same parts as the pipelines in this guide, applied to interactions instead of documents:

- **Write path**: after a turn or session, an LLM extracts candidate memories, deduplicates them against existing ones, resolves contradictions (usually the newer fact wins, with the old one kept as history), and stores each with a timestamp, source and confidence.
- **Read path**: retrieve memories relevant to the current request. The Generative Agents work (Park et al., 2023) scored memories by a weighted sum of **recency** (exponentially decaying with time since last access), **importance** (rated when stored) and **relevance** (embedding similarity to the current situation); variants of this scoring remain common.
- **Forgetting**: expiry dates, user deletion, and removal of memories derived from deleted documents.

Systems such as MemGPT (Packer et al., 2023; now the Letta project) let the model manage its own memory with tools that move information between the context and external storage; libraries such as Mem0 and many assistant products provide memory layers.

**Risks**: memory makes privacy and security problems persistent. Show users what is remembered and let them edit or delete it; isolate memories by user and tenant; never store secrets; and treat memories written from untrusted content as untrusted, because an injected instruction stored as a "preference" (**memory poisoning**) would affect every future session.

### 7.3 Long context or retrieval?

Models with context windows of hundreds of thousands to over a million tokens make "put everything in the prompt" possible for small corpora. The decision is economic and empirical:

- **Cost**: a 200,000-token corpus read for each of 10,000 daily queries is 2 billion input tokens a day; retrieving 5,000 tokens per query is 50 million, 40 times fewer. Even if prompt caching made cached tokens cost a tenth of the normal price, long context would still cost about 4 times more here.
- **Latency**: prefill grows with context length (Part 1, Chapter 2.4).
- **Quality**: accuracy tends to fall as inputs grow and relevant facts get lost in the middle; test on your own data rather than trusting "needle in a haystack" scores.
- **Scale, freshness, permissions**: corpora larger than the window, frequent updates and per-user access all favour retrieval.

Long context wins for small, static, frequently reused corpora (one contract, one codebase module, one manual), especially with caching; this is sometimes called cache-augmented generation, where the document's computed key-value cache is reused across queries. The common hybrid is to retrieve at the **document** level and give the model whole relevant documents, using long context for reading and retrieval for selection.

### 7.4 Context engineering

The term spread in 2025 to describe the work of building each model call's context, especially in agents, where context accumulates over many steps (Anthropic's engineering article "Effective context engineering for AI agents" is a good introduction). Core techniques, most of which you have met in earlier parts:

1. **Retrieve just in time**: let the agent load documents by id when needed instead of front-loading everything.
2. **Compact**: summarise older conversation turns and tool results, keeping decisions, open questions and evidence ids.
3. **Take structured notes**: the agent writes progress notes to an external file or state field and reads them back, instead of keeping everything in the transcript.
4. **Isolate**: sub-agents work in their own context windows and return condensed results to the coordinator.
5. **Prune tool output**: return snippets and ids, not whole pages (Chapter 2.1).
6. **Keep stable parts stable**: system prompt and tool definitions first and unchanged, for caching and consistent behaviour.

The guiding principle is the one from Part 1: the smallest set of high-signal tokens that lets the model do the task.

## Chapter 8. Hands-on lab

You will build a tool-calling agent from scratch and compare it with the fixed pipeline on multi-hop questions, rebuild it as a LangGraph state graph with checkpoints, construct a mini GraphRAG with community summaries and personalized PageRank, serve retrieval over MCP, and retrieve images with CLIP. The tool-call parser, agent loop, LangGraph graph, graph algorithms and MCP server and client were tested in a sandbox with LangGraph 1.2 and MCP Python SDK 2.3 (using a scripted stand-in for the LLM); the cells with the real models need Hugging Face access.

### Lab 0. Setup and a corpus that needs several hops

Import the Part 1 corpus from `ragkit`, then add two documents that link facts across the corpus:

```python
from ragkit import CORPUS, split_sentences, chunk_document
import json, re, time, numpy as np, torch
from sentence_transformers import SentenceTransformer
from transformers import AutoTokenizer, AutoModelForCausalLM
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

CORPUS += [
    {"doc_id": "eng-incidents", "title": "Incident Review Process",
     "text": "Post-incident reviews are owned by the Site Reliability team lead, Priya Raman. "
             "Reviews are stored in the incident tracker and shared with all engineering managers."},
    {"doc_id": "org-chart", "title": "Engineering Organisation",
     "text": "Priya Raman reports to Marco Diaz, the Vice President of Engineering. "
             "The Support team lead, Ana Silva, reports to the Vice President of Operations."},
]
chunks = [c for d in CORPUS for c in chunk_document(d)]
by_id = {c["chunk_id"]: c for c in chunks}

emb = SentenceTransformer("BAAI/bge-small-en-v1.5", device=DEVICE)
PREFIX = "Represent this sentence for searching relevant passages: "
E = emb.encode([f"{c['title']}\n{c['text']}" for c in chunks], normalize_embeddings=True, convert_to_numpy=True)

LLM = "Qwen/Qwen3-4B-Instruct-2507"
tok = AutoTokenizer.from_pretrained(LLM)
llm = AutoModelForCausalLM.from_pretrained(LLM, dtype=torch.float16 if DEVICE == "cuda" else torch.float32,
                                           device_map="auto")

def chat(messages, tools=None, max_new_tokens=300):
    inputs = tok.apply_chat_template(messages, tools=tools, add_generation_prompt=True,
                                     return_dict=True, return_tensors="pt").to(llm.device)
    with torch.no_grad():
        out = llm.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
    text = tok.decode(out[0, inputs["input_ids"].shape[1]:], skip_special_tokens=False)
    return text.replace("<|im_end|>", "").replace("<|endoftext|>", "").strip()   # keep <tool_call> tags

MULTI_HOP = [
    {"q": "Who must approve a fully remote arrangement for the person who owns post-incident reviews?",
     "facts": ["vice president", "marco diaz"]},
    {"q": "What should I do if the robot that carries 150 kilograms shows error E-104?",
     "facts": ["clean", "sensor"]},
    {"q": "Who does the owner of post-incident reviews report to?", "facts": ["marco diaz"]},
    {"q": "How long does the robot that is charged with the NX Dock take to reach 80 percent?",
     "facts": ["45 minutes"]},
]
```

### Lab 1. A tool-calling agent from scratch

The tools are described with JSON Schema; Qwen's chat template places them in the system prompt, and the model answers either in text or with `<tool_call>{...}</tool_call>` blocks.

```python
TOOLS = [
    {"type": "function", "function": {
        "name": "search_docs",
        "description": "Search Nimbus Robotics policies, manuals and org documents. Returns chunk ids, titles and "
                       "snippets. Use specific queries; search again with new terms if results are not relevant.",
        "parameters": {"type": "object", "properties": {
            "query": {"type": "string", "description": "What to look for"},
            "k": {"type": "integer", "description": "Number of results, 1 to 5"}},
            "required": ["query"]}}},
    {"type": "function", "function": {
        "name": "get_document",
        "description": "Return the full text of a chunk by its id, when a snippet is not enough.",
        "parameters": {"type": "object", "properties": {"chunk_id": {"type": "string"}}, "required": ["chunk_id"]}}},
]

def search_docs(query, k=3):
    q = emb.encode([PREFIX + query], normalize_embeddings=True, convert_to_numpy=True)[0]
    return [{"id": chunks[j]["chunk_id"], "title": chunks[j]["title"], "snippet": chunks[j]["text"][:200]}
            for j in np.argsort(-(E @ q))[:k]]

def get_document(chunk_id):
    return by_id[chunk_id]["text"] if chunk_id in by_id else f"No chunk with id {chunk_id!r}."

IMPLS = {"search_docs": search_docs, "get_document": get_document}
ALLOWED = {"search_docs": {"query", "k"}, "get_document": {"chunk_id"}}

def parse_tool_calls(text):
    calls = []
    for blob in re.findall(r"<tool_call>\s*(\{.*?\})\s*</tool_call>", text, flags=re.S):
        try:
            obj = json.loads(blob)
            calls.append({"name": obj["name"], "arguments": obj.get("arguments", {})})
        except (json.JSONDecodeError, KeyError):
            calls.append({"name": "__invalid__", "arguments": {}})
    return calls

def run_tool(call, evidence):
    name, args = call["name"], dict(call["arguments"])
    if name not in IMPLS:
        return f"Error: unknown tool {name!r}. Available: {list(IMPLS)}."
    if set(args) - ALLOWED[name]:
        return f"Error: unexpected arguments {sorted(set(args) - ALLOWED[name])}."
    if "k" in args:
        args["k"] = max(1, min(int(args["k"]), 5))            # enforce bounds in code
    try:
        out = IMPLS[name](**args)
    except Exception as e:                                      # errors go back to the model
        return f"Error: {e}"
    for r in (out if name == "search_docs" else [{"id": args.get("chunk_id")}]):
        if r["id"] in by_id:
            evidence[r["id"]] = by_id[r["id"]]["text"]
    return json.dumps(out)[:1500]                               # truncate observations

AGENT_SYSTEM = ("You answer questions about Nimbus Robotics using the tools. Questions may need several "
                "searches: find one fact, then search for the next. When you have enough evidence, answer "
                "concisely and cite chunk ids in square brackets, like [org-chart#0]. If the documents do not "
                "contain the answer, say you don't know.")

def agent(question, max_steps=5):
    messages = [{"role": "system", "content": AGENT_SYSTEM}, {"role": "user", "content": question}]
    evidence, seen, trace, t0 = {}, set(), [], time.time()
    for step in range(max_steps):
        reply = chat(messages, tools=TOOLS)
        calls = parse_tool_calls(reply)
        if not calls:
            break
        messages.append({"role": "assistant", "content": "",
                         "tool_calls": [{"type": "function", "function": c} for c in calls]})
        for c in calls:
            key = json.dumps(c, sort_keys=True)
            result = ("You already ran this exact call. Use its result or try different terms."
                      if key in seen else run_tool(c, evidence))
            seen.add(key); trace.append(c)
            messages.append({"role": "tool", "name": c["name"], "content": result})
    else:                                                       # step limit reached: force an answer
        messages.append({"role": "user", "content": "Answer now using only the evidence above, or say you don't know."})
        reply = chat(messages)
    cited = set(re.findall(r"\[([\w\-]+#\d+)\]", reply))
    return {"answer": reply, "steps": len(trace), "seconds": round(time.time() - t0, 1),
            "evidence": sorted(evidence), "uncited_evidence_ids": sorted(cited - set(evidence)), "trace": trace}

res = agent(MULTI_HOP[0]["q"])
print(json.dumps({k: v for k, v in res.items() if k != "trace"}, indent=1))
for c in res["trace"]:
    print("  ->", c["name"], c["arguments"])
```

Read the trace: a good run searches for the review owner, finds Priya Raman, then searches for her manager or the remote-work rule, and cites both. The `uncited_evidence_ids` field is a citation check against the evidence store: in our sandbox test with a scripted model, the final answer cited a chunk the agent had never retrieved, exactly the kind of error this check catches.

**Template check.** We rendered the chat template published with Qwen3-4B-Instruct-2507 (in its `tokenizer_config.json`) with exactly the message structures this loop builds. The tool definitions appear in a `<tools>` block in the system turn; an assistant message with `tool_calls` (arguments as a dictionary) renders as `<tool_call>{"name": ..., "arguments": {...}}</tool_call>`; and `tool` messages render inside `<tool_response>` tags in a user turn. A call in that format parses with `parse_tool_calls`. The `<tool_call>` tags are ordinary (non-special) tokens, so they survive decoding.

### Lab 2. Pipeline versus agent on multi-hop questions

```python
def pipeline(question, k=3):
    t0 = time.time()
    hits = search_docs(question, k)
    ctx = "\n".join(f"[{h['id']}] {by_id[h['id']]['text']}" for h in hits)
    ans = chat([{"role": "system", "content": AGENT_SYSTEM},
                {"role": "user", "content": f"{ctx}\n\nQuestion: {question}"}])
    return {"answer": ans, "seconds": round(time.time() - t0, 1)}

def success(answer, facts):
    return all(f in answer.lower() for f in facts)

for item in MULTI_HOP:
    p, a = pipeline(item["q"]), agent(item["q"])
    print(f"{item['q'][:60]:<62} pipeline={success(p['answer'], item['facts'])!s:<5} ({p['seconds']} s) "
          f"agent={success(a['answer'], item['facts'])!s:<5} ({a['seconds']} s, {a['steps']} calls)")
```

Expect the agent to win on the questions whose second fact cannot be found from the original wording, and to cost several times the pipeline's latency. Substring matching on key facts is crude; with more questions, use Part 6's key-fact judge and report success rate, calls per task and latency percentiles. Run each question several times to see how consistent the agent is.

### Lab 3. The same agent as a LangGraph state graph

```python
from typing import TypedDict, Annotated
import operator
from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import InMemorySaver

class AgentState(TypedDict):
    messages: Annotated[list, operator.add]     # reducer: new messages are appended
    evidence: dict
    steps: int

def call_model(state):
    reply = chat(state["messages"], tools=TOOLS)
    calls = parse_tool_calls(reply)
    msg = ({"role": "assistant", "content": "", "tool_calls": [{"type": "function", "function": c} for c in calls]}
           if calls else {"role": "assistant", "content": reply})
    return {"messages": [msg], "steps": state["steps"] + 1}

def run_tools(state):
    evidence = dict(state["evidence"])
    calls = [tc["function"] for tc in state["messages"][-1]["tool_calls"]]
    return {"messages": [{"role": "tool", "name": c["name"], "content": run_tool(c, evidence)} for c in calls],
            "evidence": evidence}

def route(state):
    if state["steps"] >= 6:
        return END
    return "run_tools" if state["messages"][-1].get("tool_calls") else END

g = StateGraph(AgentState)
g.add_node("call_model", call_model)
g.add_node("run_tools", run_tools)
g.add_edge(START, "call_model")
g.add_conditional_edges("call_model", route, ["run_tools", END])
g.add_edge("run_tools", "call_model")
app = g.compile(checkpointer=InMemorySaver())                # state saved after every step

cfg = {"configurable": {"thread_id": "user-42"}}
final = app.invoke({"messages": [{"role": "system", "content": AGENT_SYSTEM},
                                 {"role": "user", "content": MULTI_HOP[2]["q"]}],
                    "evidence": {}, "steps": 0}, cfg)
print(final["messages"][-1]["content"])
print("evidence:", sorted(final["evidence"]))
print("saved checkpoints:", len(list(app.get_state_history(cfg))))   # one per step; inspect or resume any
```

The graph is the same loop as Lab 1, but each step's state is persisted under the thread id. Exercise 9 adds a human-approval interrupt before a tool runs.

### Lab 4. A mini GraphRAG

Extract entity-relation triples with the LLM, build a graph, find communities, summarise them for a global question, and use personalized PageRank for a multi-hop one.

```python
import networkx as nx
from collections import defaultdict

EXTRACT = ("Extract factual relations from the text as a JSON list of objects with keys "
           "'source', 'relation', 'target'. Use short entity names. Text:\n{text}")
norm = lambda e: re.sub(r"\s+", " ", str(e).strip().lower())
G, ent_chunks = nx.Graph(), defaultdict(set)
for c in chunks:
    m = re.search(r"\[.*\]", chat([{"role": "user", "content": EXTRACT.format(text=c["text"])}], max_new_tokens=400), re.S)
    try:
        triples = json.loads(m.group(0)) if m else []
    except json.JSONDecodeError:
        triples = []
    for t in triples:
        if isinstance(t, dict) and t.get("source") and t.get("target"):
            s, o = norm(t["source"]), norm(t["target"])
            G.add_edge(s, o, relation=t.get("relation", ""), chunk=c["chunk_id"])
            ent_chunks[s].add(c["chunk_id"]); ent_chunks[o].add(c["chunk_id"])
print(G.number_of_nodes(), "entities,", G.number_of_edges(), "relations")

# Communities (Louvain here; Microsoft GraphRAG uses Leiden) and their summaries
communities = [c for c in nx.community.louvain_communities(G, seed=0) if len(c) >= 3]
print("modularity:", round(nx.community.modularity(G, nx.community.louvain_communities(G, seed=0)), 3))
summaries = []
for comm in communities:
    facts = [f"{u} --{d['relation']}--> {v}" for u, v, d in G.subgraph(comm).edges(data=True)][:40]
    summaries.append(chat([{"role": "user", "content":
        "Summarise what these related facts are about in two sentences:\n" + "\n".join(facts)}], max_new_tokens=120))

# Global question by map-reduce over community summaries
def global_answer(question):
    partial = [chat([{"role": "user", "content": f"Summary: {s}\n\nUsing only this summary, give the points "
                     f"relevant to: {question}. If nothing is relevant, reply NONE."}], max_new_tokens=150)
               for s in summaries]                                   # map
    useful = [p for p in partial if "NONE" not in p.upper()[:10]]
    return chat([{"role": "user", "content": "Combine these notes into one answer:\n\n" + "\n\n".join(useful)
                  + f"\n\nQuestion: {question}"}], max_new_tokens=300)  # reduce

print(global_answer("What are the main areas covered by Nimbus Robotics' internal documents?"))

# Multi-hop retrieval with personalized PageRank seeded at the question's entities
def ppr_chunks(seed_entities, top=4):
    seeds = {e: 1.0 for e in seed_entities if e in G}
    if not seeds:
        return []
    pr = nx.pagerank(G, alpha=0.85, personalization=seeds)
    score = defaultdict(float)
    for e, s in pr.items():
        for cid in ent_chunks[e]:
            score[cid] += s
    return sorted(score.items(), key=lambda x: -x[1])[:top]

seed = [n for n in G if any(w in n for w in ["post-incident review", "fully remote"])]
print("seeds:", seed)
print("PPR chunks:  ", ppr_chunks(seed))
print("dense chunks:", [h["id"] for h in search_docs(MULTI_HOP[0]["q"], 4)])
```

In our sandbox test on hand-written triples for these documents, the three chunks a full answer needs (incident process, org chart, remote policy) took the top three PageRank positions, and unrelated robot chunks scored close to zero. With LLM-extracted triples, results depend on extraction and on entity resolution: if "Priya Raman" and "Priya Raman (SRE lead)" become two nodes, the walk cannot connect them. Exercise 6 adds simple entity resolution.

### Lab 5. Retrieval as an MCP server

Write the server to a file. It uses the MCP Python SDK 2.x, in which the high-level server class is `MCPServer` (version 1.x called it `FastMCP`; the import path changed).

```python
%%writefile nimbus_mcp_server.py
import re
from mcp.server.mcpserver import MCPServer          # MCP Python SDK 2.x

DOCS = {
    "hr-remote": ("Remote and Hybrid Work Policy",
                  "Fully remote arrangements require approval from a vice president. "
                  "Employees may work remotely up to three days per week."),
    "org-chart": ("Engineering Organisation",
                  "Priya Raman reports to Marco Diaz, the Vice President of Engineering."),
}
server = MCPServer("nimbus-docs", instructions="Search Nimbus Robotics internal documents.")

def _tokens(s):
    return set(re.findall(r"\w+", s.lower()))

@server.tool()
def search_docs(query: str, k: int = 3) -> list[dict]:
    """Search Nimbus Robotics policies and org documents. Returns ids, titles and snippets to cite."""
    q = _tokens(query)
    scored = sorted(((len(q & _tokens(t + " " + x)), d, t, x) for d, (t, x) in DOCS.items()), reverse=True)
    return [{"id": d, "title": t, "snippet": x[:200]} for s, d, t, x in scored[:max(1, min(k, 10))] if s > 0]

@server.tool()
def get_document(doc_id: str) -> str:
    """Return the full text of a document by id (from search_docs results)."""
    return DOCS[doc_id][1] if doc_id in DOCS else f"No document with id {doc_id!r}."

if __name__ == "__main__":
    server.run()                                     # stdio transport by default
```

The server uses keyword overlap so that it starts instantly without a model; in production it would call your hybrid retriever and apply ACL filters derived from the authenticated caller (Chapter 6.3). Now connect a client, list the tools, convert them into the LLM's tool schema, and call one. In a notebook, use top-level `await`; in a script, wrap the call in `asyncio.run(main())`.

```python
import sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    params = StdioServerParameters(command=sys.executable, args=["nimbus_mcp_server.py"])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            listed = await session.list_tools()
            llm_tools = [{"type": "function", "function": {"name": t.name, "description": t.description,
                                                             "parameters": t.input_schema}} for t in listed.tools]
            print(json.dumps(llm_tools, indent=1)[:600])
            res = await session.call_tool("search_docs", {"query": "who approves fully remote work", "k": 2})
            print([c.text for c in res.content if hasattr(c, "text")])

await main()
```

The converted `llm_tools` list has exactly the shape Lab 1's `TOOLS` used, so the agent can call any MCP server's tools; Exercise 10 wires them together.

### Lab 6. Image retrieval with CLIP

```python
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from PIL import Image

def save_chart(kind, path):
    fig, ax = plt.subplots(figsize=(4, 3))
    x = np.arange(6); y = np.array([3, 5, 4, 7, 6, 8])
    if kind == "bar": ax.bar(x, y)
    elif kind == "line": ax.plot(x, y, marker="o")
    elif kind == "pie": ax.pie([40, 30, 20, 10])
    elif kind == "scatter": ax.scatter(np.random.rand(40), np.random.rand(40))
    ax.set_title("Q" + kind[0].upper())
    fig.savefig(path); plt.close(fig)

kinds = ["bar", "line", "pie", "scatter"]
for k in kinds:
    save_chart(k, f"{k}.png")

clip = SentenceTransformer("clip-ViT-B-32", device=DEVICE)
img_emb = clip.encode([Image.open(f"{k}.png") for k in kinds], normalize_embeddings=True)
for query in ["a pie chart", "a bar chart", "a line graph showing a trend", "a scatter plot"]:
    q = clip.encode([query], normalize_embeddings=True)[0]
    print(f"{query:<32} ->", kinds[int(np.argmax(img_emb @ q))])
```

CLIP should match the chart types because they are what the images depict. Now try a query about a value printed in a chart title or an axis label: CLIP-style models rarely read text in images reliably, which is the gap ColPali-style models and VLM descriptions fill (Chapter 5).

**Optional: the same images with a ColPali-style model.** Checked against the sentence-transformers 6 documentation, not executed; a ColQwen2 model needs a GPU with several gigabytes free, so run it after unloading the 4B generator.

```python
from sentence_transformers import MultiVectorEncoder
colqwen = MultiVectorEncoder("vidore/colqwen2-v1.0", device=DEVICE)          # visual document retriever
page_embs = colqwen.encode_document([Image.open(f"{k}.png") for k in kinds])   # one matrix of patch vectors per image
for query in ["a pie chart", "the chart titled QL", "a scatter plot"]:
    q_emb = colqwen.encode_query([query])
    scores = colqwen.similarity(q_emb, page_embs)                              # MaxSim over patches
    scores = scores.float().cpu().numpy() if hasattr(scores, "cpu") else np.asarray(scores)
    print(f"{query:<24} ->", kinds[int(np.argmax(scores[0]))])
print("patch vectors per page:", [len(e) for e in page_embs])                 # about a thousand, as in Chapter 5.3
```

The query about the title ("QL") is the one CLIP cannot answer; a model that encodes the page as patches and matches query tokens against them can read it.

## Interview questions with model answers

These 22 questions cover agents, frameworks, GraphRAG, multimodal retrieval, MCP and memory. Interviewers increasingly test judgement here: expect follow-ups like "would you really need an agent for that?"

### Agents

**Q1. What is the difference between a workflow and an agent?** In a workflow, code defines the sequence of LLM and tool calls; in an agent, the LLM decides the next step, typically by calling tools in a loop. Workflows are cheaper and predictable; agents handle open-ended, multi-step problems. Start with the simplest that solves the measured problem.

**Q2. Explain the ReAct pattern and how tool calling implements it.** The model alternates reasoning and actions, observing results between steps. With native tool calling, the application describes tools with JSON Schemas; the model emits a structured call; the runtime validates and executes it and appends the result as a tool message; the loop continues until the model answers or a limit is reached.

**Q3. When would you use agentic RAG instead of a pipeline?** When evaluation shows failures on multi-hop questions whose later queries depend on earlier answers, on exploratory questions, or on tasks mixing sources and tools. Not for simple lookups, where it adds latency, cost and variance without gain.

**Q4. How do you design tools for an agent?** Few, distinct tools with clear names and descriptions that say when to use them; constrained, validated arguments; compact outputs with ids for citation; errors returned as messages; read tools free to call, write tools behind confirmation.

**Q5. How do you stop an agent from looping or running forever?** Hard step, token and time limits; a forced final answer at the limit; detection of repeated identical calls and of steps that add no new evidence; and traces to diagnose why it happened.

**Q6. How do you keep an agent's context from growing out of control?** Truncate tool outputs to snippets and ids; keep full texts in an evidence store fetched on demand; summarise old observations; use sub-agents with isolated contexts that return condensed results; keep stable prompt parts first for caching.

**Q7. How do you evaluate an agent?** Final-answer quality with Part 6 metrics, plus trajectory metrics: task success rate, steps and tool calls per task, tool-call validity, redundant calls, evidence recall across steps, cost and latency percentiles, and categorised failures. Run each task several times and report consistency, for example pass^k.

**Q8. Why might a multi-agent research system beat a single agent, and what does it cost?** Parallel sub-agents explore more directions in separate context windows and return condensed findings, improving breadth on research tasks. It costs many times more tokens, adds coordination overhead and is harder to debug, so it fits high-value tasks.

### Frameworks and protocols

**Q9. What does LangGraph add over a plain loop?** An explicit state graph with typed state and reducers, conditional edges, checkpointing per step and thread for durable conversations and replay, interrupts for human approval, streaming, and integration with tracing tools.

**Q10. What is MCP and why does it matter for RAG?** An open, JSON-RPC-based protocol in which servers expose tools, resources and prompts to AI applications over stdio or HTTP. A retrieval service written once as an MCP server works with any MCP-capable assistant or agent. Introduced by Anthropic in 2024 and donated to the Linux Foundation's Agentic AI Foundation in December 2025.

**Q11. What security risks does MCP introduce, and how do you mitigate them?** Prompt injection via tool results, tool poisoning by malicious servers, over-privileged credentials, exfiltration when private data, untrusted content and outbound tools combine, and supply-chain risk. Mitigate with allow-listed, pinned servers; per-user least-privilege credentials; permissions from authenticated identity; confirmation for writes and sends; gateways with logging; and injection testing.

**Q12. MCP versus A2A?** MCP connects an AI application to tools and data; A2A lets agents discover each other's capabilities and delegate tasks across systems. They are complementary.

### GraphRAG

**Q13. What problems does GraphRAG solve that vector RAG does not?** Global questions that need an overview of a whole corpus, and connective questions whose evidence is linked through shared entities across documents.

**Q14. Describe Microsoft's GraphRAG pipeline.** Extract entities and relations from chunks with an LLM; build a graph; detect hierarchical communities with Leiden; write LLM summaries per community; answer global questions by map-reduce over community summaries and local questions by gathering a query's entities, neighbours, relations, community reports and source chunks.

**Q15. What is modularity?** The fraction of edges within communities minus the fraction expected at random given node degrees: Q = (1/2m) Σ \[A\_ij − k\_i k\_j / 2m\] δ(c\_i, c\_j). Louvain and Leiden maximise it; Leiden guarantees connected communities.

**Q16. How does HippoRAG use personalized PageRank?** It seeds a random walk with restart at the query's entities in a graph built from passages; scores spread along relations, so passages connected to several query entities rank highly, retrieving multi-hop evidence in one step.

**Q17. What are the costs and risks of GraphRAG?** LLM extraction per chunk (often the biggest indexing cost), entity-resolution errors that fragment the graph, updating the graph and summaries as documents change, and evaluation complexity. Use it only when a strong hybrid baseline fails on global or connective questions.

### Multimodal

**Q18. Compare three ways to make images and scanned pages retrievable.** Convert to text (OCR, VLM captions, transcripts): reuses the text stack but loses visual detail. Shared multimodal embeddings (CLIP-style or newer multimodal models): good for what images depict, weaker on dense text. Late-interaction page retrieval (ColPali): reads text, layout and figures from page images without OCR, at high storage cost.

**Q19. How does ColPali score a page, and what does it cost to store?** A vision-language model encodes the page into about a thousand patch vectors and the query into token vectors; the score is the sum over query tokens of the maximum similarity to any patch (MaxSim). About 1,030 × 128 float16 values is roughly 264 KB per page, about 264 GB per million pages before compression, so systems binarise, pool patches and use a cheap first stage.

### Memory and context

**Q20. How would you design long-term memory for an assistant?** As RAG over the user's history: extract candidate memories after sessions, deduplicate and resolve contradictions, store with timestamps and provenance, retrieve by relevance, recency and importance, support expiry and user deletion, isolate per user and tenant, and treat memories derived from untrusted content as untrusted.

**Q21. Long context or RAG for a 200,000-token corpus queried 10,000 times a day?** RAG, unless evaluation shows a quality gain worth the cost: reading the corpus per query is 2 billion input tokens a day versus about 50 million for 5,000-token retrieval, about 4 times more even if cached tokens cost a tenth, plus higher latency and quality loss with long inputs. Long context with caching suits small, static, heavily reused corpora; a hybrid retrieves whole documents.

**Q22. What is context engineering?** Deciding, for each model call, which instructions, tools, retrieved knowledge, memory, history and tool results go into the context window: retrieve just in time, compact history, keep structured notes, isolate sub-agents, prune tool outputs, and keep stable parts stable.

## Exercises with solutions

Twelve exercises: one judgement, four mathematical, five coding, one debugging and one design. Coding exercises reuse the Chapter 8 lab; the code for Exercises 9 and 10 was tested in a sandbox with a scripted model.

### Exercise 1. Pipeline, workflow or agent?

Choose an architecture for each and justify it in one sentence: (a) an FAQ bot for 300 HR questions; (b) "compare our last three years of travel policies and list every change"; (c) a support assistant that must check a customer's order status and then the returns policy; (d) an analyst tool that writes a 5-page market brief from internal reports and the web; (e) answering "what does error E-212 mean?" inside the robot's mobile app.

**Solution.** (a) Fixed pipeline, perhaps with routing: single-hop lookups. (b) Fixed workflow: decompose into three years, retrieve each with date filters, then compare; the steps are known in advance. (c) A workflow with a tool call (order API) followed by retrieval, or a small agent if the order status changes which policy applies; keep the order tool read-only. (d) A research agent (possibly multi-agent): open-ended, many searches, high value per task. (e) Fixed pipeline, or even a direct lookup table of error codes: latency matters and the answer is deterministic.

### Exercise 2. What an agent costs

A pipeline answers with one LLM call whose prompt is 2,500 tokens. An agent's base prompt (system, tools, question) is 1,500 tokens; each of 4 tool steps adds a tool call and an observation totalling 450 tokens, then a final answer call. Each call takes 1.4 seconds and each tool 0.1 seconds. Compare input tokens and latency.

**Solution.** The agent makes 5 calls with prompts of 1,500, 1,950, 2,400, 2,850 and 3,300 tokens: 12,000 input tokens, about 4.8 times the pipeline's 2,500, because every call re-reads the growing history (prompt caching reduces the cost of the repeated prefix). Latency: 5 × 1.4 + 4 × 0.1 = 7.4 seconds versus 1.4 seconds. This is the price that the multi-hop accuracy gain must justify.

### Exercise 3. Personalized PageRank by hand

On the path graph A – B – C with damping α = 0.85 and all restarts at A, set up and solve r = α Pᵀ r + (1 − α) s. Which node scores highest, and why does that matter for retrieval?

**Solution.** From A the walker always moves to B; from B it moves to A or C with probability 0.5 each; from C always to B. The equations are r\_A = 0.85 × 0.5 r\_B + 0.15, r\_B = 0.85 (r\_A + r\_C), r\_C = 0.85 × 0.5 r\_B. Solving gives r\_A ≈ 0.345, r\_B ≈ 0.460, r\_C ≈ 0.195 (networkx's `pagerank` with personalization gives the same). The neighbour B outscores the seed A because it is a **hub**: it receives mass from both sides. In a knowledge graph, generic hub entities ("company", "policy") can therefore dominate; HippoRAG-style systems down-weight nodes that appear in many passages, and you should filter or penalise very high-degree entities.

### Exercise 4. Modularity

Two triangles {0, 1, 2} and {3, 4, 5} are connected by the single edge 2–3. Compute the modularity of the partition into the two triangles, and of putting everything in one community.

**Solution.** With m = 7 edges, modularity can be written as Q = Σ\_c \[L\_c / m − (d\_c / 2m)²\], where L\_c is the number of edges inside community c and d\_c the sum of its degrees. Each triangle has L\_c = 3 and d\_c = 2 + 2 + 3 = 7. Q = 2 × (3/7 − (7/14)²) = 2 × (0.429 − 0.25) ≈ 0.357. One community: L = 7, d = 14, Q = 7/7 − 1² = 0. The natural split scores well; a single community always scores 0.

### Exercise 5. Storing a visual index

You index 2 million pages with a ColPali-style model (about 1,030 vectors of 128 dimensions per page). Estimate storage with binarisation and with token pooling that keeps one third of the vectors, combined.

**Solution.** Binarised: 1,030 × 128 / 8 = 16,480 bytes per page. Keeping a third of the vectors: about 5,500 bytes per page. For 2 million pages: about 11 GB, versus about 527 GB in float16 without compression. Measure retrieval quality after each compression step on your labelled pages.

### Exercise 6 (coding). Entity resolution for the mini GraphRAG

Merge graph nodes that refer to the same entity: first by normalising names (strip titles and punctuation), then by embedding similarity above 0.9 between entity names. Re-run Lab 4's personalized PageRank.

**Solution.**

```python
def canonical(name):
    name = re.sub(r"\b(the|mr|ms|dr)\b", "", name)
    return re.sub(r"[^\w\s-]", "", name).strip()

for n in list(G.nodes):                                         # 1. normalisation
    c = canonical(n)
    if c != n and c:
        G = nx.contracted_nodes(G, c, n, self_loops=False) if c in G else nx.relabel_nodes(G, {n: c})
        ent_chunks[c] |= ent_chunks.pop(n, set())

names = list(G.nodes)                                           # 2. embedding similarity
V = emb.encode(names, normalize_embeddings=True, convert_to_numpy=True)
merged = set()
for i in range(len(names)):
    for j in range(i + 1, len(names)):
        a, b = names[i], names[j]
        if a in merged or b in merged or a not in G or b not in G:
            continue
        if float(V[i] @ V[j]) > 0.9:
            keep, drop = (a, b) if len(a) <= len(b) else (b, a)
            G = nx.contracted_nodes(G, keep, drop, self_loops=False)
            ent_chunks[keep] |= ent_chunks.pop(drop, set()); merged.add(drop)
print(G.number_of_nodes(), "entities after resolution")
print(ppr_chunks([n for n in G if "post-incident" in n or "fully remote" in n]))
```

Inspect the merged pairs: a 0.9 threshold on short names can merge different people with similar names, which is why production systems add type checks (both must be persons) and, for borderline cases, an LLM decision.

### Exercise 7 (coding). Measure agent reliability

Run each Lab 0 multi-hop question three times through `agent` (greedy decoding is deterministic, so sample with temperature 0.7 for this exercise). Report success rate, pass^3 (all three runs succeed), mean tool calls and the slowest run.

**Solution.** Add a sampling switch to `chat` (`do_sample=True, temperature=0.7` when requested), then:

```python
import statistics
rows = []
for item in MULTI_HOP:
    runs = [agent(item["q"]) for _ in range(3)]
    ok = [success(r["answer"], item["facts"]) for r in runs]
    rows.append({"q": item["q"][:50], "success_rate": sum(ok) / 3, "pass^3": all(ok),
                 "mean_calls": statistics.mean(r["steps"] for r in runs),
                 "max_seconds": max(r["seconds"] for r in runs)})
for r in rows: print(r)
```

A question with success rate 2/3 has pass^3 false: users who ask it often will see the agent fail sometimes. Report both numbers in agent evaluations.

### Exercise 8 (coding). Plan and execute

Implement a plan-and-execute variant: ask the LLM for up to three sub-questions as a JSON list, retrieve for each in one batch, then answer once with all the evidence. Compare success and latency with the ReAct agent.

**Solution.**

```python
def plan_and_execute(question):
    t0 = time.time()
    plan = chat([{"role": "user", "content": "Break this question into at most 3 short search queries. "
                  f"Return a JSON list of strings.\n\nQuestion: {question}"}], max_new_tokens=120)
    m = re.search(r"\[.*\]", plan, re.S)
    subqs = json.loads(m.group(0)) if m else [question]
    hits = {h["id"]: h for sq in [question] + subqs for h in search_docs(sq, 3)}
    ctx = "\n".join(f"[{i}] {by_id[i]['text']}" for i in hits)
    ans = chat([{"role": "system", "content": AGENT_SYSTEM}, {"role": "user", "content": f"{ctx}\n\nQuestion: {question}"}])
    return {"answer": ans, "seconds": round(time.time() - t0, 1), "subqueries": subqs}

for item in MULTI_HOP:
    r = plan_and_execute(item["q"])
    print(success(r["answer"], item["facts"]), r["seconds"], r["subqueries"])
```

Plan-and-execute uses two LLM calls regardless of difficulty, so it is faster and more predictable than ReAct, but it cannot use the first answer to form the next query. It fails on truly sequential questions ("who does the owner of X report to?") when the planner cannot guess the intermediate entity, which is exactly where the ReAct agent earns its cost.

### Exercise 9 (coding). Human approval before tools run

Compile the Lab 3 graph so that it pauses before `run_tools`, show the pending call, and resume after approval.

**Solution.**

```python
app = g.compile(checkpointer=InMemorySaver(), interrupt_before=["run_tools"])
cfg = {"configurable": {"thread_id": "approval-demo"}}
app.invoke({"messages": [{"role": "system", "content": AGENT_SYSTEM},
                         {"role": "user", "content": MULTI_HOP[2]["q"]}], "evidence": {}, "steps": 0}, cfg)

while app.get_state(cfg).next:                                    # paused before run_tools
    pending = app.get_state(cfg).values["messages"][-1]["tool_calls"]
    print("Agent wants to run:", [tc["function"] for tc in pending])
    if input("Approve? [y/n] ").strip().lower() != "y":
        print("Rejected; stopping."); break
    app.invoke(None, cfg)                                         # resume from the checkpoint

print(app.get_state(cfg).values["messages"][-1]["content"])
```

In our sandbox test the graph paused with `next == ('run_tools',)` and the pending call visible in the state, then finished after `invoke(None, cfg)`. For read-only search you would not ask for approval; use this for tools that send, write or spend. LangGraph also offers an `interrupt()` function inside nodes for finer-grained approval.

### Exercise 10 (coding). Give the agent MCP tools

Write an async agent loop that lists the tools of the Lab 5 MCP server, passes them to the LLM, and executes the model's tool calls through `session.call_tool`.

**Solution.**

```python
async def mcp_agent(question, max_steps=4):
    params = StdioServerParameters(command=sys.executable, args=["nimbus_mcp_server.py"])
    async with stdio_client(params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()
            listed = await session.list_tools()
            tools = [{"type": "function", "function": {"name": t.name, "description": t.description,
                                                         "parameters": t.input_schema}} for t in listed.tools]
            allowed = {t.name for t in listed.tools}
            messages = [{"role": "system", "content": AGENT_SYSTEM}, {"role": "user", "content": question}]
            for _ in range(max_steps):
                reply = chat(messages, tools=tools)
                calls = parse_tool_calls(reply)
                if not calls:
                    return reply
                messages.append({"role": "assistant", "content": "",
                                 "tool_calls": [{"type": "function", "function": c} for c in calls]})
                for c in calls:
                    if c["name"] not in allowed:
                        content = f"Error: unknown tool {c['name']!r}."
                    else:
                        res = await session.call_tool(c["name"], c["arguments"])
                        content = "\n".join(x.text for x in res.content if hasattr(x, "text"))[:1500]
                    messages.append({"role": "tool", "name": c["name"], "content": content})
            messages.append({"role": "user", "content": "Answer now or say you don't know."})
            return chat(messages)

print(await mcp_agent("Who approves a fully remote arrangement?"))
```

The agent code no longer knows how retrieval works: any MCP server with search tools plugs in. In production, the server would authenticate the caller and filter by their permissions; the agent cannot override that.

### Exercise 11 (debugging). Four agent incidents

Diagnose each: (a) traces show the agent repeating the same search five times; (b) answers cite chunk ids that never appear in the trace; (c) monthly cost is ten times the estimate, though query volume matches; (d) after reading a customer's web page, the agent emailed an internal pricing document to an external address.

**Solution.** (a) No repeated-call detection and no forced answer at the limit, or search results that never contain new information (an index or filter problem); add duplicate detection, a "try different terms" message and a step limit, and inspect the tool's results. (b) Citation hallucination; validate cited ids against the evidence store (Lab 1's check), regenerate or strip unsupported citations. (c) Long trajectories with full documents in context: count steps and tokens per task, truncate observations, cap steps, cache stable prefixes, and route easy questions to the pipeline. (d) The "lethal trifecta": private data, untrusted content and an outbound tool in one agent, plus a prompt injection on the page. Remove or gate the outbound tool (human confirmation, allow-listed recipients), separate browsing from internal-data agents, and add injection tests (Part 9).

### Exercise 12 (design). A research assistant for analysts

Design an assistant that writes cited briefs for financial analysts from one million internal reports (PDFs with charts) and the public web, within five minutes per brief.

**Solution (one good answer).**

- **Architecture**: a research agent with a lead planner and parallel sub-agents (internal search, web search), each with its own context, returning condensed, cited findings; a final writer step; hard budgets on steps, tokens and wall time.
- **Retrieval**: hybrid text search over parsed reports plus a visual index (ColPali-style, compressed) for chart-heavy pages, fused with RRF and reranked; web search through a vetted provider; GraphRAG-style entity graph of companies and products for connective questions if evaluation shows the need.
- **Tools via MCP**: internal search and fetch servers that enforce each analyst's entitlements from their identity; web search read-only; no outbound communication tools in the same agent.
- **Context engineering**: snippets and ids in context, full pages fetched on demand, structured notes for findings, compaction between phases.
- **Verification**: citation existence and support checks per claim (Part 5), conflicts between sources flagged explicitly, numbers from charts cross-checked against text where possible.
- **Evaluation**: a set of past briefs and analyst questions with key facts; trajectory metrics, cost per brief, consistency across runs (pass^k), analyst ratings; weekly review of failures.

## Summary, cheat sheet and references

The one-sentence summary of Part 8: **add autonomy, graphs, images or memory only for question types that a strong pipeline measurably fails on, and when you do, keep tools small and validated, limits hard, citations checked against evidence, permissions in your own code, and trajectories evaluated.**

### Ten things you should now be able to do

1. Place a design on the pipeline-to-agent spectrum and justify it with measured failures.
2. Implement a tool-calling ReAct loop with validation, limits, an evidence store and citation checks.
3. Rebuild the loop as a LangGraph state graph with checkpointing and human approval.
4. Evaluate agents with success rate, cost, latency, tool-call validity and pass^k.
5. Explain GraphRAG's extraction, community detection, community summaries, and local and global search.
6. Compute modularity and personalized PageRank, and explain the hub problem.
7. Choose between text conversion, multimodal embeddings and ColPali-style retrieval, and size their storage.
8. Write and secure an MCP retrieval server and connect an agent to it.
9. Design long-term memory as RAG over interactions, with privacy and poisoning controls.
10. Decide between long context and retrieval with a token-cost calculation.

### Cheat sheet

| Item | Rule or formula |
| --- | --- |
| Workflow vs agent | Code decides steps vs the model decides steps |
| Agent loop | Model → tool calls → validate → run → observe; stop on answer or limit; force final answer |
| Tool design | Few, distinct, described, validated, compact outputs with ids, writes need confirmation |
| Agent cost | Each step re-reads the growing context; tokens grow roughly quadratically in steps |
| Agent evaluation | Success rate, calls per task, validity, evidence recall, cost and latency p95, pass^k |
| LangGraph | Typed state with reducers, nodes, conditional edges, checkpointer, interrupts |
| Modularity | Q = (1/2m) Σ \[A\_ij − k\_i k\_j / 2m\] δ(c\_i, c\_j) |
| Personalized PageRank | r = α Pᵀ r + (1 − α) s, seeds at query entities; beware hubs |
| GraphRAG search | Global: map-reduce over community summaries; local: entity neighbourhoods |
| ColPali storage | about 1,030 × 128 values per page; about 264 KB float16, 16.5 KB binary |
| MCP | Hosts and clients; servers expose tools, resources, prompts; stdio or Streamable HTTP |
| Lethal trifecta | Private data + untrusted content + outbound channel; break one leg |
| Memory scoring | Relevance + recency + importance |
| Long context vs RAG | Compare tokens per day: corpus × queries versus retrieved × queries |

### References

- Yao et al. (2022). [ReAct: Synergizing Reasoning and Acting in Language Models](https://arxiv.org/abs/2210.03629).
- Anthropic engineering articles: "Building effective agents" (December 2024), "How we built our multi-agent research system" (June 2025), "Effective context engineering for AI agents" (September 2025).
- Jin et al. (2025). [Search-R1: Training LLMs to Reason and Leverage Search Engines with Reinforcement Learning](https://arxiv.org/abs/2503.09516).
- Yao et al. (2024). [τ-bench: A Benchmark for Tool-Agent-User Interaction in Real-World Domains](https://arxiv.org/abs/2406.12045).
- Edge et al. (2024). [From Local to Global: A Graph RAG Approach to Query-Focused Summarization](https://arxiv.org/abs/2404.16130).
- Blondel et al. (2008). [Fast Unfolding of Communities in Large Networks](https://arxiv.org/abs/0803.0476) (Louvain); Traag, Waltman and van Eck (2019). [From Louvain to Leiden](https://arxiv.org/abs/1810.08473).
- Gutiérrez et al. (2024). [HippoRAG: Neurobiologically Inspired Long-Term Memory for Large Language Models](https://arxiv.org/abs/2405.14831).
- Guo et al. (2024). [LightRAG: Simple and Fast Retrieval-Augmented Generation](https://arxiv.org/abs/2410.05779).
- Radford et al. (2021). [Learning Transferable Visual Models From Natural Language Supervision](https://arxiv.org/abs/2103.00020) (CLIP); Zhai et al. (2023). [Sigmoid Loss for Language Image Pre-Training](https://arxiv.org/abs/2303.15343) (SigLIP).
- Faysse et al. (2024). [ColPali: Efficient Document Retrieval with Vision Language Models](https://arxiv.org/abs/2407.01449).
- Dhulipala et al. (2024). [MUVERA: Multi-Vector Retrieval via Fixed Dimensional Encodings](https://arxiv.org/abs/2405.19504).
- Park et al. (2023). [Generative Agents: Interactive Simulacra of Human Behavior](https://arxiv.org/abs/2304.03442); Packer et al. (2023). [MemGPT: Towards LLMs as Operating Systems](https://arxiv.org/abs/2310.08560).
- Model Context Protocol: [specification, changelog and SDKs](https://modelcontextprotocol.io). Simon Willison's 2025 writing on the "lethal trifecta" for AI agents.
- Agent frameworks: the official repositories and documentation of [LangGraph](https://github.com/langchain-ai/langgraph), the [Claude Agent SDK](https://github.com/anthropics/claude-agent-sdk-python), [Google ADK](https://github.com/google/adk-python), the OpenAI Agents SDK and the Microsoft Agent Framework.

### Coming in Part 9: Production

Part 9 takes a RAG system to production. You will budget latency and cost end to end, add caching at every layer (embeddings, retrieval results, semantic caches, prompt prefixes), serve models efficiently (vLLM, batching, quantisation), scale indexes and services, harden security (permissions, prompt injection defences, data leakage, abuse), design observability and incident response, and handle privacy, compliance and governance.
