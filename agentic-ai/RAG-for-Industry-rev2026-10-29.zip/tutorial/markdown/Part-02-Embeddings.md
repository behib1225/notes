# RAG for Industry, Part 2: Embeddings

Oct 28, 2026 · @Behi · revised 29 October 2026 (see CHANGELOG.md)

## How Part 2 fits

Part 2 opens the black box you called in Part 1 with one line, `embedder.encode(...)`. The embedding model decides which chunks the retriever can find, so it sets the ceiling on everything downstream: a perfect prompt cannot fix a chunk that was never retrieved.

**After this part you will be able to:**

1. Explain how a Transformer turns text into one vector, including pooling, normalisation and instruction prefixes.
2. Derive the contrastive (InfoNCE) loss that trains embedding models, and explain temperature, in-batch negatives and hard negatives.
3. Compare bi-encoders, cross-encoders, late-interaction models (ColBERT) and learned sparse models (SPLADE) on quality, speed and storage.
4. Cut embedding storage by 4× to 32× with Matryoshka truncation and quantisation, and recover quality with rescoring.
5. Choose an embedding model for a real project and justify the choice with your own evaluation, not just a leaderboard.

**Prerequisites.** Part 1, especially Chapter 3 (similarity functions) and Chapter 5 (the Nimbus Robotics notebook). The lab in Chapter 7 reuses `CORPUS`, `split_sentences`, `chunk_document` and `EVAL_SET` from Part 1 Chapter 5; the notebook imports them from `ragkit`, so upload `code/ragkit.py` first. Everything else is defined in the lab.

**Setup.** Same free Colab or Kaggle T4 GPU. Run this cell at the top of the Part 2 notebook:

```python
!pip install -q -U "sentence-transformers>=6.0,<7" "transformers>=5.0,<6" accelerate pillow

import torch, numpy as np
print(torch.__version__, "GPU:", torch.cuda.is_available())
```

**Track notes.** Chapters 1, 2, 4, 5 and 6 are core for both tracks. Chapter 3 is essential for the ML track and still asked in application-track interviews at a conceptual level ("how are embedding models trained?").

## Chapter 1. What an embedding is

An embedding model is a function f that maps a piece of text to a vector in ℝᵈ so that texts with related meaning land close together. Retrieval then reduces to geometry: find the vectors nearest to the query's vector.

```latex
f : \text{text} \rightarrow \mathbb{R}^d, \qquad \text{relevance}(q, p) \approx \cos\big(f(q), f(p)\big)
```

Typical dimensions in 2026 range from 384 (small, fast models) to 4,096 (large, LLM-based models).

### 1.1 From counting words to learning meaning

Each generation of text representation fixed a weakness of the previous one. Knowing the sequence helps you answer "why not just use X?" questions.

| Era | Representation | Key idea | Main weakness |
| --- | --- | --- | --- |
| 1960s onward | One-hot and bag-of-words | One dimension per vocabulary word | Every pair of different words is orthogonal: "car" and "automobile" have similarity 0 |
| 1970s onward | TF-IDF, later BM25 | Weight words by frequency in the document and rarity in the corpus | Still no notion of synonyms; vectors as wide as the vocabulary |
| 1990 | Latent Semantic Analysis (LSA) | Truncated SVD of the term-document matrix gives dense vectors | Linear, trained per corpus, weak on word order |
| 2013 to 2014 | word2vec, GloVe | Learn one dense vector per word from co-occurrence | One vector per word regardless of context: "bank" (river) = "bank" (money) |
| 2018 | ELMo, BERT | Contextual token vectors from deep language models | Not trained to make whole-sentence vectors comparable |
| 2019 | Sentence-BERT | Fine-tune BERT in a siamese setup so pooled sentence vectors are comparable with cosine | Trained on limited labelled pairs |
| 2021 to 2023 | Contriever, E5, GTE, BGE | Contrastive training on hundreds of millions of weakly paired texts, then fine-tuning | Encoder size limits capacity and context length |
| 2023 to 2026 | LLM-based embedders (E5-Mistral, NV-Embed, Qwen3-Embedding, Gemini Embedding, and others) | Start from a decoder LLM, train it contrastively | Larger, slower and more memory-hungry |

LSA is worth one more line because it connects to your linear algebra. Given a term-document matrix X (terms × documents), keep the top k singular values:

```latex
X \approx U_k \Sigma_k V_k^\top
```

The columns of Σ\_k V\_kᵀ are k-dimensional document vectors in which words that co-occur collapse onto shared "topic" directions, so synonyms become similar. Modern embeddings keep this goal (dense vectors where meaning is a direction) but learn the mapping with a neural network and a training signal aimed directly at retrieval.

### 1.2 Static versus contextual

word2vec gives "bank" one vector. A Transformer gives each occurrence of "bank" a different vector that depends on the surrounding words, because every token attends to every other token. A text embedding model then **pools** the contextual token vectors of a whole passage into one vector (Chapter 2).

### 1.3 Symmetric and asymmetric tasks

- **Symmetric** tasks compare texts of the same kind: duplicate-question detection, semantic textual similarity (STS), clustering. Swapping the two inputs should not change the score.
- **Asymmetric** tasks compare different kinds of text: a short question against a long passage that answers it. RAG retrieval is asymmetric.

This distinction explains why many retrieval models use different instruction prefixes for queries and documents (Chapter 2.5), and why a model that tops a similarity benchmark is not automatically the best retriever.

### 1.4 The geometry of real embedding spaces

Two facts surprise newcomers.

First, **similarity scores are compressed and model-specific**. Contextual embeddings tend to occupy a narrow cone of the space (**anisotropy**), so even unrelated texts can score a cosine of 0.5 or more with some models, while another model puts unrelated pairs near 0. Only the **ranking** within one model is meaningful. Never compare raw scores across models, and never hard-code a threshold without calibrating it on your data (Part 1, Exercise 9).

Second, **similar is not the same as relevant**. "How do I reset my password?" and "How do I reset my username?" are very similar texts but different intents. "The NX-7 battery lasts 8 hours" and "The NX-7 battery does not last 8 hours" can be close neighbours. Embeddings are known to be weak on negation, exact numbers, rare identifiers and fine-grained constraints, which is why production systems add keyword search (Part 3) and rerankers (Chapter 4 and Part 5).

### 1.5 What fits in one vector

A single vector of d numbers must summarise an entire passage. The longer and more varied the passage, the more information is averaged away. This is the fundamental reason chunking exists (Part 4), and the motivation for multi-vector models such as ColBERT (Chapter 4), which keep one vector per token instead.

## Chapter 2. From a Transformer to a text embedding

A text embedding model is a Transformer followed by a **pooling** step that collapses one vector per token into one vector per text, usually followed by L2 normalisation. Five details in this pipeline cause most silent quality bugs: the pooling method, padding, truncation, normalisation and instruction prefixes.

### 2.1 Encoders and decoders as embedding backbones

- **Encoder models** (BERT family, including modern variants such as ModernBERT) use bidirectional attention: every token sees every other token. They were the standard backbone from 2019 to 2023 and are still the best choice when you need small, fast models. Examples: bge-small-en-v1.5, the E5 and GTE families, all-MiniLM-L6-v2.
- **Decoder models** (GPT-style LLMs) use causal attention: token t sees only tokens 1 to t. Since 2023, most top leaderboard models start from a decoder LLM and are then trained contrastively, gaining the LLM's knowledge, multilingual ability and long context. Example: Qwen3-Embedding (0.6B, 4B and 8B), built on Qwen3.

### 2.2 Tokens in, hidden states out

The tokenizer turns a text into n token ids and an **attention mask** m ∈ {0, 1}ⁿ (1 for real tokens, 0 for padding added to make a batch rectangular). The Transformer returns a hidden state for each position, a matrix H ∈ ℝⁿˣʰ, where h is the hidden size.

Every model has a **maximum sequence length**. Text beyond it is **silently truncated**: the model simply never sees it. bge-small-en-v1.5 stops at 512 tokens; Qwen3-Embedding accepts 32K. Always check `model.max_seq_length` and make chunks fit; a 2,000-token chunk fed to a 512-token model is retrieved only by its first quarter.

### 2.3 Pooling: one vector per text

Three pooling methods dominate. The right one is whichever the model was trained with; using another one degrades quality without raising any error.

**CLS pooling** takes the hidden state of the special first token, h₁. BERT-style models trained this way (including the BGE v1.5 family) learn to summarise the text in that position.

**Mean pooling** averages the hidden states of real tokens, ignoring padding:

```latex
\mathbf{e} = \frac{\sum_{i=1}^{n} m_i\, \mathbf{h}_i}{\sum_{i=1}^{n} m_i}
```

Forgetting the mask and averaging padding vectors too is a classic bug: the same sentence then gets a different embedding depending on what else was in its batch.

**Last-token pooling** takes the hidden state of the final real token (often an end-of-sequence token). It is the natural choice for decoder models: with causal attention, only the last token has attended to the whole text. With right padding the last position may be padding, so these models either pad on the left (Qwen3-Embedding's model card loads the tokenizer with `padding_side='left'`) or index the last real token using the mask.

### 2.4 Normalisation and output dimension

Most retrieval models then L2-normalise, e ← e / ‖e‖, so that dot product equals cosine (Part 1, Chapter 3). Some add a small linear projection before normalising. Models trained with Matryoshka representation learning let you keep only the first k dimensions and renormalise (Chapter 5).

### 2.5 Instruction prefixes

Many models were trained with short instructions prepended to the input, and expect the same at inference. Because retrieval is asymmetric, queries and documents often get different treatment:

| Model family | Query input | Document input |
| --- | --- | --- |
| E5 (v2) | "query: " + text | "passage: " + text |
| BGE v1.5 (English) | "Represent this sentence for searching relevant passages: " + text (recommended for short queries) | text, no prefix |
| Nomic Embed | "search\_query: " + text | "search\_document: " + text |
| Qwen3-Embedding | "Instruct: {task description}\\nQuery:" + text | text, no prefix |

Copy prefixes exactly from the model card, including spaces and capitalisation. Missing or wrong prefixes typically cost a few points of retrieval quality, and the failure is silent.

### 2.6 How sentence-transformers packages all this

The sentence-transformers library stores the whole recipe with the model: a Transformer module, a Pooling module configured with the right method, an optional Normalize module, the maximum sequence length, and named prompts. Since version 5.0 (July 2025) it offers `encode_query` and `encode_document`, which automatically apply the model's predefined query and document prompts when the model defines them. You can inspect a model's recipe:

```python
from sentence_transformers import SentenceTransformer
m = SentenceTransformer("BAAI/bge-small-en-v1.5")
print(m)                    # Transformer -> Pooling (shows CLS or mean) -> Normalize
print(m.max_seq_length)     # 512
print(m.prompts)            # named prompts, if the model defines any
```

If a model's configuration does not define a query prompt, `encode_query` encodes the plain text, so for such models you still pass the prefix yourself, for example with `prompt=QUERY_PREFIX`. In the lab (Chapter 7) you re-implement CLS and mean pooling yourself and check that you reproduce the library's vectors.

## Chapter 3. How embedding models are trained

Modern embedding models are trained with **contrastive learning**: pull each query towards its matching passage and push it away from non-matching passages. Almost everything else (batch size, hard negatives, temperature, distillation) is about making that signal stronger and cleaner.

### 3.1 The training data: pairs

The basic unit is a pair (q, p⁺): a query and a passage that answers or matches it. Sources include labelled question-answering datasets (for example MS MARCO and Natural Questions), naturally occurring pairs (title and body, question and accepted answer, anchor text and the linked page), and, increasingly, **synthetic pairs** in which an LLM writes plausible queries for real passages.

### 3.2 The InfoNCE loss, derived

Take a batch of B pairs (q₁, p₁), ..., (q\_B, p\_B). Encode them, normalise, and form the score matrix with a temperature τ:

```latex
S_{ij} = \frac{\cos(\mathbf{q}_i, \mathbf{p}_j)}{\tau}, \qquad S = \frac{Q P^\top}{\tau} \in \mathbb{R}^{B \times B}
```

For query i, the correct passage is p\_i (the diagonal) and the other B − 1 passages in the batch serve as negatives. Treat this as a B-way classification problem and apply softmax cross-entropy to each row:

```latex
\mathcal{L} = -\frac{1}{B} \sum_{i=1}^{B} \log \frac{\exp(S_{ii})}{\sum_{j=1}^{B} \exp(S_{ij})}
```

This is the **InfoNCE** loss (van den Oord et al., 2018), called MultipleNegativesRankingLoss in sentence-transformers, where the `scale` parameter is 1/τ (default 20, so τ = 0.05). In code it is one line: cross-entropy on the logits S with labels 0, 1, ..., B − 1.

**Why it works: the gradient.** Write P\_ij for the softmax probability of passage j in row i. Then:

```latex
\frac{\partial \mathcal{L}_i}{\partial S_{ij}} = P_{ij} - \mathbb{1}[j = i]
```

The positive is pulled up with strength 1 − P\_ii, and each negative is pushed down in proportion to P\_ij, its current probability. Negatives the model already ranks low get almost no gradient; **negatives that look relevant get the most**. This is why hard negatives matter so much (3.5).

**An information-theoretic reading.** van den Oord et al. showed that minimising InfoNCE maximises a lower bound on the mutual information between queries and passages, I(q; p) ≥ log B − 𝓛. The bound grows with B, one intuition for why larger batches help.

Many recipes also add the symmetric term (each passage must pick out its query among the B queries), averaging the row-wise and column-wise losses, as CLIP does for images and captions.

### 3.3 Temperature

τ controls how peaked the softmax is. A small τ (large scale) sharpens the distribution so the loss concentrates on the hardest negatives; too small and training becomes unstable and over-sensitive to label noise. Typical values are 0.01 to 0.05. A side effect: models trained with small τ only need small cosine gaps to separate relevant from irrelevant, which contributes to the compressed score ranges you saw in Chapter 1.4.

### 3.4 In-batch negatives and batch size

In-batch negatives are free: the B − 1 other passages are already encoded. More negatives per query make the task harder and the bound tighter, so large-scale pre-training uses batches of thousands or tens of thousands of pairs, gathered across GPUs. When memory is the limit, gradient caching (GradCache, exposed in sentence-transformers as CachedMultipleNegativesRankingLoss) computes the loss over a large batch in small chunks.

One trap: if two pairs in the batch share an equivalent passage (for example duplicate FAQ answers), one becomes a negative for the other's query. Deduplicate training data, or batch so that near-duplicates do not co-occur.

### 3.5 Hard negatives and false negatives

Random in-batch negatives are mostly easy (a robot manual versus a parental-leave policy). **Hard negatives** are passages that look relevant but are not: same topic, overlapping words, wrong answer. They are usually **mined** by retrieving the top results for each training query with BM25 or an earlier embedding model, removing the known positive, and keeping some of the rest. Each query then contributes 1 positive plus h hard negatives, and the softmax runs over all in-batch and hard-negative passages.

Mining creates a new risk: **false negatives**, passages that are actually relevant but were never labelled. Training pushes the model away from correct answers. Standard mitigations:

- Skip the very top of the mined list (for example sample negatives from ranks 30 to 100 instead of 1 to 10).
- Score candidates with a cross-encoder and drop any that score close to the positive. NV-Retriever (2024) popularised "positive-aware" mining, which drops negatives whose score exceeds a fixed fraction (for example 95%) of the positive's score.
- Use an LLM to judge whether a mined negative actually answers the query.

### 3.6 Alignment and uniformity

Wang and Isola (2020) described what contrastive training achieves geometrically. **Alignment**: matching pairs end up close. **Uniformity**: embeddings spread out over the unit sphere instead of collapsing into a small region. A model with perfect alignment but no uniformity maps everything to one point; good retrieval models balance both, and anisotropy (Chapter 1.4) is a symptom of poor uniformity.

### 3.7 The modern multi-stage recipe

Published recipes from 2022 to 2026 (E5, GTE, BGE, NV-Embed, Qwen3-Embedding and others) share a common shape:

1. **Start from a pre-trained backbone**: an encoder such as BERT, or since 2023 increasingly a decoder LLM.
2. **Weakly supervised contrastive pre-training** on very many noisy pairs (hundreds of millions or more, mined from the web or generated synthetically), with large batches and in-batch negatives.
3. **Supervised fine-tuning** on smaller, high-quality labelled datasets with mined hard negatives and false-negative filtering, often mixing tasks (retrieval, classification, clustering) with task-specific instructions.
4. **Optional extras**: distillation from a cross-encoder or LLM teacher, Matryoshka training (Chapter 5), and **model merging** (averaging the weights of several fine-tuned checkpoints, which Qwen3-Embedding's report uses to improve robustness).

LLM-generated synthetic data became central from 2024: E5-Mistral (Wang et al., 2023) was trained largely on synthetic data from a proprietary LLM, and the Qwen3-Embedding report describes generating large-scale synthetic pairs with Qwen3 models for its weakly supervised stage.

### 3.8 Distillation from a cross-encoder

A cross-encoder (Chapter 4) is a better relevance judge than a bi-encoder but too slow for search. You can transfer its knowledge: let the teacher score (q, p⁺, p⁻) triples and train the student bi-encoder to reproduce the teacher's **margins**. Margin-MSE (Hofstätter et al., 2020) is:

```latex
\mathcal{L}_{\text{MarginMSE}} = \Big( \big[s_S(q,p^+) - s_S(q,p^-)\big] - \big[s_T(q,p^+) - s_T(q,p^-)\big] \Big)^2
```

where s\_S is the student score and s\_T the teacher score. Matching margins rather than raw scores avoids forcing the two models onto the same scale. A listwise alternative is to minimise the KL divergence between teacher and student softmax distributions over a list of candidates. Part 7 puts these losses to work on your own data.

### 3.9 Training a cross-encoder

A cross-encoder takes the concatenated pair "\[CLS\] query \[SEP\] passage \[SEP\]" and outputs one logit. It is commonly trained with binary cross-entropy on labelled (q, p, relevant or not) pairs including hard negatives, or with listwise losses over several candidates per query. Since 2024, LLM-based rerankers (including the Qwen3-Reranker family) frame relevance as predicting "yes" or "no" with a small instruction-tuned LLM and use the probability of "yes" as the score.

## Chapter 4. Relevance architectures

The four ways to score a query against a passage trade accuracy against speed and storage by deciding **when query and passage tokens are allowed to interact**: never (bi-encoder), at the very end through token vectors (late interaction), only through a shared vocabulary (learned sparse), or in every layer (cross-encoder).

![Relevance architectures: bi-encoder, learned sparse, late interaction, cross-encoder](../diagrams/p02_relevance_architectures.svg)

*Relevance architectures: bi-encoder, learned sparse, late interaction, cross-encoder*

The later query and passage interact, the more can be precomputed and the faster search is; the earlier they interact, the more precise the score. Learned sparse models (4.4) sit beside the bi-encoder: separate encoding, with interaction through shared vocabulary terms.

### 4.1 Bi-encoder (dense, single vector)

```latex
s(q, p) = f(q)^\top f(p)
```

Passages are encoded once, offline; a query costs one encoder pass plus a nearest-neighbour search. Storage is one vector per passage. This is the workhorse of first-stage retrieval. Its weakness: all interaction is compressed into a single dot product, so fine-grained matching (negation, exact numbers, multiple constraints) suffers.

### 4.2 Cross-encoder

```latex
s(q, p) = g\big([\text{CLS}]\; q\; [\text{SEP}]\; p\; [\text{SEP}]\big)
```

Query and passage are fed together, so every query token attends to every passage token in every layer. This is the most accurate scorer, but nothing can be precomputed: scoring N passages costs N forward passes per query. Use it only to **rerank** a short candidate list (typically 20 to 200).

### 4.3 Late interaction (ColBERT)

ColBERT (Khattab and Zaharia, 2020) keeps one small vector per token (often 128 dimensions) for both query and passage. Each query token finds its best-matching passage token, and the maxima are summed (**MaxSim**):

```latex
s(q, p) = \sum_{i=1}^{|q|} \max_{j=1}^{|p|} \; \mathbf{q}_i^\top \mathbf{p}_j
```

Passage token vectors are precomputed, so queries stay fast, while token-level matching recovers much of the cross-encoder's precision and generalises well to new domains.

![MaxSim on the vectors of Exercise 7: each query token keeps its best-matching passage token](../diagrams/p02_maxsim.svg)

*MaxSim on the vectors of Exercise 7: each query token keeps its best-matching passage token* The cost is storage: one vector per token rather than per passage. For 1 million passages of 200 tokens at 128 dimensions in float16, that is 1,000,000 × 200 × 128 × 2 bytes ≈ 51 GB, versus about 4 GB for one 1,024-dimensional float32 vector per passage. ColBERTv2 (2021) compresses token vectors with centroids plus quantised residuals to cut this by roughly an order of magnitude, and the PLAID engine makes search fast. The same idea powers ColPali-style retrieval over page images (Part 8). Since version 6.0, sentence-transformers ships a fourth model class, `MultiVectorEncoder`, which absorbed the modelling, training and evaluation code of PyLate (text ColBERT models) and colpali-engine (visual document models): one class loads `lightonai/GTE-ModernColBERT-v1` or `vidore/colqwen2-v1.0`, exposes `encode_query` and `encode_document`, and scores with MaxSim through `model.similarity`. Indexing at scale (PLAID) is still done with PyLate or a vector database that supports multi-vector fields; Lab 8 uses the new class.

### 4.4 Learned sparse (SPLADE)

SPLADE (Formal et al., 2021) uses a BERT masked-language-model head to predict, for every vocabulary term j, how important it is to the text, including terms that do not appear (**expansion**: "car" can activate "vehicle"). With w\_ij the MLM logit for term j at token position i, SPLADE v2 and later use max pooling:

```latex
w_j = \max_{i} \; \log\big(1 + \mathrm{ReLU}(w_{ij})\big), \qquad s(q,p) = \sum_j w_j^{(q)}\, w_j^{(p)}
```

Training adds a sparsity regulariser (the FLOPS loss) so only a few hundred of the roughly 30,000 dimensions are non-zero. The result is served from an ordinary **inverted index**, like BM25, but with learned weights and expansion. It is interpretable (you can read which terms matched), strong on exact terms, and a natural partner for dense vectors in hybrid search. "Inference-free" variants skip the encoder on the query side and use only token lookups, making queries as cheap as BM25. Since sentence-transformers 5.0, these models load with the `SparseEncoder` class.

### 4.5 Comparison

| Property | Bi-encoder | Learned sparse (SPLADE) | Late interaction (ColBERT) | Cross-encoder |
| --- | --- | --- | --- | --- |
| Query-passage interaction | None until one dot product | Through shared vocabulary terms | Token vectors, at the end | Full, in every layer |
| Passage precomputation | One vector | One sparse vector | One vector per token | None |
| Index type | Vector (ANN) index | Inverted index | Specialised multi-vector index | None (reranks candidates) |
| Index size | Small | Small to medium | Large unless compressed | None |
| Query cost | Low | Low | Medium | High: one pass per candidate |
| Exact identifiers and rare terms | Weak | Strong | Good | Strong |
| Explainability | Low | High (term weights) | Medium (token matches) | Low |
| Typical role | First-stage retrieval | First-stage, hybrid with dense | First-stage or reranking | Reranking the top candidates |

The standard production funnel combines them: BM25 or SPLADE plus a bi-encoder retrieve a few hundred candidates cheaply, then a cross-encoder (or an LLM reranker) orders the top few. Part 3 covers fusing the first-stage lists and Part 5 covers reranking.

## Chapter 5. Making embeddings cheap

Vector storage and search cost scale with N × d × bytes per value, and two independent levers shrink it: fewer dimensions (Matryoshka truncation) and fewer bits per dimension (quantisation). Combined with rescoring, they routinely cut memory 10× to 100× for a small loss in retrieval quality.

### 5.1 Matryoshka representation learning

Matryoshka Representation Learning (MRL; Kusupati et al., 2022) trains the model so that the **first m dimensions** of the embedding are themselves a good embedding, for several nested sizes m ∈ 𝓜 (for example 64, 128, 256, 512, 1,024), like nested Russian dolls. The loss is a weighted sum of the usual loss computed on each prefix:

```latex
\mathcal{L}_{\text{MRL}} = \sum_{m \in \mathcal{M}} c_m \; \mathcal{L}\big(\mathbf{e}_{1:m}\big)
```

At inference you keep the first m values and **re-normalise** (truncating a unit vector makes it shorter). In sentence-transformers, pass `truncate_dim=m` when loading the model. Many current models are trained this way, including Qwen3-Embedding, Nomic Embed v1.5 and OpenAI's text-embedding-3 models (through their `dimensions` parameter). Truncating a model that was **not** MRL-trained, such as bge-small-en-v1.5, still works mechanically but loses quality much faster; the lab measures this.

Uses: store short vectors for a fast first pass and full vectors for rescoring, or simply pick the smallest size that meets your quality bar.

### 5.2 Scalar quantisation (int8)

Map each float dimension to one of 256 integer levels using a range calibrated on a sample of embeddings:

```latex
x_q = \mathrm{round}\!\left(255 \cdot \frac{x - \min_k}{\max_k - \min_k}\right) - 128
```

where min\_k and max\_k are the calibrated range of dimension k. Memory drops 4× versus float32 and retrieval quality usually drops only slightly. float16 storage, a 2× saving, is almost free in quality and should be your default.

### 5.3 Binary quantisation

Keep only the sign of each dimension: one bit instead of 32, a 32× saving. Similarity between binary vectors is computed with **Hamming distance** (XOR then count the set bits), which CPUs do extremely fast.

Why does a sign pattern preserve similarity? A classic result (Charikar, 2002, behind SimHash) says that for a random hyperplane through the origin, the probability that it separates two vectors at angle θ is θ/π. With d random hyperplanes, the expected fraction of differing bits is θ/π, so Hamming distance estimates the angle. Using the embedding's own coordinates as hyperplanes is not random, but works well in practice for high-dimensional embeddings, and better for larger d.

Two refinements recover most of the lost quality:

- **Asymmetric scoring**: keep the query in float and score q ᵀ sign(p) instead of comparing two bit vectors.
- **Rescoring**: retrieve r × k candidates with binary vectors (for example r = 4 to 10), then re-rank only those candidates using float or int8 passage vectors, kept on disk or in cheaper memory.

### 5.4 How much memory per vector?

For one 1,024-dimensional embedding:

| Format | Bytes per vector | Saving vs float32 | Memory for 10 million vectors |
| --- | --- | --- | --- |
| float32, 1,024 dims | 4,096 | 1× | 41 GB |
| float16, 1,024 dims | 2,048 | 2× | 20 GB |
| int8, 1,024 dims | 1,024 | 4× | 10 GB |
| float32, 256 dims (MRL) | 1,024 | 4× | 10 GB |
| binary, 1,024 dims | 128 | 32× | 1.3 GB |
| binary, 256 dims (MRL + binary) | 32 | 128× | 0.3 GB |

The last row shows why the two levers are combined: a first pass over 32-byte codes, then rescoring a few hundred candidates with full vectors. Approximate nearest-neighbour indexes add their own overhead and their own compression (product quantisation), covered in Part 3.

### 5.5 Rules of thumb

1. Store float16 by default.
2. Before quantising or truncating, build the evaluation set; measure recall@k at each setting on your own data.
3. Prefer models trained for the compression you plan (MRL-trained for truncation; models reported to retain quality under binary quantisation).
4. Always rescore when using binary codes, and keep the full-precision vectors somewhere so you can re-index without re-embedding.

## Chapter 6. Choosing an embedding model in October 2026

Pick embedding models by measuring them on your own queries and documents, using leaderboards only to build a shortlist. Leaderboard rankings change every few months, and the best general model is often not the best model for a specific domain.

### 6.1 Benchmarks you will hear about

- **MTEB** (Massive Text Embedding Benchmark; Muennighoff et al., 2022) evaluates models across task types: retrieval, reranking, classification, clustering, pair classification, semantic similarity and summarisation. Its retrieval portion draws heavily on the BEIR collection of datasets and reports nDCG@10.
- **MMTEB** (2025) expanded MTEB to hundreds of tasks across hundreds of languages and introduced curated sub-benchmarks such as MTEB(Multilingual), MTEB(eng, v2) and MTEB(Code).
- **RTEB** (Retrieval Embedding Benchmark, launched on Hugging Face in late 2025) focuses on retrieval and keeps part of its evaluation data private, to reduce the risk that models were trained on the test sets.
- **BRIGHT** (Su et al., 2024) tests **reasoning-intensive** retrieval: queries from coding, maths and science forums whose relevant documents share few keywords with the query and must be found by reasoning about the problem. Strong models that score above 0.7 nDCG@10 on classic BEIR datasets score around 0.2 to 0.3 here, and LLM query rewriting or reasoning-trained retrievers help far more than on keyword-friendly benchmarks. If your users ask "how do I solve X" rather than "where is fact Y", look at BRIGHT-style results, not only MTEB averages.

### 6.2 How to read a leaderboard critically

1. **Look at the retrieval column, not the overall mean.** The mean mixes classification and clustering, which matter little for RAG.
2. **Check for training-data overlap.** Many public test sets have training splits, or near-copies, that models have seen. Prefer zero-shot results or held-out benchmarks.
3. **Check size, memory and speed.** An 8B-parameter model that wins by one point may be 10× to 20× slower and more expensive than a 0.6B model.
4. **Check maximum input length, languages and licence.** A 512-token model cannot embed 2,000-token chunks; a non-commercial licence can rule a model out.
5. **Remember that scores are averages.** A two-point lead on average says little about your legal contracts, Japanese support tickets or source code.

### 6.3 The landscape (snapshot, October 2026)

This table is a snapshot to help you recognise names in interviews and job descriptions, not a ranking. Verify current versions before choosing.

| Category | Examples | Notes |
| --- | --- | --- |
| Small open models (CPU-friendly) | bge-small-en-v1.5, all-MiniLM-L6-v2, Google's EmbeddingGemma (about 300M parameters) | Fast, cheap, good baselines; shorter context for older models |
| Mid-size and large open models | [Qwen3-Embedding](https://huggingface.co/Qwen/Qwen3-Embedding-0.6B) 0.6B, 4B and 8B (Apache 2.0, 32K context, MRL, multilingual); BGE-M3 (dense, sparse and multi-vector outputs from one model); Nomic Embed; NVIDIA's NV-Embed family | Self-hostable, so data never leaves your infrastructure |
| Commercial APIs | OpenAI text-embedding-3 (small, large); Google gemini-embedding-001 and Gemini Embedding 2 (`gemini-embedding-2-preview`, public preview since 10 March 2026, natively multimodal: text, images, video, audio and PDFs in one space, Matryoshka dimensions from 128 to 3,072; [Google's announcement](https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-embedding-2/)); Cohere Embed v4; the [Voyage 4 series](https://www.mongodb.com/products/updates/the-voyage-4-series-now-available) from MongoDB (January 2026: voyage-4-large, voyage-4, voyage-4-lite and the open-weight voyage-4-nano, sharing one embedding space) | No GPUs to run, pay per token; data is sent to the vendor; models get deprecated |
| Learned sparse | SPLADE v3, OpenSearch's inference-free sparse models | Pair with dense vectors for hybrid search |
| Late interaction | ColBERTv2, GTE-ModernColBERT, Jina-ColBERT, answerai-colbert-small; loadable with sentence-transformers' `MultiVectorEncoder` (6.0+) | Higher precision, larger indexes |

Two trends to mention in interviews: LLM-based embedders dominate the top of text leaderboards, and the newest commercial models are **multimodal**, embedding images, audio and documents into the same space as text (Part 8).

### 6.4 A selection procedure you can defend

1. **Write down constraints**: languages, maximum chunk length, latency budget per query, corpus size, whether data may leave your network, licence, budget.
2. **Shortlist three to five models** that satisfy the constraints, using the leaderboard's retrieval scores and model cards.
3. **Build a domain evaluation set**: at least 50 to 200 real or realistic queries with labelled relevant chunks (Part 6 shows how to bootstrap this with an LLM and review it by hand).
4. **Evaluate with your full pipeline settings**: your chunking, your query prefix, your k. Measure recall@k, MRR or nDCG, plus encoding throughput and query latency on your hardware.
5. **Test the compression you plan** (Matryoshka size, int8, binary) because models degrade differently.
6. **Decide on quality per unit of cost and latency**, not on quality alone. Record the decision and the numbers.

### 6.5 Operational facts that interviewers probe

- **Embeddings from different models are incompatible.** Switching models, or even model versions, means re-embedding the whole corpus. Budget for it, keep the raw text, and version your indexes.
- **Query and documents must use the same model** (and the matching prefixes).
- **API models can be retired** by the vendor; self-hosted models can be pinned forever but must be served and scaled by you.
- **Throughput matters at indexing time**: embedding 100 million chunks is a batch job measured in GPU-hours or API dollars, so estimate it before committing.

## Chapter 7. Hands-on lab

In this lab you verify Chapters 2 to 5 by experiment: reproduce a library's embeddings with your own pooling, implement InfoNCE and check its gradient, compare three embedding models on a harder evaluation set, and measure what Matryoshka truncation, binary quantisation and a cross-encoder do to retrieval quality.

### Lab 0. Setup and a harder evaluation set

Import the Part 1 objects from `ragkit`, then run:

```python
from ragkit import CORPUS, split_sentences, chunk_document, EVAL_SET   # Part 1, Chapter 5
import re, numpy as np, torch
import torch.nn.functional as F
from sentence_transformers import SentenceTransformer

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"
chunks = [c for doc in CORPUS for c in chunk_document(doc)]
chunk_texts = [f"{c['title']}\n{c['text']}" for c in chunks]

# Part 1's questions are easy. These paraphrase heavily and avoid the documents' wording.
HARD_SET = [
    {"question": "Is booze covered on expense reports?", "gold_doc": "fin-expense"},
    {"question": "My robot can't see because the laser sensor is dirty", "gold_doc": "prod-nx7-errors"},
    {"question": "How long can I work from Portugal?", "gold_doc": "hr-remote"},
    {"question": "What's the top speed of the robot around humans?", "gold_doc": "prod-nx7"},
    {"question": "Who do I tell about a suspicious email?", "gold_doc": "it-security"},
    {"question": "Do sick days roll over?", "gold_doc": "hr-leave"},
    {"question": "How long after an outage do I have to write it up?", "gold_doc": "eng-oncall"},
    {"question": "Where are the company's offices?", "gold_doc": "company-about"},
    {"question": "Is business class allowed on a 7 hour flight?", "gold_doc": "fin-expense"},
    {"question": "The NX-7 can't figure out where it is", "gold_doc": "prod-nx7-errors"},
    {"question": "How much do they pay toward my internet at home?", "gold_doc": "hr-remote"},
    {"question": "My laptop got stolen, what now?", "gold_doc": "it-security"},
]
ALL_EVAL = EVAL_SET + HARD_SET

def metrics(Qv, Ev, eval_set, k=3):
    """Qv: (n_queries, d), Ev: (n_chunks, d), both unit-normalised float32."""
    S = Qv @ Ev.T
    hit1 = hitk = rr = 0.0
    for i, ex in enumerate(eval_set):
        ranked_docs = [chunks[j]["doc_id"] for j in np.argsort(-S[i])]
        rank = ranked_docs.index(ex["gold_doc"]) + 1      # rank of the gold doc's best chunk
        hit1 += rank == 1
        hitk += rank <= k
        rr += 1.0 / rank
    n = len(eval_set)
    return {"hit@1": round(hit1 / n, 3), f"hit@{k}": round(hitk / n, 3), "MRR": round(rr / n, 3)}
```

### Lab 1. Pooling from scratch

Re-implement CLS and mean pooling with plain `transformers` and check that you reproduce sentence-transformers exactly. One detail matters for an exact match: use the same maximum length as the library (`model.max_seq_length`), which is 512 for bge-small but 256 for all-MiniLM-L6-v2; a different truncation length changes the vectors of long inputs.

```python
from transformers import AutoTokenizer, AutoModel

def manual_embed(model_name, texts, pooling, use_mask=True, max_length=512):
    tok = AutoTokenizer.from_pretrained(model_name)
    model = AutoModel.from_pretrained(model_name).to(DEVICE).eval()
    batch = tok(texts, padding=True, truncation=True, max_length=max_length,   # match model.max_seq_length
                return_tensors="pt").to(DEVICE)
    with torch.no_grad():
        H = model(**batch).last_hidden_state                       # (B, n, h)
    if pooling == "cls":
        e = H[:, 0]
    elif use_mask:                                                  # masked mean
        m = batch["attention_mask"].unsqueeze(-1).to(H.dtype)       # (B, n, 1)
        e = (H * m).sum(dim=1) / m.sum(dim=1).clamp(min=1e-9)
    else:                                                           # bug on purpose
        e = H.mean(dim=1)                                           # averages padding too
    return F.normalize(e, p=2, dim=1).cpu().numpy()

texts = ["How many PTO days do I get?",
         "The NX-7 battery lasts up to 8 hours of continuous operation."]
for name, pooling, max_len in [("BAAI/bge-small-en-v1.5", "cls", 512),
                               ("sentence-transformers/all-MiniLM-L6-v2", "mean", 256)]:   # the library truncates MiniLM at 256
    mine = manual_embed(name, texts, pooling, max_length=max_len)
    lib = SentenceTransformer(name, device=DEVICE).encode(texts, normalize_embeddings=True)
    assert lib.shape[1] == mine.shape[1]
    wrong = manual_embed(name, texts, "mean" if pooling == "cls" else "cls", max_length=max_len)
    print(name)
    print("  max |mine - library|      :", np.abs(mine - lib).max())          # tiny, about 1e-6
    print("  cosine with wrong pooling :", np.round((wrong * lib).sum(1), 3)) # clearly below 1
```

Now see the padding bug. The same sentence should get the same vector whatever else is in its batch:

```python
MINILM = "sentence-transformers/all-MiniLM-L6-v2"
s = "How many PTO days do I get?"
long_text = "This is a much longer sentence that forces padding. " * 10
for use_mask in (False, True):
    alone = manual_embed(MINILM, [s], "mean", use_mask, max_length=256)[0]
    batched = manual_embed(MINILM, [s, long_text], "mean", use_mask, max_length=256)[0]
    print(f"use_mask={use_mask}: cosine(alone, batched) = {alone @ batched:.4f}")
```

Without the mask the cosine falls below 1: retrieval results would depend on batch composition, a bug that is very hard to spot in production. With the mask it is 1.0000 up to floating-point noise.

### Lab 2. InfoNCE from scratch, with a gradient check

```python
rng = np.random.default_rng(0)
def l2norm(X): return X / np.linalg.norm(X, axis=1, keepdims=True)

def info_nce(Q, P, tau=0.05):
    """Row i of P is the positive for row i of Q. Returns (loss, dLoss/dS)."""
    S = (Q @ P.T) / tau                                    # (B, B) logits
    S = S - S.max(axis=1, keepdims=True)                   # stability; does not change the loss
    log_probs = S - np.log(np.exp(S).sum(axis=1, keepdims=True))
    B = len(Q)
    loss = -np.mean(np.diag(log_probs))
    grad_S = (np.exp(log_probs) - np.eye(B)) / B           # P_ij - 1[i=j], averaged
    return loss, grad_S

B, d = 8, 16
Q = l2norm(rng.normal(size=(B, d)))
P_random  = l2norm(rng.normal(size=(B, d)))                 # unrelated pairs
P_aligned = l2norm(Q + 0.1 * rng.normal(size=(B, d)))       # matching pairs
for tau in (1.0, 0.1, 0.05):
    print(f"tau={tau}: random={info_nce(Q, P_random, tau)[0]:.3f} "
          f"aligned={info_nce(Q, P_aligned, tau)[0]:.3f}  log(B)={np.log(B):.3f}")

# The same loss in PyTorch is one line: cross-entropy with labels 0..B-1
S_t = torch.tensor(Q @ P_random.T / 0.05)
print(F.cross_entropy(S_t, torch.arange(B)).item(), info_nce(Q, P_random, 0.05)[0])
```

With τ = 1 the loss for random pairs is close to log B ≈ 2.079 (the model is guessing uniformly). Smaller τ makes aligned pairs' loss approach 0 and random pairs' loss grow, which is the sharpening described in Chapter 3.3. Exercise 6 asks you to verify `grad_S` with finite differences; the expected maximum error is around 1e-9.

### Lab 3. Compare embedding models

```python
def as_f32(x): return np.asarray(x, dtype=np.float32)

minilm = SentenceTransformer("sentence-transformers/all-MiniLM-L6-v2", device=DEVICE)
bge = SentenceTransformer("BAAI/bge-small-en-v1.5", device=DEVICE)
qwen = SentenceTransformer("Qwen/Qwen3-Embedding-0.6B", device=DEVICE,
                           model_kwargs={"dtype": torch.float16} if DEVICE == "cuda" else {},
                           processor_kwargs={"padding_side": "left"})   # renamed from tokenizer_kwargs in sentence-transformers 5.4
BGE_PREFIX = "Represent this sentence for searching relevant passages: "

ENCODERS = {   # name: (encode queries, encode documents)
    "all-MiniLM-L6-v2":      (lambda t: minilm.encode(t, normalize_embeddings=True),
                              lambda t: minilm.encode(t, normalize_embeddings=True)),
    "bge-small, no prefix":  (lambda t: bge.encode(t, normalize_embeddings=True),
                              lambda t: bge.encode(t, normalize_embeddings=True)),
    "bge-small, prefix":     (lambda t: bge.encode(t, prompt=BGE_PREFIX, normalize_embeddings=True),
                              lambda t: bge.encode(t, normalize_embeddings=True)),
    "Qwen3-Embedding-0.6B":  (lambda t: qwen.encode_query(t, normalize_embeddings=True),
                              lambda t: qwen.encode_document(t, normalize_embeddings=True)),
}

VECS = {}
for name, (enc_q, enc_d) in ENCODERS.items():
    Ev = as_f32(enc_d(chunk_texts))
    for set_name, es in [("easy", EVAL_SET), ("hard", HARD_SET)]:
        Qv = as_f32(enc_q([ex["question"] for ex in es]))
        VECS[(name, set_name)] = (Qv, Ev)
        print(f"{name:<22} {set_name:<5} dim={Ev.shape[1]:<5} {metrics(Qv, Ev, es)}")
```

What to look for: all models should do well on the easy set, and the gaps should appear on the hard set. Compare "bge-small, no prefix" with "bge-small, prefix" to see what the instruction is worth. With 12 hard questions one question moves hit@1 by 0.083, so treat differences of one or two questions as noise; Exercise 9 runs the same comparison on a real benchmark.

Qwen3-Embedding lets you write a task-specific instruction. Try one tailored to this corpus:

```python
TASK = ("Instruct: Given an employee's question, retrieve the company policy or "
        "product documentation passage that answers it\nQuery:")
Qv = as_f32(qwen.encode(
    [ex["question"] for ex in HARD_SET], prompt=TASK, normalize_embeddings=True))
print("custom instruction:", metrics(Qv, VECS[("Qwen3-Embedding-0.6B", "hard")][1], HARD_SET))
```

### Lab 4. Matryoshka truncation

```python
def truncate(X, m):
    X = X[:, :m]
    return X / np.linalg.norm(X, axis=1, keepdims=True)   # re-normalise after truncating

for name in ["Qwen3-Embedding-0.6B", "bge-small, prefix"]:
    Qv, Ev = VECS[(name, "hard")]
    for m in [32, 64, 128, 256, Ev.shape[1]]:
        if m <= Ev.shape[1]:
            print(f"{name:<22} dims={m:<5} {metrics(truncate(Qv, m), truncate(Ev, m), HARD_SET)}")
```

Qwen3-Embedding was trained with Matryoshka losses, so its quality should fall slowly as dimensions shrink. bge-small was not, so expect a steeper drop. On a corpus this small, both may look fine down to surprisingly few dimensions; the effect is clearer on larger corpora (Exercise 9).

### Lab 5. Binary quantisation with rescoring

```python
def metrics_from_scores(S, eval_set, k=3):
    """Same metrics as metrics(), but from a precomputed (n_queries, n_chunks) score matrix."""
    hit1 = hitk = rr = 0.0
    for i, ex in enumerate(eval_set):
        ranked_docs = [chunks[j]["doc_id"] for j in np.argsort(-S[i], kind="stable")]
        rank = ranked_docs.index(ex["gold_doc"]) + 1
        hit1 += rank == 1; hitk += rank <= k; rr += 1.0 / rank
    n = len(eval_set)
    return {"hit@1": round(hit1 / n, 3), f"hit@{k}": round(hitk / n, 3), "MRR": round(rr / n, 3)}

POPCOUNT = np.array([bin(i).count("1") for i in range(256)], dtype=np.uint8)

def to_bits(X):                      # sign -> 1 bit per dimension, packed 8 per byte
    return np.packbits(X > 0, axis=1)

def hamming(q_bits, D_bits):         # XOR, then count set bits
    return POPCOUNT[np.bitwise_xor(D_bits, q_bits)].sum(axis=1)

def binary_scores(Qv, Ev, mode):
    """Return an (n_queries, n_chunks) score matrix; larger = more similar."""
    E_bits = to_bits(Ev)
    if mode == "hamming":            # both sides binary
        Q_bits = to_bits(Qv)
        return -np.stack([hamming(qb, E_bits) for qb in Q_bits]).astype(np.float32)
    if mode == "asymmetric":         # float query against +-1 document codes
        return Qv @ np.where(Ev > 0, 1.0, -1.0).astype(np.float32).T

Qv, Ev = VECS[("Qwen3-Embedding-0.6B", "hard")]
print("bytes per vector: float32", Ev.shape[1] * 4, "| binary", to_bits(Ev).shape[1])
for mode in ["hamming", "asymmetric"]:
    S = binary_scores(Qv, Ev, mode)
    print(f"{mode:<11}", metrics_from_scores(S, HARD_SET))
```

For Qwen3-Embedding-0.6B the binary code is 128 bytes instead of 4,096: a 32× saving.

The helper `metrics_from_scores` at the top of that cell reports the same metrics as `metrics`, but from any score matrix, so you can reuse it for every scoring scheme below.

Then add rescoring: take the top r × k candidates by Hamming distance and re-rank only those with full-precision vectors.

```python
def binary_then_rescore(Qv, Ev, k=3, r=4):
    S_bin = binary_scores(Qv, Ev, "hamming")
    S = np.full_like(S_bin, -np.inf)
    n_cand = min(Ev.shape[0], r * k)
    for i in range(len(Qv)):
        cand = np.argsort(-S_bin[i], kind="stable")[:n_cand]
        S[i, cand] = Ev[cand] @ Qv[i]          # exact scores for candidates only
    return S

print("binary + rescore:", metrics_from_scores(binary_then_rescore(Qv, Ev), HARD_SET))
print("float32 exact   :", metrics(Qv, Ev, HARD_SET))
```

Expected ordering on larger corpora: Hamming-only is worst, asymmetric scoring is better, and binary plus rescoring is close to exact float search while touching only a few full-precision vectors. Here, with 17 chunks and r × k = 12 candidates, rescoring nearly covers the whole corpus, so it is trivially close to exact; Exercise 9 shows the real trade-off.

### Lab 6. A cross-encoder reranker

```python
from sentence_transformers import CrossEncoder
ce = CrossEncoder("cross-encoder/ms-marco-MiniLM-L6-v2", device=DEVICE)

def rerank_scores(questions, Qv, Ev, n_cand=10):
    S_first = Qv @ Ev.T
    S = np.full_like(S_first, -np.inf)
    for i, q in enumerate(questions):
        cand = np.argsort(-S_first[i])[:n_cand]
        ce_scores = ce.predict([(q, chunk_texts[j]) for j in cand])
        S[i, cand] = ce_scores                     # cross-encoder scores replace dense scores
    return S

Qv, Ev = VECS[("bge-small, prefix", "hard")]
qs = [ex["question"] for ex in HARD_SET]
print("bge-small alone     :", metrics(Qv, Ev, HARD_SET))
print("bge-small + reranker:", metrics_from_scores(rerank_scores(qs, Qv, Ev), HARD_SET))
```

Notes: a gold document outside the top `n_cand` keeps a score of minus infinity, so a reranker can never fix a first-stage miss (recall bounds quality again). This particular reranker was trained on MS MARCO web search, so it can disagree with intuitions on HR-policy questions; stronger general rerankers, including LLM-based ones such as Qwen3-Reranker, are covered in Part 5.

### Lab 7. Look inside a learned sparse vector

```python
from sentence_transformers import SparseEncoder
splade = SparseEncoder("naver/splade-cocondenser-ensembledistil", device=DEVICE)

q = splade.encode_query(["Is booze covered on expense reports?"])
for token, weight in splade.decode(q, top_k=12)[0]:
    print(f"{token:<12} {weight:.2f}")
```

You should see the query's own words plus **expansion terms** the model added, possibly words such as "alcohol" or "reimbursement" that never appear in the query. This is how learned sparse retrieval bridges vocabulary gaps while still using an inverted index. Exercise 10 turns this into a full retriever.

### Lab 8. Late interaction with `MultiVectorEncoder` (sentence-transformers 6)

This cell was checked against the sentence-transformers 6 documentation but not executed on a GPU. It loads a ColBERT-style text model and scores the hard set with MaxSim; compare the result with the single-vector models from Lab 3.

```python
from sentence_transformers import MultiVectorEncoder
colbert = MultiVectorEncoder("lightonai/GTE-ModernColBERT-v1", device=DEVICE)   # a PyLate checkpoint loads directly
q_multi = colbert.encode_query([ex["question"] for ex in HARD_SET])            # one matrix of token vectors per query
d_multi = colbert.encode_document(chunk_texts)                                 # one matrix per chunk
S = colbert.similarity(q_multi, d_multi)                                       # MaxSim, shape (n_queries, n_chunks)
S = S.float().cpu().numpy() if hasattr(S, "cpu") else np.asarray(S, dtype=np.float32)
print("GTE-ModernColBERT:", metrics_from_scores(S, HARD_SET))
print("vectors per chunk:", [len(m) for m in d_multi[:3]], "| dims:", d_multi[0].shape[-1])
```

The last line shows the storage cost from Chapter 4.3 directly: one 128-dimensional vector per token instead of one per chunk. The same class loads visual document models (`MultiVectorEncoder("vidore/colqwen2-v1.0")`, Part 8), so late interaction over text and over page images now share one API.

## Interview questions with model answers

These 25 questions cover how embedding models work, how they are trained, and how to choose and operate them. Answer aloud first, then compare. (ML) marks questions asked mostly in ML engineer and applied scientist loops.

### How embeddings are produced

**Q1. How does a text embedding model turn a passage into one vector?** Tokenise the text, run a Transformer to get one contextual hidden state per token, pool them into one vector (CLS, masked mean, or last-token pooling, whichever the model was trained with), optionally project, then L2-normalise. Instruction prefixes may be prepended to queries or documents before tokenising.

**Q2. CLS, mean or last-token pooling: when is each used?** Use the one the model was trained with; mismatches silently hurt quality. Encoder models use CLS (BGE) or mean (many sentence-transformers models). Decoder-based embedders use last-token pooling because, under causal attention, only the final token has attended to the whole input; they pad on the left or index the last real token.

**Q3. What goes wrong if mean pooling ignores the attention mask?** Padding vectors get averaged in, so a text's embedding depends on the longest text in its batch. Results change with batch composition, which is non-deterministic in production and very hard to debug.

**Q4. What happens to text longer than the model's maximum sequence length?** It is silently truncated: the model never sees the rest, so facts at the end of a long chunk are unretrievable. Keep chunks within the limit, measured in the model's tokens, and log truncation counts at indexing time.

**Q5. Why do some models need different prefixes for queries and documents?** Retrieval is asymmetric: short questions versus long answers. Models trained with "query:" and "passage:" style prefixes or task instructions learn to place the two roles appropriately in the space. Omitting or changing the prefix creates a train-test mismatch and lowers recall.

### Training

**Q6. Write the InfoNCE loss and explain it.** With unit vectors and temperature τ, S\_ij = cos(q\_i, p\_j) / τ and 𝓛 = −(1/B) Σ\_i log \[exp(S\_ii) / Σ\_j exp(S\_ij)\]. Each row is a B-way softmax classification whose correct class is the paired passage; the other passages in the batch act as negatives. In PyTorch it is cross-entropy on the B × B score matrix with labels 0 to B − 1.

**Q7. (ML) Why do hard negatives matter, in terms of the gradient?** ∂𝓛\_i/∂S\_ij = P\_ij − 1\[i = j\]. Each negative is pushed down in proportion to its current softmax probability, so easy negatives contribute almost nothing and confusable negatives drive learning. Random in-batch negatives quickly become easy; mined hard negatives keep the signal informative.

**Q8. What does the temperature do?** Smaller τ sharpens the softmax, focusing the loss on the hardest negatives and increasing separation; too small causes instability and overfitting to label noise. Typical values are 0.01 to 0.05 (scale 20 to 100).

**Q9. Why are large batches used, and what if they do not fit in memory?** More in-batch negatives per query make the task harder and the contrastive estimate better (the mutual-information bound grows with log B). When memory limits batch size, use gradient caching (GradCache) or gather negatives across GPUs.

**Q10. What are false negatives, and how do you mitigate them?** Mined "negatives" that are actually relevant but unlabelled; training pushes the model away from correct answers. Mitigate by sampling negatives below the top ranks, filtering with a cross-encoder or LLM judge, positive-aware thresholds (drop negatives scoring above a fraction of the positive), and deduplicating training data.

**Q11. (ML) Describe the typical training recipe of a modern embedding model.** Start from a pre-trained encoder or LLM; weakly supervised contrastive pre-training on very many noisy or synthetic pairs with large batches; supervised fine-tuning on high-quality labelled data with hard negatives and multiple tasks with instructions; optional distillation from a cross-encoder, Matryoshka losses, and checkpoint merging.

**Q12. (ML) How do you distil a cross-encoder into a bi-encoder?** Score (q, p⁺, p⁻) triples with the teacher and train the student to match the score margins (Margin-MSE), or match the teacher's softmax distribution over a candidate list with KL divergence. Margins avoid forcing both models onto the same score scale.

**Q13. (ML) What are alignment and uniformity?** Alignment: matching pairs are close. Uniformity: embeddings spread over the hypersphere rather than collapsing. Contrastive losses optimise both; poor uniformity shows up as anisotropy and compressed similarity scores.

### Architectures

**Q14. Compare bi-encoders, cross-encoders, ColBERT and SPLADE.** Bi-encoder: one vector per text, fast ANN search, least precise. Cross-encoder: joint encoding, most precise, one forward pass per candidate, so only for reranking. ColBERT: one vector per token with MaxSim late interaction, near cross-encoder precision with precomputed passages but large indexes. SPLADE: learned sparse term weights with expansion, served from an inverted index, strong on exact terms and interpretable. In sentence-transformers these are the four model classes: `SentenceTransformer`, `CrossEncoder`, `MultiVectorEncoder` and `SparseEncoder`.

**Q15. Write ColBERT's scoring function and estimate its storage.** s(q, p) = Σ\_i max\_j q\_iᵀp\_j. Storage is passages × tokens per passage × dimensions × bytes: 1 million passages × 200 tokens × 128 dimensions × 2 bytes ≈ 51 GB in float16, before ColBERTv2-style residual compression, compared with about 4 GB for one 1,024-dimensional float32 vector per passage.

**Q16. How does SPLADE handle vocabulary mismatch while using an inverted index?** Its MLM head assigns weights to vocabulary terms that are semantically related even if absent from the text (expansion), with a sparsity regulariser keeping only a few hundred non-zero terms. The sparse vectors are stored in an inverted index and scored by a dot product over shared terms, like BM25 with learned weights.

### Efficiency and operations

**Q17. What is Matryoshka representation learning, and how do you use it?** Training with the loss applied to several nested prefixes of the embedding, so the first m dimensions form a usable embedding. At inference, keep the first m dimensions and re-normalise. Use small prefixes for a fast first pass and full vectors for rescoring, or choose the smallest size that meets the quality bar. It only works well on models trained this way.

**Q18. Explain binary quantisation and rescoring.** Keep the sign of each dimension (32× smaller than float32) and compare with Hamming distance via XOR and popcount, which approximates the angle between vectors. Quality drops, so retrieve several times k candidates with binary codes, then rescore them with float or int8 vectors. Scoring a float query against binary document codes (asymmetric) also helps.

**Q19. All cosine scores in your system are between 0.6 and 0.9, even for unrelated pairs. Is that a bug?** Not necessarily. Many models produce compressed, anisotropic score distributions. Only the ranking is meaningful within a model. Any threshold must be calibrated on labelled data for that specific model, and recalibrated when the model changes.

**Q20. Embeddings fail on queries with negation or exact numbers. What do you do?** Add lexical or learned sparse retrieval in hybrid search, use metadata filters for structured constraints (dates, prices, versions), rerank with a cross-encoder, and add such cases to the evaluation set. If they are frequent in your domain, fine-tune on hard negatives that differ only in the negation or number.

**Q21. How do you choose an embedding model for a new project?** List constraints (languages, chunk length, latency, data residency, licence, budget); shortlist from leaderboard retrieval scores and model cards; build a domain evaluation set; measure recall@k or nDCG and latency with my real chunking, prefixes and compression; choose on quality per cost. Leaderboards build the shortlist; my data decides.

**Q22. What are the pitfalls of the MTEB leaderboard?** The overall mean mixes tasks irrelevant to retrieval; test-set contamination through training data; self-reported results; average scores hide domain and language differences; and size, latency and licence are not part of the score. Held-out benchmarks such as RTEB reduce, but do not remove, these issues.

**Q23. You must switch to a new embedding model in production. What does that involve?** Embeddings are not compatible across models, so re-embed the full corpus into a new index while serving from the old one; evaluate offline; shadow-test or A/B test online; switch queries and documents together; keep the old index for rollback; and update any calibrated thresholds. Keep raw text and version indexes so this is routine.

**Q24. API embedding model or self-hosted?** APIs: no infrastructure, strong models, pay per token, but data leaves your network, rate limits apply, and models can be deprecated. Self-hosted: data stays inside, pinned versions, predictable cost at scale, but you run GPUs and serving. Decide on data policy, volume, latency, and team capacity.

**Q25. Should you embed whole long documents or chunks?** Usually chunks: one vector averages away detail, and models truncate long input. Long-context embedders make larger units feasible, and techniques such as adding document context to each chunk, or late chunking (embed the long text once, then pool per chunk span), keep context without losing precision. Part 4 compares these on evaluation data.

## Exercises with solutions

Twelve exercises: five mathematical, two conceptual, three coding (one a stretch on a real benchmark), one debugging and one design. Coding exercises reuse the Chapter 7 lab variables.

### Exercise 1. Diagnose the pooling

For each case say what pooling the model needs and what goes wrong otherwise. (a) An encoder model whose card says it was trained with CLS pooling, used with mean pooling. (b) A decoder-based embedder used with mean pooling. (c) A decoder-based embedder with last-token pooling, right padding, and code that takes position −1 of every row.

**Solution.** (a) It needs CLS. Mean pooling produces vectors the model was never trained to make comparable; quality drops silently (Lab 1 shows cosine to the correct vector clearly below 1). (b) It needs last-token pooling. Under causal attention early tokens never saw later ones, so averaging mixes partial-context states; quality drops. (c) With right padding, position −1 of shorter texts is a padding token, so those texts get a meaningless vector. Pad on the left, or index the last real token using the attention mask.

### Exercise 2. InfoNCE by hand

Two queries and two passages have the cosine matrix C = \[\[0.9, 0.2\], \[0.3, 0.8\]\] (row i = query i, column j = passage j; positives on the diagonal). Compute the InfoNCE loss with τ = 1 and with τ = 0.1.

**Solution.** Row i contributes −log\[exp(S\_ii) / Σ\_j exp(S\_ij)\] = log(1 + exp(S\_ij − S\_ii)) for its single negative j.

With τ = 1: row 1 gives log(1 + e^(−0.7)) = log(1.4966) = 0.4032; row 2 gives log(1 + e^(−0.5)) = log(1.6065) = 0.4741. Loss = (0.4032 + 0.4741) / 2 = 0.4386.

With τ = 0.1 the gaps become 7 and 5: row 1 gives log(1 + e^(−7)) = 0.00091; row 2 gives log(1 + e^(−5)) = 0.00672. Loss = 0.0038. The same geometry gives a 100× smaller loss at low temperature because the softmax is much sharper: low τ rewards small cosine gaps generously, and punishes a negative that beats the positive severely (Exercise 4).

### Exercise 3. Derive the InfoNCE gradient

Show that for one row, 𝓛\_i = −S\_ii + log Σ\_j exp(S\_ij), the gradient is ∂𝓛\_i/∂S\_ij = P\_ij − 1\[i = j\], where P\_ij is the row's softmax.

**Solution.** Differentiate the log-sum-exp term: ∂/∂S\_ij log Σ\_k exp(S\_ik) = exp(S\_ij) / Σ\_k exp(S\_ik) = P\_ij. The first term −S\_ii contributes −1 only when j = i. So ∂𝓛\_i/∂S\_ij = P\_ij − 1\[i = j\]. For the full loss averaged over B rows, divide by B, which is exactly `grad_S` in Lab 2. Consequences: the gradient on the positive is P\_ii − 1 ≤ 0 (pushes S\_ii up), the gradients in a row sum to zero, and a negative's push is proportional to its probability.

### Exercise 4. Bounds on the loss

(a) Show that if all scores in a row are equal, that row's loss is log B. (b) Show the loss is always ≥ 0. (c) As τ → 0, what happens to a row's loss if the positive has the highest cosine, and if some negative beats it by a margin δ > 0?

**Solution.** (a) Equal scores give P\_ii = 1/B, so −log P\_ii = log B. This is the "random guessing" level seen in Lab 2 at τ = 1. (b) P\_ii ≤ 1, so −log P\_ii ≥ 0. (c) Write the row's loss as log(1 + Σ\_{j≠i} exp((c\_ij − c\_ii)/τ)) with cosines c. If every c\_ij < c\_ii, each exponent → −∞, so the loss → 0. If some negative has c\_ij − c\_ii = δ > 0, that term grows like exp(δ/τ), so the loss grows like δ/τ, without bound. Low temperature makes the loss behave like a hinge on the worst negative, which explains both its power and its sensitivity to false negatives.

### Exercise 5. Storage budget

A corpus has 5 million passages of 300 tokens on average. Compute index size for: (a) one 768-dimensional float16 vector per passage; (b) ColBERT with 128-dimensional float16 token vectors; (c) ColBERT with token vectors compressed to 2 bits per dimension (ignore the small overhead of centroid ids); (d) one Matryoshka-truncated 256-dimensional binary vector per passage.

**Solution.** (a) 5,000,000 × 768 × 2 bytes = 7.68 GB. (b) 5,000,000 × 300 × 128 × 2 bytes = 384 GB. (c) 128 dims × 2 bits = 256 bits = 32 bytes per token, so 5,000,000 × 300 × 32 = 48 GB. (d) 256 bits = 32 bytes per passage, so 5,000,000 × 32 = 160 MB. The spread, from 160 MB to 384 GB for the same corpus, is why storage format is an architecture decision, not a detail.

### Exercise 6 (coding). Check your gradient numerically

Using Lab 2's `info_nce`, verify `grad_S` with central finite differences on a random 8 × 8 problem at τ = 0.05.

**Solution.**

```python
def loss_from_S(S):
    S = S - S.max(axis=1, keepdims=True)
    lp = S - np.log(np.exp(S).sum(axis=1, keepdims=True))
    return -np.mean(np.diag(lp))

S = (Q @ P_random.T) / 0.05
_, g = info_nce(Q, P_random, 0.05)
eps, num = 1e-6, np.zeros_like(S)
for i in range(B):
    for j in range(B):
        Sp, Sm = S.copy(), S.copy()
        Sp[i, j] += eps; Sm[i, j] -= eps
        num[i, j] = (loss_from_S(Sp) - loss_from_S(Sm)) / (2 * eps)
print("max abs error:", np.abs(num - g).max())    # about 1e-9 or smaller
```

Gradient checks like this are standard practice whenever you write a custom loss; interviewers for ML roles sometimes ask you to describe one.

### Exercise 7. MaxSim by hand

Query tokens: q1 = (1, 0), q2 = (0, 1). Passage A has tokens (0.8, 0.6), (0.6, 0.8), (1, 0). Passage B has one token (0.7, 0.7). Compute ColBERT scores for both passages and say which ranks first.

**Solution.** Passage A: q1 against A's tokens gives 0.8, 0.6, 1.0, max 1.0; q2 gives 0.6, 0.8, 0.0, max 0.8; score 1.8. Passage B: q1 gives 0.7; q2 gives 0.7; score 1.4. A ranks first, because each query token found its own strong match in A. Late interaction rewards covering every part of the query with some passage token.

### Exercise 8. Why re-normalise after truncation?

Vectors q = (1, 0, 0), d1 = (0.6, 0, 0.8), d2 = (0.7, 0.7, 0.14) are (approximately) unit length. Truncate all to the first 2 dimensions. Rank d1 and d2 by dot product without re-normalising, then by cosine. Which is right for a Matryoshka model?

**Solution.** Truncated: q = (1, 0), d1 = (0.6, 0), d2 = (0.7, 0.7). Dot products: d1 = 0.6, d2 = 0.7, so d2 ranks first. Cosines: d1 = 0.6 / 0.6 = 1.0, d2 = 0.7 / 0.99 = 0.707, so d1 ranks first. Truncation leaves vectors of different lengths, and the dot product then rewards whichever passage happened to keep more of its norm in the first dimensions. A Matryoshka model is trained so that the normalised prefix is the embedding, so re-normalise (use cosine).

### Exercise 9 (coding, stretch). Repeat the lab on a real benchmark

The Nimbus corpus is too small to separate models. Repeat Labs 3 to 5 on SciFact (5,183 scientific abstracts, 300 test queries with labelled relevant abstracts), reporting recall@10, MRR@10 and nDCG@10.

**Solution.** Load the files from the MTEB copy on the Hugging Face Hub (if the repository layout has changed, check its file list and adjust the three file names):

```python
import pandas as pd
from huggingface_hub import hf_hub_download

def load_scifact():
    get = lambda f: hf_hub_download("mteb/scifact", f, repo_type="dataset")
    corpus = pd.read_json(get("corpus.jsonl"), lines=True, dtype={"_id": str})
    queries = pd.read_json(get("queries.jsonl"), lines=True, dtype={"_id": str})
    qrels = pd.read_csv(get("qrels/test.tsv"), sep="\t",
                        dtype={"query-id": str, "corpus-id": str})
    rel = qrels[qrels["score"] > 0].groupby("query-id")["corpus-id"].apply(set).to_dict()
    queries = queries[queries["_id"].isin(rel)].reset_index(drop=True)
    return corpus, queries, rel

corpus, queries, rel = load_scifact()
doc_ids = corpus["_id"].tolist()
doc_texts = (corpus["title"].fillna("") + "\n" + corpus["text"].fillna("")).tolist()
query_ids, query_texts = queries["_id"].tolist(), queries["text"].tolist()
print(len(doc_ids), "documents,", len(query_ids), "test queries")

def ir_metrics(S, k=10):
    rec = mrr = ndcg = 0.0
    for i, qid in enumerate(query_ids):
        top = np.argpartition(-S[i], k)[:k]
        top = top[np.argsort(-S[i][top])]                 # top k, best first
        gains = [1.0 if doc_ids[j] in rel[qid] else 0.0 for j in top]
        R = len(rel[qid])
        rec += sum(gains) / R
        mrr += next((1.0 / (r + 1) for r, g in enumerate(gains) if g), 0.0)
        dcg = sum(g / np.log2(r + 2) for r, g in enumerate(gains))
        idcg = sum(1.0 / np.log2(r + 2) for r in range(min(R, k)))
        ndcg += dcg / idcg
    n = len(query_ids)
    return {"recall@10": round(rec / n, 3), "MRR@10": round(mrr / n, 3), "nDCG@10": round(ndcg / n, 3)}

SCI = {}
for name, (enc_q, enc_d) in ENCODERS.items():
    Ev = as_f32(enc_d(doc_texts))          # a few seconds for small models, minutes for Qwen3 on a T4
    Qv = as_f32(enc_q(query_texts))
    SCI[name] = (Qv, Ev)
    print(f"{name:<22}", ir_metrics(Qv @ Ev.T))

for name in ["Qwen3-Embedding-0.6B", "bge-small, prefix"]:
    Qv, Ev = SCI[name]
    for m in [64, 128, 256]:
        print(f"{name:<22} dims={m:<4}", ir_metrics(truncate(Qv, m) @ truncate(Ev, m).T))

Qv, Ev = SCI["Qwen3-Embedding-0.6B"]
print("hamming only    ", ir_metrics(binary_scores(Qv, Ev, "hamming")))
print("asymmetric      ", ir_metrics(binary_scores(Qv, Ev, "asymmetric")))
print("binary + rescore", ir_metrics(binary_then_rescore(Qv, Ev, k=10, r=4)))
```

How to read your results: nDCG@10 is the metric MTEB reports for retrieval, so you can compare your numbers with the model cards (expect them to be close but not identical, because prefixes, truncation length and precision differ). You should see the MRL-trained model degrade more gently under truncation than bge-small, and binary-plus-rescore recover most of the gap between Hamming-only and full precision. If your Qwen3 run is slow on a T4, cap documents at 512 tokens with `qwen.max_seq_length = 512` and note it as a deviation.

### Exercise 10 (coding). A SPLADE retriever

Using Lab 7's `splade` model, retrieve over the Nimbus chunks, evaluate on `HARD_SET`, and print the terms shared by a query and its best chunk.

**Solution.**

```python
D_sp = splade.encode_document(chunk_texts)
Q_sp = splade.encode_query([ex["question"] for ex in HARD_SET])
S = splade.similarity(Q_sp, D_sp)                        # dot products, shape (n_queries, n_chunks)
S = (S.to_dense() if S.is_sparse else S).float().cpu().numpy()
print("SPLADE:", metrics_from_scores(S, HARD_SET))

i = 0
best = int(np.argmax(S[i]))
q_terms = dict(splade.decode(Q_sp, top_k=None)[i])
d_terms = dict(splade.decode(D_sp, top_k=None)[best])
shared = sorted(set(q_terms) & set(d_terms), key=lambda t: -q_terms[t] * d_terms[t])
print(HARD_SET[i]["question"], "->", chunks[best]["chunk_id"])
print([(t, round(q_terms[t] * d_terms[t], 2)) for t in shared[:8]])
```

The shared-term list is the explanation of the score: each term contributes the product of its query and document weights. Expansion terms appearing in both lists are how SPLADE matched "booze" to a document about alcohol. Compare SPLADE's hard-set results with the dense models from Lab 3; Part 3 fuses them.

### Exercise 11 (debugging). Recall dropped after a harmless upgrade

After a routine dependency upgrade, recall@10 on your evaluation set fell from 0.82 to 0.61. Nobody changed the model name. List the likely causes in the order you would check them.

**Solution.**

1. **Mixed embeddings**: queries embedded by the new code, documents still from the old index (or vice versa) with a different model revision. Check model revision hashes on both sides.
2. **Prefix or prompt change**: a new library version applies (or stops applying) default query prompts, or `encode` was swapped for `encode_query`.
3. **Pooling or normalisation change**: a different model configuration file loaded, or normalisation disabled.
4. **Truncation**: a different `max_seq_length` default now cuts chunks shorter.
5. **Tokenizer or padding side**: for last-token pooling, padding switched from left to right.
6. **Precision**: a switch to float16 or quantised vectors without rescoring.

The fix for the process: pin model revisions and library versions, store the embedding configuration alongside the index, and run the evaluation set in CI so such regressions are caught before release.

### Exercise 12 (design). Choose an embedding setup

A European retailer wants semantic search over 50 million product descriptions and support articles in 12 languages. Data must stay in the EU on the company's own cloud account. The p95 latency budget for retrieval is 100 ms. Propose an embedding setup and how you would validate it.

**Solution (one good answer).**

- **Model:** a self-hosted multilingual model (for example from the Qwen3-Embedding or BGE-M3 families), because data cannot go to an external API. Shortlist two or three sizes; the 0.6B class is a likely latency fit for query encoding.
- **Storage:** 50 million × 1,024 dims × 4 bytes ≈ 205 GB in float32. Use MRL truncation (for example 512 dims) plus int8 or binary codes for the first pass, with rescoring from float16 vectors on disk. Binary 512 dims = 64 bytes × 50 million = 3.2 GB in memory.
- **Hybrid:** add BM25 or a learned sparse model for SKUs, brand names and exact product codes, which dense models handle poorly.
- **Latency:** query encoding on GPU (a few milliseconds for short queries), ANN search over compressed codes, rescoring a few hundred candidates; measure p95 end to end.
- **Validation:** an evaluation set per language from real search logs with clicked or purchased items as weak labels plus a hand-labelled sample; report recall@k and nDCG@10 per language, not just the average; A/B test against the current search on conversion.
- **Operations:** pin model revisions, store embedding configuration with the index, plan re-embedding jobs (50 million items is a multi-GPU-hour batch), and monitor query-side latency and drift in score distributions.

## Summary, cheat sheet and references

The one-sentence summary of Part 2: **an embedding model is a Transformer, a pooling rule and a contrastive training signal, and every one of those choices (plus prefixes, truncation and compression) shows up in your retrieval metrics, so verify each on your own evaluation set.**

### Ten things you should now be able to do

1. Explain the path from tokens to a normalised text vector, and name the pooling each model family uses.
2. Spot the five silent bugs: wrong pooling, unmasked mean, truncation, missing normalisation, wrong or missing prefixes.
3. Write InfoNCE, derive its gradient, and explain temperature, in-batch negatives and hard negatives.
4. Explain false negatives and three ways to mitigate them.
5. Describe the multi-stage training recipe and cross-encoder distillation (Margin-MSE).
6. Compare bi-encoders, cross-encoders, ColBERT and SPLADE on interaction, cost, storage and role.
7. Apply Matryoshka truncation correctly (re-normalise) and know which models support it.
8. Implement binary quantisation with Hamming distance and rescoring, and estimate memory for any format.
9. Read MTEB critically and run a defensible model selection on your own data.
10. Plan an embedding-model migration in production.

### Cheat sheet

| Item | Rule or formula |
| --- | --- |
| Mean pooling | e = Σ m\_i h\_i / Σ m\_i (mask out padding) |
| Pooling by family | Match training: CLS (BGE), mean (many sentence-transformers models), last token (decoder LLM embedders) |
| InfoNCE | 𝓛 = −(1/B) Σ\_i log softmax(S\_i)\_i, with S = QPᵀ/τ |
| InfoNCE gradient | ∂𝓛\_i/∂S\_ij = P\_ij − 1\[i = j\] |
| Typical temperature | τ ≈ 0.01 to 0.05 (scale 20 to 100) |
| Margin-MSE | ((s\_S⁺ − s\_S⁻) − (s\_T⁺ − s\_T⁻))² |
| ColBERT MaxSim | s = Σ\_i max\_j q\_iᵀ p\_j |
| SPLADE term weight | w\_j = max\_i log(1 + ReLU(w\_ij)) |
| Matryoshka | Keep first m dims, then re-normalise |
| Bytes per vector | d × 4 (float32), d × 2 (float16), d (int8), d / 8 (binary) |
| Hamming and angle | Fraction of differing sign bits estimates θ/π |
| Choosing a model | Constraints → shortlist → your eval set → quality per cost |
| Switching models | Re-embed everything; never mix models between queries and documents |

### References

- van den Oord et al. (2018). [Representation Learning with Contrastive Predictive Coding](https://arxiv.org/abs/1807.03748) (InfoNCE).
- Reimers and Gurevych (2019). [Sentence-BERT](https://arxiv.org/abs/1908.10084).
- Karpukhin et al. (2020). [Dense Passage Retrieval](https://arxiv.org/abs/2004.04906).
- Khattab and Zaharia (2020). [ColBERT](https://arxiv.org/abs/2004.12832); Santhanam et al. (2021). [ColBERTv2](https://arxiv.org/abs/2112.01488).
- Wang and Isola (2020). [Understanding Contrastive Representation Learning through Alignment and Uniformity on the Hypersphere](https://arxiv.org/abs/2005.10242).
- Hofstätter et al. (2020). [Improving Efficient Neural Ranking Models with Cross-Architecture Knowledge Distillation](https://arxiv.org/abs/2010.02666) (Margin-MSE).
- Gao et al. (2021). [Scaling Deep Contrastive Learning Batch Size under Memory Limited Setup](https://arxiv.org/abs/2101.06983) (GradCache).
- Formal et al. (2021). [SPLADE](https://arxiv.org/abs/2107.05720) and [SPLADE v2](https://arxiv.org/abs/2109.10086).
- Izacard et al. (2021). [Contriever: Unsupervised Dense Information Retrieval with Contrastive Learning](https://arxiv.org/abs/2112.09118).
- Kusupati et al. (2022). [Matryoshka Representation Learning](https://arxiv.org/abs/2205.13147).
- Wang et al. (2022). [E5: Text Embeddings by Weakly-Supervised Contrastive Pre-training](https://arxiv.org/abs/2212.03533); Wang et al. (2023). [Improving Text Embeddings with Large Language Models](https://arxiv.org/abs/2401.00368) (E5-Mistral).
- Muennighoff et al. (2022). [MTEB](https://arxiv.org/abs/2210.07316); Enevoldsen et al. (2025). [MMTEB](https://arxiv.org/abs/2502.13595); Su et al. (2024). [BRIGHT: A Realistic and Challenging Benchmark for Reasoning-Intensive Retrieval](https://arxiv.org/abs/2407.12883).
- Moreira et al. (2024). [NV-Retriever: Improving Text Embedding Models with Effective Hard-Negative Mining](https://arxiv.org/abs/2407.15831).
- Lee et al. (2025). [Gemini Embedding: Generalizable Embeddings from Gemini](https://arxiv.org/abs/2503.07891).
- Zhang et al. (2025). [Qwen3 Embedding](https://arxiv.org/abs/2506.05176) technical report; model card: [Qwen/Qwen3-Embedding-0.6B](https://huggingface.co/Qwen/Qwen3-Embedding-0.6B).
- Charikar (2002). Similarity Estimation Techniques from Rounding Algorithms. STOC 2002 (random-hyperplane hashing).
- Library: [sentence-transformers migration guide](https://www.sbert.net/docs/migration_guide.html) (v5.0: SparseEncoder, encode\_query and encode\_document; v5.4: `tokenizer_kwargs` renamed to `processor_kwargs`, new import paths; v6.0: `MultiVectorEncoder`, requires transformers 5).
- 2026 model releases cited in Chapter 6: MongoDB, [The Voyage 4 Series Now Available](https://www.mongodb.com/products/updates/the-voyage-4-series-now-available) (15 January 2026); Google (10 March 2026), [Gemini Embedding 2: Our first natively multimodal embedding model](https://blog.google/innovation-and-ai/models-and-research/gemini-models/gemini-embedding-2/); check Google's Gemini API documentation for current model IDs.

### Coming in Part 3: Search and indexing

Part 3 builds the index that holds your vectors. You will derive BM25 from TF-IDF and probabilistic retrieval, implement exact search and then approximate nearest-neighbour search (IVF, product quantisation, HNSW, DiskANN) and measure their recall-speed trade-offs, learn how vector databases handle metadata filtering and updates, compare pgvector, Qdrant, Milvus, Weaviate, Elasticsearch/OpenSearch and managed services, and fuse dense and sparse results with reciprocal rank fusion.
