"""CI evaluation gate: fail the build if the candidate is likely worse than the baseline by more than a tolerance."""
import json, sys
import numpy as np

def paired_bootstrap_lower(candidate, baseline, B=10_000, seed=0, alpha=0.05):
    d = np.asarray(candidate, float) - np.asarray(baseline, float)
    rng = np.random.default_rng(seed)
    means = d[rng.integers(0, len(d), size=(B, len(d)))].mean(axis=1)
    return d.mean(), np.quantile(means, alpha / 2)

def main(candidate_path, baseline_path, tolerance=0.02):
    cand, base = json.load(open(candidate_path)), json.load(open(baseline_path))
    assert cand["question_ids"] == base["question_ids"], "scores must be on the same questions, in the same order"
    mean_diff, lower = paired_bootstrap_lower(cand["scores"], base["scores"])
    print(f"mean difference {mean_diff:+.3f}, 95% lower bound {lower:+.3f}, tolerance -{tolerance}")
    if lower < -tolerance:
        print("FAIL: likely regression beyond tolerance"); return 1
    print("PASS"); return 0

if __name__ == "__main__":
    sys.exit(main(sys.argv[1], sys.argv[2], float(sys.argv[3]) if len(sys.argv) > 3 else 0.02))
