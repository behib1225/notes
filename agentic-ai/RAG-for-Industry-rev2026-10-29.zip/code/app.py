"""A minimal production-shaped RAG API: authentication, permission-aware retrieval, cited answers, traces."""
import uuid, time, re
from fastapi import FastAPI, Depends, Header, HTTPException
from pydantic import BaseModel, Field

# ---- replace these three with your real components (Parts 3, 5 and 9) ----
DOCS = [{"id": "hr-leave#0", "title": "Leave Policy", "text": "Employees get 21 days of PTO per year.", "acl": ["all"]},
        {"id": "eng-oncall#0", "title": "On-Call Policy", "text": "Engineers receive 400 dollars per on-call week.", "acl": ["engineering"]}]
def retrieve(question: str, groups: list[str], k: int = 3) -> list[dict]:
    allowed = set(groups) | {"all"}
    q = set(re.findall(r"\w+", question.lower()))
    visible = [d for d in DOCS if allowed & set(d["acl"])]                     # permission filter first
    scored = sorted(visible, key=lambda d: -len(q & set(re.findall(r"\w+", d["text"].lower()))))
    return [d for d in scored[:k] if q & set(re.findall(r"\w+", d["text"].lower()))]
def generate(question: str, sources: list[dict]) -> str:
    return f"{sources[0]['text']} [{sources[0]['id']}]" if sources else "I don't know based on the provided documents."
TOKENS = {"token-eng": {"user": "eve", "groups": ["engineering"]}, "token-sales": {"user": "sam", "groups": ["sales"]}}
# ---------------------------------------------------------------------------

app = FastAPI(title="Nimbus RAG API")

class AskRequest(BaseModel):
    question: str = Field(min_length=1, max_length=2000)

class Source(BaseModel):
    id: str
    title: str

class AskResponse(BaseModel):
    answer: str
    sources: list[Source]
    abstained: bool
    trace_id: str
    latency_ms: int

def current_user(authorization: str = Header(default="")):
    """Identity comes from the request's credentials, never from the question or the model."""
    user = TOKENS.get(authorization.removeprefix("Bearer ").strip())
    if user is None:
        raise HTTPException(status_code=401, detail="invalid or missing token")
    return user

@app.get("/healthz")
def healthz():
    return {"status": "ok"}

@app.post("/ask", response_model=AskResponse)
def ask(req: AskRequest, user=Depends(current_user)):
    t0, trace_id = time.perf_counter(), uuid.uuid4().hex
    sources = retrieve(req.question, user["groups"])
    answer = generate(req.question, sources)
    cited = set(re.findall(r"\[([\w\-]+#\d+)\]", answer))
    if cited - {s["id"] for s in sources}:                                 # citation existence check
        answer, sources = "I don't know based on the provided documents.", []
    return AskResponse(answer=answer, sources=[Source(id=s["id"], title=s["title"]) for s in sources],
                       abstained=not sources, trace_id=trace_id,
                       latency_ms=round(1000 * (time.perf_counter() - t0)))
