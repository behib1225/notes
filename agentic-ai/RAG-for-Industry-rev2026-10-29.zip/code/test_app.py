from fastapi.testclient import TestClient
from app import app
client = TestClient(app)

def test_requires_auth():
    assert client.post("/ask", json={"question": "PTO days?"}).status_code == 401

def test_answer_is_cited():
    r = client.post("/ask", json={"question": "How many PTO days per year?"}, headers={"Authorization": "Bearer token-sales"})
    body = r.json()
    assert r.status_code == 200 and "[hr-leave#0]" in body["answer"] and not body["abstained"]

def test_no_permission_leak():
    r = client.post("/ask", json={"question": "How many dollars per on-call week?"}, headers={"Authorization": "Bearer token-sales"})
    assert "400" not in r.json()["answer"]

def test_engineer_can_see_oncall():
    r = client.post("/ask", json={"question": "How many dollars per on-call week?"}, headers={"Authorization": "Bearer token-eng"})
    assert "400" in r.json()["answer"]

def test_validation():
    assert client.post("/ask", json={"question": ""}, headers={"Authorization": "Bearer token-eng"}).status_code == 422
