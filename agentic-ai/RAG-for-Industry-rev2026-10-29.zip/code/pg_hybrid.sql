CREATE EXTENSION IF NOT EXISTS vector;
DROP TABLE IF EXISTS chunks;
CREATE TABLE chunks (
    chunk_id    text PRIMARY KEY,
    title       text NOT NULL,
    content     text NOT NULL,
    acl_groups  text[] NOT NULL,                                   -- groups allowed to read
    embedding   vector(3) NOT NULL,                                -- 384 or 1024 in practice
    tsv         tsvector GENERATED ALWAYS AS (to_tsvector('english', title || ' ' || content)) STORED
);
CREATE INDEX chunks_hnsw ON chunks USING hnsw (embedding vector_cosine_ops);
CREATE INDEX chunks_tsv  ON chunks USING gin (tsv);
CREATE INDEX chunks_acl  ON chunks USING gin (acl_groups);

INSERT INTO chunks VALUES
 ('hr-leave#0',  'Leave Policy',      'Employees get 21 days of paid time off per year.',     '{all}',         '[0.9,0.1,0.0]'),
 ('eng-oncall#0','On-Call Policy',    'Engineers receive 400 dollars per on-call week.',      '{engineering}', '[0.1,0.9,0.0]'),
 ('err#0',       'NX-7 Troubleshooting','Error E-212 means the battery is overheating.',      '{support,engineering}', '[0.0,0.2,0.9]');

-- Hybrid search with reciprocal rank fusion, permission filter applied inside both searches.
PREPARE hybrid(vector, text, text[]) AS
WITH dense AS (
    SELECT chunk_id, ROW_NUMBER() OVER (ORDER BY embedding <=> $1) AS r
    FROM chunks
    WHERE acl_groups && ($3 || '{all}'::text[])
    ORDER BY embedding <=> $1
    LIMIT 50
), sparse AS (
    SELECT chunk_id, ROW_NUMBER() OVER (ORDER BY ts_rank_cd(tsv, q) DESC) AS r
    FROM chunks, websearch_to_tsquery('english', $2) AS q
    WHERE tsv @@ q AND acl_groups && ($3 || '{all}'::text[])
    ORDER BY ts_rank_cd(tsv, q) DESC
    LIMIT 50
)
SELECT chunk_id, SUM(1.0 / (60 + r)) AS rrf
FROM (SELECT * FROM dense UNION ALL SELECT * FROM sparse) AS both_lists
GROUP BY chunk_id
ORDER BY rrf DESC
LIMIT 5;

\echo '--- engineering user, query about on-call pay'
EXECUTE hybrid('[0.1,0.8,0.1]', 'on-call week dollars', '{engineering}');
\echo '--- sales user, same query: no engineering-only chunk'
EXECUTE hybrid('[0.1,0.8,0.1]', 'on-call week dollars', '{sales}');
\echo '--- support user, error code query'
EXECUTE hybrid('[0.0,0.1,0.9]', 'E-212 battery', '{support}');
SELECT extversion FROM pg_extension WHERE extname = 'vector';
