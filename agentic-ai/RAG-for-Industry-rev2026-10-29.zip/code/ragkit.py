"""ragkit: shared helpers for the "RAG for Industry" guide (Parts 1 to 11).

Upload this file to Colab or Kaggle and `from ragkit import *` instead of re-pasting cells.
Pure-Python parts are tested; model helpers load models only when called.
"""
from __future__ import annotations
import math, re, json, hashlib
from collections import Counter
import numpy as np

# ---------------------------------------------------------------- corpus (Parts 1, 8)
CORPUS = [
    {"doc_id": "hr-leave", "title": "Paid Time Off and Leave Policy",
     "text": ("Full-time employees at Nimbus Robotics accrue 1.75 days of paid time off (PTO) per month, which is 21 days per year. "
              "PTO accrual starts on the first day of employment. "
              "Up to 5 unused PTO days can be carried over into the next calendar year. "
              "Carried-over days expire if they are not used by March 31. "
              "Requests for PTO must be submitted in Workday at least two weeks in advance for absences longer than three days. "
              "Primary caregivers receive 16 weeks of fully paid parental leave. "
              "Secondary caregivers receive 6 weeks of fully paid parental leave. "
              "Sick days are separate from PTO: every employee receives 8 paid sick days per year, and they do not carry over.")},
    {"doc_id": "hr-remote", "title": "Remote and Hybrid Work Policy",
     "text": ("Employees may work remotely up to three days per week, subject to manager approval. "
              "Core collaboration hours are 10:00 to 15:00 Eastern Time, Monday to Friday. "
              "Every employee receives a one-time home office stipend of 600 dollars to buy a desk, chair or monitor. "
              "Employees also receive 50 dollars per month toward home internet costs. "
              "Fully remote arrangements require approval from a vice president. "
              "Working from another country for more than 30 days in a year requires approval from the legal team because of tax rules.")},
    {"doc_id": "fin-expense", "title": "Travel and Expense Policy",
     "text": ("Expenses must be submitted in Expensify within 30 days of the purchase. "
              "An itemised receipt is required for any expense above 25 dollars. "
              "When travelling for work, meals are reimbursed up to 75 dollars per day. "
              "Book economy class for flights shorter than six hours. "
              "For flights of six hours or longer, premium economy is allowed. "
              "Any single expense above 500 dollars requires written approval from your manager before purchase. "
              "Alcohol is not reimbursable except at approved client events.")},
    {"doc_id": "it-security", "title": "Information Security Standards",
     "text": ("Passwords must be at least 14 characters long and must not be reused across systems. "
              "Multi-factor authentication with a hardware security key is required for any access to production systems. "
              "All company laptops use full-disk encryption, which must never be disabled. "
              "Suspected phishing emails must be reported to security@nimbus-robotics.example within one hour. "
              "Use the company VPN whenever you connect from a public network. "
              "Lost or stolen devices must be reported to the IT help desk immediately so they can be wiped remotely.")},
    {"doc_id": "prod-nx7", "title": "Nimbus NX-7 Warehouse Robot: Technical Specifications",
     "text": ("The Nimbus NX-7 is an autonomous mobile robot for warehouse picking and transport. "
              "It carries a maximum payload of 150 kilograms. "
              "Its battery lasts up to 8 hours of continuous operation. "
              "The battery recharges from 0 to 80 percent in 45 minutes using the NX Dock. "
              "Maximum travel speed is 2.0 metres per second, limited to 1.2 metres per second near people. "
              "Navigation uses a 360-degree lidar and two stereo cameras. "
              "The current firmware version is 4.2. "
              "The robot is rated for operating temperatures between 0 and 40 degrees Celsius.")},
    {"doc_id": "prod-nx7-errors", "title": "Nimbus NX-7 Troubleshooting Guide",
     "text": ("Error E-104 means the lidar is obstructed: clean the sensor window with a dry microfibre cloth and restart navigation. "
              "Error E-212 means the battery is overheating: stop the robot, move it to a cooler area, and contact support if the error persists for more than 30 minutes. "
              "Error E-330 means a wheel motor has stalled: check for debris around the wheels before resetting. "
              "Error E-415 means the robot lost its map localisation: drive it manually to a docking station to relocalise. "
              "For any error not listed here, collect the robot logs from the NX Console and open a support ticket.")},
    {"doc_id": "eng-oncall", "title": "Engineering On-Call Policy",
     "text": ("On-call duty rotates weekly, with handoff every Monday at 09:00 Eastern Time. "
              "The on-call engineer must acknowledge a SEV-1 page within 15 minutes. "
              "SEV-2 pages must be acknowledged within one hour. "
              "Engineers receive 400 dollars of extra compensation for each week of on-call duty. "
              "If you are paged between midnight and 06:00, you may start work late the next day. "
              "Every incident must have a written post-incident review within five business days.")},
    {"doc_id": "company-about", "title": "About Nimbus Robotics",
     "text": ("Nimbus Robotics was founded in 2019 in Waterloo, Ontario. "
              "The company builds autonomous robots for warehouses and logistics centres. "
              "It has about 450 employees across offices in Waterloo, Montreal and Boston. "
              "The chief executive officer is Dana Whitfield. "
              "The company's mission is to make warehouse work safer by automating heavy and repetitive tasks.")},
]
EXTRA_MULTIHOP_DOCS = [  # Part 8
    {"doc_id": "eng-incidents", "title": "Incident Review Process",
     "text": "Post-incident reviews are owned by the Site Reliability team lead, Priya Raman. "
             "Reviews are stored in the incident tracker and shared with all engineering managers."},
    {"doc_id": "org-chart", "title": "Engineering Organisation",
     "text": "Priya Raman reports to Marco Diaz, the Vice President of Engineering. "
             "The Support team lead, Ana Silva, reports to the Vice President of Operations."},
]
ACL = {"prod-nx7-errors": ["support", "engineering"], "eng-oncall": ["engineering"]}   # everything else: ["all"]

EVAL_SET = [
    {"question": "How many vacation days do I get per year?", "gold_doc": "hr-leave"},
    {"question": "Can I carry unused PTO into next year?", "gold_doc": "hr-leave"},
    {"question": "How much money do I get to set up my home office?", "gold_doc": "hr-remote"},
    {"question": "What is the daily food allowance on a business trip?", "gold_doc": "fin-expense"},
    {"question": "Do I need a receipt for a 20 dollar taxi ride?", "gold_doc": "fin-expense"},
    {"question": "What is the minimum password length?", "gold_doc": "it-security"},
    {"question": "The robot shows E-212. What should I do?", "gold_doc": "prod-nx7-errors"},
    {"question": "How heavy a load can the NX-7 carry?", "gold_doc": "prod-nx7"},
    {"question": "How fast must I respond to a SEV-1 page?", "gold_doc": "eng-oncall"},
    {"question": "Who runs the company?", "gold_doc": "company-about"},
]
HARD_SET = [
    {"question": "Is booze covered on expense reports?", "gold_doc": "fin-expense"},
    {"question": "My robot can't see because the laser sensor is dirty", "gold_doc": "prod-nx7-errors"},
    {"question": "How long can I work from Portugal?", "gold_doc": "hr-remote"},
    {"question": "What's the top speed of the robot around humans?", "gold_doc": "prod-nx7"},
    {"question": "Who do I tell about a suspicious email?", "gold_doc": "it-security"},
    {"question": "Do sick days roll over?", "gold_doc": "hr-leave"},
    {"question": "How long after an outage do I have to write it up?", "gold_doc": "eng-oncall"},
    {"question": "Where are the company's offices?", "gold_doc": "company-about"},
    {"question": "Is business class allowed on a 7 hour flight?", "gold_doc": "fin-expense"},
    {"question": "The NX-7 can't figure out where it is", "gold_doc": "prod-nx7-errors"},
    {"question": "How much do they pay toward my internet at home?", "gold_doc": "hr-remote"},
    {"question": "My laptop got stolen, what now?", "gold_doc": "it-security"},
]

# ---------------------------------------------------------------- chunking (Parts 1, 4)
def split_sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text.strip()) if s.strip()]

def chunk_document(doc, max_words=60, overlap_sentences=1):
    """Sentence packing with overlap; max_words is a target (a single long sentence can exceed it)."""
    groups, current = [], []
    for sent in split_sentences(doc["text"]):
        if current and sum(len(s.split()) for s in current) + len(sent.split()) > max_words:
            groups.append(current)
            current = current[-overlap_sentences:] if overlap_sentences > 0 else []
        current.append(sent)
    if current:
        groups.append(current)
    return [{"chunk_id": f"{doc['doc_id']}#{i}", "doc_id": doc["doc_id"], "title": doc["title"],
             "text": " ".join(s), "acl": ACL.get(doc["doc_id"], ["all"])} for i, s in enumerate(groups)]

def chunk_spans(n_tokens, size, overlap):
    assert 0 <= overlap < size
    spans, start = [], 0
    while start < n_tokens:
        end = min(start + size, n_tokens)
        spans.append((start, end))
        if end == n_tokens:
            break
        start = end - overlap
    return spans

# ---------------------------------------------------------------- retrieval (Parts 3, 5)
def bm25_scores(query_tokens, docs_tokens, k1=1.2, b=0.75):
    N = len(docs_tokens); avgdl = sum(map(len, docs_tokens)) / N
    df = Counter(t for d in docs_tokens for t in set(d))
    out = []
    for d in docs_tokens:
        tf, s = Counter(d), 0.0
        for t in set(query_tokens):
            if t in tf:
                idf = math.log(1 + (N - df[t] + 0.5) / (df[t] + 0.5))
                s += idf * tf[t] * (k1 + 1) / (tf[t] + k1 * (1 - b + b * len(d) / avgdl))
        out.append(s)
    return out

def rrf(rankings, k=60, weights=None):
    scores = Counter()
    for w, ranking in zip(weights or [1.0] * len(rankings), rankings):
        for rank, doc in enumerate(ranking, start=1):
            scores[doc] += w / (k + rank)
    return [d for d, _ in scores.most_common()]

def mmr(q, C, k, lam=0.7):
    rel = C @ q; chosen, rest = [], list(range(len(C)))
    while rest and len(chosen) < k:
        best = max(rest, key=lambda i: lam * rel[i] - (1 - lam) * (max(C[i] @ C[j] for j in chosen) if chosen else 0.0))
        chosen.append(best); rest.remove(best)
    return chosen

# ---------------------------------------------------------------- metrics and statistics (Part 6)
def recall_at_k(ranked, relevant, k): return len(set(ranked[:k]) & relevant) / len(relevant) if relevant else 0.0
def mrr(ranked, relevant): return next((1 / (i + 1) for i, d in enumerate(ranked) if d in relevant), 0.0)
def ndcg_at_k(ranked, grades, k):
    dcg = sum((2 ** grades.get(d, 0) - 1) / math.log2(i + 2) for i, d in enumerate(ranked[:k]))
    idcg = sum((2 ** g - 1) / math.log2(i + 2) for i, g in enumerate(sorted(grades.values(), reverse=True)[:k]))
    return dcg / idcg if idcg else 0.0

def bootstrap_ci(scores, B=10_000, alpha=0.05, seed=0):
    x = np.asarray(scores, float); rng = np.random.default_rng(seed)
    m = x[rng.integers(0, len(x), size=(B, len(x)))].mean(axis=1)
    return x.mean(), np.quantile(m, alpha / 2), np.quantile(m, 1 - alpha / 2)

def paired_bootstrap(a, b, **kw):
    return bootstrap_ci(np.asarray(a, float) - np.asarray(b, float), **kw)

def mcnemar_exact(a_ok, b_ok):
    from scipy.stats import binomtest
    a, b = np.asarray(a_ok, bool), np.asarray(b_ok, bool)
    only_a, only_b = int((a & ~b).sum()), int((~a & b).sum())
    return only_a, only_b, (binomtest(only_b, only_a + only_b, 0.5).pvalue if only_a + only_b else 1.0)

def cohen_kappa(h, j):
    h, j = np.asarray(h), np.asarray(j)
    po = (h == j).mean(); pe = sum((h == c).mean() * (j == c).mean() for c in np.union1d(h, j))
    return (po - pe) / (1 - pe)

# ---------------------------------------------------------------- data (Parts 2 to 7)
def load_scifact(split="test"):
    """SciFact from the MTEB copy on the Hugging Face Hub (needs internet and pandas)."""
    import pandas as pd
    from huggingface_hub import hf_hub_download
    get = lambda f: hf_hub_download("mteb/scifact", f, repo_type="dataset")
    corpus = pd.read_json(get("corpus.jsonl"), lines=True, dtype={"_id": str})
    queries = pd.read_json(get("queries.jsonl"), lines=True, dtype={"_id": str})
    qrels = pd.read_csv(get(f"qrels/{split}.tsv"), sep="\t", dtype={"query-id": str, "corpus-id": str})
    rel = qrels[qrels["score"] > 0].groupby("query-id")["corpus-id"].apply(set).to_dict()
    queries = queries[queries["_id"].isin(rel)].reset_index(drop=True)
    return corpus, queries, rel

# ---------------------------------------------------------------- models (loaded on demand)
def load_chat(model_name="Qwen/Qwen3-4B-Instruct-2507"):
    """Returns chat(messages, tools=None, max_new_tokens=200) -> str for a local instruct model."""
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    dtype = (torch.bfloat16 if dev == "cuda" and torch.cuda.get_device_capability()[0] >= 8
             else torch.float16 if dev == "cuda" else torch.float32)
    tok = AutoTokenizer.from_pretrained(model_name)
    llm = AutoModelForCausalLM.from_pretrained(model_name, dtype=dtype, device_map="auto")
    def chat(messages, tools=None, max_new_tokens=200):
        inputs = tok.apply_chat_template(messages, tools=tools, add_generation_prompt=True,
                                         return_dict=True, return_tensors="pt").to(llm.device)
        with torch.no_grad():
            out = llm.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False)
        text = tok.decode(out[0, inputs["input_ids"].shape[1]:], skip_special_tokens=False)
        return text.replace("<|im_end|>", "").replace("<|endoftext|>", "").strip()
    return chat

__all__ = [n for n in dir() if not n.startswith("_")]
