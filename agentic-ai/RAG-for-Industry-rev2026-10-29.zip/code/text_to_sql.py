"""Safe text-to-SQL: the LLM writes SELECT queries; code validates, scopes to the user, limits and runs them read-only."""
import sqlite3
import sqlglot
from sqlglot import exp

SCHEMA = {"orders": ["order_id", "customer_id", "status", "total", "created_at"],
          "order_items": ["order_id", "product", "quantity", "price"]}
SCOPE = {"orders": "customer_id", "order_items": None}          # how each table is restricted to the caller

def validate_and_scope(sql: str, customer_id: int, max_rows: int = 100) -> str:
    trees = sqlglot.parse(sql, read="sqlite")
    if len(trees) != 1 or not isinstance(trees[0], exp.Select):
        raise ValueError("only a single SELECT statement is allowed")
    tree = trees[0]
    if any(isinstance(n, (exp.Insert, exp.Update, exp.Delete, exp.Drop, exp.Create, exp.Alter, exp.Command))
           for n in tree.walk()):
        raise ValueError("write or DDL operations are not allowed")
    tables = {t.name for t in tree.find_all(exp.Table)}
    if not tables <= SCHEMA.keys():
        raise ValueError(f"unknown tables: {sorted(tables - SCHEMA.keys())}")
    for col in tree.find_all(exp.Column):
        if col.name not in {c for cols in SCHEMA.values() for c in cols} and col.name != "*":
            raise ValueError(f"unknown column: {col.name}")
    # Row-level scoping: replace every table with a subquery restricted to this customer.
    def scope(node):
        if isinstance(node, exp.Table) and node.name in SCHEMA:
            alias = node.alias_or_name
            if node.name == "orders":
                inner = f"SELECT * FROM orders WHERE customer_id = {int(customer_id)}"
            else:   # child table: restrict through the customer's orders
                inner = f"SELECT * FROM order_items WHERE order_id IN (SELECT order_id FROM orders WHERE customer_id = {int(customer_id)})"
            return exp.Subquery(this=sqlglot.parse_one(inner), alias=exp.TableAlias(this=exp.to_identifier(alias)))
        return node
    scoped = tree.transform(scope)
    if not scoped.args.get("limit"):
        scoped = scoped.limit(max_rows)
    return scoped.sql(dialect="sqlite")

def run_readonly(db_path: str, sql: str):
    con = sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)       # read-only connection
    try:
        con.execute("PRAGMA query_only = ON")
        return con.execute(sql).fetchall()
    finally:
        con.close()

if __name__ == "__main__":
    con = sqlite3.connect("shop.db")
    con.executescript("""DROP TABLE IF EXISTS orders; DROP TABLE IF EXISTS order_items;
    CREATE TABLE orders(order_id INTEGER, customer_id INTEGER, status TEXT, total REAL, created_at TEXT);
    CREATE TABLE order_items(order_id INTEGER, product TEXT, quantity INTEGER, price REAL);
    INSERT INTO orders VALUES (1, 7, 'shipped', 120.0, '2026-09-01'), (2, 7, 'late', 80.0, '2026-10-10'), (3, 9, 'late', 999.0, '2026-10-12');
    INSERT INTO order_items VALUES (1, 'NX dock', 1, 120.0), (2, 'cable', 2, 40.0), (3, 'robot', 1, 999.0);""")
    con.commit(); con.close()
    llm_sql = "SELECT status, COUNT(*) AS n, SUM(total) AS spend FROM orders GROUP BY status"
    s = validate_and_scope(llm_sql, customer_id=7); print(s); print(run_readonly("shop.db", s))
    s2 = validate_and_scope("SELECT o.order_id, i.product FROM orders o JOIN order_items i ON o.order_id = i.order_id", 7)
    print(run_readonly("shop.db", s2))
    for bad in ["DELETE FROM orders", "SELECT * FROM orders; DROP TABLE orders", "SELECT * FROM users",
                "SELECT password FROM orders", "SELECT * FROM orders WHERE customer_id = 9"]:
        try:
            s = validate_and_scope(bad, 7); print("allowed:", bad, "->", run_readonly("shop.db", s))
        except Exception as e:
            print("blocked:", bad, "->", e)
