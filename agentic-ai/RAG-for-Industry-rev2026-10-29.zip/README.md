# RAG for Industry: a book-length guide in 11 parts

Version: 28 October 2026, **revised 29 October 2026** (see `CHANGELOG.md` for what changed and why). The "live document" links below point to the 28 October text; the files in this bundle are the revised version.

## Contents

| Folder | What it contains |
| --- | --- |
| `tutorial/markdown/` | All 11 parts as Markdown, with the 21 diagrams referenced from `tutorial/diagrams/` |
| `tutorial/pdf/` | All 11 parts as PDF (23 to 31 pages each), rebuilt from the Markdown with rendered formulas, a table of contents per part and the diagrams in place |
| `tutorial/diagrams/` | 21 diagrams as SVG (for the Markdown), PDF (for the LaTeX build) and PNG (embedded in the notebooks); `tools/make_diagrams.py` regenerates them |
| `notebooks/` | One Jupyter/Colab notebook per part, generated from the Markdown: the text as Markdown cells (diagrams embedded) and every Python block as a code cell, in order. Each notebook is self-contained: it installs its requirements, imports the shared objects from `ragkit.py`, and Part 6 carries a copy of the Part 5 setup it depends on |
| `requirements/` | One requirements file per part plus `common.txt`; all parts share the same core pair (sentence-transformers 6.x with transformers 5.x) |
| `code/` | Companion code: `ragkit.py` (shared corpus, evaluation sets, chunkers, retrieval helpers, metrics, statistics, loaders) and the Part 9 appendix code (FastAPI service and tests, CI evaluation gate, text-to-SQL guard, PostgreSQL + pgvector hybrid search) |
| `tools/` | The scripts that produced this revision: text fixes, diagram generation, notebook generation, PDF build |
| `CHANGELOG.md` | Every correction made on 29 October 2026, with the source that justified it |

## Parts

| Part | Topic | Live document (28 Oct text) |
| --- | --- | --- |
| 1 | Foundations and your first RAG system | https://claude.ai/artifact/EZn47cMeU1KKKEEAjx6PwH |
| 2 | Embeddings | https://claude.ai/artifact/JgNvMFmuZvfWnZkiMSrtWF |
| 3 | Search and indexing | https://claude.ai/artifact/4apeazLPXdREEJWeobchwQ |
| 4 | Ingestion and chunking | https://claude.ai/artifact/Kojq29xyALdCjLp56LRkWA |
| 5 | The query side | https://claude.ai/artifact/VtsWPqvYkF9UXHJPsgF96S |
| 6 | Evaluation | https://claude.ai/artifact/1BsZtfMeYvc5FgZLtKS8Lp |
| 7 | Training and fine-tuning | https://claude.ai/artifact/DeFauod2SpsyuD6ej7gESv |
| 8 | Advanced architectures | https://claude.ai/artifact/TEQmXiS6JoHaPAPRe69zr4 |
| 9 | Production | https://claude.ai/artifact/WTdC2TbCPp4iqsBgjDC7yw |
| 10 | Frameworks | https://claude.ai/artifact/H1H5o75VToB8mNDBV7SJCJ |
| 11 | Interview preparation | https://claude.ai/artifact/SBtRjsao76FFxcsYQZa1uS |

**In a hurry?** Part 1 opens with a four-week fast-track reading order.

## How to use the notebooks

1. Open a notebook in Google Colab or Kaggle and select a T4 GPU runtime.
2. Upload `code/ragkit.py` into the notebook's working directory (Colab: Files panel, drag and drop).
3. Run the pip cell, then the "setup check" cell (`from ragkit import *`), then the lab cells in order.

Exercise solutions and short illustrative snippets are not meant to run top to bottom: they depend on the lab state or are deliberate fragments (for example the code-review drills in Part 11). Part 1 contains a lab guide with GPU needs, time estimates and CPU fallbacks for every part.

## Verification status (read this)

What was executed and passed in a sandbox (28 October, re-run 29 October):
- Every pure-Python lab component in the text (metrics, BM25, RRF, IVF and PQ from scratch, chunkers, MinHash, caches, statistics, agent loops with a scripted model, MCP server and client, LangGraph graphs, framework wiring with stand-in models).
- All companion code: `pytest -q code/test_app.py` (5 tests pass); the evaluation gate passes an unchanged system and fails a 7-point regression; the text-to-SQL guard blocks writes, unknown tables and columns, and cross-customer reads; `pg_hybrid.sql` runs on PostgreSQL 16 with pgvector 0.6 (it uses only features available since 0.5 and should be re-tested on 0.8.x) and enforces permission filters.
- Every Python code block in every notebook compiles (syntax check on 29 October: 0 errors).
- Every worked example and numerical exercise solution in Parts 1 to 11 was recomputed on 29 October and is correct.

What was checked but **not executed** (no GPU, no Hugging Face access in the sandbox):
- Cells that download models or datasets from Hugging Face. Their APIs were checked against library source code and documentation (sentence-transformers 6.x, transformers 5.x, TRL, PEFT, LangChain 1.x, LlamaIndex core 0.14, Haystack 3.x, DSPy 3.x, MCP Python SDK 2.x). The two new `MultiVectorEncoder` cells (Part 2 Lab 8, Part 8 Lab 6) were written from the sentence-transformers 6 migration guide and have not been run. Expected results in those labs are expectations, not measurements.

Known limitations:
- Fast-moving facts (model releases, framework versions, regulation) are as of 29 October 2026; the primary sources are cited in the text and in `CHANGELOG.md`. Check them before relying on a date or a version.
- The free-tier generator remains Qwen3-4B-Instruct-2507; Gemma 4 E4B (April 2026) is documented as the upgrade on a 24 GB GPU but was not used in the labs (Part 1 explains why).
