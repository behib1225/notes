# phase_16_solutions.md

Worked answers for Phase 16: cumulative review, concept checks, quiz, and both
assignments. No case study this phase.

## Cumulative review (section 2)

**1. 87.5% raw agreement.** A judge that always says "pass" scores 87.5% on a
sample that is 87.5% passes, with Cohen's kappa 0.000 — raw agreement is
dominated by the base rate, so it measures your sample's balance more than your
judge. Compute **kappa against hand labels over a deliberately balanced
sample**, report the **worst** criterion rather than the mean, and make the
label count part of the gate. Below the floor a judge may be reported and may
not grade.

**2. ASR 1.000 before and after.** The compromised agent simply *typed* the
canary: the attack's success did not require the capability the defence removed,
so removing it changed nothing measurable. Every attack must now complete "this
succeeds only if the agent can ___" with a tool, a credential or a channel;
success is graded from the **environment**; each family carries a control that
must still pass; and the rate is reported per family with a Wilson interval and
the minimum detectable effect beside any delta.

**3. `read_only` grants three things:** exemption from the approval gate,
eligibility for retry, and eligibility for caching. A mislabelled tool therefore
does not merely bypass the gate — it becomes **replayable**, so one bad label
converts a side-effecting call into something the system may perform again on
its own initiative. Hence: either read-only *and* proven effect-free, or gated
*and* supplied with a consequence renderer. "Unverified" is not a third state.

**4. Retry a call, not a tool.** *Capability:* a retry re-sends the identical
call, while another loop step lets the model send a **different** one — strictly
more capable. *Safety:* under injection, an automatic retry repeats an action an
attacker induced, with no new decision point; another loop step passes the
outcome back through the model and the guards. A model call is a pure request
whose failure is transport; a tool call may have had an effect already.

**5. A `safe` field.** A caller will branch on it as though it were an
authorisation, at which point a classifier that is free, deterministic and
fallible has become the gate. `InjectionReport` may tighten a decision and may
never grant one, and the enforcement is a raised exception at the call site.
Same shape as invariant 50 — a model arm over a mechanical decision may only
tighten it — with "model arm" replaced by "classifier".

## Concept checks

**6.0 — why deferred rows are in the manifest at all.** If a deferred
capability were simply omitted, the list would read as a complete description of
the system, and a reader would have no way to distinguish "Atlas does not have a
multi-agent supervisor" from "the author forgot to mention it". Deferral is a
decision that was made and costed; omission is indistinguishable from an
oversight. The verifier branch asserting that deferred rows name **no** entry
point, tests or tasks exists because the opposite failure is the one this module
is about: a row that admits the thing was not built while claiming evidence for
it would be the capability-with-no-mechanism defect committed in its own
confession. Section 6.0's three-step recipe follows from this — you clear
`appendix` and fill in the evidence **last**, because the row is what you earn.

**6.1 — why parse rather than import.** *Cost:* importing every test module runs
its import-time code, which in this repository builds indexes and opens
databases; parsing 60 files takes milliseconds, and a two-second gate is one
people run on every commit. *Safety:* importing executes arbitrary code from the
files under audit, so a verifier that imports can be affected by what it is
verifying — the same argument that keeps the reviewer syntactic.

**6.2 — ranges rather than a number.** "A single number from a single run on an
unnamed model is not a measurement; a range with its tier, seed and date says I
ran it more than once and watched it move." It rests on invariant 25 (a recorded
number carries its provenance) and invariant 73 (a number no target prints is an
opinion).

**6.3 — accepting `# noqa: BLE001 - reason`.** *Defence:* the rule exists to
force a **reason**, and six sites already had one in `noqa` form; demanding a new
dialect would make a human rewrite sixteen correct comments to say the same
thing, and the tool would be read as bureaucracy and switched off. *Cost:* the
exemption is loose — any comment with a dash and eight characters passes,
including a careless one. That failure direction is a false exemption rather
than a false finding, which is acceptable for a tool meant to stay on; if it
became a problem, the fix is a periodic human read of the EXPLAINED list, which
is printed for exactly that reason.

**6.4 — why steps 1–3 are not simply tests.** Step 2 is "read each function's
body for its own parameter names". A test can assert that a *specific* parameter
is used, but writing that test requires already suspecting the specific
parameter — which is the knowledge the step exists to produce. The general
version ("every parameter is referenced") has too many legitimate exceptions to
be a gate: interface conformance, framework-injected arguments, deliberate
forward compatibility. So it stays a human read, five minutes, no tooling. Steps
1 and 3 *have* partly become tests (the emitter tests, the wiring gate), and the
residue is the part where judgement decides whether a hit matters.

**9.5 / 6.7 — the audit log's mandatory subject.** *Engineering reason:* an
audit entry with no subject cannot be joined to anything — you can see that a
file was written and never who caused it, which makes the log useless at exactly
the moment you need it, during an incident. *Ethical reason:* an action taken on
a person's behalf, or affecting a person, must be attributable, because
attribution is what makes it contestable; an unattributed action is one nobody
can be held to and nobody can appeal. The ethical one is harder to preserve under
deadline pressure because it has no symptom — the system works perfectly without
it, the tests pass, the feature ships, and the cost arrives months later in a
conversation with someone who cannot find out why a decision was made about them.
That is why it is enforced by a `raise` rather than by a convention.

## Quiz (section 13)

**1. The credential.** Scope, drawn from an enumerated table on the server and
never from the client's request (prevents a caller granting itself more than the
task needs); an **audience**, so a token for service A cannot be replayed against
service B (prevents the confused-deputy attack — and this is the property people
omit, because an unaudienced bearer token works perfectly in every test);
a **lifetime ceiling in code**, not a caller-supplied expiry (bounds the damage
from a leak); and an attributable **subject**, so a refusal can name who was
refused. Over-permissioning is the only security defect whose symptom is that
everything works.

**2. Stateless MCP.** *Server author:* no connection-scoped handshake to
maintain, so a server is an ordinary HTTP workload that can sit behind any load
balancer, scale horizontally and be restarted freely; cross-call state becomes
explicit server-minted handles passed as ordinary tool arguments rather than
session memory. *Client author:* protocol version is negotiated per request
rather than once, routing headers must be set on every POST, and list results
carry cache hints the client is expected to honour — so the client gains caching
responsibilities it previously did not have. Current revision and SEP numbers are
in `VERSIONS.md`.

**3. 5,000 traces, one week.** Sample with a stated rule (do not hand-pick;
stratify by route and by outcome). Open-code a first pass without a taxonomy.
Cluster the codes and **count** them. Cost each fix. Choose, fix, and
**re-measure the same sample**. First, though: fix defects in the *instrument*,
because the grader, the checks and the tracer are upstream of the evidence you
would use to prioritise everything else — in this project, most failure-log
entries in the last seven phases were instrument defects, not agent defects.

**4. Four ASI entries.** *ASI01 goal hijack* → egress filtering of every rendered
output at one boundary plus the injection classifier; residual: the classifier
decides nothing and an adversary who rephrases passes it. *ASI02 tool misuse* →
registry-as-security-model, batch validation as a unit, approval gate with
consequence renderers; residual: a mislabelled `read_only` still grants three
things at once. *ASI03 identity and privilege abuse* → scoped, audience-bound,
short-lived tokens with permission tiers intersected with route scope; residual:
the default principal is permissive and says so. *ASI05 unexpected code
execution* → containerised executor, no network, no degraded mode; residual: the
container's own escape surface is not in scope. The full mapping is one section
per entry in `docs/THREAT_MODEL.md`.

**5. What the suite proves.** It proves Atlas's own code does what it says:
parsing, schema conformance, control flow, budget arithmetic, retrieval maths,
refusal paths, wiring. It proves **nothing** about model behaviour, because no
test asserts on model output — which is what lets it run in seconds with no
model. Model behaviour is measured separately in `docs/RESULTS.md` with tier,
model, seed and date, as ranges. The boundary is: anything downstream of a token
the model generated is data, not a test.

**6. A retrieved instruction.** Stop it at the **egress boundary** for anything
it might exfiltrate, and at the **tool registry and approval gate** for anything
it might do. Not the prompt, because prompt text is a request and an attacker
writes requests too; not the model, because you cannot test a model into
reliability. The specific answer this project learned: a control watching the
tool channel cannot see an exfiltration that uses the **answer** channel, so
every rendered output is filtered at one boundary every route passes through,
with an allowlist whose empty case denies.

**7. Liveness versus readiness.** Liveness failing means **restart me**;
readiness failing means **stop sending traffic, I am still here**. Conflating
them: wire a model-backend check into liveness, the backend slows down, and the
orchestrator restarts every container you have — removing capacity from a system
already struggling, and manufacturing the outage the probe was watching for. So
`healthz` checks nothing, `readyz` names each check it made, and neither ever
spends a model call.

**8. 71% to 80%.** Ask: over what sample, how many tasks, how many trials,
`pass@k` or `pass^k`, which model at which tier, and what the **minimum
detectable effect** is. At 40 tasks, a 9-point improvement is at or near the
noise floor, so the honest answer is that you cannot reliably detect the change
you are being asked to deliver; the first deliverable is a larger or better
suite, not a fix. Also ask what "accuracy" means here — the number usually hides
an abstention policy.

**9. When not to build an agent.** When the branch set can be **enumerated at
design time**. Then the control flow belongs in code, and the model's job is to
return a label. An agent buys you flexibility over an unenumerable decision
space and charges you an unbounded trajectory for it; if you can write the `if`,
write the `if`.

**10. The answer channel.** Twelve phases of guards inspect what the agent
*calls*. A poisoned document can instruct the model to embed the quarter's
figures in the query string of a zero-alt Markdown image, which the renderer
fetches automatically — no unexpected tool call, no budget exceeded, no gate
triggered, and the eval task passes because its check set has no negative half.
The defence is egress filtering at one boundary with a host allowlist that
denies when empty, refusing images even from allowed hosts because an image is
the only thing fetched without a human deciding to fetch it — and eval checks
that assert what must be **absent**, not only what must be present.

## Assignment 1 — reference approach

Structure: `CRITERIA` as a tuple of ten names matching `docs/PORTFOLIO.md`;
`LEVELS = (0, 1, 2, 3)`; `CriterionScore` as a Pydantic model with a validator
that raises on an unknown criterion and a `Field(ge=0, le=3)` on the level;
`Assessment` with `scores: list[CriterionScore]` and `total` as a **derived**
property surfaced through `model_dump()` — `extra="forbid"` makes
`Assessment(scores=..., total=99)` raise, which is what the hidden test checks.

The substance is the evidence function. For each criterion, decide what must
*exist* for each level, then check it. A workable ladder:

* **0** — the artefact is absent.
* **1** — the module or document exists.
* **2** — a test names it.
* **3** — a command fails when the claim stops being true.

So "capability honesty" reaches 3 only if `atlas/capabilities.py` exists, a test
file references `verify_capabilities`, and `verify_capabilities(root=root)`
returns zero unsupported. Assessing an empty directory must fall through every
rung to 0, which is what `test_every_level_is_reachable_and_evidence_decides_it`
asserts — a rubric that returns a constant is the failure this assignment exists
to prevent.

For `missing`, name the artefact rather than the deficiency: `"no test reaches
the orphan-root branch through the public tracer"`, not `"observability is
weak"`. The hidden test requires at least three words per item, which is a floor
and not a target.

**Common wrong turn:** reading a checklist file and trusting its ticks. A rubric
that trusts a flag scores what you claimed, which is the thing this entire phase
argues against.

## Assignment 2 — reference approach

Build the import graph by parsing. For each `.py` under `atlas/`, collect
`ast.Import` and `ast.ImportFrom` nodes, resolve module names to repository
paths, and store the edges. Seed the walk with the modules named by every
non-deferred capability's `entry_point`, then take the transitive closure.
`claimed` is the closure; `unclaimed` is everything else minus `INFRASTRUCTURE`
and minus modules whose filename starts with `_`.

Two details that matter. Handle **relative** imports (`from . import x`) by
resolving against the importing module's package — miss this and half the
package looks unreachable. And walk **function-local** imports too:
`atlas/graph/app.py` imports `make_plan` inside a closure, and a walker that
only reads module-level imports will report the planner as unclaimed, which is
the same class of blind spot invariant 67's corollary was written for.

`stale_exemptions` is `set(INFRASTRUCTURE) - set(all_modules)`, and it exists
because F-14-10 needed two tests: one that the gate fires, and one that the
exemption set has not become a list of things that used to be true.

`test_the_audit_does_not_import_the_modules_it_audits` monkeypatches
`importlib.import_module` to raise for anything under `atlas.`, so a solution
built on `importlib` fails even though it would otherwise be correct. That is
deliberate: the assignment is the version that does not import.

**Expected result on the shipped tree:** `unclaimed == []` and a small
`INFRASTRUCTURE` map — `atlas/config.py`, `atlas/llm.py`, `atlas/trace.py`,
`atlas/schemas.py`, `atlas/record.py` and similar, each with a reason of the
form "reached by every capability rather than any one of them".
