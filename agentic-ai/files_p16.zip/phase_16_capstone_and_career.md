# Phase 16 — Capstone Integration, Professional Practice, and Career Preparation

## 1. [core] Title and budget

| | |
|---|---|
| **Phase** | 16 — Capstone Integration, Professional Practice, and Career Preparation |
| **Weight** | light |
| **Study hours** | 7 total — 3 read / 2 build / 2 assess |
| **Compute time** | ~2 min. The only optional Tier A work is rehearsing your five-minute demo aloud against a real model |
| **Tier A calls per sweep** | **0.** Nothing this phase builds needs a model; `make demo` runs the whole capability set on scripted fixtures in about two seconds |
| **Tier H calls** | 0 |
| **Cost** | $0.00 |
| **Repo tag** | `phase-16` — and `v1.0`, the only tag in this book that names a release rather than a lesson |

There is no final exam. The assessment is the repository: Atlas at v1.0, its
eval report, and your `atlas-broken` write-up. An exam measures what you can
recall under time pressure, and nobody will ever ask you to do that again. A
repository measures what you can build and — more to the point — what you can
say truthfully about what you built, which is what this phase is about.

## 2. [core] Cumulative review

Five questions from Phases 13 and 14. Answers in `phase_16_solutions.md`.

1. A judge scores 87.5% raw agreement with your hand labels. Why is that number
   compatible with a judge that has learned nothing, and what do you compute?
2. Phase 14's red-team suite reported an attack success rate of 1.000 before the
   defences and 1.000 after. The defences worked. What was wrong with the suite,
   and what sentence must every attack now complete?
3. `read_only` on a tool grants three separate things. Name them, and explain
   why that makes a mislabelled tool worse than merely ungated.
4. Why does Atlas not automatically retry a failing *tool*, when it does retry a
   failing model *call*? Give the capability argument and the safety argument.
5. An `InjectionReport` has no field called `safe`, `blocked` or `verdict`, and
   a test asserts their absence. What would go wrong if one existed, and which
   earlier invariant is this the same shape as?

## 3. [core] Why this phase matters

Sixteen phases ago you had a `for` loop and an HTTP client. You now have a
system that answers questions over documents with citations, queries a database
over read-only SQL, searches a seeded web corpus, runs tools in a jail and in a
container, remembers people between sessions, plans research and fans it out,
stops to ask a human before it writes, acts as a named user with scoped
credentials, speaks MCP in both directions, grades itself, traces itself across
a process boundary, and serves the whole thing over HTTP with authentication
and streaming.

None of that is the hard part of this phase.

The hard part is that you are now going to describe it to somebody. To an
interviewer, to a hiring manager reading a README for ninety seconds, to a
colleague who inherits it, to a stakeholder deciding whether to fund it. Every
description is a *claim*, which means every description is something that can be
false — quietly, for months, while every test stays green.

You already know this. Invariants 41, 53, 58, 63, 72 and 81 are six statements
of one sentence: **a mechanism can be built, tested to 24/24, described in the
interface file, named in a summary, and called by nothing.** Each time, what
found it was a human reading a printed number beside a label — never the suite,
because the suite tested the mechanism rather than the claim.

A README is where that failure mode retires. It is the one document with no
test, written last, by the person least able to notice what is missing, and read
first by the person least able to check it. Open the one you have carried since
Phase 3: `Current tag: phase-03`, `389 tests`. Twelve phases stale, against an
actual 1,618, green the whole time.

So this phase makes the capability list **data**, renders the README's table
**from** that data, and fails a test when a claim has no evidence. It writes a
**code reviewer for agent systems** — seven syntactic rules, each tied to an
invariant this book paid for in failures — and runs it on Atlas, where it
immediately finds a defect ten phases old. Then it turns both outward: into a
review protocol for code an assistant wrote, into the four documents a
professional agent system ships with, and into the questions you will be asked.

There is a fourth thing, quieter. Somewhere in the last fifteen phases you
started using a coding assistant, as the book told you to. That was correct. It
also means an interviewer has no way to distinguish, from the artefact alone,
between a person who understands this system and a person who generated it.
Section 6.2 is about making that distinction legible — not by claiming it, which
anyone can do, but by shipping the two artefacts a generator does not produce.

## 4. [core] Learning objectives

By the end of this phase you will be able to:

1. **State every capability Atlas has as a testable claim**, bound to an entry
   point, at least one named test, and — where the claim is about behaviour — an
   eval task, and run `make capabilities` to verify all three exist.
2. **Explain what capability verification proves and what it does not**, in one
   sentence, without overstating it.
3. **Review agent code against eight areas** — prompts, tools, state, identity,
   safety, evals, observability, cost — using a checklist where each line names
   the invariant behind it and the command that checks it.
4. **Name the five defects that assistant-written agent code reliably
   contains**, say why each is invisible to a passing test suite, and detect
   three of them mechanically with `make review`.
5. **Run a review protocol on assistant-written code** in under twenty minutes,
   in an order that puts the instrument first.
6. **Write the four documents an agent system ships with** — README,
   architecture doc, system card, runbook — and say which reader each is for.
7. **Assess your own repository against a rubric** and identify, for every
   criterion below the top level, the specific missing artefact.
8. **Answer ten conceptual interview questions** on identity, MCP
   statelessness, error analysis and the ASI list.
9. **[extended] Swap Atlas's domain** and predict correctly which modules need
   editing before you edit any.
10. **Maintain a personal VERSIONS.md** and name the primary sources worth
    watching.
11. **State the four professional duties** an agent engineer carries — scope,
    disclosure of what the system refuses, other people's data, and honest
    accounting of assistant use — and point at the artefact in your own
    repository that discharges each.
12. **Run a demo that exercises every capability offline in about two seconds**,
    and explain why resolving an entry point is not exercising it.

## 5. [core] Prerequisites and quick recap

You need Atlas at `phase-15`, green:

```bash
make test-offline     # expect: all tests pass, 12 skipped
make evals            # expect: the full suite, Tier F
```

If that is not green, start again from `atlas_phase_15.zip`.

Four things carry directly into this phase.

**The wiring gate (Phases 14–15).** Phase 14 shipped a test asserting every new
public name had a call site — over a hard-coded list of five names, chosen
because they passed. Rewritten in Phase 15 to walk each new module, read
`__all__` and fail on anything with neither a call site nor a written exemption,
it found nine, one of which mattered: the containerised executor, the phase's
headline deliverable, registered nowhere while the capstone claimed it. This
phase generalises that gate from "names the phase added" to "claims the project
makes".

**Cluster B (Phase 13).** Your error taxonomy says the measuring instrument is
the largest single source of defects — five of fifteen entries, none about the
agent, holding for seven consecutive phases. The corollary is about order: fix
instrument defects first, because everything you would use to prioritise the
rest arrives through the instrument.

**Invariant 71.** A printed value beside its own label is a test the assertions
did not write.

**Scripted fixtures.** Everything in `tests/` runs against hand-written fixtures.
That proves parsing, schema conformance, control flow, budget arithmetic and
retrieval maths — the parts that are *yours*. It proves nothing about whether a
real model behaves well. Those claims live in `docs/RESULTS.md` with a tier, a
model, a seed and a date. When a hiring manager asks "how do you know it works",
the honest answer has two halves and you should give both.

## 6. [core] Core concepts


### 6.0 [core] The walkthrough: what you built, and where it lives

Before anything is checked, look at the whole thing once. Sixteen phases
produced one system, and a student who has only ever seen it a phase at a time
has never seen it.

```
                       HTTP  ──►  atlas/api/app.py        P15: auth, threads,
                                        │                  jobs, SSE. The subject
                                        │                  is resolved HERE.
                                        ▼
                                  atlas/api/service.py    P15: composition root
                                        │                  tracer + egress + principal
                                        ▼
                      ┌──────────  classify_route  ──────────┐   P5: label, never
                      │         model + keyword prior        │       a callable
                      ▼                                      ▼
            atlas/flow/app.py                        atlas/graph/app.py
            P5 hand-written handlers                 P9 compiled LangGraph
            (engine="flow", the default)             (engine="graph")
                      │                                      │
                      │   P10: approval gate, escalation ────┤
                      └───────────────┬──────────────────────┘
                                      ▼
                          atlas/tools/registry.py      P3: the security model
                                      │
        ┌──────────┬──────────┬───────┴───────┬──────────┬─────────────┐
        ▼          ▼          ▼               ▼          ▼             ▼
   calculator   clock    files (jailed)   query_db   search_web   run_python
      P3         P3           P3            P7          P3       P14 container
                                      │
                                      ▼
                          atlas/mcp/tools.py  ──►  P12: another team's server,
                                                   called as the user
```

Around that spine sit four things that are not on the request path and are the
reason it works: `atlas/rag/` (P6–P7, retrieval and grounded generation),
`atlas/memory/` (P8, cross-session memory, context budget, skills),
`atlas/safety/` and `atlas/auth/` (P12, P14, permissions, egress, audit, scoped
tokens), and `atlas/obs/` (P15, spans and metrics).

**The repo tour, by the phase that built it.** Read this column downwards once;
it is the book's table of contents seen from the outside.

| Path | Phase | What it owns |
|---|---|---|
| `atlas/config.py` | 0 | every environment read in the process |
| `atlas/llm.py` | 1–2 | every model request built in the process |
| `atlas/agents/` | 1, 3, 4 | the minimal loop, ReAct, plan-and-execute, the critic |
| `atlas/tools/` | 3, 7, 14 | registry, jail, calculator, clock, SQL, sandbox |
| `evals/` | 3, 13 | the harness, the task suite, the judge, the gate |
| `atlas/flow/` | 5 | routing, handlers, fan-out, cost accounting |
| `atlas/rag/` | 6–7 | extraction, chunking, hybrid index, grading, generation |
| `atlas/memory/` | 8 | memory store, context assembly, skills |
| `atlas/graph/` | 9–10 | the compiled engine, approval, escalation |
| `atlas/mcp/`, `atlas/auth/` | 12 | server, client, scopes, tokens |
| `atlas/safety/` | 14 | permissions, egress, trust, audit, reliability |
| `atlas/obs/`, `atlas/api/` | 15 | spans, export, metrics; HTTP, SSE, health |
| `atlas/capabilities.py`, `atlas/review.py`, `atlas/demo.py`, `atlas/domain.py` | 16 | the project's claims about itself |

**`ATLAS_INTERFACES.md`, the contract.** One section per module, in the order
the modules were built, plus three things a reader should know exist: an
**Interface changes** table per phase with migration notes, a numbered
**Invariants** list (99 of them, each traceable to a failure that bought it),
and a list of the **documents that are part of the contract**. When you change
anything, this file is what you read first and edit last.

**What is deliberately absent, and how to add it.** Eight capabilities were
designed, costed and not built. They are rows in `atlas/capabilities.py` with an
`appendix` set and no entry point — CodeAct (F.1), a text-to-SQL agent (F.2), a
retrieved tool registry (F.3), time travel and map-reduce (F.4), a multi-agent
supervisor (F.5), online evaluation with simulated users (F.6), a browser tool
(F.7), a second-framework port (F.9). Each is a self-contained build on a branch
off the tag of the phase that discussed it.

Adding one is three steps, in this order:

1. **Branch off the tag**, so the thing you are comparing against still exists.
2. **Build it, with its tests and at least one eval task**, exactly as a phase
   would have.
3. **Change its manifest row last**: clear `appendix`, fill in `entry_point`,
   `tests` and `eval_tasks`. `make capabilities` will refuse the row until all
   three exist, which is the point — the row is the last thing you earn, not the
   first thing you write.

> **Concept check 6.0.** The deferred rows carry a claim sentence but no entry
> point, and a verifier branch asserts they name no evidence at all. Why is that
> branch necessary — what would go wrong if a deferred row were simply omitted
> from the manifest?

### 6.1 [core] A capability is a claim, and a claim is something that can be false

Two sentences you can write about software look identical:

> *Atlas answers questions over internal documents with citations.*

> *`atlas/rag/generate.py` contains a function that produces an answer object
> with a citations field.*

The second is about the code and is true if the file exists. The first is about
the **system** — it asserts that a request arriving at Atlas's front door, from
a user who did nothing special, reaches that function, and that what comes back
carries citations that resolve. The second can be true while the first is false,
and this book has documented that gap six times.

The gap has a name: **wiring**. But "wiring" undersells it, because a mechanism
can be wired and still not be a capability. Phase 8's memory retrieval had two
gates that were wired, tested, and *could not fire* — one a literal `False`, the
other computed against the very constant that had already filtered away its own
trigger — while the interface file, the results file and a tool's help text all
described them as protection.

So a claim needs evidence, in three kinds that prove three different things:

| Evidence | Proves | Does not prove |
|---|---|---|
| An entry point that imports and resolves | the thing a caller reaches exists, under the name you published | that it does anything |
| A named test | somebody wrote down what it should do, and a machine checks it | that the test is good, or that the path is reachable from the front door |
| An eval task | a real request, through the real composition, produced a gradeable outcome | that a model will behave this way tomorrow, or on your data |

None is sufficient. Together they are the most you can get cheaply — and **all
six historical wiring failures would have been caught by the weakest of the
three**, because in every case the evidence did not exist at all.

**Misconception: "a green capability report means the system works."** It does
not. A green report proves every claim is *attached* to something that exists
and is named. The honest bound is narrow and still worth having, because the
failures it catches are total absences, and total absences are exactly what
nobody notices.

**Concept check 6.1.** Why does the verifier parse the test files with `ast`
rather than importing them and reading `dir()`? Two reasons — one about cost,
one about safety.

**The measurement.** I wrote the manifest from memory — 44 claims, covering
sixteen phases I had just finished building. The first run reported **fifteen
unsupported**. Two were Phase 16's own rows. The other thirteen named evidence
that did not exist: eleven wrong test names, two wrong entry-point attributes,
one task id with a doubled letter. Every one would have gone into a README as a
confident sentence, and none would have failed a test.

### 6.2 [core] What a portfolio is evidence *of*

An interviewer is answering one question: **did the understanding precede the
artefact, or follow it, or never happen?** A person who used an assistant and
understood every line produces the same diff as a person who used one and
understood none of it. Good interviewers have stopped trying to detect assistant
use — it is universal and tells them nothing — and look instead for artefacts
that generation does not produce. There are two.

**The failure log.** An assistant will not write you a truthful failure log,
because it does not know which of its outputs were wrong. A failure log is a
record of surprise; surprise requires an expectation; an expectation requires
understanding. Read F-11-01 with an interviewer's eyes: a broad
`except Exception: return []` was the correct response to an unplannable request
*and* swallowed an `ImportError` that made every request unplannable. Nothing
raised, nothing logged, 1,306 tests green, and the route had never once planned
anything. That paragraph demonstrates exception scope, correct error handling as
a hiding place, and why a green suite is not evidence.

**The `atlas-broken` write-up.** Phase 13's exercise. The failure log shows you
noticed a defect you did not expect; the write-up shows you can locate one you
do.

**Misconception: "I should hide that I used an assistant."** No. What you should
be able to do is say precisely what you delegated, what you did not, and why —
which every phase's "With an assistant" note has been teaching. "I wrote the
retrieval maths and budget arithmetic unaided because getting them subtly wrong
is silent; I delegated the FastAPI boilerplate and reviewed it against
`docs/REVIEW_CHECKLIST.md`" is a *better* answer than "I wrote it all myself",
and it is checkable.

**Concept check 6.2.** `docs/RESULTS.md` reports ranges rather than single
numbers. A hiring manager might see that as hedging. Give the one-sentence
defence and name the invariant it rests on.

### 6.3 [core] Five things assistant-written agent code gets wrong

The defects are not syntax errors or hallucinated APIs — those are visible. They
are **shapes**, and they share one property: the system works when you run it.

**One: silent broad exception handling.** `try: ... except Exception: return
None` is defensive, reads as careful, and makes the demo not crash. It converts
a programming error into a business outcome. The tell is not the `except` — it
is the absence of a re-raise *and* of any use of the exception.

**Two: missing budgets.** A loop that terminates on the model saying it is
finished is not a bug in any test, because in every test the scripted model says
it is finished. A `while` with a model call inside it is an unbounded spend, and
it will be found in production by a bill.

**Three: tool schemas that lie.** Two descriptions of one shape — a signature
with type hints, and a hand-written JSON Schema beside it — agreeing on the day
they are written.

**Four: tests that assert on fixtures rather than behaviour.** The subtlest.
F-06-02: the first `pre_check` tested `report.empty`, a condition a brute-force
dense retriever can never produce. The mechanism passed its own tests and was
wired to an impossible condition. The tell: if a test constructs the input
object literally, it is testing the function; if it reaches the function through
the composition callers use, it is testing the system.

**Five: credentials passed too far.** Each hop individually reasonable; the
result is a secret in the signature of a retriever, a chunker, a planner.

**Misconception: "an assistant would not make such basic mistakes."** None is
basic. Every one is a *defensible general policy* applied where a specific one
was needed. Invariant 59: a framework standardises mechanism, never policy, and
every policy you can name has a line of somebody's code deciding it. An
assistant is a policy-choosing machine with no access to your requirements.

Three of the five are syntactic, which means a program can find them.

**Concept check 6.3.** The `broad-except` rule accepts a reason written as
`# noqa: BLE001 - a renderer needing arguments we lack` as readily as
`# review: broad-except -- <reason>`. Defend that, then state its cost.

### 6.4 [core] A review protocol, in the order that matters

A checklist with forty items is a checklist nobody finishes. The order does most
of the work.

**Step 0 — run the instrument first.** `make review`, `make capabilities`,
`make check-docs`. Two minutes, no reading. Cluster B's corollary: defects in the
measuring apparatus are upstream of the evidence you would use to prioritise
everything else.

**Step 1 — read the closed sets.** For every `Literal` member, find the line in
production code that sets it. Five minutes; finds F-15-09's `approval` event
kind, validated by the parser, constructed by the tests, emitted by nothing.

**Step 2 — read each new function's body for its own parameter names.**
F-15-07: `serve_scenario(scenario=...)` documented three scenarios, ran one,
three eval tasks green.

**Step 3 — grep every public name for a call site on the default path.**

**Step 4 — now read the logic.** By now you know the claims are real, the
branches reachable, the parameters read and the names called. Everything from
here is about correctness, which is the only question a human is uniquely good
at.

**Concept check 6.4.** Steps 1–3 are mechanical and each takes five minutes. Why
are they not simply tests? Answer for step 2 specifically.

### 6.5 [core] Documentation is an interface, with four readers

**README — for someone deciding whether to look further, in ninety seconds.**
*What is this and does it work?*

**Architecture doc — for the engineer who inherits it.** *Where do I make a
change, and what will it break?* Including the decisions considered and
declined, with the measurement that would reverse them.

**System card — for whoever signs off on deploying it.** *What does it do, to
whom, with what data, and what happens when it is wrong?* Including residual
risks that were *accepted* rather than mitigated.

**Runbook — for whoever is paged at 3am.** *It is broken, what do I do?*
Symptom-first: the reader knows what they are seeing and not what it is called.

**Misconception: "the README should be comprehensive."** Its job is to be
correct in ninety seconds, not complete. The one you are carrying is
comprehensive and wrong.

### 6.7 [core] Ethics and professional responsibility

This is the shortest section with the longest consequences, so it is concrete
rather than aspirational. Four duties, each with the thing you actually do.

**You are responsible for what the system is pointed at, not only for how it
works.** Atlas is a good system and a bad fit for deciding who gets a loan, who
is investigated, or which employee is managed out. The property that decides it
is not accuracy — it is **whether the person affected can contest the output**.
A research assistant answering a staff question wrong wastes twenty minutes; the
same machinery scoring a person produces a decision they cannot see the reasons
for. `docs/SYSTEM_CARD.md` has an *Out of scope* section for this, and writing it
is your job even when nobody asks.

**Report what the system refuses, as loudly as what it does.** Atlas abstains.
The abstention rate is the number that decides whether people trust it, and a
stakeholder who learns about abstention from a user experiences it as a defect
rather than a design. Put it in the first summary, not the appendix. The same
goes for accepted residual risks: `docs/THREAT_MODEL.md` numbers the risks that
were *accepted rather than solved*, and the hardest professional habit in this
book is keeping that list visible after the launch that made everyone happy.

**Other people's documents are in your corpus.** Every RAG system ingests things
written by colleagues who did not consent to being a training or retrieval
corpus, and some of it is about them — performance notes, medical absences,
grievance threads. Two practices: ingest by **allowlist** rather than by crawling
a share, and make deletion real, which means deleting the chunks and the
embeddings and the memory store's derived facts, not the source file. Phase 8's
memory gate exists for this reason and it should be read as an ethical mechanism,
not only a quality one.

**Disclose assistant use accurately, in both directions.** Overstating what you
wrote is dishonest. Understating it is also a failure, because the person
reviewing your code needs to know which parts had a second pair of eyes and which
had none. The professional form is specific: what you delegated, what you did
not, and the check you ran over the delegated part. If you cannot say that
sentence about your own repository, that is information about the repository.

> **Concept check 9.5.** Atlas's audit log refuses to be written without a
> subject. Give the engineering reason and the ethical reason, and say why the
> ethical one is the harder of the two to preserve under deadline pressure.

### 6.8 [core] Staying current, and a personal VERSIONS.md

Everything technical in this book has a half-life. The practice that survives it
is the one you have been following since Phase 0: a **current-state fact never
appears in prose, only in a table with a source and a checked-on date**.

Copy the format, not the contents. Four columns — fact, value, source URL,
checked-on — and one rule: re-verify before you start anything. When a row turns
out to be stale, write down what it cost you; that note is what turns a
maintenance chore into a habit you keep.

The Phase 16 delta is a worked example of it paying off. Everything pinned in
earlier phases re-verified unchanged, and the MCP specification revision was the
same one Phase 12 checked — but the maintainers had published a **new roadmap
after that check**, which is precisely the class of change that breaks nothing
today and breaks your client next quarter. Sources worth watching, with what each
is good for, are in `VERSIONS.md`.

### 6.9 [extended] What this book could not teach you

**Production traffic.** Everything measured ran against a seeded corpus. The
first week of real traffic will invalidate several things you believe. What the
book gave you is the flywheel: traces become eval tasks, and that works
unchanged on real traffic.

**Frontier-model behaviour.** Tier A is a laptop model.

**Scale.** Atlas serves one process; most of what changes is ordinary
distributed-systems engineering.

**Cost at volume.** Every figure is $0.00 outside Appendix B. The arithmetic is
right; the rate card is a placeholder that says so.

**Organisational failure.** Section 10; most of the reasons are not technical.

## 7. [core] Hands-on: making the claims checkable

Five steps. The first two are the core, about ninety minutes; steps 3 and 4 are
writing; step 5 is `[extended]`.

### Step 1 — the capability manifest

Start with the data rather than the code.

```python
# excerpt: atlas/capabilities.py
class Capability(BaseModel):
    """One sentence Atlas is allowed to say about itself, plus its evidence."""

    model_config = {"extra": "forbid", "frozen": True}

    id: str
    phase: int
    claim: str
```

Four decisions. **`claim` is written in the second person, as a user would
describe it** — a claim phrased as a module name ("has a retrieval subsystem") is
true if the directory exists, which makes it unfalsifiable and worthless as a
claim. **`entry_point` names the public door, not the worker** (invariant 58).
**`frozen=True`**, because the manifest has three readers. And **`appendix`
makes the deferred builds first-class rows** — Appendix F's eight deliverables
are *in* the manifest with no entry point, no tests and no tasks, and a verifier
branch asserts exactly that. A capability list that silently omits what was not
built reads as a complete system.

Then the verifier:

```python
# excerpt: atlas/capabilities.py
def _test_functions(path: Path) -> set[str]:
    """Every `def test_*` in a file, found by parsing rather than importing.

    Importing a test module to check a name exists would run its import-time
    code, which for this repository means building indexes and opening
    databases. Parsing costs nothing and cannot be affected by what it reads.
    """
```

It never runs a test or a task, and a test monkeypatches `subprocess.run` and
`subprocess.Popen` to raise, so the bound is asserted rather than intended.
Verification takes about two seconds; a gate that took two minutes is a gate
people run once.

**Your turn.** Before reading further, predict your own error rate. Write the
manifest for five capabilities you built in Phases 6–8 without looking anything
up, then run the verifier. The number is the exercise.

### Step 2 — the reviewer

Seven rules over the syntax tree, with one constraint: **no imports, no
execution, no model.** A reviewer that runs the code under review can be
attacked by it — and the code under review, in a real workflow, is code an
assistant just generated from a prompt that may contain a retrieved document. A
reviewer that needs a model costs money per commit and finds different things on
different days. The price is that these rules find shapes, never semantics.

```python
# excerpt: atlas/review.py
RULES: dict[RuleId, str] = {
    "broad-except": (
        "a broad `except` that neither re-raises nor uses the exception turns a "
        "programming error into a business outcome (invariant 67, F-11-01)"
    ),
```

Each rule cites its invariant, and each invariant cites the failure that bought
it. A rule justified by "best practice" is a rule someone will argue with; a
rule justified by F-11-01 is a rule with a receipt.

The exemption design is what makes it usable. A finding is answered by a comment
carrying a *reason clause*:

```python
# excerpt: atlas/review.py
_REASON = re.compile(r"(?:^|\s)-{1,2}\s*(\S.{7,})")
```

The rule accepts `# noqa: BLE001 - <reason>` exactly as readily as
`# review: broad-except -- <reason>`. **The point is the reason, not the
marker.** Atlas already had six broad-except sites, each carrying a written
justification in `noqa` form; a rule insisting on its own dialect would have made
a human rewrite sixteen correct comments, and the reviewer would have been
judged — correctly — as bureaucracy. The cost is a slightly loose exemption. That
failure direction is a false *exemption*, never a false finding, which is the
right way round for a tool meant to stay switched on. A bare `# noqa: BLE001`
exempts nothing.

One concession, forced by a failing test: a broad `except` is usually explained
above the `try`.

```python
# excerpt: atlas/review.py
    `others` are additional anchor lines to try. Exactly one rule uses it:
    a broad `except` is usually explained above the `try` it belongs to,
    because the sentence is about the whole construct rather than the clause.
```

**Then run it.** 142 files, sixteen phases: seven unexplained findings. Six were
judgements and got reasons written down. The seventh was a defect — section 8.

The gate is one test:

```python
# excerpt: tests/test_review_phase16.py
def test_atlas_has_no_unexplained_findings():
    report = review_paths(
        [REPO / "atlas", REPO / "evals", REPO / "scripts"], root=REPO
    )
    assert report.unexplained == [], render_report(report)
```

Plus seven positives from a committed bad sample and seven near misses, one per
rule (invariant 68's quantifier). The near-miss table doubles as the fix list.

The sample lives at `tests/fixtures/review_bad_agent.py.txt` — `.txt` because a
file ending in `.py` under `tests/` is one somebody's tooling eventually imports.
Writing it produced the phase's most embarrassing bug: each block was labelled
`# rule: broad-except -- a programming error becomes a business outcome`, and
**the reason clause in the label exempted the finding it was labelling.** The
generalisation: when a tool reads comments, comments about the tool are inputs to
the tool.

### Step 3 — the four documents

Write them in the order README, architecture, system card, runbook — each is
harder than the last to be honest in.

The README's capability table is a rendering between two HTML comment markers,
not a fully generated file: a generated README is one nobody edits and therefore
nobody reads. Everything outside the markers stays hand-written, including the
sentence most portfolios omit — *What Atlas is not*.

Two tests hold it to reality: one fails on table drift, one parses the Makefile's
`.PHONY` line and asserts every `make <target>` the README names exists. The
second fired immediately.

**A worked example.** Here is the whole opening of Atlas's README — the part a
hiring manager reads before deciding whether to scroll:

```markdown
# Atlas — a research and operations assistant, built from scratch

Atlas answers questions for a small company: over its internal documents with
citations, over its database in read-only SQL, and over the web — calling
tools, remembering people between sessions, pausing for a human before anything
consequential, and grading itself.

**Current tag: `v1.0` (`phase-16`).**

## Quick start

    make test-offline     # the whole suite: no network, no model, no .env
    make capabilities     # every claim below, checked against its evidence
    make review           # the source, against docs/REVIEW_CHECKLIST.md
    make demo             # every capability exercised, offline, ~2 seconds

Nothing above needs a model, a key or a network.
```

Four things that paragraph does. It says what the system does **for a person**,
not what packages it contains. It puts runnable commands above the fold, and
they run on a clone with no setup — which is the single highest-value property a
portfolio README can have, because it converts a sceptical reader into a reader
who has seen it work. It states the tag, so nothing is ambiguous about which
version the claims describe. And it ends the section on a limitation ("nothing
above needs a model"), which reads as confidence rather than hedging because it
is specific.

Further down, after the generated table, the section most portfolios omit:

```markdown
## What Atlas is not

It has never seen production traffic. Every corpus is generated from a seed.
Every measurement is on a laptop-scale model unless `docs/RESULTS.md` says
otherwise. The deferred table above is honest: those capabilities were
designed and costed and deliberately not built.
```

An interviewer who reads that knows two things about you in four sentences, and
neither can be faked by a generator: you know what you did not do, and you are
willing to write it down where it costs you.

### Step 4 — the review checklist

`docs/REVIEW_CHECKLIST.md`, eight areas, each line naming its invariant and,
where one exists, the command that checks it. Three kinds of line: checked by a
rule `[auto]`, checked by a printed output you read `[printed]`, checked by
nothing but your eyes `[human]`. Marking which is which tells a reviewer where
to spend the twenty minutes.

### Step 5 — the demo that actually demos

`make demo` must **exercise** every capability, not resolve its name. My first
version printed, per capability, whether its entry point imported — which is
`make capabilities` with a different heading, and which would print a green line
for a function whose body is `raise NotImplementedError`.

`atlas/demo.py` splits the work the way the manifest forces:

* A capability naming **eval tasks** is demonstrated by running them. Those
  tasks already reach the mechanism through the composition a caller uses — that
  is what makes them eval tasks rather than unit tests — so writing a separate
  demonstration beside them would be a second, worse copy of the same call.
* A capability naming **no eval task** needs a written probe. There are four,
  and a test asserts that `set(DIRECT_PROBES)` equals
  `CapabilityReport.ungraded` exactly. Add a fifth ungraded capability and the
  demo fails until somebody writes its probe — without that, an ungraded
  capability would quietly drop out and the demo would still say "every
  capability".

Each step reports an **observation**, not a verdict: `"2 event(s), terminal kind
'done'; a newline inside the payload did not forge a frame boundary"`, not
`"passed"`. A test enforces it (at least five words, and not one of `passed`,
`ok`, `green`), because a viewer should read what happened.

Two things this cost, both instructive. Wiring it without the harness's
`judge_factory` made `judged-evaluation` the single red line — a demo that
composes the suite differently from the way the suite composes itself is
demonstrating a system nobody runs. And giving the demo its own capability row
made it run its own eval task, which calls the demo: infinite recursion, which
presents as a **hang** rather than a stack trace and cost 300 seconds to notice.
The exclusion is one named constant with a paragraph beside it, not a filter on
entrypoints — a filter would silently absorb the next self-reference somebody
writes.

```
36 capabilities exercised (32 through the eval suite, 4 by direct probe)
ok  document-qa   answer questions over internal documents and cite the extract...
      2/2 eval task(s) passed through the public composition
ok  scoped-credentials   act on behalf of a named user with a short-lived...
      token for 'priya' carries 1 scope(s); replay against another audience refused: True
```

### Step 6 — [extended] the domain swap

```python
# excerpt: atlas/domain.py
DOMAIN_BOUND_EXPECTED: dict[str, str] = {
    "atlas/domain.py": "the glossary itself: this module names the old domain in order to find it",
```

`domain_bound()` searches `atlas/` for the shipped domain's proper nouns over
source *text*, not an import graph, because the leaks worth finding are in
prompts, docstrings and tool descriptions. Ten files name it; nine are prompt
text, tool descriptions or docstring examples, and the tenth is
`atlas/domain.py`, which names it in order to find it.

A domain contributes **three** things and they fail differently. The corpus is
what retrieval reads. The database is what read-only SQL reads, and its relation
*names* are the part that leaks into prompts. The skill is a procedure written in
English about this domain's work, and it is the piece most likely to be silently
wrong after a swap — because it still parses, still loads, and still describes
the previous company's quarter-end.

So `swap_report()` opens all three: BM25 over the corpus, a **read-only** SQLite
connection listing tables and views, and `load_skill_catalogue` over the skill
directory so a malformed `SKILL.md` fails at the swap rather than at the first
request that needed it. My first draft declared `db_path` and `skill_dir` and
read neither — two fields with no reader (invariant 40), in the phase about
claims with no evidence.

No model and no embedder anywhere, because a demonstration that needs a model is
one a reader without one cannot check. `code_edits_required: 0` means the
retrieval path is domain-free. It does **not** mean a swap is free: the ten exempted files are the
work, and naming them honestly is the answer to "how portable is this?", which
is a question about whether you know where your own coupling is.

### Step 7 — the portfolio review (this replaces the final exam)

Work through `docs/PORTFOLIO.md` at the keyboard, not in your head.

1. **Score yourself 0–3** against the ten criteria. The ladder is the same every
   time: 0 absent, 1 present but undemonstrated, 2 demonstrated once by hand, 3
   demonstrated by something that **fails when it stops being true**. For every
   score below 3, write the specific missing artefact — "no test reaches the
   orphan-root branch through the public tracer", not "observability is weak".
2. **Rewrite the README's opening** until a stranger could tell, in ninety
   seconds, what Atlas does and whether it works. Step 3 has the worked example.
3. **Write the five-minute demo script**, in this order: one grounded answer
   with a citation you resolve live; one **abstention**; one gated write,
   **refused**; one trace crossing into the MCP server; `make capabilities`.
   Then stop. The abstention and the refusal are the two that land, because
   anyone can demo a success.
4. **Decide what to show and what to omit.** Show `pass^k` over trials with `n`,
   per suite, with the date and the model; the worst criterion, not the mean;
   the abstention rate; the minimum detectable effect beside any delta. Do not
   show a single headline accuracy, a benchmark you did not run, a latency
   figure with no tier, or a percentage with no denominator.

**Why ranges beat a number**, since someone will ask: a single number from a
single run on an unnamed model is not a measurement, and everyone qualified to
hire you knows it. A range with a tier, a seed and a date says you have run the
thing more than once and watched it move. That is the difference between a
result and a screenshot.

### With an assistant

**Safe to delegate.** The near-miss table — seven small correct samples, verified
by a parametrised test that fails loudly. The `render_*` functions, whose output
is pinned. The prose scaffolding of the architecture doc, from your outline.

**Not safe to delegate.** The rule bodies, because a rule with a subtly wrong
predicate produces a *clean report*, indistinguishable from a working reviewer
until a defect ships. The capability manifest, for the reason step 1 measured.
And the exemption *reasons* — delegating a judgement about your own code to the
thing that wrote the code is a review protocol with a hole in it exactly where
the review goes.

**A prompt that works:**

> Here is `atlas/review.py` and its rule table. Write me one Python snippet per
> rule that has the same silhouette as the rule's target but must NOT trigger it
> — the correct way to write the thing the rule objects to. Do not write the
> tests; I have a parametrised test that will consume them. For each, state in
> one sentence why it is a near miss rather than a clean unrelated sample.

The last clause is the useful one: a near miss sharing no structure with the
positive proves nothing.

## 8. [core] Debug this trace

Not an agent trajectory — the reviewer's output, which is the trace this phase
produces.

```
reviewed 139 file(s): 7 unexplained, 6 explained

UNEXPLAINED — each needs a fix or a reason comment
  atlas/rag/hosted.py:61  [env-outside-config] os.environ outside atlas/config.py
      configuration enters the process in exactly one module; anywhere else is
      a setting no test can inject and no operator can find (invariant 4)
  atlas/rag/hosted.py:62  [env-outside-config] os.environ outside atlas/config.py
  atlas/rag/hosted.py:63  [env-outside-config] os.environ outside atlas/config.py
```

Three lines in a module first written in Phase 6 and untouched since:

```python
self.model_id = os.environ.get("ATLAS_TIER_H_EMBED_MODEL", "")
self.base_url = os.environ.get("ATLAS_TIER_H_BASE_URL", "")
self.api_key  = os.environ.get("ATLAS_TIER_H_API_KEY", "")
```

**First diagnosis — the invariant violation.** Invariant 4 says no module
outside `atlas/config.py` reads `os.environ`. This one does, three times.

**Second diagnosis.** Read the constructor's first parameter. It takes a
`Settings` object and never uses it. Then read the module's own docstring,
unchanged since Phase 6: *"They are read from `Settings` here so that changing
provider is a `.env` edit, not a code edit."* The comment names the
responsibility; the code does the opposite. Invariant 82, in the module that
documented it.

**Third diagnosis — the user-facing bug.** Grep the three names. They appear in
no `Settings` field, no `.env.example` row and no `VERSIONS.md` row. What
`Settings` carries is `h_base_url` from `ATLAS_H_BASE_URL` and `h_api_key` from
`ATLAS_H_API_KEY` — the names in `.env.example`. **Tier H was configured twice,
under two disjoint sets of names.** A reader who filled in `.env.example`
correctly was told to set three variables that did not exist. Ten phases, 1,618
green tests.

**Why nothing caught it.** Nothing offline constructs a `HostedEmbedder`. And the
one test that touched it called `HostedEmbedder(None)  # type: ignore[arg-type]`
and passed, *because `settings` was never read*. The `type: ignore` is the tell.

**The fix.** `Settings` gains `h_embed_model`; the embedder reads all three from
`Settings`; the stale `import os` goes; `.env.example` gains the row; the error
names variables that exist. Two tests: the old one rewritten to pass a real
`Settings`, and a new one asserting no `ATLAS_TIER_H_*` name survives and that
one set in the environment is ignored.

**What generalises.** A configuration key is a name shared between code, a `.env`
file, a docs table and a person, and nothing type-checks a shared name. The only
thing that finds a second, undocumented door is something reading the source for
the shape.

## 9. [core] Common pitfalls

**Writing the capability list from memory.** Thirteen of forty-two wrong.
Professionals write the row *when they build the thing*, which is why
`Capability` carries a phase number.

**A rule that fires on everything.** The fastest way to kill a reviewer is a
noisy first run. `model-id-literal` is deliberately narrow and will miss ids that
look like ordinary words. A rule that fires on everything is a rule someone
disables, which is worse than never writing it — now the invariant has a disabled
guard standing in for it.

**Treating a green report as a working reviewer.** A broken predicate produces a
clean report. The eval task grades both halves for that reason, which is
invariant 77's shape.

**Confusing the four documents.** The commonest failure is a README trying to be
the architecture doc.

**Publishing a single number.** A single number from a single run on an unnamed
model is not a measurement, and the person who knows that is visibly not the
person who generated the repository.

**Adding a mechanism to the set it measures without asking what happens on the
diagonal.** The demo got a capability row; the row named an eval task; the task
ran the demo. Infinite recursion presents as a **hang**, not a stack trace, so
the only signal was a 300-second timeout with no output. Any time a gate becomes
one of the things it gates, work the self-reference out on paper first.

**Assuming the gate you built covers the work you did this phase.** Six of this
phase's eleven failure-log entries were found by reviewing the phase against its
own block *after* it was written, and every one was a claim the phase made about
itself that the phase's own gates did not yet point at. A gate is only ever
pointed at what you remembered to point it at, which is why section 6.4 is an
order rather than a tool.

**Letting the exemption set become a dumping ground.** Both gates are enumerated
*with reasons*, and a second test asserts no exemption names something that no
longer exists.


## 10. [extended] Industry perspective

### How agent teams are organised

Four roles, rarely four people. The **agent engineer** owns the loop, tools and
state. The **evaluation owner** owns the suite, judge calibration and the
regression gate — a named person on any team that has been burned once, because
an eval suite with no owner decays into one everybody overrides. The **domain
expert** owns the corpus, the labels and the definition of "correct", and is
usually not an engineer; the highest-leverage thing an agent engineer does is
make the labelling loop cheap enough for them to use. The **platform or SRE
owner** takes the pager, owns the runbook, and will ask the section 6.5 questions
before your service gets an endpoint.

### The lifecycle, and where it goes wrong

**Discovery → prototype → eval → pilot → production → iteration.**

The prototype takes a week and works. Agent demos are unusually easy and agent
products unusually hard, and the gap is entirely in the tail: a demo needs one
path to work once; a product needs every path to fail legibly.

The transition that kills projects is **prototype → eval**, because it is the
first point at which the project can be told it is not working. Teams skip it by
moving to pilot with "we'll gather feedback", and what they gather is anecdotes —
which cannot be regressed against, so the fifth fix silently breaks the second.

**Estimation.** The loop is a week, the evaluation is a month, the tail is a
quarter. Then double the tail. Phases 13–15 were half this book because tail work
is more than half the calendar.

**Stakeholder communication.** Give a range, never a number. Report the worst
criterion, not the mean. Report what the system refuses to do as a feature,
early — a stakeholder who learns about abstention from a user thinks it is a bug.

**Why agent projects fail**, in rough order: no owned eval suite; a use case
where being wrong 5% of the time is unacceptable and nobody said so; unbounded
cost discovered in month three; an integration needing credentials nobody would
grant; and a capability that was demoed, believed, and never wired.


**Why agent projects fail, in more detail**, because this is the section
students find least concrete and it is the one that decides careers.

*No owned eval suite.* Not "no evals" — an unowned suite. Someone writes one,
it decays, a release is blocked by a task nobody understands, the task gets
deleted, and within two quarters the suite is a formality. The fix is a named
person and a rule: a task is deleted only with a written reason in the same
commit.

*Being wrong is unacceptable and nobody said so.* Discovered in pilot, when a
user forwards an incorrect answer to someone senior. The question that would have
caught it is asked in week one: "what happens when this is wrong, and who finds
out?" If the answer is "a person is harmed and nobody finds out", stop.

*Unbounded cost in month three.* Usually a retry loop or a fan-out whose width
depends on model output. Both are prevented by the same discipline: the width and
the depth of every loop are values you can print.

*Credentials nobody would grant.* An integration is designed assuming access that
security will refuse, and the refusal arrives after the architecture depends on
it. Ask for the scopes in week one, in writing, and design for what you are
actually given.

*A capability demoed, believed and never wired.* This book's own most frequent
failure, six times, and the reason section 6.1 exists.

### What interviewers are actually testing

The ten questions are in section 13, with model answers in the solutions file,
and the full bank of thirty plus the system-design prompts is Appendix F.8. What
is worth saying *here* is what the questions are for, because knowing that
changes how you answer them.

An interviewer asking "what does your test suite prove?" is not checking whether
you can describe pytest. They are checking whether you know the **boundary** of
your own evidence — and the answer that lands has two halves, because a candidate
who gives one half has usually never run a real eval. An interviewer asking about
credentials is checking whether you have ever had to refuse someone a scope. An
interviewer asking "when would you *not* build an agent?" is checking whether you
have an opinion that costs you something, since the candidate who thinks
everything should be an agent has not yet paid for one.

The pattern: every good question in this space asks you to name a **trade-off you
personally made**, and your repository is where those live. Answer from it.
"In Phase 11 I designed a multi-agent supervisor, costed it, and declined to
build it — here are the four measurements that would reverse that" is a better
answer to almost any architecture question than a correct abstract one.

## 11. [core] Capstone increment — Atlas v1.0

*If your code diverged, start again from `atlas_phase_15.zip`.*

**Resume note.** Atlas now states what it can do in a form that can be false,
and checks it. Forty-four capability claims, thirty-six built and eight
deliberately deferred, each bound to an entry point, a test and — where
gradeable — an eval task. Seven review rules over its own source, with zero
unexplained findings and ten written exemptions. A second domain indexed with no
model. Four documents, each for a named reader. One configuration defect ten
phases old, found by a rule written that morning.

**What Atlas can do now that it could not before.** Tell the truth about itself
mechanically. Every earlier phase added a capability; this one added the thing
that says whether the earlier ones are still there.

### Files added

| File | What |
|---|---|
| `atlas/capabilities.py` | the manifest and its verifier |
| `atlas/review.py` | seven syntactic rules and the report |
| `atlas/demo.py` | the end-to-end demo: every capability exercised, offline |
| `atlas/domain.py` | `[extended]` the domain pack (corpus + database + skill) and swap audit |
| `tests/test_capabilities_phase16.py` | 17 tests, including the README pin |
| `tests/test_review_phase16.py` | 19 tests: 7 positives, 7 near misses, the gate |
| `tests/test_domain_phase16.py` | 22 tests: the three data paths, the boundary, the documents |
| `tests/test_demo_phase16.py` | 11 tests: the demo, and the generated summary |
| `tests/fixtures/review_bad_agent.py.txt` | the bad sample, parsed and never imported |
| `tests/hidden/test_phase16_a1.py` | Assignment 1 |
| `tests/hidden/test_phase16_a2.py` | Assignment 2 |
| `evals/tasks/phase16.json` | 4 tasks |
| `scripts/phase16_results.py` | `make capabilities` / `review` / `swap` / `demo` / `summary` |
| `docs/ARCHITECTURE.md`, `docs/SYSTEM_CARD.md`, `docs/REVIEW_CHECKLIST.md`, `docs/PORTFOLIO.md`, `docs/ENGINEERING_SUMMARY.md` | the documents |

### Files changed

| File | Change |
|---|---|
| `atlas/config.py` | `+ h_embed_model`, read from `ATLAS_H_EMBED_MODEL` (F-16-01) |
| `atlas/rag/hosted.py` | reads all three Tier H values from `Settings`; `import os` removed |
| `.env.example` | `+ ATLAS_H_EMBED_MODEL` |
| `atlas/mcp/server.py`, `scripts/hello_model.py`, `scripts/phase12_results.py`, `scripts/phase15_results.py` | one written review exemption each |
| `tests/test_rag_embed.py` | the `HostedEmbedder(None)` test rewritten; one test added |
| `tests/test_evals_harness.py` | gradeable task count 69 → 72 |
| `evals/run.py` | three dispatch branches |
| `Makefile` | `PHASE ?= 16`; `capabilities`, `review`, `swap`, `summary`; `demo` retargeted |
| `README.md` | rewritten; capability table generated |

### Interface changes

`HostedEmbedder` now reads Tier H credentials from `Settings`. **Migration:** set
`ATLAS_H_BASE_URL`, `ATLAS_H_API_KEY` and the new `ATLAS_H_EMBED_MODEL`. The old
`ATLAS_TIER_H_*` names are ignored, and a test asserts it. Everything else is
additive.

### Eval tasks added

* `p16-every-capability-claim-has-evidence` — unsupported claims must be 0.
* `p16-every-rule-fires-and-atlas-is-clean` — every rule fires on the sample AND
  `atlas/` is clean. Both halves, because a rule set firing on nothing produces a
  clean report that means nothing.
* `p16-a-domain-swap-is-data-not-code` — the second corpus is reachable and no
  unaccounted file names the old domain.
* `p16-the-demo-exercises-every-capability` — every built capability is
  exercised, `missing_probes` is empty, nothing failed.

### `make results` and the expected ranges

```
make capabilities   →  45 claimed / 37 supported / 8 deferred / 0 unsupported
make review         →  145 files, 0 unexplained, 10 explained, 7 of 7 rules fire
make swap           →  2 docs + 2 relations + 1 skill opened; code_edits_required 0
make summary        →  the one-page numbers, computed; --write-summary regenerates the doc
make demo           →  36 capabilities exercised (32 via the suite, 4 by probe), all green
```

All Tier F. Every number deterministic — there is no model anywhere in this
phase, so these are exact rather than ranges. The one estimate: the five-minute
portfolio demo on Tier A, **4–12 minutes**, author estimate, unmeasured.

### Read five failing traces

Eleven entries added to `docs/FAILURE_LOG.md`. The first five came from building
the phase: F-16-01 (Tier H configured twice under disjoint names), F-16-02 (13 of
42 capability claims named evidence that did not exist), F-16-03 (the README
wrong since Phase 3), F-16-04 (the bad-code fixture's labels exempted the
findings they labelled), F-16-05 (a hand-typed count in the section that prints
counts).

The other six came from **reviewing the phase against its own block** after it
was first written, which is the exercise section 6.4 describes and is worth
reading as a worked example of it: F-16-06 (a derived property that read a
module-level global and crashed on any custom capability set), F-16-07 (two
`DomainPack` fields declared and read by nothing), F-16-08 (a "demo" that
resolved entry points instead of exercising them), F-16-09 (the demo composing
the eval suite differently from the way the suite composes itself), F-16-10 (the
one-page summary typed by hand and wrong within the hour, on a page whose own
first line said its figures were not typed), F-16-11 (the demo's capability row
made it run its own eval task — infinite recursion, presenting as a hang).

Ten of the eleven are defects in the instrument or the documentation; none is in
the agent — `docs/ERROR_TAXONOMY.md` cluster B for the eighth consecutive phase,
which makes it a law rather than an observation. The six found in review are the
more interesting half: every one was a claim the phase made about itself that
the phase's own gates did not yet point at.

### Tag

```bash
git add -A && git commit -m "Phase 16: capability gate, code reviewer, documents, v1.0"
git tag phase-16 && git tag v1.0
```

## 12. [core] Mastery checklist

You are ready to move on if you can:

* State, in one sentence each, what an entry point, a test and an eval task
  prove about a claim — and what none of them proves.
* Write a new capability row for something you build, in the same commit.
* Name the five defects assistant-written agent code reliably contains, and say
  which three a program can find.
* Run the five-step review protocol on an unfamiliar agent repository and say
  what you found in each step.
* Explain why the reviewer accepts `# noqa: BLE001 - reason` and rejects
  `# noqa: BLE001`.
* Say which of the four documents answers a given question, without looking.
* Defend reporting ranges rather than a number, to someone who thinks it is
  hedging.
* Predict, before running `make swap`, which files name your domain.
* Answer the ten questions in section 13 out loud, at conversational speed.

## 13. [core] Quiz

Questions only; answers in `phase_16_solutions.md`. These ten are the interview
set the phase promised; the full bank of thirty is Appendix F.8.

1. An agent calls a colleague's service on behalf of a user. Enumerate what must
   be in the credential, and say what each property prevents. Which one do people
   most often omit, and what attack does omitting it enable?
2. MCP's current revision is stateless at the protocol layer. What does that
   change for a server author, and what does it change for a client author?
3. You have 5,000 traces and one week. Describe your procedure end to end, and
   say what you would do first and why.
4. Name four entries from the OWASP Top 10 for Agentic Applications and, for
   each, the control in Atlas that addresses it and the residual risk that
   remains.
5. What does your test suite prove, and what does it not? Be precise about the
   boundary.
6. A retrieved document contains an instruction to the model. Where do you stop
   it, and why is that the right layer rather than the prompt or the model?
7. Explain the difference between a liveness probe and a readiness probe, and
   describe an outage caused by conflating them.
8. You are asked to improve accuracy from 71% to 80%. What do you need to know
   before agreeing, and what would you say if the sample is 40 tasks?
9. When would you *not* build an agent? Give the property of the problem that
   decides it.
10. Your agent's answer channel can exfiltrate data that its tool channel cannot.
    Explain how, and what defends against it.

## 14. [core] Coding assignments

### Assignment 1 — the portfolio self-assessment `[fast track: do this one]`

Build `atlas/portfolio.py`: the rubric in `docs/PORTFOLIO.md` as code.

**Acceptance criteria.** `CRITERIA` is a closed, ordered tuple of at least eight
names; `LEVELS` is `(0, 1, 2, 3)`. `assess(root=...)` returns an `Assessment`
with exactly one `CriterionScore` per criterion, in criterion order. Every score
below the top level names at least one **specific missing artefact** — a path, a
test name, a target — and a score at the top level names none. Every level is
reachable, and the level is decided by evidence the function *checks*, not by a
flag it is told: assessing an empty directory must score every criterion below
the top. `Assessment.total` is derived and cannot be set by a caller. An unknown
criterion or an out-of-range level raises. `render_assessment()` prints each
criterion's level beside the missing artefact.

**UNAIDED CORE.** The evidence-gathering: for each criterion, decide what file,
test or command would have to exist for a level to be justified, and check it.
Delegating this is delegating the judgement the assignment is about.

```bash
make grade PHASE=16
```

### Assignment 2 — the inverse gate `[extended]`

`verify_capabilities` walks from the claim to the code. Build `atlas/coverage.py`
to walk the other way: every public module under `atlas/` must be reachable from
some capability's entry point, or be listed in `INFRASTRUCTURE` with a reason.

**Acceptance criteria.** `audit_coverage(root=...)` returns a `CoverageReport`
with `claimed`, `unclaimed`, `infrastructure` and `stale_exemptions`.
`INFRASTRUCTURE` is a mapping from module path to a reason of at least five
words. Reachability is computed from the import graph **by parsing** — the audit
must not import the modules it audits, and a test enforces it. Modules whose name
begins with an underscore are not reported. `stale_exemptions` names any
exemption for a module that no longer exists. A new unclaimed module is detected.
The report round-trips its dump and the rendering prints the exemption count.

**UNAIDED CORE.** The reachability walk. An assistant will offer you
`importlib`; the assignment is the version that does not import.

```bash
make grade PHASE=16
```

## 16. [core] Summary & key takeaways

*Self-contained. Paste this where you start the appendices.*

**A capability is a claim, and a claim is something that can be false.** Six
invariants in this contract file are one sentence said six ways, and every one
was found by a human reading a printed number beside a label rather than by the
suite — because the suite tested the mechanism rather than the claim. So the
capability list is **data**: forty-four rows, each binding a sentence Atlas is
allowed to say about itself to an entry point that imports, a test that exists,
and — where gradeable — an eval task in the suite. The bound is narrow and worth
saying out loud: verification proves a claim is *attached* to something, never
that the thing is good. It is still the bound that would have caught all six,
because in every case the evidence did not exist at all.

**The measurement is the lesson.** A manifest of 44 rows, written from memory
immediately after building the work it describes, had **thirteen wrong
references** — eleven test names, two entry points, one task id. Every one would
have gone into a README as a confident sentence, and none would have failed a
test. Write the row in the same commit as the thing.

**The document with no test is the document that rots, and the fix is generation
rather than discipline.** The README said `phase-03` and `389 tests` against a
suite of 1,618, for twelve phases, green throughout. One part of it is now
rendered from the manifest and pinned by a test; the rest stays hand-written,
because a fully generated README is one nobody edits and therefore nobody reads.
A second test parses the Makefile and asserts every `make` target the prose names
exists. It fired on its first run.

**A reviewer is syntactic, and an exemption is a sentence somebody wrote.** Seven
rules decided with `ast` alone: no imports, no execution, no model — one that
runs the code under review can be attacked by it, and one that needs a model
costs money per commit and finds different things on different days. A finding is
answered by a reason clause in whatever marker syntax the file already uses,
because **the point is the reason, not the marker**; a bare `# noqa` exempts
nothing. The loose direction is a false exemption rather than a false finding,
which is the right way round for a tool meant to stay switched on. Corollary,
learned within the hour: when a tool reads comments, comments *about* the tool
are inputs to the tool.

**And it found something.** `atlas/rag/hosted.py` read three `ATLAS_TIER_H_*`
names from the environment that existed in no `Settings` field, no
`.env.example` and no `VERSIONS.md` — while its own docstring said those values
came from `Settings`. Tier H was configured twice under disjoint names, for ten
phases, invisible to 1,618 tests, because nothing offline constructs the class
and the one test that touched it passed `None` for the argument that was never
read. **A configuration key is a name shared between code, a file, a docs table
and a person, and nothing type-checks a shared name.**

**Three of the five shapes are syntactic; two need a human.** Silent broad
exception handling, missing budgets and tool schemas that lie can be found by a
program. Tests that assert on fixtures rather than behaviour, and credentials
passed too far in a form no rule catches, cannot. So the review protocol is an
**order**: run the instrument first, read the closed sets for emitters, read each
function's body for its own parameter names, grep every public name for a call
site — and only then read the logic. The middle three take five minutes each and
are the thing no test can do for you.

**Portability is a claim, so it is computed.** The retrieval path needed **zero**
code edits for a second domain; **ten** files name the old one, in prompt text,
tool descriptions, time zones and id formats. The second number is the useful
one, because the question behind "how portable is this?" is whether you know
where your own coupling is.

**And the measurement.** **1,687 offline tests passing, 12 skipped. 74 eval
tasks. 45 capabilities claimed, 37 supported, 8 deferred, 0 unsupported. 145
files reviewed, 0 unexplained findings, 10 written exemptions. 36 capabilities
exercised by `make demo` in about two seconds, 0 exercised by nothing.**
`make check-docs` green, no network, no model, no Docker.

**Cluster B, for the eighth consecutive phase.** Four of five failure-log entries
are defects in the instrument or the documentation; none is in the agent. Which
means the last thing to carry forward is the first thing this phase argued: the
system you are least able to see is the one you are looking through.

## 17. [core] Further reading

* **Anthropic, "Building effective agents"** — the workflow-versus-agent
  distinction this book's Phases 5 and 11 rest on.
  https://www.anthropic.com/engineering/building-effective-agents
* **Anthropic, "Effective context engineering for AI agents"** — the framing
  behind Phase 8. https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents
* **OWASP GenAI Security Project, Top 10 for Agentic Applications (2026
  edition, published 9 December 2025)** — ASI01–ASI10, the taxonomy
  `docs/THREAT_MODEL.md` is organised around.
  https://genai.owasp.org/resource/owasp-top-10-for-agentic-applications-for-2026/
* **Model Context Protocol specification and changelog** — the only
  authoritative record of what changed between revisions.
  https://modelcontextprotocol.io/specification/
* **Model Context Protocol blog, roadmap posts** — what will break, before it
  breaks. https://blog.modelcontextprotocol.io/
* **OpenTelemetry GenAI semantic conventions** — still moving; the source for
  Phase 15's attribute names.
  https://opentelemetry.io/docs/specs/semconv/gen-ai/
* **Zheng et al., "Judging LLM-as-a-Judge" (2023)** — self-enhancement and
  position bias, the reasons Phase 13's judge is calibrated and never the model
  under test. https://arxiv.org/abs/2306.05685

Dates and versions for all of the above are in `VERSIONS.md`, with a checked-on
column. Re-verify before you rely on any of them.
