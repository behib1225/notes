# appendix_f1_f3_solutions.md

Worked answers for Appendix F.1 (CodeAct), F.2 (Text-to-SQL Agents) and F.3
(Scaling to Many Tools): the concept checks and all three assignments.

**How to use this file.** Read a solution only after you have written something
and run `make grade PHASE=f1` (or `f2`, `f3`) at least once. The hidden tests
are the assessment; this file is the explanation. For each assignment there are
three parts: the code that passes, *why* it is written that way, and the wrong
turns — including two I took and measured before writing the section.

Every code block here was executed against the snapshot it belongs to. The
reference solutions pass the hidden tests: 12/12 for F.1, 13/13 for F.2, 12/12
for F.3.

**A fourth thing in each section is worth reading before the assignment:** the
`APPENDIX_F1.md` / `_F2.md` / `_F3.md` file at the root of each snapshot gives
the reading order and the commands. If you have not run `make test-offline` and
the section's eval runner yet, do that first — the assignments all extend
behaviour the tests already pin, and it is much easier to extend code you have
watched run.

---

## F.1 — CodeAct: concept checks

### CC1. A snippet calls `query_db` twice with identical SQL. How many launches, how many `execute()` calls, and why is that right rather than one cached result reused?

**Three launches and two `execute()` calls.** Executed:

```
launches 3   execute calls 2   stdout "4.00 4.00"   keys identical: True
```

The resolved-call file is a **list**, not a dict. Run 1 requests call 0 and
exits; the parent resolves it and appends. Run 2 replays slot 0 from the list,
requests call 1, exits; the parent resolves and appends. Run 3 replays both
slots and finishes. N calls, N+1 launches, regardless of whether the calls are
identical.

The tempting alternative — key the store by `(name, arguments)` so an identical
call is answered from the first result — is wrong for a reason that only shows
up on a write. Two identical `write_file(...)` calls in one snippet are two
writes; a dict-keyed store performs one and reports two. It also silently
changes the meaning of any tool whose result depends on something other than
its arguments, which is every clock, every counter and every queue.

The positional design also gives the divergence detector for free. "The i-th
call must equal the cached i-th call" is a prefix check, and a prefix check is
exactly the statement "this snippet is replay-stable". A dict-keyed store
cannot express that, because any ordering hits the same keys — which is why it
would have passed §f's set-iteration snippet silently.

### CC2. ReAct has seven exits; CodeAct has six. Why can `bad_action` not occur, and what replaced it?

`bad_action` fires when the model names a tool the registry does not hold. In
CodeAct the registry *is* the child's namespace: `build_prelude` emits one stub
per registered tool and nothing else. A misspelled name is therefore not a
dispatch at all — it is a `NameError` raised inside the snippet before any tool
runs:

```
Traceback (most recent call last):
  File "snippet", line 1, in <module>
NameError: name 'qeury_db' is not defined. Did you mean: 'query_db'?
```

Nothing replaced it, and that is the point. ReAct ends the episode on a phantom
tool because re-sending the tool list the model just ignored spends a prompt on
nothing. Here the model gets a message naming the line, the typo and the
correction, so the failure moved from a terminal exit to a recoverable
observation. The exit did not need a substitute; the class of failure stopped
being terminal.

`cycle` is a different case: it was dropped by choice, not by construction. Its
unit is a tool call, and here the unit is a snippet, so `no_progress` on snippet
text already catches the repeat. Two snippets that differ by whitespace and do
the same thing would slip past — a real gap, documented rather than papered
over.

### CC3. The resolved-call file lives in the jail and the child opens it with a relative path. What breaks with an absolute path — not security, something more mundane?

**The generated source stops being a function of the snippet alone.**
`build_prelude` embeds the filename as a literal, so with an absolute path the
child's source contains a temporary directory that differs per episode, per
machine and per test run. Three consequences, none of them dramatic and all of
them annoying:

- `build_prelude` can no longer be asserted against a fixed string, so every
  test of it becomes a substring match.
- Two runs of the identical snippet produce byte-different `run_python`
  arguments, so anything keyed on the call signature — a response cache, a
  recorded fixture, a trajectory diff — never matches.
- The path spends `MAX_CODE_CHARS`, which the snippet needs.

Relative-plus-`cwd` costs nothing and keeps the prelude a pure function of
`(registry, snippet)`. The security benefit — the child never learns an
absolute path — is real and is a bonus, not the reason.

---

## F.1 — Assignment: `audit_snippet`

### The solution

**`atlas/agents/codeact_audit.py`** — the stub's header and constants
unchanged, with the body filled in:

```python
def audit_snippet(
    source: str, registry: ToolRegistry, *, allow_writes: bool = False
) -> list[str]:
    """Return every reason this snippet should not run. Empty means run it."""
    import ast

    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        return [
            f"the snippet does not parse: {exc.msg} on line {exc.lineno}. "
            "Send valid Python."
        ]

    complaints: list[str] = []
    defined: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            defined.add(node.name)
        elif isinstance(node, ast.Name) and isinstance(node.ctx, ast.Store):
            defined.add(node.id)
        elif isinstance(node, ast.arg):
            defined.add(node.arg)

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                root = alias.name.split(".")[0]
                if root not in ALLOWED_IMPORTS:
                    complaints.append(
                        f"line {node.lineno}: importing {root!r} is not allowed. "
                        f"Allowed modules: {', '.join(sorted(ALLOWED_IMPORTS))}."
                    )
        elif isinstance(node, ast.ImportFrom):
            root = (node.module or "").split(".")[0]
            if root not in ALLOWED_IMPORTS:
                complaints.append(
                    f"line {node.lineno}: importing from {root!r} is not "
                    f"allowed. Allowed modules: {', '.join(sorted(ALLOWED_IMPORTS))}."
                )
        elif isinstance(node, ast.For) and isinstance(
            node.iter, (ast.Set, ast.SetComp)
        ):
            complaints.append(
                f"line {node.lineno}: iterating over a set. Set order changes "
                "between runs and this snippet may be re-run; use a list."
            )
        elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            name = node.func.id
            spec = registry.get(name)
            if spec is None and name not in defined and name not in SAFE_BUILTINS:
                complaints.append(
                    f"line {node.lineno}: {name}() is not a tool you were "
                    f"given. Available: {', '.join(registry.names)}."
                )
            elif spec is not None and not spec.read_only and not allow_writes:
                complaints.append(
                    f"line {node.lineno}: {name}() modifies state and writes "
                    "are disabled for this episode. Report what you would "
                    "have changed instead."
                )
    return complaints
```

### Why it is written this way

**A `SyntaxError` returns early and alone.** Everything downstream needs a
tree; without one there is nothing to walk. Returning one complaint rather than
raising keeps the function total, which is what lets `run_codeact_agent` treat
it as data.

**Two passes, not one.** The `defined` set has to be complete before any call
is judged, because a snippet may call a helper defined below it:

```python
print(total([1, 2]))
def total(xs):
    return sum(xs)
```

A single pass would report `total()` as an unknown tool. Collecting every
`Store` name, every `def`/`class` name and every argument first costs one extra
walk over a snippet of at most a few dozen lines.

**`ast.Name` only, never `ast.Attribute`.** `math.sqrt(2)` is a call whose
`func` is an `Attribute`, not a `Name`, so it is ignored — correctly, since the
import rule already governs whether `math` is available. Trying to resolve
attribute chains would turn a thirty-line auditor into a half-finished name
resolver.

**The complaint is written for the model.** Each one names the line, what was
rejected and what to do instead (D-10). And the function returns *every*
complaint rather than the first, because a model told about one defect fixes it
and fails again — the same argument Phase 3 makes about argument validation and
the reason `_explain_validation` reports all of them.

**`elif`, deliberately.** A call that is both an unknown name and a write
cannot be both; a node that is a `For` is not a `Call`. The chain reflects the
node types, not a priority.

### How the hidden tests map to the rules

| Hidden test | Rule |
|---|---|
| clean snippet → `[]` | none fire |
| unparseable → truthy | rule 1 |
| `import random` names `random`; `import math` passes | rule 2 |
| `from os import path` names `os` | rule 2, `ImportFrom` branch |
| `query_db()` outside the registry is named | rule 3 |
| locally defined `total()` is not a complaint | rule 3, two-pass `defined` |
| `write_file` complains at `allow_writes=False`, not at `True` | rule 4 |
| `for d in {"a","b"}` complains; a list does not | rule 5 |
| two defects → ≥ 2 complaints | report-all |
| twice → equal | purity |

### Wrong turns

**Returning `bool` instead of `list[str]`.** The loop refuses on a non-empty
list and puts the joined complaints into the snippet's error text. A boolean
gives the model "refused" with no line number, which is a worse prompt fragment
than the thing it was protecting against.

**Trying to make `SAFE_BUILTINS` a security boundary.** It is not, and the
stub's comment says so. A snippet can reach `__builtins__` through several
routes and the auditor will not stop it. What it stops is the *honest* mistake
— calling a tool that was never offered — which is the case that actually
occurs. Security is the registry and the executor.

**Flagging `while` loops.** Tempting, and wrong for this executor: the sandbox
already has a wall-clock timeout and `RLIMIT_CPU`, so a runaway loop is a
`TimeoutError` with an actionable message. An auditor that duplicates a
guarantee the layer below already gives you produces false positives on
legitimate code (`while queue:`) for no benefit.

**The question in the section, answered.** What should the auditor do about a
call it cannot resolve statically — `getattr(builtins, name)()`, or a tool name
assembled from a string? The defensible answer is to **complain, and say why**:
the auditor's contract is "I can tell you what this snippet will call", and an
indirect call makes that contract unsatisfiable, so reporting "line N: this call
is built at runtime and cannot be checked before running" is accurate rather
than restrictive. It also has almost no cost, because no model writes
`getattr`-dispatched tool calls unless something has gone badly wrong upstream.
The version that refuses everything dynamic *silently* is the bad one; the
version that allows it silently is worse.

---

## F.2 — Text-to-SQL: concept checks

### CC1. The fan-out probe ignores `min()`, `max()` and `count(DISTINCT x)`. Why is that necessary rather than convenient?

Because those aggregates are **invariant under row multiplication**. If a join
repeats each row of `v_shipments` six times, `max(units)` is unchanged,
`min(units)` is unchanged, and `count(DISTINCT sku)` is unchanged. Only
additive aggregates — `sum`, `avg`, `total`, `count(*)` — change.

The word "necessary" turns on one fact: `join_fanout` **blocks**. A blocking
probe that fires on correct queries does not merely annoy people; it refuses
answers. Add `max()` to the additive set and every correct
`SELECT max(units) FROM a JOIN b ...` in the repository becomes an abstention.
Two weeks of that and someone switches the probe off, at which point you have
neither the false positives nor the true ones.

The general rule: **a check's precision is a precondition of its being allowed
to block.** Phase 7 made the same decision in the other direction —
`filter_dropped` caveats rather than blocks, because a total across all quarters
is a true fact badly labelled.

### CC2. The magnitude probe catches 3832 against a ceiling of 1398 and misses 924 against the same ceiling. State the general rule.

An envelope check compares a *filtered* aggregate to the *unfiltered* total of
the same column. It can only fire when the inflation is large enough to exceed
the headroom between the true filtered value and the unfiltered one. On the
seeded corpus:

| query | reported | ceiling | caught? |
|---|---|---|---|
| fan-out join, filtered to 2026Q1 | 924 | 1398 | no |
| fan-out join, all quarters | 3832 | 1398 | yes |

**An envelope check's sensitivity is bounded by how selective the filter is, so
it catches gross errors and is blind to proportionate ones.** A quarter is a
quarter of the data, so a 2.5x inflation still fits inside the envelope. Filter
to one SKU in one region and almost any inflation fits.

A grain check has no such dependence. It tests the *mechanism* — is the join key
unique in the relation being joined to — and answers the same way whether the
inflation is 2.5x or 100x. The two are complements, not alternatives: the
envelope catches errors whose cause you did not anticipate, and the grain check
catches one cause at any size. There is a test asserting the miss, so nobody
later mistakes the envelope for a general guard.

### CC3. What does re-sending the schema buy, and what would you have to believe to leave it out?

It buys the guarantee that **the model is never asked to remember or infer the
schema**. On a repair turn the only new information is the complaint;
everything else is identical to the first turn, so the model's job is "fix this
one named problem", not "reconstruct what the columns were and then fix it".

To leave it out you would have to believe two things, and F-07-01 falsified
both. First, that the schema stays reliably available in context across turns —
but a repair turn sits behind a rejected draft and an error message, and many
runners truncate from the oldest end, which is where the system prompt lives.
Second, that the error prose contains enough to fix the query — F-07-01 is
precisely the case where the error message *contained* the correct schema and
the model guessed a column name anyway.

The cost is real: the grounded block is several hundred tokens, re-sent per
attempt. That is the right trade at `max_attempts=3`, and it is the wrong trade
at 20 — which is an argument for a small attempt cap, not for a thinner repair
prompt.

---

## F.2 — Assignment: `extra_probe_findings`

### The solution

**`atlas/flow/sqlprobe_extra.py`** — header and types unchanged, with
`BLOCKING_EXTRA_PROBES` set and the body filled in:

```python
BLOCKING_EXTRA_PROBES: frozenset[str] = frozenset({"distinct_over_measure"})
```

```python
def extra_probe_findings(
    db_path: Path | str, sql: str, rows: Sequence[Sequence[object]] = ()
) -> list[ExtraProbeFinding]:
    """Report both defects. Never raises."""
    import re
    import sqlite3

    from atlas.flow.sqlprobe import _connect, dimension_columns, join_keys, alias_map

    distinct_sum = re.compile(
        r"\b(sum|total|avg)\s*\(\s*distinct\s+"
        r"(?:([a-z_][a-z0-9_]*)\.)?([a-z_][a-z0-9_]*)\s*\)",
        re.IGNORECASE,
    )
    inner_join = re.compile(r"(?<!left )(?<!right )(?<!full )(?<!outer )\bjoin\b",
                            re.IGNORECASE)

    aliases = alias_map(sql)
    findings: list[ExtraProbeFinding] = []

    for match in distinct_sum.finditer(sql):
        prefix, column = (match.group(2) or "").lower(), match.group(3).lower()
        relation = aliases.get(prefix) if prefix else None
        candidates = [relation] if relation else sorted(set(aliases.values()))
        for name in candidates:
            try:
                dimensions = dimension_columns(db_path, name)
            except sqlite3.Error:
                continue
            if column in dimensions:
                break
            findings.append(
                ExtraProbeFinding(
                    kind="distinct_over_measure",
                    detail=(
                        f"{match.group(1).lower()}(DISTINCT {column}) reads a "
                        f"measure column of {name}. Two rows holding the same "
                        f"{column} count once between them, so the total "
                        "depends on which values happen to repeat. If the "
                        "join was repeating rows, pre-aggregate instead."
                    ),
                    evidence=f"{column} is not a dimension column of {name}",
                )
            )
            break

    if inner_join.search(sql):
        for left, left_cols, right, right_cols in join_keys(sql):
            for relation, columns, other, other_cols in (
                (left, left_cols, right, right_cols),
                (right, right_cols, left, left_cols),
            ):
                predicate = " AND ".join(
                    f"r.{o} = l.{c}" for c, o in zip(columns, other_cols)
                )
                probe = (
                    f"SELECT count(*) FROM {relation} l WHERE NOT EXISTS "
                    f"(SELECT 1 FROM {other} r WHERE {predicate})"
                )
                try:
                    with _connect(db_path) as conn:
                        missing = conn.execute(probe).fetchone()[0]
                except sqlite3.Error:
                    continue
                if missing:
                    findings.append(
                        ExtraProbeFinding(
                            kind="inner_join_may_drop",
                            detail=(
                                f"{missing} rows of {relation} have no match in "
                                f"{other} on this key, and a plain JOIN removes "
                                "them from the answer. Use a LEFT JOIN if those "
                                "rows belong in the result."
                            ),
                            evidence=f"{probe}  -> {missing}",
                        )
                    )
                    break
    return findings
```

### Why it is written this way

**Reuse, not re-derivation.** `alias_map`, `join_keys` and `dimension_columns`
are already in `sqlprobe`, already tested, and already the place where "is this
a measure?" is decided by measurement rather than by name. Writing a second
alias parser here would be a second description of the same thing (invariant 13)
and would drift the first time somebody supported `USING`.

**`count(DISTINCT x)` is excluded by the regex, not by a special case.** The
alternation is `sum|total|avg`; `count` is simply not in it. That matters
because `count(DISTINCT x)` is the one distinct aggregate that means what it
says — "how many different values" — and destroys nothing.

**`sum(DISTINCT dimension)` passes.** Odd but coherent: summing the distinct
values of a categorical column is a strange query, not a wrong one, and blocking
every strange query is how a checker becomes something people route around. The
measure/dimension split is the line, and `dimension_columns` draws it with
`typeof()`.

**The `NOT EXISTS` probe rather than `NOT IN`.** `NOT IN` with a NULL anywhere
in the subquery returns no rows at all — the classic three-valued-logic trap,
and a probe that silently reports zero missing rows because of a NULL would be
worse than no probe. `NOT EXISTS` is correct under NULLs and works on any
SQLite version the book supports.

**Both join sides are probed and the first hit breaks.** One finding per
relation pair is enough to send the author to the join; two would say the same
thing twice.

### Why only one of them blocks

The acceptance criteria fix the answer, and the reasoning is the point.

`distinct_over_measure` has **the whole query in view**. Nothing about the data
can make `sum(DISTINCT units)` correct: it is a statement that two rows with
equal `units` should count once, which is never what a units total means. The
check needs no evidence beyond the statement and the column's type, so it can
block.

`inner_join_may_drop` is computed **without the query's `WHERE` clause**. The
probe asks whether *any* row of `v_shipments` lacks a match in `v_warranty` — 8
of 64 on the seeded corpus at seed 7 — and says nothing about whether the
query's filter already excludes those eight. At seed 7, restricted to 2026Q1,
every SKU does have a claim, so the finding is true about the relation and false
about the answer. A verifier with partial evidence must caveat rather than
block. Phase 7 made this exact call about `filter_dropped`, and the rule
generalises: **how much of the query a check can see determines whether it may
block.**

### Wrong turns

**Reaching for a SQL parser.** `sqlparse` or `sqlglot` would make the ON-clause
extraction cleaner and would add a dependency to a repository whose Phases 1–8
are framework-free. It also buys less than it looks: the probes are used to
*describe* and to *contradict* a query, never to permit one, so a regex that
misses an exotic construct costs a caveat rather than a breach — the reasoning
`relations_in_sql` already records.

**Blocking both.** The hidden test pins the frozenset for a reason. If you set
it to both members, `f2-sql-agent-repairs-a-fanout-join` starts abstaining on a
query the section shows being repaired correctly, and the repaired query in §h
uses a `LEFT JOIN` precisely to keep rows the inner join would drop — a fix your
own probe would then have refused to accept.

**Making the `distinct` detector case-sensitive.** Models emit
`Sum(Distinct x)`, `SUM( DISTINCT x )` and `sum(distinct x)`. The
`re.IGNORECASE` flag and the `\s*` are not defensive programming; they are the
observed input distribution.

**Wiring it in and forgetting the ordering.** Once the module works,
`run_sql_agent` should run it *alongside* `probe_findings`, not instead of it,
and blocking findings from both lists are concatenated before the repair
decision. Criterion 9 — the §f trace ending in an abstention — only passes if
the new findings reach `blocking`.

---

## F.3 — Many tools: concept checks

### CC1. `execute_tool` takes its arguments as a JSON *string*. One thing that buys, one thing it costs.

**It buys one fixed schema for sixty tools.** The advertised parameters are:

```json
{"properties": {"name": {"type": "string"},
                "arguments": {"type": "string", "default": "{}"}},
 "required": ["arguments", "name"], "additionalProperties": false}
```

`schema_for(strict=True)` produces a concrete shape from a concrete signature.
A typed `arguments` object would need to be either a union of sixty schemas —
which nothing in the dialect expresses — or an open object, which contradicts
`additionalProperties: false` and Phase 2's two-switch rule. A string sidesteps
the problem: the wrapper's schema is fixed, and the *inner* shape is checked by
the inner tool's own `args_model`, which is where invariant 18 says the
description lives anyway.

**It costs decode-time constraint.** With sixty tools advertised directly, a
backend doing schema-constrained decoding can make a malformed argument object
literally ungeneratable. Through the wrapper, `arguments` is an unconstrained
string, so validation moves from the decoder to runtime and a malformed payload
becomes a step that costs a model call:

```
ValueError: arguments was not valid JSON (Expecting value). Send one JSON
object as a string, like {"record_id": "INV-204"}.
```

That message exists because the failure moved. It is recoverable, and it is not
free.

### CC2. Recall@k is called `ceiling`. What is the other factor, and which phase made this mistake in the other direction?

The other factor is **the model choosing correctly from the k candidates it was
shown**. End-to-end selection accuracy is the product:

```
selection accuracy  =  recall@k  x  P(model picks the right one | it was shown)
```

The ceiling at k=5 on the seeded probes is 0.50, so no agent using this ranker
can exceed 50% however good it is at choosing. Naming the field `accuracy`
would invite exactly the reading that the search's job is done.

Phase 7 opened with the mirror image: Phase 6 printed recall@5 = 1.000 and did
not print precision, which was 0.279 — 101 of 140 chunks reaching the generator
came from documents that could not answer the question. Both mistakes are the
same shape: **reporting the factor you measured as though it were the quantity
you care about.** The fix both times is to name the field after what it is.

### CC3. `ToolCatalog` builds its index once; the eval runner builds one environment for all trials. Justify both, and say what would make the second wrong.

**The index, once:** BM25's `doc_freqs` is a statistic over the *whole* corpus,
so the score of any tool depends on all sixty. Rebuilding per search is wasted
work; rebuilding per *changed set* silently changes every ranking. It is also
invariant 16 exactly — a stateful object constructed once per run, outside the
loop it serves, and passed in.

**The environment, once:** the core harness rebuilds the corpus and registry per
trial because a trial can mutate them — a `write_file` in trial 1 must not be
visible in trial 2. The sixty synthetic tools are pure functions of their
arguments; they return a marker string and touch nothing. With nothing to
contaminate, per-trial isolation buys nothing and costs sixty `exec`
compilations per trial.

**What would make it wrong:** give any synthetic tool state — a file, a counter,
an in-memory dict of "archived" ids — and trials stop being independent.
`support_archive_ticket` writing to disk would make the fifth trial's result
depend on the first four, which is precisely the correlated-failure pattern the
core's rule exists to prevent. The justification is a property of *these* tools,
so if you extend the generator, re-check it.

---

## F.3 — Assignment: `ranked_search` and `make_guarded_search`

### The solution

**`atlas/tools/catalog_rank.py`** — the imports gain `render_full`,
`render_index` and `tool`; the constants are unchanged:

```python
from atlas.tools.catalog import (
    CatalogHit,
    CatalogSearch,
    ToolCatalog,
    render_full,
    render_index,
)
from atlas.tools.registry import ToolRegistry, tool
```

```python
def ranked_search(
    catalog: ToolCatalog,
    query: str,
    *,
    k: int = 5,
    min_top_score: float = MIN_TOP_SCORE,
    min_margin: float = MIN_MARGIN,
) -> RankedSearch:
    """Search, then judge. Pure given the catalogue; never raises."""
    found = catalog.search(query, k=k) if query.strip() else CatalogSearch(query=query)
    if not found.hits:
        return RankedSearch(
            search=found, confident=False,
            reason="no tool matched any word of the query",
        )
    if found.top_score < min_top_score:
        return RankedSearch(
            search=found, confident=False,
            reason=(
                f"the best score was {found.top_score:.2f}, below the floor of "
                f"{min_top_score:.2f}: this is the least bad of "
                f"{found.n_candidates}, not a match"
            ),
        )
    if len(found.hits) > 1 and found.margin < min_margin:
        return RankedSearch(
            search=found, confident=False,
            reason=(
                f"the top two are {found.margin:.2f} apart, below the margin of "
                f"{min_margin:.2f}: the order between them is noise"
            ),
        )
    return RankedSearch(
        search=found, confident=True, hits=list(found.hits),
        reason=f"top score {found.top_score:.2f}, margin {found.margin:.2f}",
    )


def make_guarded_search(
    registry: ToolRegistry,
    *,
    catalog: ToolCatalog | None = None,
    k: int = 5,
) -> Callable[..., str]:
    """A `search_tools` replacement that falls back to the level-1 index."""
    index = catalog if catalog is not None else ToolCatalog(registry)
    default_k = k

    @tool(
        name="search_tools",
        read_only=True,
        cacheable=True,
        max_output_chars=3_000,
        examples=("search_tools(query='open support tickets for a customer')",),
    )
    def search_tools(query: str, k: int = default_k) -> str:
        """Find the tools that can answer a request, with their arguments.

        Args:
            query: Three to eight content words describing the ACTION you need
                and the thing it acts on, in the words a tool would use.
            k: How many tools to return, 1 to 10.
        """
        if not query.strip():
            raise ValueError("query is empty")
        result = ranked_search(index, query, k=k)
        if result.confident:
            return render_full(index.specs_for([hit.name for hit in result.hits]))
        return (
            f"no tool clearly matched ({result.reason}). Every tool that exists "
            "is listed below. Call search_tools again with a name from this "
            "list, or say you cannot do this.\n\n"
            + render_index(registry)
        )

    return search_tools
```

### Why it is written this way

**Three rules in order, each with its own reason string.** The order matters: an
empty result must be caught before `top_score` is read (it is 0.0 for an empty
search and would be reported as a floor failure, which is true but
uninformative), and the margin rule must come last because it is the only one
that needs two hits. The hidden test that asserts the empty and weak reasons
differ exists because a single generic "not confident" tells the model nothing
about whether to rephrase or to pick from the index.

**`len(found.hits) > 1 and ...` — the `AND` is the subtle part.** A query
matching exactly one tool strongly returns one hit and a margin of 0.0 by
definition, and a naive `margin < min_margin` would refuse the single clearest
outcome the ranker can produce. Measured:

```
catalog.search("warehouse stock spare parts inventory", k=1)
  -> 1 hit, margin 0.00
```

**`hits` is empty when not confident.** The stub says so and it is worth
restating: a caller that renders the candidates anyway is exactly §f, and the
only thing that stops that is the type making it awkward.

**`default_k` shadows the parameter deliberately.**
`def search_tools(query: str, k: int = k)` inside a factory whose own parameter
is `k` works but reads as a bug; binding `default_k` first makes the closure
explicit. Either passes the tests.

**The fallback names the next action.** "Call search_tools again with a name
from this list, or say you cannot do this" gives two exits, one of which is an
abstention. A fallback that only lists sixty names invites the model to guess
from them.

**The declared properties are copied exactly.** `read_only=True`,
`cacheable=True`, the same tool name and the same two argument names, so
swapping the two implementations is one import change. A hidden test pins all
four.

### Picking the thresholds

The stub ships `MIN_TOP_SCORE = 3.0` and `MIN_MARGIN = 0.5` and tells you to
justify them from the measured spread. The relevant observations on the seeded
catalogue:

- the §f query scores `top_score 5.89, margin 0.00` — well above any sensible
  floor, and caught only by the margin rule;
- an out-of-vocabulary query returns no hits at all, because
  `BM25Index.search` excludes zero scores;
- a strong single-relation match (`"export the invoice report for one period"`)
  clears 3.0 comfortably.

So the floor catches "matched a stopword or two" and the margin catches "matched
the shape, not the domain" — which is the failure mode that actually occurred.
If you set the margin much above 0.5 you begin refusing correct rankings among
near-identical siblings, which is most of this registry. Record whichever
numbers you pick and *why*, in a comment, because the next person will otherwise
read them as arbitrary.

### Wrong turns, including one I measured

**Two-stage retrieval: domain first, then verb.** This is the obvious idea and
it is worse. I built it — classify the query into the two most likely domains
with a second BM25 index over each domain's pooled text, then rank only within
those — and measured it against the shipped ranker on the same 24 probes:

| ranker | recall@5 all | easy | hard |
|---|---|---|---|
| shipped | 12/24 | 7/12 | 5/12 |
| + plural normalisation | 14/24 | 9/12 | 5/12 |
| two-stage, domain then verb | 12/24 | 9/12 | **3/12** |

The hard half gets *worse*, and the reason is worth more than the number: when
the user's vocabulary is the problem, the domain classifier is fed the same
wrong words, picks the wrong domain, and the restriction then removes the right
tool from the candidate set entirely. **A filter applied before the thing that
is uncertain amplifies the uncertainty instead of resolving it.**

**Morphological normalisation, which does help a little.** Stripping a trailing
`s` before indexing and before searching lifts recall@5 from 12/24 to 14/24 —
the `ticket`/`tickets` mismatch from §f. It is not part of the assignment, it is
two lines, and it is worth doing. Note where the gain lands: entirely in the
easy half. The hard half is unchanged at 5/12, because no amount of stemming
bridges `helpdesk case` -> `ticket`.

Which points at the fix the section ends on and this assignment does not
attempt: **the remaining gap is a description problem, not a ranker problem.**
Put the user's word in the tool's description and the hard half moves; leave it
out and no reranking will find it.

**Making the fallback conditional on a small registry.** Criterion 7 requires
every tool name in the weak-search output, and that is right at sixty and
impossible at six hundred. Do not special-case it here; note it and answer the
section's closing question separately. The defensible answer at scale is to fall
back to the *domains* — six lines instead of sixty — and let the model narrow,
which is the same progressive disclosure one level coarser.

---

## Errata, and what was corrected in the shipped snapshots

The snapshots differ from the section listings in six places. All six are
corrections; each is described here so a reader working from the printed
sections is not confused by the difference.

**1. `scripts/gen_tools.py` stated the near-collisions wrongly.** The docstring
said "Four domains have a `search_*` tool ... and three have an
`export_*_report`." Executed, it is six and six: every domain gets all ten
shapes. `tests/test_catalog.py` already asserted the correct counts three files
away, which is precisely the prose-versus-code divergence Phase 8's F-08-02 is
about, and the corrected docstring now says so.

**2. F.1 did not document the forged-sentinel case.** A snippet can print the
request sentinel itself. Measured: a forged request for a tool the registry
does not hold returns `unknown_tool` and runs nothing; one for a tool it does
hold runs a tool the snippet could have called anyway; and either way the child
never consumes the resolved slot, so it reprints the same line each launch and
the episode ends at `tool_budget`. Bounded, terminating, registry-confined. Two
tests now pin it and the module docstring states it.

**3. F.2 executed the drafted query three times per attempt.** Once through the
Phase 3 tool and twice more to fetch rows and column names separately.
`cursor.description` comes from the same cursor as the rows, so `_values` now
answers both in one execution — two total, and the second is explained where it
happens: the tool returns rendered TEXT and the checks need VALUES, because
`no_rows_matched` has to tell a row of real NULLs from a row containing the
four characters `NULL`. `PROBE_ROW_LIMIT = MAX_ROWS + 1` is now named, with the
honest limit stated: a magnitude violation appearing only beyond row 51 is not
seen.

**4. No section cached Tier H results.** Block A requires it and
`Settings.cache_dir` has existed since Phase 4. All three results scripts now
cache per cell under `data/cache/appendix_fN/`, keyed on
(tier, model, seed, arm, cell), with Tier F never cached.

**5. F.3 shipped no "before" arm in the eval harness.** The block asks for
selection accuracy measured before and after, and all three tasks used
`arm: catalog` even though the runner supported `flat`. There is now a fourth
task, `f3-flat-arm-advertises-every-tool`, which answers the same question with
all sixty schemas advertised and asserts `tools_offered` is 60 and there is no
search step.

**6. `[Tier H recommended]` was never tagged**, despite each section having an
obvious candidate column. Each results script header now carries the tag and
says what Tier A still shows.

Two things were added rather than corrected: an ASCII fan-out diagram in
`atlas/flow/sqlprobe.py` (with the real seeded values, checked against the
database) and a three-level diagram in `atlas/tools/catalog.py`.

**7. F.3, `atlas/tools/catalog.py`.** The `execute_tool` docstring in the
delivered listing read:

```python
            arguments: A JSON object of that tool's arguments, as a string, for
                example {{"query": "Halden Labs"}}.
```

The doubled braces are a habit from `str.format` prompt templates and are wrong
here: a tool docstring is not a template, `parse_docstring` does no
substitution, and the doubled form is what the model sees in the advertised
schema. The corrected line is:

```python
            arguments: A JSON object of that tool's arguments, as a string, for
                example {"query": "Halden Labs"}.
```

Verified after the fix: the advertised description reads
`... for example {"query": "Halden Labs"}.`, the suite stays at 1257 passing,
and the measured token figures are unchanged (catalog 458 estimated tokens,
ratio 10.6x). The corrected file is what `atlas_appendix_f3.zip` ships.

It is a small defect and a representative one. The same two characters in
`atlas_sqlagent.v1.md` are *correct*, because that file really is a
`str.format` template — which is why the only reliable way to tell is to render
the artifact and read it, not to reason about it. Phase 3's contract test for
prompts exists for the template case; the docstring case has no such test, and
adding one (assert no `{{` survives into `spec.description`) is a three-line
improvement for anyone extending this appendix.

---

**End of Appendix F.1–F.3.** F.4 through F.8 — time travel and map-reduce, the
multi-agent supervisor, simulated users and online evaluation, the browser tool,
the second-framework port, and the full interview bank — are written in the two
later chats and can be read in any order.
