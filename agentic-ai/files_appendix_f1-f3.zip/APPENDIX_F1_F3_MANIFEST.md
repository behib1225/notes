# Appendix F.1–F.3 — companion code

Three snapshots, one per section. Each is a complete, runnable tree built on the
phase snapshot it plugs into, so you unzip one and work in it; you do not need
the others.

| file | built on | top-level dir | offline tests |
|---|---|---|---|
| `atlas_appendix_f1.zip` | `atlas_phase_04.zip` | `atlas-agent/` | 571 (from 536) |
| `atlas_appendix_f2.zip` | `atlas_phase_07.zip` | `atlas/` | 1119 (from 1074) |
| `atlas_appendix_f3.zip` | `atlas_phase_08.zip` | `atlas/` | 1257 (from 1220) |

Each snapshot opens with `APPENDIX_F1.md` / `_F2.md` / `_F3.md` at its root: a
one-page orientation naming the reading order, the commands, the assignment and
what is measured. Start there.

`appendix_f1_f3_solutions.md` covers the nine concept checks and all three
assignments. Read it after `make grade`, not before.

## Verify a snapshot

```bash
unzip atlas_appendix_f1.zip && cd atlas-agent
pip install -r requirements.txt
make test-offline                       # no network, no model
ATLAS_TIER=F python evals/run_appendix_f1.py   # the section's 3 eval tasks
ATLAS_TIER=F make demo PHASE=f1         # the measurement script, offline
make grade PHASE=f1                     # skips until you start the assignment
```

Substitute `f2` / `f3` and `evals/run_appendix_f2.py` / `_f3.py`. All three were
re-verified from these zips on a clean unpack.

## What each section adds

**F.1 CodeAct** — `atlas/agents/codeact.py` (replay bridge over the Phase 3
sandbox), `atlas/agents/codeact_audit.py` (assignment stub),
`atlas/prompts/files/atlas_codeact.v1.md` (checksum `367d0cbbe69c`),
`scripts/phasef1_results.py` (five-arm comparison), `tests/test_codeact.py` (35),
`tests/hidden/test_phasef1_a1.py`, `evals/tasks/appendix_f1.json` (3 tasks),
`evals/run_appendix_f1.py`.

**F.2 Text-to-SQL** — `atlas/flow/sqlprobe.py` (grain, fan-out and magnitude
probes), `atlas/flow/sqlagent.py` (the agent; drop-in for the Phase 7 route),
`atlas/flow/sqlprobe_extra.py` (assignment stub),
`atlas/flow/sql_examples.v1.json` (checksum `b83cee572f0b`),
`atlas/prompts/files/atlas_sqlagent.v1.md` (checksum `90389218fafc`),
`scripts/phasef2_results.py`, `tests/test_sqlagent.py` (45),
`tests/hidden/test_phasef2_a1.py`, `evals/tasks/appendix_f2.json` (3 tasks),
`evals/run_appendix_f2.py`.

**F.3 Many tools** — `scripts/gen_tools.py` (seeded 60-tool registry and
24-probe set), `atlas/tools/catalog.py` (search_tools / execute_tool /
execute_write_tool), `atlas/tools/catalog_rank.py` (assignment stub),
`evals/selection_eval.py` (model-free recall@k),
`scripts/phasef3_results.py`, `tests/test_catalog.py` (37),
`tests/hidden/test_phasef3_a1.py`, `evals/tasks/appendix_f3.json` (4 tasks: catalogue arm, flat arm, and the model-free selection ceiling),
`evals/run_appendix_f3.py`.

## Additive, and what that does and does not mean

No core module is modified in any of the three. A recursive diff against each
base snapshot shows only additions under `atlas/`, `scripts/`, `tests/` and
`evals/`, and `tests/test_sqlagent.py` asserts that `atlas/flow/dataq.py`
imports nothing from F.2. The core eval suites are untouched — 26, 41 and 45
tasks respectively, unchanged — because each section's task file is named
`appendix_fN.json` and does not match the `phase*.json` glob `load_tasks` uses.
`make results PHASE=fN` and `make grade PHASE=fN` work with no Makefile edit,
because the Makefile already parameterises on `PHASE`.

Three append-only documents do gain entries, which is what those files are for:
`atlas/prompts/CHANGELOG.md` (F.1 and F.2, one prompt each),
`docs/FAILURE_LOG.md` (one worked trace per section) and `docs/RESULTS.md` (a
placeholder table per section, with the executed Tier F figures labelled as
fixture arithmetic rather than measurements). Deleting a section means deleting
its files and those three blocks.

## Tier H

Capped at 300 calls per section, and every cell of every `make results
PHASE=fN` sweep is cached under `data/cache/appendix_fN/`, keyed on
(tier, model, seed, arm, cell). The tier is in the key on purpose: a Tier A
result and a Tier H result are different measurements (D-14), and a cache that
conflated them would let a hosted number be reported as a local one. Tier F is
never cached — a cached fixture is a way to hide a changed fixture.

Each section's results script carries a `[Tier H recommended]` note in its
header saying which column needs a stronger model and what Tier A still shows.
The three cache helpers are duplicated across the three scripts rather than
factored into a shared module, because a helper two sections import is a
section that cannot be deleted.

## Known, pre-existing

`tests/test_rag_generate.py` in the Phase 7 base emits an intermittent
`ResourceWarning` (an unclosed file at line 98). It predates F.2 — the
unmodified `atlas_phase_07.zip` reproduces it — and is left alone, because
this appendix does not edit core tests.

## What is measured and what is not

Every number in these snapshots that came from running code is real and was
executed: token estimates, recall@k, test counts, fixture-replayed grids. Every
number that would need a model is `____` in `docs/RESULTS.md` with the exact
command that fills it, and each `make results PHASE=fN` script refuses
`--append-results` on a fixture-replayed run. Nothing here has been measured
against a model, so treat the author estimates in each section as hypotheses.
