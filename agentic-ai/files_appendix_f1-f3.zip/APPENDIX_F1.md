# Appendix F.1 — CodeAct: Code-as-Action

**Read this if:** a job description mentions "code interpreter", "agentic
coding", or step-count cost.

This snapshot is `atlas_phase_04.zip` plus F.1. Nothing here needs anything
introduced after Phase 4, so you can work through it the moment you finish that
phase. Study time: 1.5 h read / 2.0 h build / 0.5 h assess. Cost $0.00.

## Do it in this order

1. **Read the module.** `atlas/agents/codeact.py`, top to bottom. The docstring
   states the one constraint the whole design turns on: the Phase 3 sandbox
   gives back exactly one channel (stdout) and one shot, and the tools live in
   the parent process. Everything else follows from that.
2. **Run the offline suite.** `make test-offline` — 571 tests, no network, no
   model. Then read `tests/test_codeact.py`, which is organised in the same
   order as the module.
3. **Watch the bridge work.** `ATLAS_TIER=F make demo PHASE=f1` runs the
   five-arm comparison on scripted fixtures. The token column is
   `FakeLLMClient`'s word count, not tokens; the `calls` and `launches` columns
   are real code behaviour and are the ones to read.
4. **Run the section's eval tasks.** `ATLAS_TIER=F python evals/run_appendix_f1.py`
5. **Reproduce the failure.** Write a snippet that iterates a `set` of strings
   and calls a tool inside the loop. Run it through `run_snippet` three times.
   The divergence report should name a different index on different runs; that
   instability is the diagnosis.
6. **Do the assignment.** `atlas/agents/codeact_audit.py`, then
   `make grade PHASE=f1`. Acceptance criteria are in the stub's docstring.

## What is measured and what is not

`make results PHASE=f1` on Tier A or H fills the `F1` rows in
`docs/RESULTS.md`. Nothing in this snapshot has been run against a model, so
every model-dependent figure is `_not yet measured_`. The Tier F grid measures
the fixtures, and the script refuses `--append-results` on a fixture run.

**[Tier H recommended]** for the CodeAct arm's accuracy column; see the header
of `scripts/phasef1_results.py` for why, and what Tier A still shows.

## Files F.1 adds

    atlas/agents/codeact.py                 the replay bridge and the loop
    atlas/agents/codeact_audit.py           YOUR ASSIGNMENT (stub)
    atlas/prompts/files/atlas_codeact.v1.md checksum 367d0cbbe69c
    scripts/phasef1_results.py              make results PHASE=f1
    tests/test_codeact.py                   35 tests, scripted fixtures
    tests/hidden/test_phasef1_a1.py         make grade PHASE=f1 — do not read
    evals/tasks/appendix_f1.json            3 eval tasks
    evals/run_appendix_f1.py                runs them

No core module is modified. `atlas/prompts/CHANGELOG.md`, `docs/FAILURE_LOG.md`
and `docs/RESULTS.md` gain entries, which is what those files are for.
