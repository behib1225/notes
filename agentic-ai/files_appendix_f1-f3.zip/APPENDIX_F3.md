# Appendix F.3 — Scaling to Many Tools

**Read this if:** you will integrate more than a few dozen tools, or any MCP
gateway.

This snapshot is `atlas_phase_08.zip` plus F.3. Nothing here needs anything
introduced after Phase 8. Study time: 1.0 h read / 1.5 h build / 0.5 h assess.
Cost $0.00.

## Do it in this order

1. **See the registry.** `python scripts/gen_tools.py --seed 7` prints sixty
   tools over six domains; `--probes` prints the 24 questions and the tool each
   should reach. Note how many tools differ only in a domain prefix and a noun.
2. **See the bill.** `ATLAS_TIER=F python scripts/phasef3_results.py` prints
   two blocks that are deterministic CODE and are real at every tier: the
   static token cost of the tool list (4851 flat / 1516 level-1 index / 458
   catalogue) and recall@k of `search_tools` split by difficulty. Only
   end-to-end selection accuracy needs a model, and the script refuses to fake
   it.
3. **Read `atlas/tools/catalog.py`.** Its docstring diagrams the three levels
   and states the one property indirection destroys: per-tool identity at the
   gate. The two-door split is the repair, and a test pins it.
4. **Run the offline suite** (`make test-offline`, 1257 tests) and read
   `tests/test_catalog.py`.
5. **Run the eval tasks.** `ATLAS_TIER=F python evals/run_appendix_f3.py` — four
   tasks, one of which is the flat "before" arm and one the catalogue "after"
   arm over the same question.
6. **Reproduce the failure.** Search the catalogue for
   `"find out who owns tickets"` and print the scores. The margin is 0.00 and
   the right tool is ranked sixth with k=5; the tie is broken alphabetically by
   a sort added in Phase 3 for cache-key stability.
7. **Do the assignment.** `atlas/tools/catalog_rank.py`, then
   `make grade PHASE=f3`.

## The cheapest improvement is not the ranker

Before reaching for a better scorer, put the user's vocabulary into the tool
DESCRIPTIONS and re-measure with `evals/selection_eval.py`. Phase 3 already
established that tool descriptions dominate tool-call accuracy; this is the
same finding at sixty tools, and you can test it in an afternoon with no model.

**[Tier H recommended]** for the probe sweep — the flat arm may not fit in a
small local model's context at all, which is a result worth recording rather
than a reason to drop the arm.

## Files F.3 adds

    scripts/gen_tools.py             seeded 60-tool registry and 24 probes
    atlas/tools/catalog.py           search_tools / execute_tool / execute_write_tool
    atlas/tools/catalog_rank.py      YOUR ASSIGNMENT (stub)
    evals/selection_eval.py          model-free recall@k by difficulty
    scripts/phasef3_results.py       make results PHASE=f3
    tests/test_catalog.py            37 tests, seeded registry and fixtures
    tests/hidden/test_phasef3_a1.py  make grade PHASE=f3 — do not read
    evals/tasks/appendix_f3.json     4 eval tasks, before and after arms
    evals/run_appendix_f3.py         runs them

No core module is modified. Where this goes next is Phase 12: a gateway does
this across servers, and its tool-discovery API has this shape for this reason.
