# Appendix F.2 — Text-to-SQL Agents

**Read this if:** your target role touches analytics or BI.

This snapshot is `atlas_phase_07.zip` plus F.2. Nothing here needs anything
introduced after Phase 7. Study time: 2.0 h read / 2.5 h build / 0.5 h assess.
Cost $0.00.

## Do it in this order

1. **See the failure first.** Run these two queries against
   `data/atlas_query.db` and compare:

       SELECT sum(units) FROM v_shipments WHERE quarter='2026Q1';
       SELECT sum(s.units) FROM v_shipments s
         JOIN v_warranty w ON w.sku=s.sku AND w.quarter=s.quarter
        WHERE s.quarter='2026Q1';

   363 against 924. The second reads the right relations, carries the right
   filter and returns rows. Nothing in the statement is wrong.
2. **Read `atlas/flow/sqlprobe.py`.** Its docstring has an ASCII diagram of
   exactly that fan-out with the real seeded numbers. This module runs SQL to
   contradict SQL; the point is that the defect is a fact about DATA and is
   invisible in the statement.
3. **Look at the grounding.**
   `python -c "from atlas.flow.sqlprobe import describe_schema_grounded as d; print(d('data/atlas_query.db'))"`
   Read the last line of `v_warranty`. That sentence is the whole appendix.
4. **Read `atlas/flow/sqlagent.py`,** then `make test-offline` (1119 tests) and
   `tests/test_sqlagent.py`.
5. **Run both arms.** `ATLAS_TIER=F python scripts/phasef2_results.py --show`
   Both arms replay the SAME drafts, so the difference is the verifier and the
   repair, not the SQL.
6. **Run the eval tasks.** `ATLAS_TIER=F python evals/run_appendix_f2.py`
7. **Do the assignment.** `atlas/flow/sqlprobe_extra.py`, then
   `make grade PHASE=f2`. It catches the two defects the repair loop slipped
   through, which is the trace at the end of the section.

## The habit worth taking away

Re-run any data grader at a second seed before believing it. The `DISTINCT`
pseudo-repair in the section is *correct* at seed 7, wrong by 26 at seed 8, and
missing a whole row at seeds 9 and 11. Regenerate with
`python scripts/gen_dataset.py --seed 8` and check for yourself.

**[Tier H recommended]** for the drafting half; see the header of
`scripts/phasef2_results.py` for what Tier A still shows.

## Files F.2 adds

    atlas/flow/sqlprobe.py                    grain, fan-out and magnitude probes
    atlas/flow/sqlagent.py                    the agent; drop-in for the Phase 7 route
    atlas/flow/sqlprobe_extra.py              YOUR ASSIGNMENT (stub)
    atlas/flow/sql_examples.v1.json           few-shot bank, checksum b83cee572f0b
    atlas/prompts/files/atlas_sqlagent.v1.md  checksum 90389218fafc
    scripts/phasef2_results.py                make results PHASE=f2
    tests/test_sqlagent.py                    45 tests, scripted fixtures
    tests/hidden/test_phasef2_a1.py           make grade PHASE=f2 — do not read
    evals/tasks/appendix_f2.json              3 eval tasks
    evals/run_appendix_f2.py                  runs them

No core module is modified, and a test asserts that `atlas/flow/dataq.py`
imports nothing from this appendix.
