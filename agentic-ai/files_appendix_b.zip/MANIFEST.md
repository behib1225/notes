# Appendix B — files

Everything Appendix B adds to Atlas. **Additive only**: no file from
`atlas_phase_16.zip` is renamed, re-signatured or changed. Delete
`atlas/backends/`, `scripts/appendix_b_*.py`, `tests/*appendix_b*` and
`evals/tasks/phase16b-appendix-b.json` and the repository is back at Phase 16.

## Install

Unzip over your Phase 16 tree, preserving paths:

```
atlas/backends/          -> atlas/backends/
scripts/                 -> scripts/
tests/                   -> tests/
tests/hidden/            -> tests/hidden/
evals/tasks/             -> evals/tasks/
```

Then verify, offline and for free:

```bash
ATLAS_TIER=F python3 -m pytest tests/test_appendix_b_plan.py \
    tests/test_appendix_b_backends.py -q          # expect 67 passed with the
                                                  # two hidden files included
python3 -c "from atlas.backends.audit import verify_capabilities as v; \
            print(v('.').model_dump())"           # expect 0 leaks, 0 undated,
                                                  # 0 price literals, 0 fake cards
```

## Files

| Path | Lines | What it is |
|---|---|---|
| `atlas/backends/__init__.py` | 33 | the package's public surface |
| `atlas/backends/features.py` | 309 | declared / probed / effective capabilities, with dates |
| `atlas/backends/messages_api.py` | 415 | the second request dialect: pure `build_body`, pure parse, cache breakpoints |
| `atlas/backends/caching.py` | 211 | cache economics; no price or multiplier is a constant |
| `atlas/backends/config.py` | 244 | `ATLAS_B_*` settings, `MeteredClient`, the wrapped client factory |
| `atlas/backends/audit.py` | 191 | the appendix's three claims, checked from the source tree |
| `atlas/backends/layout.py` | 174 | **Assignment 1 reference solution** |
| `atlas/backends/probe.py` | 293 | **Assignment 2 reference solution** |
| `scripts/appendix_b_plan.py` | 527 | spending plan, pre-flight, ledger, reconciliation |
| `scripts/appendix_b_probe.py` | 255 | paid exercises B1–B4 |
| `scripts/appendix_b_validate.py` | 286 | the three validation runs B5–B7 |
| `tests/test_appendix_b_plan.py` | 147 | 14 offline tests |
| `tests/test_appendix_b_backends.py` | 369 | 36 offline tests |
| `tests/hidden/test_appendix_b_a1.py` | 84 | Assignment 1 grader |
| `tests/hidden/test_appendix_b_a2.py` | 99 | Assignment 2 grader |
| `evals/tasks/phase16b-appendix-b.json` | — | 3 eval tasks, 12 checks |

**If you want to attempt the assignments**, delete `atlas/backends/layout.py`
and `atlas/backends/probe.py` first. Both hidden test files use
`importlib.util.find_spec` / `pytest.importorskip`, so they report as *skipped*
rather than as errors until you create the modules. Note that exercise B2
(`--only features`) calls `atlas.backends.probe`, so it needs Assignment 2 done
or the reference solution present.

The file name `evals/tasks/phase16b-appendix-b.json` matters: `evals.run.
load_tasks` globs `phase*.json`, so a file named `appendix_b.json` would load
in no suite and grade nothing, silently.

## Commands

Nothing below sends a request without `--go`, and every runner prints its
estimate and its stop rule first.

```bash
# free
python3 scripts/appendix_b_plan.py --write-card --checked-on YYYY-MM-DD
python3 scripts/appendix_b_plan.py --preflight
python3 scripts/appendix_b_plan.py --plan --ceiling 25
python3 scripts/appendix_b_probe.py --only caching          # dry run
python3 scripts/appendix_b_validate.py --run strategies     # dry run

# paid
python3 scripts/appendix_b_probe.py    --only hello --go
python3 scripts/appendix_b_probe.py    --only features --go
python3 scripts/appendix_b_probe.py    --only caching --calls 10 --go
python3 scripts/appendix_b_probe.py    --only longctx --go
python3 scripts/appendix_b_validate.py --run multiagent --go --append-results
python3 scripts/appendix_b_validate.py --run judge      --go --append-results
python3 scripts/appendix_b_validate.py --run strategies --go --append-results

# afterwards
python3 scripts/appendix_b_plan.py --reconcile
python3 scripts/appendix_b_plan.py --invoice AMOUNT --period YYYY-MM --read-on YYYY-MM-DD
python3 scripts/appendix_b_plan.py --reconcile
```

No Makefile target is added. A target is an edit to an existing file, and this
appendix is removable.

## Environment

Disjoint from `ATLAS_H_*` on purpose: a paid key sharing a variable with a free
one gets spent by accident.

| Variable | Required | Meaning |
|---|---|---|
| `ATLAS_B_BASE_URL` | yes | provider base URL |
| `ATLAS_B_MODEL` | yes | model id |
| `ATLAS_B_API_KEY` | yes | a key created for this appendix and revoked after |
| `ATLAS_B_DIALECT` | no | `openai_compat` (default) or `messages` |
| `ATLAS_B_API_VERSION` | no | required by the Messages dialect |
| `ATLAS_B_CALL_CAP` | no | default 120 |
| `ATLAS_B_TOKEN_CAP` | no | default 400,000 |
| `ATLAS_B_CACHE_STATIC` | no | default on |
| `ATLAS_B_CHECKED_ON` | no | the date you last probed capabilities; defaults to 1970-01-01 so an unchecked backend announces itself |
| `ATLAS_B_RATE_CARD` | no | default `data/rate_cards/tier_b.json` |

`ATLAS_TIER=B` is **not** used and still raises in `atlas/config.py`. That
refusal is what keeps the core free, and an eval task asserts it survives.

## Data files this creates (none are shipped)

- `data/rate_cards/tier_b.json` — you write it, dated, from a pricing page.
- `data/appendix_b_ledger.jsonl` — append-only, one measured run per line.
- `data/appendix_b_invoice.json` — what the provider's usage page said.

None is included here, deliberately. An earlier draft shipped an illustrative
card with invented rates; the audit now fails the suite if a card with non-zero
rates and a placeholder or example-domain source ever appears under `data/`.

## Revision 2 — what changed

| Defect | Fix |
|---|---|
| Cache breakpoint marked the last **tool**, excluding the system prompt from the cached prefix — and a test and an eval task certified it | Marker moves to the last **system** block; tool only as fallback. `F-B-02` |
| Reconciliation could never show measured tokens | `MeteredClient` inside the cache, outside the budget; `spend_from_meter()` |
| `usd` column stamped the whole run's cost on every row | `per_row_usd()` divides the measured run cost across its rows |
| `scripts/appendix_b_probe.py`, `--probe`, `--record` were referenced but absent | Probe script written (B1–B4); phantom flags removed |
| Six of nine plan rows had no runner | Plan reduced to seven runnable exercises; batch and server-side tools taught, not planned |
| Audit checks that could not fail | Broader claim detection, wider price regex, `data/` scanned for fabricated rate cards |
| `probe_plan` ignored its argument; no-op filter; bare `assert` | `declared` flag attached to each entry |
| Unstable-prefix penalty multiplied the whole prompt | `CacheScenario.stable`; only the marked prefix pays the write premium (+23.3%, not +25%) |
| A missing rate card produced a `FileNotFoundError` traceback on the first command a reader runs | `require_card()` prints the command that creates one and exits 2 |

## Known limitation, stated

`scripts/phase04_results.py` calls its own `append_results(rows, settings)`
against a three-parameter definition — a `TypeError` reachable only with
`--append-results` on a paying tier, which no offline test can take. Logged as
**F-B-01**. Not patched here, because Appendix B does not edit core files;
`scripts/appendix_b_validate.py` writes its own rows. The fix in your own copy
is one argument at one call site.
