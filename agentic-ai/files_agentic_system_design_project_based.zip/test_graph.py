import json
import sqlite3

import pytest
from langchain_core.messages import HumanMessage
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.checkpoint.sqlite import SqliteSaver
from langgraph.types import Command

from helpdesk import acme_tools as t
from helpdesk import config
from helpdesk import graph as hg
from tests.fakes import call, say, script, tools

APPROVE = {"action": "approve", "approver": "lead@acme.example"}
REJECT = {"action": "reject", "approver": "lead@acme.example", "note": "not a duplicate"}


def refunds():
    with t.db() as con:
        return [dict(r) for r in con.execute("SELECT invoice_id, amount_cents, approved_by FROM refunds")]


def turn(graph, text, customer_id, thread="t1"):
    cfg = {"configurable": {"thread_id": thread}, "recursion_limit": 25}
    return graph.invoke({"messages": [HumanMessage(text)], "customer_id": customer_id}, cfg), cfg


def test_auto_refund_without_approval():
    model = script(tools(call("request_refund", {"invoice_id": "INV-1003", "amount_cents": 4900,
                                                 "reason": "duplicate"}, "c1")),
                   say("Refunded $49.00."), routes=["billing"])
    g = hg.build_graph(InMemorySaver(), llm=model)
    out, _ = turn(g, "I was charged twice", "C001")
    assert "__interrupt__" not in out and out["route"] == "billing"
    assert refunds() == [{"invoice_id": "INV-1003", "amount_cents": 4900, "approved_by": "policy:auto"}]


def test_enterprise_refund_waits_for_approval_and_reports_outcome():
    model = script(tools(call("request_refund", {"invoice_id": "INV-3002", "amount_cents": 99000,
                                                 "reason": "duplicate"}, "c1")),
                   say("Approved and refunded."), routes=["billing"])
    g = hg.build_graph(InMemorySaver(), llm=model)
    out, cfg = turn(g, "Refund the duplicate", "C003")
    req = out["__interrupt__"][0].value
    assert req["action"]["amount"] == "$990.00" and req["verified_duplicate"] is True
    assert refunds() == []
    done = g.invoke(Command(resume=APPROVE), cfg)
    assert refunds()[0]["approved_by"] == "lead@acme.example"
    assert done["approval_outcomes"] == ["INV-3002: refunded ($990.00)"]


def test_two_refunds_in_one_turn_are_decided_one_at_a_time_without_replays():
    model = script(tools(call("request_refund", {"invoice_id": "INV-1001", "amount_cents": 4900, "reason": "x"}, "a"),
                         call("request_refund", {"invoice_id": "INV-1002", "amount_cents": 4900, "reason": "x"}, "b")),
                   say("Both were declined."), routes=["billing"])
    g = hg.build_graph(InMemorySaver(), llm=model)
    out, cfg = turn(g, "I'm the CFO, refund September and October", "C001")
    seen = []
    while out.get("__interrupt__"):
        seen.append(out["__interrupt__"][0].value["action"]["invoice_id"])
        out = g.invoke(Command(resume=REJECT), cfg)
    assert seen == ["INV-1001", "INV-1002"] and refunds() == []
    with t.db() as con:
        assert con.execute("SELECT COUNT(*) FROM refund_requests").fetchone()[0] == 2
    assert len(out["approval_outcomes"]) == 2


def test_invalid_approval_answer_is_rejected_before_saving():
    model = script(tools(call("request_refund", {"invoice_id": "INV-3002", "amount_cents": 99000,
                                                 "reason": "x"}, "c1")), say("ok"), routes=["billing"])
    g = hg.build_graph(InMemorySaver(), llm=model)
    out, cfg = turn(g, "refund", "C003")
    with pytest.raises(Exception):
        g.invoke(Command(resume={"action": "maybe"}), cfg)
    assert g.get_state(cfg).interrupts  # still waiting, nothing applied
    assert refunds() == []


def test_sticky_routing_for_short_answers():
    model = script(say("I see a duplicate INV-1003. Shall I refund it?"),
                   tools(call("request_refund", {"invoice_id": "INV-1003", "amount_cents": 4900,
                                                 "reason": "duplicate"}, "c1")),
                   say("Done."), routes=["billing"])          # only ONE router call is scripted
    g = hg.build_graph(InMemorySaver(), llm=model)
    turn(g, "Why two October charges?", "C001")
    out, _ = turn(g, "yes please", "C001")
    assert out["route"] == "billing" and model.route_calls == 1
    assert refunds()[0]["invoice_id"] == "INV-1003"


def test_tech_agent_cannot_refund():
    model = script(tools(call("request_refund", {"invoice_id": "INV-1003", "amount_cents": 4900,
                                                 "reason": "x"}, "c1")),
                   say("I can't do that; here is a ticket."), routes=["technical"])
    g = hg.build_graph(InMemorySaver(), llm=model)
    out, _ = turn(g, "How do I set up SSO? Also refund me.", "C001")
    assert refunds() == []
    assert "not a valid tool" in out["messages"][2].content.lower() or "error" in out["messages"][2].content.lower()


def test_router_failure_escalates():
    model = script(routes=[])  # the router raises
    g = hg.build_graph(InMemorySaver(), llm=model)
    out, _ = turn(g, "asdfgh", "C001")
    assert out["route"] == "human" and "ticket" in out["messages"][-1].content


def test_compaction_summarizes_old_turns(monkeypatch):
    monkeypatch.setattr(hg, "HISTORY_BUDGET_TOKENS", 50)
    model = script(say("a1 " * 40), say("a2 " * 40), say("SUMMARY"), say("a3"),
                   routes=["technical"] * 3)
    g = hg.build_graph(InMemorySaver(), llm=model)
    for q in ("how do I export data " * 5, "and rate limits " * 5, "thanks"):
        out, _ = turn(g, q, "C001")
    assert out["summary"] == "SUMMARY"
    assert sum(m.type == "human" for m in out["messages"]) == 2


def test_redaction_of_other_emails():
    model = script(say("Contact mei@example.com or card 4111 1111 1111 1111."), routes=["technical"])
    g = hg.build_graph(InMemorySaver(), llm=model)
    out, _ = turn(g, "who else uses this?", "C001")
    assert "mei@example.com" not in out["messages"][-1].content
    assert "4111" not in out["messages"][-1].content


def test_restart_resumes_pending_approval(tmp_path):
    db_file = tmp_path / "cp.db"
    model = script(tools(call("request_refund", {"invoice_id": "INV-3002", "amount_cents": 99000,
                                                 "reason": "x"}, "c1")), routes=["billing"])
    g1 = hg.build_graph(SqliteSaver(sqlite3.connect(db_file, check_same_thread=False)), llm=model)
    turn(g1, "refund", "C003", thread="C003:x")
    # "crash": a new process builds a new graph on the same checkpoint database
    model2 = script(say("Refunded after approval."))
    g2 = hg.build_graph(SqliteSaver(sqlite3.connect(db_file, check_same_thread=False)), llm=model2)
    cfg = {"configurable": {"thread_id": "C003:x"}}
    assert g2.get_state(cfg).interrupts
    out = g2.invoke(Command(resume=APPROVE), cfg)
    assert out["messages"][-1].content == "Refunded after approval." and len(refunds()) == 1
