"""Hybrid retrieval over the Acme knowledge base: BM25 + embeddings, fused with RRF."""
import json
import re

import numpy as np
from openai import OpenAI
from rank_bm25 import BM25Okapi

from helpdesk import config

_client = OpenAI(base_url=config.LLM_BASE_URL, api_key=config.LLM_API_KEY)


def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())


def chunk_markdown(doc_id: str, text: str, max_chars: int = 600, overlap: int = 1) -> list[dict]:
    first = text.strip().splitlines()[0]
    title = first.lstrip("#").strip() if first.startswith("#") else doc_id
    chunks: list[str] = []
    for section in re.split(r"\n(?=#{1,3} )", text.strip()):
        sentences = [s.strip() for s in re.split(r"(?<=[.!?])\s+|\n+", section)]
        sentences = [s for s in sentences if s and not s.startswith("#")]
        buf: list[str] = []
        for s in sentences:
            if buf and len(" ".join(buf + [s])) > max_chars:
                chunks.append(" ".join(buf))
                buf = buf[-overlap:] if overlap else []
            buf.append(s)
        if buf:
            chunks.append(" ".join(buf))
    return [{"chunk_id": f"{doc_id}#{i}", "doc_id": doc_id, "title": title,
             "text": f"{title}: {c}"} for i, c in enumerate(chunks)]


def load_chunks() -> list[dict]:
    chunks: list[dict] = []
    for path in sorted(config.KB_DIR.glob("*.md")):
        chunks += chunk_markdown(path.stem, path.read_text(encoding="utf-8"))
    return chunks


def embed(texts: list[str], kind: str) -> np.ndarray:
    if "nomic" in config.EMBED_MODEL:
        prefix = "search_query: " if kind == "query" else "search_document: "
        texts = [prefix + t for t in texts]
    resp = _client.embeddings.create(model=config.EMBED_MODEL, input=texts)
    vecs = np.array([d.embedding for d in resp.data], dtype=np.float32)
    return vecs / np.linalg.norm(vecs, axis=1, keepdims=True)


def build_index() -> None:
    chunks = load_chunks()
    vecs = embed([c["text"] for c in chunks], kind="document")
    config.INDEX_DIR.mkdir(parents=True, exist_ok=True)
    np.save(config.INDEX_DIR / "vectors.npy", vecs)
    (config.INDEX_DIR / "chunks.json").write_text(json.dumps(chunks, indent=1), encoding="utf-8")
    print(f"Indexed {len(chunks)} chunks, dim={vecs.shape[1]}")


def rrf(rankings: list[list[int]], k: int = 60) -> list[int]:
    scores: dict[int, float] = {}
    for ranking in rankings:
        for rank, idx in enumerate(ranking, start=1):
            scores[idx] = scores.get(idx, 0.0) + 1.0 / (k + rank)
    return sorted(scores, key=scores.get, reverse=True)


class HybridRetriever:
    """BM25 always works; dense and hybrid modes need the embedding index."""

    def __init__(self):
        index = config.INDEX_DIR / "chunks.json"
        if index.is_file():
            self.chunks = json.loads(index.read_text(encoding="utf-8"))
            self.vecs = np.load(config.INDEX_DIR / "vectors.npy")
        else:
            self.chunks, self.vecs = load_chunks(), None
        self.bm25 = BM25Okapi([tokenize(c["text"]) for c in self.chunks])

    def bm25_rank(self, query: str, n: int = 20) -> list[int]:
        scores = self.bm25.get_scores(tokenize(query))
        return [int(i) for i in np.argsort(-scores)[:n] if scores[i] > 0]

    def dense_rank(self, query: str, n: int = 20) -> list[int]:
        if self.vecs is None:
            raise RuntimeError("No embedding index. Run: uv run python -m helpdesk.rag")
        sims = self.vecs @ embed([query], kind="query")[0]
        return [int(i) for i in np.argsort(-sims)[:n]]

    def search(self, query: str, k: int = 4, mode: str | None = None) -> list[dict]:
        mode = mode or config.retrieval_mode()
        if mode == "bm25":
            ranked = self.bm25_rank(query)
        elif mode == "dense":
            ranked = self.dense_rank(query)
        else:
            ranked = rrf([self.bm25_rank(query), self.dense_rank(query)])
        return [self.chunks[i] for i in ranked[:k]]


if __name__ == "__main__":
    build_index()
