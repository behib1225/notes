import asyncio
import json
import sys

from fastmcp import Client

from helpdesk.mcp_client import MCPToolset
from helpdesk.mcp_server import mcp


def test_in_process_server_tools_and_resource():
    async def go():
        async with Client(mcp) as c:
            names = {t.name for t in await c.list_tools()}
            res = await c.call_tool("search_kb", {"query": "SSO Okta"})
            doc = await c.read_resource("kb://sso-setup")
            return names, res, doc
    names, res, doc = asyncio.run(go())
    assert names == {"search_kb", "create_ticket"}
    assert res.data["results"][0]["doc_id"] == "sso-setup"
    assert "Enterprise plan only" in doc[0].text


def test_adapter_over_stdio_subprocess():
    async def go():
        async with MCPToolset("helpdesk/mcp_server.py") as tools:
            schemas = await tools.schemas()
            ok = await tools.run("search_kb", json.dumps({"query": "API rate limits"}))
            bad = await tools.run("search_kb", "{}")
            return schemas, ok, bad
    schemas, ok, bad = asyncio.run(go())
    assert {s["function"]["name"] for s in schemas} == {"search_kb", "create_ticket"}
    assert json.loads(ok)["results"][0]["doc_id"] == "api-rate-limits"
    assert "error" in json.loads(bad)
