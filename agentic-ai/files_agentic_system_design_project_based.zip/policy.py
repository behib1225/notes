"""Refund policy as code. The model can propose a refund; only this module decides
whether it is allowed, auto-approved, or needs a billing lead."""
import datetime as dt
from dataclasses import dataclass, field

from helpdesk import config, guards
from helpdesk.acme_tools import db, money

AUTO_APPROVE_LIMIT_CENTS = 5000
REFUND_WINDOW_DAYS = 60
MAX_AUTO_REFUNDS_PER_DAY = 1


@dataclass
class Assessment:
    allowed: bool
    code: str = "ok"
    message: str = ""
    approval_reasons: list[str] = field(default_factory=list)
    verified_duplicate: bool = False
    invoice: dict | None = None

    @property
    def needs_approval(self) -> bool:
        return bool(self.approval_reasons)


def is_verified_duplicate(con, invoice_id: str) -> bool:
    """True if an earlier paid invoice for the same customer has the same description and
    amount within 7 days. Only the later invoice of the pair counts as the duplicate."""
    return con.execute("""
        SELECT 1 FROM invoices a JOIN invoices b
          ON b.customer_id = a.customer_id AND b.id <> a.id
         AND b.description = a.description AND b.amount_cents = a.amount_cents
         AND b.status = 'paid' AND a.status = 'paid'
         AND abs(julianday(a.issued_at) - julianday(b.issued_at)) <= 7
         AND (b.issued_at < a.issued_at OR (b.issued_at = a.issued_at AND b.id < a.id))
        WHERE a.id = ?""", (invoice_id,)).fetchone() is not None


def assess(con, customer_id: str, invoice_id: str, amount_cents: int) -> Assessment:
    inv = con.execute("SELECT i.*, c.plan FROM invoices i JOIN customers c "
                      "ON c.id = i.customer_id WHERE i.id = ?", (invoice_id,)).fetchone()
    if inv is None or inv["customer_id"] != customer_id:
        return Assessment(False, "not_found", f"No invoice {invoice_id} on this account.")
    if inv["status"] != "paid":
        return Assessment(False, "not_refundable",
                          f"Invoice is {inv['status']}; no money was collected.")
    committed = con.execute(
        "SELECT COALESCE(SUM(amount_cents), 0) FROM refund_requests WHERE invoice_id = ? "
        "AND status IN ('pending', 'approved', 'refunded')", (invoice_id,)).fetchone()[0]
    remaining = inv["amount_cents"] - committed
    if not 0 < amount_cents <= remaining:
        return Assessment(False, "invalid_amount", f"Refundable balance is {money(remaining)}.")

    verified = is_verified_duplicate(con, invoice_id)
    age_days = (config.today() - dt.date.fromisoformat(inv["issued_at"])).days
    auto_today = con.execute(
        "SELECT COUNT(*) FROM refunds r JOIN invoices i ON i.id = r.invoice_id "
        "WHERE i.customer_id = ? AND r.approved_by = 'policy:auto' AND r.created_on = ?",
        (customer_id, config.today().isoformat())).fetchone()[0]

    reasons = []
    if amount_cents > AUTO_APPROVE_LIMIT_CENTS:
        reasons.append("amount over $50.00")
    if inv["plan"] == "enterprise":
        reasons.append("Enterprise customer")
    if not verified:
        reasons.append("not a verified duplicate charge")
    elif age_days > REFUND_WINDOW_DAYS:
        reasons.append(f"charge is {age_days} days old (policy window is {REFUND_WINDOW_DAYS})")
    if auto_today >= MAX_AUTO_REFUNDS_PER_DAY:
        reasons.append("daily auto-approval limit reached for this customer")
    return Assessment(True, approval_reasons=reasons, verified_duplicate=verified,
                      invoice=dict(inv))


def _describe(row) -> dict:
    status = {"pending": "pending_approval"}.get(row["status"], row["status"])
    out = {"request_id": row["id"], "invoice_id": row["invoice_id"],
           "amount": money(row["amount_cents"]), "status": status,
           "policy": row["policy_reason"]}
    if row["note"]:
        out["note"] = row["note"]
    return out


def _execute(con, request_id: str, approver: str) -> None:
    """Exactly-once: the UNIQUE request_id makes a repeated call a no-op."""
    req = con.execute("SELECT * FROM refund_requests WHERE id = ?", (request_id,)).fetchone()
    con.execute("INSERT OR IGNORE INTO refunds (request_id, invoice_id, amount_cents, approved_by, "
                "created_on) VALUES (?,?,?,?,?)", (request_id, req["invoice_id"],
                req["amount_cents"], approver, config.today().isoformat()))
    con.execute("UPDATE refund_requests SET status = 'refunded', decided_by = ? WHERE id = ?",
                (approver, request_id))


def request_refund(thread_id: str, customer_id: str, invoice_id: str, amount_cents: int,
                   reason: str) -> dict:
    """Create (or replay) a refund request. Safe to call any number of times."""
    if not guards.writes_enabled():
        return {"error": "disabled", "message": "Refunds are temporarily disabled. Create a ticket."}
    request_id = f"{thread_id}:{invoice_id}:{amount_cents}"
    with db() as con:
        existing = con.execute("SELECT * FROM refund_requests WHERE id = ?", (request_id,)).fetchone()
        if existing:  # a retry or a replay returns the same answer as the first call
            return _describe(existing)
        a = assess(con, customer_id, invoice_id, amount_cents)
        if not a.allowed:
            return {"error": a.code, "message": a.message}
        policy_reason = "; ".join(a.approval_reasons) or "auto-approved: verified duplicate under $50"
        con.execute("INSERT INTO refund_requests (id, thread_id, customer_id, invoice_id, "
                    "amount_cents, reason, verified_duplicate, policy_reason, status, created_on) "
                    "VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (request_id, thread_id, customer_id, invoice_id, amount_cents, reason[:300],
                     int(a.verified_duplicate), policy_reason,
                     "pending" if a.needs_approval else "approved", config.today().isoformat()))
        if not a.needs_approval:
            _execute(con, request_id, "policy:auto")
        row = con.execute("SELECT * FROM refund_requests WHERE id = ?", (request_id,)).fetchone()
    return _describe(row)


def pending_requests(thread_id: str | None = None) -> list[dict]:
    sql = "SELECT * FROM refund_requests WHERE status = 'pending'"
    params: tuple = ()
    if thread_id:
        sql, params = sql + " AND thread_id = ?", (thread_id,)
    with db() as con:
        # Deterministic order: parallel tool calls insert in a random order.
        return [dict(r) for r in con.execute(sql + " ORDER BY created_on, invoice_id, id", params)]


def approval_payload(req: dict) -> dict:
    """What the billing lead sees: the raw action and the evidence, not the agent's pitch."""
    with db() as con:
        inv = con.execute("SELECT i.*, c.plan, c.name FROM invoices i JOIN customers c "
                          "ON c.id = i.customer_id WHERE i.id = ?", (req["invoice_id"],)).fetchone()
        history = [dict(r) for r in con.execute(
            "SELECT r.invoice_id, r.amount_cents, r.approved_by, r.created_on FROM refunds r "
            "JOIN invoices i ON i.id = r.invoice_id WHERE i.customer_id = ?", (req["customer_id"],))]
    return {"type": "refund_approval", "request_id": req["id"],
            "action": {"tool": "refund", "invoice_id": req["invoice_id"],
                       "amount_cents": req["amount_cents"], "amount": money(req["amount_cents"])},
            "customer": {"id": req["customer_id"], "name": inv["name"], "plan": inv["plan"]},
            "invoice": {"issued_at": inv["issued_at"], "description": inv["description"],
                        "amount": money(inv["amount_cents"]), "status": inv["status"]},
            "verified_duplicate": bool(req["verified_duplicate"]),
            "why_review": req["policy_reason"],
            "agent_reason_unverified": req["reason"],
            "refund_history": history}


def apply_decision(request_id: str, action: str, approver: str, note: str = "",
                   amount_cents: int | None = None) -> dict:
    """Idempotent: deciding an already-decided request returns its current state."""
    with db() as con:
        req = con.execute("SELECT * FROM refund_requests WHERE id = ?", (request_id,)).fetchone()
        if req is None:
            raise ValueError(f"Unknown refund request {request_id}")
        if req["status"] == "pending":
            if action == "reject":
                con.execute("UPDATE refund_requests SET status = 'rejected', decided_by = ?, "
                            "note = ? WHERE id = ?", (approver, note or "no reason given", request_id))
            else:
                if action == "edit":
                    if amount_cents is None or not 0 < amount_cents <= req["amount_cents"]:
                        raise ValueError("An edit may only lower the refund amount.")
                    con.execute("UPDATE refund_requests SET amount_cents = ?, note = ? WHERE id = ?",
                                (amount_cents, note or "amount edited by approver", request_id))
                _execute(con, request_id, approver)
        row = con.execute("SELECT * FROM refund_requests WHERE id = ?", (request_id,)).fetchone()
    return _describe(row)
