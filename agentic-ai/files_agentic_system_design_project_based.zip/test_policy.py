import pytest

from helpdesk import acme_tools as t
from helpdesk import policy


def rows(sql):
    with t.db() as con:
        return [dict(r) for r in con.execute(sql)]


def test_small_verified_duplicate_is_auto_refunded_once():
    first = policy.request_refund("th", "C001", "INV-1003", 4900, "duplicate")
    again = policy.request_refund("th", "C001", "INV-1003", 4900, "duplicate")
    assert first == again and first["status"] == "refunded"
    assert rows("SELECT approved_by FROM refunds") == [{"approved_by": "policy:auto"}]


@pytest.mark.parametrize("customer, invoice, cents, reason", [
    ("C003", "INV-3002", 99000, "Enterprise"),               # enterprise and over $50
    ("C001", "INV-1001", 4900, "not a verified duplicate"),  # a legitimate charge
    ("C002", "INV-2002", 1500, "days old"),                  # duplicate outside 60 days
])
def test_cases_that_need_a_billing_lead(customer, invoice, cents, reason):
    out = policy.request_refund("th", customer, invoice, cents, "x")
    assert out["status"] == "pending_approval" and reason in out["policy"]
    assert rows("SELECT * FROM refunds") == []


@pytest.mark.parametrize("customer, invoice, cents, code", [
    ("C002", "INV-1003", 4900, "not_found"),       # another customer's invoice
    ("C004", "INV-4001", 4900, "not_refundable"),  # failed payment
    ("C001", "INV-1003", 9999, "invalid_amount"),  # more than was paid
])
def test_guards(customer, invoice, cents, code):
    assert policy.request_refund("th", customer, invoice, cents, "x")["error"] == code


def test_pending_requests_count_against_the_balance():
    policy.request_refund("a", "C003", "INV-3002", 99000, "x")
    assert policy.request_refund("b", "C003", "INV-3002", 99000, "x")["error"] == "invalid_amount"


def test_daily_auto_approval_cap():
    policy.request_refund("th", "C001", "INV-1003", 2000, "partial")
    second = policy.request_refund("th", "C001", "INV-1003", 2900, "rest")
    assert second["status"] == "pending_approval" and "daily" in second["policy"]


def test_decisions_are_idempotent_and_edits_only_lower():
    rid = policy.request_refund("th", "C003", "INV-3002", 99000, "x")["request_id"]
    with pytest.raises(ValueError):
        policy.apply_decision(rid, "edit", "lead", amount_cents=150000)
    out = policy.apply_decision(rid, "edit", "lead", amount_cents=50000)
    assert out["status"] == "refunded" and out["amount"] == "$500.00"
    assert policy.apply_decision(rid, "approve", "lead") == out      # replay: no second refund
    assert len(rows("SELECT * FROM refunds")) == 1


def test_kill_switch(monkeypatch):
    monkeypatch.setenv("HELPDESK_WRITES_ENABLED", "0")
    assert policy.request_refund("th", "C001", "INV-1003", 4900, "x")["error"] == "disabled"
