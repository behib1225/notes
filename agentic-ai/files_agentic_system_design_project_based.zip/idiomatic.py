"""The billing specialist written the 2026-idiomatic way: LangChain `create_agent` with
HumanInTheLoopMiddleware (per-call mode) and a policy predicate deciding which calls
need a human. Compare with the hand-built approval gate in graph.py."""
from dataclasses import dataclass
from typing import Literal

from langchain.agents import create_agent
from langchain.agents.middleware import HumanInTheLoopMiddleware
from langchain.tools import ToolRuntime, tool

from helpdesk import acme_tools as t
from helpdesk import config, policy


@dataclass
class Ctx:
    customer_id: str  # supplied by your server from the authenticated session


@tool
def list_invoices(runtime: ToolRuntime[Ctx],
                  status: Literal["paid", "open", "failed"] | None = None) -> dict:
    """List the authenticated customer's invoices, newest first."""
    cid = runtime.context.customer_id
    return t.list_invoices(t.ListInvoicesArgs(customer_id=cid, status=status), {"customer_id": cid})


@tool
def refund(runtime: ToolRuntime[Ctx], invoice_id: str, amount_cents: int, reason: str) -> dict:
    """Refund a paid invoice (amount_cents: 4900 = $49.00). Policy decides if a human must
    approve first; if this runs, it was allowed or approved."""
    cid = runtime.context.customer_id
    with t.db() as con:
        a = policy.assess(con, cid, invoice_id, amount_cents)
    if not a.allowed:
        return {"error": a.code, "message": a.message}
    req = policy.request_refund(f"tool:{runtime.tool_call_id}", cid, invoice_id, amount_cents, reason)
    if req.get("status") == "pending_approval":  # reached only after a human approved
        req = policy.apply_decision(req["request_id"], "approve", "hitl-middleware")
    return req


def needs_human(request) -> bool:
    args, cid = request.tool_call["args"], request.runtime.context.customer_id
    with t.db() as con:
        a = policy.assess(con, cid, args["invoice_id"], args["amount_cents"])
    return a.allowed and a.needs_approval  # disallowed calls fail fast inside the tool


def build_billing_agent(model=None, checkpointer=None):
    if model is None:
        from helpdesk.graph import make_llm
        model = make_llm()
    return create_agent(
        model, tools=[list_invoices, refund], context_schema=Ctx, checkpointer=checkpointer,
        system_prompt=f"You handle Acme Cloud billing. Today is {config.today()}. "
                      "Use tools for every fact. Refund only the later duplicate.",
        middleware=[HumanInTheLoopMiddleware(
            interrupt_on={"refund": {"allowed_decisions": ["approve", "edit", "reject"],
                                     "when": needs_human}},
            interrupt_mode="per_call")])
