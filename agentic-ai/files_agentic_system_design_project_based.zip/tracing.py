"""Minimal OpenTelemetry-style tracer: one JSONL span per model call and tool call.
Swap for an OpenTelemetry exporter (Langfuse, Phoenix, ...) in production."""
import json
import time
import uuid

from langchain_core.callbacks import BaseCallbackHandler


class JsonlTracer(BaseCallbackHandler):
    def __init__(self, path, trace_id: str | None = None):
        self.path, self.trace_id, self.open = path, trace_id or uuid.uuid4().hex, {}

    def _start(self, run_id, kind, name, parent_run_id, attrs):
        self.open[run_id] = (time.time(), kind, name, parent_run_id, attrs)

    def _end(self, run_id, attrs=None, error=None):
        start, kind, name, parent, a = self.open.pop(run_id, (time.time(), "unknown", "?", None, {}))
        span = {"trace_id": self.trace_id, "span_id": str(run_id),
                "parent_id": str(parent) if parent else None, "kind": kind, "name": name,
                "start": start, "duration_ms": round((time.time() - start) * 1000), **a,
                **(attrs or {})}
        if error is not None:
            span["error"] = repr(error)[:300]
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(span, default=str) + "\n")

    def on_chat_model_start(self, serialized, messages, *, run_id, parent_run_id=None, **kw):
        name = (serialized or {}).get("name") or "chat_model"
        self._start(run_id, "llm", name, parent_run_id, {"messages_in": sum(len(m) for m in messages)})

    def on_llm_end(self, response, *, run_id, **kw):
        try:
            usage = response.generations[0][0].message.usage_metadata or {}
        except (AttributeError, IndexError):
            usage = {}
        self._end(run_id, {"gen_ai.usage.input_tokens": usage.get("input_tokens"),
                           "gen_ai.usage.output_tokens": usage.get("output_tokens")})

    def on_llm_error(self, error, *, run_id, **kw):
        self._end(run_id, error=error)

    def on_tool_start(self, serialized, input_str, *, run_id, parent_run_id=None, **kw):
        name = (serialized or {}).get("name") or "tool"
        self._start(run_id, "tool", name, parent_run_id, {"tool.input": str(input_str)[:300]})

    def on_tool_end(self, output, *, run_id, **kw):
        self._end(run_id, {"tool.output": str(getattr(output, "content", output))[:300]})

    def on_tool_error(self, error, *, run_id, **kw):
        self._end(run_id, error=error)


def summarize(path) -> None:
    import collections
    spans = [json.loads(line) for line in open(path, encoding="utf-8")]
    groups = collections.defaultdict(list)
    for s in spans:
        groups[(s["kind"], s["name"])].append(s)
    for (kind, name), ss in sorted(groups.items()):
        d = sorted(x["duration_ms"] for x in ss)
        errors = sum("error" in x for x in ss)
        tokens = sum(x.get("gen_ai.usage.input_tokens") or 0 for x in ss)
        print(f"{kind:5s} {name:22s} n={len(ss):4d} p50={d[len(d) // 2]:7d}ms "
              f"max={d[-1]:7d}ms errors={errors:3d} input_tokens={tokens}")


if __name__ == "__main__":
    import sys
    summarize(sys.argv[1])
