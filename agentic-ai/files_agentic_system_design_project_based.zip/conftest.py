import os
import tempfile

# Must run before helpdesk.config is imported anywhere.
os.environ["HELPDESK_DATA_DIR"] = tempfile.mkdtemp(prefix="helpdesk-test-")
os.environ["HELPDESK_TODAY"] = "2026-11-10"
os.environ["HELPDESK_RETRIEVAL_MODE"] = "bm25"
os.environ["HELPDESK_WRITES_ENABLED"] = "1"

import pytest  # noqa: E402

import seed  # noqa: E402
from helpdesk import acme_tools  # noqa: E402


@pytest.fixture(autouse=True)
def fresh_data():
    seed.main()
    acme_tools.reset_retriever()
    yield
