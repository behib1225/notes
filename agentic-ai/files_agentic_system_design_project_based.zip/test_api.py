from fastapi.testclient import TestClient
from langgraph.checkpoint.memory import InMemorySaver

from helpdesk import api
from helpdesk import graph as hg
from tests.fakes import call, say, script, tools

STAFF = {"X-Staff-Key": "dev-staff-key"}


def client_with(model):
    api._graph = hg.build_graph(InMemorySaver(), llm=model)
    return TestClient(api.app)


def test_chat_approval_queue_and_decision():
    c = client_with(script(
        tools(call("request_refund", {"invoice_id": "INV-1001", "amount_cents": 4900, "reason": "x"}, "a"),
              call("request_refund", {"invoice_id": "INV-1002", "amount_cents": 4900, "reason": "x"}, "b")),
        say("Your refund requests were reviewed."), routes=["billing"]))
    r = c.post("/chat", json={"thread_id": "t1", "message": "refund both"},
               headers={"Authorization": "Bearer priya@example.com"})
    assert r.json()["status"] == "pending_approval"
    assert c.post("/chat", json={"thread_id": "t1", "message": "hello?"},
                  headers={"Authorization": "Bearer priya@example.com"}).status_code == 409

    queue = c.get("/approvals", headers=STAFF).json()["pending"]
    assert [q["answerable_now"] for q in queue] == [True, False]
    second = queue[1]["request_id"]
    assert c.post(f"/approvals/{second}", json={"action": "reject", "approver": "lead"},
                  headers=STAFF).status_code == 409          # must answer in order
    r1 = c.post(f"/approvals/{queue[0]['request_id']}",
                json={"action": "reject", "approver": "lead", "note": "legit charge"}, headers=STAFF)
    assert r1.json()["status"] == "pending_approval"
    r2 = c.post(f"/approvals/{second}", json={"action": "reject", "approver": "lead"}, headers=STAFF)
    assert r2.json() == {"status": "done", "thread_id": "C001:t1",
                         "reply": "Your refund requests were reviewed."}


def test_auth_and_staff_checks():
    c = client_with(script(routes=[]))
    assert c.post("/chat", json={"thread_id": "t", "message": "x"},
                  headers={"Authorization": "Bearer nobody@example.com"}).status_code == 401
    assert c.get("/approvals", headers={"X-Staff-Key": "wrong"}).status_code == 403


def test_streaming_sends_steps_and_the_redacted_reply():
    model = script(tools(call("search_kb", {"query": "SSO"}, "c1")),
                   say("See [sso-setup]. Mei (mei@example.com) set it up."), routes=["technical"])
    c = client_with(model)
    r = c.post("/chat/stream", json={"thread_id": "s", "message": "SSO?"},
               headers={"Authorization": "Bearer priya@example.com"})
    assert r.headers["content-type"].startswith("text/event-stream")
    for part in ("event: step", "event: reply", "[sso-setup]", "[redacted email]", "event: done"):
        assert part in r.text
    assert "mei@example.com" not in r.text
