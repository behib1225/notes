"""Week 0 smoke test (needs a running model server). Run: uv run python -m tests.smoke"""
from openai import OpenAI

from helpdesk import config

client = OpenAI(base_url=config.LLM_BASE_URL, api_key=config.LLM_API_KEY)
r = client.chat.completions.create(
    model=config.LLM_MODEL,
    messages=[{"role": "user", "content": "Reply with the single word: ready"}],
    temperature=0,
    extra_body=config.EXTRA_BODY or None,
)
print(r.choices[0].message.content, r.usage)

e = client.embeddings.create(model=config.EMBED_MODEL, input=["hello world"])
print("embedding dims:", len(e.data[0].embedding))
