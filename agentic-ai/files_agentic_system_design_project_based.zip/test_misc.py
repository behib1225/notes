import json

from langgraph.checkpoint.memory import InMemorySaver
from langchain_core.messages import HumanMessage

from helpdesk import graph as hg
from helpdesk.tracing import JsonlTracer
from tests.fakes import call, say, script, tools


def test_agents_sdk_module_builds():
    from helpdesk import agents_sdk_triage as m
    assert [a.name for a in m.triage.handoffs] == ["Billing specialist", "Technical specialist"]


def test_tracer_records_model_and_tool_spans(tmp_path):
    path = tmp_path / "t.jsonl"
    model = script(tools(call("search_kb", {"query": "SSO"}, "c1")), say("See [sso-setup]."),
                   routes=["technical"])
    g = hg.build_graph(InMemorySaver(), llm=model)
    g.invoke({"messages": [HumanMessage("SSO?")], "customer_id": "C001"},
             {"configurable": {"thread_id": "x"}, "callbacks": [JsonlTracer(path)]})
    kinds = [json.loads(line)["kind"] for line in open(path)]
    assert kinds.count("tool") == 1 and kinds.count("llm") >= 2
