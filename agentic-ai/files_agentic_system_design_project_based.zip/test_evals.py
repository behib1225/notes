import pytest

from helpdesk.evals import run_evals
from helpdesk.evals.judge import cohen_kappa
from tests.fakes import call, say, script, tools


def test_harness_scores_a_scripted_run(monkeypatch):
    model = script(tools(call("list_invoices", {}, "a")),
                   tools(call("request_refund", {"invoice_id": "INV-1003", "amount_cents": 4900,
                                                 "reason": "dup"}, "b")),
                   say("Refunded $49.00 for INV-1003."), routes=["billing"])
    summary = run_evals.main(k=1, ids=["dup-charge-pro"], llm=model)
    assert summary["pass_hat_k"] == 1.0


def test_check_catches_wrong_side_effects():
    case = {"expect_refunds": [], "expect_route": "billing"}
    run = {"route": "billing", "tools": [], "answer": "", "interrupted": False,
           "refunds": [("INV-1001", 4900)]}
    assert run_evals.check(case, run) == ["refunds=[('INV-1001', 4900)]"]


def test_kappa_worked_example():
    human = [True] * 9 + [False] * 3 + [True] * 2 + [False]
    model = [True] * 9 + [False] * 3 + [False] * 2 + [True]
    assert cohen_kappa(human, model) == pytest.approx(0.526, abs=0.001)
