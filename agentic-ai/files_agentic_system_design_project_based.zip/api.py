"""Helpdesk HTTP API.  Run: uv run uvicorn helpdesk.api:app --port 8000
DEMO-ONLY parts are marked; see the course text for the production versions."""
import json
import os
import sqlite3
import threading
from typing import Literal

from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import StreamingResponse
from langchain_core.messages import HumanMessage
from langgraph.types import Command
from pydantic import BaseModel

from helpdesk import acme_tools as t
from helpdesk import config, policy

app = FastAPI(title="Acme Helpdesk")
STAFF_KEY = os.getenv("STAFF_KEY", "dev-staff-key")
_graph = None
_locks: dict[str, threading.Lock] = {}
_locks_guard = threading.Lock()


def get_graph():
    global _graph
    if _graph is None:
        from langgraph.checkpoint.sqlite import SqliteSaver
        from helpdesk.graph import build_graph
        _graph = build_graph(SqliteSaver(sqlite3.connect(config.CHECKPOINT_DB,
                                                         check_same_thread=False)))
    return _graph


def thread_lock(thread_id: str) -> threading.Lock:
    """One active run per conversation (single-process demo; use a DB or Redis lock at scale)."""
    with _locks_guard:
        return _locks.setdefault(thread_id, threading.Lock())


class ChatIn(BaseModel):
    thread_id: str
    message: str


class DecisionIn(BaseModel):
    action: Literal["approve", "edit", "reject"]
    approver: str
    note: str = ""
    amount_cents: int | None = None


def customer_from(authorization: str) -> dict:
    # DEMO ONLY: "Bearer <email>". In production, verify a signed session token (OIDC/JWT).
    if not authorization.startswith("Bearer "):
        raise HTTPException(401, "Missing bearer token")
    try:
        return t.lookup_customer(t.LookupCustomerArgs(email=authorization[7:]))
    except t.ToolError:
        raise HTTPException(401, "Unknown customer")


def require_staff(key: str) -> None:
    if key != STAFF_KEY:  # DEMO ONLY: use staff SSO and role checks in production
        raise HTTPException(403, "Staff only")


def cfg(thread_id: str) -> dict:
    return {"configurable": {"thread_id": thread_id}, "recursion_limit": 25}


def to_response(thread_id: str, result: dict) -> dict:
    if result.get("__interrupt__"):
        return {"status": "pending_approval", "thread_id": thread_id,
                "reply": "Your request needs a quick review by our billing team. "
                         "We'll reply here once it's decided."}
    return {"status": "done", "thread_id": thread_id, "reply": result["messages"][-1].content}


@app.post("/chat")
def chat_endpoint(body: ChatIn, authorization: str = Header(...)):
    customer = customer_from(authorization)
    thread_id = f"{customer['customer_id']}:{body.thread_id}"  # nobody can reach others' threads
    graph = get_graph()
    lock = thread_lock(thread_id)
    if not lock.acquire(blocking=False):
        raise HTTPException(409, "A reply is still being prepared for this conversation.")
    try:
        if graph.get_state(cfg(thread_id)).interrupts:
            raise HTTPException(409, "This conversation is waiting for a billing review.")
        result = graph.invoke({"messages": [HumanMessage(body.message)],
                               "customer_id": customer["customer_id"]}, cfg(thread_id))
        return to_response(thread_id, result)
    finally:
        lock.release()


@app.get("/approvals")
def list_approvals(x_staff_key: str = Header(...)):
    """The billing lead's queue: every pending request with its evidence."""
    require_staff(x_staff_key)
    graph = get_graph()
    queue = []
    for req in policy.pending_requests():
        current = graph.get_state(cfg(req["thread_id"])).interrupts
        queue.append({"thread_id": req["thread_id"],
                      "answerable_now": bool(current) and
                      current[0].value["request_id"] == req["id"],
                      **policy.approval_payload(req)})
    return {"pending": queue}


@app.post("/approvals/{request_id}")
def decide(request_id: str, body: DecisionIn, x_staff_key: str = Header(...)):
    require_staff(x_staff_key)
    req = next((r for r in policy.pending_requests() if r["id"] == request_id), None)
    if req is None:
        raise HTTPException(404, "No pending request with this id (already decided?)")
    graph, thread_id = get_graph(), req["thread_id"]
    with thread_lock(thread_id):
        current = graph.get_state(cfg(thread_id)).interrupts
        if not current or current[0].value["request_id"] != request_id:
            raise HTTPException(409, "Answer the earlier request in this conversation first.")
        result = graph.invoke(Command(resume=body.model_dump()), cfg(thread_id))
    return to_response(thread_id, result)


@app.post("/chat/stream")
def chat_stream(body: ChatIn, authorization: str = Header(...)):
    """Server-sent events: one event per graph step, then the final (redacted) reply.
    Raw model tokens are NOT streamed: in "messages" mode they arrive before the node's
    output redaction runs, so token streaming would bypass that guardrail."""
    customer = customer_from(authorization)
    thread_id = f"{customer['customer_id']}:{body.thread_id}"
    graph = get_graph()
    lock = thread_lock(thread_id)
    if not lock.acquire(blocking=False):
        raise HTTPException(409, "A reply is still being prepared for this conversation.")
    if graph.get_state(cfg(thread_id)).interrupts:
        lock.release()
        raise HTTPException(409, "This conversation is waiting for a billing review.")
    inputs = {"messages": [HumanMessage(body.message)], "customer_id": customer["customer_id"]}

    def events():
        try:
            for update in graph.stream(inputs, cfg(thread_id), stream_mode="updates"):
                if "__interrupt__" in update:
                    yield "event: pending_approval\ndata: {}\n\n"
                    continue
                for node, change in update.items():
                    yield f"event: step\ndata: {json.dumps(node)}\n\n"
                    for m in (change or {}).get("messages", []):
                        if m.type == "ai" and not m.tool_calls and isinstance(m.content, str):
                            yield f"event: reply\ndata: {json.dumps(m.content)}\n\n"
            yield "event: done\ndata: {}\n\n"
        finally:
            lock.release()

    return StreamingResponse(events(), media_type="text/event-stream")
