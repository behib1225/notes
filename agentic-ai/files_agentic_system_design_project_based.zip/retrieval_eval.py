"""Retrieval quality per mode. Usage: uv run python -m tests.retrieval_eval [bm25 dense hybrid]"""
import sys

from helpdesk.rag import HybridRetriever

GOLD = [
    ("how do I turn on single sign-on with Okta", "sso-setup"),
    ("what happens when my card is declined", "failed-payments"),
    ("can I get my money back for a double charge", "refund-policy"),
    ("getting 429 too many requests", "api-rate-limits"),
    ("download all my workspace data as csv", "data-export"),
    ("I forgot my login password", "password-reset"),
    ("when am I billed after upgrading", "billing-cycle"),
    ("how much does the pro plan cost", "plans-and-pricing"),
    ("close my account and delete everything", "account-cancellation"),
    ("does enterprise include audit logs", "plans-and-pricing"),
    ("my workspace became read-only after payments failed", "failed-payments"),
    ("who approves refunds over fifty dollars", "refund-policy"),
]


def evaluate(r: HybridRetriever, mode: str, k: int = 3):
    hits, rr, misses = 0, 0.0, []
    for query, gold in GOLD:
        docs = [c["doc_id"] for c in r.search(query, k=10, mode=mode)]
        hits += gold in docs[:k]
        rr += 1 / (docs.index(gold) + 1) if gold in docs else 0
        if gold not in docs[:k]:
            misses.append((query, docs[:3]))
    return hits / len(GOLD), rr / len(GOLD), misses


if __name__ == "__main__":
    r = HybridRetriever()
    for mode in sys.argv[1:] or ("bm25", "dense", "hybrid"):
        recall, mrr, misses = evaluate(r, mode)
        print(f"{mode:7s} recall@3={recall:.2f}  MRR={mrr:.2f}")
        for q, got in misses:
            print(f"   miss: {q!r} -> {got}")
