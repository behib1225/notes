"""A scripted chat model so graph logic can be tested in CI without any LLM."""
from langchain_core.language_models.fake_chat_models import GenericFakeChatModel
from langchain_core.messages import AIMessage
from langchain_core.runnables import RunnableLambda


class ScriptedModel(GenericFakeChatModel):
    """Replies with the scripted AIMessages in order; routes with the scripted labels."""
    routes: list = []
    route_calls: int = 0

    def bind_tools(self, tools, **kwargs):
        return self

    def with_structured_output(self, schema, **kwargs):
        def pick(_):
            if self.route_calls >= len(self.routes):
                raise RuntimeError("router called more often than scripted")
            self.route_calls += 1
            return schema(route=self.routes[self.route_calls - 1])
        return RunnableLambda(pick)


def call(name: str, args: dict, call_id: str) -> dict:
    return {"name": name, "args": args, "id": call_id}


def script(*messages, routes=()):
    return ScriptedModel(messages=iter(list(messages)), routes=list(routes))


def say(text: str) -> AIMessage:
    return AIMessage(text)


def tools(*calls) -> AIMessage:
    return AIMessage("", tool_calls=list(calls))
