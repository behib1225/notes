# Helpdesk: reference implementation

Reference code for the course *Agentic AI System Design: A 4-Week Project-Based Course*
(revised November 2026). It is the end-of-week-4 state of the capstone: a support agent for the
fictional SaaS company Acme Cloud.

## Verified environment (11 November 2026)

Python 3.12, uv 0.11.32, langgraph 1.2.20, langchain 1.5.0, langchain-core 1.8.0,
langchain-ollama 1.1.0, langchain-openai 1.7.4, langgraph-checkpoint-sqlite 3.1.3,
fastmcp 4.1.8 (mcp 2.3.0), openai 3.49.0, openai-agents 0.24.0, fastapi 0.162.4.
Exact versions are in `uv.lock`; install with `uv sync --frozen`.

What was verified: all 43 tests in `tests/` pass without any model (a scripted fake model drives
the graph). What was NOT verified here: behaviour with a real local model. Expect lower and
noisier eval scores from a 4B CPU model than from an API model.

## Run

```bash
uv sync --frozen
cp .env.example .env               # keep HELPDESK_TODAY=2026-11-10 (seed data is dated 2026)
uv run python seed.py
uv run pytest -q                   # model-free test suite
ollama pull qwen3.5:4b && ollama pull nomic-embed-text
uv run python -m helpdesk.rag      # build the embedding index
uv run python -m helpdesk.agent priya@example.com           # weeks 1-2 agent
uv run python -m helpdesk.graph mei@example.com demo        # weeks 3-4 graph (CLI approvals)
uv run python -m helpdesk.evals.run_evals 1                 # golden set, 1 trial per case
uv run uvicorn helpdesk.api:app --port 8000                 # HTTP API, approval queue, /chat/stream
```

## Map

| File | Week | What it shows |
| --- | --- | --- |
| `helpdesk/llm.py`, `tools.py`, `acme_tools.py`, `agent.py` | 1-2 | Framework-free loop, typed tools, session binding |
| `helpdesk/rag.py`, `memory.py`, `mcp_server.py`, `mcp_client.py` | 2 | Hybrid retrieval, memory, compaction, MCP |
| `helpdesk/policy.py`, `graph.py`, `agents_sdk_triage.py`, `idiomatic.py` | 3 | Policy as code, approval gate, durable graph, SDK comparisons |
| `helpdesk/guards.py`, `tracing.py`, `evals/`, `api.py` | 4 | Guardrails, traces, golden-set evals, judge, service, approval queue, safe SSE streaming |
| `tests/` | all | Model-free tests that run in CI |

## Known limitations

SQLite checkpoints and an in-process lock serialize work in one process; production needs
Postgres checkpoints, a distributed per-thread lock, real authentication (OIDC) and a staff UI.
The injection regex in `guards.py` is a weak signal, not a defense; the defense is `policy.py`.
