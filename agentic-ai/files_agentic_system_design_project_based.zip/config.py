"""Central configuration. Everything provider- or environment-specific lives here."""
import datetime as dt
import os
from pathlib import Path

from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / ".env")

DATA_DIR = Path(os.getenv("HELPDESK_DATA_DIR", ROOT / "data"))
DB_PATH = DATA_DIR / "acme.db"
KB_DIR = DATA_DIR / "kb"
INDEX_DIR = DATA_DIR / "index"
CHECKPOINT_DB = DATA_DIR / "checkpoints.db"

LLM_BASE_URL = os.getenv("LLM_BASE_URL", "http://localhost:11434/v1")
LLM_API_KEY = os.getenv("LLM_API_KEY", "ollama")
LLM_MODEL = os.getenv("LLM_MODEL", "qwen3.5:4b")
EMBED_MODEL = os.getenv("EMBED_MODEL", "nomic-embed-text")
DISABLE_THINKING = os.getenv("LLM_DISABLE_THINKING", "1") == "1"
IS_OLLAMA = "11434" in LLM_BASE_URL

# Extra request fields sent on every chat call. "none" is an Ollama convenience.
EXTRA_BODY = {"reasoning_effort": "none"} if DISABLE_THINKING else {}


def today() -> dt.date:
    """The business date. Fixed by HELPDESK_TODAY so the 2026 seed data stays valid."""
    value = os.getenv("HELPDESK_TODAY")
    return dt.date.fromisoformat(value) if value else dt.date.today()


def retrieval_mode() -> str:
    return os.getenv("HELPDESK_RETRIEVAL_MODE", "hybrid")
