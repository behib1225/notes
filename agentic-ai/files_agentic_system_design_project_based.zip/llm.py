"""Thin provider-agnostic chat client for any OpenAI-compatible endpoint."""
from dataclasses import dataclass

from openai import OpenAI

from helpdesk import config

_client = OpenAI(base_url=config.LLM_BASE_URL, api_key=config.LLM_API_KEY, timeout=600)


@dataclass
class Usage:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    calls: int = 0

    def add(self, u) -> None:
        self.calls += 1
        if u is not None:
            self.prompt_tokens += u.prompt_tokens or 0
            self.completion_tokens += u.completion_tokens or 0


def chat(messages, tools=None, response_format=None, temperature=0.0, max_tokens=1024):
    kwargs = dict(model=config.LLM_MODEL, messages=messages, temperature=temperature,
                  max_tokens=max_tokens, extra_body=config.EXTRA_BODY or None)
    if tools:
        kwargs["tools"] = tools
    if response_format:
        kwargs["response_format"] = response_format
    resp = _client.chat.completions.create(**kwargs)
    return resp.choices[0].message, resp.usage
