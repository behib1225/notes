"""Cheap guardrail layers. None of these is a security boundary on its own:
the boundary is the policy code in helpdesk/policy.py."""
import os
import re

# A weak signal: trivially bypassed by paraphrase. Use it for labelling and logging,
# and pair it with a trained injection classifier in production.
INJECTION = re.compile(r"ignore (all |any )?(previous|prior|above) instructions|note to ai|"
                       r"you are now|system prompt|do not ask (anyone|for approval)", re.I)
CARD = re.compile(r"\b(?:\d[ -]?){13,19}\b")
EMAIL = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")


def writes_enabled() -> bool:
    """Kill switch for every tool with side effects."""
    return os.getenv("HELPDESK_WRITES_ENABLED", "1") == "1"


def trust_level(doc_id: str) -> str:
    return "untrusted_user_content" if doc_id.startswith("community-") else "official"


def sanitize_retrieved(text: str) -> tuple[str, bool]:
    if INJECTION.search(text):
        return "[Removed: this passage contained instructions aimed at AI assistants.]", True
    return text, False


def redact_output(text: str, allowed_email: str | None) -> str:
    text = CARD.sub("[redacted card number]", text)
    keep = (allowed_email or "").lower()
    return EMAIL.sub(lambda m: m.group(0) if m.group(0).lower() == keep else "[redacted email]", text)
