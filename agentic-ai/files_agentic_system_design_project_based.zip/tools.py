"""A typed tool registry for the framework-free agent (weeks 1-2)."""
import inspect
import json

from pydantic import BaseModel, ValidationError

MAX_RESULT_CHARS = 4000


class ToolError(Exception):
    """An expected failure the model should see and recover from."""

    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


def _err(code: str, message: str, **extra) -> str:
    return json.dumps({"error": code, "message": message, **extra}, default=str)


class Tool:
    def __init__(self, fn, args_model: type[BaseModel], side_effect: bool):
        self.fn, self.args_model, self.side_effect = fn, args_model, side_effect
        self.name = fn.__name__
        self.description = inspect.getdoc(fn) or ""
        self.wants_ctx = len(inspect.signature(fn).parameters) == 2

    def schema(self) -> dict:
        params = self.args_model.model_json_schema()
        params.pop("title", None)
        return {"type": "function",
                "function": {"name": self.name, "description": self.description,
                             "parameters": params}}

    def run(self, raw_args: str | None, ctx: dict | None = None) -> str:
        try:
            data = json.loads(raw_args or "{}")
        except json.JSONDecodeError as e:
            return _err("invalid_json", f"Arguments were not valid JSON: {e}")
        try:
            args = self.args_model.model_validate(data)
        except ValidationError as e:
            return _err("invalid_arguments", "Fix the arguments and retry.",
                        details=e.errors(include_url=False))
        try:
            result = self.fn(args, ctx or {}) if self.wants_ctx else self.fn(args)
        except ToolError as e:
            return _err(e.code, str(e))
        except Exception as e:  # never crash the loop
            return _err("internal_error", f"{type(e).__name__}: {e}")
        text = result if isinstance(result, str) else json.dumps(result, default=str)
        return text[:MAX_RESULT_CHARS]


class ToolRegistry:
    def __init__(self):
        self.tools: dict[str, Tool] = {}

    def register(self, args_model: type[BaseModel], side_effect: bool = False):
        def deco(fn):
            self.tools[fn.__name__] = Tool(fn, args_model, side_effect)
            return fn
        return deco

    def schemas(self, names: list[str] | None = None) -> list[dict]:
        return [t.schema() for n, t in self.tools.items() if names is None or n in names]

    def run(self, name: str, raw_args: str | None, ctx: dict | None = None) -> str:
        tool = self.tools.get(name)
        if tool is None:
            return _err("unknown_tool", f"No tool named {name!r}.", available=list(self.tools))
        return tool.run(raw_args, ctx)
