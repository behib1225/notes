"""The router rebuilt with the OpenAI Agents SDK (handoffs), running on the local model.
Run: uv run python -m helpdesk.agents_sdk_triage"""
import json

from agents import (Agent, ModelSettings, OpenAIChatCompletionsModel, Runner,
                    function_tool, set_tracing_disabled)
from openai import AsyncOpenAI

from helpdesk import acme_tools as t
from helpdesk import config

set_tracing_disabled(True)  # default tracing exports to OpenAI's platform; off for local runs
model = OpenAIChatCompletionsModel(
    model=config.LLM_MODEL,
    openai_client=AsyncOpenAI(base_url=config.LLM_BASE_URL, api_key=config.LLM_API_KEY))
settings = ModelSettings(temperature=0, extra_body=config.EXTRA_BODY or None)


@function_tool
def lookup_customer(email: str) -> str:
    """Find a customer by account email."""
    return t.registry.run("lookup_customer", json.dumps({"email": email}))


@function_tool
def list_invoices(customer_id: str) -> str:
    """List a customer's invoices, newest first."""
    return t.registry.run("list_invoices", json.dumps({"customer_id": customer_id}))


@function_tool
def search_kb(query: str) -> str:
    """Search Acme help-center articles; cite doc ids."""
    return t.registry.run("search_kb", json.dumps({"query": query}))


billing = Agent(name="Billing specialist", model=model, model_settings=settings,
                handoff_description="Charges, invoices, refunds, payments and plans.",
                instructions="Explain charges using tools. Never invent amounts. Read-only.",
                tools=[lookup_customer, list_invoices, search_kb])
tech = Agent(name="Technical specialist", model=model, model_settings=settings,
             handoff_description="How-to questions: SSO, API, exports, passwords.",
             instructions="Answer from search_kb results and cite doc ids.", tools=[search_kb])
triage = Agent(name="Triage", model=model, model_settings=settings, handoffs=[billing, tech],
               instructions="Hand off to the right specialist. Do not answer yourself.")

if __name__ == "__main__":
    for q in ["I'm priya@example.com, why two October charges?", "How do I enable SSO with Okta?"]:
        result = Runner.run_sync(triage, q)
        print(f"[{result.last_agent.name}] {result.final_output}\n")
