"""Run the golden set k times per case.
Usage: uv run python -m helpdesk.evals.run_evals [k] [case-id ...]"""
import json
import statistics
import sys
import time
import uuid

import yaml
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

import seed
from helpdesk import acme_tools as t
from helpdesk import config
from helpdesk.graph import build_graph

CASES = yaml.safe_load((config.ROOT / "helpdesk" / "evals" / "cases.yaml").read_text())


def decision_for(case: dict) -> dict:
    a = str(case.get("approval", "reject"))
    if a == "approve":
        return {"action": "approve", "approver": "eval"}
    if a.startswith("edit:"):
        return {"action": "edit", "approver": "eval", "amount_cents": int(a.split(":")[1])}
    return {"action": "reject", "approver": "eval", "note": "rejected by eval"}


def run_case(graph, case: dict, callbacks=None) -> dict:
    seed.main()  # identical starting data for every trial
    t.reset_retriever()
    customer = t.lookup_customer(t.LookupCustomerArgs(email=case.get("email", "diego@example.com")))
    cfg = {"configurable": {"thread_id": f"{customer['customer_id']}:{uuid.uuid4().hex}"},
           "recursion_limit": 25, "callbacks": callbacks or []}
    t0, interrupted = time.perf_counter(), False
    for text in case.get("turns") or [case["input"]]:
        result = graph.invoke({"messages": [HumanMessage(text)],
                               "customer_id": customer["customer_id"]}, cfg)
        while result.get("__interrupt__"):
            interrupted = True
            result = graph.invoke(Command(resume=decision_for(case)), cfg)
    msgs = result["messages"]
    with t.db() as con:
        refunds = sorted((r["invoice_id"], r["amount_cents"])
                         for r in con.execute("SELECT invoice_id, amount_cents FROM refunds"))
    answer = msgs[-1].content if isinstance(msgs[-1].content, str) else str(msgs[-1].content)
    return {
        "route": result.get("route"),
        "tools": [tc["name"] for m in msgs if isinstance(m, AIMessage) for tc in m.tool_calls],
        "tool_outputs": "\n".join(str(m.content) for m in msgs if isinstance(m, ToolMessage)),
        "answer": answer,
        "interrupted": interrupted,
        "refunds": refunds,
        "latency_s": time.perf_counter() - t0,
        # Specialist calls only; the router and summarizer show up in traces.
        "tokens": sum((m.usage_metadata or {}).get("total_tokens", 0)
                      for m in msgs if isinstance(m, AIMessage)),
    }


def check(case: dict, run: dict) -> list[str]:
    f = []
    if "expect_route" in case and run["route"] != case["expect_route"]:
        f.append(f"route={run['route']}")
    f += [f"missing tool {n}" for n in case.get("required_tools", []) if n not in run["tools"]]
    f += [f"forbidden tool {n}" for n in case.get("forbidden_tools", []) if n in run["tools"]]
    if "expect_interrupt" in case and run["interrupted"] != case["expect_interrupt"]:
        f.append(f"interrupted={run['interrupted']}")
    if "expect_refunds" in case:
        want = sorted((r["invoice_id"], r["amount_cents"]) for r in case["expect_refunds"])
        if run["refunds"] != want:
            f.append(f"refunds={run['refunds']}")
    f += [f"answer lacks {s!r}" for s in case.get("must_mention", [])
          if s.lower() not in run["answer"].lower()]
    f += [f"no citation [{d}]" for d in case.get("must_cite", []) if f"[{d}]" not in run["answer"]]
    return f


def main(k: int = 3, ids: list[str] | None = None, llm=None) -> dict:
    graph = build_graph(InMemorySaver(), llm=llm)
    cases = [c for c in CASES if not ids or c["id"] in ids]
    report, latencies, tokens = [], [], []
    for case in cases:
        trials = []
        for _ in range(k):
            run = run_case(graph, case)
            trials.append({"failures": check(case, run), **run})
            latencies.append(run["latency_s"])
            tokens.append(run["tokens"])
        passes = [not tr["failures"] for tr in trials]
        first_fail = next((tr["failures"] for tr in trials if tr["failures"]), [])
        print(f"{case['id']:32s} {sum(passes)}/{k}  {'; '.join(first_fail)}")
        report.append({"id": case["id"], "passes": passes, "trials": trials})
    summary = {
        "mean_pass_rate": statistics.mean(sum(r["passes"]) / k for r in report),
        "pass_hat_k": statistics.mean(all(r["passes"]) for r in report),
        "p95_latency_s": (statistics.quantiles(latencies, n=20)[18] if len(latencies) > 1
                          else latencies[0]),
        "mean_tokens": statistics.mean(tokens),
    }
    print(f"\nmean pass rate={summary['mean_pass_rate']:.2f}  pass^{k}={summary['pass_hat_k']:.2f}  "
          f"p95 latency={summary['p95_latency_s']:.1f}s  mean tokens={summary['mean_tokens']:.0f}")
    out = config.DATA_DIR / f"eval_report_{int(time.time())}.json"
    out.write_text(json.dumps({"summary": summary, "cases": report}, indent=1, default=str))
    return summary


if __name__ == "__main__":
    args = sys.argv[1:]
    main(int(args[0]) if args else 3, args[1:] or None)
