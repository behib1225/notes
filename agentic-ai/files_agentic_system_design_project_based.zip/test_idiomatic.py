from langgraph.checkpoint.memory import InMemorySaver
from langgraph.types import Command

from helpdesk import acme_tools as t
from helpdesk.idiomatic import Ctx, build_billing_agent
from tests.fakes import call, say, script, tools


def refunds():
    with t.db() as con:
        return [tuple(r) for r in con.execute("SELECT invoice_id, amount_cents, approved_by FROM refunds")]


def test_small_duplicate_runs_without_interrupt():
    model = script(tools(call("refund", {"invoice_id": "INV-1003", "amount_cents": 4900, "reason": "dup"}, "c1")),
                   say("Refunded."))
    agent = build_billing_agent(model, InMemorySaver())
    out = agent.invoke({"messages": [{"role": "user", "content": "double charge"}]},
                       {"configurable": {"thread_id": "a"}}, context=Ctx("C001"), version="v2")
    assert not out.interrupts and refunds() == [("INV-1003", 4900, "policy:auto")]


def test_enterprise_refund_needs_approval_and_edit_lowers_amount():
    model = script(tools(call("refund", {"invoice_id": "INV-3002", "amount_cents": 99000, "reason": "dup"}, "c1")),
                   say("Partially refunded."))
    agent = build_billing_agent(model, InMemorySaver())
    cfg = {"configurable": {"thread_id": "b"}}
    out = agent.invoke({"messages": [{"role": "user", "content": "double charge"}]}, cfg,
                       context=Ctx("C003"), version="v2")
    (pending,) = out.interrupts
    assert refunds() == []
    edit = {"type": "edit", "edited_action": {"name": "refund", "args": {
        "invoice_id": "INV-3002", "amount_cents": 50000, "reason": "approver lowered"}}}
    agent.invoke(Command(resume={pending.id: edit}), cfg, context=Ctx("C003"), version="v2")
    assert refunds() == [("INV-3002", 50000, "hitl-middleware")]
