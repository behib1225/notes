"""Expose any MCP server's tools to the framework-free agent loop (week 2)."""
import asyncio
import json
import os
from pathlib import Path

from fastmcp import Client
from fastmcp.client.transports import PythonStdioTransport

from helpdesk.agent import system_prompt
from helpdesk.llm import chat


class MCPToolset:
    def __init__(self, target):
        if isinstance(target, (str, Path)) and str(target).endswith(".py"):
            # stdio servers do NOT inherit your environment by default: pass what they need.
            env = {k: v for k, v in os.environ.items()
                   if k.startswith(("HELPDESK_", "LLM_", "EMBED_")) or k in ("PATH", "HOME")}
            target = PythonStdioTransport(Path(target), env=env)
        self.client = Client(target)  # a stdio transport, an http(s) URL, or a FastMCP object

    async def __aenter__(self):
        await self.client.__aenter__()
        return self

    async def __aexit__(self, *exc):
        await self.client.__aexit__(*exc)

    async def schemas(self) -> list[dict]:
        tools = await self.client.list_tools()
        return [{"type": "function", "function": {
            "name": t.name, "description": t.description or "", "parameters": t.input_schema}}
            for t in tools]

    async def run(self, name: str, raw_args: str | None) -> str:
        try:
            args = json.loads(raw_args or "{}")
        except json.JSONDecodeError as e:
            return json.dumps({"error": "invalid_json", "message": str(e)})
        try:
            result = await self.client.call_tool(name, args, raise_on_error=False)
        except Exception as e:  # transport errors, unknown tools, schema errors
            return json.dumps({"error": "mcp_error", "message": str(e)})
        text = "\n".join(getattr(c, "text", "") for c in result.content)
        if result.is_error:
            return json.dumps({"error": "tool_error", "message": text})
        return text[:4000]


async def run_agent_mcp(user_input: str, target="helpdesk/mcp_server.py", max_steps: int = 8):
    async with MCPToolset(target) as tools:
        schemas = await tools.schemas()
        messages = [{"role": "system", "content": system_prompt()},
                    {"role": "user", "content": user_input}]
        for _ in range(max_steps):
            msg, _ = await asyncio.to_thread(chat, messages, schemas)
            if not msg.tool_calls:
                return msg.content or ""
            messages.append({"role": "assistant", "content": msg.content or "", "tool_calls": [
                {"id": c.id, "type": "function",
                 "function": {"name": c.function.name, "arguments": c.function.arguments}}
                for c in msg.tool_calls]})
            for c in msg.tool_calls:
                messages.append({"role": "tool", "tool_call_id": c.id,
                                 "content": await tools.run(c.function.name, c.function.arguments)})
        return "Step budget reached; escalating to a human."


if __name__ == "__main__":
    print(asyncio.run(run_agent_mcp("How do I set up SSO with Okta?")))
