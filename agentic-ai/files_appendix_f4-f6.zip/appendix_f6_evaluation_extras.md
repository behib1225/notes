# Appendix F.6 — Evaluation Extras: Simulated Users, Canaries, A/B, Online Eval

## a. Read this if …

… you will own an agent after it launches.

---

## b. What it is, and why it was deferred

Three extensions to the evaluation suite Phase 13 built. A **simulated-user harness**, so a task can be a conversation rather than a prompt. A **canary and an A/B comparison** over recorded, production-style traces. And the arithmetic for **reading an online metric without fooling yourself** — sample size, seasonality, and the number that moved because the population changed rather than because you changed anything.

All three were deferred because none is needed to build Atlas; they are needed to *keep* it. Phase 13's job was to make Atlas measurable before launch, and it produced 63 tasks, a rubric judge, a committed baseline and a gate. Everything here is about the week after, which the core never reaches. The other reason is honest and less flattering to the subject: online evaluation is mostly statistics and record-keeping, and a phase spent on it would have bought no new capability. It buys something else — that when the number moves, you can say why.

Nothing here is a second harness. A conversation is a `Task` with `setup.persona`; a canary is a `Task` with `setup.windows`; both are graded by the same `Check` model and appear in the same report.

---

## c. Plugs into Phase 13

Build on the snapshot `atlas_phase_13.zip`. If your code diverged, start from that snapshot.

**What it assumes, named concretely.** `evals/stats.py`'s `wilson_interval`, `min_detectable_effect` and `Interval` — every statistic here is computed by that module and none is re-derived. `evals/report.py`'s gate philosophy: a baseline is a committed artefact and a gate fires on categorical events about named tasks, never on the rate. `evals/dataset.py`'s `Provenance` block, which the new tasks carry. The `Task` / `Check` / `run_checks` / `build_environment` / `format_report` machinery in `evals/run.py`. Phase 10's `run_atlas_graph` with a checkpointer and a thread id, which is what makes a multi-turn conversation a conversation rather than five unrelated requests. `atlas.llm.FakeLLMClient` for every fixture. Nothing from Phase 14 or later.

| | |
|---|---|
| Study hours | 1.5 read · 1.5 build · 1.0 assess |
| Compute time | under 2 minutes on the baseline laptop, Tier F |
| Tier A calls per sweep | ~240 (experiment 6 only) |
| Tier H calls | ≤ 300 for the whole section, cached to `data/cache/` |
| Cost | $0.00 |
| Repo snapshot | `atlas_appendix_f6.zip` (built on `atlas_phase_13.zip`) |

**Applying to the finished code.** `evals/stats.py`, `evals/report.py` and `evals/dataset.py` are byte-identical in `atlas_phase_16.zip`, `evals/run.py`'s `load_tasks` still globs `phase*.json`, and the committed baseline there still holds the same 63 cells under the same suite version. Adding `evals/tasks/appendix_f6.json` does not move it, and the Phase 13 gate keeps passing — verified, not assumed.

**A note on Git.** `ATLAS_INTERFACES.md` invariant 12 describes Appendix F builds as branches off phase tags. This appendix distributes snapshots; read any such reference as "the snapshot named for that phase, plus this section's snapshot on top of it".

---

## d. Concepts

### Offline asks a proposition; online observes a population

The suite asks *did this change break a named task*, over inputs you chose and can re-run. Online metrics ask *what happened to the people using it*, over inputs you did not choose and cannot re-run. The first is a proposition. The second is an observation of a population that moves underneath you — and **a number computed over a moving population is not a number about your agent.** Everything in `evals/online.py` exists because of that sentence.

```
                 traffic  ──▶  preflight  ──▶  is this a comparison at all?
                                  │
          ┌───────────────────────┼───────────────────────┐
     do_not_read            read_segments_only         proceed
   (assignment broken)       (mix moved)            (arms alike)
          │                       │                       │
       fix & re-run         decompose_delta          ab_compare
                            within / mix / inter.    delta ± interval, MDE

  canary, in parallel and independent of all three:
     new_error_kind · segment_floor · escalation_ceiling · segment_vanished  ──▶ HOLD
     sample_too_small                                                        ──▶ UNDECIDED
     none of the above                                                       ──▶ PASS
```

(The `preflight` box is this section's assignment. The rest ships in the snapshot.)

### A real user withholds

Every eval task in this book so far is one turn. The gap between that and real use is not "more turns"; it is that a real user opens with half the question, answers what they are asked, and leaves when the agent stops being useful. An agent that scores well on single-turn tasks can still be unable to elicit a missing constraint, and no number of single-turn tasks will show you.

> **Misconception: "let a model play the user; it'll be more realistic."** It will be more varied, which is not the same thing. A model playing the user is a second model inside your measurement loop, and when the score drops you cannot say which model moved. Atlas's default user is a rule table; `ModelUser` exists, is opt-in, and every result records `user_was_model` so a number produced with one is visibly a different number (invariant 25).

> **Concept check 1.** `run_conversation` takes `goal_check` as a parameter rather than reading it off the `Persona`. What failure does separating them prevent, and which invariant is it an instance of?

### A canary blocks on events, and has three verdicts

Phase 13 argued that a gate fires on categorical events about named tasks. Online the argument is stronger, because the sample is whatever traffic arrived: **a canary that fires when a rate moves fires on Mondays.**

The subtler decision is the third verdict. A canary over forty requests that finds nothing has found nothing *because it could not look*, and recording that as a pass is how a rollout acquires a clean record it never earned. So `CanaryReport.verdict` is `hold | undecided | pass`, and `sample_too_small` is deliberately **not** in the blocking set — it means the canary decided nothing, which is a different state from finding something. Phase 13's judge floor with a different noun: below the floor it may be reported and may not decide.

> **Misconception: "a segmented canary is strictly more sensitive than a rate."** Measured here, and it is not. A small segment has a wide minimum detectable effect, so a diffuse degradation moves the aggregate before it crosses the segment's floor. What the canary buys is **specificity** — it names the segment — and **reach**: a brand-new error kind, or a segment that stopped receiving traffic, is invisible to any rate. The table in section h has the numbers, including the rows where the canary loses.

### Sample size, before you read any delta

`min_detectable_effect` is already in `evals/stats.py` and the habit transfers directly: **a delta smaller than the MDE is not a small effect; it is an unmeasured one.** Measured at 86% success:

| n per arm | MDE |
|---|---|
| 50 | 0.136 |
| 250 | 0.061 |
| 1,000 | 0.030 |
| 10,000 | 0.010 |

Halving the interval takes four times the sample.

> **Concept check 2.** `ABResult.mde` is computed at the *smaller* arm. Why is that the honest choice, and what does using the pooled n instead let you claim?

### A window is a population, not a period

"Last week versus the week before" sounds symmetric and often is not: if one window is Monday-to-Friday and the other includes a weekend, you are comparing two different populations. `windows_comparable` returns every complaint in one pass — in the style of `validate_plan` — rather than a boolean, so a caller may proceed anyway but may not proceed without the list.

### The metric that moved because the population changed

The headline. An aggregate delta decomposes exactly:

```
delta = Σ w_c[s] (p_t[s] − p_c[s])              rate effect  ("what the change did")
      + Σ (w_t[s] − w_c[s]) p_c[s]              mix effect   ("who showed up")
      + Σ (w_t[s] − w_c[s]) (p_t[s] − p_c[s])   interaction
```

Three terms that sum to the delta by construction. The interaction term is kept rather than folded into one of the others, because folding it is a choice and a silent choice inside an attribution is exactly what this module is about.

Measured on the seeded window, where the planted truth is a uniform +0.04 on every route plus a traffic shift toward the hardest one:

```
  aggregate delta   +0.0094
  rate effect       +0.0487   (what the change did)
  mix effect        -0.0613   (who showed up)
  interaction       +0.0220
```

The aggregate says +0.9% and its MDE is 3.25%, so the honest aggregate readout is **"we could not tell"**. The segmented readout recovers +4.9% against a planted +4.0%. And at large n the aggregate delta is actually *negative* — so at fourteen days the aggregate has the wrong sign as well as being unreadable.

---

## e. The build, step by step

### Step 1 — traces from a committed, seeded generator

Atlas has no production, so `scripts/gen_traces.py` makes traces that behave like production's. Three properties are planted, each to defeat one way of reading online metrics badly: weekly seasonality (weekday volume triple the weekend, with a different weekend mix); a mix shift that runs *against* the effect; and a rollout beginning on day 8, so a naive "last week versus the week before" reads the rollout and the weekday mix at once.

```python
# excerpt: scripts/gen_traces.py
BASE_SUCCESS: dict[str, float] = {
    "chat": 0.95,
    "document": 0.88,
    "data": 0.82,
    "research": 0.60,
    "tool_action": 0.78,
}

# The treatment genuinely helps, everywhere, by a small amount. Small on
# purpose: an effect larger than the minimum detectable effect at any sample
# size teaches nothing about sample size.
TREATMENT_LIFT = 0.04
```

The start date is a fixed Monday rather than today, for the reason `build_environment` already freezes its clock. Byte-identical for a fixed seed, verified by digest. Write them with `make results PHASE=_f6 ARGS=--write-traces`; the offline tests build them in process, so a fresh clone needs the file only for the shell examples below.

It buys a dataset whose ground truth is known, so you can check that an analysis *recovers* the effect that was put in — the only way to test an analysis. It buys no evidence whatever about real user behaviour, and every table printed from it says so.

### Step 2 — the canary

```python
# excerpt: evals/online.py
CanaryKind = Literal[
    "new_error_kind",      # an error nobody saw in the baseline window
    "segment_floor",       # a route fell below its baseline floor
    "escalation_ceiling",  # escalations crossed an absolute ceiling
    "segment_vanished",    # a route that had traffic has none: silent breakage
    "sample_too_small",    # the canary cannot detect what it is watching for
]

BLOCKING_CANARY_KINDS: frozenset[str] = frozenset(
    {"new_error_kind", "segment_floor", "escalation_ceiling", "segment_vanished"}
)
```

Every condition is categorical and about a named segment. The floor is the baseline segment's own rate minus its own MDE, so a segment is faulted only for a move the baseline sample was large enough to see — a fixed floor would fault the noisiest segment every time.

```python
# excerpt: evals/online.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def verdict(self) -> Literal["hold", "undecided", "pass"]:
        """Three states, because "we could not tell" is not "it was fine"."""
        if self.blocking:
            return "hold"
        return "undecided" if self.undecided else "pass"
```

### Step 3 — A/B, with the interval and the MDE attached

```python
# excerpt: evals/online.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def mde(self) -> float:
        """Computed at the SMALLER arm, which is what the comparison is limited by."""
        n = max(min(self.control_n, self.treatment_n), 1)
        p = max(0.05, min(0.95, self.control_rate))
        return min_detectable_effect(n, p=p)
```

`verdict` returns the sentence, not a boolean: *"within noise: do not call this an improvement or a regression"*. A field that can only be read as a word is harder to quietly ignore than a flag.

### Step 4 — the decomposition

`decompose_delta` is thirty lines of arithmetic and one design decision: the segments carry their own `n`, shares and rates in the record, so a reader can check the arithmetic by hand. `MixDecomposition.exact` is a computed field asserting the three terms sum to the delta, and a test asserts it — an attribution whose parts do not add up is an opinion with decimal places. Two warnings are derived rather than written: `sign_flipped` and `mix_dominates`. On this window the second fires.

### Step 5 — the simulated user

```python
# excerpt: evals/simuser.py
    def reply(self, agent_text: str, *, turn: int) -> str | None:
        if turn == 1:
            self.per_turn.append(0)
            return self.persona.opening
        new = [
            cue for cue, _ in self.persona.facts.items()
            if cue not in self.revealed and mentions(agent_text, cue)
        ]
        self.per_turn.append(len(new))
        if not new:
            self.bored += 1
            if self.bored >= self.persona.patience:
                return None  # the user leaves. A bounded exit the user owns.
            return "I'm not sure — what else do you need from me?"
        self.bored = 0
        self.revealed.extend(new)
        return " ".join(self.persona.facts[cue] for cue in new)
```

A real user leaves. A simulated user with infinite patience measures an agent that converges *eventually*, which is not a property anyone cares about.

The load-bearing decision is one line elsewhere:

```python
# excerpt: evals/simuser.py
        if goal_check(agent_text):
            result.goal_met = True
            result.stop_reason = "goal_met"
            break
```

`goal_check` runs on the **agent's** text and is the only thing that can set `goal_met`. The user's opinion is not consulted and there is no field in which it could be expressed — invariant 44's shape, applied to a fixture instead of to a model.

And the honest limitation, in the module docstring rather than discovered later: cue matching is normalised substring matching, so an agent that emits every cue word in one turn extracts every fact without asking a real question. That hole is **measurable** — `reveals_in_one_turn` — and it is computed, printed and wired to no decision (invariant 49's shape), because no metric available here separates skill from cue-stuffing.

### With an assistant

**Safe to delegate:** the Pydantic record shapes and their `render()` methods; the weekday-profile bookkeeping; converting the task JSON.

**Not safe to delegate:** the three-verdict canary and the decomposition's term structure. Ask for "a canary check" and you will get a threshold on the overall rate; ask for "explain why the metric dropped" and you will get an attribution that does not sum to the delta. Both are the defaults, and both are what this section replaces.

A prompt that works:

> Write `decompose_delta(control, treatment, *, by, metric)` returning a Pydantic record with `within`, `mix` and `interaction` such that `within + mix + interaction == treatment_rate - control_rate` exactly. Use the control's shares for the rate effect and the control's rates for the mix effect; keep the interaction as its own term and do not fold it into either. Then write a test asserting the identity to 1e-9 on a dataset where the mixes differ.

---

## f. Debug this trace

An engineer ships a change, waits two weeks, and posts this in the channel:

```
$ python - <<'PY'
from evals.online import load_traces, ab_compare
t = load_traces("data/traces/traces.jsonl")
c = [r for r in t if r.cohort == "control"]
x = [r for r in t if r.cohort == "treatment"]
print(ab_compare(c, x).render())
PY

overall        control 0.856 [0.842, 0.870] n=2506
               treat.  0.866 [0.842, 0.887] n=894
               delta +0.0094  mde 0.0325  -> within noise: do not call this an
                                             improvement or a regression
```

> "+0.9% and the intervals overlap, so it's neutral. No harm done — let's ship it and move on."

Three things are wrong with that reading and only one of them is the statistics.

**First, "neutral" is not what the tool said.** It said *within noise*, which means the experiment did not measure anything. "Neutral" is a claim about the world; "within noise" is a claim about the experiment. Shipping on the first while holding evidence only for the second is how a team accumulates changes that were never evaluated and a belief that they were.

**Second, the arms are not the same size and the reason is calendar, not assignment.** Control is 2,506 and treatment is 894 because the rollout began on day 8. The MDE is computed at the smaller arm, 0.0325, and it is that large *because* of the imbalance. Fixing the windows before comparing costs nothing and roughly halves it.

**Third, and this is the finding:** the population is not the same in the two arms.

```
DECOMPOSITION answered rate
  aggregate delta   +0.0094
  rate effect       +0.0487   (what the change did)
  mix effect        -0.0613   (who showed up)
  interaction       +0.0220
    chat           share 0.383->0.254   rate 0.961->0.987  (+0.025)
    data           share 0.176->0.170   rate 0.814->0.875  (+0.061)
    document       share 0.250->0.213   rate 0.869->0.889  (+0.020)
    research       share 0.097->0.256   rate 0.566->0.725  (+0.159)
    tool_action    share 0.095->0.107   rate 0.772->0.854  (+0.082)
  WARNING: the mix moved more than the rates did. This number is mostly
           about who showed up.
```

Every route improved. `research` — the hardest route — went from 10% of traffic to 26%, because a better research route gets recommended internally. The mix effect is −6.1 points and it ate the entire +4.9-point improvement.

**The fix, and the lesson.** The aggregate readout was not wrong; it was answering a different question. *Did the population's success rate change?* — barely, and unmeasurably. *Did the change help?* — by about five points on every segment. Report the segments, and report the mix shift beside them, because the mix shift is also real news: research traffic more than doubled and somebody should know.

The general shape is Phase 13's invariant 74 in a new place: **five of the fifteen most recent failure-log entries were defects in the measuring instrument, not in the agent.** A readout that answers a question nobody asked is an instrument defect, and it is upstream of every decision you were about to make with it.

---

## g. Common pitfalls

**Reading "within noise" as "neutral".** The two differ by exactly the amount of evidence you have.

**Comparing calendar windows instead of populations.** Measured: Mon–Fri against a full week differs in weekend share 0.000 against 0.118 — two different populations wearing the same date range.

**Letting the simulated user grade.** It is a fixture. If it can set `goal_met`, your score measures the fixture's agreeableness.

**A model user in a number you will publish.** Report `user_was_model` beside every figure, and treat the gap between the scripted and the model user as the measurement of how much of your score belongs to the fixture.

**Assuming the canary dominates the rate.** It does not, and the sensitivity table below shows where it loses. A mechanism better along one axis and worse along another is the normal case; claiming otherwise is how a defence stops being checked.

**Treating the seeded traces as evidence.** They are a simulator with a known ground truth. Delete the banner and you have invented a measurement.

**Building a second harness.** `setup.windows` and `setup.persona` are setup like any other. The moment a canary lives in its own runner with its own report, "which suite said that?" becomes a question with two answers.

---

## h. The Atlas increment

**Files added.** All new; nothing in `atlas/` or in the Phase 13 eval modules imports them.

| Path | What it is |
|---|---|
| `evals/simuser.py` | `Persona`, `ScriptedUser`, `ModelUser`, `ConversationTurn`, `ConversationResult`; `normalise`, `mentions`, `requires_all`, `run_conversation` |
| `evals/online.py` | `TraceRecord`, `SegmentRate`, `CanaryFinding`, `CanaryReport`, `ABResult`, `MixDecomposition`, `WeekdayProfile`; `load_traces`, `in_window`, `segment_rates`, `canary_report`, `ab_compare`, `decompose_delta`, `weekday_profile`, `windows_comparable` |
| `scripts/gen_traces.py` | The seeded generator; `build_traces`, `digest`, `write_traces` |
| `tests/test_appendix_f6_simuser.py` | 15 tests |
| `tests/test_appendix_f6_online.py` | 21 tests |
| `evals/tasks/appendix_f6.json` | 5 tasks, each with a `provenance` block |
| `evals/run_appendix_f6.py` | The harness extension |
| `scripts/phase_f6_results.py` | `make results PHASE=_f6`, plus `ARGS=--write-traces` |
| `tests/hidden/test_phase_f6_a1.py` | `make grade PHASE=_f6` |
| `docs/RESULTS_APPENDIX_F.md`, `docs/FAILURE_LOG_APPENDIX_F.md` | Appendix-owned; the core documents stay untouched |

**Files changed: none.** `data/traces/` is generated and never committed. The task file is `appendix_f6.json`, so `load_tasks`' `phase*.json` glob skips it and **the committed baseline's 63 cells and suite version do not move** — verified by running `make eval-gate` after adding everything: still green, `unchanged 63`.

**Eval tasks added (5).** Two shown; all five carry provenance and pass `pass^3`.

```json
{"id": "f6-b-an-agent-that-never-asks-loses-the-user",
 "suite": "regression",
 "provenance": {"source": "golden",
   "derived_from": "appendix F.6 section e; the negative half of f6-a",
   "added": "2026-09-16", "split": "dev",
   "note": "Balance matters more than volume: an elicitation metric with only
            positive tasks has a trivially optimal implementation."},
 "setup": {"entrypoint": "evals.simuser:run_conversation", "persona": {"...": "..."},
           "force_route": "chat", "max_turns": 8,
           "goal_requires": ["S400-11872"],
           "fixtures": ["Warranty on the S400 is normally 24 months.", "..."]},
 "checks": [{"field": "conversation.stop_reason", "op": "eq", "value": "user_left"},
            {"field": "conversation.n_revealed", "op": "eq", "value": 0},
            {"field": "conversation.elicitation_rate", "op": "eq", "value": 0.0},
            {"field": "conversation.n_turns", "op": "eq", "value": 3}]}
```

The negative half makes the metric real: an agent answering from the defaults produces text that *looks* like an answer. `n_turns == 3` is the persona's patience, derived rather than guessed.

```json
{"id": "f6-e-the-aggregate-hides-the-effect-the-segments-show",
 "provenance": {"source": "synthetic",
   "derived_from": "scripts/gen_traces.py seed=7; planted TREATMENT_LIFT=0.04 on
                    every route plus a mix shift toward research", "...": "..."},
 "setup": {"entrypoint": "evals.online:decompose_delta", "by": "route", "fixtures": []},
 "checks": [{"field": "decomposition.exact", "op": "eq", "value": true},
            {"field": "decomposition.within", "op": "gt", "value": 0.0},
            {"field": "decomposition.mix", "op": "lt", "value": 0.0},
            {"field": "decomposition.mix_dominates", "op": "eq", "value": true},
            {"field": "ab.measurable", "op": "eq", "value": false},
            {"field": "ab.verdict", "op": "contains", "value": "within noise"}]}
```

The other three: `f6-a` (a patient agent elicits 3/3 in 4 turns, with `reveals_in_one_turn == 1` proving it asked rather than listed every cue), `f6-c` (a planted regression on one route; the canary must **hold** and must name `research`), and `f6-d` (the same healthy traffic over 40 requests must return `undecided`, with `blocking` empty — the task that keeps the third verdict reachable, invariant 30).

**Tests added (36), all on scripted fixtures and seeded traces.** They prove the decomposition is exact and recovers the planted lift, that every canary verdict and every conversation stop reason is reachable, that a mix-free comparison reports zero mix effect (the absolute assertion beside the comparison), that the generator is byte-identical for a fixed seed and different for a different one, and that every record round-trips its own dump.

**`make results PHASE=_f6`** — measured, Tier F, seed 7. The sensitivity table is the row that cost me a claim:

```
[4] the canary, three ways
    (b2) sensitivity: how big must the defect be for each to see it?
         defect | aggregate delta | mde    | rate sees it | canary
         1 in 2  |         -0.0917 | 0.0316 | True         | hold
         1 in 3  |         -0.0638 | 0.0316 | True         | pass
         1 in 4  |         -0.0492 | 0.0316 | True         | pass
         1 in 6  |         -0.0358 | 0.0316 | True         | pass
         1 in 8  |         -0.0268 | 0.0316 | False        | pass
         1 in 12 |         -0.0179 | 0.0316 | False        | pass
```

The canary is not uniformly more sensitive than the rate, and the first draft of this section said it was. `research`'s own baseline MDE is 0.108 — a small segment has a wide floor — so a diffuse degradation moves the aggregate before it crosses that floor. The floor margin is the knob: `rate − 1·mde` is chosen here, `rate − 0.5·mde` catches the 1-in-3 row and costs false holds, and that trade is a number to publish rather than bury.

Rows for `docs/RESULTS_APPENDIX_F.md`:

| experiment | metric | value | provenance |
|---|---|---|---|
| 1 | seeded window: traces · days · digest | 3,400 · 14 · `c68101083439` | Tier F, measured (simulated) |
| 2 | aggregate delta · MDE · verdict | +0.0094 · 0.0325 · within noise | simulated, measured |
| 2 | MDE at n = 50 / 250 / 1,000 / 10,000, p=0.86 | 0.136 / 0.061 / 0.030 / 0.010 | illustrative arithmetic, not a measurement |
| 3 | rate effect · mix effect · interaction | +0.0487 · −0.0613 · +0.0220 | simulated, measured |
| 3 | planted lift · recovered rate effect | +0.0400 · +0.0487 | simulated, measured |
| 3 | decomposition sums to the delta | exact to 1e-9 | asserted by test |
| 4 | canary on healthy traffic | `pass`, 0 findings | simulated, measured |
| 4 | canary on `research` degraded 2-in-3 | `hold`, `segment_floor research` | simulated, measured |
| 4 | canary on 40 healthy requests | `undecided`, 0 blocking | simulated, measured |
| 4 | smallest defect the canary holds on · the rate can see | 1 in 2 · 1 in 6 | simulated, measured |
| 5 | weekend share, Mon–Fri vs full week | 0.000 vs 0.118 → 1 complaint | simulated, measured |
| 6 | scripted agent: elicitation · turns to goal | 3/3 · 4 | Tier F, measured |
| 6 | cue-stuffing agent: facts extracted in one turn | 3 | Tier F, measured |
| 6 | elicitation rate over 10 personas, scripted vs model user | ____ · ____ | fill: `ATLAS_TIER=A make results PHASE=_f6` |
| 6 | goal met of 10 · median turns to goal | ____ · ____ | fill as above |
| — | offline test count | 1469 passed, 12 skipped | `make test-offline` |
| — | appendix eval tasks | 5/5, pass^3 100% | `python evals/run_appendix_f6.py` |
| — | core suite and gate, unchanged | 63/63, `unchanged 63`, gate pass | `make eval-gate` |

**Tier H, and what Tier A shows.** Experiment 6 is the only model-dependent table: 10 personas × 6 turns × 2 user kinds × 2 trials ≈ 240 calls, inside the 300 cap, cached. Tier A shows every column except the model-user one and all of the plumbing; what it cannot show is whether a small local model asks a *useful* question. Read both columns or neither.

**`docs/FAILURE_LOG_APPENDIX_F.md` entry.**

> **F-F6-01 — a per-turn counter that read zero on every row and summed correctly.** `run_conversation` measured the reveal count across the wrong side of `user.reply()`, so every `ConversationTurn.facts_revealed` recorded 0 while `n_revealed` and `elicitation_rate` — computed from the user's own list — were right. Every aggregate was correct, so no test of a total could fail; the defect was visible only in `reveals_in_one_turn`, which read 0 for an agent that had extracted three facts in one turn. That field is the harness's own hole detector, so the bug disabled exactly the metric that exists to show the harness cannot be trusted. Found by writing the cue-stuffing test the docstring promised. Lesson: a per-row number that is never checked against a row is not data, and a totals-only test cannot see it.

---

## i. Assignment — check whether it is a comparison at all

Build `evals/ab_preflight.py`, exporting `PreflightVerdict`, `PREFLIGHT_VERDICTS`, `SRMResult`, `ShiftReport`, `PreflightReport` and:

```python
def srm_check(*, control_n: int, treatment_n: int, expected_share: float = 0.5) -> SRMResult
def population_shift(control, treatment, *, by="route", tolerance=0.05) -> ShiftReport
def preflight(control, treatment, *, expected_share=0.5, by="route", tolerance=0.05) -> PreflightReport
```

Everything in `evals/online.py` answers *what does this delta mean?*. This answers the question that comes first and is skipped more often: **is this a comparison at all?**

A **sample ratio mismatch** is the situation where the observed split differs from the planned one — you assigned 50/50 and observed 60/40. It is one of the most useful indicators of data-quality problems in online controlled experiments precisely because it is a symptom of many different causes, from faulty bucketing to a crash that dropped one arm's sessions non-randomly. Whatever removed those sessions removed them selectively, so the arms are no longer two samples of one population.

**Acceptance criteria.**

1. `srm_check` uses `evals.stats.wilson_interval` on the observed treatment share and passes when the expected share falls inside it. No second implementation of "is this proportion different".
2. It behaves correctly at small n — the same 60/40 imbalance that fails at n = 2,000 does not fail at n = 20, because the interval is too wide to fault anything.
3. An uneven *planned* split is respected: 90/10 with `expected_share=0.1` passes, and 50/50 with `expected_share=0.1` fails.
4. `ShiftReport.total_variation` is half the sum of absolute share differences: 0 for identical mixes, 1 for disjoint ones, and `largest_move` **names** the segment that moved most.
5. `PreflightVerdict` is `proceed | read_segments_only | do_not_read`, and the ordering is the content: a broken assignment beats a mix shift.
6. Every verdict is reachable, everything round-trips its own dump, and nothing raises — including on two empty arms.

**UNAIDED CORE.** Criteria 2, 3 and 5. An assistant will reliably produce a fixed 50/50 assumption, a chi-square test that fires at n = 20, and a verdict that ORs the two conditions together — all three of which turn a pre-flight check into a thing people disable.

**Hidden test:** `tests/hidden/test_phase_f6_a1.py`. Run `make grade PHASE=_f6`. Do not read it; it skips itself until the module exists.

---

## j. Summary, and what to read next

**Offline grades a proposition; online observes a population.** A number computed over a moving population is not a number about your agent.

**A simulated user is a fixture, not a judge.** `goal_check` runs on the agent's text and is the only thing that can set `goal_met`. The default user is rule-based and deterministic, the model user is opt-in, and `user_was_model` travels with every result.

**A real user withholds and leaves.** Measured: a patient agent elicits 3/3 in four turns; an agent that answers from the defaults elicits 0/3 and loses the user at turn 3. And the harness's own hole — an agent that lists every cue at once extracts everything — is measured, printed, and decides nothing.

**A canary blocks on categorical events and has three verdicts.** A green canary over forty requests is `undecided`. And the canary is not uniformly better than a rate gate: it holds on a 1-in-2 degradation and passes on 1-in-3 while the aggregate sees down to 1-in-6. What it buys is specificity and reach, not sensitivity.

**Print the MDE beside every delta, and check the window before you read one.** A delta under the MDE is unmeasured, not small. A window is a population, not a period.

**Decompose the aggregate.** Measured on a dataset with a planted +0.04 on every route: aggregate +0.0094 against an MDE of 0.0325 (unreadable, and the wrong sign at large n), rate effect +0.0487, mix effect −0.0613, exact to 1e-9.

**What to read next.** F.7 ports the core to a second framework; F.8 is the interview bank. More usefully: this section is what turns Phase 13's committed baseline from a pre-launch artefact into something that keeps meaning what it said after traffic arrives, so the next step is to run `make eval-gate` and `preflight` on the same day and notice they answer different questions.

---

## F.6 additions

```
evals.simuser:
    ConversationStopReason (goal_met|user_left|agent_stopped|turn_cap, closed)
    Persona (frozen) / SimulatedUser (Protocol) / ScriptedUser / ModelUser
    ConversationTurn / ConversationResult
    normalise / mentions / requires_all
    run_conversation(agent, user, persona, *, goal_check, max_turns=6)

evals.online:
    TraceRecord (extra="allow") / load_traces / in_window
    answered / escalated / SegmentRate / segment_rates
    CanaryKind / CANARY_KINDS / BLOCKING_CANARY_KINDS
    CanaryFinding / CanaryReport / canary_report(...)   # verdict: hold|undecided|pass
    ABResult / ab_compare(...)
    MixDecomposition / decompose_delta(...)
    WeekdayProfile / weekday_profile / windows_comparable(...)

evals.ab_preflight (assignment):
    PreflightVerdict / PREFLIGHT_VERDICTS / SRMResult / ShiftReport / PreflightReport
    srm_check(...) / population_shift(...) / preflight(...)

scripts/gen_traces.py: build_traces / digest / write_traces  (data never committed)
evals/run_appendix_f6.py: install() / dispatch_appendix_f6(...) / main()
    payload prefixes: conversation. · canary. · kinds · segments · decomposition. ·
                      ab. · seasonality.
scripts/phase_f6_results.py: make results PHASE=_f6
    (--only window|power|decompose|canary|seasonality|simuser; ARGS=--write-traces)
tests/hidden/test_phase_f6_a1.py: make grade PHASE=_f6
docs/RESULTS_APPENDIX_F.md · docs/FAILURE_LOG_APPENDIX_F.md
```

## VERSIONS.md delta rows

| fact | value | source URL | checked-on |
|---|---|---|---|
| Pinned library versions for this section | unchanged from Phase 13's pins; re-verified installable | https://pypi.org/project/langgraph/ | 2026-09-16 |
| Sample ratio mismatch, definition and status | the observed sample ratio differs from the expected; one of the most useful indicators of data-quality issues in online controlled experiments, and a symptom of many distinct causes | Fabijan et al., KDD'19 — https://dl.acm.org/doi/10.1145/3292500.3330722 | 2026-09-16 |
| SRM root-cause taxonomy (assignment / execution / log processing / analysis stages) | published taxonomy and practitioner rules of thumb | https://www.microsoft.com/en-us/research/articles/diagnosing-sample-ratio-mismatch-in-a-b-testing/ | 2026-09-16 |
| General reference for online controlled experiments | Kohavi, Tang & Xu, *Trustworthy Online Controlled Experiments: A Practical Guide to A/B Testing*, Cambridge University Press, 2020 | cited in https://arxiv.org/pdf/2208.07766 | 2026-09-16 |
| Seeded trace window: traces · days · digest | 3,400 · 14 · `c68101083439` | `make results PHASE=_f6 ARGS=--write-traces` | 2026-09-16 |
| Planted per-route lift · recovered rate effect | +0.0400 · +0.0487 | measured, `make results PHASE=_f6` | 2026-09-16 |
| Aggregate delta · MDE at 14 days | +0.0094 · 0.0325 (within noise) | measured, simulated traces | 2026-09-16 |
| Smallest planted defect: canary holds · aggregate detects | 1 in 2 · 1 in 6 | measured, simulated traces | 2026-09-16 |
| Tier H cap, this section | 300 calls, cached to `data/cache/` | `scripts/phase_f6_results.py --plan` | 2026-09-16 |
| Core suite after this section | 63 tasks, baseline unchanged, `make eval-gate` green | measured | 2026-09-16 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-16 |

**Pre-release APIs used in code: none.**
