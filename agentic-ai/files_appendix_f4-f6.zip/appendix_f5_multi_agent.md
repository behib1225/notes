# Appendix F.5 — Multi-Agent Build: Supervisor, Researcher, Analyst, Writer

## a. Read this if …

… a job advert says "multi-agent", or your Phase 11 decision document said switch.

---

## b. What it is, and why it was deferred

The supervisor that `docs/MULTI_AGENT_DECISION.md` designed in section 1 and declined to build in section 4. A coordinator with no domain tools of its own, three named specialists behind it, an explicit handoff, and a comparison against the pipeline Atlas actually ships — on quality, cost and latency, in the same columns Phase 11's table used.

It was deferred because Phase 11 decided against it, and the deferral is the *shape* of that decision rather than a shortcut around it. Section 5 lists four measurements that would reverse the call. This is the build those conditions point at. Read it the way the decision document intends: if your own decision doc said "keep the pipeline", build this once so you have measured the thing you declined rather than quoted somebody else's number about it; if it said "switch", this is what you switch to, and you should be able to name which of the four conditions tripped. Building a supervisor because it is the interesting architecture is how you end up with the failure Phase 11 §8 reproduced.

---

## c. Plugs into Phase 11

Build on the snapshot `atlas_phase_11.zip`. If your code diverged, start from that snapshot.

**What it assumes, named concretely.** `docs/MULTI_AGENT_DECISION.md` itself — sections 1, 2 and 3 are the specification this build implements, and section 3's arithmetic is what the comparison checks. `atlas.flow.app.HANDLER_TOOLS["research"]`, the declared tool set the roster is asserted against. `atlas.flow.orchestrate.scoped_registry`, for per-specialist action spaces. `atlas.graph.adapter.run_core`, which is each specialist. `atlas.llm.structured` and Phase 2's repair loop, for the delegation decision. `atlas.graph.app.run_atlas_graph` with `force_route="research"`, the pipeline arm of the comparison. `scripts/phase11_results.py`'s `pipeline_tokens` and `supervisor_tokens`, imported rather than copied. Phase 8's `estimate_message_tokens`. Nothing from Phase 12 or later — which matters, because reversal condition 3 is exactly the Phase 12 concern.

**One thing in the source material contradicts this appendix, and you should know before you follow it.** Section 5 of the decision document ends *"Where the build lives when a condition is met: Appendix F.5, on branch `f5-supervisor` off tag `phase-11`"*, and `ATLAS_INTERFACES.md` invariant 12 says the repository is a real Git repository whose Appendix F builds branch off phase tags. This appendix distributes snapshots, not branches: there is no `f5-supervisor` and no `phase-11` tag to look for. Read both references as *"the snapshot `atlas_phase_11.zip`, plus `atlas_appendix_f5.zip` on top of it"*. The contradiction is not a defect in the decision — the decision is unaffected — and it is exactly the drift invariant 53 warns about: a prose claim about where something lives is worth what the thing it points at is worth, which here is nothing.

| | |
|---|---|
| Study hours | 1.5 read · 3.0 build · 1.5 assess |
| Compute time | under 3 minutes on the baseline laptop, Tier F |
| Tier A calls per sweep | ~180 (12 tasks × 2 arms × 3 trials) |
| Tier H calls | ≤ 300 for the whole section, cached to `data/cache/` |
| Cost | $0.00 |
| Repo snapshot | `atlas_appendix_f5.zip` (built on `atlas_phase_11.zip`) |

**Applying to the finished code.** In `atlas_phase_16.zip`, `atlas/graph/adapter.py`, `atlas/graph/core.py`, `atlas/flow/orchestrate.py` and `scripts/phase11_results.py` are byte-identical to Phase 11. One thing differs and it changes behaviour: Phase 16 appends two MCP tools to `HANDLER_TOOLS["research"]`, so on the final code the coverage assertion will refuse the shipped roster the moment an MCP connection is wired and those tools exist in the registry. That is the assertion doing its job — grant `company_data_query` to the analyst and `company_docs_search` to the retriever, or narrow `require_coverage` and say why.

---

## d. Concepts

### The decision document is the specification

Section 2 of `MULTI_AGENT_DECISION.md` is a table of every message boundary in the supervisor design and what does *not* cross it. Three rows are bolded, and the document says plainly that those three "are not trade-offs; they are regressions against invariants Atlas already holds." It then lists three fixes as preconditions for the build being comparable to the pipeline at all.

That list is the most valuable artefact in Phase 11, because it converts "multi-agent is harder" into three named defects with three named remedies:

1. **Failed attempts cross the worker boundary,** so repetition is detectable in code rather than by a model noticing.
2. **The `partial` flag crosses to the writer and to the answer.**
3. **The roster's tool coverage is asserted at build time,** so an infeasible allocation is a build error and not a loop.

> **Misconception: "the supervisor will notice it is going in circles."** It will not, reliably, and Phase 11 §8 measured why. That supervisor's prompt sizes went `151, 376, 310, 376, 310, 376` — after turn 1 its input took exactly two values forever, so no policy over it could escape. The model was not stupid; it was being handed the same two prompts alternately. Invariant 9 already says this: **the harness owns termination.** A multi-agent system does not get an exemption because the loop is now made of agents.

### A handoff is a label, not a callable

The framework's idiom for a handoff is a **tool** that returns a `Command`: the model calls `transfer_to_analyst`, and the tool returns `Command(goto="analyst", graph=Command.PARENT)`, which specifies a state update and a node transition as one operation. There is a prebuilt library built on that mechanism. It is a reasonable general design and it is not Atlas's, for two reasons that are both already written down.

A tool the model can call is a capability the roster grants. Putting `transfer_to_analyst` in the supervisor's tool set puts control flow in the action space, which is what invariant 33 forbids: a model returns a **label**, never a callable. And Phase 10 measured what `Command` does to the record: without `destinations=`, `draw_mermaid()` prints `a --> __end__` for a node that jumps to `b`, so the topology's only serialisation becomes wrong and invariant 62's oracle turns against invariant 62.

So Atlas's supervisor emits a `DelegationDraft` with two fields, one of them a `Literal`, and a conditional edge routes on the label. The handoff is a value you can put in a record, assert on in an eval check, and see in the diagram.

> **Concept check 1.** `DelegationDraft` has no `done` field. Delegating to the `writer` is how the supervisor says it has enough. What does that buy, in terms of which component owns termination — and what would a `done: bool` field cost you the first time a model set it on turn one?

### Specialisation is an architecture, and it turns out to be a discount

Phase 11's cost arithmetic charged every turn the same static floor: instructions 506 tokens, two tool schemas at 147 each. Measured on this build, that is wrong in a way that runs against the decision document's conclusion, and the measurement is worth more than the estimate.

A pipeline worker is scoped to `HANDLER_TOOLS["research"]` — five tools on a registry with no index, **734 estimated tokens of schema on every branch**. The supervisor's retriever sees three tools (383 tokens), its analyst two (351), its writer none (1), and the supervisor itself holds no tools at all, so its delegation turns pay no schema block whatsoever. Phase 9 measured tool schemas at 73.9% of a three-tool prompt before the conversation existed; that block is the dominant static cost, and specialisation shrinks it per worker.

The consequence, measured on a two-finding task: the supervisor used **2× the model calls** and **1.09× the prompt tokens**, against an arithmetic prediction of 1.76× at n=2. The call-count argument against the supervisor survives and sharpens; the token argument weakens substantially.

> **Misconception: "the cost model settles it."** A cost model is arithmetic over assumptions, and section 3 names its six assumptions precisely so you can find the wrong one. The assumption that broke was *"every turn pays the same static floor"*, and nothing but running both arms would have found it.

### The cheap oracle, promoted to an assertion

Phase 11 §8 left a diagnostic worth keeping: **a healthy supervisor's context grows monotonically, so an oscillating one has lost its history and a constant one never had one.** Here it is a test: `build_supervisor_prompt` is pure, so four successive delegation records produce four strictly increasing prompt sizes — measured `[424, 605, 661, 717]`.

> **Concept check 2.** Why is the *strictly increasing* assertion stronger than "the prompt contains the previous report"? Name a bug the first catches and the second does not.

---

## e. The build, step by step

```mermaid
flowchart LR
    START([START]) --> S[supervise<br/>no domain tools]
    S -->|label: retriever| R[retriever<br/>retrieve_documents, read_file,<br/>list_files, search_web]
    S -->|label: analyst| A[analyst<br/>query_db, calculate]
    S -->|label: writer| W[writer<br/>no tools]
    S -->|stop_reason set| E([END])
    R --> S
    A --> S
    W --> E
```

Three labels and an `END`, all four in the `path_map`. Every arrow out of `supervise` is a value a check can name; none of them is a tool the model can call.

### Step 1 — the roster, and the assertion that found a bug in the design document

```python
# excerpt: atlas/graph/supervisor.py
ROSTER_TOOLS: dict[Specialist, tuple[str, ...]] = {
    "retriever": ("retrieve_documents", "read_file", "list_files", "search_web"),
    "analyst": ("query_db", "calculate"),
    "writer": (),
}
```

The `writer` holds nothing. That is invariant 20 used as a design tool — a prohibition is an absent tool — and it is what makes the writer's citations traceable to a specialist rather than to a call nobody logged.

`search_web` is in that tuple and is **not** in the decision document's section 1 table. The coverage assertion found that on its first run: `HANDLER_TOOLS["research"]` declares `search_web`, the document's roster granted it to nobody, and no allocation of that roster could complete a web-answerable request. A table in a design document is a claim; the assertion is the test.

```python
# excerpt: atlas/graph/supervisor.py
def assert_roster_covers(
    roster: dict[str, tuple[str, ...]],
    *,
    required: Sequence[str],
    registry: ToolRegistry | None = None,
) -> None:
    granted = {name for tools in roster.values() for name in tools}
    missing = [name for name in required if name not in granted]
    if missing:
        raise RosterCoverageError(
            f"the roster cannot reach {sorted(missing)}, which the route "
            f"declares. No allocation of this roster can complete a task "
            f"needing them, so the supervisor would delegate until its turn "
            f"cap and return nothing. Grant them to a specialist, or narrow "
            f"the route's declared tools. Roster union: {sorted(granted)}."
        )
```

It reports **every** missing tool in one pass, matching `validate_plan`'s contract from Phase 4, and it runs on by default (invariant 58). Passing `()` disables it, explicitly, and is how the ping-pong below is reproduced at all.

### Step 2 — what the model may say

```python
# excerpt: atlas/graph/supervisor.py
class DelegationDraft(BaseModel):
    model_config = ConfigDict(extra="forbid")

    delegate_to: Specialist = Field(
        description="Which specialist should take the next step."
    )
    instruction: str = Field(
        description="One instruction for that specialist, in one sentence."
    )
```

Two fields. `delegate_to` is a `Literal`, so it renders as a JSON Schema enum and the model returns a label. No `done`, no `confidence`, no `tools_needed`: termination belongs to the harness (invariant 9), and a field the model can set is a field the model can lie about (invariant 26). The draft goes through Phase 2's `structured()`, so a draft that will not parse ends the run as `bad_delegation` **before** anything is dispatched.

### Step 3 — fix 1, repetition in code

```python
# excerpt: atlas/graph/supervisor.py
def delegation_signature(specialist: str, instruction: str) -> str:
    """A (who, what) pair, normalised. Pure."""
    return f"{specialist.strip().lower()}({' '.join(instruction.lower().split())})"
```

Whitespace and case only. Normalising harder would make two genuinely different instructions collide, and a false `no_progress` is worse than a slow one: it ends a run that was working. `seen_delegations` is a pure function of the record, so the guard survives persistence.

When it fires, it fires **as a delegation**, not only as a stop reason — a guard that fires correctly and is read by nothing is indistinguishable from an absent guard (invariant 62). The repeated instruction is in the record, so a reader can see *what* was repeated.

### Step 4 — fix 2, the partial flag crosses both boundaries

The supervisor's own prompt carries every past delegation **with its outcome**, successes and failures alike. The writer's prompt carries the same plus a banner:

```python
# excerpt: atlas/graph/supervisor.py
    failures = [d for d in findings if not d.get("ok")]
    errors = sorted({e for d in findings for e in (d.get("tool_errors") or [])})
    if failures or errors:
        lines += [
            "",
            f"INCOMPLETE EVIDENCE: {len(failures)} of {len(findings)} "
            f"specialist turns failed; tool errors seen: {errors or 'none'}.",
            "Say what could not be established. Do not fill a gap with a "
            "plausible figure.",
        ]
```

Conditional, not unconditional: a warning present on every run is a warning nobody reads. And the flag does not stop at the writer — `SupervisorResult.partial` is computed from every incompleteness signal (invariant 35), so a run can be `stop_reason="final"` with an answer and still be labelled partial, which is the case the decision document said gets lost.

### Step 5 — the graph, and where control flow lives

```python
# excerpt: atlas/graph/supervisor.py
    def route(state: SupervisorState) -> str:
        if state.get("stop_reason"):
            return END
        pending = state.get("pending") or {}
        return str(pending.get("to_agent") or END)

    graph = StateGraph(SupervisorState)
    graph.add_node("supervise", supervise)
    for name in SPECIALISTS:
        graph.add_node(name, _specialist(name))
    graph.add_edge(START, "supervise")
    graph.add_conditional_edges(
        "supervise", route, {**{n: n for n in SPECIALISTS}, END: END}
    )
    for name in ("retriever", "analyst"):
        graph.add_edge(name, "supervise")
    graph.add_edge("writer", END)
```

Each specialist is `run_core` over a `scoped_registry`, with `allow_writes=False` **unconditionally** — matching what `research` already does, so no specialist can reach the approval gate. The fuse is derived: `SUPERVISOR_SUPERSTEPS_PER_TURN = 2`, so `supervisor_recursion_limit(4) == 10`, set inside the entry point.

### Step 6 — count the calls, do not predict them

```python
# excerpt: atlas/graph/supervisor.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def n_model_calls(self) -> int:
        """Every call actually made. MEASURED, summed from the turns."""
        return sum(d.n_model_calls for d in self.delegations)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def n_worker_turns(self) -> int:
        """Delegations that actually REACHED a specialist, writer excluded.

        A turn the repetition guard refused, or one whose draft would not
        parse, never reached a worker and must not be counted as one: doing so
        made `predicted_model_calls` read 7 on a run that spent 5. A predicted
        number that is wrong in the direction of the point you are making is
        the worst kind, so the filter is `n_model_calls > 1` -- one supervision
        call and at least one specialist call.
        """
        return sum(
            d.specialist not in ("writer", "(unparsed)") and d.n_model_calls > 1
            for d in self.delegations
        )

    @computed_field  # type: ignore[prop-decorator]
    @property
    def predicted_model_calls(self) -> int:
        """`2n + 1` from the decision document, for comparison with the truth."""
        return 2 * self.n_worker_turns + 1
```

Both, side by side, because the gap between them is the finding. Section 3 predicts `2n + 1` on the assumption of one model call per worker. A specialist is a ReAct loop, so a worker that reaches for a tool costs two. Measured on a task where one worker used `list_files`: **5 calls against a prediction of 3**, with `n_model_calls == len(client.calls)` asserted so the count is real rather than derived.

### With an assistant

**Safe to delegate:** the `Delegation` / `SupervisorResult` record shapes and their `render()` methods; the pytest parametrisation; converting the eval task JSON.

**Not safe to delegate:** the three fixes. Ask an assistant for "a supervisor over three agents" and you will get the prebuilt shape — handoff tools returning `Command`, a `done` flag on the supervisor's output, and no repetition guard — because none of those is wrong in general. Every one is a specific regression against something Atlas already holds, and you can only see them if you enumerate the boundaries first.

A prompt that works:

> I have `SupervisorResult.delegations`, a list of `Delegation` records each with `specialist`, `instruction`, `ok`, `report` and `tool_errors`. Write `build_supervisor_prompt(task, *, roster, delegations, max_turns) -> str`, pure. Every past delegation must appear with its instruction and its outcome, failures included. Do not summarise or truncate the history. Then write a test asserting that four successive delegations produce four strictly increasing prompt lengths.

---

## f. Debug this trace

Phase 11 §8's failure, reproduced against this build. The roster is deliberately broken — `retriever: (list_files,)`, `analyst: (calculate,)`, `writer: ()` — and the coverage assertion is disabled with `require_coverage=()`, which is the only way to reach this state.

```
$ make results PHASE=_f5 ARGS="--only pingpong"

[3] the Phase 11 section 8 failure, reproduced against this build
    detector on, preventer off (require_coverage=()):
      stop_reason        no_progress
      turns used         3 of 6
      model calls spent  5
      answer             none
    Phase 11 section 8, same roster, no guards: 6 turns, 12 calls, no answer.
```

And the run itself:

```
SUPERVISOR  How many days of runway do we have, and which policy sets the reserve floor?
roster: {"retriever": ["list_files"], "analyst": ["calculate"], "writer": []}
------------------------------------------------------------------------
ok  [turn 1] retriever The runway figure is not in the documents.
ok  [turn 2] analyst   I have no burn figure.
FAIL [turn 3] retriever repeated a delegation already made
------------------------------------------------------------------------
(no answer)
stop_reason=no_progress  turns=3  model calls=5 (2n+1 predicts 5)  tokens=1142
PARTIAL: failed turns [3]
```

**What the trace says, and what it does not.** The guard worked: three turns instead of six, five model calls instead of twelve, and a stop reason a grader can name instead of an exhausted cap. That is a real improvement and also a trap, because `no_progress` reads like "the model gave up" and invites you to fix the prompt.

**The diagnosis.** Look at turns 1 and 2. The retriever reported that the runway figure is not in the documents; the analyst reported that it has no burn figure. Neither failed — both `ok` — and between them they have said the same thing twice: *the number this task needs is not reachable from here.* The supervisor then re-asked the retriever, because from its point of view the only remaining move was one it had already made.

Bug 1 would be "no memory of its own delegations" — not present; the prompt carries both turns. Bug 2 would be "no worker could see the other's output" — not present either. Bug 3 is the root cause and the only one that matters: **the union of the workers' tool sets does not cover the task.** The runway figure lives in the database, and `query_db` is granted to nobody. Invariant 20 read backwards: *a capability the roster lacks is a prohibition nobody declared.*

**The fix, and why it is not a better prompt.** Turn the preventer back on:

```
    preventer on (the default):
      RosterCoverageError, 0 model calls spent
      the roster cannot reach ['query_db', 'read_file', 'search_web'], which
      the route declares. No allocation of this roster can complete a task...
```

Zero model calls. The defect is now a build failure with the missing tools named, and it cannot reach a trace at all. That is the difference between a guard and a fix: `no_progress` detects the symptom on every affected request forever, and costs five calls each time; the assertion removes the class.

**The second lesson, and it is about me rather than the agent.** The first version of `predicted_model_calls` counted the refused turn as a worker turn and printed 7 against 5 — a prediction inflated in exactly the direction that flattered the finding I was writing about. It is not a coincidence that it went unnoticed; a wrong number that supports your argument is the one you do not check. The fix is one predicate, and the habit is: when a measured and a predicted value sit side by side, re-derive the predicted one by hand at least once.

---

## g. Common pitfalls

**Building the supervisor because the architecture is interesting.** Phase 11's document is a decision with four named reversal conditions. If you cannot say which one tripped, you are buying adaptive re-planning you have no evidence you need — and 87% of the overhead is exactly that purchase.

**Quoting one multiplier.** The ratio is a function of plan length, 1.59× to 3.03× in the arithmetic, and 1.09× on tokens once you measure it. Anyone quoting a single figure has not asked how many steps; anyone quoting the arithmetic has not run both arms.

**Comparing against the wrong baseline, silently.** Section 3 names its baseline out loud: Phase 10's single-level subgraph, not Phase 5's full pipeline with its per-level critic. Do the same when you extend the table.

**Letting a specialist write.** `allow_writes=False` unconditionally on every specialist, and a test that a `write_file` call through a mis-granted roster leaves no file.

**Trusting the roster table in a design document.** The one in `MULTI_AGENT_DECISION.md` was missing a tool the route declares. It was written carefully, reviewed, and shipped. The assertion found it on the first run of the code.

**Concurrency across specialists on a fixture tier.** Delegations are sequential here (invariant 38), and on Tier A the local runner holds one model anyway.

---

## h. The Atlas increment

**Files added.** All new; nothing in `atlas/` imports them, so the `research` route stays the pipeline.

| Path | What it is |
|---|---|
| `atlas/graph/supervisor.py` | `DelegationDraft`, `Handoff`, `Delegation`, `SupervisorResult`, `SupervisorState`, `RosterCoverageError`; `assert_roster_covers`, `delegation_signature`, `seen_delegations`, `build_supervisor_prompt`, `build_writer_task`, `build_supervisor_graph`, `run_supervisor` |
| `tests/test_appendix_f5_supervisor.py` | 22 tests |
| `evals/tasks/appendix_f5.json` | 4 tasks |
| `evals/run_appendix_f5.py` | The harness extension |
| `scripts/phase_f5_results.py` | `make results PHASE=_f5` |
| `tests/hidden/test_phase_f5_a1.py` | `make grade PHASE=_f5` |
| `data/recordings/appendix_f5_frontier.PLACEHOLDER.md` | The frontier-transcript form, empty on purpose |
| `docs/RESULTS_APPENDIX_F.md`, `docs/FAILURE_LOG_APPENDIX_F.md` | Appendix-owned; the core documents stay untouched |

**Files changed: none.** As in F.4, `make results PHASE=_f5` and `make grade PHASE=_f5` work through the existing `$(PHASE)` substitution. The runner is its own file rather than shared with F.4, because the two sections plug into different snapshots; all three appendix runners capture `harness.dispatch` inside `install()` so that any subset installs in any order.

**Eval tasks added (4).** All four pass `pass^3` on Tier F. Two shown:

```json
{"id": "f5-a-a-roster-that-cannot-reach-a-declared-tool-fails-before-any-call",
 "setup": {"entrypoint": "atlas.graph.supervisor:build_supervisor_graph",
           "roster": {"retriever": ["list_files"], "analyst": ["calculate"],
                      "writer": []},
           "fixtures": []},
 "checks": [{"field": "coverage.type", "op": "eq", "value": "RosterCoverageError"},
            {"field": "coverage.message", "op": "contains_all",
             "value": ["query_db", "search_web"]},
            {"field": "client.n_calls", "op": "eq", "value": 0}]}
```

The last check is the one that matters: a build that spent a model call before refusing has *detected* the defect rather than prevented it, and the two are worth different amounts.

```json
{"id": "f5-d-the-measured-call-count-exceeds-what-2n-plus-1-predicts",
 "checks": [{"field": "supervisor.n_model_calls", "op": "gt",
             "ref": "supervisor.predicted_model_calls"},
            {"field": "supervisor.n_model_calls", "op": "eq", "ref": "client.n_calls"},
            {"field": "supervisor.n_worker_turns", "op": "eq", "value": 1}]}
```

Graded as a **relation** (`ref`), not against a hard-coded number, so it survives a change to the fixture list.

The other two are `f5-b-a-repeated-delegation-ends-the-run-before-the-turn-cap` (asserting `n_turns == 3` against a cap of 6, because a run that reached the cap also stops and stopping for the wrong reason is how a guard passes its own test) and `f5-c-a-failed-specialist-turn-reaches-the-writer-and-the-final-record` (asserting the banner in the writer's assembled prompt *and* `partial` on a run whose `stop_reason` is `final`).

**Tests added (22), all on scripted fixtures.** They prove the three fixes are real, that the draft schema admits no field the harness owns, that the topology declares a path to `END`, that no specialist can write, and that `SupervisorResult` round-trips its own dump. They prove nothing about whether a model delegates sensibly.

**`make results PHASE=_f5`** — the comparison, in Phase 11's columns, measured Tier F, seed 7, one task with two findings:

```
[1] single versus multi on one task, MEASURED on Tier F (2 findings)
    | metric | pipeline | supervisor | ratio |
    |---|---|---|---|
    | model calls | 3 | 6 | 2.00x |
    | units of work | 2 | 3 | 1.50x |
    | est. prompt tokens | 1994 | 2179 | 1.09x |
    | answer produced | yes | yes | — |
    | labelled partial | no | no | — |
    | answer quality (1-5) | ____ | ____ | ____ |
    | every figure traceable to a source | ____ | ____ | ____ |
    | median wall clock per task (s) | ____ | ____ | ____ |

    where the estimate and the measurement disagree:
      pipeline worker sees 5 tool schemas = 734 tokens, every branch
      retriever  sees 3 tool schemas = 383 tokens
      analyst    sees 2 tool schemas = 351 tokens
      writer     sees 0 tool schemas = 1 tokens
      and the supervisor itself holds NO tools, so its delegation
      turns pay no schema block at all.
```

Both token columns are estimates over the messages each arm actually sent, using Phase 8's estimator — not usage fields, because the fixture client's usage numbers are fixture numbers and the research subgraph's `aggregate` node leaves `HandlerOutcome`'s token fields at 0 (measured; a real gap in Phase 10). One estimator over both arms is a comparison; two different sources is not.

Rows for `docs/RESULTS_APPENDIX_F.md`:

| experiment | metric | value | provenance |
|---|---|---|---|
| 1 | model calls, pipeline · supervisor, n=2 findings | 3 · 6 (2.00×) | Tier F, measured |
| 1 | estimated prompt tokens, pipeline · supervisor | 1,994 · 2,179 (1.09×) | Tier F, measured (est.) |
| 1 | same ratio predicted by section 3's arithmetic at n=2 | 1.76× | illustrative arithmetic, not a measurement |
| 1 | tool-schema tokens per turn: pipeline worker · retriever · analyst · writer · supervisor | 734 · 383 · 351 · 1 · 0 | Tier F, measured |
| 2 | model calls measured · `2n+1` predicted (one tool-using worker) | 5 · 3 | Tier F, measured |
| 3 | ping-pong, guard on: turns · calls · answer | 3 of 6 · 5 · none | Tier F, measured |
| 3 | same roster, Phase 11 §8, no guards | 6 turns · 12 calls · none | Phase 11, measured |
| 3 | same roster, coverage assertion on | `RosterCoverageError`, 0 calls | Tier F, measured |
| 3 | supervisor prompt sizes over 4 turns | 424, 605, 661, 717 (strictly increasing) | Tier F, measured |
| 4 | tasks answered, of 12 | ____ · ____ | fill: `ATLAS_TIER=H make results PHASE=_f5` |
| 4 | answers whose every figure appears in a cited source | ____ · ____ | fill as above |
| 4 | delegations repeating an earlier instruction | ____ · ____ | fill as above |
| — | offline test count | 1332 passed, 12 skipped | `make test-offline` |
| — | appendix eval tasks | 4/4, pass^3 100% | `python evals/run_appendix_f5.py` |
| — | core eval suite, unchanged | 54/54 | `python evals/run.py --trials 1` |

**Tier H, and what Tier A shows.** The quality rows need a model. The sweep is 12 tasks × 2 arms × 3 trials = 72 episodes; at the measured 5–7 calls per supervisor episode and 3 per pipeline episode that is roughly 180 calls, inside the 300 cap, cached to `data/cache/`. **Run Tier A first.** Calls, tokens, turns, the repetition guard and the partial label are facts about Atlas and are all measurable there; whether the supervisor's *allocation* was sensible is a fact about the model, and it is the one row Tier A cannot settle.

**The frontier transcript.** `data/recordings/appendix_f5_frontier.PLACEHOLDER.md` ships empty and says so in its first line. It contains the task verbatim, both run procedures, the recording format, and an explicit instruction not to fill it with a plausible transcript. A transcript of a run nobody performed is evidence manufactured to support a claim that was made first (invariant 48).

**`docs/FAILURE_LOG_APPENDIX_F.md` entry.**

> **F-F5-01 — the design document's roster could not do the job it specified.** `docs/MULTI_AGENT_DECISION.md` section 1 grants the retriever `retrieve_documents, read_file, list_files` and the analyst `query_db, calculate`, while `HANDLER_TOOLS["research"]` declares `search_web`. No specialist held it, so no allocation of that roster could answer a web-answerable request — Phase 11 §8's bug 3, in the document that diagnosed bug 3. Found on the first run of `assert_roster_covers`, before a model call. Fix: grant `search_web` to the retriever. Lesson: a table in a design document is a claim, and the fix that prevents rather than detects is also the fix that audits the design.

---

## i. Assignment — the reader the record needs

Build `atlas/graph/handoff_audit.py`, exporting `AuditKind`, `AUDIT_KINDS`, `BLOCKING_AUDIT_KINDS`, `AuditFinding`, `AuditReport` and:

```python
def audit_supervisor(result: SupervisorResult, *, roster=None, required=None) -> AuditReport
```

Reason 5 for keeping the pipeline was *"we cannot yet read a multi-agent trace"*, and invariant 40 says a record type ships with its reader in the same commit. Shipping the supervisor without one repeats the omission the decision document used as an argument against it. This is Phase 4's mechanical critic, pointed at a `SupervisorResult`: pure, no model, never raises.

**Acceptance criteria.**

1. `AUDIT_KINDS` is a closed `Literal` with exactly five members: `repeated_instruction`, `unused_specialist`, `no_synthesis`, `worker_tool_error`, `roster_gap`. Every one has a line of code that sets it, reachable from `audit_supervisor` (invariant 30).
2. `BLOCKING_AUDIT_KINDS` is defined **by consequence**: `repeated_instruction` and `roster_gap` mean the run could not have succeeded; the other three mean the answer is worth less than it looks. `worker_tool_error` is not blocking.
3. `repeated_instruction` uses `delegation_signature`, so whitespace and case do not defeat it, and the finding names the turn that *repeated*, not the first occurrence.
4. A specialist with **no tools** is never reported as `unused_specialist`.
5. `required=None` omits the `roster_gap` check rather than guessing a default.
6. `AuditReport` accepts its own `model_dump()`, exposes `n_findings`, `kinds`, `blocking` and `clean`, and `render()` prints every finding's kind.
7. `audit_supervisor` never raises, including on a `SupervisorResult` with an empty roster and no delegations.

**UNAIDED CORE.** Criteria 2, 4 and 5. Specifically: deciding *by consequence* which kinds block, deciding that a tool-less specialist is not a finding, and deciding that a missing `required` means "do not check" rather than "check against a guess". An assistant will happily make everything blocking, flag the writer, and default `required` to `HANDLER_TOOLS["research"]` — all three of which produce a report that is technically complete and that nobody will read twice.

**Hidden test:** `tests/hidden/test_phase_f5_a1.py`. Run `make grade PHASE=_f5`. Do not read it. It skips itself until the module exists.

---

## j. Summary, and what to read next

**Build this from a decision, not from a diagram.** Section 5 lists four measurements that reverse Phase 11's call. If you cannot name the one that tripped, you are buying mid-flight re-decision you have no evidence you need.

**The boundary table is the specification.** Three bolded omissions are regressions, not trade-offs, and all three have code in this build. The third found a gap in the design document's own roster on its first run, at zero model calls.

**A handoff is a label.** The framework's idiom is a tool returning `Command(goto=...)`, which puts control flow in the model's action space and, without `destinations=`, makes the generated diagram wrong. A `Literal` plus a conditional edge is a handoff you can assert on, grade, and see.

**Measure both arms before you quote a multiplier.** Measured: 2.00× the model calls and **1.09×** the prompt tokens against an arithmetic prediction of 1.76×, because specialisation shrinks the tool-schema block the cost model held constant. `2n + 1` is a floor, not an estimate, because a specialist is a ReAct loop.

**And the guard is not the fix.** `no_progress` turned Phase 11 §8's six turns and twelve calls into three turns and five. The coverage assertion turned them into zero.

**What to read next.** F.6 fills the three empty quality columns in this section's table; F.7 ports the same design elsewhere. Before either, re-read your own decision document: this build's job was to make one of its four reversal conditions measurable, and the honest next step is to say which.

---

## F.5 additions

```
atlas.graph.supervisor:
    Specialist / SPECIALISTS / ROSTER_TOOLS / SupervisorStopReason
    SUPERVISOR_SUPERSTEPS_PER_TURN = 2 / supervisor_recursion_limit(max_turns)
    RosterCoverageError
    DelegationDraft (extra="forbid": delegate_to, instruction — nothing else)
    Handoff (frozen) / Delegation / SupervisorResult / SupervisorState
    assert_roster_covers(roster, *, required, registry=None)
    delegation_signature(specialist, instruction) / seen_delegations(delegations)
    render_roster(roster) / build_supervisor_prompt(...) / build_writer_task(...)
    build_supervisor_graph(client, *, registry, roster=None, max_turns=4,
                           max_steps=3, seed=7, max_tokens=None,
                           require_coverage=None)
    run_supervisor(client, task, *, registry, ...) -> SupervisorResult

atlas.graph.handoff_audit (assignment):
    AuditKind / AUDIT_KINDS / BLOCKING_AUDIT_KINDS / AuditFinding / AuditReport
    audit_supervisor(result, *, roster=None, required=None) -> AuditReport

evals/run_appendix_f5.py: install() / dispatch_appendix_f5(...) / main()
    payload prefixes: coverage. · supervisor. · writer. · environment.
scripts/phase_f5_results.py: make results PHASE=_f5
    (--only compare|predict|pingpong|quality)
tests/hidden/test_phase_f5_a1.py: make grade PHASE=_f5
docs/RESULTS_APPENDIX_F.md · docs/FAILURE_LOG_APPENDIX_F.md
data/recordings/appendix_f5_frontier.PLACEHOLDER.md
```

## VERSIONS.md delta rows

| fact | value | source URL | checked-on |
|---|---|---|---|
| `langgraph` pinned version for this section | unchanged from Phase 11's pin; re-verified available | https://pypi.org/project/langgraph/ | 2026-09-16 |
| Framework handoff idiom | a tool returning `Command(goto=<agent>, graph=Command.PARENT)`, optionally carrying `Send(...)` | https://docs.langchain.com/oss/python/langchain/multi-agent/handoffs | 2026-09-16 |
| Framework custom multi-agent guidance | `Command` combines a state update and a node transition in one operation; prebuilt agent/`ToolNode` natively support handoff tools returning `Command` | https://docs.langchain.com/oss/python/multi-agent-custom | 2026-09-16 |
| Prebuilt supervisor library | `langgraph-supervisor`, a separate package implementing tool-based handoffs; NOT imported by `atlas/` | https://reference.langchain.com/python/langgraph-supervisor | 2026-09-16 |
| Prebuilt swarm library | `langgraph-swarm`, agents hand off directly to one another; NOT imported by `atlas/` | https://docs.langchain.com/oss/javascript/multi-agent-custom | 2026-09-16 |
| `Command(goto=...)` without `destinations=` in `draw_mermaid()` | node drawn as `--> __end__`; topology serialisation wrong | measured, Phase 10 `docs/RESULTS.md` | 2026-09-10 |
| Supervisor superstep cost per turn | 2 (supervise, specialist); `supervisor_recursion_limit(4) == 10` | measured, `tests/test_appendix_f5_supervisor.py` | 2026-09-16 |
| Measured vs predicted model calls, one tool-using worker | 5 measured · 3 predicted by `2n+1` | measured, `make results PHASE=_f5` | 2026-09-16 |
| Measured vs predicted prompt-token ratio, n=2 | 1.09× measured · 1.76× predicted | measured / illustrative arithmetic | 2026-09-16 |
| Tool-schema tokens per turn (pipeline worker · retriever · analyst · writer · supervisor) | 734 · 383 · 351 · 1 · 0 | measured, Tier F, `CHARS_PER_TOKEN=4.0` | 2026-09-16 |
| Tier H cap, this section | 300 calls, cached to `data/cache/` | `scripts/phase_f5_results.py --plan` | 2026-09-16 |
| Frontier transcript | NOT recorded; placeholder form only | `data/recordings/appendix_f5_frontier.PLACEHOLDER.md` | 2026-09-16 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-16 |

**Pre-release APIs used in code: none.** `langgraph-supervisor` and `langgraph-swarm` are named in prose and never imported.
