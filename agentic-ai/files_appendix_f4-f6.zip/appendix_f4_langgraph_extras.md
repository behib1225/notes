# Appendix F.4 — LangGraph Extras: Time Travel and Map-Reduce

## a. Read this if …

… you debug long multi-turn runs, or you process document batches.

---

## b. What it is, and why it was deferred

Two capabilities that sit on top of machinery Atlas already has, and neither of which changes what Atlas can do for a user. **Time travel** is replay, forking and alternative trajectories over the checkpointer Phase 10 wired for human-in-the-loop — a debugging instrument, not a feature. **Map-reduce** is a fan-out over a document corpus, one branch per document, with the concurrency bounded — which is Phase 10's `Send` fan-out pointed at a different input.

They were deferred for the same reason, stated honestly: neither is load-bearing for the capstone. Phase 10 needed persistence to suspend a run before a write, and it got time travel for free without using it; Phase 10 needed a fan-out to research several sub-questions, and a document batch is that fan-out with a larger and more predictable branch count. Teaching either in the core would have spent a phase's word budget on depth rather than on the next capability, and the core's job is to reach a working assistant in four months.

What you get here instead is the depth: the operations, the measurements that make them behave unlike the intuition, and — for the map-reduce — the argument that **"bounded concurrency" is three separate bounds with three separate reasons**, which is the part every tutorial that shows you `max_concurrency` leaves out.

---

## c. Plugs into Phase 10

Build on the snapshot `atlas_phase_10.zip`. If your code diverged, start from that snapshot.

**What it assumes, named concretely.** `atlas.graph.core.build_core_graph` compiled with a `checkpointer=`, and its `CoreState` channels `messages`, `stop_reason`, `approvals`, `pending`. `atlas.graph.core.reset_core_run_channels` and `gated_recursion_limit_for`. `atlas.graph.adapter.trajectory_from_state`, which rebuilds a `ReactTrajectory` from state the process never ran. `atlas.graph.tools.calls_of` and the `additional_kwargs["atlas_tool_result"]` payload every `ToolMessage` carries. `ToolSpec.read_only` from Phase 3. Phase 6's `atlas.rag.extract.ingest_directory` and the `ExtractedDoc.usable` / `quality.flags` pair. Phase 10's approval gate, because a gated write is what makes the invariant-37 refusal below test something real. Nothing from Phase 11 or later.

| | |
|---|---|
| Study hours | 1.0 read · 1.5 build · 0.5 assess |
| Compute time | under 2 minutes on the baseline laptop, Tier F |
| Tier A calls per sweep | 8 (experiment 4 only, one per document) |
| Tier H calls | 0 |
| Cost | $0.00 |
| Repo snapshot | `atlas_appendix_f4.zip` (built on `atlas_phase_10.zip`) |

**Applying to the finished code.** In `atlas_phase_16.zip`, `atlas/graph/core.py`, `atlas/graph/tools.py` and `atlas/graph/adapter.py` are byte-identical to Phase 10, `evals/run.py` has grown (its `dispatch` is still a module-level function and `load_tasks` still globs `phase*.json`), and the Makefile still substitutes `$(PHASE)` into the same three paths. Everything here applies unchanged.

**A note on Git.** `ATLAS_INTERFACES.md` invariant 12 says the repository is a real Git repository whose Appendix F builds branch off phase tags. This appendix distributes snapshots, not branches: there is no tag to check out. Read every such reference as "the snapshot named for that phase, plus this section's snapshot on top of it".

---

## d. Concepts

### A checkpoint is a state, and a thread is a lineage

Phase 10 used the checkpointer as a place to pause. It is also a record. Every superstep writes a checkpoint; a thread is the chain of them; and the framework will start a run from any link in the chain instead of from the end.

Run one three-call episode through Atlas's core and the thread holds **ten** checkpoints — measured — one before the graph starts, then one per superstep through the `model → decide → tools` cycle. Three of those ten have `next == ("model",)`: the states just before a model call, one per turn. Those three are the interesting ones, because "what if the model had said something else here?" is the only counterfactual an agent debugger usually wants.

> **Misconception: "replay reproduces the run."** It reproduces the *graph*, not the model. Re-running from checkpoint k calls the client again. On Tier F the scripted fixture queue advances to the next entry; on Tier A the model is asked afresh. Measured: a replay from step 3 consumed the next fixture and produced a different answer. To reproduce a run, replay the *recording* — `atlas.record.ReplayClient`, Phase 2 — which is a different mechanism answering a different question.

### Branching in place moves the tip

The framework's model is that resuming from an old checkpoint creates a new branch on the **same thread**, and that `update_state` does not roll back a thread: it creates a new checkpoint branching from the given point, and the original history remains intact. Nothing is destroyed. But measured on Atlas's core, after an in-place replay `get_state(thread)` describes the re-run, the history grows from 10 checkpoints to 13, and **three step numbers appear twice**. The original tip is still addressable by `checkpoint_id`, and "the state of thread t-1" now means something it did not mean five minutes ago.

```
thread t-1, after a run and then one in-place replay
                                                    (steps collide!)
  step -1 ──▶ 0 ──▶ 1 ──▶ 2 ──▶ 3 ──▶ 4 ──▶ …──▶ 8   original branch
                               │
                               └──▶ 4'──▶ …──▶ 9      replayed branch  ◀── get_state(t-1)

  fork(into="t-1a") instead:
  thread t-1   -1 ──▶ 0 ──▶ 1 ──▶ 2 ──▶ 3 ──▶ 4 ──▶ …──▶ 8   ◀── get_state(t-1), unmoved
                               │ copy of values
  thread t-1a          -1 ──▶ 0 ──▶ 1 ──▶ …                   ◀── get_state(t-1a)

  ★ = next == ("model",), the only checkpoints fork() will start from
      step -1   0★   1   2   3★   4   5   6★   7   8
                     decide tools model …
```

That matters for Atlas specifically, because a thread id is the key an approval audit trail is namespaced by (Phase 10's `persist` node). "Thread t-14, three approvals" has to keep meaning what it said. So Atlas's policy is: **fork onto a new thread**. The source is untouched, each alternative has a name, and the provenance lives in a record.

> **Concept check 1.** After an in-place replay, `checkpoint_at(app, "t-1", step=4)` raises `KeyError`. Why is raising better than returning the first match?

### The fork point is not free to choose

Seeding a fresh thread enters the graph at `START`, which reaches `model` first. A fork from a checkpoint whose `next` is `tools` would therefore re-run the *model*, not the pending batch, producing a trajectory that is neither the original nor the one you asked for. Atlas refuses to fork anywhere except a checkpoint with `next == ("model",)`, and names the nearest eligible one.

There is a second refusal and it is the important one. Re-executing a segment re-executes its **tools**. Invariant 37: a step whose tool is not `read_only` is never auto-retried, never replayed and never cached. Time travel is replay with a nicer name, and the workspace has no memory of which universe it is in. So `fork` and `replay` scan the continuation for calls to tools the registry marks non-read-only and refuse, naming them, unless you pass `force=True`.

> **Misconception: "the approval record protects me."** It does not. An approval is evidence that a human oversaw a particular action in a particular conversation. Copying it into a fork carries that evidence into a run nobody approved — invariant 66's manufactured-oversight failure, arriving through a feature nobody thought of as a gate. Atlas seeds a fork's `approvals` channel **empty**, so the fork re-proposes and re-asks. The framework agrees on the mechanics: interrupts are always re-triggered during time travel.

### Granularity is decided by where the checkpointer is

By default a subgraph inherits the parent's checkpointer, and the parent treats the whole subgraph as a single superstep, so time travelling from before it re-executes it from scratch. Measured on Atlas's front door: a full `chat` run leaves seven parent checkpoints — `__start__`, `router`, `chat`, `critic`, `persist`, `respond`, end. The whole route is one of them.

This is why F.4 builds on `build_core_graph` and not on `build_atlas_graph`. At the front door you can fork before a route; you cannot fork before the third model call inside it.

> **Concept check 2.** Atlas's `tool_action` subgraph is where writes happen. Given the granularity rule, what is the *only* thing forking at the parent level before `tool_action` can tell you — and why does the invariant-37 refusal matter more there, not less?

### Bounded concurrency is three bounds

Analysing twenty documents is one model call per document, fanned out. "Bound the concurrency" sounds like one decision. It is three, and they are not substitutes.

**Bound 1, the fan-out width.** How many `Send`s you emit at all. This decides the *bill*, and it is decided before anything is spent.

**Bound 2, the in-flight limit.** How many branches run at once. This decides *burst*. Measured on a 1-vCPU box: `max_concurrency` at 1, 2, 3 and 5 gave peak workers in flight of exactly 1, 2, 3 and 5, and wall clock fell from 0.41 s to 0.11 s for eight 50 ms branches. **Unset**, peak in flight was 5 — `min(32, cpu_count + 4)`, the host thread pool. That is a fact about the machine, not about the provider, and it changes when you deploy.

**Bound 3, the per-branch output cap.** Concurrency bounds requests in flight; it does not bound tokens per minute, and the published limit that bites first is usually the token one. The burst is `worker_limit × max_tokens`, and it is the product you compare against a rate card.

And one number that looks like a bound and is not. `recursion_limit` is the fuse. A fan-out of n branches is **one superstep**, so the analyser's fuse is `3 + 2 = 5` whether the fan-out is one document or three hundred — measured, and the reason `mapreduce_recursion_limit()` takes no argument. *The fuse does not grow with the fan-out; the bill does.*

> **Concept check 3.** A provider publishes 60 requests/minute and 40,000 output tokens/minute. Your per-document cap is 500 output tokens. Which of the three bounds does each published limit constrain, and what is the tightest legal `worker_limit`?

---

## e. The build, step by step

### Step 1 — a checkpoint you can name

The framework's `StateSnapshot` is a namedtuple. Invariant 11 says anything an eval check can name must survive `model_dump()`, so the first thing is a record.

```python
# excerpt: atlas/graph/timetravel.py
class Checkpoint(BaseModel):
    model_config = ConfigDict(frozen=True)

    thread_id: str
    checkpoint_id: str
    step: int
    next: tuple[str, ...]
    source: str
    n_messages: int
    stop_reason: str | None
    proposed_tools: tuple[str, ...]

    @computed_field  # type: ignore[prop-decorator]
    @property
    def forkable(self) -> bool:
        """True iff a fresh thread seeded here would resume in the right place."""
        return self.next == (MODEL_NODE,)
```

Frozen, because a checkpoint you can edit in place is a checkpoint id that no longer describes anything. `history()` reverses the framework's newest-first ordering once, here, rather than at every call site.

`checkpoint_at(..., step=n)` **raises on an ambiguous step** — the measurement above turned into a guard. On a thread that has been replayed in place, two branches carry the same step numbers, and a function that silently returned the first would fork the branch you were not looking at.

### Step 2 — the refusals, before the operations

```python
# excerpt: atlas/graph/timetravel.py
def writes_after(
    app: Any, checkpoint: Checkpoint, *, registry: ToolRegistry
) -> list[str]:
    """Non-read-only tools called on this thread AFTER `checkpoint`."""
    tip = app.get_state(thread_config(checkpoint.thread_id))
    messages = list((tip.values or {}).get("messages") or [])
    names: list[str] = []
    for message in messages[checkpoint.n_messages :]:
        for call in calls_of(message):
            spec = registry.get(call.name)
            if spec is not None and not spec.read_only:
                names.append(call.name)
    return names
```

`registry` is required and never defaulted (invariant 10): `read_only` is a property of the tool set the caller wired, not of the name, and a function that guessed from names would wave `write_report` through. Duplicates are kept, because two writes are worth seeing as two. The guard turns the list into a refusal that says what to do instead:

```python
# excerpt: atlas/graph/timetravel.py
    writes = writes_after(app, checkpoint, registry=registry)
    if writes and not force:
        raise ForkRefused(
            f"refusing to {verb} thread {checkpoint.thread_id!r} from step "
            f"{checkpoint.step}: the continuation calls {sorted(set(writes))}, "
            "which are not read_only. Invariant 37 -- a step whose tool is not "
            "read-only is never auto-retried, never replayed and never cached. "
            "Re-run it against a fresh workspace, or pass force=True and own "
            "the second write."
        )
```

### Step 3 — fork onto a new thread

```python
# excerpt: atlas/graph/timetravel.py
    source = app.get_state(config_for(checkpoint))
    messages = list((source.values or {}).get("messages") or [])
    edited = edit_messages is not None
    if edit_messages is not None:
        messages = list(edit_messages(list(messages)))

    target = thread_config(into)
    app.update_state(
        target,
        {"messages": messages, "approvals": [], "stop_reason": None, "pending": None},
        as_node="__start__",
    )
    state = app.invoke(None, {**(config or {}), **target})
```

Three decisions in nine lines. `as_node="__start__"` seeds a *fresh* thread so the graph resumes at `model` — the framework's documented way of making it think a node already ran. `approvals` is seeded empty. And `edit_messages` is a **pure function over a copy of the transcript**, which is how "what if the tool had returned something else?" is asked; a pure function is testable without a graph, a mutating callback is not.

`replay()` is the in-place operation, kept because sometimes it is what you want, and it returns a `ReplayRecord` carrying `previous_tip` and a computed `tip_moved`. The record is how the caller learns what happened to the thread rather than noticing later.

### Step 4 — the map-reduce, bound by bound

```python
# excerpt: atlas/graph/mapreduce.py
def select_documents(
    docs: Sequence[ExtractedDoc], *, limit: int = DEFAULT_DOC_LIMIT
) -> tuple[list[str], int]:
    """(selected ids, number offered). Pure, deterministic, no model."""
    if limit < 0:
        raise ValueError("limit must not be negative")
    return [doc.doc_id for doc in docs[:limit]], len(docs)
```

Corpus order, not "the most relevant n". Selecting by relevance would be a retrieval decision, and Atlas already has a retriever with an evaluation harness behind it (Phase 6); a second, unevaluated ranker hidden inside a fan-out is the silent policy invariant 59 is about. Returning the count offered alongside the selection is what makes the next part possible.

```python
# excerpt: atlas/graph/mapreduce.py
    @computed_field  # type: ignore[prop-decorator]
    @property
    def coverage(self) -> float:
        """Documents actually READ over documents the corpus offered."""
        return round(self.n_read / self.n_offered, 4) if self.n_offered else 0.0

    @computed_field  # type: ignore[prop-decorator]
    @property
    def partial(self) -> bool:
        return bool(
            self.n_failed
            or self.n_skipped
            or self.n_selected < self.n_offered
            or not self.findings
        )
```

`coverage` divides by `n_offered`, **never** by `n_selected`: a ratio whose denominator is the cap always reads near 1.0 and measures the cap rather than the corpus. `partial` is every incompleteness signal available (invariant 35), so a capped run is partial even when every branch succeeded.

The worker skips a document whose extraction is unusable, spending no model call and recording why:

```python
# excerpt: atlas/graph/mapreduce.py
        if not doc.usable:
            finding = finding.model_copy(
                update={
                    "skipped": True,
                    "note": "extraction unusable: " + ", ".join(flags),
                    "elapsed_s": round(time.perf_counter() - started, 4),
                }
            )
            return {"findings": [finding.model_dump()]}
```

A deliberate departure from Phase 6's D-33, which defaults `exclude_blocking=False` so flags travel to the citation rather than filtering. D-33 is about a retrieval whose cost is a similarity computation; here each document costs a model call, and spending one on column-scrambled text buys a fluent summary of scrambled text. The flag still travels — into the finding, into the report, into `partial`.

The entry point sets every fuse, because invariant 58 says a capability the caller must remember to switch on is off in production:

```python
# excerpt: atlas/graph/mapreduce.py
    state = app.invoke(
        {"request": request},
        {
            "max_concurrency": worker_limit,
            "recursion_limit": mapreduce_recursion_limit(),
        },
    )
```

### With an assistant

**Safe to delegate:** the record shapes and their `render()` methods; the pytest scaffolding for the concurrency tests; converting the eval task JSON.

**Not safe to delegate:** the two refusals. An assistant asked to "handle the case where the tool wrote a file" will reliably produce a warning, a log line, or a `force` default of `True` — all three of which are the absent-gate failure.

A prompt that works:

> In `atlas/graph/timetravel.py` I have `writes_after(app, checkpoint, *, registry) -> list[str]`, returning non-read-only tool names called after a checkpoint. Write `_guard(app, checkpoint, *, registry, force, verb)` that raises `ForkRefused` when the list is non-empty and `force` is False. Do not add a default for `force`, do not log-and-continue, and make the message name the tools and state the remedy. Then write two pytest tests: one where the continuation wrote and the guard raises, one where the checkpoint is *after* the write and it does not.

---

## f. Debug this trace

A student forks an episode to ask "what if the model had read the notes first?" and gets this:

```
>>> cp = tt.checkpoint_at(app, "t-1", step=3)
>>> rec = tt.fork(app, cp, into="t-1a", registry=registry)
>>> rec.render()
fork t-1a <- t-1@step3 edited=False stop=final answer='Based on the notes, 24 months.'

>>> tt.compare_threads(app, ["t-1", "t-1a"], registry=registry).render()
thread        t-1             t-1a
 stop_reason   final           final
!answer        The answer is   Based on the
 sources       None            None
 n_steps       3               3
 tools_called  ['list_files',  ['list_files',
 tool_errors   []              []
 observations  ['notes.md  (5  ['notes.md  (5

>>> tt.checkpoint_at(app, "t-1", step=3)
KeyError: step 3 is ambiguous on thread 't-1': 2 branches (1f1b1e51, 1f1b1e6a).
This thread has been replayed in place. Select a Checkpoint from history()
by checkpoint_id instead.
```

The fork worked. The second `checkpoint_at` on the *same thread* then failed — and the student has not replayed anything.

**The diagnosis.** Look at `tools_called` and `observations`: identical across both threads, including the `notes.md` observation, in the branch that was supposed to *not* have read the notes yet. The comparison is not comparing two branches. It is comparing a thread against a copy of itself, and something has added a second branch to `t-1`.

The cause is a line above the visible trace:

```python
rec = tt.fork(app, cp, into="t-1", registry=registry)   # earlier, "just to try it"
```

That raises `ForkRefused` — but the student had wrapped their exploration in a `try/except Exception: pass` while iterating in a notebook, and reached for `tt.replay(app, cp, registry=registry)` next. The replay ran, in place, on `t-1`. From then on the source thread had two branches, its tip was the replayed one, and the "original" the comparison shows is the replay.

**The fix, and the lesson.** The `KeyError` is doing its job — it is the only thing in the session that noticed. Recover by addressing branches explicitly:

```python
>>> [c.checkpoint_id[:8] for c in tt.history(app, "t-1") if c.step == 3]
['1f1b1e51', '1f1b1e6a']
>>> original = [c for c in tt.history(app, "t-1") if c.step == 3][0]
>>> tt.fork(app, original, into="t-1b", registry=registry)
```

**A broad `except` around an exploratory call converts a refusal into a silent policy change.** `ForkRefused` was raised, correctly, by the mechanism designed to prevent exactly this, and a bare `except Exception` turned it into "try the other function". The second lesson is smaller and worth as much: once a thread has been replayed in place, `step` is a label for humans and `checkpoint_id` is the address.

---

## g. Common pitfalls

**Grading a comparison with no absolute assertion beside it.** Two forked trajectories that diverge tell you the fork worked; they do not tell you either is right. Invariant 60 applies verbatim — `test_comparing_a_thread_with_itself_finds_nothing` exists so that "diverged" can be trusted.

**Forking with a live client shared across branches.** `alternatives()` is sequential on purpose: a fan-out over an ordered fixture list serialises or it is not a test (invariant 38).

**Treating `max_concurrency` as a rate limit.** It bounds requests in flight on one process. The number to compare against a rate card is `worker_limit × max_tokens`; the number to compare against a call budget is `doc_limit`.

**Concurrency on Tier A.** A local runner holds one loaded model. Raising `worker_limit` above 1 or 2 there buys queueing and worse reproducibility.

**Believing the corpus is a promise about document length.** `make_document_analyser` truncates at `max_chars`; one 90k-character file would otherwise silently blow the context of whichever branch drew it.

**Leaving a broken `make results` in the tree.** Worth seeing on real code: `scripts/phase10_results.py` in both the Phase 10 and Phase 16 snapshots calls `recursion_limit_for(4, gated=True)`, and that keyword was reverted from `atlas/graph/core.py` by Phase 10's own F-10-06. `make results PHASE=10` raises `TypeError` before printing a row, and every unit test is green because no test runs the results script. This appendix must not fix a core file, so it reports it: the fix is `gated_recursion_limit_for(4)`. Invariant 41's shape, in the file whose job is to produce evidence.

---

## h. The Atlas increment

**Files added.** All new; nothing in `atlas/` imports them, so deleting them leaves Phase 10 exactly as it shipped.

| Path | What it is |
|---|---|
| `atlas/graph/timetravel.py` | `Checkpoint`, `ReplayRecord`, `ForkRecord`, `TrajectoryComparison`, `ForkRefused`; `history`, `forkable_checkpoints`, `checkpoint_at`, `writes_after`, `replay`, `fork`, `alternatives`, `compare_threads` |
| `atlas/graph/mapreduce.py` | `DocFinding`, `MapReduceReport`, `MapReduceState`; `select_documents`, `make_document_analyser`, `build_document_mapreduce`, `run_document_mapreduce`, `mapreduce_recursion_limit` |
| `atlas/prompts/files/atlas_docmap.v1.md` | The per-document reader prompt; checksum `094c7ebd0af5`, **pinned by `tests/test_appendix_f4_mapreduce.py`** |
| `tests/test_appendix_f4_timetravel.py` | 17 tests |
| `tests/test_appendix_f4_mapreduce.py` | 19 tests |
| `evals/tasks/appendix_f4.json` | 4 tasks |
| `evals/run_appendix_f4.py` | The harness extension |
| `scripts/phase_f4_results.py` | `make results PHASE=_f4` |
| `tests/hidden/test_phase_f4_a1.py` | `make grade PHASE=_f4` |
| `docs/RESULTS_APPENDIX_F.md` | Where this section's measured rows go |
| `docs/FAILURE_LOG_APPENDIX_F.md` | Where this section's failure entries go |

**Files changed: none.** Three conventions make that possible and all three are worth stealing. The Makefile substitutes `$(PHASE)` into `scripts/phase$(PHASE)_results.py` and `tests/hidden/test_phase$(PHASE)_*.py`, so naming the files `phase_f4_*` makes `make results PHASE=_f4` and `make grade PHASE=_f4` work with no Makefile edit. `check_docs.py` globs `phase_*.md` only, so an `appendix_f4_*.md` document needs no `DOC_BLOCKS.json` entry — which also means the code blocks above are **not** pinned by `make check-docs`, so the snapshot is the source of truth for them and not this document. And the results and failure-log rows go into **appendix-owned** documents rather than appending to `docs/RESULTS.md`, because appending to a core document a later phase owns is a core file change.

**The harness extension, and its honest cost.** `evals/run.py` picks a call shape from a chain of `if entrypoint.endswith(...)`. A new shape means a new branch, which is a core edit. So `evals/run_appendix_f4.py` extends the chain from outside: it reuses the harness's `Task`, `Check`, `run_checks`, `build_environment`, `make_client_factory`, `run_trial`, `summarise` and `format_report` unchanged, and rebinds one function.

```python
# excerpt: evals/run_appendix_f4.py
def install() -> None:
    """Rebind `evals.run.dispatch`, capturing whatever is there NOW. Idempotent.

    The capture happens inside `install()` and not at module import, and the
    difference is a silent bug. With an import-time capture, installing this
    section after another appendix section had already installed itself would
    close over the PRISTINE dispatch and drop the other section's entrypoints
    -- no error, no warning, just tasks that fall through to the wrong branch.
    Every appendix runner captures at install time, so they chain in any order.
    """
    global _ORIGINAL
    if _ORIGINAL is not None:
        return
    _ORIGINAL = harness.dispatch
    captured = _ORIGINAL

    def extended(task: harness.Task, **kwargs: Any) -> tuple[dict[str, Any], str | None]:
        handled = dispatch_appendix_f4(task, **kwargs)
        return handled if handled is not None else captured(task, **kwargs)

    harness.dispatch = extended  # type: ignore[assignment]
```

Say plainly what that costs: a module that rebinds a function in another module is a seam you have to know about. If you owned `evals/run.py` you would add a `DISPATCH_HOOKS` list and four lines at the top of `dispatch`, and append to it from here. That is the better change and it is forbidden to this appendix. The rebinding is the same extension point built from outside, reversible by deletion — the property a deferred build needs. Appendix task files are named `appendix_*.json` so `load_tasks`, which globs `phase*.json`, never picks them up: **the core suite's task count does not move because this file exists.**

**Eval tasks added (4).** Two shown; all four are in the snapshot.

```json
{"id": "f4-a-a-fork-leaves-the-source-thread-where-it-was",
 "kind": "environment", "tier": "F",
 "setup": {"entrypoint": "atlas.graph.timetravel:alternatives",
           "prompt": "What is 2+2, and what notes do we have?",
           "tools": ["list_files", "read_file", "calculate"],
           "max_steps": 4, "allow_writes": false, "thread_id": "t-1",
           "fork_at_step": 3, "forks": ["t-1a", "t-1b"],
           "fixtures": ["...5 scripted replies..."]},
 "checks": [{"field": "source.tip_unchanged", "op": "eq", "value": true},
            {"field": "source.n_forkable", "op": "eq", "value": 3},
            {"field": "forks.0.answer", "op": "contains", "value": "Branch A"},
            {"field": "comparison.diverged", "op": "contains", "value": "answer"},
            {"field": "environment.files_created", "op": "len_eq", "value": 0}]}
```

```json
{"id": "f4-b-replaying-past-a-write-is-refused-and-the-file-stays-written-once",
 "kind": "environment", "tier": "F",
 "setup": {"entrypoint": "atlas.graph.timetravel:replay",
           "prompt": "Write the Q3 report to r.md",
           "tools": ["write_file", "list_files", "read_file"],
           "allow_writes": true, "thread_id": "t-2", "fork_index": 0,
           "resume": [{"decisions": [{"kind": "approve", "operator_id": "op1"}]}],
           "fixtures": ["...a write proposal, then a final answer..."]},
 "checks": [{"field": "refusal.type", "op": "eq", "value": "ForkRefused"},
            {"field": "refusal.message", "op": "contains", "value": "write_file"},
            {"field": "environment.files_created", "op": "len_eq", "value": 1},
            {"field": "environment.file_texts", "op": "contains", "value": "DRAFT Q3"},
            {"field": "environment.files_after", "op": "eq",
             "ref": "environment.files_before"}]}
```

The other two are `f4-c-a-capped-map-reduce-labels-the-corpus-it-did-not-read` (asserting `n_offered == 20`, `coverage ≈ 0.25`, `partial`) and `f4-d-an-unusable-document-is-recorded-not-summarised` (asserting `n_read == 19` beside `n_selected == 20`, and — the half that makes it real — `analysed.doc_ids not_contains "fsb-2026-04"`).

Note task b's last check: `files_after eq ref files_before`. The refusal is graded against the **filesystem**, not only the record, because F-10-03's exact shape was a correct refusal beside the effect it claimed to prevent.

**Tests added (36), all on scripted fixtures.** They prove the refusals fire, that `worker_limit` is reached and not exceeded, that findings arrive in argument order when workers finish backwards, that a raising branch is recorded without killing its siblings, that both records round-trip their own `model_dump()`, that the fuse is constant in n, and that the new prompt's checksum is pinned. They prove nothing about whether a real model writes a faithful per-document summary.

**`make results PHASE=_f4`** — measured output, Tier F, seed 7:

```
[1] worker_limit vs workers actually in flight  (8 documents, 50ms each)
    worker_limit=1  peak in flight=1  wall=0.408s  argument order kept=True
    worker_limit=2  peak in flight=2  wall=0.206s  argument order kept=True
    worker_limit=3  peak in flight=3  wall=0.156s  argument order kept=True
    worker_limit=5  peak in flight=5  wall=0.106s  argument order kept=True

[2] doc_limit vs model calls, coverage and the partial label
    corpus: 20 documents  fuse: recursion_limit=5 at every width
    | doc_limit | calls | read | skipped | coverage | partial |
    | 2  | 2  | 2  | 0 | 0.10 | True |
    | 5  | 5  | 5  | 0 | 0.25 | True |
    | 8  | 8  | 8  | 0 | 0.40 | True |
    | 20 | 19 | 19 | 1 | 0.95 | True |

[3] time travel: what each operation does to the thread
    checkpoints on one 3-call episode: 10   forkable (next == model): 3
    fork  -> new thread t-1a; source tip moved: False
    fork  -> model calls the fork consumed: 1
    replay-> tip_moved=True, previous tip 1f1b1e6f still addressable
    replay-> checkpoints on the thread: 10 -> 13; duplicated step numbers: 3
```

Rows for `docs/RESULTS_APPENDIX_F.md`:

| experiment | metric | value | provenance |
|---|---|---|---|
| 1 | peak workers in flight at `worker_limit` ∈ {1,2,3,5} | 1, 2, 3, 5 | Tier F, measured |
| 1 | peak with `max_concurrency` unset, 1-vCPU host | 5 = `min(32, cpu_count+4)` | Tier F, measured |
| 1 | findings in argument order at every bound | 8/8 | Tier F, measured |
| 2 | `recursion_limit` for the analyser, any fan-out width | 5 | Tier F, measured |
| 2 | full-corpus run still labelled partial | True (1 unusable document) | Tier F, measured |
| 3 | checkpoints per 3-call core episode · forkable | 10 · 3 | Tier F, measured |
| 3 | source tip moved by `fork` · by `replay` | False · True | Tier F, measured |
| 3 | duplicated step numbers after one in-place replay | 3 | Tier F, measured |
| 4 | summaries naming a figure present in the document | ____ | fill: `ATLAS_TIER=A make results PHASE=_f4` |
| 4 | summaries naming a figure **not** in the document | ____ | fill as above |
| 4 | unusable document described as unreadable (of 1) | ____ | fill as above |
| 4 | mean completion tokens per document | ____ | fill as above |
| — | offline test count | 1341 passed, 12 skipped | `make test-offline` |
| — | appendix eval tasks | 4/4, pass^3 100% | `python evals/run_appendix_f4.py` |
| — | core eval suite, unchanged | 51/51 | `python evals/run.py --trials 1` |

Experiment 4 is the only model-dependent table and this script cannot invent it. `--with-model` prints a refusal saying so. Tier A shows that the plumbing delivers one summary per document, in order, inside the bound; it cannot show whether the summaries are faithful, and row 2 is the number that decides that.

**`docs/FAILURE_LOG_APPENDIX_F.md` entry.**

> **F-F4-01 — a broad `except` converted a refusal into a policy change.** A notebook session wrapped exploratory time-travel calls in `try/except Exception: pass`. `fork(into="t-1")` raised `ForkRefused` ("a fork onto its own thread is a replay"), the exception was swallowed, the session fell through to `replay()`, and from then on `t-1` carried two branches with colliding step numbers while `compare_threads` silently compared a thread against a copy of itself. Found by `checkpoint_at`'s ambiguity guard — the only thing in the session that noticed. Fix: address branches by `checkpoint_id` once a thread has been replayed; never wrap a refusal in a bare `except`.

---

## i. Assignment — plan the fan-out before you run it

**[fast track: do this one]** Build `atlas/graph/fanout_plan.py`, exporting `BindingConstraint`, `BINDING_CONSTRAINTS`, `WorkerConstraint`, `WORKER_CONSTRAINTS`, `FanoutPlan` and:

```python
def plan_fanout(*, n_documents: int, call_budget: int, burst_token_cap: int,
                max_tokens: int, worker_ceiling: int) -> FanoutPlan
```

A bound whose reason you cannot state is a magic number, and a magic number in a fan-out is a bill nobody predicted. This function chooses all three bounds from the constraints you actually have and **names the constraint that chose each one**.

**Acceptance criteria.**

1. `FanoutPlan` carries `n_offered`, `doc_limit`, `worker_limit`, `max_tokens`, `reason`, `detail`, `worker_reason`, `refused`, and computed `estimated_calls`, `estimated_output_tokens`, `peak_output_tokens_in_flight`. It accepts its own `model_dump()` (invariant 31).
2. `reason` is typed `BindingConstraint`, a closed `Literal` of `corpus | call_budget | refused`, and every member has a line of code that sets it (invariant 30). The human-readable sentence lives in `detail`, not in `reason` — a check grades the label with `eq`, a person reads the detail.
3. `doc_limit = min(n_documents, call_budget)`; `reason` is `"corpus"` when the corpus binds and `"call_budget"` when the budget does.
4. `worker_limit` is the minimum of `worker_ceiling`, `burst_token_cap // max_tokens` and `doc_limit`, and `worker_reason` names which one bound.
5. `max_tokens > burst_token_cap` is **refused**, not rounded down to one worker: one branch alone breaks the cap, so no `worker_limit` is legal.
6. A zero call budget or an empty corpus is refused, and a refused plan reports `estimated_calls == 0` and `estimated_output_tokens == 0` — a plan that cannot run must not read as a plan that costs something.
7. Negative or zero inputs raise `ValueError` rather than producing a plan.

**UNAIDED CORE.** Criteria 2, 5 and 6. Specifically: splitting the gradeable label from the human sentence, deciding that an impossible `max_tokens` is a refusal rather than a clamp, and deciding that a refused plan costs nothing. Delegate the Pydantic boilerplate and `render()` if you like; take those three yourself, because the section's whole argument is that a clamp which silently violates its constraint is worse than a refusal.

**Hidden test:** `tests/hidden/test_phase_f4_a1.py`. Run `make grade PHASE=_f4`. Do not read it; if it fails, reproduce the failure with a test of your own first. It skips itself until the module exists, so a clean skip means "not started", not "broken".

---

## j. Summary, and what to read next

**Time travel is replay of the graph, not of the run.** The model is called again; the tools run again. That is what makes an alternative trajectory possible and what makes invariant 37 apply: a fork past a write writes twice, so Atlas refuses and names the tool.

**Fork onto a new thread; replay in place only when you mean it.** Measured: an in-place replay moves the tip, grows a 10-checkpoint thread to 13, and duplicates three step numbers. Nothing is destroyed, but "the state of this thread" changes meaning silently — so `ReplayRecord` reports `tip_moved`, `checkpoint_at` refuses an ambiguous step, and forking copies the transcript onto a named thread with an **empty** approval trail.

**Granularity follows the checkpointer.** A subgraph that inherits its parent's checkpointer is one parent-level superstep — measured on Atlas's front door, where a whole route is a single checkpoint.

**"Bounded concurrency" is three bounds and a fuse.** Fan-out width decides the bill and is chosen before anything is spent; the in-flight limit decides the burst and is the host's thread pool if you leave it unset; the per-branch token cap is what a token rate limit actually measures. The `recursion_limit` is none of these: it is constant in n.

**And the cap is not the denominator.** `coverage` over `n_offered`, `partial` from every incompleteness signal — a run that read 5 of 20 documents perfectly is still a partial answer.

**What to read next.** F.5 builds on this fan-out; F.6 grades what a fan-out produced rather than how it ran. If neither, return to Phase 11 — the map-reduce's `doc_limit` is the same decision its cost table argues about, now with a `make` target behind it.

---

## F.4 additions

```
atlas.graph.timetravel:
    MODEL_NODE / COMPARED_FIELDS / ForkRefused
    Checkpoint (frozen) / ReplayRecord / ForkRecord / TrajectoryComparison
    thread_config(thread_id, **configurable) / config_for(checkpoint, **configurable)
    history(app, thread_id, *, limit=None)        # OLDEST FIRST
    forkable_checkpoints(app, thread_id) / checkpoint_at(app, thread_id, *, step)
    writes_after(app, checkpoint, *, registry)    # invariant 37
    replay(app, checkpoint, *, registry, force=False, config=None) -> ReplayRecord
    fork(app, checkpoint, *, into, registry, edit_messages=None, force=False,
         config=None) -> ForkRecord
    alternatives(app, checkpoint, *, registry, names, edits=None, ...) -> list[ForkRecord]
    compare_threads(app, thread_ids, *, registry, fields=COMPARED_FIELDS)

atlas.graph.mapreduce:
    DEFAULT_DOC_LIMIT = 8 / DEFAULT_WORKER_LIMIT = 3 / DEFAULT_ANALYSIS_TOKENS = 192
    MAPREDUCE_SUPERSTEPS = 3 / mapreduce_recursion_limit()   # takes no argument
    DocFinding / MapReduceReport / MapReduceState
    select_documents(docs, *, limit) -> (ids, n_offered)     # pure
    make_document_analyser(client, *, max_tokens, temperature, seed, max_chars)
    build_document_mapreduce(*, documents, analyse, doc_limit, reduce_fn=None)
    run_document_mapreduce(request, *, documents, analyse, doc_limit,
                           worker_limit, reduce_fn=None) -> MapReduceReport

atlas.graph.fanout_plan (assignment):
    BindingConstraint / BINDING_CONSTRAINTS / WorkerConstraint / WORKER_CONSTRAINTS
    FanoutPlan / plan_fanout(*, n_documents, call_budget, burst_token_cap,
                             max_tokens, worker_ceiling)

atlas/prompts/files/atlas_docmap.v1.md
    sections (Role, Goal, Question, Document, Rules); placeholders {question}, {document}
    checksum 094c7ebd0af5, pinned by tests/test_appendix_f4_mapreduce.py

evals/run_appendix_f4.py: install() / dispatch_appendix_f4(...) / main()
    payload prefixes: source. · forks · comparison. · refusal. · writes_after ·
                      environment.
scripts/phase_f4_results.py: make results PHASE=_f4
    (--only concurrency|width|timetravel|quality)
tests/hidden/test_phase_f4_a1.py: make grade PHASE=_f4
docs/RESULTS_APPENDIX_F.md · docs/FAILURE_LOG_APPENDIX_F.md
```

## VERSIONS.md delta rows

| fact | value | source URL | checked-on |
|---|---|---|---|
| Pinned library versions for this section | unchanged from Phase 10's pins; re-verified installable | https://pypi.org/project/langgraph/ | 2026-09-16 |
| Time-travel procedure | run; find a checkpoint with `get_state_history()`; optionally `update_state`; resume with `invoke(None, config)` carrying `thread_id` + `checkpoint_id` | https://docs.langchain.com/oss/python/langgraph/use-time-travel | 2026-09-16 |
| `update_state` semantics | does not roll back a thread; creates a new checkpoint branching from the given point; the original history remains intact | https://docs.langchain.com/oss/python/langgraph/use-time-travel | 2026-09-16 |
| `as_node` | treats the update as if that node produced it; execution resumes at that node's successor | same page | 2026-09-16 |
| Interrupts during time travel | always re-triggered; the node containing `interrupt()` re-executes and pauses for a new `Command(resume=...)` | same page | 2026-09-16 |
| Subgraph checkpoint granularity | a subgraph inheriting the parent's checkpointer is ONE parent superstep; you cannot time travel to a point between its nodes | same page | 2026-09-16 |
| Parent-level checkpoints per Atlas `chat` run | 7 (`__start__`, router, chat, critic, persist, respond, end) | measured, Tier F | 2026-09-16 |
| Checkpoints per 3-call core episode · forkable | 10 · 3 | measured, Tier F | 2026-09-16 |
| Tip moved by `fork` · by `replay` | False · True | measured, Tier F | 2026-09-16 |
| Duplicated step numbers after one in-place replay | 3 | measured, Tier F | 2026-09-16 |
| `max_concurrency` unset, 1-vCPU host | 5 = `min(32, cpu_count + 4)` | measured, Tier F | 2026-09-16 |
| `mapreduce_recursion_limit()` | 5, constant in the fan-out width | measured, Tier F | 2026-09-16 |
| `atlas_docmap` v1 checksum | `094c7ebd0af5` | `atlas/prompts/files/` | 2026-09-16 |
| Tier A calls per sweep · Tier H | 8 · 0. Cost $0.00 | `make plan PHASE=_f4` | 2026-09-16 |
| Known-broken core target | `make results PHASE=10` raises `TypeError`: `recursion_limit_for(4, gated=True)`; the keyword was reverted by F-10-06. Fix is `gated_recursion_limit_for(4)` | measured in both the Phase 10 and Phase 16 snapshots | 2026-09-16 |
| Coding assistant named for this book | unchanged from Phase 0 | — | 2026-09-16 |

**Pre-release APIs used in code: none.**
