# appendix_f4_f6_solutions.md

Worked answers for Appendix F.4, F.5 and F.6: the concept checks, and a
reference solution for each of the three assignments.

Read an assignment answer only after `make grade PHASE=_f4` (or `_f5`, `_f6`)
has failed and you have reproduced the failure with a test of your own. The
reference solutions below are one way to satisfy the acceptance criteria, not
the only one; the hidden tests grade behaviour, not shape. Where a solution
takes a decision the criteria left open, the commentary says so.

All three modules pass their hidden tests: 14, 13 and 15 assertions
respectively. To use one, drop the file at the path in its heading and re-run
`make grade`.

---

## F.4 — Concept checks

### CC1 — Why does `checkpoint_at` raise on an ambiguous step instead of returning the first match?

Because after an in-place replay a thread holds two branches whose step numbers
collide, and the two branches are not interchangeable.

Measured in the section: a ten-checkpoint thread becomes thirteen after one
replay, with three duplicated step numbers. `history()` orders by the
framework's own ordering, so "the first match" is an ordering artefact rather
than a choice. A function that returned it would silently answer a different
question from the one asked — *give me step 4* would mean *give me whichever
branch's step 4 happens to sort first*.

The consequence is worse than a wrong answer, because forking from the wrong
branch **succeeds**. You get a `ForkRecord`, a completed run and a
`TrajectoryComparison`, and the comparison is between a thread and a near-copy
of itself. That is the shape of the debug trace in section f: every visible
artefact looked right, and the only thing in the session that noticed was the
ambiguity guard.

The general rule: `step` is a label for a human, `checkpoint_id` is an address.
A lookup by label must refuse when the label is not unique, because the
alternative is not "a slightly wrong result" but "a plausible result about
something else".

### CC2 — Forking at the parent level before `tool_action`

Measured: at Atlas's front door a full run leaves seven parent checkpoints —
`__start__`, `router`, `chat`, `critic`, `persist`, `respond`, end. A subgraph
that inherits its parent's checkpointer is a **single superstep** to the
parent, so the whole route is one of those seven.

So the only thing a parent-level fork before `tool_action` can tell you is
**what the route does as a whole, from scratch**, with a different model
continuation. You cannot ask "what if the model had proposed a different write
on turn 2"; there is no parent checkpoint between turn 1 and turn 2 to fork
from. Turn-level questions have to be asked against `build_core_graph`, which
is why F.4 targets it.

And the invariant-37 refusal matters *more* there, not less, for two
compounding reasons. First, `tool_action` is the route that can write — the one
route where re-executing the segment has an effect outside the process. Second,
the coarse granularity means a fork re-runs the **entire route**, so it re-runs
every write in it rather than one. A fork before `tool_action` on a thread
whose route wrote three files is a request to write three files again.
`writes_after` scans the continuation and refuses by name, which is the only
thing standing between a debugging session and a second set of side effects.

### CC3 — 60 requests/minute, 40,000 output tokens/minute, 500 output tokens per document

The published limits constrain **rate**, and neither of your two bounds is a
rate. Converting them is the work, and it is Phase 5's `make plan` lesson:
convert a limit into your own unit before believing it.

Which bound each limit touches:

- **40,000 output tokens/minute** touches bound 3 and bound 2 jointly. Divided
  by the 500-token per-document cap it is 80 documents/minute of output
  allowance. It also caps the instantaneous burst: `worker_limit × max_tokens`
  must be something you are willing to emit at once.
- **60 requests/minute** touches bound 1 over time — sustained throughput — and
  bound 2 only once you know how long a request takes.
- **Neither limit mentions concurrency at all.** That is the point of the
  question.

The tightest legal `worker_limit` therefore cannot be computed from the
published numbers alone. It needs one measurement you supply: the per-document
latency. With `w` workers and a mean request time of `t` seconds, sustained
throughput is `60w / t` requests per minute. Setting that at or below the
binding rate — `min(60, 80) = 60` requests/minute — gives `w ≤ t`. At a
measured 6-second per-document call, `w ≤ 6`; at 2 seconds, `w ≤ 2`.

Two things to take away. The binding limit here is requests, not tokens
(60 < 80), which is the opposite of the common case and the reason you compute
both rather than assuming. And a bound derived from a latency you measured is a
bound that moves when the model changes — which is why `worker_limit` is a
parameter passed explicitly at invoke time, and why leaving `max_concurrency`
unset (host thread pool, measured at 5 on a 1-vCPU box) is never right.

---

## F.4 — Assignment: `atlas/graph/fanout_plan.py`

### The three decisions that were yours

**Criterion 2 — the gradeable label, split from the human sentence.** The
obvious implementation gives `reason` a whole sentence, so an eval check can
only match it with `contains`. That is a renderer's output format becoming a
parser's input contract, which is invariant 65: editing the message a human
reads silently changes what the harness grades. Splitting `reason`
(a `Literal` a check matches with `eq`) from `detail` (prose) makes the set
closed, makes every member reachable, and makes the check robust to rewording.

**Criterion 5 — refuse rather than clamp.** `max_tokens > burst_token_cap` has
no legal setting: one branch already breaks the cap. Clamping to
`worker_limit=1` produces a plan that *violates the constraint it was given
while reporting success*, which is the absent-gate failure wearing a plan's
clothes. This is the one criterion where the obvious implementation is actively
harmful.

**Criterion 6 — a refused plan costs nothing.** `estimated_calls` and
`estimated_output_tokens` return 0 when `refused`. A refused plan that still
reports twelve calls will be read as a plan by anything that reads the field
rather than the flag, and something eventually reads the field.

### Common wrong answers

- `max(1, min(...))` applied *before* the refusal check, which silently
  converts criterion 5 into a clamp.
- `reason: str` carrying prose, so `BindingConstraint` is declared, exported
  and never used — a dead `Literal`, which is exactly invariant 30's target.
- Deriving `worker_reason` by re-deriving which value was smallest after taking
  the `min`, which ties on equality and picks by dict order.
- Computing `doc_limit` as `min(n_documents, call_budget, worker_ceiling)` —
  conflating the fan-out width with the in-flight bound, which is precisely the
  conflation F.4 exists to prevent.
- Omitting `doc_limit` from the `worker_limit` candidates, so three workers are
  planned over two documents.

### Reference solution

```python
"""Appendix F.4 assignment — reference solution. Choose the three bounds, and
name the constraint that chose each one.

A bound whose reason you cannot state is a magic number, and a magic number in
a fan-out is a bill nobody predicted. This module is pure: no graph, no client,
no clock, so the arithmetic that decides what a run costs can be tested without
running one.
"""

from __future__ import annotations

from typing import Literal

from pydantic import BaseModel, computed_field

__all__ = ["BindingConstraint", "BINDING_CONSTRAINTS", "WorkerConstraint",
           "WORKER_CONSTRAINTS", "FanoutPlan", "plan_fanout"]

BindingConstraint = Literal["corpus", "call_budget", "refused"]
"""Which constraint chose `doc_limit`. `refused` is the member that says no
legal plan exists, and it has a line of code that sets it (invariant 30)."""
BINDING_CONSTRAINTS: tuple[BindingConstraint, ...] = (
    "corpus", "call_budget", "refused",
)

WorkerConstraint = Literal["worker_ceiling", "burst_token_cap", "doc_limit", "none"]
WORKER_CONSTRAINTS: tuple[WorkerConstraint, ...] = (
    "worker_ceiling", "burst_token_cap", "doc_limit", "none",
)


class FanoutPlan(BaseModel):
    """The three bounds, the reasons, and the arithmetic they imply.

    No `extra="forbid"`: a harness record must accept its own `model_dump()`,
    computed fields included (invariant 31, D-19).
    """

    n_offered: int
    doc_limit: int
    worker_limit: int
    max_tokens: int
    reason: BindingConstraint
    detail: str = ""
    """The sentence a human reads. `reason` is the LABEL a check can name."""
    worker_reason: WorkerConstraint
    refused: bool = False

    @computed_field  # type: ignore[prop-decorator]
    @property
    def estimated_calls(self) -> int:
        return 0 if self.refused else self.doc_limit

    @computed_field  # type: ignore[prop-decorator]
    @property
    def estimated_output_tokens(self) -> int:
        return 0 if self.refused else self.doc_limit * self.max_tokens

    @computed_field  # type: ignore[prop-decorator]
    @property
    def peak_output_tokens_in_flight(self) -> int:
        return 0 if self.refused else self.worker_limit * self.max_tokens

    def render(self) -> str:
        if self.refused:
            return f"REFUSED: {self.detail}"
        return (
            f"{self.doc_limit}/{self.n_offered} documents ({self.reason}), "
            f"{self.worker_limit} at a time ({self.worker_reason}), "
            f"{self.max_tokens} output tokens each -> "
            f"{self.estimated_calls} calls, peak burst "
            f"{self.peak_output_tokens_in_flight} tokens"
        )


def plan_fanout(
    *,
    n_documents: int,
    call_budget: int,
    burst_token_cap: int,
    max_tokens: int,
    worker_ceiling: int,
) -> FanoutPlan:
    """Choose `doc_limit`, `worker_limit` and `max_tokens`, or refuse.

    Refusing is a real outcome, and it is not the same as planning one branch.
    A per-branch cap larger than the whole burst allowance has no legal
    setting at all: one worker already exceeds it, and rounding down to one
    would produce a plan that violates the constraint it was given while
    reporting success.
    """
    if n_documents < 0 or call_budget < 0:
        raise ValueError("n_documents and call_budget must not be negative")
    if max_tokens < 1:
        raise ValueError("max_tokens must be at least 1")
    if worker_ceiling < 1:
        raise ValueError("worker_ceiling must be at least 1")
    if burst_token_cap < 1:
        raise ValueError("burst_token_cap must be at least 1")

    doc_limit = min(n_documents, call_budget)
    if doc_limit == 0:
        detail = (
            "call_budget is 0: there is nothing to spend"
            if call_budget == 0
            else "corpus is empty: there is nothing to read"
        )
        return FanoutPlan(
            n_offered=n_documents, doc_limit=0, worker_limit=0,
            max_tokens=max_tokens, reason="refused", detail=detail,
            worker_reason="none", refused=True,
        )
    if max_tokens > burst_token_cap:
        return FanoutPlan(
            n_offered=n_documents, doc_limit=0, worker_limit=0,
            max_tokens=max_tokens, reason="refused",
            detail=(
                f"max_tokens {max_tokens} exceeds burst_token_cap "
                f"{burst_token_cap}: one branch alone breaks the cap, so no "
                "worker_limit is legal. Lower max_tokens."
            ),
            worker_reason="none", refused=True,
        )

    from_burst = burst_token_cap // max_tokens
    candidates: list[tuple[int, WorkerConstraint]] = [
        (worker_ceiling, "worker_ceiling"),
        (from_burst, "burst_token_cap"),
        (doc_limit, "doc_limit"),
    ]
    worker_limit, worker_reason = min(candidates, key=lambda pair: pair[0])
    reason: BindingConstraint = (
        "corpus" if n_documents <= call_budget else "call_budget"
    )
    return FanoutPlan(
        n_offered=n_documents,
        doc_limit=doc_limit,
        worker_limit=max(1, worker_limit),
        max_tokens=max_tokens,
        reason=reason,
        detail=f"{doc_limit} of {n_documents} documents",
        worker_reason=worker_reason,
    )
```

### Checking it yourself

```
12/20 documents (call_budget), 3 at a time (worker_ceiling), 200 output tokens each
    -> 12 calls, peak burst 600 tokens
4/4 documents (corpus), 3 at a time (worker_ceiling), 200 output tokens each
    -> 4 calls, peak burst 600 tokens
12/20 documents (call_budget), 2 at a time (burst_token_cap), 200 output tokens each
    -> 12 calls, peak burst 400 tokens
REFUSED: max_tokens 200 exceeds burst_token_cap 150: one branch alone breaks the cap...
REFUSED: call_budget is 0: there is nothing to spend
```

Note rows 1 and 3: the same corpus and budget, a tighter burst cap, and only
the `worker_reason` tells you which knob to turn.

---

## F.5 — Concept checks

### CC1 — Why `DelegationDraft` has no `done` field

Delegating to the `writer` is how the supervisor says "enough", which puts
termination in the harness: the `writer` node is the only node with an edge to
`END`, and the supervisor reached it by emitting a **label from a closed set**
that the graph routes on. Invariant 9 holds without a special case, and
invariant 33 holds because the label is data an eval check can name.

A `done: bool` would cost three things, and the first time a model set it on
turn one you would meet all of them. You would need a second terminal path —
"done but no writer turn" — which means an answer produced by nobody, so
`SupervisorResult.answer` would be `None` on a run whose `stop_reason` is
`final`. You would have added a field the model can set that carries execution
state (invariant 26), so `done=true` on turn one is indistinguishable from a
correct early exit. And the turn cap would stop being a bound on cost: `done`
short-circuits before the writer, so the one call that produces the
user-visible answer becomes optional.

The shape to remember is the same one Phase 6's `GroundedDraft` and Phase 7's
`SqlDraft` use: the model-facing schema carries what the model *decides*, and
nothing about what the harness *does with it*.

### CC2 — Strictly increasing versus "contains the previous report"

"Contains the previous report" is true of Phase 11 §8's broken supervisor. That
one carried the latest worker report in its prompt and nothing else, so it
would pass a containment check on every turn while its prompt sizes went
`151, 376, 310, 376, 310, 376` — periodic with period 2, and no policy over it
could escape.

Strict increase catches that, because the prompt length after turn `n` must
exceed the length after turn `n−1`: carrying only the *latest* report gives a
size that oscillates with report length instead of growing.

The concrete bug the first catches and the second does not is **history
truncation**. Add a "keep the last three delegations" line to
`build_supervisor_prompt` — a reasonable-looking context-budget optimisation —
and the containment assertion still passes on every turn, while the prompt
stops growing at turn 4 and the supervisor becomes unable to see that turn 5
repeats turn 1. Measured here as `[424, 605, 661, 717]`, strictly increasing
and all distinct. The assertion is Phase 11's cheap oracle promoted from an
observation you make while debugging to a test that runs before you ship.

---

## F.5 — Assignment: `atlas/graph/handoff_audit.py`

### The three decisions that were yours

**Criterion 2 — blocking by consequence.** `repeated_instruction` and
`roster_gap` mean the run *could not have succeeded*; the other three mean the
answer is worth less than it looks. Making everything blocking produces a
report where every run is blocked, which is invariant 23's failure — a
permanently-red row trains people to ignore red.

**Criterion 4 — a tool-less specialist is not unused.** The `writer` holds
nothing by design. Flagging it produces a finding on every clean run, and a
report with a permanent finding is a report people stop reading. This is the
same reason `build_writer_task`'s incomplete-evidence banner is conditional.

**Criterion 5 — no `required` means no check.** Defaulting it to
`HANDLER_TOOLS["research"]` would be a guess dressed as a fact: the audit does
not know which route this supervisor stands in for, and on the Phase 16 code
that route's tool set has grown. Omitting a check you cannot ground is honest;
guessing is invariant 53's failure.

### Common wrong answers

- Reporting the *first* occurrence as the repeat. The first was fine; the
  second is the defect, and a reader looking at turn 1 will not find anything
  wrong with it.
- Raising on a malformed `SupervisorResult`. A critic that can fail stops you
  reading the trace at exactly the moment you needed to.
- Deriving `blocking` from a severity integer rather than from set membership,
  which makes the threshold invisible and untestable.

### Reference solution

```python
"""Appendix F.5 assignment — reference solution. The reader a multi-agent record
needs before it is allowed to ship.

`docs/MULTI_AGENT_DECISION.md` section 4 gives five reasons for keeping the
pipeline, and the fifth is this one: *we cannot yet read a multi-agent trace.*
Invariant 40 says a record type ships with its reader in the same commit, and a
record nobody can render is a failure-log entry telling somebody to read a
trace that does not exist.

So this is Phase 4's mechanical critic, pointed at a `SupervisorResult`. Pure,
no model, never raises — a critic that can fail is a critic that stops you
reading the trace at exactly the moment you needed to. Findings are ADDITIVE
and the blocking subset is defined by consequence rather than by count (D-40's
shape, and Phase 7's `BLOCKING_SANITY`).
"""

from __future__ import annotations

from typing import Literal, Sequence

from pydantic import BaseModel, ConfigDict, computed_field

from atlas.graph.supervisor import SupervisorResult, delegation_signature

__all__ = ["AuditKind", "AUDIT_KINDS", "BLOCKING_AUDIT_KINDS", "AuditFinding",
           "AuditReport", "audit_supervisor"]

AuditKind = Literal[
    "repeated_instruction",  # the supervisor asked twice: wasted turns
    "unused_specialist",     # a roster member with tools was never reached
    "no_synthesis",          # the run ended without a writer turn
    "worker_tool_error",     # a specialist hit a tool error inside a good turn
    "roster_gap",            # the roster cannot reach a required tool
]
AUDIT_KINDS: tuple[AuditKind, ...] = (
    "repeated_instruction", "unused_specialist", "no_synthesis",
    "worker_tool_error", "roster_gap",
)

# By CONSEQUENCE, not by severity felt. These two mean the run could not have
# succeeded: a repeat spent a turn that could not advance, and a gap means no
# allocation existed. The other three mean the answer is worth less than it
# looks, which a reader can weigh.
BLOCKING_AUDIT_KINDS: frozenset[str] = frozenset(
    {"repeated_instruction", "roster_gap"}
)


class AuditFinding(BaseModel):
    model_config = ConfigDict(frozen=True)

    kind: AuditKind
    turn: int | None = None
    detail: str

    @computed_field  # type: ignore[prop-decorator]
    @property
    def blocking(self) -> bool:
        return self.kind in BLOCKING_AUDIT_KINDS

    def render(self) -> str:
        where = f"turn {self.turn}" if self.turn is not None else "run"
        mark = "!" if self.blocking else " "
        return f"{mark} [{self.kind}] {where}: {self.detail}"


class AuditReport(BaseModel):
    """A harness record: no `extra=\"forbid\"`, so it round-trips (inv. 31)."""

    task: str = ""
    findings: list[AuditFinding] = []

    @computed_field  # type: ignore[prop-decorator]
    @property
    def n_findings(self) -> int:
        return len(self.findings)

    @computed_field  # type: ignore[prop-decorator]
    @property
    def kinds(self) -> list[str]:
        return [f.kind for f in self.findings]

    @computed_field  # type: ignore[prop-decorator]
    @property
    def blocking(self) -> list[AuditFinding]:
        return [f for f in self.findings if f.blocking]

    @computed_field  # type: ignore[prop-decorator]
    @property
    def clean(self) -> bool:
        return not self.findings

    def render(self) -> str:
        if self.clean:
            return f"AUDIT {self.task}: clean"
        lines = [f"AUDIT {self.task}: {self.n_findings} finding(s)"]
        lines += [f.render() for f in self.findings]
        return "\n".join(lines)


def audit_supervisor(
    result: SupervisorResult,
    *,
    roster: dict[str, Sequence[str]] | None = None,
    required: Sequence[str] | None = None,
) -> AuditReport:
    """Read one supervisor run mechanically. Pure, no model, never raises.

    `required` is optional and omitting it omits the `roster_gap` check rather
    than defaulting to a guess: a route's declared tool set is a fact the
    caller has and this function does not.
    """
    findings: list[AuditFinding] = []
    chosen = {k: list(v) for k, v in (roster or result.roster).items()}

    seen: set[str] = set()
    for delegation in result.delegations:
        signature = delegation_signature(delegation.specialist, delegation.instruction)
        if signature in seen:
            findings.append(AuditFinding(
                kind="repeated_instruction", turn=delegation.turn,
                detail=f"{delegation.specialist} was asked this in an earlier turn",
            ))
        seen.add(signature)
        if delegation.tool_errors:
            findings.append(AuditFinding(
                kind="worker_tool_error", turn=delegation.turn,
                detail=f"{delegation.specialist} saw {sorted(set(delegation.tool_errors))}",
            ))

    used = {d.specialist for d in result.delegations}
    for name, tools in chosen.items():
        # A specialist with no tools cannot be "unused" in any way that costs
        # anything: the writer holds nothing by design, and flagging it would
        # be a finding on every clean run, which trains a reader to skip the
        # report (invariant 23's shape).
        if tools and name not in used:
            findings.append(AuditFinding(
                kind="unused_specialist",
                detail=f"{name} was never delegated to, and holds {sorted(tools)}",
            ))

    if not any(d.specialist == "writer" for d in result.delegations):
        findings.append(AuditFinding(
            kind="no_synthesis",
            detail=f"no writer turn; the run ended {result.stop_reason}",
        ))

    if required is not None:
        granted = {t for tools in chosen.values() for t in tools}
        missing = sorted(t for t in required if t not in granted)
        if missing:
            findings.append(AuditFinding(
                kind="roster_gap",
                detail=f"the roster cannot reach {missing}",
            ))

    return AuditReport(task=result.task, findings=findings)
```

### Checking it yourself

Run the audit over the broken-roster ping-pong from section f:

```
AUDIT q: 3 finding(s)
! [repeated_instruction] turn 3: retriever was asked this in an earlier turn
  [no_synthesis] run: no writer turn; the run ended no_progress
! [roster_gap] run: the roster cannot reach ['query_db', 'read_file', 'search_web']
```

Three lines and a reader who has never opened the transcript knows what
happened, in the right order of causation: the repeat is the symptom, the
missing writer is the consequence, the roster gap is the cause.

---

## F.6 — Concept checks

### CC1 — Why `goal_check` is a parameter and not a `Persona` field

Because the thing that talks and the thing that grades must not be editable in
one place.

Put `goal_check` on the `Persona` and a failing task acquires a one-line fix
that nobody will read as cheating: soften the check, and the persona still says
the same things, so the diff looks like a persona tweak. Over a few months the
suite converges on checks the agent already satisfies, and the elicitation
metric measures nothing. Separating them makes the same edit a change to the
**task's** grading criteria, which is a thing a reviewer looks at.

This is invariant 44's shape — abstention is computed by code from the
retrieval, never granted by the model — applied one level out, to a fixture
rather than to a model. It is also why `ConversationResult` has no field in
which the user could express an opinion: a field that can report success is a
field that can report it falsely, so the field does not exist.

### CC2 — Why the MDE is computed at the smaller arm

Because the comparison is limited by whichever arm has less information, and
using anything larger lets you claim precision you do not have.

Measured on F.6's window at p = 0.856:

| n used | MDE |
|---|---|
| smaller arm (894) | 0.0325 |
| pooled ÷ 2 (1,700) | 0.0236 |
| larger arm (2,506) | 0.0194 |
| total (3,400) | 0.0167 |

The observed delta is +0.0094. At the smaller arm it is within noise,
correctly. Use the total and the MDE drops to 0.0167 — still above the delta,
so this particular reading survives. But with a delta of +0.020 the choice
flips the verdict: unmeasured at the smaller arm, "measurably better" at the
total. Picking the denominator after seeing the delta is the mechanism by which
an A/B readout becomes a formality, and the fact that it is the
*arithmetically tempting* choice is what makes it dangerous.

The deeper point is what the imbalance itself means. In F.6's window the arms
are 2,506 and 894 because the rollout started on day 8, so control includes a
week the treatment did not exist. The honest fix is not a cleverer denominator
but a matched window — which is exactly what `windows_comparable` complains
about, and what the assignment's SRM check catches when the imbalance is not
calendar but breakage.

---

## F.6 — Assignment: `evals/ab_preflight.py`

### The three decisions that were yours

**Criterion 2 — underpowered is not a failure.** The same 60/40 imbalance fails
at n = 2,000 and does not fail at n = 20, because at n = 20 the Wilson interval
is too wide to exclude 0.5. That is the right answer: the check has no
evidence, and reporting a failure it cannot support is as bad as reporting a
pass. Implementing SRM as a Wilson interval rather than a chi-square test gets
this for free and reuses the estimator every other rate in the repository
already uses — one implementation of "is this proportion different", so there
is nothing to drift.

**Criterion 3 — a planned uneven split is the plan.** A 90/10 ramp is not an
SRM. Hard-coding 0.5 makes the check fire on every staged rollout, which is how
a pre-flight check gets switched off in week two.

**Criterion 5 — precedence, not conjunction.** A broken assignment beats a mix
shift. `read_segments_only` says "the aggregate is about the population; run
`decompose_delta`", and that advice is only sound if assignment is intact.
ORing the two conditions into one "not clean" flag loses the distinction
between *read it differently* and *do not read it*.

### Common wrong answers

- A chi-square test with a p < 0.05 threshold and no small-n handling, which
  fires at n = 20.
- Total variation computed as the plain sum of absolute differences, which
  maxes at 2 rather than 1 and makes any tolerance meaningless.
- A `comparable` flag with no `largest_move`: "the mix shifted" is not
  actionable, "research went from 10% to 26%" is.
- Raising on empty input, so the pre-flight check dies exactly when the
  experiment produced no data — which is itself a finding.

### Reference solution

```python
"""Appendix F.6 assignment — reference solution. What to check BEFORE you read
any number out of an experiment.

Every mechanism in `evals/online.py` answers "what does this delta mean?". This
module answers the question that comes first and is skipped more often: *is
this a comparison at all?* Two failures make everything downstream
uninterpretable, and neither is visible in the metric you were going to read.

**Sample ratio mismatch.** You assigned 50/50 and observed 60/40. Something in
the assignment is broken — a filter, a retry, a crash that removed one arm's
sessions — and whatever removed those sessions removed them non-randomly. The
arms are no longer two samples of one population, so the delta between them is
a delta between two different groups of people. This is the highest-value
pre-flight check in A/B practice and it costs two counts.

**Population shift.** The arms are assigned correctly and the traffic inside
them is not alike: the treatment's mix moved. The aggregate is then a fact
about who showed up, which is exactly what `decompose_delta` is for — so the
verdict downgrades to "read the segments" rather than blocking.

The order is the content: a broken assignment beats a mix shift, because a mix
shift is still readable segment by segment and a broken assignment is not
readable at all. Pure, never raises.
"""

from __future__ import annotations

from collections import Counter
from typing import Callable, Literal, Sequence

from pydantic import BaseModel, ConfigDict, Field, computed_field

from evals.online import TraceRecord
from evals.stats import wilson_interval

__all__ = [
    "PreflightVerdict",
    "PREFLIGHT_VERDICTS",
    "SRMResult",
    "ShiftReport",
    "PreflightReport",
    "srm_check",
    "population_shift",
    "preflight",
]

PreflightVerdict = Literal["proceed", "read_segments_only", "do_not_read"]
PREFLIGHT_VERDICTS: tuple[PreflightVerdict, ...] = (
    "proceed", "read_segments_only", "do_not_read",
)

DEFAULT_TV_TOLERANCE = 0.05
"""Total variation distance above which the mixes are not alike.

0.05 means "five percent of the population would have to be moved between
segments to make the two mixes identical". A published number, not a hidden
one: it is the knob that decides how often this downgrades an experiment, and
a threshold nobody can see is a threshold nobody can argue with.
"""


class SRMResult(BaseModel):
    """Did the split come out the way it was assigned?"""

    model_config = ConfigDict(extra="ignore")

    control_n: int
    treatment_n: int
    expected_share: float
    passed: bool
    detail: str

    @computed_field  # type: ignore[prop-decorator]
    @property
    def n(self) -> int:
        return self.control_n + self.treatment_n

    @computed_field  # type: ignore[prop-decorator]
    @property
    def observed_share(self) -> float:
        return self.treatment_n / self.n if self.n else 0.0

    def render(self) -> str:
        mark = "ok  " if self.passed else "FAIL"
        return (
            f"{mark} SRM  expected {self.expected_share:.3f}  observed "
            f"{self.observed_share:.3f}  n={self.n}  {self.detail}"
        )


def srm_check(
    *, control_n: int, treatment_n: int, expected_share: float = 0.5
) -> SRMResult:
    """Is the observed treatment share consistent with the planned one? Pure.

    Implemented as a Wilson interval on the observed share rather than as a
    chi-square test, for one reason: the interval is the same estimator every
    other rate in this repository already uses (`evals.stats.wilson_interval`),
    so a reader who understands one understands all of them, and there is no
    second implementation of "is this proportion different" to drift. It also
    behaves correctly at small n, where the interval is simply too wide to
    fault anything — which is the honest answer, not a pass.
    """
    n = control_n + treatment_n
    if n <= 0:
        return SRMResult(
            control_n=control_n, treatment_n=treatment_n,
            expected_share=expected_share, passed=False,
            detail="no requests in either arm; there is nothing to check",
        )
    interval = wilson_interval(treatment_n, n)
    passed = interval.low <= expected_share <= interval.high
    return SRMResult(
        control_n=control_n, treatment_n=treatment_n,
        expected_share=expected_share, passed=passed,
        detail=(
            f"observed {interval.render()}"
            + ("" if passed else
               f"; {expected_share:.3f} is outside it, so assignment is "
               "suspect and every downstream number with it")
        ),
    )


class ShiftReport(BaseModel):
    """How much the population moved between the arms."""

    model_config = ConfigDict(extra="ignore")

    shares: dict[str, dict[str, float]] = Field(default_factory=dict)
    tolerance: float = DEFAULT_TV_TOLERANCE

    @computed_field  # type: ignore[prop-decorator]
    @property
    def total_variation(self) -> float:
        """Half the sum of absolute share differences. 0 identical, 1 disjoint."""
        return round(
            0.5 * sum(abs(row["treatment"] - row["control"])
                      for row in self.shares.values()),
            6,
        )

    @computed_field  # type: ignore[prop-decorator]
    @property
    def comparable(self) -> bool:
        return self.total_variation <= self.tolerance

    @computed_field  # type: ignore[prop-decorator]
    @property
    def largest_move(self) -> str:
        """The segment that moved most. Named, because "the mix shifted" is
        not actionable and "research went from 10% to 26%" is."""
        if not self.shares:
            return ""
        return max(
            self.shares,
            key=lambda name: abs(
                self.shares[name]["treatment"] - self.shares[name]["control"]
            ),
        )

    def render(self) -> str:
        mark = "ok  " if self.comparable else "WARN"
        lines = [
            f"{mark} MIX  total variation {self.total_variation:.4f} "
            f"(tolerance {self.tolerance:.3f})"
        ]
        for name in sorted(self.shares):
            row = self.shares[name]
            lines.append(
                f"       {name:<14} {row['control']:.3f} -> {row['treatment']:.3f}"
                f"  ({row['treatment'] - row['control']:+.3f})"
            )
        return "\n".join(lines)


def population_shift(
    control: Sequence[TraceRecord],
    treatment: Sequence[TraceRecord],
    *,
    by: Callable[[TraceRecord], str] | str = "route",
    tolerance: float = DEFAULT_TV_TOLERANCE,
) -> ShiftReport:
    """Per-segment share in each arm, and the distance between the mixes. Pure."""
    key = (lambda t, name=by: str(getattr(t, name, ""))) if isinstance(by, str) else by
    left, right = Counter(key(t) for t in control), Counter(key(t) for t in treatment)
    n_c, n_t = max(len(control), 1), max(len(treatment), 1)
    shares = {
        name: {
            "control": round(left.get(name, 0) / n_c, 6),
            "treatment": round(right.get(name, 0) / n_t, 6),
        }
        for name in sorted(set(left) | set(right))
    }
    return ShiftReport(shares=shares, tolerance=tolerance)


class PreflightReport(BaseModel):
    """Both checks, and the one verdict that follows from them."""

    model_config = ConfigDict(extra="ignore")

    srm: SRMResult
    shift: ShiftReport

    @computed_field  # type: ignore[prop-decorator]
    @property
    def verdict(self) -> PreflightVerdict:
        """Order is the content: a broken assignment beats a mix shift."""
        if not self.srm.passed:
            return "do_not_read"
        return "proceed" if self.shift.comparable else "read_segments_only"

    def render(self) -> str:
        return "\n".join([
            "PREFLIGHT",
            "  " + self.srm.render(),
            "  " + self.shift.render().replace("\n", "\n  "),
            f"  VERDICT: {self.verdict}",
            {
                "proceed": "  The arms are assigned as planned and alike. Read "
                           "the aggregate, with its interval.",
                "read_segments_only": "  Assignment is fine and the mix moved. "
                                      "The aggregate is a fact about who showed "
                                      "up; run decompose_delta.",
                "do_not_read": "  Assignment is suspect. Fix it and re-run; "
                               "nothing downstream is interpretable.",
            }[self.verdict],
        ])


def preflight(
    control: Sequence[TraceRecord],
    treatment: Sequence[TraceRecord],
    *,
    expected_share: float = 0.5,
    by: Callable[[TraceRecord], str] | str = "route",
    tolerance: float = DEFAULT_TV_TOLERANCE,
) -> PreflightReport:
    """Run both checks over two arms. Pure; never raises, including on empty."""
    return PreflightReport(
        srm=srm_check(
            control_n=len(control), treatment_n=len(treatment),
            expected_share=expected_share,
        ),
        shift=population_shift(control, treatment, by=by, tolerance=tolerance),
    )
```

### Checking it yourself, and a warning

Run `preflight` over F.6's own seeded window — control 2,506, treatment 894 —
and it returns `do_not_read`, because a 26% observed treatment share is nowhere
near the planned 50%. That is **correct and is not a defect in the data**: the
imbalance is the rollout start date, not broken assignment, and the honest
response is to restrict both arms to days 8–14 and re-run the check. An SRM
result is a symptom, and the published taxonomy of causes runs from faulty
bucketing through log processing to an analyst segmenting on a biased
condition. The check tells you to go and look; it does not tell you what you
will find.

Which is the last thing worth carrying out of all three sections. Every
mechanism here — the fork refusal, the roster assertion, the canary's third
verdict, the SRM check — exists to make you stop and look at something
specific, at a moment when the alternative was to read a number and move on.
