# Multi-Objective Optimization for Engineers

### A self-study module in applied optimization, using Python and pymoo

---

**Who this is for.** You have taken a course in single-objective optimization: you know what decision variables, objective functions, and constraints are; you know local versus global optima; you have seen the KKT conditions; and you can drive `scipy.optimize`. You are comfortable with Python and NumPy. You have *not* worked with more than one objective at a time. This module is designed to replace a lecture module on multi-objective optimization: it is meant to be read and worked through alone, with no instructor available.

**What you will be able to do at the end.** Formulate a genuine engineering trade-off as a multi-objective problem; explain why the obvious first idea (average the objectives) is not enough, and prove it to yourself; run and interpret NSGA-II and NSGA-III in pymoo; validate your own pipeline against problems with known answers; measure the quality of a result with the right indicator; select one design from a front and defend that choice; and diagnose the specific ways these methods go wrong.

**Software.** Everything here was executed on Python 3.12 with `numpy 2.4.4`, `scipy 1.17.1`, `matplotlib 3.10.8`, and **`pymoo 0.6.2`** (released 27 June 2026, the current release at the time of writing). See `requirements.txt`.

**Reproducibility.** Every figure in this document, and every number quoted in the text, was produced by a script in the accompanying `scripts/` folder. Each section names the script that generated its figures. Nothing here is quoted from memory; if you run the scripts you will get these numbers back, because every random seed is fixed.

---

## How to work through this module

Read Parts I–IV in order; each part depends on the one before. Part V is reference material you will come back to.

There are **24 exercises**, placed at the end of the part they belong to, with full solutions in Section 30. Do them. Several exist specifically to inoculate you against mistakes that are easy to make and hard to notice — Exercise 12, in particular, is the single most valuable thing in this module.

The scripts are meant to be run, edited, and broken:

```bash
pip install -r requirements.txt
cd scripts
python fig01_foundations.py      # ~5 s
python fig04_beam.py             # ~30 s   <- the main case study
python check_kkt.py              # instant
```

Rough timings: reading, 5–6 hours. Exercises, 4–6 hours. Running every script, about 40 minutes of compute (the statistical experiments in Sections 20 and 25 dominate that).

### Table of contents

**Part I — Foundations**
1. [What changes when there is more than one objective](#1-what-changes-when-there-is-more-than-one-objective)
2. [The problem statement and the two spaces](#2-the-problem-statement-and-the-two-spaces)
3. [Dominance and Pareto optimality](#3-dominance-and-pareto-optimality)
4. [Reference points and normalization](#4-reference-points-and-normalization)
5. [A complete problem, solved by hand](#5-a-complete-problem-solved-by-hand)
6. [Optimality conditions: KKT with several objectives](#6-optimality-conditions-kkt-with-several-objectives)
7. [When does preference enter? The three families of methods](#7-when-does-preference-enter-the-three-families-of-methods)

**Part II — Scalarization: turning one problem into many**

8. [The weighted-sum method](#8-the-weighted-sum-method)
9. [Weighted Tchebycheff and the achievement scalarizing function](#9-weighted-tchebycheff-and-the-achievement-scalarizing-function)
10. [The ε-constraint method](#10-the-ε-constraint-method)
11. [Normal boundary intersection, briefly](#11-normal-boundary-intersection-briefly)
12. [Scalarization scorecard](#12-scalarization-scorecard)

**Part III — The evolutionary approach**

13. [Why population-based algorithms fit this problem](#13-why-population-based-algorithms-fit-this-problem)
14. [NSGA-II, opened up](#14-nsga-ii-opened-up)
15. [Constraints: the feasibility-first rule](#15-constraints-the-feasibility-first-rule)

**Part IV — Practice with pymoo**

16. [Getting started](#16-getting-started)
17. [Termination: when is it done?](#17-termination-when-is-it-done)
18. [Case Study I: the cantilever beam](#18-case-study-i-the-cantilever-beam)
19. [Validating your pipeline on benchmarks](#19-validating-your-pipeline-on-benchmarks)
20. [Measuring quality: performance indicators](#20-measuring-quality-performance-indicators)
21. [From a front to a decision](#21-from-a-front-to-a-decision)
22. [Four objectives and beyond](#22-four-objectives-and-beyond)
23. [Case Study II: the compact beam, three objectives](#23-case-study-ii-the-compact-beam-three-objectives)
24. [Discrete and mixed variables](#24-discrete-and-mixed-variables)
25. [Making it affordable: seeding, vectorizing, parallelizing](#25-making-it-affordable-seeding-vectorizing-parallelizing)

**Part V — Reference**

26. [Troubleshooting: symptom to cause](#26-troubleshooting-symptom-to-cause)
27. [Practical tips and a pre-flight checklist](#27-practical-tips-and-a-pre-flight-checklist)
28. [Summary](#28-summary)
29. [Glossary and notation](#29-glossary-and-notation)
30. [Solutions to exercises](#30-solutions-to-exercises)
31. [References](#31-references)

---

# Part I — Foundations

## 1. What changes when there is more than one objective

In your single-objective course, every problem had one number to make small. Real design problems almost never do:

| Task | Objective 1 | Objective 2 — and it fights the first |
|---|---|---|
| Structural member | minimize mass | minimize deflection |
| Engine calibration | minimize fuel burn | minimize NO$_x$ |
| Heat exchanger | maximize heat duty | minimize pumping power |
| Chip design | minimize power | maximize clock frequency |
| Water network | minimize capital cost | maximize reliability |
| Controller tuning | minimize settling time | minimize overshoot |
| Machine learning model | maximize accuracy | minimize inference latency |

The load-bearing word is **conflicting**. If the lightest beam were also the stiffest, there would be nothing to discuss: optimize one, get the other free. Multi-objective optimization exists because past a certain point, **improving one objective forces another to get worse**.

This changes what "the answer" is:

> In single-objective optimization, the answer is **a point**.
> In multi-objective optimization, the answer is **a set of trade-offs** — and then, separately, a human decision.

That set is the **Pareto front**. Note the two-stage structure, because it is the source of most confusion for newcomers: the optimizer's job is to produce the *menu*; choosing from the menu is a different job, done with different tools (Section 21), and it requires information the optimizer does not have.

### A worked intuition before any formalism

Four candidate beam designs, mass in kg and tip deflection in mm, both to be minimized:

| Design | mass | deflection |
|---|---|---|
| P | 5 | 16.0 |
| Q | 23 | 0.48 |
| R | 707 | 0.005 |
| S | 30 | 2.0 |

Which is best? The question is malformed. P, Q, and R are all reasonable answers to *different* questions — a drone arm, a robot link, a machine-tool base. But **S is not**: Q is lighter *and* stiffer than S, so nobody who knows about Q would ever build S. That asymmetry — "S is beaten outright, but P, Q and R merely differ" — is the entire conceptual foundation of this subject, and Section 3 makes it precise.

---

## 2. The problem statement and the two spaces

A general multi-objective problem (MOP):

$$
\begin{aligned}
\min_{\mathbf{x}} \quad & \mathbf{F}(\mathbf{x}) = \big(f_1(\mathbf{x}),\, f_2(\mathbf{x}),\, \dots,\, f_M(\mathbf{x})\big) \\
\text{subject to}\quad & g_j(\mathbf{x}) \le 0, && j = 1, \dots, J \\
& h_k(\mathbf{x}) = 0, && k = 1, \dots, K \\
& x_i^{L} \le x_i \le x_i^{U}, && i = 1, \dots, n
\end{aligned}
$$

with $\mathbf{x} \in \mathbb{R}^n$ the **decision variables**, $M \ge 2$ the number of **objectives**, and $g_j, h_k$ constraints exactly as you already know them. The set of $\mathbf{x}$ satisfying all constraints and bounds is the **feasible set** $\Omega$.

Two conventions, used everywhere below and by pymoo:

- **Everything is minimized.** To maximize $f$, minimize $-f$.
- **Inequalities are written $g(\mathbf{x}) \le 0$.** A requirement $\sigma \le \sigma_{\text{allow}}$ becomes $g = \sigma/\sigma_{\text{allow}} - 1 \le 0$; a requirement $q \ge q_{\min}$ becomes $g = 1 - q/q_{\min} \le 0$. Write them **dimensionless and of order 1** — Section 15 explains why this is not cosmetic.

### The habit that prevents most confusion: keep the two spaces apart

- **Decision space** ($\mathbb{R}^n$): where *designs* live. Things you can build and dimension.
- **Objective space** ($\mathbb{R}^M$): where *performance* lives. Things you can measure.

$\mathbf{F}$ maps the first into the second. The map is generally many-to-one: different designs can perform identically. Concretely:

```
  Decision space (b, h, material, ...)        Objective space (mass, deflection)
  ┌────────────────────────────────┐          ┌────────────────────────────────┐
  │     • x_a                      │   F(·)   │                • F(x_b)        │
  │              • x_b             │  ─────►  │    • F(x_a)                    │
  │        • x_c                   │          │          • F(x_c)              │
  └────────────────────────────────┘          └────────────────────────────────┘
      designs — what you build                 performance — what you measure
```

Three consequences worth memorizing now:

1. Algorithms **search** decision space; engineers **judge** objective space. Both plots are needed.
2. "Pareto front" always means the objective-space object. Its preimage in decision space is the **Pareto set**. They are different things, and they converge at different rates (Section 18 shows this with numbers).
3. The engineering *insight* usually lives in the connection between the two: not "700 kg buys 5 µm" but "*every optimal design pushes the section as tall as the rules allow*." Section 18 is built around exactly this.

---

## 3. Dominance and Pareto optimality

With one objective, comparing two designs is a single `<`. With two or more, comparison becomes a **partial order**: sometimes there is a winner, sometimes there genuinely is not.

### 3.1 Dominance

> **Definition (dominance).** Let $\mathbf{x}^{(1)}, \mathbf{x}^{(2)} \in \Omega$. Then $\mathbf{x}^{(1)}$ **dominates** $\mathbf{x}^{(2)}$, written $\mathbf{x}^{(1)} \prec \mathbf{x}^{(2)}$, if
> 1. $f_m(\mathbf{x}^{(1)}) \le f_m(\mathbf{x}^{(2)})$ for **all** $m = 1,\dots,M$, and
> 2. $f_m(\mathbf{x}^{(1)}) < f_m(\mathbf{x}^{(2)})$ for **at least one** $m$.

In words: dominating is being a **free upgrade** — no worse anywhere, better somewhere. No rational engineer builds a dominated design, because something strictly better exists. If neither of two designs dominates the other, they are **mutually non-dominated**: a real trade-off that dominance alone cannot settle.

Two variants you will meet in the literature:

- **Weak dominance** ($\preceq$): condition 1 only. Every design weakly dominates itself, so this is a *reflexive* relation; it matters when you compare *sets* of solutions (Section 20).
- **Strict dominance** ($\prec\prec$): strictly better in *every* objective. Much rarer; do not use it as the selection rule, or almost nothing gets eliminated.

Geometrically, each design cuts objective space into four regions:

![Dominance regions](figures/fig_dominance.png)

*Figure 3.1 — Around design A. Everything up-and-right is dominated by A. Everything down-and-left dominates A. The other two quadrants are genuine trade-offs. In $M$ dimensions, "dominated by A" is one orthant out of $2^M$ — remember this when you reach Section 22.*
*(Generated by `scripts/fig01_foundations.py`.)*

### 3.2 The comparison that catches people out

Three designs, both objectives minimized:

| Design | $f_1$ | $f_2$ |
|---|---|---|
| A | 3 | 9 |
| B | 5 | 7 |
| C | 6 | 8 |

- **A vs B:** A wins on $f_1$ (3 < 5), B wins on $f_2$ (7 < 9). Neither dominates. Real trade-off.
- **B vs C:** B wins on both (5 < 6, 7 < 8). **B dominates C.**
- **A vs C:** A wins on $f_1$ (3 < 6) but *loses* on $f_2$ (9 > 8). **Neither dominates.**

The last line is the subtle one. C *is* dominated — but not by A. Dominance is not a ranking; it is a partial order, and "C is dominated" is a statement about the whole set, not about any particular pairwise comparison. The non-dominated members of $\{A,B,C\}$ are $\{A, B\}$.

### 3.3 Pareto optimality, the Pareto set, the Pareto front

> **Definition.** $\mathbf{x}^\ast \in \Omega$ is **Pareto-optimal** if no $\mathbf{x} \in \Omega$ dominates it.
> - The set of all Pareto-optimal designs is the **Pareto set** $P^\ast \subseteq \mathbb{R}^n$.
> - Its image $\{\mathbf{F}(\mathbf{x}) : \mathbf{x} \in P^\ast\}$ is the **Pareto front** $PF^\ast \subseteq \mathbb{R}^M$.

Plainly: at a Pareto-optimal design, **no objective can be improved without making another worse**. The front is the boundary between "you can do better" and "physically impossible".

Two refinements, both of which you will need later:

- **Weakly Pareto-optimal:** no design is *strictly* better in *all* objectives. This is a weaker requirement, and it admits points you would never want. Example: on $f_1 = x_1$, $f_2 = 0$ for $x_1 \in [0,1]$, every point is weakly Pareto-optimal but only $x_1 = 0$ is Pareto-optimal. Some scalarizations (the plain Tchebycheff function, Section 9) can return weakly optimal points; the standard fix is a small *augmentation* term.
- **Properly Pareto-optimal** (Geoffrion, 1968): Pareto-optimal *and* the trade-off ratios are bounded — there is some $\kappa$ such that gaining $\Delta$ in one objective never costs more than $\kappa\Delta$ in another. Improper points are those where an infinitesimal gain costs an unbounded loss. This is not pedantry: proper optimality is exactly the class of points that positive-weight scalarizations can find, which is why it appears in the theory of Section 9.

![Front concept](figures/fig_front_concept.png)

*Figure 3.2 — A cloud of 220 random designs. Grey points are dominated; the green chain is the non-dominated front. The star is the ideal point, the open square the nadir point, and the dashed box between them contains the whole front (Section 4).*
*(`scripts/fig01_foundations.py`.)*

### 3.4 Non-dominated sorting, and why it is not free

Given a finite population, "peel" it: rank 1 is the non-dominated set; remove it and rank 2 is the non-dominated set of what remains; and so on. `scripts/common.py` contains a deliberately naive implementation you should read:

```python
def nds_ranks(F):
    n = len(F); ranks = np.full(n, -1); remaining = set(range(n)); rank = 1
    while remaining:
        idx = np.array(sorted(remaining)); layer = []
        for i in idx:
            if not any(np.all(F[j] <= F[i]) and np.any(F[j] < F[i])
                       for j in idx if j != i):
                layer.append(i)
        for i in layer:
            ranks[i] = rank; remaining.discard(i)
        rank += 1
    return ranks
```

That is $O(MN^3)$ as written. Deb's fast non-dominated sort brings it to $O(MN^2)$, and pymoo 0.6.1.6 added an $O(N \log N)$ path for the bi-objective case. Sorting cost is essentially never your bottleneck in engineering work — your objective function is — but you should know the scaling before you set `pop_size = 5000`.

![Non-dominated sorting](figures/fig_nds.png)

*Figure 3.3 — 60 random designs peeled into 6 ranks, of sizes 16, 17, 12, 7, 6, 2. Rank 1 (dark) is the current best trade-off layer.*
*(`scripts/fig03_nsga2.py`.)*

---

## 4. Reference points and normalization

Two points bound the front, and both are used constantly.

- **Ideal point** $\mathbf{z}^{\text{ideal}}$: $z^{\text{ideal}}_m = \min_{\mathbf{x}\in\Omega} f_m(\mathbf{x})$ — each objective optimized *on its own*, ignoring the others. Almost always **unattainable**; that unattainability *is* what "conflicting" means.
- **Nadir point** $\mathbf{z}^{\text{nadir}}$: $z^{\text{nadir}}_m = \max_{\mathbf{x}\in P^\ast} f_m(\mathbf{x})$ — the worst value of each objective **among Pareto-optimal designs only**.

> **Read that definition of the nadir twice.** It is *not* the worst value over the feasible set. A terrible design can be arbitrarily heavy and arbitrarily floppy; that tells you nothing about the nadir. The nadir is the worst you can be while still being non-improvable. Many textbooks and a great many blog posts get this wrong, and the error propagates into wrong normalizations and meaningless hypervolumes.

### Normalization

Objectives arrive in incompatible units — kilograms against millimetres against hertz. Every method that compares objectives to each other (weights, distances, indicators, decision rules) silently assumes comparable scales. Normalization is where you make that assumption true:

$$
\tilde f_m = \frac{f_m - z^{\text{ideal}}_m}{z^{\text{nadir}}_m - z^{\text{ideal}}_m}
$$

which maps the front into $[0,1]^M$.

### The honest part: estimating the nadir is hard

In practice you do not know $P^\ast$, so you estimate:

```python
ideal = F.min(axis=0)     # column-wise min of your front approximation
nadir = F.max(axis=0)     # column-wise max
```

This is standard and it is what pymoo's own examples do — but be aware of what can go wrong:

- The **ideal estimate is usually decent**, because algorithms push hard toward the extremes.
- The **nadir estimate is unreliable**, and gets worse as $M$ grows. If your front approximation misses one end, `F.max()` under-estimates the nadir; if a poorly-converged straggler survives into `res.F`, it over-estimates it. For $M \ge 3$ the nadir is genuinely difficult to compute — it is not obtainable from $M$ separate single-objective runs (that gives you the *payoff table*, whose row maxima can be badly wrong in either direction).
- **Practical checks:** run $M$ single-objective optimizations to bracket the ideal; compare `F.max()` across several seeds; and if a decision changes materially when you drop the three worst designs, say so out loud rather than reporting one number.

Section 21 shows a case where the choice of normalization moves the recommended design by a factor of five. Take normalization seriously; it is not a formality.

---

## 5. A complete problem, solved by hand

Before touching a library, solve one problem completely, analytically. Everything later is a generalization of this.

**Problem** (Schaffer, 1985 — the "hello world" of the field):

$$
\min_{x \in [-2,\,4]} \quad f_1(x) = x^2, \qquad f_2(x) = (x-2)^2 .
$$

One variable, two objectives. Alone, $f_1$ wants $x=0$; alone, $f_2$ wants $x=2$.

**Derivation by pure reasoning.**

- Take any $x < 0$. Moving right decreases $f_1$ (closer to 0) *and* decreases $f_2$ (closer to 2). A free upgrade exists, so every $x<0$ is dominated. Mirrored, every $x>2$ is dominated.
- Take any $x \in [0,2]$. Moving right improves $f_2$ and worsens $f_1$; moving left does the reverse. No free upgrade exists, so every point of $[0,2]$ is Pareto-optimal.

**Answer, in the vocabulary of Sections 3–4.**

| Object | Value |
|---|---|
| Pareto set (decision space) | the interval $[0,2]$ |
| Pareto front (objective space) | the curve $\big(x^2,\,(x-2)^2\big)$, $x\in[0,2]$, from $(0,4)$ to $(4,0)$ |
| Ideal point | $(0,0)$ — attained by no single $x$ |
| Nadir point | $(4,4)$ — at the two front endpoints |

Note that the nadir here is $(4,4)$, but the *worst feasible* values are $f_1(4)=16$ and $f_2(-2)=16$. The nadir is not the worst feasible point. This is the smallest possible illustration of the warning in Section 4.

```python
import numpy as np, matplotlib.pyplot as plt

x = np.linspace(-2, 4, 600)
f1, f2 = x**2, (x - 2)**2
pareto = (x >= 0) & (x <= 2)          # derived analytically above

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(11, 4.4))
ax1.plot(x, f1, label="$f_1=x^2$"); ax1.plot(x, f2, label="$f_2=(x-2)^2$")
ax1.axvspan(0, 2, alpha=0.16, color="green", label="Pareto set [0,2]")
ax1.set_xlabel("x"); ax1.legend(); ax1.set_title("Decision space")

ax2.plot(f1[~pareto], f2[~pareto], ".", ms=4, color="lightgray", label="dominated")
ax2.plot(f1[pareto], f2[pareto], "-", lw=3, color="green", label="Pareto front")
ax2.plot(0, 0, "k*", ms=15, label="ideal (0,0)")
ax2.plot(4, 4, "s", mfc="none", mec="k", label="nadir (4,4)")
ax2.set_xlabel("$f_1$"); ax2.set_ylabel("$f_2$"); ax2.legend()
plt.tight_layout(); plt.show()
```

![Schaffer, both spaces](figures/fig_schaffer_spaces.png)

*Figure 5.1 — Left: the two objectives over the single decision variable; the green band is the Pareto set. Right: the same designs in objective space. Every grey point is beatable.*
*(`scripts/fig01_foundations.py`.)*

**The observation that motivates the whole module.** Even this one-variable toy has **infinitely many** Pareto-optimal designs. No algorithm will return them all. So the realistic definition of success in applied multi-objective optimization is a **finite, converged, well-spread approximation**:

- **convergence** — the points lie on (or very near) the true front;
- **diversity** — they cover it evenly, end to end.

Every algorithm in this module is a different strategy for getting both at once, and every performance indicator in Section 20 is a different way of measuring whether you did.

---

## 6. Optimality conditions: KKT with several objectives

You already know the single-objective KKT conditions. They generalize, and the generalization explains several things that would otherwise look like magic — in particular *why* weighted sums produce Pareto points at all.

> **Fritz John / KKT necessary conditions.** Let $\mathbf{x}^\ast$ be Pareto-optimal, with $f_m$ and $g_j$ differentiable and a suitable regularity (constraint-qualification) condition holding at $\mathbf{x}^\ast$. Then there exist multipliers $\lambda_m \ge 0$ with $\sum_m \lambda_m = 1$, and $\mu_j \ge 0$, such that
> $$\sum_{m=1}^{M} \lambda_m \nabla f_m(\mathbf{x}^\ast) \;+\; \sum_{j=1}^{J} \mu_j \nabla g_j(\mathbf{x}^\ast) \;=\; \mathbf{0}, \qquad \mu_j\, g_j(\mathbf{x}^\ast) = 0 \ \ \forall j .$$

Set $M=1$ and you recover exactly the conditions from your previous course. The complementarity condition $\mu_j g_j = 0$ is unchanged: inactive constraints get zero multipliers.

**How to read this.** At a Pareto-optimal point, the objective gradients and the active-constraint gradients are in **balance** — there is no direction that improves one objective without worsening another or violating a constraint. The vector $\boldsymbol\lambda$ is the *local* trade-off: it tells you the exchange rate between objectives at that specific point. Different points on the front have different $\boldsymbol\lambda$, which is precisely why "the weights" are not a global property of the problem.

**Sufficiency.** For *convex* problems (convex $f_m$, convex feasible set), the conditions with all $\lambda_m > 0$ are sufficient, and every properly Pareto-optimal point is obtained from *some* positive $\boldsymbol\lambda$. This is the theorem behind the weighted-sum method, and — read carefully — it is also the theorem that tells you the method fails when the problem is not convex. Section 8 makes that concrete.

### Verify it yourself on the beam

`scripts/check_kkt.py` checks these conditions numerically at points of the case study you will meet in Section 18. Run it. Output at a point on the interior of that front, $b=2$ cm, $h=20$ cm, where only the aspect-ratio constraint is active:

```
  mass = 31.400 kg   deflection = 0.2500 mm
  g1 (stress)  = -0.9500   -> inactive
  g2 (aspect)  = +0.0000   -> ACTIVE
  multipliers (SI units): lambda_mass = 1.592e-05, lambda_defl = 0.999984, mu_g2 = 2.500e-04
  all non-negative? True    residual = 1.01e-14
```

The conditions hold to machine precision. But look at $\lambda_{\text{mass}} = 1.6\times10^{-5}$ against $\lambda_{\text{defl}} \approx 1$. Does that mean deflection matters 60 000 times more than mass at this design? **No.** It is a units artifact: mass is $O(10)$ kg while deflection is $O(10^{-4})$ m. Normalize both objectives by their front ranges and rerun:

```
  multipliers: lambda_mass = 0.4159, lambda_defl = 0.5841, mu_g2 = 9.242e-03
```

Now the numbers mean something: at this design, mass and deflection carry roughly comparable local weight. **The multipliers — like weights, like indicators, like every decision rule in Section 21 — are only interpretable after normalization.** This is the first of many appearances of that theme.

The script also checks a *dominated* interior point ($b = h = 10$ cm), where no valid non-negative multipliers exist (residual $5.7\times 10^{-3}$, not zero) — as it must be, since growing $h$ at constant mass improves both objectives there.

---

## 7. When does preference enter? The three families of methods

Here is the organizing idea for the rest of the module. A multi-objective problem cannot be *solved* without some statement of preference — dominance alone will never pick between P, Q, and R in Section 1. Methods differ in **when** that preference is supplied (the classification is due to Hwang & Masud, 1979, and is standard in Miettinen, 1999):

| Family | Preference is stated… | Method asks you for… | Examples |
|---|---|---|---|
| **A priori** | *before* optimizing | weights, budgets, goals | weighted sum, ε-constraint, goal programming |
| **A posteriori** | *after* optimizing | nothing up front; you choose from the computed front | NSGA-II, NSGA-III, MOEA/D, SMS-EMOA |
| **Interactive** | *during* optimizing | repeated local judgements as candidates are shown | NIMBUS, reference-point methods, R-NSGA-II |
| **No-preference** | never (a canonical compromise is imposed) | nothing | compromise programming to the ideal point |

Why this matters for how you read the rest:

- **A priori methods are cheap but fragile.** One solver run gives one design. Excellent *if* you truly know the trade-off in advance — which, before seeing the front, you usually do not. Worse, as Section 8 shows, the relationship between the numbers you supply and the design you get is not intuitive.
- **A posteriori methods are the default in engineering**, and the bulk of this module. You compute the whole menu, then decide. The cost is many function evaluations; the payoff is that you *see* the trade-off before committing to a position on it, and that the front itself — not the single chosen design — is often the most valuable deliverable.
- **Interactive methods** are underused and worth knowing about. When each evaluation is a two-hour CFD run, computing the whole front is unaffordable, but a handful of guided iterations with an engineer in the loop is not. pymoo's `R-NSGA-II` / `R-NSGA-III` implement the reference-point flavour.

A common misreading to avoid: an a posteriori method does **not** eliminate preference, it *postpones* it. Sections 20 and 21 are both, in the end, about preference — the reference point for hypervolume and the normalization for a decision rule are preference statements wearing technical clothes.

### Exercises for Part I

**E1.** Five designs, all objectives minimized: A $(2,8,5)$, B $(3,7,5)$, C $(2,8,4)$, D $(4,6,7)$, E $(2,9,6)$. Find all dominance relations and list the non-dominated set.

**E2.** Prove that dominance is transitive: if $\mathbf{a} \prec \mathbf{b}$ and $\mathbf{b} \prec \mathbf{c}$ then $\mathbf{a} \prec \mathbf{c}$. Then show by counterexample that "mutually non-dominated" is *not* transitive. Why does that second fact make ranking designs harder than sorting numbers?

**E3.** For Schaffer's problem, compute the exact worst feasible value of each objective and compare to the nadir $(4,4)$. State in one sentence what would go wrong if you normalized with the worst-feasible values instead.

**E4.** Consider $\min\,(f_1, f_2) = (x_1,\ x_1)$ on $x_1 \in [0,1]$ — two identical objectives. What are the Pareto set and front? Now try $(f_1,f_2) = (x_1, -x_1)$. What are they? What does each case tell you about checking that your objectives genuinely conflict?

**E5.** Take $\min (f_1,f_2) = (x_1, 0)$ on $[0,1]$. Show that every point is weakly Pareto-optimal but only $x_1=0$ is Pareto-optimal. Why is this a problem for any method that only checks "is anything strictly better in all objectives?"

**E6.** Run `python scripts/check_kkt.py`. At the lightest design the stress constraint is active *and* $b$ sits on its lower bound. Write down the KKT conditions for that point, including the bound multiplier. (You will use this in Exercise 12.)

**E7.** You are asked to minimize the cost of a pressure vessel and to keep its wall thickness at least 12 mm. Should thickness be a second objective or a constraint? Give the general rule and apply it.

---

# Part II — Scalarization: turning one problem into many

The oldest idea in the field, and still the right tool in several situations: convert the multi-objective problem into a *family* of single-objective problems, solve each with a solver you already own, and assemble the results.

This part is not a straw man to be knocked down. One of these methods (the achievement scalarizing function) returns in Section 21 as the right tool for choosing a design, and another (Tchebycheff decomposition) is the engine inside MOEA/D. What you need is a precise sense of what each one can and cannot reach.

## 8. The weighted-sum method

$$
\min_{\mathbf{x}\in\Omega} \ \sum_{m=1}^{M} w_m\, f_m(\mathbf{x}), \qquad w_m \ge 0,\quad \sum_m w_m = 1 .
$$

Each weight vector defines one single-objective problem. By the sufficiency result in Section 6, for **positive** weights its optimum is properly Pareto-optimal. Sweep many weight vectors to trace the front.

### 8.1 The geometry that explains everything

For fixed $\mathbf{w}$, the level sets of $w_1f_1 + w_2f_2$ are **straight lines** in objective space with slope $-w_1/w_2$. Minimizing slides such a line down-left until it just touches the attainable region; the touching point is your answer.

![Weighted-sum geometry](figures/fig_ws_geometry.png)

*Figure 8.1 — Left: on a convex front, different slopes touch different points, so sweeping weights walks along the front. Right: on a non-convex front, every line settles onto an endpoint. A straight line can only be tangent to the **convex hull** of the attainable region, so any part of the front that bulges away from the origin is invisible to the method for **every** choice of weights.*
*(`scripts/fig02_scalarization.py`.)*

That right-hand panel is the method's structural flaw, and it is worth stating as a theorem you can hold in your head: **the weighted sum can only find points on the convex hull of the attainable set.** Non-convex fronts are common in real engineering, and you generally cannot know in advance whether yours is one.

### 8.2 Demonstrating the failure, with no solver to blame

A demonstration of this claim has to be airtight, because there is an obvious objection: maybe the *solver* failed, not the method. So here the subproblems are solved by exhaustive search over 200 001 grid points — global optimality is guaranteed by construction.

Problem: $f_1 = x$, $f_2 = 1 - x^2$ on $x\in[0,1]$. The attainable set is the curve itself, and $f_2 = 1 - f_1^2$ is concave, hence the front is non-convex. Twenty-one weight vectors from $0.02$ to $0.98$:

![Three scalarizations on a non-convex front](figures/fig_scalarization_compare.png)

*Figure 8.2 — 21 runs each, all solved to global optimality by exhaustive search. Weighted sum: **2 distinct results** — the two endpoints, exactly as the convex-hull argument predicts. The other two methods (Sections 9 and 10) return 21 distinct points and cover the whole front, including the non-convex interior.*
*(`scripts/fig02_scalarization.py`.)*

You can see the mechanism analytically. Minimizing $w_1 x + w_2(1-x^2)$ has derivative $w_1 - 2w_2x$, so the stationary point $x = w_1/(2w_2)$ has second derivative $-2w_2 < 0$ — it is a **maximum**. The minimum is therefore always at a boundary of $[0,1]$. The interior of the front is not merely hard to reach; it is never a minimizer for any weights.

**The same thing on a real benchmark.** ZDT2 is a standard 30-variable problem with a concave front. Fifteen weighted-sum runs with `scipy`'s L-BFGS-B, versus one run of NSGA-II:

```python
import numpy as np
from scipy.optimize import minimize as scipy_min
from pymoo.problems import get_problem

zdt2 = get_problem("zdt2")                          # concave front, 30 variables
ws_points = []
for w1 in np.linspace(0.02, 0.98, 15):
    def weighted(x, w1=w1):
        F = zdt2.evaluate(np.atleast_2d(x))[0]
        return w1 * F[0] + (1 - w1) * F[1]
    r = scipy_min(weighted, x0=np.full(30, 0.5), bounds=[(0, 1)] * 30, method="L-BFGS-B")
    ws_points.append(zdt2.evaluate(np.atleast_2d(r.x))[0])

print(np.unique(np.array(ws_points)[:, 0].round(3)))    # -> [0. 1.]   endpoints only
```

![Weighted sum on ZDT2](figures/fig_ws_zdt2_failure.png)

*Figure 8.3 — All 15 weighted-sum runs land on the two endpoints. NSGA-II covers the whole front in one run.*

**One caveat, stated because it is the kind of thing a careful reader should catch.** In this 30-variable run the collapse is *partly* the convexity argument and *partly* L-BFGS-B struggling with ZDT2's 30-dimensional $g$ function — 11 of the 15 runs land on the *same* endpoint, which pure geometry would not predict. That is exactly why Figure 8.2 exists: there, exhaustive search removes the solver from the argument entirely. Use Figure 8.2 as the proof and Figure 8.3 as the illustration that it bites in practice.

### 8.3 The second weakness: you do not control the spread

Even where the weighted sum works — a convex front — the *distribution* of the points it returns is not under your control. This is often stated as a blanket rule, which is wrong, and the honest version is more useful.

![Weighted-sum spread](figures/fig_ws_spread.png)

*Figure 8.4 — 25 uniformly spaced weights on two different convex fronts. **Left:** Schaffer. The result is nearly uniform: the arc-length gaps vary by only $1.4\times$. **Right:** the front $f_1=x$, $f_2=(1-x)/(1+99x)$. Same 25 uniform weights, and now the gaps vary by $44.5\times$, with **56% of the weights landing in the first 10% of the front**. Bottom row: the gap-to-mean-gap ratio for each; note the logarithmic axis on the right.*
*(`scripts/fig02_scalarization.py`.)*

Why is Schaffer so well-behaved? Because minimizing $w_1x^2 + w_2(x-2)^2$ gives $x^\ast = 2(1-w_1)$ — the solution is *exactly linear in the weight*, so uniform weights give uniform coverage. That is a special property of that problem, not a property of the method.

So the correct statement is: **uniform weights give you no guarantee about spread; whether you get lucky depends on the curvature of a front you have not seen yet.** Do not conclude from one tidy textbook example that the method distributes points well.

### 8.4 Verdict

| | |
|---|---|
| **Strengths** | Trivial to implement; reuses any single-objective solver; each subproblem is unconstrained beyond the original constraints; genuinely the right choice if you *know* the trade-off a priori and only want one design. |
| **Weaknesses** | (1) Provably blind to non-convex regions of the front, for every weight vector. (2) No control over spread (Fig. 8.4). (3) The weights are meaningless unless objectives are normalized, and normalizing needs ideal/nadir estimates, which need the front — a chicken-and-egg loop. (4) One point per solver run, each carrying the full single-objective risk of local optima. |

---

## 9. Weighted Tchebycheff and the achievement scalarizing function

The natural fix. Instead of a weighted *sum* (whose level sets are straight lines), use a weighted **max** — whose level sets are nested right-angled corners, and a corner *can* touch a non-convex boundary.

**Weighted Tchebycheff (weighted $L_\infty$) scalarization:**

$$
\min_{\mathbf{x}\in\Omega} \ \max_{m=1,\dots,M} \ \Big[\, w_m \big( f_m(\mathbf{x}) - z^{\text{ref}}_m \big) \Big]
$$

with a **reference point** $\mathbf{z}^{\text{ref}}$, usually the ideal point (or slightly better than it, the *utopian* point).

**Why it works where the weighted sum does not.** Every Pareto-optimal point — convex region or not — is the optimum of this problem for *some* weight vector. That is the key theoretical advantage, and it is visible in the middle panel of Figure 8.2: 21 distinct front points, evenly covering the concave interior, from the same 21 weight vectors that gave the weighted sum only 2 points.

You can check the middle-panel mechanism by hand. With $\mathbf{z}^{\text{ref}} = (0,0)$ and $w_1=w_2=\tfrac12$ on $f_2 = 1-f_1^2$, the optimum balances the two terms: $f_1 = 1 - f_1^2$, giving $f_1 = 0.618$ — comfortably in the interior that the weighted sum could never reach.

**The catch, and the standard fix.** The plain Tchebycheff function can return **weakly** Pareto-optimal points (Section 3.3), because a corner can touch a flat edge of the attainable set along its whole length. The remedy is the **augmented** form, adding a small sum term:

$$
\min_{\mathbf{x}\in\Omega} \ \max_m \Big[ w_m \big( f_m - z^{\text{ref}}_m \big) \Big] \;+\; \rho \sum_{m=1}^{M} w_m \big( f_m - z^{\text{ref}}_m \big), \qquad \rho \approx 10^{-4}\text{–}10^{-6}.
$$

The $\rho$ term breaks ties in favour of genuinely Pareto-optimal points. This augmented form is the **achievement scalarizing function** (ASF) of Wierzbicki (1980), and it is the workhorse of reference-point methods.

**In pymoo.** ASF is available as a decomposition, and it appears again in Section 21 for choosing a design:

```python
from pymoo.decomposition.asf import ASF

# NOTE the convention: pymoo's ASF DIVIDES by the weights, so pass reciprocals
# of your importance weights.
weights = np.array([0.7, 0.3])            # mass matters 70/30 over deflection
i = ASF()(normalized_front, 1.0 / weights).argmin()
```

That division convention catches everyone once. If your ASF result moves the *opposite* way to your intent when you change the weights, this is why.

**Where this belongs in the taxonomy.** Tchebycheff/ASF is an a priori method when you sweep weights to generate a front, and a no-preference or a priori method when you use it to pick one point. It is also the scalarization inside **MOEA/D** (Zhang & Li, 2007), which runs a whole population of Tchebycheff subproblems simultaneously and lets neighbours share information — Part II's ideas reborn inside an evolutionary loop.

---

## 10. The ε-constraint method

Keep one objective; demote the rest to constraints with adjustable budgets:

$$
\min_{\mathbf{x}\in\Omega} \ f_1(\mathbf{x}) \quad\text{subject to}\quad f_m(\mathbf{x}) \le \varepsilon_m \ \ (m = 2,\dots,M), \ \text{plus the original constraints.}
$$

Read as an engineering question this is the most natural of the three: *"What is the lightest design whose tip deflection stays under 2 mm?"* Sweep $\varepsilon$ and you trace the front point by point.

```python
import numpy as np
from scipy.optimize import minimize

f1 = lambda x: x[0]**2
f2 = lambda x: (x[0] - 2)**2

front = []
for eps in np.linspace(0.02, 4.0, 25):                     # sweep the budget on f2
    res = minimize(f1, x0=[1.0], bounds=[(-2, 4)],
                   constraints=[{"type": "ineq",
                                 "fun": lambda x, e=eps: e - f2(x)}])   # f2 <= eps
    if res.success:
        front.append((f1(res.x), f2(res.x)))
```

![Epsilon-constraint on Schaffer](figures/fig_eps_schaffer.png)

*Figure 10.1 — 25 budgets, 25 front points. Because $\varepsilon$ is swept uniformly in $f_2$, the points are uniform along the $f_2$ axis: you get direct, predictable control over spread in that objective.*
*(`scripts/fig02_scalarization.py`.)*

**Strengths.** Reaches non-convex regions (right panel of Figure 8.2 — 21 of 21 points). The $\varepsilon$ values have direct physical meaning, which stakeholders understand and can argue about productively: "deflection budget" is a sentence an engineering manager can respond to; "$w_1 = 0.7$" is not.

**Weaknesses.**
- You must guess a sensible range and spacing for each $\varepsilon_m$. Too tight, and subproblems are infeasible; too loose, and the constraint is inactive and you get the same point repeatedly.
- With $M$ objectives you sweep an $(M-1)$-dimensional grid. Ten values per objective and $M=4$ means $1000$ constrained optimizations — the combinatorial explosion is the real limit.
- Each subproblem is now *constrained*, typically harder for gradient-based solvers than the original.
- Some $\varepsilon$ choices give **weakly** Pareto-optimal points (when the $\varepsilon$ constraint is inactive at the optimum). The standard cure, again, is a small augmentation term, or checking activity of the $\varepsilon$ constraints afterwards.

---

## 11. Normal boundary intersection, briefly

Worth knowing by name, because it addresses the one weakness Tchebycheff and ε-constraint share: producing an *evenly spread* set of points without trial and error.

**Normal Boundary Intersection** (Das & Dennis, 1998) works like this. Compute the $M$ individual optima; their convex hull in objective space is the **CHIM** (convex hull of individual minima), a simplex spanning the extremes. Place evenly spaced points on the CHIM, and from each, search along the direction *normal* to the CHIM, pointing toward the front, for the furthest attainable point. Because the starting points are evenly spaced by construction, the resulting front points are close to evenly spaced too.

**Trade-offs.** NBI gives the best spread control of any classical method and, like Tchebycheff, reaches non-convex regions. Its costs are that it needs the individual optima first, it can return dominated points in awkward geometries, and each subproblem is an equality-constrained problem. The related **Normalized Normal Constraint** method (Messac et al., 2003) fixes the dominated-point issue.

You will not need NBI in this module — but if you ever hear "classical methods cannot produce a well-spread front," that claim is about the weighted sum, not about the classical family.

---

## 12. Scalarization scorecard

| Property | Weighted sum | Tchebycheff / ASF | ε-constraint | NBI |
|---|---|---|---|---|
| Reuses single-objective solvers | yes | yes | yes | yes |
| Points per solver run | 1 | 1 | 1 | 1 |
| Reaches non-convex front regions | **no** | yes | yes | yes |
| Can return only Pareto-optimal points | yes (with $w>0$) | needs augmentation | needs care | needs care |
| Control over spread | none | indirect | direct, per objective | good, by construction |
| Needs objective normalization | critical | critical | mild | built in |
| Scales past 3 objectives | poorly | moderately | poorly (grid explosion) | poorly |
| Parameters carry physical meaning | weights (fuzzy) | reference point + weights | budgets (clear) | geometric |
| Needs gradients / smoothness | inherits solver's | inherits solver's | inherits solver's, plus harder subproblems | inherits solver's |

**The shared structural weakness** is the second row: **one Pareto point per solver run**. Every run carries the full single-objective risk of getting stuck in a local optimum, and afterwards you must assemble, de-duplicate, and filter dominated results by hand.

What we actually want is a *set* of well-spread non-dominated points, produced together, with the members helping each other. That suggests using an algorithm whose native data structure is a set. That is Part III.

Before moving on, keep two things:

1. **Scalarization is not obsolete.** ASF returns in Section 21 as the correct tool for picking one design from a computed front; Tchebycheff decomposition is the engine of MOEA/D; ε-constraint is often the *right* method when a stakeholder genuinely thinks in budgets and only three or four designs are needed.
2. **For a smooth, convex, low-dimensional problem, a classical method can give you something no evolutionary algorithm can: a certificate.** A converged KKT point with verified multipliers is proof. NSGA-II gives you a good picture and no proof. Choose accordingly.

### Exercises for Part II

**E8.** For Schaffer's problem, solve $\min w_1x^2 + (1-w_1)(x-2)^2$ analytically to get $x^\ast(w_1)$. Confirm it is linear in $w_1$. Then use the arc-length element of the front to explain the $1.4\times$ gap variation measured in Figure 8.4.

**E9.** Take $f_2 = 1 - f_1^{1/2}$ on $f_1 \in [0,1]$ (a convex front). Derive the weighted-sum tangent point $f_1^\ast(w_1)$, and find the range of $w_1$ that produces interior points. What fraction of $[0,1]$ is that? Comment.

**E10.** Modify `scripts/fig02_scalarization.py` to use the *augmented* ASF with $\rho = 10^{-4}$ on the flat-front problem $\min (x_1,\,0)$, $x_1 \in [0,1]$. Show that the plain form can return any $x_1$ while the augmented form returns $x_1 = 0$.

**E11.** You have $M=4$ objectives and can afford 250 function evaluations in total. A colleague proposes an ε-constraint sweep with 5 values per objective. Count the subproblems, estimate the evaluations, and recommend an alternative.

---
# Part III — The evolutionary approach

## 13. Why population-based algorithms fit this problem

Recall the goal from Section 5: a finite, converged, well-spread approximation of the front — a *set*. Which family of algorithms natively manipulates a set of solutions? Population-based ones.

Evolutionary algorithms (EAs) hold a **population** of candidate designs and improve it generation by generation with three operators:

- **selection** — better designs get to reproduce;
- **crossover / recombination** — blend two parents into offspring;
- **mutation** — small random perturbations, for exploration.

For single-objective problems an EA is one heuristic among many, often not the best. For multi-objective problems the structural match is excellent:

> **One run of a multi-objective EA returns an entire front approximation** — tens to hundreds of trade-off designs at once — where every method in Part II needed one solver run per point.

Further practical reasons they dominate applied work:

- **No gradients needed.** Your objective may be a finite-element solve, a CFD run, a Simulink model, or thirty-year-old Fortran. An EA needs only function *values*.
- **Tolerant of nastiness:** discontinuities, non-convexity, disconnected fronts, mixed integer/continuous/categorical variables (Section 24), mild noise.
- **Global character:** a spread-out population explores several basins at once, which *reduces* — never eliminates — the local-optimum trap.
- **The members help each other.** This is the deep reason. A design that is currently mediocre may carry a variable value that becomes valuable later; in a population it survives long enough to be recombined. Sequential scalarization discards it.

And the honest costs, so that you deploy them where they belong:

- **Evaluation-hungry:** typically $10^3$–$10^5$ evaluations. If one evaluation takes two hours, see Section 25.
- **No optimality certificate.** EAs are heuristics. They return a good approximation with no proof that it is the front. For smooth convex problems the classical methods of Part II can give guarantees an EA cannot.
- **Stochastic.** Two runs differ. Fix seeds while developing; report statistics over many runs in anything that matters (Section 20.5).

The most widely used multi-objective EA, and the default throughout this module, is **NSGA-II**.

---

## 14. NSGA-II, opened up

NSGA-II — *Non-dominated Sorting Genetic Algorithm II* (Deb, Pratap, Agarwal & Meyarivan, 2002) — is among the most cited algorithms in computational science and remains the standard first choice for 2–3 objectives. pymoo implements it for you, but you need its two mechanisms in your head, because they explain the algorithm's behaviour, its parameters, and the specific way it degrades in Section 22.

Any front-approximating algorithm must deliver the two properties from Section 5:

1. **convergence** — push the population *toward* the front;
2. **diversity** — spread it *along* the front (100 copies of one excellent design is a useless "front").

NSGA-II devotes one mechanism to each.

### 14.1 Mechanism 1 — non-dominated sorting gives convergence

Exactly the peeling from Section 3.4: rank 1 is the non-dominated set of the population, rank 2 the non-dominated set of the remainder, and so on (Figure 3.3). Lower rank is better, and selection pressure toward low rank is what drives the population front-ward.

Note carefully what rank 1 means: **non-dominated within this population**, not Pareto-optimal. A rank-1 design can be far from the true front if the population is poor. This distinction is the source of a great deal of over-claiming, and Section 18 will show you a concrete instance.

### 14.2 Mechanism 2 — crowding distance gives diversity

Within a single rank, dominance is silent: every member is non-dominated against every other. NSGA-II breaks the tie by rewarding **solitude**.

For each objective $m$, sort the front by $f_m$; give each interior design the gap between its two neighbours, normalized by the front's range in that objective; assign $\infty$ to the two boundary designs so the extremes are never discarded. Then **sum over objectives**:

$$
d_i \;=\; \sum_{m=1}^{M} \frac{f_m(i+1) - f_m(i-1)}{f_m^{\max} - f_m^{\min}}
$$

where $i\pm1$ are $i$'s neighbours in the $m$-sorted order. Larger $d_i$ means a sparser neighbourhood, which is preferred.

> **A terminology warning.** Deb's paper motivates $d_i$ as "the average side length of the cuboid" spanned by the neighbours, and many write-ups repeat that phrase — but the algorithm, and pymoo, compute the **sum**, not the average. Since the two differ only by the constant factor $M$, the ranking is identical and nothing breaks; but if you implement it yourself from a verbal description and then compare numbers against pymoo, you need to know which one you are looking at.

![Crowding distance](figures/fig_crowding.png)

*Figure 14.1 — Five rank-1 designs a–e. The shaded cuboid belongs to $c$ and is spanned by its neighbours $b$ and $d$.*
*(`scripts/fig03_nsga2.py`, which prints the table below so the figure and the numbers cannot drift apart.)*

Front ranges here are $\Delta f_1 = 8.0$ and $\Delta f_2 = 6.4$:

| design | $f_1$ | $f_2$ | gap in $f_1$ | gap in $f_2$ | $d$ |
|---|---|---|---|---|---|
| a (boundary) | 1.0 | 9.0 | — | — | $\infty$ |
| b | 2.0 | 6.5 | $(3.5-1.0)/8.0 = 0.312$ | $(9.0-5.0)/6.4 = 0.625$ | **0.938** |
| c | 3.5 | 5.0 | $(6.0-2.0)/8.0 = 0.500$ | $(6.5-3.2)/6.4 = 0.516$ | **1.016** |
| d | 6.0 | 3.2 | $(9.0-3.5)/8.0 = 0.688$ | $(5.0-2.6)/6.4 = 0.375$ | **1.062** |
| e (boundary) | 9.0 | 2.6 | — | — | $\infty$ |

If one of $b, c, d$ had to be discarded, **$b$ goes first** — it sits in the most crowded region. That is the whole diversity mechanism.

### 14.3 The generational loop

One generation with population size $N$:

1. **Mating selection — binary tournament.** Pick two random members; the lower *rank* wins; ties broken by larger *crowding distance*. Repeat to fill the parent pool.
2. **Variation.** Produce $N$ offspring by **SBX crossover** (simulated binary crossover, which blends parent variable values with a tunable spread parameter $\eta_c$) and **polynomial mutation** (perturbations with spread $\eta_m$). pymoo's defaults are sensible for a first run.
3. **Elitist survival.** Merge parents and offspring into a pool of $2N$; run non-dominated sorting on the pool; fill the next generation rank by rank; when a rank overflows the remaining slots, keep its **least crowded** members. Because parents compete with their own children, the best designs can never be lost — this is **elitism**, and it is the main advance of NSGA-II over NSGA.

That is the entire algorithm: *rank for convergence, crowding for diversity, inside an elitist genetic algorithm.* Its two practically relevant knobs are **population size** and **evaluation budget**; everything else has defaults you should leave alone until you have a measured reason not to.

---

## 15. Constraints: the feasibility-first rule

Engineering problems have constraints, and NSGA-II handles them with a rule that fits in three lines — Deb's **constrained-domination** (feasibility-first) rule, applied in every comparison the algorithm makes:

1. A **feasible** design always beats an **infeasible** one.
2. Between two infeasible designs, the smaller **total constraint violation** wins:
   $$CV(\mathbf{x}) = \sum_{j=1}^{J}\max\big(0,\,g_j(\mathbf{x})\big) \;+\; \sum_{k=1}^{K}\big|h_k(\mathbf{x})\big| .$$
3. Between two feasible designs, ordinary dominance (then crowding) applies.

There are no penalty coefficients to tune, which is the great practical virtue of the rule.

> **The consequence you must respect.** Violations of *different* constraints are **summed**. So the constraints must live on comparable scales, or the large-magnitude one silently dominates the comparison and the algorithm effectively ignores the others.
>
> Concretely: write $g = \sigma/\sigma_{\text{allow}} - 1 \le 0$, which is $O(1)$, **not** $g = \sigma - \sigma_{\text{allow}} \le 0$, which is $O(10^8)$ in pascals. If you mix a pascal-scaled constraint with a metre-scaled one, the metre-scaled constraint contributes nothing to $CV$ and is, for selection purposes, absent.

**Alternatives pymoo offers**, worth knowing for the cases where feasibility-first struggles (very small feasible regions, where an all-infeasible initial population has no gradient of useful information):

```python
from pymoo.constraints.as_penalty import ConstraintsAsPenalty
from pymoo.constraints.as_obj import ConstraintsAsObjective

problem_p = ConstraintsAsPenalty(problem, penalty=100.0)   # CV folded into F
problem_o = ConstraintsAsObjective(problem)                # CV becomes an extra objective
```

`ConstraintsAsObjective` is the interesting one: it turns "get feasible" into a goal the population optimizes explicitly, which can find a needle-in-a-haystack feasible region that feasibility-first misses. The cost is one extra objective dimension.

**Equality constraints.** Prefer to eliminate them by substitution if you possibly can — an EA satisfies $h(\mathbf{x}) = 0$ only to within a tolerance, and a population of near-feasible points is a poor search medium. If a variable is determined by the others, solve for it inside `_evaluate` rather than declaring it a variable and adding an equality. When elimination is impossible, use a **repair operator** (pymoo's `Repair` class), which projects each offspring onto the feasible manifold before evaluation. This is far more effective than hoping mutation lands on a measure-zero set.

### Exercises for Part III

**E12.** *(The most important exercise here.)* Implement crowding distance yourself for the five points in Figure 14.1 and reproduce the table. Then change $c$'s position to $(3.5, 8.9)$ and recompute. Which design is now the most crowded? Explain the change in one sentence.

**E13.** Explain why the boundary designs get $d = \infty$ rather than a large finite number. What would go wrong over 200 generations if they got a large finite value instead?

**E14.** A student writes two constraints as $g_1 = \sigma - 300\times10^6 \le 0$ (pascals) and $g_2 = h - 10b \le 0$ (metres). Estimate the magnitude of each at a typical infeasible design and explain, quantitatively, why $g_2$ will be effectively ignored. Then rewrite both correctly.

**E15.** NSGA-II merges parents and offspring before survival. Construct a small example ($N=3$) showing a design that would be lost without elitism.

---

# Part IV — Practice with pymoo

## 16. Getting started

[pymoo](https://pymoo.org) (Blank & Deb, 2020) is the standard open-source Python framework for multi-objective optimization: algorithms, benchmark problems, indicators, visualization, and decision-making tools behind one coherent API. This module targets **pymoo 0.6.2**; the code runs on any 0.6.x release, with one import-path note flagged in Section 25.

### 16.1 Installation

```bash
pip install -U pymoo
python -c "import pymoo; print(pymoo.__version__)"        # 0.6.2
```

pymoo compiles a few speed-critical modules when it can and falls back to pure Python when it cannot — identical results, somewhat slower. Check with:

```bash
python -c "from pymoo.functions import is_compiled; print('Compiled:', is_compiled())"
```

### 16.2 The three building blocks

Every pymoo script assembles the same three things:

1. a **Problem** — variables, bounds, objectives, constraints;
2. an **Algorithm** — e.g. `NSGA2`, with its parameters;
3. the **`minimize()`** call — runs one on the other until a termination criterion fires.

### 16.3 Defining a problem

Subclass `ElementwiseProblem` and write `_evaluate` for **one design at a time**; pymoo loops over the population for you. (Section 25 shows the vectorized alternative.)

```python
import numpy as np
from pymoo.core.problem import ElementwiseProblem

class Schaffer(ElementwiseProblem):

    def __init__(self, **kwargs):
        super().__init__(
            n_var=1,                    # number of decision variables
            n_obj=2,                    # number of objectives
            n_ieq_constr=0,             # number of inequality constraints
            xl=np.array([-2.0]),        # lower bounds
            xu=np.array([ 4.0]),        # upper bounds
            **kwargs)                   # forward kwargs -> enables Section 25

    def _evaluate(self, x, out, *args, **kwargs):
        # x is a 1-D array of length n_var: ONE design
        out["F"] = [x[0]**2, (x[0] - 2)**2]
```

Get into the habit of that `**kwargs` forwarding now. It costs nothing and it is what lets you attach a parallel runner later without editing the class.

The conventions never change:

| Key | Meaning | Convention |
|---|---|---|
| `out["F"]` | objective values | all **minimized**; maximize by negating |
| `out["G"]` | inequality constraints | feasible when **$\le 0$** |
| `out["H"]` | equality constraints | feasible when **$= 0$** (avoid; see Section 15) |

### 16.4 Running it

```python
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize

res = minimize(Schaffer(),
               NSGA2(pop_size=50),
               ("n_gen", 100),          # termination
               seed=1,                  # reproducibility
               verbose=True)
```

The result object holds everything:

| Field | Content |
|---|---|
| `res.X` | Pareto-**set** approximation (designs), shape `(n_solutions, n_var)` |
| `res.F` | Pareto-**front** approximation (objective values), shape `(n_solutions, n_obj)` |
| `res.G`, `res.CV` | constraint values, and total violation per design |
| `res.exec_time` | wall-clock seconds |
| `res.algorithm` | the algorithm object at termination (e.g. `res.algorithm.n_gen`) |
| `res.history` | per-generation snapshots — only if `save_history=True` |

With `verbose=True`, pymoo prints one line per generation with `n_gen` and `n_eval`. Note that `n_eval` $=$ `pop_size` $\times$ generation: here $50\times100 = 5000$. **Evaluations, not generations, are your real budget** — that is the number that costs you money when each evaluation is a simulation.

![NSGA-II on Schaffer](figures/fig_schaffer_nsga2.png)

*Figure 16.1 — Left: NSGA-II's 50 solutions against the front we derived by hand in Section 5. Right: the corresponding designs, all inside the true Pareto set $[0,2]$.*
*(`scripts/fig03_nsga2.py`.)*

**A detail worth pausing on.** That run returns designs spanning $x \in [0.000005,\ \mathbf{2.000143}]$. The right endpoint is *outside* the true Pareto set: $x = 2.000143$ is dominated by $x=2$, which is lighter in $f_1$ and equal in the limit on $f_2$. So `res.F` contains a design that is **not Pareto-optimal**.

Nothing is broken. `res.F` is the set that is non-dominated *within the final population* — precisely as Section 14.1 warned. There was no population member close enough to $x=2$ to dominate it, so it survived. Internalize this now: **pymoo returns a mutually non-dominated set, never a certified Pareto front.** Every quality claim you make later needs an indicator (Section 20) or an analytical check (Section 18), not the mere fact that `minimize()` returned.

---

## 17. Termination: when is it done?

`("n_gen", 100)` is the simplest criterion, not the best.

```python
res = minimize(problem, algorithm, ("n_gen",  200), ...)      # generations
res = minimize(problem, algorithm, ("n_eval", 20000), ...)    # evaluation budget
res = minimize(problem, algorithm, ("time", "00:05:00"), ...) # wall clock
```

`("n_eval", ...)` is the most honest for comparing algorithms — everyone gets the same budget — and the most natural for expensive problems, where the budget is simply what you can afford.

**Convergence-based termination.** Better still, stop when the front stops improving. If you pass **no** termination argument, pymoo uses `DefaultMultiObjectiveTermination`, which watches movement in design space, constraint violation, and objective space over a sliding window and stops when all fall below tolerances, with a generous generation cap as a safety net:

```python
from pymoo.termination.default import DefaultMultiObjectiveTermination

termination = DefaultMultiObjectiveTermination(
    xtol=1e-8,        # design-space movement tolerance
    cvtol=1e-6,       # constraint-violation tolerance
    ftol=0.0025,      # objective-space movement tolerance
    period=30,        # sliding window, in generations
    n_max_gen=1000,   # hard cap
)
res = minimize(problem, algorithm, termination, seed=1)
```

On ZDT1 with `NSGA2(pop_size=100)` and `seed=1`, the default stops at **generation 275** — which, as Figure 20.3 shows, is almost exactly the elbow of the hypervolume curve. That is a good default doing its job.

For production runs: **convergence-based termination plus a hard budget cap** is the professional setup. Fixed `n_gen` remains useful for exactly reproducible experiments, which is why this module uses it throughout.

---

## 18. Case Study I: the cantilever beam

Now a problem with real engineering content — units, physics, constraints, and an answer you can verify by hand. This section is the heart of the module. Work through it slowly.

```
            │←──────  L = 1 m ──────→│
  wall ▓▓▓  ╔═══════════════════════╗
       ▓▓▓  ║                       ║ ↓ P = 2 kN
       ▓▓▓  ╚═══════════════════════╝
                cross-section: b × h  (the design variables)
```

**Given** (structural steel): $L = 1$ m, $P = 2000$ N, $E = 200$ GPa, $\rho = 7850$ kg/m³, allowable bending stress $\sigma_{\text{allow}} = 300$ MPa.

**Decision variables:** width $b \in [0.01,\, 0.30]$ m, height $h \in [0.01,\, 0.30]$ m.

**Objectives** from Euler–Bernoulli theory, with $I = bh^3/12$:

$$
f_1 = \text{mass} = \rho\, b\, h\, L, \qquad\qquad f_2 = \text{tip deflection} = \frac{PL^3}{3EI} = \frac{4PL^3}{E\,b\,h^3}.
$$

A big section is stiff but heavy; a small one is light but floppy. A genuine conflict.

**Constraints.**

1. Bending stress at the wall within allowable: $\sigma = PL(h/2)/I \le \sigma_{\text{allow}}$.
2. Aspect-ratio limit $h \le 10b$ (a crude proxy for lateral-torsional stability of tall thin sections).

Both in $\le 0$ form, dimensionless and $O(1)$ as Section 15 demands:

$$
g_1 = \frac{\sigma}{\sigma_{\text{allow}}} - 1 = \frac{6PL}{\sigma_{\text{allow}}\,b\,h^2} - 1 \le 0,
\qquad
g_2 = \frac{h}{10\,b} - 1 \le 0 .
$$

### 18.1 The complete script

```python
import numpy as np
from pymoo.core.problem import ElementwiseProblem
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize

L, P, E, RHO, SIG = 1.0, 2000.0, 200e9, 7850.0, 300e6
BL, BU, HL, HU = 0.01, 0.30, 0.01, 0.30

class CantileverBeam(ElementwiseProblem):
    def __init__(self, **kwargs):
        super().__init__(n_var=2, n_obj=2, n_ieq_constr=2,
                         xl=np.array([BL, HL]), xu=np.array([BU, HU]), **kwargs)

    def _evaluate(self, x, out, *args, **kwargs):
        b, h = x
        I = b * h**3 / 12.0
        out["F"] = [RHO * b * h * L,                       # mass          [kg]
                    P * L**3 / (3 * E * I)]                # deflection    [m]
        out["G"] = [P * L * (h / 2) / I / SIG - 1.0,       # g1 <= 0
                    h / (10.0 * b) - 1.0]                  # g2 <= 0

res = minimize(CantileverBeam(), NSGA2(pop_size=100), ("n_gen", 200),
               seed=1, verbose=False)
print(len(res.F), "feasible non-dominated designs;  max CV =", res.CV.max())
```

Output: `100 feasible non-dominated designs;  max CV = 0.0`.

The extreme designs (printed by `scripts/fig04_beam.py`):

```
lightest  b= 1.00 cm  h= 6.33 cm  mass=   4.97 kg  defl= 15.78808 mm  sigma/sigma_allow=0.9990
stiffest  b=30.00 cm  h=30.00 cm  mass= 706.50 kg  defl=  0.00494 mm  sigma/sigma_allow=0.0015
```

A trade-off spanning **142× in mass and 3 200× in deflection**. Every point between is a defensible design; which one you build depends on requirements the optimizer cannot know. Producing this entire menu in one run, rather than one point per guessed weight, is the practical payoff of Part III.

Note the last column: at the lightest design the stress ratio is 0.9990 — the stress constraint is **active**, right at the limit. Remember that; it is about to matter a great deal.

### 18.2 Deriving the true Pareto set analytically

Here is where this case study earns its place. We can solve this problem *by hand* and then use the answer to audit the optimizer. Do the derivation before reading the result.

Fix the mass at $m = \rho b h L$, so $b = m/(\rho h L)$. Substitute into the deflection:

$$
\delta = \frac{4PL^3}{E\,b\,h^3} = \frac{4PL^3}{E\,h^3}\cdot\frac{\rho h L}{m} = \frac{4PL^4\rho}{E\,m\,h^{2}} \;\propto\; \frac{1}{h^{2}} \quad\text{at fixed mass.}
$$

**Taller is always stiffer at equal mass.** ($I \propto h^3$ while mass $\propto h$: height buys stiffness cubically and costs mass only linearly. This asymmetry is why I-beams exist.) So every Pareto-optimal design makes $h$ **as large as the constraints permit**, and the true Pareto set is defined by

$$
h^\ast(m) = \min\Big(\underbrace{\sqrt{\tfrac{10\,m}{\rho L}}}_{\text{from } h \le 10b},\ \ \underbrace{h_U}_{\text{box bound}},\ \ \underbrace{\tfrac{m}{b_L\,\rho L}}_{\text{from } b \ge b_L}\Big).
$$

That third term is the one that is easy to forget. **The lower bound on $b$ is a constraint too.** For light designs, $b$ cannot shrink below 1 cm, so $h$ cannot grow along $h = 10b$; it is capped by the mass itself. Working out which term is smallest on which interval:

| Branch | Active limit | Locus | Mass range |
|---|---|---|---|
| **1** | $b \ge b_L$ (lower bound), cut off below by $g_1$ | $b = 1$ cm, $h \in [6.32,\ 10]$ cm | 4.97 → 7.85 kg |
| **2** | $g_2$: aspect ratio | $h = 10b$, $b \in [1,\ 3]$ cm | 7.85 → 70.65 kg |
| **3** | $h \le h_U$ (box bound) | $h = 30$ cm, $b \in [3,\ 30]$ cm | 70.65 → 706.5 kg |

The branch boundaries follow from equating the terms: $\sqrt{10m/\rho L} = m/(b_L\rho L)$ gives $m = 10 b_L^2 \rho L = 7.85$ kg, and $\sqrt{10m/\rho L} = h_U$ gives $m = \rho h_U^2 L/10 = 70.65$ kg. The low-mass end of branch 1 is set by the stress constraint: at $b = b_L$, $g_1 = 0$ gives $h = \sqrt{6PL/(\sigma_{\text{allow}} b_L)} = 6.32$ cm, hence $m_{\min} = 4.97$ kg — exactly the lightest design the optimizer found.

`scripts/fig04_beam.py` verifies all of this against an independent brute-force search over a $1500\times1500$ grid (3515 non-dominated grid designs), so the analytical curve is not taken on trust.

### 18.3 Comparing the optimizer to the truth

![Beam results](figures/fig_beam_results.png)

*Figure 18.1 — Left: the mass–deflection front against the brute-force reference, **on log–log axes**. Right: the designs against all three analytical branches, coloured by mass. Red crosses mark designs more than 2 mm from the true Pareto set.*
*(`scripts/fig04_beam.py`.)*

Measured agreement:

```
NSGA-II designs within 2 mm of the analytic set: 83 / 100
  -> nearest branch 1 (b=b_L): 39 | branch 2 (h=10b): 9 | branch 3 (h=h_U): 35
distance to analytic set [mm]: median 0.130  90th pct 4.40  max 24.49
within 0.5 mm: 75   beyond 5 mm: 9   (the stragglers sit at b = [1.9 1.9 3.1 3.1 3.4 3.5 3.9 5.1 9.5] cm)
```

Three lessons, in increasing order of importance.

**(a) The engineering insight lives in decision space.** The optimal designs are not scattered; they organize onto three lines, each one an active constraint. The optimizer has rediscovered a design principle — *make the section as tall as the rules allow* — and told you *which rule binds where*. That statement is worth more to a designer than any single point on the front, and you would never see it by looking at objective space alone. **Always plot both spaces.**

**(b) Beware the incomplete "theory" curve — this is the trap.** A very natural first attempt at the analytical answer is $h = \min(10b,\ h_U)$: light designs ride the aspect-ratio limit, heavy ones the height bound. It looks right, it is what the physics argument seems to give, and it accounts for branches 2 and 3.

But it **omits branch 1 entirely** — and branch 1 holds **39 of the 100 returned designs**, the dense purple column in the right panel. If you plot the incomplete curve and see 39 designs sitting off it, you face a fork:

- *Wrong turn:* "the optimizer's decision-space convergence is fuzzy; those points are just under-converged." This sounds sophisticated, is superficially plausible, and is **false**. It also permanently blinds you to the fact that your model of the problem was incomplete.
- *Right turn:* "39 designs disagree with my theory in a *structured* way — they form a straight vertical line at exactly $b = b_L$. A structured disagreement is a missing active constraint, not noise." Then you look, find the bound on $b$, and your understanding of the problem improves.

The general rule, worth writing on the wall: **when computation disagrees with your analysis, look for the missing constraint before you blame the algorithm.** Random scatter is noise; structure is information. Exercise 12 in Part V asks you to walk into this trap deliberately.

**(c) There *is* genuine under-convergence — a smaller effect than it looks, and visible in both spaces.** Nine designs sit more than 5 mm from the true set, all in the region $b \in [1.9,\ 9.5]$ cm — the elbow between branches 1 and 2, where the front is steepest and the mapping from decision to objective space is most compressed. The reason: a design slightly off the optimal locus is only *slightly* worse in one objective, so no population member strictly dominates it, and selection pressure to remove it is weak. Decision-space convergence really is slower than objective-space convergence.

But notice the axes in the left panel. Those same nine designs are visibly **off the front in objective space too** — they only look "crisp" on linear axes, which compress a four-decade range into a corner. **On any objective spanning more than one order of magnitude, plot logarithmically or you will not see your own errors.**

### 18.4 Sanity checks to run every single time

1. `res.CV.max() == 0` — pymoo returns only feasible designs for a constrained problem, but check anyway; if it is nonzero, *no* feasible design was found and everything downstream is meaningless.
2. Verify the extremes by hand. The lightest design should have an active constraint (it does: $\sigma/\sigma_{\text{allow}} = 0.9990$). If your lightest design has no active constraint, your bounds are doing the work and you should ask whether they are physically justified.
3. Compare front endpoints against **single-objective** runs. If minimizing mass alone beats the lightest point on your front, the front is under-converged at that end.
4. Check units. Keep strict SI internally; convert only for plotting. Every unit conversion inside `_evaluate` is a future bug.
5. Plot both spaces, with log axes where ranges are wide.

---

## 19. Validating your pipeline on benchmarks

Before trusting a stochastic algorithm on your real problem — where the true front is unknown — validate the *whole pipeline* (problem class, algorithm settings, plotting, indicators) on problems whose answers are known. pymoo ships the standard suites.

### 19.1 Unconstrained: the ZDT family

```python
from pymoo.problems import get_problem
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.indicators.igd_plus import IGDPlus

problem = get_problem("zdt1")                        # 30 variables, known front
res = minimize(problem, NSGA2(pop_size=100), ("n_gen", 200), seed=1, verbose=False)
print("IGD+ =", IGDPlus(problem.pareto_front())(res.F))
```

![ZDT 1, 2, 3](figures/fig_zdt123.png)

*Figure 19.1 — Identical settings, three difficulties. **ZDT1** convex front, IGD$^+$ = 0.0046. **ZDT2** non-convex front, IGD$^+$ = 0.0046 — covered just as easily by NSGA-II, where Section 8.2 showed the weighted sum finds only its two endpoints. **ZDT3** disconnected front in five pieces, IGD$^+$ = 0.0022 — all five populated in one run, which no sequence of scalarized runs achieves without knowing the pieces in advance.*
*(`scripts/fig05_benchmarks.py`.)*

### 19.2 Constrained: BNH, TNK, OSY

This step is routinely skipped, and it should not be. Sections 15 and 18 lean hard on constraint handling; you should verify that it works against known answers before trusting it on your own problem.

![Constrained benchmarks](figures/fig_constrained_bench.png)

*Figure 19.2 — Three classic constrained problems, `NSGA2(pop_size=100)`, 300 generations, seed 1. All return `max CV = 0`.*
*(`scripts/fig05_benchmarks.py`.)*

| Problem | difficulty | raw IGD$^+$ | normalized IGD$^+$ | objective ranges |
|---|---|---|---|---|
| BNH | 2 constraints, smooth | 0.178 | **0.0026** | $[136,\ 46]$ |
| TNK | wiggly feasible boundary | 0.0021 | **0.0021** | $[1,\ 1]$ |
| OSY | 6 constraints, front in 5 patches | 0.414 | **0.0032** | $[202,\ 71]$ |

Read that table carefully, because it is the cleanest demonstration in this module of a rule you are about to meet formally. The raw IGD$^+$ values suggest BNH and OSY were solved 80–200 times *worse* than TNK. They were not. All three are solved to essentially the same quality — the raw numbers differ only because BNH and OSY have objectives spanning hundreds of units while TNK's span one. **Indicator values on unnormalized objectives are not comparable across problems, and are barely meaningful within one.**

### 19.3 What passing looks like

If your pipeline reproduces Figures 19.1 and 19.2, your tooling is sound: any subsequent trouble on your real problem is about the *problem* — formulation, scaling, conflict, budget — not the plumbing. This is the cheapest insurance available in this subject, and it takes about two minutes to run.

---

## 20. Measuring quality: performance indicators

"The front looks good" is not a number, does not survive a design review, and cannot be plotted against budget. Indicators quantify front quality. There are two situations.

### 20.1 When the true front is known (benchmarks)

- **GD** (generational distance): average distance from each *obtained* point to the nearest *true-front* point. Measures convergence only.
- **IGD** (inverted generational distance): average distance from each *true-front* point to the nearest *obtained* point. To score well you must be close to **and** cover the whole front.

Both have a defect that is not widely enough known, and it matters enough to demonstrate.

### 20.2 Pareto compliance, and why to prefer IGD$^+$

An indicator is **Pareto compliant** if, whenever set $A$ dominates set $B$, the indicator ranks $A$ at least as good as $B$. That is the minimum you should demand — an indicator that can prefer a *dominated* set is worse than useless, because it will make you choose the wrong algorithm. **GD and IGD are not Pareto compliant.** Hypervolume is. IGD$^+$ and GD$^+$ (Ishibuchi et al., 2015) are *weakly* compliant, which is enough in practice.

Here is a minimal counterexample, computed in `scripts/fig06_indicators.py`. Reference front: the line $f_1+f_2 = 1$, sampled at 101 points. Two single-point approximation sets:

$$A = \{(0.20,\ 0.60)\}, \qquad B = \{(0.30,\ 0.70)\}.$$

$A$ dominates $B$ outright — better in both objectives. Yet:

| indicator | $A$ | $B$ | verdict |
|---|---|---|---|
| GD | 0.1414 | **0.0000** | **wrong** — scores the dominated set as *perfect* |
| IGD | 0.4514 | **0.4131** | **wrong** — prefers the dominated set |
| IGD$^+$ | **0.2020** | 0.2921 | correct |

![IGD compliance](figures/fig_igd_compliance.png)

*Figure 20.1 — Why plain IGD fails. Distance to a reference point is measured *geometrically*, ignoring dominance. The far corner of $R$ at $(1,0)$ happens to be closer to $B$ than to $A$, and with enough reference points weighted that way, $B$ wins. IGD$^+$ fixes this by measuring only the dominance-relevant components of the distance: $d^+ = \sqrt{\sum_m \max(0,\, a_m - r_m)^2}$.*

GD's failure is even more striking: $B$ happens to coincide exactly with one reference point, so GD scores it $0.0000$ — a flawless result for a dominated set. GD can be gamed by returning a single well-placed point.

**Practical rule: use IGD$^+$ (and GD$^+$ if you specifically want convergence alone), never plain IGD or GD.** pymoo ships both:

```python
from pymoo.indicators.igd_plus import IGDPlus
from pymoo.indicators.gd_plus  import GDPlus
```

### 20.3 When the true front is unknown (your real problem)

**Hypervolume (HV)** is the area (volume, for $M\ge3$) of objective space **dominated by your set**, bounded by a fixed **reference point** that every solution dominates.

![Hypervolume](figures/fig_hv_concept.png)

*Figure 20.2 — HV is the shaded staircase: everything beaten by at least one obtained point, capped at $r$. Pushing points toward the ideal grows it (convergence); filling gaps grows it too (diversity). One scalar, both properties, no true front required.*

Choosing the reference point:

- Slightly **worse** than the estimated nadir — a common choice is nadir $\times 1.1$ after normalization.
- **Keep it fixed** across everything you compare. HV values computed with different reference points are incomparable, full stop.
- Not *too* far out, or the constant bulk of the volume swamps the differences you care about.
- Every solution must dominate it, or that solution contributes nothing and is silently ignored.

HV's costs: computation grows quickly with $M$ (exact algorithms are exponential in $M$; pymoo uses an efficient implementation, but expect pain beyond about $M=6$, where you should switch to a Monte-Carlo estimate), and the reference-point choice is a preference statement you should report.

For ZDT1, HV has a closed form you can check against. With $r = (1.1,\,1.1)$ and front $f_2 = 1-\sqrt{f_1}$:

$$
HV_{\max} = \underbrace{\int_0^1 \big(0.1 + \sqrt{f_1}\big)\,\mathrm{d}f_1}_{= 0.1 + 2/3} + \underbrace{0.1 \times 1.1}_{f_1 \in [1,1.1]} = 1.21 - \tfrac13 = 0.8767 .
$$

```python
import numpy as np
from pymoo.indicators.hv import HV

hv = HV(ref_point=np.array([1.1, 1.1]))(res.F)   # ZDT1 lives in [0,1]^2
```

### 20.4 Justifying your budget with a curve

```python
res = minimize(problem, NSGA2(pop_size=100), ("n_gen", 400),
               seed=seed, save_history=True, verbose=False)
hv_ind = HV(ref_point=np.array([1.1, 1.1]))
hv_per_gen = [hv_ind(algo.opt.get("F")) for algo in res.history]
```

![HV convergence](figures/fig_hv_convergence.png)

*Figure 20.3 — ZDT1, 10 seeds. **Left:** HV against evaluations, with the min–max band and the theoretical maximum. **Right:** the same data as the *gap to maximum*, on log–log axes.*
*(`scripts/fig06_indicators.py`.)*

| generation | evaluations | HV median | IQR | gap to max |
|---|---|---|---|---|
| 50 | 5 000 | 0.6586 | 0.0857 | $2.2\times10^{-1}$ |
| 100 | 10 000 | 0.8493 | 0.0059 | $2.7\times10^{-2}$ |
| 200 | 20 000 | 0.8682 | 0.00059 | $8.4\times10^{-3}$ |
| 400 | 40 000 | 0.8705 | 0.00034 | $6.2\times10^{-3}$ |

The left panel answers "was my budget enough?" (plateau reached: yes) and "was it wasted?" (long flat tail: you could have stopped earlier — or let the default termination of Section 17 do it, which fires at generation 275, right at the elbow).

The right panel exists because the left one lies a little. What looks like a hard plateau after 20 000 evaluations is, on a log axis, still improving — the gap shrinks from $8.4\times10^{-3}$ to $6.2\times10^{-3}$ over the next 20 000 evaluations. Whether that matters depends entirely on your engineering tolerance, which is the point: **plot the gap on a log axis and decide deliberately, rather than eyeballing a linear curve and calling it converged.**

`save_history=True` deep-copies the algorithm state every generation — fine for a study, wasteful in production. Use pymoo's `Callback` to record only what you need.

### 20.5 Reporting results honestly: statistics, not anecdotes

EAs are stochastic. A single run tells you almost nothing, and comparing two algorithms on one run each is comparing two samples from overlapping distributions.

`scripts/fig06_indicators.py` runs NSGA-II and NSGA-III on ZDT1 with 20 seeds each and a deliberately small budget of 6 000 evaluations:

![Seed statistics](figures/fig_seed_statistics.png)

*Figure 20.4 — 20 seeds each. NSGA-II median HV **0.7302** (IQR 0.0346); NSGA-III median **0.6828** (IQR 0.0452). Mann–Whitney $U$ test: $p < 0.0001$.*

Two things to take away:

1. **The IQRs are about ten times the size of a difference a single run would report.** Any conclusion drawn from one run per algorithm is noise. This is why single-run comparisons in reports and papers should be disbelieved.
2. **With enough seeds, the difference here is real and significant**: NSGA-II beats NSGA-III on this bi-objective problem at this budget. That is expected — NSGA-III's reference-direction machinery is overhead you pay for and do not need at $M=2$. Do not read this as "NSGA-III is worse"; read it as "match the algorithm to $M$" (Section 22 shows the same comparison at $M=5$, where the result reverses dramatically).

**The reporting standard**: at least 10 seeds (20 is better), report **median and IQR** rather than mean and standard deviation (indicator distributions are skewed), state the budget in *evaluations*, state the reference point for HV, and use a rank-based test (Mann–Whitney $U$ for two algorithms, Kruskal–Wallis then pairwise for more) rather than a $t$-test.

### 20.6 The rule that prevents silent nonsense

**Compute all indicators on normalized objectives.** ZDT problems are pre-normalized to $[0,1]$, so it is easy to forget. Your beam problem — kilograms against metres — is not, and an unnormalized HV there would measure essentially only the mass axis, since the deflection axis contributes a factor of $10^{-4}$ to every volume. Section 19.2's table quantifies exactly this effect on real benchmarks.

---

## 21. From a front to a decision

A Pareto front cannot be manufactured. Eventually someone builds **one** beam. This step is **multi-criteria decision making** (MCDM), and it is the legitimate place where human preference enters an a posteriori workflow.

### 21.1 Step zero — normalize

Every method below compares objectives against each other, so map the front to $[0,1]$ per objective first, using ideal/nadir estimates from the obtained front:

```python
F = res.F                              # the beam front from Section 18
ideal, nadir = F.min(axis=0), F.max(axis=0)
nF = (F - ideal) / (nadir - ideal)
```

Keep Section 4's warning in mind. This is an estimate, and Section 21.5 shows how much rides on it.

### 21.2 Method A — pseudo-weights

The pseudo-weight of objective $m$ at a front point measures how close that point sits to $f_m$'s best value relative to the others, producing an intuitive reading like "this design is 70% about lightness, 30% about stiffness". Given target weights, pick the point whose pseudo-weights match best.

```python
import numpy as np
from pymoo.mcdm.pseudo_weights import PseudoWeights

weights = np.array([0.7, 0.3])          # mass matters 70/30 over deflection
i = PseudoWeights(weights).do(nF)
```

### 21.3 Method B — ASF

Pick the front point closest to the ideal in a weighted max sense. This is the achievement scalarizing function of Section 9, and it is used here rather than a weighted sum precisely because it **can select points in non-convex regions** — a weighted sum could only ever pick a vertex of the convex hull of your front, which for a decision rule is unacceptable.

```python
from pymoo.decomposition.asf import ASF

i = ASF()(nF, 1.0 / weights).argmin()   # remember: pymoo's ASF divides by weights
```

### 21.4 Methods C and D — two things that are often conflated

These two are frequently presented as the same method under the name "knee point". They are not, and keeping them apart will save you an embarrassing conversation.

**C. Compromise programming** — the front point closest to the ideal in the normalized $L_p$ norm (usually $p=2$):

```python
i = np.linalg.norm(nF, axis=1).argmin()
```

This is often advertised as "no weights needed." That is **false**. Taking an unweighted $L_2$ norm of normalized objectives *is* an equal-weights scalarization; the preference has not gone away, it has been hidden in the choice of norm and the choice of normalization. It belongs to the "no-preference" family of Section 7 — a canonical compromise imposed by the method, not an absence of preference.

**D. A knee point** — the point of maximum *bend*, where moving away in either direction buys little in one objective at a large cost in the other. A standard construction: take the chord joining the two extreme points of the normalized front and find the point with maximum perpendicular distance from it, on the side toward the ideal. pymoo also offers a trade-off-based detector:

```python
from pymoo.mcdm.high_tradeoff import HighTradeoffPoints
candidates = HighTradeoffPoints().do(nF)      # may return several, or none
```

A knee is the most *persuasive* pick in a design review, because it is the point where the argument "spend a bit more and get a lot" stops being true. Note it can be **empty** — a front with uniform curvature has no knee, and a method that always returns one is not detecting anything.

### 21.5 What they actually choose — and why the scaling matters more than the method

Running all four on the Section 18 front (`scripts/fig07_mcdm.py`, seed 1):

| Method | $b$ [cm] | $h$ [cm] | mass [kg] | deflection [mm] |
|---|---|---|---|---|
| Pseudo-weights (0.7, 0.3) | 1.00 | 7.57 | **5.95** | 9.21 |
| ASF (0.7, 0.3) | 1.93 | 13.59 | **20.60** | 0.83 |
| Compromise programming ($L_2$) | 1.72 | 16.92 | **22.83** | 0.48 |
| Knee (max bend from the chord) | 1.72 | 16.92 | **22.83** | 0.48 |

`HighTradeoffPoints` returns three candidates: 22.8, 44.5, and 56.2 kg.

![MCDM choices](figures/fig_mcdm.png)

*Figure 21.1 — Left: the four picks on the front (log–log). The two black circles are the additional `HighTradeoffPoints` candidates. Right: the normalized front with the chord construction.*

**Observation 1: the same "70/30 preference" gives designs a factor of 3.5 apart in mass.** Pseudo-weights and ASF ask genuinely different questions — pseudo-weights: *"which point's position along the front has a 70/30 character?"*; ASF: *"which point is closest to the ideal when deviations in mass are penalized more heavily?"* — and on a front spanning four decades in deflection, different questions get very different answers. Neither is wrong. But **stating "(0.7, 0.3)" does not identify a design until you also name the method that interprets it.** Always report both.

**Observation 2: the knee and the compromise point agree here — and that agreement is an artifact.** Look at the right panel of Figure 21.1. Linear min–max normalization applied to a front spanning four decades collapses it into an **L-shape** hugging the axes. On an L-shaped front, the corner is trivially both the maximum-bend point and the closest point to the ideal. The agreement is telling you about your normalization, not about beams.

Prove it by changing the scaling — nothing else — and re-running the same "closest to the ideal" rule:

| Normalization used | "Closest to the ideal" picks |
|---|---|
| mass, deflection (both linear) | **22.8 kg** |
| mass, $\log_{10}$ deflection | **120.9 kg** |
| $\log_{10}$ mass, $\log_{10}$ deflection | **60.9 kg** |

![MCDM scaling sensitivity](figures/fig_mcdm_scaling.png)

*Figure 21.2 — One rule, three defensible scalings, three designs spanning a factor of 5 in mass. Every one of these is a "no-preference, weight-free" answer.*

Which scaling is right? That depends on whether a doubling of deflection means the same thing to you at 0.5 mm as at 5 mm. If it does, use linear. If deflection matters proportionally (as it often does for stiffness specifications), use logarithmic. **This is an engineering judgement, and it is a larger lever on the outcome than the choice of decision method.** A method that hides it is not saving you from a decision; it is making the decision for you, silently.

### 21.6 What to actually deliver

1. **A shortlist, not a point.** The knee, the two extremes, and one or two intermediates.
2. **The plot.** Figure 21.1's left panel — showing exactly what each kilogram buys in deflection — is a far better meeting artifact than "the optimizer said 22.8".
3. **The decision-space structure.** "Every optimal design is as tall as the rules allow, and here is which rule binds where" (Section 18.3) is often the most valuable single sentence you will produce.
4. **Your method, weights, normalization, and reference point, all named.** If someone cannot reproduce your recommendation from your report, you have not made a recommendation.
5. **Run more than one method.** Agreement builds confidence; disagreement tells you the preference statement is doing more work than it appears to, and is worth a conversation with the stakeholder rather than a silent choice by you.

---
## 22. Four objectives and beyond

Everything so far works unchanged at $M = 3$: NSGA-II still functions, and 3-D scatter or parallel-coordinate plots still readable. At $M \ge 4$ — the **many-objective** regime — two things degrade, and one of them is fatal.

### 22.1 Dominance loses its teeth — measured, not asserted

To dominate, a design must be no worse in **every** objective. As $M$ grows, that becomes a vanishingly unlikely event: almost any pair of designs is mutually non-dominated, because each is better somewhere. Rank 1 swallows the whole population, and NSGA-II's convergence pressure — which is *entirely* driven by rank differences — collapses to nothing.

You do not have to take this on faith. `scripts/fig08_manyobj.py` generates random populations of 100 designs in $[0,1]^M$ and measures the fraction in rank 1, averaged over 30 repetitions:

| $M$ | 2 | 3 | 5 | 8 | 10 | 15 |
|---|---|---|---|---|---|---|
| % of population in rank 1 | 5% | 16% | 47% | 82% | 94% | **100%** |

![Dominance breakdown](figures/fig_dominance_breakdown.png)

*Figure 22.1 — Left: the fraction of a random population that is non-dominated. Right: the number of dominance ranks available, which is what selection has to work with. By $M=15$ there is exactly one rank, and dominance-based selection is doing literally nothing.*

The intuition is geometric: "dominated by A" is one orthant out of $2^M$ (Figure 3.1). At $M=2$ that is a quarter of the space; at $M=10$ it is one part in 1024.

The second degradation is that **crowding distance becomes a poor diversity measure** in high dimensions — distances concentrate, so all crowding values become similar — and plain scatter plots stop working entirely.

### 22.2 The remedy: NSGA-III and reference directions

**NSGA-III** (Deb & Jain, 2014) keeps non-dominated sorting but replaces crowding distance with a set of **well-spread reference directions** in objective space. The survival step associates each population member with its nearest direction and then balances the count across directions, restoring both diversity control *and* selection pressure — because "which direction are you the best representative of?" remains a discriminating question even when everyone is rank 1.

```python
from pymoo.algorithms.moo.nsga3 import NSGA3
from pymoo.util.ref_dirs import get_reference_directions

ref_dirs = get_reference_directions("das-dennis", 3, n_partitions=12)   # 91 directions
algorithm = NSGA3(pop_size=92, ref_dirs=ref_dirs)      # pop_size at or just above the count
```

The Das–Dennis construction gives $\binom{p + M - 1}{M - 1}$ directions for $p$ partitions; $p=12$, $M=3$ gives $\binom{14}{2} = 91$. For $M=5$, $p=6$ gives 210. Note the trap: at fixed $p$, the count grows combinatorially in $M$, so for large $M$ you need the "energy" or multi-layer constructions instead of raising $p$.

### 22.3 Does it actually matter? Yes, dramatically

DTLZ2 with $M=5$, same budget (212 population, 400 generations) for both algorithms. DTLZ2's true front is the unit-sphere octant, so $\|\mathbf{F}\| = 1$ is an exact physical check available for free:

| | IGD$^+$ | $\|\mathbf{F}\|$ (true value 1.00) |
|---|---|---|
| NSGA-II | 0.3054 | $1.526 \pm 0.324$ |
| NSGA-III | **0.0019** | $\mathbf{1.001 \pm 0.002}$ |

![NSGA-III vs NSGA-II at M=5](figures/fig_nsga3_vs_nsga2_m5.png)

*Figure 22.2 — Parallel coordinate plots of the two results. NSGA-II has drifted 53% off the true front and its designs are scattered; NSGA-III sits on it to within 0.2%.*
*(`scripts/fig08_manyobj.py`.)*

A factor of 160 in IGD$^+$, from changing one algorithm. Compare this with Section 20.5, where NSGA-II *beat* NSGA-III at $M=2$. The lesson is not that one algorithm is better; it is that **the choice of algorithm is determined by $M$**, and getting it wrong costs you two orders of magnitude.

### 22.4 Reading fronts you cannot plot

At $M=3$ a scatter plot still works, and the front is a **surface**, not a curve:

![DTLZ2 with NSGA-III](figures/fig_dtlz2.png)

*Figure 22.3 — DTLZ2 at $M=3$, NSGA-III, IGD$^+$ = 0.0004 with 91 designs. Left: the unit-sphere octant, tiled evenly thanks to the reference directions. Right: the identical data as a **parallel coordinate plot** (PCP) — each design is one polyline across the objective axes.*

Beyond $M=3$ you need other views. pymoo provides several; each answers a different question.

| Plot | Reads | Best for |
|---|---|---|
| **PCP** (`pymoo.visualization.pcp`) | one polyline per design | spotting conflict — heavy crossing between two axes means those two objectives fight |
| **Petal** (`...petal`) | one "flower" per design | presenting a *shortlist* of 3–6 designs to a non-specialist |
| **Radar** (`...radar`) | overlaid polygons | comparing a handful of designs across all objectives at once |
| **Heatmap** (`...heatmap`) | designs $\times$ objectives grid, sortable | finding structure in a whole front of 100+ designs |
| **Star coordinates** (`...star_coordinate`) | projection to 2-D | a quick overall shape check |

![Petal](figures/fig_viz_petal.png)
![Radar](figures/fig_viz_radar.png)
![Heatmap](figures/fig_viz_heatmap.png)

*Figures 22.4–22.6 — Five representative designs from the $M=5$ DTLZ2 front, shown three ways. Petal plots are the right choice when you have to put a shortlist in front of a manager; heatmaps are the right choice when you are hunting for structure yourself.*

All three take a `bounds` argument; **always pass it**, computed from the whole front, or each plot normalizes independently and the designs become incomparable.

### 22.5 The pragmatic move you should try first

Before reaching for many-objective machinery, ask whether some of your "objectives" are **requirements in disguise**.

If vibration merely has to stay below 50 Hz, it is a **constraint**, not an objective. If cost merely has to fit a budget, same. An objective is something you would genuinely trade away — where, if you could have a bit more, you would want it, indefinitely.

Every objective you legitimately demote to a constraint makes the problem exponentially friendlier (Figure 22.1 is exponential in $M$) *and* makes the final decision clearer, because you have one fewer axis to explain. In practice, problems presented as having seven objectives usually have two or three, plus five requirements that someone wrote in the wrong column.

---

## 23. Case Study II: the compact beam, three objectives

DTLZ2 is abstract. Here is a tri-objective problem with physical content, built by extending Section 18: the beam must now fit inside a **compact housing**, so its section height is a third objective rather than a free by-product.

$$
f_1 = \text{mass},\qquad f_2 = \text{tip deflection},\qquad f_3 = h \ \ \text{(envelope height, minimized)}
$$

with the same two constraints. This attacks exactly the design principle Section 18 discovered — *make it as tall as allowed* — so now **height buys stiffness but costs envelope**: a genuine three-way conflict. Only the marked lines differ from the bi-objective script:

```python
from pymoo.algorithms.moo.nsga3 import NSGA3                      # changed
from pymoo.util.ref_dirs import get_reference_directions           # changed

class CompactBeam(ElementwiseProblem):
    def __init__(self, **kw):
        super().__init__(n_var=2, n_obj=3, n_ieq_constr=2,          # n_obj=3
                         xl=np.array([BL, HL]), xu=np.array([BU, HU]), **kw)

    def _evaluate(self, x, out, *a, **k):
        b, h = x
        I = b * h**3 / 12.0
        out["F"] = [RHO * b * h * L,
                    P * L**3 / (3 * E * I),
                    h]                                             # third objective
        out["G"] = [P * L * (h / 2) / I / SIG - 1.0,
                    h / (10.0 * b) - 1.0]

ref_dirs = get_reference_directions("das-dennis", 3, n_partitions=12)
res = minimize(CompactBeam(), NSGA3(pop_size=92, ref_dirs=ref_dirs),
               ("n_gen", 300), seed=1, verbose=False)
```

Result: **73 designs**, `max CV = 0`.

![Tri-objective beam](figures/fig_tribeam.png)

*Figure 23.1 — Left: the front is now a **surface** in 3-D (deflection plotted logarithmically). Middle: the PCP view — the heavy crossing between the deflection and height axes is the new conflict, made visible. Right: the correlation matrix of a **badly formulated** version, discussed below.*
*(`scripts/fig09_tribeam.py`.)*

### 23.1 Three observations worth internalizing

**The front's dimension grew.** Bi-objective fronts are curves; tri-objective fronts are surfaces; $M$-objective fronts are $(M-1)$-dimensional manifolds. Covering a surface needs many more points than covering a curve — this is why the reference-direction machinery starts earning its keep already at $M=3$, and why "just use more generations" does not substitute for it.

**73 designs from 91 directions is not a bug.** Not every reference direction gets filled. With only two decision variables, the attainable surface is limited, and some directions point into regions with no feasible optimal design. **Unfilled directions are diagnostic information**: they tell you which combinations of goals are physically unreachable, which is often exactly what a stakeholder wanted to know.

**Check that your objectives actually conflict.** This third objective works — the correlation matrix of the good formulation is mild:

$$
\text{corr}(\mathbf{F}) = \begin{pmatrix} 1 & -0.33 & 0.45 \\ -0.33 & 1 & -0.52 \\ 0.45 & -0.52 & 1 \end{pmatrix}
$$

Now consider a plausible-looking alternative third objective: **maximize specific stiffness** (stiffness per unit mass). It sounds like a fine engineering goal. It is a near-restatement of "low deflection at low mass", i.e. of objectives 1 and 2 together. The script runs it, and the symptoms are unmistakable:

- $\text{corr}(f_2, f_3) = \mathbf{+0.745}$ — strongly correlated with an existing objective;
- the run returns **19 designs instead of 73** — the front has collapsed toward a curve, because a three-objective problem in disguise is really two-objective and the reference directions have nothing to spread across.

**The diagnostic to run every time you add an objective:**

```python
print(np.corrcoef(res.F.T))          # look for |corr| near 1 off the diagonal
print(len(res.F), "of", len(ref_dirs), "directions filled")
```

If two objectives correlate above roughly $|0.8|$, or the number of returned designs is far below the number of directions, you have a redundant objective. **Merge it, demote it to a constraint, or drop it** — this is problem *formulation*, and no algorithm can repair a bad formulation. Choosing genuinely conflicting objectives is your job, not the optimizer's.

---

## 24. Discrete and mixed variables

Real engineering variables are frequently not continuous. You buy sections from a catalogue, bolts come in integer counts, and material is a choice from a short list. This case is arguably more common than the all-continuous one, and it is easy in pymoo.

```python
from pymoo.core.mixed import MixedVariableGA
from pymoo.core.variable import Real, Integer, Choice, Binary
from pymoo.algorithms.moo.nsga2 import RankAndCrowding

WIDTHS_MM = [10, 12, 16, 20, 25, 32, 40, 50, 63, 80, 100, 125, 160, 200, 250, 300]
MATERIALS = {"steel":     (200e9, 7850.0, 300e6),      # (E, rho, sigma_allow)
             "aluminium": ( 70e9, 2700.0, 150e6)}

class CatalogueBeam(ElementwiseProblem):
    def __init__(self, **kw):
        super().__init__(vars={"b_mm": Choice(options=WIDTHS_MM),   # from a catalogue
                               "h_mm": Integer(bounds=(10, 300)),   # whole millimetres
                               "mat":  Choice(options=list(MATERIALS))},
                         n_obj=2, n_ieq_constr=2, **kw)

    def _evaluate(self, x, out, *a, **k):
        b, h = x["b_mm"] / 1000.0, x["h_mm"] / 1000.0
        E, rho, sa = MATERIALS[x["mat"]]
        I = b * h**3 / 12.0
        out["F"] = [rho * b * h * L, P * L**3 / (3 * E * I)]
        out["G"] = [P * L * (h / 2) / I / sa - 1.0, h / (10.0 * b) - 1.0]

res = minimize(CatalogueBeam(),
               MixedVariableGA(pop_size=100, survival=RankAndCrowding()),
               ("n_gen", 200), seed=1, verbose=False)
```

Note the two changes from the continuous case: variables are declared as a **dict of typed variables** (with no `n_var`, `xl`, `xu`), and the algorithm is `MixedVariableGA` with `survival=RankAndCrowding()` — that survival operator is what makes it multi-objective; without it you get a single-objective GA.

Result: 100 designs, `max CV = 0`, with the material split **25 steel / 75 aluminium**.

![Mixed-variable beam](figures/fig_mixed_variable.png)

*Figure 24.1 — Left: the catalogue front, coloured by material, against the (unbuildable) continuous front. Right: what happens when you optimize continuously and round afterwards.*
*(`scripts/fig10_mixed_and_seeding.py`.)*

### 24.1 Why both materials survive — a free engineering insight

At first glance a mixed steel/aluminium front looks like a bug. It is not, and the reason is instructive. What matters for a mass-versus-deflection trade-off is **specific stiffness** $E/\rho$:

| | $E/\rho$ [MJ/kg] | $\sigma_{\text{allow}}/\rho$ [kJ/kg] |
|---|---|---|
| steel | 25.5 | 38.2 |
| aluminium | 25.9 | 55.6 |

Steel and aluminium have **almost identical specific stiffness** — a fact every materials course teaches and every student forgets. So neither dominates on the mass–deflection trade-off, and the optimizer correctly keeps both. Aluminium wins the majority of the front because its higher specific *strength* lets it survive the stress constraint at lower mass. The optimizer just rediscovered the content of an Ashby chart, from nothing but $f$ and $g$.

### 24.2 Never round a continuous solution by hand

The tempting shortcut is to optimize continuously and then snap each variable to the nearest catalogue value. Measured on this problem:

```
rounding the continuous solution: 9 of 100 designs became INFEASIBLE (9%)
  worst violation after rounding: 0.0920  (i.e. 9.20% over the stress limit)
```

Nine per cent of your recommended designs are **over the allowable stress**, one of them by more than 9%. And this is a benign case — the rounding steps are small and the constraints are smooth. On problems where the active constraint is steep in the rounded variable, the failure rate is far higher.

The reason is structural: the continuous optimum sits *on* the constraint boundary (that is what "optimal" means here), so any perturbation has roughly a 50% chance of moving outward. Rounding is a perturbation applied after all feasibility information has been discarded. **Declare your variables with their true types and let the algorithm respect them.**

---

## 25. Making it affordable: seeding, vectorizing, parallelizing

Real budgets are dominated by evaluation cost. Four levers, in the order you should reach for them.

### 25.1 Lever 0 — seed the initial population with what you already know

You almost always have a baseline design. pymoo will happily start from it:

```python
X0 = np.random.rand(pop_size, n_var) * (xu - xl) + xl
X0[:3] = known_good_designs                      # your existing designs
res = minimize(problem, NSGA2(pop_size=pop_size, sampling=X0), ("n_gen", 60), seed=1)
```

An `(pop_size, n_var)` array works directly as `sampling`. (You can also pass a `Population` object, or an operator like `LHS()` for Latin hypercube sampling instead of pymoo's default random sampling.)

Does it help? **It depends, and you should measure rather than assume.** `scripts/fig10_mixed_and_seeding.py` runs the experiment twice, 10 seeds each:

![Seeding](figures/fig_seeding.png)

| Problem | random start | seeded | change |
|---|---|---|---|
| Cantilever beam (2 variables), gen 5 | HV 15.771 | 15.805 | +0.2% |
| Cantilever beam, final | HV 15.820 | 15.817 | **−0.0%** |
| ZDT1 (30 variables, 1600 evals), gen 5 | HV **0.000** | 0.779 | — |
| ZDT1, final | HV 0.215 | **0.861** | **+300%** |

On the beam — 2 variables, easy, generous budget — seeding buys **nothing measurable**. On ZDT1 with 30 variables and a deliberately tiny budget, seeding five known-good designs is the difference between a useless result (HV 0.215) and a good one (HV 0.861), and at generation 5 the random-start runs have not yet found a single point that dominates the reference point at all.

So: **seeding matters when the problem is hard relative to the budget, and not otherwise.** That is exactly the regime where expensive simulations live, which is why it is worth knowing.

One caution: seeding a whole population with near-identical good designs destroys initial diversity and can converge prematurely to a fragment of the front. Seed a *few* members (3–5 out of 60 above), keep the rest random.

### 25.2 Lever 1 — vectorized evaluation

If your objectives are NumPy math, subclass `Problem` instead of `ElementwiseProblem`. `_evaluate` then receives the **whole population** as a matrix and returns matrices — one NumPy call per generation instead of `pop_size` Python calls:

```python
from pymoo.core.problem import Problem

class SchafferVectorized(Problem):
    def __init__(self):
        super().__init__(n_var=1, n_obj=2, xl=np.array([-2.0]), xu=np.array([4.0]))

    def _evaluate(self, X, out, *args, **kwargs):        # X: (pop_size, n_var)
        out["F"] = np.column_stack([X[:, 0]**2, (X[:, 0] - 2)**2])
```

This is usually a 10–50× speedup on cheap analytic objectives, and irrelevant when a single evaluation takes a second or more.

### 25.3 Lever 2 — parallel evaluation

If each evaluation is an expensive, independent computation (a simulation call), the population's evaluations are *embarrassingly parallel*:

```python
import multiprocessing
from pymoo.parallelization import StarmapParallelization    # pymoo >= 0.6.2 path

pool   = multiprocessing.Pool(8)
runner = StarmapParallelization(pool.starmap)
problem = CantileverBeam(elementwise_runner=runner)         # rides in via **kwargs
res = minimize(problem, NSGA2(pop_size=100), ("n_gen", 200), seed=1)
pool.close()
```

This works because the class in Section 18 forwards `**kwargs` to `super().__init__` — that is what the habit was for. In pymoo 0.6.1 and earlier the import path was `pymoo.core.problem`; it still works in 0.6.2 but emits a `DeprecationWarning`. pymoo also supports thread pools, `joblib`, and `dask`.

**Honest scaling arithmetic.** The speedup ceiling is the number of workers, but only *within* a generation — generations are inherently sequential. A population of 100 on 8 cores runs about 13 sequential batches per generation, so your wall-clock time is $\lceil 100/8\rceil \times n_{\text{gen}} \times t_{\text{eval}}$, not $100 \times n_{\text{gen}} \times t_{\text{eval}} / 8$. To exploit more cores, increase `pop_size` (which also improves the front, up to a point) rather than expecting more workers to help a small population.

### 25.4 Lever 3 — change paradigm

If a single evaluation takes minutes to hours and your total budget is a few hundred evaluations, **no parallelization scheme saves you**. That regime belongs to **surrogate-assisted / Bayesian multi-objective optimization**: fit a cheap model (Gaussian process, radial basis function) to the evaluations you have, optimize the model, evaluate the most promising candidate, refit, repeat.

Search terms worth knowing: **ParEGO** (Knowles, 2006 — the classic, a Tchebycheff scalarization with randomized weights inside Bayesian optimization), **SMS-EGO**, **qEHVI** (expected hypervolume improvement), and the frameworks **BoTorch** and **Trieste**. pymoo has some surrogate support but this is not its centre of gravity.

Rough guidance on which regime you are in:

| Affordable evaluations | Use |
|---|---|
| $> 10^4$ | NSGA-II / NSGA-III straightforwardly |
| $10^3$–$10^4$ | NSGA-II with a well-chosen `pop_size`, seeded, parallelized |
| $10^2$–$10^3$ | small population, seeded, convergence-based termination; consider surrogates |
| $< 10^2$ | surrogate-assisted / Bayesian, or an interactive method (Section 7) |

### Exercises for Part IV

**E16.** Run the Section 18 script with `pop_size` of 20, 50, 100, and 200 at a **fixed budget of 20 000 evaluations** (so adjust `n_gen` accordingly). Compute HV each time with a fixed reference point. Which population size wins, and why does the trade-off exist?

**E17.** Change the beam's aspect-ratio constraint from $h \le 10b$ to $h \le 4b$. Predict, before running, how the three analytical branches change. Then derive the new branch boundaries and verify against the optimizer.

**E18.** Set the beam's lower bound on $b$ to 0.005 m and re-run. What happens to branch 1? Explain in terms of the $h^\ast(m)$ formula in Section 18.2.

**E19.** Compute HV on the *unnormalized* beam front with reference point $(800, 0.02)$, then again on the normalized front with reference $(1.1, 1.1)$. Explain why the first number tells you almost nothing about deflection.

**E20.** Take the beam front and deliberately delete the 20 lightest designs. Recompute the ideal/nadir estimates and re-run all four MCDM methods. Which recommendations move, and by how much? What does this tell you about reporting a single design?

**E21.** Run NSGA-II on `dtlz2` with `n_obj=5` and 20 seeds; do the same for NSGA-III. Report medians, IQRs, and a Mann–Whitney $p$-value. Compare your conclusion with Section 20.5's result at $M=2$.

**E22.** Add a third objective to the beam that you *expect* to be redundant (e.g. second moment of area $I$, maximized). Run it, compute the correlation matrix and the filled-direction count, and confirm the symptoms described in Section 23.1.

**E23.** Formulate the catalogue beam with `Integer` for `b_mm` over the range 10–300 instead of `Choice` over the catalogue list. Compare the resulting fronts. Which is the correct model of the physical situation, and what does the difference cost you?

**E24.** Estimate the wall-clock time for a 2-objective problem with `pop_size=100`, `n_gen=200`, where one evaluation takes 45 seconds, (a) serial, (b) on 8 cores, (c) on 64 cores. Then say which lever from Section 25 you would actually pull.

---

# Part V — Reference

## 26. Troubleshooting: symptom to cause

The table you will actually use. Symptoms are what you *see*; work down the causes in order.

| Symptom | Most likely causes, in order |
|---|---|
| **"Front" is a single point** | (1) Sign error — you are maximizing one objective by accident. (2) Objectives do not conflict (Section 23.1). (3) One objective is constant over the feasible set. (4) The feasible set is a single point — check `res.CV` and your constraint signs. |
| **"Front" is a thin curve when $M=3$** | Two objectives are near-duplicates: check `np.corrcoef(res.F.T)` for $|corr| > 0.8$. |
| **All designs infeasible (`res.CV.max() > 0`)** | (1) A constraint sign is flipped — you wrote $g \ge 0$. (2) The feasible region is tiny; try `ConstraintsAsObjective` (Section 15) or seed a known feasible design (Section 25.1). (3) Constraints are contradictory. (4) Bounds exclude the feasible region. |
| **One constraint appears to be ignored** | Constraints on wildly different scales; $CV$ is a plain sum (Section 15). Normalize every $g$ to $O(1)$. |
| **Front has an unexpected gap** | (1) The true front is genuinely disconnected (like ZDT3) — plot the true front if you have one. (2) The gap is where a constraint becomes active; check activity along the front. (3) Insufficient budget in a steep region. |
| **Front does not reach the extremes** | Under-convergence at the ends is normal and common. Check by optimizing each objective **alone** and comparing (Section 18.4). If the gap is large, increase budget or seed the single-objective optima. |
| **Designs scatter off a curve I derived analytically** | **Look for a missing active constraint first** (Section 18.3b). Structured scatter = missing branch. Only unstructured scatter is under-convergence. |
| **HV is meaningless / dominated by one axis** | Objectives unnormalized (Section 20.6). Normalize, then choose the reference point. |
| **HV values disagree between two of my runs' reports** | Different reference points. HV is only comparable at a fixed reference point. |
| **Two algorithms rank differently on IGD vs HV** | IGD is not Pareto compliant (Section 20.2). Re-rank with IGD$^+$ and HV; discard the IGD result. |
| **Results change every run** | Normal — EAs are stochastic. Fix `seed=` for development; report median and IQR over $\ge 10$ seeds (Section 20.5). |
| **Rank 1 contains the whole population** | $M$ too large for dominance-based selection (Section 22.1). Switch to NSGA-III / MOEA/D, or demote objectives to constraints. |
| **NSGA-III returns far fewer designs than directions** | Often correct and informative (Section 23.1) — those directions are unattainable. Confirm by checking whether the missing regions are constraint-blocked. |
| **Optimizer exploits a physically silly design** | Your bounds or model permit nonsense (e.g. zero-thickness walls). Optimizers are ruthless: they will find every hole in your model. Tighten bounds, add the missing constraint. |
| **Results look great but the engineer says they are wrong** | Verify `_evaluate` by hand on two or three designs you can compute independently. This finds more bugs than anything else on this list. |
| **`res.F` contains a design I can show is dominated** | Expected: `res.F` is non-dominated *within the final population* only (Section 16.4). Quantify quality with an indicator, not with the fact that the run finished. |
| **`import` fails after a pymoo upgrade** | Check pymoo's "Versions" page. Known move: `StarmapParallelization` from `pymoo.core.problem` to `pymoo.parallelization` in 0.6.2. |

---

## 27. Practical tips and a pre-flight checklist

Ordered roughly by how often each one bites.

**Formulation**

1. **Minimize everything; write constraints as $g \le 0$.** Sign errors are the single most common bug in student code. Symptom: a "front" that is one point or a strange cloud. Check signs before anything else.
2. **Objective or constraint?** Only genuinely negotiable quantities are objectives. Hard requirements — design codes, safety factors, physical limits, budgets — are constraints. Each objective you correctly demote makes the problem exponentially easier (Figure 22.1) and the decision clearer.
3. **Normalize constraints to dimensionless $O(1)$.** $CV$ is a sum; mixed scales silently break constraint handling (Section 15).
4. **Verify that your objectives conflict.** Check `np.corrcoef(res.F.T)`; merge or demote near-duplicates (Section 23.1).
5. **Verify `_evaluate` by hand** on two or three designs you can compute independently, before trusting anything downstream.
6. **Declare variable types honestly.** Integer, choice, and binary variables are supported; never round a continuous result afterwards (Section 24.2).
7. **Sanity-check your bounds.** Optimizers exploit silly bounds ruthlessly. If your best design sits on a bound with no active physical constraint, ask whether that bound is real.

**Running**

8. **Budget = `pop_size` × generations, and evaluations are what cost money.** Starting points: `pop_size` 50–100 for two objectives; grow toward $\ge 10\times$ `n_var` for larger problems; for NSGA-III set it at or just above the reference-direction count.
9. **Justify the budget with a curve, not a feeling.** HV against evaluations (Figure 20.3), and look at the *gap to maximum on a log axis* before declaring convergence.
10. **Fix `seed=` during development; report statistics in results.** $\ge 10$ seeds (20 better), median and IQR, plus a rank-based test (Section 20.5).
11. **Seed the initial population with designs you already trust** when the problem is hard relative to the budget — but keep most of the population random (Section 25.1).
12. **Validate the pipeline on ZDT1–3 and one constrained benchmark** before running your own problem (Section 19). Two minutes, enormous return.

**Interpreting**

13. **The output is an approximation, not a certified front.** `res.F` is non-dominated within the final population only (Section 16.4).
14. **Inspect the Pareto set, not only the front.** Decision-space structure is frequently the most valuable engineering output of the whole exercise (Section 18.3a).
15. **When computation disagrees with your analysis, look for the missing constraint before blaming the algorithm.** Structured disagreement is information (Section 18.3b).
16. **Use log axes on any objective spanning more than a decade,** or you will not see your own errors (Section 18.3c).
17. **Normalize before indicators and before MCDM, always.** Unnormalized, the largest-magnitude objective silently decides everything (Sections 19.2, 20.6).
18. **Use IGD$^+$ / HV, not IGD / GD.** The latter are not Pareto compliant and can rank a dominated set higher (Section 20.2).
19. **State your decision method, weights, *and normalization*.** "(0.7, 0.3)" identifies nothing on its own, and the normalization is a bigger lever than the method (Section 21.5).
20. **Do not over-read tiny differences.** Two designs 0.1% apart on the front are, for engineering purposes, one design measured twice.

**Which algorithm? A defensible default map**

| Situation | Start with |
|---|---|
| 2–3 objectives, generic | **NSGA-II** |
| $\ge 4$ objectives | **NSGA-III** with reference directions (or MOEA/D) |
| Hypervolume quality paramount, $M \le 3$ | SMS-EMOA |
| Preference direction known a priori | R-NSGA-II / R-NSGA-III |
| Mixed / discrete / categorical variables | `MixedVariableGA(survival=RankAndCrowding())` |
| Smooth, convex, low-dimensional, and you want a certificate | classical: ASF or ε-constraint sweep + KKT check (Part II) |
| Very expensive evaluations ($\lesssim$ a few hundred) | surrogate-assisted / Bayesian (Section 25.4) |
| Stakeholder thinks in budgets, needs 3–4 options | ε-constraint (Section 10) |

**Pre-flight checklist for your own problem**

- [ ] All objectives minimized; all constraints in $\le 0$ form; every constraint normalized to $O(1)$?
- [ ] Objectives verified to genuinely conflict (correlation checked)?
- [ ] Variable types declared honestly (integer / choice / real)?
- [ ] Bounds physically justified, not just convenient?
- [ ] `_evaluate` verified by hand on known designs?
- [ ] Pipeline validated on ZDT1–3 **and** one constrained benchmark?
- [ ] Algorithm matched to $M$?
- [ ] Seed fixed; budget justified by an HV-vs-evaluations curve (log gap checked)?
- [ ] Feasibility of returned designs confirmed (`res.CV.max() == 0`)?
- [ ] Both objective **and** decision space plotted, with log axes where needed?
- [ ] Extremes cross-checked against single-objective runs?
- [ ] Indicators computed on normalized objectives, with IGD$^+$/HV and a stated reference point?
- [ ] $\ge 10$ seeds, median and IQR reported?
- [ ] Decision method, weights, **and normalization** named in the report?
- [ ] A shortlist plus the front plot delivered, not a single number?

---

## 28. Summary

1. Real design problems have **conflicting objectives**, so a single optimum does not exist. The answer is the **Pareto front** — the set of trade-offs where no objective can improve without another worsening — whose designs form the **Pareto set**. The optimizer produces the menu; a human chooses from it.
2. **Dominance** is the comparison tool: prefer one design over another only if it is no worse everywhere and strictly better somewhere. Success means a **converged and well-spread** finite approximation. The **nadir** point is the worst value *over the front*, not over the feasible set.
3. The **multi-objective KKT conditions** generalize what you already know: at a Pareto point, objective and active-constraint gradients balance with non-negative multipliers. Those multipliers are the local trade-off — and, like everything else in this subject, they are only interpretable after normalization.
4. Methods differ in **when preference enters**: a priori (weights, budgets), a posteriori (compute the front, then choose), or interactive. Engineering practice defaults to a posteriori.
5. **The weighted sum is provably blind to non-convex front regions** for every choice of weights, and gives no control over spread. **Tchebycheff/ASF, ε-constraint, and NBI do not share the first defect.** Scalarization is not obsolete: it is the right tool for choosing from a front, it powers MOEA/D, and on smooth convex problems it can give a certificate no EA can.
6. **Evolutionary algorithms** evolve a population, delivering a whole front in one gradient-free run, at the price of many evaluations and no optimality proof. **NSGA-II** = non-dominated sorting (convergence) + crowding distance (diversity) + feasibility-first constraints, inside an elitist GA.
7. **Dominance collapses as $M$ grows** — 100% of a random population is rank 1 by $M=15$ — so at $M\ge4$ switch to **NSGA-III** with reference directions. At $M=5$ on DTLZ2 this is a factor of 160 in IGD$^+$; at $M=2$ it is a small *loss*. Match the algorithm to $M$.
8. In **pymoo**: subclass `ElementwiseProblem` (fill `out["F"]`, `out["G"]`, forward `**kwargs`), choose an algorithm, call `minimize()`, validate on benchmarks, and quantify with **HV and IGD$^+$ on normalized objectives**, over $\ge10$ seeds with a rank-based test. `res.F` is non-dominated within the population, never a certified front.
9. **Look at decision space.** "Every optimal design is as tall as the rules allow, and here is which rule binds where" is usually worth more than any single point on the front. And when computation disagrees with your analysis, **hunt the missing active constraint before blaming the algorithm** — structured disagreement is information.
10. Close the loop with **MCDM**, knowing that different methods legitimately pick different designs, that "weight-free" methods hide their preference in the normalization, and that the front itself — showing exactly what each unit of one objective costs in another — is often the most valuable deliverable of all.

---

## 29. Glossary and notation

| Term / symbol | Meaning | Section |
|---|---|---|
| $\mathbf{x}$, decision variables | the $n$ quantities the designer controls | 2 |
| $\Omega$, feasible set | designs satisfying all constraints and bounds | 2 |
| Decision space / objective space | space of designs / space of their performance vectors | 2 |
| $\mathbf{F}(\mathbf{x})$, $M$ | vector of $M$ objectives, all minimized | 2 |
| $g_j \le 0$ / $h_k = 0$ | inequality / equality constraint conventions | 2 |
| Dominance $\mathbf{x}^{(1)} \prec \mathbf{x}^{(2)}$ | no worse in all objectives, strictly better in $\ge 1$ | 3.1 |
| Weak / strict dominance | condition 1 only / strictly better in every objective | 3.1 |
| Mutually non-dominated | neither dominates the other; a genuine trade-off | 3.1 |
| Pareto-optimal | feasible and dominated by no feasible design | 3.3 |
| Weakly Pareto-optimal | nothing is strictly better in *all* objectives | 3.3 |
| Properly Pareto-optimal | Pareto-optimal with bounded trade-off ratios (Geoffrion) | 3.3 |
| Pareto set $P^\ast$ / front $PF^\ast$ | optimal designs / their objective-space image | 3.3 |
| Rank, non-dominated sorting | dominance layers of a population | 3.4 |
| Ideal point $\mathbf{z}^{\text{ideal}}$ | per-objective individual optima; usually unattainable | 4 |
| Nadir point $\mathbf{z}^{\text{nadir}}$ | per-objective worst values **over the Pareto front** | 4 |
| Normalization | mapping objectives to $[0,1]$ via ideal/nadir | 4 |
| Convergence / diversity | closeness to the true front / even coverage along it | 5 |
| $\lambda_m$, $\mu_j$ | KKT multipliers on objectives / constraints | 6 |
| A priori / a posteriori / interactive | when preference is supplied | 7 |
| Scalarization | collapsing $M$ objectives into one scalar problem | 8 |
| Weighted sum | $\sum w_m f_m$; blind to non-convex regions | 8 |
| Weighted Tchebycheff / ASF | $\max_m w_m(f_m - z^{\text{ref}}_m)$, augmented; reaches all of the front | 9 |
| $\varepsilon$-constraint | minimize one objective, budget the rest | 10 |
| NBI / CHIM | normal boundary intersection / convex hull of individual minima | 11 |
| Crowding distance | summed normalized neighbour gaps; NSGA-II's diversity measure | 14.2 |
| SBX, polynomial mutation | standard real-coded crossover / mutation | 14.3 |
| Elitism | parents compete with offspring for survival | 14.3 |
| Constrained domination, $CV$ | feasibility-first comparison; $CV=\sum_j\max(0,g_j)+\sum_k|h_k|$ | 15 |
| `ElementwiseProblem` / `Problem` | pymoo: per-design vs whole-population evaluation | 16.3, 25.2 |
| `res.X` / `res.F` / `res.CV` | designs / objective values / total violations | 16.4 |
| GD / IGD | convergence-only / convergence+diversity distances; **not** Pareto compliant | 20.1 |
| GD$^+$ / IGD$^+$ | dominance-aware versions; weakly Pareto compliant — prefer these | 20.2 |
| Pareto compliance | if $A$ dominates $B$, the indicator must not prefer $B$ | 20.2 |
| Hypervolume (HV), reference point | dominated volume up to a fixed reference point | 20.3 |
| MCDM | selecting one design from the front | 21 |
| Pseudo-weights / ASF / compromise programming / knee | four selection rules | 21.2–21.4 |
| Many-objective | $M \ge 4$; dominance-based selection degrades | 22.1 |
| Reference directions, Das–Dennis | NSGA-III's diversity scaffold | 22.2 |
| PCP | parallel coordinate plot | 22.4 |
| Surrogate-assisted / Bayesian MOO | model-based optimization for very expensive evaluations | 25.4 |

---

## 30. Solutions to exercises

**E1.** Pairwise: C dominates A (equal on $f_1,f_2$; better on $f_3$: $4<5$). A dominates E (equal $f_1$; $8<9$; $5<6$), so C dominates E by transitivity. B vs A: B worse on $f_1$ ($3>2$), better on $f_2$ ($7<8$) — neither. B vs C: B worse on $f_1$ and $f_3$, better on $f_2$ — neither. B vs D: B better on $f_1$ and $f_3$, worse on $f_2$ — neither. C vs D, A vs D: neither. **Non-dominated set: $\{$B, C, D$\}$.** Note A is dominated but only by C, illustrating Section 3.2.

**E2.** Transitivity: $a_m \le b_m \le c_m$ for all $m$ gives $a_m \le c_m$; and there is some $m_0$ with $a_{m_0} < b_{m_0} \le c_{m_0}$, so strict improvement is preserved. Non-transitivity of mutual non-dominance: $A=(1,3)$, $B=(2,2)$, $C=(3,1)$. $A$ and $B$ are non-dominated, $B$ and $C$ are non-dominated, and $A$ and $C$ are also non-dominated — but now try $A=(1,3)$, $B=(2,2)$, $C=(0,4)$: $A\!-\!B$ non-dominated, $B\!-\!C$ non-dominated, yet $C$ dominates nothing and $A$ dominates nothing... The cleanest counterexample uses the *relation* directly: mutual non-dominance is not transitive because $A=(1,5)$, $B=(3,3)$, $C=(5,1)$ are pairwise non-dominated, but insert $D=(2,2)$: $A$–$D$ non-dominated and $D$–$C$ non-dominated, while $D$ dominates $B$. The consequence: you cannot sort designs into a total order, so no comparison-based sort applies, and you need the layered peeling of Section 3.4 instead.

**E3.** Worst feasible values: $f_1(4) = 16$, $f_2(-2)=16$. Nadir is $(4,4)$. Normalizing with $(16,16)$ compresses the entire front into the lower-left quarter of $[0,1]^2$, so all distances, weights, and hypervolumes shrink and become dominated by the empty region — HV in particular would be mostly constant "free" area, drowning the differences you care about.

**E4.** For $(x_1,x_1)$: the objectives are identical, so dominance reduces to the single-objective case. Pareto set $=\{0\}$, front $=\{(0,0)\}$ — one point. For $(x_1,-x_1)$: perfectly anti-correlated, so *every* point is Pareto-optimal. Pareto set $=[0,1]$, front is the segment from $(0,0)$ to $(1,-1)$. Lesson: identical objectives collapse the front to a point; perfectly opposed ones make everything optimal. Both are degenerate, and both are detectable from `np.corrcoef(res.F.T)` returning $\pm1$ — which is exactly the diagnostic in Section 23.1.

**E5.** $f_2 \equiv 0$, so no design is strictly better in *both* objectives than any other: every $x_1$ is weakly Pareto-optimal. But $x_1 = 0$ has $f_1 = 0 \le f_1(x)$ for all $x$ with strict inequality for $x>0$, so $x_1=0$ dominates every other point and is the only Pareto-optimal design. A method that only checks strict improvement in *all* objectives accepts any $x_1$ — which is exactly why the plain Tchebycheff function needs the augmentation term of Section 9.

**E6.** At $b=b_L$, $h = 6.32$ cm, active constraints are $g_1 = 0$ and the bound $b_L - b \le 0$. So
$$\lambda_1\nabla m + \lambda_2\nabla\delta + \mu_1\nabla g_1 + \nu\nabla(b_L - b) = \mathbf{0},$$
with $\lambda_m,\mu_1,\nu \ge 0$ and $\mu_2 = 0$ since $g_2 = -0.3675 < 0$. The presence of $\nu$ — a bound multiplier — is precisely what distinguishes branch 1 from branch 2, and it is the term that the incomplete analysis in Section 18.3b forgets to allow for.

**E7.** Rule: an objective is something you would trade away indefinitely — more is always better and you would pay for it. A hard requirement with a fixed threshold is a constraint. "At least 12 mm" is a threshold: **constraint**, $g = 1 - t/0.012 \le 0$. Making it an objective would be wrong twice over: it adds a front dimension you do not want, and it would produce designs with 40 mm walls that nobody asked for.

**E8.** $\frac{d}{dx}[w_1x^2 + w_2(x-2)^2] = 2w_1x + 2w_2(x-2) = 0 \Rightarrow x^\ast = 2w_2 = 2(1-w_1)$, linear in $w_1$. So uniform weights give uniform $x$. The front arc-length element is $\sqrt{(2x)^2 + (2(x-2))^2}\,dx = 2\sqrt{x^2+(x-2)^2}\,dx$, which equals 4 at $x=0$ and $x=2$ and $2\sqrt2 \approx 2.83$ at $x=1$. Ratio $4/2.83 = 1.41$ — matching the measured $1.38$ (finite-difference gaps rather than the exact differential). Note the points are *denser in the middle*, not at the ends.

**E9.** $f_2 = 1-\sqrt{f_1}$, so $\frac{d}{df_1}[w_1f_1 + w_2(1-\sqrt{f_1})] = w_1 - \frac{w_2}{2\sqrt{f_1}} = 0 \Rightarrow f_1^\ast = \left(\frac{w_2}{2w_1}\right)^2$. Interior requires $0 < f_1^\ast < 1$, i.e. $w_2 < 2w_1$, i.e. $w_1 > 1/3$. So only $w_1 \in (1/3, 1)$ — **two-thirds of the weight range maps to the interior, one-third all collapses onto the single endpoint $f_1 = 1$**. Uniform sampling of $[0,1]$ therefore wastes a third of your solver runs on one point, and the surviving two-thirds are non-uniformly distributed (Figure 8.4, left panel is the mild case of this).

**E10.** Plain form: $\max(w_1x_1, w_2\cdot 0) = \max(w_1 x_1, 0) = w_1 x_1$ for $x_1 \ge 0$, minimized at $x_1 = 0$ — actually here the plain form *does* find it. The degenerate case arises when the reference point is chosen at or below the flat edge: take $z^{\text{ref}} = (0, -1)$, so the second term is $w_2\cdot 1$, a constant. Then for any $x_1 < w_2/w_1$ the max is that constant and every such $x_1$ is optimal. Adding $\rho\sum_m w_m(f_m - z^{\text{ref}}_m)$ makes the objective strictly increasing in $x_1$, recovering $x_1 = 0$ uniquely.

**E11.** $5^{M-1} = 5^3 = 125$ subproblems. Even a very efficient gradient-based solve needs, say, 20–50 evaluations each, so 2 500–6 250 evaluations — ten to twenty-five times over budget, and that ignores infeasible subproblems. With 250 evaluations for $M=4$ you are firmly in the surrogate/interactive regime (Section 25.4): fit a Gaussian process and use qEHVI or ParEGO, or run an interactive reference-point method with an engineer in the loop. NSGA-III would also be starved at 250 evaluations.

**E12.** The table is reproduced by `crowding_distance` in `scripts/common.py`; run `python scripts/fig03_nsga2.py`. Moving $c$ to $(3.5, 8.9)$ puts it between $a$ ($f_2 = 9.0$) and $b$ ($f_2=6.5$) in the $f_2$ ordering while leaving the $f_1$ ordering unchanged, so the neighbour structure changes: $c$ is now sandwiched very close to $a$ in $f_2$. Recomputing, $c$'s $f_2$ gap shrinks dramatically while $b$'s grows, and **$c$ becomes the most crowded** — it would be discarded first. One-sentence explanation: crowding is about *neighbour separation in each objective separately*, so moving a point in only one objective can flip the crowding ranking without changing anything about dominance.

**E13.** With a large finite value, a boundary design could eventually lose a tournament to an interior design with a slightly larger crowding value, or be trimmed when its rank overflows. Over 200 generations that happens with near-certainty at least once, and the front's extremes erode inward — you would systematically underestimate the range of achievable performance, and your nadir estimate (Section 4) and hypervolume (Section 20.3) would both be corrupted. $\infty$ makes the extremes unloseable.

**E14.** At a design 10% over the stress limit, $g_1 = \sigma - \sigma_{\text{allow}} \approx 0.1 \times 3\times10^8 = 3\times 10^7$. A gross aspect-ratio violation is $g_2 = h - 10b \approx 0.1$ m at most (bounded by the box: $h \le 0.3$, so $|g_2| \le 0.3$). So $g_2$ contributes about $10^{-8}$ of $CV$ — utterly invisible. Every comparison between infeasible designs is decided by stress alone, and the aspect-ratio constraint is effectively absent until stress is satisfied. Correct: $g_1 = \sigma/\sigma_{\text{allow}} - 1$ and $g_2 = h/(10b) - 1$, both $O(1)$.

**E15.** Population $P = \{(1,9), (5,5), (9,1)\}$, offspring $Q = \{(4,6), (6,4), (5,6)\}$. Without elitism the next generation is $Q$, and the extreme designs $(1,9)$ and $(9,1)$ — both non-dominated, and both on the true front's ends — are gone forever. With elitism, the merged pool of 6 is sorted and $(1,9)$, $(9,1)$ are rank 1 with $d=\infty$, so they survive. The front's range is preserved.

**E16.** Expect an interior optimum, typically around `pop_size` 50–100 for this problem. Small populations run many generations (strong convergence pressure) but cannot represent the front — with `pop_size=20` you get at most 20 points, so HV is capped by discretization no matter how well converged. Large populations represent the front finely but get few generations, so they remain under-converged. The trade-off is between *resolution* and *convergence* at fixed budget, and it is why Section 27 tip 8 gives a range rather than a number.

**E17.** With $h \le 4b$ the aspect-ratio branch becomes $h = 4b$, and the branch boundaries shift: branch 1/2 at $m = 4b_L^2\rho L = 3.14$ kg (from $\sqrt{4m/\rho L} = m/(b_L\rho L)$), branch 2/3 at $m = \rho h_U^2 L/4 = 176.6$ kg (from $\sqrt{4m/\rho L} = h_U$, i.e. $b = h_U/4 = 7.5$ cm). Branch 1 now spans $h \in [6.32,\ 4]$ cm — which is *empty*, since $6.32 > 4$: at $b = b_L = 1$ cm the aspect limit $h \le 4$ cm is *stricter* than the stress limit $h \ge 6.32$ cm, so $b = b_L$ is **infeasible entirely** and the lightest design moves off the lower bound. A good reminder that the branch structure is not a fixed feature of the problem class — it depends on the numbers.

**E18.** $h^\ast(m)$ has the term $m/(b_L\rho L)$; halving $b_L$ doubles it, so it binds only for masses below $10b_L^2\rho L = 1.96$ kg instead of 7.85 kg. Branch 1 shrinks toward the extreme light end, and the stress cut-off moves to $h = \sqrt{6PL/(\sigma_{\text{allow}}b_L)} = 8.94$ cm at $b = 0.5$ cm, giving $m_{\min} = 3.51$ kg. Fewer designs will sit on branch 1 because it now covers a much shorter stretch of the front.

**E19.** Unnormalized, mass ranges over $\sim 700$ and deflection over $\sim 0.016$. Every rectangle in the HV staircase has width $O(100)$ and height $O(0.01)$, so the total is dominated by the mass extent; improving deflection by a factor of two changes HV in the fourth significant figure. Normalized, both axes span 1 and both contribute comparably. This is the same effect as the BNH/OSY rows in Section 19.2, quantified.

**E20.** Deleting the 20 lightest designs raises the ideal estimate on mass sharply (the new lightest is around 20 kg instead of 5 kg) and barely changes the nadir. Pseudo-weights and ASF, which reference the ideal, move substantially; the compromise/knee picks move too, because the normalization changed. The lesson is Section 21.5's: your recommendation is a function of your *front approximation*, not just of your preference, so report a shortlist and state which normalization produced it.

**E21.** You should find the reverse of Section 20.5: NSGA-III wins decisively at $M=5$ (Section 22.3 measures IGD$^+$ 0.0019 vs 0.3054 on one seed; over 20 seeds the separation is large and $p$ will be very small). Conclusion: algorithm choice is a function of $M$, and a benchmark result at $M=2$ tells you nothing about $M=5$.

**E22.** $I = bh^3/12$ and deflection $\delta = 4PL^3/(Ebh^3) = PL^3/(3EI)$, so maximizing $I$ is *exactly* minimizing $\delta$ up to a positive constant — the two objectives are perfectly anti-correlated by construction. Expect $|\text{corr}(f_2, f_3)| = 1.000$, a front that is a curve rather than a surface, and far fewer filled directions than 91. This is the cleanest possible instance of the Section 23.1 failure and worth running once so you recognize the symptoms.

**E23.** `Integer(bounds=(10,300))` for `b_mm` allows any whole millimetre, e.g. $b = 47$ mm — which you cannot buy. `Choice(options=WIDTHS_MM)` restricts to stock sizes and is the correct model. The integer version will report a better-looking front (a superset of the achievable designs, so weakly dominating it), and every "improvement" it shows over the catalogue front is unbuildable. Cost of getting this wrong: you present a design that procurement cannot source, and the real design is worse than you promised.

**E24.** (a) Serial: $100 \times 200 \times 45\ \mathrm{s} = 900\,000$ s $\approx 10.4$ days. (b) 8 cores: batches per generation $=\lceil 100/8\rceil = 13$, so $13 \times 200 \times 45 = 117\,000$ s $\approx 1.4$ days. (c) 64 cores: $\lceil 100/64\rceil = 2$ batches, so $2\times200\times45 = 18\,000$ s $= 5$ hours — note this is a $50\times$ speedup from $64\times$ the cores, and going to 100 cores would only reach 2.5 hours because you cannot go below one batch. Which lever: at 45 s per evaluation and 20 000 evaluations you are in the $10^3$–$10^4$ band, so parallelize *and* raise `pop_size` to 128 (so it divides your core count evenly), seed the population, and use convergence-based termination with a cap. If only 64 cores for a few hours were available, drop to a few hundred evaluations and move to a surrogate-assisted method instead.

---

## 31. References

**Textbooks**

- K. Deb, *Multi-Objective Optimization using Evolutionary Algorithms*, Wiley, 2001. The reference for the evolutionary side; Chapters 2–3 deepen Sections 3–12 here.
- K. Miettinen, *Nonlinear Multiobjective Optimization*, Kluwer, 1999. The classical and mathematical side: scalarization theory, optimality conditions, the a priori/a posteriori/interactive taxonomy, ASF, interactive methods.
- C.-L. Hwang & A. S. M. Masud, *Multiple Objective Decision Making — Methods and Applications*, Springer, 1979. Origin of the taxonomy in Section 7.
- J. Branke, K. Deb, K. Miettinen & R. Słowiński (eds.), *Multiobjective Optimization: Interactive and Evolutionary Approaches*, Springer, 2008.
- C. A. Coello Coello, G. B. Lamont & D. A. Van Veldhuizen, *Evolutionary Algorithms for Solving Multi-Objective Problems*, 2nd ed., Springer, 2007.

**Key papers**

- A. M. Geoffrion, "Proper efficiency and the theory of vector maximization," *J. Math. Anal. Appl.* 22(3):618–630, 1968. Proper Pareto optimality (Section 3.3).
- A. P. Wierzbicki, "The use of reference objectives in multiobjective optimization," in *Multiple Criteria Decision Making Theory and Application*, Springer, 1980. The ASF (Section 9).
- I. Das & J. E. Dennis, "Normal-boundary intersection: a new method for generating the Pareto surface in nonlinear multicriteria optimization problems," *SIAM J. Optimization* 8(3):631–657, 1998. NBI (Section 11).
- A. Messac, A. Ismail-Yahaya & C. A. Mattson, "The normalized normal constraint method for generating the Pareto frontier," *Structural and Multidisciplinary Optimization* 25:86–98, 2003.
- E. Zitzler, K. Deb & L. Thiele, "Comparison of multiobjective evolutionary algorithms: empirical results," *Evolutionary Computation* 8(2):173–195, 2000. The ZDT suite (Section 19).
- K. Deb, A. Pratap, S. Agarwal & T. Meyarivan, "A fast and elitist multiobjective genetic algorithm: NSGA-II," *IEEE Trans. Evolutionary Computation* 6(2):182–197, 2002.
- Q. Zhang & H. Li, "MOEA/D: a multiobjective evolutionary algorithm based on decomposition," *IEEE Trans. Evolutionary Computation* 11(6):712–731, 2007.
- J. Knowles, "ParEGO: a hybrid algorithm with on-line landscape approximation for expensive multiobjective optimization problems," *IEEE Trans. Evolutionary Computation* 10(1):50–66, 2006. Surrogate-assisted MOO (Section 25.4).
- K. Deb & H. Jain, "An evolutionary many-objective optimization algorithm using reference-point-based nondominated sorting, Part I: solving problems with box constraints (NSGA-III)," *IEEE Trans. Evolutionary Computation* 18(4):577–601, 2014.
- H. Ishibuchi, H. Masuda, Y. Tanigaki & Y. Nojima, "Modified distance calculation in generational distance and inverted generational distance," in *Evolutionary Multi-Criterion Optimization (EMO 2015)*, LNCS 9019, pp. 110–125, Springer, 2015. **GD$^+$ and IGD$^+$, and the Pareto-compliance argument of Section 20.2.**
- E. Zitzler, L. Thiele, M. Laumanns, C. M. Fonseca & V. G. da Fonseca, "Performance assessment of multiobjective optimizers: an analysis and review," *IEEE Trans. Evolutionary Computation* 7(2):117–132, 2003. The definitive treatment of indicator properties.
- J. Blank & K. Deb, "pymoo: multi-objective optimization in Python," *IEEE Access* 8:89497–89509, 2020. Cite this when you use pymoo.

**Software**

- pymoo documentation: <https://pymoo.org> — especially *Getting Started*, *Algorithms*, *Constraint Handling*, *Parallelization*, *MCDM*, *Visualization*, and *Mixed Variable*.
- Source: <https://github.com/anyoptimization/pymoo> (Apache-2.0; release 0.6.2, June 2026).
- BoTorch: <https://botorch.org> — Bayesian multi-objective optimization (qEHVI and relatives).

---

*Every figure and number in this module was produced by the scripts in `scripts/`, executed against pymoo 0.6.2, numpy 2.4.4, scipy 1.17.1 and matplotlib 3.10.8, with fixed random seeds. APIs evolve: if an import fails on a later pymoo release, consult the "Versions" page of the pymoo documentation — the `StarmapParallelization` move in Section 25.3 is an example of exactly such a change.*
