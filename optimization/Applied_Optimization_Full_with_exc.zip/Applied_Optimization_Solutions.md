# Applied Optimization for Engineers — Solutions

Complete worked solutions to every exercise in *Applied Optimization for Engineers*.
Solutions are keyed by **section number**: exercise 5.6.2 belongs to §5.6 of the
tutorial, and its solution appears below under "Solutions — 5.6 Right-hand-side
ranging...". Exercises are tagged by type:

| Tag | Type | What it asks of you |
|---|---|---|
| **[C]** | Conceptual / short answer | State, explain, distinguish, or correct a claim in words |
| **[H]** | By-hand computation & derivation | Derive, solve, or verify with pencil and paper |
| **[P]** | Python / coding | Write and run code; every numerical answer here has been executed |
| **[M]** | Modeling & interpret-the-output | Build a model, or read a solver's answer as engineering |

**How to use this file.** Attempt an exercise fully before reading its solution —
including running the code for a [P] item, since the habit of *checking* is most of
what the course teaches. Every numerical result quoted below was produced by
running the code shown, so if your output differs, the discrepancy is worth
chasing: it is usually a version difference, a random seed, or a genuine error in
one of the two runs.

**A note on [P] solutions.** Code is written for `numpy`, `scipy`,
and `cvxpy`. A few exercises reference `pyomo` as an alternative modeling layer
(as the tutorial does in Part IV); where Pyomo is unavailable, the equivalent model
via `scipy.optimize.milp` or CVXPY with `boolean=True` is given instead, using the
same HiGHS engine underneath.

---

## Solutions — 0.1 The gradient: the direction things get worse fastest

**0.1.1** $\nabla f = (2x_1 + 3x_2,\; 3x_1)$, so $\nabla f(2,-1) = (4-3,\;6) = (1,6)$, with $\|\nabla f\| = \sqrt{37}$.
(a) Steepest decrease: $-\nabla f/\|\nabla f\| = (-1,-6)/\sqrt{37} \approx (-0.164,\,-0.986)$.
(b) Any unit vector orthogonal to $\nabla f$: $(6,-1)/\sqrt{37} \approx (0.986,\,-0.164)$ (or its negative). This is tangent to the contour through $(2,-1)$, where $f = -2$.

**0.1.2** $\partial f/\partial x_1 = e^{x_2}$, $\partial f/\partial x_2 = x_1e^{x_2} + 2x_2$, so $\nabla f(1,0) = (1,1)$.
Predicted change: $\nabla f^\top d = (1)(-0.01) + (1)(-0.01) = -0.02$.
Exact: $f(0.99,-0.01) - f(1,0) = 0.99\,e^{-0.01} + 0.0001 - 1 = -0.0197507$.
Discrepancy $\approx 2.5\times10^{-4}$. The Taylor remainder is $O(\|d\|^2)$; here $\|d\| \approx 0.0141$, so $\|d\|^2 \approx 2\times10^{-4}$ — the right size. Halving $d$ should cut the error by about four.

**0.1.3**
```python
import numpy as np

def grad_check(f, grad, x, h=1e-6):
    x = np.asarray(x, float)
    fd = np.zeros_like(x)
    for k in range(x.size):
        e = np.zeros_like(x); e[k] = h
        fd[k] = (f(x + e) - f(x - e)) / (2*h)
    return np.max(np.abs(fd - grad(x))), fd, grad(x)

f      = lambda x: x[0]*np.exp(x[1]) + x[1]**2
g_ok   = lambda x: np.array([np.exp(x[1]), x[0]*np.exp(x[1]) + 2*x[1]])
g_bad  = lambda x: np.array([np.exp(x[1]), x[0]*np.exp(x[1])])       # dropped 2*x2

for x in ([1.0, 0.0], [1.0, 2.0]):
    print(x, "correct:", f"{grad_check(f, g_ok,  x)[0]:.2e}",
             "  buggy:", f"{grad_check(f, g_bad, x)[0]:.2e}")
```
Output: at $(1,0)$ both errors are $\sim10^{-10}$; at $(1,2)$ the buggy gradient is off by $4.0$.
**Why:** the dropped term is $2x_2$, which vanishes at $x_2 = 0$. A gradient check at a single point — especially a point with zeros in it — can pass a wrong derivative. *Always check at a generic point with no zero components*, and at more than one point. This trap reappears with real consequences in §12.1.

**0.1.4** Correct statement: $-\nabla f(x)$ is the direction of steepest *local* decrease; it says nothing about where the minimizer is. Example: on $f(x) = \tfrac12(x_1^2 + 100x_2^2)$ at $x = (1,\,0.01)$, $-\nabla f = (-1,-1)$, which points at $45^\circ$, whereas the minimizer is at the origin, in the direction $(-1,-0.01)$ — nearly along $x_1$. The steepest-descent step overshoots in $x_2$ and must come back; this is exactly the zigzag quantified in §7.3.

## Solutions — 0.2 Taylor expansion: the local models every algorithm uses

**0.2.1** $\nabla f = (2x_1 + 2x_2 - 1,\; 2x_1 + 6x_2)$ and $\nabla^2 f = \begin{pmatrix}2 & 2\\ 2 & 6\end{pmatrix}$ (constant).
At $x_0=(1,1)$: $f = 5$, $\nabla f = (3,8)$.
$\nabla f^\top d = 0.3 - 0.8 = -0.5$. With $\nabla^2 f\,d = (0,\,-0.4)$, $\tfrac12 d^\top\nabla^2 f\,d = \tfrac12(0.04) = 0.02$.
Model: $5 - 0.5 + 0.02 = 4.52$. Exact: $f(1.1,0.9) = 1.21 + 1.98 + 2.43 - 1.1 = 4.52$.
They agree **exactly**, and not by luck: $f$ is quadratic, so the third and higher Taylor terms are identically zero. The second-order model *is* the function.

**0.2.2** One iteration, from any starting point. The quadratic model coincides with $f$, so the model's minimizer is $f$'s minimizer: $x_1 = x_0 - (\nabla^2 f)^{-1}\nabla f(x_0)$ solves the problem outright. (Check with 0.2.1: $(\nabla^2f)^{-1}\nabla f = \frac{1}{8}\begin{pmatrix}6&-2\\-2&2\end{pmatrix}\begin{pmatrix}3\\8\end{pmatrix} = \frac18(2,\,10) = (0.25,1.25)$, giving $x^\star = (0.75,-0.25)$, where $\nabla f = (0,0)$ ✓.) This is why Newton's method is the benchmark: near a minimum, smooth functions look quadratic, so it converges very fast — the topic of §7.4.

**0.2.3**
```python
import numpy as np
h  = 10.0**-np.arange(1, 7)
e1 = np.abs(np.exp(h) - (1 + h))              # first-order model error
e2 = np.abs(np.exp(h) - (1 + h + h**2/2))     # second-order model error
for hi, a, b in zip(h, e1, e2): print(f"h={hi:8.0e}  e1={a:.3e}  e2={b:.3e}")
m = slice(0, 4)                                # fit only where round-off is negligible
print("slopes:", np.polyfit(np.log10(h[m]), np.log10(e1[m]), 1)[0],
                 np.polyfit(np.log10(h[m]), np.log10(e2[m]), 1)[0])
```

| $h$ | $e_1$ | $e_2$ |
|---|---|---|
| $10^{-1}$ | $5.171\times10^{-3}$ | $1.709\times10^{-4}$ |
| $10^{-2}$ | $5.017\times10^{-5}$ | $1.671\times10^{-7}$ |
| $10^{-3}$ | $5.002\times10^{-7}$ | $1.667\times10^{-10}$ |
| $10^{-4}$ | $5.000\times10^{-9}$ | $1.668\times10^{-13}$ |
| $10^{-5}$ | $5.000\times10^{-11}$ | $0$ |

Each factor-of-10 reduction in $h$ divides $e_1$ by $\approx100$ and $e_2$ by $\approx1000$; the fitted slopes are $2.00$ and $3.00$ — exactly the Taylor remainder orders $O(h^2)$ and $O(h^3)$.
For $h \le 10^{-5}$ the measured $e_2$ becomes **exactly zero**, which is not a triumph of accuracy but a failure of arithmetic: the true error $h^3/6 \approx 1.7\times10^{-16}$ is below the spacing of double-precision numbers near $1$ ($\approx2.2\times10^{-16}$), so $e^h$ and its quadratic model round to the same floating-point value. This is your first sight of *round-off swamping truncation* — the exact mechanism that makes finite-difference gradients fail for small steps (§12.1). Always fit convergence rates in the range where truncation still dominates.

**0.2.4** (i) **Line search** — accept the model's *direction* but shrink the *step length* until the function actually decreases (§7.5, §7.2). (ii) **Trust region** — restrict the step to a ball $\|d\| \le \Delta$ in which the model is believed, and adapt $\Delta$ based on whether the model's prediction was borne out (§7.5). One limits how far you go along a chosen direction; the other limits the region in which the model is allowed to choose a direction at all.

## Solutions — 0.3 Positive definiteness: what "curves upward in every direction" means

**0.3.1** For a symmetric $2\times2$: eigenvalues have product $\det A$ and sum $\operatorname{tr}A$. So $\det > 0$ means same-sign eigenvalues (sign given by the trace), $\det < 0$ means opposite signs, $\det = 0$ means one eigenvalue is zero.
(a) $\operatorname{tr} = 7 > 0$, $\det = 11 > 0$ → **positive definite** (eigenvalues $2.382,\,4.618$).
(b) $\det = 4-4 = 0$, $\operatorname{tr} = 5 > 0$ → **positive semidefinite, not definite** (eigenvalues $0,\,5$).
(c) $\det = 1-9 = -8 < 0$ → **indefinite** (eigenvalues $-2,\,4$).
(d) $\operatorname{tr} = -7 < 0$, $\det = 10 > 0$ → **negative definite** (eigenvalues $-2,-5$).

**0.3.2** $A = \begin{pmatrix}1&3\\3&1\end{pmatrix}$, so $d^\top A d = d_1^2 + 6d_1d_2 + d_2^2$.
$d = (1,1)$: $1 + 6 + 1 = 8 > 0$ (this is the $\lambda = 4$ eigenvector, $\|d\|^2 = 2$, and $4\cdot2 = 8$ ✓).
$d = (1,-1)$: $1 - 6 + 1 = -4 < 0$ (the $\lambda = -2$ eigenvector: $-2\cdot 2 = -4$ ✓).
Positive in some directions, negative in others — a saddle.

**0.3.3** Counterexample: $A = \begin{pmatrix}1&2\\2&1\end{pmatrix}$ has positive diagonal but eigenvalues $3$ and $-1$; indeed $d = (1,-1)$ gives $d^\top A d = 1-4+1 = -2 < 0$. Off-diagonal coupling can defeat positive diagonals.
Correct test (Sylvester's criterion for $2\times2$): $A \succ 0 \iff a_{11} > 0$ **and** $\det A = a_{11}a_{22} - a_{12}^2 > 0$. (Positive diagonal is necessary but far from sufficient.)

**0.3.4**
```python
import numpy as np

def classify(A, rtol=1e-10):
    w = np.linalg.eigvalsh(np.asarray(A, float))
    tol = rtol * max(1.0, np.max(np.abs(w)))
    pos, neg = np.any(w > tol), np.any(w < -tol)
    if pos and neg: return "indefinite"
    if pos:  return "PD"  if np.all(w >  tol) else "PSD"
    if neg:  return "ND"  if np.all(w < -tol) else "NSD"
    return "PSD"          # all eigenvalues numerically zero
```
A *relative* tolerance is required because eigenvalues carry the units and magnitude of the problem: a Hessian in pascals may have entries of size $10^{11}$, so a true zero eigenvalue can compute as $10^{2}$ — huge in absolute terms, negligible relative to $\lambda_{\max}$. Absolute thresholds classify such a matrix as indefinite and send you chasing a nonexistent saddle. (Compare §2.3: badly scaled models make every numerical test unreliable.)

## Solutions — 0.4 The condition number: how stretched a bowl is

**0.4.1** $\kappa = 10/0.1 = 100$. Contour semi-axis lengths scale as $1/\sqrt{\lambda}$, so the ratio is $\sqrt{\lambda_{\max}/\lambda_{\min}} = \sqrt{100} = 10$: the ellipse is 10 times longer than it is wide. The square root appears because the *quadratic form*, not the coordinate, carries $\lambda$: setting $\tfrac12\lambda_i s_i^2 = c$ gives $s_i = \sqrt{2c/\lambda_i}$.

**0.4.2** $\kappa = 400/4 = 100$. With $x_2 = z_2/10$, $f$'s second derivative in $z_2$ picks up a factor $(1/10)^2$: $400/100 = 4$, so the Hessian becomes $\operatorname{diag}(4,4)$ and $\kappa = 1$ — a perfectly round bowl. **Moral:** most enormous condition numbers in engineering models are *artifacts of unit choice*, not intrinsic difficulty. They are removable in five minutes by rescaling (§2.3), which is why scaling is worth more than switching algorithms.

**0.4.3**
```python
import numpy as np
H = np.array([[802., -400.], [-400., 200.]])
w = np.linalg.eigvalsh(H); print(w, w[1]/w[0])
```
Eigenvalues $\lambda \approx 0.3994$ and $1001.6$, so $\kappa \approx 2.51\times10^3$. Rosenbrock's notoriety is exactly this: even *at* the solution the bowl is 50:1 in aspect ratio ($\sqrt{2508}\approx50$), and away from it the valley is far worse.

**0.4.4**
```python
import numpy as np

def sd_iters(kappa, rtol=1e-6):
    Q = np.diag([1.0, float(kappa)])
    x = np.array([1.0, 1.0/kappa])          # worst case: equal gradient components
    f0 = 0.5*x@Q@x; it = 0
    while 0.5*x@Q@x > rtol*f0:
        g = Q@x; a = (g@g)/(g@Q@g); x = x - a*g; it += 1
    return it

for k in [1, 10, 100, 1000, 10000]:
    r = ((k-1)/(k+1))**2
    pred = np.log(1e-6)/np.log(r) if k > 1 else 1
    print(f"kappa={k:>6}  iters={sd_iters(k):>6}  theory={pred:>9.1f}")
```

| $\kappa$ | iterations | theory $\log\varepsilon/\log r$ |
|---|---|---|
| 1 | 1 | 1 |
| 10 | 35 | 34.4 |
| 100 | 346 | 345.4 |
| 1000 | 3 454 | 3 453.9 |
| $10^4$ | 34 539 | 34 538.8 |

Iterations $\approx 3.45\,\kappa$ — linear in $\kappa$, matching theory, since $r = \big(\tfrac{\kappa-1}{\kappa+1}\big)^2 \approx 1 - 4/\kappa$ gives $-\ln r \approx 4/\kappa$ and $\ln(10^{6})/(4/\kappa) \approx 3.45\kappa$.
**Why the specific start:** the bound is a *worst case*, attained only when the initial gradient has equal-magnitude components in the eigen-directions. From the "innocent" start $x_0 = (1,1)$ with a diagonal $Q$, the first step nearly annihilates the stiff component and the method finishes in a handful of iterations — you would wrongly conclude that conditioning does not matter. Benchmarks must not be run from accidentally favourable points (§17.4).

## Solutions — 1.1 The three ingredients

**1.1.1** The test: *can the designer set it?* If yes it is a variable; if it is imposed by the world or the specification it is a parameter; if it is computed from the others it is derived.
- **Decision variables:** $L$ [m], $t$ [m], material choice [binary/categorical], fan-set $h$ [W m$^{-2}$K$^{-1}$] (a variable *only because* the fan speed is yours to choose).
- **Parameters:** $T_\infty$ [K] (the weather), $T_b$ [K] (imposed by the chip), maximum mass [kg], cost per kg [\$/kg], and the material properties $k$, $\rho$ that follow from the material choice.
- **Derived:** fin mass $\rho Lt w$ [kg], heat dissipated $Q$ [W], fin efficiency, tip temperature.
Note $h$ is the interesting case: it is a parameter in a natural-convection design and a variable in a forced-convection design. Which one it is depends on the physical situation, not on the equations it appears in.

**1.1.2** One acceptable answer (fin of fixed width $w$, one-dimensional):
**Variables:** $L$ [m], $t$ [m], $h$ [W m$^{-2}$K$^{-1}$].
**Objective:** minimize material cost $c_\rho\,\rho\,wLt$ [\$] (a single scalar).
**Constraints:**
1. *Physics:* the fin equation / heat-balance relation giving $Q(L,t,h)$ — an equality.
2. *Codes & standards:* tip temperature $\le T_{\max}$; fan noise $\le$ limit, i.e. $h \le h_{\max}$.
3. *Resources:* $\rho w L t \le m_{\max}$; fan power $\le P_{\max}$; $Q \ge Q_{\text{req}}$ (the duty you must meet).
4. *Definitional bounds:* $t \ge t_{\min} > 0$ (manufacturable), $L > 0$, $h > 0$.
The bound $t \ge t_{\min}$ is the one students omit, and without it the optimizer returns a zero-thickness fin of zero cost.

**1.1.3** The fourth source — **definitional bounds** — was neglected. Cost typically enters as something like $c\,\pi D L$ (material) so a negative $D$ makes the modelled cost negative, while the head-loss term $\propto 1/D^5$ is *also* satisfied because $(-0.4)^{-5} < 0$ makes the pressure-drop constraint trivially true. The optimizer is not malfunctioning: it found a genuine loophole in the algebra you wrote. This is the "converged to nonsense" outcome of §1.3, and the fix is one line: `bounds=(1e-3, None)`.

**1.1.4** An objective must be a single scalar (§1.1); "minimize mass and cost" specifies no ranking when the two disagree, so there is no well-defined best point — there is a *family* of optimal trade-offs. Two honest routes: (i) keep one as the objective and impose the other as a constraint at a chosen level, then sweep that level (the $\varepsilon$-constraint method, §19.2); (ii) minimize a weighted sum $w_1\,\text{mass} + w_2\,\text{cost}$ with explicitly justified weights and units, and sweep the weights (§19.1). Either way you report a Pareto front, not a point.

## Solutions — 1.2 Standard form

**1.2.1** Negate the objective and flip the $\ge$:
$$\min_x\; -3x_1 - 2x_2 \quad\text{s.t.}\quad \underbrace{4 - x_1 - x_2}_{g_1(x)} \le 0,\quad \underbrace{2x_1 - x_2 - 6}_{h_1(x)} = 0,\quad 0\le x_1\le 5,\ x_2 \ge 0.$$
Bounds stay bounds. The relation is $f^\star_{\max} = -f^\star_{\min}$, at the *same* $x^\star$. (Here $x^\star = (5,4)$, $f^\star_{\max} = 23$, $f^\star_{\min} = -23$.)

**1.2.2** (i) **Speed:** solvers handle bounds by a separate, much cheaper mechanism (in a simplex basis a bounded variable never needs a constraint row; interior-point methods treat bounds directly), so declaring $n$ bounds as $2n$ general rows inflates the constraint matrix for no benefit. (ii) **Readability and diagnosis:** the active-set report then distinguishes "variable at its bound" from "a physical constraint is binding" — two different engineering statements (§1.4, §10.3). A third reason: presolvers use bounds to tighten other constraints and detect infeasibility early.

**1.2.3**
```python
import numpy as np
from scipy.optimize import linprog

c = [-3., -2.]                        # minimize -(3x1+2x2)
A_ub = [[-1., -1.]]; b_ub = [-4.]     # -(x1+x2) <= -4
A_eq = [[2., -1.]];  b_eq = [6.]

r1 = linprog(c, A_ub, b_ub, A_eq, b_eq, bounds=[(0, 5), (0, None)])
A2 = A_ub + [[1., 0.], [-1., 0.], [0., -1.]]      # x1<=5, -x1<=0, -x2<=0
b2 = b_ub + [5., 0., 0.]
r2 = linprog(c, A2, b2, A_eq, b_eq, bounds=[(None, None), (None, None)])
print(r1.x, -r1.fun, len(A_ub), "rows")   # [5. 4.]  23.0  1 rows
print(r2.x, -r2.fun, len(A2),  "rows")    # [5. 4.]  23.0  4 rows
```
Both give $x^\star = (5,4)$ with objective $23$. The bounded version carries **1** general row; the all-constraints version carries **4**. Scaled to a model with 10 000 variables, that is 1 row versus 20 001.

**1.2.4** Two standard-form constraints: $5 - g(x) \le 0$ and $g(x) - 12 \le 0$. If instead you introduce $u = g(x)$ as a variable with bounds $5 \le u \le 12$, you have **one** equality constraint $g(x) - u = 0$ plus a bound (which costs nothing) — often the better formulation when $g$ is expensive or nonlinear, because the nonlinearity now appears once.

## Solutions — 1.3 The four possible outcomes

**1.3.1**
- **Optimal** — no fault; verify anyway by reading the active set and checking units (§1.4, §21.3).
- **Infeasible** — usually yours: contradictory constraints or a unit error. First move: re-solve with the suspect constraints softened by slacks and minimize total violation, which tells you *which* constraint and *by how much* (§2.2, §21.2).
- **Unbounded** — yours: a missing constraint. First move: find the diverging variable from the ray the solver reports and ask what physically limits it.
- **Converged to nonsense** — yours, and the most dangerous, since it looks like success. First move: sanity-check magnitudes and signs against a hand estimate, then look for a missing bound.

**1.3.2**
```python
from scipy.optimize import linprog
inf = linprog([1., 1.], A_ub=[[1., 1.], [-1., -1.]], b_ub=[1., -3.])   # x1+x2<=1 and >=3
unb = linprog([-1., 0.], A_ub=[[0., 1.]], b_ub=[1.], bounds=[(0, None), (0, None)])
for name, r in [("infeasible", inf), ("unbounded", unb)]:
    print(name, "status", r.status, "|", r.message)
```
HiGHS via SciPy returns `status=2` with a message reporting the problem is infeasible, and `status=3` for unbounded. (`0` = optimal, `1` = iteration/time limit, `4` = numerical failure.) Note in (b) that $x_1$ is unconstrained above while the objective $-x_1$ rewards growth — precisely the "missing constraint" signature.

**1.3.3** This is **converged to nonsense**. Most likely missing: buckling of compression members (a slender member's critical load falls with area, so vanishing area is only admissible if buckling is unmodelled); a close second is a minimum manufacturable area bound $A \ge A_{\min}$, or missing displacement limits. Two-minute test: take the returned design and evaluate the *neglected* physics by hand — compute the Euler buckling load of the most heavily loaded compression member and compare with its axial force. If it fails by six orders of magnitude, you have found the missing constraint. (General principle of §2.1: an absurd answer is a free design review of your model.)

**1.3.4** They certify a *local* optimality condition — that the KKT conditions (§9.3) hold to tolerance at the returned point, and that no small feasible step improves the objective. That is a genuine, checkable mathematical statement; it simply is not the statement "no better point exists anywhere." The word "success" refers to the algorithm's own termination test, not to global optimality. On a convex problem the local certificate upgrades to a global one automatically (§3.2) — which is the entire reason convexity is the organizing idea of the course.

## Solutions — 1.4 Active constraints: how to read a solution

**1.4.1** **Active** ($g_i = 0$): deflection, and the width upper bound. **Inactive**: stress (23 % margin), buckling (61 % margin), cost (5 % margin).
Summary: *"The design is deflection-limited with the width at its maximum permitted value; stress and buckling are not limiting. To get lighter, either relax the deflection limit or raise the width cap — improving the allowable stress would achieve nothing."* Note how much more that says than "mass = 41.2 kg."

**1.4.2** At $x^\star$ an inactive constraint holds strictly, so it holds in a whole neighbourhood; the local optimality argument (and the KKT system, where its multiplier is zero by complementary slackness, §5.3) is unchanged. Deleting it is nonetheless a mistake if you intend to re-solve with different data: inactive at *these* parameter values does not mean inactive at next month's load case, and sensitivity/robust studies (§5.6, §20) will move the active set. Keep it in the model; just do not read it as a design driver today.

**1.4.3**
```python
import numpy as np

def report(g_funcs, x, tol=1e-6, names=None):
    x = np.asarray(x, float)
    names = names or [f"g{i+1}" for i in range(len(g_funcs))]
    for nm, g in zip(names, g_funcs):
        v = float(g(x)); state = "ACTIVE" if abs(v) <= tol else ("inactive" if v < 0 else "VIOLATED")
        print(f"{nm:>4}: value={v:+.6f}  slack={-v:+.6f}  {state}")

gs = [lambda x: x[0]+x[1]-4, lambda x: x[0]-3, lambda x: -x[1]]
report(gs, [3.0, 1.0])
```
Output: $g_1 = 0$ (**ACTIVE**), $g_2 = 0$ (**ACTIVE**), $g_3 = -1$ (inactive, slack 1). The point sits at the intersection of two constraints — a vertex, in the language of §4.1.

**1.4.4** **Design B** should worry you more. If no constraint is active, the reported point is an *interior* stationary point of the objective — but a mass-minimization objective has no interior minimum (less material is always lighter), so either the model is missing the constraints that should be limiting, or the solver stopped early, or a bound is active but not being reported. Design A tells a coherent physical story; design B says "nothing is stopping me and yet I stopped," which is a contradiction worth chasing before you trust the 0.2 kg advantage.

## Solutions — 1.5 The map of the territory

**1.5.1**
(a) Continuous + convex → **LP** (blending is the classic LP).
(b) Integer + convex → **MILP** (fixed charges need binaries and big-$M$ links, §13.3).
(c) Continuous + convex → **QP** (bounded least squares).
(d) Continuous + nonconvex, black-box → bottom-left, **no derivatives available**: surrogate/Bayesian optimization or heuristics (Part V).
(e) Integer + convex → **convex MINLP** (quadratic costs, binary on/off): unit commitment.
(f) Continuous + convex → **SOCP** (the constraint is exactly $\|Ax+b\|_2 \le c$, §3.4).

**1.5.2** Because convexity, not linearity, is what decides whether "the answer" means a certified global optimum. A convex QP or SOCP is solved as reliably and globally as an LP, so drawing the line at linearity would put problems with identical guarantees on opposite sides. Linearity is a *special case* of convexity that happens to be especially cheap; it earns a class name (LP), not an axis.

**1.5.3** It costs **time** — potentially an enormous amount, since branch and bound may explore exponentially many nodes. Global optimality is recovered by **branch and bound** (Part IV), which uses the convex relaxation as its bounding engine and prunes with the bound; the price is paid in node count, and how big that price is depends heavily on formulation strength (§13.3, §15.2).

**1.5.4** (i) **Keep nonconvexity, manage risk:** solve with a gradient-based local solver from many randomized starts (multi-start), report the best point *and* the spread of local optima found. Price: no optimality certificate — you know only that you searched, not that you finished. (ii) **Change the class:** replace the nonconvex pieces by convex approximations (linearize a bilinear term, use the epigraph/norm tricks of §2.2, or relax to an SOCP) and solve globally. Price: the answer is optimal for a *different, less faithful* model, so you must bound the modelling error — the trade-off stated as the design principle in §3.2.

## Solutions — 2.1 The modeling loop

**2.1.1** (1) **Name** variables, objective, constraints in words with units; (2) **Write** the mathematics; (3) **Classify** using the §1.5 map and choose a method; (4) **Solve**; (5) **Interrogate** the answer — active set, variables on bounds, plausibility, units; (6) **Fix and repeat**.
Beginners skip **step 5** (and, closely related, step 1). The cost: an answer that is optimal for a model nobody checked. Steps 2–4 are where the effort *feels* productive; step 5 is where the engineering is.

**2.1.2** Questions: (i) *Is negative flow meaningful in my formulation?* — if flow direction is encoded by sign it may be legitimate, so which convention did I write? (ii) *Which constraints are active, and is that physically sensible?* — if none are, cost has no floor. (iii) *Does cost depend on flow with the right sign?* — if cost enters as $\propto Q$ rather than $|Q|$ or $Q^2$, negative flow generates negative cost. Most likely defect: **cost linear in a signed flow with no lower bound**, so the model pays you to run the pipe backwards. Fixes: bound $Q \ge 0$ with a separate reverse-flow variable, or make cost a function of $|Q|$ via the $L_1$ trick of §2.2, plus check that head-loss equations are sign-consistent.

**2.1.3** Two examples (any discipline is fine; the pattern is what matters):
- *Structures:* a mass-minimized plate becomes infinitely thin and wide because only in-plane stress was constrained. Closes with buckling constraints and a minimum thickness bound.
- *Process:* a heat-exchanger network reaches perfect recovery because the model constrains only energy balance, not temperature-driving forces, letting heat flow up a zero or negative $\Delta T$. Closes with a minimum-approach-temperature constraint $\Delta T \ge \Delta T_{\min}$.
- *Controls:* a controller achieves zero tracking error by demanding unbounded actuator effort. Closes with actuator saturation limits and a rate limit.

**2.1.4**
```python
import numpy as np

def interrogate(x, f, cons=(), bounds=None, names=None, tol=1e-6):
    x = np.asarray(x, float)
    print(f"objective = {f(x):.6g}")
    names = names or [f"g{i+1}" for i in range(len(cons))]
    for nm, g in zip(names, cons):
        v = float(g(x))
        tag = "ACTIVE" if abs(v) <= tol else ("inactive" if v < 0 else "** VIOLATED **")
        print(f"  {nm:>10}: {v:+.6g}  {tag}")
    if bounds is not None:
        for k, (lo, hi) in enumerate(bounds):
            if lo is not None and abs(x[k]-lo) <= tol: print(f"  x[{k}] AT LOWER BOUND {lo}")
            if hi is not None and abs(x[k]-hi) <= tol: print(f"  x[{k}] AT UPPER BOUND {hi}")
    return x
```
Reuse this in §4.2, §10, §11 and §21.3; the habit of running it *before* reading the objective value is the entire content of §1.4.

## Solutions — 2.2 A formulation toolbox

**2.2.1** Epigraph trick with one new variable $t$:
$$\min_{x_1,x_2,t}\ t \quad\text{s.t.}\quad 2x_1 - x_2 \le t,\quad -x_1 + 4 \le t,\quad x_1 + x_2 - 3 \le t,\quad x_1 + 2x_2 \ge 1.$$
Three variables and four linear inequalities — an LP. The kinks of the original objective (where the identity of the maximizer changes) have become vertices of the feasible region, which is exactly where LP solvers are happy.

**2.2.2** $\|Ax-b\|_\infty = \max_i |a_i^\top x - b_i|$, so with a single $t$:
$$\min_{x,t}\ t\quad\text{s.t.}\quad -t \le a_i^\top x - b_i \le t,\quad i=1,\dots,m.$$
That is $2m$ inequalities and $n+1$ variables. The $L_1$ version needs one $t_k$ per residual: $2m$ inequalities but $n+m$ variables. So $L_\infty$ is the cheaper reformulation ($1$ extra variable vs $m$); both are LPs.

**2.2.3**
```python
import numpy as np, cvxpy as cp
rng = np.random.default_rng(1)
t = np.linspace(0, 10, 30); y = 2.0*t + 1.0 + rng.normal(0, 0.4, t.size)
y[[5, 20]] += np.array([15.0, -12.0])
a, b = cp.Variable(), cp.Variable(); res = a*t + b - y
for name, obj in [("L2", cp.sum_squares(res)), ("L1", cp.norm1(res)), ("Linf", cp.norm_inf(res))]:
    cp.Problem(cp.Minimize(obj)).solve(); print(f"{name:5s} slope={a.value:.3f} intercept={b.value:.3f}")
```

| fit | slope (true 2.0) | intercept (true 1.0) |
|---|---|---|
| $L_2$ | 1.702 | 2.566 |
| $L_1$ | 1.965 | 1.156 |
| $L_\infty$ | 0.240 | 10.175 |

$L_\infty$ is by far the **worst** — much worse than least squares — and this is predictable from the definition, not the data: minimizing the *maximum* residual makes the two outliers the only residuals that matter, so the fit positions itself to split the difference between them and ignores the 28 good points. Rule of thumb: the smaller the norm's exponent, the more outlier-robust ($L_1$ robust, $L_2$ sensitive, $L_\infty$ maximally sensitive). $L_\infty$ is the right choice when you must certify a worst-case bound (tolerance envelopes, approximation theory), not when your data has glitches.

**2.2.4** Introduce nonnegative slacks on the constraints you are willing to bend:
$$\min_{x,s_1,s_2}\ f(x) + \rho(s_1 + s_2)\quad\text{s.t.}\quad \delta(x) \le 5 + s_1,\quad m(x) \le 40 + s_2,\quad s_1,s_2 \ge 0,$$
with $\rho$ large relative to $f$'s scale (and note $s_1$, $s_2$ should be *scaled* to comparable units, e.g. express both as fractions of their limits, or the penalty silently prefers to violate whichever has the larger numerical units — §2.3).
Result $s_1 = 1.4$ mm, $s_2 = 0$ reads: *the specification is infeasible, and the minimum-violation repair is to relax the deflection limit from 5 mm to 6.4 mm; the mass limit can be met.* That is a sentence you can take to a design review — you now know which requirement to negotiate and by how much. Compare "infeasible," which tells you nothing.

**2.2.5** (a) **(ii)** — linear-fractional: exactly an LP via the Charnes–Cooper substitution *provided* numerator/denominator are affine and the denominator is strictly positive on $\mathcal{F}$. (b) **(i)** — a binary times a bounded continuous linearizes exactly with the four McCormick/big-$M$ inequalities $y \le Ux_1$, $y \le x_2$, $y \ge x_2 - U(1-x_1)$, $y \ge 0$ (§13.2). (c) **(iii)** — a genuine bilinear term: nonconvex, no exact convex reformulation; relaxations (McCormick) bound it but do not reproduce it. (d) **(i)** — the $L_1$ trick makes it an LP exactly.

## Solutions — 2.3 Scaling: the boring thing that ruins everything

**2.3.1** Use reference values of the right physical size and make every quantity dimensionless:
- Variables: $\tilde t = t/(2\times10^{-3})$, $\tilde L = L/3$. ($E$ is a parameter, so it needs no new variable — but it should be absorbed into the coefficients, not left multiplying a variable.)
- Constraint: divide by its own natural scale, $\sigma(x)/(250\times10^6) - 1 \le 0$, so the constraint reads "ratio $\le 1$" and its residual is $O(1)$.
- Objective: $\tilde f = m(x)/40$, so the objective and its gradient are $O(1)$.
Then all variables, constraint residuals, gradients and multipliers live near 1, tolerance settings mean what they say, and the multipliers are directly comparable to one another (§9.4).

**2.3.2** "Line search failed / step size became too small"; "maximum iterations reached" or "slow progress / no progress"; "singular or ill-conditioned Jacobian / matrix factorization failed" (also "problem may be infeasible" from an interior-point method, and LP messages about numerical trouble requiring a basis refactorization). None names scaling, and all three are routinely cured by it.

**2.3.3**
```python
import numpy as np

def sd_iters(kappa, x0, rtol=1e-6):
    Q = np.diag([1.0, float(kappa)]); x = np.array(x0, float)
    f0 = 0.5*x@Q@x; it = 0
    while 0.5*x@Q@x > rtol*f0: 
        g = Q@x; a = (g@g)/(g@Q@g); x = x - a*g; it += 1
    return it

for k in [1, 100, 10000]:
    bad = sd_iters(k, [1.0, 1.0/k])          # original coordinates
    good = sd_iters(1, [1.0, 1.0/np.sqrt(k)])  # after x2 = z2/sqrt(kappa): kappa -> 1
    print(f"kappa={k:>6}  unscaled iters={bad:>6}   rescaled iters={good}")
```

| $\kappa$ | iterations, original variables | after rescaling |
|---|---|---|
| 1 | 1 | 1 |
| $10^2$ | 346 | 1 |
| $10^4$ | 34 539 | 1 |

The substitution $x_2 = z_2/\sqrt{\kappa}$ turns $\tfrac12(x_1^2+\kappa x_2^2)$ into $\tfrac12(z_1^2+z_2^2)$: $\kappa = 1$, and exact-line-search steepest descent finishes in one step. A factor of 34 000 in cost, bought with one line of algebra and no change of algorithm. (Note also *why* steepest descent is the honest test vehicle: BFGS and CG solve any 2-D quadratic in at most two steps because they build curvature information, which masks the effect — see §7.4.)

**2.3.4** Because conditioning is a property of the whole system, not just the variables: the objective, the constraint residuals, and the multipliers all carry scales too. If constraint 1 is $\sigma(x) - 250\times10^6 \le 0$ (residuals $\sim10^8$) and constraint 2 is $\delta(x)/\delta_{\max} - 1 \le 0$ (residuals $\sim1$), then a feasibility tolerance of $10^{-6}$ is absurdly strict for the first and reasonable for the second; a merit function or penalty adding the two compares $10^8$ with $1$ and effectively ignores constraint 2; and the multipliers differ by $10^8$, so you cannot read them as prices side by side (§9.4). Fix: normalize **each constraint by its own limit** so all residuals are $O(1)$, in addition to rescaling variables and the objective.

## Solutions — 3.1 Definitions

**3.1.1** (a) **Convex** — a norm ball; chords of a ball stay inside (also: sublevel set of the convex function $\|x\|_2$). (b) **Not convex** — the sphere's chord passes through the interior, which is not in the set. (c) **Convex** — the region above a hyperbola in the positive quadrant is $\{x_1>0,\ x_2 \ge 1/x_1\}$, the epigraph-style sublevel set of the convex function $1/x_1$ on $x_1>0$. (d) **Convex** — an affine set; any combination of two solutions of $Ax=b$ with weights summing to 1 also solves it. (e) **Convex** — the region above the graph of the convex function $x_1^2$ (its epigraph). (f) **Not convex** — the parabola itself: the chord between $(-1,1)$ and $(1,1)$ passes through $(0,1)$, but the curve requires $x_2 = 0$ there.

**3.1.2** Let $z = \theta x + (1-\theta)y$ with $\theta\in[0,1]$. Since $\max\{\cdot,0\}$ is nondecreasing and $z \le \theta x + (1-\theta)y$ trivially, use monotonicity of the max plus $\max\{a+b,0\}\le\max\{a,0\}+\max\{b,0\}$ for the two nonnegative-weighted pieces:
$$f(z) = \max\{\theta x + (1-\theta)y,\ 0\} \le \max\{\theta x,0\} + \max\{(1-\theta)y,0\} = \theta\max\{x,0\} + (1-\theta)\max\{y,0\} = \theta f(x) + (1-\theta)f(y),$$
using $\max\{cx,0\} = c\max\{x,0\}$ for $c \ge 0$. The definition is easier because $f$ is **not differentiable** at $0$, so the Hessian test does not apply there at all. (Alternatively: $f = \max\{f_1,f_2\}$ of two affine functions — the pointwise-max rule of §3.3.)

**3.1.3** A convex problem needs a convex feasible set. $\{x : h(x) = 0\}$ for nonlinear $h$ is a curved surface, and curved surfaces are not convex. Concretely, $x_1^2+x_2^2=4$ contains $(2,0)$ and $(-2,0)$; their midpoint $(0,0)$ gives $0 \ne 4$, so the segment leaves the set. (The equivalent view: $h = 0$ is $h \le 0$ *and* $-h \le 0$, and a convex problem would need both $h$ and $-h$ convex — which forces $h$ affine.) The asymmetry is real: $x_1^2+x_2^2 \le 4$ *is* convex.

**3.1.4**
```python
import numpy as np

def convexity_probe(f, lo=-3, hi=3, n=20000, tol=1e-9, seed=0):
    rng = np.random.default_rng(seed)
    x, y = rng.uniform(lo, hi, n), rng.uniform(lo, hi, n)
    th = rng.uniform(0, 1, n)
    lhs = f(th*x + (1-th)*y); rhs = th*f(x) + (1-th)*f(y)
    worst = np.max(lhs - rhs)
    return ("no violation found" if worst <= tol else "NOT convex"), worst

print(convexity_probe(lambda x: x**2 - np.cos(x)))   # no violation found
print(convexity_probe(lambda x: x**2 - np.abs(x)))   # NOT convex, positive gap
```
$x^2-\cos x$ passes (indeed $f'' = 2+\cos x \ge 1 > 0$, so it is convex). $x^2-|x|$ fails, with a worst sampled violation of $\approx 0.235$. The cleanest hand witness is $x=-0.5$, $y=0.5$, $\theta=0.5$: the midpoint value is $f(0) = 0$, while the chord value is $\tfrac12 f(-0.5) + \tfrac12 f(0.5) = -0.25$ — the graph lies *above* its chord by $0.25$.
A **pass proves nothing**: it is a finite sample of an infinite condition, and it can miss violations confined to a small region (try restricting the range to $[1,3]$, where $x^2-|x| = x^2-x$ *is* convex). Use the probe to catch mistakes quickly; use the composition rules of §3.3 or CVXPY's DCP certificate when you need an actual guarantee.

## Solutions — 3.2 Why it matters

**3.2.1** Suppose $x^\star$ is a local minimum and some feasible $y$ has $f(y) < f(x^\star)$. Set $x_\theta = \theta y + (1-\theta)x^\star$. Convexity of $\mathcal{F}$ gives $x_\theta \in \mathcal{F}$ for all $\theta\in[0,1]$. Convexity of $f$ gives
$$f(x_\theta) \le \theta f(y) + (1-\theta)f(x^\star) < f(x^\star)\quad\text{for all }\theta\in(0,1].$$
As $\theta \downarrow 0$, $x_\theta \to x^\star$, so every neighbourhood of $x^\star$ contains a strictly better feasible point — contradicting local optimality. Hence no such $y$ exists. $\square$
If $f$ is nonconvex, the **second** inequality fails: the segment is still feasible, but $f$ along it may rise before it falls, so a better point $y$ can exist without any nearby improvement. That bump is precisely a local minimum that is not global.

**3.2.2** $f(x) = x^4 - 3x^3 + 2$ has $f' = 4x^3-9x^2 = x^2(4x-9)$, giving stationary points $x = 0$ (an inflection with $f'=0$, not a minimum) and $x = 9/4$ (the global min). A cleaner example: $f(x) = x^4 - 4x^2 + 0.5x$ has two local minima, at $x \approx -1.4445$ ($f \approx -4.7148$, **global**) and $x \approx 1.3819$ ($f \approx -3.3009$, local only). A local method started at $x_0 = 2$ descends to $1.3819$ and reports success; started at $x_0 = -2$ it reports $-1.4445$. Neither run can detect the other basin, because both satisfy the same first- and second-order conditions ($f' = 0$, $f'' > 0$) — the conditions are *local by construction*, and no amount of local information distinguishes a local from a global minimum.

**3.2.3** The certificate is a **dual feasible point** — a set of multipliers $(\mu \ge 0, \lambda)$ — whose dual objective $q(\mu,\lambda)$ is a *lower bound* on the optimal value (weak duality, §5.2, §9.5). If you exhibit a feasible $x$ and multipliers with
$$q(\mu,\lambda) \;=\; f(x)\qquad(\text{equivalently, zero duality gap}),$$
then $x$ is optimal and no further search is needed. For LP this is the dual solution and the check $c^\top x = b^\top y$ (§5.2); for convex NLP it is the KKT multipliers (§9.3, §9.5). Convexity is what guarantees the gap can be closed (strong duality, under mild conditions).

**3.2.4** **For:** a convex model gives a global answer with a certificate, scales to large size, needs no tuning or multi-start, and gives trustworthy sensitivities/shadow prices — so the *decision* it supports is defensible. Example: replacing an exact nonconvex pressure-drop relation by a conservative convex bound in a pipe-sizing model yields a design guaranteed feasible for the true physics and provably optimal for the bound. **Against:** the answer is optimal for a model you know is wrong; the modelling error can exceed the optimization gain, and it may systematically bias the design (a conservative convex bound always costs money). If you take the convex route you must report **which approximation you made, in which direction it errs, and a bound or estimate on the resulting suboptimality/conservatism** — ideally by evaluating the true model at the convex solution (§21.3).

## Solutions — 3.3 Recognizing convexity without computing anything

**3.3.1** (a) $\|Ax-b\|_2$ is a norm (convex atom) composed with the affine map $x \mapsto Ax-b$ → convex; $\|x\|_1$ is a norm → convex; a nonnegative-weighted sum of convex functions is convex. ✔ (This is the lasso/elastic-net family.)
(b) $c^\top x$ affine, $e^{(\cdot)}$ convex and nondecreasing → $e^{c^\top x}$ convex (composition with affine also suffices directly); $\max\{0, d^\top x - 1\}$ is a pointwise max of two affine functions → convex; sum → convex. ✔
(c) $\|x\|_2$ convex → $1 - \|x\|_2$ concave; $-\log(u)$ is convex and *nonincreasing* in $u$, and a convex nonincreasing function of a **concave** function is convex → convex on the domain $\|x\|_2<1$. ✔ (This is the log-barrier for a ball, §9.6.)

**3.3.2** With $g(u)=u^2$ (convex but *not* nondecreasing on $\mathbb{R}$) and $f(x)=|x|-1$ (convex), $g(f(x)) = (|x|-1)^2$ is **not convex**: at $x=-1,\ 1$ the value is $0$, but at the midpoint $x=0$ it is $1 > 0$ — the chord dips below the graph. The composition rule fails exactly because $g$ decreases on $u<0$, where $f$ takes values. If $f(x)=|x| \ge 0$, then $f$'s range lies where $g$ *is* nondecreasing, and $g(f(x)) = x^2$ is convex. Moral: the monotonicity must hold on the *range of $f$*, which is why $\mathtt{cp.square}$ of a nonnegative expression is accepted while $\mathtt{cp.square}$ of a general one composed with something convex is not.

**3.3.3**
```python
import cvxpy as cp
x = cp.Variable(); y = cp.Variable(nonneg=True)
for name, e in [("log(y)", cp.log(y)), ("inv_pos(y)", cp.inv_pos(y)), ("-log(y)", -cp.log(y)),
                ("square(pos(x))", cp.square(cp.pos(x))),
                ("log(1+exp(x))", cp.log(1 + cp.exp(x))), ("logistic(x)", cp.logistic(x)),
                ("sqrt(square(x))", cp.sqrt(cp.square(x)))]:
    print(f"{name:18s}{e.curvature}")
```
| expression | curvature reported |
|---|---|
| `cp.log(y)` | CONCAVE |
| `cp.inv_pos(y)` | CONVEX |
| `-cp.log(y)` | CONVEX |
| `cp.square(cp.pos(x))` | CONVEX |
| `cp.log(1 + cp.exp(x))` | QUASILINEAR |
| `cp.logistic(x)` | CONVEX |
| `cp.sqrt(cp.square(x))` | QUASICONVEX |

The two mathematically convex but uncertified cases are **`cp.log(1 + cp.exp(x))`** and **`cp.sqrt(cp.square(x))`**. The first is $\log(1+e^x)$, genuinely convex, but written as concave-$\log$ of a convex argument it matches no DCP rule (CVXPY can only certify that it is monotone, hence quasilinear); the rewrite is the dedicated atom **`cp.logistic(x)`** (or `cp.log_sum_exp(cp.hstack([0, x]))`). The second is $|x|$, convex, but concave-$\sqrt{}$ of a convex argument breaks the rule; the rewrite is **`cp.abs(x)`**. General lesson: when DCP refuses, you usually need the *right atom*, not a different problem.

**3.3.4** Four warning signs, three of them real nonconvexities:
1. $x_1x_2 = 10$ — a **product of variables** *and* a **nonlinear equality**: doubly nonconvex. Relaxing to $x_1x_2 \ge 10$ with $x_1,x_2>0$ *is* convex (it is $x_2 \ge 10/x_1$, and $\mathtt{cp.inv\_pos}$ handles it); if the equality is physically required, you are in nonconvex territory (Part III/V) or must use a bilinear-relaxation global solver.
2. $\sin(x_3) \le 0.5$ — **trigonometric function of a variable**: nonconvex (the feasible set is a union of infinitely many intervals). If $x_3$ can be restricted a priori to a single monotone branch, e.g. $x_3 \in [-\pi/2,\pi/2]$, the constraint becomes $x_3 \le \arcsin 0.5$, which is linear.
3. $x_4 \in \{0,1\}$ — **integrality**: not convex, but it does not cost global optimality; it is handled by branch and bound (Part IV), whose relaxation replaces it with $0 \le x_4 \le 1$.
4. $\|x\|_2 \le 5$ — **convex** (norm ball); no action needed. Include it in your scan only to confirm it is harmless.

## Solutions — 3.4 The named convex classes

**3.4.1** (a) **LP**. (b) **QP** — convex quadratic objective, linear (bound) constraints. (c) **SOCP** — a second-order cone constraint in epigraph form (it is also an LP-free way of writing $\min\|Fx+g\|_2$). (d) **SDP** — the largest eigenvalue of an affine matrix function; equivalently $\min t$ s.t. $tI - (A_0+\sum x_iA_i) \succeq 0$. (e) **SOCP** — $\|Ax\|_2 \le d^\top x$ is exactly a cone constraint.

**3.4.2** The hierarchy is about *expressive power*, not cost. All four are handled by the same interior-point machinery, but the per-iteration linear algebra grows dramatically: an LP iteration works with sparse vectors, whereas an SDP iteration manipulates dense matrix variables whose size is quadratic in the matrix dimension and requires eigen-decompositions. So expressiveness increases while tractable size *decreases* — millions of variables for LP, hundreds to a few thousand for SDP. The practical error: modelling something as an SDP because it is elegant (SDP relaxations of hard combinatorial problems are the classic case), then discovering the formulation is intractable at real size. Always check whether a cheaper class in the hierarchy suffices.

**3.4.3**
```python
import numpy as np, cvxpy as cp
rng = np.random.default_rng(0); A = rng.normal(size=(6,3)); b = rng.normal(size=6)
x = cp.Variable(3)
p = cp.Problem(cp.Minimize(cp.sum_squares(A@x - b)), [cp.sum(x) == 1, x >= 0, x <= 1])
p.solve()
print(x.value, p.value, p.constraints[0].dual_value)
```
Result: $x^\star \approx (0,\;0.0139,\;0.9861)$, objective $\approx 3.38495$, the bound $x_1 \ge 0$ **active** (so component 1 is excluded), the other bounds inactive, and the equality multiplier $\approx -2.2808$.
Class: **QP** (convex quadratic objective, linear constraints). Dimensionally, the equality multiplier is $\partial f^\star/\partial(\text{right-hand side})$ — the rate of change of the sum-of-squares objective per unit change in the budget $\mathbf{1}^\top x = 1$, i.e. "units of objective per unit of total weight" (§5.1, §9.4). Its sign says the objective would *decrease* if the budget were increased slightly.

**3.4.4** Three box constraints allow the *corner* case $|d_x|=|d_y|=|d_z|=5$, which has magnitude $\|d\|_2 = 5\sqrt3 \approx 8.66$ mm — so the box formulation is **more permissive** than intended (it inscribes the true ball inside a box), and the resulting design may violate the real 5 mm requirement by up to 73 %. The error is therefore *unsafe*, not conservative. The correct constraint is the single Euclidean one
$$\|d(x)\|_2 \le 5,$$
a second-order cone constraint → the model is an **SOCP** (still convex, still globally solvable, at very manageable extra cost). If you deliberately want the conservative direction instead, use $\|d\|_1 \le 5$ or $\|d\|_\infty \le 5/\sqrt3$ — both LPs — and say so.

## Solutions — 4.1 Form and geometry

**4.1.1** *If an LP has an optimal solution, at least one vertex of the feasible polyhedron is optimal.* Because the objective is linear, its level sets are parallel hyperplanes; sweeping them across a polyhedron, the last contact is at a face, and every nonempty face of a polyhedron contains a vertex. So it suffices to search the finitely many vertices instead of the continuum. **Practical limitation:** the number of vertices grows combinatorially — choosing which $n$ of $m$ constraints are active gives up to $\binom{m}{n}$ candidates — so enumeration is hopeless beyond tiny problems. Simplex exploits the theorem intelligently by walking only *improving* edges (§4.3).

**4.1.2** Vertices: $(0,0)$, $(2,0)$, $(3,1)$, $(0,4)$. (Check $(3,1)$: $x_1+x_2 = 4$ ✓ and $x_1-x_2 = 2$ ✓.)
(a) $c = (1,1)$: values $0, 2, 4, 4$ → **tie** between $(3,1)$ and $(0,4)$, and along the whole edge joining them; the objective is parallel to the constraint $x_1+x_2\le4$. **Non-unique optimum.**
(b) $c = (1,-1)$: values $0, 2, 2, -4$ → tie between $(2,0)$ and $(3,1)$ (value 2) — also non-unique, along that edge.
(c) $c = (-1,-1)$: values $0,-2,-4,-4$ → unique maximizer $(0,0)$.
The non-uniqueness in (a) and (b) happens exactly when $c$ is parallel to an active constraint's normal — the boundary case of the cone condition in §5.7.

**4.1.3** The LP assumes **constant returns to scale**: each unit of an activity consumes the same resources and earns the same margin regardless of volume, so the trade-off is exactly linear and its best point is at an end of the range. Extreme answers become suspicious when the real world has nonlinear effects the model omits: quantity discounts or learning curves (increasing returns), congestion or overtime premiums (decreasing returns), fixed changeover costs, contractual minimum volumes, or risk/diversification concerns. If any of those matters, the model — not the LP's extremeness — is at fault; the fix is a nonlinear objective (Part III) or binaries for fixed charges (§13.3), not distrust of the solver.

**4.1.4** Example: $\max\ -x_1 - x_2$ s.t. $x_1 + x_2 \ge 1$, $x \ge 0$. The feasible set is unbounded (you may take $x_1 \to \infty$), yet the optimum is finite: $-1$, attained anywhere on the segment $x_1+x_2 = 1$. Now change $c$ to $(1,1)$ (i.e. maximize $x_1+x_2$): the problem is unbounded.
**Moral:** an unbounded feasible set is *necessary but not sufficient* for an unbounded problem. Unboundedness is a property of the pair $(\mathcal{F}, c)$: it occurs only when $\mathcal{F}$ contains a ray along which $c$ improves forever. This is why "unbounded" always means *a missing constraint in the direction the objective likes*, not merely a big feasible region (§1.3).

## Solutions — 4.2 Worked Example 1 — allocating two limited resources

**4.2.1** Candidate vertices come from intersecting pairs of constraints (including the axes):

| Vertex | Defined by | Feasible? | $z = 5x_1+4x_2$ |
|---|---|---|---|
| $(0,0)$ | $x_1=0,\ x_2=0$ | yes | 0 |
| $(4,0)$ | $C$, $x_2=0$ | yes ($A$: $24\le24$ ✓, $B$: $4\le6$ ✓) | 20 |
| $(3,1.5)$ | $A\cap B$ | yes ($C$: $3\le4$ ✓) | **21** |
| $(0,3)$ | $B$, $x_1=0$ | yes ($A$: $12\le24$ ✓) | 12 |
| $A\cap C$ | $x_1=4 \Rightarrow x_2=0$ | duplicates $(4,0)$ | 20 |

So $x^\star = (3,\,1.5)$ and $z^\star = 21$. (Solving $A\cap B$: $6x_1+4x_2=24$ and $x_1+2x_2=6$; doubling the second gives $2x_1+4x_2=12$, and subtracting gives $4x_1=12$.)

**4.2.2** At $x^\star=(3,1.5)$: $A$: $18+6=24$ → **active**; $B$: $3+3=6$ → **active**; $C$: $3 < 4$ → inactive, slack $1$ unit.
Summary: *"The workshop is limited by alloy supply and finishing time; the packing line is not a bottleneck (one unit of headroom). More packing capacity is worthless; more alloy or more finishing hours would both help."*

**4.2.3**
```python
import numpy as np, cvxpy as cp
from scipy.optimize import linprog

A, b = [[6, 4], [1, 2], [1, 0]], [24, 6, 4]
r = linprog([-5, -4], A_ub=A, b_ub=b, bounds=[(0, None)]*2, method="highs")
print("linprog x* =", r.x, " z* =", -r.fun, " slacks =", np.array(b) - np.array(A) @ r.x)

x = cp.Variable(2, nonneg=True)
cons = [6*x[0] + 4*x[1] <= 24, x[0] + 2*x[1] <= 6, x[0] <= 4]
p = cp.Problem(cp.Maximize(5*x[0] + 4*x[1]), cons); p.solve(solver=cp.HIGHS)
print("cvxpy   x* =", x.value, " z* =", p.value)
```
Output: `x* = [3. 1.5]`, `z* = 21.0`, `slacks = [0. 0. 1.]` from both — matching 4.2.1–4.2.2 exactly. The two independent routes agreeing is your error check (Preface).

**4.2.4** The **packing line (C)** is worth nothing, because it is not binding: the plan uses 3 of the 4 permitted units. For $C$ to acquire value, the optimum would have to be pushed against $x_1 \le 4$ — which happens if product 1 becomes more attractive or the other resources become more plentiful. Concretely: raise $c_1$ above 6 (then the optimum jumps to $(4,0)$-type vertices, §5.7), or raise the alloy supply above 28 kg (then $A$ stops binding and $C$ takes over, §5.6). Either way the *active set changes*, which is the general rule: a constraint's price is nonzero only when it is active.

## Solutions — 4.3 How LPs are actually solved

**4.3.1**

| | Simplex | Interior point |
|---|---|---|
| Iterates | vertices of the polyhedron, moving along edges | points strictly inside, following a smooth central path |
| Worst case | exponential (contrived examples exist) | polynomial |
| Warm start | **excellent** — resumes from the previous vertex in a few pivots | poor — must essentially restart from the centre |
| Choose it when | you re-solve many related LPs, or you need an exact vertex/basis | one very large sparse LP solved once |

**4.3.2** **Simplex** (usually dual simplex) belongs inside branch and bound. The reason is total, not per-LP, cost: each child node differs from its parent by one variable bound, so the parent's optimal basis is nearly optimal for the child and simplex finishes in a handful of pivots. An interior-point method cannot exploit that similarity and would pay near-full price at every one of thousands of nodes. Simplex also returns an exact vertex and basis, which branch and bound needs in order to choose a fractional variable to branch on (§14.1).

**4.3.3**
```python
import numpy as np
from scipy.optimize import linprog
for m in ["highs-ds", "highs-ipm"]:
    r = linprog([-5, -4], A_ub=[[6,4],[1,2],[1,0]], b_ub=[24,6,4],
                bounds=[(0,None)]*2, method=m)
    print(f"{m:10s} x*={np.round(r.x,6)} z*={-r.fun:.6f} nit={getattr(r,'nit',None)}")
for m in ["highs-ds", "highs-ipm"]:
    r = linprog([-1,-1], A_ub=[[1,1],[1,0],[0,1]], b_ub=[2,1,1],
                bounds=[(0,None)]*2, method=m)
    print(f"{m:10s} x*={np.round(r.x,6)} duals={np.round(-r.ineqlin.marginals,6)}")
```
On (E) both methods return $x^\star = (3,\,1.5)$ and $z^\star = 21$ — identical answers, different paths (simplex takes a couple of pivots; the IPM takes a handful of Newton steps). On the **degenerate** LP both return $x^\star=(1,1)$ with value 2, but the reported duals need not agree: simplex reports the multipliers of whichever optimal *basis* it stopped at, while an interior-point method converges toward the analytic centre of the optimal dual face and tends to report an interior (often "spread out") dual such as $(0.5,0.5,0.5)$. Same primal answer, different prices — a preview of §5.8, and the reason the course insists on the two-sided perturbation test.

**4.3.4** **Argument:** hand tableau work drills arithmetic bookkeeping you will never repeat in practice, and it illuminates neither the geometry (Figure 4.1 does) nor the economics (§5 does). It also fails at the thing hand work is *for*: catching modelling errors. **The three skills required:** (i) enumerate vertices of a 2-D LP and evaluate the objective at each; (ii) identify the active set at a solution and read its engineering meaning; (iii) compute the duals from complementary slackness and verify the certificate $c^\top x = b^\top y$.
At 2 a.m. use **(iii)**: the certificate is a two-line arithmetic check that proves optimality independently of the solver, requires no re-solve, and catches sign errors, unit errors, and mis-entered data all at once (§5.2, §21.3).

## Solutions — 5.1 The dual, read through its units

**5.1.1** Primal (E) is $\max c^\top x$ s.t. $Ax\le b$, $x\ge0$ with $c = (5,4)$, $A = \begin{pmatrix}6&4\\1&2\\1&0\end{pmatrix}$, $b = (24,6,4)$. The dual is $\min b^\top y$ s.t. $A^\top y \ge c$, $y \ge 0$:
$$\min_{y}\ 24y_A + 6y_B + 4y_C \quad\text{s.t.}\quad 6y_A + y_B + y_C \ge 5,\quad 4y_A + 2y_B \ge 4,\quad y \ge 0.$$
**Units:** $y_A$ = \$/kg of alloy; $y_B$ = \$/hour of finishing time; $y_C$ = \$/unit of packing capacity. (Check: $24\,\text{kg} \times \$/\text{kg} = \$$ ✓.)
**Interpretation:** the first constraint says *one unit of product 1 consumes 6 kg, 1 h and 1 packing slot, and valued at the internal prices that bundle must be worth at least the \$5 margin it earns* — i.e. product 1 is not a bargain. The second says the same for product 2. The objective says: value the whole endowment as cheaply as possible subject to no activity being a bargain.

**5.1.2** The dual is a **marginal opportunity value, not a purchase price**. $y_R = 20$ means: *given the current plan and prices, one additional kilogram would raise optimal profit by \$20.* It is measured in objective-units per constraint-unit (\$ per kg), and it is an *increment* — the value of relaxing the constraint by one unit, valid only locally (§5.6). Its relation to the market price: the \$40/\$30 margins already have the *purchase* cost of material netted out, so \$20 is the maximum **premium above the current purchase price** you should be willing to pay for extra supply. If your supplier offers extra material at \$15/kg over contract, take it; at \$25/kg, decline.

**5.1.3** The objective is in kg and the constraint in mm, so the dual has units of **kg per mm**. Its numerical value supports a sentence like: *"relaxing the deflection limit from 5 mm to 6 mm would save 3.2 kg"* (if $y = 3.2$). This is exactly how a structural engineer negotiates a specification: the dual converts a *requirement* into a *cost*, so the tightness of the spec can be traded against mass on a common footing. (Note the sign convention: for a minimization with a $\le$ constraint, relaxing the limit reduces the objective, so many solvers report the multiplier as negative; always confirm the sign by a two-sided perturbation, §5.4.)

**5.1.4** Because the dual is being used as a *certificate*, and only the cheapest valuation is tight enough to prove anything. Any price vector making all activities non-bargains gives an upper bound $b^\top y \ge z^\star$ (weak duality, §5.2); inflated prices give a *loose* bound — true but uninformative, proving nothing about optimality. Minimizing $b^\top y$ drives the bound down until it exactly meets the achieved profit, which is what converts "here is a plan" into "here is a plan *and a proof no plan is better*." Economically, inflated prices would also overstate scarcity and lead you to reject activities that are in fact worth running.

## Solutions — 5.2 Weak duality: where certificates come from

**5.2.1**
$$c^\top x \;\underset{(1)}{\le}\; (A^\top y)^\top x \;\underset{(2)}{=}\; y^\top(Ax) \;\underset{(3)}{\le}\; y^\top b.$$
(1) uses **dual feasibility** $A^\top y \ge c$, multiplied componentwise by $x \ge 0$ — this is where **$x \ge 0$** enters (multiplying an inequality by a negative number would flip it). (2) is transposition, an identity, no hypothesis. (3) uses **primal feasibility** $Ax \le b$, multiplied componentwise by $y \ge 0$ — this is where **$y \ge 0$** enters. Both sign conditions are load-bearing; drop either and the chain breaks.

**5.2.2** $x = (2,1)$: check $A$: $12+4 = 16 \le 24$ ✓; $B$: $2+2 = 4\le6$ ✓; $C$: $2\le4$ ✓ — feasible, with $c^\top x = 10+4 = 14$.
$y = (1,0,0)$: check $6(1)+0+0 = 6 \ge 5$ ✓ and $4(1)+0 = 4 \ge 4$ ✓, $y \ge 0$ ✓ — dual feasible, with $b^\top y = 24$.
Weak duality: $14 \le z^\star \le 24$ ✓. The pair **proves** the optimum lies in $[14, 24]$ — a genuine, algorithm-free bracket. It does **not** prove either point is optimal, since $14 \ne 24$; the gap of 10 is the residual uncertainty. (We know from §4.2 that $z^\star=21$, comfortably inside.)

**5.2.3** With only weak duality you retain *bounds* but lose *proof of optimality*: you can say "the optimum is between 14 and 24" but never "this point is optimal," because the gap may be irreducible (a *duality gap*). Practically, you lose the stopping certificate — you cannot know when to stop searching. This is precisely the situation in integer programming, where the LP relaxation gives a bound and the best found integer solution gives the other side; their difference is the **MIP gap** (§14.3). Branch and bound's whole job is to shrink that gap to zero (or to an accepted tolerance) by refining the relaxation until the bound meets the incumbent.

**5.2.4**
```python
import numpy as np

def certificate(A, b, c, x, y, tol=1e-8):
    A, b, c, x, y = map(lambda v: np.asarray(v, float), (A, b, c, x, y))
    pf = np.all(A@x <= b + tol) and np.all(x >= -tol)
    df = np.all(A.T@y >= c - tol) and np.all(y >= -tol)
    px, dy = c@x, b@y
    if not pf: return f"x infeasible"
    if not df: return f"y infeasible (no valid bound)"
    if abs(px - dy) <= tol*max(1, abs(px)): return f"OPTIMAL, both certified: {px:.6f}"
    return f"bracket only: {px:.6f} <= z* <= {dy:.6f} (gap {dy-px:.6f})"

A, b, c = [[6,4],[1,2],[1,0]], [24,6,4], [5,4]
print(certificate(A, b, c, [3, 1.5], [0.75, 0.5, 0.0]))   # OPTIMAL, both certified: 21.0
print(certificate(A, b, c, [3, 1.5], [1.0, 0.5, 0.0]))    # bracket only: 21 <= z* <= 27
print(certificate(A, b, c, [3, 1.5], [0.0, 0.5, 0.0]))    # y infeasible (no valid bound)
```
The optimal pair certifies $z^\star = 21$. Inflating $y_A$ to 1 keeps $y$ feasible but loosens the bound to 27 — true but no longer a proof. Setting $y_A = 0$ violates $6y_A+y_B+y_C\ge5$, and an infeasible $y$ gives **no bound at all** — a common and dangerous mistake when duals are read out of a badly converged solve.

## Solutions — 5.3 Complementary slackness — both directions

**5.3.1** Constraint side: $y_i^\star(b_i - a_i^\top x^\star) = 0$ — *a resource with slack has zero price*; you cannot pay for something you have not run out of. Variable side: $x_j^\star\big((A^\top y^\star)_j - c_j\big) = 0$ — *an activity you actually run breaks even exactly at the internal prices*; if it earned more than its inputs are worth, the prices would understate scarcity, and the dual's minimization forbids that.
Introductions usually give only the **constraint side**. But the constraint side alone only tells you which duals are *zero*; the nonzero ones come from the **variable side**, which supplies the equations you actually solve. Omit it and duals can only be read off a solver — hence "magic."

**5.3.2** From the **constraint side**: constraint 2 has slack, so $y_2^\star = 0$; constraints 1 and 3 are active, so $y_1^\star$ and $y_3^\star$ are unrestricted by this direction (they may be positive or zero). From the **variable side**: $x_2^\star = 7 > 0$ and $x_3^\star = 3 > 0$, so dual constraints 2 and 3 hold with *equality*: $(A^\top y^\star)_2 = c_2$ and $(A^\top y^\star)_3 = c_3$. Since $x_1^\star = 0$, dual constraint 1 need only hold as an inequality, $(A^\top y^\star)_1 \ge c_1$ — its slack is the **reduced cost** of the unused activity (§5.5). That is two equations for the two unknown duals $y_1, y_3$, obtained with no algebra beyond reading the solution.

**5.3.3** At $x^\star = (3,1.5)$: $C$ is slack ($3<4$) → $y_C = 0$. Both $x_1>0$ and $x_2>0$ → both dual constraints are tight. The columns of $A$ are $(6,1,1)$ for $x_1$ and $(4,2,0)$ for $x_2$:
$$6y_A + y_B + y_C = 5, \qquad 4y_A + 2y_B = 4.$$
With $y_C=0$, halve the second: $2y_A+y_B = 2$; subtract from the first: $4y_A = 3$, so
$$\boxed{y_A = 0.75\ \$/\text{kg},\qquad y_B = 0.5\ \$/\text{h},\qquad y_C = 0.}$$
All $y\ge0$ ✓ (dual feasible). Certificate: $b^\top y = 24(0.75) + 6(0.5) + 4(0) = 18+3 = 21 = z^\star$ ✓ — both primal and dual are proved optimal.

**5.3.4**
```python
import cvxpy as cp
x = cp.Variable(2, nonneg=True)
cons = [6*x[0]+4*x[1] <= 24, x[0]+2*x[1] <= 6, x[0] <= 4]
p = cp.Problem(cp.Maximize(5*x[0]+4*x[1]), cons); p.solve(solver=cp.HIGHS)
print("duals:", [round(float(c.dual_value), 6) for c in cons])
for bA in (25, 23):
    y = cp.Variable(2, nonneg=True)
    q = cp.Problem(cp.Maximize(5*y[0]+4*y[1]),
                   [6*y[0]+4*y[1] <= bA, y[0]+2*y[1] <= 6, y[0] <= 4]); q.solve(solver=cp.HIGHS)
    print(f"b_A={bA}: z*={q.value:.4f}  rate={(q.value-21)/(bA-24):+.4f}")
```
Reported duals: $(0.75,\ 0.5,\ 0.0)$ — identical to the hand computation. Perturbation: $b_A = 25$ gives $z^\star = 21.75$ (rate $+0.75$) and $b_A = 23$ gives $z^\star = 20.25$ (rate $+0.75$). All three routes agree, and the two one-sided rates match each other — the signature of a **non-degenerate** optimum (contrast §5.8).

## Solutions — 5.4 Worked Example 1, continued — computing the duals by hand, then by machine

**5.4.1**
- *Alloy:* "An extra kilogram of alloy is worth \$0.75 of profit. Pay any premium below \$0.75/kg for additional supply; refuse above it."
- *Finishing time:* "An extra finishing hour is worth \$0.50. Overtime at less than \$0.50/h of *incremental* cost is profitable; more than that is not."
- *Packing line:* "Extra packing capacity is worth \$0. Do not spend anything on it — we have a unit of headroom already."

**5.4.2** Extra alloy is worth \$0.75/kg and costs \$0.60/kg of premium, so the net gain is \$0.15/kg. **Accept.** Estimated profit change $\approx 5 \times (0.75 - 0.60) = +\$0.75$; total profit $\approx 21 + 5(0.75) - 5(0.60) = 21.75$.
**Assumption to check:** that $y_A = 0.75$ still holds over the *whole* 5 kg — i.e. that $b_A = 29$ is inside the range over which the active set is unchanged. It is not: §5.6 will show the range is $12 \le b_A \le 28$, so the last kilogram is worth **\$0** and the true gain is smaller. This is exactly the extrapolation error the text warns about — a shadow price is a slope valid only until the next kink.

**5.4.3**
```python
import numpy as np
from scipy.optimize import linprog

def solve_E(b):
    r = linprog([-5, -4], A_ub=[[6,4],[1,2],[1,0]], b_ub=b, bounds=[(0,None)]*2, method="highs")
    return -r.fun

def two_sided(solve_fn, nominal, i, delta=1.0):
    z0 = solve_fn(nominal)
    up, dn = list(nominal), list(nominal)
    up[i] += delta; dn[i] -= delta
    return (solve_fn(up) - z0)/delta, (z0 - solve_fn(dn))/delta

b = [24., 6., 4.]
for i, nm in enumerate("ABC"):
    r_up, r_dn = two_sided(solve_E, b, i)
    print(f"{nm}: rate up = {r_up:+.4f}   rate down = {r_dn:+.4f}")
```

| resource | rate (+1) | rate ($-1$) | reported dual | verdict |
|---|---|---|---|---|
| A (alloy) | $+0.75$ | $+0.75$ | 0.75 | agree — trustworthy |
| B (finishing) | $+0.50$ | $+0.50$ | 0.50 | agree — trustworthy |
| C (packing) | $0.00$ | $0.00$ | 0.00 | agree — genuinely worthless |

All three constraints pass the two-sided test, so this optimum is non-degenerate and the duals may be used as prices. Keep this function: it is the single most useful diagnostic in Part II, and §5.8 shows the case where it *fails*.

**5.4.4** (i) **The primal plan is often re-computed anyway, but the prices drive investment.** Which mix to run this week is an operational decision that will be re-solved tomorrow with new data; whether to buy a machine, sign a supply contract, or authorize overtime is a capital decision, and the duals price exactly those options. (ii) **Duals compress the model into negotiable numbers.** A plant manager cannot audit a 40 000-variable plan, but can immediately act on "an alloy kilogram is worth \$0.75" — and can sanity-check it against experience, catching model errors the primal would hide.
**When the primal matters more:** when the plan itself is the deliverable and must be executed as computed — a crew roster, a cutting pattern, a delivery route, a unit-commitment schedule. There the answer *is* $x^\star$, and the duals are only diagnostic.

## Solutions — 5.5 Reduced cost: pricing a new activity

**5.5.1** Opportunity cost of the bundle at the internal prices: $2y_A + 1\,y_B = 2(0.75) + 1(0.5) = \$2.00$. Reduced cost $= \text{margin} - \text{opportunity cost} = 3 - 2 = +\$1.00 > 0$.
Positive reduced cost → **the product is worth introducing**; every unit produced adds about \$1 of profit at the current prices. (Contrast the text's Example-1 candidate, whose reduced cost was $-5$ and was rejected.)

**5.5.2**
```python
import numpy as np, cvxpy as cp
x = cp.Variable(3, nonneg=True)
p = cp.Problem(cp.Maximize(5*x[0] + 4*x[1] + 3*x[2]),
               [6*x[0] + 4*x[1] + 2*x[2] <= 24,
                x[0]   + 2*x[1] + 1*x[2] <= 6,
                x[0]                      <= 4])
p.solve(solver=cp.HIGHS); print("z* =", p.value, " x* =", np.round(x.value, 6))
```
Result: $z^\star = 24.0$ with $x^\star = (3,\,0,\,3)$ — profit rose from 21 to **24**, and the new product entirely displaced product 2.
The total increase is not "reduced cost × units" because the reduced cost is a **marginal** quantity computed at the *old* prices. As the new activity enters, it consumes scarce alloy and hours, the active set and hence the duals change, and the marginal value of further units falls. Reduced cost answers "should the first unit enter?" — a yes/no screening question — not "how much will we gain in total." For the total you re-solve, exactly as here.

**5.5.3** Opportunity cost $= 3(0.75) + 2(0.5) = 2.25 + 1.00 = \$3.25$. Reduced cost $= 4 - 3.25 = +\$0.75 > 0$, so this candidate is *also* attractive (though less so per unit than the first, whose reduced cost was \$1.00).
The break-even margin is where the reduced cost hits zero: margin $= \$3.25$. Below \$3.25/unit it should not enter the plan; above, it should. Note this threshold is valid only while the duals $(0.75, 0.5, 0)$ remain valid — introducing the activity changes them.

**5.5.4** In **column generation** you never build the full LP. You solve a restricted master problem containing a small subset of activities (columns), read off its duals, and then solve a *pricing subproblem*: "over the enormous implicit set of candidate columns, find one with positive reduced cost." Add it, re-solve, repeat; stop when no column prices out favourably — at which point the restricted LP's solution is optimal for the full problem, certified by the duals. Standard practice in **airline crew scheduling** (columns = legal pairings of flights) and **cutting-stock / paper and steel trim optimization** (columns = cutting patterns); also vehicle routing and rolling-stock scheduling.
The essential requirement: you must be able to solve the **pricing subproblem cheaply** — usually a shortest-path or knapsack problem over the structure that defines legal columns (§16, §13.4). Without a fast pricing oracle the method collapses, because enumerating columns is exactly what you were avoiding.

## Solutions — 5.6 Right-hand-side ranging: how far a shadow price is valid

**5.6.1** While $A$ and $B$ are both active, the optimum is their intersection: from $6x_1+4x_2 = b_A$ and $x_1+2x_2 = 6$,
$$x_1 = \frac{b_A - 12}{4}, \qquad x_2 = \frac{36 - b_A}{8}.$$
Feasibility/basis conditions: $x_1 \ge 0 \Rightarrow b_A \ge 12$; $x_2 \ge 0 \Rightarrow b_A \le 36$; $x_1 \le 4$ (constraint $C$) $\Rightarrow b_A \le 28$. The binding pair gives
$$\boxed{12 \le b_A \le 28}.$$
Inside this interval $y_A = 0.75$ exactly. (Sanity check at $b_A = 24$: $x_1 = 3$, $x_2 = 1.5$ ✓.) At $b_A = 28$ the plan reaches $x = (4,1)$, constraint $C$ becomes active, and extra alloy becomes worthless.

**5.6.2** The nominal supply is 24 kg, and the price holds only to 28 kg. So the first **4** kg are worth \$0.75 each and the **fifth** is worth \$0.00:
$$\Delta z = 4(0.75) + 1(0) = \$3.00,$$
versus the naive extrapolation \$3.75 — an overestimate of 25 %. The fifth kilogram is worth **nothing**, because by then the packing line has become the binding constraint. Revisiting 5.4.2: at a \$0.60/kg premium the true gain is $3.00 - 5(0.60) = \$0.00$ — the deal is exactly break-even, not the \$0.75 profit the shadow price suggested.

**5.6.3**
```python
import numpy as np
from scipy.optimize import linprog
for bA in [8, 12, 16, 20, 24, 28, 32, 36, 40]:
    r = linprog([-5,-4], A_ub=[[6,4],[1,2],[1,0]], b_ub=[bA,6,4],
                bounds=[(0,None)]*2, method="highs")
    print(f"b_A={bA:3d}  x*={np.round(r.x,3)}  z*={-r.fun:7.3f}")
```

| segment | active constraints | slope $dz^\star/db_A$ |
|---|---|---|
| $0 \le b_A \le 12$ | $A$ and $x_1=0$ | $1.0$ (an alloy kg makes $\tfrac14$ unit of product 2, worth \$1) |
| $12 \le b_A \le 28$ | $A$ and $B$ | $0.75$ |
| $b_A \ge 28$ | $B$ and $C$ | $0$ (alloy no longer binds; $z^\star \equiv 24$) |

Sample values: $z^\star(8) = 8$, $z^\star(12) = 12$, $z^\star(24) = 21$, $z^\star(28) = 24$, $z^\star(40) = 24$. Kinks at $b_A = 12$ and $b_A = 28$; the slopes $1.0 > 0.75 > 0$ are **decreasing**, which is exactly concavity — each additional kilogram is worth no more than the last. (For a maximization, $z^\star$ is always concave in $b$; that is a theorem, and a useful sanity check on any sweep you compute.)

**5.6.4** Say this: *"The \$0.75/kg figure is the value of the **next** kilogram, not of 200 kilograms. Our own numbers show alloy stops being the bottleneck at 28 kg — 4 kg from now. Beyond that point extra alloy is worth exactly zero, because the packing line takes over. So of the 200 kg, roughly 4 are worth \$0.75 and 196 are worth nothing: about \$3 of value for \$80 of cost."*
**Correct procedure:** re-solve the model at the proposed quantity ($b_A = 224$) rather than extrapolating — it costs milliseconds. Then, since the bottleneck will have moved, re-solve *with the packing-line constraint also relaxed* to see whether a combined investment (alloy contract **plus** packing capacity) is worthwhile. Large changes require re-solving; shadow prices are for small ones.

## Solutions — 5.7 Cost ranging: how far the *plan* is valid

**5.7.1** **RHS ranging (§5.6):** the resource amounts $b$ move; $A$ and $c$ are fixed. You track the *optimal value* $z^\star(b)$, and the shadow price is its slope; the range is the interval over which that slope is constant. **Cost ranging (§5.7):** the objective coefficients $c$ move; $A$ and $b$ are fixed. You track the *optimal plan* $x^\star$, which is piecewise *constant* in $c$; the range is the interval over which the same vertex stays optimal. One asks "what is another kilogram worth?", the other asks "do we change what we make?"

**5.7.2** The vertex $(3,1.5)$ is defined by the active constraints $A$ and $B$, with outward normals $a_A = (6,4)$ and $a_B = (1,2)$. It stays optimal exactly while $c$ lies in the cone they span:
$$c = \alpha(6,4) + \beta(1,2), \qquad \alpha,\beta \ge 0.$$
*Range for $c_1$ (with $c_2 = 4$):* solve $6\alpha + \beta = c_1$ and $4\alpha + 2\beta = 4$. The second gives $\beta = 2 - 2\alpha$; substituting, $6\alpha + 2 - 2\alpha = c_1$, so $\alpha = (c_1-2)/4$ and $\beta = (6-c_1)/2$. Requiring $\alpha \ge 0$ and $\beta \ge 0$:
$$\boxed{2 \le c_1 \le 6}.$$
*Range for $c_2$ (with $c_1 = 5$):* solve $6\alpha + \beta = 5$, $4\alpha + 2\beta = c_2$. From the first $\beta = 5-6\alpha$; substituting, $4\alpha + 10 - 12\alpha = c_2$, so $\alpha = (10-c_2)/8$ and $\beta = 5 - 6(10-c_2)/8 = (3c_2-10)/4$. Nonnegativity gives
$$\boxed{10/3 \le c_2 \le 10}.$$
(Check: $\alpha,\beta$ at the nominal $c = (5,4)$ are $0.75$ and $0.5$ — the shadow prices of §5.3.3, as the text notes.)

**5.7.3** Slopes in the $(x_1,x_2)$ plane: constraint $A$, $6x_1+4x_2 = 24$, has slope $-6/4 = -1.5$; constraint $B$, $x_1+2x_2=6$, has slope $-1/2 = -0.5$. The objective level line $c_1x_1 + 4x_2 = z$ has slope $-c_1/4$. For the sweep of the level line to last touch the polygon at the vertex $A \cap B$, its slope must lie between the two:
$$-1.5 \le -\frac{c_1}{4} \le -0.5 \quad\Longleftrightarrow\quad 0.5 \le \frac{c_1}{4} \le 1.5 \quad\Longleftrightarrow\quad 2 \le c_1 \le 6\ \checkmark$$
Same answer, and this is the "pinched slope" observation of Figure 4.1 made quantitative.

**5.7.4**
```python
import numpy as np
from scipy.optimize import linprog
for c1 in [1.9, 2, 5, 6, 6.1]:
    r = linprog([-c1,-4], A_ub=[[6,4],[1,2],[1,0]], b_ub=[24,6,4],
                bounds=[(0,None)]*2, method="highs")
    print(f"c1={c1:4.1f}  x*={np.round(r.x,3)}  z*={-r.fun:.3f}")
```

| $c_1$ | $x^\star$ | $z^\star$ |
|---|---|---|
| 1.9 | $(0,3)$ | 12.0 |
| 2.0 | $(3,1.5)$ | 12.0 |
| 5.0 | $(3,1.5)$ | 21.0 |
| 6.0 | $(4,0)$ | 24.0 |
| 6.1 | $(4,0)$ | 24.4 |

The plan is $(3,1.5)$ throughout $[2,6]$ and jumps to a neighbouring vertex just outside either end — exactly the predicted range. **At an endpoint** the objective is parallel to one active constraint, so two vertices (and the whole edge between them) are optimal and tie: at $c_1=2$ both $(0,3)$ and $(3,1.5)$ give $z=12$; at $c_1=6$ both $(3,1.5)$ and $(4,0)$ give $z=24$. The solver may report either; the *values* agree, so nothing is wrong — but if a downstream decision depends on which plan you get, you must break the tie yourself (a secondary objective), not leave it to the solver.

**5.7.5** The new margin \$4.20 lies inside the range $[2, 6]$, so **the plan does not change**: still $x^\star = (3,\ 1.5)$. The new profit is $4.20(3) + 4(1.5) = 12.60 + 6.00 = \$18.60$, a fall of \$2.40 — which is exactly $x_1^\star \Delta c_1 = 3 \times (-0.80)$.
The most useful sentence: **"Nothing about our operations needs to change — we lose \$2.40 of margin, not a production decision."** That converts a price shock into a routine number and prevents an unnecessary and disruptive re-plan. (Add the safety note: the plan would only change if the margin fell below \$2.00.)

## Solutions — 5.8 Worked Example 2 — degeneracy, or: shadow prices are not always unique

**5.8.1** Try $x = (1,2)$: ① $1+2 = 3$ ✓ active; ② $x_2 = 2$ ✓ active; ③ $1+4 = 5$ ✓ active. Objective $z = 1 + 4 = 5$. No feasible point does better (① alone caps $x_1+2x_2 \le 3 + x_2 \le 5$). So $x^\star = (1,2)$, $z^\star = 5$, with **three active constraints in two dimensions** — the vertex is over-determined, so the optimum is **primal degenerate**. Any two of the three constraints already pin the point down; the third passes through it redundantly.

**5.8.2** Dual: $\min\ 3y_1 + 2y_2 + 5y_3$ s.t. (column of $x_1$) $y_1 + y_3 \ge 1$, (column of $x_2$) $y_1 + y_2 + 2y_3 \ge 2$, $y \ge 0$.

| $y$ | $y_1+y_3\ge1$ | $y_1+y_2+2y_3\ge2$ | feasible | objective |
|---|---|---|---|---|
| $(1,1,0)$ | $1\ge1$ ✓ | $2\ge2$ ✓ | yes | $3+2+0 = 5$ |
| $(0,0,1)$ | $1\ge1$ ✓ | $2\ge2$ ✓ | yes | $0+0+5 = 5$ |
| $(0.5,0.5,0.5)$ | $1\ge1$ ✓ | $2\ge2$ ✓ | yes | $1.5+1+2.5 = 5$ |
| $(1,0,0)$ | $1\ge1$ ✓ | $1\ge2$ ✗ | **no** | — |

The first three are all dual feasible with objective $5 = z^\star$, so by the certificate argument all three are **optimal duals**. Hence $y_1$ is $1$, $0$, or $0.5$ depending on which optimal dual you happen to be handed: there is no such thing as "the" shadow price of ① here. Two solvers can legitimately report different prices for the same model.

**5.8.3**
```python
import numpy as np, cvxpy as cp
x = cp.Variable(2, nonneg=True)
cons = [x[0]+x[1] <= 3, x[1] <= 2, x[0]+2*x[1] <= 5]
p = cp.Problem(cp.Maximize(x[0]+2*x[1]), cons); p.solve(solver=cp.HIGHS)
print("z* =", p.value, " duals =", [round(float(c.dual_value),4) for c in cons])
for db in (+0.1, -0.1):
    y = cp.Variable(2, nonneg=True)
    q = cp.Problem(cp.Maximize(y[0]+2*y[1]),
                   [y[0]+y[1] <= 3+db, y[1] <= 2, y[0]+2*y[1] <= 5]); q.solve(solver=cp.HIGHS)
    print(f"b1 = 3{db:+.1f}: z* = {q.value:.4f}  one-sided rate = {(q.value-5)/db:+.3f}")
```
HiGHS reports duals $(0,\,0,\,1)$ — the *second* row of the table above; another solver or another option setting could report $(1,1,0)$. The perturbation test gives:
- $b_1 = 3.1$: $z^\star = 5.00$, rate $\mathbf{0.00}$ — relaxing ① gains nothing;
- $b_1 = 2.9$: $z^\star = 4.90$, rate $\mathbf{+1.00}$ — tightening ① costs 1 per unit.

Geometrically: at $x^\star$ three lines cross. Pushing ① *outward* leaves the point pinned by ② and ③, so nothing improves (right derivative 0). Pulling ① *inward* immediately drags the optimum along ②, costing 1 per unit (left derivative 1). The reported single number describes one of these two behaviours and silently ignores the other.

**5.8.4** Write the objective as $z = x_1+2x_2 = (x_1+x_2) + x_2$. To maximize, push $x_2$ as high as allowed: $x_2 = \min(2, b_1)$, and then $x_1 = b_1 - x_2$, giving $z = b_1 + \min(2,b_1)$, capped by ③ at 5. Hence for $b_1 \ge 0$
$$z^\star(b_1) = \min\big(2b_1,\ b_1 + 2,\ 5\big),$$
with slope 2 on $[0,2]$, slope 1 on $[2,3]$, and slope 0 beyond — so there is a kink **exactly at the nominal $b_1 = 3$**. (Check: $z^\star(2.9) = 4.9$, $z^\star(3) = 5$, $z^\star(3.1) = 5$ ✓, matching 5.8.3.)
The left derivative is $1$ and the right derivative is $0$. A kink has **no derivative**, so "the slope" does not exist and the question is malformed. The correct object is the **subdifferential** (the set of generalized slopes), here the interval
$$\partial z^\star(3) = [0,\ 1],$$
and every optimal dual's $y_1$ lies in exactly that interval — matching the table in 5.8.2, where $y_1 \in \{0, 0.5, 1\}$. The solver is not wrong; it is reporting one element of a set.

**5.8.5** **The three habits:** (1) *Detect* — if the number of active constraints exceeds the number of variables (in the relevant subspace), suspect degeneracy; (2) *never* build a business case on a single reported dual from a degenerate model; (3) *prefer the two-sided perturbation test* whenever a price drives a real decision, degenerate or not.
**What I would compute:** re-solve with $b_1$ perturbed both ways by amounts matching the *actual* investment size (not $\pm0.1$ — if the \$2 M buys 20 units of capacity, test $b_1 + 20$), and also test relaxing ① *jointly* with ② and ③, since a degenerate vertex means several constraints bind at once and relieving one alone may buy nothing.
**What I would report:** *"Relieving constraint ① alone yields \$0 of additional profit — the reported price of 1.0 is an artifact of three constraints binding simultaneously. To gain anything, ① must be relaxed together with ②; that combined investment yields \$X. I recommend against the ①-only proposal."* Along with the two one-sided rates and the joint-relaxation figure, so the decision rests on re-solves rather than on a slope that does not exist.

## Solutions — 6.1 Total unimodularity

**6.1.1** $A$ is **totally unimodular** if every square submatrix has determinant $0$, $+1$ or $-1$. **Theorem:** if $A$ is TU and $b$ is integral, every vertex of $\{x : Ax\le b,\ x\ge0\}$ has integer coordinates.
*Argument:* a vertex is the unique solution of a square nonsingular subsystem of the active constraints, so by Cramer's rule each coordinate is $\det(\text{numerator matrix})/\det(\text{submatrix of }A)$. The denominator is $\pm1$ by TU (nonzero because the subsystem is invertible), and the numerator is an integer determinant *because its entries are entries of $A$ and of $b$, all integers*. An integer divided by $\pm1$ is an integer. — **$b$'s integrality is used in the numerator**: with fractional $b$ the numerator is fractional and the conclusion fails (see 6.3).

**6.1.2**
```python
import numpy as np, itertools

def is_TU(A):
    A = np.asarray(A, float); m, n = A.shape
    for k in range(1, min(m, n) + 1):
        for rs in itertools.combinations(range(m), k):
            for cs in itertools.combinations(range(n), k):
                d = round(np.linalg.det(A[np.ix_(rs, cs)]))
                if d not in (-1, 0, 1):
                    return False, (rs, cs, d)
    return True, None

arcs = [(0,1),(0,2),(1,2),(1,3),(2,3)]
N = np.zeros((4,5))
for j,(u,v) in enumerate(arcs): N[u,j] = 1; N[v,j] = -1
print("node-arc:", is_TU(N)[0])                                    # True
rows = [np.eye(3).repeat(3, axis=1)[i] for i in range(3)]          # or build explicitly
T = np.array([[1,1,0],[1,0,1],[0,1,1]])
print("triangle:", is_TU(T))                                       # (False, ((0,1,2),(0,1,2),-2))
```
(a) **TU** ✓ — every square submatrix of a node–arc incidence matrix has determinant $0,\pm1$. (b) **TU** ✓ — the assignment matrix (three row-sum rows, three column-sum rows) is the incidence matrix of a bipartite graph. (c) **Not TU**: the full $3\times3$ determinant is $-2$ (magnitude 2), so the theorem does not apply.

**6.1.3** By symmetry try $x = (t,t,t)$: each constraint reads $2t \le 1$, so $t = 0.5$ and the LP value is $1.5$. That is optimal (summing the three constraints gives $2\mathbf{1}^\top x \le 3$, so $\mathbf{1}^\top x \le 1.5$ — the bound is attained). The best **integer** solution picks one edge: value $1$. Gap $= 0.5$, i.e. the LP over-estimates by 50 %.
Cause: the graph contains an **odd cycle**. On an odd cycle you can put $\tfrac12$ on every edge without violating any degree constraint, but no integral matching can cover more than $\lfloor k/2\rfloor$ of $k$ vertices. Bipartite graphs contain no odd cycles, which is exactly why bipartite matching is integral and general matching is not. (Verify in code: `cp.Variable(3, nonneg=True)` gives $1.5$; `boolean=True` gives $1$.)

**6.1.4** In a **directed** node–arc matrix each column has exactly one $+1$ and one $-1$. Any square submatrix either has a column with fewer than two nonzeros (expand along it and recurse) or has every column containing both $+1$ and $-1$, in which case the rows sum to zero and the determinant is $0$. That argument never needs bipartiteness — orientation supplies the cancelling signs. In an **undirected** edge–node matrix both entries are $+1$, so there is nothing to cancel; the rows sum to zero only if the vertices can be 2-coloured so that each edge joins the colours — i.e. only if the graph is bipartite. An odd cycle breaks it, giving $\det = \pm2$ as in 6.1.2(c).
**Recognition rule:** *directed flow structures are safe; undirected pairing structures are safe only when the two sides are genuinely separate groups.* If your model is "flow along arcs with conservation at nodes" or "match group X to group Y," drop the integrality and solve an LP. If it pairs items *within* one group (general matching, cliques, odd-cycle structures), keep the integers and expect Part IV.

## Solutions — 6.2 Worked Example 3 — the assignment problem

**6.2.1** Optimal: **T1→J2 (4), T2→J4 (4), T3→J3 (2), T4→J1 (1)** with total cost $4+4+2+1 = \mathbf{11}$.
Efficient reasoning: column J1 has two very cheap entries ($C_{21}=1$, $C_{41}=1$) and row 4's cheapest options are $J1 = 1$ and $J2 = 3$; row 3 is dominated by $J3 = 2$; row 1's cheapest is $J2 = 4$. Assigning T3→J3 and T4→J1 (both near-forced) leaves T1, T2 for J2, J4: $C_{12}+C_{24} = 4+4 = 8$ versus $C_{14}+C_{22} = 6+11 = 17$. Total $2+1+8 = 11$. Confirm no better: any assignment must pay $\ge1$ in row 2 and $\ge1$ in row 4, and both cheap cells are in the same column J1, so one of them pays at least $3$ more.

**6.2.2**
```python
import numpy as np, cvxpy as cp
from scipy.optimize import linear_sum_assignment
C = np.array([[13,4,7,6],[1,11,5,4],[6,7,2,8],[1,3,5,9]])

X = cp.Variable((4,4), nonneg=True)                       # (i) LP, no integrality
lp = cp.Problem(cp.Minimize(cp.sum(cp.multiply(C, X))),
                [cp.sum(X, axis=1) == 1, cp.sum(X, axis=0) == 1]); lp.solve(solver=cp.HIGHS)
print("LP cost:", lp.value); print(np.round(X.value, 6))

r, c = linear_sum_assignment(C)                            # (ii) Hungarian
print("Hungarian:", list(zip(r.tolist(), c.tolist())), C[r, c].sum())

B = cp.Variable((4,4), boolean=True)                       # (iii) MILP
mi = cp.Problem(cp.Minimize(cp.sum(cp.multiply(C, B))),
                [cp.sum(B, axis=1) == 1, cp.sum(B, axis=0) == 1]); mi.solve(solver=cp.HIGHS)
print("MILP cost:", mi.value)
```
All three give cost **11**, and the LP returns exactly
$$X^\star = \begin{pmatrix}0&1&0&0\\0&0&0&1\\0&0&1&0\\1&0&0&0\end{pmatrix},$$
pure 0/1 from a solver never told about integers — total unimodularity at work (§6.1).
At $2000\times2000$ use **`linear_sum_assignment`** (the Hungarian/Jonker–Volgenant algorithm): it is $O(n^3)$ and exploits the structure directly, whereas a general LP has 4 million variables and a MILP solver would waste effort on branching machinery that can never be needed. *Specialist algorithm for a recognized special structure* is the rule.

**6.2.3** Greedy: cheapest cell overall is a tie at $1$ — say $C_{21} = 1$ (T2→J1); delete row 2, column 1. Cheapest remaining is $C_{33} = 2$ (T3→J3); delete. Cheapest remaining among rows $\{1,4\}$, columns $\{2,4\}$ is $C_{42} = 3$ (T4→J2); delete. T1 is forced to J4: $C_{14} = 6$. Total $1+2+3+6 = \mathbf{12}$ — a gap of 1 (9 % above optimal). (Taking the other tied cell $C_{41}$ first gives $1 + 2 + 4 + 4 = 11$; greedy's answer depends on tie-breaking, which is itself a warning.)
Greedy went wrong at its **first** decision: by consuming column J1 with T2, it stranded T4 — whose only cheap option was J1 — and forced T1 into the expensive J4. The optimum *declines* the tempting $C_{21}=1$ and lets T4 take J1 instead. This is the structural failure of greedy on assignment problems: local cheapness ignores the opportunity cost imposed on other rows, which is exactly what the LP duals account for.

**6.2.4** It is not wrong — you get the same answer, 11 — but it is wasteful, and specifically it costs: (i) the solver invokes **branch and bound** machinery, so instead of one LP solve you may get a root relaxation plus node processing, presolve for integers, and cut generation; (ii) you lose meaningful **dual values** (a MILP has no clean shadow prices), forfeiting the sensitivity analysis of §5; (iii) at scale, solve times can differ by orders of magnitude, and the model becomes hard to warm-start or embed in a larger loop.
**The one check:** solve the LP relaxation and *look at the answer*. If it comes back integral, you are done and the certificate is the LP's own optimality (the answer is a feasible integer point achieving the LP bound, so it must be optimal for the integer problem too). If it comes back fractional, you have lost only one LP solve, and Part IV's branch and bound starts from exactly that relaxation. This "solve first, check integrality after" habit costs nothing and is safer than trying to prove TU by hand.

## Solutions — 6.3 The family worth recognizing

**6.3.1** Shortest path, max flow, **min-cost flow**, transportation, assignment, bipartite matching. **Min-cost flow contains all the others.**
- *Shortest path:* min-cost flow of one unit from source to sink, arc costs = lengths, uncapacitated.
- *Max flow:* min-cost flow with zero arc costs and a unit reward on the sink arc (or maximize flow subject to capacities).
- *Transportation:* min-cost flow on a bipartite graph, supplies at one side, demands at the other, no intermediate nodes.
- *Assignment:* transportation with all supplies and demands equal to 1.
- *Bipartite matching:* assignment with 0/1 costs (or a feasibility question — does a perfect matching exist).

**6.3.2** (a) **Not TU.** Routing a van through 15 cities and returning is the *travelling salesman problem*: the offending feature is the **subtour-elimination requirement** (a set of arcs with degree 2 at every node can form several disjoint loops), which cannot be expressed by flow-conservation rows and needs exponentially many constraints or extra binaries. Integrality is emphatically not free here.
(b) **TU flow structure** — a transportation problem. Provided supplies and demands are integers, solve the LP and collect an integral shipping plan for free.
(c) **TU flow structure** — a $40\times40$ assignment/bipartite matching problem (preferences enter as costs). Use `linear_sum_assignment` or an LP. *But:* if the nurse rules include things like "no more than 3 night shifts per fortnight" or "at least one senior per shift," those are **side constraints** coupling arcs, TU is destroyed, and it becomes a MILP (§13.4).

**6.3.3**
```python
import numpy as np, cvxpy as cp
# (i) fractional supplies
C = np.array([[1.,2.],[3.,1.]]); s = np.array([1.5,1.5]); d = np.array([1.,2.])
Y = cp.Variable((2,2), nonneg=True)
p = cp.Problem(cp.Minimize(cp.sum(cp.multiply(C,Y))),
               [cp.sum(Y,axis=1)==s, cp.sum(Y,axis=0)==d]); p.solve(solver=cp.HIGHS)
print("cost", p.value); print(np.round(Y.value,4))

# (ii) side constraint on the 3x3 assignment
C3 = np.array([[9,2,7],[6,4,3],[5,8,1]], float)
r  = np.array([[1,2,3],[4,3,2],[1,4,4]], float)
for kind in ("LP", "MILP"):
    X = cp.Variable((3,3), nonneg=True) if kind=="LP" else cp.Variable((3,3), boolean=True)
    q = cp.Problem(cp.Minimize(cp.sum(cp.multiply(C3,X))),
                   [cp.sum(X,axis=1)==1, cp.sum(X,axis=0)==1,
                    cp.sum(cp.multiply(r,X)) <= 5.5]); q.solve(solver=cp.HIGHS)
    print(kind, "cost", round(q.value,4)); print(np.round(X.value,4))
```
(i) Cost $3.5$ with $Y = \begin{pmatrix}1&0.5\\0&1.5\end{pmatrix}$ — **fractional**, exactly as the theorem's integrality-of-$b$ hypothesis warns. The matrix is still TU; the data is not integral, so the vertices are not integral. (Half a truckload is meaningful for tonnes of grain and meaningless for containers — which is a modelling question, not a solver question.)
(ii) LP relaxation: cost **9.9** with
$$X_{\text{LP}} = \begin{pmatrix}0&1&0\\0.1&0&0.9\\0.9&0&0.1\end{pmatrix}$$
— **fractional**, because the side constraint is not part of the bipartite structure. The binary model gives cost **10.0** with the assignment M1→T2, M2→T3, M3→T1 (resource use $2+2+1 = 5 \le 5.5$ ✓). Note the unconstrained optimum of §6.2 (cost 9) uses resources $2+4+4 = 10$ and is now infeasible; the side constraint costs 1 unit of objective, and the LP bound 9.9 under-estimates the true 10.0 by 0.1 — the LP-relaxation gap that branch and bound must close.

**6.3.4** You still get three things. (i) A **valid bound**: the LP optimum is a lower bound (for minimization) on the integer optimum — here $9.9 \le 10.0$ — so you immediately know how much the integrality can possibly cost you, which is often enough to make the decision. (ii) A **starting point and a branching guide**: the fractional variables tell you exactly where the integer structure is violated (here $x_{21},x_{23},x_{31},x_{33}$), and those are the variables to branch on. (iii) A **feasibility check** on the rest of the model, at LP speed. Part IV's branch and bound *begins* by solving precisely this relaxation at the root node (§14.1) and uses the bound to prune; so the LP you "wasted" is literally the first step of the exact algorithm. The only cost of trying is one LP solve, typically milliseconds.

## Solutions — 7.1 Optimality conditions: when can you stop?

**7.1.1** $\nabla f = (3x_1^2 - 3,\; 2x_2) = 0$ gives $x_1 = \pm1$, $x_2 = 0$: two stationary points, $(1,0)$ and $(-1,0)$.
$\nabla^2 f = \begin{pmatrix}6x_1 & 0\\ 0 & 2\end{pmatrix}$.
- At $(1,0)$: eigenvalues $6$ and $2$, both $>0$ → **strict local minimum**, $f = -2$.
- At $(-1,0)$: eigenvalues $-6$ and $2$, mixed → **saddle**, $f = 2$.

It is **not global**: $f \to -\infty$ as $x_1 \to -\infty$ (the cubic dominates), so the problem is unbounded below and no global minimum exists. This is the standard trap — a perfectly valid local minimum in an unbounded problem.

**7.1.2** *Necessary but not sufficient:* if $\nabla f \ne 0$ then the step $d = -\varepsilon\nabla f$ reduces $f$ for small $\varepsilon$ (§0.1), so a minimum forces $\nabla f = 0$; but the converse fails because maxima and saddles are also stationary. *Second order:* if some direction had negative curvature, moving along it would decrease $f$ (the quadratic term dominates once the linear term is zero), so $\succeq 0$ is necessary; strict positive definiteness makes the quadratic term strictly positive in every direction, guaranteeing $f$ increases — hence sufficient for a *strict* local minimum.
**Inconclusive example:** $f(x) = x^3$ at $x=0$ has $f'=0$ and $f''=0$ ($\succeq0$), yet $0$ is neither a min nor a max. Compare $f(x) = x^4$ (same derivatives at 0, but a genuine minimum). The second-order test cannot distinguish them; you need the third/fourth-order term.

**7.1.3**
```python
import numpy as np

def classify_stationary(grad, hess, x, gtol=1e-8, rtol=1e-10):
    g = np.asarray(grad(x), float)
    if np.linalg.norm(g) > gtol:
        return f"not stationary (|grad| = {np.linalg.norm(g):.2e})"
    w = np.linalg.eigvalsh(np.asarray(hess(x), float))
    tol = rtol * max(1.0, np.max(np.abs(w)))
    if np.all(w >  tol): return "strict local MINIMUM"
    if np.all(w < -tol): return "strict local MAXIMUM"
    if np.any(w > tol) and np.any(w < -tol): return "SADDLE"
    return "INCONCLUSIVE (semidefinite)"

grad = lambda x: np.array([3*x[0]**2 - 3, 2*x[1]])
hess = lambda x: np.array([[6*x[0], 0.0], [0.0, 2.0]])
print(classify_stationary(grad, hess, [ 1.0, 0.0]))   # strict local MINIMUM
print(classify_stationary(grad, hess, [-1.0, 0.0]))   # SADDLE
print(classify_stationary(grad, hess, [ 0.5, 0.0]))   # not stationary
```

**7.1.4** **Certified:** a *first-order* condition — the point is (numerically) stationary. That is all. **Not certified:** that it is a minimum rather than a saddle or maximum; that it is a *global* minimum (unless the problem is convex, §3.2); that it is feasible, if constraints exist (a constrained solver must also certify feasibility and complementarity, §9.7); and that the gradient being used is *correct* — a wrong gradient has its own spurious zeros.
**Two checks:** (i) **curvature** — evaluate the Hessian (or its action on a few random directions) and confirm no negative eigenvalue; equivalently, perturb $x^\star$ in several random directions by a small amount and confirm $f$ increases in all of them. (ii) **gradient verification** — compare the analytic gradient against a central difference at a generic nearby point (§0.1, §12.1); a stalled solver very often means a broken derivative rather than a converged one. A third, cheap check: re-solve from a few different starting points (multi-start) to see whether the same point is found.

## Solutions — 7.2 The descent framework

**7.2.1** Descent condition: $\nabla f(x_k)^\top p_k < 0$.
(a) $p = -g$: $g^\top(-g) = -\|g\|^2 < 0$ whenever $g \ne 0$ ✓ — always a descent direction.
(b) $p = -H^{-1}g$ with $H \succ 0$: $g^\top(-H^{-1}g) = -g^\top H^{-1}g < 0$, because $H \succ 0 \Rightarrow H^{-1} \succ 0$ ✓.
(c) If $H$ is indefinite, $g^\top H^{-1}g$ can be *negative*, making $\nabla f^\top p > 0$: **the "Newton step" points uphill**. It is solving for a stationary point of the local model, and if that model is a saddle, the step heads for the saddle rather than downhill. Remedies (§7.4, §7.5): modify $H$ (add $\nu I$ until positive definite), or use a trust region, which handles indefiniteness naturally by minimizing the model inside a ball.

**7.2.2** Let $\phi(\alpha) = f(x+\alpha p) = \tfrac12(x+\alpha p)^\top Q(x+\alpha p) = \tfrac12 x^\top Qx + \alpha p^\top Qx + \tfrac{\alpha^2}{2}p^\top Qp$. With $g = Qx$,
$$\phi'(\alpha) = p^\top g + \alpha\, p^\top Qp = 0 \quad\Longrightarrow\quad \alpha^\star = -\frac{g^\top p}{p^\top Qp}.$$
(Valid since $p^\top Qp > 0$ for $Q\succ0$, which also makes $\phi$ strictly convex, so this is the minimum.) For $p = -g$:
$$\alpha^\star = -\frac{g^\top(-g)}{(-g)^\top Q(-g)} = \frac{g^\top g}{g^\top Qg},$$
the formula used in §7.3 and §0.4.

**7.2.3**
```python
import numpy as np
Q = np.diag([1.0, 10.0]); f = lambda x: 0.5*x@Q@x; grad = lambda x: Q@x

def descend(f, grad, x0, direction, alpha_rule, tol=1e-8, maxit=100000):
    x = np.array(x0, float); it = 0
    while np.linalg.norm(grad(x)) > tol and it < maxit:
        p = direction(x); x = x + alpha_rule(x, p)*p; it += 1
    return x, it

sd_dir   = lambda x: -grad(x)
exact_a  = lambda x, p: -(grad(x)@p)/(p@Q@p)
fixed_a  = lambda x, p: 1.0/np.max(np.linalg.eigvalsh(Q))
print("exact line search:", descend(f, grad, [10,1], sd_dir, exact_a)[1], "iterations")
print("fixed 1/lmax     :", descend(f, grad, [10,1], sd_dir, fixed_a)[1], "iterations")
```
Both converge; the exact line search takes roughly 70 iterations to $\|\nabla f\|\le10^{-8}$ and the fixed step $\alpha = 1/\lambda_{\max} = 0.1$ takes several times more. Neither escapes the $\kappa$-proportional rate of §7.3 — a *better step length* cannot fix a *bad direction*, which is the whole point of §7.4.

**7.2.4** The misleading word is **locally** (equivalently, "fastest" per unit of *Euclidean* length). Steepest descent maximizes the instantaneous rate of decrease per unit step measured in the Euclidean norm — but the Euclidean norm has no relation to the geometry of $f$. In Taylor terms, it uses only the **first-order model**, which contains no curvature information; it therefore cannot know that a step of a given Euclidean length buys very different amounts of progress in different directions. Newton's method effectively measures length in the norm $\|d\|_{H} = \sqrt{d^\top Hd}$ defined by the curvature, which is why it points at the minimizer of a quadratic exactly (§7.3). "Steepest" is norm-dependent; the choice of norm is the algorithm.

## Solutions — 7.3 Worked Example 4 — the zigzag, in exact numbers

**7.3.1** $Q = \operatorname{diag}(1,4)$, so $\kappa = 4$. Predictions: $\alpha = \dfrac{2}{1+\kappa} = \dfrac25 = 0.4$ (constant, because $x_0 = (\kappa c, c)$ with $c = 1$), and the ratio $\Big(\dfrac{\kappa-1}{\kappa+1}\Big)^2 = \Big(\dfrac35\Big)^2 = 0.36$.
*Iteration 1:* $g_0 = Qx_0 = (4,4)$. $\alpha = \dfrac{g^\top g}{g^\top Qg} = \dfrac{32}{16 + 4(16)} = \dfrac{32}{80} = 0.4$ ✓. Then $x_1 = (4,1) - 0.4(4,4) = (2.4,\,-0.6)$. $f(x_0) = \tfrac12(16+4) = 10$; $f(x_1) = \tfrac12(5.76 + 4(0.36)) = \tfrac12(7.2) = 3.6$; ratio $0.36$ ✓.
*Iteration 2:* $g_1 = (2.4, -2.4)$, $\alpha = \dfrac{11.52}{5.76+4(5.76)} = 0.4$, $x_2 = (2.4,-0.6) - 0.4(2.4,-2.4) = (1.44,\,+0.36)$, $f = \tfrac12(2.0736 + 4(0.1296)) = 1.296$; ratio $0.36$ ✓. Note the **sign of $x_2$ flips** each step — the zigzag, in the arithmetic.

**7.3.2**
```python
import numpy as np
Q = np.diag([1.0, 4.0]); f = lambda x: 0.5*x@Q@x
x = np.array([4.0, 1.0]); fp = f(x)
print(f"k=0  x=({x[0]:+.6f},{x[1]:+.6f})  f={f(x):.6f}")
for k in range(1, 7):
    g = Q@x; a = (g@g)/(g@Q@g); x = x - a*g
    print(f"k={k}  alpha={a:.6f}  x=({x[0]:+.6f},{x[1]:+.6f})  f={f(x):.6f}  ratio={f(x)/fp:.6f}")
    fp = f(x)
```

| $k$ | $\alpha$ | $x_k$ | $f$ | ratio |
|---|---|---|---|---|
| 0 | — | $(4,\,1)$ | 10.000000 | — |
| 1 | 0.4 | $(+2.4,\,-0.6)$ | 3.600000 | 0.36 |
| 2 | 0.4 | $(+1.44,\,+0.36)$ | 1.296000 | 0.36 |
| 3 | 0.4 | $(+0.864,\,-0.216)$ | 0.466560 | 0.36 |
| 4 | 0.4 | $(+0.5184,\,+0.1296)$ | 0.167962 | 0.36 |
| 5 | 0.4 | $(+0.31104,\,-0.07776)$ | 0.060466 | 0.36 |
| 6 | 0.4 | $(+0.186624,\,+0.046656)$ | 0.021768 | 0.36 |

The ratio is exactly $0.36 = (3/5)^2$ at every step, and $\alpha$ is exactly $0.4$ — the worst-case bound attained with equality.
Starting from $(1,1)$ instead: the first step lands essentially on the $x_1$-axis (the gradient components are then unbalanced in the other direction), and the method finishes in **two** iterations. The worst-case rate is only attained from the special start $x_0 = (\kappa c, c)$, which balances the gradient components. This is exactly the benchmarking hazard of §0.4.4 and §17.4 — an accidentally favourable starting point can make a bad algorithm look excellent.

**7.3.3** $\nabla f(x_0) = (4,4)$ and $\nabla^2 f = Q = \operatorname{diag}(1,4)$, so
$$p_0 = -Q^{-1}\nabla f(x_0) = -\begin{pmatrix}1&0\\0&1/4\end{pmatrix}\begin{pmatrix}4\\4\end{pmatrix} = \begin{pmatrix}-4\\-1\end{pmatrix},\qquad x_1 = (4,1)+(-4,-1) = (0,0).$$
The exact optimum in one step. Newton is exact because multiplying by $Q^{-1}$ **rescales the space** so the stretched bowl becomes perfectly round (§0.4.2), and in the round space the negative gradient points straight at the minimum; equivalently, the quadratic model equals $f$ exactly (§0.2.2).

**7.3.4** Require $\Big(\dfrac{\kappa-1}{\kappa+1}\Big)^{2N} \le 10^{-8}$, i.e.
$$N \ge \frac{-8\ln 10}{2\ln\!\big(\frac{\kappa-1}{\kappa+1}\big)} = \frac{\ln(10^{-8})}{\ln\big[\big(\frac{\kappa-1}{\kappa+1}\big)^2\big]}.$$
- $\kappa = 20$: ratio $= (19/21)^2 = 0.81859$, $\ln = -0.20014$; $N \ge 18.42/0.20014 \approx \mathbf{92}$.
- $\kappa = 2000$: ratio $= (1999/2001)^2 = 0.998002$, $\ln = -0.0019996$; $N \ge 18.42/0.0019996 \approx \mathbf{9\,212}$.
Increasing $\kappa$ by a factor of 100 increased the iteration count by a factor of $\approx100$: iterations grow **in direct proportion to $\kappa$** (since $-\ln\big[(\frac{\kappa-1}{\kappa+1})^2\big]\approx 4/\kappa$ for large $\kappa$, giving $N \approx \tfrac{\kappa}{4}\ln(1/\varepsilon)$).

**7.3.5** (i) **The result is $\kappa$-dependent, and $\kappa$ is a property of that problem's scaling, not of the algorithm.** Nine iterations means their current problem happens to be well conditioned (or they started at a favourable point, as in 7.3.2). Change units, add a stiff constraint, or refine a mesh, and $\kappa$ — hence run time — can grow by orders of magnitude with no warning. (ii) **The comparison was never made.** BFGS would very likely have solved the same problem in 4–5 iterations at essentially the same cost per iteration, and the gap widens with $\kappa$ and dimension (§7.4: 41 versus 4 at $\kappa=100$). "It worked" is not evidence that it worked *well*; the honest test is to run the default (L-BFGS-B) alongside it.

## Solutions — 7.4 Newton, quasi-Newton, and conjugate gradient

**7.4.1**

| Method | Information | Local rate | Choose when |
|---|---|---|---|
| Steepest descent | $\nabla f$ | linear, factor $\big(\frac{\kappa-1}{\kappa+1}\big)^2$ | essentially never — baseline and teaching tool |
| Conjugate gradient | $\nabla f$, $O(n)$ storage | linear but in $\sqrt{\kappa}$ | $n$ enormous, memory very tight |
| BFGS / L-BFGS | $\nabla f$ | superlinear | **default** for smooth problems (L-BFGS for large $n$) |
| Newton | $\nabla f$, $\nabla^2 f$ | quadratic | Hessian cheap, high accuracy needed |
| Gauss–Newton / LM | Jacobian of residuals | near-quadratic | objective is a sum of squares (§8) |

**7.4.2**
```python
import numpy as np
from scipy.optimize import minimize
for kappa in (100.0, 1e4):
    Q = np.diag([1.0, kappa]); f = lambda x: 0.5*x@Q@x; g = lambda x: Q@x
    x, n = np.array([10.0, 1.0]), 0
    while np.linalg.norm(g(x)) > 1e-5:
        gg = g(x); x = x - (gg@gg)/(gg@Q@gg)*gg; n += 1
    print(f"kappa={kappa:.0e}  steepest descent: {n:4d} iterations")
    for m, extra in [("BFGS", {}), ("Newton-CG", {"hess": lambda x: Q})]:
        r = minimize(f, [10.0, 1.0], jac=g, method=m, tol=1e-10, **extra)
        print(f"           {m:10s}: {r.nit:4d} iterations, f* = {r.fun:.1e}")
```
At $\kappa = 100$: steepest descent **41**, BFGS **4**, Newton-CG **3** — matching the text. At $\kappa = 10^4$ the steepest-descent count changes dramatically (and depends strongly on the starting point — see 7.3.2), while **BFGS and Newton-CG stay at 3–4 iterations**. That is the essential contrast: first-order methods pay for conditioning; methods that build or use curvature do not. On a quadratic, BFGS reconstructs the exact Hessian within $n$ steps and Newton needs only one *model* solve, so neither is sensitive to $\kappa$ (up to floating-point limits).

**7.4.3** BFGS accumulates an approximation to the Hessian (or its inverse) from **successive gradient differences**: each step gives a pair $(s_k, y_k) = (x_{k+1}-x_k,\ \nabla f(x_{k+1}) - \nabla f(x_k))$, and since $y_k \approx \nabla^2 f\, s_k$, that pair reveals the curvature *along the direction actually travelled*. The BFGS update installs this information into the approximation while preserving symmetry and positive definiteness. So "no second derivatives" means no second-derivative *code* — the curvature is inferred from first-derivative observations. What it needs from each step: a genuine change in position and a correspondingly accurate change in gradient. This is why a noisy or inconsistent gradient destroys quasi-Newton methods specifically (the learned curvature becomes garbage), and why L-BFGS keeps only the last few pairs — old curvature information is stale.

**7.4.4** (a) **Newton** — $n$ is tiny, the Hessian is cheap and exact, and quadratic convergence delivers 12 digits in a handful of iterations. (b) **CG** (or L-BFGS with a very small memory) — at $n = 5\times10^6$ even L-BFGS's few stored vectors are large, and CG needs only $O(n)$ storage. (c) **Gauss–Newton / Levenberg–Marquardt via `scipy.optimize.least_squares`** — the objective is a sum of squares, so $J^\top J$ gives a free Hessian approximation (§8.1); never pass a sum of squares to a generic minimizer. (d) **Derivative-free: surrogate or Bayesian optimization** (Part V) — with 20-minute evaluations and no gradient, finite differences would cost 21 runs per iteration *and* be corrupted by simulation noise (§12.1); an expensive-black-box method is the correct diagnosis, not a defeat.

## Solutions — 7.5 Line search versus trust region

**7.5.1** **Line search:** fix the direction $p_k$ first, then search along that ray for a step length $\alpha_k$ that produces an acceptable decrease — reliability is enforced *after* the direction is chosen, by testing candidate steps (Armijo/Wolfe). **Trust region:** fix a radius $\Delta_k$ within which the local model is believed, then minimize the model *inside that ball* — reliability is enforced *before* the direction is chosen, and $\Delta_k$ is expanded or shrunk according to how well the model's predicted reduction matched the actual one.

**7.5.2** **Armijo (sufficient decrease):** the actual decrease must be at least a fixed fraction $c_1$ of what the linear model promised, $f(x+\alpha p) \le f(x) + c_1\alpha\nabla f^\top p$. It prevents **overshoot** — accepting a long step that happens to leave $f$ barely changed or higher. **Curvature (second Wolfe) condition:** the directional derivative at the new point must have risen toward zero, $\nabla f(x+\alpha p)^\top p \ge c_2 \nabla f(x)^\top p$ with $c_2 \in (c_1,1)$. It prevents **microscopically small steps** — a tiny $\alpha$ satisfies Armijo trivially but makes no progress and starves quasi-Newton updates of information. Together they bracket $\alpha$ away from both pathologies.

**7.5.3** (1) **A wrong gradient** (most likely). The line search fails because the direction is not actually a descent direction; the model and reality disagree at first order. *Diagnostic:* central-difference check of every gradient component at a generic point (§0.1.3, §12.1) — they must agree to ~6 digits. (2) **Bad scaling.** With $\kappa \sim 10^{10}$ the model is valid only in a needle-thin region, and no acceptable step exists at the tried lengths. *Diagnostic:* print the magnitudes of variables, gradient components and constraint residuals; if they span more than a few orders of magnitude, rescale (§2.3). (3) **Nonsmoothness or noise in $f$** — an `abs`, a `max`, an if-branch, a table lookup, or an inner solver with loose tolerance makes $f$ effectively discontinuous at the scale of the trial steps. *Diagnostic:* plot $f$ along the search ray at 50 points; kinks or hash are immediately visible, and if present the answer is a different method class (§2.2 for reformulation, Part V for black boxes).

**7.5.4**
```python
import numpy as np

def armijo(f, x, p, g, c1=1e-4, a=1.0, shrink=0.5, amin=1e-20):
    f0 = f(x); slope = g @ p
    while a > amin and f(x + a*p) > f0 + c1*a*slope:
        a *= shrink
    return a

f  = lambda x: 100*(x[1]-x[0]**2)**2 + (1-x[0])**2
gr = lambda x: np.array([-400*x[0]*(x[1]-x[0]**2) - 2*(1-x[0]), 200*(x[1]-x[0]**2)])

x, it = np.array([-1.2, 1.0]), 0
while np.linalg.norm(gr(x)) > 1e-6 and it < 500000:
    g = gr(x); p = -g; x = x + armijo(f, x, p, g)*p; it += 1
print(it, x, f(x))
```
This takes **13 756 iterations** to crawl to $(1,1)$ (to $\|\nabla f\|\le10^{-6}$; the count depends on the tolerance). Why: Rosenbrock's Hessian at the solution has $\kappa \approx 2.5\times10^3$ (§0.4.3), and inside the curved valley the effective conditioning is worse still, so the $\big(\frac{\kappa-1}{\kappa+1}\big)^2$ rate applies with a large $\kappa$ — and the valley is *curved*, so each straight-line step leaves it almost immediately and the line search must cut $\alpha$ down. A good line search cannot repair a bad direction: `minimize(f, x0, jac=gr, method="BFGS")` solves the identical problem in **32 iterations**, a factor of 430.

## Solutions — 7.6 When to stop

**7.6.1** (i) scaled gradient norm $\|\nabla f(x_k)\| \le \varepsilon(1+|f(x_k)|)$; (ii) relative step $\|x_{k+1}-x_k\| \le \varepsilon(1+\|x_k\|)$; (iii) relative change in $f$ over the last few iterations; (iv) a hard budget on iterations or function evaluations.
The gradient must be *scaled* because $\nabla f$ carries the units of $f$ divided by the units of $x$. If $f$ is in joules ($\sim10^6$) the gradient is naturally of size $10^6$ and $\|\nabla f\| \le 10^{-6}$ is unreachable; if $f$ is in megajoules ($\sim1$) the same test is easy. Dividing by $(1+|f|)$ makes the criterion approximately dimensionless and gives it the same meaning across models — the same reasoning as §2.3.

**7.6.2** (i) **The algorithm has stalled, not converged** — e.g. it is on a narrow curved ridge, or the line search has collapsed to a tiny $\alpha$ because the direction is not truly descending (which usually means a **wrong gradient**). (ii) **The gradient is correct but badly scaled**, so $\|\nabla f\| = 4.7$ is in fact small relative to $|f|$ (if $f \sim 10^8$, then $4.7$ is a relative gradient of $5\times10^{-8}$ and the point *is* converged).
The distinguishing computation: **evaluate $|f|$ and form the scaled residual $\|\nabla f\|/(1+|f|)$** — and independently verify the gradient by central differences. If the scaled residual is large *and* the finite-difference gradient disagrees with the analytic one, it is a derivative bug; if they agree and the scaled residual is large, the algorithm stalled and needs a different method or better scaling.

**7.6.3**
```python
import numpy as np
Q = np.diag([1.0, 100.0]); f = lambda x: 0.5*x@Q@x
x = np.array([10.0, 1.0]); eps = 1e-6
fired = {"grad": None, "step": None, "df": None}
for k in range(1, 20000):
    g = Q@x; a = (g@g)/(g@Q@g); xn = x - a*g
    gn = np.linalg.norm(Q@xn); sn = np.linalg.norm(xn - x)
    df = abs(f(xn) - f(x))/max(1.0, abs(f(x)))
    if fired["grad"] is None and gn <= eps*(1+abs(f(xn))): fired["grad"] = k
    if fired["step"] is None and sn <= eps*(1+np.linalg.norm(x)):  fired["step"] = k
    if fired["df"]   is None and df <= eps:                        fired["df"]   = k
    x = xn
    if all(v is not None for v in fired.values()): break
print(fired)
```
The three criteria fire at **different** iterations: the relative-objective-change and step tests fire first (both are $O$(rate$^k$) quantities that shrink fast once the linear rate sets in), while the scaled-gradient test fires last because it is the strictest measure of actual stationarity. They do **not** agree — which is precisely why §7.6 says to use several together and treat each as necessary rather than sufficient. Reporting convergence on the step test alone would have stopped hundreds of iterations before the gradient was small.

**7.6.4** **Operational:** an unbounded run is not a plan. Optimization is usually embedded in something larger — a design sweep, a multi-start loop, a real-time controller, an overnight batch — and a run that may take forever cannot be scheduled, costed, or safely deployed. A budget converts a possible hang into a reported outcome you can handle. **Scientific:** the budget is what makes results *comparable and honest*. Without a fixed evaluation budget, comparing two algorithms (or two formulations) is meaningless because one may simply have been allowed more work; and when a run hits the budget, that fact is itself information — it says the method or the formulation is inadequate, which is exactly what §17.4's experimental hygiene demands you report rather than hide.

## Solutions — 8.1 The structural gift

**8.1.1** With $f = \tfrac12\sum_i r_i^2$ and $J_{ik} = \partial r_i/\partial x_k$:
$$\frac{\partial f}{\partial x_k} = \sum_i r_i \frac{\partial r_i}{\partial x_k} = (J^\top r)_k \quad\Longrightarrow\quad \nabla f = J^\top r.$$
Differentiating again,
$$\frac{\partial^2 f}{\partial x_k \partial x_l} = \sum_i \frac{\partial r_i}{\partial x_k}\frac{\partial r_i}{\partial x_l} + \sum_i r_i \frac{\partial^2 r_i}{\partial x_k \partial x_l} \quad\Longrightarrow\quad \nabla^2 f = J^\top J + \sum_i r_i \nabla^2 r_i.$$
Dropping the second term is good when the **residuals are small compared with the curvature scale of the model** — i.e. near a good fit (small $r_i$), or when the model is nearly linear in the parameters (small $\nabla^2 r_i$). It is a *bad* approximation when the model fits poorly (large residuals) even if the model is smooth — which is why Gauss–Newton can converge slowly or fail on badly misspecified models.

**8.1.2** Gauss–Newton: $\;(J^\top J)\,p = -J^\top r$. Levenberg–Marquardt: $\;(J^\top J + \nu I)\,p = -J^\top r$.
As $\nu \to 0$, LM $\to$ Gauss–Newton: long, aggressive, near-Newton steps — good near the solution. As $\nu \to \infty$, $p \to -\tfrac1\nu J^\top r = -\tfrac1\nu\nabla f$: a short steepest-descent step — safe far from the solution, and well defined even when $J^\top J$ is singular (rank-deficient $J$). Adapting $\nu$ from the observed success of each step is exactly the **trust-region** logic of §7.5: larger $\nu$ ⟺ smaller trusted step, and $\nu$ is increased when the model over-promises, decreased when it delivers.

**8.1.3**
```python
import numpy as np
t = np.linspace(0.2, 3.0, 12)
y = 2.0*np.exp(-1.5*t) + np.array([0.01,-0.02,0.015,0.0,-0.01,0.02,-0.005,0.01,0.0,-0.015,0.005,0.01])

r  = lambda x: x[0]*np.exp(-x[1]*t) - y
J  = lambda x: np.column_stack([np.exp(-x[1]*t), -x[0]*t*np.exp(-x[1]*t)])
f  = lambda x: 0.5*np.sum(r(x)**2)

def exact_hess(x):
    e = np.exp(-x[1]*t); ri = r(x)
    H = J(x).T @ J(x)
    H[0,1] += np.sum(ri * (-t*e)); H[1,0] = H[0,1]
    H[1,1] += np.sum(ri * (x[0]*t**2*e))
    return H

def fd_grad(x, h=1e-6):
    return np.array([(f(x+h*e) - f(x-h*e))/(2*h) for e in np.eye(2)])

for x in ([0.5, 4.0], [2.0, 1.5]):
    x = np.array(x, float)
    G = J(x).T @ r(x); H = exact_hess(x); A = J(x).T @ J(x)
    print(f"x={x}  |JtR - FD| = {np.max(np.abs(G - fd_grad(x))):.2e}"
          f"   rel err of JtJ = {np.linalg.norm(A-H)/np.linalg.norm(H):.3e}")
```
(a) and (b) agree to $\sim10^{-10}$, confirming $\nabla f = J^\top r$. For (c) vs (d): **far** from the solution ($x = (0.5,4)$) the residuals are large and $J^\top J$ differs from the exact Hessian by a relative error of $0.88$ — nearly 90 %, so it is not a usable Hessian there; **near** the solution ($x = (2.0,1.5)$) the residuals are at the noise level and the relative error falls to $3.8\times10^{-3}$, more than two orders of magnitude better. That is the structural gift, measured: the approximation becomes accurate exactly where the algorithm needs it, near convergence.

**8.1.4** The rule matters because a generic minimizer sees only the scalar $f = \tfrac12\sum r_i^2$ and must infer curvature from gradient differences (BFGS) or compute a full Hessian; the least-squares interface sees the **residual vector** and its **Jacobian**, and therefore gets two things for free:
1. **A Hessian approximation $J^\top J$ at first-derivative cost** — near-quadratic convergence without any second derivatives (§8.1.1).
2. **Structure for diagnostics and robustness** — the covariance estimate $\sigma^2(J^\top J)^{-1}$ for standard errors, the conditioning check $\operatorname{cond}(J^\top J)$ for identifiability (§8.3), and robust loss functions (`loss="soft_l1"`, `"huber"`) that act on individual residuals.
Practically: `least_squares` typically converges in a handful of iterations where `minimize` on the same problem needs many times more, and it hands you the uncertainty analysis that `minimize` cannot.

## Solutions — 8.2 Worked Example 5 — identifying a process from a step test

**8.2.1**
```python
import numpy as np
from scipy.optimize import least_squares
for sigma in (0.05, 0.25):
    rng = np.random.default_rng(7)
    t = np.linspace(0.0, 10.0, 25)
    y = 3.0*(1 - np.exp(-t/2.0)) + rng.normal(0, sigma, t.size)
    res = lambda p: p[0]*(1 - np.exp(-t/p[1])) - y
    s = least_squares(res, [1.0, 1.0])
    m, n = s.jac.shape
    se = np.sqrt(np.diag(np.sum(s.fun**2)/(m-n) * np.linalg.inv(s.jac.T @ s.jac)))
    print(f"sigma={sigma}: K={s.x[0]:.4f}+/-{se[0]:.4f}  tau={s.x[1]:.4f}+/-{se[1]:.4f}"
          f"  cond={np.linalg.cond(s.jac.T @ s.jac):.1f}")
```
At $\sigma = 0.05$: $\hat K = 2.9679 \pm 0.0142$, $\hat\tau = 1.9723 \pm 0.0363$, $\operatorname{cond} = 17.5$. At $\sigma = 0.25$ the estimates move further from truth and the standard errors grow by **about a factor of five** — standard errors scale **linearly in $\sigma$** (they are $\sigma$ times a purely geometric factor $\sqrt{\operatorname{diag}(J^\top J)^{-1}}$). The conditioning is essentially **unchanged** (still $\approx17$), because $\operatorname{cond}(J^\top J)$ depends on the *experiment design* — where you sampled and how the parameters enter the model — not on how noisy the measurements are. Two independent quantities: noise sets precision; conditioning sets identifiability.

**8.2.2**
```python
import numpy as np
from scipy.optimize import least_squares
R = 8.314
T = np.array([300., 320., 340., 360., 380., 400., 420., 440.])
k_obs = np.array([1.0846e-06, 6.6031e-06, 3.8494e-05, 1.5288e-04,
                  5.7909e-04, 1.8771e-03, 5.8021e-03, 1.4928e-02])

s1 = least_squares(lambda p: p[0]*np.exp(-p[1]/(R*T)) - k_obs, [1e6, 6e4])
Y  = np.log(k_obs); X = np.vstack([np.ones_like(T), -1/(R*T)]).T
c, *_ = np.linalg.lstsq(X, Y, rcond=None)
s2 = least_squares(lambda p: np.log(p[0]) - p[1]/(R*T) - Y, [1e6, 6e4])
print(f"absolute residuals: A={s1.x[0]:.3e}  E={s1.x[1]:.0f}")
print(f"log-space         : A={np.exp(c[0]):.3e}  E={c[1]:.0f}")
```

| fit | $A$ (true $1.2\times10^7$) | $E$ (true 75 000) | SE($E$) |
|---|---|---|---|
| absolute residuals | $1.44\times10^6$ | 66 956 | $\pm6514$ |
| log-space (linear regression) | $1.09\times10^7$ | 74 678 | $\pm316$ |

The **log-space fit is far better**, and the reason is the **error model, not the algorithm** (both fits converge cleanly; the nonlinear fit on log residuals reproduces the linear regression to all digits). The measured rate constants span four orders of magnitude, $10^{-6}$ to $10^{-2}$. Minimizing $\sum(k_{\text{pred}} - k_{\text{obs}})^2$ weights each point by its *absolute* size, so the two hottest points contribute essentially all of the objective and the six colder ones are invisible — the fit is effectively determined by two data points. Physically, however, the measurement error is **multiplicative** (a fixed *percentage* per point), and taking logs converts constant-percentage error into constant-additive error, which is exactly what least squares assumes. Least squares is maximum likelihood *for Gaussian additive noise of equal variance*; if your noise is not that, fit in a transformed variable or use explicit weights $w_i = 1/\sigma_i$. This is the least-squares cousin of §2.3: get the scaling of the residuals right, or the objective answers the wrong question.

**8.2.3** With $r_i = K(1-e^{-t_i/\tau}) - y_i$:
$$\frac{\partial r_i}{\partial K} = 1 - e^{-t_i/\tau}, \qquad \frac{\partial r_i}{\partial \tau} = -K\,\frac{t_i}{\tau^2}\,e^{-t_i/\tau}.$$
For $t_i \gg \tau$ the factor $e^{-t_i/\tau}$ is exponentially small, so the $\tau$ column $\to 0$ (while the $K$ column $\to 1$). Physically: long after the transient has died, the response is just the steady-state gain and carries **no information about how fast it got there**. Consequence for experiment design: measurements must be concentrated **where the transient is happening**, roughly $t \lesssim 3\tau$, with several points in $t \in (0, \tau)$. A step test sampled only at large $t$ determines $K$ beautifully and $\tau$ not at all — a rank-deficiency you would detect as a huge $\operatorname{cond}(J^\top J)$ (§8.3). This is the actionable form of the identifiability lesson: fix the experiment, not the optimizer.

**8.2.4** (1) **The fit** — use `least_squares` (an LM-type method) so the $J^\top J$ structure is exploited; here it converged in a handful of evaluations. (2) **The uncertainty** — form $\sigma^2(J^\top J)^{-1}$ and report standard errors alongside every estimate. (3) **The conditioning check** — compute $\operatorname{cond}(J^\top J)$ at the solution to test whether the data can distinguish the parameters at all.
A parameter estimate without a standard error is, in the text's phrase, "a guess wearing a lab coat": it is a single number from a continuum of nearly equally good fits, and without the error bar you cannot tell whether it is determined to 1 % or not determined at all. In §8.3 exactly that distinction separates a usable identification from a meaningless one — the point estimate looked fine in both cases.

## Solutions — 8.3 When the data cannot answer the question: identifiability

**8.3.1** They are compatible because *fitting the data* and *determining the parameters* are different questions. The sum of two exponentials with similar time constants is nearly the same function as a single exponential with intermediate parameters; a whole continuum of $(a_1,\tau_1,a_2,\tau_2)$ combinations produces curves that differ from one another by less than the noise. The optimizer honestly found a point where the gradient vanishes — a point in a long flat valley (Figure 8.2) — and any other point in that valley would have been equally "successful." Nothing failed; the *data* does not contain the information.
The two revealing numbers: **$\operatorname{cond}(J^\top J) \approx 8\times10^5$** (five orders of magnitude worse than the well-behaved fit) and the **standard errors, which exceed the estimates themselves** ($\pm1.81$ on a value of $0.56$). Both cost three lines to compute.

**8.3.2**
```python
import numpy as np
from scipy.optimize import least_squares
rng = np.random.default_rng(7); _ = rng.normal(0, 0.05, 25)
tt = np.linspace(0.05, 6, 40)
yy = np.exp(-tt/1.0) + np.exp(-tt/1.3) + rng.normal(0, 0.01, tt.size)
res = lambda p: p[0]*np.exp(-tt/p[1]) + p[2]*np.exp(-tt/p[3]) - yy
for x0 in ([0.8,0.8,1.2,1.6], [1.5,0.5,0.5,2.0], [0.2,1.2,1.8,1.1], [1.0,1.0,1.0,1.3]):
    s = least_squares(res, x0)
    print(np.round(s.x,3), f" SSE={np.sum(s.fun**2):.6f}", f" cond={np.linalg.cond(s.jac.T@s.jac):.1e}")
```
The pattern: **different starts land at visibly different parameter vectors with essentially identical SSE** (agreeing to several decimals), and every run reports a huge condition number. Some runs return the label-swapped mirror solution, since the model is symmetric in its two terms.
This is a **diagnosis**, not a nuisance: multi-start is a two-line test that distinguishes "the landscape has several distinct basins" (different SSE values — a genuine nonconvexity, address with multi-start or a better formulation) from "the landscape has a flat valley" (identical SSE — the data cannot separate the parameters, address with a better experiment or regularization). Here it is unambiguously the second.

**8.3.3**
```python
import numpy as np
from scipy.optimize import least_squares

def study(tau2, extra_early=False, sigma=0.01, seed=7):
    rng = np.random.default_rng(seed)
    tt = np.linspace(0.05, 6, 40)
    if extra_early: tt = np.concatenate([tt, np.linspace(0.001, 0.2, 40)])
    yy = np.exp(-tt/1.0) + np.exp(-tt/tau2) + rng.normal(0, sigma, tt.size)
    res = lambda p: p[0]*np.exp(-tt/p[1]) + p[2]*np.exp(-tt/p[3]) - yy
    s = least_squares(res, [0.8, 0.8, 1.2, max(1.6, 0.8*tau2)])
    m, n = s.jac.shape
    se = np.sqrt(np.diag(np.sum(s.fun**2)/(m-n) * np.linalg.inv(s.jac.T @ s.jac)))
    return s.x, se, np.linalg.cond(s.jac.T @ s.jac)

for label, args in [("baseline (tau2=1.3)", (1.3, False)),
                    ("(a) separated tau2=5", (5.0, False)),
                    ("(b) extra early data", (1.3, True))]:
    x, se, c = study(*args)
    print(f"{label:24s} fit={np.round(x,3)}  SE={np.round(se,2)}  cond={c:.2e}")
```
Typical outcome: the **baseline** has $\operatorname{cond}\sim10^{5-6}$ with standard errors larger than the estimates. **(a) Separating the time constants** ($\tau_2 = 5$) improves conditioning by orders of magnitude and the parameters are recovered with useful error bars. **(b) Adding early-time data** also helps substantially, because the two exponentials differ most in the first fraction of a time constant, but it cannot fully cure the case where the two decays are intrinsically close.
Interpretation: intervention (a) helps more, which tells you the confounding is between the **two $(a_i,\tau_i)$ pairs jointly** — when $\tau_1 \approx \tau_2$ the two terms are nearly the same basis function, so only the *sum* $a_1 + a_2$ is determined while the split between them is not. No amount of data at any sampling density fixes a model whose two components are indistinguishable; changing the *system* or the *excitation* does. (This is why controls practice uses rich inputs — steps plus sine sweeps — rather than more repeats of one step.)

**8.3.4** *"The two-exponential model fits the data to within the noise, but the experiment does not identify the two time constants separately. Our fit gives $\tau_1 = 0.88$ and $\tau_2 = 1.26$, but the standard errors ($\pm0.56$ and $\pm0.27$) and the condition number of $J^\top J$ ($\approx10^6$) show that a wide family of quite different parameter pairs explains the data equally well; different starting points return different answers with identical fit quality. What I can state with confidence is the total gain $a_1 + a_2 \approx 2.0$ and an effective single time constant of about 1.1, which is what the data actually supports. To separate the two constants I need either a richer excitation (a sine sweep, or a second step with different amplitude) or measurements in the first 0.2 s where the two decays differ most; either is a short experiment. I do not recommend reporting the individual constants as they stand."*
The essential moves: report the identifiable combination rather than the unidentifiable parameters, quantify the problem with the two diagnostics, and propose an experiment rather than a different algorithm.

## Solutions — 9.1 The tangency picture

**9.1.1** With a constraint, most directions are forbidden. At the constrained optimum $f$ is usually still decreasing — but only in directions that would leave the feasible set. So the right condition is not "no direction reduces $f$" but "**no *allowed* direction reduces $f$**." For an equality constraint $h = 0$, the allowed directions (to first order) are those tangent to the surface $h=0$; requiring $-\nabla f$ to have no component along that tangent space means $\nabla f$ must be *entirely* normal to the surface — i.e. parallel to $\nabla h$:
$$\nabla f(x^\star) = -\lambda\nabla h(x^\star).$$
Geometrically this says the contour of $f$ through $x^\star$ is **tangent** to the constraint curve: they touch rather than cross. Where contours cross a constraint, you can slide along the constraint to a lower contour.

**9.1.2** $\nabla f = (1,1)$, $\nabla h = (2x_1, 2x_2)$. Parallel gradients: $1 = -2\lambda x_1$ and $1 = -2\lambda x_2$, so $x_1 = x_2$. Feasibility $2x_1^2 = 1$ gives $x_1 = x_2 = \pm 1/\sqrt2$.
- $x = (-1/\sqrt2, -1/\sqrt2)$: $f = -\sqrt2 \approx -1.4142$, and $\lambda = -1/(2x_1) = +1/\sqrt2 \approx 0.7071$ — the **minimum**.
- $x = (+1/\sqrt2, +1/\sqrt2)$: $f = +\sqrt2$, $\lambda = -1/\sqrt2$ — the maximum.
The tangency condition finds *all* stationary points of the constrained problem; you must still compare values (or use second-order conditions) to say which is the minimum. Note that both have $\nabla f = (1,1) \ne 0$: the objective's gradient never vanishes anywhere, yet a constrained minimum exists.

**9.1.3** At $(1,0)$: $-\nabla f = (-1,-1)$. The normal to the circle is $\nabla h = (2,0) \propto (1,0)$, so the unit tangent is $\hat t = (0,1)$. The tangential component of $-\nabla f$ is $(-\nabla f\cdot\hat t)\hat t = (-1)(0,1) = (0,-1) \ne 0$. So moving along the circle in the direction $(0,-1)$ (clockwise, toward negative $x_2$) decreases $f$ to first order — the point is *not* optimal.
In code: `t = np.array([0.,1.]); print(-grad @ t)` gives $-1$. Repeat at $x^\star=(-1/\sqrt2,-1/\sqrt2)$, where $\hat t \propto (1,-1)/\sqrt2$: $-\nabla f\cdot\hat t = (-1,-1)\cdot(1,-1)/\sqrt2 = 0$ ✓ — no first-order improvement available. That zero *is* the KKT condition.

**9.1.4** They will find nothing — or something irrelevant. In a mass-minimization the objective's gradient never vanishes: less material is always lighter, so $\nabla(\text{mass}) \ne 0$ everywhere in the design space. Searching for $\nabla f = 0$ returns either no solution or a spurious point produced by whatever regularization or bound happened to intervene. The correct statement is that at the optimum the objective's pull is **balanced by the constraints**: $\nabla(\text{mass}) + \mu\,\nabla(\text{stress constraint}) = 0$ with $\mu > 0$, meaning the design is pushed exactly against the stress limit and the multiplier $\mu$ measures how much mass that limit costs (§9.4). "Nothing is pulling on me" is the unconstrained condition; "the pulls balance" is the constrained one.

## Solutions — 9.2 The Lagrangian

**9.2.1**
$$\mathcal{L}(x,\mu,\lambda) = x_1^2 + x_2^2 + \mu\,(x_1 - 1) + \lambda\,(x_1 + 2x_2 - 4), \qquad \mu \ge 0,\ \lambda \in \mathbb{R}.$$
$$\nabla_x\mathcal{L} = \begin{pmatrix}2x_1 + \mu + \lambda \\ 2x_2 + 2\lambda\end{pmatrix} = \begin{pmatrix}0\\0\end{pmatrix}.$$

**9.2.2** An **equality** constraint forbids motion in *both* directions off the surface, so the "force" it exerts can point either way; its multiplier is unrestricted in sign. An **inequality** $g_i \le 0$ forbids motion only in the direction that increases $g_i$ — it can *push back* but never pull you into the forbidden region. In the stationarity balance $\nabla f = -\sum\mu_i\nabla g_i$, a negative $\mu_i$ would mean the constraint is pulling you *toward* violating it, i.e. that you could improve $f$ by moving *into* the feasible interior — in which case the constraint is not what is stopping you and cannot be active at an optimum. Hence $\mu_i \ge 0$ (KKT condition 3).

**9.2.3** *Assume $x_1 \le 1$ inactive*, so $\mu = 0$. Then $2x_1 + \lambda = 0$ and $2x_2 + 2\lambda = 0$ give $x_1 = -\lambda/2$, $x_2 = -\lambda$. Feasibility: $-\lambda/2 - 2\lambda = 4 \Rightarrow -2.5\lambda = 4 \Rightarrow \lambda = -1.6$, so $x = (0.8,\ 1.6)$. Check the ignored constraint: $x_1 = 0.8 \le 1$ ✓ — **it is genuinely inactive**, so this is the answer:
$$x^\star = (0.8,\,1.6),\quad \lambda^\star = -1.6,\quad \mu^\star = 0,\quad f^\star = 0.64 + 2.56 = 3.2.$$
Signs: $\mu^\star = 0 \ge 0$ ✓, and $\lambda$ may be negative ✓. (Had the guess produced $x_1 > 1$, we would set $x_1 = 1$, solve $1 + 2x_2 = 4 \Rightarrow x_2 = 1.5$, then get $\lambda = -x_2 = -1.5$ and $\mu = -2x_1 - \lambda = -2 + 1.5 = -0.5 < 0$, which **violates dual feasibility** — telling us that branch is not optimal. Trying the active set both ways and checking signs is exactly how small KKT problems are solved by hand.)

**9.2.4** Because those extra derivative conditions are only correct for **equalities**, and even then they are just a restatement of feasibility. $\partial\mathcal{L}/\partial\lambda_j = h_j(x) = 0$ does reproduce the equality constraint. But $\partial\mathcal{L}/\partial\mu_i = g_i(x) = 0$ would force *every* inequality to be active, which is wrong — inactive inequalities are the normal case. The correct treatment of inequalities is the pair (feasibility $g_i \le 0$, sign $\mu_i \ge 0$) together with **complementary slackness** $\mu_ig_i = 0$, which allows either $g_i = 0$ (active, $\mu_i$ free to be positive) or $\mu_i = 0$ (inactive). The Lagrangian is not a function to be made stationary in all its arguments; it is a device for expressing the balance of forces in $x$, plus a separate combinatorial statement about which constraints are pressing.

## Solutions — 9.3 The KKT conditions

**9.3.1** The unconstrained minimizer $(2,1)$ violates $x_1+x_2 \le 2$ (it gives 3), so that constraint is active; the bounds are not. With $g = x_1+x_2-2$:
$$\nabla f = \big(2(x_1-2),\ 2(x_2-1)\big), \qquad \nabla g = (1,1).$$
Stationarity: $2(x_1-2) + \mu = 0$, $2(x_2-1) + \mu = 0$, so $x_1 - 2 = x_2 - 1 = -\mu/2$. Feasibility (active): $x_1+x_2 = 2$. Substituting $x_1 = 2-\mu/2$, $x_2 = 1-\mu/2$: $3 - \mu = 2 \Rightarrow \mu = 1$, hence
$$x^\star = (1.5,\ 0.5),\qquad \mu^\star = 1,\qquad f^\star = 0.25 + 0.25 = 0.5.$$
Verification:
1. **Stationarity:** $\nabla f = (-1,-1)$ and $\mu\nabla g = (1,1)$; sum $= (0,0)$ ✓.
2. **Primal feasibility:** $1.5+0.5 = 2 \le 2$ ✓; $x \ge 0$ ✓.
3. **Dual feasibility:** $\mu = 1 \ge 0$ ✓ (and the bound multipliers are $0 \ge 0$ ✓).
4. **Complementary slackness:** $\mu\,g = 1\times 0 = 0$ ✓; for the bounds, $0 \times(\text{slack}) = 0$ ✓.
Since the problem is convex, KKT is sufficient and this is the **global** minimum (§3.2).

**9.3.2** **LICQ** (linear independence constraint qualification): at $x^\star$, the gradients of the *active* constraints are linearly independent. Failure example:
$$\min\ x_1 \quad\text{s.t.}\quad g_1 = x_2 - x_1^3 \le 0,\quad g_2 = -x_2 \le 0.$$
At the optimum $x^\star = (0,0)$ both are active with $\nabla g_1 = (0,1)$ and $\nabla g_2 = (0,-1)$ — linearly *dependent* (they are negatives). A simpler and very common cause: **writing the same constraint twice**, e.g. $x_1 \le 1$ and $2x_1 \le 2$; both active, gradients parallel.
What goes wrong: the multipliers may fail to exist at all, or (in the duplicated-constraint case) they exist but are **non-unique** — any split of the total force between the two identical constraints works, so a solver reports one arbitrary choice. This is the nonlinear cousin of LP degeneracy (§5.8), and it has the same cure: do not trust a single reported multiplier; verify with a two-sided perturbation of the actual quantity you care about.

**9.3.3** They have not established (i) that the point is even a **local minimum** — a KKT point can be a constrained maximum or a saddle; and (ii) that it is a **global** minimum — KKT is local by construction. For (i), add the **second-order sufficient condition**: the Hessian of the Lagrangian $\nabla^2_{xx}\mathcal{L}$ must be positive definite on the subspace of directions tangent to the active constraints (curvature matters only along directions you can actually move). For (ii) there is no local test at all; you need convexity (§3.2), a global solver, or an honest multi-start with the caveat reported (§9.6).

**9.3.4**
```python
import numpy as np

def kkt_residual(gradf, gs, grad_gs, x, mu):
    x = np.asarray(x, float); mu = np.asarray(mu, float)
    stat = np.asarray(gradf(x), float) + sum(m*np.asarray(gg(x), float)
                                             for m, gg in zip(mu, grad_gs))
    gvals = np.array([g(x) for g in gs], float)
    return {"stationarity": float(np.linalg.norm(stat)),
            "max_violation": float(max(0.0, gvals.max())),
            "max_complementarity": float(np.max(np.abs(mu*gvals))),
            "dual_feasible": bool(np.all(mu >= -1e-12))}

gradf   = lambda x: np.array([2*(x[0]-2), 2*(x[1]-1)])
gs      = [lambda x: x[0] + x[1] - 2]
grad_gs = [lambda x: np.array([1.0, 1.0])]

print(kkt_residual(gradf, gs, grad_gs, [1.5, 0.5], [1.0]))
print(kkt_residual(gradf, gs, grad_gs, [1.0, 1.0], [1.0]))
```
At $(1.5,0.5)$ with $\mu = 1$: all three residuals are $0$ (to machine precision) and $\mu \ge 0$ — a certified KKT point. At $(1,1)$ with $\mu = 1$: stationarity residual $\|(-2+1,\,0+1)\| = \|(-1,1)\| = \sqrt2 \approx 1.414$, violation $0$, complementarity $0$ — feasible and complementary but **not stationary**, so not optimal. Notice that two of the three tests passing tells you nothing; §9.7's point is that all three are required.

## Solutions — 9.4 Multipliers are shadow prices

**9.4.1** With the relaxed constraint $x_1+x_2 \le 2+\varepsilon$ (still active for small $\varepsilon$), the optimum is the projection of $(2,1)$ onto the line $x_1+x_2 = 2+\varepsilon$. The signed distance from $(2,1)$ to that line is $\big(3-(2+\varepsilon)\big)/\sqrt2 = (1-\varepsilon)/\sqrt2$, so
$$f^\star(\varepsilon) = \text{dist}^2 = \frac{(1-\varepsilon)^2}{2}.$$
Then $\dfrac{df^\star}{d\varepsilon}\Big|_{0} = -(1-\varepsilon)\Big|_{0} = -1 = -\mu^\star$ ✓ (recall $\mu^\star = 1$). Check the values: $f^\star(0) = 0.5$, $f^\star(0.1) = 0.405$, $f^\star(-0.1) = 0.605$.

**9.4.2**
```python
import numpy as np
from scipy.optimize import minimize
f = lambda x: (x[0]-2)**2 + (x[1]-1)**2
def solve(eps):
    r = minimize(f, [0,0], method="SLSQP", options={"ftol":1e-16},
                 constraints=[{"type":"ineq", "fun": lambda x, e=eps: (2+e) - x[0] - x[1]}])
    return r.fun
f0 = solve(0.0)
print("rate up  :", (solve(+0.1) - f0)/0.1)     # -0.95
print("rate down:", (f0 - solve(-0.1))/0.1)     # -1.05
print("-mu*     :", -1.0)
```
The two one-sided rates are $-0.95$ and $-1.05$: they **bracket** $-\mu^\star = -1$ and average to it exactly. They are not identical because $f^\star(\varepsilon) = (1-\varepsilon)^2/2$ is *curved* — the multiplier is the derivative at $\varepsilon=0$, and a finite difference of $\pm0.1$ picks up the second-order term. Shrinking to $\pm0.001$ makes both rates $-1.000$. (Contrast the LP case, where $f^\star$ is piecewise *linear*, so one-sided rates are exactly equal inside a range and differ abruptly at a kink — §5.8.)

**9.4.3** Recommendation, in priority order:
1. **Deflection is the dominant driver at 12.4 kg per unit of relative relaxation** — a 10 % relaxation of the deflection limit would save roughly 1.24 kg. This is the specification to take back to the client first; it costs the most and is often the softest requirement (deflection limits are frequently serviceability rules of thumb rather than safety limits).
2. **Frequency is second at 3.1 kg** — worth checking whether the required margin above the excitation frequency is genuinely needed or inherited from a template.
3. **Width contributes 0.4 kg** — minor; relaxing it is unlikely to be worth the packaging discussion.
4. **Stress has multiplier 0, so it is not active** — the design is *not* stress-limited. Requesting a higher-strength alloy would buy **nothing**, and any proposal to do so should be declined.
That last line is the one that saves money, and it comes free with the multipliers.

**9.4.4** The multiplier is the derivative of the *value function* $f^\star(\varepsilon)$, and that derivative need not exist. Exactly as in LP, the value function can have a kink at the nominal point — this happens when LICQ fails, when several constraints become active simultaneously, or when the active set changes at $\varepsilon = 0$. At such a point there is a *set* of valid generalized slopes (subgradients), every element of which a solver may legitimately report, and two solvers can return different numbers for the same model. The habit: **before spending money on a multiplier, re-solve with the constraint perturbed up and down by an amount matching the real decision**, and compare the two one-sided rates. If they agree, the multiplier is a price you can use; if they differ, report both and say the question of "the" price is malformed (§5.8.5).

## Solutions — 9.5 The Lagrangian dual: one idea behind every certificate

**9.5.1** Write the constraint as $g = 2 - x - y \le 0$. Then
$$\mathcal{L}(x,y,\mu) = x^2 + y^2 + \mu(2 - x - y).$$
Minimize over $x,y$: $2x - \mu = 0$ and $2y - \mu = 0$, so $x = y = \mu/2$. Substituting,
$$q(\mu) = \frac{\mu^2}{4} + \frac{\mu^2}{4} + \mu\Big(2 - \mu\Big) = \frac{\mu^2}{2} + 2\mu - \mu^2 = 2\mu - \frac{\mu^2}{2}.$$
Concave ✓ ($q'' = -1 < 0$; and in general $q$ is a pointwise infimum of affine functions of $\mu$). Maximize: $q'(\mu) = 2 - \mu = 0 \Rightarrow \mu^\star = 2$, giving $q(2) = 4 - 2 = 2$.
The primal: by symmetry $x = y = 1$, so $f^\star = 2$. Hence $q(\mu^\star) = 2 = f^\star$ — **zero duality gap**, as guaranteed for a convex problem satisfying Slater's condition.

**9.5.2** **Weak duality** ($q(\mu,\lambda) \le f^\star$ for all $\mu \ge 0$) requires **nothing**: no convexity, no differentiability, not even continuity — only that $\mu \ge 0$ and that $g(x)\le0$, $h(x)=0$ at feasible points, which is what makes $\mathcal{L}(x,\mu,\lambda) \le f(x)$ there. **Strong duality** (the gap closes) requires **convexity plus a constraint qualification** such as Slater's condition (a strictly feasible point exists); without convexity a gap can persist.
$q$ is always concave because $\mathcal{L}(x,\mu,\lambda)$ is **affine in $(\mu,\lambda)$ for each fixed $x$**, and $q$ is the pointwise infimum over $x$ of that family of affine functions. A pointwise infimum of affine functions is concave — no property of $f$, $g$, or $h$ is used. This is why the dual problem "maximize $q$" is always a well-behaved concave problem, and why dual bounds are available even for integer and black-box problems.

**9.5.3** The framing: a feasible point gives an **upper** bound on $f^\star$ (you achieved that value); a dual-feasible multiplier vector gives a **lower** bound; optimality is proved when the two meet. A heuristic — simulated annealing, a genetic algorithm, tabu search — produces *only feasible points*. It therefore produces only upper bounds, and can never bracket the optimum from below. With no lower bound there is no gap to close, hence no certificate: you can say "I found a solution of value 1 342" but never "no solution better than 1 340 exists."
This is **structural**, not a maturity problem. A certificate requires an object that bounds *all* solutions at once — a dual feasible point, an LP relaxation, a valid inequality. A search procedure that only ever evaluates candidates has no such object, no matter how cleverly it searches or how much compute it is given. That is why Part IV (branch and bound, which maintains a relaxation) can certify and Part V cannot.

**9.5.4**
```python
import numpy as np
from scipy.optimize import minimize
q = lambda mu: 2*mu - mu**2/2
for mu in [0, 0.5, 1, 1.5, 2, 2.5, 3, 4]:
    print(f"mu={mu:4.1f}  q={q(mu):+.4f}   valid lower bound (f*=2)? {q(mu) <= 2 + 1e-12}")

f = lambda x: x[0]**2 + x[1]**2
def solve(rhs):
    r = minimize(f, [0,0], method="SLSQP", options={"ftol":1e-16},
                 constraints=[{"type":"ineq","fun":lambda x, b=rhs: x[0]+x[1]-b}])
    return r.fun
print("d f*/d rhs =", (solve(2.001) - solve(1.999))/0.002, " mu* =", 2.0)
```

| $\mu$ | 0 | 0.5 | 1 | 1.5 | **2** | 2.5 | 3 | 4 |
|---|---|---|---|---|---|---|---|---|
| $q(\mu)$ | 0 | 0.875 | 1.5 | 1.875 | **2** | 1.875 | 1.5 | 0 |

Every value satisfies $q(\mu) \le 2 = f^\star$, with equality only at $\mu^\star = 2$ — the curve touches the optimum exactly once, from below. The perturbation test returns $df^\star/d(\text{rhs}) \approx 2.000 = \mu^\star$, confirming the multiplier is the shadow price of the constraint (§9.4). Note the sign convention: written as $x+y \ge b$, increasing $b$ *tightens* the problem and raises $f^\star$ at rate $+\mu^\star$.

## Solutions — 9.6 Algorithms for constrained problems

**9.6.1**
- **Penalty / augmented Lagrangian** — replace constraints by a penalty on violation and drive the penalty weight up (the augmented version also carries explicit multiplier estimates, so a *moderate* weight suffices). *Weakness:* pure penalties become severely ill-conditioned as $\rho$ grows; augmented Lagrangian largely fixes this but converges only linearly. *Associated with:* LANCELOT, ALGENCAN; the augmented-Lagrangian idea also underlies many ADMM implementations.
- **SQP** — at each iterate solve a QP built from a quadratic model of the Lagrangian and a linear model of the constraints. *Weakness:* each iteration is expensive and needs a QP solve; the QP can be infeasible far from the solution, requiring safeguards. *SciPy:* `method="SLSQP"` (also SNOPT, filterSQP commercially).
- **Interior point / barrier** — add a log-barrier that blows up at the boundary, keep iterates strictly interior, then shrink the barrier parameter. *Weakness:* warm-starts poorly, and iterates only *approach* the boundary, so active constraints are satisfied to tolerance rather than exactly. *SciPy:* `method="trust-constr"`; industry standard **IPOPT**.

**9.6.2** $P_\rho = x_1^2 + x_2^2 + \rho(x_1-1)^2$ has
$$\nabla^2 P_\rho = \begin{pmatrix}2 + 2\rho & 0\\ 0 & 2\end{pmatrix}, \qquad \kappa(\rho) = \frac{2+2\rho}{2} = 1 + \rho.$$
So $\kappa$ grows **linearly in $\rho$**: at $\rho = 10^8$ the penalized problem has $\kappa \approx 10^8$. By §7.3, a first-order method's iteration count grows in direct proportion to $\kappa$, and even a quasi-Newton method loses accuracy because the Hessian's stiff direction swamps the soft one in floating point. The penalty term creates exactly the stretched canyon of Figure 7.1, with the canyon walls being the constraint. This is the precise sense in which "penalty methods trade a constrained problem for an ill-conditioned unconstrained one" — and why the augmented Lagrangian, which reaches feasibility through multiplier updates rather than through $\rho \to \infty$, is the practical version.

**9.6.3**
```python
import numpy as np
from scipy.optimize import minimize, LinearConstraint
f  = lambda x: np.exp(x[0]) + 2*x[1]**2
gf = lambda x: np.array([np.exp(x[0]), 4*x[1]])
for m in ("SLSQP", "trust-constr"):
    r = minimize(f, [0,0], jac=gf, method=m, tol=1e-12,
                 constraints=[LinearConstraint([[1,1]], 1, 1)])
    print(f"{m:13s} x*={np.round(r.x,10)}  h={r.x.sum()-1:+.2e}  nfev={r.nfev}  f={r.fun:.10f}")
```
Both converge to $x^\star \approx (0.561622,\ 0.438378)$ with $f^\star \approx 2.137865$ — matching the hand solution of §11.1. The difference is in *how* they sit on the constraint: **SLSQP** solves the linearized constraint exactly at each QP step, so the returned point satisfies $x_1+x_2 = 1$ to machine precision. **trust-constr**, being a barrier/interior-point method, approaches the feasible set from inside and satisfies the constraint only to its tolerance (typically $10^{-8}$–$10^{-10}$), which is visible in the residual. Neither is "wrong" — but if your equality constraint is a mass balance that downstream code will divide by, the SQP answer is the one to use, or you must project the interior-point answer onto the constraint afterwards (§9.7).

**9.6.4** (a) **Interior point** — designed exactly for large sparse convex problems, with a few dozen iterations almost independent of size. (b) **SQP** — iterations, not linear algebra, are what cost money here; SQP is the stingiest in function evaluations, and 40-minute evaluations make everything else irrelevant. (c) **Augmented Lagrangian** — most tolerant of messy, badly scaled constraints and of a model you keep changing (though the real answer is also to *fix the scaling*, §2.3). (d) Any of the three, but wrapped in **multi-start**: the family choice is secondary because all three find only local solutions on a nonconvex problem; what matters is running many starts and reporting the spread of optima found.

## Solutions — 9.7 Stopping criteria for constrained problems

**9.7.1** (i) **Feasibility** — $\max_i\max(0,g_i(x))$ and $\max_j|h_j(x)|$; corresponds to KKT condition 2. (ii) **Optimality / stationarity** — the scaled norm of $\nabla f + \sum\mu_i\nabla g_i + \sum\lambda_j\nabla h_j$; KKT condition 1. (iii) **Complementarity** — $\max_i|\mu_ig_i(x)|$; KKT condition 4 (with $\mu \ge 0$, condition 3, checked separately).
Checking a subset is insufficient because each residual can be zero while the point is badly wrong: a feasible point that is not stationary is simply not optimal (9.3.4's second test case); a stationary point that is infeasible is not a solution at all; and a point satisfying stationarity and feasibility but not complementarity has a nonzero multiplier on an inactive constraint, meaning the reported "forces" do not correspond to the actual active set — so the multipliers, and any economics read from them, are meaningless.

**9.7.2** Unscaled, the constraint residual is measured in pascals, so $\varepsilon_{\text{feas}} = 10^{-6}$ permits a violation of $10^{-6}$ Pa $= 10^{-12}$ MPa — utterly negligible *here*. The trap is the reverse case: if the constraint were written as $\sigma/\sigma_{\text{allow}} - 1 \le 0$ the same tolerance means $2.5\times10^{-4}$ MPa, still negligible; but if it were written in gigapascals or normalized by something large, $10^{-6}$ of that unit could be megapascals. **The point is that the tolerance means nothing until you know the constraint's units** — which is the §2.3 argument again.
The two remedies: (i) **tighten the tolerance**, or (ii) **build explicit margin into the constraint** — write $\sigma \le 0.98\,\sigma_{\text{allow}}$ so that a tolerance-level violation lands inside your safety factor rather than outside the allowable stress. The course prefers **(ii)**: tolerances are numerical parameters that someone will change, defaults that vary between solvers, and quantities whose meaning depends on scaling; an explicit margin is part of the model, is visible to reviewers, and survives a change of solver.

**9.7.3**
```python
import numpy as np
gradf = lambda x: np.array([np.exp(x[0]), 4*x[1]])
# constraints: h = x1+x2-1 = 0 ; g = x2-0.3 <= 0
for x, lam, mu in [(np.array([0.7, 0.3]), -np.exp(0.7), 0.8138),
                   (np.array([0.70, 0.30]), -2.01, 0.81)]:
    stat = gradf(x) + lam*np.array([1.0,1.0]) + mu*np.array([0.0,1.0])
    print(f"x={x}  stationarity={np.linalg.norm(stat):.2e}"
          f"  |h|={abs(x.sum()-1):.2e}  compl={abs(mu*(x[1]-0.3)):.2e}")
```
At the exact solution with the exact multipliers, all three residuals are at machine level. Rounding the *multipliers* to two decimals leaves feasibility and complementarity untouched (they depend on $x$, which is unchanged) but degrades **stationarity** to $\sim10^{-3}$ — the stationarity residual is the one that detects inaccurate multipliers. Conversely, rounding $x$ while keeping exact multipliers degrades **feasibility and complementarity**. That is the practical value of computing all three: they localize the error to the primal or the dual variables.

**9.7.4** $|\mu_ig_i|$ is small either because (a) $g_i \approx 0$ — the constraint is genuinely active and the multiplier can be large and meaningful; or (b) $\mu_i \approx 0$ — the constraint is inactive with slack, and the product is small no matter how much slack there is. Both are correct at an optimum, but they mean opposite things for design: (a) says "this limit is driving your design and is worth $\mu_i$ per unit," (b) says "this limit is irrelevant." A log line reporting only "complementarity = 3e-11" tells you the solver is happy and tells you *nothing* about the active set. This is why §1.4's habit is to print the constraint values and multipliers separately — the residual is a convergence diagnostic, not an engineering result.

## Solutions — 10.1 Version A — constant wall thickness (a can, or an unpressurized tank)

**10.1.1** $\mathcal{L} = \pi r^2 + 2\pi rh + \lambda(V - \pi r^2h)$.
$$\frac{\partial\mathcal{L}}{\partial h} = 2\pi r - \lambda\pi r^2 = 0 \implies \lambda = \frac{2}{r}.$$
$$\frac{\partial\mathcal{L}}{\partial r} = 2\pi r + 2\pi h - \lambda(2\pi rh) = 2\pi r + 2\pi h - 4\pi h = 2\pi r - 2\pi h = 0 \implies \boxed{h = r}.$$
So the open-top optimum is **height = radius** ($h/2r = 0.5$), against $h = 2r$ for the closed can. Removing the lid removes an $r^2$-cost, so the optimizer is willing to make the cylinder wider and shallower. Substituting the constraint, $r^\star = (V/\pi)^{1/3}$.

**10.1.2**
```python
import numpy as np
from scipy.optimize import minimize
V = 1.0
A   = lambda z: np.pi*z[0]**2 + 2*np.pi*z[0]*z[1]
vol = {"type":"eq", "fun": lambda z: np.pi*z[0]**2*z[1] - V}
r = minimize(A, [0.5, 1.0], constraints=[vol], bounds=[(1e-6,None)]*2,
             method="SLSQP", options={"ftol":1e-16})
print(f"r*={r.x[0]:.6f}  h*={r.x[1]:.6f}  h/r={r.x[1]/r.x[0]:.6f}")
print(f"analytic r* = (V/pi)^(1/3) = {(V/np.pi)**(1/3):.6f}")
```
Output: $r^\star = h^\star = 0.682784$ m, ratio $h/r = 1.000000$ ✓, matching $(1/\pi)^{1/3} = 0.682784$ exactly.

**10.1.3** Minimizing area = minimizing material whenever **wall thickness is constant and set by something other than the loading**: a beverage can (thickness set by formability and handling stiffness, plus a minimum gauge for the sheet), a sheet-metal enclosure, an atmospheric storage tank whose plate thickness is set by a corrosion allowance or a minimum-gauge code rule, a plastic bottle where thickness is set by the moulding process, or any thin-shell object whose loading is negligible.
It is **not** minimizing material when thickness is set by the load — the pressure vessel of §10.2 being the canonical case, where $t = pr/\sigma$ makes thickness a *function of the design variable*, so area and volume of material scale differently.

**10.1.4** (i) **Manufacturing and material reality:** the can's ends are much thicker than its wall (they must take the seaming operation and the internal pressure of a carbonated drink), so the true material cost weights the $r^2$ terms far more heavily than the area objective does — and the optimum of the *true* cost is a taller, narrower can. (ii) **Non-material objectives:** shelf presentation, fit to the human hand, printing area, compatibility with existing filling lines, six-pack packing efficiency, and shipping-pallet dimensions. Also thermal: a narrower can chills faster.
What this says about optimizer answers: an optimum is optimal *for the model you wrote*, and the gap between it and practice is a **list of the terms you omitted**, not evidence that optimization failed. The professional move is to treat the discrepancy as a diagnostic — exactly the §10.5 argument — and then either add the missing terms or use the multipliers to price the trade-off explicitly.

## Solutions — 10.2 Version B — a real pressure vessel, where thickness is set by stress

**10.2.1** For a long vessel the two hemispherical heads contribute negligibly, so
$$M \approx (2\pi rL)\,\frac{pr}{\sigma} = \frac{2\pi p}{\sigma}r^2L, \qquad V \approx \pi r^2 L \implies r^2L = \frac{V}{\pi}.$$
Substituting: $M \approx \dfrac{2\pi p}{\sigma}\cdot\dfrac{V}{\pi} = \dfrac{2pV}{\sigma}$. The radius and length appear only through the product $r^2L$, which the volume constraint fixes — so **the aspect ratio drops out entirely**.
What this means for Version A: its answer $h = 2r$ is not merely inaccurate under pressure loading, it answers a question that no longer exists — to leading order there is no aspect-ratio trade-off left to optimize.

**10.2.2** The volume constraint $\pi r^2L + \tfrac43\pi r^3 = V$ gives $r^2 L = \dfrac{V}{\pi} - \dfrac43 r^3$. Substituting into $M = k(r^2L + r^3)$:
$$M(r) = k\Big(\frac{V}{\pi} - \frac43 r^3 + r^3\Big) = k\Big(\frac{V}{\pi} - \frac{r^3}{3}\Big).$$
Since $k > 0$, $dM/dr = -kr^2 < 0$ for $r>0$: **strictly decreasing**, no interior stationary point.
Physically, the $-1/3$ is the *net* effect of two competing terms: making $r$ larger lets the heads swallow more of the required volume ($-\tfrac43r^3$, a saving because barrel length shrinks), while the heads themselves cost material ($+r^3$). The head is *cheaper per unit volume contained* than the barrel — by exactly the factor of two in the thickness formulas — so the net coefficient is negative and the optimizer keeps growing $r$.

**10.2.3** $L \ge 0$ with $r^2L = V/\pi - \tfrac43r^3$ requires $V/\pi - \tfrac43 r^3 \ge 0$, i.e.
$$r^3 \le \frac{3V}{4\pi} \implies r \le r_{\max} = \Big(\frac{3V}{4\pi}\Big)^{1/3}.$$
(This is just "the sphere of radius $r$ must not already exceed the required volume.") At $r = r_{\max}$, $L = 0$ and
$$M^\star = k\Big(\frac{V}{\pi} - \frac13\cdot\frac{3V}{4\pi}\Big) = k\cdot\frac{V}{\pi}\Big(1 - \frac14\Big) = \frac{2\pi p}{\sigma}\cdot\frac{3V}{4\pi} = \frac{3pV}{2\sigma},$$
which is $\tfrac34$ of the long-cylinder value $2pV/\sigma$ — a **25 % material saving** for the sphere.

**10.2.4**
```python
import numpy as np
V, p, sig, rho = 10.0, 2e6, 150e6, 7850.0
k = 2*np.pi*p/sig
for r in [0.6, 0.8, 1.0, 1.2, (3*V/(4*np.pi))**(1/3)]:
    L = (V - 4/3*np.pi*r**3)/(np.pi*r**2)
    M = k*(r**2*L + r**3)
    print(f"r={r:.4f}  L={L:7.4f}  M={M:.5f} m^3 = {rho*M:7.1f} kg   t_head={p*r/(2*sig)*1e3:.2f} mm")
```

| $r$ [m] | $L$ [m] | mass [kg] |
|---|---|---|
| 0.6 | 7.8434 | 2029.0 |
| 0.8 | 3.9069 | 1981.1 |
| 1.0 | 1.8498 | 1874.1 |
| 1.2 | 0.6105 | 1714.5 |
| 1.3365 | 0.0000 | **1570.0** |

Monotone decreasing in $r$ ✓, reaching $3pV/2\sigma = 0.2000$ m³ $= 1570$ kg at the sphere ✓. Thin-wall validity at the optimum: $t_s = pr^\star/2\sigma = 2\times10^6(1.3365)/(2\times150\times10^6) = 8.9$ mm, so $t/r = 0.0067 \ll 0.1$ ✓ — the theory is comfortably valid, which is a check you should always run before trusting a thin-wall result.

**10.2.5** Cylindrical shell: hoop stress $\sigma_\theta = pr/t$ and axial stress $\sigma_a = pr/2t$. Spherical shell: $\sigma = pr/2t$ in every direction.
The **hoop stress governs the cylinder** because it is twice the axial stress, so it reaches the allowable first; setting $\sigma_\theta = \sigma$ gives $t_c = pr/\sigma$. The sphere carries the pressure in *two* directions everywhere — its double curvature means both principal membrane directions share the load — whereas the cylinder's straight generators carry no hoop load, so the hoop direction must take it all. Hence $t_s = pr/2\sigma$, exactly half. That factor of two is the entire reason the sphere wins, and it is a statement about geometry (Gaussian curvature), not about material.

## Solutions — 10.3 The KKT conditions at an active bound

**10.3.1** With $g = -L \le 0$ and $\mathcal{L} = k(r^2L+r^3) + \lambda\big[V - \pi r^2L - \tfrac43\pi r^3\big] + \mu(-L)$:
$$\frac{\partial\mathcal{L}}{\partial L} = kr^2 - \lambda\pi r^2 - \mu = 0, \qquad \frac{\partial\mathcal{L}}{\partial r} = k(2rL + 3r^2) - \lambda(2\pi rL + 4\pi r^2) = 0.$$
Assume $L > 0$. Complementary slackness $\mu\,(-L) = 0$ then forces $\mu = 0$, and the first equation gives $\lambda = k/\pi$. Substituting into the second:
$$k(2rL + 3r^2) - \frac{k}{\pi}\big(2\pi rL + 4\pi r^2\big) = k(2rL + 3r^2) - k(2rL + 4r^2) = -kr^2 = 0 \implies r = 0,$$
contradicting $r > 0$. **This proves no KKT point exists with $L > 0$** — i.e. no cylinder of positive straight length is even a *candidate* for optimality, confirming algebraically what the monotonicity of $M(r)$ showed.

**10.3.2** With $L = 0$ the second stationarity equation becomes $3kr^2 = 4\pi\lambda r^2$, so $\lambda = \dfrac{3k}{4\pi}$. The first then gives
$$\mu = kr^2 - \lambda\pi r^2 = kr^2 - \tfrac34 kr^2 = \frac{kr^2}{4} > 0 \quad\checkmark$$
Dual feasibility holds *strictly*, so $(r^\star, L^\star) = (r_{\max}, 0)$ with $\mu^\star = kr^{\star2}/4$ is the unique KKT point.
Had $\mu$ come out **negative**, dual feasibility (KKT condition 3) would have failed, which means the bound is not actually holding the optimum back — the objective would improve by moving *away* from the bound, into $L>0$. In that case the assumed active set is wrong and you must re-solve with the constraint treated as inactive. Sign-checking the multipliers is precisely the mechanism that tells you whether your guessed active set was right (compare 9.2.3).

**10.3.3** **General lesson:** when the objective is monotone in a variable, the optimum sits on a bound, and *the bound is doing the design work* — the "optimization" has produced your own assumption echoed back to you.
What I would tell them: *"Your model has not chosen the thickness; you did. The reported optimum is a consequence of the 3 mm floor, so the design's mass and cost are determined by that number, not by physics."* Two checks: (i) **Is the bound physically real?** A minimum manufacturable/weldable gauge, a corrosion allowance, or a code minimum is real and should be documented with its source; "reasonable" is not. (ii) **What is the bound worth?** Read the multiplier on the bound (or re-solve at 2.5 and 3.5 mm) to get kg per mm; if that number is large, the bound deserves a proper engineering justification, and if it is small the choice does not matter much. Third, if applicable: check whether some other physics was omitted that would have made the thickness interior — buckling, vibration, local denting — because a monotone objective usually signals a missing constraint (§1.3).

**10.3.4** (i) It tells you **where the answer will be** — on a bound, so you know before solving that the bound's justification is the crux of the design, and you can prepare the sensitivity to it. (ii) It reveals **missing physics**: a genuinely monotone objective in a design variable means nothing in the model resists that variable growing (or shrinking), which is almost always a sign that a constraint was forgotten — buckling for thin members, a manufacturing limit, a transport envelope. It also (iii) saves you from a fruitless search for an interior stationary point that does not exist, and (iv) warns you that the solver's returned "optimum" is not distinguished by any local condition, so multipliers rather than gradients carry all the design information.

## Solutions — 10.4 What the multiplier prices — with real numbers

**10.4.1** Step by step:
- $k = \dfrac{2\pi p}{\sigma} = \dfrac{2\pi(2\times10^6)}{150\times10^6} = 0.083776\ \text{m}^{-1}$.
- $r^\star = \Big(\dfrac{3V}{4\pi}\Big)^{1/3} = \Big(\dfrac{30}{4\pi}\Big)^{1/3} = (2.3873)^{1/3} = 1.3365$ m.
- $M^\star = \dfrac{3pV}{2\sigma} = \dfrac{3(2\times10^6)(10)}{2(150\times10^6)} = 0.2000$ m³ of steel $\Rightarrow 7850 \times 0.2 = \mathbf{1570}$ kg.
- $\mu^\star = \dfrac{k r^{\star2}}{4} = \dfrac{0.083776 \times 1.7862}{4} = 0.037414$ m³ per metre $\Rightarrow 7850 \times 0.037414 = \mathbf{294}$ kg per metre.
(Check on thin-wall validity: $t_s = pr^\star/2\sigma = 8.9$ mm, $t/r = 0.0067$ ✓.)

**10.4.2**
```python
import numpy as np
from scipy.optimize import minimize
V, p, sig, rho = 10.0, 2e6, 150e6, 7850.0
k = 2*np.pi*p/sig

def solve(rmax):
    M   = lambda z: k*(z[0]**2*z[1] + z[0]**3)
    vol = {"type":"eq", "fun": lambda z: np.pi*z[0]**2*z[1] + 4/3*np.pi*z[0]**3 - V}
    return minimize(M, [1.0, 1.0], constraints=[vol], bounds=[(1e-3, rmax), (0.0, None)],
                    method="SLSQP", options={"ftol":1e-16, "maxiter":2000})

for rmax in [1.6, 1.2, 1.0, 0.8]:
    r = solve(rmax)
    print(f"rmax={rmax:.1f}: r*={r.x[0]:.4f}  L*={r.x[1]:.4f}  M={rho*r.fun:7.1f} kg")

h = 1e-4
d = (solve(1.0+h).fun - solve(1.0-h).fun)/(2*h)
print(f"dM*/dr_max = {d:.5f} m^3/m = {rho*d:.1f} kg/m   (analytic -k r^2 = {-k*1.0**2:.5f})")
```

| $r_{\max}$ [m] | $r^\star$ | $L^\star$ [m] | mass [kg] |
|---|---|---|---|
| 1.6 | 1.3365 | 0.0000 | 1570.0 (bound inactive — sphere) |
| 1.2 | 1.2000 | 0.6105 | 1714.5 |
| 1.0 | 1.0000 | 1.8498 | 1874.1 |
| 0.8 | 0.8000 | 3.9069 | 1981.1 |

At $r_{\max} = 1.6$ the bound is slack and we recover the sphere. Once $r_{\max} < 1.3365$ the bound is **active** and a genuine cylinder reappears — the transport limit, not the physics, now sets the shape. The finite-difference multiplier at $r_{\max}=1.0$ is $-0.08378$ m³/m $= -657.6$ kg per metre, matching the analytic $dM/dr = -kr^2 = -0.083776$ exactly ✓ (negative because *relaxing* the radius cap *reduces* mass).

**10.4.3** For the review: *"The 1.0 m road-transport limit costs 304 kg of steel — 1874 kg versus 1570 kg for the unconstrained sphere, a 19 % mass penalty. At the margin, each additional metre of permitted radius is worth about 658 kg, so even a modest relaxation is valuable: going from 1.0 m to 1.2 m saves 160 kg."*
How to use it in the negotiation: the numbers convert a categorical constraint ("we can't ship anything wider than 2 m") into a price, so logistics and design can trade on a common scale. Concretely: ask what a permit for a 2.4 m-diameter load costs, or what field-assembly of a spherical vessel would cost, and compare with 304 kg of steel plus its fabrication. If the permit costs less than the steel saving, the limit should be relaxed; if not, the design is correct and the review can stop discussing it. That is the entire value of a multiplier — it ends arguments with a number.

**10.4.4** Estimate: $1.5\ \text{m} \times 294\ \text{kg/m} \approx \mathbf{441}$ kg of additional steel (on top of the 1570 kg sphere, roughly a 28 % increase).
**Assumption:** that the multiplier — a *derivative at $L = 0$* — stays constant over the whole 1.5 m. That is a linear extrapolation of a slope, exactly the error §5.6 warns about; here $M(r) = k(V/\pi - r^3/3)$ is nonlinear in $r$, and forcing $L = 1.5$ pushes $r$ well away from $r_{\max}$, so the true penalty will differ.
**How to check:** re-solve the model with the bound $L \ge 1.5$ imposed and compare the actual mass with the extrapolated 441 kg. (Doing so gives $r$ from $\pi r^2(1.5) + \tfrac43\pi r^3 = 10$, then $M = k(r^2(1.5) + r^3)$ — a two-line computation.) For any perturbation that is not small, re-solve; never extrapolate a multiplier.

## Solutions — 10.5 What the model still omits — and why that is the point

**10.5.1**
- **Fabrication cost** (rolled cylindrical shells are cheap; double-curvature spherical shells need forming, many more welds, more inspection) → pushes $L^\star$ **up** (favours cylinders).
- **Transport and support** (cylinders ship on trucks and sit in saddles; spheres need bespoke skirts and legs) → pushes $L^\star$ **up**, usually via a cap on $r$ as in 10.4.2.
- **Access and internals** (trays, baffles, agitators, manholes, nozzle spacing need straight length) → pushes $L^\star$ **up** directly, by imposing $L \ge L_{\min}$.
All three point the same way, which is exactly why the world is full of cylinders. (Material cost alone is the only term favouring the sphere.)

**10.5.2** Because the model's job was never to make the decision by itself; it was to isolate and quantify one trade-off. What it contributed, precisely:
1. **A bound on the prize.** The best conceivable material saving from going spherical is 25 % (523 kg here). If fabrication of a sphere costs more than 523 kg of steel, the discussion is over — and now it can be over in one line instead of three meetings.
2. **A price for every competing consideration.** $\mu^\star = 294$ kg per metre of mandated straight length is the exact number to set against the fabrication saving per metre of cylinder, and $-658$ kg per metre of radius prices the transport limit.
3. **A diagnosis of the model itself.** The disagreement with practice is a *list* of omitted terms, each now identified and priced, which is how the model gets improved.
The failure mode to avoid is not "the model said sphere"; it is treating a model's optimum as a decision without asking what it omitted (§2.1, step 5).

**10.5.3**
```python
import numpy as np
from scipy.optimize import minimize
V, p, sig, rho = 10.0, 2e6, 150e6, 7850.0
k = 2*np.pi*p/sig; c_s = 2.0

def solve(c_f, rmax=1.3, rmin=0.4):
    def cost(z):
        r, L = z
        return c_s*rho*k*(r**2*L + r**3) + c_f*(4*np.pi*r**2)
    vol = {"type":"eq", "fun": lambda z: np.pi*z[0]**2*z[1] + 4/3*np.pi*z[0]**3 - V}
    return minimize(cost, [0.9, 2.0], constraints=[vol],
                    bounds=[(rmin, rmax), (0.0, None)],
                    method="SLSQP", options={"ftol":1e-14, "maxiter":3000})

for c_f in [0, 200, 400, 800]:
    r = solve(c_f)
    mat = c_s*rho*k*(r.x[0]**2*r.x[1] + r.x[0]**3); fab = c_f*4*np.pi*r.x[0]**2
    print(f"c_f={c_f:4d}: r*={r.x[0]:.4f} L*={r.x[1]:.4f} total={r.fun:8.1f} "
          f"(material {mat:.0f}, forming {fab:.0f})")
```
With $c_f = 0$ the optimum returns to the largest permitted radius with $L^\star = 0$-ish (the sphere, subject to the transport cap). As $c_f$ rises, the head-forming charge $\propto r^2$ makes large radii expensive, the optimizer shrinks $r$, and **$L^\star$ grows** — a genuine cylinder, exactly as §10.5 predicts. The cost split shifts steadily from material-dominated toward forming-dominated.
**Why a bound on $r$ (or $L$) is necessary:** the material cost of a long thin vessel tends to the aspect-ratio-independent limit $2pV/\sigma$ (10.2.1), while the head-forming charge $4\pi r^2c_f \to 0$ as $r \to 0$. So without a lower bound on $r$ the model drives $r \to 0$, $L \to \infty$ — an infinitely long capillary — with total cost approaching a finite limit but no attained minimum. The model is **ill-posed** (and thin-wall theory, and physical sense, fail long before that). This is the §10.3 lesson in reverse: whenever a cost term is monotone in a variable, some bound must be doing the design work, and it had better be a real one — here a minimum manufacturable radius, a maximum shippable length, or a support-span limit.

**10.5.4** (1) **The formulation is the physics.** The same English sentence — "minimize material for a given volume" — produced $h = 2r$ under one thickness assumption and a sphere under another. No algorithm can rescue a wrong objective, so the modelling step deserves more care than the solver choice. (2) **Optima can live on bounds.** Check monotonicity before hunting for $\nabla f = 0$, and when a variable is pinned at a bound, ask whether that bound is physics or convenience. (3) **A "wrong" answer is a list of what your model is missing** — and the multipliers price each missing item, converting a qualitative argument into a comparison of numbers.
*Example (structures):* a topology-optimized bracket comes back as a delicate lattice with 0.4 mm members. Wrong for manufacturing — and informative: it says the load paths are these, the stress constraint is inactive, and the binding consideration is minimum printable feature size, whose multiplier tells you what coarsening the mesh will cost in mass. *Example (process):* a heat-integration model recovers 98 % of the heat via a 40-shell network; the "wrong" answer prices capital-versus-energy and identifies which matches are doing the work.

## Solutions — 11.1 The problem, and its exact solution

**11.1.1** $\mathcal{L} = e^{x_1} + 2x_2^2 + \lambda(x_1+x_2-1)$, so KKT is
$$e^{x_1} + \lambda = 0,\qquad 4x_2 + \lambda = 0,\qquad x_1 + x_2 = 1.$$
Eliminating $\lambda$: $e^{x_1} = 4x_2 = 4(1-x_1)$, i.e.
$$\phi(x_1) \equiv e^{x_1} + 4x_1 - 4 = 0.$$
$\phi(0.5) = 1.6487 + 2 - 4 = -0.351 < 0$; $\phi(0.6) = 1.8221 + 2.4 - 4 = +0.222 > 0$, so the root is in $(0.5, 0.6)$. Newton from $0.5$: $\phi' = e^{x_1}+4 = 5.6487$, giving $x_1 \leftarrow 0.5 + 0.351/5.6487 = 0.56215$; one more step gives $0.561622$. Hence
$$x^\star = (0.561622,\ 0.438378),\quad \lambda^\star = -e^{0.561622} = -1.753514,\quad f^\star = 2.137865.$$

**11.1.2** Closed forms require the stationarity equations to be solvable in elementary functions, which happens only for very special combinations (quadratics, a few power laws, log/exp pairs that cancel). Real objectives mix exponentials, powers, roots, table look-ups and simulation outputs, so the KKT system is a nonlinear algebraic system with no symbolic solution — and that is *before* inequality constraints introduce the combinatorial question of which are active. Iterative solvers exist precisely because this is the normal case.
What to verify instead of "the formula": (i) the **KKT residuals** at the returned point (§9.7) — stationarity, feasibility, complementarity; (ii) the **multipliers**, against a perturbed re-solve; (iii) **the model's** behaviour — units, magnitudes, active set, monotonicity — since with no closed form to check against, model verification replaces algebra verification. This is the §21.3 discipline.

**11.1.3**
```python
import numpy as np
from scipy.optimize import brentq, minimize, LinearConstraint
x1 = brentq(lambda t: np.exp(t) + 4*t - 4, 0.0, 1.0, xtol=1e-15, rtol=1e-15)
print(f"root      x1={x1:.12f}  x2={1-x1:.12f}  lam={-np.exp(x1):.12f}"
      f"  f={np.exp(x1)+2*(1-x1)**2:.12f}")
r = minimize(lambda x: np.exp(x[0])+2*x[1]**2, [0,0],
             jac=lambda x: np.array([np.exp(x[0]), 4*x[1]]),
             method="SLSQP", constraints=[LinearConstraint([[1,1]],1,1)],
             options={"ftol":1e-16})
print(f"minimize  x*={np.round(r.x,12)}  f={r.fun:.12f}")
```
Both give $x_1 = 0.561622$, $x_2 = 0.438378$, $f = 2.137865$, agreeing to at least eight digits. Two independent computational routes to the same answer is the cheapest verification available (Preface, §21.3) — and here one of them is a *scalar* root-find, which is far easier to trust than a constrained optimizer.

**11.1.4** Rewrite stationarity as $e^{x_1} = 4x_2$, i.e. **marginal cost of activity 1 = marginal cost of activity 2**. Economically: at the optimum you cannot gain by shifting a small amount of effort from one activity to the other, because both consume effort at the same marginal rate. If activity 1's marginal cost were lower, you would move effort into it — that is exactly what a descent step would do.
$\lambda^\star = -1.7535$ is the **shadow price of the effort budget**: by §9.4, $\partial f^\star/\partial b = -\lambda^\star$ for the constraint written $x_1+x_2 = b$… careful with signs — here relaxing the budget from $1$ to $1+\varepsilon$ *increases* the total cost at rate $|\lambda^\star| = 1.7535$ per unit, since both cost curves are increasing and more effort must be spent. Equivalently, the common marginal cost at the optimum is $1.7535$ units of objective per unit of effort — the single number that prices the budget, and the same quantity from either activity, which is why the balance condition is the optimality condition.

## Solutions — 11.2 The SQP iteration, by hand

**11.2.1** At $x^{(0)} = (1,0)$: $\nabla f = (e^1,\ 0) = (2.718282,\ 0)$; $\nabla^2_{xx}\mathcal{L} = \operatorname{diag}(e^{1},\,4) = \operatorname{diag}(2.718282,\,4)$; $\nabla h = (1,1)$; $h = 1 + 0 - 1 = 0$ (this start is already feasible). The system
$$\begin{pmatrix}2.718282 & 0 & 1\\ 0 & 4 & 1\\ 1 & 1 & 0\end{pmatrix}\begin{pmatrix}d_1\\d_2\\\lambda^+\end{pmatrix} = \begin{pmatrix}-2.718282\\ 0\\ 0\end{pmatrix}.$$
Row 1: $d_1 = (-2.718282 - \lambda^+)/2.718282$. Row 2: $d_2 = -\lambda^+/4$. Row 3: $d_1 + d_2 = 0$, so
$$\frac{-2.718282-\lambda^+}{2.718282} = \frac{\lambda^+}{4} \implies -4(2.718282+\lambda^+) = 2.718282\lambda^+ \implies \lambda^+ = \frac{-10.873127}{6.718282} = -1.618143.$$
Then $d_2 = 0.404536$, $d_1 = -0.404536$, so $x^{(1)} = (0.595464,\ 0.404536)$.
**Feasible:** yes, exactly — $0.595464 + 0.404536 = 1$. Because $h$ is *linear*, its linear model is exact, so the KKT system's last row enforces the true constraint and every iterate after the first is exactly feasible. ($\lambda^+ = -1.618$ is already within 8 % of $\lambda^\star = -1.7535$.)

**11.2.2**
```python
import numpy as np
x = np.array([1.0, 0.0])
for k in range(5):
    gf = np.array([np.exp(x[0]), 4*x[1]]); H = np.diag([np.exp(x[0]), 4.0])
    a  = np.array([1.0, 1.0]); h = x[0] + x[1] - 1.0
    KKT = np.block([[H, a.reshape(2,1)], [a.reshape(1,2), np.zeros((1,1))]])
    d1, d2, lam = np.linalg.solve(KKT, np.array([-gf[0], -gf[1], -h]))
    d = np.array([d1, d2])
    print(f"k={k}  x=({x[0]:+.8f},{x[1]:+.8f})  lam={lam:+.6f}  |d|={np.linalg.norm(d):.2e}")
    x = x + d
```
The $|d|$ column falls roughly as $5.7\times10^{-1} \to 3\times10^{-2} \to 1\times10^{-4} \to 2\times10^{-9} \to 0$: each step's size is approximately the *square* of the previous one, i.e. the number of correct digits doubles per iteration — **quadratic convergence**, reaching machine precision in four steps. Same behaviour as the text's run from $(0,0)$, from a different start: SQP's rate is a local property of the KKT system, not of the starting point.

**11.2.3**
```python
import numpy as np
def sqp(use_lagrangian_hessian, n=6):
    x = np.array([2.0, 0.5]); lam = -1.0
    for k in range(n):
        gf = 2*x
        H  = np.array([[2.0, lam], [lam, 2.0]]) if use_lagrangian_hessian else np.eye(2)*2.0
        a  = np.array([x[1], x[0]]); h = x[0]*x[1] - 1.0
        KKT = np.block([[H, a.reshape(2,1)], [a.reshape(1,2), np.zeros((1,1))]])
        s = np.linalg.solve(KKT, np.array([-gf[0], -gf[1], -h]))
        d, lam = s[:2], s[2]
        print(f"  k={k} x=({x[0]:+.8f},{x[1]:+.8f}) h={h:+.2e} lam={lam:+.6f} |d|={np.linalg.norm(d):.2e}")
        x = x + d
print("(a) Hessian of f only:");        sqp(False)
print("(b) Hessian of the Lagrangian:"); sqp(True)
```

| $k$ | $|d|$ with $\nabla^2 f$ only | $|d|$ with $\nabla^2_{xx}\mathcal{L}$ |
|---|---|---|
| 0 | 1.82 | 1.47 |
| 1 | 1.17 | 5.15e-1 |
| 2 | 1.22 | 6.28e-2 |
| 3 | 1.17 | 1.68e-3 |
| 4 | 1.18 | 2.85e-6 |
| 5 | 1.17 | 3.19e-12 |

Case (a) **never converges**: the iterates oscillate between roughly $(0.26, 1.06)$ and $(1.14, 0.28)$ forever, with $|d|$ stuck near 1.2 and the constraint residual never approaching zero. Case (b) converges **quadratically** to $x^\star = (1,1)$, $\lambda^\star = -2$, hitting $|d| \sim 10^{-12}$ by the sixth step.
The reason: SQP is Newton's method on the KKT *system*, whose Jacobian contains $\nabla^2_{xx}\mathcal{L} = \nabla^2 f + \lambda\nabla^2 h$. Here $\nabla^2 h = \begin{pmatrix}0&1\\1&0\end{pmatrix} \ne 0$, so omitting $\lambda\nabla^2 h$ uses the wrong Jacobian and destroys Newton's convergence entirely — it is not a small penalty but a qualitative failure. The text's example has a *linear* constraint, where $\nabla^2h = 0$ and the two Hessians coincide, which is why the distinction is invisible there. **Whenever a constraint is curved, the curvature of the constraint (weighted by its multiplier) is part of the right model.**

**11.2.4** With a linear constraint, the linearized constraint *is* the constraint, so a single SQP step lands exactly on the feasible set and stays there; the constraint residual is zero from iteration 1 onward and carries no information about convergence. With a **nonlinear** constraint the linear model is only an approximation, so each step lands slightly off the true surface: feasibility is restored only *asymptotically*, and the residual $|h(x_k)|$ decreases at the same quadratic rate as the step (see the $h$ column in 11.2.3(b): $-5\times10^{-1} \to 8\times10^{-2} \to 8\times10^{-4} \to -1\times10^{-6} \to -4\times10^{-12}$).
Implication: the constraint residual is a *legitimate* convergence measure only for nonlinear constraints, and for linear ones it is trivially zero and tells you nothing. In general you must monitor all three residuals of §9.7 — which is exactly why solvers report them separately.

**11.2.5** (i) **A line search or trust region on the SQP step** (with a merit function or filter combining objective and constraint violation) — prevents divergence far from the solution, where the quadratic/linear models are unreliable and the full Newton step may increase both $f$ and infeasibility. (ii) **Quasi-Newton updates of $\nabla^2_{xx}\mathcal{L}$** (BFGS-type, often with damping to keep it positive definite) — prevents the need for exact second derivatives, and prevents indefinite Hessian blocks from producing meaningless steps. (iii) **An active-set (or QP-subproblem) mechanism for inequalities**, with handling of infeasible QP subproblems (elastic mode / relaxation) — prevents the algorithm from stalling when the linearized constraints are inconsistent, and decides *which* inequalities to treat as equalities at each iterate.

## Solutions — 11.3 Adding an inequality, and reading the multipliers

**11.3.1** Guess the cap is active (the unconstrained-in-$x_2$ answer wanted $x_2 = 0.438 > 0.2$). Then $x_2 = 0.2$ and feasibility of the equality gives $x_1 = 0.8$. With $g = x_2 - 0.2 \le 0$ and $h = x_1+x_2-1 = 0$:
$$e^{x_1} + \lambda = 0 \implies \lambda^\star = -e^{0.8} = -2.225541,$$
$$4x_2 + \lambda + \mu = 0 \implies \mu^\star = -4(0.2) + 2.225541 = -0.8 + 2.225541 = 1.425541 > 0\ \checkmark$$
Dual feasibility holds, so the guess was right:
$$x^\star = (0.8,\ 0.2), \quad \lambda^\star = -2.225541, \quad \mu^\star = +1.425541, \quad f^\star = e^{0.8} + 2(0.04) = 2.305541.$$
(Compare the text's looser cap $x_2\le0.3$: $\mu^\star = 0.8138$. Tightening the cap raises its price — the constraint is hurting more.)

**11.3.2**
```python
import numpy as np
from scipy.optimize import minimize, LinearConstraint
f  = lambda x: np.exp(x[0]) + 2*x[1]**2
gf = lambda x: np.array([np.exp(x[0]), 4*x[1]])
cons = [LinearConstraint([[1,1]], 1, 1), LinearConstraint([[0,1]], -np.inf, 0.2)]
r = minimize(f, [0,0], jac=gf, method="trust-constr", constraints=cons, tol=1e-12)
print("trust-constr x* =", np.round(r.x,6), " f* =", round(r.fun,6),
      " multipliers:", [round(float(v[0]),6) for v in r.v])
s = minimize(f, [0,0], jac=gf, method="SLSQP", constraints=cons, options={"ftol":1e-16})
print("SLSQP        x* =", np.round(s.x,10), " f* =", round(s.fun,10))
```
`trust-constr` returns $x^\star = (0.800004,\ 0.199996)$ with $f^\star = 2.305547$ and multipliers $-2.225551$ and $+1.425569$ — matching the hand values $-2.225541$ and $+1.425541$ to five digits. `SLSQP` returns $(0.8,\ 0.2)$ exactly.
The difference is structural (§9.6): `trust-constr` is a **barrier/interior-point** method, so it approaches the active constraint from the strictly feasible side and stops when within tolerance — it never sits exactly on the boundary. `SLSQP` solves a QP whose linearized active constraints are satisfied *exactly*, so it lands on the vertex. If a downstream calculation needs the constraint met exactly (a mass balance, a geometric closure), use the SQP answer or project the interior-point answer onto the active set.

**11.3.3** *"Your cap on $x_2$ currently costs about 1.43 units of objective per unit of relaxation. If you can raise the limit from 0.20 to 0.25, that is worth roughly $0.05 \times 1.43 \approx 0.07$ units — I can tell you that without re-solving anything."*
If they ask for 0.5 of relaxation (to $x_2 \le 0.7$): **decline to extrapolate, and re-solve.** The multiplier is a derivative, valid locally; a relaxation of 0.5 is enormous here, and in fact the cap stops binding altogether once it exceeds $0.438378$ (the unconstrained-in-$x_2$ optimum from §11.1). So the true saving is $f^\star(0.2) - f^\star(\text{no cap}) = 2.305541 - 2.137865 = 0.167676$, not the extrapolated $0.5\times1.4255 = 0.713$ — an overestimate by a factor of more than four. Beyond $x_2 = 0.438$ further relaxation is worth exactly **zero**. This is §5.6's lesson in nonlinear form: shadow prices are slopes, valid to the next kink; for large changes, re-solve.

**11.3.4** (1) **Check which constraints are active.** Protects you from misreading the design: the active set is the physical story (§1.4), and multipliers are meaningless without it. (2) **Read the multipliers.** Protects you from leaving the most decision-relevant output of the model unused — the price of every requirement, available at no extra cost. (3) **Sanity-check at least one multiplier against a perturbed re-solve or a hand KKT argument.** Protects you from degenerate or non-unique multipliers (§5.8, §9.4), from sign-convention errors (solvers differ), and from a solver that converged to loose tolerances — all of which produce numbers that look authoritative and are wrong.

## Solutions — 12.1 The finite-difference step-size trap

**12.1.1** Forward difference: the Taylor remainder gives truncation error $\approx \tfrac12 h|f''(x)|$, and evaluating $f$ to relative precision $\epsilon$ gives an absolute error $\approx \epsilon|f|$ in each of the two evaluations, hence round-off $\approx 2\epsilon|f|/h$. Total
$$E(h) \approx \tfrac12 h|f''| + \frac{2\epsilon|f|}{h}, \qquad E'(h) = \tfrac12|f''| - \frac{2\epsilon|f|}{h^2} = 0 \implies h^\star = 2\sqrt{\frac{\epsilon|f|}{|f''|}}.$$
With $|f|, |f''|$ of order 1 (or scaled by $|x|$), $h^\star \sim \sqrt{\epsilon}$, and the achievable error is $E(h^\star) \sim \sqrt{\epsilon}$ — you keep about **half** the available digits.
Central difference: truncation is $O(h^2)$, specifically $\tfrac16h^2|f'''|$, and round-off is still $\approx \epsilon|f|/h$:
$$E(h) \approx \tfrac16h^2|f'''| + \frac{\epsilon|f|}{h} \implies \frac13 h|f'''| = \frac{\epsilon|f|}{h^2} \implies h^\star \sim \epsilon^{1/3},$$
with error $E(h^\star) \sim \epsilon^{2/3}$ — about **two-thirds** of the digits, at twice the cost per component.

**12.1.2**
```python
import numpy as np, math
x0, exact = 1.0, math.cos(1.0)
for h in [1e-1, 1e-4, 1e-8, 1e-12]:
    fwd = (math.sin(x0+h) - math.sin(x0))/h
    cen = (math.sin(x0+h) - math.sin(x0-h))/(2*h)
    cst = np.imag(np.sin(x0 + 1j*h))/h
    print(f"h={h:.0e}  fwd={abs(fwd-exact):.1e}  cen={abs(cen-exact):.1e}  cstep={abs(cst-exact):.1e}")
```

| $h$ | forward | central | complex step |
|---|---|---|---|
| $10^{-1}$ | $4.3\times10^{-2}$ | $9.0\times10^{-4}$ | $9.0\times10^{-4}$ |
| $10^{-4}$ | $4.2\times10^{-5}$ | $9.0\times10^{-10}$ | $9.0\times10^{-10}$ |
| $10^{-8}$ | $3.0\times10^{-9}$ | $2.6\times10^{-9}$ | $1.1\times10^{-16}$ |
| $10^{-12}$ | $4.3\times10^{-5}$ | $1.2\times10^{-5}$ | $\mathbf{0}$ |

Forward differences bottom out near $h \approx 10^{-8}$ with an error floor of $\sim10^{-9}$ (matching $\sqrt{\epsilon}$); central differences do best near $h \approx 10^{-5}$–$10^{-6}$ with a floor around $10^{-11}$ ($\epsilon^{2/3}$); both **deteriorate** by orders of magnitude at $h = 10^{-12}$. The complex step has no round-off branch at all — its error falls monotonically and reaches exactly zero, because no subtraction of nearly equal numbers ever occurs (§12.2).

**12.1.3**
```python
import numpy as np
rng = np.random.default_rng(5)
def fsim(x, noise=1e-6): return np.exp(x)*(1 + noise*rng.normal())
exact = np.exp(1.0)
for h in [1e-1, 1e-2, 1e-3, 1e-4, 1e-6, 1e-8]:
    errs = [abs((fsim(1.0+h) - fsim(1.0))/h - exact) for _ in range(200)]
    print(f"h={h:.0e}  median error = {np.median(errs):.2e}")
```

| $h$ | median forward-difference error |
|---|---|
| $10^{-1}$ | $1.4\times10^{-1}$ |
| $10^{-2}$ | $1.4\times10^{-2}$ |
| $10^{-3}$ | $\mathbf{2.5\times10^{-3}}$ (best) |
| $10^{-4}$ | $2.4\times10^{-2}$ |
| $10^{-6}$ | $2.5$ |
| $10^{-8}$ | $2.7\times10^{2}$ |

The best step is $h \approx 10^{-3} = \sqrt{10^{-6}}$ — exactly the $\sqrt{\text{noise}}$ rule with the noise floor set by the *simulation tolerance*, not by machine epsilon. The achievable error there is $\approx2.5\times10^{-3}$, i.e. a gradient accurate to about three digits at best. Compare the noise-free case (12.1.2), where forward differences reach $\sim10^{-9}$: **six orders of magnitude of accuracy have been lost to a $10^{-6}$ simulation tolerance.** And note the catastrophe at small $h$: at $h = 10^{-8}$ the "gradient" is wrong by a factor of 100 — it has no relationship to the derivative at all, yet nothing in the code errors out.

**12.1.4** With a noise floor $\epsilon_{\text{eff}} \approx 10^{-5}$, the best forward-difference step is $h^\star \sim \sqrt{10^{-5}} \approx 3\times10^{-3}$ (relative), and the best achievable gradient error is also $O(\sqrt{\epsilon_{\text{eff}}}) \approx 3\times10^{-3}$ *relative* — roughly two to three correct digits, per component, on a good day. Cost: $n+1 = 31$ CFD runs per gradient (61 for central differences), every iteration.
**Conclusion:** finite differences here are both ruinously expensive and barely accurate enough to define a descent direction — and a gradient with 3 digits will stall a quasi-Newton method, whose curvature estimates are built from gradient *differences* (§7.4.3). The right responses, in order of preference: (i) get **exact** derivatives — adjoint/AD from the CFD code, which costs about one extra solve for the whole gradient regardless of $n$; (ii) if the source is unavailable, use **surrogate-based or Bayesian optimization** (Part V), which is designed for expensive noisy black boxes; (iii) tighten the simulation tolerance if cheap, since $\epsilon_{\text{eff}}$ enters as $\sqrt{\cdot}$. Recognizing this situation is a *diagnosis*, not a defeat — it is precisely the criterion the text gives for legitimately leaving Part III for Part V.

## Solutions — 12.2 Complex-step differentiation: the escape hatch

**12.2.1** For analytic $f$ and real $x$, $h$:
$$f(x+ih) = f(x) + ih f'(x) + \frac{(ih)^2}{2}f''(x) + \frac{(ih)^3}{6}f'''(x) + \cdots = \underbrace{f(x) - \frac{h^2}{2}f''(x) + \cdots}_{\text{real}} + i\underbrace{\Big(hf'(x) - \frac{h^3}{6}f'''(x) + \cdots\Big)}_{\text{imaginary}}.$$
Taking the imaginary part and dividing by $h$:
$$\frac{\operatorname{Im}[f(x+ih)]}{h} = f'(x) - \frac{h^2}{6}f'''(x) + O(h^4) = f'(x) + O(h^2).$$
**No cancellation** because the derivative appears *alone* in the imaginary part — it is not obtained by subtracting two nearly equal real numbers. In a finite difference, $f(x+h)$ and $f(x)$ agree to many digits and their difference destroys most of them; here the real and imaginary parts are stored in separate floating-point words, so $\operatorname{Im}$ is an exact extraction, and $h$ may be taken as small as $10^{-20}$ without any loss. The only error left is the $O(h^2)$ truncation term, which vanishes as $h\to0$.

**12.2.2** Requirements: (i) the code must **run in complex arithmetic** — all variable declarations, intermediate arrays and library calls must accept complex input (NumPy mostly does; Fortran needs `complex(8)` throughout); (ii) every operation must **preserve analyticity** on the path from input to output.
Three operations that silently break it:
- **`abs(z)`** — for complex arguments NumPy returns the *modulus* $\sqrt{a^2+b^2}$, which is real, so the imaginary part is destroyed and the derivative comes back wrong (see 12.2.3). Analytic replacement: `z if z.real >= 0 else -z`.
- **`min` / `max`** (and `np.maximum`, `np.clip`) — comparisons on complex numbers either error out or compare only real parts, silently discarding derivative information at the branch.
- **`np.transpose(...).conj()` or any use of `.conj()`, `np.vdot`, `np.linalg.norm`** — conjugation flips the sign of the derivative part, and `norm` uses conjugates internally; use $\sqrt{z^\top z}$ (no conjugate) instead. Also `if x > 0` branches, `np.sign`, `np.floor`, `round`, and comparison-based table look-ups.

**12.2.3**
```python
import numpy as np
h = 1e-20
f_bad  = lambda z: z * abs(z)                                  # abs -> modulus for complex
f_good = lambda z: z * (z if z.real >= 0 else -z)              # analytic on each branch
print("bad :", np.imag(f_bad (2 + 1j*h))/h)   # 2.0   (WRONG; true value 4)
print("good:", np.imag(f_good(2 + 1j*h))/h)   # 4.0   (correct)
```
With `abs`, $|2 + ih| = \sqrt{4+h^2} \approx 2$ exactly (a *real* number), so the product is $(2+ih)\cdot2$ and the imaginary part divided by $h$ returns $2$ — the value of $|x|$, not the derivative $2|x| = 4$. The failure is silent: no exception, no warning, and the answer is wrong by a factor of two. Replacing `abs(z)` by the analytic branch $\pm z$ restores the exact answer $4$. **Moral:** complex-step is exact when it applies, and quietly wrong when it does not — so it must be validated against a central difference the first time it is used on a new code path.

**12.2.4** **Argument for complex-step:** the objective is a thermal-stress computation — smooth physics, built from arithmetic and elementary functions — so it is very likely analytic on the paths that matter. Complex-step then delivers **machine-precision derivatives** where finite differences would give at best half the digits, and (crucially) the accuracy is insensitive to $h$, removing the step-size tuning problem entirely. That matters most because a gradient-based method's convergence depends on gradient quality (§7.4, §12.1): with exact derivatives you can use BFGS/SQP as designed; with $10^{-8}$-accurate ones you fight stalls and line-search failures. Cost-wise it is comparable to forward differences ($n$ complex evaluations, each perhaps 2–3× a real one) and needs no restructuring of the algorithm.
**Two practical costs:** (i) **a conversion sweep of the source** — every real declaration, intermediate array and I/O buffer on the differentiation path must become complex, and every non-analytic construct (`abs`, `min`/`max`, sign tests, `if` branches on magnitudes, table interpolation with comparisons, convergence tests) must be found and rewritten; missing one produces a silently wrong gradient, so the conversion needs a component-by-component validation against central differences. (ii) **runtime and memory** roughly double to quadruple, and the cost still scales as $O(n)$ evaluations for an $n$-dimensional gradient — unlike an adjoint/reverse-mode approach, which would get the whole gradient for about one extra solve. So for large $n$, complex-step is a good *interim* answer, and an adjoint is the eventual one.

## Solutions — 12.3 Automatic differentiation in twenty lines

**12.3.1** A dual number carries the pair $(v, d)$ = (the value of an intermediate quantity, its derivative with respect to the chosen input). Every operation must update both.
*Product rule:* if $u = (u_v, u_d)$ and $w = (w_v, w_d)$ represent quantities $u$ and $w$ with their derivatives, then $(uw)' = u'w + uw'$, so
$$u \cdot w = \big(u_vw_v,\ u_dw_v + u_vw_d\big),$$
which is exactly `Dual(self.val*o.val, self.der*o.val + self.val*o.der)`.
*Chain rule:* for $g = \exp(u)$, $g' = e^{u}u'$, so $\exp(u) = (e^{u_v},\ e^{u_v}u_d)$ — the code's `Dual(e, e*z.der)`.
The **seed** is set to 1 because we differentiate with respect to the input variable itself: $dx/dx = 1$. Setting $x = \mathtt{Dual}(x_0, 1)$ initializes the chain, and every subsequent operation propagates that seed forward. Seeding a different variable with 1 (and the rest with 0) computes the partial derivative with respect to *that* variable — which is how 12.3.2 gets both components.

**12.3.2**
```python
import math

class Dual:
    def __init__(self, val, der=0.0): self.val, self.der = val, der
    def _c(o): return o if isinstance(o, Dual) else Dual(o)
    def __add__(s, o): o = Dual._c(o); return Dual(s.val+o.val, s.der+o.der)
    __radd__ = __add__
    def __sub__(s, o): o = Dual._c(o); return Dual(s.val-o.val, s.der-o.der)
    def __rsub__(s, o): o = Dual._c(o); return Dual(o.val-s.val, o.der-s.der)
    def __mul__(s, o): o = Dual._c(o); return Dual(s.val*o.val, s.der*o.val + s.val*o.der)
    __rmul__ = __mul__
    def __truediv__(s, o):
        o = Dual._c(o)
        return Dual(s.val/o.val, (s.der*o.val - s.val*o.der)/o.val**2)

def sin(z): return Dual(math.sin(z.val), math.cos(z.val)*z.der)

f = lambda a, b: a*a*b + sin(a*b)
a0, b0 = 1.5, 2.0
df_da = f(Dual(a0, 1.0), Dual(b0, 0.0)).der      # seed a
df_db = f(Dual(a0, 0.0), Dual(b0, 1.0)).der      # seed b
print(f(Dual(a0,1.0), Dual(b0,0.0)).val, df_da, df_db)
print(a0**2*b0 + math.sin(a0*b0),
      2*a0*b0 + b0*math.cos(a0*b0), a0**2 + a0*math.cos(a0*b0))
```
Results: $f = 4.641120008059867$, $\partial f/\partial a = 4.02001500679911$, $\partial f/\partial b = 0.7650112550993318$ — matching the analytic $2ab + b\cos(ab)$ and $a^2 + a\cos(ab)$ **to every digit**, with no step size anywhere.
Forward mode needs **one pass per input**, so $n$ passes for an $n$-variable gradient (here 2).

**12.3.3** For $f:\mathbb{R}^n\to\mathbb{R}$:
- **Forward mode** propagates derivatives *with* the computation, one seed at a time: cost $\approx n \times$ (one function evaluation). Cheap when $n$ is small, or when you want $\partial(\text{many outputs})/\partial(\text{one input})$.
- **Reverse mode** evaluates the function once (recording the operations), then sweeps *backwards* applying the chain rule from the output to the inputs: cost $\approx$ **a small constant times one function evaluation, independent of $n$**. The price is memory — the tape of intermediate values.
Reverse mode is what makes the two headline applications possible. Training a network with $10^9$ parameters requires $\partial(\text{one loss})/\partial(10^9 \text{ weights})$; forward mode would need $10^9$ passes, reverse mode needs one. Likewise **adjoint** shape optimization: the gradient of one drag coefficient with respect to $10^4$ shape variables costs about one extra PDE solve rather than $10^4$ of them — that single fact is the difference between aerodynamic shape optimization being routine and being impossible.

**12.3.4** The checklist, with the failure each prevents:
1. **Hand-derived gradient → compare against a central difference at a random point (agree to ~6 digits).** Prevents an algebra error that yields a wrong descent direction; the failure mode is a solver that stalls, reports "line search failed," or converges to a non-stationary point. Seen in §0.1.3 (the dropped $2x_2$ term that passes a check at $x_2=0$) and §7.5.3.
2. **If you must use finite differences, use the $h^\star$ rules scaled per component by $|x_k|$.** Prevents the step-size trap — either truncation-dominated garbage from a large $h$ or round-off-dominated garbage from a small one. §12.1, and foreshadowed in §0.2.3 where the second-order Taylor error underflowed to exactly zero.
3. **If $f$ is a noisy simulation, do not use finite differences at all — go to Part V.** Prevents chasing a gradient that does not exist at the scale you are probing; the accuracy ceiling is $\sqrt{\text{noise}}$, and quasi-Newton curvature estimates built from such gradients are meaningless. §12.1.3–4, §7.4.3.
4. **If you control the source, prefer AD or complex-step — both are exact.** Prevents all of the above, and removes step-size tuning entirely. §12.2, §12.3.

## Solutions — 13.1 The problem class, and why it is hard

**13.1.1** Every method in Parts I–III relies on *local motion*: take a small step, measure the change. Integrality replaces a connected feasible set with a scatter of isolated points, so there is no small step to take — and simultaneously the combinatorics explode ($2^{100} \approx 10^{30}$ for 100 binaries).
Specifically: **§0.1** (the gradient as the direction of steepest change) becomes meaningless, since $f$ is not defined between lattice points and no derivative describes the allowed moves; **§3.1** (convexity) has nothing to act on, because a finite scatter of points is not a convex set — indeed the local-implies-global theorem of §3.2 fails outright; **§4.1** (the fundamental theorem of LP: an optimal vertex exists, reachable by edge-following) fails because the integer optimum is generally *not* a vertex of the LP polyhedron, and there are no edges connecting integer points.

**13.1.2** Deleting the integrality requirement can only *enlarge* the feasible set: $\mathcal{F}_{\text{MILP}} \subseteq \mathcal{F}_{\text{LP}}$. Minimizing over a larger set cannot give a larger value, so
$$z_{\text{LP}} = \min_{\mathcal{F}_{\text{LP}}} c^\top x \;\le\; \min_{\mathcal{F}_{\text{MILP}}} c^\top x = z_{\text{MILP}},$$
i.e. the LP value is a **lower bound** for minimization. For maximization the inequality flips and it is an **upper bound**. (Mnemonic: the relaxation is *optimistic* — it always reports something at least as good as reality.)

**13.1.3**
```python
import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds
c, A, b = [-4, -3], [[3, 4], [4, 2]], [12, 10]
r = linprog(c, A_ub=A, b_ub=b, bounds=[(0, None)]*2, method="highs")
print("LP:", np.round(r.x, 4), " z =", -r.fun)
pts = [(i, j) for i in range(4) for j in range(5) if 3*i+4*j <= 12 and 4*i+2*j <= 10]
print("integer points:", pts)
print("best:", max(pts, key=lambda p: 4*p[0]+3*p[1]), max(4*p[0]+3*p[1] for p in pts))
```
LP relaxation: $x = (1.6,\ 1.8)$, $z_{\text{LP}} = 11.8$ (solve $3x_1+4x_2=12$ with $4x_1+2x_2=10$).
The nine feasible integer points are $(0,0),(0,1),(0,2),(0,3),(1,0),(1,1),(1,2),(2,0),(2,1)$, and the best is $x^\star = (2,1)$ with $z^\star = \mathbf{11}$.
Integrality gap: $11.8 - 11 = 0.8$ absolute, $0.8/11 = \mathbf{7.3\%}$ relative — a fairly tight relaxation, which is why the branch-and-bound tree in 14.1.1 will be small.

**13.1.4** §9.5's framing: any **feasible point** gives a bound on one side (an achieved value); any **relaxation or dual-feasible multiplier** gives a bound on the other side; optimality is proved when they meet. The LP relaxation is exactly the second kind of object. Formally, for a minimization, dropping integrality is a relaxation of the constraint set, and $\inf$ over a superset is a valid lower bound — the same one-line argument that gives $q(\mu,\lambda) = \inf_x\mathcal{L} \le f^\star$ in §9.5 (there the constraints are relaxed into the objective with multipliers; here they are simply deleted). Both are instances of *bound-by-relaxation*, both require no convexity of the original problem, and both are useless without the matching feasible point. Branch and bound (§14.3) is then literally the two-bounds-meeting certificate tracked in real time: incumbent above, best open relaxation below, MIP gap between.

## Solutions — 13.2 The logic vocabulary

**13.2.1** Let $0 \le x \le U$, $y \in\{0,1\}$, and impose $w \le x$, $w \le Uy$, $w \ge x - U(1-y)$, $w \ge 0$.
- **$y = 0$:** the second gives $w \le 0$ and the fourth gives $w \ge 0$, so $w = 0$ ✓ (and $= yx$). The other two are slack: $w \le x$ holds since $x \ge 0$, and $w \ge x - U$ holds since $x \le U$.
- **$y = 1$:** the third becomes $w \ge x$ and the first is $w \le x$, so $w = x$ ✓ (and $= yx$). The second is $w \le U$, which holds since $x \le U$; the fourth holds since $x\ge0$.
So in both cases the four inequalities force $w$ to exactly $yx$ — an **exact** linearization, not an approximation. (Note where $U$ earns its keep: the third inequality is a big-M constraint, and an inflated $U$ weakens the relaxation exactly as in §13.3.)

**13.2.2**
(a) $x$ = power [kW], $y\in\{0,1\}$ = running: $\;30y \le x \le 80y$. (Semi-continuous: $y=0$ forces $x=0$; $y=1$ forces $30\le x\le 80$.)
(b) $y_k\in\{0,1\}$ = supplier $k$ used, $k=1..5$: $\;\sum_{k=1}^{5}y_k \le 2$, plus linking constraints $q_k \le U_ky_k$ on the purchased quantities $q_k$ (without these, "used" is decoupled from actual purchases).
(c) $y_{\text{pipe}} \le y_{\text{pump}}$.
(d) $s_5, s_8 \ge 0$ start times, $p_5, p_8$ durations, $z\in\{0,1\}$ = "5 precedes 8", $M = 40$ (the horizon, *not* $10^9$):
$$s_8 \ge s_5 + p_5 - 40(1-z), \qquad s_5 \ge s_8 + p_8 - 40z.$$
(e) $\sum_{k=1}^{8}y_k = 3$.

**13.2.3**
```python
import numpy as np
from scipy.optimize import milp, LinearConstraint, Bounds
# variables: x (output), y (binary)
def solve(with_link):
    rows = [[-1.0, 0.0]]; ub = [-40.0]                 # -x <= -40  (x >= 40)
    if with_link: rows.append([1.0, -60.0]); ub.append(0.0)   # x - 60y <= 0
    return milp(c=[3.0, 200.0], constraints=[LinearConstraint(rows, ub=ub)],
                integrality=[0, 1], bounds=Bounds([0, 0], [np.inf, 1]))
for wl in (False, True):
    r = solve(wl)
    print(f"link={wl}: cost={r.fun:.1f}  x={r.x[0]:.1f}  y={r.x[1]:.0f}")
```
Without the link: cost **120**, $x = 40$, $y = \mathbf{0}$ — the model produces 40 units while declaring the unit switched off, and pays no fixed cost. With the link: cost **320**, $x = 40$, $y = 1$ — the correct answer.
The symptom is exactly the one the text names: **an answer that is too good**. Nothing errors out, no constraint is violated, and the optimizer is behaving correctly — it found a genuine loophole in the algebra, namely that $y$ appears only in the objective (where it is costly) and nowhere else. The linking constraint is what says *you may only use it if you have bought it*.

**13.2.4** Audit, in order:
1. **Linking constraints.** For every binary, ask: does it appear anywhere except the objective? If a fixed-cost binary has no $x \le Uy$ tying it to the activity it enables, the model is buying capacity for free. This is the most likely cause — nearly every binary-variable bug in practice is a missing or mis-signed linking constraint.
2. **Read the active set and the solution itself** (§1.4, §2.1 step 5): print which constraints bind, and look at the decisions. A "too good" answer usually contains one physically impossible line — a unit running above capacity, a shipment from an unopened site, two jobs overlapping.
3. **Check big-Ms and bounds.** A big-M large enough to be non-binding effectively deletes the constraint it appears in; a missing upper bound lets a variable go somewhere absurd.
4. **Check constraint senses and units.** A flipped $\le$/$\ge$ or a unit mismatch (tonnes vs kg) can relax a real limit by orders of magnitude.
5. **Validate against a known case.** Fix the decisions to a historical plan, check the model reproduces its cost; if it does not, the *cost model*, not the optimizer, is wrong.

## Solutions — 13.3 Worked Example 8 — the big-M trap, quantified

**13.3.1** Relax $y\in\{0,1\}$ to $0\le y\le1$. The objective penalizes $y$ at 200 per unit, so the relaxation makes $y$ as small as the linking constraint allows: $y \ge x/M$. And $x$ is pushed to its own minimum, $x = 40$ (variable cost 3 > 0). Hence
$$y_{\text{LP}} = \frac{40}{M}, \qquad z_{\text{LP}} = 200\cdot\frac{40}{M} + 3(40) = \frac{8000}{M} + 120.$$

| $M$ | $y_{\text{LP}}$ | LP bound | gap to 320 |
|---|---|---|---|
| **60** (true capacity) | 0.6667 | **253.33** | 20.8 % |
| 1 000 | 0.0400 | 128.00 | 60.0 % |
| $10^6$ | 0.00004 | 120.01 | 62.5 % |

True integer optimum: $y = 1$, $x = 40$, cost $= 200 + 120 = \mathbf{320}$.

**13.3.2**
```python
import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds
for M in [60, 1000, 10**6]:
    r = linprog([3, 200], A_ub=[[-1, 0], [1, -M]], b_ub=[-40, 0],
                bounds=[(0, None), (0, 1)], method="highs")
    print(f"M={M:>9,}: LP bound={r.fun:9.4f}  y={r.x[1]:.6f}  formula={8000/M+120:.4f}")
ri = milp(c=[3, 200], constraints=[LinearConstraint([[-1,0],[1,-60]], ub=[-40,0])],
          integrality=[0,1], bounds=Bounds([0,0],[np.inf,1]))
print("MILP:", ri.x, ri.fun)
```
Output matches the table exactly: 253.3333, 128.0000, 120.0080; MILP cost 320.
Half the fixed cost (100 of 200) remains in the bound when $8000/M = 100$, i.e. $M = 80$. Since the true capacity is 60, **inflating $M$ from 60 to just 80 already loses a quarter of the fixed cost from the bound** — the collapse is fast, and it is why "round it up to be safe" is the wrong instinct.

**13.3.3** (a) $M = 120$ m³/h — the pump rating. (b) $M = 120$ h (3 shifts × 8 h × 5 days), the scheduling horizon. (c) $M = 4000$ t — the contract limit. (d) $M = 250$ °C.
The pattern: every big-M has a *physical* referent — a rating, a horizon, a contract, a physical range. If you cannot name the quantity, you do not yet know your model. When a genuine upper bound is unknown, derive one from the constraints (e.g. $x \le \min_i b_i/a_{ij}$ over rows where $a_{ij}>0$) rather than picking a round number.

**13.3.4** A loose big-M produces a **weak relaxation**, hence a **slow** search — and in practice "slow" means "no answer within the time limit," which is operationally the same as no answer. Mechanically: branch and bound prunes a node when its relaxation bound cannot beat the incumbent. With $M = 10^6$ the bound is ~120 against a truth of 320, so it is far below every incumbent and *no node can be pruned on the basis of the fixed costs* — precisely the decisions the model exists to make. The tree degenerates toward blind enumeration of the $2^n$ on/off combinations.
Two further consequences worth naming: the reported **MIP gap** stays large, so even a good solution found early cannot be *certified* and you cannot stop confidently (§14.3); and numerically, coefficients of $10^6$ alongside coefficients of order 1 create the badly scaled constraint matrix of §2.3, which can cause LP solver instability and spurious "infeasible" reports at nodes.

## Solutions — 13.4 Canonical models worth recognizing — and a real model in Pyomo

**13.4.1** (a) **Knapsack** — select a subset of items (jobs) with values and "weights" (durations) under a single budget (the window). (b) **Semi-continuous / unit commitment** — on/off binaries with minimum stable output, $L_iy_i \le x_i \le U_iy_i$. (c) **Set covering** — every weld (row) must be covered by at least one chosen camera position. (d) **Sequencing with disjunctions** — pairwise either–or constraints on start times over a shared machine. (e) **Capacitated facility location** — open/close binaries plus assignment flows with capacity linking.

**13.4.2** Variables: $y_i\in\{0,1\}$ (open site $i$), $x_{ij}\ge0$ (units shipped $i\to j$).
$$\min \sum_{i=1}^{3}K_iy_i + \sum_{i=1}^{3}\sum_{j=1}^{4}C_{ij}x_{ij}$$
$$\text{s.t.}\quad \sum_{i}x_{ij} = d_j\ \ \forall j, \qquad \sum_{j}x_{ij} \le U_i\,y_i\ \ \forall i, \qquad x \ge 0,\ y\in\{0,1\}^3.$$
(The capacity constraint *is* the linking constraint, and $U_i$ is a true capacity — this model is born with tight big-Ms.)
*Hand evaluation of "open 2 and 3":* fixed cost $250+300 = 550$. Cheaper option per customer among $\{2,3\}$: cust 1 → site 3 (6 vs 7); cust 2 → site 2 (3 vs 5); cust 3 → site 3 (4 vs 5); cust 4 → site 3 (3 vs 8). Site 3 would then carry $20+25+10 = 55 > U_3 = 50$ — **capacity violated**, so 5 units must move to site 2. The cheapest reassignment is the one with the smallest penalty: moving 5 units of customer 3 from site 3 to site 2 costs $+1$/unit $= +5$ (customer 1 would cost $+1$/unit too; customer 4 costs $+5$/unit). Site 2 then carries $15+5 = 20 \le 45$ ✓.
Shipping $= 6(20) + 3(15) + 4(20) + 5(5) + 3(10) = 120+45+80+25+30 = 300$. **Total $= 550 + 300 = 850$.**

**13.4.3**
```python
import numpy as np, cvxpy as cp
K = np.array([350., 250., 300.]); U = np.array([60., 45., 50.])
d = np.array([20., 15., 25., 10.])
C = np.array([[4., 6., 9., 5.], [7., 3., 5., 8.], [6., 5., 4., 3.]])

def solve(binary):
    y = cp.Variable(3, boolean=True) if binary else cp.Variable(3, nonneg=True)
    x = cp.Variable((3, 4), nonneg=True)
    cons = [cp.sum(x, axis=0) == d, cp.sum(x, axis=1) <= cp.multiply(U, y)]
    if not binary: cons += [y <= 1]
    p = cp.Problem(cp.Minimize(K @ y + cp.sum(cp.multiply(C, x))), cons)
    p.solve(solver=cp.HIGHS)
    return p.value, y.value, x.value

vM, yM, xM = solve(True);  vL, yL, _ = solve(False)
print(f"MILP cost {vM:.1f}  y={np.round(yM,3)}"); print(np.round(xM,3))
print(f"LP bound  {vL:.1f}  y={np.round(yL,4)}   gap = {(vM-vL)/vM*100:.1f}%")
```
**MILP:** cost **850**, opening sites **2 and 3** ($y = (0,1,1)$), with shipments $x_{22}=15$, $x_{23}=5$, $x_{31}=20$, $x_{33}=20$, $x_{34}=10$ — matching the hand evaluation of 13.4.2 exactly, so that plan *is* optimal.
**LP relaxation:** bound **665**, with $y \approx (0.333,\ 0.333,\ 0.700)$ — it builds a third of two warehouses and seven-tenths of another, paying fractional fixed costs. Integrality gap $= (850-665)/850 = \mathbf{21.8\%}$, from a model whose big-Ms are already as tight as physics allows. Fractional facilities are the normal face of an LP relaxation; closing this gap is Chapter 14's job.

**13.4.4** *"The model declines to open site 1 even though it ships most cheaply to customer 1 (4 versus 6 from site 3), because the shipping saving is 2/unit on 20 units — \$40 — while site 1's fixed cost is \$350. Opening it could at best save \$40 of shipping and would have to displace the \$250 or \$300 of fixed cost of a site that is already needed for capacity, and 60 units of capacity cannot be spared: total demand is 70, so no single site suffices."*
The general form of the sentence to write after any facility-location solve: **[the rejected option]'s variable-cost advantage is X; its fixed cost is Y; since X < Y it stays closed.** That one comparison is the whole discrete trade-off, and stating it is how you convince a reviewer the answer is not a solver artifact.

## Solutions — 14.1 Worked Example 9 — a complete tree

**14.1.1** Root LP: $x = (1.6,\ 1.8)$, $z = 11.8$. **No integer solution can exceed 11.8** — and since the objective coefficients are integers, no integer solution can exceed $\lfloor 11.8 \rfloor = 11$.
Branch on the first fractional variable, $x_1 = 1.6$: children $x_1 \le 1$ and $x_1 \ge 2$.

| Node | Added constraints | LP solution | bound $z$ | Action |
|---|---|---|---|---|
| Root | — | $(1.6,\ 1.8)$ | 11.80 | fractional → branch on $x_1$ |
| **N1** | $x_1 \le 1$ | $(1,\ 2.25)$ | 10.75 | fractional → branch on $x_2$ |
| **N1a** | $x_1\le1,\ x_2\le2$ | $(1,\ 2)$ | 10.00 | **integer** → incumbent 10 |
| **N1b** | $x_1\le1,\ x_2\ge3$ | $(0,\ 3)$ | 9.00 | integer, $9 < 10$ → discard |
| **N2** | $x_1 \ge 2$ | $(2,\ 1)$ | 11.00 | **integer** → new incumbent **11** |

(Node N1's LP: with $x_1 = 1$ pushed to its ceiling, $4x_2 \le 9$ gives $x_2 \le 2.25$. Node N2's LP: $4x_1+2x_2\le10$ with $x_1\ge2$ forces $x_2 \le 1$, and $x_1 = 2$ is optimal.)
No open nodes remain, so $x^\star = (2,1)$, $z^\star = \mathbf{11}$, **proved optimal**. Note that if N2 had been explored *first* (as a LIFO stack would), its incumbent of 11 would have pruned the whole N1 subtree at once on the bound $10.75 < 11$ — three LP solves instead of five.

**14.1.2**
```python
import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds
c, A, b = [-4, -3], [[3, 4], [4, 2]], [12, 10]
def node(name, eA=(), eb=()):
    r = linprog(c, A_ub=A + [list(v) for v in eA], b_ub=b + list(eb),
                bounds=[(0, None)]*2, method="highs")
    print(f"{name:22s} x=({r.x[0]:.4f},{r.x[1]:.4f})  z={-r.fun:.4f}")
node("ROOT")
node("x1<=1", [[1,0]], [1]);            node("x1>=2", [[-1,0]], [-2])
node("x1<=1,x2<=2", [[1,0],[0,1]], [1,2]); node("x1<=1,x2>=3", [[1,0],[0,-1]], [1,-3])
r = milp(c=c, constraints=[LinearConstraint(A, ub=b)], integrality=[1,1],
         bounds=Bounds([0,0],[np.inf]*2))
print("milp:", np.round(r.x).astype(int), -r.fun)
```
Reproduces 11.8000, 10.7500, 11.0000, 10.0000, 9.0000 and `milp: [2 1] 11.0` — every hand number confirmed.

**14.1.3** Rounding $(1.6,\ 1.8)$:

| rounded point | feasible? | $z$ |
|---|---|---|
| $(1,1)$ (both down) | yes | 7 |
| $(2,2)$ (both up) | **no** — $3(2)+4(2) = 14 > 12$ | — |
| $(2,1)$ ($x_1$ up, $x_2$ down) | yes | 11 |
| $(1,2)$ ($x_1$ down, $x_2$ up) | yes | 10 |

Here one of the four roundings happens to hit the true optimum $(2,1)$ — but notice you had to try **all four** and check feasibility of each, i.e. enumerate $2^n$ candidates, and one of the four was infeasible. In the text's Example 9, *no* rounding of the LP optimum reaches the true optimum $(4,0)$ at all. In higher dimensions both problems compound: $2^n$ candidates, and each rounded coordinate can violate a different constraint, so typically *none* of the roundings is feasible. Rounding also provides **no bound and no certificate** — even when it lands on the optimum, you cannot know that it did. It is a heuristic for getting an early incumbent (which is genuinely useful, §14.4), not a method.

**14.1.4** What is proved: the incumbent's value is optimal over the *whole* feasible set. The argument is that the child nodes at every branch **partition** the integer points of their parent (no integer point satisfies $1 < x_1 < 2$), so the union of all leaves — explored and pruned — covers every feasible integer point. A pruned node carries a *certificate*: its LP relaxation bound is an optimistic estimate of everything in its subtree, and that bound was no better than the incumbent, so nothing in the subtree can beat the incumbent. No examination is needed because the bound already settled the question for all points at once.
This is the same argument as **§9.5 / §5.2**: a relaxation bounds the optimum from one side, a feasible point from the other, and optimality is proved when they meet. Branch and bound simply applies it recursively to pieces of the feasible set — which is why §14.3 can read the search's progress as a gap between two bounds.

## Solutions — 14.2 Branch and bound in forty lines

**14.2.1** **Ingredients:** (1) *Branching* — split a node's feasible set into subproblems whose union preserves every integer point ($x_j \le \lfloor v\rfloor$ vs $x_j \ge \lceil v\rceil$); (2) *Bounding* — solve each subproblem's LP relaxation for an optimistic estimate; (3) *Pruning* — discard nodes that cannot contain anything better.
**Three pruning circumstances:**
- **Infeasible relaxation** → the subtree is empty. Cost: nothing extra; the LP solve already told you (`status != 0`).
- **Bound no better than the incumbent** → nothing in the subtree can beat what you have. Cost: one comparison, plus the LP solve. This is the rule that makes the method tractable.
- **Relaxation is integral** → you have found the best point in this subtree; record it and stop descending. Cost: a fractionality check on the LP solution, $O(n)$.

**14.2.2**
```python
x, z = branch_and_bound([4, 3], [[3, 4], [4, 2]], [12, 10])
```
With the LIFO stack, the $x_1 \ge 2$ child is pushed last and therefore explored **first**; its relaxation $(2,1)$ is integral, so it becomes the incumbent 11 immediately. The $x_1 \le 1$ node then has bound 10.75, which is $\le 11$, so it is **pruned by bound** — and its two children ($(1,2)$ with $z=10$ and $(0,3)$ with $z=9$) are never generated at all.
So the machine's tree has **3 nodes** where the hand tree of 14.1.1 had 5: the differences are (i) node N2 is *recorded as an integral relaxation* rather than reached last, and (ii) the entire N1 subtree is pruned by bound instead of explored. Same answer, same certificate, fewer LP solves — exploration order changes which rule fires where, not the result.

**14.2.3**
```python
import heapq, numpy as np
from scipy.optimize import linprog

def bb_best_bound(c, A, b, tol=1e-6):
    incumbent, z_inc, nodes = None, -np.inf, 0
    def relax(eA, eb):
        return linprog([-ci for ci in c], A_ub=A+eA, b_ub=b+eb,
                       bounds=[(0, None)]*len(c), method="highs")
    r0 = relax([], []); heap = [(-(-r0.fun), 0, [], [])]; counter = 1
    while heap:
        negz, _, eA, eb = heapq.heappop(heap); z = -negz
        nodes += 1
        if z <= z_inc + tol: continue                  # bound prune
        r = relax(eA, eb)
        if r.status != 0: continue
        z = -r.fun
        if z <= z_inc + tol: continue
        frac = [j for j, v in enumerate(r.x) if abs(v - round(v)) > tol]
        if not frac:
            incumbent, z_inc = np.round(r.x), z; continue
        j, v = frac[0], r.x[frac[0]]
        row = [1.0 if k == j else 0.0 for k in range(len(c))]
        for extra_row, extra_b in [(row, np.floor(v)), ([-t for t in row], -np.ceil(v))]:
            heapq.heappush(heap, (-z, counter, eA+[extra_row], eb+[extra_b])); counter += 1
    return incumbent, z_inc, nodes

print(bb_best_bound([4, 3], [[3, 4], [4, 2]], [12, 10]))
print(bb_best_bound([5, 4], [[6, 4], [1, 2]], [24, 6]))
```
On these small problems both orders take a handful of nodes (3–5); the ordering effect is real but only visible at scale.
**Trade-off:** *Best-bound-first* minimizes the number of nodes needed to *prove* optimality — it always works on the most promising open node, so the global bound (and hence the MIP gap) shrinks fastest. Its costs are memory (the open-node list can grow enormously) and the fact that it may go a long time without finding *any* integer solution, so there is no incumbent and no good answer if you run out of time. *Depth-first* finds integer solutions early (it dives straight to leaves), keeps memory tiny, and warm-starts beautifully because each child differs from its parent by one bound — but it can waste effort in hopeless subtrees. Real solvers therefore **hybridize**: dive depth-first to get an incumbent, then switch to best-bound to close the gap, with periodic restarts and heuristics.

**14.2.4** If a node's LP relaxation returns an *integral* point, that point is feasible for the integer problem and achieves the node's own relaxation bound. Since the relaxation bound is an upper limit (for maximization) on everything in that subtree, and this feasible point attains it, **nothing in the subtree can be better** — the subtree is fully settled, so you record the point and stop descending. No branching is needed or useful.
This is *not* the same as global optimality: the bound that was attained is the *node's* bound, valid only for the node's restricted feasible set (the parent's set intersected with the branching constraints). Other parts of the tree may contain better points — in the text's run, the integral node giving 18 is later superseded by the incumbent 20 from a different branch. Local certificate, local scope; the global certificate arrives only when no open nodes remain.

## Solutions — 14.3 The MIP gap: a certificate you can stop on

**14.3.1** **Incumbent:** the best integer-feasible value found so far (an achieved value — a bound from the attainable side). **Best bound:** the best relaxation value among still-open nodes (a limit on what could still be found). **MIP gap:** their difference, which bounds everything further search could gain.
For the tree of 14.1.1 (maximization):
- *After the root:* no incumbent yet, best bound 11.8 → gap undefined (or $\infty$); all that is known is $z^\star \le 11.8$.
- *After N1a:* incumbent 10; open nodes are N1b and N2, whose bounds are inherited from N1 (10.75) and the root (11.8), so best bound $= 11.8$. Relative gap $= (11.8-10)/10 = \mathbf{18.0\%}$.
- *After N2:* incumbent 11; remaining open node N1b has bound $\le 10.75 < 11$, so it is pruned and no open nodes remain → best bound $= 11$, gap $= \mathbf{0}$ — optimality proved.

**14.3.2** **False**, and the error is important: it inverts the logic. The gap *is* the proof. The solver holds a feasible solution of value $z_{\text{inc}}$ **and** a rigorous bound $z_{\text{bound}}$ on the best possible value, derived from the relaxations of all open nodes; the 1 % is the certified distance between them. So the correct statement is: *the solver has found a solution and can prove it is within 1 % of optimal.* What it has **not** proved is that the incumbent is *exactly* optimal — the true optimum lies somewhere in that 1 % window, possibly at the incumbent itself (often it is, and the remaining work is spent proving it). This is §9.5's two-bounds certificate, tracked in real time.

**14.3.3**
```python
import numpy as np, time
from scipy.optimize import milp, LinearConstraint, Bounds
rng = np.random.default_rng(2)
n, m = 25, 12
c = -rng.integers(5, 40, n).astype(float)          # maximize value
A = rng.integers(1, 20, (m, n)).astype(float)
b = A.sum(axis=1) * 0.35
for gap in (1e-4, 0.02):
    t0 = time.perf_counter()
    r = milp(c=c, constraints=[LinearConstraint(A, ub=b)], integrality=[1]*n,
             bounds=Bounds([0]*n, [1]*n), options={"mip_rel_gap": gap, "time_limit": 60})
    print(f"gap tol {gap:<7}: value = {-r.fun:8.2f}   time = {time.perf_counter()-t0:.3f} s"
          f"   status = {r.status}")
```
Typical outcome: the tight tolerance returns the proven optimum after noticeably more work, while the 2 % tolerance returns an equal or nearly equal objective in a fraction of the time. (On instances this small both are fast; the pattern becomes dramatic at industrial scale, where the last fraction of a percent routinely costs more compute than everything before it.)
Honest reporting form: **"Total value 1 042, proved within 2 % of optimal, in 0.4 s."** Both the number and its certified quality, never one without the other.

**14.3.4** With inputs known to $\pm5\%$, the *model's* answer carries at least that much uncertainty, so proving optimality to $10^{-6}$ of a model whose data is $\pm5\%$ is spending compute to refine a number that is already dominated by input error. A gap tolerance of **0.5–1 %** is defensible: comfortably inside the data uncertainty, while still guaranteeing you have not left a materially better plan on the table. (Do not set it *at* 5 %: the gap and the data error compound, and a 5 % gap admits plans that are genuinely, structurally different — different sites opened, different units committed — not just slightly costlier.) Also set a time limit, and report if it binds.
Report sentence: **"Recommended plan: total annual cost \$4.28 M, proved within 0.5 % of the optimum for this model; note that demand and cost inputs carry roughly ±5 % uncertainty, which dominates the remaining optimality gap."**

## Solutions — 14.4 Practical checklist for integer models

**14.4.1**
1. **Tighten every big-M to a physical value** → *bound tightness* (§13.3): the relaxation stops paying fractional fixed costs.
2. **Break symmetry when units are interchangeable** → *search-space size*: prevents re-exploring permutations of the same solution.
3. **Supply a starting solution (warm start)** → *early pruning*: an incumbent from node 1 makes the bound rule effective immediately.
4. **Always set a gap tolerance and a time limit** → *method choice / operational control*: converts a possible hang into a reported, usable outcome.
5. **Bound every variable, even generously** → *bound tightness* (and *numerical stability*): unbounded variables weaken relaxations and can make node LPs unbounded or ill-conditioned.
6. **Relax integrality where fractional answers are physically tolerable** → *search-space size*: fewer integer variables is a superlinear speedup.
7. **Check whether the model is secretly a network (§6)** → *method choice*: if TU holds, none of this chapter is needed — the LP already returns integers.

**14.4.2** Total size $= 6+5+4+3+2 = 20$, and each machine holds 10, so **at least 2 machines** are needed and 2 suffice exactly if the jobs split into two groups of load 10 each. The only such split is $\{6,4\}$ and $\{5,3,2\}$ (checking: $6+4 = 10$ ✓, $5+3+2 = 10$ ✓; no other subset sums to 10 — $6+3+2 = 11$, $5+4 = 9$, $6+2=8$, $5+4+2=11$…). So there is exactly **one genuine partition**.
Counting **labelled assignments**: choose which two of the three machines are used and which group goes to which — $3 \times 2 = 6$ ordered choices. So **6 assignments represent 1 partition**: a symmetry factor of 6, and a solver without symmetry breaking may explore all six as if they were different solutions (and, worse, explore six copies of every *suboptimal* configuration too).
Symmetry-breaking constraints: force the machines into a canonical order, e.g. $y_1 \ge y_2 \ge y_3$ (used machines are the lowest-indexed), optionally strengthened by ordering loads, $\sum_j s_jx_{1j} \ge \sum_j s_jx_{2j} \ge \sum_j s_jx_{3j}$, or by fixing the largest job to machine 1.

**14.4.3**
```python
import itertools, numpy as np, cvxpy as cp
sizes, cap, m = [6,5,4,3,2], 10, 3
best = None; count = 0
for a in itertools.product(range(m), repeat=len(sizes)):
    loads = [sum(sizes[j] for j in range(len(sizes)) if a[j]==i) for i in range(m)]
    if all(l <= cap for l in loads):
        used = sum(1 for l in loads if l > 0)
        if best is None or used < best: best, count = used, 1
        elif used == best: count += 1
print("min machines:", best, " labelled assignments achieving it:", count)

def solve(symmetry):
    y = cp.Variable(m, boolean=True); x = cp.Variable((m, len(sizes)), boolean=True)
    cons = [cp.sum(x, axis=0) == 1, np.array(sizes) @ x.T <= cap*y]
    if symmetry: cons += [y[i] >= y[i+1] for i in range(m-1)]
    p = cp.Problem(cp.Minimize(cp.sum(y)), cons); p.solve(solver=cp.HIGHS)
    return p.value
print("without symmetry breaking:", solve(False), " with:", solve(True))
```
Enumeration confirms **min = 2 machines with 6 labelled assignments**, i.e. 6 = 3×2 relabellings of the single partition $\{6,4\},\{5,3,2\}$. Both MILP formulations return objective 2.
**Honest comment:** at this size the node count does *not* change — HiGHS's presolve and heuristics settle the problem at the root, so there is nothing to save. Symmetry breaking pays when the symmetric group is large enough that the solver must actually branch through equivalent solutions: with $K$ interchangeable units the factor is up to $K!$, so 3 machines ($3! = 6$) is negligible while 12 identical generators ($12! \approx 4.8\times10^8$) is decisive — and it matters most for *proving* optimality, since every symmetric copy of a suboptimal configuration must otherwise be bounded away separately.

**14.4.4** **First: the bound.** A 40 % gap after a timeout is a statement about *bound quality*, so inspect the root relaxation value against the incumbent, then audit every big-M for a physical justification (§13.3) and confirm every variable has a finite bound. This is the highest-leverage change and usually costs one line per constraint; a tightened formulation can move the root bound by tens of percent.
**Second: the structure of the search space.** Look for interchangeable units and add symmetry-breaking constraints; count the integer variables and ask which of them could be relaxed to continuous without physical nonsense (a flow, a fraction, an inventory level) — reducing integer count is a superlinear win. Also check whether some substructure is a network (§6), which would let you drop integrality wholesale.
**Third: the search's starting conditions and stopping rule.** Supply a warm start from a heuristic or from last month's plan so pruning begins at node 1; set an explicit gap tolerance appropriate to the data uncertainty (§14.3.4) rather than demanding a proven optimum; and if the model must be solved repeatedly, consider decomposing it. Expect: item one to shrink the gap, item two to shrink the tree, item three to make whatever remains *usable* — a certified 2 % answer instead of an uncertified 40 % one.

## Solutions — 15.1 Worked Example 10 — one cut solves the entire problem

**15.1.1** A cutting plane must be (a) **violated by fractional points of the current relaxation** — otherwise it changes nothing — and (b) **satisfied by every integer-feasible point** — otherwise it would cut off the true optimum and make the problem wrong.
Integrality enters through **(b)**, and specifically through the *rounding step*: an inequality valid for the continuous relaxation can have its right-hand side rounded down whenever the left-hand side is guaranteed to be a whole number. That rounding is information the LP cannot see, which is exactly why the cut can tighten the relaxation without touching the integer problem.

**15.1.2** Constraints: $3x_1+4x_2\le12$ and $4x_1+2x_2\le10$. With $u = (0.2,\ 0.1)$:
$$0.2(3x_1+4x_2) + 0.1(4x_1+2x_2) \;\le\; 0.2(12) + 0.1(10),$$
$$(0.6+0.4)x_1 + (0.8+0.2)x_2 \le 2.4 + 1.0 \quad\Longrightarrow\quad 1.0\,x_1 + 1.0\,x_2 \le 3.4.$$
The coefficients are already integers ($\lfloor1\rfloor = 1$), and since $x_1,x_2$ are integers the left side is a whole number; a whole number $\le 3.4$ is a whole number $\le 3$:
$$\boxed{x_1 + x_2 \le 3.}$$

**15.1.3** The nine feasible integer points and their coordinate sums:
$(0,0)\!:\!0$, $(0,1)\!:\!1$, $(0,2)\!:\!2$, $(0,3)\!:\!3$, $(1,0)\!:\!1$, $(1,1)\!:\!2$, $(1,2)\!:\!3$, $(2,0)\!:\!2$, $(2,1)\!:\!3$.
The maximum sum is **3**, attained at $(0,3)$, $(1,2)$ and $(2,1)$ — so **no integer point is removed** ✓. The LP optimum has sum $1.6+1.8 = 3.4 > 3$, so it is **cut off** ✓. Both required properties hold.

**15.1.4**
```python
from scipy.optimize import linprog
r = linprog([-4,-3], A_ub=[[3,4],[4,2],[1,1]], b_ub=[12,10,3],
            bounds=[(0,None)]*2, method="highs")
print(f"LP with cut: x = ({r.x[0]:.1f}, {r.x[1]:.1f}), z = {-r.fun:.1f}")
```
Result: $x = (2,\ 1)$, $z = 11.0$ — **the exact integer optimum, from a pure LP with no integrality declared anywhere**. Compare 14.1.1, which needed three to five LP solves plus branching bookkeeping and an incumbent to reach the same answer with the same certificate. One inequality, derived in two lines, replaced the whole tree.
Geometrically the cut slices off the fractional corner: the vertex $(2,1)$ is the intersection of $4x_1+2x_2 = 10$ with $x_1+x_2 = 3$, and it is an integer point, so the LP's fundamental theorem (§4.1) now delivers an integer answer automatically.

**15.1.5** For weights $u \ge 0$ applied to $Ax \le b$, $x \ge 0$ integer, the **Chvátal–Gomory cut** is
$$\sum_j \big\lfloor u^\top A_j \big\rfloor\, x_j \;\le\; \big\lfloor u^\top b \big\rfloor,$$
where $A_j$ is column $j$.
*Why the coefficient floors are valid:* the exact combination gives $\sum_j (u^\top A_j)x_j \le u^\top b$. Since $x_j \ge 0$, replacing each coefficient by something no larger can only decrease the left-hand side, so $\sum_j\lfloor u^\top A_j\rfloor x_j \le \sum_j (u^\top A_j)x_j \le u^\top b$ — the inequality survives. (This step needs $x \ge 0$; with free variables it fails.)
*Why the right-hand-side floor is valid:* now every coefficient is an integer and every $x_j$ is an integer, so the left-hand side is an integer; an integer that is $\le u^\top b$ is $\le \lfloor u^\top b\rfloor$.
The two floors do different jobs — the first uses nonnegativity, the second uses integrality — and applying the recipe repeatedly to the tightened system generates the *Chvátal closure*, which eventually reaches the integer hull (in general after exponentially many rounds).

## Solutions — 15.2 Formulation strength: the practical moral

**15.2.1** An **ideal formulation** is one whose LP relaxation is exactly the convex hull of the feasible integer points (the *integer hull*). For it, every vertex of the relaxation is an integer point, so by the fundamental theorem of LP (§4.1) a plain LP solve returns the integer optimum — exactly what happened in §15.1.4.
It does not make IP easy because finding the ideal formulation is generally intractable: the hull can require exponentially many inequalities, and being able to produce it cheaply for arbitrary problems would collapse NP-hardness. (Separating over the hull is as hard as optimizing over it.)
What it tells everyday practice: **there is a continuum of formulations between yours and the ideal one, and moving along it is pure profit.** Every tightening — a physical big-M, a valid bound, a symmetry-breaking constraint, a stronger disaggregated linking constraint — moves the relaxation closer to the hull, which improves the bound at *every* node of the tree simultaneously.

**15.2.2** The cut $x_1+x_2\le3$ together with $x_1 \ge 0$ already gives $x_2 \le 3$. So
$$3x_1 + 4x_2 = 3(x_1 + x_2) + x_2 \;\le\; 3(3) + 3 = 12,$$
using the cut twice and nonnegativity — no use of the constraint being proved, so the argument is not circular. Hence $3x_1+4x_2 \le 12$ is implied and can be dropped without changing the feasible set: it is **redundant**. (Verify computationally: maximizing $3x_1+4x_2$ subject only to the cut and $4x_1+2x_2\le10$ gives exactly $12$, at $(0,3)$ — the constraint is tight but never violated.) The lesson mirrors the text's: a good cut does not merely add information, it can *supersede* an original constraint, and presolvers exploit exactly this to shrink models.

**15.2.3** (1) **"My big-Ms are not physically justified, so my root bound is far from the truth."** Check every $M$ against a rating, horizon or contract limit, and compare the root relaxation with the incumbent to quantify the damage (§13.3).
(2) **"My model contains interchangeable units and unbounded variables, so the tree is exploring redundant and unbounded regions."** Add symmetry-breaking constraints and finite bounds on every variable (§14.4).
(3) **"I have declared more integer variables than the physics requires, and I have not given the solver a starting incumbent or a stopping rule."** Relax integrality where fractional values are physically tolerable, warm-start from a heuristic or a historical plan, and set a gap tolerance matched to data uncertainty (§14.3.4).
Each is checkable in minutes and each is a statement about the model, which is where the leverage is — the "orders of magnitude" difference between two algebraically equivalent formulations is not something a faster computer fixes.

**15.2.4** **You supply:** physically justified big-Ms; finite, tight bounds on every variable; symmetry-breaking constraints; the choice of which variables genuinely need integrality; the tighter of two equivalent formulations (e.g. disaggregated rather than aggregated linking constraints); a warm start; and a gap tolerance and time limit. **The solver supplies:** presolve and reductions, automatic cut families (Gomory, cover, clique, flow-cover, mixed-integer rounding), branching-variable selection, node selection, primal heuristics for early incumbents, and parallelism.
The division makes sense because the two kinds of knowledge are different in kind. Cut generation and branching are *polyhedral combinatorics* — general-purpose, heavily engineered, and responsible for much of MILP solvers' multiple-orders-of-magnitude improvement over recent decades; no user can out-implement them. But the solver cannot know that a pump is rated at 120 m³/h, that three machines are identical, or that a flow may be fractional while a build decision may not. That information exists only in your head, it cannot be inferred from the algebra, and supplying it is what gives the solver's machinery something to work with.

## Solutions — 16.1 The principle of optimality

**16.1.1** **Bellman's principle:** any tail of an optimal path is itself optimal for the subproblem it starts from.
*Argument:* suppose the cheapest route from A to Z passes through M, but its portion from M to Z is not the cheapest M-to-Z route. Then splice the cheaper M-to-Z route onto the A-to-M portion. The result is still a valid A-to-Z route (the pieces join at M) and it is strictly cheaper — contradicting the optimality of the original. Hence the tail must have been optimal.
**What it licenses:** computing the optimal tail from each state *once*, and reusing it for every path that passes through that state. Since exponentially many paths share the same tail from a given state, this replaces enumeration of paths with a computation indexed by states.

**16.1.2** Let $V(n)$ = the minimum cost to travel from node $n$ to the terminal node. Then
$$V(\text{terminal}) = 0, \qquad V(n) = \min_{m \in \text{successors}(n)}\big[c(n,m) + V(m)\big],$$
and the optimal decision at $n$ is the minimizing $m$ (stored as a policy). The total optimum is $V(\text{start})$, and the optimal path is recovered by following the stored decisions *forwards*.
It is solved backwards because the right-hand side needs $V(m)$ for successors $m$ — i.e. each state's value depends on states *later* in the sequence. Starting from the terminal condition and working back guarantees every value needed is already known when it is required. (Forward recursions exist too, on cost-so-far rather than cost-to-go; the point is that one direction must be the one where dependencies are already resolved.)

**16.1.3** With $k$ stages of width $w$: the number of complete paths is $w^k$; the number of states is $k\cdot w$; and the work is one arc evaluation per (state, successor) pair, about $k\cdot w^2$ additions and comparisons.
At $k = 20$, $w = 10$: paths $= 10^{20}$ (utterly infeasible to enumerate); states $= 200$; arc evaluations $\approx 20 \times 100 = 2\,000$ — instant. That contrast is the entire economic case for DP, and the fine print is §16.3: the *state count itself* can explode if the state is a vector.

**16.1.4** Example: **maximizing the minimum-cost path's reliability with a variance penalty** — e.g. choose a route minimizing $\mathbb{E}[\text{time}] + \gamma\,\text{sd}(\text{time})$. The standard deviation of a sum is not the sum of standard deviations, so "cost so far + cost to go" is not meaningful and the tail of an optimal route need not be an optimal tail. Other examples: an objective involving a *ratio* over the whole horizon (average cost per unit produced, where the denominator also accumulates), a constraint on the *variance* of a portfolio over time, or a penalty depending on the number of distinct suppliers used across all periods.
What to do: (i) **augment the state** so the recursion becomes valid — carry the accumulated sum *and* sum of squares (for variance), or the set of suppliers used (which may explode the state, paying the curse of §16.3); (ii) **reformulate** — optimize a linear scalarization or use the $\varepsilon$-constraint form (§19.2) so the objective becomes separable, then sweep; (iii) if neither works, abandon DP and use branch and bound or a heuristic, which do not require separability. Recognizing the failure *before* coding is the point: the three conditions of §16.3 are a checklist, not a formality.

## Solutions — 16.2 Worked Example 11 — shortest path

**16.2.1** Work backwards from $V(T) = 0$:

| Stage | State | Bellman computation | $V$ | Best move |
|---|---|---|---|---|
| 4 | $T$ | terminal | **0** | — |
| 3 | $E$ | $1 + V(T) = 1$ | **1** | $E\to T$ |
| 3 | $F$ | $3 + V(T) = 3$ | **3** | $F\to T$ |
| 2 | $C$ | $\min\{1+1,\ 4+3\} = \min\{2, 7\}$ | **2** | $C\to E$ |
| 2 | $D$ | $\min\{5+1,\ 2+3\} = \min\{6, 5\}$ | **5** | $D\to F$ |
| 1 | $A$ | $\min\{1+2,\ 5+5\} = \min\{3, 10\}$ | **3** | $A\to C$ |
| 1 | $B$ | $\min\{6+2,\ 2+5\} = \min\{8, 7\}$ | **7** | $B\to D$ |
| 0 | $S$ | $\min\{4+3,\ 2+7\} = \min\{7, 9\}$ | **7** | $S\to A$ |

Following the best-move column forward: $S \to A \to C \to E \to T$, total cost **7**.

**16.2.2** Greedy forward: from $S$, the cheaper arc is $S\to B$ (2 vs 4). From $B$, cheaper is $B\to D$ (2 vs 6). From $D$, cheaper is $D\to F$ (2 vs 5). From $F$, forced to $T$ (3). Path $S\to B\to D\to F\to T$, cost $2+2+2+3 = \mathbf{9}$ — it loses **2** (29 % above the optimum of 7).
Greedy goes wrong at its **very first decision**. It compares the *arcs* ($4$ vs $2$) when the relevant comparison is arc plus everything after: $4 + V(A) = 7$ against $2 + V(B) = 9$. What greedy lacked is precisely the value function — the true price of the remainder of the journey. Note the value function makes the comparison *fair*: $B$'s cheap entry arc leads into an expensive continuation ($V(B) = 7$ vs $V(A) = 3$). This is the same disease as the greedy assignment trap of §6.2, and DP is one cure.

**16.2.3**
```python
succ = {"S": [("A",4), ("B",2)], "A": [("C",1), ("D",5)], "B": [("C",6), ("D",2)],
        "C": [("E",1), ("F",4)], "D": [("E",5), ("F",2)],
        "E": [("T",1)], "F": [("T",3)], "T": []}
V, best = {"T": 0}, {}
for n in ["E", "F", "C", "D", "A", "B", "S"]:            # backward order
    V[n], best[n] = min((c + V[m], m) for m, c in succ[n])
print("V =", V)
path, n = ["S"], "S"
while n != "T": n = best[n]; path.append(n)
print("optimal:", " -> ".join(path), " cost", V["S"])

def all_paths(n):
    if n == "T": return [(["T"], 0)]
    return [([n]+p, c+c2) for m, c in succ[n] for p, c2 in all_paths(m)]
for p, c in sorted(all_paths("S"), key=lambda t: t[1]): print("  ", " -> ".join(p), c)
```
Output: $V = \{T\!:\!0,\ E\!:\!1,\ F\!:\!3,\ C\!:\!2,\ D\!:\!5,\ A\!:\!3,\ B\!:\!7,\ S\!:\!7\}$; optimal $S\to A\to C\to E\to T$ at cost 7. Enumeration of all eight paths gives $7, 9, 10, 10, 12, 14, 15, 15$ — minimum **7** ✓, matching the DP, with greedy's path $S\to B\to D\to F\to T$ sitting second at 9.

**16.2.4** Both are true because they answer different questions. "$A$'s best move is to $C$" is a statement about the subproblem *starting at $A$* — given that you are at $A$, the cheapest continuation goes via $C$. "The optimum passes through $D$" (in the text's network) is a statement about the *whole* path, which may never visit $A$ at all: the optimal route reaches $D$ from $B$, not from $A$. The two claims concern different states, so there is no conflict.
What it says about local choices: **optimal solutions cannot be assembled greedily from the front**, because a front-end decision must be priced against the true cost of everything downstream, which is not visible locally. But they *can* be assembled from the back, because the value function prices the remainder exactly — that is the whole design of DP. Optimal *tails* compose; optimal *heads* do not.

## Solutions — 16.3 When DP applies — and when it fails

**16.3.1** (1) **Stages** — the decision decomposes into a sequence of steps. (2) **State** — a summary of the past that captures everything the future needs to know. (3) **Additive separability** — the objective accumulates over stages so that "cost so far + cost to go" is meaningful.
The state is the art because it must be simultaneously *sufficient* (the recursion is only valid if the future depends on the past **only** through the state) and *small* (cost is proportional to the number of states).
*Too small:* in a lot-sizing problem, using only "current period" as the state, ignoring inventory on hand — the future cost genuinely depends on stock, so the recursion computes the wrong values. *Too large:* using "the entire production history" as the state — sufficient but with exponentially many values, so the table cannot be built. The craft is finding the minimal sufficient summary: for shortest path, the current node; for inventory, the stock level; for the knapsack, remaining capacity.

**16.3.2** Let $dp[c]$ = best value achievable with capacity $c$, processing items one at a time (backward inner loop so each item is used at most once).
Start $dp = [0]\times 11$.
- Item 1 ($v=7,w=3$): $dp[c] = 7$ for $c \ge 3$.
- Item 2 ($v=8,w=4$): $dp[7..10] = 15$ (both items, weight 7); $dp[4..6] = 8$.
- Item 3 ($v=9,w=5$): $dp[9,10] = \max(15,\ dp[c-5]+9)$; $dp[9] = \max(15, dp[4]+9 = 17) = 17$; $dp[10] = \max(15, dp[5]+9 = 17) = 17$; $dp[8] = \max(15, dp[3]+9 = 16) = 16$; $dp[5..7] = 9$ or previous, giving $dp[5]=9,\ dp[6]=9,\ dp[7]=15$.
- Item 4 ($v=10,w=6$): $dp[10] = \max(17,\ dp[4] + 10 = 18) = \mathbf{18}$.
Optimal value **18**, achieved by items **2 and 4** (weights $4+6 = 10$, values $8+10 = 18$).
Enumeration check: the best feasible subsets are $\{2,4\}$ = 18, $\{1,4\}$ = 17 (weight 9), $\{3,4\}$ infeasible (weight 11), $\{1,2,3\}$ infeasible (weight 12), $\{1,3\}$ = 16 (weight 8). Maximum **18** ✓.

**16.3.3**
```python
def knap(values, weights, W):
    dp = [0]*(W+1)
    for v, w in zip(values, weights):
        for c in range(W, w-1, -1):
            dp[c] = max(dp[c], dp[c-w] + v)
    return dp[W], W+1

values, weights, W = [7, 8, 9, 10], [3, 4, 5, 6], 10
for s in (1, 10, 100):
    best, size = knap(values, [w*s for w in weights], W*s)
    print(f"scale={s:4d}  table size={size:6d}  best value={best}")
```
Output: table sizes **11, 101, 1001** with the same optimal value 18 each time. The *answer* is unchanged — it is the same problem in different units — but the **work grows in proportion to the numeric value of $W$**.
This does not contradict NP-hardness because $O(nW)$ is **pseudo-polynomial**: polynomial in the numeric value of $W$, but *exponential in the number of bits* needed to write $W$ down (a $W$ with 60 binary digits gives a table of $10^{18}$ entries). Complexity is measured in input length, not input magnitude. The refinement is genuinely useful: knapsack is easy when the numbers are small (grams, not micrograms) and hard when they are large — so before reaching for branch and bound, check the magnitude of your capacities, and consider rounding weights to a coarser unit (which is exactly how knapsack approximation schemes work).

**16.3.4** **Enumeration:** $3^{24} \approx 2.8\times10^{11}$ action sequences — infeasible. **DP:** states $= 24 \times 200 = 4\,800$ (stage, level) pairs, work $\approx$ states × actions $= 14\,400$ evaluations — instant. A factor of $10^7$.
**Validity condition:** the **state property** — the energy level must summarize everything the future needs. That holds if prices and demands are known per period and if efficiency/losses depend only on the current level and the chosen action. (Additive separability also holds: total cost is a sum of hourly costs.)
**If a warranty rule depends on cumulative cycling**, the level alone is no longer sufficient — future feasibility depends on how much throughput has already been used — so the state must be **augmented** to (level, cumulative cycles). Discretizing cumulative cycles into, say, 100 buckets multiplies the state count by 100 (to 480 000, still fine here); but each additional such quantity multiplies again, and a five-dimensional state at 100 levels per dimension gives $10^{10}$ states. That is the **curse of dimensionality**: DP's cost is linear in the number of states and the number of states is exponential in the state's dimension. (Approximating $V$ instead of tabulating it is precisely the project of reinforcement learning.)

## Solutions — 16.4 Where you will meet DP

**16.4.1**
| Setting | Stage | State |
|---|---|---|
| Shortest path (Dijkstra, Bellman–Ford) | position in the graph / iteration | current node |
| Inventory & lot-sizing | planning period | stock on hand |
| Equipment replacement | year | age (and condition) of the machine |
| Reservoir / battery scheduling | time period | stored energy or water volume |
| Discrete-time optimal control (→ HJB in the limit) | time step | the plant's state vector |
| Viterbi decoding / sequence alignment | symbol position | hidden state / pair of prefix indices |
(Also: reinforcement learning, where $V$ is the cost-to-go being approximated rather than tabulated.)

**16.4.2** Let $F(t)$ = minimum cost to cover periods $t..4$, with $F(5) = 0$. Producing in period $t$ to cover through period $j$ costs $K = 5$, plus \$2 per unit for $\sum_{k=t}^{j}d_k$ units, plus holding \$1 per unit per period for anything carried past its production period.
Working backwards (all quantities in dollars):
- $F(4)$: produce 2 in period 4 → $5 + 4 = \mathbf{9}$.
- $F(3)$: cover 3 only → $5 + 8 + F(4) = 5+8+9 = 22$; cover 3–4 → $5 + 2(6) + 1(2) + F(5) = 5+12+2 = \mathbf{19}$. So $F(3) = 19$, produce 6 in period 3.
- $F(2)$: cover 2 → $5+4+F(3) = 28$; cover 2–3 → $5+2(6)+1(4)+F(4) = 5+12+4+9 = 30$; cover 2–4 → $5+2(8)+[1(4)+2(2)]+F(5) = 5+16+8 = 29$. So $F(2) = \mathbf{28}$.
- $F(1)$: cover 1 → $5+6+F(2) = 39$; cover 1–2 → $5+2(5)+1(2)+F(3) = 5+10+2+19 = \mathbf{36}$; cover 1–3 → $5+2(9)+[1(2)+2(4)]+F(4) = 5+18+10+9 = 42$; cover 1–4 → $5+2(11)+[1(2)+2(4)+3(2)] = 5+22+16 = 43$. So $F(1) = \mathbf{36}$.
**Optimal plan:** produce **5 units in period 1** (covering periods 1–2) and **6 units in period 3** (covering periods 3–4). **Total cost 36.**

**16.4.3**
```python
d, K, h, uc = [3, 2, 4, 2], 5.0, 1.0, 2.0
T = len(d); INF = float("inf")
F = [0.0]*(T+1); choice = [None]*(T+1)
for t in range(T-1, -1, -1):
    F[t] = INF
    for j in range(t, T):
        qty  = sum(d[t:j+1])
        hold = sum(h*sum(d[k+1:j+1]) for k in range(t, j+1))
        val  = K + uc*qty + hold + F[j+1]
        if val < F[t]: F[t], choice[t] = val, j
print("F =", F)
t, plan = 0, []
while t < T:
    j = choice[t]; plan.append((t+1, sum(d[t:j+1]))); t = j+1
print("plan (period, qty):", plan, " cost", F[0])
```
Output: $F = [36, 28, 19, 9, 0]$; plan $[(1, 5), (3, 6)]$, cost **36** — matching the hand computation.
Brute force over the $2^3 = 8$ choices of which periods (beyond period 1, which must produce) have a setup, assigning each demand to the most recent production period, also returns **36** with production in periods 1 and 3 ✓.

**16.4.4** **Decision rule:** try DP first when the problem has (i) a natural **sequence** — a time axis, a route, a position in a string — and (ii) a **compact state** that summarizes the past, typically one or two scalars with a modest number of discrete levels, and (iii) an objective that **accumulates** over stages. Where those hold, DP gives the exact optimum in time linear in states × actions, with no relaxation gap, no branching, and a policy (not just a plan) as a byproduct — nothing in Chapters 13–15 competes.
**A problem that looks like DP but is better as a MILP:** multi-item lot-sizing with a **shared capacity** constraint. Each item alone is a textbook DP (as in 16.4.2), but a joint capacity limit per period couples the items, so the state must include the inventory levels of *all* items simultaneously — a vector state whose size explodes with the number of items (the curse of §16.3). A MILP handles the coupling naturally with setup binaries and a single capacity row per period, and modern solvers do it well. The general signal: **DP breaks when constraints couple otherwise independent sequences**, because coupling is exactly what forces the state to become high-dimensional.

## Solutions — 17.1 When you need them — and when you must not use them

**17.1.1**
- **Black-box objective** (simulation, experiment, legacy executable): no gradients, and finite differences on simulation noise are garbage — diagnosed by **§12.1** (the noise floor sets the achievable gradient accuracy at $\sqrt{\epsilon_{\text{eff}}}$).
- **Nonsmooth or discontinuous** objective (an `if`, a table lookup, a remeshing step): diagnosed by **§7.5** ("line search failed" and plotting $f$ along a ray) and **§2.2** (whether the nonsmoothness is reformulable instead).
- **Strongly multimodal** landscape where multi-start is unreliable: diagnosed by **§3.3** (scanning for products, nonlinear equalities, trigonometric terms) and by **§8.3/§9.6** multi-start evidence.
- **Combinatorial with no useful relaxation** at a scale where branch and bound will not finish: diagnosed by **§13.3/§15.2** (is the relaxation weak because of my formulation?) and **§14.3** (what gap does the solver actually reach?).

**17.1.2** (a) **No** — this is a MILP (sequencing disjunctions, §13.4). Use a MILP solver for moderate size; at 45 jobs it may be hard, in which case use a MILP-based heuristic or a *tabu search* — but only after seeing the solver's gap, and always reporting the bound the MILP gives you. (b) **No** — smooth nonlinear least squares: `least_squares` (Levenberg–Marquardt, §8.1), plus the standard errors and $\operatorname{cond}(J^\top J)$ check. (c) **No** — blending is the classic **LP** (§4.1); a solver proves optimality in milliseconds. (d) **Yes, but not a metaheuristic** — expensive black box, so **Bayesian optimization / surrogate** methods (§18), which are sample-efficient; a GA needing $10^4$ evaluations would take 7 years. (e) **No** — a $200\times200$ **assignment problem**, totally unimodular, solved exactly by `linear_sum_assignment` or an LP (§6.2). (f) **Yes** — nonsmooth, black-box, low-dimensional: a metaheuristic or a derivative-free direct-search method (NOMAD, Nelder–Mead with caveats) is legitimate here.

**17.1.3** (i) **About the answer:** you get a *worse* answer, slower, with no certificate. The MILP solver would have returned the proven optimum in seconds; the GA returns some feasible point of unknown quality — possibly 30 % off — and cannot tell you which. You also pay in tuning time (population, rates, penalties) that the exact method does not charge. (ii) **About what you never learn:** you forfeit all the *structural* information the exact route hands over for free — the LP relaxation bound, the MIP gap, shadow prices and reduced costs, the active set, sensitivity ranges. Those are the outputs that drive investment decisions and design conversations (§5.4, §9.4, §10.4). A heuristic gives you a number; structure gives you an understanding of the problem.

**17.1.4** Three questions:
1. **"Is my problem convex, linear, a network, or a moderate MILP?"** — i.e. have we located it in the §1.5 map? If it sits anywhere with exploitable structure, the GA is the wrong tool regardless of its merits.
2. **"What baseline are you comparing against, at the same evaluation budget?"** — plain random search and multi-start local optimization (§17.4). A surprising number of metaheuristic "improvements" do not beat multi-start L-BFGS on a fair comparison.
3. **"What will you report about solution quality and reproducibility?"** — the distribution over independent seeds (best/median/worst), the seeds and budget, explicit final feasibility checks, and an honest statement that no lower bound exists (§17.5).
What would change my mind: credible evidence that the objective is genuinely black-box/nonsmooth (so no relaxation exists), *plus* a demonstration that the GA beats multi-start and random search at equal budget on my instances, *plus* a plan to obtain some bound — even a weak LP relaxation of a simplified model — so the answer can be assessed rather than merely delivered.

## Solutions — 17.2 Worked Example 12 — a local optimum you can verify by hand

**17.2.1** From $S = \{1\}$ (value 10, weight 6), the four single flips are:

| move | result | verdict |
|---|---|---|
| add item 2 | weight $6+6 = 12 > 10$ | infeasible |
| add item 3 | weight $6+5 = 11 > 10$ | infeasible |
| add item 4 | weight $6+5 = 11 > 10$ | infeasible |
| drop item 1 | value 0 | worse |

No improving single flip exists, so hill-climbing halts and reports value **10**. The global optimum is $\{3,4\}$: weight $5+5 = 10$ ✓, value $\mathbf{22}$. The local optimum is $(22-10)/22 = \mathbf{54.5\%}$ below optimal — on a four-item problem. To escape by single flips you must first *accept* the collapse $\{1\}\to\{\}$, value $10 \to 0$; permitting such moves in a disciplined way is exactly what SA, tabu search and evolutionary methods do.

**17.2.2** (a) Total capacity 15. Enumerating: $\{3,4,5\}$ has weight $5+5+5 = 15$ ✓ and value $9+9+9 = \mathbf{27}$ — the optimum. ($\{1,2\}$: weight 14, value 24; $\{1,3,4\}$: weight 17 ✗; $\{1,2,3\}$: weight 19 ✗.)
(b) From $S = \{1,2\}$ (weight 14, value 24): adding any item gives weight $14+5 = 19 > 15$ (infeasible); dropping either gives value 12 (worse). **No improving flip.**
(c) Swaps (one out, one in): $\{1,3\}$, $\{1,4\}$, $\{1,5\}$, $\{2,3\}$, … all have weight $7+5 = 12$ ✓ but value $12+9 = 21 < 24$. **No improving swap** — so enriching to swaps, which rescued the text's example, fails here.
(d) The smallest escaping move class is **"drop 2, add 3"**: $\{1,2\} \to \{3,4,5\}$, value $24 \to 27$ in a single move. (Equivalently, a *ruin-and-recreate* move: remove the heavy items and greedily refill.) Note why: the optimum shares *no* items with the starting point, so any neighborhood that changes fewer than 5 memberships at once cannot reach it in one improving step.

**17.2.3**
```python
import numpy as np, itertools
vals = np.array([12,12,9,9,9]); wts = np.array([7,7,5,5,5]); W = 15; n = 5
val = lambda S: int(vals[list(S)].sum()) if S else 0
wt  = lambda S: int(wts[list(S)].sum()) if S else 0

def flips(S):
    for i in range(n):
        T = set(S); T.symmetric_difference_update({i}); yield T
def swaps(S):
    yield from flips(S)
    for i in list(S):
        for j in set(range(n)) - S:
            T = set(S); T.remove(i); T.add(j); yield T
def big(S):
    yield from swaps(S)
    for k_out in (1, 2):
        for out in itertools.combinations(sorted(S), k_out):
            rest = set(range(n)) - S
            for k_in in (1, 2, 3):
                for inn in itertools.combinations(sorted(rest), k_in):
                    yield (set(S) - set(out)) | set(inn)

def hill(S, nb):
    S = set(S)
    while True:
        better = [T for T in nb(S) if wt(T) <= W and val(T) > val(S)]
        if not better: return sorted(S), val(S)
        S = max(better, key=val)

for name, nb in [("flip", flips), ("flip+swap", swaps), ("flip+swap+(2out,3in)", big)]:
    print(f"{name:24s}", hill({0,1}, nb))

def sa(seed, T0, cool, iters):
    rng = np.random.default_rng(seed); S = {0,1}; best = val(S); T = T0
    for _ in range(iters):
        i = int(rng.integers(0, n)); Tn = set(S); Tn.symmetric_difference_update({i})
        if wt(Tn) <= W:
            d = val(S) - val(Tn)                       # d > 0 means worsening
            if d <= 0 or rng.random() < np.exp(-d/T): S = Tn
        best = max(best, val(S)); T *= cool
    return best

for T0, cool, iters in [(10, 0.95, 400), (30, 0.99, 2000), (50, 0.995, 5000)]:
    r = [sa(s, T0, cool, iters) for s in range(20)]
    print(f"SA T0={T0:3} cool={cool} iters={iters:5}: reached 27 in {sum(x==27 for x in r)}/20,"
          f" median {int(np.median(r))}")
```

| neighborhood | stops at |
|---|---|
| flips | $\{1,2\}$, value **24** |
| flips + swaps | $\{1,2\}$, value **24** |
| flips + swaps + (drop ≤2, add ≤3) | $\{3,4,5\}$, value **27** ✓ |

| SA schedule | reached 27 | median |
|---|---|---|
| $T_0=10$, cool 0.95, 400 iters | **0/20** | 24 |
| $T_0=30$, cool 0.99, 2000 iters | **18/20** | 27 |
| $T_0=50$, cool 0.995, 5000 iters | **20/20** | 27 |

**17.2.4** The text's moral: *before adding a temperature schedule and a mutation rate, ask whether your neighborhood is rich enough* — the neighborhood **is** the landscape, and redesigning it is cheaper and more reliable than tuning randomness.
The qualification from 17.2.3: **enriching the neighborhood only helps if the enrichment reaches the optimum's basin.** Here swaps — the exact fix that rescued the text's example — buy nothing, because the optimum shares no items with the start; you need a genuinely larger move class (drop 2 / add 3), and the cost of that is combinatorial: the neighborhood grows from $O(n)$ to $O(n^2)$ to $O(n^5)$ candidates per step, so each iteration becomes far more expensive and the approach does not scale.
The honest synthesis, and what the SA table shows: neither lever dominates. A fast cooling schedule fails completely (0/20) on a trap this deep, while a hot, slow schedule succeeds every time (20/20) at 12× the evaluation budget. So the real design question is *how to spend a fixed budget* — on richer moves, on more permissive acceptance, or on more restarts — and answering it requires measuring, over multiple seeds, at equal budget (§17.4). Neighborhood first, because it is free when it works; acceptance rules and budget when it does not.

## Solutions — 17.3 The main metaheuristics, briefly and honestly

**17.3.1**

| $T$ | $e^{-1/T}$ | $e^{-5/T}$ | behaviour |
|---|---|---|---|
| 50 | 0.980 | 0.905 | accepts almost anything — near a random walk |
| 10 | 0.905 | 0.607 | broad exploration |
| 5 | 0.819 | 0.368 | exploring |
| 2 | 0.607 | 0.082 | becoming selective |
| 1 | 0.368 | 0.0067 | nearly greedy for big moves |
| 0.5 | 0.135 | $4.5\times10^{-5}$ | greedy |
| 0.2 | 0.0067 | $1.4\times10^{-11}$ | frozen — pure hill-climbing |

A worsening of 5 becomes effectively impossible ($<10^{-4}$) at about $T = 0.5$. Implication: **the cooling schedule is the algorithm.** Once $T$ falls below roughly $\Delta f/10$ for the barrier heights in your landscape, SA has silently become hill-climbing and all remaining budget is spent polishing whatever basin it happens to be in. Cool too fast and you freeze into the first local optimum (17.2.3's 0/20); too slowly and you spend the whole budget wandering. Note also that the two columns differ: at $T = 2$ small worsenings ($\Delta f = 1$) are still accepted 61 % of the time while large ones ($\Delta f = 5$) are down to 8 %, so cooling filters barriers *by height* — which is the mechanism's real content.

**17.3.2** With $f$ in joules ($\Delta f \sim 10^6$) and $T_0 = 1$: $e^{-10^6/1} \approx 0$ — **every** worsening move is rejected from the first iteration. SA is hill-climbing with extra overhead, and it will report the first local optimum it meets. With $f$ in megajoules ($\Delta f \sim 1$) and $T_0 = 10^4$: $e^{-1/10^4} \approx 0.9999$ — **every** move is accepted, so the search is a pure random walk that never converges and never exploits anything it finds; the entire budget is spent sampling uniformly.
This is **§2.3 (scaling)** in a new costume: a numerical parameter with units ($T$ has the units of $f$) compared against a quantity whose scale you never checked. The remedy is the same — normalize. In practice set $T_0$ from measured data: sample random moves, compute the distribution of $|\Delta f|$, and choose $T_0$ so that a typical worsening is accepted with probability $\approx0.5$ (i.e. $T_0 \approx \overline{|\Delta f|}/\ln 2$), and cool to $T_{\text{end}} \ll \overline{|\Delta f|}$.

**17.3.3**
- **Simulated annealing** — *escape:* accept worsening moves with probability $e^{-\Delta f/T}$; *tuning:* $T_0$, cooling rate, iterations per temperature, move distribution; *failure:* freezing too early (or wandering forever), and total sensitivity to the scale of $f$.
- **Genetic / evolutionary** — *escape:* recombination of a *population*, so new points can jump between basins, plus mutation; *tuning:* population size, selection pressure, crossover and mutation rates, encoding; *failure:* slow, unproven convergence and loss of diversity (the population collapses onto one basin); encoding design is often the real determinant.
- **Particle swarm** — *escape:* velocities pulled toward personal and global bests, giving momentum through poor regions; *tuning:* swarm size, inertia weight, cognitive/social coefficients; *failure:* premature convergence when the swarm collapses; continuous spaces only, without extra machinery.
- **Tabu search** — *escape:* a short-term memory forbidding recently made moves, forcing the search out of the basin it just explored; *tuning:* tabu tenure, aspiration criteria, neighborhood definition; *failure:* highly problem-specific design effort, and the memory structure must be tailored; classical form is deterministic, which is often an advantage.

**17.3.4** Pick **tabu search**. Reasons: it is often the strongest choice on *structured* combinatorial problems (rostering, scheduling, routing) because its memory is built from problem-specific move attributes; and in its classical form it is **deterministic**, so runs are reproducible and debuggable — exactly what an audit requires. Its neighborhood can also encode the hard rostering rules directly, keeping the search inside feasibility rather than penalizing violations.
If instead a stochastic family were chosen (SA or GA), reproducibility must be manufactured: **fix and record the random seed** and the exact evaluation budget; log the full run so any reported roster can be regenerated bit-for-bit; report the *distribution* over seeds (best/median/worst) rather than a single run; and check final feasibility explicitly at the returned point, since penalty-based constraint handling routinely returns slightly infeasible solutions (§17.4). Also worth stating in the audit trail: no lower bound exists, so the roster's distance from optimal is unknown (§17.5) — unless a MILP relaxation of a simplified model is solved alongside to supply one.

## Solutions — 17.4 Experimental hygiene

**17.4.1**
- **Run multiple independent trials; report best/median/worst.** Skipped ⇒ you cannot claim the method *works*, only that it once produced a number. A single lucky run is a fluke dressed as a result (17.2.3: the same SA setup gave 0/20 and 20/20 under different schedules — one run of either would have "proved" the opposite).
- **Fix and report seeds and the evaluation budget.** Skipped ⇒ the result is not reproducible, so no one — including you next month — can verify or build on it.
- **Compare against honest baselines at equal budget** (random search, multi-start local optimization). Skipped ⇒ you cannot claim the *method* deserves credit rather than the budget; many published "improvements" do not beat multi-start L-BFGS on a fair comparison.
- **Check final feasibility explicitly.** Skipped ⇒ you cannot claim the returned point is a *design*; penalty-based constraint handling routinely returns slightly infeasible points.

**17.4.2**
```python
import numpy as np
f = lambda x: np.sin(10*x)*x + 1.2*(x - 1)**2
print("grid  (16):", f(np.linspace(0, 2, 16)).min())
rng = np.random.default_rng(0)
best = [f(rng.uniform(0, 2, 16)).min() for _ in range(200)]
print(f"random(16): median {np.median(best):.5f}   best-case {min(best):.5f}")
# BO from 18.2, 4 initial + 12 iterations = 16 evaluations -> -1.09369
```

| method (16 evaluations) | best $f$ found |
|---|---|
| uniform grid | $-1.08542$ |
| random search, **median** of 200 runs | $-1.06350$ |
| random search, **best** of 200 runs | $-1.09369$ |
| Bayesian optimization | $\mathbf{-1.09369}$ (the true minimum) |

Reporting only the best random-search run would have been misleading in **both directions**: it matches BO exactly, so it would suggest that the surrogate machinery buys nothing — while in fact that figure is the best of $200\times16 = 3200$ evaluations, twelve times BO's total budget of 16. The honest comparison is BO ($-1.09369$, deterministic) against random search's **median** ($-1.06350$), i.e. against what one run actually delivers. This is why the requirement is to report the *distribution*: the maximum over many runs is not a property of the method at the stated budget.

**17.4.3** Missing: (i) the number of independent GA runs and the distribution of outcomes (was 41.2 kg the median or the best of 50 runs?); (ii) the random seeds and the total evaluation budget for each method — if the GA used $10^5$ evaluations and the gradient method one start with 200, the comparison is meaningless; (iii) whether the gradient method was given **multi-start**, the honest baseline; (iv) plain random search at the same budget; (v) explicit constraint values at both returned designs (is the 41.2 kg design actually feasible, or feasible only up to a penalty?); (vi) any statement of solution quality — neither method provides a lower bound, so neither design is known to be near optimal; (vii) whether the two methods were even solving the same model (same bounds, same constraint tolerances).
Corrected version: *"Over 30 independent runs (seeds 1–30, budget $2\times10^4$ evaluations each), the hybrid GA returned masses of 41.2 / 43.1 / 47.6 kg (best / median / worst); all reported designs satisfy every constraint to within $10^{-8}$. Multi-start L-BFGS-B with 200 random starts at the same total evaluation budget returned 41.0 / 41.4 / 43.8 kg. On this problem the two methods are comparable, with the gradient-based multi-start slightly better at the median; neither provides a lower bound, so the distance to the global optimum is unknown."*

**17.4.4** Because most metaheuristics do not enforce constraints — they **absorb them into the objective as penalty terms**, $f + \rho\sum\max(0,g_i)^2$ or similar. That mechanism makes infeasibility *expensive* rather than *impossible*, so a point that violates a constraint slightly but scores well on the objective can win, especially if $\rho$ is too small or if the penalty terms are on mismatched scales (§2.3 again). Nothing in the algorithm's stopping rule checks feasibility; there is no analogue of the constrained-solver KKT/feasibility test of §9.7.
Consequently feasibility is a *separate* verification you must perform: evaluate every $g_i$ and $h_j$ at the returned point and report the violations, exactly as `interrogate` does in §2.1. If small violations are unacceptable, either project the point onto the feasible set afterwards, tighten the constraints by a margin (§9.7.2), or use a method that treats constraints as constraints — which is one more argument for exact methods when the structure permits.

## Solutions — 17.5 The limitations, stated plainly

**17.5.1** §9.5's framing: a **feasible point** bounds $f^\star$ from the achievable side (an upper bound for minimization); a **relaxation or dual-feasible multiplier** bounds it from the other side (a lower bound); optimality is proved only when the two meet. A metaheuristic generates *nothing but feasible points* — it evaluates candidates and remembers the best. So it produces a one-sided bound only: "there exists a solution of cost 1.42 M." It has no object that says anything about *all* solutions at once.
This is structural because a lower bound requires an argument about the entire feasible set — a dual feasible point, an LP relaxation, a valid inequality, a combinatorial counting argument. Such objects come from **structure**, and a search procedure that only samples has no access to them however cleverly it samples or however much compute it is given. No improvement in heuristic technology changes this; it is a statement about what kind of object a certificate is.

**17.5.2** **Careful statement:** averaged uniformly over *all possible objective functions* on a finite search space, every non-revisiting search algorithm has identical expected performance (Wolpert & Macready, 1997).
**What it licenses:** the conclusion that no algorithm is universally superior, and therefore that any algorithm's advantage on your problem comes entirely from *matching your problem's structure* — so claims of a generally best metaheuristic are unfounded, and benchmark results do not transfer automatically to your instances.
**What it does not license:** (i) *"all algorithms are equally good on my problem"* — false. The average is over a set of functions that is overwhelmingly dominated by structureless noise, which real objectives are not. On your particular problem, differences are enormous (a MILP solver versus a GA on a 200×200 assignment: exact in milliseconds versus mediocre in hours). (ii) *"method choice does not matter"* — this inverts the theorem. NFL says the *only* thing that can give an advantage is exploiting structure, so method choice is precisely what matters. That is the argument for Parts I–IV existing at all, even on the days you end up using a heuristic.

**17.5.3** The honest answer: *"We have a feasible schedule costing \$1.42 M — that is an upper bound on the best achievable cost. The method used provides no lower bound, so I cannot tell you whether the optimum is \$1.41 M or \$1.0 M. What I can tell you is the spread over 30 independent runs (best 1.42 M, median 1.47 M, worst 1.55 M), which suggests the search is finding a consistent region but says nothing about how far that region is from optimal."*
Concrete route to a lower bound: **build and solve a relaxed model.** Drop the constraints that make the problem intractable — sequence-dependent setups, side coupling, integrality — and solve the resulting LP or MILP; its optimum is a rigorous lower bound on the true cost. Even a crude relaxation is decisive: if it returns \$1.39 M you now know the heuristic schedule is within 2 %, and the conversation is over; if it returns \$0.9 M you know only that there may be room, and where to look. Alternative routes: a Lagrangian relaxation of the coupling constraints (which is §9.5 applied deliberately, and gives a bound plus multiplier information), or solving small instances to proven optimality to calibrate the heuristic's typical gap.

**17.5.4** **The default:** use a global strategy (or plain multi-start) to *locate* promising basins, then polish each candidate with a gradient-based local method from Part III.
**What each half contributes:** the global phase supplies **reach** — it samples widely enough to find several basins, which no local method can do, and it tolerates the ruggedness that defeats a single descent run. The local phase supplies **efficiency and precision** — once inside a basin, BFGS/SQP converges superlinearly to a point satisfying the KKT conditions to tolerance (§7.4, §9.7), where a metaheuristic would spend thousands of evaluations creeping toward the same point and stop somewhere slightly infeasible. Polishing is cheap relative to the global search, so this is nearly free.
**What the combination reports:** not just a best point, but **how many distinct local optima were found, and their spread**. That is genuine information about the problem — a landscape with 3 basins whose values differ by 0.5 % is a different engineering situation from one with 40 basins differing by 60 %, and it tells you how much to trust any single answer, how much multi-start budget the problem deserves, and whether the model itself should be reformulated (§3.2's design principle). It also gives *local* certificates (KKT residuals) at each candidate, which is the strongest guarantee available without global structure.

## Solutions — 18.1 The loop

**18.1.1** (1) Evaluate the true function at a modest, well-spread initial design (Latin hypercube sampling). (2) Fit a **surrogate**, typically a Gaussian process. (3) Choose the next expensive evaluation by maximizing an **acquisition function** such as expected improvement. (4) Add the point, refit, repeat until the budget is exhausted.
What a GP returns that plain regression does not: at every candidate point, both a **prediction** $\mu(x)$ *and* a calibrated **uncertainty** $\sigma(x)$ — a full posterior distribution rather than a point estimate. The uncertainty is what makes step 3 possible: without it there is no way to distinguish "the model predicts a poor value here because it knows" from "because it has never looked here."

**18.1.2** $EI = (y_{\min}-\mu)\Phi(z) + \sigma\phi(z)$.
- The **first term** is the *exploitation* term: it is large when the predicted mean $\mu$ is well below the current best $y_{\min}$, i.e. where the model confidently expects improvement. It vanishes when $\mu \ge y_{\min}$ and $\sigma$ is small.
- The **second term** is the *exploration* term: it is proportional to $\sigma$, so it is large wherever the model is uncertain, regardless of the mean. Even a point with a poor predicted mean scores well if the error bars are wide enough to admit a good value.
In a **well-sampled** region $\sigma \to 0$, so the second term vanishes and EI is driven by the mean — exploitation. In an **unexplored** region $\sigma$ is large and $\mu$ reverts toward the prior, so the second term dominates — exploration. The switch is automatic and requires no tuning parameter, which is EI's main practical appeal.

**18.1.3** (i) **Fitting the surrogate becomes the bottleneck and the statistics weaken.** A GP requires $O(N^3)$ work in the number of samples, and — more fundamentally — the number of points needed to pin down a response surface grows exponentially with $n$, so in high dimensions the posterior is essentially the prior everywhere and $\sigma(x)$ is large and uninformative. (ii) **Maximizing the acquisition function becomes its own hard global optimization problem** in $n$ dimensions, multimodal and increasingly expensive; the inner problem inherits the curse you were trying to avoid.
At $n = 500$ with cheap gradients, BO is the wrong tool entirely: use **L-BFGS (or CG) with multi-start**, or a gradient-based method with an adjoint if the gradient comes from a simulation (§12.3). Gradients carry $n$ pieces of information per evaluation, which is exactly what high dimensions require; surrogates carry one.

**18.1.4** (a) **BO** — expensive, black-box, low-dimensional: this is precisely BO's design case, and 8 dimensions is comfortably inside its range. (b) **Gradient method** (BFGS or SQP) — smooth, unimodal, gradients available; nothing else competes, and you get local certificates. (c) **Metaheuristic** (tabu search or SA) — combinatorial with no usable relaxation and a fast objective, so many evaluations are affordable; BO's sample efficiency is irrelevant and GPs do not model binary spaces well. But first check whether a relaxation really is unavailable (§13.1, §17.1). (d) **BO** — very expensive, noisy, 3 dimensions; the GP handles observation noise naturally (a nonzero noise term in the kernel), and sample efficiency is worth the most here at \$2 000 per evaluation.

## Solutions — 18.2 Watch it think

**18.2.1**
```python
import numpy as np
from scipy.stats import norm

f  = lambda x: np.sin(10*x)*x + 1.2*(x - 1)**2
xg = np.linspace(0, 2, 2001)

def gp_posterior(X, y, Xs, ell=0.15, sf=1.0, noise=1e-8):
    k = lambda a, b: sf*np.exp(-(a[:, None] - b[None, :])**2/(2*ell**2))
    L = np.linalg.cholesky(k(X, X) + noise*np.eye(len(X)))
    alpha = np.linalg.solve(L.T, np.linalg.solve(L, y))
    Ks = k(X, Xs); v = np.linalg.solve(L, Ks)
    return Ks.T @ alpha, np.sqrt(np.clip(sf - np.sum(v**2, axis=0), 1e-12, None))

X = np.array([0.15, 0.7, 1.3, 1.9]); y = f(X)
for it in range(12):
    mu, sd = gp_posterior(X, y, xg)
    z  = (y.min() - mu)/sd
    EI = (y.min() - mu)*norm.cdf(z) + sd*norm.pdf(z)
    xn = xg[np.argmax(EI)]
    X, y = np.append(X, xn), np.append(y, f(xn))
    print(f"iter {it+1:2d}: best x={X[np.argmin(y)]:.4f}  f={y.min():.5f}")
print(f"grid truth: x={xg[np.argmin(f(xg))]:.4f}  f={f(xg).min():.5f}")
```
Final: best $x = 1.7240$, $f = -1.09369$ in 16 evaluations — exactly the grid truth over 2001 points.
Best-so-far trace: iterations 1–3 sit at $x \approx 0.994$ ($f = -0.48973$); iteration 4 finds $x = 1.080$ ($f = -1.05173$); iterations 5–9 refine within that basin to $x \approx 1.105$ ($f = -1.09013$); **iteration 10** is the first evaluation in the *true* basin, at $x \approx 1.722$ ($f = -1.09349$), refined to $-1.09369$ by the end. So the search spent most of its budget in a *different* basin and entered the correct one only at evaluation 14 of 16 — driven there by EI's exploration term, not by the mean.

**18.2.2**

| $\ell$ | best $f$ found | best $x$ |
|---|---|---|
| 0.05 | $-1.09100$ | 1.7180 |
| **0.15** | $\mathbf{-1.09369}$ | 1.7240 |
| 0.5 | $-1.08480$ | 1.1160 |

**Too small** ($\ell = 0.05$): the GP assumes the function wiggles on a very short scale, so $\sigma$ rebounds to the prior almost immediately away from any sample. The model generalizes nothing, EI is high nearly everywhere, and BO degenerates toward **space-filling random search** — it gets close but wastes evaluations and never sharpens the final answer.
**Too large** ($\ell = 0.5$): the GP assumes the function is smoother than it is, so it *smooths away* the true structure — the several local minima are averaged into one broad valley — and $\sigma$ is small over wide regions the model has not actually resolved. The result is **confident nonsense** (§18.3): EI stops exploring, the search commits to the wrong basin, and it terminates at $x \approx 1.116$, missing the optimum. Note this is the more dangerous failure: it looks converged.

**18.2.3** The expression is the standard GP posterior variance via the Cholesky factor. With $K = LL^\top$ and $v = L^{-1}K_s$,
$$\sigma^2(x_s) = k(x_s,x_s) - K_s^\top K^{-1}K_s = s_f - \|v\|^2,$$
i.e. the prior variance $s_f$ minus the variance *explained* by the observed data. At a **sampled** point $x_s = X_i$, the column $K_s$ is exactly the $i$-th column of $K$, so $K_s^\top K^{-1}K_s = K_{ii} = s_f$ and $\sigma^2 = 0$ (in the noise-free limit; the `noise` jitter makes it a tiny positive number numerically). Interpretation: the GP interpolates the data exactly and admits no uncertainty where it has looked.
Guarantee: since $EI = (y_{\min}-\mu)\Phi(z) + \sigma\phi(z)$ and at a sampled point $\sigma = 0$ while $\mu = y_i \ge y_{\min}$, EI is **zero at every already-sampled point**. So BO never wastes an evaluation re-sampling a point it has already tried — the acquisition function enforces non-revisiting automatically, without a memory structure or tabu list.

**18.2.4** With a budget of 10, BO would have stopped at $x \approx 1.105$, $f = -1.09013$ — in the *wrong basin*, but within $0.33\%$ of the true optimum **by objective value**, and with no indication that a different basin existed. That is the characteristic BO outcome: a near-optimal *value* at a substantially different *design point* ($x \approx 1.11$ versus $1.72$), and no bound to reveal the difference.
Implications for reporting: (i) never report a BO result as "the optimum" — report it as the best found within a stated budget, with the budget stated, since BO like everything in Part V yields upper bounds only (§17.5, §18.3). (ii) Report the **history**, not just the final point: a best-so-far curve that was still improving at the budget limit means the budget bound, not the function. (iii) Report the *locations* of the near-best candidates, not just values — if two very different designs score within 0.5 %, that is decision-relevant information (it may mean a robustness or manufacturability choice is free, §20). (iv) Where possible, re-run with different initial designs and different kernel hyperparameters (18.2.2) and report the spread, which is the BO analogue of multi-start.

## Solutions — 18.3 Two cautions

**18.3.1** The GP's uncertainty is not measured from the data alone; it is produced by the **kernel** — the assumed covariance function, which encodes smoothness and a length scale (plus amplitude and noise level). If those assumptions are wrong, the error bars are wrong in a specific and dangerous way: a too-large length scale yields **narrow bands around wrong predictions**, so the acquisition function believes it already understands regions it has never resolved, stops exploring, and converges confidently to the wrong place (demonstrated in 18.2.2, $\ell = 0.5$).
Partial mitigation: **fit the kernel hyperparameters by maximum marginal likelihood** at each refit, rather than fixing them by hand, and use a kernel class flexible enough for the physics (Matérn-5/2 rather than the very smooth RBF is a common default; anisotropic length scales per dimension for problems with different sensitivities). Also: standardize inputs and outputs (§2.3 again), and sanity-check by leave-one-out cross-validation on the samples you have. On tiny budgets the assumptions still dominate — which is why reporting the sensitivity to them (18.2.2) is part of the result.

**18.3.2** Like everything in Part V, BO evaluates only feasible candidates, so it yields **upper bounds only** ($f^\star \le$ best found). It has no relaxation and no dual object, hence no lower bound and no certificate; it cannot tell you what it missed, and the near-miss in 18.2.4 is exactly that failure being invisible from inside the run.
What BO uniquely provides: it **spends each expensive evaluation where the model says information is highest**, trading exploitation against exploration in a principled way, so it achieves in tens of evaluations what random search or a metaheuristic needs thousands to approach (17.4.2: BO's $-1.09369$ at 16 evaluations versus random search's median $-1.06350$). It also provides a *model* as a byproduct — a cheap surrogate with calibrated uncertainty that can be reused for sensitivity studies, visualization, or as an inner model for robust design. That is the best available without structure.

**18.3.3** Protocol for 40 evaluations, $n = 6$:
1. **Initial design:** a Latin hypercube of about $2n$–$3n$ points, i.e. 12–18, on scaled variables (each mapped to $[0,1]$). Keep at least half the budget for the sequential phase.
2. **Surrogate:** GP with a Matérn-5/2 kernel and **anisotropic** length scales (one per dimension), hyperparameters refit by maximum marginal likelihood at every iteration; standardize $y$ to zero mean and unit variance; include a noise term if evaluations are noisy, and estimate it rather than fixing it at zero.
3. **Acquisition:** expected improvement, maximized by multi-start local optimization over the scaled box (not a coarse grid, which fails at $n=6$).
4. **Stopping:** exhaust the budget, but also record the best-so-far curve; if EI's maximum has fallen below a small fraction of the current best improvement for several consecutive iterations, note that the search has converged in the model's own terms.
5. **Reporting:** the best design and value; the **best-so-far curve** (still improving at the limit, or flat?); the fitted length scales (which double as a sensitivity analysis — a long length scale means that variable barely matters); a **repeat run** with a different LHS seed and the spread between them; a leave-one-out check of the GP's predictive accuracy; explicit constraint values at the returned design; and an explicit statement that no lower bound exists. Also report the second- and third-best distinct candidates, since near-ties at different locations are decision-relevant (18.2.4).

**18.3.4** The analogy: a trust-region method builds a **local model** of $f$, decides how far it trusts that model, minimizes the model within the trusted region, then compares predicted with actual reduction and adjusts the trust radius (§7.5). BO builds a **global surrogate**, and its posterior standard deviation $\sigma(x)$ is precisely a *quantified statement of how far the model is trusted* at each point; the acquisition function then optimizes a combination of predicted value and trust, and each new observation updates the trust everywhere. Trust expands where data accumulates and contracts where it does not — the same adaptive logic, with the ad hoc radius replaced by a posterior.
**Where it breaks down:** (i) a trust region's guarantee is *local and provable* — under standard assumptions the method converges to a stationary point, with the radius mechanism enforcing decrease; BO has no such convergence guarantee and no decrease requirement, since it may deliberately evaluate somewhere much worse to explore. (ii) A trust region's model is derived from **exact derivative information** at the current point, so its accuracy is controlled by Taylor's theorem; BO's surrogate accuracy rests on **assumed** smoothness (the kernel), which can be wrong in ways Taylor's theorem cannot be (§18.3.1). (iii) Trust regions are local and monotone by design; BO is global and non-monotone. So the analogy is a good intuition for *how* the mechanism balances model against reality, and a poor guide to *what is guaranteed*.

## Solutions — 19.1 Method 1 — the weighted sum

**19.1.1** Design $x^a$ **dominates** $x^b$ if it is at least as good in every objective and strictly better in at least one. A design dominated by nothing is **Pareto optimal**, and the set of all Pareto-optimal designs, viewed in objective space, is the **Pareto front**.
"Everything off the front is a mistake" because a dominated design can be replaced by one that is *no worse in anything and better in something* — an improvement available at no cost in any objective, so choosing it is strictly irrational. By contrast, every point *on* the front is a legitimate choice: moving along the front necessarily trades one objective against another, and which trade is preferable is a **values judgment**, not a mathematical one — which is why the analyst's job is to deliver the front, not to pick a point on it.

**19.1.2** With raw values, $0.5(400) + 0.5(2) = 200 + 1$: the mass term is 200 times larger, so the "equal weights" objective is effectively **minimizing mass alone** and the cost objective is invisible. Weights on unnormalized objectives are meaningless numerology — the implicit exchange rate is set by the units, not by the decision-maker.
Recommended normalization: scale each objective to roughly $[0,1]$ using
- the **ideal point** $f_i^{\text{ideal}}$: the best achievable value of $f_i$, obtained by optimizing $f_i$ *alone*;
- the **nadir point** $f_i^{\text{nadir}}$: the worst value of $f_i$ over the Pareto front,

then use $\tilde f_i = \dfrac{f_i - f_i^{\text{ideal}}}{f_i^{\text{nadir}} - f_i^{\text{ideal}}}$. Now $w = (0.5, 0.5)$ genuinely means "equal importance," and the weights are interpretable as trade-off rates in dimensionless units.

**19.1.3** Minimizing $w_1f_1 + w_2f_2$ over the feasible set is geometrically the operation of sliding a line of slope $-w_1/w_2$ in objective space until it last touches the attainable region; the touch point is the returned design. As $w$ sweeps, that line rolls around the region's **lower-left convex hull**. On a *dented* (locally concave) stretch of the front, the line spans the dent — touching the two rims on either side — and no orientation of a straight line can touch the interior of the dent, because those points lie strictly *above* the chord joining the rims. So the sweep jumps across the dent.
Exactly which points the sweep can return: the points on the front that lie on the boundary of the convex hull of the attainable set — i.e. the *supported* Pareto-optimal points. Everything in a dent is Pareto-optimal but **unsupported**, hence unreachable by any weighted sum, for any weights whatsoever. The skipped region is often precisely the interesting compromise zone.

**19.1.4** The weighted sum is complete — it sweeps the *entire* front — when the front is **convex**, which is guaranteed whenever the underlying problem is convex (convex objectives, convex feasible set). In that case it is the right choice: it is cheap (one unconstrained-in-$\varepsilon$ solve per weight), every solve is feasible (no wasted runs), and the weights have a direct interpretation as the marginal rate of substitution between normalized objectives at the returned point.
Practical advantage over $\varepsilon$-constraint: **no infeasible solves and no grid design.** With $\varepsilon$-constraint you must choose the $\varepsilon$ values, and some will be infeasible (wasted work) while a poorly chosen grid can leave gaps. Weighted sums always return a Pareto point (for positive weights), so a uniform weight sweep is trivially safe to run — plus, the scalarized problem is often easier for a solver than the constrained one, since it adds no constraint.

## Solutions — 19.2 Method 2 — the $\varepsilon$-constraint

**19.2.1** Formulation: minimize $f_1$ subject to $f_2 \le \varepsilon$ (plus the original constraints), and sweep $\varepsilon$ over a grid.
Two headline advantages: (i) it **reaches the entire front, convex or not** — a constraint boundary can sit anywhere in objective space, including inside a dent, where no straight line can touch; (ii) **each run answers a real engineering question.**
The second point: the subproblem is literally *"what is the lightest design costing no more than \$X?"* — which is how requirements and specifications are actually written. There is no need to elicit an exchange rate between kilograms and dollars from a decision-maker (which people find very hard to state and easy to state inconsistently); you need only a limit, which is what contracts and codes already contain. The returned multiplier on the $\varepsilon$-constraint is then the local trade-off rate (§9.4) — so you obtain the weights as *output* rather than requiring them as *input*.

**19.2.2** Three costs: (i) you must **choose the $\varepsilon$ grid**, and some values will be infeasible (wasted solves) while a coarse grid leaves gaps in the front; (ii) it needs **one solve per point**, and the constrained subproblem is often harder than the corresponding weighted-sum problem; (iii) in plain form it can return **weakly Pareto-optimal** points.
A *weakly* Pareto-optimal point is one that is not dominated *strictly in every objective* but where some objective could still be improved at **no cost** to the others — e.g. the subproblem is satisfied with $f_2$ strictly below $\varepsilon$ and a whole segment of designs shares the same $f_1$, so the returned point may have an unnecessarily large $f_2$. Such a point is on the boundary of the attainable set but is dominated in the weak sense, and presenting it as a trade-off is misleading.
Standard fix: the **augmented $\varepsilon$-constraint method** — minimize $f_1 - \delta s$ subject to $f_2 + s = \varepsilon$, $s \ge 0$, with a small $\delta > 0$. The tiny reward $\delta s$ for slack in the constrained objective breaks ties in favour of pushing $f_2$ as far below $\varepsilon$ as is free, which eliminates weakly Pareto points while (for small enough $\delta$) not distorting the front.

**19.2.3** The subproblem is
$$\min_x\ \|x\|^2 \quad\text{s.t.}\quad \|x - (2,1)\|^2 \le 2.$$
Geometry: minimize the distance to the origin subject to lying in the disk of radius $\sqrt2$ centred at $(2,1)$. The origin is at distance $\|(2,1)\| = \sqrt5 \approx 2.236 > \sqrt2$, so the origin is *outside* the disk and the constraint is **active**: the solution is the point of the circle closest to the origin, which lies on the segment from the origin to the centre, at distance $\sqrt5 - \sqrt2$ from the origin. Hence
$$x^\star = \frac{\sqrt5 - \sqrt2}{\sqrt5}\,(2,1) \approx (0.735,\ 0.368), \qquad f_1^\star = (\sqrt5-\sqrt2)^2 \approx 0.675,\qquad f_2^\star = 2.$$
This matches the text's computed table ($\varepsilon = 2 \Rightarrow f_1 = 0.675$, $f_2 = 2.000$) — and note $f_2 = \varepsilon$ exactly, the constraint active, which is the signature of the method: each point sits *at* the requested budget.

**19.2.4** The phrasing is a pair of **limits**, which is exactly the $\varepsilon$-constraint form — no exchange rate between kilograms and dollars is being offered, so a weighted sum would require inventing one.
How to generate the front: first find the **ideal point** by optimizing each objective alone (lightest possible design ignoring cost; cheapest ignoring mass) to learn the feasible ranges; then sweep $\varepsilon_{\text{cost}}$ over a grid spanning that range — say 20 values from the minimum achievable cost to a little above \$18 000 — solving $\min$ mass s.t. cost $\le \varepsilon$ each time, using the augmented form to avoid weakly Pareto points. Record mass, cost, the active set, and the multiplier on the cost constraint (the local kg-per-dollar trade-off rate).
What to present: the **Pareto front** with both requirement limits drawn as lines, so the feasible-and-compliant region is visible at a glance; the **knee region** marked, where a small concession in one objective buys a large gain in the other; a table of 3–5 representative designs with their objective values, active constraints and trade-off rates; and an explicit statement of whether the joint requirement (mass $\le40$ **and** cost $\le\$18\,000$) is achievable at all — if the front passes below both lines, say by how much margin; if it does not, the minimum-violation figure (§2.2, §21.2) is the number to negotiate with.

## Solutions — 19.3 Both methods, computed

**19.3.1**
```python
import numpy as np, cvxpy as cp
a, b = np.array([0., 0.]), np.array([2., 1.])
ws = np.linspace(0.02, 0.98, 25)
for w in [0.1, 0.5, 0.9]:
    x = cp.Variable(2)
    cp.Problem(cp.Minimize(w*cp.sum_squares(x-a) + (1-w)*cp.sum_squares(x-b))).solve()
    print(f"w={w}: f1={np.sum((x.value-a)**2):.3f}  f2={np.sum((x.value-b)**2):.3f}")
for eps in [0.5, 2.0, 4.0]:
    x = cp.Variable(2)
    cp.Problem(cp.Minimize(cp.sum_squares(x-a)), [cp.sum_squares(x-b) <= eps]).solve()
    print(f"eps={eps}: f1={np.sum((x.value-a)**2):.3f}  f2={np.sum((x.value-b)**2):.3f}")
```
Reproduces the text exactly: $w = 0.1 \to (4.050,\ 0.050)$, $w=0.5 \to (1.250,\ 1.250)$, $w=0.9\to(0.050,\ 4.050)$; $\varepsilon = 0.5 \to (2.338,\ 0.500)$, $\varepsilon=2 \to (0.675,\ 2.000)$, $\varepsilon=4\to(0.056,\ 4.000)$.
Sweeping 25 of each traces the **same curve** — the two sets of points interleave along one front. They must coincide because the problem is **convex** (both objectives are convex quadratics, the feasible set is all of $\mathbb{R}^2$), so the front is convex, every Pareto point is *supported*, and the weighted sum is complete (§19.1.4). The two methods differ only in *how they parameterize* the same curve: by trade-off rate versus by budget.

**19.3.2**
```python
import numpy as np
for A in (0.0, 0.12):
    t = np.linspace(0, 1, 120)
    P = np.column_stack([t, (1-t)**2 + A*np.exp(-((t-0.5)**2)/0.004)])
    pareto = [i for i, p in enumerate(P)
              if not np.any(np.all(P <= p, axis=1) & np.any(P < p, axis=1))]
    ws  = {int(np.argmin(w*P[:,0] + (1-w)*P[:,1])) for w in np.linspace(5e-4, 1-5e-4, 2000)}
    eps = set()
    for e in np.linspace(P[:,1].min(), P[:,1].max(), 2000):
        c = np.where(P[:,1] <= e + 1e-12)[0]
        if len(c): eps.add(int(c[np.argmin(P[c,0])]))
    print(f"A={A}: pareto {len(pareto)}/120   weighted-sum reachable "
          f"{len(ws & set(pareto))}   eps reachable {len(eps & set(pareto))}")
```

| | Pareto-optimal designs | reachable by 2000 weights | reachable by 2000 $\varepsilon$ |
|---|---|---|---|
| $A = 0$ (convex front) | 120 / 120 | **120** | 119 |
| $A = 0.12$ (dented) | 111 / 120 | **94** | 110 |

Interpretation: on the convex front the weighted sum is complete — 2000 weights recover every one of the 120 Pareto designs. Introduce a dent and **17 of the 111 Pareto-optimal designs (15 %) become unreachable by *any* weight whatsoever**, no matter how finely you sweep; those are the unsupported points inside the dent, and they are exactly the compromise designs a decision-maker is most likely to want. The $\varepsilon$-constraint sweep recovers 110 of 111 (the one miss is grid resolution, curable by refining the grid — a benign failure). The contrast in failure modes is the whole argument: refining a weight grid *cannot* fix the weighted sum's blind spot, because the blindness is structural, whereas refining an $\varepsilon$ grid *does* fix the $\varepsilon$-method's.

**19.3.3** **Why $f_2 = \varepsilon$ exactly:** in $\min f_1$ s.t. $f_2 \le \varepsilon$, the two objectives conflict, so reducing $f_2$ below $\varepsilon$ would require increasing $f_1$ — meaning the optimizer has no incentive to leave slack. The constraint is therefore **active** at the optimum, and $f_2 = \varepsilon$ (this is §1.4's "optimization pushes against limits," and it is why the multiplier on that constraint is nonzero and equals the local trade-off rate).
**Why weighted-sum points land "wherever the ratio dictates":** the weighted sum imposes no budget at all; it slides a line of slope $-w_1/w_2$ onto the front, and the touch point is wherever the front happens to have that tangent slope. The resulting $(f_1,f_2)$ pair is an *output* of the geometry, not a target — and small changes in $w$ can move it a lot (or not at all, across a dent).
**Easier to explain to a client:** the $\varepsilon$-constraint output, decisively. "This is the lightest design that costs no more than \$18 000" is a sentence a client can check against their own requirements. "This is the design you get when mass is weighted 0.3 and cost 0.7 after normalizing by the ideal and nadir points" requires explaining the normalization before the number means anything.

**19.3.4** *"If the problem is convex, use a **normalized** weighted sum: it is cheap, every solve returns a Pareto point, and it sweeps the whole front — but do the normalization by ideal and nadir points first, or your weights are numerology (§19.1.2). If the front may be nonconvex — which you should assume whenever the model has discrete choices, a catalogue of parts, nonconvex physics, or comes from a simulation — or if your requirements arrive as limits rather than trade-off rates, use $\varepsilon$-constraint (in its augmented form, to avoid weakly Pareto points). In doubt, use $\varepsilon$-constraint.*
*The reason for that default is an asymmetry in how the two methods fail. The $\varepsilon$-constraint method's failure mode is a few wasted infeasible solves and possible gaps in the front — visible, and curable by refining the grid. The weighted sum's failure mode is **silently omitting part of the answer**: an entire dented region of Pareto-optimal designs that no weight can reach, with nothing in the output to indicate anything is missing (in a computed example, 17 of 111 Pareto designs, 15 %, were unreachable by 2000 weights). A failure you can see and fix beats a failure you cannot detect. And whichever you use, hand over a front with the knee region marked, not a single design — the choice along the front is a values judgment, and your job is to enable it, not to make it."*

## Solutions — 20.1 Worked Example 13 — Example 1 meets reality

**20.1.1** **Structural reason:** optimization pushes against active constraints, so an optimum computed at nominal data sits *exactly on* the boundary of feasibility — and a point on a boundary is thrown outside by half of all small perturbations. This is §1.4 read as a warning rather than a diagnostic: the active set is where the design is pressed hardest, hence exactly where it is most sensitive.
**Why 50 %:** at $x^\star = (20,60)$ the machine-hour constraint holds with equality, $2(20)+60 = 100$. The perturbed constraint value is $\big[(2,1)+\rho u\big]^\top x^\star = 100 + \rho\,u^\top x^\star$, which exceeds 100 exactly when $u^\top x^\star > 0$ — i.e. for the half of the uncertainty ball lying on the positive side of the hyperplane through the origin normal to $x^\star$. For any symmetric uncertainty set, that is **half** the realizations, for **any** $\rho > 0$. So the 50 % is a geometric identity, not a property of the data; it is the signature of a plan optimized onto a knife edge.

**20.1.2** Feasibility for every realization requires the worst case to satisfy the constraint:
$$\max_{\|u\|_2\le1}\big[(2,1)+\rho u\big]^\top x \le 100.$$
The inner maximization is $\max_{\|u\|\le1} u^\top x = \|x\|_2$ (a dot product over a ball is maximized by aligning $u$ with $x$; the maximizer is $u^\star = x/\|x\|_2$). Hence
$$(2,1)^\top x + \rho\,\|x\|_2 \le 100.$$
The robust counterpart of a linear constraint is the same constraint **plus a norm-sized safety margin that scales with the decision itself** — larger plans buy more margin, which is the mathematical form of "don't push as hard when you're not sure."
This is a second-order cone constraint, so the robust LP is an **SOCP** (§3.4): still convex, still globally solvable with a certificate, still handled by the same interior-point machinery. Robustness here costs *conservatism*, not tractability — a genuinely surprising and important fact.

**20.1.3**
```python
import numpy as np, cvxpy as cp
def solve_plan(rho, robust_R=False):
    x = cp.Variable(2, nonneg=True)
    cons = [np.array([2., 1.]) @ x + rho*cp.norm(x, 2) <= 100]
    cons += [x[0] + x[1] + rho*cp.norm(x, 2) <= 80] if robust_R else [x[0] + x[1] <= 80]
    cons += [x[0] <= 40]
    p = cp.Problem(cp.Maximize(40*x[0] + 30*x[1]), cons); p.solve()
    return p.value, x.value
for rr in (False, True):
    print("both rows robust" if rr else "machine row robust only")
    for rho in [0.0, 0.05, 0.1, 0.2]:
        v, xv = solve_plan(rho, rr)
        print(f"  rho={rho:4}: profit={v:8.2f}  plan=({xv[0]:5.2f},{xv[1]:5.2f})")
```

| $\rho$ | M robust only: profit, plan | both rows robust: profit, plan |
|---|---|---|
| 0.00 | 2600.00, $(20.00, 60.00)$ | 2600.00, $(20.00, 60.00)$ |
| 0.05 | 2567.28, $(16.73, 63.27)$ | 2509.42, $(20.00, 56.98)$ |
| 0.10 | 2531.90, $(13.19, 66.81)$ | 2426.62, $(20.00, 54.22)$ |
| 0.20 | 2449.59, $(4.96, 75.04)$ | 2280.51, $(20.00, 49.35)$ |

Robustifying **both** rows costs considerably more — at $\rho = 0.1$, profit falls to 2426.62 (a 6.7 % loss) versus 2531.90 (2.6 %) for the machine row alone. The plans explain why: with only the machine row uncertain, the optimizer *shifts toward mode 2* ($x_1$ falls from 20 to 13.2), because mode 1 consumes twice the machine time and is therefore where the machine-row uncertainty bites; the material row, being slack-free but certain, still permits a large total. When the material row is *also* uncertain, that escape route closes — total output must shrink instead, so $x_2$ falls from 60 to 54.2 while $x_1$ stays at 20. Robustness is cheap when the model has a *direction* to move in, and expensive when every direction is uncertain.

**20.1.4** *"The nominal plan (20, 60) earning \$2 600 has both the machine-hour and material constraints exactly tight. Because it sits precisely on those boundaries, once the machine-time coefficients wobble by a modest 5 % ($\rho = 0.1$), the plan **exceeds the available machine hours in 50 % of realizations** — one week in two, we blow the schedule. The robust plan (13.2, 66.8) earns \$2 531.90: we give up **\$68.10, or 2.6 % of profit**, and in exchange the machine-hour limit is respected in 0 % of 20 000 sampled realizations — and by construction in 100 % of the uncertainty set, not merely in the samples.*
*The comparison to make: is 2.6 % of profit — \$68 per period — worth less than the cost of overrunning the schedule every other period? That cost includes overtime, expedited material, late-delivery penalties, and the planning effort of replanning mid-period. If a single overrun costs more than \$136, robustness pays.*
*One reason the insurance is this cheap: the objective is nearly flat near the optimum, so a substantial retreat from the boundary costs little profit. That flatness is common, which is why robust solutions so often cost a few percent rather than tens of percent — and it is worth checking on any model before assuming robustness is unaffordable."*

## Solutions — 20.2 The toolbox beyond the ellipsoid

**20.2.1**
| | Robust optimization | Stochastic optimization |
|---|---|---|
| Assumes | parameters lie in a **bounded set** (box, ball, polytope); no distribution needed | parameters are **random with a known distribution** |
| Guarantees | feasibility for **every** realization in the set (a worst-case guarantee) | good **average** performance, or a chance constraint such as $\Pr[\text{violation}] \le 10^{-3}$ |
| Cost | tractable — box gives an LP, ellipsoid an SOCP; conservatism tunable via set size | generally harder; usually approximated by optimizing over sampled scenarios (sample average approximation) |
| Choose when | violating the constraint is expensive or unsafe, and distributions are unknown or untrustworthy | you genuinely know the distribution and care about expected performance, or the constraint may be violated occasionally at known cost |
In practice the choice often comes down to what you can defend: a bounded set ("loads never exceed the code value by more than 10 %") is far easier to justify than a specific distribution, which is why robust formulations dominate in engineering design and chance constraints dominate in finance and inventory.

**20.2.2** With $a_i = \bar a_i + \delta_i$, $|\delta_i| \le \rho_i$, robust feasibility requires
$$\max_{|\delta_i|\le\rho_i}\ \sum_i(\bar a_i + \delta_i)x_i \le b.$$
For $x \ge 0$ the worst case takes $\delta_i = +\rho_i$ for every $i$ (each term is increasing in $\delta_i$), so
$$\sum_i \bar a_i x_i + \sum_i \rho_i x_i \le b \quad\Longleftrightarrow\quad (\bar a + \rho)^\top x \le b.$$
(For general sign-free $x$ the margin is $\sum_i\rho_i|x_i| = \|\,\rho \odot x\,\|_1$, which is still LP-representable.) The result is **just another linear constraint**, so the robust problem remains an **LP** — even cheaper than the ellipsoidal case.
Conservatism: box uncertainty is **more conservative** than an ellipsoid of comparable radius, because it insists all coefficients hit their worst values *simultaneously*. Quantitatively the margins are $\|\rho\odot x\|_1$ versus $\rho\|x\|_2$, and $\|v\|_1 \ge \|v\|_2$, so the box margin is larger (by up to $\sqrt n$). The ellipsoid encodes the realistic assumption that independent errors partially cancel, which is why it is usually preferred despite needing an SOCP.

**20.2.3**
```python
import numpy as np, cvxpy as cp
x = cp.Variable(2, nonneg=True)
cons = [2*x[0] + x[1] <= 100, x[0] + x[1] <= 80, x[0] <= 40]
p = cp.Problem(cp.Maximize(40*x[0] + 30*x[1]), cons); p.solve()
x_nom = x.value
rng = np.random.default_rng(3)
U = rng.normal(size=(20000, 2))
U = U/np.linalg.norm(U, axis=1, keepdims=True)*np.sqrt(rng.random((20000, 1)))
for rho in (0.05, 0.1):
    lhs = (np.array([2., 1.]) + rho*U) @ x_nom
    print(f"rho={rho}: violation frequency {np.mean(lhs > 100 + 1e-9)*100:5.1f}%   "
          f"worst overrun {lhs.max()-100:6.3f} h   mean overrun (when violated) "
          f"{np.mean(lhs[lhs>100]-100):.3f} h")
```
Both $\rho = 0.05$ and $\rho = 0.1$ give a violation frequency of **50.0 %** — as 20.1.1 predicts, the frequency is independent of $\rho$ because the plan sits exactly on the boundary. What *does* scale with $\rho$ is the **severity**: the worst sampled overrun doubles from $3.16$ h at $\rho=0.05$ to $6.32$ h at $\rho=0.1$ (on a 100 h budget), and the mean overrun *given* a violation from $1.34$ h to $2.68$ h. That is the right pair of numbers to report — *how often* and *by how much* — because the second is what determines whether a violation is a rounding error or a shut-down.

**20.2.4** Both are "perturb and look" disciplines: change an input by a realistic amount, re-evaluate, and inspect what happens — rather than trusting a single computed number. The two-sided shadow-price test perturbs a right-hand side up *and* down and compares the two rates, because the value function may have a kink; the stress test perturbs the coefficients across their plausible range and checks feasibility and objective, because the optimum may sit on a knife edge.
**The general principle:** *optimized systems concentrate their sensitivity exactly where you pressed hardest.* An optimizer drives the design against its active constraints until no further improvement is possible; at that point the objective is (locally) flat in the feasible directions while feasibility is razor-thin in the constrained ones. So the most reliable quantity in an optimization output is often the objective value, and the least reliable are the things that depend on the active set staying put — the shadow prices, the identity of the binding constraints, and feasibility itself. Both tests exist to probe precisely that, and both cost two or three extra solves. Neither is optional on a model whose answer will be built.

## Solutions — 21.1 Choosing

**21.1.1** Start with the two questions of §1.5.
1. **Are all variables continuous?**
 - **Yes → 2.** **No (some integer/binary) → 4.**
2. **Is the problem convex?** (verified, not assumed)
 - **Yes:** identify the smallest class — LP, QP, SOCP, SDP (§3.4) — and use the matching solver through a modeling layer. Global optimum with a certificate.
 - **No → 3.**
3. **Are derivatives available and is $f$ smooth?**
 - **Yes:** gradient-based local method (BFGS/L-BFGS, SQP, interior point) **with multi-start**; report the spread of local optima. Use `least_squares` if the objective is a sum of squares (§8.1).
 - **No** (black box, nonsmooth, noisy): if evaluations are *expensive* → surrogate/Bayesian optimization (§18); if *cheap* → metaheuristic or direct search (§17).
4. **Integer variables present:** is it secretly a network/TU structure (§6)? If yes, drop integrality and solve the LP. Otherwise: linear → **MILP** via branch and bound (global, Part IV); convex nonlinear → convex MINLP; nonconvex nonlinear → global MINLP solver at modest size, else heuristics. If it has stages and a compact state, try **DP** first (§16).
**Three sanity notes:** (i) linear-plus-integer is still *globally* solvable — that is the point of Part IV, so integrality is not a reason to abandon exactness; (ii) "convex" should be *checked* properly via §3.3's composition rules or by letting CVXPY certify it, not assumed; (iii) a smooth nonconvex problem should get gradient methods with multi-start **before** it gets a metaheuristic.

**21.1.2** (a) **Gradient-based local NLP with multi-start** (SQP or interior point; IPOPT/`trust-constr`) — smooth, continuous, moderate size, nonconvex physics; and derive or AD the gradients (§12). (b) **MILP** — this is **set covering** (§13.4); 200 binaries is routine for branch and bound, and you get a proven optimum plus a gap. (c) **`least_squares`** (Levenberg–Marquardt, §8.1) — a sum of squares; also report standard errors and $\operatorname{cond}(J^\top J)$ for identifiability (§8.3). (d) **Gradient-based local with multi-start**, then compare the distinct local optima; a metaheuristic only if multi-start reveals genuinely rugged structure and the local method struggles — and note buckling constraints are smooth, so derivatives exist. (e) **Derivative-free**: the `if`-based saturation makes $f$ nonsmooth, so use a direct-search or metaheuristic method on 4 variables — but first ask whether the saturation can be *reformulated* smoothly or modelled with a binary (§2.2, §13.2), which would return the problem to a much better class.

**21.1.3** Because convexity is the single property that decides whether you get a certified global optimum or a candidate, and human judgment about it is unreliable in both directions — the composition rules of §3.3 are mechanical precisely because intuition fails. Assuming convexity wrongly means reporting "the optimum" when you have a local point; assuming nonconvexity wrongly means paying for multi-start or a metaheuristic when a solver would have proved optimality in milliseconds.
*Looks nonconvex but is convex:* $f(x) = -\log\big(1-\|x\|_2\big)$ on $\|x\|_2 < 1$ — a negative log of a nonlinear expression, yet convex (convex nonincreasing ∘ concave, §3.3.1c); likewise $\max\{f_1,\dots,f_k\}$ of convex pieces, which looks kinked and horrible but is convex, and geometric-programming models that become convex after a log transformation.
*Looks convex but is not:* $x^2 - |x|$ — a sum of two convex-looking terms, but convex minus convex follows no rule and it is genuinely nonconvex (the text's `UNKNOWN` example); likewise a nonlinear *equality* constraint such as $x_1x_2 = 10$, which many people accept because the individual expressions look tame, and any product or quotient of variables.

**21.1.4** The missing step is **gradient-based local optimization with multi-start** (and, before even that, checking convexity and looking for exploitable structure).
Cost comparison: on a smooth nonconvex problem with $n = 40$, one L-BFGS run from a random start typically needs $O(100)$ function-and-gradient evaluations to converge to a KKT point; 200 such starts cost $\sim2\times10^4$ evaluations and yield the best of 200 certified local optima *plus* a map of how many distinct basins exist. A GA on the same problem typically needs a population of 50–100 over hundreds of generations — $10^4$ to $10^5$ evaluations — to reach a comparable point, requires tuning (population, rates, penalty weights) that consumes further budget, provides no local optimality certificate, and returns a point that is usually slightly infeasible if constraints were penalized. So multi-start is cheaper, more accurate, tuning-free, and more informative — and §17.4's honest-baseline requirement exists precisely because published comparisons often omit it. The GA becomes defensible only when the objective is genuinely nonsmooth or black-box, which is a *diagnosis* (§12.1, §17.1), not a default.

## Solutions — 21.2 Diagnosing the three bad outcomes

**21.2.1** (1) **Check units and signs first** — a mismatched unit or a flipped inequality causes most infeasibilities, and both are free to find. (2) **Make the suspect constraints soft** (§2.2) and minimize total violation, converting a status code into a quantitative diagnosis: *which* constraint, and *by how much*. (3) **Consider that the model may be right** — the specification may be genuinely impossible, and discovering that early, with a number attached, is among the most valuable outputs optimization produces.
"Start deleting constraints" is absent because it destroys the information you need: deletion tells you only that *some* subset was contradictory, not which requirement is binding nor by how much, and it leaves you with a model that no longer represents the problem. It also invites the worst outcome — deleting a real physical or safety constraint to make the solver stop complaining, thereby producing an answer that is feasible only in the model.

**21.2.2**
```python
from scipy.optimize import linprog
# hard: x1<=50, x2<=40, x3<=20, x1+x2+x3 >= 120
r = linprog([0,0,0], A_ub=[[-1,-1,-1],[1,0,0],[0,1,0],[0,0,1]], b_ub=[-120,50,40,20],
            bounds=[(0,None)]*3, method="highs")
print("hard model:", r.message.split(".")[0])
# soft: x1+x2+x3+s >= 120, minimize s
r2 = linprog([0,0,0,1], A_ub=[[-1,-1,-1,-1],[1,0,0,0],[0,1,0,0],[0,0,1,0]],
             b_ub=[-120,50,40,20], bounds=[(0,None)]*4, method="highs")
print(f"soft model: minimum violation s = {r2.x[3]:.0f} at x = "
      f"({r2.x[0]:.0f}, {r2.x[1]:.0f}, {r2.x[2]:.0f})")
```
Output: the hard model reports **infeasible**; the soft model gives **minimum violation $s = 10$** at $x = (50,\ 40,\ 20)$ — every line at capacity.
Meeting-ready sentence: *"All three lines at full capacity produce 110 units against a demand of 120 — we are short by exactly 10 units. Either raise capacity somewhere by 10, or reduce the committed demand by 10; there is no scheduling fix."* Compare "the problem is infeasible," which supports no decision at all.

**21.2.3** **Unbounded:** the solver reports a **ray** — a feasible direction along which the objective improves without limit. Use it by looking at which components are nonzero: those are the variables running away, and for each you ask *what physically limits this?* The answer is the missing constraint or bound (§1.3). It is almost always a forgotten capacity, a missing nonnegativity, or a sign error in the objective.
**Converged to nonsense:** look first at (i) the **active set** — which constraints bind, and does that story make physical sense (§1.4)? — and (ii) any **variable sitting exactly on an artificial bound**, because that bound is doing design work it should not be doing (the pressure vessel's §10.3 is the worked instance). Then ask what physical limit the optimizer has exploited, and add it.
It is the most dangerous outcome because it **looks like success**: the solver reports convergence, the KKT residuals are small, and the number is precise. Infeasible and unbounded announce themselves; nonsense arrives with a status code of 0 and can propagate into a design review, a drawing, and a built object before anyone checks. The framing from §2.1 is the antidote: the optimizer is a ruthless search for loopholes in your model, and every absurd answer is a loophole report.

**21.2.4** **Irreducible infeasible subsystem (IIS)** analysis — also called an irreducible inconsistent subsystem — returns a **minimal subset of constraints (and bounds) that is itself infeasible**, minimal in the sense that removing any one member makes the subset feasible. Most commercial solvers and several open ones compute it on request.
Contrast: an IIS answers *"which constraints contradict each other?"* — a **structural** answer naming a small set you can inspect line by line. The minimum-violation (soft-constraint) approach answers *"how far off are we, and where?"* — a **quantitative** answer giving the size of the shortfall in engineering units.
Prefer the **IIS** when the infeasibility is probably a modelling error and the model is large: with 40 000 constraints, an IIS of four rows immediately localizes a unit error or a typo that no amount of violation-minimizing would pinpoint. Prefer **minimum violation** when the model is probably right and the *specification* is in question: it produces the negotiable number ("short by exactly 10 units," "the deflection limit must move from 5 mm to 6.4 mm") that a design review can act on. In practice they are complementary — run the IIS to find the culprit constraints, then soften exactly those to price the repair.

## Solutions — 21.3 Verifying an answer

**21.3.1**
1. **Read the active set** — does the physical story match expectation? (§1.4, §4.2)
2. **Check units and orders of magnitude** of the objective and every multiplier. (§2.3, §5.1)
3. **Look for artificial bounds** — a variable pinned at a bound you invented means the true optimum lies outside your box. (§10.3)
4. **Solve a simplified case with a known analytic answer** and confirm the model reproduces it. (§10.1 vs §10.2)
5. **Perturb and re-solve** — small input changes should give small output changes. (§20.2, §5.6)
6. **Two-sided shadow-price test** on any multiplier that will drive a real decision. (§5.8, §9.4)
7. **Multi-start** on any nonconvex problem; report how many distinct local optima appeared. (§9.6, §8.3)
8. **Read the multipliers** — free sensitivity information showing where the cost lives. (§5.4, §9.4, §10.4)

**21.3.2** Actions and what each tells me:
- **Active set (step 1):** $\Delta T_{\min}$ active on three matches says the network is *driving-force limited*, not area limited — a coherent and expected story for heat integration. Good sign.
- **Artificial bound (step 3):** the exchanger at exactly 500 m² is the flag to chase first. Is 500 m² a real limit (largest shell available, plot-space constraint, code limit) or a number someone typed? If it is not physical, the reported optimum is my own assumption echoed back, and I must widen the bound and re-solve. I would also read its multiplier to price it.
- **Units (step 2):** confirm \$41 000 per K is per *kelvin of $\Delta T_{\min}$*, and sanity-check the magnitude: a 1 K relaxation saving \$41 k on a \$1.24 M network is 3.3 % — plausible, but worth a hand estimate from the utility cost and the total duty.
- **Two-sided test (step 6):** re-solve at $\Delta T_{\min} \pm 1$ K and compare the one-sided rates. Three matches becoming active simultaneously is a classic degeneracy signature, so the reported \$41 000/K may be one of several valid subgradients — and this multiplier is exactly the kind that drives a real decision (whether to buy more area to relax $\Delta T_{\min}$).
- **Perturb and re-solve (step 5):** vary utility prices and stream duties by $\pm10\%$; if the *set of matches* changes, the network topology is fragile and that must be reported, since topology is not something you can adjust later.
- **Simplified case (step 4):** check a two-stream sub-problem against a hand pinch analysis.
- **Multi-start (step 7):** heat-exchanger network synthesis is nonconvex; run from several starts and report how many distinct topologies of comparable cost appear.
- **Multipliers (step 8):** rank all constraints by multiplier to see where the cost actually lives before recommending anything.

**21.3.3**
```python
import numpy as np, cvxpy as cp

def perturb_and_resolve(solve_fn, nominal, fractions=(-0.05, 0.0, 0.05)):
    """solve_fn(params) -> (objective, active_set_tuple)"""
    base_obj, base_active = solve_fn(nominal)
    rows = []
    for fs in np.array(np.meshgrid(*[fractions]*len(nominal))).T.reshape(-1, len(nominal)):
        p = np.asarray(nominal, float)*(1 + fs)
        obj, active = solve_fn(p)
        rows.append((tuple(np.round(fs, 3)), obj, active, active != base_active))
    objs = [r[1] for r in rows]
    print(f"nominal objective {base_obj:.2f}, active set {base_active}")
    print(f"objective range over perturbations: [{min(objs):.2f}, {max(objs):.2f}]"
          f"  ({(max(objs)-min(objs))/base_obj*100:.1f}% spread)")
    print(f"active set changed in {sum(r[3] for r in rows)} of {len(rows)} cases")
    return rows

def solve_ex1(b):
    x = cp.Variable(2, nonneg=True)
    lhs = [lambda v: 2*v[0] + v[1], lambda v: v[0] + v[1], lambda v: v[0]]
    rhs = [b[0], b[1], 40.0]
    cons = [L(x) <= R for L, R in zip(lhs, rhs)]
    p = cp.Problem(cp.Maximize(40*x[0] + 30*x[1]), cons); p.solve(solver=cp.HIGHS)
    xv = x.value
    active = tuple(k for k, (L, R) in enumerate(zip(lhs, rhs)) if abs(L(xv) - R) < 1e-6)
    return p.value, active

perturb_and_resolve(solve_ex1, [100.0, 80.0])
```
On Worked Example 1 the objective moves smoothly over roughly $\pm5\%$ (2 470–2 730) and the active set stays $\{M, R\}$ throughout — a *stable* optimum, which is the reassuring outcome. (Contrast §5.8's degenerate example, where a $\pm5\%$ perturbation changes which constraints bind and therefore which prices are valid.) The function is worth keeping: "did the active set change?" is a more informative robustness measure than the objective spread, because a changed active set means the *engineering story* changed, not just the number.

**21.3.4** **Evidence versus proof.** Multi-start explores a finite sample of starting points; each run converges to a local minimum in whose basin its start happened to lie. If 200 starts all reach the same point, that point's basin is large relative to the sampled region — genuine information, and a reasonable basis for proceeding. But it is compatible with a better optimum sitting in a small basin that no start happened to hit, and no number of starts closes that gap: the argument is inductive, over a set you sampled rather than a set you covered. (§9.5's framing: multi-start produces feasible points only, hence upper bounds only, hence no certificate.)
**What would constitute proof:** (i) **convexity** — verify the problem is convex (§3.3, or let CVXPY certify it), after which any local solution is global and the KKT conditions suffice (§3.2, §9.3); (ii) a **global solver** for the problem class — BARON, ANTIGONE, SCIP, Couenne — which maintains a rigorous *lower* bound by relaxation and branching and terminates with a gap, exactly as branch and bound does for MILP; (iii) a **problem-specific bound** — a Lagrangian relaxation, an LP relaxation of a discretized version, or an analytical bound from physics — which turns "best found" into "within $x\%$ of optimal." In each case the proof arrives by the same mechanism: an object that says something about *all* solutions at once, which sampling can never supply.

## Solutions — 21.4 Twelve things that go wrong most often

**21.4.1**
- **Scaling:** items 1 (variables/constraints not $O(1)$, hence huge $\kappa$) and 8 (big-Ms orders of magnitude too large) — and arguably 11, since the finite-difference step rule is a scaling calculation.
- **Modelling:** items 2 (bounds written as general constraints), 3 (missing constraint), 4 (wrong objective), 5 (wrong physics), 6 (hunting $\nabla f=0$ when the optimum is on a bound), 10 (trusting one shadow price under degeneracy).
- **Method choice:** items 7 (rounding a relaxation), 9 (integers on a network-flow problem), 12 (metaheuristic on structured problems) — and 11 (finite differences on a noisy simulation) sits between method choice and numerics.
**Modelling is much the largest category**, which is the course's central claim made statistically: most optimization failures are not algorithmic. The learning effort should therefore go into formulation — the §2.1 loop, units, active sets, reading multipliers, recognizing structure (§1.5, §3.3, §6) — rather than into algorithm internals. You will change solvers rarely and models daily.

**21.4.2** (a) **Item 1 (scaling)** or a wrong gradient (item 11's cousin). *Check:* print the magnitudes of variables, gradient components and constraint residuals — if they span more than a few orders of magnitude, rescale; and central-difference-check the gradient at a generic point. (b) **Item 8 (big-M too large).** *Check:* for every $x \le My$, ask what physical quantity $M$ is; recompute the relaxed $y = x/M$ by hand and see how much of the fixed cost survives (§13.3). (c) **Item 3 (missing constraint)**, specifically buckling or a minimum-gauge bound. *Check:* evaluate the neglected physics at the returned design — compute the Euler buckling load of the most loaded member and compare with its axial force. (d) **Item 10 (degeneracy).** *Check:* count active constraints against variables, and run the two-sided perturbation test at the *actual* investment size (§5.8). (e) **Item 9 (integers on a network).** *Check:* is the constraint matrix an assignment/incidence structure? Drop `boolean=True`, solve the LP, and see whether the answer comes back integral (§6.2.4). (f) **Item 11 (finite differences on a noisy simulation).** *Check:* estimate the simulation's noise floor from repeated evaluations at the same point; the best achievable gradient accuracy is $\sqrt{\text{noise}}$ (§12.1.3) — if that is worse than a few digits, go to derivatives from AD/adjoints or to Part V.

**21.4.3** Items **3** (missing constraint, revealed by an absurd or unbounded answer), **4** (wrong objective), **5** (wrong physics), **6** (optimum on a bound), and **10** (single shadow price under degeneracy) all share the same root cause: the answer was accepted without being interrogated. Item **7** (rounding) belongs here too, since a glance at feasibility would expose it.
The habit that catches all of them: **step 5 of the modelling loop (§2.1) — interrogate every answer before reading its objective value.** Concretely, run the `interrogate` routine of §2.1.4 on every solve: print the objective, every constraint value with its active/inactive status, every variable sitting on a bound, and every multiplier — then ask whether the resulting *story* is physically sensible. Two minutes, and it converts five of the twelve most common failures from silent to obvious.

**21.4.4** A defensible six-item pre-flight list, ordered by *probability of catching a serious error per minute spent*:
1. **Are the units and magnitudes right?** Objective, variables, constraint residuals and multipliers all within a few orders of magnitude of 1 (§2.3). Cheapest check, catches the largest single failure category, and makes every subsequent test meaningful (tolerances mean nothing at the wrong scale).
2. **What is the active set, and does the physical story make sense?** (§1.4) Before the objective value. This is what tells you *why* the design is what it is, and it exposes missing constraints and wrong physics.
3. **Is any variable pinned at a bound I invented?** (§10.3) If yes, that bound — not the optimization — determined the answer, and it needs a documented physical source.
4. **Does the gradient (or derivative source) check out, and is the problem the class I think it is?** Central-difference-check any hand-derived gradient (§0.1, §12.1); confirm convexity via CVXPY or the §3.3 rules rather than assuming it. This determines whether the answer is global or merely local.
5. **Do the multipliers survive a two-sided perturbation, and does the answer survive perturbed inputs?** (§5.8, §20.2) Any number that will drive a decision must be tested both ways; and the active set must not change under realistic input variation, or the engineering story is fragile.
6. **What is my quality statement?** For convex/MILP: the certificate or the MIP gap (§14.3). For nonconvex: how many starts, how many distinct optima, and an explicit "no lower bound available" (§17.5). Last because it is a *reporting* obligation rather than a search for errors — but non-negotiable, because an answer without a quality statement is not a result.

## Solutions — 22. The software landscape

**22.1** A **modeling layer** sits between you and the solver: you write the model in near-mathematical notation (variables, constraints, objective, index sets), and the layer translates it into whatever form the chosen solver requires. Examples: CVXPY (convex, with convexity *verified* by the DCP rules of §3.3), Pyomo (general LP/NLP/MILP/MINLP), JuMP, AMPL, GAMS.
Two benefits the text emphasizes: (i) the model **reads like the mathematics**, so it can be reviewed by another human and checked against the formulation — which matters because most errors are modelling errors (§21.4); (ii) you can **swap solvers without rewriting**, which is both a practical hedge (licences expire, solvers have different strengths) and a *diagnostic*: re-solving the same model with a different solver is the fastest way to find out whether a bad answer is your model's fault or the solver's.
Why learn the layer rather than the API: **models outlive solvers.** A model expressed in Pyomo or CVXPY survives licence changes, vendor changes and algorithmic fashion; a model written against `gurobipy` is coupled to one product's calling conventions, and porting it means re-deriving the formulation from code.

**22.2** (a) **HiGHS** (via `scipy.optimize.linprog`, CVXPY or Pyomo) — a mature open-source LP/MILP engine that handles large sparse LPs with both simplex and interior point (§4.3). (b) **CVXPY** with Clarabel/SCS/ECOS or MOSEK — CVXPY recognizes the cone structure automatically and certifies convexity, which is exactly what a robust counterpart needs (§20.1). (c) **IPOPT via Pyomo** — the workhorse interior-point code for large sparse nonlinear problems, including PDE-constrained ones (§9.6). (d) **BARON or SCIP/Couenne** — global MINLP solvers; expect modest sizes and help them with tight variable bounds. (e) **JAX, PyTorch, or an adjoint method** — reverse-mode AD gives the whole 10 000-component gradient for roughly the cost of one extra evaluation (§12.3). (f) **CasADi** — built specifically for optimization and optimal control, with AD and NLP-solver interfaces integrated, so the discretized control problem is expressed once and differentiated exactly.

**22.3** Measure on **your own instances**, not on public benchmarks. Specifically: take 10–20 representative models from your actual work, and for each record, at a fixed time limit, (i) the **MIP gap reached**, (ii) the **time to first good incumbent**, and (iii) the **time to prove optimality** where achievable. Then compare open (HiGHS, SCIP) against a commercial trial (Gurobi, CPLEX, Xpress) at identical formulations and identical gap tolerances.
Two further things to measure before concluding: **how much of the gap is your formulation's fault** — tighten the big-Ms, add symmetry breaking and bounds (§14.4), and re-run both, because a formulation fix often exceeds the solver difference; and the **variance across instances**, since a licence is worth buying only if the advantage is consistent on the models you actually solve. Finally, cost it out: licence price against the value of the decisions the improvement enables — if a 1 % better schedule saves \$200 k/year, the licence is trivially justified; if you solve three models a month at a 0.2 % gap already, it is not.

**22.4** **Migration:** re-express the model in a modeling layer — **Pyomo** for a general LP/MILP/NLP, **CVXPY** if it is convex — working from the *mathematics* rather than translating API calls line by line. Steps: (1) write down the formulation (index sets, variables with units and bounds, constraints, objective) from the existing code, which doubles as the documentation that was probably never written; (2) implement it in the layer and solve with the vendor solver still available, verifying that objective value, solution and multipliers match the legacy model to tolerance — this is the regression test, and it must pass before the licence lapses; (3) re-solve the identical model with an open solver (HiGHS, SCIP, IPOPT) and record any difference in answer, run time and gap; (4) fix any formulation weaknesses the comparison exposes (§14.4, §15.2), since a tighter model narrows the open-versus-commercial gap; (5) keep the layer's solver selection as a configuration option, not a code change.
**The property that makes it worthwhile: solver independence.** Because the layer separates the model from the solver, step 3 costs one line — and thereafter you can benchmark solvers, survive licence changes, and use solver disagreement as a diagnostic (if two independent solvers return different answers, the model is ill-posed or badly scaled, not the solvers). That is the same "two independent routes to the same answer" discipline the course applies to every worked example.
