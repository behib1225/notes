# Applied Optimization for Engineers
### A self-study course: formulation, linear programming, nonlinear programming, discrete optimization, and heuristics — with Python

*Complete edition — all six parts, thirteen worked examples, all code verified.*

---

## Preface

**Who this is for.** Undergraduate engineering students in any discipline, working alone, over roughly one term. It assumes multivariable calculus (partial derivatives, the chain rule), basic linear algebra (matrices, eigenvalues), and introductory Python. Chapter 0 refreshes exactly the pieces of calculus and linear algebra that optimization uses, so you do not need those courses fresh in your mind — only somewhere in it.

**What it is for.** Optimization has a beautiful theory and a separate practical skill. Courses teach the theory; industry needs the skill. This course carries just enough theory to make the practice honest, and spends its effort on *formulation, computation, interpretation, and diagnosis* — the parts that actually determine whether your answer is useful.

**How this course teaches: hand first, then machine.** Every worked example is solved twice.

1. **By hand**, completely, with every number shown — so you understand *why* the answer is what it is.
2. **In Python**, with short, self-contained scripts — so you can solve the same class of problem when it has 200 variables instead of 2.

The hand calculation is your understanding; the code is your capability; and their agreement is your error check. When you later solve your own problems, you will not have a solution to compare against — but you *will* have the habits this course drills: check the numbers two ways, read the active constraints, interrogate the multipliers, perturb and re-solve.

**How to study it.**

- **Do not read the worked examples — redo them.** Cover the solution, work it yourself on paper, compare. Then type in the code (or download it), run it, and confirm it reproduces your hand result. That loop is the whole study method.
- Each Part ends with a **Checkpoint** ("what you should now be able to do") and a short **Self-test** with full answers. If a self-test item is hard, the item tells you which section to re-study.
- Parts I–II are prerequisites for everything else. Within Parts III–V the chapters are largely independent.

**Suggested pacing for a 13-week term.**

| Weeks | Material |
|---|---|
| 1–2 | Chapter 0 and Part I (foundations, modeling, convexity) |
| 3–5 | Part II (LP, duality and sensitivity, networks) |
| 6–8 | Part III (unconstrained and constrained nonlinear optimization, least squares) |
| 9–11 | Part IV (integer programming, branch and bound, cuts, dynamic programming) |
| 12 | Part V (heuristics, surrogate/Bayesian optimization) |
| 13 | Part VI (multi-objective, uncertainty, diagnosis and verification) |

**The Python environment.** Everything runs on free, open-source libraries:

```bash
pip install numpy scipy matplotlib cvxpy pyomo highspy
```

- **NumPy / SciPy** — arrays, linear algebra, and `scipy.optimize` (which includes the excellent open-source LP/MILP solver **HiGHS**).
- **CVXPY** — a *modeling layer* for convex optimization: you type the mathematics almost verbatim, and it verifies convexity for you before solving. We use it heavily in Parts I–II.
- **Pyomo + HiGHS** — a general modeling layer, used in Part IV for mixed-integer models (and the route to industrial NLP solvers such as IPOPT).
- **Matplotlib** — every figure in this course was generated with it, and the plotting scripts are part of the course material.

Test your installation now:

```python
import numpy, scipy, cvxpy
print(numpy.__version__, scipy.__version__, cvxpy.__version__)
```

If that prints three version numbers, you are ready.

**Index of worked examples.**

| # | Problem | Where | The lesson it exists to teach |
|---|---|---|---|
| 1 | Two-resource allocation LP | §4.2, §5.4–5.7 | Vertex optima; duals as prices; sensitivity ranges |
| 2 | A degenerate LP | §5.8 | Shadow prices are *not always unique* |
| 3 | 3×3 assignment | §6.2 | Some integer problems are free — no branching needed |
| 4 | Steepest descent on a stretched bowl | Part III | Conditioning controls cost, exactly and predictably |
| 5 | Fitting a step-response model (nonlinear least squares) | Part III | Identifiability; when the data cannot answer the question |
| 6 | Minimum-material pressure vessel | Part III | Correct physics changes the answer; optima at bounds |
| 7 | Constrained design by SQP and interior point | Part III | What a constrained solver actually does, iteration by iteration |
| 8 | Fixed-cost facility (the big-M trap) | Part IV | A loose big-M destroys the bound — quantified |
| 9 | Small integer program | Part IV | Branch and bound; why rounding fails |
| 10 | One cutting plane | Part IV | A single cut can solve the whole problem |
| 11 | Shortest path | Part IV | Bellman's principle; DP beats enumeration |
| 12 | 4-item knapsack | Part V | Local optima are real; neighborhood design matters |
| 13 | A robust LP | Part VI | The price of robustness, computed |

**Three traps this course insists on** that many introductions skip: shadow prices can be non-unique (§5.8), integrality is sometimes free (§6), and the "obvious" formulation of a classic design problem can be physically wrong in a way that changes the optimum entirely (Part III). Each is a trap that students — and practicing engineers — reliably fall into.

**Exercises.** Every section ends with an **Exercises** block — 363 in total, three to five per section. Each is tagged by what it asks of you:

| Tag | Type | What it asks of you |
|---|---|---|
| **[C]** | Conceptual / short answer | State, explain, distinguish, or correct a claim in words |
| **[H]** | By-hand computation & derivation | Derive, solve, or verify with pencil and paper |
| **[P]** | Python / coding | Write and run code |
| **[M]** | Modeling & interpret-the-output | Build a model, or read a solver's answer as engineering |

A balanced diet of all four is the point: the [C] items check that you can say what you know, the [H] items are where understanding actually forms, the [P] items build the verification habit this course is organized around, and the [M] items are the ones your job will consist of.

Complete solutions to all of them are in the companion file **`Applied_Optimization_Solutions.md`**, keyed by section number (exercise 5.6.2 belongs to §5.6). Every numerical answer in that file was produced by *running* the code shown, so if your output differs, the discrepancy is worth chasing — that is the same discipline the worked examples model throughout.

Several exercises deliberately reuse one problem across a whole chapter, as the worked examples do: the **Exercise LP (E)** introduced in §4.2 is carried through §5.8, and the **Exercise MILP (F)** introduced in §13.1 is carried through §15.2. Working them in order is worth more than sampling.

---

## Notation

| Symbol | Meaning |
|---|---|
| $x \in \mathbb{R}^n$ | decision variables — the quantities you choose |
| $f(x)$ | objective function (scalar), to be minimized |
| $g_i(x) \le 0$ | inequality constraints, $i = 1,\dots,m$ |
| $h_j(x) = 0$ | equality constraints, $j = 1,\dots,p$ |
| $\nabla f$, $\nabla^2 f$ | gradient (vector of $\partial f/\partial x_k$); Hessian (matrix of $\partial^2 f/\partial x_k\,\partial x_l$) |
| $\mathcal{F}$ | feasible set: all $x$ satisfying every constraint |
| $x^\star, f^\star$ | optimal point, optimal value |
| $\mu_i \ge 0$, $\lambda_j$ | Lagrange multipliers for inequalities, equalities |
| $y_i$ | LP dual variable (the same object as $\mu_i$) |
| $A \succeq 0$ | $A$ is symmetric positive semidefinite (all eigenvalues $\ge 0$) |
| $\kappa$ | condition number; for symmetric positive definite $A$, $\lambda_{\max}/\lambda_{\min}$ |
| $\lfloor a \rfloor$ | largest integer $\le a$ |

Two conventions used everywhere:

1. **Everything is a minimization.** Maximizing $f$ is minimizing $-f$: the same $x^\star$, and $f^\star_{\max} = -f^\star_{\min}$. (The LP chapters keep maximization where it reads more naturally, and flip signs explicitly.)
2. **Inequalities point one way:** $\le 0$. Rewrite $g(x) \ge b$ as $b - g(x) \le 0$.

---
---

# CHAPTER 0 — The mathematics you need, refreshed

This chapter contains no optimization. It contains the four mathematical facts that all of optimization is built on, stated in the form we will actually use them. If they are all familiar, skim the boxed statements and move on; if any is rusty, spend the twenty minutes here — it will repay itself many times.

## 0.1 The gradient: the direction things get worse fastest

For a scalar function of several variables, $f : \mathbb{R}^n \to \mathbb{R}$, the **gradient** collects the partial derivatives into a vector:

$$\nabla f(x) = \begin{pmatrix} \partial f/\partial x_1 \\ \vdots \\ \partial f/\partial x_n \end{pmatrix}.$$

The single fact to internalize:

> **At any point $x$, the gradient $\nabla f(x)$ points in the direction of steepest *increase* of $f$, and its negative $-\nabla f(x)$ points in the direction of steepest *decrease*. The gradient is perpendicular to the level set (contour) of $f$ through $x$.**

Why: for a small step $d$, the change in $f$ is approximately the dot product $\nabla f(x)^\top d$. Among all steps of the same length, the dot product is largest when $d$ is parallel to $\nabla f$, most negative when antiparallel, and zero when perpendicular — and "the change in $f$ is zero" is exactly what it means to move along a contour.

Optimization algorithms are, at heart, machines for exploiting this fact: they compute $\nabla f$, step in a direction that has a negative dot product with it (a *descent direction*), and repeat.

**Worked micro-example.** For $f(x_1, x_2) = x_1^2 + 3x_1 x_2$, the gradient is $\nabla f = (2x_1 + 3x_2,\; 3x_1)$. At the point $(1, 2)$: $\nabla f = (8, 3)$. Moving in direction $(-8, -3)$ (suitably scaled) decreases $f$ fastest; moving in direction $(3, -8)$ or $(-3, 8)$ — perpendicular — leaves $f$ unchanged to first order.

```python
import numpy as np

f = lambda x: x[0]**2 + 3*x[0]*x[1]
grad = lambda x: np.array([2*x[0] + 3*x[1], 3*x[0]])

x0 = np.array([1.0, 2.0])
g = grad(x0)                       # (8, 3)
eps = 1e-3
print("f at x0:                 ", f(x0))
print("step along -grad:        ", f(x0 - eps*g/np.linalg.norm(g)))   # decreases
print("step along +grad:        ", f(x0 + eps*g/np.linalg.norm(g)))   # increases
print("step perpendicular:      ", f(x0 + eps*np.array([3,-8])/np.linalg.norm([3,-8])))  # ~unchanged
```

Expected output (your last digits may differ):

```
f at x0:                  7.0
step along -grad:         6.991457...
step along +grad:         7.008545...
step perpendicular:       6.999999...   (unchanged to first order)
```

This three-line experiment — evaluate, step, compare — is also how you will *verify* every gradient you ever derive by hand. Get in the habit now.

---

#### Exercises

**0.1.1 [H]** For $f(x_1,x_2) = x_1^2 + 3x_1x_2$, evaluate $\nabla f$ at $(2,-1)$. Then write (a) a **unit** vector pointing in the direction of steepest decrease, and (b) a unit vector along which $f$ does not change to first order.

**0.1.2 [H]** Let $f(x_1,x_2) = x_1 e^{x_2} + x_2^2$. Compute $\nabla f(1,0)$ by hand. Use the first-order model to *predict* the change in $f$ for the step $d = (-0.01,\,-0.01)$, then compute the exact change. How large is the discrepancy, and what order in $\|d\|$ should it be?

**0.1.3 [P]** Write a reusable function `grad_check(f, grad, x, h=1e-6)` that compares an analytic gradient against central differences $\big(f(x+he_k)-f(x-he_k)\big)/(2h)$ and returns the largest absolute discrepancy. Test it on 0.1.2, and then on the *deliberately wrong* gradient $\nabla f = (e^{x_2},\; x_1e^{x_2})$ (the $2x_2$ term dropped). Confirm the checker catches the error at $(1,2)$ but *not* at $(1,0)$ — and explain why.

**0.1.4 [C]** A classmate writes: "$-\nabla f(x)$ points toward the minimum." Give a one-sentence correction and a concrete example where following $-\nabla f$ initially moves *away* from the minimizer.


## 0.2 Taylor expansion: the local models every algorithm uses

Optimization algorithms never see your whole function. At each iterate they see a *local model* built from derivatives at the current point, and Taylor's theorem says what those models are. For $f$ smooth and a step $d$:

$$f(x + d) \;\approx\; \underbrace{f(x) + \nabla f(x)^\top d}_{\text{1st-order (linear) model}} \;\approx\; \underbrace{f(x) + \nabla f(x)^\top d + \tfrac{1}{2}\, d^\top \nabla^2 f(x)\, d}_{\text{2nd-order (quadratic) model}}.$$

Here $\nabla^2 f(x)$ is the **Hessian**, the symmetric $n \times n$ matrix of second partial derivatives $\partial^2 f / \partial x_k \partial x_l$. The linear model is a tilted plane through the point; the quadratic model adds curvature.

![Taylor models](figures/fig0_taylor.png)

*Figure 0.1 — A function (blue), its first-order model (dashed), and its second-order model (dotted) at the point $x_0$. Near $x_0$ both models are excellent; far away, both can be badly wrong. Every algorithm in this course is a strategy for using these models while respecting their limited range of validity.*

Two consequences we will use constantly:

- **First-order methods** (steepest descent and relatives) trust only the linear model. Cheap per step, but the linear model contains no information about curvature, and that ignorance has an exactly quantifiable price (Part III).
- **Second-order methods** (Newton and relatives) trust the quadratic model, which they can minimize in one algebraic step. Far fewer iterations, at the cost of computing or approximating the Hessian.

---

#### Exercises

**0.2.1 [H]** For $f(x_1,x_2) = x_1^2 + 2x_1x_2 + 3x_2^2 - x_1$, write $\nabla f$ and $\nabla^2 f$. At $x_0 = (1,1)$, evaluate the second-order model at the step $d = (0.1,-0.1)$ and compare with the exact $f(x_0 + d)$. Explain the result you get.

**0.2.2 [C]** Newton's method minimizes the quadratic model at each step. Using your answer to 0.2.1, state exactly how many iterations Newton's method needs on *any* convex quadratic, from *any* starting point, and why.

**0.2.3 [P]** For $f(x) = e^x$ at $x_0 = 0$, compute the errors of the first- and second-order Taylor models at steps $h = 10^{-1}, 10^{-2}, \dots, 10^{-6}$. Verify that the errors scale as $h^2$ and $h^3$ by fitting slopes on a log–log scale — and explain what happens to the second-order error for $h \le 10^{-5}$.

**0.2.4 [M]** Both Taylor models are only accurate near $x_0$, yet every algorithm in this course minimizes such a model to choose its next step. Name the two families of safeguards that keep an algorithm from trusting the model too far, and say in one sentence what each one limits.


## 0.3 Positive definiteness: what "curves upward in every direction" means

A symmetric matrix $A$ is

- **positive definite** ($A \succ 0$) if $d^\top A\, d > 0$ for every nonzero direction $d$ — equivalently, **all eigenvalues are strictly positive**;
- **positive semidefinite** ($A \succeq 0$) if $d^\top A\, d \ge 0$ for every $d$ — all eigenvalues $\ge 0$;
- **indefinite** if $d^\top A\, d$ is positive for some directions and negative for others — mixed-sign eigenvalues.

Why we care: in the quadratic Taylor model, the term $\tfrac12 d^\top \nabla^2 f\, d$ is what happens *after* the linear term is dealt with. If the Hessian is positive definite, the function curves upward whichever way you step — a **bowl**. Mixed signs give a **saddle**: up in some directions, down in others. All negative gives a **dome**.

![Quadratic forms](figures/fig0_quadratic_forms.png)

*Figure 0.2 — Contours of $\tfrac12 x^\top Q x$ for three matrices $Q$. Eigenvalue signs are the shape of the landscape near a stationary point, and Chapter 7 (Part III) turns this picture into the classification of minima, maxima, and saddles.*

**How to check in practice:** compute the eigenvalues.

```python
import numpy as np

for Q, name in [(np.array([[2., 0.], [0., 1.]]), "bowl"),
                (np.array([[2., 0.], [0., -1.]]), "saddle"),
                (np.array([[4., 2.], [2., 1.]]), "semidefinite (a trough)")]:
    print(f"{name:24s} eigenvalues: {np.linalg.eigvalsh(Q)}")
```

```
bowl                     eigenvalues: [1. 2.]
saddle                   eigenvalues: [-1.  2.]
semidefinite (a trough)  eigenvalues: [0. 5.]
```

Note the third case: one eigenvalue exactly zero. The quadratic $\tfrac12 x^\top Q x$ is then flat along one direction — a trough with a flat bottom, not a bowl. "Semidefinite" is the boundary case, and it will matter when we discuss when optimality conditions are *inconclusive*.

---

#### Exercises

**0.3.1 [H]** Classify each symmetric matrix as positive definite, positive semidefinite (but not definite), negative definite, or indefinite, using only the trace/determinant shortcut for $2\times2$ matrices:
(a) $\begin{pmatrix}4&1\\1&3\end{pmatrix}$, (b) $\begin{pmatrix}1&2\\2&4\end{pmatrix}$, (c) $\begin{pmatrix}1&3\\3&1\end{pmatrix}$, (d) $\begin{pmatrix}-2&0\\0&-5\end{pmatrix}$.

**0.3.2 [H]** For the matrix in 0.3.1(c), exhibit one direction $d$ with $d^\top A d > 0$ and one with $d^\top A d < 0$, and report both values.

**0.3.3 [C]** A student proposes the test: "all diagonal entries positive $\Rightarrow$ positive definite." Disprove it with a $2\times2$ counterexample. Then state the correct $2\times2$ test in terms of $a_{11}$ and $\det A$.

**0.3.4 [P]** Write `classify(A)` that returns the string `"PD"`, `"PSD"`, `"ND"`, `"NSD"`, or `"indefinite"` from `np.linalg.eigvalsh`, using a tolerance of $10^{-10}$ scaled by the largest eigenvalue magnitude. Explain in one sentence why a *relative* tolerance is needed rather than an absolute one.


## 0.4 The condition number: how stretched a bowl is

For a symmetric positive definite matrix, the **condition number** is

$$\kappa = \frac{\lambda_{\max}}{\lambda_{\min}} \;\ge\; 1.$$

Geometrically, the contours of $\tfrac12 x^\top Q x$ are ellipses whose axis lengths are proportional to $1/\sqrt{\lambda}$, so $\kappa$ measures **how elongated the bowl is**: $\kappa = 1$ is perfectly round; $\kappa = 10^6$ is a canyon a thousand times longer than it is wide. In Part III we will prove that the cost of the simplest optimization algorithms grows in direct proportion to $\kappa$, which is why one of the very first practical rules in this course (§2.3) is about keeping $\kappa$ small by scaling your variables.

---

#### Exercises

**0.4.1 [H]** Compute $\kappa$ for $Q = \begin{pmatrix}10&0\\0&0.1\end{pmatrix}$ and state the axis ratio of the contour ellipses of $\tfrac12x^\top Qx$. Why is the axis ratio $\sqrt{\kappa}$ and not $\kappa$?

**0.4.2 [H]** A model has $x_1$ in metres ($\sim1$) and $x_2$ in millimetres of deflection ($\sim1$), with Hessian $\begin{pmatrix}4&0\\0&400\end{pmatrix}$. Find $\kappa$. Now substitute $x_2 = z_2/10$ and give the Hessian and $\kappa$ in the new variable. What does this say about the *origin* of most large condition numbers in engineering models?

**0.4.3 [P]** The Rosenbrock function $f = 100(x_2-x_1^2)^2 + (1-x_1)^2$ has Hessian $\begin{pmatrix}802&-400\\-400&200\end{pmatrix}$ at its minimizer $(1,1)$. Compute its eigenvalues and $\kappa$ numerically.

**0.4.4 [P]** Verify the claim "the cost of the simplest algorithms grows in direct proportion to $\kappa$." Run steepest descent with *exact* line search on $f = \tfrac12x^\top Qx$ with $Q = \operatorname{diag}(1,\kappa)$, starting from $x_0 = (1,\,1/\kappa)$, and count iterations to reduce $f$ by a factor $10^{-6}$, for $\kappa = 1,10,100,1000,10^4$. Compare against the theoretical per-iteration factor $\big(\tfrac{\kappa-1}{\kappa+1}\big)^2$. Why is the starting point specified so precisely?


## 0.5 Checkpoint for Chapter 0

You should now be able to: compute a gradient by hand and verify it numerically with a small-step experiment; write the first- and second-order Taylor models of a function at a point; classify a symmetric $2\times 2$ matrix as positive definite / semidefinite / indefinite via its eigenvalues; and say in one sentence what the condition number measures. If any of these is shaky, re-read the corresponding section — everything in Parts I and III leans on them.

---
---
# PART I — FOUNDATIONS

---

## 1. Anatomy of an optimization problem

### 1.1 The three ingredients

Every optimization problem in every field — a truss, a chemical plant, a controller, a delivery schedule, a machine-learning model — is built from exactly three things.

**Decision variables** — what you control. A beam's cross-section dimensions. Which of six pumps runs. Controller gains. Flow in each pipe. The test is simple: *if you cannot change it, it is not a variable — it is a parameter.* Confusing the two is the most common beginner's error, and it produces models that are either trivially infeasible or absurdly optimistic. When in doubt, write the list of variables in words, with units, before writing any mathematics.

**An objective** — one scalar measuring how good a choice is: mass, cost, energy, tracking error, settling time, negative profit. It must be a *single number*. If you genuinely care about two things at once — mass *and* cost, say — you do not have one problem; you have a family of them, and Part VI (§18) shows how to handle that honestly. For now: one objective, one number.

**Constraints** — the rules separating admissible designs from inadmissible ones. They come from four places, and it is worth checking all four every time you build a model:

1. **Physics**: conservation laws, Kirchhoff's laws, force balance, mass balance. These are usually *equalities*.
2. **Codes and standards**: allowable stress, maximum temperature, safety factors. Usually *inequalities*.
3. **Resources**: budget, floor area, available supply, machine hours. Inequalities.
4. **Definitional bounds**: thickness $> 0$, a fraction between 0 and 1. Easy to forget, and forgetting them is a classic source of absurd answers.

> **The picture to hold onto.** Constraints carve a region — the feasible set $\mathcal{F}$ — out of the space of conceivable designs. The objective drapes a landscape of hills and valleys over that space. Optimization is the search for the lowest point of the landscape that still lies inside the region.

![Landscape and feasible region](figures/fig1_landscape.png)

*Figure 1.1 — Contours of an objective $f$ (labeled curves) and a feasible set $\mathcal{F}$ (shaded). The unconstrained minimum of $f$ (triangle) lies outside $\mathcal{F}$, so it is irrelevant. The constrained optimum (star) is the point of the region touched by the lowest contour — and notice that it sits on the region's boundary. That is typical, not accidental: optimization pushes against limits, which is why §1.4 teaches you to read which limits it is pushing against.*

---

#### Exercises

**1.1.1 [M]** A cooling fin is to be designed. Available quantities: fin length $L$, fin thickness $t$, fin material (aluminium or copper), ambient air temperature $T_\infty$, convection coefficient $h$ (set by a fan whose speed you may choose), maximum permitted mass, the base temperature $T_b$ of the chip being cooled, and the cost per kilogram of each material. Sort every item into **decision variable**, **parameter**, or **derived quantity**, with units. State the test you applied.

**1.1.2 [H]** For the same fin, write the three-part inventory: variables (with units), one scalar objective, and constraints sorted into the four sources of §1.1. Include at least one definitional bound.

**1.1.3 [C]** A model of a pump station takes the pipe diameter as a variable but forgets the bound $D > 0$. Solvers return $D = -0.4$ m with a very low cost. Which of the four constraint sources was neglected, and why does a negative diameter *reduce* the modelled cost?

**1.1.4 [M]** Your supervisor says: "minimize mass and cost." Explain in two sentences why this is not yet an optimization problem, and give the two legitimate ways to proceed (name the section of this course that treats each).


### 1.2 Standard form

$$
\begin{aligned}
\min_{x \in \mathbb{R}^n} \quad & f(x) \\
\text{subject to} \quad & g_i(x) \le 0, && i = 1, \dots, m \\
& h_j(x) = 0, && j = 1, \dots, p
\end{aligned}
$$

That is the entire subject. Everything that follows in this course concerns what happens when you assume specific things about $f$, $g$, $h$, and the set $x$ lives in — linear, convex, smooth, integer.

One practical note that saves real time. Simple bounds such as $x_k \ge 0$ or $2 \le t \le 10$ are technically inequality constraints, but every serious solver treats them by a separate, far cheaper mechanism. **Declare bounds as bounds, never as general constraints.** In `scipy.optimize` this is the `bounds=` argument; in CVXPY, `nonneg=True` or explicit bound constraints the presolver recognizes; in Pyomo, the `bounds=` keyword on the variable. It is free performance, and it also makes the model easier to read.

---

#### Exercises

**1.2.1 [H]** Put this problem into the standard form of §1.2, showing every sign change:
$$\max_{x}\; 3x_1 + 2x_2 \quad \text{s.t.}\quad x_1 + x_2 \ge 4,\quad 2x_1 - x_2 = 6,\quad 0 \le x_1 \le 5,\; x_2 \ge 0.$$
State the relation between your $f^\star_{\min}$ and the original $f^\star_{\max}$.

**1.2.2 [C]** Simple bounds *are* inequality constraints mathematically. Give two distinct reasons the course insists you declare them as bounds anyway.

**1.2.3 [P]** Solve the LP of 1.2.1 twice with `scipy.optimize.linprog`: once with $0\le x_1\le5$, $x_2\ge0$ passed via `bounds=`, and once with the same limits passed as rows of `A_ub`. Confirm the solutions agree and compare the number of constraint rows in each formulation.

**1.2.4 [C]** Rewrite the constraint $5 \le g(x) \le 12$ in the standard form $g_i(x)\le0$. How many standard-form constraints result, and what is the corresponding count if you instead treat $g$ as a variable with bounds?


### 1.3 The four possible outcomes

When you press "solve," exactly one of four things happens. You must be able to recognize each, because three of them are usually *your* mistake rather than the solver's.

**Optimal.** The solver returns a feasible $x^\star$ with $f(x^\star) \le f(x)$ for all feasible $x$: a *global* minimum. Compare a *local* minimum, which beats everything in some neighborhood of itself but not necessarily the whole feasible set. Which of the two you actually get is decided almost entirely by convexity (§3) — this distinction is the single most important idea in the course.

**Infeasible.** $\mathcal{F}$ is empty; the constraints contradict one another. There is no answer, and the solver is right to say so. Perhaps your specification really is impossible — or perhaps you typed a unit wrong. §20 (Part VI) shows how to find the culprit systematically rather than guessing.

**Unbounded.** $f$ can be driven to $-\infty$ while remaining feasible. Real engineering objectives are bounded, because real resources are finite. If your model says otherwise, your model is missing a constraint — and the solver has just told you which physical limit you forgot to write down.

**Converged to nonsense.** The solver reports success, and the answer is absurd: a beam of zero thickness, a plan that produces negative amounts. This is the most dangerous case, because it *looks* like success. It is covered in depth in §20, but the diagnosis habit starts in the very next section.

---

#### Exercises

**1.3.1 [C]** List the four outcomes. For each, say in one sentence whose fault it usually is and what the *first* diagnostic move should be.

**1.3.2 [P]** Using `scipy.optimize.linprog`, construct (a) an infeasible LP and (b) an unbounded LP, each with two variables. Print `res.status` and `res.message` for both and record the integer status codes.

**1.3.3 [M]** A truss mass-minimization returns "optimal" with member areas of $10^{-9}$ m$^2$ and a mass of essentially zero. Classify the outcome, name the most likely missing constraint, and describe the two-minute test that would confirm your diagnosis.

**1.3.4 [C]** "Optimal" from a solver means a global minimum for convex problems but only a local minimum for nonconvex ones. Why, then, do nonconvex solvers still report `success = True`? What exactly are they certifying?


### 1.4 Active constraints: how to read a solution

At a solution, an inequality constraint $g_i$ is **active** (or *binding*) if $g_i(x^\star) = 0$ — you are pressed exactly against the limit — and **inactive** (or *slack*) if $g_i(x^\star) < 0$, meaning there is room to spare.

This distinction carries the engineering content of the answer:

- **Active constraints are the ones causing your design to be what it is.** Delete an inactive constraint and nothing changes; loosen an active one and the design improves.
- **The active set is the physical story.** "This beam is deflection-limited, not stress-limited" is precisely the statement that the deflection constraint is active and the stress constraint is not. That sentence is worth more to a design review than the objective value is.

> **Habit to build now.** In any solution report, read the active set *before* the objective value. The objective tells you how good the design is; the active set tells you *why*, and what to change if you want it better.

In code, "read the active set" means: after solving, evaluate every $g_i(x^\star)$ and see which are (numerically) zero. We will do this in every worked example from §4.2 onward.

---

#### Exercises

**1.4.1 [H]** A beam design returns $x^\star$ with these normalized constraint values ($g_i \le 0$ required): $g_{\text{stress}} = -0.23$, $g_{\text{deflection}} = 0.0$, $g_{\text{buckling}} = -0.61$, $g_{\text{width}\le b_{\max}} = 0.0$, $g_{\text{cost}} = -0.05$. List the active and inactive constraints, and write the one-sentence engineering summary a design review would want.

**1.4.2 [C]** Explain why deleting an *inactive* constraint leaves the solution unchanged, and give one situation in which deleting it anyway would be a mistake.

**1.4.3 [P]** Write `report(g_funcs, x, tol=1e-6)` that evaluates a list of constraint functions at `x` and prints each one's value, its slack, and whether it is active. Apply it to the constraints $g_1 = x_1+x_2-4$, $g_2 = x_1-3$, $g_3 = -x_2$ at $x = (3,1)$.

**1.4.4 [M]** Two designs are reported: design A has mass 41.2 kg with the deflection constraint active; design B has mass 41.0 kg with *no* constraint active. Which result should worry you more, and why?


### 1.5 The map of the territory

Optimization problems come in what looks like a zoo of types — LP, QP, NLP, MILP, MINLP, and more. The zoo is organized by just **two questions**. Everything else is detail.

|  | **All variables continuous** | **Some variables integer / binary** |
|---|---|---|
| **Convex** (includes all linear) | LP, QP, SOCP, SDP. **Global** optimum, with a certificate. Very large scale routine for LP/QP. (§3.4, §4–5) | MILP, convex MINLP. **Global** optimum via branch and bound; achievable size depends strongly on formulation. (Part IV) |
| **Nonconvex** | *Smooth:* local optimum via gradient methods, plus multi-start (Part III). *Nonsmooth or black-box:* heuristics, surrogates (Part V) | Nonconvex MINLP — the hardest class. Global solvers handle modest sizes; otherwise heuristics with no guarantee (Part V) |

The two dividing lines:

- **Convexity** (§3) decides whether "the answer" means *the global optimum, certified* or *the best point we happened to find*. Linearity is just an especially convenient special case of convexity, which is why linear-vs-nonlinear does not get its own axis in the table.
- **Discreteness** decides whether you can use derivatives to walk downhill, or must instead search a combinatorial tree.

Note the top-right cell carefully: adding integer variables does **not** cost you global optimality. Branch and bound (Part IV) recovers it, using the convex case as its engine. What integrality costs is *time* — sometimes an enormous amount of it. And note §6 in this installment, which identifies an important family of integer problems that cost nothing extra at all.

Keep this table in sight for the rest of the course. Choosing a method (§20) is nothing more than locating your problem in this table and then exploiting any additional structure it has.

---

#### Exercises

**1.5.1 [C]** Place each problem in one of the four cells of the §1.5 table, and name the class (LP, QP, SOCP, MILP, nonconvex NLP, nonconvex MINLP):
(a) blending four crude oils to meet octane and sulphur specs at minimum cost;
(b) the same blend, but each crude has a fixed charge if used at all;
(c) least-squares calibration of five parameters with box bounds;
(d) minimizing drag of an airfoil evaluated by a CFD solver;
(e) choosing which of 12 generators to run, and at what output, with quadratic fuel costs;
(f) keeping the Euclidean norm of a displacement vector below 5 mm at minimum mass, with linear stiffness relations.

**1.5.2 [C]** Why does the table use *convex vs nonconvex* as an axis rather than *linear vs nonlinear*?

**1.5.3 [C]** The top-right cell claims integrality does **not** cost global optimality. What does it cost instead, and which mechanism recovers the guarantee?

**1.5.4 [M]** You have a nonconvex smooth NLP and a deadline. Give two distinct strategies from the map: one that keeps nonconvexity and manages the risk, one that changes the model class. State the price of each.


---

## 2. Modeling: the part that decides success

Students spend most of their time on algorithms; practitioners spend most of theirs on formulation. A well-formulated problem solved by a mediocre algorithm beats a badly formulated problem solved by the world's best algorithm — usually by orders of magnitude. This chapter is short and has the highest value per page in the course.

### 2.1 The modeling loop

Optimization in practice is never one pass. It is this loop:

1. **Name** the variables, objective, and constraints — *in words, with units* — before writing mathematics.
2. **Write** the mathematical model.
3. **Classify** it using the table of §1.5, and choose a method.
4. **Solve.**
5. **Interrogate the answer.** Which constraints are active — and is that physically sensible? Is any variable sitting on a bound? Which bound, and why? Is the objective value plausible? Are the units right?
6. Almost always, step 5 exposes a missing constraint or a wrong objective. **Fix it and go around again.**

Step 5 is where the engineering happens. An optimizer is an extremely effective search for loopholes in your model. Forget to constrain buckling, and it will hand you an infinitely thin, infinitely wide beam — because that beam is genuinely optimal *for the model you wrote*. That is not a failure. It is free, ruthless design review, and you should treat every absurd answer as information about what your model is missing.

---

#### Exercises

**2.1.1 [C]** Reproduce the six steps of the modeling loop from memory, then say which single step most beginners skip and what it costs them.

**2.1.2 [M]** A pipe-network cost minimization returns a solution in which one pipe carries a *negative* flow of 12 L/s and total cost is lower than any hand design. Work through step 5 of the loop: give three specific questions you would ask of this answer, and the most likely model defect behind it.

**2.1.3 [M]** "An optimizer is an extremely effective search for loopholes in your model." Give two examples from your own discipline of a loophole an optimizer would exploit, and the constraint that closes each.

**2.1.4 [P]** Write an `interrogate(x, f, cons, bounds, names)` helper that, given a returned solution, prints: the objective value, every constraint value with its active/inactive status, and any variable within $10^{-6}$ of a bound. This is the step-5 tool you should reuse in every later chapter.


### 2.2 A formulation toolbox

A handful of transformations convert awkward problems into well-behaved standard ones. They are worth memorizing, because they come up constantly, and because each is a small piece of magic: a problem that looks unsolvable by clean methods becomes exactly solvable by them.

**Minimize a maximum (the epigraph trick).** The problem $\min_x \max_i f_i(x)$ — "minimize the worst-case stress over all load cases" — has a non-differentiable objective: it has kinks wherever the identity of the worst case changes. Introduce one new variable $t$ standing for "the level of the worst case":

$$\min_{x,\,t} \ t \quad \text{subject to} \quad f_i(x) \le t \quad \text{for all } i.$$

The solutions are identical — pushing $t$ down forces $t = \max_i f_i(x)$ at the optimum — but the reformulated problem is smooth, and if the $f_i$ are linear it is an LP. One extra variable buys differentiability.

**Absolute values and $L_1$ objectives.** For $\min_x \sum_k |r_k(x)|$ with $r_k$ linear (robust data fitting, for instance), introduce $t_k \ge |r_k|$:

$$\min_{x,\,t} \ \sum_k t_k \quad \text{subject to} \quad -t_k \le r_k(x) \le t_k.$$

Each $t_k$ is squeezed down to exactly $|r_k(x)|$ at the optimum. A kinked objective has become a **linear program**. Here is the trick in action — fitting a line through data that contains outliers, where least squares gets dragged off course and the $L_1$ fit does not:

```python
"""L1 (robust) line fitting as a linear program, via CVXPY."""
import numpy as np, cvxpy as cp

rng = np.random.default_rng(1)
t  = np.linspace(0, 10, 30)
y  = 2.0*t + 1.0 + rng.normal(0, 0.4, t.size)   # true line: slope 2, intercept 1
y[[5, 20]] += np.array([15.0, -12.0])           # two gross outliers (sensor glitches)

a, b = cp.Variable(), cp.Variable()
res  = a*t + b - y
L2   = cp.Problem(cp.Minimize(cp.sum_squares(res)))       # least squares
L1   = cp.Problem(cp.Minimize(cp.norm1(res)))             # the LP in disguise
L2.solve(); print(f"L2 fit: slope={a.value:.3f}, intercept={b.value:.3f}")
L1.solve(); print(f"L1 fit: slope={a.value:.3f}, intercept={b.value:.3f}")
```

```
L2 fit: slope=1.702, intercept=2.566
L1 fit: slope=1.965, intercept=1.156
```

Two outliers dragged the least-squares fit badly off the true line (slope $2.0$, intercept $1.0$): its intercept is wrong by a factor of 2.5. The $L_1$ fit shrugged the outliers off and recovered the line closely. Behind the scenes, `cp.norm1` performs precisely the reformulation above and hands an LP to the solver. This is why robust regression is *no harder* than ordinary least squares — a fact that surprises most people the first time.

**Soft constraints.** For a requirement you want but cannot allow to make the whole problem infeasible, add a slack variable $s \ge 0$:

$$g(x) \le s, \qquad \text{minimize } f(x) + \rho\, s \quad (\rho \text{ large}).$$

The solver satisfies $g \le 0$ whenever it can, and when it cannot, it tells you *exactly how much violation was unavoidable*. This is the single best debugging tool for infeasible models (§20): instead of the useless status code "infeasible," you get "your deflection limit had to be relaxed by 1.4 mm."

**Ratios.** "Maximize efficiency $=$ output/input" is nonconvex as written. If numerator and denominator are both affine (linear plus constant) and the denominator is strictly positive over $\mathcal{F}$, the *Charnes–Cooper* change of variables turns the problem into an exact LP. If not, a serviceable practical route: constrain the denominator to a target value, optimize the numerator, and sweep the target.

**Products of variables.** $x_1 x_2$ is nonconvex, and it is why process models (flow × concentration) and structural models (area × stress) are hard. If one factor is *binary*, the product linearizes exactly (Part IV, §12.2). If both are continuous, you are genuinely in nonconvex territory (Parts III and V) — no trick will save you, and it is better to know that at formulation time than to discover it as mysterious solver failure later.

---

#### Exercises

**2.2.1 [H]** Reformulate as a linear program, stating the new variables and counting constraints:
$$\min_{x\in\mathbb{R}^2}\ \max\{\,2x_1 - x_2,\ -x_1 + 4,\ x_1 + x_2 - 3\,\}\quad\text{s.t.}\quad x_1 + 2x_2 \ge 1.$$

**2.2.2 [H]** Show that $\min_x \|Ax - b\|_\infty$ (Chebyshev fitting) is an LP by writing it out with one new variable $t$. How many inequality constraints does an $m$-row problem produce, and how does that compare with the $L_1$ reformulation of §2.2?

**2.2.3 [P]** Extend the $L_1$/$L_2$ outlier experiment: add an $L_\infty$ fit (`cp.norm_inf`) to the same data and report all three slope/intercept pairs. Explain the $L_\infty$ result — is it better or worse than least squares here, and why is that predictable from the definition rather than from the numbers?

**2.2.4 [M]** A colleague's model is infeasible and the solver says only "infeasible." Show how the soft-constraint trick converts this into actionable information, writing the modified model explicitly for the constraint set $\{$deflection $\le 5$ mm, mass $\le 40$ kg$\}$. What would you conclude if the returned slack on the deflection constraint were 1.4 mm and on the mass constraint 0?

**2.2.5 [C]** Classify each as (i) exactly reformulable to convex, (ii) reformulable only under extra conditions, or (iii) genuinely nonconvex: (a) maximize $(c^\top x + d)/(e^\top x + f)$; (b) $y = x_1x_2$ with $x_1$ binary and $x_2 \in [0,U]$; (c) $y = x_1x_2$ with both continuous; (d) minimize $\sum_k|r_k(x)|$ with $r_k$ affine.


### 2.3 Scaling: the boring thing that ruins everything

Suppose one variable is a length in metres ($\sim 10^0$) and another is Young's modulus in pascals ($\sim 10^{11}$). Numerically, the algorithm sees a canyon $10^{11}$ times longer in one direction than the other. Convergence will be dreadful or the solver will fail outright — and the failure message will not mention scaling. It will say something unhelpful like "line search failed" or "maximum iterations reached."

![Scaling and the descent direction](figures/fig2_scaling.png)

*Figure 2.1 — The same minimization with good and bad scaling. In the round bowl (left), the steepest-descent direction points essentially at the minimum. In the stretched canyon (right), it points across the canyon: the algorithm will zigzag from wall to wall, making almost no progress along the valley floor. Part III quantifies this exactly; the cost grows in direct proportion to the condition number $\kappa$ of §0.4.*

> **Rule.** Rescale so that every variable, every constraint value, and the objective are within an order of magnitude or two of 1. Replace $x$ by $\tilde x = x/x_{\text{ref}}$ using a reference value of the right physical size; divide each constraint by its own natural scale so it reads "ratio $\le 1$"; normalize the objective by a nominal value.

This is not cosmetic. More real optimization runs are rescued by rescaling than by changing algorithms — and it costs five minutes.

---

#### Exercises

**2.3.1 [H]** A model has variables $t$ (thickness, $\sim2\times10^{-3}$ m), $E$ (modulus, $\sim2\times10^{11}$ Pa, a parameter), and $L$ (length, $\sim3$ m), a stress constraint $\sigma(x) \le 250\times10^6$ Pa and an objective in kilograms ($\sim40$). Propose a complete rescaling — new variables, new constraint form, new objective — that puts everything within an order of magnitude of 1.

**2.3.2 [C]** Name three solver messages that are commonly *caused* by bad scaling but never mention it.

**2.3.3 [P]** Demonstrate the cost of bad scaling on a problem where quasi-Newton methods cannot hide it. Run steepest descent with exact line search on $f = \tfrac12(x_1^2 + \kappa x_2^2)$ from $x_0 = (1, 1/\kappa)$ for $\kappa = 1, 10^2, 10^4$, then apply the substitution $x_2 = z_2/\sqrt{\kappa}$ and repeat. Report iteration counts to $f \le 10^{-6}f_0$ in both coordinate systems.

**2.3.4 [M]** Why does rescaling *variables* alone sometimes fail to fix a badly conditioned model, and what else must be rescaled? Illustrate with a two-constraint example in which one constraint is measured in pascals and the other as a dimensionless ratio.


---

## 3. Convexity

If you retain one concept from this entire course, retain this one. Convexity is the property that separates "we computed *the* answer" from "we found *something*."

### 3.1 Definitions

A set $C$ is **convex** if the straight segment between any two of its points stays inside it:

$$x, y \in C \implies \theta x + (1-\theta)\,y \in C \quad \text{for all } \theta \in [0,1].$$

Intuitively: **no dents, no holes, no separate pieces.** A disk, a triangle, a half-plane, a slab are convex; a crescent, an annulus, a star shape, two disjoint blobs are not.

![Convex and nonconvex sets](figures/fig3_sets.png)

*Figure 3.1 — Left: a convex set; every chord stays inside. Right: a nonconvex set; the marked chord leaves the set. The definition is nothing more than this picture, written in algebra.*

A function $f$, defined on a convex domain, is **convex** if the chord between any two points of its graph lies on or above the graph:

$$f\big(\theta x + (1-\theta)y\big) \;\le\; \theta f(x) + (1-\theta) f(y) \quad \text{for all } \theta \in [0,1].$$

(The convex-domain requirement is not pedantry: the statement would be meaningless if the point $\theta x + (1-\theta)y$ could fall outside where $f$ is defined.)

![Convex and nonconvex functions](figures/fig3_convexity.png)

*Figure 3.2 — Left: a convex function; chords lie above the graph, and a downhill search cannot stall anywhere except at the (global) minimum. Right: a nonconvex function; the chord dips below the graph, and there is a local minimum that is not global — a trap that no purely local search can detect, let alone escape.*

For a twice-differentiable $f$ on a convex domain, there is a calculus test: $f$ is convex $\iff \nabla^2 f(x) \succeq 0$ everywhere on that domain (curves upward, or at least not downward, in every direction — §0.3). In one dimension this is simply $f'' \ge 0$.

A **convex optimization problem** is one where $f$ is convex, every inequality function $g_i$ is convex, and every equality function $h_j$ is *affine* (linear plus a constant). Note the asymmetry in the last requirement, because students trip on it: for a nonlinear $h$, the set $\{x : h(x) = 0\}$ is a curved surface, and a curved surface is not a convex set — a chord between two of its points leaves the surface. **Equality constraints must be straight.**

---

#### Exercises

**3.1.1 [H]** Decide whether each set is convex, with a one-line reason: (a) $\{x : \|x\|_2 \le 3\}$; (b) $\{x : \|x\|_2 = 3\}$; (c) $\{x \in \mathbb{R}^2 : x_1x_2 \ge 1,\ x_1 > 0\}$; (d) $\{x : Ax = b\}$; (e) $\{x \in \mathbb{R}^2 : x_2 \ge x_1^2\}$; (f) $\{x \in \mathbb{R}^2 : x_2 = x_1^2\}$.

**3.1.2 [H]** Use the definition (not the Hessian) to prove $f(x) = \max\{x, 0\}$ is convex on $\mathbb{R}$. Why is the definition the easier route here?

**3.1.3 [C]** State precisely why a *convex optimization problem* requires equality constraints to be affine, and explain what goes wrong for the constraint $x_1^2 + x_2^2 = 4$ using a specific pair of feasible points.

**3.1.4 [P]** Write a *sanity check* (not a proof) for convexity of a scalar function: sample many random pairs $x,y$ and $\theta \in (0,1)$ and test $f(\theta x + (1-\theta)y) \le \theta f(x) + (1-\theta)f(y)$ up to a small tolerance. Run it on $f(x) = x^2 - \cos x$ and $f(x) = x^2 - |x|$, and state clearly what a "pass" does and does not establish.


### 3.2 Why it matters

> **Theorem.** For a convex optimization problem, every local minimum is a global minimum.

*Proof sketch — worth following once in your life.* Suppose $x^\star$ is locally optimal but some feasible $y$ has $f(y) < f(x^\star)$. Convexity of $\mathcal{F}$ makes the whole segment $x_\theta = \theta y + (1-\theta)x^\star$ feasible. Convexity of $f$ gives $f(x_\theta) \le \theta f(y) + (1-\theta) f(x^\star) < f(x^\star)$ for every $\theta \in (0,1]$. Taking $\theta$ tiny places a strictly better feasible point arbitrarily close to $x^\star$ — contradicting local optimality. $\square$

Three practical consequences:

1. **You can trust the answer.** A solver reporting convergence on a convex problem has found *the* optimum. On a nonconvex problem it has found *a* candidate — and cannot tell you how good a candidate.
2. **You get a certificate.** Duality (§5.2 for LP, and Part III in general) produces a verifiable lower bound that matches the achieved value. Optimality becomes checkable, not merely asserted.
3. **It scales.** Interior-point methods solve convex problems with hundreds of thousands of variables reliably, with no tuning.

> **Design principle.** When you have a choice of how to model something, prefer the convex formulation *even if it is somewhat less faithful*. A convex approximation you can solve globally and trust is usually worth more than an exact nonconvex model whose answer you cannot certify. Know which one you chose, and why.

---

#### Exercises

**3.2.1 [H]** Reproduce the local-implies-global proof for convex problems without looking, then identify exactly which hypothesis fails if the feasible set is convex but $f$ is not.

**3.2.2 [C]** Give a concrete nonconvex $f:\mathbb{R}\to\mathbb{R}$ with exactly two local minima, one global; state both, and explain what a local method started at each would report and why it cannot know it is wrong.

**3.2.3 [C]** The section claims a convex problem gives you "a certificate." What object is the certificate, and what inequality must it satisfy for you to conclude optimality?

**3.2.4 [M]** Argue for and against the design principle "prefer the convex formulation even if less faithful," using a design problem of your choice. What must you always report if you take the convex route?


### 3.3 Recognizing convexity without computing anything

You almost never verify convexity by computing a Hessian. In practice, convexity is *assembled*: you recognize your functions as combinations of known convex pieces, glued together by rules that preserve convexity.

**Known convex functions.** Affine $a^\top x + b$ (convex *and* concave — the only functions that are both); every norm $\|x\|_1$, $\|x\|_2$, $\|x\|_\infty$; powers $x^p$ for $p \ge 1$ on $x \ge 0$; exponentials $e^{ax}$; $-\log x$ on $x > 0$; $x \log x$ on $x > 0$; the quadratic form $x^\top Q x$ when $Q \succeq 0$; the largest eigenvalue of a symmetric matrix (as a function of the matrix).

**Rules that preserve convexity.**

| Operation | Result | Watch out |
|---|---|---|
| $\alpha f_1 + \beta f_2$ with $\alpha,\beta \ge 0$ | convex | nonnegative weights only |
| $f(Ax + b)$ | convex | composition with an *affine* map, any $A, b$ |
| $\max\{f_1, f_2, \dots\}$ | convex | pointwise max of any number of convex functions |
| $g(f(x))$, $g$ convex **and nondecreasing**, $f$ convex | convex | the monotonicity condition is essential |
| intersection of convex sets | convex | — |

The last row explains why having *many* constraints is never itself an obstacle: the feasible set of a convex program is an intersection of convex sets, hence convex, however many there are. It is nonconvexity, not multiplicity, that hurts.

**Warning signs of nonconvexity**, worth scanning any model for: products or quotients of variables; nonlinear equality constraints; integer or binary variables; trigonometric functions of variables; and anything computed by a black-box simulation — where you simply cannot know.

**Let the computer check your reasoning.** CVXPY implements exactly the composition rules above (the framework is called *disciplined convex programming*, DCP). Every expression you build carries a certified curvature, and CVXPY will refuse to solve anything it cannot verify as convex. This makes it a *proof assistant* for §3.3, not just a solver:

```python
import cvxpy as cp
x = cp.Variable()
y = cp.Variable(nonneg=True)

print(cp.square(x).curvature)                 # CONVEX      (known atom)
print(cp.sqrt(y).curvature)                   # CONCAVE     (known atom)
print((cp.square(x) + cp.abs(x)).curvature)   # CONVEX      (sum rule)
print(cp.maximum(cp.square(x), 1 - x).curvature)  # CONVEX  (pointwise-max rule)
print((cp.square(x) - cp.abs(x)).curvature)   # UNKNOWN     (convex minus convex: no rule!)
print(cp.exp(cp.square(x)).curvature)         # CONVEX      (convex, nondecreasing ∘ convex)
```

```
CONVEX
CONCAVE
CONVEX
CONVEX
UNKNOWN
CONVEX
```

Study the `UNKNOWN` line: $x^2 - |x|$ happens to be nonconvex, but the honest point is subtler — *convex minus convex* follows no rule, so DCP refuses to certify it either way. When CVXPY rejects your model, it is telling you that your formulation is not *verifiably* convex by the composition rules; often a small reformulation (frequently one from §2.2) fixes it. Learning to write DCP-compliant models is learning §3.3 by muscle memory.

---

#### Exercises

**3.3.1 [H]** Assemble a convexity argument (atoms + rules, no Hessians) for each: (a) $f(x) = \|Ax-b\|_2 + \lambda\|x\|_1$, $\lambda \ge 0$; (b) $f(x) = e^{\,c^\top x} + \max\{0, d^\top x - 1\}$; (c) $f(x) = -\log(1 - \|x\|_2)$ on $\|x\|_2 < 1$.

**3.3.2 [H]** Explain why the monotonicity condition in the composition rule is essential, using $g(u) = u^2$ and $f(x) = |x| - 1$: is $g(f(x))$ convex? Now replace $f$ by $|x|$ and re-answer.

**3.3.3 [P]** Use CVXPY as a proof assistant. Report the `.curvature` of: `cp.log(y)`, `cp.inv_pos(y)`, `-cp.log(y)` (with `y = cp.Variable(nonneg=True)`), `cp.square(cp.pos(x))`, `cp.log(1 + cp.exp(x))`, and `cp.logistic(x)`. Two of these are mathematically convex but *not* certified CONVEX as written — identify them and give the DCP-compliant rewrite.

**3.3.4 [M]** Scan this model for the §3.3 warning signs and list every nonconvexity, with the reformulation (if any) that removes it:
$$\min\ c^\top x \quad\text{s.t.}\quad x_1x_2 = 10,\quad \sin(x_3) \le 0.5,\quad x_4 \in \{0,1\},\quad \|x\|_2 \le 5.$$


### 3.4 The named convex classes

Four classes are worth recognizing by name, in increasing generality:

| Class | Form | Typical engineering use | Honest scale note |
|---|---|---|---|
| **LP** | linear objective, linear constraints | allocation, blending, flows, scheduling | millions of variables routine |
| **QP** | convex quadratic objective, linear constraints | least squares with bounds, model-predictive control, portfolio | very large |
| **SOCP** | adds constraints $\|Ax+b\|_2 \le c^\top x + d$ | "keep the displacement *vector* under 5 mm"; robust LP (Part VI) | large |
| **SDP** | adds matrix inequalities $\sum_i x_i A_i \succeq B$ | robust control, relaxations of hard problems | **much** smaller — hundreds to a few thousand variables |

All four are solved by the same interior-point machinery, and modeling tools such as CVXPY recognize and convert them for you automatically. But do not let the shared machinery mislead you about scale: SDP is enormously more expensive per variable than LP, and treating them as interchangeable in size is a common and costly misconception.

---

#### Exercises

**3.4.1 [C]** Name the smallest class in the §3.4 hierarchy that contains each problem: (a) minimize $c^\top x$ subject to $Ax\le b$; (b) minimize $\|Ax-b\|_2^2$ subject to $0\le x\le1$; (c) minimize $t$ subject to $\|Fx+g\|_2 \le t$; (d) minimize $\lambda_{\max}(A_0 + \sum_i x_iA_i)$; (e) minimize $c^\top x$ subject to $\|Ax\|_2 \le d^\top x$.

**3.4.2 [C]** LP $\subset$ QP $\subset$ SOCP $\subset$ SDP. Why is the table's "honest scale note" column not monotone in the same way — and what practical error does ignoring it cause?

**3.4.3 [P]** Solve $\min \|Ax-b\|_2^2$ subject to $\mathbf{1}^\top x = 1$, $0\le x\le1$ with CVXPY for a random $6\times3$ system (`default_rng(0)`), and report the optimal $x$, the objective, the active bounds, and the multiplier of the equality constraint. Which class is this, and what does the equality multiplier mean dimensionally?

**3.4.4 [M]** A colleague models "keep the displacement vector under 5 mm" as three separate constraints $|d_x|\le5$, $|d_y|\le5$, $|d_z|\le5$. What has changed physically, in which direction is the error, and what is the correct single constraint (and its class)?


---

## Checkpoint — Part I

You should now be able to:

- take a design situation described in words and produce the three-part inventory — variables (with units), one scalar objective, constraints sorted into physics / codes / resources / bounds;
- state the four possible solver outcomes and what each one usually means about *your model*;
- define active vs. inactive constraints and explain why the active set is read before the objective value;
- place any problem in the two-question map of §1.5;
- apply the epigraph and $L_1$ tricks, and explain to a colleague why $L_1$ fitting is an LP;
- state the definition of a convex set, a convex function, and a convex problem — including why equality constraints must be affine;
- reproduce the local-implies-global proof sketch;
- assemble a convexity argument from the atoms and rules of §3.3, and use CVXPY's curvature attribute to check it.

## Self-test — Part I

Work these on paper before looking at the answers.

**Q1.** A colleague models a heat exchanger and includes the ambient temperature as a decision variable "because it appears in the equations." What error is this, and what will the optimizer likely do with it?

**Q2.** Rewrite $\min_x \max\{\,3x_1 - x_2,\; x_1 + 2x_2 + 1\,\}$ as a smooth (in fact linear) problem.

**Q3.** Is the set $\{(x_1,x_2) : x_1^2 + x_2^2 = 4\}$ convex? Is $\{(x_1,x_2) : x_1^2 + x_2^2 \le 4\}$? Explain both in one sentence each.

**Q4.** Classify: (a) $f(x) = e^{2x} + 5|x|$; (b) $f(x) = x^2 - \cos x$ on $\mathbb{R}$; (c) $f(x_1,x_2) = x_1 x_2$. Convex, nonconvex, or needs more information?

**Q5.** Your solver returns "unbounded" on a cost-minimization model of a pump network. What does this tell you, and what is the first thing to look for?

**Answers.**

**A1.** Ambient temperature is a *parameter* — the designer cannot set the weather (§1.1). The optimizer will exploit it: it will pick whatever ambient temperature makes the design cheapest, producing an absurdly optimistic answer. Fix: move it to the data, or (Part VI) treat it as an uncertain parameter.

**A2.** Epigraph trick (§2.2): $\min_{x,\,t} t$ subject to $3x_1 - x_2 \le t$ and $x_1 + 2x_2 + 1 \le t$. This is an LP in $(x_1, x_2, t)$.

**A3.** The circle (equality) is *not* convex: the chord between two points on a circle cuts through the interior, leaving the set. The disk (inequality) *is* convex: chords between interior-or-boundary points stay inside. This is exactly why convex problems require equality constraints to be affine (§3.1).

**A4.** (a) Convex: $e^{2x}$ is a known convex atom, $|x|$ is a norm, and a nonnegative-weighted sum of convex functions is convex. (b) Convex: $f''(x) = 2 + \cos x \ge 1 > 0$ everywhere — here the Hessian test is the easy route. (c) Nonconvex: a product of variables (§3.3 warning list); its Hessian has eigenvalues $\pm 1$ — a saddle (§0.3).

**A5.** Some variable can run away to infinity while reducing cost — the model is missing a constraint (§1.3). Find which variable is diverging (solvers report a ray), then ask what physically limits it in reality, and add that limit to the model.

---
---
# PART II — LINEAR PROGRAMMING

Linear programming is where optimization first became an industrial tool, and it is still where most industrial optimization lives: allocation, blending, scheduling, logistics, power dispatch. It is also the perfect training ground, because everything — geometry, duality, sensitivity — can be seen completely in two dimensions and then trusted in two hundred thousand.

---

## 4. Geometry and algorithms

### 4.1 Form and geometry

The standard maximization form (we keep max here because the economics reads more naturally; remember from the Notation section that flipping signs converts to min):

$$\max_x \ c^\top x \quad \text{subject to} \quad Ax \le b, \quad x \ge 0.$$

Each row of $Ax \le b$ is a linear inequality, so it defines a **half-space** — everything on one side of a straight line (in 2-D) or hyperplane (in general). The feasible set is the intersection of these half-spaces: a **polyhedron**, flat-faced and possibly unbounded. The objective's level sets $c^\top x = z$ are parallel lines (hyperplanes).

Now do the following mental experiment, which is the whole geometry of LP. Push the level line $c^\top x = z$ across the polyhedron in the direction of increasing $z$. The last point of contact before the line leaves the region entirely is the optimum — and geometrically, that final contact happens at a **corner** (a *vertex*), or in a tie along an entire edge or face, which still contains corners.

> **Fundamental theorem of linear programming.** If an LP has an optimal solution, then at least one vertex of the feasible polyhedron is optimal.

Pause on what this buys: an infinite search over a continuum has collapsed to a **finite search over corners**. That single fact is the foundation of the simplex method, and — indirectly — of all of Part IV.

A consequence worth internalizing early, because it collides with intuition: **LP optima are extreme.** The answer typically exhausts some resources completely and uses others not at all. If your intuition insists the best plan should be a balanced compromise, and the LP says "run line A flat out and shut line B down," the LP is usually right — your intuition is smoothing over a genuinely linear trade-off, and linear trade-offs have their optima at the ends.

---

#### Exercises

**4.1.1 [C]** State the fundamental theorem of LP, and explain in two sentences why it converts an infinite search into a finite one. What is the *practical* limitation of exploiting it by brute force?

**4.1.2 [H]** Sketch (or describe) the feasible set of $\{x \ge 0 : x_1 + x_2 \le 4,\ x_1 - x_2 \le 2\}$ and list all its vertices. Then find the maximizer of $c^\top x$ for (a) $c = (1,1)$, (b) $c = (1,-1)$, (c) $c = (-1,-1)$. Which case has a non-unique optimum?

**4.1.3 [C]** "LP optima are extreme." A production manager objects that a balanced plan using every resource partially must be better than one that shuts a line down entirely. Explain what assumption in the LP makes the extreme answer correct, and name one realistic effect whose absence from the model makes the extreme answer suspicious.

**4.1.4 [H]** Give a two-variable LP whose feasible set is nonempty and unbounded, but which nevertheless has a finite optimum. Then change only $c$ so it becomes unbounded. What does this show about the relation between an unbounded *feasible set* and an unbounded *problem*?


### 4.2 Worked Example 1 — allocating two limited resources

*This example is the backbone of Part II: we solve it here, extract its shadow prices in §5.4, price a new product with it in §5.5, and stress-test its plan in §5.6–5.7. Work it by hand before reading on.*

A plant can run two production modes. Mode 1 earns \$40 per unit; mode 2 earns \$30 per unit. Three limits apply:

- **Machine time (M):** mode 1 needs 2 h/unit, mode 2 needs 1 h/unit; 100 h available.
- **Raw material (R):** both modes need 1 kg/unit; 80 kg available.
- **Line capacity (C):** mode 1 cannot exceed 40 units.

Following §2.1: the variables are $x_1, x_2$ = units of each mode (dimensionless counts); the objective is profit in dollars; the constraints are three resource limits plus nonnegativity. The model:

$$
\begin{aligned}
\max_{x_1,x_2} \quad & z = 40x_1 + 30x_2 \\
\text{s.t.} \quad & 2x_1 + x_2 \le 100 && (M)\\
& x_1 + x_2 \le 80 && (R)\\
& x_1 \le 40 && (C)\\
& x_1,\, x_2 \ge 0
\end{aligned}
$$

![Worked Example 1](figures/fig4_example1.png)

*Figure 4.1 — The feasible polygon of Example 1 (shaded), its five vertices with their objective values, and objective level lines $40x_1 + 30x_2 = z$ (red) swept upward. The last line to touch the region touches it at the vertex $(20, 60)$: the optimum. Notice the optimum is exactly where the level line's slope is "pinched" between the slopes of the two constraints meeting there — an observation that will become quantitative in §5.7.*

**Solve by hand: enumerate the vertices.** Only five vertices exist, so check them all. (This brute-force method dies combinatorially in higher dimensions — a polyhedron in $\mathbb{R}^{50}$ can have more vertices than atoms in the universe — but in 2-D it is exact, instructive, and a perfect check on the software.)

| Vertex | Defined by | Feasible? | $z = 40x_1 + 30x_2$ |
|---|---|---|---|
| $(0,0)$ | $x_1 = 0,\ x_2 = 0$ | yes | 0 |
| $(40,0)$ | $C$, $x_2 = 0$ | yes | 1600 |
| $(40,20)$ | $C \cap M$ | yes ($R$: $60 \le 80$ ✓) | 2200 |
| $(20,60)$ | $M \cap R$ | yes ($C$: $20 \le 40$ ✓) | **2600** |
| $(0,80)$ | $R$, $x_1 = 0$ | yes ($M$: $80 \le 100$ ✓) | 2400 |

So $x^\star = (20, 60)$ and $z^\star = 2600$.

**Read the physics off the active set** (the §1.4 habit). At $x^\star$: $2(20) + 60 = 100$, so $M$ is active. $20 + 60 = 80$, so $R$ is active. $20 < 40$, so $C$ is inactive, with 20 units of slack. In words: **the plant is limited by machine hours and by material — not by line capacity.** Buying line capacity is worth exactly nothing. That conclusion, not the number 2600, is the useful output of this model, and §5 makes it quantitative.

**Now in Python.** Two ways, both of which you should run.

*Way 1: `scipy.optimize.linprog`* — the low-level workhorse. It minimizes, so we negate the objective; it uses the HiGHS solver internally.

```python
"""Worked Example 1 with scipy.linprog (HiGHS)."""
import numpy as np
from scipy.optimize import linprog

c = [-40, -30]                       # minimize -z  <=>  maximize z
A = [[2, 1],                         # M
     [1, 1],                         # R
     [1, 0]]                         # C
b = [100, 80, 40]

res = linprog(c, A_ub=A, b_ub=b, bounds=[(0, None), (0, None)], method="highs")

print("status :", res.message)
print("x*     :", res.x)             # [20. 60.]
print("z*     :", -res.fun)          # 2600.0
slack = b - np.array(A) @ res.x
print("slacks :", slack)             # [ 0.  0. 20.]  -> M, R active; C slack
```

```
status : Optimization terminated successfully. ...
x*     : [20. 60.]
z*     : 2600.0
slacks : [ 0.  0. 20.]
```

The `slacks` line *is* the active-set reading of §1.4, computed rather than eyeballed: zeros mark active constraints.

*Way 2: CVXPY* — the model reads like the mathematics, which is why we prefer it for anything you will show another human:

```python
"""Worked Example 1 with CVXPY."""
import cvxpy as cp

x = cp.Variable(2, nonneg=True)
constraints = [2*x[0] + x[1] <= 100,     # M
               x[0] + x[1]   <= 80,      # R
               x[0]          <= 40]      # C
prob = cp.Problem(cp.Maximize(40*x[0] + 30*x[1]), constraints)
prob.solve(solver=cp.HIGHS)

print("z* =", prob.value, "  x* =", x.value)
```

```
z* = 2600.0   x* = [20. 60.]
```

Keep this CVXPY script — we extend it, rather than rewrite it, throughout §5.

---

#### Exercises

> **The Exercise LP (E).** Sections 4.2–5.8 of these exercises use one companion problem throughout, exactly as the text uses Example 1. A workshop runs two products. Product 1 earns \$5/unit, product 2 earns \$4/unit.
> - **Alloy (A):** product 1 uses 6 kg/unit, product 2 uses 4 kg/unit; 24 kg available.
> - **Finishing time (B):** product 1 uses 1 h/unit, product 2 uses 2 h/unit; 6 h available.
> - **Packing line (C):** product 1 cannot exceed 4 units.
>
> $$\max\ 5x_1 + 4x_2 \quad\text{s.t.}\quad 6x_1+4x_2 \le 24\ (A),\quad x_1+2x_2\le6\ (B),\quad x_1\le4\ (C),\quad x \ge 0.$$

**4.2.1 [H]** Solve (E) by vertex enumeration: list every vertex, mark feasibility, and give $z$ at each. State $x^\star$ and $z^\star$.

**4.2.2 [H]** Read the physics off the active set of (E): which constraints are active, what is the slack on each inactive one, and what is the one-sentence engineering summary?

**4.2.3 [P]** Solve (E) twice in Python — once with `scipy.optimize.linprog` and once with CVXPY — and print $x^\star$, $z^\star$ and the vector of slacks. Confirm both agree with your hand answer.

**4.2.4 [M]** In Example 1 the text notes that buying line capacity is "worth exactly nothing." For (E), which resource is worth nothing, and what would have to change about the *data* before it acquired positive value? Answer without computing any duals.


### 4.3 How LPs are actually solved

Both dominant algorithm families are mature enough to treat as reliable black boxes; what you need is to know which to pick and why.

**Simplex** (Dantzig, 1947) walks along *edges* of the polyhedron, from vertex to adjacent vertex, always improving, stopping when no neighbor is better. Finitely many vertices plus strict improvement gives termination. Its worst case is exponential — contrived examples exist — but in practice it is very fast, and it has one decisive practical virtue: it **warm-starts**. Re-solve after a small data change and simplex resumes from the old vertex, typically finishing in a few steps. That is exactly why simplex sits inside branch and bound (Part IV), which must solve thousands of closely related LPs.

**Interior-point methods** (Karmarkar, 1984, and the primal–dual methods that followed) cut through the *middle* of the polyhedron along a smooth path, approaching the optimal vertex in the limit. Polynomial worst case, and typically a few dozen iterations almost regardless of problem size — but each iteration solves a large linear system, and interior-point methods warm-start poorly.

> **Rule of thumb.** Interior point for one very large sparse LP. Simplex for many related LPs, or when you need an exact vertex. HiGHS — the solver behind both `scipy.linprog` and our CVXPY calls — implements both and chooses sensibly by default.

**Why we did not hand-execute simplex.** A full simplex tableau by hand is a rite of passage in some courses, but it teaches arithmetic, not optimization; you will never run it manually on a real problem, and it illuminates neither the geometry (Figure 4.1 does that) nor the economics (§5 does that). What you *should* be able to do by hand — and now can — is enumerate vertices in 2-D, identify the active set, and, after §5, extract the duals. Those are the skills that transfer.

---

#### Exercises

**4.3.1 [C]** Fill in the comparison: for simplex and interior-point, give (i) what the iterates are geometrically, (ii) the worst-case complexity, (iii) warm-start behaviour, (iv) the situation in which you would choose it.

**4.3.2 [C]** Branch and bound (Part IV) solves thousands of LPs that differ from one another by a single bound. Which algorithm belongs inside it, and why is the answer not "whichever is faster on one LP"?

**4.3.3 [P]** Solve (E) with `method="highs-ds"` (dual simplex) and `method="highs-ipm"` (interior point) and compare the returned $x^\star$, objective, and — if available in your SciPy version — the iteration counts in `res.nit`. Then re-solve the degenerate LP $\max x_1+x_2$ s.t. $x_1+x_2\le2,\ x_1\le1,\ x_2\le1$ with both, and compare the reported duals (`res.ineqlin.marginals`). What do you observe?

**4.3.4 [M]** The text declines to make you execute a simplex tableau by hand. Give the argument for that choice, and then state the three by-hand LP skills the course *does* require. Which of the three would you use to check a suspicious solver answer at 2 a.m. before a deadline?


---

## 5. Duality, shadow prices, and sensitivity

This chapter is where LP stops being a calculation and starts being an engineering tool. The dual variables are, in most industrial settings, **more valuable than the primal solution itself** — a strong claim that this chapter will earn.

*A gentle warning before we start: duality is the one topic in Part II that feels abstract on first contact. The cure is to hold onto the units. Every dual variable is a price, in objective-units per constraint-unit — dollars per machine-hour, dollars per kilogram — and every statement in this chapter is a statement about prices. If you get lost, come back to the units.*

### 5.1 The dual, read through its units

For the primal $\max c^\top x$ s.t. $Ax \le b$, $x \ge 0$, define the **dual problem**:

$$\min_y \ b^\top y \quad \text{subject to} \quad A^\top y \ge c, \quad y \ge 0.$$

Where does this come from? Ignore the algebra for a moment and read the units. A primal variable $x_j$ is "units of activity $j$" (units of mode 1, in Example 1). A dual variable $y_i$ multiplies $b_i$, which is a resource *amount* (machine-hours, kilograms) — so for $b^\top y$ to carry objective units (dollars), $y_i$ must carry units of **dollars per unit of resource $i$: a price.**

Now read the two pieces of the dual through that lens:

- The dual constraint for activity $j$ is $\sum_i a_{ij} y_i \ge c_j$: "the resources consumed by one unit of activity $j$, valued at the internal prices $y$, must be worth at least the profit $c_j$ that the activity generates." In other words: *at these prices, no activity looks like a bargain.*
- The dual objective $\min b^\top y$: "make the total valuation of the resource endowment as small as possible."

So the dual asks: **what is the cheapest set of internal prices for my resources such that no activity is worth doing at those prices?** The theorems below say that this minimal total valuation exactly equals the maximum achievable profit — the resources are "worth," in a precise sense, exactly what the best plan can extract from them.

---

#### Exercises

**5.1.1 [H]** Write the dual of the Exercise LP (E) explicitly: give the dual variables with their **units**, the dual objective, and the two dual constraints. Interpret each dual constraint as a sentence about prices.

**5.1.2 [C]** A student says "the dual variable $y_R$ is 20, so material costs \$20/kg." Correct this statement precisely. What *is* the \$20 measuring, and how does it relate to the price actually paid for material?

**5.1.3 [H]** Perform a units audit on the dual of a mass-minimization structural LP whose objective is in kg and whose constraint is "deflection $\le$ 5 mm." What are the units of that constraint's dual variable, and what sentence does its numerical value support?

**5.1.4 [M]** The dual asks: "what is the cheapest set of internal prices such that no activity is worth doing?" Explain why the *cheapest* such price set is the meaningful one — what would go wrong if you chose prices that were higher than necessary?


### 5.2 Weak duality: where certificates come from

For *any* primal-feasible $x$ and *any* dual-feasible $y$, chain two inequalities:

$$c^\top x \;\le\; (A^\top y)^\top x \;=\; y^\top (Ax) \;\le\; y^\top b.$$

The first step uses dual feasibility $A^\top y \ge c$ together with $x \ge 0$ (multiplying a valid inequality by nonnegative numbers preserves it); the middle is just transposition; the last step uses primal feasibility $Ax \le b$ together with $y \ge 0$. Conclusion:

> **Weak duality.** Every dual-feasible $y$ gives an *upper bound* $b^\top y$ on every primal-feasible objective value — in particular, on the optimum.

This humble inequality is the origin of **provable optimality**. Exhibit a primal-feasible $x$ and a dual-feasible $y$ with $c^\top x = b^\top y$, and you have *proved* both optimal — with no reference to any algorithm, checkable by anyone with a calculator. We will do exactly this for Example 1 in §5.4.

> **Strong duality.** For a feasible, bounded LP, both problems attain their optima and the optimal values are *equal*. The certificate is exactly tight — no gap.

(Part III shows what survives of this when the problem is nonlinear: weak duality survives *always*; strong duality survives under convexity. That one sentence is the skeleton of the whole course's treatment of "how do I know my answer is right.")

---

#### Exercises

**5.2.1 [H]** Reproduce the two-inequality chain $c^\top x \le (A^\top y)^\top x = y^\top(Ax) \le y^\top b$, stating at each step which feasibility condition and which sign condition you used. Where exactly does $x \ge 0$ enter, and where does $y \ge 0$?

**5.2.2 [H]** For (E), take the (non-optimal but feasible) primal point $x = (2,1)$ and the (feasible) dual point $y = (1,\,0,\,0)$. Compute $c^\top x$ and $b^\top y$, verify weak duality, and state what the pair does and does not prove.

**5.2.3 [C]** Weak duality survives without convexity; strong duality needs it. Explain what practical capability you lose when only weak duality holds, and connect this to the MIP gap of §14.3.

**5.2.4 [P]** Write a function `certificate(A, b, c, x, y, tol=1e-8)` that checks primal feasibility, dual feasibility, and whether $c^\top x = b^\top y$, returning a verdict string. Test it on (E) with the optimal pair, then with a deliberately perturbed $y$.


### 5.3 Complementary slackness — both directions

At a primal–dual optimal pair, for each constraint $i$ and each variable $j$:

$$\underbrace{y_i^\star\,\big(b_i - a_i^\top x^\star\big) = 0}_{\text{constraint side}}\,, \qquad \underbrace{x_j^\star\,\big((A^\top y^\star)_j - c_j\big) = 0}_{\text{variable side}}.$$

In words:

- **Constraint side:** a resource you have not run out of is worthless at the margin. *Slack $\Rightarrow$ zero price.* (If you have spare kilograms, one more kilogram adds nothing.)
- **Variable side:** an activity you actually run must break even *exactly* at the internal prices. *Used $\Rightarrow$ its dual constraint is tight.* (If mode 1 generated more profit than its resources are worth, the prices would be understating scarcity; the dual's minimization forbids that.)

Both directions are needed to solve for the duals by hand — most introductions state only the first, and then duals seem to appear by magic. Watch what happens when we use both.

---

#### Exercises

**5.3.1 [C]** State both complementary-slackness conditions and translate each into a sentence of plain economics. Which one do introductory treatments usually omit, and why does omitting it make duals seem to "appear by magic"?

**5.3.2 [H]** For an LP with optimal $x^\star = (0,\,7,\,3)$ and a constraint set in which constraints 1 and 3 are active and constraint 2 has slack 5, write down everything complementary slackness tells you about $y^\star$ and about the dual constraints, *before* solving anything.

**5.3.3 [H]** Use both directions to compute the duals of (E) by hand from $x^\star=(3,1.5)$. Show the two-equation system, solve it, and verify the certificate $b^\top y = z^\star$.

**5.3.4 [P]** Verify your 5.3.3 answer numerically by reading `constraint.dual_value` in CVXPY, and *also* by the two-sided perturbation test on the alloy supply ($b_A = 24 \pm 1$). Do all three agree?


### 5.4 Worked Example 1, continued — computing the duals by hand, then by machine

From §4.2: $x^\star = (20, 60)$; constraints $M$ and $R$ active; $C$ slack.

**Constraint side.** $C$ has slack ($20 < 40$), so its price is zero:

$$y_C = 0.$$

**Variable side.** Both $x_1 > 0$ and $x_2 > 0$, so *both* dual constraints hold with equality. The columns of $A$ for $x_1$ and $x_2$ are $(2, 1, 1)$ and $(1, 1, 0)$:

$$2y_M + y_R + y_C = 40, \qquad y_M + y_R = 30.$$

Substituting $y_C = 0$ and subtracting the second from the first: $y_M = 10$, and then $y_R = 20$.

$$\boxed{\,y_M = 10, \qquad y_R = 20, \qquad y_C = 0.\,}$$

**Check the certificate** (§5.2 in action). Dual feasibility: all $y \ge 0$ ✓. Dual objective:

$$b^\top y = 100(10) + 80(20) + 40(0) = 1000 + 1600 = 2600 = z^\star.\ \checkmark$$

Primal and dual values agree, so *both are proved optimal* — independently of how we found them. You have just written your first optimality certificate.

**These three numbers are the most decision-relevant output of the whole model:**

- $y_M = 10$: an extra machine-hour is worth \$10 of profit. Overtime priced below \$10/h is profitable; above, it is not. A number your manager can act on this afternoon.
- $y_R = 20$: an extra kilogram of material is worth \$20 — your maximum willingness to pay for additional supply, *over and above* the material cost already embedded in the \$40/\$30 margins.
- $y_C = 0$: extra line capacity is worth nothing. Do not buy it. (This is complementary slackness speaking: the constraint is slack.)

**Verify $y_M$ directly, because you should never trust a marginal value you haven't tested.** With 101 machine-hours, the optimum moves to the new intersection of $M$ and $R$: solving $2x_1 + x_2 = 101$, $x_1 + x_2 = 80$ gives $x^\star = (21, 59)$, so $z = 40(21) + 30(59) = 840 + 1770 = 2610$. Exactly \$10 more. ✓

**By machine.** Every LP solver computes the duals as a by-product (they are, roughly, the multipliers its own optimality test uses). In CVXPY, each constraint object carries its dual value after solving:

```python
"""Example 1: extract shadow prices, verify the certificate, test y_M."""
import cvxpy as cp

x = cp.Variable(2, nonneg=True)
cons = [2*x[0] + x[1] <= 100,     # M
        x[0] + x[1]   <= 80,      # R
        x[0]          <= 40]      # C
prob = cp.Problem(cp.Maximize(40*x[0] + 30*x[1]), cons)
prob.solve(solver=cp.HIGHS)

names = ["M", "R", "C"]
b     = [100, 80, 40]
print(f"z* = {prob.value:.1f}")
for nm, cn in zip(names, cons):
    print(f"  y_{nm} = {cn.dual_value:.4f}")

certificate = sum(bi * cn.dual_value for bi, cn in zip(b, cons))
print("dual objective b^T y =", certificate)          # must equal z*

# two-sided test of y_M: re-solve with b_M = 101 and 99
for bM in (101, 99):
    x2 = cp.Variable(2, nonneg=True)
    p2 = cp.Problem(cp.Maximize(40*x2[0] + 30*x2[1]),
                    [2*x2[0] + x2[1] <= bM, x2[0] + x2[1] <= 80, x2[0] <= 40])
    p2.solve(solver=cp.HIGHS)
    print(f"b_M = {bM}:  z* = {p2.value:.1f}   (change {p2.value - prob.value:+.1f})")
```

```
z* = 2600.0
  y_M = 10.0000
  y_R = 20.0000
  y_C = 0.0000
dual objective b^T y = 2600.0
b_M = 101:  z* = 2610.0   (change +10.0)
b_M = 99:  z* = 2590.0   (change -10.0)
```

The last two lines are the **two-sided perturbation test**: the value moves by $+10$ per hour added *and* $-10$ per hour removed. Both sides agreeing with the reported dual is what "the shadow price is \$10/h" really means. Hold onto this test — §5.8 shows a case where the two sides *disagree*, and where trusting the reported number would cost real money.

---

#### Exercises

**5.4.1 [M]** Write the three decision sentences that the duals of (E) support — one per resource — each phrased as advice a manager could act on today, with a number and a unit.

**5.4.2 [H]** Your supplier offers 5 extra kg of alloy at a premium of \$0.60/kg over contract. Using only $y_A$, decide whether to accept, and estimate the profit change. Then state the one assumption you have made that §5.6 will force you to check.

**5.4.3 [P]** Implement the **two-sided perturbation test** as a reusable function `two_sided(solve_fn, nominal, i, delta)` that re-solves an LP with $b_i$ increased and decreased by `delta` and returns both one-sided rates. Apply it to all three constraints of (E) with $\delta = 1$ and tabulate results against the reported duals.

**5.4.4 [C]** The text says the duals are "the most decision-relevant output of the whole model" — more than $x^\star$ itself. Give two reasons this is true in an industrial setting, and one situation in which the primal solution is definitely the more important output.


### 5.5 Reduced cost: pricing a new activity

Someone proposes a third production mode with margin \$25/unit, consuming 1 machine-hour and 1 kg of material. Worth introducing? You do not need to rebuild or re-solve the model — you already own the prices.

Value the new mode's consumption at the shadow prices: $1 \cdot y_M + 1 \cdot y_R = 10 + 20 = 30$ dollars of scarce capacity per unit. Its **reduced cost** — margin minus the opportunity cost of what it consumes — is

$$25 - 30 = -5 < 0.$$

The mode would burn \$30 of scarce capacity to generate \$25 of margin. **Reject it**, and note that you reached this conclusion with one multiplication. This is exactly how large LPs are extended one candidate activity at a time, and it is the engine of *column generation*, the technique behind airline crew scheduling and cutting-stock optimization at industrial scale.

Confirm with the machine (and this is worth doing once, to believe it):

```python
import cvxpy as cp
x = cp.Variable(3, nonneg=True)                 # third variable: the new mode
prob = cp.Problem(cp.Maximize(40*x[0] + 30*x[1] + 25*x[2]),
                  [2*x[0] + x[1] + x[2] <= 100,
                   x[0] + x[1] + x[2]   <= 80,
                   x[0]                 <= 40])
prob.solve(solver=cp.HIGHS)
print("z* =", prob.value, "  x* =", x.value)    # z* = 2600.0, x3 = 0
```

```
z* = 2600.0   x* = [20. 60.  0.]
```

The solver, given the option, uses zero units of the new mode — exactly as the reduced cost predicted, without solving anything.

---

#### Exercises

**5.5.1 [H]** A third product is proposed for (E): margin \$3/unit, consuming 2 kg of alloy and 1 h of finishing, no packing slot. Compute its reduced cost from the duals and decide whether it should enter the plan.

**5.5.2 [P]** Verify 5.5.1 by re-solving (E) with the third product included. Report the new $z^\star$ and $x^\star$, and check the profit increase against what the reduced cost predicted per unit. Why is the total increase *not* simply "reduced cost × any number of units"?

**5.5.3 [H]** A fourth candidate has margin \$4/unit and uses 3 kg of alloy and 2 h of finishing. Compute its reduced cost. Then find the minimum margin at which it would become attractive.

**5.5.4 [M]** Explain how reduced-cost pricing scales to problems with millions of candidate activities (column generation), and name two industries where this is standard practice. What is the one thing you must be able to do cheaply for the technique to work?


### 5.6 Right-hand-side ranging: how far a shadow price is valid

Here is the caveat students most often miss: **a shadow price is a slope, and slopes of piecewise-linear functions are only valid until the next kink.**

In Example 1, while $M$ and $R$ are both active, the optimum tracks their intersection. Solve it as a function of the machine-hours $b_M$: from $2x_1 + x_2 = b_M$ and $x_1 + x_2 = 80$,

$$x_1 = b_M - 80, \qquad x_2 = 160 - b_M.$$

This solution stays feasible (and the same pair of constraints stays active) only while

$$x_1 \ge 0 \;\Rightarrow\; b_M \ge 80, \qquad x_1 \le 40 \;\Rightarrow\; b_M \le 120, \qquad x_2 \ge 0 \;\Rightarrow\; b_M \le 160.$$

The binding pair is $80 \le b_M \le 120$. Inside that interval, $y_M = 10$ exactly; outside it, the active set changes and so does the price. At $b_M = 120$ the plan reaches $x = (40, 40)$, capacity $C$ becomes active, and additional machine-hours become worthless — the price drops to 0.

![RHS ranging](figures/fig5_ranging.png)

*Figure 5.1 — The optimal profit $z^\star(b_M)$, computed by re-solving the LP across a sweep of $b_M$ (script below). It is piecewise linear and concave, with the shadow price $y_M = 10$ as the slope of the middle segment only (shaded band, $80 \le b_M \le 120$). Note there is also a kink at $b_M = 80$: below it, machine time is so scarce that the plan changes character again, and the slope there is steeper (an hour is worth \$30). Shadow prices are exact — but local.*

```python
"""Sweep b_M and plot the optimal value function."""
import numpy as np, matplotlib.pyplot as plt
from scipy.optimize import linprog

bs = np.linspace(60, 160, 200)
zs = [-linprog([-40, -30], A_ub=[[2, 1], [1, 1], [1, 0]], b_ub=[bm, 80, 40],
               bounds=[(0, None)]*2, method="highs").fun for bm in bs]
plt.plot(bs, zs); plt.xlabel("$b_M$ (machine-hours)"); plt.ylabel("$z^*$")
plt.title("Optimal value vs. machine-hours: piecewise linear, concave")
plt.savefig("value_function.png", dpi=120)
```

> **Rule.** $z^\star$ is a piecewise-linear concave function of the right-hand sides (for a maximization). Shadow prices are the slopes of its pieces: exact, but only within a range that every solver will report if asked. **Never extrapolate a shadow price to a large change; for a large change, re-solve.** Re-solving costs milliseconds. Extrapolating a \$10/h price into a decision to buy 200 hours costs real money, because most of those hours are worth \$0.

---

#### Exercises

**5.6.1 [H]** For (E), derive the range of alloy supply $b_A$ over which $y_A = 0.75$ remains valid. Track the optimum as a function of $b_A$ while $A$ and $B$ stay active, then impose every remaining feasibility condition.

**5.6.2 [H]** Using your range, compute the *true* profit gain from buying 5 extra kg of alloy, and compare with the naive extrapolation $5 \times 0.75 = \$3.75$. What is the value of the fifth kilogram?

**5.6.3 [P]** Sweep $b_A$ from 8 to 40 and plot (or tabulate) $z^\star(b_A)$. Identify every kink, state the slope on each segment, and confirm the function is piecewise linear and concave.

**5.6.4 [M]** Your manager asks whether to sign a contract for 200 extra kg of alloy per month at \$0.40/kg. Explain — in terms a manager would accept — why the shadow price cannot answer this question, and state the correct procedure.


### 5.7 Cost ranging: how far the *plan* is valid

Managers rarely ask "what if I had one more kilogram." They ask: *"the margin on mode 1 is dropping from \$40 to \$34 — do we change the plan?"* That is **cost ranging**, and it is a different calculation from §5.6: there the data $b$ moved and we tracked the value; here the objective $c$ moves and we track the *plan*.

The geometric condition is clean, and Figure 4.1 already showed it: the vertex $(20,60)$ stays optimal exactly while the objective vector $c$ lies inside the **cone spanned by the outward normals of the two active constraints**, $a_M = (2,1)$ and $a_R = (1,1)$:

$$c = \alpha\,(2,1) + \beta\,(1,1), \qquad \alpha, \beta \ge 0.$$

(Those coefficients $\alpha, \beta$ are precisely the shadow prices — this is the same linear system as §5.4, read as a condition on $c$ instead of solved for $y$. Duality keeps showing up because it *is* the geometry.)

*Range for $c_1$, holding $c_2 = 30$.* Solve $2\alpha + \beta = c_1$ and $\alpha + \beta = 30$: $\alpha = c_1 - 30$, $\beta = 60 - c_1$. Nonnegativity of both requires

$$\boxed{30 \le c_1 \le 60}.$$

*Range for $c_2$, holding $c_1 = 40$.* Solve $2\alpha + \beta = 40$, $\alpha + \beta = c_2$: $\alpha = 40 - c_2$, $\beta = 2c_2 - 40$, giving

$$\boxed{20 \le c_2 \le 40}.$$

*Check the endpoints by machine* — sweeping $c_1$ and watching where the plan jumps:

```python
import numpy as np
from scipy.optimize import linprog
A, b = [[2, 1], [1, 1], [1, 0]], [100, 80, 40]
for c1 in [29, 30, 40, 60, 61]:
    r = linprog([-c1, -30], A_ub=A, b_ub=b, bounds=[(0, None)]*2, method="highs")
    print(f"c1 = {c1:2d}:  x* = {np.round(r.x, 1)},  z* = {-r.fun:.0f}")
```

```
c1 = 29:  x* = [ 0. 80.],  z* = 2400
c1 = 30:  x* = [20. 60.],  z* = 2400
c1 = 40:  x* = [20. 60.],  z* = 2600
c1 = 60:  x* = [40. 20.],  z* = 3000
c1 = 61:  x* = [40. 20.],  z* = 3040
```

Inside $[30, 60]$ the plan is $(20, 60)$; just outside either end it jumps to a neighboring vertex. (At an endpoint two vertices tie, and the solver may report either — the values agree.) Exactly as the cone condition predicted. ✓

**How to use this.** The proposed drop from \$40 to \$34 lies inside $[30, 60]$, so **the production plan does not change** — you still make $(20, 60)$; only the profit changes, by $20 \times (34 - 40) = -\$120$. That is a far more useful answer than a re-solved number alone, because it tells the manager *the decision is robust*, not just what the new profit is. "Nothing about our operations needs to change" is often the most valuable sentence an analyst can say.

---

#### Exercises

**5.7.1 [C]** In one or two sentences each, distinguish RHS ranging from cost ranging: what data moves, what is held fixed, and what quantity you are tracking in each case.

**5.7.2 [H]** For (E), derive the range of $c_1$ (holding $c_2 = 4$) over which the plan $x^\star = (3,1.5)$ remains optimal, using the cone-of-normals condition. Then derive the range of $c_2$ holding $c_1 = 5$.

**5.7.3 [H]** Verify your $c_1$ range by the slope argument instead: write the slopes of the two active constraint lines and of the objective level line, and state the inequality that pins the vertex.

**5.7.4 [P]** Sweep $c_1$ over $\{1.9, 2, 5, 6, 6.1\}$, print $x^\star$ and $z^\star$, and confirm the plan changes exactly at your computed endpoints. Explain what happens *at* an endpoint.

**5.7.5 [M]** Product 1's margin is about to fall from \$5.00 to \$4.20 because of an alloy price rise. Give the complete answer you would send to the production manager: does the plan change, what is the new profit, and what is the single most useful sentence in your reply?


### 5.8 Worked Example 2 — degeneracy, or: shadow prices are not always unique

Everything in §5.4–5.7 assumed a well-behaved optimal vertex. Here is the trap — small enough to verify entirely by hand, common enough to cost companies real money.

$$\max\ x_1 + x_2 \quad \text{s.t.} \quad x_1 + x_2 \le 2, \quad x_1 \le 1, \quad x_2 \le 1, \quad x \ge 0.$$

The optimum is obviously $x^\star = (1,1)$, $z^\star = 2$. But count the active constraints there: $x_1 + x_2 = 2$ ✓, $x_1 = 1$ ✓, $x_2 = 1$ ✓ — **three** active constraints in a **two**-dimensional problem. The vertex is over-determined: any two of the three constraints already pin it down, and the third passes through the same point redundantly. This is **primal degeneracy**. It sounds exotic; it is not — it arises whenever constraints happen to intersect at a common point, which redundant or symmetric modeling produces *constantly* in real models.

Now build the dual: $\min\ 2y_1 + y_2 + y_3$ s.t. $y_1 + y_2 \ge 1$, $y_1 + y_3 \ge 1$, $y \ge 0$. Check these four candidates by direct substitution:

| $y = (y_1, y_2, y_3)$ | dual feasible? | dual objective $2y_1 + y_2 + y_3$ |
|---|---|---|
| $(1, 0, 0)$ | yes | 2 |
| $(0, 1, 1)$ | yes | 2 |
| $(0.5,\ 0.5,\ 0.5)$ | yes | 2 |
| $(0.25,\ 0.75,\ 0.75)$ | yes | 2 |

All four achieve dual objective $2 = z^\star$, so by the certificate argument of §5.2, **all four are optimal duals**. The "shadow price of the joint resource $x_1 + x_2 \le 2$" is 1 according to the first, 0 according to the second, and 0.5 according to the third. Two different solvers — or the same solver with different options — will legitimately report different prices for the same model. Watch it happen:

```python
"""Degenerate LP: the solver's reported duals are just one valid choice."""
import cvxpy as cp

x = cp.Variable(2, nonneg=True)
cons = [x[0] + x[1] <= 2, x[0] <= 1, x[1] <= 1]
prob = cp.Problem(cp.Maximize(x[0] + x[1]), cons)
prob.solve(solver=cp.HIGHS)
print("z* =", prob.value, " duals:", [float(c.dual_value) for c in cons])

# the honest answer: perturb b1 both ways and re-solve
for db in (+0.1, -0.1):
    xp = cp.Variable(2, nonneg=True)
    pp = cp.Problem(cp.Maximize(xp[0] + xp[1]),
                    [xp[0] + xp[1] <= 2 + db, xp[0] <= 1, xp[1] <= 1])
    pp.solve(solver=cp.HIGHS)
    print(f"b1 = 2{db:+.1f}:  z* = {pp.value:.2f}   one-sided rate = {(pp.value - 2)/db:+.2f}")
```

```
z* = 2.0  duals: [0.0, 1.0, 1.0]
b1 = 2+0.1:  z* = 2.00   one-sided rate = +0.00
b1 = 2-0.1:  z* = 1.90   one-sided rate = +1.00
```

Two things to notice. First, HiGHS happened to report $(0, 1, 1)$ — the *second* row of our table; another solver could report the first. Second — and this is the honest answer — the perturbation test shows the two one-sided rates **differ**: relaxing the constraint gains you *nothing* (rate 0), while tightening it costs *1 per unit* (rate 1).

**Which reported price is right?** Neither — *the question is malformed.* Look at the true value function. Since $x_1 \le 1$ and $x_2 \le 1$ cap $z$ at 2 no matter how large $b_1$ grows:

$$z^\star(b_1) = \min(b_1,\ 2) \qquad \text{for } b_1 \ge 0.$$

![Degenerate kink](figures/fig5_kink.png)

*Figure 5.2 — The value function of Example 2 has a kink exactly at the nominal $b_1 = 2$. Left derivative 1, right derivative 0. No single number can be "the slope" at a kink; every value in the interval $[0, 1]$ is a valid* subgradient *(a generalized slope), and every optimal dual's $y_1$ lies in exactly that interval — as the table shows. The solver is not wrong; the question "what is the shadow price" has no unique answer here.*

> **What to do about it in practice — three habits.**
> 1. **Detect it.** If the number of active constraints exceeds the number of variables (in the relevant subspace), suspect degeneracy. Many solvers also flag it directly.
> 2. **Never build a business case on a single reported shadow price from a degenerate model.** Get the honest answer by *re-solving* with $b_i$ perturbed up and down by a realistic amount — the six-line loop above. Two extra solves cost milliseconds and give you both one-sided rates, which is what you actually wanted to know.
> 3. **Prefer the two-sided test whenever a shadow price drives a real decision** — degenerate or not. It is the only version that cannot mislead you, and you have now seen why.

This is not an exotic corner case. Degeneracy is the *normal* condition of large industrial LPs, and uncritical use of reported shadow prices is a genuine, documented source of bad capital-expenditure decisions.

---

#### Exercises

**5.8.1 [H]** Consider $\max\ x_1 + 2x_2$ s.t. $x_1 + x_2 \le 3$ (①), $x_2 \le 2$ (②), $x_1 + 2x_2 \le 5$ (③), $x \ge 0$. Find $x^\star$ and $z^\star$, count the active constraints, and state whether the optimum is degenerate and why.

**5.8.2 [H]** Write the dual of 5.8.1. Then check each candidate $y = (1,1,0)$, $(0,0,1)$, $(0.5,0.5,0.5)$, $(1,0,0)$ for dual feasibility and compute its objective. Which are optimal duals, and what does that imply about "the" shadow price of constraint ①?

**5.8.3 [P]** Solve 5.8.1 in CVXPY, print the reported duals, and then run the two-sided perturbation test on constraint ① with $\delta = 0.1$. Report both one-sided rates and explain the discrepancy geometrically.

**5.8.4 [C]** Write down the value function $z^\star(b_1)$ for 5.8.1 explicitly for $b_1 \ge 0$, and use it to explain why the question "what is the shadow price of ①?" is malformed. What is the correct mathematical object, and what interval does it occupy here?

**5.8.5 [M]** State the three practical habits from §5.8 and apply them: you are handed a degenerate industrial LP and asked whether to invest \$2 M in relieving constraint ①. Describe exactly what you would compute and what you would report.


---

## 6. Networks: when integrality is free

Part IV will show that integer constraints are, in general, *expensive* — exponentially so. This chapter identifies a large and practically important family of problems where they cost **nothing at all**. Knowing this family is worth real money: it is the difference between an LP that solves in milliseconds and a branch-and-bound tree that runs all night — on the *same problem*.

### 6.1 Total unimodularity

A matrix $A$ is **totally unimodular (TU)** if every square submatrix of it has determinant $0$, $+1$, or $-1$.

> **Theorem.** If $A$ is TU and $b$ is a vector of integers, then every vertex of the polyhedron $\{x : Ax \le b,\ x \ge 0\}$ has integer coordinates.

The reason is Cramer's rule, and it fits in two sentences. A vertex is the solution of a square subsystem of the constraints, so each of its coordinates is a ratio of two determinants; the denominator determinant comes from a submatrix of $A$, hence is $\pm 1$ (it cannot be 0 for an invertible subsystem). Integers divided by $\pm 1$ are integers.

Combine this with the fundamental theorem of LP (§4.1) — *an optimal vertex exists* — and you get the payoff:

> **If your constraint matrix is TU and the data is integral, then solving the LP relaxation solves the integer problem exactly.** No branching, no gap, LP speed.

And the crucial recognition fact: **the node–arc incidence matrix of a directed graph is TU**, as is the incidence matrix of a bipartite graph. So this theorem applies to an entire family of models that engineers meet constantly — anything that is secretly a *flow on a network*.

---

#### Exercises

**6.1.1 [C]** Define total unimodularity, state the integrality theorem, and reproduce the two-sentence Cramer's-rule argument for why TU forces integral vertices. Where is the integrality of $b$ used?

**6.1.2 [P]** Write `is_TU(A)` that brute-forces every square submatrix and returns whether all determinants are in $\{0,\pm1\}$ (plus a counterexample if not). Test it on (a) the node–arc incidence matrix of the directed graph with arcs $(0,1),(0,2),(1,2),(1,3),(2,3)$; (b) the $6\times9$ constraint matrix of the $3\times3$ assignment problem; (c) the triangle matrix $\begin{pmatrix}1&1&0\\1&0&1\\0&1&1\end{pmatrix}$.

**6.1.3 [H]** For the triangle matrix in 6.1.2(c) — the edge-incidence matrix of a 3-cycle — the LP $\max \mathbf{1}^\top x$ s.t. $Tx \le \mathbf{1}$, $x \ge 0$ is the *fractional matching* problem. Solve it by hand and compare with the best integer solution. What is the gap, and what property of the graph causes it?

**6.1.4 [C]** Why is the node–arc incidence matrix of *any* directed graph TU, whereas the edge–node incidence matrix of an *undirected* graph is TU only when the graph is bipartite? State the practical recognition rule you take from this.


### 6.2 Worked Example 3 — the assignment problem

Three machines must be assigned to three tasks, one each. The cost $C_{ij}$ of running machine $i$ on task $j$:

|  | T1 | T2 | T3 |
|---|---|---|---|
| **M1** | 9 | 2 | 7 |
| **M2** | 6 | 4 | 3 |
| **M3** | 5 | 8 | 1 |

Formulate with $x_{ij} = 1$ if machine $i$ does task $j$, else 0:

$$\min \sum_{i,j} C_{ij}\, x_{ij} \quad \text{s.t.} \quad \sum_j x_{ij} = 1 \ \ \forall i \ \ \text{(each machine does one task)}, \quad \sum_i x_{ij} = 1 \ \ \forall j \ \ \text{(each task gets one machine)}, \quad x_{ij} \ge 0.$$

Notice what is **absent**: any statement that $x_{ij}$ must be binary. We deliberately did not write it, because we do not need it. The constraint matrix here is the incidence matrix of a bipartite graph (machines on one side, tasks on the other), hence TU — so every vertex of this polytope is integral. In fact the vertices are exactly the permutation matrices (this is the Birkhoff–von Neumann theorem), and an LP solver, which always returns a vertex, returns a genuine assignment.

**Solve by hand: enumerate.** With $3! = 6$ possible assignments, list them all:

| Assignment | Cost |
|---|---|
| M1→T1, M2→T2, M3→T3 | $9+4+1 = 14$ |
| M1→T1, M2→T3, M3→T2 | $9+3+8 = 20$ |
| **M1→T2, M2→T1, M3→T3** | $2+6+1 = \mathbf{9}$ |
| M1→T2, M2→T3, M3→T1 | $2+3+5 = 10$ |
| M1→T3, M2→T1, M3→T2 | $7+6+8 = 21$ |
| M1→T3, M2→T2, M3→T1 | $7+4+5 = 16$ |

Unique optimum: cost **9**, with M1→T2, M2→T1, M3→T3. (Enumeration dies fast: $10! \approx 3.6$ million, $20! \approx 2.4 \times 10^{18}$. The LP does not care.)

**By machine — twice.** First, the pure LP with *no* integrality, to watch the theorem work; second, the dedicated assignment routine you would use in practice.

```python
"""Assignment: the LP relaxation returns 0/1 values on its own."""
import numpy as np, cvxpy as cp
from scipy.optimize import linear_sum_assignment

C = np.array([[9, 2, 7],
              [6, 4, 3],
              [5, 8, 1]])

# --- LP relaxation: continuous x, no binary declaration anywhere ---
X = cp.Variable((3, 3), nonneg=True)
prob = cp.Problem(cp.Minimize(cp.sum(cp.multiply(C, X))),
                  [cp.sum(X, axis=1) == 1,      # each machine: one task
                   cp.sum(X, axis=0) == 1])     # each task: one machine
prob.solve(solver=cp.HIGHS)
print("LP optimal cost:", prob.value)
print("LP solution (continuous variables!):")
print(np.round(X.value, 6))

# --- the specialist: Hungarian-algorithm routine in SciPy ---
rows, cols = linear_sum_assignment(C)
pairs = [(int(i), int(j)) for i, j in zip(rows, cols)]
print("linear_sum_assignment:", pairs, " cost:", C[rows, cols].sum())
```

```
LP optimal cost: 9.0
LP solution (continuous variables!):
[[0. 1. 0.]
 [1. 0. 0.]
 [0. 0. 1.]]
linear_sum_assignment: [(0, 1), (1, 0), (2, 2)]  cost: 9
```

Look at the LP solution: **pure zeros and ones**, from a solver that was never told about integers. That is total unimodularity working — the theorem of §6.1, live.

**The trap this example avoids: greedy.** A tempting heuristic — take the globally cheapest entry ($C_{33} = 1$), then the cheapest remaining ($C_{12} = 2$), then whatever is left ($C_{21} = 6$) — gives $1 + 2 + 6 = 9$. Correct here, *by luck*. Change one number, $C_{21}$ from 6 to 20, and:

```python
import numpy as np
from scipy.optimize import linear_sum_assignment

C2 = np.array([[9, 2, 7],
               [20, 4, 3],      # C[1,0]: 6 -> 20
               [5, 8, 1]])
rows, cols = linear_sum_assignment(C2)
print("optimal:", [(int(i), int(j)) for i, j in zip(rows, cols)], " cost:", C2[rows, cols].sum())
# greedy: picks C33=1, then C12=2, forced into C21=20  ->  cost 23
```

```
optimal: [(0, 1), (1, 2), (2, 0)]  cost: 10
```

Greedy pays 23; the optimum is 10 (M1→T2, M2→T3, M3→T1: $2+3+5$), reached by *declining* the tempting cheap cell $C_{33}=1$. Greedy is not an algorithm for this problem. The LP is.

---

#### Exercises

**6.2.1 [H]** Four technicians must be assigned to four jobs, one each, at costs
$$C = \begin{pmatrix}13&4&7&6\\1&11&5&4\\6&7&2&8\\1&3&5&9\end{pmatrix}.$$
Find the optimal assignment and its cost. (You need not enumerate all 24 permutations if you argue efficiently — but state your reasoning.)

**6.2.2 [P]** Solve 6.2.1 three ways: (i) as an LP with continuous nonnegative $x_{ij}$ and *no* integrality declaration; (ii) with `scipy.optimize.linear_sum_assignment`; (iii) with binary variables. Compare costs and confirm the LP returned a 0/1 matrix. Which of the three would you use on a $2000\times2000$ instance, and why?

**6.2.3 [H]** Apply the greedy heuristic to 6.2.1 (repeatedly take the cheapest remaining cell, deleting its row and column). Report greedy's assignment and cost, and the gap to the optimum. Identify the exact decision at which greedy went wrong.

**6.2.4 [M]** Explain to a colleague why writing `boolean=True` in the assignment model is not *wrong* but is *wasteful*, and what specifically it costs. Then state the one check you would run to confirm the LP route is safe on a new problem.


### 6.3 The family worth recognizing

All of the following have TU structure and therefore integral LP optima:

| Model | What it does |
|---|---|
| **Shortest path** | cheapest route through a network |
| **Max flow** | greatest throughput from source to sink |
| **Min-cost flow** | ship supply to demand at least cost — the general case containing all the others |
| **Transportation** | min-cost flow on a bipartite graph (plants → customers) |
| **Assignment** | transportation with unit supplies and demands (§6.2) |
| **Bipartite matching** | pair up members of two groups |

> **Recognition habit.** Before adding integer variables to any model, ask: *is this really a flow on a network?* Does every variable represent movement along an arc, and does every constraint say "what comes in equals what goes out" or "this row/column sums to a fixed amount"? If yes: drop the integrality, solve an LP, and collect the integer answer for free. This single observation regularly turns an intractable model into a fast one.

Two honest limits, so the habit does not overreach. First, adding *side constraints* — a shared budget across arcs, a capacity coupling two paths — generally **destroys** total unimodularity; then you genuinely need Part IV. Second, the theorem needs integral $b$: fractional supplies or demands give fractional vertices even with a TU matrix. When in doubt, just solve the LP and look at the answer: if it came back integral, you are done; if not, you have lost nothing, and Part IV's branch and bound will start from exactly this relaxation anyway.

---

#### Exercises

**6.3.1 [C]** List the six model types in the §6.3 family and identify which one contains all the others as special cases. For each of the other five, state what specialization produces it.

**6.3.2 [M]** Apply the recognition habit to three models: (a) route a delivery van through 15 cities returning to base; (b) ship product from 3 plants to 7 warehouses at minimum freight cost; (c) assign 40 nurses to 40 shifts respecting preferences. Which are TU flow structures (integrality free) and which are not? For any that is not, name the offending feature.

**6.3.3 [P]** Demonstrate both honest limits of §6.3.
(i) *Fractional data:* solve the $2\times2$ transportation LP with costs $\begin{pmatrix}1&2\\3&1\end{pmatrix}$, supplies $(1.5,\,1.5)$ and demands $(1,\,2)$. Is the answer integral?
(ii) *Side constraint:* add to the $3\times3$ assignment of §6.2 a shared resource constraint $\sum_{ij} r_{ij}x_{ij} \le 5.5$ with $r = \begin{pmatrix}1&2&3\\4&3&2\\1&4&4\end{pmatrix}$. Solve the LP relaxation and the binary model; report both objectives and the LP solution.

**6.3.4 [C]** After adding a side constraint that destroys TU, the text says "you have lost nothing" by trying the LP first. Justify that claim precisely — what do you still get from the fractional LP solution, and how does Part IV use it?


---

## Checkpoint — Part II

You should now be able to:

- state and use the fundamental theorem of LP, and explain why LP optima are "extreme" rather than balanced;
- solve a 2-variable LP by hand via vertex enumeration, and by machine via `scipy.linprog` and CVXPY, and read the active set from the slacks;
- write down the dual of $\max c^\top x,\ Ax \le b,\ x \ge 0$ and interpret every dual variable as a price with units;
- prove weak duality in three steps, and use a matching primal–dual pair as an optimality certificate;
- state both directions of complementary slackness and use them to compute duals by hand at a nondegenerate vertex;
- compute a reduced cost to accept or reject a proposed new activity without re-solving;
- explain why shadow prices have validity ranges, and compute an RHS range and a cost range by hand for a 2-D problem;
- recognize degeneracy, explain via the kinked value function why shadow prices then fail to be unique, and run the two-sided perturbation test;
- define total unimodularity, state what it buys, and recognize the network-flow family in a model dressed up in application language.

## Self-test — Part II

**Q1.** For the LP $\max\ 3x_1 + 5x_2$ s.t. $x_1 \le 4$, $2x_2 \le 12$, $3x_1 + 2x_2 \le 18$, $x \ge 0$: find the optimum by vertex enumeration, identify the active set, and compute all three shadow prices by hand using both directions of complementary slackness. Verify your certificate.

**Q2.** In Example 1, a broker offers to sell you 50 additional kilograms of material at \$18/kg (recall $y_R = 20$). A colleague says: "\$18 < \$20, buy all 50." What is wrong with this reasoning, and what should you do instead?

**Q3.** Your solver reports a shadow price of \$140/unit on a warehouse-capacity constraint, and management is about to approve an expansion based on it. What two checks from this Part do you run before signing off?

**Q4.** True or false: "If some variables of an LP-with-integer-variables must be integers, branch and bound is always required." Explain.

**Q5.** A logistics model assigns 40 trucks to 40 routes, one each, minimizing total cost. A consultant proposes a genetic algorithm. What do you say?

**Answers.**

**A1.** Vertices: $(0,0)$ z=0; $(4,0)$ z=12; $(4,3)$ z=27 (from $x_1 = 4$ and $3x_1+2x_2=18$); $(2,6)$ z=36 (from $2x_2 = 12$ and $3x_1+2x_2=18$); $(0,6)$ z=30. Optimum $x^\star = (2,6)$, $z^\star = 36$; active: constraints 2 and 3; constraint 1 slack ($x_1 = 2 < 4$). Duals: slack constraint gives $y_1 = 0$ (constraint side). Both variables positive, so both dual constraints are tight (variable side): columns are $(1,0,3)$ and $(0,2,2)$, so $y_1 + 3y_3 = 3 \Rightarrow y_3 = 1$, and $2y_2 + 2y_3 = 5 \Rightarrow y_2 = 1.5$. Certificate: $b^\top y = 4(0) + 12(1.5) + 18(1) = 36 = z^\star$ ✓. (This is the classic Wyndor problem; if your numbers differ, re-read §5.4.)

**A2.** Two errors. First, \$20 is valid only within the RHS range (§5.6); adding 50 kg to the 80 available is a *large* change that almost certainly crosses a kink, after which extra material is worth less (eventually machine time runs out and material is worth \$0 at the margin). Second, even the comparison at the margin should be verified two-sidedly (§5.8) in case of degeneracy. Correct action: re-solve with $b_R = 130$ (and a few intermediate values) and compute the actual profit gain; buy only up to the quantity where marginal value still exceeds \$18.

**A3.** (1) Degeneracy check with the two-sided perturbation test (§5.8): re-solve with capacity perturbed up and down; if the one-sided rates differ, the reported \$140 is one of many valid subgradients and may massively overstate the value of *expansion* (the relevant direction is *up*). (2) Ranging (§5.6): even if non-degenerate, find how many units of expansion the \$140 rate is valid for; an expansion project usually adds far more capacity than the range covers. In both cases: re-solve at the actually proposed capacity.

**A4.** False. If the constraint matrix is totally unimodular and the data integral — as in assignment, transportation, shortest path, max flow, min-cost flow — the LP relaxation has integral vertices, and plain LP solves the integer problem exactly (§6.1). Branch and bound is required only when such structure is absent (or destroyed by side constraints).

**A5.** The problem is a 40×40 assignment — bipartite, TU (§6.2–6.3). An LP (or `scipy.optimize.linear_sum_assignment`) solves it *exactly, with a proof of optimality, in milliseconds*. A genetic algorithm would be slower, approximate, tuning-hungry, and certificate-free (Part V makes this precise). Recognizing exploitable structure before reaching for general-purpose search is the single most valuable habit in this course.

---

---
---

---
---

# PART III — NONLINEAR PROGRAMMING

Linear programming lived on a polyhedron, and its optimum sat at a corner we could find by algebra. The moment $f$ curves, corners stop mattering and derivatives take over: we must *feel* our way downhill using the local Taylor models of §0.2. This Part builds that machinery from nothing, prices its failure modes exactly, and ends with the full apparatus for constrained nonlinear design — the KKT conditions — used on a real engineering problem where getting the physics right changes the answer completely.

---

## 7. Unconstrained optimization

We start with no constraints at all: $\min_x f(x)$, with $f$ smooth. Everything learned here transfers to the constrained case in §9, because constrained algorithms are built out of unconstrained pieces.

### 7.1 Optimality conditions: when can you stop?

Expand $f$ about a candidate point $x^\star$ using the second-order Taylor model (§0.2):

$$f(x^\star + d) \;\approx\; f(x^\star) + \nabla f(x^\star)^\top d + \tfrac{1}{2}\, d^\top \nabla^2 f(x^\star)\, d.$$

For $x^\star$ to be a local minimum, *no small step $d$ may reduce $f$*. Look at the terms in order of size. For small $d$, the linear term dominates — and it can always be made negative by stepping against the gradient, *unless the gradient is zero*. Hence:

> **First-order necessary condition:** $\nabla f(x^\star) = 0$. Such a point is called **stationary**.

With the linear term gone, the quadratic term decides, and §0.3 told us how to read it:

> **Second-order conditions:** $\nabla^2 f(x^\star) \succeq 0$ is *necessary* for a local minimum; $\nabla^2 f(x^\star) \succ 0$ (positive definite) is *sufficient* for a strict local minimum.

The Hessian's eigenvalues classify every stationary point — this is Figure 0.2 again, now with its official meaning:

| Eigenvalues of $\nabla^2 f(x^\star)$ | Type | Shape |
|---|---|---|
| all $> 0$ | strict local **minimum** | bowl |
| all $< 0$ | strict local **maximum** | dome |
| mixed signs | **saddle** | mountain pass |
| some $= 0$, rest $> 0$ | inconclusive — needs higher-order information | flat-bottomed valley |

> **Why this matters in practice.** Solvers find *stationary* points. "Converged" means "$\|\nabla f\|$ is small" — a condition a saddle point satisfies just as well as a minimum. Good solvers check curvature; if you ever write your own convergence test, remember that a vanishing gradient is *not* a minimum.

Two qualifiers to keep you honest. First, all of this is **local**: the conditions certify that no *nearby* point is better, and say nothing about a deeper basin on the other side of a ridge. Second, if $f$ is convex, stationarity is not merely necessary but *sufficient for a global minimum* — that is the entire payoff of §3, cashed in.

---

#### Exercises

**7.1.1 [H]** Find all stationary points of $f(x) = x_1^3 - 3x_1 + x_2^2$ and classify each using the Hessian eigenvalues. Which is a local minimum? Is it global?

**7.1.2 [C]** Explain why $\nabla f(x^\star) = 0$ is *necessary* but not *sufficient* for a local minimum, and why $\nabla^2 f(x^\star) \succeq 0$ is necessary but $\succ 0$ is sufficient. Give a one-dimensional example where the semidefinite case is genuinely inconclusive.

**7.1.3 [P]** Write `classify_stationary(grad, hess, x)` that checks $\|\nabla f\|$ against a tolerance and, if stationary, reports "minimum", "maximum", "saddle" or "inconclusive" from the Hessian eigenvalues. Test it at both stationary points of 7.1.1.

**7.1.4 [M]** A colleague's solver reports convergence with $\|\nabla f\| = 3\times10^{-9}$ and hands you the point. What exactly has been certified, what has not, and what two additional checks would you run before using the design?


### 7.2 The descent framework

Almost every smooth optimization algorithm ever written is one loop:

$$x_{k+1} = x_k + \alpha_k\, p_k,$$

with a **search direction** $p_k$ and a **step length** $\alpha_k > 0$. The direction is a *descent direction* if $\nabla f(x_k)^\top p_k < 0$ — it points into the downhill half-space (§0.1). Algorithms differ essentially only in how they pick $p_k$:

- **Steepest descent:** $p_k = -\nabla f(x_k)$. The locally fastest decrease, dead simple, needs only first derivatives.
- **Newton:** $p_k = -[\nabla^2 f(x_k)]^{-1} \nabla f(x_k)$ — the step that jumps to the minimum of the local *quadratic* model.
- **Quasi-Newton (BFGS):** Newton with the Hessian replaced by an approximation built up from observed gradient changes.

Steepest descent looks unimprovable — "fastest decrease," what could beat that? — and is, in practice, usually dismayingly slow. The next example shows *exactly* why, with arithmetic instead of hand-waving, and the reason will turn out to be the condition number $\kappa$ from §0.4.

---

#### Exercises

**7.2.1 [H]** State the descent condition on $p_k$ and verify it for (a) steepest descent, (b) Newton's step when $\nabla^2 f \succ 0$, (c) Newton's step when $\nabla^2 f$ is indefinite. What goes wrong in case (c)?

**7.2.2 [H]** Derive the exact line-search step length for a quadratic $f = \tfrac12 x^\top Qx$ along direction $p$: substitute $x + \alpha p$, differentiate in $\alpha$, and solve. Show your derivation gives $\alpha = -\dfrac{g^\top p}{p^\top Qp}$, and specialize it to $p = -g$.

**7.2.3 [P]** Implement a generic descent loop `descend(f, grad, x0, direction, alpha_rule, tol)` and run it with two direction rules — steepest descent and a fixed-step gradient method with $\alpha = 1/\lambda_{\max}$ — on $f = \tfrac12(x_1^2 + 10x_2^2)$ from $(10,1)$. Compare iteration counts.

**7.2.4 [C]** "Steepest descent is the locally fastest decrease, so it must be the best direction." Identify the hidden word that makes this claim misleading, and explain in terms of Taylor models (§0.2) what information the direction is throwing away.


### 7.3 Worked Example 4 — the zigzag, in exact numbers

*Redo this one with a pencil first; every number is checkable by hand. Then run the script and watch the same numbers appear.*

Take the simplest ill-conditioned problem, a stretched bowl:

$$f(x) = \tfrac{1}{2}\big(x_1^2 + 10\,x_2^2\big), \qquad \nabla f = (x_1,\; 10x_2), \qquad \nabla^2 f = \begin{pmatrix} 1 & 0 \\ 0 & 10 \end{pmatrix}.$$

Its condition number is $\kappa = 10$. Start at $x_0 = (10, 1)$ and use an **exact line search** — at each step, choose the $\alpha$ that truly minimizes $f$ along the ray, which for a quadratic $f = \tfrac12 x^\top Q x$ has the closed form $\alpha = \dfrac{g^\top g}{g^\top Q\, g}$ with $g = \nabla f(x_k)$. (Derive it: substitute $x_k - \alpha g$ into $f$, differentiate in $\alpha$, set to zero.)

For our $f$ and the special starting point $x_0 = (\kappa c,\ c)$ — ours, with $c = 1$ — the iteration simplifies beautifully. The step length comes out constant, $\alpha = \dfrac{2}{1+\kappa} = \dfrac{2}{11}$, and the update is

$$x_{k+1} = \frac{\kappa - 1}{\kappa + 1}\,\big(x_{1,k},\; -x_{2,k}\big).$$

Read that formula carefully, because it *is* the pathology: **both coordinates shrink by the same factor $\frac{\kappa-1}{\kappa+1} = \frac{9}{11}$, and the sign of $x_2$ flips every single iteration.** The zigzag is not an artist's impression — it is in the arithmetic. Verify the first step by hand: $g_0 = (10, 10)$, $\alpha = \frac{200}{10^2 + 10 \cdot 10^2} = \frac{200}{1100} = \frac{2}{11}$, so $x_1 = (10,1) - \frac{2}{11}(10,10) = (\frac{90}{11}, -\frac{9}{11}) = (8.1818, -0.8182)$. ✓ (matches row $k=1$ below).

```python
"""Worked Example 4: steepest descent on a kappa=10 quadratic, exact line search."""
import numpy as np

Q = np.diag([1.0, 10.0])
f = lambda x: 0.5 * x @ Q @ x
grad = lambda x: Q @ x

x = np.array([10.0, 1.0])
f_prev = f(x)
print(f"k=0  x=({x[0]:+9.5f},{x[1]:+9.5f})  f={f(x):9.5f}")
for k in range(1, 9):
    g = grad(x)
    alpha = (g @ g) / (g @ Q @ g)          # exact line search (quadratic case)
    x = x - alpha * g
    print(f"k={k}  x=({x[0]:+9.5f},{x[1]:+9.5f})  f={f(x):9.5f}  "
          f"f_k/f_(k-1)={f(x)/f_prev:.5f}")
    f_prev = f(x)
```

```
k=0  x=(+10.00000, +1.00000)  f= 55.00000
k=1  x=( +8.18182, -0.81818)  f= 36.81818  f_k/f_(k-1)=0.66942
k=2  x=( +6.69421, +0.66942)  f= 24.64688  f_k/f_(k-1)=0.66942
k=3  x=( +5.47708, -0.54771)  f= 16.49915  f_k/f_(k-1)=0.66942
k=4  x=( +4.48125, +0.44813)  f= 11.04489  f_k/f_(k-1)=0.66942
k=5  x=( +3.66648, -0.36665)  f=  7.39368  f_k/f_(k-1)=0.66942
k=6  x=( +2.99985, +0.29998)  f=  4.94949  f_k/f_(k-1)=0.66942
k=7  x=( +2.45442, -0.24544)  f=  3.31330  f_k/f_(k-1)=0.66942
k=8  x=( +2.00816, +0.20082)  f=  2.21799  f_k/f_(k-1)=0.66942
```

Eight iterations to reduce $f$ by a factor of 25, *on a two-variable quadratic* — the easiest problem in the world. The per-step ratio is constant at $\big(\tfrac{9}{11}\big)^2 = \tfrac{81}{121} = 0.669421\ldots$, which is exactly the classical worst-case bound

$$\frac{f(x_{k+1}) - f^\star}{f(x_k) - f^\star} \;\le\; \left(\frac{\kappa - 1}{\kappa + 1}\right)^{\!2},$$

attained with equality at every step from this starting point.

![The zigzag](figures/fig7_zigzag.png)

*Figure 7.1 — The iterates of the table (red), overlaid on the contours of $f$. Each step is perpendicular to the previous one (a property of exact line searches: the new gradient is orthogonal to the old direction), so the path bounces between the canyon walls instead of traveling along the canyon floor. The blue dashed segment is Newton's method from the same start: one step, done.*

**Contrast Newton's method.** Here $\nabla^2 f = Q$ is constant, so the Newton step from $x_0$ is

$$p_0 = -Q^{-1} \nabla f(x_0) = -\begin{pmatrix} 1 & 0 \\ 0 & 1/10 \end{pmatrix}\begin{pmatrix} 10 \\ 10 \end{pmatrix} = \begin{pmatrix} -10 \\ -1 \end{pmatrix}, \qquad x_1 = x_0 + p_0 = (0, 0):$$

**the exact optimum, in one step.** What Newton is really doing is *rescaling the space* so the stretched bowl becomes round — multiplying by $Q^{-1}$ undoes the stretching — and then steepest descent in the round space points straight at the answer. Everything expensive about Newton's method is the price of that rescaling.

**Now put the bound to work.** How many iterations does steepest descent need to gain 6 digits of accuracy, i.e., reduce the error by $10^6$? Solve $\big(\frac{\kappa-1}{\kappa+1}\big)^{2N} \le 10^{-6}$:

| $\kappa$ | worst-case factor $\left(\frac{\kappa-1}{\kappa+1}\right)^2$ | iterations for 6 digits |
|---|---|---|
| 1 | 0 | 1 |
| 10 | 0.6694 | 35 |
| 100 | 0.9608 | 346 |
| 1000 | 0.9960 | 3454 |

The cost grows essentially **in direct proportion to $\kappa$**. This table is why §2.3 exists: poor scaling inflates $\kappa$, and inflating $\kappa$ is literally multiplying your run time. Rescaling variables is often a hundredfold speedup available for free.

![Convergence vs conditioning](figures/fig7_convergence.png)

*Figure 7.2 — $f(x_k)$ on a log scale for $\kappa = 10, 100, 1000$. Linear convergence means a straight line on this plot, and the slope flattens in proportion to $\kappa$ — the table above, drawn. Newton (black) is a single step for any quadratic, regardless of $\kappa$.*

---

#### Exercises

**7.3.1 [H]** Repeat the worked example for $f(x) = \tfrac12(x_1^2 + 4x_2^2)$ starting at $x_0 = (4,1)$. Compute $\kappa$, predict $\alpha$ and the per-iteration ratio from the formulas, then carry out two iterations by hand showing every number.

**7.3.2 [P]** Run the same case in code for six iterations, printing $\alpha$, $x_k$, $f(x_k)$ and the ratio $f_k/f_{k-1}$. Confirm the ratio is constant and equals $\big(\frac{\kappa-1}{\kappa+1}\big)^2$ exactly. Then change the start to $(1,1)$ and explain what you observe.

**7.3.3 [H]** Compute the Newton step from $x_0 = (4,1)$ for the same $f$ and confirm it reaches the optimum in one step. Explain in one sentence, using the phrase "rescaling the space," why Newton is exact here.

**7.3.4 [H]** Using the worst-case rate, derive the number of steepest-descent iterations needed to reduce the error by $10^{-8}$ for $\kappa = 20$ and $\kappa = 2000$. Show the algebra, and state the proportionality you observe.

**7.3.5 [M]** A colleague reports that steepest descent solved their 12-variable design problem in 9 iterations and concludes it is a fine algorithm for their work. Give two distinct reasons this conclusion may not survive their next problem.


### 7.4 Newton, quasi-Newton, and conjugate gradient

**Newton:** $p_k = -[\nabla^2 f(x_k)]^{-1}\,\nabla f(x_k)$ — minimize the local *quadratic* model instead of the local *linear* one. Near a well-behaved minimum, convergence is **quadratic**: the number of correct digits roughly *doubles* each iteration, so 3–5 iterations is typical regardless of $\kappa$. The costs are real: $\sim n^2$ second derivatives, an $n \times n$ linear solve per step, and one subtlety that matters — far from the optimum, $\nabla^2 f$ is often *not* positive definite, in which case the "Newton step" can point uphill. Practical implementations modify the Hessian when needed, or wrap the step in a trust region (§7.5).

**Quasi-Newton (BFGS):** build an approximation of the Hessian (or directly of its inverse) from successive *gradient differences* — each step, the observed change in $\nabla f$ reveals a slice of curvature, and BFGS accumulates those slices. No second derivatives, **superlinear** convergence (between linear and quadratic), cost per iteration barely above steepest descent. **BFGS is the sensible default** for smooth unconstrained problems of small-to-moderate size; **L-BFGS** (limited-memory) is the default for large ones, because it never stores the matrix at all — only the last few gradient differences.

**Conjugate gradient (CG):** builds a sequence of directions that are mutually "conjugate" with respect to the Hessian, using only gradients and $O(n)$ storage. The method of choice when $n$ is enormous and even L-BFGS memory matters.

Watch all of this happen on the $\kappa = 100$ version of our stretched bowl:

```python
"""Method comparison on 0.5*(x1^2 + 100 x2^2), start (10, 1)."""
import numpy as np
from scipy.optimize import minimize

Q = np.diag([1.0, 100.0])
f    = lambda x: 0.5 * x @ Q @ x
grad = lambda x: Q @ x
hess = lambda x: Q
x0 = np.array([10.0, 1.0])

# steepest descent (our own loop, exact line search)
x, n = x0.copy(), 0
while np.linalg.norm(grad(x)) > 1e-5:
    g = grad(x); x = x - (g @ g)/(g @ Q @ g) * g; n += 1
print(f"steepest descent : {n:3d} iterations")

for method, extra in [("BFGS", {}), ("Newton-CG", {"hess": hess})]:
    r = minimize(f, x0, jac=grad, method=method, tol=1e-10, **extra)
    print(f"{method:17s}: {r.nit:3d} iterations,  f* = {r.fun:.1e}")
```

```
steepest descent :  41 iterations
BFGS             :   4 iterations,  f* = 3.8e-34
Newton-CG        :   3 iterations,  f* = 1.6e-30
```

Forty-one iterations versus four. And this gap *widens* with $\kappa$ and with dimension — on real problems it is routinely a factor of hundreds. The summary table to carry:

| Method | Info needed | Local rate | Use when |
|---|---|---|---|
| Steepest descent | $\nabla f$ | linear, factor $\left(\frac{\kappa-1}{\kappa+1}\right)^2$ | almost never; a baseline and a teaching tool |
| Conjugate gradient | $\nabla f$ | linear, but in $\sqrt{\kappa}$ | $n$ very large, memory tight |
| BFGS / L-BFGS | $\nabla f$ | superlinear | **default** for smooth problems |
| Newton | $\nabla f,\ \nabla^2 f$ | quadratic | Hessian cheap; high accuracy needed |
| Gauss–Newton / LM | Jacobian of residuals only | near-quadratic | objective is a sum of squares (§8) |

In `scipy.optimize.minimize`, these are `method="L-BFGS-B"` (the workhorse; also handles bounds), `"BFGS"`, `"Newton-CG"`, `"CG"`, and `"trust-*"` variants. If you remember one call signature from this chapter, make it `minimize(f, x0, jac=grad, method="L-BFGS-B")`.

---

#### Exercises

**7.4.1 [C]** Complete the method table from memory: for steepest descent, CG, BFGS/L-BFGS, Newton and Gauss–Newton/LM, give the derivative information required, the local convergence rate, and the situation in which you would choose it.

**7.4.2 [P]** Reproduce the method comparison on $f = \tfrac12(x_1^2 + 100x_2^2)$ from $x_0 = (10,1)$: steepest descent with exact line search (your own loop), `BFGS`, and `Newton-CG` with an exact Hessian. Report iteration counts. Then repeat with $\kappa = 10^4$ and comment on which counts change and which do not.

**7.4.3 [C]** Explain what BFGS actually accumulates, and why "no second derivatives" does not mean "no curvature information." What does it need from each step in order to learn?

**7.4.4 [M]** For each situation, name the method you would use and justify it in one sentence: (a) $n = 3$, analytic Hessian available, 12 digits of accuracy needed; (b) $n = 5\times10^6$, gradient from reverse-mode AD, memory tight; (c) $n = 40$, objective is a sum of 900 squared residuals; (d) $n = 20$, each function evaluation is a 20-minute CFD run and the gradient is unavailable.


### 7.5 Line search versus trust region

The direction $p_k$ is half the algorithm; deciding *how far* to move is the other half. Two competing philosophies, both standard:

**Line search.** Fix the direction, then search along it for an acceptable step $\alpha$. "Acceptable" is made precise by the **Armijo condition** — the actual decrease must be at least a fixed fraction of what the linear model promised — plus a curvature condition; together these are the **Wolfe conditions**. They rule out both microscopic steps (which stall) and wild overshoots (which diverge). You will never implement these yourself — every quality library has them — but when a solver log says "line search failed," you now know it means *the local model and reality disagreed so badly that no acceptable step existed*, which usually indicates a bug in your gradient (§11) or terrible scaling (§2.3).

**Trust region.** Turn the logic around: first choose a radius $\Delta_k$ within which you trust the local model, then minimize the model *inside that ball*, then compare predicted to actual reduction and expand or shrink $\Delta_k$ accordingly. More robust when the model is unreliable, and it handles indefinite Hessians naturally rather than by patching them. This is the `trust-` family in SciPy, and the idea returns in §8 (Levenberg–Marquardt is a trust region in disguise) and Part V (surrogate optimization is trust-region thinking applied to expensive black boxes).

---

#### Exercises

**7.5.1 [C]** Contrast line search and trust region in one sentence each: what is fixed first, what is searched for, and how is the local model's reliability enforced?

**7.5.2 [C]** State in words what the Armijo condition requires and what the curvature (second Wolfe) condition requires. What failure mode does each one prevent?

**7.5.3 [M]** Your solver log reports "line search failed." List the three most likely causes in order of probability, and for each give the concrete diagnostic you would run.

**7.5.4 [P]** Implement a backtracking line search satisfying the Armijo condition ($f(x+\alpha p) \le f(x) + c_1\alpha\nabla f^\top p$, $c_1 = 10^{-4}$, halving $\alpha$ from 1). Use it with steepest descent on the Rosenbrock function from $(-1.2, 1)$ and report the iteration count and final point. Then explain why the count is so large.


### 7.6 When to stop

Use several criteria *together*, and understand that all of them are necessary rather than sufficient:

- **scaled gradient norm:** $\|\nabla f(x_k)\| \le \varepsilon\,(1 + |f(x_k)|)$ — the scaling matters; a raw threshold like $10^{-6}$ is meaningless without knowing the units of $f$;
- **relative step:** $\|x_{k+1} - x_k\| \le \varepsilon\,(1 + \|x_k\|)$;
- **relative objective change** over the last few iterations;
- a hard **budget** on iterations or function evaluations, because an unbounded run is not a plan.

A tiny step can mean the algorithm has *stalled* rather than converged — on a ridge, or because of a broken gradient. Always check the gradient norm too; never trust the step size alone.

---

#### Exercises

**7.6.1 [C]** List the four stopping criteria of §7.6 and explain why the gradient test is written as $\|\nabla f\| \le \varepsilon(1+|f|)$ rather than $\|\nabla f\| \le \varepsilon$.

**7.6.2 [H]** A solver stops with a relative step of $2\times10^{-11}$ but $\|\nabla f\| = 4.7$. Give two distinct explanations, and state which single further computation would distinguish them.

**7.6.3 [P]** Take $f(x) = \tfrac12(x_1^2 + 100x_2^2)$ and run steepest descent, recording at each iteration the gradient norm, the step norm, and the relative objective change. Print the iteration at which each of the three criteria (with $\varepsilon = 10^{-6}$) would first have fired. Do they agree?

**7.6.4 [M]** Why does the course insist on a hard iteration/evaluation budget as one of the criteria? Give an operational reason and a scientific one.


---

## 8. Nonlinear least squares: fitting models to data

A large fraction of real engineering optimization is not "design" at all — it is **fitting a model to measurements**: calibrating material parameters, identifying a process model from a step test, reconstructing a field from sensor readings, training a controller. All of these have the special form

$$\min_x \ f(x) = \tfrac{1}{2}\sum_{i=1}^{M} r_i(x)^2, \qquad r_i(x) = \text{predicted}_i(x) - \text{measured}_i,$$

and the structure is worth exploiting, because it gives you second-order convergence at first-order cost.

### 8.1 The structural gift

Let $J$ be the Jacobian of the residuals, $J_{ik} = \partial r_i / \partial x_k$. Differentiating the sum of squares:

$$\nabla f = J^\top r, \qquad \nabla^2 f = J^\top J + \sum_i r_i\, \nabla^2 r_i.$$

Near a good fit, the residuals $r_i$ are small, so the second term — the only part needing second derivatives — is negligible. **You get a Hessian approximation, $J^\top J$, for free from first derivatives alone.** Two algorithms cash this in:

- **Gauss–Newton** solves $(J^\top J)\, p = -J^\top r$ for the step. Newton-like convergence using only $J$.
- **Levenberg–Marquardt (LM)** solves $(J^\top J + \nu I)\, p = -J^\top r$. Large $\nu$ makes the step short and steepest-descent-like (safe far from the solution); small $\nu$ recovers Gauss–Newton (fast near it). Adapting $\nu$ from the observed success of each step is exactly the trust-region logic of §7.5. **This is the algorithm inside essentially every curve-fitting tool you have ever used** — including `scipy.optimize.least_squares` and `curve_fit`.

Practical rule: never feed a sum of squares to a generic minimizer. `least_squares` sees the residual *vector* and exploits $J^\top J$; `minimize` sees only the scalar sum and cannot.

---

#### Exercises

**8.1.1 [H]** Starting from $f(x) = \tfrac12\sum_i r_i(x)^2$, derive $\nabla f = J^\top r$ and $\nabla^2 f = J^\top J + \sum_i r_i\nabla^2 r_i$. State precisely the condition under which dropping the second term is a good approximation.

**8.1.2 [C]** Contrast Gauss–Newton and Levenberg–Marquardt by writing the linear system each solves. Explain the role of $\nu$ at both extremes and identify which §7.5 idea LM is implementing.

**8.1.3 [P]** Verify the structural gift numerically. For the residuals $r_i(x) = x_1 e^{-x_2 t_i} - y_i$ on some data, compute at a given $x$: (a) $\nabla f$ from $J^\top r$; (b) $\nabla f$ by central differences on $f$; (c) the exact Hessian; (d) the approximation $J^\top J$. Report the relative error of $J^\top J$ versus the exact Hessian both far from and near the solution.

**8.1.4 [M]** Explain the practical rule "never feed a sum of squares to a generic minimizer," and quantify what is lost by naming the two things `least_squares` can exploit that `minimize` cannot see.


### 8.2 Worked Example 5 — identifying a process from a step test

*The engineering task: you kicked a thermal system (or a motor, or a tank level — the mathematics is identical) with a step input at $t = 0$ and logged the response. Identify the model*

$$y(t) = K\,\big(1 - e^{-t/\tau}\big),$$

*with gain $K$ and time constant $\tau$ — the two numbers every controls course asks for.*

We generate 25 noisy measurements from a true system with $K = 3$, $\tau = 2$ (noise $\sigma = 0.05$), then recover the parameters:

```python
"""Worked Example 5: fit a first-order step response with Levenberg-Marquardt."""
import numpy as np
from scipy.optimize import least_squares

rng = np.random.default_rng(7)
t = np.linspace(0.0, 10.0, 25)
y = 3.0*(1 - np.exp(-t/2.0)) + rng.normal(0, 0.05, t.size)   # "measurements"

def residuals(p):
    K, tau = p
    return K*(1 - np.exp(-t/tau)) - y

sol = least_squares(residuals, x0=[1.0, 1.0])       # LM-type solver
K_hat, tau_hat = sol.x

# --- uncertainty: covariance of the estimates from the Jacobian ---
m, n = sol.jac.shape
sigma2 = np.sum(sol.fun**2) / (m - n)                # noise variance estimate
cov = sigma2 * np.linalg.inv(sol.jac.T @ sol.jac)
se = np.sqrt(np.diag(cov))

print(f"K   = {K_hat:.4f} +/- {se[0]:.4f}   (true 3.0)")
print(f"tau = {tau_hat:.4f} +/- {se[1]:.4f}   (true 2.0)")
print(f"cond(J^T J) = {np.linalg.cond(sol.jac.T @ sol.jac):.1f}")
```

```
K   = 2.9679 +/- 0.0142   (true 3.0)
tau = 1.9723 +/- 0.0363   (true 2.0)
cond(J^T J) = 17.5
```

![Step-response fit](figures/fig8_fit.png)

*Figure 8.1 — Left: the data and the fitted curve. Right: the residuals, which look like pure noise with no leftover structure — the visual check that the model form is adequate. If the residuals showed a systematic bow or trend, the two-parameter model would be missing physics, and no optimizer could fix that.*

Three habits packed into those few lines, each worth naming:

1. **The fit itself** took `least_squares` six function evaluations — the $J^\top J$ gift at work.
2. **The uncertainty.** The matrix $\sigma^2 (J^\top J)^{-1}$ is the (approximate) covariance of the parameter estimates; its diagonal square roots are standard errors. A parameter estimate without a standard error is a guess wearing a lab coat. Here both parameters are determined to about 1–2% — this experiment *identifies* this model.
3. **The conditioning check.** $\text{cond}(J^\top J) = 17.5$ is small: the two parameters affect the data in cleanly distinguishable ways. Hold that thought.

---

#### Exercises

**8.2.1 [P]** Reproduce Worked Example 5 and then re-run it with the noise level raised to $\sigma = 0.25$ (same seed). Report $\hat K$, $\hat\tau$, their standard errors, and $\operatorname{cond}(J^\top J)$. How do the standard errors scale with $\sigma$, and does the conditioning change?

**8.2.2 [P]** **An Arrhenius fit, and a trap.** Rate constants are measured at eight temperatures:
```python
import numpy as np
R = 8.314
T = np.array([300., 320., 340., 360., 380., 400., 420., 440.])
k_obs = np.array([1.0846e-06, 6.6031e-06, 3.8494e-05, 1.5288e-04,
                  5.7909e-04, 1.8771e-03, 5.8021e-03, 1.4928e-02])
```
Fit $k = A\,e^{-E/(RT)}$ two ways: (i) `least_squares` on the residuals $A e^{-E/(RT)} - k_{\text{obs}}$; (ii) linear regression of $\ln k$ against $-1/(RT)$. Report $A$ and $E$ from each, with standard errors for both. The true values are $A = 1.2\times10^7$, $E = 75\,000$ J/mol. Which fit is better, and *why* — in terms of the error model rather than the algorithm?

**8.2.3 [H]** Derive the Jacobian of the residuals for the step-response model $y = K(1-e^{-t/\tau})$ analytically (both columns), and explain why the $\tau$ column is nearly zero for $t \gg \tau$. What does that imply about where to place your measurements?

**8.2.4 [M]** State the three habits the worked example packs into a few lines of code, and explain what a parameter estimate without a standard error is worth.


### 8.3 When the data cannot answer the question: identifiability

Now the same workflow on a problem that *looks* only slightly harder — and is, in fact, nearly impossible. Fit a **sum of two exponentials** (two decay processes, e.g. two RC time constants or two reaction rates):

$$y(t) = a_1 e^{-t/\tau_1} + a_2 e^{-t/\tau_2}, \qquad \text{true values } a_1 = a_2 = 1,\ \tau_1 = 1,\ \tau_2 = 1.3,$$

with the *same* small noise as before ($\sigma = 0.01$, even smaller):

```python
"""Worked Example 5b: a near-unidentifiable fit."""
import numpy as np
from scipy.optimize import least_squares

rng = np.random.default_rng(7)
_ = rng.normal(0, 0.05, 25)                       # advance the stream as in 5a
tt = np.linspace(0.05, 6, 40)
yy = np.exp(-tt/1.0) + np.exp(-tt/1.3) + rng.normal(0, 0.01, tt.size)

def residuals(p):
    a1, t1, a2, t2 = p
    return a1*np.exp(-tt/t1) + a2*np.exp(-tt/t2) - yy

sol = least_squares(residuals, x0=[0.8, 0.8, 1.2, 1.6])
m, n = sol.jac.shape
sigma2 = np.sum(sol.fun**2) / (m - n)
se = np.sqrt(np.diag(sigma2 * np.linalg.inv(sol.jac.T @ sol.jac)))

print("fit   (a1, tau1, a2, tau2):", np.round(sol.x, 3))
print("true  (a1, tau1, a2, tau2): [1.    1.    1.    1.3  ]")
print("standard errors           :", np.round(se, 2))
print(f"cond(J^T J) = {np.linalg.cond(sol.jac.T @ sol.jac):.1e}")
```

```
fit   (a1, tau1, a2, tau2): [0.561 0.878 1.43  1.259]
true  (a1, tau1, a2, tau2): [1.    1.    1.    1.3  ]
standard errors           : [1.81 0.56 1.81 0.27]
cond(J^T J) = 8.2e+05
```

Read that output slowly, because it is the most important lesson in this chapter. The solver **converged successfully**. The fitted curve matches the data beautifully (residuals at the noise floor). And the parameters are **completely wrong** — $a_1 = 0.56$ against a true value of $1.0$ — with standard errors *larger than the estimates themselves* ($\pm 1.81$ on a value of $0.56$). The diagnosis was sitting in plain sight: $\text{cond}(J^\top J) \approx 10^6$, five orders of magnitude worse than Example 5a.

![Identifiability valley](figures/fig8_identifiability.png)

*Figure 8.2 — The fitting error (SSE) as a function of $(\tau_1, \tau_2)$, with amplitudes optimized out at each point. The dark region is a long, flat valley of near-identical fit quality: a whole continuum of quite different parameter pairs explains the data equally well. (The valley even contains the mirror point with the two labels swapped — the white star — since the model is symmetric in its two terms.) The data* cannot *distinguish among these; no optimizer, however good, can extract information the experiment never captured.*

> **The warning that matters more than the algorithm.** Parameter-fitting problems are often *poorly identifiable*: many different parameter sets fit the data almost equally well. The tell-tale signs — a huge $\text{cond}(J^\top J)$ at the solution, or equivalently enormous standard errors — cost three lines to compute and should be checked after **every** fit. The remedy is a better-designed experiment (excite the system so the parameters separate: here, data with $t \ll 1$ and richer inputs would help) or regularization — **not a better optimizer**. If the data cannot distinguish two models, no algorithm can.

A quick further check worth adopting: re-run the fit from a second, different starting point. In Example 5b, different starts land at different points *in the valley* with essentially identical SSE — the multi-start version of the same diagnosis, and a two-line habit.

---

#### Exercises

**8.3.1 [C]** In Worked Example 5b the solver converged, the curve fit the data at the noise floor, and the parameters were badly wrong. Explain how all three can be true simultaneously, and name the two numbers that reveal the problem.

**8.3.2 [P]** Reproduce Example 5b, then run it again from three different starting points. Report the fitted parameters and the SSE for each. What pattern do you see, and how is this a diagnosis rather than a nuisance?

**8.3.3 [P]** **Fix the experiment, not the optimizer.** The original design samples $t \in [0.05, 6]$ at 40 points with $\tau_1 = 1$, $\tau_2 = 1.3$. Try two changes and report $\operatorname{cond}(J^\top J)$ and the standard errors for each: (a) separate the time constants to $\tau_1 = 1$, $\tau_2 = 5$, keeping the design; (b) keep $\tau_2 = 1.3$ but add 40 more samples in $t\in[0.001, 0.2]$. Which intervention helps more, and what does that tell you about which parameter pairs were confounded?

**8.3.4 [M]** Write the three-line report you would give a supervisor who asks for "the two time constants" of a system whose data turns out to be near-unidentifiable. Include what you can and cannot state, and what you would ask for next.


---

## 9. Constrained optimization

Real designs have constraints, and constrained optimality is a genuinely different — and more beautiful — condition than $\nabla f = 0$. This chapter builds it in three moves: a picture (tangency), an algebra for the picture (the Lagrangian), and a full set of conditions (KKT). Then it connects the multipliers to Part II's shadow prices — they are the *same object* — and shows what solvers actually do.

### 9.1 The tangency picture

Add a single equality constraint $h(x) = 0$ to $\min f(x)$. Now $\nabla f = 0$ is the wrong condition: the unconstrained minimum is typically infeasible, and at the constrained optimum, $f$ is usually still decreasing in some direction — just not in any direction *you are allowed to move*. The right question is:

> *At which feasible point can I no longer improve by sliding along the constraint?*

Picture standing on the curve $h = 0$ with the contours of $f$ around you. If the contour of $f$ through your point *crosses* the constraint curve, then walking along the constraint one way takes you to lower contours — you can improve. You are stuck exactly when the contour is **tangent** to the constraint curve. And tangency of two curves means their normals — the gradients — are **parallel**:

$$\nabla f(x^\star) = -\lambda\, \nabla h(x^\star) \qquad \text{for some scalar } \lambda.$$

![Tangency](figures/fig9_tangency.png)

*Figure 9.1 — Contours of $f$ (colored) and the feasible curve $h = 0$ (black). At the optimum (star) the contour just touches the constraint, and the two gradients are parallel. Anywhere else on the curve, $-\nabla f$ has a component* along *the curve — an allowed direction of improvement — so the point cannot be optimal.*

That one picture is the entire content of Lagrange multipliers. Everything below is bookkeeping to make it precise, general, and computable.

---

#### Exercises

**9.1.1 [C]** Explain in your own words why $\nabla f = 0$ is the *wrong* optimality condition once an equality constraint is present, and state the condition that replaces it. What geometric fact does "the gradients are parallel" encode?

**9.1.2 [H]** Solve $\min\ x_1 + x_2$ subject to $x_1^2 + x_2^2 = 1$ by the tangency condition: write $\nabla f = -\lambda\nabla h$, solve for $x^\star$ and $\lambda$, and identify which of the two solutions is the minimum.

**9.1.3 [H]** For the same problem, verify the tangency picture numerically at a *non-optimal* feasible point, say $(1,0)$: compute $-\nabla f$, project it onto the tangent to the circle at that point, and show the projection is nonzero — i.e. there is an allowed direction of improvement.

**9.1.4 [M]** A colleague insists their constrained design must be at a point where "the gradient of the objective vanishes." Explain what they will find if they search for such a point, using the example of a mass-minimization with a stress constraint.


### 9.2 The Lagrangian

Encode "the gradients are parallel" with multiplier variables. For the general problem

$$\min_x f(x) \quad \text{s.t.} \quad g_i(x) \le 0 \ (i = 1,\dots,m), \qquad h_j(x) = 0 \ (j = 1,\dots,p),$$

define the **Lagrangian**

$$\mathcal{L}(x, \mu, \lambda) \;=\; f(x) + \sum_i \mu_i\, g_i(x) + \sum_j \lambda_j\, h_j(x).$$

Stationarity of $\mathcal{L}$ in $x$, i.e. $\nabla_x \mathcal{L} = 0$, is exactly the parallel-gradients condition, now with one multiplier per constraint.

---

#### Exercises

**9.2.1 [H]** Write the Lagrangian for
$$\min\ x_1^2 + x_2^2 \quad\text{s.t.}\quad x_1 + 2x_2 = 4,\quad x_1 \le 1,$$
listing every multiplier with its sign restriction. Then write out $\nabla_x\mathcal{L} = 0$ explicitly.

**9.2.2 [C]** Why does the Lagrangian *add* $\mu_i g_i$ with $\mu_i \ge 0$ for inequalities but allow $\lambda_j$ of either sign for equalities? Answer in terms of which directions each kind of constraint forbids.

**9.2.3 [H]** Solve 9.2.1 completely: first assume $x_1 \le 1$ is inactive, check the result, and if it is violated re-solve with the constraint active. Report $x^\star$, all multipliers, and verify the signs.

**9.2.4 [C]** Stationarity of $\mathcal{L}$ in $x$ is one KKT condition. Why is it *not* correct to also set $\partial\mathcal{L}/\partial\lambda = 0$ and $\partial\mathcal{L}/\partial\mu = 0$ and call the collection "the" optimality conditions?


### 9.3 The KKT conditions

At a local optimum $x^\star$ (of a problem satisfying a regularity condition — see below), there exist multipliers $\mu^\star \ge 0$ and $\lambda^\star$ such that:

| # | Condition | How to read it |
|---|---|---|
| 1 | $\nabla f(x^\star) + \sum_i \mu_i^\star \nabla g_i(x^\star) + \sum_j \lambda_j^\star \nabla h_j(x^\star) = 0$ | **Stationarity.** The pull downhill is exactly balanced by the constraints holding you back. |
| 2 | $g_i(x^\star) \le 0$, $\ h_j(x^\star) = 0$ | **Primal feasibility.** The point is actually allowed. |
| 3 | $\mu_i^\star \ge 0$ | **Dual feasibility.** An inequality can only *push back*, never pull you into itself. A negative $\mu_i$ would mean the constraint is helping you — in which case you should walk away from it, so it cannot be active at an optimum with negative price. |
| 4 | $\mu_i^\star\, g_i(x^\star) = 0$ | **Complementary slackness.** Each inequality is either active or has zero multiplier — *identical in meaning to §5.3*. A constraint with room to spare exerts no force. |

These are the **Karush–Kuhn–Tucker (KKT) conditions**, and they are the master optimality conditions of continuous optimization: set $m = p = 0$ and they collapse to $\nabla f = 0$ (§7.1); make everything linear and they become LP duality plus complementary slackness (§5.3–5.4). One set of conditions, the whole subject.

Three points of rigor that are often skipped and should not be:

- KKT are **necessary** conditions only under a **constraint qualification** — a regularity assumption on the constraint geometry. The usual one is **LICQ**: the gradients of the *active* constraints are linearly independent at $x^\star$. Cusps and redundantly-written constraints can break it, and when it breaks, multipliers may fail to exist or fail to be unique. (This is the nonlinear cousin of the LP degeneracy you met in §5.8 — same disease, same two-sided-perturbation cure.)
- **For a convex problem, KKT is also sufficient:** any point satisfying all four conditions is a *global* optimum. This is the workhorse theorem of convex optimization, and it is what lets §5.4's certificate generalize.
- For nonconvex problems, KKT alone does not guarantee even a local minimum — a KKT point can be a constrained *maximum* or saddle. The second-order condition is that the Hessian of $\mathcal{L}$ be positive definite *on the subspace of directions tangent to the active constraints* (curvature only matters along directions you can actually move).

---

#### Exercises

**9.3.1 [H]** For $\min (x_1-2)^2 + (x_2-1)^2$ s.t. $x_1 + x_2 \le 2$, $x \ge 0$: find $x^\star$ and all multipliers, and verify all four KKT conditions explicitly, one line each.

**9.3.2 [C]** State LICQ. Then give a two-constraint example in two variables where LICQ fails at the optimum, and say what goes wrong with the multipliers there.

**9.3.3 [C]** A colleague finds a point satisfying all four KKT conditions on a nonconvex problem and reports it as the optimum. What are the two distinct things they have *not* established? What extra condition would establish the first of them?

**9.3.4 [P]** Write `kkt_residual(gradf, gs, grad_gs, x, mu)` returning the three residuals of §9.7 — stationarity norm, maximum violation, maximum complementarity product. Test it at the solution of 9.3.1 and at the deliberately wrong point $x = (1,1)$ with $\mu = 1$.


### 9.4 Multipliers are shadow prices

Perturb the $i$-th constraint to $g_i(x) \le \varepsilon_i$ — give yourself a little more room. Then, under the same regularity,

$$\frac{\partial f^\star}{\partial \varepsilon_i} = -\mu_i^\star.$$

Relaxing an active constraint by one unit improves the optimal objective by $\mu_i^\star$ units. **The multiplier measures how much each requirement is costing you** — a direct, quantitative ranking of which specification is worth renegotiating with the customer, which limit is worth an engineering effort to relax, and which constraints are free.

This is the moment Part II and Part III fuse: **LP shadow prices are just KKT multipliers in the linear case.** Same object, same units (objective per unit of constraint), same interpretation, same caveat — where the value function has a kink, the multiplier is one of many valid subgradients (§5.8), so verify with a two-sided perturbation before you spend money on it. Worked Example 6 will put a physical multiplier in your hands: kilograms of steel per metre of mandated vessel length.

---

#### Exercises

**9.4.1 [H]** For the problem of 9.3.1, verify $\partial f^\star/\partial\varepsilon = -\mu^\star$ by hand: replace the constraint with $x_1+x_2 \le 2+\varepsilon$, derive $f^\star(\varepsilon)$ in closed form, and differentiate at $\varepsilon = 0$.

**9.4.2 [P]** Verify the same thing numerically by re-solving at $\varepsilon = \pm0.1$ and forming both one-sided rates. Do they agree with each other and with $-\mu^\star$?

**9.4.3 [M]** A structural optimization returns multipliers (all constraints normalized so residuals are dimensionless fractions of their limits): $\mu_{\text{stress}} = 0$, $\mu_{\text{deflection}} = 12.4$ kg, $\mu_{\text{frequency}} = 3.1$ kg, $\mu_{\text{width}} = 0.4$ kg. Write the design-review recommendation this supports, in priority order, and state which specification you would try to renegotiate first and why.

**9.4.4 [C]** Explain why the caveat from §5.8 (kinks, non-unique subgradients) applies verbatim to nonlinear multipliers, and what habit it implies before spending money on a multiplier.


### 9.5 The Lagrangian dual: one idea behind every certificate

This short section unifies every bound in the entire course; it is the five most important minutes in Part III.

Define the **dual function** by minimizing the Lagrangian over $x$ with the multipliers held fixed:

$$q(\mu, \lambda) \;=\; \inf_x\ \mathcal{L}(x, \mu, \lambda).$$

> **Weak duality.** For every $\mu \ge 0$ and every $\lambda$: $\quad q(\mu, \lambda) \le f^\star$.

*Proof — two lines, and worth reading twice.* Let $x$ be any feasible point. Since $\mu \ge 0$ and $g(x) \le 0$, the term $\mu^\top g(x) \le 0$; and $h(x) = 0$ kills the last term. So $\mathcal{L}(x, \mu, \lambda) \le f(x)$. Then $q(\mu,\lambda) = \inf_{x'} \mathcal{L}(x', \mu, \lambda) \le \mathcal{L}(x, \mu, \lambda) \le f(x)$ — and this holds for every feasible $x$, hence for the best one. $\square$

Two remarkable features. First, the inequality needs **no assumptions whatsoever** — not convexity, not differentiability, not even continuity of $f$. Second, $q$ is **always concave** (it is a pointwise infimum of functions affine in $(\mu, \lambda)$), however hideous the primal problem is. So maximizing $q$ — the **dual problem** — is always a nice concave problem, even when the primal is a monster.

**A concrete instance you can do entirely by hand.** Take $\min x^2$ s.t. $x \ge 1$, i.e. $g(x) = 1 - x \le 0$. The answer is obviously $x^\star = 1$, $f^\star = 1$. Now the dual: $\mathcal{L} = x^2 + \mu(1 - x)$; minimizing over $x$ (set $\partial \mathcal{L}/\partial x = 2x - \mu = 0$, so $x = \mu/2$):

$$q(\mu) = \frac{\mu^2}{4} + \mu - \frac{\mu^2}{2} = \mu - \frac{\mu^2}{4}.$$

Concave in $\mu$ ✓. Every $\mu \ge 0$ gives a valid lower bound: $q(1) = 0.75 \le 1$ ✓, $q(3) = 0.75 \le 1$ ✓. Maximizing: $q'(\mu) = 1 - \mu/2 = 0 \Rightarrow \mu^\star = 2$, and $q(2) = 1 = f^\star$. **The best lower bound is exactly tight.** And $\mu^\star = 2$ is precisely the shadow price: perturbing to $x \ge 1 - \varepsilon$ gives $f^\star(\varepsilon) = (1-\varepsilon)^2$, whose derivative at $\varepsilon = 0$ is $-2 = -\mu^\star$ ✓ (§9.4).

![Dual function](figures/fig9_dualfn.png)

*Figure 9.2 — The dual function $q(\mu) = \mu - \mu^2/4$ for the toy problem. Every point of the curve is a certified lower bound on $f^\star$; the maximum touches $f^\star$ exactly. For convex problems (with a strictly feasible point — Slater's condition), the touch is always exact; for nonconvex problems a* duality gap *can remain, and that gap is precisely why nonconvex answers are hard to certify.*

> **This is the single organizing idea of certified optimization.**
> - Any **feasible point** gives an *upper* bound on $f^\star$ (you achieved that value, so the optimum is at least as good).
> - Any **dual-feasible multiplier vector** gives a *lower* bound on $f^\star$ (weak duality — no assumptions).
> - **Optimality is proved when the two bounds meet.**
>
> Every certificate in this course is an instance of this pair: LP strong duality (§5.2) is the case where the gap closes exactly; the MIP gap of Part IV is the same two bounds tracked during a search; the KKT residual check of §9.7 is the local version. And it explains, one installment early, the fundamental limitation of Part V: heuristics produce only feasible points, hence only *upper* bounds — never a lower bound, hence never a certificate. That is structural, not a maturity problem.

---

#### Exercises

**9.5.1 [H]** Build the Lagrangian dual of $\min\ x^2 + y^2$ s.t. $x + y \ge 2$ by hand: form $\mathcal{L}$, minimize over $(x,y)$ analytically, obtain $q(\mu)$, maximize it, and compare $q(\mu^\star)$ with $f^\star$. Confirm $q$ is concave.

**9.5.2 [C]** State exactly which hypotheses weak duality requires and which strong duality requires. Then explain why the dual function is *always* concave regardless of how horrible the primal is.

**9.5.3 [C]** Explain, using the upper-bound/lower-bound framing, why heuristics (Part V) can never provide an optimality certificate. Is this a limitation of current heuristic technology or something structural?

**9.5.4 [P]** For the problem in 9.5.1, evaluate $q(\mu)$ on a grid $\mu \in \{0, 0.5, 1, 1.5, 2, 2.5, 3, 4\}$ and confirm every value is a valid lower bound on $f^\star = 2$, with equality only at $\mu^\star$. Then verify $\mu^\star$ equals the shadow price by perturbing the right-hand side.


### 9.6 Algorithms for constrained problems

Three families dominate; you should recognize their names in solver documentation and know when each shines.

**Penalty and augmented Lagrangian.** Replace constraints by a penalty, e.g. $f(x) + \rho \sum_j h_j(x)^2$, and drive $\rho \to \infty$. Simple — but pure penalty methods become severely ill-conditioned as $\rho$ grows: the penalty term creates exactly the stretched-canyon geometry of §7.3, with $\kappa \propto \rho$. The **augmented Lagrangian** method fixes this by carrying explicit multiplier *estimates* alongside a merely moderate penalty, updating both; far more robust, and the basis of several widely used solvers.

**Sequential quadratic programming (SQP).** At each iterate, build a *quadratic* model of the Lagrangian plus a *linear* model of the constraints, solve that small QP for a step, repeat. This is Newton's method applied to the KKT system, and it inherits Newton's quadratic convergence — very few iterations, which makes SQP the method of choice when each function evaluation is expensive (a finite-element or CFD run). Worked Example 7 traces it by hand. In SciPy: `method="SLSQP"`.

**Interior-point / barrier.** Add a barrier such as $-\sigma \sum_i \log(-g_i(x))$, which blows up at the boundary, keeping iterates strictly inside; solve, shrink $\sigma$, repeat. Excellent for large sparse problems; the same technology that solves LPs and convex programs at scale (§4.3). In SciPy: `method="trust-constr"`. The industrial standard for large nonlinear problems is **IPOPT** (open source), reached through the Pyomo modeling layer; `trust-constr` is the same algorithmic family in pure Python and is what we use in this course's examples.

> **Choosing.** SQP when function evaluations dominate cost. Interior point when the problem is large and sparse. Augmented Lagrangian when constraints are messy or conditioning is poor. All three find **local** solutions unless the problem is convex; for nonconvex problems, **multi-start** from many initial points is the standard pragmatic response — and the spread of local optima it reveals is itself useful information about how rugged your landscape is.

---

#### Exercises

**9.6.1 [C]** For each of the three families — penalty/augmented Lagrangian, SQP, interior point — state what it does in one sentence, its characteristic weakness, and the SciPy or open-source solver name associated with it.

**9.6.2 [H]** Show why a pure quadratic penalty becomes ill-conditioned as $\rho \to \infty$. Take $\min x_1^2 + x_2^2$ s.t. $x_1 = 1$, form $P_\rho = x_1^2+x_2^2+\rho(x_1-1)^2$, compute its Hessian and condition number as a function of $\rho$, and connect the result to §7.3.

**9.6.3 [P]** Solve $\min e^{x_1}+2x_2^2$ s.t. $x_1+x_2=1$ with `SLSQP` and with `trust-constr`, and compare: the returned $x^\star$, the number of function evaluations, and how exactly each lands on the constraint. Which one gives the constraint-exact answer, and why?

**9.6.4 [M]** For each scenario pick a family and justify in one sentence: (a) 200 000 variables, sparse, convex; (b) each objective evaluation is a 40-minute FEA run, 15 variables; (c) constraints are badly scaled and the model is a research prototype you will change daily; (d) nonconvex with several suspected local optima.


### 9.7 Stopping criteria for constrained problems

The unconstrained tests of §7.6 are not enough. A constrained solver must certify three separate things, and you should know which tolerance is which in your solver's options:

1. **Feasibility:** $\max_i \max(0, g_i(x)) \le \varepsilon_{\text{feas}}$ and $\max_j |h_j(x)| \le \varepsilon_{\text{feas}}$.
2. **Optimality (KKT residual):** $\big\| \nabla f + \sum_i \mu_i \nabla g_i + \sum_j \lambda_j \nabla h_j \big\| \le \varepsilon_{\text{opt}}$, suitably scaled.
3. **Complementarity:** $\max_i |\mu_i\, g_i(x)| \le \varepsilon_{\text{comp}}$.

All three must hold; a solver reporting success on one of them is not done.

> **The practical implication people miss.** "Converged" with $\varepsilon_{\text{feas}} = 10^{-6}$ means your answer is *slightly infeasible* — the constraint is violated by up to $10^{-6}$. Usually harmless. But if the constraint is a hard safety limit, either tighten the tolerance or — better — build explicit margin into the constraint itself, so a solver-tolerance violation lands inside your safety factor rather than outside your allowable stress.

---

#### Exercises

**9.7.1 [C]** Name the three quantities a constrained solver must drive to zero, and give the KKT condition each one corresponds to. Why is checking one or two of them insufficient?

**9.7.2 [M]** A solver reports success with $\varepsilon_{\text{feas}} = 10^{-6}$ on a design whose active constraint is "peak stress $\le$ 250 MPa," written unscaled. How large is the possible violation in MPa, and what are the two ways of making this acceptable? Which does the course prefer, and why?

**9.7.3 [P]** Take the solution of §11.3's capped problem and compute all three residuals from the reported multipliers. Then compute them again at a deliberately truncated point (round $x^\star$ to two decimals) and report which residuals degrade the most.

**9.7.4 [C]** Explain why the complementarity residual $\max_i|\mu_ig_i|$ can be small for two entirely different reasons, and why that ambiguity matters when reading a solver log.


---

## 10. Worked Example 6 — a minimum-material pressure vessel, done twice

*This example exists to teach the most important lesson in the course:* **the formulation is the physics, and getting the physics wrong changes the answer completely** *— not by a few percent, but qualitatively. We solve the "same" problem under two different physical models, by hand with the KKT machinery of §9, and then verify everything numerically.*

### 10.1 Version A — constant wall thickness (a can, or an unpressurized tank)

Minimize the surface area of a closed cylinder of radius $r$ and height $h$ holding a required volume $V$:

$$\min_{r,h}\ A = 2\pi r^2 + 2\pi r h \quad \text{s.t.} \quad \pi r^2 h = V.$$

With $\mathcal{L} = 2\pi r^2 + 2\pi rh + \lambda (V - \pi r^2 h)$, stationarity (§9.3, condition 1) in each variable:

$$\frac{\partial \mathcal{L}}{\partial h} = 2\pi r - \lambda \pi r^2 = 0 \implies \lambda = \frac{2}{r},$$

$$\frac{\partial \mathcal{L}}{\partial r} = 4\pi r + 2\pi h - \lambda\,(2\pi r h) = 4\pi r + 2\pi h - 4\pi h = 4\pi r - 2\pi h = 0 \implies \boxed{h = 2r}.$$

**Height equals diameter**, independent of $V$. This is the classic calculus-course answer, and it is *correct — for what it models*. A beverage can, a sheet-metal enclosure, a storage tank at atmospheric pressure: anywhere the wall thickness is set by handling, corrosion allowance, or a minimum-gauge rule rather than by pressure, minimizing area *is* minimizing material, and $h = 2r$ is right.

---

#### Exercises

**10.1.1 [H]** Repeat the Version A derivation for an **open-top** cylinder (no lid): minimize $A = \pi r^2 + 2\pi r h$ subject to $\pi r^2 h = V$. Derive the optimal aspect ratio and compare with the closed-can answer $h = 2r$.

**10.1.2 [P]** Verify 10.1.1 numerically for $V = 1$ m$^3$ with a constrained solver, and confirm both the aspect ratio and the closed-form radius $r^\star = (V/\pi)^{1/3}$.

**10.1.3 [C]** The text stresses that $h = 2r$ is "correct — for what it models." List the physical situations in which minimizing *surface area* really is minimizing *material*, and one in which it is not.

**10.1.4 [M]** A real beverage can has $h/2r \approx 2.6$, not 1. Give two reasons a manufacturer would deviate from the area-optimal shape, and explain what that says about using an optimizer's answer as a design decision.


### 10.2 Version B — a real pressure vessel, where thickness is set by stress

Now pressurize it. The wall thickness is no longer a constant you can ignore: it is *determined by the stress*, which depends on the radius. Thin-wall theory (valid for $t/r \lesssim 0.1$) gives, for allowable stress $\sigma$ and internal gauge pressure $p$:

| Shape | Governing stress | Required thickness |
|---|---|---|
| cylindrical shell | hoop, $\sigma_\theta = pr/t$ | $t_c = pr/\sigma$ |
| spherical shell | $\sigma = pr/2t$ | $t_s = pr/(2\sigma)$ |

(The hoop stress governs the cylinder because it is twice the axial stress $pr/2t$; a sphere carries the same pressure with *half* the thickness. **That factor-of-two asymmetry is what drives the entire answer below.**)

Take a cylindrical barrel of radius $r$ and straight length $L$, closed by two hemispherical heads of the same radius. Material *volume* is thickness times surface area:

$$M(r, L) = \underbrace{(2\pi r L)\,\frac{pr}{\sigma}}_{\text{barrel}} \;+\; \underbrace{(4\pi r^2)\,\frac{pr}{2\sigma}}_{\text{two heads} \, = \, \text{one sphere}} \;=\; \underbrace{\frac{2\pi p}{\sigma}}_{\textstyle \equiv\, k}\big(r^2 L + r^3\big),$$

subject to the volume requirement and physical bounds:

$$\pi r^2 L + \tfrac{4}{3}\pi r^3 = V, \qquad L \ge 0, \qquad r > 0.$$

**First, a striking check before optimizing anything.** For a very long vessel, where the heads are negligible: $M \approx 2\pi p\, r^2 L / \sigma$ and $V \approx \pi r^2 L$, so

$$M \approx \frac{2p}{\sigma}\, V.$$

The barrel material depends only on the volume you must contain and the pressure-to-strength ratio — **not on the radius, not on the length, not on the aspect ratio at all.** A slender vessel and a squat one need the same steel. Version A's confident answer $h = 2r$ has not become inaccurate; it has become *an answer to a question that no longer exists*, because under pressure loading there is (to leading order) no aspect-ratio trade-off to optimize. Pause on that. Same words — "minimize material for a given volume" — and one physical assumption has dissolved the entire structure of the problem.

**Now eliminate $L$ and find what remains.** From the volume constraint, $r^2 L = V/\pi - \tfrac{4}{3} r^3$, so

$$M(r) = k\left(\frac{V}{\pi} - \frac{4}{3}r^3 + r^3\right) = k\left(\frac{V}{\pi} - \frac{r^3}{3}\right) = \frac{2p}{\sigma}\left[V - \frac{\pi}{3}\,r^3\right].$$

$M$ is **strictly decreasing in $r$**. There is no interior stationary point — no amount of hunting for $\nabla f = 0$ will produce one, because none exists. The optimizer wants $r$ as large as the constraints allow, and the binding limit is $L \ge 0$:

$$L \ge 0 \iff V \ge \tfrac{4}{3}\pi r^3 \iff r \le r_{\max} = \left(\frac{3V}{4\pi}\right)^{1/3},$$

and at $r = r_{\max}$, the straight barrel has vanished entirely: $L = 0$. **The optimal pressure vessel is a sphere.** Substituting,

$$M^\star = \frac{2p}{\sigma}\left[V - \frac{\pi}{3}\cdot\frac{3V}{4\pi}\right] = \frac{2p}{\sigma}\cdot\frac{3V}{4} = \frac{3pV}{2\sigma},$$

exactly $3/4$ of the long-cylinder value $2pV/\sigma$: **a sphere needs 25% less material than a cylindrical vessel of the same volume and pressure rating.** This is the classical result, and it is why LNG and LPG storage spheres exist.

![Vessel](figures/fig10_vessel.png)

*Figure 10.1 — Left: $M(r)$ for Version B is monotone decreasing, so the optimum sits on the bound $L = 0$ (star) — no interior stationary point exists. Right: material versus aspect ratio for both versions, each normalized to its own minimum. Version A has a genuine interior optimum at $h = 2r$; Version B is minimized at zero aspect ratio (a sphere), and is remarkably* flat *— confirming the "striking check": for pressure loading, aspect ratio barely matters, which is exactly why fabrication and transport considerations (§10.5) get to decide it in practice.*

---

#### Exercises

**10.2.1 [H]** Derive the "striking check": show that for a long cylindrical vessel where the heads are negligible, the material volume is $M \approx 2pV/\sigma$, independent of $r$, $L$ and aspect ratio. Explain in one sentence what this means for Version A's answer.

**10.2.2 [H]** Carry out the elimination of $L$ yourself: use the volume constraint to show $M(r) = k\big(V/\pi - r^3/3\big)$ with $k = 2\pi p/\sigma$, and hence that $M$ is strictly decreasing in $r$. Where does the factor $-1/3$ come from physically?

**10.2.3 [H]** Derive $r_{\max} = (3V/4\pi)^{1/3}$ from $L \ge 0$, and show that at $r = r_{\max}$ the material is $M^\star = 3pV/2\sigma$ — exactly $3/4$ of the long-cylinder value.

**10.2.4 [P]** For $V = 10$ m³, $p = 2$ MPa, $\sigma = 150$ MPa, tabulate $M(r)$ (in kg of steel at 7850 kg/m³) for $r \in \{0.6, 0.8, 1.0, 1.2, 1.3365\}$ with $L$ set by the volume constraint. Confirm monotonicity and the sphere value of 1570 kg. Also check that thin-wall theory is valid at the optimum.

**10.2.5 [C]** Why does the *sphere* need only half the wall thickness of a cylinder at the same pressure and radius? State the two stress formulas and identify which one governs the cylinder and why.


### 10.3 The KKT conditions at an active bound

Version B is a genuinely instructive KKT exercise, because the answer sits on an inequality with a *nonzero* multiplier — the situation §9.3 was built for. Write the bound as $g(r, L) = -L \le 0$ and form the Lagrangian:

$$\mathcal{L} = k(r^2 L + r^3) + \lambda\Big[V - \pi r^2 L - \tfrac{4}{3}\pi r^3\Big] + \mu\,(-L), \qquad \mu \ge 0.$$

Stationarity in both variables:

$$\frac{\partial \mathcal{L}}{\partial L} = k r^2 - \lambda \pi r^2 - \mu = 0, \qquad \frac{\partial \mathcal{L}}{\partial r} = k(2rL + 3r^2) - \lambda(2\pi r L + 4\pi r^2) = 0.$$

**Case A: $L > 0$ (interior — is a cylinder ever optimal?).** Complementary slackness (§9.3, condition 4) forces $\mu = 0$, so the first equation gives $\lambda = k/\pi$. Substitute into the second:

$$k(2rL + 3r^2) - \frac{k}{\pi}(2\pi r L + 4\pi r^2) = k(2rL + 3r^2) - k(2rL + 4r^2) = -k r^2 = 0 \implies r = 0,$$

contradicting $r > 0$. **No KKT point exists with $L > 0$** — the algebra confirms what the monotonicity already told us: no cylinder of positive length is even a candidate.

**Case B: $L = 0$ (on the bound).** With $L = 0$, the second equation gives $3k r^2 = 4\pi \lambda r^2$, so $\lambda = \dfrac{3k}{4\pi}$, and then the first gives

$$\mu = k r^2 - \lambda \pi r^2 = k r^2 - \tfrac{3}{4}k r^2 = \frac{k r^2}{4} > 0. \quad \checkmark$$

Dual feasibility holds *strictly*, so this is the unique KKT point: $L^\star = 0$, $r^\star = r_{\max}$, with multiplier $\mu^\star = k r^{\star 2}/4$ on the length bound.

> **The general lesson.** When the objective is monotone in some variable, the optimum sits on a bound, and *the bound is doing the design work*. Whenever a solution has a variable pinned at a bound, ask: is this a real physical limit, or an artifact of my model? Here $L \ge 0$ is real geometry — negative length does not exist. But had we written $L \ge 0.5$ m "for convenience," the answer would have come back $L = 0.5$ and we would have "optimized" nothing at all: the answer would have been our own arbitrary bound, echoed back to us.

---

#### Exercises

**10.3.1 [H]** Reproduce Case A of the §10.3 argument in full: assume $L>0$, apply complementary slackness, and derive the contradiction $r = 0$. State clearly what this proves.

**10.3.2 [H]** Reproduce Case B: set $L = 0$, solve for $\lambda$ and $\mu$, and check dual feasibility. What would it have meant if $\mu$ had come out negative?

**10.3.3 [M]** State the general lesson about optima on bounds, then apply it: a colleague's model returns a wall thickness pinned at the lower bound $t = 3$ mm, which they chose "as a reasonable minimum." What do you tell them, and what two things would you check?

**10.3.4 [C]** Explain why checking monotonicity of the objective in each variable *before* running a solver is worth the five minutes, giving two distinct things it can reveal.


### 10.4 What the multiplier prices — with real numbers

$\mu^\star$ is the multiplier on $-L \le 0$. Perturb the bound to $L \ge L_{\min}$ (i.e., $-L \le -L_{\min}$); then by §9.4, $\partial M^\star / \partial L_{\min} = \mu^\star$. So $\mu^\star$ is **the material cost per metre of mandated straight length** — and process requirements *do* mandate straight length: room for internals, trays, a manhole, agitator clearance, nozzle spacing.

Concrete numbers. Take $V = 10\ \text{m}^3$, $p = 2\ \text{MPa}$, $\sigma = 150\ \text{MPa}$, steel at $7850\ \text{kg/m}^3$. Then $k = 2\pi p/\sigma = 0.08378\ \text{m}^{-1}\cdot$(dimensionless form) and:

| Quantity | Value |
|---|---|
| $r^\star = (3V/4\pi)^{1/3}$ | $1.337$ m |
| head thickness $t_s = p r^\star / 2\sigma$ | $8.9$ mm — so $t/r = 0.007 \ll 0.1$: thin-wall theory valid ✓ |
| $M^\star$ (sphere) $= 3pV/2\sigma$ | $0.200\ \text{m}^3$ $= 1570$ kg |
| $M$ (long cylinder, same $V$) $= 2pV/\sigma$ | $0.267\ \text{m}^3$ $= 2093$ kg |
| material saved by the sphere | $523$ kg (25%) |
| $\mu^\star = k r^{\star 2}/4$ | $0.0374\ \text{m}^3$ per metre $= 294$ kg per metre |

**Verify everything numerically** — the analytic optimum, the KKT multiplier, all of it — with a general-purpose constrained solver that has never heard of thin-wall theory:

```python
"""Worked Example 6: numerical verification of the vessel optimum and multiplier."""
import numpy as np
from scipy.optimize import minimize

V, p, sig = 10.0, 2e6, 150e6
k = 2*np.pi*p/sig

def solve_vessel(Lmin):
    M = lambda z: k*(z[0]**2*z[1] + z[0]**3)                      # material volume
    vol = {"type": "eq",
           "fun": lambda z: np.pi*z[0]**2*z[1] + 4/3*np.pi*z[0]**3 - V}
    r = minimize(M, x0=[1.3, 0.05], constraints=[vol],
                 bounds=[(1e-3, None), (Lmin, None)],
                 method="SLSQP", options={"ftol": 1e-16, "maxiter": 800})
    return r.fun, r.x

M0, z0 = solve_vessel(0.0)
print(f"optimum: r = {z0[0]:.4f} m, L = {z0[1]:.4f} m, M = {M0:.4f} m^3")
print(f"analytic: r* = {(3*V/(4*np.pi))**(1/3):.4f} m, L* = 0, M* = {3*p*V/(2*sig):.4f} m^3")

# multiplier check: finite-difference the value function in L_min
M1, _ = solve_vessel(1e-3)
print(f"dM*/dL_min (numeric)  = {(M1 - M0)/1e-3:.5f} m^3/m")
print(f"mu* = k r*^2 / 4      = {k*(3*V/(4*np.pi))**(2/3)/4:.5f} m^3/m"
      f"  =  {7850*k*(3*V/(4*np.pi))**(2/3)/4:.0f} kg per metre")
```

```
optimum: r = 1.3365 m, L = 0.0000 m, M = 0.2000 m^3
analytic: r* = 1.3365 m, L* = 0, M* = 0.2000 m^3
dM*/dL_min (numeric)  = 0.03740 m^3/m
mu* = k r*^2 / 4      = 0.03741 m^3/m  =  294 kg per metre
```

The solver lands on the sphere, and the finite-difference slope of the value function matches the hand-derived multiplier to four digits. The KKT machinery is not a formality — it *predicts the economics of the design*, and the prediction checks out numerically.

---

#### Exercises

**10.4.1 [H]** Using $V=10$ m³, $p=2$ MPa, $\sigma=150$ MPa and steel at 7850 kg/m³, compute $k$, $r^\star$, $M^\star$ in kg, and $\mu^\star = kr^{\star2}/4$ in both m³/m and kg/m. Show every step.

**10.4.2 [P]** **A transport limit changes the answer.** Road transport caps the vessel radius at $r \le r_{\max}^{\text{road}}$. Re-solve the vessel problem numerically for $r_{\max}^{\text{road}} \in \{1.6, 1.2, 1.0, 0.8\}$ m, reporting $r^\star$, $L^\star$ and mass. Then compute the multiplier on the active radius bound by finite-differencing the value function, and compare it with the analytic $dM/dr = -kr^2$.

**10.4.3 [M]** Interpret your 10.4.2 results for a design review: what does the 1.0 m transport limit cost in kilograms, and what is one extra metre of permitted radius worth? How would you use these numbers in a negotiation with the logistics department?

**10.4.4 [C]** The multiplier on $L \ge L_{\min}$ is 294 kg per metre. A process engineer needs 1.5 m of straight length for internals. Estimate the mass penalty, state the assumption in your estimate, and say how you would check it.


### 10.5 What the model still omits — and why that is the point

The answer "build a sphere" is correct *for the model as written* — and yet most pressure vessels in the world are cylinders. That is not a contradiction. It is a precise list of what the model left out:

- **Fabrication cost.** Cylindrical shells are rolled from flat plate on standard machinery. Spherical shells need double-curvature forming, many more welds, and far more inspection. This usually dominates the 25% material saving.
- **Transport and support.** Cylinders ship on trucks and sit in saddles; spheres need bespoke skirts and legs.
- **Access and internals.** Trays, baffles, and agitators need straight length — the very requirement that $\mu^\star$ prices.

Add a fabrication cost term and $L^\star > 0$ reappears. And notice what the optimization did for that conversation even *before* the term is added: $\mu^\star = 294$ kg per metre is exactly the number to weigh against the fabrication saving per metre of cylinder. The optimizer did not make the final decision — it reduced a vague multi-department argument to a single quantitative comparison. That is what a good model is for.

> **Carry away from this example:**
> 1. The same words — "minimize material for a given volume" — gave two completely different answers, $h = 2r$ versus a sphere, because the *physics* differed. Get the physics right before the mathematics; no algorithm can rescue a wrong objective.
> 2. An optimum can sit on a bound, with no interior stationary point anywhere. Check monotonicity before hunting for $\nabla f = 0$.
> 3. A "wrong" answer that contradicts practice is not a failure — it is a list of what your model is missing, and the multipliers tell you what each missing consideration is worth.

---

#### Exercises

**10.5.1 [C]** List the three categories of omitted consideration named in §10.5, and for each say whether it would push $L^\star$ up, down, or leave it unchanged.

**10.5.2 [M]** Most real pressure vessels are cylinders, yet the model says "sphere." Explain why this is *not* evidence that the optimization was useless, and state precisely what the model did contribute to the decision.

**10.5.3 [P]** Add a crude fabrication-cost term and watch $L^\star>0$ reappear. Minimize total cost $= c_s\rho M(r,L) + c_f\,(4\pi r^2)$ where the second term charges for double-curvature head forming, with $c_s = 2$ \$/kg and $c_f = 400$ \$/m². Impose a transport bound $r \le 1.3$ m and a sensible lower bound on $r$, and report the optimal $(r, L)$ and how the split of cost changes as $c_f$ rises. Explain why a lower bound on $r$ (or an upper bound on $L$) is *necessary* for this model to be well posed.

**10.5.4 [C]** State the three "carry away" lessons of §10 in your own words, and give one example from your own field of a model whose "wrong" answer would be informative.


---

## 11. Worked Example 7 — what a constrained solver actually does

Chapters 9–10 gave you the *conditions* a constrained optimum satisfies. This example shows the *process*: an SQP solver traced iteration by iteration on a problem small enough to follow every number, then the same machinery applied through SciPy's production solvers, with the multipliers read out and checked against a hand KKT solution. After this, a constrained solver is no longer a black box.

### 11.1 The problem, and its exact solution

$$\min_{x_1, x_2}\ f(x) = e^{x_1} + 2x_2^2 \qquad \text{s.t.} \qquad h(x) = x_1 + x_2 - 1 = 0.$$

(Read it as a toy resource split: one unit of effort divided between two activities with different cost curves.) The KKT system (§9.3): $\nabla f + \lambda \nabla h = 0$ and $h = 0$, i.e.

$$e^{x_1} + \lambda = 0, \qquad 4x_2 + \lambda = 0, \qquad x_1 + x_2 = 1.$$

Eliminate $\lambda$: $e^{x_1} = 4x_2 = 4(1 - x_1)$ — one nonlinear equation in $x_1$. It has no closed form, and *that is realistic*: most constrained optima cannot be written down, which is exactly why iterative solvers exist. Numerically (we will confirm), $x^\star = (0.561622,\ 0.438378)$, $\lambda^\star = -e^{x_1^\star} = -1.753514$, $f^\star = 2.137865$.

---

#### Exercises

**11.1.1 [H]** Derive the KKT system for $\min e^{x_1}+2x_2^2$ s.t. $x_1+x_2 = 1$, eliminate $\lambda$, and obtain the single nonlinear equation in $x_1$. Solve it to six digits with any root-finder (by hand: two or three bisection/Newton steps from $x_1 = 0.5$).

**11.1.2 [C]** The text notes that this optimum "has no closed form, and that is realistic." Explain why the absence of a closed form is the normal case in engineering optimization, and what that implies about what you should verify instead of "the formula."

**11.1.3 [P]** Confirm $x^\star$, $\lambda^\star$ and $f^\star$ with (i) `scipy.optimize.brentq` on your scalar equation and (ii) `minimize` with the constraint. Check the two agree to at least eight digits.

**11.1.4 [H]** Interpret the problem as a resource split: one unit of effort divided between two activities with cost curves $e^{x_1}$ and $2x_2^2$. What does the optimality condition say in economic terms, and what is the interpretation of $\lambda^\star = -1.7535$?


### 11.2 The SQP iteration, by hand

SQP (§9.6) repeats one move: **replace the Lagrangian by its quadratic model and the constraint by its linear model, and solve that small problem exactly for the step.** For an equality-constrained problem, the step $d$ and the *new* multiplier estimate $\lambda^{+}$ solve the linear **KKT system**

$$\begin{pmatrix} \nabla^2_{xx} \mathcal{L} & \nabla h \\ \nabla h^\top & 0 \end{pmatrix} \begin{pmatrix} d \\ \lambda^{+} \end{pmatrix} = \begin{pmatrix} -\nabla f \\ -h \end{pmatrix}.$$

For our problem, $\nabla f = (e^{x_1},\ 4x_2)$, $\nabla h = (1, 1)$, and — since $h$ is linear, $\nabla^2_{xx}\mathcal{L} = \nabla^2 f$ — the Hessian block is $\text{diag}(e^{x_1},\ 4)$.

**Iteration 1, fully by hand.** Start at $x^{(0)} = (0, 0)$: $\nabla f = (1, 0)$, Hessian $= \text{diag}(1, 4)$, $h = -1$ (infeasible by one unit). The KKT system is

$$\begin{pmatrix} 1 & 0 & 1 \\ 0 & 4 & 1 \\ 1 & 1 & 0 \end{pmatrix} \begin{pmatrix} d_1 \\ d_2 \\ \lambda^{+} \end{pmatrix} = \begin{pmatrix} -1 \\ 0 \\ 1 \end{pmatrix}.$$

Row 1: $d_1 = -1 - \lambda^{+}$. Row 2: $d_2 = -\lambda^{+}/4$. Row 3: $d_1 + d_2 = 1$, so $-1 - \lambda^{+} - \lambda^{+}/4 = 1$, giving $\lambda^{+} = -1.6$, hence $d = (0.6,\ 0.4)$ and

$$x^{(1)} = (0.6,\ 0.4).$$

Notice two things about this single step. The new point is **exactly feasible** ($0.6 + 0.4 = 1$) — the linearized constraint was the true constraint here, since $h$ is linear, so one step repairs all infeasibility. And the multiplier estimate $-1.6$ is already close to $\lambda^\star = -1.7535$.

**Let the machine do iterations 2 onward** — same twelve lines of algebra, repeated:

```python
"""Worked Example 7a: a bare-bones SQP loop, every iterate printed."""
import numpy as np

x = np.array([0.0, 0.0])
for k in range(5):
    gf = np.array([np.exp(x[0]), 4*x[1]])          # gradient of f
    H  = np.diag([np.exp(x[0]), 4.0])              # Hessian of the Lagrangian
    a  = np.array([1.0, 1.0])                      # gradient of h
    h  = x[0] + x[1] - 1.0
    KKT = np.block([[H, a.reshape(2, 1)],
                    [a.reshape(1, 2), np.zeros((1, 1))]])
    d1, d2, lam = np.linalg.solve(KKT, np.array([-gf[0], -gf[1], -h]))
    d = np.array([d1, d2])
    print(f"k={k}  x=({x[0]:+.6f},{x[1]:+.6f})  h={h:+.1e}  "
          f"lam={lam:+.6f}  |step|={np.linalg.norm(d):.2e}")
    x = x + d
print(f"final x = ({x[0]:.6f}, {x[1]:.6f}),  f = {np.exp(x[0]) + 2*x[1]**2:.6f}")
```

```
k=0  x=(+0.000000,+0.000000)  h=-1.0e+00  lam=-1.600000  |step|=7.21e-01
k=1  x=(+0.600000,+0.400000)  h=+0.0e+00  lam=-1.752603  |step|=5.40e-02
k=2  x=(+0.561849,+0.438151)  h=+0.0e+00  lam=-1.753514  |step|=3.22e-04
k=3  x=(+0.561622,+0.438378)  h=+0.0e+00  lam=-1.753514  |step|=1.12e-08
k=4  x=(+0.561622,+0.438378)  h=+0.0e+00  lam=-1.753514  |step|=0.00e+00
final x = (0.561622, 0.438378),  f = 2.137865
```

**Read the `|step|` column: $7\times 10^{-1} \to 5\times 10^{-2} \to 3\times 10^{-4} \to 1\times 10^{-8}$.** The number of correct digits roughly doubles per iteration — quadratic convergence (§7.4), live, on a constrained problem. Four iterations to machine precision. This is why SQP is the method of choice when each function evaluation is a twenty-minute finite-element run: it is stingy with iterations, because each one extracts everything the local models know.

(Production SQP codes add safeguards our toy omits — a line search or trust region for global behavior far from the solution, quasi-Newton Hessian updates when second derivatives are unavailable, and an active-set mechanism to decide *which* inequalities to treat as equalities at each iterate. The core step, though, is exactly the linear system you just solved by hand.)

---

#### Exercises

**11.2.1 [H]** Carry out SQP iteration 1 by hand for the §11.1 problem from the *different* start $x^{(0)} = (1, 0)$: build the $3\times3$ KKT system, solve it, and report $d$, $\lambda^+$ and $x^{(1)}$. Is $x^{(1)}$ feasible, and why?

**11.2.2 [P]** Run the bare-bones SQP loop from $(1,0)$ for five iterations and tabulate $|d|$. Confirm the roughly-doubling-digits pattern and state the convergence order you observe.

**11.2.3 [P]** **Why the Hessian of the *Lagrangian*, not of the objective.** Take the nonlinearly constrained problem
$$\min\ x_1^2 + x_2^2 \quad\text{s.t.}\quad x_1x_2 = 1,$$
whose exact solution is $x^\star = (1,1)$, $\lambda^\star = -2$, $f^\star = 2$. Run SQP from $x^{(0)} = (2, 0.5)$ twice: (a) using $\nabla^2 f$ as the Hessian block; (b) using the true $\nabla^2_{xx}\mathcal{L} = \nabla^2 f + \lambda\nabla^2 h$. Tabulate $|d|$ for six iterations in each case and describe what happens.

**11.2.4 [C]** In the §11.1 problem the constraint is linear, so one SQP step restores exact feasibility. What changes when the constraint is nonlinear (as in 11.2.3), and what does that imply about reading the constraint residual as a convergence measure?

**11.2.5 [C]** Name the three safeguards that production SQP codes add to the bare loop, and say what failure each prevents.


### 11.3 Adding an inequality, and reading the multipliers

Now impose a design limit: $x_2 \le 0.3$ (activity 2 is capped). Since the unconstrained-in-$x_2$ answer wanted $x_2 = 0.438 > 0.3$, we expect the cap to be **active**, and the KKT conditions tell us everything by hand: with $x_2 = 0.3$ forced, $x_1 = 0.7$, and stationarity with multiplier $\mu$ on $g = x_2 - 0.3 \le 0$ reads

$$e^{x_1} + \lambda = 0 \implies \lambda = -e^{0.7} = -2.0138, \qquad 4x_2 + \lambda + \mu = 0 \implies \mu = 2.0138 - 1.2 = 0.8138 > 0\ \checkmark$$

Dual feasibility holds, so this is the optimum: $f^\star = e^{0.7} + 2(0.09) = 2.1938$. Now the machine, using both production solvers from §9.6 — SLSQP (the SQP family) and trust-constr (the interior-point family) — and, crucially, **reading the multipliers out of the solver**:

```python
"""Worked Example 7b: inequality-constrained solve, multipliers read and checked."""
import numpy as np
from scipy.optimize import minimize, LinearConstraint

f  = lambda x: np.exp(x[0]) + 2*x[1]**2
gf = lambda x: np.array([np.exp(x[0]), 4*x[1]])

r = minimize(f, [0, 0], jac=gf, method="trust-constr",
             constraints=[LinearConstraint([[1, 1]], 1, 1),        # x1 + x2  = 1
                          LinearConstraint([[0, 1]], -np.inf, 0.3)],  # x2 <= 0.3
             tol=1e-10)

print("x* =", np.round(r.x, 5), "  f* =", round(r.fun, 6))
print("multiplier on equality  :", round(float(r.v[0][0]), 4), "  (hand: -2.0138)")
print("multiplier on inequality:", round(float(r.v[1][0]), 4), "  (hand: +0.8138)")
```

```
x* = [0.70004 0.29996]   f* = 2.193785
multiplier on equality  : -2.0138   (hand: -2.0138)
multiplier on inequality: 0.814   (hand: +0.8138)
```

Both multipliers match the hand KKT solution. And now *interpret* them, because that is the entire point of computing them (§9.4): the inequality's multiplier $\mu \approx 0.81$ says **each unit of relaxation of the cap on $x_2$ is worth $0.81$ units of objective** — before anyone re-solves anything, you can tell the owner of that constraint what their limit is costing. The last digits of $x^\star$ reflect the interior-point tolerance (it approaches the boundary rather than landing on it exactly — §9.7's point about tolerances, visible in the output); `method="SLSQP"` on the same problem returns the vertex-exact $(0.7, 0.3)$.

> **The habit this example installs.** After every constrained solve: (1) check which constraints are active; (2) read the multipliers; (3) sanity-check at least one multiplier against a perturbed re-solve or a hand KKT argument. Ten minutes, and the difference between *having* an answer and *understanding* it.

---

#### Exercises

**11.3.1 [H]** Impose the tighter cap $x_2 \le 0.2$ on the §11.1 problem. Solve the KKT system by hand: give $x^\star$, $\lambda^\star$, $\mu^\star$, $f^\star$, and verify dual feasibility.

**11.3.2 [P]** Verify 11.3.1 with `trust-constr` and with `SLSQP`, reading the multipliers out of each. Compare how exactly each method lands on the active constraint, and explain the difference.

**11.3.3 [M]** Interpret $\mu^\star$ from 11.3.1 for the owner of the cap: what is one unit of relaxation worth, and what would you say if they asked to relax it by 0.5 (i.e. to $x_2 \le 0.7$)?

**11.3.4 [C]** State the three-step habit §11.3 installs, and explain what each step protects you from.


---

## 12. Where derivatives come from

Everything in §7–§11 assumed you can supply $\nabla f$. In practice, **gradient quality decides whether any of it works** — a subtly wrong gradient produces a solver that limps, stalls, or converges to the wrong point, usually without a clear error message. This chapter is the field guide.

| Source | Accuracy | Cost | Notes |
|---|---|---|---|
| **Analytic** (hand-derived) | exact | your time — and your algebra errors | Best where feasible. *Always* verify against finite differences before trusting (the §0.1 experiment). |
| **Automatic differentiation (AD)** | exact to machine precision | ~1–4× one function evaluation | Applies the chain rule through your source code. *Reverse mode* gives the full gradient of a scalar at a cost nearly independent of $n$. The modern default (JAX, PyTorch, CasADi). |
| **Adjoint methods** | exact | ~1 extra PDE solve | Reverse-mode AD as practiced in FEM/CFD. Makes shape optimization with thousands of design variables possible. |
| **Complex-step** | effectively exact | 1 complex evaluation per variable | See §12.2 — remarkable and underused. |
| **Finite differences** | approximate, often poor | $n{+}1$ (forward) or $2n$ (central) evaluations | The universal fallback. Read the trap below before relying on it. |

### 12.1 The finite-difference step-size trap

The forward difference $\big(f(x+h) - f(x)\big)/h$ carries two errors pulling in **opposite directions**: *truncation* error $O(h)$ from cutting off the Taylor series, which wants $h$ small — and *round-off* error $O(\epsilon_{\text{mach}}/h)$ from subtracting two nearly equal floating-point numbers, which wants $h$ large. You cannot win both; you can only balance them:

$$h^\star \approx \sqrt{\epsilon_{\text{mach}}}\;|x| \approx 1.5\times 10^{-8}\,|x| \quad \text{(forward: retains about half the available digits)}$$
$$h^\star \approx \epsilon_{\text{mach}}^{1/3}\,|x| \approx 6\times 10^{-6}\,|x| \quad \text{(central: about two-thirds of the digits, at twice the cost)}$$

Watch the trap spring, on the friendliest function imaginable:

```python
"""The finite-difference V-curve, and the complex-step escape."""
import numpy as np

x0, exact = 1.0, np.exp(1.0)          # f = exp, f'(1) = e
for h in [1e-1, 1e-4, 1e-8, 1e-12]:
    fwd = (np.exp(x0 + h) - np.exp(x0)) / h
    cen = (np.exp(x0 + h) - np.exp(x0 - h)) / (2*h)
    cst = np.imag(np.exp(x0 + 1j*h)) / h            # complex step
    print(f"h={h:.0e}   fwd err={abs(fwd-exact):.1e}   "
          f"cen err={abs(cen-exact):.1e}   cstep err={abs(cst-exact):.1e}")
```

```
h=1e-01   fwd err=1.4e-01   cen err=4.5e-03   cstep err=4.5e-03
h=1e-04   fwd err=1.4e-04   cen err=4.5e-09   cstep err=4.5e-09
h=1e-08   fwd err=6.6e-09   cen err=6.6e-09   cstep err=0.0e+00
h=1e-12   fwd err=4.3e-04   cen err=2.1e-04   cstep err=0.0e+00
```

Read the last row: at $h = 10^{-12}$ — "smaller must be more accurate," says intuition — the finite differences have *lost* five orders of magnitude of accuracy to round-off. There is a best $h$, it is nowhere near zero, and missing it by a few decades ruins the gradient.

![The FD V-curve](figures/fig11_fd.png)

*Figure 12.1 — Error versus step size for $f'(1)$, $f = e^x$. Both finite differences trace a V: truncation error falls to the right, round-off rises to the left, and the best achievable error sits at the bottom of the V — around $10^{-8}$ accuracy for forward differences, no matter how careful you are. The complex step (green) has no subtraction, hence no left branch: its error just keeps falling until it hits exact zero.*

**The trap in the field.** The formulas above assume noise at the level $\epsilon_{\text{mach}} \approx 10^{-16}$. If $f$ comes from a *simulation* with its own convergence tolerance of, say, $10^{-6}$, then **that** is your effective noise floor — and the same balancing act gives a best-achievable gradient error near $\sqrt{10^{-6}} = 10^{-3}$, often worse than useless. Recognizing this situation — noisy, expensive, black-box $f$ — is what legitimately sends you to Part V's derivative-free methods. Going there is a diagnosis, not a defeat.

---

#### Exercises

**12.1.1 [H]** Derive the optimal forward-difference step $h^\star \approx \sqrt{\epsilon_{\text{mach}}}|x|$ by writing total error as truncation $\approx \tfrac12 h|f''|$ plus round-off $\approx 2\epsilon_{\text{mach}}|f|/h$ and minimizing over $h$. Then repeat for central differences and obtain the $\epsilon^{1/3}$ rule.

**12.1.2 [P]** Reproduce the V-curve for $f(x) = \sin x$ at $x = 1$: tabulate forward-difference, central-difference and complex-step errors for $h = 10^{-1}, 10^{-4}, 10^{-8}, 10^{-12}$. Identify the best $h$ for each method and the floor each one hits.

**12.1.3 [P]** **The trap in the field.** Simulate a "simulation with a convergence tolerance" by $f(x) = e^x(1 + 10^{-6}\eta)$ with $\eta \sim N(0,1)$ fresh per evaluation. For $h \in \{10^{-1},10^{-2},10^{-3},10^{-4},10^{-6},10^{-8}\}$ estimate the median absolute error of the forward difference to $f'(1) = e$ over 200 repetitions. Where is the best $h$, how large is the error there, and how does that compare with the noise-free case?

**12.1.4 [M]** Your objective is a CFD run whose residual is converged to $10^{-5}$, and you have 30 design variables. Using 12.1.3's reasoning, estimate the best achievable finite-difference gradient accuracy and the per-iteration cost. What do you conclude, and which part of the course does that conclusion point to?


### 12.2 Complex-step differentiation: the escape hatch

If $f$ is real-valued on the real axis and analytic (built from smooth operations), evaluate it *at a complex point* and look at the imaginary part:

$$f(x + ih) = f(x) + ih\,f'(x) - \frac{h^2}{2}f''(x) - \frac{ih^3}{6}f'''(x) + \cdots \;\implies\; f'(x) = \frac{\operatorname{Im}\big[f(x + ih)\big]}{h} + O(h^2).$$

There is **no subtraction of nearly equal quantities anywhere**, so round-off never enters. Take $h = 10^{-20}$ and get derivatives to full machine precision — the output above shows error *exactly zero*. The requirements: your code must run in complex arithmetic (NumPy mostly just does), and every operation must preserve analyticity — `abs`, `min`, `max`, and comparison-based branches need care. When you have legacy code you cannot autodiff but can run in complex arithmetic, this is often the best option in existence.

---

#### Exercises

**12.2.1 [H]** Derive the complex-step formula: expand $f(x+ih)$ in a Taylor series, take the imaginary part, and show $f'(x) = \operatorname{Im}[f(x+ih)]/h + O(h^2)$. Explain precisely why no subtractive cancellation occurs.

**12.2.2 [C]** List the requirements on your code for complex-step to work, and name three specific Python/NumPy operations that would silently break it.

**12.2.3 [P]** Demonstrate a failure. For $f(x) = x\,|x|$ (whose derivative at $x=2$ is $2|x| = 4$), compute the complex-step estimate with `abs` and show it returns the wrong value. Then fix it by replacing `abs` with an analyticity-preserving branch and confirm you recover 4.

**12.2.4 [M]** You have inherited 40 000 lines of Fortran that computes a thermal-stress objective, with no AD tooling available but full source access. Argue for complex-step over finite differences, and state the two practical costs of the conversion.


### 12.3 Automatic differentiation in twenty lines

AD sounds like magic; it is bookkeeping. *Forward-mode* AD carries, alongside every value, its derivative — and propagates both through each operation by the chain rule. A minimal implementation makes the idea concrete:

```python
"""Forward-mode AD from scratch: dual numbers."""
import math

class Dual:
    def __init__(self, val, der=0.0):
        self.val, self.der = val, der
    def __add__(self, o):
        o = o if isinstance(o, Dual) else Dual(o)
        return Dual(self.val + o.val, self.der + o.der)
    __radd__ = __add__
    def __mul__(self, o):
        o = o if isinstance(o, Dual) else Dual(o)
        return Dual(self.val * o.val,
                    self.der * o.val + self.val * o.der)     # product rule
    __rmul__ = __mul__

def exp(z):
    e = math.exp(z.val)
    return Dual(e, e * z.der)                                # chain rule

# f(x) = x * exp(x) + 3x   ->   f'(x) = (1+x) e^x + 3
x = Dual(1.5, 1.0)            # seed derivative dx/dx = 1
y = x * exp(x) + 3 * x
print(f"f (1.5) = {y.val:.10f}")
print(f"f'(1.5) = {y.der:.10f}   (exact: {(1+1.5)*math.exp(1.5)+3:.10f})")
```

```
f (1.5) = 11.2225336055
f'(1.5) = 14.2042226758   (exact: 14.2042226758)
```

Exact to every printed digit, no step size anywhere — because each rule (`der*o.val + val*o.der` is the product rule; `e*z.der` is the chain rule) is applied *symbolically-exactly, numerically*. Production AD systems (JAX, PyTorch, CasADi) are this idea, engineered: reverse mode reorganizes the same chain rule so that one backward sweep yields the gradient with respect to *all* $n$ inputs at once — which is why training a neural network with $10^9$ parameters, or shape-optimizing a wing with $10^4$ design variables via adjoints, is possible at all.

> **The gradient checklist, before you blame the optimizer.** (1) If you derived $\nabla f$ by hand, compare it against a central difference at a random point — they should agree to ~6 digits. (2) If you must use finite differences, use the $h^\star$ rules above, scaled by $|x|$ per component. (3) If $f$ is a noisy simulation, do not use finite differences at all — go to Part V. (4) If you control the source code, prefer AD or complex-step; both are exact.

---

#### Exercises

**12.3.1 [H]** Explain what the two fields of a dual number represent, and derive the update rules for `__mul__` and for `exp` from the product and chain rules. Why is the "seed" derivative set to 1?

**12.3.2 [P]** Extend the `Dual` class of §12.3 with `__sub__`, `__rsub__`, `__truediv__` and a `sin` function, then compute both partial derivatives of
$$f(a,b) = a^2b + \sin(ab) \quad\text{at } (a,b) = (1.5,\ 2.0)$$
by running the code twice with different seeds. Verify against the analytic gradient. How many passes does forward-mode need for an $n$-variable gradient?

**12.3.3 [C]** Contrast forward and reverse mode: for a function $\mathbb{R}^n \to \mathbb{R}$, state the cost of a full gradient in each, and explain why reverse mode is what makes neural-network training and adjoint shape optimization possible.

**12.3.4 [M]** Reproduce the four-point gradient checklist of §12, and for each item name the failure it prevents and the section of the course where that failure appeared.


---

## Checkpoint — Part III

You should now be able to:

- state the first- and second-order optimality conditions, classify a stationary point from Hessian eigenvalues, and explain why "$\|\nabla f\|$ small" does not by itself mean "minimum";
- reproduce the zigzag example by hand for one step, state the $\left(\frac{\kappa-1}{\kappa+1}\right)^2$ bound, and connect it to variable scaling;
- choose among steepest descent, CG, BFGS/L-BFGS, and Newton for a given problem, and call them through `scipy.optimize.minimize`;
- explain the $J^\top J$ structure of least squares, fit a model with `least_squares`, and compute standard errors and $\text{cond}(J^\top J)$ — and act on what they say;
- diagnose an unidentifiable fit and explain why the remedy is experimental design, not a better optimizer;
- draw the tangency picture, write the Lagrangian, and state all four KKT conditions with their interpretations;
- solve a small constrained problem by KKT case analysis (as in the vessel), including verifying $\mu \ge 0$ on the active bound;
- state weak duality with its two-line proof, compute a dual function by hand for a one-variable problem, and explain the bounds-meeting principle of certification;
- trace one SQP iteration by hand, and read + interpret + verify multipliers from `trust-constr`;
- choose a derivative source, state the finite-difference $h^\star$ rules and why they exist, and use complex-step or dual numbers when exactness matters.

## Self-test — Part III

**Q1.** For $f(x_1,x_2) = x_1^2 + 4x_2^2 - 4x_1x_2 + x_1$: find all stationary points and classify them. What does the classification imply about what a solver would report?

**Q2.** A colleague's steepest-descent code takes 4000 iterations on a problem where variables range from $10^{-3}$ (a thickness in metres) to $10^{7}$ (a pressure in pascals). Estimate why, and propose the fix with the expected effect.

**Q3.** You fit a 5-parameter reaction model to lab data. The solver converges; the fitted curve looks perfect; $\text{cond}(J^\top J) = 4 \times 10^{9}$. Your PI wants to publish the rate constants. What do you tell them, and what do you propose?

**Q4.** Solve by KKT case analysis: $\min\ x_1^2 + x_2^2$ s.t. $x_1 + x_2 \ge 4$. (Hint: is the constraint active? Check both cases.) Report $x^\star$, $\mu^\star$, and interpret $\mu^\star$.

**Q5.** Using the dual-function recipe of §9.5, compute $q(\mu)$ for $\min\ x^2$ s.t. $x \ge 3$, verify that $q(\mu) \le f^\star$ for $\mu = 2$ and $\mu = 10$, and find the tight bound.

**Q6.** A solver on a safety-critical stress constraint reports success with feasibility tolerance $10^{-6}$, and the constraint is exactly active. What is the concern and the fix?

**Answers.**

**A1.** $\nabla f = (2x_1 - 4x_2 + 1,\ 8x_2 - 4x_1) = 0$. From the second equation $x_1 = 2x_2$; substituting: $4x_2 - 4x_2 + 1 = 1 \ne 0$ — **no stationary point exists**. Check the Hessian $\begin{pmatrix}2 & -4\\ -4 & 8\end{pmatrix}$: it has determinant $0$ (eigenvalues $0$ and $10$): positive *semi*definite, a trough (§0.3). The function is a parabolic trough tilted along its flat direction — it decreases without bound along that direction. A solver would report failure to converge or unboundedness; the model (if this were a model) is missing a constraint (§1.3).

**A2.** The Hessian's scales differ like the squares of the variable scales, so $\kappa$ can be of order $(10^{7}/10^{-3})^2 = 10^{20}$ in the worst case — and first-order cost grows like $\kappa$ (§7.3). Fix: rescale each variable by a reference value so all are $O(1)$ (§2.3). Expected effect: iteration counts drop by orders of magnitude; often the difference between "fails" and "converges in 30 iterations". Also consider BFGS, which reduces (but does not eliminate) sensitivity to scaling.

**A3.** Convergence and a good-looking curve do not mean identified parameters (§8.3). $\text{cond}(J^\top J) = 4\times 10^9$ means some parameter combinations are essentially undetermined by this data — compute the standard errors from $\sigma^2 (J^\top J)^{-1}$; several will likely exceed the estimates themselves. Publishing those rate constants would be publishing noise. Propose: report the standard errors honestly; identify the ill-determined directions (eigenvectors of $J^\top J$ with small eigenvalues often reveal *which combinations* are undetermined); and design additional experiments that excite those directions (different temperatures, concentrations, or time scales).

**A4.** Case "inactive": $\mu = 0$, $\nabla f = 0$ gives $x = (0,0)$, which violates $x_1 + x_2 \ge 4$ — reject. Case "active": $x_1 + x_2 = 4$ with stationarity $2x_1 = \mu$, $2x_2 = \mu$ (writing $g = 4 - x_1 - x_2 \le 0$, $\nabla g = (-1,-1)$, so $2x_i - \mu = 0$). Hence $x_1 = x_2 = 2$, $\mu^\star = 4 > 0$ ✓. $x^\star = (2,2)$, $f^\star = 8$. Interpretation (§9.4): lowering the requirement from 4 to $4 - \varepsilon$ would reduce the optimal cost at rate $\mu^\star = 4$ per unit — the price of the requirement.

**A5.** $\mathcal{L} = x^2 + \mu(3 - x)$; minimizing over $x$: $x = \mu/2$, so $q(\mu) = 3\mu - \mu^2/4$. Check: $f^\star = 9$ (at $x = 3$). $q(2) = 6 - 1 = 5 \le 9$ ✓; $q(10) = 30 - 25 = 5 \le 9$ ✓. Maximize: $q'(\mu) = 3 - \mu/2 = 0 \Rightarrow \mu^\star = 6$, $q(6) = 18 - 9 = 9 = f^\star$ — tight, and $\mu^\star = 6$ matches $-df^\star/d\varepsilon$ for the perturbed constraint $x \ge 3 - \varepsilon$ ($f^\star(\varepsilon) = (3-\varepsilon)^2$, derivative $-6$). ✓

**A6.** "Success" at tolerance $10^{-6}$ means the stress limit may be *violated* by up to that tolerance (§9.7) — the design can sit marginally on the wrong side of a safety-critical line. Fix: tighten $\varepsilon_{\text{feas}}$, and — more robustly — build explicit margin into the constraint itself (constrain to, say, 98% of allowable), so any tolerance-level violation lands inside your safety factor. Never let a solver tolerance be the only thing between a design and its failure mode.

---

---
---

---
---

# PART IV — DISCRETE OPTIMIZATION

Many engineering decisions are not continuous. *How many* pumps. *Which* supplier. *Whether* to build the second line. You cannot install 2.4 chillers, and rounding 2.4 to 2 is — as this Part will demonstrate rather than assert — not a method.

Integrality looks like a small change to the standard form and is in fact a change of universe: it makes problems NP-hard in general, and yet — through one idea used relentlessly — modern solvers dispatch industrial instances with millions of variables. That one idea is the **relaxation bound**, and you already own it: it is §9.5's "any relaxation gives a bound," specialized and industrialized. This Part is the story of that idea: how to model with integers so the bound is strong (Chapter 13), how the bound drives an exact search (Chapter 14), how to strengthen it further (Chapter 15) — and, in Chapter 16, an entirely different attack (dynamic programming) for problems with sequential structure.

---

## 13. Modeling with integer variables

### 13.1 The problem class, and why it is hard

A **mixed-integer linear program (MILP)** is an LP in which some variables must be integers:

$$\min\ c^\top x \quad \text{s.t.} \quad Ax \le b, \quad x \ge 0, \quad x_j \in \mathbb{Z}\ \text{ for } j \in \mathcal{I}.$$

Why is this hard, when the LP was easy? Everything in Parts I–III relied on one physical intuition: *take a small step, measure the improvement*. Gradients, descent directions, tangency, vertices connected by edges — all of it is local motion. Integrality destroys local motion: the feasible set becomes a scatter of isolated points with nothing in between, so there is no "small step," no gradient, and convexity has nothing to act on. And the combinatorics explode — 100 binary decisions give $2^{100} \approx 10^{30}$ possibilities, more than could be enumerated by all computers that will ever exist.

**The one idea that saves it: the LP relaxation.** Delete the integrality requirement and solve the resulting LP. Two facts, both already yours:

1. Relaxing constraints can only enlarge the feasible set, so the relaxation's optimum is at least as good as the true one: **the LP value is a bound** on the MILP value (a lower bound for minimization, upper for maximization).
2. LPs solve in milliseconds (§4.3).

A cheap, rigorous bound available on demand — that is the entire engine of Chapters 14–15, and per §9.5, it is weak duality wearing different clothes. Everything now depends on how *tight* that bound is, which turns out to be decided not by the solver but **by how you write the model**. Hence this chapter.

---

#### Exercises

**13.1.1 [C]** Explain in two sentences why integrality destroys the machinery of Parts I–III. Which specific idea from each of §0.1, §3.1 and §4.1 stops applying?

**13.1.2 [H]** For a *minimization* MILP, is the LP relaxation value a lower or an upper bound on the true optimum? Prove it in one line from the definition of relaxation, and state the direction for a maximization.

**13.1.3 [P]** Take the **Exercise MILP (F)** used throughout these Part IV exercises:
$$\max\ 4x_1 + 3x_2 \quad\text{s.t.}\quad 3x_1 + 4x_2 \le 12,\quad 4x_1 + 2x_2 \le 10,\quad x_1,x_2 \ge 0 \text{ integer.}$$
Solve the LP relaxation, enumerate all feasible integer points, and report the true optimum. State the integrality gap in absolute and percentage terms.

**13.1.4 [C]** The text calls the LP relaxation "weak duality wearing different clothes." Justify that identification precisely, using §9.5's framing of upper and lower bounds.


### 13.2 The logic vocabulary

Binary variables are how you write *logic* inside an algebraic model — and a small vocabulary covers most of what industry needs. Learn these as idioms, the way you learned `for` loops:

| To say | Write |
|---|---|
| Activity has **fixed cost** $K$ plus variable cost $c$ | cost $= cx + Ky$, **with the linking constraint** $x \le U y$ |
| $x$ is either 0 **or** between $L$ and $U$ (*semi-continuous*) | $L y \le x \le U y$ |
| **At most one** of a set of options | $\sum_k y_k \le 1$ |
| **Exactly $N$** of a set | $\sum_k y_k = N$ |
| Choosing A **implies** choosing B | $y_A \le y_B$ |
| **Either** $g_1(x) \le 0$ **or** $g_2(x) \le 0$ | $g_1(x) \le M y$, $\ g_2(x) \le M(1-y)$ |
| Product of a binary and a bounded continuous, $w = y\,x$ with $0 \le x \le U$ | $w \le x$, $\ w \le U y$, $\ w \ge x - U(1-y)$, $\ w \ge 0$ |
| Count how many are on | $\sum_k y_k$, used directly in objective or constraints |

(The product row is the promised payoff from §2.2: a product of variables is nonconvex in general, but when one factor is binary it linearizes *exactly* — check the four inequalities case by case for $y=0$ and $y=1$, a two-minute exercise worth doing once.)

The **fixed-cost** row deserves special attention, because its failure mode is silent. Without the linking constraint $x \le Uy$, the optimizer simply sets $y = 0$ to dodge the fixed cost while still using $x > 0$ — enjoying the capacity without paying for it. The constraint says: *you may only use it if you have bought it.* Nearly every binary-variable bug in practice is a missing or wrong linking constraint, and the symptom is always the same: **an answer that is too good.** When a MILP delights you, audit the linking constraints first.

That constant $U$ (often written $M$ and called a **big-M**) must be large enough not to cut off any legitimate solution. The natural instinct — "make it huge, then it's safe" — is precisely wrong, and the next example quantifies how wrong.

---

#### Exercises

**13.2.1 [H]** Verify the binary-times-continuous linearization $w = yx$ with $0 \le x \le U$, $y \in \{0,1\}$: check all four inequalities $w \le x$, $w \le Uy$, $w \ge x - U(1-y)$, $w \ge 0$ case by case for $y = 0$ and $y = 1$, and confirm each case forces $w$ to the correct value.

**13.2.2 [H]** Write the constraints for each requirement, defining every variable:
(a) a compressor is either off or running between 30 and 80 kW;
(b) at most two of five candidate suppliers may be used;
(c) if we build the pipeline, we must also build the pump station;
(d) job 5 must finish before job 8 starts *or* job 8 before job 5, on a shared machine with a 40-hour horizon;
(e) exactly three of eight sensors are installed.

**13.2.3 [P]** **The missing-linking-constraint bug.** Model: fixed cost 200 if the unit runs, variable cost 3/unit, demand $\ge 40$, capacity 60. Solve it twice — once *without* the constraint $x \le 60y$ and once with — and report both objective values and the value of $y$. Explain the symptom the text warns about.

**13.2.4 [M]** A colleague's MILP returns a cost 35 % below anything achieved historically, and they are delighted. Give the audit you would run, in order, and say what the single most likely cause is.


### 13.3 Worked Example 8 — the big-M trap, quantified

A production unit has fixed cost 100 (pay it if the unit runs at all), variable cost 2 per unit, and must meet a demand of 30:

$$\min\ 100y + 2x \quad \text{s.t.} \quad x \ge 30, \quad x \le M y, \quad x \ge 0, \quad y \in \{0, 1\}.$$

The true answer is obvious: the unit must run, so $y = 1$, $x = 30$, cost $= 100 + 60 = \mathbf{160}$. The physical capacity of the unit is 50, so the *tightest valid* choice is $M = 50$; but $M = 1000$ or $M = 10^6$ are also "valid" — they cut off nothing. Are they harmless?

**Work out the LP relaxation by hand.** Relax $y \in \{0,1\}$ to $0 \le y \le 1$. The relaxation wants $y$ as small as possible (it costs 100 per unit), and the only thing forcing $y$ up is the linking constraint: $y \ge x/M = 30/M$. So the relaxation "pays" only the fraction $30/M$ of the fixed cost:

| $M$ | relaxed $y$ | LP bound $= 100\,(30/M) + 60$ | gap to 160 |
|---|---|---|---|
| **50** (true capacity) | $0.600$ | $\mathbf{120}$ | 25% |
| $1\,000$ | $0.030$ | $63$ | 61% |
| $1\,000\,000$ | $0.00003$ | $\approx 60$ | 62.5% |

**Confirm by machine, and see the collapse as a curve:**

```python
"""Worked Example 8: the LP relaxation bound as a function of big-M."""
import numpy as np
from scipy.optimize import linprog, milp, LinearConstraint, Bounds

for M in [50, 1000, 1_000_000]:
    # LP relaxation over (x, y):  min 2x + 100y  s.t.  -x <= -30,  x - My <= 0
    r = linprog([2, 100], A_ub=[[-1, 0], [1, -M]], b_ub=[-30, 0],
                bounds=[(0, None), (0, 1)], method="highs")
    print(f"M = {M:>9,}:  LP bound = {r.fun:7.3f}   relaxed y = {r.x[1]:.6f}")

# the true integer answer, for reference
ri = milp(c=[2, 100],
          constraints=[LinearConstraint([[-1, 0], [1, -50]], ub=[-30, 0])],
          integrality=[0, 1], bounds=Bounds([0, 0], [np.inf, 1]))
print(f"MILP optimum: x = {ri.x[0]:.0f}, y = {ri.x[1]:.0f}, cost = {ri.fun:.0f}")
```

```
M =        50:  LP bound = 120.000   relaxed y = 0.600000
M =     1,000:  LP bound =  63.000   relaxed y = 0.030000
M = 1,000,000:  LP bound =  60.003   relaxed y = 0.000030
MILP optimum: x = 30, y = 1, cost = 160
```

![Big-M collapse](figures/fig13_bigM.png)

*Figure 13.1 — The LP bound as a continuous function of $M$. With a lazily chosen $M = 10^6$, the relaxation values the fixed cost at three cents: the bound collapses to 60 — the pure variable cost — carrying no information about the most important cost in the model. Branch and bound (Chapter 14) prunes with these bounds; a bound this weak prunes nothing, and the search degenerates toward blind enumeration.*

The fractional $y = 0.03$ is worth staring at: the relaxation is "building 3% of a production unit" and paying 3% of its fixed cost — algebraically legal, physically meaningless, and devastating to the bound. You will see the same pathology at model scale in §13.4.

> **Rule.** Set every big-M from a **physical limit** — the actual capacity of the unit, the actual maximum flow, the length of the scheduling horizon — never a round number chosen "to be safe." Tightening one big-M is frequently the single highest-leverage change available in a slow MILP, and it costs one line.

---

#### Exercises

**13.3.1 [H]** For the model $\min\ 200y + 3x$ s.t. $x \ge 40$, $x \le My$, $y\in\{0,1\}$ (true capacity 60): derive the LP relaxation's optimal $y$ and bound as functions of $M$, then tabulate for $M = 60,\ 1000,\ 10^6$. State the true integer optimum and the relative gap in each case.

**13.3.2 [P]** Confirm 13.3.1 numerically with `linprog` and `milp`, and plot or tabulate the LP bound for $M$ from 60 to $10^5$ on a log axis. At what $M$ has half the fixed cost disappeared from the bound?

**13.3.3 [M]** For each of the following, state the physically justified big-M: (a) $x \le My$ where $x$ is the flow through a pump rated at 120 m³/h; (b) a scheduling disjunction over a 3-shift, 5-day week measured in hours; (c) $x \le My$ where $x$ is a purchase quantity limited by the supplier's annual contract of 4000 t; (d) a temperature-difference constraint where $\Delta T$ cannot exceed the 250 °C between the utility and ambient.

**13.3.4 [C]** Branch and bound is *exact* regardless of $M$, so a loose big-M never produces a wrong answer. Explain precisely what it does produce instead, and why that is still a serious problem.


### 13.4 Canonical models worth recognizing — and a real model in Pyomo

Most industrial MILPs are one of five shapes, or compositions of them. Learn to recognize the shape underneath the application vocabulary:

**Knapsack** — select projects under a single budget:
$$\max \sum_j v_j y_j \quad \text{s.t.} \quad \sum_j w_j y_j \le W, \quad y_j \in \{0,1\}.$$

**Set covering** — place the fewest sensors so every zone is monitored (with $S_j$ = zones covered by candidate site $j$):
$$\min \sum_j c_j y_j \quad \text{s.t.} \quad \sum_{j\,:\,i \in S_j} y_j \ge 1 \ \ \forall\ \text{zones } i, \quad y_j \in \{0,1\}.$$

**Capacitated facility location** — where to build, and who serves whom:
$$\min \sum_i K_i y_i + \sum_{i,j} c_{ij} x_{ij} \quad \text{s.t.} \quad \sum_i x_{ij} = d_j\ \forall j, \quad \sum_j x_{ij} \le U_i\, y_i\ \forall i, \quad x \ge 0,\ y \in \{0,1\}.$$

Note that here the capacity constraint *is* the linking constraint — and $U_i$ is a true capacity, so this model is born with its big-Ms tight.

**Semi-continuous operation (unit commitment)** — a generator or compressor is off, or running above its minimum stable output:
$$L_i\, y_i \le x_i \le U_i\, y_i, \qquad y_i \in \{0,1\}.$$

**Sequencing with disjunctions** — jobs $i$ and $j$ on one machine cannot overlap. With start times $s$, durations $p$, and $z_{ij} \in \{0,1\}$ meaning "$i$ precedes $j$":
$$s_j \ge s_i + p_i - M(1 - z_{ij}), \qquad s_i \ge s_j + p_j - M z_{ij}.$$

Exactly one of the two is enforced, depending on $z_{ij}$ — the either–or idiom from §13.2. Here the right $M$ is the scheduling horizon, not $10^9$ (§13.3).

**Facility location, end to end.** Time to build one of these for real, in the Pyomo modeling layer (which we will use for the rest of the course whenever a model has structure worth expressing by name). Two candidate warehouse sites, three customers:

| | fixed cost $K_i$ | capacity $U_i$ | ship to cust. 1 | cust. 2 | cust. 3 |
|---|---|---|---|---|---|
| **Site 1** | 400 | 70 | 4 | 6 | 9 |
| **Site 2** | 300 | 50 | 7 | 3 | 5 |

Demands: $d = (20, 15, 25)$, total 60.

```python
"""Capacitated facility location in Pyomo, solved by HiGHS."""
import pyomo.environ as pyo
from pyomo.contrib.appsi.solvers import Highs

K = {1: 400, 2: 300}
U = {1: 70,  2: 50}
d = {1: 20, 2: 15, 3: 25}
c = {(1,1): 4, (1,2): 6, (1,3): 9,
     (2,1): 7, (2,2): 3, (2,3): 5}

m = pyo.ConcreteModel()
m.I = pyo.Set(initialize=[1, 2])          # sites
m.J = pyo.Set(initialize=[1, 2, 3])       # customers
m.y = pyo.Var(m.I, within=pyo.Binary)                 # open site i?
m.x = pyo.Var(m.I, m.J, within=pyo.NonNegativeReals)  # flow i -> j

m.demand = pyo.Constraint(m.J, rule=lambda m, j:
                          sum(m.x[i, j] for i in m.I) == d[j])
m.link   = pyo.Constraint(m.I, rule=lambda m, i:
                          sum(m.x[i, j] for j in m.J) <= U[i]*m.y[i])
m.obj    = pyo.Objective(expr=sum(K[i]*m.y[i] for i in m.I)
                              + sum(c[i, j]*m.x[i, j] for i in m.I for j in m.J))

Highs().solve(m)
print("total cost:", pyo.value(m.obj))
print("open sites:", {i: int(pyo.value(m.y[i])) for i in m.I})
print("shipments :", {(i, j): pyo.value(m.x[i, j])
                      for i in m.I for j in m.J if pyo.value(m.x[i, j]) > 1e-6})
```

```
total cost: 795.0
open sites: {1: 1, 2: 0}
shipments : {(1, 1): 20.0, (1, 2): 15.0, (1, 3): 25.0}
```

Read the answer through §1.4 eyes: the model chose **not** to open site 2 even though it has cheaper shipping to customers 2 and 3 — because the shipping saving (145) does not repay the fixed cost (300). Verify that arithmetic by hand; it is the whole discrete trade-off in one line.

And now the payoff of §13.3 at model scale — solve the *relaxation* of the same model (change `pyo.Binary` to `pyo.UnitInterval` and re-run):

```python
"""Same model, integrality relaxed: watch the fractional warehouse appear."""
import pyomo.environ as pyo
from pyomo.contrib.appsi.solvers import Highs

K = {1: 400, 2: 300}; U = {1: 70, 2: 50}
d = {1: 20, 2: 15, 3: 25}
c = {(1,1): 4, (1,2): 6, (1,3): 9, (2,1): 7, (2,2): 3, (2,3): 5}

m = pyo.ConcreteModel()
m.I = pyo.Set(initialize=[1, 2]); m.J = pyo.Set(initialize=[1, 2, 3])
m.y = pyo.Var(m.I, within=pyo.UnitInterval)           # <-- relaxed
m.x = pyo.Var(m.I, m.J, within=pyo.NonNegativeReals)
m.demand = pyo.Constraint(m.J, rule=lambda m, j: sum(m.x[i, j] for i in m.I) == d[j])
m.link   = pyo.Constraint(m.I, rule=lambda m, i: sum(m.x[i, j] for j in m.J) <= U[i]*m.y[i])
m.obj    = pyo.Objective(expr=sum(K[i]*m.y[i] for i in m.I)
                              + sum(c[i, j]*m.x[i, j] for i in m.I for j in m.J))
Highs().solve(m)
print(f"LP bound: {pyo.value(m.obj):.1f}   y = "
      f"{{1: {pyo.value(m.y[1]):.4f}, 2: {pyo.value(m.y[2]):.4f}}}")
```

```
LP bound: 604.3   y = {1: 0.2857, 2: 0.8000}
```

The relaxation builds **29% of warehouse 1 and 80% of warehouse 2**, pays fractional fixed costs, and reports a bound of 604 against a truth of 795 — a 24% integrality gap, from a model whose big-Ms are already as tight as physics allows. Fractional facilities are the *normal* face of an LP relaxation; Chapter 14 is the machine that grinds this gap to zero, and Chapter 15 is how formulations shrink it before the machine starts.

---

#### Exercises

**13.4.1 [C]** Identify the canonical shape (knapsack, set covering, capacitated facility location, semi-continuous/unit commitment, sequencing disjunction) hiding under each description:
(a) choose which of 30 maintenance jobs to do in a 12-week shutdown window;
(b) decide which of 8 gas turbines run each hour and at what load, each with a minimum stable output;
(c) place inspection cameras so every weld on a frame is visible by at least one;
(d) order 6 batches through a single autoclave without overlap;
(e) decide which of 4 regional depots to open and which serves each of 20 stores.

**13.4.2 [H]** Three candidate warehouse sites, four customers. Fixed costs $K = (350, 250, 300)$; capacities $U = (60, 45, 50)$; demands $d = (20, 15, 25, 10)$; unit shipping costs
$$C = \begin{pmatrix}4&6&9&5\\7&3&5&8\\6&5&4&3\end{pmatrix}.$$
Write the complete MILP. Then evaluate by hand the cost of the plan "open sites 2 and 3 only," assigning each customer to its cheaper open site subject to capacity.

**13.4.3 [P]** Solve 13.4.2 both as a MILP and as its LP relaxation, and report: the optimal open set and cost, the relaxation bound, the fractional $y$ values, and the integrality gap. (Pyomo is a convenient modeling layer for this, as in the text; `scipy.optimize.milp` or CVXPY with `boolean=True` solves the same model with the same HiGHS engine if Pyomo is unavailable.)

**13.4.4 [M]** In the text's two-site example the model declines to open the site with cheaper shipping. Reproduce that style of reasoning for your 13.4.3 answer: name the trade-off in one sentence, with the two numbers being compared.


---

## 14. Branch and bound

Branch and bound is the exact algorithm behind every industrial MILP solver. It is also — pleasingly — simple enough to trace completely by hand on a small problem, and simple enough to *implement* in forty lines. We do both.

### 14.1 Worked Example 9 — a complete tree

$$\max\ z = 5x_1 + 4x_2 \quad \text{s.t.} \quad 6x_1 + 4x_2 \le 24, \quad x_1 + 2x_2 \le 6, \quad x_1, x_2 \ge 0 \text{ integer.}$$

![Feasible integer points](figures/fig14_branch.png)

*Figure 14.1 — The LP relaxation (shaded), the 13 feasible integer points (dots), the fractional LP optimum $(3, 1.5)$, the true integer optimum $(4, 0)$ — and the rounded point $(3,1)$, which is feasible, tempting, and wrong.*

**Step 0 — the relaxation.** Drop integrality. The two constraint lines intersect where $6x_1 + 4x_2 = 24$ and $x_1 + 2x_2 = 6$; solving (multiply the second by 2 and subtract): $4x_1 = 12$... check it yourself — $x = (3,\ 1.5)$, $z = 21$. By the bounding fact of §13.1: **no integer solution can exceed 21.** That is already knowledge.

**The tempting mistake, dispatched first.** Round $(3, 1.5)$ down to $(3, 1)$: feasible, $z = 19$. Round up to $(3, 2)$: violates the first constraint ($6\cdot3 + 4\cdot2 = 26 > 24$). So "rounding" offers 19 — but the true optimum is **20, at $(4, 0)$**, a point that no rounding of $(3, 1.5)$ can reach in any direction. On this toy, rounding loses 5%; in higher dimensions, rounding a relaxation is frequently *not even feasible* (each rounded coordinate can break a different constraint). Rounding is not a method.

**Branch.** $x_2 = 1.5$ is fractional, and no integer solution has $1 < x_2 < 2$. So split the problem into two children — $x_2 \le 1$ and $x_2 \ge 2$ — whose union keeps every integer point. Solve each child's LP relaxation; repeat on any child whose relaxation is still fractional; and **prune** any child that cannot possibly beat the best integer solution found so far (the *incumbent*).

Every node, verified by hand:

- **Node A** ($x_2 \le 1$): $z$ increases in both variables, so push $x_2$ to its new ceiling, $x_2 = 1$; then $6x_1 \le 20 \Rightarrow x_1 \le 10/3$. LP optimum $x = (3.33, 1)$, $z = 20.67$. Still fractional → branch on $x_1$.
- **Node A1** ($x_2 \le 1,\ x_1 \le 3$): $x = (3, 1)$, both original constraints slack, $z = 19$. **Integer** — record as incumbent.
- **Node A2** ($x_2 \le 1,\ x_1 \ge 4$): combining $x_1 \ge 4$ with $6x_1 + 4x_2 \le 24$ forces $x_2 \le 0$, so $x = (4, 0)$, $z = 20$. **Integer** — new incumbent.
- **Node C** ($x_2 \ge 2$): LP optimum $x = (2, 2)$, $z = 18$. The best *conceivable* value anywhere in this subtree is 18; the incumbent is 20. **Prune the entire subtree unexplored.** This pruning — discarding regions wholesale on the strength of a bound — is why branch and bound is tractable at all.

![Branch-and-bound tree](figures/fig14_tree.png)

*Figure 14.2 — The complete tree. Five LP solves, one pruned subtree, and a* proof *of optimality: when no open nodes remain, the incumbent 20 is certified, because every discarded region carried a certificate (its bound) that it contained nothing better.*

**Now the same tree by machine** — each node is just the root LP plus branching constraints, so five calls to `linprog` reproduce every number above:

```python
"""Worked Example 9: every node of the tree, verified with HiGHS."""
from scipy.optimize import linprog, milp, LinearConstraint, Bounds
import numpy as np

c = [-5, -4]                          # maximize 5x1 + 4x2
A = [[6, 4], [1, 2]]
b = [24, 6]

def solve_node(name, extra_A=(), extra_b=()):
    r = linprog(c, A_ub=A + [list(row) for row in extra_A],
                b_ub=b + list(extra_b), bounds=[(0, None)]*2, method="highs")
    print(f"{name:24s} x = ({r.x[0]:.4f}, {r.x[1]:.4f})   z = {-r.fun:.4f}")

solve_node("ROOT")
solve_node("A : x2 <= 1", [[0, 1]],  [1])
solve_node("C : x2 >= 2", [[0, -1]], [-2])
solve_node("A1: x2 <= 1, x1 <= 3", [[0, 1], [1, 0]],  [1, 3])
solve_node("A2: x2 <= 1, x1 >= 4", [[0, 1], [-1, 0]], [1, -4])

# and the whole thing in one call: scipy's MILP interface (HiGHS branch & bound)
r = milp(c=c, constraints=[LinearConstraint(A, ub=b)],
         integrality=[1, 1], bounds=Bounds([0, 0], [np.inf, np.inf]))
print(f"\nmilp(): x* = {np.round(r.x).astype(int)},  z* = {-r.fun:.0f}")
```

```
ROOT                     x = (3.0000, 1.5000)   z = 21.0000
A : x2 <= 1              x = (3.3333, 1.0000)   z = 20.6667
C : x2 >= 2              x = (2.0000, 2.0000)   z = 18.0000
A1: x2 <= 1, x1 <= 3     x = (3.0000, 1.0000)   z = 19.0000
A2: x2 <= 1, x1 >= 4     x = (4.0000, -0.0000)   z = 20.0000

milp(): x* = [4 0],  z* = 20
```

---

#### Exercises

**14.1.1 [H]** Build the complete branch-and-bound tree by hand for the Exercise MILP (F) of 13.1.3, using depth-first search and branching on the *first* fractional variable. Show every node: its added constraints, its LP solution and bound, and the action taken (branch / integer incumbent / prune, with the reason). State the final answer and its proof.

**14.1.2 [P]** Verify every node of your tree with `linprog`, then confirm the answer in one call with `scipy.optimize.milp`.

**14.1.3 [H]** **Rounding is not a method.** Round the root LP solution $(1.6, 1.8)$ of (F) in all four coordinate-wise directions. For each, state whether the result is feasible and its objective. Compare with $z^\star = 11$ and explain why rounding fails here.

**14.1.4 [C]** Explain what is being *proved* when the search ends with no open nodes, and why the pruned subtrees do not need to be examined. Which earlier section is this the same argument as?


### 14.2 Branch and bound in forty lines

The three ingredients, in general form:

1. **Branching** splits a node's feasible set into subproblems whose union preserves every integer solution (here: $x_j \le \lfloor v \rfloor$ versus $x_j \ge \lceil v \rceil$ on a fractional coordinate $v$).
2. **Bounding** solves each subproblem's LP relaxation for an optimistic estimate.
3. **Pruning** discards a node if its relaxation is infeasible, or already integral (record it, done), or bounded below the incumbent.

That is genuinely all — so let us implement it, and watch it print its own reasoning:

```python
"""A didactic branch-and-bound for pure-integer maximization MILPs."""
import numpy as np
from scipy.optimize import linprog

def branch_and_bound(c, A, b, tol=1e-6):
    """max c@x s.t. A x <= b, x >= 0 integer. Returns (x*, z*)."""
    incumbent, z_inc = None, -np.inf
    stack = [([], [])]                                  # extra rows per node
    node_id = 0
    while stack:
        eA, eb = stack.pop()
        r = linprog([-ci for ci in c], A_ub=A + eA, b_ub=b + eb,
                    bounds=[(0, None)]*len(c), method="highs")
        node_id += 1
        if r.status != 0:
            print(f"node {node_id}: infeasible -> prune");  continue
        z = -r.fun
        if z <= z_inc + tol:
            print(f"node {node_id}: bound {z:.3f} <= incumbent {z_inc:.3f} -> prune")
            continue
        frac = [j for j, v in enumerate(r.x) if abs(v - round(v)) > tol]
        if not frac:
            incumbent, z_inc = np.round(r.x), z
            print(f"node {node_id}: INTEGER {incumbent} z={z:.3f} -> new incumbent")
            continue
        j, v = frac[0], r.x[frac[0]]
        print(f"node {node_id}: z={z:.3f}, x[{j}]={v:.3f} fractional -> branch")
        row = [1.0 if k == j else 0.0 for k in range(len(c))]
        stack.append((eA + [row],               eb + [np.floor(v)]))   # x_j <= floor
        stack.append((eA + [[-ri for ri in row]], eb + [-np.ceil(v)])) # x_j >= ceil
    return incumbent, z_inc

x, z = branch_and_bound([5, 4], [[6, 4], [1, 2]], [24, 6])
print(f"\noptimum: x* = {x}, z* = {z:.0f}")
```

```
node 1: z=21.000, x[1]=1.500 fractional -> branch
node 2: INTEGER [2. 2.] z=18.000 -> new incumbent
node 3: z=20.667, x[0]=3.333 fractional -> branch
node 4: INTEGER [ 4. -0.] z=20.000 -> new incumbent
node 5: bound 19.000 <= incumbent 20.000 -> prune

optimum: x* = [ 4. -0.], z* = 20
```

Compare this printout with the hand tree of §14.1 — **same five nodes, same answer, same proof, different story at two nodes**, and both differences are instructive. First, the LIFO stack explores the $x_2 \ge 2$ branch *first*, and its relaxation $(2,2)$ happens to be integral — so instead of being "pruned by bound" it is *recorded* as an early incumbent of 18. (An integral relaxation is the third kind of pruning: nothing below that node can beat the node's own LP optimum, which we just achieved.) Second, with the incumbent already at 20 by node 4, the $(3,1)$ node — a legitimate integer point in the hand tree — is now pruned *by bound* without even checking its integrality: its relaxation value 19 cannot beat 20. Exploration order changes which pruning rule fires where; the certificate at the end is identical. Run it, then feed it a small MILP of your own: watching your own solver prune is the moment this algorithm stops being abstract.

Production solvers add profoundly better branching-variable selection, presolve, cutting planes (Chapter 15), heuristics for early incumbents, and parallelism — but the skeleton is these forty lines.

---

#### Exercises

**14.2.1 [C]** State the three ingredients of branch and bound, and the three distinct circumstances under which a node is pruned. For each pruning rule, say what it costs you to check.

**14.2.2 [P]** Run the text's `branch_and_bound` on the Exercise MILP (F). Record the node log and compare it with your hand tree from 14.1.1: which nodes differ, and which pruning rule fired where?

**14.2.3 [P]** Modify the implementation to explore **best-bound-first** (a priority queue on the node bound) instead of LIFO depth-first, and compare node counts on (F) and on the text's Example 9. Then state the practical trade-off between the two orders.

**14.2.4 [C]** The text's run finds the incumbent 18 at an *integral relaxation*, calling this "the third kind of pruning." Explain why an integral relaxation licenses stopping at that node, and why this is not the same as "the node is optimal for the whole problem."


### 14.3 The MIP gap: a certificate you can stop on

At any moment during the search, the solver knows two numbers:

- the **incumbent** — the best *integer-feasible* solution found so far (20, once node A2 is processed): an achieved value, hence a bound on one side;
- the **best bound** — the best relaxation value among still-open nodes (21 at the root): a limit on what could possibly still be found.

The difference is the **MIP gap**, and it bounds everything you could still gain by searching further. This is §9.5 operating in real time: a feasible point bounds the optimum from one side, relaxations bound it from the other, and **optimality is proved the moment they meet** — which is exactly what "no open nodes remain" meant in Figure 14.2.

> **In industrial practice, stopping at a small nonzero gap is normal and correct.** The last fraction of a percent often costs more compute than everything before it — and is usually far smaller than the uncertainty in your input data. A solution *proved within 0.5% of optimal*, delivered in ten minutes, is worth more than a proven optimum delivered next week. Every solver takes a gap tolerance (`mip_rel_gap` in HiGHS); set it deliberately, and report it with your answer: "cost 1.42 M, within 0.3% of optimal" is a complete, honest engineering statement.

---

#### Exercises

**14.3.1 [H]** Define incumbent, best bound and MIP gap. Compute the gap after each stage of your 14.1.1 tree (after the root, after N1a, after N2), using the relative definition $|z_{\text{bound}} - z_{\text{inc}}|/|z_{\text{inc}}|$.

**14.3.2 [C]** True or false, and explain precisely: "A solver that stops at a 1 % gap has found a solution within 1 % of optimal, but cannot prove it."

**14.3.3 [P]** Solve a moderately sized random MILP (say 25 binary variables, 12 constraints) with a gap tolerance of $10^{-4}$ and then with $0.02$, and compare objective values and solve times. Report both results in the honest form the text recommends.

**14.3.4 [M]** Your model's inputs — demand forecasts and cost estimates — are known to roughly $\pm5\%$. Argue for a sensible gap tolerance, and write the one-sentence result statement you would put in a report.


### 14.4 Practical checklist for integer models

- **Tighten every big-M** to a physically justified value (§13.3).
- **Break symmetry** when units are interchangeable: for three identical machines, add $y_1 \ge y_2 \ge y_3$. Otherwise the solver wastefully re-explores permutations of the same solution.
- **Supply a starting solution** if you have one (most solvers accept a "warm start"). A decent incumbent enables pruning from the very first node.
- **Always set a gap tolerance and a time limit.** An unbounded run time is not a plan.
- **Bound every variable**, even generously: unbounded variables weaken the relaxation.
- **Relax integrality where fractional answers are physically tolerable.** A flow rate can be fractional; a build/don't-build decision cannot. Fewer integer variables is a superlinear speedup.
- **Check whether your model is secretly a network** (§6). If total unimodularity holds, you need none of this chapter — the LP already returns integers.

---

#### Exercises

**14.4.1 [C]** Reproduce the seven-item checklist from memory, and for each item name the mechanism by which it helps (bound tightness, search-space size, early pruning, numerical stability, or method choice).

**14.4.2 [H]** **Symmetry, counted.** Five jobs of sizes $(6,5,4,3,2)$ must be assigned to three *identical* machines of capacity 10, minimizing the number of machines used. Show that 2 machines suffice, then count how many distinct *assignments* of jobs to labelled machines achieve the optimum, and how many genuinely different *partitions* of the jobs those represent. What symmetry-breaking constraints would you add?

**14.4.3 [P]** Verify your count in 14.4.2 by enumeration, and solve the MILP with and without the symmetry-breaking constraints $y_1 \ge y_2 \ge y_3$. Comment honestly on whether the node count changes at this size, and explain when it would.

**14.4.4 [M]** A model with 4 000 binaries times out at a 40 % gap. Walk through the checklist as a diagnostic sequence: what would you inspect first, second and third, and what would you expect each to buy?


---

## 15. Cutting planes and formulation strength

Our root relaxation said 21 while the truth was 20 — an **integrality gap** of one unit, which branch and bound had to close by searching. A **cutting plane** closes gaps *without* searching: it is a new inequality that is (a) violated by fractional points of the relaxation, and (b) satisfied by every integer-feasible point. Add it, and the relaxation tightens while the true problem is untouched.

### 15.1 Worked Example 10 — one cut solves the entire problem

Same problem as §14.1. Take a nonnegative combination of the two constraints with weights $\tfrac18$ and $\tfrac14$:

$$\tfrac{1}{8}\big(6x_1 + 4x_2 \le 24\big) \;+\; \tfrac{1}{4}\big(x_1 + 2x_2 \le 6\big)
\;\Longrightarrow\;
\Big(\tfrac{6}{8} + \tfrac{1}{4}\Big)x_1 + \Big(\tfrac{4}{8} + \tfrac{2}{4}\Big)x_2 \le 3 + 1.5,$$

i.e. $x_1 + x_2 \le 4.5$ — valid for every feasible point, integer or not. **Now use integrality:** for integer $x_1, x_2$, the left side is a whole number, and a whole number $\le 4.5$ is a whole number $\le 4$:

$$\boxed{\,x_1 + x_2 \le \lfloor 4.5 \rfloor = 4.\,}$$

This is a **Chvátal–Gomory cut**: combine constraints with nonnegative weights, then round the right-hand side down whenever the left side is guaranteed integral. The rounding step is where integrality information — invisible to the LP — enters the geometry.

**Check validity by enumeration** (the integer points from Figure 14.1): the largest coordinate sum among all 13 feasible integer points is 4, attained at $(4,0)$, $(3,1)$, $(2,2)$. **No integer point is removed.** ✓ But the fractional optimum $(3, 1.5)$ has coordinate sum $4.5 > 4$: **cut off.** ✓

**Re-solve the relaxation with the cut added:**

```python
"""Worked Example 10: one Chvatal-Gomory cut."""
from scipy.optimize import linprog

c = [-5, -4]
A = [[6, 4], [1, 2], [1, 1]]          # third row: the cut  x1 + x2 <= 4
b = [24, 6, 4]
r = linprog(c, A_ub=A, b_ub=b, bounds=[(0, None)]*2, method="highs")
print(f"LP with cut:  x = ({r.x[0]:.1f}, {r.x[1]:.1f}),  z = {-r.fun:.1f}")
```

```
LP with cut:  x = (4.0, -0.0),  z = 20.0
```

**One cut, and the LP relaxation returns the exact integer optimum** — no branching, no tree, no incumbent. Compare §14.1's four-node tree solving the identical problem.

![Before and after the cut](figures/fig15_cut.png)

*Figure 15.1 — Left: the original relaxation, whose optimal vertex $(3, 1.5)$ is fractional. Right: the cut slices off exactly the fractional corner. Every vertex of the new polygon — $(0,0), (4,0), (2,2), (0,3)$ — is an integer point, so the new relaxation* is *the convex hull of the feasible integer points (the* integer hull*), and by the fundamental theorem of LP (§4.1), an LP over the integer hull solves the integer problem outright. (A pleasant byproduct: the original constraint $6x_1 + 4x_2 \le 24$ is now redundant — check: $6x_1 + 4x_2 = 4(x_1 + x_2) + 2x_1 \le 16 + 8 = 24$ using the cut and $x_1 \le 4$.)*

---

#### Exercises

**15.1.1 [C]** Define a cutting plane by its two required properties, and explain which of the two is where *integrality* information enters.

**15.1.2 [H]** Derive a Chvátal–Gomory cut for the Exercise MILP (F) using the weights $u = (\tfrac15,\ \tfrac1{10})$ on the two constraints. Show the weighted combination, the floor operations on both the coefficients and the right-hand side, and state the resulting inequality.

**15.1.3 [H]** Verify your cut's validity by enumerating all nine feasible integer points of (F), and confirm it cuts off the LP optimum $(1.6,\ 1.8)$.

**15.1.4 [P]** Re-solve the LP relaxation of (F) with the cut appended. Report the new solution and value, and compare the work with the branch-and-bound tree of 14.1.1.

**15.1.5 [H]** Give the general CG recipe: for weights $u \ge 0$ applied to $Ax \le b$ with $x \ge 0$ integer, write the cut, and explain why the coefficient floors are valid (not just the right-hand-side floor).


### 15.2 Formulation strength: the practical moral

For any set of integer points there exists an **ideal formulation** — one whose LP relaxation equals their convex hull — and for it, plain LP solves the integer problem, as we just witnessed. Finding the ideal formulation is generally intractable (if it were easy, NP-hardness would evaporate; the hull can need exponentially many inequalities). But the principle governs everyday practice:

> **Two algebraically equivalent MILP formulations can differ by orders of magnitude in solve time.** The one whose relaxation sits closer to the integer hull wins, because every node of the tree prunes better. This is why tightening a big-M (§13.3) matters, why reformulating beats waiting, and why "the solver is slow" is usually a statement about the model.

You will rarely derive cuts by hand. Modern solvers generate many families automatically — Gomory, cover, clique, flow-cover, mixed-integer-rounding — and this automation, together with better branching and presolve, accounts for much of the astonishing (multiple orders of magnitude) speedup of MILP solvers over recent decades. **Your job is not to invent cuts; it is to write the model tightly enough that the solver's cuts have something to work with.** The division of labor: you supply tight big-Ms, symmetry breaking, and good variable bounds; the solver supplies the polyhedral combinatorics.

---

#### Exercises

**15.2.1 [C]** Define the *ideal formulation*. Why does its existence not make integer programming easy, and what does it nevertheless tell you about everyday modelling?

**15.2.2 [H]** Show that after adding the cut $x_1+x_2\le3$ to (F), the original constraint $3x_1+4x_2 \le 12$ is redundant given $x_2 \le 3$. (Mirror the text's byproduct argument for Example 10.)

**15.2.3 [M]** "The solver is slow." Rewrite this complaint as three specific, checkable statements about the *model*, in the order you would investigate them.

**15.2.4 [C]** The text says your job is not to invent cuts but to write the model tightly. List what you supply and what the solver supplies, and explain why that division of labour makes sense.


---

## 16. Dynamic programming

Branch and bound attacks discrete problems by *splitting*. Dynamic programming (DP) attacks a different class by *reusing* — and it deserves its own chapter because it solves problems the other methods cannot touch, and because it is the conceptual root of optimal control and reinforcement learning.

### 16.1 The principle of optimality

> **Bellman's principle.** Any tail of an optimal path is itself optimal for the subproblem it starts from.

If the cheapest route from A to Z passes through M, then its portion from M to Z must be the cheapest route from M to Z — otherwise you could splice in a cheaper M-to-Z route and improve the whole, contradiction. Obvious once stated; enormously powerful, because it licenses solving the problem *backwards* by building a **value function** $V(n)$ = "cost of the best path from $n$ to the end":

$$V(n) = \min_{m \,\in\, \text{successors}(n)} \Big[\, c(n, m) + V(m) \,\Big], \qquad V(\text{terminal}) = 0.$$

This is the **Bellman equation**, and notice precisely what it does: it replaces a search over *whole paths* (exponentially many) with a computation over *states* (few), because every path through $n$ shares the same optimal tail from $n$. Optimal tails are computed once and reused.

---

#### Exercises

**16.1.1 [C]** State Bellman's principle and give the one-paragraph contradiction argument for it. Then explain precisely what computational saving the principle licenses.

**16.1.2 [H]** Write the Bellman equation for a minimum-cost path problem, defining $V$, the terminal condition, and the recursion. Explain why the recursion is naturally solved *backwards*.

**16.1.3 [C]** The text says DP "replaces a search over whole paths with a computation over states." Quantify this for $k$ stages of width $w$: how many paths, how many states, how many arc evaluations? Evaluate at $k=20$, $w=10$.

**16.1.4 [M]** Give an example of a problem where Bellman's principle **fails** because the objective is not additively separable over stages, and say what you would do about it.


### 16.2 Worked Example 11 — shortest path

A route runs from $S$ to $T$ through two intermediate stages, with arc costs:

$$S{\to}A = 2,\quad S{\to}B = 4; \qquad A{\to}C = 3,\quad A{\to}D = 7,\quad B{\to}C = 1,\quad B{\to}D = 2; \qquad C{\to}T = 5,\quad D{\to}T = 2.$$

![Network](figures/fig16_network.png)

*Figure 16.1 — The network, with the value $V$ of each node written beneath it and the optimal path in red. Compute the figure's $V$ values yourself with the backward pass below before reading them off.*

**Work backwards from the destination.** $V(T) = 0$, then each earlier layer by the Bellman equation:

| Stage | State | Bellman computation | $V$ | Best move |
|---|---|---|---|---|
| 3 | $T$ | terminal | 0 | — |
| 2 | $C$ | $5 + V(T) = 5$ | **5** | $C \to T$ |
| 2 | $D$ | $2 + V(T) = 2$ | **2** | $D \to T$ |
| 1 | $A$ | $\min\{3 + V(C),\ 7 + V(D)\} = \min\{8, 9\}$ | **8** | $A \to C$ |
| 1 | $B$ | $\min\{1 + V(C),\ 2 + V(D)\} = \min\{6, 4\}$ | **4** | $B \to D$ |
| 0 | $S$ | $\min\{2 + V(A),\ 4 + V(B)\} = \min\{10, 8\}$ | **8** | $S \to B$ |

Trace the "best move" column forward from $S$: $S \to B \to D \to T$, total cost **8**.

```python
"""Worked Example 11: backward DP, then brute force to confirm."""
succ = {"S": [("A", 2), ("B", 4)],
        "A": [("C", 3), ("D", 7)],
        "B": [("C", 1), ("D", 2)],
        "C": [("T", 5)],
        "D": [("T", 2)],
        "T": []}

V, best = {"T": 0}, {}
for node in ["C", "D", "A", "B", "S"]:                     # backward order
    V[node], best[node] = min((cost + V[m], m) for m, cost in succ[node])
print("value function:", V)

path, n = ["S"], "S"
while n != "T":
    n = best[n]; path.append(n)
print("optimal path:", " -> ".join(path), "  cost:", V["S"])

def all_paths(n):                                          # brute force check
    if n == "T": return [(["T"], 0)]
    return [([n] + p, c + c2) for m, c in succ[n] for p, c2 in all_paths(m)]
for p, cost in all_paths("S"):
    print("  ", " -> ".join(p), cost)
```

```
value function: {'T': 0, 'C': 5, 'D': 2, 'A': 8, 'B': 4, 'S': 8}
optimal path: S -> B -> D -> T   cost: 8
   S -> A -> C -> T 10
   S -> A -> D -> T 11
   S -> B -> C -> T 10
   S -> B -> D -> T 8
```

**Two subtleties worth studying in that table**, because they carry the whole logic of DP:

- $A$'s own best move goes to $C$ — yet the overall optimum passes through $D$. Optimal *tails* are not assembled greedily from the front; the value function assembles them from the back, where "the rest of the journey" is already fully priced.
- $B$ is preferred from $S$ despite the more expensive first arc ($4 > 2$), because $V(B) = 4 < V(A) = 8$: the value function makes the first-arc comparison *fair* by attaching the true cost of everything after. Greedy forward choice would take $S \to A$ and lose. (Compare the greedy trap of §6.2 — same disease, and DP is one cure.)

**Be honest about the scaling here.** With 2 interior stages of width 2, there are only 4 paths — DP saves nothing on this toy; the brute-force check even *is* the enumeration. The saving appears with depth: for $k$ stages of width $w$ there are $w^k$ paths but only $k \cdot w$ states and about $k \cdot w^2$ arc evaluations. At $k = 20$, $w = 10$: $10^{20}$ paths versus roughly $2{,}000$ additions and comparisons.

![Curse and blessing](figures/fig16_curse.png)

*Figure 16.2 — Enumeration ($w^k$, straight line on the log scale) versus DP work ($k\,w^2$) as the number of stages grows. This is the entire economic case for DP, in one picture — and the fine print is §16.3: the state count itself can explode.*

---

#### Exercises

**16.2.1 [H]** Compute the value function and optimal path by backward DP for this network ($S$ to $T$ through three intermediate layers):
$$S{\to}A=4,\ S{\to}B=2;\quad A{\to}C=1,\ A{\to}D=5,\ B{\to}C=6,\ B{\to}D=2;$$
$$C{\to}E=1,\ C{\to}F=4,\ D{\to}E=5,\ D{\to}F=2;\quad E{\to}T=1,\ F{\to}T=3.$$
Give a table with $V$ and the best move for every node.

**16.2.2 [H]** Apply the **greedy forward** rule (always take the cheapest available arc) to the same network. What path and cost does it give, and by how much does it lose? Identify the exact decision at which greedy goes wrong and explain what information it lacked.

**16.2.3 [P]** Implement the backward pass, recover the path, and verify against brute-force enumeration of all eight paths. Confirm the DP answer is the minimum.

**16.2.4 [C]** In the text's example, node $A$'s own best move goes to $C$ while the overall optimum passes through $D$. Explain how both can be true, and what this says about assembling optimal solutions from local choices.


### 16.3 When DP applies — and when it fails

Three conditions must hold, and checking them *is* the modeling act:

1. **Stages.** The decision decomposes into a sequence of steps (time periods, positions along a route, characters in a sequence).
2. **State.** There exists a summary of the past that captures *everything the future needs to know* — for the shortest path, "which node am I at" suffices; for inventory, "how much stock is on hand." Identifying the right state is the hard part and the whole art of DP: too little state and the recursion is wrong; too much and it is unaffordable.
3. **Additive separability.** The objective accumulates over stages (a sum; also products or maxima work) so that "cost so far + cost to go" is meaningful.

And the fatal limitation:

> **The curse of dimensionality.** DP's cost is proportional to the number of *states*, which grows exponentially in the dimension of the state vector. A five-dimensional continuous state discretized to 100 levels per dimension gives $10^{10}$ states — already impossible. DP is superb for low-dimensional states and helpless for high-dimensional ones. (Approximating the value function for high-dimensional states — rather than tabulating it — is precisely the project of reinforcement learning.)

A related honesty point, tying back to §13.1's NP-hardness. The classic DP for the 0–1 knapsack fills a table of size $n \times W$ (items × capacity) in $O(nW)$ time:

```python
"""Knapsack in O(nW): the classic DP table (values 10,10,11,11; weights 6,6,5,5; W=10)."""
values, weights, W = [10, 10, 11, 11], [6, 6, 5, 5], 10
dp = [0] * (W + 1)                       # dp[c] = best value with capacity c
for v, w in zip(values, weights):
    for c in range(W, w - 1, -1):        # backward, so each item used once
        dp[c] = max(dp[c], dp[c - w] + v)
print("best value:", dp[W])              # items 3 and 4: 11 + 11
```

```
best value: 22
```

$O(nW)$ looks polynomial — but it is **pseudo-polynomial**: polynomial in the *numeric value* of $W$, not in the number of bits needed to write $W$ down. Measure the same weights in grams instead of kilograms and the table grows a thousandfold. This does not contradict knapsack's NP-hardness; it refines it — knapsack is hard *when the numbers are large*, and easy when they are small. (Hold onto this little problem and its solution, 22 at items $\{3,4\}$: it returns in Part V as the arena where local search gets badly stuck.)

---

#### Exercises

**16.3.1 [C]** State the three conditions for DP and explain why identifying the state is "the whole art." Give one example of a state that is too small (recursion wrong) and one that is too large (unaffordable).

**16.3.2 [H]** Solve by hand the 0–1 knapsack with values $(7,8,9,10)$, weights $(3,4,5,6)$ and capacity $W = 10$: fill the DP table and report the optimal value and the items chosen. Verify by enumerating all 16 subsets.

**16.3.3 [P]** Implement the $O(nW)$ knapsack DP and demonstrate **pseudo-polynomiality**: solve the same instance with weights and capacity measured in units, tenths and hundredths (i.e. scale by 1, 10, 100), reporting the table size each time. Explain why this does not contradict NP-hardness.

**16.3.4 [M]** You must schedule a battery over 24 hourly periods; the energy level is discretized into 200 levels and 3 actions are available per hour. Compare enumeration with DP, and state the condition that makes DP valid. Then say what happens to the state if a battery-warranty rule depends on cumulative cycling.


### 16.4 Where you will meet DP

Shortest paths (Dijkstra and Bellman–Ford are DP with particular orderings); inventory and lot-sizing over a planning horizon; equipment replacement; reservoir and battery scheduling over time; discrete-time optimal control — and its continuous limit, the Hamilton–Jacobi–Bellman equation; the Viterbi algorithm in communications; sequence alignment in bioinformatics; and, since the value function is exactly a "cost-to-go," the theoretical backbone of reinforcement learning. When a problem has a *time axis* and a *compact state*, try DP before anything in Chapters 13–15: where it applies, nothing beats it.

---

#### Exercises

**16.4.1 [C]** List six settings where DP appears, and for each name the stage variable and the state.

**16.4.2 [H]** **Lot-sizing by DP.** Demands over four periods are $d = (3,2,4,2)$; each production run costs a setup $K = 5$ plus \$2 per unit; holding costs \$1 per unit per period carried. Production is uncapacitated and must meet demand on time. Use the Wagner–Whitin recursion $F(t) = \min_{j \ge t}\big[K + 2\!\sum_{k=t}^{j}\!d_k + \text{holding} + F(j{+}1)\big]$ to find the optimal production plan and cost.

**16.4.3 [P]** Implement 16.4.2 and verify by brute force over all $2^{4}$ choices of production periods.

**16.4.4 [M]** Give the decision rule for when to try DP before anything in Chapters 13–15, and one case where a problem *looks* like a DP but is better handled by MILP.


---

## Checkpoint — Part IV

You should now be able to:

- write the MILP standard form, explain in one sentence why integrality breaks Part III's machinery, and state what the LP relaxation provides and why (via §9.5);
- use the logic vocabulary — fixed costs with linking constraints, semi-continuous ranges, implications, either–or, binary-times-continuous products — and audit a "too good" answer for missing linking constraints;
- explain and *quantify* the big-M trap: compute the relaxed $y = 30/M$ bound collapse by hand, and state the rule for choosing $M$;
- recognize the five canonical MILP shapes under application vocabulary, and build one in Pyomo with HiGHS;
- run branch and bound by hand on a 2-variable problem — branch, bound, prune, incumbent — and explain why rounding fails;
- define the MIP gap, connect it to the bounds-meeting certificate, and defend stopping at a nonzero gap;
- derive a Chvátal–Gomory cut, verify its validity by enumeration, and explain what "ideal formulation" means and why formulation strength dominates solve time;
- state Bellman's principle, build a value function backwards, recover the policy forwards, and articulate both the exponential-to-polynomial saving and the curse of dimensionality;
- explain "pseudo-polynomial" using the knapsack DP.

## Self-test — Part IV

**Q1.** A plant model chooses between two boilers. Boiler A: fixed cost 500, capacity 80. Boiler B: fixed cost 300, capacity 60. Demand is 100 (so at least two units of capacity are needed... check!). Write the MILP with correct linking constraints. Then: a colleague's version uses $x_A \le 10^6 y_A$, $x_B \le 10^6 y_B$ and reports the LP relaxation bound. Roughly what will that bound be missing, and why does it matter?

**Q2.** In Worked Example 9, suppose node A2's LP had come back with $z = 19.5$ instead of 20, everything else unchanged. Trace what branch and bound does next, and state the final answer with its proof.

**Q3.** Derive a Chvátal–Gomory cut for: $\{\,x_1, x_2 \ge 0 \text{ integer},\ 2x_1 + 2x_2 \le 7\,\}$ using the single constraint with weight $\tfrac12$. What does the cut do to the LP optimum for $\max\ x_1 + x_2$?

**Q4.** True or false: "A MILP solver that stops at a 1% gap has found a solution within 1% of optimal, but cannot prove it." Explain precisely.

**Q5.** You must schedule battery charge/discharge over 24 hourly periods; the state is the battery's energy level, discretized to 200 levels; each hour offers 3 actions. Compare the cost of enumeration versus DP, and name the condition that makes DP valid here.

**Q6.** Your 40-truck assignment model from Part II's self-test now gains one side constraint: trucks 7 and 12 cannot both be assigned to the north region (shared driver). What does this do to the solution method, and why?

**Answers.**

**A1.** With $x_A, x_B \ge 0$ continuous outputs and $y_A, y_B \in \{0,1\}$:
$\min\ 500y_A + 300y_B + (\text{running costs})$ s.t. $x_A + x_B \ge 100$, $x_A \le 80\,y_A$, $x_B \le 60\,y_B$. (Demand 100 exceeds either single capacity, so both must open — the model should discover that, not assume it.) With $M = 10^6$, the relaxation sets $y_A \approx x_A/10^6 \approx 10^{-4}$: it pays essentially *none* of the fixed costs, so the bound collapses to running costs alone (§13.3). The consequence is not a wrong answer — branch and bound remains exact — but a *slow* one: bounds that ignore the fixed costs cannot prune nodes that differ in the open/close decisions, which are the whole point of the model.

**A2.** A2 gives an integer point $(4,0)$... no — with $z = 19.5$ it could not be the integer point $(4,0)$; suppose it returned some fractional point with bound 19.5. Then: incumbent is still 19 (from A1). Node C (bound 18) is pruned as before ($18 < 19$). Node A2 has bound 19.5 > 19, so it must be *branched*, not pruned; its children's relaxations are each $\le 19.5$. Any integer child with value 19.5 is impossible (values here are integers since $c$ is integral: the bound effectively floors to 19), so every child either proves $\le 19$ or is infeasible — after which the incumbent 19 is optimal, certified because no open node's bound exceeds it. The point of the question: pruning compares *bounds* to the *incumbent*, and integral objective data lets you round bounds down — a real solver trick (it prunes at $z \le 19.999$).

**A3.** Weight $\tfrac12$: $x_1 + x_2 \le 3.5$; the left side is integral, so $x_1 + x_2 \le 3$. The LP relaxation of $\max x_1 + x_2$ originally achieves $3.5$ (anywhere on the line $2x_1+2x_2=7$); with the cut, the LP optimum is $3$ — integral, e.g. at $(3,0)$ — and equals the true integer optimum. One cut, gap closed, exactly as in §15.1.

**A4.** **False**, importantly: it is the reverse of the truth's emphasis. The solver has found a feasible solution *and can prove* it is within 1% — that is what the gap *is*: the distance between an achieved value (incumbent) and a rigorous bound on the best possible (best open relaxation). The 1% statement is a certificate, not a hope (§14.3, §9.5). What the solver has *not* done is prove the incumbent exactly optimal — the true optimum may lie anywhere inside the 1% window, including at the incumbent itself.

**A5.** States: $24 \times 200 = 4800$ (stage, level) pairs; work $\approx$ states × actions $= 14{,}400$ evaluations — trivial. Enumeration: $3^{24} \approx 2.8 \times 10^{11}$ action sequences — not trivial. Validity requires the **state property** (§16.3): the battery's energy level must summarize everything the future needs — true if prices/demands are known per period and losses depend only on current level and action. If, say, a warranty constraint depended on the *entire past cycling history*, the level alone would no longer be a valid state, and you would need to augment it (and pay the curse).

**A6.** The pure assignment was totally unimodular, so plain LP returned integers (§6.2). The side constraint $y_{7,N} + y_{12,N} \le 1$ couples rows and **destroys the TU structure** (§6.3's first honest limit): the LP relaxation may now return fractions, and you genuinely need branch and bound — though in practice the tree will be tiny, since the relaxation is nearly integral. The strategic lesson: integrality was free until the first "small extra requirement"; recheck structure every time the model grows.

---

---
---

---
---

# PART V — WHEN THERE IS NO STRUCTURE

Every method so far exploited something: linearity, convexity, differentiability, network form, a relaxation bound, a stage decomposition. This Part is about the honest residue — problems where no such structure exists or none can be found — and the tools that remain: stochastic search (Chapter 17) and model-based search (Chapter 18). The recurring theme, set up by §9.5 and worth stating before we start: **these tools produce feasible points, hence only upper bounds, hence no certificates.** They can find good answers; they can never prove an answer good. Use them when you must, never when you needn't.

---

## 17. Heuristics and metaheuristics

### 17.1 When you need them — and when you must not use them

Legitimate triggers, all of which you can now recognize precisely:

- The objective is a **black box** — a simulation, an experiment, a legacy executable. No gradients, no algebraic form, and (per §12.1) finite-difference gradients on simulation noise are garbage.
- The problem is **nonsmooth or discontinuous**: an `if` inside the simulation, a table lookup, a remeshing step.
- The landscape is **strongly multimodal**, and local methods from any single start are unreliable even with multi-start.
- The problem is **combinatorial with no useful relaxation**, at a scale where branch and bound will not finish.

And the converse, which matters more than the list:

> **If your problem is an LP, a convex program, a network flow, a smooth NLP, or a MILP of moderate size — do not use a metaheuristic.** A dedicated solver will be faster *and* hand you a certificate. Reaching for a genetic algorithm on a problem that a MILP solver would prove optimal in two seconds is among the most common and most expensive mistakes in applied optimization — and §6 showed that some problems that *look* combinatorial (assignment! routing on networks!) are not even hard. The self-test of Part II already made you defend this once; industry will make you defend it monthly.

---

#### Exercises

**17.1.1 [C]** List the four legitimate triggers for reaching for a metaheuristic, and for each name the section of the course that lets you *diagnose* it rather than guess.

**17.1.2 [M]** For each problem, say whether a metaheuristic is appropriate; if not, name the method that is and why:
(a) scheduling 45 jobs on 6 machines to minimize makespan, with sequence-dependent setup times;
(b) fitting 4 parameters of a smooth ODE model to 200 data points;
(c) blending 12 feedstocks to meet 8 specifications at minimum cost;
(d) choosing wing-shape parameters where each evaluation is a 6-hour CFD run;
(e) assigning 200 technicians to 200 jobs at minimum total travel;
(f) minimizing a stiff, nonsmooth objective from a legacy executable with 5 inputs.

**17.1.3 [C]** The text calls reaching for a GA on a MILP-solvable problem "among the most common and most expensive mistakes." Give the two distinct costs of that mistake — one about the answer, one about what you never learn.

**17.1.4 [M]** A vendor proposes a genetic algorithm for your production-planning problem, arguing "it handles any objective." Write the three questions you would ask before agreeing, and say what answer would change your mind.


### 17.2 Worked Example 12 — a local optimum you can verify by hand

*The knapsack from §16.3, now attacked the way people actually attack messy discrete problems: by local search. Capacity $W = 10$; items:*

| Item | 1 | 2 | 3 | 4 |
|---|---|---|---|---|
| value | 10 | 10 | 11 | 11 |
| weight | 6 | 6 | 5 | 5 |

Start from the selection $S = \{1\}$ (value 10, weight 6) and hill-climb with the **single-flip** neighborhood — add or remove one item. Check every move by hand:

| Candidate move | Result | Improving? |
|---|---|---|
| add item 2 | weight $6+6 = 12 > 10$ | infeasible |
| add item 3 | weight $6+5 = 11 > 10$ | infeasible |
| add item 4 | weight $6+5 = 11 > 10$ | infeasible |
| drop item 1 | value 0 | worse |

**No improving single flip exists**, so hill-climbing stops and reports $S = \{1\}$, value 10, as a "solution." The global optimum — you computed it with DP in §16.3 — is $\{3, 4\}$: value $\mathbf{22}$, weight 10, feasible. The local optimum is **55% below optimal, on a four-item problem.** If a landscape this tiny hides a trap this deep, imagine four hundred items.

![Knapsack trap and SA runs](figures/fig17_knapsack.png)

*Figure 17.1 — Left: the entire feasible landscape under single flips — six subsets, connected only as shown. From $\{1\}$ (red), every neighbor is infeasible except the empty set: to reach $\{3,4\}$ (green), the search must first accept a collapse from value 10 to value 0. Right: simulated annealing (§17.3) run 8 times with single-flip moves; a couple of seeds make the leap early (while $T$ is hot) and freeze at 22; the rest cool before daring the drop and freeze at 10.*

**Two distinct lessons live in this one example**, and the second is the one people miss:

**(a) Acceptance rules.** To escape via single flips you must accept a strictly *worse* intermediate ($\{1\} \to \{\}$, value $10 \to 0$). Simulated annealing, tabu search, and evolutionary methods are, at bottom, disciplined mechanisms for permitting exactly that.

**(b) Neighborhood design — which usually matters more.** Enlarge the neighborhood to include **swaps** (one item out, one in, in a single move). Now from $\{1\}$: swap 1 out, 3 in → $\{3\}$, value 11, weight 5 — an *improvement*. Then add item 4 → $\{3, 4\}$, value 22. **Plain deterministic hill-climbing reaches the global optimum, with no randomness, no temperature, no tuning — purely because the moves were better designed.** Verify by machine, both neighborhoods side by side:

```python
"""Worked Example 12: hill-climbing with two neighborhoods."""
import numpy as np

vals = np.array([10, 10, 11, 11]); wts = np.array([6, 6, 5, 5]); W = 10
value  = lambda S: int(vals[list(S)].sum()) if S else 0
weight = lambda S: int(wts[list(S)].sum()) if S else 0

def flips(S):                                  # add or remove one item
    for i in range(4):
        T = set(S); T.symmetric_difference_update({i}); yield T

def flips_and_swaps(S):                        # ...plus exchange one-for-one
    yield from flips(S)
    for i in list(S):
        for j in set(range(4)) - S:
            T = set(S); T.remove(i); T.add(j); yield T

def hill_climb(S, neighborhood):
    S, path = set(S), [(sorted(S), value(S))]
    while True:
        better = [T for T in neighborhood(S)
                  if weight(T) <= W and value(T) > value(S)]
        if not better:
            return path
        S = max(better, key=value); path.append((sorted(S), value(S)))

print("single-flip :", hill_climb({0}, flips))
print("flip + swap :", hill_climb({0}, flips_and_swaps))
```

```
single-flip : [([0], 10)]
flip + swap : [([0], 10), ([2], 11), ([2, 3], 22)]
```

> **Before you add a temperature schedule and a mutation rate, ask whether your neighborhood is rich enough.** It is the cheaper fix, and it is more often the real problem. A metaheuristic is a way of *searching* a landscape; the neighborhood *is* the landscape.

---

#### Exercises

**17.2.1 [H]** Reproduce the hand verification of the text's example: from $S = \{1\}$ in the knapsack (values $10,10,11,11$; weights $6,6,5,5$; $W = 10$), check every single-flip move and show none improves. State the optimum and the percentage shortfall.

**17.2.2 [H]** **A trap that swaps cannot fix.** Five items, values $(12,12,9,9,9)$, weights $(7,7,5,5,5)$, capacity $W = 15$. Start from $S = \{1,2\}$ (0-indexed: items 1 and 2, the two heavy ones). (a) Find the global optimum by enumeration. (b) Show that no single flip improves $S$. (c) Show that no single *swap* improves it either. (d) Find a move class that does escape, and state the smallest one you can find.

**17.2.3 [P]** Implement hill-climbing with three neighborhoods on 17.2.2 — flips; flips+swaps; flips+swaps+("drop up to 2, add up to 3") — and report where each stops. Then run simulated annealing with single flips under three cooling schedules and report, over 20 seeds, how often each reaches the optimum.

**17.2.4 [M]** State the text's moral about neighborhoods versus acceptance rules, and then qualify it using your 17.2.3 results: when is enriching the neighborhood *not* enough, and what does that cost?


### 17.3 The main metaheuristics, briefly and honestly

**Simulated annealing (SA).** Propose a random neighbor; accept it if better, and accept it *even if worse* with probability $\exp(-\Delta f / T)$. Start with a high "temperature" $T$ and cool it gradually. The entire mechanism is in that exponential — for a worsening of $\Delta f = +5$:

| $T$ | $e^{-5/T}$ | behavior |
|---|---|---|
| 50 | 0.90 | accepts almost anything — near a random walk |
| 10 | 0.61 | broad exploration |
| 5 | 0.37 | exploring |
| 2 | 0.082 | becoming selective |
| 1 | 0.0067 | nearly greedy |
| 0.5 | $4.5 \times 10^{-5}$ | greedy |
| 0.2 | $1.4 \times 10^{-11}$ | frozen — pure hill-climbing |

![SA acceptance](figures/fig17_sa_accept.png)

*Figure 17.2 — Acceptance probability versus temperature for three sizes of worsening move. The cooling schedule* is *the algorithm: cool too fast and you freeze into the first local optimum you meet; too slowly and you spend the entire budget wandering. Note also that $T$ must be scaled to the size of typical $\Delta f$ in* your *objective — the scaling lesson of §2.3, back in a new costume.*

And the honest experiment, from Figure 17.1's right panel: SA with the *bad* (single-flip) neighborhood, 20 independent seeds on our knapsack, reached 22 in only **5 of 20 runs** (best 22, median 10, worst 10) — while deterministic hill-climbing with the *good* neighborhood reached 22 in 2 steps, every time, for free. Randomness is a tax you pay for not understanding your landscape; sometimes you must pay it, but check first.

**Genetic / evolutionary algorithms (GA).** Maintain a *population* of solutions. Repeat: **select** fitter members, **recombine** pairs (crossover), **mutate** slightly, replace. Naturally parallel, and comfortable with mixed discrete/continuous encodings — which is why GA is popular in early-stage conceptual design. The costs: population size, crossover and mutation rates all need tuning; convergence is slow and unproven.

**Particle swarm (PSO).** Points move through continuous space with velocities pulled toward each particle's own best-seen position and the swarm's best. Trivial to implement; prone to premature convergence when the swarm collapses onto one basin.

**Tabu search.** Local search with a short-term memory of recent moves, which are temporarily forbidden ("tabu") — forcing the search out of the basin it just explored instead of oscillating back in. Often the strongest choice on structured combinatorial problems, and in its classical form it is deterministic, which makes runs reproducible and debuggable (practical implementations often add randomized elements).

---

#### Exercises

**17.3.1 [H]** Compute the SA acceptance probability $e^{-\Delta f/T}$ for $\Delta f = +1$ and $\Delta f = +5$ at $T = 50, 10, 5, 2, 1, 0.5, 0.2$. At what temperature does a worsening of 5 become effectively impossible ($< 10^{-4}$), and what does that imply about the cooling schedule?

**17.3.2 [C]** The text warns that $T$ "must be scaled to the size of typical $\Delta f$ in *your* objective." Explain the failure mode if your objective is in joules ($\sim10^6$) and you use $T_0 = 1$, and the opposite failure if it is in megajoules ($\sim1$) and you use $T_0 = 10^4$. Which earlier section is this?

**17.3.3 [C]** For SA, GA, PSO and tabu search, give in one line each: the escape mechanism, the parameters needing tuning, and the characteristic failure mode.

**17.3.4 [M]** You must choose a metaheuristic for a structured combinatorial problem (crew rostering) where runs must be reproducible for audit. Which do you pick and why, and what would you have to add if you picked one of the stochastic families instead?


### 17.4 Experimental hygiene

Most of the above are **stochastic**: two runs give two answers. If you report metaheuristic results — in a thesis, a design review, anywhere — the following are not optional courtesies; they are the difference between evidence and anecdote:

- **Run multiple independent trials** and report the distribution — best, median, worst — as we just did (5/20 success is a finding; one lucky 22 is a fluke dressed as a result).
- **Fix and report random seeds and the evaluation budget**, or the result is not reproducible.
- **Compare against honest baselines at the same evaluation budget**: plain random search, and multi-start local optimization. A surprising number of published metaheuristic "improvements" do not beat multi-start L-BFGS on a fair comparison.
- **Check final feasibility explicitly.** Most metaheuristics handle constraints by penalty terms, which trades one tuning problem for another and frequently returns slightly infeasible points. Evaluate every constraint at the returned point yourself.

---

#### Exercises

**17.4.1 [C]** List the four hygiene requirements, and for each state what conclusion becomes invalid if it is skipped.

**17.4.2 [P]** Practise the third requirement. On the 1-D test function $f(x) = \sin(10x)\,x + 1.2(x-1)^2$ over $[0,2]$, compare at an equal budget of 16 evaluations: (a) uniform grid; (b) random search (200 repetitions — report median and best-case); (c) the Bayesian optimization loop of §18.2. Report all three and say which comparison would have been misleading if you had reported only the best random-search run.

**17.4.3 [M]** A thesis reports: "The proposed hybrid GA found a design of mass 41.2 kg, better than the 43.8 kg from gradient-based optimization." List everything missing before this sentence constitutes evidence, and write the corrected version.

**17.4.4 [C]** Why is "check final feasibility explicitly" a *separate* requirement rather than something the algorithm guarantees? Name the mechanism that creates the problem.


### 17.5 The limitations, stated plainly

- **No lower bound, therefore no certificate.** A metaheuristic cannot tell you whether you are 1% or 300% from optimal. Section 9.5 says exactly why: these methods generate feasible points only, and feasible points bound $f^\star$ from one side. A lower bound requires a relaxation or a dual — which requires structure. This is not a maturity problem awaiting better heuristics; it is structural and permanent.
- **Tuning consumes the budget** you were trying to conserve — temperatures, populations, rates, neighborhoods.
- **The No Free Lunch theorems** (Wolpert & Macready, 1997) make the limitation precise: averaged over *all possible objective functions*, every non-revisiting search algorithm performs identically. Any algorithm's advantage on your problem comes entirely from matching your problem's structure. There is no universally best method — which is exactly why Parts I–IV matter even on the days you end up using a heuristic.

> **A good default for a hard, nonconvex, smooth-ish problem:** use a global strategy (or plain multi-start) to *locate* promising basins, then polish each candidate with a gradient-based local method from Part III. Global reach from one family, fast certified-local convergence from the other — and you can report how many distinct local optima you found, which is genuine information about the problem.

---

#### Exercises

**17.5.1 [C]** Explain, using the upper/lower-bound framing of §9.5, why a metaheuristic can never certify optimality — and why this is structural rather than a technology gap.

**17.5.2 [C]** State the No Free Lunch result carefully, then explain what it does *and does not* license you to conclude. (Two common misreadings: "all algorithms are equally good on my problem," and "so method choice does not matter.")

**17.5.3 [M]** Your heuristic returns a schedule costing \$1.42 M. Management asks "how good is that?" Give the answer you can honestly give, and describe one concrete way to obtain a lower bound so the question becomes answerable.

**17.5.4 [M]** Reproduce and justify the text's recommended default for a hard, nonconvex, smooth-ish problem. Say what each half of the strategy contributes, and what genuinely useful information the combination reports.


---

## 18. Expensive black boxes: surrogate and Bayesian optimization

If one evaluation of $f$ takes hours — a CFD run, a transient finite-element analysis, a physical experiment — then a metaheuristic needing $10^4$ evaluations is out of the question, and even multi-start local search is extravagant. The right tool **spends its intelligence between evaluations**: it builds a cheap statistical model of the expensive function and lets the model decide where to evaluate next.

### 18.1 The loop

1. Evaluate the true function at a modest, well-spread set of points (a *design of experiments* — Latin hypercube sampling, typically).
2. Fit a **surrogate** — most commonly a **Gaussian process (GP)**, which returns at every candidate point both a *prediction* and an *uncertainty*.
3. Choose the next expensive evaluation by maximizing an **acquisition function** such as *expected improvement (EI)*, which deliberately balances "the model predicts a good value here" (exploitation) against "the model is very uncertain here" (exploration).
4. Add the new point, refit, repeat until the budget is spent.

This is **Bayesian optimization (BO)**. Its strength is *sample efficiency* — tens of evaluations rather than thousands — and it is the standard approach for expensive, possibly noisy, low-dimensional problems (roughly $n \lesssim 20$; beyond that, fitting the surrogate itself becomes the bottleneck). It is also what automated hyperparameter-tuning tools use under the hood.

---

#### Exercises

**18.1.1 [C]** Write the four steps of the Bayesian-optimization loop, and state what a Gaussian process returns at each candidate point that a plain regression does not.

**18.1.2 [C]** Explain how expected improvement balances exploitation and exploration by inspecting its formula $EI = (y_{\min}-\mu)\Phi(z) + \sigma\phi(z)$ with $z = (y_{\min}-\mu)/\sigma$. Which term dominates in a well-sampled region, and which in an unexplored one?

**18.1.3 [M]** BO is recommended for roughly $n \lesssim 20$. Give the two distinct reasons the method degrades in higher dimensions, and say what you would use instead at $n = 500$ with cheap gradients.

**18.1.4 [M]** For each situation, choose between BO, a metaheuristic and a gradient method, with one sentence of justification: (a) 8 parameters, each evaluation a 4-hour transient FEA, no gradients; (b) 8 parameters, analytic gradients, smooth, unimodal; (c) 60 binary decisions, fast objective, no relaxation; (d) 3 parameters tuned on a physical rig where each test costs \$2 000 and is noisy.


### 18.2 Watch it think

The whole loop — a small GP and expected improvement — fits in a page of NumPy, and building it once removes all the mystery:

```python
"""Bayesian optimization from scratch on a multimodal 1-D function."""
import numpy as np
from scipy.stats import norm

def f(x):                                     # the "expensive" black box
    return np.sin(10*x)*x + 1.2*(x - 1)**2

xg = np.linspace(0, 2, 2001)                  # candidate grid

def gp_posterior(X, y, Xs, ell=0.15, sf=1.0, noise=1e-8):
    """GP with RBF kernel: return posterior mean and std on Xs."""
    k = lambda a, b: sf*np.exp(-(a[:, None] - b[None, :])**2/(2*ell**2))
    L = np.linalg.cholesky(k(X, X) + noise*np.eye(len(X)))
    alpha = np.linalg.solve(L.T, np.linalg.solve(L, y))
    Ks = k(X, Xs)
    mu = Ks.T @ alpha
    v = np.linalg.solve(L, Ks)
    return mu, np.sqrt(np.clip(sf - np.sum(v**2, axis=0), 1e-12, None))

X = np.array([0.15, 0.7, 1.3, 1.9]); y = f(X)     # initial design: 4 points
for it in range(12):
    mu, sd = gp_posterior(X, y, xg)
    z = (y.min() - mu)/sd                          # expected improvement
    EI = (y.min() - mu)*norm.cdf(z) + sd*norm.pdf(z)
    x_next = xg[np.argmax(EI)]
    X, y = np.append(X, x_next), np.append(y, f(x_next))

print(f"best found : x = {X[np.argmin(y)]:.4f},  f = {y.min():.5f}   ({len(X)} evaluations)")
print(f"grid truth : x = {xg[np.argmin(f(xg))]:.4f},  f = {f(xg).min():.5f}")
```

```
best found : x = 1.7240,  f = -1.09369   (16 evaluations)
grid truth : x = 1.7240,  f = -1.09369
```

Sixteen evaluations to find the global minimum of a function with several local minima — where a grid at the same resolution costs 2001 and a metaheuristic would cost thousands.

![BO snapshot](figures/fig18_bo.png)

*Figure 18.1 — A snapshot mid-run (after 7 evaluations). Top: the GP's mean hugs the truth near sampled points (black dots), and its $\pm 2\sigma$ band widens honestly in the gaps. Bottom: expected improvement is high both where the mean is low* and *where uncertainty is high — the next evaluation (dotted line) is placed by that trade-off, not by the mean alone. This is the picture to hold: BO is trust-region thinking (§7.5) with a statistical model of trust.*

An instructive detail from this very run: for its first ten evaluations, BO's best point sat in a *different* local basin ($x \approx 1.11$, $f \approx -1.089$ — within 0.5% of optimal by value). The exploration term of EI is what eventually pushed an evaluation into the true basin. With a smaller budget we would have stopped with a near-optimal answer *and no way to know* whether a better basin existed — which brings us to the cautions.

---

#### Exercises

**18.2.1 [P]** Run the §18.2 loop and confirm it finds the global minimum of $f(x) = \sin(10x)x + 1.2(x-1)^2$ on $[0,2]$ in 16 evaluations. Then print the best-so-far after each iteration and identify the iteration at which the search first enters the true basin.

**18.2.2 [P]** **Kernel length-scale sensitivity.** Re-run the same loop with $\ell = 0.05$, $0.15$ and $0.5$, all else identical. Report the best value found in each case and explain the two distinct failure mechanisms of a too-small and a too-large length scale.

**18.2.3 [H]** In the GP code, the posterior standard deviation is computed as $\sqrt{s_f - \sum v^2}$ with $v = L^{-1}K_s$. Explain what this expression is, and why $\sigma$ is exactly zero at a sampled point (in the noise-free limit). What does that guarantee about where EI will *never* place a new evaluation?

**18.2.4 [M]** The text notes that for its first ten evaluations, BO's best point sat in a different local basin at $f \approx -1.089$ — within 0.5 % of the true optimum by value. Discuss what would have happened with a budget of 10 rather than 16, and what this implies about reporting BO results.


### 18.3 Two cautions

**The uncertainty is only as good as the surrogate's assumptions.** The GP's error bars come from its kernel — its assumed smoothness and length scale. A badly chosen kernel produces *confident nonsense*: narrow bands around wrong predictions, and an acquisition function that never looks where it should. Kernel hyperparameters are usually fit by maximum likelihood, which helps, but on tiny budgets the assumptions dominate.

**No bound, no certificate — again.** Like everything in this Part, BO returns feasible evaluations, hence upper bounds only. It cannot tell you what it missed. What it *can* do — and simpler methods cannot — is spend each precious evaluation where the model says information is highest, which is the best one can do without structure.

---

#### Exercises

**18.3.1 [C]** Explain the "confident nonsense" failure mode. Which specific object in the GP produces the error bars, and what practice partially mitigates a bad choice?

**18.3.2 [C]** Restate the no-certificate limitation for BO, and say precisely what BO *does* provide that simpler black-box methods do not.

**18.3.3 [M]** You have a budget of 40 expensive evaluations and 6 design variables. Write the protocol you would follow — initial design, kernel handling, stopping, and reporting — such that a reviewer could assess the result's reliability.

**18.3.4 [M]** Connect §18 back to §7.5: in what sense is BO "trust-region thinking with a statistical model of trust," and where does the analogy break down?


---

## Checkpoint — Part V

You should now be able to:

- list the legitimate triggers for heuristics, and — more importantly — recite the converse rule and catch structure (convexity, networks, stages) before reaching for stochastic search;
- reproduce Worked Example 12 by hand: verify that no single flip improves $\{1\}$, and that adding swaps lets deterministic hill-climbing reach the optimum;
- explain acceptance rules versus neighborhood design, and why the neighborhood usually matters more;
- describe SA (and the meaning of its temperature, including its scaling), GA, PSO, and tabu search, each in two honest sentences;
- state the four rules of experimental hygiene, and explain what "5 successes in 20 seeds" means as a reported result;
- state why heuristics can never produce certificates (via §9.5) and paraphrase No Free Lunch correctly;
- sketch the BO loop, explain what a GP posterior and expected improvement each contribute, and state BO's dimension limit and its two cautions.

## Self-test — Part V

**Q1.** A colleague proposes a genetic algorithm to schedule 12 jobs on one machine minimizing total weighted completion time, "because scheduling is NP-hard." Two things to check before agreeing?

**Q2.** In Worked Example 12, suppose item 2's weight were 4 instead of 6. Redo the single-flip hill-climb from $\{1\}$ by hand. Does the trap survive?

**Q3.** Your SA run on a layout problem returns cost 412. Your boss asks, "How far from optimal is that?" Give the honest answer, and name two things you could do to say *something* quantitative.

**Q4.** BO on a 30-minute CFD objective returns its budget-exhausted best after 40 evaluations. The GP's error bars at the returned point are tiny. Does that mean the answer is near-optimal? Why or why not?

**Q5.** Design the baseline experiment that a fair evaluation of "our new metaheuristic" must include, per §17.4.

**Answers.**

**A1.** First: is it *actually* hard? Single-machine scheduling by weighted completion time is solved *exactly* by a sorting rule (weighted shortest processing time first) — many "NP-hard-sounding" problems have easy special cases, just as assignment did (§6.2). Second, even were it hard: at 12 jobs, $12! \approx 4.8\times10^8$ — enumerable in seconds, and trivially within reach of a MILP with the disjunctive formulation of §13.4, *with a certificate*. NP-hardness is a statement about worst-case scaling, not about your instance.

**A2.** With weights $(6, 4, 5, 5)$: from $\{1\}$ (weight 6), adding item 2 gives weight 10 ≤ 10 — feasible, value 20: an improving flip exists. Hill-climb: $\{1\} \to \{1,2\}$ (value 20, weight 10); from there every add is infeasible and every drop is worse — new local optimum 20 versus global $\{3,4\} = 22$. The trap *survives in weakened form*: single flips now improve the start but still cannot reach the optimum (to leave $\{1,2\}$ you must drop to value ~10). Moral: whether a neighborhood suffices depends on the *data*, not just the problem class — which is why you test it (multi-start, or a known small instance) rather than assume.

**A3.** Honest answer: *unknown* — SA provides no lower bound, so 412 could be 1% or 100% from optimal (§17.5). To say something quantitative: (1) compute a lower bound from structure if any exists — an LP/Lagrangian relaxation of the layout model turns "cost 412" into "cost 412, provably within X% of optimal"; (2) run the hygiene battery — many seeds, plus multi-start local search and random search at equal budget — which bounds nothing but tells you whether 412 is *stable* or a lucky draw.

**A4.** No. Tiny error bars at the returned point mean the surrogate is confident *about that point's value* — it says nothing about unexplored basins elsewhere, where the bars are wide (or worse, falsely narrow if the kernel's smoothness assumption is wrong, §18.3). Near-optimality claims need a lower bound, and BO has none. What you can honestly report: best value found, evaluation budget, and the acquisition landscape at termination (was EI everywhere small — suggesting diminishing returns — or still large somewhere, suggesting an unexplored region?).

**A5.** At an identical evaluation budget and identical constraint handling: (a) pure random search; (b) multi-start local optimization (L-BFGS or pattern search as smoothness allows) with starts from the same random stream; (c) the new method — each run with $\ge 20$ seeds, reporting best/median/worst and the seeds themselves. The new method must beat (a) *and* (b) on the distribution, not on a best-of-runs anecdote.

---
---

# PART VI — PRACTICE

Everything so far optimized a single objective with known data and interrogated one answer at a time. Real projects have several objectives, uncertain data, and stakeholders who ask "can we trust this?" This Part is the field manual: trade-offs (Chapter 19), uncertainty (Chapter 20), and the discipline of choosing, diagnosing, and verifying (Chapter 21).

---

## 19. Multiple objectives

Real designs trade off: mass against cost, accuracy against speed, performance against robustness. There is no single optimum — but there *is* a well-defined set of defensible answers, and clean machinery for computing it.

Design $x^a$ **dominates** $x^b$ if it is at least as good in every objective and strictly better in at least one. A design dominated by nothing is **Pareto optimal**; the set of all such designs (seen in objective space) is the **Pareto front**. Everything off the front is simply a mistake — you could improve something for free; everything on the front is a legitimate choice whose selection is a *values* judgment, not a mathematical one.

### 19.1 Method 1 — the weighted sum

Minimize $w_1 f_1 + w_2 f_2$ (with $w_i \ge 0$, $\sum w_i = 1$) and sweep the weights.

- **Requires normalization.** If $f_1$ is grams and $f_2$ is millions of dollars, the weights are meaningless numerology. Scale each objective to roughly $[0, 1]$ using its best achievable value (the *ideal point*, from optimizing it alone) and its worst value over the front (the *nadir*).
- **Cheap and simple**, and it sweeps the *entire* front when the front is convex — which it is whenever the underlying problem is convex.
- **But it can never return a point in a nonconvex (dented) region of the front.** Geometrically, minimizing $w_1 f_1 + w_2 f_2$ slides a line of slope $-w_1/w_2$ onto the front; a line rolled along a dented curve touches only the rim of the dent and jumps across it. The skipped region is often exactly the interesting compromise zone.

---

#### Exercises

**19.1.1 [C]** Define dominance, Pareto optimality and the Pareto front. Then explain the sentence "everything off the front is simply a mistake."

**19.1.2 [H]** Show why normalization is essential. Objectives are mass in grams ($\sim400$) and cost in millions of dollars ($\sim2$). With $w = (0.5, 0.5)$ on the raw values, what is effectively being optimized? Give the normalization the text recommends, with the two reference points named.

**19.1.3 [H]** Prove geometrically that a weighted sum can never return a point in a dented (nonconvex) region of the front: describe the rolling-line argument, and state exactly which points the sweep *can* return.

**19.1.4 [M]** When *is* the weighted sum the right choice? Give the condition that makes it complete, and one practical advantage over the $\varepsilon$-constraint method.


### 19.2 Method 2 — the $\varepsilon$-constraint

Minimize $f_1$ subject to $f_2 \le \varepsilon$, and sweep $\varepsilon$.

- **Reaches the entire front**, convex or not — a constraint can sit anywhere a line cannot.
- **Each run answers a real engineering question**: "what is the lightest design costing no more than \$X?" — which is how requirements are written anyway.
- **Its own costs:** you must choose the $\varepsilon$ grid (some values will be infeasible); it needs one solve per point; and in plain form it can return *weakly* Pareto-optimal points — designs where some objective could still improve at no cost to the other. The standard fix (the *augmented* $\varepsilon$-constraint method) adds a small reward for slack in the constrained objective, which eliminates them.

---

#### Exercises

**19.2.1 [C]** State the $\varepsilon$-constraint formulation and its two headline advantages. Why does "each run answers a real engineering question"?

**19.2.2 [C]** List the method's three costs, and explain what a *weakly* Pareto-optimal point is. What is the standard fix, and how does it work?

**19.2.3 [H]** For the bi-objective problem $f_1 = \|x - (0,0)\|^2$, $f_2 = \|x - (2,1)\|^2$, set up the $\varepsilon$-constraint problem for $\varepsilon = 2$ and identify by hand where the solution must lie (use the geometry: minimize distance to the origin subject to being within a disk about $(2,1)$).

**19.2.4 [M]** Requirements arrive as "mass under 40 kg and cost under \$18 000." Explain which scalarization matches this phrasing, how you would generate the front, and what you would present.


### 19.3 Both methods, computed

```python
"""Pareto front of a convex bi-objective problem, both methods."""
import numpy as np, cvxpy as cp

a, b = np.array([0., 0.]), np.array([2., 1.])     # f1 = |x-a|^2, f2 = |x-b|^2

print("weighted sum:")
for w in [0.1, 0.5, 0.9]:
    x = cp.Variable(2)
    cp.Problem(cp.Minimize(w*cp.sum_squares(x - a)
                           + (1 - w)*cp.sum_squares(x - b))).solve()
    print(f"  w={w}:  f1={np.sum((x.value-a)**2):.3f}  f2={np.sum((x.value-b)**2):.3f}")

print("epsilon-constraint:")
for eps in [0.5, 2.0, 4.0]:
    x = cp.Variable(2)
    cp.Problem(cp.Minimize(cp.sum_squares(x - a)),
               [cp.sum_squares(x - b) <= eps]).solve()
    print(f"  eps={eps}:  f1={np.sum((x.value-a)**2):.3f}  f2={np.sum((x.value-b)**2):.3f}")
```

```
weighted sum:
  w=0.1:  f1=4.050  f2=0.050
  w=0.5:  f1=1.250  f2=1.250
  w=0.9:  f1=0.050  f2=4.050
epsilon-constraint:
  eps=0.5:  f1=2.338  f2=0.500
  eps=2.0:  f1=0.675  f2=2.000
  eps=4.0:  f1=0.056  f2=4.000
```

Read the two halves against each other: each weighted-sum point lands wherever the weight ratio dictates, whereas each $\varepsilon$-constraint point sits exactly at the requested budget ($f_2 = \varepsilon$, the constraint active) — which is why the second method speaks the language of requirements.

![Pareto fronts](figures/fig19_pareto.png)

*Figure 19.1 — Left: a convex front; ten weighted-sum solves (dots) and ten $\varepsilon$-constraint solves (squares) both trace it faithfully. Right: a catalog of designs whose front has a dent. Sweeping 400 different weight values reaches only the red-circled points — the rim and the ends; the entire blue stretch is Pareto-optimal yet* unreachable by any weighted sum whatsoever. *In this computed example, only 48 of 213 Pareto-optimal designs are weighted-sum-reachable. If your compromise zone lives in the dent — and it often does — the weighted sum will silently pretend it doesn't exist.*

> **Which to use.** If the problem is convex, a *normalized* weighted sum is cheap and complete — use it. If the front may be nonconvex, or your requirements arrive as limits ("no more than \$X") rather than trade-off rates, use $\varepsilon$-constraint. In doubt, use $\varepsilon$-constraint: its failure mode (a few wasted infeasible solves) is far milder than the weighted sum's (silently missing part of the answer).

> **What to hand a decision-maker.** Not a single design — a Pareto front, with the *knee region* marked: where a small concession in one objective buys a large gain in the other. The front converts a values judgment, which is not yours to make, into an informed choice, which is yours to enable.

---

#### Exercises

**19.3.1 [P]** Reproduce the text's computation for $f_1 = \|x-(0,0)\|^2$, $f_2 = \|x-(2,1)\|^2$ with both methods, then extend it: sweep 25 weights and 25 $\varepsilon$ values and plot (or tabulate) both fronts. Confirm they coincide, and explain why they must here.

**19.3.2 [P]** **A dented front, quantified.** Build a discrete catalogue of 120 designs with $f_1 = t$, $f_2 = (1-t)^2 + A\exp\!\big(-(t-0.5)^2/0.004\big)$ for $t \in [0,1]$. For $A = 0$ (convex) and $A = 0.12$ (dented): count the Pareto-optimal designs, then count how many are reachable by sweeping 2000 weights, and how many by sweeping 2000 $\varepsilon$ values. Report the numbers and interpret them.

**19.3.3 [H]** In the text's output, every $\varepsilon$-constraint point has $f_2 = \varepsilon$ exactly while the weighted-sum points land wherever the ratio dictates. Explain both facts, and say which one makes the method's output easier to explain to a client.

**19.3.4 [M]** Write the recommendation you would give a colleague choosing between the two methods, including the asymmetry-of-failure-modes argument.


---

## 20. Uncertainty

An optimum computed from nominal data is often *fragile*, and for a specific structural reason you already know: **optimization pushes against active constraints** (§1.4, and every worked example since). A design that is exactly feasible at nominal parameters is, by construction, standing on the edge of infeasibility — and real loads, tolerances, and prices do not stay at nominal.

### 20.1 Worked Example 13 — Example 1 meets reality

Return to the plant of Worked Example 1: $\max 40x_1 + 30x_2$ with machine-hours $2x_1 + x_2 \le 100$, material $x_1 + x_2 \le 80$, capacity $x_1 \le 40$. The optimal plan $(20, 60)$ made both M and R **exactly tight**. Now admit what every engineer knows: the machine-time coefficients $(2, 1)$ are *estimates*. Suppose the true row is $a = (2, 1) + \rho u$ for some unknown $u$ with $\|u\|_2 \le 1$ — an uncertainty ball of radius $\rho$ around the nominal.

**Robust optimization** demands feasibility for *every* realization in the ball:

$$\max_{\|u\|_2 \le 1} \big[(2,1) + \rho u\big]^\top x \;\le\; 100
\quad\Longleftrightarrow\quad
(2,1)^\top x + \rho\,\|x\|_2 \;\le\; 100,$$

where the equivalence is because the worst $u$ points along $x$ (maximize a dot product over a ball: align with the vector). Read the result: the robust counterpart of a linear constraint is the same constraint **plus a norm-sized safety margin that scales with the decision itself** — a second-order cone constraint (§3.4). The robust LP is an SOCP: still convex, still globally solvable, still certified. Robustness, remarkably, is often *not harder* — just slightly more conservative.

```python
"""Worked Example 13: nominal vs robust plans, and what fragility costs."""
import numpy as np, cvxpy as cp

def solve_plan(rho):
    x = cp.Variable(2, nonneg=True)
    cons = [np.array([2., 1.]) @ x + rho*cp.norm(x, 2) <= 100,   # robust M
            x[0] + x[1] <= 80,
            x[0] <= 40]
    prob = cp.Problem(cp.Maximize(40*x[0] + 30*x[1]), cons)
    prob.solve()
    return prob.value, x.value

for rho in [0.0, 0.05, 0.1, 0.2]:
    v, xv = solve_plan(rho)
    print(f"rho={rho:4}:  profit = {v:8.2f}   plan = ({xv[0]:5.2f}, {xv[1]:5.2f})")

# stress test: sample 20,000 coefficient realizations at rho = 0.1
rng = np.random.default_rng(3)
U = rng.normal(size=(20000, 2))
U = U/np.linalg.norm(U, axis=1, keepdims=True)*np.sqrt(rng.random((20000, 1)))
rho = 0.1
_, x_nom = solve_plan(0.0)
_, x_rob = solve_plan(rho)
for name, xp in [("nominal", x_nom), ("robust ", x_rob)]:
    viol = np.mean((np.array([2, 1]) + rho*U) @ xp > 100 + 1e-9)
    print(f"{name} plan violates machine-hours in {viol*100:5.1f}% of realizations")
```

```
rho= 0.0:  profit =  2600.00   plan = (20.00, 60.00)
rho=0.05:  profit =  2567.28   plan = (16.73, 63.27)
rho= 0.1:  profit =  2531.90   plan = (13.19, 66.81)
rho= 0.2:  profit =  2449.59   plan = ( 4.96, 75.04)
nominal plan violates machine-hours in  50.0% of realizations
robust  plan violates machine-hours in   0.0% of realizations
```

Read that output as a business case. The nominal "optimal" plan — profit 2600, both constraints tight — **exceeds the true machine-hour budget half the time** once coefficients wobble by a modest $\rho = 0.1$ (of course it does: it sits exactly on the boundary, and half of all perturbations push the boundary inward). The robust plan gives up 68 dollars — **2.6% of profit** — and is violated in **0%** of twenty thousand sampled realizations, by construction in 100% of the ball. That 2.6% is the **price of robustness**, and it is now a number the plant manager can weigh against the cost of blowing the schedule every other week.

![Price of robustness](figures/fig20_robust.png)

*Figure 20.1 — Sweeping the uncertainty radius: robust profit declines gently and near-linearly (blue, left axis) while the nominal plan's chance of violating the machine-hours limit sits at 50% for any $\rho > 0$ (red, right axis) — the geometric signature of a plan optimized onto a knife edge. Insurance here is cheap precisely because the objective is flat near the optimum; that flatness is common, and it is why robust solutions so often cost little.*

---

#### Exercises

**20.1.1 [C]** Explain the structural reason optima are fragile, in one sentence, and connect it to the active-set idea of §1.4. Why does the nominal plan of Worked Example 1 violate the machine-hour constraint in about 50 % of perturbed realizations, and why is 50 % not a coincidence?

**20.1.2 [H]** Derive the robust counterpart of the constraint $a^\top x \le 100$ with $a = (2,1) + \rho u$, $\|u\|_2 \le 1$: perform the inner maximization over $u$ and state the resulting constraint. What class does the problem now belong to (§3.4), and what does that mean for solvability?

**20.1.3 [P]** Reproduce the robust sweep for $\rho \in \{0,\ 0.05,\ 0.1,\ 0.2\}$, then extend it: make the *material* constraint uncertain too (same $\rho$, same ball) and compare the plans and profits. Which constraint's robustification costs more, and can you explain why from the plans?

**20.1.4 [M]** Write the business case for robustness from your numbers: state the price of robustness at $\rho = 0.1$ in dollars and percent, what it buys, and the comparison a plant manager should make.


### 20.2 The toolbox beyond the ellipsoid

**Robust optimization** (above): parameters live in a bounded set; constraints must hold for every point of it. Box uncertainty gives an adjusted LP; ellipsoids give SOCPs; the "price of robustness" is tunable through the set's size. Choose it when violating the constraint is expensive or unsafe and distributions are unknown.

**Stochastic optimization:** treat parameters as random with a known distribution; optimize an expectation, or impose a **chance constraint** ("probability of failure $\le 10^{-3}$"). Preferable when you genuinely know the distribution and care about average performance; computationally harder, and usually approximated by optimizing over sampled scenarios (*sample average approximation*).

> **The cheap version everyone should do, and few do.** Solve at nominal values, then **re-evaluate the resulting design across a spread of perturbed inputs** — exactly the 20,000-sample stress test above, which cost four lines and revealed the 50% fragility. If small parameter changes break feasibility or crater performance, add margin to the active constraints and re-solve. Two or three extra solves, and it catches the worst fragility. Note the family resemblance to §5.8's two-sided shadow-price test: both are "perturb and look" discipline, and both exist because *optimized* systems concentrate their sensitivity exactly where you pressed hardest.

---

#### Exercises

**20.2.1 [C]** Contrast robust optimization and stochastic optimization: what does each assume about the parameters, what does each guarantee, and when would you choose each?

**20.2.2 [H]** For box uncertainty $|a_i - \bar a_i| \le \rho_i$ componentwise, derive the robust counterpart of $a^\top x \le b$ for $x \ge 0$. What problem class results, and how does the conservatism compare with the ellipsoidal case?

**20.2.3 [P]** Implement "the cheap version everyone should do": solve a model at nominal values, then stress-test the resulting design over 20 000 sampled perturbations, reporting the violation frequency and the distribution of the objective. Apply it to Worked Example 1's nominal plan under $\rho = 0.05$ and $\rho = 0.1$.

**20.2.4 [M]** Explain the family resemblance the text draws between the stress test and §5.8's two-sided shadow-price test. What general principle about optimized systems do both reflect?


---

## 21. Choosing a method, diagnosing failures, verifying answers

This chapter is the operating manual for everything before it. Nothing here is new theory; all of it is what separates people who *run* optimizers from people who *use* them.

### 21.1 Choosing

![Method selection flowchart](figures/fig21_flowchart.png)

*Figure 21.1 — The operational version of §1.5's classification table; the two agree by construction. Three sanity notes: linear-plus-integer is still* globally *solvable — that is the point of Part IV. "Convex" is worth checking properly via §3.3 (or letting CVXPY check) rather than assuming. And a smooth nonconvex problem should get gradient methods with multi-start* before *it gets a metaheuristic.*

---

#### Exercises

**21.1.1 [C]** Reconstruct the method-selection logic as a decision tree in words, starting from the two questions of §1.5 and ending in named method families. Include the three sanity notes the text attaches to the flowchart.

**21.1.2 [M]** Apply your tree to five problems, naming the method and the reason:
(a) minimize pumping energy over pipe diameters with nonlinear head-loss physics, continuous, smooth, 12 variables;
(b) choose which of 200 candidate sensor sites to instrument for full coverage at minimum cost;
(c) fit a 3-parameter creep model to 60 data points;
(d) minimize weight of a truss with buckling constraints, 40 continuous variables, suspected multimodality;
(e) tune 4 controller gains against a nonlinear closed-loop simulation with an `if`-based saturation block.

**21.1.3 [C]** Why does the text insist that "convex" be *checked* (via §3.3 or CVXPY) rather than assumed? Give one example of a model that looks nonconvex but is convex, and one that looks convex but is not.

**21.1.4 [M]** A colleague's flowchart sends every nonconvex problem straight to a genetic algorithm. State the missing step and justify it with a cost comparison.


### 21.2 Diagnosing the three bad outcomes

**"Infeasible."** Do not start deleting constraints at random.

1. **Check units and signs first.** A mismatched unit or a flipped inequality causes most infeasibilities.
2. **Make the suspect constraints soft** (§2.2) and minimize total violation — converting a useless status code into a diagnosis. Watch it work:

```python
"""Infeasibility diagnosis: from a status code to an answer."""
from scipy.optimize import linprog

# demand 90; line 1 max 40; line 2 max 45  ->  85 < 90: impossible
r = linprog([0, 0], A_ub=[[-1, -1], [1, 0], [0, 1]], b_ub=[-90, 40, 45],
            bounds=[(0, None)]*2, method="highs")
print("hard model:", r.message.split(".")[0])

# soften the demand constraint: x1 + x2 + s >= 90, minimize s
r2 = linprog([0, 0, 1], A_ub=[[-1, -1, -1], [1, 0, 0], [0, 1, 0]],
             b_ub=[-90, 40, 45], bounds=[(0, None)]*3, method="highs")
print(f"soft model: minimum violation s = {r2.x[2]:.0f} at x = ({r2.x[0]:.0f}, {r2.x[1]:.0f})")
```

```
hard model: The problem is infeasible
soft model: minimum violation s = 5 at x = (40, 45)
```

"Infeasible" became: *both lines at capacity still leave demand short by exactly 5 — either raise a capacity by 5 or lower the demand.* That is a meeting-ready sentence. (Solvers also offer *irreducible infeasible subsystem* analysis — a minimal contradictory subset of constraints — worth knowing the name of.)

3. **Consider that the model may be right.** Sometimes the specification is genuinely impossible, and discovering that early — with the minimum-violation number attached — is among the most valuable outputs optimization ever produces.

**"Unbounded."** You forgot a constraint, a variable bound, or a sign in the objective. The solver reports a ray — a direction of infinite improvement; find which variable is running away and ask what physically limits it (§1.3).

**"Converged, but the answer is nonsense."** The dangerous one, because it looks like success. Almost always a modeling gap. Look at the active set (§1.4), and at any variable sitting exactly on an artificial bound — that bound is doing design work it should not be doing (the pressure vessel's §10.3 was the worked instance). Then ask what physical limit the optimizer has just exploited, and add it. Remember the frame from §2.1: the optimizer is a ruthless search for loopholes in your model, and every absurd answer is a loophole report.

---

#### Exercises

**21.2.1 [C]** For "infeasible," give the three-step protocol in order and say why "start deleting constraints" is not on the list.

**21.2.2 [P]** Practise infeasibility diagnosis. Three lines have capacities 50, 40 and 20; demand is 120. Show the hard model is infeasible, then soften the demand constraint and report the minimum violation and the plan achieving it. Write the meeting-ready sentence.

**21.2.3 [C]** For "unbounded," explain what object the solver reports and how to use it. For "converged to nonsense," give the two things to look at first and say why this outcome is the most dangerous.

**21.2.4 [M]** Name the technique called *irreducible infeasible subsystem* analysis, say what it returns, and contrast its output with the minimum-violation approach. When would you prefer each?


### 21.3 Verifying an answer

Never ship an optimum you have not attacked. In rough order of value per minute spent:

1. **Read the active set.** Does the story match physical expectation? If a constraint you expected to bind is slack, find out why before believing anything else.
2. **Check units and orders of magnitude** on the objective and on every multiplier.
3. **Look for artificial bounds.** A variable pinned at a bound you invented for convenience means the true optimum lies outside your search box.
4. **Solve a simplified case with a known analytic answer** and confirm the model reproduces it. (§10.1 versus §10.2 was exactly this maneuver, used to expose a physics error.)
5. **Perturb and re-solve.** Small input changes should give small output changes; wild jumps mean genuine nonconvexity or numerical fragility — both worth knowing today rather than in service.
6. **Two-sided shadow-price test** on any multiplier that will drive a real decision (§5.8). Degeneracy is common, and one-sided rates can differ.
7. **Multi-start** on any nonconvex problem, and report how many distinct local optima appeared. All starts converging to one point is meaningful evidence — never proof — of global optimality.
8. **Read the multipliers.** They are free sensitivity information (§5.4, §9.4, §10.4). A huge multiplier on some requirement tells you where the cost lives, and where the conversation with the customer should start.

---

#### Exercises

**21.3.1 [C]** Reproduce the eight verification steps in rough order of value per minute, and state which section of the course each one draws on.

**21.3.2 [M]** Apply the checklist to a concrete report: a heat-exchanger network optimization returns total annual cost \$1.24 M; the area variables are all interior; the minimum-approach-temperature constraint is active on three matches; one exchanger's area sits exactly at its upper bound of 500 m²; and the multiplier on $\Delta T_{\min}$ is \$41 000 per K. Write the verification actions you would take and what each would tell you.

**21.3.3 [P]** Implement step 5 ("perturb and re-solve") as a reusable function that re-solves a model over a grid of scaled input perturbations and reports the range of objective values and whether the active set changed. Apply it to Worked Example 1 with $\pm5\%$ on both resource limits.

**21.3.4 [C]** Step 7 says all starts converging to one point is "meaningful evidence — never proof — of global optimality." Explain the distinction precisely, and say what *would* constitute proof.


### 21.4 Twelve things that go wrong most often

1. Variables and constraints not scaled to $O(1)$ (§2.3) — and therefore a huge $\kappa$ (§7.3).
2. General constraints used where variable bounds would do (§1.2).
3. A missing constraint, revealed by an absurd or unbounded answer (§21.2).
4. Optimizing the wrong objective — minimizing mass when the cost driver is machining time.
5. Modeling the wrong physics: an objective that omits the thing that actually varies (§10.2).
6. Hunting for $\nabla f = 0$ when the objective is monotone and the optimum is on a bound (§10.3).
7. Rounding an LP relaxation instead of solving the integer problem (§14.1).
8. Big-M values orders of magnitude too large (§13.3).
9. Adding integer variables to a problem that is secretly a network flow (§6).
10. Trusting a single reported shadow price when the LP is degenerate (§5.8).
11. Finite-difference gradients on a noisy simulation (§12.1).
12. Reaching for a metaheuristic on a problem with exploitable structure (§17.1).

---

#### Exercises

**21.4.1 [C]** From the list of twelve, identify the ones that are *scaling* problems, the ones that are *modelling* problems, and the ones that are *method-choice* problems. Which category is largest, and what does that suggest about where to spend your learning effort?

**21.4.2 [M]** Diagnose each symptom by naming the most likely item from the twelve, and the one-line check that would confirm it:
(a) a solver reports "line search failed" repeatedly;
(b) a MILP's root relaxation bound is 60 % below the first integer solution found;
(c) a truss optimization returns members of $10^{-9}$ m²;
(d) a shadow price used to justify a capital purchase turns out to be worth nothing in practice;
(e) an assignment model with 500 binaries takes 40 minutes;
(f) a gradient-based optimizer wanders and stalls on a CFD-based objective.

**21.4.3 [C]** Several of the twelve items point back to the same underlying error: *not looking at the answer*. Identify which ones, and state the habit that would catch them all.

**21.4.4 [M]** Write your own personal pre-flight checklist of six items to run before trusting any optimization result, drawing on the whole course. Justify the ordering.


---

## 22. The software landscape

Names change; check current documentation before committing to anything here. But the map is stable:

**Modeling layers** sit between you and the solver, let you write the model in near-mathematical notation, and — critically — let you swap solvers without rewriting. **CVXPY** (Python; convex problems, with convexity *verified* by the §3.3 composition rules — you used this all course); **Pyomo** (Python; general LP/NLP/MILP/MINLP — you used this in Part IV); JuMP (Julia); AMPL and GAMS (dedicated algebraic languages); `gurobipy`/`docplex` (vendor APIs).

**LP / MILP.** Open source: **HiGHS** (the engine behind everything in this course), SCIP (free for academic use), CBC. Commercial: Gurobi, IBM CPLEX, FICO Xpress. The commercial-versus-open gap on hard MILPs is real but has narrowed substantially.

**Convex / conic (QP, SOCP, SDP).** MOSEK (commercial); Clarabel, SCS, ECOS (open) — all reached most easily through CVXPY, which picks one for you.

**Smooth nonlinear, local.** **IPOPT** (interior point; open source; the workhorse for large sparse problems, including PDE-constrained), reached through Pyomo; SNOPT and filterSQP (SQP; good when evaluations are expensive); KNITRO (commercial, multiple algorithms); and `scipy.optimize` (SLSQP, trust-constr, L-BFGS-B, least_squares) for everything small-to-medium — as this course demonstrated throughout.

**Global nonlinear and MINLP.** BARON, ANTIGONE (commercial); Couenne, SCIP (open). Expect modest problem sizes and be prepared to help with tight variable bounds.

**Derivative-free and black-box.** NOMAD (mesh-adaptive direct search); Nelder–Mead for very low dimensions (note: no convergence guarantee); Bayesian optimization via libraries such as BoTorch/Ax or scikit-optimize — or thirty lines of NumPy, as §18.2 showed.

**Automatic differentiation.** JAX and PyTorch (Python); Enzyme/ForwardDiff (Julia); **CasADi** (built specifically for optimization and optimal control, with AD and solver interfaces integrated).

> **One practical recommendation, the same one the whole course has embodied: learn a modeling layer, not a solver API.** Models outlive solvers, licenses expire, and the ability to re-solve the same model with a different solver is the fastest way to diagnose whether a bad answer is your model's fault or the solver's.

---

#### Exercises

**22.1 [C]** Explain what a modeling layer is and give the two concrete benefits the text emphasizes. Why does it recommend learning a modeling layer rather than a solver API?

**22.2 [M]** For each task, name a suitable tool from §22 and justify the choice in one sentence: (a) a 200 000-variable sparse LP; (b) an SOCP arising from robust design; (c) a PDE-constrained NLP with 50 000 variables; (d) a MINLP needing a global optimum, 40 variables; (e) gradients of a 10 000-variable simulation objective; (f) optimal control of a nonlinear vehicle model.

**22.3 [C]** The text says the commercial-versus-open gap on hard MILPs "is real but has narrowed substantially." What would you actually measure to decide whether to buy a commercial licence for your work?

**22.4 [M]** You inherit a model written directly against a vendor's Python API, and the licence is expiring. Describe the migration you would perform and the property of modeling layers that makes it worthwhile.


---

## Checkpoint — Part VI

You should now be able to:

- define dominance, Pareto optimality, and the front; compute a front by weighted sum and by $\varepsilon$-constraint (with normalization), and explain — with the rolling-line picture — exactly which points a weighted sum can never return;
- advise which scalarization to use, and describe what to hand a decision-maker;
- derive the ellipsoidal robust counterpart $\bar a^\top x + \rho\|x\|_2 \le b$, explain why the worst perturbation aligns with $x$, and compute a price of robustness;
- explain *structurally* why nominal optima are fragile (active constraints), and run the four-line stress test on any solution;
- diagnose infeasible / unbounded / nonsense outcomes, including converting "infeasible" into a minimum-violation diagnosis with soft constraints;
- run the eight-step verification list on any optimum, and recite the twelve classic failure modes;
- navigate the software landscape and defend the modeling-layer recommendation.

## Self-test — Part VI

**Q1.** A structural team reports the "optimal" bracket: mass 212 g, chosen by minimizing $0.5\,\hat{f}_{\text{mass}} + 0.5\,\hat{f}_{\text{cost}}$ with both objectives normalized. Marketing wants more options. Name two distinct reasons the team should compute more than this one point, and the method you'd use.

**Q2.** Derive the robust counterpart of $c^\top x \ge r$ (a *revenue floor*, with uncertain prices $c \in \{\bar c + \rho u : \|u\|_2 \le 1\}$). Which direction does the margin go, and why?

**Q3.** Your nominal design's stress constraint is active, and material strength has $\pm 8\%$ scatter. A colleague says: "the solver's feasibility tolerance is $10^{-8}$, we're fine." Respond.

**Q4.** A dispatch model returns "infeasible" at 6 a.m. before the morning meeting. Give your first three moves, in order, with the reason for each.

**Q5.** For each failure mode, name the section that treats it and the one-line fix: (a) MILP crawls, log shows gap stuck at 40%; (b) NLP "converges" to a beam with zero web thickness; (c) reported shadow price differs between two solvers on the same model.

**Answers.**

**A1.** (1) A single weighted point encodes a hidden values judgment ($w = 0.5$) that belongs to the decision-maker, not the analyst — the deliverable is the *front* with the knee marked (§19.3). (2) If the front is nonconvex, the 50/50 weighted sum may be sitting at the rim of a dent, with the genuinely interesting compromises unreachable by *any* weights (§19.1, Figure 19.1 right). Method: sweep the augmented $\varepsilon$-constraint ("minimize mass s.t. cost $\le \varepsilon$" over a grid of $\varepsilon$), which reaches the whole front and answers questions in the language requirements are written in (§19.2).

**A2.** Requiring the floor for every realization means $\min_{\|u\| \le 1} (\bar c + \rho u)^\top x \ge r$. The minimizing $u$ points *against* $x$, giving $\bar c^\top x - \rho\|x\|_2 \ge r$. The margin *subtracts*: for a $\ge$ constraint the worst case is the low side, so robustness demands you clear the floor with room to spare. (General rule: the norm term always pushes toward feasibility's hard side — added to $\le$ left-hand sides, subtracted from $\ge$ ones.)

**A3.** Two unrelated quantities are being conflated. The solver tolerance ($10^{-8}$) governs *numerical* constraint satisfaction *at nominal data* (§9.7). The $\pm 8\%$ scatter is *parameter* uncertainty, roughly $10^7$ times larger — and because the constraint is active, the design sits exactly on the boundary, so material on the weak side of scatter fails it with probability near one-half (the Worked Example 13 geometry, exactly). Required: margin sized to the scatter — a robust counterpart, a chance constraint, or at minimum a design-to-92%-strength rule — then re-solve; the solver tolerance is irrelevant to this decision.

**A4.** (1) Check units/signs on any data that changed overnight (feeds, forecasts) — the most common cause, and thirty seconds to inspect (§21.2). (2) Re-run with the operational constraints softened, minimizing total violation — this converts the status code into "which requirement, short by how much," which is the sentence the meeting needs (§21.2, code demo). (3) If the violation is real, bring the minimum-violation diagnosis *as the deliverable*: "demand exceeds committed capacity by 5 units; options are X or Y." Infeasibility discovered before the meeting is information, not failure (§21.2 point 3).

**A5.** (a) §13.3/§15.2 — weak relaxation; tighten big-Ms to physical capacities, add symmetry breaking, bound all variables; reformulation beats waiting. (b) §21.2/§2.1 — "converged to nonsense"; a missing constraint (here: buckling or a minimum-gauge rule); read the active set, add the physics the optimizer exploited. (c) §5.8 — degeneracy; both solvers are right, the question is malformed at a kink; run the two-sided perturbation test and use the one-sided rate relevant to the actual decision.

---
---

# Closing: seven things to carry away

1. **Formulation dominates.** Time spent on variables, objective, constraints, and scaling repays more than any change of algorithm (§2). The optimizer is a search for loopholes in your model; every absurd answer is information.
2. **Convexity is the dividing line.** It decides whether you get a certified global optimum or a good guess. Prefer convex formulations when you have the choice, and know when you did not (§3).
3. **Get the physics right before the mathematics.** The same words gave $h = 2r$ in one model and a sphere in another, because thickness was constant in one and stress-determined in the other (§10). No algorithm can rescue a wrong objective.
4. **Multipliers are the real deliverable.** Shadow prices tell you which requirement is expensive, which resource to buy, and which specification to renegotiate — and they are the same object in LP, NLP, and MILP (§5.4, §9.4, §10.4). But verify them two-sidedly, because degeneracy makes them non-unique (§5.8).
5. **Certificates come from bounds meeting.** Feasible points bound $f^\star$ from above; dual-feasible multipliers and relaxations bound it from below; optimality is proved when they meet (§9.5, §14.3). Everything in this course that lets you *trust* an answer is that one idea — and everything that cannot give you a lower bound cannot certify anything (§17.5).
6. **Match the method to the structure.** Check for convexity, for network structure, and for a stage decomposition before reaching for general-purpose search (§6, §16, §17.1, §21.1). The two-question map of §1.5 is the whole taxonomy.
7. **Interrogate every answer.** Active set, units, bounds, sensitivities, perturbations, multi-start (§21.3). An optimizer is the most honest design reviewer you will ever have — provided you actually read what it tells you.

---

# Appendix A — Glossary

**Active constraint** — satisfied with equality at the solution; it is shaping the answer (§1.4).
**Acquisition function** — in Bayesian optimization, the rule (e.g. expected improvement) that converts the surrogate's prediction and uncertainty into the next evaluation point (§18).
**Basis / vertex** — a corner of an LP's feasible polyhedron; simplex moves between these (§4).
**Bellman equation** — the recursion $V(n) = \min_m [c(n,m) + V(m)]$ defining a DP value function (§16.1).
**Big-M** — a large constant linking a binary to a continuous variable; should be as small as physically valid (§13.3).
**Branch and bound** — divide-and-conquer for integer programs, using relaxation bounds to prune (§14).
**Chvátal–Gomory cut** — a valid inequality obtained by combining constraints with nonnegative weights and rounding the right-hand side down (§15.1).
**Complementary slackness** — at optimality each inequality is either active or has zero multiplier; and each variable in use has a tight dual constraint (§5.3, §9.3).
**Condition number ($\kappa$)** — ratio of largest to smallest Hessian eigenvalue; how stretched the landscape is, and how slowly first-order methods converge (§0.4, §7.3).
**Constraint qualification** — a regularity condition (e.g. LICQ) needed for the KKT conditions to be necessary (§9.3).
**Convex** — a set with no dents; a function whose chords lie on or above its graph. Guarantees local = global (§3).
**Cutting plane** — an inequality that tightens a relaxation without removing any integer-feasible point (§15).
**Degeneracy** — more active constraints than dimensions at a vertex; causes non-unique dual values (§5.8).
**Dual function** $q(\mu, \lambda)$ — $\inf_x \mathcal{L}$; always concave, always a lower bound on $f^\star$ (§9.5).
**Duality gap** — $f^\star - q^\star \ge 0$; zero for convex problems with a strictly feasible point (Slater); possibly positive otherwise (§9.5).
**Expected improvement** — see acquisition function (§18.2).
**Feasible set** — all points satisfying every constraint (§1.1).
**Gap (MIP)** — distance between incumbent and best bound; a live certificate of near-optimality (§14.3).
**Gaussian process** — a surrogate model returning a prediction and an uncertainty at every point (§18).
**Ideal formulation** — one whose LP relaxation equals the convex hull of the integer points; then LP alone solves the integer problem (§15.2).
**Identifiability** — whether the data can distinguish parameter sets; diagnosed by $\text{cond}(J^\top J)$ and standard errors (§8.3).
**Incumbent** — best feasible solution found so far during a search (§14.3).
**KKT conditions** — first-order necessary conditions for constrained optimality (§9.3); sufficient when the problem is convex.
**LP relaxation** — an integer program with integrality dropped; provides a bound (§13.1).
**Metaheuristic** — general-purpose stochastic search (SA, GA, PSO, tabu) with no optimality guarantee (§17).
**Pareto optimal** — not dominated: no objective improvable without worsening another (§19).
**Price of robustness** — the objective sacrificed by a robust solution relative to the nominal one (§20.1).
**Reduced cost** — net benefit of an unused activity, priced at the shadow prices (§5.5).
**Shadow price / dual variable / Lagrange multiplier** — three names for one object: the rate of change of the optimal value per unit relaxation of a constraint. Not always unique (§5.4, §5.8, §9.4).
**Slack** — the amount by which an inequality is not tight (§1.4).
**Stationary point** — where $\nabla f = 0$: a minimum, maximum, or saddle (§7.1).
**Subgradient** — a generalized slope at a kink; where the value function is non-differentiable, "the shadow price" is a subgradient, one of many (§5.8).
**Surrogate model** — a cheap approximation of an expensive function, used to guide search (§18).
**Total unimodularity** — a matrix property guaranteeing integral LP vertices; makes integrality free (§6.1).
**Trust region** — a neighborhood within which the local model is trusted, resized adaptively (§7.5).
**Value function** — optimal objective as a function of problem data (§5.6) or, in DP, of the state (§16.1); piecewise linear in LP right-hand sides, and the object whose slopes are shadow prices.

---

# Appendix B — Further reading

Each of these covers one part of this course in real depth.

**Convexity, duality, modeling** (§3, §5, §9) — S. Boyd and L. Vandenberghe, *Convex Optimization*, Cambridge University Press, 2004. The definitive treatment; the authors make the full text freely available on Stanford's website, with lecture videos. CVXPY is the book turned into software.

**Numerical algorithms** (§7–§12) — J. Nocedal and S. J. Wright, *Numerical Optimization*, 2nd ed., Springer, 2006. The reference for line searches, trust regions, quasi-Newton, SQP, and interior-point methods; consistently clear about what works and why.

**Linear programming, duality, networks** (§4–§6) — D. Bertsimas and J. N. Tsitsiklis, *Introduction to Linear Optimization*, Athena Scientific, 1997. Rigorous and readable on simplex, duality, sensitivity, degeneracy, and network flows.

**Integer programming** (§13–§15) — L. A. Wolsey, *Integer Programming*, 2nd ed., Wiley, 2020. Compact and authoritative on formulation strength, cutting planes, and branch and bound. For total unimodularity and polyhedral combinatorics in depth: A. Schrijver, *Theory of Linear and Integer Programming*, Wiley, 1986.

**Dynamic programming and optimal control** (§16) — D. P. Bertsekas, *Dynamic Programming and Optimal Control*, Vol. I, 4th ed., Athena Scientific, 2017.

**Robust optimization** (§20) — A. Ben-Tal, L. El Ghaoui, and A. Nemirovski, *Robust Optimization*, Princeton University Press, 2009.

**Bayesian optimization** (§18) — R. Garnett, *Bayesian Optimization*, Cambridge University Press, 2023. Freely available from the author; the modern standard.

**Engineering design optimization** (the whole course, applied) — P. Y. Papalambros and D. J. Wilde, *Principles of Optimal Design*, 3rd ed., Cambridge University Press, 2017 — outstanding on the modeling discipline of §2, §10, §21. J. R. R. A. Martins and A. Ning, *Engineering Design Optimization*, Cambridge University Press, 2021 — freely available online, with a computational orientation close to this course's. J. S. Arora, *Introduction to Optimum Design*, 4th ed., Academic Press, 2016 — a gentler treatment with many mechanical and structural examples.

**On the limits of general-purpose search** (§17.5) — D. H. Wolpert and W. G. Macready, "No Free Lunch Theorems for Optimization," *IEEE Transactions on Evolutionary Computation*, 1(1):67–82, 1997.

---

*End of the course. All thirteen worked examples were solved by hand and verified in Python; every code block in these four installments runs as printed, and every figure was generated by the accompanying scripts. Redo the examples, run the code, break the models on purpose, and read what the optimizer tells you — that habit, more than any theorem, is what this course was for.*
