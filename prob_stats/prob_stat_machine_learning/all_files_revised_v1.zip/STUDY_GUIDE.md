# Study Guide

Three ways through the tutorial, depending on what you need and how much time you have.

- **(a) Full sequential** — ~13 weeks. The intended path. Everything, in order.
- **(b) Fast track** — ~5 weeks. Only the results that ML actually invokes.
- **(c) Reference paths** — days. Minimal chapter subsets for one concrete goal.

All three assume the prerequisites in the Preface: single- and multi-variable calculus,
linear algebra, and a first probability course.

A note on the exercises. Each chapter has Part A (theory), Part B (computational labs) and
Part C (paper-style derivations). Part B is where the numbers in the text get reproduced, and
skipping it is the most common way to finish a chapter feeling like you understood it without
being able to use it. If you are short on time, do fewer chapters properly rather than more
chapters superficially.

---

## (a) Full sequential — 13 weeks

One chapter per week, which is the budget the Preface suggests. The three-part structure is
worth knowing so you can pace yourself: Chapters 1–2 are foundations and are the hardest
*conceptually*; 3–7 are the core toolkit and the hardest *technically*; 8–13 are payoff
chapters where the machinery gets spent.

| Week | Chapter | Focus | Watch out for |
|---|---|---|---|
| 1 | 1. Probability Spaces | $\sigma$-algebras as information; random variables as functions; the pushforward | §1.5 (Vitali) is starred — skim it on a first pass. The Four Failures in §1.1 are the spine of the whole book |
| 2 | 2. Integration & Densities | The three-step construction; MCT/Fatou/DCT; Radon–Nikodym | §2.2 is the most abstract stretch in the book and also the shortest. Push through; §2.3 onward you compute with theorems, not definitions |
| 3 | 3. Transformations & Families | Jacobians; exponential family; sufficiency; flows | §3.5.2 (nonlinear change of variables) rewards a second reading with paper |
| 4 | 4. Inequalities & Concentration | Chernoff; sub-Gaussianity; Hoeffding/Bernstein; VC & Rademacher | Long chapter. Split it: §§4.1–4.5 (tail bounds) then §§4.6–4.11 (generalization). §4.11 is the honest reckoning — don't skip it |
| 5 | 5. Multivariate & Gaussian | Covariance as an operator; conditioning; Schur complements; GPs | §5.4 has the hardest algebra, done three different ways. If one route doesn't land, another will |
| 6 | 6. Conditional Expectation & Martingales | The defining property; $L^2$ projection; martingales; SGD proof | The definition is a *characterization*, not a formula. §6.2.2 (finite case) is the intuition anchor |
| 7 | 7. Convergence & Limit Theorems | Four modes; LLN; characteristic functions; CLT; delta method | Figure 7.1 (which implications hold) is the chapter in one picture |
| 8 | 8. Point Estimation | MLE; Fisher information; Cramér–Rao; EM; overparameterization | Every "regularity condition" here is a DCT hypothesis from Chapter 2 in disguise |
| 9 | 9. Testing & Confidence Sets | Neyman–Pearson; $p$-values; multiple testing; bootstrap | §9.9 (evaluating ML experiments honestly) is the section you will reuse most |
| 10 | 10. Bayesian Inference | Conjugacy; priors; hierarchical models; model comparison | §10.3.2 (a flat prior is not flat) is the one that changes how people think |
| 11 | 11. Information Theory | Entropy; KL; mutual information; $f$-divergences; optimal transport | Longest chapter. Split: §§11.1–11.4 (entropy & MI) then §§11.5–11.10 (divergences & payoffs) |
| 12 | 12. High-Dimensional Probability | Concentration of measure; JL; random matrices | Rebuilds intuition. Do the Part B labs — the numbers are the point |
| 13 | 13. Monte Carlo, VI, Generative Models | Importance sampling; MCMC; ELBO; VAEs; diffusion; calibration | The assembly chapter. Every section cashes a cheque written earlier |

**Checkpoints.** Each chapter's "Before you continue" list is a genuine gate. If you cannot
answer those questions without looking back, the next chapter will be harder than it needs
to be. The Four Failures score card (§1.15, closed in §2.13) is the single best early test
of whether the foundations landed.

**If you fall behind**, the chapters that most repay slow reading are 2, 5 and 6. The ones
that can be read faster without damage are 3 (a reference chapter as much as a narrative
one), 9's §§9.6–9.8, and 12's §12.5.

---

## (b) Fast track — ~5 weeks, ML-relevant results only

For someone who needs the results that appear in ML papers and can accept stated theorems in
place of proofs. This path deliberately drops the measure-theoretic *constructions* while
keeping the measure-theoretic *vocabulary*, because the vocabulary is what makes papers
readable and the constructions are what take the time.

**The rule for this path:** read every Definition, every theorem *statement*, every Worked
Example, and every Common Confusion box. Skip proofs unless the proof is the payoff.

| Week | Read | Skip | Why it stays |
|---|---|---|---|
| 1 | **Ch. 1** §§1.1, 1.3.4, 1.8–1.9, 1.10.3–1.10.4, 1.11–1.13, 1.15 | §1.5, most of §1.4, §1.6.2 | You need: $\sigma$-algebra as information, pushforward, why a generator has no density, filtrations |
| 1 | **Ch. 2** §§2.3, 2.5 (statements), 2.6, 2.7, 2.8, 2.9, 2.10.1 | §2.2 (the construction), §2.11 | Radon–Nikodym, differentiating under $\mathbb{E}$, reparameterization vs REINFORCE, KL/$f$-divergence/Wasserstein, importance sampling |
| 2 | **Ch. 3** §§3.5, 3.6, 3.7, 3.8, 3.9.1, 3.11 | §§3.2–3.4, §3.10 (use as reference) | Jacobians, flows, exponential family, sufficiency, Gumbel-Softmax |
| 2 | **Ch. 4** §§4.1, 4.2, 4.3.1, 4.4, 4.5.1, 4.6.2, 4.7, 4.11 | §§4.8–4.10 (Rademacher/VC/chaining), §4.5.2 | Jensen and the ELBO, Chernoff, sub-Gaussianity, Hoeffding, McDiarmid, and §4.11's honest verdict on deep nets |
| 3 | **Ch. 5** §§5.1, 5.2, 5.3.2 (statement), 5.4, 5.5, 5.7, 5.8 | §5.3.1, §5.6.2 | Conditioning is the single most-used computation in ML; §5.7 derives He/Xavier; §5.8 is GPs |
| 3 | **Ch. 6** §§6.2.2, 6.3, 6.4, 6.5, 6.6.2, 6.7.1, 6.9 | §6.2.1's existence proof, §§6.7.2, 6.8.1–6.8.2 | $\mathbb{E}[Y\mid X]$ as the regression function, tower property, bias–variance, the SGD proof |
| 4 | **Ch. 7** §7.1 (Figure 7.1), §§7.3.3, 7.5.1, 7.6, 7.7, 7.9 | §7.2, §7.4 (except 7.4.3 statement), §7.8 | You need CLT, delta method, Slutsky, and §7.9's honest account of SGD noise |
| 4 | **Ch. 8** §§8.1, 8.3, 8.4, 8.6.2, 8.6.4, 8.8, 8.9, 8.10 | §8.2, §8.5 (statement only), §8.7 | MLE and its asymptotics, Fisher information, MAP-as-regularization, EM, double descent |
| 5 | **Ch. 11** §§11.1.1–11.1.4, 11.2, 11.3, 11.4.1, 11.5, 11.7, 11.8.3, 11.10 | §§11.6, 11.9, 11.8.1–11.8.2 | Cross-entropy = entropy + KL, forward vs reverse KL, $f$-divergence variational forms (GANs), transport, bits/dim |
| 5 | **Ch. 12** §§12.1, 12.2.1–12.2.2, 12.3, 12.4, 12.6 | §12.5 (statements only), §12.7 | Why your geometric intuition is wrong, JL, and what it means for initialization and landscapes |
| 5 | **Ch. 13** all of it | — | This is the destination. Nothing here is optional on any path |

**Dropped entirely:** Chapter 9 (testing) and Chapter 10 (Bayesian inference) as *sequential*
reading. That is a defensible omission only if you never report an experimental comparison
and never touch a prior. If you do either — and almost everyone does — add **§9.9**
(evaluating ML experiments honestly) and **§§10.1, 10.3.2, 10.6** (posteriors, why a flat
prior isn't flat, Bayesian linear regression). Two extra days, and they prevent the two most
common categories of published mistake.

**The honest cost of this path.** You will be able to read papers and use the results. You
will not be able to tell when a stated theorem's hypotheses fail, because the hypotheses live
in the proofs you skipped. That matters most in Chapters 2 and 6, which is why the fast track
keeps their statements in full even while dropping their constructions.

---

## (c) Reference paths

Each path lists the minimal subset and says why each piece is load-bearing. These are
derived from `DEPENDENCY_MAP.md`, so they include prerequisites you might not have guessed.

### "I need to understand diffusion models"

| Read | Why it is required |
|---|---|
| **Ch. 1** §§1.9, 1.9.4, 1.10.3–1.10.4 | Diffusion exists to solve a measure-theoretic problem: the data distribution is supported on a measure-zero set, so it has no density. You cannot state what diffusion fixes without the pushforward and Lebesgue decomposition |
| **Ch. 2** §§2.6, 2.7, 2.8.4 | Radon–Nikodym (what a density is, and why the data law hasn't got one); differentiating under $\mathbb{E}$ (every training gradient); why every $f$-divergence goes blind between singular laws — the reason score-based methods beat divergence-based ones here |
| **Ch. 3** §§3.5, 3.7 | Change of variables with $\log\lvert\det J\rvert$. Needed for the probability-flow ODE and for the flows/diffusion comparison |
| **Ch. 5** §§5.4, 5.5.1–5.5.3 | The entire DDPM derivation is Gaussian conditioning plus the product-of-Gaussians lemma. $q(x_{t-1}\mid x_t,x_0)$ *is* §5.4.3 |
| **Ch. 6** §§6.3, 6.4 | The denoising objective is a conditional expectation, and "predict the noise" is the $L^2$-projection statement. Vincent's identity is the tower property |
| **Ch. 11** §§11.3.1–11.3.3, 11.10.1 | The ELBO's decomposition, forward vs reverse KL, and the rate–distortion reading of the variational bound |
| **Ch. 12** §§12.1.3, 12.2.1 | The soap-bubble geometry. Noise schedules are parameterized the way they are because $\lVert Z\rVert$ concentrates at $\sqrt d$ — a schedule that ignores this puts the model off the typical set |
| **Ch. 13** §§13.1, 13.7, 13.9 | The destination: score matching, DDPM derived rather than quoted, §13.9.3 on how diffusion circumvents measure zero, and the SDE/guidance view |

**Can be skipped:** Chapters 4, 7, 8, 9, 10 in full. You will miss the concentration and
asymptotic story, which matters for evaluating a diffusion model but not for understanding one.

### "I need to understand variational autoencoders"

Chapter 1 §§1.9, 1.11 → Chapter 2 §§2.6.1, 2.7, 2.8.2–2.8.3 (reparameterization, densities,
forward vs reverse KL — the reason VAE posteriors over-concentrate) → Chapter 4 §4.1.4 (the
ELBO is Jensen) → Chapter 5 §5.5 (Gaussian KL in closed form, which is the analytic KL term)
→ Chapter 6 §§6.3, 6.4 → Chapter 8 §8.9 (EM, which is VI with an exact E-step) → Chapter 11
§§11.3.3, 11.10.1 → Chapter 13 §§13.7, 13.8. Read §13.8.2 (the honest failure catalogue)
before you debug anything.

### "I need to write generalization bounds"

Chapter 1 §§1.6.3 (union bound — the source of $\log\lvert\mathcal H\rvert$), 1.8.3 (why an
uncountable supremum may not be measurable, which is exactly the object you are bounding) →
Chapter 2 §§2.10 ($P^{\otimes n}$, the space every bound lives on), 2.10.2 (Tonelli, the tail
formula) → **all of Chapter 4**, this is the chapter → Chapter 6 §6.8.3 (Azuma, for
martingale-based bounds) → Chapter 12 §§12.2, 12.4 (high-dimensional versions). Finish with
§4.11 so you know what the bounds do *not* say about deep nets.

### "I need to report experiments honestly"

Chapter 4 §§4.2.2, 4.5.1 (finite-sample error bars) → Chapter 7 §§7.5.1, 7.6.3, 7.7
(CLT, delta method, Slutsky — where standard errors come from) → **Chapter 9 in full**,
especially §§9.4 ($p$-values), 9.6 (multiple testing and leaderboard decay), 9.8 (bootstrap
and its failures), 9.9 (pairing, cross-validation variance, seed budgets) → Chapter 13
§§13.10.2–13.10.3 (calibration, conformal prediction). This is the shortest path in the guide
and probably the highest expected value.

### "I need to do Bayesian inference in practice"

Chapter 2 §§2.7, 2.9 → Chapter 3 §3.8 (exponential families, hence conjugacy) → Chapter 5
§§5.4, 5.5 → Chapter 6 §§6.3, 6.6 → **Chapter 10 in full** → Chapter 13 §§13.2, 13.4, 13.5,
13.6 (MCMC and, critically, §13.6 on auditing a chain). Chapter 8 §8.8 if you want the
MAP-as-penalty bridge.

---

## Which chapters are reference material

Three chapters work better consulted than read straight through, on any path:

- **Chapter 3 §3.10** — the distribution zoo, organized by "when would I reach for this?"
- **Chapter 5 §5.5** — the Gaussian identities toolkit
- **Chapter 10 §10.2** — the conjugacy table

Bookmark them. Everything else rewards linear reading at least once.
