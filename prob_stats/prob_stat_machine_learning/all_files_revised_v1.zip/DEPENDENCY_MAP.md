# Dependency Map

For each chapter: which **earlier results it actually uses** — not what a reader might
plausibly have read first, but what the text cites and leans on. Compiled from each
chapter's "what you are assumed to bring" primer, cross-checked against its
"results used but not proved" ledger and against every in-text citation.

Load-bearing dependencies are in **bold**: remove them and the chapter's proofs stop working.

---

## Dependency graph

```mermaid
graph TD
    C1["Ch 1<br/>Probability Spaces and Random Variables"]
    C2["Ch 2<br/>Integration Expectation and Densities"]
    C3["Ch 3<br/>Transformations and Distribution Families"]
    C4["Ch 4<br/>Inequalities and Concentration"]
    C5["Ch 5<br/>Multivariate and Gaussian Theory"]
    C6["Ch 6<br/>Conditional Expectation and Martingales"]
    C7["Ch 7<br/>Convergence and Limit Theorems"]
    C8["Ch 8<br/>Point Estimation"]
    C9["Ch 9<br/>Hypothesis Testing and Confidence Sets"]
    C10["Ch 10<br/>Bayesian Inference"]
    C11["Ch 11<br/>Information Theory"]
    C12["Ch 12<br/>High-Dimensional Probability"]
    C13["Ch 13<br/>Monte Carlo Variational Inference and Generative Models"]

    C1 ==> C2
    C1 --> C3
    C1 --> C4
    C1 --> C5
    C1 ==> C6
    C1 --> C7
    C1 --> C8
    C1 --> C9
    C1 --> C10
    C1 --> C11
    C1 --> C12
    C1 --> C13
    C2 ==> C3
    C2 ==> C4
    C2 --> C5
    C2 ==> C6
    C2 --> C7
    C2 --> C8
    C2 --> C9
    C2 --> C10
    C2 ==> C11
    C2 ==> C13
    C3 --> C4
    C3 ==> C5
    C3 --> C7
    C3 --> C8
    C3 --> C9
    C3 --> C10
    C3 --> C11
    C3 --> C13
    C4 --> C5
    C4 --> C6
    C4 ==> C7
    C4 --> C8
    C4 --> C9
    C4 ==> C12
    C4 --> C13
    C5 --> C6
    C5 --> C7
    C5 --> C8
    C5 ==> C10
    C5 --> C11
    C5 --> C12
    C5 --> C13
    C6 --> C7
    C6 ==> C8
    C6 --> C10
    C6 --> C11
    C6 ==> C13
    C7 ==> C8
    C7 --> C9
    C7 --> C12
    C7 --> C13
    C8 ==> C9
    C8 --> C10
    C8 --> C11
    C8 --> C12
    C8 --> C13
    C9 --> C10
    C9 --> C13
    C11 --> C12
    C11 --> C13
    C12 --> C13

    classDef found fill:#e8f0fe,stroke:#4a6fa5,stroke-width:2px;
    classDef core fill:#fff4e6,stroke:#c47f2c,stroke-width:2px;
    classDef applied fill:#eaf7ee,stroke:#3f8f5b,stroke-width:2px;
    class C1,C2 found;
    class C3,C4,C5,C6,C7 core;
    class C8,C9,C10,C11,C12,C13 applied;
```

Thick arrows (`==>`) are the load-bearing edges. Reading them alone gives the tutorial's
spine: 1 → 2 → 3 → 4 → 7 → 8 → 9, with 2 → 6 → 8 and 2 → 13 carrying the
measure-theoretic machinery forward, and 5 feeding both 10 and 12.

---

## Chapter 1 — Probability Spaces and Random Variables

Self-contained. Chapter 1 assumes only calculus, linear algebra and a first
probability course, and states its own outstanding debts (the Kolmogorov extension
theorem, Dynkin's $\pi$–$\lambda$ theorem, the existence of Lebesgue measure) in §1.14.

## Chapter 2 — Integration, Expectation, and Densities

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | measure axioms and continuity from below (the elementary measure properties); closure of measurability under countable sups/infs/limits (the measurability closure properties); uniqueness on a generating $\pi$-system (the $\pi$-system uniqueness theorem); Doob-Dynkin (the Doob–Dynkin lemma); independence (the independence definition); almost surely (the definition of "almost surely") |

*Depends on chapters 1. Nearest prerequisite: Chapter 1.*

## Chapter 3 — Transformations and Distribution Families

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | law as pushforward (the law as a pushforward); support (the support definition); CDF and its properties (the CDF definition and characterization); CDF determines the law (the $\pi$-system uniqueness theorem); Doob-Dynkin (the Doob–Dynkin lemma) |
| **Ch. 2** | the Lebesgue integral; MCT and DCT; differentiation under the integral sign; Fubini-Tonelli; Holder's inequality; absolute continuity and Radon-Nikodym; KL divergence |

*Depends on chapters 1, 2. Nearest prerequisite: Chapter 2.*

## Chapter 4 — Inequalities and Concentration

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | union bound (the union bound) - the source of $\log|\mathcal H|$; independence (the independence definition); the uncountable-supremum measurability warning (SS1.8.3) |
| **Ch. 2** | expectation as a Lebesgue integral; the tail formula; Fubini-Tonelli; product measures and $P^{\otimes n}$; $L^p$ spaces |
| **Ch. 3** | moment generating functions; the exponential family |

*Depends on chapters 1, 2, 3. Nearest prerequisite: Chapter 3.*

## Chapter 5 — Multivariate and Gaussian Theory

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | measurable function / random vector (the random-variable definition); law as pushforward (the law as a pushforward); independence (the independence definition); conditional independence (the conditional-independence definition) |
| **Ch. 2** | densities w.r.t. $\lambda_d$ and Radon-Nikodym; Fubini-Tonelli; dominated convergence |
| **Ch. 3** | change of variables with Jacobians; the exponential family |
| **Ch. 4** | sub-Gaussianity and MGF-based concentration |

*Depends on chapters 1, 2, 3, 4. Nearest prerequisite: Chapter 4.*

## Chapter 6 — Conditional Expectation and Martingales

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | $\sigma$-algebra (the $\sigma$-algebra axioms); elementary conditional probability (elementary conditional probability); $\sigma(X)$ (the definition of $\sigma(X)$); independence (the independence definition); a.s. (the definition of "almost surely"); finite $\sigma$-algebras are partitions (the partition correspondence); $\mathbb{P}(\cdot\mid B)$ is a measure (conditioning gives a probability measure); closure properties (the measurability closure properties); **Doob-Dynkin (the Doob–Dynkin lemma)** - the conceptual key |
| **Ch. 2** | the Lebesgue integral and MCT/Fatou/DCT; **Radon-Nikodym** - gives existence of $\mathbb{E}[X\mid\mathcal G]$; completeness of $L^p$; $L^2$ as a Hilbert space with orthogonal projection; Fubini-Tonelli |
| **Ch. 4** | Jensen's inequality; McDiarmid / bounded differences - **proved here**, discharging Ch. 4's debt |
| **Ch. 5** | the Gaussian conditioning formula (re-derived as a worked instance) |

*Depends on chapters 1, 2, 4, 5. Nearest prerequisite: Chapter 5.*

## Chapter 7 — Convergence and Limit Theorems

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | a.s. (the definition of "almost surely"); monotonicity, union bound, continuity (the elementary measure properties); law and CDF (Defs. 1.16, 1.18); $\pi$-system uniqueness (the $\pi$-system uniqueness theorem); first Borel-Cantelli (Exercise A9) |
| **Ch. 2** | MCT, DCT, Fatou; the tail formula; Fubini-Tonelli |
| **Ch. 3** | Jensen's inequality; the MGF, including its possible non-existence |
| **Ch. 4** | Markov, Chebyshev, sub-Gaussianity, Hoeffding; the uniform-convergence machinery |
| **Ch. 5** | the multivariate Gaussian and its mean/covariance characterization |
| **Ch. 6** | martingales and Azuma's inequality |

*Depends on chapters 1, 2, 3, 4, 5, 6. Nearest prerequisite: Chapter 6.*

## Chapter 8 — Point Estimation

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | law as pushforward (the law as a pushforward); independence (the independence definition); Bayes' rule (the law of total probability and Bayes' rule) - which is all MAP is |
| **Ch. 2** | differentiating under the integral sign (DCT) - the 'regularity conditions' *are* DCT hypotheses; Radon-Nikodym densities against a stated base measure; the ELBO identity - reappears as the whole of EM |
| **Ch. 3** | exponential families, $A(\eta)$ with $\nabla A=\mathbb{E}[T]$, $\nabla^2A=\operatorname{Var}(T)$; sufficiency and Fisher-Neyman factorization |
| **Ch. 4** | Jensen's inequality |
| **Ch. 5** | the Gaussian identities |
| **Ch. 6** | conditional expectation as $L^2$ projection; the tower property; law of total variance - Rao-Blackwell *is* this; bias-variance decomposition |
| **Ch. 7** | SLLN; CLT; Slutsky; the delta method |

*Depends on chapters 1, 2, 3, 4, 5, 6, 7. Nearest prerequisite: Chapter 7.*

## Chapter 9 — Hypothesis Testing and Confidence Sets

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | elementary conditional probability; the CDF definition; the independence definition; the union bound; the law of total probability and Bayes' rule, with its prior/likelihood/evidence/posterior vocabulary; the CDF characterization (jumps are atoms) |
| **Ch. 2** | **Radon-Nikodym** - lets us write $dP_1/dP_0$ with no Lebesgue density; dominated convergence |
| **Ch. 3** | exponential families, natural parameters, sufficiency - why one-sided tests are *optimal* |
| **Ch. 4** | concentration inequalities; the union bound going vacuous once $\sum\mathbb{P}(A_n)\ge1$ |
| **Ch. 7** | CLT; Slutsky; the delta method; Glivenko-Cantelli; DKW |
| **Ch. 8** | asymptotic normality of the MLE; Fisher information; the sandwich variance |

*Depends on chapters 1, 2, 3, 4, 7, 8. Nearest prerequisite: Chapter 8.*

## Chapter 10 — Bayesian Inference

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | conditional probability (elementary conditional probability); conditioning gives a probability measure (conditioning gives a probability measure); law of total probability and Bayes' rule, with the prior/likelihood/evidence/posterior vocabulary (the law of total probability and Bayes' rule); conditional independence (the conditional-independence definition) |
| **Ch. 2** | Radon-Nikodym; 'the density of $\theta$' is meaningless until you name the base measure; KL divergence and the ELBO |
| **Ch. 3** | change of variables with its Jacobian; the exponential-family form and its conjugacy structure |
| **Ch. 5** | Gaussian conditioning; completing the square; Schur complements - Bayesian linear regression is a two-line consequence |
| **Ch. 6** | conditional expectation as $L^2$ projection; the minimizer of a posterior expected loss depends on the loss |
| **Ch. 8** | MAP estimation and penalized likelihood |
| **Ch. 9** | Fisher information, hypothesis testing, confidence intervals |

*Depends on chapters 1, 2, 3, 5, 6, 8, 9. Nearest prerequisite: Chapter 9.*

## Chapter 11 — Information Theory

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | independence as a product law (the independence definition); conditional independence (the conditional-independence definition); Doob-Dynkin (the Doob–Dynkin lemma) |
| **Ch. 2** | **Radon-Nikodym** and absolute continuity; KL divergence against a base measure; $f$-divergences and the singularity result; the Wasserstein distance and its $n^{-1/d}$ caveat; DCT |
| **Ch. 3** | the exponential family - reappears as the maximum-entropy family; change of variables with Jacobians (differential entropy under a diffeomorphism) |
| **Ch. 5** | Gaussian differential entropy and covariance |
| **Ch. 6** | disintegration / regular conditional distributions - for conditional mutual information |
| **Ch. 8** | Fisher information, the zero-mean score, the information equality |

*Depends on chapters 1, 2, 3, 5, 6, 8. Nearest prerequisite: Chapter 8.*

## Chapter 12 — High-Dimensional Probability

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | support (the support definition); union bound (the union bound) |
| **Ch. 4** | **sub-Gaussianity and the MGF characterization**; the Chernoff method; Hoeffding; Bernstein; covering and packing numbers; Rademacher complexity |
| **Ch. 5** | the multivariate Gaussian, rotational invariance when $\Sigma=\sigma^2I$; covariance spectra and whitening |
| **Ch. 7** | the CLT and its honest finite-$n$ limitations |
| **Ch. 8** | the James-Stein estimator |
| **Ch. 11** | mutual information and total variation distance |

*Depends on chapters 1, 4, 5, 7, 8, 11. Nearest prerequisite: Chapter 11.*

## Chapter 13 — Monte Carlo, Variational Inference, and Generative Models

| Uses from | What, specifically |
|---|---|
| **Ch. 1** | the pushforward view of a generative model; measure-zero supports |
| **Ch. 2** | the Lebesgue integral, DCT, and the licence to differentiate under $\mathbb{E}$; the change-of-measure / importance-sampling identity with $P\ll Q$; the reparameterization trick and REINFORCE; the score has mean zero; the ELBO identity; Radon-Nikodym and naming a base measure |
| **Ch. 3** | change of variables with $\det J$; normalizing flows; Gumbel-Softmax |
| **Ch. 4** | concentration inequalities - error bars that do not rely on asymptotics |
| **Ch. 5** | Gaussian identities: conditioning, and the product of two Gaussian densities |
| **Ch. 6** | conditional expectation as $L^2$ projection; martingales; the SGD convergence proof |
| **Ch. 7** | the CLT and Slutsky - together they justify Monte Carlo error bars |
| **Ch. 8** | EM - re-read as VI with an exact E-step; Rao-Blackwellization |
| **Ch. 9** | the bootstrap; coverage |
| **Ch. 11** | KL, the ELBO's rate-distortion reading, mutual information |
| **Ch. 12** | typical-set / soap-bubble geometry - why HMC beats random-walk Metropolis |

*Depends on chapters 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 12. Nearest prerequisite: Chapter 12.*

---

## Debts across chapters

Where one chapter states a result and another proves it — and where a promise was never kept.

| Debt incurred | Discharged | Status |
|---|---|---|
| Ch. 4 states Azuma-Hoeffding (Thm. 4.28) | Ch. 6 proves it (Thm. 6.28) | paid |
| Ch. 4 states McDiarmid (Thm. 4.29) | Ch. 6 proves it (Cor. 6.29) | paid |
| Ch. 1 half-resolves the ReLU law (Failure 2) | Ch. 2 closes it (SS2.7.3) | paid |
| Ch. 1 diagnoses the flat GAN loss (Failure 4) | Ch. 2 closes it (Prop. 2.36) | paid |
| Ch. 1 defers density and $\nabla/\mathbb{E}$ (Failures 1, 3) | Ch. 2 closes both (Thm. 2.26, Thm. 2.21) | paid |
| Ch. 1 defines conditional independence for discrete conditioning only | Ch. 6 gives the general form (SS6.6.3) | paid |
| Ch. 2 mentions Pinsker | Ch. 11 proves it (Thm. 11.38) | paid |
| Ch. 5 previews Bayesian linear regression | Ch. 10 derives it fully (SS10.6) | paid |
| Ch. 8 introduces the ELBO via EM | Ch. 13 generalizes to VI (SS13.7) | paid |
| Ch. 3 flags Halmos-Savage for general sufficiency | never discharged - external reference only | **open** |
| Ch. 2 states Vitali (Thm. 2.19) | never proved; Ch. 7 SS7.1.4 discusses it, exercises prove one direction | **open** |
| Ch. 4 states Efron-Stein (Thm. 4.30) | never proved in the book | **open** |
| Ch. 1 uses the Kolmogorov extension theorem | restated in Ch. 5 (Thm. 5.37), cited not proved in both | **open** |

The four open rows are honest gaps, not errors: each is stated as a debt in the relevant
chapter's ledger with an external reference. Two of them (Vitali, Efron–Stein) previously
carried *false* internal promises — "proved in Ch. 5" and "proof in Ch. 6" — which the
consistency pass corrected.

