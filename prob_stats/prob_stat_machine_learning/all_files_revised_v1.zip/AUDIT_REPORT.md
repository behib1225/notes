# Consistency Audit — Chapters 1–13

Findings first, then the fixes applied. Every count in this report was produced by script
against the source files and re-verified against the corrected files.

**Headline:** the numbering *within* every chapter is flawless, and there are no mathematical
contradictions between chapters. The defects are all in the seams — cross-references, notation,
and four forward-promises that were never kept.

---

## A. Chapter-1 citation drift — systematic, 59 instances, 12 chapters

**Severity: high.** This is one defect, not fifty-nine.

Chapter 1 is at **revision 3**. Chapters 2–13 were drafted against **revision 2**. Revision 3's
own changelog records the cause: it added inverse-transform sampling as new material at §1.10.2.
That inserted three items — Definition 1.21 (quantile function), Proposition 1.22
(inverse-transform sampling), Proposition 1.23 (generator atoms) — and shifted everything after
them by **+3**.

Chapter 1 is the one chapter the conventions permit citing by number, so this corrupts the
book's only sanctioned numeric channel.

| Cited as | What that number actually is now | Correct citation | Count | Chapters |
|---|---|---|---|---|
| Definition 1.21 — "$\sigma$-algebra as information" | Definition 1.21 = quantile function | **Definition 1.24** | 4 | 2, 6, 13 |
| Lemma 1.22 — "Doob–Dynkin" | Proposition 1.22 = inverse-transform sampling | **Lemma 1.25** | 11 | 2, 3, 6, 8, 10, 11 |
| Definition 1.23 — "independence" | Proposition 1.23 = generator has no density | **Definition 1.26** | 31 | 2, 3, 4, 5, 7, 8, 9, 11, 13 |
| Definition 1.24 — "conditional independence" | Definition 1.24 = $\sigma(X)$ | **Definition 1.27** | 13 | 5, 6, 10, 11 |
| Definition 1.25 — "almost surely" | Lemma 1.25 = Doob–Dynkin | **Definition 1.28** | 2 | 2, 7 |

The failure mode is what makes this dangerous: every wrong citation resolves to a **real but
different result**, so nothing renders as a broken link. Chapter 11 §11.4.1 cites
"Definition 1.23" for independence and lands the reader on a proposition about generators
lacking densities.

Note also that the *kinds* line up perfectly under +3 (Lemma→Lemma, Definition→Definition),
which is what confirms the diagnosis rather than merely fitting it.

### A footnote on the cause

Revision 3 added inverse-transform sampling to Chapter 1 — but Chapter 3 §3.6.2 already had it
(Theorem 3.11). So the insertion that broke 59 citations also created a duplication (see D).
Resolving D by cutting Chapter 1's version back to a worked example would prevent this class
of breakage recurring.

---

## B. Broken and dangling cross-references

| # | Location | Defect | Severity |
|---|---|---|---|
| B1 | Ch. 2 §2.1.3 | Tail formula cited as "Proposition 2.48"; 2.48 is Hölder's inequality. Correct: **2.46** | medium |
| B2 | Ch. 2 §2.8.4 | "Jensen's inequality (Proposition 2.54 below)" — **2.54 does not exist**; the chapter ends at 2.53. Correct: **2.52** | medium |
| B3 | Ch. 2 Def. 2.37 | "product $\sigma$-algebra, Definition 2.43" — 2.43 is Tonelli. Correct: **2.41** | medium |
| B4 | Ch. 2 Def. 2.37 | "contains $P\otimes Q$ (Theorem 2.44)" — 2.44 is Fubini; existence of the product measure is **2.42** | medium |
| B5 | Ch. 2 Thm. 2.19 **and** ledger §2.12 | Vitali's theorem labelled "proved in Chapter 5". **Chapter 5 contains zero occurrences of "Vitali."** It is discussed in Ch. 7 §7.1.4, whose own ledger still lists it as an outstanding external debt | **high** |
| B6 | Ch. 4 Thm. 4.30 **and** ledger §4.12 | Efron–Stein labelled "proof in Ch. 6". **Chapter 6 contains zero occurrences of "Efron."** | **high** |
| B7 | Ch. 2 ledger | Pinsker listed as an external debt "used in Chs. 4–5". It is **proved in this book** (Ch. 11, Thm. 11.38), and is never used in Ch. 5 | medium |
| B8 | Ch. 4 ledger | Same: Pinsker routed to Boucheron–Lugosi–Massart rather than to Chapter 11 | medium |

B5 and B6 are the serious ones. Both are **false claims of internal completeness** in a book
whose stated discipline is that §*.12 ledgers tell you exactly what you are taking on faith. A
reader chasing either promise finds nothing, and the ledger that was supposed to protect them
is the thing that misled them.

---

## C. Notation inconsistencies against the canonical table

The canonical table is in Chapter 1's front matter. Deviations, measured on the originals:

| Symbol | Canon | Deviation found | Instances |
|---|---|---|---|
| Indicator | $\mathbb{1}_A$ | $\mathbf{1}$ in Chs. 3, 4, 5, 6, 9, 10, 11, 12, 13 — and **Ch. 12 used both** | 243 |
| Gaussian | $\mathcal{N}(\mu,\Sigma)$ | Three-way split (see correction below) | 281 genuine + 253 cosmetic |
| Probability | $\mathbb{P}$ | Ch. 12 used `\Pr` exclusively | 77 |
| Expectation | $\mathbb{E}$ | Ch. 8 used unbraced `\mathbb E` and bare `E[` throughout | 130 |
| Var / Cov / Corr / supp | — | `\mathrm{}` vs `\operatorname{}` split; **Ch. 4 used both** | 108 |
| Uniform | — | `\mathrm{Unif}` vs `\mathrm{Uniform}` | 20 |
| Total variation | — | Three notations: $\mathrm{TV}(P,Q)$ (Chs. 2, 11), $\lVert P-Q\rVert_{\mathrm{TV}}$ and $d_{\mathrm{TV}}$ (Chs. 4, 9) | — |

### Correction to an earlier claim

An earlier pass of this audit reported that "Chapter 5, the Gaussian chapter, had zero
$\mathcal{N}$." **That was wrong**, and the error is worth recording. Chapter 5 wrote
`\mathcal N(` — correct semantics, no braces — 135 times. A regex searching for
`\mathcal{N}` missed all of them. The accurate picture:

| Form | Chapters | Status |
|---|---|---|
| `\mathcal{N}(` braced | 1, 2, 3, 12 | canonical |
| `\mathcal N(` unbraced | 5, 7, 8 | renders identically — **cosmetic only** (253 instances) |
| bare `N(` | 4, 6, 9, 10, 11, 13 | **genuine deviation** (281 instances) |

So the deviation is real and widespread, but Chapter 5 was never among the offenders. All
three forms are now normalized to `\mathcal{N}(`.

### Symbol collisions

Four overloads, none mathematically ambiguous in context, all capable of misleading a reader:

| Symbol | Meaning A | Meaning B | Where they collide |
|---|---|---|---|
| $\perp$ | independence, $X\perp Y$ (canonical) | mutual singularity, $P\perp Q$ | **Chapter 11 uses both senses**, and its local notation table codified only B |
| $I(\cdot)$ | Fisher information $I(\theta)$ (Ch. 8) | mutual information $I(X;Y)$ (Ch. 11) | **Chapter 11 uses both** — Prop. 11.23 vs. 163 uses of $I(X;Y)$ |
| $N(\cdot)$ | covering number $N(\varepsilon)$ (Ch. 4) | — | benign, but it is why the Gaussian must always be $\mathcal{N}$ |
| $\hat R$ | empirical risk $\hat R_n$ (Ch. 4) | Gelman–Rubin diagnostic (Ch. 13) | different chapters, low risk |

Only two chapters (1 and 11) carry a local notation table. The other eleven introduce symbols
with no table of their own.

---

## D. Duplicated exposition

Concepts developed from scratch in more than one place, with a recommendation for which to keep.

| Concept | Where | Recommendation |
|---|---|---|
| Total variation distance | Ch. 2 Def. 2.31; **Ch. 9 §9.1.2**; Ch. 11 Def. 11.35 + Prop. 11.36 | Keep **Ch. 11** (fullest: three faces plus the testing interpretation). Ch. 2 keeps its short working definition. **Cut Ch. 9's re-derivation to a citation** |
| $f$-divergence blindness on singular pairs | Ch. 2 Prop. 2.36; Ch. 11 Prop. 11.43 — the same theorem twice | Keep **Ch. 2** (it closes Failure 4); Ch. 11 cites it |
| "Two parallel segments" example | Ch. 2 Prop. 2.38; Ch. 11 Prop. 11.44 | Keep **Ch. 11** (sits inside optimal transport); Ch. 2 points forward |
| Importance sampling: unbiasedness, variance, optimal proposal | Ch. 2 Props. 2.39–2.40; Ch. 13 Props. 13.4–13.5 | Keep **Ch. 13**; Ch. 2 retains only the change-of-measure identity |
| Inverse-transform sampling | **Ch. 1 Prop. 1.22** (new in rev. 3); Ch. 3 Thm. 3.11 | Keep **Ch. 3**; reduce Ch. 1's to a worked example. *This duplication is the root cause of finding A* |
| Gibbs' inequality | Ch. 2 Prop. 2.33; Ch. 4 Cor. 4.4; Ch. 11 Thm. 11.17 — three times | Keep **Ch. 11**; Chs. 2 and 4 cite |
| Jensen's inequality | Ch. 2 Prop. 2.52; Ch. 4 Thm. 4.3 | Keep **Ch. 4** (full convexity treatment); Ch. 2 states and cites |
| Markov's inequality | Ch. 2 Prop. 2.15; Ch. 4 Thm. 4.8 | Keep **Ch. 4** |
| Bias–variance decomposition | Ch. 6 Cor. 6.14; Ch. 8 Prop. 8.3 | Keep **Ch. 6** (it is a conditioning identity); Ch. 8 cites |
| MLE in an exponential family = moment matching | Ch. 3 Thm. 3.19; Ch. 8 Prop. 8.10 | Keep **Ch. 3** |
| Gaussian prior → ridge, Laplace → lasso | Ch. 8 Prop. 8.34; Ch. 10 Prop. 10.22 | Keep **Ch. 10** |
| Reparameterization gradient | Ch. 2 Cor. 2.22; Ch. 13 Prop. 13.36 | Keep **Ch. 2** (it is the Failure-3 payoff) |
| ELBO | Ch. 4 §4.1.4; Ch. 8 §8.9.1; Ch. 11 §11.10.1; Ch. 13 §13.7 | **Keep all four** — genuinely different angles (Jensen, EM, rate–distortion, VI). Add a cross-reference box so the reader knows they are the same object |

Well-managed handoffs, for contrast: KL divergence (Ch. 11 Def. 11.16 is explicitly labelled
"recalled from Ch. 2"), Azuma/McDiarmid (Ch. 4 states, Ch. 6 proves, and Ch. 6 §6.8.3 is
titled "the debt to Chapter 4"), and conditional independence (Ch. 1 discrete, Ch. 6 general,
with a forward pointer). These are the model the other rows should follow.

---

## E. Contradictions and drifting definitions

**None found.** This is a real result, not an absence of effort. Specifically checked:

- **TV normalization** — sup form and $\tfrac12\int\lvert p-q\rvert$ agree across Chs. 2, 9, 11.
- **JS normalization** — Ch. 2's $0\le D_{\mathrm{JS}}\le\log 2$ is consistent with Ch. 11's
  $\mathrm{JS}=\tfrac12[\sup_D V+\log 4]$ and with both chapters' $\log 2$ on singular pairs.
- **Pinsker's direction** — Ch. 2's $\mathrm{TV}\le\sqrt{D_{\mathrm{KL}}/2}$ and Ch. 4's
  $D_{\mathrm{KL}}\ge2\mathrm{TV}^2$ are the same inequality.
- **Log-density rescaling** — the $d\log c$ shift agrees between Ch. 2 §2.7.4 and Ch. 11 §11.2.2.
- **Nats vs bits** — both chapters declare units explicitly.
- **Density is not a probability** — Ch. 11 §11.2.1 independently reaffirms Ch. 2's resolution.

The overloads in C are notation collisions, not mathematical disagreements.

---

## F. "Looking ahead" paragraphs that miss

| Location | Problem | Severity |
|---|---|---|
| Ch. 5 → Ch. 6 | Promises conditional expectation "**first** as an orthogonal projection… **then** via Radon–Nikodym." Chapter 6 does the reverse: §6.2 defines it by the defining property (existence via Radon–Nikodym), §6.3 does projection | medium |
| Ch. 11 → Ch. 12 | "We will develop the Chernoff, Hoeffding, Bernstein, and McDiarmid inequalities" — **all four are Chapter 4 material.** Chapter 12 imports them; its own ledger says so | medium |
| Ch. 3 → Ch. 4 | Omits §4.10 (covering numbers, chaining) and §4.11 (why the bounds are vacuous for deep nets) — a substantial fraction of the chapter, including its most important section | low (incomplete, not wrong) |

The other ten looking-ahead paragraphs check out against their successors' actual contents.

---

## G. Numbering integrity within chapters

**Clean.** All thirteen chapters run a single shared counter across Theorems, Propositions,
Lemmas, Corollaries and Definitions, with no gaps, no duplicates, and no out-of-order first
appearances:

| Ch | Range | Ch | Range | Ch | Range |
|---|---|---|---|---|---|
| 1 | 1–28 | 6 | 1–32 | 11 | 1–55 |
| 2 | 1–53 | 7 | 1–45 | 12 | 1–29 |
| 3 | 1–29 | 8 | 1–40 | 13 | 1–54 |
| 4 | 1–51 | 9 | 1–47 | | |
| 5 | 1–40 | 10 | 1–43 | | |

Worked Example, Common Confusion and Figure counters are likewise gap-free.

Two minor auxiliary gaps in the Self-check counters, which are numbered by section:

- **Ch. 1** has no Self-check 1.1 or 1.5. §1.1 is motivational and §1.5 is starred/optional, so
  both omissions are defensible.
- **Ch. 3 had no Self-check 3.3.** Round 1 called this "a genuine oversight." **That was wrong.**
  Self-check 3.4 was explicitly labelled *(covers Sections 3.3–3.4)*, so §3.3 was covered and the
  numbering gap was deliberate. Two of the other ten self-checks carry the same kind of scope
  label, which is how the pattern should have been spotted. Resolved in round 3 by splitting the
  combined check, so the counter is now contiguous and each section has its own — see below.

---

## H. Four Failures score card — verified

**Chapter 2 closes all four.** Every internal citation in the §2.13 score card resolves
correctly and to the right kind of object:

| Failure | Closed by | Citations checked |
|---|---|---|
| 1. Densities exceed 1 | §2.7.4 | Thm. 2.26 (Radon–Nikodym) ✓, Prop. 2.30 (rescaling) ✓ |
| 2. ReLU output is neither discrete nor continuous | §2.7.3 | WE 2.13 ✓, Thm. 2.29 (Lebesgue decomposition) ✓ |
| 3. Swapping $\nabla$ and $\mathbb{E}$ | §2.6 | Thm. 2.21 ✓, Cor. 2.22 ✓, Props. 2.23–2.24 ✓ |
| 4. Constant GAN loss | §2.8.4 | Prop. 2.36 ✓, Prop. 2.38 ✓ |

Chapter 1's §1.15 card correctly reports the starting state (2 open, 1 half-resolved, 1
diagnosed), and Chapter 2's card matches it row for row.

**No later chapter contradicts the resolutions.** Chapter 11 §11.2 independently reaffirms
Failure 1's resolution (including the same $d\log 255$ shift); Ch. 11 §11.7.3 and Ch. 13
§13.9.3 reaffirm Failure 4 with matching constants; Chapter 8's "regularity conditions" are
explicitly identified as the hypothesis set of Theorem 2.21.

One caveat worth adding to the card: Failure 4's resolution rests on Prop. 2.36, which
Chapter 11 silently re-proves as Prop. 11.43 (finding D). The claim "closed by §2.8.4" is true
but no longer uniquely sourced.

---

## Fixes applied

1,142 edits, all logged, all verified. Re-running the full audit against the corrected files
returns **0 remaining reference defects** and confirms counter integrity in all thirteen chapters.

| Fix | Count |
|---|---|
| Chapter-1 citations renumbered (A) | 59 |
| Ch. 2 broken internal references (B1–B4) | 4 |
| Vitali and Efron–Stein false promises corrected (B5, B6) | 4 |
| Pinsker debts discharged to Chapter 11 (B7, B8) | 2 |
| Gaussian normalized to `\mathcal{N}(` | 534 |
| Indicator normalized to `\mathbb{1}` | 243 |
| `\Pr` → `\mathbb{P}` | 77 |
| `\mathbb E` / `\mathbb P` braced | 139 |
| Var/Cov/Corr/supp → `\operatorname{}` | 108 |
| `\mathrm{Uniform}` → `\mathrm{Unif}` | 20 |
| Ch. 5 looking-ahead order corrected (F) | 1 |
| Ch. 11 looking-ahead misattribution corrected (F) | 1 |
| Ch. 11 `\perp` overload flagged in its notation table | 1 |

Two rounds of self-correction happened during the pass and are worth recording. First, the
plural-list form "Definitions 1.3, 1.10, 1.21, 1.23, 1.25" in Chapter 6's primer and the
abbreviated "(Def. 1.23)" in Chapter 11's notation table both evaded the first fix script and
needed a second targeted pass. Second, the Gaussian normalization initially produced 224
instances of `\mathcal \mathcal{N}` by rewriting text that already read `\mathcal N`; these
were detected by a corruption check and repaired. A regex pass over 443,000 words needs its
own audit, which is the same lesson Chapter 1 §1.16 draws about revision 2's "fix" of
revision 1.

### Deliberately not auto-applied

Three items need an authorial decision rather than a script:

1. **The Fisher/mutual-information `I` collision.** Renaming Fisher information to
   $\mathcal{I}(\theta)$ touches 186 sites across five chapters and changes displayed formulas
   (Cramér–Rao, the information equality, the sandwich, the natural gradient). Mechanically
   easy, editorially significant. Recommended, not done.
2. **TV notation unification.** Three forms are in use and the choice between
   $\mathrm{TV}(P,Q)$ and $\lVert P-Q\rVert_{\mathrm{TV}}$ is a matter of taste — the norm form
   reads better in inequalities, the functional form in $f$-divergence contexts. Needs a ruling.
3. **The duplications in D.** Cutting Chapter 9's total-variation derivation, or demoting
   Chapter 1's inverse-transform sampling, removes text a reader may be relying on. These are
   editorial calls with pedagogical consequences.

---

## Round 2 — the deferred items, now applied

All three deferred items are done, plus the process change recommended at the end of round 1.

### Ruling 1 — Fisher information is now $\\mathcal{I}(\\theta)$

108 renames across Chapters 2, 7, 8, 9, 10, 11. $I$ with a semicolon — $I(X;Y)$ — is now
unambiguously mutual information, and the Chapter 11 collision is gone (14 $\\mathcal{I}(\\theta)$
against 83 $I(X;\\cdot)$ in that chapter, visually distinct on sight).

**One wrong rename, caught and reverted.** A pattern for $\\hat I$ (observed information) hit 10
sites — 6 in Chapter 2, 4 in Chapter 11 — and *none of them was Fisher information*. Chapter 2's
$\\hat I_n$ is the importance-sampling estimator of the integral $I := \\mathbb{E}_P[f]$; Chapter 11's
$\\hat I$ is the Donsker–Varadhan critic estimator of mutual information. All 10 reverted. There
was no legitimate $\\hat I$ for Fisher information anywhere in the book, so the pattern was pure
false positive.

### Ruling 2 — total variation is now $\\mathrm{TV}(P,Q)$ everywhere

14 rewrites. $\\lVert P-Q\\rVert_{\\mathrm{TV}}$ and $d_{\\mathrm{TV}}$ are gone. The functional form
won because it is what the defining chapter (2) and the heaviest user (11) already used, and
because it composes better with the $f$-divergence notation around it.

### The Chapter-1 numeric exemption is closed

This was the process change, and it subsumes the third deferred item's motivation. **234
citations** across Chapters 2–13 converted from number to name. Every Chapter-1 result now has
a stable name, listed in the Name column of `THEOREM_INDEX.md`:

| Was | Now |
|---|---|
| Proposition 1.8(2) | the union bound |
| Proposition 1.12 | the law of total probability and Bayes' rule |
| Proposition 1.15 | the measurability closure properties |
| Theorem 1.20 | the $\\pi$-system uniqueness theorem |
| Lemma 1.25 | the Doob–Dynkin lemma |
| Definition 1.26 | the independence definition |
| Definition 1.27 | the conditional-independence definition |
| Definition 1.28 | the definition of "almost surely" |

…and sixteen more. The convention is now documented in Chapter 1's front matter, next to the
notation table, and the eleven prerequisite primers that said "From Chapter 1, **by number**"
now say "by name."

Chapter 1 can be renumbered freely from here. Nothing outside it depends on its numbers.

### Self-corrections in round 2

Four, worth recording because three of them were caused by the fix rather than found by it:

1. **The external-reference guard was too aggressive.** To protect citations like
   "Durrett Thm 1.7.2" I blocked matches followed by a period — which also blocked every
   sentence-final citation. Eight real citations were silently skipped. Guard narrowed from
   "not followed by a period" to "not followed by a period-then-digit."
2. **Plural citation lists survived again.** "Definitions 1.3, 1.10, 1.24, 1.26, 1.28;
   Propositions 1.4, 1.11, 1.15" in Chapter 6's primer needed hand rewriting, as did
   Chapter 7's. This is the second time plural lists have evaded a scripted pass.
3. **The conversion generated its own duplications.** Text reading "Proposition 1.8(2), the
   union bound" became "the union bound of Chapter 1, the union bound." Nine such artifacts
   across Chapters 3, 4, 6, 9, 11 — plus four primers where the substituted name and its
   original parenthetical gloss now said the same thing twice. All rewritten by hand.
4. **A pre-existing oddity, confirmed not mine.** Chapter 10 has an odd `$` count. The
   original upload has the same parity, so it predates this pass. Worth a look, but it is not
   a regression. All thirteen chapters were checked against their originals for `$`-parity;
   all match.

### Final state

| Check | Result |
|---|---|
| Internal reference defects | **0** |
| Cross-chapter numeric citations | **0** (the one remaining match is Kawaguchi's Thm. 2.3, external) |
| Counter integrity, all 13 chapters | contiguous, no gaps or duplicates |
| Notation forms per concept | one each |
| `$`-parity vs. originals | 13/13 match |

Total across three rounds: **1,529 edits.**

---

## Round 3 — Self-check 3.3, and what looking for it turned up

### The finding it was based on was wrong

Asked to add the missing Self-check 3.3, I read §3.3 first and found that Self-check 3.4 was
labelled *(covers Sections 3.3–3.4)*: parts (a) and (b) asked about Theorem 3.4 and the Gamma
convolution, both §3.3 material. The gap was intentional and self-documenting. Round 1's audit
should have caught the label — two other self-checks in the same chapter carry the same kind of
scope annotation.

Resolved by **splitting** rather than inserting: §3.3 now has Self-check 3.3 (four parts on the
one-sided density hypothesis, instance noise and why annealing reinstates the pathology,
convolution as a smoothing operator, and why Gamma's shared-rate requirement is more fragile
than Poisson additivity), and Self-check 3.4 is rescoped to §3.4 alone, keeping its two order-
statistics parts and gaining two new ones. Both answer blocks are written into Appendix A.
Chapter 3's self-check counter now runs 3.1–3.11 with no gap.

Verified across the whole book, format-agnostically (the appendices use three different answer-
label conventions): **13/13 chapters have an answer for every self-check question.**

### A real error found while reading §3.3

Chapter 3 attributed the Central Limit Theorem to **Chapter 5**. The CLT is Chapter 7. The same
sentence pair also credited characteristic functions to Chapter 5, where only the Gaussian's is
computed; the general theory is Chapter 7 §7.4. Both corrected.

This is a defect class round 1 did not audit: **prose claims about other chapters' contents**,
carrying no number and so invisible to a reference checker. The looking-ahead paragraphs were
checked, but not inline assertions like "which Chapter 5 proves." Worth a dedicated pass.

### Nine more artifacts from round 2, now cleaned

Round 2's name-substitution mangled possessive constructions. The original
"Theorem 1.20's uniqueness" became "the $\\pi$-system uniqueness theorem of Chapter 1's
uniqueness" — a double possessive. Nine sites across Chapters 3, 5, 6, 7, 8:

| Original | Round 2 produced | Now reads |
|---|---|---|
| Theorem 1.20's uniqueness | …theorem of Chapter 1's uniqueness | the uniqueness half of the $\\pi$-system uniqueness theorem (Ch. 1) |
| Theorem 1.20's hypotheses | …theorem of Chapter 1's hypotheses | the hypotheses of the $\\pi$-system uniqueness theorem (Ch. 1) |
| Definition 1.24's conditional independence | …definition of Chapter 1's conditional independence | conditional independence in the sense of Chapter 1's definition |
| Proposition 1.19's converse | …characterization of Chapter 1's converse | the converse half of the CDF characterization (Ch. 1) |
| Definition 1.16's notation | …of Chapter 1's notation | in the notation of Chapter 1 |
| Proposition 1.8's union bound | the elementary measure properties of Chapter 1's union bound | Chapter 1's union bound |

Also a sentence that began lowercase because the substitution replaced its first word, and one
doubled-backslash LaTeX artifact introduced by my own authoring of the new self-check. Chapter 3
was diffed against its original on doubled-backslash occurrences: **identical**, so no new LaTeX
artifacts remain.

That is now three consecutive rounds in which a scripted pass over this corpus introduced
defects of its own. The pattern is consistent enough to state as a rule: substitutions into
running prose need a proofread of every changed sentence, not just a count of changed sites.

---

### Still outstanding

The duplications in section D. Cutting Chapter 9's total-variation derivation, demoting
Chapter 1's inverse-transform sampling, or consolidating the four ELBO treatments removes text
a reader may be relying on — those are pedagogical calls, not consistency repairs, and they are
the one category this pass should not make on its own.

Recommended as a further pass: an audit of **prose cross-chapter claims** ("which Chapter 5
proves", "Chapter 8 will show"). The Chapter 3 / CLT error shows this class exists, carries no
number, and is invisible to every check run so far.

---

### Recommended process change

Findings A and B shared one cause: numbers are a brittle inter-chapter interface. Every
violation in round 1 was either inside a single chapter or inside the Chapter-1 numeric
exemption — which broke exactly once, silently, and 59 times over.

**Done in round 2.** The exemption is closed; see above. Chapter 1's results now have stable
names and are cited by name like every other chapter's. The remaining process risk is the one
this pass kept demonstrating: scripted edits over 443,000 words need their own audit, because
three of the four self-corrections in round 2 were caused by the fix rather than found by it.
Plural citation lists in particular have now evaded two separate scripted passes, so any future
renumbering should grep for `Definitions? 1\\.` and `Propositions? 1\\.` by hand.
