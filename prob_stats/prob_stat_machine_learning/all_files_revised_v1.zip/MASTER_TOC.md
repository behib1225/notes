# Master Table of Contents

*Probability and Statistics for Machine Learning and Deep Learning* — thirteen chapters, to subsection depth.
Front matter (Preface, Notation, Roadmap) sits at the head of Chapter 1.

| Ch | Title | Sections |
|---|---|---|
| 1 | Probability Spaces and Random Variables | 17 sections, 26 subsections |
| 2 | Integration, Expectation, and Densities | 14 sections, 22 subsections |
| 3 | Transformations and Distribution Families | 14 sections, 26 subsections |
| 4 | Inequalities and Concentration | 14 sections, 32 subsections |
| 5 | Multivariate and Gaussian Theory | 11 sections, 29 subsections |
| 6 | Conditional Expectation and Martingales | 12 sections, 24 subsections |
| 7 | Convergence and Limit Theorems | 12 sections, 22 subsections |
| 8 | Point Estimation | 13 sections, 31 subsections |
| 9 | Hypothesis Testing and Confidence Sets | 12 sections, 27 subsections |
| 10 | Bayesian Inference | 12 sections, 34 subsections |
| 11 | Information Theory | 13 sections, 33 subsections |
| 12 | High-Dimensional Probability | 11 sections, 19 subsections |
| 13 | Monte Carlo, Variational Inference, and Generative Models | 14 sections, 25 subsections |

---

## Chapter 1 — Probability Spaces and Random Variables

*Front matter:* Preface — who this is for; what differs from a first course;
a word about the measure theory; how the chapter is built; **canonical notation table**; roadmap.

- **1.0** What this chapter is about, and why it takes so long to say
- **1.1** Four things that break without this machinery
- **1.2** The first ingredient: the sample space \Omega
- **1.3** The second ingredient: events, and why we need \sigma-algebras
    - 1.3.1 Events
    - 1.3.2 The naive plan, and where it fails
    - 1.3.3 The definition
    - 1.3.4 The idea that makes it click: a \sigma-algebra is information
    - 1.3.5 On finite sets, a \sigma-algebra is exactly a partition
- **1.4** Building \sigma-algebras: generation and the Borel sets
    - 1.4.1 The Borel \sigma-algebra
- **1.5** ★ Why we cannot use all subsets: the Vitali construction
- **1.6** The third ingredient: measures and probability
    - 1.6.1 Properties you will use constantly
    - 1.6.2 Why *countable* additivity is the right axiom
    - 1.6.3 The union bound is the most important inequality in learning theory
- **1.7** Conditional probability and Bayes' rule
    - 1.7.1 The chain rule and the law of total probability
    - 1.7.2 Base rates: the mistake everyone makes
    - 1.7.3 Independence, previewed
    - 1.7.4 The limitation that forces Chapter 6
- **1.8** Random variables are functions
    - 1.8.1 A labour-saving shortcut
    - 1.8.2 Measurability is almost never the practical obstacle
    - 1.8.3 Where measurability *does* bite: uncountable suprema
- **1.9** Distributions: the pushforward measure
    - 1.9.1 Why the pushforward is the central concept
    - 1.9.2 Support: saying where a distribution lives
    - 1.9.3 Random vectors and joint distributions
    - 1.9.4 Failure 4, set up: generators have zero volume
- **1.10** Cumulative distribution functions, and the ReLU resolved
    - 1.10.1 Failure 2, half-resolved
    - 1.10.2 The quantile function, and how samplers actually work
    - 1.10.3 The general picture: Lebesgue's decomposition
    - 1.10.4 What kind of distribution does a deep generator output?
- **1.11** The information carried by a random variable
- **1.12** Independence
    - 1.12.1 Conditional independence
    - 1.12.2 Where independence enters machine learning
- **1.13** "Almost surely"
- **1.14** Results used but not proved
- **1.15** Chapter summary and score card
- **1.16** Corrections from revision 2
- *Back matter:* Corrections from revision 2; Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 2 — Integration, Expectation, and Densities

- **2.0** What this chapter is for
- **2.1** One integral to replace sums and Riemann integrals
    - 2.1.1 Why the two toolkits from a first course fail
    - 2.1.2 The core idea: slice the range, not the domain
    - 2.1.3 Exactly how the two integrals relate
- **2.2** The three-step construction, and the first convergence theorem
    - 2.2.1 Step (a): simple functions
    - 2.2.2 Step (b): non-negative measurable functions, and monotone convergence
    - 2.2.3 Step (c): signed functions, L^1, and the two ways a mean can fail
- **2.3** Expectation, and the theorem that lets you forget \Omega
- **2.4** Properties of the integral, and why it cannot see null sets
    - 2.4.1 The loud consequence
- **2.5** The convergence theorems
    - 2.5.1 The two escapes, in full detail
- **2.6** Differentiating under the expectation — closing Failure 3
    - 2.6.1 Application (a): the reparameterization trick
    - 2.6.2 Application (b): the score-function / REINFORCE estimator
    - 2.6.3 Application (c): the score has mean zero
- **2.7** Radon–Nikodym — closing Failures 1 and 2
    - 2.7.1 Absolute continuity: "\nu cannot put mass where \mu sees nothing"
    - 2.7.2 What a density actually is
    - 2.7.3 The ReLU output finally gets a density — Failure 2 closed
    - 2.7.4 Densities are rates, hence unbounded — Failure 1 closed
- **2.8** Distances and divergences between measures — closing Failure 4
    - 2.8.1 Total variation
    - 2.8.2 KL divergence, and why +\infty is honest
    - 2.8.3 Forward versus reverse KL
    - 2.8.4 f-divergences, and the general blindness theorem — Failure 4 closed
    - 2.8.5 Wasserstein distance — the fix, and its price
- **2.9** Change of measure and importance sampling
- **2.10** Product measures, Fubini–Tonelli, and the law of a dataset
    - 2.10.1 The measure a dataset is drawn from
    - 2.10.2 Tonelli and Fubini: the two-step dance
- **2.11** L^p spaces, briefly
- **2.12** Results used but not proved
- **2.13** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 3 — Transformations and Distribution Families

- **3.0** From one distribution, all the others
- **3.1** Transformations in one dimension
    - 3.1.1 The CDF method: the reflex that always works
    - 3.1.2 The monotone density formula
- **3.2** Non-injective maps, atoms, and flat regions
    - 3.2.1 Summing over branches
    - 3.2.2 The general recipe: branches, atoms, and flat regions together
- **3.3** Sums of independent random variables: convolution
- **3.4** Order statistics and extremes
- **3.5** The multivariate change of variables
    - 3.5.1 What linear maps do to volume — proved, not asserted
    - 3.5.2 The nonlinear case: linearize, then be honest
    - 3.5.3 The log-determinant as a volume-change rate — and a sign table
- **3.6** Inverse transform sampling and the probability integral transform
    - 3.6.1 The generalized inverse
    - 3.6.2 Sampling anything from Uniform(0,1)
    - 3.6.3 The probability integral transform
- **3.7** Normalizing flows: change of variables as a generative model
    - 3.7.1 The convention box — read this before anything else
    - 3.7.2 Exact log-likelihood
    - 3.7.3 Coupling layers (RealNVP)
    - 3.7.4 Autoregressive flows, and who pays the sequential cost
- **3.8** The exponential family
    - 3.8.1 Definition and first examples
    - 3.8.2 The log-partition function is convex, and its derivatives are moments
    - 3.8.3 Maximum likelihood is moment matching
    - 3.8.4 KL divergence inside the family is a Bregman divergence
- **3.9** Sufficiency: when a statistic loses nothing
    - 3.9.1 The idea, and the discrete case done right
    - 3.9.2 Sufficiency in action
- **3.10** The distribution zoo, organized by use
    - 3.10.1 Location–scale families: half the zoo in one corollary
    - 3.10.2 The reference table
    - 3.10.3 Four deep dives
    - 3.10.4 A mixture worth deriving: Negative Binomial = Gamma-mixed Poisson
- **3.11** The Gumbel-max trick: sampling discrete variables differentiably
    - 3.11.1 The exact identity
    - 3.11.2 The relaxation: Gumbel-Softmax / Concrete
- **3.12** Results used but not proved
- **3.13** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 4 — Inequalities and Concentration

- **4.0** Orientation: from "eventually" to "how much data"
- **4.1** Jensen's inequality
    - 4.1.1 The idea in one picture
    - 4.1.2 Convexity and supporting lines
    - 4.1.3 Jensen's inequality
    - 4.1.4 The ELBO is a lower bound because \log is concave
- **4.2** Markov and Chebyshev: everything from one moment, then two
    - 4.2.1 Markov's inequality
    - 4.2.2 What Chebyshev says about sample means
- **4.3** The Chernoff method: one procedure, four theorems
    - 4.3.1 The template
    - 4.3.2 The procedure in action
- **4.4** Sub-Gaussian and sub-exponential variables
    - 4.4.1 The right level of generality
    - 4.4.2 Bounded implies sub-Gaussian
    - 4.4.3 When Gaussian tails are too much to ask: sub-exponential variables
- **4.5** Hoeffding, Bernstein, Bennett
    - 4.5.1 Hoeffding: boundedness is enough
    - 4.5.2 Bernstein: paying for variance, refunded generously
- **4.6** Bounded differences: concentration beyond sums
    - 4.6.1 Why we need to leave sums behind
    - 4.6.2 McDiarmid's inequality
    - 4.6.3 When McDiarmid fails: Efron–Stein
    - 4.6.4 Sensitivity is stability is privacy
- **4.7** From concentration to generalization: finite classes
    - 4.7.1 The setup, stated once and used for the rest of the chapter
    - 4.7.2 The first generalization bound
- **4.8** Rademacher complexity
    - 4.8.1 Measuring a class by how well it fits noise
    - 4.8.2 Symmetrization
    - 4.8.3 The main bound
    - 4.8.4 Computing Rademacher complexities
- **4.9** VC dimension
    - 4.9.1 Counting labelings instead of hypotheses
    - 4.9.2 Sauer–Shelah: past the VC dimension, growth is polynomial
    - 4.9.3 The VC generalization bound
- **4.10** Covering numbers and chaining
    - 4.10.1 Approximating a class at one scale
    - 4.10.2 Chaining: use all the scales at once
- **4.11** Why these bounds are vacuous for deep nets, and what that means
    - 4.11.1 The accounting, done honestly
    - 4.11.2 Random labels: the experiment that rules out a whole family of explanations
    - 4.11.3 The main candidate repairs, and their status
    - 4.11.4 What to conclude, and what not to
- **4.12** Results used but not proved
- **4.13** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 5 — Multivariate and Gaussian Theory

- **5.0** Orientation: the one distribution you can compute with
- **5.1** Random vectors, mean, and covariance
    - 5.1.1 What a covariance matrix actually is
    - 5.1.2 Positive semidefiniteness, derived rather than asserted
    - 5.1.3 Uncorrelated is not independent
    - 5.1.4 Estimating \mu and \Sigma from data
- **5.2** Whitening, PCA, and the geometry of \Sigma
    - 5.2.1 The spectral picture
    - 5.2.2 PCA in one theorem
    - 5.2.3 Mahalanobis distance and the ellipsoid picture
- **5.3** The multivariate Gaussian: three definitions, one of which is right
    - 5.3.1 Why not start with the density?
    - 5.3.2 The characteristic function, and why it settles everything
    - 5.3.3 The Gaussian as an exponential family
- **5.4** Marginals and conditionals: the heart of the chapter
    - 5.4.1 Marginals are free
    - 5.4.2 Block inversion and the Schur complement
    - 5.4.3 The conditioning theorem, proved three ways
    - 5.4.4 The precision matrix and the Gaussian graphical model
- **5.5** The Gaussian identities toolkit
    - 5.5.1 Sums
    - 5.5.2 Products of Gaussian densities
    - 5.5.3 The linear-Gaussian lemma
    - 5.5.4 Completing the square, as a procedure
    - 5.5.5 Kullback–Leibler divergence between Gaussians
- **5.6** Linear-Gaussian models
    - 5.6.1 Bayesian linear regression (previewed; full treatment in Chapter 10)
    - 5.6.2 The Kalman filter as repeated conditioning
    - 5.6.3 Factor analysis and probabilistic PCA
- **5.7** Payoff: deriving He and Xavier initialization from scratch
    - 5.7.1 The ReLU moments
    - 5.7.2 Forward propagation of variance
    - 5.7.3 The backward pass and Xavier's compromise
- **5.8** Gaussian processes: §5.4 with an infinite index set
    - 5.8.1 What a GP is, and what it is not
    - 5.8.2 Kernels are assumptions
    - 5.8.3 GP regression is Gaussian conditioning. That is all.
    - 5.8.4 The cubic wall, and two asymptotic bridges
- **5.9** Results used but not proved
- **5.10** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 6 — Conditional Expectation and Martingales

- **6.0** What this chapter is for
- **6.1** Why elementary conditioning is not enough
    - 6.1.1 The object ML actually wants
    - 6.1.2 The natural repair, and why it is not enough on its own
    - 6.1.3 The plan
- **6.2** Definition and existence
    - 6.2.1 The definition
    - 6.2.2 The finite case: averaging over atoms
- **6.3** Conditional expectation as projection
    - 6.3.1 The geometry
    - 6.3.2 Regression is projection
    - 6.3.3 Other losses, other summaries
- **6.4** The algebra of conditional expectation
    - 6.4.1 Conditional Jensen and the conditional convergence theorems
- **6.5** Conditional variance, and where bias–variance comes from
    - 6.5.1 The law of total variance
    - 6.5.2 Bias–variance is a conditioning identity
- **6.6** Conditional distributions
    - 6.6.1 What is still missing
    - 6.6.2 Densities: recovering p(y\mid x)=p(x,y)/p(x)
    - 6.6.3 Conditional independence, formalised
    - 6.6.4 The Borel paradox, concretely
- **6.7** Martingales
    - 6.7.1 Information over time
    - 6.7.2 Stopping times and optional stopping
- **6.8** Martingale inequalities and convergence
    - 6.8.1 Maximal inequalities
    - 6.8.2 Convergence
    - 6.8.3 Azuma–Hoeffding, and the debt to Chapter 4
- **6.9** Capstone: a full convergence proof for SGD
    - 6.9.1 The setting and the assumptions
    - 6.9.2 The theorem
    - 6.9.3 What the theorem predicts, and what actually happens
    - 6.9.4 Where the proof breaks — one assumption at a time
- **6.10** Results used but not proved
- **6.11** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 7 — Convergence and Limit Theorems

- **7.0** What "converges" is going to mean
- **7.1** Four modes of convergence
    - 7.1.1 The definitions
    - 7.1.2 The implications that hold
    - 7.1.3 The counterexamples
    - 7.1.4 Two remarks you will need later
- **7.2** Borel–Cantelli and almost sure convergence
    - 7.2.1 The two lemmas
    - 7.2.2 Upgrading in probability to almost sure
- **7.3** Laws of large numbers
    - 7.3.1 The weak law
    - 7.3.2 The strong law
    - 7.3.3 What the SLLN buys machine learning, and what it does not
- **7.4** Characteristic functions
    - 7.4.1 Why complex exponentials
    - 7.4.2 Four computations
    - 7.4.3 Expansions, inversion, uniqueness, continuity
- **7.5** The Central Limit Theorem
    - 7.5.1 The classical theorem and its proof
    - 7.5.2 Non-identically-distributed summands: Lindeberg–Feller
    - 7.5.3 How fast? Berry–Esseen
- **7.6** The multivariate CLT and the delta method
    - 7.6.1 From one dimension to d
    - 7.6.2 Vector-valued convergence, and the notation O_p and o_p
    - 7.6.3 The delta method
    - 7.6.4 When the gradient vanishes
- **7.7** Slutsky and continuous mapping
- **7.8** Empirical processes, briefly
- **7.9** ML payoffs
    - 7.9.1 Why SGD noise is approximately Gaussian
    - 7.9.2 The diffusion approximation, and what it does not say
    - 7.9.3 Bootstrap validity, MLE asymptotics, and the fixed-n caveat
- **7.10** Results used but not proved
- **7.11** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 8 — Point Estimation

- **8.0** What this chapter is for
- **8.1** Estimators and their evaluation
    - 8.1.1 What an estimator is
    - 8.1.2 Bias, variance, mean squared error
    - 8.1.3 Large-sample criteria
- **8.2** The method of moments
    - 8.2.1 The idea in one sentence
    - 8.2.2 Two examples and three failures
    - 8.2.3 Generalized method of moments, in one paragraph
- **8.3** Maximum likelihood
    - 8.3.1 Why the base measure is not a technicality
    - 8.3.2 Invariance, and the exponential-family shortcut
    - 8.3.3 Why maximum likelihood? The KL answer
    - 8.3.4 Where maximum likelihood breaks
- **8.4** Score, Fisher information, and the information equality
    - 8.4.1 The score
    - 8.4.2 Fisher information and the information equality
- **8.5** The Cramér–Rao lower bound
    - 8.5.1 Statement and proof
    - 8.5.2 The bound in action, and where it does not apply
- **8.6** Asymptotic theory of the maximum likelihood estimator
    - 8.6.1 Consistency
    - 8.6.2 Asymptotic normality
    - 8.6.3 Asymptotic efficiency, and the caveats nobody prints
    - 8.6.4 Misspecification: the KL projection and the sandwich
    - 8.6.5 Nuisance parameters and the profile likelihood
- **8.7** Sufficiency and Rao–Blackwell
    - 8.7.1 Conditioning on a sufficient statistic never hurts
    - 8.7.2 Completeness, Lehmann–Scheffé, and the limits of the program
- **8.8** MAP, regularization, and shrinkage
    - 8.8.1 A prior is a penalty
    - 8.8.2 MAP is not reparameterization invariant, and MLE is
    - 8.8.3 Shrinkage and the James–Stein shock
- **8.9** The EM algorithm
    - 8.9.1 EM is the ELBO, twice
    - 8.9.2 EM for a Gaussian mixture
    - 8.9.3 EM and variational inference are the same construction
- **8.10** Bias, variance, and overparameterization — an honest section
    - 8.10.1 The classical picture, and what it actually assumes
    - 8.10.2 The interpolation regime and double descent
    - 8.10.3 What is actually going on, and how much is settled
    - 8.10.4 What to take away
- **8.11** Results used but not proved
- **8.12** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 9 — Hypothesis Testing and Confidence Sets

- **9.0** What this chapter is for
- **9.1** The testing framework
    - 9.1.1 What a test is
    - 9.1.2 Power is bounded by how different the hypotheses are
- **9.2** Neyman–Pearson: the optimal test is a likelihood-ratio threshold
    - 9.2.1 The lemma
    - 9.2.2 Composite alternatives: monotone likelihood ratio and UMP tests
    - 9.2.3 ROC curves: Neyman–Pearson in ML clothing
- **9.3** The three classical tests: likelihood ratio, Wald, and score
    - 9.3.1 Three ways to measure the same distance
    - 9.3.2 What differs at finite n
- **9.4** p-values: what they are, what they are not
    - 9.4.1 Definition and the uniformity theorem
    - 9.4.2 What a p-value is not
    - 9.4.3 p-hacking, forking paths, and optional stopping
- **9.5** Confidence sets, and why they are inverted tests
    - 9.5.1 Definition and the correct interpretation
    - 9.5.2 The duality theorem
    - 9.5.3 Pivots
    - 9.5.4 Four intervals for a proportion, and their real coverage
    - 9.5.5 Simultaneous bands
- **9.6** Multiple testing: the arithmetic of trying many things
    - 9.6.1 Two error rates
    - 9.6.2 Bonferroni and Holm: controlling FWER
    - 9.6.3 Benjamini–Hochberg: controlling FDR
    - 9.6.4 Selection bias in ML: leaderboards, sweeps, and holdout decay
- **9.7** Permutation and randomization tests
    - 9.7.1 Construction and exactness
- **9.8** The bootstrap
    - 9.8.1 The plug-in principle
    - 9.8.2 Four intervals
    - 9.8.3 When the bootstrap fails
- **9.9** Evaluating machine learning experiments honestly
    - 9.9.1 Pair everything you can
    - 9.9.2 Cross-validation variance, and what a fold is not
    - 9.9.3 Seeds, and how many you need
    - 9.9.4 Intervals for the metrics you actually report
- **9.10** Results used but not proved
- **9.11** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 10 — Bayesian Inference

- **10.0** Orientation: what changes when parameters become random variables
- **10.1** The Bayesian setup
    - 10.1.1 One probability space for parameters and data
    - 10.1.2 Sequential updating, and why order does not matter
    - 10.1.3 The posterior predictive is the object you deploy
    - 10.1.4 Frequentist and Bayesian, and where they meet
- **10.2** Conjugacy
    - 10.2.1 What conjugacy is, and why it is not a coincidence
    - 10.2.2 Beta–Bernoulli and Beta–Binomial
    - 10.2.3 Dirichlet–Categorical: where smoothing comes from
    - 10.2.4 Gaussian–Gaussian, known variance
    - 10.2.5 Unknown variance, and where Student-t comes from
    - 10.2.6 Gamma–Poisson and the Negative Binomial
    - 10.2.7 One theorem behind all of them
- **10.3** Choosing priors
    - 10.3.1 Three honest categories
    - 10.3.2 A flat prior is not flat after you change variables
    - 10.3.3 The Jeffreys prior and its invariance
    - 10.3.4 Improper priors: when you can get away with it
    - 10.3.5 Priors in machine learning, honestly
- **10.4** Hierarchical models and shrinkage
    - 10.4.1 The problem partial pooling solves
    - 10.4.2 Shrinkage in the Gaussian case, derived
    - 10.4.3 Empirical Bayes
- **10.5** Model comparison
    - 10.5.1 The evidence is a distribution over datasets
    - 10.5.2 The evidence is prior-sensitive in a way likelihoods are not
    - 10.5.3 The Jeffreys–Lindley paradox
    - 10.5.4 Laplace approximation, BIC, AIC, WAIC, PSIS-LOO
- **10.6** Bayesian linear regression, fully derived
    - 10.6.1 Setup and posterior
    - 10.6.2 The posterior predictive, and what a point estimate cannot say
    - 10.6.3 Evidence: choosing \lambda without a validation set
    - 10.6.4 The \ell_1/Laplace case: sparse MAP, dense posterior
- **10.7** Approximate inference, previewed
    - 10.7.1 The Laplace approximation
    - 10.7.2 What comes next
- **10.8** Bayesian deep learning
    - 10.8.1 The honest situation
    - 10.8.2 Methods, with what is derivable and what is not
- **10.9** Bayesian decision theory
    - 10.9.1 The posterior is not the answer; it is an input
    - 10.9.2 Asymmetric losses give quantiles
    - 10.9.3 Binary decisions: the threshold is a cost ratio, not a probability
- **10.10** Results used but not proved
- **10.11** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 11 — Information Theory

- **11.0** Orientation: what information theory buys a machine learner
- **11.1** Entropy
    - 11.1.1 What we want a measure of uncertainty to do
    - 11.1.2 The axiomatic characterisation
    - 11.1.3 Joint, conditional, chain rule
    - 11.1.4 Maximum entropy and why the exponential family is not arbitrary
- **11.2** Differential entropy, carefully
    - 11.2.1 The definition, and a warning label
    - 11.2.2 Change of variables: where the Jacobian goes
    - 11.2.3 Why h is not the limit of H
    - 11.2.4 What survives: KL and mutual information are invariant
- **11.3** KL divergence revisited
    - 11.3.1 The definition and Gibbs' inequality
    - 11.3.2 Cross-entropy is entropy plus KL, and that is why classifiers use it
    - 11.3.3 Forward versus reverse: the most useful picture in the chapter
    - 11.3.4 Label smoothing, analysed properly
    - 11.3.5 Near a parameter, KL is a quadratic form: the Fisher connection
- **11.4** Mutual information
    - 11.4.1 One definition, three faces
    - 11.4.2 Gaussian and channel computations
    - 11.4.3 The data processing inequality
- **11.5** f-divergences and variational representations
    - 11.5.1 One formula, six familiar divergences
    - 11.5.2 Variational representations: how a divergence becomes an optimisation over critics
    - 11.5.3 The honest part: these estimators are bad in the regime we care about
- **11.6** Total variation, Pinsker, and coupling
- **11.7** Optimal transport
    - 11.7.1 Couplings with a price tag
    - 11.7.2 The one-dimensional closed form
    - 11.7.3 Why f-divergences go blind and W_1 does not
    - 11.7.4 Entropic regularisation in one paragraph
- **11.8** Coding and compression
    - 11.8.1 Kraft's inequality and the source coding theorem
    - 11.8.2 Why blocks work: the asymptotic equipartition property
    - 11.8.3 Codes, wrong codes, and bits per dimension
- **11.9** Fano's inequality and lower bounds on learning
    - 11.9.1 You cannot decode what was never transmitted
    - 11.9.2 From Fano to minimax lower bounds
- **11.10** Consolidated machine learning payoffs
    - 11.10.1 The ELBO is a rate–distortion trade-off
    - 11.10.2 The information bottleneck: what survives scrutiny
    - 11.10.3 Contrastive learning and the \log K ceiling
    - 11.10.4 Why "select the features with highest mutual information" underdelivers
    - 11.10.5 A payoff table
- **11.11** Results used but not proved
- **11.12** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 12 — High-Dimensional Probability

- **12.0** Orientation: your geometric intuition was trained on d\le 3
- **12.1** Four ways intuition fails
    - 12.1.1 Volume flees to the boundary
    - 12.1.2 Random directions are nearly orthogonal
    - 12.1.3 The Gaussian is a soap bubble
    - 12.1.4 The four failures side by side
- **12.2** Concentration of measure
    - 12.2.1 Norm concentration for Gaussians
    - 12.2.2 Lipschitz concentration: the surprising theorem
    - 12.2.3 Isoperimetry, Lévy, Talagrand
- **12.3** Distance concentration and the failure of nearest neighbours
    - 12.3.1 The theorem: contrast dies
    - 12.3.2 The rescue: intrinsic dimension, not ambient dimension
- **12.4** Johnson–Lindenstrauss: compression for free
    - 12.4.1 One vector at a time
    - 12.4.2 All pairs at once
    - 12.4.3 What JL buys in practice
- **12.5** Random matrices
    - 12.5.1 The Marchenko–Pastur law
    - 12.5.2 Operator norm via an \varepsilon-net: a full proof
- **12.6** Consequences for deep learning
    - 12.6.1 Initialization: the whole spectrum, not just the variance
    - 12.6.2 The Hessian spectrum and the saddle story
    - 12.6.3 Why high-dimensional landscapes are more navigable
- **12.7** Covariance estimation in high dimensions
    - 12.7.1 The spiked model: when can PCA see a signal?
    - 12.7.2 Where this bites in machine learning
- **12.8** The double-edged sword
- **12.9** Results used but not proved
- **12.10** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References.

## Chapter 13 — Monte Carlo, Variational Inference, and Generative Models

- **13.0** Orientation: the chapter where the tools get used
- **13.1** Monte Carlo estimation
    - 13.1.1 The estimator and why it works
    - 13.1.2 Relative error and rare events
- **13.2** Importance sampling and variance reduction
    - 13.2.1 The identity, restated with its hypothesis
    - 13.2.2 Diagnostics: effective sample size and \hat k
    - 13.2.3 Self-normalized importance sampling and its bias
    - 13.2.4 Variance reduction
- **13.3** Rejection sampling and its curse
- **13.4** MCMC fundamentals
    - 13.4.1 The idea: give up independence, keep the target
    - 13.4.2 Metropolis–Hastings
    - 13.4.3 Tuning: the step size is everything
    - 13.4.4 Multiple modes: the failure no diagnostic catches
- **13.5** Gradient-based MCMC
    - 13.5.1 Hamiltonian Monte Carlo
    - 13.5.2 Langevin dynamics, ULA, MALA, and SGLD
    - 13.5.3 Is SGD secretly a sampler? (What is theorem, what is analogy)
- **13.6** MCMC diagnostics: how to audit a chain
- **13.7** Variational inference: the ELBO from three directions
    - 13.7.1 Mean field and CAVI
    - 13.7.2 Why VI understates uncertainty
    - 13.7.3 Stochastic and natural-gradient VI
- **13.8** Variational autoencoders
    - 13.8.1 Amortization: one network instead of n optimizations
    - 13.8.2 The honest failure catalogue
- **13.9** Score matching and diffusion models
    - 13.9.1 The score: a way around the normalizing constant
    - 13.9.2 DDPM: deriving the objective, not quoting it
    - 13.9.3 How diffusion circumvents the measure-zero problem
    - 13.9.4 The SDE view, probability flow, and guidance
- **13.10** Uncertainty quantification and calibration
    - 13.10.1 Two kinds of uncertainty, and why the split is model-relative
    - 13.10.2 Calibration
    - 13.10.3 Conformal prediction: a guarantee that needs no model assumptions
- **13.11** Closing: the toolkit assembled
- **13.12** Results used but not proved
- **13.13** Chapter summary
- *Back matter:* Results used but not proved; Chapter summary; Exercises (Parts A/B/C); Appendix A — self-check answers; Solutions; References; Where to go next.

