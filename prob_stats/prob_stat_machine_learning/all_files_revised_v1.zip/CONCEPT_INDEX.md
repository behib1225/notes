# Concept Index

Alphabetical index of concepts, each with the chapter and section where it is developed.
Where a concept appears in more than one place, the **primary** treatment is listed first
and later applications follow; a parenthetical marks where a result is merely *stated*
versus where it is proved.

Cross-reference conventions: numbered results are indexed in `THEOREM_INDEX.md`, symbols in
`NOTATION_INDEX.md`. Section numbers are stable within a chapter; cite concepts across
chapters by name plus chapter, not by number.

311 entries.

---

## A

- **Absolute continuity ($\nu\ll\mu$)** — 2 §2.7.1
- **Almost surely / almost everywhere** — 1 §1.13
- **Amortized inference** — 13 §13.8.1
- **Antithetic variates** — 13 §13.2.4
- **Asymptotic equipartition property (AEP)** — 11 §11.8.2
- **Asymptotic normality of the MLE** — 8 §8.6.2
- **Asymptotic relative efficiency** — 8 §8.6.3
- **Atoms of a $\sigma$-algebra** — 1 §1.3.5
- **Atoms of a distribution** — 1 §1.10; 3 §3.2
- **Autoregressive flows** — 3 §3.7.4
- **Azuma–Hoeffding inequality** — 6 §6.8.3 (stated 4 §4.6)

## B

- **Bai–Yin theorem** — 12 §12.5.1
- **Base rates** — 1 §1.7.2
- **Bayes factor** — 10 §10.5.1
- **Bayes' rule** — 1 §1.7
- **Bayesian decision theory** — 10 §10.9
- **Bayesian deep learning** — 10 §10.8
- **Bayesian linear regression** — 10 §10.6 (previewed 5 §5.6.1)
- **Benjamini–Hochberg procedure (FDR)** — 9 §9.6.3
- **Bennett's inequality** — 4 §4.5.2
- **Bernstein's inequality** — 4 §4.5.2
- **Bernstein–von Mises theorem** — 10 §10.1.4
- **Berry–Esseen theorem** — 7 §7.5.3
- **Bias of an estimator** — 8 §8.1.2
- **Bias–variance decomposition** — 6 §6.5.2 (restated 8 §8.1.2)
- **BIC, AIC, WAIC, PSIS-LOO** — 10 §10.5.4
- **Bits per dimension** — 11 §11.8.3 (origin 2 §2.7.4)
- **Block matrix inversion** — 5 §5.4.2
- **Bonferroni correction** — 9 §9.6.2
- **Bootstrap** — 9 §9.8
- **Bootstrap failure modes** — 9 §9.8.3
- **Borel $\sigma$-algebra** — 1 §1.4.1
- **Borel paradox** — 6 §6.6.4
- **Borel–Cantelli lemmas** — 7 §7.2.1
- **Bounded differences inequality** — see McDiarmid's inequality
- **Bregman divergence** — 3 §3.8.4

## C

- **Calibration; expected calibration error** — 13 §13.10.2
- **Cantor distribution** — 1 §1.10.4
- **Cauchy–Schwarz inequality** — 2 §2.11 (covariance form 5 §5.1)
- **Central limit theorem** — 7 §7.5.1
- **Central limit theorem, multivariate** — 7 §7.6.1
- **Chain rule of entropy** — 11 §11.1.3
- **Chain rule of probability** — 1 §1.7.1
- **Chaining** — 4 §4.10.2
- **Change of measure** — 2 §2.9
- **Change of variables, multivariate** — 3 §3.5
- **Change of variables, one dimension** — 3 §3.1
- **Change-of-variables theorem for expectation (LOTUS)** — 2 §2.3
- **Chapman–Robbins bound** — 8 §8.5.2
- **Characteristic function** — 7 §7.4 (Gaussian 5 §5.3.2)
- **Chebyshev's inequality** — 4 §4.2.2
- **Chernoff method** — 4 §4.3
- **Completeness (of a statistic)** — 8 §8.7.2
- **Completing the square** — 5 §5.5.4
- **Concentration of measure** — 12 §12.2
- **Conditional distributions; regular conditional distributions** — 6 §6.6
- **Conditional expectation as $L^2$ projection** — 6 §6.3
- **Conditional expectation, definition and existence** — 6 §6.2
- **Conditional independence** — 1 §1.12.1 (discrete); 6 §6.6.3 (general)
- **Conditional variance; law of total variance** — 6 §6.5.1
- **Conformal prediction** — 13 §13.10.3
- **Conjugate priors** — 10 §10.2
- **Consistency of an estimator** — 8 §8.1.3, §8.6.1
- **Continuity from below / above** — 1 §1.6.1
- **Continuous mapping theorem** — 7 §7.7
- **Contrastive learning and the $\log K$ ceiling** — 11 §11.10.3
- **Control variates** — 13 §13.2.4
- **Convergence theorems (MCT, Fatou, DCT)** — 2 §2.2.2, §2.5
- **Convergence, four modes of** — 7 §7.1
- **Convexity; supporting lines** — 4 §4.1.2
- **Convolution** — 3 §3.3
- **Countable additivity** — 1 §1.6.2
- **Coupling layers (RealNVP)** — 3 §3.7.3
- **Coupling; maximal coupling** — 11 §11.6
- **Covariance estimation in high dimensions** — 12 §12.7
- **Covariance matrix** — 5 §5.1
- **Covering and packing numbers** — 4 §4.10.1
- **Cramér–Rao lower bound** — 8 §8.5
- **Cramér–Wold device** — 7 §7.6.1
- **Credible interval** — 10 §10.1 (contrasted 9 CC 9.6)
- **Cross-entropy** — 11 §11.3.2 (defined 2 §2.8.2)
- **Cross-validation variance** — 9 §9.9.2
- **Cumulative distribution function (CDF)** — 1 §1.10
- **Curse of dimensionality** — 12 §12.1, §12.8

## D

- **Data processing inequality** — 11 §11.4.3, §11.5.1
- **DDPM objective** — 13 §13.9.2
- **de Finetti representation theorem** — 10 §10.1.2
- **Delta method** — 7 §7.6.3 (second-order §7.6.4)
- **Densities as Radon–Nikodym derivatives** — 2 §2.7.2
- **Detailed balance** — 13 §13.4.1
- **Differential entropy** — 11 §11.2
- **Differentiating under the expectation** — 2 §2.6
- **Diffusion models** — 13 §13.9
- **Dirichlet–Categorical conjugacy** — 10 §10.2.3
- **Dominated convergence theorem** — 2 §2.5
- **Donsker's theorem** — 7 §7.8
- **Donsker–Varadhan representation** — 11 §11.5.2
- **Doob's maximal inequality** — 6 §6.8.1
- **Doob–Dynkin lemma** — 1 §1.11
- **Double descent** — 8 §8.10.2
- **Duality of tests and confidence sets** — 9 §9.5.2
- **Dudley's entropy integral** — 4 §4.10.2
- **Dvoretzky–Kiefer–Wolfowitz inequality** — 7 §7.8

## E

- **Effective sample size** — 13 §13.2.2 (also 2 §2.9)
- **Efron–Stein inequality** — 4 §4.6.3
- **Eight-schools / partial pooling** — 10 §10.4.1
- **ELBO (evidence lower bound)** — 4 §4.1.4; 8 §8.9.1; 11 §11.10.1; 13 §13.7
- **EM algorithm** — 8 §8.9
- **Empirical Bayes** — 10 §10.4.3
- **Empirical measure $\hat P_n$** — 2 §2.3
- **Empirical processes** — 7 §7.8
- **Entropy, axiomatic characterisation** — 11 §11.1.2
- **Ergodic theorem for Markov chains** — 13 §13.4.1
- **Events** — 1 §1.3.1
- **Evidence / marginal likelihood** — 10 §10.5.1
- **Exchangeability** — 10 §10.1.2
- **Expectation as an integral** — 2 §2.3
- **Exponential family** — 3 §3.8

## F

- **$f$-divergence** — 2 §2.8.4; 11 §11.5.1
- **$f$-divergence blindness on singular pairs** — 2 §2.8.4; 11 §11.7.3
- **Factor analysis; probabilistic PCA** — 5 §5.6.3
- **Fano's inequality** — 11 §11.9
- **Fatou's lemma** — 2 §2.5
- **Filtration** — 1 §1.3.4; 6 §6.7.1
- **Fisher information** — 8 §8.4.2
- **Fisher information and local KL** — 11 §11.3.5
- **Fisher–Neyman factorization** — 3 §3.9
- **Forward vs reverse KL** — 2 §2.8.3; 11 §11.3.3
- **Fubini's theorem** — 2 §2.10.2

## G

- **Gamma–Poisson conjugacy** — 10 §10.2.6
- **GAN objective and Jensen–Shannon** — 2 §2.8.4; 11 §11.5.2
- **Gaussian annulus theorem** — 12 §12.2.1
- **Gaussian conditioning theorem** — 5 §5.4.3
- **Gaussian graphical model** — 5 §5.4.4
- **Gaussian identities toolkit** — 5 §5.5
- **Gaussian isoperimetric inequality** — 12 §12.2.3
- **Gaussian Lipschitz concentration** — 12 §12.2.2
- **Gaussian process regression** — 5 §5.8.3
- **Gaussian processes** — 5 §5.8
- **Gaussian, multivariate: three definitions** — 5 §5.3
- **Gaussian–Gaussian conjugacy** — 10 §10.2.4
- **Generalized method of moments** — 8 §8.2.3
- **Gibbs sampling** — 13 §13.4.2
- **Gibbs' inequality** — 2 §2.8.2; 4 §4.1.3; 11 §11.3.1
- **Glivenko–Cantelli theorem** — 7 §7.8
- **Growth function; shattering** — 4 §4.9.1
- **Gumbel-max trick; Gumbel-Softmax** — 3 §3.11

## H

- **Hamiltonian Monte Carlo** — 13 §13.5.1
- **He initialization** — 5 §5.7
- **Hessian spectrum** — 12 §12.6.2
- **Hierarchical models** — 10 §10.4
- **High-dimensional geometry, four failures** — 12 §12.1
- **Hoeffding's inequality** — 4 §4.5.1
- **Hoeffding's lemma** — 4 §4.4.2
- **Holm's step-down procedure** — 9 §9.6.2
- **Hölder's inequality** — 2 §2.11

## I

- **Importance sampling** — 2 §2.9; 13 §13.2
- **Importance-weighted ELBO (IWAE)** — 13 §13.8
- **Improper priors** — 10 §10.3.4
- **Independence** — 1 §1.12
- **Information bottleneck** — 11 §11.10.2
- **Information equality** — 8 §8.4.2
- **Intrinsic dimension** — 12 §12.3.2
- **Inverse transform sampling** — 1 §1.10.2; 3 §3.6

## J

- **James–Stein estimator** — 8 §8.8.3; 10 §10.4.2
- **Jeffreys prior** — 10 §10.3.3
- **Jeffreys–Lindley paradox** — 10 §10.5.3
- **Jensen's inequality** — 4 §4.1 (stated 2 §2.11); conditional 6 §6.4.1
- **Jensen–Shannon divergence** — 2 §2.8.4
- **Johnson–Lindenstrauss lemma** — 12 §12.4

## K

- **Kalman filter** — 5 §5.6.2
- **Kantorovich duality** — 11 §11.7
- **Karlin–Rubin theorem** — 9 §9.2.2
- **Kernels (GP)** — 5 §5.8.2
- **KL divergence** — 2 §2.8.2; 11 §11.3
- **KL divergence between Gaussians** — 5 §5.5.5
- **Kolmogorov extension theorem** — 1 §1.14; 5 §5.8.1
- **Kraft's inequality** — 11 §11.8.1

## L

- **Label smoothing** — 11 §11.3.4
- **Langevin dynamics; ULA, MALA, SGLD** — 13 §13.5.2
- **Laplace approximation** — 10 §10.5.4, §10.7.1
- **Law of large numbers, weak and strong** — 7 §7.3
- **Law of total probability** — 1 §1.7.1
- **Law of total variance** — 6 §6.5.1
- **Le Cam's two-point method** — 11 §11.9.2
- **Lebesgue decomposition** — 1 §1.10.3; 2 §2.7.2
- **Lebesgue integral, construction** — 2 §2.2
- **Lebesgue measure** — 1 §1.6
- **Lehmann–Scheffé theorem** — 8 §8.7.2
- **Likelihood ratio test** — 9 §9.3
- **Lindeberg–Feller CLT** — 7 §7.5.2
- **Linear-Gaussian models** — 5 §5.6
- **Location–scale families** — 3 §3.10.1
- **$L^p$ spaces** — 2 §2.11
- **Lévy continuity theorem** — 7 §7.4.3
- **Lévy's lemma** — 12 §12.2.3

## M

- **Mahalanobis distance** — 5 §5.2.3
- **MAP estimation** — 8 §8.8
- **Marchenko–Pastur law** — 12 §12.5.1
- **Markov chain Monte Carlo** — 13 §13.4
- **Markov's inequality** — 4 §4.2.1 (stated 2 §2.4)
- **Martingale convergence theorem** — 6 §6.8.2
- **Martingales** — 6 §6.7
- **Matrix Bernstein inequality** — 12 §12.5
- **Maximum entropy** — 11 §11.1.4
- **Maximum likelihood estimation** — 8 §8.3
- **McDiarmid's inequality** — 4 §4.6.2 (proved 6 §6.8.3)
- **McNemar's test** — 9 §9.9.1
- **Mean squared error** — 8 §8.1.2
- **Measurability** — 1 §1.8
- **Method of moments** — 8 §8.2
- **Metropolis–Hastings** — 13 §13.4.2
- **Minimax lower bounds** — 11 §11.9.2
- **Minkowski's inequality** — 2 §2.11
- **Misspecification; sandwich variance** — 8 §8.6.4
- **Mixtures** — 3 §3.10.4
- **Monotone convergence theorem** — 2 §2.2.2
- **Monotone likelihood ratio** — 9 §9.2.2
- **Monte Carlo estimation** — 13 §13.1
- **Multiple testing** — 9 §9.6
- **Mutual information** — 11 §11.4

## N

- **Natural gradient** — 11 §11.3.5
- **Nearest neighbours, failure of** — 12 §12.3
- **Negative Binomial as Gamma-mixed Poisson** — 3 §3.10.4
- **Neyman–Pearson lemma** — 9 §9.2.1
- **Normalizing flows** — 3 §3.7
- **Nuisance parameters; profile likelihood** — 8 §8.6.5

## O

- **Operator norm via $\varepsilon$-nets** — 12 §12.5.2
- **Optimal transport** — 11 §11.7 (introduced 2 §2.8.5)
- **Optional stopping theorem** — 6 §6.7.2
- **Order statistics** — 3 §3.4
- **Overparameterization** — 8 §8.10

## P

- **$p$-hacking; forking paths** — 9 §9.4.3
- **$p$-value** — 9 §9.4
- **PCA** — 5 §5.2.2
- **Permutation and randomization tests** — 9 §9.7
- **Pinsker's inequality** — 11 §11.6
- **Pivots** — 9 §9.5.3
- **Positive semidefiniteness** — 5 §5.1.2
- **Posterior predictive distribution** — 10 §10.1.3
- **Power of a test** — 9 §9.1.2
- **Precision matrix** — 5 §5.4.4
- **Priors, choosing** — 10 §10.3
- **Probability integral transform** — 3 §3.6.3
- **Probability space** — 1 §1.6
- **Product measures** — 2 §2.10
- **Pushforward measure** — 1 §1.9

## Q

- **Quantile function** — 1 §1.10.2

## R

- **Rademacher complexity** — 4 §4.8
- **Radon–Nikodym theorem** — 2 §2.7
- **Random matrices** — 12 §12.5
- **Rao–Blackwell theorem** — 8 §8.7.1
- **Rate–distortion** — 11 §11.10.1
- **Regression as projection** — 6 §6.3.2
- **REINFORCE / score-function estimator** — 2 §2.6.2
- **Rejection sampling** — 13 §13.3
- **ReLU output distribution** — 1 §1.1, §1.10; 2 §2.7.3
- **Reparameterization trick** — 2 §2.6.1; 13 §13.8
- **Riemann vs Lebesgue integral** — 2 §2.1.3
- **Robbins–Siegmund lemma** — 6 §6.9
- **ROC curves; AUC** — 9 §9.2.3, §9.9.4

## S

- **Sauer–Shelah lemma** — 4 §4.9.2
- **Schur complement** — 5 §5.4.2
- **Score (w.r.t. parameters)** — 2 §2.6.3; 8 §8.4.1
- **Score matching** — 13 §13.9.1
- **SDE view of diffusion; probability flow** — 13 §13.9.4
- **Selection bias in ML benchmarks** — 9 §9.6.4
- **Self-normalized importance sampling** — 13 §13.2.3
- **Sensitivity, stability, privacy** — 4 §4.6.4
- **SGD convergence proof** — 6 §6.9
- **SGD noise, Gaussianity of** — 7 §7.9.1
- **Shrinkage** — 8 §8.8.3; 10 §10.4.2
- **$\sigma$-algebra** — 1 §1.3
- **$\sigma$-algebra as information** — 1 §1.3.4, §1.11
- **Simultaneous confidence bands** — 9 §9.5.5
- **Singular continuous distributions** — 1 §1.10.3
- **Slutsky's theorem** — 7 §7.7
- **Soap-bubble picture of the Gaussian** — 12 §12.1.3
- **Source coding theorem** — 11 §11.8.1
- **Spectral theorem** — 5 §5.2.1
- **Spiked covariance model; BBP transition** — 12 §12.7.1
- **Stopping times** — 6 §6.7.2
- **Stratification** — 13 §13.2.4
- **Student-$t$, origin of** — 10 §10.2.5; 3 §3.10.3
- **Sub-exponential random variables** — 4 §4.4.3
- **Sub-Gaussian random variables** — 4 §4.4
- **Sufficiency** — 3 §3.9; 8 §8.7
- **Support of a distribution** — 1 §1.9.2
- **Symmetrization** — 4 §4.8.2

## T

- **Tail formula** — 2 §2.10
- **Talagrand's concentration inequalities** — 12 §12.2.3
- **Talagrand's contraction lemma** — 4 §4.8.4
- **Tonelli's theorem** — 2 §2.10.2
- **Total variation distance** — 2 §2.8.1; 9 §9.1.2; 11 §11.6
- **Tower property** — 6 §6.4
- **Typical set** — 11 §11.8.2

## U

- **Uncorrelated vs independent** — 5 §5.1.3
- **Uniform integrability; Vitali** — 2 §2.5.1; 7 §7.1.4
- **Uniformly most powerful tests** — 9 §9.2.2
- **Union bound** — 1 §1.6.3

## V

- **Variational autoencoders** — 13 §13.8
- **Variational inference** — 13 §13.7
- **Variational representations of divergences** — 11 §11.5.2
- **VC dimension** — 4 §4.9
- **Vitali construction (non-measurable set)** — 1 §1.5

## W

- **Wald test** — 9 §9.3
- **Wasserstein distance** — 2 §2.8.5; 11 §11.7
- **Whitening** — 5 §5.2
- **Wigner semicircle law** — 12 §12.5.1
- **Wilks' theorem** — 9 §9.3

## X

- **Xavier/Glorot initialization** — 5 §5.7.3

