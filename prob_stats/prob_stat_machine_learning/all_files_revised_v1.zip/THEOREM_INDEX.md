# Theorem Index

All **402** numbered Theorems, Propositions, Lemmas and Corollaries in the tutorial
(395 carrying a name), with chapter, number and a one-line statement.

Definitions are indexed in `CONCEPT_INDEX.md`; symbols in `NOTATION_INDEX.md`; what each
chapter actually depends on is in `DEPENDENCY_MAP.md`.

## How to cite these

**Within a chapter,** cite by number. Each chapter runs a *single* counter across Theorems,
Propositions, Lemmas, Corollaries **and** Definitions, so `Proposition 2.46` and `Theorem 2.48`
are consecutive items in one sequence, not entries in two parallel lists. Worked Examples,
Common Confusions, Figures and Self-checks each run their own separate counters.

**Across chapters,** cite by **name plus chapter** and never by number — "the Doob–Dynkin
lemma (Chapter 1)", "Pinsker's inequality (Chapter 11)". This applies to Chapter 1 too. An
earlier revision exempted Chapter 1, and the exemption caused 59 silently-wrong citations when
Chapter 1 was renumbered; the exemption is now closed. The **Name** column below is the
citation handle. Where a result is still unnamed, name it when you cite it, or cite the section.

---

## Chapter 1 — Probability Spaces and Random Variables

| No. | Kind | Name | Statement |
|---|---|---|---|
| **1.4** | Proposition | the partition correspondence | Let $\Omega$ be finite. Then $\sigma$-algebras on $\Omega$ correspond exactly to partitions of $\Omega$ |
| **1.8** | Proposition | the elementary measure properties (incl. the union bound) | Let $\mu$ be a measure on $(\Omega,\mathcal{F})$ and $A,B,A_n\in\mathcal{F}$ |
| **1.9** | Proposition | the countable-additivity criterion | Let $\mu:\mathcal{F}\to[0,\infty]$ satisfy $\mu(\emptyset)=0$ and be **finitely** additive |
| **1.11** | Proposition | conditioning gives a probability measure | Fix $B$ with $\mathbb{P}(B)>0$ and define $\mathbb{P}_B(A) := \mathbb{P}(A\mid B)$ |
| **1.12** | Proposition | the law of total probability and Bayes' rule | Let $\{B_1,B_2,\ldots\}$ be a finite or countable partition of $\Omega$ into events with $\mathbb{P}(B_i)>0$ |
| **1.14** | Lemma | the generator criterion for measurability | Suppose $\mathcal{S} = \sigma(\mathcal{C})$ and $X^{-1}(C)\in\mathcal{F}$ for every $C\in\mathcal{C}$ |
| **1.15** | Proposition | the measurability closure properties | Let $f,g,f_1,f_2,\ldots$ be measurable real-valued functions on $(\Omega,\mathcal{F})$ |
| **1.19** | Proposition | the CDF characterization | $F_X$ is non-decreasing and right-continuous, with $\lim_{a\to-\infty}F_X(a) = 0$ and $\lim_{a\to\infty}F_X(a) = 1$ |
| **1.20** | Theorem | the $\pi$-system uniqueness theorem | Let $\mathcal{C}$ be a collection of subsets of $\Omega$ closed under finite intersections (a **$\pi$-system**), and let $\mu,\nu$ be probability measures on $\sigma(\mathcal{C})$ |
| **1.22** | Proposition | inverse-transform sampling | Let $U\sim\mathrm{Unif}(0,1)$ and $X := F^{-1}(U)$ |
| **1.23** | Proposition | the no-density result for low-dimensional generators | Let $P_\theta = (G_\theta)_\#\nu$ with $G_\theta:\mathbb{R}^k\to\mathbb{R}^d$ of class $C^1$ and $k<d$ |
| **1.25** | Lemma | the Doob–Dynkin lemma | $Y$ is $\sigma(X)$-measurable $\iff$ $Y = g(X)$ for some measurable $g:\mathbb{R}\to\mathbb{R}$ |

## Chapter 2 — Integration, Expectation, and Densities

| No. | Kind | Name | Statement |
|---|---|---|---|
| **2.1** | Theorem | Riemann versus Lebesgue | Let $f:[a,b]\to\mathbb{R}$ be bounded |
| **2.4** | Lemma | the simple integral is well defined, additive, monotone | Let $s,t\ge0$ be simple and $c\ge0$ |
| **2.6** | Lemma | simple approximation | Let $f:\Omega\to[0,\infty]$ be measurable and define $$s_n := \min\Big(\frac{\lfloor 2^n f\rfloor}{2^n},\,n\Big).$$ Then each $s_n$ is simple, $0\le s_n\le s_{n+1}\le f$, and $s_n(\omega)\to f(\omega)$ for e… |
| **2.7** | Proposition | consistency and monotonicity | (i) If $f$ is simple and non-negative, Definitions 2.3 and 2.5 agree |
| **2.8** | Theorem | monotone convergence, MCT | Let $f_n:\Omega\to[0,\infty]$ be measurable with $f_n\le f_{n+1}$ pointwise, and let $f := \lim_n f_n$ (which exists pointwise in $[0,\infty]$ and is measurable by the measurability closure properties of Cha… |
| **2.11** | Theorem | change of variables / LOTUS | Let $X:\Omega\to\mathbb{R}^d$ be a random vector with law $P_X = X_\#\mathbb{P}$ (the law of $X$ as a pushforward, Ch |
| **2.12** | Corollary | the formulas from your first course, and Monte Carlo | Let $g$ be Borel with $g\ge0$ or $g\in L^1(P_X)$ |
| **2.13** | Proposition | linearity and monotonicity | 1. If $f,g\ge0$ are measurable and $c\ge0$, then $\int(f+g)\,d\mu = \int f\,d\mu+\int g\,d\mu$ and $\int cf\,d\mu = c\int f\,d\mu$ |
| **2.14** | Proposition | a.e. blindness | Let $f,g$ be measurable. 1. If $f = g$ $\mu$-a.e |
| **2.15** | Proposition | Markov's inequality | If $f\ge0$ is measurable and $t>0$, then $\mu(\{f\ge t\})\le\frac1t\int f\,d\mu$ |
| **2.16** | Theorem | Fatou's lemma | For any measurable $f_n:\Omega\to[0,\infty]$, $$\int_\Omega\liminf_n f_n\,d\mu\ \le\ \liminf_n\int_\Omega f_n\,d\mu .$$ No monotonicity, no domination, no convergence required |
| **2.17** | Theorem | dominated convergence, DCT | Let $f_n$ be measurable with $f_n\to f$ pointwise $\mu$-a.e., and suppose there is $g\in L^1(\mu)$ with $|f_n|\le g$ $\mu$-a.e |
| **2.18** | Corollary | bounded convergence | On a space of **finite total measure** — in particular a probability space — if $X_n\to X$ a.e |
| **2.19** | Theorem | Vitali convergence theorem; stated here, discussed again in Chapter 7 (§7.1.4 | not proved in this book). Let $\mu$ be a finite measure, $f_n\in L^1(\mu)$, and $f_n\to f$ in measure (in particular, if a.e.) |
| **2.20** | Corollary | interchanging sums and integrals | Let $f_n\ge0$ be measurable. Then $\int\sum_{n=1}^\infty f_n\,d\mu = \sum_{n=1}^\infty\int f_n\,d\mu$ (both sides possibly $+\infty$) |
| **2.21** | Theorem | differentiation under the integral sign | Let $(\mathcal{X},\mathcal{G},\mu)$ be a measure space, $\Theta\subseteq\mathbb{R}$ an open interval, and $h:\Theta\times\mathcal{X}\to\mathbb{R}$ satisfying: 1 |
| **2.22** | Corollary | reparameterization gradient | Suppose $P_\theta = (T_\theta)_\#Q$ for a fixed measure $Q$ on a space $\mathcal{E}$ and measurable maps $T_\theta:\mathcal{E}\to\mathbb{R}^d$ — that is, $x = T_\theta(\varepsilon)$ with $\varepsilon\sim Q$… |
| **2.23** | Proposition | score-function estimator | Let $\{P_\theta\}$ have densities $p_\theta = dP_\theta/d\mu$ with respect to a fixed base measure $\mu$ (§2.7), and $f\in L^1(P_\theta)$ |
| **2.24** | Proposition | zero-mean score | Let $p_\theta = dP_\theta/d\mu$ with $\theta$-free support $S$, suppose $\theta\mapsto p_\theta(x)$ is differentiable for a.e |
| **2.26** | Theorem | Radon–Nikodym | Let $\mu$ be $\sigma$-finite on $(\Omega,\mathcal{F})$ — meaning $\Omega = \bigcup_n\Omega_n$ with $\mu(\Omega_n)<\infty$ — and let $\nu$ be a $\sigma$-finite measure with $\nu\ll\mu$ |
| **2.28** | Proposition | the calculus of densities | All measures $\sigma$-finite on $(\Omega,\mathcal{F})$ |
| **2.29** | Theorem | Lebesgue decomposition; stated | Let $\mu,\nu$ be $\sigma$-finite on $(\Omega,\mathcal{F})$ |
| **2.30** | Proposition | rescaling shifts log-densities by $d\log c$ | Let $X$ be a random vector in $\mathbb{R}^d$ with density $p_X$ w.r.t |
| **2.33** | Proposition | Gibbs' inequality | $D_{\mathrm{KL}}(P\|Q)\ge0$, with equality iff $P = Q$ |
| **2.36** | Proposition | mutual singularity pins every $f$-divergence | If $P\perp Q$, then $$D_f(P\|Q) = f(0)+f'(\infty),$$ a constant depending only on $f$, not on $P$, $Q$, or how far apart they sit |
| **2.38** | Proposition | two parallel segments | Let $P$ be uniform on $S_0 = \{(t,0): t\in[0,1]\}$ and $Q_\alpha$ uniform on $S_\alpha = \{(t,\alpha): t\in[0,1]\}$, $\alpha\ne0$ |
| **2.39** | Proposition | change of measure | Let $P\ll Q$ with $w := dP/dQ$, and let $f$ be measurable with $f\ge0$ or $f\in L^1(P)$ |
| **2.40** | Proposition | variance and the optimal proposal | In the setting of Proposition 2.39, with $I := \mathbb{E}_P[f]$, $$\operatorname{Var}_Q(\hat I_n) = \frac1n\big(\mathbb{E}_Q[w^2f^2]-I^2\big) = \frac1n\big(\mathbb{E}_P[wf^2]-I^2\big),$$ finite **iff** $\mat… |
| **2.42** | Theorem | existence and uniqueness of the product measure | If $\mu_1,\mu_2$ are $\sigma$-finite, a product measure exists and is unique |
| **2.43** | Theorem | Tonelli; stated | Let $\mu_1,\mu_2$ be $\sigma$-finite and $f:\Omega_1\times\Omega_2\to[0,\infty]$ be $\mathcal{F}_1\otimes\mathcal{F}_2$-measurable |
| **2.44** | Theorem | Fubini | Let $\mu_1,\mu_2$ be $\sigma$-finite and $f\in L^1(\mu_1\otimes\mu_2)$ |
| **2.45** | Proposition | independence *is* a product law | Let $X,Y$ be random vectors on a common probability space, valued in $\mathbb{R}^{d_1},\mathbb{R}^{d_2}$ |
| **2.46** | Proposition | the tail formula | If $X\ge0$ is a random variable, then $$\mathbb{E}[X] = \int_0^\infty\mathbb{P}(X>t)\,dt .$$ *Proof.* Let $E := \{(\omega,t)\in\Omega\times(0,\infty): t<X(\omega)\}$, in $\mathcal{F}\otimes\mathcal{B}$ becau… |
| **2.48** | Theorem | Hölder's inequality; stated, proof in §2.12 | Let $1\le p,q\le\infty$ with $\frac1p+\frac1q = 1$ |
| **2.49** | Theorem | Minkowski's inequality | For $1\le p\le\infty$ and $f,g\in L^p(\mu)$: $f+g\in L^p(\mu)$ and $\|f+g\|_p\le\|f\|_p+\|g\|_p$ |
| **2.50** | Proposition | Cauchy–Schwarz | If $X,Y\in L^2(\mu)$ then $XY\in L^1(\mu)$ and $$\Big|\int XY\,d\mu\Big|\le\|X\|_2\|Y\|_2,$$ with equality iff $X$ and $Y$ are proportional a.e |
| **2.51** | Theorem | $L^2$ is a Hilbert space | On a probability space, $\langle X,Y\rangle := \mathbb{E}[XY]$ is an inner product on $L^2(\mathbb{P})$ inducing $\|\cdot\|_2$, and $L^2(\mathbb{P})$ is **complete**: every Cauchy sequence converges in $\|\c… |
| **2.52** | Proposition | Jensen's inequality | Let $X\in L^1(\mathbb{P})$ and $\psi:\mathbb{R}\to\mathbb{R}$ be convex |
| **2.53** | Proposition | norms nest on probability spaces | If $\mathbb{P}$ is a probability measure and $1\le p\le q$, then $\|X\|_p\le\|X\|_q$; in particular $\mathbb{E}|X|\le\sqrt{\mathbb{E}[X^2]}$, so $L^2(\mathbb{P})\subseteq L^1(\mathbb{P})$ |

## Chapter 3 — Transformations and Distribution Families

| No. | Kind | Name | Statement |
|---|---|---|---|
| **3.1** | Theorem | change of variables, one dimension, monotone case | Let $I \subseteq \mathbb{R}$ be an open interval, let $X$ take values in $I$ with density $p_X$ with respect to Lebesgue measure, and let $g : I \to J$ be continuously differentiable and strictly monotone wi… |
| **3.2** | Theorem | change of variables with branches | Let $X$ have density $p_X$ with respect to Lebesgue measure on $\mathbb{R}$ |
| **3.4** | Theorem | density of a sum | Let $X \perp Y$. If $X$ has density $p_X$ with respect to Lebesgue measure, then $X + Y$ has a Lebesgue density regardless of what $P_Y$ is: $$p_{X+Y}(s) \;=\; \int p_X(s - y)\; dP_Y(y).$$ In particular, if… |
| **3.5** | Proposition | order statistics | Let $X_1, \dots, X_n$ be i.i.d |
| **3.6** | Lemma | Lebesgue measure under linear maps | Let $T : \mathbb{R}^d \to \mathbb{R}^d$ be linear and invertible |
| **3.7** | Theorem | affine change of variables | Let $X$ have density $p_X$ on $\mathbb{R}^d$ (w.r.t |
| **3.8** | Theorem | change of variables, $C^1$ diffeomorphisms — stated; proof deferred | Let $U, V \subseteq \mathbb{R}^d$ be open and $g : U \to V$ a bijection, continuously differentiable with $\det J_g(x) \ne 0$ for all $x \in U$ (so $g^{-1}$ is also $C^1$, by the inverse function theorem) |
| **3.10** | Lemma | the switching relation | For all $u \in (0,1)$ and $x \in \mathbb{R}$: $$F^{-1}(u) \le x \iff u \le F(x).$$ *Proof.* ($\Leftarrow$) If $u \le F(x)$, then $x$ belongs to $\{x' : F(x') \ge u\}$, so the infimum $F^{-1}(u)$ is $\le x$ |
| **3.11** | Theorem | inverse transform sampling | Let $F$ be any CDF and $U \sim \mathrm{Unif}(0,1)$ |
| **3.12** | Corollary | the converse of the CDF characterization of Chapter 1, at last | Every function $F : \mathbb{R} \to [0,1]$ that is nondecreasing, right-continuous, with $\lim_{x\to-\infty}F = 0$ and $\lim_{x\to+\infty}F = 1$, is the CDF of some random variable on some probability space |
| **3.13** | Theorem | probability integral transform | If $X$ has a **continuous** CDF $F$, then $F(X) \sim \mathrm{Unif}(0,1)$ |
| **3.14** | Proposition | flow log-likelihood and composition | Let $f_\theta : \mathbb{R}^d \to \mathbb{R}^d$ be a $C^1$ diffeomorphism and fix a base density $p_Z$ (typically $\mathcal{N}(0, I_d)$) |
| **3.16** | Proposition | convexity | $\Xi$ is a convex subset of $\mathbb{R}^m$, and $A$ is convex on $\Xi$ |
| **3.17** | Theorem | derivatives of $A$ are moments of $T$ | Let $\eta$ lie in the interior of $\Xi$ |
| **3.19** | Theorem | MLE in an exponential family | Let $x_1, \dots, x_n$ be i.i.d |
| **3.20** | Proposition | KL = Bregman divergence of $A$ | For $\eta_1, \eta_2 \in \mathrm{int}\,\Xi$ in a common exponential family, $$D_{\mathrm{KL}}\big(p_{\eta_1}\,\|\,p_{\eta_2}\big) = A(\eta_2) - A(\eta_1) - \big\langle \eta_2 - \eta_1,\; \nabla A(\eta_1)\big\… |
| **3.22** | Theorem | Fisher–Neyman factorization, discrete case | In the setting above, $T$ is sufficient **iff** there exist functions $g_\theta \ge 0$ (depending on $\theta$ and on the value of $T$ only) and $h \ge 0$ (depending on $x$ only) such that $$p_\theta(x) = g_\… |
| **3.25** | Proposition | exponential families compress; minimally so when minimal | Let $x_1,\dots,x_n$ be i.i.d. from an exponential family (Definition 3.15) |
| **3.27** | Corollary | location–scale densities | $X = \mu + \sigma Z$ has density $$p_X(x) = \frac{1}{\sigma}\,p_Z\!\left(\frac{x - \mu}{\sigma}\right).$$ *Proof.* Theorem 3.1 (equivalently Worked Example 3.1) with the affine map $g(z) = \mu + \sigma z$, w… |
| **3.28** | Theorem | Gumbel-max trick | Let $\pi \in \Delta^{K-1}$ with all $\pi_i > 0$, and let $G_1, \dots, G_K$ be i.i.d |
| **3.29** | Proposition | max-stability, and where logsumexp comes from | For independent $G_i \sim$ standard Gumbel and any $\eta \in \mathbb{R}^K$: $$\max_i\,(\eta_i + G_i) \;\sim\; \mathrm{Gumbel}\Big(\mathrm{location} = \mathrm{logsumexp}(\eta) = \log\sum_i e^{\eta_i}\Big),$$… |

## Chapter 4 — Inequalities and Concentration

| No. | Kind | Name | Statement |
|---|---|---|---|
| **4.2** | Lemma | Supporting line | Let $\varphi$ be convex on an interval $I$ and let $x_0$ be a point in the interior of $I$ |
| **4.3** | Theorem | Jensen | Let $X$ be a random variable taking values in an interval $I$ with $\mathbb{E}\lvert X\rvert<\infty$, and let $\varphi:I\to\mathbb{R}$ be convex |
| **4.4** | Corollary | Gibbs' inequality: non-negativity of KL | Let $P,Q$ be probability measures on a common space with $P\ll Q$, and let $p=\frac{dP}{dQ}$ be the Radon–Nikodym derivative (Ch |
| **4.5** | Corollary | Weighted AM–GM | For $x_1,\dots,x_m>0$ and weights $\pi_i\ge0$ with $\sum_i\pi_i=1$, $$\prod_i x_i^{\pi_i}\ \le\ \sum_i \pi_i x_i .$$ *Proof.* Apply Theorem 4.3 to the concave function $\log$ and the random variable $X$ with… |
| **4.6** | Corollary | Lyapunov's moment inequality | For $0<p\le q$ and any random variable $X$, $$\big(\mathbb{E}\lvert X\rvert^p\big)^{1/p}\ \le\ \big(\mathbb{E}\lvert X\rvert^q\big)^{1/q},$$ i.e |
| **4.7** | Proposition | Evidence lower bound | Let $p_\theta(x,z)$ be a joint density with respect to a product base measure, with marginal $p_\theta(x)=\int p_\theta(x,z)\,dz>0$, and let $q(z)$ be any density with $q\ll p_\theta(\cdot\mid x)$ |
| **4.8** | Theorem | Markov's inequality | Let $X\ge0$ be a random variable and $t>0$ |
| **4.9** | Corollary | Chebyshev's inequality | Let $X$ have $\mathbb{E}[X^2]<\infty$, mean $\mu$ and variance $\sigma^2$ |
| **4.10** | Proposition | Markov's inequality is attained | For every $t>1$ there is a non-negative random variable $X$ with $\mathbb{E}[X]=1$ and $\mathbb{P}(X\ge t)=1/t$ exactly |
| **4.11** | Corollary | Chebyshev for sample means | Let $X_1,\dots,X_n$ be i.i.d. (so the dataset has law $P^{\otimes n}$, Ch |
| **4.13** | Lemma | Basic properties of the CGF | Let $\Lambda:=\{\lambda\in\mathbb{R}:M_X(\lambda)<\infty\}$ |
| **4.14** | Theorem | Chernoff–Cramér bound | For any random variable $X$ and any $t\in\mathbb{R}$, $$\mathbb{P}(X\ge t)\ \le\ \exp\big(-\psi_X^*(t)\big)=\inf_{\lambda\ge0}\ e^{-\lambda t}M_X(\lambda).$$ *Proof.* For $\lambda>0$ the map $x\mapsto e^{\la… |
| **4.15** | Proposition | Chernoff for i.i.d. sums: the rate is linear in $n$ | Let $X_1,\dots,X_n$ be i.i.d. copies of $X$, $\bar X_n$ their average, and $t>\mathbb{E}[X]$ |
| **4.17** | Theorem | Equivalent characterizations of sub-Gaussianity | Let $X$ be centered. The following are equivalent in the sense that each implies the others with a constant factor change in the parameter, and there are absolute constants $c,C>0$ making all the implication… |
| **4.18** | Proposition | Closure properties | Let $X$ be $\sigma^2$-sub-Gaussian and $c\in\mathbb{R}$ |
| **4.19** | Lemma | Hoeffding's lemma | Let $X$ be a random variable with $a\le X\le b$ a.s |
| **4.21** | Proposition | Two-regime tail bound | If $X$ satisfies the Bernstein condition with parameters $(\nu^2,b)$, then for all $t\ge0$, $$\mathbb{P}(X\ge t)\ \le\ \exp\Big(-\frac{t^2}{2(\nu^2+bt)}\Big)\ \le\ \begin{cases} \exp\big(-\dfrac{t^2}{4\nu^2}… |
| **4.22** | Proposition | Squared Gaussians are sub-exponential | Let $Z\sim \mathcal{N}(0,1)$ and $X=Z^2-1$ |
| **4.23** | Theorem | Hoeffding's inequality | Let $X_1,\dots,X_n$ be independent with $a_i\le X_i\le b_i$ a.s., and let $S_n=\sum_{i=1}^n\big(X_i-\mathbb{E}[X_i]\big)$ |
| **4.24** | Theorem | Bernstein's inequality | Let $X_1,\dots,X_n$ be independent with $\lvert X_i-\mathbb{E}[X_i]\rvert\le M$ a.s., and set $\sigma^2:=\frac1n\sum_{i=1}^n\operatorname{Var}(X_i)$ |
| **4.25** | Theorem | Bennett's inequality | In the setting of Theorem 4.24 — in fact under the weaker *one-sided* hypothesis $X_i-\mathbb{E}[X_i]\le M$ a.s., with no lower bound on the $X_i$ required — $$\mathbb{P}\big(\bar X_n-\mu\ge t\big)\ \le\ \ex… |
| **4.26** | Proposition | Empirical Bernstein; stated, not proved here | Let $X_1,\dots,X_n$ be i.i.d. in $[0,1]$ with mean $\mu$, and let $\hat V_n=\frac{1}{n(n-1)}\sum_{i<j}(X_i-X_j)^2$ be the (unbiased) sample variance |
| **4.28** | Theorem | Azuma–Hoeffding, interval form; proof in Ch. 6 | Let $(\mathcal F_k)_{k=0}^n$ be a filtration and let $(V_k)_{k=0}^n$ be a martingale with respect to it, i.e |
| **4.29** | Theorem | McDiarmid's inequality / bounded differences inequality | Let $Z_1,\dots,Z_n$ be *independent* random variables taking values in $\mathcal Z$, and let $f:\mathcal Z^n\to\mathbb{R}$ have the bounded differences property with constants $c_1,\dots,c_n$ |
| **4.30** | Theorem | Efron–Stein inequality; stated here, not proved in this book — see the ledger in §4.12 | Let $Z_1,\dots,Z_n$ be independent, $Z=(Z_1,\dots,Z_n)$, and let $f$ be such that $f(Z)$ is square-integrable |
| **4.32** | Proposition | Stability implies generalization in expectation | Let $A$ be $\beta$-uniformly stable and let $S=(Z_1,\dots,Z_n)$ be i.i.d |
| **4.34** | Theorem | Uniform convergence for finite classes | Let $\mathcal H$ be finite with $\lvert\mathcal H\rvert=N$, let $\ell$ take values in $[0,1]$, and let $S\sim P^{\otimes n}$ |
| **4.35** | Corollary | ERM is nearly optimal; sample complexity | In the setting of Theorem 4.34, with probability at least $1-\delta$ the empirical risk minimizer $\hat h$ satisfies $$R(\hat h)\ \le\ R(h^\star)+2\varepsilon(n,\delta),$$ and consequently $n\ \ge\ \dfrac{2\… |
| **4.37** | Theorem | Symmetrization | Let $\mathcal F$ be a class of functions $\mathcal Z\to\mathbb{R}$ and $S=(Z_1,\dots,Z_n)\sim P^{\otimes n}$ |
| **4.38** | Theorem | Rademacher generalization bound | Let $\ell$ take values in $[0,1]$, let $\mathcal F=\ell\circ\mathcal H$, and let $S\sim P^{\otimes n}$ |
| **4.39** | Lemma | Massart's finite class lemma | Let $A\subseteq\mathbb{R}^n$ be a finite set with $\lvert A\rvert=N\ge1$ and $\mathcal{R}:=\max_{a\in A}\lVert a\rVert_2$ |
| **4.40** | Lemma | Talagrand's contraction lemma; stated, not proved here | Let $\phi:\mathbb{R}\to\mathbb{R}$ be $L$-Lipschitz with $\phi(0)=0$, and let $\mathcal F$ be a class of real-valued functions |
| **4.41** | Proposition | Norm-bounded linear class | Let $\mathcal F_{\mathrm{lin}}=\{x\mapsto\langle w,x\rangle:\lVert w\rVert_2\le B\}$ and let $x_1,\dots,x_n\in\mathbb{R}^d$ with $\max_i\lVert x_i\rVert_2\le X$ |
| **4.42** | Proposition | Two-layer network, norm-based | Let $\rho:\mathbb{R}\to\mathbb{R}$ be $1$-Lipschitz with $\rho(0)=0$ (e.g |
| **4.44** | Proposition | VC dimensions of four basic classes | 1. *Thresholds* on $\mathbb{R}$: $\mathcal H=\{x\mapsto\mathbb{1}_{\{x\ge t\}}:t\in\mathbb{R}\}$ has $\mathrm{VC}=1$ |
| **4.45** | Lemma | Sauer–Shelah | If $\mathrm{VC}(\mathcal H)=d<\infty$ then for all $n\ge1$, $$\Pi_{\mathcal H}(n)\ \le\ \sum_{i=0}^{d}\binom{n}{i}\ \le\ (n+1)^d ,$$ and for $n\ge d\ge1$ also $\Pi_{\mathcal H}(n)\le\big(\tfrac{en}{d}\big)^d$ |
| **4.46** | Theorem | VC bound via Rademacher | Let $\mathcal H$ be a class of functions $\mathcal X\to\{0,1\}$ with $\mathrm{VC}(\mathcal H)=d<\infty$, and let $\ell$ be the $0$–$1$ loss |
| **4.47** | Proposition | VC dimension of neural networks; cited facts, not proved here | Let $\mathcal H$ be the class of binary classifiers computed by a feedforward network with $W$ weights and $L$ layers |
| **4.49** | Proposition | Covering numbers of the Euclidean ball | Let $B_2^d=\{x\in\mathbb{R}^d:\lVert x\rVert_2\le1\}$ with the Euclidean metric |
| **4.50** | Proposition | One-scale discretization bound | Let $\mathcal F$ be a class of functions with $B:=\sup_{f\in\mathcal F}\lVert f\rVert_{L^2(\hat P_n)}<\infty$ |
| **4.51** | Theorem | Dudley's entropy integral; stated, with proof sketch | Let $\mathcal F$ be a class of functions with $\sup_{f\in\mathcal F}\lVert f\rVert_{L^2(\hat P_n)}\le B$ and $0\in\mathcal F$ |

## Chapter 5 — Multivariate and Gaussian Theory

| No. | Kind | Name | Statement |
|---|---|---|---|
| **5.2** | Proposition | the covariance matrix as a quadratic form | Let $X$ be a random vector in $\mathbb{R}^d$ with $\mathbb{E}\|X\|^2 < \infty$, mean $\mu$, covariance $\Sigma$ |
| **5.3** | Proposition | affine transformation | Let $X$ be a random vector in $\mathbb{R}^d$ with mean $\mu$, covariance $\Sigma$; let $A \in \mathbb{R}^{m\times d}$, $b \in \mathbb{R}^m$, and $Y = AX+b$ |
| **5.5** | Proposition | Cauchy–Schwarz for covariance | $|\operatorname{Cov}(X_i,X_j)| \le \sqrt{\operatorname{Var}(X_i)\operatorname{Var}(X_j)}$, so $|\rho_{ij}| \le 1$; equality holds iff $X_i - \mu_i = c(X_j - \mu_j)$ a.s |
| **5.6** | Proposition | *(unnamed)* | If $X_i \perp X_j$ and both are in $L^2$, then $\operatorname{Cov}(X_i,X_j) = 0$ |
| **5.7** | Proposition | sample mean and sample covariance | Let $X_1,\dots,X_n$ be i.i.d. copies of $X$ with mean $\mu$ and covariance $\Sigma$, and set $$ \bar X_n := \frac1n\sum_{i=1}^n X_i,\qquad \hat\Sigma_n := \frac1n\sum_{i=1}^n (X_i-\bar X_n)(X_i-\bar X_n)^\top |
| **5.8** | Theorem | spectral theorem for real symmetric matrices; proof cited | Every symmetric $\Sigma \in \mathbb{R}^{d\times d}$ admits a decomposition $\Sigma = UDU^\top$ where $U$ is orthogonal ($U^\top U = I$), its columns $u_1,\dots,u_d$ are eigenvectors, and $D = \operatorname{d… |
| **5.10** | Proposition | whitening | Let $\Sigma \succ 0$ and $W$ satisfy $W\Sigma W^\top = I$ |
| **5.11** | Theorem | variance-maximizing directions | Let $\Sigma \succeq 0$ have eigenvalues $\lambda_1\ge\dots\ge\lambda_d$ with orthonormal eigenvectors $u_1,\dots,u_d$ |
| **5.13** | Proposition | ellipsoid geometry | For $\Sigma = UDU^\top \succ 0$, the set $E_r := \{x : (x-\mu)^\top\Sigma^{-1}(x-\mu)\le r^2\}$ is an ellipsoid centered at $\mu$ whose principal axes point along the eigenvectors $u_i$ with semi-axis length… |
| **5.14** | Proposition | differential entropy of a Gaussian | If $X\sim\mathcal{N}(\mu,\Sigma)$ with $\Sigma\succ0$ and $p$ is its Lebesgue density, then $$ h(X) := -\int_{\mathbb{R}^d} p(x)\log p(x)\,dx = \tfrac12\log\big((2\pi e)^d\det\Sigma\big) = \tfrac d2\big(1+\l… |
| **5.16** | Lemma | characteristic function of a Gaussian | If $X\sim\mathcal{N}(\mu,\Sigma)$ in the sense of Definition 5.15, then for all $t\in\mathbb{R}^d$ $$ \varphi_X(t) := \mathbb{E}\big[e^{i t^\top X}\big] = \exp\Big(i t^\top\mu - \tfrac12 t^\top \Sigma t\Big) |
| **5.17** | Theorem | three equivalent definitions | Let $X$ be a random vector in $\mathbb{R}^d$ with $\mathbb{E}\|X\|^2<\infty$, mean $\mu$, covariance $\Sigma$ |
| **5.18** | Corollary | Gaussians are closed under affine maps | If $X\sim\mathcal{N}(\mu,\Sigma)$ in $\mathbb{R}^d$, $B\in\mathbb{R}^{m\times d}$, $c\in\mathbb{R}^m$, then $BX+c \sim \mathcal{N}(B\mu+c,\ B\Sigma B^\top)$ |
| **5.19** | Proposition | Gaussian in natural form | For $\Sigma\succ0$, write $\Lambda := \Sigma^{-1}$ (the precision) and $\eta := \Lambda\mu$ |
| **5.20** | Proposition | marginals | $X_1\sim\mathcal{N}(\mu_1,\Sigma_{11})$ |
| **5.21** | Lemma | block inversion; Schur complement | Suppose $\Sigma\succ0$ with the block structure above (so $\Sigma_{22}\succ0$ as a principal submatrix of a positive definite matrix, and $\Sigma_{11}\succ0$ likewise) |
| **5.22** | Theorem | Gaussian conditioning | Let $X = (X_1,X_2)\sim\mathcal{N}(\mu,\Sigma)$ with $\Sigma\succ0$ |
| **5.23** | Corollary | uncorrelated blocks of a jointly Gaussian vector are independent | If $X = (X_1,X_2)$ is jointly Gaussian and $\Sigma_{12} = 0$, then $X_1 \perp X_2$ |
| **5.25** | Theorem | precision zeros = conditional independence | Let $X\sim\mathcal{N}(\mu,\Sigma)$ with $\Sigma\succ0$ and $\Lambda = \Sigma^{-1}$ |
| **5.26** | Proposition | independent sums | If $X\sim\mathcal{N}(\mu_X,\Sigma_X)$ and $Y\sim\mathcal{N}(\mu_Y,\Sigma_Y)$ are independent random vectors in $\mathbb{R}^d$, then $X+Y\sim\mathcal{N}(\mu_X+\mu_Y,\ \Sigma_X+\Sigma_Y)$ |
| **5.27** | Lemma | product of Gaussian densities | Let $\mathcal{N}(x; m,P)$ denote the density of $\mathcal{N}(m,P)$ evaluated at $x$, with $P\succ0$ |
| **5.28** | Theorem | marginalization and conditioning for linear-Gaussian models | Let $$ X\sim\mathcal{N}(\mu,\ \Lambda_x^{-1}),\qquad Y\mid X = x \ \sim\ \mathcal{N}(Ax+b,\ \Lambda_y^{-1}), $$ with $\Lambda_x\succ0$, $\Lambda_y\succ0$, $A\in\mathbb{R}^{m\times d}$ |
| **5.29** | Proposition | KL divergence between Gaussians | Let $P_1 = \mathcal{N}(\mu_1,\Sigma_1)$ and $P_2 = \mathcal{N}(\mu_2,\Sigma_2)$ on $\mathbb{R}^d$ with $\Sigma_1,\Sigma_2\succ0$ |
| **5.30** | Proposition | posterior and predictive | With the above, $$ \theta\mid y \ \sim\ \mathcal{N}\big(\Sigma_\theta X^\top y/\sigma^2,\ \Sigma_\theta\big),\qquad \Sigma_\theta = \Big(\tfrac{1}{\sigma^2}X^\top X + \tfrac1\alpha I_p\Big)^{-1}, $$ and for… |
| **5.31** | Theorem | Kalman filter | Consider the linear-Gaussian state-space model $$ x_t = F x_{t-1} + w_t,\quad w_t\sim\mathcal{N}(0,Q);\qquad y_t = Hx_t + v_t,\quad v_t\sim\mathcal{N}(0,R), $$ with $x_0\sim\mathcal{N}(m_0,P_0)$ and all nois… |
| **5.32** | Proposition | factor analysis marginal | Let $z\sim\mathcal{N}(0,I_k)$ and $x = Wz+\mu+\varepsilon$ with $\varepsilon\sim\mathcal{N}(0,\Psi)$ independent of $z$, $W\in\mathbb{R}^{d\times k}$, $\Psi$ diagonal positive |
| **5.34** | Theorem | forward variance recursion and the He rule | Under (A1)–(A4), for each unit $i$, $$ \mathbb{E}\big[(z_i^{(l+1)})^2\big] = n_l\, v_l\, \mathbb{E}\big[(a^{(l)})^2\big] |
| **5.35** | Proposition | backward recursion; Xavier/Glorot | Let $\delta^{(l)} := \partial\mathcal L/\partial z^{(l)}$ |
| **5.37** | Theorem | Kolmogorov extension theorem; cited, not proved | Given a family of finite-dimensional distributions on $\mathbb{R}^{S}$ for each finite $S\subseteq\mathcal X$ that is consistent under marginalization and permutation, there exists a probability space and a… |
| **5.38** | Proposition | existence of GPs | For any $m:\mathcal X\to\mathbb{R}$ and any symmetric PSD kernel $k$, a Gaussian process $\mathcal{GP}(m,k)$ exists |
| **5.39** | Theorem | GP regression posterior | Let $f\sim\mathcal{GP}(0,k)$ and observe $y_i = f(x_i)+\varepsilon_i$, $\varepsilon_i\stackrel{iid}\sim\mathcal{N}(0,\sigma_n^2)$, at training inputs $X = (x_1,\dots,x_n)$ |
| **5.40** | Proposition | log marginal likelihood | With the setup above and $K_y := K+\sigma_n^2I$, $$ \log p(y\mid X,\theta) = -\tfrac12 y^\top K_y^{-1}y \;-\; \tfrac12\log\det K_y \;-\; \tfrac n2\log2\pi |

## Chapter 6 — Conditional Expectation and Martingales

| No. | Kind | Name | Statement |
|---|---|---|---|
| **6.2** | Theorem | existence and a.s. uniqueness | Let $X\in L^1(\Omega,\mathcal{F},\mathbb{P})$ and $\mathcal{G}\subseteq\mathcal{F}$ a sub-$\sigma$-algebra |
| **6.4** | Proposition | conditional expectation on a partition | Suppose $\mathcal{G}=\sigma(\{A_1,\dots,A_k\})$ where $A_1,\dots,A_k$ partition $\Omega$ (by the partition correspondence of Chapter 1 every $\sigma$-algebra with finitely many sets is of this form, the $A_i… |
| **6.5** | Theorem | $\mathbb{E}[\cdot\mid\mathcal{G}]$ is orthogonal projection | Let $X\in L^2(\Omega,\mathcal{F},\mathbb{P})$ and $\mathcal{G}\subseteq\mathcal{F}$ |
| **6.6** | Corollary | the Bayes-optimal predictor under squared loss | Let $\mathbb{E}[Y^2]<\infty$ and define $f^\star(x):=\mathbb{E}[Y\mid X=x]$ (a Doob–Dynkin version) |
| **6.7** | Proposition | Bayes predictors for absolute and 0–1 loss | Let $(X,Y)$ be a random pair. (a) *(Absolute loss $\to$ conditional median.)* Suppose $\mathbb{E}|Y|<\infty$ |
| **6.8** | Theorem | basic properties | Let $X,X_1,X_2\in L^1(\mathbb{P})$, $a,b\in\mathbb{R}$, and $\mathcal{H}\subseteq\mathcal{G}\subseteq\mathcal{F}$ sub-$\sigma$-algebras |
| **6.9** | Theorem | conditional Jensen | Let $\varphi:\mathbb{R}\to\mathbb{R}$ be convex and suppose $X,\varphi(X)\in L^1$ |
| **6.10** | Corollary | $L^p$ contraction | For $p\ge1$ and $X\in L^p$, $\bigl\|\mathbb{E}[X\mid\mathcal{G}]\bigr\|_p\le\|X\|_p$ |
| **6.11** | Proposition | conditional MCT, Fatou, DCT | Let $X_n$ be random variables |
| **6.13** | Theorem | law of total variance | For $X\in L^2$ and any $\mathcal{G}\subseteq\mathcal{F}$, $$ \operatorname{Var}(X)=\underbrace{\mathbb{E}\bigl[\operatorname{Var}(X\mid\mathcal{G})\bigr]}_{\text{unexplained: noise within atoms}}+\underbrace… |
| **6.14** | Corollary | bias–variance decomposition | Assume all quantities are square-integrable and $(X,Y)\perp D$ |
| **6.16** | Theorem | existence of regular conditional distributions; cited, not proved | If $\mathcal{Y}$ is a Polish space (a complete separable metric space) with its Borel $\sigma$-algebra — e.g |
| **6.17** | Proposition | conditional density | Suppose $(X,Y)$ takes values in $\mathbb{R}^d\times\mathbb{R}^m$ and has a joint density $p(x,y)$ with respect to $\lambda_d\otimes\lambda_m$ |
| **6.20** | Proposition | three constructions | (a) *(Random walk.)* If $\xi_1,\xi_2,\dots$ are independent with $\mathbb{E}|\xi_i|<\infty$ and $\mathbb{E}\xi_i=0$, and $\mathcal{F}_n=\sigma(\xi_1,\dots,\xi_n)$, then $M_n=\sum_{i\le n}\xi_i$ is a martingale |
| **6.22** | Proposition | you cannot beat a fair game; stopped martingales | Let $(M_n)$ be a martingale, $(H_n)_{n\ge1}$ predictable and bounded, and define the *martingale transform* $(H\cdot M)_n:=\sum_{k=1}^nH_k(M_k-M_{k-1})$, $(H\cdot M)_0=0$ |
| **6.23** | Theorem | optional stopping | Let $(M_n)$ be a martingale and $\tau$ a stopping time |
| **6.24** | Theorem | Doob's maximal inequality | Let $(X_n)$ be a non-negative submartingale and $X_n^*:=\max_{0\le k\le n}X_k$ |
| **6.25** | Theorem | Doob's $L^p$ inequality; stated, not proved | For $p>1$ and a non-negative submartingale $(X_n)$, $$ \bigl\|X_n^*\bigr\|_p\ \le\ \frac{p}{p-1}\,\|X_n\|_p |
| **6.26** | Theorem | martingale convergence; stated, with sketch | (a) Let $(M_n)$ be a supermartingale with $\sup_n\mathbb{E}|M_n|<\infty$ (e.g |
| **6.27** | Lemma | conditional Hoeffding lemma | Let $\mathcal{H}\subseteq\mathcal{F}$ and let $D$ be a random variable with $\mathbb{E}[D\mid\mathcal{H}]=0$ and $A\le D\le B$ a.s., where $A,B$ are $\mathcal{H}$-measurable with $B-A\le c$ a.s |
| **6.28** | Theorem | Azuma–Hoeffding | Let $(M_n)_{n\ge0}$ be a martingale with respect to $(\mathcal{F}_n)$ and suppose the increments $D_k:=M_k-M_{k-1}$ satisfy $A_k\le D_k\le A_k+c_k$ a.s |
| **6.29** | Corollary | McDiarmid / bounded differences — the Chapter 4 debt, paid | Let $\xi_1,\dots,\xi_n$ be independent (not necessarily identically distributed) random elements and let $f$ satisfy the bounded-differences condition $$ \bigl|f(x_1,\dots,x_k,\dots,x_n)-f(x_1,\dots,x_k',\do… |
| **6.30** | Theorem | SGD on smooth non-convex objectives | Under (A1)–(A5), with $\Gamma_T:=\sum_{t=0}^{T-1}\eta_t$, $$ \min_{0\le t<T}\mathbb{E}\bigl\|\nabla F(\theta_t)\bigr\|^2\ \le\ \frac{\sum_{t<T}\eta_t\,\mathbb{E}\|\nabla F(\theta_t)\|^2}{\Gamma_T}\ \le\ \fra… |
| **6.31** | Theorem | almost-sure version; Robbins–Siegmund route, stated | Under (A1)–(A5), $F(\theta_t)$ converges a.s |
| **6.32** | Corollary | convex case: function values converge | Assume (A3), (A5) with $\sum\eta_t^2<\infty$, that $F$ is convex with a minimiser $\theta_\star$, and $\mathbb{E}[\|g_t\|^2\mid\mathcal{F}_t]\le G^2$ |

## Chapter 7 — Convergence and Limit Theorems

| No. | Kind | Name | Statement |
|---|---|---|---|
| **7.5** | Theorem | Portmanteau | The following are equivalent for probability measures $P_n, P$ on $\mathbb{R}^d$: 1 |
| **7.6** | Proposition | a reformulation of almost sure convergence | $X_n\to_{\mathrm{as}}X$ if and only if for every $\varepsilon>0$, $$\lim_{N\to\infty}\ \mathbb{P}\Big(\sup_{n\ge N}|X_n-X|>\varepsilon\Big)=0,$$ if and only if $\mathbb{P}\big(|X_n - X|>\varepsilon \text{ fo… |
| **7.7** | Proposition | a.s. $\Rightarrow$ in probability | If $X_n\to_{\mathrm{as}}X$ then $X_n\to_{\mathrm p}X$ |
| **7.8** | Proposition | $L^q\Rightarrow L^p\Rightarrow$ in probability | Let $1\le p<q<\infty$. (i) If $X_n\to_{L^q}X$ then $X_n\to_{L^p}X$ |
| **7.9** | Proposition | in probability $\Rightarrow$ in distribution | If $X_n\to_{\mathrm p}X$ then $X_n\to_{\mathrm d}X$ |
| **7.10** | Proposition | converse when the limit is a constant | If $X_n\to_{\mathrm d}c$ for a constant $c\in\mathbb{R}$, then $X_n\to_{\mathrm p}c$ |
| **7.11** | Theorem | Borel–Cantelli I | If $\sum_{n\ge1}\mathbb{P}(A_n)<\infty$ then $\mathbb{P}(A_n\text{ i.o.})=0$ |
| **7.12** | Theorem | Borel–Cantelli II | If $A_1,A_2,\dots$ are independent (the independence definition, Ch |
| **7.13** | Corollary | a zero–one dichotomy | For independent events, $\mathbb{P}(A_n\text{ i.o.})\in\{0,1\}$, and which one it is depends only on whether $\sum_n\mathbb{P}(A_n)$ converges |
| **7.14** | Proposition | summable tails criterion | If for every $\varepsilon>0$, $$\sum_{n\ge1}\mathbb{P}(|X_n-X|>\varepsilon)<\infty,$$ then $X_n\to_{\mathrm{as}}X$ |
| **7.15** | Theorem | subsequence principle | $X_n\to_{\mathrm p}X$ if and only if every subsequence $(X_{n_k})$ has a further subsequence $(X_{n_{k_j}})$ with $X_{n_{k_j}}\to_{\mathrm{as}}X$ |
| **7.16** | Theorem | WLLN under a second moment | If $\mathbb{E}[X_1^2]<\infty$ with $\mu=\mathbb{E}[X_1]$ and $\sigma^2=\operatorname{Var}(X_1)$, then $\bar X_n\to_{\mathrm p}\mu$; quantitatively, for every $\varepsilon>0$, $$\mathbb{P}(|\bar X_n-\mu|>\var… |
| **7.17** | Theorem | WLLN under a first moment; Khinchin | If $\mathbb{E}|X_1|<\infty$ and $\mu=\mathbb{E}[X_1]$, then $\bar X_n\to_{\mathrm p}\mu$ |
| **7.18** | Theorem | SLLN under a fourth moment | If $\mathbb{E}[X_1^4]<\infty$, then $\bar X_n\to_{\mathrm{as}}\mu$ |
| **7.19** | Theorem | Kolmogorov's SLLN | Let $X_1,X_2,\dots$ be i.i.d. Then $\bar X_n$ converges almost surely to a finite limit if and only if $\mathbb{E}|X_1|<\infty$, in which case the limit is $\mathbb{E}[X_1]$ |
| **7.20** | Proposition | infinite mean destroys the average | If $X_1,X_2,\dots$ are i.i.d. with $\mathbb{E}|X_1|=\infty$, then $\limsup_n|S_n/n|=\infty$ almost surely |
| **7.21** | Corollary | pointwise consistency of empirical risk | If $\mathbb{E}|\ell(h(X),Y)|<\infty$ for a *fixed* $h$, then $\hat R_n(h)\to_{\mathrm{as}}R(h)$ |
| **7.23** | Proposition | elementary properties | For any random variable $X$: 1 |
| **7.24** | Proposition | independence turns convolution into multiplication | If $X\perp Y$ then $\varphi_{X+Y}=\varphi_X\varphi_Y$ |
| **7.25** | Lemma | Taylor bound for the complex exponential | For every $x\in\mathbb{R}$ and integer $n\ge1$, $$\Big|e^{ix}-\sum_{k=0}^{n}\frac{(ix)^k}{k!}\Big|\ \le\ \min\Big\{\frac{|x|^{n+1}}{(n+1)!},\ \frac{2|x|^{n}}{n!}\Big\}.$$ *Proof.* Start from $\int_0^x e^{is}… |
| **7.26** | Proposition | moments and the expansion at $0$ | Suppose $\mathbb{E}|X|^{n}<\infty$ |
| **7.27** | Lemma | product-difference bound | Let $a_1,\dots,a_n$ and $b_1,\dots,b_n$ be complex numbers with $|a_j|\le1$ and $|b_j|\le1$ for all $j$ |
| **7.28** | Theorem | inversion formula | Let $X$ have characteristic function $\varphi$ and CDF $F$ |
| **7.29** | Corollary | uniqueness | If $\varphi_X=\varphi_Y$ then $P_X=P_Y$ |
| **7.30** | Theorem | Lévy's continuity theorem | Let $X_1,X_2,\dots$ be random variables with characteristic functions $\varphi_n$ |
| **7.31** | Theorem | i.i.d. Central Limit Theorem | Let $X_1,X_2,\dots$ be i.i.d. with $\mathbb{E}[X_1]=\mu$ and $0<\sigma^2=\operatorname{Var}(X_1)<\infty$ |
| **7.32** | Theorem | Lindeberg–Feller CLT | For each $n$, let $X_{n,1},\dots,X_{n,k_n}$ be independent with $\mathbb{E}[X_{n,j}]=0$ and $\mathbb{E}[X_{n,j}^2]<\infty$ |
| **7.33** | Corollary | Lyapunov's condition | If for some $\delta>0$, $$\frac{1}{s_n^{2+\delta}}\sum_{j=1}^{k_n}\mathbb{E}\big|X_{n,j}\big|^{2+\delta}\longrightarrow0,$$ then the Lindeberg condition holds, hence $S_n/s_n\to_{\mathrm d}\mathcal{N}(0,1)$ |
| **7.34** | Theorem | Berry–Esseen | Let $X_1,\dots,X_n$ be i.i.d. with mean $\mu$, variance $\sigma^2\in(0,\infty)$, and finite third absolute central moment $\rho:=\mathbb{E}|X_1-\mu|^3$ |
| **7.35** | Theorem | Cramér–Wold device | Let $X_n,X$ be random vectors in $\mathbb{R}^d$ |
| **7.36** | Theorem | multivariate CLT | Let $X_1,X_2,\dots$ be i.i.d. random vectors in $\mathbb{R}^d$ with $\mathbb{E}\|X_1\|^2<\infty$, mean $\mu:=\mathbb{E}[X_1]$ and covariance $\Sigma:=\operatorname{Cov}(X_1)$ |
| **7.37** | Theorem | delta method | Let $\hat\theta_n$ be random vectors in $\mathbb{R}^d$, $\theta\in\mathbb{R}^d$ fixed, and $a_n\to\infty$ a deterministic sequence with $$a_n(\hat\theta_n-\theta)\ \longrightarrow_{\mathrm d}\ T .$$ Let $g:\… |
| **7.38** | Theorem | second-order delta method | Suppose $a_n(\hat\theta_n-\theta)\to_{\mathrm d}T$ in $\mathbb{R}^d$, and $g:\mathbb{R}^d\to\mathbb{R}$ is twice differentiable at $\theta$ with $\nabla g(\theta)=0$ and Hessian $H:=\nabla^2g(\theta)$ |
| **7.39** | Theorem | continuous mapping theorem | Let $h:\mathbb{R}^d\to\mathbb{R}^m$ be Borel measurable and let $D_h$ be its set of discontinuity points |
| **7.40** | Theorem | Slutsky | Suppose $X_n\to_{\mathrm d}X$ and $Y_n\to_{\mathrm p}c$ for a constant $c$ |
| **7.41** | Corollary | asymptotically valid confidence intervals | Let $\hat\theta_n$ satisfy $\sqrt n(\hat\theta_n-\theta)\to_{\mathrm d}\mathcal{N}(0,\sigma^2)$ with $\sigma^2>0$, and let $\hat\sigma_n$ be any estimator with $\hat\sigma_n\to_{\mathrm p}\sigma$ |
| **7.42** | Theorem | Glivenko–Cantelli | $\displaystyle D_n:=\sup_{x\in\mathbb{R}}\big|F_n(x)-F(x)\big|\ \longrightarrow_{\mathrm{as}}\ 0 .$ *Proof.* First, measurability: the supremum is over an uncountable family, which Chapter 1 warned is not au… |
| **7.43** | Theorem | Dvoretzky–Kiefer–Wolfowitz, with Massart's constant | For every $n\ge1$ and every $\varepsilon>0$, $$\mathbb{P}\big(D_n>\varepsilon\big)\ \le\ 2e^{-2n\varepsilon^2}.$$ The constant $2$ in front is sharp (Massart, 1990) |
| **7.44** | Theorem | Donsker | Let $\mathbb{G}_n(x):=\sqrt n\,(F_n(x)-F(x))$ |
| **7.45** | Proposition | minibatch gradient CLT | Fix $\theta$ and $\mathcal{D}$, and let $\Sigma(\theta):=\frac1N\sum_i\big(\nabla\ell(\theta;z_i)-g(\theta)\big)\big(\nabla\ell(\theta;z_i)-g(\theta)\big)^\top$ be the empirical gradient covariance |

## Chapter 8 — Point Estimation

| No. | Kind | Name | Statement |
|---|---|---|---|
| **8.3** | Proposition | Bias–variance decomposition | > Under the conditions of Definition 8.2, for every $\theta$, > $$\operatorname{MSE}_\theta(\hat g_n) = \operatorname{Bias}_\theta(\hat g_n)^2 + \operatorname{Var}_\theta(\hat g_n).$$ > > *Proof.* Write $b :… |
| **8.5** | Proposition | $L^2$ consistency implies consistency | > If $\operatorname{MSE}_\theta(\hat\theta_n)\to 0$ as $n\to\infty$, then $\hat\theta_n \to_p \theta$ |
| **8.7** | Proposition | Consistency and asymptotic normality of MoM | > Suppose $m_{2d}(\theta) < \infty$ (so the sample moments have finite variance), the map $M:\theta\mapsto(m_1(\theta),\dots,m_d(\theta))$ is injective on $\Theta$, continuously differentiable, and its inver… |
| **8.9** | Proposition | Equivariance of the MLE under reparameterization | > Let $\psi = g(\theta)$ for a function $g:\Theta\to\Psi$ |
| **8.10** | Proposition | MLE in an exponential family is moment matching | > Let $p_\eta(x) = h(x)\exp(\eta^\top T(x) - A(\eta))$ w.r.t |
| **8.11** | Proposition | The likelihood of a Gaussian mixture is unbounded | > Let $\Theta = \{(w,m_1,v_1,m_2,v_2) : w\in(0,1), m_j\in\mathbb R, v_j > 0\}$ with > $$p_\theta(x) = w\,\phi_{m_1,v_1}(x) + (1-w)\phi_{m_2,v_2}(x)$$ > w.r.t |
| **8.14** | Proposition | The score has mean zero | > Under (R1)–(R3), $\mathbb E_\theta[s(\theta;X)] = 0$ for every $\theta$ in the interior of $\Theta$ |
| **8.15** | Theorem | Information equality | > Under (R1)–(R4), define the **Fisher information matrix** > $$\mathcal{I}(\theta) := \operatorname{Var}_\theta\big(s(\theta;X)\big) = \mathbb E_\theta\big[s(\theta;X)s(\theta;X)^\top\big]$$ > (the second e… |
| **8.16** | Proposition | Additivity over independent observations | > If $X_1,\dots,X_n$ are i.i.d |
| **8.17** | Proposition | Exponential families | > For $p_\eta(x)=h(x)\exp(\eta^\top T(x)-A(\eta))$ in natural parameterization on an open natural parameter space, the regularity conditions hold and > $$s(\eta;x) = T(x)-\nabla A(\eta), \qquad \mathcal{I}(\… |
| **8.18** | Proposition | Reparameterization | > Let $\psi = g(\theta)$ with $g$ a $C^1$ diffeomorphism, and write $I_\theta$ and $I_\psi$ for the informations in the two parameterizations |
| **8.19** | Theorem | Cramér–Rao, scalar case | > Let $\{p_\theta:\theta\in\Theta\subseteq\mathbb R\}$ be regular in the sense of Definition 8.13 with $0 < \mathcal{I}(\theta)<\infty$, and let $\hat g_n = \hat g_n(X_1,\dots,X_n)$ be an estimator with $\ma… |
| **8.20** | Corollary | Multivariate Cramér–Rao | > Under the analogous conditions with $\theta\in\mathbb R^d$ and $\hat\theta_n$ unbiased for $\theta$, > $$\operatorname{Cov}_\theta(\hat\theta_n) \;\succeq\; \frac{1}{n} \mathcal{I}(\theta)^{-1},$$ > meanin… |
| **8.22** | Proposition | When the bound is attained | > Equality holds in Theorem 8.19 at $\theta$ if and only if there is a constant $c(\theta)$ (not depending on the data) with > $$\hat g_n(x) - g(\theta) = c(\theta)\,S_n(\theta;x) \quad \text{for } P_\theta\… |
| **8.23** | Proposition | Chapman–Robbins bound | > Let $\hat g$ be unbiased for $g(\theta)$ with finite variance, and suppose $h\ne0$ is such that $P_{\theta+h}^{\otimes n}\ll P_\theta^{\otimes n}$ |
| **8.24** | Theorem | Consistency of the MLE | > Let $X_1,\dots,X_n\stackrel{iid}\sim P_{\theta_0}$ with $\theta_0$ in the interior of a compact $\Theta\subseteq\mathbb R^d$ |
| **8.25** | Theorem | Asymptotic normality of the MLE | > Assume (i) $\hat\theta_n\to_p\theta_0$ with $\theta_0$ interior to $\Theta$; (ii) regularity (R1)–(R4) in a neighborhood of $\theta_0$, with $\mathcal{I}(\theta_0)$ finite and nonsingular; (iii) $\hat\thet… |
| **8.26** | Corollary | Standard errors for a transformed MLE | > Under the hypotheses of Theorem 8.25, let $g:\Theta\to\mathbb R^k$ be continuously differentiable at $\theta_0$ with Jacobian $G := \nabla g(\theta_0)$ |
| **8.28** | Theorem | Sandwich / White's theorem | > Under regularity conditions analogous to Theorem 8.25 but with expectations taken under $P^\star$, and with $\hat\theta_n\to_p\theta^\star$, > $$\sqrt n(\hat\theta_n - \theta^\star)\to_d\mathcal{N}\big(0,\… |
| **8.30** | Theorem | Rao–Blackwell | > Let $\delta = \delta(X_1,\dots,X_n)$ be an estimator of $g(\theta)$ with $\mathbb E_\theta[\delta^2]<\infty$ for all $\theta$, and let $T$ be sufficient for $\theta$ |
| **8.32** | Theorem | Lehmann–Scheffé | > Let $T$ be complete and sufficient, and let $\delta$ be any unbiased estimator of $g(\theta)$ with finite variance |
| **8.34** | Proposition | Gaussian prior gives ridge; Laplace prior gives lasso | > Consider the Gaussian linear model $y_i \mid x_i \sim \mathcal{N}(x_i^\top\beta, \sigma^2)$ with $\sigma^2$ known, $\beta \in \mathbb R^d$ |
| **8.35** | Proposition | MAP is not equivariant | > Let $\psi = g(\theta)$ with $g$ a $C^1$ diffeomorphism |
| **8.37** | Proposition | Optimal linear shrinkage | > Let $X\sim\mathcal{N}(\theta,I_d)$ and consider $\hat\theta_c := cX$ for a constant $c\in[0,1]$ |
| **8.38** | Theorem | James–Stein | > Let $X\sim\mathcal{N}(\theta,I_d)$ with $d\ge3$ and define > $$\hat\theta^{\mathrm{JS}} := \Big(1 - \frac{d-2}{\|X\|^2}\Big)X.$$ > Then for every $\theta\in\mathbb R^d$, > $$\mathbb E_\theta\|\hat\theta^{\… |
| **8.39** | Theorem | Monotone likelihood improvement | > The EM iterates satisfy $\log p_{\theta^{(t+1)}}(x) \ge \log p_{\theta^{(t)}}(x)$ for every $t$, with equality only if $\theta^{(t+1)}$ fails to increase $Q(\cdot\mid\theta^{(t)})$ |
| **8.40** | Proposition | EM updates for a $K$-component Gaussian mixture | > Let $p_\theta(x) = \sum_{k=1}^K w_k\,\phi_{m_k,v_k}(x)$ with $\sum_k w_k=1$, $w_k>0$, and latent $Z_i\in\{1,\dots,K\}$ indicating the component of $x_i$ |

## Chapter 9 — Hypothesis Testing and Confidence Sets

| No. | Kind | Name | Statement |
|---|---|---|---|
| **9.5** | Proposition | the power ceiling | Let $\varphi$ be any test and $P_0, P_1$ any two probability measures on $(\mathcal{X},\mathcal{A})$ |
| **9.7** | Theorem | Neyman–Pearson lemma | Fix $\alpha \in (0,1)$. Consider testing $H_0: P = P_0$ vs $H_1 : P = P_1$ |
| **9.8** | Corollary | Neyman–Pearson tests are unbiased | The most powerful level-$\alpha$ test satisfies $\mathbb{E}_1[\varphi^*] \ge \alpha$, with equality if and only if $P_0 = P_1$ |
| **9.10** | Theorem | Karlin–Rubin | Suppose $\{P_\theta\}$ has MLR in $T$ |
| **9.11** | Proposition | exponential families have MLR | Let $\{P_\eta\}$ be a one-parameter exponential family (Ch |
| **9.13** | Proposition | the likelihood ratio has the best ROC; ROC curves are concave | > (i) Let $R^*$ be the ROC curve of the score $s^* = L = dP_1/dP_0$ and $R$ the ROC curve of any other score $s$ |
| **9.15** | Theorem | Wilks | Assume the regularity conditions under which Chapter 8's MLE asymptotics hold: the model is correctly specified with true parameter $\theta^* = (\psi_0,\lambda^*)$ in the interior of $\Theta$, $\ell$ is thre… |
| **9.16** | Proposition | asymptotic equivalence | Under the hypotheses of Theorem 9.15, > $$W_{\mathrm{LR}} - W_{\mathrm{Wald}} \to_p 0, \qquad W_{\mathrm{LR}} - W_{\mathrm{score}} \to_p 0,$$ > so all three converge in distribution to $\chi^2_k$ under $H_0$… |
| **9.18** | Proposition | super-uniformity, and exact uniformity in the continuous case | Let $T$ be a real-valued statistic, $H_0: P = P_0$ simple, and $p(x) = \mathbb{P}_0(T \ge T(x))$ |
| **9.19** | Proposition | $p$-values and tests are the same object | Let $p$ satisfy $\mathbb{P}_\theta(p \le \alpha)\le\alpha$ for all $\theta\in\Theta_0,\alpha\in[0,1]$ |
| **9.20** | Proposition | posterior probability of the null; the false-discovery arithmetic | Consider testing $H_0$ vs $H_1$ with prior probabilities $\pi_0, \pi_1 = 1-\pi_0$, a level-$\alpha$ test with power $\beta$ |
| **9.21** | Proposition | continuous monitoring rejects almost surely | Let $X_1,X_2,\dots\overset{\text{iid}}{\sim}\mathcal{N}(0,1)$ (the null), $S_n = \sum_{i\le n}X_i$, and $Z_n = S_n/\sqrt n$ |
| **9.23** | Theorem | test–confidence-set duality | Suppose for each $\theta_0\in\Theta$ we have a level-$\alpha$ test $\varphi_{\theta_0}$ of $H_0 : \theta = \theta_0$, non-randomized, with acceptance region $A(\theta_0) := \{x : \varphi_{\theta_0}(x) = 0\}$ |
| **9.25** | Proposition | pivots give exact confidence sets | Let $Q$ be a pivot with known law $\mathcal{L}$, and choose $q_{\alpha/2}, q_{1-\alpha/2}$ with $\mathcal{L}([q_{\alpha/2}, q_{1-\alpha/2}]) \ge 1-\alpha$ |
| **9.26** | Proposition | three inverted tests for a proportion | Fix $\alpha$ and let $z = z_{1-\alpha/2}$ |
| **9.28** | Proposition | a DKW band for a CDF | Let $X_1,\dots,X_n$ be i.i.d. with CDF $F$ and let $\hat F_n$ be the empirical CDF (Chapter 1's empirical measure $\hat P_n$ evaluated on half-lines) |
| **9.30** | Proposition | Bonferroni | Reject $H_{0,i}$ iff $p_i \le \alpha/m$ |
| **9.31** | Theorem | Holm's step-down procedure | Order the $p$-values $p_{(1)}\le\dots\le p_{(m)}$ with corresponding hypotheses $H_{(1)},\dots,H_{(m)}$ |
| **9.32** | Theorem | Benjamini–Hochberg, 1995 | Fix $q\in(0,1)$. Order $p_{(1)}\le\dots\le p_{(m)}$, let > $$\hat k := \max\Big\{i : p_{(i)} \le \frac{q\,i}{m}\Big\}$$ > ($\hat k = 0$ if the set is empty), and reject $H_{(1)},\dots,H_{(\hat k)}$ |
| **9.33** | Proposition | selection inflates the selected estimate | Let $\hat\theta_1,\dots,\hat\theta_m$ be estimators with $\mathbb{E}[\hat\theta_j] = \theta_j$, and let $\hat j := \arg\max_j\hat\theta_j$ |
| **9.35** | Theorem | exactness of the randomization test | Let $\mathcal{G}$ be a finite group with $|\mathcal{G}| = M$, let $T:\mathcal{X}\to\mathbb{R}$ be any statistic, and suppose $g(X)\overset d= X$ for all $g\in\mathcal{G}$ under $H_0$ |
| **9.36** | Proposition | Monte Carlo permutation is still exact | Let $g_1,\dots,g_B$ be i.i.d. uniform on $\mathcal{G}$, independent of $X$, and define > $$\hat p := \frac{1 + \#\{b : T(g_b(X)) \ge T(X)\}}{B+1} .$$ > Then under $H_0$, $\mathbb{P}(\hat p \le \alpha)\le\alp… |
| **9.38** | Theorem | bootstrap consistency for the mean | Let $X_1,X_2,\dots$ be i.i.d. with $\mathbb{E}[X_1^2]<\infty$, $\operatorname{Var}(X_1) = \sigma^2 \in(0,\infty)$, and let $\bar X_n$ be the sample mean |
| **9.40** | Proposition | the percentile interval respects monotone transformations | Let $\phi$ be a strictly increasing continuous function and let $C = [q^*_{\alpha/2}, q^*_{1-\alpha/2}]$ be the percentile interval for $\theta$ built from replicates $\hat\theta^*_b$ |
| **9.41** | Proposition | the bootstrap fails for the maximum | Let $X_1,\dots,X_n\overset{\text{iid}}{\sim}\mathrm{Unif}[0,\theta]$ and $\hat\theta = X_{(n)} = \max_i X_i$ |
| **9.42** | Proposition | why pairing works | Let $(A_i, B_i)_{i\le n}$ be i.i.d |
| **9.44** | Proposition | McNemar is exact conditionally | Under $H_0$ as stated, and conditionally on $b + c = m$, the count $b$ is $\mathrm{Bin}(m,1/2)$, so the exact two-sided test has size $\le\alpha$ for every $m$ and every distribution of the concordant cells |
| **9.45** | Proposition | variance of a $K$-fold average | Let $D_1,\dots,D_K$ be the per-fold score differences, with common variance $\tau^2$ and common pairwise correlation $\varrho$ |
| **9.46** | Proposition | seed budget | Suppose training with seed $s$ yields test accuracy $Y_s$ with $\operatorname{Var}(Y_s) = \sigma_{\text{seed}}^2$, i.i.d |
| **9.47** | Proposition | AUC as a probability | With continuous scores, $\mathrm{AUC} = \mathbb{P}(S_+ > S_-)$ for independent $S_+\sim P_1$, $S_-\sim P_0$; the empirical AUC equals the normalized Mann–Whitney $U$ statistic $\frac{1}{n_+n_-}\sum_{i,j}\mat… |

## Chapter 10 — Bayesian Inference

| No. | Kind | Name | Statement |
|---|---|---|---|
| **10.3** | Proposition | the posterior is a probability measure, and exists almost surely | Fix a Bayesian model as above with dominating measure $\mu$ |
| **10.4** | Theorem | coherence and order-invariance of updating | Let $X_1,\dots,X_n$ be conditionally i.i.d |
| **10.5** | Theorem | de Finetti representation; stated, not proved | Let $(X_1,X_2,\dots)$ be an infinite sequence of random variables taking values in a Polish space $\mathcal{X}$, whose joint law is *exchangeable*: for every $n$ and every permutation $\varsigma$ of $\{1,\do… |
| **10.7** | Proposition | predictive moments; over-dispersion | With $\mu(\theta):=\mathbb{E}[\tilde X\mid\theta]$ and $v(\theta):=\operatorname{Var}(\tilde X\mid\theta)$, assuming these are integrable under the posterior, $$ \mathbb{E}[\tilde X\mid D]=\mathbb{E}[\mu(\th… |
| **10.9** | Theorem | Bernstein–von Mises; stated, not proved | Let $\{P_\theta:\theta\in\Theta\}$, $\Theta\subseteq\mathbb{R}^d$ open, be a differentiable-in-quadratic-mean model with nonsingular Fisher information $\mathcal{I}(\theta_0)$ (Ch |
| **10.11** | Proposition | Beta–Bernoulli | Let $X_1,\dots,X_n\mid\theta \overset{iid}{\sim}\mathrm{Bernoulli}(\theta)$ with $\theta\sim\mathrm{Beta}(a_0,b_0)$, $a_0,b_0>0$, and let $s=\sum_i x_i$ |
| **10.12** | Proposition | Dirichlet–Categorical | Let $X_1,\dots,X_n\mid\theta\overset{iid}{\sim}\mathrm{Categorical}(\theta)$ on $\{1,\dots,K\}$, $\theta\in\Delta_{K-1}$, with $\theta\sim\mathrm{Dirichlet}(\alpha_1,\dots,\alpha_K)$, $\alpha_k>0$, and let $… |
| **10.13** | Proposition | Gaussian mean, known variance | Let $X_1,\dots,X_n\mid\mu\overset{iid}{\sim}\mathcal{N}(\mu,\sigma^2)$ with $\sigma^2$ known, and $\mu\sim \mathcal{N}(\mu_0,\tau^2)$ |
| **10.14** | Proposition | Normal-Inverse-Gamma | Let $X_1,\dots,X_n\mid(\mu,\sigma^2)\overset{iid}{\sim}\mathcal{N}(\mu,\sigma^2)$ and put the *joint* prior $$ \sigma^2\sim\mathrm{Inv\text{-}Gamma}(\alpha_0,\beta_0),\qquad \mu\mid\sigma^2\sim \mathcal{N}(\… |
| **10.15** | Proposition | Gamma–Poisson | Let $X_1,\dots,X_n\mid\lambda\overset{iid}{\sim}\mathrm{Poisson}(\lambda)$ with $\lambda\sim\mathrm{Gamma}(\alpha_0,\beta_0)$ (shape, rate) |
| **10.16** | Theorem | conjugate prior for an exponential family; hyperparameters as pseudo-counts | Let the model be a natural exponential family in canonical form (Ch |
| **10.17** | Corollary | predictive distributions are over-dispersed | Write $\hat\theta:=\mathbb{E}[\theta\mid D]$ and let $\tilde X$ have posterior predictive variance $V:=\operatorname{Var}(\tilde X\mid D)$, to be compared with the plug-in variance $v(\hat\theta)$ |
| **10.18** | Proposition | priors transform as measures | Let $\Theta\subseteq\mathbb{R}^d$ be open, let $g:\Theta\to\Phi\subseteq\mathbb{R}^d$ be a $C^1$ diffeomorphism, and let $\theta$ have prior density $\pi_\theta$ with respect to $\lambda_d$ |
| **10.20** | Theorem | reparameterization invariance of the Jeffreys prior | Let $g:\Theta\to\Phi$ be a $C^1$ diffeomorphism and $\phi=g(\theta)$ |
| **10.21** | Proposition | propriety of the posterior | Let $\pi\ge0$ be a measurable, possibly non-integrable prior density and let $Z(x)=\int p(x\mid\theta)\pi(\theta)\mathrm{d}\theta$ |
| **10.22** | Proposition | weight decay is a Gaussian prior; $\ell_1$ is a Laplace prior | Consider a model with likelihood $p(y\mid x,\theta)$ and let $D=\{(x_i,y_i)\}_{i=1}^n$ |
| **10.24** | Theorem | Gaussian hierarchical model | Suppose group $j$ yields a summary $y_j$ with known sampling variance $s_j^2$, $$ y_j\mid\theta_j\sim \mathcal{N}(\theta_j,s_j^2)\ \text{ independently},\qquad \theta_j\mid\mu,\tau^2\overset{iid}{\sim}\mathc… |
| **10.25** | Corollary | the shrinkage factor, and James–Stein | In Theorem 10.24, group $j$'s estimate is pulled toward the population mean by the fraction $$ B_j=\frac{s_j^2}{s_j^2+\tau^2}=\frac{1/n_j}{1/n_j+\tau^2/\sigma^2}\quad\text{when }s_j^2=\sigma^2/n_j, $$ so: (a… |
| **10.28** | Proposition | evidence as a prequential score; automatic Occam | For any Bayesian model and data $D=(x_1,\dots,x_n)$: (i) $\displaystyle \log p(D\mid M)=\sum_{k=1}^{n}\log p(x_k\mid x_1,\dots,x_{k-1},M)$: the log-evidence is the total log-loss of the model's honest sequen… |
| **10.29** | Proposition | Jeffreys–Lindley | Let $\bar X\mid\mu\sim \mathcal{N}(\mu,\sigma^2/n)$ with $\sigma^2$ known, and compare $M_0:\mu=0$ against $M_1:\mu\sim \mathcal{N}(0,\tau^2)$ |
| **10.30** | Theorem | Laplace approximation to the evidence | Let $\Theta\subseteq\mathbb{R}^d$ be open and let $q(\theta):=p(D\mid\theta)\pi(\theta)=\exp\{n g_n(\theta)\}$ for data $D=(x_1,\dots,x_n)$ i.i.d., where $g_n\to g$ uniformly on compacts with $g$ three times… |
| **10.31** | Corollary | BIC | In the i.i.d. setting with $\hat\theta\to\theta_0$ and $H=nI(\theta_0)(1+o_P(1))$, and with a prior density continuous and positive at $\theta_0$, $$ \log Z=\ell(\hat\theta)-\frac d2\log n+O_P(1), \qquad \ma… |
| **10.33** | Theorem | posterior | With the model above, $$ \theta\mid y\ \sim\ \mathcal{N}(m,\ \Sigma),\qquad \Sigma=\Big(\frac{\Phi^{\!\top}\Phi}{\sigma^2}+\frac{I_d}{\tau^2}\Big)^{-1},\qquad m=\Sigma\,\frac{\Phi^{\!\top}y}{\sigma^2} |
| **10.34** | Corollary | the posterior mean is the ridge estimator | With $\lambda:=\sigma^2/\tau^2$, $$ m=\big(\Phi^{\!\top}\Phi+\lambda I_d\big)^{-1}\Phi^{\!\top}y=\hat\theta^{\text{ridge}}_\lambda , $$ and $m$ is also the MAP estimate, since the posterior is Gaussian (mean… |
| **10.35** | Proposition | posterior predictive and its variance decomposition | For a new input with features $\varphi_*:=\varphi(x_*)$, the posterior predictive of $y_*=\varphi_*^{\!\top}\theta+\varepsilon$, $\varepsilon\sim \mathcal{N}(0,\sigma^2)$ independent, is $$ y_*\mid y\ \sim\… |
| **10.36** | Proposition | evidence for Bayesian linear regression | Under the model of §10.6.1, $$ y\ \sim\ N\big(0,\ \sigma^2I_n+\tau^2\Phi\Phi^{\!\top}\big), $$ so with $A=\Phi^{\!\top}\Phi/\sigma^2+I_d/\tau^2$ and $m=A^{-1}\Phi^{\!\top}y/\sigma^2$, $$ \log p(y)= -\frac{n}… |
| **10.37** | Proposition | Laplace prior: soft-thresholded MAP, non-sparse posterior mean | Consider the scalar case $y\mid\theta\sim \mathcal{N}(\theta,s^2)$ with prior density $\pi(\theta)=\frac{1}{2b}e^{-|\theta|/b}$ on $\mathbb{R}$ |
| **10.38** | Theorem | Laplace approximation to a posterior | Let $q(\theta)=p(D\mid\theta)\pi(\theta)$ satisfy the hypotheses of Theorem 10.30, with mode $\hat\theta$ interior and $H=-\nabla^2\log q(\hat\theta)\succ0$ |
| **10.41** | Theorem | your loss selects your summary | Let $\theta$ be real-valued with posterior $\Pi(\cdot\mid D)$ and $\mathcal{A}=\mathbb{R}$ |
| **10.42** | Proposition | asymmetric linear loss $\to$ posterior quantile | Let $c_u,c_o>0$ and $$ L(\theta,a)=c_u(\theta-a)_++c_o(a-\theta)_+ , $$ so under-shooting costs $c_u$ per unit and over-shooting $c_o$ per unit |
| **10.43** | Corollary | optimal decision threshold | Let $\theta\in\{0,1\}$ (disease present or not), $\mathcal{A}=\{\text{act},\text{don't act}\}$, and losses $L(1,\text{don't act})=c_{FN}$, $L(0,\text{act})=c_{FP}$, $L(1,\text{act})=L(0,\text{don't act})=0$ |

## Chapter 11 — Information Theory

| No. | Kind | Name | Statement |
|---|---|---|---|
| **11.2** | Proposition | range and extremes | Let $\mathcal{X}$ be finite with $|\mathcal{X}| = k$ |
| **11.3** | Lemma | *(unnamed)* | Let $A:\mathbb{N}_{\ge 1}\to[0,\infty)$ be non-decreasing with $A(1)=0$ and $A(mn)=A(m)+A(n)$ for all $m,n\ge 1$ |
| **11.4** | Theorem | Shannon's characterisation | Let $H_k(p_1,\dots,p_k)$ be defined for every $k\ge 1$ and every probability vector, and suppose: 1 |
| **11.6** | Theorem | chain rule | $H(X,Y) = H(X) + H(Y\mid X)$, and more generally $$H(X_1,\dots,X_n) = \sum_{i=1}^n H(X_i \mid X_1,\dots,X_{i-1}).$$ *Proof.* Factor $p(x,y) = p(x)p(y\mid x)$ and split the logarithm: $$H(X,Y) = -\sum_{x,y}p(… |
| **11.7** | Proposition | conditioning reduces entropy; functions lose entropy | For discrete variables: 1. $0 \le H(Y\mid X) \le H(Y)$, with the right equality iff $X \perp Y$ (the independence definition, Ch |
| **11.8** | Proposition | concavity | On the simplex of distributions over a fixed finite $\mathcal{X}$, the map $P \mapsto H(P)$ is concave: for $\lambda\in[0,1]$, $H(\lambda P + (1-\lambda)Q) \ge \lambda H(P) + (1-\lambda)H(Q)$ |
| **11.9** | Theorem | maximum entropy under moment constraints | Let $\mu$ be a $\sigma$-finite base measure on $\mathcal{X}$, let $T:\mathcal{X}\to\mathbb{R}^m$ be measurable, and let $\tau\in\mathbb{R}^m$ |
| **11.11** | Proposition | standard differential entropies | In nats: $$h(\mathrm{Unif}[0,a]) = \log a, \qquad h(\mathcal{N}(\mu,\sigma^2)) = \tfrac12\log(2\pi e\sigma^2), \qquad h\bigl(\mathcal{N}(m,\Sigma)\bigr) = \tfrac12\log\bigl((2\pi e)^d\det\Sigma\bigr),$$ $$h(… |
| **11.12** | Theorem | differential entropy under a diffeomorphism | Let $X$ have density $p_X$ on an open set $U\subseteq\mathbb{R}^d$, and let $T:U\to V$ be a $C^1$ diffeomorphism with Jacobian matrix $J_T(x)$ |
| **11.13** | Proposition | quantisation | Let $X$ have a density $p$ on $\mathbb{R}^d$ that is bounded, compactly supported, and continuous outside a Lebesgue-null set |
| **11.14** | Theorem | the Gaussian maximises $h$ at fixed covariance | Let $P$ on $\mathbb{R}^d$ have density $q$, mean $m$, and covariance $\Sigma \succ 0$ |
| **11.15** | Proposition | reparameterisation invariance | Let $T:\mathcal{X}\to\mathcal{Y}$ be a bimeasurable bijection (measurable with measurable inverse) between measurable spaces |
| **11.17** | Theorem | Gibbs' inequality | $D_{\mathrm{KL}}(P\Vert Q)\ge 0$, with equality if and only if $P = Q$ |
| **11.18** | Proposition | KL is not a metric | In general $D_{\mathrm{KL}}(P\Vert Q)\ne D_{\mathrm{KL}}(Q\Vert P)$, and the triangle inequality fails |
| **11.20** | Proposition | the decomposition | Whenever the terms are finite, $$H_\mu(P,Q) = H_\mu(P) + D_{\mathrm{KL}}(P\Vert Q) .$$ Hence for fixed $P$, minimising cross-entropy over $Q$ is exactly minimising $D_{\mathrm{KL}}(P\Vert Q)$, and the minimu… |
| **11.21** | Proposition | MLE $=$ minimising KL to the empirical distribution | Let $x_1,\dots,x_n$ be observations in a countable space (or in $\mathbb{R}^d$ with a fixed base measure $\mu$ and $P_\theta\ll\mu$), and $\hat P_n = \frac1n\sum_i \delta_{x_i}$ the empirical distribution |
| **11.22** | Proposition | label smoothing | Fix $K\ge2$ classes, a true class $y$, and $\varepsilon\in[0,1)$ |
| **11.23** | Proposition | KL is locally the Fisher quadratic form | Let $\{P_\theta:\theta\in\Theta\}$, with $\Theta\subseteq\mathbb{R}^k$ open, have densities $p_\theta>0$ $\mu$-a.e |
| **11.25** | Proposition | three equivalent expressions | 1. Always: $I(X;Y) = \mathbb{E}_{X}\bigl[D_{\mathrm{KL}}(P_{Y\mid X}\Vert P_Y)\bigr]$, the average amount by which learning $X$ moves your belief about $Y$ |
| **11.26** | Theorem | properties | For any random elements: 1. **Non-negativity with a sharp equality case:** $I(X;Y)\ge 0$, with equality iff $X\perp Y$ |
| **11.27** | Proposition | Gaussian mutual information | Let $(X,Y)$ be jointly Gaussian in $\mathbb{R}^{d_1}\times\mathbb{R}^{d_2}$ with covariance blocks $\Sigma_{XX},\Sigma_{YY},\Sigma_{XY}$ and joint covariance $\Sigma$, all non-singular |
| **11.28** | Theorem | data processing inequality for mutual information | Suppose $X \to Y \to Z$ is a Markov chain, i.e |
| **11.30** | Proposition | non-negativity and identifiability | $D_f(P\Vert Q)\ge 0$ always. If $f$ is strictly convex at $t=1$ (i.e |
| **11.31** | Theorem | joint convexity | $(P,Q)\mapsto D_f(P\Vert Q)$ is jointly convex: for $\lambda\in[0,1]$, $$D_f\bigl(\lambda P_1 + (1-\lambda)P_2 \,\Vert\, \lambda Q_1 + (1-\lambda)Q_2\bigr) \le \lambda D_f(P_1\Vert Q_1) + (1-\lambda)D_f(P_2\… |
| **11.32** | Theorem | data processing inequality for $f$-divergences | Let $K$ be a Markov kernel (a "channel") from $\mathcal{X}$ to $\mathcal{Y}$, and write $PK$ for the law of the output when the input is drawn from $P$ |
| **11.33** | Theorem | Donsker–Varadhan | Let $P,Q$ be probability measures on $\mathcal{X}$ |
| **11.34** | Theorem | Fenchel / $f$-GAN variational lower bound | Let $f$ be as in Definition 11.29 with convex conjugate $f^*(s) := \sup_{t>0}\{st - f(t)\}$ |
| **11.36** | Proposition | three faces of TV | Let $\mu$ dominate both $P$ and $Q$, with densities $p,q$ |
| **11.37** | Proposition | TV is exactly the testing advantage | Consider deciding between $H_0: X\sim P$ and $H_1: X\sim Q$ from a single observation, using a (possibly randomised) test |
| **11.38** | Theorem | Pinsker's inequality | For all $P,Q$: $\quad\mathrm{TV}(P,Q) \le \sqrt{\tfrac12 D_{\mathrm{KL}}(P\Vert Q)}$ |
| **11.39** | Theorem | coupling characterisation; maximal coupling | Let $\Pi(P,Q)$ denote the set of **couplings** of $P$ and $Q$: joint laws $\pi$ on $\mathcal{X}\times\mathcal{X}$ with marginals $P$ and $Q$ |
| **11.41** | Theorem | Kantorovich duality, stated | With $\mathcal{X}$ Polish and $c(x,y)$ lower semicontinuous and non-negative, $$\inf_{\pi\in\Pi(P,Q)}\int c\,\mathrm{d}\pi = \sup\left\{\int \varphi\,\mathrm{d}P + \int\psi\,\mathrm{d}Q \ :\ \varphi(x)+\psi(… |
| **11.42** | Theorem | transport on the line | Let $P,Q$ be probability measures on $\mathbb{R}$ with CDFs $F,G$ and quantile functions $F^{-1},G^{-1}$ (generalised inverses) |
| **11.43** | Proposition | every $f$-divergence is constant on mutually singular pairs | Suppose $P$ and $Q$ are mutually singular |
| **11.44** | Proposition | transport sees the gap: the two parallel segments | In $\mathbb{R}^2$ with the Euclidean metric, let $$P := \text{law of }(0,U),\qquad Q_\alpha := \text{law of }(\alpha,U),\qquad U\sim\mathrm{Unif}[0,1].$$ Then $P\perp Q_\alpha$ for every $\alpha\ne0$, so $\m… |
| **11.45** | Theorem | Kraft's inequality | (a) Every prefix-free code satisfies $\sum_{x\in\mathcal{X}} D^{-\ell(x)}\le 1$ |
| **11.46** | Theorem | source coding, single-symbol version | Let $X\sim p$ on a finite $\mathcal{X}$ and let $L^\star := \min\{\mathbb{E}[\ell(X)] : \text{prefix-free codes}\}$ |
| **11.47** | Proposition | asymptotic equipartition property | Let $X_1,X_2,\dots$ be i.i.d. with pmf $p$ on a finite alphabet, and write $p(x^n) := \prod_{i=1}^n p(x_i)$ |
| **11.48** | Proposition | the redundancy of a wrong code is exactly a KL divergence | Suppose you build an (idealised, fractional-length) code for the distribution $q$, assigning length $-\log_D q(x)$, but the data is actually distributed as $p$ |
| **11.50** | Proposition | scale conversion, and why reported bpd is an upper bound | Let $p$ be a density on $\mathbb{R}^d$ modelling images rescaled to $x = \tilde x/s$ for a scale factor $s>0$ (typically $s=256$), and let $$\tilde P(\tilde x) := \int_{[0,1)^d} p_{\tilde X}(\tilde x+u)\,\ma… |
| **11.51** | Theorem | Fano's inequality | Let $X$ take values in a finite set $\mathcal{X}$ with $|\mathcal{X}| = M \ge 2$, let $X \to Y \to \hat X$ be a Markov chain (so $\hat X$ is any estimator computed from $Y$ alone, possibly randomised), and l… |
| **11.52** | Corollary | information floor on classification accuracy | Let $Y$ take $M\ge2$ values with *any* distribution, let $Z$ be any representation such that $Y\to X\to Z$ is a Markov chain, and let $\hat Y$ be any (possibly randomised) classifier computed from $Z$ |
| **11.53** | Corollary | Fano's method | Let $\theta_1,\dots,\theta_M\in\Theta$ be $2s$-separated, i.e |
| **11.54** | Proposition | Le Cam's two-point method | Let $\theta_0,\theta_1\in\Theta$ with $d(\theta_0,\theta_1)\ge 2s$, and let $P_0,P_1$ be the corresponding laws of the data |
| **11.55** | Proposition | rate, distortion, and the sandwich on mutual information | Let $P_X$ be the data distribution with (Shannon or differential) entropy $H(X)$, let $q(z\mid x)$ be an encoder, $p(x\mid z)$ a decoder, and $p(z)$ a prior |

## Chapter 12 — High-Dimensional Probability

| No. | Kind | Name | Statement |
|---|---|---|---|
| **12.1** | Proposition | *(unnamed)* | For every $d\ge 1$ and $r>0$, $$V_d(r) = \frac{\pi^{d/2}}{\Gamma\!\big(\tfrac d2+1\big)}\, r^d .$$ Consequently: 1 |
| **12.2** | Proposition | *(unnamed)* | Let $U, V$ be independent and uniform on the unit sphere $S^{d-1}\subset\mathbb{R}^d$, and let $T = \langle U,V\rangle = \cos\Theta$ where $\Theta\in[0,\pi]$ is the angle between them |
| **12.3** | Proposition | *(unnamed)* | Let $Z\sim\mathcal{N}(0,I_d)$ |
| **12.4** | Lemma | chi-square moment generating function and tails | Let $W\sim\chi^2_d$. Then $\mathbb{E}[e^{sW}] = (1-2s)^{-d/2}$ for $s<\tfrac12$, and for every $t>0$ $$\mathbb{P}\big(W \ge d + 2\sqrt{dt}+2t\big)\le e^{-t},\qquad \mathbb{P}\big(W\le d-2\sqrt{dt}\big)\le e^… |
| **12.5** | Theorem | Gaussian annulus theorem | Let $Z\sim\mathcal{N}(0,I_d)$ |
| **12.6** | Theorem | norm concentration for sub-Gaussian vectors | Let $X=(X_1,\dots,X_d)$ have independent coordinates with $\mathbb{E}X_i=0$, $\mathbb{E}X_i^2=1$, and sub-Gaussian norm $\|X_i\|_{\psi_2}\le K$ (Ch |
| **12.7** | Theorem | Gaussian Lipschitz concentration; Borell, Tsirelson–Ibragimov–Sudakov | Let $Z\sim\mathcal{N}(0,I_d)$ and let $f:\mathbb{R}^d\to\mathbb{R}$ be $L$-Lipschitz with respect to the Euclidean norm, i.e |
| **12.8** | Corollary | *(unnamed)* | Taking $f(x)=\|x\|$, which is $1$-Lipschitz by the triangle inequality: $\operatorname{Var}(\|Z\|)\le1$ and $\mathbb{P}(|\|Z\|-\mathbb{E}\|Z\||\ge t)\le2e^{-t^2/2}$, recovering Proposition 12.3's variance bo… |
| **12.10** | Theorem | Gaussian isoperimetric inequality | Let $\gamma_d=\mathcal{N}(0,I_d)$ on $\mathbb{R}^d$ |
| **12.11** | Corollary | Lévy's lemma on the sphere | Let $\mu$ be the uniform probability measure on $S^{d-1}$ and $f:S^{d-1}\to\mathbb{R}$ be $L$-Lipschitz in the geodesic (or Euclidean) metric |
| **12.12** | Theorem | Talagrand's convex distance inequality | Let $X=(X_1,\dots,X_d)$ have independent coordinates with $X_i\in[0,1]$, and let $f:[0,1]^d\to\mathbb{R}$ be convex and $L$-Lipschitz |
| **12.13** | Theorem | distance concentration for i.i.d. coordinates | Let $X^{(1)},\dots,X^{(n)},Q$ be i.i.d |
| **12.15** | Proposition | contrast is governed by intrinsic, not ambient, dimension | Let $\Psi:\mathbb{R}^k\to\mathbb{R}^d$ be bi-Lipschitz with constants $0<\alpha\le\beta<\infty$, i.e |
| **12.16** | Lemma | distributional Johnson–Lindenstrauss | Let $R\in\mathbb{R}^{k\times d}$ have i.i.d |
| **12.17** | Theorem | Johnson–Lindenstrauss lemma | Let $x_1,\dots,x_n\in\mathbb{R}^d$, let $\varepsilon\in(0,1)$ and $\delta\in(0,1)$, and let $$k\ \ge\ \frac{8}{\varepsilon^{2}}\Big(2\log n+\log\tfrac1\delta\Big).$$ Let $R\in\mathbb{R}^{k\times d}$ have i.i.d |
| **12.18** | Corollary | inner products are preserved too | Under the hypotheses of Theorem 12.17 applied to the $2n$ vectors $\{x_i\}\cup\{x_i/\|x_i\|\}$ — or more simply, applied to all sums and differences $x_i\pm x_j$ — we get, with probability $\ge1-\delta$, $$\… |
| **12.19** | Theorem | Marchenko–Pastur | Let $A\in\mathbb{R}^{n\times d}$ have i.i.d |
| **12.20** | Theorem | Bai–Yin edge behaviour | Under the hypotheses of Theorem 12.19 with finite fourth moment, the extreme singular values of $A$ satisfy, almost surely, $$s_{\max}(A)\to 1+\sqrt\gamma,\qquad s_{\min}(A)\to 1-\sqrt\gamma\quad(\gamma<1).$… |
| **12.21** | Theorem | Wigner semicircle law | Let $M\in\mathbb{R}^{d\times d}$ be symmetric with i.i.d |
| **12.22** | Lemma | net-to-norm | Let $A\in\mathbb{R}^{n\times d}$, let $\varepsilon\in(0,\tfrac12)$, and let $\mathcal{N}\subseteq S^{d-1}$, $\mathcal{M}\subseteq S^{n-1}$ be $\varepsilon$-nets |
| **12.23** | Theorem | operator norm of a Gaussian matrix | Let $B\in\mathbb{R}^{n\times d}$ have i.i.d |
| **12.24** | Theorem | Matrix Bernstein | Let $X_1,\dots,X_N$ be independent, mean-zero, symmetric $d\times d$ random matrices with $\|X_i\|\le K$ almost surely, and let $\sigma^2 := \big\|\sum_i\mathbb{E}X_i^2\big\|$ |
| **12.25** | Proposition | *(unnamed)* | Let $W\in\mathbb{R}^{n_{\text{out}}\times n_{\text{in}}}$ have i.i.d |
| **12.26** | Proposition | spectral error of the sample covariance | Suppose $X_i\sim\mathcal{N}(0,\Sigma)$ and $\gamma=d/n$ |
| **12.28** | Proposition | the oracle intensity | Write $\mu := \mathrm{tr}(\Sigma)/d$, $\alpha^2:=\|\Sigma-\mu I\|_F^2$ and $\beta^2:=\mathbb{E}\|\hat\Sigma-\Sigma\|_F^2$ |
| **12.29** | Theorem | BBP phase transition; eigenvector overlap | In the spiked model with $d/n\to\gamma\in(0,1]$, almost surely: 1 |

## Chapter 13 — Monte Carlo, Variational Inference, and Generative Models

| No. | Kind | Name | Statement |
|---|---|---|---|
| **13.2** | Proposition | unbiasedness, variance, and the $n^{-1/2}$ law | Suppose $\mathbb{E}|f(X)| < \infty$ |
| **13.3** | Proposition | Monte Carlo error bars | Assume $\sigma^2 \in (0,\infty)$ and let $s_n^2 := \frac{1}{n-1}\sum_i (f(X_i) - \hat\theta_n)^2$ |
| **13.4** | Proposition | importance sampling: unbiasedness and variance | Let $P \ll Q$, $w = dP/dQ$, and $\hat\theta_n^{\mathrm{IS}} := \frac1n \sum_i f(Y_i) w(Y_i)$ with $Y_i \sim Q$ i.i.d |
| **13.5** | Proposition | optimal proposal | Among all $Q$ with $P \ll Q$, the variance of $\hat\theta_n^{\mathrm{IS}}$ is minimized by $$ q^\star(x) \;\propto\; |f(x)|\, p(x), $$ and if $f \ge 0$ the minimal variance is zero |
| **13.8** | Proposition | control variates | Let $h$ be measurable with known mean $\mathbb{E}[h(X)] = \eta$ and finite variance |
| **13.9** | Proposition | antithetic variates | Let $U \sim \mathrm{Unif}(0,1)^d$ and let $\tilde U := \mathbb{1} - U$ (componentwise) |
| **13.10** | Proposition | stratification never hurts | Partition $\mathcal X = \biguplus_{k=1}^K S_k$ with $p_k := P(X \in S_k) > 0$ known |
| **13.12** | Theorem | correctness and cost | The output of the rejection sampler has law exactly $P$; the acceptance probability at each trial is $1/M$; and the number of trials until the first acceptance is $\mathrm{Geometric}(1/M)$ with mean $M$, ind… |
| **13.13** | Proposition | the curse, quantified for two canonical cases | (i) Let $P = \mathcal{N}(0, I_d)$ and $Q = \mathcal{N}(0, s^2 I_d)$ with $s > 1$ |
| **13.17** | Proposition | detailed balance implies invariance | If $K$ is reversible w.r.t. $\pi$ then $\pi$ is invariant for $K$ |
| **13.19** | Theorem | ergodic theorem for Harris chains; stated, not proved | Let $K$ have invariant probability measure $\pi$, and suppose the chain is $\pi$-irreducible, aperiodic, and Harris recurrent |
| **13.21** | Theorem | MH is reversible w.r.t. $\pi$, hence leaves $\pi$ invariant | The kernel of Definition 13.20 satisfies detailed balance with respect to $\pi$, and therefore $\pi K = \pi$ |
| **13.22** | Proposition | Gibbs sampling is MH with acceptance 1 | Partition $x = (x_1,\dots,x_m)$ into blocks and let the proposal replace block $i$ by a draw from the exact conditional $\pi(x_i \mid x_{-i})$, leaving $x_{-i}$ fixed |
| **13.24** | Proposition | leapfrog is volume-preserving and reversible | Let $T_\epsilon$ be one leapfrog step and $F(x,p) := (x,-p)$ |
| **13.25** | Theorem | HMC leaves $\pi$ invariant | The HMC kernel of Definition 13.23 is reversible with respect to the joint density $\propto e^{-H}$, hence leaves it invariant; consequently its $x$-marginal leaves $\pi$ invariant |
| **13.26** | Proposition | Langevin invariance, formal computation | Suppose $\pi$ is a positive $C^2$ density on $\mathbb{R}^d$ and let $\rho_t$ solve the associated Fokker–Planck equation $\partial_t\rho = -\nabla\!\cdot\!\big(\tfrac12\rho\nabla\log\pi\big) + \tfrac12\Delta… |
| **13.27** | Proposition | ULA's bias, exactly, on a Gaussian | Let $\pi = \mathcal{N}(0,1)$, so $\nabla\log\pi(x) = -x$ |
| **13.28** | Proposition | constant-step SGD on a quadratic, exactly | Let $U(\theta) = \frac a2\theta^2$ with $a>0$ and suppose the stochastic gradient is $\hat g(\theta) = a\theta + s\xi$, $\xi\sim \mathcal{N}(0,1)$ i.i.d |
| **13.31** | Theorem | three derivations of the same object | Assume the expectations below exist (possibly $-\infty$) |
| **13.33** | Proposition | CAVI update and monotone ascent | Fix all factors but the $j$th |
| **13.34** | Proposition | mean-field on a correlated Gaussian | Let $p = \mathcal{N}(0,\Sigma)$ on $\mathbb R^2$ with $\Sigma = \begin{pmatrix}1&\rho\\\rho&1\end{pmatrix}$, $|\rho|<1$, and let $q = q_1\otimes q_2$ minimize $D_{\mathrm{KL}}(q\|p)$ over product distributions |
| **13.36** | Proposition | the reparameterized gradient | With $q_\phi(z\mid x) = \mathcal{N}(\mu_\phi(x), \operatorname{diag}\sigma^2_\phi(x))$, write $Z = T_\phi(x,\varepsilon) := \mu_\phi(x) + \sigma_\phi(x)\odot\varepsilon$ with $\varepsilon\sim \mathcal{N}(0,I… |
| **13.37** | Proposition | collapse is an optimum, not a bug | Suppose the decoder is such that $p_\theta(x \mid z) = p_\theta(x)$ does not depend on $z$ (for instance, the decoder weights on $z$ are zero) |
| **13.38** | Proposition | importance-weighted ELBO | For $K \ge 1$ define $$ \mathcal L_K := \mathbb{E}_{Z_1,\dots,Z_K \sim q}\Big[\log\frac1K\sum_{j=1}^K \frac{p(x,Z_j)}{q(Z_j)}\Big] |
| **13.40** | Proposition | score matching / integration by parts | Let $p$ be a positive $C^1$ density on $\mathbb R^d$ with $\mathbb{E}_p\|\nabla\log p\|^2 < \infty$, and let $s_\theta$ be $C^1$ with $p(x)\,s_\theta(x) \to 0$ as $\|x\|\to\infty$ and suitable integrability |
| **13.41** | Proposition | denoising score matching; Vincent's identity | Let $X \sim P_{\mathrm{data}}$ (any distribution, no density needed), let $\varepsilon\sim \mathcal{N}(0,I_d)$ independent, fix $\sigma>0$, and let $\tilde X := X + \sigma\varepsilon$ with law $P_\sigma$, wh… |
| **13.43** | Proposition | closed-form marginals | For every $t$, $q(x_t\mid x_0) = N\big(x_t; \sqrt{\bar\alpha_t}\,x_0,\ (1-\bar\alpha_t)I\big)$ |
| **13.44** | Proposition | the forward posterior is Gaussian and computable | For $t\ge1$, $$ q(x_{t-1}\mid x_t, x_0) = N\big(x_{t-1};\ \tilde\mu_t(x_t,x_0),\ \tilde\beta_t I\big), $$ $$ \tilde\mu_t(x_t,x_0) = \frac{\sqrt{\alpha_t}(1-\bar\alpha_{t-1})}{1-\bar\alpha_t}x_t + \frac{\sqrt… |
| **13.45** | Theorem | the DDPM training objective | With $q$ as in Definition 13.42 and $p_\theta$ as above, $$ -\log p_\theta(x_0) \;\le\; \underbrace{D_{\mathrm{KL}}\big(q(x_T\mid x_0)\|p(x_T)\big)}_{L_T:\ \text{no parameters}} + \sum_{t=2}^{T}\underbrace{\… |
| **13.46** | Proposition | probability-flow ODE; stated | The *deterministic* dynamics $$ \frac{dx}{dt} = -\tfrac12\beta(t)\Big[x + \nabla_x\log q_t(x)\Big] $$ has the same time-marginals $q_t$ as the SDE above |
| **13.51** | Proposition | calibration–refinement decomposition | Let $\hat p$ be a predictor with a discrete set of possible outputs, and for each output value $q$ let $\pi_q := P(Y = \cdot \mid \hat p(X) = q)$ be the true conditional class distribution given that report |
| **13.52** | Proposition | binned ECE is biased upward | Let $\hat p$ be perfectly calibrated |
| **13.54** | Theorem | split-conformal coverage | Let $(X_1,Y_1),\dots,(X_n,Y_n),(X_{n+1},Y_{n+1})$ be exchangeable |

