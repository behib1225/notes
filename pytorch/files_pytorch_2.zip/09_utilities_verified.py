"""Every helper the tutorial shows outside the main narrative, in one runnable file.
All of it executed on torch 2.14.0 / torchvision 0.29.0, CPU. Run: python 09_utilities_verified.py
"""
import math, time, random
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, TensorDataset, WeightedRandomSampler

torch.manual_seed(0)
sec = lambda s: print(f"\n--- {s} " + "-" * (58 - len(s)))


# --------------------------------------------------------------- nn.Linear by hand
class MyLinear(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features, self.out_features = in_features, out_features
        self.weight = nn.Parameter(torch.empty(out_features, in_features))  # (out, in)
        if bias:
            self.bias = nn.Parameter(torch.empty(out_features))
        else:
            self.register_parameter("bias", None)      # keeps the name in the namespace
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        if self.bias is not None:
            bound = 1 / math.sqrt(self.in_features)
            nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x):
        return x @ self.weight.T + (self.bias if self.bias is not None else 0)

    def extra_repr(self):
        return f"in_features={self.in_features}, out_features={self.out_features}"


# --------------------------------------------------------- gradient reversal layer
class GradReverse(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = lambd
        return x.view_as(x)                    # identity forward

    @staticmethod
    def backward(ctx, g):
        return -ctx.lambd * g, None            # None for lambd, which needs no gradient


# ------------------------------------------------------ variable-length collate fn
def pad_collate(batch):
    from torch.nn.utils.rnn import pad_sequence
    seqs, labels = zip(*batch)
    lengths = torch.tensor([len(s) for s in seqs])
    padded = pad_sequence(seqs, batch_first=True, padding_value=0)   # (B, T_max)
    return padded, lengths, torch.tensor(labels)


# ------------------------------------------------------------------- dataset stats
def channel_stats(loader):
    """Mean and std per channel. Compute on the TRAINING split only."""
    n_pixels, total, total_sq = 0, torch.zeros(3), torch.zeros(3)
    for x, _ in loader:
        b, c, h, w = x.shape
        x = x.permute(1, 0, 2, 3).reshape(c, -1)
        total += x.sum(dim=1)
        total_sq += (x ** 2).sum(dim=1)
        n_pixels += b * h * w
    mean = total / n_pixels
    return mean, (total_sq / n_pixels - mean ** 2).sqrt()


# ----------------------------------------------------------------- learning rate
def lr_range_test(model_fn, loader, criterion, lo=1e-7, hi=10.0, steps=100):
    model = model_fn()
    opt = torch.optim.SGD(model.parameters(), lr=lo)
    mult = (hi / lo) ** (1 / steps)
    lrs, losses, best = [], [], float("inf")
    it = iter(loader)
    for _ in range(steps):
        try:
            xb, yb = next(it)
        except StopIteration:
            it = iter(loader); xb, yb = next(it)
        opt.zero_grad(set_to_none=True)
        loss = criterion(model(xb), yb)
        loss.backward()
        opt.step()
        lrs.append(opt.param_groups[0]["lr"]); losses.append(loss.item())
        best = min(best, loss.item())
        if not torch.isfinite(loss) or loss.item() > 4 * best:
            break
        for g in opt.param_groups:
            g["lr"] *= mult
    return lrs, losses


# ---------------------------------------------------------------------- metrics
def precision_recall_f1(cm):
    tp = cm.diag().float()
    precision = tp / cm.sum(0).clamp_min(1)
    recall = tp / cm.sum(1).clamp_min(1)
    f1 = 2 * precision * recall / (precision + recall).clamp_min(1e-12)
    return precision, recall, f1


def top_confusions(cm, k=3):
    off = cm.clone(); off.fill_diagonal_(0)
    top = torch.topk(off.flatten(), k)
    return [(int(i) // len(cm), int(i) % len(cm), int(v))
            for v, i in zip(top.values, top.indices)]


@torch.no_grad()
def topk_accuracy(logits, target, ks=(1, 5)):
    _, pred = logits.topk(max(ks), dim=1)
    correct = pred.eq(target.view(-1, 1))
    return {k: correct[:, :k].any(dim=1).float().mean().item() for k in ks}


# ------------------------------------------------------------------- inspection
def show_batch(xb, mean, std, n=8):
    """Undo Normalize and display. Needs matplotlib; see the tutorial §11.2."""
    import matplotlib.pyplot as plt
    mean = torch.tensor(mean).view(1, -1, 1, 1)
    std = torch.tensor(std).view(1, -1, 1, 1)
    imgs = (xb[:n].cpu() * std + mean).clamp(0, 1).permute(0, 2, 3, 1)
    fig, axes = plt.subplots(1, n, figsize=(2 * n, 2))
    for ax, im in zip(np.atleast_1d(axes), imgs):
        ax.imshow(im.squeeze()); ax.axis("off")
    plt.show()


def param_report(model):
    rows, total = [], 0
    for name, m in model.named_modules():
        n = sum(p.numel() for p in m.parameters(recurse=False))   # recurse=False!
        if n:
            rows.append((name or "<root>", m.__class__.__name__, n)); total += n
    w = max(len(r[0]) for r in rows)
    for name, cls, n in rows:
        print(f"  {name:<{w}}  {cls:<14} {n:>9,}  ({100*n/total:5.1f}%)")
    print(f"  {'TOTAL':<{w}}  {'':<14} {total:>9,}")


def freeze_bn(m):
    """Call model.apply(freeze_bn) AFTER model.train() when the backbone is frozen."""
    if isinstance(m, nn.modules.batchnorm._BatchNorm):
        m.eval()


def latency(model, device, n=50, shape=(1, 3, 32, 32)):
    model.eval().to(device)
    x = torch.randn(*shape, device=device)
    with torch.inference_mode():
        for _ in range(10):                      # warm-up: autotune, memory pool, JIT
            model(x)
        if device.type == "cuda":
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        for _ in range(n):
            model(x)
        if device.type == "cuda":
            torch.cuda.synchronize()
    return (time.perf_counter() - t0) / n * 1000


if __name__ == "__main__":
    sec("MyLinear")
    m = MyLinear(4, 3); print(" ", m, "->", tuple(m(torch.randn(2, 4)).shape))
    print("  bias=False keeps the name:", MyLinear(4, 3, bias=False).bias)

    sec("GradReverse")
    x = torch.randn(3, requires_grad=True)
    GradReverse.apply(x, 2.0).sum().backward()
    print("  gradient is negated and scaled:", x.grad.tolist())

    sec("pad_collate")
    p, l, y = pad_collate([(torch.arange(n), n % 3) for n in (3, 7, 5)])
    print("  padded", tuple(p.shape), "| lengths", l.tolist())

    sec("WeightedRandomSampler on a 9:1 imbalance")
    labels = torch.tensor([0] * 900 + [1] * 100)
    w = (1.0 / torch.bincount(labels).float())[labels]
    dl = DataLoader(TensorDataset(torch.randn(1000, 4), labels), batch_size=1000,
                    sampler=WeightedRandomSampler(w, len(labels), replacement=True))
    _, yb = next(iter(dl))
    print(f"  positives before 0.100 -> after {yb.float().mean():.3f}")

    sec("channel_stats")
    imgs = torch.rand(64, 3, 8, 8) * torch.tensor([0.5, 1.0, 0.25]).view(1, 3, 1, 1)
    mn, sd = channel_stats(DataLoader(TensorDataset(imgs, torch.zeros(64)), batch_size=16))
    print("  mean", [round(v, 4) for v in mn.tolist()], "std", [round(v, 4) for v in sd.tolist()])

    sec("lr_range_test")
    dl = DataLoader(TensorDataset(torch.randn(512, 20), torch.randint(0, 5, (512,))),
                    batch_size=64, shuffle=True)
    lrs, losses = lr_range_test(lambda: nn.Sequential(nn.Linear(20, 64), nn.ReLU(), nn.Linear(64, 5)),
                                dl, nn.CrossEntropyLoss())
    steep = int(np.argmin(np.gradient(np.array(losses))))
    print(f"  {len(lrs)} steps | steepest descent near lr={lrs[steep]:.3g} "
          f"| suggested lr ~ {lrs[steep]/10:.3g}")

    sec("metrics on an imbalanced 4-class problem")
    cm = torch.tensor([[4900, 60, 30, 10], [80, 700, 15, 5], [60, 40, 90, 10], [25, 10, 5, 10]])
    prec, rec, f1 = precision_recall_f1(cm)
    print("  support   ", cm.sum(1).tolist())
    print("  per-class F1", [round(v, 3) for v in f1.tolist()])
    print(f"  accuracy {cm.diag().sum()/cm.sum():.4f} | weighted-F1 "
          f"{(f1*cm.sum(1)/cm.sum()).sum():.4f} | macro-F1 {f1.mean():.4f}  <- the honest one")
    print("  top confusions (true -> pred, count):", top_confusions(cm))

    sec("param_report")
    param_report(nn.Sequential(nn.Conv2d(3, 16, 3, padding=1), nn.ReLU(),
                               nn.Flatten(), nn.Linear(16 * 4, 10)))

    sec("freeze_bn actually freezes the buffers")
    net = nn.Sequential(nn.Conv2d(3, 8, 3, padding=1), nn.BatchNorm2d(8))
    net.train(); net.apply(freeze_bn)
    before = net[1].running_mean.clone(); net(torch.randn(4, 3, 8, 8))
    print("  with freeze_bn, running_mean unchanged:", torch.equal(before, net[1].running_mean))
    net.train()
    before = net[1].running_mean.clone(); net(torch.randn(4, 3, 8, 8))
    print("  without it, running_mean moves:       ", not torch.equal(before, net[1].running_mean))

    sec("nn.LazyLinear")
    lz = nn.Sequential(nn.Conv2d(3, 16, 3, stride=2, padding=1), nn.Flatten(), nn.LazyLinear(10))
    print("  before first forward:", lz[2].weight.__class__.__name__)
    lz(torch.randn(2, 3, 28, 28))
    print("  after :", tuple(lz[2].weight.shape))

    sec("TorchScript trace, and its pitfall")
    model = nn.Sequential(nn.Conv2d(3, 8, 3, padding=1), nn.ReLU(),
                          nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(8, 5)).eval()
    ex = torch.randn(1, 3, 32, 32)
    traced = torch.jit.trace(model, ex)
    print("  traced output matches eager:", torch.allclose(model(ex), traced(ex), atol=1e-5))

    class Branchy(nn.Module):
        def forward(self, x):
            return x.sum() if x.sum() > 0 else x.sum() * 0
    b = Branchy(); tb = torch.jit.trace(b, torch.ones(3))
    print(f"  data-dependent branch: eager {b(-torch.ones(3)).item():.1f} "
          f"vs traced {tb(-torch.ones(3)).item():.1f}  <- trace baked in the wrong path")

    sec("latency, measured with warm-up")
    print(f"  {latency(model, torch.device('cpu')):.3f} ms per image (CPU)")

    sec("topk_accuracy")
    print(" ", topk_accuracy(torch.randn(100, 10), torch.randint(0, 10, (100,))))
