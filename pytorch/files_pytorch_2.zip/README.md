# Code for *PyTorch for Engineers*

Runnable companions to the tutorial. Written and checked against
**torch 2.14.0 / torchvision 0.29.0, Python 3.12**, CPU.

```bash
python -m venv .venv && source .venv/bin/activate
pip install torch torchvision          # add --index-url for a CUDA build; see pytorch.org
pip install matplotlib                 # only for show_batch() in 09
pip install onnx onnxscript            # only if you want the ONNX export in Chapter 13
```

| File | Chapter | Needs | Verified |
| --- | --- | --- | --- |
| `01_tensors_autograd.py` | 1–3 | — | yes |
| `02_activations_gradient_flow.py` | 9.1–9.4 | — | yes |
| `03_losses_metrics.py` | 6.2, 7.5 | — | yes |
| `04_conv_shapes.py` | 8 | — | yes |
| `05_resnet_from_scratch.py` | 10 | — | yes — parameter counts match torchvision exactly |
| `06_assignment1_backprop.py` | 15 | — | yes — gradient check passes at ~1e-8 |
| `09_utilities_verified.py` | 4–13 | matplotlib for one function | yes |
| `07_train_mlp_fashionmnist.py` | 7 | ~30 MB download | syntax-checked only |
| `08_assignment2_cifar10.py` | 15 | ~170 MB download, GPU | syntax-checked only |

"Verified" means the script was executed and its printed values are the ones quoted in
the tutorial. The two training scripts need dataset downloads and, for CIFAR, a GPU to
be practical, so their accuracy figures in the tutorial are informed estimates rather
than measurements — run them and compare.

Each file is self-contained except `08`, which imports `resnet18` from `05`.

**Suggested order:** 01 → 04 → 02 → 03 → 05 → 06 → 09, then the two training scripts.
