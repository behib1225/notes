"""Chapters 6.2 and 7.5: numerical stability of losses, and metrics that are not accuracy."""
import torch
import torch.nn as nn

# ===================== 6.2 why BCEWithLogitsLoss, demonstrated ==================
logits = torch.tensor([-50.0, 50.0], requires_grad=True)   # confidently WRONG both ways
target = torch.tensor([1.0, 0.0])

print("loss values")
print(f"  BCEWithLogitsLoss = {nn.BCEWithLogitsLoss()(logits, target).item():.1f}   correct")
print(f"  Sigmoid + BCELoss = {nn.BCELoss()(torch.sigmoid(logits), target).item():.1f}   wrong")

# Where does the split version lose it? Not where most people guess.
print("\nwhere it breaks")
print("  sigmoid(-50) =", torch.sigmoid(torch.tensor(-50.0)).item(), " <- small but representable")
print("  sigmoid(+50) =", torch.sigmoid(torch.tensor(50.0)).item(), "                <- rounds to EXACTLY 1.0")
print("  so 1 - p = 0, log(0) would be -inf, and BCELoss clamps its log at -100.")
print("  mean(correct 50, clamped 100) = 75.")

# The gradient is the real damage -- and it VANISHES, it does not explode.
print("\ngradient w.r.t. the LOGITS (what the model actually receives)")
logits.grad = None
nn.BCEWithLogitsLoss()(logits, target).backward()
print("  fused:", logits.grad.tolist(), "  bounded, largest exactly when most wrong")

z = torch.tensor([-50.0, 50.0], requires_grad=True)
nn.BCELoss()(torch.sigmoid(z), target).backward()
print("  split:", z.grad.tolist(), "  vanished")

p = torch.sigmoid(torch.tensor(-50.0)).item()
print(f"\n  why: BCELoss clamps dL/dp at 1e12, but dp/dz = p(1-p) = {p:.4e}")
print(f"       product = 1e12 * {p:.4e} / 2 = {1e12*p*(1-p)/2:.4e}")
print("       and for the second element p = 1.0 exactly, so p(1-p) = 0 -> gradient is")
print("       EXACTLY zero. That error can never be corrected, like a dead ReLU.")

# ============================ 7.5 accuracy is not a metric =====================
print("\n" + "=" * 70)
y = torch.cat([torch.ones(10), torch.zeros(990)])
pred = torch.zeros(1000)                                   # always predict negative
print("trivial always-negative baseline accuracy:", (pred == y).float().mean().item())


def precision_recall_f1(cm):
    tp = cm.diag().float()
    precision = tp / cm.sum(0).clamp_min(1)     # column sums = how often we PREDICTED it
    recall    = tp / cm.sum(1).clamp_min(1)     # row sums    = how often it was TRUE
    f1 = 2 * precision * recall / (precision + recall).clamp_min(1e-12)
    return precision, recall, f1


print("\nbinary case")
cm = torch.tensor([[90, 10],      # 100 positives: 90 caught, 10 missed
                   [ 5, 895]])    # 900 negatives: 5 false alarms
p_, r_, f1 = precision_recall_f1(cm)
print("  precision", [round(v, 4) for v in p_.tolist()])
print("  recall   ", [round(v, 4) for v in r_.tolist()])
print("  accuracy    ", round((cm.diag().sum() / cm.sum()).item(), 4))
print("  macro-F1    ", round(f1.mean().item(), 4))
print("  weighted-F1 ", round((f1 * cm.sum(1) / cm.sum()).sum().item(), 4))

print("\nimbalanced 4-class case -- this is where the choice bites")
cm = torch.tensor([[4900,  60,  30,  10],     # support 5000
                   [  80, 700,  15,   5],     # support  800
                   [  60,  40,  90,  10],     # support  200
                   [  25,  10,   5,  10]])    # support   50
p_, r_, f1 = precision_recall_f1(cm)
print("  support     ", cm.sum(1).tolist())
print("  per-class F1", [round(v, 3) for v in f1.tolist()])
print("  accuracy    ", round((cm.diag().sum() / cm.sum()).item(), 4))
print("  weighted-F1 ", round((f1 * cm.sum(1) / cm.sum()).sum().item(), 4))
print("  macro-F1    ", round(f1.mean().item(), 4), " <- the only one that notices class 3")

off = cm.clone(); off.fill_diagonal_(0)
top = torch.topk(off.flatten(), 3)
print("\n  top confusions:")
for v, i in zip(top.values, top.indices):
    print(f"    true {int(i)//len(cm)} predicted as {int(i)%len(cm)}: {int(v)} times")
