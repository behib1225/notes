# PyTorch for Engineers — A Self-Study Tutorial (Core + Computer Vision)

2026-09-18 · @Behi

**Contents**

**Foundations** — [0 · How to use this tutorial](#0-how-to-use-this-tutorial) · [1 · Tensors](#1-tensors-the-one-object-everything-is-made-of) · [2 · Shapes, strides, broadcasting](#2-tensor-mechanics-shapes-strides-views-and-broadcasting) · [3 · Autograd](#3-autograd-how-pytorch-computes-gradients) · [4 · nn.Module](#4-nnmodule-how-models-are-organised)

**Training** — [5 · Data pipeline](#5-the-data-pipeline-dataset-dataloader-transforms) · [6 · Losses and optimizers](#6-losses-and-optimizers) · [7 · Training loop, metrics, debugging](#7-the-training-loop-metrics-and-your-first-complete-model)

**Computer vision** — [8 · Convolution](#8-convolution-from-first-principles) · [9 · Activations, normalisation, regularisation](#9-activations-normalisation-and-regularisation) · [10 · CNN architectures](#10-building-cnn-architectures-from-scratch) · [11 · Training vision models well](#11-training-vision-models-well)

**Engineering** — [12 · Debugging and performance](#12-debugging-reproducibility-and-performance) · [13 · Saving and shipping](#13-saving-loading-and-shipping)

**Practice** — [14 · Exercises with solutions](#14-exercises-with-worked-solutions) · [15 · Assignments](#15-assignments-with-reference-solutions) · [16 · Interview questions](#16-interview-questions-with-model-answers) · [17 · FAQ](#17-faq-the-questions-students-actually-ask) · [18 · Cheat sheet and reading](#18-cheat-sheet-glossary-and-further-reading)

## 0. How to use this tutorial

This tutorial takes you from "I know some Python and some machine learning" to "I can build, train, debug and defend a convolutional network in PyTorch in an industry interview." Everything you need is here: explanations, runnable code, exercises with solutions, three assignments with reference solutions, an interview bank, and an FAQ.

### What you are assumed to know

- Python: functions, classes, `__init__`, decorators at a reading level, list comprehensions.
- NumPy: arrays, shapes, indexing, broadcasting (we re-derive broadcasting anyway).
- ML basics: what a loss function is, gradient descent, train/validation/test splits, overfitting, logistic regression.
- Calculus: partial derivatives and the chain rule. You do not need to derive backprop by hand, but you must believe the chain rule.

You do **not** need prior PyTorch, prior deep learning, or a GPU.

### Versions this tutorial targets

This tutorial targets **PyTorch 2.x**, and every example was checked against **torch 2.14.0 / torchvision 0.29.0 on Python 3.12**, the current release on PyPI as of September 2026. [The latest stable PyTorch requires Python 3.10 or later.](https://pytorch.org/) Code here avoids deprecated 1.x and early-2.x idioms (`Variable`, `.data`, `pretrained=True`, `ToTensor()`, `torch.cuda.amp.autocast`). Where an API changed recently, the old form is named so you recognise it in legacy code and in interviews.

**On the numbers in this document.** Every code snippet in Chapters 1–13 that does not need a dataset download, a GPU, or an extra package was executed on CPU, and the outputs quoted beside them are real. That includes all parameter counts, shape traces, gradient checks, the loss and metric demonstrations, the from-scratch ResNet (whose parameter counts match torchvision exactly), and the Assignment 1 reference solution.

Four things were **not** executed, and are marked where they appear: the FashionMNIST and CIFAR-10 training runs (§7.4 and Chapter 15), so their accuracy figures are informed estimates; GPU-only paths (mixed precision, `channels_last`, `torch.compile`, CUDA timing); ONNX export, which needs the separate `onnxscript` package; and speedup ranges quoted from the wider literature. Measure those on your own hardware rather than trusting the numbers here.

### Install

Use a fresh virtual environment. On a CPU-only laptop:

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install torch torchvision torchaudio
```

For an NVIDIA GPU, pick the CUDA build from the selector on pytorch.org, which generates a command of this shape (the CUDA version in the URL changes over time — read it off the site, do not copy it from memory):

```bash
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu128
```

If you have no GPU, use Google Colab or Kaggle Notebooks; both ship a working CUDA PyTorch for free. Nothing in this tutorial requires more than a few minutes of GPU time.

### Verify the install

Run this once and keep the output. It is also the device-selection snippet you will reuse in every script.

```python
import torch, torchvision

print("torch       :", torch.__version__)
print("torchvision :", torchvision.__version__)
print("CUDA build  :", torch.version.cuda)          # None on a CPU-only wheel
print("CUDA usable :", torch.cuda.is_available())
print("MPS usable  :", torch.backends.mps.is_available())  # Apple Silicon

def get_device():
    if torch.cuda.is_available():
        return torch.device("cuda")
    if torch.backends.mps.is_available():
        return torch.device("mps")
    return torch.device("cpu")

device = get_device()
print("using       :", device)

x = torch.randn(1000, 1000, device=device)
print("matmul ok   :", (x @ x).shape)
```

If the last line prints `torch.Size([1000, 1000])`, you are ready.

### How to study this

Do not read passively. Deep learning code fails in quiet ways — a wrong shape that broadcasts instead of erroring, a missing `optimizer.zero_grad()`, a `model.eval()` you forgot. The only defence is having typed the code yourself and seen the failure.

For each chapter: read the prose, type the snippets into a REPL or notebook, change one thing and predict the output before running it, then do that chapter's exercises from Chapter 14 before moving on.

| Week | Chapters | Outcome |
| --- | --- | --- |
| 1 | 1–3 | You manipulate tensors fluently and explain autograd without hand-waving |
| 2 | 4–7 | You write a full training loop from a blank file, choose the right metric, and debug a model that will not learn |
| 3 | 8–10 | You derive conv shapes on paper, explain ReLU versus sigmoid, and build a ResNet from scratch |
| 4 | 11–13 | You train a competitive CIFAR-10 model and ship the weights |
| 5 | 14–16 | Exercises, assignments, interview drilling |

**If you have one weekend before an interview**, read these in order and skip everything else: §3 (all of autograd), §4.1–4.5, §6.1–6.4, §7.1–7.2, §7.5, §7.7, §8.2–8.3, §8.8, §9.1–9.4, §10.3–10.4, §11.3, then work Chapter 14 Part A and Chapter 16 straight through. That is roughly a fifth of the document and covers everything in the interview bank.

### Conventions used here

- `B` = batch size, `C` = channels, `H` = height, `W` = width, `N` = number of samples, `D` = feature dimension.
- Tensor shapes are written as `(B, C, H, W)`, matching `tensor.shape`.
- ⚠️ marks a mistake that costs people offers in interviews and hours in debugging.
- Every claim about the PyTorch API in this document is checkable against the official documentation at [pytorch.org/docs/stable](https://pytorch.org/docs/stable/index.html). When you are unsure in real work, read the docstring: `help(torch.nn.Conv2d)` works offline and is authoritative for your installed version.

## 1. Tensors: the one object everything is made of

A PyTorch tensor is a multidimensional array that additionally knows three things a NumPy array does not: which **device** its memory lives on, whether it should **track gradients**, and which operation **produced** it. Everything else in PyTorch — layers, losses, optimizers, images, model weights — is a tensor or a container of tensors.

The mental model that will serve you best: *a tensor is a typed, device-resident buffer of numbers plus a shape, and optionally a node in a graph that remembers how it was computed.* Chapter 3 fills in the "graph" half. This chapter is the buffer half.

### 1.1 Creating tensors

```python
import torch

# From existing Python data — dtype is inferred
torch.tensor([1, 2, 3])                 # tensor([1, 2, 3]),  dtype=int64
torch.tensor([1.0, 2.0, 3.0])           # dtype=float32
torch.tensor([[1, 2], [3, 4]])          # shape (2, 2)

# From shape — contents chosen by the constructor
torch.zeros(2, 3)                       # all 0.0
torch.ones(2, 3)
torch.full((2, 3), 7.0)
torch.empty(2, 3)                       # UNINITIALISED memory: garbage values
torch.eye(3)                            # 3x3 identity

# Ranges
torch.arange(0, 10, 2)                  # tensor([0, 2, 4, 6, 8]), int64, end-exclusive
torch.linspace(0, 1, steps=5)           # tensor([0.00, 0.25, 0.50, 0.75, 1.00]), end-inclusive

# Random
torch.rand(2, 3)                        # uniform on [0, 1)
torch.randn(2, 3)                       # standard normal, mean 0 std 1
torch.randint(0, 10, (2, 3))            # integers in [0, 10)
torch.randperm(5)                       # a random permutation of 0..4

# "Like" variants copy shape, dtype AND device from another tensor
x = torch.randn(4, 5, device="cpu")
torch.zeros_like(x)                     # same shape, dtype, device
torch.randn_like(x)
```

Two traps worth internalising now:

- ⚠️ `torch.empty` does not zero memory. Printing it shows whatever bytes were there. Use it only when you are about to overwrite every element.
- ⚠️ `torch.Tensor(2, 3)` (capital T, the legacy constructor) means "uninitialised 2×3 float tensor", while `torch.tensor([2, 3])` means "a tensor holding the values 2 and 3". Never use the capital-T form. Interviewers occasionally show it to see whether you notice.

### 1.2 The three attributes you check first

When anything goes wrong, print these three before anything else.

```python
x = torch.randn(8, 3, 32, 32)
x.shape      # torch.Size([8, 3, 32, 32]) — a tuple subclass, so x.shape[0] == 8
x.dtype      # torch.float32
x.device     # device(type='cpu')
x.ndim       # 4
x.numel()    # 24576 = 8*3*32*32, total number of elements
```

`x.size()` is the method form of `x.shape`; `x.size(0)` gives one dimension. Both are used in real code, so read both fluently.

### 1.3 Dtypes, and why float32 is the default

| dtype | Alias | Typical use |
| --- | --- | --- |
| `torch.float32` | `torch.float` | Default for all model weights, activations, gradients |
| `torch.float64` | `torch.double` | Scientific code; almost never in deep learning (slow on GPU) |
| `torch.float16` | `torch.half` | Mixed-precision training and inference on GPU |
| `torch.bfloat16` | — | Mixed precision with wider exponent range; preferred on modern GPUs/TPUs |
| `torch.int64` | `torch.long` | Class labels, indices — required by `CrossEntropyLoss` and `nn.Embedding` |
| `torch.int32` | `torch.int` | Interop, memory-tight index tensors |
| `torch.uint8` | — | Raw image bytes in \[0, 255\] before conversion |
| `torch.bool` | — | Masks |

Why float32 and not float64? Consumer and datacentre GPUs deliver far more throughput at 32-bit than 64-bit, gradients are a noisy estimate anyway, and halving the bytes halves memory traffic — which is the real bottleneck. Statistical noise in SGD dwarfs float32 rounding error, so the extra precision buys nothing.

Converting:

```python
x = torch.arange(5)          # int64
x.float()                    # -> float32
x.to(torch.float32)          # identical, more explicit
x.long()                     # -> int64
x.to(dtype=torch.bfloat16)
```

⚠️ Integer division and integer accumulation bite people constantly. `torch.arange(5).mean()` raises an error because mean is undefined for integer dtypes — you must call `.float()` first. And labels for `CrossEntropyLoss` must be `int64`; passing `int32` or `float32` raises a confusing error deep inside the loss.

### 1.4 Devices

A tensor lives on exactly one device. Operations require all operands on the same device.

```python
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

x = torch.randn(3, 3)                  # created on CPU
x = x.to(device)                       # returns a COPY on the GPU
y = torch.randn(3, 3, device=device)   # created directly on the GPU — cheaper

x + y                                  # fine, both on device
x + torch.randn(3, 3)                  # RuntimeError: Expected all tensors on the same device
```

Key facts:

- `.to(device)` returns a **new** tensor if a move is needed, and the *same* tensor if it is already there. So `x.to(device)` without reassignment is a no-op bug: write `x = x.to(device)`.
- Modules behave differently: `model.to(device)` moves parameters **in place** and also returns `self`. So `model.to(device)` alone works, but `x.to(device)` alone does not. This asymmetry is a favourite interview question.
- `.cuda()` and `.cpu()` are shorthands. Prefer `.to(device)` so the same script runs everywhere.
- CPU↔GPU transfer is slow relative to compute. Move data once, keep it there, and never call `.item()` or `.cpu()` inside a hot loop if you can avoid it.

### 1.5 The NumPy bridge, and the memory it shares

```python
import numpy as np

a = np.array([1.0, 2.0, 3.0])
t = torch.from_numpy(a)        # SHARES memory with a
t[0] = 99.0
print(a)                       # [99.  2.  3.]  <- the NumPy array changed too

b = t.numpy()                  # also SHARES memory (CPU tensors only)
```

Sharing only happens on CPU, and only when no dtype conversion is required. `torch.tensor(a)` always **copies**. `t.cpu().numpy()` on a GPU tensor copies, because the data must cross the bus. `.numpy()` on a tensor that requires grad raises an error; call `.detach().numpy()`.

Why does this matter? Because a subtle class of bug is "I modified the NumPy array after building the dataset and my tensors silently changed." When in doubt, copy explicitly with `torch.tensor(a)` or `t.clone()`.

### 1.6 Getting numbers back out

```python
loss = torch.tensor(0.4567)
loss.item()        # 0.4567... a Python float. Only works on a ONE-element tensor.
t.tolist()         # nested Python lists, any shape
float(loss)        # same as .item() for scalars
```

⚠️ The classic memory leak: accumulating `total_loss += loss` instead of `total_loss += loss.item()`. The first keeps every batch's computational graph alive for the whole epoch and eventually exhausts GPU memory. Use `.item()` (or `.detach()`) for anything you only want to log.

### 1.7 In-place operations and the trailing underscore

Any method ending in `_` modifies the tensor in place and returns it.

```python
x = torch.ones(3)
y = x.add(1)      # x unchanged, y is new
x.add_(1)         # x is now tensor([2., 2., 2.])
x.zero_()         # fill with zeros in place
x.clamp_(0, 1)    # clamp in place
```

In-place saves memory, which sometimes matters. But ⚠️ in-place operations on tensors that autograd needs for the backward pass raise `RuntimeError: one of the variables needed for gradient computation has been modified by an inplace operation`. Chapter 3 explains exactly when. Rule of thumb for now: use in-place freely on data and on tensors under `torch.no_grad()`, and be careful inside a model's `forward`.

### 1.8 Reproducibility, first pass

```python
torch.manual_seed(0)          # seeds CPU and all GPUs
print(torch.randn(3))         # same three numbers every run
```

This is necessary but not sufficient for bit-identical runs; Chapter 12 covers the rest (DataLoader workers, cuDNN autotuning, non-deterministic kernels).

### 1.9 Check yourself

Before moving on, you should be able to answer without running code:

1. What does `torch.arange(6).mean()` do, and why?
2. Why does `model.to(device)` work but `x.to(device)` silently fail?
3. After `t = torch.from_numpy(a); a[0] = 5`, what is `t[0]`?
4. Why is `total += loss` a bug and `total += loss.item()` not?

Solutions are in Chapter 14.

## 2. Tensor mechanics: shapes, strides, views and broadcasting

More bugs in deep learning code come from shapes than from mathematics. This chapter is the one to over-learn. If you can explain strides and broadcasting precisely, you will read other people's models faster than they can.

### 2.1 The storage/stride model

A tensor is a **view onto a flat one-dimensional buffer**. The buffer is called the *storage*. The tensor adds three pieces of metadata: a shape, a **stride**, and a storage offset.

The stride tells you how many elements to skip in the flat buffer to advance one step along each dimension.

```python
x = torch.arange(12).reshape(3, 4)
print(x)
# tensor([[ 0,  1,  2,  3],
#         [ 4,  5,  6,  7],
#         [ 8,  9, 10, 11]])
print(x.stride())         # (4, 1)
print(x.untyped_storage().size())   # 12 — one flat buffer of 12 ints
```

Stride `(4, 1)` means: to move one row down, jump 4 elements; to move one column right, jump 1 element. The address of element `x[i, j]` is `offset + 4*i + 1*j`. That is all a tensor is.

Now transpose it:

```python
y = x.t()                 # or x.transpose(0, 1)
print(y.shape)            # (4, 3)
print(y.stride())         # (1, 4)
print(y.data_ptr() == x.data_ptr())   # True — SAME memory
```

Nothing was copied. PyTorch just swapped the shape and the stride. This is why transposing a 10 GB tensor is instantaneous.

**Contiguity.** A tensor is *contiguous* when its elements are laid out in the buffer in exactly row-major (C) order — i.e. the stride of the last dimension is 1 and each earlier stride is the product of all later shapes. `x` above is contiguous; `y` is not.

```python
x.is_contiguous()    # True
y.is_contiguous()    # False
y.contiguous().is_contiguous()   # True — this one COPIES into fresh memory
```

Why you care: some operations require contiguous input and will either copy silently or raise. And `view` — the zero-copy reshape — only works on tensors whose layout is compatible.

### 2.2 view vs reshape

```python
x = torch.arange(12).reshape(3, 4)
x.view(4, 3)          # works: x is contiguous, no copy

y = x.t()             # non-contiguous
y.view(3, 4)          # RuntimeError: view size is not compatible ... use .reshape()
y.reshape(3, 4)       # works: falls back to a copy
```

The rule:

- `view` **never copies**. It fails loudly if it cannot produce the requested shape without copying.
- `reshape` returns a view when it can and a copy when it must. It never fails on layout grounds.

Which should you use? Use `reshape` by default — it always works. Use `view` when you want a guarantee of no copy, and are willing to be told when that guarantee is impossible. In interviews, say exactly this.

`-1` in either means "infer this dimension":

```python
feat = torch.randn(32, 64, 7, 7)
flat = feat.reshape(32, -1)      # (32, 3136) — the standard CNN-to-classifier flatten
flat = feat.flatten(start_dim=1) # identical, and clearer about intent
```

### 2.3 Rearranging dimensions

```python
x = torch.randn(2, 3, 4)

x.transpose(0, 1).shape     # (3, 2, 4)  — swap exactly two dims
x.permute(2, 0, 1).shape    # (4, 2, 3)  — arbitrary reordering; argument is the
                            #              NEW order expressed as OLD indices
x.unsqueeze(0).shape        # (1, 2, 3, 4) — insert a size-1 dim at position 0
x.unsqueeze(-1).shape       # (2, 3, 4, 1)
x.squeeze().shape           # (2, 3, 4) — removes ALL size-1 dims
torch.randn(1, 3, 1).squeeze(0).shape   # (3, 1) — removes only dim 0
```

⚠️ Bare `.squeeze()` is dangerous in library code: with batch size 1, `(1, 10)` becomes `(10,)` and downstream code that assumed a batch dimension breaks. Always pass an explicit dim.

⚠️ `permute`/`transpose` produce non-contiguous tensors. A very common idiom after permuting is `.contiguous()` before a `view`:

```python
# (B, C, H, W) -> (B, H, W, C) -> (B*H*W, C)
z = x.permute(0, 2, 3, 1).contiguous().view(-1, x.shape[1])
# or simply: x.permute(0, 2, 3, 1).reshape(-1, x.shape[1])
```

### 2.4 Broadcasting, derived properly

Broadcasting lets operations combine tensors of different shapes without materialising copies. The algorithm, applied right-to-left over the dimensions:

1. If the two tensors have different numbers of dimensions, **prepend** size-1 dimensions to the smaller one until they match.
2. For each dimension, the sizes are compatible if they are **equal**, or if **one of them is 1**.
3. The output size in that dimension is the maximum of the two.
4. If any dimension pair is incompatible, PyTorch raises.

Worked examples:

| A | B | Result | Why |
| --- | --- | --- | --- |
| `(3, 4)` | `(4,)` | `(3, 4)` | B becomes `(1, 4)`, then 1 stretches to 3 |
| `(3, 1)` | `(1, 4)` | `(3, 4)` | both stretch — an outer-product pattern |
| `(8, 3, 32, 32)` | `(3, 1, 1)` | `(8, 3, 32, 32)` | per-channel scaling, the image-normalisation pattern |
| `(5, 4)` | `(5,)` | **error** | right-aligned, 4 vs 5 |
| `(5, 4)` | `(5, 1)` | `(5, 4)` | the fix for the row above |

The fourth row is the single most common source of a confusing broadcast error, and the fifth is its fix.

And here is the bug that costs people whole afternoons:

```python
pred   = torch.randn(32, 1)    # forgot to squeeze the model output
target = torch.randn(32)       # labels
loss = ((pred - target) ** 2).mean()
print((pred - target).shape)   # (32, 32) !!! not (32,)
```

No error is raised. Broadcasting happily produced a 32×32 matrix of all pairwise differences, the loss is a meaningless number, and the model trains to nothing. ⚠️ **Whenever a loss looks plausible but the model will not learn, print the shape of every intermediate.** Squeeze or reshape deliberately:

```python
loss = ((pred.squeeze(1) - target) ** 2).mean()   # (32,) — correct
```

### 2.5 Indexing

Basic slicing behaves like NumPy and returns **views**:

```python
x = torch.arange(24).reshape(2, 3, 4)
x[0]            # (3, 4)   first sample
x[:, 1]         # (2, 4)   second row of every sample
x[..., -1]      # (2, 3)   last element along the final dim; ... = "all remaining dims"
x[0, 1, 2]      # a 0-dim tensor; use .item() for a Python number
```

Advanced indexing (integer tensors, boolean masks) returns **copies**:

```python
idx  = torch.tensor([0, 2])
x[:, idx]                  # (2, 2, 4) — pick rows 0 and 2

mask = x > 20
x[mask]                    # 1-D tensor of all elements > 20
x[mask].shape              # data-dependent shape

x.masked_fill(x > 20, 0)   # same shape, offending entries replaced
```

Three indexing functions that show up constantly in real models:

```python
logits = torch.randn(4, 10)          # 4 samples, 10 classes
labels = torch.tensor([3, 0, 7, 2])

# gather: pick one entry per row, along dim 1, at the given indices
chosen = logits.gather(1, labels.unsqueeze(1)).squeeze(1)   # (4,)

# equivalent and more readable for this case:
chosen = logits[torch.arange(4), labels]                    # (4,)

# index_select: pick whole slices along a dim
torch.index_select(logits, 0, torch.tensor([0, 2]))         # (2, 10)
```

`gather` is worth understanding because it is how negative log-likelihood is implemented and it appears in interview coding rounds. The contract: `out[i][j] = input[i][index[i][j]]` when `dim=1`, and `index` must have the same number of dimensions as `input`.

### 2.6 Reductions, `dim`, and `keepdim`

```python
x = torch.randn(4, 5)
x.sum()                 # scalar — reduce everything
x.sum(dim=0).shape      # (5,)   — collapse dim 0, i.e. sum DOWN the rows
x.sum(dim=1).shape      # (4,)   — collapse dim 1, sum ACROSS each row
x.sum(dim=1, keepdim=True).shape   # (4, 1) — keep the reduced dim as size 1
```

The rule to memorise: **`dim=k` is the dimension that disappears.** People misremember this constantly. `keepdim=True` keeps it as size 1, which is exactly what you want when you are about to broadcast the result back against the original:

```python
# row-wise softmax, numerically stable, written by hand
z = x - x.max(dim=1, keepdim=True).values     # keepdim so (4,1) broadcasts against (4,5)
p = z.exp() / z.exp().sum(dim=1, keepdim=True)
torch.allclose(p, torch.softmax(x, dim=1))    # True
```

Note that `max` with a `dim` returns a named tuple `(values, indices)`, while `max()` with no dim returns a plain scalar tensor. `argmax(dim=1)` gives just the indices — this is how you turn logits into predictions.

Other reductions: `mean`, `std`, `var`, `prod`, `min`, `median`, `norm`, `any`, `all`, `cumsum`, `topk`.

### 2.7 Joining and splitting

```python
a = torch.randn(2, 3)
b = torch.randn(2, 3)

torch.cat([a, b], dim=0).shape     # (4, 3) — joins along an EXISTING dim
torch.cat([a, b], dim=1).shape     # (2, 6)
torch.stack([a, b], dim=0).shape   # (2, 2, 3) — creates a NEW dim

big = torch.randn(10, 3)
torch.chunk(big, 5, dim=0)         # tuple of 5 tensors of shape (2, 3)
torch.split(big, 4, dim=0)         # sizes 4, 4, 2
```

`cat` vs `stack` comes up often in interviews. One sentence answer: *`cat` concatenates along an existing axis and requires all other dimensions to match; `stack` requires all shapes to be identical and inserts a new axis.* `stack` is how a DataLoader turns a list of per-sample tensors into a batch.

### 2.8 Matrix multiplication

```python
A = torch.randn(3, 4)
B = torch.randn(4, 5)
A @ B                   # (3, 5) — the @ operator is torch.matmul
torch.mm(A, B)          # strictly 2-D only
torch.bmm(torch.randn(8, 3, 4), torch.randn(8, 4, 5))   # (8, 3, 5) batched, strictly 3-D

# matmul broadcasts leading "batch" dimensions:
torch.matmul(torch.randn(8, 1, 3, 4), torch.randn(4, 5)).shape   # (8, 1, 3, 5)

torch.dot(torch.randn(5), torch.randn(5))     # scalar, 1-D only
(A * A).shape                                 # (3, 4) — elementwise, NOT matmul
```

⚠️ `*` is elementwise; `@` is matrix product. Mixing them up produces either a shape error or, worse, a silent broadcast.

### 2.9 einsum: one notation for all of the above

`torch.einsum` writes tensor contractions in index notation. Repeated indices are summed over; indices in the output are kept.

```python
A = torch.randn(3, 4)
B = torch.randn(4, 5)

torch.einsum("ij,jk->ik", A, B)          # matrix multiply
torch.einsum("ij->ji", A)                # transpose
torch.einsum("ij->", A)                  # sum everything
torch.einsum("ij->i", A)                 # row sums
torch.einsum("i,j->ij", torch.randn(3), torch.randn(4))   # outer product
torch.einsum("bij,bjk->bik", X, Y)       # batched matmul
torch.einsum("bchw,bchw->b", f, g)       # per-sample inner product of feature maps
```

You do not need einsum to survive, but it makes attention and multi-head reshaping readable, and fluency with it reads as seniority.

### 2.10 Memory format: a note for the CNN chapters

A `(B, C, H, W)` tensor is stored channels-first by default. Modern GPU convolution kernels (especially with Tensor Cores) often prefer channels-last. PyTorch supports this as a *memory format*, changing strides without changing the logical shape:

```python
x = torch.randn(8, 3, 224, 224).to(memory_format=torch.channels_last)
x.shape       # still (8, 3, 224, 224)
x.stride()    # (150528, 1, 672, 3) — channel stride is now 1
```

You set it on both the model and the input, and it can give a meaningful speedup with mixed precision. File it away for Chapter 12.

### 2.11 Check yourself

1. `torch.randn(5, 4) + torch.randn(5)` — error or fine? What about `+ torch.randn(4)`?
2. Why does `x.t().view(-1)` fail while `x.t().reshape(-1)` succeeds?
3. What shape is `torch.randn(2, 3, 4).sum(dim=1, keepdim=True)`?
4. Write the `(B, C, H, W) -> (B, H*W, C)` rearrangement used before attention.

## 3. Autograd: how PyTorch computes gradients

This is the chapter that separates people who *use* PyTorch from people who *understand* it. Interviewers know this, which is why autograd questions are unavoidable.

### 3.1 The idea in one paragraph

As you perform operations on tensors, PyTorch records them in a directed acyclic graph whose nodes are functions and whose edges are tensors. When you call `.backward()` on a scalar output, PyTorch walks that graph backwards from the output to the inputs, applying the chain rule at each node, and accumulates the resulting partial derivatives into the `.grad` attribute of every *leaf* tensor that asked for them. The graph is built **during** the forward pass, on every iteration, by ordinary Python control flow — this is what "define-by-run" or "dynamic graph" means. Because the graph is rebuilt each iteration, you can use `if`, `for` and `while` inside `forward` and the gradients will still be correct.

### 3.2 requires\_grad and leaves

```python
x = torch.tensor([2.0])                        # requires_grad=False by default
w = torch.tensor([3.0], requires_grad=True)    # we want d(loss)/dw
b = torch.tensor([1.0], requires_grad=True)

y = w * x + b
print(y)             # tensor([7.], grad_fn=<AddBackward0>)
print(y.requires_grad)   # True — it propagates
print(y.is_leaf)         # False — y was computed
print(w.is_leaf)         # True — w was created by the user
```

A **leaf** tensor is one that you created directly rather than computing from other tensors. Model parameters are leaves. `requires_grad=True` propagates: any operation whose input requires grad produces an output that requires grad, so the whole downstream computation is tracked.

After `backward()`, `.grad` is populated on leaves only. Non-leaf tensors get `None` and a warning, unless you explicitly call `y.retain_grad()` before the backward pass.

### 3.3 A gradient computed by hand, then checked

Let `w = 3`, `x = 2`, `b = 1`, target `t = 5`.

Forward: `y = wx + b = 7`, `L = (y - t)² = 4`.

By the chain rule:

- `dL/dy = 2(y - t) = 2(7 - 5) = 4`
- `dy/dw = x = 2`, so `dL/dw = 4 · 2 = 8`
- `dy/db = 1`, so `dL/db = 4 · 1 = 4`

```python
x = torch.tensor([2.0])
t = torch.tensor([5.0])
w = torch.tensor([3.0], requires_grad=True)
b = torch.tensor([1.0], requires_grad=True)

y = w * x + b
L = (y - t) ** 2
L.backward()

print(w.grad)   # tensor([8.])
print(b.grad)   # tensor([4.])
```

Do this once by hand. It converts autograd from magic into bookkeeping.

### 3.4 Why `.backward()` wants a scalar

Reverse-mode automatic differentiation computes a **vector–Jacobian product**. For a function `f: Rⁿ → Rᵐ` with Jacobian `J` (shape `m × n`), one backward pass computes `vᵀJ` for a vector `v` you supply. Getting the full Jacobian would require `m` backward passes.

When the output is a scalar loss, `m = 1` and the natural choice is `v = [1.0]`, which makes `vᵀJ` exactly the gradient. That is why `loss.backward()` works with no arguments.

For a non-scalar output you must supply `v` yourself:

```python
x = torch.tensor([1.0, 2.0, 3.0], requires_grad=True)
y = x ** 2                       # non-scalar output

# y.backward()                   # RuntimeError: grad can be implicitly created
                                 # only for scalar outputs
y.backward(torch.ones_like(y))   # v = [1,1,1] -> gradient of y.sum()
print(x.grad)                    # tensor([2., 4., 6.])
```

Equivalently, `y.sum().backward()`. This is exactly why every training loop ends in a **single scalar** loss: `loss = criterion(...)` returns a mean over the batch, and the batch mean makes gradients independent of batch size.

If you genuinely need a full Jacobian, use `torch.func.jacrev` / `torch.func.jacfwd`, or `torch.autograd.functional.jacobian`.

### 3.5 Gradients accumulate — and why that is a feature

```python
w = torch.tensor([1.0], requires_grad=True)

for _ in range(3):
    loss = (w * 2).sum()
    loss.backward()
    print(w.grad)     # tensor([2.]) then tensor([4.]) then tensor([6.])
```

`.backward()` **adds** to `.grad` rather than overwriting it. This is why `optimizer.zero_grad()` exists and why forgetting it is the single most common PyTorch bug: your gradients become the running sum of every batch you have ever seen, the effective learning rate explodes, and the loss diverges.

The accumulate-by-default design is deliberate. It lets you:

- Sum gradients from several loss terms (`(loss_a + loss_b).backward()` or two separate backward calls).
- Implement **gradient accumulation**: simulate a large batch on a small GPU by running several forward/backward passes before a single `optimizer.step()` (Chapter 11).
- Handle architectures where a parameter is used more than once — its gradient contributions correctly sum.

Two ways to clear:

```python
optimizer.zero_grad()                 # sets .grad to None (PyTorch 2.x default)
optimizer.zero_grad(set_to_none=True) # explicit; same thing
model.zero_grad()                     # equivalent when the optimizer holds all params
```

Setting to `None` rather than zero is slightly faster and saves memory; it is the default since PyTorch 2.0. Defensive code that reads `p.grad` should therefore handle `None`.

### 3.6 Turning autograd off: `no_grad`, `inference_mode`, `detach`

During validation and inference you do not need gradients, and building the graph wastes memory and time.

```python
with torch.no_grad():
    preds = model(x)          # no graph is built; preds.requires_grad is False

with torch.inference_mode():  # stronger and faster than no_grad
    preds = model(x)
```

`inference_mode` (PyTorch 1.9+) additionally disables version counting and view tracking, so it is faster — but tensors created inside it cannot later be used in autograd. Use `inference_mode` for pure serving and `no_grad` when the results might re-enter a graph.

`detach()` cuts a single tensor out of the graph:

```python
h = model_a(x)
z = model_b(h.detach())      # gradients from z will NOT flow back into model_a
```

`detach()` returns a new tensor sharing the same storage but with `requires_grad=False` and no `grad_fn`. It is how you freeze part of a pipeline, how you stop a recurrent hidden state from back-propagating through all of history (truncated BPTT), and how you safely log intermediate values.

| Want to… | Use |
| --- | --- |
| Evaluate a model | `with torch.no_grad():` |
| Serve a model in production | `with torch.inference_mode():` |
| Stop gradient flow through one tensor | `t.detach()` |
| Log a scalar | `loss.item()` |
| Freeze a whole submodule | `for p in m.parameters(): p.requires_grad_(False)` |

Note the difference between the last row and `model.eval()`. ⚠️ **`model.eval()` does not disable gradients** — it switches Dropout and BatchNorm into inference behaviour. `torch.no_grad()` does not change layer behaviour. You almost always need **both** during validation. It is also one of the most commonly asked PyTorch interview questions.

### 3.7 The graph is freed after backward

```python
y = (w * x).sum()
y.backward()
y.backward()   # RuntimeError: Trying to backward through the graph a second time
```

By default the intermediate buffers are released as soon as they are consumed, because keeping them would waste memory. If you truly need two backward passes through the same graph, pass `retain_graph=True` to the first one. But in 95% of cases where students hit this error, the real bug is something else: re-using a tensor computed outside the loop, or forgetting to recompute the forward pass each iteration.

`create_graph=True` goes further and makes the backward pass itself differentiable, which is how you get second-order gradients (used in MAML-style meta-learning and in gradient penalties such as WGAN-GP).

### 3.8 `torch.autograd.grad`: gradients without side effects

```python
x = torch.tensor([2.0], requires_grad=True)
y = x ** 3

g, = torch.autograd.grad(y, x, create_graph=True)   # dy/dx = 3x² = 12
g2, = torch.autograd.grad(g, x)                     # d²y/dx² = 6x = 12
print(g, g2)     # tensor([12.], grad_fn=...) tensor([12.])
```

`torch.autograd.grad` **returns** gradients instead of writing them into `.grad`. Use it when you need gradients as values — penalties, influence functions, adversarial examples — rather than as an optimisation step.

### 3.9 Writing a custom autograd Function

You need this rarely: when you have a numerically better gradient formula, when you call out to non-PyTorch code, or when you want to modify the gradient (straight-through estimators, gradient reversal layers in domain adaptation).

```python
class DoubleGradSquare(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        ctx.save_for_backward(x)          # save what backward will need
        return x ** 2

    @staticmethod
    def backward(ctx, grad_output):
        (x,) = ctx.saved_tensors
        # the true gradient is 2x; we deliberately return twice that
        return grad_output * 4 * x

x = torch.tensor([3.0], requires_grad=True)
y = DoubleGradSquare.apply(x)             # NOTE: .apply, never .forward
y.backward()
print(x.grad)                             # tensor([12.])  — twice the true 2x = 6
```

With `grad_output = 1`, backward returns `1 · 4 · 3 = 12`, exactly twice the true gradient `2x = 6` — proof that you now control what flows backwards. Three rules for custom Functions:

1. `forward` and `backward` are `@staticmethod`, and you invoke the op with `.apply(...)`, never by calling `forward` directly.
2. `backward` must return one gradient per input to `forward`, in the same order, or `None` for inputs that do not need one.
3. Use `ctx.save_for_backward` for tensors (it cooperates with autograd's memory management and correctness checks) and plain `ctx.attribute = value` for non-tensors.

A real example — the gradient reversal layer used in domain-adversarial training:

```python
class GradReverse(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, lambd):
        ctx.lambd = lambd
        return x.view_as(x)          # identity forward

    @staticmethod
    def backward(ctx, g):
        return -ctx.lambd * g, None  # None for lambd, which needs no gradient
```

Check any custom Function with `torch.autograd.gradcheck`, which compares your analytic gradient against finite differences (use `float64` inputs, or it will fail on precision alone).

### 3.10 The gotchas, collected

⚠️ **In-place modification of a needed tensor.**

```python
x = torch.randn(3, requires_grad=True)
y = x.exp()
y += 1          # RuntimeError at backward: y was needed to compute exp's gradient
```

The derivative of `exp` is `exp(x)`, i.e. the *output* itself, so overwriting the output destroys the information backward needs. `relu` on the other hand can be in-place (`nn.ReLU(inplace=True)`) because its gradient only depends on the sign, which is recoverable. When in doubt, do not use in-place ops inside `forward`.

⚠️ **Assigning to `.data`.** Legacy code uses `p.data = ...` to bypass autograd. It skips version-counter checks and can silently produce wrong gradients. Use `with torch.no_grad(): p.copy_(...)` instead.

⚠️ **Breaking the graph with NumPy.** `torch.tensor(x.detach().numpy() * 2)` computes the right numbers and destroys the gradient path. Any excursion through NumPy or Python floats ends differentiability.

⚠️ **Leaf tensors created on the wrong device.** `torch.randn(3, requires_grad=True).cuda()` produces a *non-leaf* tensor (the `.cuda()` is a tracked op), so it will never receive a `.grad`. Write `torch.randn(3, device="cuda", requires_grad=True)`.

⚠️ **Forgetting that `requires_grad` is sticky.** Once a model parameter is frozen with `requires_grad_(False)`, it stays frozen through save/load of the *model object* — but `state_dict` does not carry it, so a reloaded model has all parameters trainable again.

### 3.11 Check yourself

1. Why does `loss.backward()` need a scalar, and what does `y.backward(v)` compute?
2. Give two legitimate reasons gradients accumulate by default.
3. What is the difference between `model.eval()` and `torch.no_grad()`? Do you need both?
4. After `b = a.detach()`, if you modify `b` in place, does `a` change? (Yes — they share storage. Use `a.detach().clone()` if you want independence.)

## 4. nn.Module: how models are organised

Autograd alone is enough to train a model, but you would be managing hundreds of loose tensors by hand. `nn.Module` is the container abstraction that tracks parameters, moves them between devices, saves and loads them, and composes into trees.

### 4.1 The anatomy of a module

```python
import torch.nn as nn
import torch.nn.functional as F

class MLP(nn.Module):
    def __init__(self, in_dim, hidden, out_dim):
        super().__init__()              # MANDATORY and must come first
        self.fc1 = nn.Linear(in_dim, hidden)
        self.fc2 = nn.Linear(hidden, out_dim)
        self.dropout = nn.Dropout(0.2)

    def forward(self, x):
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        return self.fc2(x)              # return LOGITS, not probabilities

model = MLP(784, 256, 10)
out = model(torch.randn(32, 784))       # call the module, do NOT call .forward()
print(out.shape)                        # (32, 10)
```

Four rules, each of which is an interview question:

1. **`super().__init__()` must be the first line of `__init__`.** `nn.Module.__init__` creates the internal dictionaries (`_parameters`, `_buffers`, `_modules`). If you assign `self.fc1 = nn.Linear(...)` before calling it, you get `AttributeError: cannot assign module before Module.__init__() call`.
2. **Call `model(x)`, never `model.forward(x)`.** `__call__` runs registered forward hooks, handles a few internal flags, and then calls `forward`. Calling `forward` directly skips all of that and silently breaks hooks, which is how people break `torch.compile`, quantisation, and profiling tools.
3. **Assigning a submodule to `self` registers it.** This is the magic: `nn.Module.__setattr__` is overridden, so `self.fc1 = nn.Linear(...)` adds `fc1` to `_modules` and its weights become part of `model.parameters()`. This is also why a plain Python list of layers fails (§4.4).
4. **Return logits from classifiers.** `nn.CrossEntropyLoss` applies log-softmax internally. Applying softmax yourself and then passing it to `CrossEntropyLoss` is a classic bug that trains a model to a worse optimum without ever erroring.

### 4.2 Parameters, buffers, and plain tensors

Three kinds of tensor can live inside a module, and knowing the difference is the mark of someone who has debugged real models.

```python
class Demo(nn.Module):
    def __init__(self):
        super().__init__()
        self.w = nn.Parameter(torch.randn(3, 3))          # trained
        self.register_buffer("running_mean", torch.zeros(3))  # saved, moved, NOT trained
        self.scale = torch.tensor(2.0)                    # invisible to the module system

m = Demo()
print([n for n, _ in m.named_parameters()])   # ['w']
print([n for n, _ in m.named_buffers()])      # ['running_mean']
print(m.state_dict().keys())                  # odict_keys(['w', 'running_mean'])
```

|  | `nn.Parameter` | buffer | plain tensor attribute |
| --- | --- | --- | --- |
| Appears in `parameters()` | yes | no | no |
| Updated by the optimizer | yes | no | no |
| Saved in `state_dict()` | yes | yes | no |
| Moved by `model.to(device)` | yes | yes | **no** |

The last row is the trap. ⚠️ `self.scale = torch.tensor(2.0)` stays on the CPU forever. When you move the model to a GPU and run a forward pass, you get a device-mismatch error that looks like it comes from nowhere. Buffers are the correct home for constants, running statistics (BatchNorm's `running_mean`/`running_var`), positional-encoding tables, and masks.

`nn.Parameter` is just a `Tensor` subclass with `requires_grad=True` by default and a hook into `__setattr__` that registers it.

### 4.3 Inspecting a model

```python
print(model)                      # tree of submodules and their constructor args

for name, p in model.named_parameters():
    print(f"{name:20s} {tuple(p.shape)}  trainable={p.requires_grad}")
# fc1.weight           (256, 784)  trainable=True
# fc1.bias             (256,)      trainable=True
# ...

n_total = sum(p.numel() for p in model.parameters())
n_train = sum(p.numel() for p in model.parameters() if p.requires_grad)
print(f"{n_total:,} parameters ({n_train:,} trainable)")
```

Be ready to compute a parameter count by hand in an interview. For `nn.Linear(in, out)` it is `in*out + out`. For `nn.Conv2d(Cin, Cout, k)` it is `Cout * Cin * k * k + Cout`. A 784→256→10 MLP has `784·256 + 256 + 256·10 + 10 = 203,530`.

Other traversal helpers: `model.children()` (direct submodules), `model.modules()` (every module recursively, including `model` itself), `model.named_modules()`.

### 4.4 Containers: Sequential, ModuleList, ModuleDict

```python
# Sequential: a chain. Its forward is "apply each in order".
net = nn.Sequential(
    nn.Linear(784, 256), nn.ReLU(),
    nn.Dropout(0.2),
    nn.Linear(256, 10),
)
net(torch.randn(4, 784)).shape    # (4, 10)

# Named version, so state_dict keys are readable
from collections import OrderedDict
net = nn.Sequential(OrderedDict([
    ("fc1", nn.Linear(784, 256)),
    ("act", nn.ReLU()),
    ("fc2", nn.Linear(256, 10)),
]))
```

⚠️ **Never store submodules in a plain Python list.**

```python
class Broken(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = [nn.Linear(10, 10) for _ in range(3)]   # WRONG

len(list(Broken().parameters()))    # 0 — the optimizer will train nothing

class Fixed(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = nn.ModuleList([nn.Linear(10, 10) for _ in range(3)])

    def forward(self, x):
        for layer in self.layers:
            x = layer(x)
        return x

len(list(Fixed().parameters()))     # 6 — three weights and three biases
```

The failure is silent: training runs, loss does not move, and nothing raises. `ModuleList` registers its contents but has **no** `forward` — you write the loop yourself. `ModuleDict` does the same for a dict. Use `Sequential` when the flow really is a straight chain, `ModuleList` when you need branching, skip connections, or per-layer logic.

The analogous trap for tensors is `nn.ParameterList` / `nn.ParameterDict`.

### 4.5 `nn.X` vs `nn.functional.x`

Many operations exist in two forms:

```python
# stateful module form
self.act = nn.ReLU()
x = self.act(x)

# stateless functional form
x = F.relu(x)
```

The rule: **if the operation has learnable parameters or persistent state, use the module form; otherwise either works.**

- `nn.Linear`, `nn.Conv2d`, `nn.BatchNorm2d`, `nn.Embedding` — must be modules; they own weights or running statistics.
- `F.relu`, `F.max_pool2d`, `F.softmax`, `F.pad` — pure functions, fine anywhere.
- `nn.Dropout` vs `F.dropout` is the sharp edge. ⚠️ `F.dropout(x, p=0.5)` defaults to `training=True` and **ignores `model.eval()`**, so it keeps dropping units at inference unless you pass `training=self.training`. Use `nn.Dropout` and let the module system handle it.

A practical argument for module form even where optional: modules show up in `print(model)`, get hooks, and are visible to quantisation and pruning tooling.

### 4.6 Weight initialisation

PyTorch layers initialise themselves sensibly — `nn.Linear` and `nn.Conv2d` use a Kaiming-uniform scheme by default — so you rarely need to intervene. When you do:

```python
def init_weights(m):
    if isinstance(m, nn.Linear):
        nn.init.kaiming_normal_(m.weight, nonlinearity="relu")
        if m.bias is not None:
            nn.init.zeros_(m.bias)
    elif isinstance(m, nn.Conv2d):
        nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
    elif isinstance(m, nn.BatchNorm2d):
        nn.init.ones_(m.weight)
        nn.init.zeros_(m.bias)

model.apply(init_weights)      # applies the function to every submodule, depth-first
```

**Where the scaling rules come from.** Consider one pre-activation `z = Σᵢ wᵢxᵢ` over `n_in` inputs, with weights and inputs independent and zero-mean. Variances of independent zero-mean terms add, so

```
Var(z) = n_in · Var(w) · Var(x)
```

If the signal is to neither explode nor vanish as it passes through many layers, you want `Var(z) = Var(x)`, which forces

```
Var(w) = 1 / n_in
```

That is **Xavier/Glorot** initialisation (`nn.init.xavier_uniform_`), which in practice uses `2/(n_in + n_out)` to balance the forward pass against the backward pass. It assumes a roughly linear, symmetric activation such as tanh near the origin.

ReLU breaks that assumption: it zeroes the negative half, halving the variance of the output. To compensate, double the weight variance:

```
Var(w) = 2 / n_in
```

That is **Kaiming/He** initialisation (`nn.init.kaiming_normal_`), and this factor-of-two argument is the whole content of the He paper. `mode="fan_in"` preserves forward-pass variance; `mode="fan_out"` preserves backward-pass variance and is what the ResNet reference implementation uses for convolutions.

**Why not initialise everything to zero?** Every unit in a layer would compute the same output, receive the same gradient, and update identically — they would stay permanently identical, so the layer would have the expressive power of a single unit. Random initialisation exists to break that symmetry, and the same argument rules out any single constant.

### 4.7 train() and eval()

```python
model.train()      # sets self.training = True on every submodule
model.eval()       # sets self.training = False on every submodule
```

That is literally all these do: flip a boolean, recursively. Layers read it and behave accordingly. Only two common layer families care:

- **Dropout** drops units during training and becomes the identity in eval.
- **BatchNorm** normalises by batch statistics during training (and updates its running estimates) and by the stored running statistics in eval.

Everything else is unaffected. Chapter 9 explains why this matters enormously in practice.

### 4.8 state\_dict

```python
sd = model.state_dict()             # OrderedDict: name -> tensor
torch.save(sd, "model.pt")

model2 = MLP(784, 256, 10)          # architecture must be reconstructed first
model2.load_state_dict(torch.load("model.pt", weights_only=True))
```

`state_dict` holds parameters *and* buffers, as plain tensors, keyed by dotted path. It does not hold the architecture, the optimizer, or `requires_grad` flags. `load_state_dict(..., strict=False)` returns the lists of missing and unexpected keys instead of raising — invaluable when loading a pretrained backbone into a modified model. Chapter 13 goes deeper, including why `weights_only=True` matters for security.

### 4.9 Writing your own layer

Here is `nn.Linear` reimplemented, which is a genuine interview task:

```python
import math

class MyLinear(nn.Module):
    def __init__(self, in_features, out_features, bias=True):
        super().__init__()
        self.in_features = in_features
        self.out_features = out_features
        self.weight = nn.Parameter(torch.empty(out_features, in_features))
        if bias:
            self.bias = nn.Parameter(torch.empty(out_features))
        else:
            self.register_parameter("bias", None)   # keeps the name in the namespace
        self.reset_parameters()

    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        if self.bias is not None:
            fan_in = self.in_features
            bound = 1 / math.sqrt(fan_in)
            nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x):
        return x @ self.weight.T + (self.bias if self.bias is not None else 0)

    def extra_repr(self):
        return f"in_features={self.in_features}, out_features={self.out_features}"
```

Two details worth noticing. The weight is stored as `(out_features, in_features)` — transposed relative to the mathematical `x @ W` — because that layout makes the underlying GEMM faster; this is why `nn.Linear(784, 256).weight.shape` is `(256, 784)` and surprises people. And `extra_repr` is what makes `print(model)` informative for your own layers.

### 4.10 Hooks, briefly

Hooks let you observe or modify tensors mid-network without editing `forward`.

```python
activations = {}

def save_output(name):
    def hook(module, inputs, output):
        activations[name] = output.detach()
    return hook

handle = model.fc1.register_forward_hook(save_output("fc1"))
model(torch.randn(4, 784))
print(activations["fc1"].shape)    # (4, 256)
handle.remove()                    # ALWAYS remove, or you leak memory
```

Uses: feature extraction for Grad-CAM, activation statistics while debugging, gradient clipping per layer via `register_full_backward_hook`. Remember: hooks only fire when you call `model(x)`, not `model.forward(x)`.

### 4.11 Check yourself

1. Why does a plain list of layers break training, and what breaks first — the forward pass or the optimizer?
2. Name three things stored in `state_dict()` that are not parameters.
3. Why is `self.mask = torch.ones(10)` inside `__init__` a bug on GPU, and what is the fix?
4. What does `model.eval()` actually change? Does it stop gradient tracking?

## 5. The data pipeline: Dataset, DataLoader, transforms

In real projects the data pipeline is where most of the engineering time goes, and it is where interviews probe whether you have actually shipped anything. PyTorch splits the job cleanly: a **Dataset** knows how to produce *one* sample; a **DataLoader** knows how to turn many samples into batches, in parallel, in a useful order.

### 5.1 The Dataset protocol

A map-style dataset implements exactly two methods:

```python
from torch.utils.data import Dataset

class PointsDataset(Dataset):
    def __init__(self, X, y, transform=None):
        self.X = torch.as_tensor(X, dtype=torch.float32)
        self.y = torch.as_tensor(y, dtype=torch.long)
        self.transform = transform

    def __len__(self):
        return len(self.y)

    def __getitem__(self, idx):
        x, y = self.X[idx], self.y[idx]
        if self.transform is not None:
            x = self.transform(x)
        return x, y          # a tuple; the DataLoader will batch each element
```

That is the whole contract. `__getitem__` receives an integer index and returns one sample — usually a `(input, target)` tuple, but any structure of tensors works.

Design guidance that matters in practice:

- **Store paths, not decoded images.** For image datasets, keep a list of file paths in `__init__` and open the file inside `__getitem__`. Loading 100 GB of JPEGs into RAM up front does not work; loading them lazily in worker processes does.
- **Do the augmentation inside `__getitem__`.** Then each worker does it in parallel and every epoch sees a different random crop of the same image.
- **Return tensors, not NumPy arrays**, so the default collate function does the obvious thing.

For streams that have no meaningful length or random access — a socket, a huge sharded log — subclass `IterableDataset` and implement `__iter__` instead. You then take responsibility for splitting work across workers, which is why map-style is preferred whenever it is possible.

### 5.2 The DataLoader

```python
from torch.utils.data import DataLoader

train_loader = DataLoader(
    train_ds,
    batch_size=64,
    shuffle=True,          # reshuffles every epoch
    num_workers=4,         # subprocesses that prepare batches ahead of time
    pin_memory=True,       # faster host->GPU copies; only useful with CUDA
    drop_last=True,        # discard a final partial batch
    persistent_workers=True,   # keep workers alive between epochs
)

val_loader = DataLoader(val_ds, batch_size=256, shuffle=False, num_workers=4)

for xb, yb in train_loader:
    print(xb.shape, yb.shape)   # (64, ...) and (64,)
    break
```

What each argument really does:

| Argument | Effect | Guidance |
| --- | --- | --- |
| `shuffle` | Random order each epoch | `True` for training, `False` for val/test — otherwise your logged predictions do not line up with your labels |
| `num_workers` | Parallel sample preparation | Start at 4, or `os.cpu_count()//2`. `0` means load in the main process, which is what you want while debugging |
| `pin_memory` | Page-locked host memory | `True` on CUDA, pointless on CPU-only |
| `drop_last` | Drop the ragged last batch | `True` for training with BatchNorm (a batch of 1 breaks BN); `False` for evaluation, or you silently ignore samples |
| `persistent_workers` | Avoid worker restart each epoch | `True` when `num_workers > 0` and epochs are short |
| `prefetch_factor` | Batches queued per worker | Default 2; raise only if profiling shows the GPU starving |

⚠️ **`drop_last=True` on your test loader silently shrinks your test set.** If 10,000 test images are loaded with `batch_size=256` and `drop_last=True`, you evaluate on 9,984 and report accuracy on a slightly different set than everyone else. Never do this in evaluation.

⚠️ **`num_workers > 0` on Windows or in a Jupyter notebook** requires the main script to be guarded by `if __name__ == "__main__":`, because worker processes are spawned rather than forked and will re-import your module. Under debugging, set `num_workers=0` — tracebacks from worker processes are unreadable.

### 5.3 Collation: how samples become batches

The DataLoader gets a list of `batch_size` samples from the dataset and passes it to `collate_fn`. The default one recursively `torch.stack`s tensors, converts numbers to tensors, and preserves tuple/dict/list structure. This works whenever every sample has an identical shape.

When shapes vary — sentences of different lengths, point clouds of different sizes — you write your own:

```python
from torch.nn.utils.rnn import pad_sequence

def pad_collate(batch):
    seqs, labels = zip(*batch)                      # tuple of tensors, tuple of ints
    lengths = torch.tensor([len(s) for s in seqs])
    padded  = pad_sequence(seqs, batch_first=True, padding_value=0)  # (B, T_max)
    return padded, lengths, torch.tensor(labels)

loader = DataLoader(ds, batch_size=32, collate_fn=pad_collate)
```

"Write a custom collate function for variable-length sequences" is a standard take-home warm-up. The key insight to state out loud: pad to the longest item *in the batch*, not to a global maximum, and return the lengths so the model can mask.

### 5.4 Samplers and class imbalance

`shuffle=True` is shorthand for `sampler=RandomSampler(dataset)`. You can supply a sampler yourself — and `shuffle` and `sampler` are mutually exclusive.

The common real-world case is imbalanced classes:

```python
from torch.utils.data import WeightedRandomSampler

labels = torch.tensor([0]*900 + [1]*100)          # 9:1 imbalance
class_count = torch.bincount(labels).float()      # [900., 100.]
class_weight = 1.0 / class_count                  # rarer class -> larger weight
sample_weight = class_weight[labels]              # one weight per SAMPLE

sampler = WeightedRandomSampler(sample_weight, num_samples=len(labels), replacement=True)
loader = DataLoader(ds, batch_size=64, sampler=sampler)   # note: no shuffle=True
```

This draws roughly balanced batches. The alternative is to leave sampling alone and weight the loss instead (`nn.CrossEntropyLoss(weight=class_weight)`). Interviewers like asking you to compare them: resampling changes the effective data distribution and can overfit the minority class by repetition; loss weighting keeps the data distribution but changes the objective. Neither is universally better, and for extreme imbalance you often also need a metric other than accuracy.

### 5.5 torchvision datasets and transforms

```python
from torchvision import datasets
from torchvision.transforms import v2

train_tf = v2.Compose([
    v2.RandomCrop(32, padding=4),
    v2.RandomHorizontalFlip(),
    v2.ToImage(),                              # PIL/ndarray -> tv_tensors.Image
    v2.ToDtype(torch.float32, scale=True),     # uint8 [0,255] -> float32 [0,1]
    v2.Normalize(mean=(0.4914, 0.4822, 0.4465),
                 std=(0.2470, 0.2435, 0.2616)),
])

test_tf = v2.Compose([
    v2.ToImage(),
    v2.ToDtype(torch.float32, scale=True),
    v2.Normalize(mean=(0.4914, 0.4822, 0.4465),
                 std=(0.2470, 0.2435, 0.2616)),
])

train_ds = datasets.CIFAR10(root="./data", train=True,  download=True, transform=train_tf)
test_ds  = datasets.CIFAR10(root="./data", train=False, download=True, transform=test_tf)
```

Four things to understand here.

**`transforms.v2` is the current API.** The older `torchvision.transforms` still works, but v2 is faster, supports batched tensors, and transforms bounding boxes and masks alongside images. In v2, `ToImage()` followed by `ToDtype(torch.float32, scale=True)` replaces the old `ToTensor()`. You will see `ToTensor()` in every tutorial written before 2024; recognise it, but prefer the v2 pair.

**Normalisation is `(x - mean) / std`, per channel.** The constants above are the per-channel means and standard deviations of the CIFAR-10 training set. For ImageNet-pretrained models the required constants are `mean=(0.485, 0.456, 0.406)`, `std=(0.229, 0.224, 0.225)` — you must use these when fine-tuning such a model, because its weights were learned on inputs scaled that way.

**Augmentations go on the training transform only.** ⚠️ Random cropping and flipping your test set makes evaluation noisy and non-reproducible. The test pipeline should be deterministic.

**Order matters.** Geometric ops on PIL images come before conversion to tensor; `Normalize` must come after `ToDtype(..., scale=True)`, because it expects floats.

### 5.6 Splitting data without cheating

```python
from torch.utils.data import random_split

g = torch.Generator().manual_seed(42)
train_sub, val_sub = random_split(train_ds, [45_000, 5_000], generator=g)
```

⚠️ The subtle bug: `random_split` returns `Subset` objects that share the *same underlying dataset object*, and therefore the *same transform*. Your validation set now gets random crops and flips. Two clean fixes: build two dataset instances with different transforms and split both with the same generator and indices, or set the transform on a per-subset wrapper:

```python
class WithTransform(Dataset):
    def __init__(self, subset, transform):
        self.subset, self.transform = subset, transform
    def __len__(self):
        return len(self.subset)
    def __getitem__(self, i):
        x, y = self.subset[i]
        return self.transform(x), y
```

The deeper principle, which interviewers probe relentlessly: **anything fitted on data must be fitted on the training split only.** Normalisation statistics, PCA, vocabularies, class weights, imputation values. Computing the mean over the whole dataset before splitting leaks test information into training and inflates your reported score.

### 5.7 Reproducible workers

Each worker process needs its own random seed, or (in some setups) several workers generate identical augmentations.

```python
def seed_worker(worker_id):
    worker_seed = torch.initial_seed() % 2**32
    np.random.seed(worker_seed)
    random.seed(worker_seed)

g = torch.Generator().manual_seed(0)
loader = DataLoader(ds, batch_size=64, shuffle=True,
                    num_workers=4, worker_init_fn=seed_worker, generator=g)
```

### 5.8 Is your input pipeline the bottleneck?

A quick diagnostic before you buy a bigger GPU:

```python
import time

start = time.time()
for i, _ in enumerate(train_loader):
    if i == 50:
        break
print(f"{51 * train_loader.batch_size / (time.time() - start):.0f} samples/s, data only")
```

Compare this with your observed training throughput. If they are close, the GPU is starving and the fix is more workers, faster decoding, smaller images on disk, or caching — not a better model. `nvidia-smi` showing low and spiky GPU utilisation is the same symptom.

### 5.9 Check yourself

1. What two methods must a map-style `Dataset` implement?
2. Why is `drop_last=True` correct for training but wrong for testing?
3. Your validation accuracy is unstable between runs even with a fixed seed. Name two data-pipeline causes.
4. Give two ways to handle a 100:1 class imbalance, and one trade-off of each.

## 6. Losses and optimizers

### 6.1 Choosing a loss

| Task | Loss | Model output | Target |
| --- | --- | --- | --- |
| Regression | `nn.MSELoss` | any real | same shape, float |
| Regression, outlier-robust | `nn.L1Loss`, `nn.SmoothL1Loss`/`HuberLoss` | any real | same shape, float |
| Multi-class, one label per sample | `nn.CrossEntropyLoss` | **logits** `(B, C)` | `(B,)` int64 class indices |
| Binary or multi-label | `nn.BCEWithLogitsLoss` | **logits** `(B,)` or `(B, K)` | same shape, float 0/1 |
| Already log-probabilities | `nn.NLLLoss` | `log_softmax` output | `(B,)` int64 |
| Distribution matching (distillation) | `nn.KLDivLoss` | `log_softmax` output | probabilities |

The two facts that fix most beginner errors: **`CrossEntropyLoss` takes raw logits**, and **its target is a 1-D vector of integer class indices, not one-hot vectors**.

```python
logits = torch.randn(4, 10)                 # (B, C), raw scores
target = torch.tensor([3, 1, 9, 0])         # (B,), int64, values in [0, C)
loss = nn.CrossEntropyLoss()(logits, target)
```

⚠️ Passing `float` targets, one-hot targets, or softmax outputs are the three ways students break this. (Modern PyTorch *does* accept float probability targets for label-smoothing use cases, but if you pass one-hot floats by accident together with softmaxed inputs, you get a number that trains nothing.)

### 6.2 Why the loss swallows the softmax: numerical stability

Cross-entropy for one sample is `−log p_y` where `p = softmax(z)`. Written naively:

```python
p = torch.softmax(z, dim=1)
loss = -torch.log(p[range(B), y])      # fragile
```

If any logit is large, `exp(z)` overflows to `inf`; if `p_y` underflows to 0, `log(0) = -inf` and every gradient becomes `nan`. The stable formulation folds the two operations together using the log-sum-exp trick:

`log softmax(z)_i = z_i − max(z) − log Σ_j exp(z_j − max(z))`

Subtracting the maximum leaves the result unchanged mathematically (softmax is shift-invariant) but guarantees the largest exponent is `exp(0) = 1`. `nn.CrossEntropyLoss` and `F.log_softmax` do this internally. That is the entire reason the API is shaped the way it is, and it is among the most commonly asked questions on this topic.

The same argument applies to `BCEWithLogitsLoss` versus `Sigmoid` + `BCELoss`, and it is worth seeing the actual failure rather than being told about it. ⚠️ **Never apply a sigmoid yourself and then call `nn.BCELoss`.** Use `BCEWithLogitsLoss` on raw logits.

```python
logits = torch.tensor([-50.0, 50.0], requires_grad=True)   # confidently WRONG both ways
target = torch.tensor([1.0, 0.0])

nn.BCEWithLogitsLoss()(logits, target)            # tensor(50.0)  <- correct
nn.BCELoss()(torch.sigmoid(logits), target)       # tensor(75.0)  <- wrong
```

The true loss is 50: for a target of 1 the term is `−log σ(z)`, for a target of 0 it is `−log(1 − σ(z))`, and at `|z| = 50` both come to 50. Trace where the split version loses it:

```python
torch.sigmoid(torch.tensor(-50.0))     # 1.9287e-22  — small, but perfectly representable
torch.sigmoid(torch.tensor( 50.0))     # 1.0         — rounds to EXACTLY one
```

The first element is fine. The second is the casualty: `σ(50)` rounds to exactly `1.0` in float32, so `1 − p` is exactly `0`, `log(0)` would be `−inf`, and `BCELoss` clamps its log output at `−100`. The mean of the correct 50 and the clamped 100 is 75. The clamp converts a `nan` into a plausible-looking wrong number, which is arguably worse — nothing alerts you.

The gradient is where the real damage is, and it is the opposite of what people expect. Differentiate all the way back to the logits, which is what training actually does:

```python
# gradient w.r.t. the LOGITS — the quantity the model actually receives
# BCEWithLogitsLoss:  tensor([-0.5000,  0.5000])          bounded, exactly right
# Sigmoid + BCELoss:  tensor([-9.6437e-11,  0.0000e+00])  vanished
```

The split version's gradient does not explode — it **vanishes**, and the model can therefore never correct these two confidently wrong predictions. Follow the chain rule to see why. `BCELoss` clamps its gradient with respect to the probability at magnitude `1e12`, but the sigmoid's local derivative is `p(1−p) = 1.93e-22`, and the product is `1e12 × 1.93e-22 / 2 = 9.64e-11`. For the second element it is worse still: `p = 1.0` exactly, so `p(1−p) = 0` and the gradient is **exactly zero** — that error is frozen forever, like a dead ReLU (§9.4).

The fused version never forms `p` as an intermediate. Its gradient with respect to the logit is `(σ(z) − y)/B`, which is bounded by `1/B` and, crucially, is **largest exactly when the prediction is most wrong**. That is the behaviour you want from a loss, and it is why the API is shaped this way.

⚠️ If you take one thing from this section: a model that will not learn from its worst mistakes is often a saturated-sigmoid problem, not a learning-rate problem.

### 6.3 Useful loss arguments

```python
nn.CrossEntropyLoss(
    weight=torch.tensor([1.0, 5.0, 2.0]),  # per-class weights for imbalance
    label_smoothing=0.1,                    # target 0.9 for the true class, 0.1/(C-1) elsewhere
    ignore_index=-100,                      # skip padding tokens entirely
    reduction="mean",                       # 'mean' | 'sum' | 'none'
)

nn.BCEWithLogitsLoss(pos_weight=torch.tensor([9.0]))   # up-weight the positive class
```

`reduction="none"` returns a per-sample loss vector, which you need for per-sample weighting, hard-example mining, or focal loss. `label_smoothing` discourages the network from driving logits to infinity and usually gives a small accuracy gain and much better-calibrated probabilities.

Writing a custom loss is just writing a function that returns a scalar tensor:

```python
def focal_loss(logits, target, gamma=2.0):
    ce = F.cross_entropy(logits, target, reduction="none")   # (B,)
    pt = torch.exp(-ce)                                      # prob of the true class
    return ((1 - pt) ** gamma * ce).mean()
```

No subclassing is required — autograd differentiates whatever you compose out of tensor ops.

### 6.4 Optimizers: the update rules

Let `θ` be a parameter, `g = ∂L/∂θ`, `η` the learning rate.

**SGD.** `θ ← θ − η g`. Simple, memory-free, and still the best final accuracy for convolutional vision models when tuned.

**SGD with momentum.** Maintains a velocity `v`:

```
v ← μ v + g
θ ← θ − η v
```

with `μ ≈ 0.9`. The intuition: gradients in a narrow ravine oscillate across the walls and point consistently along the floor; averaging cancels the oscillation and accumulates the consistent direction, giving roughly a `1/(1−μ) = 10×` effective step along stable directions. Nesterov momentum evaluates the gradient after the momentum step, a look-ahead that slightly improves convergence.

**Adam.** Keeps exponential moving averages of the gradient and its square:

```
m ← β₁ m + (1−β₁) g            (first moment, like momentum)
v ← β₂ v + (1−β₂) g²           (second moment, per-parameter scale)
m̂ = m / (1−β₁ᵗ),  v̂ = v / (1−β₂ᵗ)      (bias correction)
θ ← θ − η m̂ / (√v̂ + ε)
```

Defaults `β₁=0.9, β₂=0.999, ε=1e-8`. The division by `√v̂` gives each parameter its own effective learning rate: parameters with consistently large gradients take smaller steps. Bias correction exists because `m` and `v` start at zero and would otherwise be badly underestimated in the first iterations.

**AdamW.** Decouples weight decay from the gradient. In Adam, adding `λθ` to the gradient means the decay also gets divided by `√v̂`, so parameters with small gradients are barely regularised. AdamW instead applies `θ ← θ − ηλθ` directly:

```
θ ← θ − η ( m̂ / (√v̂ + ε) + λ θ )
```

This is why ⚠️ `Adam(weight_decay=0.01)` and `AdamW(weight_decay=0.01)` are *not* the same thing, and why AdamW is the default for transformers and most modern training recipes. Expect to be asked this.

```python
opt = torch.optim.SGD(model.parameters(), lr=0.1, momentum=0.9,
                      weight_decay=5e-4, nesterov=True)
opt = torch.optim.AdamW(model.parameters(), lr=3e-4, weight_decay=0.01)
```

**Practical defaults.** Adam/AdamW at `lr=1e-3` (small models) or `3e-4` (larger) converges fast with little tuning and is the right first choice. SGD+momentum at `lr=0.1` with a cosine schedule and `weight_decay=5e-4` is the standard recipe for CNNs on CIFAR/ImageNet and usually generalises slightly better, at the cost of needing a tuned schedule.

### 6.5 Parameter groups

Different parts of a model often want different hyperparameters:

```python
opt = torch.optim.AdamW([
    {"params": model.backbone.parameters(), "lr": 1e-4},   # pretrained: move gently
    {"params": model.head.parameters(),     "lr": 1e-3},   # new: move fast
], weight_decay=0.01)    # applies to groups that don't override it
```

The standard refinement, used in essentially every serious recipe: **do not apply weight decay to biases or normalisation parameters.** Shrinking a BatchNorm scale toward zero actively hurts.

```python
decay, no_decay = [], []
for name, p in model.named_parameters():
    if not p.requires_grad:
        continue
    if p.ndim <= 1 or name.endswith(".bias"):    # biases, BN/LN weights
        no_decay.append(p)
    else:
        decay.append(p)

opt = torch.optim.AdamW([
    {"params": decay,    "weight_decay": 0.01},
    {"params": no_decay, "weight_decay": 0.0},
], lr=3e-4)
```

### 6.6 Learning-rate schedules

The learning rate is the single most important hyperparameter. Too high and the loss diverges or plateaus high; too low and training crawls or lands in a poor basin.

```python
from torch.optim import lr_scheduler

sched = lr_scheduler.StepLR(opt, step_size=30, gamma=0.1)        # ×0.1 every 30 epochs
sched = lr_scheduler.MultiStepLR(opt, milestones=[60, 90], gamma=0.1)
sched = lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)        # smooth decay to ~0
sched = lr_scheduler.OneCycleLR(opt, max_lr=0.1,
                                steps_per_epoch=len(train_loader), epochs=epochs)
sched = lr_scheduler.ReduceLROnPlateau(opt, mode="min", factor=0.5, patience=5)
```

Rules for using them correctly:

- Call `scheduler.step()` **after** `optimizer.step()`. Calling it before produces a warning and skips the first learning rate.
- Most schedulers step **once per epoch**. `OneCycleLR` and warmup schedulers step **once per batch**. Getting this wrong by a factor of `len(loader)` is a very common bug — your cosine schedule finishes in the first epoch.
- `ReduceLROnPlateau` is the exception that takes an argument: `sched.step(val_loss)`.
- Log the actual value with `opt.param_groups[0]["lr"]` (or `sched.get_last_lr()`) and plot it. Half of all "my training is broken" reports are a schedule that is not doing what the author thinks.

**Warmup.** Large batch sizes and transformers need the learning rate ramped up over the first few hundred iterations, because early gradients are large and Adam's second-moment estimate is still unreliable. Compose it:

```python
warm = lr_scheduler.LinearLR(opt, start_factor=0.01, total_iters=500)
cos  = lr_scheduler.CosineAnnealingLR(opt, T_max=total_steps - 500)
sched = lr_scheduler.SequentialLR(opt, [warm, cos], milestones=[500])
```

**Finding a learning rate: the range test.** The cheapest reliable method is to train for a few hundred iterations while multiplying the learning rate geometrically from very small to very large, recording the loss at each step.

```python
def lr_range_test(model_fn, loader, criterion, lo=1e-7, hi=10.0, steps=100):
    """Returns (lrs, losses). Plot losses against log(lrs) and read the curve."""
    model = model_fn()                       # a FRESH model: the test perturbs weights
    opt = torch.optim.SGD(model.parameters(), lr=lo)
    mult = (hi / lo) ** (1 / steps)
    lrs, losses, best = [], [], float("inf")
    it = iter(loader)

    for _ in range(steps):
        try:
            xb, yb = next(it)
        except StopIteration:
            it = iter(loader); xb, yb = next(it)

        opt.zero_grad(set_to_none=True)
        loss = criterion(model(xb), yb)
        loss.backward()
        opt.step()

        lrs.append(opt.param_groups[0]["lr"])
        losses.append(loss.item())
        best = min(best, loss.item())
        if not torch.isfinite(loss) or loss.item() > 4 * best:
            break                            # diverged; no point continuing
        for group in opt.param_groups:
            group["lr"] *= mult

    return lrs, losses
```

How to read the resulting curve, from left to right: a flat region where the learning rate is too small to move anything; a descending region where the loss drops fastest; a minimum; then a sharp rise into divergence. **Pick roughly one order of magnitude below the point of steepest descent** — not the minimum itself, which is already close to unstable.

In an interview, "how would you choose a learning rate?" is answered with this procedure plus the two diagnostic shapes: a loss that diverges or goes `nan` means too high; a loss that falls slowly and linearly means too low.

### 6.7 Check yourself

1. Why does `CrossEntropyLoss` expect logits rather than probabilities? Give the numerical argument.
2. What exactly differs between Adam and AdamW?
3. Where in the loop does `scheduler.step()` go, and when is it per-batch rather than per-epoch?
4. Why exclude biases and BatchNorm weights from weight decay?

## 7. The training loop, metrics, and your first complete model

### 7.1 The five lines

Every PyTorch training step is these five lines. Memorise them; you will be asked to write them on a whiteboard.

```python
for xb, yb in train_loader:
    optimizer.zero_grad()          # 1. clear gradients from the previous step
    preds = model(xb)              # 2. forward pass; builds the graph
    loss  = criterion(preds, yb)   # 3. reduce to a single scalar
    loss.backward()                # 4. backward pass; fills .grad on every parameter
    optimizer.step()               # 5. update parameters using .grad
```

Why this order, and what breaks if you change it:

- **Omit `zero_grad`** → gradients accumulate across batches, the effective step grows without bound, loss diverges. The most common bug in the world.
- **Call `step` before `backward`** → the step uses last iteration's gradients; the model updates in the wrong direction and training is subtly, permanently worse.
- **Call `zero_grad` after `backward`** → you erase the gradients you just computed, `step` does nothing, the model never changes.
- **Loss is not a scalar** → `backward()` raises (see §3.4).

`zero_grad` may go either at the top of the loop or immediately after `step()`; both are correct. Top-of-loop is more robust because it survives `continue` statements.

### 7.2 The full loop, annotated

```python
import torch, torch.nn as nn

def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()                                  # dropout ON, BN uses batch stats
    running_loss, correct, seen = 0.0, 0, 0

    for xb, yb in loader:
        xb = xb.to(device, non_blocking=True)      # non_blocking pairs with pin_memory
        yb = yb.to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)
        logits = model(xb)
        loss = criterion(logits, yb)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)   # optional
        optimizer.step()

        bs = yb.size(0)
        running_loss += loss.item() * bs           # .item() detaches -> no graph leak
        correct += (logits.argmax(1) == yb).sum().item()
        seen += bs

    return running_loss / seen, correct / seen


@torch.no_grad()                                   # decorator form; applies to the body
def evaluate(model, loader, criterion, device):
    model.eval()                                   # dropout OFF, BN uses running stats
    total_loss, correct, seen = 0.0, 0, 0

    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        logits = model(xb)
        total_loss += criterion(logits, yb).item() * yb.size(0)
        correct += (logits.argmax(1) == yb).sum().item()
        seen += yb.size(0)

    return total_loss / seen, correct / seen
```

Seven details in that code that are worth stating explicitly in an interview:

1. `model.train()` and `model.eval()` are called **every** epoch, not once at the start. If you evaluate mid-epoch you must switch back.
2. `@torch.no_grad()` and `model.eval()` are both present, for the two different reasons from §3.6.
3. Losses are weighted by `bs` before summing, so the epoch average is correct even when the last batch is smaller.
4. `.item()` is called immediately, so no computational graph survives the iteration.
5. `non_blocking=True` only helps when the source tensor is in pinned memory.
6. Accuracy is computed from `argmax` on logits — no softmax needed, since softmax is monotonic and does not change the argmax.
7. Gradient clipping is optional for CNNs but essential for RNNs and useful for transformers.

### 7.3 Checkpointing and early stopping

```python
best_val = float("inf")
patience, bad_epochs = 10, 0

for epoch in range(1, epochs + 1):
    tr_loss, tr_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
    va_loss, va_acc = evaluate(model, val_loader, criterion, device)
    scheduler.step()                       # AFTER optimizer.step()s for this epoch

    print(f"epoch {epoch:3d} | train {tr_loss:.4f}/{tr_acc:.3f} "
          f"| val {va_loss:.4f}/{va_acc:.3f} | lr {scheduler.get_last_lr()[0]:.2e}")

    if va_loss < best_val:
        best_val, bad_epochs = va_loss, 0
        torch.save({
            "epoch": epoch,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "best_val": best_val,
        }, "best.pt")
    else:
        bad_epochs += 1
        if bad_epochs >= patience:
            print(f"early stop at epoch {epoch}")
            break

# restore the best weights before testing
ckpt = torch.load("best.pt", weights_only=True)
model.load_state_dict(ckpt["model"])
```

Save the optimizer and scheduler state too, not just the weights. Without the optimizer state, resuming a half-trained Adam run restarts the moment estimates from zero and the loss visibly jumps.

⚠️ **Model selection must use the validation set, and only the validation set.** Selecting the checkpoint by test accuracy means your reported test number is optimistically biased — you have used the test set for fitting. Touch the test set once, at the end.

### 7.4 Complete worked example: FashionMNIST with an MLP

This runs in about a minute on CPU and gets roughly 88–89% test accuracy.

```python
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from torchvision import datasets
from torchvision.transforms import v2

torch.manual_seed(0)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# ---- data -----------------------------------------------------------------
tf = v2.Compose([
    v2.ToImage(),
    v2.ToDtype(torch.float32, scale=True),
    v2.Normalize((0.2860,), (0.3530,)),        # FashionMNIST train statistics
])

full_train = datasets.FashionMNIST("./data", train=True,  download=True, transform=tf)
test_ds    = datasets.FashionMNIST("./data", train=False, download=True, transform=tf)

g = torch.Generator().manual_seed(42)
train_ds, val_ds = random_split(full_train, [54_000, 6_000], generator=g)

train_loader = DataLoader(train_ds, batch_size=128, shuffle=True,  num_workers=2)
val_loader   = DataLoader(val_ds,   batch_size=512, shuffle=False, num_workers=2)
test_loader  = DataLoader(test_ds,  batch_size=512, shuffle=False, num_workers=2)

# ---- model ----------------------------------------------------------------
class MLP(nn.Module):
    def __init__(self, in_dim=28*28, hidden=256, n_classes=10, p_drop=0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Flatten(),                       # (B,1,28,28) -> (B,784)
            nn.Linear(in_dim, hidden), nn.ReLU(), nn.Dropout(p_drop),
            nn.Linear(hidden, hidden),  nn.ReLU(), nn.Dropout(p_drop),
            nn.Linear(hidden, n_classes),       # logits
        )

    def forward(self, x):
        return self.net(x)

model = MLP().to(device)
print(sum(p.numel() for p in model.parameters()), "parameters")   # 269,322

# ---- training -------------------------------------------------------------
criterion = nn.CrossEntropyLoss()
optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
EPOCHS = 15
scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

best_val, best_state = float("inf"), None
for epoch in range(1, EPOCHS + 1):
    tr_loss, tr_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
    va_loss, va_acc = evaluate(model, val_loader, criterion, device)
    scheduler.step()
    print(f"{epoch:2d}  train {tr_loss:.4f} ({tr_acc:.3f})   val {va_loss:.4f} ({va_acc:.3f})")
    if va_loss < best_val:
        best_val = va_loss
        best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

model.load_state_dict(best_state)
te_loss, te_acc = evaluate(model, test_loader, criterion, device)
print(f"TEST  loss {te_loss:.4f}  accuracy {te_acc:.4f}")
```

Note `{k: v.detach().cpu().clone() ...}` when keeping the best state in memory. ⚠️ `best_state = model.state_dict()` stores *references* to the live tensors, which keep changing as training continues — so you would "restore" the final model, not the best one. This is a genuinely nasty bug that has shipped in published code.

### 7.5 Measuring the right thing

Everything above reports accuracy. Accuracy is the right metric for exactly one situation — balanced classes where every kind of mistake costs the same — and that situation is rare outside textbooks. Getting this wrong is not a rounding error; it produces models that look excellent and are useless.

**The one-line demonstration.** Take a dataset that is 99% negative (fraud, disease screening, defect detection). A model that ignores its input and always predicts "negative":

```python
y    = torch.cat([torch.ones(10), torch.zeros(990)])   # 10 positives in 1000
pred = torch.zeros(1000)                               # always predict negative
print((pred == y).float().mean().item())                # 0.99
```

99% accuracy, zero value. Any real model that scores 97% is *worse by this metric* and probably far more useful. This is why "what metric are you using, and why?" is one of the first questions a good interviewer asks.

**The confusion matrix is the primitive.** Everything else is derived from it, so compute it first and keep it around.

```python
@torch.no_grad()
def confusion_matrix(model, loader, n_classes, device):
    """cm[i, j] = number of samples with true class i predicted as class j."""
    model.eval()
    cm = torch.zeros(n_classes, n_classes, dtype=torch.long)
    for xb, yb in loader:
        pred = model(xb.to(device)).argmax(1).cpu()
        for t, p in zip(yb, pred):
            cm[t, p] += 1
    return cm


def precision_recall_f1(cm):
    tp        = cm.diag().float()
    precision = tp / cm.sum(0).clamp_min(1)      # column sums = how often we PREDICTED it
    recall    = tp / cm.sum(1).clamp_min(1)      # row sums    = how often it was TRUE
    f1        = 2 * precision * recall / (precision + recall).clamp_min(1e-12)
    return precision, recall, f1
```

Worked example, with real output:

```python
cm = torch.tensor([[ 90,  10],       # 100 true positives: 90 caught, 10 missed
                   [  5, 895]])      # 900 true negatives: 5 false alarms
precision_recall_f1(cm)
# precision  [0.9474, 0.9890]
# recall     [0.9000, 0.9944]
# f1         [0.9231, 0.9917]
# accuracy    0.9850
```

Read it as English. **Precision** answers "when the model says positive, how often is it right?" — `90/(90+5) = 0.947`. **Recall** (sensitivity) answers "of all the real positives, how many did we catch?" — `90/(90+10) = 0.900`. **F1** is their harmonic mean, which stays low if *either* is low, unlike the arithmetic mean.

**Which one you optimise is a statement about cost, not about mathematics.**

| Situation | Optimise | Because a mistake costs… |
| --- | --- | --- |
| Cancer screening | Recall | A missed tumour is far worse than a needless follow-up scan |
| Spam filter | Precision | A lost job offer is far worse than a spam message getting through |
| Search / recommendation | Precision@k | Users only look at the top few results |
| Balanced benchmark (CIFAR, ImageNet) | Accuracy, top-5 | All classes and errors are treated alike |

Say this explicitly in an interview: *"the metric follows from the relative cost of a false positive and a false negative, so I'd ask the product owner which is worse before choosing."*

**Averaging across classes.** With more than two classes you must say how you combine per-class scores:

- **Macro** — unweighted mean over classes. Every class counts equally, so rare classes matter as much as common ones. Usually what you want under imbalance.
- **Micro** — pool all true positives, false positives and false negatives before dividing. Dominated by common classes; for single-label classification micro-F1 equals accuracy.
- **Weighted** — mean weighted by class frequency. A compromise, and the one most likely to hide a failure on the rare class.

```python
precision, recall, f1 = precision_recall_f1(cm)
macro_f1    = f1.mean()
weighted_f1 = (f1 * cm.sum(1).float() / cm.sum()).sum()
```

Here is why the choice matters, on a realistic four-class problem with an imbalanced test set:

```
cm = [[4900,  60,  30,  10]     support 5000
      [  80, 700,  15,   5]     support  800
      [  60,  40,  90,  10]     support  200
      [  25,  10,   5,  10]]    support   50

per-class precision   0.967   0.864   0.643   0.286
per-class recall      0.980   0.875   0.450   0.200
per-class F1          0.974   0.870   0.529   0.235

accuracy      0.9421
weighted-F1   0.9391
macro-F1      0.6520     <- the only number that notices class 3 is broken
```

Accuracy and weighted-F1 agree to within half a point and both say "94%, ship it." Macro-F1 says 65%, because the rarest class is recovered only one time in five. Report all three plus the per-class table, and lead with the one that reflects what a mistake costs.

**Read the off-diagonal too.** The largest off-diagonal entries tell you *which* confusions to fix, which is far more actionable than any aggregate:

```python
off = cm.clone()
off.fill_diagonal_(0)
top = torch.topk(off.flatten(), k=3)
for value, idx in zip(top.values, top.indices):
    print(f"true {idx // len(cm)} predicted as {idx % len(cm)}: {value} times")
```

On CIFAR-10 this reliably surfaces cat↔dog and automobile↔truck. Those are semantically close classes that are genuinely hard at 32×32 resolution — a data and resolution limitation, not an argument for more layers.

**The threshold is a free parameter, and accuracy hides it.** A binary classifier outputs a score; turning it into a decision requires a threshold, and 0.5 is a default, not a law. Sweeping the threshold traces a curve:

- **ROC-AUC** plots true-positive rate against false-positive rate. ⚠️ It is *optimistic under heavy imbalance*, because the false-positive rate has a huge denominator — you can add hundreds of false alarms and barely move it.
- **PR-AUC** (average precision) plots precision against recall and is the honest choice when positives are rare. For a 1%-positive dataset, a random model has PR-AUC ≈ 0.01 and ROC-AUC ≈ 0.5, so PR-AUC has far more room to distinguish models.

Tune the threshold on the **validation** set, using the same cost argument as above, and report it alongside the model. A threshold chosen on the test set is test-set fitting.

**Calibration** is a separate question from ranking. A model can order examples perfectly (AUC 1.0) while its probabilities are systematically overconfident. If a downstream system consumes the probability — expected-value calculations, triage thresholds, human review queues — check it by binning predictions and comparing mean predicted probability against observed frequency in each bin. Label smoothing (§6.3) and temperature scaling both improve calibration.

**For regression**, the same reasoning applies: RMSE punishes large errors quadratically and is sensitive to outliers; MAE treats all errors linearly and is the median-seeking loss; MAPE is scale-free but explodes near zero targets and asymmetrically penalises over-prediction. R² tells you how much variance you explain relative to predicting the mean, which is the baseline worth reporting.

**The rule that survives every interview:** always report your metric *next to the trivial baseline*. "94% accuracy" means nothing until you say the majority-class baseline is 99%, or 10%. A number without its baseline is not a result.

### 7.6 Reading your loss curves

| Symptom | Likely cause | First thing to try |
| --- | --- | --- |
| Train loss flat from step 0 | LR far too small; frozen parameters; broken graph (`detach` somewhere) | Raise LR ×10; check `p.grad is not None` after backward |
| Loss → `nan` after a few steps | LR too high; `log(0)`; exploding gradients; bad input scaling | Lower LR; use logit-based losses; clip gradients; check for NaNs in data |
| Train loss falls, val loss rises | Overfitting | More augmentation, weight decay, dropout, early stopping, more data |
| Both losses plateau high | Underfitting / too little capacity | Bigger model, train longer, higher LR, remove excessive regularisation |
| Val loss much *lower* than train loss | Dropout active in train only (normal, small gap), or a leak / too-easy val split | Check split construction |
| Loss spikes periodically | A pathological batch; LR schedule restarts; too-large batch variance | Inspect the data at those steps |

### 7.7 The debugging protocol that actually works

Before you tune anything, run this ladder in order. It localises nearly every bug in minutes.

```
   THE LOSS IS NOT GOING DOWN
            |
            v
   [1] shapes, label dtype and range correct? ---no--> fix the data pipeline
            | yes
            v
   [2] initial loss approximately ln(C)? ---------no--> check the output layer,
            | yes                                       the labels, and the loss fn
            v
   [3] does ONE batch overfit to ~0 loss? --------no--> the bug is in the model
            | yes                                       or the loss, not the data
            v
   [4] every parameter has a non-zero gradient? -no--> broken graph, or frozen
            | yes                                       parameters
            v
   [5] ONLY NOW: tune the learning rate
```

1. **Check shapes and dtypes.** Print `xb.shape, xb.dtype, yb.shape, yb.dtype, yb.min(), yb.max()` for one batch. Labels must be `int64` in `[0, C)`.
2. **Check the initial loss.** For a balanced `C`-class problem with random weights, cross-entropy should start near `ln(C)` — about 2.30 for 10 classes, 6.91 for 1000. A wildly different starting loss means the output layer, the labels, or the loss is wrong.
3. **Overfit a single batch.** Take one batch of 8 samples and train on it for 200 steps with no augmentation and no regularisation. The loss must reach approximately zero. If it cannot, the bug is in the model or the loss — not in your data or hyperparameters. **This is the single most valuable debugging technique in deep learning, and a superb answer to "how do you debug a model that isn't learning?"**
4. **Verify gradients flow.** After `loss.backward()`, check that no parameter has `p.grad is None` and that the norms are not all zero:

   ```python
   for n, p in model.named_parameters():
       g = 0.0 if p.grad is None else p.grad.norm().item()
       print(f"{n:30s} grad_norm={g:.3e}")
   ```
5. **Then, and only then**, scale up to the full dataset and tune the learning rate.

### 7.8 Check yourself

1. Write the five-line training step from memory, then explain what each line would break.
2. Your 10-class classifier starts at loss 7.4. What is wrong?
3. Why store `{k: v.cpu().clone()}` rather than `model.state_dict()` for the best checkpoint?
4. A colleague reports 99.2% accuracy on a fraud dataset. What is your first question?
5. When is ROC-AUC misleading, and what replaces it?
6. Give the procedure you would follow for "the loss is not going down."

## 8. Convolution from first principles

### 8.1 Why not just use an MLP on images?

Take a modest 224×224 RGB image and a first hidden layer of 1000 units. A fully connected layer needs `224·224·3·1000 ≈ 150 million` weights — for one layer. Worse, it has no notion that the pixel at (10, 10) and the pixel at (10, 11) are neighbours: shuffle the pixels consistently across the whole dataset and an MLP learns exactly as well. That is a red flag, because it means the architecture encodes none of what we know about images.

Convolution builds in three assumptions, and these three sentences are the complete answer to "why CNNs for images?":

1. **Locality.** Useful features (edges, corners, textures) are local, so a unit only needs to look at a small neighbourhood.
2. **Weight sharing / translation equivariance.** An edge detector is useful everywhere, so use the same filter at every position. Shifting the input shifts the output correspondingly. This cuts parameters by orders of magnitude and is a genuine statistical prior, not just a compression trick.
3. **Hierarchical composition.** Stacking local operations makes later units see larger regions, so simple features compose into complex ones.

The same first layer as a `Conv2d(3, 64, kernel_size=3)` has `3·64·3·3 + 64 = 1,792` parameters, independent of image size.

### 8.2 What `conv2d` actually computes

For input `x` of shape `(B, C_in, H, W)` and weight `w` of shape `(C_out, C_in, K_h, K_w)`, the output at batch `b`, output channel `o`, position `(i, j)` is:

```
out[b, o, i, j] = bias[o] + Σ_c Σ_p Σ_q  x[b, c, i·S + p, j·S + q] · w[o, c, p, q]
```

Three observations that clear up most confusion:

- **Every filter spans all input channels.** A 3×3 filter on a 3-channel input is a `3×3×3 = 27`-weight object, not a 9-weight object. It produces **one** output channel. `C_out` filters produce `C_out` output channels.
- **This is technically cross-correlation, not convolution.** True mathematical convolution flips the kernel. Since the kernel is learned, the flip is irrelevant — the network just learns the flipped filter. Saying this out loud in an interview is a small, reliable signal of depth.
- **The bias is per output channel**, one scalar each, so `C_out` biases total.

### 8.3 The output-size formula

This is the formula to have permanently memorised:

```
H_out = floor( (H_in + 2·P − D·(K − 1) − 1) / S ) + 1
```

where `P` = padding, `K` = kernel size, `S` = stride, `D` = dilation. With the usual `D = 1` it simplifies to the form most people carry around:

```
H_out = floor( (H_in + 2·P − K) / S ) + 1
```

Derivation, so you can rebuild it if you blank: after padding, the usable length is `H_in + 2P`. The kernel with dilation `D` physically spans `D·(K−1) + 1` positions. The number of valid starting positions at stride 1 is `H_in + 2P − (D·(K−1) + 1) + 1`; at stride `S` you keep every `S`-th one, giving the floor expression plus one for the initial position.

See it in one dimension. Input length 5, kernel 3, padding 1, stride 1:

```
padded:      0   x0  x1  x2  x3  x4   0
window 1    [0   x0  x1]                     -> out0
window 2        [x0  x1  x2]                 -> out1
window 3            [x1  x2  x3]             -> out2
window 4                [x2  x3  x4]         -> out3
window 5                    [x3  x4   0]     -> out4
                                             H_out = 5   (size preserved)
```

Now change only the stride to 2 — you keep every second window:

```
padded:      0   x0  x1  x2  x3  x4   0
window 1    [0   x0  x1]                     -> out0
window 2            [x1  x2  x3]             -> out1
window 3                    [x3  x4   0]     -> out2
                          H_out = floor((5 + 2 - 3)/2) + 1 = 3
```

And the channel picture, which is the part people get wrong. One filter is a 3-D block spanning **all** input channels, and it produces **one** output channel:

```
  input (C_in = 3)              one filter (3 x 3 x 3)         output
  ┌───────────┐                 ┌─────┐
  │ R plane   │                 │ 3x3 │ ─┐
  │ G plane   │   slide over,   │ 3x3 │  ├─ multiply and sum all      one value
  │ B plane   │   elementwise   │ 3x3 │ ─┘  3 x 3 x 3 = 27 products   per position
  └───────────┘                 └─────┘     (+ 1 bias)

  C_out such filters  ->  C_out output channels, stacked
```

The cases you should be able to state instantly:

| Config | Effect |
| --- | --- |
| `K=3, S=1, P=1` | size preserved — the workhorse |
| `K=1, S=1, P=0` | size preserved, channel mixing only |
| `K=3, S=2, P=1` | size halved (for even inputs) — strided downsampling |
| `K=5, S=1, P=2` | size preserved |
| `K=7, S=2, P=3` | size halved — the ResNet stem |
| `K, S=1, P=0` | size shrinks by `K−1` — "valid" convolution |

The general rule for "same" spatial size at stride 1 and odd `K`: **`P = (K − 1) / 2`**. PyTorch also accepts `padding="same"` directly (stride 1 only).

### 8.4 Worked shape trace

Trace a 32×32 CIFAR image through a small network. Do this by hand before checking.

```python
net = nn.Sequential(
    nn.Conv2d(3,  32, 3, stride=1, padding=1),   # (B,  3, 32, 32) -> (B, 32, 32, 32)
    nn.ReLU(),
    nn.MaxPool2d(2, 2),                          #                 -> (B, 32, 16, 16)
    nn.Conv2d(32, 64, 3, stride=1, padding=1),   #                 -> (B, 64, 16, 16)
    nn.ReLU(),
    nn.MaxPool2d(2, 2),                          #                 -> (B, 64,  8,  8)
    nn.Conv2d(64, 128, 3, stride=2, padding=1),  #                 -> (B,128,  4,  4)
    nn.ReLU(),
    nn.AdaptiveAvgPool2d(1),                     #                 -> (B,128,  1,  1)
    nn.Flatten(),                                #                 -> (B,128)
    nn.Linear(128, 10),                          #                 -> (B, 10)
)
print(net(torch.randn(8, 3, 32, 32)).shape)      # torch.Size([8, 10])
```

Check the third conv by formula: `floor((8 + 2·1 − 3)/2) + 1 = floor(7/2) + 1 = 3 + 1 = 4`. ✓

When you cannot be bothered to compute by hand, print as you go:

```python
x = torch.randn(1, 3, 32, 32)
for layer in net:
    x = layer(x)
    print(f"{layer.__class__.__name__:18s} {tuple(x.shape)}")
```

**Or let PyTorch infer it.** `nn.LazyLinear` figures out its own input dimension from the first batch it sees, which removes the most common shape bug in student code — the flattened feature size that does not match the classifier.

```python
net = nn.Sequential(
    nn.Conv2d(3, 16, 3, stride=2, padding=1),
    nn.Flatten(),
    nn.LazyLinear(10),          # input features determined on first forward pass
)
net[2].weight                    # UninitializedParameter — no shape yet
net(torch.randn(2, 3, 28, 28))   # (2, 10)
net[2].weight.shape              # torch.Size([10, 3136])  — now materialised
```

⚠️ Two caveats. You must run one forward pass **before** constructing the optimizer or calling `.to(device)`, because the parameters do not exist until then. And lazy modules hide the shape arithmetic rather than teaching it, so use them in production code and compute the shapes by hand while you are learning. `nn.LazyConv2d` and `nn.LazyBatchNorm2d` exist too.

### 8.5 Parameter counts

`nn.Conv2d(C_in, C_out, K)` with bias has `C_out · C_in · K · K + C_out` parameters — **independent of `H` and `W`**.

```python
conv = nn.Conv2d(64, 128, 3, padding=1)
conv.weight.shape      # (128, 64, 3, 3)
conv.bias.shape        # (128,)
sum(p.numel() for p in conv.parameters())   # 128*64*9 + 128 = 73,856
```

Compare to compute cost, which *does* depend on spatial size: roughly `C_out · C_in · K · K · H_out · W_out` multiply-accumulates. This asymmetry explains a lot of architecture design: early layers are cheap in parameters but expensive in FLOPs (large spatial size, few channels); late layers are the reverse.

### 8.6 The variants worth knowing

**1×1 convolution.** A `K=1` convolution does no spatial mixing at all — it is a per-pixel linear map across channels, mathematically a `C_in → C_out` matrix applied at every location. Its uses: cheaply change channel count (the "bottleneck" in ResNet-50, which reduces 256→64 channels, does the expensive 3×3 work, then restores 64→256), add nonlinearity without changing resolution, and fuse information across channels. Be ready to explain why it is not a no-op.

**Grouped convolution.** `groups=g` splits input and output channels into `g` independent groups; each group's filters see only their own input channels. Parameters drop by a factor of `g`. Used in ResNeXt and, historically, in AlexNet to split across two GPUs.

**Depthwise separable convolution.** The extreme case `groups=C_in`, one filter per input channel, followed by a 1×1 convolution to mix channels. This is the core of MobileNet.

```python
depthwise = nn.Conv2d(64, 64, 3, padding=1, groups=64)   # 64*1*9 + 64  =    640
pointwise = nn.Conv2d(64, 128, 1)                        # 128*64*1 + 128 =  8,320
# total 8,960  vs  a standard Conv2d(64, 128, 3): 73,856  — roughly 8x cheaper
```

The general saving over a standard `K×K` convolution is about `1/C_out + 1/K²`, so around 8–9× for `K=3`. Depthwise separable convolution is a very common interview topic because it tests whether you can reason about parameter counts rather than recite architectures.

**Dilated (atrous) convolution.** `dilation=d` spreads the kernel taps `d` apart, enlarging the receptive field without extra parameters or lost resolution. Central to semantic segmentation (DeepLab) and to WaveNet.

**Transposed convolution.** `nn.ConvTranspose2d` increases spatial size — used in autoencoders, GAN generators, and U-Net decoders. It is *not* the mathematical inverse of convolution; it is the operation whose forward pass has the same connectivity pattern as convolution's backward pass. ⚠️ It produces checkerboard artefacts when `stride` does not divide `kernel_size`; `nn.Upsample` followed by a regular convolution is often preferred.

### 8.7 Pooling

```python
nn.MaxPool2d(kernel_size=2, stride=2)    # halves H and W, no parameters
nn.AvgPool2d(2, 2)
nn.AdaptiveAvgPool2d((1, 1))             # any input size -> exactly 1x1
nn.AdaptiveAvgPool2d((7, 7))             # any input size -> exactly 7x7
```

Pooling downsamples, adds a small amount of local translation *invariance* (as opposed to the equivariance convolution gives), and enlarges the receptive field. Max-pooling keeps the strongest response, which suits detecting whether a feature is present; average pooling keeps the mean, which suits summarising.

`AdaptiveAvgPool2d` deserves special attention because it solves a real engineering problem: it computes whatever kernel and stride are needed to produce the requested output size, so the network accepts **any input resolution**. This is why modern classifiers end with `AdaptiveAvgPool2d(1)` followed by a `Linear`, and it is why you can feed a 300×300 image to a ResNet trained at 224×224 without an error. The older VGG design flattened a fixed 7×7×512 feature map into a huge `Linear`, which locks the input size and accounts for most of VGG's 138 million parameters.

Global average pooling also acts as a structural regulariser: it forces each of the final channels to be an evidence score for something, which is what makes class activation maps work.

Modern architectures increasingly replace pooling with strided convolution, which is learnable. Both approaches are defensible; pooling is parameter-free and cheap, strided convolution is more expressive.

### 8.8 Receptive field

The receptive field of a unit is the region of the *input image* that can influence it. Compute it layer by layer, tracking the jump (the effective stride so far):

```
j_0 = 1,  r_0 = 1
j_l = j_{l-1} · S_l
r_l = r_{l-1} + (K_l − 1) · j_{l-1}
```

Example — three stacked 3×3 stride-1 convolutions:

- After layer 1: `r = 1 + 2·1 = 3`
- After layer 2: `r = 3 + 2·1 = 5`
- After layer 3: `r = 5 + 2·1 = 7`

So three 3×3 convolutions see a 7×7 region, the same as one 7×7 convolution — but with `3·(9C²) = 27C²` parameters instead of `49C²`, and two extra nonlinearities in between. **This is the entire argument of the VGG paper**, and it comes up regularly in CNN interviews. Stacking small kernels is cheaper and more expressive than one large kernel.

If a pooling or stride-2 layer sits between them, the jump doubles and the receptive field grows much faster — which is why deep networks with a few downsampling stages can see the whole image by the final layer.

### 8.9 Convolution as matrix multiplication

GPUs have extremely fast matrix-multiply units, so implementations often lower convolution to a GEMM. The `im2col` transform extracts every `K×K×C_in` patch into a column of a matrix, giving a `(C_in·K·K) × (H_out·W_out)` matrix; the weights reshape to `C_out × (C_in·K·K)`; one matrix product yields the whole output. The cost is memory — patches overlap, so `im2col` duplicates data by a factor of about `K²`. cuDNN chooses among im2col-GEMM, FFT-based, Winograd, and direct algorithms depending on the shapes, which is why `torch.backends.cudnn.benchmark = True` (autotuning) can speed up training with fixed input sizes.

You will not implement this, but knowing that convolution *is* a matrix multiply under the hood explains why channel counts that are multiples of 8 or 32 run disproportionately fast on Tensor Cores.

### 8.10 Check yourself

1. Input `(8, 3, 224, 224)` through `Conv2d(3, 64, kernel_size=7, stride=2, padding=3)` — output shape and parameter count?
2. Why are two 3×3 convolutions usually preferred to one 5×5?
3. What does a 1×1 convolution accomplish, given that it does no spatial mixing?
4. Compute the receptive field of `[Conv3x3 s1, MaxPool2 s2, Conv3x3 s1]`.

## 9. Activations, normalisation and regularisation

This chapter covers the layers that are not linear algebra: the nonlinearities that make depth meaningful, the normalisers that make depth trainable, and the regularisers that make depth generalise.

### 9.1 Why you need a nonlinearity at all

Stack two linear layers with nothing between them:

```
z = W₂(W₁x + b₁) + b₂ = (W₂W₁)x + (W₂b₁ + b₂) = W'x + b'
```

The composition is **another linear layer**. A hundred stacked `nn.Linear` layers with no activation can represent exactly what one `nn.Linear` represents — you have burned 99 layers of parameters and gained nothing but a harder optimisation problem. The nonlinearity is what makes each layer add expressive power.

```python
net = nn.Sequential(nn.Linear(4, 8), nn.Linear(8, 3))     # no activation!
W_eq = net[1].weight @ net[0].weight                       # (3, 4)
b_eq = net[1].weight @ net[0].bias + net[1].bias
x = torch.randn(5, 4)
torch.allclose(net(x), x @ W_eq.T + b_eq, atol=1e-6)       # True
```

This is the answer to "why do we need activation functions?" — and the collapse identity above is the proof, not a hand-wave. ⚠️ Forgetting activations between `nn.Linear` layers is a real bug, and its signature is a deep model that performs exactly like logistic regression.

### 9.2 The vanishing gradient problem, measured

Backpropagation multiplies local derivatives along the chain. If each factor is smaller than 1, the product shrinks exponentially with depth.

Sigmoid is the classic offender. Its derivative is `σ(z)(1 − σ(z))`, which **peaks at 0.25** when `z = 0` and collapses away from there:

```python
for z in [0.0, 6.0]:
    t = torch.tensor(z, requires_grad=True)
    torch.sigmoid(t).backward()
    print(z, t.grad.item())
# 0.0  0.25
# 6.0  0.0024664658
```

So ten sigmoid layers multiply gradients by at most `0.25¹⁰ ≈ 1e-6`, and in practice far less, because most units are not sitting at `z = 0`. Here is the effect measured on a 10-layer MLP, printing the gradient norm of each weight matrix after one backward pass:

```python
def grad_norms(act, depth=10, width=128):
    layers = []
    for _ in range(depth):
        layers += [nn.Linear(width, width), act()]
    net = nn.Sequential(*layers, nn.Linear(width, 1))
    net(torch.randn(64, width)).sum().backward()
    return [l.weight.grad.norm().item() for l in net if isinstance(l, nn.Linear)]

torch.manual_seed(0); print(grad_norms(nn.Sigmoid))
torch.manual_seed(0); print(grad_norms(nn.ReLU))
```

Actual output (first three and last two layers):

| Gradient norm | layer 1 | layer 2 | layer 3 | layer 5 | layer 8 | layer 11 |
| --- | --- | --- | --- | --- | --- | --- |
| Sigmoid | 3.2e-07 | 1.0e-05 | 7.2e-05 | 3.7e-03 | 1.3e+00 | 3.7e+02 |
| ReLU | 1.4e-02 | 3.8e-02 | 5.8e-02 | 1.5e-01 | 2.4e+00 | 2.9e+01 |

Read the sigmoid row from right to left, the direction gradients actually travel. Each layer back, the norm falls by roughly a factor of 7, and after ten layers the first layer's gradient is **3.2e-07** against the last layer's **370** — a ratio of about **1.2 × 10⁹**. With a learning rate of 0.01 that first layer moves by something like 3e-09 per step: it is not training, it is standing still. The ReLU row falls too, but only by a factor of about **2.1 × 10³** across the whole network, and every layer gets a signal it can actually use.

The decay is geometric in depth, so it gets worse fast. Running the same experiment at greater depths, the first layer's gradient norm is:

| Depth | 10 | 15 | 20 | 25 | 30 |
| --- | --- | --- | --- | --- | --- |
| First-layer gradient norm | 3.2e-07 | 1.7e-11 | 7.1e-16 | 3.7e-20 | **0.0** |

At 30 layers it underflows float32 and becomes *exactly* zero — the early layers of a deep sigmoid network are not merely slow, they are mathematically frozen.

This is the historical reason deep networks did not work before about 2011, and the three fixes that made them work are exactly the subject of this chapter and the next: **ReLU-family activations** (no saturation on the positive side), **normalisation layers** (§9.5), and **residual connections** (§10.3).

### 9.3 The activation zoo

All of these are elementwise. Here are their actual values at five inputs, so you can see the shapes without a plot:

| Input `z` | −2.0 | −0.5 | 0.0 | 0.5 | 2.0 |
| --- | --- | --- | --- | --- | --- |
| `ReLU` | 0.0 | 0.0 | 0.0 | 0.5 | 2.0 |
| `LeakyReLU(0.01)` | −0.02 | −0.005 | 0.0 | 0.5 | 2.0 |
| `GELU` | −0.046 | −0.154 | 0.0 | 0.346 | 1.955 |
| `SiLU` (Swish) | −0.238 | −0.189 | 0.0 | 0.311 | 1.762 |
| `tanh` | −0.964 | −0.462 | 0.0 | 0.462 | 0.964 |
| `sigmoid` | 0.119 | 0.378 | 0.5 | 0.622 | 0.881 |

**ReLU** — `max(0, z)`. Derivative is 1 for `z > 0` and 0 otherwise, so it neither shrinks nor grows gradients on the active path. Cheap (one comparison), sparse (about half the units output exactly zero), and the default for convolutional networks. Not differentiable at 0; PyTorch defines the subgradient there as 0, which is harmless.

**LeakyReLU** — `max(αz, z)` with `α = 0.01`. Gives a small gradient on the negative side so units cannot die permanently. `PReLU` learns `α`.

**GELU** — `z · Φ(z)`, where `Φ` is the standard normal CDF. A smooth gate: instead of a hard on/off it scales the input by the probability that a standard normal is below it. The default in transformers (BERT, GPT) and in ConvNeXt. Note from the table that it is slightly **negative** for small negative inputs and non-monotonic there.

**SiLU / Swish** — `z · σ(z)`. Smooth, non-monotonic, very close to GELU in behaviour and cheaper. Used in EfficientNet and in many recent models.

**tanh** — `(eᶻ−e⁻ᶻ)/(eᶻ+e⁻ᶻ)`. Zero-centred with output in `(−1, 1)` and a maximum derivative of **1.0** at the origin, so it is strictly better-behaved than sigmoid for hidden layers. It still saturates. Survives in LSTM/GRU gates and where a bounded zero-centred output is genuinely wanted.

**sigmoid** — `1/(1+e⁻ᶻ)`, output in `(0, 1)`. ⚠️ Do not use it in hidden layers of a deep network. Two problems: derivative capped at 0.25 (§9.2), and output always positive, so all gradients into a given weight row share a sign and the optimiser zig-zags. Its correct role is the **output** layer for binary or multi-label classification — and even there you do not call it yourself, because `BCEWithLogitsLoss` fuses it for numerical stability (§6.2).

**softmax** — turns a vector of logits into a probability distribution. Also an output-layer function, also fused into `CrossEntropyLoss`. Not an activation for hidden layers.

### 9.4 Dying ReLU, and how to choose

A ReLU unit whose pre-activation is negative for *every* input in the dataset outputs zero always, and receives exactly zero gradient always. It is dead permanently — no gradient can ever revive it, because the gradient that would move its weights is itself zero. Watch it happen:

```python
lin = nn.Linear(4, 3)
with torch.no_grad():
    lin.bias.fill_(-10.0)              # push every pre-activation strongly negative
h = F.relu(lin(torch.randn(16, 4)))
h.sum().backward()
print((h > 0).float().mean().item())   # 0.0  — no unit ever fires
print(lin.weight.grad.norm().item())   # 0.0  — and no gradient to fix it
```

Causes: a learning rate high enough to drive weights into that regime in one step, a large negative bias initialisation, or unnormalised inputs. Detection: hook the activations and report the fraction of units that are zero for the whole validation set. If more than \~40% of a layer's units never fire, you have a problem. Fixes, in order: lower the learning rate, add normalisation, switch to LeakyReLU or GELU.

**The decision rule, which is what an interview wants:**

| Where | Use | Why |
| --- | --- | --- |
| CNN hidden layers | ReLU | Cheapest, well understood, the default in every standard architecture |
| Transformer / modern hidden layers | GELU or SiLU | Smooth gating; empirically a small but consistent gain |
| Suspected dying units | LeakyReLU or GELU | Nonzero gradient on the negative side |
| RNN gates | sigmoid and tanh | Bounded outputs are required by the gate semantics |
| Binary / multi-label output | **nothing** — emit logits | `BCEWithLogitsLoss` fuses the sigmoid |
| Multi-class output | **nothing** — emit logits | `CrossEntropyLoss` fuses the log-softmax |

Start with ReLU. Switch only if you have a measured reason. The activation function is one of the lowest-leverage knobs in a modern architecture — normalisation, data and the learning-rate schedule matter far more — and saying so is itself a good answer.

### 9.5 BatchNorm: what it computes

For a `(B, C, H, W)` activation, `nn.BatchNorm2d(C)` normalises **per channel**, using statistics gathered over the batch and both spatial dimensions — that is, over `B·H·W` values for each of the `C` channels.

```
μ_c = mean over (B, H, W)
σ²_c = variance over (B, H, W)
x̂ = (x − μ_c) / sqrt(σ²_c + ε)
y  = γ_c · x̂ + β_c
```

`γ` (`weight`) and `β` (`bias`) are learnable, one scalar per channel, so a `BatchNorm2d(64)` has 128 parameters. Crucially they let the network *undo* the normalisation if that is useful — the layer can represent the identity, so it never removes capacity.

```python
bn = nn.BatchNorm2d(64)
list(dict(bn.named_parameters()).keys())   # ['weight', 'bias']       — learnable
list(dict(bn.named_buffers()).keys())      # ['running_mean', 'running_var',
                                           #  'num_batches_tracked']  — not learnable
```

### 9.6 The train/eval asymmetry — the highest-value thing in this chapter

**In `train()` mode**, BatchNorm normalises using the *current batch's* statistics, and simultaneously updates its running estimates:

```
running_mean ← (1 − momentum) · running_mean + momentum · μ_batch
```

⚠️ PyTorch's `momentum` (default `0.1`) is the weight on the **new** observation — the opposite of the convention used in optimizer momentum and in most papers. `momentum=0.1` means the running estimate moves 10% of the way toward each new batch.

**In `eval()` mode**, BatchNorm uses the stored `running_mean` and `running_var` and updates nothing. This is essential: inference must be deterministic and must work for a single sample, which has no meaningful batch statistics.

The consequences, all of which appear in interviews and in real bug reports:

- **Forgetting `model.eval()`** makes validation accuracy depend on how validation samples happen to be grouped into batches, and corrupts the running statistics with validation data. Symptom: unstable, usually worse, validation numbers that change when you change the validation batch size.
- **Forgetting `model.train()` after evaluating** freezes BN in inference mode for the rest of training. Symptom: training loss stops improving after the first validation pass.
- **Small batches break BN.** With `batch_size=2`, the batch statistics are extremely noisy estimates, training becomes unstable, and the train/eval gap widens. Below roughly 8–16, switch to GroupNorm.
- **A batch of size 1 raises an error in training mode**, because the variance is undefined. This is exactly why `drop_last=True` is recommended for training loaders (§5.2).

One more detail that impresses: PyTorch normalises the batch with the **biased** variance (divide by `n`) but updates `running_var` with the **unbiased** estimate (divide by `n−1`). This is a deliberate choice so the stored statistic is an unbiased estimate of the population variance.

### 9.7 Why BatchNorm helps

Be honest here, because interviewers who know the literature will notice if you are not. The original 2015 paper attributed the benefit to reducing "internal covariate shift" — the changing distribution of each layer's inputs as earlier layers update. Later work (notably Santurkar et al., 2018) presented evidence against that explanation and argued that the real mechanism is a **smoother loss landscape**: normalisation bounds the gradients and makes the loss less sensitive to the scale of the weights, so larger learning rates become stable.

What is not in dispute, and what you should say:

- It permits substantially higher learning rates, so training converges in far fewer epochs.
- It reduces sensitivity to weight initialisation.
- It acts as a mild regulariser, because each sample's normalisation depends on the random other members of its batch — noise that behaves a little like dropout. This is also why BN's benefit shrinks when the batch is very large.

The honest summary: *"it empirically stabilises and accelerates training; the mechanism is debated, and the modern view emphasises loss-landscape smoothing over the original covariate-shift story."*

### 9.8 Where to put BatchNorm — and why `bias=False`

The standard block:

```python
nn.Sequential(
    nn.Conv2d(in_c, out_c, 3, padding=1, bias=False),   # note bias=False
    nn.BatchNorm2d(out_c),
    nn.ReLU(inplace=True),
)
```

**Why `bias=False`?** BatchNorm subtracts the mean of its input. Any constant added by the convolution's bias is subtracted right back out, so the bias has literally no effect on the output — it is `out_c` wasted parameters and a wasted gradient. BN's own `β` plays the role of the bias. ⚠️ Getting this right is a small but reliable signal that you have read real architecture code.

**Conv → BN → ReLU** is the conventional order. The alternative BN-after-activation exists and occasionally works better, but every standard architecture uses the conventional order, and pre-activation ResNet (`BN → ReLU → Conv`) is the notable deliberate variation.

### 9.9 LayerNorm, GroupNorm, InstanceNorm

All four normalisation layers do the same arithmetic. They differ only in **which axes they average over**.

For an activation of shape `(B, C, H, W)`:

| Layer | Averages over | Depends on batch? | Typical use |
| --- | --- | --- | --- |
| `BatchNorm2d(C)` | `(B, H, W)`, per channel | **yes** | CNNs with reasonable batch size |
| `LayerNorm(...)` | `(C, H, W)`, per sample | no | Transformers, RNNs, any sequence model |
| `GroupNorm(g, C)` | `(C/g, H, W)`, per sample per group | no | Small batches, detection, segmentation |
| `InstanceNorm2d(C)` | `(H, W)`, per sample per channel | no | Style transfer, generative models |

`GroupNorm(1, C)` is LayerNorm over `(C,H,W)`; `GroupNorm(C, C)` is InstanceNorm. Group normalisation with `g=32` is the usual choice when batch size per device is small.

The reason transformers use LayerNorm rather than BatchNorm is worth stating precisely: sequence lengths vary and padding pollutes batch statistics, batch sizes per device are often small, and inference on a single sequence must behave identically to training. LayerNorm normalises within each token's feature vector, so it is independent of the batch entirely.

```python
# LayerNorm for a transformer: normalise over the last (feature) dimension only
ln = nn.LayerNorm(512)              # input (B, T, 512)
# LayerNorm for a CNN feature map: specify the trailing dims explicitly
ln = nn.LayerNorm([64, 32, 32])     # input (B, 64, 32, 32)
```

### 9.10 Dropout

During training, `nn.Dropout(p)` zeroes each element independently with probability `p` **and divides the survivors by `1−p`**. That rescaling is called *inverted dropout*, and it is what makes evaluation a plain identity function: the expected activation is unchanged, so no adjustment is needed at test time.

```python
d = nn.Dropout(0.5)
x = torch.ones(1, 10)
d.train(); print(d(x))   # about half the entries are 0, the rest are 2.0
d.eval();  print(d(x))   # all ones — identity
```

Why it regularises: units cannot rely on any particular co-adaptation partner being present, so the network learns redundant, more robust features. An equivalent view is that it approximates an ensemble over exponentially many sub-networks sharing weights.

Practical guidance:

- Fully connected layers: `p = 0.2` to `0.5`.
- Convolutional layers: standard dropout is much less effective, because neighbouring pixels are strongly correlated so zeroing individual activations leaks little information. Use `nn.Dropout2d` (which drops entire channels) or, more commonly today, rely on BatchNorm plus data augmentation instead.
- ⚠️ **Dropout and BatchNorm interact badly** when dropout precedes BN. Dropout changes the variance of its output between train and eval; BN's running statistics are estimated under the training-time variance and are then wrong at inference. This "variance shift" is why modern CNNs (ResNet and successors) use BatchNorm and essentially no dropout in the convolutional trunk. If you use both, put dropout after all BN layers, typically just before the classifier.

### 9.11 The other regularisers

**Weight decay.** Penalises large weights, biasing the model toward simpler functions. Use `5e-4` with SGD for CNNs, `0.01`–`0.1` with AdamW. Exclude biases and normalisation parameters (§6.5).

**Data augmentation.** The most effective regulariser in vision, because it injects real knowledge about which transformations preserve the label. Covered in Chapter 11.

**Early stopping.** Free, and often the strongest single intervention. Stop when validation loss has not improved for `k` epochs and restore the best checkpoint.

**Label smoothing.** Replaces hard targets with `1−ε` and `ε/(C−1)`, preventing the network from pushing logits to infinity. Improves calibration and typically gives a small accuracy gain.

**Stochastic depth / DropPath.** Randomly skips entire residual blocks during training. Standard in very deep networks and in modern vision transformers.

### 9.12 Diagnosing which one you need

The decision procedure to recite in an interview:

1. Compute the gap between training and validation performance.
2. **Large gap** (train 99%, val 75%) → overfitting → add augmentation first, then weight decay, then dropout, then early stopping; get more data if you can.
3. **Small gap but both poor** (train 70%, val 68%) → underfitting → a bigger model, longer training, a higher learning rate, and *less* regularisation.
4. Never add regularisation to fix underfitting. Students do this constantly because "regularisation is good."

### 9.13 Check yourself

1. Prove that a stack of `nn.Linear` layers with no activation is equivalent to one `nn.Linear`.
2. Why does sigmoid cause vanishing gradients, and what is the exact numerical bound involved?
3. What is a dead ReLU unit, and why can it never recover?
4. Why does `Conv2d(..., bias=False)` appear before every BatchNorm in real code?
5. Exactly what changes in BatchNorm between `train()` and `eval()`?
6. Why do transformers use LayerNorm instead of BatchNorm?
7. Why is dropout rarely used in the convolutional part of a modern CNN?

## 10. Building CNN architectures from scratch

You should be able to write LeNet, a VGG block, and a ResNet residual block from memory. The first two take two minutes each; the third is the one interviews actually ask for.

### 10.1 LeNet-5 (1998) — the ancestor

```python
class LeNet5(nn.Module):
    """Input (B, 1, 32, 32) -> 10 classes. Modernised with ReLU and max-pooling."""
    def __init__(self, n_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            nn.Conv2d(1, 6, kernel_size=5), nn.ReLU(),   # 32 -> 28
            nn.MaxPool2d(2, 2),                          # 28 -> 14
            nn.Conv2d(6, 16, kernel_size=5), nn.ReLU(),  # 14 -> 10
            nn.MaxPool2d(2, 2),                          # 10 ->  5
        )
        self.classifier = nn.Sequential(
            nn.Flatten(),                                # 16*5*5 = 400
            nn.Linear(400, 120), nn.ReLU(),
            nn.Linear(120, 84),  nn.ReLU(),
            nn.Linear(84, n_classes),
        )

    def forward(self, x):
        return self.classifier(self.features(x))

LeNet5()(torch.randn(4, 1, 32, 32)).shape    # (4, 10);  ~61.7k parameters
```

The `features` / `classifier` split is the convention every torchvision model follows, and it is what makes transfer learning tidy (Chapter 11).

### 10.2 The VGG block (2014) — depth via small kernels

VGG's contribution was showing that stacking 3×3 convolutions beats larger kernels (§8.8). The reusable pattern:

```python
def vgg_block(in_c, out_c, n_convs):
    layers = []
    for i in range(n_convs):
        layers += [
            nn.Conv2d(in_c if i == 0 else out_c, out_c, 3, padding=1, bias=False),
            nn.BatchNorm2d(out_c),          # not in the 2014 paper; standard now
            nn.ReLU(inplace=True),
        ]
    layers.append(nn.MaxPool2d(2, 2))       # halve spatial size once per block
    return nn.Sequential(*layers)


class SmallVGG(nn.Module):
    def __init__(self, n_classes=10):
        super().__init__()
        self.features = nn.Sequential(
            vgg_block(3,   64, 2),    # 32 -> 16
            vgg_block(64, 128, 2),    # 16 ->  8
            vgg_block(128, 256, 3),   #  8 ->  4
            vgg_block(256, 512, 3),   #  4 ->  2
        )
        self.head = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),  # -> (B, 512, 1, 1)
            nn.Flatten(),
            nn.Dropout(0.5),
            nn.Linear(512, n_classes),
        )

    def forward(self, x):
        return self.head(self.features(x))
```

Note the doubling of channels each time the spatial size halves. This keeps the computational cost per stage roughly constant and is the design rule behind nearly every CNN: **halve the resolution, double the width.**

### 10.3 ResNet (2015) — the problem it solved

Before ResNet, making networks deeper eventually made them *worse on the training set*. That is the key observation: not overfitting — a deeper network could not even fit the training data as well as a shallower one. This is the **degradation problem**, and it is not explained by vanishing gradients alone (BatchNorm had largely handled that).

The argument in the paper is elegant. A 56-layer network contains a 20-layer network as a special case: set the extra 36 layers to the identity. So the deeper network's optimum is at least as good. If optimisation cannot find it, the problem is optimisation, not capacity. The fix: make the identity easy to represent.

Instead of asking a block to learn a mapping `H(x)`, ask it to learn the **residual** `F(x) = H(x) − x`, and compute:

```
y = F(x) + x
```

Now "do nothing" means driving `F` to zero, which is trivially achievable — weight decay pushes weights toward zero anyway. Gradients also get a clean path: `∂y/∂x = ∂F/∂x + 1`, so the `+1` guarantees gradient reaches earlier layers even when `∂F/∂x` is tiny. That single sentence is the answer to "why do residual connections help?"

### 10.4 The BasicBlock, implemented

The block, drawn:

```
              x --------------------------------+
              |                                  |
              v                                  v
      Conv 3x3, stride s               SHORTCUT PATH
              |                        Identity                 (shapes match)
              v                          -- or --
         BatchNorm                     1x1 Conv stride s
              |                        + BatchNorm              (shapes differ)
              v                                  |
            ReLU                                 |
              |                                  |
              v                                  |
      Conv 3x3, stride 1                         |
              |                                  |
              v                                  |
         BatchNorm                               |
              |                                  |
              +-------------->  (+)  <-----------+
                                 |
                                 v
                               ReLU
                                 |
                                 v
                                 y
```

The two paths must meet at `+` with identical shapes — that requirement is the entire reason the shortcut sometimes needs a 1×1 convolution.

```python
class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_c, out_c, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_c, out_c, 3, stride=stride, padding=1, bias=False)
        self.bn1   = nn.BatchNorm2d(out_c)
        self.conv2 = nn.Conv2d(out_c, out_c, 3, stride=1, padding=1, bias=False)
        self.bn2   = nn.BatchNorm2d(out_c)
        self.relu  = nn.ReLU(inplace=True)

        # The shortcut must match the main path in shape. If the stride or the
        # channel count changes, project with a 1x1 conv; otherwise pass through.
        if stride != 1 or in_c != out_c:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_c, out_c, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_c),
            )
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        identity = self.shortcut(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        out = out + identity          # addition BEFORE the final ReLU
        return self.relu(out)
```

Four points that come up every single time this is asked:

1. **The shortcut is added before the last ReLU, not after.** `out = out + identity; return relu(out)` is the ordering from the original paper.
2. **When shapes mismatch, project.** A stride-2 block halves `H` and `W` and usually doubles `C`, so the identity path needs a 1×1 stride-2 convolution (option B in the paper). The alternative — zero-padding the channels — is option A and appears in some CIFAR implementations.
3. **The second BN has no ReLU after it inside the block.** The activation comes after the addition.
4. **`out += identity` is also correct here, and torchvision uses it.** The in-place add is safe because `out` is the freshly created output of `bn2`, nothing else in the graph consumes it, and BatchNorm's backward does not need its own output. The general rule is narrower than "never use in-place in `forward`": an in-place operation is unsafe when it overwrites a tensor that is a view of something else, or that another node still needs for its backward pass. `out = out + identity` is always safe and costs one allocation, so prefer it while you are learning and use the in-place form once you can state why it is legal.

### 10.5 The Bottleneck block (ResNet-50 and deeper)

```python
class Bottleneck(nn.Module):
    expansion = 4                      # output channels = out_c * 4

    def __init__(self, in_c, out_c, stride=1):
        super().__init__()
        w = out_c
        self.conv1 = nn.Conv2d(in_c, w, 1, bias=False)                      # reduce
        self.bn1   = nn.BatchNorm2d(w)
        self.conv2 = nn.Conv2d(w, w, 3, stride=stride, padding=1, bias=False)  # process
        self.bn2   = nn.BatchNorm2d(w)
        self.conv3 = nn.Conv2d(w, w * self.expansion, 1, bias=False)        # restore
        self.bn3   = nn.BatchNorm2d(w * self.expansion)
        self.relu  = nn.ReLU(inplace=True)

        if stride != 1 or in_c != w * self.expansion:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_c, w * self.expansion, 1, stride=stride, bias=False),
                nn.BatchNorm2d(w * self.expansion),
            )
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        identity = self.shortcut(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        return self.relu(out + identity)
```

The 1×1–3×3–1×1 sandwich is a cost-saving device. Running a 3×3 convolution directly on 256 channels costs `256·256·9 ≈ 590k` parameters; squeezing to 64 channels first costs `256·64 + 64·64·9 + 64·256 ≈ 70k`. The expensive spatial operation happens in a low-dimensional space — the same idea as a bottleneck autoencoder, applied per pixel.

### 10.6 A full ResNet-18

```python
class ResNet(nn.Module):
    def __init__(self, block, layers, n_classes=1000, small_input=False):
        super().__init__()
        self.in_c = 64

        if small_input:                 # CIFAR-style 32x32 stem: no aggressive downsampling
            self.stem = nn.Sequential(
                nn.Conv2d(3, 64, 3, stride=1, padding=1, bias=False),
                nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            )
        else:                           # ImageNet stem: 224 -> 56 in two steps
            self.stem = nn.Sequential(
                nn.Conv2d(3, 64, 7, stride=2, padding=3, bias=False),
                nn.BatchNorm2d(64), nn.ReLU(inplace=True),
                nn.MaxPool2d(3, stride=2, padding=1),
            )

        self.layer1 = self._make_layer(block,  64, layers[0], stride=1)
        self.layer2 = self._make_layer(block, 128, layers[1], stride=2)
        self.layer3 = self._make_layer(block, 256, layers[2], stride=2)
        self.layer4 = self._make_layer(block, 512, layers[3], stride=2)

        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(512 * block.expansion, n_classes)

        for m in self.modules():        # He init, as in the paper
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def _make_layer(self, block, out_c, n_blocks, stride):
        strides = [stride] + [1] * (n_blocks - 1)   # only the FIRST block downsamples
        blocks = []
        for s in strides:
            blocks.append(block(self.in_c, out_c, s))
            self.in_c = out_c * block.expansion
        return nn.Sequential(*blocks)

    def forward(self, x):
        x = self.stem(x)
        x = self.layer1(x); x = self.layer2(x)
        x = self.layer3(x); x = self.layer4(x)
        x = self.avgpool(x)
        return self.fc(torch.flatten(x, 1))


def resnet18(n_classes=1000, small_input=False):
    return ResNet(BasicBlock, [2, 2, 2, 2], n_classes, small_input)

def resnet50(n_classes=1000, small_input=False):
    return ResNet(Bottleneck, [3, 4, 6, 3], n_classes, small_input)


m = resnet18()
print(m(torch.randn(2, 3, 224, 224)).shape)                  # (2, 1000)
print(f"{sum(p.numel() for p in m.parameters()):,}")         # 11,689,512
```

**Verify the layer count.** ResNet-18 = 1 stem convolution + 4 stages × 2 blocks × 2 convolutions + 1 fully connected = `1 + 16 + 1 = 18` weighted layers. The 1×1 shortcut convolutions are not counted. ResNet-50 = `1 + (3+4+6+3)·3 + 1 = 50`. Being able to do this arithmetic on the spot is a nice signal.

**Shape trace for 224×224 input:**

| Stage | Output shape |
| --- | --- |
| input | `(B, 3, 224, 224)` |
| stem conv 7×7 s2 | `(B, 64, 112, 112)` |
| maxpool 3×3 s2 | `(B, 64, 56, 56)` |
| layer1 (s1) | `(B, 64, 56, 56)` |
| layer2 (s2) | `(B, 128, 28, 28)` |
| layer3 (s2) | `(B, 256, 14, 14)` |
| layer4 (s2) | `(B, 512, 7, 7)` |
| adaptive avgpool | `(B, 512, 1, 1)` |
| fc | `(B, 1000)` |

### 10.7 What came after, and why

| Architecture | Year | Key idea | Why it mattered |
| --- | --- | --- | --- |
| AlexNet | 2012 | ReLU, dropout, GPU training | Started the era |
| VGG | 2014 | Stacked 3×3, uniform design | Depth via small kernels |
| Inception/GoogLeNet | 2014 | Parallel multi-scale branches, 1×1 bottlenecks | Accuracy at low FLOPs |
| ResNet | 2015 | Residual connections | Made 100+ layers trainable; still the default backbone |
| DenseNet | 2016 | Concatenate all earlier features | Feature reuse, fewer parameters |
| MobileNet | 2017 | Depthwise separable convolution | Mobile/edge deployment |
| EfficientNet | 2019 | Compound scaling of depth/width/resolution | Best accuracy per FLOP of its era |
| Vision Transformer | 2020 | Patches + self-attention, no convolution | Scales better with very large data |
| ConvNeXt | 2022 | A ResNet modernised with transformer-era design choices | Convolutions remain competitive |

The honest 2026 summary for an interview: ResNet-style convolutional backbones remain the pragmatic default for most vision tasks at ordinary data scales and are far cheaper to train; vision transformers win when pretraining data is abundant; hybrid and modernised-convolution designs occupy the middle.

### 10.8 Check yourself

1. What is the degradation problem, and why is it *not* just overfitting?
2. In `BasicBlock`, when is the shortcut a 1×1 convolution rather than the identity, and why?
3. Why does the bottleneck block reduce channels before the 3×3 convolution?
4. Count the weighted layers in ResNet-34 (`BasicBlock, [3, 4, 6, 3]`).

## 11. Training vision models well

### 11.1 Computing normalisation statistics

Use the published constants when they exist, and compute them yourself otherwise — from the **training split only**.

```python
def channel_stats(loader):
    """Mean and std per channel over a dataset of (B, C, H, W) float tensors in [0,1]."""
    n_pixels = 0
    total    = torch.zeros(3)
    total_sq = torch.zeros(3)
    for x, _ in loader:
        b, c, h, w = x.shape
        x = x.permute(1, 0, 2, 3).reshape(c, -1)      # (C, B*H*W)
        total    += x.sum(dim=1)
        total_sq += (x ** 2).sum(dim=1)
        n_pixels += b * h * w
    mean = total / n_pixels
    std  = (total_sq / n_pixels - mean ** 2).sqrt()   # E[x²] − (E[x])²
    return mean, std
```

The constants you will use most often:

| Dataset | mean | std |
| --- | --- | --- |
| ImageNet (and any ImageNet-pretrained model) | `(0.485, 0.456, 0.406)` | `(0.229, 0.224, 0.225)` |
| CIFAR-10 | `(0.4914, 0.4822, 0.4465)` | `(0.2470, 0.2435, 0.2616)` |
| MNIST | `(0.1307,)` | `(0.3081,)` |

Why normalise at all? Inputs centred near zero with unit scale keep activations in the well-conditioned part of each nonlinearity and make the loss surface more isotropic, so a single learning rate works for all input dimensions. ⚠️ If you fine-tune a pretrained model with the wrong normalisation constants, accuracy silently drops by several points and nothing errors.

### 11.2 Augmentation recipes

Augmentation encodes what you know: a cat rotated 10° is still a cat; a cat flipped horizontally is still a cat; the digit 6 flipped vertically is not still a 6. **Only apply transformations that preserve the label.**

```python
from torchvision.transforms import v2

# Baseline for 32x32 natural images (CIFAR)
train_tf = v2.Compose([
    v2.RandomCrop(32, padding=4, padding_mode="reflect"),
    v2.RandomHorizontalFlip(),
    v2.ToImage(),
    v2.ToDtype(torch.float32, scale=True),
    v2.Normalize(CIFAR_MEAN, CIFAR_STD),
    v2.RandomErasing(p=0.25),                 # after Normalize: erases in tensor space
])

# Stronger recipe for 224x224 natural images
train_tf = v2.Compose([
    v2.RandomResizedCrop(224, scale=(0.35, 1.0)),
    v2.RandomHorizontalFlip(),
    v2.TrivialAugmentWide(),                  # or RandAugment(num_ops=2, magnitude=9)
    v2.ToImage(),
    v2.ToDtype(torch.float32, scale=True),
    v2.Normalize(IMAGENET_MEAN, IMAGENET_STD),
])

# Evaluation: deterministic, centre crop
test_tf = v2.Compose([
    v2.Resize(256),
    v2.CenterCrop(224),
    v2.ToImage(),
    v2.ToDtype(torch.float32, scale=True),
    v2.Normalize(IMAGENET_MEAN, IMAGENET_STD),
])
```

**Batch-level augmentation: mixup and CutMix.** These operate on whole batches and require soft targets, so they live in the training loop rather than the transform pipeline.

```python
def mixup(x, y, n_classes, alpha=0.2):
    lam = float(torch.distributions.Beta(alpha, alpha).sample())
    perm = torch.randperm(x.size(0), device=x.device)
    x_mixed = lam * x + (1 - lam) * x[perm]
    y1 = F.one_hot(y, n_classes).float()
    y_mixed = lam * y1 + (1 - lam) * y1[perm]
    return x_mixed, y_mixed          # use a loss that accepts soft targets
```

Mixup trains on convex combinations of pairs of images with correspondingly mixed labels. It regularises strongly, improves calibration, and typically needs longer training to pay off. torchvision provides `v2.MixUp` and `v2.CutMix` ready-made.

**Sanity check your augmentations by looking at them.** Denormalise a batch and display it. Half of all augmentation bugs — the flip that makes text unreadable, the crop that cuts out the object, the normalisation applied twice — are obvious in one glance and invisible in the metrics.

```python
import matplotlib.pyplot as plt

def show_batch(xb, mean, std, n=8):
    """Undo Normalize and display, so you can see what the model actually receives."""
    mean = torch.tensor(mean).view(1, -1, 1, 1)
    std  = torch.tensor(std).view(1, -1, 1, 1)
    imgs = (xb[:n].cpu() * std + mean).clamp(0, 1)      # (B, C, H, W) back in [0,1]
    imgs = imgs.permute(0, 2, 3, 1)                     # -> (B, H, W, C) for imshow
    fig, axes = plt.subplots(1, n, figsize=(2 * n, 2))
    for ax, im in zip(axes, imgs):
        ax.imshow(im.squeeze())     # .squeeze() handles single-channel images
        ax.axis("off")
    plt.show()

xb, yb = next(iter(train_loader))
show_batch(xb, CIFAR_MEAN, CIFAR_STD)
```

The `clamp(0, 1)` matters: augmentations such as colour jitter can push values outside the displayable range, and without it `imshow` either errors or renders nonsense. Run this once per project. It costs thirty seconds and catches the flipped text, the crop that removed the object, and the normalisation applied twice — none of which show up in the loss curve.

### 11.3 Transfer learning: the highest-leverage technique in applied vision

If you have fewer than roughly 10,000 labelled images, do not train from scratch. Start from ImageNet-pretrained weights. Early convolutional layers learn edges, colours and textures that are essentially universal; only the later layers are task-specific.

```python
import torchvision
from torchvision.models import resnet18, ResNet18_Weights

weights = ResNet18_Weights.DEFAULT           # current best available checkpoint
model = resnet18(weights=weights)

# The checkpoint knows its own preprocessing — use it, don't guess
preprocess = weights.transforms()
print(weights.meta["categories"][:5])        # class names
```

⚠️ `pretrained=True` is the **old** API. It was deprecated in torchvision 0.13 and removed later. The modern form is `weights=ResNet18_Weights.DEFAULT` (or `.IMAGENET1K_V1` to pin an exact checkpoint, which you should do for reproducibility — `DEFAULT` can change between releases). Using `pretrained=True` in an interview dates you immediately.

**Replace the head.** For `K` classes:

```python
in_features = model.fc.in_features           # 512 for resnet18
model.fc = nn.Linear(in_features, K)         # new, randomly initialised
```

For other families the attribute differs: `model.classifier[-1]` for VGG, DenseNet and MobileNet; `model.heads.head` for torchvision's ViT. `print(model)` tells you.

**Strategy A — feature extraction (freeze the backbone).** Fastest, best for very small datasets and when the target domain resembles ImageNet.

```python
for p in model.parameters():
    p.requires_grad = False
model.fc = nn.Linear(512, K)                 # new layer defaults to requires_grad=True

opt = torch.optim.AdamW(
    [p for p in model.parameters() if p.requires_grad], lr=1e-3)
```

⚠️ Two traps. First, pass only trainable parameters to the optimizer, or at least be aware that Adam will still apply weight decay to frozen parameters in some configurations. Second, `requires_grad=False` does **not** freeze BatchNorm's running statistics — those are buffers, updated in `train()` mode regardless of gradients. On a small or domain-shifted dataset this quietly degrades the pretrained features. Fix it by putting the BN layers in eval mode:

```python
def freeze_bn(m):
    if isinstance(m, nn.modules.batchnorm._BatchNorm):
        m.eval()

model.train()
model.apply(freeze_bn)      # call AFTER model.train(), every epoch
```

This is a genuinely advanced point and lands very well in interviews.

**Strategy B — full fine-tuning with discriminative learning rates.** Best when you have a few thousand images or more, or a domain that differs from ImageNet.

```python
backbone = [p for n, p in model.named_parameters() if not n.startswith("fc")]
head     = [p for n, p in model.named_parameters() if n.startswith("fc")]

opt = torch.optim.AdamW([
    {"params": backbone, "lr": 1e-4},     # small: don't destroy what was learned
    {"params": head,     "lr": 1e-3},     # large: it starts from noise
], weight_decay=1e-4)
```

**Strategy C — two-phase.** Freeze the backbone and train the head for a few epochs (so the random head stops producing huge gradients), then unfreeze everything at a low learning rate. This is the standard recipe and usually the best answer to "how would you fine-tune?"

**How to choose**, stated as a rule:

| Dataset size | Similar to ImageNet | Different domain (medical, satellite, microscopy) |
| --- | --- | --- |
| < 1k images | Freeze backbone, train head | Freeze early layers, fine-tune later ones |
| 1k–10k | Fine-tune the last stage or two | Fine-tune everything, low LR |
| > 10k | Fine-tune everything | Fine-tune everything; consider training from scratch |

**Grayscale or non-3-channel inputs.** Either repeat the channel three times, or surgically replace the first convolution and initialise it by summing the pretrained RGB weights:

```python
old = model.conv1
model.conv1 = nn.Conv2d(1, 64, 7, stride=2, padding=3, bias=False)
with torch.no_grad():
    model.conv1.weight.copy_(old.weight.sum(dim=1, keepdim=True))
```

### 11.4 Mixed precision

Running most operations in 16-bit roughly doubles throughput on modern NVIDIA GPUs and halves activation memory. PyTorch's `torch.amp` handles the details.

```python
from torch.amp import autocast, GradScaler

scaler = GradScaler("cuda")

for xb, yb in train_loader:
    xb, yb = xb.to(device), yb.to(device)
    optimizer.zero_grad(set_to_none=True)

    with autocast("cuda", dtype=torch.float16):
        logits = model(xb)
        loss = criterion(logits, yb)

    scaler.scale(loss).backward()        # scale up, so small gradients survive fp16
    scaler.unscale_(optimizer)          # needed only if you clip gradients
    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
    scaler.step(optimizer)              # unscales, then steps (skips the step on inf/nan)
    scaler.update()                     # adapt the scale factor for next iteration
```

What is happening, in one paragraph: `autocast` runs convolutions and matrix multiplications in `float16` while keeping reductions, losses and normalisation in `float32`, because those are the numerically delicate ones. Master weights stay in `float32`. The gradient scaler exists because `float16`'s smallest normal magnitude is about `6e-5`, so many legitimate gradients would underflow to zero; multiplying the loss by a large constant shifts them into range, and the scaler divides it back out before the optimizer step. If it detects `inf`/`nan`, it skips that step and reduces the scale.

Notes:

- ⚠️ `torch.cuda.amp.autocast(...)` and `torch.cuda.amp.GradScaler()` are the deprecated spellings. Use `torch.amp.autocast("cuda", ...)` and `torch.amp.GradScaler("cuda")`.
- With `dtype=torch.bfloat16` on Ampere-or-newer GPUs you can usually skip the scaler entirely, because bfloat16 has the same exponent range as float32.
- Do not call `.half()` on your model and hope. That is manual, error-prone, and loses the float32 master weights.

### 11.5 Gradient accumulation

Simulate a large batch when it will not fit in memory:

```python
ACCUM = 4                       # effective batch = batch_size * 4
optimizer.zero_grad(set_to_none=True)

for i, (xb, yb) in enumerate(train_loader):
    loss = criterion(model(xb.to(device)), yb.to(device))
    (loss / ACCUM).backward()   # divide so the AVERAGE gradient matches a big batch
    if (i + 1) % ACCUM == 0:
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        optimizer.zero_grad(set_to_none=True)
```

The `/ ACCUM` is essential and frequently forgotten: without it you accumulate a *sum* of gradients, which is `ACCUM` times too large. Note that gradient accumulation does **not** reproduce large-batch training exactly, because BatchNorm statistics are still computed over the small physical batch.

### 11.6 Gradient clipping

```python
torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
```

This computes the global L2 norm of all gradients and, if it exceeds `max_norm`, scales every gradient down by the same factor — preserving direction, limiting magnitude. Essential for RNNs, standard for transformers, generally harmless for CNNs. `clip_grad_value_` clips each element independently and distorts the direction; prefer the norm version. Place it after `backward()` and before `step()`.

### 11.7 Two cheap wins

**Exponential moving average of weights.** Keep a slowly-updated copy of the parameters and evaluate with it. It costs one extra copy of the model and typically buys a few tenths of a percent.

```python
ema = torch.optim.swa_utils.AveragedModel(
    model, multi_avg_fn=torch.optim.swa_utils.get_ema_multi_avg_fn(0.999))
# after each optimizer.step():
ema.update_parameters(model)
# at the end, before evaluating:
torch.optim.swa_utils.update_bn(train_loader, ema, device=device)
```

**Test-time augmentation.** Average predictions over the image and its horizontal flip. Free accuracy at double inference cost; often worth it for a competition or a report, rarely for production latency.

### 11.8 A complete CIFAR-10 recipe

Put together, this reaches roughly 94–95% test accuracy with a CIFAR-style ResNet-18 in about 30 epochs on one modern GPU:

- Model: `resnet18(n_classes=10, small_input=True)` from §10.6 (3×3 stem, no maxpool).
- Augmentation: `RandomCrop(32, padding=4)`, `RandomHorizontalFlip()`, normalise, `RandomErasing(0.25)`.
- Optimizer: SGD, `lr=0.1`, `momentum=0.9`, `nesterov=True`, `weight_decay=5e-4`, no decay on BN/bias.
- Schedule: `OneCycleLR` or cosine with a 5-epoch linear warmup, stepped **per batch** for OneCycle.
- Batch size 128, `drop_last=True`, mixed precision on.
- Loss: `CrossEntropyLoss(label_smoothing=0.1)`.
- Select the checkpoint by validation accuracy, then report once on test.

⚠️ Using the ImageNet stem (7×7 stride 2 plus maxpool) on 32×32 images reduces the feature map to 8×8 before the first stage even begins, and costs several points of accuracy. This mistake is extremely common in student code.

### 11.9 Check yourself

1. Why must fine-tuning use the pretrained model's normalisation constants?
2. `requires_grad=False` on every backbone parameter — what is still changing during training?
3. Why does `GradScaler` exist, and when can you drop it?
4. Why divide the loss by the accumulation count?

## 12. Debugging, reproducibility and performance

### 12.1 Decoding the error messages you will actually see

| Message (abbreviated) | What it really means | Fix |
| --- | --- | --- |
| `Expected all tensors to be on the same device` | One operand is on CPU, another on GPU | Usually a tensor created in `__init__` without `register_buffer`, or data not moved in the loop |
| `mat1 and mat2 shapes cannot be multiplied (32x1024 and 512x10)` | The flattened feature size does not match the `Linear` input | Print the shape before `Flatten`; use `AdaptiveAvgPool2d` or `nn.LazyLinear` |
| `Expected scalar type Long but found Float` | Labels are floats; `CrossEntropyLoss` needs `int64` | `y = y.long()` |
| `0D or 1D target tensor expected, multi-target not supported` | You passed one-hot labels to `CrossEntropyLoss` | Pass class indices, `y.argmax(1)` |
| `Trying to backward through the graph a second time` | Two `backward()` calls on one graph, or a tensor reused across iterations | Recompute the forward pass; or `retain_graph=True` if truly intended |
| `one of the variables needed for gradient computation has been modified by an inplace operation` | An in-place op clobbered a tensor backward needed | Remove `inplace=True` / `+=` inside `forward` |
| `element 0 of tensors does not require grad` | The loss has no graph — something was detached, or you are inside `no_grad` | Check for stray `.detach()`, `.item()`, `.numpy()` |
| `CUDA out of memory. Tried to allocate …` | Exactly what it says | See §12.4 |
| `CUDA error: device-side assert triggered` | Almost always an out-of-range label index | Run on CPU to get a real traceback; check `y.min(), y.max()` against `num_classes` |
| `Expected more than 1 value per channel when training` | BatchNorm received a batch of size 1 | `drop_last=True`, or a larger batch |

The device-side-assert row deserves emphasis. ⚠️ CUDA errors are asynchronous, so the reported line is often unrelated to the real fault. Two remedies: set `CUDA_LAUNCH_BLOCKING=1` in the environment to get accurate line numbers, or reproduce on CPU where the error message is precise.

### 12.2 Hunting NaNs

```python
# Find the first iteration where things go wrong
torch.autograd.set_detect_anomaly(True)    # SLOW — debugging only, never in training runs

# Or check manually, which is cheap
if not torch.isfinite(loss):
    print("non-finite loss")
    for n, p in model.named_parameters():
        if p.grad is not None and not torch.isfinite(p.grad).all():
            print("bad grad in", n)
    raise SystemExit
```

The usual causes, in order of frequency: learning rate too high; `log` or `sqrt` of something that reached zero; division by a near-zero denominator without an `eps`; unnormalised inputs; fp16 overflow; and corrupt data (a NaN already present in your inputs — check with `torch.isfinite(xb).all()`).

### 12.3 Reproducibility

Full bitwise reproducibility costs speed, so decide how much you need.

```python
import random, numpy as np, torch

def set_seed(seed=0):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)              # covers CPU and all CUDA devices

def make_deterministic():
    torch.use_deterministic_algorithms(True)   # raises if an op has no deterministic kernel
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False     # autotuning picks different algorithms per run
```

Even with all of this, results may differ across PyTorch versions, GPU models, and CUDA versions, and floating-point addition is not associative so different reduction orders give slightly different sums. `use_deterministic_algorithms(True)` may also require setting the environment variable `CUBLAS_WORKSPACE_CONFIG=:4096:8`.

The pragmatic standard in industry: seed everything, log the seed and all versions, and report **mean ± standard deviation over 3–5 seeds** rather than a single number. A 0.3% difference between two models is usually seed noise, and claiming it as an improvement is the kind of thing a good interviewer will push back on.

Do not forget the DataLoader (§5.7) — worker processes need their own seeding.

### 12.4 GPU memory

What occupies memory during training:

1. **Parameters** — `N` floats.
2. **Gradients** — another `N`.
3. **Optimizer state** — 0 for plain SGD, `N` for SGD with momentum, `2N` for Adam/AdamW.
4. **Activations** — every intermediate tensor kept for the backward pass. This scales with **batch size** and usually dominates for CNNs.

So a 100M-parameter model with AdamW needs roughly `4·(100M) · 4 bytes = 1.6 GB` before a single activation. Being able to do this arithmetic is a real interview question.

```python
print(torch.cuda.memory_allocated() / 1e9, "GB in tensors")
print(torch.cuda.max_memory_allocated() / 1e9, "GB peak")
print(torch.cuda.memory_summary())
torch.cuda.reset_peak_memory_stats()
```

When you hit OOM, try in this order:

1. Reduce batch size (and use gradient accumulation to keep the effective batch).
2. Turn on mixed precision — often halves activation memory.
3. Make sure evaluation runs under `torch.no_grad()`. Forgetting this is a top-three cause of OOM.
4. Check for graph leaks: any `total_loss += loss` without `.item()` or `.detach()` (§1.6).
5. Use gradient checkpointing — recompute activations during backward instead of storing them, trading roughly 30% extra compute for a large memory saving:

   ```python
   from torch.utils.checkpoint import checkpoint
   out = checkpoint(self.heavy_block, x, use_reentrant=False)
   ```
6. Smaller input resolution, or a smaller model.

⚠️ `torch.cuda.empty_cache()` releases PyTorch's cached-but-unused blocks back to the driver. It does **not** free memory held by live tensors and it rarely fixes a real OOM — it mostly makes `nvidia-smi` look better. Do not sprinkle it through your training loop; it forces synchronisation and slows things down.

### 12.5 Timing things correctly

```python
# WRONG on GPU: CUDA calls are asynchronous, so this times the queueing, not the work
t0 = time.time(); y = model(x); print(time.time() - t0)

# RIGHT
torch.cuda.synchronize()
t0 = time.time()
for _ in range(50):
    y = model(x)
torch.cuda.synchronize()
print((time.time() - t0) / 50)
```

Always run a few warm-up iterations first: the first call includes cuDNN algorithm selection, kernel autotuning, and memory-pool growth.

For a real breakdown, use the profiler:

```python
from torch.profiler import profile, ProfilerActivity

with profile(activities=[ProfilerActivity.CPU, ProfilerActivity.CUDA],
             record_shapes=True) as prof:
    for _ in range(10):
        loss = criterion(model(xb), yb)
        loss.backward()
        optimizer.step()
        optimizer.zero_grad()

print(prof.key_averages().table(sort_by="cuda_time_total", row_limit=15))
prof.export_chrome_trace("trace.json")     # open in chrome://tracing or Perfetto
```

### 12.6 Making training faster

In rough order of effort-to-benefit:

1. **Mixed precision** (§11.4). Often 1.5–3× on modern GPUs, one block of code.
2. **`torch.backends.cudnn.benchmark = True`.** Lets cuDNN autotune convolution algorithms. Big win when input shapes are constant; actively harmful when shapes vary every batch, since it re-benchmarks each new shape.
3. **`torch.compile(model)`.** The PyTorch 2.x compiler traces your model and generates fused kernels, typically giving 1.2–2× with a one-line change:

   ```python
   model = torch.compile(model)   # first iteration is slow: that is compilation
   ```

   Caveats worth knowing: compilation takes seconds to minutes; changing input shapes triggers recompilation (use `dynamic=True` or pad to fixed shapes); data-dependent Python control flow causes "graph breaks" that reduce the benefit; and debugging inside a compiled model is harder, so develop eagerly and compile once it works.
4. **Fix the input pipeline** (§5.8) if the GPU is idle.
5. **`channels_last` memory format** (§2.10), which pairs well with AMP on convolutional models.
6. **Larger batch size**, up to the point where it stops improving throughput — then scale the learning rate roughly linearly and add warmup.
7. **`set_to_none=True` in `zero_grad`** (the default now) and `non_blocking=True` transfers with `pin_memory`.

### 12.7 A pre-flight checklist

Before launching a long run, verify:

- [ ] One batch overfits to \~zero loss.
- [ ] Initial loss ≈ `ln(C)`.
- [ ] `model.train()` / `model.eval()` are in the right places.
- [ ] Validation is inside `torch.no_grad()`.
- [ ] The learning-rate schedule is plotted and looks as intended.
- [ ] Augmentations have been visually inspected.
- [ ] Normalisation constants match the pretrained weights, if any.
- [ ] Checkpointing saves model, optimizer and scheduler state.
- [ ] The seed and all library versions are logged.
- [ ] The test set has not been looked at.

### 12.8 Check yourself

1. Why can a CUDA error point at the wrong line, and what do you do about it?
2. Estimate the optimizer-state memory for a 50M-parameter model trained with AdamW.
3. When does `cudnn.benchmark = True` hurt rather than help?
4. Why is `time.time()` around a GPU forward pass misleading?

## 13. Saving, loading and shipping

### 13.1 Save the state\_dict, not the model

```python
# Recommended
torch.save(model.state_dict(), "weights.pt")

model = MyModel(**config)                 # reconstruct the architecture in code
model.load_state_dict(torch.load("weights.pt", map_location="cpu", weights_only=True))
model.eval()

# Discouraged
torch.save(model, "whole_model.pt")       # pickles the class by reference
```

Pickling the whole model stores a *reference* to the class, not its source. Move the file to a machine where the module path differs, rename your file, or upgrade PyTorch, and loading breaks. The `state_dict` is just a dictionary of tensors and is portable.

⚠️ **Security.** `torch.load` historically used `pickle`, which can execute arbitrary code during deserialisation. Loading an untrusted checkpoint was equivalent to running an untrusted script. `weights_only=True` restricts loading to plain tensors and simple containers. This became the default in PyTorch 2.6; pass it explicitly anyway so your code is unambiguous across versions. For distributing weights, the `safetensors` format avoids pickle entirely.

`map_location="cpu"` matters too: a checkpoint saved from GPU 3 tries to restore onto GPU 3, which fails on a machine with fewer GPUs. Load to CPU and then `.to(device)`.

### 13.2 A resumable checkpoint

```python
torch.save({
    "epoch": epoch,
    "model": model.state_dict(),
    "optimizer": optimizer.state_dict(),
    "scheduler": scheduler.state_dict(),
    "scaler": scaler.state_dict(),          # if using AMP
    "best_val": best_val,
    "config": config,                       # hyperparameters, for sanity
    "torch_version": torch.__version__,
}, "ckpt.pt")

ckpt = torch.load("ckpt.pt", map_location="cpu", weights_only=True)
model.load_state_dict(ckpt["model"])
optimizer.load_state_dict(ckpt["optimizer"])
scheduler.load_state_dict(ckpt["scheduler"])
start_epoch = ckpt["epoch"] + 1
```

Restore the model **before** constructing the optimizer if you construct it fresh, and move the model to its device before `optimizer.load_state_dict` — Adam's state tensors must sit on the same device as the parameters.

### 13.3 Loading into a different architecture

Two situations come up constantly.

**A pretrained backbone with a new head:**

```python
sd = torch.load("pretrained.pt", map_location="cpu", weights_only=True)
sd = {k: v for k, v in sd.items() if not k.startswith("fc.")}    # drop the old classifier
missing, unexpected = model.load_state_dict(sd, strict=False)
print("missing:", missing)        # ['fc.weight', 'fc.bias'] — expected, they're new
print("unexpected:", unexpected)  # [] — good
```

⚠️ Always print and read those two lists. `strict=False` silently tolerates a checkpoint that loaded *nothing* because every key was misspelled, and you will train a randomly initialised model while believing it is pretrained.

**A checkpoint saved from `DataParallel` or `DistributedDataParallel`** has every key prefixed with `module.`:

```python
sd = {k.removeprefix("module."): v for k, v in sd.items()}
```

Save `model.module.state_dict()` in the first place to avoid this.

### 13.4 Inference done properly

```python
model.eval()                                    # BN/Dropout to inference behaviour

@torch.inference_mode()                         # no graph, faster than no_grad
def predict(model, images, device, batch_size=64):
    outs = []
    for i in range(0, len(images), batch_size):
        xb = images[i:i + batch_size].to(device, non_blocking=True)
        logits = model(xb)
        outs.append(logits.softmax(dim=1).cpu())   # softmax only if you need probabilities
    return torch.cat(outs)
```

The three things people forget: `eval()`, `inference_mode()`, and applying **exactly the same preprocessing** as at training time. A mismatch in resize, crop, channel order (PIL gives RGB, OpenCV gives BGR) or normalisation constants is the most common cause of "it worked in the notebook and fails in production." Serialise your preprocessing definition alongside the weights.

### 13.5 Beyond Python: TorchScript, ONNX, export

**TorchScript** serialises both the weights and the computation, so a C++ or mobile runtime can execute the model with no Python.

```python
model.eval()
example = torch.randn(1, 3, 224, 224)

scripted = torch.jit.trace(model, example)     # runs the model, records the operations
scripted.save("model.ts")

loaded = torch.jit.load("model.ts")
```

⚠️ `torch.jit.trace` records **one** execution path. Data-dependent `if` statements and loops over variable lengths are baked in at their traced values, silently. `torch.jit.script` compiles the Python source instead and preserves control flow, but supports a restricted subset of Python. Rule of thumb: trace when the model is a fixed feed-forward graph (most CNNs), script when control flow depends on the data. Always verify by comparing outputs:

```python
assert torch.allclose(model(example), loaded(example), atol=1e-5)
```

**ONNX** is an interchange format consumed by ONNX Runtime, TensorRT, CoreML and others.

```python
torch.onnx.export(
    model, (example,), "model.onnx",
    input_names=["input"], output_names=["logits"],
    dynamic_axes={"input": {0: "batch"}, "logits": {0: "batch"}},  # variable batch size
    opset_version=17,
)
```

⚠️ **ONNX export needs extra packages.** `torch.onnx.export` is not self-contained: on a clean PyTorch 2.x install the call above raises `ModuleNotFoundError: No module named 'onnxscript'`. Install them first:

```bash
pip install onnx onnxscript
```

Recent PyTorch also offers a `dynamo=True` export path built on `torch.export`, which handles more models faithfully and is becoming the default. Whichever you use, validate numerically against the PyTorch outputs before trusting it, and do not forget `dynamic_axes` — without it the exported graph is locked to the exact batch size you traced with.

**`torch.export`** produces a full-graph intermediate representation, and is the foundation for ExecuTorch (mobile/embedded) and for AOT compilation. It is where the ecosystem is heading, but TorchScript and ONNX remain what you will meet in most existing production systems.

### 13.6 Making inference cheap

- **Batch requests.** GPUs are throughput devices; one image at a time wastes almost all of the hardware.
- **`torch.compile(model, mode="reduce-overhead")`** for inference, which uses CUDA graphs to cut per-call launch overhead.
- **Half precision.** `model.half()` or autocast at inference is usually safe for CNNs and roughly doubles throughput.
- **Quantisation.** Post-training dynamic quantisation is one line and mainly helps linear-heavy models on CPU:

  ```python
  qmodel = torch.ao.quantization.quantize_dynamic(
      model, {nn.Linear}, dtype=torch.qint8)
  ```

  ⚠️ This still works in PyTorch 2.14 but now emits a migration warning: the eager-mode and FX quantisation APIs under `torch.ao.quantization` are moving to the separate **torchao** library (`torchao.quantization.quantize_`, and `prepare_pt2e`/`convert_pt2e` for graph-mode). Use `torch.ao` for quick experiments, and check torchao before building anything you intend to maintain. Static (calibrated) quantisation and quantisation-aware training give better accuracy for convolutional networks at more engineering cost. Expect roughly 4× smaller weights and 2–4× faster CPU inference, at the price of an accuracy drop that must be measured, not assumed.
- **Fuse Conv+BN.** At inference, a convolution followed by BatchNorm can be folded into a single convolution with adjusted weights and bias, saving a kernel launch and some memory traffic. `torch.compile` and the export paths generally do this for you.

### 13.7 Check yourself

1. Why is saving `state_dict` preferred to saving the model object?
2. What does `weights_only=True` protect against?
3. When does `torch.jit.trace` silently produce a wrong model?
4. You load a pretrained checkpoint with `strict=False` and accuracy is at chance. What do you check first?

## 14. Exercises with worked solutions

This chapter has two parts. **Part A** is a graded problem set of new problems, arranged in four tiers: *recall* (you either know it or you don't), *apply* (compute something), *derive* (prove something), and *debug* (find the fault). **Part B** is the answer key to every "Check yourself" box in the preceding chapters.

Work each problem before reading its solution. Attempting and failing is what builds the retrieval pathway; reading a solution you have not attempted builds almost nothing.

### Part A — graded problem set

#### Tier 1 · Recall (aim: 60 seconds each, no code)

**A1.** Which of these are stored in `state_dict()`? (a) `nn.Parameter`, (b) buffers, (c) plain tensor attributes, (d) `requires_grad` flags, (e) optimizer momentum.

> (a) and (b) only. Plain attributes are invisible to the module system, `requires_grad` is not serialised, and optimizer state lives in `optimizer.state_dict()`.

**A2.** Name the three tensor attributes you print first when anything goes wrong.

> `shape`, `dtype`, `device`. In practice add `y.min()` and `y.max()` for labels.

**A3.** For each, say whether it changes layer behaviour, gradient tracking, both, or neither: `model.eval()`, `torch.no_grad()`, `p.requires_grad_(False)`, `torch.inference_mode()`.

> `model.eval()` — layer behaviour only. `torch.no_grad()` — gradient tracking only. `p.requires_grad_(False)` — gradient tracking, for that parameter only (and it does **not** stop BatchNorm buffers updating). `torch.inference_mode()` — gradient tracking, more aggressively than `no_grad`.

**A4.** Which of these is the correct target for `nn.CrossEntropyLoss` given logits of shape `(32, 10)`? (a) `(32, 10)` one-hot float, (b) `(32,)` int64, (c) `(32, 1)` int64, (d) `(32,)` float.

> (b). Modern PyTorch also accepts (a) for soft targets such as mixup, but (b) is the standard form and (c) and (d) both raise.

**A5.** What is the derivative of ReLU at exactly `z = 0` in PyTorch?

> 0. The function is not differentiable there; PyTorch picks the subgradient 0. It is a measure-zero event and has no practical consequence.

#### Tier 2 · Apply (aim: 3–5 minutes each, pen and paper, then verify in code)

**A6.** Trace this network for input `(16, 3, 64, 64)` and give the shape after every layer plus the total parameter count.

```python
nn.Sequential(
    nn.Conv2d(3, 32, 5, stride=1, padding=2), nn.ReLU(),
    nn.MaxPool2d(2),
    nn.Conv2d(32, 64, 3, stride=2, padding=1), nn.ReLU(),
    nn.AdaptiveAvgPool2d(1), nn.Flatten(),
    nn.Linear(64, 5),
)
```

> ```
> Conv2d              (16, 32, 64, 64)   floor((64 + 4 − 5)/1) + 1 = 64
> ReLU                (16, 32, 64, 64)
> MaxPool2d           (16, 32, 32, 32)
> Conv2d              (16, 64, 16, 16)   floor((32 + 2 − 3)/2) + 1 = 16
> ReLU                (16, 64, 16, 16)
> AdaptiveAvgPool2d   (16, 64,  1,  1)
> Flatten             (16, 64)
> Linear              (16,  5)
> ```
>
> Parameters: `32·3·5·5 + 32 = 2,432`, then `64·32·3·3 + 64 = 18,496`, then `64·5 + 5 = 325`. **Total 21,253.** Note that the two convolutions hold 98% of them despite the network looking "mostly" like pooling and linear layers.

**A7.** Compute the receptive field of `[Conv5 s1, Conv3 s1, MaxPool2 s2, Conv3 s1]`.

> `j=1, r=1` initially. Conv5 s1 → `r = 1 + 4·1 = 5`, `j = 1`. Conv3 s1 → `r = 5 + 2·1 = 7`, `j = 1`. MaxPool2 s2 → `r = 7 + 1·1 = 8`, `j = 2`. Conv3 s1 → `r = 8 + 2·2 = 12`, `j = 2`. **Receptive field 12×12.** Notice the last layer contributed 4 pixels rather than 2, because the pool doubled the jump. This is why receptive field grows fast *after* downsampling.

**A8.** A 25M-parameter model is trained in float32 with SGD+momentum. Estimate the memory for parameters, gradients and optimizer state, then redo it for AdamW.

> Each copy is `25e6 × 4 bytes = 100 MB`. SGD+momentum: parameters 100 + gradients 100 + one momentum buffer 100 = **300 MB**. AdamW keeps two buffers: 100 + 100 + 200 = **400 MB**. Activations are extra and usually dominate for CNNs, scaling with batch size.

**A9.** For the confusion matrix below, compute accuracy, macro-F1 and weighted-F1, and say which you would report.

```
cm = [[ 90,  10],      # 100 positives
      [  5, 895]]      # 900 negatives
```

> Accuracy **0.9850**, macro-F1 **0.9574**, weighted-F1 **0.9848**. Report macro-F1 (and the per-class recall of 0.90 on the positive class). Accuracy and weighted-F1 are both dominated by the 900 easy negatives and are nearly identical to each other — they hide the fact that one in ten positives is missed. Macro-F1 is the only one of the three that moves when the rare class degrades.

**A10.** Write, in one line each, the `optimizer` construction for: (i) SGD with momentum and no weight decay on biases, (ii) a pretrained backbone at `1e-4` with a new head at `1e-3`.

> ```python
> # (i)
> opt = torch.optim.SGD([{"params": [p for p in model.parameters() if p.ndim > 1], "weight_decay": 5e-4},
>                        {"params": [p for p in model.parameters() if p.ndim <= 1], "weight_decay": 0.0}],
>                       lr=0.1, momentum=0.9)
> # (ii)
> opt = torch.optim.AdamW([{"params": backbone_params, "lr": 1e-4},
>                          {"params": head_params,     "lr": 1e-3}], weight_decay=0.01)
> ```

#### Tier 3 · Derive (aim: 10–20 minutes each)

**A11.** Prove that softmax is shift-invariant, and explain why this justifies the max-subtraction trick.

> For any constant `c`, `softmax(z + c)ᵢ = exp(zᵢ + c) / Σⱼ exp(zⱼ + c) = eᶜ·exp(zᵢ) / (eᶜ·Σⱼ exp(zⱼ)) = softmax(z)ᵢ`. The `eᶜ` cancels exactly. So choosing `c = −max(z)` changes nothing mathematically but guarantees the largest exponent is `exp(0) = 1`, eliminating overflow. Underflow of the *small* terms is harmless because they contribute negligibly to the sum.

**A12.** Derive `∂L/∂z = softmax(z) − y` for cross-entropy with a one-hot target, for a single sample.

> Let `p = softmax(z)` and `L = −Σₖ yₖ log pₖ`. With `y` one-hot at index `t`, `L = −log p_t = −z_t + log Σⱼ exp(zⱼ)`. Differentiate with respect to `zᵢ`: `∂L/∂zᵢ = −[i = t] + exp(zᵢ)/Σⱼ exp(zⱼ) = pᵢ − yᵢ`. The result is the prediction minus the target — the same form as the gradient of squared error for linear regression, which is not a coincidence: both losses are the negative log-likelihood of an exponential-family model with the matching link function. Dividing by `B` gives the batch-mean version used in code.

**A13.** Show that the convolution bias is redundant when the layer is immediately followed by BatchNorm.

> Let the convolution output at channel `c` be `uᵢ = vᵢ + b_c`, where `vᵢ` is the bias-free output. BatchNorm computes `(uᵢ − μ_c)/√(σ²_c + ε)` where `μ_c` is the mean of `u` over the batch and spatial positions. Since `b_c` is constant across those positions, `μ_c = mean(v) + b_c`, so `uᵢ − μ_c = vᵢ − mean(v)`: the bias cancels exactly. The variance is also unchanged, since adding a constant does not change variance. Therefore the output is identical for any `b_c`, and its gradient is zero. BN's learned `β` provides the shift instead.

**A14.** Generalise the VGG argument: under what condition do `n` stacked `k×k` convolutions have fewer parameters than one convolution with the same receptive field?

> `n` stacked `k×k` layers at `C` channels give receptive field `R = n(k−1) + 1` and cost `n·k²C²` parameters. One layer with the same receptive field costs `R²C² = (n(k−1)+1)²C²`. Stacking wins when `n·k² < (n(k−1)+1)²`. For `k = 3` this is `9n < (2n+1)²`, i.e. `4n² − 5n + 1 > 0`, true for every `n ≥ 2`. So stacking 3×3 always wins from two layers up — and the margin grows with `n`. The gain is not only parameters: you also get `n−1` extra nonlinearities.

**A15.** Explain why a dead ReLU unit cannot recover, in terms of the chain rule.

> The gradient reaching the unit's weights is `∂L/∂w = (∂L/∂a)·(∂a/∂z)·(∂z/∂w)`, where `a = max(0, z)`. If `z < 0` for every input in the dataset, then `∂a/∂z = 0` for every input, so the product is zero regardless of how large `∂L/∂a` is. The weights and bias therefore never change, so `z` stays negative forever. The state is a fixed point of the optimiser, not a slow region — which is precisely why LeakyReLU's small negative slope is sufficient to fix it.

#### Tier 4 · Debug (aim: spot the fault in under a minute)

**A16.**

```python
scheduler = torch.optim.lr_scheduler.OneCycleLR(
    opt, max_lr=0.1, epochs=30, steps_per_epoch=len(train_loader))
for epoch in range(30):
    for xb, yb in train_loader:
        ...
        opt.step()
    scheduler.step()          # <-- here
```

> `OneCycleLR` is parameterised in *iterations* (`epochs × steps_per_epoch`), so it must be stepped once per batch. Stepping once per epoch means the schedule advances `len(train_loader)` times too slowly and never completes its cycle — the learning rate stays near `max_lr/25` for the whole run and the model badly underfits.

**A17.**

```python
class MyDataset(Dataset):
    def __getitem__(self, i):
        img = np.load(self.paths[i])          # float64 array, HWC
        return img, self.labels[i]            # labels are Python ints
```

> Three faults. The array is `float64`, so the whole batch becomes `float64` and every operation runs at half speed and double memory — cast to `float32`. It is HWC, but `Conv2d` expects CHW — permute. And it is a NumPy array rather than a tensor, so the default collate will convert it but you lose control of dtype; convert explicitly with `torch.from_numpy(img).permute(2, 0, 1).float()`.

**A18.**

```python
for p in model.parameters():
    p.requires_grad = False
model.fc = nn.Linear(512, 10)
opt = torch.optim.AdamW(model.parameters(), lr=1e-3)
model.train()
for epoch in range(20):
    train_one_epoch(...)
```

> The freeze looks right but the backbone is not actually frozen: `model.train()` leaves every BatchNorm in training mode, so `running_mean` and `running_var` keep being overwritten with statistics from the new dataset — they are buffers, unaffected by `requires_grad`. On a small or domain-shifted dataset this degrades the pretrained features over the 20 epochs. Fix by calling `model.apply(freeze_bn)` after `model.train()` each epoch (§11.3). Passing `model.parameters()` to the optimizer is harmless here since the frozen ones get no gradient, but filtering is clearer.

**A19.**

```python
probs = torch.softmax(model(xb), dim=1)
pred  = probs.argmax(dim=1)
acc   = (pred == yb).float().mean()
loss  = criterion(probs, yb)          # criterion = nn.CrossEntropyLoss()
```

> The accuracy lines are correct but wasteful — softmax is monotonic, so `model(xb).argmax(1)` gives the same answer for free. The real bug is the last line: `CrossEntropyLoss` applies log-softmax internally, so this applies softmax twice. The model still trains, just to a worse optimum, and nothing raises — which is what makes it dangerous.

**A20.**

```python
mean, std = channel_stats(DataLoader(full_dataset, batch_size=256))
train_ds, val_ds = random_split(full_dataset, [45000, 5000])
```

> Data leakage. The normalisation statistics are computed over the whole dataset, including the 5,000 samples that become the validation set, so validation information influences the training-time transform. Compute statistics on the training split only. The effect is small for normalisation constants specifically, but the same mistake with PCA, vocabularies, imputation values or class weights is not small at all — and an interviewer will treat it as a methodology red flag regardless of magnitude.

### Part B — answers to the "Check yourself" boxes

### Chapter 1 — Tensors

**1.1** `torch.arange(6).mean()` — what happens?

> Raises `RuntimeError: mean(): could not infer output dtype. Input dtype must be either a floating point or complex dtype.` `arange` with integer arguments produces `int64`, and mean is undefined for integer types. Fix: `torch.arange(6).float().mean()` → `2.5`.

**1.2** Why does `model.to(device)` work but `x.to(device)` not?

> `nn.Module.to()` moves parameters and buffers **in place** and returns `self` for convenience. `Tensor.to()` cannot modify a tensor's device in place, so it returns a new tensor; discarding the return value leaves `x` where it was. Always write `x = x.to(device)`.

**1.3** After `t = torch.from_numpy(a); a[0] = 5`, what is `t[0]`?

> `5`. `from_numpy` shares memory with the NumPy array on CPU. `torch.tensor(a)` would have copied.

**1.4** Why is `total += loss` a memory bug?

> `loss` is a tensor attached to the whole batch's computational graph. Summing tensors keeps every graph alive for the entire epoch, so memory grows linearly with the number of batches until you run out. `loss.item()` extracts a Python float and drops the graph.

**1.5 (code)** Write a function that takes any tensor and returns a dictionary reporting shape, dtype, device, element count, memory in MB, and whether it is contiguous.

> ```python
> def describe(t):
>     return {
>         "shape": tuple(t.shape),
>         "dtype": str(t.dtype),
>         "device": str(t.device),
>         "numel": t.numel(),
>         "MB": t.numel() * t.element_size() / 1e6,
>         "contiguous": t.is_contiguous(),
>         "requires_grad": t.requires_grad,
>     }
> ```

### Chapter 2 — Shapes and broadcasting

**2.1** `torch.randn(5, 4) + torch.randn(5)` vs `+ torch.randn(4)`.

> The first **fails**: right-aligned, the trailing dims are 4 and 5 — incompatible. The second **works**: `(4,)` becomes `(1, 4)`, stretches to `(5, 4)`. To add a per-row vector you need `torch.randn(5, 1)`.

**2.2** Why does `x.t().view(-1)` fail while `.reshape(-1)` succeeds?

> `x.t()` swaps strides without moving memory, so the transposed tensor is non-contiguous. `view` requires that the requested shape be expressible with the existing strides; flattening a transposed tensor is not. `reshape` detects this and falls back to copying into fresh contiguous memory.

**2.3** Shape of `torch.randn(2, 3, 4).sum(dim=1, keepdim=True)`?

> `(2, 1, 4)`. Dimension 1 is reduced; `keepdim=True` retains it with size 1.

**2.4** `(B, C, H, W) → (B, H*W, C)`.

> ```python
> B, C, H, W = x.shape
> out = x.permute(0, 2, 3, 1).reshape(B, H * W, C)
> ```
>
> `permute` first so that channels end up last, then merge the two spatial dims. `reshape` (not `view`) because `permute` broke contiguity.

**2.5 (code)** Implement a numerically stable log-softmax by hand and verify against `F.log_softmax`.

> ```python
> def my_log_softmax(z, dim=-1):
>     z_max = z.max(dim=dim, keepdim=True).values
>     z = z - z_max                                   # shift: safe, softmax is shift-invariant
>     return z - z.exp().sum(dim=dim, keepdim=True).log()
> 
> x = torch.randn(4, 10) * 100                        # deliberately extreme
> assert torch.allclose(my_log_softmax(x, 1), F.log_softmax(x, 1), atol=1e-5)
> ```

**2.6 (code)** Compute pairwise squared Euclidean distances between two sets of points without loops.

> ```python
> def pdist2(A, B):                     # A: (N, D), B: (M, D) -> (N, M)
>     return ((A[:, None, :] - B[None, :, :]) ** 2).sum(-1)
> 
> # memory-efficient version using ||a-b||² = ||a||² + ||b||² − 2a·b
> def pdist2_fast(A, B):
>     return (A.pow(2).sum(1, keepdim=True)
>             + B.pow(2).sum(1)
>             - 2 * A @ B.T).clamp_min(0)
> ```
>
> The first materialises an `(N, M, D)` tensor and will OOM for large inputs; the second never exceeds `(N, M)`. `clamp_min(0)` guards against small negative values from floating-point cancellation.

### Chapter 3 — Autograd

**3.1** Why must `backward()` be called on a scalar?

> Reverse-mode AD computes a vector–Jacobian product `vᵀJ`, not the Jacobian. `v` must be supplied; for a scalar output the only sensible `v` is `1`, so PyTorch fills it in. `y.backward(v)` computes `vᵀJ`, which equals the gradient of `(y·v).sum()` with respect to the inputs.

**3.2** Two reasons gradients accumulate.

> (a) Gradient accumulation across micro-batches to simulate a large batch on limited memory. (b) Multiple loss terms or multiple uses of the same parameter — their gradient contributions must sum, which falls out automatically. A third: multi-task setups where several heads each call `backward()`.

**3.3** `model.eval()` vs `torch.no_grad()`.

> `model.eval()` flips `self.training` to `False` recursively, changing the behaviour of Dropout and BatchNorm. It does nothing to autograd. `torch.no_grad()` stops graph construction, saving memory and time, but does not change layer behaviour. You need both during validation: `eval()` for correct outputs, `no_grad()` for efficiency.

**3.4** Does modifying `b = a.detach()` in place change `a`?

> Yes — `detach` shares storage. Use `a.detach().clone()` for an independent copy. Note that in-place modification of a detached tensor that autograd still needs will also trigger a version-counter error.

**3.5 (code)** Verify by hand-computation that PyTorch's gradient of `f(x) = sin(x²)` at `x = 1.5` is correct.

> `f'(x) = 2x·cos(x²)`. At `x = 1.5`: `3·cos(2.25) ≈ 3 · (−0.6282) ≈ −1.8845`.
>
> ```python
> x = torch.tensor(1.5, requires_grad=True)
> y = torch.sin(x ** 2)
> y.backward()
> print(x.grad)                                    # tensor(-1.8845)
> print(2 * 1.5 * torch.cos(torch.tensor(2.25)))   # tensor(-1.8845)
> ```

**3.6 (code)** Implement a straight-through estimator: forward rounds to the nearest integer, backward passes the gradient through unchanged.

> ```python
> class RoundSTE(torch.autograd.Function):
>     @staticmethod
>     def forward(ctx, x):
>         return torch.round(x)
>     @staticmethod
>     def backward(ctx, g):
>         return g                      # pretend the forward was the identity
> 
> x = torch.tensor([1.2, 2.7], requires_grad=True)
> RoundSTE.apply(x).sum().backward()
> print(x.grad)                         # tensor([1., 1.])
> ```
>
> Without this trick the gradient of `round` is zero almost everywhere and nothing upstream can learn. This is the basis of quantisation-aware training.

### Chapter 4 — Modules

**4.1** Plain list of layers — what breaks first?

> The forward pass still works if you loop over the list manually. What breaks is registration: `model.parameters()` is empty, so the optimizer receives nothing and updates nothing, and `model.to(device)` leaves those layers on the CPU. Training runs and the loss never moves. Use `nn.ModuleList`.

**4.2** Three things in `state_dict` that are not parameters.

> BatchNorm's `running_mean`, `running_var`, and `num_batches_tracked`. More generally, anything registered with `register_buffer` — positional encodings, causal masks, quantisation scales.

**4.3** `self.mask = torch.ones(10)` in `__init__` — the bug and the fix.

> A plain tensor attribute is not registered, so `model.to("cuda")` leaves it on the CPU and the forward pass raises a device mismatch. It is also missing from `state_dict`, so it is not saved. Fix: `self.register_buffer("mask", torch.ones(10))`.

**4.4** What does `model.eval()` change?

> Only the `training` flag on every submodule, which Dropout and BatchNorm read. It does not stop gradient tracking.

**4.5 (code)** Write a module that counts its own parameters and reports the per-layer breakdown.

> ```python
> def param_report(model):
>     rows, total = [], 0
>     for name, m in model.named_modules():
>         n = sum(p.numel() for p in m.parameters(recurse=False))
>         if n:
>             rows.append((name or "<root>", m.__class__.__name__, n))
>             total += n
>     width = max(len(r[0]) for r in rows)
>     for name, cls, n in rows:
>         print(f"{name:<{width}}  {cls:<16} {n:>10,}  ({100*n/total:5.1f}%)")
>     print(f"{'TOTAL':<{width}}  {'':<16} {total:>10,}")
> ```
>
> `recurse=False` is the key detail — without it every parent double-counts its children.

### Chapter 5 — Data

**5.1** Two required `Dataset` methods: `__len__` and `__getitem__`.

**5.2** `drop_last` asymmetry.

> In training, a final batch of size 1 or 2 gives noisy gradients and crashes BatchNorm, and one discarded batch per epoch is statistically irrelevant since the data is reshuffled anyway. In testing, dropping the last batch means you never evaluate those samples, so your reported metric is on a different (smaller) set.

**5.3** Unstable validation accuracy despite a fixed seed — two data-pipeline causes.

> (a) Augmentation is being applied to the validation set, typically via `random_split` sharing one transform. (b) DataLoader workers are unseeded, so augmentation randomness is not reproducible. Also plausible: `shuffle=True` on the validation loader combined with `drop_last=True`, or non-deterministic cuDNN kernels.

**5.4** Two approaches to 100:1 imbalance.

> `WeightedRandomSampler` rebalances the batches — simple, but repeats minority samples many times per epoch and can overfit them. Loss weighting (`CrossEntropyLoss(weight=...)` or `pos_weight`) keeps the data distribution and reweights the objective — no repetition, but the gradient signal from rare classes is still sparse. Both should be paired with a metric that survives imbalance (per-class recall, F1, average precision), because accuracy is meaningless at 100:1.

**5.5 (code)** Write a `Dataset` for a folder of images with labels in a CSV.

> ```python
> import pandas as pd
> from PIL import Image
> from pathlib import Path
> 
> class CsvImageDataset(Dataset):
>     def __init__(self, csv_path, img_dir, transform=None):
>         self.df = pd.read_csv(csv_path)          # columns: filename, label
>         self.img_dir = Path(img_dir)
>         self.transform = transform
>         self.classes = sorted(self.df["label"].unique())
>         self.class_to_idx = {c: i for i, c in enumerate(self.classes)}
> 
>     def __len__(self):
>         return len(self.df)
> 
>     def __getitem__(self, idx):
>         row = self.df.iloc[idx]
>         img = Image.open(self.img_dir / row["filename"]).convert("RGB")
>         if self.transform:
>             img = self.transform(img)
>         return img, self.class_to_idx[row["label"]]
> ```
>
> `.convert("RGB")` matters: some PNGs are RGBA or grayscale and would otherwise produce inconsistent channel counts that crash collation.

### Chapters 6–7 — Losses, optimizers, training

**6.1** Why logits?

> Computing softmax then log separately overflows (`exp` of a large logit) or underflows (`log` of a tiny probability). The fused `log_softmax` uses the max-subtraction identity to stay in range. Passing already-softmaxed values to `CrossEntropyLoss` applies log-softmax *again*, which is mathematically wrong and flattens the gradients.

**6.2** Adam vs AdamW.

> Adam implements weight decay as an L2 term added to the gradient, which then passes through the adaptive `1/√v̂` scaling — so parameters with large gradient variance get *less* decay, which is not what regularisation should do. AdamW applies the decay directly to the weights, decoupled from the adaptive step. AdamW generalises better in practice and is the default for modern recipes.

**6.3** Scheduler placement.

> After all `optimizer.step()` calls for that period. Per-epoch for `StepLR`, `MultiStepLR`, `CosineAnnealingLR`, `ReduceLROnPlateau`. Per-batch for `OneCycleLR` and warmup schedulers, where `T_max`/`total_steps` is measured in iterations.

**6.4** Why exclude biases and norm parameters from weight decay?

> Weight decay is a prior favouring small weights, which is meaningful for the multiplicative weights that determine function complexity. A bias only shifts the output and does not increase capacity in the relevant sense. Shrinking a BatchNorm `γ` toward zero literally suppresses whole channels, and shrinking `β` fights the layer's purpose. Empirically, excluding them gives a small but consistent improvement.

**7.1** The five lines: `zero_grad`, forward, loss, `backward`, `step`.

**7.2** 10-class classifier starting at loss 7.4.

> Random initialisation should give `ln(10) ≈ 2.30`. A loss of 7.4 means the initial predictions are confidently wrong, which points to: a final layer with an activation applied (softmax then cross-entropy), labels out of range or misaligned, a badly scaled initialisation, or unnormalised inputs producing huge logits. Check the label range and the final layer first.

**7.3** Why clone the best state?

> `state_dict()` returns references to the live parameter tensors. They keep being updated by subsequent `optimizer.step()` calls, so the "saved" dictionary tracks the current model and you restore the final weights instead of the best ones. `{k: v.detach().cpu().clone()}` snapshots the values.

**7.4** 99.2% accuracy on a fraud dataset — first question?

> "What fraction of the data is fraud?" If fraud is 1% of rows, always predicting *legitimate* scores 99.0%, so their model is worth 0.2 points over a constant. Follow up by asking for the confusion matrix, the recall on the fraud class, and PR-AUC. A metric without its trivial baseline is not a result.

**7.5** When is ROC-AUC misleading?

> Under heavy class imbalance. The false-positive rate is `FP/(FP+TN)`, and with a huge negative class `TN` dominates the denominator, so hundreds of false alarms barely move the curve. ROC-AUC therefore looks flattering while precision is terrible. Use PR-AUC (average precision), where a random model scores about the positive rate rather than 0.5.

**7.6** The debugging protocol: shapes and label dtype/range → initial loss ≈ `ln(C)` → overfit one batch → check gradient norms → only then tune.

**7.7 (code)** Implement linear regression with manual gradients, then with autograd, and confirm they agree.

> ```python
> torch.manual_seed(0)
> X = torch.randn(100, 3); true_w = torch.tensor([2.0, -1.0, 0.5]); y = X @ true_w + 0.1
> 
> # manual: L = mean((Xw + b − y)²);  dL/dw = 2/N · Xᵀ(Xw + b − y)
> w = torch.zeros(3); b = torch.zeros(1)
> for _ in range(500):
>     resid = X @ w + b - y
>     gw = 2 / len(X) * X.T @ resid
>     gb = 2 * resid.mean()
>     w -= 0.1 * gw; b -= 0.1 * gb
> 
> # autograd
> w2 = torch.zeros(3, requires_grad=True); b2 = torch.zeros(1, requires_grad=True)
> opt = torch.optim.SGD([w2, b2], lr=0.1)
> for _ in range(500):
>     opt.zero_grad()
>     ((X @ w2 + b2 - y) ** 2).mean().backward()
>     opt.step()
> 
> print(w, w2)          # both ≈ [2.0, -1.0, 0.5]
> assert torch.allclose(w, w2.detach(), atol=1e-4)
> ```

### Chapters 8–10 — Convolutions and architectures

**8.1** `(8, 3, 224, 224)` through `Conv2d(3, 64, 7, stride=2, padding=3)`.

> `H_out = floor((224 + 6 − 7)/2) + 1 = floor(223/2) + 1 = 111 + 1 = 112`. Output `(8, 64, 112, 112)`. Parameters: `64·3·7·7 + 64 = 9,408 + 64 = 9,472`.

**8.2** Two 3×3 vs one 5×5.

> Same 5×5 receptive field. Parameters: `2·(9C²) = 18C²` versus `25C²` — 28% fewer. And two nonlinearities instead of one, so the composite function is more expressive. Both effects favour the stacked version; this is VGG's central claim.

**8.3** What does a 1×1 convolution do?

> A learned linear projection across channels at every spatial location. Uses: changing channel depth cheaply (bottlenecks), adding a nonlinearity without touching resolution, and mixing information that grouped or depthwise convolutions kept separate. It is not a no-op because `C_in ≠ C_out` in general, and even when they are equal it is a full `C×C` mixing matrix.

**8.4** Receptive field of `[Conv3 s1, MaxPool2 s2, Conv3 s1]`.

> `j₀=1, r₀=1`. Conv3 s1: `r = 1 + 2·1 = 3`, `j = 1`. MaxPool2 s2: `r = 3 + 1·1 = 4`, `j = 2`. Conv3 s1: `r = 4 + 2·2 = 8`, `j = 2`. Receptive field **8×8**.

**9.1** Linear layers collapse: `W₂(W₁x + b₁) + b₂ = (W₂W₁)x + (W₂b₁ + b₂)`, which is a single affine map. Depth without nonlinearity buys nothing but a harder optimisation problem.

**9.2** Sigmoid's derivative is `σ(z)(1−σ(z))`, bounded above by **0.25** at `z = 0` and far smaller elsewhere (`0.0025` at `z = 6`). Backpropagation multiplies one such factor per layer, so gradients decay geometrically with depth. Measured on a 10-layer MLP (§9.2), the first layer's gradient norm is `3.2e-07` against the last layer's `370` — a ratio of about `1.2e9`, and the decay is roughly a factor of 7 per layer. ReLU has derivative exactly 1 on the active path, so it does not attenuate; the same measurement gives a ratio of about `2.1e3`.

**9.3** A dead ReLU has `z < 0` for every input, so `∂a/∂z = 0` for every input, so the gradient reaching its weights is exactly zero by the chain rule — it is a fixed point, not a slow region. No learning rate or optimizer can revive it. LeakyReLU's nonzero negative slope prevents the state from existing.

**9.4** `bias=False` before BatchNorm: BN subtracts the mean, removing any constant offset the convolution's bias added, so the bias has zero effect on the output and only wastes parameters. BN's `β` serves that role.

**9.5** BatchNorm train vs eval: train normalises with the current batch's mean and variance and updates the running estimates; eval normalises with the stored running estimates and updates nothing.

**9.6** Transformers use LayerNorm because sequence lengths vary and padding pollutes batch statistics, per-device batch sizes are small, and single-sequence inference must behave identically to training. LayerNorm normalises within each token's feature vector, independent of the batch.

**9.7** Dropout in CNN trunks: convolutional activations are spatially correlated, so zeroing individual units removes little information; and dropout before BatchNorm shifts the variance between train and eval, corrupting BN's running statistics. BatchNorm plus augmentation regularises better.

**10.1** Degradation: deeper plain networks had higher *training* error than shallower ones — an optimisation failure, not overfitting, since overfitting would show as low training error and high test error.

**10.2** Projection shortcut: whenever `stride != 1` (spatial size changes) or `in_channels != out_channels`, because addition requires identical shapes.

**10.3** Bottleneck: the 3×3 convolution's cost is quadratic in channel count, so reducing 256→64 first, doing the spatial work at 64, and restoring to 256 costs roughly an eighth of the parameters of a direct 3×3 at 256 channels.

**10.4** ResNet-34: `1 + (3+4+6+3)·2 + 1 = 1 + 32 + 1 = 34`.

**10.5 (code)** Add a squeeze-and-excitation block to `BasicBlock`.

> ```python
> class SEBlock(nn.Module):
>     def __init__(self, c, r=16):
>         super().__init__()
>         self.fc = nn.Sequential(
>             nn.Linear(c, c // r), nn.ReLU(inplace=True),
>             nn.Linear(c // r, c), nn.Sigmoid(),
>         )
>     def forward(self, x):
>         b, c, _, _ = x.shape
>         s = x.mean(dim=(2, 3))            # global average pool -> (B, C)
>         s = self.fc(s).view(b, c, 1, 1)   # per-channel gate in [0, 1]
>         return x * s                       # broadcast over H and W
> ```
>
> Insert it after `bn2` and before the residual addition. It is channel attention: the network learns which feature maps matter for this particular input.

### Chapters 11–13 — Training well and shipping

**11.1** Normalisation constants: the pretrained weights were optimised for inputs with a specific mean and scale. Feeding differently-scaled inputs shifts every activation away from the regime the filters expect, degrading features. Nothing errors, so it is invisible without a controlled comparison.

**11.2** With `requires_grad=False` everywhere in the backbone, BatchNorm's `running_mean` and `running_var` still update in `train()` mode, because they are buffers rather than parameters. Put the BN modules in `eval()` mode to truly freeze the backbone.

**11.3** `GradScaler` exists because float16's representable range bottoms out around `6e-5` and many gradients are smaller, so they would flush to zero. Scaling the loss up shifts them into range. With `bfloat16` — same exponent range as float32 — you can usually omit it.

**11.4** Dividing by the accumulation count makes the accumulated gradient the *mean* over the effective batch, matching what a single large batch would produce. Without it the gradient is `ACCUM` times too large and the effective learning rate scales with it.

**12.1** CUDA kernels launch asynchronously, so the Python line executing when the error surfaces is usually later than the line that caused it. Set `CUDA_LAUNCH_BLOCKING=1`, or reproduce on CPU for an accurate traceback.

**12.2** AdamW keeps two state tensors per parameter (`exp_avg`, `exp_avg_sq`). For 50M parameters at 4 bytes: `2 · 50e6 · 4 = 400 MB` of optimizer state, plus 200 MB parameters and 200 MB gradients — 800 MB before activations.

**12.3** `cudnn.benchmark = True` benchmarks candidate algorithms for each new input shape. With varying shapes (variable-size images, ragged last batches) it re-benchmarks constantly and is slower than the default heuristic.

**12.4** GPU work is queued asynchronously, so `time.time()` measures how long it took to enqueue the kernels, not to run them. Call `torch.cuda.synchronize()` before and after, and warm up first.

**13.1** `state_dict` is a plain dictionary of tensors, portable across codebases and versions. Pickling the model stores a reference to the class definition, so it breaks when file paths, module names, or library versions change.

**13.2** `weights_only=True` blocks arbitrary code execution during unpickling of an untrusted checkpoint.

**13.3** `torch.jit.trace` records the operations executed for one specific input. Any data-dependent branch, variable-length loop, or shape-dependent logic is frozen at the traced value and silently wrong for other inputs. Use `torch.jit.script` for those models.

**13.4** Print the `missing` and `unexpected` key lists returned by `load_state_dict(..., strict=False)`. Accuracy at chance with `strict=False` almost always means every key mismatched (often a `module.` prefix from DataParallel, or a renamed backbone attribute) so nothing was loaded at all.

## 15. Assignments with reference solutions

Three assignments, increasing in scope. Do them in order; each assumes the previous one.

### Assignment 1 — Backpropagation by hand (understanding)

**Task.** Implement a two-layer MLP for multi-class classification using only tensor operations — no `nn.Module`, no `autograd`. Write the forward pass and the analytic backward pass yourself. Then verify every gradient against autograd to within `1e-5`.

**Requirements**

1. Architecture: `Linear(D, H) → ReLU → Linear(H, C)`, softmax cross-entropy loss.
2. Derive and implement `dL/dW1, db1, dW2, db2` on paper first.
3. Verify with `torch.autograd.grad`.
4. Train on a synthetic 3-class 2-D dataset and report accuracy.

**Rubric:** derivation correct (30) · implementation matches autograd (30) · trains to >90% on the toy set (20) · code clarity and the written explanation of the softmax-CE gradient (20).

**The key derivation.** For softmax cross-entropy with logits `z` and one-hot target `y`, the gradient with respect to the logits collapses to something remarkably simple:

```
∂L/∂z = (softmax(z) − y) / B
```

That is *the* result to be able to derive on a whiteboard. The `exp` in the softmax and the `log` in the cross-entropy cancel; the derivation is two lines and it is commonly asked in interviews. The rest is standard matrix calculus: for `z = a W + b`, `∂L/∂W = aᵀ (∂L/∂z)`, `∂L/∂b = Σ_batch ∂L/∂z`, `∂L/∂a = (∂L/∂z) Wᵀ`. ReLU's local gradient is the mask `a > 0`.

**Reference solution**

```python
import torch

torch.manual_seed(0)
D, H, C, B = 2, 64, 3, 256

# ---- synthetic three-spiral data ------------------------------------------
def make_spirals(n_per_class=400, n_classes=3, noise=0.15):
    X, y = [], []
    for c in range(n_classes):
        t = torch.linspace(0.2, 1.0, n_per_class)
        theta = t * 4 + c * 2 * torch.pi / n_classes + torch.randn(n_per_class) * noise
        X.append(torch.stack([t * torch.cos(theta), t * torch.sin(theta)], dim=1))
        y.append(torch.full((n_per_class,), c))
    return torch.cat(X), torch.cat(y)

X, y = make_spirals()

# ---- parameters ------------------------------------------------------------
W1 = torch.randn(D, H) * (2.0 / D) ** 0.5     # He init for ReLU
b1 = torch.zeros(H)
W2 = torch.randn(H, C) * (2.0 / H) ** 0.5
b2 = torch.zeros(C)

def forward(X, W1, b1, W2, b2):
    z1 = X @ W1 + b1
    a1 = z1.clamp_min(0.0)          # ReLU
    z2 = a1 @ W2 + b2               # logits
    return z1, a1, z2

def softmax_ce(z2, y):
    z = z2 - z2.max(dim=1, keepdim=True).values          # stability
    logp = z - z.exp().sum(dim=1, keepdim=True).log()
    return -logp[torch.arange(len(y)), y].mean()

def backward(X, y, z1, a1, z2, W2):
    B = len(y)
    p = torch.softmax(z2, dim=1)
    dz2 = p.clone()
    dz2[torch.arange(B), y] -= 1.0
    dz2 /= B                                    # (B, C)  = (softmax − onehot)/B

    dW2 = a1.T @ dz2                            # (H, C)
    db2 = dz2.sum(0)                            # (C,)
    da1 = dz2 @ W2.T                            # (B, H)
    dz1 = da1 * (z1 > 0).float()                # ReLU mask
    dW1 = X.T @ dz1                             # (D, H)
    db1 = dz1.sum(0)                            # (H,)
    return dW1, db1, dW2, db2

# ---- gradient check --------------------------------------------------------
Ps = [p.clone().requires_grad_(True) for p in (W1, b1, W2, b2)]
z1, a1, z2 = forward(X, *Ps)
loss = softmax_ce(z2, y)
auto = torch.autograd.grad(loss, Ps)

z1, a1, z2 = forward(X, W1, b1, W2, b2)
mine = backward(X, y, z1, a1, z2, W2)

for name, m, a in zip(["W1", "b1", "W2", "b2"], mine, [auto[0], auto[1], auto[2], auto[3]]):
    print(f"{name}: max abs diff {(m - a).abs().max():.2e}")
    assert torch.allclose(m, a, atol=1e-5)
print("gradient check passed")

# ---- train with plain SGD ---------------------------------------------------
lr = 0.5
for step in range(3000):
    z1, a1, z2 = forward(X, W1, b1, W2, b2)
    loss = softmax_ce(z2, y)
    dW1, db1, dW2, db2 = backward(X, y, z1, a1, z2, W2)
    W1 -= lr * dW1; b1 -= lr * db1
    W2 -= lr * dW2; b2 -= lr * db2
    if step % 500 == 0:
        acc = (z2.argmax(1) == y).float().mean()
        print(f"step {step:4d}  loss {loss:.4f}  acc {acc:.3f}")
```

Verified output when run: the four gradient differences are `7.45e-09`, `1.49e-08`, `2.98e-08`, `1.12e-08`, and after 3,000 steps the loss is `0.0034` at **accuracy 1.000** on this seed. Note that `dW1 = X.T @ dz1` needs no `/B` because the division already happened inside `dz2`.

### Assignment 2 — CIFAR-10 from scratch (engineering)

**Task.** Train a CNN on CIFAR-10 without any pretrained weights. Reach **≥ 90%** test accuracy for a pass and **≥ 93%** for full marks, in under 60 epochs.

**Requirements**

1. Proper three-way split; the test set is used exactly once.
2. Data augmentation, with a figure showing augmented samples.
3. A learning-rate schedule, with the schedule plotted.
4. Training curves for loss and accuracy, both splits.
5. A confusion matrix and a discussion of the two most-confused classes.
6. An ablation: train the same model with augmentation disabled and report the difference.
7. Report mean ± std over 3 seeds for your final configuration.

**Rubric:** accuracy target (25) · correct methodology, no test-set leakage (25) · ablation and analysis (25) · reproducibility, seeds, logged config (15) · code quality (10).

**Reference solution.** This script is not standalone — it reuses three things defined earlier, and you should paste them into the same file: `BasicBlock`, `ResNet` and `resnet18` from §10.6, and `evaluate` from §7.2. Everything else is here.

```python
import torch, torch.nn as nn, numpy as np
from torch.utils.data import DataLoader, random_split
from torchvision import datasets
from torchvision.transforms import v2

MEAN, STD = (0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def build_loaders(augment=True, batch_size=128):
    common = [v2.ToImage(), v2.ToDtype(torch.float32, scale=True), v2.Normalize(MEAN, STD)]
    train_tf = v2.Compose(
        ([v2.RandomCrop(32, padding=4, padding_mode="reflect"),
          v2.RandomHorizontalFlip()] if augment else []) + common
        + ([v2.RandomErasing(p=0.25)] if augment else []))
    test_tf = v2.Compose(common)

    train_full = datasets.CIFAR10("./data", train=True, download=True, transform=train_tf)
    val_full   = datasets.CIFAR10("./data", train=True, download=True, transform=test_tf)
    test_ds    = datasets.CIFAR10("./data", train=False, download=True, transform=test_tf)

    # Split INDICES once, then index two dataset objects with different transforms.
    g = torch.Generator().manual_seed(1234)          # fixed: the split must not vary
    idx = torch.randperm(len(train_full), generator=g)
    tr_idx, va_idx = idx[:45_000], idx[45_000:]
    train_ds = torch.utils.data.Subset(train_full, tr_idx.tolist())
    val_ds   = torch.utils.data.Subset(val_full,   va_idx.tolist())

    return (DataLoader(train_ds, batch_size, shuffle=True,  num_workers=4,
                       pin_memory=True, drop_last=True, persistent_workers=True),
            DataLoader(val_ds,   512, shuffle=False, num_workers=4, pin_memory=True),
            DataLoader(test_ds,  512, shuffle=False, num_workers=4, pin_memory=True))


def run(seed, augment=True, epochs=40):
    torch.manual_seed(seed); np.random.seed(seed)
    train_loader, val_loader, test_loader = build_loaders(augment)

    model = resnet18(n_classes=10, small_input=True).to(device)
    model = model.to(memory_format=torch.channels_last)

    decay = [p for n, p in model.named_parameters() if p.ndim > 1]
    no_decay = [p for n, p in model.named_parameters() if p.ndim <= 1]
    opt = torch.optim.SGD(
        [{"params": decay, "weight_decay": 5e-4},
         {"params": no_decay, "weight_decay": 0.0}],
        lr=0.1, momentum=0.9, nesterov=True)

    sched = torch.optim.lr_scheduler.OneCycleLR(
        opt, max_lr=0.1, epochs=epochs, steps_per_epoch=len(train_loader), pct_start=0.15)

    crit = nn.CrossEntropyLoss(label_smoothing=0.1)
    scaler = torch.amp.GradScaler("cuda", enabled=(device.type == "cuda"))

    best_acc, best_state, history = 0.0, None, []
    for ep in range(epochs):
        model.train()
        for xb, yb in train_loader:
            xb = xb.to(device, non_blocking=True).to(memory_format=torch.channels_last)
            yb = yb.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=(device.type == "cuda")):
                loss = crit(model(xb), yb)
            scaler.scale(loss).backward()
            scaler.step(opt); scaler.update()
            sched.step()                         # OneCycle steps PER BATCH

        va_loss, va_acc = evaluate(model, val_loader, crit, device)
        history.append((ep, va_loss, va_acc, sched.get_last_lr()[0]))
        if va_acc > best_acc:
            best_acc = va_acc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)
    _, test_acc = evaluate(model, test_loader, crit, device)   # touched ONCE
    return test_acc, history, model


results = [run(s, augment=True)[0] for s in (0, 1, 2)]
print(f"with augmentation:    {np.mean(results)*100:.2f} ± {np.std(results)*100:.2f}")

ablation = [run(s, augment=False)[0] for s in (0, 1, 2)]
print(f"without augmentation: {np.mean(ablation)*100:.2f} ± {np.std(ablation)*100:.2f}")
```

**Expected results and what to write about them.** With augmentation you should see about 94–95%; without it, about 87–89% with an obvious overfitting signature (training accuracy near 100% by epoch 15 while validation stalls). That 5–7 point gap is the headline of your report: augmentation is worth more than any architectural tweak at this scale.

The confusion matrix will show cat↔dog as the dominant error pair, with automobile↔truck second. Both are semantically close classes with similar textures and shapes at 32×32 resolution — a resolution limitation as much as a model limitation. Saying that, rather than "the model needs more layers," is what distinguishes a good report.

```python
# Confusion matrix without extra dependencies
@torch.no_grad()
def confusion(model, loader, n_classes=10):
    model.eval()
    cm = torch.zeros(n_classes, n_classes, dtype=torch.long)
    for xb, yb in loader:
        pred = model(xb.to(device)).argmax(1).cpu()
        for t, p in zip(yb, pred):
            cm[t, p] += 1
    return cm
```

### Assignment 3 — Transfer learning on a small dataset (applied judgement)

**Task.** Take a small image dataset with 5–20 classes and no more than \~200 images per class — Oxford Flowers-102, Oxford-IIIT Pet, Food-101 subsampled, or your own photographs. Build the best classifier you can, and justify every choice.

**Requirements**

1. Compare three regimes on the same split: train from scratch, freeze the backbone and train only the head, and full fine-tuning with discriminative learning rates.
2. Use the checkpoint's own preprocessing via `weights.transforms()`.
3. Report per-class precision, recall and F1, not just accuracy.
4. Show five misclassified images with predicted and true labels, and explain the failures.
5. Measure inference latency per image on CPU, and again after `torch.compile` or half precision.
6. Discuss: at what dataset size would you switch strategies, and why?

**Rubric:** all three regimes compared fairly (25) · correct preprocessing and no leakage (20) · per-class metrics and error analysis (25) · latency measurement done correctly, with synchronisation and warm-up (15) · written justification (15).

**Reference solution — the core**

```python
from torchvision.models import resnet18, ResNet18_Weights

def make_model(mode, n_classes):
    """mode: 'scratch' | 'frozen' | 'finetune'"""
    if mode == "scratch":
        m = resnet18(weights=None, num_classes=n_classes)
        params = [{"params": m.parameters(), "lr": 1e-3}]
        return m, params

    m = resnet18(weights=ResNet18_Weights.IMAGENET1K_V1)   # pinned, reproducible
    m.fc = nn.Linear(m.fc.in_features, n_classes)

    if mode == "frozen":
        for name, p in m.named_parameters():
            p.requires_grad = name.startswith("fc.")
        params = [{"params": m.fc.parameters(), "lr": 1e-3}]
    else:                                                   # finetune
        backbone = [p for n, p in m.named_parameters() if not n.startswith("fc.")]
        params = [{"params": backbone,          "lr": 1e-4},
                  {"params": m.fc.parameters(), "lr": 1e-3}]
    return m, params


def freeze_bn_stats(model):
    """Call after model.train() when the backbone is frozen."""
    for mod in model.modules():
        if isinstance(mod, nn.modules.batchnorm._BatchNorm):
            mod.eval()


# preprocessing comes FROM the checkpoint
weights = ResNet18_Weights.IMAGENET1K_V1
eval_tf = weights.transforms()
train_tf = v2.Compose([
    v2.RandomResizedCrop(224, scale=(0.5, 1.0)),
    v2.RandomHorizontalFlip(),
    v2.TrivialAugmentWide(),
    v2.ToImage(), v2.ToDtype(torch.float32, scale=True),
    v2.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
])
```

**Per-class metrics without scikit-learn**

```python
def prf(cm):
    tp = cm.diag().float()
    precision = tp / cm.sum(0).clamp_min(1)     # column sums = predicted counts
    recall    = tp / cm.sum(1).clamp_min(1)     # row sums    = true counts
    f1 = 2 * precision * recall / (precision + recall).clamp_min(1e-12)
    return precision, recall, f1
```

**Latency, measured correctly**

```python
import time

def latency(model, device, n=100, shape=(1, 3, 224, 224)):
    model.eval().to(device)
    x = torch.randn(*shape, device=device)
    with torch.inference_mode():
        for _ in range(10):            # warm-up: cuDNN autotune, memory pool, JIT
            model(x)
        if device.type == "cuda":
            torch.cuda.synchronize()
        t0 = time.perf_counter()
        for _ in range(n):
            model(x)
        if device.type == "cuda":
            torch.cuda.synchronize()
    return (time.perf_counter() - t0) / n * 1000      # ms per image
```

**Expected findings, and the discussion to write.** On roughly 100 images per class you should see something like: scratch 45–60%, frozen backbone 80–88%, full fine-tuning 88–94%. The ordering is the point. Training from scratch fails because ImageNet-scale features cannot be learned from a few thousand images. The frozen backbone works surprisingly well because early-layer features are close to universal. Full fine-tuning wins when the low learning rate on the backbone prevents catastrophic forgetting.

The switching rule to defend: freeze below roughly 1,000 images total; fine-tune above; consider training from scratch only past tens of thousands of images, or when the domain (medical, satellite, spectrograms) is so far from natural images that ImageNet features transfer poorly — and even then, fine-tuning usually still beats scratch because the low-level filters remain useful.

For the error analysis, do not just list the mistakes. Group them: are the failures visually ambiguous even to you, mislabelled ground truth, or systematic (one class always losing to another)? Each diagnosis implies a different fix — more data, label cleaning, or class-specific augmentation.

## 16. Interview questions with model answers

Targeted at ML/DL engineer roles. Answer out loud before reading. A good answer is 30–60 seconds; the extra detail here is what you draw on when they follow up.

Where it helps, a ⚠️ line shows the **weak** version of the answer — usually true, but the kind of reply that ends the topic instead of opening it. The difference between the two is almost always a concrete mechanism, a number, or a consequence.

### A. Rapid-fire PyTorch

**A1. `view` vs `reshape`?**

> `view` returns a zero-copy view and raises if the requested shape is incompatible with the existing strides. `reshape` returns a view when possible and copies otherwise. Use `reshape` unless you need the no-copy guarantee.

**A2. `cat` vs `stack`?**

> `cat` joins along an existing dimension; all other dimensions must match; the rank is unchanged. `stack` requires identical shapes and adds a new dimension. Batching `N` tensors of shape `(3,224,224)` into `(N,3,224,224)` is `stack`.

**A3. What does `squeeze()` do, and why is it risky?**

> Removes all size-1 dimensions. Risky because a batch of size 1 loses its batch dimension and downstream code silently misinterprets the shape. Always pass an explicit `dim`.

**A4. `.detach()` vs `.data` vs `torch.no_grad()`?**

> `.detach()` returns a tensor sharing storage but excluded from the graph — the correct tool. `.data` is a legacy attribute that bypasses autograd's version counter and can produce silently wrong gradients; avoid it. `no_grad()` is a context manager that disables graph construction for everything inside it.

**A5. `model.eval()` vs `torch.no_grad()`?**

> `eval()` changes layer behaviour (Dropout off, BatchNorm uses running statistics). `no_grad()` disables gradient tracking. They are orthogonal; validation needs both.

**A6. Why does `optimizer.zero_grad()` exist?**

> `backward()` accumulates into `.grad` rather than overwriting. That is intentional — it enables gradient accumulation, multi-loss training, and parameters used more than once — so the caller must clear explicitly.

**A7. Parameter vs buffer?**

> Both are saved in `state_dict` and moved by `.to(device)`. Parameters appear in `parameters()` and are updated by the optimizer; buffers are not. BatchNorm's running statistics are the canonical buffers.

**A8. What breaks if you put layers in a Python list?**

> They are not registered: `parameters()` misses them, the optimizer never updates them, and `.to(device)` leaves them behind. Use `nn.ModuleList`.

**A9. `nn.ReLU()` vs `F.relu()`?**

> Functionally identical. The module version appears in `print(model)`, supports hooks, and is visible to tooling. Use modules for anything stateful; either for pure functions.

**A10. Why `model(x)` and not `model.forward(x)`?**

> `__call__` runs registered pre/post hooks and internal bookkeeping before dispatching to `forward`. Bypassing it breaks hooks, profiling, quantisation and some compilation paths.

**A11. What does `nn.Linear(784, 256).weight.shape` return, and why?**

> `(256, 784)` — output-first. The forward pass computes `x @ W.T`, and this layout is what the underlying GEMM prefers.

**A12. `num_workers=0` vs `4`?**

> `0` loads in the main process — simpler, debuggable, and slower. `>0` spawns subprocesses that prepare batches ahead of time. Use `0` while debugging; tune upward until GPU utilisation is high.

**A13. What is `pin_memory`?**

> Allocates page-locked host memory, which enables genuinely asynchronous DMA transfers to the GPU. Pair it with `.to(device, non_blocking=True)`. Meaningless without CUDA.

**A14. `torch.save(model)` vs `torch.save(model.state_dict())`?**

> The first pickles a class reference and breaks when code moves or versions change. The second is a portable dictionary of tensors. Always the second.

**A15. What is `torch.compile` and when would you skip it?**

> A PyTorch 2.x compiler that traces the model and emits fused kernels, typically giving 1.2–2×. Skip it while actively debugging, when input shapes change constantly (recompilation), and when the model has heavy data-dependent Python control flow (graph breaks).

### B. Autograd

**B1. Explain autograd in two minutes.**

> PyTorch builds a dynamic computational graph during the forward pass — each output tensor stores a `grad_fn` pointing at the operation that created it and the inputs it needs. `backward()` on a scalar traverses this graph in reverse topological order, applying each operation's local derivative via the chain rule, and accumulates results into the `.grad` of leaf tensors that require gradients. The graph is rebuilt every iteration, so ordinary Python control flow is differentiable.

> ⚠️ Weak version: *"Autograd automatically computes gradients for you so you don't have to do calculus."* True, and it tells the interviewer nothing. The strong answer names the mechanism — a graph built during the forward pass, `grad_fn`, reverse topological traversal, accumulation into leaves — and the consequence: because the graph is rebuilt every iteration, Python control flow is differentiable.

**B2. Why must the output be a scalar?**

> Reverse-mode AD computes a vector–Jacobian product `vᵀJ`, and `v` has to come from somewhere. For a scalar, `v = 1` is the only sensible choice, so PyTorch supplies it. Otherwise you pass `v` explicitly.

**B3. Forward-mode vs reverse-mode AD — when is each better?**

> Reverse mode costs one pass per *output*; forward mode costs one pass per *input*. Deep learning has millions of inputs (parameters) and one output (loss), so reverse mode wins overwhelmingly. Forward mode is better for functions with few inputs and many outputs, and PyTorch supports it via `torch.func.jvp`.

**B4. What is a leaf tensor?**

> A tensor not produced by a tracked operation — created directly by the user. Only leaves accumulate `.grad`. `torch.randn(3, requires_grad=True).cuda()` is *not* a leaf, which is a classic bug.

**B5. When does an in-place operation break backward?**

> When the overwritten tensor is needed to compute a gradient. `exp`'s derivative is its own output, so modifying that output in place breaks it. `relu`'s derivative depends only on the sign, which survives, so `inplace=True` is safe there. PyTorch detects violations with a version counter and raises.

**B6. How would you freeze half a network?**

> Set `requires_grad=False` on those parameters, and exclude them from the optimizer. Additionally put any BatchNorm layers into `eval()` mode, because their running statistics are buffers that keep updating regardless of `requires_grad`.

**B7. When do you need `retain_graph=True`?**

> When you call `backward()` twice through the same graph — for example a GAN where one forward pass feeds two losses that are stepped separately. Usually its appearance signals a different bug: reusing a tensor computed outside the loop.

**B8. How do you get second-order gradients?**

> `torch.autograd.grad(..., create_graph=True)` makes the backward pass itself differentiable, so you can differentiate the gradient. Used in gradient penalties (WGAN-GP) and meta-learning (MAML). It is expensive in memory.

### C. CNNs and architectures

**C1. Why convolutions for images?**

> Locality (features are local), weight sharing giving translation equivariance (a detector is useful everywhere), and hierarchical composition. Together they cut parameters by orders of magnitude *and* encode a correct prior about images — an MLP would have to learn translation invariance from data.

**C2. Output shape formula.**

> `H_out = floor((H_in + 2P − D(K−1) − 1)/S) + 1`. For "same" size at stride 1, `P = (K−1)/2`.

**C3. Parameters in `Conv2d(64, 128, 3)`?**

> `128 · 64 · 3 · 3 + 128 = 73,856`. Independent of spatial size.

**C4. Two 3×3 vs one 5×5?**

> Same 5×5 receptive field, `18C²` vs `25C²` parameters, and an extra nonlinearity. VGG's core argument.

**C5. What does a 1×1 convolution do?**

> A per-pixel linear map across channels. Changes channel count cheaply, adds nonlinearity, and mixes channel information. The basis of bottleneck blocks and of the pointwise half of depthwise-separable convolution.

**C6. Why do residual connections help?**

> They make the identity easy to represent, so adding depth cannot hurt the trainable optimum — which addresses the degradation problem. And `∂y/∂x = ∂F/∂x + 1` gives gradients an unattenuated path to early layers.

> ⚠️ Weak version: *"They let gradients flow so you can train deeper networks."* Half the story, and it skips the question the paper actually asked. The strong answer starts from the degradation problem — deeper plain networks had higher *training* error, so this was an optimisation failure and not overfitting — then gives the two reasons: the identity becomes trivially representable, and `∂y/∂x = ∂F/∂x + 1` guarantees an unattenuated gradient path.

**C7. BatchNorm: what, and why train/eval differ?**

> Normalises each channel using mean and variance over the batch and spatial dimensions, then applies a learned scale and shift. In training it uses batch statistics and updates running estimates; in eval it uses the running estimates, so inference is deterministic and works for a single sample.

**C8. When would you not use BatchNorm?**

> Small batch sizes (below \~8–16), where batch statistics are too noisy — use GroupNorm. Sequence models with variable lengths and padding — use LayerNorm. Style transfer and some generative models — InstanceNorm. Online/streaming inference where batches do not exist.

**C9. Why `bias=False` before BatchNorm?**

> BN subtracts the mean, cancelling any constant the convolution bias added. The bias is a no-op; BN's `β` does that job.

**C10. Depthwise separable convolution — what and why?**

> A per-channel spatial convolution followed by a 1×1 channel mix. Cost drops by roughly `1/C_out + 1/K²` — about 8–9× for 3×3 — with a modest accuracy loss. The foundation of MobileNet and of efficient on-device vision.

**C11. Global average pooling vs flatten-then-Linear?**

> GAP produces a fixed-size vector regardless of input resolution, has zero parameters, regularises by forcing each channel to be a class-evidence score, and enables class activation maps. Flattening locks the input size and, in VGG, accounts for most of the parameters.

**C12. CNN or Vision Transformer in 2026?**

> ViTs have weaker inductive biases, so they need much more data or strong augmentation and pretraining, but they scale better and dominate at very large scale. Convolutional backbones remain the pragmatic default at ordinary data scales: cheaper to train, better out of the box on small datasets, and easier to deploy. In practice: start from a pretrained ResNet or ConvNeXt, and reach for a pretrained ViT if you have the data or a strong pretrained checkpoint for your domain.

**C13. Why do we need activation functions at all?**

> Without one, stacked linear layers collapse: `W₂(W₁x+b₁)+b₂ = (W₂W₁)x + (W₂b₁+b₂)`, a single affine map. Depth adds parameters and optimisation difficulty but no expressive power. The nonlinearity is what makes each additional layer able to represent something the previous one could not.

**C14. Why ReLU rather than sigmoid in hidden layers?**

> Sigmoid's derivative peaks at 0.25 and collapses toward zero away from the origin, so backpropagation multiplies a shrinking factor per layer and the signal decays geometrically with depth. Measured on a 10-layer MLP, the first layer's gradient norm is about `3e-07` while the last layer's is about `370` — a factor of a billion — so early layers are effectively frozen. Sigmoid's output is also strictly positive, so all gradients into a weight row share a sign and the optimiser zig-zags. ReLU has derivative exactly 1 on the active path, is one comparison to compute, and produces useful sparsity.

**C15. What is dying ReLU, and how do you detect and fix it?**

> A unit whose pre-activation is negative for every input outputs zero and receives exactly zero gradient forever — a fixed point, not a slow region. Detect it by hooking activations and reporting the fraction of units that never fire across the validation set; above roughly 40% in a layer is a problem. Fix by lowering the learning rate, adding normalisation, or switching to LeakyReLU or GELU.

**C16. GELU versus ReLU — when does it matter?**

> GELU is `z·Φ(z)`, a smooth probabilistic gate rather than a hard cut-off, and it is the default in transformers. Empirically it gives a small consistent gain on large models and makes essentially no difference on small CNNs. The honest answer is that activation choice is one of the lowest-leverage knobs available — normalisation, data and the learning-rate schedule matter far more.

### D. Training and debugging scenarios

**D1. "The loss isn't going down." Walk me through your process.**

> Check shapes and label dtypes/ranges. Check the initial loss equals `ln(C)`. Try to overfit a single batch of 8 to near-zero loss — if that fails, the bug is in the model or loss, not the data or hyperparameters. Verify gradients are non-`None` and non-zero after `backward()`. Confirm `zero_grad` is present and `optimizer.step()` is being called. Then sweep the learning rate over a few orders of magnitude. **The single-batch overfit test is the one to lead with.**

> ⚠️ Weak version: *"I'd try a lower learning rate, then a bigger model, then more data."* This is guessing dressed as a plan, and it is what most candidates say. The strong answer is an ordered diagnostic that *localises* the fault before changing anything, and it leads with the single-batch overfit test because that one test partitions the space: if a batch of 8 cannot reach zero loss, the bug is in the model or the loss and no amount of hyperparameter tuning will help.

**D2. Training loss 0.01, validation loss 2.5. What do you do?**

> Severe overfitting. In order: more and stronger augmentation, weight decay, dropout in the classifier, early stopping, a smaller model, more data, transfer learning. First verify it is not a leak or a distribution mismatch between splits.

**D3. Loss becomes NaN at epoch 3.**

> Most likely learning rate too high. Then: `log`/`sqrt`/division without an epsilon, fp16 overflow, unnormalised inputs, NaNs already in the data. Diagnose by lowering the LR, adding gradient clipping, checking `torch.isfinite` on inputs and gradients, and `set_detect_anomaly(True)` temporarily.

**D4. Validation accuracy is much worse than training even with heavy regularisation — but only after you added a validation pass mid-epoch.**

> You almost certainly forgot `model.train()` after the validation call, so Dropout and BatchNorm stayed in inference mode for the remainder of training.

**D5. CUDA out of memory at epoch 5, not epoch 1.**

> Something is accumulating. Classic causes: `total_loss += loss` without `.item()`, storing predictions without `.detach()`, or a validation loop missing `torch.no_grad()`. Memory fragmentation is also possible but far less likely than a graph leak.

**D6. Your model gets 95% offline and 70% in production.**

> Preprocessing mismatch first — resize/crop, channel order, normalisation constants, image decoding library. Then `model.eval()` not being called. Then distribution shift between the collected data and live traffic. Then a genuine leak in the offline evaluation (test data used during selection).

**D7. How do you pick a learning rate?**

> Run an LR range test: a few hundred iterations with the learning rate multiplied geometrically from `1e-7` to `10`, plot loss against log-LR, and pick roughly an order of magnitude below the steepest-descent point. Sanity checks: divergence means too high; a flat curve means too low.

**D8. Batch size 32 → 256. What else changes?**

> Scale the learning rate roughly linearly (or by `√k` for adaptive optimizers) and add warmup, since early large-batch steps are unstable. Expect slightly worse generalisation for the same number of epochs, and note that BatchNorm's regularising noise weakens with larger batches. Gradient accumulation gets you the large effective batch without the memory, but BN statistics still come from the physical batch.

**D9. How do you know an improvement is real?**

> Run 3–5 seeds and report mean ± standard deviation. A gap of a few tenths of a percent on CIFAR-scale data is usually seed noise. Also hold the test set out of all decisions and change one thing at a time.

**D10. Your dataset is 99% negative. What do you do?**

> Stop using accuracy — report precision/recall, F1, PR-AUC. Then some combination of: `pos_weight` in `BCEWithLogitsLoss`, `WeightedRandomSampler`, focal loss, and threshold tuning on the validation set. Also check whether the problem is better framed as anomaly detection, and whether more negatives even help.

**D11. What metric would you use, and why?**

> The question is really "what does a mistake cost?" Accuracy is correct only for balanced classes with symmetric error costs. Under imbalance, report per-class precision and recall, macro-F1, and PR-AUC rather than ROC-AUC — the false-positive rate has a huge denominator when negatives dominate, so ROC-AUC flatters. Optimise recall when misses are expensive (screening), precision when false alarms are expensive (spam). And always report the trivial baseline next to the number.

**D12. Your model has AUC 0.95 but the product team says its confidence scores are useless. What is going on?**

> Ranking and calibration are different properties. AUC measures only whether positives are ranked above negatives; it is invariant to any monotonic transform of the scores, so a model can rank perfectly while being systematically overconfident. Check calibration by binning predictions and comparing mean predicted probability against observed frequency per bin. Fix with temperature scaling on a validation set, or label smoothing during training.

**D13. When is macro-averaging the wrong choice?**

> When a rare class is rare *because it genuinely does not matter much*, or when its support is so small (a handful of samples) that its per-class F1 is dominated by noise and swamps the macro mean. In those cases weighted averaging or explicitly reporting per-class numbers is more honest than either aggregate.

### E. Spot the bug

**E1.**

```python
for xb, yb in loader:
    preds = model(xb)
    loss = criterion(preds, yb)
    loss.backward()
    optimizer.step()
```

> Missing `optimizer.zero_grad()`. Gradients accumulate across every batch, so the effective step grows without bound and training diverges.

**E2.**

```python
class Net(nn.Module):
    def __init__(self):
        super().__init__()
        self.layers = [nn.Linear(10, 10), nn.Linear(10, 10)]
```

> A plain list. Nothing is registered, `parameters()` is empty, the optimizer updates nothing, and `.to(device)` leaves the layers on CPU. Use `nn.ModuleList`.

**E3.**

```python
def forward(self, x):
    x = self.fc(x)
    return torch.softmax(x, dim=1)

criterion = nn.CrossEntropyLoss()
```

> Double softmax. `CrossEntropyLoss` applies log-softmax internally. Return raw logits. The model still trains, just worse — which is why this bug survives code review.

**E4.**

```python
model.eval()
for xb, yb in val_loader:
    preds = model(xb)
    val_loss += criterion(preds, yb)
```

> Two bugs. No `torch.no_grad()`, so graphs are built during validation — wasted memory, eventually OOM. And `val_loss += criterion(...)` accumulates tensors rather than floats, keeping every graph alive. Use `.item()`.

**E5.**

```python
train_ds, val_ds = random_split(dataset, [45000, 5000])
# dataset was built with transform=train_transform (random crop + flip)
```

> The validation subset inherits the training augmentation, making validation metrics noisy and optimistic-looking in the wrong way. Split indices and index two dataset objects carrying different transforms.

**E6.**

```python
best_state = None
for epoch in range(epochs):
    ...
    if val_acc > best_acc:
        best_acc, best_state = val_acc, model.state_dict()
model.load_state_dict(best_state)
```

> `state_dict()` returns references to the live tensors, which keep changing. You restore the final model, not the best one. Snapshot with `{k: v.detach().cpu().clone() for k, v in model.state_dict().items()}`.

### F. Coding-round problems

**F1. Implement `nn.Linear` from scratch.** See §4.9. Mention the `(out, in)` weight layout and `register_parameter("bias", None)` for the no-bias case.

**F2. Implement 2-D convolution with loops, then verify against `F.conv2d`.**

```python
def conv2d_naive(x, w, b=None, stride=1, padding=0):
    B, Cin, H, W = x.shape
    Cout, _, KH, KW = w.shape
    x = F.pad(x, (padding,) * 4)
    H_out = (H + 2 * padding - KH) // stride + 1
    W_out = (W + 2 * padding - KW) // stride + 1
    out = torch.zeros(B, Cout, H_out, W_out, dtype=x.dtype)
    for i in range(H_out):
        for j in range(W_out):
            patch = x[:, :, i*stride:i*stride+KH, j*stride:j*stride+KW]   # (B,Cin,KH,KW)
            out[:, :, i, j] = torch.einsum("bchw,ochw->bo", patch, w)
    if b is not None:
        out += b.view(1, -1, 1, 1)
    return out

x, w, b = torch.randn(2,3,8,8), torch.randn(4,3,3,3), torch.randn(4)
assert torch.allclose(conv2d_naive(x, w, b, 1, 1), F.conv2d(x, w, b, 1, 1), atol=1e-5)
```

> The `einsum` contracts channel and kernel dimensions at once. A follow-up they may ask: rewrite it with `unfold` (im2col) and a single matrix multiply.

**F3. Implement batch normalisation from scratch, both modes.**

```python
class MyBatchNorm2d(nn.Module):
    def __init__(self, C, eps=1e-5, momentum=0.1):
        super().__init__()
        self.eps, self.momentum = eps, momentum
        self.weight = nn.Parameter(torch.ones(C))
        self.bias   = nn.Parameter(torch.zeros(C))
        self.register_buffer("running_mean", torch.zeros(C))
        self.register_buffer("running_var",  torch.ones(C))

    def forward(self, x):
        if self.training:
            mean = x.mean(dim=(0, 2, 3))
            var  = x.var(dim=(0, 2, 3), unbiased=False)      # biased for normalising
            with torch.no_grad():
                n = x.numel() / x.size(1)
                self.running_mean.mul_(1 - self.momentum).add_(self.momentum * mean)
                self.running_var.mul_(1 - self.momentum).add_(
                    self.momentum * var * n / (n - 1))       # unbiased for the buffer
        else:
            mean, var = self.running_mean, self.running_var
        x = (x - mean[None, :, None, None]) / (var[None, :, None, None] + self.eps).sqrt()
        return x * self.weight[None, :, None, None] + self.bias[None, :, None, None]
```

> The biased/unbiased distinction and the `no_grad` around the buffer update are the details that separate a correct answer from a passable one.

**F4. Implement a training loop with gradient accumulation and mixed precision.** See §11.4 and §11.5. Say the `/ACCUM` out loud.

**F5. Implement top-k accuracy.**

```python
@torch.no_grad()
def topk_accuracy(logits, target, ks=(1, 5)):
    maxk = max(ks)
    _, pred = logits.topk(maxk, dim=1)          # (B, maxk)
    correct = pred.eq(target.view(-1, 1))       # broadcast compare
    return {k: correct[:, :k].any(dim=1).float().mean().item() for k in ks}
```

**F6. Implement a custom collate function for variable-length sequences.** See §5.3. Mention padding to the batch maximum and returning lengths for masking.

### G. Applied judgement

**G1. You have 500 labelled images across 5 classes. Design the system.**

> Transfer learning from an ImageNet-pretrained backbone, almost certainly. Given 100 images per class, freeze the backbone and train the head first, then unfreeze with a low backbone learning rate. Heavy augmentation. Stratified k-fold cross-validation rather than a single split, because a 20% validation set is only 100 images and the variance is enormous. Report per-class recall. Consider whether more labels or better labels is the cheaper win — at this scale, 500 more images beats any architecture change.

**G2. Model is 95% accurate but must run in 10 ms on a CPU. What now?**

> Measure first — where is the time going? Then, roughly in order of cost-effectiveness: a smaller architecture (MobileNet, EfficientNet-Lite), reduced input resolution, dynamic or static quantisation to int8, ONNX Runtime or OpenVINO instead of eager PyTorch, batching if the workload allows, and distillation from the large model into a small one. Quantify the accuracy cost of each and present the trade-off curve rather than a single choice.

**G3. How would you monitor this model in production?**

> Input distribution drift (per-feature or embedding-level statistics versus the training set), prediction distribution drift, confidence distribution, latency and error rates, and delayed ground-truth accuracy where labels eventually arrive. Alert on drift, sample flagged inputs for human review, and keep a held-out golden set that you re-evaluate on every deploy.

**G4. Your teammate reports a new architecture beats the baseline by 0.4%. What do you ask?**

> How many seeds, and what is the variance? Was the baseline tuned as carefully as the new model? Same data, same augmentation, same epoch budget, same parameter count? Was the test set used for any selection decision? Most reported gains of that size do not survive these four questions.

**G5. Explain gradient descent to a non-technical stakeholder.**

> The model makes a guess, we measure how wrong it is, and we work out which direction each of its internal settings should move to be a little less wrong. We take a small step in that direction and repeat, millions of times. The "learning rate" is how big those steps are: too big and we overshoot, too small and it takes forever. Being able to do this cleanly is tested more often than people expect.

## 17. FAQ — the questions students actually ask

**Do I need a GPU?** Not for this tutorial. Everything through Chapter 10 runs on a laptop CPU in minutes. Assignment 2 wants a GPU; Google Colab's free tier is sufficient, and Kaggle Notebooks gives longer sessions. Do not buy hardware until you have hit a wall you can name.

**PyTorch or TensorFlow — which should I learn?** Learn PyTorch. It dominates research and has become the default in industry too; most new models ship PyTorch first. The concepts transfer, so learning the second framework later is a weekend, not a semester. If a specific employer uses JAX or TensorFlow, learn it then.

**Should I use PyTorch Lightning, fastai, or plain PyTorch?** Learn plain PyTorch first, thoroughly. Frameworks hide exactly the mechanics you are interviewed on, and when something breaks inside a framework you need the underlying model anyway. Once you can write the loop from memory, Lightning is a reasonable productivity choice for real projects — it removes boilerplate around distributed training, logging and checkpointing without hiding the model.

**How much maths do I really need?** For an engineering role: comfort with matrix multiplication and shapes, partial derivatives and the chain rule, and basic probability. You should be able to derive the softmax cross-entropy gradient and reason about variance in initialisation. You do not need measure theory or convex optimisation. Depth of *intuition* about shapes and gradients matters far more than breadth of theory.

**My model trains but accuracy is terrible. Where do I start?** §7.7, in that exact order. Do not start by changing the architecture. The overfit-one-batch test localises the problem in five minutes, and the answer is nearly always a bug rather than a modelling choice.

**What batch size should I use?** The largest that fits comfortably in memory, commonly 32–256 for vision. Larger is faster per epoch but needs a higher learning rate and warmup, and slightly hurts generalisation for a fixed epoch budget. If memory is the binding constraint, use gradient accumulation. Powers of two are conventional and marginally better aligned for GPU kernels, but nothing catastrophic happens at 100.

**How many epochs?** Enough that validation loss stops improving. Use early stopping with patience rather than guessing. Typical ranges: 10–30 for fine-tuning, 50–200 for CIFAR from scratch, 90–300 for ImageNet. If validation loss is still falling when you stop, you stopped too early.

**How do I choose an architecture?** For almost any vision task: start with a pretrained ResNet-18 or ResNet-50 and get the pipeline working end to end. Only then consider alternatives, and change one thing at a time. Architecture is rarely the bottleneck for a student project — data quantity, data quality and the training recipe dominate.

**Why is my GPU only 30% utilised?** The input pipeline is starving it. More `num_workers`, `pin_memory=True`, smaller/pre-decoded images on disk, or caching. Run the data-only throughput test in §5.8 to confirm before changing anything else.

**Why do I get different results every run despite `torch.manual_seed`?** DataLoader workers need their own seeding (§5.7), cuDNN autotuning picks different algorithms, and some CUDA kernels are non-deterministic by design. See §12.3. Rather than chasing bitwise reproducibility, report mean ± std over several seeds.

**Should I normalise my images to \[0,1\] or standardise with mean/std?** Both, in that order: convert to float in \[0,1\], then subtract the mean and divide by the standard deviation. If you are using pretrained weights you must use *their* constants (§11.1).

**What is the difference between `torchvision.transforms` and `transforms.v2`?** v2 is the current API: faster, works on batched tensors, and transforms bounding boxes and masks consistently alongside images. Old tutorials use `ToTensor()`; the v2 equivalent is `ToImage()` then `ToDtype(torch.float32, scale=True)`. Use v2 in new code.

**When should I write a custom `autograd.Function`?** Almost never. Only when you need a gradient PyTorch cannot derive (calling external code), a numerically better gradient formula, or a deliberately *wrong* gradient (straight-through estimators, gradient reversal). Composing standard operations is differentiable already.

**How do I debug something that only fails on GPU?** Run it on CPU. CUDA errors are asynchronous and the reported line is often wrong; CPU gives an accurate traceback. If it only fails on GPU, set `CUDA_LAUNCH_BLOCKING=1` and re-run. The most common GPU-only failure is an out-of-range index, which on CPU raises a clear `IndexError` and on GPU raises "device-side assert triggered."

**Is `inplace=True` on ReLU worth it?** It saves activation memory, which can matter for large models, and is safe for ReLU specifically. It can cause autograd errors in more complex graphs — for example inside a residual block where the same tensor is used twice. If you hit an in-place error, turn it off first and investigate second.

**Why does my validation loss go up while accuracy also goes up?** This is normal and worth understanding. Cross-entropy penalises confident mistakes heavily. Late in training the model becomes more confident overall, so the few remaining errors contribute large losses even as the argmax gets more things right. If you care about accuracy, select on accuracy; if you care about calibrated probabilities, select on loss and consider label smoothing or temperature scaling.

**Can I use a pretrained model on grayscale / 4-channel / non-image data?** Yes, with a surgically replaced first layer (§11.3). For genuinely non-image data (spectrograms, time-frequency plots, some sensor data), ImageNet pretraining often still helps because low-level edge and texture filters are general. Measure it rather than assuming.

**How do I show this work to an employer?** One well-documented repository beats five notebooks. Include: a README with the result and how to reproduce it, a single command that trains the model, logged configs and seeds, a plot of training curves, an ablation table, and an honest limitations section. The limitations section is what senior engineers read first.

**Am I ready for interviews?** You are ready when you can, without notes: write the training loop; explain autograd including why the output must be scalar; derive a convolution output shape and parameter count; implement a residual block; explain `eval()` versus `no_grad()`; and describe your debugging procedure for a model that will not learn. Chapter 16 is the checklist.

**What should I learn next?** In rough order of usefulness for an industry ML engineer: sequence models and the transformer architecture (attention, positional encoding, LayerNorm — Chapter 9 already gave you the normalisation half); object detection and segmentation if you are doing vision; distributed training with `DistributedDataParallel`; experiment tracking and reproducible pipelines; and model serving. Implementing multi-head self-attention from scratch is the natural next exercise after this tutorial, and it reuses everything in Chapters 2 and 4.

## 18. Cheat sheet, glossary and further reading

### 18.1 The formulas to have memorised

```
Conv/pool output size:
    H_out = floor( (H_in + 2P − D(K−1) − 1) / S ) + 1
    "same" size at stride 1, odd K:  P = (K−1)/2

Conv2d parameters:            C_out · C_in · K · K  (+ C_out if bias)
Linear parameters:            in · out (+ out if bias)
BatchNorm2d(C) parameters:    2C  (plus 2C+1 buffers)

Receptive field:              j_0 = 1, r_0 = 1
                              j_l = j_{l−1} · S_l
                              r_l = r_{l−1} + (K_l − 1) · j_{l−1}

Softmax cross-entropy grad:   ∂L/∂z = (softmax(z) − onehot(y)) / B
Stable log-softmax:           z_i − max(z) − log Σ_j exp(z_j − max(z))
Initial CE loss, C classes:   ≈ ln(C)      (2.303 for 10, 6.908 for 1000)

Initialisation variance:      Var(z) = n_in · Var(w) · Var(x)
    Xavier (tanh-like):       Var(w) = 1/n_in     (or 2/(n_in+n_out))
    Kaiming (ReLU):           Var(w) = 2/n_in     (ReLU halves the variance)

Sigmoid derivative:           σ'(z) = σ(z)(1−σ(z)),  max 0.25 at z = 0
tanh derivative:              max 1.0 at z = 0
ReLU derivative:              1 if z > 0 else 0

Metrics, from the confusion matrix:
    precision_c = TP_c / (TP_c + FP_c)      column sum = predicted as c
    recall_c    = TP_c / (TP_c + FN_c)      row sum    = truly c
    F1_c        = 2·P·R / (P + R)
    macro-F1    = unweighted mean over classes  (use under imbalance)
    baseline    = majority-class rate           (ALWAYS report it)

Training memory:              params + grads + optimizer state + activations
                              SGD+momentum state = 1× params
                              AdamW state        = 2× params
```

### 18.2 API cheat sheet

```python
# --- creation ---------------------------------------------------------------
torch.tensor(data)            torch.zeros/ones/full/empty(shape)
torch.arange/linspace(...)    torch.rand/randn/randint(...)
torch.zeros_like(t)           torch.randn_like(t)

# --- shape ------------------------------------------------------------------
t.shape  t.dtype  t.device  t.ndim  t.numel()
t.reshape(...)  t.view(...)  t.flatten(start_dim=1)
t.permute(...)  t.transpose(a, b)  t.unsqueeze(d)  t.squeeze(d)
torch.cat(ts, dim)  torch.stack(ts, dim)  torch.chunk/split(t, n, dim)
t.contiguous()  t.is_contiguous()  t.stride()

# --- maths ------------------------------------------------------------------
A @ B   torch.matmul  torch.bmm  torch.einsum("ij,jk->ik", A, B)
t.sum/mean/max/min/std(dim=, keepdim=)   t.argmax(dim)  t.topk(k, dim)
t.gather(dim, idx)  torch.index_select(t, dim, idx)  t.masked_fill(mask, v)

# --- autograd ---------------------------------------------------------------
t.requires_grad_(True)   loss.backward()   p.grad
with torch.no_grad(): ...        @torch.inference_mode()
t.detach()   torch.autograd.grad(y, x, create_graph=True)

# --- modules ----------------------------------------------------------------
nn.Linear  nn.Conv2d  nn.BatchNorm2d  nn.LayerNorm  nn.GroupNorm
nn.ReLU  nn.GELU  nn.Dropout  nn.MaxPool2d  nn.AdaptiveAvgPool2d  nn.Flatten
nn.Sequential  nn.ModuleList  nn.ModuleDict  nn.Identity
m.parameters()  m.named_parameters()  m.buffers()  m.modules()  m.apply(fn)
m.train()  m.eval()  m.to(device)  m.state_dict()  m.load_state_dict(sd)
m.register_buffer(name, t)  m.register_forward_hook(fn)

# --- data -------------------------------------------------------------------
Dataset: __len__, __getitem__      IterableDataset: __iter__
DataLoader(ds, batch_size, shuffle, num_workers, pin_memory, drop_last,
           collate_fn, sampler, persistent_workers)
random_split  Subset  WeightedRandomSampler

# --- losses & optim ---------------------------------------------------------
nn.CrossEntropyLoss(weight=, label_smoothing=, ignore_index=, reduction=)
nn.BCEWithLogitsLoss(pos_weight=)   nn.MSELoss  nn.L1Loss  nn.HuberLoss
torch.optim.SGD(params, lr, momentum, weight_decay, nesterov)
torch.optim.AdamW(params, lr, betas, weight_decay)
lr_scheduler.CosineAnnealingLR / OneCycleLR / ReduceLROnPlateau / SequentialLR
torch.nn.utils.clip_grad_norm_(params, max_norm)

# --- amp, compile, io -------------------------------------------------------
torch.amp.autocast("cuda", dtype=torch.bfloat16)   torch.amp.GradScaler("cuda")
torch.compile(model)
torch.save(obj, path)   torch.load(path, map_location="cpu", weights_only=True)
torch.jit.trace/script   torch.onnx.export
```

### 18.3 A training script skeleton to start every project from

```python
import torch, torch.nn as nn

def main():
    torch.manual_seed(cfg.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    train_loader, val_loader, test_loader = build_loaders(cfg)
    model = build_model(cfg).to(device)
    criterion = nn.CrossEntropyLoss(label_smoothing=cfg.smoothing)
    optimizer = build_optimizer(model, cfg)          # param groups, no decay on norms
    scheduler = build_scheduler(optimizer, cfg, len(train_loader))
    scaler = torch.amp.GradScaler("cuda", enabled=cfg.amp)

    best, bad = float("inf"), 0
    for epoch in range(cfg.epochs):
        model.train()
        for xb, yb in train_loader:
            xb, yb = xb.to(device, non_blocking=True), yb.to(device, non_blocking=True)
            optimizer.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=cfg.amp):
                loss = criterion(model(xb), yb)
            scaler.scale(loss).backward()
            scaler.step(optimizer); scaler.update()
            if cfg.step_per_batch:
                scheduler.step()
        if not cfg.step_per_batch:
            scheduler.step()

        val_loss, val_acc = evaluate(model, val_loader, criterion, device)
        log(epoch, val_loss, val_acc, scheduler.get_last_lr()[0])

        if val_loss < best:
            best, bad = val_loss, 0
            save_checkpoint(model, optimizer, scheduler, scaler, epoch, cfg)
        else:
            bad += 1
            if bad >= cfg.patience:
                break

    load_best(model)
    print(evaluate(model, test_loader, criterion, device))   # touched exactly once

if __name__ == "__main__":      # required for num_workers > 0 on Windows/macOS spawn
    main()
```

### 18.4 Glossary

| Term | Meaning |
| --- | --- |
| Activation | The output of a layer; also the nonlinearity itself (ReLU, GELU) |
| Autograd | PyTorch's reverse-mode automatic differentiation engine |
| Batch | A group of samples processed together in one forward/backward pass |
| Broadcasting | Automatic expansion of size-1 dimensions so shapes align |
| Buffer | A tensor saved and moved with a module but not trained |
| Calibration | Whether predicted probabilities match observed frequencies |
| Contiguous | Elements laid out in row-major order in the underlying storage |
| Dead ReLU | A unit negative for all inputs, receiving permanently zero gradient |
| Epoch | One pass over the training dataset |
| Equivariance | Shifting the input shifts the output correspondingly (convolution) |
| Invariance | The output is unchanged by the transformation (pooling, approximately) |
| Leaf tensor | A tensor created by the user rather than by a tracked operation |
| Logits | Raw unnormalised scores, before softmax or sigmoid |
| Macro average | Unweighted mean of a metric across classes; rare classes count fully |
| Micro average | Metric computed from pooled counts; dominated by common classes |
| Precision | Of what we predicted positive, the fraction that truly was |
| Recall | Of what truly was positive, the fraction we caught |
| Receptive field | The input region that can influence a given unit |
| Saturation | An activation in a flat region, where the local derivative is ≈ 0 |
| Stride (tensor) | Elements skipped in storage to advance one step along a dimension |
| Stride (conv) | Step size of the sliding kernel |
| `state_dict` | Dictionary mapping names to parameter and buffer tensors |
| VJP | Vector–Jacobian product, what one backward pass computes |

### 18.5 Further reading

**Primary documentation.** The [PyTorch documentation](https://pytorch.org/docs/stable/index.html) and [official tutorials](https://pytorch.org/tutorials/) are excellent and should be your first stop. `help(torch.nn.Conv2d)` in a REPL is authoritative for your exact installed version, which matters when APIs change.

**Papers worth reading in full.** Each is short and repays the effort:

| Paper | Link | Why |
| --- | --- | --- |
| Very Deep Convolutional Networks (VGG), 2014 | [arXiv:1409.1556](https://arxiv.org/abs/1409.1556) | The stacked-3×3 argument, cleanly made |
| Batch Normalization, 2015 | [arXiv:1502.03167](https://arxiv.org/abs/1502.03167) | The original (and now disputed) motivation |
| Delving Deep into Rectifiers (PReLU, He init), 2015 | [arXiv:1502.01852](https://arxiv.org/abs/1502.01852) | Where the `2/n_in` initialisation comes from |
| Deep Residual Learning (ResNet), 2015 | [arXiv:1512.03385](https://arxiv.org/abs/1512.03385) | The degradation problem and its fix |
| Gaussian Error Linear Units (GELU), 2016 | [arXiv:1606.08415](https://arxiv.org/abs/1606.08415) | The activation used throughout modern transformers |
| Adam, 2014 | [arXiv:1412.6980](https://arxiv.org/abs/1412.6980) | The update rule you use every day |
| Decoupled Weight Decay (AdamW), 2017 | [arXiv:1711.05101](https://arxiv.org/abs/1711.05101) | Why Adam's weight decay was wrong |
| How Does Batch Normalization Help Optimization?, 2018 | [arXiv:1805.11604](https://arxiv.org/abs/1805.11604) | The loss-landscape rebuttal |
| MobileNets, 2017 | [arXiv:1704.04861](https://arxiv.org/abs/1704.04861) | Depthwise separable convolution |
| An Image is Worth 16×16 Words (ViT), 2020 | [arXiv:2010.11929](https://arxiv.org/abs/2010.11929) | Where vision went next |

**Practical.** Andrej Karpathy's ["A Recipe for Training Neural Networks"](https://karpathy.github.io/2019/04/25/recipe/) is the best short piece on methodology ever written for this field; read it after Chapter 7 and again after Assignment 2.

**Sources used for version-specific claims in this tutorial:** [pytorch.org](https://pytorch.org/) (current stable release and Python requirement, as of 18 September 2026). Everything else is checkable against the linked documentation for your installed version — and when a claim here disagrees with the docstring on your machine, trust the docstring.
