"""Chapters 1-3: tensors, shapes/strides/broadcasting, autograd.
Every printed value here is quoted in the tutorial. Run: python 01_tensors_autograd.py
"""
import math
import numpy as np
import torch

torch.manual_seed(0)
print("torch", torch.__version__)

# --- 1.3 integer dtypes -----------------------------------------------------
try:
    torch.arange(6).mean()
except RuntimeError as e:
    print("arange(6).mean() ->", str(e)[:60], "...")
print("arange(6).float().mean() =", torch.arange(6).float().mean().item())   # 2.5

# --- 1.5 the NumPy bridge shares memory ------------------------------------
a = np.array([1.0, 2.0, 3.0])
t = torch.from_numpy(a)
a[0] = 5.0
print("shared memory ->", t[0].item())                                       # 5.0

# --- 2.1 storage and strides ------------------------------------------------
x = torch.arange(12).reshape(3, 4)
print("stride", x.stride(), "| transposed stride", x.t().stride())           # (4,1) (1,4)
print("same buffer:", x.t().data_ptr() == x.data_ptr())                      # True

# --- 2.2 view vs reshape ----------------------------------------------------
try:
    x.t().view(-1)
except RuntimeError as e:
    print("view on non-contiguous ->", str(e)[:50], "...")
print("reshape works:", tuple(x.t().reshape(-1).shape))                      # (12,)

# --- 2.4 the silent broadcast bug ------------------------------------------
pred, target = torch.randn(32, 1), torch.randn(32)
print("WRONG shape:", tuple((pred - target).shape))                          # (32,32)
print("RIGHT shape:", tuple((pred.squeeze(1) - target).shape))               # (32,)

# --- 2.6 stable softmax by hand --------------------------------------------
z = torch.randn(4, 5)
s = z - z.max(dim=1, keepdim=True).values
p = s.exp() / s.exp().sum(dim=1, keepdim=True)
assert torch.allclose(p, torch.softmax(z, dim=1))
print("hand-written softmax matches torch.softmax")

# --- 3.3 a gradient computed by hand, then checked -------------------------
xx, tt = torch.tensor([2.0]), torch.tensor([5.0])
w = torch.tensor([3.0], requires_grad=True)
b = torch.tensor([1.0], requires_grad=True)
((w * xx + b) - tt).pow(2).backward()
print("dL/dw =", w.grad.item(), "(hand: 8.0) | dL/db =", b.grad.item(), "(hand: 4.0)")

# --- 3.4 backward needs a scalar -------------------------------------------
v = torch.tensor([1.0, 2.0, 3.0], requires_grad=True)
(v ** 2).backward(torch.ones(3))
print("d(sum x^2)/dx =", v.grad.tolist())                                    # [2,4,6]

# --- 3.5 chain rule spot check ---------------------------------------------
xs = torch.tensor(1.5, requires_grad=True)
torch.sin(xs ** 2).backward()
print("autograd", round(xs.grad.item(), 4), "| analytic", round(2 * 1.5 * math.cos(2.25), 4))

# --- 3.9 a custom autograd Function ----------------------------------------
class DoubleGradSquare(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x):
        ctx.save_for_backward(x)
        return x ** 2

    @staticmethod
    def backward(ctx, grad_output):
        (x,) = ctx.saved_tensors
        return grad_output * 4 * x          # deliberately twice the true 2x

xd = torch.tensor([3.0], requires_grad=True)
DoubleGradSquare.apply(xd).backward()
print("custom grad =", xd.grad.item(), "(true 2x would be 6.0)")             # 12.0
