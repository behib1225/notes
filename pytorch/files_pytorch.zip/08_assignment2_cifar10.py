"""Assignment 2: CIFAR-10 from scratch. Target >=93% test accuracy in <60 epochs.
Needs a GPU to be quick; downloads ~170 MB on first run.
NOTE: this script was written and syntax-checked but the full training run was NOT
executed while writing the tutorial. The quoted 94-95% is an informed estimate."""
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Subset
from torchvision import datasets
from torchvision.transforms import v2

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from importlib import import_module
_rn = import_module("05_resnet_from_scratch")
resnet18 = _rn.resnet18

MEAN, STD = (0.4914, 0.4822, 0.4465), (0.2470, 0.2435, 0.2616)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    model.eval()
    total, correct, seen = 0.0, 0, 0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        logits = model(xb)
        total += criterion(logits, yb).item() * yb.size(0)
        correct += (logits.argmax(1) == yb).sum().item()
        seen += yb.size(0)
    return total / seen, correct / seen


def build_loaders(augment=True, batch_size=128):
    common = [v2.ToImage(), v2.ToDtype(torch.float32, scale=True), v2.Normalize(MEAN, STD)]
    train_tf = v2.Compose(
        ([v2.RandomCrop(32, padding=4, padding_mode="reflect"), v2.RandomHorizontalFlip()]
         if augment else []) + common + ([v2.RandomErasing(p=0.25)] if augment else []))
    test_tf = v2.Compose(common)

    train_full = datasets.CIFAR10("./data", train=True, download=True, transform=train_tf)
    val_full = datasets.CIFAR10("./data", train=True, download=True, transform=test_tf)
    test_ds = datasets.CIFAR10("./data", train=False, download=True, transform=test_tf)

    # Split INDICES once, then index two dataset objects with DIFFERENT transforms,
    # so the validation set is never augmented.
    g = torch.Generator().manual_seed(1234)          # fixed: the split must not vary by seed
    idx = torch.randperm(len(train_full), generator=g)
    train_ds = Subset(train_full, idx[:45_000].tolist())
    val_ds = Subset(val_full, idx[45_000:].tolist())

    return (DataLoader(train_ds, batch_size, shuffle=True, num_workers=4, pin_memory=True,
                       drop_last=True, persistent_workers=True),
            DataLoader(val_ds, 512, shuffle=False, num_workers=4, pin_memory=True),
            DataLoader(test_ds, 512, shuffle=False, num_workers=4, pin_memory=True))


def run(seed, augment=True, epochs=40):
    torch.manual_seed(seed); np.random.seed(seed)
    train_loader, val_loader, test_loader = build_loaders(augment)

    model = resnet18(n_classes=10, small_input=True).to(device)
    model = model.to(memory_format=torch.channels_last)

    decay = [p for _, p in model.named_parameters() if p.ndim > 1]
    no_decay = [p for _, p in model.named_parameters() if p.ndim <= 1]
    opt = torch.optim.SGD(
        [{"params": decay, "weight_decay": 5e-4}, {"params": no_decay, "weight_decay": 0.0}],
        lr=0.1, momentum=0.9, nesterov=True)
    sched = torch.optim.lr_scheduler.OneCycleLR(
        opt, max_lr=0.1, epochs=epochs, steps_per_epoch=len(train_loader), pct_start=0.15)

    crit = nn.CrossEntropyLoss(label_smoothing=0.1)
    use_amp = device.type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)

    best_acc, best_state = 0.0, None
    for ep in range(epochs):
        model.train()
        for xb, yb in train_loader:
            xb = xb.to(device, non_blocking=True).to(memory_format=torch.channels_last)
            yb = yb.to(device, non_blocking=True)
            opt.zero_grad(set_to_none=True)
            with torch.amp.autocast("cuda", enabled=use_amp):
                loss = crit(model(xb), yb)
            scaler.scale(loss).backward()
            scaler.step(opt); scaler.update()
            sched.step()                              # OneCycleLR steps PER BATCH
        va_loss, va_acc = evaluate(model, val_loader, crit, device)
        print(f"epoch {ep:3d}  val loss {va_loss:.4f}  val acc {va_acc:.4f}")
        if va_acc > best_acc:
            best_acc = va_acc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)
    _, test_acc = evaluate(model, test_loader, crit, device)   # test set touched ONCE
    return test_acc, model


@torch.no_grad()
def confusion(model, loader, n_classes=10):
    model.eval()
    cm = torch.zeros(n_classes, n_classes, dtype=torch.long)
    for xb, yb in loader:
        pred = model(xb.to(device)).argmax(1).cpu()
        for t, p in zip(yb, pred):
            cm[t, p] += 1
    return cm


if __name__ == "__main__":
    with_aug = [run(s, augment=True)[0] for s in (0, 1, 2)]
    print(f"with augmentation:    {np.mean(with_aug)*100:.2f} +- {np.std(with_aug)*100:.2f}")
    without = [run(s, augment=False)[0] for s in (0, 1, 2)]
    print(f"without augmentation: {np.mean(without)*100:.2f} +- {np.std(without)*100:.2f}")
