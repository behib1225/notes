# Code for *PyTorch for Engineers*

Runnable companions to the tutorial. Written and checked against
**torch 2.14.0 / torchvision 0.29.0, Python 3.12**, CPU.

```bash
python -m venv .venv && source .venv/bin/activate
pip install torch torchvision          # add --index-url for a CUDA build; see pytorch.org
```

| File | Chapter | Runs offline | Verified |
| --- | --- | --- | --- |
| `01_tensors_autograd.py` | 1–3 | yes | yes |
| `02_activations_gradient_flow.py` | 9.1–9.4 | yes | yes |
| `03_losses_metrics.py` | 6.2, 7.5 | yes | yes |
| `04_conv_shapes.py` | 8 | yes | yes |
| `05_resnet_from_scratch.py` | 10 | yes | yes — parameter counts match torchvision exactly |
| `06_assignment1_backprop.py` | 15 | yes | yes — gradient check passes at ~1e-8 |
| `07_train_mlp_fashionmnist.py` | 7 | downloads ~30 MB | syntax-checked only |
| `08_assignment2_cifar10.py` | 16 | downloads ~170 MB, wants a GPU | syntax-checked only |

"Verified" means the script was executed and its printed values are the ones quoted
in the tutorial. The last two need dataset downloads and, for CIFAR, a GPU to be
practical, so their accuracy figures in the tutorial are informed estimates rather
than measurements — run them yourself and compare.

Run them in order; each is self-contained except `08`, which imports `resnet18`
from `05`.
