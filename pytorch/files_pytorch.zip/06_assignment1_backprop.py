"""Assignment 1: a two-layer MLP with hand-written forward AND backward passes,
checked against autograd. No nn.Module, no autograd in the training loop."""
import torch

torch.manual_seed(0)
D, H, C = 2, 64, 3


def make_spirals(n_per_class=400, n_classes=3, noise=0.15):
    X, y = [], []
    for c in range(n_classes):
        t = torch.linspace(0.2, 1.0, n_per_class)
        theta = t * 4 + c * 2 * torch.pi / n_classes + torch.randn(n_per_class) * noise
        X.append(torch.stack([t * torch.cos(theta), t * torch.sin(theta)], dim=1))
        y.append(torch.full((n_per_class,), c))
    return torch.cat(X), torch.cat(y)


def forward(X, W1, b1, W2, b2):
    z1 = X @ W1 + b1
    a1 = z1.clamp_min(0.0)                       # ReLU
    z2 = a1 @ W2 + b2                            # logits
    return z1, a1, z2


def softmax_ce(z2, y):
    z = z2 - z2.max(dim=1, keepdim=True).values  # shift for stability
    logp = z - z.exp().sum(dim=1, keepdim=True).log()
    return -logp[torch.arange(len(y)), y].mean()


def backward(X, y, z1, a1, z2, W2):
    B = len(y)
    p = torch.softmax(z2, dim=1)
    dz2 = p.clone()
    dz2[torch.arange(B), y] -= 1.0
    dz2 /= B                                     # (softmax - onehot) / B
    dW2 = a1.T @ dz2
    db2 = dz2.sum(0)
    da1 = dz2 @ W2.T
    dz1 = da1 * (z1 > 0).float()                 # ReLU mask
    return X.T @ dz1, dz1.sum(0), dW2, db2


if __name__ == "__main__":
    X, y = make_spirals()
    W1 = torch.randn(D, H) * (2.0 / D) ** 0.5    # He init for ReLU
    b1 = torch.zeros(H)
    W2 = torch.randn(H, C) * (2.0 / H) ** 0.5
    b2 = torch.zeros(C)

    # ---- gradient check against autograd ----
    Ps = [p.clone().requires_grad_(True) for p in (W1, b1, W2, b2)]
    z1, a1, z2 = forward(X, *Ps)
    auto = torch.autograd.grad(softmax_ce(z2, y), Ps)
    z1, a1, z2 = forward(X, W1, b1, W2, b2)
    mine = backward(X, y, z1, a1, z2, W2)
    for name, m, a in zip(["W1", "b1", "W2", "b2"], mine, auto):
        diff = (m - a).abs().max().item()
        print(f"  {name}: max abs diff {diff:.2e}")
        assert torch.allclose(m, a, atol=1e-5)
    print("gradient check PASSED\n")

    # ---- train with plain SGD ----
    lr = 0.5
    for step in range(3001):
        z1, a1, z2 = forward(X, W1, b1, W2, b2)
        dW1, db1, dW2, db2 = backward(X, y, z1, a1, z2, W2)
        W1 -= lr * dW1; b1 -= lr * db1
        W2 -= lr * dW2; b2 -= lr * db2
        if step % 500 == 0:
            acc = (z2.argmax(1) == y).float().mean()
            print(f"step {step:4d}  loss {softmax_ce(z2, y):.4f}  acc {acc:.3f}")
