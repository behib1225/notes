"""Chapter 7: the complete training loop on FashionMNIST. Downloads ~30 MB on first run.
Expect roughly 88-89% test accuracy in ~1 minute on CPU."""
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from torchvision import datasets
from torchvision.transforms import v2

torch.manual_seed(0)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()                                    # dropout ON, BN uses batch stats
    running_loss, correct, seen = 0.0, 0, 0
    for xb, yb in loader:
        xb = xb.to(device, non_blocking=True)
        yb = yb.to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        logits = model(xb)
        loss = criterion(logits, yb)
        loss.backward()
        optimizer.step()
        bs = yb.size(0)
        running_loss += loss.item() * bs             # .item() -> no graph leak
        correct += (logits.argmax(1) == yb).sum().item()
        seen += bs
    return running_loss / seen, correct / seen


@torch.no_grad()                                     # needed IN ADDITION to model.eval()
def evaluate(model, loader, criterion, device):
    model.eval()                                     # dropout OFF, BN uses running stats
    total_loss, correct, seen = 0.0, 0, 0
    for xb, yb in loader:
        xb, yb = xb.to(device), yb.to(device)
        logits = model(xb)
        total_loss += criterion(logits, yb).item() * yb.size(0)
        correct += (logits.argmax(1) == yb).sum().item()
        seen += yb.size(0)
    return total_loss / seen, correct / seen


class MLP(nn.Module):
    def __init__(self, in_dim=28 * 28, hidden=256, n_classes=10, p_drop=0.2):
        super().__init__()
        self.net = nn.Sequential(
            nn.Flatten(),
            nn.Linear(in_dim, hidden), nn.ReLU(), nn.Dropout(p_drop),
            nn.Linear(hidden, hidden), nn.ReLU(), nn.Dropout(p_drop),
            nn.Linear(hidden, n_classes),            # LOGITS, no softmax
        )

    def forward(self, x):
        return self.net(x)


def main():
    tf = v2.Compose([
        v2.ToImage(),
        v2.ToDtype(torch.float32, scale=True),
        v2.Normalize((0.2860,), (0.3530,)),          # FashionMNIST train statistics
    ])
    full_train = datasets.FashionMNIST("./data", train=True, download=True, transform=tf)
    test_ds = datasets.FashionMNIST("./data", train=False, download=True, transform=tf)

    g = torch.Generator().manual_seed(42)
    train_ds, val_ds = random_split(full_train, [54_000, 6_000], generator=g)

    train_loader = DataLoader(train_ds, batch_size=128, shuffle=True, num_workers=2)
    val_loader = DataLoader(val_ds, batch_size=512, shuffle=False, num_workers=2)
    test_loader = DataLoader(test_ds, batch_size=512, shuffle=False, num_workers=2)

    model = MLP().to(device)
    print(f"{sum(p.numel() for p in model.parameters()):,} parameters")   # 269,322

    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-4)
    EPOCHS = 15
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=EPOCHS)

    best_val, best_state = float("inf"), None
    for epoch in range(1, EPOCHS + 1):
        tr_loss, tr_acc = train_one_epoch(model, train_loader, criterion, optimizer, device)
        va_loss, va_acc = evaluate(model, val_loader, criterion, device)
        scheduler.step()                              # AFTER optimizer.step()
        print(f"{epoch:2d}  train {tr_loss:.4f} ({tr_acc:.3f})   val {va_loss:.4f} ({va_acc:.3f})")
        if va_loss < best_val:
            best_val = va_loss
            # CLONE: state_dict() returns live references that keep changing
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

    model.load_state_dict(best_state)
    te_loss, te_acc = evaluate(model, test_loader, criterion, device)
    print(f"TEST  loss {te_loss:.4f}  accuracy {te_acc:.4f}")


if __name__ == "__main__":      # required for num_workers > 0 on Windows/macOS
    main()
