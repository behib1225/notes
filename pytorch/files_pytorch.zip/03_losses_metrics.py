"""Chapters 6.2 and 7.5: numerical stability of losses, and metrics that are not accuracy."""
import torch
import torch.nn as nn

# --- 6.2 why BCEWithLogitsLoss, demonstrated -------------------------------
logits = torch.tensor([-50.0, 50.0], requires_grad=True)     # confidently wrong both ways
target = torch.tensor([1.0, 0.0])

fused = nn.BCEWithLogitsLoss()(logits, target)
split = nn.BCELoss()(torch.sigmoid(logits), target)
print(f"BCEWithLogitsLoss = {fused.item():.1f}  (correct: mean(|logit|) = 50.0)")
print(f"Sigmoid + BCELoss = {split.item():.1f}  (wrong: BCELoss clamps log at -100)")

fused.backward()
print("fused gradient:", logits.grad.tolist())               # [-0.5, 0.5] bounded
s = torch.sigmoid(logits).detach().requires_grad_(True)
nn.BCELoss()(s, target).backward()
print("split gradient:", s.grad.tolist())                    # ~ +-5e11, destroys the model

# --- 7.5 accuracy is not a metric ------------------------------------------
y    = torch.cat([torch.ones(10), torch.zeros(990)])
pred = torch.zeros(1000)                                     # always predict negative
print("\ntrivial baseline accuracy:", (pred == y).float().mean().item())     # 0.99

def precision_recall_f1(cm):
    tp = cm.diag().float()
    precision = tp / cm.sum(0).clamp_min(1)
    recall    = tp / cm.sum(1).clamp_min(1)
    f1 = 2 * precision * recall / (precision + recall).clamp_min(1e-12)
    return precision, recall, f1

cm = torch.tensor([[90, 10],      # 100 positives: 90 caught
                   [ 5, 895]])    # 900 negatives: 5 false alarms
p, r, f1 = precision_recall_f1(cm)
print("precision", [round(v, 4) for v in p.tolist()])
print("recall   ", [round(v, 4) for v in r.tolist()])
print("f1       ", [round(v, 4) for v in f1.tolist()])
print("accuracy    ", round((cm.diag().sum() / cm.sum()).item(), 4))          # 0.9850
print("macro-F1    ", round(f1.mean().item(), 4))                             # 0.9574
print("weighted-F1 ", round((f1 * cm.sum(1) / cm.sum()).sum().item(), 4))     # 0.9848
print("-> accuracy and weighted-F1 hide the 10% of positives we miss; macro-F1 does not")
