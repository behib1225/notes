"""Chapter 8: convolution shape arithmetic, parameter counts, depthwise separable."""
import torch, torch.nn as nn

def out_size(h_in, k, s=1, p=0, d=1):
    return (h_in + 2 * p - d * (k - 1) - 1) // s + 1

print("224 -> Conv 7x7 s2 p3 :", out_size(224, 7, 2, 3))      # 112
print(" 32 -> Conv 3x3 s2 p1 :", out_size(32, 3, 2, 1))       # 16
print("  8 -> Conv 3x3 s2 p1 :", out_size(8, 3, 2, 1))        # 4

c = nn.Conv2d(3, 64, 7, stride=2, padding=3)
print("\nConv2d(3,64,7,s2,p3) on (8,3,224,224) ->", tuple(c(torch.randn(8, 3, 224, 224)).shape))
print("  params:", sum(p.numel() for p in c.parameters()), "= 64*3*49 + 64")

# shape tracing: print as you go, always
net = nn.Sequential(
    nn.Conv2d(3, 32, 3, 1, 1), nn.ReLU(), nn.MaxPool2d(2, 2),
    nn.Conv2d(32, 64, 3, 1, 1), nn.ReLU(), nn.MaxPool2d(2, 2),
    nn.Conv2d(64, 128, 3, 2, 1), nn.ReLU(),
    nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(128, 10),
)
x = torch.randn(1, 3, 32, 32)
print()
for layer in net:
    x = layer(x)
    print(f"{layer.__class__.__name__:18s} {tuple(x.shape)}")

# depthwise separable vs standard
std = nn.Conv2d(64, 128, 3, padding=1)
dw  = nn.Conv2d(64, 64, 3, padding=1, groups=64)
pw  = nn.Conv2d(64, 128, 1)
n = lambda m: sum(p.numel() for p in m.parameters())
print(f"\nstandard 3x3 64->128 : {n(std):,}")
print(f"depthwise + pointwise: {n(dw):,} + {n(pw):,} = {n(dw)+n(pw):,}  ({n(std)/(n(dw)+n(pw)):.1f}x cheaper)")

# receptive field
def receptive_field(layers):          # layers = [(kernel, stride), ...]
    r, j = 1, 1
    for k, s in layers:
        r += (k - 1) * j
        j *= s
    return r
print("\n[3x3 s1] x3            RF =", receptive_field([(3,1)]*3))          # 7
print("[5 s1, 3 s1, pool2 s2, 3 s1] RF =", receptive_field([(5,1),(3,1),(2,2),(3,1)]))  # 12
