"""Chapter 9.1-9.4: why nonlinearity, vanishing gradients, the activation zoo, dying ReLU."""
import torch
import torch.nn as nn
import torch.nn.functional as F

# --- 9.1 stacked linear layers collapse to one -----------------------------
net = nn.Sequential(nn.Linear(4, 8), nn.Linear(8, 3))        # no activation!
W_eq = net[1].weight @ net[0].weight
b_eq = net[1].weight @ net[0].bias + net[1].bias
x = torch.randn(5, 4)
print("collapses to one affine map:", torch.allclose(net(x), x @ W_eq.T + b_eq, atol=1e-6))

# --- 9.2 sigmoid saturates --------------------------------------------------
for z in (0.0, 6.0):
    t = torch.tensor(z, requires_grad=True)
    torch.sigmoid(t).backward()
    print(f"sigmoid'({z}) = {t.grad.item():.7f}")            # 0.25, 0.0024665

def grad_norms(act, depth=10, width=128):
    layers = []
    for _ in range(depth):
        layers += [nn.Linear(width, width), act()]
    net = nn.Sequential(*layers, nn.Linear(width, 1))
    net(torch.randn(64, width)).sum().backward()
    return [l.weight.grad.norm().item() for l in net if isinstance(l, nn.Linear)]

for name, act in (("sigmoid", nn.Sigmoid), ("relu", nn.ReLU)):
    torch.manual_seed(0)
    g = grad_norms(act)
    print(f"{name:8s} first={g[0]:.6f}  last={g[-1]:.3f}  ratio={g[-1]/max(g[0],1e-30):.3g}")

# --- 9.3 the activation zoo, by value --------------------------------------
xs = torch.tensor([-2.0, -0.5, 0.0, 0.5, 2.0])
for name, f in [("ReLU", F.relu), ("LeakyReLU", lambda t: F.leaky_relu(t, 0.01)),
                ("GELU", F.gelu), ("SiLU", F.silu),
                ("tanh", torch.tanh), ("sigmoid", torch.sigmoid)]:
    print(f"{name:10s}", [round(v, 4) for v in f(xs).tolist()])

# --- 9.4 a dead ReLU unit ---------------------------------------------------
lin = nn.Linear(4, 3)
with torch.no_grad():
    lin.bias.fill_(-10.0)
h = F.relu(lin(torch.randn(16, 4)))
h.sum().backward()
print("fraction of units firing:", (h > 0).float().mean().item())            # 0.0
print("weight gradient norm:    ", lin.weight.grad.norm().item())            # 0.0 -> never recovers
