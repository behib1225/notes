"""Chapter 10: BasicBlock, Bottleneck and a full ResNet, verified against torchvision.
Import this module from the other scripts: `from resnet_from_scratch import resnet18`."""
import torch
import torch.nn as nn


class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, in_c, out_c, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(in_c, out_c, 3, stride=stride, padding=1, bias=False)
        self.bn1 = nn.BatchNorm2d(out_c)
        self.conv2 = nn.Conv2d(out_c, out_c, 3, stride=1, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(out_c)
        self.relu = nn.ReLU(inplace=True)
        if stride != 1 or in_c != out_c:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_c, out_c, 1, stride=stride, bias=False),
                nn.BatchNorm2d(out_c))
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        identity = self.shortcut(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return self.relu(out + identity)          # add BEFORE the final ReLU


class Bottleneck(nn.Module):
    expansion = 4

    def __init__(self, in_c, out_c, stride=1):
        super().__init__()
        w = out_c
        self.conv1 = nn.Conv2d(in_c, w, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(w)
        self.conv2 = nn.Conv2d(w, w, 3, stride=stride, padding=1, bias=False)
        self.bn2 = nn.BatchNorm2d(w)
        self.conv3 = nn.Conv2d(w, w * 4, 1, bias=False)
        self.bn3 = nn.BatchNorm2d(w * 4)
        self.relu = nn.ReLU(inplace=True)
        if stride != 1 or in_c != w * 4:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_c, w * 4, 1, stride=stride, bias=False),
                nn.BatchNorm2d(w * 4))
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        identity = self.shortcut(x)
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        return self.relu(out + identity)


class ResNet(nn.Module):
    def __init__(self, block, layers, n_classes=1000, small_input=False):
        super().__init__()
        self.in_c = 64
        if small_input:                                   # CIFAR: keep 32x32 resolution
            self.stem = nn.Sequential(
                nn.Conv2d(3, 64, 3, stride=1, padding=1, bias=False),
                nn.BatchNorm2d(64), nn.ReLU(inplace=True))
        else:                                             # ImageNet: 224 -> 56
            self.stem = nn.Sequential(
                nn.Conv2d(3, 64, 7, stride=2, padding=3, bias=False),
                nn.BatchNorm2d(64), nn.ReLU(inplace=True),
                nn.MaxPool2d(3, stride=2, padding=1))

        self.layer1 = self._make_layer(block, 64, layers[0], 1)
        self.layer2 = self._make_layer(block, 128, layers[1], 2)
        self.layer3 = self._make_layer(block, 256, layers[2], 2)
        self.layer4 = self._make_layer(block, 512, layers[3], 2)
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.fc = nn.Linear(512 * block.expansion, n_classes)

        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode="fan_out", nonlinearity="relu")
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight); nn.init.zeros_(m.bias)

    def _make_layer(self, block, out_c, n_blocks, stride):
        strides = [stride] + [1] * (n_blocks - 1)     # only the FIRST block downsamples
        blocks = []
        for s in strides:
            blocks.append(block(self.in_c, out_c, s))
            self.in_c = out_c * block.expansion
        return nn.Sequential(*blocks)

    def forward(self, x):
        x = self.stem(x)
        x = self.layer1(x); x = self.layer2(x); x = self.layer3(x); x = self.layer4(x)
        return self.fc(torch.flatten(self.avgpool(x), 1))


def resnet18(n_classes=1000, small_input=False):
    return ResNet(BasicBlock, [2, 2, 2, 2], n_classes, small_input)

def resnet34(n_classes=1000, small_input=False):
    return ResNet(BasicBlock, [3, 4, 6, 3], n_classes, small_input)

def resnet50(n_classes=1000, small_input=False):
    return ResNet(Bottleneck, [3, 4, 6, 3], n_classes, small_input)


if __name__ == "__main__":
    m = resnet18()
    print("resnet18 output", tuple(m(torch.randn(2, 3, 224, 224)).shape))
    for name, ours in [("resnet18", resnet18()), ("resnet34", resnet34()), ("resnet50", resnet50())]:
        n_ours = sum(p.numel() for p in ours.parameters())
        try:
            import torchvision.models as tvm
            n_tv = sum(p.numel() for p in getattr(tvm, name)().parameters())
            ok = "MATCHES torchvision" if n_ours == n_tv else f"MISMATCH (tv {n_tv:,})"
        except Exception:
            ok = "(torchvision unavailable)"
        print(f"{name}: {n_ours:>11,} parameters  {ok}")

    print("\nshape trace, 224x224 input:")
    h = torch.randn(1, 3, 224, 224)
    h = m.stem[0:3](h); print("  stem conv 7x7 s2 ", tuple(h.shape))
    h = m.stem[3](h);   print("  maxpool 3x3 s2   ", tuple(h.shape))
    for i, layer in enumerate([m.layer1, m.layer2, m.layer3, m.layer4], 1):
        h = layer(h);   print(f"  layer{i}           ", tuple(h.shape))
