# The PyTorch Computational Graph — a self-study series

From `loss.backward()` to `torch.compile`, `torch.export` and distributed training.
For undergraduates who know Python, NumPy, basic PyTorch and how neural networks are trained.
Written and fully executed against **PyTorch 2.14.1** (the current stable release, October 2026). Everything runs on a CPU-only laptop; GPU-only cells skip themselves.

## Contents

| # | Notebook | Level | Time | Exercises |
|---|---|---|---|---|
| 1 | `01_foundations.ipynb` — graphs, leaves, `grad_fn`, VJPs, define-by-run, accumulation (incl. variable-length data), `no_grad` / `inference_mode` / `detach`, freezing | beginner | 3–4 h | 6 |
| 2 | `02_working_with_the_graph.ipynb` — saved tensors, in-place ops and views, `.data` vs `.detach()`, the autograd engine, gradient clipping, hooks, custom `autograd.Function`, higher-order gradients, WGAN-GP | intermediate | 4–5 h | 6 |
| 3 | `03_func_memory_debugging.ipynb` — benchmarking, `torch.func`, the full memory budget, checkpointing (full and selective), mixed precision and `GradScaler`, debugging, testing and determinism | advanced | 5–6 h | 6 |
| 4 | `04_capturing_the_graph.ipynb` — `torch.fx`, `torch.compile` (graph breaks, AOT graphs, recompilation, 0/1 specialisation), `torch.library.custom_op`, `torch.export`, AOTInductor, how DDP/FSDP hook into autograd | advanced | 5–6 h | 4 |
| 5 | `05_capstone.ipynb` — rescue a broken training script: fix NaNs, a crash, leaks and slowness; meet a memory budget; compile and export | project | 3–5 h | 8 graded requirements |

`solutions/` contains one solutions notebook per part, **executed**, with worked explanations. The student notebooks ship **without outputs** so that the "🤔 Predict" prompts are genuine.

## Setup
```bash
pip install torch matplotlib        # see pytorch.org for the GPU-specific install command
jupyter lab                         # or VS Code / any Jupyter frontend
```
Run each notebook top to bottom, starting with its **Toolkit** cell. Each notebook is self-contained: it never depends on an earlier notebook's state or on your exercise answers.

## How the exercises work
Every exercise has a **YOUR ANSWER** cell and a **TEST** cell. The test prints:
* ✅ correct · ❌ wrong, with a hint about what is wrong · ⏳ not attempted yet.

The tests were checked against both the reference solutions (all pass) and typical wrong answers (they fail with a specific message), e.g. dividing by *k* in variable-length gradient accumulation, forgetting `scaler.unscale_` before clipping, evaluating without `no_grad`, exporting in train mode, or leaving a hook attached.

## Conventions
* **🤔 Predict** — commit to a prediction before running the next cell.
* **🧠 Concept check** — a quick question; click to reveal the answer.
* **🏭 In industry** — how the idea is used in production.
* **⏱** — the cell compiles code and takes 10–60 s the first time.
* Tensor comparisons use `torch.testing.assert_close`. Private (underscore) APIs are used only for teaching/debugging and are labelled as such (table at the top of Notebook 4).
* Timings are measured with `torch.utils.benchmark`; your numbers will differ from anyone else's.

## What changed from the first version
| Review finding | Fix |
|---|---|
| `inference_mode` rule overstated | exact rule (inference tensors cannot be **saved** for backward) with a demo of both cases (NB1 §7) |
| gradient accumulation "divide by k" presented as exact | shown to be wrong for unequal micro-batches; sum ÷ global count, demo + Exercise 1.6 (NB1 §6) |
| "activations usually dominate memory" | full memory budget (params, grads, optimizer state, activations), measured; 16 bytes/param for Adam (NB3 §18, Exercise 3.5) |
| automatic dynamic shapes "serve all sizes" | 0/1 specialisation demonstrated; recompilation exercise (NB4 §23.5, Exercise 4.4) |
| hooks under AMP | `GradScaler` section: hooks see scaled gradients; `unscale_` before clipping (NB3 §19, Exercise 3.6) |
| WGAN-GP mislabeled | correct critic loss on interpolates, `allow_unused` explained (NB2 §15) |
| optimizer-in-backward without caveats | explicit list of what it breaks (NB2 §13.2) |
| poor benchmarking | `torch.utils.benchmark` section, used for every timing (NB3 §16) |
| `_saved_*` called "stable"; private APIs unlabelled | marked private; public/private table (NB2 §9, NB4 intro) |
| unmeasured memory claims | CPU/GPU peak-memory measurement (`memory_timeline`), memory plots, measured checkpointing trade-offs (NB3 §18, Exercise 3.4) |
| solution used as a dependency; fragile global state | shared helpers in each notebook's toolkit; sections self-contained |
| executed outputs spoiled predictions | student notebooks ship clean; solutions separate |
| one 180-cell notebook | five notebooks with time estimates |
| no figures | diagrams of the forward/backward pass, VJPs, checkpointing, the compile stack, DDP overlap; live `draw_graph` renderer |
| exercises mostly "verify X = Y" | added design/debugging exercises (broken loop, gradient monitor, custom op, recompilation) and the capstone |
| missing topics | views & `.data`, autograd engine & node hooks, gradient clipping, AMP, GPU memory tools, DDP/FSDP, selective checkpointing, `torch.library.custom_op` + `opcheck`, `Dim.AUTO`/`draft_export`/strict vs non-strict, eval mode before export, BatchNorm-while-frozen, testing & determinism |
