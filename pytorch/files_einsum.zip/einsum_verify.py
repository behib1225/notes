#!/usr/bin/env python3
"""
einsum_verify.py — reproducible checks for every factual claim in the einsum tutorial.

Run:  python einsum_verify.py
Needs: torch, numpy.  Optional: einops, opt_einsum (sections are skipped if absent).

Every assertion printed here is one the tutorial makes in prose. If a line says FAIL,
the tutorial is wrong, not your machine.
"""
import math
import sys

import torch
import torch.nn.functional as F

torch.manual_seed(0)
torch.set_default_dtype(torch.float64)  # float64 => allclose comparisons are meaningful

PASS, FAIL = 0, 0


def check(label, condition):
    global PASS, FAIL
    ok = bool(condition)
    PASS, FAIL = PASS + ok, FAIL + (not ok)
    print(f"  [{'PASS' if ok else 'FAIL'}] {label}")


def section(name):
    print(f"\n=== {name} ===")


# ---------------------------------------------------------------- Part II
section("Part II - notation and the loop model")

A = torch.tensor([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
B = torch.tensor([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]])
C = torch.einsum('ij,jk->ik', A, B)
check("worked micro-example C == [[4,5],[10,11]]",
      torch.equal(C, torch.tensor([[4.0, 5.0], [10.0, 11.0]])))

# the same thing as explicit loops
C_loops = torch.zeros(2, 2)
for i in range(2):
    for k in range(2):
        total = 0.0
        for j in range(3):
            total += A[i, j] * B[j, k]
        C_loops[i, k] = total
check("loop expansion reproduces einsum", torch.equal(C, C_loops))

x = torch.randn(2, 3, 4)
check("implicit mode sorts output letters ('kij' -> 'ijk')",
      torch.einsum('kij', x).shape == torch.Size([3, 4, 2]))
z = torch.randn(2, 3)
check("implicit mode sorts by ASCII: uppercase before lowercase",
      torch.einsum('iJ', z).shape == torch.Size([3, 2]))
check("ellipsis transposes trailing axes",
      torch.einsum('...ij->...ji', x).shape == torch.Size([2, 4, 3]))
check("spaces in the equation are ignored",
      torch.einsum('b h q d, b h k d -> b h q k',
                   torch.randn(1, 2, 3, 4), torch.randn(1, 2, 5, 4)).shape
      == torch.Size([1, 2, 3, 5]))
check("sublist format works",
      torch.einsum(torch.randn(3, 4), [0, 1], torch.randn(4, 5), [1, 2], [0, 2]).shape
      == torch.Size([3, 5]))

# ---------------------------------------------------------------- Part III
section("Part III - cookbook identities")

M, N = torch.randn(4, 4), torch.randn(4, 4)
check("'ij,ji->' == trace(M@N)",
      torch.allclose(torch.einsum('ij,ji->', M, N), torch.trace(M @ N)))
check("'ij,ij->' == Frobenius inner product",
      torch.allclose(torch.einsum('ij,ij->', M, N), (M * N).sum()))
check("'ii->' == trace", torch.allclose(torch.einsum('ii->', M), torch.trace(M)))
check("'ii->i' == diagonal", torch.allclose(torch.einsum('ii->i', M), torch.diagonal(M)))

a2, b2 = torch.randn(2, 3), torch.randn(4, 5)
check("Kronecker via 'ij,kl->ikjl' + reshape",
      torch.allclose(torch.einsum('ij,kl->ikjl', a2, b2).reshape(8, 15), torch.kron(a2, b2)))

# ---------------------------------------------------------------- Part IV
section("Part IV - torch vs numpy behaviour")

try:
    torch.einsum('ij,jk->ik', torch.randn(3, 4), torch.randn(4, 5).float())
    check("mixed dtypes raise RuntimeError", False)
except RuntimeError:
    check("mixed dtypes raise RuntimeError", True)

aa, bb = torch.randn(3, 1), torch.randn(3, 4)
check("size-1 axes broadcast SILENTLY (a real hazard)",
      torch.einsum('ij,ij->ij', aa, bb).shape == torch.Size([3, 4]))

for eq, args, name in [('i->ij', (torch.randn(3),), "cannot invent an output axis"),
                       ('i->ii', (torch.randn(3),), "cannot repeat an output axis")]:
    try:
        torch.einsum(eq, *args)
        check(name, False)
    except RuntimeError:
        check(name, True)

# ---------------------------------------------------------------- Part V
section("Part V - real workloads")

Bn, H, T, Dh = 2, 4, 16, 8
q, k, v = (torch.randn(Bn, H, T, Dh) for _ in range(3))
scores = torch.einsum('bhqd,bhkd->bhqk', q, k) / math.sqrt(Dh)
out_e = torch.einsum('bhqk,bhkd->bhqd', scores.softmax(-1), v)
check("einsum attention == F.scaled_dot_product_attention",
      torch.allclose(out_e, F.scaled_dot_product_attention(q, k, v), atol=1e-10))

# causal mask: einsum computes scores, masking is a separate additive step
mask = torch.full((T, T), float('-inf')).triu(1)
causal = torch.einsum('bhqk,bhkd->bhqd', (scores + mask).softmax(-1), v)
check("additive causal mask == sdpa(is_causal=True)",
      torch.allclose(causal, F.scaled_dot_product_attention(q, k, v, is_causal=True), atol=1e-10))

D = H * Dh
xemb, Wq = torch.randn(Bn, T, D), torch.randn(H, D, Dh)
check("per-head projection 'btd,hde->bhte'",
      torch.allclose(torch.einsum('btd,hde->bhte', xemb, Wq),
                     torch.stack([xemb @ Wq[h] for h in range(H)], dim=1)))

qm, km = torch.randn(2, 4, 6, 8), torch.randn(2, 5, 8)
check("multi-query attention 'bhqd,bkd->bhqk'",
      torch.einsum('bhqd,bkd->bhqk', qm, km).shape == torch.Size([2, 4, 6, 5]))

Nb, Cin, Hh, Ww, Cout, K = 2, 3, 9, 9, 5, 3
img, W, bias = torch.randn(Nb, Cin, Hh, Ww), torch.randn(Cout, Cin, K, K), torch.randn(Cout)
Ho, Wo = Hh - K + 1, Ww - K + 1
patches = F.unfold(img, K).view(Nb, Cin, K, K, Ho, Wo)
check("conv2d == unfold + 'nckluv,ockl->nouv'",
      torch.allclose(torch.einsum('nckluv,ockl->nouv', patches, W) + bias.view(1, -1, 1, 1),
                     F.conv2d(img, W, bias), atol=1e-10))

Wdw = torch.randn(Cin, K, K)
check("depthwise conv == 'nckluv,ckl->ncuv'",
      torch.allclose(torch.einsum('nckluv,ckl->ncuv', patches, Wdw),
                     F.conv2d(img, Wdw.unsqueeze(1), groups=Cin), atol=1e-10))

G, CinG, CoutG = 3, 2, 4
imgg, Wg = torch.randn(Nb, G * CinG, Hh, Ww), torch.randn(G, CoutG, CinG, K, K)
pg = F.unfold(imgg, K).view(Nb, G, CinG, K, K, Ho, Wo)
check("grouped conv == 'ngckluv,gockl->ngouv'",
      torch.allclose(torch.einsum('ngckluv,gockl->ngouv', pg, Wg).reshape(Nb, G * CoutG, Ho, Wo),
                     F.conv2d(imgg, Wg.reshape(G * CoutG, CinG, K, K), groups=G), atol=1e-10))

feat = torch.randn(Nb, Cout, Ho, Wo)
check("global average pool 'nchw->nc'",
      torch.allclose(torch.einsum('nchw->nc', feat) / (Ho * Wo), feat.mean((2, 3))))
f2 = feat.reshape(Nb, Cout, -1)
check("Gram matrix 'nchw,ndhw->ncd'",
      torch.allclose(torch.einsum('nchw,ndhw->ncd', feat, feat), f2 @ f2.transpose(1, 2)))

ca, cb = torch.randn(6, 8), torch.randn(9, 8)
an, bn = ca / ca.norm(dim=-1, keepdim=True), cb / cb.norm(dim=-1, keepdim=True)
check("cosine similarity matrix 'id,jd->ij'",
      torch.allclose(torch.einsum('id,jd->ij', an, bn),
                     F.cosine_similarity(ca[:, None], cb[None], dim=-1)))

th = torch.tensor(0.7)
R = torch.tensor([[torch.cos(th), -torch.sin(th), 0.0],
                  [torch.sin(th), torch.cos(th), 0.0],
                  [0.0, 0.0, 1.0]])
S = torch.randn(3, 3); S = S + S.T
Sp = torch.einsum('ip,jq,pq->ij', R, R, S)
check("tensor rotation 'ip,jq,pq->ij' == R S R^T", torch.allclose(Sp, R @ S @ R.T))
check("trace invariant under rotation",
      torch.allclose(torch.einsum('ii->', S), torch.einsum('ii->', Sp)))

Cel = torch.randn(3, 3, 3, 3)
eps = torch.randn(3, 3); eps = eps + eps.T
sig = torch.einsum('ijkl,kl->ij', Cel, eps)
check("elasticity 'ijkl,kl->ij'",
      torch.allclose(sig, torch.stack([torch.stack([(Cel[i, j] * eps).sum() for j in range(3)])
                                       for i in range(3)])))
check("strain energy 'ij,ijkl,kl->'",
      torch.allclose(torch.einsum('ij,ijkl,kl->', eps, Cel, eps), (eps * sig).sum()))

X, Amat = torch.randn(6, 4), torch.randn(4, 4)
Amat = Amat @ Amat.T + 4 * torch.eye(4)
check("batched quadratic form 'bi,ij,bj->b'",
      torch.allclose(torch.einsum('bi,ij,bj->b', X, Amat, X), ((X @ Amat) * X).sum(-1)))

Xg = torch.randn(3, 50, 4)
Xc = Xg - Xg.mean(1, keepdim=True)
check("batched covariance 'nbi,nbj->nij'",
      torch.allclose(torch.einsum('nbi,nbj->nij', Xc, Xc) / 49,
                     torch.stack([torch.cov(Xg[n].T) for n in range(3)])))

Ee, Bb, Tt, Dd = 4, 2, 5, 7
eo, gate = torch.randn(Ee, Bb, Tt, Dd), torch.randn(Bb, Tt, Ee)
check("MoE combine 'ebtd,bte->btd'",
      torch.allclose(torch.einsum('ebtd,bte->btd', eo, gate),
                     sum(eo[e] * gate[..., e:e + 1] for e in range(Ee))))

# ---------------------------------------------------------------- Part VI
section("Part VI - the Golden Rule for gradients")


def grad_rule(label, eq, shapes, rules):
    ts = [torch.randn(*s, requires_grad=True) for s in shapes]
    out = torch.einsum(eq, *ts)
    g = torch.randn_like(out)
    out.backward(g)
    ok = True
    for i, rule in enumerate(rules):
        mine = rule(g, [t.detach() for t in ts])
        ok &= mine.shape == ts[i].grad.shape and torch.allclose(mine, ts[i].grad)
    check(f"{label:34s} {eq}", ok)


grad_rule("matmul", 'ij,jk->ik', [(3, 4), (4, 5)],
          [lambda g, t: torch.einsum('ik,jk->ij', g, t[1]),
           lambda g, t: torch.einsum('ij,ik->jk', t[0], g)])
grad_rule("batched matmul", 'bij,bjk->bik', [(2, 3, 4), (2, 4, 5)],
          [lambda g, t: torch.einsum('bik,bjk->bij', g, t[1]),
           lambda g, t: torch.einsum('bij,bik->bjk', t[0], g)])
grad_rule("matrix-vector", 'ij,j->i', [(3, 4), (4,)],
          [lambda g, t: torch.einsum('i,j->ij', g, t[1]),
           lambda g, t: torch.einsum('ij,i->j', t[0], g)])
grad_rule("outer product", 'i,j->ij', [(3,), (4,)],
          [lambda g, t: torch.einsum('ij,j->i', g, t[1]),
           lambda g, t: torch.einsum('ij,i->j', g, t[0])])
grad_rule("dot -> scalar", 'i,i->', [(5,), (5,)],
          [lambda g, t: torch.einsum(',i->i', g, t[1]),
           lambda g, t: torch.einsum(',i->i', g, t[0])])
grad_rule("row-wise dot", 'ij,ij->i', [(3, 4), (3, 4)],
          [lambda g, t: torch.einsum('i,ij->ij', g, t[1]),
           lambda g, t: torch.einsum('i,ij->ij', g, t[0])])
grad_rule("linear layer", 'bi,oi->bo', [(8, 4), (5, 4)],
          [lambda g, t: torch.einsum('bo,oi->bi', g, t[1]),
           lambda g, t: torch.einsum('bo,bi->oi', g, t[0])])
grad_rule("attention scores", 'bhqd,bhkd->bhqk', [(2, 3, 5, 7), (2, 3, 6, 7)],
          [lambda g, t: torch.einsum('bhqk,bhkd->bhqd', g, t[1]),
           lambda g, t: torch.einsum('bhqk,bhqd->bhkd', g, t[0])])
grad_rule("transpose", 'ij->ji', [(3, 4)],
          [lambda g, t: torch.einsum('ji->ij', g)])
grad_rule("3-operand chain", 'ij,jk,kl->il', [(3, 4), (4, 5), (5, 2)],
          [lambda g, t: torch.einsum('il,jk,kl->ij', g, t[1], t[2]),
           lambda g, t: torch.einsum('il,ij,kl->jk', g, t[0], t[2]),
           lambda g, t: torch.einsum('il,ij,jk->kl', g, t[0], t[1])])
grad_rule("bilinear form", 'bi,oij,bj->bo', [(7, 3), (5, 3, 4), (7, 4)],
          [lambda g, t: torch.einsum('bo,oij,bj->bi', g, t[1], t[2]),
           lambda g, t: torch.einsum('bo,bi,bj->oij', g, t[0], t[2]),
           lambda g, t: torch.einsum('bo,oij,bi->bj', g, t[1], t[0])])

section("Part VI - the three exception cases")

grad_rule("A: letter summed away -> expand", 'ijk,k->i', [(3, 4, 5), (5,)],
          [lambda g, t: torch.einsum('i,k->ik', g, t[1]).unsqueeze(1).expand(-1, 4, -1),
           lambda g, t: torch.einsum('ijk,i->k', t[0], g)])
grad_rule("A: plain sum -> broadcast", 'ij->i', [(3, 4)],
          [lambda g, t: g.unsqueeze(1).expand(-1, 4)])
grad_rule("B: trace -> identity", 'ii->', [(4, 4)],
          [lambda g, t: g * torch.eye(4)])
grad_rule("B: diagonal -> diag", 'ii->i', [(4, 4)],
          [lambda g, t: torch.diag(g)])
grad_rule("C: size-1 broadcast -> sum back", 'ij,ij->ij', [(3, 1), (3, 4)],
          [lambda g, t: torch.einsum('ij,ij->ij', g, t[1]).sum(1, keepdim=True),
           lambda g, t: torch.einsum('ij,ij->ij', g, t[0].expand(3, 4))])

# the repeated-letter restriction applies only to the operand being differentiated
Ar = torch.randn(4, 4, requires_grad=True)
Br = torch.randn(4, 5, requires_grad=True)
yr = torch.einsum('ii,ij->j', Ar, Br)
gr = torch.randn_like(yr)
yr.backward(gr)
check("repeated letter blocks only the repeated operand",
      torch.allclose(Br.grad, torch.einsum('j,ii->ij', gr, Ar.detach())))

section("Part VI - hand-checkable gradient")

Ah = torch.tensor([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]], requires_grad=True)
Bh = torch.tensor([[1.0, 0.0], [0.0, 1.0], [1.0, 1.0]], requires_grad=True)
Ch = torch.einsum('ij,jk->ik', Ah, Bh)
Ch.backward(torch.eye(2))
check("hand-computed grad_A == [[1,0,1],[0,1,1]]",
      torch.equal(Ah.grad, torch.tensor([[1.0, 0.0, 1.0], [0.0, 1.0, 1.0]])))
check("hand-computed grad_B == A^T",
      torch.equal(Bh.grad, Ah.detach().T))

section("Part VI - autograd internals and higher order")

Ag = torch.randn(3, 4, requires_grad=True)
Bg = torch.randn(4, 5, requires_grad=True)
check("einsum is composite: no EinsumBackward node",
      'Einsum' not in type(torch.einsum('ij,jk->ik', Ag, Bg).grad_fn).__name__)
check("gradcheck passes on einsum",
      torch.autograd.gradcheck(lambda a, b: torch.einsum('bij,bjk->bik', a, b),
                               (torch.randn(2, 3, 4, requires_grad=True),
                                torch.randn(2, 4, 5, requires_grad=True))))
check("gradgradcheck passes (double backward works)",
      torch.autograd.gradgradcheck(lambda a, b: torch.einsum('ij,jk->ik', a, b), (Ag, Bg)))


class Bilinear(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, W, z):
        ctx.save_for_backward(x, W, z)
        return torch.einsum('bi,oij,bj->bo', x, W, z)

    @staticmethod
    def backward(ctx, g):
        x, W, z = ctx.saved_tensors
        return (torch.einsum('bo,oij,bj->bi', g, W, z),
                torch.einsum('bo,bi,bj->oij', g, x, z),
                torch.einsum('bo,oij,bi->bj', g, W, x))


xb = torch.randn(7, 3, requires_grad=True)
Wb = torch.randn(5, 3, 4, requires_grad=True)
zb = torch.randn(7, 4, requires_grad=True)
check("custom autograd.Function passes gradcheck",
      torch.autograd.gradcheck(Bilinear.apply, (xb, Wb, zb)))
check("einsum bilinear == F.bilinear",
      torch.allclose(torch.einsum('bi,oij,bj->bo', xb, Wb, zb), F.bilinear(xb, zb, Wb)))

section("Part VI - per-sample gradients, two ways")

xs = torch.randn(16, 4, requires_grad=True)
Ws = torch.randn(5, 4, requires_grad=True)
ys = torch.einsum('bi,oi->bo', xs, Ws)
gs = torch.randn_like(ys)
ys.backward(gs)
per_sample = torch.einsum('bo,bi->boi', gs, xs.detach())
check("per-sample gradients sum to the batch gradient",
      torch.allclose(per_sample.sum(0), Ws.grad))

try:
    from torch.func import grad, vmap

    def loss_one(W, x, g):
        return (torch.einsum('i,oi->o', x, W) * g).sum()

    vmapped = vmap(grad(loss_one), in_dims=(None, 0, 0))(Ws.detach(), xs.detach(), gs)
    check("torch.func vmap(grad(...)) matches the einsum trick",
          torch.allclose(vmapped, per_sample))
except Exception as e:  # pragma: no cover
    print(f"  [SKIP] torch.func unavailable: {e}")

# ---------------------------------------------------------------- Part VII
section("Part VII - cost accounting (hardware independent)")

I, J, K, L = 4000, 10, 4000, 10
macs_lr = I * J * K + I * K * L          # (AB) then (AB)C
macs_rl = J * K * L + I * J * L          # (BC) then A(BC)
check(f"left-to-right MACs == 3.2e8 (got {macs_lr:.3e})", macs_lr == 320_000_000)
check(f"right-to-left MACs == 8.0e5 (got {macs_rl:.3e})", macs_rl == 800_000)
check("true path ratio is 400x, not 3000x", abs(macs_lr / macs_rl - 400) < 1e-9)
check("intermediate ratio is 160000x", (I * K) / (J * L) == 160_000)
check("'product of all letters' OVERSTATES 3-operand cost by 2000x",
      abs((I * J * K * L) / macs_rl - 2000) < 1e-9)

try:
    import opt_einsum
    import torch.backends.opt_einsum as oe

    At, Bt, Ct = torch.randn(I, J), torch.randn(J, K), torch.randn(K, L)
    _, info_auto = opt_einsum.contract_path('ij,jk,kl->il', At, Bt, Ct)
    _, info_lr = opt_einsum.contract_path('ij,jk,kl->il', At, Bt, Ct, optimize=[(0, 1), (0, 1)])
    flops_auto = info_auto.opt_cost
    flops_lr = info_lr.opt_cost
    check(f"opt_einsum optimized cost == 2*MACs ({flops_auto:.3e})",
          abs(flops_auto - 2 * macs_rl) < 1)
    check(f"opt_einsum forced-LR cost == 2*MACs ({flops_lr:.3e})",
          abs(flops_lr - 2 * macs_lr) < 1)
    check("opt_einsum backend is available to torch", oe.is_available())
    check("torch enables it by default", oe.enabled)
except ImportError:
    print("  [SKIP] opt_einsum not installed")

section("Part VII - measured timings (machine dependent, reported not asserted)")

import time


def bench(fn, n=20, warmup=5):
    for _ in range(warmup):
        fn()
    ts = []
    for _ in range(n):
        t0 = time.perf_counter()
        fn()
        ts.append(time.perf_counter() - t0)
    ts.sort()
    return ts[len(ts) // 2] * 1e3


try:
    import torch.backends.opt_einsum as oe
    At = torch.randn(I, J); Bt = torch.randn(J, K); Ct = torch.randn(K, L)
    oe.enabled = False
    t_off = bench(lambda: torch.einsum('ij,jk,kl->il', At, Bt, Ct), n=10)
    oe.enabled = True
    t_on = bench(lambda: torch.einsum('ij,jk,kl->il', At, Bt, Ct), n=10)
    print(f"  [INFO] 3-operand einsum: opt_einsum OFF {t_off:.1f} ms | ON {t_on:.1f} ms "
          f"| speedup {t_off / t_on:.1f}x  (median of 10, CPU)")
except ImportError:
    pass

Am, Bm = torch.randn(512, 512), torch.randn(512, 512)
print(f"  [INFO] 512x512: matmul {bench(lambda: Am @ Bm):.2f} ms | "
      f"einsum {bench(lambda: torch.einsum('ij,jk->ik', Am, Bm)):.2f} ms")

Ab = torch.randn(1024, 1024, requires_grad=True)
Bb2 = torch.randn(1024, 1024, requires_grad=True)


def fwd():
    return torch.einsum('ij,jk->ik', Ab, Bb2)


def fwd_bwd():
    y = fwd()
    y.backward(torch.ones_like(y))
    Ab.grad = Bb2.grad = None


tf, tfb = bench(fwd, n=10), bench(fwd_bwd, n=10)
print(f"  [INFO] 2-operand backward/forward ratio ~ {(tfb - tf) / tf:.2f}x "
      f"(theory: 2x, independent of operand count)")

# ---------------------------------------------------------------- Part VIII
section("Part VIII - einops")

try:
    import einops
    from einops import rearrange, reduce, repeat, pack, unpack
    from einops import einsum as eeinsum

    xe = torch.randn(2, 5, 12)
    qe = rearrange(xe, 'b t (h d) -> b h t d', h=3)
    check("rearrange == view + permute",
          torch.allclose(qe, xe.view(2, 5, 3, 4).permute(0, 2, 1, 3)))
    check("einops.einsum == torch.einsum",
          torch.allclose(eeinsum(qe, qe, 'b h i d, b h j d -> b h i j'),
                         torch.einsum('bhid,bhjd->bhij', qe, qe)))
    check("reduce mean == tensor.mean", torch.allclose(reduce(xe, 'b t d -> b d', 'mean'), xe.mean(1)))
    check("repeat broadcasts", repeat(torch.arange(3.0), 'd -> b d', b=4).shape == torch.Size([4, 3]))
    imge = torch.randn(2, 3, 8, 8)
    pat = rearrange(imge, 'n c (h p1) (w p2) -> n (h w) (c p1 p2)', p1=4, p2=4)
    check("patchify shape", pat.shape == torch.Size([2, 4, 48]))
    check("patchify round-trips",
          torch.allclose(rearrange(pat, 'n (h w) (c p1 p2) -> n c (h p1) (w p2)',
                                   h=2, p1=4, p2=4, c=3), imge))
    packed, ps = pack([torch.randn(2, 3, 4), torch.randn(2, 5, 4)], 'b * d')
    u1, u2 = unpack(packed, ps, 'b * d')
    check("pack/unpack round-trips",
          packed.shape == torch.Size([2, 8, 4]) and u1.shape == torch.Size([2, 3, 4]))
    print(f"  [INFO] einops version {einops.__version__}")
except ImportError:
    print("  [SKIP] einops not installed")

# ---------------------------------------------------------------- Part IX
section("Part IX - neighbours, precision, gotchas")

An, Bn2 = torch.randn(3, 4), torch.randn(4, 5)
check("tensordot == einsum for a simple contraction",
      torch.allclose(torch.tensordot(An, Bn2, dims=([1], [0])),
                     torch.einsum('ij,jk->ik', An, Bn2)))
T1, T2 = torch.randn(2, 3, 4), torch.randn(3, 4, 5)
check("tensordot over two axes == einsum",
      torch.allclose(torch.tensordot(T1, T2, dims=([1, 2], [0, 1])),
                     torch.einsum('ijk,jkl->il', T1, T2)))
check("einsum output can be non-contiguous",
      not torch.einsum('ij->ji', torch.randn(4, 4)).is_contiguous())

f32a, f32b = torch.randn(256, 256).float(), torch.randn(256, 256).float()
same_bits = torch.equal(torch.einsum('ij,jk->ik', f32a, f32b), f32a @ f32b)
print(f"  [INFO] einsum vs matmul bitwise identical in float32 on this machine: {same_bits}")
print("         (not guaranteed: reduction order may differ, especially on GPU)")

with torch.autocast('cpu', dtype=torch.bfloat16):
    check("einsum participates in autocast (CPU/bfloat16 tested here)",
          torch.einsum('ij,jk->ik', torch.randn(4, 4).float(),
                       torch.randn(4, 4).float()).dtype == torch.bfloat16)

# ---------------------------------------------------------------- summary
print(f"\n{'=' * 46}\n  {PASS} passed, {FAIL} failed\n{'=' * 46}")
print(f"  torch {torch.__version__}")
sys.exit(1 if FAIL else 0)
