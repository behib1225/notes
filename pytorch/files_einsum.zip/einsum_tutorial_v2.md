# `einsum`: From Einstein Notation to Production PyTorch

### A self-contained, self-study tutorial for engineering undergraduates

**Version 2.** Every factual claim in this document is checked by the companion script `einsum_verify.py`. Run it; it should print `79 passed, 0 failed`. If a line fails, the tutorial is wrong, not your machine.

---

## How to use this tutorial

You need Python. You do **not** need Einstein notation, tensor calculus, or PyTorch internals.

```bash
pip install torch numpy einops opt-einsum
python einsum_verify.py          # reproduces every claim below
```

**Versions this was tested against:** PyTorch 2.14.0, NumPy 2.4.4, einops 0.8.2, opt_einsum 3.4.0.

### Suggested self-study schedule

| Session | Read | Do | Time |
|---|---|---|---|
| 1 | Parts I–IV | Drills D1–D10 | ~2 h |
| 2 | Part V | Exercises E1–E9 | ~2 h |
| 3 | Part VI | Drills D11–D20, Exercises E10–E15 | ~3 h |
| 4 | Parts VII–IX | Exercises E16–E18, full quiz | ~2 h |

Answers to everything live in the **Appendix**, deliberately separated from the questions. Work with a Python session open, and check your answers before reading mine.

### What changed from version 1 (and why you should care)

Version 1 of this tutorial contained three substantive errors. They are listed here rather than quietly fixed, because *how they happened* is itself worth learning:

1. **A FLOP count was off by 7.5×** because I quoted a tool's "naive" baseline while calling it "left-to-right." Two different baselines, silently swapped mid-paragraph. Corrected in VII.1.
2. **"Cost ≈ product of all letter sizes"** was stated without qualification. It is true only for two operands; for three or more it overstated the real cost by 2000× in this document's own example. Corrected in II.6.
3. **"Backward costs n contractions for n operands"** was wrong; backward is ≈2× forward regardless of operand count. Corrected in VI.7, with measurements.

The lesson: **plausible arithmetic stated confidently is the most dangerous kind of error**, because nobody checks it. That is why this version ships a verification script instead of asking you to trust prose.

---

# Part I — Why `einsum` exists

## I.1 The problem

You have token embeddings `x` of shape `(batch, time, model_dim)` and per-head projection matrices `W` of shape `(heads, model_dim, head_dim)`. You want the projection for every batch element, head, and time step.

Without `einsum`:

```python
B, T, D = x.shape
H, _, E = W.shape
out = x.unsqueeze(1).expand(B, H, T, D).reshape(B * H, T, D)
Wr  = W.unsqueeze(0).expand(B, H, D, E).reshape(B * H, D, E)
out = torch.bmm(out, Wr).reshape(B, H, T, E)
```

Five lines, each a chance to get an axis wrong. And the bug will usually **not** crash: if `B == H` or `T == E`, a transposed axis yields a correctly shaped tensor full of wrong numbers, and you discover it three weeks later when the model refuses to train.

With `einsum`:

```python
out = torch.einsum('btd,hde->bhte', x, W)
```

Verified equal to `torch.stack([x @ W[h] for h in range(H)], dim=1)`.

The one-liner is not merely shorter — it is **self-documenting**. It states what every axis of every tensor *means* and what the output axes mean. You can review it without running it.

## I.2 The one-sentence summary

> **`einsum` specifies a tensor computation by naming axes instead of manipulating their positions.**

Position-based code (`permute`, `reshape`, `transpose`, `unsqueeze`, `bmm`) forces you to track where each axis currently sits. Name-based code does not.

## I.3 What it can and cannot do

A single `einsum` subsumes: transpose, sum over any axes, matrix multiply, matrix–vector, dot, outer, batched matmul with any number of batch axes, trace, diagonal, multiply-then-sum, quadratic and bilinear forms, arbitrary-rank tensor contraction, attention scores, Gram and covariance matrices.

It **cannot** express anything nonlinear (`exp`, `softmax`, `relu`, `max`), anything involving comparison (`argmax`, masking), division, or concatenation.

`einsum` does **multiply-and-add only**. That restriction is exactly why its derivative is so clean (Part VI). It is a feature, not a gap.

---

# Part II — The notation, built from nothing

## II.1 Einstein's idea

Physics is full of expressions like

$$C_{ik} = \sum_{j} A_{ij} B_{jk}$$

Einstein noticed the $\sum_j$ is redundant: `j` appears **twice on the right and not on the left**, and the intent is always "sum over it." So he dropped the sigma:

$$C_{ik} = A_{ij} B_{jk}$$

`einsum` is this convention as an API. The string `'ij,jk->ik'` *is* that equation: commas separate operands, `->` separates inputs from output.

## II.2 The three rules — this is the whole language

**Rule 1 — Each letter names one axis.** The same letter in two places asserts *those axes have the same length and are lined up with each other*.

**Rule 2 — A letter in the inputs but not the output is summed over.** It is **contracted**.

**Rule 3 — The letters after `->`, in the order you type them, are the output shape.** `'->ik'` gives one layout; `'->ki'` gives its transpose. **You choose the layout by typing.**

Everything else in this tutorial is consequence, application, or performance.

## II.3 A fully worked example with real numbers

Abstraction is easier to trust once you have watched it work on numbers you can check by hand. Take

$$A = \begin{pmatrix}1 & 2 & 3\\ 4 & 5 & 6\end{pmatrix}, \qquad B = \begin{pmatrix}1 & 0\\ 0 & 1\\ 1 & 1\end{pmatrix}$$

```python
A = torch.tensor([[1., 2., 3.],
                  [4., 5., 6.]])          # shape (2, 3), letters (i, j)
B = torch.tensor([[1., 0.],
                  [0., 1.],
                  [1., 1.]])              # shape (3, 2), letters (j, k)

C = torch.einsum('ij,jk->ik', A, B)
```

Compute $C_{00}$ by hand. Rule 2 says sum over `j`:

$$C_{00} = \sum_{j=0}^{2} A_{0j}B_{j0} = (1)(1) + (2)(0) + (3)(1) = 4$$

$$C_{01} = (1)(0) + (2)(1) + (3)(1) = 5, \quad C_{10} = (4)(1)+(5)(0)+(6)(1) = 10, \quad C_{11} = 11$$

```
C = tensor([[ 4.,  5.],
            [10., 11.]])                  # verified: matches exactly
```

**Do this once with pen and paper before reading further.** Every later section is this operation with more letters.

## II.4 The loop expansion — the tool to keep in your head

Any `einsum` string expands mechanically into nested loops:

1. Collect all letters.
2. **Output letters become outer loops** — one iteration per output element.
3. **Non-output letters become inner accumulation loops.**
4. The body is the product of operands indexed by their own letters.

```python
# einsum('ij,jk->ik', A, B) literally means:
C = zeros(size_i, size_k)
for i in range(size_i):           # output letter -> outer loop
    for k in range(size_k):       # output letter -> outer loop
        total = 0
        for j in range(size_j):   # consumed letter -> accumulation loop
            total += A[i, j] * B[j, k]
        C[i, k] = total
```

The verification script runs exactly this loop on the numbers from II.3 and confirms it reproduces `einsum` output.

A harder one — `einsum('bhqd,bhkd->bhqk', Q, K)`, the attention-score computation:

```python
S = zeros(B, H, Tq, Tk)
for b, h, q, k in product(...):   # all four are in the output -> outer
    total = 0
    for d in range(D):            # d is consumed -> accumulate
        total += Q[b, h, q, d] * K[b, h, k, d]
    S[b, h, q, k] = total
```

Read it and you see immediately: a dot product over the feature dimension `d`, between query position `q` and key position `k`, independently per batch element and head. That *is* attention.

> **Habit worth forming:** when a string confuses you, write the loops. Thirty seconds, never ambiguous. Reading loops is a skill you already have.

## II.5 Seeing it: the index alignment picture

For matrix multiply, the shared letter is the axis that "touches":

```
          j                     k                      k
      ┌───────┐             ┌───────┐              ┌───────┐
   i  │   A   │      ×    j │   B   │      =    i  │   C   │
      └───────┘             └───────┘              └───────┘
        (i,j)                 (j,k)                  (i,k)
           └──────── j is shared, and vanishes ────────┘
```

For a four-letter string, a role table is clearer than any picture. Take `'bhqd,bhkd->bhqk'`:

```
 letter │ in Q │ in K │ in output │ role
 ───────┼──────┼──────┼───────────┼──────────────────────────────────
   b    │  ✓   │  ✓   │     ✓     │ batch      — carried along untouched
   h    │  ✓   │  ✓   │     ✓     │ batch      — carried along untouched
   q    │  ✓   │      │     ✓     │ free (Q)   — becomes the row index
   k    │      │  ✓   │     ✓     │ free (K)   — becomes the column index
   d    │  ✓   │  ✓   │           │ CONTRACTED — summed away
```

Build this table whenever a string is unfamiliar. It takes fifteen seconds and answers every question you have about the operation.

## II.6 Letter roles, and how to estimate cost

Every letter you will ever write falls into one of five roles:

| Where the letter appears | Role | Effect |
|---|---|---|
| All operands **and** the output | **batch** | carried along; the op is repeated independently |
| Two or more operands, **not** the output | **contracted** | this is the "multiply-and-sum" |
| One operand **and** the output | **free** | this is the "outer product" direction |
| One operand, **not** the output | **summed away** | a plain reduction; needs `expand` in backward (VI.5) |
| Twice inside **one** operand | **diagonal** | a gather, *not* a contraction (VI.5) |

### Cost: the rule, stated correctly

> **For a contraction with exactly two operands, the number of multiply–accumulates is the product of the sizes of all distinct letters.**

For `'bhqd,bhkd->bhqk'` that is `b·h·q·k·d`. With `(4,8,128,64)` and `(4,8,256,64)`: `4·8·128·256·64 = 67,108,864` MACs. Notice this immediately explains attention's quadratic cost: `q` and `k` are both the sequence length, so doubling it quadruples the work.

**This rule fails for three or more operands, and the failure is large.** For `'ij,jk,kl->il'` with sizes `4000, 10, 4000, 10`, the product of all letters is `1.6 × 10⁹`, while a good contraction order costs `8 × 10⁵` MACs — the rule overstates by **2000×**. With three or more operands the cost depends on the *order* in which pairs are contracted, and you must reason about the order explicitly. Part VII does exactly that.

> Version 1 of this document stated the cost rule without that caveat, and consequently contradicted its own performance chapter. Watch for this failure mode in any tutorial, including mine: a rule introduced in a simple setting and then silently reused outside its domain.

### MACs vs FLOPs — fix a convention now

A *multiply–accumulate* (MAC) is one multiply plus one add. Most tools, including `opt_einsum`, report **FLOPs ≈ 2 × MACs** for a pairwise contraction. This tutorial counts **MACs** and says so every time. Mixing the two conventions is how off-by-2× errors enter benchmark reports.

## II.7 Implicit mode, and why never to use it

Omit `->` and `einsum` picks the output: every letter appearing exactly once across the inputs, **sorted by ASCII**.

```python
torch.einsum('kij', x).shape     # x is (2,3,4) -> (3,4,2): implicit output is 'ijk'
torch.einsum('iJ', z).shape      # z is (2,3)   -> (3,2): 'J' sorts BEFORE 'i' in ASCII
```

Both verified. Uppercase before lowercase catches people every time.

**Rule for your codebase: always write the arrow.** Four characters buy an explicit, reviewable, diff-able contract.

## II.8 Ellipsis, sublists, whitespace

```python
torch.einsum('...ij->...ji', x)                  # transpose last two axes, any rank
torch.einsum('...ij,...jk->...ik', A, B)         # batched matmul, any number of batch axes
torch.einsum('b h q d, b h k d -> b h q k', q, k)  # spaces are ignored
torch.einsum(A, [0,1], B, [1,2], [0,2])          # sublist form, == 'ij,jk->ik'
```

All verified. `...` axes broadcast against each other by standard NumPy rules. Use `...` in reusable library functions where rank is unknown; use explicit letters when rank is fixed, because explicit letters document better. Spaces are worth adding to any string longer than about eight letters. Sublists exist for programmatically generated equations; prefer readable strings otherwise.

---
# Part III — The cookbook

Every identity here is asserted in `einsum_verify.py`. Learn the loop expansion for each; the equivalent column is a check, not a substitute for understanding.

## III.1 One operand

| `einsum` | Loops | Equivalent |
|---|---|---|
| `'ij->ji'` | `out[j,i] = A[i,j]` | `A.T` |
| `'ij->i'` | `out[i] = Σ_j A[i,j]` | `A.sum(1)` |
| `'ij->j'` | `out[j] = Σ_i A[i,j]` | `A.sum(0)` |
| `'ij->'` | sum everything | `A.sum()` |
| `'ii->i'` | `out[i] = A[i,i]` | `torch.diagonal(A)` |
| `'ii->'` | `out = Σ_i A[i,i]` | `torch.trace(A)` |
| `'nchw->nc'` | sum spatial axes | `A.sum((2,3))` |

`'ii->i'` is the odd one: a repeated letter **inside one operand** means "walk the diagonal," not "double loop." Remember it; it returns as a special case in VI.5.

## III.2 Two operands

| `einsum` | Name | Equivalent |
|---|---|---|
| `'i,i->'` | dot product | `a @ b` |
| `'i,j->ij'` | outer product | `torch.outer(a,b)` |
| `'ij,jk->ik'` | matrix multiply | `A @ B` |
| `'ij,j->i'` | matrix–vector | `A @ v` |
| `'ij,ij->'` | Frobenius inner product | `(A*B).sum()` |
| `'ij,ji->'` | **trace of a product** | `torch.trace(A@B)` |
| `'ij,ij->i'` | row-wise dot | `(A*B).sum(1)` |
| `'bij,bjk->bik'` | batched matmul | `torch.bmm(A,B)` |
| `'bi,oi->bo'` | linear layer (`nn.Linear` convention) | `x @ W.T` |
| `'id,jd->ij'` | all-pairs similarity | `A @ B.T` |
| `'ij,kl->ikjl'` | Kronecker (before reshape) | `torch.kron` after reshape |

`'ij,ji->'` deserves special attention: it computes $\mathrm{tr}(AB)$ **without forming $AB$**, so it costs $O(n^2)$ instead of $O(n^3)$ and allocates nothing. It appears in log-determinant estimators, Fisher-information approximations, and physics codes.

## III.3 Three or more operands

| `einsum` | Name |
|---|---|
| `'i,ij,j->'` | quadratic / bilinear form $x^\top A y$ |
| `'bi,ij,bj->b'` | batch of quadratic forms (Mahalanobis) |
| `'bi,oij,bj->bo'` | bilinear layer (`nn.Bilinear`) |
| `'ij,jk,kl->il'` | three-matrix chain |
| `'ip,jq,pq->ij'` | rank-2 tensor rotation $RSR^\top$ |
| `'ijkl,kl->ij'` | rank-4 contraction (elasticity) |

⚠️ **Anything in this table is subject to Part VII.** With three or more operands, contraction order decides your runtime and your memory. Never ship one of these without reading VII.1.

---

# Part IV — `einsum` among its neighbours

## IV.1 NumPy vs PyTorch

The notation is identical; you can prototype in NumPy and paste into PyTorch. The differences are operational:

| | `np.einsum` | `torch.einsum` |
|---|---|---|
| Autodiff | none | full, including double backward |
| GPU | no | yes (all operands on the **same** device) |
| Order optimization | opt-in: `optimize=True` | **on by default** for ≥3 operands, *if* `opt_einsum` is installed |
| `out=` argument | yes | no |
| Sublist format | yes | yes |
| Mixed dtypes | promotes | **raises `RuntimeError`** (verified) |
| Autocast | n/a | participates — see VII.6 |

Two consequences that bite in practice:

1. **`np.einsum` defaults to `optimize=False`.** Three-operand NumPy `einsum` can be catastrophically slow for this reason alone.
2. **Device and dtype mismatches raise.** This is correct behavior: a silent host↔device copy inside a training loop would be a performance disaster.

## IV.2 Other PyTorch operations that do the same job

`einsum` is not always the shortest path. Know its neighbours so you can pick deliberately rather than by habit.

| Operation | What it does | When to prefer it over `einsum` |
|---|---|---|
| `A @ B` / `torch.matmul` | matmul with broadcasting over leading axes | plain matmul; clearer to every reader |
| `torch.bmm` | exactly one batch axis | when you want the constraint enforced |
| `torch.tensordot(A, B, dims=([1,2],[0,1]))` | contract named axis *positions* | when axes are chosen at runtime by index |
| `torch.inner`, `torch.outer`, `torch.dot` | the obvious small cases | always — they are clearer |
| `torch.kron` | Kronecker product | always — `einsum` + reshape is error-prone here |
| `opt_einsum.contract` | drop-in `einsum` with more path strategies | multi-operand contractions in NumPy or when you want path control |
| `torch.func.vmap` | add a batch axis to *any* function | when the batched thing is not a contraction (see VI.9) |

Verified: `torch.tensordot(A, B, dims=([1],[0]))` equals `einsum('ij,jk->ik', A, B)`, and `tensordot(T1, T2, dims=([1,2],[0,1]))` equals `einsum('ijk,jkl->il', T1, T2)`.

The useful distinction: **`tensordot` names axes by position, `einsum` names them by letter.** If your code computes *which* axis to contract at runtime, `tensordot` is the honest tool. If the axes are known and meaningful, `einsum` documents them.

---

# Part V — Real workloads

All code in this part is asserted in the verification script.

## V.1 Transformers and attention

### V.1.1 Projecting into heads

```python
q = torch.einsum('btd,hde->bhte', x, Wq)      # x: (B,T,D), Wq: (H,D,E)
```

Role check: `d` contracted (that is the matmul); `b, t` from `x` only; `h, e` from `Wq` only. The output order `bhte` is exactly the `(batch, head, time, head_dim)` layout attention kernels want — obtained by typing the letters in that order, with no `permute`.

### V.1.2 Attention end to end

```python
scores = torch.einsum('bhqd,bhkd->bhqk', q, k) / math.sqrt(Dh)
attn   = scores.softmax(dim=-1)                       # NOT einsum: nonlinear
out    = torch.einsum('bhqk,bhkd->bhqd', attn, v)
```

Verified equal to `F.scaled_dot_product_attention(q, k, v)`.

The two `einsum` calls are the *linear* parts; the softmax between them is the *nonlinear* part. In the second string, the letter that disappears is `k` — the key/value position — which is precisely "average the value vectors, weighted by attention." **The letter that vanishes tells you what got averaged away.**

### V.1.3 Masking — where students actually get stuck

`einsum` cannot mask, because masking is a comparison, not a contraction. The idiom is to keep them separate: compute scores with `einsum`, then add a mask of `0` and `-inf` **before** the softmax.

```python
mask   = torch.full((T, T), float('-inf')).triu(1)    # 0 on/below diagonal, -inf above
scores = torch.einsum('bhqd,bhkd->bhqk', q, k) / math.sqrt(Dh)
out    = torch.einsum('bhqk,bhkd->bhqd', (scores + mask).softmax(-1), v)
```

Verified equal to `F.scaled_dot_product_attention(q, k, v, is_causal=True)`.

Why *additive* `-inf` rather than multiplicative zeros: softmax turns $-\infty$ into exactly $0$ probability, and the gradient through a masked position is exactly zero. Multiplying the *post*-softmax weights by a 0/1 mask instead leaves the denominator wrong — the surviving weights no longer sum to 1. This is a real and common bug.

### V.1.4 Variants you can now write without thinking

```python
# Multi-query attention: one shared K/V head. k has no h axis at all.
scores = torch.einsum('bhqd,bkd->bhqk', q, k)          # verified shape (B,H,Tq,Tk)

# Grouped-query attention: g groups of query heads share a KV head.
scores = torch.einsum('bgrqd,bgkd->bgrqk', q, k)

# Additive relative position bias, before softmax
scores = scores + torch.einsum('bhqd,rd->bhqr', q, rel_emb)

# Mixture-of-experts: combine E expert outputs with per-token gate weights
combined = torch.einsum('ebtd,bte->btd', expert_out, gate)     # verified
```

In multi-query attention, `h` appears in `q` only, so the single shared key head is reused across all query heads automatically — no `expand`, no `repeat`, no extra memory.

> **Production note:** do not ship hand-rolled attention. Use `F.scaled_dot_product_attention`, which dispatches to fused kernels (FlashAttention and relatives) that never materialize the `(B,H,Tq,Tk)` score matrix. The `einsum` version is for understanding, prototyping, and research variants the fused kernel does not cover. VII.4 quantifies the difference.

## V.2 Computer vision

### V.2.1 Pooling and Gram matrices

```python
gap  = torch.einsum('nchw->nc', feat) / (H * W)     # == feat.mean((2,3))
gram = torch.einsum('nchw,ndhw->ncd', feat, feat)   # style-transfer Gram matrix
```

Both verified. The Gram string says it all: contract over every spatial location, keep two separate channel letters `c` and `d`, get the channel–channel correlation matrix. One line, zero reshapes.

### V.2.2 Convolution as `unfold` + `einsum`

The single best exercise for understanding what a convolution *is*.

```python
patches = F.unfold(img, K).view(N, Cin, K, K, Ho, Wo)     # name the axes unfold flattened
out = torch.einsum('nckluv,ockl->nouv', patches, W) + b.view(1, -1, 1, 1)
```

Verified equal to `F.conv2d(img, W, b)`. The string is the definition of convolution:

$$\text{out}[n,o,u,v] = \sum_{c}\sum_{k}\sum_{l} \text{patch}[n,c,k,l,u,v]\; W[o,c,k,l]$$

Now the variants, verified against `F.conv2d` with `groups`:

```python
# Depthwise: 'c' is in BOTH operands AND the output -> it is a batch axis -> no channel mixing
out = torch.einsum('nckluv,ckl->ncuv', patches, W_dw)

# Grouped: add a group letter 'g' that behaves as a batch axis
out = torch.einsum('ngckluv,gockl->ngouv', patches_g, W_g)
```

**Look at what changed between standard, depthwise, and grouped: only the letters.** The difference between "mix all channels," "mix none," and "mix within groups" is entirely whether the channel letter is contracted, is a batch axis, or is split into `g` and `c`. That is a remarkably clear way to see what those layer types actually are.

> **Do not ship this either.** `unfold` materializes each input pixel `K·K` times. `F.conv2d` calls cuDNN/oneDNN kernels that are far faster and leaner. Use this construction to understand, to prototype an exotic variant, or when your kernel genuinely is not expressible by `F.conv2d`.

### V.2.3 Similarity matrices

```python
an, bn = a / a.norm(dim=-1, keepdim=True), b / b.norm(dim=-1, keepdim=True)
sim = torch.einsum('id,jd->ij', an, bn)
```

Verified equal to `F.cosine_similarity(a[:,None], b[None], dim=-1)`. The `einsum` form is not just clearer — the broadcasting form materializes an `(i, j, d)` intermediate before reducing it. See VII.4 for what that costs.

## V.3 Classical engineering

`einsum` is not an ML tool that happens to work in physics. It is a physics tool that ML borrowed.

### V.3.1 Rotating a rank-2 tensor

$$\sigma'_{ij} = R_{ip} R_{jq} \sigma_{pq}$$

```python
Sp = torch.einsum('ip,jq,pq->ij', R, R, S)       # verified == R @ S @ R.T
```

The `einsum` form is a **transcription of the textbook line**. The matrix form requires you to know which rotation needs transposing. For a rank-4 tensor the matrix form stops working entirely, while `einsum` just grows letters:

```python
Cp = torch.einsum('ia,jb,kc,ld,abcd->ijkl', R, R, R, R, C)     # rotate an elasticity tensor
```

Invariants come free: `einsum('ii->', S)` equals `einsum('ii->', Sp)` — verified.

### V.3.2 Constitutive laws

Hooke's law in full generality, $\sigma_{ij} = C_{ijkl}\varepsilon_{kl}$:

```python
sigma = torch.einsum('ijkl,kl->ij', C, eps)          # verified against explicit loops
U     = torch.einsum('ij,ijkl,kl->', eps, C, eps)    # strain energy; verified == (eps*sigma).sum()
```

Try writing the energy line with `reshape` and `matmul` and you will see why finite-element codes adopted index notation early.

### V.3.3 Quadratic forms and covariance

```python
quad = torch.einsum('bi,ij,bj->b', X, A, X)                 # Mahalanobis / Kalman / GP
cov  = torch.einsum('nbi,nbj->nij', Xc, Xc) / (B - 1)       # per-group covariance
```

Both verified. In the covariance line, contract over the *sample* letter `b` and keep the feature axis twice, as `i` and `j`. **Turning one vector axis into a matrix by naming it twice is the core covariance/Gram idiom.**

---
# Part VI — Backpropagation through `einsum`

By the end of this part you will write the gradient of any `einsum` string **without doing calculus**, by applying one rule stated in a single sentence — and you will know the three cases where that rule needs help.

## VI.1 What backward actually asks for

Forget "chain rule" for a moment and look at the concrete job.

You have a scalar loss $L$. Somewhere inside the network sits $Y = f(X_1,\dots,X_n)$. Autograd hands your operation exactly one thing:

$$\bar{Y} = \frac{\partial L}{\partial Y}, \qquad \text{same shape as } Y$$

This is the *upstream gradient* (in code: `grad_output`). Your job is to return, for each input, $\bar{X}_m = \partial L/\partial X_m$, **with exactly that input's shape**. The defining formula, summing over every output element:

$$\bar{X}_m[\text{idx}] \;=\; \sum_{\text{all output elements } o} \bar{Y}[o] \cdot \frac{\partial Y[o]}{\partial X_m[\text{idx}]}$$

This is the **vector–Jacobian product (VJP)**. Two facts to internalize:

- **Shapes are non-negotiable.** If a backward formula produces the wrong shape, it is wrong. This makes debugging far easier than it sounds — most incorrect derivations fail the shape check immediately.
- **You never build the Jacobian.** For a 1000×1000 matmul, $\partial Y/\partial A$ has $10^{12}$ entries. The whole point of reverse-mode autodiff is computing $\bar{Y}^\top J$ without ever forming $J$.

## VI.2 Why `einsum` is special: multilinearity

`einsum` only multiplies and adds. Fix every operand but one — fix $B$, vary $A$ — and the map $A \mapsto \text{einsum}(A,B)$ is **linear**. An operation linear in each argument separately is **multilinear**, and multilinear maps have a beautiful derivative property:

> **The derivative of a multilinear map with respect to one argument is obtained by deleting that argument.**

Compare the scalar case you already know: for $f(a,b,c)=abc$, $\partial f/\partial a = bc$ — you deleted $a$. Same thing here, except "deleting" a tensor operand means replacing it with the upstream gradient and re-routing the indices.

Hence: **the gradient of an `einsum` is another `einsum`.**

## VI.3 Derivation from scratch — with numbers you can check

### The algebra

Forward: $C_{ik} = \sum_j A_{ij}B_{jk}$, i.e. `einsum('ij,jk->ik', A, B)`.

Want $\bar{A}_{pq}$ for a specific entry $(p,q)$. From the definition:

$$\bar{A}_{pq} = \sum_{i,k} \bar{C}_{ik}\,\frac{\partial C_{ik}}{\partial A_{pq}}$$

Only the term with $i=p, j=q$ involves $A_{pq}$, so

$$\frac{\partial C_{ik}}{\partial A_{pq}} = \begin{cases} B_{qk} & i = p \\ 0 & \text{otherwise}\end{cases}$$

Substituting kills the sum over $i$:

$$\bar{A}_{pq} = \sum_{k} \bar{C}_{pk}\, B_{qk} \quad \Longrightarrow \quad \boxed{\bar{A} = \texttt{einsum('ik,jk->ij', gC, B)}}$$

Now put the two strings side by side:

```
forward:   'ij,jk->ik'      operands  A,  B
grad_A:    'ik,jk->ij'      operands  gC, B
```

`ij` (A's subscript) and `ik` (the output's subscript) have **traded places**. B's `jk` never moved. That is the entire rule.

### The same thing in numbers — check this by hand

Reuse $A$ and $B$ from II.3, and take the upstream gradient to be the identity, $\bar{C} = \begin{pmatrix}1&0\\0&1\end{pmatrix}$:

```python
A = torch.tensor([[1., 2., 3.], [4., 5., 6.]], requires_grad=True)
B = torch.tensor([[1., 0.], [0., 1.], [1., 1.]], requires_grad=True)
C = torch.einsum('ij,jk->ik', A, B)
C.backward(torch.eye(2))
```

Predict $\bar{A}$ before running. By the formula $\bar{A}_{ij} = \sum_k \bar{C}_{ik}B_{jk}$:

- Row $i=0$: $\bar{C}_{0\cdot} = (1,0)$, so $\bar{A}_{0j} = B_{j0}$, i.e. column 0 of $B$ = $(1,0,1)$.
- Row $i=1$: $\bar{C}_{1\cdot} = (0,1)$, so $\bar{A}_{1j} = B_{j1}$, i.e. column 1 of $B$ = $(0,1,1)$.

```
A.grad = tensor([[1., 0., 1.],
                 [0., 1., 1.]])      # verified: matches exactly
B.grad = A.T                         # verified: equals [[1,4],[2,5],[3,6]]
```

**Work this by hand once.** The rest of Part VI is this computation with more letters.

Note also `C.backward(torch.eye(2))`: that is how you drive a backward pass from a non-scalar output, and it is exactly the VJP of VI.1. Get comfortable with it — it is the fastest way to check any derivative claim you meet.

## VI.4 The Golden Rule

> **To differentiate an `einsum` with respect to operand $m$: swap operand $m$'s subscript string with the output's subscript string, and replace operand $m$ itself with `grad_output`. Everything else stays put.**

Formally, for `Y = torch.einsum('s1,...,sn->o', X1, ..., Xn)`:

```python
gXm = torch.einsum('o,s1,...,ŝm,...,sn->sm', gY, X1, ..., X̂m, ..., Xn)
```

where the hat means "removed from the input list."

**Why it works.** In the forward pass each letter either survives to the output or is contracted away. Reverse-mode differentiation *exchanges these roles* for the operand you are differentiating: a letter summed away in the forward pass must now be *produced* (because $\bar{A}$ needs that axis), and a letter kept in the forward pass must now be *summed* (because the loss has already been accumulated over it). Swapping the two strings performs that exchange for every letter at once.

### Verified gradient table

Each row is asserted in the verification script, with both value and shape checked.

| Forward | grad wrt operand 1 | grad wrt operand 2 |
|---|---|---|
| `'ij,jk->ik'` | `einsum('ik,jk->ij', g, B)` | `einsum('ij,ik->jk', A, g)` |
| `'bij,bjk->bik'` | `einsum('bik,bjk->bij', g, B)` | `einsum('bij,bik->bjk', A, g)` |
| `'ij,j->i'` | `einsum('i,j->ij', g, v)` | `einsum('ij,i->j', A, g)` |
| `'i,j->ij'` | `einsum('ij,j->i', g, b)` | `einsum('ij,i->j', g, a)` |
| `'i,i->'` | `einsum(',i->i', g, b)` | `einsum(',i->i', g, a)` |
| `'ij,ij->i'` | `einsum('i,ij->ij', g, B)` | `einsum('i,ij->ij', g, A)` |
| `'bi,oi->bo'` | `einsum('bo,oi->bi', g, W)` | `einsum('bo,bi->oi', g, x)` |
| `'bhqd,bhkd->bhqk'` | `einsum('bhqk,bhkd->bhqd', g, K)` | `einsum('bhqk,bhqd->bhkd', g, Q)` |
| `'ij->ji'` | `einsum('ji->ij', g)` | — |

Three observations:

- **A scalar output has the empty subscript**, so `'i,i->'` differentiates to a string starting with a bare comma: `',i->i'`. Legal, and it works.
- **The attention gradients are themselves attention-shaped contractions** with the same letter count, hence the same asymptotic cost as the forward pass. That is why attention backward costs about what attention forward costs, and why memory-efficient attention kernels must either store or recompute the scores.
- **Transpose is its own inverse**: `'ij->ji'` differentiates to `'ji->ij'`. A good sanity check that the rule is not doing something exotic.

### Three-operand example

Forward `'ij,jk,kl->il'` with operands $A,B,C$. Apply the rule three times:

| Gradient | String | Operands |
|---|---|---|
| $\bar A$ | `'il,jk,kl->ij'` | `g, B, C` |
| $\bar B$ | `'il,ij,kl->jk'` | `g, A, C` |
| $\bar C$ | `'il,ij,jk->kl'` | `g, A, B` |

All verified. Completely mechanical: take the input list, remove the operand you are differentiating, insert `g` carrying the output's subscript, make the target the removed subscript.

The bilinear layer, a common interview question:

```python
y  = torch.einsum('bi,oij,bj->bo', x, W, z)     # == F.bilinear(x, z, W)   verified
gx = torch.einsum('bo,oij,bj->bi', g, W, z)     # verified
gW = torch.einsum('bo,bi,bj->oij', g, x, z)     # verified
gz = torch.einsum('bo,oij,bi->bj', g, W, x)     # verified
```

## VI.5 The three cases where the rule needs help

The Golden Rule is valid when:

- **(a)** every letter in operand $m$'s subscript also appears in the output or in another operand;
- **(b)** **operand $m$'s own subscript** has no repeated letter;
- **(c)** operand $m$ is not relying on size-1 broadcasting.

Condition (b) is about the operand **being differentiated**, not all operands. Verified: for `einsum('ii,ij->j', A, B)`, the gradient with respect to `B` is an ordinary swap — `einsum('j,ii->ij', g, A)` — and works fine, even though `A`'s subscript is repeated. *(Version 1 stated this condition too broadly.)*

### Case A — a letter that lives only in one operand and is summed away

```python
Y = torch.einsum('ijk,k->i', A, b)       # A: (3,4,5), b: (5,), Y: (3,)
```

`j` appears only in `A` and not in the output. The naive rule wants `einsum('i,k->ijk', g, b)`, but `einsum` cannot invent a `j` axis:

```
RuntimeError: einsum(): output subscript j does not appear in the equation for any input operand
```

**Reason it out from the definition.** $y_i = \sum_{j,k} A_{ijk} b_k$, so $\partial y_i/\partial A_{ijk} = b_k$, **independent of $j$**. Every `j`-slice of the gradient is identical:

```python
gA = torch.einsum('i,k->ik', g, b).unsqueeze(1).expand(-1, A.shape[1], -1)     # verified
```

The simplest instance is a plain sum: for `Y = einsum('ij->i', A)`, the gradient is `g.unsqueeze(1).expand(-1, n)` — verified. Use `.expand` (stride-0 view, allocates nothing), not `.repeat`.

> **The dual pair to memorize:** forward sum ⟷ backward broadcast; forward broadcast ⟷ backward sum. Every reduction/expansion pair in autodiff is an instance of this.

### Case B — a repeated letter inside the differentiated operand

```python
Y = torch.einsum('ii->i', A)     # diagonal
Y = torch.einsum('ii->',  A)     # trace
```

Here the forward is a **gather from the diagonal**, not a contraction, and the adjoint of a gather is a **scatter** — which `einsum` cannot express (it rejects repeated output subscripts). Only diagonal entries influence the output, so every off-diagonal gradient is zero:

```python
# Y = einsum('ii->i', A):   gA = torch.diag(g)         verified
# Y = einsum('ii->',  A):   gA = g * torch.eye(n)      verified
```

PyTorch's autograd handles both correctly. You need to know it because inside a custom `autograd.Function` the swap rule would silently give the wrong answer.

### Case C — size-1 broadcasting

`einsum` happily broadcasts a length-1 axis against a longer one sharing the same letter — both PyTorch and NumPy do this:

```python
torch.einsum('ij,ij->ij', a_(3,1), b_(3,4)).shape     # (3,4), no error   verified
```

The forward result is correct and equals `a * b`. But the Golden Rule now yields the **wrong shape**: `(3,4)` where `a.grad` must be `(3,1)`. Fix by summing over the broadcast axis:

```python
gA = torch.einsum('ij,ij->ij', g, b).sum(1, keepdim=True)      # verified
```

This case is also a **forward-pass bug magnet**: a stray singleton axis (a `keepdim=True` you forgot, a batch of size 1 in a unit test) produces plausible numbers instead of a crash. Defences in Part IX.

## VI.6 What PyTorch actually does internally

`torch.einsum` is **not** a primitive with a hand-written derivative. It is a **composite** op: PyTorch parses the equation and lowers it to `permute`, `reshape`/`view`, `mul`, `sum`, and `bmm`, and autograd differentiates *those*.

You can see it directly — there is no `EinsumBackward`:

```python
torch.einsum('ij,jk->ik', A, B).grad_fn     # <ViewBackward0 ...>   (a reshape atop a bmm)
torch.einsum('ii->i', M).grad_fn            # <PermuteBackward0 ...>
```

Four practical consequences:

1. **Double backward works.** Verified: `torch.autograd.gradgradcheck` passes on `einsum`. Hessian-vector products and gradient penalties are fine. *(Version 1 asserted this without testing it. It happens to be true.)*
2. **The contraction path chosen in the forward pass determines the backward graph** — different intermediates, different memory, slightly different floating-point results. Normal, not a bug.
3. **What is saved for backward is what the underlying `bmm`s need.** Usually views of the inputs; occasionally contiguous copies, when the required layout is not reachable as a view.
4. **Profilers will not show an "einsum" kernel.** You will see `permute`, `copy_`, and `bmm`/`gemm`. Knowing this saves an afternoon the first time you profile.

## VI.7 What backward costs

> **A `einsum` backward pass costs roughly 2× the forward pass, regardless of how many operands there are.**

The reasoning follows directly from VI.6: PyTorch differentiates the *decomposed pairwise chain*, and each pairwise contraction contributes two gradient contractions of comparable cost. Two times forward, whatever `n` is.

Measured on this machine (median of 10, after warmup):

| Case | backward / forward |
|---|---|
| 2-operand `'ij,jk->ik'`, 1024³ | ≈ 2.3× |
| 3-operand `'ij,jk,kl->il'`, thin chain | ≈ 1.1× |

> ⚠️ **Version 1 claimed "n extra contractions, one per operand" — that was wrong**, and contradicted its own VI.6. The `n`-contractions figure applies only if you hand-write the Golden Rule at the `einsum` level inside a custom `Function`, which is *not* what PyTorch does by default. Worth knowing precisely because it is a tempting piece of false intuition.

**Memory**, however, does grow with operand count: for a chain like `'ij,jk,kl->il'`, the pairwise intermediate is kept alive for backward alongside the inputs. This is why a three-operand `einsum` with a poor contraction path can blow up memory in ways a two-operand one cannot. See VII.1.

## VI.8 Writing a custom `autograd.Function`

Ninety-nine times in a hundred, call `torch.einsum` and let autograd work. The exception is when you want to control what is saved for backward (a memory optimization) or to fuse several ops.

```python
class Bilinear(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, W, z):
        ctx.save_for_backward(x, W, z)
        return torch.einsum('bi,oij,bj->bo', x, W, z)

    @staticmethod
    def backward(ctx, g):
        x, W, z = ctx.saved_tensors
        return (torch.einsum('bo,oij,bj->bi', g, W, z),     # each line: one Golden Rule swap
                torch.einsum('bo,bi,bj->oij', g, x, z),
                torch.einsum('bo,oij,bi->bj', g, W, x))
```

**Always validate with `gradcheck`, in `float64`:**

```python
torch.autograd.gradcheck(Bilinear.apply, (x, W, z))     # verified True
```

`gradcheck` compares your analytic backward against finite differences. It **must** run in `float64`: in `float32` the finite-difference noise swamps the signal and you get false failures. Reviewers at any serious shop will ask for this.

## VI.9 Per-sample gradients: the `einsum` trick and the modern alternative

This is the highest-value gradient pattern in industry, and it is a pure consequence of the Golden Rule.

For a linear layer `'bi,oi->bo'`, the rule gives $\bar W = \texttt{einsum('bo,bi->oi', g, x)}$. The batch letter `b` is **contracted** — that contraction *is* the summation over the batch that PyTorch performs. Delete `b` from the contraction and keep it in the output:

```python
per_sample = torch.einsum('bo,bi->boi', g, x)         # (B, out, in)
per_sample.sum(0) == W.grad                            # verified True
```

**The DP-SGD trick is nothing more than declining to sum over one letter.** Memory cost is `B × out × in`, which is why DP-SGD needs microbatching for large layers.

### The alternative you should also know

Since PyTorch 2.0, `torch.func` provides function transforms that do this generically, for *any* function rather than just contractions:

```python
from torch.func import grad, vmap

def loss_one(W, x, g):
    return (torch.einsum('i,oi->o', x, W) * g).sum()

per_sample = vmap(grad(loss_one), in_dims=(None, 0, 0))(W, x, g)   # verified == einsum trick
```

Verified to match the `einsum` formula exactly.

**When to use which.** The `einsum` version is faster and allocation-free for the layer types where a closed form exists (linear, conv, embedding) — which is why production DP libraries hand-code those. `vmap(grad(...))` works for *arbitrary* per-sample quantities, including ones with no closed form, at some overhead. Knowing both, and knowing why libraries hand-code the common cases, is the actual industry-level understanding.

## VI.10 The three-line self-check

Even when you are not writing a custom `Function`, validate any derivative claim in three lines:

```python
Y = torch.einsum('ij,jk->ik', A, B)
g = torch.randn_like(Y)
Y.backward(g)
assert torch.allclose(torch.einsum('ik,jk->ij', g, B.detach()), A.grad)
```

---
# Part VII — Performance and memory

`einsum` is a *specification* language, not a kernel. Two `einsum` calls computing the same mathematical result can differ by orders of magnitude in time and memory. This part is about controlling that.

**Read the arithmetic, distrust the stopwatch.** Everything in VII.1 is hardware-independent counting that you can verify on paper. Everything in VII.3 is a timing measured on one CPU and should be treated as illustration, not specification.

## VII.1 Contraction order is everything

With three or more operands the *result* is independent of the order in which you contract pairs, but the *cost* is not.

Take `'ij,jk,kl->il'` with `A: (4000,10)`, `B: (10,4000)`, `C: (4000,10)`. Count MACs (II.6 convention):

| Order | Intermediate | Step 1 MACs | Step 2 MACs | Total MACs | Largest intermediate |
|---|---|---|---|---|---|
| `(AB)C` — left to right | `(4000, 4000)` | 4000·10·4000 = 1.6×10⁸ | 4000·4000·10 = 1.6×10⁸ | **3.2×10⁸** | 16,000,000 elements |
| `A(BC)` — right to left | `(10, 10)` | 10·4000·10 = 4.0×10⁵ | 4000·10·10 = 4.0×10⁵ | **8.0×10⁵** | 100 elements |

**Right-to-left wins by 400× in arithmetic and 160,000× in intermediate memory**, from the same one-line equation.

These numbers are asserted in the verification script, and cross-checked against `opt_einsum`, which reports `2 × MACs` as its FLOP count for both paths: `1.600e+6` for the optimized path and `6.400e+8` when the left-to-right path is forced with `optimize=[(0,1),(0,1)]`.

> ### A cautionary note about the number 3000
>
> Version 1 of this tutorial claimed a **3000× arithmetic difference** here. That figure is `opt_einsum`'s **"Naive FLOP count"**, which assumes a single fused loop over *all four* indices with **no pairwise decomposition at all** — something no implementation actually executes. Left-to-right, the real fallback, is 400× worse than optimal, not 3000×.
>
> Version 1 then used the inflated gap to "explain" why the measured speedup was smaller than predicted. That explanation was rationalizing an arithmetic error.
>
> **The transferable lesson:** whenever you quote a speedup, name the baseline. `opt_einsum` prints three different cost numbers and they mean three different things. Getting this wrong is the single most common error in performance write-ups, including mine.

## VII.2 `opt_einsum` and `torch.backends.opt_einsum`

PyTorch delegates the ordering decision to the `opt_einsum` package, if installed.

```python
import torch.backends.opt_einsum as oe
oe.is_available()   # True iff the opt_einsum package is installed
oe.enabled          # True by default when available
oe.strategy         # 'auto' | 'greedy' | 'optimal'
```

The PyTorch documentation states the behaviour precisely: when `opt_einsum` is available, `einsum` optimizes the contraction order through this backend; the optimization applies only with **at least three inputs**, since with two the order is irrelevant. Finding *the* optimal path is NP-hard, so the package uses heuristics. When `opt_einsum` is absent, PyTorch contracts **left to right**. The docs also warn explicitly that the `'optimal'` strategy's runtime is **factorial** in the number of inputs — use it only for few operands, or offline to discover a path you then hard-code.

**Three things every engineer should know:**

1. **`opt_einsum` is an optional dependency.** Absent, your three-operand `einsum` silently takes the left-to-right path. Put `opt-einsum` in `requirements.txt`; assert `oe.is_available()` at service startup if it matters.
2. **The path search itself costs time** on every call. Small, but real in a tight loop with fixed shapes — `torch.compile` hoists it, or split into explicit pairwise contractions once you know the answer.
3. **Path choice affects backward memory** (VI.7): the chosen intermediate is retained for the backward pass.

Inspect the plan before shipping:

```python
import opt_einsum
path, info = opt_einsum.contract_path('ij,jk,kl->il', A, B, C)
print(path)     # [(1, 2), (0, 1)]  -> contract operands 1 and 2 first
print(info)     # FLOP counts, largest intermediate, per-step BLAS calls
```

**Make this a habit.** Before shipping any `einsum` with ≥3 operands, print `contract_path` and read **`Largest intermediate`**. Ten seconds, and it catches the bug class that only appears in production at the largest batch size.

## VII.3 Measured timings, and why you should distrust them

Here is the same benchmark — `'ij,jk,kl->il'`, `opt_einsum` off versus on, median of 10–15 runs after warmup — on **one CPU**, varying only the thread count and dtype:

| Configuration | opt_einsum OFF | ON | Speedup |
|---|---|---|---|
| float32, 1 thread | 44.4 ms | 0.32 ms | **140×** |
| float32, 4 threads | 44.6 ms | 1.80 ms | **25×** |
| float64, 4 threads | 109 ms | 2.00 ms | **55×** |

Same machine. Same equation. Same data. The reported speedup moves between 25× and 140× purely from thread count and precision, because the optimized path is so small (8×10⁵ MACs) that thread-dispatch overhead dominates it, while the unoptimized path is large enough to be compute-bound.

**Three conclusions:**

1. **The arithmetic ratio (400×) is the stable, transferable number.** The wall-clock number is a property of a machine on a day.
2. **A single benchmark number without methodology is not evidence.** Report dtype, thread count, warmup, repetitions, and the statistic (median, not mean — one GC pause ruins a mean). Version 1 of this tutorial reported "25×" from 5 unwarmed repetitions and presented it as a fact.
3. **The direction and order of magnitude are robust** even when the exact figure is not. Optimizing contraction order is worth doing; claiming it gives exactly 25× is not defensible.

### Is `einsum` slower than `matmul`?

On this CPU, 512×512: `matmul` 4.08 ms, `einsum` 4.21 ms. For patterns that map cleanly onto BLAS, **`einsum` lowers to the same GEMM and is essentially free.** The small gap is equation parsing and permutation overhead, and it shrinks as tensors grow.

Where `einsum` genuinely loses:

- **When the equation forces a physical permutation.** `einsum` must arrange axes so the contraction becomes a `bmm`. If the layout is not reachable as a view, PyTorch inserts a `copy_`, which on large tensors can dominate. Symptom: `copy_` or `contiguous` eating real time in your profile.
- **On very small tensors**, where parsing overhead is comparable to the arithmetic. Hoist or compile.
- **Against fused kernels.** No `einsum` beats FlashAttention or cuDNN convolution, because those fuse the nonlinearity and never materialize intermediates. `einsum` is not permitted to know there is a softmax coming.

## VII.4 The materialization trap

The most important performance idea in this part.

`einsum` computes exactly what you asked for and **stores the result**. If the result is enormous, you get an enormous allocation, even if you immediately reduce it.

Attention is the canonical case. `einsum('bhqd,bhkd->bhqk', q, k)` allocates `(B, H, T, T)`. For `B=4, H=16, T=4096` in `float16`:

$$4 \times 16 \times 4096 \times 4096 \times 2\ \text{bytes} = 2{,}147{,}483{,}648\ \text{bytes} = 2.0\ \text{GiB}$$

per score tensor, per layer — and autograd keeps the post-softmax copy for backward too. This is precisely the wall FlashAttention was built to break: it tiles the computation so the `T×T` matrix never exists in HBM.

**General principle:** an `einsum` whose output has *more* letters than either input is an expansion, and expansions cost memory. Scan every string for it.

```python
# similarity matrix, two ways
torch.einsum('id,jd->ij', a, b)             # (50000,50000) output: 2.5e9 elements = 10 GB fp32
(a[:, None, :] * b[None, :, :]).sum(-1)     # SAME result, but builds (50000,50000,512) first
                                            # = 1.28e12 elements = over 5 TB. Process dies.
```

Both compute the same thing. One runs; the other does not. `einsum` is the *good* option here — the point is that you must think about the intermediate either way. Ten GB is still large; in a real retrieval system you would chunk over `i`. But it is the *unavoidable* size of the answer, not a wasted intermediate.

**Mitigations, in order of preference:** use a fused op if one exists; chunk the expansion axis and loop; apply `torch.utils.checkpoint` to trade recomputation for memory; reorder the contraction so the large axis is consumed earlier.

## VII.5 Contiguity

`einsum` often returns non-contiguous tensors — verified: `einsum('ij->ji', x).is_contiguous()` is `False`. Usually good (a copy was avoided). But if the next op needs contiguous memory, the copy happens *there*, and now it appears in the wrong place in your profile. Chasing a mystery `copy_`? Check whether an upstream `einsum` handed on a permuted view.

## VII.6 Precision, autocast, and reproducibility

**Autocast.** `torch.einsum` is treated as a matmul-class op and runs in the **lower** precision under autocast. Verified here on CPU with `bfloat16`: `einsum` output dtype is `bfloat16`, matching `@`. *(GPU float16 autocast follows the same policy but was not tested in this environment — verify on your own hardware before relying on it.)*

Consequences:

- Under AMP your `einsum` gets tensor-core speed automatically. Good.
- But an `einsum` acting as a **long reduction** (`'nchw->nc'`, summing thousands of values) also drops to reduced precision, and long `float16` reductions lose accuracy badly. If an `einsum` computes statistics rather than a matmul, cast to `float32` or wrap it in `torch.autocast(enabled=False)`.
- Operands must share a dtype; there is no implicit promotion.

**Reproducibility.** `einsum` and a hand-written matmul chain may produce **bitwise different** results, because floating-point addition is not associative and the two may accumulate in different orders. On this CPU, `einsum('ij,jk->ik', a, b)` happened to be bitwise identical to `a @ b` in float32 — but that is a coincidence of this implementation and not a guarantee, especially on GPU where reduction order varies with block scheduling. Also relevant on NVIDIA hardware: `torch.backends.cuda.matmul.allow_tf32` affects `einsum` too, since `einsum` lowers to GEMM. Small numerical differences between `einsum` and its "equivalent" are expected and are not correctness bugs. If you need bitwise reproducibility, fix the op, the dtype, the TF32 setting, and `torch.use_deterministic_algorithms(True)` — and re-validate.

## VII.7 `torch.compile`

`einsum` compiles cleanly. Under `torch.compile`, Inductor can fuse the surrounding elementwise ops into the contraction and hoist the path decision out of the hot loop. **For production training code, compiling the module containing your `einsum`s is usually a larger win than hand-optimizing the strings.** Compile first, measure, then optimize.

## VII.8 Deployment — what I have *not* verified

Honesty about scope: this tutorial was written and tested in a CPU container. The following are real deployment concerns that you should investigate on your own target, and that I make **no verified claim** about:

- **ONNX / TorchScript export.** `Einsum` is a standard ONNX operator, but coverage of exotic equations, ellipsis, and opset version varies by exporter and runtime. Test your specific string end-to-end before committing to it in an exported graph.
- **Mobile and edge runtimes** may implement a narrower subset, or fall back to slow generic paths.
- **Quantized tensors.** `einsum` does not generally support quantized dtypes; quantized pipelines usually require the op to be expressed as a supported matmul.
- **Sparse tensors.** Support is limited; prefer the dedicated sparse ops.

A defensible engineering rule: **if the model will be exported, prefer `matmul`/`bmm`/`conv` in the final serving path and keep `einsum` for research and training code** — unless you have tested the export yourself.

## VII.9 When *not* to use `einsum`

- **A fused primitive exists.** Attention → `F.scaled_dot_product_attention`. Convolution → `F.conv2d`. Plain matmul → `@`. Never hand-roll these in production.
- **The op is elementwise.** `einsum('ij,ij->ij', a, b)` is just `a * b`, written less clearly with more overhead.
- **It is a plain transpose or sum.** `A.T` and `A.sum(1)` are clearer to every reader.
- **Axes are chosen at runtime by position.** Use `tensordot`.
- **The string exceeds ~8 distinct letters.** Use `einops.einsum` with word-length names.
- **The output is a large expansion you immediately reduce.** Restructure the contraction.
- **The model will be exported to a constrained runtime** and you have not tested the export.

The honest summary: use `einsum` when it makes *intent* clearer than the alternative, and check the intermediates whenever there are three or more operands.

---

# Part VIII — `einops`

`einsum` names axes for *contractions*. `einops` extends the same idea to **reshaping, splitting, merging, reducing, repeating**. Together they remove nearly every raw `permute`/`reshape`/`view` from a codebase. You will meet `einops` in most modern vision and NLP repositories.

It is framework-agnostic (PyTorch, JAX, NumPy, TensorFlow and others) and fully differentiable — the operations are views and reductions, so autograd flows through exactly as through the equivalent `reshape`/`sum`.

## VIII.1 `rearrange`

```python
q = rearrange(x, 'b t (h d) -> b h t d', h=8)
```

Verified equal to `x.view(B, T, 8, D//8).permute(0, 2, 1, 3)`. The `einops` version additionally *states* that the model dimension is a product of head count and head dim, in that order, and that heads are promoted to axis 1 — three facts the positional version leaves implicit.

| Pattern element | Meaning |
|---|---|
| `b t d` | three named axes |
| `(h d)` on the **left** | split this axis into `h × d` (supply one size) |
| `(h d)` on the **right** | merge into one axis, `h`-major |
| `1` | a singleton axis |
| `...` | any number of unnamed axes |

The entire ViT patchifier, verified to round-trip:

```python
patches = rearrange(img, 'n c (h p1) (w p2) -> n (h w) (c p1 p2)', p1=16, p2=16)
```

**Its best property is the error messages.** A size mismatch reports the pattern, the actual shape, and the axis sizes you supplied — compare with `RuntimeError: shape '[2,5,5,2]' is invalid for input of size 120`.

## VIII.2 `reduce` and `repeat`

```python
reduce(x, 'b t d -> b d', 'mean')                    # == x.mean(1)               verified
reduce(img, 'n c (h 2) (w 2) -> n c h w', 'max')     # 2x2 max-pool, no layer object
repeat(bias, 'd -> b d', b=4)                        # explicit broadcast          verified
```

`reduce` accepts `'mean' | 'sum' | 'max' | 'min' | 'prod'`. In the pooling example, the pattern *is* the specification of the window — nothing to look up. And by VI.5, `repeat`'s gradient is a **sum** over the repeated axis.

## VIII.3 `einops.einsum`

```python
scores = einsum(q, k, 'b h i d, b h j d -> b h i j')      # verified == torch.einsum
```

Two differences from `torch.einsum`: **axis names can be words**, not single letters (`'batch head query dim, ... -> ...'` is legal), and the **pattern comes last**. For contractions with many axes, word-length names are the difference between reviewable and unreviewable code.

## VIII.4 `pack` and `unpack`

For "concatenate a few tensors along one axis, do something, split them back" — prepending a CLS token, bundling Q/K/V:

```python
packed, ps = pack([a, b], 'b * d')       # (2,3,4) & (2,5,4) -> (2,8,4); ps records the split
a2, b2 = unpack(packed, ps, 'b * d')     # exact round trip                        verified
```

Safer than hand-computed split indices, because the record travels with the data.

## VIII.5 Layers, and division of labour

```python
from einops.layers.torch import Rearrange, Reduce
model = nn.Sequential(nn.Conv2d(3, 64, 3),
                      Reduce('n c h w -> n c', 'mean'),   # self-documenting global average pool
                      nn.Linear(64, 10))
```

Note `Rearrange`/`Reduce` (classes, `einops.layers.torch`) versus `rearrange`/`reduce` (functions, `einops`). Confusing them is a common first-day error.

| Task | Tool |
|---|---|
| Move, split, merge axes | `einops.rearrange` |
| Reduce over axes | `einops.reduce` |
| Broadcast/tile | `einops.repeat` |
| Contract two or more tensors | `torch.einsum` / `einops.einsum` |
| Bundle a variable number of tensors | `einops.pack` / `unpack` |
| Anything nonlinear | plain PyTorch |

A good house style: **`einops` for shape, `einsum` for arithmetic, no raw `permute`/`view` in model code at all.**

---

# Part IX — Gotchas and the debugging playbook

## IX.1 The gotcha list

Cross-references point at the full treatment rather than repeating it.

| # | Gotcha | Where |
|---|---|---|
| 1 | Size-1 axes broadcast **silently** — no shape error, wrong numbers | VI.5 Case C |
| 2 | Implicit mode sorts output letters by ASCII (uppercase first) | II.7 |
| 3 | A repeated letter inside one operand means **diagonal**, not contraction | II.6, VI.5 Case B |
| 4 | `einsum` cannot invent an output axis (`'i->ij'`) | VI.5 Case A |
| 5 | `einsum` cannot repeat an output axis (`'i->ii'`) — use `diag_embed` | III.1 |
| 6 | All operands must share device **and** dtype; no promotion | IV.1 |
| 7 | Only 52 labels available (`a-zA-Z`) | II.8 |
| 8 | ≥3 operands without `opt_einsum` installed silently degrade to left-to-right | VII.2 |
| 9 | Output is often non-contiguous; the copy surfaces in the *next* op | VII.5 |
| 10 | Reductions under autocast run in low precision | VII.6 |
| 11 | `np.einsum` defaults to `optimize=False` | IV.1 |
| 12 | Export/quantization/sparse support is limited and untested here | VII.8 |

## IX.2 The playbook

Work this in order; it resolves almost every case.

**1. Expand it into loops on paper** (II.4). Thirty seconds, never ambiguous.

**2. Re-test with distinct dimension sizes.**

```python
B, T, H, D = 2, 5, 3, 7      # all different, small, none a multiple of another
```

If every dimension is 32, a transposition is invisible. If they are `2,5,3,7`, it is a crash. **This one habit prevents more `einsum` bugs than everything else in this tutorial combined.**

**3. Differential-test against a naive reference.** Write the slow, obviously-correct version and compare:

```python
ref = torch.stack([x @ W[h] for h in range(H)], dim=1)
assert torch.allclose(fast, ref, atol=1e-5)
```

This is how every claim in this document was validated, and it is what a reviewer will expect in your test file.

**4. Build the letter-role table** (II.5). Is a letter you meant to contract accidentally in the output, so it was never summed? Is a letter you meant to keep missing, so it was summed away?

**5. Verify gradients** — `gradcheck` in `float64` for a custom `Function`, or the three-line check in VI.10 otherwise.

**6. Print the contraction path** (`opt_einsum.contract_path`) if there are ≥3 operands and the problem is speed or memory rather than correctness.

## IX.3 Team style rules

- Always write `->`.
- Use consistent letters across the codebase: `b` batch, `t`/`s` sequence, `h` head, `d` model dim, `e` head dim, `c` channel, `n` sample, `o` output feature. Then any reviewer can read any string.
- Add spaces to strings longer than eight letters.
- One comment above any non-obvious `einsum`, giving input and output shapes.
- Prefer `einops.einsum` with word-length names when a comment is not enough.
- Never hand-roll an op that has a fused kernel.

---
# Part X — Drills (closed book)

**Do these with no computer.** They take about twenty minutes and they are what builds fluency. Answers in Appendix A.

**D1.** Output shape of `einsum('ij,jk->ik', A, B)` with `A: (3,4)`, `B: (4,5)`?

**D2.** Output shape of `einsum('bhqd,bhkd->bkqh', q, k)` with `q: (2,4,6,8)`, `k: (2,4,10,8)`?

**D3.** Output shape of `einsum('nchw->hw', x)` with `x: (2,3,5,7)`? What did it compute?

**D4.** Output shape of `einsum('i,j,k->ijk', a, b, c)` with sizes 2, 3, 4? What is this operation called?

**D5.** In `einsum('abc,cd,de->abe', X, Y, Z)`, which letters are contracted and which survive?

**D6.** What does `einsum('ij,ij->j', A, B)` compute, in one sentence? Write the non-`einsum` equivalent.

**D7.** How many MACs does `einsum('ij,jk->ik', A, B)` cost with `i=100, j=200, k=300`?

**D8.** `einsum('ii->i', A)` with `A: (4,4)` — output shape, and what is it?

**D9.** Without running it: does `einsum('kij', x)` on `x: (2,3,4)` return shape `(2,3,4)`? If not, what and why?

**D10.** Is `einsum('ij,jk->ik', A, B)` the same operation as `einsum('jk,ij->ik', B, A)`? Justify.

**D11.** Forward is `'ij,jk->ik'`. Write the gradient w.r.t. **B** — string and operand order.

**D12.** Forward is `'bi,oi->bo'` (a linear layer). Write the gradient w.r.t. **x** — string and operands.

**D13.** Forward is `'ij->ji'`. Write the gradient. What is notable about it?

**D14.** Forward is `'bhqd,bhkd->bhqk'`. Write the gradient w.r.t. **K**.

**D15.** Forward is `'ijk,k->i'` with `A: (3,4,5)`. Apply the Golden Rule to get `grad_A`. What goes wrong, and what is the fix?

**D16.** Forward is `'ii->'`. What is `grad_A`, and why is it not obtainable from the Golden Rule?

**D17.** Spot the bug: `scores = torch.einsum('bhqd,bhdk->bhqk', q, k)` where `q: (B,H,Tq,D)` and `k: (B,H,Tk,D)`. Will it crash? What is the correct string?

**D18.** Spot the bug: `out = torch.einsum('ij,ij->ij', a, b)` where `a: (3,1)` and `b: (3,4)`. Will it crash? What is the danger?

**D19.** For `'ij,jk,kl->il'` with `i=1000, j=20, k=1000, l=30`, compute the MAC count for both contraction orders. Which wins, and by what factor?

**D20.** True or false, with one line of justification each: (a) `einsum` can implement softmax. (b) `einsum` can implement a causal mask. (c) `einsum` can implement max-pooling. (d) `einsum`'s gradient is always another `einsum`.

---

# Part XI — Coding exercises

Work these with a Python session open. Full solutions in Appendix B. Verify every answer against a reference implementation — that habit is as much the point as the answer.

```python
import torch, math
import torch.nn.functional as F
torch.manual_seed(0)
torch.set_default_dtype(torch.float64)   # makes allclose comparisons trustworthy
```

## Tier 1 — Translation

**E1.** Write `einsum` equivalents for: `A.T`, `A.sum(0)`, `torch.trace(A)`, `torch.diagonal(A)`, `A @ v`, `torch.outer(a,b)`, `torch.bmm(A,B)`.

**E2.** Explain what each computes, then write the non-`einsum` form: (a) `'ij,ji->'`, (b) `'ij,ij->'`, (c) `'ij,ij->i'`, (d) `'nchw->nc'`. For (a), state its asymptotic cost and why it matters.

**E3.** Each of these fails or misleads. Say why and fix it: (a) `einsum('ij,jk', A, B)` in production; (b) `einsum('i->ij', v)`; (c) `einsum('i->ii', v)`; (d) `einsum('ij,jk->ik', A_cpu, B_cuda)`.

## Tier 2 — Applications

**E4.** Cosine-similarity matrix between `a: (N,D)` and `b: (M,D)`. Verify against `F.cosine_similarity`.

**E5.** Per-group covariance from `X: (G,B,D)` → `(G,D,D)`. Verify against `torch.cov`.

**E6.** Kronecker product of `A: (m,n)` and `B: (p,q)` with one `einsum` and one `reshape`. Verify against `torch.kron`. Explain why the output letter order matters.

**E7.** Mixture-of-experts combination: `expert_out: (E,B,T,D)`, `gate: (B,T,E)` → `(B,T,D)`.

**E8.** Multi-query attention scores: `q: (B,H,Tq,E)` and a single shared `k: (B,Tk,E)` → `(B,H,Tq,Tk)`. Explain why no `expand` is needed.

**E9.** Implement causal masked attention with `einsum` + an additive mask. Verify against `F.scaled_dot_product_attention(..., is_causal=True)`. Explain why the mask must be additive and pre-softmax.

**E10.** Depthwise convolution via `F.unfold` + `einsum`. Verify against `F.conv2d(..., groups=C)`.

**E11.** Grouped convolution the same way. Verify against `F.conv2d(..., groups=G)`.

**E12.** Contract the rank-4 elasticity tensor `C: (3,3,3,3)` with strain `eps: (3,3)`; then compute strain energy $U = \varepsilon_{ij}C_{ijkl}\varepsilon_{kl}$ in one `einsum`.

**E13.** Rotate a stress tensor with one `einsum`, and verify numerically that the trace is invariant.

**E14.** **Batched ordinary least squares.** Given `X: (B,N,P)` and `y: (B,N)`, build the normal equations $X^\top X$ and $X^\top y$ with `einsum`, solve with `torch.linalg.solve`, and verify against `torch.linalg.lstsq` per batch element.

## Tier 3 — Backpropagation

**E15.** For `y = einsum('bi,oi->bo', x, W)`, derive both gradients by the Golden Rule and verify against autograd.

**E16.** Derive both gradients of `'bhqd,bhkd->bhqk'` and explain in words what each one means physically.

**E17.** Derive `grad_A` for `y = einsum('ijk,k->i', A, b)`. Explain why the Golden Rule alone is insufficient, and give working code.

**E18.** Starting from E15, derive the per-sample gradient used in DP-SGD; verify that summing over the batch reproduces `W.grad`; then reproduce it with `torch.func.vmap(grad(...))` and say when you would prefer each.

**E19.** Write a custom `autograd.Function` for `y = einsum('bi,oij,bj->bo', x, W, z)` with all three gradients hand-written, and validate with `gradcheck` in `float64`.

## Tier 4 — Performance

**E20.** For `'ij,jk,kl->il'` with `A: (1000,20)`, `B: (20,1000)`, `C: (1000,30)`, count MACs and the largest intermediate for both orders. Then run `opt_einsum.contract_path` and **reconcile** your MAC count with each of the three numbers the tool reports.

**E21.** You are reviewing this pull request line:

```python
sim = (queries[:, None, :] * keys[None, :, :]).sum(-1)   # queries, keys: (50000, 512)
```

Estimate peak memory, rewrite it, and estimate the memory of the rewrite. Then estimate the memory of a `(B,H,T,T)` attention score tensor for `B=4, H=16, T=4096` in `float16`.

**E22.** A colleague reports a three-operand `einsum` running 20× slower on the deployment box than on their laptop, identical shapes and PyTorch versions. Give the most likely cause, the one-line check, and two other hypotheses worth ruling out.

---

# Part XII — Concept quiz

Answers in Appendix C.

**Q1.** In `'ij,jk->ik'`, what happens to `j`, and why?

**Q2.** State the Golden Rule in one sentence.

**Q3.** Give the three conditions under which the Golden Rule applies, and the fix for each violation.

**Q4.** Is `torch.einsum` a primitive autograd op? What does `grad_fn` reveal, and what are two practical consequences?

**Q5.** How do you estimate the MAC cost of a **two-operand** `einsum`? Why does that method fail for three operands?

**Q6.** Roughly what does an `einsum` backward pass cost relative to its forward pass, and does the answer depend on the number of operands?

**Q7.** Why does contraction order matter for three operands but not for two?

**Q8.** Your three-operand `einsum` is unexpectedly slow in production. What is the first thing you check?

**Q9.** What does `einsum('ii->i', A)` compute, and why is it not an ordinary contraction?

**Q10.** In what precision should `gradcheck` run, and why?

**Q11.** You write `einsum('ij,ij->ij', a, b)` with `a: (3,1)`, `b: (3,4)`. What happens, and why is it dangerous?

**Q12.** Name three situations where `einsum` is the wrong tool despite producing a correct answer.

**Q13.** Someone reports "switching to `einsum` gave a 25× speedup." What three questions do you ask before believing it?

**Q14.** Why must an attention mask be additive (`-inf`) and applied *before* the softmax, rather than multiplicative and applied after?

---

# Part XIII — Cheat sheet and checklist

## XIII.1 The three rules

1. Each letter names an axis; the same letter twice means "same length, line them up."
2. A letter in the inputs but not the output is **summed over**.
3. The letters after `->`, in the order typed, are the output shape.

## XIII.2 Reading any string

| Letter appears in | Role |
|---|---|
| all operands **and** output | batch axis |
| two operands, **not** output | contracted |
| one operand **and** output | free axis |
| one operand, **not** output | summed away (needs `expand` in backward) |
| twice in **one** operand | diagonal — not a contraction |

**Cost (two operands only):** MACs = product of all distinct letter sizes. **Three or more operands: cost depends on contraction order — see VII.1.**

## XIII.3 Gradients

```
forward:    'sA,sB->o'
grad wrt A: 'o,sB->sA'   operands (g, B)     # swap sA <-> o
grad wrt B: 'sA,o->sB'   operands (A, g)     # swap sB <-> o
```

Exceptions: letter unique to the differentiated operand and absent from the output → `.expand`; repeated letter in the differentiated operand → `torch.diag` / `torch.eye`; size-1 broadcasting → `.sum(dim, keepdim=True)`.

Backward costs ≈ 2× forward, independent of operand count.

## XIII.4 Ten strings worth memorizing

```python
'ij->ji'                  # transpose
'ij->i'                   # row sums
'ii->'                    # trace
'ij,jk->ik'               # matmul
'ij,ji->'                 # trace of a product, without forming the product
'bij,bjk->bik'            # batched matmul
'bi,oi->bo'               # linear layer
'id,jd->ij'               # all-pairs similarity
'bhqd,bhkd->bhqk'         # attention scores
'bi,ij,bj->b'             # batched quadratic form
```

## XIII.5 Pre-merge checklist

- [ ] The equation has an explicit `->`.
- [ ] A comment states input and output shapes.
- [ ] Letters follow the team convention.
- [ ] A test compares against a naive reference, using **distinct, small, non-divisible** dimension sizes.
- [ ] If ≥3 operands: `contract_path` inspected, and `opt-einsum` pinned in `requirements.txt`.
- [ ] Largest intermediate and output size estimated **in bytes at production batch size**.
- [ ] No fused kernel exists that would do this better.
- [ ] Custom `autograd.Function`? `gradcheck` passes in `float64`.
- [ ] Under AMP, any `einsum` acting as a long reduction is cast up to `float32`.
- [ ] If the model will be exported, the export path has been tested (VII.8).

## XIII.6 Benchmark hygiene

Any performance claim you make or receive should state: dtype, device, thread count, warmup, repetitions, the statistic (median, not mean), and **the baseline being compared against**. A speedup number without a named baseline is not a measurement — as VII.1 and VII.3 of this very document demonstrate.

## XIII.7 References

- **`torch.einsum`** — official documentation, `opt_einsum` behaviour, sublist format, ellipsis broadcasting: <https://docs.pytorch.org/docs/stable/generated/torch.einsum.html>
- **`opt_einsum` path finding** — how contraction orders are searched: <https://optimized-einsum.readthedocs.io/en/stable/path_finding.html>
- **`einops`** — source, tutorials, API reference: <https://github.com/arogozhnikov/einops>
- **`torch.autograd.gradcheck`** and the PyTorch autograd mechanics notes, for the VJP formalism of Part VI.
- **`F.scaled_dot_product_attention`** in the PyTorch docs, for the fused attention kernels recommended in VII.4.
- **`torch.func`** (`grad`, `vmap`) for the function-transform approach in VI.9.

## XIII.8 Where to go next

- **Shape typing** (`jaxtyping`, `torchtyping`) — the same "name your axes" philosophy, enforced by a type checker.
- **`torch.compile` and Inductor** — how contractions and surrounding elementwise ops fuse into single kernels.
- **Tensor-network methods** — where contraction-order optimization is the entire research problem, and where `opt_einsum` came from.

---
# Appendix A — Drill answers

**A1.** `(3, 5)`. `j` is contracted; `i` and `k` survive in the order typed.

**A2.** `(2, 10, 6, 4)`. Output letters are `b, k, q, h` with sizes 2, 10, 6, 4. You get whatever layout you type — that is the feature.

**A3.** `(5, 7)`. Both `n` and `c` are absent from the output, so it summed over batch **and** channel, leaving a spatial map. (Almost certainly a bug in real code; `'nchw->hw'` is rarely what anyone means.)

**A4.** `(2, 3, 4)`. A rank-3 outer product: no letter is shared, so nothing is contracted and every combination is formed.

**A5.** Contracted: `c` (in operands 1 and 2, absent from output) and `d` (in operands 2 and 3, absent from output). Surviving: `a`, `b`, `e`.

**A6.** Column-wise dot product: `out[j] = Σ_i A[i,j]·B[i,j]`. Equivalent: `(A*B).sum(0)`. Contrast with `'ij,ij->i'`, which sums over columns instead.

**A7.** `100 × 200 × 300 = 6,000,000` MACs — the product of all distinct letter sizes (valid here because there are exactly two operands).

**A8.** Shape `(4,)`; it is the main diagonal. The repeated letter indexes both axes simultaneously.

**A9.** No — it returns `(3, 4, 2)`. With no `->`, the implicit output is the surviving letters sorted by ASCII, i.e. `'ijk'`, which permutes the axes. This is why you always write the arrow.

**A10.** Yes, identical. `einsum` is defined by the letters, not by operand position; swapping the operands and their subscripts together leaves the equation unchanged. (The *contraction path* chosen internally might differ, which can change floating-point rounding in the last bits, but not the mathematics.)

**A11.** `einsum('ij,ik->jk', A, g)` — B's subscript `jk` swapped with the output's `ik`; A stays put.

**A12.** `einsum('bo,oi->bi', g, W)` — x's subscript `bi` swapped with the output's `bo`.

**A13.** `einsum('ji->ij', g)`. Notable: transpose is its own adjoint. A useful sanity check that the Golden Rule is not doing anything exotic.

**A14.** `einsum('bhqk,bhqd->bhkd', g, Q)` — K's subscript `bhkd` swapped with the output's `bhqk`.

**A15.** The rule wants `einsum('i,k->ijk', g, b)`, which fails: `j` appears in no remaining input, and `einsum` cannot invent an axis. Because $y_i = \sum_{j,k}A_{ijk}b_k$, the gradient is independent of `j`, so compute without it and broadcast:
```python
gA = torch.einsum('i,k->ik', g, b).unsqueeze(1).expand(-1, A.shape[1], -1)
```

**A16.** `grad_A = g * torch.eye(n)`. The forward is a diagonal **gather**, not a contraction; its adjoint is a **scatter**, and `einsum` rejects repeated output subscripts, so no `einsum` can express it.

**A17.** It will crash. The string says operand 2 has axes `(b,h,d,k)`, i.e. the feature dim in position 2 — but `k` is `(B,H,Tk,D)` with the feature dim last. PyTorch reports a size conflict on `d`. Correct string: `'bhqd,bhkd->bhqk'`. **Note this only crashes because `Tk ≠ D`**; if they happened to be equal it would run and silently produce nonsense — which is the case for the habit in IX.2 step 2.

**A18.** It will **not** crash. `einsum` broadcasts the size-1 axis and returns `(3,4)`, equal to `a*b`. Dangerous because a stray singleton (a forgotten `keepdim=True`, a unit test with batch size 1) yields plausible numbers instead of an error — and because the naive backward now has the wrong shape and must be summed back with `.sum(1, keepdim=True)`.

**A19.**

| Order | Step 1 | Step 2 | Total MACs | Largest intermediate |
|---|---|---|---|---|
| `(AB)C` | 1000·20·1000 = 2.0×10⁷ | 1000·1000·30 = 3.0×10⁷ | **5.0×10⁷** | 1,000,000 |
| `A(BC)` | 20·1000·30 = 6.0×10⁵ | 1000·20·30 = 6.0×10⁵ | **1.2×10⁶** | 600 |

Right-to-left wins by **≈42× in arithmetic** and **≈1667× in intermediate size**.

**A20.**
(a) **False** — softmax needs `exp` and a division; `einsum` is multiply-and-add only.
(b) **False** — masking is a comparison/selection; the idiom is an additive `-inf` mask applied outside the `einsum` (V.1.3).
(c) **False** — max is not a sum. (Average-pooling *is* expressible, e.g. `'nchw->nc'` divided by `H·W`; max-pooling is not.)
(d) **False** — almost always true, but not when a letter appears only in the differentiated operand and is summed away (needs `expand`), or when that operand has a repeated letter (needs a scatter). See VI.5.

---

# Appendix B — Exercise solutions

## Tier 1

**E1.** `'ij->ji'`, `'ij->j'`, `'ii->'`, `'ii->i'`, `'ij,j->i'`, `'i,j->ij'`, `'bij,bjk->bik'`.

Note the second: `A.sum(0)` sums *over* axis 0, so the **surviving** letter is `j`. Half of all `einsum` mistakes are this confusion. The letters after `->` are the ones that survive.

**E2.**

| String | Meaning | Equivalent |
|---|---|---|
| `'ij,ji->'` | trace of a product | `torch.trace(A@B)` (verified) |
| `'ij,ij->'` | Frobenius inner product | `(A*B).sum()` (verified) |
| `'ij,ij->i'` | row-wise dot product | `(A*B).sum(1)` |
| `'nchw->nc'` | sum over spatial axes | `A.sum((2,3))` |

For (a): cost is $O(n^2)$, not $O(n^3)$, because the product matrix is never formed — only its diagonal is ever needed, and `einsum` computes exactly that. It also allocates nothing beyond the scalar. This matters in log-determinant estimators, Fisher-information approximations, and physics codes where $n$ is large.

**E3.**
(a) Implicit mode. It works here (output `'ik'`), but the contract is invisible to a reader and fragile to a letter rename. Fix: `'ij,jk->ik'`.
(b) Cannot create an output axis absent from all inputs. Fix: `v.unsqueeze(1).expand(-1, n)`.
(c) Cannot repeat an output subscript. Fix: `torch.diag(v)` or `torch.diag_embed(v)`.
(d) Operands must share a device; raises `RuntimeError`. Fix: move one tensor explicitly — then ask *why* they were on different devices, because that is usually the real bug.

## Tier 2

**E4.**
```python
an, bn = a / a.norm(dim=-1, keepdim=True), b / b.norm(dim=-1, keepdim=True)
sim = torch.einsum('id,jd->ij', an, bn)          # verified == F.cosine_similarity(a[:,None], b[None], dim=-1)
```

**E5.**
```python
Xc  = X - X.mean(1, keepdim=True)
cov = torch.einsum('nbi,nbj->nij', Xc, Xc) / (X.shape[1] - 1)     # verified == torch.cov per group
```
Contract over the **sample** letter `b`; name the feature axis twice, as `i` and `j`. Naming one vector axis twice is the core covariance/Gram idiom.

**E6.**
```python
kr = torch.einsum('ij,kl->ikjl', A, B).reshape(m*p, n*q)          # verified == torch.kron(A, B)
```
The interleaved order `ikjl` is the whole trick: the result's row index is the pair `(i,k)` read as a mixed-radix number and its column index is `(j,l)`. Writing `'ij,kl->ijkl'` and reshaping gives a different, wrong matrix. (In production, just call `torch.kron`.)

**E7.** `torch.einsum('ebtd,bte->btd', expert_out, gate)` — verified against an explicit loop. `e` is contracted; that contraction *is* the weighted sum over experts.

**E8.** `torch.einsum('bhqd,bkd->bhqk', q, k)` — verified shape `(B,H,Tq,Tk)`. `h` appears in `q` only, so the single shared key head is reused across all query heads automatically. No `expand`, no `repeat`, no extra memory: the contraction visits the same `k` data for every `h`.

**E9.**
```python
mask   = torch.full((T, T), float('-inf')).triu(1)
scores = torch.einsum('bhqd,bhkd->bhqk', q, k) / math.sqrt(Dh)
out    = torch.einsum('bhqk,bhkd->bhqd', (scores + mask).softmax(-1), v)
```
Verified equal to `F.scaled_dot_product_attention(q, k, v, is_causal=True)`.

Additive and pre-softmax because softmax maps $-\infty$ to exactly zero probability **and** excludes the masked position from the normalizing denominator, so the surviving weights still sum to 1. Multiplying the *post*-softmax weights by a 0/1 mask zeroes the weights but leaves the denominator computed over all positions, so the remaining weights sum to less than 1 — a silent, common bug.

**E10.**
```python
p = F.unfold(img, K).view(N, C, K, K, Ho, Wo)
out = torch.einsum('nckluv,ckl->ncuv', p, W_dw)                   # verified == F.conv2d(..., groups=C)
```
`c` appears in **both** operands **and** the output, making it a batch axis — no cross-channel mixing. That is the definition of depthwise.

**E11.**
```python
pg  = F.unfold(img, K).view(N, G, CinG, K, K, Ho, Wo)
out = torch.einsum('ngckluv,gockl->ngouv', pg, Wg).reshape(N, G*CoutG, Ho, Wo)
```
Verified against `F.conv2d(..., groups=G)`. The group letter `g` behaves as a batch axis; `c` is still contracted within each group.

**E12.**
```python
sigma = torch.einsum('ijkl,kl->ij', C, eps)          # verified against explicit loops
U     = torch.einsum('ij,ijkl,kl->', eps, C, eps)    # verified == (eps*sigma).sum()
```

**E13.**
```python
Sp = torch.einsum('ip,jq,pq->ij', R, R, S)                          # verified == R @ S @ R.T
assert torch.allclose(torch.einsum('ii->', S), torch.einsum('ii->', Sp))    # verified
```

**E14.**
```python
XtX  = torch.einsum('bni,bnj->bij', X, X)      # (B, P, P)
Xty  = torch.einsum('bni,bn->bi',  X, y)       # (B, P)
beta = torch.linalg.solve(XtX, Xty)            # verified == torch.linalg.lstsq per batch element
```
Both `einsum`s contract over the observation letter `n`. Note the normal equations are numerically worse-conditioned than a QR-based `lstsq` — for ill-conditioned `X` prefer `lstsq`. The `einsum` form is the right choice when `P` is small and `B` is large, where batching dominates.

## Tier 3

**E15.** `'bi,oi->bo'`. Swapping W's `oi` with the output's `bo`, and x's `bi` with `bo`:
$$\bar W = \texttt{einsum('bo,bi->oi', g, x)}, \qquad \bar x = \texttt{einsum('bo,oi->bi', g, W)}$$
Both verified. Shape check: $\bar W$ must be `(o,i)`, and `'bo,bi->oi'` gives exactly that, contracting `b`. Every correct backward passes this check; most incorrect ones fail it.

**E16.** $\bar Q = \texttt{einsum('bhqk,bhkd->bhqd', g, K)}$ and $\bar K = \texttt{einsum('bhqk,bhqd->bhkd', g, Q)}$ — both verified.

In words: **the gradient arriving at a query vector is the attention-weighted sum of the key vectors it was compared against**, weighted by how much the loss cared about each score; symmetrically for keys. Each backward contraction has the same letter count as the forward, hence the same asymptotic cost — which is why attention backward costs about what attention forward costs, and why memory-efficient kernels must store or recompute the scores.

**E17.** `j` appears only in `A` and not in the output, so the rule's target string contains a letter present in no remaining input and `einsum` rejects it. From the definition, $\partial y_i/\partial A_{ijk} = b_k$, independent of `j`:
```python
gA = torch.einsum('i,k->ik', g, b).unsqueeze(1).expand(-1, A.shape[1], -1)     # verified
```
Use `.expand` (stride-0 view, allocates nothing), not `.repeat`.

**E18.** The batch-summed gradient is `einsum('bo,bi->oi', g, x)`; the only thing making it batch-summed is that `b` is **absent from the output**. Keep it:
```python
per_sample = torch.einsum('bo,bi->boi', g, x)        # (B, out, in)
per_sample.sum(0) == W.grad                           # verified True
```
The `torch.func` route, verified to match exactly:
```python
from torch.func import grad, vmap
def loss_one(W, x, g):
    return (torch.einsum('i,oi->o', x, W) * g).sum()
per_sample = vmap(grad(loss_one), in_dims=(None, 0, 0))(W, x, g)
```
Prefer the `einsum` form for layer types with a closed form (linear, conv, embedding) — it is faster and allocation-free, which is why production DP libraries hand-code them. Prefer `vmap(grad(...))` when the per-sample quantity has no closed form, or when you want one generic implementation. Memory for either is `B × out × in`, which is why DP-SGD microbatches large layers.

**E19.**
```python
class Bilinear(torch.autograd.Function):
    @staticmethod
    def forward(ctx, x, W, z):
        ctx.save_for_backward(x, W, z)
        return torch.einsum('bi,oij,bj->bo', x, W, z)

    @staticmethod
    def backward(ctx, g):
        x, W, z = ctx.saved_tensors
        return (torch.einsum('bo,oij,bj->bi', g, W, z),
                torch.einsum('bo,bi,bj->oij', g, x, z),
                torch.einsum('bo,oij,bi->bj', g, W, x))

torch.autograd.gradcheck(Bilinear.apply, (x, W, z))     # verified True, float64
```
Each line is one Golden Rule swap: remove the operand being differentiated, insert `g` with the output subscript `bo`, target the removed subscript. The forward also matches `F.bilinear(x, z, W)` — verified.

## Tier 4

**E20.** MAC counts and intermediates: see **A19** (5.0×10⁷ vs 1.2×10⁶ MACs; 1,000,000 vs 600 elements; right-to-left wins by ≈42×).

Reconciling with `opt_einsum.contract_path`, which prints:

```
Naive FLOP count:      1.800e+9
Optimized FLOP count:  2.400e+6
Theoretical speedup:   7.500e+2
Largest intermediate:  3.000e+4 elements
```

| Tool number | What it is | Reconciliation |
|---|---|---|
| Optimized FLOP count `2.4e6` | best pairwise path | `= 2 × 1.2e6 MACs` — the tool counts 1 multiply + 1 add per MAC |
| Naive FLOP count `1.8e9` | **one fused loop over all four letters, no pairwise decomposition** | `= 3 × (1000·20·1000·30)` — per innermost iteration, 2 multiplies + 1 add for three operands |
| Theoretical speedup `750` | naive ÷ optimized | **not** left-to-right ÷ optimized, which is ≈42× |
| Largest intermediate `3.0e4` | includes the **output** | output is `1000×30 = 30,000`; the `BC` intermediate is only 600 |

**This is the exercise.** Three different numbers, three different baselines, and the one people quote (`750×`) is the one that corresponds to no real implementation. Version 1 of this tutorial made exactly this mistake. When you report a speedup, name the baseline.

**E21.** The broadcast intermediate is `(50000, 50000, 512)` = 1.28×10¹² elements ≈ **5.1 TB** in float32. The process dies instantly.

```python
sim = torch.einsum('id,jd->ij', queries, keys)      # or queries @ keys.T
```

Now the only large allocation is the `(50000, 50000)` output: 2.5×10⁹ elements = **10 GB** in float32. Still large — in a real system you would chunk over `i` — but it is the unavoidable size of the answer rather than a wasted intermediate.

Attention scores at `B=4, H=16, T=4096`, float16:
$$4 \times 16 \times 4096 \times 4096 \times 2 = 2{,}147{,}483{,}648 \text{ bytes} = 2.0 \text{ GiB}$$
per score tensor, per layer — and autograd keeps the post-softmax copy too. Multiply by layer count and the case for fused attention is obvious.

**E22.** Most likely cause: **`opt_einsum` is not installed on the deployment box**, so PyTorch silently falls back to left-to-right contraction. Check:
```python
import torch.backends.opt_einsum as oe
print(oe.is_available(), oe.enabled, oe.strategy)      # expect: True True auto
```
Fix by adding `opt-einsum` to deployment requirements, and consider asserting availability at startup.

Two other hypotheses worth ruling out: **thread count** (VII.3 shows a 5.6× swing on the same machine from threads alone — a small contraction can be *slower* with more threads because dispatch overhead dominates), and a **CPU-only build or different BLAS backend** where you expected CUDA/MKL. Rule these out by printing `torch.get_num_threads()`, `torch.__config__.show()`, and the device of the tensors.

---

# Appendix C — Quiz answers

**A1.** `j` appears in the inputs but not the output, so it is **contracted** — summed over. It becomes the accumulation loop in the loop expansion, and its length must match in both operands.

**A2.** To differentiate with respect to operand *m*, swap operand *m*'s subscript string with the output's subscript string and replace operand *m* by `grad_output`; everything else stays put.

**A3.** (i) Every letter in the differentiated operand's subscript must appear in the output or another operand — otherwise compute without that letter and `.expand` along it. (ii) The **differentiated** operand must not have a repeated letter — otherwise the forward is a diagonal gather and the gradient is a scatter (`torch.diag`, `g*torch.eye(n)`). (iii) The operand must not rely on size-1 broadcasting — otherwise `.sum(dim, keepdim=True)` the naive result back to shape.

**A4.** No — it is a **composite** op, lowered to `permute`, `reshape`, `mul`, `sum`, `bmm`. `grad_fn` shows something like `<ViewBackward0>`, never `EinsumBackward`. Consequences: double backward works for free (verified by `gradgradcheck`), and profilers show `bmm`/`permute`/`copy_` rather than an `einsum` kernel.

**A5.** For **two** operands, MACs = product of the sizes of all distinct letters. It fails for three or more because the computation is performed as a sequence of *pairwise* contractions, and a good ordering never visits all index combinations — in this document's own example the all-letters product overstates the real cost by 2000×.

**A6.** Roughly **2× forward**, and **independent of operand count**, because PyTorch differentiates the decomposed pairwise chain and each pairwise contraction contributes two gradient contractions. Measured here: 2.3× for a two-operand case, 1.1× for a thin three-operand chain. (Memory, unlike time, *does* grow with operand count, since pairwise intermediates stay alive for backward.)

**A7.** With two operands there is exactly one pairwise contraction, so there is no ordering choice. With three or more, different pairings produce different intermediates, and intermediate size drives both FLOPs and memory — 400× in arithmetic and 160,000× in memory for the VII.1 example.

**A8.** Whether `opt_einsum` is installed and enabled on that machine (`torch.backends.opt_einsum.is_available()`). If `False`, PyTorch silently uses left-to-right. Second check: `opt_einsum.contract_path(...)` and read `Largest intermediate`.

**A9.** It extracts the main diagonal. A repeated letter inside one operand indexes **both** axes with the same variable — a gather along the diagonal, not a sum of products over independent indices. That is exactly why its gradient is a scatter rather than an `einsum`.

**A10.** `float64`. `gradcheck` compares your analytic gradient against finite differences; in `float32` the truncation and round-off noise is comparable to the quantity being measured, producing false failures.

**A11.** It **silently broadcasts**, returning `(3,4)` equal to `a*b` — no error. Dangerous because a stray singleton axis produces plausible numbers instead of a crash, and because the naive backward then has the wrong shape. Defend by asserting shapes at function boundaries and testing with distinct, non-divisible dimension sizes.

**A12.** Any three of: a fused kernel exists (`scaled_dot_product_attention`, `conv2d`) and will be faster with far less memory; the operation is elementwise, a plain transpose, or a plain sum, where `a*b` / `A.T` / `A.sum(1)` are clearer; the axes are selected by position at runtime (use `tensordot`); the string exceeds ~8 letters (use `einops.einsum`); the output is a large expansion you immediately reduce; the model targets a constrained export runtime you have not tested.

**A13.** (1) **Against what baseline?** — "25× faster" than a naive left-to-right path, than a hand-written matmul chain, and than a fused kernel are three different claims. (2) **What was the methodology?** — dtype, device, thread count, warmup, repetition count, median or mean. (3) **Does the arithmetic support it?** — count MACs and intermediate bytes; if the FLOP ratio does not explain the timing, one of the two numbers is wrong. VII.3 of this tutorial shows the *same* benchmark yielding 25×, 55×, and 140× on one machine from dtype and thread count alone.

**A14.** Softmax maps $-\infty$ to exactly zero probability **and** removes the masked position from the normalizing denominator, so the surviving weights still sum to 1 and the gradient through masked positions is exactly zero. A multiplicative 0/1 mask applied *after* softmax zeroes the weights but leaves the denominator computed over all positions, so the remaining weights sum to less than 1 — silently down-weighting every unmasked token. It is a common and hard-to-spot bug.

---

*Every claim in this document is asserted in the companion script `einsum_verify.py`, which reports 79 passed, 0 failed on PyTorch 2.14.0 / NumPy 2.4.4 / einops 0.8.2 / opt_einsum 3.4.0. Timings are from a CPU container and are labelled as illustration, not specification. If a check fails on your machine, trust the script over the prose — and please treat any tutorial that cannot be checked this way with corresponding suspicion.*
