# Pydantic for AI Engineers

A self-study course in three Jupyter notebooks for engineers who know Python but are new to Pydantic:
from data validation fundamentals to structured LLM outputs, tool calling, and agents.

| Notebook | Part | Core path | Everything |
|---|---|---|---|
| `1_pydantic_fundamentals.ipynb` | I. Pydantic fundamentals | 3.9 h | 5.0 h |
| `2_pydantic_llms_and_agents.ipynb` | II. Pydantic for LLMs and agents | 4.7 h | 5.5 h |
| `3_capstone_and_interview_prep.ipynb` | III. Capstone and interview prep | 2.3 h | 3.2 h |
| **Total** | | **10.9 h** | **13.8 h** |

Times are estimates for a learner new to Pydantic. The *core path* covers sections marked Core plus core exercises;
deep-dive sections and optional exercises add depth. Section-by-section estimates are in each notebook's roadmap.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate            # Windows: .venv\Scripts\activate
pip install -r requirements.txt jupyterlab
jupyter lab
```

With uv: `uv venv` then `uv pip install -r requirements.txt jupyterlab`. A plain `uv venv` contains no `pip`, so the
notebooks' `%pip install` cell won't work there; skip it (you've already installed everything) or create the
environment with `uv venv --seed`.

Python **3.11+** is required: Pydantic itself supports 3.10, but several pinned libraries (pydantic-ai-slim,
pydantic-settings, langchain, fastapi, httpx2) require 3.11 or newer. Verified on Python 3.11, 3.12 and 3.13.
`requirements.txt` pins the exact versions the notebooks were verified with. Each notebook also has an install
cell with the same pins and a version check.

No API key is needed. Optional "LIVE" cells call OpenAI or Anthropic if `OPENAI_API_KEY` / `ANTHROPIC_API_KEY`
are set (this costs money).

## What was verified (November 2026)

* All code cells of all three notebooks were executed top to bottom in a Jupyter kernel with the pinned versions.
* All exercise solutions were run against their tests; the exercise stubs were also run to confirm the notebooks
  work end to end before any exercise is attempted.
* **Not verified:** the LIVE cells were executed only in their "skipped" branch (no API keys were available).
  Their code follows the official SDK docs and was checked against the SDKs' signatures and against mocked HTTP
  responses, but no real request was made. Default model names are examples taken from the SDKs' type definitions.

## How exercises work

Each exercise has a code cell for your solution, followed by a **collapsed test cell** (hidden in JupyterLab and
Notebook 7; other editors may show it). Run your cell, then the test cell, and read the ✅ / ❌ / ⏳ result.
Solutions are in a collapsible block after each exercise.
