module f3 #(parameter F = "x.hex") (input logic [1:0] a, output logic [7:0] y);
  logic [7:0] m [0:3]; initial $readmemh(F, m); assign y = m[a];
endmodule
