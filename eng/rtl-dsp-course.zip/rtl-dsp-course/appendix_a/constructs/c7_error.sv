module c7(input logic clk, a, b, output logic y);
  always_ff @(posedge clk) y <= a & b;
  always @(posedge clk) if (a && b) $error("both high");
endmodule
