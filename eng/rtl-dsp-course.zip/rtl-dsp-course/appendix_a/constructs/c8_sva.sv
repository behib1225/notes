module c8(input logic clk, a, output logic y);
  always_ff @(posedge clk) y <= a;
  assert property (@(posedge clk) a |=> y);
endmodule
