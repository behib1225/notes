module f4 #(parameter int W = 8) (input logic signed [W-1:0] a, output logic signed [W:0] y);
  assign y = -((W+1)'(a));
endmodule
