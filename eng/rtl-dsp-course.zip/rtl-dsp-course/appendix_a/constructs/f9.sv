module f9(input logic [3:0] a, output logic is_match);
  assign is_match = (a == 4'd5);
endmodule
