module f8(input logic clk, a, output logic y);
  always_ff @(posedge clk) y <= a;
`ifndef SYNTHESIS
  logic a_d = 1'b0;
  always @(posedge clk) begin a_d <= a; if (a_d && !y) $error("y did not follow a"); end
`endif
endmodule
