module c10(input logic clk, input logic [2:0] c, input logic d, output logic [7:0] m);
  function automatic logic [2:0] rev(input logic [2:0] v); rev = {v[0], v[1], v[2]}; endfunction
  always_ff @(posedge clk) m[rev(c)] <= d;
endmodule
