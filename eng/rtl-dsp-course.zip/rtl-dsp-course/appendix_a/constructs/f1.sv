module f1(input logic clk, x, output logic y);
  typedef enum logic {A, B} st_t; st_t s, n;
  always_comb if (x) n = B; else n = A;
  always_ff @(posedge clk) s <= n;
  assign y = (s == B);
endmodule
