module c2(input logic [3:0] a, output logic [3:0] y);
  function automatic logic [3:0] inc(input logic [3:0] v); return v + 1'b1; endfunction
  assign y = inc(a);
endmodule
