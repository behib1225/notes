#!/bin/sh
# check_portable.sh -- Appendix A: every portable form (f*.sv) must pass Icarus, Verilator and Yosys.
# (The non-portable originals, c*.sv, are kept to show each tool's error message.)
fail=0
printf "00\n01\n02\n03\n" > x.hex                 # the small table that f3.sv and c3_string_param.sv read
for f in f*.sv; do
  t=${f%.sv}
  iverilog -g2012 -Wall -o /dev/null "$f" 2>&1 | grep -qiE "error|sorry" && { echo "FAIL icarus: $f"; fail=1; }
  verilator --lint-only -Wall -Wno-DECLFILENAME --top-module "$t" "$f" > /dev/null 2>&1 || { echo "FAIL verilator: $f"; fail=1; }
  yosys -q -p "read_verilog -sv $f; synth -top $t" > /dev/null 2>&1 || { echo "FAIL yosys: $f"; fail=1; }
done
[ $fail = 0 ] && echo "PASS: all portable forms accepted by Icarus, Verilator and Yosys"
exit $fail
