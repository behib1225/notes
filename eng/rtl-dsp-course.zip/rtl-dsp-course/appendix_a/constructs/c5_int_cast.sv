module c5(input logic [3:0] k, output logic [31:0] y);
  assign y = int'(k) + 1;
endmodule
