module c9(input logic [3:0] a, output logic matches);
  assign matches = (a == 4'd5);
endmodule
