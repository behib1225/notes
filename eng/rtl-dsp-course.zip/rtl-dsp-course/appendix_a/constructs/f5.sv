module f5(input logic [3:0] k, output logic [31:0] y);
  assign y = 32'(k) + 1;
endmodule
