module f6(input logic [7:0] a, output logic [3:0] y);
  always_comb begin
    logic found; y = 0; found = 1'b0;
    for (int i = 0; i < 8; i++) if (a[i] && !found) begin y = 4'(i); found = 1'b1; end
  end
endmodule
