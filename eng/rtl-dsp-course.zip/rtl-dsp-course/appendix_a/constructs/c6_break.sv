module c6(input logic [7:0] a, output logic [3:0] y);
  always_comb begin
    y = 0;
    for (int i = 0; i < 8; i++) begin if (a[i]) begin y = 4'(i); break; end end
  end
endmodule
