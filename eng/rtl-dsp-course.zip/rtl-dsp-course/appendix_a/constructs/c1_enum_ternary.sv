module c1(input logic clk, x, output logic y);
  typedef enum logic {A, B} st_t; st_t s, n;
  always_comb n = x ? B : A;
  always_ff @(posedge clk) s <= n;
  assign y = (s == B);
endmodule
