// axis_if.sv -- an AXI4-Stream interface with modports
interface axis_if #(parameter int W = 32) (input logic clk);
  logic         tvalid, tready, tlast;
  logic [W-1:0] tdata;
  modport src (output tvalid, tdata, tlast, input  tready);
  modport snk (input  tvalid, tdata, tlast, output tready);
endinterface
