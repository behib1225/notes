module tb_order; import dsp_pkg::*; cq15_t c; initial begin c.re = 16'h1234; c.im = 16'habcd; $display("packed value %h (re first = high half)", c); end endmodule
