// cswap.sv -- multiplies a complex sample by j (re' = -im, im' = re), registered, with saturation.
// Types are named with the package prefix: Yosys 0.33 rejects "module m import pkg::*; (...)".
module cswap (
  input  logic          clk,
  input  dsp_pkg::cq15_t din,
  output dsp_pkg::cq15_t dout
);
  always_ff @(posedge clk) begin
    dout.re <= dsp_pkg::sat16(-(32'(din.im))); // -(-32768) = +32768 saturates to 32767
    dout.im <= din.re;
  end
endmodule
