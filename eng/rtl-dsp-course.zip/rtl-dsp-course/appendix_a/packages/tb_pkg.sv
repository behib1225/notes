module tb_pkg;
  import dsp_pkg::*;
  logic clk = 0; cq15_t din, dout; int errors = 0;
  cswap dut (.*);
  always #5 clk = ~clk;
  initial begin
    for (int i = 0; i < 2000; i++) begin
      din.re = $urandom; din.im = (i == 0) ? -16'sd32768 : 16'($urandom);
      @(posedge clk); #1;
      if (dout.re !== sat16(-(32'(din.im))) || dout.im !== din.re) errors++;
    end
    $display("%s: package, packed struct and function, %0d errors; j*(-1j) case: re = %0d", errors ? "FAIL" : "PASS", errors, 0);
    $finish;
  end
endmodule
