// dsp_pkg.sv -- shared types and constants for the course's designs
package dsp_pkg;
  localparam int XW = 16;
  typedef logic signed [XW-1:0] q15_t;                 // a Q1.15 sample
  typedef struct packed { q15_t re; q15_t im; } cq15_t; // a complex Q1.15 sample: 32 bits
  function automatic q15_t sat16(input logic signed [31:0] v);
    if (v > 32'sd32767)       sat16 = 16'sd32767;
    else if (v < -32'sd32768) sat16 = -16'sd32768;
    else                      sat16 = 16'(v);                 // not q15_t'(v): Yosys 0.33 rejects casts to a user type
  endfunction
endpackage
