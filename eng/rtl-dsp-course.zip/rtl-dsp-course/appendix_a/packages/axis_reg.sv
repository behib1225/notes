// axis_reg.sv -- a pass-through register stage using the interface (forward path only, for the test)
module axis_reg (input logic clk, rst, axis_if.snk s, axis_if.src m);
  assign s.tready = m.tready || !m.tvalid;
  always_ff @(posedge clk) begin
    if (rst) m.tvalid <= 1'b0;
    else if (s.tready) begin m.tvalid <= s.tvalid; m.tdata <= s.tdata; m.tlast <= s.tlast; end
  end
endmodule
