module top_if (input logic clk, rst, input logic v, input logic [31:0] d, output logic [31:0] q, output logic qv, input logic r);
  axis_if #(32) a (clk), b (clk);
  assign a.tvalid = v; assign a.tdata = d; assign a.tlast = 1'b0;
  axis_reg u (.clk(clk), .rst(rst), .s(a), .m(b));
  assign b.tready = r; assign q = b.tdata; assign qv = b.tvalid;
  wire unused = a.tready ^ b.tlast;
endmodule
