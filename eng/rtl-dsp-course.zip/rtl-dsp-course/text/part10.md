# Verilog & RTL for DSP — Part 10: Multirate Processing

*Markdown export of the online document: https://claude.ai/artifact/GVcqMPYuqVkNVuUWDUAXgQ. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 10 fits

After the mixer of Part 9 has moved a narrow signal down to 0 Hz, the receiver no longer needs the high sample rate it started with. A 2 MHz-wide signal sampled at 100 MHz carries 50 times more samples than it needs, and every one of them costs power and arithmetic. **Multirate processing** changes the sample rate: **decimation** reduces it and **interpolation** increases it.

The catch is Part 5's oldest lesson: reducing the sample rate is sampling again, so it aliases unless the signal is filtered first. This part shows how to do that filtering cheaply, using two ideas that make multirate hardware far more efficient than it first appears:

1. **Compute only the outputs you keep.** A filter followed by "throw away 3 out of 4 samples" wastes 75% of its multiplications. A decimating filter skips them (10.2).
2. **CIC filters** decimate by large factors with no multipliers at all, using only adders and registers, and they do it correctly even though their internal registers overflow constantly (10.3).

Section 10.4 then combines the two into a **decimation chain**, a CIC filter followed by a small FIR filter, and shows with numbers why this is how practically every digital receiver is built. It is the back half of the digital down-converter of Part 12.

As always, every number comes from code that was run: Python 3 with NumPy and SciPy, Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33. This part reuses `fixedpoint.py`, `requant.sv` and `mac.sv` (Part 6), and the coefficients and golden model of the 32-tap filter (`fir_model.py`, Part 7).

## 10.1 Decimation and interpolation

**Decimating** by M keeps one sample in every M; **interpolating** by L inserts L − 1 new samples between each pair. Both change where frequencies appear, and both need a low-pass filter to stay correct: before decimation to prevent aliasing, after interpolation to remove images.

### Downsampling and aliasing

Keeping every M-th sample, y\[m\] = x\[mM\], is sampling at a new rate f\_s/M. Every frequency above the new Nyquist frequency, f\_s/(2M), folds back by the rule of Part 5.

A demonstration: a wanted tone at 0.05 cycles per sample and an unwanted one at 0.2, both of amplitude 0.5, downsampled by M = 4 **without** filtering. Measured in cycles per sample at the **new** rate:

```python
x = 0.5 * np.cos(2 * np.pi * 0.05 * n) + 0.5 * np.cos(2 * np.pi * 0.2 * n + 1.0)
d = x[::4]                                   # keep every 4th sample
```

- The wanted tone moves to 0.05 × 4 = **0.2** of the new rate. Measured alone: amplitude 0.5, as expected.
- The unwanted tone moves to 0.2 × 4 = 0.8, which folds to 1 − 0.8 = **0.2**, exactly on top of the wanted one. Measured alone: also amplitude 0.5.
- Together they produce a single component at 0.2 of amplitude 0.878 (the two tones add with a phase difference). The two can no longer be separated, by any processing.

Filtering **first** with the 32-tap low-pass filter of Part 7 (cutoff 0.1) reduces the unwanted tone's residue at 0.2 to an amplitude of 0.00044, **61 dB** below its original level, while the wanted tone passes. The rule:

**Before decimating by M, low-pass filter to below f\_s/(2M).**

### Upsampling and images

Interpolating by L starts with **zero-stuffing**: insert L − 1 zeros after each sample. That raises the sample rate but adds no new information, and in the spectrum it creates copies, called **images**, of the original spectrum around every multiple of the original sample rate.

Upsampling a tone at 0.1 cycles per sample by L = 4 puts it at 0.1/4 = **0.025** of the new rate, as intended. But the spectrum also shows peaks at **0.225**, **0.275**, and so on: images at k/4 ± 0.025. A low-pass filter at the new rate, cutting off below 0.125 of the new rate (the old Nyquist frequency), removes them. The filter's output then holds smooth new samples between the original ones: that is what "interpolation" means.

### Rate changes in practice

| Operation | Order | The filter removes | Typical use |
| --- | --- | --- | --- |
| Decimation by M | Filter, then keep every M-th sample | Everything that would alias, above f\_s/(2M) | Receivers, data acquisition, audio downsampling |
| Interpolation by L | Insert zeros, then filter | The images above the old Nyquist | Transmitters, DACs, audio upsampling |
| Rational change L/M | Interpolate by L, then decimate by M | Both, with one filter | 44.1 kHz ↔ 48 kHz audio conversion |

In both directions, the filter operates at the **higher** sample rate. Done naively, that is expensive. The next two sections make it cheap.

### Check your understanding: 10.1

1. A signal sampled at 48 kHz is decimated by 3. What is the new sample rate, and what cutoff must the anti-aliasing filter have?
2. Without filtering, where does a tone at 20 kHz (in the 48 kHz signal) appear after decimation by 3?
3. A tone at 1 kHz, sampled at 8 kHz, is zero-stuffed by L = 2. At which frequencies does the 16 kHz output have components?
4. Why does zero-stuffing create images?
5. Why must the anti-aliasing filter come before downsampling, not after?

#### Answers

1. **16 kHz**; the filter must remove everything above the new Nyquist frequency, **8 kHz** (in practice it starts cutting a little below, to leave a transition band).
2. At the new rate of 16 kHz, 20 kHz mod 16 = 4 kHz, which is below 8 kHz: it appears at **4 kHz**, inside the band.
3. The original 1 kHz tone, and its image around the old sample rate, 8 − 1 = **7 kHz** (and 8 + 1 = 9 kHz, which at 16 kHz is the mirror of 7 kHz). The interpolation filter must remove the 7 kHz image.
4. The zero-stuffed signal equals the original samples multiplied by a pulse train at the old sample rate. Multiplying by a periodic pulse train copies the spectrum around each harmonic of the pulse rate, which are the multiples of the old sample rate.
5. Once the samples are discarded, the unwanted frequencies have already folded onto the wanted band and are indistinguishable from it. Filtering afterwards would remove the wanted signal along with them.

## 10.2 The decimating FIR filter

A filter followed by "keep one sample in M" computes M outputs and throws M − 1 of them away. A **decimating filter** computes only the one it keeps, so it needs M times fewer multiplications. The idea is simple; this section builds it in RTL by reusing the serial architecture and the MAC unit from earlier parts.

### Only the kept outputs

The decimated output is y\[m\] = Σ h\[k\] x\[mM + M − 1 − k\]: the filter output at every M-th input sample, here the one computed just after the M-th sample arrives. Every input sample still enters the delay line, but the N multiply-accumulates are performed only once per **output**. For the 32-tap filter of Part 7 and M = 4:

|  | Filter, then discard | Decimating filter |
| --- | --- | --- |
| MACs per input sample | 32 | 8 |
| MACs per output sample | 128 | 32 |

### Polyphase thinking

Another way to see the saving: split the coefficients into M **phases**. Phase p holds h\[p\], h\[p + M\], h\[p + 2M\], …, and each phase only ever multiplies samples that arrive at one particular position within each group of M. A **polyphase** decimator gives each phase its own small filter running at the low output rate and adds their outputs. It does exactly the same arithmetic as the decimating filter below, but arranged so that every multiplier works at the output rate, which suits fully parallel hardware. Interpolators use the same trick in reverse: the zeros inserted by zero-stuffing would multiply coefficients for nothing, and a polyphase interpolator never computes those products.

### The RTL

The design is Part 7's serial FIR with one change: the controller collects M samples before each computation.

```systemverilog
`timescale 1ns/1ps
// fir_decim.sv -- decimating FIR: y[m] = sum_k h[k] x[mM + M-1 - k], one output per M inputs.
// Only the outputs that are kept are computed: N MACs per OUTPUT, not per input.
// One MAC (mac.sv, Part 6) is reused for all taps.
module fir_decim #(
  parameter int N = 32, M = 4,
  parameter int XW = 16, XF = 15, CW = 18, CF = 17, YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int KW = $clog2(N), MW = (M > 1) ? $clog2(M) : 1;

  typedef enum logic {S_COLLECT, S_RUN} state_t;
  state_t               state;
  logic [MW-1:0]        phase;                     // samples collected toward the next output
  logic [KW-1:0]        k;                         // tap fed to the MAC this cycle
  logic signed [XW-1:0] taps [0:N-1];

  assign in_ready = (state == S_COLLECT);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_COLLECT;  phase <= '0;  k <= '0;
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else begin
      case (state)
        S_COLLECT: if (in_valid) begin             // accept a sample: shift it in
          taps[0] <= x;
          for (int i = 1; i < N; i++) taps[i] <= taps[i-1];
          if (phase == MW'(M - 1)) begin           // M-th sample: compute one output
            phase <= '0;  k <= '0;  state <= S_RUN;
          end else begin
            phase <= phase + 1'b1;
          end
        end
        S_RUN: begin
          k <= k + 1'b1;
          if (k == KW'(N - 1)) state <= S_COLLECT;
        end
        default: state <= S_COLLECT;
      endcase
    end
  end

  logic mac_ovf_unused;
  mac #(.A_W(XW), .A_F(XF), .B_W(CW), .B_F(CF), .ACC_W(XW + CW + KW + 1),
        .OUT_W(YW), .OUT_F(YF)) u_mac (
    .clk(clk), .rst(rst),
    .in_valid(state == S_RUN), .first(k == '0), .last(k == KW'(N - 1)),
    .a(taps[k]), .b(fir_coef(32'(k))),
    .out_valid(out_valid), .dout(y), .dout_ovf(mac_ovf_unused)
  );
endmodule
```

The golden model is one line on top of Part 7's: `fir_golden(x, coefficients())[M - 1 :: M]`, the full-rate output with only every M-th sample kept, starting from sample M − 1.

### A testbench for decimators

Part 7's testbench expects one output per input. `tb_decim.sv` is the same file with three changes: it reads the decimation factor as a plusarg (`+M=4`), expects n/M outputs, and passes a parameter override to the design through a macro, `` `DUT #(`DUT_PARAMS) dut (...) ``. The run script sets both:

```sh
if [ "$DUT" = cic_decim ]; then P=".R($M)"; else P=".M($M)"; fi
iverilog -g2012 -Wall -DDUT="$DUT" -DDUT_PARAMS="$P" -o sim_$DUT "$DUT.sv" requant.sv mac.sv tb_decim.sv
vvp -n sim_$DUT +N="$N" +M="$M" +SEED="$SEED"
```

That macro was added after the first runs: with only the testbench told about M = 2, the design kept its default M = 4, and the run ended in `TIMEOUT` (the testbench waited for 2,000 outputs that never came). With M = 8 it produced `FAILED: 498 of 500 outputs wrong`. A parameter has to reach every place that depends on it.

With the fix, the design is bit-exact for M = 1, 2, 4 and 8 on 4,000 inputs, and on two more seeds. The clock counts show the saving: **132,007** cycles for M = 1 (33 cycles per input, exactly Part 7's serial filter) and **36,753** for M = 4 (about 37 cycles per output, of which 32 are MACs). Yosys reports one DSP48E1, as for the serial FIR.

### Check your understanding: 10.2

1. A 64-tap filter decimates by 8. How many MACs per input sample does a decimating implementation need?
2. List the coefficients in phase 1 of the 32-tap filter for M = 4.
3. Why does a decimating filter still have to shift every input sample into the delay line?
4. With a 100 MHz clock and one MAC, what is the highest input sample rate for the 32-tap filter at M = 4?
5. Why did the M = 2 run end in a timeout rather than a bit mismatch?

#### Answers

1. 64 MACs per output, one output per 8 inputs: **8 MACs per input**, instead of 64.
2. h\[1\], h\[5\], h\[9\], h\[13\], h\[17\], h\[21\], h\[25\], h\[29\]: every 4th coefficient starting from index 1.
3. Each output uses the last N input samples, including those that arrived between outputs. The samples are needed even though the outputs at their positions are never computed.
4. Each output needs 32 MAC cycles plus the cycles that collect 4 samples, so about 36 cycles per 4 inputs (as measured, about 37 with the testbench's gaps). 100 MHz / 36 × 4 ≈ **11 million input samples per second**.
5. The design, still at M = 4, produced one output per 4 inputs: 1,000 outputs for 4,000 inputs. The testbench, told M = 2, waited for 2,000. It never saw a wrong value, only too few values, so the watchdog fired.

## 10.3 CIC filters

The **cascaded integrator-comb** (CIC) filter, invented by Eugene Hogenauer in 1981, decimates by large factors using only adders and registers. It is a moving-average filter (Part 5) repeated N times, rearranged so that most of the work happens at the low output rate and no multiplier is needed at all.

### From moving average to CIC

A moving sum of R samples has the transfer function

```latex
H_1(z) = 1 + z^{-1} + \cdots + z^{-(R-1)} = \frac{1 - z^{-R}}{1 - z^{-1}}
```

The right-hand form splits it into two simple parts: an **integrator**, 1/(1 − z⁻¹), which is a running sum, y\[n\] = y\[n−1\] + x\[n\]; and a **comb**, 1 − z⁻ᴿ, which subtracts the input R samples ago. Cascading N such filters gives H(z) = ((1 − z⁻ᴿ)/(1 − z⁻¹))ᴺ.

Now the trick. When the filter is followed by decimation by R, the comb's delay of R input samples is a delay of exactly **one output sample**. So the combs can be moved after the decimation, where they run at the low rate with a delay of 1. The result: N integrators at the input rate, a decimator, then N combs at the output rate.

> **Figure:** cic\_decim.sv with N = 3 (shown in the [online version](https://claude.ai/artifact/GVcqMPYuqVkNVuUWDUAXgQ))

### Gain and bit growth

The gain at 0 Hz is Rᴺ: each moving sum of R samples multiplies a constant by R. So the internal registers need N·log₂ R extra bits. For R = 8 and N = 3: 3 × 3 = **9 extra bits**, so a 16-bit input needs **25-bit** registers, and the gain is 8³ = 512 = 2⁹, removed at the output by dropping 9 bits with `requant`. That is Hogenauer's register-width rule.

### Why overflow does not matter

An integrator is a running sum with no feedback coefficient: fed a constant, it grows forever. With any fixed register width, it **will** overflow, over and over. Remarkably, that is fine: in two's-complement arithmetic, wrap-around is arithmetic modulo 2ᵂ, and addition and subtraction remain exactly correct modulo 2ᵂ. The combs subtract the wrapped values, and the final result is the true result modulo 2ᵂ. Since the true output is guaranteed to fit in W bits (that is what the register-width rule ensures), it comes out exactly right.

This was checked directly. Over the 4,000-sample test stimulus, the integrators of the R = 8 model **wrapped 1,049 times**, yet every output was identical to an unbounded-precision version of the same filter, and identical to filtering with three length-8 moving sums followed by keeping every 8th sample (with a 4-sample delay). Two conditions make it work: the registers must **wrap**, never saturate, and they must be at least the width given by the rule. Saturation, so important in Part 8, would break the CIC completely.

### The RTL

```systemverilog
`timescale 1ns/1ps
// cic_decim.sv -- CIC decimator: NS integrators at the input rate, decimate by R,
// NS combs at the output rate. No multipliers. All internal arithmetic WRAPS
// (W = XW + NS*log2(R) bits), which is correct for a CIC filter.
module cic_decim #(
  parameter int R  = 8,                         // decimation factor
  parameter int NS = 3,                         // number of integrator/comb stages
  parameter int XW = 16, XF = 15,
  parameter int W  = XW + NS * $clog2(R)        // 25 bits for R = 8, NS = 3
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  localparam int RW = (R > 1) ? $clog2(R) : 1;
  assign in_ready = 1'b1;

  logic signed [W-1:0] integ  [0:NS-1];         // integrators (input rate)
  logic signed [W-1:0] comb_d [0:NS-1];         // comb delay registers (output rate)
  logic signed [W-1:0] c      [0:NS];           // comb chain, combinational
  logic [RW-1:0]       cnt;
  logic                dec;                     // this input completes a group of R

  assign dec = in_valid && (cnt == RW'(R - 1));

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < NS; k++) begin integ[k] <= '0; comb_d[k] <= '0; end
      cnt <= '0;
    end else if (in_valid) begin
      // integrators: y[n] = y[n-1] + input; overflow wraps, by design
      integ[0] <= integ[0] + W'(x);
      for (int k = 1; k < NS; k++) integ[k] <= integ[k] + integ[k-1];
      cnt <= dec ? '0 : cnt + 1'b1;
      // combs: once per R inputs, y = input - input delayed by one output sample
      if (dec) for (int k = 0; k < NS; k++) comb_d[k] <= c[k];
    end
  end

  always_comb begin
    c[0] = integ[NS-1];
    for (int k = 0; k < NS; k++) c[k+1] = c[k] - comb_d[k];
  end

  // gain is R**NS = 2**(NS*log2 R): drop those bits with rounding, saturate to Q1.15
  logic signed [XW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(W), .IN_F(XF + NS * $clog2(R)), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1))
    u_rq (.din(c[NS]), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= dec;
    if (dec) y <= y_c;
  end
endmodule
```

Notes:

- **Pipelined integrators.** `integ[k] <= integ[k] + integ[k-1]` uses the **previous** value of the stage before, so each stage adds one sample of delay. That only delays the output; it keeps each adder's path short, and the integrators can run at the full clock rate.
- **The combs** are combinational between their delay registers, and their delays update only on decimation cycles: one comb step per output.
- **`R` must be a power of two** here, so that the gain is removed by a shift. Other values of R need a final multiplication by 1/Rᴺ (Exercise 3).

### Verification, and an off-by-one

The Python model simulates the registers exactly, with W-bit wrap-around: `wrap = lambda v: ((v + half) & mask) - half`. The first comparison failed: `FAIL sample 1: got 480 expected 672`. The model's comb took the last integrator's value **after** the current input's update, while the RTL's combinational comb sees the register **before** it. Both are correct CIC filters, one sample apart, but bit-exact verification needs the model to copy the hardware's timing exactly. After the fix (`c = old[N - 1]`, with a comment), the RTL was bit-exact for **R = 2, 4, 8 and 16**, and on two more seeds at R = 8.

Yosys reports **no DSP blocks**: about 200 LUTs, 50 `CARRY4` and 170 flip-flops for the whole decimate-by-8 filter.

### The frequency response

The magnitude response is the moving average's, raised to the power N:

```latex
|H(f)| = \left| \frac{\sin(\pi f R)}{R \sin(\pi f)} \right|^N
```

> **Figure:** |sin(πfR)/(R sin(πf))|³ for R = 8, clipped at −120 dB (shown in the [online version](https://claude.ai/artifact/GVcqMPYuqVkNVuUWDUAXgQ))

Two facts determine how a CIC is used:

- **Its nulls land exactly where aliasing comes from.** After decimation by R, the frequencies that fold onto 0 Hz are the multiples of f\_s/R, and the response has zeros of order N at exactly those frequencies. Only the narrow bands around them (the shaded bands) alias into a narrow passband, and there the attenuation is high: for a passband up to f\_out/16, the worst alias is **70.1 dB** down; up to f\_out/8, **50.9 dB**.
- **It droops in the passband.** The response falls smoothly from 0 Hz: at f\_out/4 it is already **−2.69 dB** down. A CIC is therefore never used alone for a wide passband. It is followed by a small FIR filter that compensates the droop and does the final sharp filtering, at the low rate (section 10.4).

### Check your understanding: 10.3

1. What register width does a CIC decimator with R = 64 and N = 4 need for 16-bit input?
2. Why can the combs use a delay of 1 instead of R?
3. The integrators overflow constantly. Why is the output still correct, and what would break it?
4. Why must the CIC's registers wrap rather than saturate, when Part 8 insisted on saturation in feedback?
5. Why is a CIC filter almost always followed by an FIR filter?

#### Answers

1. 16 + 4 × log₂ 64 = 16 + 24 = **40 bits**.
2. After decimation by R, R input samples are one output sample. A delay of R at the input rate, moved past the decimator, becomes a delay of 1 at the output rate.
3. Two's-complement addition and subtraction are exact modulo 2ᵂ, so the wrapped intermediate values still produce the true output modulo 2ᵂ, and the register-width rule guarantees that the true output fits in W bits. Saturating, or using fewer bits than the rule requires, would break it.
4. In an IIR filter, a wrapped value is fed back as a large error into a resonant loop. In a CIC, the integrator's wrap is undone exactly by the later subtractions: the combs compute differences, and differences of modular values are correct as long as the true difference fits. Saturation would destroy that exactness.
5. Its passband droops (−2.69 dB at f\_out/4 for R = 8, N = 3), and its transition from passband to stopband is very gradual. A short FIR filter at the low rate corrects the droop and provides the sharp cutoff, cheaply.

## 10.4 Designing a decimation chain

Real receivers decimate in stages: a CIC filter does most of the rate reduction cheaply at the high rate, and a small FIR filter at the low rate fixes the CIC's droop and provides the sharp cutoff. This section designs such a chain for a realistic case and counts the cost, which is also the plan for Part 12.

### The task

A receiver samples at **100 MHz**. After mixing (Part 9), the wanted signal occupies **±1.25 MHz** around 0 Hz. The goal is an output rate of **3.125 MHz**, a decimation by 32, with aliases suppressed by about 60 dB. The anti-aliasing filter must pass 1.25 MHz and block everything that would fold onto ±1.25 MHz at the new rate, which starts at 3.125 − 1.25 = **1.875 MHz**.

### Option A: one big FIR filter

A single decimating FIR at the input rate needs a transition from 1.25 to 1.875 MHz, just 0.625 MHz at a 100 MHz sample rate. `kaiserord(60, ...)` estimates **582 taps**. Even with the decimation trick of 10.2, that is 582 MACs per output, about **1.8 billion MACs per second**: 18 multipliers working flat out at 100 MHz, or about 9 with symmetric pre-adders, plus a 582-entry delay line.

### Option B: CIC, then FIR

1. A **CIC with R = 16, N = 4** takes the rate from 100 MHz to 6.25 MHz (N = 4 is a first choice, to be checked against the 60 dB requirement below; the check will show that it is one stage short). Its registers need 16 + 4 × 4 = 32 bits. It uses 8 adders and **no multipliers**.
2. A **decimate-by-2 FIR** at 6.25 MHz then takes the rate to 3.125 MHz. Its transition from 1.25 to 1.875 MHz is now 0.1 of its sample rate, and `kaiserord(60, ...)` estimates only **38 taps**: about **119 million MACs per second**, less than two multipliers' worth at 100 MHz.

The CIC's limitations, computed from its response:

| CIC property (R = 16, N = 4) | Value |
| --- | --- |
| Droop at the passband edge, 1.25 MHz | −2.31 dB |
| Worst alias attenuation into ±1.25 MHz | 50.3 dB |

Both tell the FIR what to do. It must have a gain that **rises** by about 2.3 dB toward the passband edge, the inverse of the CIC's droop. Such a **CIC compensation filter** is designed with `scipy.signal.firwin2`, which accepts an arbitrary desired gain at a list of frequencies. And 50.3 dB is short of the 60 dB target, and here the FIR cannot help. The 50.3 dB comes from inputs near 5 MHz (6.25 − 1.25 MHz), which fold into ±1.25 MHz already at the CIC's output, on top of the wanted signal: no later filter can separate them, so only the CIC can attenuate them. (The FIR does remove a second family of aliases, the inputs within 1.25 MHz of odd multiples of 3.125 MHz, which land in its stopband at the 6.25 MHz rate.) The fix is a CIC of order N = 5, which steepens every null and raises the CIC's worst attenuation on those bands to 62.9 dB. It costs 36-bit registers instead of 32, 10 adders instead of 8, and a passband droop of 2.9 dB instead of 2.3 dB for the FIR to compensate; Exercise 4 designs the matching FIR. This check-and-revise step is the normal way to size a CIC: choose N, compute the attenuation on every band that folds into the passband, and add a stage if it falls short. One practical note on firwin2: it interpolates the desired gain linearly between the listed frequencies, so ask for a step, by listing one frequency in the middle of the transition band twice (gain 1/H\_CIC, then 0), not a ramp ending at the stopband edge.

### The comparison

|  | One FIR filter | CIC + FIR |
| --- | --- | --- |
| Taps / stages | 582 taps | 5 integrators + 5 combs (N = 5, needed for 60 dB), 34 taps |
| Multiplications per second | about 1.8 billion | about 106 million (34 taps × 3.125 MHz) |
| Multipliers at a 100 MHz clock | about 18 (9 symmetric) | 2 |
| Delay line | 582 samples at 100 MHz | 38 samples at 6.25 MHz |

The chain is roughly **17 times cheaper** in multiplications. This is why the front end of almost every digital receiver, in cellular base stations, software-defined radios and spectrum analyzers, is an NCO, a mixer, a CIC decimator and one or two FIR decimators. Part 12 builds exactly that.

### Check your understanding: 10.4

1. Why must the anti-aliasing filter block from 1.875 MHz, not from the new Nyquist frequency of 1.5625 MHz?
2. Why does the FIR after the CIC need so many fewer taps than the single FIR?
3. Why must the compensation filter's gain rise toward the passband edge?
4. What register width does the CIC need, and why can it still be built without multipliers?
5. If the output rate were 6.25 MHz instead, which stage could be dropped?

#### Answers

1. Only components that land **inside the wanted band** after decimation matter. Frequencies between 1.5625 and 1.875 MHz fold to between 1.25 and 1.5625 MHz, outside ±1.25 MHz, where a later filter can remove them. The first frequency that folds into the wanted band is 3.125 − 1.25 = 1.875 MHz.
2. The number of taps depends on the transition width **relative to the sample rate**. The same 0.625 MHz transition is 0.00625 of 100 MHz but 0.1 of 6.25 MHz: 16 times wider in normalized terms, so roughly 16 times fewer taps.
3. The CIC attenuates the upper part of the passband (−2.31 dB at the edge). The overall response is the product of the two filters, so the FIR must boost those frequencies by the inverse amount to make the total flat.
4. 16 + 4 · log₂ 16 = **32 bits**. Integrators and combs are only additions and subtractions, and the gain of 16⁴ = 2¹⁶ is removed by a shift because R is a power of two.
5. The decimate-by-2 FIR's rate reduction, but not its filtering: the CIC alone would still droop and leak 50 dB aliases, so a compensation FIR (without decimation) would still be needed.

### Half-band filters: a decimate-by-2 stage at a third of the cost

Decimation chains are often built from several stages of **decimation by 2**, and for those there is a special filter that does the job with about half the multiplications of a symmetric FIR of the same length (and under a third of a plain one): the **half-band filter**. Its zero-phase amplitude response is antisymmetric about f\_s/4, A(f) + A(0.5 − f) = 1 (so the gain at f\_s/4 is exactly ½), and in exchange its impulse response has a remarkable structure:

- the **centre tap is exactly ½**;
- **every second tap is exactly zero** (the taps at even distances from the centre, except the centre itself);
- the remaining taps come in symmetric pairs.

A 31-tap half-band filter therefore has only 17 non-zero coefficients, and only **8 distinct ones** plus the centre.

#### Design

Parks–McClellan produces a half-band filter when the bands are symmetric about 0.25 and equally weighted:

```python
h = signal.remez(31, [0, 0.2, 0.3, 0.5], [1, 0])        # pass to 0.2, stop from 0.3
```

It comes out with h\[15\] = 0.499996 and the even-offset taps at about 5 × 10⁻⁶: very nearly, but not exactly, the ideal structure. Before quantizing, **force it exactly**: set the centre to 0.5 and the even-offset taps to 0. Then in Q1.17 the centre is exactly 2¹⁶ = 65,536, the zeros stay zero, and the hardware may skip them. The quantized filter keeps a **57.3 dB** stopband and **0.0118 dB** passband ripple; |H(0.25)| = 0.5000 exactly.

Those two figures are linked, and that is the half-band filter's one limitation: the passband and stopband ripples are equal (here δ ≈ 0.00136, which is both 0.0118 dB and −57.3 dB), and the transition band must be centred on f\_s/4. A 60 dB stopband automatically brings a tiny passband ripple, but you cannot trade one for the other, or move the transition band. For a decimate-by-2 stage that is exactly right: after decimation, frequencies from 0.3 to 0.5 fold onto 0.2 to 0, so a stopband from 0.3 protects an output band from 0 to 0.2 cycles per input sample.

#### The decimator

`fir_hb_decim.sv` keeps the structure of `fir_decim.sv` (collect 2 samples, then compute one output with the Part 6 MAC), but each MAC cycle takes a **pre-added pair** of samples, and the last one takes the centre sample with the coefficient ½:

```systemverilog
  // operand: a pre-added symmetric pair, or the centre sample
  always_comb begin
    if (m < MW'(NP)) begin a = (XW+1)'(taps[ia]) + (XW+1)'(taps[ib]); b = hb_coef(32'(m)); end
    else             begin a = (XW+1)'(taps[C]);                      b = CENTRE;          end
  end
```

with `ia = C − 1 − 2m`, `ib = C + 1 + 2m` and `CENTRE = 1 <<< (CF − 1)`. The coefficient file holds only the 8 distinct values. One output takes **9 MAC cycles instead of 31**.

Because the forced zeros and the exact ½ are part of the quantized coefficients, the half-band decimator computes exactly the same integers as `fir_decim` running all 31 coefficients. Verified with Part 10's testbench (three seeds, random input gaps): **bit-exact**, and identical to `fir_decim` with the same coefficients, in 22,503 clock cycles against 66,503 for the same 4,000 inputs. Both are lint-clean.

|  | `fir_decim` (31 taps) | `fir_hb_decim` |
| --- | --- | --- |
| MAC cycles per output | 31 | **9** |
| DSP48E1 | 1 | 1 |
| LUTs / flip-flops (Yosys) | 305 / 541 | 260 / 555 |
| Multipliers in a fully parallel version | 31 (16 with symmetry) | **9** |

With one shared MAC the saving is throughput: the same multiplier serves 3.4 times the sample rate. In a parallel design it is area: 9 multipliers instead of 16.

This is why practical decimation chains look like **CIC → one or more half-band stages → a short compensating FIR**: the CIC does the large factor without multipliers, the half-bands each halve the rate cheaply, and the last FIR, at the lowest rate, shapes the final passband. The Part 12 DDC could use one: a decimate-by-4 CIC, a half-band, and the compensating FIR.

## 10.5 Exercises

For scale: the worked solutions to these exercises add 3 design files, 2 testbenches and 2 Python scripts, about 340 new lines (not counting the many short checks run inline). Time depends too much on experience for a reliable estimate, so none is given. Reuse `decim_model.py`, `tb_decim.sv` and `run_decim.sh`. Send me your code, tables and plots.

- [ ] Exercise 1: see aliasing in a spectrum
- [ ] Exercise 2: an interpolator
- [ ] Exercise 3: a CIC with any R
- [ ] Exercise 4: design the compensation FIR
- [ ] Exercise 5: a two-stage RTL chain

### Exercise 1: see aliasing in a spectrum

Generate 8,192 samples containing tones at 0.03, 0.11 and 0.21 cycles per sample.

- Decimate by 4 with plain `x[::4]`, then with `fir_decim`'s golden model, and plot both spectra at the new rate. Predict where each tone lands before looking.
- Repeat with the RTL `fir_decim` and check that its output spectrum matches the model's.

### Exercise 2: an interpolator

Build `fir_interp`: interpolation by L = 4 with the 32-tap filter of Part 7, using the polyphase idea: for each input sample, produce 4 outputs, where output p uses only the coefficients h\[p\], h\[p+4\], h\[p+8\], …. No multiplication by an inserted zero may ever be computed.

- Golden model: zero-stuff, then `np.convolve` with h scaled by L (why the scaling?), round once. Verify bit-exactly.
- How many MACs per output does it perform? Compare with filtering the zero-stuffed signal directly.

### Exercise 3: a CIC with any R

`cic_decim` requires R to be a power of two, because its gain Rᴺ is removed by a shift.

- Extend it to any R, for example R = 10: the register width is ⌈16 + N log₂ R⌉, and the gain correction becomes a multiplication by a constant close to 1/Rᴺ followed by a shift. Add the multiplier, update the model, and verify for R = 10 and 12.
- How much error does the approximate gain correction introduce, in LSBs? Choose the constant's width so the error stays below half an LSB.

### Exercise 4: design the compensation FIR

For the chain of section 10.4 (CIC with R = 16, then a 2× FIR decimator):

- Design the FIR with `scipy.signal.firwin2`, asking for a gain that is the inverse of the CIC's response in the passband and zero in the stopband. Find the smallest number of taps that gives a combined passband ripple below 0.2 dB and combined alias rejection of 60 dB.
- Show that N = 4 **cannot** reach 60 dB with any FIR: compute the CIC's attenuation on the inputs that fold into ±1.25 MHz already at its own output (within 1.25 MHz of multiples of 6.25 MHz), and confirm it by searching FIR lengths up to 120 taps. Then design the FIR for N = 5, and compare the cost of the N = 5 chain with the N = 4 one (adders, register bits, multiplications per second): what does the extra CIC stage cost, and what does it buy?
- Plot the CIC response, the FIR response and the combined response on one chart.

### Exercise 5: a two-stage RTL chain

Connect `cic_decim` (R = 8) and `fir_decim` (M = 2) into one module, `decim16`, with the CIC's output valid driving the FIR's input valid.

- Write the golden model by chaining the two existing models, and verify the RTL bit-exactly.
- The FIR's `in_ready` can be low while it computes. Can the CIC's output ever arrive while the FIR is busy? Work out the clock cycles per CIC output and per FIR computation, and add an assertion that would catch a lost sample.
- Synthesize it and compare its cost with the 582-tap single filter of section 10.4, scaled to this example.

## 10.6 Summary and what comes next

You can now change sample rates without aliasing, build decimators that skip the work their outputs do not need, and use CIC filters for large rate changes without a single multiplier. Keep this table beside you for the exercises.

| Topic | Key fact | Remember |
| --- | --- | --- |
| Decimation by M | Keep every M-th sample | Filter to below f\_s/(2M) first |
| Interpolation by L | Insert L − 1 zeros, then filter | Removes images at multiples of the old rate |
| Decimating FIR | Compute only the kept outputs | M times fewer MACs |
| Polyphase | Split h into M phases | Every multiplier runs at the low rate |
| CIC structure | N integrators, ↓R, N combs (delay 1) | No multipliers |
| CIC gain | Rᴺ | Register width XW + N log₂ R |
| CIC arithmetic | Must wrap, never saturate | Modular arithmetic makes it exact |
| CIC response | \|sin(πfR)/(R sin(πf))\|ᴺ | Nulls on the alias bands; droop in the passband |
| Decimation chain | CIC at the high rate, FIR at the low rate | About 15× fewer multiplications here |
| Compensation FIR | Inverse droop in the passband | `scipy.signal.firwin2` |
| Model timing | Copy the hardware's register timing exactly | A one-sample shift fails bit-exactness |
| Parameters | Pass them to the design and the testbench | One forgotten override: a timeout |

The ideas that matter most from this part:

1. A sample-rate change is a sampling operation, and it aliases unless the filter comes first.
2. Never compute a result you will throw away: decimating and polyphase filters work at the low rate.
3. The CIC filter is correct **because** its arithmetic wraps; the register-width rule is what makes it safe.
4. Large rate changes are done in stages, with cheap filters where the rate is high and sharp filters where the rate is low.

**Part 11: The FFT** builds the instrument you have used since Part 9 as a black box. You will learn the discrete Fourier transform, how the fast Fourier transform computes it with N log₂ N operations instead of N², what windows do to a spectrum, and how a radix-2 butterfly, twiddle factors and bit-reversed addressing turn into hardware. You will build a streaming FFT in RTL and verify it against NumPy.

### Further reading: non-integer rate changes

This part changes sample rates by integer factors. For ratios that are not integers, or that change over time, [Part 14: More DSP Structures](https://claude.ai/artifact/V3up8RZjK314g2yFkPZiiK), section 14.3, builds a Farrow interpolator: a pipelined cubic interpolator that evaluates the signal at any fraction between two samples, verified bit-exactly, with measurements showing why it works best on signals first interpolated by an integer factor with the filters of this part.
