# Verilog & RTL for DSP — Appendix A: Portable SystemVerilog

*Markdown export of the online document: https://claude.ai/artifact/2rooPowLtJJTig3xL7sYfU. Diagrams and charts appear only online; each is marked below with its title.*


Oct 22, 2026 · @Behi

## Why this appendix exists

The course uses three free tools, and each accepts a different subset of SystemVerilog: **Icarus Verilog 12.0** for simulation, **Verilator 5.020** for lint, and **Yosys 0.33** for synthesis. A construct that simulates perfectly can stop synthesis, and code that synthesizes can fail to simulate. Throughout the course and its solutions, these differences were discovered one at a time, usually late; this appendix collects them in one place so that you can write code that all three tools accept from the start.

**Read it after Part 1**, and come back to it whenever a tool rejects code that another tool accepted.

**How every rule was checked.** Each construct below was written as a small module and run through all three tools with the course's usual commands:

```sh
iverilog -g2012 -Wall -o /dev/null test.sv
verilator --lint-only -Wall -Wno-DECLFILENAME --top-module test test.sv
yosys -q -p "read_verilog -sv test.sv; synth -top test"
```

The portable form of each construct was then run through the same three commands, and **all three accepted every portable form**. The error messages quoted are the tools' own. These results are specific to the versions named above; newer versions may accept more, so when you upgrade a tool, re-run the checks rather than relying on this list.

## The rules

### Summary

| Construct | Icarus 12.0 | Verilator 5.020 | Yosys 0.33 | Portable form |
| --- | --- | --- | --- | --- |
| `?:` between enum values | **rejects** | accepts | accepts | `if / else` |
| `return` in a function | accepts | accepts | **rejects** | assign the function name |
| `parameter string` | accepts | accepts | **rejects** | untyped `parameter` |
| `-(W+1)'(a)`: minus before a cast | accepts | accepts | **rejects** | `-((W+1)'(a))` |
| `int'(k)` | accepts | accepts | **rejects** | `32'(k)` |
| `break` in a loop | **rejects** | accepts | **rejects** | a "found" flag |
| `$error` in design code | accepts | accepts | **rejects** | `` `ifndef SYNTHESIS `` around it |
| `assert property (...)` | **rejects** | accepts | **rejects** | a procedural check (below) |
| `matches` as a signal name | **rejects** | **rejects** | accepts | another name |

The pattern is worth knowing: **Icarus** lacks parts of SystemVerilog's newer syntax (strict enum typing, `break`, concurrent assertions), **Yosys 0.33** reads a narrower synthesizable subset, and **Verilator** accepts the most. Lint-clean in Verilator therefore does not mean the code will simulate in Icarus or synthesize in Yosys: check with all three.

### Each rule, with the evidence

**1. No `?:` between enum values (Icarus).** `n = x ? B : A;` with an enum-typed `n` gives `error: This assignment requires an explicit cast.`: Icarus types the result of `?:` as a plain vector. Write it as `if (x) n = B; else n = A;`, which all three accept and which is usually clearer in a state machine anyway.

**2. No `return` (Yosys).** A function using `return v + 1'b1;` stops Yosys with `syntax error, unexpected TOK_ID`. Assign the function's name instead, the older Verilog form: `inc = v + 1'b1;`.

**3. No `parameter string` (Yosys).** `parameter string F = "x.hex"` gives `syntax error, unexpected TOK_ID, expecting ',' or '=' or ')'`. An untyped `parameter F = "x.hex"` holds a string in all three tools.

**4. Parenthesize a cast after a minus sign (Yosys).** `-(W+1)'(a)` gives `Static cast with zero or negative size!`: Yosys reads the minus sign as part of the cast's width. `-((W+1)'(a))` means what was intended. This one appeared three times in the course (Parts 9 and 11, and the Part 9 solutions).

**5. Size casts with numbers, not types (Yosys).** `int'(k)` gives `syntax error, unexpected TOK_INT`. `32'(k)` is the same cast and is accepted everywhere.

**6. No `break` (Icarus and Yosys).** Icarus answers `sorry: break statements not supported.`, Yosys `Can't resolve task name '\break'.`. Use a flag:

```systemverilog
  always_comb begin
    logic found; y = 0; found = 1'b0;
    for (int i = 0; i < 8; i++) if (a[i] && !found) begin y = 4'(i); found = 1'b1; end
  end
```

This is also what hardware does: a loop is unrolled into gates, and "stop early" is just a condition on the later copies.

**7. Keep simulation-only checks away from synthesis (Yosys).** An `$error` in a design file stops Yosys with `Can't resolve task name '$error'.`. Yosys defines the macro `SYNTHESIS` while reading, so:

```systemverilog
`ifndef SYNTHESIS
  always @(posedge clk) if (a && b) $error("both high");
`endif
```

keeps the check in simulation and hides it from synthesis.

**8. No concurrent assertions in Icarus or Yosys 0.33.** `assert property (@(posedge clk) a |=> y);` is a syntax error in both (Yosys: `syntax error, unexpected '@'`). Write the check procedurally, with the delay made explicit:

```systemverilog
`ifndef SYNTHESIS
  logic a_d = 1'b0;
  always @(posedge clk) begin a_d <= a; if (a_d && !y) $error("y did not follow a"); end
`endif
```

For formal verification (Part 13), Yosys reads immediate `assert`, `assume` and `$past()` inside `always` blocks when it is invoked with `read_verilog -formal`; that is the form Part 13 uses.

**9. Avoid SystemVerilog keywords as names.** `matches` is a keyword (pattern matching), so a signal called `matches` is a syntax error in Icarus and Verilator (Yosys happens to accept it). Other keywords that look like ordinary names include `bit`, `byte`, `int`, `logic`, `string`, `type`, `ref`, `unique` and `priority`.

## Tool behaviors that cost time

These are not language rules but properties of the tools, each met during the course or its solutions.

**Icarus: `-P` sets only top-level parameters.** `iverilog -Pfir_symmetric.N=67 ...` has no effect when the design is instantiated inside a testbench: the testbench is the top level, and the filter silently keeps its default N. (In the Part 7 solutions this produced `FAIL sample 24: got -152 expected -185` from a correct design.) Pass parameters through a macro in the testbench instead:

```systemverilog
`ifndef DUT_PARAMS
  `define DUT_PARAMS .N(32)
`endif
  `DUT #(`DUT_PARAMS) dut (.*);
```

and compile with `-DDUT_PARAMS=".N(67),.CW(16),.CF(17)"`.

**Icarus: no macro stringification.** `` `"`DUT`" `` (turning a macro's value into a string) is a syntax error in Icarus 12. Print a fixed message instead.

**Verilator: loops are unrolled up to 64 iterations by default.** A `for` loop of non-blocking assignments to an array with more iterations fails lint with `%Error-BLKLOOPINIT: Unsupported: Delayed assignment to array inside for loops`. A 64-tap filter lints cleanly, a 65-tap one does not, and neither does a loop that resets a 1,024-word memory. Raise the limit with `--unroll-count 256` (or more); Icarus and Yosys have no such limit.

**Verilator: 1-bit parameters on the command line.** `-GGAUSS=1` passes a 32-bit constant to a `bit` parameter and gives `WIDTHTRUNC`; write `-GGAUSS=1'b1`.

**Yosys: default parameter values are elaborated too.** When a module's default parameter names a file (`QFILE = "qsin_lut.hex"`), Yosys reads that file even if every instance overrides the parameter, and stops with `Can not open file 'qsin_lut.hex'` if it is missing. Keep the default file present, or choose a default that exists.

**Yosys: `-q` hides `stat`.** `yosys -q -p "...; stat"` prints nothing, so a script that parses the statistics silently gets zeros (the Part 4 solutions' first report was a table of zeros). Use `tee -q -o /dev/stdout stat`, which prints only the statistics.

**Yosys: parameters of the top module** are set with `chparam -set N 67 top_name` before `synth`; for a string, quote it: `chparam -set QFILE \"q.hex\" top_name`.

**Yosys: hierarchical references are not resolved.** A reference such as `dut.skid_valid` in a formal harness is read as a new, implicitly declared and undriven wire (`Warning: Identifier '\dut.skid_valid' is implicitly declared.`), even after `flatten`. When a formal property needs an internal signal, expose it as a formal-only port inside `` `ifdef FORMAL `` (Part 13). Icarus and Verilator do resolve hierarchical references in testbenches, which the course's testbenches use.

## Packages, structs and interfaces

The course writes mostly Verilog-2001 plus `logic`, `always_ff`, `always_comb` and `enum`. SystemVerilog also offers **packages** (shared types, constants and functions), **packed structs** (named fields in one vector) and **interfaces** (a bundle of signals with directions). With these tools, the first two are usable with three restrictions; the third is not.

### A portable package and struct

```systemverilog
// dsp_pkg.sv -- shared types and constants for the course's designs
package dsp_pkg;
  localparam int XW = 16;
  typedef logic signed [XW-1:0] q15_t;                 // a Q1.15 sample
  typedef struct packed { q15_t re; q15_t im; } cq15_t; // a complex Q1.15 sample: 32 bits
  function automatic q15_t sat16(input logic signed [31:0] v);
    if (v > 32'sd32767)       sat16 = 16'sd32767;
    else if (v < -32'sd32768) sat16 = -16'sd32768;
    else                      sat16 = 16'(v);                 // not q15_t'(v): Yosys 0.33 rejects casts to a user type
  endfunction
endpackage
```

```systemverilog
// cswap.sv -- multiplies a complex sample by j (re' = -im, im' = re), registered, with saturation.
// Types are named with the package prefix: Yosys 0.33 rejects "module m import pkg::*; (...)".
module cswap (
  input  logic          clk,
  input  dsp_pkg::cq15_t din,
  output dsp_pkg::cq15_t dout
);
  always_ff @(posedge clk) begin
    dout.re <= dsp_pkg::sat16(-(32'(din.im))); // -(-32768) = +32768 saturates to 32767
    dout.im <= din.re;
  end
endmodule
```

This passes all three tools: an Icarus testbench (2,000 random samples, including the −32,768 case that saturates) passes, Verilator lints it clean, and Yosys synthesizes it to 32 flip-flops (17 FDRE and 15 FDSE), 34 LUTs and 12 CARRY4 for the negation and saturation. A packed struct is laid out with its **first field in the high bits**: `{re, im}` with `re` = `16'h1234` and `im` = `16'habcd` reads `32'h1234abcd`, so a `cq15_t` drops straight into a 32-bit AXI4-Stream `tdata`.

The three restrictions, each found by running this example:

| Construct | Yosys 0.33 says | Portable form |
| --- | --- | --- |
| Cast to a user type, `q15_t'(v)` | `syntax error, unexpected TOK_USER_TYPE` | a width cast, `16'(v)` |
| Import in the module header, `module m import dsp_pkg::*; (...)` | `syntax error, unexpected TOK_ID` | package-qualified types, `dsp_pkg::cq15_t` |
| Minus before a cast, `-32'(x)` | `Static cast with zero or negative size!` | `-(32'(x))` (rule 4, again) |

Icarus and Verilator accepted all three original forms.

### Interfaces: not portable here

An AXI4-Stream interface with `src` and `snk` modports, used as module ports (`module axis_reg (..., axis_if.snk s, axis_if.src m);`), failed in two of the three tools: Icarus 12 reports `syntax error` and `Errors in port declarations`, and Yosys 0.33 fails to elaborate the parameterized interface (`does not have a port named 'm.clk'`). Verilator accepted it. With these versions, bundle signals with packed structs, or write the ports out, as the course does.

## Verilator as a simulator

The course uses Verilator only for lint, but it is also a simulator, and a much faster one: it compiles the design and the testbench into a C++ program. With `--timing` (Verilator 5), it runs ordinary event-driven testbenches with `#` delays and `@(posedge clk)`, so the course's testbenches work unchanged.

The Part 12 DDC testbench (`tb_ddc2.sv` from the Part 12 solutions, 32,768 input samples):

```sh
verilator --binary --timing -Wno-fatal -Wno-lint -Wno-style --top-module tb_ddc2 -o vddc \
  ddc.sv mixer.sv nco.sv cic_decim.sv fir_decim.sv mac.sv requant.sv tb_ddc2.sv
./obj_dir/vddc +SEED=1 +GAP=5
```

|  | Icarus 12.0 | Verilator 5.020 |
| --- | --- | --- |
| Compile / build | under 0.1 s | 6.7 s |
| Run | 2.9 s | **0.09 s** |
| Result | PASS, 2,048 outputs bit-exact | PASS, 2,048 outputs bit-exact |

The independent Python check agrees for both. Verilator ran this testbench about **30 times faster**, but its build takes several seconds, so Icarus is quicker for short runs and Verilator wins for long ones: regressions over many seeds, or a million samples for a spectrum. The `-Wno-lint -Wno-style` options silence lint warnings about testbench code; lint the design itself separately with `--lint-only -Wall`, as before.

One difference to expect: the two simulators produce different `$urandom` sequences from the same seed, so testbenches with random gaps take a different number of clock cycles (196,756 against 196,645 here). The outputs are identical, because the design's results do not depend on the gaps; if a result ever does differ between simulators, that is a bug worth finding (often a race between blocking and non-blocking assignments in the testbench).

## A checklist for every design

A design is finished only when all of these hold. Each item caught at least one real problem somewhere in the course or its solutions.

1. **It simulates bit-exactly** against its Python model, on more than one seed, with random gaps in its valid signals.
2. **It lints clean** with `verilator --lint-only -Wall`, with any waiver written next to the code with its reason (`/* verilator lint_off ... */`).
3. **It synthesizes** with Yosys (`synth_xilinx -family xc7`, or the family you target), and the report is read: the multiplier and memory counts are what you expected, and no memory turned into thousands of flip-flops (Part 4, section 4.6).
4. **It meets timing** at the intended clock after place and route, on more than one placement seed (Part 13). Synthesis alone does not tell you this.
5. **Simulation-only code is guarded** by `` `ifndef SYNTHESIS ``, and formal-only code by `` `ifdef FORMAL ``.
6. **Parameters reach the design**: run at least one test with non-default parameters, passed through the testbench macro, and check that the behavior changes.
7. **One script regenerates, simulates and checks** (Part 12 solutions, Exercise 1), so that no result can come from a stale file.
