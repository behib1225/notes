# Verilog & RTL for DSP — Solutions to Part 8

*Markdown export of the online document: https://claude.ai/artifact/Age771xKc3nN9UNFVqbS85. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the five exercises of Part 8. Try each one first; the "Check your understanding" answers are in Part 8 itself.

**How these solutions were checked.** Everything was run with Python 3, NumPy and SciPy, Icarus Verilog 12.0 (`-g2012 -Wall`), Verilator 5.020 (`--lint-only -Wall`) and Yosys 0.33. Every RTL result is bit-exact against a Python model, checked both by the testbench and independently in Python, and every number below is copied from an actual run.

### Three shared changes

The exercises reuse `iir_biquad.sv`, `iir_cascade.sv` and `tb_fir.sv` from Part 8, with three small additions:

- **A `SAT` parameter** in `iir_biquad.sv` and `iir_cascade.sv` (default 1), passed to each section's `requant`, so that Exercise 3 can switch the sections to wrap-around. The cascade's final output stage always saturates.
- **A `DUT_PARAMS` macro** in the testbench, `` `DUT #(`DUT_PARAMS) dut (...) ``, as in the Part 7 solutions, so each run can set `NSEC`, `SW`, `SF` and `SAT` on the design itself (Icarus's `-P` only reaches the top-level module).
- **A generalized model, `iirlib.py`**, whose `golden()` takes the signal format and the overflow mode as arguments, plus helpers `scale()` (L∞ scaling), `coefs()` (Q2.16 quantization, with a check that every coefficient fits) and `write_coef_file()`:

```python
def golden(xq, cq, SW=24, SF=20, ovf="saturate"):
    """Sample-by-sample integer model: exact sum, one rounding per section, then Q1.15 out."""
    v = np.asarray(xq, dtype=np.int64) << (SF - XF)
    for b0, b1, b2, a1, a2 in [tuple(int(t) for t in r) for r in cq]:
        x1 = x2 = y1 = y2 = 0
        out = np.empty_like(v)
        for n, x0 in enumerate(v.tolist()):
            acc = b0 * x0 + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            y0 = int(requant(np.array([acc]), SF + CF, SW, SF, "round", ovf)[0])
            out[n] = y0
            x2, x1, y2, y1 = x1, x0, y1, y0
        v = out
    return requant(v, SF, XW, XF, "round", "saturate")
```

## Exercise 1: a DC blocker

### Pole, zero and response

y\[n\] = x\[n\] − x\[n−1\] + a·y\[n−1\] has the transfer function

```latex
H(z) = \frac{1 - z^{-1}}{1 - a z^{-1}}, \qquad a = 0.995
```

- **Zero at z = 1**, exactly on the unit circle at 0 Hz: a perfect null for a constant (DC) input.
- **Pole at z = 0.995**, just inside the circle, very close to the zero. Away from 0 Hz, the pole and zero almost cancel, so the response is nearly flat: at f\_s/2 (z = −1) the gain is 2/(1 + 0.995) = **1.0025**, +0.02 dB.

On a pole-zero plot, the two sit side by side at z ≈ 1; the closer the pole is to the zero, the narrower the notch around 0 Hz.

**The −3 dB cutoff** at f\_s = 48 kHz, found numerically on a 0.01 Hz grid: **38.1 Hz** (where |H| = 1/√2; relative to the high-frequency gain of 1.0025, 38.3 Hz). A quick estimate for a pole close to 1: f\_c ≈ (1 − a)·f\_s/(2π) = 0.005 × 48,000 / 2π = 38.2 Hz. So this filter removes DC and the lowest few tens of hertz and passes the audio band essentially untouched.

### As one biquad

The DC blocker is a biquad with b₀ = 1, b₁ = −1, b₂ = 0, a₁ = −0.995 and a₂ = 0. In Q2.16 (×65,536) the coefficients are **65,536, −65,536, 0, −65,208, 0**; 1.0 and −1.0 are exactly representable in Q2.16. It runs unchanged on `iir_cascade.sv` with `NSEC = 1`:

```python
cq = quantize(np.array([[1.0, -1.0, 0.0, -0.995, 0.0]]), 18, 16)
write_coef_file(cq)
out, y, msg = run_rtl(x, cq, 1)          # x: 0.3 + 0.5 sin(2 pi 1 kHz t), 8,000 samples
```

Result: `PASS: 8000 outputs bit-exact`, and the independent Python check agrees.

### How long does the offset take to disappear?

With a constant input, x\[n\] − x\[n−1\] = 0, so after the first sample the output simply decays as y\[n\] = a·y\[n−1\]: a time constant of 1/(1 − a) = **200 samples** (4.2 ms). In exact arithmetic, an offset of 0.3 falls below half an output LSB (2⁻¹⁶) after about **1,975 samples** (41 ms).

The fixed-point filter, fed a constant 0.3 (9,830 in Q1.15), does this:

| Sample | 0 | 100 | 500 | 1,000 | 1,500 | 1,800 | 2,000 | 5,000 | 20,000 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Output (LSB) | 9,830 | 5,952 | 800 | 65 | 6 | 3 | **3** | **3** | **3** |

**It never reaches zero: it stops at 3 LSB, forever.** This is the zero-input limit-cycle mechanism of section 8.3, in its simplest form, a **dead band**. Once the input is constant, each step computes round(0.995·y) in the internal Q4.20 format. When 0.005·|y| is less than half an internal LSB, the rounding gives back y itself and the decay stops. That happens for |y| up to about 100 internal LSBs (0.5 / 0.005), which is 100 / 32 ≈ **3 output LSBs**, exactly what the simulation shows.

With the 1 kHz sine on top of the offset, the outcome is different. Averaged over 1-ms blocks (whole cycles of the sine), the output's mean falls from 8,199 LSB in the first millisecond to **0.08 LSB** after about 80 ms, and stays there. The varying signal keeps changing the rounding errors, so they average out instead of locking the state: the sine acts as **dither**.

To remove the dead band for constant inputs too, the cures are those of section 8.3: more fractional bits in the state (each extra bit halves the dead band), magnitude truncation in the feedback, or a little added dither.

## Exercise 2: watch a filter go unstable

### Five sections in RTL

The filter of section 8.3: `ellip(10, 0.1, 80, 0.05)`, a 10th-order elliptic low-pass with its cutoff at 0.025 cycles per sample and poles at radius up to **0.99701**.

```python
sos = signal.ellip(10, 0.1, 80, 0.05, output="sos")
ss = scale(sos)                 # L-infinity scaling
cq = coefs(ss)                  # Q2.16; asserts that every coefficient fits
write_coef_file(cq)
```

After scaling, the largest coefficient is **1.969** in magnitude, still inside Q2.16. Poles this close to the unit circle need a₁ close to −2 (a₁ = −2r cos θ), and 1.969 leaves little room: a filter with an even narrower passband would need Q3.15 coefficients. After quantization, the five sections' largest pole radii are 0.9468, 0.9614, 0.9779, 0.9896 and **0.9970**: all inside the circle, and the last one still within 2 × 10⁻⁵ of its true value. Driven by the test stimulus (with its full-scale step and square wave), the internal signals peak at 1.01, 1.04, 1.10, 1.16 and 1.19, well inside Q4.20.

On the RTL, with `NSEC = 5` and nothing else changed: two seeds of 6,000 samples, `PASS: 6000 outputs bit-exact`, confirmed independently.

### The same filter as one polynomial

The single-polynomial form has denominator coefficients up to **216.7** in magnitude. Quantizing them with F fractional bits and computing where the poles land:

| Fractional bits F | Largest pole radius | Stable? |
| --- | --- | --- |
| 16 | 1.3856 | No |
| 20 | 1.1550 | No |
| 24 | 1.1082 | No |
| 28 | 1.0557 | No |
| 32 | 1.0126 | No |
| 34 | 1.0046 | No |
| **36** | **0.9977** | **Yes** |
| 40 | 0.9970 | Yes |

The impulse response of the 20-bit polynomial, computed with `scipy.signal.lfilter`, shows what an unstable filter does:

| Sample | 0 | 100 | 500 | 1,000 | 2,000 | 2,999 |
| --- | --- | --- | --- | --- | --- | --- |
| \|y\| | 1.1 × 10⁻⁴ | 2.8 × 10³ | 1.1 × 10³⁰ | 1.9 × 10⁶¹ | 4.1 × 10¹²³ | 5.1 × 10¹⁸⁵ |

The output grows by a factor of about 1.155 per sample, the radius of the escaped pole, without limit. In fixed-point hardware it would saturate (or, worse, wrap) within a few dozen samples and stay there.

### How many bits does each form need?

- **One polynomial**: the smallest stable choice is **F = 36** fractional bits, and the coefficients also need a sign bit and 8 integer bits for values up to 216.7: 45**-bit coefficients**, far beyond a DSP block's 18-bit port. Even at F = 36 the largest pole is at 0.9977 instead of 0.9970, so the response would still be noticeably off.
- **Second-order sections**: the poles stay inside the unit circle with as few as **7 fractional bits** (largest radius 0.9961). Stability is the minimum requirement, not a good response, but it shows the difference in sensitivity: **29 fewer bits** for the same guarantee.

The reason is the one in section 8.3: each coefficient of a high-order polynomial depends on all ten poles, which are clustered near z = 1, so tiny coefficient errors move the clustered roots a long way. A biquad's two coefficients depend only on its own two poles.

## Exercise 3: provoke an overflow oscillation

### The setup

The Part 8 elliptic cascade, with two changes made through parameters only:

- **Wrap instead of saturate** inside the sections: `SAT = 0` (the new parameter), and `"wrap"` in the model.
- **Internal format Q1.23** instead of Q4.20: `SW = 24`, `SF = 23`. The internal signals now have no headroom above ±1, while section 8.3 measured internal peaks of up to 1.29 for this filter, so overflow is certain.

The stimulus: 400 samples of a full-scale square wave with a period of 12 samples (just inside the passband edge, where the filter rings most), followed by silence. Both versions, saturating and wrapping, are verified bit-exactly against the model with the same overflow mode:

```python
sq = np.where((np.arange(400) // 6) % 2 == 0, 32767, -32768)
x = np.zeros(6000, dtype=np.int64); x[100:500] = sq           # burst, then zeros
for sat in (1, 0):
    out, y, msg = run_rtl(x, cq, 4, SW=24, SF=23, sat=sat)
```

Both runs: `PASS: 6000 outputs bit-exact`.

### What happens

> **Figure:** iir\_cascade.sv (Icarus 12.0), SW = 24, SF = 23, SAT = 1 and SAT = 0; envelope, not the waveform (shown in the [online version](https://claude.ai/artifact/Age771xKc3nN9UNFVqbS85))

|  | During the burst | After the burst (samples 2,000 to 5,999) |
| --- | --- | --- |
| Saturating sections | Peaks at 27,856, saturates at 32,767 as the burst ends | **0**: silent by about sample 970 |
| Wrapping sections | Identical to the saturating version | **Never stops**: peak 28,789, RMS 21,276 |

During the burst the two are identical: overflow happens only in the transient when the square wave stops. From that moment, the saturating version rings down and decays to exactly zero within about 470 samples. The wrapping version jumps into a full-scale oscillation, at **0.25 cycles per sample**, and stays there. A 40,000-sample run of the model shows the same RMS, 21,276, in its last 5,000 samples: it does not decay at all.

### Why it never recovers

This is the **overflow oscillation** of section 8.3. When a section's sum overflows, wrap-around turns a large positive value into a large negative one (or the reverse): an error of almost two full-scale units, fed straight back into the resonant poles. With a large enough signal inside the loop, the wrapping itself becomes part of the dynamics, and a self-sustaining pattern appears: each cycle, the state overflows again in the same way and is thrown back to the same orbit. The input is zero, so nothing ever disturbs it. This is a property of the nonlinear system, which the linear stability rule (every pole inside the unit circle) does not cover: the poles are exactly as stable as before.

Saturation is far better behaved. A saturated value is the largest representable value **with the correct sign**, so its error is never the huge, sign-flipping error of wrap-around; once the input stops, the stable poles bring the state back to zero, as they did here. (For second-order direct-form sections, saturation arithmetic is known to suppress zero-input overflow oscillations in general; this experiment is one example.)

The lesson: inside a recursive filter, use saturation **and** enough integer headroom that it is rarely needed. Wrap-around is only safe in feed-forward structures (such as an FIR's accumulator with enough guard bits) and in the special case of CIC filters (Part 10), where the wrap is undone exactly by the following subtractions.

## Exercise 4: a Butterworth cascade

### Design, scaling, coefficients

```python
n, wn = signal.buttord(0.16, 0.24, 0.1, 60)       # the Part 8 specification
sos = signal.butter(n, wn, output="sos")           # n = 21: 10 biquads + 1 first-order section
cq = coefs(scale(sos))
```

`buttord` confirms **order 21**, so 11 sections. After L∞ scaling, the largest coefficient is **1.644**, so all of them fit Q2.16. The Butterworth's poles are less extreme than the elliptic filter's (largest radius **0.962** after quantization, against 0.976), so its coefficients are less sensitive. The quantized filter still meets the specification: worst passband deviation **0.0996 dB** (below 0.1 dB) and stopband attenuation **62.7 dB**, the same as in floating point.

### Verification and cost

On the RTL with `NSEC = 11`: two seeds of 4,000 samples, `PASS: 4000 outputs bit-exact`, confirmed independently.

|  | Elliptic (Part 8) | Butterworth |
| --- | --- | --- |
| Order / sections | 7 / 4 | 21 / 11 |
| DSP48E1 (Yosys) | 18 | **53** |
| LUTs | about 590 | about 1,940 |
| Largest pole radius | 0.976 | 0.962 |

53 DSP blocks is exactly 10 biquads × 5 plus 3 for the first-order section, almost three times the elliptic filter's 18.

### Group delay

| Frequency (cycles/sample) | 0.01 | 0.04 | 0.06 | 0.075 | 0.079 |
| --- | --- | --- | --- | --- | --- |
| Elliptic | 8.1 | 9.9 | 13.7 | 24.6 | 38.0 |
| Butterworth | 24.0 | 26.1 | 30.2 | 38.2 | 43.3 |

The Butterworth filter delays every frequency **more**, but its delay **varies less** across the passband: from 24.0 to 43.3 samples (a spread of 19 samples, a ratio of 1.8), against 8.1 to 38.0 for the elliptic filter (a spread of 30 samples, a ratio of 4.7). Its phase is closer to linear, so pulses come out less smeared; the price is a longer delay overall.

### Was the extra cost worth anything?

For this specification, almost never: three times the multipliers, more delay, and only a modest improvement in phase linearity. If linear phase really matters, an FIR filter is the proper solution (Part 8, section 8.5).

The Butterworth's real advantage is a **monotonic, maximally flat passband**, with no ripple at all. That matters where the passband's exact shape is the point: measurement instruments, audio crossovers and anti-aliasing filters in data acquisition, where a ripple of 0.1 dB would itself be an error. Those designs usually use **low** Butterworth orders (2 to 6), where the cost difference against an elliptic filter is small, rather than order 21.

## Exercise 5: one DSP block for the whole filter

### The ASM chart, as a table

For each input sample, each of the four sections computes its five products one per clock, rounds once, updates its state, and hands its output to the next section:

| State | Condition | Actions | Next |
| --- | --- | --- | --- |
| S\_IDLE | `in_valid` (`in_ready` = 1) | `xin` ← x (converted to Q4.20); s ← 0; c ← 0 | S\_MAC |
| S\_MAC | c < 4 | acc ← product (c = 0), acc ± product (c > 0); c ← c + 1 | S\_MAC |
| S\_MAC | c = 4 | acc ← acc − a₂·y₂\[s\] | S\_UPD |
| S\_UPD | s < NSEC − 1 | round acc once → y; shift x₁, x₂, y₁, y₂ of section s; `xin` ← y; s ← s + 1; c ← 0 | S\_MAC |
| S\_UPD | s = NSEC − 1 | as above, and output y (rounded to Q1.15), `out_valid` = 1 | S\_IDLE |

### The RTL

The datapath is one multiplier, a multiplexer that chooses its operand (x, x₁, x₂, y₁ or y₂ of the current section), the coefficient ROM `iir_coef(s, c)` from the same generated file as the parallel cascade, and an accumulator:

```systemverilog
  // ---- the datapath: one multiplier and an accumulator ----
  logic signed [SW-1:0]    operand;
  logic signed [CW-1:0]    coef;
  logic signed [ACC_W-1:0] acc, prod;
  always_comb begin
    case (c)
      3'd0:    operand = xin;
      3'd1:    operand = x1[s];
      3'd2:    operand = x2[s];
      3'd3:    operand = y1[s];
      default: operand = y2[s];
    endcase
    coef = iir_coef(32'(s), 32'(c));
    prod = ACC_W'(operand * coef);
  end
```

The controller:

```systemverilog
      case (state)
        S_IDLE: if (in_valid) begin
          xin   <= {{(SW - XW - (SF - XF)){x[XW-1]}}, x, {(SF - XF){1'b0}}};   // Q1.15 -> Q4.20
          s     <= '0;  c <= '0;  state <= S_MAC;
        end
        S_MAC: begin                             // acc = b0 x + b1 x1 + b2 x2 - a1 y1 - a2 y2
          if (c == 3'd0)      acc <= prod;
          else if (c < 3'd3)  acc <= acc + prod;
          else                acc <= acc - prod;
          if (c == 3'd4) state <= S_UPD;
          else           c <= c + 1'b1;
        end
        S_UPD: begin                             // round once, update this section, move on
          x2[s] <= x1[s];  x1[s] <= xin;
          y2[s] <= y1[s];  y1[s] <= ysec;
          xin   <= ysec;                         // the next section's input
          c     <= '0;
          if (s == SB'(NSEC - 1)) begin
            y <= y_c;  out_valid <= 1'b1;  state <= S_IDLE;
          end else begin
            s <= s + 1'b1;  state <= S_MAC;
          end
        end
        default: state <= S_IDLE;
      endcase
```

Here `ysec` is `requant(acc)` to Q4.20 with rounding and saturation, exactly the rounding of `iir_biquad.sv`, and `y_c` is `ysec` rounded to Q1.15. The products are added or subtracted in the same order as the model's single expression, but since integer addition is exact, the order does not matter; what matters is that the sum is rounded exactly once per section, as in the parallel version.

### Results

The same bit-exact model verifies it (`iirlib.golden()` with the Part 8 coefficients, the same algorithm as Part 8's `iir_model.golden()`): three seeds of 3,000 samples, `PASS: 3000 outputs bit-exact`, confirmed independently. The module is lint-clean. Yosys reports **one DSP48E1**, about 590 LUTs and 480 flip-flops (the 16 state registers of 24 bits, plus the accumulator and control).

**Cycles per sample: 25**, measured (75,003 cycles for 3,000 samples): 1 to accept the sample, then 4 sections × (5 MAC cycles + 1 update cycle). The first-order section's b₂ and a₂ are zero, so skipping those two products would save 2 cycles, giving 23.

At 48 kHz on a 100 MHz clock there are 100,000,000 / 48,000 ≈ **2,083** cycles per sample, so this single multiplier is busy only 1.2% of the time: one DSP block could run the same filter for about **80 independent channels**.

### Extending it to two channels

The arithmetic and the controller stay the same; what changes is the **state storage**. Each channel needs its own x₁, x₂, y₁ and y₂ for every section, because they hold that channel's own signal history:

- Add a channel index `ch` and double each state array: `x1[ch][s]`, and so on: 2 × 4 sections × 4 values × 24 bits = 768 bits. (The coefficients are shared: both channels use the same filter.)
- Accept a left sample, process all sections with `ch = 0`, then accept a right sample and process them with `ch = 1`: 50 cycles per stereo sample pair.
- With more channels, the state is better kept in a small RAM addressed by (channel, section, value), which maps to LUT RAM, as the circular buffer did in the Part 7 solutions, instead of growing the flip-flop count with every channel.

---

That completes Part 8. Send me your own designs and results if you would like them reviewed.
