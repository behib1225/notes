# Verilog & RTL for DSP — Part 11: The FFT

*Markdown export of the online document: https://claude.ai/artifact/T1gr6ybzjpUwCiKnGLseXd. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 11 fits

Since Part 9 you have measured spectra with `np.fft`, treating it as an instrument. Part 11 opens the instrument. The **discrete Fourier transform** (DFT) splits a block of N samples into N frequency components, and the **fast Fourier transform** (FFT) computes it with about (N/2)·log₂ N complex multiplications instead of N². For N = 1,024, that is 5,120 instead of 1,048,576: a factor of 200.

The FFT is everywhere in DSP hardware: spectrum analyzers, radar, OFDM modems (Wi-Fi, 4G, 5G and DVB all transmit data on hundreds of FFT bins), fast convolution for very long filters, and audio processing.

In this part you will:

1. Learn the DFT from the single-frequency measurement of Part 5, and see what windows do to a spectrum (11.1).
2. Derive the radix-2 FFT, its **butterfly**, **twiddle factors** and **bit-reversed** order, and write it in Python (11.2).
3. Make it work in fixed point, where every stage can double the signal (11.3).
4. Build a 64-point FFT processor in RTL, using the RTL method of Part 3: a memory, one butterfly unit and a controller, verified bit-exactly and measured against NumPy (11.4).

As always, every number comes from code that was run: Python 3 with NumPy, Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33. The Part 6 files `fixedpoint.py` and `requant.sv` are reused.

## 11.1 The discrete Fourier transform

The DFT takes a block of N samples and measures how much of each of N frequencies it contains. It is the `amplitude()` measurement of Part 5, repeated at N equally spaced frequencies at once.

### The definition

```latex
X[k] = \sum_{n=0}^{N-1} x[n] \, e^{-j 2\pi k n / N}, \qquad k = 0, 1, \ldots, N-1
```

Each output X\[k\], a **bin**, is the correlation of the block with a complex sinusoid at k/N cycles per sample: the same projection that `amplitude()` used, without the factor 2/N. So:

- **Bin k** measures frequency k·f\_s/N. Bins above N/2 are the negative frequencies (bin N − k is −k·f\_s/N), as for the NCO's phase in Part 9.
- The **bin spacing**, the resolution, is f\_s/N: a 1,024-point DFT at 1 MHz resolves frequencies 977 Hz apart. Finer resolution needs a longer block, which takes longer to collect.
- Each X\[k\] is complex: its magnitude is the amplitude at that frequency, its angle the phase.

Written directly, the definition needs N complex multiplications for each of N bins: **N²** in total. In Python, a direct implementation of the formula agrees with `np.fft.fft` to within 2.4 × 10⁻¹³ on 64 random complex samples. The definition is correct; it is only slow.

```python
def dft(x):
    """The definition: X[k] = sum_n x[n] exp(-j 2 pi k n / N). N*N complex multiplications."""
    x = np.asarray(x, dtype=complex); N = len(x); n = np.arange(N)
    return np.array([np.sum(x * np.exp(-2j * np.pi * k * n / N)) for k in range(N)])
```

### Leakage and windows

The DFT assumes the block repeats forever. A tone with a whole number of cycles in the block, k exactly an integer, repeats seamlessly and lands in exactly one bin (and its mirror). A tone that does not, say at 10.5 cycles per block, has a jump where the block wraps around, and its energy **leaks** into every bin.

The numbers for N = 64: a cosine exactly on bin 10 produces 2 bins above −40 dB (bin 10 and its mirror, bin 54), and nothing else. Move it to bin 10.5, and **all 64 bins** are above −40 dB. Leakage is not a defect of the FFT; it is what the DFT of a truncated sinusoid really is.

The cure is the same as in Part 7's filter design: multiply the block by a **window** that tapers to zero at both ends, so that the wrap-around has no jump. The chart shows the tone at bin 10.5 with no window (the 33 actual DFT bins from 0 to f\_s/2) and with the Blackman–Harris window that Parts 9 and 10 used:

> **Figure:** np.fft on cos(2π·10.5n/64); window curve evaluated at quarter-bin spacing (zero-padded FFT) (shown in the [online version](https://claude.ai/artifact/T1gr6ybzjpUwCiKnGLseXd))

With the window, the leakage far from the tone falls from about −30 dB to below −90 dB, and only 12 bins (6 on each side, counting the mirror) remain above −40 dB. The price is a wider main peak: the window trades frequency resolution for dynamic range, exactly the trade-off of Part 7's window table. That is why every spectrum measurement in this course used a window.

### Check your understanding: 11.1

1. A 4,096-point DFT is computed on data sampled at 48 kHz. What is the bin spacing, and which frequency does bin 100 represent?
2. In a 64-point DFT, which bin holds the frequency −3·f\_s/64?
3. How many complex multiplications does the direct DFT need for N = 4,096?
4. Why does a tone at exactly 10 cycles per block produce no leakage at all?
5. Why does a window widen the main peak?

#### Answers

1. 48,000 / 4,096 ≈ **11.72 Hz**; bin 100 is 100 × 11.72 ≈ **1,172 Hz**.
2. **Bin 61** (64 − 3).
3. N² = **16,777,216**.
4. With a whole number of cycles, the periodic extension that the DFT assumes is a perfect, continuous sinusoid, which is exactly one of the DFT's basis frequencies. It correlates fully with that bin and is orthogonal to all the others.
5. Tapering the ends shortens the block's effective length, and a shorter observation has coarser frequency resolution. Mathematically, the spectrum is convolved with the window's own transform, whose main lobe is wider than the rectangular window's.

## 11.2 The fast Fourier transform

The FFT computes exactly the same N numbers as the DFT, using a divide-and-conquer trick: an N-point DFT can be built from two N/2-point DFTs plus N/2 cheap combining steps called **butterflies**. Applied recursively, that turns N² multiplications into (N/2)·log₂ N.

### Splitting the sum (decimation in time)

Write W\_N = e^{−j2π/N}, so the DFT is X\[k\] = Σ x\[n\] W\_N^{kn}. Split the samples into even-indexed and odd-indexed ones:

```latex
X[k] = \underbrace{\sum_{m} x[2m] \, W_{N/2}^{km}}_{E[k]} \; + \; W_N^{k} \underbrace{\sum_{m} x[2m+1] \, W_{N/2}^{km}}_{O[k]}
```

E\[k\] and O\[k\] are themselves DFTs of length N/2, of the even and the odd samples. Because they repeat with period N/2, and because W\_N^{k+N/2} = −W\_N^k, the two halves of the output come from the same pair of values:

```latex
X[k] = E[k] + W_N^{k} \, O[k], \qquad X[k + N/2] = E[k] - W_N^{k} \, O[k]
```

That pair of equations is the **butterfly**: one complex multiplication by the **twiddle factor** W\_N^k, one addition and one subtraction, producing two outputs from two inputs. Splitting E and O again, and again, until the DFTs have length 1 (a single sample is its own DFT) gives **log₂ N stages of N/2 butterflies** each. This is the radix-2 **decimation-in-time** (DIT) FFT of Cooley and Tukey (1965).

### Bit-reversed order

Splitting into even and odd samples repeatedly scrambles the input order. After all the splits, the sample that enters position i is x\[rev(i)\], where rev reverses the bits of i. For N = 8 (3 bits), positions 0 to 7 hold samples 0, 4, 2, 6, 1, 5, 3, 7: position 1 = `001` holds sample `100` = 4. In hardware this reordering costs nothing: you simply write each input sample to its bit-reversed address, as the RTL in section 11.4 does.

### The algorithm in Python

An iterative, in-place version, structured exactly as the hardware will be:

```python
def bit_reverse(i, bits):
    return int(f"{i:0{bits}b}"[::-1], 2)

def fft_iter(x):
    """Radix-2 decimation-in-time FFT, in place: bit-reversed input order, log2(N) stages."""
    x = np.asarray(x, dtype=complex); N = len(x); L = N.bit_length() - 1
    a = np.array([x[bit_reverse(i, L)] for i in range(N)])
    for s in range(L):
        span = 1 << s
        for b in range(N // 2):                       # N/2 butterflies per stage
            grp, pos = b >> s, b & (span - 1)
            i = grp * 2 * span + pos; j = i + span
            w = np.exp(-2j * np.pi * (pos << (L - 1 - s)) / N)
            t = a[j] * w
            a[i], a[j] = a[i] + t, a[i] - t           # the butterfly
    return a
```

In stage s, butterflies combine elements that are **span = 2ˢ** apart: neighbors in stage 0, then elements 2 apart, then 4, up to N/2 apart in the last stage. The butterfly index b is split into a group number and a position within the group, which give the two addresses i and j = i + span and the twiddle index k = pos·2^(L−1−s). The results overwrite the inputs (**in place**), so the FFT needs no memory beyond the N values themselves. On 64 random complex samples, `fft_iter` matches `np.fft.fft` to within 1.1 × 10⁻¹⁴.

### What it saves

| N | Direct DFT (complex multiplications) | FFT butterflies (one multiplication each) | Speed-up |
| --- | --- | --- | --- |
| 64 | 4,096 | 192 | 21× |
| 1,024 | 1,048,576 | 5,120 | 205× |
| 4,096 | 16,777,216 | 24,576 | 683× |

The speed-up grows with N, which is why FFT-based methods dominate whenever N is large: spectral analysis, OFDM, and fast convolution, where a long FIR filter is applied by multiplying spectra instead of convolving samples.

### Check your understanding: 11.2

1. How many stages and butterflies does a 256-point radix-2 FFT have?
2. In a 16-point FFT, at which position does sample x\[3\] go after bit reversal?
3. Why is W\_N^{k+N/2} = −W\_N^k?
4. In stage 2 (s = 2) of a 64-point FFT, butterfly b = 9: what are i, j and the twiddle index k?
5. Why does an in-place FFT need no extra memory?

#### Answers

1. log₂ 256 = **8** stages of 128 butterflies: **1,024** butterflies.
2. 3 = `0011` reversed is `1100` = **12**. (Bit reversal is its own inverse: position 3 holds sample 12, and position 12 holds sample 3.)
3. W\_N^{N/2} = e^{−jπ} = −1, so W\_N^{k+N/2} = W\_N^k · W\_N^{N/2} = −W\_N^k: half a turn further around the circle points the opposite way.
4. span = 4, grp = 9 >> 2 = 2, pos = 9 & 3 = 1. i = 2·8 + 1 = **17**, j = 17 + 4 = **21**, k = 1 << (6 − 1 − 2) = **8**.
5. Each butterfly reads two values and writes its two results back to the same two locations, and no other butterfly in that stage needs the old values. So the inputs can be overwritten as the computation proceeds.

## 11.3 The FFT in fixed point

Each butterfly can double the size of its outputs, so the values in an N-point FFT can grow by a factor of N over log₂ N stages. A fixed-point FFT must either widen its words by one bit per stage, or scale every stage by ½ and accept more rounding noise. This section picks the second, builds a bit-exact model, and measures what it costs.

### How large does the output get?

A complex tone of amplitude 0.9 exactly on bin 5 of a 64-point block gives |X\[5\]| = 0.9 × 64 = **57.6**: all the energy of 64 samples piles into one bin. In general, the DFT's gain for a pure tone is N, so an unscaled N-point FFT needs **log₂ N extra bits**: 6 for N = 64, 10 for N = 1,024.

### Three strategies

| Strategy | How | Cost | Weakness |
| --- | --- | --- | --- |
| Bit growth | Add one bit per stage | Wider memory and multipliers each stage | Expensive for large N |
| Scale by ½ every stage | Each butterfly computes (a ± b·w)/2 | Free: one more bit dropped in each rounding | Small signals lose accuracy |
| Block floating point | Scale a stage by ½ only if some value would overflow; count the scalings | A detector and a shared exponent | More control logic |

This course uses the second. Each butterfly halves its results, so after 6 stages the output is **DFT/64**, the same scaling as `np.fft.fft(x)/64`. If the input's complex magnitude stays below 1, no value can ever exceed it: |(a ± b·w)/2| ≤ (|a| + |b|)/2. Saturation is still kept as a safety net.

### The bit-exact model

The model mirrors the hardware: twiddle factors in Q1.15 with amplitude 32,767 (so +1.0, which Q1.15 cannot hold, never appears), exact complex products, and one rounding per output:

```python
N_FFT, W, TW = 64, 16, 16                             # points, data bits (Q1.15), twiddle bits (Q1.15)

def twiddles(N=N_FFT, tw=TW):
    k = np.arange(N // 2); amp = (1 << (tw - 1)) - 1  # 32767: +1.0 is not representable
    return (np.round(amp * np.cos(2 * np.pi * k / N)).astype(np.int64),
            np.round(-amp * np.sin(2 * np.pi * k / N)).astype(np.int64))

def fft_fixed(xr, xi, N=N_FFT):
    """Bit-exact model: each butterfly computes (a + b*w)/2 and (a - b*w)/2 exactly,
    then rounds once to Q1.15 and saturates. Output = DFT / N."""
    L = N.bit_length() - 1
    wr, wi = twiddles(N)
    ar = [int(xr[bit_reverse(i, L)]) for i in range(N)]
    ai = [int(xi[bit_reverse(i, L)]) for i in range(N)]
    rq = lambda v: int(requant(np.array([v]), 31, W, 15, "round", "saturate")[0])  # Q?.30 sum /2 -> Q1.15
    for s in range(L):
        span = 1 << s
        for b in range(N // 2):
            grp, pos = b >> s, b & (span - 1)
            i = grp * 2 * span + pos; j = i + span; k = pos << (L - 1 - s)
            tr = ar[j] * int(wr[k]) - ai[j] * int(wi[k])          # Q2.30, exact
            ti = ar[j] * int(wi[k]) + ai[j] * int(wr[k])
            ur, ui = ar[i] << 15, ai[i] << 15                     # a in Q?.30
            ar[i], ai[i], ar[j], ai[j] = rq(ur + tr), rq(ui + ti), rq(ur - tr), rq(ui - ti)
    return np.array(ar), np.array(ai)
```

The scaling by ½ is free: the sum a + b·w has 30 fractional bits, and `requant` is told it has **31**, so dropping 16 bits both returns to Q1.15 and divides by 2. One rounding per output, no separate shift.

### What scaling costs

Comparing the model with the ideal `np.fft.fft(x)/64` of the same quantized input, averaged over 20 random complex blocks at each level:

| Input amplitude (each of I and Q) | SQNR of the fixed-point FFT |
| --- | --- |
| 0.5 | 68.2 dB |
| 0.05 | 48.6 dB |
| 0.005 | 28.4 dB |

The SQNR falls 20 dB for every factor of 10 in input level. The rounding noise added in each stage has a fixed absolute size (about half an LSB), while scaling by ½ six times shrinks the signal by 64 relative to the words that carry it. A full-scale input gets good accuracy; a quiet one is buried. That is exactly the case for **block floating point**, which scales only when needed (Exercise 3), and for wider internal words in high-performance FFTs.

### Check your understanding: 11.3

1. A 1,024-point FFT with 16-bit input and no scaling: how wide must its last stage be?
2. Why does scaling by ½ in every stage guarantee no overflow, as long as the input's complex magnitude is below 1?
3. Why are the twiddle factors stored with amplitude 32,767 instead of 32,768?
4. With scaling, the output equals DFT/N. How would you get back the true magnitude of a tone?
5. Why does the SQNR drop by 20 dB when the input drops by a factor of 10?

#### Answers

1. 16 + log₂ 1,024 = **26 bits**.
2. |w| ≤ 1, so |(a ± b·w)/2| ≤ (|a| + |b·w|)/2 ≤ (|a| + |b|)/2, which is at most the larger of |a| and |b|. Values never grow from stage to stage, so they stay below 1 if they start below 1.
3. Q1.15 can represent −1.0 but not +1.0; the largest value is 32,767/32,768. The twiddle factor W⁰ = 1 must therefore be approximated, and using the same amplitude for all entries keeps them consistent (and keeps Part 6's −1 × −1 case away).
4. Multiply by N (a shift by log₂ N bits) after the FFT, in a wider word or in software. The scaling changes the units, not the information, apart from the extra rounding noise.
5. The noise power stays the same while the signal power falls by a factor of 100, which is 20 dB.

## 11.4 An FFT processor in RTL

The RTL method of Part 3 applies directly: a **datapath** with a working memory, a twiddle ROM and one butterfly unit, and a **controller** that sequences three phases: load 64 samples, compute 6 × 32 butterflies, unload 64 bins. The result is bit-exact with `fft_fixed` and within 1.6 LSB of NumPy.

> **Figure:** fft64.sv architecture (shown in the [online version](https://claude.ai/artifact/T1gr6ybzjpUwCiKnGLseXd))

### The three phases

| Phase | Clock cycles | What happens |
| --- | --- | --- |
| `S_LOAD` | 64 (one per valid input) | Sample n is written to address rev(n): the bit reversal costs nothing |
| `S_COMPUTE` | 6 × 32 = 192 | One butterfly per clock, results written back in place |
| `S_UNLOAD` | 64 | Bins 0 to 63 are read out in natural order |

### The RTL

```systemverilog
`timescale 1ns/1ps
// fft64.sv -- 64-point radix-2 decimation-in-time FFT processor.
// Memory-based: LOAD 64 samples (written at bit-reversed addresses), COMPUTE 6 stages of
// 32 butterflies with ONE butterfly unit (one butterfly per clock), UNLOAD 64 bins in order.
// Each butterfly scales by 1/2, so the output is DFT/64. Data and twiddles are Q1.15.
module fft64 #(
  parameter int N = 64, W = 16
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  output logic                in_ready,
  input  logic signed [W-1:0] in_re, in_im,
  output logic                out_valid,
  output logic signed [W-1:0] out_re, out_im
);
  localparam int L = $clog2(N);                  // 6 stages
  typedef enum logic [1:0] {S_LOAD, S_COMPUTE, S_UNLOAD} state_t;
  state_t state;

  logic signed [W-1:0] mem_re [0:N-1];           // the working memory, updated in place
  logic signed [W-1:0] mem_im [0:N-1];
  logic signed [W-1:0] tw_re  [0:N/2-1];         // twiddle ROM: exp(-j 2 pi k / N)
  logic signed [W-1:0] tw_im  [0:N/2-1];
  initial begin
    $readmemh("tw_re.hex", tw_re);
    $readmemh("tw_im.hex", tw_im);
  end

  logic [L-1:0]         cnt;                     // sample counter (LOAD, UNLOAD)
  logic [$clog2(L)-1:0] stage;                   // 0 .. L-1
  logic [L-2:0]         bfly;                    // butterfly within the stage, 0 .. N/2-1

  // bit reversal of the load address
  function automatic logic [L-1:0] rev(input logic [L-1:0] a);
    for (int b = 0; b < L; b++) rev[b] = a[L-1-b];
  endfunction

  logic [L-1:0] load_addr;
  assign load_addr = rev(cnt);                   // bit-reversed load address

  // ---- address generation for butterfly 'bfly' of stage 'stage' ----
  logic [L-1:0] ia, ja;                          // the two memory addresses
  logic [L-2:0] tk;                              // twiddle index
  always_comb begin
    logic [L-1:0] span, pos, grp;
    span = L'(1) << stage;
    pos  = L'(bfly) & (span - 1'b1);
    grp  = L'(bfly) >> stage;
    ia   = (grp << (stage + 1)) | pos;           // grp * 2 * span + pos
    ja   = ia | span;                            // ia + span
    tk   = (L-1)'(pos << (L - 1 - 32'(stage)));
  end

  // ---- the butterfly: (a +- b*w) / 2, exact products, one rounding each ----
  localparam int PW = 2 * W + 2;                 // product sum width with headroom
  logic signed [PW-1:0] tr, ti, ur, ui;
  logic signed [W-1:0]  yr0, yi0, yr1, yi1;
  logic                 ovf0, ovf1, ovf2, ovf3;   // unused overflow flags
  assign tr = PW'(mem_re[ja] * tw_re[tk]) - PW'(mem_im[ja] * tw_im[tk]);   // Q.30
  assign ti = PW'(mem_re[ja] * tw_im[tk]) + PW'(mem_im[ja] * tw_re[tk]);
  assign ur = PW'(mem_re[ia]) <<< (W - 1);                                  // a in Q.30
  assign ui = PW'(mem_im[ia]) <<< (W - 1);
  // dropping 16 fractional bits from Q.30 both returns to Q1.15 and divides by 2
  requant #(.IN_W(PW), .IN_F(2*W - 1), .OUT_W(W), .OUT_F(W - 1), .RND(1), .SAT(1'b1))
    q0 (.din(ur + tr), .dout(yr0), .ovf(ovf0)),
    q1 (.din(ui + ti), .dout(yi0), .ovf(ovf1)),
    q2 (.din(ur - tr), .dout(yr1), .ovf(ovf2)),
    q3 (.din(ui - ti), .dout(yi1), .ovf(ovf3));

  wire unused_ovf = ovf0 | ovf1 | ovf2 | ovf3;

  assign in_ready = (state == S_LOAD);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_LOAD;  cnt <= '0;  stage <= '0;  bfly <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= 1'b0;
      case (state)
        S_LOAD: if (in_valid) begin
          mem_re[load_addr] <= in_re;              // bit-reversed write: input reordering is free
          mem_im[load_addr] <= in_im;
          cnt <= cnt + 1'b1;
          if (cnt == L'(N - 1)) state <= S_COMPUTE;
        end
        S_COMPUTE: begin                           // one butterfly per clock, in place
          mem_re[ia] <= yr0;  mem_im[ia] <= yi0;
          mem_re[ja] <= yr1;  mem_im[ja] <= yi1;
          bfly <= bfly + 1'b1;
          if (bfly == '1) begin                    // last butterfly of this stage
            if (stage == ($clog2(L))'(L - 1)) begin stage <= '0; state <= S_UNLOAD; end
            else stage <= stage + 1'b1;
          end
        end
        S_UNLOAD: begin                            // bins 0 .. N-1 in natural order
          out_valid <= 1'b1;
          out_re <= mem_re[cnt];  out_im <= mem_im[cnt];
          cnt <= cnt + 1'b1;
          if (cnt == L'(N - 1)) state <= S_LOAD;
        end
        default: state <= S_LOAD;
      endcase
    end
  end
endmodule
```

Points worth studying:

- **Address generation is pure bit manipulation.** Multiplying by 2 · span is a shift by stage + 1; adding span to an address whose bit `stage` is always 0 is an OR. The same is true of the twiddle index. No multiplier is spent on addresses.
- **Four `requant` instances in one statement.** `requant #(...) q0 (...), q1 (...), ...;` declares several instances with the same parameters.
- **A variable in an `always_comb` block** (`span`, `pos`, `grp`) is a temporary wire. It is declared inside the block, which keeps it local.
- **The `/2` costs nothing**: `requant` is told the sum has 31 fractional bits rather than 30.

### Two lint fixes

Verilator flagged two things in the first version, both worth knowing. `mem_re[rev(cnt)] <= in_re;` gave `SIDEEFFECT: Expression side effect may be mishandled`: a function call inside the index of an assignment target. Computing the address in its own signal, `load_addr`, fixed it and reads better. And passing `unused_ovf[0]` to an output port gave the same warning, because an element of an unpacked array was used as a port connection; plain scalar signals fixed that.

### Verification

The testbench loads blocks of 64 complex samples with random gaps on `in_valid` and writes every output bin. The checker runs `fft_fixed` on the same blocks and also compares with `np.fft.fft(x)/64`. The blocks cycle through four kinds: a complex tone on bin 5, a real tone at bin 10.5 plus another component (leakage everywhere), an impulse (whose spectrum is flat), and random data.

```text
2560 bins from 40 blocks, 13574 clock cycles
PASS: 40 blocks bit-exact; max error vs np.fft/64: 1.56 LSB
```

That is about 339 cycles per block: 320 for load, compute and unload, plus the testbench's idle cycles. The error against floating point stays below 1.6 LSB on every bin.

To prove the check has teeth, the twiddle index was deliberately shifted by one bit (`L - 2` instead of `L - 1`): the checker reported `FAIL`, with errors of 28,698 LSB.

### Cost, and a memory lesson

Yosys reports **4 DSP48E1** blocks, one per real multiplication of the complex product. But it also reports about **2,100 flip-flops**, 5,600 LUTs and 1,200 `MUXF7`/`MUXF8`. The working memory, 64 complex words, is 2,048 bits, and it was built from flip-flops, with large read multiplexers in front. The reason is the access pattern: one butterfly per clock **reads two** words and **writes two** words (back to the same two addresses) every cycle, but an FPGA block RAM has at most two ports. Production FFT processors solve this by splitting the memory into banks so that i and j always fall into different banks, by pipelining the butterfly (read in one cycle, write later), or by using a **pipelined streaming architecture** (for example the radix-2 single-path delay feedback, R2SDF, design), which has one butterfly per stage and small delay lines between stages, and accepts one sample per clock continuously. Exercise 4 asks you to map this design's memory into block RAM.

### Check your understanding: 11.4

1. How many clock cycles does one 64-point transform take, from the first input to the last output, without idle cycles? How would that grow for N = 1,024?
2. Why is writing input sample n at address rev(n) "free"?
3. Why are 4 DSP blocks needed for one butterfly?
4. Why did the memory end up in flip-flops instead of block RAM?
5. The design cannot accept new samples while computing. What throughput does it achieve at 100 MHz, in samples per second?

#### Answers

1. 64 + 192 + 64 = **320** cycles. For N = 1,024: 1,024 + (512 × 10) + 1,024 = **7,168** cycles.
2. Bit reversal is just a re-wiring of the address bits: no arithmetic, no extra cycle. The samples are reordered as they are written.
3. The complex product b·w = (b\_r w\_r − b\_i w\_i) + j(b\_r w\_i + b\_i w\_r) needs **four** real multiplications (three with Gauss's trick).
4. The butterfly reads two and writes two words every clock: four accesses per cycle, more than a block RAM's two ports, so the synthesizer had to build a many-ported memory out of registers and multiplexers.
5. 64 samples per 320 cycles: 100 MHz × 64 / 320 = **20 million samples per second**. A streaming design would accept 100 million.

## 11.5 Exercises

For scale: their worked solutions add 3 design files, 3 testbenches and 4 Python scripts, about 650 new lines (not counting short checks run inline). Time depends too much on experience for a reliable estimate, so none is given. Reuse `fft_model.py`, `tb_fft.sv` and `check_fft.py`. Send me your code, tables and plots.

- [ ] Exercise 1: a spectrum analyzer in Python
- [ ] Exercise 2: a parameterized FFT
- [ ] Exercise 3: block floating point
- [ ] Exercise 4: the memory in block RAM
- [ ] Exercise 5: fast convolution

### Exercise 1: a spectrum analyzer in Python

Write `spectrum(x, fs, window)` that returns frequencies and magnitudes in dBFS (dB relative to a full-scale sine), using your own `fft_iter` rather than `np.fft`.

- Calibrate it: a full-scale sine exactly on a bin must read 0 dBFS with a rectangular window. What correction does each window need (its **coherent gain**)?
- Use it on the NCO output of Part 9 and reproduce its SFDR measurement.

### Exercise 2: a parameterized FFT

Generalize `fft64` to any power-of-two N from 8 to 1,024 (`parameter int N`). The twiddle files must be generated for the chosen N.

- Verify N = 8, 64 and 256 bit-exactly. For N = 8, check one block by hand against the butterfly equations.
- How do the cycle count, memory size and Yosys resources grow with N?

### Exercise 3: block floating point

Change the butterfly so that a stage is scaled by ½ only when it needs to be: before each stage, check whether any value entering it is too large for an unscaled butterfly; if so, scale that whole stage and increment a shared exponent output. Choose the threshold carefully. If every value's **complex** magnitude is below ½, an unscaled output, a ± b·w, stays below 1. Hardware usually checks the real and imaginary parts separately instead, because that needs no squaring; then the bound is weaker, since an output component can reach (1 + √2) times the largest input component. Derive the safe component threshold (it is below ½), and find an example where ½ would overflow.

- Update the model, verify bit-exactly, and output the exponent with the bins.
- Repeat the SQNR measurement of section 11.3 at input amplitudes 0.5, 0.05 and 0.005. What happens to the 20-dB-per-decade loss?

### Exercise 4: the memory in block RAM

Restructure `fft64` so that its working memory maps onto block RAM, which allows two accesses per cycle per memory.

- One way: take two clock cycles per butterfly (read i and j in the first, write both in the second). Another: split the memory into two banks, by the parity of the address bits, so that i and j are always in different banks.
- Keep it bit-exact. Compare Yosys reports with the original: flip-flops, LUTs, block RAMs, and cycles per transform.

### Exercise 5: fast convolution

Filtering by multiplying spectra: the convolution of x and h equals the inverse DFT of X·H, if both are zero-padded to the length of the result.

- In Python, filter a long signal with the 32-tap filter of Part 7 using 64-point FFTs and the **overlap-add** method (blocks of 33 samples, zero-padded to 64). Compare with `np.convolve`.
- Count the multiplications per output sample of overlap-add versus direct convolution for a 32-tap and a 1,000-tap filter. At what length does the FFT method win?

## 11.6 Summary and what comes next

You can now compute spectra, explain what the FFT does inside, make it work in fixed point, and build an FFT processor that is bit-exact against a Python model. Keep this table beside you for the exercises.

| Topic | Key fact | Remember |
| --- | --- | --- |
| DFT | X\[k\] = Σ x\[n\] e^{−j2πkn/N} | Bin k is k·f\_s/N; bins above N/2 are negative frequencies |
| Resolution | f\_s/N | Longer blocks resolve finer |
| Leakage | Tones between bins spread into every bin | Use a window; it widens the peak |
| FFT | log₂ N stages of N/2 butterflies | 205× fewer multiplications at N = 1,024 |
| Butterfly | E + W·O and E − W·O | One complex multiplication |
| Twiddles | W\_N^k = e^{−j2πk/N} | Amplitude 32,767 in Q1.15 |
| Bit reversal | Write input n to address rev(n) | Free in hardware |
| Addressing | i = grp·2·span + pos, j = i + span | Shifts and ORs only |
| Growth | Up to ×N over the transform | log₂ N extra bits, or scale |
| Scaling by ½ per stage | Output = DFT/N | Free; costs SQNR for small inputs |
| Block floating point | Scale only when needed | Shared exponent |
| Memory | One butterfly per clock = 2 reads + 2 writes | Banks or pipelining for block RAM |
| Streaming FFT | One butterfly per stage, delay lines between | One sample per clock continuously |

The ideas that matter most from this part:

1. The DFT is N correlations with complex sinusoids; the FFT computes them by reusing shared sub-results.
2. Every spectrum you measure is the spectrum of a windowed block, and the window is part of the measurement.
3. In fixed point, the FFT's growth must be planned per stage, like every other bit-growth problem in this course.
4. The FFT's data movement, not its arithmetic, decides its hardware architecture.

**Part 12: the capstone** puts the course together into one complete system: a **digital down-converter** (DDC). A real input at a high sample rate passes through the NCO and mixer of Part 9, the CIC decimator of Part 10, and a compensating FIR decimator from Parts 7 and 10, to produce a narrowband complex baseband signal at a low rate. You will design its word widths, verify the whole chain bit-exactly against a Python model, measure its spectrum with the FFT of this part, and synthesize it.

### Further reading: an FFT for one sample per clock

This part's FFT computes one block at a time with a single butterfly, about one sample per 5 clocks. [Part 14: More DSP Structures](https://claude.ai/artifact/V3up8RZjK314g2yFkPZiiK), section 14.4, builds a streaming FFT (radix-2 single-path delay feedback) that takes one sample every clock, verified bit-exactly against its own model and within 2.44 LSB of NumPy, and compares its cost with both FFTs of this part and its solutions.
