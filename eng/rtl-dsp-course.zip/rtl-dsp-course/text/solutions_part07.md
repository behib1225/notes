# Verilog & RTL for DSP — Solutions to Part 7

*Markdown export of the online document: https://claude.ai/artifact/Eere5Eis9mnVnLUhWf3ZbK. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the five exercises of Part 7. Try each one first; the "Check your understanding" answers are in Part 7 itself.

**How these solutions were checked.** Everything was run with Python 3, NumPy and SciPy, Icarus Verilog 12.0 (`-g2012 -Wall`), Verilator 5.020 (`--lint-only -Wall`) and Yosys 0.33. Every RTL design was verified bit-exactly with the Part 7 testbench on at least two seeds, plus an independent check in Python, and every number below is copied from an actual run.

### Two shared tools

**A generalized model, `firlib.py`.** Part 7's `fir_model.py` was written for one filter. The exercises need other lengths and coefficient formats, so its functions were generalized:

```python
def write_coef_file(hq, CW, comment, path="fir_coefs.svh"):
    with open(path, "w") as f:
        f.write(f"// fir_coefs.svh -- generated; do not edit by hand\n// {comment}\n")
        f.write(f"function automatic logic signed [{CW-1}:0] fir_coef(input int k);\n  case (k)\n")
        for k, v in enumerate(hq):
            lit = f"{CW}'sd{v}" if v >= 0 else f"-{CW}'sd{-v}"
            f.write(f"    {k:2d}: fir_coef = {lit};\n")
        f.write("    default: fir_coef = '0;\n  endcase\nendfunction\n")

def golden(xq, hq, CF):
    acc = np.convolve(np.asarray(xq, np.int64), np.asarray(hq, np.int64))[: len(xq)]
    return requant(acc, XF + CF, YW, YF, "round", "saturate")
```

`stimulus()` is the same as before (an impulse, random samples and three periods of the worst-case input for the given coefficients), and `amplitude()` is the measurement of Part 5.

**A parameter macro in the testbench.** The first run of Exercise 1 failed: `FAIL sample 24: got -152 expected -185`. The design was fine. Icarus's `-P` option, which I had used to set N = 67, only sets parameters of the **top-level** module, so the filter inside the testbench silently kept its default N = 32. This is the same trap as in Part 10, and the same fix: `tb_fir.sv` now instantiates the design as `` `DUT #(`DUT_PARAMS) dut (...) ``, with a default of `.N(32)`, and each run passes the parameters explicitly:

```sh
iverilog -g2012 -Wall -DDUT=fir_symmetric -DDUT_PARAMS=".N(67),.CW(16),.CF(17)" -o sim fir_symmetric.sv requant.sv tb_fir.sv
```

## Exercise 1: design to a specification

Specification: f\_s = 48 kHz, passband to 4 kHz, stopband from 6 kHz, at least 60 dB attenuation, passband ripple below 0.1 dB. In SciPy, frequencies can be given in hertz with `fs=48000`, which avoids the Nyquist-fraction trap of section 7.1.

### Kaiser window

```python
n, beta = signal.kaiserord(60, (6000 - 4000) / (48000 / 2))      # transition as a fraction of Nyquist
h = signal.firwin(n, 5000, window=("kaiser", beta), fs=48000)     # cutoff in the middle of the transition
```

`kaiserord` gives **N = 89** and β = 5.653. Checking every requirement numerically, on a 65,536-point frequency grid:

| Design | Taps | Worst passband deviation | Stopband attenuation | Meets the spec? |
| --- | --- | --- | --- | --- |
| Kaiser, N from `kaiserord` | 89 | 0.0099 dB | **59.95 dB** | **No**, by 0.05 dB |
| Kaiser, one tap more | 90 | 0.0098 dB | 60.40 dB | Yes |

Kaiser's formula is an **estimate**, and here it falls just short. Always check the actual design against the specification, never just the formula. The passband is easily within its 0.1 dB limit, because a Kaiser window with 60 dB of stopband ripple also has a passband ripple of only about 0.001 (0.01 dB): the window method cannot trade the two against each other.

### Parks–McClellan

`remez` can trade them, through a weight. Searching from 30 taps upward for the shortest design that meets both requirements, with stopband weights of 1, 3, 10 and 30:

```python
h = signal.remez(67, [0, 4000, 6000, 24000], [1, 0], weight=[1, 10], fs=48000)
```

The shortest is **67 taps**, with the stopband weighted 10 times the passband: **23 taps fewer** than the Kaiser design (−26%). The weight says how to spend the error budget: the passband is allowed 0.1 dB (a relative ripple of about 0.0115), and the stopband 60 dB (0.001), so the stopband needs about ten times more weight, and that is what the search found.

### Coefficient width (section 6.6)

For the 67-tap design, max |h| = 0.203 (so scaling gains 2 fractional bits) and Σ|h| = 1.677. Sweeping the width with scaled coefficients, 16-bit input and output, 200,000 random samples:

| W | F | Passband deviation | Stopband | Output SNR |
| --- | --- | --- | --- | --- |
| 12 | 13 | 0.081 dB | 56.68 dB | 64.5 dB |
| 13 | 14 | 0.079 dB | 58.02 dB | 69.3 dB |
| 14 | 15 | 0.080 dB | 59.50 dB | 76.2 dB |
| 15 | 16 | 0.079 dB | 60.23 dB | 80.8 dB |
| **16** | **17** | 0.079 dB | **60.40 dB** | **85.5 dB** |
| 17 | 18 | 0.079 dB | 60.72 dB | 87.8 dB |
| 18 | 19 | 0.079 dB | 60.72 dB | 88.7 dB |

An optimal design leaves no slack: Parks–McClellan spends the whole error budget, so the floating-point stopband is only about 0.7 dB above 60 dB, and every quantization error eats into that margin. 15 bits barely passes (60.23 dB); I chose **16 bits with F = 17** (60.40 dB, 85.5 dB SNR), which still fits the 18-bit DSP port. With more margin needed, the usual cure is to design for 61 or 62 dB and accept a tap or two more.

### The RTL: symmetric form for odd N

With 67 taps there are 33 pairs and an unpaired center tap. The extended `fir_symmetric.sv` handles both even and odd N:

```systemverilog
  localparam int H   = N / 2;                         // number of coefficient pairs
  localparam bit ODD = (N % 2) == 1;                  // is there a center tap?
  localparam int NM  = H + (ODD ? 1 : 0);             // number of multipliers
  ...
  // stage 2: pre-adders; the center tap of an odd filter passes through unpaired
  always_ff @(posedge clk) begin
    for (int k = 0; k < H; k++) pre[k] <= (XW+1)'(taps[k]) + (XW+1)'(taps[N-1-k]);
    if (ODD) pre[NM-1] <= (XW+1)'(taps[H]);
  end
  // stage 3: one multiplier per pair (and one for the center)
  always_ff @(posedge clk) begin
    for (int k = 0; k < NM; k++) prod[k] <= pre[k] * fir_coef(k);
  end
```

For odd N, `pre[NM-1]` holds the center sample `taps[H]` and is multiplied by `fir_coef(H)`, the center coefficient (index H = 33 for N = 67), so the coefficient index of each multiplier is simply k. Everything else is unchanged from Part 7.

### Verification and measurement

Three seeds of 4,000 samples, each with the worst-case input pattern: `PASS: 4000 outputs bit-exact` every time, confirmed by an independent check in Python, with 27 to 29 saturated outputs (Σ|h| = 1.68 > 1, so the worst-case input saturates). Yosys reports **34 DSP48E1 blocks**, exactly 33 pairs plus the center tap, against 67 for a direct form.

Measuring the RTL with sine waves at 12 frequencies:

| Frequency | 1 kHz | 3 kHz | 4 kHz | 5 kHz | 6 kHz | 7 kHz | 12 kHz | 20 kHz |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RTL | +0.07 dB | −0.05 dB | −0.07 dB | −8.45 dB | −61.19 dB | −61.88 dB | −65.87 dB | −76.70 dB |
| Design | +0.07 dB | −0.05 dB | −0.08 dB | −8.45 dB | −61.20 dB | −61.88 dB | −65.83 dB | −76.82 dB |

The hardware meets the specification, as measured: within ±0.08 dB up to 4 kHz, and more than 60 dB down from 6 kHz.

### A Verilator limit

Linting the 67-tap design failed with `%Error-BLKLOOPINIT: Unsupported: Delayed assignment to array inside for loops`. Verilator unrolls `for` loops of at most 64 iterations by default: the same design lints cleanly with N = 64 and fails with N = 65. Raising the limit, `verilator --lint-only -Wall --unroll-count 256 ...`, makes the 67-tap design lint-clean. Icarus and Yosys have no such limit.

## Exercise 2: a high-pass filter with an odd length

### Why the length must be odd

A symmetric filter with an **even** number of taps (type II, section 7.2) always has a zero at f\_s/2, and a high-pass filter must pass f\_s/2. SciPy refuses the even version outright:

```text
firwin(32, 0.5, pass_zero=False): A filter with an even number of coefficients must have zero response at the Nyquist frequency.
```

With 33 taps (type I) there is no forced zero anywhere.

### The design

```python
h = signal.firwin(33, 0.5, pass_zero=False)    # high-pass, cutoff 0.5 x Nyquist = 0.25 cycles/sample
```

Its largest coefficient is the center one, h\[16\] = **0.5007**, and Σ|h| = 1.547. Since |h| < 1, Q1.17 (18 bits) holds every coefficient without scaling. (Scaling would gain nothing: the center tap already uses the top magnitude bit.) The center tap is close to ½ because this high-pass filter is approximately an impulse minus the matching low-pass filter, \`firwin(33, 0.5)\`, whose center tap is close to ½. (Approximately: the two designs are normalized separately, and they differ by at most 0.0014 per coefficient.)

### The RTL

The direct form of Part 7 is already parameterized, so the only changes are the coefficient file (written by `firlib.write_coef_file`) and `-DDUT_PARAMS=.N(33)`. Its accumulator width adapts by itself: 16 + 18 + ⌈log₂ 33⌉ = 40 bits.

Three seeds of 3,000 samples: `PASS: 3000 outputs bit-exact` each time, and the independent Python check agrees. The module is lint-clean with `-GN=33`.

### The measured response

The RTL was measured with 20 cosines of amplitude 0.9, from 0 to 0.475 cycles per sample, exactly as in section 7.8 (at 0 Hz, from the mean of the output):

> **Figure:** Icarus 12.0, 4,000 samples per tone, amplitude 0.9 (shown in the [online version](https://claude.ai/artifact/Eere5Eis9mnVnLUhWf3ZbK))

Every measured gain agrees with the design within 0.25 dB, and within 0.1 dB everywhere but one stopband point near −61 dB. The −6.0 dB point lies exactly at the cutoff, 0.25 cycles per sample, as for any window-method design (the ideal response is ½ there).

### Its gain at 0 Hz

The gain at 0 Hz is the sum of the coefficients: Σh = **0.00141**, which is **−57.0 dB** (the RTL measured −56.93 dB). It is small but **not zero**. An odd-length symmetric filter has no forced zero at 0 Hz, so the window method only makes the gain there as small as the stopband ripple. Quantized to Q1.17, the coefficients sum to 185, which is 185/2¹⁷ = 0.00141: the quantization did not change it noticeably.

If a true zero at DC matters (for example, to remove an exact constant offset), a type IV filter (antisymmetric, even length) has one built in; or the coefficients can be adjusted slightly so they sum to exactly zero.

## Exercise 3: pipeline the direct form's sum

### The RTL

The delay line and the registered products are unchanged from `fir_direct.sv`. The single 32-input sum becomes a tree of registered levels, written once with a `generate` loop over the levels:

```systemverilog
`timescale 1ns/1ps
// fir_direct_pipe.sv -- direct-form FIR with a pipelined, balanced adder tree:
// N products -> N/2 sums -> register -> N/4 sums -> register -> ... -> 1 sum.
// N must be a power of two. Each level is one bit wider than the one before.
// Latency: 1 (delay line) + 1 (products) + log2(N) (tree levels) + 1 (output) cycles.
module fir_direct_pipe #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int LV = $clog2(N);                      // number of tree levels
  localparam int PW = XW + CW;                         // product width (34)
  assign in_ready = 1'b1;

  logic signed [XW-1:0] taps [0:N-1];
  logic signed [PW-1:0] prod [0:N-1];
  logic                 v [0:LV+1];                    // v[0]: products valid; v[l+1]: level l valid

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < N; k++) taps[k] <= '0;
    end else if (in_valid) begin
      taps[0] <= x;
      for (int k = 1; k < N; k++) taps[k] <= taps[k-1];
    end
    for (int k = 0; k < N; k++) prod[k] <= taps[k] * fir_coef(k);
  end

  // valid bits travel alongside the data: in_valid -> taps (1) -> products (v[0]) -> levels
  logic v_taps;
  always_ff @(posedge clk) begin
    if (rst) begin
      v_taps <= 1'b0;
      for (int l = 0; l <= LV + 1; l++) v[l] <= 1'b0;
    end else begin
      v_taps <= in_valid;
      v[0]   <= v_taps;
      for (int l = 0; l <= LV; l++) v[l+1] <= v[l];
    end
  end

  // the tree: level l has N >> (l+1) registers of width PW + l + 1
  for (genvar l = 0; l < LV; l++) begin : g_lvl
    localparam int M = N >> (l + 1);                   // sums at this level
    localparam int SW = PW + l + 1;                    // their width
    logic signed [SW-1:0] s [0:M-1];
    for (genvar i = 0; i < M; i++) begin : g_add
      if (l == 0) begin : g_first
        always_ff @(posedge clk) s[i] <= SW'(prod[2*i]) + SW'(prod[2*i+1]);
      end else begin : g_next
        always_ff @(posedge clk) s[i] <= SW'(g_lvl[l-1].s[2*i]) + SW'(g_lvl[l-1].s[2*i+1]);
      end
    end
  end

  localparam int ACC_W = PW + LV;                      // 39: the final sum
  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(g_lvl[LV-1].s[0]), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= v[LV];
    if (v[LV]) y <= y_c;
  end
endmodule
```

The interesting construct is the **per-level width**. Each pass of the outer `generate` loop creates a block `g_lvl[l]` with its own `localparam` width and its own array `s`, so level 0 holds 16 sums of 35 bits, level 1 holds 8 of 36 bits, and so on. A level reads the previous one through a **hierarchical name into the generate block**, `g_lvl[l-1].s[2*i]`. Icarus, Verilator and Yosys all accept it. Each sum is one bit wider than its operands, so the tree grows the width by exactly the ⌈log₂ N⌉ = 5 bits the full sum needs, ending at 39 bits.

The testbench needed **no change**: its monitor records outputs in order, whatever the latency.

### Results

Three seeds of 3,000 samples: `PASS: 3000 outputs bit-exact`, with independent checks; lint-clean.

**The latency**, measured with a single impulse: **8 cycles**, against 4 for the original direct form. That is 1 (delay line) + 1 (products) + 5 (tree levels) + 1 (output register), as predicted.

**The extra flip-flops, by hand.** The tree's registers hold 16 × 35 + 8 × 36 + 4 × 37 + 2 × 38 + 1 × 39 = 560 + 288 + 148 + 76 + 39 = **1,111 bits**. The original design already had the final 39-bit sum register, so the pipeline adds **1,072** data flip-flops, plus a few valid bits.

**And from Yosys:**

|  | Direct form | Pipelined tree |
| --- | --- | --- |
| DSP48E1 | 32 | 32 |
| Flip-flops | 539 | 1,131 |
| LUTs | 534 | 619 |
| CARRY4 | 76 | 175 |
| DSP blocks with P register used | 0 | **12** |

Yosys reports only 592 more flip-flops, not 1,072. The netlist explains why: in the pipelined version, 12 DSP blocks have their P register enabled, 8 of them adding a product to their C input (OPMODE `0x35`) and 4 adding a neighbor's product through the cascade (`0x15`). Yosys recognized that a first-level sum of two products, followed by a register, is exactly what a DSP block's post-adder and P register do, and moved 12 of the 16 first-level adders **with their registers** into DSP blocks. Those registers no longer appear as fabric flip-flops. As in Part 7, the synthesis report is the place to learn what the tool did with your structure.

The benefit, which Yosys's reports cannot show reliably for DSP-based designs (section 7.8): the longest combinational path is now one product plus at most one two-input addition per stage, instead of a 32-input sum, so the design can run at a much higher clock frequency. The price is 4 more cycles of latency and the registers counted above.

## Exercise 4: a better serial filter

### Step 1: remove the idle cycle

In Part 7's `fir_serial`, a new sample is accepted only in `S_IDLE`, which costs one cycle per sample. But in the last `S_RUN` cycle (k = N − 1), the MAC is reading the oldest tap for the last time; after that clock edge the delay line is free to shift. So the next sample can be accepted **in that same cycle**:

```systemverilog
  assign last_k   = (k == KW'(N - 1));
  // ready when idle, or in the cycle that feeds the last tap (the taps are no longer needed after it)
  assign in_ready = (state == S_IDLE) || (state == S_RUN && last_k);
  assign accept   = in_valid && in_ready;

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;  k <= '0;
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else begin
      if (accept) begin                          // shift in the new sample, start from tap 0
        taps[0] <= x;
        for (int i = 1; i < N; i++) taps[i] <= taps[i-1];
        k <= '0;  state <= S_RUN;
      end else if (state == S_RUN) begin
        k <= k + 1'b1;
        if (last_k) state <= S_IDLE;           // no new sample was waiting
      end
    end
  end
```

This is safe because the MAC samples `taps[k]` at the same clock edge at which the delay line shifts: non-blocking assignments mean the MAC gets the old value of `taps[31]`, and the next computation starts from the new `taps[0]`. `in_ready` still depends only on the state and the counter, never on `in_valid`, so the valid/ready rules hold. The MAC needs no change: `first` (k = 0) restarts its accumulator for the new sample in the very next cycle.

Result, `fir_serial_n.sv`: bit-exact on two seeds, in **96,008 cycles** for 3,000 samples, against 99,007 before: exactly **32 cycles per sample** instead of 33.

### Step 2: a circular buffer instead of a shifting delay line

Shifting 32 registers for every sample moves 512 bits per sample just to keep them in order. A **circular buffer** writes each new sample once, at a write pointer `wp`, and finds tap k at address (wp − k) mod N. With N a power of two, the modulo is free: the address simply wraps around in a $clog2(N)-bit register.

```systemverilog
  typedef enum logic [1:0] {S_INIT, S_IDLE, S_RUN} state_t;
  state_t               state;
  logic [KW-1:0]        k, wp, ra;                 // tap index, write pointer, read address
  logic signed [XW-1:0] mem [0:N-1];               // no reset: may become LUT RAM
  logic signed [XW-1:0] tap;
  logic                 last_k, accept;

  assign last_k   = (k == KW'(N - 1));
  assign in_ready = (state == S_IDLE) || (state == S_RUN && last_k);
  assign accept   = in_valid && in_ready;
  assign ra       = wp - k;                        // wraps modulo N because N = 2**KW
  assign tap      = mem[ra];

  // the memory: one write port
  always_ff @(posedge clk) begin
    if (state == S_INIT)  mem[k]  <= '0;           // clear one location per cycle
    else if (accept)      mem[wp + 1'b1] <= x;     // the new newest sample
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_INIT;  k <= '0;  wp <= '0;
    end else begin
      case (state)
        S_INIT: begin
          k <= k + 1'b1;
          if (last_k) begin state <= S_IDLE; k <= '0; end
        end
        default: begin
          if (accept) begin
            wp <= wp + 1'b1;  k <= '0;  state <= S_RUN;
          end else if (state == S_RUN) begin
            k <= k + 1'b1;
            if (last_k) state <= S_IDLE;
          end
        end
      endcase
    end
  end
```

The MAC is connected as before, with `.a(tap)`. Two design decisions make the memory cheap:

- **No reset on the memory.** A reset would force every bit to be a flip-flop (as section 7.7 of Part 7 noted for the delay line). Instead, after `rst` the controller spends N cycles in `S_INIT` writing zeros, one location per cycle, with `in_ready` low, so the filter still starts at rest as the model assumes.
- **One write port and one read port.** The memory is written at most once per cycle and read once per cycle, which is exactly what an FPGA's distributed (LUT) RAM provides.

Result, `fir_serial_ram.sv`: bit-exact on two seeds, in **96,039 cycles**: the same 32 cycles per sample, plus the 32 initialization cycles at the start (and one cycle of start-up difference).

### The comparison

|  | `fir_serial` (Part 7) | No idle cycle | Circular buffer |
| --- | --- | --- | --- |
| Cycles per sample | 33 | **32** | **32** |
| DSP48E1 | 1 | 1 | 1 |
| Flip-flops | 556 | 556 | **67** |
| LUTs | 319 | 316 | **109** |
| MUXF7 / MUXF8 | 96 / 0 | 96 / 0 | 2 / 1 |
| Distributed RAM | — | — | **3 RAM32M** |

All three are lint-clean. Removing the idle cycle is free. The circular buffer removes 489 flip-flops and about 210 LUTs: the 512-bit shifting delay line and the 32-to-1 multiplexer that selected `taps[k]` are replaced by three `RAM32M` primitives, LUTs configured as small 32-entry memories that hold the 32 × 16 sample bits. What the synthesizer reports as "flip-flops" now is mostly the MAC pipeline and the counters.

The general lesson, which reappears in every large DSP design: **data that is only read in sequence should live in a memory, not in a shift register**, and memories should not be reset.

## Exercise 5: two MACs in parallel

### A MAC that hands over its exact sum

The Part 6 MAC rounds its result inside. To add two partial sums before rounding, each half needs the **raw accumulator**, so `mac_acc.sv` is the same pipeline without the output stage:

```systemverilog
`timescale 1ns/1ps
// mac_acc.sv -- the Part 6 MAC without its output stage: it delivers the EXACT accumulator
// (no rounding) when the last product of a group has been added. Same pipeline as mac.sv.
module mac_acc #(
  parameter int A_W = 16, B_W = 18, ACC_W = 40
) (
  input  logic                    clk, rst,
  input  logic                    in_valid, first, last,
  input  logic signed [A_W-1:0]   a,
  input  logic signed [B_W-1:0]   b,
  output logic                    acc_valid,  // one-cycle pulse: acc holds a finished sum
  output logic signed [ACC_W-1:0] acc
);
  logic signed [A_W-1:0]     a_r;
  logic signed [B_W-1:0]     b_r;
  logic signed [A_W+B_W-1:0] m_r;
  logic v1, v2, first1, first2, last1, last2;

  always_ff @(posedge clk) begin
    if (rst) begin v1 <= 1'b0; v2 <= 1'b0; acc_valid <= 1'b0; end
    else begin v1 <= in_valid; v2 <= v1; acc_valid <= v2 && last2; end
    a_r <= a;  b_r <= b;  first1 <= first;  last1 <= last;
    m_r <= a_r * b_r;     first2 <= first1; last2 <= last1;
    if (v2) acc <= (first2 ? ACC_W'(0) : acc) + ACC_W'(m_r);
  end
endmodule
```

### The two-MAC filter

The controller is `fir_serial_n`'s (no idle cycle), with a counter that runs over N/2 = 16 taps. In each cycle, MAC A gets tap k and MAC B gets tap k + 16, with their coefficients; both see the same `first` and `last`, so they finish in the same cycle. Their sums are added, then rounded once:

```systemverilog
  localparam int H     = N / 2;
  localparam int KW    = (H > 1) ? $clog2(H) : 1;
  localparam int ACC_W = XW + CW + $clog2(N);           // each half's exact sum fits
  localparam int SUM_W = ACC_W + 1;                     // the sum of the two halves
  ...
  logic [$clog2(N)-1:0] ia, ib;                         // the two taps read this cycle

  assign ia = ($clog2(N))'(k);                          // tap k        (first half)
  assign ib = ($clog2(N))'(k) + ($clog2(N))'(H);        // tap k + N/2  (second half)
  ...
  mac_acc #(.A_W(XW), .B_W(CW), .ACC_W(ACC_W)) u_a (
    .clk(clk), .rst(rst), .in_valid(state == S_RUN), .first(k == '0), .last(last_k),
    .a(taps[ia]), .b(fir_coef(32'(ia))), .acc_valid(va), .acc(acc_a));
  mac_acc #(.A_W(XW), .B_W(CW), .ACC_W(ACC_W)) u_b (
    .clk(clk), .rst(rst), .in_valid(state == S_RUN), .first(k == '0), .last(last_k),
    .a(taps[ib]), .b(fir_coef(32'(ib))), .acc_valid(vb_unused), .acc(acc_b));

  // add the exact halves, round once
  assign total = SUM_W'(acc_a) + SUM_W'(acc_b);
  requant #(.IN_W(SUM_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(total), .dout(y_c), .ovf(unused_ovf));
```

The explicit 5-bit indices `ia` and `ib` came from lint: the first version wrote `taps[k]` with the 4-bit counter, and Verilator reported `WIDTHEXPAND: Bit extraction of array[31:0] requires 5 bit index, not 4 bits`. Widening the index explicitly says what is meant and silences it.

### Results

Three seeds, plus a fourth after the lint fix: `PASS: 3000 outputs bit-exact`, in **48,007 or 48,008 cycles**: exactly **16 cycles per sample**, half of the single-MAC design, as expected. Yosys reports **2 DSP48E1** and 573 flip-flops (the shifting delay line is still there; Exercise 4's circular buffer could be combined with this design, using a memory with two read ports or two memories). The design is lint-clean.

### Why add the partial sums before rounding?

Because the model, and the specification, is the exact sum of all 32 products, rounded **once**. Rounding each half separately adds two rounding errors instead of one, and the result can differ by one LSB. Measured in Python on 20,000 samples: rounding each half to Q1.15 and then adding differs from the single rounding in **4,837 outputs (24%)**, always by −1, 0 or +1 LSB. That would break bit-exactness with the other architectures and add noise (two rounding errors have twice the noise power of one, 3 dB more). Adding exact integers first costs only one adder one bit wider than the accumulators.

### Generalization to M MACs

With M MACs, each handles N/M taps, so the throughput is one sample every **⌈N/M⌉ clock cycles** (with the overlap of Exercise 4; one more without it). The partial sums are combined in an adder tree of ⌈log₂ M⌉ levels, followed by one rounding.

| MACs | Clocks per sample (N = 32) | DSP blocks |
| --- | --- | --- |
| 1 | 32 | 1 |
| 2 | 16 | 2 |
| 4 | 8 | 4 |
| 8 | 4 | 8 |
| 32 | 1 | 32 (the fully parallel direct form) |

The choice is set by the ratio of clock rate to sample rate (section 7.8): use M = ⌈N × f\_s / f\_clk⌉ MACs. When that ratio comes close to N, that is, when only a few clocks are available per sample, the controller, the multiplexers that feed each MAC, and the combining tree become a large overhead compared with the multipliers themselves, and a fully parallel form, symmetric if possible and with a pipelined or cascaded sum (Exercise 3), becomes the simpler and cheaper choice.

---

That completes Part 7. Send me your own designs and results if you would like them reviewed.
