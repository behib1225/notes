# Verilog & RTL for DSP — Part 3: State Machines and the RTL Method

*Markdown export of the online document: https://claude.ai/artifact/XngCtA9pBhmBvt1WcnBTXt. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 3 fits

Part 3 adds **control**. Parts 1 and 2 gave you the pieces of a datapath: adders, registers, counters, delay lines. Part 3 shows how a finite-state machine (FSM) sequences those pieces over many clock cycles, which is the RTL design method in its complete form.

You will write FSMs with SystemVerilog `enum` types, compare Moore and Mealy machines, and then build a design the way Mano's Chapter 8 describes it: an ASM chart, split into a **datapath** and a **controller**. The worked example is a shift-and-add multiplier that computes an 8 × 8 product in 8 clock cycles.

Why this matters for DSP: most DSP blocks are pure datapaths that process one sample per clock. But many useful designs trade speed for area by reusing one multiplier for many operations, for example a filter that computes 64 taps with one multiplier over 64 cycles. Those designs need a controller, and that is what you learn here.

As before, every code example was compiled with Icarus Verilog 12.0 (`-g2012 -Wall`) and linted with Verilator 5.020 (`--lint-only -Wall`). Every section ends with "Check your understanding" questions and answers, and section 3.7 has the exercises. If you have not done the Part 2 exercises yet, do them first: this part assumes you are comfortable with `always_ff`, `<=`, resets and clocked testbenches.

## 3.1 What a finite-state machine is

A finite-state machine is a register that holds a **state** (one of a fixed, finite set of values), plus combinational logic that decides the next state and the outputs. Every FSM you will ever write has the same three parts, and keeping them visibly separate in your code is the main skill of this part.

> **Figure:** the three parts of an FSM (shown in the [online version](https://claude.ai/artifact/XngCtA9pBhmBvt1WcnBTXt))

1. **The state register**: a group of flip-flops holding the current state. It is the only memory in the FSM, and it updates at every rising clock edge, exactly like the registers in Part 2.
2. **The next-state logic**: combinational logic that computes the next state from the current state and the inputs. It is the state diagram written as logic.
3. **The output logic**: combinational logic that computes the outputs.

### Moore and Mealy

Mano introduces two kinds of FSM, and the difference is entirely in the output logic:

|  | Moore machine | Mealy machine |
| --- | --- | --- |
| Outputs depend on | The current state only | The current state **and** the current inputs |
| In a state diagram | Outputs are written inside the state circles | Outputs are written on the transition arrows |
| Output timing | Changes only after a clock edge | Can change in the middle of a cycle when an input changes |
| Reaction to an input | One cycle later | In the same cycle |
| Number of states | Usually more | Usually fewer |

Both are correct designs; you choose based on timing. Section 3.3 compares them on the same problem.

### Where FSMs appear in DSP hardware

The sample-processing datapath of a filter rarely needs an FSM. The control around it does: starting and stopping a computation, loading coefficients, sequencing a single multiplier through many taps, running the stages of an FFT, or detecting a synchronization pattern in a received bit stream. That last one is our first example.

### Check your understanding: 3.1

1. Name the three parts of an FSM, and say which of them contain flip-flops.
2. An FSM has 5 states. What is the minimum number of flip-flops in its state register?
3. In a Moore machine, can an output change while the clock is not ticking? In a Mealy machine?
4. A traffic-light controller shows red, green or yellow, and changes after a timer expires. Is it more naturally Moore or Mealy? Why?
5. Why is a counter (Part 2) also an FSM?

#### Answers

1. The state register, the next-state logic and the output logic. Only the state register contains flip-flops; the other two are combinational.
2. **3**, since ⌈log₂ 5⌉ = 3 and 3 bits give 8 codes, enough for 5 states. (Section 3.4 explains why tools sometimes use more, such as one flip-flop per state.)
3. Moore: no. Its outputs depend only on the state register, which changes only at clock edges. Mealy: yes. Its outputs also depend on the inputs, so they follow an input change at any moment within the cycle.
4. Moore. Each light corresponds to a state and is shown for the whole time the machine is in that state; the timer input only decides **when** to move on, not what is displayed right now.
5. Its count register is a state register, `count + 1` (with wrap-around) is its next-state logic, and terminal count is its output logic. It is simply an FSM whose state diagram is a ring, where the states are numbered rather than named.

## 3.2 Coding an FSM

Write every FSM as two blocks: an `always_ff` for the state register, and an `always_comb` with a `case` statement for the next-state logic. Name the states with an `enum`, so code, waveforms and messages show `S_101` instead of `3'b011`.

### The problem: a sequence detector

A serial input `din` delivers one bit per clock cycle. Raise `found` whenever the last four bits received were 1, 0, 1, 1 (oldest first). Patterns may **overlap**: in the stream 1011011, the final "1" of the first match is also the first "1" of the second (bits 1011**011** contain a second 1011 starting at the fourth bit). Detecting a synchronization word like this is the first job of many digital receivers.

Each state records **how much of the pattern has been seen so far**:

> **Figure:** Moore state diagram of the 1011 detector (shown in the [online version](https://claude.ai/artifact/XngCtA9pBhmBvt1WcnBTXt))

The transitions that need thought are the ones that do not simply advance. In `S_101` a 0 arrives: the input now ends in "1010", whose longest useful ending is "10", so go to `S_10`, not back to the start. In `S_1011` a 1 arrives: the input ends in "10111", whose longest useful ending is "1", so go to `S_1`. That is how overlap is handled.

### The code

```systemverilog
`timescale 1ns/1ps
// detect1011_moore.sv -- Moore FSM: found = 1 for one cycle after the input
// has shown the bits 1,0,1,1 (oldest first). Overlapping patterns count.
module detect1011_moore (
  input  logic clk,
  input  logic rst,        // synchronous, active-high
  input  logic din,        // one serial bit per clock cycle
  output logic found
);
  // 1. The states: one name per "how much of the pattern have I seen?"
  typedef enum logic [2:0] {
    S_IDLE,    // nothing useful seen yet
    S_1,       // seen "1"
    S_10,      // seen "10"
    S_101,     // seen "101"
    S_1011     // seen "1011": the pattern is complete
  } state_t;

  state_t state, next;

  // 2. The state register: the only flip-flops in the FSM
  always_ff @(posedge clk) begin
    if (rst) state <= S_IDLE;
    else     state <= next;
  end

  // 3. Next-state logic: combinational, a direct copy of the state diagram
  always_comb begin
    next = state;                          // default: stay
    case (state)
      S_IDLE: if (din) next = S_1;     else next = S_IDLE;
      S_1:    if (din) next = S_1;     else next = S_10;
      S_10:   if (din) next = S_101;   else next = S_IDLE;
      S_101:  if (din) next = S_1011;  else next = S_10;
      S_1011: if (din) next = S_1;     else next = S_10;
      default: next = S_IDLE;              // unreachable codes 5..7: recover
    endcase
  end

  // 4. Output logic: Moore, so it depends on the state only
  assign found = (state == S_1011);
endmodule
```

### What is new here

- **`typedef enum logic [2:0] { ... } state_t;`** defines a new type, `state_t`, whose values are the listed names. The `logic [2:0]` part is the underlying storage: 3 bits. By default the names are numbered 0, 1, 2, ... in order, so `S_1011` is 4.
- **`state_t state, next;`** declares the state register and its next value with that type. The tools now check that you only assign state names to them.
- **The `default: next = S_IDLE;` branch** handles the codes 5, 6 and 7, which have no name. They should never occur, but section 3.4 explains why recovering from them is good practice.
- **`next = state;` at the top** is the default assignment from section 1.5, which prevents latches. Here it also means "if nothing below says otherwise, stay in this state".
- In a testbench or a `$display`, **`state.name()`** returns the state's name as a string, for example `S_101`. Waveform viewers also show the names.

### Two gotchas found while testing this code

**Icarus rejects `?:` between enum values.** The more compact `S_IDLE: next = din ? S_1 : S_IDLE;` compiles in many tools, but Icarus 12 reports `error: This assignment requires an explicit cast.` for every such line. Writing `if (din) ... else ...` works everywhere and is easier to read, so use it.

**SystemVerilog has many reserved words.** The first version of the testbench used a counter named `matches`; Icarus reported a baffling `syntax error`. `matches` is a SystemVerilog keyword (used in pattern matching). Others that catch people include `program`, `property`, `sequence`, `bit`, `byte`, `string`, `type` and `interface`. If a perfectly ordinary-looking declaration gives a syntax error, suspect a keyword.

### Testing it

The testbench keeps the last four input bits in a 4-bit shift register, `last4`, and compares them with `4'b1011`. That model is so simple that it is obviously right, which is exactly what a reference model should be. For the Moore machine, the model's answer is delayed by one cycle (section 3.3 explains why):

```systemverilog
    repeat (5000) begin
      din = $urandom_range(0, 1);
      exp_mealy = ({last4[2:0], din} == 4'b1011);   // pattern complete with this bit
      #1;
      if (found_mealy !== exp_mealy || found_moore !== exp_moore) begin
        $display("FAIL at %0d ns: mealy=%b (exp %b) moore=%b (exp %b)",
                 $time, found_mealy, exp_mealy, found_moore, exp_moore);
        errors++;
      end
      if (exp_mealy) hits++;
      last4     = {last4[2:0], din};   // the FSMs take this bit at the next edge
      exp_moore = exp_mealy;           // Moore reports it one cycle later
      @(negedge clk);
    end
```

The same loop checks the Mealy version from section 3.3. It printed `PASS: 5000 bits, 319 patterns found`. As a sanity check, 5,000 random bits should contain about 5,000 / 16 ≈ 312 occurrences of a 4-bit pattern, which matches. When the overlap transition out of `S_1011` was broken on purpose (always going back to `S_IDLE`), the testbench reported `FAILED with 52 errors`.

### Check your understanding: 3.2

1. What numeric code does the tool give `S_101` by default? How many bits does `state_t` use, and how many codes are unused?
2. Why is `next = state;` placed at the top of the `always_comb` block?
3. Trace the Moore machine on the input 1, 1, 0, 1, 1, 0, 1, 1 starting from `S_IDLE`. In which cycles is `found` high?
4. You want to detect the non-overlapping version: after a match, the next match must start fresh. Which single transition changes?
5. Why is the testbench model (`last4 == 4'b1011`) a better reference than a second copy of the state machine?

#### Answers

1. 3 (the fourth name, counting from 0). `state_t` uses 3 bits, giving 8 codes, of which 5 are used and **3 are unused** (5, 6 and 7).
2. It is the default assignment: every path through the block assigns `next`, so no latch is inferred, and any state whose `case` branch does not change `next` simply stays where it is.
3. The states after each bit are: S\_1, S\_1, S\_10, S\_101, S\_1011, S\_10, S\_101, S\_1011. `found` is high **during the cycle after** bit 5 and the cycle after bit 8, that is, while the machine is in `S_1011`. Bits 2 to 5 (1, 0, 1, 1) form the first match and bits 5 to 8 (1, 0, 1, 1) the second; they share bit 5.
4. Only the **0 transition out of `S_1011`** changes: it goes to `S_IDLE` instead of `S_10`. In the overlapping version, `S_10` reuses the match's final 1 as the start of a new "10"; the non-overlapping version must not reuse it. The 1 transition stays `S_1`, because that new 1 is a fresh bit, not part of the old match. We checked: on the input 1011011, the overlapping detector reports 2 matches and the modified one reports 1.
5. A second state machine could contain the same design mistake as the first, and both would agree on the wrong answer. A model built differently (here, by directly comparing the last four bits) is unlikely to share the bug, so a disagreement really means something.

## 3.3 Mealy machines, output timing and registered outputs

A Mealy machine reports the pattern in the same cycle as its final bit, using one fewer state. The price is an output that is a combinational function of the input, and in a large design that costs timing. The usual compromise is to **register** the output.

### The Mealy detector

The pattern is complete the moment a 1 arrives in state `S_101`, so the Mealy machine needs no `S_1011` state:

```systemverilog
`timescale 1ns/1ps
// detect1011_mealy.sv -- Mealy FSM: found = 1 in the SAME cycle as the
// final 1 of the pattern 1,0,1,1. Overlapping patterns count.
module detect1011_mealy (
  input  logic clk,
  input  logic rst,
  input  logic din,
  output logic found
);
  typedef enum logic [1:0] {S_IDLE, S_1, S_10, S_101} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_IDLE;
    else     state <= next;
  end

  always_comb begin
    next = state;
    case (state)
      S_IDLE: if (din) next = S_1;     else next = S_IDLE;
      S_1:    if (din) next = S_1;     else next = S_10;
      S_10:   if (din) next = S_101;   else next = S_IDLE;
      S_101:  if (din) next = S_1;     else next = S_10;     // after "1011", the last "1" may start a new match
      default: next = S_IDLE;
    endcase
  end

  // Mealy output: depends on the state AND the current input
  assign found = (state == S_101) && din;
endmodule
```

Four states fit in 2 bits, so `state_t` is `logic [1:0]` and every code is used.

### The two machines side by side

This trace feeds both machines the stream 1011011010, printing the values in the middle of each cycle:

```text
cycle din  moore_state  found_moore found_mealy
  0    1    S_IDLE       0           0
  1    0    S_1          0           0
  2    1    S_10         0           0
  3    1    S_101        0           1
  4    0    S_1011       1           0
  5    1    S_10         0           0
  6    1    S_101        0           1
  7    0    S_1011       1           0
  8    1    S_10         0           0
  9    0    S_101        0           0
```

The pattern is completed by the input bits in cycles 3 and 6 (the second match overlaps the first). The Mealy output is high **in those same cycles**, while the bit is still on the input. The Moore output is high **one cycle later**, because the machine must first enter `S_1011` at the clock edge.

### Why designers are wary of Mealy outputs

`found_mealy` is a combinational path from the input `din` to the output, with no flip-flop in between. Three consequences:

1. **Timing paths get longer.** If `din` itself comes from combinational logic in another block, and `found` feeds more logic in a third block, the whole chain must settle in one clock period (section 2.1 of Part 2).
2. **Glitches.** While `din` and the state settle within a cycle, `found_mealy` can pulse briefly. That is harmless if `found` is only sampled by flip-flops at the next edge, but harmful if it drives anything that reacts immediately.
3. **Feedback loops.** Two Mealy machines whose outputs feed each other's inputs can form a combinational loop, a circuit that may oscillate.

### The compromise: registered outputs

Put a flip-flop on the output. This version computes the same Mealy condition but stores it:

```systemverilog
  // Registered Mealy output: same logic, stored in a flip-flop
  always_ff @(posedge clk) begin
    if (rst) found_r <= 1'b0;
    else     found_r <= (state == S_101) && din;
  end
```

`found_r` comes straight out of a flip-flop: no glitches and no combinational path through the block. It arrives with the **same timing as the Moore output** (we ran it through the same 5,000-bit testbench and it matched the Moore model exactly), but it needs only four states. A common rule in larger designs, and the one this course follows, is: **every output of a module comes from a flip-flop**, unless there is a specific reason for it not to.

### Check your understanding: 3.3

1. In the trace, the stream contains a third partial pattern at the end. Why is neither output high in cycle 9?
2. Why does the Mealy detector need only four states while the Moore detector needs five?
3. Is `found_r` a Moore output or a Mealy output? Explain carefully.
4. A designer needs the earliest possible reaction to the pattern, in the same cycle. Which machine, and what must they check?
5. Your module's output is `assign ready = (state == S_WAIT) && !fifo_full;`. A reviewer asks you to register it. What changes for the logic that uses `ready`?

#### Answers

1. The last bits are 1, 0, 1, 0: after "101" the next bit is 0, not 1. The Moore machine goes to `S_10`, and the Mealy machine's condition `(state == S_101) && din` is false. There is no match.
2. The Mealy output can say "the pattern is complete right now" from `S_101` plus the incoming 1. A Moore output can only depend on the state, so it needs a separate state, `S_1011`, that means "the pattern was just completed".
3. From the outside it behaves like a Moore output: it comes from a flip-flop and changes only at clock edges. Strictly, the flip-flop holding it is part of the state, so the module is a Moore machine with a larger state (the enum state plus `found_r`) even though its logic was written in Mealy style. That is why its timing matches the Moore version.
4. The Mealy machine, with the unregistered output. They must make sure the combinational path from the input, through the output logic, to wherever `found` is used, fits in one clock period, and that nothing uses `found` without sampling it in a flip-flop first.
5. The registered `ready` will change one cycle later than before. Any logic that relied on `ready` reacting in the same cycle as `fifo_full` must be redesigned to tolerate the extra cycle of delay, for example by registering early (using the next state) or by leaving some slack in the FIFO.

## 3.4 State encoding and safe recovery

The **encoding** is the bit pattern chosen for each state. Write your FSM with named states and let the synthesis tool choose; it will usually pick well. You should still understand the options, because they explain resource reports and a few real-world failures.

### The common encodings

For the five-state Moore detector:

| State | Binary (default) | Gray | One-hot |
| --- | --- | --- | --- |
| `S_IDLE` | `000` | `000` | `00001` |
| `S_1` | `001` | `001` | `00010` |
| `S_10` | `010` | `011` | `00100` |
| `S_101` | `011` | `010` | `01000` |
| `S_1011` | `100` | `110` | `10000` |
| Flip-flops | 3 | 3 | 5 |

- **Binary** uses the fewest flip-flops, ⌈log₂ N⌉, but the next-state logic must decode several bits at once.
- **Gray** codes neighboring states so that they differ in one bit. It helps when the state sequence is mostly a fixed order, as in counters, and it is essential for counters that cross between clock domains (a topic for later).
- **One-hot** uses one flip-flop per state, with exactly one bit set. It needs more flip-flops but very simple logic: "am I in `S_101`?" is a single bit. FPGAs have flip-flops in abundance, so synthesis tools for FPGAs usually choose one-hot (or a close variant) automatically for small and medium FSMs.

Synthesis tools such as Vivado and Yosys recognize FSMs written in the style of section 3.2 and re-encode them automatically; their reports tell you which encoding they chose. That is one more reason to write FSMs in the standard template: an FSM written in an unusual style may not be recognized.

### Choosing the encoding yourself

You can assign explicit values to the enum names. This one-hot version of the detector lints cleanly and behaves identically:

```systemverilog
  typedef enum logic [4:0] {
    S_IDLE = 5'b00001, S_1 = 5'b00010, S_10 = 5'b00100, S_101 = 5'b01000, S_1011 = 5'b10000
  } state_t;
```

The width you give the enum must hold every value. Declaring five names in `logic [1:0]` is caught at compile time. Icarus reports `Enumeration name E has an inferred value that overflowed`, and Verilator reports `Enum value illegally wrapped around`. In practice, hand-encoding is rarely needed; it is mostly used when an output should be one state bit directly.

### Unreachable states and safe recovery

Three flip-flops give 8 codes, but the binary Moore detector uses only 5. Codes 5, 6 and 7 are **unreachable**: no sequence of inputs leads there from reset. With one-hot, 27 of the 32 codes of 5 bits are unreachable.

Could the FSM ever land in one? In normal operation, no. But a radiation-induced bit flip (a real concern in space and avionics), a power glitch, or a timing violation on an unsynchronized input can push the state register into an illegal code. If the next-state logic has no rule for that code, the FSM can be stuck forever.

The `default: next = S_IDLE;` branch states your intent: "from anything unexpected, go back to idle". Two caveats:

1. In simulation, the `default` branch also catches `x`. A `case` item matches only exact values, so a state of `xxx` matches nothing and falls into `default`. We checked: with reset never asserted, the detector's state was `xxx` at 1 ns and `S_IDLE` after the first clock edge. That can **hide a missing reset** in simulation, while real hardware may power up in any state. Always drive reset in your testbenches, and check the reset value explicitly.
2. Synthesis tools may **optimize the recovery logic away**, because they know the codes are unreachable and treat them as "don't care". If you genuinely need recovery (safety-critical designs), you must request it with a tool option. Vivado, for example, has an `fsm_safe_state` attribute for this. For this course, the `default` branch is enough.

### Check your understanding: 3.4

1. An FSM has 12 states. How many flip-flops does it need with binary encoding and with one-hot encoding? How many codes are unreachable in each case?
2. In a one-hot FSM, write the expression for "the FSM is in `S_10`", assuming `S_10` is bit 2.
3. Why might an FPGA tool prefer one-hot even though it uses more flip-flops?
4. Why does writing `default: next = S_IDLE;` not guarantee that the hardware recovers from an illegal state?
5. You declare `typedef enum logic [2:0] {...}` with 9 names. What happens?

#### Answers

1. Binary: ⌈log₂ 12⌉ = **4** flip-flops, 16 codes, **4** unreachable. One-hot: **12** flip-flops, 4,096 codes, **4,084** unreachable.
2. `state[2]`. With one-hot encoding, a single bit identifies the state, so no decoding is needed. (Comparing `state == S_10` gives the same result; the synthesis tool reduces it to that one bit, because it knows the other codes cannot occur.)
3. FPGAs provide one or more flip-flops beside every lookup table, so flip-flops are cheap, while next-state logic that decodes many state bits costs lookup tables and adds delay. One-hot logic is shallow and fast.
4. Because the synthesis tool may treat unreachable codes as don't-cares and remove the logic that handles them; the `default` branch then exists only in simulation. Guaranteed recovery requires asking the tool for a safe FSM implementation.
5. It fails to compile: 3 bits hold only 8 values, so the ninth name overflows. Icarus and Verilator both report an error. Widen the enum to `logic [3:0]`.

## 3.5 The RTL method: datapath plus controller

Any algorithm that takes several clock cycles can be built the same way: a **datapath** holds the data and does the arithmetic, and a **controller** (an FSM) tells it what to do in each cycle. This is the method of Mano's Chapter 8, and it scales from a multiplier to a processor.

### The method, step by step

1. **Write the algorithm** in plain words or pseudocode.
2. **Identify the datapath**: which registers hold the data, and which operations (add, shift, compare, count) happen to them.
3. **Draw the ASM chart** (algorithmic state machine): the states, the decisions, and which datapath operation happens in each state.
4. **Name the signals between the two halves.** **Control signals** go from the controller to the datapath ("load", "step"). **Status signals** go from the datapath to the controller ("last step", "result is zero").
5. **Write the datapath and the controller as separate modules**, and a top level that connects them.
6. **Verify** the top level against a simple model.

### Step 1: the algorithm

Shift-and-add multiplication is long multiplication in binary. For each bit of the multiplier, from the least significant up: if the bit is 1, add the multiplicand to a running total; then move on to the next bit, which is worth twice as much.

Mano's version does this in registers of fixed size by shifting the **running total right**, instead of shifting the multiplicand left. It uses:

| Register | Width | Holds |
| --- | --- | --- |
| `B` | W bits | The multiplicand, unchanged during the computation |
| `Q` | W bits | The multiplier; one bit is consumed per step, from bit 0 |
| `A` | W bits | The upper half of the running product |
| `P` | ⌈log₂ W⌉ bits | A step counter, W−1 down to 0 |

Each step: if `Q[0]` is 1, add `B` to `A` (the carry out is kept); then shift the carry, `A` and `Q` right by one place as a single 2W+1-bit unit. After W steps, `{A, Q}` holds the 2W-bit product: the bits of the product have been shifted into `Q` from the left as the multiplier bits were shifted out to the right.

### Steps 2 and 3: the ASM chart

The controller needs only three states:

> **Figure:** ASM chart of the multiplier controller (shown in the [online version](https://claude.ai/artifact/XngCtA9pBhmBvt1WcnBTXt))

In an ASM chart, a rectangle is a **state** (outputs written inside are asserted for the whole state, like Moore outputs), a diamond is a **decision** on an input, and a rounded box after a decision is a **conditional output** (asserted only on that path, like a Mealy output). Here, `load` is a conditional output: it is asserted in `IDLE` only when `start` is 1.

### Step 4: the interface between the halves

> **Figure:** multiplier: controller and datapath (shown in the [online version](https://claude.ai/artifact/XngCtA9pBhmBvt1WcnBTXt))

The controller never touches the data, and the datapath never makes decisions. That separation is what keeps large designs understandable.

### Step 5: the code

The datapath:

```systemverilog
`timescale 1ns/1ps
// mult_datapath.sv -- registers and arithmetic for a W x W shift-and-add multiplier
// (after Mano's binary multiplier: accumulator A, multiplier Q, multiplicand B, counter P)
module mult_datapath #(
  parameter  int W  = 8,
  localparam int PW = $clog2(W)            // counter width: holds 0 .. W-1
) (
  input  logic           clk,
  input  logic           load,             // control: initialize for a new product
  input  logic           step,             // control: one add-and-shift step
  input  logic [W-1:0]   a_in, b_in,       // operands, sampled when load = 1
  output logic           last,             // status: this is the final step
  output logic [2*W-1:0] product           // valid after the final step
);
  logic [W-1:0]  A, B, Q;
  logic [PW-1:0] P;
  logic [W:0]    sum;                      // W+1 bits: carry out of A + B

  // Combinational: add B to A only if the current multiplier bit is 1
  assign sum  = Q[0] ? ({1'b0, A} + {1'b0, B}) : {1'b0, A};
  assign last = (P == '0);

  always_ff @(posedge clk) begin
    if (load) begin
      A <= '0;
      B <= b_in;                           // multiplicand
      Q <= a_in;                           // multiplier, consumed one bit per step
      P <= PW'(W - 1);                     // W steps: W-1 down to 0
    end else if (step) begin
      // add, then shift {carry, A, Q} right by one -- all in one clock edge:
      // the carry (sum[W]) lands in A's MSB, Q's LSB (already used) falls off
      {A, Q} <= {sum, Q[W-1:1]};
      P <= P - 1'b1;
    end
  end

  assign product = {A, Q};
endmodule
```

The key line is `{A, Q} <= {sum, Q[W-1:1]};`. The right-hand side is the W+1-bit sum (carry included) followed by the upper W−1 bits of `Q`: 2W bits in total, which is exactly `{A, Q}` shifted right by one with the carry entering at the top. Concatenation on **both** sides lets one line describe a shift across two registers.

Mano's original design does the add and the shift in **separate** clock cycles, so it needs a carry flip-flop, `C`, to hold the carry between them. Our first version kept `C`, and Verilator's lint immediately reported `Signal is not used: 'C'`: doing both operations in one edge sends the carry straight into `A`, so the flip-flop is unnecessary. A lint warning about an unused signal often points to a design simplification.

The controller is an FSM in the section 3.2 style, with its outputs in the same `always_comb` block and defaults at the top:

```systemverilog
`timescale 1ns/1ps
// mult_ctrl.sv -- controller FSM for the shift-and-add multiplier
module mult_ctrl (
  input  logic clk,
  input  logic rst,
  input  logic start,      // request: begin a multiplication
  input  logic last,       // status from the datapath
  output logic load,       // control to the datapath
  output logic step,       // control to the datapath
  output logic busy,       // a multiplication is in progress
  output logic done        // one-cycle pulse: product is ready
);
  typedef enum logic [1:0] {S_IDLE, S_RUN, S_DONE} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_IDLE;
    else     state <= next;
  end

  // Next state AND outputs in one block, with defaults first
  always_comb begin
    next = state;
    load = 1'b0;
    step = 1'b0;
    done = 1'b0;
    case (state)
      S_IDLE: begin
        if (start) begin
          load = 1'b1;
          next = S_RUN;
        end
      end
      S_RUN: begin
        step = 1'b1;
        if (last) next = S_DONE;
      end
      S_DONE: begin
        done = 1'b1;
        next = S_IDLE;
      end
      default: next = S_IDLE;
    endcase
  end

  assign busy = (state != S_IDLE);
endmodule
```

The top level only wires the halves together:

```systemverilog
`timescale 1ns/1ps
// seq_mult.sv -- top level: controller + datapath
module seq_mult #(
  parameter int W = 8
) (
  input  logic           clk,
  input  logic           rst,
  input  logic           start,
  input  logic [W-1:0]   a, b,
  output logic           busy,
  output logic           done,
  output logic [2*W-1:0] product
);
  logic load, step, last;   // the wires between the two halves

  mult_ctrl u_ctrl (
    .clk(clk), .rst(rst), .start(start), .last(last),
    .load(load), .step(step), .busy(busy), .done(done)
  );

  mult_datapath #(.W(W)) u_dp (
    .clk(clk), .load(load), .step(step), .a_in(a), .b_in(b),
    .last(last), .product(product)
  );
endmodule
```

Notice that the datapath has **no reset**. Its registers are always loaded by `load` before they are used, so resetting them would add logic for nothing, which is the guidance from section 2.4 of Part 2. Only the controller, which decides what happens, is reset.

### Watching it work: 13 × 11

This trace prints the registers in the middle of each cycle after `start`:

```text
step state   Q(multiplier) A(accum)  P  {A,Q}
 0   S_RUN   00001101      00000000  7  13
 1   S_RUN   10000110      00000101  6  1414
 2   S_RUN   11000011      00000010  5  707
 3   S_RUN   11100001      00000110  4  1761
 4   S_RUN   11110000      00001000  3  2288
 5   S_RUN   01111000      00000100  2  1144
 6   S_RUN   00111100      00000010  1  572
 7   S_RUN   00011110      00000001  0  286
 8   S_DONE  10001111      00000000  7  143
 9   S_IDLE  10001111      00000000  7  143
```

Read the `Q` column: 13 = `00001101` is loaded, and its bits leave from the right one per step while product bits enter from the left. In step 0, `Q[0]` = 1, so 11 is added to `A`. After 8 steps, `{A, Q}` = 143 = 13 × 11. Also note that the `product` output shows meaningless intermediate values during `S_RUN`: it is only valid when `done` is 1. (`P` wraps from 0 to 7 at the final step; that is harmless, because the controller has already left `S_RUN`.)

### Step 6: verification

The testbench uses a `task` that requests one multiplication, sets the operand inputs to `'x` immediately afterwards (proving the design captured them and never reads them again), waits for `done`, and checks both the product and the number of cycles:

```systemverilog
  task automatic multiply(input logic [W-1:0] ta, tb);
    int cycles;
    @(negedge clk);
    a = ta;  b = tb;  start = 1'b1;          // request, for exactly one cycle
    @(negedge clk);
    start = 1'b0;
    a = 'x;  b = 'x;                         // operands must not be needed any more
    cycles = 1;
    while (!done) begin
      @(negedge clk);
      cycles++;
    end
    tests++;
    if (product !== ta * tb || cycles != W + 1) begin
      $display("FAIL: %0d * %0d = %0d after %0d cycles (expected %0d after %0d)",
               ta, tb, product, cycles, ta * tb, W + 1);
      errors++;
    end
  endtask
```

The main sequence runs the corner cases (0 × 0, 1 × 1, 255 × 255, 255 × 1, 1 × 255, 128 × 2) and then 1,000 random pairs, with a watchdog as in Part 2. Result: `PASS: 1006 products correct, 9 cycles each`. When the counter was deliberately loaded with W−2 instead of W−1, the very first test failed, `FAIL: 0 * 0 = 0 after 8 cycles (expected 0 after 9)`, and the second showed a wrong product, `1 * 1 = 2`. Checking the cycle count caught the bug even when the product happened to be right.

### The trade-off

A combinational 8 × 8 multiplier produces a product every clock cycle but needs about 64 AND gates and dozens of adders. This design needs one 8-bit adder, a few registers and a tiny FSM, but takes 9 cycles per product. That **area versus throughput** trade-off is a central theme of DSP hardware: Part 6 uses fast parallel multipliers (FPGAs have hard multiplier blocks), and Part 7 shows filters that reuse one multiplier for many taps, controlled exactly like this.

### Check your understanding: 3.5

1. Classify each signal in `seq_mult` as a control signal, a status signal, or neither: `load`, `step`, `last`, `done`, `product`.
2. Why is `load` a conditional output in the ASM chart, and what would go wrong if it were asserted for the whole `IDLE` state?
3. Using the trace, explain why `A` is `00000101` after step 0, given that 0 + 11 = 11 = `00001011`.
4. How many cycles does a 16 × 16 multiplication take with this design (W = 16)? How many flip-flops does `P` need?
5. Why does the testbench set `a` and `b` to `'x` after `start`?
6. A colleague suggests removing the controller and letting the datapath run continuously. What information does the controller provide that the datapath cannot?

#### Answers

1. `load` and `step`: **control** (controller to datapath). `last`: **status** (datapath to controller). `done` and `product`: **neither**; they are outputs of the whole design to the outside world.
2. `load` overwrites `A`, `B`, `Q` and `P`. If it were asserted throughout `IDLE`, the datapath would reload on every idle cycle, which wastes power and, worse, overwrites the finished `product` that the outside world reads after `done`. As a conditional output, it fires only in the one cycle when a new multiplication starts.
3. The sum 11 = `0_00001011` (9 bits, carry 0) is shifted right by one together with `Q`. Its lowest bit, 1, moves into the top of `Q` (`Q` goes from `00001101` to `10000110`), and the remaining bits become `A` = `00000101` = 5. Nothing is lost: `{A, Q}` = 5 × 256 + 134 = 1414 holds the partial product and the remaining multiplier bits together.
4. W + 1 = **17 cycles** from `start` to `done` (16 steps plus the load cycle, as measured for W = 8: 9 cycles). `P` needs ⌈log₂ 16⌉ = **4** flip-flops to count from 15 down to 0.
5. To prove that the design captured its operands at `load` and never reads the inputs again. If it did, `x` would propagate into the product and the check would fail. Real systems often change the inputs right after a request, so this is a real requirement.
6. Sequencing: when a computation starts (in response to `start`), when it ends (after exactly W steps), and telling the outside world that the result is ready (`done`) and that the unit is in use (`busy`). The datapath can only perform operations; it does not know which operation is needed when.

## 3.6 Handshakes between blocks

When a block takes a variable or unknown number of cycles, the blocks around it need an agreed protocol for "here is data" and "I have taken it". The two you will use in this course are start/busy/done, which you have just built, and **valid/ready**, the standard for streaming DSP data.

### start / busy / done

This is the protocol of the multiplier in section 3.5:

| Signal | Direction | Meaning |
| --- | --- | --- |
| `start` | Into the block | Begin now, using the inputs present in this cycle |
| `busy` | Out of the block | Working; a `start` now will be ignored |
| `done` | Out of the block | A one-cycle pulse: the result is valid in this cycle |

Its weakness is that the requester must watch `busy`, and a `start` sent while the block is busy is silently lost: in `mult_ctrl`, the `S_RUN` state never looks at `start`. A protocol in which data cannot be lost is better.

### valid / ready

The valid/ready handshake connects a **source** to a **sink**:

- The source drives `valid` high when it has data on its data lines.
- The sink drives `ready` high when it can accept data.
- **A transfer happens at a rising clock edge where both `valid` and `ready` are 1.** Nothing else counts as a transfer.

Two rules make it safe:

1. **Once the source raises `valid`, it must keep `valid` high and the data unchanged until the transfer happens.** It cannot withdraw an offer.
2. **The source must not wait for `ready` before raising `valid`.** The sink, however, may wait for `valid` before raising `ready`. If both waited for each other, nothing would ever move: a deadlock.

This is exactly the handshake of the AXI4-Stream interface from Arm's AMBA specification (`TVALID`, `TREADY`, `TDATA`), which AMD's FPGA DSP IP blocks use throughout, so learning it now pays off directly.

### Wrapping the multiplier

Turning `seq_mult` into a valid/ready sink takes two lines of logic: it is ready whenever it is idle, and a transfer (`start`) happens when the source is valid and the multiplier is ready.

```systemverilog
`timescale 1ns/1ps
// mult_stream.sv -- seq_mult with a valid/ready input and a valid output
module mult_stream #(
  parameter int W = 8
) (
  input  logic           clk,
  input  logic           rst,
  input  logic           in_valid,     // source: a, b hold a new operand pair
  output logic           in_ready,     // this block: I can accept a pair now
  input  logic [W-1:0]   a, b,
  output logic           out_valid,    // one-cycle pulse: product is valid
  output logic [2*W-1:0] product
);
  logic busy, start;

  assign in_ready = !busy;                  // ready whenever the multiplier is idle
  assign start    = in_valid && in_ready;   // a transfer happens on this edge

  seq_mult #(.W(W)) u_mult (
    .clk(clk), .rst(rst), .start(start), .a(a), .b(b),
    .busy(busy), .done(out_valid), .product(product)
  );
endmodule
```

The testbench for it uses a source that offers a new operand pair at random moments and holds each offer until it is accepted (rule 1). It stores the expected product of every accepted pair in a **queue**, `logic [15:0] expected [$];` (a variable-length list with `push_back` and `pop_front`), and checks the outputs in order. It printed `PASS: 200 products through valid/ready`. Because the source holds its data until `in_ready` is high, no request can be lost, whatever the timing.

The output side here is only `out_valid`, with no `out_ready`: the sink must take each product in the cycle it appears. Full valid/ready on both sides, which lets a slow sink stall the whole pipeline (**backpressure**), comes in a later part.

### Check your understanding: 3.6

1. At five consecutive rising edges, (valid, ready) = (1,0), (1,0), (1,1), (0,1), (1,1). How many transfers happen, and at which edges?
2. A source raises `valid` only after it sees `ready` high, and the sink raises `ready` only after it sees `valid` high. What happens?
3. During the cycles between edges 1 and 3 in question 1, may the source change its data? Why?
4. Why is valid/ready better than start/busy/done when the requester is another block that does not track `busy`?
5. In `mult_stream`, `in_ready` is a combinational function of the controller state. Does it break any rule?

#### Answers

1. **Two** transfers: at edge 3 and edge 5, the only edges where both signals are 1. At edges 1 and 2 the source is offering but the sink is not ready; at edge 4 the sink is ready but there is no data.
2. **Deadlock.** Each waits for the other forever. This is why rule 2 forbids the source from waiting for `ready`.
3. **No.** The offer made at edge 1 has not been accepted yet, so by rule 1 the data and `valid` must stay unchanged until the transfer at edge 3.
4. With start/busy/done, a `start` sent while the block is busy is lost, and nothing reports the loss. With valid/ready, the source keeps offering until the sink accepts, so every item is transferred exactly once, and the sink controls the pace.
5. No. `in_ready` depends only on the multiplier's own state, not on `in_valid`, so the sink is not waiting for anything and no combinational loop is formed. (A sink **may** make `ready` depend on `valid`; the source may never make `valid` depend on `ready`.)

## 3.7 Exercises

Do all five before Part 4; for scale, their worked solutions add 7 design files and 6 testbenches, about 570 new lines (time depends too much on experience for a reliable estimate). For each FSM, **draw the state diagram or ASM chart on paper before writing code**. Use synchronous `rst`, a self-checking clocked testbench with a watchdog, and lint every file. Send me your diagrams and code when you are done.

- [ ] Exercise 1: detect 0110, three ways
- [ ] Exercise 2: traffic-light controller
- [ ] Exercise 3: serial (UART) transmitter
- [ ] Exercise 4: sequential divider
- [ ] Exercise 5: find the four bugs

Exercise 5 uses a third free tool, the **Yosys** synthesizer, which Part 4 covers properly. Install it now: `sudo apt install yosys` on Linux or WSL, or `brew install yosys` on macOS. To check a file for latches, run `yosys -p "read_verilog -sv file.sv; proc"`.

### Exercise 1: detect 0110, three ways

Detect the overlapping pattern 0, 1, 1, 0 (oldest first) in a serial bit stream.

- Write a Moore version, a Mealy version, and a Mealy version with a registered output.
- Check all three against a `last4` model in one testbench, as in section 3.2, on 5,000 random bits. Report how many patterns were found and compare with the expected count.
- Which states are needed in each version? Explain each transition that does not go back to the start.

### Exercise 2: traffic-light controller

A light cycles green (5 ticks), yellow (2 ticks), red (4 ticks), and repeats. A **tick** is a one-cycle enable from the `tick_gen` of Part 2 (use DIV = 4 in simulation so the test is fast).

- Split it into a controller (states `S_GREEN`, `S_YELLOW`, `S_RED`) and a datapath (a down-counter timer that the controller loads with each state's duration).
- Outputs `green`, `yellow`, `red` must come from flip-flops (section 3.3) and exactly one must be high at all times after reset.
- The testbench measures how many ticks each color lasts, over at least 10 full cycles.
- Then add a `ped` (pedestrian) input: pressing it during green shortens the remaining green to at most 1 tick. Update the diagram first.

### Exercise 3: serial (UART) transmitter

A UART sends one byte as a frame of 10 bits on a single wire `tx`, which idles at 1: a **start bit** (0), the 8 data bits **least significant first**, and a **stop bit** (1). Each bit lasts one `baud_tick` period.

- Interface: `clk`, `rst`, `baud_tick` (an enable, one pulse per bit period), `in_valid`, `in_ready`, `data[7:0]`, and `tx`. Use the valid/ready rules of section 3.6.
- Datapath: a 10-bit shift register loaded with `{1'b1, data, 1'b0}` and a bit counter. Controller: `S_IDLE` and `S_SEND`.
- The testbench contains a **receiver model**: it waits for `tx` to fall, then samples `tx` once per bit period and rebuilds each byte. Send 50 random bytes, with random gaps, and check every one.
- Why must `tx` be driven from a flip-flop and never from combinational logic?

### Exercise 4: sequential divider (the full RTL method)

Build an unsigned W-bit divider with a start/busy/done interface: given `dividend` and `divisor`, produce `quotient` and `remainder`, using the **restoring division** algorithm, one quotient bit per clock cycle.

- The algorithm, for W steps: shift `{R, Q}` left by one (R is the partial remainder, initially 0; Q is initially the dividend); if R ≥ divisor, subtract the divisor from R and set Q\[0\] = 1. After W steps, Q is the quotient and R the remainder.
- Follow all six steps of section 3.5: write the algorithm, list the registers, draw the ASM chart, name the control and status signals, write the datapath and controller as separate modules, and verify.
- Add an output `div_by_zero` that is set (and the computation skipped) when the divisor is 0.
- Test with W = 8 against the testbench's `/` and `%` operators: all corner cases you can think of plus 1,000 random pairs. How many cycles does a division take?

### Exercise 5: find the four bugs

Specification: `led` is 1 **only in state `S_ON`**. A press of `go` in `S_OFF` moves to `S_ON`; `S_ON` always moves to `S_WAIT`; `S_WAIT` always moves back to `S_OFF`.

```systemverilog
`timescale 1ns/1ps
module blink_ctrl (
  input  logic clk, rst, go,
  output logic led
);
  typedef enum logic [1:0] {S_OFF, S_ON, S_WAIT} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_OFF;
    else     state <= next;
  end

  always_comb begin
    case (state)
      S_OFF:  if (go) begin next = S_ON; led = 1'b1; end
      S_ON:   begin next = S_WAIT; led = 1'b1; end
      S_WAIT: begin next <= S_OFF; led = 1'b0; end
    endcase
  end
endmodule
```

1. Run it through all three tools: Icarus with `-Wall`, Verilator with `--lint-only -Wall`, and Yosys with the `proc` command above. Record which tool reports which problem. You will find that they disagree: one bug is reported by one tool only.
2. One bug is reported by **no** tool, because the code is legal; it simply does not meet the specification. Find it with a testbench.
3. Rewrite the module in the style of section 3.2, so that every one of the four bugs becomes impossible rather than merely fixed.

## 3.8 Summary and what comes next

You can now design control logic as well as datapaths, and combine them with the RTL method. Keep this table beside you for the exercises.

| Concept | Syntax or rule | Remember |
| --- | --- | --- |
| State type | `typedef enum logic [N-1:0] {S_A, S_B} state_t;` | Width must hold every state |
| State register | `always_ff ... if (rst) state <= S_IDLE; else state <= next;` | The only flip-flops in the FSM |
| Next-state logic | `always_comb begin next = state; case (state) ... endcase end` | Defaults first; `if/else`, not `?:`, for enums |
| Recovery | `default: next = S_IDLE;` | May hide a missing reset in simulation |
| Moore output | Depends on state only | One cycle later; no input-to-output path |
| Mealy output | Depends on state and inputs | Same cycle; combinational path |
| Registered output | `always_ff ... out <= f(state, inputs);` | Moore timing, Mealy state count |
| Print a state | `state.name()` | Testbench only |
| RTL method | Datapath + controller | Control signals in, status signals out |
| Shift across registers | `{A, Q} <= {sum, Q[W-1:1]};` | Concatenation on both sides |
| start/busy/done | Pulse, level, pulse | Requests can be lost while busy |
| valid/ready | Transfer when both are 1 at an edge | Source never waits for `ready` |
| Third opinion | `yosys -p "read_verilog -sv f.sv; proc"` | Catches latches that Verilator can miss |

The ideas that matter most from this part:

1. Every FSM has three parts: state register, next-state logic and output logic. Write them as separate, recognizable blocks.
2. Separate **what decides** (controller) from **what computes** (datapath), and connect them with named control and status signals.
3. Register module outputs unless you have a reason not to.
4. Use handshakes that cannot lose data: valid/ready.
5. Use several tools. In this part, Icarus, Verilator and Yosys each caught a bug the others missed.

**Part 4: Verification and synthesis** turns these habits into a workflow. You will drive testbenches from test vectors generated by a Python reference model (the bridge to all the DSP parts), use Verilator's lint systematically, and synthesize your designs with Yosys to see the hardware they really produce: gate and flip-flop counts, multipliers, and the critical path. That closes the loop between "it simulates" and "it is good hardware" before the DSP theory begins in Part 5.
