# Verilog & RTL for DSP — Solutions to Part 10

*Markdown export of the online document: https://claude.ai/artifact/RvCGoFYvvV75zMsNJiS7rm. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the five exercises of Part 10. Try each one first; the "Check your understanding" answers are in Part 10 itself.

**How these solutions were checked.** Everything was run with Python 3, NumPy and SciPy, Icarus Verilog 12.0 (`-g2012 -Wall`), Verilator 5.020 (`--lint-only -Wall`) and Yosys 0.33. Every RTL design is bit-exact against a Python model, checked by the testbench and again independently in Python, and every number below is copied from an actual run. The designs reuse `decim_model.py`, `tb_decim.sv`, `fir_decim.sv`, `cic_decim.sv`, `mac.sv` and `requant.sv` from Part 10.

**A correction to Exercise 4.** The original exercise asked you to compare N = 4 with a longer FIR against N = 5 with a shorter one (Part 10's section 10.4 and Exercise 4 have since been corrected). With this passband, **N = 4 cannot reach 60 dB at all**, whatever the FIR's length. Part of the CIC's aliasing lands inside the wanted band already at the CIC output, where no later filter can separate it from the signal, and there the CIC alone gives only 50.3 dB. The solution shows why, and compares the costs anyway.

**Two tool notes from Exercise 5.** The lost-sample check uses `$error`, which Yosys cannot synthesize (`Can't resolve task name '$error'`). Wrapping simulation-only code in `` `ifndef SYNTHESIS `` hides it from Yosys, which defines that macro while reading. And the exercises with new testbenches (an interpolator, a fixed-rate source) were written as small variants of `tb_decim.sv`, so the checking logic stays the same.

## Exercise 1: see aliasing in a spectrum

### Predictions

After decimating by 4, every frequency is multiplied by 4 (in cycles per **output** sample) and folded into 0 to 0.5:

| Input tone | × 4 | Lands at | In the filter's… |
| --- | --- | --- | --- |
| 0.03 | 0.12 | **0.12** | passband: should survive |
| 0.11 | 0.44 | **0.44** | transition band: only partly removed |
| 0.21 | 0.84 | 1 − 0.84 = **0.16** | stopband: should be removed |

Without a filter, the 0.21 tone appears at 0.16, between the other two, indistinguishable from a real 0.04-cycles-per-sample input tone. The test signal is 0.3 × (sum of the three cosines), 8,192 samples, quantized to Q1.15.

### Results

> **Figure:** 8,192 input samples, 2,048 outputs, Blackman–Harris window; each point is the maximum of 4 FFT bins (shown in the [online version](https://claude.ai/artifact/RvCGoFYvvV75zMsNJiS7rm))

Levels at the three output frequencies, relative to one input tone (Blackman–Harris window):

|  | At 0.12 (from 0.03) | At 0.44 (from 0.11) | At 0.16 (from 0.21) |
| --- | --- | --- | --- |
| Plain `x[::4]` | −0.2 dB | 0.0 dB | **−0.3 dB** |
| `fir_decim` golden model | −0.2 dB | **−9.5 dB** | **−69.5 dB** |
| `fir_decim` RTL | −0.2 dB | −9.5 dB | −69.5 dB |
| Filter gain at the input frequency | −0.0 dB | −9.5 dB | −69.4 dB |

- **Plain decimation** keeps all three tones at full strength: the 0.21 tone has become a full-strength false tone at 0.16.
- **With the filter**, the 0.21 tone's alias is 69.5 dB down, exactly the filter's attenuation at 0.21.
- **The 0.11 tone is the instructive one.** It lies in the filter's transition band (the passband ends near 0.05 and the stopband starts at 0.15), so it is attenuated by only 9.5 dB, and its alias at 0.44 survives at −9.5 dB. A decimator with M = 4 needs the stopband to start below 1/(2M) = 0.125 to protect the whole new band; this filter, designed in Part 7 for a different purpose, starts its stopband at 0.15. An alias lands on output frequency f only from input frequencies of at least (1 − f)/4, so outputs from 0 to 0.4 cycles per output sample are still protected; aliases from the transition band land between 0.4 and 0.5. That is acceptable if the wanted signal occupies only the lower part of the output band, which is exactly the reasoning of section 10.4.

The RTL run (`fir_decim` with M = 4, random gaps in `in_valid`) produced `PASS: 2048 outputs bit-exact`, so its spectrum is necessarily identical to the model's.

## Exercise 2: an interpolator

### The polyphase idea

Interpolating by L = 4 means inserting three zeros after every sample (zero-stuffing) and low-pass filtering the result. Written out, output 4m + p is

```latex
y[4m + p] = \sum_{k} h[k]\, u[4m + p - k], \qquad u[n] = \begin{cases} x[n/4] & n \equiv 0 \pmod 4 \\ 0 & \text{otherwise} \end{cases}
```

and u is non-zero only when 4m + p − k is a multiple of 4, that is when k = p + 4j. So output phase p needs only the coefficients h\[p\], h\[p + 4\], h\[p + 8\], …: **8 of the 32**, applied to the 8 most recent input samples x\[m\], x\[m − 1\], …, x\[m − 7\]. The zeros are never touched.

### The RTL

```systemverilog
`timescale 1ns/1ps
// fir_interp.sv -- polyphase interpolator by L: for each input sample, L outputs.
// Output p (p = 0 .. L-1) uses only h[p], h[p+L], h[p+2L], ...: the inserted zeros are never
// multiplied. One MAC computes all L outputs: N/L products each, N products per input.
module fir_interp #(
  parameter int N = 32, L = 4,
  parameter int XW = 16, XF = 15, CW = 18, CF = 17, YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "interp_coefs.svh"
  localparam int NP = N / L;                         // taps per phase (8)
  localparam int JW = (NP > 1) ? $clog2(NP) : 1;
  localparam int PW = (L > 1) ? $clog2(L) : 1;

  typedef enum logic {S_IDLE, S_RUN} state_t;
  state_t               state;
  logic [PW-1:0]        p;                           // output phase
  logic [JW-1:0]        j;                           // tap within the phase
  logic signed [XW-1:0] taps [0:NP-1];               // only N/L input samples are needed

  assign in_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;  p <= '0;  j <= '0;
      for (int i = 0; i < NP; i++) taps[i] <= '0;
    end else begin
      case (state)
        S_IDLE: if (in_valid) begin
          taps[0] <= x;
          for (int i = 1; i < NP; i++) taps[i] <= taps[i-1];
          p <= '0;  j <= '0;  state <= S_RUN;
        end
        S_RUN: begin
          j <= j + 1'b1;
          if (j == JW'(NP - 1)) begin
            p <= p + 1'b1;
            if (p == PW'(L - 1)) state <= S_IDLE;
          end
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  logic mac_ovf_unused;
  mac #(.A_W(XW), .A_F(XF), .B_W(CW), .B_F(CF), .ACC_W(XW + CW + JW + 1),
        .OUT_W(YW), .OUT_F(YF)) u_mac (
    .clk(clk), .rst(rst),
    .in_valid(state == S_RUN), .first(j == '0), .last(j == JW'(NP - 1)),
    .a(taps[j]), .b(interp_coef(32'(p) + L * 32'(j))),
    .out_valid(out_valid), .dout(y), .dout_ovf(mac_ovf_unused)
  );
endmodule
```

The MAC's `first` and `last` flags mark each group of 8 products, so it delivers one rounded output per phase, in the order p = 0, 1, 2, 3. The delay line holds only N/L = 8 samples, a quarter of the decimator's.

### The golden model, and why h is scaled by L

```python
L = 4; h = firwin(32, 0.2)
hq = quantize(L * h, 18, 17)                 # max |L h| = 0.784: still fits Q1.17

def interp_golden(x):
    u = np.zeros(len(x) * L, dtype=np.int64); u[::L] = x             # zero-stuff
    acc = np.convolve(u, hq.astype(np.int64))[: len(u)]               # filter with L*h
    return requant(acc, 15 + 17, 16, 15, "round", "saturate")          # round once
```

**The scaling by L:** zero-stuffing keeps only one sample in L, so the stuffed signal has 1/L of the original's average value, and the spectrum of each copy is divided by L. The filter must multiply by L to restore the amplitude. Measured with a constant input of 0.5: with L·h the output is 0.4996 to 0.5004; with h alone it is **0.125**, exactly 0.5/4. (The small variation between 0.4996 and 0.5004 is real: each of the four phases' coefficient sums differs slightly from 1, a tiny ripple at the input rate.) Scaling the floating-point h by L **before** quantizing, as above, keeps all 17 fractional bits; quantizing first and then multiplying by 4 would waste two of them.

The testbench is `tb_decim.sv` with the expected output count changed from n/M to n × L. Three seeds of 2,000 inputs: `PASS: 8000 outputs bit-exact`, confirmed independently; lint-clean.

### MACs per output

|  | MACs per output | MACs per input |
| --- | --- | --- |
| Polyphase (`fir_interp`) | **8** (N/L) | 32 |
| Filtering the zero-stuffed signal directly | 32 (N) | 128 |

The polyphase form does **4 times fewer** multiplications, exactly the L multiplications by zero that the direct form wastes on every output. It took 33 clock cycles per input (32 MAC cycles plus 1 to accept the sample), about 8.25 per output. This is the interpolation counterpart of the decimator's trick in section 10.2: there, only the kept outputs are computed; here, only the non-zero inputs are multiplied.

## Exercise 3: a CIC with any R

### The register width

The CIC's gain is Rᴺ, so the registers need ⌈log₂ Rᴺ⌉ extra bits. In SystemVerilog that is simply `$clog2(R**NS)`, which equals ⌈N log₂ R⌉ for any R. In Python, `(R**N - 1).bit_length()` is the same:

| R (N = 3) | Rᴺ | Extra bits | Register width W |
| --- | --- | --- | --- |
| 8 | 512 | 9 | 25 |
| 10 | 1,000 | **10** | **26** |
| 12 | 1,728 | **11** | **27** |
| 16 | 4,096 | 12 | 28 |

The integrators and combs are unchanged: they still wrap, and the decimation counter (`cnt == R - 1`) already works for any R.

### The gain correction

For a power-of-two R, dividing by Rᴺ is a shift. For R = 10, dividing by 1,000 is replaced by multiplying with a constant K ≈ 2^S/1,000 and dropping S bits with rounding:

```systemverilog
  // gain correction: c * GK, then drop GS bits with rounding (and saturate to Q1.15)
  localparam logic signed [GKW-1:0] K = GKW'(GK);
  logic signed [W+GKW-1:0] prod;
  assign prod = c[NS] * K;

  logic signed [XW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(W + GKW), .IN_F(XF + GS), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1))
    u_rq (.din(prod), .dout(y_c), .ovf(unused_ovf));
```

The module, `cic_decim_any.sv`, takes `GK` and `GS` as parameters, computed in Python:

```python
def gain_constant(R, N, kbits=17):
    """Largest shift S with K = round(2**S / R**N) < 2**kbits (fits a (kbits+1)-bit signed word)."""
    G = R ** N
    S = int(np.floor(np.log2((2 ** kbits - 1) * G)))
    K = round(2 ** S / G)
    while K >= 2 ** kbits:
        S -= 1; K = round(2 ** S / G)
    return K, S
```

The model `cic_any_golden` is Part 10's CIC model with the general width and, at the end, `requant(c * K, 15 + S, 16, 15, "round", "saturate")`. As a check of the generalization, with R = 8 the constant is exact (K = 65,536 = 2²⁵/512), and the new model reproduces the original model bit for bit.

### How wide must the constant be?

The approximation's relative error is ε = K·Rᴺ/2^S − 1. The largest CIC output corresponds to a full-scale input, 32,768 LSB, so the worst error added before rounding is **32,768 · |ε| LSB**:

| Constant (magnitude bits) | R = 10: K, S | Added error | R = 12: K, S | Added error |
| --- | --- | --- | --- | --- |
| 10 | 524, 19 | 18.0 LSB | 607, 20 | 10.0 LSB |
| 12 | 2,097, 21 | 2.38 LSB | 2,427, 22 | 3.50 LSB |
| 14 | 8,389, 23 | 1.53 LSB | 9,709, 24 | **0.125 LSB** |
| 16 | 33,554, 25 | **0.422 LSB** | 38,836, 26 | 0.125 LSB |
| **17** | **67,109, 26** | **0.066 LSB** | **77,672, 27** | **0.125 LSB** |

The error is set by how well K happens to approximate 2^S/Rᴺ, so it does not fall smoothly with the width. To stay below half an LSB, R = 10 needs **16** magnitude bits and R = 12 only 14. I chose **17 magnitude bits, an 18-bit signed constant**, which fits a DSP48E1's B port and gives 0.066 LSB for R = 10 and 0.125 LSB for R = 12.

### Verification

Two seeds each for R = 10 and R = 12, 6,000 inputs:

| R | W | K, S | Result | Max \|y − c/Rᴺ\| | Differs from ideal rounding |
| --- | --- | --- | --- | --- | --- |
| 10 | 26 | 67,109, 26 | `PASS: 600 outputs bit-exact` (both seeds) | 0.509 LSB | 5 and 1 of 600 |
| 12 | 27 | 77,672, 27 | `PASS: 500 outputs bit-exact` (both seeds) | 0.506 LSB | 2 and 3 of 500 |

Both are lint-clean. The total error is at most 0.509 LSB: the 0.5 LSB of the final rounding plus a small part of the constant's error. In practice the approximation changes the result only when the exact value lies within a few hundredths of an LSB of a rounding tie: 1 to 5 outputs in 500 to 600 differ by one LSB from the ideal round(c/Rᴺ).

## Exercise 4: design the compensation FIR

The chain of section 10.4: 100 MHz in, CIC with R = 16 to 6.25 MHz, then a decimate-by-2 FIR to 3.125 MHz; passband ±1.25 MHz; the first frequency that folds into it at the output is 1.875 MHz.

### Which aliases can the FIR remove?

An input frequency lands inside ±1.25 MHz at the 3.125 MHz output if it lies within 1.25 MHz of a multiple of 3.125 MHz. Those images fall into two groups:

- **Odd multiples** (3.125, 9.375, … MHz): after the CIC, at the 6.25 MHz rate, they land between 1.875 and 3.125 MHz, **in the FIR's stopband**. Both the CIC and the FIR attenuate them.
- **Even multiples** (6.25, 12.5, … MHz): these fold into ±1.25 MHz **already at the CIC's output**, on top of the wanted signal. No later filter can separate them, so **only the CIC** attenuates them.

The CIC's worst attenuation on the even images is at 6.25 − 1.25 = 5 MHz, and computing it over all of them:

| CIC (R = 16) | Worst attenuation of the even images |
| --- | --- |
| N = 4 | **50.3 dB** |
| N = 5 | **62.9 dB** |

So with N = 4, **no FIR can reach 60 dB**; the 50.3 dB found in section 10.4 is a hard limit for this passband. Searching anyway, with ripple below 0.2 dB, the best combined rejection with N = 4 was 48.2 dB at 34 taps, 48.2 dB at 60 taps and 48.1 dB at 120 taps (2 dB worse than 50.3 because the compensation boosts the band edge by about that much). The exercise's first option is not a cheaper solution; it is no solution. The only ways to reach 60 dB with N = 4 are a narrower passband or a smaller R.

### The design, with N = 5

`firwin2` takes a list of frequencies and gains and interpolates **linearly** between them. A first attempt asked for 1/CIC up to 1.25 MHz and 0 from 1.875 MHz, with a linear ramp between. It failed badly: with 63 taps the FIR was only **−23 dB** at 1.875 MHz, because the desired response itself is still far from zero just below it.

The window method works best with a **step**, placed in the middle of the transition band. `firwin2` makes a step when a frequency is repeated:

```python
def design(nt, N, beta, fc):
    fp = np.linspace(0, fc, 80)
    freq = np.r_[fp, fc, FS1 / 2] / (FS1 / 2)          # fc twice: a step from 1/CIC to 0
    gain = np.r_[1 / cic(fp, N), 0, 0]
    return signal.firwin2(nt, freq, gain, window=("kaiser", beta))
```

The combined response was checked on every image band up to 50 MHz, as described above, plus the passband ripple of CIC × FIR. Searching the number of taps, the Kaiser β and the step frequency fc, the **shortest design meeting both requirements** is:

| Taps | Window | Step at | Combined ripple | Combined alias rejection |
| --- | --- | --- | --- | --- |
| **34** | Kaiser, β = 5.5 | 1.525 MHz | **0.123 dB** | **60.2 dB** |

That is close to section 10.4's estimate of about 38 taps. The coefficients are symmetric (linear phase). The FIR's gain rises to +2.83 dB at 1.25 MHz, mirroring the CIC's −2.88 dB droop there (N = 5 droops more than N = 4's −2.31 dB).

> **Figure:** The FIR repeats every 6.25 MHz; inputs from 5 to 6.25 MHz fold into the passband at the CIC output, and only the CIC attenuates them (shown in the [online version](https://claude.ai/artifact/RvCGoFYvvV75zMsNJiS7rm))

### Cost

|  | CIC N = 4 + FIR | CIC N = 5 + FIR (34 taps) |
| --- | --- | --- |
| Meets 60 dB? | **No** (at most 50.3 dB) | Yes (60.2 dB) |
| CIC adders | 8 | 10 |
| CIC register bits | 8 × 32 = 256 | 10 × 36 = 360 |
| FIR multiplications per second | — | 34 × 3.125 MHz = 106 million (53 million with symmetric pre-adders) |

The extra CIC stage costs two adders and 104 register bits at the 100 MHz rate, which is very little next to what it buys: 12.6 dB more rejection on the bands no FIR can reach.

## Exercise 5: a two-stage RTL chain

### The RTL

```systemverilog
`timescale 1ns/1ps
// decim16.sv -- two-stage decimator: CIC (R = 8) then decimating FIR (M = 2): one output per 16 inputs.
// The CIC's output valid drives the FIR's input valid. The CIC cannot wait, so every CIC output
// must find the FIR ready; the assertion below reports a lost sample.
module decim16 #(
  parameter int XW = 16
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  logic                 c_valid, c_ready_unused, f_ready;
  logic signed [XW-1:0] c_y;

  cic_decim #(.R(8), .NS(3)) u_cic (
    .clk(clk), .rst(rst), .in_valid(in_valid), .in_ready(c_ready_unused), .x(x),
    .out_valid(c_valid), .y(c_y));
  fir_decim #(.M(2)) u_fir (
    .clk(clk), .rst(rst), .in_valid(c_valid), .in_ready(f_ready), .x(c_y),
    .out_valid(out_valid), .y(y));

  assign in_ready = 1'b1;                       // the CIC accepts a sample every cycle

  // a CIC output arriving while the FIR is computing would be dropped
  // (simulation only: Yosys defines SYNTHESIS and cannot synthesize $error)
`ifndef SYNTHESIS
  always @(posedge clk) begin
    if (!rst && c_valid && !f_ready)
      $error("decim16: CIC output lost: the FIR was busy (inputs arrive too fast)");
  end
`endif
endmodule
```

### The golden model

Simply the two existing models, chained:

```python
y = fir_decim_golden(cic_decim_golden(x, 8), 2)        # 8,000 inputs -> 1,000 -> 500 outputs
```

This works because the CIC's model already produces exactly the integers the RTL's CIC hands to the FIR, and the FIR's model takes those as its input samples.

### Can a CIC output arrive while the FIR is busy?

Count the cycles, with one input sample every g clocks:

- **The CIC** produces one output per 8 inputs: every **8g** clocks. It has no way to wait (`cic_decim` has no output handshake), so the FIR must take each output in the cycle it appears.
- **The FIR** collects 2 samples, then computes for **32 clocks** (k = 0 to 31) with `in_ready` low, then returns to collecting.

After the FIR accepts its second sample, the next CIC output arrives 8g clocks later. It is safe only if the FIR has finished, that is if **8g > 32**: **g ≥ 5** clocks per input sample. At g = 4 the next output arrives exactly as the FIR spends its last busy cycle, and is lost.

The experiment, with a testbench that sends inputs at a fixed spacing of g clocks (a variant of `tb_decim.sv`), 8,000 inputs:

| Input spacing g | Lost-sample assertions | Result |
| --- | --- | --- |
| 1 clock | 666 | `FAILED: 167 outputs (expected 500), 165 wrong` |
| 2 | 500 | `FAILED: 250 outputs (expected 500), 249 wrong` |
| 3 | 333 | `FAILED: 333 outputs (expected 500), 332 wrong` |
| 4 | 333 | `FAILED: 333 outputs (expected 500), 332 wrong` |
| **5** | **0** | **`PASS: 500 outputs bit-exact`** |
| 6 | 0 | `PASS: 500 outputs bit-exact` |

The boundary is exactly where the count predicts, and the assertion fires on every lost sample, so a too-fast input can never pass silently. (The Part 12 capstone met the same constraint with a 31-tap FIR, where the busy time is 31 clocks, so g = 4 was just enough there.) To accept faster inputs, give the FIR a one-sample input buffer, so it can take the next CIC output while computing; or use two MACs (Part 7, Exercise 5); or accept the next sample in the last MAC cycle, as in Part 7, Exercise 4.

### Cost

Yosys (`synth_xilinx`), after hiding the assertion from synthesis: **1 DSP48E1**, 501 LUTs, 727 flip-flops, 61 `CARRY4` and 1 `SRL16E`. The design is lint-clean.

Scaling section 10.4's single-filter comparison to this example: the FIR here is Part 7's 32-tap filter at the CIC output rate, whose passband (−0.1 dB) ends at 0.052 and whose 44 dB stopband starts at 0.15 cycles per sample of that rate. A single decimating FIR at the input rate with the same edges has a transition band 8 times narrower in normalized terms, 0.0122 cycles per sample, and `kaiserord(44, ...)` estimates **208 taps**.

|  | Single FIR, decimating by 16 | CIC + FIR (`decim16`) |
| --- | --- | --- |
| Multiplications per output | 208 | 32 |
| Multiplications per input | 13 | **2** |
| Delay line | 208 samples at the input rate | 32 samples at 1/8 of the rate, plus 6 CIC registers |
| Additions for the anti-alias filtering | in the MACs | 6 CIC adders, no multipliers |

The chain needs **6.5 times fewer** multiplications. The comparison is approximate in one respect: the chain's response is the CIC's response times the FIR's, including the CIC's droop, which this FIR does not compensate (Exercise 4 shows how to). For a real design, the FIR would be a compensation filter, at about the same cost.

---

That completes Part 10. Send me your own designs and results if you would like them reviewed.
