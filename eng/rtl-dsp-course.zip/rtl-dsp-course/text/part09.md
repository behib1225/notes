# Verilog & RTL for DSP — Part 9: NCO, CORDIC and Mixers

*Markdown export of the online document: https://claude.ai/artifact/7S1igzHyDp8uhEBH4a1TKD. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 9 fits

Parts 7 and 8 removed unwanted frequencies. Part 9 **generates** signals and **moves** them from one frequency to another. These are the building blocks of every digital radio, software-defined receiver, modem and signal generator, and the front end of the digital down-converter you will build in Part 12.

Three blocks, each built in RTL and verified bit-exactly against a Python model:

1. The **numerically controlled oscillator** (NCO): a phase accumulator and a sine lookup table that produce a sine and a cosine at any frequency, set by one number, with sub-hertz resolution (9.2).
2. **CORDIC**: an algorithm that rotates a vector using only shifts and additions, and so computes sines, cosines, magnitudes and angles without a single multiplier (9.3).
3. The **digital mixer**: an NCO and two multipliers that shift a signal's spectrum, turning a real input into the complex (I/Q) form used everywhere in communications (9.4).

Section 9.1 first introduces the one new idea these all rely on: complex signals and negative frequencies.

This part also introduces a new measurement tool. To see what an oscillator really produces, you will look at its **spectrum**, computed with NumPy's FFT: a plot of how much power the signal has at each frequency. Part 11 explains how the FFT works and builds one in hardware; here it is simply a measuring instrument, like an oscilloscope set to frequency instead of time.

As always, every number in this part comes from code that was run: Python 3 with NumPy, Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33. The Part 6 files `fixedpoint.py` and `requant.sv` are reused.

## 9.1 Complex signals and frequency shifting

A **complex signal** is a pair of real signals processed together: the **in-phase** part I and the **quadrature** part Q, written x\[n\] = I\[n\] + j·Q\[n\]. Complex signals can tell positive frequencies from negative ones, and multiplying by a complex sinusoid shifts every frequency by the same amount. Those two facts are the foundation of digital radio.

### Positive and negative frequencies

Euler's formula from Part 5 says e^{jωn} = cos(ωn) + j·sin(ωn): a point turning around the unit circle by ω radians per sample. Turning counter-clockwise is a **positive** frequency, +ω; clockwise, e^{−jωn}, is a **negative** frequency, −ω.

A real cosine is the sum of both:

```latex
\cos(\omega n) = \tfrac{1}{2} e^{j\omega n} + \tfrac{1}{2} e^{-j\omega n}
```

So a real signal always has a mirror-image spectrum: whatever it contains at +f, it also contains at −f. That is why the spectra in Parts 5 to 8 only showed 0 to f\_s/2: the negative half carried no new information. A complex signal can have **different** content at +f and −f, so its useful spectrum runs from −f\_s/2 to +f\_s/2: twice the bandwidth for the same sample rate.

### Mixing: multiplication shifts frequency

Multiplying two complex sinusoids adds their frequencies, because exponents add:

```latex
e^{j\omega_1 n} \cdot e^{j\omega_2 n} = e^{j(\omega_1 + \omega_2) n}
```

Multiplying a whole signal by e^{−jω₀n} therefore shifts **every** frequency component down by ω₀. That operation is a **mixer**, and the complex sinusoid it uses is the **local oscillator** (LO). A radio receiver uses it to bring the station it wants, say at 0.2 cycles per sample, down to 0 Hz, where a simple low-pass filter (Parts 7 and 8) can separate it from its neighbors.

In hardware, multiplying a **real** input x\[n\] by e^{−jω₀n} = cos(ω₀n) − j·sin(ω₀n) needs two real multipliers:

```latex
I[n] = x[n] \cos(\omega_0 n), \qquad Q[n] = -x[n] \sin(\omega_0 n)
```

A real tone at +f becomes a component at f − f₀, and its mirror at −f becomes one at −f − f₀. With f = f₀, one copy lands exactly at 0 Hz and the other at −2f₀, where the following low-pass filter removes it. Section 9.4 builds exactly this, and Part 12 adds the filter.

### Why I and Q are both needed

Multiplying by the cosine alone (a real mixer) also shifts the spectrum, but it cannot keep a component at f₀ + Δ apart from one at f₀ − Δ: both land at ±Δ and mix together. Keeping both I and Q preserves the sign of the frequency, so the two stay separate. Every modern digital receiver keeps both.

### Check your understanding: 9.1

1. Is e^{−j2π(0.1)n} a positive or a negative frequency? Write its I and Q parts.
2. A complex signal sampled at 10 MHz: what range of frequencies can it represent without aliasing?
3. A real input contains a tone at 0.2 cycles per sample. After mixing with e^{−j2π(0.15)n}, at which frequencies does the output have components?
4. Why does a real signal not need a separate spectrum for negative frequencies?
5. How many real multipliers does a mixer need for a real input? For a complex input?

#### Answers

1. **Negative** (−0.1 cycles per sample, turning clockwise). I = cos(2π·0.1n), Q = −sin(2π·0.1n).
2. **−5 MHz to +5 MHz**: 10 MHz of bandwidth, twice the 0 to 5 MHz of a real signal at the same rate.
3. The real tone has components at +0.2 and −0.2. Shifting both down by 0.15 gives **+0.05** and **−0.35** cycles per sample.
4. Its negative-frequency content is always the mirror image (the complex conjugate) of its positive-frequency content, so it carries no extra information.
5. Real input: **2** (x·cos and x·sin). Complex input: a full complex multiplication, (I + jQ)(cos − j·sin), which needs **4** real multiplications (or 3 with Gauss's trick from Part 6).

## 9.2 The numerically controlled oscillator

An NCO produces cos(ω₀n) and sin(ω₀n) for any frequency you choose, using one adder and a lookup table. Its frequency is set by a single number, the **frequency control word** (FCW), and with a 32-bit accumulator it can be tuned in steps of f\_s/2³², about 0.023 Hz at a 100 MHz sample rate.

### The phase accumulator

Picture the phase of a sinusoid as a pointer on a wheel. Every sample, the pointer advances by a fixed angle; the sine of the pointer's angle is the output. In hardware, the wheel is an N-bit register, the **phase accumulator**, whose full range, 0 to 2^N − 1, represents one full turn. Each sample it adds the FCW, and when it passes 2^N it wraps around automatically, which is exactly what a turn of the wheel should do. Binary overflow, normally a bug, is here the whole point.

```latex
f_{out} = \frac{\mathrm{FCW}}{2^N} f_s, \qquad \mathrm{FCW} = \mathrm{round}\left(\frac{f_{out}}{f_s} 2^N\right)
```

With N = 32:

- **Resolution**: one FCW step is f\_s/2³². At f\_s = 100 MHz, that is **0.0233 Hz**.
- **Example**: 0.1 cycles per sample needs FCW = round(0.1 × 2³²) = 429,496,730 = `0x1999999A`.
- **Range**: FCW values from 0 to 2³¹ give 0 to f\_s/2; larger values act as negative frequencies, because the accumulator is modular.

### The lookup table

The top A bits of the phase address a table holding one period of the cosine (and a second table for the sine). Dropping the lower N − A bits is called **phase truncation**. With A = 10, the tables have 1,024 entries of 16 bits each, generated by Python:

```python
def make_lut(addr_bits=LUT_A, w=OUT_W):
    """Full-wave cosine and sine tables, amplitude 2**(w-1) - 1, rounded."""
    k = np.arange(1 << addr_bits)
    amp = (1 << (w - 1)) - 1
    c = np.round(amp * np.cos(2 * np.pi * k / (1 << addr_bits))).astype(np.int64)
    s = np.round(amp * np.sin(2 * np.pi * k / (1 << addr_bits))).astype(np.int64)
    return c, s
```

The amplitude is 32,767, not 32,768, so that +1.0 never has to be represented (Part 6). The tables are written to `cos_lut.hex` and `sin_lut.hex`, which the RTL loads with `$readmemh`.

### The RTL

```systemverilog
`timescale 1ns/1ps
// nco.sv -- numerically controlled oscillator: phase accumulator + cosine/sine lookup tables.
// Output frequency = fcw / 2**ACC_W cycles per enabled sample.
module nco #(
  parameter int ACC_W = 32,                 // phase accumulator width
  parameter int A     = 10,                 // LUT address bits (phase bits used)
  parameter int W     = 16                  // output width, Q1.15
) (
  input  logic                clk, rst,
  input  logic                en,           // advance one sample
  input  logic [ACC_W-1:0]    fcw,          // frequency control word
  output logic                out_valid,
  output logic signed [W-1:0] cos_o, sin_o
);
  logic [ACC_W-1:0]    phase;               // wraps around naturally: modulo 2**ACC_W
  logic signed [W-1:0] cos_rom [0:(1<<A)-1];
  logic signed [W-1:0] sin_rom [0:(1<<A)-1];

  initial begin                              // ROM contents, generated by dds_model.py
    $readmemh("cos_lut.hex", cos_rom);
    $readmemh("sin_lut.hex", sin_rom);
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      phase     <= '0;
      out_valid <= 1'b0;
    end else begin
      out_valid <= en;
      if (en) begin
        cos_o <= cos_rom[phase[ACC_W-1 -: A]];   // the top A bits of the phase
        sin_o <= sin_rom[phase[ACC_W-1 -: A]];
        phase <= phase + fcw;
      end
    end
  end
endmodule
```

Two new constructs:

- **`phase[ACC_W-1 -: A]`** is an **indexed part-select**: "A bits, counting down from bit ACC\_W − 1". It is the same as `phase[31:22]` here, but stays correct when the parameters change. (`+:` counts up.)
- **`$readmemh` in an `initial` block of design code** initializes a ROM. Synthesis tools accept this for memories: Yosys put both tables into **two RAMB18E1 block RAMs**, and the whole NCO used only 33 flip-flops (the phase and the valid bit) and 8 `CARRY4` for the 32-bit adder.

The Python model (in `dds_model.py`) computes the same thing in one line: the phase of sample k is k·FCW mod 2³², and its top 10 bits index the tables. The testbench enables the NCO with random gaps and writes every output; the RTL matched the model bit for bit at five FCW values, including the extremes `0x00000001` (the slowest possible frequency) and `0x7FFFFFFF` (just below f\_s/2).

### Phase truncation creates spurs

Dropping the low phase bits makes the table address step slightly unevenly, a small periodic error that shows up in the spectrum as **spurs**: unwanted tones beside the wanted carrier. The chart shows the spectrum of the RTL's cosine output at FCW = `0x0B3A5C1F` (0.0439 cycles per sample), 16,384 samples with a Blackman–Harris window:

> **Figure:** nco.sv output (Icarus 12.0), np.fft.rfft with Blackman-Harris window, peak of each 32-bin group (shown in the [online version](https://claude.ai/artifact/7S1igzHyDp8uhEBH4a1TKD))

The carrier stands at 0 dB, and the largest spur, at 0.132 cycles per sample, is **60.4 dB** below it. That figure is the **spurious-free dynamic range** (SFDR). The famous rule of thumb predicts about 6.02 dB per table address bit, and the model confirms it across table sizes:

| Table address bits A | Table entries | Measured SFDR | 6.02 × A |
| --- | --- | --- | --- |
| 8 | 256 | 48.1 dB | 48.2 dB |
| 10 (this design) | 1,024 | 60.4 dB | 60.2 dB |
| 12 | 4,096 | 71.7 dB | 72.2 dB |
| 14 | 16,384 | 84.1 dB | 84.3 dB |

Each extra address bit doubles the table and buys 6 dB. Practical designs use cheaper tricks: storing only a quarter of a sine wave and using symmetry for the rest (a 4× memory saving, Exercise 2), adding a small random **dither** to the phase to turn spurs into a flat noise floor, interpolating between table entries, or replacing the table with a CORDIC (section 9.3).

### Check your understanding: 9.2

1. What FCW gives 12.5 MHz at f\_s = 100 MHz with a 32-bit accumulator? What is the exact output frequency?
2. The FCW is `0xC0000000`. What frequency does the NCO produce?
3. Why does the phase accumulator need no special logic to wrap around?
4. How many table address bits are needed for at least 80 dB SFDR?
5. Why can the accumulator be 32 bits while the table uses only 10 of them?

#### Answers

1. 12.5/100 = 0.125 = 2⁻³, so FCW = 2²⁹ = **`0x20000000`**, and the frequency is exactly **12.5 MHz** (no rounding needed).
2. 0xC0000000 / 2³² = 0.75 cycles per sample, which is equivalent to 0.75 − 1 = **−0.25 cycles per sample** (−f\_s/4): the cosine is the same as at +f\_s/4, but the sine is inverted.
3. An N-bit adder naturally discards the carry out of the top bit, so the sum is computed modulo 2^N, which is exactly the wrap of a full turn of phase.
4. 6.02 A ≥ 80 → A ≥ 13.3, so **14 bits** (84 dB), a 16,384-entry table, or fewer bits with quarter-wave storage, dither or interpolation.
5. The accumulator's width sets the **frequency resolution**, because the low bits accumulate small phase increments exactly over time. The table's size sets the **output accuracy** (spurs). The two are independent design choices; the low bits still affect which table entry is chosen as they carry into the upper bits.

## 9.3 CORDIC: rotation with shifts and adds

CORDIC (COordinate Rotation DIgital Computer, from 1959) rotates a vector (x, y) by an angle z using only shifts, additions and a small table of constants: no multipliers. One iteration gives roughly one more bit of accuracy. It computes sines and cosines, vector magnitudes and angles, and in its rotation mode it is itself a complete mixer.

### The idea

Rotating (x, y) by an angle θ is x' = x cos θ − y sin θ, y' = x sin θ + y cos θ. Factor out cos θ:

```latex
x' = \cos\theta \, (x - y \tan\theta), \qquad y' = \cos\theta \, (y + x \tan\theta)
```

CORDIC builds any angle from a fixed sequence of small angles θᵢ = arctan(2⁻ⁱ): 45°, 26.6°, 14.0°, 7.1°, …, each either added or subtracted. For these angles tan θᵢ = 2⁻ⁱ, so multiplying by tan θᵢ is just a **right shift by i bits**. Each iteration i is:

```latex
d_i = \mathrm{sign}(z_i), \quad x_{i+1} = x_i - d_i \, y_i 2^{-i}, \quad y_{i+1} = y_i + d_i \, x_i 2^{-i}, \quad z_{i+1} = z_i - d_i \arctan(2^{-i})
```

The register z holds the angle still to be rotated; each step rotates toward it and subtracts what was done, so z converges to 0.

The cos θᵢ factors were dropped, so every iteration stretches the vector slightly. After many iterations the total stretch is a constant, the **CORDIC gain**:

```latex
K = \prod_i \sqrt{1 + 2^{-2i}} \approx 1.6468
```

(1.64676 for 16 iterations.) Because K does not depend on the angle, it is compensated once, for example by starting with x₀ = 1/K ≈ 0.60725 to produce an exact cos and sin.

The sequence of angles adds up to about 99.9°, so CORDIC on its own only reaches angles within ±99.9°. A first **quadrant step** rotates by exactly ±90° when needed (swap x and y and negate one, which is free), so any angle works.

### Angles in binary units

Angles are stored as **binary angle units**, like the NCO's phase: a full turn is 2^ZW. With ZW = 20, a quarter turn is 2¹⁸ = 262,144, and the angle register wraps around naturally. The table of arctan(2⁻ⁱ) values is generated by Python into `cordic_atan.svh`; its first entries are 131,072 (45°), 77,376, 40,884, 20,753, …

### The pipelined RTL

```systemverilog
`timescale 1ns/1ps
// cordic.sv -- pipelined CORDIC in rotation mode: rotates (x, y) by angle z.
// Only shifts and adds. Output is scaled by the CORDIC gain K = 1.6468 (for 16 stages).
// Angle z: binary angle units, full turn = 2**ZW. Latency: N_IT + 1 cycles.
module cordic #(
  parameter int XW = 16,                 // input x, y width (Q1.15)
  parameter int CW = 18,                 // internal and output width: 2 guard bits for the gain
  parameter int ZW = 20,                 // angle width
  parameter int N_IT = 16                // iterations = pipeline stages
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  input  logic signed [XW-1:0] x_in, y_in,
  input  logic signed [ZW-1:0] z_in,     // -1/2 .. +1/2 turn
  output logic                 out_valid,
  output logic signed [CW-1:0] x_out, y_out
);
  `include "cordic_atan.svh"
  localparam logic signed [ZW-1:0] QUARTER = ZW'(1) <<< (ZW - 2);   // 90 degrees

  logic signed [CW-1:0] x [0:N_IT];
  logic signed [CW-1:0] y [0:N_IT];
  logic signed [ZW-1:0] z [0:N_IT];
  logic                 v [0:N_IT];

  // stage 0: rotate by +-90 degrees if needed, so the remaining angle is within +-90
  always_ff @(posedge clk) begin
    if (rst) v[0] <= 1'b0;
    else     v[0] <= in_valid;
    if (z_in > QUARTER) begin
      x[0] <= -(CW'(y_in)); y[0] <= CW'(x_in);   z[0] <= z_in - QUARTER;
    end else if (z_in < -QUARTER) begin
      x[0] <= CW'(y_in);    y[0] <= -(CW'(x_in));  z[0] <= z_in + QUARTER;
    end else begin
      x[0] <= CW'(x_in);   y[0] <= CW'(y_in);   z[0] <= z_in;
    end
  end

  // stages 1..N_IT: one micro-rotation each, by +-atan(2^-i)
  for (genvar i = 0; i < N_IT; i++) begin : g_stage
    always_ff @(posedge clk) begin
      if (rst) v[i+1] <= 1'b0;
      else     v[i+1] <= v[i];
      if (z[i] >= 0) begin                      // rotate counter-clockwise
        x[i+1] <= x[i] - (y[i] >>> i);
        y[i+1] <= y[i] + (x[i] >>> i);
        z[i+1] <= z[i] - cordic_atan(i);
      end else begin                            // rotate clockwise
        x[i+1] <= x[i] + (y[i] >>> i);
        y[i+1] <= y[i] - (x[i] >>> i);
        z[i+1] <= z[i] + cordic_atan(i);
      end
    end
  end

  assign x_out = x[N_IT];
  assign y_out = y[N_IT];
  assign out_valid = v[N_IT];
endmodule
```

Each iteration is one pipeline stage, so the CORDIC accepts a new vector every clock with a latency of 17 cycles. The shift amount `i` is a constant in each stage (a `genvar`), so `>>> i` is pure wiring: each stage is three adders and nothing else. The internal width has 2 extra integer bits, because the gain of 1.65 times a full-scale vector of length up to √2 reaches about 2.33.

### Verification, and a precedence trap

The Python model `cordic_rotate()` performs the same integer operations. Python's `>>` on negative integers rounds toward −∞, exactly like SystemVerilog's `>>>` on signed values, so the bits match. The testbench reads 3,000 "x y z" lines (random, plus corner cases: full-scale inputs, angles of exactly ±90° and ±180°, zero) with random gaps: **bit-exact on all 3,000**.

Yosys then refused the first version: `ERROR: Static cast with zero or negative size!` for the line `x[0] <= -CW'(y_in);`. It parsed the expression as a cast to the width `−CW`, where Icarus and Verilator read it as the negation of a cast. The fix is parentheses: `-(CW'(y_in))`. Write casts with explicit parentheses whenever an operator precedes them.

### Accuracy versus the number of stages

Rotating x₀ = round(32,767/K) by 5,000 random angles and comparing with 32,767·cos and 32,767·sin computed in floating point:

| Iterations | 6 | 8 | 10 | 12 | 14 | 16 |
| --- | --- | --- | --- | --- | --- | --- |
| Maximum error (LSB of Q1.15) | 1,016 | 255 | 66 | 19 | 8.3 | 7.3 |

The error falls by about a factor of 4 for every 2 iterations, one bit per iteration, until about 14 iterations. Then it stops improving at around 7 LSB: the right shifts throw away bits at every stage, and this design has **no extra fractional guard bits** to absorb those truncations. Adding about log₂(16) = 4 fractional bits to the internal width brings the error down to 1 to 2 LSB (Exercise 3). The general rule: for B bits of accuracy, use about B iterations and B + log₂(B) + 2 internal bits.

### Cost

Yosys reports **no DSP blocks**: about 1,300 LUTs, 413 `CARRY4` and 949 flip-flops for 17 stages of three adders each. That is the CORDIC trade-off: no multipliers and no table memory, in exchange for a long pipeline of adders. On an FPGA with spare DSP blocks and block RAM, a table-based NCO with multipliers is usually cheaper; in an ASIC, or when multipliers are scarce, or when you need magnitude and angle (vectoring mode, below), CORDIC wins.

### Vectoring mode

Run the same iterations but choose d\_i = −sign(y\_i) instead of sign(z\_i): the vector is rotated onto the x-axis. At the end, x holds K times the vector's **magnitude** and z holds its **angle**. That is how hardware computes |I + jQ| and the phase of a complex signal, for example in an FM demodulator or a phase-locked loop.

### Check your understanding: 9.3

1. Why is multiplying by tan θᵢ "free" in CORDIC?
2. What are the first three angles of the sequence, in degrees, and in binary angle units with ZW = 20?
3. To produce cos θ and sin θ in Q1.15 with this design, what should x₀ and y₀ be?
4. Why does the design need a quadrant pre-rotation stage?
5. Why does accuracy stop improving beyond 14 iterations in this design?

#### Answers

1. The angles are chosen so that tan θᵢ = 2⁻ⁱ exactly, and multiplying by 2⁻ⁱ is a right shift by i bits, which is just wiring.
2. arctan(1) = **45°** → 2²⁰/8 = **131,072**; arctan(1/2) = **26.57°** → **77,376**; arctan(1/4) = **14.04°** → **40,884**.
3. x₀ = round(32,767 / 1.64676) = **19,898**, y₀ = **0**. Then x\_out ≈ 32,767·cos θ and y\_out ≈ 32,767·sin θ.
4. The micro-rotations add up to only about ±99.9°, so larger angles cannot be reached. Pre-rotating by exactly ±90° (which only swaps and negates) brings every angle into range.
5. Each stage truncates `y >>> i` and `x >>> i`, losing up to one LSB per stage, and those errors accumulate. Without extra fractional bits in the datapath, the accumulated truncation error, not the remaining angle, limits the accuracy.

## 9.4 The digital mixer

The mixer of section 9.1 needs an NCO and two multipliers: I = x·cos(ω₀n) and Q = −x·sin(ω₀n). Built from the NCO of section 9.2, it shifts a real input's spectrum down by the LO frequency and produces a complex (I/Q) output, bit-exact against a five-line Python model.

> **Figure:** mixer.sv: real input to complex I/Q output (shown in the [online version](https://claude.ai/artifact/7S1igzHyDp8uhEBH4a1TKD))

### The RTL

```systemverilog
`timescale 1ns/1ps
// mixer.sv -- real-to-complex digital mixer: I = x*cos(w0 n), Q = -x*sin(w0 n).
// The NCO advances once per valid input sample. Latency: 2 cycles.
module mixer #(
  parameter int W = 16, ACC_W = 32
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,             // real input, Q1.15
  input  logic [ACC_W-1:0]    fcw,           // LO frequency
  output logic                out_valid,
  output logic signed [W-1:0] i_out, q_out   // complex output, Q1.15
);
  logic                lo_valid;
  logic signed [W-1:0] lo_cos, lo_sin, x_d;

  nco #(.ACC_W(ACC_W), .W(W)) u_nco (
    .clk(clk), .rst(rst), .en(in_valid), .fcw(fcw),
    .out_valid(lo_valid), .cos_o(lo_cos), .sin_o(lo_sin)
  );

  always_ff @(posedge clk) if (in_valid) x_d <= x;   // align x with the NCO's registered output

  logic signed [2*W-1:0] pi, pq;                     // Q2.30 products
  assign pi = x_d * lo_cos;
  assign pq = -(x_d * lo_sin);                        // -32768 * 32767 cannot overflow 32 bits

  logic signed [W-1:0] i_c, q_c;
  logic                ovf_i_unused, ovf_q_unused;
  requant #(.IN_W(2*W), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_rqi (.din(pi), .dout(i_c), .ovf(ovf_i_unused));
  requant #(.IN_W(2*W), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_rqq (.din(pq), .dout(q_c), .ovf(ovf_q_unused));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= lo_valid;
    if (lo_valid) begin
      i_out <= i_c;
      q_out <= q_c;
    end
  end
endmodule
```

The one subtle point is **alignment**. The NCO's outputs are registered, so they appear one clock after the `in_valid` that requested them. The input sample must be delayed by the same amount (`x_d`), or every sample would be multiplied by the oscillator value meant for its neighbor. Alignment errors like this are invisible in a waveform glance and obvious to a bit-exact check.

The overflow comment is worth checking. The NCO's amplitude is 32,767, not 32,768, so the worst product, −32,768 × 32,767, fits in 32 bits, and its negation does too: the −1 × −1 trap of Part 6 cannot occur here.

### Verification

The model is as short as the hardware:

```python
c, s = nco(fcw, N)                                            # the LO, one value per input sample
I = requant(x * c, 30, 16, 15, "round", "saturate")
Q = requant(-(x * s), 30, 16, 15, "round", "saturate")
```

The input was a sum of a tone at 0.2 cycles per sample (amplitude 0.6), a tone at 0.12 (amplitude 0.3) and a little noise, plus full-scale samples at the start; the LO was at 0.15 cycles per sample. With random gaps in `in_valid`, all **8,192 I/Q pairs were bit-exact**.

The spectrum of the complex output (−f\_s/2 to +f\_s/2, Blackman–Harris window) shows exactly the frequencies predicted by section 9.1:

| Input tone | Shifted by −0.15 | Measured peak | Level |
| --- | --- | --- | --- |
| +0.20 | +0.05 | +0.0500 | −0.4 dB |
| −0.20 (the mirror) | −0.35 | −0.3500 | 0.0 dB |
| +0.12 | −0.03 | −0.0300 | −6.1 dB |
| −0.12 (the mirror) | −0.27 | −0.2700 | −5.9 dB |

The 6 dB difference is the 2:1 amplitude ratio of the two input tones. A low-pass filter with a cutoff of about 0.06 cycles per sample would now keep the 0.2 tone (at +0.05) and reject everything else, including its own mirror image at −0.35. That filter, combined with a sample-rate reduction, is the subject of Parts 10 and 12.

### Cost

Yosys reports **2 DSP48E1** blocks (the two multipliers), **2 RAMB18E1** block RAMs (the NCO tables), about 95 LUTs and 66 flip-flops. A complete tunable frequency shifter for a few percent of a small FPGA.

### The CORDIC alternative

A CORDIC in rotation mode does the whole mixing operation by itself: feed it the input as (x, y) and the negated NCO phase as the angle z, and it outputs the rotated (I, Q) directly, scaled by K. With a complex input, it replaces an NCO table and four multipliers with a pipeline of adders. Which is cheaper depends on the target: on an FPGA with free DSP blocks, the table-and-multiplier mixer usually is; in an ASIC, the CORDIC often wins.

### Check your understanding: 9.4

1. What would happen if `x` were not delayed to `x_d`?
2. Why is the NCO's `en` connected to `in_valid`, not tied to 1?
3. An input tone at 0.3 cycles per sample is mixed with an LO at 0.15. Where are the output components?
4. Why can't `pq = -(x_d * lo_sin)` overflow, and what would make it overflow?
5. How would you mix a **complex** input (I\_in, Q\_in) down by f₀? How many multipliers?

#### Answers

1. Each input sample would be multiplied by the LO value of the **next** sample, a phase offset of one LO step. For a single fixed frequency it is a constant phase shift, but it is still a bug, and it breaks bit-exactness. When `in_valid` has gaps, the misalignment changes over time and corrupts the output.
2. So that the LO advances exactly once per **input sample**. If it ran every clock, gaps in `in_valid` would advance the LO without a sample, and its frequency relative to the signal would depend on the gap pattern.
3. +0.3 − 0.15 = **+0.15**, and −0.3 − 0.15 = **−0.45**.
4. The product's magnitude is at most 32,768 × 32,767 = 1,073,709,056, far below 2³¹, so neither it nor its negation can overflow 32 bits. Even a table entry of −32,768 would only give +2³⁰, which still fits. The only real consequence of such an entry would be at the output: a result of exactly +1.0 cannot be represented in Q1.15 and would saturate, which is Part 6's −1 × −1 case. Keeping the table amplitude at 32,767 avoids that, too.
5. A full complex multiplication: I\_out = I·cos + Q·sin, Q\_out = Q·cos − I·sin, which is (I + jQ)(cos − j·sin). That needs **4** multipliers (or 3 with Gauss's trick), or one CORDIC in rotation mode.

## 9.5 Exercises

For scale: their worked solutions add 7 design files and 8 testbenches, about 570 new lines, with the Python checks run inline. Time depends too much on experience for a reliable estimate, so none is given. Each RTL exercise gets a bit-exact Python model, a testbench, lint and a Yosys report. Send me your code, tables and spectra.

- [ ] Exercise 1: a tunable signal generator
- [ ] Exercise 2: a quarter-wave sine table
- [ ] Exercise 3: a more accurate CORDIC
- [ ] Exercise 4: CORDIC in vectoring mode
- [ ] Exercise 5: a complex mixer

### Exercise 1: a tunable signal generator

Add a **phase offset** input to the NCO, so that its output is cos(ω₀n + φ), where φ is a 16-bit binary angle added to the top of the phase before the table lookup.

- Verify it bit-exactly for several offsets, including φ = 90° (the cosine output should then equal the original sine output, negated). Explain why.
- Change the FCW in the middle of a run. Show in a waveform that the output changes frequency **without a jump in phase**. Why does an NCO give phase-continuous frequency changes for free?

### Exercise 2: a quarter-wave sine table

Store only the first quarter of a sine wave (256 entries for an equivalent 1,024-entry table) and reconstruct the full wave from symmetry: the top two phase bits select the quadrant, which decides whether to read the table forward or backward and whether to negate the result.

- Make it bit-exact with the full-table NCO. Careful: the read-backward address must be chosen so that no entry is off by one. Check it exhaustively over all 1,024 addresses.
- Compare block RAM usage in Yosys. Then use the saving to double the address bits (A = 12 in the same memory) and measure the new SFDR.

### Exercise 3: a more accurate CORDIC

- Add G fractional guard bits to the CORDIC datapath (CW = 18 + G), and round the outputs back to 18 bits at the end with `requant`. Update the Python model.
- Measure the maximum error for G = 0, 2, 4 and 6 with 16 iterations. Our Python check found about 7.3 LSB without guard bits and about 2 LSB with 4. Do your RTL measurements agree?
- What limits the accuracy once the guard bits are enough? Test each candidate separately in your model: more iterations (20 instead of 16), a wider angle word (24 bits instead of 20), and more guard bits. (Hints: after 16 iterations, how large can the angle still to be rotated be, and what is that at full scale? Each entry of the arctan table is rounded to the angle's resolution, and 16 of those errors add up in z. Finally, what do the last rounding and the rounding of the starting value 32,767/K contribute? Regenerate `cordic_atan.svh` for more than 16 iterations, or the extra stages will read zeros.)

### Exercise 4: CORDIC in vectoring mode

Build `cordic_vec`: given (x, y), it rotates the vector onto the positive x-axis by choosing dᵢ = −sign(yᵢ), and outputs the magnitude (scaled by K) and the angle accumulated in z.

- Handle the left half-plane with a pre-rotation, as in the rotation-mode design.
- Verify against `np.hypot` and `np.arctan2`, and report the maximum errors.
- Use it to compute the instantaneous phase of the mixer's output for a single tone. What does the phase do over time, and how could you turn that into an FM demodulator?

### Exercise 5: a complex mixer

Extend `mixer` to a complex input (I\_in, Q\_in), computing (I\_in + jQ\_in)·e^{−jω₀n} with four multipliers.

- Verify it bit-exactly, and show with a spectrum that a complex tone at +0.2 cycles per sample moves to +0.05 with an LO at 0.15, **with no mirror image**.
- Rebuild it with three multipliers using Gauss's trick from Part 6. What happens to the bit growth, and does it stay bit-exact with the four-multiplier version?
- Compare both against the CORDIC-based mixer in Yosys: DSP blocks, LUTs, flip-flops, latency.

## 9.6 Summary and what comes next

You can now generate sinusoids of any frequency, rotate vectors without multipliers, and shift a signal's spectrum into complex I/Q form, all bit-exact against Python and measured in the frequency domain. Keep this table beside you for the exercises.

| Topic | Key fact | Remember |
| --- | --- | --- |
| Complex signals | I + jQ; e^{jωn} turns counter-clockwise | Real signals have mirror-image spectra |
| Mixing | Multiplying by e^{−jω₀n} shifts every frequency by −f₀ | Real input: 2 multipliers; complex: 4 |
| Phase accumulator | Wraps modulo 2^N: a full turn | f\_out = FCW · f\_s / 2^N |
| Resolution | f\_s / 2^N | 0.023 Hz at 100 MHz with N = 32 |
| Phase truncation | Spurs about 6.02 dB per table address bit | 1,024 entries: about 60 dBc SFDR |
| Sine table | `$readmemh` in an `initial` block | Maps to block RAM; amplitude 32,767 |
| Indexed part-select | `phase[ACC_W-1 -: A]` | Stays correct when parameters change |
| CORDIC | Micro-rotations by arctan(2⁻ⁱ): shifts and adds | Gain K ≈ 1.6468, compensated once |
| CORDIC accuracy | About one bit per iteration | Needs fractional guard bits |
| Vectoring mode | Rotate to the x-axis | Gives magnitude and angle |
| Alignment | Delay data to match registered LO outputs | Bit-exact checks catch it |
| Spectrum measurement | FFT with a window (Blackman–Harris) | Reveals spurs no waveform shows |
| Tool lesson | Yosys parsed `-CW'(x)` as a cast to width −CW | Parenthesize casts: `-(CW'(x))` |

The ideas that matter most from this part:

1. Complex signals separate positive from negative frequencies, and multiplying by a complex exponential moves a whole spectrum.
2. An NCO's frequency resolution comes from the accumulator width and its purity from the table size: two independent knobs.
3. CORDIC trades multipliers and memory for a pipeline of adders; whether that is a good trade depends on the target.
4. In the frequency domain, "correct" has a number: the SFDR, measured on the RTL's own output.

**Part 10: Multirate processing** changes the sample rate itself. After mixing a signal down to near 0 Hz, a receiver no longer needs the original high sample rate. You will learn decimation and interpolation, why filtering must come first (aliasing again), the **CIC filter** that decimates by large factors using only adders and registers, and **polyphase** structures that skip every multiplication whose result would be thrown away. Together with the NCO, mixer and FIR filter, these are the parts of the digital down-converter in Part 12.
