# Verilog & RTL for DSP — Solutions to Part 3

*Markdown export of the online document: https://claude.ai/artifact/3VHBsdxdFTb54AwPRTRwgt. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the five exercises of Part 3. Try each one yourself first, including the state diagram or ASM chart on paper, as the exercises ask. The answers to the "Check your understanding" questions are in Part 3 itself.

The state diagrams are given here as **transition tables**, one row per state, which carry exactly the same information as a drawn diagram: compare yours row by row. Every FSM follows the three-part template of section 3.2 (state register, next-state logic with defaults, output logic).

**How these solutions were checked.** Every module and testbench was compiled and run with Icarus Verilog 12.0 (`iverilog -g2012 -Wall`) and linted with Verilator 5.020 (`--lint-only -Wall`). Exercise 5 was also checked with Yosys 0.33 (`proc`). Every result quoted is copied from an actual run, and each design was broken once on purpose to confirm that its testbench fails. Each testbench has a watchdog (`$fatal` after a timeout), as the exercises require.

One Icarus limitation, already noted in Part 3, came up again while writing these: Icarus 12 rejects the `?:` operator between enum values (`next = x ? S2 : S1;` gives `This assignment requires an explicit cast`). All the transitions below are therefore written with `if / else`, which every tool accepts.

## Exercise 1: detect 0110, three ways

### The states

Each state remembers the longest suffix of the input so far that is also a prefix of 0110. The prefixes are "" (nothing), "0", "01", "011", and, for Moore only, the complete "0110".

**Moore** (5 states; the output belongs to the state):

| State | Meaning | Next if x = 0 | Next if x = 1 | y |
| --- | --- | --- | --- | --- |
| S0 | nothing useful seen | S1 | S0 | 0 |
| S1 | "0" | S1 | S2 | 0 |
| S2 | "01" | S1 | S3 | 0 |
| S3 | "011" | S4 | S0 | 0 |
| S4 | "0110" just seen | S1 | S2 | **1** |

**Mealy** (4 states; the output belongs to the transition): the same S0 to S3, but from S3 an input of 0 completes the pattern, gives y = 1 **on that transition**, and goes to S1. No fifth state is needed, because the Mealy machine signals the match while the last bit is still on its input.

### The transitions that do not go back to the start

The interesting transitions are the ones where a failed or completed match still leaves a useful suffix, which is what makes the detector **overlapping**:

- **S1, x = 0 → S1**: "00" ends in "0", which is still the first bit of a new match.
- **S2, x = 0 → S1**: "010" fails as "010" but ends in "0".
- **S4, x = 0 → S1** (Moore), and the completing transition **S3, x = 0 → S1** (Mealy): the final 0 of "0110" is also the first 0 of the next possible "0110".
- **S4, x = 1 → S2** (Moore): "01101" ends in "01", two bits into a new match.

Only **S3, x = 1 → S0** truly starts over: "0111" has no suffix that begins 0110.

### The code

```systemverilog
`timescale 1ns/1ps
// detect0110.sv -- overlapping detector for the pattern 0,1,1,0 (oldest first), three ways.

// ---------- Moore: the output depends only on the state ----------
module detect0110_moore (
  input  logic clk, rst, x,
  output logic y
);
  typedef enum logic [2:0] {S0, S1, S2, S3, S4} state_t;   // S4 = "just saw 0110"
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S0;
    else     state <= next;
  end

  always_comb begin
    next = S0;
    case (state)
      S0: if (x) next = S0; else next = S1;     // nothing useful seen yet
      S1: if (x) next = S2; else next = S1;     // "0"
      S2: if (x) next = S3; else next = S1;     // "01"
      S3: if (x) next = S0; else next = S4;     // "011"
      S4: if (x) next = S2; else next = S1;     // "0110": overlap, its last 0 starts a new match
      default: next = S0;
    endcase
  end

  assign y = (state == S4);
endmodule

// ---------- Mealy: the output depends on the state AND the current input ----------
module detect0110_mealy (
  input  logic clk, rst, x,
  output logic y
);
  typedef enum logic [1:0] {S0, S1, S2, S3} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S0;
    else     state <= next;
  end

  always_comb begin
    next = S0;
    y    = 1'b0;
    case (state)
      S0: if (x) next = S0; else next = S1;
      S1: if (x) next = S2; else next = S1;
      S2: if (x) next = S3; else next = S1;
      S3: if (x) next = S0;
          else begin next = S1; y = 1'b1; end   // the 0 that completes 0110
      default: next = S0;
    endcase
  end
endmodule

// ---------- Mealy with a registered output: Mealy logic, output delayed one cycle ----------
module detect0110_mealy_reg (
  input  logic clk, rst, x,
  output logic y
);
  logic y_comb;
  detect0110_mealy u_mealy (.clk(clk), .rst(rst), .x(x), .y(y_comb));

  always_ff @(posedge clk) begin
    if (rst) y <= 1'b0;
    else     y <= y_comb;          // y comes straight from a flip-flop: glitch-free
  end
endmodule
```

The registered Mealy version reuses the Mealy module and adds one flip-flop, so its output has exactly the Moore version's timing while needing only 4 states.

### The testbench

The model `last4` holds the last four bits already clocked in. The Mealy output is compared with `{last4[2:0], x}` (it includes the current bit); the Moore and registered outputs with `last4` (one cycle later):

```systemverilog
`timescale 1ns/1ps
module tb_detect0110;
  logic clk = 1'b0, rst, x;
  logic y_moore, y_mealy, y_mreg;
  logic [3:0] last4 = 4'b1111;       // the last 4 bits ALREADY clocked in (oldest in bit 3)
  int found_moore = 0, found_mealy = 0, found_mreg = 0, expected = 0, errors = 0;
  detect0110_moore     u1 (.clk(clk), .rst(rst), .x(x), .y(y_moore));
  detect0110_mealy     u2 (.clk(clk), .rst(rst), .x(x), .y(y_mealy));
  detect0110_mealy_reg u3 (.clk(clk), .rst(rst), .x(x), .y(y_mreg));
  always #5 clk = ~clk;
  initial begin #200_000; $fatal(1, "TIMEOUT"); end

  initial begin
    rst = 1'b1; x = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (5000) begin
      x = $urandom_range(0, 1);                      // new bit, applied at the falling edge
      #1;
      // Mealy: sees the current bit, so it reports a match in the same cycle
      if (y_mealy !== ({last4[2:0], x} == 4'b0110)) begin errors++; $display("FAIL mealy at %0d", $time); end
      // Moore and registered Mealy: report a match one cycle later, from the bits already clocked in
      if (y_moore !== (last4 == 4'b0110)) begin errors++; $display("FAIL moore at %0d", $time); end
      if (y_mreg  !== (last4 == 4'b0110)) begin errors++; $display("FAIL mealy_reg at %0d", $time); end
      found_mealy += y_mealy;  found_moore += y_moore;  found_mreg += y_mreg;
      expected    += ({last4[2:0], x} == 4'b0110);
      @(posedge clk);
      last4 = {last4[2:0], x};
      @(negedge clk);
    end
    // count the Moore/registered match of the final bit, which appears one cycle later
    #1; found_moore += y_moore; found_mreg += y_mreg;
    if (errors == 0 && found_mealy == expected && found_moore == expected && found_mreg == expected)
      $display("PASS: 5000 bits, %0d patterns expected; Moore %0d, Mealy %0d, registered Mealy %0d",
               expected, found_moore, found_mealy, found_mreg);
    else
      $display("FAILED: errors %0d, expected %0d, found %0d %0d %0d", errors, expected, found_moore, found_mealy, found_mreg);
    $finish;
  end
endmodule
```

`last4` starts at `1111`, which matches no prefix of 0110, so the model starts in the same "nothing seen" condition as the reset FSMs.

### Results

```text
PASS: 5000 bits, 324 patterns expected; Moore 324, Mealy 324, registered Mealy 324
```

324 matches in 5,000 random bits is close to the expected 5,000/16 ≈ 312 (each position matches with probability 1/16). All three versions are lint-clean (Verilator only notes, as `DECLFILENAME`, that the file name differs from the module names, because three modules share one file).

With the overlap transition broken (S4, x = 1 going to S0 instead of S2), the testbench reported `FAILED: errors 38, expected 324, found 286 324 324`: the Moore version missed 38 matches, the ones that reuse the final 0 of the previous match when a 1 follows it, as in 0110110.

## Exercise 2: traffic-light controller

### The split

- **Datapath**: a 3-bit down-counter, `timer`, which the controller can load (`load`, `load_val`) and which counts down by one on each `tick` until it reaches zero. It reports one status signal, `timer_zero`.
- **Controller**: three states. In each, it waits for `tick && timer_zero`, then moves to the next color and loads the timer with that color's duration minus one.

| State | Leaves when | Goes to | Loads the timer with |
| --- | --- | --- | --- |
| S\_GREEN | `tick && timer_zero` | S\_YELLOW | 2 − 1 = 1 |
| S\_GREEN | `ped && !timer_zero` (stays) | S\_GREEN | 0: at most one more tick |
| S\_YELLOW | `tick && timer_zero` | S\_RED | 4 − 1 = 3 |
| S\_RED | `tick && timer_zero` | S\_GREEN | 5 − 1 = 4 |

Why duration **minus one**: the state is entered at a tick. Loaded with D − 1, the timer reaches zero after D − 1 more ticks, and the transition happens on the next one, the D-th tick. On reset, the timer is loaded with 5 − 1 = 4 for the first green.

### The code

```systemverilog
`timescale 1ns/1ps
// traffic_light.sv -- green 5 ticks, yellow 2, red 4, repeat; ped shortens green.
// Controller (FSM) + datapath (down-counter timer). Lights come from flip-flops.
module traffic_light #(
  parameter int DIV = 4,                       // tick_gen division (4 for fast simulation)
  parameter int T_GREEN = 5, T_YELLOW = 2, T_RED = 4
) (
  input  logic clk, rst,
  input  logic ped,                            // pedestrian request (synchronous here)
  output logic green, yellow, red
);
  // ---- tick source (Part 2) ----
  logic tick;
  tick_gen #(.DIV(DIV)) u_tick (.clk(clk), .rst(rst), .tick(tick));

  // ---- datapath: the timer ----
  logic [2:0] timer, load_val;
  logic       load, timer_zero;
  assign timer_zero = (timer == 3'd0);

  always_ff @(posedge clk) begin
    if (rst)                      timer <= 3'(T_GREEN - 1);   // green starts with its full duration
    else if (load)                timer <= load_val;
    else if (tick && !timer_zero) timer <= timer - 1'b1;
  end

  // ---- controller ----
  typedef enum logic [1:0] {S_GREEN, S_YELLOW, S_RED} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_GREEN;
    else     state <= next;
  end

  always_comb begin
    next = state;  load = 1'b0;  load_val = '0;          // defaults: stay, keep counting
    case (state)
      S_GREEN:
        if (tick && timer_zero) begin
          next = S_YELLOW;  load = 1'b1;  load_val = 3'(T_YELLOW - 1);
        end else if (ped && !timer_zero) begin
          load = 1'b1;  load_val = 3'd0;                    // at most 1 more tick of green
        end
      S_YELLOW:
        if (tick && timer_zero) begin
          next = S_RED;     load = 1'b1;  load_val = 3'(T_RED - 1);
        end
      S_RED:
        if (tick && timer_zero) begin
          next = S_GREEN;   load = 1'b1;  load_val = 3'(T_GREEN - 1);
        end
      default: next = S_GREEN;
    endcase
  end

  // ---- registered outputs: decoded from NEXT, so they change together with the state ----
  always_ff @(posedge clk) begin
    if (rst) {green, yellow, red} <= 3'b100;
    else     {green, yellow, red} <= {next == S_GREEN, next == S_YELLOW, next == S_RED};
  end
endmodule
```

**Outputs from flip-flops** (section 3.3): the three lights are registers loaded from a decode of `next`, so they change at exactly the same clock edge as `state` does, without the one-cycle delay that registering a decode of `state` would add, and without any combinational logic between the flip-flops and the pins. Exactly one of the three is 1 after every edge, because `next` is always exactly one of the three states (reset sets `100`).

It reuses `tick_gen` and `mod_counter` from Part 2 unchanged. Compile with all four files: `iverilog -g2012 -Wall -o sim tick_gen.sv mod_counter.sv traffic_light.sv tb_traffic_light.sv`.

### The testbench

```systemverilog
`timescale 1ns/1ps
module tb_traffic_light;
  logic clk = 1'b0, rst, ped, green, yellow, red;
  int g = 0, yl = 0, r = 0, cycles_done = 0, errors = 0, ped_ticks = -1;
  logic [2:0] prev;
  traffic_light #(.DIV(4)) dut (.*);
  always #5 clk = ~clk;
  initial begin #100_000; $fatal(1, "TIMEOUT"); end

  // exactly one light, always (checked at every falling edge after reset)
  always @(negedge clk) if (!rst && (green + yellow + red) != 1) begin
    $display("FAIL: lights %b%b%b at %0d ns", green, yellow, red, $time); errors++;
  end

  // count ticks per color: a tick at a rising edge belongs to the color shown before that edge
  always @(posedge clk) if (!rst) begin
    prev = {green, yellow, red};
    if (dut.tick) begin
      if (green)  g++;
      if (yellow) yl++;
      if (red)    r++;
      if (ped_ticks >= 0 && green) ped_ticks++;
    end
  end

  // at each change of color, check the run that just ended
  always @(negedge clk) if (!rst && {green, yellow, red} != prev && prev != 3'b000) begin
    if (prev == 3'b100) begin
      if (ped_ticks < 0 && g != 5) begin $display("FAIL: green lasted %0d ticks", g);  errors++; end
      if (ped_ticks >= 0) begin
        $display("pedestrian press during green: green lasted %0d more tick(s) after the press", ped_ticks);
        if (ped_ticks > 1) errors++;
        ped_ticks = -1;
      end
      g = 0;
    end
    if (prev == 3'b010) begin if (yl != 2) begin $display("FAIL: yellow lasted %0d ticks", yl); errors++; end yl = 0; end
    if (prev == 3'b001) begin if (r  != 4) begin $display("FAIL: red lasted %0d ticks", r);    errors++; end r = 0; cycles_done++; end
  end

  initial begin
    rst = 1'b1; ped = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    wait (cycles_done == 10);
    $display("10 full cycles: green 5, yellow 2, red 4 ticks each time");
    // pedestrian: press for one cycle, 1 tick into a green phase
    @(posedge green); repeat (5) @(negedge clk);
    ped = 1'b1; ped_ticks = 0; @(negedge clk); ped = 1'b0;
    wait (cycles_done == 12);
    if (errors == 0) $display("PASS");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

The testbench reads the internal tick through a **hierarchical reference**, `dut.tick`: a testbench may look inside the design, a design may not. A tick seen at a rising edge is counted for the color shown just **before** that edge, because the last tick of each color is the one that changes it.

### Results

```text
10 full cycles: green 5, yellow 2, red 4 ticks each time
pedestrian press during green: green lasted 1 more tick(s) after the press
PASS
```

The design is lint-clean. With yellow's load value deliberately off by one (`T_YELLOW` instead of `T_YELLOW - 1`), the testbench reported `FAIL: yellow lasted 3 ticks` for every cycle.

### The pedestrian extension

In the diagram, the change is one extra self-loop on S\_GREEN: if `ped` is pressed while the timer is not yet zero, the timer is reloaded with 0, so the next tick ends green. If the timer is already zero, green ends at the next tick anyway, so nothing needs to happen. The transition to yellow has priority over the `ped` reload, so a press on the very tick that ends green cannot extend it. In a real crossing, `ped` would come from a button through the synchronizer and edge detector of Part 2, Exercise 1.

## Exercise 3: serial (UART) transmitter

### The design

- **Datapath**: a 10-bit shift register, `shreg`, loaded with `{1'b1, data, 1'b0}` (stop bit, data, start bit, so the start bit is at bit 0 and goes out first), a bit counter `nbits`, and the output register `tx`.
- **Controller**: `S_IDLE` (ready for a byte; `tx` stays 1) and `S_SEND`. In `S_SEND`, each `baud_tick` puts `shreg[0]` on `tx`, shifts the register right (filling with 1s), and counts. After the tick that puts the tenth bit, the stop bit, on the line, it returns to `S_IDLE`.

| State | Condition | Action | Next |
| --- | --- | --- | --- |
| S\_IDLE | `in_valid` (with `in_ready` = 1) | load `shreg`, clear `nbits` | S\_SEND |
| S\_SEND | `baud_tick`, `nbits` < 9 | `tx <= shreg[0]`, shift, count | S\_SEND |
| S\_SEND | `baud_tick`, `nbits` = 9 | `tx <= shreg[0]` (the stop bit), shift, count | S\_IDLE |

```systemverilog
`timescale 1ns/1ps
// uart_tx.sv -- 8N1 serial transmitter: start bit (0), 8 data bits LSB first, stop bit (1).
// One bit per baud_tick. Valid/ready input: a byte is accepted when in_valid && in_ready.
module uart_tx (
  input  logic       clk, rst,
  input  logic       baud_tick,       // one pulse per bit period
  input  logic       in_valid,
  output logic       in_ready,
  input  logic [7:0] data,
  output logic       tx                // idles at 1; driven by a flip-flop
);
  typedef enum logic {S_IDLE, S_SEND} state_t;
  state_t     state;
  logic [9:0] shreg;                  // {stop, data[7:0], start}: bit 0 goes out first
  logic [3:0] nbits;                  // bits sent so far in this frame

  assign in_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;  tx <= 1'b1;  shreg <= '1;  nbits <= '0;
    end else begin
      case (state)
        S_IDLE:
          if (in_valid) begin                       // in_ready is 1 here: a transfer
            shreg <= {1'b1, data, 1'b0};
            nbits <= '0;
            state <= S_SEND;
          end
        S_SEND:
          if (baud_tick) begin                      // each bit starts on a tick
            tx    <= shreg[0];
            shreg <= {1'b1, shreg[9:1]};
            nbits <= nbits + 1'b1;
            if (nbits == 4'd9) state <= S_IDLE;     // the stop bit is now on the line
          end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule
```

This is a small FSM written in a single `always_ff` block, which is fine when the outputs are all registers anyway; the three-block template of section 3.2 would work equally well.

Three timing details make the frame correct:

1. **Every bit starts on a `baud_tick`**, including the start bit. Loading the shift register in `S_IDLE` does not change `tx`; the start bit appears at the first tick after the byte is accepted, so it lasts a full bit period.
2. **The stop bit lasts at least one full period.** The FSM returns to `S_IDLE` at the tick that drives the stop bit. Even if a new byte is accepted immediately, its start bit cannot appear before the next tick, one full period later.
3. **`in_ready` depends only on the state**, not on `in_valid`, following the valid/ready rules of section 3.6.

### The testbench and its receiver model

```systemverilog
`timescale 1ns/1ps
module tb_uart_tx;
  localparam int BAUD = 8;                          // clocks per bit
  logic clk = 1'b0, rst, baud_tick, in_valid, in_ready, tx;
  logic [7:0] data;
  logic [7:0] sent [$];                             // queue of bytes accepted by the DUT
  int received = 0, errors = 0, cnt = 0;
  uart_tx dut (.*);
  always #5 clk = ~clk;
  initial begin #200_000; $fatal(1, "TIMEOUT"); end

  // baud tick: one pulse every BAUD clocks
  always @(posedge clk) begin
    if (rst) begin cnt <= 0; baud_tick <= 1'b0; end
    else begin cnt <= (cnt == BAUD - 1) ? 0 : cnt + 1; baud_tick <= (cnt == BAUD - 1); end
  end

  // source: random bytes with random gaps, following valid/ready
  initial begin
    rst = 1'b1; in_valid = 1'b0; data = '0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    repeat (50) begin
      repeat ($urandom_range(0, 30)) @(negedge clk);   // random idle gap
      in_valid = 1'b1; data = $urandom;
      do @(posedge clk); while (!in_ready);          // transfer at an edge with ready high
      sent.push_back(data);
      @(negedge clk); in_valid = 1'b0; data = 'x;
    end
  end

  // receiver model: falling edge = start bit; sample each bit in its middle
  initial begin
    logic [7:0] b;
    @(negedge rst);
    repeat (50) begin
      @(negedge tx);                                  // start of the start bit
      repeat (BAUD / 2) @(posedge clk);              // middle of the start bit
      if (tx !== 1'b0) begin $display("FAIL: bad start bit"); errors++; end
      for (int i = 0; i < 8; i++) begin
        repeat (BAUD) @(posedge clk);
        b[i] = tx;                                    // LSB first
      end
      repeat (BAUD) @(posedge clk);
      if (tx !== 1'b1) begin $display("FAIL: bad stop bit"); errors++; end
      if (b !== sent[received]) begin
        $display("FAIL byte %0d: received %h, sent %h", received, b, sent[received]); errors++;
      end
      received++;
    end
    if (errors == 0) $display("PASS: %0d bytes received correctly", received);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

New testbench features:

- **A queue**, `logic [7:0] sent [$]`, grows with `push_back` as bytes are accepted and is indexed by the receiver. It decouples the source from the receiver, which run in separate `initial` blocks.
- **The receiver behaves like real UART hardware**: it waits for the falling edge of the start bit, moves to the middle of that bit, and then samples once per bit period, in the middle of each bit, which is the point most tolerant of timing errors. It knows nothing about the transmitter's internals.

Result: `PASS: 50 bytes received correctly`, lint-clean. With the data bits deliberately rotated by one place when loaded, the receiver reported `FAIL byte 0: received c0, sent 81`.

### Why must `tx` come from a flip-flop?

`tx` leaves the chip and goes to a receiver that is **not synchronized to this clock**: the receiver watches the line continuously and treats any falling edge in the idle state as the start of a frame. Combinational logic can **glitch**: while its inputs change at a clock edge, its output can briefly take wrong values before settling. Inside a synchronous design, glitches are harmless because flip-flops only sample after the logic has settled. On `tx`, a brief glitch to 0 while idle would look like a start bit, and the receiver would read a whole false byte. A flip-flop's output changes once per clock edge, cleanly, so the line only ever carries the intended levels.

## Exercise 4: sequential divider

The solution follows the six steps of section 3.5.

### Step 1: the algorithm

For W steps: shift `{R, Q}` left by one place (the top bit of Q moves into the bottom of R); if the shifted R is at least the divisor D, subtract D and set the new bottom bit of Q to 1, otherwise leave R as it is ("restore") and set it to 0. After W steps, Q is the quotient and R the remainder. Worked by hand, 13 ÷ 3 with W = 4 gives Q = 4 and R = 1.

### Step 2: the registers

| Register | Width | Holds |
| --- | --- | --- |
| R | W | Partial remainder, always < D after each step |
| Q | W | Dividend bits not yet used, then the quotient bits |
| D | W | The divisor, captured at the start |
| count | log₂ W | Steps done |

The shifted remainder `{R, Q[W-1]}` can reach 2D − 1, so it needs **W + 1** bits. R itself only needs W bits, because after the subtract-or-restore it is again smaller than D. (The first version of this solution declared R with W + 1 bits; Verilator flagged `UNUSEDSIGNAL: Bits of signal are not used: 'r'[8]`, which is exactly this observation.)

### Step 3: the ASM chart, as a table

| State | Condition | Actions | Next |
| --- | --- | --- | --- |
| S\_IDLE | `start` and D = 0 | `load`; set `div_by_zero` | S\_DONE |
| S\_IDLE | `start` and D ≠ 0 | `load`; clear `div_by_zero` | S\_RUN |
| S\_RUN | not `last` | `step` | S\_RUN |
| S\_RUN | `last` | `step` | S\_DONE |
| S\_DONE | — | `done` = 1 for one cycle | S\_IDLE |

`busy` is 1 in S\_RUN.

### Step 4: control and status signals

- **Control** (controller → datapath): `load` (R ← 0, Q ← dividend, D ← divisor, count ← 0) and `step` (one division step).
- **Status** (datapath → controller): `last` (count = W − 1: this is the final step) and `d_zero` (the divisor input is 0).

### Step 5: datapath and controller

```systemverilog
`timescale 1ns/1ps
// div_datapath.sv -- registers and arithmetic of the restoring divider
module div_datapath #(
  parameter int W = 8
) (
  input  logic         clk,
  input  logic [W-1:0] dividend, divisor,
  input  logic         load,          // control: R <= 0, Q <= dividend, D <= divisor, count <= 0
  input  logic         step,          // control: one restoring-division step
  output logic         last,          // status: this is step W (count == W-1)
  output logic         d_zero,        // status: the divisor input is zero
  output logic [W-1:0] quotient, remainder
);
  logic [W-1:0]         r;            // partial remainder: always < divisor, so W bits suffice
  logic [W-1:0]         q, d;
  logic [$clog2(W)-1:0] count;
  logic [W:0]           r_sh;         // R shifted left with the next dividend bit: needs W+1 bits
  logic                 fits;

  assign r_sh   = {r, q[W-1]};
  assign fits   = (r_sh >= {1'b0, d});
  assign last   = (count == ($clog2(W))'(W - 1));
  assign d_zero = (divisor == '0);

  always_ff @(posedge clk) begin
    if (load) begin
      r <= '0;  q <= dividend;  d <= divisor;  count <= '0;
    end else if (step) begin
      r     <= fits ? W'(r_sh - {1'b0, d}) : r_sh[W-1:0];   // subtract only if it fits ("restore" otherwise)
      q     <= {q[W-2:0], fits};                      // the new quotient bit enters at the bottom
      count <= count + 1'b1;
    end
  end

  assign quotient  = q;
  assign remainder = r;
endmodule
```

```systemverilog
`timescale 1ns/1ps
// div_ctrl.sv -- controller of the restoring divider: start / busy / done
module div_ctrl (
  input  logic clk, rst,
  input  logic start,
  input  logic last, d_zero,          // status from the datapath
  output logic load, step,            // control to the datapath
  output logic busy, done, div_by_zero
);
  typedef enum logic [1:0] {S_IDLE, S_RUN, S_DONE} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_IDLE;
    else     state <= next;
  end

  // div_by_zero is registered: it holds the result of the last division until the next start
  always_ff @(posedge clk) begin
    if (rst)                            div_by_zero <= 1'b0;
    else if (state == S_IDLE && start)  div_by_zero <= d_zero;
  end

  always_comb begin
    next = state;  load = 1'b0;  step = 1'b0;
    case (state)
      S_IDLE: if (start) begin
                load = 1'b1;
                if (d_zero) next = S_DONE;               // skip the computation for divisor 0
                else        next = S_RUN;
              end
      S_RUN:  begin
                step = 1'b1;
                if (last) next = S_DONE;
              end
      S_DONE: next = S_IDLE;
      default: next = S_IDLE;
    endcase
  end

  assign busy = (state == S_RUN);
  assign done = (state == S_DONE);                       // a one-cycle pulse
endmodule
```

The top level, `seq_div.sv`, only instantiates the two and connects `load`, `step`, `last` and `d_zero` between them, exactly like `seq_mult` in section 3.5.

### Step 6: verification

The testbench applies `dividend` and `divisor` with `start` for one cycle, then drives them to `'x` (proving the design captured them), waits for `done`, and compares with SystemVerilog's own `/` and `%`. Corner cases: 0 ÷ 5, 5 ÷ 0, 0 ÷ 0, 255 ÷ 1, 255 ÷ 255, 1 ÷ 255, 254 ÷ 255, 255 ÷ 2, 128 ÷ 128, 127 ÷ 128, 255 ÷ 16 and 7 ÷ 7, then 1,000 random pairs:

```text
200 / 7: q=28 r=4, 9 cycles from start to done
5 / 0: div_by_zero=1, 1 cycles
PASS: 1013 divisions
```

Because 8-bit operands allow only 256 × 255 valid pairs, a second run (`-DEXHAUSTIVE`) tested **every** dividend against every non-zero divisor: `PASS: 65293 divisions` (65,280 pairs plus the 13 directed cases). That is a complete proof for W = 8. The design is lint-clean for W = 8 and W = 16. With the restore step removed (always subtracting), the first check failed: `FAIL: 200 / 7 -> q=127 r=207 dbz=0, expected q=28 r=4`.

### How many cycles does a division take?

**W + 1 = 9 clock cycles** from the edge that samples `start` to the cycle in which `done` is high: 1 cycle to load, then W = 8 cycles of steps. A division by zero takes **1** cycle, because the controller goes straight from S\_IDLE to S\_DONE. Like the multiplier of section 3.5, it uses one adder (here a subtractor and a comparator) W times instead of W copies of it.

## Exercise 5: find the four bugs

### Step 1: what each tool reports

**Icarus** (`iverilog -g2012 -Wall`):

```text
blink_ctrl.sv:18: warning: A non-blocking assignment should not be used in an always_comb process.
```

**Verilator** (`--lint-only -Wall`):

```text
%Warning-CASEINCOMPLETE: blink_ctrl.sv:15:5: Case values incompletely covered (example pattern 0x3)
%Warning-COMBDLY: blink_ctrl.sv:18:26: Non-blocking assignment '<=' in combinational logic process
```

**Yosys** (`yosys -p "read_verilog -sv blink_ctrl.sv; proc"`):

```text
ERROR: Latch inferred for signal `\blink_ctrl.\led' from always_comb process ...
```

| Bug | Icarus | Verilator | Yosys | Testbench |
| --- | --- | --- | --- | --- |
| 1. `next <= S_OFF` in `always_comb` | ✔ | ✔ |  |  |
| 2. `case` without `default` |  | ✔ |  |  |
| 3. Nothing assigned in `S_OFF` when `go` = 0: latches |  |  | ✔ |  |
| 4. `led` = 1 in `S_OFF` when `go` = 1 |  |  |  | ✔ |

The tools disagree, as the exercise said they would: the incomplete `case` is reported only by Verilator, and the latch only by Yosys. Yosys stops at its first error, the latch on `led`; `next` is unassigned on the same path and would be a latch too.

### The four bugs

1. **A non-blocking `<=` in combinational logic.** Rule (sections 3.2 and 2.3): `always_comb` uses blocking `=` only; `<=` belongs in clocked blocks.
2. **An incomplete `case`.** The 2-bit state has a fourth encoding, `2'b11`, which no branch handles. Rule (section 3.4): always give an FSM's `case` a `default` that returns to a safe state, so an illegal state can recover.
3. **Unassigned outputs.** In `S_OFF`, when `go` is 0, neither `next` nor `led` is assigned, so both must hold their old values: latches. Rule (sections 1.5 and 3.2): assign defaults at the top of every `always_comb`.
4. **`led` is wrong in `S_OFF`.** When `go` is 1 in `S_OFF`, the code sets `led = 1`, so the LED turns on one cycle early, for as long as `go` is held. The specification says `led` is 1 **only in `S_ON`**: a Moore output. The code is perfectly legal, so no tool can object; only a testbench that checks the specification can.

### Step 2: the testbench

The model tracks the specified state machine and checks `led` against "model state is ON", with random `go`, in every cycle:

```systemverilog
`timescale 1ns/1ps
// tb_blink.sv -- checks the specification: led = 1 only in S_ON; OFF -go-> ON -> WAIT -> OFF
module tb_blink;
  logic clk = 1'b0, rst, go, led;
  int errors = 0, model = 0;                   // model state: 0 = OFF, 1 = ON, 2 = WAIT
  blink_ctrl dut (.*);
  always #5 clk = ~clk;
  initial begin #100_000; $fatal(1, "TIMEOUT"); end
  initial begin
    rst = 1'b1; go = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (2000) begin
      go = $urandom_range(0, 1);
      #1;                                        // settle, then check the combinational output
      if (led !== (model == 1)) begin
        if (errors < 4) $display("FAIL at %0d ns: state %0d go=%b led=%b, expected %b", $time, model, go, led, model == 1);
        errors++;
      end
      @(posedge clk);
      case (model)
        0: if (go) model = 1;
        1: model = 2;
        default: model = 0;
      endcase
      @(negedge clk);
    end
    if (errors == 0) $display("PASS"); else $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

On the original module it failed at once, on bug 4:

```text
FAIL at 21 ns: state 0 go=1 led=1, expected 0
```

### Step 3: the rewrite

```systemverilog
`timescale 1ns/1ps
// blink_ctrl.sv -- rewritten in the style of section 3.2:
//   defaults first, a default branch, blocking '=' only, and a Moore output decoded from the state.
module blink_ctrl (
  input  logic clk, rst, go,
  output logic led
);
  typedef enum logic [1:0] {S_OFF, S_ON, S_WAIT} state_t;
  state_t state, next;

  // 1. state register
  always_ff @(posedge clk) begin
    if (rst) state <= S_OFF;
    else     state <= next;
  end

  // 2. next-state logic: only 'next' is assigned here, with a default first
  always_comb begin
    next = state;                       // default: every path assigns next (no latch)
    case (state)
      S_OFF:   if (go) next = S_ON;
      S_ON:    next = S_WAIT;
      S_WAIT:  next = S_OFF;
      default: next = S_OFF;            // the unused encoding 2'b11 recovers
    endcase
  end

  // 3. output logic: Moore, a function of the state only, written once
  assign led = (state == S_ON);
endmodule
```

Why each bug is now **impossible**, not just fixed:

- **Bug 3**: the first line of the `always_comb` assigns `next`, so every path assigns it; and `led` is no longer assigned in that block at all.
- **Bug 4**: `led` is written exactly once, as a function of `state` only. It cannot depend on `go`, so it cannot be on outside `S_ON`.
- **Bug 2**: the `default` branch covers every encoding not listed.
- **Bug 1**: the next-state block contains only blocking assignments to a single variable, so there is no place where a `<=` would make sense.

Results with the rewrite: the testbench prints `PASS`; Icarus prints no warnings; Verilator is clean; and Yosys's `proc` reports `No latch inferred for signal '\blink_ctrl.\next'`.

---

That completes Part 3. Send me your own diagrams and solutions if you would like them reviewed; FSMs in particular often have several equally good designs.
