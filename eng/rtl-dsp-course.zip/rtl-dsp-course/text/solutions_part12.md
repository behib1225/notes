# Verilog & RTL for DSP — Solutions to Part 12

*Markdown export of the online document: https://claude.ai/artifact/3jrnSkCFdJSJcQWgeJB226. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the four exercises of Part 12, with starting points for the three projects. The exercises each change the DDC, so every solution follows the course's method: a model change, a bit-exact check of the RTL, and a measurement of what improved.

**How these solutions were checked.** Everything was run with Python 3, NumPy and SciPy, Icarus Verilog 12.0 (`-g2012 -Wall`), Verilator 5.020 (`--lint-only -Wall`) and Yosys 0.33. Every RTL variant of the DDC is bit-exact against the model, both in the testbench and in an independent Python check, on at least two seeds, and every number below is copied from an actual run.

### One generalized model

All four exercises need the model to do a little more than `ddc_model.golden()`: an FCW that can change per sample, any NCO table size, and any power-of-two R with its own compensation filter. `ddc_lib.py` provides that, reusing the Part 9, 10 and 12 building blocks:

```python
def nco_var(fcws, A=10):
    """Part 9 NCO with a per-sample FCW: output k uses the phase before the k-th increment."""
    fcws = np.asarray(fcws, dtype=np.int64)
    ph = np.concatenate([[0], np.cumsum(fcws[:-1])]) % (1 << 32)
    c, s = make_lut(A)
    return c[ph >> (32 - A)], s[ph >> (32 - A)], ph

def golden(x, fcws, A=10, R=8):
    x = np.asarray(x, dtype=np.int64)
    if np.isscalar(fcws): fcws = np.full(len(x), fcws, dtype=np.int64)
    c, s, _ = nco_var(fcws, A)
    i = requant(x * c, 30, 16, 15, "round", "saturate")
    q = requant(-(x * s), 30, 16, 15, "round", "saturate")
    i, q = cic_decim_golden(i, R, 5), cic_decim_golden(q, R, 5)
    hq = coefficients(R)
    return fir_model.golden(i, hq)[1::2], fir_model.golden(q, hq)[1::2]
```

It also contains `sqnr()`, the floating-point references of section 12.4 (five cascaded R-sample moving sums instead of the integer CIC, with either the NCO's table values or an ideal oscillator), and `mirror_dbc()`. As a check, with the Part 12 settings it reproduces the course's results exactly: outputs bit-identical to `ddc_model.golden()`, **79.5 dB** against the table-based reference, **49.1 dB** against an ideal oscillator, mirror at **−64.4 dBc**.

Writing it exposed one small bug of my own, worth knowing: the CIC response |sin(πfR)/(R sin(πf))|⁵ is 0/0 at f = 0, and replacing f by a tiny value only in the denominator gives 0, then 1/0 in the compensation target. Part 12's `cic_response` replaces f in **both** places, which is the right way.

## Exercise 1: harden the testbench

### Lockstep assertions

The I and Q branches are separate instances that must stay in step. `ddc.sv` already ties off the Q branch's status signals (for lint); the testbench checks them through **hierarchical references**, so the design needs no change:

```systemverilog
  // ---- the I and Q branches must stay in lockstep ----
  always @(negedge clk) if (!rst) begin
    assert (dut.cic_valid === dut.cic_valid_q) else $fatal(1, "I/Q CIC valid signals disagree");
    assert (dut.fir_rdy_i === dut.fir_rdy_q)   else $fatal(1, "I/Q FIR ready signals disagree");
    assert (dut.out_valid === dut.fir_valid_q) else $fatal(1, "I/Q output valid signals disagree");
    assert (!overrun) else $fatal(1, "OVERRUN: a sample was lost between the CIC and the FIR");
  end
```

The same assertions apply unchanged to the DDC variants of Exercises 2 to 4, which keep the signal names.

### An FCW change in the middle of a run

The testbench takes `+SWITCH=k` and `+FCW1=…`: from input sample k on, it drives the new FCW. The model already accepts a per-sample FCW array (`nco_var` integrates it), and the generator writes the same schedule:

```python
fcws = np.full(a.n, a.fcw0, dtype=np.int64)
if a.switch >= 0: fcws[a.switch:] = a.fcw1
yi, yq = golden(x, fcws, A=a.a)
```

With the LO moving from 4.8 MHz (`0x3D70A3D7`) to 4.85 MHz (`0x3E147AE1`) at sample 9,000, both seeds passed bit-exactly. The output tone moves from **0.2000 to 0.1500 MHz**, and its amplitude stays at 0.150 straight through the switch (0.1499 to 0.1507 for outputs 560 to 566): the NCO's phase register is never reset, so the LO's phase, and the output, are continuous.

To confirm the check can fail, the model was generated with the switch and the testbench run without it: `FAIL output 564: got 4823 -1059, expected 4823 -1060`. The first difference appears at output 564, just after 9,000/16 ≈ 562 plus the filters' delay, exactly where it should.

### One script: `run_ddc.sh`

```sh
#!/bin/sh
# run_ddc.sh -- regenerate, simulate and check in ONE run, for several seeds; stop at the first failure.
# Usage: ./run_ddc.sh [seeds] [gap] [switch-sample]      e.g. ./run_ddc.sh 5 5 9000
set -e
SEEDS=${1:-3}; GAP=${2:-5}; SW=${3:--1}
iverilog -g2012 -Wall -o sim_ddc2 ddc.sv mixer.sv nco.sv cic_decim.sv fir_decim.sv mac.sv requant.sv tb_ddc2.sv
for SEED in $(seq 1 "$SEEDS"); do
  rm -f x.hex y_expected.txt y_actual.txt fcws.npy        # no file can survive from an earlier run
  python3 ddc_gen.py --seed "$SEED" --switch "$SW" --fcw1 3e147ae1
  vvp -n sim_ddc2 +SEED="$SEED" +GAP="$GAP" +SWITCH="$SW" +FCW1=3e147ae1 | grep -E "PASS|FAIL|FATAL|ERROR"
  python3 ddc_check.py
done
echo "all $SEEDS seeds passed"
```

Three defenses against the stale-file mistake of section 12.4:

1. **Every file is deleted** before each seed's run, so a missing step fails loudly instead of reusing an old result.
2. **One script** generates, simulates and checks, so the three always belong to the same run.
3. **An independent checker**, `ddc_check.py`, recomputes the model from the `x.hex` and FCW schedule actually used, rather than trusting `y_expected.txt`, and compares it with `y_actual.txt`. A mismatch between any two files of a run is caught.

`set -e` stops the script at the first failing command. One subtlety: `vvp`'s output goes through `grep`, and a pipeline's exit status is that of its **last** command, so a `$fatal` in the testbench alone would not stop the script. It does not need to: after a failed simulation, `y_actual.txt` is incomplete or wrong, the independent check fails, and `set -e` stops there. (In bash, `set -o pipefail` would make the simulation's own failure stop it too.) Results:

```text
seed 1: 32768 inputs -> 2048 outputs; FCW 0x3d70a3d7
PASS: 2048 complex outputs bit-exact, 196645 clock cycles
independent check: PASS (2048 outputs)
...
all 3 seeds passed
```

and, with the FCW switch, `all 2 seeds passed`.

## Exercise 2: fix the weakest link

### The RTL: a quarter-wave NCO in the mixer

The Part 9 solutions' `nco_qw2.sv` reproduces a 2^A-entry table from 2^(A−2) stored words, and its table reads are registered first so they map onto block RAM. It has **two** cycles of latency instead of one, so `mixer_qw.sv` delays the input sample through two matching stages:

```systemverilog
  nco_qw2 #(.ACC_W(ACC_W), .A(A), .W(W), .QFILE(QFILE)) u_nco (
    .clk(clk), .rst(rst), .en(in_valid), .fcw(fcw),
    .out_valid(lo_valid), .cos_o(lo_cos), .sin_o(lo_sin)
  );

  // align x with the NCO's two pipeline stages (correct even with a sample every clock)
  always_ff @(posedge clk) begin
    if (rst) v1 <= 1'b0;
    else     v1 <= in_valid;
    if (in_valid) x1 <= x;
    if (v1)       x2 <= x1;
  end
```

The rest is `mixer.sv` unchanged, and `ddc_qw.sv` is `ddc.sv` with this mixer. The model needs only `A = 12`, because the quarter-wave table is exactly equal to the full 4,096-entry table (proved at every address in the Part 9 solutions).

Verification: two seeds and an FCW-switch run, **bit-exact**, confirmed independently; lint-clean. One practical point: Yosys also elaborates `nco_qw2` with its default parameter, so the default table file (`qsin_lut.hex`) must be present even though the design uses `qsin12_lut.hex`; without it Yosys stops with `Can not open file 'qsin_lut.hex'`.

### Resources

|  | Original (10-bit table) | Quarter-wave 12-bit table |
| --- | --- | --- |
| Block RAM | 2 RAMB18E1 | **1 RAMB18E1** |
| DSP48E1 | 4 | 4 |
| LUTs | 1,398 | 1,485 |
| Flip-flops | 1,811 | 1,832 |

Four times the table resolution in **half** the block RAM, for about 90 LUTs of symmetry logic and 21 flip-flops of pipeline.

### The measurements

With the model (bit-exact with the RTL for A = 10 and 12), the same stimulus and the same references as section 12.4:

| NCO table bits A | Stored words (quarter-wave) | Mirror image | SQNR vs the NCO's own table | SQNR vs an ideal oscillator |
| --- | --- | --- | --- | --- |
| 10 (original) | 256 | −64.4 dBc | 79.5 dB | **49.1 dB** |
| **12** | 1,024 | **−73.2 dBc** | 79.3 dB | **59.6 dB** |
| 14 | 4,096 | −72.8 dBc | 79.5 dB | 72.7 dB |
| 16 | 16,384 | −72.7 dBc | 79.4 dB | 78.1 dB |

- **The mirror image** drops by about 9 dB with the 12-bit table and then stays put: from there on it is at the noise floor (the noise deliberately added to the input), so the measurement no longer sees the NCO. This is the figure section 12.4 now reports, with the same measurement method stated there (an earlier version of that section gave −69.2 dBc, from a different measurement window; near the noise floor, the method changes the number by a few dB).
- **The SQNR against the NCO's own table** stays at 79.5 dB whatever A is: it measures the arithmetic, which did not change.
- **The SQNR against an ideal oscillator** rises by roughly 6 dB per extra address bit, as Part 9's spur rule predicts, from 49.1 to 78.1 dB.

### When does the NCO stop being the weakest link?

At **about 16 bits** of table address: there, the SQNR against an ideal oscillator (78.1 dB) is within 1.4 dB of the arithmetic's own limit (79.5 dB), so the NCO no longer dominates. With 14 bits it still costs about 7 dB. With the quarter-wave design, 16 bits means 16,384 stored words: 16 RAMB18E1, a real cost. In practice one would stop at 14 bits (4 RAMB18E1) or add phase dithering (a small random value added to the phase before the table) to spread the spurs into noise instead.

### The next weakest link

The 79.5 dB of the arithmetic, broken down by applying each rounding alone to the floating-point chain:

| Rounding applied alone | SQNR |
| --- | --- |
| Mixer output to Q1.15 | 94.3 dB |
| CIC output to Q1.15 | **83.8 dB** |
| Final FIR output to Q1.15 | **81.6 dB** |
| All together (the RTL) | 79.5 dB |

The next weakest link is the **16-bit word length after the CIC and at the output**. The reason is the signal level: the wanted tone is only 0.15 of full scale (−16.5 dBFS), because the input also carries two interferers of the same size that the filters remove. Its 16-bit words therefore carry about 13 useful bits. The cures are wider words between the stages (the FIR's DSP block accepts 18 or even 25 bits at no extra cost) or a gain stage after the filtering, which is how real receivers handle it (automatic gain control).

## Exercise 3: one sample per clock

### What has to change

At one input per clock, the CIC produces an output **every 8 clocks**, and the decimate-by-2 FIR must produce one output from 31 taps **every 16 clocks**. The serial FIR fails twice over: it needs 32 cycles per output, and it refuses inputs (`in_ready` low) while computing, so a CIC output arriving meanwhile is lost. The original passes at `+GAP=4` and fails at `+GAP=1`:

```text
original ddc, GAP=1: FATAL: tb_ddc2.sv:23: OVERRUN: a sample was lost between the CIC and the FIR
original ddc, GAP=4: PASS: 2048 complex outputs bit-exact, 131109 clock cycles
```

### The new FIR: four MACs, always ready

`fir_decim4.sv` uses **P = 4 MACs**, each handling 8 taps (31 padded to 32, the last coefficient being zero), so one output takes **8 cycles**. Its delay line accepts a sample in **every** cycle (`in_ready = 1`). That works because of a timing argument:

- A computation starts when the second sample of a pair arrives, and reads taps for 8 cycles.
- The next sample arrives at least 8 clocks later (the CIC's output spacing), so it shifts the delay line exactly at the edge where the last tap read is captured. Non-blocking assignments make the MAC receive the old value.
- The next computation starts 16 clocks later: no overlap.

```systemverilog
      if (in_valid) begin
        taps[0] <= x;
        for (int i = 1; i < NT; i++) taps[i] <= taps[i-1];
        phase <= (phase == MW'(M - 1)) ? '0 : phase + 1'b1;
      end
      if (in_valid && phase == MW'(M - 1)) begin run <= 1'b1;  k <= '0; end   // M-th sample: compute
      else if (run) begin
        k <= k + 1'b1;
        if (k == KW'(NP - 1)) run <= 1'b0;
      end
```

The four MACs are the exact-accumulator `mac_acc` of the Part 7 solutions; MAC p reads tap p·8 + k. Their four exact sums are added and rounded **once**, which keeps the result bit-exact with the single-MAC filter (rounding each partial sum would not be, as Part 7, Exercise 5 measured):

```systemverilog
  for (genvar p = 0; p < P; p++) begin : g_mac
    logic [TW-1:0] ti;
    assign ti = TW'(p * NP) + TW'(k);
    mac_acc #(.A_W(XW), .B_W(CW), .ACC_W(ACC_W)) u_mac (
      .clk(clk), .rst(rst), .in_valid(run), .first(k == '0), .last(k == KW'(NP - 1)),
      .a(taps[ti]), .b(fir_coef(32'(ti))), .acc_valid(av[p]), .acc(acc[p]));
  end
```

The timing rule is also checked in simulation (inside `` `ifndef SYNTHESIS ``): an input arriving during a computation, except in its last cycle, raises an error.

### The overrun analysis, updated

|  | Original | One sample per clock |
| --- | --- | --- |
| CIC output spacing at GAP = g | 8g clocks | 8 clocks at g = 1 |
| FIR work per output | 32 cycles, input refused | 8 cycles, input always accepted |
| Condition | 8g > 31: **g ≥ 4** | 8 ≥ 8: **g ≥ 1** |

An overrun is now impossible, because the FIR never refuses a sample; the condition that remains is the timing rule above, which the CIC's decimation by 8 guarantees for any input rate up to one sample per clock.

### The proof

The testbench got a `+JIT=0` option, so that `+GAP=1` means exactly one sample every clock (by default it adds 0 to 2 random clocks). `ddc_fast.sv`, `ddc.sv` with `fir_decim4`:

```text
PASS: 2048 complex outputs bit-exact, 32785 clock cycles
independent check: PASS (2048 outputs)
```

Three seeds passed like this, plus a run with random gaps. 32,768 input samples in 32,785 clock cycles: **one per clock**, four times the original's maximum rate (one sample per 4 clocks). Lint-clean.

### What it costs

|  | Original `ddc.sv` | `ddc_fast.sv` |
| --- | --- | --- |
| Input rate at 100 MHz | 25 MS/s (GAP ≥ 4) | **100 MS/s** |
| DSP48E1 | 4 | 10 |
| RAMB18E1 | 2 | 2 |
| LUTs | 1,398 | 1,593 |
| Flip-flops | 1,811 | 1,906 |

Four times the throughput for 6 more DSP blocks (2 for the mixer as before, now 4 MACs per channel instead of 1) and about 200 LUTs. The symmetric form (Part 7) could halve the multipliers again: 15 pre-added pairs plus the center tap are 16 products, which 2 MACs per channel would also finish in 8 cycles.

## Exercise 4: a programmable bandwidth

### The CIC with a run-time factor

`cic_decim_var.sv` takes `rsel` (0, 1, 2 for R = 4, 8, 16):

- **Register width for the largest R**: 16 + 5 × log₂ 16 = **36 bits**. A smaller R needs fewer bits, but extra bits do no harm: the CIC's wrap-around arithmetic gives the same final result in any width at least as large as needed (Part 10), so the same registers serve all three factors, and the model for each R is still Part 10's `cic_decim_golden(x, R, 5)`.
- **The counter** compares with R − 1, chosen by `rsel`.
- **The gain** R⁵ = 2¹⁰, 2¹⁵ or 2²⁰ is removed by one of three rounding shifts, three `requant` instances with 10, 15 or 20 extra fractional bits, and a multiplexer:

```systemverilog
  // the gain: 2**(2 NS), 2**(3 NS) or 2**(4 NS)
  logic signed [XW-1:0] y4, y8, y16, y_c;
  logic                 o4, o8, o16;
  requant #(.IN_W(W), .IN_F(XF + 2 * NS), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1)) u_r4  (.din(c[NS]), .dout(y4),  .ovf(o4));
  requant #(.IN_W(W), .IN_F(XF + 3 * NS), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1)) u_r8  (.din(c[NS]), .dout(y8),  .ovf(o8));
  requant #(.IN_W(W), .IN_F(XF + 4 * NS), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1)) u_r16 (.din(c[NS]), .dout(y16), .ovf(o16));
  wire unused = o4 | o8 | o16;
  always_comb case (rsel)
    2'd0:    y_c = y4;
    2'd1:    y_c = y8;
    default: y_c = y16;
  endcase
```

`rsel` may only change while `rst` is high: switching R on the fly would leave the integrators and combs holding a state that belongs to the old factor, and the FIR's delay line full of samples at the old rate.

### The FIR with three coefficient sets

The compensation filter depends on R, because the CIC's droop does. The design of Part 12 carries over: at the CIC's output rate, the passband edge (0.16) and the stopband edge (0.34) are the same for every R, but the target 1/|H\_CIC| changes slightly with R. The three sets therefore differ: the R = 4 set differs from R = 8 in all 31 coefficients, and the R = 16 set in 27. They are generated into one ROM file, `fir_coefs3.svh`, addressed by `cs × 32 + k`, and `fir_decim_sel.sv` is `fir_decim.sv` reading `fir_coef3(sel, k)`. (Lint caught one detail: the function's argument was first called `sel`, like the module port, which Verilator reports as `VARHIDDEN`; it is now `cs`.)

The output bandwidth scales with R: at 20 MS/s in, R = 4, 8 and 16 give output rates of 2.5, 1.25 and 0.625 MS/s and passbands of ±0.8, ±0.4 and ±0.2 MHz.

### The rate rule, now depending on R

The serial FIR is busy for 31 clocks after it starts a computation, and the CIC delivers its next output R × GAP clocks later, so the condition is **R × GAP > 31**:

| R | Minimum GAP predicted | GAP one less | GAP at the minimum |
| --- | --- | --- | --- |
| 4 | 8 | `OVERRUN` at GAP = 7 | `PASS: 4096 complex outputs bit-exact` |
| 8 | 4 | `OVERRUN` at GAP = 3 | `PASS: 2048 complex outputs bit-exact` |
| 16 | 2 | `OVERRUN` at GAP = 1 | `PASS: 1024 complex outputs bit-exact` |

Every boundary is exactly where the rule puts it. Two seeds per factor with random gaps also passed, confirmed by the independent check. The design is lint-clean, and it synthesizes to 4 DSP48E1, 2 RAMB18E1, 1,599 LUTs and 1,913 flip-flops: about 200 LUTs and 100 flip-flops more than the fixed-R design, for the wider CIC registers, the three gain shifts and the larger coefficient ROM.

Combined with Exercise 3's four-MAC FIR, R = 8 and 16 would run at one sample per clock. R = 4 would not: its CIC outputs come every 4 clocks, so the FIR would need to finish in 4 cycles, that is 8 MACs per channel.

## The projects: where to start

The projects are open-ended, so instead of full solutions, here is what each needs, what already exists from the course and its solutions, and the first measurement that tells you it works.

### Project A: an FM receiver

**What exists.** The vectoring CORDIC with guard bits (Part 9 solutions, Exercise 4): with G = 8 it gives the angle to about 0.003°, and the same solution already demodulated an FM test signal in Python with a correlation of 1.000000. The DDC is the front end.

**The steps:**

1. **The test signal**: an FM carrier at, say, 5.0 MHz in the 20 MS/s input, whose phase is the running sum of 2π × deviation × audio. Keep the deviation, plus the audio bandwidth, inside the DDC's ±0.4 MHz passband: for example a deviation of ±75 kHz, as in broadcast FM, with audio up to 15 kHz.
2. **The RTL**: `cordic_vec` after the DDC's output (I to x, Q to y), then a subtractor: the phase difference between consecutive outputs, in binary-angle units, **wrapping naturally modulo 2²⁰**, which is exactly the modulo-2π the formula needs. The difference is the instantaneous frequency.
3. **The model**: `ddc_lib.golden()` followed by the vectoring model of the Part 9 solutions and `np.diff` with the same wrap; check bit-exactly as always.
4. **Listening**: the difference arrives at 1.25 MS/s; low-pass filter and decimate it to 48 kHz in Python (`scipy.signal.resample_poly(audio, 24, 625)` gives exactly 48 kHz), scale it, and write it with `scipy.io.wavfile.write("fm.wav", 48000, audio.astype(np.int16))`.

**First measurement**: a single 1 kHz audio tone. The recovered audio's spectrum should show 1 kHz, and its SNR against the original tone is the receiver's figure of merit.

### Project B: a spectrum analyzer

**What exists.** The DDC (any of the variants above, with `ddc_fast.sv` if the input must run at full rate), the FFT (Part 11, and the block-RAM version of its solutions, which makes a 1,024-point FFT cost one RAMB36E1), and the calibrated `spectrum()` function of the Part 11 solutions, which is the Python reference for the whole analyzer.

**The steps:**

1. **The window**: a small ROM of N Blackman–Harris values in Q1.15, and one multiplier per channel between the DDC and the FFT's input. The window is real and the data complex, so that is two multiplications per sample.
2. **Averaging**: |X\[k\]|² = re² + im² per bin, accumulated over B blocks in a second memory of N words; output the average, or its logarithm in Python. Averaging B blocks lowers the noise floor's fluctuation by √B; it does not lower the floor itself.
3. **Rates**: the DDC delivers 1.25 MS/s, so a 1,024-point block arrives every 820 µs, while even the two-cycle block-RAM FFT needs only 12,288 clocks, 123 µs at 100 MHz. One FFT therefore serves the analyzer with time to spare.
4. **Zoom**: the FCW selects which 0.8 MHz slice of the 10 MHz input band appears in the spectrum: the NCO's frequency is the analyzer's center frequency.

**First measurement**: the Part 12 stimulus, with the NCO at 4.8 MHz; the averaged spectrum should show the wanted tone at +0.2 MHz and the noise floor, with the interferers removed, matching section 12.4's figures.

### Project C: on real hardware

**What exists.** Every DDC variant above synthesizes with Yosys's `synth_xilinx` for the 7-series family and lints clean, and the block RAMs it uses are the standard ones.

**The steps:**

1. **The flow**: for an AMD (Xilinx) 7-series board, either the vendor's Vivado (its free edition covers the smaller 7-series devices) or an open-source flow: Yosys for synthesis and nextpnr for place and route, for the devices it supports. Constrain the clock to 100 MHz and read the timing report: the critical paths are likely to be the CIC's 31-bit adders and the requant saturation logic, which pipelining (Part 7, Exercise 3) can fix.
2. **The test pattern**: store the 32,768-sample stimulus in block RAM with `$readmemh`, play it into the DDC at the chosen rate, and capture the outputs in a second block RAM.
3. **Reading the results**: through the board's UART (the Part 3 transmitter, with the receiver model of its solutions as a reference) or a vendor debug core, then into the same Python analysis.

**First measurement**: the captured outputs must be **bit-identical** to the simulation's `y_actual.txt`. If they are, everything in this course has been confirmed on silicon; if not, the difference points at timing, at the reset, or at the initialization of the memories, the three things simulation cannot fully show.

---

That completes the solutions to Part 12, and to the course. Every exercise in all twelve parts now has a verified solution. Send me your own designs and results whenever you would like them reviewed.
