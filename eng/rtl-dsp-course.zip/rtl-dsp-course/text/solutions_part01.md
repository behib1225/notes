# Verilog & RTL for DSP — Solutions to Part 1

*Markdown export of the online document: https://claude.ai/artifact/SoAi6iJTLVzpQmwxdJuHVL. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the six exercises of Part 1. Try each exercise yourself first, and compare afterwards: a solution you read is learned far less well than one you struggled with. The answers to the "Check your understanding" questions are already in Part 1, directly after each question set.

Your solution does not have to look like these to be correct. Most of these exercises have several good designs. What matters is that yours passes an equally strong testbench and lints cleanly.

**How these solutions were checked.** Every module and testbench below was compiled and run with Icarus Verilog 12.0 (`iverilog -g2012 -Wall`) and linted with Verilator 5.020 (`--lint-only -Wall`). Every result quoted is copied from an actual run. Wherever the input space was small enough, the design was tested **exhaustively**, on every possible input, which is a proof of correctness for combinational logic. Each design was also deliberately broken once to confirm that its testbench can fail.

## Exercise 1: predict the output

The program prints exactly this (Icarus Verilog 12.0):

```text
a 0001
b 10001
c -3 125
d 0
e 1
f 1 1
g 1
```

| Line | Output | Why |
| --- | --- | --- |
| a | `0001` | 10 + 7 = 17 = `10001`. The left-hand side `r4` has 4 bits, so the expression is evaluated in 4 bits and the carry is lost: 17 mod 16 = 1 (rule 2 of section 1.4). |
| b | `10001` | Same sum, but `r5` has 5 bits, so the operands are extended to 5 bits **before** adding and the carry is kept: 17 (rule 1). |
| c | `-3 125` | −6 is `1111_1010`. `>>>` is an arithmetic shift: it copies the sign bit in, giving `1111_1101` = −3. `>>` is a logical shift: it inserts a 0, giving `0111_1101` = 125. |
| d | `0` | `u` is unsigned, so the whole comparison is unsigned (rule 4). −6 is then read as the bit pattern `1111_1010` = 250, and 250 < 1 is false. |
| e | `1` | `$signed(u)` makes both operands signed: −6 < 1 is true. |
| f | `1 1` | `&4'b1111` is the AND of all four bits: 1. `^4'b1011` is the XOR of all bits: three 1s is an odd number, so 1 (odd parity). |
| g | `1` | `&&` is a logical AND: each operand is non-zero, so each is true, and true && true = 1. (The bitwise `4'b0100 & 4'b0010` would have been `0000`.) |

Lines c and d are the dangerous ones in real designs. Line c is why signed DSP data is divided by powers of two with `>>>`, never `>>`. Line d is the signed/unsigned trap of section 1.4 hiding inside a comparison, where it is even harder to spot than in an addition: Verilator reports it as `UNSIGNED: Comparison is constant due to unsigned arithmetic` only when the comparison is with a constant, as in Exercise 5, not here.

## Exercise 2: 2-to-4 decoder with enable

Both versions live in one module so a single testbench can check them against each other and against the specification.

```systemverilog
`timescale 1ns/1ps
// decoder2to4.sv -- 2-to-4 decoder with enable, written two ways
module decoder2to4 (
  input  logic       en,
  input  logic [1:0] a,
  output logic [3:0] y_case,    // version 1: case statement
  output logic [3:0] y_shift    // version 2: one shift
);
  always_comb begin
    y_case = 4'b0000;           // default: no output active (also prevents a latch)
    if (en) begin
      case (a)
        2'd0:    y_case = 4'b0001;
        2'd1:    y_case = 4'b0010;
        2'd2:    y_case = 4'b0100;
        default: y_case = 4'b1000;
      endcase
    end
  end

  assign y_shift = en ? (4'b0001 << a) : 4'b0000;
endmodule
```

The shift version works because shifting `0001` left by `a` places a single 1 at bit position `a`: exactly the decoder's definition. The synthesizer builds the same four AND-style gates for both versions.

### The testbench

The expected output is written straight from the specification ("bit `a` is 1 if enabled"), not by copying either implementation:

```systemverilog
`timescale 1ns/1ps
module tb_decoder2to4;
  logic       en;
  logic [1:0] a;
  logic [3:0] y_case, y_shift, expected;
  int errors = 0;
  decoder2to4 dut (.*);
  initial begin
    for (int i = 0; i < 8; i++) begin
      {en, a} = i[2:0];
      #10;
      expected = '0;
      if (en) expected[a] = 1'b1;          // the specification, written directly
      if (y_case !== expected || y_shift !== expected) begin
        $display("FAIL en=%b a=%0d: case=%b shift=%b expected=%b", en, a, y_case, y_shift, expected);
        errors++;
      end
    end
    if (errors == 0) $display("PASS: all 8 input combinations, both versions");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

Result: `PASS: all 8 input combinations, both versions`, and the design is lint-clean. Since all 8 inputs were tested, this is a complete proof that both versions are correct. As a check that the testbench can fail, one `case` entry was changed (`2'd2` driving `4'b1000`); the testbench reported `FAIL en=1 a=2: case=1000 shift=0100 expected=0100`, so it also tells you which version is wrong.

Two details worth noticing: `expected[a] = 1'b1;` writes one bit at a **variable** position, which is fine in a testbench; and the `case` has a `default`, so even though all four values of `a` are listed, the block remains safe if `a` is ever widened.

## Exercise 3: 4-to-2 priority encoder

```systemverilog
`timescale 1ns/1ps
// prio_enc4.sv -- 4-to-2 priority encoder: the highest-numbered active input wins
module prio_enc4 (
  input  logic [3:0] d,
  output logic [1:0] y,
  output logic       valid
);
  always_comb begin
    if      (d[3]) y = 2'd3;
    else if (d[2]) y = 2'd2;
    else if (d[1]) y = 2'd1;
    else           y = 2'd0;      // d[0] alone, or no input at all
  end

  assign valid = |d;              // reduction OR: any input active
endmodule
```

**Why `if` suits it better than `case`:** a priority encoder is defined by an order of precedence ("bit 3 wins over bit 2, which wins over bit 1"), and an `if / else if` chain expresses exactly that order: the first true condition wins. A `case` on `d` would have to list all 16 input patterns, or use wildcard `casez` items, to say the same thing.

The final `else` assigns `y` on every path, so there is no latch. When no input is active, `y` is `00` and `valid` is 0, as specified; when only `d[0]` is active, `y` is also `00`, and `valid` (1) is what distinguishes the two cases.

### The testbench

The model scans the bits **upward** and keeps the last active one it finds, which is a different algorithm from the design's top-down chain, so the two are unlikely to share a mistake:

```systemverilog
`timescale 1ns/1ps
module tb_prio_enc4;
  logic [3:0] d;
  logic [1:0] y, exp_y;
  logic       valid, exp_valid;
  int errors = 0;
  prio_enc4 dut (.*);
  initial begin
    for (int i = 0; i < 16; i++) begin
      d = i[3:0];
      #10;
      exp_y = 2'd0;  exp_valid = 1'b0;
      for (int k = 0; k < 4; k++)          // scan upward: the last active bit found wins
        if (d[k]) begin exp_y = k[1:0]; exp_valid = 1'b1; end
      if (y !== exp_y || valid !== exp_valid) begin
        $display("FAIL d=%b: y=%0d valid=%b, expected %0d %b", d, y, valid, exp_y, exp_valid);
        errors++;
      end
    end
    if (errors == 0) $display("PASS: all 16 inputs");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

Result: `PASS: all 16 inputs`; lint-clean. With the priority of bits 1 and 2 deliberately swapped, it reported `FAIL d=0110: y=1 valid=1, expected 2 1`: the bug shows up only when two inputs are active at once, which is exactly why exhaustive testing matters here.

**A harmless Icarus message.** Compiling this file, Icarus 12 prints `sorry: constant selects in always_* processes are not currently supported (all bits will be included)`. It means Icarus makes the block sensitive to all of `d`, not just the bits it reads, which for combinational logic gives the same result. The message is about Icarus's internals, not a problem in your design; Verilator reports nothing.

## Exercise 4: saturating adder

```systemverilog
`timescale 1ns/1ps
// sat_add.sv -- signed W-bit adder whose result is clamped to the W-bit range
module sat_add #(
  parameter int W = 8
) (
  input  logic signed [W-1:0] a, b,
  output logic signed [W-1:0] y
);
  localparam logic signed [W-1:0] MAX = {1'b0, {(W-1){1'b1}}};   //  2^(W-1) - 1
  localparam logic signed [W-1:0] MIN = {1'b1, {(W-1){1'b0}}};   // -2^(W-1)

  logic signed [W:0] sum;                       // W+1 bits: the exact sum always fits
  assign sum = {a[W-1], a} + {b[W-1], b};       // sign-extend both, then add

  // The exact sum fits in W bits only if its top two bits are equal.
  // If they differ, the sign of the true sum is sum[W]: negative -> MIN, positive -> MAX.
  assign y = (sum[W] == sum[W-1]) ? sum[W-1:0] : (sum[W] ? MIN : MAX);
endmodule
```

### Why the top two bits detect overflow (Hint 2)

The sum of two W-bit signed numbers always fits in **W + 1** bits, so `sum` is exact. It fits back into **W** bits exactly when its top bit, `sum[W]`, is just a copy of the next bit, `sum[W-1]`: that is what sign extension looks like. If they differ, the true value lies outside the W-bit range:

- `sum[W:W-1]` = `01`: the true sum is positive and too large → saturate to MAX (for W = 8, 127).
- `sum[W:W-1]` = `10`: the true sum is negative and too small → saturate to MIN (−128).

In both cases `sum[W]` is the true sign, which is how the `assign` chooses between MIN and MAX. `MAX` and `MIN` are built with replication, so they are correct for any W.

A first version wrote the same decision as a `case` on `sum[W:W-1]` inside `always_comb`. It was correct, but Icarus printed its harmless `sorry: constant selects` message (see Exercise 3). The `assign` form avoids it and is shorter.

### The testbench

The model computes in 32-bit `int`, which cannot overflow, and clamps explicitly:

```systemverilog
`timescale 1ns/1ps
module tb_sat_add;
  localparam int W = 8;
  logic signed [W-1:0] a, b, y;
  int errors = 0, tests = 0;
  sat_add #(.W(W)) dut (.*);

  task automatic check(input int ta, tb);
    int exact, expected;
    a = ta[W-1:0]; b = tb[W-1:0];
    #1;
    exact = int'(a) + int'(b);                  // int arithmetic: no overflow possible
    if      (exact >  127) expected =  127;
    else if (exact < -128) expected = -128;
    else                   expected = exact;
    tests++;
    if (int'(y) != expected) begin
      if (errors < 5) $display("FAIL: %0d + %0d -> %0d, expected %0d", a, b, y, expected);
      errors++;
    end
  endtask

  initial begin
    check(127, 1);   check(-128, -1);  check(127, 127);
    check(-128, -128); check(-1, 1);   check(0, 0);  check(127, -128);
    repeat (2000) check($urandom_range(0, 255) - 128, $urandom_range(0, 255) - 128);
    if (errors == 0) $display("PASS: %0d cases", tests);
    else             $display("FAILED: %0d of %0d", errors, tests);
    $finish;
  end
endmodule
```

`int'(a)` converts the signed 8-bit value to a signed `int`, with sign extension, because `a` is declared signed. The random operands come from `$urandom_range(0, 255) - 128`, which gives uniform values from −128 to 127.

Results:

- `PASS: 2007 cases` (7 corners plus 2,000 random pairs).
- An extra **exhaustive** run over all 65,536 pairs of 8-bit inputs reported **0 errors**.
- Lint-clean for W = 8 and for W = 16 (`verilator -GW=16`), which checks that the parameterization is right.
- With positive saturation replaced by wrap-around, the testbench reported `FAIL: 127 + 1 -> -128, expected 127` and `FAIL: 127 + 127 -> -2, expected 127`: exactly the audio "click" of the exercise's introduction.

## Exercise 5: find the three bugs

### Step 1: a testbench first

With only 256 possible inputs, test them all. The expected value is |x|, clamped to 127:

```systemverilog
`timescale 1ns/1ps
module tb_abs_sat;
  logic signed [7:0] x, y;
  int expected, errors = 0;
  abs_sat dut (.*);
  initial begin
    for (int i = -128; i < 128; i++) begin      // exhaustive: all 256 inputs
      x = i[7:0];
      #1;
      expected = (i < 0) ? -i : i;
      if (expected > 127) expected = 127;
      if (y !== 8'(expected)) begin
        if (errors < 5) $display("FAIL x=%0d: y=%0d, expected %0d", x, y, expected);
        errors++;
      end
    end
    if (errors == 0) $display("PASS: all 256 inputs");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

On the original module, the very first lines of output were:

```text
FAIL x=-128: y=x, expected 127
FAIL x=-127: y=x, expected 127
FAIL x=-126: y=x, expected 126
```

The output is `x` for **every** input: nothing ever assigns `y`.

### Step 2: what the tools find

| Stage | Tool message | Bug |
| --- | --- | --- |
| Original | Verilator: `UNSIGNED: Comparison is constant due to unsigned arithmetic` | **Bug 1** |
| Bug 1 fixed | Verilator: `LATCH: Latch inferred for signal 'y' (not all control paths of combinational always assign a value)` | **Bug 2** |
| Bugs 1 and 2 fixed | Lint clean, but the testbench: `FAIL x=-128: y=-128, expected 127` | **Bug 3** |

**Bug 1: `x < 8'd0` compares a signed value with an unsigned literal.** With one unsigned operand the comparison becomes unsigned (Part 1, section 1.4, rule 4), and nothing is less than unsigned 0, so the condition is always false. That is why Verilator says the comparison is constant. Rule broken: *mixing signed and unsigned makes everything unsigned*. Fix: `x < 8'sd0` (or `x < 0`, since an unsized literal like `0` is signed).

**Bug 2: no `else`.** For non-negative inputs `y` is never assigned, so the hardware must remember its old value: a latch. Rule broken: *in `always_comb`, assign every output on every path* (section 1.5). Before bug 1 was fixed, Verilator could not see this one, because the only assigning branch was unreachable.

**Bug 3: −128 has no positive counterpart in 8 bits.** −(−128) = +128 wraps back to −128. The specification asks for saturation to +127. No tool can find this, because the code is perfectly legal; only a test of the corner case does. Rule broken: *two's complement is asymmetric; the most negative value needs special handling* (sections 1.4 and Exercise 4).

### The fixed module

```systemverilog
`timescale 1ns/1ps
// abs_sat.sv -- |x| of a signed 8-bit input, saturated to +127
module abs_sat (
  input  logic signed [7:0] x,
  output logic signed [7:0] y   // |x|, saturated to +127
);
  always_comb begin
    if (x == -8'sd128)          // bug 3: +128 does not fit, so saturate
      y = 8'sd127;
    else if (x < 8'sd0)         // bug 1: compare with a SIGNED zero
      y = -x;
    else                        // bug 2: assign y on every path (no latch)
      y = x;
  end
endmodule
```

Result: `PASS: all 256 inputs`, lint-clean. Because the test is exhaustive, this proves the module correct.

The lesson of this exercise is the order in which the bugs appeared: the linter found two of them, but each only after the previous one was fixed, and the third was invisible to every tool. **Lint first, fix, lint again, and test the corners regardless.**

## Exercise 6: adder-subtractor with overflow flag

The design is Mano's adder-subtractor, generalized with a parameter and built from the `full_adder` of section 1.3.

```systemverilog
`timescale 1ns/1ps
// addsub.sv -- N-bit adder-subtractor with signed overflow flag (Mano, Chapter 4)
//   m = 0: s = a + b      m = 1: s = a - b = a + ~b + 1
module addsub #(
  parameter int N = 8
) (
  input  logic [N-1:0] a, b,
  input  logic         m,          // 0 = add, 1 = subtract
  output logic [N-1:0] s,
  output logic         c,          // carry out of the MSB
  output logic         v           // signed (two's-complement) overflow
);
  logic [N:0]   carry;             // carry[i] = carry into bit i
  logic [N-1:0] bx;                // b, inverted when subtracting

  assign carry[0] = m;             // +1 for the two's complement when subtracting
  assign bx       = b ^ {N{m}};    // XOR each bit of b with m

  for (genvar i = 0; i < N; i++) begin : g_bit
    full_adder fa (.a(a[i]), .b(bx[i]), .cin(carry[i]), .sum(s[i]), .cout(carry[i+1]));
  end

  assign c = carry[N];
  assign v = carry[N] ^ carry[N-1];   // carry into MSB differs from carry out: overflow
endmodule
```

How it works:

- **Subtraction is addition of the two's complement.** a − b = a + (\~b + 1). The XOR gates invert every bit of b when m = 1 (`b ^ {N{m}}` replicates m to N bits), and m itself is the carry-in that supplies the +1. When m = 0, the XORs pass b unchanged and the carry-in is 0.
- **The overflow flag** is the XOR of the carry into the most significant bit and the carry out of it. Signed overflow happens exactly when two operands of the same sign produce a result of the other sign, and in the adder that shows up as those two carries disagreeing.
- **The carry chain must be visible** for `v`, which is why this design is structural: with `assign {c, s} = a + bx + m;` the internal carry into the MSB would not be available.

### The testbench

With 8-bit operands there are 65,536 pairs, so the test covers all of them, for both addition and subtraction:

```systemverilog
`timescale 1ns/1ps
module tb_addsub;
  localparam int N = 8;
  logic [N-1:0] a, b, s;
  logic         m, c, v;
  int errors = 0, tests = 0;
  addsub #(.N(N)) dut (.*);

  task automatic check(input int ta, tb, input logic tm);
    int sa, sb, exact; logic exp_v; logic [N-1:0] exp_s;
    a = ta[N-1:0]; b = tb[N-1:0]; m = tm;
    #1;
    sa = int'($signed(a)); sb = int'($signed(b));        // the operands as signed numbers
    exact = tm ? sa - sb : sa + sb;                      // exact result in int
    exp_s = exact[N-1:0];                                // the N-bit result wraps
    exp_v = (exact > 127) || (exact < -128);             // overflow: outside -128..127
    tests++;
    if (s !== exp_s || v !== exp_v) begin
      if (errors < 5) $display("FAIL %0d %s %0d: s=%0d v=%b, expected s=%0d v=%b",
                               sa, tm ? "-" : "+", sb, $signed(s), v, $signed(exp_s), exp_v);
      errors++;
    end
  endtask

  initial begin
    for (int i = -128; i < 128; i++)                     // exhaustive: 2 x 65,536 cases
      for (int j = -128; j < 128; j++) begin
        check(i, j, 1'b0);
        check(i, j, 1'b1);
      end
    if (errors == 0) $display("PASS: %0d cases (all pairs, add and subtract)", tests);
    else             $display("FAILED: %0d of %0d", errors, tests);
    $finish;
  end
endmodule
```

Compile it with the full adder: `iverilog -g2012 -Wall -o sim full_adder.sv addsub.sv tb_addsub.sv`.

Results:

- `PASS: 131072 cases (all pairs, add and subtract)`: a complete proof for N = 8.
- Lint-clean with `verilator --lint-only -Wall --top-module addsub addsub.sv full_adder.sv`.
- A common mistake, using the carry-out itself as the overflow flag (`assign v = carry[N];`), was caught at once: `FAIL -128 - -128: s=0 v=1, expected s=0 v=0`. The carry-out indicates **unsigned** overflow (or, when subtracting, the absence of a borrow), not signed overflow.

That last point was also checked: when subtracting, `c` = 1 exactly when a ≥ b as unsigned numbers, over all 65,536 pairs, with 0 errors. So the same hardware gives an unsigned comparison for free, which is how processors implement "branch if lower".

---

That completes Part 1. Send me your own solutions if you would like them reviewed, including any that differ from these: alternative correct designs are worth discussing.
