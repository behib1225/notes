# Verilog & RTL for DSP — Solutions to Part 6

*Markdown export of the online document: https://claude.ai/artifact/6GdbjPGUos5VvXpbNhSHUw. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the five exercises of Part 6. Try each one first; the "Check your understanding" answers are in Part 6 itself.

Every solution uses the Part 6 library `fixedpoint.py` (`quantize`, `requant`, `to_real`) for its Python model and `requant.sv` for rounding in hardware, exactly as the exercises ask. The RTL exercises (2, 3 and 5) each have a bit-exact checker in the Part 4 style.

**How these solutions were checked.** Everything was run with Python 3, NumPy and SciPy, Icarus Verilog 12.0 (`-g2012 -Wall`), Verilator 5.020 (`--lint-only -Wall`) and Yosys 0.33. Every number is copied from an actual run.

Two results came out differently from what one might expect, and both are kept, because they are real:

- In Exercise 2, rounding with `requant` (round half up) reduces the mean error from −7/16 to **+1/16** of an LSB, not to zero; convergent rounding brings it to zero.
- In Exercise 5, Yosys does not need anything special for a 19-bit coefficient. It places the coefficient on the DSP block's 25-bit A port, so the design still uses one DSP48E1; a second block is needed only above 25 bits.

## Exercise 1: Q-format drills

Each answer was worked by hand and then checked with `fixedpoint.py`.

### 1. Converting to Q1.11 with rounding

Q1.11 has 12 bits, 11 of them fractional, so the integer is round(x × 2¹¹) = round(x × 2048), using round half up (`quantize(x, 12, 11)`, which computes ⌊x · 2048 + ½⌋). Negative values are stored in 12-bit two's complement: 4096 + q.

| x | x × 2048 | Integer q | 12-bit hex | Value stored | Error |
| --- | --- | --- | --- | --- | --- |
| 0.3 | 614.4 | **614** | **266** | 0.299805 | −0.000195 |
| −0.3 | −614.4 | **−614** | **D9A** | −0.299805 | +0.000195 |
| 0.999 | 2045.952 | **2046** | **7FE** | 0.999023 | +0.000023 |
| −0.0001 | −0.2048 | **0** | **000** | 0 | +0.000100 |

−0.0001 is smaller than half an LSB (2⁻¹² ≈ 0.000244), so it rounds to zero: values that small simply cannot be represented in Q1.11. For −0.3: 4096 − 614 = 3482 = `0xD9A`. Every error is at most half an LSB (2⁻¹² = 0.000244), as rounding guarantees.

### 2. Q1.23 audio

- **Resolution**: one LSB is 2⁻²³ ≈ **1.19 × 10⁻⁷** of full scale.
- **SQNR for a full-scale sine**: 6.02 × 24 + 1.76 = **146.2 dB** (all 24 bits count, including the sign). A simulation in Python, quantizing a full-scale sine to 24 bits with rounding, measured **146.27 dB**.

That is far beyond what any analog circuit around it can achieve, which is why 24-bit audio is limited in practice by its analog electronics, not by its number format.

### 3. Multiplying Q1.11 by Q3.13

- Widths: 12 + 16 = **28 bits**.
- Fractional bits: 11 + 13 = **24**, so the product is **Q4.24**.

The ranges are \[−1, 1) and \[−4, 4). The four extreme products, computed as integers, are:

| Product | Value |
| --- | --- |
| (−1) × (−4) | **+4.0** |
| (−1) × (+3.99988) | −3.99988 |
| (+0.99951) × (−4) | −3.99805 |
| (+0.99951) × (+3.99988) | +3.99792 |

A 27-bit Q3.24 product would cover \[−4, +4), which holds every one of them **except +4.0**: the integer 2²⁶ = 67,108,864 is exactly one beyond the 27-bit maximum. So the top bit of the 28-bit product is needed only for one input pair: **the most negative value times the most negative value**, (−1) × (−4). This is the general version of section 6.3's −1 × −1 trap.

### 4. Adding Q1.15 and Q4.12

The binary points must be aligned before adding (section 6.3):

1. **Align**: give the Q4.12 value three more fractional bits by shifting it left by 3, appending zeros: Q4.12 → **Q4.15** (19 bits). This is exact; no information is lost.
2. **Extend**: sign-extend the Q1.15 value to Q4.15 (copy its sign bit into three new integer bits).
3. **Add**: the sum of \[−1, 1) and \[−8, 8) lies in \[−9, 9), which needs one more integer bit than either operand: **Q5.15, 20 bits** is the safe format.

Checked in Python: 0.99997 (32,767 in Q1.15) plus −7.5 (−30,720 in Q4.12, which becomes −245,760 after the shift) gives −212,993 in Q5.15, which is −6.500031: exactly the real sum.

## Exercise 2: fix the moving average's rounding

### The RTL change

The only change from Part 2's `moving_avg8` is the division. The 19-bit sum is read as a fixed-point number with **3 fractional bits** (sum / 8), and `requant` drops those 3 bits with rounding and saturation:

```systemverilog
  // sum / 8: read the sum as a number with 3 fractional bits and drop them with rounding
  logic signed [W-1:0] avg;
  logic                unused_ovf;
  requant #(.IN_W(W+3), .IN_F(3), .OUT_W(W), .OUT_F(0), .RND(1), .SAT(1'b1))
    u_rq (.din(sum), .dout(avg), .ovf(unused_ovf));
```

and the output register takes `y <= avg;` instead of `y <= W'(sum >>> 3);`. Here the output is counted in input LSBs (OUT\_F = 0); with Q1.15 samples it would be IN\_F = 18 and OUT\_F = 15, which drops the same 3 bits.

### The model

```python
def moving_sum(x):
    return np.convolve(np.asarray(x, np.int64), np.ones(8, dtype=np.int64))[: len(x)]

def golden(x):        # new design: sum with 3 fractional bits -> integer, round half up, saturate
    return requant(moving_sum(x), 3, W, 0, "round", "saturate")

def golden_old(x):    # old design: arithmetic shift (floor)
    return moving_sum(x) >> 3
```

### Verification and measured errors

Both the old and the new RTL were run on the same 100,000 random full-scale samples (plus long runs at ±full scale). Each matched its own model bit-exactly. Then each output was compared with the **exact** average, the sum divided by 8 in floating point:

| Design | Bit-exact | Mean error | Range of errors | RMS error |
| --- | --- | --- | --- | --- |
| Old (`>>> 3`, floor) | PASS, 100,000 samples | **−0.4375 LSB** | −0.875 to 0 | 0.523 LSB |
| New (`requant`, round half up) | PASS, 100,000 samples | **+0.0627 LSB** | −0.375 to +0.500 | 0.293 LSB |

The old design's mean error is exactly the **−7/16 LSB** predicted in section 6.2. Rounding removes almost all of it, and nearly halves the RMS error, but the new mean is **+1/16 LSB**, not zero. The table of all eight possible remainders shows why:

| Dropped bits (sum mod 8) | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Floor error (LSB) | 0 | −⅛ | −²⁄₈ | −⅜ | −⁴⁄₈ | −⅝ | −⁶⁄₈ | −⅞ |
| Round-half-up error (LSB) | 0 | −⅛ | −²⁄₈ | −⅜ | **+⁴⁄₈** | +⅜ | +²⁄₈ | +⅛ |

With rounding, everything cancels except the tie: a remainder of exactly 4 (one half) is always rounded **up**, adding +½ one time in eight, a mean of +1/16. **Convergent** rounding (round half to even, `RND = 2`) rounds ties up half the time and down half the time; computed with `requant(..., "convergent")` on the same data, its mean error is **0.0006 LSB**, zero within the statistics.

### Can the rounded result ever need saturation?

**No.** Proof: every input lies between −32,768 and +32,767, so the sum of eight lies between 8 × (−32,768) = −262,144 and 8 × 32,767 = 262,136. Dividing by 8, the exact average lies between −32,768 and +32,767. Rounding a number to the nearest integer can never move it past an integer bound it already respects: a value ≤ 32,767 rounds to at most 32,767, and a value ≥ −32,768 rounds to at least −32,768. So the result always fits in 16 bits.

The extremes, checked with `requant` in **wrap** mode (no saturation at all):

| Sum | Sum / 8 | Rounded |
| --- | --- | --- |
| 262,136 (8 × 32,767) | 32,767.0 | 32,767 |
| 262,135 | 32,766.875 | 32,767 |
| −262,144 (8 × −32,768) | −32,768.0 | −32,768 |
| −262,143 | −32,767.875 | −32,768 |

None wraps (the new module is also lint-clean with \`requant\` in its hierarchy), and the 100,000-sample test reached exactly +32,767 and −32,768 without saturating. The `SAT = 1` setting is therefore harmless but unnecessary here; it matters in filters with gains above 1 (Σ|h| > 1), such as the filters of section 6.6 and Part 7.

## Exercise 3: a complex multiplier

### The RTL

```systemverilog
`timescale 1ns/1ps
// cmult.sv -- pipelined complex multiplier: (a + jb)(c + jd) = (ac - bd) + j(ad + bc)
// Q1.15 inputs, Q1.15 outputs (round half up, saturate). Products kept exact until the end.
// Pipeline: input registers -> product registers -> sum registers -> requant + output registers.
module cmult #(
  parameter int W = 16, F = 15
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] a, b, c, d,         // (a + jb) and (c + jd)
  output logic                out_valid,
  output logic signed [W-1:0] re, im,
  output logic                ovf                 // re or im saturated
);
  localparam int P_W = 2 * W;                     // each product: Q2.30
  localparam int S_W = P_W + 1;                   // sum or difference of two products: Q3.30

  logic signed [W-1:0]   a_r, b_r, c_r, d_r;      // stage 1
  logic signed [P_W-1:0] ac, bd, ad, bc;          // stage 2
  logic signed [S_W-1:0] s_re, s_im;              // stage 3
  logic                  v1, v2, v3;

  always_ff @(posedge clk) begin
    if (rst) {v1, v2, v3} <= '0;
    else     {v1, v2, v3} <= {in_valid, v1, v2};
    a_r <= a;  b_r <= b;  c_r <= c;  d_r <= d;
    ac <= a_r * c_r;  bd <= b_r * d_r;  ad <= a_r * d_r;  bc <= b_r * c_r;
    s_re <= S_W'(ac) - S_W'(bd);
    s_im <= S_W'(ad) + S_W'(bc);
  end

  logic signed [W-1:0] re_c, im_c;
  logic                ovf_re, ovf_im;
  requant #(.IN_W(S_W), .IN_F(2*F), .OUT_W(W), .OUT_F(F), .RND(1), .SAT(1'b1))
    u_re (.din(s_re), .dout(re_c), .ovf(ovf_re));
  requant #(.IN_W(S_W), .IN_F(2*F), .OUT_W(W), .OUT_F(F), .RND(1), .SAT(1'b1))
    u_im (.din(s_im), .dout(im_c), .ovf(ovf_im));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= v3;
    if (v3) begin re <= re_c;  im <= im_c;  ovf <= ovf_re | ovf_im; end
  end
endmodule
```

Widths: each product of two Q1.15 values is 32 bits, Q2.30. A sum or difference of two such products needs one more bit, **33 bits, Q3.30**. Only `requant` rounds, once per output, from 30 to 15 fractional bits. The latency is 4 cycles, and as in the MAC, only the valid bits are reset.

### The model and the verification

```python
def model(a, b, c, d):
    """Integer arithmetic exactly as the hardware: exact products, exact sums, one rounding each."""
    a, b, c, d = (np.asarray(v, np.int64) for v in (a, b, c, d))
    s_re = a * c - b * d                          # Q3.30
    s_im = a * d + b * c
    return (requant(s_re, 30, 16, 15, "round", "saturate"),
            requant(s_im, 30, 16, 15, "round", "saturate"))
```

The testbench reads four hex words per line, applies them with random idle cycles, and writes `re im` for every valid output. With 5,000 inputs (eight corner cases plus random full-scale values): `PASS: 5000 complex products bit-exact`, and 384 of them saturated. The module is lint-clean.

### The corner cases, and which inputs saturate

| Inputs | Exact product | re | im |
| --- | --- | --- | --- |
| (−1 − j)(−1 − j) | 0 + **2**j | 0 | **32,767** (saturated) |
| (−1)(−1) | **+1** | **32,767** (saturated) | 0 |
| (≈1 + ≈j)² | 0 + 1.99988j | 0 | 32,767 (saturated) |
| (≈1)(≈1) | 0.99994 | 32,766 | 0 |
| (≈j)(≈j) | −0.99994 | −32,766 | 0 |
| (−j)(−j) | **−1** | **−32,768** (exact) | 0 |
| ((1 + j)/√2)((1 − j)/√2) | 0.99996 | 32,767 | 0 |

A result saturates when its **real or imaginary part** falls outside \[−1, 1). Two separate effects cause it:

1. **+1 is not representable.** (−1)(−1) = +1 exactly, one LSB above the largest Q1.15 value, the −1 × −1 trap of section 6.3. Notice the asymmetry: (−j)(−j) = −1 is representable, so it does **not** saturate.
2. **Complex magnitudes grow.** A complex number whose parts are both full scale has magnitude up to √2, so a product can reach magnitude 2: (−1 − j)² = 2j. With random full-scale parts, the real or imaginary part of the product exceeds ±1 quite often: 384 times in 5,000 here. In practice, complex signals are scaled so that their **magnitude** stays below 1 (for example, a unit-magnitude oscillator times a signal of magnitude below 1), which keeps both parts of the product in range.

### What Yosys builds

With `synth_xilinx -family xc7 -flatten`: **4 DSP48E1**, one per real multiplication, with their A, B and M registers in use, plus 70 flip-flops and about 95 LUTs. The DSP configuration shows one more detail: three of the four DSP blocks only multiply (OPMODE `0x05`, P = M), while one has OPMODE `0x15` (P = PCIN + M) with its P register enabled. That block adds the product of its neighbor through the dedicated **cascade** connection, so one of the two additions costs no fabric logic at all.

### Gauss's three-multiplication trick

Define three products:

```latex
k_1 = c\,(a + b), \qquad k_2 = a\,(d - c), \qquad k_3 = b\,(c + d)
```

Then

```latex
\mathrm{Re} = k_1 - k_3 = ac - bd, \qquad \mathrm{Im} = k_1 + k_2 = ad + bc
```

Expanding: k₁ − k₃ = ac + bc − bc − bd = ac − bd, and k₁ + k₂ = ac + bc + ad − ac = ad + bc. Checked in integer arithmetic on 200,000 random inputs plus the corners: identical to the four-multiplication results in every case.

What it costs:

|  | Four multiplications | Gauss |
| --- | --- | --- |
| Multipliers | 4 (16 × 16) | **3** (16 × 17) |
| Adders and subtractors | 2 | **5**: three before the multipliers, two after |
| Pre-sum widths | — | **17 bits** (a + b, d − c, c + d) |
| Product widths | 32 bits | **up to 33 bits** (the measured ranges of k₁ and k₃ reach 2³¹) |
| Pipeline | 1 multiplier stage | an extra pre-add stage |

The bit growth is the subtle cost: each pre-sum needs one more bit, so the multipliers become 16 × 17, and the intermediate products are wider than the final results need. On a DSP48E1, the pre-additions are free: the block's **pre-adder** (the D input) computes a sum of two values in front of the 25-bit multiplier input. So the trick saves one DSP block per complex multiplier at little cost. In an ASIC, where a multiplier is much larger than an adder, removing one of four multipliers is usually worth the extra adders. Where the multipliers are free (spare DSP blocks), the four-multiplication form is simpler and has less latency.

## Exercise 4: a word-width study

### The method

The script follows section 6.6 exactly. For each coefficient width W, the coefficients are quantized two ways: **plain** (Q1.(W−1), F = W − 1) and **scaled** to fill the word. Two measures are taken:

- **Stopband attenuation** of the quantized coefficients, here measured from **0.075 cycles per sample** upward (the filter's cutoff is 0.05; its transition band ends about 0.025 later, half as wide as the 32-tap filter's because the filter is twice as long).
- **Output SNR**: the full fixed-point filter (16-bit Q1.15 input, exact accumulation, output rounded to Q1.15 and saturated) against the floating-point filter, on 200,000 uniformly distributed random samples.

```python
h = firwin(64, 0.1)                       # cutoff 0.1 x Nyquist = 0.05 cycles/sample
F_STOP = 0.075                            # stopband measured from here
x = quantize(rng.uniform(-1, 1, 200_000), 16, 15)       # 16-bit input, Q1.15
y_float = np.convolve(to_real(x, 15), h)[: len(x)]       # ideal: float coefficients, exact arithmetic

def out_snr(q, F):
    acc = np.convolve(x.astype(np.int64), q.astype(np.int64))[: len(x)]    # exact accumulation
    y = to_real(requant(acc, 15 + F, 16, 15, "round", "saturate"), 15)     # output Q1.15
    e = y - y_float
    return 10 * np.log10(np.mean(y_float ** 2) / np.mean(e ** 2))
```

### How much scaling?

This filter's largest coefficient is **0.0994**, below 2⁻³ = 0.125, so the top three magnitude bits of a plain coefficient are always copies of the sign. Scaling therefore adds **3** fractional bits: F = W − 1 + 3 = W + 2. (The 32-tap filter of section 6.6 had max |h| = 0.196, which allowed only 2.) The coefficients still sum to 1.0, and Σ|h| = **1.328**.

### Results

Floating point: stopband 46.6 dB.

| W | Plain F | Stopband | Output SNR | Scaled F | Stopband | Output SNR |
| --- | --- | --- | --- | --- | --- | --- |
| 8 | 7 | 26.2 dB | 24.6 dB | 10 | 44.1 dB | 42.0 dB |
| 9 | 8 | 33.4 dB | 30.0 dB | 11 | 45.0 dB | 48.9 dB |
| 10 | 9 | 41.0 dB | 36.5 dB | 12 | 46.6 dB | 55.2 dB |
| 11 | 10 | 44.1 dB | 42.0 dB | 13 | 46.6 dB | 60.4 dB |
| 12 | 11 | 45.0 dB | 48.9 dB | 14 | 46.4 dB | 67.1 dB |
| **13** | 12 | 46.6 dB | 55.2 dB | **15** | **46.7 dB** | **71.5 dB** |
| 14 | 13 | 46.6 dB | 60.4 dB | 16 | 46.6 dB | 77.8 dB |
| 15 | 14 | 46.4 dB | 67.1 dB | 17 | 46.6 dB | 82.0 dB |
| 16 | 15 | 46.7 dB | 71.5 dB | 18 | 46.5 dB | 84.4 dB |
| 17 | 16 | 46.6 dB | 77.8 dB | 19 | 46.6 dB | 85.5 dB |
| 18 | 17 | 46.6 dB | 82.0 dB | 20 | 46.6 dB | 85.6 dB |

Three observations:

- **A scaled W-bit coefficient behaves exactly like a plain (W + 3)-bit one**: every scaled row repeats the plain row three widths further down (scaled 13 = plain 16, both 71.5 dB). The numbers are the same integers; only the binary point moved.
- **About 6 dB per bit**, as always, until the output rounding takes over: from 15 bits scaled the gains shrink (82.0, 84.4, 85.5 and 85.6 dB for 15 to 18 bits), and the SNR levels off at about 85.6 dB, the floor set by rounding the output to 16 bits.
- **The stopband saturates long before the SNR does.** It reaches the floating-point value (46.6 dB) at 10 bits scaled, but the output SNR keeps improving for several more bits, because the passband response, where the signal energy is, keeps getting more accurate. Section 6.6 made the same point.

### The choice

The smallest width that reaches 70 dB is **13 bits, scaled to F = 15**: 71.5 dB. Without scaling, 16 bits would be needed. 13-bit coefficients easily fit a DSP48E1's 18-bit port; if a margin is wanted (it usually is), 14 bits scaled gives 77.8 dB. The quantized coefficients range from −442 to 3,257, well inside the 13-bit range (±4,096).

### The accumulator, both ways

The product of a 16-bit Q1.15 sample and a 13-bit coefficient with F = 15 is **29 bits**, with 15 + 15 = 30 fractional bits.

- **By length**: 64 taps need ⌈log₂ 64⌉ = **6** guard bits: 29 + 6 = **35 bits**. Always safe, whatever the coefficients.
- **By Σ|h|**: the output can be at most Σ|h| = 1.328 times full scale. The largest possible accumulator value, with every input at full scale and of the right sign, is 1,426,063,360 = 1.328 in real terms, which needs **32 bits** (sign, one integer bit and 30 fractional bits). This bound is tight, but valid only for these exact coefficients.

On an FPGA with 48-bit DSP accumulators, use 35. In an ASIC, 32 bits saves three bits of adders and registers. Either way, `requant` drops 30 − 15 = 15 fractional bits and saturates, which is necessary: Σ|h| > 1, so a worst-case input can exceed full scale.

### The chart

> **Figure:** scipy.signal.freqz at 126 frequencies; the thick grey line is floating point, under the 13-bit curve (shown in the [online version](https://claude.ai/artifact/6GdbjPGUos5VvXpbNhSHUw))

With 13 scaled bits the response is indistinguishable from floating point at this scale; with 8 plain bits (Q1.7) the stopband rises to about −26 dB in places, 20 dB worse.

## Exercise 5: an 18-bit-coefficient MAC

### The widths

With A as Q1.15 samples and B as Q1.17 coefficients:

| Quantity | Value |
| --- | --- |
| Product width | 16 + 18 = **34 bits** |
| Product (and accumulator) fractional bits | 15 + 17 = **32** (Q2.32) |
| Accumulator | 40 bits (the default ACC\_W): 34 + 6 guard bits, exact for sums of up to 64 products |
| Bits `requant` drops | 32 − 15 = **17** |

`mac.sv` itself needs no change: it computes `P_F = A_F + B_F` and passes it to `requant`, so the new parameters flow through automatically.

### The changes to the flow

In `gen_mac.py`, the coefficients are quantized to 18 bits and the model drops 17 bits instead of 15:

```python
    if kind == 0:                                    # worst case: -1 * -1 every time -> saturates
        a = np.full(L, -32768); b = np.full(L, -131072)
    elif kind == 1:                                  # small vectors: sum stays inside Q1.15
        a = rng.integers(-32768, 32768, L); b = rng.integers(-131072, 131072, L) // max(L, 1)
    else:                                            # random real values, scaled so sums rarely overflow
        a = quantize(rng.uniform(-1, 1, L), 16, 15)
        b = quantize(rng.uniform(-1, 1, L) / np.sqrt(L), 18, 17)
    for i in range(L):
        rows.append((int(a[i]) & 0xFFFF, int(b[i]) & 0x3FFFF, int(i == 0), int(i == L - 1)))
    acc = int(np.sum(a.astype(np.int64) * b.astype(np.int64)))      # exact sum, Q?.32
    expected.append(int(requant(np.array([acc]), 32, 16, 15, "round", "saturate")[0]))
    ideal.append(float(np.dot(to_real(a, 15), to_real(b, 17))))     # floating-point reference
```

The file format writes `b` with five hex digits (`{r[1]:05x}`). In `tb_mac.sv`, `b` and its read buffer become 18 bits, and the instance gets the new parameters: `mac #(.B_W(18), .B_F(17)) dut (.*);`. `check_mac.py` is unchanged.

### Verification

Five seeds, 300 dot products each:

```text
300 results, 31 saturated
PASS: 300 results bit-exact
error vs floating point (unsaturated results): max 0.498 LSB, mean -0.003 LSB
```

All five passed, with maximum errors between 0.496 and 0.500 LSB and mean errors within ±0.017 LSB: the single rounding at the output, as designed. The 31 saturated results per seed are mostly the deliberate −1 × −1 vectors. The design is lint-clean with `-GB_W=18 -GB_F=17`.

### The DSP block

Synthesizing with `B_W = 18` and writing the netlist (`write_verilog -noattr net.v`), the report shows **one DSP48E1**, 23 flip-flops, 37 LUTs and 9 `CARRY4` (the rounding and saturation logic), and the DSP instance has:

```text
.AREG(32'd1)   .BREG(32'd1)   .MREG(1'h1)   .PREG(1'h1)
```

All four pipeline registers sit inside the DSP block, exactly as with 16-bit coefficients. One detail in the netlist is worth noticing: Yosys connects the 18-bit **coefficient** to the block's **A** input (sign-extended to 30 bits) and the 16-bit **sample** to the **B** input. The DSP48E1 multiplies a 25-bit A by an 18-bit B, and Yosys put the wider operand on the wider port.

### And with `B_W = 19`?

The B port is only 18 bits wide, so one might expect a 19-bit coefficient to need a second DSP block, or logic outside it. **It does not.** With `B_W = 19`, Yosys again reports one DSP48E1, with AREG, BREG, MREG and PREG all set to 1: the 19-bit coefficient goes on the 25-bit A input, and the 16-bit sample still fits the 18-bit B input.

The real limits are the multiplier's 25 × 18 shape: one operand up to 25 bits, the other up to 18. With a 16-bit sample, the coefficient can grow to **25 bits** in one DSP block; at 26 bits Yosys needs two. (Testing this, the accumulator was widened to 16 + B\_W + 6 bits, which must be done anyway: with 19-bit coefficients and 64-product sums, ACC\_W should be 41, one more than the default of 40, to stay exact.)

The practical rule: a DSP48E1 multiplier is free if **one operand fits 18 bits and the other 25**. Choose widths so that the wider signal, often the coefficient or an accumulated value, uses the 25-bit side.

---

That completes Part 6. Send me your own code and tables if you would like them reviewed.
