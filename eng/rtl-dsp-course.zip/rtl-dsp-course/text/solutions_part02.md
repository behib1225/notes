# Verilog & RTL for DSP — Solutions to Part 2

*Markdown export of the online document: https://claude.ai/artifact/UtLmP3bmaiEavHcUn4r8NL. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the six exercises of Part 2. Try each one yourself first. The answers to the "Check your understanding" questions are in Part 2 itself, after each question set.

Most of the testbenches follow the template of Part 2, section 2.5: a free-running clock, stimulus applied at the **falling** edge, and a model updated alongside the stimulus and compared with the design at the next falling edge. Exercises 2, 3, 5 and 6 also test long random input sequences, not just hand-picked cases.

**How these solutions were checked.** Every module and testbench was compiled and run with Icarus Verilog 12.0 (`iverilog -g2012 -Wall`) and linted with Verilator 5.020 (`--lint-only -Wall`); every quoted result is copied from an actual run. Each design was then broken once, deliberately, to confirm that its testbench fails. Your own solutions may look different and still be correct: what matters is that they pass equally strong tests.

## Exercise 1: synchronizer and rising-edge detector

```systemverilog
`timescale 1ns/1ps
// edge_detect.sv -- one-cycle pulse after each rising edge of an asynchronous input
module edge_detect (
  input  logic clk,
  input  logic rst,
  input  logic btn,        // asynchronous: may change at any time
  output logic pulse
);
  logic s1, s2, s3;        // s1, s2: two-flip-flop synchronizer; s3: previous value of s2

  always_ff @(posedge clk) begin
    if (rst) begin
      s1 <= 1'b0;  s2 <= 1'b0;  s3 <= 1'b0;
    end else begin
      s1 <= btn;           // may go metastable; never used directly
      s2 <= s1;            // safe, synchronized copy of btn
      s3 <= s2;            // the synchronized value one cycle ago
    end
  end

  assign pulse = s2 && !s3;   // "is 1 now, was 0 one cycle ago"
endmodule
```

The three flip-flops form one shift register. `s1` and `s2` are the two-flip-flop synchronizer of section 2.4: `s1` may go metastable when `btn` changes near a clock edge, and it gets a full clock period to settle before `s2` samples it. `s3` holds the previous synchronized value, so `s2 && !s3` is true for exactly one cycle after each 0-to-1 change. Only `s2` and `s3`, never `btn` or `s1`, feed the logic.

### The testbench

The button changes at times that are deliberately **not** aligned to the 10 ns clock (37, 63, 47 ns offsets), and one press is short (17 ns). The testbench counts pulses at the rising edges and checks at each falling edge that no pulse lasts two cycles:

```systemverilog
`timescale 1ns/1ps
module tb_edge_detect;
  logic clk = 1'b0, rst, btn, pulse;
  int pulses = 0, presses = 0, errors = 0;
  time t_rise, t_pulse;
  int edges_seen = 0;
  edge_detect dut (.*);
  always #5 clk = ~clk;                       // 10 ns clock

  // count pulses and check that each lasts exactly one cycle
  always @(posedge clk) if (!rst && pulse) begin
    pulses++;
    t_pulse = $time;
  end
  logic prev_pulse = 1'b0;
  always @(negedge clk) if (!rst) begin
    if (pulse && prev_pulse) begin $display("FAIL: pulse longer than one cycle at %0d ns", $time); errors++; end
    prev_pulse = pulse;
  end

  initial begin
    rst = 1'b1; btn = 1'b0;
    #23 rst = 1'b0;
    // press 1: rises off the clock grid, held for several cycles
    #37 btn = 1'b1; presses++; t_rise = $time;
    #200 btn = 1'b0;
    #63 btn = 1'b1; presses++;
    #91 btn = 1'b0;
    #47 btn = 1'b1; presses++;                // short press: 17 ns (longer than a clock period)
    #17 btn = 1'b0;
    #120;
    if (pulses == presses && errors == 0) $display("PASS: %0d presses, %0d pulses, each one cycle long", presses, pulses);
    else $display("FAILED: %0d presses, %0d pulses, %0d errors", presses, pulses, errors);
    $finish;
  end

  // latency of the first press: clock edges from btn rising until pulse rises
  initial begin
    wait (presses == 1);
    fork
      begin forever begin @(posedge clk); edges_seen++; end end
      begin @(posedge pulse); end
    join_any
    disable fork;
    $display("btn rose at %0d ns; pulse rose at %0d ns, after %0d rising clock edges", t_rise, $time, edges_seen);
  end
endmodule
```

The latency measurement uses `fork ... join_any`: two processes run in parallel, one counting clock edges and one waiting for the pulse; when the pulse arrives, `disable fork` stops the counter.

Results:

```text
btn rose at 60 ns; pulse rose at 75 ns, after 2 rising clock edges
PASS: 3 presses, 3 pulses, each one cycle long
```

The module is lint-clean. With the edge detection removed (`assign pulse = s2;`), the testbench reported `FAILED: 3 presses, 31 pulses, 28 errors`: a level, not a pulse.

### How many cycles after `btn` rises does `pulse` appear?

**At the second rising clock edge after `btn` rises.** The first edge copies `btn` into `s1`, the second copies `s1` into `s2`, and since `s3` is still 0, `pulse` goes high immediately after that edge (it is combinational). In time, that is between one and two clock periods after `btn` changes, depending on where in the clock cycle the change happens: here 15 ns with a 10 ns clock. The pulse then lasts exactly one clock period.

Two practical notes:

- A press must last at least about one clock period to be seen reliably: a pulse shorter than that might fall entirely between two clock edges. (The 17 ns press was longer than the 10 ns clock and was caught.)
- A real mechanical button also **bounces**: it closes and opens several times within a few milliseconds. This design would produce one pulse per bounce. A debouncer (a counter that waits for the synchronized input to stay stable for several milliseconds) is the usual addition.

## Exercise 2: up/down counter with load

```systemverilog
`timescale 1ns/1ps
// updown_counter.sv -- W-bit counter with synchronous reset, load and up/down count
// Priority: reset, then load, then count (when en = 1). Wraps in both directions.
module updown_counter #(
  parameter int W = 8
) (
  input  logic         clk,
  input  logic         rst,
  input  logic         en,
  input  logic         up,        // 1 = count up, 0 = count down
  input  logic         load,
  input  logic [W-1:0] d,
  output logic [W-1:0] count
);
  always_ff @(posedge clk) begin
    if (rst)
      count <= '0;
    else if (load)
      count <= d;
    else if (en) begin
      if (up) count <= count + 1'b1;   // 255 + 1 wraps to 0: W-bit arithmetic
      else    count <= count - 1'b1;   // 0 - 1 wraps to 255
    end
  end
endmodule
```

The priority order of the specification is simply the order of the `if / else if` chain: the first true condition wins. Wrap-around needs no code at all: `count + 1'b1` is evaluated in W bits (the width of `count`), so 255 + 1 gives 0 and 0 − 1 gives 255, exactly like the modulo counter of section 2.6. Note that `load` works even when `en` = 0; the specification gives it priority over counting, not a dependence on enable.

### The testbench

A `step` task checks the counter against the model, applies one set of inputs, and updates the model:

```systemverilog
`timescale 1ns/1ps
module tb_updown_counter;
  localparam int W = 8, MOD = 1 << W;
  logic clk = 1'b0, rst, en, up, load;
  logic [W-1:0] d, count;
  int model = 0, errors = 0, up_wraps = 0, down_wraps = 0;
  updown_counter #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  // apply one set of inputs at the falling edge, update the model for the next rising edge
  task automatic step(input logic ten, tup, tload, input int td);
    @(negedge clk);
    if (count !== model[W-1:0]) begin
      if (errors < 5) $display("FAIL at %0d ns: count=%0d expected %0d", $time, count, model);
      errors++;
    end
    en = ten; up = tup; load = tload; d = td[W-1:0];
    if (tload)    model = td % MOD;
    else if (ten) begin
      if (tup) begin model = model + 1; if (model == MOD) begin model = 0;       up_wraps++;   end end
      else     begin model = model - 1; if (model < 0)    begin model = MOD - 1; down_wraps++; end end
    end
  endtask

  initial begin
    rst = 1'b1; en = 0; up = 0; load = 0; d = 0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    // directed: both wrap-arounds
    step(0, 0, 1, 254);  step(1, 1, 0, 0);  step(1, 1, 0, 0);  step(1, 1, 0, 0);   // 254 255 0 1
    step(0, 0, 1, 1);    step(1, 0, 0, 0);  step(1, 0, 0, 0);  step(1, 0, 0, 0);   // 1 0 255 254
    step(1, 1, 1, 77);                                                            // load beats count
    // random
    repeat (5000) step($urandom_range(0, 1), $urandom_range(0, 1), $urandom_range(0, 19) == 0, $urandom_range(0, 255));
    step(0, 0, 0, 0);
    if (errors == 0) $display("PASS: %0d up-wraps and %0d down-wraps checked", up_wraps, down_wraps);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

The directed steps load 254 and count up through the 255-to-0 wrap, load 1 and count down through the 0-to-255 wrap, and check that `load` wins over counting. Then 5,000 random steps follow, with `load` active about 1 time in 20 (so the counter has time to wander).

Result: `PASS: 3 up-wraps and 2 down-wraps checked`, lint-clean. The random part rarely reaches a wrap (it needs a long run in one direction), which is exactly why the directed steps are there. When the priority was deliberately changed so that loading required `en` (`else if (en && load)`), the test failed at once: `FAIL at 40 ns: count=0 expected 254`.

### The modulo caveat

The model avoids `%` for counting down on purpose. In SystemVerilog, as in C, the remainder takes the sign of the dividend, so `-1 % 256` is **−1**. In Python it is **255**. Both were checked:

```text
-1 % 256 in SystemVerilog = -1
-1 % 256 in Python: 255
```

A model written as `model = (model - 1) % 256` would therefore work in Python and fail in SystemVerilog. The explicit test `if (model < 0) model = MOD - 1;` is correct in any language. (The model uses `td % MOD` only for `load`, where `td` is never negative.)

## Exercise 3: parameterized delay line

```systemverilog
`timescale 1ns/1ps
// delay_line.sv -- y = x delayed by N samples (a sample is a cycle with en = 1)
module delay_line #(
  parameter int W = 16,
  parameter int N = 8              // N >= 1
) (
  input  logic         clk,
  input  logic         rst,
  input  logic         en,
  input  logic [W-1:0] x,
  output logic [W-1:0] y
);
  logic [W-1:0] taps [0:N-1];      // taps[k] = x delayed by k+1 samples

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else if (en) begin
      taps[0] <= x;
      for (int i = 1; i < N; i++) taps[i] <= taps[i-1];   // unrolled: N parallel registers
    end
  end

  assign y = taps[N-1];
endmodule
```

The `for` loop inside `always_ff` is unrolled into N separate non-blocking assignments, all of which happen at the same clock edge, so every register takes the **old** value of its neighbor: the shift register of section 2.7, written once for any N. Because the assignments are non-blocking, the order of the loop does not matter; with blocking `=` it would (the shift-register experiment of section 2.3).

The edge case N = 1 also works: the shifting loop runs from 1 to 0 and so contains no iterations, leaving a single register.

### The testbench

One testbench instantiates the module three times, with N = 1, 2 and 8, drives all three with the same random input and random `en`, and compares each against a model history array that shifts only on samples:

```systemverilog
`timescale 1ns/1ps
module tb_delay_line;
  localparam int W = 16;
  logic clk = 1'b0, rst, en;
  logic [W-1:0] x, y1, y2, y8;
  int hist [0:7];                  // model: hist[k] = input k+1 samples ago
  int errors = 0, samples = 0;
  delay_line #(.W(W), .N(1)) d1 (.clk(clk), .rst(rst), .en(en), .x(x), .y(y1));
  delay_line #(.W(W), .N(2)) d2 (.clk(clk), .rst(rst), .en(en), .x(x), .y(y2));
  delay_line #(.W(W), .N(8)) d8 (.clk(clk), .rst(rst), .en(en), .x(x), .y(y8));
  always #5 clk = ~clk;
  initial begin
    rst = 1'b1; en = 0; x = 0;
    for (int k = 0; k < 8; k++) hist[k] = 0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (3000) begin
      @(negedge clk);
      if (y1 !== W'(hist[0]) || y2 !== W'(hist[1]) || y8 !== W'(hist[7])) begin
        if (errors < 5) $display("FAIL at %0d ns: y1=%0d y2=%0d y8=%0d, expected %0d %0d %0d",
                                 $time, y1, y2, y8, hist[0], hist[1], hist[7]);
        errors++;
      end
      en = $urandom_range(0, 2) != 0;          // samples on about 2 cycles in 3
      x  = $urandom;
      if (en) begin                            // the model shifts only on samples
        for (int k = 7; k > 0; k--) hist[k] = hist[k-1];
        hist[0] = x;
        samples++;
      end
    end
    if (errors == 0) $display("PASS: N = 1, 2, 8 over %0d samples", samples);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

In the model, the loop runs **downward** (k from 7 to 1), because it uses blocking assignments: copying from the top first means each element still holds its old value when it is read. That is the software equivalent of the non-blocking assignment in the hardware.

Result: `PASS: N = 1, 2, 8 over 2025 samples`, and Verilator is clean for each of the three sizes (`-GN=1`, `-GN=2`, `-GN=8`). With the `en` condition removed (shifting on every clock), it failed on the first cycle that had no sample: `FAIL at 50 ns: y1=22115 y2=24193 y8=0, expected 24193 0 0`.

## Exercise 4: 16-bit LFSR

```systemverilog
`timescale 1ns/1ps
// lfsr16.sv -- 16-bit Fibonacci LFSR, polynomial x^16 + x^14 + x^13 + x^11 + 1 (maximal length)
module lfsr16 (
  input  logic        clk,
  input  logic        rst,
  input  logic        en,
  output logic [15:0] s
);
  logic fb;
  assign fb = s[15] ^ s[13] ^ s[12] ^ s[10];     // taps 16, 14, 13, 11 (bits 15, 13, 12, 10)

  always_ff @(posedge clk) begin
    if (rst)     s <= 16'h0001;                   // any non-zero seed
    else if (en) s <= {s[14:0], fb};              // shift left, feedback into the LSB
  end
endmodule
```

The concatenation `{s[14:0], fb}` is a left shift by one: bits 14 to 0 move up one place and the feedback bit enters at bit 0. The tap numbers of the polynomial (16, 14, 13, 11) are 1-based, so they become bit indices 15, 13, 12 and 10.

### The testbench

Starting from the reset value, it steps the LFSR until the state returns to `0x0001`, counting the steps and checking that the state is never zero on the way:

```systemverilog
`timescale 1ns/1ps
module tb_lfsr16;
  logic clk = 1'b0, rst, en;
  logic [15:0] s;
  int steps = 0, zeros = 0, ones = 0;
  lfsr16 dut (.*);
  always #5 clk = ~clk;
  initial begin
    rst = 1'b1; en = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0; en = 1'b1;
    do begin
      @(negedge clk);
      steps++;
      if (s == 16'h0000) zeros++;
      ones += s[0];                               // count 1s in the output bit stream
    end while (s != 16'h0001 && steps < 70000);
    if (steps == 65535 && zeros == 0)
      $display("PASS: period %0d, state never zero, %0d ones and %0d zeros in the output bit", steps, ones, steps - ones);
    else
      $display("FAILED: period %0d, zero states %0d", steps, zeros);
    $finish;
  end
endmodule
```

The `steps < 70000` limit stops the loop if the period is wrong, so a broken design cannot run forever.

Result:

```text
PASS: period 65535, state never zero, 32768 ones and 32767 zeros in the output bit
```

The period is 2¹⁶ − 1 = 65,535: the LFSR visits **every** non-zero 16-bit state exactly once before repeating. The output bit contains exactly one more 1 than 0s over a full period, a known property of maximal-length sequences (all 32,768 states with bit 0 set appear, but only 32,767 of the states with bit 0 clear, because the all-zero state is excluded). The design is lint-clean.

With one tap moved (bit 9 instead of bit 10), the testbench reported `FAILED: period 5115, zero states 0`: the polynomial is no longer maximal-length, so the state cycles through only 5,115 of the 65,535 non-zero values. **The choice of taps is everything**; they come from published tables of primitive polynomials.

### Why must the state never be all zeros?

If every bit is 0, the feedback is 0 ^ 0 ^ 0 ^ 0 = 0, so the next state is again all zeros: the LFSR is **stuck** forever. That is why the reset value must be non-zero. Conversely, starting from any non-zero state, a maximal-length LFSR passes through all the other non-zero states and never reaches zero, because zero leads only to itself and so cannot lie on the cycle of non-zero states.

## Exercise 5: moving average of 8

```systemverilog
`timescale 1ns/1ps
// moving_avg8.sv -- y[n] = (x[n] + x[n-1] + ... + x[n-7]) / 8, by an arithmetic shift
// Output is registered; one cycle of latency; samples marked by in_valid.
module moving_avg8 #(
  parameter int W = 16
) (
  input  logic                clk,
  input  logic                rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W-1:0] y
);
  logic signed [W-1:0] d [1:7];                 // x[n-1] .. x[n-7]
  logic signed [W+2:0] sum;                     // W+3 bits: the sum of 8 values cannot overflow

  always_comb begin
    sum = (W+3)'(x);
    for (int k = 1; k <= 7; k++) sum += (W+3)'(d[k]);   // each operand sign-extended first
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      y <= '0;
      out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        y <= W'(sum >>> 3);                     // divide by 8 (rounds toward minus infinity)
      end
    end
  end
endmodule
```

It follows `moving_sum4` of section 2.7: a delay line holds the seven previous samples, a combinational sum adds them to the current one, and the result is registered when the sample is valid.

### How many bits does the internal sum need?

Eight W-bit values can add up to 8 times the largest one, which needs log₂ 8 = **3 more bits: W + 3 = 19 bits** for W = 16. The extreme cases are 8 × (−32,768) = −262,144 = −2¹⁸, exactly the smallest 19-bit value, and 8 × 32,767 = 262,136, just under the largest, 2¹⁸ − 1. Each operand is sign-extended to 19 bits **before** it is added (the `(W+3)'(…)` casts), so no partial sum can overflow.

### Why does the result fit back into W bits?

The average of eight numbers lies between the smallest and the largest of them, and every input lies between −32,768 and 32,767. Rounding the average down cannot take it below −32,768 either, because the sum is at least −262,144 and −262,144 / 8 is exactly −32,768. So `sum >>> 3` is always within the W-bit range, and the cast `W'(…)` only drops copies of the sign bit.

The arithmetic shift `>>>` rounds toward minus infinity (floor), not toward zero: an average of −7/8 becomes −1. Part 6, Exercise 2 replaces it with proper rounding.

### The testbench

The model computes in `int` and uses `>>> 3` on the `int`, so it rounds exactly as the hardware does. Samples arrive on about 3 cycles in 4, with two long runs at full scale to exercise the extreme sums:

```systemverilog
`timescale 1ns/1ps
module tb_moving_avg8;
  localparam int W = 16;
  logic clk = 1'b0, rst, in_valid, out_valid;
  logic signed [W-1:0] x, y;
  int hist [0:6];                    // x[n-1] .. x[n-7]
  int xi, exp_y = 0, errors = 0, checks = 0, n = 0;
  logic exp_valid = 1'b0;
  moving_avg8 #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  function automatic int pick(int n);
    if (n >= 500 && n < 540)  return -32768;           // a long run at negative full scale
    if (n >= 600 && n < 640)  return  32767;           // and at positive full scale
    return $signed(W'($urandom));
  endfunction

  initial begin
    rst = 1'b1; in_valid = 1'b0; x = '0;
    for (int k = 0; k < 7; k++) hist[k] = 0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (4000) begin
      if (y !== W'(exp_y) || out_valid !== exp_valid) begin
        if (errors < 5) $display("FAIL at %0d ns: y=%0d valid=%b, expected %0d %b", $time, y, out_valid, exp_y, exp_valid);
        errors++;
      end
      if (out_valid) checks++;
      in_valid = $urandom_range(0, 3) != 0;
      exp_valid = in_valid;
      if (in_valid) begin
        int s;
        xi = pick(n); n++;
        x = xi[W-1:0];
        s = xi;
        for (int k = 0; k < 7; k++) s += hist[k];
        exp_y = s >>> 3;                           // int arithmetic shift: same rounding as the RTL
        for (int k = 6; k > 0; k--) hist[k] = hist[k-1];
        hist[0] = xi;
      end else x = 'x;
      @(negedge clk);
    end
    if (errors == 0) $display("PASS: %0d outputs checked, including full-scale runs", checks);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

Result: `PASS: 3016 outputs checked, including full-scale runs`, lint-clean. Driving `x` to `'x` between samples makes the test stricter: if the design ever used `x` when `in_valid` is low, the unknowns would reach the output and the comparison would fail.

With the sum made deliberately too narrow (W + 1 bits instead of W + 3), the test reported `FAILED with 1035 errors` (failing cycles, out of 4,000): random sums of eight 16-bit values regularly exceed the 17-bit range.

**Using the Python flow of Part 4** for this exercise: NumPy's `>>` on signed integers also rounds toward minus infinity (`np.int64(-7) >> 3` gives −1, checked), so a NumPy model written with `>> 3` matches the hardware exactly, while one written with `/ 8` or `// 8` must be checked carefully: `/` gives a float, and `//` happens to floor, like `>>`.

## Exercise 6: find the three bugs

The original module, for reference:

```systemverilog
module accum #(
  parameter int W = 8
) (
  input  logic                clk, rst, en,
  input  logic [W-1:0]        x,      // signed sample
  output logic signed [W+3:0] acc     // running sum of up to 16 samples
);
  always_ff @(posedge clk or rst) begin
    if (rst) acc = 0;
    else if (en) acc <= acc + x;
  end
endmodule
```

### What each tool reports

**Icarus** (`iverilog -g2012 -Wall`):

```text
accum_bad.sv:9 warning: Synthesis requires the sensitivity list of an always_ff process to only be edge sensitive. accum.rst is missing a pos/negedge.
```

**Verilator** (`--lint-only -Wall`):

```text
%Warning-WIDTHEXPAND: accum_bad.sv:11:29: Operator ADD expects 12 bits on the RHS, but RHS's VARREF 'x' generates 8 bits.
%Warning-BLKSEQ: accum_bad.sv:10:18: Blocking assignment '=' in sequential logic process
%Error-BLKANDNBLK: accum_bad.sv:7:31: Unsupported: Blocked and non-blocking assignments to same variable: 'acc'
```

### The three bugs

**Bug 1: `@(posedge clk or rst)`. Found by Icarus.** Without `posedge`, `rst` is level-sensitive: the block also runs whenever `rst` changes in either direction, including when it falls, which is not a flip-flop's behavior and cannot be synthesized as one. Rule broken: *an `always_ff` sensitivity list contains only edges* (section 2.4). The fix depends on the intended reset: `@(posedge clk)` for a synchronous reset (chosen here, as in most of the course), or `@(posedge clk or posedge rst)` for an asynchronous one.

**Bug 2: `acc = 0` uses a blocking assignment. Found by Verilator** (`BLKSEQ`, and `BLKANDNBLK` because the same variable is also assigned with `<=`). Rule broken: *non-blocking `<=` for every register in clocked logic* (section 2.3). Mixing the two on one variable makes simulation order-dependent; Verilator refuses it outright.

**Bug 3: `x` is declared unsigned. Found only by a test.** The comment says the sample is signed, but the port is `logic [W-1:0]`. In `acc + x`, `x` is then zero-extended to 12 bits, so −1 (`8'hFF`) is added as +255. Verilator's `WIDTHEXPAND` warning points at the right expression but not the real problem: the width is fine once the sign is right. Rule broken: *declare signed data signed, and mixing signed and unsigned makes everything unsigned* (Part 1, section 1.4).

With bugs 1 and 2 fixed but bug 3 left in, the test below printed:

```text
FAIL at 40 ns: acc=255 expected -1
FAIL at 50 ns: acc=510 expected -2
FAIL at 60 ns: acc=765 expected -3
```

Every sample of −1 adds 255.

### The fixed module

```systemverilog
`timescale 1ns/1ps
// accum.sv -- running sum of signed W-bit samples, W+4 bits wide (up to 16 samples)
module accum #(
  parameter int W = 8
) (
  input  logic                clk, rst, en,
  input  logic signed [W-1:0] x,                // bug 3 fixed: the sample is SIGNED
  output logic signed [W+3:0] acc
);
  always_ff @(posedge clk) begin                // bug 1 fixed: edge-only sensitivity
    if (rst)     acc <= '0;                     // bug 2 fixed: non-blocking everywhere
    else if (en) acc <= acc + (W+4)'(x);        // sign-extend explicitly to the accumulator width
  end
endmodule
```

The explicit cast `(W+4)'(x)` sign-extends `x` because it is now signed, and it also removes the `WIDTHEXPAND` warning: the module is lint-clean.

### The test

```systemverilog
`timescale 1ns/1ps
module tb_accum;
  localparam int W = 8;
  logic clk = 1'b0, rst, en;
  logic [W-1:0] x;                              // driven as raw bits: works for both versions
  logic signed [W+3:0] acc;
  int model = 0, errors = 0;
  accum #(.W(W)) dut (.*);
  always #5 clk = ~clk;
  task automatic sample(input int v, input logic e);
    @(negedge clk);
    if (acc !== (W+4)'(model)) begin
      if (errors < 3) $display("FAIL at %0d ns: acc=%0d expected %0d", $time, acc, model);
      errors++;
    end
    x = v[W-1:0]; en = e;
    if (e) model += v;
  endtask
  initial begin
    rst = 1'b1; en = 1'b0; x = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (8) sample(-1, 1'b1);                // the test that exposes bug 3: expect -8
    sample(0, 1'b0);
    $display("after eight samples of -1: acc = %0d (expected -8)", acc);
    rst = 1'b1; @(negedge clk); rst = 1'b0; model = 0;
    repeat (16) sample(-128, 1'b1);             // the largest negative total: -2048
    repeat (16) sample(127, 1'b1);              // back up by 16 x 127
    repeat (500) begin                          // random, with a reset every 16 samples
      for (int k = 0; k < 15; k++) sample($urandom_range(0, 255) - 128, $urandom_range(0, 1));
      sample(0, 1'b0);
      rst = 1'b1; @(negedge clk); rst = 1'b0; model = 0;
    end
    sample(0, 1'b0);
    if (errors == 0) $display("PASS");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

The random part resets the accumulator after at most 16 samples, because the specification promises correctness only for "up to 16 samples": 16 × (−128) = −2,048 is the smallest value a 12-bit signed accumulator can hold, which the directed test reaches exactly.

Result for the fixed module:

```text
after eight samples of -1: acc = -8 (expected -8)
PASS
```

The lesson is the same as in Part 1, Exercise 5, with one addition: Icarus and Verilator each found a bug the other did not report, and neither found the one that mattered most. **Use both tools, and always test with negative numbers.**

---

That completes Part 2. Send me your own solutions if you would like them reviewed, including designs that differ from these.
