# Verilog & RTL for DSP — the course text

Markdown exports of the course documents. Each file starts with a link to its online version.
Text, code, tables and equations are complete; the 35 diagrams and charts appear only online,
and each is marked in the Markdown with its title and a link.

| File | Document | Figures (online only) |
| --- | --- | --- |
| [part01.md](part01.md) | [Part 1: Foundations and Combinational Logic](https://claude.ai/artifact/WSYZRgE4Aht9qgq5L31Fmv) | 1 |
| [part02.md](part02.md) | [Part 2: Sequential Logic](https://claude.ai/artifact/GtMiTn92xqh9t91P3YVqfC) | 2 |
| [part03.md](part03.md) | [Part 3: State Machines and the RTL Method](https://claude.ai/artifact/XngCtA9pBhmBvt1WcnBTXt) | 4 |
| [part04.md](part04.md) | [Part 4: Verification and Synthesis](https://claude.ai/artifact/3QsbxnNwYciGtrqhsR5HE2) | 1 |
| [part05.md](part05.md) | [Part 5: DSP from Scratch I](https://claude.ai/artifact/UEAzBg8TVjMqHYdAtu6sze) | 3 |
| [part06.md](part06.md) | [Part 6: Fixed-Point Arithmetic and Multipliers](https://claude.ai/artifact/Kf8LBgUrUAxWA8XXHXmN3r) | 2 |
| [part07.md](part07.md) | [Part 7: FIR Filters](https://claude.ai/artifact/NMsRDSNoi3mtNigMQRqwFg) | 3 |
| [part08.md](part08.md) | [Part 8: IIR Filters](https://claude.ai/artifact/Ex2RtpY2pmZrEbiQziwunA) | 3 |
| [part09.md](part09.md) | [Part 9: NCO, CORDIC and Mixers](https://claude.ai/artifact/7S1igzHyDp8uhEBH4a1TKD) | 2 |
| [part10.md](part10.md) | [Part 10: Multirate Processing](https://claude.ai/artifact/GVcqMPYuqVkNVuUWDUAXgQ) | 2 |
| [part11.md](part11.md) | [Part 11: The FFT](https://claude.ai/artifact/T1gr6ybzjpUwCiKnGLseXd) | 2 |
| [part12.md](part12.md) | [Part 12: Capstone, a Digital Down-Converter](https://claude.ai/artifact/HpTCMxddB15Mq5CWTsBojN) | 2 |
| [part13.md](part13.md) | [Part 13: From Simulation to Hardware](https://claude.ai/artifact/Ms1SzQtcuXeZ5H8UjsXZPk) | — |
| [part14.md](part14.md) | [Part 14: More DSP Structures](https://claude.ai/artifact/V3up8RZjK314g2yFkPZiiK) | — |
| [solutions_part01.md](solutions_part01.md) | [Solutions to Part 1](https://claude.ai/artifact/SoAi6iJTLVzpQmwxdJuHVL) | — |
| [solutions_part02.md](solutions_part02.md) | [Solutions to Part 2](https://claude.ai/artifact/UtLmP3bmaiEavHcUn4r8NL) | — |
| [solutions_part03.md](solutions_part03.md) | [Solutions to Part 3](https://claude.ai/artifact/3VHBsdxdFTb54AwPRTRwgt) | — |
| [solutions_part04.md](solutions_part04.md) | [Solutions to Part 4](https://claude.ai/artifact/UitnDaQeiSMz2mfThdkXnY) | 1 |
| [solutions_part05.md](solutions_part05.md) | [Solutions to Part 5](https://claude.ai/artifact/7aGatSsAt9ajsS7vGeWQVa) | 2 |
| [solutions_part06.md](solutions_part06.md) | [Solutions to Part 6](https://claude.ai/artifact/6GdbjPGUos5VvXpbNhSHUw) | 1 |
| [solutions_part07.md](solutions_part07.md) | [Solutions to Part 7](https://claude.ai/artifact/Eere5Eis9mnVnLUhWf3ZbK) | 1 |
| [solutions_part08.md](solutions_part08.md) | [Solutions to Part 8](https://claude.ai/artifact/Age771xKc3nN9UNFVqbS85) | 1 |
| [solutions_part09.md](solutions_part09.md) | [Solutions to Part 9](https://claude.ai/artifact/E1amagyV6G3r57CPTXGFYy) | — |
| [solutions_part10.md](solutions_part10.md) | [Solutions to Part 10](https://claude.ai/artifact/RvCGoFYvvV75zMsNJiS7rm) | 2 |
| [solutions_part11.md](solutions_part11.md) | [Solutions to Part 11](https://claude.ai/artifact/RddXrDPewzAofqjsJATZnD) | — |
| [solutions_part12.md](solutions_part12.md) | [Solutions to Part 12](https://claude.ai/artifact/3jrnSkCFdJSJcQWgeJB226) | — |
| [appendix_a.md](appendix_a.md) | [Appendix A: Portable SystemVerilog](https://claude.ai/artifact/2rooPowLtJJTig3xL7sYfU) | — |
| [appendix_b.md](appendix_b.md) | [Appendix B: Measuring and Cross-Checking](https://claude.ai/artifact/5UJq2UPxPsecQq5o4hY4SX) | — |
| [appendix_c.md](appendix_c.md) | [Appendix C: The Mathematics Behind the DSP Parts](https://claude.ai/artifact/2HA6TpUNfXT1oUGK8nfuyq) | — |

The code for each part is in `../course/partNN/`, the code of the solutions in `../solutions/partNN/`.
