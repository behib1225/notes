# Verilog & RTL for DSP — Part 14: More DSP Structures

*Markdown export of the online document: https://claude.ai/artifact/V3up8RZjK314g2yFkPZiiK. Diagrams and charts appear only online; each is marked below with its title.*


Oct 22, 2026 · @Behi

## 14.0 What this part adds

The course built its filters and transforms from one recipe: multiply, accumulate, round once. This part shows four structures that break that recipe to save something:

| Structure | What it saves | What it costs |
| --- | --- | --- |
| Canonical signed digit (14.1) | multipliers, when coefficients are constants | logic (adders) |
| Distributed arithmetic (14.2) | all multipliers | throughput: one output per 16 clocks |
| Farrow interpolator (14.3) | the bank of stored filters that a polyphase resampler needs for an arbitrary ratio | a few multiplications by the fraction |
| Streaming FFT (14.4) | throughput: one sample per clock | more multipliers and delay memory |

Each structure is verified like everything in the course: bit-exact against a Python model on several seeds, lint-clean with Verilator, and synthesized with Yosys for the 7-series. The coefficients and test signals are generated in Python, and two of the designs are themselves **generated** RTL: a Python script writes the SystemVerilog, a common practice for structures whose shape depends on the numbers (constant multipliers, tables).

One practical note, from building them: the minus-before-a-cast trap of the Portable SystemVerilog appendix (rule 4) appeared once more, in 14.3. Run all three tools on every design.

## 14.1 Multiplier-free coefficients: canonical signed digit

### The idea

When a filter's coefficients are fixed, a multiplication by a coefficient is a multiplication by a **constant**, which is a sum of shifted copies of the input: 23·x = 16x + 4x + 2x + x, three adders. Allowing **negative** digits often needs fewer: 23·x = 32x − 8x − x, two adders. **Canonical signed digit** (CSD) recoding writes every integer with digits −1, 0 and +1 and no two adjacent non-zero digits, which gives the fewest non-zero digits possible:

```python
def csd(v):
    """Digits d_i in {-1, 0, +1} with v = sum d_i 2^i and no two adjacent non-zero digits.
    Returns a list of (power, sign) pairs, lowest power first."""
    v = int(v); out = []; i = 0
    while v != 0:
        if v & 1:
            d = 2 - (v & 3)          # v mod 4 == 1 -> +1, v mod 4 == 3 -> -1
            out.append((i, d)); v -= d
        v >>= 1; i += 1
    return out
```

| Value | Non-zero bits in binary | CSD digits | CSD form |
| --- | --- | --- | --- |
| 7 | 3 | 2 | 2³ − 2⁰ |
| 23 | 4 | 3 | 2⁵ − 2³ − 2⁰ |
| 32,767 | **15** | **2** | 2¹⁵ − 2⁰ |
| −12,900 | 6 | 6 | −2¹⁴ + 2¹² − 2⁹ − 2⁷ + 2⁵ − 2² |

Every recoding was checked to sum back to the original value. Long runs of ones are where CSD shines; on average it needs about a third fewer non-zero digits than binary.

### A generated filter

The test filter: `firwin(15, 0.25)` quantized to 12-bit Q1.11 coefficients, (−5, −14, −23, 0, 99, 270, 441, 513, 441, …): symmetric, with 7 pairs plus a centre tap, and 48 non-zero binary digits across all taps against **38 in CSD**.

`gen_fir_const.py` writes the same symmetric direct-form filter two ways: with `*` and the coefficient as a constant, or with each product as its CSD shifts and adds (`p4` is the pre-added pair of taps 4 and 10, coefficient 99 = 2⁷ − 2⁵ + 2² − 2⁰):

```systemverilog
  always_comb sum = (- (p0 <<< 2) - (p0 <<< 0))
                 + (- (p1 <<< 4) + (p1 <<< 1))
                 + (- (p2 <<< 5) + (p2 <<< 3) + (p2 <<< 0))
                 + (+ (p4 <<< 7) - (p4 <<< 5) + (p4 <<< 2) - (p4 <<< 0))
                 ...
```

Both versions are **bit-exact** against the generalized FIR model of the Part 7 solutions on three seeds (they compute exactly the same integers), and lint-clean.

### What it saves

| Version (`synth_xilinx -family xc7`) | DSP48E1 | LUTs | Logic depth (`ltp`) |
| --- | --- | --- | --- |
| `*`, DSP blocks allowed | 7 | 53 | — |
| `*`, `-nodsp` | 0 | 1,185 | 62 |
| CSD shift-and-add | 0 | **981** | **47** |

The honest conclusion: against the synthesizer's own constant multipliers, CSD saves **17% of the LUTs** and a quarter of the logic depth. Against DSP blocks it loses: 7 DSP blocks and 53 LUTs are far cheaper than 981 LUTs, if the device has the blocks to spare. CSD matters when the DSP blocks are all taken, on small FPGAs without them, and above all in ASICs, where a hard multiplier does not exist and every adder is area. (Part 14.3 shows the same trade-off appearing on its own: Yosys put the constant multiplications by 3 and 5 of the Farrow interpolator into DSP blocks until they were written as shifts and adds.)

## 14.2 Distributed arithmetic

### The idea

Write each 16-bit two's-complement sample as its bits: x\_k = −2¹⁵·b\_k,15 + Σ\_{i<15} 2ⁱ·b\_k,i. The filter output then reorders into a sum over **bits** instead of over taps:

```latex
y = \sum_k h_k x_k = \sum_{i=0}^{15} w_i \Big( \sum_k h_k\, b_{k,i} \Big), \qquad w_i = 2^i \ (i < 15), \quad w_{15} = -2^{15}
```

The inner sum, Σ h\_k b\_k,i, depends only on **one bit of each sample**, so it can be read from a table indexed by those bits, holding every possible sum of the coefficients. One output then takes 16 cycles, one per bit: look up the table, shift by i, add (subtract for the sign bit). No multiplier anywhere.

A table for all 15 taps would have 2¹⁵ entries, so the taps are split into **groups of 4**, each with its own 16-entry table, and the four tables' outputs are added: 15 taps → tables of 16, 16, 16 and 8 entries.

### The generated RTL

`gen_fir_da.py` computes the tables from the same 15 coefficients as 14.1 and writes them as functions; for example, entry 5 (binary 0101) of group 0 holds h₀ + h₂ = −5 − 23 = −28. The datapath:

```systemverilog
  always_comb begin
    part = '0;
    part += 19'(lut0({taps[3][b], taps[2][b], taps[1][b], taps[0][b]}));
    part += 19'(lut1({taps[7][b], taps[6][b], taps[5][b], taps[4][b]}));
    part += 19'(lut2({taps[11][b], taps[10][b], taps[9][b], taps[8][b]}));
    part += 19'(lut3({taps[14][b], taps[13][b], taps[12][b]}));
  end
  ...
      // bit b has weight 2^b, except the sign bit, whose weight is -2^15
      if (b == 4'd15) begin acc <= acc - (33'(part) <<< 15); run <= 1'b0; done <= 1'b1; end
      else             acc <= acc + (33'(part) <<< b);
```

The accumulator holds the exact Σ h\_k x\_k, which `requant` rounds once, as everywhere in the course. Verified on three seeds: **bit-exact** against the same model, and lint-clean.

### What it costs

| Version (same 15-tap filter) | Multipliers | LUTs | Flip-flops | Outputs per clock |
| --- | --- | --- | --- | --- |
| CSD, parallel (14.1) | 0 | 981 | 281 | 1 |
| **Distributed arithmetic** | **0** | **352** | 296 | 1/17 |
| `*` with DSP blocks (14.1) | 7 DSP48E1 | 53 | 243 | 1 |

Distributed arithmetic is the smallest multiplier-free option by far, 2.8 times smaller than parallel CSD, at 1/17 of the throughput (16 bit-cycles plus one to accept the sample). It suits FPGAs without DSP blocks and slow, many-tap filters; on an FPGA with DSP blocks, the serial MAC of Part 7 gives a similar throughput for one DSP block and fewer LUTs. Its other virtues are that the tables are just LUTs, which FPGAs are made of, and that the cost does not depend on the coefficient values at all, unlike CSD.

## 14.3 Fractional resampling: a Farrow interpolator

### The problem

Part 10 changed sample rates by integer factors. Converting between rates with a non-integer ratio, 48 kHz audio to 44.1 kHz, or a receiver locking onto a transmitter's slightly different symbol rate, needs the signal's value **between** samples, at a fraction μ (0 ≤ μ < 1) of the way from x\[n\] to x\[n+1\], with μ changing for every output. A polyphase filter bank would need a separate filter for every possible μ. A **Farrow** structure instead writes the interpolating filter as a polynomial in μ, so one small set of fixed filters serves every fraction.

### The interpolator

The **cubic Hermite** (Catmull-Rom) interpolator uses four samples, x\[n−1\] to x\[n+2\], and is evaluated in Horner form, three multiplications by μ:

```latex
y(\mu) = ((c_3 \mu + c_2)\,\mu + c_1)\,\mu + c_0, \qquad
\begin{aligned}
c_0 &= x_0, & c_1 &= \tfrac12 (x_1 - x_{-1}),\\
c_2 &= x_{-1} - \tfrac52 x_0 + 2 x_1 - \tfrac12 x_2, & c_3 &= \tfrac12 (-x_{-1} + 3 x_0 - 3 x_1 + x_2)
\end{aligned}
```

It was chosen over the more common cubic **Lagrange** interpolator for a hardware reason: its coefficients contain only halves, which are exact in binary with one extra fractional bit, while Lagrange's contain thirds and sixths, which are not.

### The model and the RTL

The model keeps the coefficients at **twice** their value, so they are exact integers, and rounds once per Horner step:

```python
def coeffs2(xm, x0, x1, x2):
    """2 * c0 .. 2 * c3, exact integers (Q1.15 inputs -> Q?.16)."""
    return (2 * x0, x1 - xm, 2 * xm - 5 * x0 + 4 * x1 - x2, -xm + 3 * x0 - 3 * x1 + x2)

def rnd_mul(t, mu):
    """round(t * mu / 2^16), round half up, as requant does."""
    return (t * mu + (1 << (MUB - 1))) >> MUB

def farrow(xm, x0, x1, x2, mu):
    c0, c1, c2, c3 = coeffs2(int(xm), int(x0), int(x1), int(x2))
    t = c3
    t = rnd_mul(t, mu) + c2
    t = rnd_mul(t, mu) + c1
    t = rnd_mul(t, mu) + c0                 # now Q?.16: one fractional bit more than the input
    return int(requant(np.array([t]), 16, 16, 15, "round", "saturate")[0])
```

The RTL is a five-cycle pipeline: the four coefficients in stage 1, one Horner step in each of stages 2 to 4, and the rounding to Q1.15 in stage 5, with one result per clock:

```systemverilog
    // stage 1: the coefficients (times 2), exact
    c0 <= TW'(x0) <<< 1;
    c1 <= TW'(x1) - TW'(xm);
    c2 <= (TW'(xm) <<< 1) - ((TW'(x0) <<< 2) + TW'(x0)) + (TW'(x1) <<< 2) - TW'(x2);
    c3 <= -(TW'(xm)) + ((TW'(x0) <<< 1) + TW'(x0)) - ((TW'(x1) <<< 1) + TW'(x1)) + TW'(x2);
    mu1 <= mu;
    // stages 2 to 4: one Horner step each
    t1 <= rnd_mul(c3, mu1) + c2;  c1_2 <= c1;  c0_2 <= c0;  mu2 <= mu1;
    t2 <= rnd_mul(t1, mu2) + c1_2;              c0_3 <= c0_2; mu3 <= mu2;
    t3 <= rnd_mul(t2, mu3) + c0_3;
```

The Horner values are 22 bits: the worst case, |t| < 24 × 2¹⁵, needs 21. The constants 3 and 5 are written as shifts and adds on purpose: written as `3 *` and `5 *`, Yosys mapped them into DSP blocks, **6 DSP48E1 and 143 LUTs**; as shifts and adds, **3 DSP48E1** (one per multiplication by μ) **and 254 LUTs**, the CSD trade-off of 14.1 appearing on its own. Both versions are bit-exact.

Verification: 20,000 random windows and fractions, including all-full-scale and alternating ±full-scale windows (258 of the results saturate), with random gaps: **bit-exact**; lint-clean. Exact cases check the arithmetic: μ = 0 returns x₀, and a straight line is reproduced (halfway between 1,000 and 2,000 gives 1,500).

### Resampling with it

`resample()` in the model reads the input at times 0, s, 2s, …, with the step s in Q.16, splitting each time into a sample index and a fraction μ, exactly like an NCO's phase. Resampling full-scale sines by the non-integer ratio s = 1.1:

| Input tone (cycles per input sample) | Output tone | SQNR against the ideal resampled sine | SFDR |
| --- | --- | --- | --- |
| 0.02 | 0.022 | 89.5 dB | 96.3 dB |
| 0.05 | 0.055 | 68.2 dB | 70.4 dB |
| 0.10 | 0.110 | 48.7 dB | 50.1 dB |

The quality depends steeply on how oversampled the signal is: a cubic interpolator is excellent for slowly varying signals and poor near the band edge. That is why practical resamplers first **interpolate by an integer factor** with a good filter (Part 10, Exercise 2), and only then use a Farrow structure on the now heavily oversampled signal.

## 14.4 A streaming FFT

### Why another FFT

Part 11's FFT loads a block, computes it with one butterfly, then unloads it: about 5 clocks per sample (8 for its block-RAM version). A receiver or spectrum analyzer that takes one sample per clock needs a **pipelined** FFT, with one butterfly per stage, all working at once. The classic structure is the **radix-2 single-path delay feedback** (R2SDF) FFT: a chain of log₂ N stages, each with one butterfly, one twiddle multiplier, and a delay line that holds half a block.

### How one stage works

The FFT here is **decimation in frequency**: stage s combines samples D = N/2^(s+1) apart (32, 16, …, 1 for N = 64). For each block of 2D samples arriving at a stage:

1. **First half** (D samples): they go into the delay line, and the stage emits the **differences** it stored during the previous block, multiplied by their twiddles W\_N^(k·2^s).
2. **Second half** (D samples): each new sample meets the one from D samples ago at the end of the delay line; the stage emits their **sum** and stores their **difference** in the delay line.

So each stage outputs one sample for every input, D samples late, and its output order (all sums of a block, then all differences) is exactly what the next stage, with half the span, needs. The final output is DFT/N in **bit-reversed** order, the usual result of a decimation-in-frequency FFT.

### The arithmetic, and its model

Each butterfly halves its results, so the output is DFT/N, as in Part 11: sum = round((a + b)/2), difference = round((a − b)/2), then the difference is multiplied by its twiddle and rounded again, except when the twiddle is exactly 1 (k = 0), where the multiplication is skipped. `sdf_model.py` computes exactly this, block by block; against `np.fft.fft(x)/64` its error is at most **2.96 LSB** over 40 random blocks, a little more than Part 11's 1.56 LSB, because each difference is rounded twice (halving, then the twiddle).

### The RTL

One `sdf_stage` module, instantiated six times by a `generate` loop with S = 0 to 5:

```systemverilog
  assign hr = fr[D-1];  assign hi = fi[D-1];     // the oldest sample: from D samples ago
  assign sr = half(17'(hr) + 17'(xr));  assign si = half(17'(hi) + 17'(xi));
  assign dr = half(17'(hr) - 17'(xr));  assign di = half(17'(hi) - 17'(xi));
  assign widx = ($clog2(N/2))'(32'(j) << S);     // W_N^(k * 2^s), k = j in the first half
  assign pr = 32'(hr) * 32'(tw_re[widx]) - 32'(hi) * 32'(tw_im[widx]) + 32'sd16384;
  assign pi = 32'(hr) * 32'(tw_im[widx]) + 32'(hi) * 32'(tw_re[widx]) + 32'sd16384;
  assign mr = (j == '0) ? hr : sat16(pr >>> 15);  // k = 0: the twiddle is exactly 1, no multiply
  assign mi = (j == '0) ? hi : sat16(pi >>> 15);
```

A counter `j` runs through the 2D positions of a block; in the first half the stage emits the twiddled head of the delay line (`mr`, `mi`) and stores the input, in the second half it emits the sum and stores the difference. Everything advances only on valid samples, so the FFT works with gaps in its input. A stage's first D outputs are marked invalid (its delay line was not yet filled), so the whole FFT's first valid output comes after 63 samples, and the testbench appends one block of zeros to flush the last real block out.

**The delay lines are not reset**, and that matters (Part 4, section 4.6): their initial contents never reach a valid output, and without a reset Yosys builds them from LUT shift registers.

### Verification

Twelve blocks (complex tones, impulses, mixed tones between bins, random data), streamed back to back:

| Input | Result | Max error vs `np.fft/64` | Clock cycles for 832 samples |
| --- | --- | --- | --- |
| One sample per clock | all 12 blocks **bit-exact** with the model | 2.44 LSB | 854 |
| Random gaps (25% idle) | all 12 blocks **bit-exact** | 2.44 LSB | 1,101 |

832 samples (12 blocks plus the flush block) in 854 cycles: **one sample per clock**. The design is lint-clean.

### Cost, against the Part 11 FFTs

| 64-point FFT | Samples per clock | DSP48E1 | LUTs | Flip-flops | Other |
| --- | --- | --- | --- | --- | --- |
| Part 11, memory in flip-flops | about 1/5 | 4 | 5,169 | 2,098 |  |
| Part 11 solutions, block RAM | about 1/8 | 4 | 350 | 19 | 1 RAMB36E1 |
| R2SDF, delay lines reset | **1** | 20 | 1,490 | 2,341 |  |
| **R2SDF, delay lines not reset** | **1** | 20 | 1,489 | **741** | 96 LUT shift registers (64 SRL16E, 32 SRLC32E) |

The streaming FFT does five times the work per clock of the memory-based one, for 5 times the multipliers: 4 per stage, in 5 stages (the last stage's twiddle is always 1, so it has none). Removing the reset from the delay lines cut its flip-flops from 2,341 to 741 at no cost, the memory rule of Part 4 once more. Which FFT to use is the course's usual trade: the block-RAM one when samples arrive slowly, the streaming one when they arrive every clock.

## 14.5 Choosing a structure, and exercises

### A summary of the choices

All the numbers of this part come down to one question: **how many clock cycles do you have per sample, and which resource is scarce?**

| Situation | Good choice |
| --- | --- |
| Many cycles per sample, DSP blocks available | One MAC, serial (Parts 6, 7, 10) |
| Many cycles per sample, no DSP blocks | Distributed arithmetic (14.2) |
| One sample per clock, DSP blocks available | Parallel FIR with DSP blocks; streaming FFT (14.4) |
| One sample per clock, DSP blocks used up, or an ASIC | Constant coefficients in CSD shift-and-add (14.1) |
| Decimate or interpolate by 2 | Half-band filter (Part 10, section 10.4) |
| Arbitrary or changing ratio | Integer interpolation, then a Farrow interpolator (14.3) |

### Exercise 1: a better CSD filter

The CSD filter of 14.1 computes every product separately. Products of different coefficients can share sub-expressions (the same pair of shifted terms, with the same spacing, occurring in several coefficients' CSD digits): find them, compute each once, and measure how many adders and LUTs that saves. Then pipeline the adder tree (Part 7, Exercise 3) and compare the logic depth.

### Exercise 2: a faster distributed arithmetic filter

Process two bits per clock instead of one: two copies of each table, one for the even bits and one for the odd bits, and a shift of 2 per cycle. Verify bit-exactly, and measure the cost of doubling the throughput.

### Exercise 3: a complete resampler

Build the control of `resample()` in RTL: a phase accumulator of the step s (as in the NCO of Part 9) whose integer part says how many input samples to advance and whose fraction is μ. Feed `farrow.sv` from a four-sample window, handle the cases where the next output needs zero, one or two new inputs, and verify against `resample()` bit-exactly. Then resample a 48 kHz sine to 44.1 kHz and measure its SFDR with `measure.py`.

### Exercise 4: a 256-point streaming FFT

Run the R2SDF FFT with N = 256 (twiddle files for 256 points, as in the Part 11 solutions). How do its DSP blocks, flip-flops and shift registers grow with N? Then replace the radix-2 stages by radix-2² stages, which use the trivial twiddle −j between every pair of stages, and measure how many multipliers that saves.
