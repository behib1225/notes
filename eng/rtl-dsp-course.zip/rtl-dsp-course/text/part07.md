# Verilog & RTL for DSP — Part 7: FIR Filters

*Markdown export of the online document: https://claude.ai/artifact/NMsRDSNoi3mtNigMQRqwFg. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 7 fits

Part 7 builds your first real DSP filter, and builds it four ways. You will design a 32-tap low-pass FIR filter in Python, then implement it as four hardware architectures that trade multipliers, logic depth and throughput against each other. All four compute **exactly the same bits**, so one fixed-point golden model verifies them all.

Everything from earlier parts comes together here: the convolution and frequency response of Part 5, the fixed-point formats, `requant` and MAC unit of Part 6, the file-driven verification flow of Part 4, the controller-plus-datapath method of Part 3, and the pipelining and synthesis reports of Parts 2 and 4.

The filter throughout: **32 taps, cutoff 0.1 cycles per sample**, the same `firwin(32, 0.2)` design whose word widths you chose in Part 6. Samples are 16-bit Q1.15, coefficients 18-bit Q1.17 (they fit a DSP48E1's B port), the accumulator keeps every product bit, and the output is rounded once to Q1.15 and saturated.

| Architecture | Section | Multipliers | Samples per clock | Main idea |
| --- | --- | --- | --- | --- |
| Direct form | 7.4 | 32 | 1 | The formula of Part 5, built literally |
| Transposed form | 7.5 | 32 | 1 | Reorder the additions so the pipeline registers come for free |
| Symmetric form | 7.6 | 16 | 1 | Equal coefficients share a multiplier |
| Time-multiplexed | 7.7 | 1 | 1/32 | One MAC, reused 32 times per sample |

As always, every number in this part comes from code that was run: Python 3 with NumPy and SciPy, Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33. You will need SciPy for this part (`sudo apt install python3-scipy` or `pip3 install scipy`).

## 7.1 Designing an FIR filter

Designing an FIR filter means choosing its coefficients h\[0\] … h\[N−1\] so that its frequency response matches a specification. The **window method** does this in three steps: write down the ideal impulse response, cut it to N taps, and taper the cut with a window. SciPy's `firwin` does all three in one call.

### The specification

A low-pass filter is specified by four numbers:

| Term | Meaning | Example |
| --- | --- | --- |
| Passband edge f\_p | Frequencies below this must pass | 0.08 cycles/sample |
| Stopband edge f\_st | Frequencies above this must be blocked | 0.12 cycles/sample |
| Passband ripple | Allowed gain variation in the passband | ±0.1 dB |
| Stopband attenuation | Minimum suppression in the stopband | 60 dB |

The band between f\_p and f\_st is the **transition band**. No real filter switches instantly; a narrower transition or a deeper stopband needs **more taps**.

### Step 1: the ideal impulse response

An ideal low-pass filter with cutoff f\_c (in cycles per sample) passes everything below f\_c with gain 1 and blocks everything above. Its impulse response is the **sinc** function:

```latex
h_{ideal}[n] = 2 f_c \, \mathrm{sinc}(2 f_c n) = \frac{\sin(2 \pi f_c n)}{\pi n}
```

This is infinitely long and non-causal (it extends to negative n), so it cannot be built.

### Step 2: truncate and shift

Keep N samples centered on the peak and delay them by (N−1)/2 so they start at n = 0. The filter is now causal and finite, and still symmetric. But cutting the sinc abruptly causes ripples in the frequency response (the **Gibbs phenomenon**): about 9% overshoot near the edge, and stopband sidelobes only about 21 dB down, however many taps you use.

### Step 3: taper with a window

Multiplying the truncated sinc by a **window**, a smooth curve that falls to near zero at both ends, removes the abrupt edges and with them most of the ripple. The cost is a wider transition band. The chart shows the trade-off for 32 taps and f\_c = 0.1:

> **Figure:** scipy.signal.firwin(32, 0.2, window=...), freqz at 101 frequencies (shown in the [online version](https://claude.ai/artifact/NMsRDSNoi3mtNigMQRqwFg))

| Window (32 taps) | Peak stopband sidelobe | First zero (end of the main lobe) | Attenuation from 0.15 cycles/sample up |
| --- | --- | --- | --- |
| Rectangular (plain truncation) | −21.8 dB | 0.120 | 27.2 dB |
| Hamming (`firwin`'s default) | −53.6 dB | 0.156 | 44.2 dB |
| Blackman | −76.0 dB | 0.196 | 27.2 dB |

The Blackman window has by far the deepest sidelobes, but its transition is so wide that at 0.15 cycles per sample it has barely started to attenuate. **There is no best window, only a best window for a specification.** The **Kaiser** window has a parameter β that slides continuously along this trade-off, which makes it the usual choice when you design to a specification.

In SciPy:

```python
from scipy.signal import firwin, freqz
h = firwin(32, 0.2)                          # Hamming window by default
h = firwin(32, 0.2, window="blackman")       # or another window
h = firwin(32, 0.2, window=("kaiser", 5.0))  # Kaiser with beta = 5
```

Be careful with `firwin`'s units: by default the cutoff is a fraction of the **Nyquist** frequency, so 0.2 means 0.2 × f\_s/2 = **0.1 cycles per sample**. (Pass `fs=...` to use hertz instead.)

### How many taps?

For the Kaiser window, a well-known estimate (Kaiser's formula) gives the length needed for an attenuation of A dB and a transition width Δf in cycles per sample:

```latex
N \approx \frac{A - 8}{2.285 \cdot 2\pi \Delta f} + 1
```

SciPy's `kaiserord` applies it and also returns β. For the specification above (60 dB, transition 0.04 cycles per sample) it gives **N = 92** and β = 5.65. Two consequences worth remembering:

| Change to the specification | Taps needed (kaiserord) |
| --- | --- |
| 60 dB, transition 0.04 | 92 |
| 80 dB, transition 0.04 | 127 |
| 60 dB, transition **0.02** | 183 |

Halving the transition width doubles the length; adding 20 dB of attenuation adds about 40%. Since every tap costs a multiplier or a clock cycle, the specification directly sets the hardware cost.

The window method is simple and robust. Its main alternative, the **Parks–McClellan** (or Remez) algorithm, `scipy.signal.remez`, computes the optimal "equiripple" filter that meets a specification with the fewest taps, typically 10 to 20% fewer. Both produce symmetric coefficients, so everything in the rest of this part applies to either.

### Check your understanding: 7.1

1. A filter must pass up to 3 kHz and block from 4 kHz at f\_s = 48 kHz. What is the transition width in cycles per sample?
2. With 60 dB attenuation, estimate the number of taps for question 1 using Kaiser's formula.
3. Why can't you simply use more taps with a rectangular window to get 60 dB of stopband attenuation?
4. A colleague writes `firwin(64, 0.1)` expecting a cutoff of 0.1 cycles per sample. What cutoff did they get?
5. Why did the Blackman-window filter perform worse than the Hamming one at 0.15 cycles per sample, despite its much lower sidelobes?

#### Answers

1. (4 − 3) kHz / 48 kHz ≈ **0.0208** cycles per sample.
2. N ≈ (60 − 8) / (2.285 × 2π × 0.0208) + 1 ≈ 52 / 0.299 + 1 ≈ **175 taps**.
3. Truncation's sidelobes stay at about −21 dB regardless of length (the Gibbs phenomenon): more taps make the transition narrower and push the ripples closer to the edge, but do not make them smaller. Only a window, a different design method, or both, reduce them.
4. 0.1 × Nyquist = 0.1 × 0.5 = **0.05 cycles per sample**, half of what they intended.
5. With 32 taps, the Blackman window's main lobe is so wide that its first zero is at 0.196 cycles per sample. At 0.15 the response is still on the falling edge of the main lobe, not yet in the deep-sidelobe region. Its low sidelobes only help beyond about 0.2.

## 7.2 Linear phase and symmetric coefficients

Every filter designed by the window method has **symmetric** coefficients: h\[k\] = h\[N−1−k\]. Symmetry gives two benefits: the filter delays all frequencies by the same amount (linear phase), and the hardware can share multipliers between equal coefficients (section 7.6).

### Symmetry and linear phase

For our filter, `np.allclose(h, h[::-1])` is `True`: h\[0\] = h\[31\] = −0.000507, h\[1\] = h\[30\] = 0.000606, and so on, up to the two equal center taps h\[15\] = h\[16\] = 0.196. SciPy's `group_delay`, which measures the delay at each frequency, reports **15.5 samples** at every frequency tested, exactly (N − 1)/2 = 31/2.

This is the linear-phase property you met with the moving average in Part 5: every frequency component is delayed by the same 15.5 samples, so the waveform's shape is preserved. For audio, communications and measurement, that is usually essential. The price is latency: a long linear-phase filter is also a long delay.

### The four types of linear-phase FIR filter

Symmetric or antisymmetric coefficients, with an odd or even number of taps, give four types with different built-in constraints:

| Type | Coefficients | Length N | Forced zero | Can be used for |
| --- | --- | --- | --- | --- |
| I | Symmetric | Odd | None | Any filter: low-pass, high-pass, band-pass, band-stop |
| II | Symmetric | Even | At f\_s/2 | Low-pass, band-pass (not high-pass) |
| III | Antisymmetric | Odd | At 0 and f\_s/2 | Differentiators, Hilbert transformers |
| IV | Antisymmetric | Even | At 0 | Differentiators, high-pass |

Our 32-tap filter is type II: its response at f\_s/2 is exactly zero (SciPy computes about 10⁻¹⁷). That is harmless for a low-pass filter, but it makes an even-length high-pass filter impossible. SciPy enforces this: `firwin(32, 0.2, pass_zero=False)` raises `ValueError: A filter with an even number of coefficients must have zero response at the Nyquist frequency.` Use an odd length, such as 31 or 33, for high-pass filters.

### Check your understanding: 7.2

1. What is the delay, in samples and in microseconds, of a 101-tap linear-phase filter at f\_s = 1 MHz?
2. A 32-tap filter has h\[3\] = 0.0041. Which other coefficient must equal it?
3. Why can a type II filter never be a high-pass filter?
4. A real-time control loop needs a low-pass filter with very small delay. Why might the designer accept a non-linear-phase filter?

#### Answers

1. (101 − 1)/2 = **50 samples**; at 1 µs per sample, **50 µs**.
2. **h\[28\]**, since 32 − 1 − 3 = 28.
3. Its symmetric, even-length coefficients force the response at f\_s/2 to be exactly zero, and a high-pass filter must pass that frequency.
4. Delay inside a feedback loop reduces its stability margin. A minimum-phase or IIR filter (Part 8) can have far less delay than a linear-phase FIR with the same magnitude response, at the cost of distorting the waveform's shape, which a control loop may not care about.

## 7.3 The golden model and the shared test bench

One Python file designs the filter, writes the coefficients as a SystemVerilog include file, computes the bit-exact expected output, and generates the test vectors. One testbench and one script then verify any of the four architectures. Because every architecture computes the exact sum and rounds once, **the same expected output is correct for all of them**.

### The golden model: `fir_model.py`

```python
#!/usr/bin/env python3
"""fir_model.py -- the 32-tap low-pass FIR: design, coefficient file, golden model, test vectors.

Formats: x Q1.15 (16 bits), h Q1.17 (18 bits), products Q2.32, exact sum, y Q1.15 rounded + saturated.
"""
import argparse
import numpy as np
from scipy.signal import firwin
from fixedpoint import quantize, requant

N, XW, XF, CW, CF, YW, YF = 32, 16, 15, 18, 17, 16, 15

def coefficients():
    """Design in floating point, then quantize to Q1.17."""
    return quantize(firwin(N, 0.2), CW, CF)

def write_coef_file(hq, path="fir_coefs.svh"):
    """A SystemVerilog function returning coefficient k: usable with a constant
    (folded by synthesis) or a variable index (becomes a small ROM)."""
    with open(path, "w") as f:
        f.write("// fir_coefs.svh -- generated by fir_model.py; do not edit by hand\n")
        f.write(f"// firwin({N}, 0.2) quantized to Q1.{CF} ({CW} bits)\n")
        f.write(f"function automatic logic signed [{CW-1}:0] fir_coef(input int k);\n")
        f.write("  case (k)\n")
        for k, v in enumerate(hq):
            lit = f"{CW}'sd{v}" if v >= 0 else f"-{CW}'sd{-v}"
            f.write(f"    {k:2d}: fir_coef = {lit};\n")
        f.write(f"    default: fir_coef = '0;\n  endcase\nendfunction\n")

def golden(xq, hq):
    """Bit-exact output: exact integer convolution, then one rounding to Q1.15."""
    acc = np.convolve(np.asarray(xq, np.int64), np.asarray(hq, np.int64))[: len(xq)]
    return requant(acc, XF + CF, YW, YF, "round", "saturate")

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def stimulus(n, seed):
    rng = np.random.default_rng(seed)
    x = quantize(rng.uniform(-0.9, 0.9, n), XW, XF)          # random samples
    x[:40] = 0; x[8] = 16384                                  # an impulse of 0.5 at sample 8
    t = np.arange(400)
    x[100:500] = quantize(0.9 * np.cos(2 * np.pi * 0.03 * t), XW, XF)   # passband tone
    x[500:900] = quantize(0.9 * np.cos(2 * np.pi * 0.3 * t), XW, XF)    # stopband tone
    hq = coefficients()
    worst = np.where(hq[::-1] >= 0, 32767, -32768)           # signs matching h: the largest output
    x[900:900 + 3 * N] = np.tile(worst, 3)
    return x

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=3000)
    p.add_argument("--seed", type=int, default=1)
    a = p.parse_args()
    hq = coefficients()
    write_coef_file(hq)
    x = stimulus(a.n, a.seed)
    y = golden(x, hq)
    open("x.hex", "w").write("\n".join(to_hex(x, XW)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(y, YW)) + "\n")
    sat = int(np.sum((y == 32767) | (y == -32768)))
    print(f"{a.n} samples, seed {a.seed}; {sat} outputs at full scale (saturated)")
```

The stimulus is designed, not just random. It contains an **impulse** (so the output contains the impulse response itself, scaled by 0.5), a **passband tone** and a **stopband tone** (so the output shows the filter working), random samples, and three periods of the **worst-case input**: full-scale values whose signs match the time-reversed coefficients, which drives every product positive and produces the largest possible output, 1.327 × full scale. That pattern forces saturation; the script reports 15 saturated outputs.

### The coefficient include file

The quantized coefficients are written as a function, `fir_coef(k)`, in `fir_coefs.svh`. The first lines:

```systemverilog
// fir_coefs.svh -- generated by fir_model.py; do not edit by hand
// firwin(32, 0.2) quantized to Q1.17 (18 bits)
function automatic logic signed [17:0] fir_coef(input int k);
  case (k)
     0: fir_coef = -18'sd66;
     1: fir_coef = 18'sd79;
     2: fir_coef = 18'sd293;
     ...
    15: fir_coef = 18'sd25695;
    16: fir_coef = 18'sd25695;
     ...
    31: fir_coef = -18'sd66;
    default: fir_coef = '0;
  endcase
endfunction
```

A module pulls it in with `` `include "fir_coefs.svh" `` inside its body. A function works in every tool used in this course: with a constant argument (a loop index), synthesis folds it into a constant multiplier; with a variable argument (a counter, as in section 7.7), it becomes a small ROM. The quantized coefficients stay symmetric, and they sum to exactly 131,072, which is 1.0 in Q1.17: the filter's gain at 0 Hz is exactly 1.

Never edit a generated file by hand. Change the Python and regenerate, so the model and the RTL can never disagree.

### One testbench for all four architectures

Every architecture has the same ports: `clk`, `rst`, `in_valid`, `in_ready`, `x`, `out_valid` and `y`. The streaming designs simply tie `in_ready` to 1. The testbench is the Part 4 design, extended with the valid/ready source of Part 3 so that it also drives the time-multiplexed design correctly:

```systemverilog
`timescale 1ns/1ps
// tb_fir.sv -- one testbench for every FIR architecture (choose with -DDUT=...).
// Source: valid/ready with random gaps. Monitor: records every output in order.
`ifndef DUT
  `define DUT fir_direct
`endif
module tb_fir;
  localparam int XW = 16, YW = 16, MAX_N = 100_000;
  logic                 clk = 1'b0, rst, in_valid, in_ready, out_valid;
  logic signed [XW-1:0] x;
  logic signed [YW-1:0] y;
  logic [XW-1:0] x_mem   [0:MAX_N-1];
  logic [YW-1:0] exp_mem [0:MAX_N-1];
  int n = 3000, seed = 1, sent = 0, got = 0, errors = 0, fd, cycles = 0;

  `DUT dut (.clk(clk), .rst(rst), .in_valid(in_valid), .in_ready(in_ready), .x(x),
            .out_valid(out_valid), .y(y));
  always #5 clk = ~clk;
  initial begin #100_000_000; $fatal(1, "TIMEOUT"); end
  always @(posedge clk) cycles++;

  initial begin
    void'($value$plusargs("N=%d", n));
    void'($value$plusargs("SEED=%d", seed));
    void'($urandom(seed));
    $readmemh("x.hex", x_mem, 0, n - 1);
    $readmemh("y_expected.hex", exp_mem, 0, n - 1);
    fd = $fopen("y_actual.hex", "w");
    rst = 1'b1; in_valid = 1'b0; x = '0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    while (sent < n) begin
      if (!in_valid && $urandom_range(0, 4) != 0) begin    // offer a sample (sometimes wait)
        in_valid = 1'b1;
        x = x_mem[sent];
      end
      @(posedge clk);
      if (in_valid && in_ready) begin                      // transfer at this edge
        sent++;
        @(negedge clk);
        in_valid = 1'b0;
        x = 'x;
      end else @(negedge clk);
    end
  end

  always @(negedge clk) if (!rst && out_valid) begin
    assert (!$isunknown(y)) else $error("output %0d unknown", got);
    $fdisplay(fd, "%h", y);
    if (y !== exp_mem[got]) begin
      if (errors < 5) $display("FAIL sample %0d: got %0d expected %0d", got, y, $signed(exp_mem[got]));
      errors++;
    end
    got++;
    if (got == n) begin
      $fclose(fd);
      if (errors) $fatal(1, "FAILED: %0d of %0d outputs wrong", errors, n);
      $display("PASS: %0d outputs bit-exact, %0d clock cycles", n, cycles);
      $finish;
    end
  end
endmodule
```

The source holds each sample until it is accepted (the valid/ready rule from Part 3), so the same file order works whether the design accepts a sample every clock or every 33 clocks. The testbench also counts clock cycles, which measures throughput directly.

The run script and checker follow Part 4 exactly. `check_fir.py` recomputes the golden output from `x.hex` and compares it with `y_actual.hex`.

```sh
#!/bin/sh
# run_fir.sh -- verify one FIR architecture.  Usage: ./run_fir.sh fir_direct [seed] [n]
set -e
DUT=$1; SEED=${2:-1}; N=${3:-3000}
python3 fir_model.py --seed "$SEED" --n "$N"
iverilog -g2012 -Wall -DDUT="$DUT" -o sim_$DUT "$DUT.sv" requant.sv mac.sv tb_fir.sv
vvp -n sim_$DUT +N="$N" +SEED="$SEED"
python3 check_fir.py
```

Put `fixedpoint.py`, `requant.sv` and `mac.sv` from Part 6 in the same folder.

### Check your understanding: 7.3

1. Why can one expected-output file verify four different architectures?
2. What does the impulse at sample 8 let you see in the output?
3. The worst-case input uses signs that match the **time-reversed** coefficients. Why reversed?
4. Why is the coefficient file generated by Python rather than typed in by hand?
5. What happens in the testbench when a design's `in_ready` is low?

#### Answers

1. All four compute the same mathematical quantity, the exact sum of the 32 exact products, before a single, identical rounding step. Different orders of addition give identical results when no intermediate step rounds or overflows. Any architecture that rounded partial sums differently would need its own model.
2. The impulse response: the outputs from sample 8 onward are 0.5 × h\[0\], 0.5 × h\[1\], …, rounded to Q1.15. You can read the filter's coefficients straight out of the RTL's output file.
3. y\[n\] = Σ h\[k\] x\[n−k\]: the newest sample multiplies h\[0\] and the oldest multiplies h\[31\]. So, in time order, the input samples meet the coefficients in reverse order, and each sign must match its partner's sign to make every product positive.
4. So the RTL and the golden model always use exactly the same numbers. A hand-typed table can contain a typo that the model does not share, which would show up as an unexplained mismatch, or worse, as a correct-looking filter with the wrong response.
5. The source keeps `in_valid` high with the same sample on `x` until an edge where `in_ready` is also high; only then does it count the transfer and move to the next sample.

## 7.4 Architecture 1: the direct form

The direct form builds the convolution formula literally, as in the diagram of Part 5: a delay line holds the last 32 samples, 32 multipliers form the products, and one large addition sums them. It accepts a new sample every clock cycle.

```systemverilog
`timescale 1ns/1ps
// fir_direct.sv -- direct-form FIR: delay line, N parallel multipliers, one big sum.
// Accepts one sample per clock. Latency: 4 cycles.
module fir_direct #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int ACC_W = XW + CW + $clog2(N),           // 39: exact sum, never overflows
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  assign in_ready = 1'b1;                               // never stalls

  logic signed [XW-1:0]    taps [0:N-1];                // taps[k] = x[n-k]
  logic signed [XW+CW-1:0] prod [0:N-1];
  logic signed [ACC_W-1:0] sum_c, acc;
  logic                    v1, v2, v3;

  // stage 1: shift the new sample into the delay line
  // (reset to zero: the golden model assumes the filter starts at rest)
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < N; k++) taps[k] <= '0;
    end else if (in_valid) begin
      taps[0] <= x;
      for (int k = 1; k < N; k++) taps[k] <= taps[k-1];
    end
  end
  // stage 2: N products, each registered (maps to the DSP blocks' M registers)
  always_ff @(posedge clk) begin
    for (int k = 0; k < N; k++) prod[k] <= taps[k] * fir_coef(k);
  end
  // stage 3: one big sum of all N products
  always_comb begin
    sum_c = '0;
    for (int k = 0; k < N; k++) sum_c += ACC_W'(prod[k]);
  end
  always_ff @(posedge clk) acc <= sum_c;
  // stage 4: round and saturate once
  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) {v1, v2, v3, out_valid} <= '0;
    else     {v1, v2, v3, out_valid} <= {in_valid, v1, v2, v3};
    if (v3) y <= y_c;
  end
endmodule
```

The structure is four pipeline stages: delay line, products, sum, rounding. Things to notice:

- **`for` loops inside `always_ff` and `always_comb`** are unrolled by the compiler into N copies of the hardware, exactly like `generate` loops (Part 1). `sum_c += ...` in a loop describes one 32-input adder; the synthesizer arranges it as a tree of two-input adders.
- **`fir_coef(k)` with a loop index** is a constant at each unrolled copy, so each multiplier multiplies by a fixed number.
- **`ACC_W = XW + CW + $clog2(N)`** applies the "worst case by length" rule of Part 6: 16 + 18 + 5 = 39 bits, so the sum can never overflow.
- **The data pipeline registers update every cycle**, valid or not. Only the valid bits are reset, so the pipeline is cheap, and the valid bits mark which outputs are real.

### The bug the first run found

The first version did not reset the delay line. The testbench failed immediately on the first 31 outputs, every one of them `x`:

```text
ERROR: tb_fir.sv:48: output 0 unknown
FAIL sample 0: got x expected 0
...
FATAL: tb_fir.sv:57: FAILED: 31 of 3000 outputs wrong
```

The golden model assumes that the filter starts at rest, with zeros in the delay line, which is the usual mathematical convention. Until 32 real samples have arrived, the hardware's unreset taps contain `x`, which reaches the sum. Exactly 31 outputs were affected, the number of samples it takes to flush the delay line. Part 2 said data registers often do not need a reset; this is the exception that proves the rule. **If your model assumes a known initial state, the hardware needs a reset to that state**, or the testbench must ignore the start-up outputs.

After adding the reset, the design passed bit-exactly: `PASS: 3000 outputs bit-exact, 3726 clock cycles` (the extra 726 cycles are mostly the testbench's random idle gaps). It also passed three more seeds.

### Its weakness: the big sum

The products are computed in parallel by DSP blocks, but stage 3 must add all 32 products in a single clock cycle. Even as a balanced tree, that is five levels of 39-bit additions, ⌈log₂ 32⌉ = 5, in series, and the depth grows with the number of taps. For long filters at high clock rates, this sum is the **critical path**. The usual fix is to pipeline the adder tree, inserting registers between its levels (you will do this in Exercise 3). The transposed form of section 7.5 avoids the problem altogether.

### Check your understanding: 7.4

1. How many multiplications per second does this design perform at a 200 MHz clock with a sample every cycle?
2. Why did exactly 31 outputs fail when the delay line was not reset?
3. The design has a latency of 4 clock cycles. Where is each of the 4 registers on the path from `x` to `y`?
4. A 128-tap version of this filter: how wide must the accumulator be, and how many levels of addition does the sum have?
5. Why is it acceptable for `prod` and `acc` to update on cycles when no valid sample is present?

#### Answers

1. 32 multiplications per sample × 200 million samples per second = **6.4 billion** per second.
2. Output n depends on samples n, n−1, …, n−31. For n = 0 to 30, some of those samples lie before the start, in unreset (`x`) registers. From n = 31 onward every tap holds a real sample. So outputs 0 to 30, **31 outputs**, are affected.
3. `taps[0]` (the input enters the delay line), `prod` (the product registers), `acc` (the sum register), and `y` (the output register after rounding). `out_valid` follows the same path through `v1`, `v2`, `v3`.
4. 16 + 18 + ⌈log₂ 128⌉ = **41 bits**; a balanced tree has **7** levels of addition.
5. Their values are only ever used when the matching valid bit is 1. On other cycles they hold meaningless values that nothing reads, so updating them costs nothing and keeps the logic simple.

## 7.5 Architecture 2: the transposed form

The transposed form computes the same sum in a different order. Instead of delaying the **input** and adding everything at the end, it multiplies the current input by every coefficient at once and delays the **partial sums**. Each register stage contains one multiplication and one addition, whatever the number of taps, so the filter is pipelined by construction.

### How the reordering works

Write the 4-tap case out. The direct form computes y\[n\] = h₀x\[n\] + h₁x\[n−1\] + h₂x\[n−2\] + h₃x\[n−3\] all at once. The transposed form keeps registered partial sums s₁, s₂, s₃, updated at every sample:

```latex
\begin{aligned}
s_3 &\leftarrow h_3\,x[n] \\
s_2 &\leftarrow h_2\,x[n] + s_3 \\
s_1 &\leftarrow h_1\,x[n] + s_2 \\
y[n] &= h_0\,x[n] + s_1
\end{aligned}
```

Follow the term that becomes h₃x\[n−3\]: three samples ago it entered s₃, then moved to s₂, then to s₁, and now it is added into y\[n\] together with h₀x\[n\], h₁x\[n−1\] and h₂x\[n−2\], which entered the chain more recently. The same products are added; only the order and the place of the registers differ.

> **Figure:** transposed-form FIR filter, 4 taps (shown in the [online version](https://claude.ai/artifact/NMsRDSNoi3mtNigMQRqwFg))

### The code

```systemverilog
`timescale 1ns/1ps
// fir_transposed.sv -- transposed-form FIR: every multiplier sees the same input sample,
// and a chain of registered partial sums replaces the delay line.
// Each stage: s[k] <= h[k]*x + s[k+1]. Critical path: one multiply + one add.
module fir_transposed #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int ACC_W = XW + CW + $clog2(N),
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  assign in_ready = 1'b1;

  logic signed [XW-1:0]    x_r;                     // registered input sample
  logic signed [ACC_W-1:0] s [1:N-1];               // registered partial sums
  logic signed [ACC_W-1:0] acc;                     // y before rounding
  logic                    v1, v2;

  always_ff @(posedge clk) begin
    if (in_valid) x_r <= x;
    if (rst) begin
      for (int k = 1; k < N; k++) s[k] <= '0;       // start at rest, like the model
    end else if (v1) begin
      // one new sample: every partial sum moves one step toward the output
      acc      <= ACC_W'(x_r * fir_coef(0)) + s[1];
      for (int k = 1; k < N - 1; k++)
        s[k]   <= ACC_W'(x_r * fir_coef(k)) + s[k+1];
      s[N-1]   <= ACC_W'(x_r * fir_coef(N - 1));     // the end of the chain adds nothing
    end
  end

  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) {v1, v2, out_valid} <= '0;
    else     {v1, v2, out_valid} <= {in_valid, v1, v2};
    if (v2) y <= y_c;
  end
endmodule
```

It passed bit-exactly on the first try after one Icarus-specific fix: the first version declared `s[1:N]` and drove the last element with `assign s[N] = '0;` while the loop wrote the others. Icarus 12 refused, `error: array 's' index must be a constant in this context`, because it cannot mix a continuous assignment and procedural writes on one unpacked array. Handling the last stage explicitly, as above, is clearer anyway. Result: `PASS: 3000 outputs bit-exact`, and three more seeds.

### What it costs and what it buys

- **The critical path no longer grows with N.** Each stage is one multiply and one add, so a 32-tap and a 1,000-tap transposed filter can run at the same clock frequency.
- **The partial sums are full-width registers.** The delay line of the direct form holds 31 × 16-bit samples; the transposed form holds 31 × 39-bit partial sums, more than twice the flip-flops.
- **One input drives every multiplier.** In a large filter, that one signal has a large fan-out, which can itself become a timing problem; designs that are long enough insert a few pipeline registers on the input broadcast.
- **The latency is shorter**: 3 cycles here instead of 4.

### A surprise in the synthesis report

Yosys reported only **16** DSP48E1 blocks for this design, not 32. Because every multiplier sees the same input `x_r`, and the coefficients are symmetric (h\[k\] = h\[31 − k\]), the products x·h\[k\] and x·h\[31−k\] are identical. The synthesizer noticed and computed each one once, finding the symmetric saving of section 7.6 by itself. On the other hand, Yosys 0.33 built all 31 adders and their 39-bit registers in fabric logic (315 `CARRY4`, about 1,200 flip-flops), rather than inside the DSP blocks. Vendor tools can pack each stage's adder and register into the DSP block, using the dedicated cascade connections between neighboring blocks, which is how high-speed FPGA FIR filters are usually built. Section 7.8 compares all four designs.

### Check your understanding: 7.5

1. In the 4-tap equations above, which partial sum holds the term h₂x\[n−1\] after sample n has been processed?
2. Why does the transposed form's maximum clock frequency not depend on N?
3. How many flip-flops do the partial sums of this 32-tap design need? Compare with the direct form's delay line.
4. Why did Yosys need only 16 multipliers for the transposed form, and why could it not do the same for the direct form?
5. The transposed form's latency is 3 cycles, the direct form's 4. Where did the cycle go?

#### Answers

1. After sample n, s₂ holds h₂x\[n\] + s₃ = h₂x\[n\] + h₃x\[n−1\]. The term h₂x\[n−1\] was in s₂ one sample earlier, and has now moved into **s₁** (s₁ = h₁x\[n\] + h₂x\[n−1\] + h₃x\[n−2\]). It will be added into y\[n+1\].
2. Each register is fed by exactly one multiplication and one addition, independent of how many stages there are. The direct form's sum has ⌈log₂ N⌉ levels of addition between two registers, which grows with N.
3. 31 partial sums × 39 bits = **1,209** flip-flops, versus 31 × 16 = **496** for the direct form's delay line (taps 1 to 31).
4. In the transposed form all multipliers share one input, so products with equal coefficients are literally the same computation and can be shared. In the direct form, equal coefficients multiply **different** samples (x\[n−k\] and x\[n−31+k\]), so the products differ. Sharing them needs the pre-addition of section 7.6.
5. The transposed form has no separate sum stage: the final addition (h₀x + s₁) happens in the same register stage as the multiplication, so the product register and the sum register of the direct form become one.

## 7.6 Architecture 3: the symmetric (folded) form

Because h\[k\] = h\[N−1−k\], the two products h\[k\]·x\[n−k\] and h\[N−1−k\]·x\[n−(N−1−k)\] use the same coefficient. Add the two samples first, then multiply once:

```latex
y[n] = \sum_{k=0}^{N/2-1} h[k] \left( x[n-k] + x[n-(N-1-k)] \right)
```

This halves the number of multipliers, from 32 to 16, at the cost of 16 extra adders. On an FPGA the extra adders are free: the DSP48E1 has a **pre-adder** in front of its multiplier for exactly this purpose.

```systemverilog
`timescale 1ns/1ps
// fir_symmetric.sv -- direct form that exploits h[k] = h[N-1-k]:
// add the two samples that share a coefficient first, then multiply once.
// N/2 multipliers instead of N. Requires even N and symmetric coefficients.
module fir_symmetric #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int ACC_W = XW + CW + $clog2(N),
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int H = N / 2;                         // number of coefficient pairs
  assign in_ready = 1'b1;

  logic signed [XW-1:0]    taps [0:N-1];
  logic signed [XW:0]      pre  [0:H-1];            // x[n-k] + x[n-(N-1-k)]: one bit wider
  logic signed [XW+CW:0]   prod [0:H-1];
  logic signed [ACC_W-1:0] sum_c, acc;
  logic                    v1, v2, v3, v4;

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < N; k++) taps[k] <= '0;
    end else if (in_valid) begin
      taps[0] <= x;
      for (int k = 1; k < N; k++) taps[k] <= taps[k-1];
    end
  end
  // stage 2: pre-adders (the DSP48E1's D + A pre-adder)
  always_ff @(posedge clk) begin
    for (int k = 0; k < H; k++) pre[k] <= (XW+1)'(taps[k]) + (XW+1)'(taps[N-1-k]);
  end
  // stage 3: half as many multipliers
  always_ff @(posedge clk) begin
    for (int k = 0; k < H; k++) prod[k] <= pre[k] * fir_coef(k);
  end
  // stage 4: sum
  always_comb begin
    sum_c = '0;
    for (int k = 0; k < H; k++) sum_c += ACC_W'(prod[k]);
  end
  always_ff @(posedge clk) acc <= sum_c;

  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) {v1, v2, v3, v4, out_valid} <= '0;
    else     {v1, v2, v3, v4, out_valid} <= {in_valid, v1, v2, v3, v4};
    if (v4) y <= y_c;
  end
endmodule
```

The width bookkeeping: the sum of two 16-bit samples needs **17 bits**, and the product of a 17-bit sum and an 18-bit coefficient needs **35 bits**. The DSP48E1's pre-adder takes a 25-bit input, so this fits comfortably. The pre-addition is exact, so the final sum, and the output, are identical to the direct form's: `PASS: 3000 outputs bit-exact` on the first run, and on three more seeds.

### What Yosys built

The synthesis report showed 16 DSP48E1 blocks, and the netlist confirms the pre-adder was used: in all 16, `USE_DPORT = "TRUE"` with the pre-adder register (`ADREG`) and the product register (`MREG`) enabled, and 15 of them also absorbed one register of the delay line into their A-input register pipeline (`AREG = 2`). The pre-add, multiply and their registers all live inside the DSP blocks. Only the delay line, the 16-input sum and the rounding remain in fabric.

### Limits of the trick

- It needs exactly symmetric coefficients. Window and Parks–McClellan designs always are; adaptive filters, whose coefficients change at run time, generally are not.
- An odd number of taps leaves one unpaired center tap, which gets its own multiplier: a 33-tap filter needs 17.
- It keeps the direct form's weakness: a large sum in one stage. The two ideas can be combined: real high-speed FIR implementations use a pre-adder **and** a pipelined, cascaded sum.

### Check your understanding: 7.6

1. How many multipliers does a symmetric 101-tap filter need?
2. Why does `pre` need one more bit than the samples?
3. A colleague says the symmetric form "loses accuracy because it adds before multiplying". Is that true?
4. Why does the transposed form get the symmetric saving "for free" from the synthesizer, while the direct form needs to be rewritten?
5. Which DSP48E1 inputs do the two samples and the coefficient use?

#### Answers

1. 50 pairs plus the center tap: **51**.
2. The sum of two 16-bit values can reach twice the largest 16-bit value: 32,767 + 32,767 = 65,534, which needs 17 bits signed. Without the extra bit, the pre-addition could wrap around.
3. **No.** With the extra bit, the pre-addition is exact, and multiplication distributes over addition exactly in integer arithmetic: h·(a + b) = h·a + h·b, bit for bit. The bit-exact test against the direct-form model proves it.
4. In the transposed form, the two products with equal coefficients multiply the **same** sample, so they are identical cells that the synthesizer merges. In the direct form, they multiply **different** samples, so they are different products. Only an algebraic rewrite, adding the samples first, makes them shareable.
5. The two samples go to the pre-adder's **A** and **D** inputs (both up to 25 bits; their 17-bit sum is still within 25), and the coefficient to the **B** input (18 bits).

## 7.7 Architecture 4: one multiplier, reused

When the clock is much faster than the sample rate, one multiplier can do all 32 multiplications of a sample, one per clock. This is the RTL method of Part 3 applied to DSP: a controller sequences a datapath, and the datapath is the Part 6 MAC unit, reused without a single change.

```systemverilog
`timescale 1ns/1ps
// fir_serial.sv -- time-multiplexed FIR: one MAC (mac.sv, Part 6) reused N times per sample.
// Controller: accept a sample, then feed taps 0..N-1 to the MAC, one per clock.
// Throughput: one sample per N+1 clocks. Uses valid/ready on the input.
module fir_serial #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int KW = $clog2(N);

  typedef enum logic {S_IDLE, S_RUN} state_t;
  state_t               state;
  logic [KW-1:0]        k;                         // which tap the MAC gets this cycle
  logic signed [XW-1:0] taps [0:N-1];

  assign in_ready = (state == S_IDLE);

  // ---- controller + delay line ----
  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;
      k     <= '0;
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else begin
      case (state)
        S_IDLE: if (in_valid) begin               // in_ready is 1 here: a transfer
          taps[0] <= x;
          for (int i = 1; i < N; i++) taps[i] <= taps[i-1];
          k     <= '0;
          state <= S_RUN;
        end
        S_RUN: begin
          k <= k + 1'b1;
          if (k == KW'(N - 1)) state <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  // ---- datapath: the Part 6 MAC, fed one tap per clock ----
  logic mac_ovf_unused;
  mac #(.A_W(XW), .A_F(XF), .B_W(CW), .B_F(CF), .ACC_W(XW + CW + KW + 1),
        .OUT_W(YW), .OUT_F(YF)) u_mac (
    .clk(clk), .rst(rst),
    .in_valid(state == S_RUN),
    .first(k == '0),
    .last(k == KW'(N - 1)),
    .a(taps[k]),
    .b(fir_coef(32'(k))),
    .out_valid(out_valid), .dout(y), .dout_ovf(mac_ovf_unused)
  );
endmodule
```

How it works, cycle by cycle:

1. In `S_IDLE`, `in_ready` is 1. When `in_valid` is also 1, the sample is accepted: it enters the delay line, the counter `k` is cleared, and the FSM moves to `S_RUN`.
2. In each of the 32 `S_RUN` cycles, the MAC receives `taps[k]` and `fir_coef(k)`, with `first` on k = 0 and `last` on k = 31. `taps[k]` with a variable `k` is a 32-to-1 multiplexer; `fir_coef(k)` with a variable `k` becomes a 32-entry coefficient ROM.
3. After `last`, the MAC's own pipeline (Part 6) rounds, saturates and outputs the result 4 cycles later, while the controller is already back in `S_IDLE` accepting the next sample.

The Part 6 MAC rounds once from its 40-bit accumulator to Q1.15 with the same `requant` settings, so the result is bit-identical to the other three architectures: `PASS: 3000 outputs bit-exact, 99007 clock cycles`. That is 3,000 samples × 33 cycles plus the start-up: one sample per **N + 1 = 33** clocks. (Exercise 4 removes the idle cycle.)

One tool difference appeared here. The first version passed the coefficient index as `fir_coef(int'(k))`. Icarus and Verilator accepted it, but Yosys 0.33 stopped with `syntax error, unexpected TOK_INT`: it does not support casts to type names. The size cast `32'(k)` means the same thing and works in all three tools. Test that a design **synthesizes**, not only that it simulates, before you call it finished.

### When to use it

The throughput drops by a factor of 33, so this design suits sample rates well below the clock rate: audio (48 kHz) on a 100 MHz FPGA leaves over 2,000 clocks per sample, enough to serve dozens of channels or a filter with hundreds of taps from one multiplier. Its synthesis report shows **one** DSP48E1, plus about 540 flip-flops, almost all of them the 32 × 16-bit delay line. Because that delay line is reset, Yosys must build it from flip-flops. Without the reset, FPGA tools can put it in the LUTs themselves as shift registers or small RAMs, at a fraction of the cost (Exercise 4).

### Check your understanding: 7.7

1. At a 100 MHz clock, what is the highest sample rate this design supports? How many taps could one multiplier handle at 48 kHz?
2. Why does `in_ready` come straight from the state, and why does that not break the valid/ready rules?
3. Why can the controller accept the next sample while the MAC is still finishing the previous result?
4. Why is the result bit-exact with the parallel architectures although the products are added in a completely different order?
5. What does `fir_coef(32'(k))` become in hardware?

#### Answers

1. 100 MHz / 33 ≈ **3.03 MHz**. At 48 kHz there are 100,000,000 / 48,000 ≈ 2,083 clocks per sample, so about **2,082 taps** with one idle cycle per sample.
2. The design can accept a sample exactly when it is idle, which depends only on its own state. `in_ready` does not depend on `in_valid`, so there is no combinational loop, and the source never waits for `in_ready` before raising `in_valid` (Part 3's rules).
3. The MAC is a pipeline: once the last product has entered it, the remaining work (accumulate, round, output) proceeds in later stages without needing the controller or the delay line. The next sample can shift the delay line immediately, because the MAC has already read the taps it needed.
4. Integer addition is exact and associative, and the accumulator is wide enough that nothing overflows. Any order of adding the same 32 exact products gives the same exact sum, and the single final rounding is identical.
5. A 32-entry ROM (a lookup table) of 18-bit constants, addressed by the 5-bit counter `k`. On an FPGA it maps to LUTs.

## 7.8 Comparing the four architectures

All four designs passed the same bit-exact test, so they are functionally identical; they differ only in cost and speed. The table summarizes them. Resource counts are from Yosys 0.33 (`synth_xilinx -family xc7 -flatten`, I/O buffers excluded), and latency and throughput from simulation.

|  | Direct | Transposed | Symmetric | Serial (one MAC) |
| --- | --- | --- | --- | --- |
| Samples per clock | 1 | 1 | 1 | 1/33 |
| Latency (clocks) | 4 | 3 | 5 | 35 |
| DSP48E1 blocks | 32 | 16 (merged by Yosys) | 16 | 1 |
| LUTs | 534 | 1,197 | 252 | 319 |
| Flip-flops | 539 | 1,237 | 517 | 556 |
| CARRY4 | 76 | 315 | 36 | 11 |
| Longest path between registers | 32-input sum (5 adder levels) | 1 multiply + 1 add | 16-input sum (4 adder levels) | 1 multiply + 1 add (inside the MAC) |
| Grows with N? | Path: yes (log₂ N) | Path: no | Path: yes (log₂ N/2) | Throughput: 1/(N+1) |

How to read it:

- **Symmetric** is the cheapest of the full-rate designs: half the DSP blocks of the direct form, and the fewest LUTs, because the pre-adders live inside the DSP blocks.
- **Transposed** has the best timing structure, but in this Yosys run its 31 wide adders and partial-sum registers ended up in fabric, which makes it the most expensive in LUTs and flip-flops. That is a tool result, not a law: with a tool that maps the adders into cascaded DSP blocks, the transposed form becomes both fast and cheap.
- **Serial** uses one DSP block and is the right answer whenever the clock is many times faster than the sample rate.

The **longest path** row is an analysis of each design's structure, not a measurement. As in Part 4, a real maximum frequency needs place-and-route timing analysis. Yosys's `ltp` depth measure, which worked for the small designs of Part 4, is not meaningful here: on generic gates it builds each multiplier from gates, while on the FPGA a multiplier is one DSP block, and the mapped netlist counts DSP blocks as if they had no internal registers.

### Choosing

For a given filter, start from the ratio of clock rate to sample rate:

1. **Clocks per sample ≥ N:** use one serial MAC (or a few, for several channels).
2. **Clocks per sample between 1 and N:** use several MACs in parallel, each handling a share of the taps. This is the general case of which "serial" and "parallel" are the two ends.
3. **One sample per clock:** use a fully parallel form, symmetric if the coefficients allow it, with the sum pipelined or cascaded for high clock rates.

### Does the hardware really filter? Measuring the response

The bit-exact tests prove that the RTL matches the fixed-point model. A separate question is whether the fixed-point filter still matches the **design**. To answer it, `measure_fir.py` sends 20 cosines of amplitude 0.9, from 0.0125 to 0.4875 cycles per sample, through the transposed RTL using the same testbench (so each run is also verified bit-exactly), and measures the gain with the projection method of Part 5:

```python
for f in np.round(np.arange(0.0125, 0.5, 0.025), 4):
    x = quantize(0.9 * np.cos(2 * np.pi * f * np.arange(N)), 16, 15)
    open("x.hex", "w").write("\n".join(to_hex(x, 16)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(golden(x, hq), 16)) + "\n")
    subprocess.run(["vvp", "-n", "msim", f"+N={N}"], check=True, capture_output=True)
    y = from_hex("y_actual.hex", 16)[200:]
    g = amplitude(y, f) / amplitude(x[200:], f)
    _, H = freqz(firwin(32, 0.2), worN=[2 * np.pi * f])
    print(f"{f:.4f} {20*np.log10(g):8.2f} {20*np.log10(abs(H[0])):8.2f}")
```

> **Figure:** measure\_fir.py on fir\_transposed.sv (Icarus 12.0), 4,000 samples per tone, amplitude 0.9 (shown in the [online version](https://claude.ai/artifact/NMsRDSNoi3mtNigMQRqwFg))

The measured gains match the floating-point design to within 0.05 dB through the passband and transition band, down to about −55 dB, and to within 0.6 dB down to −70 dB. Only at the two deepest points, near −81 and −83 dB, do the measurements differ by 0.6 and 1.6 dB. There the output signal is a fraction of an LSB of Q1.15, so the measurement is limited by the output rounding noise (about 82 dB below full scale, as predicted in Part 6), not by the filter.

### Check your understanding: 7.8

1. A 64-tap filter must run at 250 million samples per second on a 250 MHz clock. Which architecture, and roughly how many DSP blocks?
2. The same filter at 1 million samples per second on a 250 MHz clock?
3. At 25 million samples per second on 250 MHz, how many MACs are needed, and how many taps does each handle?
4. Why did the measured gain near −83 dB disagree with the design by 1.6 dB, while being within 0.1 dB at −40 dB?
5. Why measure the response at all, when the RTL is already proven bit-exact against the model?

#### Answers

1. One sample per clock: a parallel form. With symmetric coefficients, **32** DSP blocks (64 / 2), with a pipelined or cascaded sum to reach 250 MHz.
2. 250 clocks per sample ≥ 64 taps: **one** serial MAC, with about 185 cycles to spare.
3. 250 / 25 = 10 clocks per sample. 64 taps / 10 cycles: **7** MACs, each handling up to 10 taps (6 × 10 + 4). (With symmetric pre-adders, 32 coefficient pairs need only 4 MACs.)
4. A −83 dB output from a 0.9-amplitude input is about 6 × 10⁻⁵, roughly two LSBs of Q1.15. The output rounding (±½ LSB) is then a large fraction of the signal, so the measured amplitude is noisy. At −40 dB the output is about 300 LSBs, and rounding is negligible.
5. The bit-exact test proves the RTL equals the fixed-point model; it says nothing about whether that model still meets the specification. Coefficient quantization, rounding and saturation all change the response. The measurement checks the whole chain, from design intent to bits.

## 7.9 Exercises

For scale: their worked solutions add 6 design files, 2 testbenches and 2 Python scripts, about 500 new lines (not counting short checks run inline). Time depends too much on experience for a reliable estimate, so none is given. Every RTL exercise uses the shared testbench and `run_fir.sh`, plus a Yosys report. Send me your code, tables and plots.

- [ ] Exercise 1: design to a specification
- [ ] Exercise 2: a high-pass filter with an odd length
- [ ] Exercise 3: pipeline the direct form's sum
- [ ] Exercise 4: a better serial filter
- [ ] Exercise 5: two MACs in parallel

### Exercise 1: design to a specification

Specification: f\_s = 48 kHz, passband up to 4 kHz, stopband from 6 kHz, at least 60 dB stopband attenuation, passband ripple below 0.1 dB.

- Use `kaiserord` to choose the length and β, then `firwin` with the Kaiser window. Plot the response in dB and check every requirement numerically, not by eye.
- Repeat with `scipy.signal.remez` and find the shortest length that meets the specification. How many taps does it save?
- Choose the coefficient width as in Part 6, section 6.6, for 16-bit input and output. Then generate the coefficient file and run your filter on the symmetric architecture (extend it for odd N if needed: the center tap has no partner).

### Exercise 2: a high-pass filter with an odd length

- Design `firwin(33, 0.5, pass_zero=False)`: 33 taps, a high-pass filter with cutoff at 0.25 cycles per sample. Why must the length be odd (section 7.2)?
- Implement it with the direct form (set N = 33) and verify it bit-exactly.
- Measure its response on the RTL with `measure_fir.py` and plot it over the design curve. What is its gain at 0 Hz?

### Exercise 3: pipeline the direct form's sum

The direct form adds 32 products in one stage. Replace that with a pipelined adder tree: 16 sums, register, 8 sums, register, 4, register, 2, register, 1.

- Write it with a `generate` loop over the levels, so that it works for any N that is a power of 2.
- Delay `v3` through the extra stages so `out_valid` still marks the right outputs. The testbench needs no change, because the monitor does not depend on latency.
- What is the new latency? How many extra flip-flops did the pipeline cost (count them by hand, then compare with Yosys)?

### Exercise 4: a better serial filter

Improve `fir_serial` in two ways, one at a time, keeping it bit-exact:

1. **Remove the idle cycle**: accept the next sample during the last `S_RUN` cycle, so the throughput becomes exactly one sample per N clocks. Check the clock count reported by the testbench.
2. **Replace the shifting delay line with a circular buffer**: write each new sample into a 32-entry memory at a write pointer, and read the taps at (pointer − k), so no data moves. Then the memory needs no reset if you instead initialize it by writing 32 zeros after reset. Synthesize both versions: what happens to the flip-flop count, and what does Yosys use instead?

### Exercise 5: two MACs in parallel

Build `fir_serial2`, which uses **two** `mac` instances: one handles taps 0 to 15, the other taps 16 to 31, and an adder combines their exact sums (take the accumulators before rounding, by adding an output for them to a copy of the MAC).

- Its throughput should be one sample every 17 clocks (or 16, after Exercise 4). Verify bit-exactly.
- Why must the two partial sums be added **before** rounding, not after?
- Generalize: with M MACs, what is the throughput, and when does it become worth switching to a fully parallel form?

## 7.10 Summary and what comes next

You have designed an FIR filter, built it four ways, proved all four bit-exact against one model, and measured the result against the original design. Keep this table beside you for the exercises.

| Topic | Key fact | Remember |
| --- | --- | --- |
| Window method | Ideal sinc × window = coefficients | `firwin` cutoff is relative to Nyquist |
| Window choice | Deeper stopband ↔ wider transition | Kaiser's β slides along the trade-off |
| Length estimate | N ≈ (A − 8) / (2.285 · 2πΔf) + 1 | Halving Δf doubles N |
| Linear phase | Symmetric h: delay (N−1)/2 for all frequencies | Even N cannot be high-pass |
| Coefficient file | Generated `fir_coef(k)` function | Never edit generated files |
| Starting state | The model assumes zeros | Reset the delay line, or ignore start-up outputs |
| Direct form | Delay line + N multipliers + big sum | Sum depth grows as log₂ N |
| Transposed form | Same input to all multipliers, registered partial sums | One multiply + one add per stage |
| Symmetric form | Pre-add equal-coefficient pairs | N/2 multipliers, uses the DSP pre-adder |
| Serial form | One MAC, N cycles per sample | Choose by clocks per sample |
| Verification | Same expected output for every architecture | Exact sums + one rounding |
| Validation | Measure the RTL's response with sine sweeps | Checks the fixed-point design, not just the RTL |

The ideas that matter most from this part:

1. The architecture is a separate decision from the filter: the same coefficients can be built for speed, for area, or anywhere in between.
2. If every intermediate result is exact and the rounding happens once, all architectures are bit-identical, and one model verifies them all.
3. Synthesis reports reveal what the tool actually did: merged multipliers, pre-adders used, adders left in fabric. Read them.
4. Verification proves the RTL equals the model; measurement proves the model meets the specification. You need both.

**Part 8: IIR filters** adds feedback. You will learn the z-transform properly, see why poles near the unit circle give sharp filters with very few multipliers, and why feedback makes fixed-point arithmetic dangerous: coefficient quantization can move poles, rounding can cause limit cycles, and overflow can cause oscillation. You will build a biquad section, cascade several of them into a sharp low-pass filter, and compare its cost with the FIR filters of this part.

### Further reading: FIR filters without multipliers

Every FIR in this part multiplies. [Part 14: More DSP Structures](https://claude.ai/artifact/V3up8RZjK314g2yFkPZiiK) shows two ways to avoid it, both verified bit-exactly against the same kind of model: constant coefficients recoded as canonical signed digits and built from shifts and adds (14.1), and distributed arithmetic, which replaces the multipliers with small tables and processes one bit of every sample per clock (14.2).
