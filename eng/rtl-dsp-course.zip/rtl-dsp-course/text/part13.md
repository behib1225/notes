# Verilog & RTL for DSP — Part 13: From Simulation to Hardware

*Markdown export of the online document: https://claude.ai/artifact/Ms1SzQtcuXeZ5H8UjsXZPk. Diagrams and charts appear only online; each is marked below with its title.*


Oct 22, 2026 · @Behi

## 13.0 What this part adds

Parts 1 to 12 stop at a design that simulates bit-exactly and synthesizes. Four things stand between that and working hardware, and the course did not cover them:

1. **Timing.** Synthesis reports logic depth, not timing. Whether a design runs at its intended clock is known only after **place and route**, and the answer for the Part 12 DDC was a surprise (13.1).
2. **Standard interfaces.** The course's blocks use their own valid/ready conventions, and the DDC detects overruns instead of preventing them. Industry DSP blocks talk **AXI4-Stream** (13.2).
3. **Proof instead of samples.** Random simulation checks the cases it happens to generate. **Formal verification** proves a property for every input sequence (13.3).
4. **More than one clock.** Real systems take samples on one clock and process them on another. Crossing between them needs structures that a single-clock simulation cannot fully check (13.4).

### Two more free tools

- **nextpnr** places and routes designs for FPGAs whose internal databases are open. The AMD (Xilinx) 7-series targeted elsewhere in the course is not among the devices it supports well, so this part uses a **Lattice ECP5** (LFE5U-25F, package CABGA381), a common low-cost FPGA with 18 × 18 multipliers (MULT18X18D) and 18-kbit block RAMs (DP16KD). It installs from PyPI as a WebAssembly build, with no compilation: `pip install yowasp-nextpnr-ecp5`, then run `yowasp-nextpnr-ecp5`. Yosys 0.33 synthesizes for it with `synth_ecp5`.
- **z3** is an SMT solver. Yosys ships `yosys-smtbmc`, which turns a design and its properties into solver queries; it needs a `z3` executable, available from the system's packages (`apt-get install z3` on Ubuntu). The SymbiYosys front end (`sby`), often used with it, is not needed: a three-line script does the same job here.

**Every number in this part comes from running these tools**: Icarus Verilog 12.0, Verilator 5.020, Yosys 0.33, nextpnr-ecp5 (YoWASP 0.11) and z3 4.8.12. Timing numbers are specific to this device and these tool versions; on another FPGA family the critical paths and achievable frequencies are different, which is exactly why they must be measured.

## 13.1 Timing closure

### The flow

```sh
yosys -q -p "read_verilog -sv ddc.sv mixer.sv nco.sv cic_decim.sv fir_decim.sv mac.sv requant.sv; synth_ecp5 -top ddc -json ddc.json"
yowasp-nextpnr-ecp5 --25k --package CABGA381 --json ddc.json --freq 100 --seed 1 > pnr.log 2>&1
grep "Max frequency" pnr.log
```

`--freq 100` is the timing constraint: a 100 MHz clock, so every path from one register to the next must fit in 10 ns, including the delay of the wires the placer and router chose. `--seed` changes the random start of the placement; different seeds give different, equally valid placements, and the achieved frequency varies between them.

### The Part 12 DDC: 44 MHz, not 100

The course assumed a 100 MHz clock throughout Part 12, but never checked it. On this device:

```text
ERROR: Max frequency for clock '$glbnet$clk$TRELLIS_IO_IN': 44.20 MHz (FAIL at 100.00 MHz)
```

The report names the slowest path, 22.6 ns from register to register:

| Step | Delay |
| --- | --- |
| Sine table (block RAM) clock-to-output | 5.61 ns |
| Route to the multiplier | 1.73 ns |
| 18 × 18 multiplier | 3.93 ns |
| Negation, rounding and saturation (carry chains, LUTs) and routing | about 11 ns |

All of it is in the mixer of Part 9, written for clarity, with the table read, the multiplication and `requant`'s rounding all in one clock cycle. This is the normal state of a design that has only been simulated: nothing in an RTL simulation measures delay.

On the AMD 7-series that the rest of the course targets, the DSP48E1 contains optional registers that the tools can fill from surrounding logic, so the same RTL may fare differently there; the lesson does not change, because the only way to know is to run place and route for the actual device.

### Fix 1: pipeline the mixer

`mixer_p.sv` adds two register stages: the table outputs are registered once more (a block RAM's optional output register), and the products are registered before the rounding:

```systemverilog
  always_ff @(posedge clk) begin
    if (rst) begin v2 <= 1'b0; v3 <= 1'b0; end
    else     begin v2 <= lo_valid; v3 <= v2; end
    if (in_valid) x_d <= x;
    if (lo_valid) begin lc <= lo_cos; ls <= lo_sin; x2 <= x_d; end     // stage 2: table output register
    if (v2) begin pi_r <= x2 * lc; pq_r <= -(x2 * ls); end            // stage 3: product register
  end
```

followed by the two `requant` instances and the output register (stage 4). A valid bit travels with the data through each stage. **Every output value is unchanged**, only later, so the Part 12 model still applies: the DDC with this mixer passed the hardened testbench of the Part 12 solutions (two seeds, bit-exact, with the independent check).

Result: **50.0 MHz**. The mixer is no longer the slowest path; the CIC is.

### Fix 2: pipeline the CIC's combs

The new critical path ran through the CIC's comb section: five 31-bit subtractions in series, each feeding the next, then the rounding, all in one cycle. The combs work only once per output sample, and the next output sample is at least 8 clocks away, so the chain can be spread over several clocks. In `cic_decim_p.sv`, each comb stage is a register, triggered by a valid bit that travels with the data:

```systemverilog
      // stage 0: sample the last integrator BEFORE this input's update (as cic_decim does)
      cv[0] <= dec;
      if (dec) cs[0] <= integ[NS-1];
      // comb stage k: one subtraction per clock, triggered by its valid bit
      for (int k = 0; k < NS; k++) begin
        cv[k+1] <= cv[k];
        if (cv[k]) begin
          cs[k+1]   <= cs[k] - comb_d[k];
          comb_d[k] <= cs[k];
        end
      end
```

Each stage performs exactly the arithmetic of the combinational chain, once per output sample, in the same order, so the outputs are identical; again, bit-exact on two seeds.

### Result

| Version | Max frequency (seed 1) | Flip-flops | LUT cells | Multipliers | Block RAMs |
| --- | --- | --- | --- | --- | --- |
| Part 12 DDC | 44.2 MHz | 2,013 | 4,896 | 4 | 2 |
| + pipelined mixer | 50.0 MHz |  |  | 4 | 2 |
| + pipelined combs | **101.6 MHz** | 2,455 | 4,908 | 4 | 2 |

442 extra flip-flops (2,013 to 2,455), and almost no extra logic, more than double the clock frequency. But one seed is not a result. Three placement seeds:

| Seed | 1 | 2 | 3 |
| --- | --- | --- | --- |
| Max frequency | 101.58 MHz | 101.25 MHz | **98.04 MHz (fails)** |

After these two fixes the design meets 100 MHz on only **two placements of three**: marginal, not closed. A design that passes only with a lucky placement will fail when anything changes.

### Fix 3: split the rounding, and move a negation

The failing path of seed 3 was again a rounding and saturation step, inside the FIR's MAC: from the accumulator through `requant`'s rounding adder, comparison and multiplexer, about 10.2 ns. The same structure follows every multiplier, so the fix goes into `requant` itself. `requant_p.sv` registers the rounded value and saturates in the next cycle:

```systemverilog
  logic signed [RW-1:0] rounded_r;             // the pipeline register between the two stages
  assign rounded = floor_v + RW'(round_up);
  always_ff @(posedge clk) if (en) rounded_r <= rounded;
  assign rounded_c = CW'(rounded_r);           // sign-extend if the output is wider
```

It replaces `requant` in the MAC (`mac_p.sv`, used by `fir_decim_p.sv`), the mixer and the CIC, each gaining one cycle of latency and no change in value. With it, all five seeds passed (100.9 to 107.0 MHz), and the slowest path became the mixer's Q product, `pq_r <= -(x2 * ls)`: the 18 × 18 multiplier followed by the carry chain of the negation, 9.9 ns. Negating the sine one stage earlier removes that carry chain from the multiplier's path:

```systemverilog
    if (lo_valid) begin lc <= lo_cos; ls <= -lo_sin; x2 <= x_d; end
    if (v2) begin pi_r <= x2 * lc; pq_r <= x2 * ls; end               // stage 3: product register
```

This is exact only because the table's values lie in −32,767 to 32,767 (checked): the negation of −32,768 would not fit in 16 bits. The final design, `ddc_p2.sv`, passed the hardened testbench bit-exactly on three seeds and with an FCW change, the independent check and the specification checks, and is lint-clean.

### Timing closed

| Seed | 1 | 2 | 3 | 4 | 5 |
| --- | --- | --- | --- | --- | --- |
| Max frequency | 109.93 MHz | 118.33 MHz | 106.38 MHz | 112.20 MHz | 119.33 MHz |

**All five placements pass 100 MHz**; the worst has 6.4% of margin. That is closed, though below the 10 to 15% margin a common rule of thumb asks for (Exercise 1). The whole progression:

| Version | Worst of the seeds tried | Flip-flops | LUT cells | Multipliers | Block RAMs |
| --- | --- | --- | --- | --- | --- |
| Part 12 DDC | 44.2 MHz (1 seed) | 2,013 | 4,896 | 4 | 2 |
| + pipelined mixer | 50.0 MHz (1 seed) |  |  | 4 | 2 |
| + pipelined combs | 98.04 MHz (3 seeds) | 2,455 | 4,908 | 4 | 2 |
| + two-stage rounding, earlier negation | **106.38 MHz (5 seeds)** | 2,578 | 4,892 | 4 | 2 |

565 extra flip-flops, and no extra multipliers or memory, took the design from 44 to over 106 MHz, every output bit unchanged. These figures are for the Lattice ECP5 with nextpnr; on another device both the critical paths and the frequencies differ, which is exactly why they must be measured there.

**What this section teaches** is the method more than the numbers: measure after place and route, read the critical path, move a register to cut it, re-verify bit-exactly, and repeat on several seeds until every one passes with some margin (a common rule of thumb is 10 to 15% above the target).

## 13.2 AXI4-Stream

### The rules

AXI4-Stream, part of Arm's AMBA specifications, is the interface that FPGA vendors' DSP blocks and most third-party IP use for streaming data. Its core is the valid/ready handshake you already know from Part 3, with a few precise rules:

- **`tdata`** carries the word, **`tvalid`** says the source offers it, **`tready`** says the sink can take it. A **transfer** happens at a rising clock edge where both `tvalid` and `tready` are 1.
- **`tlast`** marks the last word of a packet (a block of FFT samples, a line of an image).
- **Once a source raises `tvalid`, it must keep it high, with `tdata` and `tlast` unchanged, until the transfer happens.** It may not withdraw or change an offer.
- **A source must not wait for `tready` before raising `tvalid`.** `tready` may depend on `tvalid`, but not the other way round; this rules out deadlock between two blocks that each wait for the other.

Compared with the course's blocks: `fir_decim` already behaves like an AXI sink (it lowers `in_ready` while computing), but `cic_decim` and the DDC have no way to slow their source down; the DDC detects an overrun instead of preventing it. An AXI version propagates `tready` backward so that a slow stage throttles the stages before it.

### Why a register slice needs two registers

In a long chain of AXI blocks, `tready` travels backward through every stage combinationally, and becomes the critical path. Registering it seems simple, but there is a catch: if `s_tready` is a register, it was computed a cycle ago, so the sink side has promised to accept a word **before** knowing that its own output stalls. It needs a second place to put that word. That is the **skid buffer**:

```systemverilog
  assign s_tready = !skid_valid;                 // a register output: no combinational path from m_tready

  always_ff @(posedge clk) begin
    if (rst) begin
      m_tvalid <= 1'b0;  skid_valid <= 1'b0;
    end else if (m_tready || !m_tvalid) begin    // the output register may load
      if (skid_valid) begin                      // the skid word goes first (keeps the order)
        m_tdata <= skid_data;  m_tlast <= skid_last;  m_tvalid <= 1'b1;  skid_valid <= 1'b0;
      end else if (s_tvalid) begin               // s_tready is 1 here
        m_tdata <= s_tdata;    m_tlast <= s_tlast;    m_tvalid <= 1'b1;
      end else begin
        m_tvalid <= 1'b0;
      end
    end else if (s_tvalid && s_tready) begin     // output stalled: park the accepted word
      skid_data <= s_tdata;  skid_last <= s_tlast;  skid_valid <= 1'b1;
    end
  end
```

The output register `m_tdata` is the normal pipeline register. The skid register catches the one word accepted in the cycle in which the output stalled; while it is full, `s_tready` is 0. When the output frees up, the skid word goes first, so the order is kept. Both `s_tready` and every output are register outputs: the slice cuts every combinational path through it, in both directions, at full throughput.

### Verification by simulation

The testbench drives a counting sequence with a random `tvalid` (80% of cycles, holding each offer until accepted, as the rules require) and a random `m_tready`. It checks the order and `tlast` of every word, and the AXI rule on the output: a valid word that is not taken must stay unchanged in the next cycle.

| `m_tready` probability | Result (20,000 words) | Clock cycles | Output valid |
| --- | --- | --- | --- |
| 100% | PASS, in order | 24,909 | 80% of cycles |
| 70% | PASS, in order | 31,315 | 91% |
| 50% | PASS, in order | 41,469 | 96% |
| 30% | PASS, in order | 67,745 | 99% |

With the output always ready, the output is valid 80% of the time, exactly the source's offer rate: the slice adds no bubbles. The module is lint-clean. Random tests, however, only show that 20,000 particular sequences worked; the next section proves it for all of them.

## 13.3 Formal verification

### The idea

A formal tool does not run test vectors. It translates the design and a set of **properties** into logic formulas and asks a solver: is there **any** sequence of inputs, from reset, that violates a property? Two questions are asked:

- **Bounded model check (BMC)**: is there a violation within the first k cycles after reset? If not, the design is correct for every input sequence up to k cycles long.
- **k-induction**: if the properties hold for k consecutive cycles, starting from **any** state, must they hold in the next one? If yes, together with the BMC, the properties hold forever.

Inputs are free: the solver chooses them. **Assumptions** (`assume`) restrict them to legal behavior (here: the source obeys AXI); **assertions** (`assert`) are what must be proved.

### The harness

The properties live in a separate module that instantiates the design:

```systemverilog
module axis_skid_formal (
  input logic clk,
  input logic rst,
  input logic s_tvalid, m_tready
);
  logic        s_tready, m_tvalid, m_tlast, s_tlast;
  logic [15:0] s_tdata, m_tdata;
  logic [15:0] n_in = '0, n_out = '0;         // words accepted, words delivered
  logic        f_skid_valid, f_skid_last;      // the formal-only ports of axis_skid
  logic [15:0] f_skid_data;
  axis_skid #(.W(16)) dut (.*);

  assign s_tdata = n_in;                       // word i carries i ...
  assign s_tlast = n_in[0];                    // ... and an alternating last flag

  logic init = 1'b1;
  always @(posedge clk) begin
    init <= 1'b0;
    if (rst) begin n_in <= '0; n_out <= '0; end
    else begin
      if (s_tvalid && s_tready) n_in  <= n_in + 1'b1;
      if (m_tvalid && m_tready) n_out <= n_out + 1'b1;
    end
  end
  always @(*) if (init) assume (rst);

  logic [15:0] inside;
  assign inside = n_in - n_out;
  always @(*) if (!init && !rst) begin
    assert (inside <= 16'd2);                  // never more than two words inside
    assert (m_tvalid == (inside != 16'd0));    // valid exactly when something is inside
    assert (s_tready == (inside != 16'd2));    // ready exactly when there is room
    if (m_tvalid) assert (m_tdata == n_out && m_tlast == n_out[0]);   // the right word, in order
    // internal invariant, needed for induction: the parked word is the one after the output word
    if (f_skid_valid) assert (f_skid_data == n_out + 16'd1 && f_skid_last == !n_out[0]);
  end
  // a valid source word is held until accepted (our source holds it by construction: s_tdata = n_in)
  always @(posedge clk) if (!init && !$past(rst) && $past(s_tvalid && !s_tready)) assume (s_tvalid);
  // the output obeys AXI: a valid word stays valid and unchanged until taken
  always @(posedge clk) if (!init && !$past(rst) && $past(m_tvalid && !m_tready))
    assert (m_tvalid && m_tdata == $past(m_tdata) && m_tlast == $past(m_tlast));
endmodule
```

The trick that makes data checking easy is the **counting source**: word i carries the value i. Then "the output carries `n_out`, the number of words delivered so far" proves at once that nothing is lost, duplicated or reordered. (For a design that only moves data, as this one does, the result for counting data carries over to any data.)

### Running it

```sh
#!/bin/sh
# run_formal.sh -- bounded model check and k-induction of a harness with yosys + yosys-smtbmc + z3
# Usage: ./run_formal.sh harness.sv design.sv top depth
set -e
H=$1; D=$2; TOP=$3; K=${4:-20}
yosys -q -p "read_verilog -sv -formal $D $H; prep -top $TOP; async2sync; dffunmap; write_smt2 -wires $TOP.smt2"
echo "-- bounded model check, $K cycles:"; yosys-smtbmc -s z3 -t "$K" "$TOP.smt2" | tail -1
echo "-- k-induction, $K cycles:";         yosys-smtbmc -s z3 -i -t "$K" "$TOP.smt2" | tail -1
```

`read_verilog -formal` enables `assert`, `assume` and `$past()` and defines the macro `FORMAL`; `write_smt2` produces the solver model; `yosys-smtbmc` runs the two checks.

### Results, and two lessons from getting there

| Design | Bounded check, 20 cycles | k-induction, 20 cycles |
| --- | --- | --- |
| `axis_skid` | **PASSED** | **PASSED** |
| Broken copy (`s_tready` always 1) | FAILED at step 3 | FAILED |

The correct design is proved for all time; the broken one, which accepts a word while both registers are full, is caught within three cycles, and `yosys-smtbmc --dump-vcd cex.vcd` writes the failing trace for a waveform viewer.

**Lesson 1: Yosys does not resolve hierarchical names.** The first harness used `dut.skid_valid` to look inside the design. Yosys read it as a new, undriven wire (`Warning: Identifier '\dut.skid_valid' is implicitly declared.`), and the check failed for a reason that had nothing to do with the design. The fix is a **formal-only port**, which simulation and synthesis never see:

```systemverilog
  output logic         m_tlast
`ifdef FORMAL                                    // formal-only view of the skid register
  , output logic         f_skid_valid,
    output logic [W-1:0] f_skid_data,
    output logic         f_skid_last
`endif
);
```

**Lesson 2: induction needs invariants.** With only the port-level properties, the bounded check passed but induction failed. Induction starts from any state that satisfies the assertions for k cycles, including unreachable ones: here, a skid register holding a wrong word while the output stalls for more than k cycles, which no port-level property can see. Adding the internal invariant (the parked word is the one after the output word) excludes those states, and induction passes. Finding such invariants is the real work of formal verification; when induction fails, the counterexample shows which unreachable state needs excluding.

## 13.4 Crossing clock domains

### The problem

An ADC delivers samples on its own clock; the DSP runs on another; the two have no fixed phase relationship. A flip-flop sampling a signal from the other domain can catch it mid-change and go **metastable**: its output hovers between 0 and 1 for an unpredictable time before settling. Part 2's two-flip-flop synchronizer handles one bit: the second flip-flop gives the first a full cycle to settle. A **multi-bit** value cannot be synchronized bit by bit, because the bits may settle to a mixture of the old and new values that is neither.

The standard structure for passing a stream of words between domains is the **asynchronous FIFO**: a small memory written in one domain and read in the other, with the write and read pointers passed across in **Gray code**.

### Gray-coded pointers

In Gray code, consecutive values differ in **exactly one bit** (0, 1, 3, 2, 6, 7, 5, 4, …, computed as b ⊕ (b >> 1)). A pointer that advances by one changes one bit, so a synchronizer that samples it mid-change sees either the old or the new pointer, never a third value. Both outcomes are safe: an old read pointer only makes the writer think the FIFO is fuller than it is, an old write pointer only makes the reader think it is emptier. The FIFO is **conservative**, never wrong.

The pointers have one bit more than the address. With 2^AW words, the FIFO is **empty** when the two pointers are equal, and **full** when they differ only in the top bit, which in Gray code means the top **two** bits inverted and the rest equal:

```systemverilog
  // ---- write domain ----
  assign wbin_next  = wbin + (AW+1)'(w_en && !w_full);
  assign wgray_next = bin2gray(wbin_next);
  always_ff @(posedge wclk) begin
    if (wrst) begin wbin <= '0; wgray <= '0; rgray_w1 <= '0; rgray_w2 <= '0; w_full <= 1'b0; end
    else begin
      if (w_en && !w_full) mem[wbin[AW-1:0]] <= w_data;
      wbin <= wbin_next;  wgray <= wgray_next;
      {rgray_w2, rgray_w1} <= {rgray_w1, rgray};               // synchronize the read pointer
      // full: the next write pointer equals the read pointer with the top two bits inverted
      w_full <= (wgray_next == {~rgray_w2[AW:AW-1], rgray_w2[AW-2:0]});
    end
  end

  // ---- read domain ----
  assign rbin_next  = rbin + (AW+1)'(r_en && !r_empty);
  assign rgray_next = bin2gray(rbin_next);
  always_ff @(posedge rclk) begin
    if (rrst) begin rbin <= '0; rgray <= '0; wgray_r1 <= '0; wgray_r2 <= '0; r_empty <= 1'b1; end
    else begin
      rbin <= rbin_next;  rgray <= rgray_next;
      {wgray_r2, wgray_r1} <= {wgray_r1, wgray};               // synchronize the write pointer
      r_empty <= (rgray_next == wgray_r2);
    end
  end
  assign r_data = mem[rbin[AW-1:0]];                           // first-word fall-through
```

The memory has no reset (section 4.6's rule), and its read is combinational, so it becomes LUT RAM: Yosys builds the 16 × 16-bit FIFO from 3 RAM32M cells, 21 LUTs and 40 flip-flops. The design is lint-clean.

### Verification

The testbench runs two free-running clocks with unrelated periods. The writer sends a counting sequence on its clock whenever the FIFO is not full; the reader checks every word it takes on its clock:

| Write clock half-period | Read clock half-period | Write / read activity | Result (20,000 words) | Most words in flight |
| --- | --- | --- | --- | --- |
| 5.000 ns | 3.650 ns | 50% / 50% | PASS | 15 |
| 3.650 ns | 5.000 ns | 50% / 50% | PASS | 16 (full) |
| 5.000 ns | 11.700 ns | 90% / 95% | PASS | 16 (full) |
| 11.700 ns | 5.000 ns | 95% / 90% | PASS | 3 |
| 5.000 ns | 5.100 ns | 100% / 100% | PASS | 13 |

The runs reach the full condition (16 words) and the empty condition many times, in both rate directions and with nearly equal clocks, without losing, repeating or reordering a word.

### What simulation cannot show

These passing runs prove the **logic** of the FIFO: the pointers, the Gray coding, the full and empty conditions. They prove nothing about metastability, because an RTL simulator has no notion of it: every flip-flop samples a clean 0 or 1, and a synchronized multi-bit **binary** pointer, the classic mistake, passes these same tests: a copy of the FIFO that synchronizes its binary pointers instead of Gray-coded ones passed all five runs above, although in hardware it would occasionally see a pointer value that never existed. Three things beyond simulation make a real crossing safe:

1. **Structure**, checked by review or by a clock-domain-crossing lint tool: every signal crossing between domains goes through a synchronizer, and multi-bit values only cross in Gray code or through a handshake.
2. **Timing constraints**: the paths into the first synchronizer flip-flop must be excluded from normal timing analysis, or limited with a maximum-delay constraint, in the tool's constraint language.
3. **Placement**: the synchronizer's two flip-flops placed close together, for the most settling time (AMD tools, for example, use the `ASYNC_REG` attribute for this).

The probability of failure is then not zero but extremely small, and it falls exponentially with the settling time the second flip-flop provides.

### A bounded formal check

The FIFO was also checked formally, with both clocks free: Yosys's `clk2fflogic` pass turns the two clocks into ordinary signals sampled by one formal global clock, so the solver can choose any interleaving of their edges. A harness (`async_fifo_formal.sv`, 4-word FIFO, counting source) asserts that there are never more words inside than places, and that the reader always sees the next word in order. The result is **bounded only**: no counterexample within the first 24 global steps (about 16 after reset), at which point the run was stopped because each further step took the solver longer. That covers full and empty, and many interleavings of the two clocks, but it is not a proof for all time, and, like simulation, it says nothing about metastability.

## 13.5 Reset strategy

### The question

The course resets everything synchronously: `if (rst)` inside `always_ff @(posedge clk)`. That is the right default inside a clock domain, but it leaves two questions open: where does `rst` itself come from, and what happens when two clock domains are reset separately?

### A reset synchronizer

An external reset (a button, a supply monitor, another chip) is asynchronous to every clock. If it simply ends at an arbitrary moment, some flip-flops of a domain may leave reset on one clock edge and others on the next, which can start a state machine in an impossible state. The standard cure is a **reset synchronizer**: reset is applied asynchronously, at once, even without a running clock, and released synchronously, on a clock edge, through two flip-flops:

```systemverilog
module rst_sync (
  input  logic clk,
  input  logic arst,          // external reset, asynchronous, active high
  output logic rst            // reset for the clk domain: async assert, sync release
);
  logic r1;
  always_ff @(posedge clk or posedge arst) begin
    if (arst) begin r1 <= 1'b1; rst <= 1'b1; end
    else      begin r1 <= 1'b0; rst <= r1;   end
  end
endmodule
```

Simulated with a 10 ns clock (rising edges at 5, 15, 25, … ns):

| Event | `rst` |
| --- | --- |
| `arst` rises at 2 ns, between edges | rises **at 2 ns**, at once |
| `arst` falls at 33 ns | falls at **45 ns**, the second edge after the release |
| a 1 ns glitch on `arst` at 93 ns | rises at 93 ns, falls at 105 ns |

Yosys maps it to two flip-flops with asynchronous preset (FDPE). The last row is a warning: even a 1 ns glitch resets the whole domain, so an external reset input is normally filtered or debounced first. Each clock domain gets its own synchronizer, fed from the same external reset.

### Reset both sides of a crossing together

The asynchronous FIFO of 13.4 has a reset on each side. Resetting only one side is a real failure, not a theoretical one. The FIFO testbench was run with a reset in the middle of the stream:

| Reset at 20.1 µs | Result |
| --- | --- |
| Write side only | **FAILED**: the read side still holds its old pointer, sees a FIFO that looks non-empty, and re-reads stale words (989, 990, … where 1005 was expected) |
| Both sides together | PASS: 20,000 words in order |

The rule: reset both sides of every crossing from the same source, each through its own synchronizer, and hold the reset long enough for the slower clock to see it on several edges.

## 13.6 Exercises

### Exercise 1: a 10% timing margin

Section 13.1 closed timing at 100 MHz with 6.4% of margin on the worst of five placements (seed 3, 106.38 MHz).

- Read the critical path of seed 3 in the nextpnr report, find which block it belongs to, and cut it with one more register stage. Keep every output bit-exact (`run_part13.sh` checks that).
- Place and route with at least five seeds again. Stop when every seed passes 110 MHz, and report the cost in flip-flops of the whole progression from 44 MHz.

### Exercise 2: an AXI4-Stream DDC

Give the DDC AXI4-Stream ports: `s_axis` for the real input, `m_axis` for the complex output (I and Q packed into a 32-bit `tdata`).

- Make the FIR's `in_ready` propagate backward, so that the DDC lowers `s_tready` instead of raising `overrun`. (The CIC must then stop accepting input while the FIR is busy, or have a small FIFO in front of the FIR; decide which, and why.)
- Put an `axis_skid` on the output, test with a random `m_tready`, and show that no sample is lost at any input rate.

### Exercise 3: prove a FIFO

Write a formal harness for a **single-clock** version of the FIFO (one clock for both sides; the same pointers, without synchronizers) with the counting-source technique of 13.3: prove that it never loses, duplicates or reorders a word, that `full` and `empty` are exact, and that it never writes when full or reads when empty. Then break it (for example, compare only AW bits of the pointers) and read the counterexample.

### Exercise 4: crossing with a handshake

A FIFO is overkill for a value that changes rarely, such as the NCO's FCW written by a control processor on its own clock. Design a **request/acknowledge handshake** that transfers a 32-bit word between two clock domains: the sender holds the word and toggles a request bit; the receiver synchronizes the request, captures the word, and toggles an acknowledge bit back. Explain why the 32 data bits need no synchronizers, and test with two unrelated clocks as in 13.4.
