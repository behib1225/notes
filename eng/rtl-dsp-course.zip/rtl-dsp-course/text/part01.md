# Verilog & RTL for DSP — Part 1: Foundations and Combinational Logic

*Markdown export of the online document: https://claude.ai/artifact/WSYZRgE4Aht9qgq5L31Fmv. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## How to use this course

This is a 12-part self-study course that takes you from zero Verilog to working DSP hardware, with every design checked against a Python reference model. Part 1 teaches you to describe and simulate combinational logic; each later part arrives after you have tried the exercises of the previous one.

Each part follows the same rhythm: a concept, a small complete example you run yourself, the common mistakes, then exercises. Type the code in rather than pasting it. Your fingers learn the syntax faster than your eyes do.

When you finish the exercises, send me your solutions (or your questions) and I will review them before the next part.

### The roadmap

| Part | Topic | What you build |
| --- | --- | --- |
| 1 | Foundations and combinational logic | Adders, multiplexers, decoders, a self-checking testbench |
| 2 | Sequential logic | Registers, counters, shift registers, a clean reset strategy |
| 3 | State machines and the RTL method | FSMs, datapath + controller designs (Mano's ASM charts, in code) |
| 4 | Verification and synthesis | Python-driven test vectors, Verilator lint, Yosys synthesis reports |
| 5 | DSP from scratch I | Sampling, aliasing, convolution, frequency response, all in NumPy |
| 6 | Fixed-point arithmetic and multipliers | Q-format math, rounding, saturation, a pipelined MAC unit |
| 7 | FIR filters | Direct, transposed and symmetric FIR filters, designed in SciPy |
| 8 | IIR filters | Biquad sections, stability, quantization effects |
| 9 | NCO, CORDIC and mixers | Phase accumulator, sine LUT, CORDIC rotator, a complex mixer |
| 10 | Multirate processing | Decimators, interpolators, CIC filters, polyphase structures |
| 11 | The FFT | DFT theory, radix-2 butterflies, a streaming FFT |
| 12 | Capstone | A complete digital down-converter (NCO + mixer + CIC + FIR) |

The DSP theory you need (z-transforms, the DFT, sampling) is taught from scratch in Parts 5, 7 and 11, just before you need it.

### Which language you are learning

You will write the **synthesizable subset of SystemVerilog**. SystemVerilog (IEEE 1800) is the modern superset of Verilog; the old standalone Verilog standard (IEEE 1364) was merged into it in 2009. In industry, new RTL is mostly written this way.

In practice this means classic Verilog plus a few keywords that catch beginner bugs at compile time: `logic`, `always_comb`, `always_ff` and `enum`. Wherever it matters, I show the classic Verilog-2001 equivalent, so you can read older code and textbooks.

Files use the `.sv` extension. All the free tools in this course accept them.

## 1.1 What Verilog and RTL are

Verilog is a hardware description language (HDL): text that describes a circuit, not a program that runs on a processor. Every line you write becomes physical gates and wires, and all of them operate at the same time.

This is the single most important idea in the course. In C or Python, line 2 runs after line 1. In Verilog, two `assign` statements are two separate circuits sitting side by side on the chip. Their order in the file means nothing.

### From Mano to Verilog

Everything you learned with gates, adders and flip-flops still applies. Verilog is simply a precise, compact way to write it down.

| What you drew in Mano's book | How you write it in Verilog | Where |
| --- | --- | --- |
| A Boolean expression, a gate network | `assign y = (a & b) \| ~c;` | Part 1 |
| A multiplexer, decoder, encoder | `?:`, `if`, `case` inside `always_comb` | Part 1 |
| A block with labelled pins (full adder, ALU) | A `module` with `input` and `output` ports | Part 1 |
| Wiring blocks together on paper | Instantiating one module inside another | Part 1 |
| D flip-flop, register, counter | `always_ff @(posedge clk)` | Part 2 |
| Register transfer `R2 ← R1 + R3` | `r2 <= r1 + r3;` inside `always_ff` | Part 2 |
| State diagram, ASM chart, controller | An FSM with an `enum` state register | Part 3 |

### What "RTL" means

RTL stands for **register-transfer level**. It is the same idea as Mano's register-transfer notation: a design is a set of registers, plus the combinational logic that computes each register's next value on every clock edge.

Hardware can be described at several levels of abstraction:

1. **Behavioral (algorithmic)**: "compute the FIR filter output", with no notion of clock cycles.
2. **RTL**: which registers exist, and what combinational logic sits between them, cycle by cycle.
3. **Gate level**: individual AND, OR and XOR gates and flip-flops.
4. **Transistor and layout**: the physical silicon.

You write at the RTL level. A **synthesis tool** then converts your RTL into gates automatically, much as a compiler turns C into machine code. Writing good RTL means you always know roughly which hardware each line will produce.

### Two consumers of your code: simulation and synthesis

The same Verilog text is read by two very different programs.

- **A simulator** (Icarus Verilog, Verilator) executes your description in software so you can watch signals change over time. It accepts the whole language, including printing (`$display`), time delays (`#10`) and loops that run once at start-up.
- **A synthesizer** (Yosys, AMD Vivado, Intel Quartus) turns your description into real gates for an FPGA or a chip. It only accepts the **synthesizable subset**: constructs that map to hardware. Printing and delays mean nothing to it.

So every project has two kinds of code. **Design code** (the RTL) must be synthesizable. **Testbench code** surrounds the design in simulation, drives inputs, and checks outputs; it can use any language feature because it never becomes hardware.

The golden rule for design code: **if you cannot sketch the hardware a block of code produces, do not write that code.** We will come back to this rule in every part.

The diagram below shows how the pieces fit together in this course.

> **Figure:** design flow · simulation and synthesis (shown in the [online version](https://claude.ai/artifact/WSYZRgE4Aht9qgq5L31Fmv))

The top row is where you will spend most of your time: the testbench drives your RTL inside the simulator and reports PASS or FAIL. The bottom row turns the same RTL into hardware; this course uses it from Part 4 to check what your code really builds.

### Check your understanding: 1.1

Answer each question in writing before reading the answers below it.

1. A module contains `assign p = a & b;` followed by `assign q = p | c;`. If you swap the order of the two lines, does the circuit change? Why?
2. Which of these can appear in synthesizable design code, and which are testbench-only: `assign`, `$display`, `#10`, `initial`, `module`?
3. Mano would write the register transfer `R1 ← R1 + R2`. Describe, in hardware terms, what an RTL description of it contains.
4. Why do engineers write RTL instead of drawing gate-level schematics?
5. A colleague's design passes every simulation, but the synthesis tool reports warnings that some statements were ignored. How is that possible?

#### Answers

1. No. Each `assign` is a separate, permanently connected piece of hardware: an AND gate and an OR gate wired together. The order of lines in the file has no meaning; only the connections (which names appear on which side) do.
2. Synthesizable: `assign` and `module`. Testbench-only: `$display` (printing), `#10` (a simulation delay; synthesis ignores it) and `initial` (runs once at simulation start; a few FPGA tools accept it for setting register power-up values, but treat it as testbench-only in this course).
3. A register `R1` (a set of flip-flops), a register `R2`, and a combinational adder whose inputs come from both registers and whose output feeds `R1`'s D inputs. On every active clock edge (when the transfer is enabled), `R1` loads the sum. RTL describes exactly these pieces: registers plus the logic between them.
4. Productivity and portability. A 16-tap filter is a few dozen lines of RTL but tens of thousands of gates. The synthesis tool picks the gates, optimizes them for the target (an FPGA's lookup tables or an ASIC cell library), and lets the same RTL target different chips.
5. The simulator accepts the whole language, but the synthesizer only the synthesizable subset. Delays, `$display` and similar constructs are silently ignored by synthesis, so the hardware can behave differently from the simulation. This is why design code must stick to constructs whose hardware you can sketch.

## 1.2 Setting up your tools

You need three free tools: a simulator, a linter and a waveform viewer, plus Python from Part 4 onward. Install them locally if you can, and keep EDA Playground as a zero-install backup.

| Tool | Role | Current version | Version this course was tested with |
| --- | --- | --- | --- |
| [Icarus Verilog](https://en.wikipedia.org/wiki/Icarus_Verilog) (`iverilog`, `vvp`) | Event-driven simulator, your main workhorse | 13.0 (March 2026) | 12.0 |
| [Verilator](https://en.wikipedia.org/wiki/Verilator) | Strict linter now; fast simulator later | 5.052 (September 2026) | 5.020 |
| GTKWave or Surfer | Waveform viewer for `.vcd` files | — | — |
| Python 3 + NumPy, SciPy, Matplotlib | Golden reference models (Part 4 onward) | — | — |

Every example in this part was compiled and run with the older versions in the last column, so any version at or above them works. Linux distributions often ship older packages; that is fine for this course.

### Option A: install locally (recommended)

**Linux (Ubuntu or Debian):**

```bash
sudo apt update
sudo apt install iverilog verilator gtkwave python3-numpy python3-scipy python3-matplotlib
```

**macOS (with Homebrew):**

```bash
brew install icarus-verilog verilator
pip3 install numpy scipy matplotlib
```

For waveforms on macOS, use **Surfer**, a modern open-source viewer that also runs in a web browser (search for "Surfer waveform viewer"). GTKWave works on macOS too but can be awkward to install.

**Windows:** install **WSL2** (Windows Subsystem for Linux) with Ubuntu from the Microsoft Store, then follow the Linux instructions inside it. This gives you the same environment as most hardware engineers. Native Windows installers for Icarus exist, but Verilator is much easier under WSL2.

**Check the install** by opening a terminal and typing:

```bash
iverilog -V          # prints the Icarus version
verilator --version  # prints the Verilator version
```

### Option B: EDA Playground (browser, nothing to install)

[EDA Playground](https://www.edaplayground.com) runs simulators in your browser after a free sign-up.

1. On the left panel, set **Testbench + Design** to **SystemVerilog/Verilog**.
2. Under **Tools & Simulators**, choose **Icarus Verilog** (the newest version listed).
3. Tick **Open EPWave after run** if you want to see waveforms.
4. Paste the testbench into the left editor (`testbench.sv`) and the design into the right one (`design.sv`), then press **Run**.

### The commands you will use constantly

| Task | Command |
| --- | --- |
| Compile design + testbench | `iverilog -g2012 -Wall -o sim design.sv tb_design.sv` |
| Run the simulation | `vvp sim` |
| Lint a design file (catches bugs before simulating) | `verilator --lint-only -Wall design.sv` |
| View waveforms | `gtkwave dump.vcd` (or open the `.vcd` file in Surfer) |

`-g2012` tells Icarus to accept SystemVerilog (IEEE 1800-2012) syntax such as `logic` and `always_comb`. `-Wall` turns on all warnings. `-o sim` names the compiled output. Always lint design files with Verilator: it is far stricter than Icarus and catches width mismatches and accidental latches that Icarus silently accepts.

Create one folder per exercise, for example `~/rtl/part1/full_adder/`, and keep the design and its testbench together there.

### Check your understanding: 1.2

1. What are the separate jobs of `iverilog` and `vvp`?
2. You compile `full_adder.sv` with `iverilog -o sim full_adder.sv`, forgetting `-g2012`. What happens, and why?
3. Icarus compiles your design without a single warning. Why lint it with Verilator anyway?
4. Write the command that compiles `half_adder.sv`, `full_adder_ha.sv` and `tb_full_adder.sv` into an executable named `fa_sim`, and the command that runs it.
5. After a run, which file do you open in GTKWave or Surfer, and which lines in the testbench created it?

#### Answers

1. `iverilog` is the **compiler**: it reads your `.sv` files, checks them, and writes a compiled simulation file. `vvp` is the **runtime**: it executes that file, which is when `$display` output appears and the `.vcd` file is written.
2. Compilation fails. Icarus reports `error: Net data type requires SystemVerilog.` on each port line, because `logic` is a SystemVerilog keyword and Icarus's default language mode does not include it. `-g2012` enables IEEE 1800-2012 SystemVerilog.
3. Icarus checks syntax, not design quality. Verilator's lint finds real hardware bugs that are syntactically legal: accidental latches (section 1.5), width mismatches and truncation (section 1.4), and signed/unsigned mistakes. Section 1.5 shows a latch that Icarus accepts silently.
4. Compile: `iverilog -g2012 -Wall -o fa_sim half_adder.sv full_adder_ha.sv tb_full_adder.sv` (with the testbench's instance changed to `full_adder_ha`). Run: `vvp fa_sim`. The order of the files does not matter to Icarus, but list every file the design uses.
5. `full_adder.vcd`. The testbench line `$dumpfile("full_adder.vcd");` names the file, and `$dumpvars(0, tb_full_adder);` records every signal in the testbench and everything below it.

## 1.3 Anatomy of a module: your first design

A `module` is Verilog's version of a block in a schematic: a box with named input and output pins and some logic inside. Here is the half adder from Mano's Chapter 4: sum = a XOR b, carry = a AND b.

```systemverilog
`timescale 1ns/1ps
// half_adder.sv -- adds two 1-bit numbers
module half_adder (
  input  logic a,
  input  logic b,
  output logic sum,
  output logic carry
);
  assign sum   = a ^ b;   // XOR
  assign carry = a & b;   // AND
endmodule
```

Read it line by line:

- `` `timescale 1ns/1ps `` is a compiler directive (note the back-tick). It says that a delay written as `#1` means 1 nanosecond, measured with 1 picosecond precision. It only affects simulation, and only matters once delays appear in testbenches; put it at the top of every file so all files agree.
- `//` starts a comment that runs to the end of the line. `/* ... */` comments can span several lines.
- `module half_adder ( ... );` opens the module and names it. The name must match how you instantiate it later. By convention, the file has the same name.
- The **port list** declares each pin's direction (`input` or `output`), type (`logic`) and name. Names are case-sensitive: `Sum` and `sum` are different signals.
- `assign sum = a ^ b;` is a **continuous assignment**. It is a permanent connection, not a one-time calculation: whenever `a` or `b` changes, `sum` follows. Picture an XOR gate whose output is wired to `sum`.
- `endmodule` closes the module. Note: no semicolon after it.

The two `assign` lines are two independent gates. Swapping their order changes nothing about the circuit.

### The full adder

The full adder adds three bits. You know its equations from the Karnaugh map: sum = a ⊕ b ⊕ cin, and cout = ab + a·cin + b·cin (the majority function).

```systemverilog
`timescale 1ns/1ps
// full_adder.sv -- adds a, b and a carry-in
module full_adder (
  input  logic a,
  input  logic b,
  input  logic cin,
  output logic sum,
  output logic cout
);
  assign sum  = a ^ b ^ cin;
  assign cout = (a & b) | (a & cin) | (b & cin);
endmodule
```

This description is **structural at the equation level**: you wrote the Boolean equations, and the synthesizer builds them from gates. In section 1.7 you will build the same full adder by wiring two half adders together, and later just write `a + b`, letting the tool choose the adder circuit.

### Reading older code: the Verilog-2001 version

In classic Verilog, which you will meet in older books and code, the same ports are written with `wire`:

```verilog
module half_adder (input wire a, input wire b, output wire sum, output wire carry);
```

Classic Verilog has two kinds of signal: `wire` (driven by `assign` or by a module output) and `reg` (assigned inside an `always` block). The name `reg` is misleading: it does **not** necessarily mean a register. SystemVerilog's `logic` replaces both, so you no longer have to choose. Section 1.4 explains the one restriction that remains.

### Check your understanding: 1.3

1. Find the mistakes in this module. Then predict on which line numbers Icarus will report errors.

   ```systemverilog
   module and_or (
     input  logic a, b, c
     output logic y
   );
     assign y = (a & b) | c
   endmodule;
   ```
2. With `` `timescale 1ns/1ps ``, how long is `#2.5`? What changes with `` `timescale 1ns/1ns ``?
3. Write a module `mux2` with 1-bit inputs `d0`, `d1`, `s` and output `y`, using only `assign` and the bitwise operators `&`, `|`, `~` (no `?:`). It should output `d1` when `s` is 1.
4. In classic Verilog, why is the keyword `reg` misleading?
5. A module declares ports `Sum` and `sum`. Is that legal, and is it a good idea?

#### Answers

1. There are two real errors: the missing comma after `c` on line 2 (ports in the list are separated by commas), and the missing semicolon at the end of the `assign` on line 5. Icarus reports `syntax error` at **line 3** and line 6, then gives up. Notice that errors are usually reported on the line **after** the real mistake, because the compiler only realizes something is wrong when it reads the next token. The `;` after `endmodule` is tolerated by both Icarus and Verilator, but it is unconventional, so leave it out.
2. `#2.5` is 2.5 ns, stored exactly as 2,500 ps. With `1ns/1ns` the precision is a whole nanosecond, so `#2.5` is rounded to 3 ns; this was confirmed by printing `$realtime`, which reported 3. Choose a precision finer than your smallest delay.
3. This is the sum-of-products form of a 2-to-1 multiplexer, y = s'·d0 + s·d1:

   ```systemverilog
   `timescale 1ns/1ps
   module mux2 (
     input  logic d0, d1, s,
     output logic y
   );
     assign y = (~s & d0) | (s & d1);
   endmodule
   ```
4. `reg` suggests a register (flip-flops), but in Verilog it only means "a variable assigned inside a procedural block". A `reg` assigned in a combinational `always @(*)` block becomes plain gates, not a register. SystemVerilog's `logic` removes the confusion.
5. It is legal, because Verilog is case-sensitive, so they are two different signals. It is a bad idea: readers and some downstream tools (for example, case-insensitive VHDL flows) will confuse them. Most style guides use lower-case `snake_case` names for signals.

## 1.4 Values, data types, vectors and numbers

Every DSP bug you will ever chase comes down to bit widths and signedness, so this section is worth reading twice. The rules are few but strict, and the compiler will not warn you about most mistakes.

### Four-state values

Each bit of a `logic` signal holds one of four values:

| Value | Meaning | Where you see it |
| --- | --- | --- |
| `0` | Logic low | Everywhere |
| `1` | Logic high | Everywhere |
| `x` | Unknown: could be 0 or 1 | An undriven input, an uninitialized register, two drivers fighting |
| `z` | High impedance: nothing drives it | Tri-state buses, an unconnected port |

`x` only exists in simulation; real hardware is always 0 or 1. Treat it as a gift: an `x` on a waveform means "you forgot to drive or reset something", and it spreads through the logic so the bug is visible. Note that `x & 0` is `0` (an AND with 0 is 0 whatever the other input), but `x & 1` is `x`.

Testbenches often use the two-state types `int` (32-bit signed) and `bit` (0 or 1 only) for loop counters and bookkeeping. In design code, use `logic`.

### The one rule about `logic`

A `logic` signal may have **only one driver**: either one `assign`, one procedural block, or one module output. Two `assign` statements that drive the same signal is an error, which is exactly what you want, because in hardware it would be two gate outputs shorted together.

### Vectors (buses)

A multi-bit signal is declared with a range in square brackets:

```systemverilog
logic [7:0]  data;      // 8 bits: data[7] is the MSB, data[0] the LSB
logic [15:0] sample;    // 16 bits
logic [N-1:0] word;     // N bits, where N is a parameter (section 1.7)
```

Always write `[MSB:LSB]` with the LSB at 0. You can select parts of a vector:

| Expression | Meaning |
| --- | --- |
| `data[3]` | Bit 3 alone (a bit-select) |
| `data[7:4]` | The upper 4 bits, a 4-bit vector (a part-select) |
| `{a, b}` | Concatenation: `a`'s bits followed by `b`'s, MSB first |
| `{4{1'b1}}` | Replication: four copies of `1'b1`, giving `4'b1111` |
| `{{8{x[7]}}, x}` | Sign-extend an 8-bit `x` to 16 bits by copying its sign bit |

A memory is an array of vectors: `logic [15:0] coeff [0:63];` is 64 words of 16 bits each. You will use these for filter coefficients in Part 7.

### Writing numbers (literals)

The format is `<width>'<base><digits>`, with base `b` (binary), `o` (octal), `d` (decimal) or `h` (hex). Underscores are ignored and help readability.

| Literal | Width | Value |
| --- | --- | --- |
| `8'b1010_0101` | 8 bits | 165 |
| `8'hA5` | 8 bits | 165 (same bits) |
| `4'd9` | 4 bits | 9 |
| `1'b0`, `1'b1` | 1 bit | 0, 1 |
| `8'hFF` | 8 bits | 255 |
| `-4'sd3` | 4 bits, signed | −3 (bits `1101`) |
| `255` | 32 bits | An unsized literal is 32 bits wide |

Always size your literals in design code. An unsized `255` is 32 bits, which can silently widen an expression.

### Signed numbers

By default, vectors are **unsigned**. Add the keyword `signed` to treat the bits as two's complement, exactly as in Mano's Chapter 1:

```systemverilog
logic        [7:0] u8;   // range 0 .. 255
logic signed [7:0] s8;   // range -128 .. 127
```

The bits are identical; only the **interpretation** changes. The pattern `1111_0000` is 240 as unsigned and −16 as signed. Signedness matters for comparison (`<`, `>`), for division, for right shifts (`>>>`) and, critically, for **extension** to a wider width.

### How Verilog decides the width of an expression

These are the rules behind most DSP bugs:

1. **Expressions are sized to their context.** Before evaluating `y = a + b`, Verilog extends every operand to the width of the widest one, **including the left-hand side `y`**. So an 8-bit + 8-bit sum assigned to a 9-bit variable keeps its carry.
2. **Assigning a wider value to a narrower variable silently keeps the low bits.** This is wrap-around (modulo 2ⁿ) overflow, and nothing warns you in simulation. Verilator's lint does warn you.
3. **Unsigned operands are zero-extended; signed operands are sign-extended**, but only if **every** operand in the expression is signed.
4. **If any operand is unsigned, the whole expression is treated as unsigned.** One unsigned signal in a sum turns your negative numbers into large positive ones. Use `$signed(x)` and `$unsigned(x)` to convert explicitly.

### See it for yourself

Save this as `numbers_demo.sv`. Before running it, **write down what you predict each line will print**. Then run it with `iverilog -g2012 -o nd numbers_demo.sv && vvp nd`.

```systemverilog
`timescale 1ns/1ps
// numbers_demo.sv -- run it and compare the output with your predictions
module numbers_demo;
  logic [7:0]         u8;   // unsigned 8-bit
  logic signed [7:0]  s8;   // signed 8-bit (two's complement)
  logic [3:0]         n4;
  logic signed [3:0]  sn4;
  logic [8:0]         u9;
  logic signed [15:0] s16;
  logic               x_demo;

  initial begin
    // 1. Literals: <width>'<base><digits>
    u8 = 8'b1010_0101;   $display("1. 8'b1010_0101 = %0d (dec) = %h (hex)", u8, u8);
    u8 = 8'hFF;          $display("   8'hFF        = %0d", u8);

    // 2. The same bits, read two ways
    u8 = 8'hF0;  s8 = 8'hF0;
    $display("2. bits 11110000: unsigned = %0d, signed = %0d", u8, s8);

    // 3. Truncation: assigning a wider value to a narrower variable keeps the LOW bits
    n4 = 8'hAB;          $display("3. n4 = 8'hAB  -> n4 = %h (high bits lost)", n4);

    // 4. Overflow: sum of two 8-bit numbers needs 9 bits
    u8 = 8'd200;
    u9 = u8 + 8'd100;    $display("4. 200 + 100 into 9 bits = %0d", u9);
    u8 = u8 + 8'd100;    $display("   200 + 100 into 8 bits = %0d (wrapped mod 256)", u8);

    // 5. Sign extension: signed -> wider signed copies the sign bit
    sn4 = -4'sd3;        // 4'b1101
    s16 = sn4;           $display("5. sn4 = %b (%0d) -> s16 = %b (%0d)", sn4, sn4, s16, s16);

    // 6. The classic trap: mixing signed and unsigned makes EVERYTHING unsigned
    n4  = 4'd2;
    s16 = sn4 + n4;      $display("6. (-3) + 2 with an unsigned operand = %0d  (wrong!)", s16);
    s16 = sn4 + $signed({1'b0, n4});
                         $display("   (-3) + 2 with both signed        = %0d  (right)", s16);

    // 7. Four-state values: x = unknown
    x_demo = 1'bx;
    $display("7. x & 0 = %b,  x & 1 = %b,  x | 1 = %b", x_demo & 1'b0, x_demo & 1'b1, x_demo | 1'b1);

    // 8. Concatenation and replication
    u8 = {4'hA, 4'h5};       $display("8. {4'hA, 4'h5} = %h", u8);
    u8 = {8{1'b1}};          $display("   {8{1'b1}}    = %b", u8);
    s16 = {{8{s8[7]}}, s8};  $display("   manual sign-extension of %0d = %0d", s8, s16);
  end
endmodule
```

This is the exact output from Icarus Verilog:

```text
1. 8'b1010_0101 = 165 (dec) = a5 (hex)
   8'hFF        = 255
2. bits 11110000: unsigned = 240, signed = -16
3. n4 = 8'hAB  -> n4 = b (high bits lost)
4. 200 + 100 into 9 bits = 300
   200 + 100 into 8 bits = 44 (wrapped mod 256)
5. sn4 = 1101 (-3) -> s16 = 1111111111111101 (-3)
6. (-3) + 2 with an unsigned operand = 15  (wrong!)
   (-3) + 2 with both signed        = -1  (right)
7. x & 0 = 0,  x & 1 = x,  x | 1 = 1
8. {4'hA, 4'h5} = a5
   {8{1'b1}}    = 11111111
   manual sign-extension of -16 = -16
```

Line 6 deserves a careful look. Because `n4` is unsigned, `sn4` (bits `1101`) was **zero-extended** to 16 bits, giving 13, and 13 + 2 = 15. In the fix, `{1'b0, n4}` adds a zero sign bit so the value stays +2, and `$signed()` makes it a signed operand, so `sn4` is sign-extended correctly. You will meet exactly this bug when a signed audio sample meets an unsigned coefficient.

Two things in this file are testbench-only: `initial` (a block that runs once at time 0) and `$display` (print, like C's `printf`; `%0d` is decimal without padding, `%h` hex, `%b` binary). Neither becomes hardware.

### Check your understanding: 1.4

Work these out on paper. Every answer below was confirmed in Icarus Verilog.

1. What are the width, decimal value and binary bits of `6'o17`?
2. Given `logic [3:0] a = 4'b1001;`, evaluate `a[3:2]`, `{a, a[0]}` and `{2{a[1:0]}}`, with widths.
3. `logic signed [7:0] s = 8'b1000_0001;` What decimal value does `s` hold? What would the same bits mean if `s` were unsigned?
4. `logic [7:0] u8 = 8'd250;` What is stored by `y8 = u8 + 8'd10;` (with `y8` 8 bits) and by `z9 = u8 + 8'd10;` (with `z9` 9 bits)?
5. `logic signed [7:0] a = -8'sd2;`, `logic [7:0] b = 8'd1;` and `logic signed [15:0] y;`. What does `y = a + b;` store? How do you fix it?
6. Write an expression that sign-extends a signed 12-bit signal `x` to 16 bits using concatenation and replication.
7. A signal `v` is `x` (unknown). Evaluate `v | 1'b1`, `v ^ 1'b1` and `~v`.
8. Why is writing `y = a + 255;` risky in design code, compared with `y = a + 8'd255;`?

#### Answers

1. 6 bits; octal 17 = 1×8 + 7 = **15**; bits **001111**. Each octal digit is 3 bits (`1` → `001`, `7` → `111`).
2. `a[3:2]` = `2'b10` (2 bits). `{a, a[0]}` = `5'b10011` (5 bits: `1001` followed by `1`). `{2{a[1:0]}}` = `4'b0101` (two copies of `01`).
3. Signed: **−127**. The MSB weighs −128, so −128 + 1 = −127. Unsigned: **129** (128 + 1). Same bits, two meanings.
4. `y8` = **4**: 260 does not fit in 8 bits, so it wraps to 260 − 256 = 4. `z9` = **260**: the 9-bit left-hand side widens the whole expression to 9 bits (rule 1), so the carry is kept.
5. It stores **255**, not −1. Because `b` is unsigned, the whole expression is unsigned (rule 4): `a` is **zero**-extended from `1111_1110` (254) to 16 bits, and 254 + 1 = 255. The fix is `y = a + $signed(b);`, which gives −1. Here `$signed(b)` is safe because `b` = 1 has a 0 in its MSB. For an unsigned value that could have its MSB set, write `$signed({1'b0, b})` so it is not misread as negative.
6. `{{4{x[11]}}, x}`: four copies of the sign bit `x[11]`, followed by the original 12 bits. For `x` = −100, the result is −100. (Simply assigning `x` to a `logic signed [15:0]` variable also sign-extends, because both sides are signed.)
7. `v | 1'b1` = **1** (an OR with 1 is 1 whatever `v` is). `v ^ 1'b1` = **x** (inverting an unknown is still unknown). `~v` = **x**.
8. `255` is an unsized literal, so it is 32 bits wide, and it widens the expression to 32 bits. That is harmless here, but it hides your intended width and triggers Verilator width warnings. Worse, sized and unsized literals mixed in comparisons and concatenations produce results that are easy to misread. Size every literal in design code.

## 1.5 Describing combinational logic

Combinational logic is any circuit whose outputs depend only on its current inputs: no memory, no clock. You describe it in one of two ways, `assign` for a single expression and `always_comb` for anything that needs `if` or `case`.

### Operators

Most operators will look familiar from C, but several have hardware meanings worth learning precisely.

| Group | Operators | Example | Result |
| --- | --- | --- | --- |
| Bitwise | `~` `&` `\|` `^` `~^` | `4'b1100 & 4'b1010` | `4'b1000` (bit by bit) |
| Reduction | `&` `\|` `^` (one operand) | `^data` | XOR of all bits of `data`: its parity |
| Logical | `!` `&&` `\|\|` | `(a != 0) && (b != 0)` | One bit: true or false |
| Arithmetic | `+` `-` `*` `/` `%` | `a + b` | Width per section 1.4 |
| Relational | `<` `<=` `>` `>=` | `a < b` | One bit; signedness matters |
| Equality | `==` `!=` | `a == b` | `x` if either side contains `x` or `z` |
| Case equality | `===` `!==` | `a === 4'bx01x` | Compares `x` and `z` literally; testbench only |
| Shift (logical) | `<<` `>>` | `8'b1001_0000 >> 2` | `8'b0010_0100` (fills with 0) |
| Shift (arithmetic) | `<<<` `>>>` | signed `-8 >>> 1` | `-4` (fills with the sign bit) |
| Conditional | `? :` | `sel ? b : a` | A 2-to-1 multiplexer |

Two warnings. First, `&` and `&&` are different: `4'b0100 & 4'b0010` is `4'b0000` (false), but `4'b0100 && 4'b0010` is `1` (both are non-zero, so both are true). Second, precedence rules are long and surprising, so use parentheses whenever you mix operators.

On hardware cost: `+`, `-`, comparisons and shifts by a constant are cheap. A shift by a constant is just wiring. `*` is expensive but FPGAs have dedicated multiplier blocks, which Part 6 covers. Avoid `/` and `%` in design code unless the divisor is a constant power of two; a general divider is large and slow.

### Style 1: `assign` for one expression

Use `assign` when the output is a single expression. The conditional operator `?:` gives you multiplexers, and you can chain it:

```systemverilog
assign y = (sel == 2'd0) ? d0 :
           (sel == 2'd1) ? d1 :
           (sel == 2'd2) ? d2 : d3;
```

### Style 2: `always_comb` for procedural descriptions

An `always_comb` block lets you use `if`, `case`, and intermediate variables. The statements inside are evaluated top to bottom **in simulation**, every time any input changes, and the synthesizer builds a circuit that produces the same final values. When a variable is assigned more than once in the block, the **last assignment wins**.

Inside `always_comb`, always use the **blocking assignment `=`**. (Part 2 introduces the non-blocking `<=` for flip-flops; mixing them up is a classic bug.)

Here is a 4-to-1, 8-bit multiplexer written three ways. All three produce the same hardware:

```systemverilog
`timescale 1ns/1ps
// mux4.sv -- 4-to-1 multiplexer, 8-bit wide, written three ways
module mux4 (
  input  logic [7:0] d0, d1, d2, d3,
  input  logic [1:0] sel,
  output logic [7:0] y_assign,
  output logic [7:0] y_if,
  output logic [7:0] y_case
);
  // Style 1: continuous assignment with the conditional operator ?:
  assign y_assign = (sel == 2'd0) ? d0 :
                    (sel == 2'd1) ? d1 :
                    (sel == 2'd2) ? d2 : d3;

  // Style 2: procedural block with if/else
  always_comb begin
    if      (sel == 2'd0) y_if = d0;
    else if (sel == 2'd1) y_if = d1;
    else if (sel == 2'd2) y_if = d2;
    else                  y_if = d3;
  end

  // Style 3: procedural block with case
  always_comb begin
    case (sel)
      2'd0:    y_case = d0;
      2'd1:    y_case = d1;
      2'd2:    y_case = d2;
      default: y_case = d3;
    endcase
  end
endmodule
```

Notice `begin` and `end`: they group several statements, like `{ }` in C. A one-statement body does not need them, but using them always is a good habit.

**`if` versus `case`.** An `if / else if` chain describes **priority**: the first true condition wins, which is the natural way to write a priority encoder. A `case` describes a choice among **mutually exclusive** values, which is the natural way to write a multiplexer or decoder. Modern synthesizers optimize both well, so choose whichever states your intent most clearly.

**In classic Verilog** you will see `always @(*)` instead of `always_comb`, and in very old code `always @(a or b or sel)`, a hand-written list of inputs. If you forget a signal in that list, simulation and hardware disagree. `always_comb` computes the list for you and also lets tools check that the block really is combinational.

### The accidental latch: the most common beginner bug

What hardware does this describe?

```systemverilog
module latch_bad (
  input  logic       en,
  input  logic [3:0] d,
  output logic [3:0] q
);
  always_comb begin
    if (en) q = d;      // no else: what is q when en = 0?
  end
endmodule
```

When `en` is 0, the code does not say what `q` should be, so `q` must **keep its old value**. Keeping a value requires memory, so the synthesizer builds a **latch** (Mano's level-sensitive D latch). That is not combinational logic, and latches cause timing problems in FPGAs. Verilator catches it immediately:

```text
%Warning-LATCH: latch_bad.sv:6:3: Latch inferred for signal 'q'
    (not all control paths of combinational always assign a value)
```

Icarus Verilog compiles the same file **without any warning**, which is why you lint every design with Verilator.

The fix is a rule you should apply to every `always_comb` block: **give every output a value on every path.** The easiest way is a default assignment at the top:

```systemverilog
  always_comb begin
    q = 4'd0;           // default assignment first...
    if (en) q = d;      // ...then override it
  end
```

For `case` statements, always include a `default` branch for the same reason.

### Rules for combinational blocks

1. Use `assign` for single expressions and `always_comb` for `if` and `case`.
2. Inside `always_comb`, use only blocking assignments `=`.
3. Assign every output on every path: start with defaults, and give every `case` a `default`.
4. Never read a signal in an `always_comb` block that the same block assigns later (that describes a feedback loop).
5. Lint every design file with `verilator --lint-only -Wall`.

### Check your understanding: 1.5

1. Evaluate, with widths: `4'b0110 & 4'b0011`, `4'b0110 && 4'b0011`, `|4'b0100`, `&4'b1110`, `^4'b0111`.
2. `logic signed [7:0] s = -8'sd16;` What are `s >>> 2` and `s >> 2`?
3. With `a = 4'b0011`, `b = 4'b0101`, `c = 4'b0001`, what is `a & b == c`? What did the writer probably mean?
4. Does this block infer a latch? Note that it has no `default`.

   ```systemverilog
   always_comb begin
     case (sel)          // sel is logic [1:0]
       2'd0: y = d0;
       2'd1: y = d1;
       2'd2: y = d2;
       2'd3: y = d3;
     endcase
   end
   ```
5. Does this block infer a latch? If so, for which signal?

   ```systemverilog
   always_comb begin
     if (s) begin y = a; z = b; end
     else   begin y = b;        end
   end
   ```
6. Write one `assign` that computes the absolute difference |a − b| of two unsigned 8-bit inputs into an 8-bit output `d`.
7. In an `if / else if` chain, two conditions are true at once. Which branch runs, and what kind of circuit does that describe?
8. Inside `always_comb`, a variable `t` is assigned three times. Which value appears on the hardware output?

#### Answers

1. `4'b0010` (bitwise AND, 4 bits); `1'b1` (logical AND: both operands are non-zero, so true; 1 bit); `1'b1` (OR of all bits: at least one is 1); `1'b0` (AND of all bits: one bit is 0); `1'b1` (XOR of all bits: three 1s is odd parity).
2. `s >>> 2` = **−4**: an arithmetic shift fills with the sign bit, `1111_0000` becomes `1111_1100`, which is −16 ÷ 4. `s >> 2` = **60**: a logical shift fills with zeros, giving `0011_1100`. For signed DSP data, always use `>>>` to divide by a power of two.
3. It evaluates to `4'b0000`. `==` has **higher** precedence than `&`, so it parses as `a & (b == c)`. `b == c` is false (`1'b0`), which widens to `4'b0000`, and `0011 & 0000` = `0000`. The writer meant `(a & b) == c`, which is `0001 == 0001` = 1. Use parentheses.
4. No. All four values of a 2-bit `sel` are listed, so `y` is assigned on every path, and Verilator's lint reports no latch. Add a `default` anyway: if `sel` is later widened to 3 bits, the missing cases would silently create a latch, and a `default` also defines what happens when `sel` is `x` in simulation.
5. Yes, for **`z`**. `y` is assigned in both branches, but `z` is not assigned when `s` is 0, so it must hold its old value. Verilator reports `Latch inferred for signal 'z'`. Fix it with a default such as `z = 4'd0;` at the top of the block.
6. `assign d = (a > b) ? (a - b) : (b - a);` Both subtractions are non-negative in the branch where they are used, so the 8-bit result is always correct. In hardware this is a comparator, two subtractors and a multiplexer.
7. The **first** true condition wins; later branches are not considered. That describes a **priority** circuit: earlier conditions take precedence, like a priority encoder.
8. The **last** assignment executed on the path taken. The earlier assignments act as defaults that are overridden, which is exactly why the "default at the top" latch fix works.

## 1.6 Your first testbench

A testbench is a module with no ports that creates the design, drives its inputs, and **checks its outputs automatically**. Write one for every design, before you consider the design finished; a design without a testbench is untested.

The word to remember is **self-checking**. Staring at waveforms to judge whether 1,000 outputs are correct does not scale. Instead, the testbench computes the expected answer itself and compares. This idea grows into the whole verification strategy of the course: from Part 4 onward the "expected answer" comes from a Python model of your DSP algorithm.

### The testbench

```systemverilog
`timescale 1ns/1ps
// tb_full_adder.sv -- exhaustive, self-checking testbench for full_adder
module tb_full_adder;
  logic       a, b, cin;     // inputs we drive
  logic       sum, cout;     // outputs we observe
  logic [1:0] expected;      // the right answer, 2 bits wide
  int         errors = 0;

  // Device Under Test (DUT)
  full_adder dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

  initial begin
    $dumpfile("full_adder.vcd");      // record waveforms to this file
    $dumpvars(0, tb_full_adder);      // ...for every signal in the testbench

    for (int i = 0; i < 8; i++) begin
      {a, b, cin} = i[2:0];           // apply all 8 input patterns
      #10;                            // wait 10 ns for the logic to settle
      expected = a + b + cin;         // the simulator does the math for us
      if ({cout, sum} !== expected) begin
        $display("FAIL: a=%b b=%b cin=%b -> cout=%b sum=%b (expected %b)",
                 a, b, cin, cout, sum, expected);
        errors++;
      end else begin
        $display("ok:   a=%b b=%b cin=%b -> cout=%b sum=%b", a, b, cin, cout, sum);
      end
    end

    if (errors == 0) $display("PASS: all 8 cases correct");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

### What each part does

- **No ports.** `module tb_full_adder;` is the top of the simulation; nothing sits above it.
- **Signals for the DUT.** The testbench declares one `logic` per DUT port. It drives the inputs and only watches the outputs.
- **The instance.** `full_adder dut ( ... );` creates one copy of your design, named `dut`. Each `.port(signal)` pair connects a port of `full_adder` to a testbench signal. Always use these **named connections**; connecting by position is legal but a common source of swapped wires.
- **`initial begin ... end`** runs once, from time 0, top to bottom, like an ordinary program. It is testbench-only.
- **`$dumpfile` and `$dumpvars`** record every signal's changes to a `.vcd` (value change dump) file for the waveform viewer.
- **`{a, b, cin} = i[2:0];`** assigns the three low bits of the loop counter to the three inputs at once, using concatenation on the left-hand side. The loop therefore walks through the full truth table: 000, 001, ..., 111.
- **`#10;`** advances simulated time by 10 ns. Without it, the check would run before the DUT's outputs update. Delays are testbench-only; the synthesizer ignores them.
- **`expected = a + b + cin;`** is the **golden model**: a trustworthy, simple calculation of the right answer. Because `expected` is 2 bits wide, the sum keeps its carry (rule 1 in section 1.4).
- **`!==`** compares including `x` and `z`. If `cout` were `x` (undriven), `!=` would return `x`, the `if` would treat that as false, and the bug would pass silently. Always use `===` and `!==` in testbench checks.
- **`$finish`** ends the simulation.

### Run it

```bash
iverilog -g2012 -Wall -o sim full_adder.sv tb_full_adder.sv
vvp sim
```

The output:

```text
VCD info: dumpfile full_adder.vcd opened for output.
ok:   a=0 b=0 cin=0 -> cout=0 sum=0
ok:   a=0 b=0 cin=1 -> cout=0 sum=1
ok:   a=0 b=1 cin=0 -> cout=0 sum=1
ok:   a=0 b=1 cin=1 -> cout=1 sum=0
ok:   a=1 b=0 cin=0 -> cout=0 sum=1
ok:   a=1 b=0 cin=1 -> cout=1 sum=0
ok:   a=1 b=1 cin=0 -> cout=1 sum=0
ok:   a=1 b=1 cin=1 -> cout=1 sum=1
PASS: all 8 cases correct
tb_full_adder.sv:31: $finish called at 80000 (1ps)
```

The last line reports the end time in the precision unit: 80,000 ps is 80 ns, eight steps of 10 ns.

### Watch it catch a bug

Now break the design on purpose. Delete the last term of the carry equation, so it reads `assign cout = (a & b) | (a & cin);`, and run again. The testbench reports:

```text
FAIL: a=0 b=1 cin=1 -> cout=0 sum=0 (expected 10)
FAILED with 1 errors
```

It names the exact input that fails: the one case where only the missing `b & cin` term is true. Get into the habit of breaking every new design once, to prove your testbench can actually fail.

### Look at the waveforms

Open the dump with `gtkwave full_adder.vcd` (or drag it into Surfer). In the signal tree, click `tb_full_adder`, select `a`, `b`, `cin`, `sum` and `cout`, and add them to the view. Zoom to fit. You should see the inputs counting through 000 to 111 every 10 ns, with the outputs following the truth table. Waveforms are for **debugging** a failure that the self-check reported, not for deciding whether the design works.

### A shortcut for connections

When every testbench signal has the same name as the DUT port it connects to, `full_adder dut (.*);` connects them all automatically. It is convenient in testbenches; in design code, spell out the connections so a reader can see the wiring.

### Check your understanding: 1.6

1. You delete the `#10;` line from `tb_full_adder.sv`. Predict the output. Then predict it again if the check also used `!=` instead of `!==`.
2. You declare `expected` as `logic expected;` (1 bit) instead of `logic [1:0] expected;`. Which test cases fail, and why?
3. How many test cases does an exhaustive test of a 4-bit adder with carry-in need?
4. The simulator prints `$finish called at 80000 (1ps)`. What does the number mean?
5. Why should you deliberately break a design once after its testbench passes?
6. Why use named port connections `.a(a)` rather than positional connections `full_adder dut (a, b, cin, sum, cout);`?

#### Answers

1. **All 8 cases fail**, with `cout=x sum=x`. The `initial` block runs from start to finish without ever advancing time, so the simulator never gets a chance to update the `assign` outputs, which are still `x` from the start of simulation. Every check reads stale values. With `!=` it is far worse: `x != 2'b01` evaluates to `x`, the `if` treats `x` as false, and the testbench prints **`PASS: all 8 cases correct`** while every output is `x` (confirmed in Icarus: the run finished at time 0). This is exactly why testbench checks use `!==`, and why you must break a design once to prove the testbench can fail.
2. The four cases with a carry fail: a=0 b=1 cin=1, a=1 b=0 cin=1, a=1 b=1 cin=0 and a=1 b=1 cin=1. A 1-bit `expected` keeps only the low bit of the sum, so the carry is lost (rule 2 in section 1.4). The comparison then widens `expected` to 2 bits with a 0 in its upper bit, while `{cout, sum}` has a 1 there, so they never match.
3. **512**. The inputs are 4 + 4 + 1 = 9 bits, so there are 2⁹ = 512 combinations. That is small enough to test exhaustively with a `for` loop; a 16-bit adder (2³³ cases) is not.
4. Simulated time when `$finish` ran, in units of the precision (1 ps): 80,000 ps = 80 ns, which is eight test steps of 10 ns each.
5. A testbench that cannot fail is worthless, and it is easy to write one by accident (see answer 1). Breaking the design and watching the testbench report FAIL proves that the checks are connected and actually compare something.
6. Positional connections depend on the order of the ports in the module declaration. If someone reorders or adds a port, every positional instance silently connects the wrong signals, and the compiler cannot notice when the widths happen to match. Named connections say exactly which signal goes to which port, and a misspelled name is a compile error.

## 1.7 Hierarchy and reuse: building bigger blocks

Real designs are trees of modules: small, tested blocks wired together into larger ones, exactly as you drew block diagrams in Mano's book. This section builds a full adder from half adders, then an N-bit adder from full adders, with one parameter that sets the width.

### Instantiating modules inside a module

This full adder is built from two half adders plus an OR gate, the classic textbook construction:

```systemverilog
`timescale 1ns/1ps
// full_adder_ha.sv -- a full adder built from two half adders
module full_adder_ha (
  input  logic a, b, cin,
  output logic sum, cout
);
  logic s1, c1, c2;   // internal wires between the two half adders

  half_adder ha1 (.a(a),  .b(b),   .sum(s1),  .carry(c1));
  half_adder ha2 (.a(s1), .b(cin), .sum(sum), .carry(c2));

  assign cout = c1 | c2;
endmodule
```

`s1`, `c1` and `c2` are internal signals, the wires you would draw between the boxes. `ha1` and `ha2` are **instance names**: two separate copies of the same `half_adder` hardware. To simulate, list every file the design needs:

```bash
iverilog -g2012 -Wall -o sim half_adder.sv full_adder_ha.sv tb_full_adder.sv
```

The testbench from section 1.6 works unchanged if you edit one line, the instance, to `full_adder_ha dut (...)`. That is the payoff of self-checking testbenches: a new implementation is re-verified in seconds.

### Parameters: one design, any width

A **parameter** is a compile-time constant that callers can override, like a template argument. DSP blocks are full of them: data width, coefficient width, number of taps.

```systemverilog
`timescale 1ns/1ps
// rca.sv -- N-bit ripple-carry adder built from full adders
module rca #(
  parameter int N = 8                 // width; can be overridden per instance
) (
  input  logic [N-1:0] a, b,
  input  logic         cin,
  output logic [N-1:0] sum,
  output logic         cout
);
  logic [N:0] c;                      // carry chain: c[0] = cin, c[N] = cout
  assign c[0] = cin;

  genvar i;
  generate
    for (i = 0; i < N; i++) begin : g_bit
      full_adder fa (.a(a[i]), .b(b[i]), .cin(c[i]), .sum(sum[i]), .cout(c[i+1]));
    end
  endgenerate

  assign cout = c[N];
endmodule
```

The new pieces:

- **`#( parameter int N = 8 )`** declares the parameter with a default of 8. An instance overrides it with `rca #(.N(16)) my_adder ( ... );`.
- **`localparam`** (used in the testbench below) is a constant that cannot be overridden: use it for values derived inside the module.
- **`generate ... for`** is a loop that runs **at compile time** and stamps out hardware: here, N copies of `full_adder`. It is not a loop that executes at run time. The loop variable must be declared as a `genvar`.
- **`begin : g_bit`** names each copy, so they have unique hierarchical names: `dut.g_bit[0].fa`, `dut.g_bit[1].fa`, and so on. You will see these names in the waveform viewer's signal tree. Always name generate blocks.
- **`c[i+1]`** connects each stage's carry-out to the next stage's carry-in: the ripple.

### A testbench with random tests

An exhaustive test of a 16-bit adder needs 2³³ cases, about 8.6 billion, which is too many. The standard approach is **directed corner cases** plus **many random cases**:

```systemverilog
`timescale 1ns/1ps
// tb_rca.sv -- checks a 16-bit ripple-carry adder against the '+' operator
module tb_rca;
  localparam int N = 16;
  logic [N-1:0] a, b, sum;
  logic         cin, cout;
  logic [N:0]   expected;            // one bit wider than the inputs
  int errors = 0;

  rca #(.N(N)) dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

  task automatic check(input logic [N-1:0] ta, tb, input logic tcin);
    a = ta; b = tb; cin = tcin;
    #10;
    expected = a + b + cin;          // N+1-bit result, computed by the simulator
    if ({cout, sum} !== expected) begin
      $display("FAIL: %0d + %0d + %0d = %0d, expected %0d", a, b, cin, {cout, sum}, expected);
      errors++;
    end
  endtask

  initial begin
    // corner cases first: they find most bugs
    check(16'h0000, 16'h0000, 1'b0);
    check(16'hFFFF, 16'h0001, 1'b0);   // carry ripples through every bit
    check(16'hFFFF, 16'hFFFF, 1'b1);   // largest possible sum
    check(16'h8000, 16'h8000, 1'b0);
    // then 1000 random cases
    repeat (1000) check($urandom, $urandom, $urandom);
    if (errors == 0) $display("PASS: 1004 cases correct");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

New testbench tools here: a **`task`** is a reusable procedure (`automatic` gives each call its own local variables). **`$urandom`** returns a random 32-bit number; assigning it to a 16-bit or 1-bit argument keeps the low bits. **`repeat (n)`** runs a statement n times. Run it:

```bash
iverilog -g2012 -Wall -o sim full_adder.sv rca.sv tb_rca.sv && vvp sim
```

It prints `PASS: 1004 cases correct`.

### How it is done in practice

You built the adder gate by gate to see how hierarchy works. In real RTL, you write the arithmetic directly and let the synthesizer pick the circuit. FPGAs have dedicated fast carry chains that `+` maps onto automatically:

```systemverilog
`timescale 1ns/1ps
// adder.sv -- the same N-bit adder in one line; the tool picks the circuit
module adder #(parameter int N = 8) (
  input  logic [N-1:0] a, b,
  input  logic         cin,
  output logic [N-1:0] sum,
  output logic         cout
);
  assign {cout, sum} = {1'b0, a} + {1'b0, b} + {{N{1'b0}}, cin};
endmodule
```

Why the zero-padding? The simpler `assign {cout, sum} = a + b + cin;` simulates correctly, because the left-hand side is N+1 bits wide (rule 1 in section 1.4). But Verilator's lint flags it with a `WIDTHEXPAND` warning, because it cannot know that you **meant** to widen `cin` from 1 bit to N+1. Padding every operand to the result width states your intent explicitly, and the lint passes cleanly. Writing widths out explicitly like this is exactly the discipline that DSP datapaths need.

Verilator also expects each file to be named after the module it contains (`adder.sv` holds `module adder`); otherwise it warns with `DECLFILENAME`. Follow that convention from the start.

### Check your understanding: 1.7

1. Write the instance of a 12-bit `rca` named `add12`, connecting ports `a`, `b`, `cin`, `sum`, `cout` to signals `x`, `y`, `ci`, `s`, `co`.
2. How many `full_adder` instances does `rca #(.N(16))` contain? In the testbench, what is the hierarchical name of the one that produces the MSB of the sum?
3. What is the difference between `parameter` and `localparam`?
4. When does a `generate for` loop run: at compile time or while the simulation is running? What does that imply about its loop bounds?
5. Which path through a ripple-carry adder is the slowest, and which input in `tb_rca.sv` exercises it?
6. In `tb_rca.sv`, you forget the override and write `rca dut (...)` while the signals are still 16 bits. What happens?
7. Why does `assign {cout, sum} = a + b + cin;` simulate correctly but fail Verilator's lint?

#### Answers

1. `rca #(.N(12)) add12 (.a(x), .b(y), .cin(ci), .sum(s), .cout(co));` with `x`, `y`, `s` declared as `logic [11:0]`. The parameter override comes after the module name and before the instance name.
2. **16**, one per bit, created by the `generate` loop. The MSB adder is `tb_rca.dut.g_bit[15].fa`: testbench, then instance `dut`, then generate block `g_bit` copy 15, then instance `fa`. Without the label `g_bit`, the tools invent names such as `genblk1`, which are hard to find.
3. A `parameter` can be overridden from outside, per instance, with `#(.N(16))`. A `localparam` cannot: it is a fixed or derived constant inside the module, for example `localparam int W_OUT = 2*W + 1;`. Use `parameter` for what a user should configure and `localparam` for everything derived from it.
4. At compile time (strictly, during **elaboration**, when the tool builds the hierarchy). It stamps out hardware and then disappears, so its bounds must be constants (literals or parameters), never signals. A loop over a signal value cannot change how much hardware exists.
5. The carry chain: a carry generated in bit 0 that has to ripple through every stage to `cout`. The delay grows linearly with N. The test `16'hFFFF + 16'h0001` exercises it: bit 0 generates a carry and all 15 higher bits propagate it. In simulation with zero-delay logic it only checks correctness; Part 4 shows how synthesis reports the timing.
6. `N` keeps its default of 8. Icarus warns `Port 1 (a) of rca expects 8 bits, got 16` and prunes the upper bits, then the testbench fails 1,002 of the 1,004 cases (confirmed). Only the cases whose upper bytes are zero pass. Always read compiler warnings: this one tells you the bug directly.
7. The left-hand side is N+1 bits, so rule 1 widens every operand and the carry is kept: the **result** is right. But `cin` is 1 bit being silently widened to N+1 bits, and Verilator's `-Wall` lint treats any implicit widening as a possible mistake (`WIDTHEXPAND`). Padding each operand to N+1 bits, `{1'b0, a} + {1'b0, b} + {{N{1'b0}}, cin}`, states the intent explicitly and passes the lint.

## 1.8 Exercises

Do all six before moving to Part 2; for scale, their worked solutions add 8 design files and 6 testbenches, about 215 new lines (time depends too much on experience for a reliable estimate). For every design exercise, write a self-checking testbench, make it print PASS, lint the design with `verilator --lint-only -Wall`, and break the design once to prove the testbench can fail.

Send me your code (design and testbench) and your answers to Exercise 1. I will review them and then send Part 2.

- [ ] Exercise 1: predict the output
- [ ] Exercise 2: decoder with enable
- [ ] Exercise 3: priority encoder
- [ ] Exercise 4: saturating adder
- [ ] Exercise 5: find the three bugs
- [ ] Exercise 6: adder-subtractor with overflow

### Exercise 1: predict the output (warm-up, 20 minutes)

Write down what each line prints **before** you run it, with a one-sentence reason. Then run it and explain every line you got wrong.

```systemverilog
module predict;
  logic [3:0] r4;  logic [4:0] r5;
  logic signed [7:0] s;  logic [7:0] u;  logic b;
  initial begin
    r4 = 4'b1010 + 4'b0111;          $display("a %b", r4);
    r5 = 4'b1010 + 4'b0111;          $display("b %b", r5);
    s  = -8'sd6;                     $display("c %0d %0d", s >>> 1, s >> 1);
    u  = 8'd1;  b = (s < u);         $display("d %b", b);
    b  = (s < $signed(u));           $display("e %b", b);
    $display("f %b %b", &4'b1111, ^4'b1011);
    $display("g %b", 4'b0100 && 4'b0010);
  end
endmodule
```

Hint: lines c and d are the ones that catch everyone. For line d, ask yourself whether the comparison is signed or unsigned, and what −6 looks like as an unsigned 8-bit number.

### Exercise 2: 2-to-4 decoder with enable

Design `decoder2to4` with inputs `en` and `a[1:0]` and output `y[3:0]`. When `en` is 1, exactly one output bit is 1: bit number `a`. When `en` is 0, all outputs are 0. This is the decoder from Mano's Chapter 4.

- Write it with `always_comb` and a `case` statement. Remember the default assignment.
- Then write a second version in a single `assign` line using the shift operator. (Hint: what is `4'b0001 << a`?)
- Test all 8 input combinations exhaustively in one testbench, against both versions.

### Exercise 3: 4-to-2 priority encoder

Design `prio_enc4` with input `d[3:0]` and outputs `y[1:0]` and `valid`. `y` is the index of the **highest-numbered** input bit that is 1; `valid` is 1 if any input is 1. When no input is 1, set `y` to `2'b00` and `valid` to 0.

- Use an `if / else if` chain in `always_comb`. Explain in one sentence why `if` suits this circuit better than `case`.
- Write `valid` as a one-line `assign` using a reduction operator.
- Test all 16 inputs. In the testbench, compute the expected `y` with a `for` loop that scans the bits.

### Exercise 4: saturating adder (your first DSP block)

In DSP, an overflowing sum must not wrap around: wrapping turns a large positive audio sample into a large negative one, which sounds like a loud click. Instead, the result is **saturated** (clamped) to the largest or smallest representable value.

Design `sat_add #(parameter int W = 8)` with signed inputs `a`, `b` (W bits each) and a signed output `y` (W bits) that equals `a + b` clamped to the range −2^(W−1) to 2^(W−1) − 1. For W = 8, that is −128 to 127.

- Hint 1: compute the sum in W+1 bits first, so nothing is lost. Sign-extend both operands (section 1.4).
- Hint 2: the sum overflowed when its top two bits differ. Work out why from two's-complement arithmetic.
- Test with W = 8: include the corners (127 + 1, −128 + −1, 127 + 127, −128 + −128, −1 + 1) and 2,000 random pairs. Compute the expected value in the testbench with `int` arithmetic and explicit `if` clamping.

### Exercise 5: find the three bugs

This module should output the absolute value of a signed 8-bit input, saturated to +127 (because +128 does not fit in 8 signed bits). It contains three bugs.

```systemverilog
`timescale 1ns/1ps
module abs_sat (
  input  logic signed [7:0] x,
  output logic signed [7:0] y   // |x|, saturated to +127
);
  always_comb begin
    if (x < 8'd0)
      y = -x;
  end
endmodule
```

1. Write a testbench first, and watch it fail. Try at least −5, 7, 0, −127 and −128.
2. Run Verilator's lint on the module. It finds one bug directly. Fix it and lint again: a second warning appears.
3. The third bug survives the lint. Your testbench must catch it.
4. For each bug, write one sentence naming the rule from this part that it breaks.

### Exercise 6: adder-subtractor with overflow flag (stretch)

Build the 4-bit adder-subtractor from Mano's Chapter 4 (the one with the XOR gates on the B inputs), generalized to N bits. Inputs `a`, `b` (N bits) and `m` (0 = add, 1 = subtract); outputs `s` (N bits), `c` (carry-out) and `v` (signed overflow).

- Build it **structurally** from your `full_adder`, with a `generate` loop. Each `b[i]` goes through an XOR with `m`, and `m` is also the carry-in. This computes a + (\~b) + 1 = a − b in two's complement.
- The overflow flag is the XOR of the carries into and out of the most significant bit, so you need access to the internal carry chain.
- Test with N = 8. In the testbench, treat `a` and `b` as signed: compute the exact result in `int`, and set the expected `v` whenever that result falls outside −128 to 127.

## 1.9 Summary and what comes next

You can now describe any combinational circuit in SystemVerilog, verify it with a self-checking testbench, and lint it. Keep this table next to you while doing the exercises.

| Concept | Syntax | Remember |
| --- | --- | --- |
| Module | `module name #(params) (ports); ... endmodule` | One module per file, file named after it |
| Ports | `input logic [7:0] a`, `output logic y` | Use `logic` for everything |
| Continuous assignment | `assign y = expr;` | A permanent wire, not a one-time calculation |
| Combinational block | `always_comb begin ... end` | Blocking `=`; every output assigned on every path |
| Signed vector | `logic signed [15:0] x;` | Mixing with unsigned makes the whole expression unsigned |
| Literal | `8'hA5`, `4'b1010`, `-8'sd3` | Always give the width |
| Concatenate / replicate | `{a, b}`, `{4{1'b1}}` | Sign-extend with `{{n{x[msb]}}, x}` |
| Instance | `child #(.N(16)) u1 (.port(sig));` | Always use named connections |
| Generate loop | `for (genvar i = 0; ...) begin : g_name` | Runs at compile time; stamps out hardware |
| Testbench check | `if (out !== expected) errors++;` | `!==` catches `x`; break the design once |
| Compile and run | `iverilog -g2012 -Wall -o sim *.sv && vvp sim` |  |
| Lint | `verilator --lint-only -Wall file.sv` | Catches latches and width bugs Icarus misses |

The three ideas that matter most from this part:

1. Verilog describes hardware that runs in parallel; it is not a sequential program.
2. Every signal has a width and a signedness, and the rules for combining them are strict and silent.
3. A design is finished only when a self-checking testbench says PASS and the linter is clean.

**Part 2: Sequential logic** adds the clock. You will write flip-flops, registers, counters and shift registers with `always_ff`, learn why flip-flops use the non-blocking assignment `<=`, choose a reset strategy, and write clocked testbenches. By the end of Part 2 you will have built a shift register delay line: the core of every FIR filter.

### Before Part 2: portable SystemVerilog

Icarus, Verilator and Yosys each accept a different subset of SystemVerilog, and the differences surface in later parts as code that simulates but does not synthesize, or the reverse. Read the [Appendix A: Portable SystemVerilog](https://claude.ai/artifact/2rooPowLtJJTig3xL7sYfU) now: it lists the constructs to avoid and their portable forms, each checked in all three tools.

### The course code

Every design, testbench, model and script of the course, its solutions and its appendices is collected in one archive, **rtl-dsp-course.zip**, organized as `course/partNN/`, `solutions/partNN/` and `appendix_*/`. It contains a `Dockerfile` that pins the exact toolchain the course was verified with (Ubuntu 24.04 with Icarus Verilog 12.0, Verilator 5.020, Yosys 0.33 and z3 4.8.12, plus the Python packages in `requirements.txt`), and a script, `regress.sh`, that re-runs the automated checks: bit-exact simulations, lint, formal proofs, specification checks and the cocotb coverage test. Its `README.md` lists what the regression covers and what it does not.
