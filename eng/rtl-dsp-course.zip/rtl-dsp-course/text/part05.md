# Verilog & RTL for DSP — Part 5: DSP from Scratch I

*Markdown export of the online document: https://claude.ai/artifact/UEAzBg8TVjMqHYdAtu6sze. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 5 fits

Part 5 is the first of the signal-processing parts. It teaches, from scratch, the four ideas behind every DSP block in this course: sampled signals, aliasing, convolution and frequency response. Every idea is computed in NumPy, and the last section checks the theory against the moving-sum RTL you built in Part 2.

You need no prior DSP knowledge, only school algebra and a little trigonometry (sines, cosines and angles in radians). Complex numbers are introduced where they are needed, in section 5.5.

How to work through this part: run every code snippet in an interactive Python session (type `python3`, or use a Jupyter notebook) and look at the numbers yourself. Change the values and predict what will happen before you run the code again. DSP intuition comes from seeing signals, so plot whenever you can: `import matplotlib.pyplot as plt`, then `plt.plot(x); plt.show()`.

The sections build on each other in a chain: signals (5.1) → what goes wrong when sampling (5.2) → systems and their impulse response (5.3) → convolution, which computes any filter's output (5.4) → frequency response, which tells you what a filter does to each frequency (5.5) → decibels and noise (5.6).

All numbers in this part were computed with Python 3 and NumPy 2.4, and the RTL measurement in section 5.5 used Icarus Verilog 12.0 with the Part 4 flow.

## 5.1 Signals as sequences of numbers

A digital signal is a list of numbers, one per **sample period**: x\[0\], x\[1\], x\[2\], and so on. Everything in DSP, and every register in your hardware, works on this list. This section defines it precisely and introduces the most important signal of all, the sinusoid.

### From a continuous signal to samples

A microphone produces a **continuous-time** signal: a voltage x(t) defined at every instant t. An analog-to-digital converter (ADC) measures it at regular intervals of T seconds, the **sampling period**:

```latex
x[n] = x(nT), \qquad n = 0, 1, 2, \ldots
```

The **sample rate** (or sampling frequency) is f\_s = 1/T samples per second, measured in hertz (Hz). Audio CDs use f\_s = 44.1 kHz, phone calls 8 kHz, and a software radio may sample at hundreds of MHz.

The notation matters: x(t) with round brackets is a continuous signal; x\[n\] with square brackets is a sequence, and n is an integer **sample index**, not a time. To get the time of sample n, multiply: t = nT = n/f\_s.

The ADC also rounds each sample to a fixed number of bits, for example 16. That rounding, **quantization**, is the subject of Part 6. In this part we work with exact real numbers.

In your hardware, x\[n\] is the value on the input bus in the clock cycle when `in_valid` is high for the n-th time. The clock rate and the sample rate are different things: a 100 MHz design may process 1 MHz samples, one per 100 clocks (Part 2, section 2.6).

### The sinusoid

The most important signal in DSP is the sinusoid. In continuous time:

```latex
x(t) = A \cos(2 \pi f t + \varphi)
```

with **amplitude** A (its peak value), **frequency** f in hertz (cycles per second) and **phase** φ in radians (where in its cycle it starts). Sampling it at t = n/f\_s gives the discrete sinusoid:

```latex
x[n] = A \cos\left(2 \pi \frac{f}{f_s} n + \varphi\right)
```

Notice that f and f\_s appear only as the ratio f/f\_s, in **cycles per sample**. A 1 kHz tone sampled at 8 kHz and a 1 MHz tone sampled at 8 MHz produce exactly the same list of numbers. The hardware never knows the real frequency; it only sees the ratio.

Here is the 1 kHz tone at f\_s = 8 kHz, which completes one cycle every 8 samples:

```python
import numpy as np
fs = 8000.0                       # sample rate, Hz
f  = 1000.0                       # tone frequency, Hz
n  = np.arange(10)                # sample indices 0..9
x  = np.cos(2 * np.pi * f * n / fs)
print(x)
```

```text
[ 1.     0.707  0.    -0.707 -1.    -0.707 -0.     0.707  1.     0.707]
```

The pattern repeats after 8 samples, as expected for f/f\_s = 1/8. (`-0.` is a floating-point zero with a sign; treat it as 0.)

### Normalized frequency

Because only the ratio matters, DSP texts often measure frequency in one of these normalized units. You will see all of them in documentation and in SciPy:

| Unit | Symbol | 1 kHz at f\_s = 8 kHz | Range of useful frequencies |
| --- | --- | --- | --- |
| Hertz | f | 1,000 Hz | 0 to f\_s/2 = 4,000 Hz |
| Cycles per sample | f/f\_s | 0.125 | 0 to 0.5 |
| Radians per sample | ω = 2πf/f\_s | π/4 ≈ 0.785 | 0 to π |
| Fraction of Nyquist (SciPy's default) | f/(f\_s/2) | 0.25 | 0 to 1 |

Why does every range stop at half the sample rate? That is the subject of section 5.2.

### Check your understanding: 5.1

1. A signal is sampled at f\_s = 48 kHz. What is the sampling period T, and at what time is sample x\[480\] taken?
2. Write the first five samples of x\[n\] = cos(2π · 0.25 · n). How many samples are in one cycle?
3. A 2 kHz tone is sampled at 16 kHz, and a 50 kHz tone at 400 kHz. Compare the two sample sequences.
4. Express 12 kHz at f\_s = 48 kHz in cycles per sample, radians per sample, and SciPy's normalized units.
5. A hardware design has a 200 MHz clock and receives a new sample every 50 clock cycles. What is its sample rate?

#### Answers

1. T = 1/48,000 ≈ **20.83 µs**. Sample 480 is taken at t = 480 × T = 480/48,000 = **10 ms**.
2. cos(0) = 1, cos(π/2) = 0, cos(π) = −1, cos(3π/2) = 0, cos(2π) = 1: **1, 0, −1, 0, 1**. One cycle takes 1/0.25 = **4 samples**.
3. Both have f/f\_s = 0.125, so with the same amplitude and phase they are **identical** sequences. The digital system cannot tell them apart.
4. 12/48 = **0.25 cycles/sample**; ω = 2π × 0.25 = **π/2 ≈ 1.571 rad/sample**; 12/24 = **0.5** of Nyquist.
5. 200 MHz / 50 = **4 MHz** (4 million samples per second).

## 5.2 Sampling and aliasing

Sampling throws away everything between the samples, so different continuous signals can produce exactly the same samples. Any frequency above **half the sample rate**, the **Nyquist frequency** f\_s/2, is indistinguishable from a lower one. This is called **aliasing**, and it is the most important limit in all of DSP.

### Two tones, one set of samples

Sample a 7 kHz cosine and a 3 kHz cosine at f\_s = 10 kHz:

```python
fs = 10000.0
n  = np.arange(8)
a  = np.cos(2 * np.pi * 7000 * n / fs)
b  = np.cos(2 * np.pi * 3000 * n / fs)
print(a)
print(b)
print(np.max(np.abs(a - b)))
```

```text
[ 1.    -0.309 -0.809  0.809  0.309 -1.     0.309  0.809]
[ 1.    -0.309 -0.809  0.809  0.309 -1.     0.309  0.809]
3.0531133177191805e-15
```

The two lists are identical; the difference of 3 × 10⁻¹⁵ is floating-point rounding. Once sampled, the 7 kHz tone **is** a 3 kHz tone, and nothing downstream can undo it. The chart shows why: the fast curve wiggles between the samples, but the samples fall exactly on the slow curve.

> **Figure:** computed from cos(2πft) for f = 7 and 3 kHz, sampled at 10 kHz (shown in the [online version](https://claude.ai/artifact/UEAzBg8TVjMqHYdAtu6sze))

### Why it happens

Adding a whole number of cycles per sample changes nothing at the sample instants. A frequency f + k·f\_s, for any integer k, gives samples cos(2π(f/f\_s + k)n) = cos(2π(f/f\_s)n + 2πkn), and 2πkn is a whole number of turns. So 3 kHz, 13 kHz and 23 kHz all look the same at f\_s = 10 kHz.

Cosine is also symmetric: cos(−θ) = cos(θ). So a frequency −f gives the same samples as +f, and therefore f\_s − f does too. That is why 7 kHz = 10 − 3 kHz looks like 3 kHz. Together, these two facts mean every frequency **folds** into the range 0 to f\_s/2.

A simple rule computes where any frequency lands:

1. Reduce f modulo f\_s: f₁ = f mod f\_s.
2. If f₁ is above f\_s/2, reflect it: the apparent frequency is f\_s − f₁. Otherwise it is f₁.

| True frequency (f\_s = 10 kHz) | Appears as |
| --- | --- |
| 1 kHz | 1 kHz |
| 3 kHz | 3 kHz |
| 5 kHz (exactly f\_s/2) | 5 kHz |
| 7 kHz | 3 kHz |
| 9 kHz | 1 kHz |
| 11 kHz | 1 kHz |
| 12 kHz | 2 kHz |
| 13 kHz | 3 kHz |

For a sine instead of a cosine, a reflected frequency also flips the sign: sampled at 10 kHz, sin(2π · 7000 t) gives exactly the negative of the 3 kHz sine's samples. The magnitude still aliases to 3 kHz; the phase changes.

### The sampling theorem

The **Nyquist–Shannon sampling theorem** states the positive side: a continuous signal that contains **no** frequencies at or above f\_s/2 is completely determined by its samples, and can in principle be reconstructed exactly. So:

- To sample a signal correctly, f\_s must be **more than twice** its highest frequency. CD audio uses 44.1 kHz for hearing that extends to about 20 kHz.
- Before an ADC, an analog **anti-aliasing filter** removes everything above f\_s/2. Once aliasing has happened, no digital processing can remove it, because the alias is indistinguishable from a real signal.

Aliasing matters inside digital hardware too. In Part 10 you will **reduce** the sample rate of a signal (decimation), for example keeping one sample in every eight. That is sampling again, and the signal must first be filtered digitally to below the new Nyquist frequency, or it will alias. Most of a digital down-converter's filters exist for exactly this reason.

### Check your understanding: 5.2

1. A system samples at 48 kHz. What is its Nyquist frequency? Where do tones at 30 kHz, 50 kHz and 96 kHz appear?
2. Why can no digital filter remove aliasing after sampling?
3. A 1 MHz tone is sampled at exactly 1 MHz. What do the samples look like?
4. You must sample a signal whose content extends to 20 kHz, and your anti-aliasing filter needs 4 kHz of room to fall from passing to blocking. What is the minimum sample rate?
5. Using the folding rule, where does 17 kHz appear at f\_s = 10 kHz?

#### Answers

1. Nyquist = **24 kHz**. 30 kHz → 48 − 30 = **18 kHz**. 50 kHz → 50 mod 48 = **2 kHz**. 96 kHz → 96 mod 48 = 0 → **0 Hz**, a constant (DC) value.
2. Because after sampling, the alias and a genuine signal at that frequency produce identical numbers. A filter that removed the alias would remove the genuine signal too; the information about which one it was is gone.
3. Every sample is taken at the same point of the cycle, so all samples are **equal**: the tone appears as a constant (0 Hz). Its value depends on the phase.
4. The filter must pass 20 kHz and block everything from f\_s/2 upward, with 4 kHz in between, so f\_s/2 ≥ 24 kHz: f\_s ≥ **48 kHz**. (That is one reason 48 kHz is a common audio rate.)
5. 17 mod 10 = 7, which is above 5, so it reflects: 10 − 7 = **3 kHz**.

## 5.3 Systems, linearity and the impulse response

A **system** turns an input sequence x\[n\] into an output sequence y\[n\]; every filter and every DSP block in this course is one. If a system is **linear and time-invariant** (LTI), a single sequence, its **impulse response**, tells you everything it will ever do.

### Linearity

A system is **linear** if it obeys two rules:

1. **Scaling:** if input x gives output y, then input a·x gives output a·y, for any number a.
2. **Superposition:** if x₁ gives y₁ and x₂ gives y₂, then x₁ + x₂ gives y₁ + y₂.

The moving sum y\[n\] = x\[n\] + x\[n−1\] + x\[n−2\] + x\[n−3\] is linear: doubling every input doubles every output, and the sum of two input signals produces the sum of their outputs. Systems built only from additions, delays and multiplications by **constants** are always linear.

Counterexamples: y\[n\] = x\[n\]² is not linear (doubling the input quadruples the output). Neither is the **saturating adder** of Part 1: when the sum clips at +127, doubling the input no longer doubles the output. That is the deeper reason for tracking bit growth in hardware. A filter that overflows or saturates stops being linear, and the theory of this part stops applying to it.

### Time invariance

A system is **time-invariant** if delaying the input simply delays the output by the same amount: the system behaves the same today as tomorrow. The moving sum is time-invariant. A system such as y\[n\] = n · x\[n\], whose behavior depends on the sample index itself, is not.

A system with both properties is called **LTI**. All the filters in Parts 7 to 12 are LTI, as long as their arithmetic does not overflow.

### The impulse and the impulse response

The **unit impulse** δ\[n\] (Greek "delta") is the simplest possible signal: a single 1 at n = 0, and 0 everywhere else:

```latex
\delta[n] = 1, 0, 0, 0, 0, \ldots
```

The **impulse response** h\[n\] is the output of a system when the input is δ\[n\]. For the moving sum, feed in 1, 0, 0, 0, 0, ... and the output is 1, 1, 1, 1, 0, 0, ...: the single 1 stays in the window for four samples. So h\[n\] = 1, 1, 1, 1.

```python
impulse = np.zeros(8); impulse[0] = 1
print(np.convolve(impulse, np.ones(4))[:8])     # the moving sum of an impulse
```

```text
[1. 1. 1. 1. 0. 0. 0. 0.]
```

You can measure an impulse response of real hardware the same way: feed your `moving_sum4` RTL a single sample of value 1 surrounded by zeros, and the output sequence is h\[n\].

### Why the impulse response is everything

Any input sequence is a sum of scaled, delayed impulses. For example, the input 3, −1, 2 is 3·δ\[n\] − 1·δ\[n−1\] + 2·δ\[n−2\]. For an LTI system:

- each delayed impulse δ\[n−k\] produces a delayed copy of the impulse response, h\[n−k\] (time invariance);
- each scale factor scales that copy, and the copies add (linearity).

So the output is a sum of scaled, delayed copies of h. That sum is **convolution**, the subject of section 5.4. Knowing h, you can compute the output for any input.

### FIR and IIR systems

The moving sum's impulse response ends after 4 samples: it is a **finite impulse response** (FIR) system. A system with **feedback**, whose output depends on its own past outputs, can respond forever. For example:

```latex
y[n] = x[n] + 0.5 \, y[n-1]
```

has impulse response 1, 0.5, 0.25, 0.125, ..., which halves forever without reaching zero: an **infinite impulse response** (IIR) system. FIR filters (Part 7) are always stable and easy to make exact in hardware; IIR filters (Part 8) achieve sharper responses with far fewer operations, but need care with stability and rounding.

### Causality

A system is **causal** if its output at time n depends only on inputs at n and earlier, never on future inputs. Real-time hardware must be causal: it cannot use a sample that has not arrived. For causal LTI systems, h\[n\] = 0 for n < 0. All our designs are causal.

### Check your understanding: 5.3

1. Is y\[n\] = 3x\[n\] − 2x\[n−1\] linear? Time-invariant? What is its impulse response?
2. Is y\[n\] = x\[n\] + 5 linear? Explain using the scaling rule with a = 0.
3. A filter's impulse response is h = 2, 0, −1. What is its output for the input x = 1, 1, 0, 0, 0?
4. What is the impulse response of y\[n\] = x\[n\] − 0.9 y\[n−1\] for the first five samples? Is it FIR or IIR?
5. A hardware filter's adder occasionally overflows and wraps. Is the hardware still an LTI system?

#### Answers

1. Linear: yes (only constant multiplications and additions). Time-invariant: yes (no dependence on n itself). Impulse response: feed δ: y\[0\] = 3, y\[1\] = −2, then 0: **h = 3, −2**.
2. **No.** With a = 0, the input 0 gives output 5, but scaling requires 0 × (output) = 0. Adding a constant breaks linearity. (Such systems are called affine.)
3. The input is δ\[n\] + δ\[n−1\], so the output is h\[n\] + h\[n−1\]: (2, 0, −1, 0) + (0, 2, 0, −1) = **2, 2, −1, −1, 0**.
4. y\[0\] = 1, y\[1\] = −0.9, y\[2\] = 0.81, y\[3\] = −0.729, y\[4\] = 0.6561: **(−0.9)ⁿ**, alternating in sign and decaying. It never reaches zero, so it is **IIR**.
5. **No.** Wrap-around overflow is a nonlinear operation: the output is no longer a scaled, shifted sum of impulse responses. For the inputs where it happens, the LTI theory gives the wrong answer, which is why bit growth must be planned so that overflow cannot occur.

## 5.4 Convolution

The output of any LTI system is the **convolution** of its input with its impulse response. Convolution is a sum of products, and in hardware it is a delay line, a set of multipliers and an adder: the FIR filter you will build in Part 7.

### The formula

For a filter with impulse response h\[0\], h\[1\], ..., h\[M−1\] (M **taps**):

```latex
y[n] = \sum_{k=0}^{M-1} h[k] \, x[n-k] = h[0]x[n] + h[1]x[n-1] + \cdots + h[M-1]x[n-M+1]
```

Read it as: "the output now is the current input times h\[0\], plus the previous input times h\[1\], and so on". Each h\[k\] is a **coefficient**, or tap weight. For the moving sum, all four coefficients are 1, which gives back y\[n\] = x\[n\] + x\[n−1\] + x\[n−2\] + x\[n−3\].

This is exactly the "sum of scaled, delayed copies of h" from section 5.3, regrouped by output sample instead of by input sample.

### Worked by hand

Take h = 1, 2, 1 (a simple smoothing filter) and x = 1, 3, 2, 0, −1. Inputs before n = 0 are 0.

| n | h\[0\]·x\[n\] | h\[1\]·x\[n−1\] | h\[2\]·x\[n−2\] | y\[n\] |
| --- | --- | --- | --- | --- |
| 0 | 1·1 = 1 | 2·0 = 0 | 1·0 = 0 | **1** |
| 1 | 1·3 = 3 | 2·1 = 2 | 1·0 = 0 | **5** |
| 2 | 1·2 = 2 | 2·3 = 6 | 1·1 = 1 | **9** |
| 3 | 1·0 = 0 | 2·2 = 4 | 1·3 = 3 | **7** |
| 4 | 1·(−1) = −1 | 2·0 = 0 | 1·2 = 2 | **1** |
| 5 | 0 | 2·(−1) = −2 | 1·0 = 0 | **−2** |
| 6 | 0 | 0 | 1·(−1) = −1 | **−1** |

After the input ends at n = 4, the filter keeps producing outputs for M − 1 = 2 more samples while the last inputs pass through the delay line.

### In NumPy

```python
h = np.array([1, 2, 1])
x = np.array([1, 3, 2, 0, -1])
y = np.convolve(x, h)
print(y, len(y))          # full convolution: length N + M - 1
print(y[:len(x)])         # what a streaming filter outputs while x arrives
```

```text
[ 1  5  9  7  1 -2 -1] 7
[1 5 9 7 1]
```

The result matches the table. Two facts about `np.convolve` that matter for golden models:

- The **full** output has N + M − 1 samples. A streaming hardware filter produces one output per input, so the golden model in Part 4 kept only the first N with `[:len(x)]`.
- Convolution is **commutative**: `np.convolve(h, x)` gives the same result. Mathematically, filtering x by h equals filtering h by x.

Written as an explicit loop, which is closer to what hardware does, the same computation is:

```python
N, M = len(x), len(h)
y = []
for n in range(N + M - 1):
    acc = 0
    for k in range(M):
        if 0 <= n - k < N:
            acc += h[k] * x[n - k]       # one multiply-accumulate (MAC)
    y.append(acc)
```

The inner line is a **multiply-accumulate**, or MAC: the fundamental operation of DSP, and exactly what a DSP block in an FPGA is built to do.

### Convolution as hardware

The formula maps directly onto hardware: a delay line holds x\[n\], x\[n−1\], and so on; each tap has a multiplier by its constant h\[k\]; an adder combines the products.

> **Figure:** direct-form FIR filter, 4 taps (shown in the [online version](https://claude.ai/artifact/UEAzBg8TVjMqHYdAtu6sze))

This structure is the **direct-form FIR filter**. The moving sum of Part 2 is the special case with every h\[k\] = 1, where the multipliers disappear. Part 7 builds the general version, along with faster arrangements (the transposed form) and tricks for symmetric coefficients.

### The cost of convolution

An M-tap filter needs **M multiplications and M − 1 additions per output sample**. This tells you the hardware budget:

- A 64-tap filter at 100 million samples per second needs 6.4 billion multiplications per second. At a 100 MHz clock that is 64 multipliers working in parallel, typically 64 DSP blocks.
- The same filter at 1 million samples per second, with a 100 MHz clock, has 100 clock cycles per sample. One multiplier, reused 64 times per sample and sequenced by a controller (the Part 3 method), is enough.

### Check your understanding: 5.4

1. Compute by hand the full convolution of x = 2, −1, 3 with h = 1, −1. Check with `np.convolve`.
2. A filter has 31 taps and the input has 1,000 samples. How long is the full convolution?
3. Show that convolving with h = 0, 0, 1 delays a signal by two samples, and that h = 0.5 halves it.
4. How many MACs per second does a 128-tap filter need at a 48 kHz sample rate? Could one multiplier at 100 MHz handle it?
5. Why does the moving sum's hardware need no multipliers?

#### Answers

1. y\[0\] = 2·1 = 2; y\[1\] = −1·1 + 2·(−1) = −3; y\[2\] = 3·1 + (−1)(−1) = 4; y\[3\] = 3·(−1) = −3. **y = 2, −3, 4, −3**, length 3 + 2 − 1 = 4.
2. N + M − 1 = 1,000 + 31 − 1 = **1,030** samples.
3. With h = 0, 0, 1 the sum has one non-zero term, y\[n\] = 1·x\[n−2\]: the input delayed by two samples. With h = 0.5, y\[n\] = 0.5·x\[n\]. A delay and a gain are the simplest filters.
4. 128 × 48,000 = **6,144,000** MACs per second, about 6.1 million. A 100 MHz clock gives 100,000,000 / 48,000 ≈ 2,083 cycles per sample, far more than 128, so **one** multiplier, time-shared, is plenty.
5. All its coefficients are 1, and multiplying by 1 is just a wire. Coefficients that are powers of two (2, 4, 0.5) are also cheap: they are shifts.

## 5.5 Frequency response

Feed a sinusoid into an LTI system and the output is a sinusoid of the **same frequency**, only scaled and shifted. The scale factor and the shift, as a function of frequency, are the system's **frequency response**: the single most useful description of a filter. For the moving average it predicts the RTL's behavior to four decimal places, as measured at the end of this section.

### A refresher on complex numbers

The frequency response is a complex number at each frequency, so here is what you need, and nothing more.

- A complex number is z = a + jb, where j² = −1. (Mathematicians write i; engineers write j because i is current.) In Python: `z = 3 + 4j`.
- Plotted as a point (a, b) in the plane, it has a **magnitude** |z| = √(a² + b²) (its distance from the origin) and an **angle** or phase ∠z (its direction). For 3 + 4j: |z| = 5, angle 53.13°. In NumPy: `abs(z)` and `np.angle(z)` (in radians).
- **Euler's formula** connects complex numbers to sinusoids: e^{jθ} = cos θ + j sin θ, a point at angle θ on the unit circle. For example e^{jπ/2} = j.
- Multiplying two complex numbers **multiplies their magnitudes and adds their angles**. This is why they describe filters so neatly: a gain multiplies, a phase shift adds.

### Why a sinusoid comes out as a sinusoid

Use the complex sinusoid x\[n\] = e^{jωn}, with ω = 2πf/f\_s in radians per sample. Put it through the convolution formula:

```latex
y[n] = \sum_k h[k] \, e^{j\omega(n-k)} = e^{j\omega n} \underbrace{\sum_k h[k] \, e^{-j\omega k}}_{H(\omega)}
```

The output is the input multiplied by one complex number, H(ω), that depends on the frequency but not on n. So:

```latex
H(\omega) = \sum_{k=0}^{M-1} h[k] \, e^{-j\omega k}
```

For a real cosine of amplitude A, the output is a cosine of the same frequency, with amplitude **A · |H(ω)|** and phase shifted by **∠H(ω)**. |H| is the **magnitude response** (the gain at each frequency) and ∠H is the **phase response**.

In NumPy, with f in cycles per sample:

```python
def H(h, f):
    """Frequency response of FIR coefficients h at f cycles/sample."""
    k = np.arange(len(h))
    return np.sum(h * np.exp(-2j * np.pi * f * k))

h4 = np.ones(4) / 4                    # 4-sample moving AVERAGE
for f in [0, 0.05, 0.1, 0.2, 0.25, 0.3, 0.4, 0.5]:
    v = H(h4, f)
    print(f"f={f:5.3f}  |H|={abs(v):.4f}  phase={np.degrees(np.angle(v)):8.2f} deg")
```

If SciPy is installed, `scipy.signal.freqz(h4)` computes the same thing over a grid of frequencies; we checked that it gives |H| = 0.7694 at f = 0.1, matching the function above.

### The moving average's response

For the M-sample moving average, the sum has a closed form:

```latex
|H(f)| = \left| \frac{\sin(\pi f M)}{M \sin(\pi f)} \right|, \qquad f \text{ in cycles per sample}
```

The chart plots it for M = 4 and M = 8, from 0 to the Nyquist frequency, together with gains measured on the RTL.

> **Figure:** theory: |sin(πfM)/(M sin(πf))|; dots: measure\_rtl.py on moving\_sum4.sv, Icarus 12.0, 13 frequencies (shown in the [online version](https://claude.ai/artifact/UEAzBg8TVjMqHYdAtu6sze))

What it says:

- **Gain 1 at 0 Hz**: a constant input passes unchanged (on average; the hardware moving **sum** has gain 4, hence the division by 4 everywhere).
- **Low frequencies pass, high ones are reduced**: it is a **low-pass filter**, which is why the noisy sine of Part 4, Exercise 3, came out smoother.
- **Exact zeros** at multiples of f\_s/M: for M = 4, at f\_s/4 and f\_s/2. A tone at exactly f\_s/4 (1, 0, −1, 0, ...) sums to zero over any 4 samples.
- **Poor rejection between the zeros**: the bump around 3f\_s/8 reaches 0.27. A frequency there is only reduced to about a quarter. Part 7 designs filters with far better rejection.
- **A longer average is a narrower filter**: M = 8 starts falling earlier, with its first zero at f\_s/8.

### The phase: a pure delay

The printed phases are −27° at f = 0.05, −54° at 0.1, −108° at 0.2: proportional to frequency. A phase of −2πf·D radians is exactly a delay of D samples, and here −∠H/(2πf) = **1.5 samples** at every frequency. The moving average delays every frequency by the same 1.5 samples, the middle of its 4-sample window. This property, **linear phase**, holds for every FIR filter with symmetric coefficients, and it is one reason FIR filters are popular: they do not distort the shape of a waveform, they only delay it. (Above the first zero the printed phase jumps by 180°: |H| was taken as positive, so a sign change in the sum shows up as a 180° phase step.)

### Measuring a gain correctly

The obvious way to measure the output amplitude, taking the largest output sample, is wrong. Feeding cos(2π · 0.1 · n) through the average and taking `np.max(np.abs(y))` gives **0.7318**, not 0.7694, because the samples rarely land exactly on a peak. Here the peaks fall half a sample between samples, and cos(18°) = 0.951 of 0.7694 is 0.7318.

The correct way projects the signal onto a complex sinusoid of the known frequency, which measures the amplitude regardless of where the samples fall:

```python
def amplitude(y, f):
    """Amplitude of the component of y at f cycles/sample."""
    n = np.arange(len(y))
    return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))
```

This is a single-frequency **discrete Fourier transform**, the operation that the FFT of Part 11 computes for many frequencies at once. It is most accurate when the signal contains many cycles.

### Checking the theory on the RTL

The script below uses the Part 4 flow to feed 2,000-sample cosines of amplitude 16,000 into the unchanged `moving_sum4` RTL at 13 frequencies, and measures the gain from the RTL's output file. It skips the first 100 outputs (the start-up transient while the delay line fills) and divides by 4 to turn the moving sum into an average:

```python
#!/usr/bin/env python3
"""measure_rtl.py -- measure the moving_sum4 RTL's gain at several frequencies."""
import subprocess
import numpy as np

W, N, A = 16, 2000, 16000             # input width, samples, input amplitude

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

def amplitude(y, f):
    """Amplitude of the component of y at f cycles/sample (projection onto a complex sinusoid)."""
    n = np.arange(len(y))
    return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))

subprocess.run(["iverilog", "-g2012", "-o", "sim", "moving_sum4.sv", "tb_moving_sum4_files.sv"], check=True)
for f in [0.0, 0.025, 0.05, 0.075, 0.1, 0.125, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45]:
    n = np.arange(N)
    x = np.round(A * np.cos(2 * np.pi * f * n)).astype(np.int64)
    y_ref = np.convolve(x, np.ones(4, dtype=np.int64))[:N]
    open("x.hex", "w").write("\n".join(to_hex(x, W)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(y_ref, W + 2)) + "\n")
    subprocess.run(["vvp", "-n", "sim", f"+N={N}"], check=True, capture_output=True)
    y = from_hex("y_actual.hex", W + 2)[100:]          # skip the start-up transient
    xs = x[100:]
    if f == 0.0:
        gain = np.mean(y) / (4 * np.mean(xs))
    else:
        gain = amplitude(y, f) / (4 * amplitude(xs, f))
    theory = 1.0 if f == 0 else abs(np.sin(4 * np.pi * f) / (4 * np.sin(np.pi * f)))
    print(f"f/fs={f:5.3f}  RTL gain={gain:.4f}  theory={theory:.4f}")
```

Every one of the 13 measured gains matched the formula to all four printed decimals (they are the dots on the chart above). Because the testbench still checks bit-exactness against `y_expected.hex`, each run also re-verified the RTL; a mismatch would have stopped the script through `$fatal` and `check=True`. That is the payoff of the Part 4 flow: the same infrastructure verifies the bits and measures the behavior.

### Check your understanding: 5.5

1. Compute |z| and ∠z in degrees for z = 1 − j. What is e^{jπ}?
2. A filter has |H| = 0.5 and ∠H = −90° at 1 kHz. The input is 2 cos(2π · 1000 t). What is the output?
3. Using the formula, compute the 4-sample average's gain at f = 1/8 cycles per sample. Check against the chart.
4. An 8-sample moving average runs at f\_s = 48 kHz. At which frequencies does it have exact zeros below 24 kHz?
5. Why does the moving average delay every frequency by exactly 1.5 samples?
6. Why does `np.max(np.abs(y))` underestimate the amplitude of a sampled sinusoid?

#### Answers

1. |1 − j| = √2 ≈ **1.414**, angle **−45°**. e^{jπ} = cos π + j sin π = **−1**.
2. Amplitude 2 × 0.5 = 1, phase −90°: **cos(2π · 1000 t − 90°) = sin(2π · 1000 t)**.
3. sin(π · 4/8) / (4 sin(π/8)) = 1 / (4 × 0.3827) = **0.6533**. The chart's 4-sample curve and its dot at f = 0.125 both show 0.6533.
4. At multiples of f\_s/8 = 6 kHz: **6, 12 and 18 kHz** (24 kHz is the Nyquist frequency itself, also a zero).
5. Its coefficients are symmetric about the middle of the window, which lies between taps 1 and 2: at (4 − 1)/2 = 1.5 samples. A symmetric FIR filter has linear phase, a constant delay of (M − 1)/2 samples.
6. The sample instants rarely coincide with the peaks of the underlying sinusoid, so the largest sample is usually below the true amplitude. Projecting onto a complex sinusoid uses all samples and is independent of where they fall.

## 5.6 Decibels and noise

Gains in DSP span huge ranges (a good filter passes a signal at gain 1 and suppresses noise by a factor of 10,000), so engineers measure them on a logarithmic scale, in **decibels**. This section introduces dB, the −3 dB cutoff, and answers the question from Part 4, Exercise 3: how much noise does a moving average remove?

### Decibels

For an **amplitude** ratio r (a gain like |H|):

```latex
\text{gain in dB} = 20 \log_{10} r
```

For a **power** ratio p (power is proportional to amplitude squared), the same number of dB is 10 log₁₀ p. Both formulas give the same answer for the same signal, because 10 log₁₀ r² = 20 log₁₀ r.

| Amplitude ratio | dB | Remember it as |
| --- | --- | --- |
| 10 | +20.00 | ten times larger |
| 2 | +6.02 | double: about +6 dB |
| 1 | 0.00 | unchanged |
| 0.7071 (1/√2) | −3.01 | half the **power**: the cutoff point |
| 0.5 | −6.02 | half the amplitude |
| 0.25 | −12.04 | a quarter |
| 0.1 | −20.00 | a tenth |
| 0.01 | −40.00 | a hundredth |

Useful habits: each factor of 2 in amplitude is about 6 dB, each factor of 10 is 20 dB, and dB values **add** when gains multiply. A 6 dB stage followed by a −20 dB stage gives −14 dB overall.

The 6 dB per factor of two has a direct hardware meaning: **every extra bit of a fixed-point word doubles its range, adding about 6.02 dB** of dynamic range. A 16-bit audio sample has roughly 96 dB. Part 6 uses this rule constantly.

### The −3 dB cutoff

The frequency at which a low-pass filter's gain falls to 1/√2 ≈ 0.7071 (−3 dB, half power) is its **cutoff frequency**, the conventional boundary between "passed" and "attenuated". Solving |H(f)| = 0.7071 numerically for the moving averages:

| Filter | −3 dB cutoff (cycles per sample) | At f\_s = 48 kHz |
| --- | --- | --- |
| 4-sample average | 0.1138 | about 5.5 kHz |
| 8-sample average | 0.0557 | about 2.7 kHz |

Doubling the length roughly halves the cutoff, as the chart in section 5.5 suggested.

### How much noise a moving average removes

**White noise** is a random signal whose samples are independent, with equal power at all frequencies. Its power is its **variance** σ² (the mean of the squared values, for zero-mean noise).

Averaging M independent samples reduces the variance by a factor of M. The sum of M independent values has variance M·σ²; dividing by M divides the variance by M², leaving σ²/M. In decibels, the noise power drops by **10 log₁₀ M**: 6.02 dB for M = 4 and 9.03 dB for M = 8.

Checking it on a million samples of white noise:

```python
rng = np.random.default_rng(0)
noise = rng.normal(0, 1, 1_000_000)
for M in (4, 8):
    y = np.convolve(noise, np.ones(M) / M)[M:-M]       # drop the start and end transients
    print(M, round(np.var(y) / np.var(noise), 4), round(10 * np.log10(np.var(noise) / np.var(y)), 2))
```

```text
4 0.2494 6.03
8 0.1244 9.05
```

The measured ratios match 1/4 and 1/8 to within the randomness of the test.

### Signal-to-noise ratio

The **signal-to-noise ratio** (SNR) is the signal power divided by the noise power, usually in dB. A slow tone passes the moving average almost unchanged, while the white noise loses 6 dB, so the SNR improves by about 6 dB. Testing a tone at 0.01 cycles per sample with noise of standard deviation 0.3:

```python
n = np.arange(200_000)
s = np.cos(2 * np.pi * 0.01 * n)               # slow tone, gain 0.998 through the filter
w = rng.normal(0, 0.3, len(n))                 # white noise
h = np.ones(4) / 4
ys, yw = np.convolve(s, h)[:len(n)], np.convolve(w, h)[:len(n)]
snr = lambda sig, noi: 10 * np.log10(np.mean(sig**2) / np.mean(noi**2))
print(round(snr(s, w), 2), round(snr(ys[10:], yw[10:]), 2))
```

```text
7.47 13.47
```

The SNR improved from 7.47 dB to 13.47 dB: exactly 6.0 dB. That is why the output plot in Part 4, Exercise 3 looked smoother. Because the filter is linear, it processes the tone and the noise separately and adds the results (superposition, section 5.3), which is what makes this calculation possible.

A filter only improves SNR when the signal and the noise occupy different frequencies. A sharper filter that passes the signal's band and blocks everything else removes more noise; designing those is the subject of Part 7.

### Check your understanding: 5.6

1. Convert to dB: an amplitude gain of 4, an amplitude gain of 0.001, and a power gain of 0.5.
2. A filter has a gain of −26 dB at 10 kHz. Roughly what fraction of the amplitude gets through?
3. Three stages have gains of +12 dB, −3 dB and −20 dB. What is the total gain in dB, and as an amplitude ratio?
4. How many dB of noise reduction does a 16-sample moving average give on white noise? Can you get 20 dB with a moving average, and how long would it be?
5. Roughly how many dB of dynamic range does a 12-bit ADC have?

#### Answers

1. 20 log₁₀ 4 = **+12.04 dB**; 20 log₁₀ 0.001 = **−60 dB**; 10 log₁₀ 0.5 = **−3.01 dB**.
2. −26 dB = −20 dB − 6 dB: a tenth times a half, about **1/20 = 0.05**. (Exactly: 10^(−26/20) = 0.0501.)
3. 12 − 3 − 20 = **−11 dB**, an amplitude ratio of 10^(−11/20) ≈ **0.28**.
4. 10 log₁₀ 16 = **12.04 dB**. 20 dB requires 10 log₁₀ M = 20, so **M = 100** samples. That works, but the cutoff becomes very low; it is more often better to design a proper low-pass filter.
5. About 12 × 6.02 ≈ **72 dB**.

## 5.7 Exercises

These exercises are mostly Python, with one return to your RTL. For scale: their worked solutions add 3 Python scripts, about 110 new lines, and reuse the RTL of earlier parts (not counting short checks run inline). Time depends too much on experience for a reliable estimate, so none is given. Send me your code, your plots and your answers.

- [ ] Exercise 1: find the alias by experiment
- [ ] Exercise 2: your own convolution
- [ ] Exercise 3: the 1-2-1 filter, by hand and in NumPy
- [ ] Exercise 4: remove mains hum
- [ ] Exercise 5: two tones through the filter
- [ ] Exercise 6: measure your moving\_avg8 RTL

### Exercise 1: find the alias by experiment

Generate 1,000 samples of cos(2πft) at f\_s = 10 kHz for f = 1, 4, 6, 9, 11, 14 and 19 kHz.

- For each, use `amplitude(y, f)` from section 5.5 to scan apparent frequencies from 0 to 5 kHz in 10 Hz steps, and report where the amplitude peaks.
- Compare each result with the folding rule of section 5.2.
- Then repeat with sine instead of cosine. Which tones come out with inverted sign? Explain using the symmetry of sine.

### Exercise 2: your own convolution

- Write `my_convolve(x, h)` with two nested loops (as in section 5.4), returning the full N + M − 1 outputs.
- Compare it with `np.convolve` on 100 random pairs of integer sequences of random lengths. Use `np.array_equal` and make the test print PASS or FAIL.
- Then write `my_convolve_streaming(x, h)` that returns only the first N outputs, as the hardware does, using a delay-line list that you shift by one sample per input, exactly like the RTL's registers.

### Exercise 3: the 1-2-1 filter, by hand and in NumPy

The filter h = ¼(1, 2, 1) is a common smoothing filter.

- By hand: write H(ω) = ¼(1 + 2e^{−jω} + e^{−2jω}). Factor out e^{−jω} and use e^{jω} + e^{−jω} = 2 cos ω to show that |H(ω)| = (1 + cos ω)/2. Evaluate it at 0, f\_s/4 and f\_s/2.
- In NumPy: plot |H| for this filter and for the 4-sample average on the same axes, from 0 to f\_s/2. Which has better rejection near f\_s/2? Which has the higher −3 dB cutoff?
- What is its delay in samples, and why?

### Exercise 4: remove mains hum

A sensor sampled at f\_s = 1 kHz picks up 50 Hz interference from the mains supply (60 Hz in North America).

- Choose the moving-average length M that places an exact zero at 50 Hz. Which other frequencies are also removed?
- Simulate: a slow 2 Hz signal of amplitude 1 plus a 50 Hz hum of amplitude 0.5. Plot the input and output, and measure how much of each remains.
- Repeat for 60 Hz. Is there one M that removes both 50 Hz and 60 Hz exactly?

### Exercise 5: two tones through the filter

Send x\[n\] = cos(2π · 0.05 · n) + cos(2π · 0.3 · n) through the 4-sample average.

- **Predict** the output amplitude of each tone from the chart in section 5.5 before running anything.
- Then measure both with `amplitude()`. Explain why measuring each tone separately works even though they are added together (which property of section 5.3?).
- Predict and check the delay of each tone in samples.

### Exercise 6: measure your moving\_avg8 RTL

Adapt `measure_rtl.py` to your `moving_avg8` from Part 2 (the version that divides by 8 with `>>> 3`).

- Measure the gain at 20 frequencies from 0 to 0.45 cycles per sample, and plot the measurements over the theoretical curve for M = 8.
- Feed it a single impulse of value 8,000 and record the output: is it the impulse response you expect?
- `>>> 3` rounds every output down by up to 7/8 of an LSB. Measure that error directly (the RTL output minus the exact sum divided by 8, on random samples): its mean and spread. Then explain why the gains measured at amplitude 16,000 still match the theory to about five decimal places, and repeat the gain measurement at amplitudes 200 and 20, where the error becomes visible. (Hint: what does `>>> 3` do to the low 3 bits, and how large is 1 LSB compared with the signal? Part 6 answers this properly.)

## 5.8 Summary and what comes next

You now have the core vocabulary of DSP, and you have checked it against real RTL. Keep this table beside you for the exercises and for Part 7.

| Idea | Formula or tool | Remember |
| --- | --- | --- |
| Sampling | x\[n\] = x(nT), f\_s = 1/T | Only f/f\_s matters to the hardware |
| Nyquist frequency | f\_s/2 | Higher frequencies fold back (alias) |
| Folding rule | f mod f\_s, then reflect above f\_s/2 | Aliasing cannot be undone after sampling |
| LTI system | Linear + time-invariant | Overflow and saturation break linearity |
| Impulse response | Output for δ\[n\] = 1, 0, 0, ... | FIR: finite; IIR: feedback, infinite |
| Convolution | y\[n\] = Σ h\[k\] x\[n−k\] | `np.convolve`; full length N + M − 1 |
| Cost | M multiply-accumulates per sample | Sets the number of multipliers |
| Frequency response | H(ω) = Σ h\[k\] e^{−jωk} | A sinusoid in gives the same frequency out |
| Gain and phase | \|H\| scales, ∠H shifts | Symmetric FIR: delay of (M−1)/2 samples |
| Moving average | \|sin(πfM) / (M sin(πf))\| | Zeros at multiples of f\_s/M |
| Measuring a gain | Project onto e^{−j2πfn} | Not the largest sample |
| Decibels | 20 log₁₀(amplitude ratio) | 6 dB per factor of 2; 6.02 dB per bit |
| Noise of an M-average | Power reduced by 10 log₁₀ M dB | Only if signal and noise differ in frequency |

The ideas that matter most from this part:

1. A filter is completely described by its impulse response, and its output is the convolution of input and impulse response.
2. The frequency response says, frequency by frequency, what the filter keeps and what it removes. Read it before you build anything.
3. Every theoretical prediction can be checked bit-for-bit and frequency-by-frequency on the RTL with the Part 4 flow.

**Part 6: Fixed-point arithmetic and multipliers** turns real-valued coefficients and signals into the integers that hardware uses. You will learn Q-format notation, how to choose word widths with the 6 dB-per-bit rule, the difference between truncation and rounding (and why the `>>> 3` in your moving average is slightly wrong), saturation, and the growth of products. You will build a pipelined multiply-accumulate unit that maps onto an FPGA DSP block, verified bit-exactly against a Python fixed-point model.

### Further reading: the mathematics

This part uses complex exponentials and frequency responses, and Part 8 adds the z-transform and poles. [Appendix C: The Mathematics Behind the DSP Parts](https://claude.ai/artifact/2HA6TpUNfXT1oUGK8nfuyq) collects all of it in one place, with every formula checked numerically; read it now if complex numbers are rusty.
