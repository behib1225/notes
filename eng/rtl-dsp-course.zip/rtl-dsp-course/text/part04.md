# Verilog & RTL for DSP — Part 4: Verification and Synthesis

*Markdown export of the online document: https://claude.ai/artifact/3QsbxnNwYciGtrqhsR5HE2. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 4 fits

Part 4 turns the habits of Parts 1 to 3 into a professional workflow. You will check RTL against a Python reference model through files, catch problems with assertions and lint, and synthesize designs with Yosys to see the hardware they really become.

So far, every testbench computed its own expected answers in SystemVerilog. That works for adders and counters, but not for DSP: the reference for a filter is a few lines of NumPy or SciPy, and rewriting it in a testbench would be slow and error-prone. From here on, **Python is the golden model**: it generates the stimulus, computes the expected output, and judges the result. The testbench becomes a thin layer that moves numbers between files and the design.

Synthesis closes the other half of the loop. A design that passes simulation can still be poor hardware: an accidental latch, a multiplier you did not intend, or a logic path too long for the clock. Yosys, a free open-source synthesizer, reports all of this, and it can map designs to a real FPGA family so you can count lookup tables, carry chains and DSP blocks.

New tools for this part, all free:

| Tool | Install (Linux/WSL) | Install (macOS) | Use |
| --- | --- | --- | --- |
| Python 3 + NumPy | `sudo apt install python3-numpy` | `pip3 install numpy` | Golden models, test vectors |
| Yosys | `sudo apt install yosys` | `brew install yosys` | Synthesis, resource and depth reports |

As before, every example was run: Icarus Verilog 12.0, Verilator 5.020, Yosys 0.33 and Python 3 with NumPy. Each section ends with "Check your understanding" questions and answers, and section 4.8 has the exercises.

## 4.1 The verification flow

The golden model lives in Python, the design lives in SystemVerilog, and plain text files connect them. Each of the three programs does one simple job, so each is easy to trust.

> **Figure:** the verification loop (shown in the [online version](https://claude.ai/artifact/3QsbxnNwYciGtrqhsR5HE2))

1. **Generate.** A Python script creates the input samples and computes the expected outputs with the reference model. It writes both to text files, one number per line.
2. **Simulate.** The testbench reads the inputs, feeds them to the design with realistic timing (here, random gaps in `in_valid`), and writes every output the design produces to a third file. It also compares against the expected file as it goes, so failures show up immediately with a time stamp you can find in the waveform.
3. **Check.** A second Python script reads the actual outputs back and compares them with the model independently, reporting the first mismatch and any statistics you care about.
4. **Repeat.** A shell script runs all three with one command, so you can run the test after every change, and run it for many random seeds.

### Why compare twice?

The comparison inside the testbench gives fast, local feedback: a failing sample number and a simulation time. The comparison in Python is independent of the testbench. If the testbench has a bug, for example it never checks some outputs, or it lines up the wrong samples, the Python check still catches it. Later, for filters, the Python side will also compute things that are awkward in SystemVerilog, such as the error between the fixed-point output and the ideal floating-point result.

### What "bit-exact" means

For integer and fixed-point designs, the Python model is written to compute **exactly** what the hardware should compute, bit for bit: the same widths, the same rounding, the same overflow behavior. Then the check is simple equality, and any difference at all is a bug. This is the standard in DSP hardware teams, and it is the standard for the rest of this course. (A separate, floating-point model answers a different question: is the bit-exact design accurate enough? That comes in Part 6.)

### Check your understanding: 4.1

1. Why write the expected outputs to a file instead of computing them in the testbench?
2. The testbench comparison passes, but the Python check reports that the RTL produced 1,999 outputs instead of 2,000. What kind of bug could cause this, and why did the testbench miss it?
3. What does "bit-exact" require of the Python model?
4. Why does the testbench insert random idle cycles between samples instead of sending one sample every clock?

#### Answers

1. For DSP designs the reference is easiest to write, and to trust, in NumPy or SciPy, which have filtering, FFT and fixed-point tools built in. Keeping it in Python also means the same model can later be used for plots and accuracy analysis. The testbench only needs to move numbers, which is simple enough to get right.
2. A design that drops or merges a sample, for example by mishandling `in_valid` on some cycle. The testbench might never notice if it only checks outputs that appear, and it stops when it has seen n of them, or if its own counting logic has the same off-by-one error. Counting outputs independently in Python catches it.
3. It must reproduce the hardware's arithmetic exactly: the same word widths, the same rounding and truncation, and the same overflow behavior (wrap or saturate). Then equality is the right test, and any mismatch is a real bug.
4. Because a real design receives samples at a rate set by the system, not at full clock speed, and many bugs only appear when `in_valid` is low between samples: a delay line that shifts on every clock, or an output valid that is held too long. Random gaps exercise those cases automatically.

## 4.2 File input and output in SystemVerilog

Six system tasks cover everything the flow needs: `$readmemh` to load a whole file into an array, `$fopen`, `$fdisplay` and `$fclose` to write results, `$fscanf` to read a file line by line, and `$value$plusargs` to pass options from the command line. All of them are testbench-only.

### Loading a file into an array: `$readmemh`

```systemverilog
logic [15:0] x_mem [0:99_999];          // capacity: 100,000 words of 16 bits
...
$readmemh("x.hex", x_mem, 0, n - 1);   // load words 0 .. n-1
```

- The file holds one hexadecimal word per line, without `0x` or `16'h`. `$readmemb` is the same for binary.
- `//` comments are allowed in the file, and a line `@2` moves the load address to word 2.
- The optional last two arguments give the address range to fill. Without them, Icarus fills the whole array and warns `Not enough words in the file for the requested range` when the file is shorter. Words that are not loaded stay `x`.

The same task also initializes memories in **design** code: most FPGA synthesis tools accept `$readmemh` in an `initial` block to set the contents of a ROM, such as a table of filter coefficients or sine values. You will use that in Parts 7 and 9.

### Writing results: `$fopen`, `$fdisplay`, `$fclose`

```systemverilog
int fd;
fd = $fopen("y_actual.hex", "w");      // "w" = write (create or overwrite), "r" = read, "a" = append
if (fd == 0) $fatal(1, "cannot open y_actual.hex");
$fdisplay(fd, "%h", y);                 // like $display, but into the file, one line per call
$fclose(fd);                            // flush and close; do this before $finish
```

`$fdisplay` adds a newline; `$fwrite` does not. Always check that `$fopen` returned a non-zero handle: a wrong directory otherwise fails silently.

### Reading line by line: `$fscanf`

When each line holds several fields, or you want decimal values, read with `$fscanf`. It returns the number of items it converted:

```systemverilog
int fd, code;
logic signed [15:0] v;
fd = $fopen("dec.txt", "r");
while (!$feof(fd)) begin
  code = $fscanf(fd, "%d\n", v);
  if (code == 1) $display("read %0d (bits %h)", v, v);
end
$fclose(fd);
```

On a file containing −5, 17, −32768 and 32767, this printed `read -5 (bits fffb)`, `read 17 (bits 0011)`, `read -32768 (bits 8000)` and `read 32767 (bits 7fff)`. Signed decimal values are read correctly into signed variables.

### Command-line options: plusargs

Arguments that start with `+` after the simulation file are **plusargs**, read by the testbench:

```systemverilog
int n = 2000;                                  // default
void'($value$plusargs("N=%d", n));             // vvp sim +N=5000  sets n = 5000
if ($test$plusargs("VERBOSE")) ...             // vvp sim +VERBOSE  turns this on
```

`$value$plusargs` returns 1 if it found the argument; `void'(...)` discards that result when you do not need it. With plusargs, one compiled testbench runs many tests without recompiling.

### Why hexadecimal, and the two's-complement rule

Hex files make every value's width explicit and are what `$readmemh` expects. Negative numbers must be written in **two's complement at the exact width**, with no minus sign. In Python, masking does the conversion in both directions:

```python
def to_hex(values, bits):
    """Format signed integers as two's-complement hex strings of a given width."""
    mask = (1 << bits) - 1
    digits = (bits + 3) // 4
    return [f"{int(v) & mask:0{digits}x}" for v in values]

# reading back:
v = int(line, 16)
if v >= 1 << (bits - 1):      # sign bit set -> negative
    v -= 1 << bits
```

For a 16-bit value, −1 becomes `ffff` and −1758 becomes `f922`; for the 18-bit filter output, −1758 becomes `3f922`. A hex file also makes unknown values obvious: if the design outputs `x`, `$fdisplay` writes an `x` into the line, and the Python reader rejects it.

### Exit codes for scripts

`$display("FAILED")` prints a message, but `vvp` still exits with code 0, so a script cannot tell that anything went wrong. End a failing test with `$fatal(1, "message")` instead: it prints the message, stops the simulation, and makes `vvp` exit with code 1. A watchdog should use `$fatal` too.

### Check your understanding: 4.2

1. Write the two's-complement hex line for −3 at 12 bits, and at 18 bits.
2. A `$readmemh` file has 500 lines but the array has 1,000 entries and you called `$readmemh("f.hex", mem)`. What happens to entries 500 to 999?
3. What is the difference between `$fdisplay` and `$fwrite`?
4. You compile once and want to run the same testbench with 100 and with 100,000 samples. How?
5. A regression script runs `vvp sim` and checks its exit code, but a failing test still "passes". What is wrong in the testbench?

#### Answers

1. At 12 bits: 4096 − 3 = 4093 = **`ffd`**. At 18 bits: 262144 − 3 = 262141 = **`3fffd`** (5 hex digits, of which the top digit uses only 2 bits).
2. They keep their previous value, which is `x` for an uninitialized array, and Icarus prints a warning that the file did not have enough words. Pass an address range, or size the file to match.
3. `$fdisplay` appends a newline after the formatted text; `$fwrite` does not, so several `$fwrite` calls can build one line.
4. Read the count with a plusarg, `void'($value$plusargs("N=%d", n));`, then run `vvp sim +N=100` and `vvp sim +N=100000`. Make the arrays large enough for the biggest run.
5. It reports failure with `$display` and ends with `$finish`, so `vvp` exits with code 0. Use `$fatal(1, ...)` for every failure path, including the watchdog.

## 4.3 A complete example: the moving-sum filter, checked from Python

This section puts the flow together around `moving_sum4.sv` from Part 2, section 2.7, unchanged. Put five files in one folder: the design, and the four below. One command then generates vectors, simulates, and checks.

### File 1: the golden model and vector generator

```python
#!/usr/bin/env python3
"""gen_vectors.py -- golden model and test vectors for moving_sum4.sv

Writes:
  x.hex          one input sample per line, W-bit two's complement, in hex
  y_expected.hex one expected output per line, (W+2)-bit two's complement
"""
import argparse
import numpy as np

def to_hex(values, bits):
    """Format signed integers as two's-complement hex strings of a given width."""
    mask = (1 << bits) - 1
    digits = (bits + 3) // 4
    return [f"{int(v) & mask:0{digits}x}" for v in values]

def golden_moving_sum4(x):
    """Reference model: y[n] = x[n] + x[n-1] + x[n-2] + x[n-3], exact integers."""
    x = np.asarray(x, dtype=np.int64)
    return np.convolve(x, np.ones(4, dtype=np.int64))[: len(x)]

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=2000, help="number of samples")
    p.add_argument("--w", type=int, default=16, help="input width in bits")
    p.add_argument("--seed", type=int, default=1, help="random seed")
    a = p.parse_args()

    rng = np.random.default_rng(a.seed)
    lo, hi = -(1 << (a.w - 1)), (1 << (a.w - 1)) - 1
    x = rng.integers(lo, hi + 1, size=a.n)
    x[100:120] = hi          # a run of full-scale positive values
    x[200:220] = lo          # a run of full-scale negative values
    y = golden_moving_sum4(x)

    with open("x.hex", "w") as f:
        f.write("\n".join(to_hex(x, a.w)) + "\n")
    with open("y_expected.hex", "w") as f:
        f.write("\n".join(to_hex(y, a.w + 2)) + "\n")
    print(f"wrote {a.n} samples (W={a.w}, seed={a.seed}); "
          f"y range {y.min()} .. {y.max()}")

if __name__ == "__main__":
    main()
```

The reference model is one line: `np.convolve(x, np.ones(4))` computes exactly y\[n\] = x\[n\] + x\[n−1\] + x\[n−2\] + x\[n−3\]. **Convolution** is the operation at the heart of every filter, and Part 5 explains it from scratch; for now, read it as "slide a window of four ones along x and add". `dtype=np.int64` keeps the arithmetic exact: NumPy's integers never overflow at these sizes, so the model computes the true sum that the 18-bit hardware must match.

The stimulus is random, plus two deliberate runs of full-scale values. Pure random data almost never produces four extreme samples in a row, so without those runs the worst-case sum (−131,072) would never be tested. Always add the corner cases on purpose.

### File 2: the file-driven testbench

```systemverilog
`timescale 1ns/1ps
// tb_moving_sum4_files.sv -- file-driven testbench: Python makes the vectors,
// the testbench only moves numbers between the files and the design.
module tb_moving_sum4_files;
  localparam int W     = 16;
  localparam int MAX_N = 100_000;            // array capacity

  logic                clk = 1'b0, rst, in_valid, out_valid;
  logic signed [W-1:0] x;
  logic signed [W+1:0] y;

  logic [W-1:0] x_mem   [0:MAX_N-1];         // stimulus from Python
  logic [W+1:0] exp_mem [0:MAX_N-1];         // expected results from Python
  int n = 2000;                              // default; override with +N=...
  int sent = 0, got = 0, errors = 0, fd;
  int seed = 1;                              // override with +SEED=...

  moving_sum4 #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  initial begin #50_000_000; $fatal(1, "TIMEOUT"); end   // watchdog

  // ---- stimulus: one sample per in_valid cycle, with random idle gaps ----
  initial begin
    void'($value$plusargs("N=%d", n));       // read +N=1234 from the command line
    void'($value$plusargs("SEED=%d", seed)); // read +SEED=7
    void'($urandom(seed));                   // seed the testbench's random numbers
    $readmemh("x.hex", x_mem, 0, n - 1);          // load exactly n words
    $readmemh("y_expected.hex", exp_mem, 0, n - 1);
    fd = $fopen("y_actual.hex", "w");

    rst = 1'b1; in_valid = 1'b0; x = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;

    while (sent < n) begin
      in_valid = ($urandom_range(0, 3) != 0);
      x        = in_valid ? x_mem[sent] : 'x;  // x is undefined when not valid
      if (in_valid) sent++;
      @(negedge clk);
    end
    in_valid = 1'b0;
  end

  // ---- protocol check: out_valid must follow in_valid by exactly one cycle ----
  logic in_valid_d = 1'b0;
  always @(posedge clk) in_valid_d <= in_valid && !rst;
  always @(negedge clk) begin
    if (!rst)
      assert (out_valid === in_valid_d)
        else begin $error("out_valid=%b but in_valid one cycle earlier was %b", out_valid, in_valid_d); errors++; end
  end

  // ---- monitor: record and check every output the design marks valid ----
  always @(negedge clk) begin
    if (!rst && out_valid) begin
      assert (!$isunknown(y)) else $error("output %0d has unknown bits: %b", got, y);
      $fdisplay(fd, "%h", y);
      if (y !== exp_mem[got]) begin
        if (errors < 10)
          $display("FAIL sample %0d: got %0d, expected %0d", got, y, $signed(exp_mem[got]));
        errors++;
      end
      got++;
      if (got == n) begin
        $fclose(fd);
        if (errors == 0) $display("PASS: %0d samples match the Python model", n);
        else             $fatal(1, "FAILED: %0d of %0d samples wrong", errors, n);
        $finish;
      end
    end
  end
endmodule
```

The testbench is now two independent processes. The **stimulus** process drives samples with random gaps, and deliberately sets `x` to `'x` on idle cycles: if the design ever uses `x` when `in_valid` is 0, the unknown value will propagate into the output and be caught. The **monitor** watches `out_valid` and handles outputs whenever they appear, so it does not need to know the design's latency. Splitting stimulus from checking like this is how professional testbenches are organized, and it scales to designs whose latency is long or variable.

A third process, the **protocol check**, uses assertions to verify the timing of `out_valid`; section 4.4 explains it, along with the `SEED` plusarg. Two more details: `$signed(exp_mem[got])` reinterprets the stored bits as a signed number for printing, and only the first 10 failures are printed, so a broken design does not flood the screen.

### File 3: the independent checker

```python
#!/usr/bin/env python3
"""check_results.py -- independent check of the RTL output against the golden model."""
import sys
import numpy as np
from gen_vectors import golden_moving_sum4

W = 16

def from_hex(path, bits):
    """Read two's-complement hex lines back into signed Python integers."""
    vals = []
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            if "x" in line.lower() or "z" in line.lower():
                raise ValueError(f"{path}: unknown value '{line}'")
            v = int(line, 16)
            if v >= 1 << (bits - 1):      # sign bit set -> negative
                v -= 1 << bits
            vals.append(v)
    return np.array(vals, dtype=np.int64)

x = from_hex("x.hex", W)
y_rtl = from_hex("y_actual.hex", W + 2)
y_ref = golden_moving_sum4(x)

if len(y_rtl) != len(y_ref):
    print(f"FAIL: RTL produced {len(y_rtl)} outputs, expected {len(y_ref)}")
    sys.exit(1)

bad = np.flatnonzero(y_rtl != y_ref)
if bad.size:
    i = bad[0]
    print(f"FAIL: {bad.size} mismatches; first at sample {i}: rtl={y_rtl[i]} ref={y_ref[i]}")
    sys.exit(1)
print(f"PASS: {len(y_ref)} outputs bit-exact; max |y| = {np.abs(y_ref).max()}")
```

It recomputes the reference from `x.hex` itself rather than trusting `y_expected.hex`, checks the **number** of outputs, and exits with code 1 on any failure.

### File 4: one command for everything

```sh
#!/bin/sh
# run_test.sh -- generate vectors, simulate, check.  Usage: ./run_test.sh [seed] [n]
set -e                                   # stop at the first command that fails
SEED=${1:-1}
N=${2:-2000}
python3 gen_vectors.py --seed "$SEED" --n "$N"
iverilog -g2012 -Wall -o sim moving_sum4.sv tb_moving_sum4_files.sv
vvp -n sim +N="$N" +SEED="$SEED"        # exits non-zero via $fatal on failure
python3 check_results.py
```

Make it executable once with `chmod +x run_test.sh`. The `-n` option tells `vvp` not to stop at an interactive prompt on `$stop`, which is what you want in scripts. Because of `set -e`, the script stops at the first failing step, and its own exit code tells you whether the whole test passed. (On Windows, run it inside WSL.)

### Running it

```text
$ ./run_test.sh 1 2000
wrote 2000 samples (W=16, seed=1); y range -131072 .. 131068
PASS: 2000 samples match the Python model
tb_moving_sum4_files.sv:69: $finish called at 26500000 (1ps)
PASS: 2000 outputs bit-exact; max |y| = 131072
```

The y range shows that both extremes were exercised: −131,072 is exactly the most negative 18-bit value.

To prove the flow catches real bugs, the narrow-adder bug from Part 2 (declaring the sum `logic signed [W-1:0]`) was put back in. The script stopped with exit code 1 after the simulation:

```text
FAIL sample 3: got -20277, expected 45259
FAIL sample 19: got 20100, expected -45436
...
FATAL: tb_moving_sum4_files.sv:68: FAILED: 833 of 2000 samples wrong
```

### Check your understanding: 4.3

1. Why does `gen_vectors.py` use `dtype=np.int64` instead of `np.int16`?
2. Why does the stimulus drive `x = 'x` on idle cycles instead of holding the last value?
3. The monitor process never refers to the design's latency. Why is that an advantage?
4. Why does `check_results.py` recompute the reference from `x.hex` instead of reading `y_expected.hex`?
5. Without the two deliberate full-scale runs, roughly how likely is it that four random 16-bit samples in a row are all exactly −32,768?

#### Answers

1. Because the model must compute the **true** sum, which needs 18 bits. With `int16` the NumPy arithmetic would itself wrap around, and the model would reproduce exactly the overflow bug it is supposed to catch.
2. To prove the design ignores its input when `in_valid` is 0. If the design ever loaded `x` on an idle cycle, the `x` would reach the output and fail the check (and trip the `$isunknown` assertion). Holding the last value would hide that bug, because a repeated sample can look plausible.
3. The same testbench keeps working if the design changes latency, for example after you add a pipeline register (section 4.7). The monitor just waits for `out_valid`; only the order of outputs matters.
4. To be independent of the generator's output file: if `y_expected.hex` were written incorrectly (or left over from a different run), both the testbench and the checker would agree with a wrong reference. Recomputing from the actual inputs avoids trusting an intermediate file.
5. Each sample is −32,768 with probability 1 / 65,536, so four in a row have probability (1/65,536)⁴ ≈ 5 × 10⁻²⁰. It would essentially never happen, which is why extreme values must be put into the stimulus deliberately.

## 4.4 Assertions and regressions

An **assertion** states a rule that must always hold, and complains the moment it is broken. A **regression** runs the same test many times with different random seeds. Together they find the bugs that a single hand-picked test misses.

### Immediate assertions

An immediate assertion checks a condition when the simulator reaches it, like an `if`:

```systemverilog
assert (condition) else $error("message %0d", value);
```

If the condition is false, the `else` part runs. A short test in Icarus:

```systemverilog
c = 3;
assert (c == 0) else $error("c is %0d, expected 0", c);
```

printed:

```text
ERROR: a.sv:5: c is 3, expected 0
       Time: 0  Scope: a
```

The message includes the file, the line, the time and the scope, which is exactly what you need to find the failure in a waveform. Four severity tasks are available: `$info`, `$warning`, `$error` (report and continue) and `$fatal` (report and stop, with a non-zero exit code). Note that `$error` does **not** change the exit code, so the testbench above also increments `errors`, and the final check turns any error into `$fatal`.

Two useful patterns from the testbench in section 4.3:

- **No unknowns on valid outputs:** `assert (!$isunknown(y)) else ...`. `$isunknown` is true if any bit is `x` or `z`. This catches missing resets and uninitialized data paths directly, before they turn into a confusing value mismatch.
- **Protocol timing:** the design promises that `out_valid` follows `in_valid` by exactly one cycle. The testbench delays `in_valid` by one cycle in its own flip-flop and asserts that the two are equal at every falling edge. When `out_valid` was deliberately made "sticky" (`out_valid <= in_valid | out_valid;`), the assertion reported `out_valid=1 but in_valid one cycle earlier was 0` at the first violation, while the data check only reported a confusing wrong sample.

That last point is the real value of assertions: they report the **cause** close to where it happens, instead of a symptom many cycles later.

### Concurrent assertions (SVA)

SystemVerilog also has **concurrent** assertions, written as properties over clock cycles, for example `assert property (@(posedge clk) in_valid |=> out_valid);` ("if `in_valid` is high at one edge, `out_valid` is high at the next"). They are the main tool of professional verification and of formal verification. **Icarus Verilog 12 does not support them**: it reports `Error in property_spec of concurrent assertion item`. Verilator supports a growing subset, and commercial simulators support them fully. In this course, write the same checks as immediate assertions inside clocked `always` blocks, as above; it is a little more code but works everywhere.

### Seeds and reproducibility

Random tests are only useful if a failing run can be repeated exactly. Both random generators in the flow take a seed:

- Python: `np.random.default_rng(seed)` generates the samples.
- The testbench: `void'($urandom(seed));` seeds SystemVerilog's generator, which decides the idle gaps.

We checked that Icarus repeats a sequence exactly for the same seed and gives a different sequence for a different seed. `run_test.sh` passes the same `SEED` to both, so one number reproduces the whole run.

### A regression script

```sh
#!/bin/sh
# regress.sh -- run the test for many seeds; stop at the first failure
for SEED in $(seq 1 20); do
  if ./run_test.sh "$SEED" 5000 > "log_seed$SEED.txt" 2>&1; then
    echo "seed $SEED: pass"
  else
    echo "seed $SEED: FAIL (see log_seed$SEED.txt)"
    exit 1
  fi
done
echo "all 20 seeds passed"
```

It ran 20 × 5,000 samples and printed `all 20 seeds passed`. Each run's output goes to its own log file, so a failure can be read, and reproduced with `./run_test.sh <seed> 5000`. Run the regression after every design change: it is your safety net when you start optimizing designs in later parts.

### Check your understanding: 4.4

1. What is the difference between `$error` and `$fatal`, and why does the testbench use both?
2. Write an immediate assertion that checks, at every falling clock edge after reset, that a `count` signal never exceeds 9.
3. Why did the sticky-`out_valid` bug produce a clearer message from the protocol assertion than from the data check?
4. Why must the testbench's random generator be seeded from the same `SEED` as the Python generator?
5. A regression of 20 seeds passes. Does that prove the design is correct?

#### Answers

1. `$error` reports a failure and lets the simulation continue, so you can see how many things fail; `$fatal` reports and stops immediately with a non-zero exit code. The testbench uses `$error` for individual violations (counting them) and `$fatal` at the end, so that the overall result is visible to scripts.
2. `always @(negedge clk) if (!rst) assert (count <= 9) else $error("count = %0d exceeds 9", count);`
3. The protocol assertion checks the rule that was actually broken (valid timing) at the exact cycle where it first broke. The data check only sees the consequence, a wrong value in an output slot, which could have many causes.
4. So that one number reproduces the entire run. If the testbench used a fixed or independent seed, re-running a failing Python seed might not produce the same pattern of idle cycles, and a timing-dependent bug might not reappear.
5. **No.** It shows that no bug appeared for those 20 stimulus sets. Random testing makes bugs unlikely to survive, especially combined with deliberate corner cases and assertions, but it never proves their absence. Proving properties for **all** inputs is the job of formal verification, which is beyond this course.

## 4.5 Linting systematically

The rule for this course: **every design file passes `verilator --lint-only -Wall` with no warnings**, and any exception is waived in the narrowest possible scope with a comment explaining why. Lint takes a second to run and has caught a real bug in every part so far.

### Linting a whole design

For a design with several modules, list all the files and name the top module:

```sh
verilator --lint-only -Wall --top-module seq_mult seq_mult.sv mult_ctrl.sv mult_datapath.sv
```

Linting the hierarchy finds problems that single files cannot show, such as ports that are not connected. Lint design files only, not testbenches: testbenches legitimately use constructs (delays, `$urandom` truncation, unused helper signals) that lint would flag.

### The warnings you will meet

Every message below was produced by Verilator 5.020 on a small example. The first column is the warning's name, which you also use to waive it.

| Warning | Example message | What it usually means | Usual fix |
| --- | --- | --- | --- |
| `WIDTHTRUNC` | `expects 4 bits on the Assign RHS, but ... 'a' generates 8 bits` | High bits are being silently dropped | Select bits explicitly, or widen the target |
| `WIDTHEXPAND` | `expects 8 bits on the Assign RHS, but ... 'b' generates 4 bits` | An operand is being silently widened | Extend explicitly: `{4'b0, b}` or a size cast |
| `UNUSEDSIGNAL` | `Signal is not used: 'clk'` | Dead logic, a missing connection, or a design simplification (Part 3's carry flip-flop) | Remove it, connect it, or waive it with a reason |
| `UNDRIVEN` | `Signal is not driven: 'never_driven'` | A signal is read but nothing assigns it: it will be `x` | Drive it |
| `PINMISSING` | `Cell has missing pin: 'product'` | An instance leaves a port unconnected | Connect it, or write `.product()` to show it is deliberate (see question 3) |
| `LATCH` | `Latch inferred for signal 'q'` | A combinational path does not assign an output | Default assignments at the top of `always_comb` |
| `BLKSEQ` | `Blocking assignment '=' in sequential logic process` | `=` inside `always_ff` | Use `<=` |
| `COMBDLY` | `Non-blocking assignment '<=' in combinational logic process` | `<=` inside `always_comb` | Use `=` |
| `CASEINCOMPLETE` | `Case values incompletely covered` | A `case` without `default` that misses values | Add `default` |
| `UNSIGNED` | `Comparison is constant due to unsigned arithmetic` | A signed/unsigned mix made a comparison meaningless | Fix the signedness (Part 1, section 1.4) |
| `UNOPTFLAT` | `Circular combinational logic: 'loop.p'` | A combinational loop: logic feeding itself without a register | Break the loop with a register |
| `TIMESCALEMOD` | `Timescale missing on this module as other modules have it` | Files disagree on `` `timescale `` | Put the same `` `timescale `` in every file |
| `DECLFILENAME` | `Filename 'b2' does not match MODULE name` | File naming convention broken | One module per file, named after it |

Notice that Verilator was **not** perfect either. In Part 3 it missed a latch that Yosys reported, and in Part 2 it did not complain about a register driven from two `always_ff` blocks. Lint is a strong filter, not a proof.

### Waivers: when the warning is wrong

Sometimes the code is intentional. Then waive the warning around the exact lines, and say why:

```systemverilog
  /* verilator lint_off WIDTHTRUNC */
  assign y = a;                 // intentional: keep the low 4 bits
  /* verilator lint_on WIDTHTRUNC */
```

This example also shows why waivers should be a last resort. With the `WIDTHTRUNC` warning waived, Verilator still reported `Bits of signal are not used: 'a'[7:4]`, because the real situation is that the upper input bits are unused. Writing `assign y = a[3:0];` states the intent without a waiver, but produces the same `UNUSEDSIGNAL` warning: the honest fix is to make the port only 4 bits wide, or, if the interface is fixed, to waive `UNUSEDSIGNAL` with a comment. A warning often points to a design question, not just a syntax issue.

Never use a global switch such as `-Wno-fatal` or `-Wno-WIDTH` to make lint quiet. That hides the next real bug together with the noise.

### Check your understanding: 4.5

1. Why lint the whole hierarchy with `--top-module` instead of each file separately?
2. A colleague's design gives 40 `WIDTHEXPAND` warnings, so they add `-Wno-WIDTH` to the command line. What is the risk?
3. An instance is written `seq_mult u (...)` without connecting `product`, because this test only needs `done`. How do you show that this is intentional?
4. What does `UNOPTFLAT` usually indicate, and why is it a real hardware problem?
5. Why should testbenches not be linted with `-Wall`?

#### Answers

1. Some problems only exist between modules: unconnected or misspelled ports (`PINMISSING`), width mismatches between a port and the signal connected to it, and signals that one module drives and no module reads. Linting files separately cannot see the connections.
2. `-Wno-WIDTH` hides **all** width warnings, including the next real truncation bug, such as the narrow-adder bug from Part 2. Fix each warning by making widths explicit, or waive the genuinely intentional ones locally.
3. Connect the port to nothing explicitly: `.product()`. That documents the intent and removes `PINMISSING`. Under `-Wall`, Verilator still reports a milder style warning, `PINCONNECTEMPTY` (we checked), so either waive that one locally with a comment, or connect the port to a named signal and waive `UNUSEDSIGNAL` on it. The goal is that every remaining open port is visibly deliberate.
4. A combinational loop: logic whose output feeds back to its own input without passing through a register. In hardware it may oscillate or latch up, and timing analysis cannot handle it. It usually comes from a Mealy output feeding back into the same block, or from two `always_comb` blocks that depend on each other.
5. Because testbench code is not hardware: delays, unused variables, truncating `$urandom` into narrow signals and initial blocks are normal there, and the warnings would be noise. The rule is for synthesizable design code.

## 4.6 Synthesis with Yosys

Synthesis turns RTL into a netlist of real hardware cells. Running it on your own designs is the fastest way to check that the hardware is what you meant: how many flip-flops, how many lookup tables, whether a multiplier landed in a DSP block, and whether anything unexpected, such as a latch, appeared.

### What a synthesizer does

1. **Elaborate**: read the RTL, resolve parameters and `generate` loops, and build the module hierarchy.
2. **Translate processes**: turn `always_ff` blocks into flip-flops and `always_comb` blocks into multiplexers and logic. This is where latches are detected.
3. **Optimize**: remove unused logic, share common terms, simplify constants.
4. **Map to a technology**: express the logic with the cells the target really has. For a generic target, that means simple gates; for an FPGA, lookup tables (LUTs), carry chains, flip-flops and DSP blocks.

### Two ways to run Yosys

A **generic** synthesis maps to simple gates such as `$_AND_` and `$_MUX_`. It is quick and target-independent:

```sh
yosys -p "read_verilog -sv mux4_case.sv; synth -top mux4_case; stat"
```

An **FPGA** synthesis maps to the cells of a real device family. Yosys includes flows for several families; this course uses AMD (Xilinx) 7-series, a widely used FPGA family whose cells are well documented:

```sh
yosys -p "read_verilog -sv mux4_case.sv; synth_xilinx -family xc7 -flatten -top mux4_case; stat"
```

`read_verilog -sv` reads SystemVerilog (Yosys supports the synthesizable subset used in this course), `-top` names the top module, `-flatten` merges the hierarchy so `stat` gives one total, and `stat` prints the cell counts. For designs with several files, list them all after `read_verilog -sv`.

The main 7-series cells you will see in reports:

| Cell | What it is |
| --- | --- |
| `LUT1` … `LUT6` | A lookup table with 1 to 6 inputs: any logic function of up to 6 inputs |
| `MUXF7`, `MUXF8` | Dedicated multiplexers that combine LUTs into wider functions |
| `CARRY4` | A fast carry chain for 4 bits of an adder, subtractor or comparator |
| `FDRE`, `FDSE` | A D flip-flop with clock enable and synchronous reset (or set) |
| `DSP48E1` | A hard multiply-accumulate block: a 25 × 18-bit multiplier plus a 48-bit adder |
| `IBUF`, `OBUF`, `BUFG` | Input, output and clock buffers at the chip pins (ignore them when comparing designs) |

### Example 1: three coding styles, one circuit

Part 1 claimed that the `assign`, `if` and `case` versions of the 4-to-1, 8-bit multiplexer produce the same hardware. Synthesis confirms it, with a twist:

| Style | Generic gates | 7-series cells |
| --- | --- | --- |
| `assign` with `?:` | 27 | 8 × `LUT6` |
| `if / else if` | 27 | 8 × `LUT6` |
| `case` | 52 | 8 × `LUT6` |

On the FPGA all three are identical: one 6-input LUT per output bit, because each bit depends on exactly 6 inputs (4 data bits and 2 select bits). The generic gate counts differ, because generic mapping is a rough intermediate step. The lesson: **compare designs on the real target technology**, and do not read too much into generic gate counts.

### Example 2: the accidental latch, caught

The `latch_bad` module from Part 1, section 1.5, stops synthesis immediately:

```text
ERROR: Latch inferred for signal `\latch_bad.\q' from always_comb process ...
```

Because the block is declared `always_comb`, Yosys treats a latch as an error rather than quietly building one. We also tried the same code written with `always @(*)`: Yosys then only printed an informational line, `Latch inferred for signal ...`, and built the latch. That is one more reason to use `always_comb` instead of `always @(*)`.

### Example 3: a multiplier lands in a DSP block

This combinational multiplier registers its inputs and its output:

```systemverilog
`timescale 1ns/1ps
// mult_comb.sv -- combinational multiplier with registered inputs and output
module mult_comb #(parameter int W = 8) (
  input  logic           clk,
  input  logic [W-1:0]   a, b,
  output logic [2*W-1:0] p
);
  logic [W-1:0] a_r, b_r;
  always_ff @(posedge clk) begin
    a_r <= a;
    b_r <= b;
    p   <= a_r * b_r;          // the whole product in one clock cycle
  end
endmodule
```

| Synthesis | Result (excluding I/O buffers) |
| --- | --- |
| `synth_xilinx -family xc7` | 1 × `DSP48E1`, nothing else |
| `synth_xilinx -family xc7 -nodsp` | 113 LUTs, 23 `MUXF7`/`MUXF8`, 4 `CARRY4`, 32 flip-flops |

With DSP blocks allowed, the multiplier **and all three registers** went into a single `DSP48E1`: the block has optional internal registers on its inputs and output, and the tool used them. This is why DSP code registers multiplier inputs and outputs: it matches the hard block and makes the design faster. With `-nodsp`, the same multiplier costs over a hundred LUTs. (Part 6 returns to DSP-block-friendly coding in detail.)

### Check your understanding: 4.6

1. Why does each output bit of the 8-bit 4-to-1 multiplexer need exactly one `LUT6`?
2. How many `LUT6` cells would a 16-bit 4-to-1 multiplexer need? An 8-bit 8-to-1 multiplexer?
3. Why did the generic gate counts differ between the `if` and `case` versions, when the FPGA results were identical?
4. Why did `mult_comb` use no flip-flops outside the DSP block?
5. A design synthesizes with `synth_xilinx` and reports 0 flip-flops, although the RTL has several `always_ff` blocks. What could be going on?

#### Answers

1. Each output bit is a function of 6 inputs: the corresponding bit of `d0` to `d3`, plus the 2 select bits. A `LUT6` implements any function of up to 6 inputs, so one per bit is enough.
2. 16-bit 4-to-1: **16** `LUT6`, one per bit. 8-bit 8-to-1: each bit depends on 8 data bits plus 3 select bits, 11 inputs, which no single LUT can handle, so each bit needs two `LUT6` (one per 4-to-1 half) plus a small cell to pick between them using the third select bit. We ran it: Yosys produced **16 `LUT6` and 8 `LUT3`**. Other tools often use the dedicated `MUXF7` for that last step instead; either way, it is about two LUTs per bit.
3. Generic mapping goes through a gate library with only small cells, and the result depends on how the logic was described before optimization. The FPGA mapper re-optimizes the function into 6-input LUTs, and since the function is the same, the result is the same.
4. The 7-series DSP block contains optional registers on its A and B inputs and on its product output. The tool absorbed `a_r`, `b_r` and `p` into those internal registers, so no fabric flip-flops were needed.
5. The most likely cause is that the outputs do not depend on those registers, for example an output left unconnected or never assigned, so the optimizer removed all the logic as unused. Check `UNUSEDSIGNAL` and `UNDRIVEN` warnings from Verilator, and check the top module's ports.

### Memories: what makes a block RAM

An array of registers in RTL can become three very different things after synthesis: flip-flops, small memories built from LUTs (distributed RAM), or a dedicated block RAM. Which one you get depends on two coding choices, and the difference is enormous. The same 1,024 × 16-bit memory, written four ways and synthesized with `synth_xilinx -family xc7`:

```systemverilog
// (a) every word reset: the reset needs a path to every bit, so this must be flip-flops
always_ff @(posedge clk) begin
  if (rst) for (int i = 0; i < 1024; i++) m[i] <= '0;
  else if (we) m[wa] <= wd;
  rd <= m[ra];
end

// (b) no reset, read data registered: the pattern of a block RAM
always_ff @(posedge clk) begin
  if (we) m[wa] <= wd;
  rd <= m[ra];
end

// (c) no reset, read combinational (asynchronous): only distributed (LUT) RAM can do this
always_ff @(posedge clk) if (we) m[wa] <= wd;
assign rd = m[ra];

// (d) registered read, but with logic between the memory and the register
always_ff @(posedge clk) begin
  if (we) m[wa] <= wd;
  rd <= neg ? -m[ra] : m[ra];
end
```

| Style | What Yosys built | LUTs | Flip-flops |
| --- | --- | --- | --- |
| (a) reset | flip-flops and multiplexers | 6,740 | **16,400** |
| (b) no reset, registered read | **1 RAMB18E1** | **0** | **0** |
| (c) asynchronous read | 96 RAM64M (LUT RAM) | 97 | 0 |
| (d) logic before the read register | 96 RAM64M (LUT RAM) | 161 | 16 |

Three rules follow:

1. **Never reset a memory.** A block RAM has no way to clear all its words at once, so a reset forces every bit into a flip-flop: 16,400 flip-flops instead of one block RAM. If the contents must start at zero, write zeros after reset, one word per cycle, as the circular-buffer FIR of the Part 7 solutions does.
2. **Register the read data directly.** A block RAM's output is a register; reading into a register with nothing in between (style b) lets the tool use it. A combinational read (style c) can only be built from LUTs.
3. **Put no logic between the memory and its read register** (style d). Do the arithmetic one cycle later. The quarter-wave NCO of the Part 9 solutions only mapped onto block RAM after this change, and the FFT of Part 11 (whose memory is read and written four times per cycle, combinationally) is built entirely from flip-flops for the same reasons; its block-RAM version, in the Part 11 solutions, is 16 to 167 times smaller.

A small memory may still become LUT RAM even when written as style (b), because the tool judges a block RAM wasteful for it; the 256-entry quarter-wave table in the Part 9 solutions is an example. Verilator lints style (a) only with `--unroll-count 2048`, because its reset loop has more than 64 iterations (Appendix A: Portable SystemVerilog).

### What synthesis numbers mean

Every resource count in this course (LUTs, flip-flops, DSP blocks, block RAMs) comes from **Yosys** synthesizing for the AMD 7-series (`synth_xilinx -family xc7`). Treat them as estimates for comparing designs with each other, not as the cost on a real device: AMD's own tool, Vivado, optimizes differently, and its counts can differ noticeably in either direction. None of the course's numbers was cross-checked with Vivado. Likewise, synthesis says nothing about speed: a throughput "at 100 MHz" assumes the design meets a 100 MHz clock, which only place and route can confirm (Part 13, where the Part 12 DDC first reached only 44 MHz).

## 4.7 Reading the hardware: area, throughput and logic depth

Three numbers describe a DSP block's cost and speed: its **area** (cells used), its **throughput** (results per clock cycle), and its **logic depth** (how much logic lies on the longest path between registers, which limits the clock frequency). Yosys gives you the first and third; the second you read from the design.

### Measuring logic depth

The Yosys command `ltp -noff` reports the **longest topological path**: the largest number of logic cells on any path between flip-flops or ports, after generic synthesis.

```sh
yosys -p "read_verilog -sv moving_sum4.sv; synth -flatten -top moving_sum4; ltp -noff"
```

It prints a line such as `Longest topological path in moving_sum4 (length=19)`. This is a **proxy** for delay, not a timing report: real delay depends on the target's cells and routing. Exact timing needs place-and-route, done by vendor tools such as AMD Vivado (which has a free edition) or by the open-source nextpnr. For comparing two versions of a design, though, path length is an excellent first guide.

### Area versus throughput: two multipliers

All numbers below come from Yosys 0.33, `synth_xilinx -family xc7 -flatten`, with W = 8 and I/O buffers excluded:

| Design | Products per cycle | Latency | 7-series cells | Longest path |
| --- | --- | --- | --- | --- |
| `seq_mult` (Part 3) | 1/9 | 9 cycles | 34 LUTs, 4 `CARRY4`, 29 flip-flops | 11 |
| `mult_comb`, DSP blocks off | 1 | 2 cycles | 113 LUTs, 23 `MUXF7`/`MUXF8`, 4 `CARRY4`, 32 flip-flops | 24 |
| `mult_comb`, DSP blocks on | 1 | 2 cycles | 1 `DSP48E1` | n/a |

The sequential multiplier uses about a third of the LUTs, and its logic path is less than half as long, but it produces a product only every 9 cycles. The parallel multiplier is 9 times faster in throughput, at about 3 times the logic. On an FPGA with DSP blocks, the parallel version is almost free. That is why FPGA DSP designs use the hard multipliers whenever they can, and reserve shift-and-add style designs for cases where DSP blocks run out.

### Pipelining: one register, a shorter path

In `moving_sum4`, all four samples are added in a single clock cycle. Splitting the addition into two stages, with registers in between, shortens the longest path:

```systemverilog
`timescale 1ns/1ps
// moving_sum4_pipe.sv -- same function as moving_sum4, with the adder split
// into two pipeline stages: latency 2 cycles instead of 1.
module moving_sum4_pipe #(
  parameter int W = 16
) (
  input  logic                clk,
  input  logic                rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W+1:0] y
);
  logic signed [W-1:0] d1, d2, d3;              // delay line, as before
  logic signed [W:0]   s01, s23;                // stage-1 partial sums: W+1 bits
  logic                v1;                      // stage-1 valid

  always_ff @(posedge clk) begin
    if (rst) begin
      d1 <= '0;  d2 <= '0;  d3 <= '0;
      s01 <= '0; s23 <= '0; v1 <= 1'b0;
      y  <= '0;  out_valid <= 1'b0;
    end else begin
      // stage 1: shift the delay line and form two partial sums
      v1 <= in_valid;
      if (in_valid) begin
        d1 <= x;  d2 <= d1;  d3 <= d2;
        s01 <= (W+1)'(x)  + (W+1)'(d1);
        s23 <= (W+1)'(d2) + (W+1)'(d3);
      end
      // stage 2: add the partial sums
      out_valid <= v1;
      if (v1) y <= (W+2)'(s01) + (W+2)'(s23);
    end
  end
endmodule
```

Each partial sum of two 16-bit values needs 17 bits; their sum needs 18. The **valid bit travels through the pipeline alongside the data** (`in_valid` → `v1` → `out_valid`), so each stage knows whether the value it holds is real. This pattern appears in every pipelined DSP design from now on.

| Design | Latency | 7-series cells | Longest path |
| --- | --- | --- | --- |
| `moving_sum4` | 1 cycle | 49 LUTs, 14 `MUXF7`, 5 `CARRY4`, 67 flip-flops | 19 |
| `moving_sum4_pipe` | 2 cycles | 49 `LUT2`, 15 `CARRY4`, 102 flip-flops | 14 |

The pipelined version has a 26% shorter longest path, at the cost of 35 more flip-flops (the two 17-bit partial sums and `v1`) and one more cycle of latency. Its throughput is unchanged: still one result per input sample.

There is a surprise in the LUT column. The pipelined version uses only simple 2-input LUTs, each paired with a carry chain: a two-operand adder is exactly what `CARRY4` is built for. The four-operand adder of the original was mapped by Yosys with larger LUTs and multiplexers. Different tools handle multi-operand adders differently, so measure rather than guess, and prefer adders with two operands per stage in timing-critical paths.

### Re-verifying the pipelined design

The testbench of section 4.3 needed only two changes. The module name is chosen at compile time with a macro, and the protocol check takes the latency as a plusarg:

```systemverilog
`ifndef DUT
  `define DUT moving_sum4
`endif
...
  `DUT #(.W(W)) dut (.*);                    // module name chosen at compile time
...
  // ---- protocol check: out_valid must follow in_valid by exactly LAT cycles ----
  int lat = 1;                               // the design's latency; override with +LAT=...
  logic [7:0] in_valid_hist = '0;            // in_valid_hist[k] = in_valid k+1 cycles ago
  initial void'($value$plusargs("LAT=%d", lat));
  always @(posedge clk) in_valid_hist <= {in_valid_hist[6:0], in_valid && !rst};
  always @(negedge clk) begin
    if (!rst)
      assert (out_valid === in_valid_hist[lat-1])
        else begin $error("out_valid=%b but in_valid %0d cycles earlier was %b",
                          out_valid, lat, in_valid_hist[lat-1]); errors++; end
  end
```

`` `define `` creates a text macro and `` `ifndef `` gives it a default; `-DDUT=moving_sum4_pipe` on the Icarus command line overrides it:

```sh
iverilog -g2012 -Wall -o simp moving_sum4_pipe.sv tb_pipe.sv -DDUT=moving_sum4_pipe
vvp -n simp +N=3000 +SEED=4 +LAT=2
```

With `+LAT=2`, the run printed `PASS: 3000 samples match the Python model`, and `check_results.py` confirmed it bit-exact. The data monitor needed no change, because it never depended on latency. With the wrong setting, `+LAT=1`, the protocol assertion failed immediately: `out_valid=0 but in_valid 1 cycles earlier was 1`. The same testbench still passes the original design with the default latency.

### Check your understanding: 4.7

1. A filter must process 100 million samples per second on a 100 MHz clock. Could it use `seq_mult` for its multiplications? What about at 10 million samples per second, with one multiplication per sample?
2. Why does the pipelined moving sum need 35 more flip-flops? Account for every one.
3. Pipelining shortened the path from 19 to 14 cells, not to roughly half. Why not?
4. Why must the valid bit be delayed through the pipeline together with the data?
5. Is a shorter `ltp` length a guarantee of a higher maximum clock frequency on the FPGA?

#### Answers

1. At 100 MHz with one sample per clock: **no**, `seq_mult` needs 9 cycles per product. At 10 million samples per second there are 10 clock cycles per sample, so **one** `seq_mult` fits (9 cycles per product), with one cycle to spare.
2. `s01` and `s23` are 17 bits each (34 flip-flops), plus `v1` (1): **35**. The delay line, `y` and `out_valid` exist in both versions.
3. The delay is not shared equally between the stages. Stage 2 still contains an 18-bit adder with its full carry path, and stage 1 contains a 17-bit adder; carries ripple through the whole width in each. Pipelining removed one adder's worth of logic from the critical path, not half the total. (Further gains need splitting the adders themselves, or using the carry chains' speed, which FPGA tools handle.)
4. Because each stage must know whether the value it holds corresponds to a real sample. Without the delayed valid, the output stage would load `y` when `in_valid` was high, one cycle too early, and pair partial sums with the wrong valid flag. The protocol assertion checks exactly this.
5. **No.** `ltp` counts generic cells, all with equal weight, before FPGA mapping and routing. Real delay depends on the mapped cells (carry chains are much faster per bit than LUTs) and on wiring. It is a good guide for comparing versions of a design; only place-and-route timing analysis gives the actual maximum frequency.

## 4.8 Exercises

These exercises apply the flow to designs you have already built, so the focus is on the workflow, not on new RTL. For scale: their worked solutions add 4 design files, 5 testbenches and 8 Python scripts, about 680 new lines (not counting short checks run inline). Time depends too much on experience for a reliable estimate, so none is given. Send me your scripts, results tables and any bugs the flow found.

- [ ] Exercise 1: saturating adder, verified from Python
- [ ] Exercise 2: the sequential multiplier, file-driven
- [ ] Exercise 3: moving average of 8, with a plot
- [ ] Exercise 4: a lint-and-synthesis report for Parts 1 to 3
- [ ] Exercise 5: an adder tree, pipelined

### Exercise 1: the saturating adder, verified from Python

Take `sat_add` from Part 1, Exercise 4 (W = 8).

- Write `gen_vectors.py` for it. The golden model is one line: `np.clip(a + b, -128, 127)` computed in `int64`.
- An 8-bit adder has only 65,536 input pairs, so test them **all**: generate every pair with `np.meshgrid` or two nested loops. This is exhaustive verification, the strongest result simulation can give.
- The design is combinational, so the testbench does not need `in_valid`: apply each pair, wait 1 ns, write the result. Reuse `check_results.py` with a new model.
- Then break the design in two different ways (wrap instead of saturate; saturate at the wrong value) and record what the checker reports.

### Exercise 2: the sequential multiplier, file-driven

Verify `seq_mult` from Part 3 (W = 8) with the full flow.

- Python generates operand pairs (including 0, 1 and 255 in every combination) and their products, with a `--seed` option.
- The testbench issues each `start`, waits for `done`, writes the product, and uses an assertion to check that `done` arrives exactly 9 cycles after `start`.
- Run a 10-seed regression with 2,000 products per seed.
- Then test `mult_stream` from section 3.6 of Part 3 with the same Python vectors: the source holds `in_valid` until accepted, so the file order is preserved.

### Exercise 3: moving average of 8, with a plot

Run your `moving_avg8` from Part 2, Exercise 5, through the flow.

- The model: `np.convolve(x, np.ones(8, dtype=np.int64))[:len(x)] >> 3`. In NumPy, `>>` on signed integers is an **arithmetic** shift, so it rounds the same way as the hardware's `>>>`. Check that claim yourself on a few negative numbers.
- Use a test signal that shows what the filter does: a slow sine wave plus random noise, scaled to stay within ±32,000. Generate it with `np.sin` and `rng.normal`, then convert to integers with `np.round(...).astype(np.int64)`.
- Plot the input and the RTL output with Matplotlib (`pip install matplotlib`). The output should be visibly smoother and slightly delayed. Save the plot as a PNG and send it with your results. Part 5 explains exactly why the noise is reduced and by how much.

### Exercise 4: a lint-and-synthesis report for Parts 1 to 3

For every design module you wrote in Parts 1 to 3 (not testbenches):

- Lint it with `verilator --lint-only -Wall`, with the whole hierarchy for multi-module designs. Fix every warning or waive it locally with a comment.
- Synthesize it with `synth_xilinx -family xc7 -flatten` and record LUTs, `CARRY4`, flip-flops and DSP blocks, plus `ltp -noff` from a generic synthesis.
- Put the results in a table and write one sentence per design on whether the numbers match what you expected from the RTL. Explain at least one surprise.
- Write a shell script `synth_report.sh` that produces the table automatically, so you can rerun it after every change.

### Exercise 5: an adder tree, pipelined

Build `moving_sum8` (the sum of the last 8 samples, W = 16) in three versions:

1. A single-cycle sum of all 8 values.
2. A balanced **adder tree**: 4 adders, then 2, then 1, still in a single cycle.
3. The same tree with a pipeline register after each level: latency 3 cycles.

Verify all three with the same Python flow (the `DUT` macro and `+LAT` plusarg from section 4.7), then compare area and `ltp` length in a table. Which version is best, and for what purpose? What happens to the widths at each level of the tree?

## 4.9 Summary and what comes next

You now have a complete workflow: a Python golden model, a file-driven testbench with assertions, a seeded regression, lint, and synthesis reports. Every DSP block in the rest of the course goes through it.

| Task | Command or construct | Remember |
| --- | --- | --- |
| Load a vector file | `$readmemh("x.hex", mem, 0, n-1);` | Two's complement at the exact width, no minus sign |
| Write results | `fd = $fopen("y.hex", "w"); $fdisplay(fd, "%h", y);` | Check `fd != 0`; `$fclose` before `$finish` |
| Command-line options | `void'($value$plusargs("N=%d", n));` | Run as `vvp sim +N=5000` |
| Fail a script | `$fatal(1, "msg");` | `$display` and `$error` leave exit code 0 |
| Immediate assertion | `assert (cond) else $error(...);` | Concurrent SVA not supported by Icarus 12 |
| No unknowns | `assert (!$isunknown(y))` | On every valid output |
| Reproducible runs | Same `SEED` to NumPy and `$urandom(seed)` | One number reproduces everything |
| Choose the DUT | ``  `ifndef DUT `define DUT name `endif `` + `-DDUT=...` | One testbench, several designs |
| Lint a hierarchy | `verilator --lint-only -Wall --top-module top *.sv` | Waive locally with a reason |
| Resource report | `yosys -p "read_verilog -sv f.sv; synth_xilinx -family xc7 -flatten -top m; stat"` | Compare on the real target |
| Logic depth | `yosys -p "...; synth -flatten -top m; ltp -noff"` | A proxy; real timing needs place-and-route |

The ideas that matter most from this part:

1. The golden model is written in Python and is **bit-exact**: equality is the test.
2. Testbenches separate stimulus from monitoring, so they survive changes in latency.
3. Assertions report the cause of a bug where it happens; regressions with many seeds find the rare cases.
4. Synthesis shows what you really built. Multipliers belong in DSP blocks, two-operand adders map well to carry chains, and pipeline registers shorten the critical path at the cost of latency and flip-flops.

**Part 5: DSP from scratch I** begins the signal-processing half of the course. Using NumPy, you will learn what a discrete-time signal is, why sampling works and how aliasing breaks it, what convolution does (the operation inside `np.convolve` that you used here), and what a frequency response is. You will analyze the moving-average filter you built in Part 2, see exactly which frequencies it removes, and understand the plot from Exercise 3.

### Further reading: the limits of bit-exact checking

A bit-exact match proves that the RTL computes what the model computes, not that the model computes what the specification asks for. [Appendix B: Measuring and Cross-Checking](https://claude.ai/artifact/5UJq2UPxPsecQq5o4hY4SX) shows a mistake made in both the model and the RTL that passes every bit-exact test, the checks that catch it, and a standard measurement library (`measure.py`) for the spectra and accuracy figures used from Part 5 onward.
