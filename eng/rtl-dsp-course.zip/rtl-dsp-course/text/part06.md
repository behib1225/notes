# Verilog & RTL for DSP — Part 6: Fixed-Point Arithmetic and Multipliers

*Markdown export of the online document: https://claude.ai/artifact/Kf8LBgUrUAxWA8XXHXmN3r. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 6 fits

Part 5 described filters with real numbers: coefficients like 0.25 and signals like cos(2πfn). Hardware has only integers. Part 6 is the bridge: **fixed-point arithmetic** represents fractions as scaled integers, and this part teaches you to choose the scaling, the word widths, and the rounding so that the hardware's error is small, known in advance, and reproduced bit-exactly by a Python model.

By the end you will have three reusable pieces for the rest of the course:

1. A set of Python helpers for converting to and from fixed point, with the same rounding as the hardware.
2. A parameterized **round-and-saturate** module, `requant.sv`, verified exhaustively against Python.
3. A pipelined **multiply-accumulate (MAC)** unit that maps onto a single FPGA DSP block, verified bit-exactly, with its error measured against a floating-point model.

You will also answer the question left open in Part 5, Exercise 6: why the `>>> 3` in your moving average is slightly wrong, and by exactly how much.

As in every part, all code was run: Python 3 with NumPy, Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33. Each section ends with "Check your understanding" questions and answers, and section 6.7 has the exercises.

## 6.1 Fixed-point numbers and Q format

A fixed-point number is an ordinary two's-complement integer with an **imagined binary point**. A W-bit word with F fractional bits holds the integer q and represents the real value q / 2^F. The hardware only ever sees q; the scaling exists in your head, in your comments, and in the Python model.

### The definition

```latex
\text{value} = \frac{q}{2^F}, \qquad q \in \left[-2^{W-1},\; 2^{W-1}-1\right]
```

Two properties follow:

- The **resolution**, the value of one LSB, is 2^−F.
- The **range** is −2^(W−1−F) up to 2^(W−1−F) − 2^−F.

More fractional bits give finer resolution; more integer bits give a wider range. For a fixed W, you trade one against the other.

### Q-format notation

Fixed-point formats are usually written **Qm.n**: m integer bits and n fractional bits. Unfortunately two conventions exist: some authors (including ARM) count the sign bit in m, so Q1.15 is 16 bits; others (including TI's documentation) do not, so the same format is called Q0.15 or simply Q15. **In this course, m includes the sign bit**, so W = m + n, and whenever there is any doubt the text also states W and F explicitly.

| Format | W | F | Range | Resolution (LSB) | Typical use |
| --- | --- | --- | --- | --- | --- |
| Q1.15 | 16 | 15 | −1 to 0.99997 | 3.05 × 10⁻⁵ | Audio samples, filter coefficients |
| Q1.7 | 8 | 7 | −1 to 0.992 | 0.0078 | Low-resolution data |
| Q4.4 | 8 | 4 | −8 to 7.9375 | 0.0625 | Small values with an integer part |
| Q2.30 | 32 | 30 | −2 to 1.99999999907 | 9.3 × 10⁻¹⁰ | The product of two Q1.15 numbers |
| Q16.0 | 16 | 0 | −32,768 to 32,767 | 1 | Plain integers: a special case |

The moving sum of Parts 2 to 5 used plain integers, Q16.0 in and Q18.0 out. Nothing about the hardware changes when you decide that the same 16 bits mean Q1.15 instead: the adder is identical. Only the interpretation changes.

### Converting in Python

The helper module below is used in the rest of the course. `quantize` turns real values into integers with a chosen rounding and overflow behavior; `to_real` goes back; `requant` changes the format of integers that are already fixed-point, exactly as the hardware module of section 6.4 does.

```python
"""fixedpoint.py -- bit-exact fixed-point helpers that match the hardware.

A signed fixed-point number has W bits in total, F of them fractional.
The stored integer q represents the real value q / 2**F.
"""
import numpy as np

def quantize(x, W, F, rnd="round", ovf="saturate"):
    """Real value(s) -> W-bit integer(s) with F fractional bits."""
    v = np.asarray(x, dtype=np.float64) * 2.0**F
    if rnd == "floor":                  # truncation: drop the bits below the LSB
        q = np.floor(v)
    elif rnd == "round":                # round half up: add 1/2 LSB, then floor
        q = np.floor(v + 0.5)
    elif rnd == "convergent":           # round half to even (NumPy's np.round)
        q = np.round(v)
    else:
        raise ValueError(rnd)
    return handle_overflow(q.astype(np.int64), W, ovf)

def handle_overflow(q, W, ovf="saturate"):
    lo, hi = -(1 << (W - 1)), (1 << (W - 1)) - 1
    q = np.asarray(q, dtype=np.int64)
    if ovf == "saturate":
        return np.clip(q, lo, hi)
    if ovf == "wrap":
        return ((q - lo) % (1 << W)) + lo
    raise ValueError(ovf)

def to_real(q, F):
    """Integer(s) with F fractional bits -> real value(s)."""
    return np.asarray(q, dtype=np.float64) / 2.0**F

def requant(q, F_in, W_out, F_out, rnd="round", ovf="saturate"):
    """Integer -> integer: drop (F_in - F_out) fractional bits, then fit W_out bits.
    Exactly what requant.sv does, using only integer operations."""
    q = np.asarray(q, dtype=np.int64)
    s = F_in - F_out
    assert s >= 1
    if rnd == "floor":
        r = q >> s                                   # arithmetic shift = floor
    elif rnd == "round":
        r = (q + (1 << (s - 1))) >> s                # add half an output LSB, then floor
    elif rnd == "convergent":
        r = q >> s
        rem = q - (r << s)                           # the dropped bits, 0 .. 2**s - 1
        half = 1 << (s - 1)
        r = r + ((rem > half) | ((rem == half) & (r & 1 == 1)))
    else:
        raise ValueError(rnd)
    return handle_overflow(r, W_out, ovf)
```

Converting some values to Q1.15 (W = 16, F = 15) with rounding and saturation:

```python
x = np.array([0.1, -0.1, 0.5, -0.5, 0.999, -1.0, 1.0, 0.3333])
q = quantize(x, 16, 15)
print(q)
print(to_real(q, 15))
```

```text
[  3277  -3277  16384 -16384  32735 -32768  32767  10922]
[ 0.1000061  -0.1000061   0.5        -0.5         0.99899292 -1.
  0.99996948  0.33331299]
```

Three things to notice. **0.1 is not exact**: 0.1 × 32,768 = 3,276.8 rounds to 3,277, which is 0.1000061, an error of 6.1 × 10⁻⁶, less than half an LSB. **−1.0 is exact**, but **+1.0 is not representable** in Q1.15: it saturated to 32,767, which is 0.99997. And the error of every value is at most half an LSB (1.5 × 10⁻⁵), which is the promise of rounding.

### Check your understanding: 6.1

1. What are the range and resolution of Q3.13 (W = 16)?
2. Write 0.75, −0.75 and −0.375 as Q1.7 integers, and give their 8-bit hex patterns.
3. In Q4.4, which real value does the integer 50 represent? What is the closest Q4.4 value to π?
4. A Q1.15 coefficient is stored as 0x6000. What real value is it?
5. Why can Q1.15 represent −1 exactly but not +1?

#### Answers

1. Range −2^(16−1−13) = **−4** to 4 − 2⁻¹³ ≈ **3.99988**. Resolution 2⁻¹³ ≈ **1.22 × 10⁻⁴**.
2. 0.75 × 128 = **96** = `0x60`. −0.75 → **−96** = 256 − 96 = 160 = `0xA0`. −0.375 → **−48** = 208 = `0xD0`.
3. 50 / 16 = **3.125**. π × 16 = 50.27, which rounds to 50, so **3.125** is the closest (the next value, 3.1875, is further away).
4. 0x6000 = 24,576; 24,576 / 32,768 = **0.75**.
5. Two's complement is asymmetric: 16 bits hold −32,768 to +32,767. With F = 15, −32,768 is exactly −1.0, but +1.0 would need +32,768, one more than the largest value. That asymmetry causes the −1 × −1 problem of section 6.3.

## 6.2 Quantization: truncation, rounding and their noise

Every time a value is squeezed into fewer bits, an error appears. With **rounding**, the error is at most half an LSB and averages zero. With **truncation**, it is up to a whole LSB and is always negative, which adds a bias. Both errors behave like a small random noise whose size you can predict exactly.

### Three ways to drop bits

Applied to integers (F = 0) to make the differences visible:

| Input | Floor (truncate) | Round half up | Convergent (round half to even) |
| --- | --- | --- | --- |
| 0.4 | 0 | 0 | 0 |
| 0.5 | 0 | 1 | 0 |
| 0.6 | 0 | 1 | 1 |
| 1.5 | 1 | 2 | 2 |
| 2.5 | 2 | 3 | 2 |
| −0.4 | −1 | 0 | 0 |
| −0.5 | −1 | 0 | 0 |
| −1.5 | −2 | −1 | −2 |
| −2.5 | −3 | −2 | −2 |

These are the outputs of `quantize(..., rnd=...)` with W = 8, F = 0.

- **Floor** (truncation) always moves down, toward −∞. In hardware it is free: drop the low bits, which is what an arithmetic shift `>>>` does. Its average error is −½ LSB.
- **Round half up** adds half an LSB and then floors. It costs one adder. Its error lies in \[−½, +½) LSB. Exact halves always go up, which leaves a tiny positive bias, but only when the dropped bits are exactly 100…0.
- **Convergent rounding** (round half to even, also called banker's rounding) sends exact halves to the even neighbor, so they go up half the time and down half the time: no bias at all. It costs a little more logic. NumPy's `np.round` uses it.

### Quantization noise

When the signal is busy (not a constant, not a tiny value), the rounding error behaves like random noise, uniformly spread over one LSB. A uniform error over an interval of width Δ has variance Δ²/12. We measured it on a 12-bit quantized sine:

```text
rounding:   error variance = 0.0823 LSB²   (theory 1/12 = 0.0833)
truncation: error variance = 0.0847 LSB²,  mean error = -0.506 LSB
```

Truncation has the same spread, plus a constant offset of −½ LSB. That offset adds power ¼ LSB², so truncation's total error power is ¼ + 1/12 = ⅓ LSB², four times rounding's: **6 dB worse**.

### Signal-to-quantization-noise ratio

For a full-scale sine wave quantized to W bits (Q1.(W−1), with rounding), the signal power is ½ and the noise power is LSB²/12 with LSB = 2^−(W−1). The ratio is a famous formula:

```latex
\text{SQNR} \approx 6.02\,W + 1.76 \ \text{dB}
```

That is the "6 dB per bit" rule from Part 5, made exact. The chart compares it with SQNR measured on 100,000 samples of a sine of amplitude 0.999:

> **Figure:** measured with fixedpoint.quantize on a sine at 0.0123 cycles/sample; dashed line: 6.02W + 1.76 dB (shown in the [online version](https://claude.ai/artifact/Kf8LBgUrUAxWA8XXHXmN3r))

Rounding follows the formula to within about 0.1 dB from 10 bits up (at 4 bits the error is no longer noise-like, and the 0.999 amplitude falls just short of full scale). Truncation is consistently about 6 dB, one bit, worse. In hardware terms: **rounding buys you one extra bit of accuracy for the price of one adder.**

### The answer to Part 5, Exercise 6

Your `moving_avg8` computed the 19-bit sum and then shifted right by 3 with `>>>`, which is truncation. Its outputs are, on average, about **0.44 LSB too low**: for random inputs, the 3 dropped bits take the 8 values 0 to 7 equally often, so the average error is −(0 + 1 + … + 7)/8 / 8 = −7/16 LSB. For example, if seven of the last eight samples are 1 and one is 0, the true average 7/8 = 0.875 truncates to 0, while rounding gives the nearest value, 1. The fix is to round: add 4 (half of 8) before shifting, `(sum + 4) >>> 3`, and handle the carry that may now overflow (section 6.4).

### Check your understanding: 6.2

1. Quantize −2.5, −0.5, 0.5 and 3.5 to integers with floor, round half up, and convergent rounding.
2. What SQNR does a full-scale sine reach with 14-bit rounding? With 14-bit truncation?
3. An application needs an SQNR of at least 80 dB. How many bits are needed with rounding?
4. Why is truncation's error power four times rounding's?
5. A filter's output is the sum of 64 products, each truncated separately. The truncation errors all have mean −½ LSB. What happens to the mean error of the output?

#### Answers

1. Floor: **−3, −1, 0, 3**. Round half up: **−2, 0, 1, 4**. Convergent: **−2, 0, 0, 4** (each exact half goes to the even neighbor: −2, 0, 0, 4).
2. Rounding: 6.02 × 14 + 1.76 = **86.0 dB** (measured: 86.06). Truncation: about 6 dB less, **≈ 80 dB** (measured: 79.97).
3. 6.02 W + 1.76 ≥ 80 → W ≥ 13.0, so **13 bits** with rounding gives 80.02 dB, just enough; use 14 for a margin. With truncation you would need about one bit more.
4. Both errors have the same spread (variance LSB²/12), but truncation also has a mean of −½ LSB, whose power is (½)² = ¼ LSB². Total ⅓ LSB² versus 1/12 LSB²: a factor of 4, which is 6 dB.
5. The means add: **−32 LSB** of the product format, a large DC offset. Random parts grow more slowly (their variances add, so the standard deviation grows by √64 = 8). This is why designs keep products at **full precision**, sum them, and round **once** at the end.

## 6.3 Fixed-point arithmetic

Two rules cover almost everything. **Addition** needs the binary points aligned and grows the result by one bit. **Multiplication** needs no alignment, and the result's widths are the sums of the operands' widths: W\_p = W\_a + W\_b and F\_p = F\_a + F\_b. Keep full precision through the arithmetic and round once at the end.

### Addition and subtraction

To add two fixed-point numbers, their binary points must line up: they need the **same F**. To add a Q4.4 value to a Q1.15 value, first shift the Q4.4 integer left by 11 bits so that it also has 15 fractional bits. Shifting left by k multiplies the integer by 2^k and adds k bits to F, without changing the real value.

The sum of two W-bit numbers needs **W + 1 bits** (one extra integer bit) to be safe, exactly as in Part 1; the sum of N numbers needs ⌈log₂ N⌉ extra bits (Part 2). The fractional part does not grow.

### Multiplication

Multiplying the integers multiplies the scale factors too: (q\_a / 2^F\_a) × (q\_b / 2^F\_b) = (q\_a q\_b) / 2^(F\_a + F\_b). So:

- the product's fractional bits are **F\_a + F\_b**, and
- its total width is **W\_a + W\_b**.

| Operands | Product format | Product width |
| --- | --- | --- |
| Q1.15 × Q1.15 | Q2.30 | 32 bits |
| Q1.15 × Q1.17 (a coefficient with 18 bits) | Q2.32 | 34 bits |
| Q16.0 × Q1.15 (an integer sample times a coefficient) | Q17.15 | 32 bits |
| Q4.4 × Q4.4 | Q8.8 | 16 bits |

In SystemVerilog, a signed multiplication is simply `*` with **both** operands signed and a result variable wide enough. Here is a demonstration in Icarus, with Q1.15 operands and a Q2.30 product:

```systemverilog
module mul_demo;
  logic signed [15:0] a, b;        // Q1.15
  logic signed [31:0] p;           // Q2.30: full-precision product
  logic        [15:0] bu;          // the same bits, but declared unsigned
  logic signed [31:0] p_bad;
  logic signed [15:0] p_q15;       // product squeezed back into Q1.15
  initial begin
    a = 16'sh4000; b = 16'sh6000;            // 0.5 and 0.75
    p = a * b;
    $display("0.5 * 0.75: p = %h = %0d -> %f", p, p, $itor(p) / 2.0**30);
    a = 16'sh8000; b = 16'sh8000;            // -1 and -1
    p = a * b;
    $display("-1 * -1   : p = %h -> %f  (needs bit 30: Q2.30 has room)", p, $itor(p) / 2.0**30);
    p_q15 = p[30:15];                         // naive: keep Q1.15 bits
    $display("-1 * -1 kept as Q1.15 bits [30:15] = %h -> %f  (WRONG: +1 does not fit)", p_q15, $itor(p_q15) / 2.0**15);
    a = 16'shC000; bu = 16'h4000;            // -0.5 times +0.5, but b declared unsigned
    p_bad = a * bu;
    $display("-0.5 * 0.5 with an unsigned operand: %f (WRONG)", $itor(p_bad) / 2.0**30);
    p_bad = a * $signed(bu);
    $display("-0.5 * 0.5 with $signed           : %f", $itor(p_bad) / 2.0**30);
  end
endmodule
```

```text
0.5 * 0.75: p = 18000000 = 402653184 -> 0.375000
-1 * -1   : p = 40000000 -> 1.000000  (needs bit 30: Q2.30 has room)
-1 * -1 kept as Q1.15 bits [30:15] = 8000 -> -1.000000  (WRONG: +1 does not fit)
-0.5 * 0.5 with an unsigned operand: 0.750000 (WRONG)
-0.5 * 0.5 with $signed           : -0.250000
```

(`$itor` converts an integer to a real number for printing; `16'sh8000` is a **signed** hex literal.)

Three lessons:

1. **0.5 × 0.75 = 0.375** comes out exactly: the integer product 402,653,184 divided by 2³⁰.
2. **The −1 × −1 trap.** The result +1.0 needs the second integer bit of Q2.30 (bit 30 set: `0x40000000`). If you throw that bit away to get back to Q1.15, +1 becomes −1, the worst possible error. It is the **only** pair of Q1.15 inputs whose product needs that bit, so designers either keep it, saturate it, or guarantee that −1 never appears (for example by never using −1.0 as a coefficient).
3. **The signed/unsigned trap again**, from Part 1: with one operand unsigned, −0.5 is zero-extended to the large positive number 49,152, and −0.5 × 0.5 came out as +0.75. Every operand of a signed multiplication must be signed.

### Keep full precision, round once

In a filter, products are added together. Rounding each product separately adds one rounding error per tap (section 6.2, question 5). Instead, keep each product at full width, add them in an **accumulator** wide enough for the growth, and round **once** at the output. The hardware cost of a few extra accumulator bits is tiny, and FPGA DSP blocks have a 48-bit accumulator built in for exactly this reason.

### Check your understanding: 6.3

1. What format and width does the product of a Q1.15 sample and a Q3.13 coefficient have?
2. You add a Q1.15 value to a Q2.14 value. How do you align them, and what format can hold the sum safely?
3. 64 Q2.30 products are summed. How many bits does the accumulator need?
4. Why is −1 × −1 the only Q1.15 product that overflows Q1.31?
5. Write the SystemVerilog declaration and assignment for the product of `logic signed [17:0] c` (Q1.17) and `logic signed [24:0] x` (Q1.24).

#### Answers

1. W = 16 + 16 = 32, F = 15 + 13 = 28: **Q4.28**, 32 bits.
2. Shift the Q2.14 integer left by 1 to give it 15 fractional bits; it is now 17 bits, Q2.15. The sum of a Q1.15 and a Q2.15 value can reach about ±3, so it needs **Q3.15** (18 bits).
3. 32 + ⌈log₂ 64⌉ = 32 + 6 = **38 bits** (Q8.30). A 48-bit DSP accumulator has plenty of room.
4. Q1.31 covers \[−1, +1). Every product of two Q1.15 values lies in (−1, +1\], and it reaches +1 only when both inputs are −1 (any other pair has at least one magnitude below 1, so the product's magnitude is below 1). So +1 is the only result outside the range.
5. `logic signed [42:0] p;` and `assign p = c * x;` (18 + 25 = 43 bits; Q2.41). 25 × 18 is exactly the size of a 7-series DSP48E1 multiplier, a combination you will use in section 6.5.

## 6.4 Reducing precision in hardware

Every datapath ends by squeezing a wide result into a narrower output: drop fractional bits with the chosen rounding, then make the value fit by saturating or wrapping. This section builds one parameterized module that does both, `requant.sv`, and verifies it against the Python `requant()` for **every possible input**.

### The two halves of the job

**The LSB side: rounding.** Dropping S fractional bits is an arithmetic shift right by S, which is floor. Rounding needs one more step: look at the dropped bits, `rem`, and decide whether to add 1.

| Mode | Add 1 when | Hardware cost |
| --- | --- | --- |
| Floor (truncate) | Never | Wires only |
| Round half up | `rem` ≥ 100…0 (half an output LSB or more) | One comparator (really just the top dropped bit) and one adder |
| Convergent | `rem` > 100…0, or `rem` = 100…0 and the result is odd | A little more logic, same adder |

Adding 1 can carry into a new top bit (for example, 0.1111 rounds up to 1.0000), so the rounded value needs **one extra bit** before the range check.

**The MSB side: range.** After rounding, the value may not fit in OUT\_W bits. **Wrapping** keeps the low bits, which is free but turns large positive values into negative ones (the click from Part 1). **Saturating** clamps to the largest or smallest value, which costs two comparators and a multiplexer. For signal outputs, saturate.

### The module

```systemverilog
`timescale 1ns/1ps
// requant.sv -- change a signed fixed-point value from (IN_W, IN_F) to (OUT_W, OUT_F):
// drop S = IN_F - OUT_F fractional bits with the chosen rounding, then fit OUT_W bits.
// Purely combinational; register its output in the surrounding design.
module requant #(
  parameter int IN_W  = 32,
  parameter int IN_F  = 30,
  parameter int OUT_W = 16,
  parameter int OUT_F = 15,
  parameter int RND   = 1,      // 0 = floor (truncate), 1 = round half up, 2 = convergent
  parameter bit SAT   = 1'b1    // 1 = saturate, 0 = wrap
) (
  input  logic signed [IN_W-1:0]  din,
  output logic signed [OUT_W-1:0] dout,
  output logic                    ovf     // 1 when the value did not fit (before saturation)
);
  localparam int S  = IN_F - OUT_F;            // fractional bits to drop, must be >= 1
  localparam int RW = IN_W + 1 - S;            // width after rounding: one extra bit for the carry
  localparam int CW = (RW > OUT_W) ? RW : OUT_W;   // width for the range comparisons

  logic signed [IN_W:0]   din_x;               // din with one extra (sign) bit
  logic signed [RW-1:0]   floor_v;             // floor(din / 2**S)
  logic        [S-1:0]    rem;                 // the dropped bits
  logic                   round_up;            // add 1 to floor_v?
  logic signed [RW-1:0]   rounded;
  logic signed [CW-1:0]   rounded_c, max_v, min_v;
  localparam logic [S-1:0] HALF = S'(1) << (S - 1);   // 100...0: exactly half an output LSB

  assign din_x   = (IN_W + 1)'(din);           // sign-extend by one bit
  assign floor_v = RW'(din_x >>> S);           // arithmetic shift = floor
  assign rem     = din[S-1:0];

  // Should we add 1 to the floored value?
  logic up_half, up_even;
  assign up_half = (rem >= HALF);                         // round half up: at or above 1/2
  /* verilator lint_off CMPCONST */                       // when S = 1, rem > HALF is never true: correct
  assign up_even = (rem > HALF) || (rem == HALF && floor_v[0]);   // convergent: ties to even
  /* verilator lint_on CMPCONST */
  assign round_up = (RND == 0) ? 1'b0 : (RND == 1) ? up_half : up_even;

  assign rounded = floor_v + RW'(round_up);
  assign rounded_c = CW'(rounded);             // sign-extend if the output is wider
  assign max_v     = CW'((64'sd1 <<< (OUT_W - 1)) - 1);
  assign min_v     = CW'(-(64'sd1 <<< (OUT_W - 1)));
  assign ovf       = (rounded_c > max_v) || (rounded_c < min_v);

  always_comb begin
    if (SAT && rounded_c > max_v)      dout = OUT_W'(max_v);
    else if (SAT && rounded_c < min_v) dout = OUT_W'(min_v);
    else                               dout = OUT_W'(rounded_c);  // wrap: keep the low bits
  end
endmodule
```

Points worth studying:

- **Parameters select the behavior at compile time.** `RND` and `SAT` are constants, so the synthesizer removes the logic of the unused modes completely. A conditional on a parameter costs nothing in hardware.
- **`ovf` reports overflow** even when saturation hides it. Counting overflows in a testbench tells you whether your word widths are adequate.
- **The waiver is local and explained.** With S = 1 there is only one dropped bit, so `rem > HALF` can never be true. Verilator rightly reports `CMPCONST`; the code is correct, so the warning is waived on that line only, with the reason (Part 4, section 4.5).

### Two bugs found while building it

**An Icarus limitation.** The first version computed `round_up` inside `always_comb` with a `case`. Icarus 12 printed `sorry: constant selects in always_* processes are not currently supported (all bits will be included)`. The results were still correct, but the message would hide real warnings, so the logic moved to `assign` statements.

**A real design bug.** The first version did the range comparison in RW bits, the width after rounding. That is fine when the output is narrower, but when OUT\_W is **wider** than RW (for example, dropping one fractional bit from a 10-bit value into a 12-bit output), the constant `max_v` was truncated to RW bits and became −1. Every saturating output was then wrong: the exhaustive test reported **1,024 mismatches out of 1,024** in each saturating mode. Comparing in CW bits, the larger of the two widths, fixed it. The lesson: test a parameterized module with parameter combinations at the edges, not just the default.

### Exhaustive verification

With a 10-bit input there are only 1,024 possible values, so the testbench simply tries them all, through six instances (three rounding modes × saturate/wrap), and writes one line per input. The Python checker compares every output with `fixedpoint.requant()`:

```python
#!/usr/bin/env python3
"""check_requant.py -- compare every requant.sv output with fixedpoint.requant()."""
import sys
import numpy as np
from fixedpoint import requant

IF, OW, OF = 6, 6, 3
variants = [(r, o) for o in ("saturate", "wrap") for r in ("floor", "round", "convergent")]
data = np.loadtxt("requant_out.txt", dtype=np.int64)
x, rtl = data[:, 0], data[:, 1:]
bad = 0
for k, (rnd, ovf) in enumerate(variants):
    ref = requant(x, IF, OW, OF, rnd, ovf)
    n = int(np.sum(ref != rtl[:, k]))
    bad += n
    print(f"{rnd:10s} {ovf:8s}: {len(x)} inputs, {n} mismatches")
print("PASS" if bad == 0 else "FAIL")
sys.exit(1 if bad else 0)
```

```text
floor      saturate: 1024 inputs, 0 mismatches
round      saturate: 1024 inputs, 0 mismatches
convergent saturate: 1024 inputs, 0 mismatches
floor      wrap    : 1024 inputs, 0 mismatches
round      wrap    : 1024 inputs, 0 mismatches
convergent wrap    : 1024 inputs, 0 mismatches
PASS
```

The same test passed for two more shapes: Q4.6 → Q4.5 (S = 1) and Q4.6 → Q7.5 (the widening case that exposed the bug). A few rows show the modes side by side, for Q4.6 in and Q3.3 out (the output LSB is 0.125):

| Input value | Floor, saturate | Round, saturate | Convergent, saturate | Round, wrap |
| --- | --- | --- | --- | --- |
| 0.0625 (exactly half an output LSB) | 0 | 1 | 0 | 1 |
| 0.1875 (1.5 output LSBs) | 1 | 2 | 2 | 2 |
| 0.3125 (2.5 output LSBs) | 2 | 3 | 2 | 3 |
| −0.0625 | −1 | 0 | 0 | 0 |
| 4.6875 (too large for Q3.3) | 31 | 31 | 31 | **−26** |
| −8.0 | −32 | −32 | −32 | **0** |

The wrap column shows why signal outputs saturate: 4.6875 became −26 (−3.25), and −8 became 0.

### Check your understanding: 6.4

1. A Q2.30 product is reduced to Q1.15 with `requant`. What are S, RW and CW?
2. Why does the rounded value need one more bit than the floored value?
3. Using the table, explain why 0.0625 rounds to 0 with convergent rounding but 0.1875 rounds to 2.
4. Which parameter values give exactly the behavior of the `>>> 3` in your `moving_avg8`? Which would fix it?
5. Why could the exhaustive test not be done for a 32-bit input, and what would you do instead?

#### Answers

1. S = 30 − 15 = **15**; RW = 32 + 1 − 15 = **18**; CW = max(18, 16) = **18**.
2. Rounding can add 1 to the largest floored value, which carries into a new top bit: in 4 bits, 0111 + 1 = 1000 overflows into the sign. The extra bit holds that carry so the range check sees the true value.
3. Both are exact ties (half an output LSB above an integer). Convergent rounding sends ties to the **even** neighbor: 0.0625 is between 0 and 1, and 0 is even; 0.1875 (1.5 LSBs) is between 1 and 2, and 2 is even.
4. `RND = 0` (floor) with S = 3 reproduces `>>> 3`; with `SAT = 0` it also wraps like the original. `RND = 1` (or 2) fixes the bias, and `SAT = 1` protects against the rounding carry.
5. 2³² ≈ 4.3 billion inputs would take far too long to simulate. Test the boundaries deliberately (values near each rounding threshold, ties, the largest and smallest values, values just above and below the output range) plus millions of random values, as in Part 4.

## 6.5 Multipliers and a pipelined MAC unit

The multiply-accumulate is the heart of every FIR filter, correlator and FFT. This section builds a pipelined MAC that computes dot products of Q1.15 vectors, keeps full precision in a 40-bit accumulator, and rounds and saturates once at the end. Written the right way, everything up to the accumulator fits in a single FPGA DSP block.

### What an FPGA DSP block contains

The AMD 7-series **DSP48E1** block (and its successors) contains, in order: input registers for its A and B operands, a **25 × 18-bit signed multiplier**, a product register (M), a **48-bit adder/accumulator** whose other input can be selected by a multiplexer (zero, its own output P, or a third input C), and an output register (P). A MAC maps onto it perfectly if the RTL has the same structure: registered inputs, a registered product, and an accumulator register. Other FPGA vendors' DSP blocks are organized similarly.

> **Figure:** mac.sv pipeline and its DSP48E1 mapping (Yosys 0.33, synth\_xilinx) (shown in the [online version](https://claude.ai/artifact/Kf8LBgUrUAxWA8XXHXmN3r))

### The design

```systemverilog
`timescale 1ns/1ps
// mac.sv -- pipelined multiply-accumulate with rounded, saturated output.
// Computes dot products: sum of a[i]*b[i] over a group of samples marked by first/last.
// Pipeline: input registers -> product register -> accumulator -> output register.
module mac #(
  parameter int A_W   = 16, A_F   = 15,      // a: Q1.15
  parameter int B_W   = 16, B_F   = 15,      // b: Q1.15
  parameter int ACC_W = 40,                  // accumulator: product width + 8 guard bits
  parameter int OUT_W = 16, OUT_F = 15       // result: Q1.15
) (
  input  logic                    clk,
  input  logic                    rst,
  input  logic                    in_valid,  // a, b, first, last are valid this cycle
  input  logic                    first,     // this product starts a new sum
  input  logic                    last,      // this product ends the sum: output it
  input  logic signed [A_W-1:0]   a,
  input  logic signed [B_W-1:0]   b,
  output logic                    out_valid,
  output logic signed [OUT_W-1:0] dout,
  output logic                    dout_ovf   // the result saturated
);
  localparam int P_W = A_W + B_W;            // full-precision product width
  localparam int P_F = A_F + B_F;            // and its fractional bits

  // ---- stage 1: input registers (map to the DSP block's A and B registers) ----
  logic signed [A_W-1:0] a_r;
  logic signed [B_W-1:0] b_r;
  logic                  v1, first1, last1;
  // ---- stage 2: product register (the DSP block's M register) ----
  logic signed [P_W-1:0] m_r;
  logic                  v2, first2, last2;
  // ---- stage 3: accumulator (the DSP block's P register) ----
  logic signed [ACC_W-1:0] acc;
  logic                    v3, last3;

  always_ff @(posedge clk) begin
    if (rst) begin
      v1 <= 1'b0;  v2 <= 1'b0;  v3 <= 1'b0;
    end else begin
      v1 <= in_valid;
      v2 <= v1;
      v3 <= v2;
    end
    // data registers need no reset: the valid bits say when they mean something
    a_r <= a;  b_r <= b;  first1 <= first;  last1 <= last;
    m_r <= a_r * b_r;     first2 <= first1; last2 <= last1;
    // (first ? 0 : acc) + product: the DSP block's Z multiplexer selects 0 or P
    if (v2) acc <= (first2 ? ACC_W'(0) : acc) + ACC_W'(m_r);
    last3 <= last2;
  end

  // ---- stage 4: round and saturate the finished sum, register the result ----
  logic signed [OUT_W-1:0] rq;
  logic                    rq_ovf;
  requant #(.IN_W(ACC_W), .IN_F(P_F), .OUT_W(OUT_W), .OUT_F(OUT_F), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(rq), .ovf(rq_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= v3 && last3;
    if (v3 && last3) begin
      dout     <= rq;
      dout_ovf <= rq_ovf;
    end
  end
endmodule
```

Design decisions, one by one:

- **Framing with `first` and `last`.** A dot product is a group of consecutive products. `first` marks the product that starts a new sum (the accumulator loads instead of adding), and `last` marks the one that completes it (the result is rounded and output). The same two flags will frame each output sample of an FIR filter in Part 7.
- **Valid bits travel with the data** through all four stages, as in Part 4. Only they are reset; the wide data registers are not, which saves logic and lets the DSP block absorb them (Part 2, section 2.4).
- **The accumulator has 8 guard bits**: 32 bits of Q2.30 product plus 8 = 40 bits, enough for 256 full-scale products without overflow. That is far inside the DSP block's 48 bits.
- **Rounding and saturation happen once**, after the sum, using the `requant` module of section 6.4 (Q8.30 in 40 bits → Q1.15, round half up, saturate).
- **Latency**: 4 clock cycles from the `last` input to `out_valid`.

### How the accumulator is written matters

The first version wrote the accumulator update as `acc <= first2 ? m_r : acc + m_r;`. It simulated identically, but Yosys mapped only the inputs and the multiplier into the DSP block and built the 40-bit accumulator in fabric logic. Rewriting it as **`acc <= (first2 ? 0 : acc) + m_r;`**, which states the DSP block's actual structure (a multiplexer choosing zero or P, feeding one adder), let Yosys pack everything:

| Version | DSP48E1 configuration | Fabric cells (excluding I/O) |
| --- | --- | --- |
| `first2 ? m_r : acc + m_r` | AREG = 1, BREG = 1, MREG = 1, **PREG = 0** | 63 flip-flops, 119 LUTs, 22 `CARRY4` |
| `(first2 ? 0 : acc) + m_r` | AREG = 1, BREG = 1, MREG = 1, **PREG = 1**; `first2` drives the OPMODE input | 23 flip-flops, 39 LUTs, 12 `CARRY4` |

The remaining fabric logic is the `requant` stage and the output register. The lesson generalizes: **write arithmetic in the shape of the hardware block you want**, then check the synthesis report to confirm the tool understood. Vendor tools (Vivado, Quartus) publish coding templates for their DSP blocks for this reason.

### Verification: bit-exact against Python

The Python generator builds 300 dot products of random length 1 to 64, of three kinds: random real values scaled so the sums usually fit; small values; and, in every tenth group, the worst case, −1 × −1 repeated, which must saturate. For each, it computes the exact integer sum, applies `requant()` for the expected output, and also records the floating-point dot product of the same Q1.15 inputs for an accuracy check:

```python
#!/usr/bin/env python3
"""gen_mac.py -- stimulus and bit-exact golden model for mac.sv (dot products of Q1.15 vectors)."""
import argparse
import numpy as np
from fixedpoint import quantize, requant, to_real

p = argparse.ArgumentParser()
p.add_argument("--seed", type=int, default=1)
p.add_argument("--groups", type=int, default=300)
args = p.parse_args()
rng = np.random.default_rng(args.seed)

rows, expected, ideal = [], [], []
for g in range(args.groups):
    L = int(rng.integers(1, 65))                     # vector length 1..64
    kind = g % 10
    if kind == 0:                                    # worst case: -1 * -1 every time -> saturates
        a = np.full(L, -32768); b = np.full(L, -32768)
    elif kind == 1:                                  # small vectors: sum stays inside Q1.15
        a = rng.integers(-32768, 32768, L); b = rng.integers(-32768, 32768, L) // max(L, 1)
    else:                                            # random real values, scaled so sums rarely overflow
        a = quantize(rng.uniform(-1, 1, L), 16, 15)
        b = quantize(rng.uniform(-1, 1, L) / np.sqrt(L), 16, 15)
    for i in range(L):
        rows.append((int(a[i]) & 0xFFFF, int(b[i]) & 0xFFFF, int(i == 0), int(i == L - 1)))
    acc = int(np.sum(a.astype(np.int64) * b.astype(np.int64)))      # exact sum, Q?.30
    expected.append(int(requant(np.array([acc]), 30, 16, 15, "round", "saturate")[0]))
    ideal.append(float(np.dot(to_real(a, 15), to_real(b, 15))))     # floating-point reference

with open("mac_in.txt", "w") as f:
    for r in rows:
        f.write(f"{r[0]:04x} {r[1]:04x} {r[2]} {r[3]}\n")
with open("mac_expected.txt", "w") as f:
    f.write("\n".join(str(v) for v in expected) + "\n")
np.save("mac_ideal.npy", np.array(ideal))
print(f"{len(rows)} products in {args.groups} dot products")
```

The testbench reads one line per valid cycle with `$fscanf`, inserts random idle cycles (with all inputs set to `'x`), and writes each result. Its read loop stops when `$fscanf` no longer returns 4 fields. The first version used `break` to leave the loop, and Icarus 12 refused: `sorry: break statements not supported`. A loop condition works in every simulator.

```systemverilog
    code = 4;
    while (code == 4) begin
      if ($urandom_range(0, 3) == 0) begin           // idle cycle about 1 time in 4
        in_valid = 1'b0; a = 'x; b = 'x; first = 1'bx; last = 1'bx;
      end else begin
        code = $fscanf(fd_in, "%h %h %d %d\n", ra, rb, rf, rl);   // 4 = one line read
        in_valid = (code == 4);
        a = ra; b = rb; first = rf[0]; last = rl[0];
      end
      @(negedge clk);
    end
```

The checker compares the results bit for bit, then measures the error of the unsaturated results against floating point:

```python
lsb = 2.0**-15
inside = np.abs(ideal) < 1 - lsb                 # results that did not need saturating
err = rtl[inside] * lsb - ideal[inside]
print(f"error vs floating point (unsaturated results): max {np.max(np.abs(err))/lsb:.3f} LSB, "
      f"mean {np.mean(err)/lsb:+.3f} LSB")
```

The result for seed 1 (seeds 2 to 5 also passed bit-exact, with maximum errors between 0.495 and 0.500 LSB and mean errors within ±0.011 LSB):

```text
9876 products in 300 dot products
300 results, 31 saturated
PASS: 300 results bit-exact
error vs floating point (unsaturated results): max 0.499 LSB, mean -0.011 LSB
```

The hardware's only error is the single final rounding: at most half an output LSB, with essentially zero mean. Every product and every partial sum was exact. Changing `RND(1)` to `RND(0)` (truncation) in the MAC made the bit-exact check fail on 129 of the 300 results, each exactly one LSB too low, which shows that the model really pins down the rounding.

### Check your understanding: 6.5

1. How many guard bits does the accumulator need for dot products of length up to 1,024 with Q1.15 inputs? Does it still fit a DSP48E1?
2. Why are `a_r`, `b_r`, `m_r` and `acc` not reset, while `v1`, `v2`, `v3` and `out_valid` are?
3. What would go wrong if `first` were not delayed through the pipeline together with the data?
4. The maximum error against floating point is 0.499 LSB. Where does it come from, and why is it not larger after summing 64 products?
5. You need 25-bit samples times 18-bit coefficients. Which DSP48E1 port should each go to, and what is the product width?

#### Answers

1. ⌈log₂ 1024⌉ = **10** guard bits: 32 + 10 = **42 bits**, which fits in the 48-bit accumulator.
2. The data registers' contents only matter when the corresponding valid bit is 1, so their reset values are never used; leaving out the reset saves logic and lets them map into the DSP block (whose registers have only synchronous resets anyway). The valid bits control what the outside world sees, so they must start at 0.
3. The accumulator would load or add based on a `first` flag that belongs to a different sample (one or two stages earlier), so sums would start in the wrong place. Every control bit must be delayed exactly as much as the data it describes.
4. From the one rounding step at the output, which is at most half an LSB. Before that step, every product and partial sum is computed exactly in the 40-bit accumulator, so no error accumulates over the 64 products.
5. The 25-bit sample goes to the **A** port (25 bits) and the 18-bit coefficient to the **B** port (18 bits). The product is 25 + 18 = **43 bits**, within the 48-bit post-adder.

## 6.6 Choosing word widths

Word widths are a design decision, made **before** writing RTL, with a Python experiment: quantize the model the way the hardware will, and measure the damage against the floating-point original. This section walks through the decision for a realistic 32-tap low-pass filter, the kind Part 7 builds.

### The filter

SciPy designs a 32-tap low-pass filter with a cutoff at 0.1 cycles per sample in one line (Part 7 explains the method):

```python
from scipy.signal import firwin, freqz
h = firwin(32, 0.2)          # cutoff given as a fraction of Nyquist: 0.2 x 0.5 = 0.1 cycles/sample
```

Its coefficients sum to 1.0 (gain 1 at 0 Hz), the largest is **0.196**, and the sum of their absolute values is **1.327**. In floating point, its **stopband attenuation** (how far it suppresses frequencies above 0.15 cycles per sample) is **44.2 dB**.

### Step 1: the input format

The input format is usually given by the ADC or the previous block: here 16-bit samples, Q1.15.

### Step 2: the coefficient width and scaling

The coefficient width trades accuracy against multiplier size. On a DSP48E1, coefficients up to 18 bits are free (the B port is 18 bits wide). The table measures two things for each width: the stopband attenuation of the quantized coefficients, and the **output SNR**, the full fixed-point filter's output against the ideal floating-point filter, for 200,000 random input samples (16-bit input, exact accumulation, output rounded to Q1.15).

| Coefficient bits W | Fractional bits F | Stopband attenuation | Output SNR vs floating point |
| --- | --- | --- | --- |
| 18 | 17 (Q1.17) | 44.2 dB | 81.4 dB |
| 16 | 15 (Q1.15) | 44.3 dB | 76.4 dB |
| 16 | **17** (scaled) | 44.2 dB | **81.4 dB** |
| 12 | 11 (Q1.11) | 45.1 dB | 54.7 dB |
| 12 | **13** (scaled) | 44.4 dB | **67.1 dB** |
| 10 | 9 (Q1.9) | 41.5 dB | 42.3 dB |
| 8 | 7 (Q1.7) | 30.2 dB | 29.4 dB |

Three lessons from the table:

- **Scale coefficients to fill the word.** The largest coefficient is below 0.25, so in Q1.15 the top two bits after the sign are always equal to the sign: wasted. Using F = W + 1 (two more fractional bits; the values still fit because |h| < 0.25) gains about 12 dB, two bits, wherever the coefficients limit the accuracy (12-bit: 54.7 → 67.1 dB; at 16 bits the gain is smaller because the output rounding becomes the limit). A 16-bit coefficient scaled this way performs exactly like an 18-bit one. In hardware, the extra scaling is just a different binary-point position in the accumulator, which `requant` handles by dropping 2 more bits.
- **The two measures disagree at 12 bits.** The stopband even looks slightly better (45.1 dB, by luck of rounding), but the output SNR drops to 54.7 dB because the passband response has changed. Always measure the quantity your application cares about, and more than one.
- **Around 6 dB per bit, again**: each two bits removed costs roughly 12 dB of SNR, until the stopband itself collapses at 8 bits.

For this filter and a 16-bit output, 16 bits scaled to F = 17, or 18 bits, is the right choice; the output rounding (about 82 dB here) then limits the accuracy, not the coefficients.

### Step 3: the product and accumulator widths

The product width follows from the operands: a 16-bit sample times an 18-bit coefficient is 34 bits. For the accumulator, there are two ways to count guard bits:

- **Worst case by length**: 32 taps need ⌈log₂ 32⌉ = 5 guard bits, 39 bits in total. Always safe.
- **Worst case by coefficients**: the output can be at most Σ|h| = 1.327 times the largest input. That needs only ⌈log₂ 1.327⌉ = 1 extra integer bit. This bound is tight, but valid only for these coefficients.

On an FPGA, a 48-bit DSP accumulator makes the choice easy: use the safe count. In an ASIC, where every bit costs area, designers use the tighter bound.

### Step 4: the output format

The output is rounded to Q1.15 and saturated. Because Σ|h| = 1.327 > 1, a full-scale input pattern with the right signs can produce an output above 1, so saturation is required, not optional. In practice, designers either accept rare saturation, scale the coefficients down slightly, or keep one more integer bit at the output (Q2.14).

### The general procedure

1. Write the floating-point model and decide what "good enough" means: an output SNR, a stopband attenuation, or a maximum error in LSBs.
2. Write a fixed-point model with every width as a parameter, using `quantize` and `requant`.
3. Sweep the widths, measure, and pick the smallest that meets the target with a margin.
4. Only then write the RTL, with those widths as parameters, and verify it bit-exactly against the same fixed-point model.

### Check your understanding: 6.6

1. The largest coefficient of a filter is 0.45. What is the largest F you can use for 16-bit coefficients?
2. Why did scaling 16-bit coefficients to F = 17 make them behave like 18-bit coefficients?
3. A 64-tap filter has Σ|h| = 2.1. How many guard bits does each method give?
4. Why can the output SNR get worse while the stopband attenuation looks better?
5. In the scaled design (coefficients with F = 17, input Q1.15), what are the accumulator's fractional bits, and how many bits does `requant` drop to produce Q1.15?

#### Answers

1. The coefficient must stay below 2^(W−1−F) = 2^(15−F). With 0.45 < 0.5 = 2^−1, F can be **16** (range ±0.5). F = 17 (range ±0.25) would overflow.
2. With |h| < 0.25, the top two magnitude bits of an 18-bit Q1.17 coefficient are always copies of the sign bit, so the 18-bit word carries only 16 bits of information. Storing the same values as 16-bit words with F = 17 keeps every significant bit and drops only the redundant ones.
3. By length: ⌈log₂ 64⌉ = **6**. By coefficients: ⌈log₂ 2.1⌉ = **2**.
4. Stopband attenuation measures only the worst point in one frequency band. Quantization also changes the passband (the gain and ripple where the signal is), which the output SNR includes. A change can improve one number while harming the other.
5. 15 + 17 = **32** fractional bits; `requant` drops 32 − 15 = **17** bits.

## 6.7 Exercises

For scale: their worked solutions add 4 design files, 2 testbenches and 5 Python scripts, about 460 new lines (not counting short checks run inline). Time depends too much on experience for a reliable estimate, so none is given. Use the Part 4 flow for every RTL exercise: a Python model built on `fixedpoint.py`, a file-driven testbench, a bit-exact checker, lint, and a Yosys report. Send me your code, tables and plots.

- [ ] Exercise 1: Q-format drills
- [ ] Exercise 2: fix the moving average's rounding
- [ ] Exercise 3: a complex multiplier
- [ ] Exercise 4: a word-width study
- [ ] Exercise 5: an 18-bit-coefficient MAC

### Exercise 1: Q-format drills (by hand, then check in Python)

1. Convert 0.3, −0.3, 0.999 and −0.0001 to Q1.11 with rounding. Give the integers and the 12-bit hex patterns.
2. A 24-bit audio sample is Q1.23. What is its resolution? Its SQNR for a full-scale sine?
3. Multiply a Q1.11 value by a Q3.13 value. Give the product's format and width. Which pair of inputs needs the top bit of the product?
4. Add a Q1.15 value and a Q4.12 value. Describe the alignment step and the format of a safe sum.

### Exercise 2: fix the moving average's rounding

Replace the `>>> 3` in your `moving_avg8` (Part 2, Exercise 5) with a `requant` instance (RND = 1, SAT = 1).

- Update the Python model to use `requant(..., "round", "saturate")` and verify the new RTL bit-exactly.
- Measure the mean output error against the exact average (the sum divided by 8, in floating point), for the old and the new design, on 100,000 random samples. Do your numbers match the −7/16 LSB predicted in section 6.2?
- Can the rounded result ever need saturation? Find the input pattern that would, or prove that none exists.

### Exercise 3: a complex multiplier

Complex multiplication, (a + jb)(c + jd) = (ac − bd) + j(ad + bc), is the core of the mixers and FFTs in Parts 9 and 11.

- Build `cmult` with Q1.15 inputs and Q1.15 outputs (round, saturate), pipelined like the MAC: input registers, product registers, sum registers, output stage. Keep the products at full precision until the final `requant`.
- Python model: use integer arithmetic exactly as the hardware does. Verify on random inputs and on the corners (−1 − j)(−1 − j) and (−1 + 0j)(−1 + 0j). Which inputs saturate, and why?
- Synthesize with `synth_xilinx`: how many DSP48E1 blocks does Yosys use? There is a well-known trick that computes a complex product with **three** multiplications instead of four. Look up "Gauss's complex multiplication" and explain what it costs in adders and bit growth.

### Exercise 4: a word-width study

Design `h = firwin(64, 0.1)` (64 taps, cutoff 0.05 cycles per sample).

- Following section 6.6, sweep the coefficient width from 8 to 18 bits, with and without scaling to fill the word, and tabulate the stopband attenuation and the output SNR.
- Choose the smallest coefficient width that gives at least 70 dB output SNR with 16-bit input and output. Justify the accumulator width both ways (by length and by Σ|h|).
- Plot the frequency response for floating point, your chosen width, and 8 bits on one chart (in dB, from 0 to f\_s/2).

### Exercise 5: an 18-bit-coefficient MAC

Change the MAC's parameters to `B_W = 18`, `B_F = 17` (coefficients) and keep A as Q1.15 samples.

- Update `gen_mac.py` and verify bit-exactly. What are the product width, the accumulator's fractional bits, and the number of bits `requant` drops?
- Confirm with Yosys that the design still uses one DSP48E1 with AREG, BREG, MREG and PREG all set to 1. (Hint: write the netlist with `write_verilog -noattr net.v` and search it for `PREG`.)
- Then try `B_W = 19`. What does Yosys do now, and why?

## 6.8 Summary and what comes next

You can now represent real numbers in hardware, predict the error that representation causes, and build arithmetic that is bit-exact with a Python model. Keep this table beside you for Part 7.

| Concept | Rule or tool | Remember |
| --- | --- | --- |
| Fixed-point value | q / 2^F in a W-bit word | Qm.n: here m includes the sign bit |
| Range and resolution | ±2^(W−1−F); LSB = 2^−F | Q1.15 holds −1 but not +1 |
| Quantization noise | Variance LSB²/12 with rounding | Truncation adds −½ LSB bias: 6 dB worse |
| SQNR of a full-scale sine | 6.02 W + 1.76 dB | About 6 dB per bit |
| Sum of N values | ⌈log₂ N⌉ extra bits | Or ⌈log₂ Σ\|h\|⌉ for a known filter |
| Product | W\_a + W\_b bits, F\_a + F\_b fractional | −1 × −1 needs the top bit |
| Signed multiply | Both operands `signed` | One unsigned operand ruins it |
| Precision strategy | Exact products, wide accumulator, round once | DSP48E1: 25 × 18 multiplier, 48-bit accumulator |
| Reduce precision | `requant` (RND, SAT parameters) | Rounding needs one extra bit for the carry |
| DSP-friendly accumulator | `acc <= (first ? 0 : acc) + m;` | Check the netlist: AREG, BREG, MREG, PREG |
| Python helpers | `quantize`, `to_real`, `requant` | Same rounding as the hardware |
| Word widths | Sweep in Python first, then write RTL | Scale coefficients to fill the word |

The ideas that matter most from this part:

1. A fixed-point design has two models: a bit-exact one for verification, and a floating-point one for judging accuracy. You need both.
2. Rounding costs one adder and gains one bit; saturation costs two comparators and prevents disasters.
3. Keep full precision through the arithmetic and round once. FPGA DSP blocks are built for exactly this.
4. Write arithmetic in the shape of the hardware you want, then confirm it in the synthesis report.

**Part 7: FIR filters** puts everything together. You will design filters with SciPy and understand how the window method trades length against sharpness, then build three hardware architectures of the same filter: the direct form from Part 5, the transposed form that pipelines naturally, and the symmetric form that halves the number of multipliers. Each will be built from the pieces of this part, verified bit-exactly against a fixed-point Python model, and compared in DSP blocks, LUTs and logic depth.
