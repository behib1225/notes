# Verilog & RTL for DSP — Appendix C: The Mathematics Behind the DSP Parts

*Markdown export of the online document: https://claude.ai/artifact/2HA6TpUNfXT1oUGK8nfuyq. Diagrams and charts appear only online; each is marked below with its title.*


Oct 22, 2026 · @Behi

## Why this appendix

From Part 5 on, the course uses complex exponentials, frequency responses, the z-transform, and poles and zeros, introducing each only briefly where it is first needed. This appendix collects that mathematics in one place, at the level the course uses it: enough to follow every formula and to reason about a design, without proofs.

**When to read it:** before Part 5 if complex numbers are rusty; before Part 8 (IIR filters) for the z-transform and poles; and before Part 9 (mixers) for complex signals.

**How the examples were checked:** every identity and every number below was computed in Python with NumPy and SciPy, and the results quoted are the computed ones. Try them yourself: the code is short, and seeing a formula come out of a computation is the best way to trust it.

## Complex numbers

A complex number z = a + jb has a **real part** a and an **imaginary part** b, where j² = −1 (engineers write j, since i is a current). Drawn as the point (a, b) in a plane, it has a **magnitude** |z| = √(a² + b²) and an **angle** ∠z = atan2(b, a), the angle from the positive real axis.

### Euler's formula

The link between the two descriptions is **Euler's formula**:

```latex
e^{j\theta} = \cos\theta + j \sin\theta
```

so any complex number can be written z = |z|·e^{j∠z}. Checked numerically: e^{j·0.7} = 0.764842 + 0.644218j, and cos 0.7 + j sin 0.7 gives the same value to every digit printed.

e^{jθ} lies on the **unit circle** (magnitude 1) at angle θ. Its real part is the cosine and its imaginary part the sine, which is exactly what the NCO of Part 9 produces: cos\_o and sin\_o are the real and imaginary parts of one rotating complex number.

### Multiplication is rotation

In the magnitude-and-angle form, multiplication is simple:

```latex
\left(r_1 e^{j\theta_1}\right)\left(r_2 e^{j\theta_2}\right) = r_1 r_2\, e^{j(\theta_1 + \theta_2)}
```

**Magnitudes multiply and angles add.** For example, 2e^{j0.3} × 1.5e^{j0.5} has magnitude 3 and angle 0.8, as computed. Multiplying by e^{jθ}, magnitude 1, is a pure **rotation** by θ. That is what a mixer does to every sample (Part 9), what a twiddle factor does inside an FFT butterfly (Part 11), and what each CORDIC stage approximates with shifts and adds (Part 9).

In rectangular form the same product is (a + jb)(c + jd) = (ac − bd) + j(ad + bc): four real multiplications, the complex multiplier of Part 6, Exercise 3.

## Complex exponential signals

### The basic signal

The sampled signal x\[n\] = e^{j2πfn} is a point rotating around the unit circle by 2πf radians per sample: f is its frequency in **cycles per sample**. Its real part is cos(2πfn) and its imaginary part sin(2πfn). This is the signal DSP is built on, because filters only scale and shift it (next section).

### Negative frequencies

With f negative, the point rotates the other way: e^{j2π(−f)n} is a perfectly valid, different signal. A **real** cosine contains both directions:

```latex
\cos(2\pi f n) = \tfrac12 \left( e^{j2\pi f n} + e^{-j2\pi f n} \right)
```

(checked: identical sample by sample). This is why a real signal's spectrum is symmetric, why Part 9's real mixer produces a mirror image, and why a complex signal (I and Q) can carry a single frequency without its mirror (Part 9 solutions, Exercise 5).

### Aliasing

Since e^{j2πn} = 1 for every integer n, adding a whole number to f changes nothing:

```latex
e^{j2\pi (f + k) n} = e^{j2\pi f n}\, e^{j2\pi k n} = e^{j2\pi f n} \quad (k \text{ an integer})
```

For example, f = 0.3 and f = −0.7 give identical samples (checked). Sampled signals can only tell frequencies apart **modulo 1 cycle per sample**, which is aliasing (Part 5). For real signals, the symmetry of the previous paragraph folds the range further, to 0 to 0.5.

### Mixing

Multiplying two complex exponentials adds their frequencies (angles add, from the previous section):

```latex
e^{j2\pi f_1 n}\, e^{-j2\pi f_0 n} = e^{j2\pi (f_1 - f_0) n}
```

Checked with f₁ = 0.3 and f₀ = 0.1: the product equals e^{j2π·0.2n}. That is the digital mixer of Part 9 and the first stage of the Part 12 DDC: multiplying by e^{−j2πf₀n} moves every frequency down by f₀.

## Frequency response

### Why complex exponentials are special

Feed x\[n\] = e^{j2πfn} into an FIR filter y\[n\] = Σ\_k h\[k\] x\[n−k\]:

```latex
y[n] = \sum_k h[k]\, e^{j2\pi f (n-k)} = \Big( \sum_k h[k]\, e^{-j2\pi f k} \Big) e^{j2\pi f n} = H(f)\, e^{j2\pi f n}
```

The output is the **same** complex exponential, multiplied by one complex number, H(f), the **frequency response**. Its magnitude |H(f)| is the gain at that frequency, and its angle is the phase shift. Any signal is a sum of such exponentials (that is what the DFT of Part 11 computes), and the filter treats each one independently, which is why a filter can be described entirely by H(f).

### The moving average, worked out

For the 8-sample average, h\[k\] = 1/8 for k = 0 to 7, the sum is a geometric series:

```latex
H(f) = \frac18 \sum_{k=0}^{7} e^{-j2\pi f k} = e^{-j\pi f \cdot 7}\; \frac{\sin(8\pi f)}{8 \sin(\pi f)}
```

Three ways of computing it at f = 0.05 agree to six digits: the sum, the closed form, and an actual simulation that filters e^{j2π·0.05n} and divides output by input after the start-up, all **0.345009 − 0.677119j**, of magnitude 0.75995 (Part 5's value). The factor e^{−jπf·7} is a pure delay of 3.5 samples at every frequency, **linear phase**, the property of every symmetric FIR filter (Part 7). The real factor sin(8πf)/(8 sin πf) is zero at f = 1/8, 2/8, 3/8 and 4/8: the moving average's nulls.

## The z-transform

### The definition

The frequency response replaced each delay by k samples with e^{−j2πfk}. The **z-transform** does the same with a general complex variable z, writing a delay of one sample as z⁻¹:

```latex
H(z) = \sum_k h[k]\, z^{-k}, \qquad H(f) = H(z)\big|_{z = e^{j2\pi f}}
```

The frequency response is the z-transform **on the unit circle**: f = 0 is z = 1, f = 0.25 is z = j, and f = 0.5 (half the sample rate) is z = −1. Going once around the circle sweeps every frequency, which is aliasing seen geometrically.

### From a difference equation to a transfer function

The point of z is that it turns recursive filters into simple algebra. Take the DC blocker of Part 8, Exercise 1, y\[n\] = x\[n\] − x\[n−1\] + 0.995·y\[n−1\]. Write each delay as z⁻¹ and collect terms:

```latex
Y(z) = X(z) - z^{-1} X(z) + 0.995\, z^{-1} Y(z) \quad\Longrightarrow\quad H(z) = \frac{Y(z)}{X(z)} = \frac{1 - z^{-1}}{1 - 0.995\, z^{-1}}
```

In general, the difference equation of Part 8's biquad, y = b₀x + b₁x₁ + b₂x₂ − a₁y₁ − a₂y₂, gives

```latex
H(z) = \frac{b_0 + b_1 z^{-1} + b_2 z^{-2}}{1 + a_1 z^{-1} + a_2 z^{-2}}
```

which is how SciPy describes every filter: the arrays `b` and `a` are these two polynomials. Evaluated at z = e^{j2π·0.01}, the DC blocker's H(z) is 0.99617 + 0.079445j, exactly what `scipy.signal.freqz([1, -1], [1, -0.995])` returns at that frequency.

## Poles and zeros

### Definitions

The **zeros** of H(z) are the roots of its numerator, where H = 0; the **poles** are the roots of its denominator, where H grows without bound. Since |H(f)| is |H(z)| on the unit circle, a picture of the poles and zeros shows the frequency response at a glance:

- A **zero on the unit circle** at angle 2πf₀ makes the gain exactly 0 at f₀: a null. The DC blocker's zero at z = 1 removes 0 Hz completely; the moving average's zeros sit at f = 1/8, 2/8, …
- A **pole close to the unit circle** at angle 2πf₀ makes the gain large near f₀: a resonance. The closer to the circle, the higher and narrower the peak.
- A pole and a zero close together nearly cancel, except near them. The DC blocker's pole at 0.995 sits right next to its zero at 1, so the gain is flat (2/1.995 = 1.0025 at f\_s/2) except in a narrow notch around 0 Hz, whose −3 dB cutoff is at about (1 − 0.995)·f\_s/(2π) = **38.2 Hz** at 48 kHz.

### Stability

An IIR filter is **stable** if and only if **every pole lies strictly inside the unit circle**, |p| < 1. A pole outside makes the impulse response grow like |p|ⁿ: for a single pole at 1.01, it reaches 143 after 500 samples and keeps growing. This is the danger in Part 8: rounding a coefficient moves its poles, and a pole that started at radius 0.997 can end up outside (Part 8 solutions, Exercise 2, where a 10th-order polynomial with 20-bit coefficients put a pole at 1.155).

### A resonator, by hand

A second-order section with a complex pole pair at radius r and angle ±θ has the denominator

```latex
(1 - r e^{j\theta} z^{-1})(1 - r e^{-j\theta} z^{-1}) = 1 - 2r\cos\theta\, z^{-1} + r^2 z^{-2}, \qquad a_1 = -2r\cos\theta,\quad a_2 = r^2
```

For r = 0.99 and θ = 2π × 0.1: a₁ = −1.601854 and a₂ = 0.9801, and the roots of z² + a₁z + a₂ are 0.800927 ± 0.581907j, of magnitude exactly 0.99 (checked). The response peaks at f = 0.09999, essentially θ/2π, and the width of the peak follows the pole's distance from the circle:

| Pole radius r | Measured −3 dB bandwidth (cycles per sample) | Approximation (1 − r)/π |
| --- | --- | --- |
| 0.9 | 0.0344 | 0.0318 |
| 0.99 | 0.00320 | 0.00318 |
| 0.995 | 0.00159 | 0.00159 |

The approximation is excellent for poles near the circle, the case that matters in narrow filters, and drifts as the pole moves inward. Two consequences shape Part 8's designs: a sharp filter needs poles very close to the circle, so a₂ = r² is close to 1 and a₁ close to ±2, which is why the coefficients need Q2.16 rather than Q1.17; and those poles are the most sensitive to coefficient rounding.

### Why filters are built from sections

A high-order filter could be written as one big polynomial ratio. But each coefficient of a big polynomial depends on **all** its roots, and when the roots are clustered (as the poles of a narrow filter are), tiny changes in the coefficients move the roots far. A second-order section's two coefficients depend only on its own two poles. That is the whole reason for the cascade of biquads in Part 8, and the Part 8 solutions measured how large the effect is: the 10th-order filter needed 36 fractional bits to stay stable as one polynomial, but only 7 as five sections.
