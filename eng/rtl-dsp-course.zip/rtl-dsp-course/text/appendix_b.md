# Verilog & RTL for DSP — Appendix B: Measuring and Cross-Checking

*Markdown export of the online document: https://claude.ai/artifact/5UJq2UPxPsecQq5o4hY4SX. Diagrams and charts appear only online; each is marked below with its title.*


Oct 22, 2026 · @Behi

## Why measurements need one definition

This appendix covers two habits the course used without stating them. The first is how to measure: a number such as "SFDR" or "mirror level" means nothing until its method is fixed. The second is how to check a design against something other than its own model.

The need for the first showed itself in Part 12. The mirror image of the DDC's output, with a 12-bit NCO table, was first reported as **−69.2 dBc**, and later measured as **−73.2 dBc** for exactly the same design. Neither was wrong. The two measurements took the level from slightly different sets of FFT bins, and near the noise floor that changes the answer by a few dB. Every part of the course measured with its own short Python snippet, so nothing guaranteed that two numbers were comparable.

The cure is to define each measurement once, in one file, and use that file everywhere. `measure.py`, below, does this, and it reproduces the course's established figures (see Validation, below), so the old numbers remain valid.

## measure.py

### The conventions

Every function follows the same four rules:

- **Frequencies are in cycles per sample**: 0 to 0.5 for real signals, −0.5 to 0.5 for complex ones.
- **The window is a 4-term Blackman–Harris**, normalized by its coherent gain (its mean value, 0.35875), so that a sine of amplitude 1 exactly on an FFT bin reads **0 dBFS**.
- **The level at a frequency f is the largest bin within ±2 bins of f.** A tone between two bins then reads correctly to within the window's scalloping loss, 0.83 dB at most.
- **A result is never quoted without its method.** When a number goes into a report, the function and its parameters go with it.

### The code

```python
#!/usr/bin/env python3
"""measure.py -- the course's standard measurements, defined once."""
import numpy as np

def bh_window(n):
    k = np.arange(n); a = (0.35875, 0.48829, 0.14128, 0.01168)
    return a[0] - a[1]*np.cos(2*np.pi*k/n) + a[2]*np.cos(4*np.pi*k/n) - a[3]*np.cos(6*np.pi*k/n)

def spectrum(x, full_scale=1.0):
    """Return (freqs, dBFS). Real x: one-sided, 0 .. 0.5. Complex x: two-sided, -0.5 .. 0.5."""
    x = np.asarray(x); n = len(x); w = bh_window(n); cg = w.mean()
    X = np.fft.fft(x * w) / (n * cg * full_scale)
    if np.iscomplexobj(x):
        return np.fft.fftshift(np.fft.fftfreq(n)), 20*np.log10(np.abs(np.fft.fftshift(X)) + 1e-300)
    mag = 2*np.abs(X[: n//2 + 1]); mag[0] /= 2
    return np.arange(n//2 + 1) / n, 20*np.log10(mag + 1e-300)

def level(x, f, guard=2, full_scale=1.0):
    """Level (dBFS) of the component at f: the largest bin within +-guard bins."""
    fr, db = spectrum(x, full_scale)
    return float(db[np.abs(fr - f) <= (guard + 0.5) / len(x)].max())

def sfdr(x, exclude=8, dc=4):
    """Spurious-free dynamic range (dB) of a real single tone: carrier peak minus the largest
    other bin, excluding +-exclude bins around the carrier and the lowest dc bins."""
    fr, db = spectrum(x)
    k = int(np.argmax(db)); m = np.ones(len(db), bool)
    m[max(0, k - exclude): k + exclude + 1] = False; m[:dc] = False
    return float(db[k] - db[m].max()), float(fr[k])

def mirror_dbc(z, f, guard=2):
    """Level at -f relative to the level at +f (dB), for a complex signal z."""
    return level(z, -f, guard) - level(z, f, guard)

def sqnr_db(y, ref, skip=0):
    """10 log10(power of ref / power of (y - ref)), after dropping skip start-up samples."""
    y, ref = np.asarray(y)[skip:], np.asarray(ref)[skip:]
    return float(10*np.log10(np.mean(np.abs(ref)**2) / np.mean(np.abs(y - ref)**2)))

def gain(x, y, f):
    """Complex gain y/x at frequency f (cycles per sample), from the projections of x and y onto
    exp(j 2 pi f n). Use whole cycles of every tone present, or the result leaks (Part 5)."""
    n = np.arange(len(x)); e = np.exp(-2j*np.pi*f*n)
    return complex(np.sum(np.asarray(y)*e) / np.sum(np.asarray(x)*e))
```

A few choices are worth explaining:

- `spectrum` handles real and complex signals differently. A real signal's spectrum is symmetric, so it is shown one-sided, and every bin except DC is doubled, which makes a real sine read its true amplitude. A complex signal's two sides are different signals, which is exactly what `mirror_dbc` compares.
- `sfdr` excludes ±8 bins around the carrier, the width of a Blackman–Harris main lobe with margin, and the lowest 4 bins, so that a DC offset is not counted as a spur.
- `gain` returns a complex number, so both the magnitude response and the phase (and from it the delay) come from one measurement.

## Validation

A measurement library is only trustworthy if it reproduces known answers. These checks were run on it:

| Test | Expected | `measure.py` |
| --- | --- | --- |
| Real sine, amplitude 1, on a bin (4,096 points) | 0 dBFS | 0.000 dBFS |
| Real sine, amplitude 0.1, on a bin | −20 dBFS | −20.00 dBFS |
| Complex tone exp(j2πfn), on a bin | 0 dBFS | 0.000 dBFS |
| Real sine halfway between two bins | at most 0.83 dB low (scalloping) | −0.826 dBFS |
| Part 9 NCO, 10-bit table, FCW `0x0B3A5C1F`, 16,384 samples | SFDR 60.4 dB | 60.4 dB |
| Part 12 DDC output (model, seed 1) | mirror −64.4 dBc, tone −16.8 dBFS | −64.4 dBc, −16.8 dBFS |
| 8-sample average at 0.05 cycles per sample | gain 0.75995, phase −1.0996 rad | 0.75995, −1.0996 rad |

The first four check the calibration; the last three show that the course's published figures were measured consistently with this definition. Part 12's mirror figure for the 12-bit table (−73.2 dBc) also comes from this definition; section 12.4 now states it.

## The blind spot of bit-exact checking

### What bit-exactness proves, and what it does not

The course's central method compares the RTL, bit for bit, with a Python model. A match proves that **the RTL computes what the model computes**. It proves nothing about whether **the model computes what the specification asks for**. If both were written from the same misunderstanding, they agree, and the test passes on a wrong design.

### A demonstration

The DDC's mixer computes I = x·cos and Q = −x·sin, which multiplies by e^{−jωn} and moves the input frequency f to f − f\_LO. A plausible mistake is to drop the minus sign: Q = +x·sin, which multiplies by e^{+jωn} instead. A real input has components at +5.0 and −5.0 MHz; this version moves the −5.0 MHz one to −0.2 MHz, so the near-baseband output is the mirror image of the intended one. Here it was made **in both places**, in `mixer.sv` (`assign pq = x_d * lo_sin;`) and in the model (`q = requant(+(x * s), ...)`), and the Part 12 testbench and stimulus were run on both versions:

|  | Bit-exact check | Tone at +0.2 MHz | Tone at −0.2 MHz |
| --- | --- | --- | --- |
| Correct design | PASS (2,048 outputs) | **−16.8 dBFS** | −81.2 dBFS |
| Shared mistake | **PASS (2,048 outputs)** | −81.2 dBFS | **−16.8 dBFS** |

The wrong design passes the bit-exact test perfectly. Its output is the **mirror image** of the correct one: the 5.0 MHz input, which the specification places at +0.2 MHz, appears at −0.2 MHz. In a receiver that would show the spectrum reversed, and any modulation that depends on the direction of rotation would decode wrongly.

### What catches it

One check, written from the **specification** rather than from the model, catches it immediately: *a real input tone at 5.0 MHz, with the LO at 4.8 MHz, must appear at +0.2 MHz.* In code: `level(z, +0.2/1.25) > level(z, -0.2/1.25) + 60`. It knows nothing about integers, rounding or the RTL's structure; it states what the design is for.

### What does not catch it well: a sample-by-sample float reference

A second idea is an independent floating-point reference written from the specification (multiply by an ideal e^{−j2πf\_LO n}, low-pass filter, decimate by 16) and an SQNR against it. It does separate the two cases, but poorly:

|  | SQNR against an independent float reference |
| --- | --- |
| Correct design | 10.9 dB |
| Shared mistake | −3.0 dB |

10.9 dB for a **correct** design looks like a failure. The reason is that the independent reference uses its own low-pass filter (a 255-tap `firwin`), whose passband ripple, phase and treatment of the two interferers differ from the CIC and the compensating FIR. A sample-by-sample comparison measures those legitimate differences too. An independent reference is useful, but it must be compared at the level of the specification, through properties such as tone positions, levels, passband flatness and rejection, not sample by sample. (Section 12.4's 79.5 dB figure is different: its reference shares the DDC's own filters and NCO table on purpose, to isolate the fixed-point arithmetic.)

## Functional coverage, with cocotb

### A passing test can test nothing

A test that passes says that nothing went wrong **in the situations it created**. Functional coverage measures which situations those were: you name the cases that matter ("the buffer is full", "the output stalls for several cycles") and count how often each occurs during the test.

### cocotb

**cocotb** writes testbenches in Python instead of SystemVerilog: the simulator (Icarus here) runs the design, and Python coroutines drive its inputs and read its outputs, clock edge by clock edge. It installs with `pip install cocotb` (version 2.1.0 was used) and needs no SystemVerilog testbench at all, which also sidesteps the testbench features Icarus lacks (Appendix A). Its value for this course is that the checking and coverage code can use any Python, including the models and `measure.py`.

A cocotb test of the Part 13 skid buffer, with a scoreboard and seven coverage bins (abridged):

```python
BINS = ["empty (0 words inside)", "one word inside", "two words inside (skid used)",
        "input and output transfer in the same cycle", "source stalled (s_tvalid, !s_tready)",
        "output stalled 4+ cycles in a row", "tlast word held while stalled"]

async def run(dut, ready_pct, n=5000, seed=1):
    ...
    while got < n:
        await FallingEdge(dut.clk)                      # drive inputs between edges
        ...
        dut.m_tready.value = int(random.random() * 100 < ready_pct)
        await ReadOnly()                                # sample everything just before the edge
        sv, sr = int(dut.s_tvalid.value), int(dut.s_tready.value)
        mv, mr = int(dut.m_tvalid.value), int(dut.m_tready.value)
        s_xfer, m_xfer = sv and sr, mv and mr
        # coverage
        hits[BINS[min(inside, 2)]] += 1
        if s_xfer and m_xfer: hits[BINS[3]] += 1
        if sv and not sr:     hits[BINS[4]] += 1
        ...
        # scoreboard
        if m_xfer:
            assert int(dut.m_tdata.value) == got & 0xFFFF, f"word {got}: got {int(dut.m_tdata.value)}"
            got += 1
        ...

@cocotb.test()
async def always_ready(dut):
    """The output is always ready: passes, but leaves most of the design unexercised."""
    missing = await run(dut, ready_pct=100)

@cocotb.test()
async def backpressure(dut):
    """Random backpressure: must pass AND reach every coverage bin."""
    missing = await run(dut, ready_pct=50)
    assert not missing, f"coverage holes: {missing}"
```

A four-line runner builds and runs it: `get_runner("icarus")`, `build(sources=["axis_skid.sv"], hdl_toplevel="axis_skid", build_args=["-g2012"])`, `test(hdl_toplevel="axis_skid", test_module="test_axis_skid")`.

### What coverage showed

| Coverage bin | Output always ready | 50% backpressure |
| --- | --- | --- |
| Empty | hit | hit |
| One word inside | hit | hit |
| **Two words inside (skid register used)** | **never** | hit |
| Transfer in and out in the same cycle | hit | hit |
| **Source stalled** | **never** | hit |
| **Output stalled 4+ cycles** | **never** | hit |
| **`tlast` word held while stalled** | **never** | hit |
| **Result** | PASS, **3 of 7 bins** | PASS, **7 of 7 bins** |

Both tests pass on the correct design, with 5,000 words each in order. But the always-ready test never once uses the skid register, the only non-trivial part of the design. Run against the broken skid buffer of Part 13 (`s_tready` always 1), the difference becomes concrete:

| Test | Correct design | Broken design |
| --- | --- | --- |
| `always_ready` | PASS | **PASS**: the bug is never exercised |
| `backpressure` | PASS | **FAIL**: `AssertionError: 3 words inside` |

So a test is only as good as its coverage. The rule: **define the coverage bins from the specification before running the test**, and treat a passing test with an unreached bin as incomplete, not as a pass. (Neither free simulator supports SystemVerilog's own `covergroup` construct: Icarus 12 reports a syntax error, Verilator 5.020 "Unsupported: covergroup". Counting in a Python testbench, as here, works with every simulator cocotb supports.)

## Rules for independent checking

Bit-exact comparison stays the backbone: it is the only check that finds every arithmetic difference, however small. Around it, add checks that do not share the model's assumptions:

1. **Specification properties.** For every design, write down what it is *for* as measurable statements, and test them with `measure.py`: where a tone must appear, how much a stopband must reject, how flat a passband must be, what an impulse must produce. They are independent of how the design computes. The course used some, such as the DDC's spectrum in section 12.4 and the filters' measured responses in Parts 7 and 8, but as reports rather than as pass/fail tests.
2. **Known answers.** Inputs whose output you can work out by hand: an impulse (the output is the coefficients), a constant (the output is the DC gain), an 8-point FFT computed on paper (Part 11 solutions, Exercise 2). A hand calculation shares nothing with the model.
3. **Identities.** Relations that must hold whatever the implementation: cos(θ + 90°) = −sin θ for an NCO with a phase offset (Part 9 solutions, Exercise 1), linearity (the response to a + b is the response to a plus the response to b, before rounding), time invariance (a delayed input gives a delayed output).
4. **References compared at the right level.** A floating-point reference built from the specification is compared through properties, with tolerances. A sample-by-sample comparison is meaningful only against a reference that shares the design's filters and differs only in arithmetic, as in section 12.4.
5. **A second author, where possible.** In industry the model and the RTL are often written by different engineers from the same written specification, precisely so that a misunderstanding has to happen twice to go unnoticed.

### Where to apply this in the course

| Part | A specification check worth adding |
| --- | --- |
| 5, 7, 8 | Measured RTL response against the design's response at a few frequencies, with a tolerance (Parts 5 and 7 measure this but do not test it) |
| 6 | The rounding error's mean and range against theory (Part 6 solutions, Exercise 2) |
| 9 | NCO frequency from the output's phase steps; SFDR at least 6 dB per address bit; cos/sin quadrature identity |
| 10 | Alias rejection measured with tones placed in the alias bands |
| 11 | Parseval: the energy of the bins equals N times the energy of the input (for the unscaled transform) |
| 12 | Tone position (+0.2 MHz, the check above), interferer rejection, mirror level |

For the measurements themselves, use `measure.py` everywhere, and quote every number with the function and parameters that produced it.
