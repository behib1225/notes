# Verilog & RTL for DSP — Solutions to Part 4

*Markdown export of the online document: https://claude.ai/artifact/UitnDaQeiSMz2mfThdkXnY. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the five exercises of Part 4. As the exercises say, the focus is the **workflow** (Python vectors, file-driven testbenches, independent checkers, regressions, lint and synthesis reports) applied to designs you already have. The "Check your understanding" answers are in Part 4 itself.

Each exercise lives in its own directory with its own `gen_vectors.py`, testbench, `check_results.py` and `run_test.sh`, all following the structure of Part 4, section 4.3. The designs come from the earlier parts and their solutions: `sat_add` (Part 1), `moving_avg8` (Part 2), and `seq_mult`, `mult_stream` (Part 3).

**How these solutions were checked.** Everything was run with Python 3 and NumPy, Icarus Verilog 12.0 (`-g2012 -Wall`), Verilator 5.020 (`--lint-only -Wall`) and Yosys 0.33. Every result below is copied from an actual run. The exercises themselves ask for deliberate breakages, and each one is reported with what the flow printed.

Two things went wrong while writing these solutions, and both are kept in, because they are exactly the kind of problem the flow is designed to catch: a testbench that violated the multiplier's `start` protocol (Exercise 2), and a Yosys option that silently emptied a report (Exercise 4).

## Exercise 1: the saturating adder, verified from Python

### The vector generator and golden model

```python
#!/usr/bin/env python3
"""gen_vectors.py -- exhaustive vectors and golden model for sat_add (W = 8).
Writes a.hex, b.hex (all 65,536 pairs) and y_expected.hex."""
import numpy as np

W = 8
LO, HI = -(1 << (W - 1)), (1 << (W - 1)) - 1

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def golden_sat_add(a, b):
    """The golden model: exact sum in int64, clipped to the W-bit range."""
    return np.clip(np.asarray(a, np.int64) + np.asarray(b, np.int64), LO, HI)

def all_pairs():
    v = np.arange(LO, HI + 1, dtype=np.int64)
    a, b = np.meshgrid(v, v, indexing="ij")          # every combination
    return a.ravel(), b.ravel()

if __name__ == "__main__":
    a, b = all_pairs()
    y = golden_sat_add(a, b)
    for name, data in (("a.hex", a), ("b.hex", b), ("y_expected.hex", y)):
        with open(name, "w") as f:
            f.write("\n".join(to_hex(data, W)) + "\n")
    print(f"wrote {len(a)} pairs; saturated results: {int(np.sum(y == HI))} at +{HI}, {int(np.sum(y == LO))} at {LO}")
```

`np.meshgrid(v, v)` builds two 256 × 256 grids holding every combination of `a` and `b`; `ravel()` flattens them into two lists of 65,536 values. Computing in `int64` means the sum can never overflow before `np.clip` saturates it.

### The testbench: combinational, so no clock

```systemverilog
`timescale 1ns/1ps
// tb_sat_add_files.sv -- file-driven, combinational: apply each pair, wait 1 ns, write y
module tb_sat_add_files;
  localparam int W = 8, N = 65536;
  logic signed [W-1:0] a, b, y;
  logic [W-1:0] a_mem [0:N-1], b_mem [0:N-1];
  int fd;
  sat_add #(.W(W)) dut (.*);
  initial begin
    $readmemh("a.hex", a_mem);
    $readmemh("b.hex", b_mem);
    fd = $fopen("y_actual.hex", "w");
    for (int i = 0; i < N; i++) begin
      a = a_mem[i];  b = b_mem[i];
      #1;
      assert (!$isunknown(y)) else $fatal(1, "unknown output for pair %0d", i);
      $fdisplay(fd, "%h", y);
    end
    $fclose(fd);
    $display("wrote %0d results", N);
    $finish;
  end
endmodule
```

The testbench contains no expected values at all: it only moves numbers between files and the design. The checker, `check_results.py`, is the Part 4 checker with the new model: it rebuilds all pairs with `all_pairs()`, computes `golden_sat_add`, reads `y_actual.hex` (with the two's-complement conversion of `from_hex`) and compares, reporting the first mismatch. `run_test.sh` runs the four steps (generate, compile, simulate, check) and takes the design file as an argument, so broken copies can be tested without editing anything.

### Results

```text
wrote 65536 pairs; saturated results: 8256 at +127, 8385 at -128
wrote 65536 results
PASS: all 65536 input pairs bit-exact (exhaustive)
```

This is the strongest result simulation can give: every possible input has been checked, so the design is proven correct for W = 8.

Of the 65,536 pairs, 16,384 actually saturate (8,128 above +127 and 8,256 below −128). The counts in the first line also include sums that are **exactly** +127 (128 pairs) or −128 (129 pairs) without saturating.

### Two deliberate breakages

| Breakage | Checker output |
| --- | --- |
| Wrap instead of saturate (`assign y = sum[W-1:0];`) | `FAIL: 16384 mismatches; first: -128 + -128 -> rtl 0, ref -128` |
| Saturate at the wrong value (MAX = 126 instead of 127) | `FAIL: 8128 mismatches; first: 1 + 127 -> rtl 126, ref 127` |

The **number** of mismatches is a diagnosis in itself: 16,384 is exactly the number of saturating pairs, so the wrap bug affects every one of them and nothing else. 8,128 is exactly the number of **positive** saturations, so the second bug lies only on the positive side. Notice also that the wrong-MAX bug is invisible to the 128 pairs whose sum is exactly 127, because they never saturate: only a test that drives the sum beyond the limit finds it. With random testing alone, a test would need to land in that region by chance; exhaustive testing makes the question disappear.

## Exercise 2: the sequential multiplier, file-driven

### The vectors

```python
#!/usr/bin/env python3
"""gen_vectors.py -- operand pairs and products for seq_mult / mult_stream (W = 8)."""
import argparse
import numpy as np

W = 8

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def golden(a, b):
    return np.asarray(a, np.int64) * np.asarray(b, np.int64)     # unsigned 8 x 8 -> 16 bits

def vectors(n, seed):
    rng = np.random.default_rng(seed)
    a = rng.integers(0, 1 << W, size=n)
    b = rng.integers(0, 1 << W, size=n)
    corners = [0, 1, (1 << W) - 1]                                 # 0, 1 and 255 in every combination
    ca, cb = np.meshgrid(corners, corners, indexing="ij")
    a[:9], b[:9] = ca.ravel(), cb.ravel()
    return a, b

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=2000)   # at least 9 (the corner pairs)
    p.add_argument("--seed", type=int, default=1)
    args = p.parse_args()
    a, b = vectors(args.n, args.seed)
    open("ab.hex", "w").write("\n".join(f"{x:02x}{y:02x}" for x, y in zip(a, b)) + "\n")
    open("p_expected.hex", "w").write("\n".join(to_hex(golden(a, b), 2 * W)) + "\n")
    print(f"{args.n} pairs, seed {args.seed}")
```

Each line of `ab.hex` packs both operands into one 16-bit word (`a` in the high byte), which the testbench unpacks with `{a, b} = ab_mem[i]`. The checker regenerates the same vectors from the seed, so it never reads `ab.hex` at all: an independent path to the expected answers.

### The testbench, with a latency assertion

```systemverilog
`timescale 1ns/1ps
// tb_seq_mult_files.sv -- file-driven test of seq_mult: start, wait for done, record the product
module tb_seq_mult_files;
  localparam int W = 8, MAX_N = 100_000, LATENCY = 9;
  logic clk = 1'b0, rst, start, busy, done;
  logic [W-1:0]   a, b;
  logic [2*W-1:0] product;
  logic [2*W-1:0] ab_mem [0:MAX_N-1];
  int n = 2000, seed = 1, fd, cycles;
  seq_mult #(.W(W)) dut (.*);
  always #5 clk = ~clk;
  initial begin #100_000_000; $fatal(1, "TIMEOUT"); end
  initial begin
    void'($value$plusargs("N=%d", n));
    void'($value$plusargs("SEED=%d", seed));
    void'($urandom(seed));
    $readmemh("ab.hex", ab_mem, 0, n - 1);
    fd = $fopen("p_actual.hex", "w");
    rst = 1'b1; start = 1'b0; a = '0; b = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    for (int i = 0; i < n; i++) begin
      repeat ($urandom_range(0, 3)) @(negedge clk);          // random idle time between products
      while (busy) @(negedge clk);                           // start is only seen in S_IDLE
      {a, b} = ab_mem[i]; start = 1'b1;
      @(negedge clk); start = 1'b0; a = 'x; b = 'x;          // operands are captured at start
      cycles = 1;
      while (!done) begin @(negedge clk); cycles++; end
      assert (cycles == LATENCY)
        else $fatal(1, "product %0d: done came %0d cycles after start, expected %0d", i, cycles, LATENCY);
      $fdisplay(fd, "%h", product);
    end
    $fclose(fd);
    $display("wrote %0d products; done always %0d cycles after start", n, LATENCY);
    $finish;
  end
endmodule
```

The assertion fires with `$fatal`, so a latency error stops the run and makes `run_test.sh` fail. To check it can fire, the expected latency was temporarily set to 8: `FATAL: product 0: done came 9 cycles after start, expected 8`.

### A protocol bug in the first testbench

The first version of this testbench had no `while (busy)` line, and it **timed out**. The cause: when the random gap was 0, it raised `start` in the very cycle it had seen `done`. At that moment `seq_mult`'s controller is still in `S_DONE`, which moves to `S_IDLE` without looking at `start`; one cycle later `start` was already low again, so the request was lost and the testbench waited forever for a `done` that would never come. The watchdog caught it.

The design was right; the testbench broke the interface rule that `start` is only accepted when the block is idle. The Part 3 testbench never hit this because its `multiply` task always waits one cycle first. The robust fix is to test the condition directly: wait until `busy` is low. This is a good illustration of why handshake interfaces (section 3.6 of Part 3) are preferred: with valid/ready, holding a request until it is accepted makes it impossible to lose one.

### Results

```text
PASS: 2000 products bit-exact
all 10 seeds passed (seq)
```

`regress.sh seq` runs `run_test.sh` for seeds 1 to 10 with 2,000 products each, stopping at the first failure: 20,000 products, all correct, all with exactly 9 cycles of latency. With the carry deliberately dropped in the datapath (`{A, Q} <= {1'b0, sum[W-1:0], Q[W-1:1]}`), the checker reported `FAIL: 2000 products, 658 wrong; first 255 x 255`, the first case whose sum produces a carry.

### `mult_stream` with the same vectors

The stream testbench offers each operand pair and **holds** it until `in_ready` is high at a clock edge, then moves on; a separate monitor writes every product marked by `out_valid`:

```systemverilog
  // source: offer each pair and HOLD it until it is accepted (valid/ready rule)
  while (sent < n) begin
    repeat ($urandom_range(0, 3)) @(negedge clk);
    in_valid = 1'b1; {a, b} = ab_mem[sent];
    do @(posedge clk); while (!in_ready);          // the transfer happens at this edge
    sent++;
    @(negedge clk); in_valid = 1'b0; a = 'x; b = 'x;
  end

  // sink: record every product marked valid, in order
  always @(negedge clk) if (!rst && out_valid) begin
    assert (!$isunknown(product)) else $fatal(1, "unknown product %0d", got);
    $fdisplay(fd, "%h", product);
    if (++got == n) begin $fclose(fd); $display("wrote %0d products", n); $finish; end
  end
```

Because the source waits for each transfer, the products come out in exactly the file's order, so the **same** `gen_vectors.py` and `check_results.py` work unchanged: `all 10 seeds passed (stream)`. Both `seq_mult` and `mult_stream` lint clean with their whole hierarchies.

## Exercise 3: moving average of 8, with a plot

### Checking the claim about NumPy's `>>`

The exercise asked you to check that NumPy's `>>` on signed integers rounds like the hardware's `>>>`. It does: both compute floor(v/8), rounding toward −∞, while Python's `int(v / 8)` rounds toward zero:

| v | `np.int64(v) >> 3` | floor(v/8) | `int(v/8)` (toward zero) |
| --- | --- | --- | --- |
| −1 | −1 | −1 | 0 |
| −7 | −1 | −1 | 0 |
| −8 | −1 | −1 | −1 |
| −9 | −2 | −2 | −1 |
| −15 | −2 | −2 | −1 |
| 7 | 0 | 0 | 0 |
| 15 | 1 | 1 | 1 |

So `>> 3` in the model matches the RTL exactly, while a model using `int(v / 8)` would disagree on every negative non-multiple of 8.

### The model and the test signal

```python
def golden(x):
    """Sum of the last 8 samples, then an arithmetic shift right by 3 (floor), like the RTL."""
    x = np.asarray(x, dtype=np.int64)
    return np.convolve(x, np.ones(8, dtype=np.int64))[: len(x)] >> 3

def signal(n, seed):
    """A slow sine wave plus white noise, within +-32,000."""
    rng = np.random.default_rng(seed)
    t = np.arange(n)
    s = 20000 * np.sin(2 * np.pi * t / 500) + rng.normal(0, 4000, n)
    return np.round(np.clip(s, -32000, 32000)).astype(np.int64)
```

The sine has a period of 500 samples, slow compared with the 8-sample average, so the filter passes it almost unchanged; the noise (standard deviation 4,000) changes from sample to sample, so averaging reduces it.

The testbench is `tb_moving_sum4_files.sv` from Part 4 with four changes: the module name, the DUT (`moving_avg8`), and the widths of `y` and of the expected-value memory (W bits instead of W + 2, since the average has the input's width). Its protocol assertion (`out_valid` one cycle after `in_valid`) and random input gaps are unchanged.

### Results

```text
PASS: 2000 outputs bit-exact
noise around the sine: input 4026, output 1422 (ratio 2.83)
saved moving_avg8.png
```

The checker also measured the noise: the standard deviation of the signal around the ideal sine, before and after the filter. It fell by a factor of **2.83**, which is √8. That is exactly the prediction Part 5 derives: averaging N samples of independent noise divides its standard deviation by √N (a reduction of 10 log₁₀ 8 = 9.03 dB in power).

### The plot

> **Figure:** The same data as moving\_avg8.png, drawn from the RTL's y\_actual.hex (shown in the [online version](https://claude.ai/artifact/UitnDaQeiSMz2mfThdkXnY))

The plotting code, at the end of `check_results.py`, uses Matplotlib's non-interactive backend so it can run without a display:

```python
import matplotlib
matplotlib.use("Agg")                        # write a file; no window needed
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(9, 4))
ax.plot(x[:600], lw=0.8, alpha=0.6, label="input x (sine + noise)")
ax.plot(y[:600], lw=1.6, label="RTL output y (moving average of 8)")
ax.set_xlabel("sample"); ax.set_ylabel("value"); ax.legend(); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig("moving_avg8.png", dpi=120)
```

The output is visibly smoother, and it lags the input by about **3.5 samples**: the average of x\[n\] to x\[n−7\] is centered on x\[n−3.5\]. Part 5 explains this as the filter's linear phase. The checker's noise measurement compares the output against the sine shifted by exactly that 3.5-sample delay.

## Exercise 4: a lint-and-synthesis report for Parts 1 to 3

### The script

`synth_report.sh` keeps one list of designs, each as `top|files` (the whole hierarchy), and prints a Markdown table:

```bash
#!/bin/bash
# synth_report.sh -- lint + synthesis summary for every design of Parts 1 to 3.
# Usage: ./synth_report.sh > report.md      (run from the directory containing src/)
cd src || exit 1
DESIGNS=(
  "half_adder|half_adder.sv"            "full_adder|full_adder.sv"
  "full_adder_ha|full_adder_ha.sv half_adder.sv"  "mux4|mux4.sv"
  "rca|rca.sv full_adder.sv"            "rca|adder_beh.sv"
  # ... one entry per design, 34 in all ...
  "blink_ctrl|blink_ctrl.sv"
)
echo "| Design | Files | Lint | LUTs | CARRY4 | FFs | DSP | ltp (generic) |"
echo "| --- | --- | --- | --- | --- | --- | --- | --- |"
for d in "${DESIGNS[@]}"; do
  top=${d%%|*}; files=${d#*|}
  nw=$(verilator --lint-only -Wall --top-module "$top" $files 2>&1 | grep -cE "^%(Warning|Error)-")
  lint=$([ "$nw" -eq 0 ] && echo clean || echo "$nw warnings")
  stat=$(yosys -q -p "read_verilog -sv $files; synth_xilinx -family xc7 -flatten -top $top; tee -q -o /dev/stdout stat" 2>&1)
  luts=$(echo "$stat" | awk '/^ +LUT[1-6] /{s+=$2} END{print s+0}')
  carry=$(echo "$stat" | awk '/^ +CARRY4 /{s+=$2} END{print s+0}')
  ffs=$(echo "$stat" | awk '/^ +FD[A-Z]* /{s+=$2} END{print s+0}')
  dsp=$(echo "$stat" | awk '/^ +DSP48E1 /{s+=$2} END{print s+0}')
  ltp=$(yosys -p "read_verilog -sv $files; synth -flatten -top $top; ltp -noff" 2>&1 | sed -n 's/.*(length=\([0-9]*\)).*/\1/p' | tail -1)
  echo "| $top | $files | $lint | $luts | $carry | $ffs | $dsp | ${ltp:-?} |"
done
```

How it works: `${d%%|*}` and `${d#*|}` split each entry at the `|`. The `awk` lines add up all LUT sizes (LUT1 to LUT6) and all flip-flop types (FDRE, FDSE, …) from Yosys's `stat` output. The `-p` string ends with `tee -q -o /dev/stdout stat`, which sends the statistics, and only them, to standard output.

**A bug in the first version of the script.** It ran `yosys -q -p "...; stat"`, and every resource count in the table came out as **0**. The `-q` option suppresses all of Yosys's log output, including the result of `stat`, so `awk` found nothing to count. The script ran without error and produced a plausible-looking table full of zeros. `tee -q -o /dev/stdout stat` fixes it. The lesson: **a report script needs its own sanity check**. A table where a 16-bit register has 0 flip-flops is obviously wrong, but only if you look.

### Lint results

All 34 designs are lint-clean with their whole hierarchies, after two kinds of change:

- **One real fix.** `adder_beh.sv` (the behavioral adder of Part 1) had `WIDTHEXPAND` on `a + b + cin`: the 1-bit `cin` is widened silently. The fix makes every operand's width explicit: `assign {cout, sum} = {1'b0, a} + {1'b0, b} + (N+1)'(cin);`. It still passes the Part 1 testbench (`PASS: 1004 cases correct`).
- **Two local waivers** of `DECLFILENAME` (file name differs from module name), both deliberate: `adder_beh.sv` defines a module called `rca`, as a drop-in replacement for the structural one, and `detect0110.sv` holds three modules. The waiver is a comment on the offending lines, with a comment saying why:

```systemverilog
// It deliberately has the same module name as rca.sv, so the file name cannot match:
/* verilator lint_off DECLFILENAME */
module rca #(parameter int N = 8) (
/* verilator lint_on DECLFILENAME */
```

### The table

| Design | Part | LUTs | CARRY4 | FFs | DSP | ltp | As expected? |
| --- | --- | --- | --- | --- | --- | --- | --- |
| half\_adder | 1 | 2 | 0 | 0 | 0 | 1 | Yes: one LUT for the XOR, one for the AND |
| full\_adder | 1 | 2 | 0 | 0 | 0 | 3 | Yes: one LUT3 each for sum and carry |
| full\_adder\_ha | 1 | 2 | 0 | 0 | 0 | 3 | Yes: same function as full\_adder, so the same 2 LUTs after flattening |
| mux4 | 1 | 16 | 0 | 0 | 0 | 5 | Better: three 8-bit outputs (24 bit-muxes), but Yosys shared the identical logic |
| rca, structural | 1 | 16 | 0 | 0 | 0 | 24 | **No**: see surprise 1 |
| rca, behavioral | 1 | 8 | 3 | 0 | 0 | 12 | Yes: an 8-bit adder on the carry chain |
| dff | 2 | 0 | 0 | 1 | 0 | 0 | Yes |
| register | 2 | 0 | 0 | 8 | 0 | 0 | Yes: one flip-flop per bit and no extra logic |
| mod\_counter | 2 | 5 | 1 | 4 | 0 | 4 | Yes: 4-bit counter for M = 10 |
| tick\_gen | 2 | 3 | 0 | 2 | 0 | 2 | Yes: 2-bit counter for DIV = 4 |
| moving\_sum4 | 2 | 49 | 5 | 67 | 0 | 19 | Yes: 3 × 16 delay line + 18-bit output + valid = 67 FFs |
| detect1011\_moore | 3 | 5 | 0 | 5 | 0 | 3 | **More FFs than expected**: see surprise 2 |
| detect1011\_mealy | 3 | 5 | 0 | 4 | 0 | 3 | Same: one-hot |
| detect1011\_mealy\_reg | 3 | 5 | 0 | 5 | 0 | 3 | One more FF for the registered output |
| seq\_mult | 3 | 34 | 4 | 29 | 0 | 11 | Yes: A, B, Q (24 bits), the step counter and the state |
| mult\_stream | 3 | 34 | 4 | 29 | 0 | 11 | Yes: the wrapper adds only wiring |
| decoder2to4 | sol. 1 | 4 | 0 | 0 | 0 | 2 | Yes: the two versions merged into one set of 4 LUTs |
| prio\_enc4 | sol. 1 | 3 | 0 | 0 | 0 | 2 | Yes |
| sat\_add | sol. 1 | 15 | 3 | 0 | 0 | 12 | Yes: a 9-bit add on the carry chain + saturation multiplexers |
| abs\_sat | sol. 1 | 9 | 2 | 0 | 0 | 7 | Yes: a negation on the carry chain + selection |
| addsub | sol. 1 | 19 | 0 | 0 | 0 | 23 | **No carry chain**, as surprise 1 |
| edge\_detect | sol. 2 | 1 | 0 | 3 | 0 | 1 | Yes: 3 FFs and one AND-NOT |
| updown\_counter | sol. 2 | 15 | 2 | 8 | 0 | 11 | Yes |
| delay\_line | sol. 2 | 0 | 0 | 128 | 0 | 0 | Yes: 8 × 16 FFs (see surprise 3) |
| lfsr16 | sol. 2 | 1 | 0 | 16 | 0 | 3 | Yes: one LUT4 for the 4-input XOR |
| moving\_avg8 | sol. 2 | 167 | 5 | 129 | 0 | 25 | Larger than expected: see surprise 4 |
| accum | sol. 2 | 12 | 3 | 12 | 0 | 12 | Yes: a 12-bit accumulator |
| detect0110\_moore | sol. 3 | 5 | 0 | 5 | 0 | 3 | One-hot (5 states) |
| detect0110\_mealy | sol. 3 | 4 | 0 | 3 | 0 | 2 | One-hot, then one FF optimized away |
| detect0110\_mealy\_reg | sol. 3 | 4 | 0 | 4 | 0 | 2 | As above, plus the output FF |
| traffic\_light | sol. 3 | 17 | 1 | 11 | 0 | 9 | Yes |
| uart\_tx | sol. 3 | 16 | 1 | 15 | 0 | 4 | Yes: shift register, bit counter, tx and state, minus any bits Yosys found constant |
| seq\_div | sol. 3 | 36 | 4 | 31 | 0 | 11 | Yes: R, Q, D (24 bits), the step counter, the state and the flag |
| blink\_ctrl | sol. 3 | 3 | 0 | 3 | 0 | 3 | One-hot for 3 states |

No design uses a DSP block: nothing in Parts 1 to 3 multiplies with the `*` operator (the multiplier is built from an adder).

### The surprises, explained

**1. The structural adders do not use the carry chain.** The ripple-carry adder built from `full_adder` instances uses 16 LUTs, no `CARRY4` and has a logic depth of 24; the behavioral `a + b` uses 8 LUTs and 3 `CARRY4` with depth 12. The synthesizer recognizes a `+` operator and maps it to the FPGA's dedicated carry logic, but it does not recognize a hand-built chain of XOR and AND gates as an adder, so it builds exactly the gates you wrote, in LUTs. `addsub` (also structural) shows the same thing. **Write arithmetic with operators**; write structure only when you need access to internal signals, as `addsub` does for its overflow flag.

**2. FSMs get more flip-flops than the `enum` has bits.** Yosys's FSM pass extracts each state machine and re-encodes it. Its log says so: `mapping auto encoding to 'one-hot' for this FSM`. One-hot uses one flip-flop per state, which on an FPGA usually makes the next-state logic smaller and faster (section 3.4 of Part 3). For `detect0110_mealy`, the log shows the 4-state machine re-encoded with 4 bits, and a later optimization pass then removed one of them, leaving 3 flip-flops.

**3. The delay line is 128 flip-flops, not shift-register LUTs.** FPGAs can implement a shift register in a LUT (Xilinx `SRL16E`), but only when the stages have **no reset**. The delay line resets every stage (so that the model and the hardware start from zero), which forces real flip-flops. Part 7 returns to this trade-off.

**4. The 8-input sum is mostly LUTs.** `moving_avg8` needs 167 LUTs but only 5 `CARRY4`. Yosys turned the eight-operand sum into a tree of full-adder cells implemented in LUTs (mostly LUT3, LUT5 and LUT6 in the report), followed by a single 19-bit carry-chain adder for the final sum (5 `CARRY4`). That is a sensible structure, but it is much larger than the single adder the RTL might suggest, which is exactly why Exercise 5 looks at adder trees.

## Exercise 5: an adder tree, pipelined

### The three versions

All three share the same interface, so one testbench verifies them. The output is W + 3 = 19 bits, enough for the sum of 8 values.

```systemverilog
`timescale 1ns/1ps
// moving_sum8.sv -- y[n] = x[n] + x[n-1] + ... + x[n-7], three implementations.

// ---------- 1. one sum of 8 values in a single cycle (latency 1) ----------
module moving_sum8 #(
  parameter int W = 16
) (
  input  logic                clk, rst, in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W+2:0] y              // W+3 bits: 8 values cannot overflow
);
  logic signed [W-1:0] d [1:7];
  logic signed [W+2:0] sum;
  always_comb begin
    sum = (W+3)'(x);
    for (int k = 1; k <= 7; k++) sum += (W+3)'(d[k]);   // a chain of 7 additions as written
  end
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      y <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        y <= sum;
      end
    end
  end
endmodule

// The next two modules share this file on purpose:
/* verilator lint_off DECLFILENAME */
// ---------- 2. balanced adder tree, still one cycle (latency 1) ----------
module moving_sum8_tree #(
  parameter int W = 16
) (
  input  logic                clk, rst, in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W+2:0] y
);
  logic signed [W-1:0] t [0:7];              // t[0] = x[n], t[k] = x[n-k]
  logic signed [W-1:0] d [1:7];
  logic signed [W:0]   l1 [0:3];             // level 1: 4 sums of 2 values, W+1 bits
  logic signed [W+1:0] l2 [0:1];             // level 2: 2 sums,             W+2 bits
  logic signed [W+2:0] l3;                   // level 3: 1 sum,              W+3 bits

  assign t[0] = x;
  for (genvar k = 1; k <= 7; k++) begin : g_t
    assign t[k] = d[k];
  end
  for (genvar i = 0; i < 4; i++) begin : g_l1
    assign l1[i] = (W+1)'(t[2*i]) + (W+1)'(t[2*i+1]);
  end
  for (genvar i = 0; i < 2; i++) begin : g_l2
    assign l2[i] = (W+2)'(l1[2*i]) + (W+2)'(l1[2*i+1]);
  end
  assign l3 = (W+3)'(l2[0]) + (W+3)'(l2[1]);

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      y <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        y <= l3;
      end
    end
  end
endmodule

// ---------- 3. the tree with a register after each level (latency 3) ----------
module moving_sum8_pipe #(
  parameter int W = 16
) (
  input  logic                clk, rst, in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W+2:0] y
);
  logic signed [W-1:0] t [0:7];
  logic signed [W-1:0] d [1:7];
  logic signed [W:0]   l1 [0:3];              // registered after level 1
  logic signed [W+1:0] l2 [0:1];              // registered after level 2
  logic                v1, v2;                // valid bits travelling with the data

  assign t[0] = x;
  for (genvar k = 1; k <= 7; k++) begin : g_t
    assign t[k] = d[k];
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      for (int i = 0; i < 4; i++) l1[i] <= '0;
      l2[0] <= '0;  l2[1] <= '0;  y <= '0;
      {v1, v2, out_valid} <= '0;
    end else begin
      // level 1 (and the delay line), on each input sample
      v1 <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        for (int i = 0; i < 4; i++) l1[i] <= (W+1)'(t[2*i]) + (W+1)'(t[2*i+1]);
      end
      // level 2
      v2 <= v1;
      if (v1) for (int i = 0; i < 2; i++) l2[i] <= (W+2)'(l1[2*i]) + (W+2)'(l1[2*i+1]);
      // level 3
      out_valid <= v2;
      if (v2) y <= (W+3)'(l2[0]) + (W+3)'(l2[1]);
    end
  end
endmodule
```

In the pipelined version, each level's registers load only when the valid bit of the level before is 1, and the valid bits shift along with the data, exactly as in `moving_sum4_pipe` (Part 4, section 4.7). That keeps the result correct when `in_valid` has gaps.

### Widths at each level

Every addition of two values can produce a result one bit wider than its operands, so the width grows by one bit per level:

| Level | Adders | Operand width | Result width |
| --- | --- | --- | --- |
| 1 | 4 | 16 | **17** |
| 2 | 2 | 17 | **18** |
| 3 | 1 | 18 | **19** |

The tree reaches the final W + log₂ 8 = 19 bits without ever using a wider adder than needed. The single chain of version 1 has to use 19-bit adders throughout (or carefully growing ones).

### Verification

The testbench is Part 4's `tb_pipe.sv` (the one with the `DUT` macro and the `+LAT` plusarg), with the output and expected-value widths changed from W + 2 to W + 3. The run script passes both:

```sh
iverilog -g2012 -Wall -DDUT="$DUT" -o sim_$DUT moving_sum8.sv tb_moving_sum8_files.sv
vvp -n sim_$DUT +N="$N" +SEED="$SEED" +LAT="$LAT"
```

The golden model is `np.convolve(x, np.ones(8, dtype=np.int64))[: len(x)]`, with full-scale runs in the stimulus to reach the largest sums. Each version passed 5,000 samples on four seeds (`PASS: 5000 outputs bit-exact`), with `+LAT=1`, `1` and `3`. Telling the testbench the wrong latency for the pipelined version (`+LAT=2`) made the protocol assertion fire at once: `ERROR: out_valid=0 but in_valid 2 cycles earlier was 1`. All three are lint-clean.

### Comparison

| Version | Latency | LUTs | CARRY4 | Flip-flops | ltp (generic) |
| --- | --- | --- | --- | --- | --- |
| 1. chain | 1 | 167 | 5 | 132 | 25 |
| 2. tree, one cycle | 1 | 167 | 5 | 132 | 25 |
| 3. tree, pipelined | 3 | 116 | 35 | 238 | 14 |

The flip-flop counts check out by hand: 7 × 16 delay-line bits + 19 output bits + 1 valid bit = 132; the pipeline adds 4 × 17 + 2 × 18 level registers and 2 more valid bits, 106 in all, giving 238.

### Which is best?

**Versions 1 and 2 synthesized to identical hardware.** That is the most instructive result here. Yosys collects the whole eight-operand sum into one multi-input addition and builds its own structure for it, however you wrote it, so rewriting a single-cycle sum as a tree changes nothing. Write whichever is clearer.

**Version 3 is different, because the synthesizer leaves your registers where you put them.** (Some tools can move registers to balance stages, an optimization called retiming, but Yosys does not do it in this flow.) The pipeline registers split the logic into three short stages, cutting the longest path from 25 to 14 levels, so it can run at a much higher clock frequency. Each stage is a plain two-input adder, which maps to the carry chain (35 `CARRY4`), so it even uses fewer LUTs. The costs are 106 more flip-flops and 2 more cycles of latency.

So: use version 1 (or 2) when the clock is slow enough for the long path, because it is smaller and has the least latency; use version 3 when the filter must run at a high clock rate. In DSP that is the usual case, and one sample of latency more or less rarely matters.

---

That completes Part 4. Send me your scripts, tables and plots if you would like them reviewed.
