# Verilog & RTL for DSP — Solutions to Part 11

*Markdown export of the online document: https://claude.ai/artifact/RddXrDPewzAofqjsJATZnD. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the five exercises of Part 11. Try each one first; the "Check your understanding" answers are in Part 11 itself.

**How these solutions were checked.** Everything was run with Python 3, NumPy and SciPy, Icarus Verilog 12.0 (`-g2012 -Wall`), Verilator 5.020 (`--lint-only -Wall`) and Yosys 0.33. Every RTL design is bit-exact against a Python model, block by block, and every number below is copied from an actual run. The designs build on `fft64.sv`, `fft_model.py`, `tb_fft.sv` and `check_fft.py` from Part 11.

Two results are worth knowing before you start:

- **Exercise 3:** the threshold "any value above ½" (the exercise's original wording, since clarified in Part 11) is not safe if it is applied to the real and imaginary parts separately (the cheap way to build it in hardware): an unscaled butterfly can then overflow. The solution derives the safe threshold.
- **Exercise 4:** moving the working memory into block RAM is the single biggest improvement in the whole FFT: for N = 1,024 it replaces about 97,000 LUTs and 33,000 flip-flops with **one** RAMB36E1, at the cost of 1.7 times the cycles.

## Exercise 1: a spectrum analyzer in Python

### The code

```python
import numpy as np
from fft_model import fft_iter

def spectrum(x, fs=1.0, window="rect", full_scale=1.0):
    """Return (frequencies, magnitude in dBFS) for a real signal x (length a power of two).
    0 dBFS = a sine of amplitude full_scale exactly on a bin."""
    x = np.asarray(x, dtype=float); N = len(x)
    w = {"rect": np.ones(N),
         "hann": np.hanning(N + 1)[:-1],                                  # periodic Hann
         "blackmanharris": None}[window]
    if w is None:
        n = np.arange(N); a = [0.35875, 0.48829, 0.14128, 0.01168]
        w = a[0] - a[1]*np.cos(2*np.pi*n/N) + a[2]*np.cos(4*np.pi*n/N) - a[3]*np.cos(6*np.pi*n/N)
    cg = np.mean(w)                                                       # coherent gain
    X = fft_iter(x * w)[: N // 2 + 1]
    mag = 2 * np.abs(X) / (N * cg * full_scale)                           # amplitude of each sine
    mag[0] /= 2                                                           # DC has no mirror
    return np.arange(N // 2 + 1) * fs / N, 20 * np.log10(mag + 1e-300)
```

`fft_iter` is the radix-2 FFT of section 11.2; on 1,024 random samples it agrees with `np.fft.fft` to 4.5 × 10⁻¹⁴. Two scale factors turn |X\[k\]| into the amplitude of a sine:

- **2/N**: a real sine of amplitude A on bin k produces A·N/2 in bin k and the same in the mirror bin N − k. (DC has no mirror, hence `mag[0] /= 2`.)
- **1/cg, the coherent gain**: a window multiplies the samples by values below 1, so a sine's bin is reduced by the window's mean value, Σw/N.

### Calibration

A full-scale sine exactly on bin 37 of a 1,024-point block reads **0.0000 dBFS** with all three windows after the correction:

| Window | Coherent gain (mean of w) | Correction | On a bin | Halfway between bins |
| --- | --- | --- | --- | --- |
| Rectangular | 1.000 | 0 dB | 0.00 dBFS | −3.87 dBFS |
| Hann | 0.500 | **+6.02 dB** | 0.00 dBFS | −1.42 dBFS |
| Blackman–Harris | 0.35875 | **+8.90 dB** | 0.00 dBFS | −0.83 dBFS |

The last column is the **scalloping loss**: a sine halfway between two bins reads low, because its energy splits between them. Wider windows lose less (and leak far less, as section 11.1 showed), which is why measurement work favors them.

### The NCO's SFDR

The Part 9 NCO (10-bit table, FCW `0x0B3A5C1F`, 16,384 samples), analyzed with this function and the Blackman–Harris window, excluding ±8 bins around the carrier and the lowest 4 bins:

```text
NCO (A=10, FCW 0x0B3A5C1F, 16384 samples): carrier -0.55 dBFS at bin 719; SFDR 60.4 dB
```

The **60.4 dB** is exactly Part 9's figure. The carrier reads −0.55 dBFS rather than 0 because this FCW puts it at bin 718.6 (0.043859 × 16,384), not on a bin: that is the scalloping loss of the table above, for a sine 0.4 bin from the nearest bin. SFDR is a ratio of two levels in the same spectrum, so the calibration does not affect it; but the dBFS scale makes the carrier and the spurs readable as absolute levels (the largest spur is at about −61 dBFS).

## Exercise 2: a parameterized FFT

### What had to change

Very little. `fft64.sv` was already written in terms of `N`, `L = $clog2(N)` and widths derived from them, so `fft_n.sv` is the same file with:

- the module renamed, and the comments made general;
- the twiddle file names as **parameters**, so each size can load its own table:

```systemverilog
module fft_n #(
  parameter int N = 64, W = 16,
  parameter     TWR = "tw_re.hex", TWI = "tw_im.hex"        // twiddle files generated for this N
) (
  ...
  initial begin
    $readmemh(TWR, tw_re);
    $readmemh(TWI, tw_im);
  end
```

The parameters are untyped on purpose: Yosys 0.33 rejects `parameter string` (Part 9 solutions). The model `fft_fixed(xr, xi, N)` and `twiddles(N)` already accepted any N. The testbench takes N from a macro (`-DNPT=256`) and expects N bins per block. A small runner writes the N/2-entry twiddle files, generates test blocks (a complex tone, two mixed tones, an impulse and random data) scaled to the block size, simulates and checks each block bit-exactly.

### Verification

| N | Result (8 blocks) | Max error vs `np.fft.fft(x)/N` |
| --- | --- | --- |
| 8 | **PASS** bit-exact | 0.69 LSB |
| 64 | **PASS** bit-exact | 1.55 LSB |
| 256 | **PASS** bit-exact | 2.59 LSB |
| 1,024 | **PASS** bit-exact | 1.59 LSB |

The design is lint-clean at all four sizes. (The error does not grow steadily with N because it depends on the test signals as well as on the number of stages.)

### One 8-point block, by hand

Input x = (0.5, 0.5, 0, 0, 0, 0, 0, 0), that is (16,384, 16,384, 0, …) in Q1.15. The 8-point twiddles are W⁰ = 32,767, W¹ = (23,170, −23,170), W² = (0, −32,767), W³ = (−23,170, −23,170).

1. **Bit-reversed load**: x\[1\] goes to address rev(1) = 4, so the memory holds (16,384, 0, 0, 0, 16,384, 0, 0, 0).
2. **Stage 0** (pairs 0–1, 2–3, 4–5, 6–7, twiddle W⁰): (a ± b)/2 with b = 0 gives (8,192, 8,192, 0, 0, 8,192, 8,192, 0, 0).
3. **Stage 1** (pairs 0–2, 1–3, 4–6, 5–7, twiddles W⁰ and W²): every pair has b = 0 again, so all eight values become 8,192/2 = **4,096**.
4. **Stage 2** (pairs k and k + 4, twiddle Wᵏ): for bin 1, a = b = 4,096 and b·W¹ = 4,096 × (0.7071 − 0.7071j) = 2,896.2 − 2,896.2j, so (a + b·W¹)/2 = 3,496.1 − 1,448.1j, which rounds to **3,496 − 1,448j**.

The RTL's output for this block:

| Bin | 0 | 1 | 2 | 3 | 4 | 5 | 6 | 7 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| RTL | 4,096 | 3,496 − 1,448j | 2,048 − 2,048j | 600 − 1,448j | 0 | 600 + 1,448j | 2,048 + 2,048j | 3,496 + 1,448j |
| Ideal DFT/8 | 4,096 | 3,496.15 − 1,448.15j | 2,048 − 2,048j | 599.85 − 1,448.15j | 0 | 599.85 + 1,448.15j | 2,048 + 2,048j | 3,496.15 + 1,448.15j |

It matches the hand calculation, the model (bit-exactly) and the ideal DFT to within rounding. The ideal values check the arithmetic: X\[k\]/8 = 0.5(1 + e^{−jπk/4})/8 × 32,768.

### How it grows with N

| N | Cycles per transform | Working memory | DSP48E1 | LUTs | Flip-flops |
| --- | --- | --- | --- | --- | --- |
| 8 | 28 | 256 bits | 4 | 862 | 299 |
| 64 | 320 | 2,048 bits | 4 | 5,532 | 2,098 |
| 256 | 1,536 | 8,192 bits | 4 | 20,202 | 8,246 |
| 1,024 | 7,168 | 32,768 bits | 4 | 96,810 | 32,827 |

- **Cycles**: N to load, (N/2)·log₂ N butterflies (one per clock), N to unload: growth as N log N.
- **Multipliers**: always 4, one butterfly unit, whatever N.
- **Flip-flops**: about 32 per point, because the memory, N words of 2 × 16 bits, is built from flip-flops.
- **LUTs**: they grow fastest, roughly 95 per point at N = 1,024. Every cycle the design reads two arbitrary addresses and writes two, so each of the four accesses needs an N-way multiplexer (the thousands of `MUXF7` and `MUXF8` cells in the reports) or an N-way write decoder.

At N = 1,024 the design no longer fits a small FPGA, though its arithmetic is only four multipliers. The memory structure, not the arithmetic, sets the cost of a large FFT, which is exactly what Exercise 4 addresses.

## Exercise 3: block floating point

### When is an unscaled stage safe?

An unscaled butterfly computes a ± b·w. Its complex magnitude is at most |a| + |b|, so if every value's **complex magnitude** is below ½, the outputs stay below 1: that is the rule the exercise states. But measuring a complex magnitude needs two squares and a square root. The cheap hardware test looks at the **components**, |re| and |im|, and that changes the bound:

- If every component is below c, a complex value can still have magnitude c√2 (both parts at c).
- One output component is re(a) ± re(b·w), at most c + |b| ≤ c + c√2 = **c(1 + √2) = 2.414c**.

With a component threshold of ½, an output component can reach 1.207 and overflow. A concrete case: a = 0.5, b = 0.5 + 0.5j and w = e^{−jπ/4} (twiddle 8 of 64) give b·w = 0.707, so a + b·w = **1.207**. The safe component threshold is 1/(1 + √2) = 0.414. I used **T = 0.375** (12,288 in Q1.15), a round value below it, so an unscaled stage can never overflow. (In 300 random blocks no threshold up to ½ actually saturated, because the worst case needs a particular alignment of phases; but a design should not depend on that.)

### The model

```python
def fft_bfp(xr, xi, N=64, T=12288):
    L = N.bit_length() - 1
    wr, wi = twiddles(N)
    ar = [int(xr[bit_reverse(i, L)]) for i in range(N)]
    ai = [int(xi[bit_reverse(i, L)]) for i in range(N)]
    big = lambda v: v >= T or v <= -T
    flag = any(big(v) for v in ar + ai)                  # checked while loading
    exp, nsat = 0, 0
    for s in range(L):
        scale, flag = flag, False
        F = 31 if scale else 30                          # 31: drop 16 bits = /2;  30: drop 15 bits
        ...                                              # the butterflies, as in fft_fixed, with requant(v, F, ...)
            flag |= big(ar[i]) or big(ai[i]) or big(ar[j]) or big(ai[j])
        exp += scale
    return np.array(ar), np.array(ai), exp, nsat
```

The decision for each stage uses the values **entering** it: the loaded input for stage 0, then the values each stage writes, which are exactly the next stage's inputs. The only arithmetic difference between a scaled and an unscaled butterfly is the number of bits `requant` drops: 16 (the sum ÷ 2) or 15. The result satisfies **DFT/N ≈ bins × 2^exp / N**: with every stage scaled, exp = log₂ N and this is the original design.

### The RTL

`fft_bfp.sv` adds to `fft_n.sv` a second set of four `requant` instances (dropping 15 bits), a multiplexer choosing between the two sets, and a detector:

```systemverilog
  logic scale, flag;                             // flag: some value written so far is >= T
  logic signed [W-1:0] br0, bi0, br1, bi1;       // the butterfly results actually written
  assign br0 = scale ? yr0 : zr0;  assign bi0 = scale ? yi0 : zi0;
  assign br1 = scale ? yr1 : zr1;  assign bi1 = scale ? yi1 : zi1;
  function automatic logic big(input logic signed [W-1:0] v);
    big = (v >= W'(T)) || (v <= -W'(T));
  endfunction
```

During LOAD, `flag` collects `big()` of every input; at the end of the block it becomes `scale` for stage 0. During each stage, `flag` collects `big()` of every result written; at the stage's last butterfly, `exp_o` is incremented if the stage was scaled, and the collected flag becomes the next stage's `scale`. The exponent is an output, constant while the bins of its block are unloaded.

Verification: 22 blocks (random data at amplitudes 0.9, 0.5, 0.05 and 0.005, a 0.7 complex tone, an impulse), **bins and exponent bit-exact**, lint-clean. The exponents were 5 at amplitude 0.9, 4 at 0.5, 1 at 0.05, 0 at 0.005, 6 for the tone (its energy concentrates into one bin, so every stage needs scaling) and 2 for the impulse.

### SQNR, against the original design

As in section 11.3: 20 random complex blocks per amplitude, against `np.fft.fft(x)/64` of the same quantized input (for block floating point, the bins are multiplied by 2^exp/64 first):

| Input amplitude | Scale every stage | Block floating point | Exponent |
| --- | --- | --- | --- |
| 0.5 | 68.2 dB | **74.5 dB** | 4 |
| 0.05 | 48.5 dB | **76.7 dB** | 1 |
| 0.005 | 28.8 dB | **58.6 dB** | 0 |

**The 20-dB-per-decade loss disappears**, over the range where block floating point can avoid scaling: from 0.5 to 0.05 the SQNR stays near 75 dB instead of falling by 20 dB, because the FFT now keeps the signal large in its words. Even at 0.5 it gains 6 dB, since two of the six stages need no scaling.

At 0.005, the SQNR falls again, but from 58.6 dB instead of 28.8 dB, 30 dB better. Here no stage is scaled at all (exponent 0); block floating point has used up its range, and the remaining limit is the input itself: a signal of 160 LSB carries only about 8 bits, and the 0.5-LSB rounding of each stage is large next to it. In general, block floating point extends the useful input range by up to log₂ N stages, 6 × 6 dB = **36 dB** for N = 64.

## Exercise 4: the memory in block RAM

### Why the original cannot use block RAM

`fft64.sv` reads two arbitrary addresses and writes two in the **same** cycle, combinationally: four accesses per cycle. A block RAM has two ports, each doing one **synchronous** access per cycle (the read data appears after the clock edge). So Yosys had to build the memory from flip-flops and multiplexers.

### The restructured design: two cycles per butterfly

`fft_bram.sv` keeps everything that defines the arithmetic (addresses, twiddles, the four `requant` instances) and changes the memory and its timing:

- **One memory of N words, {re, im}** packed into 32 bits, so a single access reads or writes a complex value. It has no reset.
- **Two ports**, each in its own `always_ff` block with a registered read, the pattern Yosys maps onto a true dual-port block RAM:

```systemverilog
  always_ff @(posedge clk) begin                 // port A
    if (we_a) mem[addr_a] <= wd_a;
    rd_a <= mem[addr_a];
  end
  always_ff @(posedge clk) begin                 // port B
    if (we_b) mem[addr_b] <= wd_b;
    rd_b <= mem[addr_b];
  end
```

- **Each butterfly takes two cycles**, selected by a phase bit `ph`. In the first, ports A and B read addresses i and j. In the second, the butterfly computes from the registered read data `rd_a` and `rd_b`, and both ports write the results back to i and j:

```systemverilog
  always_comb begin
    addr_a = ia;  addr_b = ja;  we_a = 1'b0;  we_b = 1'b0;
    wd_a = {yr0, yi0};  wd_b = {yr1, yi1};
    case (state)
      S_LOAD:    begin addr_a = load_addr; wd_a = {in_re, in_im}; we_a = in_valid; end
      S_COMPUTE: begin we_a = ph; we_b = ph; end          // write both results in the second cycle
      S_UNLOAD:  addr_a = cnt;                             // read; the data arrives a cycle later
      default:   ;
    endcase
  end
```

- **Unloading** reads through port A; because the read is registered, the bin appears one cycle after its address, so `out_valid` is the registered value of "in the unload state", and the output is taken directly from `rd_a`.

There are no data hazards. Within a stage, the butterflies touch disjoint pairs of addresses; and when a stage's first butterfly reads a value that the previous stage's last butterfly wrote, the write happened at an earlier clock edge than the read.

### Verification

Bit-exact against the same `fft_fixed` model at N = 64, 256 and 1,024 (6 blocks each, random input gaps), and lint-clean.

### The comparison

|  | N = 64, original | N = 64, block RAM | N = 1,024, original | N = 1,024, block RAM |
| --- | --- | --- | --- | --- |
| Block RAM | 0 | **1 RAMB36E1** | 0 | **1 RAMB36E1** |
| LUTs | 5,532 | **349** | 96,810 | **581** |
| Flip-flops | 2,098 | **19** | 32,827 | **28** |
| DSP48E1 | 4 | 4 | 4 | 4 |
| Cycles per transform | 320 | 512 | 7,168 | 12,288 |

The cycle counts follow from the structure: N to load, (N/2)·log₂ N butterflies at one or two cycles each, N to unload: N + N·log₂ N + N for the block-RAM version. (The design also needs one cycle of latency on the output, which overlaps with the next load.)

The block-RAM version is about **16 times smaller in LUTs at N = 64 and 167 times smaller at N = 1,024**, and almost all of its flip-flops are gone: the memory, its read registers and its address multiplexers are now inside one block RAM. (A 1,024 × 32-bit memory is exactly one 36-kbit RAMB36E1.) In exchange it takes 1.6 to 1.7 times as many cycles. For almost any real design that is an excellent trade: a 100 MHz clock still delivers a 1,024-point transform in 123 µs.

### The other way: two banks

The two cycles per butterfly can be recovered by splitting the memory into **two banks**, each a block RAM, chosen by the **parity** (the XOR of all bits) of the address. In every butterfly, i and j differ in exactly one bit (bit s in stage s), so their parities always differ: one is in bank 0 and the other in bank 1. Each bank then needs only one read and one write per butterfly, which its two ports can do in the same cycle (with the write going to the address read one or two butterflies earlier, through a short pipeline). The cost is a little address logic and a swap multiplexer on each side of the butterfly. This gives one butterfly per cycle again, with the same small memory cost, and is how high-throughput memory-based FFTs are usually built.

## Exercise 5: fast convolution

### Overlap-add

The convolution of a block of B samples with an M-tap filter has B + M − 1 samples. If both are zero-padded to N ≥ B + M − 1 points, the product of their DFTs is exactly the DFT of that convolution, with no circular wrap-around. With N = 64 and M = 32, the blocks can hold B = 64 − 32 + 1 = **33** samples. Each block's 64-sample result overlaps the next block's by 31 samples, and the overlapping parts are simply added:

```python
def ifft_iter(X):
    """Inverse FFT through the forward one: ifft(X) = conj(fft(conj(X))) / N."""
    return np.conj(fft_iter(np.conj(X))) / len(X)

def overlap_add(x, h, N=64):
    M = len(h); B = N - M + 1                        # block length: B + M - 1 = N, no wrap-around
    H = fft_iter(np.r_[h, np.zeros(N - M)])          # computed once
    y = np.zeros(len(x) + M - 1, dtype=complex)
    for start in range(0, len(x), B):
        blk = x[start:start + B]
        Y = ifft_iter(fft_iter(np.r_[blk, np.zeros(N - len(blk))]) * H)
        n = min(N, len(y) - start)
        y[start:start + n] += Y[:n]                  # the tails overlap and add
    return y.real
```

The inverse FFT reuses the forward one through conjugation, so only `fft_iter` is needed. Filtering 5,000 random samples with the Part 7 filter (`firwin(32, 0.2)`), in 152 blocks:

```text
overlap-add (blocks of 33, 64-point FFTs) vs np.convolve: max difference 6.66e-16 (signal rms 0.425), 152 blocks
```

The two agree to floating-point rounding: fast convolution is not an approximation.

### Multiplications per output sample

Per block, with H computed once: a forward FFT and an inverse FFT, (N/2)·log₂ N complex multiplications each, plus N complex multiplications for X·H, so N·(log₂ N + 1) complex multiplications, each 4 real ones. Each block produces B = N − M + 1 outputs:

```latex
\text{real multiplications per output} = \frac{4N(\log_2 N + 1)}{N - M + 1}
```

The block size N is free, so for each filter length the best N was searched:

| Filter | Direct | FFT, N = 64 | FFT, best N | Winner |
| --- | --- | --- | --- | --- |
| 32 taps | **32** | 54.3 | 41.0 (N = 256) | **direct**, by 22% |
| 1,000 taps | 1,000 | — | **63.8** (N = 8,192) | **FFT**, 16 times fewer |

For 1,000 taps, N = 2,048 already gives 93.7, and the cost keeps falling slowly up to N = 8,192 before rising again: longer blocks spread the FFT cost over more outputs, until the log₂ N factor wins.

**The crossover**: scanning the filter length, the FFT method becomes cheaper from **M = 44 taps** (43.3 against 44 real multiplications per output). Two refinements move it: a real-signal FFT does roughly half the work (two real blocks fit into one complex FFT), which brings the crossover down to about **19 taps**; and Gauss's three-multiplication product (Part 6) lowers it further. Against that, direct convolution needs no block buffering and has no block latency, and on an FPGA with spare DSP blocks its regular structure is often worth more than the multiplication count.

The rule of thumb: **for filters above a few dozen taps, especially in software or for very long filters (reverberation, matched filters for long codes), fast convolution wins, and the advantage grows as M / log M.**

---

That completes Part 11. Send me your own designs and results if you would like them reviewed.
