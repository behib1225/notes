# Verilog & RTL for DSP — Part 12: Capstone, a Digital Down-Converter

*Markdown export of the online document: https://claude.ai/artifact/HpTCMxddB15Mq5CWTsBojN. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 12 fits

This is the capstone. You will build a complete **digital down-converter** (DDC), the front end of every software-defined radio and digital receiver, from blocks you have already written and verified. Almost no new RTL is needed; the work is **system design**: choosing the frequency plan and filter orders, making the blocks' rates and handshakes fit together, verifying the whole chain bit-exactly, and measuring that it meets its specification.

What each earlier part contributes:

| Part | Contribution to the DDC |
| --- | --- |
| 1 to 3 | Modules, registers, FSMs, the controller-plus-datapath method |
| 4 | The Python-driven verification flow, assertions, lint, Yosys reports |
| 5 | Sampling, aliasing, frequency response |
| 6 | Fixed-point formats, `requant`, the MAC unit |
| 7 | FIR design and the serial FIR architecture |
| 9 | The NCO and the mixer |
| 10 | The CIC decimator, the decimating FIR, decimation-chain design |
| 11 | The FFT, as the measuring instrument for the output spectrum |

Part 8 (IIR) is the one part not used: a DDC needs linear phase and a sample-rate change, which point to FIR filters (Part 8, section 8.5).

As always, every number comes from code that was run: Python 3 with NumPy and SciPy, Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33. The RTL files are reused unchanged from earlier parts: `nco.sv` and `mixer.sv` (Part 9), `cic_decim.sv` and `fir_decim.sv` (Part 10), `mac.sv` and `requant.sv` (Part 6).

## 12.1 The system

A digital down-converter selects one narrow channel from a wideband signal, moves it to 0 Hz, and reduces the sample rate to match the channel's bandwidth. Its input is a fast stream of real samples from an ADC; its output is a slow stream of complex (I/Q) samples that a demodulator, a decoder or a spectrum display can process cheaply.

> **Figure:** ddc.sv signal path and sample rates (shown in the [online version](https://claude.ai/artifact/HpTCMxddB15Mq5CWTsBojN))

### The specification

| Parameter | Value |
| --- | --- |
| Clock | 100 MHz |
| Input | Real, 16-bit Q1.15, 20 MS/s (one sample per 5 clocks) |
| Channel | Tunable center frequency (example: 4.8 MHz), bandwidth ±0.4 MHz |
| Output | Complex, 16-bit Q1.15 I and Q, 1.25 MS/s (decimation by 16) |
| Passband ripple | Below 0.1 dB across ±0.4 MHz |
| Alias rejection | At least 60 dB for anything that would fold into ±0.4 MHz |
| Verification | Bit-exact against a Python model, and the output spectrum measured |

### The signal path

1. **Mixer** (Part 9): multiplies the input by e^{−j2πf\_LO n}, from the NCO, moving the channel at f\_LO to 0 Hz. Its output is complex, still at 20 MS/s.
2. **CIC decimators** (Part 10), one for I and one for Q: R = 8, so the rate falls to 2.5 MS/s, with no multipliers.
3. **Compensating FIR decimators** (Parts 7 and 10), one per channel: 31 taps, decimate by 2 to 1.25 MS/s, correcting the CIC's droop and removing everything between the passband and the new Nyquist frequency.

This is exactly the chain argued for in Part 10, section 10.4, scaled to these numbers: the CIC does the heavy rate reduction where the rate is high, and the FIR does the precise filtering where the rate is low.

### Check your understanding: 12.1

1. What is the total decimation factor, and what is the output Nyquist bandwidth?
2. Why is the output complex, when the input is real?
3. Why does each channel (I and Q) need its own CIC and FIR?
4. A tone at 5.0 MHz enters with f\_LO = 4.8 MHz. At which output frequency does it appear?

#### Answers

1. 8 × 2 = **16**. The complex output at 1.25 MS/s covers **−0.625 to +0.625 MHz**.
2. The mixer multiplies by a complex exponential, which shifts the spectrum by −f\_LO. The result has different content at positive and negative frequencies, which only a complex (I/Q) signal can represent (Part 9, section 9.1).
3. I and Q are two independent real signals: each must be low-pass filtered and decimated in the same way, with identical filters, so that their relationship (the phase of the complex signal) is preserved.
4. 5.0 − 4.8 = **+0.2 MHz**, inside the passband.

## 12.2 Designing it in Python

Every design decision is made in Python before any RTL is touched: the frequency plan, the CIC's order, the FIR's coefficients and every word width. The result is one file, `ddc_model.py`, that designs the filters, writes the coefficient file and contains the bit-exact model of the whole chain.

### The frequency plan

| Point in the chain | Sample rate | Passband edge | Normalized passband edge |
| --- | --- | --- | --- |
| Mixer output | 20 MS/s | ±0.4 MHz | 0.02 cycles/sample |
| CIC output | 2.5 MS/s | ±0.4 MHz | 0.16 cycles/sample |
| FIR output | 1.25 MS/s | ±0.4 MHz | 0.32 cycles/sample |

After the final decimation, frequencies that fold into ±0.4 MHz start at 1.25 − 0.4 = 0.85 MHz, which is **0.34** cycles per sample at the CIC output rate: the FIR's stopband must begin there.

### Choosing the CIC order

The CIC must protect the passband from everything that folds onto it at its own decimation, which comes from the bands around multiples of 1/R. Computing its droop and worst-case alias rejection for R = 8 and three orders:

| CIC order N | Droop at 0.4 MHz | Worst alias into ±0.4 MHz | Register width |
| --- | --- | --- | --- |
| 3 | −1.09 dB | 43.8 dB | 25 bits |
| 4 | −1.45 dB | 58.5 dB | 28 bits |
| **5** | **−1.82 dB** | **73.1 dB** | **31 bits** |

Only N = 5 meets the 60 dB requirement with margin. It costs 6 more bits per register than N = 3 and two more adders per stage pair, but still no multipliers.

### The compensation FIR, and a design that failed

The FIR must have a gain that rises as 1/|H\_CIC| across the passband, to undo the 1.82 dB droop, and fall to zero from 0.34 cycles per sample.

The first attempt used `scipy.signal.firwin2`, the frequency-sampling method suggested in Part 10. It met the passband (combined ripple −0.64 to +0.05 dB) but reached only **24.2 dB** of stopband attenuation with 32 taps: `firwin2` interpolates the desired gain linearly across the transition band, so the filter spends its effort fitting a meaningless ramp.

The second attempt used **least squares**, `scipy.signal.firls`, which lets the passband follow the inverse droop in 8 linear segments, leaves the transition band free, and weights the stopband 30 times more heavily:

```python
def design_fir():
    """Compensation FIR at the CIC output rate, by least squares (scipy.signal.firls):
    the inverse of the CIC droop across the passband (piecewise linear), zero in the stopband."""
    fp = F_PASS / FS_CIC                       # 0.16 cycles/sample
    fs = (FS_CIC / M_FIR - F_PASS) / FS_CIC    # 0.34: first frequency that aliases into the passband
    edges = np.linspace(0, fp, 9)
    bands, desired = [], []
    for a, b in zip(edges[:-1], edges[1:]):    # 8 passband segments following 1/|H_cic|
        bands += [a, b]
        desired += [1 / cic_response(a / R), 1 / cic_response(b / R)]
    bands += [fs, 0.5]; desired += [0, 0]
    return signal.firls(N_TAPS, bands, desired, weight=[1] * 8 + [30], fs=1.0)
```

With only **31 taps** (`firls` requires an odd length), the combined CIC + FIR passband ripple is **0.007 dB** and the FIR's stopband attenuation is **88.5 dB**. The lesson: the design method matters as much as the length. The coefficients are quantized to Q1.17, as in Part 7, and written to `fir_coefs.svh` by the Part 7 helper.

### Word widths

| Signal | Format | Why |
| --- | --- | --- |
| Input x | Q1.15 | The ADC's 16 bits |
| NCO cos, sin | Q1.15, amplitude 32,767 | 1,024-entry tables (Part 9) |
| Mixer outputs I, Q | Q1.15 | Product Q2.30 rounded once and saturated |
| CIC registers | 31 bits | 16 + 5 · log₂ 8 (Part 10's rule) |
| CIC outputs | Q1.15 | Gain 8⁵ = 2¹⁵ removed by dropping 15 bits |
| FIR coefficients | Q1.17 | 18 bits, a DSP48E1's B port |
| FIR accumulator | 40 bits | 16 + 18 + 5 + 1, inside the Part 6 MAC |
| Outputs I, Q | Q1.15 | Rounded once and saturated |

Every block keeps full precision internally and rounds once at its output, so each of the three stages contributes about half an LSB of error.

### The bit-exact chain model

Because each block already has a bit-exact model from its own part, the chain model is just those models called in sequence:

```python
def golden(x, fcw):
    """Bit-exact model of ddc.sv, block by block, exactly as the RTL computes it."""
    x = np.asarray(x, dtype=np.int64)
    c, s = nco(fcw, len(x))                                      # Part 9 NCO
    i = requant(x * c, 30, 16, 15, "round", "saturate")         # Part 9 mixer
    q = requant(-(x * s), 30, 16, 15, "round", "saturate")
    i, q = cic_decim_golden(i, R, N_CIC), cic_decim_golden(q, R, N_CIC)   # Part 10 CIC
    hq = coefficients()
    fi = fir_model.golden(i, hq)[M_FIR - 1 :: M_FIR]           # Part 10 decimating FIR
    fq = fir_model.golden(q, hq)[M_FIR - 1 :: M_FIR]
    return fi, fq
```

The test signal contains three tones of amplitude 0.3: the wanted one at **5.0 MHz** (it should appear at +0.2 MHz), an adjacent-channel interferer at **5.8 MHz** (+1.0 MHz after mixing, which the FIR must remove), and one at **7.05 MHz** (+2.25 MHz after mixing, which would fold to −0.25 MHz at the CIC's decimation, so the CIC must remove it), plus a little white noise (standard deviation 0.003).

### Check your understanding: 12.2

1. Why must the FIR's stopband start at 0.34 cycles per sample, not at 0.25 (its own output Nyquist frequency)?
2. Why is N = 4 not enough, although its alias rejection (58.5 dB) is close to the requirement?
3. Why did `firwin2` waste most of its stopband attenuation?
4. How much attenuation does the design give the 7.05 MHz interferer, and which block provides it?
5. Why can the chain model simply call the three block models in sequence?

#### Answers

1. Only frequencies that fold **into the passband** (±0.4 MHz, which is ±0.16 at the CIC rate) matter. After decimation by 2, the first such frequency is 0.5 − 0.16 = 0.34. Frequencies between 0.25 and 0.34 fold to between 0.16 and 0.25, outside the passband, where nobody looks.
2. A specification is a requirement, and 58.5 dB fails 60 dB. Designs also need margin for the effects the analysis ignores, such as coefficient quantization and the NCO's spurs.
3. It tried to follow a linear ramp from the passband gain down to zero across the whole transition band, which forced a slow roll-off and left high sidelobes. Least squares, with the transition band left unspecified, puts all its effort into the bands that matter.
4. It lies 2.25 MHz from the LO, at 0.1125 cycles per input sample, inside a CIC alias band (near 1/8 = 0.125). The CIC attenuates it by **95.2 dB** there; the FIR never sees it.
5. Each block's model is already bit-exact with its RTL, and the blocks are connected only through their sample streams. As long as the top level passes every sample from one block to the next, with none lost or duplicated, the chain of models is bit-exact too. Section 12.3 makes sure no sample is lost.

## 12.3 The RTL

The top level instantiates five existing modules and connects their valid signals in a chain. The only new logic is an **overrun** detector, because the system works only if the input rate leaves the serial FIR enough time, and that assumption deserves a check in hardware, not just a comment.

### The top level

```systemverilog
`timescale 1ns/1ps
// ddc.sv -- digital down-converter: real Q1.15 input -> complex Q1.15 baseband, decimated by 16.
//   mixer (NCO + 2 multipliers) -> CIC (R = 8, N = 5) on I and Q -> FIR (31 taps, /2) on I and Q
// Rate constraint: input samples at least 4 clock cycles apart (see section 12.3).
module ddc #(
  parameter int W = 16
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,
  input  logic [31:0]         fcw,            // LO frequency control word
  output logic                out_valid,
  output logic signed [W-1:0] out_i, out_q,
  output logic                overrun          // sticky: a CIC output arrived while the FIR was busy
);
  // ---- stage 1: mixer ----
  logic                mix_valid;
  logic signed [W-1:0] mix_i, mix_q;
  mixer #(.W(W)) u_mix (
    .clk(clk), .rst(rst), .in_valid(in_valid), .x(x), .fcw(fcw),
    .out_valid(mix_valid), .i_out(mix_i), .q_out(mix_q)
  );

  // ---- stage 2: CIC decimators, one per channel, running in lockstep ----
  logic                cic_valid, cic_valid_q, cic_rdy_i, cic_rdy_q;
  logic signed [W-1:0] cic_i, cic_q;
  cic_decim #(.R(8), .NS(5)) u_cic_i (
    .clk(clk), .rst(rst), .in_valid(mix_valid), .in_ready(cic_rdy_i), .x(mix_i),
    .out_valid(cic_valid), .y(cic_i)
  );
  cic_decim #(.R(8), .NS(5)) u_cic_q (
    .clk(clk), .rst(rst), .in_valid(mix_valid), .in_ready(cic_rdy_q), .x(mix_q),
    .out_valid(cic_valid_q), .y(cic_q)
  );

  // ---- stage 3: compensating FIR decimators (serial, one MAC each) ----
  logic fir_rdy_i, fir_rdy_q, fir_valid_q;
  fir_decim #(.N(31), .M(2)) u_fir_i (
    .clk(clk), .rst(rst), .in_valid(cic_valid), .in_ready(fir_rdy_i), .x(cic_i),
    .out_valid(out_valid), .y(out_i)
  );
  fir_decim #(.N(31), .M(2)) u_fir_q (
    .clk(clk), .rst(rst), .in_valid(cic_valid), .in_ready(fir_rdy_q), .x(cic_q),
    .out_valid(fir_valid_q), .y(out_q)
  );

  // ---- a sample is lost if the CIC delivers one while the FIR is computing ----
  always_ff @(posedge clk) begin
    if (rst) overrun <= 1'b0;
    else if (cic_valid && !fir_rdy_i) overrun <= 1'b1;
  end

  // the Q-channel status signals duplicate the I channel's: tie them off for lint
  wire unused = cic_valid_q ^ cic_rdy_i ^ cic_rdy_q ^ fir_rdy_q ^ fir_valid_q;
endmodule
```

Notes:

- **The I and Q branches run in lockstep.** Both CICs receive the same `mix_valid`, so their outputs are valid on the same cycles; both FIRs receive `cic_valid` from the I branch. The Q branch's duplicate status signals are unused, which the `unused` wire tells the linter explicitly (Part 4).
- **Parameter overrides configure reused modules**: `cic_decim #(.R(8), .NS(5))` and `fir_decim #(.N(31), .M(2))`. No source file from an earlier part was changed.
- The FIR reads its coefficients from the newly generated `fir_coefs.svh`, so the compensation filter replaced Part 7's low-pass filter just by regenerating one file.

### The rate constraint

The CIC has no `in_ready` that can stall the mixer, and its output is a one-cycle pulse: if the FIR is busy when that pulse arrives, the sample is silently lost. So the system must guarantee that the FIR is always ready in time:

- After accepting every second sample, the FIR spends **31 cycles** computing (one MAC per tap) before it can accept the next.
- The CIC produces one output per 8 input samples. If input samples are at least g clocks apart, CIC outputs are at least **8g** clocks apart.
- So the system works if 8g > 31, that is **g ≥ 4**: at most 25 MS/s on a 100 MHz clock. The specification's 20 MS/s (g = 5) leaves margin.

The `overrun` flag watches for exactly the failure the analysis predicts: a CIC output arriving while the FIR's `in_ready` is low. The testbench treats it as fatal:

```systemverilog
  always @(negedge clk) if (!rst) begin
    assert (!overrun) else $fatal(1, "OVERRUN: a sample was lost between the CIC and the FIR");
```

The testbench's input spacing is set by a plusarg, `+GAP=g`, with 0 to 2 random extra idle cycles. Testing the analysis:

| Minimum spacing g | Result |
| --- | --- |
| 5 (the specification) | `PASS: 2048 complex outputs bit-exact` |
| 4 (the predicted limit) | `PASS: 2048 complex outputs bit-exact` |
| 3 | `FATAL: OVERRUN: a sample was lost between the CIC and the FIR` |

The hardware check and the paper analysis agree. In a product, `overrun` would also be a status bit visible to software, so that a misconfigured system announces itself instead of producing subtly wrong data.

### Check your understanding: 12.3

1. Why does the FIR need 31 cycles per output, and why is that a problem only every second CIC sample?
2. What maximum input rate could the DDC handle on a 200 MHz clock?
3. Without the `overrun` detector, what would the symptom of a too-fast input be?
4. How could the design be changed to accept one input sample per clock?
5. Why is it acceptable to leave the Q branch's `in_ready` and `out_valid` unconnected?

#### Answers

1. It is the serial FIR of Part 10: one MAC per tap, 31 taps, so 31 cycles of computation. It computes only after every second input (decimation by 2); while it collects the first sample of each pair it is idle and ready.
2. The constraint is in clock cycles, g ≥ 4, so at 200 MHz: **50 MS/s**.
3. The output would still look plausible: occasionally a CIC sample would be missed, so some FIR outputs would be computed from the wrong samples. The bit-exact test would fail, but in the field there would be only a slightly worse SNR and occasional glitches, very hard to diagnose.
4. Make the FIR faster: use more MACs in parallel (2 MACs would need 16 cycles per output), use the symmetric form with pre-adders, or a fully parallel FIR. Each step costs DSP blocks; the system's rate decides how many are needed. The CIC and mixer already accept one sample per clock.
5. Both branches receive identical valid signals and run identical modules, so their status signals are identical by construction. Using the I branch's is enough; checking that the two always agree would be a good assertion for the testbench (Exercise 1).

## 12.4 Verification and measurement

Three questions, answered in order: does the RTL compute exactly what the model says (bit-exactness)? Does the output contain the wanted signal and nothing else (spectrum)? And how close is the whole fixed-point chain to ideal arithmetic (accuracy)?

### Bit-exact

With 32,768 input samples and the stimulus of section 12.2, the testbench compares every output with the model as it arrives:

```text
PASS: 2048 complex outputs bit-exact, 196572 clock cycles
```

That is 6 clocks per input sample: the 5-clock minimum spacing plus the random extra gaps. Two more seeds also passed. The whole chain worked bit-exactly the first time it was simulated, because every block had already been verified bit-exactly on its own, and the chain model is made of the same block models. **That is the payoff of the method you have followed since Part 4.**

### The output spectrum

The 2,048 complex output samples, through a Blackman–Harris window and `np.fft.fft` (Part 11), relative to the wanted tone:

> **Figure:** ddc.sv output (Icarus 12.0), np.fft.fft with Blackman-Harris window, peak of each 8-bin group (shown in the [online version](https://claude.ai/artifact/HpTCMxddB15Mq5CWTsBojN))

| Component | Where | Measured |
| --- | --- | --- |
| Wanted tone (5.0 MHz in) | +0.2002 MHz | amplitude 0.144: −16.8 dBFS |
| Adjacent-channel tone (5.8 MHz) and the CIC-aliasing tone (7.05 MHz) | both would land near −0.25 MHz | −68.4 dBc, at the noise floor |
| Largest unwanted component | −0.2002 MHz, the mirror image of the wanted tone | −64.4 dBc |
| Noise floor | everywhere | about −70 dBc per display point |

The wanted tone's amplitude, 0.144, is close to the 0.15 expected (a real cosine of amplitude 0.3 splits into two halves, and only the one at +0.2 MHz is kept); the small remainder is the window's scalloping loss, since 0.2 MHz falls between FFT bins. Both interferers, each as strong as the wanted signal at the input, have vanished into the noise floor. The floor itself is the white noise deliberately added to the input (standard deviation 0.003), filtered to the output band.

The one visible artifact is the **mirror image** of the wanted tone at −0.2 MHz. It comes from the NCO: its cosine and sine tables are not perfectly in quadrature after phase truncation, so a little of the signal is shifted the wrong way. Rerunning the model with a 12-bit NCO table lowered the mirror from −64.4 to −73.2 dBc, down to the noise floor; a 14-bit table gave no further gain (−72.8 dBc). (All three figures use the same measurement: the largest bin within two bins of −0.2 MHz, relative to the largest bin within two bins of +0.2 MHz, in a 2,048-point Blackman–Harris FFT. Near the noise floor, a different window or bin range gives a few dB of difference, so always state the method with the number.) Part 9's spur rule predicted that the 10-bit table would be the weakest link.

### Accuracy against ideal arithmetic

Comparing the RTL output with a floating-point reference of the same chain:

| Reference | SQNR of the RTL output |
| --- | --- |
| Floating point, using the NCO's own table values | **79.5 dB** |
| Floating point, with an ideal oscillator | **49.1 dB** |

The first number measures the fixed-point arithmetic alone: three rounding steps, at roughly 80 dB, close to what 16-bit outputs allow. The second includes the NCO's phase truncation, whose spurs mix the two strong interferers into the passband; with a larger table it would rise. Fixed-point design is always about finding, and paying for, the weakest link.

### Two traps in building the reference

Building the floating-point reference was harder than building the hardware, and the two mistakes are worth knowing.

**A floating-point CIC is not a reference.** The first reference used the CIC's own integrator-comb structure in floating point. Five cascaded integrators grow to values around 10²¹, far beyond the 53-bit precision of a `float64`, so after about 2,100 samples the reference began losing bits, with errors of up to 40 LSB. The fixed-point RTL was right; the reference was wrong. The CIC is defined by its exact integer arithmetic, and the correct floating-point reference is the mathematically equivalent filter, five cascaded 8-sample moving sums followed by decimation, which has no growth problem. It matched the integer CIC to within half an LSB at an offset of 2 input samples.

**Stale files.** A first accuracy measurement gave a puzzling 43 dB. The cause was that the output file `y_actual.txt` was left over from a regression run with a different seed, while the stimulus had been regenerated. Every individual stage then checked out perfectly, which is what pointed at the files. The fix is the discipline of Part 4: one script regenerates the stimulus, runs the simulation and runs every check together, so that results from different runs can never be mixed.

### Check your understanding: 12.4

1. Why did the complete chain pass bit-exactly on its first simulation?
2. The interferers had the same amplitude as the wanted signal at the input. By how much does the output suppress them, at least?
3. Why does a tone between FFT bins appear slightly weaker than its true amplitude?
4. Why is the 79.5 dB figure a measure of the arithmetic, and the 49.1 dB figure a measure of the NCO?
5. Why can a floating-point model of a CIC filter be less accurate than the fixed-point hardware?

#### Answers

1. Each block's RTL had been verified bit-exactly against its own model in earlier parts, and the chain model calls exactly those models. The only new risks were in the connections (alignment, lost samples), and the top level reuses tested handshakes.
2. They are at or below the −68.4 dBc noise floor near −0.25 MHz, so at least **68 dB** relative to the wanted tone; the analysis predicts 95 dB for the CIC-aliasing tone and 68 dB for the adjacent channel from the FIR alone.
3. The window's main lobe is not flat: a tone exactly between bins is measured on the side of the lobe (scalloping loss). For a Blackman–Harris window it is under 1 dB.
4. The first reference uses exactly the same oscillator values as the hardware, so the only difference left is the fixed-point arithmetic. The second uses a perfect oscillator, so its difference also includes the NCO's errors, which turn out to dominate.
5. The CIC's integrators grow without limit. Integer arithmetic with wrap-around is exact by construction (Part 10), but floating point keeps only 53 significant bits: once the integrators exceed about 2⁵³, small input changes are rounded away, and the comb differences inherit those errors.

## 12.5 Synthesis: the bill of materials

The complete DDC, synthesized with `synth_xilinx -family xc7 -flatten` (Yosys 0.33), lint-clean in Verilator across the whole hierarchy:

| Resource | Count | Where it goes |
| --- | --- | --- |
| DSP48E1 | **4** | 2 in the mixer (x·cos, x·sin), 1 MAC in each FIR |
| RAMB18E1 | **2** | The NCO's cosine and sine tables |
| LUTs | about 1,400 | CIC adders, rounding and saturation, FIR multiplexers and control |
| Flip-flops | about 1,810 | Mostly the two FIR delay lines (2 × 31 × 16 bits) and the CIC registers (2 × 10 × 31 bits) |
| CARRY4 | 232 | The CIC's 31-bit adders and the NCO's accumulator |

Compare that with the one-filter approach of Part 10, section 10.4: decimating by 16 in a single FIR at 20 MS/s would need hundreds of taps and, at this rate, a dozen or more multipliers. The CIC turns the high-rate filtering into adders, and the FIR does its precise work at a rate low enough for **one** multiplier per channel.

Three things this report does **not** tell you, and how they would be checked in a real project:

- **Timing.** Whether the design meets 100 MHz needs place-and-route and static timing analysis, in Vivado or nextpnr. The likely critical path is the 31-bit CIC adder chain; Part 4's pipelining techniques apply if it is too slow.
- **Power.** Vendor tools estimate it from toggle rates; the CIC's high-rate adders and the NCO dominate.
- **The test of the real thing.** On a board, the same Python flow can generate stimulus for the ADC side (or replace the ADC with a test pattern) and capture the output for the same spectrum analysis.

Even so, the result is a complete, tunable, bit-exactly verified receiver front end that uses a small fraction of even a small FPGA.

### Check your understanding: 12.5

1. Which single block uses most of the flip-flops, and why?
2. How would the DSP count change if the FIRs had to process one sample per clock in a fully parallel form?
3. Why does the NCO use block RAM while the FIR coefficients do not?

#### Answers

1. The two **FIR delay lines**: 31 samples × 16 bits × 2 channels = 992 flip-flops. They are reset, which (as Part 7 noted) prevents the tools from packing them into LUT-based shift registers.
2. A fully parallel 31-tap FIR needs 31 multipliers (16 with symmetric pre-adders, since `firls` designs are symmetric) per channel: **about 32 to 62** DSP blocks for I and Q, instead of 2.
3. Each NCO table has 1,024 entries of 16 bits, which is what block RAM is for. The FIR has only 31 coefficients, read as a small constant ROM in LUTs.

### Has the 100 MHz clock been checked?

**No, not in this part.** Everything above assumes a 100 MHz clock, but synthesis reports logic depth, not timing; only place and route, for an actual device, can say whether a design meets its clock. When this DDC was later placed and routed for a Lattice ECP5 with the open-source nextpnr, it reached only **44.2 MHz**: the mixer's table read, multiplication and rounding all fall in one clock cycle, and so do the CIC's five comb subtractions. Pipelining the mixer, the CIC's combs and every rounding step, all without changing a single output bit, raises it to between 106 and 119 MHz on five placements, so the pipelined version (ddc\_p2.sv) meets 100 MHz on that device. [Part 13: From Simulation to Hardware](https://claude.ai/artifact/Ms1SzQtcuXeZ5H8UjsXZPk) shows the whole process. Treat the figures of this section as area estimates for the unpipelined design, which does not run at 100 MHz as written.

## 12.6 Exercises and projects

The exercises improve the DDC; the projects take you beyond the course. Each needs a model change, the bit-exact check, and a new measurement showing what improved. Send me your results.

- [ ] Exercise 1: harden the testbench
- [ ] Exercise 2: fix the weakest link
- [ ] Exercise 3: one sample per clock
- [ ] Exercise 4: a programmable bandwidth
- [ ] Project A: an FM receiver
- [ ] Project B: a spectrum analyzer
- [ ] Project C: on real hardware

### Exercise 1: harden the testbench

- Add assertions that the I and Q branches' valid signals and FIR ready signals always agree.
- Add a mode that changes the FCW in the middle of a run, and check bit-exactness through the change (the NCO is phase-continuous, Part 9).
- Combine everything into one `run_ddc.sh` that regenerates the stimulus, simulates and checks, with a seed regression, so that the stale-file mistake of section 12.4 cannot happen.

### Exercise 2: fix the weakest link

The NCO's 10-bit table limited the accuracy to 49.1 dB against an ideal oscillator.

- Use your quarter-wave table from Part 9, Exercise 2, to reach a 12-bit (or larger) table in the same block RAM. Re-measure the mirror image and both SQNR figures.
- Find the point at which the NCO stops being the weakest link. What is the next one?

### Exercise 3: one sample per clock

Make the DDC accept one input sample every clock cycle (100 MS/s).

- The mixer and CIC already can. Replace the serial FIR with a design fast enough for one CIC output every 8 clocks: several MACs in parallel, or the symmetric form with a shared multiplier (Part 7). Keep it bit-exact.
- Update the overrun analysis and prove with the testbench that `+GAP=1` now passes.

### Exercise 4: a programmable bandwidth

Make the CIC's decimation factor a run-time input (R = 4, 8 or 16), so the output bandwidth can be changed without resynthesis.

- The CIC's gain Rᴺ changes with R: shift by the right amount at run time, and size the registers for the largest R.
- The compensation FIR's coefficients depend on R: store one set per R in the coefficient ROM, selected by the same input.

### Project A: an FM receiver

Add a CORDIC in vectoring mode (Part 9, Exercise 4) after the DDC to compute the phase of each output sample, and a differentiator (the phase difference between consecutive samples) to recover the audio of an FM signal. Generate an FM test signal in Python, and listen to the recovered audio with `scipy.io.wavfile`.

### Project B: a spectrum analyzer

Feed the DDC's output into the FFT of Part 11, with a window applied in a small ROM, and average the magnitudes over many blocks. You have built a zoom spectrum analyzer: tune the NCO to look at any 1.25 MHz slice of a 10 MHz band.

### Project C: on real hardware

If you have, or buy, an FPGA development board (any board with an AMD 7-series or similar device is enough), run the open-source or vendor tool flow to place and route the DDC, check its timing at 100 MHz, and run it on a test pattern stored in block RAM, capturing the outputs for the same Python analysis.

## 12.7 Course summary

Twelve parts ago you had a Digital Design course behind you and no Verilog. You can now design, verify and measure a complete DSP system in RTL. That is the core of what DSP hardware engineers do.

### What you can now do

| Skill | Where you learned it |
| --- | --- |
| Describe combinational and sequential hardware in SystemVerilog, and know what each line builds | Parts 1 and 2 |
| Design control with FSMs, and split systems into datapath and controller | Part 3 |
| Verify against a Python golden model, bit-exactly, with assertions, regressions and lint | Part 4, and every part after |
| Read synthesis reports and write RTL in the shape of the target's hard blocks | Parts 4, 6 and 7 |
| Reason about sampling, aliasing, convolution, frequency response and noise | Part 5 |
| Choose fixed-point formats, rounding, saturation and word widths, and predict their error | Part 6 |
| Design FIR and IIR filters, and choose among their architectures | Parts 7 and 8 |
| Generate and mix signals with NCOs and CORDIC | Part 9 |
| Change sample rates efficiently with decimating filters and CIC filters | Part 10 |
| Compute and interpret spectra, and build an FFT processor | Part 11 |
| Combine all of it into a system that meets a specification | Part 12 |

### The method, in seven lines

1. Write the specification as numbers.
2. Design in floating point, then in fixed point, in Python; measure against the specification.
3. Choose the architecture from the ratio of clock rate to sample rate.
4. Write RTL whose structure matches the hardware you want, with valid signals beside the data.
5. Verify it bit-exactly against the fixed-point model, with corner cases, random seeds and assertions.
6. Synthesize and read the report; fix what surprises you.
7. Measure the RTL's behavior (gain, spectrum, SQNR) against the specification, not just against the model.

### Where to go next

- **Formal verification.** SystemVerilog Assertions (SVA) and open-source formal tools (the SymbiYosys flow built on Yosys) prove properties for **all** inputs, not just the ones you simulated.
- **Better testbenches.** cocotb lets you write testbenches in Python directly, without the file interface; the UVM methodology is the industry standard for large verification projects.
- **Physical implementation.** Place-and-route, timing closure, clock-domain crossing and power: the step from "synthesizes" to "runs on a chip". Vendor tools (AMD Vivado, Altera Quartus) or the open-source nextpnr flow.
- **High-level synthesis.** Tools that generate RTL from C++ or Python descriptions. Knowing RTL is what lets you judge, and fix, what they produce.
- **Deeper DSP.** Adaptive filters (LMS), multirate filter banks, OFDM modems, and synchronization (timing and carrier recovery): each is built from the blocks of this course.

Thank you for working through the course. Send me your exercise solutions, your project results, or any questions, at any time; I will review them and can write follow-up material on any of the topics above.

### Beyond Part 12

The course has since grown two parts and three appendices, each built and verified with the same tools and method:

- [Part 13: From Simulation to Hardware](https://claude.ai/artifact/Ms1SzQtcuXeZ5H8UjsXZPk): timing closure of this DDC after place and route, AXI4-Stream, formal verification, and clock-domain crossing.
- [Part 14: More DSP Structures](https://claude.ai/artifact/V3up8RZjK314g2yFkPZiiK): canonical signed digit coefficients, distributed arithmetic, a Farrow resampler, and a streaming FFT.
- [Appendix A: Portable SystemVerilog](https://claude.ai/artifact/2rooPowLtJJTig3xL7sYfU): what Icarus, Verilator and Yosys each accept, and how to write code all three do.
- [Appendix B: Measuring and Cross-Checking](https://claude.ai/artifact/5UJq2UPxPsecQq5o4hY4SX): one definition for every measurement, the blind spot of bit-exact testing, and functional coverage with cocotb.
- [Appendix C: The Mathematics Behind the DSP Parts](https://claude.ai/artifact/2HA6TpUNfXT1oUGK8nfuyq): complex exponentials, frequency response, the z-transform, poles and zeros.
