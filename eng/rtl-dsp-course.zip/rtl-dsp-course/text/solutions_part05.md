# Verilog & RTL for DSP — Solutions to Part 5

*Markdown export of the online document: https://claude.ai/artifact/7aGatSsAt9ajsS7vGeWQVa. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the six exercises of Part 5. They are mostly Python, with one return to the RTL in Exercise 6. Try each one first; the "Check your understanding" answers are in Part 5 itself.

All the frequency measurements use the `amplitude()` function of section 5.5, which takes the frequency in **cycles per sample**:

```python
def amplitude(y, f):
    """Amplitude of the component of y at f cycles/sample (projection onto a complex sinusoid)."""
    n = np.arange(len(y))
    return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))
```

**A measurement detail that matters.** `amplitude()` is exact only when the analyzed block contains a **whole number of cycles** of every tone present. Otherwise each tone leaks slightly into the measurement of the others. While writing these solutions, a first measurement of Exercise 4 used a 3.8-second window, 7.6 cycles of the 2 Hz signal, and gave 0.9896 instead of the correct 0.9974. Every measurement below uses a window chosen to hold whole cycles; Part 11 explains this leakage properly.

**How these solutions were checked.** Everything was run with Python 3, NumPy and SciPy, and Exercise 6 with Icarus Verilog 12.0; every number is copied from an actual run.

**One correction to an exercise.** Exercise 6 originally predicted that the RTL's measured gains would not match theory to four decimal places (Part 5 has since been corrected). At the suggested amplitude of 16,000, they **do** match, to about five decimal places. The truncation error is real, and the solution measures it, but it only becomes visible with much smaller signals. The details are in Exercise 6.

## Exercise 1: find the alias by experiment

### The code

```python
#!/usr/bin/env python3
"""ex1_alias.py -- find the apparent frequency of each tone by scanning with amplitude()."""
import numpy as np

FS, N = 10_000, 1000

def amplitude(y, f):
    """Amplitude of the component of y at f cycles/sample (Part 5, section 5.5)."""
    n = np.arange(len(y))
    return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))

def fold(f, fs):
    """Folding rule (section 5.2): reduce modulo fs, then reflect anything above fs/2."""
    r = f % fs
    return (fs - r, True) if r > fs / 2 else (r, False)

n = np.arange(N)
scan = np.arange(0, 5001, 10)                          # apparent frequencies 0 .. 5 kHz, 10 Hz steps
print(" f (kHz) | peak found (Hz) | folding rule (Hz) | reflected? | sign of sine alias")
for f in [1000, 4000, 6000, 9000, 11000, 14000, 19000]:
    y = np.cos(2 * np.pi * f * n / FS)
    amps = [amplitude(y, fa / FS) for fa in scan]
    peak = scan[int(np.argmax(amps))]
    pred, refl = fold(f, FS)
    s = np.sin(2 * np.pi * f * n / FS)                 # the same tone as a sine
    c = 2 * np.mean(s * np.sin(2 * np.pi * pred * n / FS))   # projection onto +sin at the alias
    print(f"  {f/1000:5.0f}  |  {peak:13.0f}  |  {pred:15.0f}  |  {str(refl):9s} | {'+' if c > 0 else '-'} ({c:+.3f})")
```

The scan frequencies are in hertz, so each is divided by f\_s to give cycles per sample before calling `amplitude()`. For the sine version, the sign is found by projecting onto +sin(2π f\_alias n / f\_s): a result of +1 means the alias is an ordinary sine, −1 an inverted one.

### Results

| True frequency | Peak found | Folding rule | Reflected? | Sine alias |
| --- | --- | --- | --- | --- |
| 1 kHz | 1,000 Hz | 1,000 Hz | No | +1.000 |
| 4 kHz | 4,000 Hz | 4,000 Hz | No | +1.000 |
| 6 kHz | 4,000 Hz | 4,000 Hz | **Yes** | **−1.000** |
| 9 kHz | 1,000 Hz | 1,000 Hz | **Yes** | **−1.000** |
| 11 kHz | 1,000 Hz | 1,000 Hz | No | +1.000 |
| 14 kHz | 4,000 Hz | 4,000 Hz | No | +1.000 |
| 19 kHz | 1,000 Hz | 1,000 Hz | **Yes** | **−1.000** |

Every peak lies exactly where the folding rule predicts. The working, for 19 kHz: 19 mod 10 = 9 kHz, which is above f\_s/2 = 5 kHz, so it reflects to 10 − 9 = 1 kHz. For 11 kHz: 11 mod 10 = 1 kHz, below 5 kHz, so no reflection is needed.

Notice that with only seven tones, all of them land on just two frequencies, 1 and 4 kHz. After sampling, nothing in the samples distinguishes a 1 kHz tone from a 9, 11 or 19 kHz one: the information is gone.

### Why reflected sines come out inverted

At the sample instants, a tone at f is identical to one at f − k·f\_s for any whole number k, because the samples are 2π·k·n apart in phase. A **reduction** (11 → 1 kHz) is therefore exact for both cosine and sine.

A **reflection** maps f to f\_s − f, which is the same as −(f − f\_s): the tone is equivalent to one at the **negative** frequency f − f\_s. Cosine is an even function, cos(−θ) = cos θ, so a negative-frequency cosine is just a cosine at the positive frequency. Sine is odd, sin(−θ) = −sin θ, so a negative-frequency sine is an **inverted** sine at the positive frequency. That is why exactly the three reflected tones (6, 9 and 19 kHz) come out with sign −1: for example, sin(2π · 9 kHz · n/f\_s) = sin(2π · (−1 kHz) · n/f\_s) = −sin(2π · 1 kHz · n/f\_s).

## Exercise 2: your own convolution

```python
#!/usr/bin/env python3
"""ex2_convolve.py -- convolution with two nested loops, and a streaming version."""
import numpy as np

def my_convolve(x, h):
    """Full convolution: N + M - 1 outputs, y[n] = sum_k h[k] x[n-k]."""
    N, M = len(x), len(h)
    y = [0] * (N + M - 1)
    for n in range(N + M - 1):
        for k in range(M):
            if 0 <= n - k < N:                 # x is zero outside 0 .. N-1
                y[n] += h[k] * x[n - k]
    return np.array(y, dtype=np.int64)

def my_convolve_streaming(x, h):
    """First N outputs only, as the hardware produces them: one output per input sample,
    computed from a delay line that shifts by one place per sample, like the RTL's registers."""
    M = len(h)
    taps = [0] * M                             # taps[k] holds x[n-k]; all zero at reset
    out = []
    for sample in x:
        taps = [sample] + taps[:-1]            # shift in the new sample, drop the oldest
        out.append(sum(hk * tk for hk, tk in zip(h, taps)))   # the multiply-accumulate
    return np.array(out, dtype=np.int64)

rng = np.random.default_rng(1)
ok_full = ok_stream = True
for trial in range(100):
    x = rng.integers(-1000, 1001, size=rng.integers(1, 60))
    h = rng.integers(-50, 51, size=rng.integers(1, 20))
    ref = np.convolve(x, h)
    ok_full   &= np.array_equal(my_convolve(x, h), ref)
    ok_stream &= np.array_equal(my_convolve_streaming(x, h), ref[: len(x)])
print("my_convolve:           ", "PASS" if ok_full else "FAIL", "(100 random pairs)")
print("my_convolve_streaming: ", "PASS" if ok_stream else "FAIL", "(100 random pairs)")
print("by-hand example:", my_convolve([1, 3, 2, 0, -1], [1, 2, 1]), my_convolve_streaming([1, 3, 2, 0, -1], [1, 2, 1]))
```

Output:

```text
my_convolve:            PASS (100 random pairs)
my_convolve_streaming:  PASS (100 random pairs)
by-hand example: [ 1  5  9  7  1 -2 -1] [1 5 9 7 1]
```

Notes:

- **The boundary test** `0 <= n - k < N` implements "x is zero outside its samples". It is what makes the first and last M − 1 outputs correct (the filter "filling up" and "emptying").
- **Random lengths** from 1 to 59 for x and 1 to 19 for h include the edge cases where h is longer than x, or either has a single sample. Those are where off-by-one errors hide.
- **The streaming version is the RTL in Python.** `taps` is the delay-line register array, initialized to zero like a reset; `[sample] + taps[:-1]` is the shift that happens at each sample; the `sum` is the multiply-accumulate. It produces one output per input, so it gives the first N outputs of the full convolution, matching `ref[: len(x)]`.
- The by-hand example of section 5.4 comes out as \[1, 5, 9, 7, 1, −2, −1\], and its streaming version is the first five of those, exactly as the hardware would produce them.

## Exercise 3: the 1-2-1 filter, by hand and in NumPy

### By hand

Start from the definition and factor out e^{−jω}, the middle term's delay:

```latex
\begin{aligned}
H(\omega) &= \tfrac14 \left( 1 + 2e^{-j\omega} + e^{-2j\omega} \right)
           = \tfrac14 e^{-j\omega} \left( e^{j\omega} + 2 + e^{-j\omega} \right) \\
          &= \tfrac14 e^{-j\omega} \left( 2 + 2\cos\omega \right)
           = e^{-j\omega} \, \frac{1 + \cos\omega}{2}
\end{aligned}
```

Since |e^{−jω}| = 1 and (1 + cos ω)/2 is never negative:

```latex
|H(\omega)| = \frac{1 + \cos\omega}{2} = \cos^2(\omega/2)
```

| Frequency | ω | cos ω | \|H\| |
| --- | --- | --- | --- |
| 0 | 0 | 1 | **1** |
| f\_s/4 | π/2 | 0 | **½** |
| f\_s/2 | π | −1 | **0** |

NumPy confirms all three (1.0, 0.5 and 0.0). The second form, cos²(ω/2), shows that the filter is two copies of the 2-sample average ½(1, 1), whose response is |cos(ω/2)|, in series: (1, 2, 1) = (1, 1) ∗ (1, 1). Its zero at f\_s/2 is therefore a **double** zero.

### In NumPy

```python
H121 = lambda f: np.abs(0.25 * (1 + 2 * np.exp(-2j * np.pi * f) + np.exp(-4j * np.pi * f)))
H4   = lambda f: np.abs(sum(np.exp(-2j * np.pi * f * k) for k in range(4)) / 4)
```

> **Figure:** |H| computed with NumPy at 101 frequencies (shown in the [online version](https://claude.ai/artifact/7aGatSsAt9ajsS7vGeWQVa))

|  | 1-2-1 | 4-sample average |
| --- | --- | --- |
| −3 dB cutoff | **0.182** cycles/sample | 0.114 cycles/sample |
| Gain at 0.2 | 0.655 | 0.250 |
| Gain at 0.4 | 0.096 | 0.250 |
| Gain at 0.45 | **0.025** | 0.149 |
| Zeros | f\_s/2 (double) | f\_s/4 and f\_s/2 |

- **Better rejection near f\_s/2: the 1-2-1 filter.** Its double zero makes the response flat and very small near f\_s/2 (0.025 at 0.45), while the 4-sample average's second sidelobe is still at 0.149 there. The two curves cross at exactly **f = 1/3**, where both equal 0.25 (check: (1 + cos(2π/3))/2 = 0.25 and sin(4π/3)/(4 sin(π/3)) = 0.25 in magnitude).
- **Higher −3 dB cutoff: the 1-2-1 filter**, at 0.182 cycles per sample (where cos ω = √2 − 1), against 0.114 for the 4-sample average. The 1-2-1 filter keeps more of the band and only removes the top; the 4-sample average smooths much more aggressively in the middle of the band, with a zero at f\_s/4.

### Its delay

**One sample.** The factor e^{−jω} in H(ω) is a pure delay of one sample at every frequency (linear phase), multiplied by a real, non-negative amplitude. Equivalently, the coefficients (1, 2, 1) are symmetric about their middle, index 1, so the output is centered one sample behind the input. SciPy's `group_delay` gives exactly 1.0 at every frequency tested.

## Exercise 4: remove mains hum

### Choosing M for 50 Hz

An M-sample moving average has zeros at every multiple of f\_s/M (section 5.5). For a zero at 50 Hz with f\_s = 1 kHz, f\_s/M = 50 Hz, so **M = 20**.

The zeros fall at **50, 100, 150, …, 500 Hz**: every multiple of 50 Hz up to f\_s/2. That is a bonus, not a side effect: real mains interference contains **harmonics** at 100, 150, 200 Hz and so on, because power supplies and motors distort the waveform, and the same filter removes all of them.

### The simulation

```python
fs = 1000
t = np.arange(5000) / fs
x = np.sin(2 * np.pi * 2 * t) + 0.5 * np.sin(2 * np.pi * 50 * t)    # 2 Hz signal + 50 Hz hum
M = 20
y = np.convolve(x, np.ones(M) / M)[: len(x)]
ys = y[1000:4000]            # 3 s: whole cycles of 2, 50 and 60 Hz; skips the start-up
print(amplitude(ys, 2 / fs), amplitude(ys, 50 / fs))

import matplotlib.pyplot as plt
plt.plot(t[:600], x[:600], label="input"); plt.plot(t[:600], y[:600], label="output (M = 20)")
plt.xlabel("time (s)"); plt.legend(); plt.savefig("hum.png")
```

The 3-second analysis window holds exactly 6 cycles of the 2 Hz signal, 150 of the 50 Hz hum and 180 of 60 Hz, so `amplitude()` measures each without leakage. In the plot, the input is a slow sine with a fast 50 Hz ripple on it; the output is the clean slow sine, after a start-up of 20 samples.

| Case | 2 Hz amplitude after the filter | Hum amplitude after the filter (input 0.5) |
| --- | --- | --- |
| 50 Hz hum, M = 20 | 0.9974 | 7.5 × 10⁻¹⁷ (zero: rounding error of float64) |
| 60 Hz hum, M = 17 | 0.9981 | 9.86 × 10⁻³ |
| 60 Hz hum, M = 100 | 0.9355 | 8.0 × 10⁻¹⁷ (zero) |
| 50 Hz hum, M = 100 | 0.9355 | 1.2 × 10⁻¹⁶ (zero) |

Each measured value equals the theoretical gain |sin(πfM)/(M sin(πf))| to four decimal places. With M = 20, the 2 Hz signal loses only 0.26% of its amplitude, while the 50 Hz hum disappears completely.

### 60 Hz

A zero at 60 Hz needs f\_s/M = 60 Hz, so M = 1000/60 = 16.67, which is **not a whole number**. No moving average at f\_s = 1 kHz has an exact zero at 60 Hz. The nearest, M = 17, puts its zero at 58.8 Hz and leaves 9.86 × 10⁻³ of the 0.5 hum: a gain of 0.0197, about −34 dB. That may be good enough, but it is not a null.

### One M for both?

Yes. The zeros must include both 50 and 60 Hz, so f\_s/M must divide both: their greatest common divisor is **10 Hz**, so **M = 100** (zeros at every multiple of 10 Hz). It removes both completely, as the table shows. The price:

- **More loss in the passband**: the 2 Hz signal keeps 0.9355 of its amplitude (−0.58 dB) instead of 0.9974, because the main lobe is narrower (its first zero is at 10 Hz).
- **More delay**: (M − 1)/2 = 49.5 samples, or 49.5 ms, against 9.5 ms for M = 20.
- **More hardware**: a 100-sample delay line instead of 20. (A running-sum implementation, adding the new sample and subtracting the oldest, needs only two adders for any M, but still the full delay line.)

Alternatively, the sample rate can be chosen so that both work: at f\_s = 1.2 kHz, M = 24 gives a 50 Hz zero and M = 20 a 60 Hz zero. A design that must work on both kinds of mains can make M configurable, or use the 10 Hz-spaced zeros of M = f\_s/10 Hz.

## Exercise 5: two tones through the filter

### Predictions first

From the 4-sample average's response, |H(f)| = |sin(4πf) / (4 sin(πf))|:

- **At 0.05 cycles/sample**: sin(0.2π) / (4 sin(0.05π)) = 0.5878 / (4 × 0.1564) = **0.9393**.
- **At 0.3 cycles/sample**: |sin(1.2π)| / (4 sin(0.3π)) = 0.5878 / (4 × 0.8090) = **0.1816**.

The first tone lies in the passband and almost passes; the second lies beyond the filter's first zero (0.25) and is mostly removed.

### Measurement

```python
n = np.arange(5000)
x = np.cos(2 * np.pi * 0.05 * n) + np.cos(2 * np.pi * 0.3 * n)
y = np.convolve(x, np.ones(4) / 4)[: len(x)]
for f in [0.05, 0.3]:
    xs, ys = x[100:3100], y[100:3100]          # 3000 samples: whole cycles of both tones
    r = phasor(ys, f) / phasor(xs, f)          # complex gain at f
    print(f, abs(r), np.angle(r))
```

Here `phasor(y, f)` is `amplitude()` without the `abs`: `2 * np.mean(y * np.exp(-2j * np.pi * f * n))`, which keeps the phase. The ratio of output to input phasors is the complex gain H(f).

| Tone | Predicted gain | Measured gain | Measured phase | −1.5ω |
| --- | --- | --- | --- | --- |
| 0.05 | 0.9393 | **0.9393** | −0.4712 rad | −0.4712 rad |
| 0.3 | 0.1816 | **0.1816** | +0.3142 rad | −2.8274 rad |

**Why measuring each tone separately works:** the filter is **linear** (section 5.3). The output for x₁ + x₂ is the output for x₁ plus the output for x₂, so each tone passes through independently, scaled and delayed by H at its own frequency. `amplitude()` at 0.05 then picks out only the 0.05 component of the sum. (With a 3,000-sample window, which holds whole cycles of both tones, the other tone contributes exactly nothing to the projection.)

### The delay of each tone

The 4-sample average is symmetric, so it has linear phase: a delay of **(4 − 1)/2 = 1.5 samples at every frequency**, phase −1.5ω.

- **At 0.05**, the measured phase is −0.4712 rad = −1.5 × 2π × 0.05: exactly 1.5 samples.
- **At 0.3**, the measured phase is +0.3142 rad, not −1.5ω = −2.8274 rad. The difference is exactly **π**: +0.3142 = −2.8274 + π. The tone is still delayed by 1.5 samples, but it also comes out **inverted**.

The reason is the sign of the real factor in H. Written out, H(ω) = e^{−j1.5ω} · sin(2ω) / (4 sin(ω/2)): a pure delay times a **real** amplitude that changes sign at each zero of the response. For 0 < f < 0.25 it is positive. Beyond the first zero at f = 0.25 it is negative, which adds π to the phase. Plotting |H| hides this; the phase measurement reveals it. Linear-phase filters with sign changes in their amplitude are common, and it is the delay of 1.5 samples, the slope of the phase, that stays the same at every frequency.

## Exercise 6: measure your moving\_avg8 RTL

### The script

`measure_rtl.py` is the section 5.5 script with three changes: the design is `moving_avg8` (with the file-driven testbench of Part 4, Exercise 3), the model is the bit-exact `>> 3` version, and the RTL output has the input's width, so the gain needs no factor of 8:

```python
def golden(x):                            # bit-exact model of the RTL (Part 4, Exercise 3)
    return np.convolve(np.asarray(x, np.int64), np.ones(8, dtype=np.int64))[: len(x)] >> 3

def run_rtl(x):
    open("x.hex", "w").write("\n".join(to_hex(x, W)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(golden(x), W)) + "\n")
    subprocess.run(["vvp", "-n", "sim", f"+N={len(x)}"], check=True, capture_output=True)
    return from_hex("y_actual.hex", W)

def theory(f, M=8):
    return 1.0 if f == 0 else abs(np.sin(M * np.pi * f) / (M * np.sin(np.pi * f)))

for f in np.linspace(0, 0.45, 20):
    n = np.arange(N)
    x = np.round(A * np.cos(2 * np.pi * f * n)).astype(np.int64)      # A = 16000, N = 2000
    y = run_rtl(x)[100:]; xs = x[100:]
    gain = np.mean(y) / np.mean(xs) if f == 0 else amplitude(y, f) / amplitude(xs, f)
```

Because the testbench also checks every output against `golden()`, each measurement run is a bit-exact test as well.

### The impulse response

An input of 8,000 at sample 5, zeros elsewhere:

```text
impulse response (outputs 4..16): [0, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 0, 0, 0, 0]
```

Exactly as expected: **eight outputs of 8,000/8 = 1,000**, starting one cycle after the input because the output is registered, then zero. That is the impulse response h = (1/8, …, 1/8) scaled by 8,000. Since 8,000 is a multiple of 8, the shift introduces no error here.

### The frequency response

> **Figure:** measure\_rtl.py on moving\_avg8.sv (Icarus 12.0) (shown in the [online version](https://claude.ai/artifact/7aGatSsAt9ajsS7vGeWQVa))

The 20 measured gains lie on the theoretical curve. The largest difference is 6 × 10⁻⁶ (at 0.3079 and 0.4263 cycles per sample); the gain at 0 Hz is exactly 1, because a constant input of 16,000 sums to 128,000, which divides by 8 exactly.

### Why it does not match exactly, and by how much

The exercise predicted a visible mismatch; at amplitude 16,000 there is none at four decimal places. The error from `>>> 3` is real, though, and it can be measured directly.

`>>> 3` discards the low 3 bits of the sum, which **rounds down** (toward −∞). The discarded part, divided by 8, is one of 0, 1/8, 2/8, …, 7/8 of an LSB, so the output is always between 0 and 7/8 LSB **below** the exact average. With varied inputs, all eight values are equally likely, so:

- **Mean error**: −(0 + 1 + … + 7)/8/8 = **−7/16 = −0.4375 LSB**, a constant offset.
- **Standard deviation**: that of a uniform distribution over 8 equally spaced values 1/8 apart, √((8² − 1)/12)/8 = **0.2864 LSB**.

Measured on the RTL with 4,000 random full-scale samples, comparing each output with the exact sum divided by 8:

```text
error y - sum/8: min -0.8750  max 0.0000  mean -0.4385 LSB  rms 0.5232  std 0.2855
```

Mean and standard deviation match the prediction to within 0.003 LSB, and the error takes exactly the eight values 0, −1/8, …, −7/8.

**Why the gain measurement barely sees it:** the error is at most 7/8 of an LSB, while the signal is 16,000 LSB. Even if all of it landed on the measured tone, it would change the gain by about 0.29/16,000 ≈ 2 × 10⁻⁵, in the fifth decimal place, as observed. In practice the constant part (−7/16 LSB) is a DC offset, which `amplitude()` at a non-zero frequency ignores, and the varying part spreads over all frequencies.

The error becomes visible when the signal is small, because its size does not scale with the signal:

| Input amplitude A | Largest \|RTL gain − theory\| over 19 frequencies |
| --- | --- |
| 16,000 | 0.00001 |
| 200 | 0.00057 |
| 20 | 0.01538 |

And the offset is easy to see with a small sine: at A = 200, the input averages 0.088 while the RTL output averages −0.389, a difference of −0.48 LSB, close to the predicted −7/16.

Part 6 fixes both problems: rounding to nearest (add half an LSB before shifting) removes the offset, and keeping more fractional bits reduces the error itself. Part 6, Exercise 2 applies that fix to this very design.

---

That completes Part 5. Send me your plots and answers if you would like them reviewed.
