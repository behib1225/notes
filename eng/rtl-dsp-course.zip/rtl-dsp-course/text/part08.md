# Verilog & RTL for DSP — Part 8: IIR Filters

*Markdown export of the online document: https://claude.ai/artifact/Ex2RtpY2pmZrEbiQziwunA. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 8 fits

An FIR filter only looks at past **inputs**. An IIR (infinite impulse response) filter also feeds back its own past **outputs**. Feedback lets a handful of multipliers produce a response that would take an FIR filter dozens or hundreds of taps: in this part, an IIR filter of four second-order sections, **18 multipliers**, meets a specification that needs **92 FIR taps**.

Feedback has a price, and most of this part is about paying it safely. Feedback can make a filter unstable. In fixed point, it can amplify coefficient rounding into a completely different filter, keep a tiny oscillation alive forever after the input stops (a limit cycle), and turn one overflow into a sustained oscillation. In hardware, it creates a loop that no pipeline register can enter, which limits the sample rate.

You will learn:

1. The **z-transform**, poles and zeros, and the stability rule, all from scratch (8.1).
2. How to design IIR filters with SciPy, and why they are always built as a cascade of **second-order sections** (8.2).
3. Three fixed-point dangers, each demonstrated in Python (8.3).
4. A biquad section and a cascade of three in RTL, bit-exact against a Python model, with the feedback loop analyzed (8.4).
5. The measured response on the RTL, and an honest comparison with the FIR filters of Part 7 (8.5).

As always, every number comes from code that was run: Python 3 with NumPy and SciPy, Icarus Verilog 12.0, Verilator 5.020 and Yosys 0.33. The Part 6 files `fixedpoint.py` and `requant.sv` are reused.

## 8.1 Feedback and the z-transform

An IIR filter's output depends on its own past outputs. The **z-transform** turns such a recursive equation into a ratio of two polynomials, whose roots, the **zeros** and **poles**, show at a glance what the filter does and whether it is stable.

### A filter with feedback

The simplest IIR filter, from Part 5:

```latex
y[n] = x[n] + a \, y[n-1]
```

Its impulse response is 1, a, a², a³, …, which decays if |a| < 1 and grows without limit if |a| > 1. With a = 0.5 it is 1, 0.5, 0.25, …; with a = 1.1 it is 1, 1.1, 1.21, 1.33, …, an **unstable** filter whose output eventually overflows whatever the word length. An FIR filter can never do this, because it has no feedback. Stability is the first question to ask of any IIR filter.

The general second-order recursive filter, the building block of this whole part, is:

```latex
y[n] = b_0 x[n] + b_1 x[n-1] + b_2 x[n-2] - a_1 y[n-1] - a_2 y[n-2]
```

The b coefficients act on inputs, as in an FIR filter; the a coefficients feed back outputs. (The minus signs are a convention that makes the formula below tidy.)

### The z-transform, from scratch

The z-transform of a sequence x\[n\] is a polynomial in the variable z⁻¹ whose coefficients are the samples:

```latex
X(z) = \sum_{n} x[n] \, z^{-n} = x[0] + x[1]z^{-1} + x[2]z^{-2} + \cdots
```

Its most useful property: **delaying a sequence by one sample multiplies its transform by z⁻¹**. That is why a delay register is drawn as a box labelled z⁻¹. Taking the transform of both sides of the second-order equation, and collecting terms:

```latex
H(z) = \frac{Y(z)}{X(z)} = \frac{b_0 + b_1 z^{-1} + b_2 z^{-2}}{1 + a_1 z^{-1} + a_2 z^{-2}}
```

This ratio is the filter's **transfer function**. Setting z = e^{jω} (a point on the unit circle at angle ω = 2πf/f\_s) gives exactly the frequency response H(ω) of Part 5. For an FIR filter the denominator is just 1, and you get back Σ h\[k\] e^{−jωk}.

### Poles and zeros

The roots of the numerator are the **zeros**: at a zero, H(z) = 0. The roots of the denominator are the **poles**: at a pole, H(z) becomes infinite. The frequency response is H evaluated around the unit circle, so you can read it geometrically:

- A **zero on the unit circle** at angle ω₀ makes the response exactly zero at that frequency: a null.
- A **pole close to the unit circle** at angle ω₀ makes the response large near that frequency: the closer the pole, the sharper the peak.
- A low-pass filter places its poles near the unit circle along the passband edge, and its zeros on the unit circle in the stopband.

The filter of this part, a 7th-order elliptic low-pass designed in section 8.2, shows exactly that pattern:

> **Figure:** scipy.signal.ellip(7, 0.1, 60, ..., output='zpk') (shown in the [online version](https://claude.ai/artifact/Ex2RtpY2pmZrEbiQziwunA))

Its seven poles all lie inside the circle at angles up to 0.082 cycles per sample, just inside the passband edge of 0.08; the outermost is at radius 0.976. Its seven zeros lie exactly on the circle in the stopband, at 0.105, 0.121, 0.185 and 0.5 cycles per sample, which produce the deep nulls you will see in its measured response.

### The stability rule

Each pole p contributes a term like pⁿ to the impulse response. So:

**An IIR filter is stable if and only if every pole lies strictly inside the unit circle, |p| < 1.**

A pole at radius 0.976 decays slowly: its contribution falls by a factor of e after about 1/(1 − 0.976) ≈ 42 samples. That is why sharp IIR filters ring for a long time, and why section 8.3 worries so much about tiny coefficient errors: moving a pole from 0.976 to just above 1.0 turns a good filter into an oscillator.

An FIR filter's poles are all at z = 0 (the denominator is 1), so FIR filters are always stable.

### Check your understanding: 8.1

1. Write the transfer function of y\[n\] = x\[n\] + 0.9 y\[n−1\]. Where is its pole? Is it stable? Low-pass or high-pass?
2. A section has poles at radius 0.99 and angle ±0.1 cycles per sample. Describe its frequency response near 0.1 cycles per sample.
3. Why does a zero exactly on the unit circle produce a perfect null?
4. A filter has a pole at z = −1.02. What does its impulse response look like?
5. Why can't an FIR filter be unstable?

#### Answers

1. H(z) = 1 / (1 − 0.9 z⁻¹). The pole is at **z = 0.9**, inside the unit circle: **stable**. It lies at angle 0 (zero frequency), so the response peaks at 0 Hz: a **low-pass** filter (gain 1/(1 − 0.9) = 10 at DC, 1/1.9 ≈ 0.53 at f\_s/2).
2. A sharp peak: the denominator nearly vanishes when z = e^{jω} passes close to the pole, so the gain near 0.1 cycles per sample is large and narrow. Such a section is a resonator, used for example to detect one tone.
3. The frequency response is the transfer function evaluated on the unit circle. If a zero lies exactly on it, the numerator is exactly 0 at that frequency, so the gain is exactly 0.
4. The pole contributes (−1.02)ⁿ: an oscillation that flips sign every sample (frequency f\_s/2) and **grows** by 2% per sample. The filter is unstable.
5. Its transfer function has denominator 1, so all its poles are at z = 0, inside the unit circle. Equivalently, its impulse response is finite, so it cannot grow forever.

## 8.2 Designing IIR filters with SciPy

IIR filters are designed from classical analog prototypes, Butterworth, Chebyshev and elliptic, which SciPy converts to digital form in one call. For the specification of Part 7 (passband to 0.08 cycles per sample with 0.1 dB ripple, stopband from 0.12 cycles per sample at 60 dB), an elliptic filter needs **order 7**, where a Kaiser-window FIR filter needs **92 taps**.

### The four classic families

SciPy's order-estimation functions answer "what is the lowest order that meets this specification?". The frequencies are given as fractions of the Nyquist frequency, as in `firwin`:

```python
from scipy import signal
for name, fn in [("ellip", signal.ellipord), ("cheby1", signal.cheb1ord),
                 ("cheby2", signal.cheb2ord), ("butter", signal.buttord)]:
    n, wn = fn(0.16, 0.24, 0.1, 60)       # wp, ws (x Nyquist), ripple dB, attenuation dB
    print(name, "order", n)
```

| Family | Order needed | Passband | Stopband | Phase |
| --- | --- | --- | --- | --- |
| Elliptic | **7** | Equal ripple | Equal ripple | Least linear |
| Chebyshev type I | 10 | Equal ripple | Smoothly falling | Non-linear |
| Chebyshev type II | 10 | Flat | Equal ripple | Non-linear |
| Butterworth | 21 | Maximally flat | Smoothly falling | Most gentle |

The elliptic filter is the most efficient because it lets the ripple spread through both bands. The Butterworth is the smoothest but needs three times the order. For comparison, the FIR alternatives were 92 taps with a Kaiser window, or fewer with Parks–McClellan (Part 7, Exercise 1).

### Second-order sections

Design it, asking for the coefficients as **second-order sections** (SOS):

```python
n, wn = signal.ellipord(0.16, 0.24, 0.1, 60)
sos = signal.ellip(n, 0.1, 60, wn, output="sos")
print(sos)
```

```text
[[ 0.002052  0.002052  0.        1.       -0.780738  0.      ]
 [ 1.       -0.794913  1.        1.       -1.588734  0.691433]
 [ 1.       -1.45176   1.        1.       -1.641971  0.838941]
 [ 1.       -1.58254   1.        1.       -1.698035  0.953234]]
```

Each row is one **biquad**, written b₀ b₁ b₂ a₀ a₁ a₂ (a₀ is always 1). An odd order leaves one first-order section, the first row, whose b₂ and a₂ are 0. The cascade multiplies the four transfer functions: H(z) = H₁(z)·H₂(z)·H₃(z)·H₄(z).

You could also ask for one big transfer function, `output="ba"`, a 7th-order numerator over a 7th-order denominator. **Never implement that directly.** Its denominator coefficients for this filter are 1, −5.71, 14.43, −20.83, 18.54, −10.14, 3.16, −0.43: large numbers of alternating sign that nearly cancel, so tiny rounding errors in them move the poles a long way. Section 8.3 measures exactly how far. Each biquad, in contrast, has small coefficients that control just two poles, so rounding errors stay local. **Every practical IIR implementation is a cascade of second-order sections.**

### The cost

A biquad needs at most five multiplications per sample (b₀, b₁, b₂, a₁, a₂), and the first-order section three. This filter therefore needs 3 + 3 × 5 = **18 multiplications per sample**, against 92 for the direct-form FIR, or 46 with the symmetric form of Part 7. In hardware, that is 18 DSP blocks instead of 46, which is exactly what synthesis reports in section 8.4.

The savings grow with the sharpness of the specification, because FIR length grows inversely with the transition width while IIR order grows only slowly. The price is paid in phase linearity (section 8.5) and fixed-point care (section 8.3).

### Check your understanding: 8.2

1. Why does the elliptic filter need a lower order than the Butterworth for the same specification?
2. What do `0.16` and `0.24` mean in the `ellipord` call, in cycles per sample?
3. The design has order 7. How many sections does it have, and why is one of them different?
4. How many multiplications per sample would a 10th-order Chebyshev type I filter need as a cascade?
5. Why are most biquads in this design given with b₀ = b₂ = 1?

#### Answers

1. The Butterworth response is maximally flat in the passband and falls smoothly, so it "wastes" accuracy where the specification allows ripple. The elliptic filter uses the full allowed ripple in both bands, which lets it fall much faster for the same number of poles.
2. They are fractions of the Nyquist frequency (0.5 cycles per sample): 0.16 × 0.5 = **0.08** and 0.24 × 0.5 = **0.12** cycles per sample.
3. **Four** sections: three biquads and one **first-order** section, because each biquad holds two poles and seven is odd.
4. 10th order = 5 biquads × 5 multiplications = **25**.
5. Each pair of zeros lies on the unit circle, so the section's numerator is (1 − z₀z⁻¹)(1 − z₀\*z⁻¹) = 1 − 2cos(θ)z⁻¹ + z⁻², which has b₀ = b₂ = 1. SciPy puts the filter's overall gain into the first section (b₀ = 0.002052). Section 8.3 redistributes that gain to keep the internal signals well scaled.

## 8.3 IIR filters in fixed point: three dangers

In an FIR filter, a rounding error passes through once and is gone. In an IIR filter, it is fed back and circulates. This section demonstrates the three consequences in Python, and the design choices that defuse each one: **second-order sections** against coefficient sensitivity, **gain scaling** against overflow, and **extra fractional bits in the state** against limit cycles.

### Danger 1: coefficient quantization moves the poles

Quantize the coefficients, compute where the poles end up, and compare the largest pole radius with the true value, 0.97634, for the one-polynomial (`ba`) form and the second-order sections:

| Fractional bits in the coefficients | Largest pole radius, one polynomial | Largest pole radius, sections |
| --- | --- | --- |
| 16 | 0.97624 | 0.97634 |
| 14 | 0.97475 | 0.97634 |
| 12 | 0.98129 | 0.97628 |
| 10 | **1.04528 (unstable)** | 0.97628 |

With sections, the poles barely move even at 10 bits. As one polynomial, they wander at 14 bits and leave the unit circle at 10: the filter oscillates.

The effect gets dramatically worse for sharper filters. A 10th-order elliptic low-pass with a cutoff of 0.025 cycles per sample, whose poles sit at radius 0.997, has polynomial coefficients as large as 217. Quantized with **20** fractional bits as one polynomial, its largest pole moves to radius **1.155**: unstable. As sections with only 16 fractional bits, its poles stay at 0.99703. Narrow filters at high sample rates, common in receivers, are where this matters most.

### Danger 2: overflow inside the filter

SciPy puts the whole gain of the filter into the first section, whose b₀ is 0.002, so the first section's output is tiny and the later sections, each with gains well above 1 at some frequencies, carry most of the swing. Poorly distributed gain wastes bits in some sections and overflows others.

The standard fix is **L∞ scaling**: choose each section's numerator gain so that the response from the filter's input to that section's output peaks at exactly 1. Then a full-scale sine wave never exceeds full scale at any intermediate point:

```python
def scale(sos):
    """L-infinity scaling: choose each section's numerator gain so that the response
    from the input to that section's output peaks at exactly 1."""
    sos = sos.copy()
    for k in range(len(sos)):
        _, h = signal.sosfreqz(sos[: k + 1], worN=8192)
        sos[k, :3] /= np.max(np.abs(h))
    return sos
```

The scaled coefficients (b₀, b₁, b₂, a₁, a₂ per section):

| Section | b₀ | b₁ | b₂ | a₁ | a₂ |
| --- | --- | --- | --- | --- | --- |
| 1 (first order) | 0.10963 | 0.10963 | 0 | −0.78074 | 0 |
| 2 | 0.08522 | −0.06774 | 0.08522 | −1.58873 | 0.69143 |
| 3 | 0.35928 | −0.52159 | 0.35928 | −1.64197 | 0.83894 |
| 4 | 0.61131 | −0.96743 | 0.61131 | −1.69803 | 0.95323 |

All of them are below 2 in magnitude, so they fit **Q2.16** (18 bits, a DSP48E1's B port). The pole coefficients a₁ are close to −2, which is why one integer bit plus the sign is needed.

L∞ scaling is a guarantee for sinusoids only. Signals with sharp edges can still exceed it, because a sharp filter **overshoots** on a step. Running the test stimulus of section 8.4 (which contains a full-scale step and a square wave) through the scaled filter in floating point, the internal signals peaked at 1.00, 1.02, 1.11 and **1.29** after sections 1 to 4. So the internal signals get headroom: they are carried as **Q4.20** (24 bits, range ±8) between sections, and only the final output is rounded to Q1.15 and saturated.

Saturation, not wrap-around, is essential **inside** a recursive filter. A wrapped overflow turns a large positive value into a large negative one, which the feedback treats as a huge new input. In a resonant section this can start an oscillation of full-scale amplitude that never stops: an **overflow oscillation**. Saturation limits the damage to a temporary distortion.

### Danger 3: limit cycles

Take the sharpest section (poles at radius 0.976), give it an impulse, then feed it zeros forever. In exact arithmetic its output decays to zero. With the state rounded to 15 fractional bits, it does not:

```text
last 12 outputs (in LSBs): [ 0 -1 -2 -2 -1  0  1  2  2  1  0 -1]
```

The output settles into a permanent oscillation of ±2 LSB with a period of 12 samples, which is 0.083 cycles per sample, right at the pole angle of 0.082. This is a **zero-input limit cycle**. Near zero, the rounding error is as large as the signal itself, and the rounding can push the value back up every time it should decay: the loop behaves as if the pole were exactly on the unit circle.

Over the last 500 samples of a 3,000-sample run:

| State format and rounding | Limit cycle? | Amplitude |
| --- | --- | --- |
| 15 fractional bits, round half up | Yes | ±2 LSB |
| 15 fractional bits, convergent rounding | Yes | ±2 LSB |
| 15 fractional bits, floor (truncation) | No, decays to 0 | — |
| 20 fractional bits, round half up | Yes | ±2 LSB of 2⁻²⁰ |

Two practical cures:

- **Keep more fractional bits in the state than in the output.** The cycle is still there with 20 fractional bits, but its amplitude, 2 × 2⁻²⁰, is 8 times smaller than half an LSB of the Q1.15 output (2⁻¹⁶), so it disappears in the final rounding. The full four-section cascade, fed one impulse and then 4,000 zeros, produced its last non-zero output at sample 311 and exactly 0 from then on. This is the approach used in section 8.4.
- **Truncate toward zero (magnitude truncation)** in the feedback, which always shrinks the state and so cannot sustain a cycle. Plain floor truncation happened to work for this section, but floor rounds negative values away from zero, and in other sections it can lock onto a small constant negative output. Magnitude truncation is the textbook guarantee.

For most applications, a few extra state bits are the simplest cure. For audio, where a −90 dB idle tone may be audible, designers check carefully.

### Accuracy of the final design

With Q2.16 coefficients, Q4.20 internal signals, one rounding per section and a Q1.15 output, the fixed-point cascade matched the floating-point filter (with the same quantized input) to an SNR of **75.3 dB** on 20,000 random samples. The 16-bit output rounding is the limiting factor, just as for the FIR filter in Part 7.

### Check your understanding: 8.3

1. Why do the coefficients of a 7th-order polynomial behave so much worse under quantization than those of four biquads?
2. Why are the a₁ coefficients stored in Q2.16 rather than Q1.17?
3. The scaled filter has internal peaks of 1.29. What would have happened with internal signals in Q1.23 (24 bits, range ±1) and saturation?
4. Why does a limit cycle appear at the angle of the poles?
5. Why would wrap-around inside the feedback loop be far more dangerous than in an FIR filter?

#### Answers

1. The roots of a high-order polynomial are extremely sensitive to its coefficients when the roots are clustered, and these poles are clustered near the passband edge. Each coefficient of the polynomial depends on all seven poles, so one rounding error disturbs them all. A biquad's two coefficients depend only on its own pair of poles, so errors stay local and small.
2. They are close to −2 (−1.70 for the last section). Q1.17 covers only \[−1, +1), so they would not fit. Q2.16 covers \[−2, +2), at the cost of one fractional bit.
3. The step and square-wave parts of the test would have saturated inside the filter at sections 2 to 4 (peaks 1.02 to 1.29), distorting the output, and the distortion would then circulate through the later sections' feedback. With Q4.20, those peaks pass unharmed, and only the final output saturates.
4. Near zero, the loop's rounding effectively cancels the decay, so the section behaves like an undamped resonator, whose natural frequency is set by the pole angle.
5. In an FIR filter, a wrapped value affects only the outputs computed from it, for at most N samples. In an IIR filter, the wrapped value is fed back as a huge error and can excite the resonant poles indefinitely, producing a full-scale overflow oscillation.

## 8.4 The biquad in RTL

One parameterized module implements a biquad section; a second chains four of them into the 7th-order filter. Each section computes the exact sum of its five products and rounds once, exactly as the Python model does, and the cascade passed the bit-exact test on its first run.

### Direct form I

There are several ways to arrange a biquad's delays. **Direct form I** keeps separate delays for the inputs (x\[n−1\], x\[n−2\]) and the outputs (y\[n−1\], y\[n−2\]). It uses four state registers instead of the two of direct form II, but it has a single adder and a single rounding point, so its only internal overflow risk is the output itself, which `requant` saturates. That makes it the safest form for fixed point, and the easiest to model bit-exactly.

> **Figure:** direct-form-I biquad (iir\_biquad.sv) (shown in the [online version](https://claude.ai/artifact/Ex2RtpY2pmZrEbiQziwunA))

### The section

```systemverilog
`timescale 1ns/1ps
// iir_biquad.sv -- one second-order section, direct form I:
//   y[n] = b0 x[n] + b1 x[n-1] + b2 x[n-2] - a1 y[n-1] - a2 y[n-2]
// Exact sum of the five products, ONE rounding to the internal format, saturation.
// One sample per clock at most: the feedback loop (multiply, add, round) must
// finish within one clock cycle, so it cannot be pipelined.
module iir_biquad #(
  parameter int SEC = 0,                        // which coefficient set (iir_coefs.svh)
  parameter int SW = 24, SF = 20,               // signal format: Q4.20
  parameter int CW = 18, CF = 16,               // coefficient format: Q2.16
  parameter int ACC_W = SW + CW + 3             // 45: five products, never overflows
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  input  logic signed [SW-1:0] x,
  output logic                 out_valid,
  output logic signed [SW-1:0] y
);
  `include "iir_coefs.svh"
  localparam logic signed [CW-1:0] B0 = iir_coef(SEC, 0), B1 = iir_coef(SEC, 1),
                                   B2 = iir_coef(SEC, 2), A1 = iir_coef(SEC, 3),
                                   A2 = iir_coef(SEC, 4);

  logic signed [SW-1:0]    x1, x2, y1, y2;      // the section's state
  logic signed [ACC_W-1:0] acc;
  logic signed [SW-1:0]    y0;
  logic                    unused_ovf;

  // the whole loop is combinational: from y1/y2 back to y1 in one clock
  assign acc = ACC_W'(B0 * x) + ACC_W'(B1 * x1) + ACC_W'(B2 * x2)
             - ACC_W'(A1 * y1) - ACC_W'(A2 * y2);

  requant #(.IN_W(ACC_W), .IN_F(SF + CF), .OUT_W(SW), .OUT_F(SF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(y0), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) begin
      {x1, x2, y1, y2} <= '0;                    // start at rest: the model assumes it
      out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        x2 <= x1;  x1 <= x;
        y2 <= y1;  y1 <= y0;
        y  <= y0;
      end
    end
  end
endmodule
```

Notes:

- **Coefficients as `localparam`s.** `iir_coefs.svh` is generated by `iir_model.py`, like the FIR coefficient file of Part 7, but with two arguments: `iir_coef(section, k)`. Calling it with constant arguments in a `localparam` gives each instance its own fixed coefficients.
- **Widths.** Products of a 24-bit signal and an 18-bit coefficient are 42 bits (Q6.36); the sum of five needs 3 more: `ACC_W` = 45, within a DSP block's 48. `requant` drops 16 fractional bits to return to Q4.20.
- **The state is reset**, because the model starts at rest (Part 7's lesson). Here it matters even more: an unreset feedback state would ring for hundreds of samples.

### The cascade

```systemverilog
`timescale 1ns/1ps
// iir_cascade.sv -- the 7th-order elliptic low-pass: four biquads in series.
// Q1.15 in -> Q4.20 inside -> Q1.15 out (rounded, saturated). One sample per clock.
module iir_cascade #(
  parameter int NSEC = 4,
  parameter int XW = 16, XF = 15, SW = 24, SF = 20
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  assign in_ready = 1'b1;

  logic signed [SW-1:0] s [0:NSEC];               // signals between sections
  logic                 v [0:NSEC];

  // Q1.15 -> Q4.20: sign-extend and append (SF - XF) zero fraction bits
  assign s[0] = {{(SW - XW - (SF - XF)){x[XW-1]}}, x, {(SF - XF){1'b0}}};
  assign v[0] = in_valid;

  for (genvar k = 0; k < NSEC; k++) begin : g_sec
    iir_biquad #(.SEC(k), .SW(SW), .SF(SF)) u_bq (
      .clk(clk), .rst(rst), .in_valid(v[k]), .x(s[k]), .out_valid(v[k+1]), .y(s[k+1])
    );
  end

  logic signed [XW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(SW), .IN_F(SF), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1))
    u_out (.din(s[NSEC]), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= v[NSEC];
    if (v[NSEC]) y <= y_c;
  end
endmodule
```

The ports are exactly those of the Part 7 FIR filters, so `tb_fir.sv` from Part 7 verifies it unchanged, with `-DDUT=iir_cascade`. The first section's input is Q1.15 converted to Q4.20 by concatenation: 3 copies of the sign bit, the 16 input bits, and 5 zero fraction bits. A `for` loop with a `genvar` directly in the module body is a SystemVerilog shorthand for a `generate` loop.

### The bit-exact model

The golden model in `iir_model.py` runs the same integer arithmetic sample by sample:

```python
def golden(xq, cq):
    """Bit-exact model of the RTL cascade."""
    v = np.asarray(xq, dtype=np.int64) << (SF - XF)          # Q1.15 -> Q4.20
    for b0, b1, b2, a1, a2 in [tuple(int(t) for t in row) for row in cq]:
        x1 = x2 = y1 = y2 = 0
        out = np.empty_like(v)
        for n, x0 in enumerate(v.tolist()):
            acc = b0 * x0 + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2          # exact, Q?.36
            y0 = int(requant(np.array([acc]), SF + CF, SW, SF, "round", "saturate")[0])
            out[n] = y0
            x2, x1, y2, y1 = x1, x0, y1, y0
        v = out
    return requant(v, SF, XW, XF, "round", "saturate")
```

Unlike the FIR model, it cannot use `np.convolve`: each output depends on the rounded previous outputs, so the loop must run sample by sample, just like the hardware. The test stimulus adds two IIR-specific patterns to Part 7's: a full-scale **step** and a **square wave** near the cutoff, both of which make the filter overshoot and saturate at the output. The model counted 126 saturated outputs.

Result: `PASS: 3000 outputs bit-exact` on the first run, on three more seeds, and lint-clean in Verilator.

### Synthesis

Yosys reports **18 DSP48E1** blocks: 5 for each biquad and 3 for the first-order section (its b₂ and a₂ are 0, so those multipliers vanish), matching the count of section 8.2. Around them are about 590 LUTs and 107 `CARRY4` for the five-input additions and the rounding logic.

### The loop that cannot be pipelined

In every FIR architecture of Part 7, pipeline registers could be inserted anywhere, because data only flows forward. Here, y\[n\] needs y\[n−1\], computed in the previous cycle: the path from `y1` through two multipliers, the adder and `requant`, back into `y1`, must complete in **one clock period**. Adding a register inside that loop would delay y\[n−1\] by an extra cycle and compute a different filter.

So the maximum sample rate of a recursive section is set by its loop delay, not by how much pipelining you are willing to add. When that is too slow, designers have three options:

1. **Run at a lower sample rate** than the clock, allowing the loop several cycles (with a multicycle timing constraint, or a time-multiplexed design as in Part 7).
2. **Interleave independent channels** (C-slow processing): with M independent signals taking turns, the loop may contain M registers, because each channel's previous output is M cycles old. This is common in multi-channel audio.
3. **Transform the algorithm** (look-ahead techniques) to rewrite y\[n\] in terms of y\[n−2\] or older, which allows pipeline registers at the cost of extra multipliers. This is beyond this course.

### Check your understanding: 8.4

1. Why can't you add a pipeline register between `acc` and `y1` to speed up the section?
2. Why does direct form I need four state registers, and direct form II only two?
3. Why can't the golden model use `np.convolve` or `scipy.signal.sosfilt` for a bit-exact result?
4. How many DSP blocks would a 10th-order design (five biquads) need?
5. A stereo audio system needs this filter for two channels at 48 kHz with a 100 MHz clock. How would you implement it with the fewest DSP blocks?

#### Answers

1. The register would make the fed-back value two samples old instead of one, so the hardware would compute y\[n\] = … − a₁y\[n−2\] − a₂y\[n−3\], a different (and probably unstable) filter. Registers can only be added outside the loop.
2. Direct form I stores two past inputs and two past outputs. Direct form II applies the feedback first to an intermediate signal w\[n\] and shares one two-register delay line between the feedback and feedforward parts. It saves registers but has an internal node, w\[n\], that can overflow, which makes it harder to scale.
3. Those compute in floating point, without the hardware's rounding after every section, and the rounded outputs feed back into later samples. Only a sample-by-sample integer model, rounding exactly where the RTL rounds, reproduces every bit.
4. **25** if every coefficient is non-zero (5 per biquad).
5. 100 MHz / 48 kHz ≈ 2,083 clocks per sample, so time-share: one or a few multipliers, sequencing 18 multiplications per channel per sample (36 in total) through a MAC with a controller, as in Part 7's serial FIR, keeping each section's state for both channels in a small memory. One DSP block is enough.

## 8.5 Measuring the cascade, and IIR versus FIR

The sine-sweep method of Part 7 works unchanged on the IIR cascade: `measure_iir.py` sends 20 cosines of amplitude 0.5 through the RTL (each run also checked bit-exactly), skips the first 1,000 outputs because a sharp IIR filter takes hundreds of samples to settle, and measures the gain.

> **Figure:** measure\_iir.py on iir\_cascade.sv (Icarus 12.0), 6,000 samples per tone, amplitude 0.5 (shown in the [online version](https://claude.ai/artifact/Ex2RtpY2pmZrEbiQziwunA))

The RTL matches the floating-point design within 0.1 dB everywhere down to about −66 dB, within 0.25 dB down to −73 dB, and within 0.5 dB at the deepest points near −83 dB, where the measurement reaches the output's rounding noise. The 0.1 dB passband ripple and the sharp edge between 0.08 and 0.105 cycles per sample are reproduced exactly.

### IIR versus FIR for the same specification

|  | Elliptic IIR (this part) | Kaiser-window FIR, 92 taps |
| --- | --- | --- |
| Multipliers at one sample per clock | 18 | 92, or 46 with the symmetric form |
| Phase | Non-linear | Exactly linear |
| Delay | 8 to 38 samples, depending on frequency | 45.5 samples at every frequency |
| Stability | Must be checked; can be lost by quantization | Always stable |
| Fixed-point design | Sections, scaling, limit cycles, saturation | Coefficient width and one rounding |
| Maximum sample rate | Limited by the feedback loop | Any, with enough pipelining |
| Coefficients after quantization | Different filter if done carelessly | Small, predictable change |

The phase row deserves a closer look. SciPy's `group_delay` gives the IIR filter's delay at several frequencies:

| Frequency (cycles per sample) | 0.01 | 0.04 | 0.06 | 0.075 | 0.079 |
| --- | --- | --- | --- | --- | --- |
| IIR delay (samples) | 8.1 | 9.9 | 13.7 | 24.6 | 38.0 |
| FIR delay (samples) | 45.5 | 45.5 | 45.5 | 45.5 | 45.5 |

The IIR filter delays low frequencies far less than the FIR filter, which is an advantage in control loops and live audio, but it delays frequencies near the band edge almost five times more than low ones. A sharp pulse that contains many frequencies therefore comes out smeared: its components arrive at different times. For audio this is usually inaudible; for data communications and measurement, where the waveform shape carries the information, it is often unacceptable, and FIR filters are preferred.

### When to choose which

- **Choose IIR** when multipliers are scarce, the specification is sharp, low delay matters more than waveform shape, and the sample rate leaves time for the feedback loop: audio equalizers, sensor and control filtering, simple DC-blocking and smoothing filters.
- **Choose FIR** when phase must be linear, when the filter changes at run time (adaptive filters), when the sample rate is very high, or when it is part of a sample-rate change: decimation and interpolation filters (Part 10) are almost always FIR, because their structure lets most multiplications be skipped.

### Check your understanding: 8.5

1. Why does the measurement skip the first 1,000 outputs, when the FIR measurement in Part 7 skipped only 200?
2. The IIR delay is 38 samples at 0.079 cycles per sample. Which feature of the pole-zero plot causes such a large delay near the band edge?
3. A pulse-shaping filter for a data modem must not distort symbol shapes. IIR or FIR?
4. A battery-powered sensor filters one signal at 1 kHz with a tiny microcontroller-sized FPGA. IIR or FIR?
5. Why is a sharp IIR filter's group delay largest near its passband edge?

#### Answers

1. The IIR impulse response decays slowly: the outermost pole at radius 0.976 needs hundreds of samples to die away (the impulse response reached exactly zero only at sample 311). The 32-tap FIR filter's start-up transient is over after 32 samples.
2. The poles at radius 0.976 lie close to the unit circle at that angle. A pole near the circle causes a rapid change of phase with frequency there, and group delay is the rate of change of phase.
3. **FIR**: its linear phase delays all frequencies equally and preserves the symbol shapes.
4. **IIR**: very few multipliers for a sharp response, a low sample rate leaves plenty of time for the feedback loop, and waveform shape rarely matters for sensor smoothing.
5. Sharp filters put their poles close to the unit circle near the passband edge, and near such a pole the phase turns quickly with frequency. Group delay measures that rate of change (the negative derivative of the phase), so it peaks there.

## 8.6 Exercises

For scale: their worked solutions add 3 design files, 1 testbench and 1 Python script, about 310 new lines (not counting short checks run inline). Time depends too much on experience for a reliable estimate, so none is given. Reuse `iir_model.py`, `run_iir.sh` and the Part 7 testbench. Send me your code, tables and plots.

- [ ] Exercise 1: a DC blocker
- [ ] Exercise 2: watch a filter go unstable
- [ ] Exercise 3: provoke an overflow oscillation
- [ ] Exercise 4: a Butterworth cascade
- [ ] Exercise 5: one DSP block for the whole filter

### Exercise 1: a DC blocker

The DC blocker y\[n\] = x\[n\] − x\[n−1\] + a·y\[n−1\], with a = 0.995, removes a constant offset while passing everything else: one of the most common IIR filters in practice.

- Find its pole and zero, sketch the pole-zero plot, and plot its magnitude response. What is its −3 dB cutoff at f\_s = 48 kHz?
- Implement it as a single `iir_biquad` instance (which coefficients are zero?), with a bit-exact model, and verify it.
- Feed it a sine wave plus a constant offset of 0.3 and plot input and output. How many samples does the offset take to fall below one output LSB?

### Exercise 2: watch a filter go unstable

- Implement the 10th-order filter of section 8.3 (cutoff 0.025 cycles per sample, 80 dB) as five sections with the same RTL, and verify it.
- In Python, quantize it as one polynomial with 20 fractional bits and simulate it with `scipy.signal.lfilter` on a short impulse. Plot the output growing.
- Find the smallest number of fractional bits for which the one-polynomial form is stable, and compare it with the sections.

### Exercise 3: provoke an overflow oscillation

- Copy `requant.sv` and `fixedpoint.requant()` and switch the sections to **wrap** instead of saturate (`SAT = 0`), and the internal format to Q1.23 so that overflow is likely.
- Feed the cascade a burst of full-scale square wave, then zeros. Compare the output with the saturating version. Does the wrapping version ever recover?
- Explain what you see in terms of section 8.3.

### Exercise 4: a Butterworth cascade

- Design the Butterworth filter that meets the same specification (order 21, 11 sections). Apply L∞ scaling and check whether all coefficients still fit Q2.16.
- Implement and verify it with `NSEC = 11`. How many DSP blocks does Yosys report? Compare its group delay with the elliptic filter's at the same five frequencies.
- Was the extra cost worth anything? Name an application where it would be.

### Exercise 5: one DSP block for the whole filter

For a 48 kHz audio rate on a 100 MHz clock, build `iir_serial`: a controller that sequences all 18 multiplications of the cascade through a single MAC, with the section states in registers (or a small memory).

- Draw the ASM chart first. Each section's five products must be accumulated, rounded once and saturated, then fed back, exactly as in the parallel version, so the same bit-exact model applies.
- Use `in_ready` to accept one sample, process all four sections, then accept the next. How many cycles per sample does your design need?
- Extend it to two independent channels (stereo). What changes in the state storage?

## 8.7 Summary and what comes next

You can now design an IIR filter, judge its stability from its poles, make it safe in fixed point, build it as a cascade of biquads, and verify it bit-exactly. Keep this table beside you for the exercises.

| Topic | Key fact | Remember |
| --- | --- | --- |
| z-transform | A delay is a multiplication by z⁻¹ | H(z) = B(z)/A(z); z = e^{jω} gives the frequency response |
| Poles and zeros | Zeros on the circle: nulls; poles near it: peaks | Read the response from the plot |
| Stability | Every pole strictly inside the unit circle | FIR filters are always stable |
| Design | `ellipord` + `ellip(..., output="sos")` | Elliptic: lowest order; Butterworth: smoothest |
| Structure | Cascade of second-order sections | Never one high-order polynomial |
| Scaling | L∞: each partial cascade peaks at 1 | Keep headroom for overshoot |
| Coefficients | Biquad a₁ is near −2 | Q2.16 for an 18-bit DSP port |
| Overflow | Saturate inside the loop | Wrapping can cause overflow oscillation |
| Limit cycles | Rounding in a loop can sustain small oscillations | Extra state bits hide them below the output LSB |
| Direct form I | One adder, one rounding point per section | Easiest to model bit-exactly |
| Bit-exact model | Sample-by-sample integer loop | `np.convolve` and `sosfilt` cannot match bits |
| Speed | The feedback loop cannot be pipelined | Lower rate, interleave channels, or look-ahead |
| IIR vs FIR | Far fewer multipliers, but non-linear phase | FIR for phase, adaptivity and rate changes |

The ideas that matter most from this part:

1. Feedback buys sharpness with few multipliers, at the price of stability, phase linearity and fixed-point care.
2. Every practical IIR filter is a cascade of second-order sections, scaled, with headroom and saturation.
3. A recursive loop sets a hard limit on the sample rate of a single section; pipelining stops at the loop.
4. Bit-exact verification still works with feedback, as long as the model rounds exactly where the hardware does.

**Part 9: NCO, CORDIC and mixers** turns from filtering to generating and shifting signals. You will build a numerically controlled oscillator (a phase accumulator and a sine lookup table) that produces any frequency with microhertz resolution, the CORDIC algorithm that computes sines, cosines and angles with only shifts and adds, and a complex mixer that moves a signal from one frequency to another: the first stage of every digital radio receiver, and of the down-converter you will build in Part 12.

### Further reading: the z-transform, poles and zeros

This part relies on transfer functions, poles and zeros. [Appendix C: The Mathematics Behind the DSP Parts](https://claude.ai/artifact/2HA6TpUNfXT1oUGK8nfuyq) derives them from the difference equation, with a resonator worked out by hand (pole radius and angle to a₁ and a₂, peak frequency and bandwidth, all checked numerically) and the reason second-order sections are so much less sensitive than one high-order polynomial.
