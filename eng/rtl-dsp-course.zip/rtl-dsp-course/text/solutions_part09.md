# Verilog & RTL for DSP — Solutions to Part 9

*Markdown export of the online document: https://claude.ai/artifact/E1amagyV6G3r57CPTXGFYy. Diagrams and charts appear only online; each is marked below with its title.*


Oct 21, 2026 · @Behi

## How to use these solutions

These are worked solutions to the five exercises of Part 9. Try each one first; the "Check your understanding" answers are in Part 9 itself.

**How these solutions were checked.** Everything was run with Python 3 and NumPy, Icarus Verilog 12.0 (`-g2012 -Wall`), Verilator 5.020 (`--lint-only -Wall`) and Yosys 0.33. Every RTL design is bit-exact against a Python model on random data with random gaps in its valid signal, and every number below is copied from an actual run. The designs reuse `nco.sv`, `cordic.sv`, `requant.sv`, the table files and `dds_model.py` from Part 9.

### Three Yosys 0.33 limitations

The designs below first simulated and linted cleanly, then failed in Yosys. All three are worth remembering, because the other two tools accept the code:

| Construct | Yosys 0.33 says | Portable form |
| --- | --- | --- |
| `parameter string QFILE = "..."` | `syntax error, unexpected TOK_ID` | an untyped `parameter QFILE = "..."` |
| `return v;` in a function | `syntax error, unexpected TOK_ID` | assign the function name: `qsin = v;` |
| `-(W+1)'(s)` | `Static cast with zero or negative size!` | parenthesize: `-((W+1)'(s))` |

The third is the precedence trap already met in Part 9's CORDIC: Yosys reads the minus sign as part of the cast's width. The rule from Part 9 holds: **a design is not finished until it synthesizes**.

One more change, made for Exercises 3 and 4: `cordic_atan.svh` was regenerated with 24 angle entries instead of 16, because a 20-iteration CORDIC reads entries 16 to 19, and the original file returns 0 for them (its `default`). The first 20-iteration simulation was not bit-exact with the model for exactly that reason.

## Exercise 1: a tunable signal generator

### The RTL

```systemverilog
`timescale 1ns/1ps
// nco_po.sv -- the Part 9 NCO with a phase-offset input: output = cos/sin(phase + offset).
// The 16-bit offset is a binary angle (full turn = 2^16) added to the top of the phase.
module nco_po #(
  parameter int ACC_W = 32, A = 10, W = 16, PW = 16
) (
  input  logic                clk, rst,
  input  logic                en,
  input  logic [ACC_W-1:0]    fcw,
  input  logic [PW-1:0]       phase_off,     // 0x4000 = 90 degrees
  output logic                out_valid,
  output logic signed [W-1:0] cos_o, sin_o
);
  logic [ACC_W-1:0]    phase;
  // The low PW-A bits of phase_top are never read, but they are needed: they produce the carry
  // into the address bits when the offset has non-zero low bits (0x1234, say).
  /* verilator lint_off UNUSEDSIGNAL */
  logic [PW-1:0]       phase_top;             // the top PW bits of (phase + offset)
  /* verilator lint_on UNUSEDSIGNAL */
  logic signed [W-1:0] cos_rom [0:(1<<A)-1];
  logic signed [W-1:0] sin_rom [0:(1<<A)-1];
  initial begin
    $readmemh("cos_lut.hex", cos_rom);
    $readmemh("sin_lut.hex", sin_rom);
  end

  // the offset is aligned with the top of the accumulator; only the top PW bits can change,
  // so the addition needs only PW bits (and wraps modulo a full turn)
  assign phase_top = phase[ACC_W-1 -: PW] + phase_off;

  always_ff @(posedge clk) begin
    if (rst) begin
      phase <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= en;
      if (en) begin
        cos_o <= cos_rom[phase_top[PW-1 -: A]];
        sin_o <= sin_rom[phase_top[PW-1 -: A]];
        phase <= phase + fcw;                     // the accumulator itself is not offset
      end
    end
  end
endmodule
```

The offset changes only where the table is read, never the accumulator, so the frequency is untouched. Because the offset's 16 bits line up with the accumulator's top 16 bits, the addition needs only 16 bits: adding below that position would only add zeros.

**Two lint details, both instructive.** A first version added the offset to all 32 bits; Verilator reported that bits 21 to 0 of the sum were never used. The 16-bit version then reported bits 5 to 0 unused. Those six bits, unlike the first warning's, **are** needed: their carry reaches the address bits whenever the offset has non-zero low bits. An addition of only the 10 address bits would give the wrong table entry in **1,663 of 2,048** samples for an offset of `0x1234`. So the warning is waived locally, with the reason written next to it.

### Verification

The model adds the offset exactly as the hardware does, `idx = ((phase + (po << 16)) mod 2³²) >> 22`. With random gaps in `en` and FCW `0x0B3A5C1F`, all five offsets tested (`0x0000`, `0x4000`, `0x8000`, `0x1234`, `0xFFFF`) are bit-exact over 2,048 samples. The design is lint-clean.

### The 90-degree check

With `phase_off = 0x4000`, a quarter of a full turn, comparing against the run with offset 0:

```text
cos(theta + 90 deg) == -sin(theta) for every sample: True ; sin(theta + 90) == cos(theta): True
```

This is the identity cos(θ + 90°) = −sin θ, exactly, sample for sample, because the tables themselves satisfy `cos_lut[i + 256] == -sin_lut[i]` for all 1,024 entries. An offset of 90° is the same as the table address advancing by 1,024/4 = 256 entries, and the two tables were built from the same rounded function, so the identity holds to the last bit. A 90° offset is how a single NCO produces the two outputs of a quadrature (I/Q) oscillator, and how you correct a known phase error in a receiver.

### A phase-continuous frequency change

The testbench changes the FCW from `0x0B3A5C1F` (0.0439 cycles per sample) to `0x1999999A` (0.1) at sample 1,000. The model is the cumulative sum of the varying FCW, and the RTL matches it bit-exactly. Measuring the phase step from each output sample to the next:

```text
phase step (turns) around the switch: [0.0439 0.0439 0.0439 0.043  0.0439 0.1006 0.0996 0.1006 0.0996 0.0996]
```

The step changes from about 0.044 to about 0.100 turn at the switch, with **no jump in phase** and no change in amplitude (32,766 to 32,767 throughout). The small variations, 0.043 and 0.1006, are the table's phase truncation.

**Why it is free:** the phase register is never reset or reloaded when the FCW changes. It just starts adding a different amount from wherever it already is, so the phase, and the waveform, continue smoothly from the same point. A generator that switched frequency by selecting a different table, or by restarting a counter, would jump. Phase continuity is what makes NCOs suitable for frequency modulation (FSK and FM transmitters) and for the tracking loops of receivers.

## Exercise 2: a quarter-wave sine table

### The symmetries

Store q\[k\] = round(32,767 · sin(2πk/1,024)) for k = 0 to 255: the first quarter of the sine. For a 10-bit angle a, the top two bits give the quadrant and the low eight bits the position i inside it:

| Quadrant | Angle | sin(a) |
| --- | --- | --- |
| 0 | 0° to 90° | q\[i\] |
| 1 | 90° to 180° | q\[256 − i\], or **32,767 when i = 0** |
| 2 | 180° to 270° | −q\[i\] |
| 3 | 270° to 360° | −q\[256 − i\], or **−32,767 when i = 0** |

and cos(a) = sin(a + 90°), the same table read at the address plus 256.

**The off-by-one the exercise warned about** is at exactly 90° and 270°. Reading backward needs q\[256\], which is sin(90°) = 32,767, but a 256-entry table stops at q\[255\] = 32,766. A naive design reads q\[0\] (or wraps) instead. The fix is the special case in the table: at i = 0 in quadrants 1 and 3, the value is ±32,767, which is a constant, not a table entry.

**Checked exhaustively in Python** before any RTL: the reconstructed sine and cosine equal the full 1,024-entry tables at every one of the 1,024 addresses, and the same holds for a 12-bit angle (a 1,024-entry quarter table reproducing 4,096-entry tables). Exactness relies on the rounding being symmetric: round(32,767 · sin(π − x)) equals round(32,767 · sin x), and round(−v) = −round(v). Both hold for these values, as the exhaustive check confirms.

### First RTL version, and why it did not use block RAM

The first version, `nco_qw.sv`, computed the whole reconstruction in a function between the table and the output register. It is bit-exact (all 1,024 addresses, and 16,384 samples with random gaps), but Yosys built the table from **LUTs**: about 290 LUTs for A = 10 and 785 LUTs for A = 12, with no block RAM. The reason: a block RAM's data output can only feed a register directly, and here the negation and the multiplexer sit between the table and the register.

### The version that maps to block RAM

The fix is to **register the table reads first** and apply the symmetry one cycle later. It costs one cycle of latency; the testbench records outputs by `out_valid`, so nothing else changes:

```systemverilog
  // table address: forward in quadrants 0 and 2, backward (N/4 - i) in 1 and 3
  function automatic logic [QA-1:0] qaddr(input logic [A-1:0] a);
    qaddr = a[A-2] ? (QA'(0) - a[QA-1:0]) : a[QA-1:0];
  endfunction
  // the special case: exactly 90 or 270 degrees, whose value is not stored
  function automatic logic is_peak(input logic [A-1:0] a);
    is_peak = a[A-2] && (a[QA-1:0] == '0);
  endfunction

  // stage 1: registered ROM reads (two ports) and the control bits that go with them
  logic signed [W-1:0] qs, qc;
  logic                neg_s, neg_c, pk_s, pk_c, v1;
  always_ff @(posedge clk) begin
    if (rst) v1 <= 1'b0;
    else     v1 <= en;
    if (en) begin
      qs <= qrom[qaddr(a_s)];  neg_s <= a_s[A-1];  pk_s <= is_peak(a_s);
      qc <= qrom[qaddr(a_c)];  neg_c <= a_c[A-1];  pk_c <= is_peak(a_c);
    end
  end

  // stage 2: apply the symmetry
  always_ff @(posedge clk) begin
    if (rst) begin
      phase <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= v1;
      if (en) phase <= phase + fcw;
      if (v1) begin
        sin_o <= neg_s ? -(pk_s ? MAX : qs) : (pk_s ? MAX : qs);
        cos_o <= neg_c ? -(pk_c ? MAX : qc) : (pk_c ? MAX : qc);
      end
    end
  end
```

Here `a_s` is the top A bits of the phase, `a_c = a_s + 2^(A−2)`, and `QA'(0) - i` computes 2^(A−2) − i modulo 2^(A−2), the backward address. (`qaddr` also gives address 0 for the peak case, whose table value is then ignored.) The two reads use the table's two ports. The design is bit-exact for A = 10 and A = 12: every address, and 16,384 samples with gaps. It is lint-clean for both.

### The comparison

| Design | Memory | LUTs | Notes |
| --- | --- | --- | --- |
| Full tables, A = 10 (Part 9) | 2 RAMB18E1 | 33 | cos and sin tables, 1,024 × 16 each |
| Quarter table, A = 10 | **none** (LUT ROM) | about 230 | 256 × 16 is small: Yosys chose LUTs |
| Full tables, A = 12 | **4 RAMB36E1** | 33 | 4,096 × 16, twice |
| Quarter table, A = 12 | **1 RAMB18E1** | about 120 | 1,024 × 16, two read ports |

At A = 12 the saving is large: one 18-kbit block RAM instead of four 36-kbit ones, an **eighth** of the memory, for about 90 extra LUTs of symmetry logic. At A = 10 the quarter table is small enough that Yosys implemented it as logic, which is still smaller than two block RAMs, but not by the same margin.

### SFDR with 12 address bits

Measured on the RTL's cosine output, FCW `0x0B3A5C1F`, 16,384 samples, Blackman–Harris window:

| Address bits A | SFDR | 6.02 × A |
| --- | --- | --- |
| 10 | 60.4 dB | 60.2 dB |
| 12 | **71.7 dB** | 72.2 dB |

The quarter-wave design reaches the 12-bit table's spurious-free dynamic range, 11 dB better than the original, in less memory than the original 10-bit design used.

## Exercise 3: a more accurate CORDIC

### The RTL change

`cordic_g.sv` is Part 9's CORDIC with a parameter G. The inputs are shifted left by G bits, so G fractional **guard bits** sit below the original LSB; every stage works in OW + G bits; and the outputs are rounded back to OW = 18 bits once, at the end:

```systemverilog
  localparam int CW = OW + G;                                    // internal width
  ...
  logic signed [CW-1:0] xi, yi;
  assign xi = CW'(x_in) <<< G;                                    // G guard bits below the LSB
  assign yi = CW'(y_in) <<< G;
  ...                                                             // stages unchanged
  // one rounding at the end, back to OW bits (none needed when G = 0)
  if (G > 0) begin : g_round
    logic ovx, ovy;
    requant #(.IN_W(CW), .IN_F(G), .OUT_W(OW), .OUT_F(0), .RND(1), .SAT(1'b1))
      u_x (.din(x[N_IT]), .dout(x_out), .ovf(ovx)),
      u_y (.din(y[N_IT]), .dout(y_out), .ovf(ovy));
    wire unused = ovx | ovy;
  end else begin : g_plain
    assign x_out = x[N_IT];
    assign y_out = y[N_IT];
  end
```

The `generate if` handles G = 0 separately, because `requant` needs at least one bit to drop. The Python model does the same: shift in by G, run the iterations with Python's floor-rounding `>>`, then `(x + 2^(G−1)) >> G`.

### Measured errors

Input x₀ = round(32,767/K), y₀ = 0, rotated by 5,000 random angles; the error is measured against the exact rotation of each 20-bit angle (32,767 · cos and sin of the quantized angle), so the angle's own quantization is not counted. Every RTL run is bit-exact with the model.

| Guard bits G | 16 iterations | 20 iterations |
| --- | --- | --- |
| 0 | 7.24 LSB | — |
| 2 | 2.67 LSB | — |
| 4 | 1.95 LSB | — |
| 6 | 1.82 LSB | 1.21 LSB |

The guard bits remove most of the error: 7.24 → 1.95 LSB with four bits, close to the about 2 LSB found in Part 9's model. Beyond four, they barely help, because the truncation errors are no longer the limit.

### What limits the accuracy once the guard bits are enough?

Three further error sources, each measured with the bit-exact model by removing them one at a time:

| Change (always with G = 6) | Max error |
| --- | --- |
| 16 iterations, 20-bit angle (the design above) | 1.82 LSB |
| 20 iterations, 20-bit angle | 1.21 LSB |
| 20 iterations, 24-bit angle | **0.80 LSB** |
| 24 iterations, 28-bit angle | 0.84 LSB |
| G = 8, 24 iterations, 28-bit angle | 0.75 LSB |

1. **The number of iterations.** After 16 iterations, the angle still to be rotated can be up to arctan(2⁻¹⁵) = 3.05 × 10⁻⁵ rad, which at full scale (32,767) is **1.0 LSB**. More iterations shrink it: 20 iterations bring the error from 1.82 to 1.21 LSB.
2. **The angle resolution**, as the exercise's hint suggests. One 20-bit angle LSB is 2π/2²⁰ = 6.0 × 10⁻⁶ rad, 0.20 LSB at full scale; but every entry of the arctan table is itself rounded to that resolution, and 20 of those rounding errors accumulate in z. With 24-bit angles (and table), the error falls to 0.80 LSB.
3. **The floor**, about 0.75 LSB, which no further bits remove: the final rounding (up to 0.5 LSB) plus the rounding of the starting value 32,767/K = 19,897.86 to 19,898, an error of **0.24 LSB** at full scale.

The rule of thumb from Part 9 holds with one refinement: for an error near 1 LSB, use about as many iterations as output bits (here 18 to 20), log₂ of that in guard bits (4 to 5), **and** an angle word 3 to 4 bits wider than the output.

## Exercise 4: CORDIC in vectoring mode

### The RTL

In vectoring mode, each stage rotates the vector **toward the x-axis**, choosing the direction from the sign of y instead of z, and accumulates the angle it has rotated in z. When y reaches zero, x is K times the magnitude and z is the angle.

```systemverilog
  // stage 0: bring the left half-plane to the right by rotating 90 degrees, and remember it
  always_ff @(posedge clk) begin
    if (rst) v[0] <= 1'b0;
    else     v[0] <= in_valid;
    if (x_in < 0 && y_in >= 0) begin            // second quadrant: rotate by -90
      x[0] <= yi;             y[0] <= -xi;           z[0] <= QUARTER;
    end else if (x_in < 0) begin                // third quadrant: rotate by +90
      x[0] <= -yi;            y[0] <= xi;            z[0] <= -QUARTER;
    end else begin
      x[0] <= xi;             y[0] <= yi;            z[0] <= '0;
    end
  end

  // stages: rotate toward the x-axis (d = -sign(y)), accumulating the angle rotated
  for (genvar i = 0; i < N_IT; i++) begin : g_stage
    always_ff @(posedge clk) begin
      if (rst) v[i+1] <= 1'b0;
      else     v[i+1] <= v[i];
      if (y[i] >= 0) begin                       // rotate clockwise
        x[i+1] <= x[i] + (y[i] >>> i);  y[i+1] <= y[i] - (x[i] >>> i);  z[i+1] <= z[i] + cordic_atan(i);
      end else begin                             // rotate counter-clockwise
        x[i+1] <= x[i] - (y[i] >>> i);  y[i+1] <= y[i] + (x[i] >>> i);  z[i+1] <= z[i] - cordic_atan(i);
      end
    end
  end
```

`xi` and `yi` are the inputs shifted left by G guard bits (as in Exercise 3), and the magnitude is rounded back to 18 bits with `requant` at the end. The **pre-rotation** handles the left half-plane, where the iterations alone could not reach the x-axis (they rotate by at most ±99.9° in total). A vector in the second quadrant is rotated by −90° (and z starts at +90°), one in the third quadrant by +90° (z starts at −90°), so the iterations always start in the right half-plane. The 20-bit z register wraps naturally, so an angle near 180° can come out as −179.999°, the same angle.

The output angle is in binary angle units (2²⁰ per turn), the magnitude is K·|v| with K = 1.6468 for 16 iterations, and the latency is 17 cycles.

### Accuracy, and guard bits again

4,000 random vectors plus eight corner cases, with random gaps; every run bit-exact with the Python model; errors against `K * np.hypot(x, y)` and `np.arctan2(y, x)`:

| Guard bits G | Max magnitude error | Max angle error (\|v\| > 1,000) | (1, 1) gives |
| --- | --- | --- | --- |
| 0 | 13.67 LSB | 178 angle LSB = 0.061° | magnitude **16**, angle 43.25° |
| 4 | 0.96 LSB | 11.7 angle LSB = 0.0040° | magnitude 3, angle 43.25° |
| 8 | **0.52 LSB** | **7.8 angle LSB = 0.0027°** | magnitude 2, angle 45.04° |

Without guard bits the vectoring CORDIC is poor, and for tiny vectors it is absurd: (1, 1) comes out with magnitude 16 (the correct value is K·√2 = 2.3). The reason is the same as in Exercise 3, in its most visible form. An arithmetic shift rounds toward −∞, so `-1 >>> i` is still −1 for every i: once y is a small negative number, the correction `x - (y >>> i)` keeps adding 1 to x at every stage, and the magnitude grows by 1 per iteration. Guard bits make the smallest representable step much smaller than the input LSB, which removes the bias. With G = 8, the remaining angle error (7.8 angle LSB) is the residual angle after 16 iterations (arctan(2⁻¹⁵), about 5 angle LSB) plus the rounding of the arctan table.

Small vectors are inherently hard: a vector of magnitude 1 cannot have a precise angle, because its components are integers. The table above reports the angle error only for |v| > 1,000; below that it grows as the inputs' own quantization dominates.

### Following a tone's phase

A complex tone at +0.05 cycles per sample, the output that Exercise 5's mixer produces from a +0.2 tone, through the vectoring CORDIC (G = 8), gives an angle that increases by the same amount every sample:

```text
single tone at 0.05: phase steps (turns): [0.05    0.05    0.05001 0.05    0.05    0.05   ]  mean 0.05  std 6e-06
```

The phase is a straight line in time (wrapping every 20 samples), and its **slope is the frequency**: 0.05 turn per sample. The step varies by only 6 × 10⁻⁶ turn.

### An FM demodulator

An FM signal carries its message in its instantaneous frequency, f\[n\] = f\_c + deviation × m\[n\]. So computing the phase with the vectoring CORDIC and taking the difference between consecutive samples (modulo a full turn) recovers the message directly:

```python
dev = 0.02;  m = np.sin(2 * np.pi * 0.002 * n)                    # the message
ph = 2 * np.pi * np.cumsum(dev * m)                                 # FM: the phase integrates the frequency
I = quantize(0.7 * np.cos(ph), 16, 15);  Q = quantize(0.7 * np.sin(ph), 16, 15)
z = np.array([vec_model(a, b) for a, b in zip(I, Q)])              # CORDIC angle, 2^20 per turn
f_inst = (((np.diff(z) + 2**19) % 2**20) - 2**19) / 2**20           # phase step, wrapped: cycles/sample
rec = f_inst / dev                                                  # the recovered message
```

Result: correlation with the original message **1.000000**, maximum error **0.0007** for a message of amplitude 1. The hardware is just the vectoring CORDIC followed by one subtractor; the modulo-2²⁰ wrap of the subtraction is exactly the angle wrap the formula needs, so it costs nothing. A practical FM receiver adds a low-pass filter before the CORDIC (Exercise 5's mixer leaves the signal at baseband) and after the subtractor. The amplitude of the input does not matter at all, which is FM's famous immunity to amplitude noise: only the angle is used.

## Exercise 5: a complex mixer

### The arithmetic

Multiplying the complex input by e^{−jω₀n} = cos − j sin:

```latex
(I + jQ)(\cos - j\sin) = (I\cos + Q\sin) + j\,(Q\cos - I\sin)
```

Four real multiplications, two additions. With Q1.15 inputs and LO values, each product is Q2.30; the sums are rounded once to Q1.15 and saturated.

### The RTL, with both forms

```systemverilog
  localparam int SW = 2 * W + 2;                 // 34 bits: enough for both forms
  logic signed [SW-1:0] re, im;
  if (!GAUSS) begin : g_four
    // (a + jb)(c - js) = (ac + bs) + j(bc - as)
    assign re = SW'(a * c) + SW'(b * s);
    assign im = SW'(b * c) - SW'(a * s);
  end else begin : g_three
    // Gauss with d = -s:  k1 = c(a + b), k2 = a(d - c), k3 = b(c + d);  re = k1 - k3, im = k1 + k2
    logic signed [W:0] ab, dmc, cpd;             // pre-sums: 17 bits
    logic signed [SW-1:0] k1, k2, k3;            // products: 16 x 17 bits
    assign ab  = (W+1)'(a) + (W+1)'(b);
    assign dmc = -((W+1)'(s)) - (W+1)'(c);       // parenthesized: Yosys reads -(W+1)'(s) as a cast to width -(W+1)
    assign cpd = (W+1)'(c) - (W+1)'(s);
    assign k1  = SW'(c * ab);
    assign k2  = SW'(a * dmc);
    assign k3  = SW'(b * cpd);
    assign re  = k1 - k3;
    assign im  = k1 + k2;
  end
```

The rest is Part 9's mixer: the NCO advances once per valid input, the input is delayed one cycle to line up with the NCO's registered output, and two `requant` instances round the sums from 30 to 15 fractional bits. A parameter selects the form, so the same testbench verifies both.

### Verification

The model is the four-multiplication formula in integers; there is no separate model for the Gauss form, because Gauss's identity is exact in integer arithmetic (Part 6, Exercise 3):

```python
c, s = nco(fcw, len(I))
re = requant(I * c + Q * s, 30, 16, 15, "round", "saturate")
im = requant(Q * c - I * s, 30, 16, 15, "round", "saturate")
```

With 8,192 random full-scale I/Q samples, including the four corner combinations of ±full scale, and random gaps: **both forms bit-exact** against the same model. Both are lint-clean (for the Gauss form, pass `-GGAUSS=1'b1`: a plain `-GGAUSS=1` gives Verilator a 32-bit value for a 1-bit parameter and a `WIDTHTRUNC` warning).

### No mirror image

The complex tone I = 0.5 cos(2π · 0.2 n), Q = 0.5 sin(2π · 0.2 n) (a single positive frequency) with the LO at 0.15:

```text
complex tone in: peak at +0.0500; level at -0.35 (where the real mixer put the mirror): -59.3 dB; largest other component -59.3 dB
```

The tone moves to +0.2 − 0.15 = **+0.05** and nothing else appears. With Part 9's real mixer, a real input at 0.2 produced the same +0.05 **and** a full-strength image at −0.35. The complex input has no negative-frequency component, so there is nothing to mirror. What remains at −59.3 dB is not a mirror of the mixer: it is the NCO's own phase-truncation spur (its SFDR is 60.4 dB), as in the Part 12 capstone. A larger table (Exercise 2) would push it lower.

### Three multiplications, and what they cost

Gauss's form uses three multiplications instead of four: k₁ = c(a + b), k₂ = a(d − c), k₃ = b(c + d), with d = −sin, then re = k₁ − k₃ and im = k₁ + k₂. The costs are the ones found in Part 6:

- **Five additions instead of two**: three pre-sums before the multipliers, two after.
- **Bit growth**: the pre-sums need 17 bits, so the multipliers are 16 × 17 and the products up to 33 bits; the result is still exactly the same integer as the four-multiplier form.
- In a DSP48E1, a pre-sum can use the block's **pre-adder**, so the extra additions often cost no LUTs. Note also that the LO pre-sums (d − c and c + d) depend only on the NCO, so in a design where the NCO is shared they could even be precomputed.

### Comparison with a CORDIC-based mixer

`cordic_mixer.sv` uses a phase accumulator and Part 9's CORDIC in rotation mode, rotating (I, Q) by minus the LO phase. It works, giving the expected tone at 0.05000 cycles per sample with amplitude 0.8234 = 0.5 × K, but it is not bit-exact with the others, because it computes differently, and its outputs are scaled by K = 1.6468.

| Mixer | DSP48E1 | Block RAM | LUTs | Flip-flops | Latency |
| --- | --- | --- | --- | --- | --- |
| Four multipliers + NCO table | 4 | 2 RAMB18E1 | 131 | 66 | 2 cycles |
| Gauss, three multipliers + NCO table | **3** | 2 RAMB18E1 | 180 | 66 | 2 cycles |
| CORDIC rotation | **0** | **0** | 1,344 | 981 | 17 cycles |

The choice is a resource trade, exactly as in section 9.3: the table-and-multiplier mixers are small and fast if DSP blocks and block RAM are available; Gauss saves a quarter of the multipliers for about 50 LUTs; and the CORDIC mixer uses neither DSP blocks nor memory, at the price of 10 times the LUTs, 15 times the flip-flops and a 17-cycle latency. On a small FPGA whose DSP blocks are all taken by filters, the CORDIC can be the only option; with DSP blocks to spare, the Gauss mixer is usually best.

---

That completes Part 9. Send me your own designs and results if you would like them reviewed.
