# Verilog & RTL for DSP — Part 2: Sequential Logic

*Markdown export of the online document: https://claude.ai/artifact/GtMiTn92xqh9t91P3YVqfC. Diagrams and charts appear only online; each is marked below with its title.*


Oct 20, 2026 · @Behi

## Where Part 2 fits

Part 2 adds the clock. By the end you will write registers, counters and shift registers with `always_ff`, test them with clocked testbenches, and build your first DSP block: a moving-sum filter.

DSP hardware is almost entirely sequential. A sample arrives on a clock edge, is delayed by registers, combined by arithmetic, and stored again on the next edge. The single-sample delay z⁻¹ that you will meet in every filter diagram is, in hardware, simply a register.

Part 2 follows the same rhythm as Part 1: concepts, a complete example tested in Icarus Verilog and linted with Verilator, a "Check your understanding" block with answers, and exercises at the end.

**Before you start:** if you have not finished the Part 1 exercises, do them first. Section 2.7 uses signed arithmetic and width growth from section 1.4, and Exercise 4 of Part 1 (the saturating adder) reappears here. Send me your Part 1 solutions any time for review.

All the code below was compiled and run with Icarus Verilog 12.0 (`-g2012 -Wall`) and linted with Verilator 5.020 (`--lint-only -Wall`); newer versions behave the same.

## 2.1 From combinational to sequential logic

A sequential circuit has memory: its outputs depend on its inputs **and** on stored state. In this course, all state lives in edge-triggered D flip-flops that share one clock, which is called **synchronous design**.

### A quick refresher from Mano

- A **latch** is level-sensitive: while its enable is high, the output follows the input. You met the accidental latch in section 1.5; in this course you never want one.
- A **D flip-flop** is edge-triggered: it copies D to Q only at the rising edge of the clock and holds Q constant for the rest of the cycle.
- A **register** is a group of flip-flops sharing a clock: an 8-bit register is 8 flip-flops.

### The synchronous design rule

Almost every reliable digital design, and every design in this course, follows one rule:

**Every flip-flop is clocked by the same clock edge, and everything between flip-flops is combinational logic.**

You can then reason one cycle at a time. At each rising edge, every register loads the value that the combinational logic computed from the registers' previous contents. Between edges, the logic settles. Nothing else ever happens. This is exactly Mano's register-transfer view, and it is what RTL means.

### Timing: why the clock cannot be arbitrarily fast

A real flip-flop has three timing numbers:

| Parameter | Meaning |
| --- | --- |
| Clock-to-Q delay, t\_cq | Time after the clock edge before Q shows the new value |
| Setup time, t\_setup | How long D must be stable **before** the clock edge |
| Hold time, t\_hold | How long D must stay stable **after** the clock edge |

A signal leaves one register (the launch flip-flop), passes through combinational logic, and must arrive at the next register (the capture flip-flop) before that register's setup window. So the clock period T must satisfy:

```latex
T \geq t_{cq} + t_{logic,max} + t_{setup}
```

The slowest register-to-register path in the whole design is the **critical path**, and it sets the maximum clock frequency, f\_max = 1 / T\_min. For example, with t\_cq = 0.5 ns, t\_logic = 3.0 ns and t\_setup = 0.5 ns, T\_min = 4.0 ns and f\_max = 250 MHz.

This single inequality drives much of DSP hardware design. A long chain of adders and multipliers between registers lowers f\_max. The cure, **pipelining**, inserts registers to cut the logic into shorter pieces; you will use it from Part 6 onward.

Two more facts to keep in mind:

- **Simulation ignores these delays.** Your RTL simulation is "zero-delay": logic settles instantly. Only the synthesis and timing tools (Part 4) tell you whether the design meets timing at your target frequency.
- **Inputs that change at unknown times are dangerous.** A signal from a button or another clock domain can change inside the setup/hold window, and the flip-flop can become **metastable**: briefly neither 0 nor 1. Section 2.4 shows the standard fix, two flip-flops in series, for resets.

> **Figure:** register-to-register timing path (shown in the [online version](https://claude.ai/artifact/GtMiTn92xqh9t91P3YVqfC))

The launch register changes just after edge k; the result must ripple through the logic and be stable at the capture register a setup time before edge k+1.

### Check your understanding: 2.1

1. What is the difference between a latch and a flip-flop, in one sentence each?
2. A path has t\_cq = 0.4 ns, t\_logic = 4.1 ns and t\_setup = 0.5 ns. What is the maximum clock frequency?
3. You add a second adder in series on that path, adding 1.5 ns of logic delay. What happens to f\_max, and what would you do about it?
4. Your RTL simulation passes at a 1 GHz testbench clock. Does that prove the design works at 1 GHz?
5. Why does the synchronous design rule make a design easier to reason about?

#### Answers

1. A latch is level-sensitive: its output follows its input whenever its enable is active. A flip-flop is edge-triggered: it samples its input only at the clock edge and holds it for the whole cycle.
2. T\_min = 0.4 + 4.1 + 0.5 = 5.0 ns, so f\_max = 1 / 5.0 ns = **200 MHz**.
3. T\_min becomes 6.5 ns, so f\_max drops to about **154 MHz**. To recover speed, pipeline: put a register between the two adders. Each stage then has less logic and the clock can be faster, at the cost of one extra cycle of latency.
4. **No.** RTL simulation has zero logic delay, so it checks only the cycle-by-cycle behavior. Whether real gates can meet a 1 ns period is answered by static timing analysis after synthesis, not by simulation.
5. Every state change happens at one instant, the clock edge, and each register's next value depends only on the current register values and inputs. You can analyze the circuit one cycle at a time, without worrying about the order or timing in which signals change between edges.

## 2.2 Your first flip-flops

Every register in SystemVerilog is written with `always_ff @(posedge clk)` and the non-blocking assignment `<=`. Learn these two lines as a fixed pattern; section 2.3 explains why `<=` is mandatory.

### A single D flip-flop

```systemverilog
`timescale 1ns/1ps
// dff.sv -- the simplest flip-flop: q takes the value of d at every rising clock edge
module dff (
  input  logic clk,
  input  logic d,
  output logic q
);
  always_ff @(posedge clk) begin
    q <= d;
  end
endmodule
```

- **`always_ff`** declares that this block describes flip-flops. It states your intent. The standard also says a variable assigned in `always_ff` must not be written by any other block. Synthesis tools enforce this, but Icarus 12 and Verilator 5.020 do not (we tested), so following the rule is up to you.
- **`@(posedge clk)`** is the **sensitivity list**: the block runs only at a rising edge of `clk` (0 to 1). `negedge` would mean a falling edge. In this course, every register uses `posedge clk`.
- **`q <= d;`** is a **non-blocking assignment**, read "q gets d at this edge". All non-blocking assignments triggered by the same edge update together, like all of Mano's flip-flops loading at once.

Classic Verilog writes the same thing as `always @(posedge clk) q <= d;` with `q` declared as `reg`.

### A register with reset and enable

Real registers need a **reset** (to start in a known state) and usually a **load enable** (to update only on some cycles). This parameterized register is a building block you will reuse throughout the course:

```systemverilog
`timescale 1ns/1ps
// register.sv -- W-bit register with synchronous reset and load enable
module register #(
  parameter int W = 8
) (
  input  logic         clk,
  input  logic         rst,    // synchronous, active-high
  input  logic         en,     // load enable
  input  logic [W-1:0] d,
  output logic [W-1:0] q
);
  always_ff @(posedge clk) begin
    if (rst)
      q <= '0;                 // '0 = all bits zero, whatever the width
    else if (en)
      q <= d;
    // no else: when en = 0, q keeps its value -- that is what a flip-flop does
  end
endmodule
```

The hardware: W flip-flops, each with a small multiplexer in front of its D input. The multiplexer picks 0 when `rst` is 1, `d` when `en` is 1, and otherwise feeds `q` back to itself so the value is held. FPGA flip-flops have dedicated reset and clock-enable pins, so this costs almost no extra logic.

Three details to notice:

1. **The missing `else` is correct here.** In `always_comb`, a path that does not assign an output creates an unwanted latch (section 1.5). In `always_ff`, "not assigned on this edge" simply means "keep the old value", which is exactly what a flip-flop does. Holding is free.
2. **`'0`** (apostrophe, zero, with no width) fills every bit of the target with 0, whatever its width. `'1` fills with ones. Use these with parameterized widths, where `8'd0` would be wrong as soon as W changes.
3. **The order of `if` branches is priority.** Reset comes first, so it wins over the enable. That is the usual convention.

### Rules for sequential blocks

1. One `always_ff @(posedge clk)` block per group of related registers.
2. Inside `always_ff`, use only non-blocking `<=`.
3. Assign each register in exactly one `always_ff` block. Two blocks driving the same register is the sequential version of two gates shorted together.
4. Keep large combinational calculations in `always_comb` or `assign`, and use `always_ff` mainly to store their results. This keeps the hardware easy to see.

### Check your understanding: 2.2

1. Rewrite `register.sv` so the enable is ignored during reset, but reset only happens when `en` is also 1. Is that a sensible design?
2. Why is a missing `else` fine in `always_ff` but a bug in `always_comb`?
3. A 32-bit register is written `q <= 8'd0;` in its reset branch. What value is loaded? What is the better way to write it?
4. Describe the hardware that `always_ff @(posedge clk) if (en) q <= d;` creates for a 1-bit `q`.
5. Two different `always_ff` blocks each contain `count <= ...`. What will Verilator say, and why is it a real hardware problem?

#### Answers

1. Swap the nesting: `if (en) begin if (rst) q <= '0; else q <= d; end`. It is legal, but usually a bad idea: a reset that only works when some other control signal happens to be active can leave the circuit in an unknown state after power-up. Make reset unconditional.
2. In `always_ff`, a register that is not assigned on an edge keeps its value, and flip-flops hold values anyway, so no extra hardware is implied. In `always_comb`, holding a value requires memory, which combinational logic does not have, so the tool adds a latch.
3. All 32 bits become 0, because `8'd0` is zero-extended to 32 bits. It works, but it hides intent and Verilator reports a width warning. Write `q <= '0;`, which is correct for any width.
4. One D flip-flop clocked by `clk`, with a 2-to-1 multiplexer on its D input: when `en` is 1 the multiplexer passes `d`; when `en` is 0 it passes `q` back. On FPGAs, the multiplexer is usually absorbed into the flip-flop's built-in clock-enable pin.
5. Surprisingly, neither Icarus 12 nor Verilator 5.020 complains: we compiled exactly this and got no message. Synthesis tools do report it as a multiple-driver error, but only much later in the flow, which is why rule 3 is a discipline you enforce yourself. In hardware there would be two flip-flops, or two drivers, fighting for one output; no real circuit does what that code says.

## 2.3 Blocking `=` versus non-blocking `<=`

Use `<=` in `always_ff` and `=` in `always_comb`, always. Breaking this rule is the most common sequential-logic bug, and the simulator gives no error: it just silently simulates a different circuit from the one you meant.

### Experiment 1: swapping two registers

In hardware, two flip-flops can swap their contents in one clock edge: each loads the other's **old** value. Here is the same intent written both ways:

```systemverilog
`timescale 1ns/1ps
// swap.sv -- the same intent written two ways
module swap (
  input  logic clk,
  input  logic load,
  output logic [3:0] a_nb, b_nb,     // swapped with non-blocking <=
  output logic [3:0] a_bl, b_bl      // "swapped" with blocking =
);
  always_ff @(posedge clk) begin
    if (load) begin a_nb <= 4'd1; b_nb <= 4'd2; end
    else      begin a_nb <= b_nb; b_nb <= a_nb; end
  end

  always_ff @(posedge clk) begin
    if (load) begin a_bl = 4'd1; b_bl = 4'd2; end
    else      begin a_bl = b_bl; b_bl = a_bl; end
  end
endmodule
```

After loading 1 and 2, the simulation prints one line per clock cycle:

```text
non-blocking: a=1 b=2    blocking: a=1 b=2
non-blocking: a=2 b=1    blocking: a=2 b=2
non-blocking: a=1 b=2    blocking: a=2 b=2
```

The non-blocking version swaps on every edge. The blocking version destroys the value 1 on the first edge: `a_bl = b_bl` changes `a_bl` to 2 **immediately**, so the next line `b_bl = a_bl` reads the new 2.

### Experiment 2: a shift register that is not one

A 3-stage shift register should move a single 1 along one stage per clock:

```systemverilog
  always_ff @(posedge clk) begin      // correct
    q_nb[0] <= din;
    q_nb[1] <= q_nb[0];
    q_nb[2] <= q_nb[1];
  end

  always_ff @(posedge clk) begin      // wrong
    q_bl[0] = din;
    q_bl[1] = q_bl[0];   // reads the value JUST written above
    q_bl[2] = q_bl[1];
  end
```

Feeding in one `1` followed by zeros gives:

```text
q_nb = 001    q_bl = 111
q_nb = 010    q_bl = 000
q_nb = 100    q_bl = 000
q_nb = 000    q_bl = 000
```

The blocking version is not a shift register at all: every stage loads `din` on the same edge. The synthesizer builds what the code says, three flip-flops all fed from `din`, so simulation and hardware agree, and both are wrong. (Reversing the order of the three blocking lines happens to work, but code whose meaning depends on line order is exactly what you want to avoid.)

### Why `<=` works: what the simulator does at a clock edge

At each rising edge, the simulator handles non-blocking assignments in two steps:

1. **Evaluate.** Every triggered `always_ff` block runs, and the right-hand side of every `<=` is computed using the values from **before** the edge. The results are queued, not applied.
2. **Update.** After all the triggered blocks have finished, every queued value is written at once.

That is precisely how real flip-flops behave: all of them sample their D inputs at the edge, and all of their outputs change together afterwards. A blocking `=` instead writes immediately, so whatever runs later in the same time step sees the new value.

It gets worse across blocks. If one `always_ff` writes `x = ...` with a blocking assignment and another `always_ff` reads `x` at the same edge, the result depends on which block the simulator happens to run first. This is a **race condition**: the language does not define the order, and different simulators can give different answers.

### Let the linter catch it

Verilator flags blocking assignments in sequential blocks:

```text
%Warning-BLKSEQ: swap.sv:15:26: Blocking assignment '=' in sequential logic process
```

Icarus compiles the same code silently. One more reason to lint every file.

### The four rules

These are adapted from Clifford Cummings' widely used paper on non-blocking assignments, and they eliminate this whole class of bugs:

1. Sequential logic (`always_ff`): use non-blocking `<=`.
2. Combinational logic (`always_comb`): use blocking `=`.
3. Never mix `=` and `<=` in the same block.
4. Never assign the same variable from more than one block.

### Check your understanding: 2.3

1. Registers `a = 3`, `b = 5`, `c = 7`. At one clock edge, the block `a <= b; b <= c; c <= a;` executes. What are `a`, `b`, `c` afterwards?
2. Same starting values, but the block is `a = b; b = c; c = a;`. What are they now?
3. In Experiment 2, would writing the three blocking lines in reverse order (`q_bl[2] = q_bl[1];` first) give a correct shift register? Why is that still bad practice?
4. Why is `=` correct inside `always_comb`?
5. Inside one `always_ff`, a designer writes `tmp = a + b;` and then `y <= tmp * c;`. Is it legal? Is it good style?

#### Answers

1. `a = 5`, `b = 7`, `c = 3`. Every right-hand side uses the values from before the edge, so the three values rotate.
2. `a = 5`, `b = 7`, `c = 5`. Each line sees the previous line's result: `c = a` reads the new `a`, which is 5. The original 3 is lost.
3. Yes, it would simulate correctly, because each stage reads its neighbor before that neighbor is overwritten. It is bad practice because the meaning now depends on line order: a later edit that reorders or adds a line silently breaks it, and Verilator still warns. With `<=`, any order gives the same result.
4. Combinational logic has no clock edge and no stored state: it is a chain of calculations, and each later line should see the results of earlier lines, just as the output of one gate feeds the next. Blocking assignments model exactly that.
5. It is legal and it simulates as "y gets (a + b) × c", with `tmp` acting as a temporary wire. It breaks rule 3, though, Verilator warns about the blocking assignment, and if `tmp` is read anywhere else it may be inferred as an extra register. Write `tmp` in an `always_comb` block (or as an `assign`) and keep only `y <= tmp * c;` in `always_ff`.

## 2.4 Resets

A reset puts registers into a known state, usually at power-up. This course uses a **synchronous, active-high** reset called `rst`, but you need to recognize the asynchronous style too, because much existing code uses it.

Without a reset, a register in simulation starts as `x` and stays `x` until something loads it. In a feedback loop such as a counter (`count <= count + 1`), `x + 1` is `x` forever. In hardware, the flip-flop starts at some unpredictable 0 or 1 pattern.

### Synchronous versus asynchronous reset

```systemverilog
`timescale 1ns/1ps
// reset_styles.sv -- the same 4-bit register with two kinds of reset
module reset_styles (
  input  logic       clk,
  input  logic       rst,     // synchronous reset, active-high
  input  logic       arst_n,  // asynchronous reset, active-low
  input  logic [3:0] d,
  output logic [3:0] q_sync,
  output logic [3:0] q_async
);
  // Synchronous: reset is just another input, sampled at the clock edge
  always_ff @(posedge clk) begin
    if (rst) q_sync <= '0;
    else     q_sync <= d;
  end

  // Asynchronous: the reset edge itself triggers the block, no clock needed
  always_ff @(posedge clk or negedge arst_n) begin
    if (!arst_n) q_async <= '0;
    else         q_async <= d;
  end
endmodule
```

Both registers first load `4'hA`. The testbench then asserts both resets between clock edges, at 17 ns:

```text
t=18 ns, 1 ns after reset asserted: q_sync=a q_async=0
t=26 ns, just after the next edge:    q_sync=0 q_async=0
```

The asynchronous register clears immediately; the synchronous one waits for the next rising edge at 25 ns.

|  | Synchronous reset | Asynchronous reset |
| --- | --- | --- |
| Sensitivity list | `@(posedge clk)` | `@(posedge clk or negedge arst_n)` |
| Takes effect | At the next clock edge | Immediately |
| Needs a running clock | Yes | No (to assert) |
| Hardware | Reset is part of the D-input logic | Uses the flip-flop's dedicated clear pin |
| Main danger | Reset pulse shorter than a clock period is missed | Releasing reset close to a clock edge (see below) |

Notes on the asynchronous style:

- The `_n` suffix is the common convention for **active-low** signals: reset happens when `arst_n` is 0, hence `negedge arst_n` and `if (!arst_n)`.
- The reset branch must come **first** in the block, and the block must contain nothing but the reset branch and the normal clocked branch. Synthesis tools recognize this exact template.

### Which one should you use?

Both are correct when used consistently. [AMD's design guidance (UG949)](https://docs.amd.com/r/2023.1-English/ug949-vivado-design-methodology/Synchronous-Reset-vs.-Asynchronous-Reset) recommends synchronous resets when a reset is needed, partly because the dedicated multiplier blocks (DSP slices) and block RAM registers support only synchronous reset internally ([DSP coding guidance](https://docs.amd.com/r/en-US/ug949-vivado-design-methodology/Coding-for-Optimal-DSP-and-Arithmetic-Inference)). ASIC designers and many Intel FPGA designs typically use asynchronous resets. This course uses **synchronous, active-high `rst`** because it is simple and maps well onto FPGA DSP resources.

### Releasing an asynchronous reset safely

Asserting an asynchronous reset is safe at any time. **Releasing** it is not: if `arst_n` goes high just before a clock edge, some flip-flops leave reset on that edge and some on the next, and the design starts in an inconsistent state. The standard fix is a **reset synchronizer**: reset asserts asynchronously but is released in step with the clock.

```systemverilog
`timescale 1ns/1ps
// reset_sync.sv -- asynchronous assert, synchronous de-assert
module reset_sync (
  input  logic clk,
  input  logic arst_n_in,   // raw reset from a button or another clock domain
  output logic arst_n_out   // safe to use as the async reset of this clock domain
);
  logic stage1;
  always_ff @(posedge clk or negedge arst_n_in) begin
    if (!arst_n_in) begin
      stage1     <= 1'b0;
      arst_n_out <= 1'b0;
    end else begin
      stage1     <= 1'b1;
      arst_n_out <= stage1;
    end
  end
endmodule
```

When `arst_n_in` goes low, both flip-flops clear at once. When it goes high, a 1 has to travel through two flip-flops, so `arst_n_out` rises exactly on a clock edge, two cycles later. The first flip-flop might go metastable if the release arrives near an edge; the second gives it a full clock period to settle. The same two-flip-flop idea synchronizes any single-bit signal that comes from outside the clock domain.

### What to reset in a DSP design

Control logic must be reset: state machines, counters, and "valid" flags. Pure data registers, such as a filter's delay line, often do not need it: their contents are flushed by new samples within a few cycles, and on FPGAs leaving out the reset saves routing. However, unreset data registers simulate as `x` until filled, which makes early testbench output hard to read. In this course we reset everything until Part 6, where you will learn to decide case by case.

### Check your understanding: 2.4

1. A counter has no reset. What does it show in simulation after 100 clock cycles, and why?
2. Write the sensitivity list and first `if` for an asynchronous, **active-high** reset named `arst`.
3. A push-button produces a reset pulse of 20 ns. The clock period is 50 ns. Which reset style might miss it, and why?
4. What problem does the reset synchronizer solve, and why does it use two flip-flops instead of one?
5. Why does an AMD FPGA design often avoid asynchronous resets in DSP datapaths?

#### Answers

1. `x` (displayed as `x` or `xxxx`). The register starts as `x`, and `x + 1` is `x`, so the feedback loop never recovers. In hardware it would count from a random starting value.
2. `always_ff @(posedge clk or posedge arst) begin if (arst) q <= '0; else ...`. Active-high means the reset event is the rising edge of `arst`.
3. The **synchronous** reset. It is only sampled at rising clock edges, 50 ns apart, so a 20 ns pulse can begin and end between two edges and never be seen. An asynchronous reset acts immediately and catches it. (Real button inputs also need debouncing.)
4. It makes the **release** of an asynchronous reset happen on a clock edge, so all flip-flops leave reset in the same cycle. The first flip-flop may go metastable when the release is close to an edge; the second flip-flop samples it one clock period later, after it has almost certainly settled, so the output is clean.
5. The DSP slices' internal registers only support synchronous reset. Using an asynchronous reset on registers you would like to place inside a DSP slice can prevent the tool from using those registers, which costs extra logic and speed. AMD's guidance also recommends not resetting datapath registers at all unless needed.

## 2.5 Clocked testbenches

A clocked testbench needs four things: a clock, a reset sequence, a race-free way to apply inputs, and a model that predicts the outputs one cycle ahead. The template below does all four; copy it for every sequential design in this course.

```systemverilog
`timescale 1ns/1ps
// tb_register.sv -- clocked, self-checking testbench for register.sv
module tb_register;
  localparam int W = 8;
  logic         clk = 1'b0;
  logic         rst, en;
  logic [W-1:0] d, q;
  logic [W-1:0] model;             // what q should hold
  int           errors = 0;

  register #(.W(W)) dut (.clk(clk), .rst(rst), .en(en), .d(d), .q(q));

  always #5 clk = ~clk;            // 10 ns period: rising edges at 5, 15, 25, ...

  initial begin                    // watchdog: stop a simulation that hangs
    #100_000;
    $display("TIMEOUT");
    $finish;
  end

  initial begin
    $dumpfile("register.vcd");
    $dumpvars(0, tb_register);

    // reset for two cycles; inputs change only on the falling edge
    rst = 1'b1; en = 1'b0; d = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    model = '0;

    repeat (200) begin
      @(negedge clk);              // halfway between rising edges: everything is stable
      if (q !== model) begin
        $display("FAIL at %0d ns: q=%h expected %h", $time, q, model);
        errors++;
      end
      en = $urandom_range(0, 1);   // new random inputs for the next rising edge
      d  = $urandom;
      if (en) model = d;           // what q must hold after that edge
    end

    if (errors == 0) $display("PASS: 200 cycles correct");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

Run it with `iverilog -g2012 -Wall -o sim register.sv tb_register.sv && vvp sim`. It prints `PASS: 200 cycles correct`. With the enable deliberately removed from the design, it reported `FAILED with 82 errors`.

### The four parts

**1. The clock.** `logic clk = 1'b0;` starts the clock at 0, and `always #5 clk = ~clk;` inverts it every 5 ns, forever: a 10 ns period (100 MHz), with rising edges at 5, 15, 25 ns. This `always` block with a delay is testbench-only code.

**2. The reset sequence.** Hold `rst` high for a couple of clock edges, then release it. `repeat (2) @(negedge clk);` waits for two falling edges. `@(...)` means "wait until this event happens".

**3. Race-free stimulus: change inputs on the falling edge.** If the testbench changed `d` at the same instant as the rising edge, the simulator could run the DUT's `always_ff` before or after the testbench's assignment: a race, exactly like the one in section 2.3. Changing inputs at the **falling** edge keeps them half a period away from the sampling edge, so there is no ambiguity. This mirrors real hardware, where inputs must be stable around the edge (setup and hold).

**4. Check, then predict.** At each falling edge, the loop first checks that `q` matches `model`, the value predicted at the previous falling edge. Then it applies new random inputs and updates `model` to what `q` must become after the next rising edge. The model is a few lines of ordinary code describing **what** the register should do, not **how**: if `en` is 1, `q` becomes `d`.

The watchdog `initial` block is cheap insurance. If a bug makes the testbench wait forever for an event that never happens, the watchdog ends the run with a clear message instead of hanging.

### Another style you will see

Many engineers drive inputs right after the rising edge with non-blocking assignments, `@(posedge clk); d <= value;`. Because `<=` updates after all the `always_ff` blocks have sampled, this is also race-free. Both styles are correct; this course uses the falling-edge style because it is easy to read on a waveform.

### Check your understanding: 2.5

1. Write a clock generator for a 40 MHz clock with `` `timescale 1ns/1ps ``.
2. A testbench executes `@(posedge clk); d = 8'h55;` and the DUT is a register. On which edge does the register capture `8'h55`?
3. In the template, why is `model` updated **before** the rising edge that loads `q`, not after it?
4. The DUT never asserts the signal your testbench is waiting for with `@(posedge done);`. What happens with and without the watchdog?
5. What does `$urandom_range(0, 1)` return, and why is a random enable a better test than a fixed pattern?

#### Answers

1. The period is 1 / 40 MHz = 25 ns, so the clock toggles every 12.5 ns: `always #12.5 clk = ~clk;`. The 1 ps precision represents 12.5 ns exactly.
2. It is a race. The testbench's blocking assignment and the register's `always_ff` both run at that rising edge, in an order the language does not define. The register may capture `8'h55` at that edge or at the next one, and different simulators can disagree. Use the falling edge, or `d <= 8'h55;`.
3. Because the check happens at the **next** falling edge, after the rising edge. The model value must already describe the state after that rising edge, so it is computed together with the inputs that cause it, while those inputs are known.
4. Without the watchdog, the simulation never reaches `$finish`. The clock generator keeps running, so the simulator runs forever (or until you stop it), with no message. With the watchdog, the run stops at 100 µs and prints `TIMEOUT`, which points you straight at the hang.
5. It returns 0 or 1 with equal probability. A random enable exercises combinations a hand-written pattern might miss, such as several cycles in a row with the enable low, or the enable toggling every cycle, without you having to think of them in advance.

## 2.6 Counters and clock enables

A counter is a register that feeds back through an adder. In DSP hardware, counters mostly produce **clock enables**: one-cycle pulses that tell the datapath when a new sample arrives, so the whole design can run from a single fast clock.

### A modulo-N counter

```systemverilog
`timescale 1ns/1ps
// mod_counter.sv -- counts 0, 1, ..., M-1, 0, 1, ... while en is high
module mod_counter #(
  parameter int M = 10,                      // modulus (number of states), M >= 2
  localparam int W = $clog2(M)               // bits needed to hold 0 .. M-1
) (
  input  logic         clk,
  input  logic         rst,                  // synchronous, active-high
  input  logic         en,                   // count enable
  output logic [W-1:0] count,
  output logic         tc                    // terminal count: high while count = M-1 and en = 1
);
  assign tc = en && (count == W'(M - 1));

  always_ff @(posedge clk) begin
    if (rst)
      count <= '0;
    else if (en) begin
      if (tc) count <= '0;                   // wrap from M-1 back to 0
      else    count <= count + 1'b1;
    end
  end
endmodule
```

New constructs:

- **`$clog2(M)`** is the ceiling of log₂ M, computed at compile time: the number of bits needed to count from 0 to M − 1. For M = 10 it is 4; for M = 16 it is 4; for M = 17 it is 5. Use it whenever a width depends on a parameter.
- **`localparam` in the parameter list** declares a derived constant that users of the module cannot override. Here W always follows from M.
- **`W'(M - 1)`** is a **size cast**: it converts the 32-bit integer M − 1 to exactly W bits, so the comparison has matching widths and Verilator's lint stays clean. The general form is `width'(expression)`.
- **`tc` is combinational** and includes `en`. It is high during the one cycle in which the counter will wrap. A downstream block can use it as its own enable, which is how counters are chained into larger ones (seconds, then minutes).

The testbench follows the section 2.5 template. Its model is one line, `if (en) model = (model + 1) % M;`, and with a random enable it reported `PASS: 500 cycles, 26 wraps`.

### A tick generator: the clock enable

Suppose your system clock is 100 MHz but audio samples arrive at 1 MHz. You need a pulse on one cycle in every 100. Reuse the counter:

```systemverilog
`timescale 1ns/1ps
// tick_gen.sv -- a one-cycle pulse every DIV clock cycles (a clock ENABLE, not a clock)
module tick_gen #(
  parameter int DIV = 4                      // DIV >= 2
) (
  input  logic clk,
  input  logic rst,
  output logic tick
);
  logic [$clog2(DIV)-1:0] unused_count;

  mod_counter #(.M(DIV)) u_cnt (
    .clk(clk), .rst(rst), .en(1'b1), .count(unused_count), .tc(tick)
  );
endmodule
```

With `DIV = 100`, `tick` is high for one 10 ns cycle every 1 µs. Every DSP block downstream then does its work only in cycles where `tick` is 1, exactly as `register.sv` loads only when `en` is 1.

### Never make a clock out of logic

It is tempting to write `always_ff @(posedge tick)`, or to divide a clock with a toggling flip-flop and use that as a new clock. **Don't.** In an FPGA:

- Clocks travel on dedicated low-skew networks. A clock made by logic travels on ordinary routing and arrives at different flip-flops at different times, which breaks the timing assumptions of section 2.1.
- Data passing between the original clock and the derived clock crosses **clock domains**, which needs special synchronization logic.
- A clock that comes out of combinational logic can glitch, producing extra edges.

The rule for this course: **one clock, `posedge clk` everywhere, and enables for everything that runs slower.** (When you genuinely need another frequency, FPGAs provide clock-management blocks, PLLs and MMCMs, that produce clean clocks; that is beyond this course.)

### Check your understanding: 2.6

1. What is `$clog2(M)` for M = 2, 8, 9, 100 and 1024?
2. In `mod_counter`, why does `tc` include `en`? What would go wrong in a chained counter if it did not?
3. A 100 MHz system clock must process samples at 48 kHz. Can `tick_gen` produce an exact 48 kHz enable? If not, what is the closest it can do?
4. Why is `count == W'(M - 1)` written with a cast instead of simply `count == M - 1`?
5. A colleague writes `logic slow_clk; always_ff @(posedge clk) slow_clk <= ~slow_clk;` and then clocks a filter with `always_ff @(posedge slow_clk)`. What would you suggest instead, and why?

#### Answers

1. 1, 3, 4, 7, 10. For M = 9 you need 4 bits to reach 8; for M = 100, 7 bits reach 99 (2⁷ = 128); for M = 1024, 10 bits reach 1023.
2. `tc` should mean "the counter wraps at this edge", which only happens when it is enabled. Without `en`, `tc` would stay high for as long as the counter sat at M − 1 while disabled, and a second counter chained to it would advance on every one of those cycles instead of once.
3. Not exactly: 100,000,000 / 48,000 = 2083.33..., which is not an integer. `DIV = 2083` gives about 48,008 Hz, an error of 0.016%. Exact fractional rates need a different technique, the phase accumulator (a numerically controlled oscillator), which you will build in Part 9.
4. `M - 1` is a 32-bit integer and `count` has W bits. The comparison works either way in simulation, because the narrower operand is zero-extended, but Verilator's lint reports the width mismatch. The cast states the intended width and keeps the lint clean.
5. Keep one clock and generate an enable instead: a `tick_gen` with `DIV = 2` (or a 1-bit toggle used as an enable), with the filter written as `always_ff @(posedge clk) if (tick) ...`. The derived clock would travel on general routing with skew, create a second clock domain between `clk` logic and filter logic, and complicate timing analysis.

## 2.7 Shift registers and the delay line: your first DSP block

In DSP notation, z⁻¹ means "the previous sample". In hardware, z⁻¹ is one register that loads on every sample enable. A chain of them is a **delay line**, and a delay line plus an adder is a filter.

### Signals as sequences

A digital signal is a sequence of numbers, one per sample period: x\[0\], x\[1\], x\[2\], and so on. Write x\[n\] for the current sample, x\[n−1\] for the one before it, and so on. (Part 5 develops this properly; this is all you need now.)

The **moving sum** of length 4 adds the current sample and the three before it:

```latex
y[n] = x[n] + x[n-1] + x[n-2] + x[n-3]
```

It smooths a signal: a sudden one-sample spike is spread over four outputs. Divide by 4 and it becomes a **moving average**, the simplest low-pass filter. In Part 7 you will see that it is a 4-tap FIR filter with every coefficient equal to 1.

### Bit growth

Adding four W-bit signed numbers can produce a result four times larger than any input. Four times larger needs log₂ 4 = 2 extra bits, so the output is **W + 2 bits**. With W = 16, inputs range from −32,768 to 32,767, and the sum from −131,072 to 131,068, which fits exactly in 18 signed bits. Tracking bit growth like this, at every adder and multiplier, is the core skill of fixed-point DSP (Part 6).

### The hardware

> **Figure:** moving-sum filter hardware (shown in the [online version](https://claude.ai/artifact/GtMiTn92xqh9t91P3YVqfC))

Three z⁻¹ registers hold the previous samples, the adder combines all four taps, and the output register stores the result. The code below describes exactly these boxes.

```systemverilog
`timescale 1ns/1ps
// moving_sum4.sv -- y[n] = x[n] + x[n-1] + x[n-2] + x[n-3]
// One new sample per clock cycle in which in_valid = 1. Output is registered.
module moving_sum4 #(
  parameter int W = 16                          // input sample width (signed)
) (
  input  logic                clk,
  input  logic                rst,
  input  logic                in_valid,         // a new sample is on x this cycle
  input  logic signed [W-1:0] x,
  output logic                out_valid,        // y holds a new result this cycle
  output logic signed [W+1:0] y                 // W+2 bits: the sum of 4 values can't overflow
);
  logic signed [W-1:0] d1, d2, d3;              // x[n-1], x[n-2], x[n-3]: the delay line
  logic signed [W+1:0] sum;

  // Combinational adder: extend every operand to W+2 bits FIRST, then add
  assign sum = (W+2)'(x) + (W+2)'(d1) + (W+2)'(d2) + (W+2)'(d3);

  always_ff @(posedge clk) begin
    if (rst) begin
      d1 <= '0;  d2 <= '0;  d3 <= '0;
      y  <= '0;
      out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d1 <= x;                                // shift the delay line ...
        d2 <= d1;
        d3 <= d2;
        y  <= sum;                              // ... and register the result
      end
    end
  end
endmodule
```

How to read it:

- **`d1`, `d2`, `d3` are the z⁻¹ registers.** On every cycle with `in_valid` high they shift by one sample, exactly like the shift register in section 2.3, but W bits wide. Because they use `<=`, each reads its neighbor's old value.
- **`(W+2)'(x)` sign-extends.** A size cast of a signed value to a wider width copies its sign bit, so each operand is widened to 18 bits before any addition happens. No intermediate result can overflow.
- **The adder is combinational** (`assign`) and its result is stored in the output register `y`. That separation, logic in `assign`/`always_comb` and storage in `always_ff`, is rule 4 of section 2.2.
- **`in_valid` and `out_valid` form a simple handshake.** `in_valid` is the clock enable from section 2.6: it marks the cycles that carry a sample. `out_valid` follows it one cycle later, marking the cycles in which `y` holds a new result. That one-cycle delay is the block's **latency**.

### Verifying it against a model

The testbench keeps its own delay line in `int` variables, which cannot overflow, and computes the expected sum the simple way:

```systemverilog
`timescale 1ns/1ps
// tb_moving_sum4.sv -- compares the hardware with a software model of the same filter
module tb_moving_sum4;
  localparam int W = 16;
  logic                clk = 1'b0, rst, in_valid, out_valid;
  logic signed [W-1:0] x;
  logic signed [W+1:0] y;
  int hist [0:2];                 // model's delay line: x[n-1], x[n-2], x[n-3]
  int exp_y, xi, errors = 0, checks = 0;
  logic exp_valid;

  moving_sum4 #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  // pick a test sample: mostly random, sometimes the extreme values
  function automatic int pick();
    case ($urandom_range(0, 9))
      0:       return -(2**(W-1));          // most negative: -32768
      1:       return  (2**(W-1)) - 1;      // most positive: +32767
      default: return $signed(W'($urandom));   // random W-bit value, read as signed
    endcase
  endfunction

  initial begin
    rst = 1'b1; in_valid = 1'b0; x = '0;
    hist[0] = 0;  hist[1] = 0;  hist[2] = 0;
    exp_y = 0;  exp_valid = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;

    repeat (2000) begin
      // 1. check the outputs produced by the previous rising edge
      if (y !== exp_y[W+1:0] || out_valid !== exp_valid) begin
        $display("FAIL at %0d ns: y=%0d valid=%b, expected %0d valid=%b",
                 $time, y, out_valid, exp_y, exp_valid);
        errors++;
      end
      if (out_valid) checks++;
      // 2. apply new inputs and predict the next outputs
      in_valid = $urandom_range(0, 3) != 0;   // a sample on about 3 cycles in 4
      xi = pick();
      x  = xi[W-1:0];
      exp_valid = in_valid;
      if (in_valid) begin
        exp_y   = xi + hist[0] + hist[1] + hist[2];
        hist[2] = hist[1];  hist[1] = hist[0];  hist[0] = xi;
      end
      @(negedge clk);
    end
    if (errors == 0) $display("PASS: %0d outputs checked", checks);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
```

New testbench features: a **`function`** returns a value (here, a test sample), and choosing the extreme values 10% of the time each makes overflow bugs much more likely to show up than pure random data would. The result: `PASS: 1536 outputs checked`.

One Icarus limitation surfaced while testing: Icarus 12 does not support assigning a whole array at once (`hist = '{0, 0, 0};`) and reports `sorry: Assignment to an entire array ... is not yet supported`. That is why the testbench clears `hist` one element at a time.

### The bug every DSP engineer writes once

Change one line, declaring the adder result with the input width:

```systemverilog
  logic signed [W-1:0] sum;      // BUG: too narrow
  assign sum = x + d1 + d2 + d3;
```

It compiles in Icarus without complaint. The testbench catches it at once:

```text
FAIL at 80 ns: y=17360 valid=1, expected -48176 valid=1
FAIL at 120 ns: y=-25042 valid=1, expected 40494 valid=1
...
FAILED with 993 errors
```

The true sum −48,176 does not fit in 16 bits, so it wrapped to +17,360: a large negative sample turned into a positive one, which in audio is a loud click. Verilator's lint also flags it (`WIDTHEXPAND` on the assignment of `sum` to the 18-bit `y`).

### Check your understanding: 2.7

1. How many output bits does a moving sum of 8 samples of 12-bit signed input need?
2. With W = 16, what are the largest and smallest values `y` can ever hold? Do they fit in 18 signed bits?
3. What would change if `d1 <= x; d2 <= d1; d3 <= d2;` were written with blocking `=`?
4. Why does the testbench model use `int` instead of 16-bit variables?
5. You want a moving **average**: y\[n\] equals the sum divided by 4. How do you divide by 4 in hardware, and which operator must you use for signed data?
6. `in_valid` is high on only 3 cycles in 4. What happens to the delay line on the other cycles, and why does that matter for a filter?

#### Answers

1. Eight values need log₂ 8 = 3 extra bits: **15 bits**. In general, summing N values needs ⌈log₂ N⌉ extra bits.
2. Largest: 4 × 32,767 = **131,068**. Smallest: 4 × (−32,768) = **−131,072**. An 18-bit signed number ranges from −131,072 to 131,071, so both fit; the most negative sum lands exactly on the limit.
3. The delay line collapses, as in section 2.3: `d1`, `d2` and `d3` all load `x` on the same edge. Worse, simulation and hardware now **disagree**. We tried it: feeding the samples 1, 10, 100 into Icarus gave y = 400, that is 4·x\[n\], because Icarus updated `sum` from the new register values before `y <= sum` read it. Synthesized hardware computes `sum` from the flip-flop outputs, which hold the previous sample, so it would produce x\[n\] + 3·x\[n−1\] = 130. A design whose simulation does not match its hardware is the worst kind of bug, because every test passes or fails for the wrong reason. Verilator flags the cause with `BLKSEQ`.
4. Because the model must be obviously correct. 32-bit `int` arithmetic cannot overflow for these values, so it computes the true sum. A model written with the same 16-bit widths as the design could share the design's overflow bug and pass it.
5. Shift right by 2 bits: `y_avg = sum >>> 2;`. You must use the **arithmetic** shift `>>>` on a signed value, so the sign bit is copied in; `>>` fills with zeros and turns negative averages into large positive ones (section 1.5). Note that shifting right rounds toward minus infinity; Part 6 covers rounding properly.
6. The registers hold their values, because the shift happens only when `in_valid` is 1. That matters because the filter's equation is in **samples**, not clock cycles: x\[n−1\] must be the previous sample, whatever number of clock cycles passed in between. Shifting on every clock would mix samples with idle cycles.

## 2.8 Exercises

Do all six before Part 3; for scale, their worked solutions add 8 design files and 6 testbenches, about 385 new lines (time depends too much on experience for a reliable estimate). For every design: use synchronous active-high `rst`, write a clocked self-checking testbench from the section 2.5 template, lint with `verilator --lint-only -Wall`, and break the design once to prove the testbench can fail. Send me your code when you are done.

- [ ] Exercise 1: synchronizer and edge detector
- [ ] Exercise 2: up/down counter with load
- [ ] Exercise 3: parameterized delay line
- [ ] Exercise 4: LFSR noise generator
- [ ] Exercise 5: moving average of 8
- [ ] Exercise 6: find the bugs in an accumulator

### Exercise 1: synchronizer and rising-edge detector

Design `edge_detect` with inputs `clk`, `rst`, `btn` (an asynchronous input, such as a push-button) and output `pulse`, which is high for exactly **one** clock cycle after each 0-to-1 transition of `btn`.

- First pass `btn` through two flip-flops in series (the synchronizer idea from section 2.4). Then keep one more delayed copy, and detect "was 0, is now 1".
- In the testbench, change `btn` at times that are **not** aligned to the clock (for example `#37`), hold it high for several cycles, and check that each press gives exactly one pulse. Count the pulses.
- How many clock cycles after `btn` rises does `pulse` appear? Explain why.

### Exercise 2: up/down counter with load

Design `updown_counter #(parameter int W = 8)` with inputs `rst`, `en`, `up`, `load`, `d[W-1:0]` and output `count[W-1:0]`. Priority: reset, then load (count becomes `d`), then count up or down by 1 when `en` is 1. The counter wraps around in both directions (255 + 1 = 0 and 0 − 1 = 255 for W = 8).

- Test with random `en`, `up` and occasional `load`. Your model: an `int`, wrapped with `% (1 << W)`. Careful: in SystemVerilog, as in C, `%` of a negative number is negative, so handle the 0 − 1 case explicitly.
- Include directed tests for both wrap-arounds.

### Exercise 3: parameterized delay line

Design `delay_line #(parameter int W = 16, parameter int N = 8)`: output `y` equals input `x` delayed by N **samples**, where a sample arrives on each cycle with `en` = 1.

- Store the taps in an array, `logic [W-1:0] taps [0:N-1];`, and shift them with a `for` loop inside `always_ff`: `for (int i = 1; i < N; i++) taps[i] <= taps[i-1];`. A `for` loop inside an `always_ff` is unrolled into N parallel registers, just like `generate` in section 1.7.
- Verify with N = 1, 2 and 8 (three instances in one testbench is fine). Model the delay line in the testbench with an `int` array.

### Exercise 4: LFSR pseudo-random noise generator

A **linear-feedback shift register** (LFSR) produces a pseudo-random bit sequence from a shift register and a few XOR gates. DSP engineers use it to generate test noise and to scramble data.

Design `lfsr16` with inputs `clk`, `rst`, `en` and a 16-bit state `s`. On reset, load `16'h0001` (the state must never be all zeros). On each enabled clock, shift left by one and insert a new LSB equal to `s[15] ^ s[13] ^ s[12] ^ s[10]`.

- This tap set (the polynomial x¹⁶ + x¹⁴ + x¹³ + x¹¹ + 1) is **maximal-length**: the state visits all 65,535 non-zero values before repeating. Your testbench must confirm it: count enabled clocks until the state returns to `16'h0001`, check the count is exactly 65,535, and check the state is never zero.
- Why can the state never be zero, and what would happen if it were?

### Exercise 5: moving average of 8

Extend section 2.7 to `moving_avg8 #(parameter int W = 16)`: the output is the sum of the last 8 samples divided by 8, with the **same width W** as the input, and with `in_valid` and `out_valid` as before.

- Keep the 7 previous samples in an array, as in Exercise 3, but note that the adder needs every tap, not just the last one, so you cannot simply reuse the delay\_line module as written.
- How many bits does the internal sum need? Divide with an arithmetic shift, then explain why the result always fits back into W bits.
- In the testbench model, compute the expected output with `int` arithmetic and `>>> 3`, so it rounds the same way as the hardware. Include long runs of the extreme values, ±full scale.

### Exercise 6: find the bugs in an accumulator

This accumulator should add each new signed sample to a running total when `en` is high. It has **three** bugs.

```systemverilog
`timescale 1ns/1ps
module accum #(
  parameter int W = 8
) (
  input  logic                clk, rst, en,
  input  logic [W-1:0]        x,      // signed sample
  output logic signed [W+3:0] acc     // running sum of up to 16 samples
);
  always_ff @(posedge clk or rst) begin
    if (rst) acc = 0;
    else if (en) acc <= acc + x;
  end
endmodule
```

1. Compile it with Icarus (`-Wall`) and lint it with Verilator. Each tool finds something the other does not. Write down every message.
2. Fix what the tools found, then write a testbench that adds a sequence of negative samples, such as −1 eight times. The third bug only appears in that test.
3. For each bug, name the rule from Part 1 or Part 2 that it breaks.

## 2.9 Summary and what comes next

You can now write registers, counters, shift registers and a simple filter, and verify them with clocked testbenches. Keep this table beside you for the exercises.

| Concept | Syntax | Remember |
| --- | --- | --- |
| Register | `always_ff @(posedge clk) q <= d;` | Non-blocking `<=` only |
| Synchronous reset | `if (rst) q <= '0; else ...` | Reset branch first; the course default |
| Asynchronous reset | `@(posedge clk or negedge arst_n) if (!arst_n) ...` | Release it through a reset synchronizer |
| Load enable | `else if (en) q <= d;` | No `else` needed: flip-flops hold |
| Fill with zeros or ones | `'0`, `'1` | Correct for any width |
| Width from a parameter | `$clog2(M)` | Bits needed for 0 .. M−1 |
| Size cast | `W'(expr)`, `(W+2)'(x)` | Sign-extends signed values |
| Clock in a testbench | `always #5 clk = ~clk;` | 10 ns period with `1ns` time unit |
| Race-free stimulus | Change inputs at `@(negedge clk)` | Or use `<=` right after `posedge` |
| Slow logic | One clock plus an enable (`tick`) | Never `@(posedge tick)` |
| Delay line (z⁻¹) | `d1 <= x; d2 <= d1;` under `if (in_valid)` | Shift per sample, not per clock |
| Bit growth | Sum of N values: ⌈log₂ N⌉ extra bits | Extend operands before adding |

The ideas that matter most from this part:

1. In a synchronous design, all state changes at the rising clock edge, and timing is a budget: t\_cq + t\_logic + t\_setup ≤ T.
2. `<=` in `always_ff`, `=` in `always_comb`, never mixed. Breaking this rule can make simulation disagree with hardware.
3. A DSP datapath runs on one fast clock, and "valid" or "enable" signals mark the cycles that carry samples.
4. Every adder grows the word; plan the widths before you write the code.

**Part 3: State machines and the RTL method** brings in control. You will turn Mano's state diagrams and ASM charts into finite-state machines with `enum` state types, then split designs into a **datapath** (registers, adders, multiplexers) and a **controller** (the FSM that sequences them). By the end, you will build a sequential multiplier that computes a product over several clock cycles: the slow-but-small counterpart of the fast multipliers in Part 6.
