`timescale 1ns/1ps
// mixer_qw.sv -- mixer.sv with the quarter-wave NCO of the Part 9 solutions (nco_qw2.sv):
// a 2^A-entry table held in 2^(A-2) words. That NCO has 2 cycles of latency instead of 1,
// so x is delayed by two pipeline stages to stay aligned. Latency: 3 cycles.
module mixer_qw #(
  parameter int W = 16, ACC_W = 32, A = 12,
  parameter     QFILE = "qsin12_lut.hex"
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,
  input  logic [ACC_W-1:0]    fcw,
  output logic                out_valid,
  output logic signed [W-1:0] i_out, q_out
);
  logic                lo_valid, v1;
  logic signed [W-1:0] lo_cos, lo_sin, x1, x2;

  nco_qw2 #(.ACC_W(ACC_W), .A(A), .W(W), .QFILE(QFILE)) u_nco (
    .clk(clk), .rst(rst), .en(in_valid), .fcw(fcw),
    .out_valid(lo_valid), .cos_o(lo_cos), .sin_o(lo_sin)
  );

  // align x with the NCO's two pipeline stages (correct even with a sample every clock)
  always_ff @(posedge clk) begin
    if (rst) v1 <= 1'b0;
    else     v1 <= in_valid;
    if (in_valid) x1 <= x;
    if (v1)       x2 <= x1;
  end

  logic signed [2*W-1:0] pi, pq;
  assign pi = x2 * lo_cos;
  assign pq = -(x2 * lo_sin);

  logic signed [W-1:0] i_c, q_c;
  logic                ovf_i_unused, ovf_q_unused;
  requant #(.IN_W(2*W), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_rqi (.din(pi), .dout(i_c), .ovf(ovf_i_unused));
  requant #(.IN_W(2*W), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_rqq (.din(pq), .dout(q_c), .ovf(ovf_q_unused));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= lo_valid;
    if (lo_valid) begin i_out <= i_c; q_out <= q_c; end
  end
endmodule
