`timescale 1ns/1ps
// fir_decim4.sv -- decimating FIR with P = 4 MACs: each MAC handles ceil(N/P) = 8 taps, so one
// output takes 8 cycles. The delay line accepts a sample in EVERY cycle (in_ready = 1): with M = 2
// and inputs at least 8 cycles apart (one CIC output per 8 clocks), a computation always ends
// exactly when the next sample shifts in. Bit-exact with fir_decim.sv (one rounding of the exact sum).
module fir_decim4 #(
  parameter int N = 31, M = 2, P = 4,
  parameter int XW = 16, XF = 15, CW = 18, CF = 17, YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int NP    = (N + P - 1) / P;               // taps per MAC (8)
  localparam int NT    = NP * P;                        // padded length (32)
  localparam int KW    = $clog2(NP);
  localparam int TW    = $clog2(NT);
  localparam int MW    = (M > 1) ? $clog2(M) : 1;
  localparam int ACC_W = XW + CW + KW + 1;              // one MAC's exact sum
  localparam int SUM_W = ACC_W + $clog2(P);             // the sum of P of them
  assign in_ready = 1'b1;

  logic signed [XW-1:0] taps [0:NT-1];
  logic [MW-1:0]        phase;
  logic [KW-1:0]        k;
  logic                 run;

  always_ff @(posedge clk) begin
    if (rst) begin
      phase <= '0;  k <= '0;  run <= 1'b0;
      for (int i = 0; i < NT; i++) taps[i] <= '0;
    end else begin
      if (in_valid) begin
        taps[0] <= x;
        for (int i = 1; i < NT; i++) taps[i] <= taps[i-1];
        phase <= (phase == MW'(M - 1)) ? '0 : phase + 1'b1;
      end
      if (in_valid && phase == MW'(M - 1)) begin run <= 1'b1;  k <= '0; end   // M-th sample: compute
      else if (run) begin
        k <= k + 1'b1;
        if (k == KW'(NP - 1)) run <= 1'b0;
      end
    end
  end

`ifndef SYNTHESIS
  // the timing rule this design relies on: while computing, a new sample may arrive only in the
  // last cycle (its shift then happens after the last tap has been read)
  always @(posedge clk) if (!rst && run && in_valid && k != KW'(NP - 1))
    $error("fir_decim4: input arrived during the computation (inputs closer than %0d cycles)", NP);
`endif

  // P MACs in lockstep: MAC p reads tap p*NP + k (coefficients beyond N are zero)
  logic                    av [0:P-1];
  logic signed [ACC_W-1:0] acc [0:P-1];
  for (genvar p = 0; p < P; p++) begin : g_mac
    logic [TW-1:0] ti;
    assign ti = TW'(p * NP) + TW'(k);
    mac_acc #(.A_W(XW), .B_W(CW), .ACC_W(ACC_W)) u_mac (
      .clk(clk), .rst(rst), .in_valid(run), .first(k == '0), .last(k == KW'(NP - 1)),
      .a(taps[ti]), .b(fir_coef(32'(ti))), .acc_valid(av[p]), .acc(acc[p]));
  end

  logic signed [SUM_W-1:0] total;
  always_comb begin
    total = '0;
    for (int p = 0; p < P; p++) total += SUM_W'(acc[p]);
  end

  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(SUM_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(total), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= av[0];
    if (av[0]) y <= y_c;
  end
endmodule
