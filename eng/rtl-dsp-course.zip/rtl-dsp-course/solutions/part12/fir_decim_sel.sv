`timescale 1ns/1ps
// fir_decim_sel.sv -- fir_decim.sv with a run-time coefficient set (sel), from fir_coefs3.svh.
// (Original header:) decimating FIR: y[m] = sum_k h[k] x[mM + M-1 - k], one output per M inputs.
// Only the outputs that are kept are computed: N MACs per OUTPUT, not per input.
// One MAC (mac.sv, Part 6) is reused for all taps.
module fir_decim_sel #(
  parameter int N = 32, M = 4,
  parameter int XW = 16, XF = 15, CW = 18, CF = 17, YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic [1:0]           sel,            // coefficient set: 0, 1, 2 for R = 4, 8, 16
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs3.svh"
  localparam int KW = $clog2(N), MW = (M > 1) ? $clog2(M) : 1;

  typedef enum logic {S_COLLECT, S_RUN} state_t;
  state_t               state;
  logic [MW-1:0]        phase;                     // samples collected toward the next output
  logic [KW-1:0]        k;                         // tap fed to the MAC this cycle
  logic signed [XW-1:0] taps [0:N-1];

  assign in_ready = (state == S_COLLECT);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_COLLECT;  phase <= '0;  k <= '0;
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else begin
      case (state)
        S_COLLECT: if (in_valid) begin             // accept a sample: shift it in
          taps[0] <= x;
          for (int i = 1; i < N; i++) taps[i] <= taps[i-1];
          if (phase == MW'(M - 1)) begin           // M-th sample: compute one output
            phase <= '0;  k <= '0;  state <= S_RUN;
          end else begin
            phase <= phase + 1'b1;
          end
        end
        S_RUN: begin
          k <= k + 1'b1;
          if (k == KW'(N - 1)) state <= S_COLLECT;
        end
        default: state <= S_COLLECT;
      endcase
    end
  end

  logic mac_ovf_unused;
  mac #(.A_W(XW), .A_F(XF), .B_W(CW), .B_F(CF), .ACC_W(XW + CW + KW + 1),
        .OUT_W(YW), .OUT_F(YF)) u_mac (
    .clk(clk), .rst(rst),
    .in_valid(state == S_RUN), .first(k == '0), .last(k == KW'(N - 1)),
    .a(taps[k]), .b(fir_coef3(32'(sel), 32'(k))),
    .out_valid(out_valid), .dout(y), .dout_ovf(mac_ovf_unused)
  );
endmodule
