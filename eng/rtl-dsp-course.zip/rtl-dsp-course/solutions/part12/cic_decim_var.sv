`timescale 1ns/1ps
// cic_decim_var.sv -- CIC decimator with a RUN-TIME factor: rsel = 0, 1, 2 selects R = 4, 8, 16.
// Registers are sized for the largest R (16 + NS*4 bits); with wrap-around arithmetic the result is
// the same for a smaller R (Part 10). The gain R**NS = 2**(NS*log2 R) is removed by one of three
// rounding shifts, chosen by rsel. Change rsel only while rst is high.
module cic_decim_var #(
  parameter int NS = 5, XW = 16, XF = 15,
  parameter int W  = XW + NS * 4                // 36 bits: enough for R = 16
) (
  input  logic                 clk, rst,
  input  logic [1:0]           rsel,            // 0: R = 4, 1: R = 8, 2: R = 16
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  assign in_ready = 1'b1;
  logic signed [W-1:0] integ  [0:NS-1];
  logic signed [W-1:0] comb_d [0:NS-1];
  logic signed [W-1:0] c      [0:NS];
  logic [3:0]          cnt, rm1;
  logic                dec;

  always_comb case (rsel)
    2'd0:    rm1 = 4'd3;
    2'd1:    rm1 = 4'd7;
    default: rm1 = 4'd15;
  endcase
  assign dec = in_valid && (cnt == rm1);

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < NS; k++) begin integ[k] <= '0; comb_d[k] <= '0; end
      cnt <= '0;
    end else if (in_valid) begin
      integ[0] <= integ[0] + W'(x);
      for (int k = 1; k < NS; k++) integ[k] <= integ[k] + integ[k-1];
      cnt <= dec ? '0 : cnt + 1'b1;
      if (dec) for (int k = 0; k < NS; k++) comb_d[k] <= c[k];
    end
  end
  always_comb begin
    c[0] = integ[NS-1];
    for (int k = 0; k < NS; k++) c[k+1] = c[k] - comb_d[k];
  end

  // the gain: 2**(2 NS), 2**(3 NS) or 2**(4 NS)
  logic signed [XW-1:0] y4, y8, y16, y_c;
  logic                 o4, o8, o16;
  requant #(.IN_W(W), .IN_F(XF + 2 * NS), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1)) u_r4  (.din(c[NS]), .dout(y4),  .ovf(o4));
  requant #(.IN_W(W), .IN_F(XF + 3 * NS), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1)) u_r8  (.din(c[NS]), .dout(y8),  .ovf(o8));
  requant #(.IN_W(W), .IN_F(XF + 4 * NS), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1)) u_r16 (.din(c[NS]), .dout(y16), .ovf(o16));
  wire unused = o4 | o8 | o16;
  always_comb case (rsel)
    2'd0:    y_c = y4;
    2'd1:    y_c = y8;
    default: y_c = y16;
  endcase

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= dec;
    if (dec) y <= y_c;
  end
endmodule
