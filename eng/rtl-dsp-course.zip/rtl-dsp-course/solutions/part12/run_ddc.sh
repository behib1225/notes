#!/bin/sh
# run_ddc.sh -- regenerate, simulate and check in ONE run, for several seeds; stop at the first failure.
# Checks per seed: bit-exact (testbench), independent model check, specification checks (no FCW switch).
# Usage: ./run_ddc.sh [seeds] [gap] [switch-sample]      e.g. ./run_ddc.sh 5 5 9000
set -e
SEEDS=${1:-3}; GAP=${2:-5}; SW=${3:--1}
iverilog -g2012 -Wall -o sim_ddc2 ddc.sv mixer.sv nco.sv cic_decim.sv fir_decim.sv mac.sv requant.sv tb_ddc2.sv
for SEED in $(seq 1 "$SEEDS"); do
  rm -f x.hex y_expected.txt y_actual.txt fcws.npy        # no file can survive from an earlier run
  python3 ddc_gen.py --seed "$SEED" --switch "$SW" --fcw1 3e147ae1
  vvp -n sim_ddc2 +SEED="$SEED" +GAP="$GAP" +SWITCH="$SW" +FCW1=3e147ae1 > sim.log 2>&1 || true
  grep -E "PASS|FAIL|FATAL|ERROR" sim.log
  grep -q "^PASS" sim.log                               # stop here if the simulation did not pass
  python3 ddc_check.py
  if [ "$SW" -lt 0 ]; then python3 ddc_spec.py; fi      # specification checks (Appendix B)
done
echo "all $SEEDS seeds passed"
