`timescale 1ns/1ps
module tb_lat; logic clk=0, rst, in_valid, out_valid; logic signed [15:0] i_in=1000, q_in=0; logic [31:0] fcw=32'h26666666;
`ifdef CORDIC logic signed [17:0] i_out, q_out; cordic_mixer dut (.*); `else logic signed [15:0] i_out, q_out; cmixer #(.GAUSS(`GAUSS)) dut (.*); `endif
always #5 clk = ~clk; int n=0;
initial begin rst=1; in_valid=0; repeat(3) @(negedge clk); rst=0; in_valid=1; @(negedge clk); in_valid=0;
 while(!out_valid) begin @(negedge clk); n++; end $display("%0d", n+1); $finish; end endmodule