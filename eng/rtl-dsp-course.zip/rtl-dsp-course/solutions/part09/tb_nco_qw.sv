`timescale 1ns/1ps
// tb_nco_po.sv -- enabled samples with random gaps; optional FCW change at sample +SWITCH
module tb_nco_qw;
  logic clk = 1'b0, rst, en, out_valid;
  logic [31:0] fcw, fcw0 = 32'h0b3a5c1f, fcw1 = 32'h1999999a;
  logic [15:0] phase_off = 16'h0000;
  logic signed [15:0] cos_o, sin_o;
  int n = 2048, sw = -1, sent = 0, got = 0, fd;
  `ifdef A12
    nco_qw #(.A(12), .QFILE("qsin12_lut.hex")) dut (.clk, .rst, .en, .fcw, .out_valid, .cos_o, .sin_o);
  `else
    nco_qw dut (.clk, .rst, .en, .fcw, .out_valid, .cos_o, .sin_o);
  `endif
  always #5 clk = ~clk;
  initial begin
    void'($value$plusargs("PO=%h", phase_off));
    void'($value$plusargs("N=%d", n));
    void'($value$plusargs("SWITCH=%d", sw));
    void'($value$plusargs("FCW0=%h", fcw0));
    fd = $fopen("nco_out.txt", "w");
    fcw = fcw0; rst = 1'b1; en = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    forever begin
      en = ($urandom_range(0, 3) != 0);
      if (en && sent == sw) fcw = fcw1;               // change frequency at this sample
      if (en) sent++;
      @(negedge clk);
    end
  end
  always @(negedge clk) if (!rst && out_valid) begin
    $fdisplay(fd, "%0d %0d", cos_o, sin_o);
    if (++got == n) begin $fclose(fd); $finish; end
  end
endmodule
