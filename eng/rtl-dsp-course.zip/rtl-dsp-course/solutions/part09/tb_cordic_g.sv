`timescale 1ns/1ps
// tb_cordic.sv -- reads "x y z" lines, writes "x y" results in order
module tb_cordic_g;
  logic clk = 1'b0, rst, in_valid, out_valid;
  logic signed [15:0] x_in, y_in;
  logic signed [19:0] z_in;
  logic signed [17:0] x_out, y_out;
  int fi, fo, code, rx, ry, rz, sent = 0, got = 0;
  cordic_g #(.G(`GB), .N_IT(`NIT)) dut (.*);
  always #5 clk = ~clk;
  initial begin
    fi = $fopen("cordic_in.txt", "r"); fo = $fopen("cordic_out.txt", "w");
    rst = 1'b1; in_valid = 1'b0; x_in = '0; y_in = '0; z_in = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    code = 3;
    while (code == 3) begin
      if ($urandom_range(0, 4) == 0) in_valid = 1'b0;          // occasional gap
      else begin
        code = $fscanf(fi, "%d %d %d\n", rx, ry, rz);
        in_valid = (code == 3);
        x_in = rx; y_in = ry; z_in = rz;
        if (code == 3) sent++;
      end
      @(negedge clk);
    end
    in_valid = 1'b0;
    repeat (30) @(negedge clk);
    $fclose(fo);
    $display("sent %0d, received %0d", sent, got);
    $finish;
  end
  always @(negedge clk) if (!rst && out_valid) begin
    $fdisplay(fo, "%0d %0d", x_out, y_out); got++;
  end
endmodule
