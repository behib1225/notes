`timescale 1ns/1ps
// cmixer.sv -- complex mixer: (I + jQ) * exp(-j w0 n) = (I cos + Q sin) + j (Q cos - I sin).
// GAUSS = 0: four multipliers. GAUSS = 1: three multipliers (Gauss's trick), same exact sums.
// Q1.15 in and out (round, saturate). The NCO advances once per valid input. Latency: 2 cycles.
module cmixer #(
  parameter int W = 16, ACC_W = 32,
  parameter bit GAUSS = 1'b0
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] i_in, q_in,
  input  logic [ACC_W-1:0]    fcw,
  output logic                out_valid,
  output logic signed [W-1:0] i_out, q_out
);
  logic                lo_valid;
  logic signed [W-1:0] c, s, a, b;               // LO cos, sin; delayed input a + jb

  nco #(.ACC_W(ACC_W), .W(W)) u_nco (
    .clk(clk), .rst(rst), .en(in_valid), .fcw(fcw),
    .out_valid(lo_valid), .cos_o(c), .sin_o(s));

  always_ff @(posedge clk) if (in_valid) begin a <= i_in; b <= q_in; end   // align with the NCO

  localparam int SW = 2 * W + 2;                 // 34 bits: enough for both forms
  logic signed [SW-1:0] re, im;
  if (!GAUSS) begin : g_four
    // (a + jb)(c - js) = (ac + bs) + j(bc - as)
    assign re = SW'(a * c) + SW'(b * s);
    assign im = SW'(b * c) - SW'(a * s);
  end else begin : g_three
    // Gauss with d = -s:  k1 = c(a + b), k2 = a(d - c), k3 = b(c + d);  re = k1 - k3, im = k1 + k2
    logic signed [W:0] ab, dmc, cpd;             // pre-sums: 17 bits
    logic signed [SW-1:0] k1, k2, k3;            // products: 16 x 17 bits
    assign ab  = (W+1)'(a) + (W+1)'(b);
    assign dmc = -((W+1)'(s)) - (W+1)'(c);       // parenthesized: Yosys reads -(W+1)'(s) as a cast to width -(W+1)
    assign cpd = (W+1)'(c) - (W+1)'(s);
    assign k1  = SW'(c * ab);
    assign k2  = SW'(a * dmc);
    assign k3  = SW'(b * cpd);
    assign re  = k1 - k3;
    assign im  = k1 + k2;
  end

  logic signed [W-1:0] re_c, im_c;
  logic                o1, o2;
  requant #(.IN_W(SW), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_re (.din(re), .dout(re_c), .ovf(o1)),
    u_im (.din(im), .dout(im_c), .ovf(o2));
  wire unused = o1 | o2;

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= lo_valid;
    if (lo_valid) begin i_out <= re_c; q_out <= im_c; end
  end
endmodule
