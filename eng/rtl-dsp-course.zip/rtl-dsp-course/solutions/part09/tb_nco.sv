`timescale 1ns/1ps
// tb_nco.sv -- runs the NCO for N enabled samples (with random gaps), writes cos and sin
module tb_nco;
  logic clk = 1'b0, rst, en, out_valid;
  logic [31:0] fcw = 32'h1999999a;
  logic signed [15:0] cos_o, sin_o;
  int n = 4096, got = 0, fd;
  nco dut (.*);
  always #5 clk = ~clk;
  initial begin
    void'($value$plusargs("FCW=%h", fcw));
    void'($value$plusargs("N=%d", n));
    fd = $fopen("nco_out.txt", "w");
    rst = 1'b1; en = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    forever begin
      en = ($urandom_range(0, 3) != 0);
      @(negedge clk);
    end
  end
  always @(negedge clk) if (!rst && out_valid) begin
    $fdisplay(fd, "%0d %0d", cos_o, sin_o);
    if (++got == n) begin $fclose(fd); $finish; end
  end
endmodule
