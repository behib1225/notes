`timescale 1ns/1ps
// cordic_g.sv -- the Part 9 CORDIC with G fractional guard bits inside:
// inputs are shifted left by G, every stage works in OW + G bits, and the outputs are
// rounded back to OW bits once at the end. G = 0 is the original design.
module cordic_g #(
  parameter int XW = 16, OW = 18, ZW = 20, N_IT = 16, G = 4
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  input  logic signed [XW-1:0] x_in, y_in,
  input  logic signed [ZW-1:0] z_in,
  output logic                 out_valid,
  output logic signed [OW-1:0] x_out, y_out
);
  `include "cordic_atan.svh"
  localparam int CW = OW + G;                                    // internal width
  localparam logic signed [ZW-1:0] QUARTER = ZW'(1) <<< (ZW - 2);

  logic signed [CW-1:0] x [0:N_IT];
  logic signed [CW-1:0] y [0:N_IT];
  logic signed [ZW-1:0] z [0:N_IT];
  logic                 v [0:N_IT];
  logic signed [CW-1:0] xi, yi;
  assign xi = CW'(x_in) <<< G;                                    // G guard bits below the LSB
  assign yi = CW'(y_in) <<< G;

  always_ff @(posedge clk) begin
    if (rst) v[0] <= 1'b0;
    else     v[0] <= in_valid;
    if (z_in > QUARTER)       begin x[0] <= -yi;  y[0] <= xi;   z[0] <= z_in - QUARTER; end
    else if (z_in < -QUARTER) begin x[0] <= yi;   y[0] <= -xi;  z[0] <= z_in + QUARTER; end
    else                      begin x[0] <= xi;   y[0] <= yi;   z[0] <= z_in;           end
  end

  for (genvar i = 0; i < N_IT; i++) begin : g_stage
    always_ff @(posedge clk) begin
      if (rst) v[i+1] <= 1'b0;
      else     v[i+1] <= v[i];
      if (z[i] >= 0) begin
        x[i+1] <= x[i] - (y[i] >>> i);  y[i+1] <= y[i] + (x[i] >>> i);  z[i+1] <= z[i] - cordic_atan(i);
      end else begin
        x[i+1] <= x[i] + (y[i] >>> i);  y[i+1] <= y[i] - (x[i] >>> i);  z[i+1] <= z[i] + cordic_atan(i);
      end
    end
  end

  // one rounding at the end, back to OW bits (none needed when G = 0)
  if (G > 0) begin : g_round
    logic ovx, ovy;
    requant #(.IN_W(CW), .IN_F(G), .OUT_W(OW), .OUT_F(0), .RND(1), .SAT(1'b1))
      u_x (.din(x[N_IT]), .dout(x_out), .ovf(ovx)),
      u_y (.din(y[N_IT]), .dout(y_out), .ovf(ovy));
    wire unused = ovx | ovy;
  end else begin : g_plain
    assign x_out = x[N_IT];
    assign y_out = y[N_IT];
  end
  assign out_valid = v[N_IT];
endmodule
