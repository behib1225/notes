// cordic_atan.svh -- generated: atan(2^-i) in binary angle units (full turn = 2^20)
function automatic logic signed [19:0] cordic_atan(input int i);
  case (i)
     0: cordic_atan = 20'sd131072;
     1: cordic_atan = 20'sd77376;
     2: cordic_atan = 20'sd40884;
     3: cordic_atan = 20'sd20753;
     4: cordic_atan = 20'sd10417;
     5: cordic_atan = 20'sd5213;
     6: cordic_atan = 20'sd2607;
     7: cordic_atan = 20'sd1304;
     8: cordic_atan = 20'sd652;
     9: cordic_atan = 20'sd326;
    10: cordic_atan = 20'sd163;
    11: cordic_atan = 20'sd81;
    12: cordic_atan = 20'sd41;
    13: cordic_atan = 20'sd20;
    14: cordic_atan = 20'sd10;
    15: cordic_atan = 20'sd5;
    16: cordic_atan = 20'sd3;
    17: cordic_atan = 20'sd1;
    18: cordic_atan = 20'sd1;
    19: cordic_atan = 20'sd0;
    20: cordic_atan = 20'sd0;
    21: cordic_atan = 20'sd0;
    22: cordic_atan = 20'sd0;
    23: cordic_atan = 20'sd0;
    default: cordic_atan = '0;
  endcase
endfunction
