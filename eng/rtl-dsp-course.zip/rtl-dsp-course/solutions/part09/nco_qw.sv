`timescale 1ns/1ps
// nco_qw.sv -- NCO with a quarter-wave sine table: 2^(A-2) entries reproduce the full
// 2^A-entry cosine and sine tables exactly, using the symmetries of the sine.
module nco_qw #(
  parameter int    ACC_W = 32, A = 10, W = 16,
  parameter        QFILE = "qsin_lut.hex"        // sin(2 pi k / 2^A), k = 0 .. 2^(A-2) - 1 (untyped: Yosys 0.33 rejects "string")
) (
  input  logic                clk, rst,
  input  logic                en,
  input  logic [ACC_W-1:0]    fcw,
  output logic                out_valid,
  output logic signed [W-1:0] cos_o, sin_o
);
  localparam int QA = A - 2;                       // quarter-table address bits
  localparam logic signed [W-1:0] MAX = {1'b0, {(W-1){1'b1}}};   // 32767 = sin(90 degrees)

  logic [ACC_W-1:0]    phase;
  logic signed [W-1:0] qrom [0:(1<<QA)-1];
  initial $readmemh(QFILE, qrom);

  // sine of the A-bit angle a, from the quarter table
  function automatic logic signed [W-1:0] qsin(input logic [A-1:0] a);
    logic [1:0]    quad;
    logic [QA-1:0] i;
    logic signed [W-1:0] v;
    quad = a[A-1 -: 2];
    i    = a[QA-1:0];
    if (!quad[0])        v = qrom[i];               // quadrants 0 and 2: read forward
    else if (i == '0)    v = MAX;                   // exactly 90 or 270 degrees: not stored
    else                 v = qrom[QA'(0) - i];      // quadrants 1 and 3: read backward, N/4 - i
    qsin = quad[1] ? -v : v;                         // quadrants 2 and 3: negate (no "return": Yosys 0.33)
  endfunction

  logic [A-1:0] a_sin, a_cos;
  assign a_sin = phase[ACC_W-1 -: A];
  assign a_cos = a_sin + A'(1 << QA);               // cos(a) = sin(a + 90 degrees)

  always_ff @(posedge clk) begin
    if (rst) begin
      phase <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= en;
      if (en) begin
        sin_o <= qsin(a_sin);
        cos_o <= qsin(a_cos);
        phase <= phase + fcw;
      end
    end
  end
endmodule
