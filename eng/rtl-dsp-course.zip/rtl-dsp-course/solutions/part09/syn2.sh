#!/bin/bash
rep() { yosys -q -p "read_verilog -sv $1; $3 synth_xilinx -family xc7 -flatten -top $2; tee -q -o /dev/stdout stat" 2>/dev/null | awk '/DSP48E1|RAMB|CARRY4/{printf "%s=%s ", $1, $2} /^ +LUT[1-6] /{l+=$2} /^ +FD[A-Z]* /{f+=$2} END{printf "LUT=%d FF=%d\n", l, f}'; }
echo -n "cmixer, 4 mult:   "; rep "cmixer.sv nco.sv requant.sv" cmixer ""
echo -n "cmixer, Gauss:    "; rep "cmixer.sv nco.sv requant.sv" cmixer "chparam -set GAUSS 1 cmixer;"
echo -n "cordic_mixer:     "; rep "cordic_mixer.sv cordic.sv" cordic_mixer ""
