`timescale 1ns/1ps
// cordic.sv -- pipelined CORDIC in rotation mode: rotates (x, y) by angle z.
// Only shifts and adds. Output is scaled by the CORDIC gain K = 1.6468 (for 16 stages).
// Angle z: binary angle units, full turn = 2**ZW. Latency: N_IT + 1 cycles.
module cordic #(
  parameter int XW = 16,                 // input x, y width (Q1.15)
  parameter int CW = 18,                 // internal and output width: 2 guard bits for the gain
  parameter int ZW = 20,                 // angle width
  parameter int N_IT = 16                // iterations = pipeline stages
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  input  logic signed [XW-1:0] x_in, y_in,
  input  logic signed [ZW-1:0] z_in,     // -1/2 .. +1/2 turn
  output logic                 out_valid,
  output logic signed [CW-1:0] x_out, y_out
);
  `include "cordic_atan.svh"
  localparam logic signed [ZW-1:0] QUARTER = ZW'(1) <<< (ZW - 2);   // 90 degrees

  logic signed [CW-1:0] x [0:N_IT];
  logic signed [CW-1:0] y [0:N_IT];
  logic signed [ZW-1:0] z [0:N_IT];
  logic                 v [0:N_IT];

  // stage 0: rotate by +-90 degrees if needed, so the remaining angle is within +-90
  always_ff @(posedge clk) begin
    if (rst) v[0] <= 1'b0;
    else     v[0] <= in_valid;
    if (z_in > QUARTER) begin
      x[0] <= -(CW'(y_in)); y[0] <= CW'(x_in);   z[0] <= z_in - QUARTER;
    end else if (z_in < -QUARTER) begin
      x[0] <= CW'(y_in);    y[0] <= -(CW'(x_in));  z[0] <= z_in + QUARTER;
    end else begin
      x[0] <= CW'(x_in);   y[0] <= CW'(y_in);   z[0] <= z_in;
    end
  end

  // stages 1..N_IT: one micro-rotation each, by +-atan(2^-i)
  for (genvar i = 0; i < N_IT; i++) begin : g_stage
    always_ff @(posedge clk) begin
      if (rst) v[i+1] <= 1'b0;
      else     v[i+1] <= v[i];
      if (z[i] >= 0) begin                      // rotate counter-clockwise
        x[i+1] <= x[i] - (y[i] >>> i);
        y[i+1] <= y[i] + (x[i] >>> i);
        z[i+1] <= z[i] - cordic_atan(i);
      end else begin                            // rotate clockwise
        x[i+1] <= x[i] + (y[i] >>> i);
        y[i+1] <= y[i] - (x[i] >>> i);
        z[i+1] <= z[i] + cordic_atan(i);
      end
    end
  end

  assign x_out = x[N_IT];
  assign y_out = y[N_IT];
  assign out_valid = v[N_IT];
endmodule
