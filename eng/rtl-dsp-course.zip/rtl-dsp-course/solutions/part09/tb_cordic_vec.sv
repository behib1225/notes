`timescale 1ns/1ps
module tb_cordic_vec;
  logic clk = 1'b0, rst, in_valid, out_valid;
  logic signed [15:0] x_in, y_in;
  logic signed [17:0] mag;
  logic signed [19:0] ang;
  int fi, fo, code = 2, rx, ry, sent = 0, got = 0;
  cordic_vec #(.G(`GB)) dut (.*);
  always #5 clk = ~clk;
  initial begin
    fi = $fopen("vec_in.txt", "r"); fo = $fopen("vec_out.txt", "w");
    rst = 1'b1; in_valid = 1'b0; x_in = '0; y_in = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    while (code == 2) begin
      if ($urandom_range(0, 4) == 0) in_valid = 1'b0;
      else begin
        code = $fscanf(fi, "%d %d\n", rx, ry);
        in_valid = (code == 2); x_in = rx; y_in = ry; if (code == 2) sent++;
      end
      @(negedge clk);
    end
    in_valid = 1'b0; repeat (30) @(negedge clk);
    $fclose(fo); $display("sent %0d, received %0d", sent, got); $finish;
  end
  always @(negedge clk) if (!rst && out_valid) begin $fdisplay(fo, "%0d %0d", mag, ang); got++; end
endmodule
