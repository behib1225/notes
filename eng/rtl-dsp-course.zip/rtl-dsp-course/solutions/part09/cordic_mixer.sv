`timescale 1ns/1ps
// cordic_mixer.sv -- complex mixer built from a phase accumulator and the Part 9 CORDIC:
// rotates (I, Q) by -phase. Outputs are scaled by the CORDIC gain K = 1.6468 (18 bits).
module cordic_mixer #(
  parameter int W = 16, ACC_W = 32, ZW = 20
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] i_in, q_in,
  input  logic [ACC_W-1:0]    fcw,
  output logic                out_valid,
  output logic signed [17:0]  i_out, q_out
);
  logic [ACC_W-1:0] phase;
  always_ff @(posedge clk) begin
    if (rst)           phase <= '0;
    else if (in_valid) phase <= phase + fcw;
  end
  logic signed [ZW-1:0] z;
  assign z = -$signed(phase[ACC_W-1 -: ZW]);          // rotate by minus the LO phase
  cordic u_c (.clk(clk), .rst(rst), .in_valid(in_valid), .x_in(i_in), .y_in(q_in), .z_in(z),
              .out_valid(out_valid), .x_out(i_out), .y_out(q_out));
endmodule
