`timescale 1ns/1ps
// cordic_vec.sv -- CORDIC in VECTORING mode: rotates (x, y) onto the positive x-axis.
// Outputs: mag = K * sqrt(x^2 + y^2) (K = 1.6468 for 16 stages), ang = atan2(y, x)
// in binary angle units (full turn = 2^ZW). Latency: N_IT + 1 cycles.
module cordic_vec #(
  parameter int XW = 16, OW = 18, ZW = 20, N_IT = 16,
  parameter int G = 4                           // fractional guard bits inside (0 = none)
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  input  logic signed [XW-1:0] x_in, y_in,
  output logic                 out_valid,
  output logic signed [OW-1:0] mag,
  output logic signed [ZW-1:0] ang
);
  `include "cordic_atan.svh"
  localparam logic signed [ZW-1:0] QUARTER = ZW'(1) <<< (ZW - 2);   // 90 degrees
  localparam int CW = OW + G;                   // internal width

  logic signed [CW-1:0] x [0:N_IT];
  logic signed [CW-1:0] y [0:N_IT];
  logic signed [ZW-1:0] z [0:N_IT];
  logic                 v [0:N_IT];

  logic signed [CW-1:0] xi, yi;
  assign xi = CW'(x_in) <<< G;
  assign yi = CW'(y_in) <<< G;

  // stage 0: bring the left half-plane to the right by rotating 90 degrees, and remember it
  always_ff @(posedge clk) begin
    if (rst) v[0] <= 1'b0;
    else     v[0] <= in_valid;
    if (x_in < 0 && y_in >= 0) begin            // second quadrant: rotate by -90
      x[0] <= yi;             y[0] <= -xi;           z[0] <= QUARTER;
    end else if (x_in < 0) begin                // third quadrant: rotate by +90
      x[0] <= -yi;            y[0] <= xi;            z[0] <= -QUARTER;
    end else begin
      x[0] <= xi;             y[0] <= yi;            z[0] <= '0;
    end
  end

  // stages: rotate toward the x-axis (d = -sign(y)), accumulating the angle rotated
  for (genvar i = 0; i < N_IT; i++) begin : g_stage
    always_ff @(posedge clk) begin
      if (rst) v[i+1] <= 1'b0;
      else     v[i+1] <= v[i];
      if (y[i] >= 0) begin                       // rotate clockwise
        x[i+1] <= x[i] + (y[i] >>> i);  y[i+1] <= y[i] - (x[i] >>> i);  z[i+1] <= z[i] + cordic_atan(i);
      end else begin                             // rotate counter-clockwise
        x[i+1] <= x[i] - (y[i] >>> i);  y[i+1] <= y[i] + (x[i] >>> i);  z[i+1] <= z[i] - cordic_atan(i);
      end
    end
  end

  if (G > 0) begin : g_round                    // round the magnitude back to OW bits
    logic ovm;
    requant #(.IN_W(CW), .IN_F(G), .OUT_W(OW), .OUT_F(0), .RND(1), .SAT(1'b1))
      u_m (.din(x[N_IT]), .dout(mag), .ovf(ovm));
    wire unused = ovm;
  end else begin : g_plain
    assign mag = x[N_IT];
  end
  assign ang = z[N_IT];
  assign out_valid = v[N_IT];
endmodule
