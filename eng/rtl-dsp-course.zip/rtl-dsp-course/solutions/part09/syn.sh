#!/bin/bash
rep() { yosys -q -p "read_verilog -sv $1; $3 synth_xilinx -family xc7 -flatten -top $2; tee -q -o /dev/stdout stat" 2>/dev/null | awk '/RAMB|LUT[1-6] |FD|CARRY|RAM32|RAM64|MUXF/{printf "%s=%s ", $1, $2}'; echo; }
echo -n "nco (full, A=10):     "; rep nco.sv nco ""
echo -n "nco_qw (A=10):        "; rep nco_qw.sv nco_qw ""
echo -n "nco_qw (A=12):        "; rep nco_qw.sv nco_qw "chparam -set A 12 -set QFILE \"qsin12_lut.hex\" nco_qw;"
python3 -c "from dds_model import write_lut_files; write_lut_files(12)"
echo -n "nco_qw2 (A=10):       "; rep nco_qw2.sv nco_qw2 ""
echo -n "nco_qw2 (A=12):       "; rep nco_qw2.sv nco_qw2 "chparam -set A 12 -set QFILE \"qsin12_lut.hex\" nco_qw2;"
echo -n "nco (full, A=12):     "; rep nco.sv nco "chparam -set A 12 nco;"
python3 -c "from dds_model import write_lut_files; write_lut_files(10)"
