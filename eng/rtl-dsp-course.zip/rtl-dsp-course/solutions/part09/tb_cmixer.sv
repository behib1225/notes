`timescale 1ns/1ps
module tb_cmixer;
  logic clk = 1'b0, rst, in_valid, out_valid;
  logic signed [15:0] i_in, q_in, i_out, q_out;
  logic [31:0] fcw = 32'h26666666;               // 0.15 cycles/sample
  logic [15:0] ri, rq;
  int fi, fo, code = 2, n = 0, got = 0;
  cmixer #(.GAUSS(`GAUSS)) dut (.*);
  always #5 clk = ~clk;
  initial begin
    fi = $fopen("cm_in.txt", "r"); fo = $fopen("cm_out.txt", "w");
    rst = 1'b1; in_valid = 1'b0; i_in = '0; q_in = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    while (code == 2) begin
      if ($urandom_range(0, 3) == 0) begin in_valid = 1'b0; i_in = 'x; q_in = 'x; end
      else begin code = $fscanf(fi, "%h %h\n", ri, rq); in_valid = (code == 2); i_in = ri; q_in = rq; end
      @(negedge clk);
    end
    in_valid = 1'b0; repeat (5) @(negedge clk); $fclose(fo); $display("%0d outputs", got); $finish;
  end
  always @(negedge clk) if (!rst && out_valid) begin $fdisplay(fo, "%0d %0d", i_out, q_out); got++; end
endmodule
