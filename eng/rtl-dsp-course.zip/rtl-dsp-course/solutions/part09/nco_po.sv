`timescale 1ns/1ps
// nco_po.sv -- the Part 9 NCO with a phase-offset input: output = cos/sin(phase + offset).
// The 16-bit offset is a binary angle (full turn = 2^16) added to the top of the phase.
module nco_po #(
  parameter int ACC_W = 32, A = 10, W = 16, PW = 16
) (
  input  logic                clk, rst,
  input  logic                en,
  input  logic [ACC_W-1:0]    fcw,
  input  logic [PW-1:0]       phase_off,     // 0x4000 = 90 degrees
  output logic                out_valid,
  output logic signed [W-1:0] cos_o, sin_o
);
  logic [ACC_W-1:0]    phase;
  // The low PW-A bits of phase_top are never read, but they are needed: they produce the carry
  // into the address bits when the offset has non-zero low bits (0x1234, say).
  /* verilator lint_off UNUSEDSIGNAL */
  logic [PW-1:0]       phase_top;             // the top PW bits of (phase + offset)
  /* verilator lint_on UNUSEDSIGNAL */
  logic signed [W-1:0] cos_rom [0:(1<<A)-1];
  logic signed [W-1:0] sin_rom [0:(1<<A)-1];
  initial begin
    $readmemh("cos_lut.hex", cos_rom);
    $readmemh("sin_lut.hex", sin_rom);
  end

  // the offset is aligned with the top of the accumulator; only the top PW bits can change,
  // so the addition needs only PW bits (and wraps modulo a full turn)
  assign phase_top = phase[ACC_W-1 -: PW] + phase_off;

  always_ff @(posedge clk) begin
    if (rst) begin
      phase <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= en;
      if (en) begin
        cos_o <= cos_rom[phase_top[PW-1 -: A]];
        sin_o <= sin_rom[phase_top[PW-1 -: A]];
        phase <= phase + fcw;                     // the accumulator itself is not offset
      end
    end
  end
endmodule
