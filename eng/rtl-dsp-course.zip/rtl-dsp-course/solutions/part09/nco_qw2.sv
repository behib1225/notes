`timescale 1ns/1ps
// nco_qw2.sv -- nco_qw with the quarter-table reads registered FIRST (so they map to block RAM),
// and the symmetry (backward read, 90-degree case, negation) applied in a second stage.
// Same outputs as nco_qw, one cycle later.
module nco_qw2 #(
  parameter     ACC_W = 32, A = 10, W = 16,
  parameter     QFILE = "qsin_lut.hex"
) (
  input  logic                clk, rst,
  input  logic                en,
  input  logic [ACC_W-1:0]    fcw,
  output logic                out_valid,
  output logic signed [W-1:0] cos_o, sin_o
);
  localparam int QA = A - 2;
  localparam logic signed [W-1:0] MAX = {1'b0, {(W-1){1'b1}}};

  logic [ACC_W-1:0]    phase;
  logic signed [W-1:0] qrom [0:(1<<QA)-1];
  initial $readmemh(QFILE, qrom);

  logic [A-1:0]  a_s, a_c;
  assign a_s = phase[ACC_W-1 -: A];
  assign a_c = a_s + A'(1 << QA);                  // cos(a) = sin(a + 90 degrees)

  // table address: forward in quadrants 0 and 2, backward (N/4 - i) in 1 and 3
  function automatic logic [QA-1:0] qaddr(input logic [A-1:0] a);
    qaddr = a[A-2] ? (QA'(0) - a[QA-1:0]) : a[QA-1:0];
  endfunction
  // the special case: exactly 90 or 270 degrees, whose value is not stored
  function automatic logic is_peak(input logic [A-1:0] a);
    is_peak = a[A-2] && (a[QA-1:0] == '0);
  endfunction

  // stage 1: registered ROM reads (two ports) and the control bits that go with them
  logic signed [W-1:0] qs, qc;
  logic                neg_s, neg_c, pk_s, pk_c, v1;
  always_ff @(posedge clk) begin
    if (rst) v1 <= 1'b0;
    else     v1 <= en;
    if (en) begin
      qs <= qrom[qaddr(a_s)];  neg_s <= a_s[A-1];  pk_s <= is_peak(a_s);
      qc <= qrom[qaddr(a_c)];  neg_c <= a_c[A-1];  pk_c <= is_peak(a_c);
    end
  end

  // stage 2: apply the symmetry
  always_ff @(posedge clk) begin
    if (rst) begin
      phase <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= v1;
      if (en) phase <= phase + fcw;
      if (v1) begin
        sin_o <= neg_s ? -(pk_s ? MAX : qs) : (pk_s ? MAX : qs);
        cos_o <= neg_c ? -(pk_c ? MAX : qc) : (pk_c ? MAX : qc);
      end
    end
  end
endmodule
