#!/usr/bin/env python3
"""gen_mac.py -- stimulus and bit-exact golden model for mac.sv with Q1.15 samples a and
Q1.17 (18-bit) coefficients b: products Q2.32, exact sum, rounded to Q1.15."""
import argparse
import numpy as np
from fixedpoint import quantize, requant, to_real

p = argparse.ArgumentParser()
p.add_argument("--seed", type=int, default=1)
p.add_argument("--groups", type=int, default=300)
args = p.parse_args()
rng = np.random.default_rng(args.seed)

rows, expected, ideal = [], [], []
for g in range(args.groups):
    L = int(rng.integers(1, 65))                     # vector length 1..64
    kind = g % 10
    if kind == 0:                                    # worst case: -1 * -1 every time -> saturates
        a = np.full(L, -32768); b = np.full(L, -131072)
    elif kind == 1:                                  # small vectors: sum stays inside Q1.15
        a = rng.integers(-32768, 32768, L); b = rng.integers(-131072, 131072, L) // max(L, 1)
    else:                                            # random real values, scaled so sums rarely overflow
        a = quantize(rng.uniform(-1, 1, L), 16, 15)
        b = quantize(rng.uniform(-1, 1, L) / np.sqrt(L), 18, 17)
    for i in range(L):
        rows.append((int(a[i]) & 0xFFFF, int(b[i]) & 0x3FFFF, int(i == 0), int(i == L - 1)))
    acc = int(np.sum(a.astype(np.int64) * b.astype(np.int64)))      # exact sum, Q?.32
    expected.append(int(requant(np.array([acc]), 32, 16, 15, "round", "saturate")[0]))
    ideal.append(float(np.dot(to_real(a, 15), to_real(b, 17))))     # floating-point reference

with open("mac_in.txt", "w") as f:
    for r in rows:
        f.write(f"{r[0]:04x} {r[1]:05x} {r[2]} {r[3]}\n")
with open("mac_expected.txt", "w") as f:
    f.write("\n".join(str(v) for v in expected) + "\n")
np.save("mac_ideal.npy", np.array(ideal))
print(f"{len(rows)} products in {args.groups} dot products")
