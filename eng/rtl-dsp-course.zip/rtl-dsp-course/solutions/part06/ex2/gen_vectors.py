#!/usr/bin/env python3
"""gen_vectors.py -- vectors and models for moving_avg8: rounded (new) and floored (old)."""
import argparse
import numpy as np
from fixedpoint import requant

W = 16

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def moving_sum(x):
    return np.convolve(np.asarray(x, np.int64), np.ones(8, dtype=np.int64))[: len(x)]

def golden(x):        # new design: sum with 3 fractional bits -> integer, round half up, saturate
    return requant(moving_sum(x), 3, W, 0, "round", "saturate")

def golden_old(x):    # old design: arithmetic shift (floor)
    return moving_sum(x) >> 3

def stimulus(n, seed):
    rng = np.random.default_rng(seed)
    x = rng.integers(-(1 << (W - 1)), 1 << (W - 1), size=n)
    x[100:140] = (1 << (W - 1)) - 1          # long full-scale runs: the extreme sums
    x[200:240] = -(1 << (W - 1))
    return x

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=100000); p.add_argument("--seed", type=int, default=1)
    p.add_argument("--old", action="store_true")
    a = p.parse_args()
    x = stimulus(a.n, a.seed)
    y = golden_old(x) if a.old else golden(x)
    open("x.hex", "w").write("\n".join(to_hex(x, W)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(y, W)) + "\n")
    print(f"{a.n} samples ({'old' if a.old else 'new'} model)")
