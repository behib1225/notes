#!/usr/bin/env python3
"""measure.py -- run old and new RTL on the same 100,000 samples; error against the exact average."""
import subprocess
import numpy as np
from gen_vectors import stimulus, moving_sum, golden, golden_old, W

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

N = 100000
x = stimulus(N, 1)
exact = moving_sum(x) / 8.0                        # the true average, in floating point
for name, src, flag, model in (("old (>>> 3)", "moving_avg8_old.sv", "--old", golden_old),
                               ("new (requant, round)", "moving_avg8.sv", "", model_new := golden)):
    subprocess.run(["python3", "gen_vectors.py", "--n", str(N)] + ([flag] if flag else []), check=True, capture_output=True)
    top = "moving_avg8_old" if flag else "moving_avg8"
    subprocess.run(["iverilog", "-g2012", "-Wall", f"-DTOP={top}", "-o", "sim", src, "requant.sv", "tb.sv"], check=True)
    r = subprocess.run(["vvp", "-n", "sim", f"+N={N}"], check=True, capture_output=True, text=True)
    y = from_hex("y_actual.hex", W)
    assert np.array_equal(y, model(x)), "RTL differs from the model"
    e = y - exact
    print(f"{name:22s}: {r.stdout.strip().splitlines()[0]}; mean error {e.mean():+.4f} LSB, "
          f"min {e.min():+.3f}, max {e.max():+.3f}, rms {np.sqrt(np.mean(e**2)):.4f}")
