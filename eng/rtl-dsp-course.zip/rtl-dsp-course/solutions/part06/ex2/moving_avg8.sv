`timescale 1ns/1ps
// moving_avg8.sv -- y[n] = round((x[n] + ... + x[n-7]) / 8), rounding half up, saturating.
// Same as Part 2, Exercise 5, with the '>>> 3' replaced by a requant instance.
module moving_avg8 #(
  parameter int W = 16
) (
  input  logic                clk,
  input  logic                rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W-1:0] y
);
  logic signed [W-1:0] d [1:7];                 // x[n-1] .. x[n-7]
  logic signed [W+2:0] sum;                     // W+3 bits: the sum of 8 values cannot overflow

  always_comb begin
    sum = (W+3)'(x);
    for (int k = 1; k <= 7; k++) sum += (W+3)'(d[k]);
  end

  // sum / 8: read the sum as a number with 3 fractional bits and drop them with rounding
  logic signed [W-1:0] avg;
  logic                unused_ovf;
  requant #(.IN_W(W+3), .IN_F(3), .OUT_W(W), .OUT_F(0), .RND(1), .SAT(1'b1))
    u_rq (.din(sum), .dout(avg), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      y <= '0;
      out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        y <= avg;
      end
    end
  end
endmodule
