#!/usr/bin/env python3
"""widths.py -- word-width study for h = firwin(64, 0.1), following Part 6, section 6.6."""
import numpy as np
from scipy.signal import firwin, freqz
from fixedpoint import quantize, requant, to_real

h = firwin(64, 0.1)                       # cutoff 0.1 x Nyquist = 0.05 cycles/sample
F_STOP = 0.075                            # stopband measured from here (transition 0.05 -> 0.075)
rng = np.random.default_rng(0)
x = quantize(rng.uniform(-1, 1, 200_000), 16, 15)       # 16-bit input, Q1.15
y_float = np.convolve(to_real(x, 15), h)[: len(x)]       # ideal: float coefficients, exact arithmetic

def stop_att(hq):
    w, H = freqz(hq, worN=16384)
    f = w / (2 * np.pi)
    return -20 * np.log10(np.max(np.abs(H[f >= F_STOP])))

def out_snr(q, F):
    acc = np.convolve(x.astype(np.int64), q.astype(np.int64))[: len(x)]    # exact accumulation
    y = to_real(requant(acc, 15 + F, 16, 15, "round", "saturate"), 15)     # output Q1.15
    e = y - y_float
    return 10 * np.log10(np.mean(y_float ** 2) / np.mean(e ** 2))

print(f"max|h| = {np.max(np.abs(h)):.4f}, sum|h| = {np.sum(np.abs(h)):.4f}, sum h = {np.sum(h):.4f}")
print(f"floating point: stopband {stop_att(h):.1f} dB")
extra = int(np.floor(-np.log2(np.max(np.abs(h)))))     # free integer bits: |h| < 2**-extra
print(f"|h| < 2^-{extra}: scaling adds {extra} fractional bits")
print(" W | F  (plain) stop  SNR  | F  (scaled) stop  SNR")
for W in range(8, 19):
    row = []
    for F in (W - 1, W - 1 + extra):
        q = quantize(h, W, F)
        assert np.max(np.abs(q)) < 1 << (W - 1)          # still fits in W bits
        row.append(f"{F:2d}  {stop_att(to_real(q, F)):6.1f}  {out_snr(q, F):5.1f}")
    print(f"{W:2d} | " + "  | ".join(row))
