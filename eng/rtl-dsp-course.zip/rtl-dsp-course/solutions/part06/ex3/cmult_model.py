#!/usr/bin/env python3
"""cmult_model.py -- bit-exact model of cmult.sv, vectors, and checks."""
import argparse, sys
import numpy as np
from fixedpoint import requant

def model(a, b, c, d):
    """Integer arithmetic exactly as the hardware: exact products, exact sums, one rounding each."""
    a, b, c, d = (np.asarray(v, np.int64) for v in (a, b, c, d))
    s_re = a * c - b * d                          # Q3.30
    s_im = a * d + b * c
    return (requant(s_re, 30, 16, 15, "round", "saturate"),
            requant(s_im, 30, 16, 15, "round", "saturate"),
            (np.abs(s_re) >= 1 << 30) | (np.abs(s_im) >= 1 << 30))   # rough saturation indicator

def vectors(n, seed):
    rng = np.random.default_rng(seed)
    v = rng.integers(-32768, 32768, size=(n, 4))
    corners = [(-32768, -32768, -32768, -32768),    # (-1 - j)(-1 - j)
               (-32768, 0, -32768, 0),              # (-1)(-1)
               (32767, 32767, 32767, 32767),        # (~1 + ~j)^2
               (32767, 0, 32767, 0),                # (~1)(~1)
               (0, 32767, 0, 32767),                # (~j)(~j) = ~-1
               (-32768, 0, 32767, 0),               # (-1)(~1)
               (0, -32768, 0, -32768),              # (-j)(-j) = -1
               (23170, 23170, 23170, -23170)]       # ((1+j)/sqrt2)((1-j)/sqrt2) = 1
    v[: len(corners)] = corners
    return v

if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("mode"); p.add_argument("--n", type=int, default=5000); p.add_argument("--seed", type=int, default=1)
    args = p.parse_args()
    v = vectors(args.n, args.seed)
    re, im, _ = model(*v.T)
    if args.mode == "make":
        with open("cm_in.txt", "w") as f:
            for row in v: f.write(" ".join(f"{int(x) & 0xFFFF:04x}" for x in row) + "\n")
        sys.exit(0)
    rtl = np.loadtxt("cm_out.txt", dtype=np.int64, ndmin=2)
    ok = rtl.shape == (args.n, 2) and np.array_equal(rtl[:, 0], re) and np.array_equal(rtl[:, 1], im)
    print(f"{'PASS' if ok else 'FAIL'}: {args.n} complex products bit-exact")
    sys.exit(0 if ok else 1)
