`timescale 1ns/1ps
// tb_cmult.sv -- drives cmult from cm_in.txt with random gaps; writes "re im" per result
module tb_cmult;
  logic clk = 1'b0, rst, in_valid, out_valid, ovf;
  logic signed [15:0] a, b, c, d, re, im;
  logic [15:0] ra, rb, rc, rd;
  int fi, fo, code = 4, n_out = 0, n_ovf = 0;
  cmult dut (.*);
  always #5 clk = ~clk;
  initial begin #10_000_000; $fatal(1, "TIMEOUT"); end
  initial begin
    fi = $fopen("cm_in.txt", "r"); fo = $fopen("cm_out.txt", "w");
    rst = 1'b1; in_valid = 1'b0; {a, b, c, d} = '0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    while (code == 4) begin
      if ($urandom_range(0, 3) == 0) begin in_valid = 1'b0; {a, b, c, d} = 'x; end
      else begin
        code = $fscanf(fi, "%h %h %h %h\n", ra, rb, rc, rd);
        in_valid = (code == 4); a = ra; b = rb; c = rc; d = rd;
      end
      @(negedge clk);
    end
    in_valid = 1'b0;
    repeat (8) @(negedge clk);
    $fclose(fo);
    $display("%0d results, %0d saturated", n_out, n_ovf);
    $finish;
  end
  always @(negedge clk) if (!rst && out_valid) begin
    assert (!$isunknown({re, im})) else $error("unknown output");
    $fdisplay(fo, "%0d %0d", re, im);
    n_out++; if (ovf) n_ovf++;
  end
endmodule
