`timescale 1ns/1ps
// cmult.sv -- pipelined complex multiplier: (a + jb)(c + jd) = (ac - bd) + j(ad + bc)
// Q1.15 inputs, Q1.15 outputs (round half up, saturate). Products kept exact until the end.
// Pipeline: input registers -> product registers -> sum registers -> requant + output registers.
module cmult #(
  parameter int W = 16, F = 15
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] a, b, c, d,         // (a + jb) and (c + jd)
  output logic                out_valid,
  output logic signed [W-1:0] re, im,
  output logic                ovf                 // re or im saturated
);
  localparam int P_W = 2 * W;                     // each product: Q2.30
  localparam int S_W = P_W + 1;                   // sum or difference of two products: Q3.30

  logic signed [W-1:0]   a_r, b_r, c_r, d_r;      // stage 1
  logic signed [P_W-1:0] ac, bd, ad, bc;          // stage 2
  logic signed [S_W-1:0] s_re, s_im;              // stage 3
  logic                  v1, v2, v3;

  always_ff @(posedge clk) begin
    if (rst) {v1, v2, v3} <= '0;
    else     {v1, v2, v3} <= {in_valid, v1, v2};
    a_r <= a;  b_r <= b;  c_r <= c;  d_r <= d;
    ac <= a_r * c_r;  bd <= b_r * d_r;  ad <= a_r * d_r;  bc <= b_r * c_r;
    s_re <= S_W'(ac) - S_W'(bd);
    s_im <= S_W'(ad) + S_W'(bc);
  end

  logic signed [W-1:0] re_c, im_c;
  logic                ovf_re, ovf_im;
  requant #(.IN_W(S_W), .IN_F(2*F), .OUT_W(W), .OUT_F(F), .RND(1), .SAT(1'b1))
    u_re (.din(s_re), .dout(re_c), .ovf(ovf_re));
  requant #(.IN_W(S_W), .IN_F(2*F), .OUT_W(W), .OUT_F(F), .RND(1), .SAT(1'b1))
    u_im (.din(s_im), .dout(im_c), .ovf(ovf_im));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= v3;
    if (v3) begin re <= re_c;  im <= im_c;  ovf <= ovf_re | ovf_im; end
  end
endmodule
