`timescale 1ns/1ps
// sat_add.sv -- signed W-bit adder whose result is clamped to the W-bit range
module sat_add #(
  parameter int W = 8
) (
  input  logic signed [W-1:0] a, b,
  output logic signed [W-1:0] y
);
  localparam logic signed [W-1:0] MAX = {1'b0, {(W-1){1'b1}}} - 1'b1;
  localparam logic signed [W-1:0] MIN = {1'b1, {(W-1){1'b0}}};   // -2^(W-1)

  logic signed [W:0] sum;                       // W+1 bits: the exact sum always fits
  assign sum = {a[W-1], a} + {b[W-1], b};       // sign-extend both, then add

  // The exact sum fits in W bits only if its top two bits are equal.
  // If they differ, the sign of the true sum is sum[W]: negative -> MIN, positive -> MAX.
  assign y = (sum[W] == sum[W-1]) ? sum[W-1:0] : (sum[W] ? MIN : MAX);
endmodule
