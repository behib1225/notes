#!/usr/bin/env python3
"""gen_vectors.py -- exhaustive vectors and golden model for sat_add (W = 8).
Writes a.hex, b.hex (all 65,536 pairs) and y_expected.hex."""
import numpy as np

W = 8
LO, HI = -(1 << (W - 1)), (1 << (W - 1)) - 1

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def golden_sat_add(a, b):
    """The golden model: exact sum in int64, clipped to the W-bit range."""
    return np.clip(np.asarray(a, np.int64) + np.asarray(b, np.int64), LO, HI)

def all_pairs():
    v = np.arange(LO, HI + 1, dtype=np.int64)
    a, b = np.meshgrid(v, v, indexing="ij")          # every combination
    return a.ravel(), b.ravel()

if __name__ == "__main__":
    a, b = all_pairs()
    y = golden_sat_add(a, b)
    for name, data in (("a.hex", a), ("b.hex", b), ("y_expected.hex", y)):
        with open(name, "w") as f:
            f.write("\n".join(to_hex(data, W)) + "\n")
    print(f"wrote {len(a)} pairs; saturated results: {int(np.sum(y == HI))} at +{HI}, {int(np.sum(y == LO))} at {LO}")
