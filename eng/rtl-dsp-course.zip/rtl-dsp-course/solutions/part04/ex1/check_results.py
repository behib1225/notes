#!/usr/bin/env python3
"""check_results.py -- independent check of sat_add's output against the golden model."""
import sys
import numpy as np
from gen_vectors import golden_sat_add, all_pairs, W

def from_hex(path, bits):
    vals = []
    for line in open(path):
        line = line.strip()
        if not line:
            continue
        if any(c in line.lower() for c in "xz"):
            raise ValueError(f"{path}: unknown value '{line}'")
        v = int(line, 16)
        vals.append(v - (1 << bits) if v >= 1 << (bits - 1) else v)
    return np.array(vals, dtype=np.int64)

a, b = all_pairs()
y_ref = golden_sat_add(a, b)
y_rtl = from_hex("y_actual.hex", W)
if len(y_rtl) != len(y_ref):
    print(f"FAIL: {len(y_rtl)} outputs, expected {len(y_ref)}"); sys.exit(1)
bad = np.flatnonzero(y_rtl != y_ref)
if bad.size:
    i = bad[0]
    print(f"FAIL: {bad.size} mismatches; first: {a[i]} + {b[i]} -> rtl {y_rtl[i]}, ref {y_ref[i]}")
    sys.exit(1)
print(f"PASS: all {len(y_ref)} input pairs bit-exact (exhaustive)")
