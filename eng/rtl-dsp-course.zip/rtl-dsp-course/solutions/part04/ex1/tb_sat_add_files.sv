`timescale 1ns/1ps
// tb_sat_add_files.sv -- file-driven, combinational: apply each pair, wait 1 ns, write y
module tb_sat_add_files;
  localparam int W = 8, N = 65536;
  logic signed [W-1:0] a, b, y;
  logic [W-1:0] a_mem [0:N-1], b_mem [0:N-1];
  int fd;
  sat_add #(.W(W)) dut (.*);
  initial begin
    $readmemh("a.hex", a_mem);
    $readmemh("b.hex", b_mem);
    fd = $fopen("y_actual.hex", "w");
    for (int i = 0; i < N; i++) begin
      a = a_mem[i];  b = b_mem[i];
      #1;
      assert (!$isunknown(y)) else $fatal(1, "unknown output for pair %0d", i);
      $fdisplay(fd, "%h", y);
    end
    $fclose(fd);
    $display("wrote %0d results", N);
    $finish;
  end
endmodule
