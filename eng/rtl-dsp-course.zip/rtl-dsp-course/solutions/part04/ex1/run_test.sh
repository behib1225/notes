#!/bin/sh
# run_test.sh -- generate, simulate, check.  Usage: ./run_test.sh [design file]
set -e
DESIGN=${1:-sat_add.sv}
python3 gen_vectors.py
iverilog -g2012 -Wall -o sim "$DESIGN" tb_sat_add_files.sv
vvp -n sim
python3 check_results.py
