#!/usr/bin/env python3
import sys
import numpy as np
from gen_vectors import golden, W
def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)
x = from_hex("x.hex", W); y = from_hex("y_actual.hex", W + 3); ref = golden(x)
ok = len(y) == len(ref) and np.all(y == ref)
print(f"PASS: {len(ref)} outputs bit-exact" if ok else "FAIL"); sys.exit(0 if ok else 1)
