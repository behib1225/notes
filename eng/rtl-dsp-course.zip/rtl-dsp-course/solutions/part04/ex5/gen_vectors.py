#!/usr/bin/env python3
"""gen_vectors.py -- vectors and golden model for moving_sum8 (W = 16, output W+3 bits)."""
import argparse
import numpy as np
W = 16
def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]
def golden(x):
    return np.convolve(np.asarray(x, np.int64), np.ones(8, dtype=np.int64))[: len(x)]
def stimulus(n, seed):
    rng = np.random.default_rng(seed)
    lo, hi = -(1 << (W - 1)), (1 << (W - 1)) - 1
    x = rng.integers(lo, hi + 1, size=n)
    x[100:120] = hi; x[200:220] = lo            # full-scale runs: the extreme sums
    return x
if __name__ == "__main__":
    p = argparse.ArgumentParser(); p.add_argument("--n", type=int, default=2000); p.add_argument("--seed", type=int, default=1)
    a = p.parse_args()
    x = stimulus(a.n, a.seed); y = golden(x)
    open("x.hex", "w").write("\n".join(to_hex(x, W)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(y, W + 3)) + "\n")
    print(f"{a.n} samples, seed {a.seed}; y range {y.min()} .. {y.max()}")
