#!/bin/sh
# run_test.sh -- Usage: ./run_test.sh DUT LAT [seed] [n]
set -e
DUT=$1; LAT=$2; SEED=${3:-1}; N=${4:-5000}
python3 gen_vectors.py --seed "$SEED" --n "$N"
iverilog -g2012 -Wall -DDUT="$DUT" -o sim_$DUT moving_sum8.sv tb_moving_sum8_files.sv
vvp -n sim_$DUT +N="$N" +SEED="$SEED" +LAT="$LAT"
python3 check_results.py
