`timescale 1ns/1ps
// moving_sum8.sv -- y[n] = x[n] + x[n-1] + ... + x[n-7], three implementations.

// ---------- 1. one sum of 8 values in a single cycle (latency 1) ----------
module moving_sum8 #(
  parameter int W = 16
) (
  input  logic                clk, rst, in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W+2:0] y              // W+3 bits: 8 values cannot overflow
);
  logic signed [W-1:0] d [1:7];
  logic signed [W+2:0] sum;
  always_comb begin
    sum = (W+3)'(x);
    for (int k = 1; k <= 7; k++) sum += (W+3)'(d[k]);   // a chain of 7 additions as written
  end
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      y <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        y <= sum;
      end
    end
  end
endmodule

// The next two modules share this file on purpose:
/* verilator lint_off DECLFILENAME */
// ---------- 2. balanced adder tree, still one cycle (latency 1) ----------
module moving_sum8_tree #(
  parameter int W = 16
) (
  input  logic                clk, rst, in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W+2:0] y
);
  logic signed [W-1:0] t [0:7];              // t[0] = x[n], t[k] = x[n-k]
  logic signed [W-1:0] d [1:7];
  logic signed [W:0]   l1 [0:3];             // level 1: 4 sums of 2 values, W+1 bits
  logic signed [W+1:0] l2 [0:1];             // level 2: 2 sums,             W+2 bits
  logic signed [W+2:0] l3;                   // level 3: 1 sum,              W+3 bits

  assign t[0] = x;
  for (genvar k = 1; k <= 7; k++) begin : g_t
    assign t[k] = d[k];
  end
  for (genvar i = 0; i < 4; i++) begin : g_l1
    assign l1[i] = (W+1)'(t[2*i]) + (W+1)'(t[2*i+1]);
  end
  for (genvar i = 0; i < 2; i++) begin : g_l2
    assign l2[i] = (W+2)'(l1[2*i]) + (W+2)'(l1[2*i+1]);
  end
  assign l3 = (W+3)'(l2[0]) + (W+3)'(l2[1]);

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      y <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        y <= l3;
      end
    end
  end
endmodule

// ---------- 3. the tree with a register after each level (latency 3) ----------
module moving_sum8_pipe #(
  parameter int W = 16
) (
  input  logic                clk, rst, in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W+2:0] y
);
  logic signed [W-1:0] t [0:7];
  logic signed [W-1:0] d [1:7];
  logic signed [W:0]   l1 [0:3];              // registered after level 1
  logic signed [W+1:0] l2 [0:1];              // registered after level 2
  logic                v1, v2;                // valid bits travelling with the data

  assign t[0] = x;
  for (genvar k = 1; k <= 7; k++) begin : g_t
    assign t[k] = d[k];
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      for (int i = 0; i < 4; i++) l1[i] <= '0;
      l2[0] <= '0;  l2[1] <= '0;  y <= '0;
      {v1, v2, out_valid} <= '0;
    end else begin
      // level 1 (and the delay line), on each input sample
      v1 <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        for (int i = 0; i < 4; i++) l1[i] <= (W+1)'(t[2*i]) + (W+1)'(t[2*i+1]);
      end
      // level 2
      v2 <= v1;
      if (v1) for (int i = 0; i < 2; i++) l2[i] <= (W+2)'(l1[2*i]) + (W+2)'(l1[2*i+1]);
      // level 3
      out_valid <= v2;
      if (v2) y <= (W+3)'(l2[0]) + (W+3)'(l2[1]);
    end
  end
endmodule
