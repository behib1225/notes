| Design | Files | Lint | LUTs | CARRY4 | FFs | DSP | ltp (generic) |
| --- | --- | --- | --- | --- | --- | --- | --- |
| half_adder | half_adder.sv | clean | 2 | 0 | 0 | 0 | 1 |
| full_adder | full_adder.sv | clean | 2 | 0 | 0 | 0 | 3 |
| full_adder_ha | full_adder_ha.sv half_adder.sv | clean | 2 | 0 | 0 | 0 | 3 |
| mux4 | mux4.sv | clean | 16 | 0 | 0 | 0 | 5 |
| rca | rca.sv full_adder.sv | clean | 16 | 0 | 0 | 0 | 24 |
| rca | adder_beh.sv | clean | 8 | 3 | 0 | 0 | 12 |
| dff | dff.sv | clean | 0 | 0 | 1 | 0 | 0 |
| register | register.sv | clean | 0 | 0 | 8 | 0 | 0 |
| mod_counter | mod_counter.sv | clean | 5 | 1 | 4 | 0 | 4 |
| tick_gen | tick_gen.sv mod_counter.sv | clean | 3 | 0 | 2 | 0 | 2 |
| moving_sum4 | moving_sum4.sv | clean | 49 | 5 | 67 | 0 | 19 |
| detect1011_moore | detect1011_moore.sv | clean | 5 | 0 | 5 | 0 | 3 |
| detect1011_mealy | detect1011_mealy.sv | clean | 5 | 0 | 4 | 0 | 3 |
| detect1011_mealy_reg | detect1011_mealy_reg.sv | clean | 5 | 0 | 5 | 0 | 3 |
| seq_mult | seq_mult.sv mult_datapath.sv mult_ctrl.sv | clean | 34 | 4 | 29 | 0 | 11 |
| mult_stream | mult_stream.sv seq_mult.sv mult_datapath.sv mult_ctrl.sv | clean | 34 | 4 | 29 | 0 | 11 |
| decoder2to4 | decoder2to4.sv | clean | 4 | 0 | 0 | 0 | 2 |
| prio_enc4 | prio_enc4.sv | clean | 3 | 0 | 0 | 0 | 2 |
| sat_add | sat_add.sv | clean | 15 | 3 | 0 | 0 | 12 |
| abs_sat | abs_sat.sv | clean | 9 | 2 | 0 | 0 | 7 |
| addsub | addsub.sv full_adder.sv | clean | 19 | 0 | 0 | 0 | 23 |
| edge_detect | edge_detect.sv | clean | 1 | 0 | 3 | 0 | 1 |
| updown_counter | updown_counter.sv | clean | 15 | 2 | 8 | 0 | 11 |
| delay_line | delay_line.sv | clean | 0 | 0 | 128 | 0 | 0 |
| lfsr16 | lfsr16.sv | clean | 1 | 0 | 16 | 0 | 3 |
| moving_avg8 | moving_avg8.sv | clean | 167 | 5 | 129 | 0 | 25 |
| accum | accum.sv | clean | 12 | 3 | 12 | 0 | 12 |
| detect0110_moore | detect0110.sv | clean | 5 | 0 | 5 | 0 | 3 |
| detect0110_mealy | detect0110.sv | clean | 4 | 0 | 3 | 0 | 2 |
| detect0110_mealy_reg | detect0110.sv | clean | 4 | 0 | 4 | 0 | 2 |
| traffic_light | traffic_light.sv tick_gen.sv mod_counter.sv | clean | 17 | 1 | 11 | 0 | 9 |
| uart_tx | uart_tx.sv | clean | 16 | 1 | 15 | 0 | 4 |
| seq_div | seq_div.sv div_datapath.sv div_ctrl.sv | clean | 36 | 4 | 31 | 0 | 11 |
| blink_ctrl | blink_ctrl.sv | clean | 3 | 0 | 3 | 0 | 3 |
