`timescale 1ns/1ps
// adder_beh.sv -- behavioral drop-in replacement for the structural rca of Part 1.
// It deliberately has the same module name as rca.sv, so the file name cannot match:
/* verilator lint_off DECLFILENAME */
module rca #(parameter int N = 8) (
/* verilator lint_on DECLFILENAME */
  input  logic [N-1:0] a, b,
  input  logic         cin,
  output logic [N-1:0] sum,
  output logic         cout
);
  // widen every operand to N+1 bits explicitly (fixes WIDTHEXPAND on the 1-bit cin)
  assign {cout, sum} = {1'b0, a} + {1'b0, b} + (N+1)'(cin);
endmodule
