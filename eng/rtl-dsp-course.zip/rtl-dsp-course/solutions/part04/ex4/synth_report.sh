#!/bin/bash
# synth_report.sh -- lint + synthesis summary for every design of Parts 1 to 3.
# Usage: ./synth_report.sh > report.md      (run from the directory containing src/)
cd src || exit 1
DESIGNS=(
  "half_adder|half_adder.sv"            "full_adder|full_adder.sv"
  "full_adder_ha|full_adder_ha.sv half_adder.sv"  "mux4|mux4.sv"
  "rca|rca.sv full_adder.sv"            "rca|adder_beh.sv"
  "dff|dff.sv"                          "register|register.sv"
  "mod_counter|mod_counter.sv"          "tick_gen|tick_gen.sv mod_counter.sv"
  "moving_sum4|moving_sum4.sv"
  "detect1011_moore|detect1011_moore.sv" "detect1011_mealy|detect1011_mealy.sv"
  "detect1011_mealy_reg|detect1011_mealy_reg.sv"
  "seq_mult|seq_mult.sv mult_datapath.sv mult_ctrl.sv"
  "mult_stream|mult_stream.sv seq_mult.sv mult_datapath.sv mult_ctrl.sv"
  "decoder2to4|decoder2to4.sv"          "prio_enc4|prio_enc4.sv"
  "sat_add|sat_add.sv"                  "abs_sat|abs_sat.sv"
  "addsub|addsub.sv full_adder.sv"
  "edge_detect|edge_detect.sv"          "updown_counter|updown_counter.sv"
  "delay_line|delay_line.sv"            "lfsr16|lfsr16.sv"
  "moving_avg8|moving_avg8.sv"          "accum|accum.sv"
  "detect0110_moore|detect0110.sv"      "detect0110_mealy|detect0110.sv"
  "detect0110_mealy_reg|detect0110.sv"
  "traffic_light|traffic_light.sv tick_gen.sv mod_counter.sv"
  "uart_tx|uart_tx.sv"                  "seq_div|seq_div.sv div_datapath.sv div_ctrl.sv"
  "blink_ctrl|blink_ctrl.sv"
)
echo "| Design | Files | Lint | LUTs | CARRY4 | FFs | DSP | ltp (generic) |"
echo "| --- | --- | --- | --- | --- | --- | --- | --- |"
for d in "${DESIGNS[@]}"; do
  top=${d%%|*}; files=${d#*|}
  nw=$(verilator --lint-only -Wall --top-module "$top" $files 2>&1 | grep -cE "^%(Warning|Error)-")
  lint=$([ "$nw" -eq 0 ] && echo clean || echo "$nw warnings")
  stat=$(yosys -q -p "read_verilog -sv $files; synth_xilinx -family xc7 -flatten -top $top; tee -q -o /dev/stdout stat" 2>&1)
  luts=$(echo "$stat" | awk '/^ +LUT[1-6] /{s+=$2} END{print s+0}')
  carry=$(echo "$stat" | awk '/^ +CARRY4 /{s+=$2} END{print s+0}')
  ffs=$(echo "$stat" | awk '/^ +FD[A-Z]* /{s+=$2} END{print s+0}')
  dsp=$(echo "$stat" | awk '/^ +DSP48E1 /{s+=$2} END{print s+0}')
  ltp=$(yosys -p "read_verilog -sv $files; synth -flatten -top $top; ltp -noff" 2>&1 | sed -n 's/.*(length=\([0-9]*\)).*/\1/p' | tail -1)
  echo "| $top | $files | $lint | $luts | $carry | $ffs | $dsp | ${ltp:-?} |"
done
