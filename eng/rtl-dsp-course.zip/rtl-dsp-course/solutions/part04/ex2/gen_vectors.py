#!/usr/bin/env python3
"""gen_vectors.py -- operand pairs and products for seq_mult / mult_stream (W = 8)."""
import argparse
import numpy as np

W = 8

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def golden(a, b):
    return np.asarray(a, np.int64) * np.asarray(b, np.int64)     # unsigned 8 x 8 -> 16 bits

def vectors(n, seed):
    rng = np.random.default_rng(seed)
    a = rng.integers(0, 1 << W, size=n)
    b = rng.integers(0, 1 << W, size=n)
    corners = [0, 1, (1 << W) - 1]                                 # 0, 1 and 255 in every combination
    ca, cb = np.meshgrid(corners, corners, indexing="ij")
    a[:9], b[:9] = ca.ravel(), cb.ravel()
    return a, b

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=2000)   # at least 9 (the corner pairs)
    p.add_argument("--seed", type=int, default=1)
    args = p.parse_args()
    a, b = vectors(args.n, args.seed)
    open("ab.hex", "w").write("\n".join(f"{x:02x}{y:02x}" for x, y in zip(a, b)) + "\n")
    open("p_expected.hex", "w").write("\n".join(to_hex(golden(a, b), 2 * W)) + "\n")
    print(f"{args.n} pairs, seed {args.seed}")
