#!/usr/bin/env python3
"""check_results.py -- independent check of p_actual.hex against the Python model."""
import sys
import numpy as np
from gen_vectors import golden, vectors

n, seed = int(sys.argv[1]), int(sys.argv[2])
a, b = vectors(n, seed)
ref = golden(a, b)
rtl = np.array([int(l, 16) for l in open("p_actual.hex") if l.strip()], dtype=np.int64)
if len(rtl) != n or np.any(rtl != ref):
    bad = np.flatnonzero(rtl[: min(len(rtl), n)] != ref[: min(len(rtl), n)])
    print(f"FAIL: {len(rtl)} products, {bad.size} wrong" + (f"; first {a[bad[0]]} x {b[bad[0]]}" if bad.size else ""))
    sys.exit(1)
print(f"PASS: {n} products bit-exact")
