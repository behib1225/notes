#!/bin/sh
# regress.sh -- 10 seeds x 2,000 products.  Usage: ./regress.sh [seq|stream]
TB=${1:-seq}
for SEED in $(seq 1 10); do
  if ./run_test.sh "$SEED" 2000 "$TB" > "log_${TB}_$SEED.txt" 2>&1; then echo "seed $SEED: pass"
  else echo "seed $SEED: FAIL (see log_${TB}_$SEED.txt)"; exit 1; fi
done
echo "all 10 seeds passed ($TB)"
