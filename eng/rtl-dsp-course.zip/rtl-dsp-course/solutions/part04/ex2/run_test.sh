#!/bin/sh
# run_test.sh -- one seed.  Usage: ./run_test.sh [seed] [n] [tb: seq|stream]
set -e
SEED=${1:-1}; N=${2:-2000}; TB=${3:-seq}
python3 gen_vectors.py --seed "$SEED" --n "$N"
if [ "$TB" = stream ]; then
  iverilog -g2012 -Wall -o sim mult_stream.sv seq_mult.sv mult_datapath.sv mult_ctrl.sv tb_mult_stream_files.sv
else
  iverilog -g2012 -Wall -o sim seq_mult.sv mult_datapath.sv mult_ctrl.sv tb_seq_mult_files.sv
fi
vvp -n sim +N="$N" +SEED="$SEED"
python3 check_results.py "$N" "$SEED"
