`timescale 1ns/1ps
// tb_mult_stream_files.sv -- the same Python vectors through mult_stream (valid/ready)
module tb_mult_stream_files;
  localparam int W = 8, MAX_N = 100_000;
  logic clk = 1'b0, rst, in_valid, in_ready, out_valid;
  logic [W-1:0]   a, b;
  logic [2*W-1:0] product;
  logic [2*W-1:0] ab_mem [0:MAX_N-1];
  int n = 2000, seed = 1, fd, sent = 0, got = 0;
  mult_stream #(.W(W)) dut (.*);
  always #5 clk = ~clk;
  initial begin #100_000_000; $fatal(1, "TIMEOUT"); end

  // source: offer each pair and HOLD it until it is accepted (valid/ready rule)
  initial begin
    void'($value$plusargs("N=%d", n));
    void'($value$plusargs("SEED=%d", seed));
    void'($urandom(seed));
    $readmemh("ab.hex", ab_mem, 0, n - 1);
    fd = $fopen("p_actual.hex", "w");
    rst = 1'b1; in_valid = 1'b0; a = '0; b = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    while (sent < n) begin
      repeat ($urandom_range(0, 3)) @(negedge clk);
      in_valid = 1'b1; {a, b} = ab_mem[sent];
      do @(posedge clk); while (!in_ready);          // the transfer happens at this edge
      sent++;
      @(negedge clk); in_valid = 1'b0; a = 'x; b = 'x;
    end
  end

  // sink: record every product marked valid, in order
  always @(negedge clk) if (!rst && out_valid) begin
    assert (!$isunknown(product)) else $fatal(1, "unknown product %0d", got);
    $fdisplay(fd, "%h", product);
    if (++got == n) begin
      $fclose(fd);
      $display("wrote %0d products", n);
      $finish;
    end
  end
endmodule
