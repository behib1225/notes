`timescale 1ns/1ps
// tb_seq_mult_files.sv -- file-driven test of seq_mult: start, wait for done, record the product
module tb_seq_mult_files;
  localparam int W = 8, MAX_N = 100_000, LATENCY = 8;
  logic clk = 1'b0, rst, start, busy, done;
  logic [W-1:0]   a, b;
  logic [2*W-1:0] product;
  logic [2*W-1:0] ab_mem [0:MAX_N-1];
  int n = 2000, seed = 1, fd, cycles;
  seq_mult #(.W(W)) dut (.*);
  always #5 clk = ~clk;
  initial begin #100_000_000; $fatal(1, "TIMEOUT"); end
  initial begin
    void'($value$plusargs("N=%d", n));
    void'($value$plusargs("SEED=%d", seed));
    void'($urandom(seed));
    $readmemh("ab.hex", ab_mem, 0, n - 1);
    fd = $fopen("p_actual.hex", "w");
    rst = 1'b1; start = 1'b0; a = '0; b = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    for (int i = 0; i < n; i++) begin
      repeat ($urandom_range(0, 3)) @(negedge clk);          // random idle time between products
      while (busy) @(negedge clk);                           // start is only seen in S_IDLE
      {a, b} = ab_mem[i]; start = 1'b1;
      @(negedge clk); start = 1'b0; a = 'x; b = 'x;          // operands are captured at start
      cycles = 1;
      while (!done) begin @(negedge clk); cycles++; end
      assert (cycles == LATENCY)
        else $fatal(1, "product %0d: done came %0d cycles after start, expected %0d", i, cycles, LATENCY);
      $fdisplay(fd, "%h", product);
    end
    $fclose(fd);
    $display("wrote %0d products; done always %0d cycles after start", n, LATENCY);
    $finish;
  end
endmodule
