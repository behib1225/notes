#!/usr/bin/env python3
"""gen_vectors.py -- test signal and golden model for moving_avg8 (W = 16)."""
import argparse
import numpy as np

W = 16

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def golden(x):
    """Sum of the last 8 samples, then an arithmetic shift right by 3 (floor), like the RTL."""
    x = np.asarray(x, dtype=np.int64)
    return np.convolve(x, np.ones(8, dtype=np.int64))[: len(x)] >> 3

def signal(n, seed):
    """A slow sine wave plus white noise, within +-32,000."""
    rng = np.random.default_rng(seed)
    t = np.arange(n)
    s = 20000 * np.sin(2 * np.pi * t / 500) + rng.normal(0, 4000, n)
    return np.round(np.clip(s, -32000, 32000)).astype(np.int64)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=2000)
    p.add_argument("--seed", type=int, default=1)
    a = p.parse_args()
    x = signal(a.n, a.seed)
    open("x.hex", "w").write("\n".join(to_hex(x, W)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(golden(x), W)) + "\n")
    print(f"{a.n} samples, x in {x.min()} .. {x.max()}")
