#!/usr/bin/env python3
"""check_results.py -- check y_actual.hex against the model, then plot input and RTL output."""
import sys
import numpy as np
from gen_vectors import golden, W

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

x = from_hex("x.hex", W)
y = from_hex("y_actual.hex", W)
ref = golden(x)
if len(y) != len(ref) or np.any(y != ref):
    print("FAIL"); sys.exit(1)
print(f"PASS: {len(y)} outputs bit-exact")
noise_in  = np.std(x - 20000 * np.sin(2 * np.pi * np.arange(len(x)) / 500))
noise_out = np.std(y[8:] - 20000 * np.sin(2 * np.pi * (np.arange(8, len(y)) - 3.5) / 500))
print(f"noise around the sine: input {noise_in:.0f}, output {noise_out:.0f} (ratio {noise_in / noise_out:.2f})")

import matplotlib
matplotlib.use("Agg")                        # write a file; no window needed
import matplotlib.pyplot as plt
fig, ax = plt.subplots(figsize=(9, 4))
ax.plot(x[:600], lw=0.8, alpha=0.6, label="input x (sine + noise)")
ax.plot(y[:600], lw=1.6, label="RTL output y (moving average of 8)")
ax.set_xlabel("sample"); ax.set_ylabel("value"); ax.legend(); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig("moving_avg8.png", dpi=120)
print("saved moving_avg8.png")
