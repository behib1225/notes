#!/bin/sh
set -e
SEED=${1:-1}; N=${2:-2000}
python3 gen_vectors.py --seed "$SEED" --n "$N"
iverilog -g2012 -Wall -o sim moving_avg8.sv tb_moving_avg8_files.sv
vvp -n sim +N="$N" +SEED="$SEED"
python3 check_results.py
