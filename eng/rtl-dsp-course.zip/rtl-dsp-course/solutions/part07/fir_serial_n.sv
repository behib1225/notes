`timescale 1ns/1ps
// fir_serial_n.sv -- fir_serial (Part 7) without the idle cycle: the next sample is accepted
// during the last MAC cycle of the current one, so the throughput is one sample per N clocks.
module fir_serial_n #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int KW = $clog2(N);

  typedef enum logic {S_IDLE, S_RUN} state_t;
  state_t               state;
  logic [KW-1:0]        k;
  logic signed [XW-1:0] taps [0:N-1];
  logic                 last_k, accept;

  assign last_k   = (k == KW'(N - 1));
  // ready when idle, or in the cycle that feeds the last tap (the taps are no longer needed after it)
  assign in_ready = (state == S_IDLE) || (state == S_RUN && last_k);
  assign accept   = in_valid && in_ready;

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;  k <= '0;
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else begin
      if (accept) begin                          // shift in the new sample, start from tap 0
        taps[0] <= x;
        for (int i = 1; i < N; i++) taps[i] <= taps[i-1];
        k <= '0;  state <= S_RUN;
      end else if (state == S_RUN) begin
        k <= k + 1'b1;
        if (last_k) state <= S_IDLE;           // no new sample was waiting
      end
    end
  end

  logic mac_ovf_unused;
  mac #(.A_W(XW), .A_F(XF), .B_W(CW), .B_F(CF), .ACC_W(XW + CW + KW + 1),
        .OUT_W(YW), .OUT_F(YF)) u_mac (
    .clk(clk), .rst(rst),
    .in_valid(state == S_RUN), .first(k == '0), .last(last_k),
    .a(taps[k]), .b(fir_coef(32'(k))),
    .out_valid(out_valid), .dout(y), .dout_ovf(mac_ovf_unused)
  );
endmodule
