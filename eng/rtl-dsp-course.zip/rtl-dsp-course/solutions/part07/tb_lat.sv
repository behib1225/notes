`timescale 1ns/1ps
module tb_lat;
  logic clk = 1'b0, rst, in_valid, in_ready, out_valid; logic signed [15:0] x, y; int t0, n = 0;
  `DUT dut (.*);
  always #5 clk = ~clk;
  initial begin
    rst = 1; in_valid = 0; x = 0; repeat (3) @(negedge clk); rst = 0;
    @(negedge clk); in_valid = 1; x = 16384; t0 = $time; @(negedge clk); in_valid = 0;
    while (!out_valid) begin @(negedge clk); n++; end
    $display("out_valid %0d cycles after in_valid", n + 1); $finish;
  end
endmodule
