`timescale 1ns/1ps
// mac_acc.sv -- the Part 6 MAC without its output stage: it delivers the EXACT accumulator
// (no rounding) when the last product of a group has been added. Same pipeline as mac.sv.
module mac_acc #(
  parameter int A_W = 16, B_W = 18, ACC_W = 40
) (
  input  logic                    clk, rst,
  input  logic                    in_valid, first, last,
  input  logic signed [A_W-1:0]   a,
  input  logic signed [B_W-1:0]   b,
  output logic                    acc_valid,  // one-cycle pulse: acc holds a finished sum
  output logic signed [ACC_W-1:0] acc
);
  logic signed [A_W-1:0]     a_r;
  logic signed [B_W-1:0]     b_r;
  logic signed [A_W+B_W-1:0] m_r;
  logic v1, v2, first1, first2, last1, last2;

  always_ff @(posedge clk) begin
    if (rst) begin v1 <= 1'b0; v2 <= 1'b0; acc_valid <= 1'b0; end
    else begin v1 <= in_valid; v2 <= v1; acc_valid <= v2 && last2; end
    a_r <= a;  b_r <= b;  first1 <= first;  last1 <= last;
    m_r <= a_r * b_r;     first2 <= first1; last2 <= last1;
    if (v2) acc <= (first2 ? ACC_W'(0) : acc) + ACC_W'(m_r);
  end
endmodule
