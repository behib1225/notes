// fir_coefs.svh -- generated; do not edit by hand
// firwin(32, 0.2) quantized to Q1.17 (18 bits)
function automatic logic signed [17:0] fir_coef(input int k);
  case (k)
     0: fir_coef = -18'sd66;
     1: fir_coef = 18'sd79;
     2: fir_coef = 18'sd293;
     3: fir_coef = 18'sd542;
     4: fir_coef = 18'sd654;
     5: fir_coef = 18'sd364;
     6: fir_coef = -18'sd515;
     7: fir_coef = -18'sd1866;
     8: fir_coef = -18'sd3130;
     9: fir_coef = -18'sd3399;
    10: fir_coef = -18'sd1739;
    11: fir_coef = 18'sd2351;
    12: fir_coef = 18'sd8564;
    13: fir_coef = 18'sd15706;
    14: fir_coef = 18'sd22003;
    15: fir_coef = 18'sd25695;
    16: fir_coef = 18'sd25695;
    17: fir_coef = 18'sd22003;
    18: fir_coef = 18'sd15706;
    19: fir_coef = 18'sd8564;
    20: fir_coef = 18'sd2351;
    21: fir_coef = -18'sd1739;
    22: fir_coef = -18'sd3399;
    23: fir_coef = -18'sd3130;
    24: fir_coef = -18'sd1866;
    25: fir_coef = -18'sd515;
    26: fir_coef = 18'sd364;
    27: fir_coef = 18'sd654;
    28: fir_coef = 18'sd542;
    29: fir_coef = 18'sd293;
    30: fir_coef = 18'sd79;
    31: fir_coef = -18'sd66;
    default: fir_coef = '0;
  endcase
endfunction
