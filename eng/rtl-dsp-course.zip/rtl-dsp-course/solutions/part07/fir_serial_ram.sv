`timescale 1ns/1ps
// fir_serial_ram.sv -- fir_serial_n with the shifting delay line replaced by a circular buffer:
// each new sample is written once, at wp; tap k is read from address (wp - k) mod N.
// The memory has no reset: after rst, S_INIT writes N zeros (the model starts at rest).
module fir_serial_ram #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,   // N: a power of two
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int KW = $clog2(N);

  typedef enum logic [1:0] {S_INIT, S_IDLE, S_RUN} state_t;
  state_t               state;
  logic [KW-1:0]        k, wp, ra;                 // tap index, write pointer, read address
  logic signed [XW-1:0] mem [0:N-1];               // no reset: may become LUT RAM
  logic signed [XW-1:0] tap;
  logic                 last_k, accept;

  assign last_k   = (k == KW'(N - 1));
  assign in_ready = (state == S_IDLE) || (state == S_RUN && last_k);
  assign accept   = in_valid && in_ready;
  assign ra       = wp - k;                        // wraps modulo N because N = 2**KW
  assign tap      = mem[ra];

  // the memory: one write port
  always_ff @(posedge clk) begin
    if (state == S_INIT)  mem[k]  <= '0;           // clear one location per cycle
    else if (accept)      mem[wp + 1'b1] <= x;     // the new newest sample
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_INIT;  k <= '0;  wp <= '0;
    end else begin
      case (state)
        S_INIT: begin
          k <= k + 1'b1;
          if (last_k) begin state <= S_IDLE; k <= '0; end
        end
        default: begin
          if (accept) begin
            wp <= wp + 1'b1;  k <= '0;  state <= S_RUN;
          end else if (state == S_RUN) begin
            k <= k + 1'b1;
            if (last_k) state <= S_IDLE;
          end
        end
      endcase
    end
  end

  logic mac_ovf_unused;
  mac #(.A_W(XW), .A_F(XF), .B_W(CW), .B_F(CF), .ACC_W(XW + CW + KW + 1),
        .OUT_W(YW), .OUT_F(YF)) u_mac (
    .clk(clk), .rst(rst),
    .in_valid(state == S_RUN), .first(k == '0), .last(last_k),
    .a(tap), .b(fir_coef(32'(k))),
    .out_valid(out_valid), .dout(y), .dout_ovf(mac_ovf_unused)
  );
endmodule
