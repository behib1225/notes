`timescale 1ns/1ps
// fir_direct_pipe.sv -- direct-form FIR with a pipelined, balanced adder tree:
// N products -> N/2 sums -> register -> N/4 sums -> register -> ... -> 1 sum.
// N must be a power of two. Each level is one bit wider than the one before.
// Latency: 1 (delay line) + 1 (products) + log2(N) (tree levels) + 1 (output) cycles.
module fir_direct_pipe #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int LV = $clog2(N);                      // number of tree levels
  localparam int PW = XW + CW;                         // product width (34)
  assign in_ready = 1'b1;

  logic signed [XW-1:0] taps [0:N-1];
  logic signed [PW-1:0] prod [0:N-1];
  logic                 v [0:LV+1];                    // v[0]: products valid; v[l+1]: level l valid

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < N; k++) taps[k] <= '0;
    end else if (in_valid) begin
      taps[0] <= x;
      for (int k = 1; k < N; k++) taps[k] <= taps[k-1];
    end
    for (int k = 0; k < N; k++) prod[k] <= taps[k] * fir_coef(k);
  end

  // valid bits travel alongside the data: in_valid -> taps (1) -> products (v[0]) -> levels
  logic v_taps;
  always_ff @(posedge clk) begin
    if (rst) begin
      v_taps <= 1'b0;
      for (int l = 0; l <= LV + 1; l++) v[l] <= 1'b0;
    end else begin
      v_taps <= in_valid;
      v[0]   <= v_taps;
      for (int l = 0; l <= LV; l++) v[l+1] <= v[l];
    end
  end

  // the tree: level l has N >> (l+1) registers of width PW + l + 1
  for (genvar l = 0; l < LV; l++) begin : g_lvl
    localparam int M = N >> (l + 1);                   // sums at this level
    localparam int SW = PW + l + 1;                    // their width
    logic signed [SW-1:0] s [0:M-1];
    for (genvar i = 0; i < M; i++) begin : g_add
      if (l == 0) begin : g_first
        always_ff @(posedge clk) s[i] <= SW'(prod[2*i]) + SW'(prod[2*i+1]);
      end else begin : g_next
        always_ff @(posedge clk) s[i] <= SW'(g_lvl[l-1].s[2*i]) + SW'(g_lvl[l-1].s[2*i+1]);
      end
    end
  end

  localparam int ACC_W = PW + LV;                      // 39: the final sum
  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(g_lvl[LV-1].s[0]), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= v[LV];
    if (v[LV]) y <= y_c;
  end
endmodule
