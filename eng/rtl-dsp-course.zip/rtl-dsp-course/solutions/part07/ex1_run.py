#!/usr/bin/env python3
"""ex1_run.py -- the 67-tap Parks-McClellan design, 16-bit coefficients (F = 17), on fir_symmetric.sv."""
import subprocess, sys
import numpy as np
from fixedpoint import quantize
from firlib import write_coef_file, golden, to_hex, from_hex, stimulus

N, CW, CF = 67, 16, 17
h = np.load("h_remez67.npy")
hq = quantize(h, CW, CF)
assert np.array_equal(hq, hq[::-1]), "quantized coefficients must stay symmetric"
write_coef_file(hq, CW, f"remez(67), 48 kHz: pass 4 kHz, stop 6 kHz; Q-1.17 in {CW} bits (F = {CF})")
fails = 0
for seed in (1, 2, 3):
    x = stimulus(4000, seed, hq)
    y = golden(x, hq, CF)
    open("x.hex", "w").write("\n".join(to_hex(x, 16)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(y, 16)) + "\n")
    subprocess.run(["iverilog", "-g2012", "-Wall", "-DDUT=fir_symmetric", "-o", "sim",
                    f"-DDUT_PARAMS=.N({N}),.CW({CW}),.CF({CF})", "fir_symmetric.sv", "requant.sv", "tb_fir.sv"], check=True)
    r = subprocess.run(["vvp", "-n", "sim", "+N=4000", f"+SEED={seed}"], capture_output=True, text=True)
    ok = np.array_equal(from_hex("y_actual.hex", 16), y)
    print(f"seed {seed}: {r.stdout.strip().splitlines()[0]}; independent check {'PASS' if ok else 'FAIL'}; "
          f"{int(np.sum(np.abs(y) >= 32767))} saturated")
    fails += not ok
sys.exit(fails)
