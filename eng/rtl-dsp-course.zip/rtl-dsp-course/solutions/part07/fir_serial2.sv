`timescale 1ns/1ps
// fir_serial2.sv -- serial FIR with TWO MACs: one handles taps 0..N/2-1, the other N/2..N-1.
// Their exact sums are added BEFORE the single rounding, so the result is bit-exact.
// Throughput: one sample per N/2 clocks (the next sample is accepted in the last MAC cycle).
module fir_serial2 #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,   // N even
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int H     = N / 2;
  localparam int KW    = (H > 1) ? $clog2(H) : 1;
  localparam int ACC_W = XW + CW + $clog2(N);           // each half's exact sum fits
  localparam int SUM_W = ACC_W + 1;                     // the sum of the two halves

  typedef enum logic {S_IDLE, S_RUN} state_t;
  state_t               state;
  logic [KW-1:0]        k;
  logic signed [XW-1:0] taps [0:N-1];
  logic                 last_k, accept;
  logic [$clog2(N)-1:0] ia, ib;                         // the two taps read this cycle

  assign ia = ($clog2(N))'(k);                          // tap k        (first half)
  assign ib = ($clog2(N))'(k) + ($clog2(N))'(H);        // tap k + N/2  (second half)

  assign last_k   = (k == KW'(H - 1));
  assign in_ready = (state == S_IDLE) || (state == S_RUN && last_k);
  assign accept   = in_valid && in_ready;

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;  k <= '0;
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else if (accept) begin
      taps[0] <= x;
      for (int i = 1; i < N; i++) taps[i] <= taps[i-1];
      k <= '0;  state <= S_RUN;
    end else if (state == S_RUN) begin
      k <= k + 1'b1;
      if (last_k) state <= S_IDLE;
    end
  end

  // two MACs in lockstep
  logic                    va, vb_unused;
  logic signed [ACC_W-1:0] acc_a, acc_b;
  mac_acc #(.A_W(XW), .B_W(CW), .ACC_W(ACC_W)) u_a (
    .clk(clk), .rst(rst), .in_valid(state == S_RUN), .first(k == '0), .last(last_k),
    .a(taps[ia]), .b(fir_coef(32'(ia))), .acc_valid(va), .acc(acc_a));
  mac_acc #(.A_W(XW), .B_W(CW), .ACC_W(ACC_W)) u_b (
    .clk(clk), .rst(rst), .in_valid(state == S_RUN), .first(k == '0), .last(last_k),
    .a(taps[ib]), .b(fir_coef(32'(ib))), .acc_valid(vb_unused), .acc(acc_b));

  // add the exact halves, round once
  logic signed [SUM_W-1:0] total;
  logic signed [YW-1:0]    y_c;
  logic                    unused_ovf;
  assign total = SUM_W'(acc_a) + SUM_W'(acc_b);
  requant #(.IN_W(SUM_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(total), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= va;
    if (va) y <= y_c;
  end
endmodule
