#!/usr/bin/env python3
"""firlib.py -- generalized FIR golden model and coefficient-file writer (any N, any coefficient format).
Samples are Q1.15 (16 bits); output is Q1.15, rounded once and saturated."""
import numpy as np
from fixedpoint import quantize, requant

XW, XF, YW, YF = 16, 15, 16, 15

def write_coef_file(hq, CW, comment, path="fir_coefs.svh"):
    with open(path, "w") as f:
        f.write(f"// fir_coefs.svh -- generated; do not edit by hand\n// {comment}\n")
        f.write(f"function automatic logic signed [{CW-1}:0] fir_coef(input int k);\n  case (k)\n")
        for k, v in enumerate(hq):
            lit = f"{CW}'sd{v}" if v >= 0 else f"-{CW}'sd{-v}"
            f.write(f"    {k:2d}: fir_coef = {lit};\n")
        f.write("    default: fir_coef = '0;\n  endcase\nendfunction\n")

def golden(xq, hq, CF):
    acc = np.convolve(np.asarray(xq, np.int64), np.asarray(hq, np.int64))[: len(xq)]
    return requant(acc, XF + CF, YW, YF, "round", "saturate")

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

def stimulus(n, seed, hq):
    rng = np.random.default_rng(seed)
    x = quantize(rng.uniform(-0.9, 0.9, n), XW, XF)
    x[:60] = 0; x[8] = 16384                                   # impulse of 0.5
    worst = np.where(hq[::-1] >= 0, 32767, -32768)             # largest possible output
    x[300:300 + 3 * len(hq)] = np.tile(worst, 3)
    return x

def amplitude(y, f):
    n = np.arange(len(y)); return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))
