#!/usr/bin/env python3
"""measure_rtl.py -- measure the moving_avg8 RTL: gain at 20 frequencies, and its impulse response."""
import subprocess
import numpy as np

W, N, A = 16, 2000, 16000                 # input width, samples, input amplitude

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

def amplitude(y, f):
    n = np.arange(len(y))
    return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))

def golden(x):                            # bit-exact model of the RTL (Part 4, Exercise 3)
    return np.convolve(np.asarray(x, np.int64), np.ones(8, dtype=np.int64))[: len(x)] >> 3

def run_rtl(x):
    open("x.hex", "w").write("\n".join(to_hex(x, W)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(golden(x), W)) + "\n")
    subprocess.run(["vvp", "-n", "sim", f"+N={len(x)}"], check=True, capture_output=True)
    return from_hex("y_actual.hex", W)

def theory(f, M=8):
    return 1.0 if f == 0 else abs(np.sin(M * np.pi * f) / (M * np.sin(np.pi * f)))

subprocess.run(["iverilog", "-g2012", "-o", "sim", "moving_avg8.sv", "tb_moving_avg8_files.sv"], check=True)

# ---- impulse response
x = np.zeros(40, dtype=np.int64); x[5] = 8000
print("impulse response (outputs 4..16):", run_rtl(x)[4:17].tolist())

# ---- frequency response
print(" f/fs    RTL gain   theory    RTL - theory")
rows = []
for f in np.linspace(0, 0.45, 20):
    n = np.arange(N)
    x = np.round(A * np.cos(2 * np.pi * f * n)).astype(np.int64)
    y = run_rtl(x)[100:]; xs = x[100:]
    gain = np.mean(y) / np.mean(xs) if f == 0 else amplitude(y, f) / amplitude(xs, f)
    print(f"{f:6.4f}   {gain:.5f}   {theory(f):.5f}   {gain - theory(f):+.6f}")
    rows.append((f, gain, theory(f)))
np.save("gains.npy", np.array(rows))
