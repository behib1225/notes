#!/usr/bin/env python3
"""ex1_alias.py -- find the apparent frequency of each tone by scanning with amplitude()."""
import numpy as np

FS, N = 10_000, 1000

def amplitude(y, f):
    """Amplitude of the component of y at f cycles/sample (Part 5, section 5.5)."""
    n = np.arange(len(y))
    return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))

def fold(f, fs):
    """Folding rule (section 5.2): reduce modulo fs, then reflect anything above fs/2."""
    r = f % fs
    return (fs - r, True) if r > fs / 2 else (r, False)

n = np.arange(N)
scan = np.arange(0, 5001, 10)                          # apparent frequencies 0 .. 5 kHz, 10 Hz steps
print(" f (kHz) | peak found (Hz) | folding rule (Hz) | reflected? | sign of sine alias")
for f in [1000, 4000, 6000, 9000, 11000, 14000, 19000]:
    y = np.cos(2 * np.pi * f * n / FS)
    amps = [amplitude(y, fa / FS) for fa in scan]
    peak = scan[int(np.argmax(amps))]
    pred, refl = fold(f, FS)
    s = np.sin(2 * np.pi * f * n / FS)                 # the same tone as a sine
    c = 2 * np.mean(s * np.sin(2 * np.pi * pred * n / FS))   # projection onto +sin at the alias
    print(f"  {f/1000:5.0f}  |  {peak:13.0f}  |  {pred:15.0f}  |  {str(refl):9s} | {'+' if c > 0 else '-'} ({c:+.3f})")
