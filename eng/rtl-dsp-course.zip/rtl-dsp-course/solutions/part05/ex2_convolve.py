#!/usr/bin/env python3
"""ex2_convolve.py -- convolution with two nested loops, and a streaming version."""
import numpy as np

def my_convolve(x, h):
    """Full convolution: N + M - 1 outputs, y[n] = sum_k h[k] x[n-k]."""
    N, M = len(x), len(h)
    y = [0] * (N + M - 1)
    for n in range(N + M - 1):
        for k in range(M):
            if 0 <= n - k < N:                 # x is zero outside 0 .. N-1
                y[n] += h[k] * x[n - k]
    return np.array(y, dtype=np.int64)

def my_convolve_streaming(x, h):
    """First N outputs only, as the hardware produces them: one output per input sample,
    computed from a delay line that shifts by one place per sample, like the RTL's registers."""
    M = len(h)
    taps = [0] * M                             # taps[k] holds x[n-k]; all zero at reset
    out = []
    for sample in x:
        taps = [sample] + taps[:-1]            # shift in the new sample, drop the oldest
        out.append(sum(hk * tk for hk, tk in zip(h, taps)))   # the multiply-accumulate
    return np.array(out, dtype=np.int64)

rng = np.random.default_rng(1)
ok_full = ok_stream = True
for trial in range(100):
    x = rng.integers(-1000, 1001, size=rng.integers(1, 60))
    h = rng.integers(-50, 51, size=rng.integers(1, 20))
    ref = np.convolve(x, h)
    ok_full   &= np.array_equal(my_convolve(x, h), ref)
    ok_stream &= np.array_equal(my_convolve_streaming(x, h), ref[: len(x)])
print("my_convolve:           ", "PASS" if ok_full else "FAIL", "(100 random pairs)")
print("my_convolve_streaming: ", "PASS" if ok_stream else "FAIL", "(100 random pairs)")
print("by-hand example:", my_convolve([1, 3, 2, 0, -1], [1, 2, 1]), my_convolve_streaming([1, 3, 2, 0, -1], [1, 2, 1]))
