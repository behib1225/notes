`timescale 1ns/1ps
// iir_serial.sv -- the IIR cascade with ONE multiplier: for each sample, each section's five
// products are accumulated one per clock, rounded once, and fed to the next section.
// Bit-exact with iir_cascade.sv. Cycles per sample: 1 (accept) + NSEC * 6.
module iir_serial #(
  parameter int NSEC = 4,
  parameter int XW = 16, XF = 15, SW = 24, SF = 20, CW = 18, CF = 16
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  `include "iir_coefs.svh"
  localparam int ACC_W = SW + CW + 3;            // 45: as in iir_biquad
  localparam int SB    = (NSEC > 1) ? $clog2(NSEC) : 1;

  typedef enum logic [1:0] {S_IDLE, S_MAC, S_UPD} state_t;
  state_t state;
  logic [SB-1:0] s;                              // current section
  logic [2:0]    c;                              // current product: 0..4 = b0 b1 b2 a1 a2

  // per-section state (direct form I), and the current section's input
  logic signed [SW-1:0] x1 [0:NSEC-1], x2 [0:NSEC-1], y1 [0:NSEC-1], y2 [0:NSEC-1];
  logic signed [SW-1:0] xin;

  // ---- the datapath: one multiplier and an accumulator ----
  logic signed [SW-1:0]    operand;
  logic signed [CW-1:0]    coef;
  logic signed [ACC_W-1:0] acc, prod;
  always_comb begin
    case (c)
      3'd0:    operand = xin;
      3'd1:    operand = x1[s];
      3'd2:    operand = x2[s];
      3'd3:    operand = y1[s];
      default: operand = y2[s];
    endcase
    coef = iir_coef(32'(s), 32'(c));
    prod = ACC_W'(operand * coef);
  end

  logic signed [SW-1:0] ysec;                    // the section output: one rounding
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(SF + CF), .OUT_W(SW), .OUT_F(SF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(ysec), .ovf(unused_ovf));

  logic signed [XW-1:0] y_c;
  logic                 unused_ovf2;
  requant #(.IN_W(SW), .IN_F(SF), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1))
    u_out (.din(ysec), .dout(y_c), .ovf(unused_ovf2));

  assign in_ready = (state == S_IDLE);

  // ---- the controller ----
  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;  s <= '0;  c <= '0;  out_valid <= 1'b0;
      for (int i = 0; i < NSEC; i++) begin x1[i] <= '0; x2[i] <= '0; y1[i] <= '0; y2[i] <= '0; end
    end else begin
      out_valid <= 1'b0;
      case (state)
        S_IDLE: if (in_valid) begin
          xin   <= {{(SW - XW - (SF - XF)){x[XW-1]}}, x, {(SF - XF){1'b0}}};   // Q1.15 -> Q4.20
          s     <= '0;  c <= '0;  state <= S_MAC;
        end
        S_MAC: begin                             // acc = b0 x + b1 x1 + b2 x2 - a1 y1 - a2 y2
          if (c == 3'd0)      acc <= prod;
          else if (c < 3'd3)  acc <= acc + prod;
          else                acc <= acc - prod;
          if (c == 3'd4) state <= S_UPD;
          else           c <= c + 1'b1;
        end
        S_UPD: begin                             // round once, update this section, move on
          x2[s] <= x1[s];  x1[s] <= xin;
          y2[s] <= y1[s];  y1[s] <= ysec;
          xin   <= ysec;                         // the next section's input
          c     <= '0;
          if (s == SB'(NSEC - 1)) begin
            y <= y_c;  out_valid <= 1'b1;  state <= S_IDLE;
          end else begin
            s <= s + 1'b1;  state <= S_MAC;
          end
        end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule
