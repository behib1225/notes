#!/usr/bin/env python3
"""iirlib.py -- generalized bit-exact model of iir_cascade.sv (any sections, signal format, overflow mode)."""
import subprocess
import numpy as np
from scipy import signal
from fixedpoint import quantize, requant

XW, XF, CW, CF = 16, 15, 18, 16

def scale(sos):
    """L-infinity scaling (Part 8, section 8.3)."""
    sos = sos.copy()
    for k in range(len(sos)):
        _, h = signal.sosfreqz(sos[: k + 1], worN=8192)
        sos[k, :3] /= np.max(np.abs(h))
    return sos

def coefs(sos):
    """Integer coefficients b0 b1 b2 a1 a2 per section, Q2.16."""
    c = np.column_stack([sos[:, 0], sos[:, 1], sos[:, 2], sos[:, 4], sos[:, 5]])
    assert np.max(np.abs(c)) < 2.0, f"coefficient {np.max(np.abs(c)):.4f} outside Q2.16"
    return quantize(c, CW, CF)

def golden(xq, cq, SW=24, SF=20, ovf="saturate"):
    """Sample-by-sample integer model: exact sum, one rounding per section, then Q1.15 out."""
    v = np.asarray(xq, dtype=np.int64) << (SF - XF)
    for b0, b1, b2, a1, a2 in [tuple(int(t) for t in r) for r in cq]:
        x1 = x2 = y1 = y2 = 0
        out = np.empty_like(v)
        for n, x0 in enumerate(v.tolist()):
            acc = b0 * x0 + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            y0 = int(requant(np.array([acc]), SF + CF, SW, SF, "round", ovf)[0])
            out[n] = y0
            x2, x1, y2, y1 = x1, x0, y1, y0
        v = out
    return requant(v, SF, XW, XF, "round", "saturate")

def write_coef_file(cq, path="iir_coefs.svh"):
    with open(path, "w") as f:
        f.write(f"// iir_coefs.svh -- generated; do not edit by hand. Q2.{CF}: b0 b1 b2 a1 a2 per section\n")
        f.write(f"function automatic logic signed [{CW-1}:0] iir_coef(input int s, input int c);\n  case (s * 5 + c)\n")
        for s, row in enumerate(cq):
            for c, v in enumerate(row):
                f.write(f"    {s*5+c:2d}: iir_coef = {CW}'sd{v};\n" if v >= 0 else f"    {s*5+c:2d}: iir_coef = -{CW}'sd{-v};\n")
        f.write("    default: iir_coef = '0;\n  endcase\nendfunction\n")

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

def run_rtl(x, cq, nsec, SW=24, SF=20, sat=1, sim="sim"):
    """Compile (once per configuration) and run iir_cascade on x; returns (rtl_output, pass_message)."""
    y = golden(x, cq, SW, SF, "saturate" if sat else "wrap")
    open("x.hex", "w").write("\n".join(to_hex(x, 16)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(y, 16)) + "\n")
    subprocess.run(["iverilog", "-g2012", "-Wall", "-DDUT=iir_cascade",
                    f"-DDUT_PARAMS=.NSEC({nsec}),.SW({SW}),.SF({SF}),.SAT({sat})", "-o", sim,
                    "iir_cascade.sv", "iir_biquad.sv", "requant.sv", "tb_fir.sv"], check=True)
    r = subprocess.run(["vvp", "-n", sim, f"+N={len(x)}"], capture_output=True, text=True)
    out = from_hex("y_actual.hex", 16)
    return out, y, (r.stdout.strip().splitlines() or ["(no output)"])[0]
