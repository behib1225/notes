// iir_coefs.svh -- generated; do not edit by hand. Q2.16: b0 b1 b2 a1 a2 per section
function automatic logic signed [17:0] iir_coef(input int s, input int c);
  case (s * 5 + c)
     0: iir_coef = 18'sd7185;
     1: iir_coef = 18'sd7185;
     2: iir_coef = 18'sd0;
     3: iir_coef = -18'sd51166;
     4: iir_coef = 18'sd0;
     5: iir_coef = 18'sd5585;
     6: iir_coef = -18'sd4440;
     7: iir_coef = 18'sd5585;
     8: iir_coef = -18'sd104119;
     9: iir_coef = 18'sd45314;
    10: iir_coef = 18'sd23546;
    11: iir_coef = -18'sd34183;
    12: iir_coef = 18'sd23546;
    13: iir_coef = -18'sd107608;
    14: iir_coef = 18'sd54981;
    15: iir_coef = 18'sd40063;
    16: iir_coef = -18'sd63401;
    17: iir_coef = 18'sd40063;
    18: iir_coef = -18'sd111282;
    19: iir_coef = 18'sd62471;
    default: iir_coef = '0;
  endcase
endfunction
