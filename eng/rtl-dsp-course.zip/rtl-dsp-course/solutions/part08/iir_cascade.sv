`timescale 1ns/1ps
// iir_cascade.sv -- the 7th-order elliptic low-pass: four biquads in series.
// Q1.15 in -> Q4.20 inside -> Q1.15 out (rounded, saturated). One sample per clock.
module iir_cascade #(
  parameter int NSEC = 4,
  parameter int XW = 16, XF = 15, SW = 24, SF = 20,
  parameter bit SAT = 1'b1                        // inside the sections: saturate (1) or wrap (0)
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  assign in_ready = 1'b1;

  logic signed [SW-1:0] s [0:NSEC];               // signals between sections
  logic                 v [0:NSEC];

  // Q1.15 -> Q4.20: sign-extend and append (SF - XF) zero fraction bits
  assign s[0] = {{(SW - XW - (SF - XF)){x[XW-1]}}, x, {(SF - XF){1'b0}}};
  assign v[0] = in_valid;

  for (genvar k = 0; k < NSEC; k++) begin : g_sec
    iir_biquad #(.SEC(k), .SW(SW), .SF(SF), .SAT(SAT)) u_bq (
      .clk(clk), .rst(rst), .in_valid(v[k]), .x(s[k]), .out_valid(v[k+1]), .y(s[k+1])
    );
  end

  logic signed [XW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(SW), .IN_F(SF), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1))
    u_out (.din(s[NSEC]), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= v[NSEC];
    if (v[NSEC]) y <= y_c;
  end
endmodule
