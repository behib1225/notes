`timescale 1ns/1ps
// tb_decim16.sv -- inputs at a FIXED spacing (+GAP=g clocks per sample); expects n/16 outputs
module tb_decim16;
  logic clk = 1'b0, rst, in_valid, in_ready, out_valid;
  logic signed [15:0] x, y;
  logic [15:0] x_mem [0:99999], exp_mem [0:9999];
  int n = 8000, gap = 4, sent = 0, got = 0, errors = 0, fd;
  decim16 dut (.*);
  always #5 clk = ~clk;
  initial begin #50_000_000; $fatal(1, "TIMEOUT"); end
  initial begin
    void'($value$plusargs("N=%d", n)); void'($value$plusargs("GAP=%d", gap));
    $readmemh("x.hex", x_mem, 0, n - 1); $readmemh("y_expected.hex", exp_mem, 0, n / 16 - 1);
    fd = $fopen("y_actual.hex", "w");
    rst = 1'b1; in_valid = 1'b0; x = '0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    while (sent < n) begin
      in_valid = 1'b1; x = x_mem[sent]; sent++;
      @(negedge clk); in_valid = 1'b0; x = 'x;
      repeat (gap - 1) @(negedge clk);
    end
    repeat (100) @(negedge clk);
    $fclose(fd);
    if (got == n / 16 && errors == 0) $display("GAP %0d: PASS: %0d outputs bit-exact", gap, got);
    else $display("GAP %0d: FAILED: %0d outputs (expected %0d), %0d wrong", gap, got, n / 16, errors);
    $finish;
  end
  always @(negedge clk) if (!rst && out_valid) begin
    $fdisplay(fd, "%h", y);
    if (got < n / 16 && y !== exp_mem[got]) errors++;
    got++;
  end
endmodule
