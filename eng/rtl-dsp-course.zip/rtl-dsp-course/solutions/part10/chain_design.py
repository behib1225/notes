#!/usr/bin/env python3
"""chain_design.py -- CIC (R = 16) + 2x FIR compensation decimator: design and combined analysis."""
import numpy as np
from scipy import signal

FS, R = 100e6, 16                      # input rate, CIC decimation
FS1 = FS / R                           # 6.25 MHz: CIC output, FIR input
FP, FSTOP = 1.25e6, 1.875e6            # passband edge; first frequency folding into the band

def cic(f, N):
    """CIC magnitude at input frequency f (Hz), normalized to 1 at DC."""
    x = np.pi * np.asarray(f, float) / FS
    with np.errstate(invalid="ignore", divide="ignore"):
        h = np.abs(np.sin(R * x) / (R * np.sin(x)))
    return np.where(np.abs(np.sin(x)) < 1e-15, 1.0, h) ** N

def design_fir(ntaps, N, window=("kaiser", 6.0)):
    """firwin2: gain 1/CIC up to the passband edge, 0 from the stopband edge (at the FS1 rate)."""
    fp = np.linspace(0, FP, 60)
    freq = np.r_[fp, FSTOP, FS1 / 2] / (FS1 / 2)
    gain = np.r_[1 / cic(fp, N), 0, 0]
    return signal.firwin2(ntaps, freq, gain, window=window)

def fir_resp(h, f):
    """FIR magnitude at frequency f (Hz) of ITS rate FS1 (periodic in FS1)."""
    _, H = signal.freqz(h, worN=2 * np.pi * (np.asarray(f) % FS1) / FS1)
    return np.abs(H)

def analyze(h, N, npts=400):
    fo = np.linspace(0, FP, npts)                         # output frequencies inside the wanted band
    pas = 20 * np.log10(cic(fo, N) * fir_resp(h, fo))
    ripple = pas.max() - pas.min()
    worst, worst_cic_only = 200.0, 200.0
    for k in range(1, int(FS / 2 / (FS1 / 2)) + 1):     # every image k * 3.125 MHz +- fo, up to 50 MHz
        for s in (-1, 1):
            fin = k * FS1 / 2 + s * fo
            fin = fin[(fin > 0) & (fin <= FS / 2)]
            if fin.size == 0: continue
            tot = 20 * np.log10(cic(fin, N) * fir_resp(h, fin) + 1e-15)
            worst = min(worst, -(tot.max() - pas.max()))
            if k % 2 == 0:                                # lands in the passband at the CIC output too
                worst_cic_only = min(worst_cic_only, -20 * np.log10(cic(fin, N).max()))
    return ripple, worst, worst_cic_only

if __name__ == "__main__":
    for N in (4, 5):
        r, w, wc = analyze(design_fir(39, N), N)
        print(f"N={N}: images at even multiples of 3.125 MHz land in the passband already at the CIC output;"
              f" the CIC alone limits them to {wc:.1f} dB")
