`timescale 1ns/1ps
// decim16.sv -- two-stage decimator: CIC (R = 8) then decimating FIR (M = 2): one output per 16 inputs.
// The CIC's output valid drives the FIR's input valid. The CIC cannot wait, so every CIC output
// must find the FIR ready; the assertion below reports a lost sample.
module decim16 #(
  parameter int XW = 16
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  logic                 c_valid, c_ready_unused, f_ready;
  logic signed [XW-1:0] c_y;

  cic_decim #(.R(8), .NS(3)) u_cic (
    .clk(clk), .rst(rst), .in_valid(in_valid), .in_ready(c_ready_unused), .x(x),
    .out_valid(c_valid), .y(c_y));
  fir_decim #(.M(2)) u_fir (
    .clk(clk), .rst(rst), .in_valid(c_valid), .in_ready(f_ready), .x(c_y),
    .out_valid(out_valid), .y(y));

  assign in_ready = 1'b1;                       // the CIC accepts a sample every cycle

  // a CIC output arriving while the FIR is computing would be dropped
  // (simulation only: Yosys defines SYNTHESIS and cannot synthesize $error)
`ifndef SYNTHESIS
  always @(posedge clk) begin
    if (!rst && c_valid && !f_ready)
      $error("decim16: CIC output lost: the FIR was busy (inputs arrive too fast)");
  end
`endif
endmodule
