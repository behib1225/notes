`timescale 1ns/1ps
// tb_interp.sv -- tb_decim.sv with n * L expected outputs (+M= gives L)
// Source: valid/ready with random gaps. Monitor: records every output in order.
`ifndef DUT
  `define DUT fir_interp
`endif
`ifndef DUT_PARAMS
  `define DUT_PARAMS .L(4)
`endif
module tb_interp;
  localparam int XW = 16, YW = 16, MAX_N = 100_000;
  logic                 clk = 1'b0, rst, in_valid, in_ready, out_valid;
  logic signed [XW-1:0] x;
  logic signed [YW-1:0] y;
  logic [XW-1:0] x_mem   [0:MAX_N-1];
  logic [YW-1:0] exp_mem [0:MAX_N-1];
  int n = 3000, decim = 1, seed = 1, sent = 0, got = 0, errors = 0, fd, cycles = 0;

  `DUT #(`DUT_PARAMS) dut (.clk(clk), .rst(rst), .in_valid(in_valid), .in_ready(in_ready), .x(x),
            .out_valid(out_valid), .y(y));
  always #5 clk = ~clk;
  initial begin #100_000_000; $fatal(1, "TIMEOUT"); end
  always @(posedge clk) cycles++;

  initial begin
    void'($value$plusargs("N=%d", n));
    void'($value$plusargs("SEED=%d", seed));
    void'($value$plusargs("M=%d", decim));
    void'($urandom(seed));
    $readmemh("x.hex", x_mem, 0, n - 1);
    $readmemh("y_expected.hex", exp_mem, 0, n * decim - 1);
    fd = $fopen("y_actual.hex", "w");
    rst = 1'b1; in_valid = 1'b0; x = '0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    while (sent < n) begin
      if (!in_valid && $urandom_range(0, 4) != 0) begin    // offer a sample (sometimes wait)
        in_valid = 1'b1;
        x = x_mem[sent];
      end
      @(posedge clk);
      if (in_valid && in_ready) begin                      // transfer at this edge
        sent++;
        @(negedge clk);
        in_valid = 1'b0;
        x = 'x;
      end else @(negedge clk);
    end
  end

  always @(negedge clk) if (!rst && out_valid) begin
    assert (!$isunknown(y)) else $error("output %0d unknown", got);
    $fdisplay(fd, "%h", y);
    if (y !== exp_mem[got]) begin
      if (errors < 5) $display("FAIL sample %0d: got %0d expected %0d", got, y, $signed(exp_mem[got]));
      errors++;
    end
    got++;
    if (got == n * decim) begin
      $fclose(fd);
      if (errors) $fatal(1, "FAILED: %0d of %0d outputs wrong", errors, n * decim);
      $display("PASS: %0d outputs bit-exact, %0d clock cycles", n * decim, cycles);
      $finish;
    end
  end
endmodule
