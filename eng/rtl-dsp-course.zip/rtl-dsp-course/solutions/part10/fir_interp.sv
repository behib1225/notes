`timescale 1ns/1ps
// fir_interp.sv -- polyphase interpolator by L: for each input sample, L outputs.
// Output p (p = 0 .. L-1) uses only h[p], h[p+L], h[p+2L], ...: the inserted zeros are never
// multiplied. One MAC computes all L outputs: N/L products each, N products per input.
module fir_interp #(
  parameter int N = 32, L = 4,
  parameter int XW = 16, XF = 15, CW = 18, CF = 17, YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "interp_coefs.svh"
  localparam int NP = N / L;                         // taps per phase (8)
  localparam int JW = (NP > 1) ? $clog2(NP) : 1;
  localparam int PW = (L > 1) ? $clog2(L) : 1;

  typedef enum logic {S_IDLE, S_RUN} state_t;
  state_t               state;
  logic [PW-1:0]        p;                           // output phase
  logic [JW-1:0]        j;                           // tap within the phase
  logic signed [XW-1:0] taps [0:NP-1];               // only N/L input samples are needed

  assign in_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;  p <= '0;  j <= '0;
      for (int i = 0; i < NP; i++) taps[i] <= '0;
    end else begin
      case (state)
        S_IDLE: if (in_valid) begin
          taps[0] <= x;
          for (int i = 1; i < NP; i++) taps[i] <= taps[i-1];
          p <= '0;  j <= '0;  state <= S_RUN;
        end
        S_RUN: begin
          j <= j + 1'b1;
          if (j == JW'(NP - 1)) begin
            p <= p + 1'b1;
            if (p == PW'(L - 1)) state <= S_IDLE;
          end
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  logic mac_ovf_unused;
  mac #(.A_W(XW), .A_F(XF), .B_W(CW), .B_F(CF), .ACC_W(XW + CW + JW + 1),
        .OUT_W(YW), .OUT_F(YF)) u_mac (
    .clk(clk), .rst(rst),
    .in_valid(state == S_RUN), .first(j == '0), .last(j == JW'(NP - 1)),
    .a(taps[j]), .b(interp_coef(32'(p) + L * 32'(j))),
    .out_valid(out_valid), .dout(y), .dout_ovf(mac_ovf_unused)
  );
endmodule
