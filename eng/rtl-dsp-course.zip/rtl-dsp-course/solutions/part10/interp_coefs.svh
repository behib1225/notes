// interp_coefs.svh -- generated: L * firwin(32, 0.2), L = 4, in Q1.17
function automatic logic signed [17:0] interp_coef(input int k);
  case (k)
     0: interp_coef = -18'sd266;
     1: interp_coef = 18'sd318;
     2: interp_coef = 18'sd1172;
     3: interp_coef = 18'sd2166;
     4: interp_coef = 18'sd2616;
     5: interp_coef = 18'sd1455;
     6: interp_coef = -18'sd2062;
     7: interp_coef = -18'sd7462;
     8: interp_coef = -18'sd12520;
     9: interp_coef = -18'sd13596;
    10: interp_coef = -18'sd6955;
    11: interp_coef = 18'sd9405;
    12: interp_coef = 18'sd34256;
    13: interp_coef = 18'sd62825;
    14: interp_coef = 18'sd88011;
    15: interp_coef = 18'sd102782;
    16: interp_coef = 18'sd102782;
    17: interp_coef = 18'sd88011;
    18: interp_coef = 18'sd62825;
    19: interp_coef = 18'sd34256;
    20: interp_coef = 18'sd9405;
    21: interp_coef = -18'sd6955;
    22: interp_coef = -18'sd13596;
    23: interp_coef = -18'sd12520;
    24: interp_coef = -18'sd7462;
    25: interp_coef = -18'sd2062;
    26: interp_coef = 18'sd1455;
    27: interp_coef = 18'sd2616;
    28: interp_coef = 18'sd2166;
    29: interp_coef = 18'sd1172;
    30: interp_coef = 18'sd318;
    31: interp_coef = -18'sd266;
    default: interp_coef = '0;
  endcase
endfunction
