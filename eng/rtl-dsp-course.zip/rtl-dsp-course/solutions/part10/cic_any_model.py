#!/usr/bin/env python3
"""cic_any_model.py -- bit-exact model of cic_decim_any.sv, and the choice of its gain constant."""
import numpy as np
from fixedpoint import requant

def gain_constant(R, N, kbits=17):
    """Largest shift S with K = round(2**S / R**N) < 2**kbits (fits a (kbits+1)-bit signed word)."""
    G = R ** N
    S = int(np.floor(np.log2((2 ** kbits - 1) * G)))
    K = round(2 ** S / G)
    while K >= 2 ** kbits:
        S -= 1; K = round(2 ** S / G)
    return K, S

def cic_any_golden(x, R, N, K, S, XW=16):
    W = XW + (R ** N - 1).bit_length()               # XW + ceil(log2(R**N)), like $clog2(R**NS)
    mask, half = (1 << W) - 1, 1 << (W - 1)
    wrap = lambda v: ((v + half) & mask) - half
    integ, comb_d, cnt, out = [0] * N, [0] * N, 0, []
    for v in np.asarray(x, dtype=np.int64).tolist():
        old = integ[:]
        integ[0] = wrap(old[0] + v)
        for k in range(1, N):
            integ[k] = wrap(old[k] + old[k - 1])
        if cnt == R - 1:
            c = old[N - 1]
            for k in range(N):
                c, comb_d[k] = wrap(c - comb_d[k]), c
            out.append(c)
            cnt = 0
        else:
            cnt += 1
    c = np.array(out, dtype=np.int64)
    return requant(c * K, 15 + S, 16, 15, "round", "saturate"), c, W
