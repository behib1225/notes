`timescale 1ns/1ps
// cic_decim_any.sv -- CIC decimator for ANY R: the gain R**NS is removed by multiplying with
// a constant GK ~ 2**GS / R**NS and dropping GS bits (rounded). Integrators and combs wrap,
// as in cic_decim.sv; their width is XW + ceil(NS * log2 R) = XW + $clog2(R**NS).
module cic_decim_any #(
  parameter int R  = 10, NS = 3,
  parameter int XW = 16, XF = 15,
  parameter int GK = 67109, GS = 26,            // 2**26 / 1000 = 67108.9 -> 67109 (R = 10, NS = 3)
  parameter int GKW = 18,                       // the constant's width (signed): one DSP B port
  parameter int W  = XW + $clog2(R**NS)         // 26 bits for R = 10
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  localparam int RW = $clog2(R);
  assign in_ready = 1'b1;

  logic signed [W-1:0] integ  [0:NS-1];
  logic signed [W-1:0] comb_d [0:NS-1];
  logic signed [W-1:0] c      [0:NS];
  logic [RW-1:0]       cnt;
  logic                dec;
  assign dec = in_valid && (cnt == RW'(R - 1));

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < NS; k++) begin integ[k] <= '0; comb_d[k] <= '0; end
      cnt <= '0;
    end else if (in_valid) begin
      integ[0] <= integ[0] + W'(x);
      for (int k = 1; k < NS; k++) integ[k] <= integ[k] + integ[k-1];
      cnt <= dec ? '0 : cnt + 1'b1;
      if (dec) for (int k = 0; k < NS; k++) comb_d[k] <= c[k];
    end
  end

  always_comb begin
    c[0] = integ[NS-1];
    for (int k = 0; k < NS; k++) c[k+1] = c[k] - comb_d[k];
  end

  // gain correction: c * GK, then drop GS bits with rounding (and saturate to Q1.15)
  localparam logic signed [GKW-1:0] K = GKW'(GK);
  logic signed [W+GKW-1:0] prod;
  assign prod = c[NS] * K;

  logic signed [XW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(W + GKW), .IN_F(XF + GS), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1))
    u_rq (.din(prod), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= dec;
    if (dec) y <= y_c;
  end
endmodule
