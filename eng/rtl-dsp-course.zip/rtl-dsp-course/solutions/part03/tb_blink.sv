`timescale 1ns/1ps
// tb_blink.sv -- checks the specification: led = 1 only in S_ON; OFF -go-> ON -> WAIT -> OFF
module tb_blink;
  logic clk = 1'b0, rst, go, led;
  int errors = 0, model = 0;                   // model state: 0 = OFF, 1 = ON, 2 = WAIT
  blink_ctrl dut (.*);
  always #5 clk = ~clk;
  initial begin #100_000; $fatal(1, "TIMEOUT"); end
  initial begin
    rst = 1'b1; go = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (2000) begin
      go = $urandom_range(0, 1);
      #1;                                        // settle, then check the combinational output
      if (led !== (model == 1)) begin
        if (errors < 4) $display("FAIL at %0d ns: state %0d go=%b led=%b, expected %b", $time, model, go, led, model == 1);
        errors++;
      end
      @(posedge clk);
      case (model)
        0: if (go) model = 1;
        1: model = 2;
        default: model = 0;
      endcase
      @(negedge clk);
    end
    if (errors == 0) $display("PASS"); else $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
