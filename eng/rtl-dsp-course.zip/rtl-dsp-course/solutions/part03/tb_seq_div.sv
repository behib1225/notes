`timescale 1ns/1ps
module tb_seq_div;
  localparam int W = 8;
  logic clk = 1'b0, rst, start, busy, done, div_by_zero;
  logic [W-1:0] dividend, divisor, quotient, remainder;
  int errors = 0, tests = 0, cycles;
  seq_div #(.W(W)) dut (.*);
  always #5 clk = ~clk;
  initial begin #2_000_000; $fatal(1, "TIMEOUT"); end

  task automatic divide(input int a, b);
    @(negedge clk);
    dividend = a[W-1:0]; divisor = b[W-1:0]; start = 1'b1;
    @(negedge clk); start = 1'b0; dividend = 'x; divisor = 'x;   // inputs only needed at start
    cycles = 1;
    while (!done) begin @(negedge clk); cycles++; end
    tests++;
    if (b == 0) begin
      if (!div_by_zero) begin $display("FAIL: %0d / 0 did not set div_by_zero", a); errors++; end
    end else if (div_by_zero || quotient !== W'(a / b) || remainder !== W'(a % b)) begin
      if (errors < 5) $display("FAIL: %0d / %0d -> q=%0d r=%0d dbz=%b, expected q=%0d r=%0d",
                               a, b, quotient, remainder, div_by_zero, a / b, a % b);
      errors++;
    end
  endtask

  initial begin
    rst = 1'b1; start = 1'b0; dividend = '0; divisor = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    divide(200, 7);  $display("200 / 7: q=%0d r=%0d, %0d cycles from start to done", quotient, remainder, cycles);
    divide(0, 5);  divide(5, 0);  $display("5 / 0: div_by_zero=%b, %0d cycles", div_by_zero, cycles);
    divide(0, 0);  divide(255, 1);  divide(255, 255);  divide(1, 255);  divide(254, 255);
    divide(255, 2);  divide(128, 128);  divide(127, 128);  divide(255, 16);  divide(7, 7);
    repeat (1000) divide($urandom_range(0, 255), $urandom_range(1, 255));
    if (errors == 0) $display("PASS: %0d divisions", tests);
    else             $display("FAILED: %0d of %0d", errors, tests);
    $finish;
  end
endmodule
