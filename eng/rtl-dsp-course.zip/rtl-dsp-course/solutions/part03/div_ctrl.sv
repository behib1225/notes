`timescale 1ns/1ps
// div_ctrl.sv -- controller of the restoring divider: start / busy / done
module div_ctrl (
  input  logic clk, rst,
  input  logic start,
  input  logic last, d_zero,          // status from the datapath
  output logic load, step,            // control to the datapath
  output logic busy, done, div_by_zero
);
  typedef enum logic [1:0] {S_IDLE, S_RUN, S_DONE} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_IDLE;
    else     state <= next;
  end

  // div_by_zero is registered: it holds the result of the last division until the next start
  always_ff @(posedge clk) begin
    if (rst)                            div_by_zero <= 1'b0;
    else if (state == S_IDLE && start)  div_by_zero <= d_zero;
  end

  always_comb begin
    next = state;  load = 1'b0;  step = 1'b0;
    case (state)
      S_IDLE: if (start) begin
                load = 1'b1;
                if (d_zero) next = S_DONE;               // skip the computation for divisor 0
                else        next = S_RUN;
              end
      S_RUN:  begin
                step = 1'b1;
                if (last) next = S_DONE;
              end
      S_DONE: next = S_IDLE;
      default: next = S_IDLE;
    endcase
  end

  assign busy = (state == S_RUN);
  assign done = (state == S_DONE);                       // a one-cycle pulse
endmodule
