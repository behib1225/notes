`timescale 1ns/1ps
module tb_detect0110;
  logic clk = 1'b0, rst, x;
  logic y_moore, y_mealy, y_mreg;
  logic [3:0] last4 = 4'b1111;       // the last 4 bits ALREADY clocked in (oldest in bit 3)
  int found_moore = 0, found_mealy = 0, found_mreg = 0, expected = 0, errors = 0;
  detect0110_moore     u1 (.clk(clk), .rst(rst), .x(x), .y(y_moore));
  detect0110_mealy     u2 (.clk(clk), .rst(rst), .x(x), .y(y_mealy));
  detect0110_mealy_reg u3 (.clk(clk), .rst(rst), .x(x), .y(y_mreg));
  always #5 clk = ~clk;
  initial begin #200_000; $fatal(1, "TIMEOUT"); end

  initial begin
    rst = 1'b1; x = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (5000) begin
      x = $urandom_range(0, 1);                      // new bit, applied at the falling edge
      #1;
      // Mealy: sees the current bit, so it reports a match in the same cycle
      if (y_mealy !== ({last4[2:0], x} == 4'b0110)) begin errors++; $display("FAIL mealy at %0d", $time); end
      // Moore and registered Mealy: report a match one cycle later, from the bits already clocked in
      if (y_moore !== (last4 == 4'b0110)) begin errors++; $display("FAIL moore at %0d", $time); end
      if (y_mreg  !== (last4 == 4'b0110)) begin errors++; $display("FAIL mealy_reg at %0d", $time); end
      found_mealy += y_mealy;  found_moore += y_moore;  found_mreg += y_mreg;
      expected    += ({last4[2:0], x} == 4'b0110);
      @(posedge clk);
      last4 = {last4[2:0], x};
      @(negedge clk);
    end
    // count the Moore/registered match of the final bit, which appears one cycle later
    #1; found_moore += y_moore; found_mreg += y_mreg;
    if (errors == 0 && found_mealy == expected && found_moore == expected && found_mreg == expected)
      $display("PASS: 5000 bits, %0d patterns expected; Moore %0d, Mealy %0d, registered Mealy %0d",
               expected, found_moore, found_mealy, found_mreg);
    else
      $display("FAILED: errors %0d, expected %0d, found %0d %0d %0d", errors, expected, found_moore, found_mealy, found_mreg);
    $finish;
  end
endmodule
