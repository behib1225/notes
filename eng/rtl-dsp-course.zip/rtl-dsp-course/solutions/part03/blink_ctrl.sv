`timescale 1ns/1ps
// blink_ctrl.sv -- rewritten in the style of section 3.2:
//   defaults first, a default branch, blocking '=' only, and a Moore output decoded from the state.
module blink_ctrl (
  input  logic clk, rst, go,
  output logic led
);
  typedef enum logic [1:0] {S_OFF, S_ON, S_WAIT} state_t;
  state_t state, next;

  // 1. state register
  always_ff @(posedge clk) begin
    if (rst) state <= S_OFF;
    else     state <= next;
  end

  // 2. next-state logic: only 'next' is assigned here, with a default first
  always_comb begin
    next = state;                       // default: every path assigns next (no latch)
    case (state)
      S_OFF:   if (go) next = S_ON;
      S_ON:    next = S_WAIT;
      S_WAIT:  next = S_OFF;
      default: next = S_OFF;            // the unused encoding 2'b11 recovers
    endcase
  end

  // 3. output logic: Moore, a function of the state only, written once
  assign led = (state == S_ON);
endmodule
