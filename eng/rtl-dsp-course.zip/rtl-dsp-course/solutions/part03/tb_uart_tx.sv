`timescale 1ns/1ps
module tb_uart_tx;
  localparam int BAUD = 8;                          // clocks per bit
  logic clk = 1'b0, rst, baud_tick, in_valid, in_ready, tx;
  logic [7:0] data;
  logic [7:0] sent [$];                             // queue of bytes accepted by the DUT
  int received = 0, errors = 0, cnt = 0;
  uart_tx dut (.*);
  always #5 clk = ~clk;
  initial begin #200_000; $fatal(1, "TIMEOUT"); end

  // baud tick: one pulse every BAUD clocks
  always @(posedge clk) begin
    if (rst) begin cnt <= 0; baud_tick <= 1'b0; end
    else begin cnt <= (cnt == BAUD - 1) ? 0 : cnt + 1; baud_tick <= (cnt == BAUD - 1); end
  end

  // source: random bytes with random gaps, following valid/ready
  initial begin
    rst = 1'b1; in_valid = 1'b0; data = '0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    repeat (50) begin
      repeat ($urandom_range(0, 30)) @(negedge clk);   // random idle gap
      in_valid = 1'b1; data = $urandom;
      do @(posedge clk); while (!in_ready);          // transfer at an edge with ready high
      sent.push_back(data);
      @(negedge clk); in_valid = 1'b0; data = 'x;
    end
  end

  // receiver model: falling edge = start bit; sample each bit in its middle
  initial begin
    logic [7:0] b;
    @(negedge rst);
    repeat (50) begin
      @(negedge tx);                                  // start of the start bit
      repeat (BAUD / 2) @(posedge clk);              // middle of the start bit
      if (tx !== 1'b0) begin $display("FAIL: bad start bit"); errors++; end
      for (int i = 0; i < 8; i++) begin
        repeat (BAUD) @(posedge clk);
        b[i] = tx;                                    // LSB first
      end
      repeat (BAUD) @(posedge clk);
      if (tx !== 1'b1) begin $display("FAIL: bad stop bit"); errors++; end
      if (b !== sent[received]) begin
        $display("FAIL byte %0d: received %h, sent %h", received, b, sent[received]); errors++;
      end
      received++;
    end
    if (errors == 0) $display("PASS: %0d bytes received correctly", received);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
