`timescale 1ns/1ps
// div_datapath.sv -- registers and arithmetic of the restoring divider
module div_datapath #(
  parameter int W = 8
) (
  input  logic         clk,
  input  logic [W-1:0] dividend, divisor,
  input  logic         load,          // control: R <= 0, Q <= dividend, D <= divisor, count <= 0
  input  logic         step,          // control: one restoring-division step
  output logic         last,          // status: this is step W (count == W-1)
  output logic         d_zero,        // status: the divisor input is zero
  output logic [W-1:0] quotient, remainder
);
  logic [W-1:0]         r;            // partial remainder: always < divisor, so W bits suffice
  logic [W-1:0]         q, d;
  logic [$clog2(W)-1:0] count;
  logic [W:0]           r_sh;         // R shifted left with the next dividend bit: needs W+1 bits
  logic                 fits;

  assign r_sh   = {r, q[W-1]};
  assign fits   = (r_sh >= {1'b0, d});
  assign last   = (count == ($clog2(W))'(W - 1));
  assign d_zero = (divisor == '0);

  always_ff @(posedge clk) begin
    if (load) begin
      r <= '0;  q <= dividend;  d <= divisor;  count <= '0;
    end else if (step) begin
      r     <= W'(r_sh - {1'b0, d});
      q     <= {q[W-2:0], fits};                      // the new quotient bit enters at the bottom
      count <= count + 1'b1;
    end
  end

  assign quotient  = q;
  assign remainder = r;
endmodule
