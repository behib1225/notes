`timescale 1ns/1ps
module blink_ctrl (
  input  logic clk, rst, go,
  output logic led
);
  typedef enum logic [1:0] {S_OFF, S_ON, S_WAIT} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_OFF;
    else     state <= next;
  end

  always_comb begin
    case (state)
      S_OFF:  if (go) begin next = S_ON; led = 1'b1; end
      S_ON:   begin next = S_WAIT; led = 1'b1; end
      S_WAIT: begin next <= S_OFF; led = 1'b0; end
    endcase
  end
endmodule
