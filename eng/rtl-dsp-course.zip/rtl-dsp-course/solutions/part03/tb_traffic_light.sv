`timescale 1ns/1ps
module tb_traffic_light;
  logic clk = 1'b0, rst, ped, green, yellow, red;
  int g = 0, yl = 0, r = 0, cycles_done = 0, errors = 0, ped_ticks = -1;
  logic [2:0] prev;
  traffic_light #(.DIV(4)) dut (.*);
  always #5 clk = ~clk;
  initial begin #100_000; $fatal(1, "TIMEOUT"); end

  // exactly one light, always (checked at every falling edge after reset)
  always @(negedge clk) if (!rst && (green + yellow + red) != 1) begin
    $display("FAIL: lights %b%b%b at %0d ns", green, yellow, red, $time); errors++;
  end

  // count ticks per color: a tick at a rising edge belongs to the color shown before that edge
  always @(posedge clk) if (!rst) begin
    prev = {green, yellow, red};
    if (dut.tick) begin
      if (green)  g++;
      if (yellow) yl++;
      if (red)    r++;
      if (ped_ticks >= 0 && green) ped_ticks++;
    end
  end

  // at each change of color, check the run that just ended
  always @(negedge clk) if (!rst && {green, yellow, red} != prev && prev != 3'b000) begin
    if (prev == 3'b100) begin
      if (ped_ticks < 0 && g != 5) begin $display("FAIL: green lasted %0d ticks", g);  errors++; end
      if (ped_ticks >= 0) begin
        $display("pedestrian press during green: green lasted %0d more tick(s) after the press", ped_ticks);
        if (ped_ticks > 1) errors++;
        ped_ticks = -1;
      end
      g = 0;
    end
    if (prev == 3'b010) begin if (yl != 2) begin $display("FAIL: yellow lasted %0d ticks", yl); errors++; end yl = 0; end
    if (prev == 3'b001) begin if (r  != 4) begin $display("FAIL: red lasted %0d ticks", r);    errors++; end r = 0; cycles_done++; end
  end

  initial begin
    rst = 1'b1; ped = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    wait (cycles_done == 10);
    $display("10 full cycles: green 5, yellow 2, red 4 ticks each time");
    // pedestrian: press for one cycle, 1 tick into a green phase
    @(posedge green); repeat (5) @(negedge clk);
    ped = 1'b1; ped_ticks = 0; @(negedge clk); ped = 1'b0;
    wait (cycles_done == 12);
    if (errors == 0) $display("PASS");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
