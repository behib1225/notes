`timescale 1ns/1ps
// traffic_light.sv -- green 5 ticks, yellow 2, red 4, repeat; ped shortens green.
// Controller (FSM) + datapath (down-counter timer). Lights come from flip-flops.
module traffic_light #(
  parameter int DIV = 4,                       // tick_gen division (4 for fast simulation)
  parameter int T_GREEN = 5, T_YELLOW = 2, T_RED = 4
) (
  input  logic clk, rst,
  input  logic ped,                            // pedestrian request (synchronous here)
  output logic green, yellow, red
);
  // ---- tick source (Part 2) ----
  logic tick;
  tick_gen #(.DIV(DIV)) u_tick (.clk(clk), .rst(rst), .tick(tick));

  // ---- datapath: the timer ----
  logic [2:0] timer, load_val;
  logic       load, timer_zero;
  assign timer_zero = (timer == 3'd0);

  always_ff @(posedge clk) begin
    if (rst)                      timer <= 3'(T_GREEN - 1);   // green starts with its full duration
    else if (load)                timer <= load_val;
    else if (tick && !timer_zero) timer <= timer - 1'b1;
  end

  // ---- controller ----
  typedef enum logic [1:0] {S_GREEN, S_YELLOW, S_RED} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_GREEN;
    else     state <= next;
  end

  always_comb begin
    next = state;  load = 1'b0;  load_val = '0;          // defaults: stay, keep counting
    case (state)
      S_GREEN:
        if (tick && timer_zero) begin
          next = S_YELLOW;  load = 1'b1;  load_val = 3'(T_YELLOW - 1);
        end else if (ped && !timer_zero) begin
          load = 1'b1;  load_val = 3'd0;                    // at most 1 more tick of green
        end
      S_YELLOW:
        if (tick && timer_zero) begin
          next = S_RED;     load = 1'b1;  load_val = 3'(T_RED - 1);
        end
      S_RED:
        if (tick && timer_zero) begin
          next = S_GREEN;   load = 1'b1;  load_val = 3'(T_GREEN - 1);
        end
      default: next = S_GREEN;
    endcase
  end

  // ---- registered outputs: decoded from NEXT, so they change together with the state ----
  always_ff @(posedge clk) begin
    if (rst) {green, yellow, red} <= 3'b100;
    else     {green, yellow, red} <= {next == S_GREEN, next == S_YELLOW, next == S_RED};
  end
endmodule
