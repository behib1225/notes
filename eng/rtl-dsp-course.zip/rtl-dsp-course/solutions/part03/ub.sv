`timescale 1ns/1ps
// uart_tx.sv -- 8N1 serial transmitter: start bit (0), 8 data bits LSB first, stop bit (1).
// One bit per baud_tick. Valid/ready input: a byte is accepted when in_valid && in_ready.
module uart_tx (
  input  logic       clk, rst,
  input  logic       baud_tick,       // one pulse per bit period
  input  logic       in_valid,
  output logic       in_ready,
  input  logic [7:0] data,
  output logic       tx                // idles at 1; driven by a flip-flop
);
  typedef enum logic {S_IDLE, S_SEND} state_t;
  state_t     state;
  logic [9:0] shreg;                  // {stop, data[7:0], start}: bit 0 goes out first
  logic [3:0] nbits;                  // bits sent so far in this frame

  assign in_ready = (state == S_IDLE);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;  tx <= 1'b1;  shreg <= '1;  nbits <= '0;
    end else begin
      case (state)
        S_IDLE:
          if (in_valid) begin                       // in_ready is 1 here: a transfer
            shreg <= {1'b1, {data[0], data[7:1]}, 1'b0};
            nbits <= '0;
            state <= S_SEND;
          end
        S_SEND:
          if (baud_tick) begin                      // each bit starts on a tick
            tx    <= shreg[0];
            shreg <= {1'b1, shreg[9:1]};
            nbits <= nbits + 1'b1;
            if (nbits == 4'd9) state <= S_IDLE;     // the stop bit is now on the line
          end
        default: state <= S_IDLE;
      endcase
    end
  end
endmodule
