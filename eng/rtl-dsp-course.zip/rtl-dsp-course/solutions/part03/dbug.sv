`timescale 1ns/1ps
// detect0110.sv -- overlapping detector for the pattern 0,1,1,0 (oldest first), three ways.

// ---------- Moore: the output depends only on the state ----------
module detect0110_moore (
  input  logic clk, rst, x,
  output logic y
);
  typedef enum logic [2:0] {S0, S1, S2, S3, S4} state_t;   // S4 = "just saw 0110"
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S0;
    else     state <= next;
  end

  always_comb begin
    next = S0;
    case (state)
      S0: if (x) next = S0; else next = S1;     // nothing useful seen yet
      S1: if (x) next = S2; else next = S1;     // "0"
      S2: if (x) next = S3; else next = S1;     // "01"
      S3: if (x) next = S0; else next = S4;     // "011"
      S4: if (x) next = S0; else next = S1;     // "0110": overlap, its last 0 starts a new match
      default: next = S0;
    endcase
  end

  assign y = (state == S4);
endmodule

// ---------- Mealy: the output depends on the state AND the current input ----------
module detect0110_mealy (
  input  logic clk, rst, x,
  output logic y
);
  typedef enum logic [1:0] {S0, S1, S2, S3} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S0;
    else     state <= next;
  end

  always_comb begin
    next = S0;
    y    = 1'b0;
    case (state)
      S0: if (x) next = S0; else next = S1;
      S1: if (x) next = S2; else next = S1;
      S2: if (x) next = S3; else next = S1;
      S3: if (x) next = S0;
          else begin next = S1; y = 1'b1; end   // the 0 that completes 0110
      default: next = S0;
    endcase
  end
endmodule

// ---------- Mealy with a registered output: Mealy logic, output delayed one cycle ----------
module detect0110_mealy_reg (
  input  logic clk, rst, x,
  output logic y
);
  logic y_comb;
  detect0110_mealy u_mealy (.clk(clk), .rst(rst), .x(x), .y(y_comb));

  always_ff @(posedge clk) begin
    if (rst) y <= 1'b0;
    else     y <= y_comb;          // y comes straight from a flip-flop: glitch-free
  end
endmodule
