`timescale 1ns/1ps
// seq_div.sv -- W-bit unsigned restoring divider: datapath + controller
module seq_div #(
  parameter int W = 8
) (
  input  logic         clk, rst, start,
  input  logic [W-1:0] dividend, divisor,
  output logic         busy, done, div_by_zero,
  output logic [W-1:0] quotient, remainder
);
  logic load, step, last, d_zero;
  div_datapath #(.W(W)) u_dp (
    .clk(clk), .dividend(dividend), .divisor(divisor), .load(load), .step(step),
    .last(last), .d_zero(d_zero), .quotient(quotient), .remainder(remainder)
  );
  div_ctrl u_ctrl (
    .clk(clk), .rst(rst), .start(start), .last(last), .d_zero(d_zero),
    .load(load), .step(step), .busy(busy), .done(done), .div_by_zero(div_by_zero)
  );
endmodule
