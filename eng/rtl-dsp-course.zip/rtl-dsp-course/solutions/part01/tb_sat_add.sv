`timescale 1ns/1ps
module tb_sat_add;
  localparam int W = 8;
  logic signed [W-1:0] a, b, y;
  int errors = 0, tests = 0;
  sat_add #(.W(W)) dut (.*);

  task automatic check(input int ta, tb);
    int exact, expected;
    a = ta[W-1:0]; b = tb[W-1:0];
    #1;
    exact = int'(a) + int'(b);                  // int arithmetic: no overflow possible
    if      (exact >  127) expected =  127;
    else if (exact < -128) expected = -128;
    else                   expected = exact;
    tests++;
    if (int'(y) != expected) begin
      if (errors < 5) $display("FAIL: %0d + %0d -> %0d, expected %0d", a, b, y, expected);
      errors++;
    end
  endtask

  initial begin
    check(127, 1);   check(-128, -1);  check(127, 127);
    check(-128, -128); check(-1, 1);   check(0, 0);  check(127, -128);
    repeat (2000) check($urandom_range(0, 255) - 128, $urandom_range(0, 255) - 128);
    if (errors == 0) $display("PASS: %0d cases", tests);
    else             $display("FAILED: %0d of %0d", errors, tests);
    $finish;
  end
endmodule
