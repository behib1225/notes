`timescale 1ns/1ps
// abs_sat.sv -- |x| of a signed 8-bit input, saturated to +127
module abs_sat (
  input  logic signed [7:0] x,
  output logic signed [7:0] y   // |x|, saturated to +127
);
  always_comb begin
    if (x == -8'sd128)          // bug 3: +128 does not fit, so saturate
      y = 8'sd127;
    else if (x < 8'sd0)         // bug 1: compare with a SIGNED zero
      y = -x;
    else                        // bug 2: assign y on every path (no latch)
      y = x;
  end
endmodule
