module tb_sat_ex; logic signed [7:0] a,b,y; int e=0, ex; sat_add #(.W(8)) dut(.*);
initial begin for (int i=-128;i<128;i++) for (int j=-128;j<128;j++) begin a=i; b=j; #1; ex=i+j; if (ex>127) ex=127; if (ex<-128) ex=-128; if (int'(y)!=ex) e++; end
$display("exhaustive 65536: %0d errors", e); $finish; end endmodule
