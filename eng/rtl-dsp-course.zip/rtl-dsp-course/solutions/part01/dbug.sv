`timescale 1ns/1ps
// decoder2to4.sv -- 2-to-4 decoder with enable, written two ways
module decoder2to4 (
  input  logic       en,
  input  logic [1:0] a,
  output logic [3:0] y_case,    // version 1: case statement
  output logic [3:0] y_shift    // version 2: one shift
);
  always_comb begin
    y_case = 4'b0000;           // default: no output active (also prevents a latch)
    if (en) begin
      case (a)
        2'd0:    y_case = 4'b0001;
        2'd1:    y_case = 4'b0010;
        2'd2:    y_case = 4'b1000;
        default: y_case = 4'b1000;
      endcase
    end
  end

  assign y_shift = en ? (4'b0001 << a) : 4'b0000;
endmodule
