`timescale 1ns/1ps
module tb_abs_sat;
  logic signed [7:0] x, y;
  int expected, errors = 0;
  abs_sat dut (.*);
  initial begin
    for (int i = -128; i < 128; i++) begin      // exhaustive: all 256 inputs
      x = i[7:0];
      #1;
      expected = (i < 0) ? -i : i;
      if (expected > 127) expected = 127;
      if (y !== 8'(expected)) begin
        if (errors < 5) $display("FAIL x=%0d: y=%0d, expected %0d", x, y, expected);
        errors++;
      end
    end
    if (errors == 0) $display("PASS: all 256 inputs");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
