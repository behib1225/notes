`timescale 1ns/1ps
// prio_enc4.sv -- 4-to-2 priority encoder: the highest-numbered active input wins
module prio_enc4 (
  input  logic [3:0] d,
  output logic [1:0] y,
  output logic       valid
);
  always_comb begin
    if      (d[3]) y = 2'd3;
    else if (d[2]) y = 2'd2;
    else if (d[1]) y = 2'd1;
    else           y = 2'd0;      // d[0] alone, or no input at all
  end

  assign valid = |d;              // reduction OR: any input active
endmodule
