`timescale 1ns/1ps
// addsub.sv -- N-bit adder-subtractor with signed overflow flag (Mano, Chapter 4)
//   m = 0: s = a + b      m = 1: s = a - b = a + ~b + 1
module addsub #(
  parameter int N = 8
) (
  input  logic [N-1:0] a, b,
  input  logic         m,          // 0 = add, 1 = subtract
  output logic [N-1:0] s,
  output logic         c,          // carry out of the MSB
  output logic         v           // signed (two's-complement) overflow
);
  logic [N:0]   carry;             // carry[i] = carry into bit i
  logic [N-1:0] bx;                // b, inverted when subtracting

  assign carry[0] = m;             // +1 for the two's complement when subtracting
  assign bx       = b ^ {N{m}};    // XOR each bit of b with m

  for (genvar i = 0; i < N; i++) begin : g_bit
    full_adder fa (.a(a[i]), .b(bx[i]), .cin(carry[i]), .sum(s[i]), .cout(carry[i+1]));
  end

  assign c = carry[N];
  assign v = carry[N];
endmodule
