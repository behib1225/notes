`timescale 1ns/1ps
module abs_sat (
  input  logic signed [7:0] x,
  output logic signed [7:0] y   // |x|, saturated to +127
);
  always_comb begin
    if (x < 8'sd0)
      y = -x;
  end
endmodule
