`timescale 1ns/1ps
// sat_add.sv -- signed W-bit adder whose result is clamped to the W-bit range
module sat_add #(
  parameter int W = 8
) (
  input  logic signed [W-1:0] a, b,
  output logic signed [W-1:0] y
);
  localparam logic signed [W-1:0] MAX = {1'b0, {(W-1){1'b1}}};   //  2^(W-1) - 1
  localparam logic signed [W-1:0] MIN = {1'b1, {(W-1){1'b0}}};   // -2^(W-1)

  logic signed [W:0] sum;                       // W+1 bits: the exact sum always fits
  assign sum = {a[W-1], a} + {b[W-1], b};       // sign-extend both, then add

  // The exact sum fits in W bits only if its top two bits are equal.
  // 01... = positive overflow, 10... = negative overflow.
  always_comb begin
    case (sum[W:W-1])
      2'b01:   y = sum[W-1:0];
      2'b10:   y = MIN;
      default: y = sum[W-1:0];
    endcase
  end
endmodule
