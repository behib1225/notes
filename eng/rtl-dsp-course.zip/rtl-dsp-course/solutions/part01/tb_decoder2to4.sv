`timescale 1ns/1ps
module tb_decoder2to4;
  logic       en;
  logic [1:0] a;
  logic [3:0] y_case, y_shift, expected;
  int errors = 0;
  decoder2to4 dut (.*);
  initial begin
    for (int i = 0; i < 8; i++) begin
      {en, a} = i[2:0];
      #10;
      expected = '0;
      if (en) expected[a] = 1'b1;          // the specification, written directly
      if (y_case !== expected || y_shift !== expected) begin
        $display("FAIL en=%b a=%0d: case=%b shift=%b expected=%b", en, a, y_case, y_shift, expected);
        errors++;
      end
    end
    if (errors == 0) $display("PASS: all 8 input combinations, both versions");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
