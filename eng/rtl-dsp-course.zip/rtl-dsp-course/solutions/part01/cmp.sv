module cmp (input logic signed [7:0] s, input logic [7:0] u, output logic b);
  assign b = (s < u);
endmodule
