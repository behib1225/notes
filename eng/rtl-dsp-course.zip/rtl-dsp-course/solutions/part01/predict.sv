module predict;
  logic [3:0] r4;  logic [4:0] r5;
  logic signed [7:0] s;  logic [7:0] u;  logic b;
  initial begin
    r4 = 4'b1010 + 4'b0111;          $display("a %b", r4);
    r5 = 4'b1010 + 4'b0111;          $display("b %b", r5);
    s  = -8'sd6;                     $display("c %0d %0d", s >>> 1, s >> 1);
    u  = 8'd1;  b = (s < u);         $display("d %b", b);
    b  = (s < $signed(u));           $display("e %b", b);
    $display("f %b %b", &4'b1111, ^4'b1011);
    $display("g %b", 4'b0100 && 4'b0010);
  end
endmodule
