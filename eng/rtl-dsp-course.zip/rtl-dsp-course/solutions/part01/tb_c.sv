module tb_c; logic [7:0] a,b,s; logic m,c,v; int e=0; addsub #(.N(8)) dut(.*);
initial begin m=1; for (int i=0;i<256;i++) for (int j=0;j<256;j++) begin a=i; b=j; #1; if (c !== (i>=j)) e++; end $display("subtract: c == (a >= b unsigned) errors: %0d", e); $finish; end endmodule
