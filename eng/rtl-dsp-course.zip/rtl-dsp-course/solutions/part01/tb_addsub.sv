`timescale 1ns/1ps
module tb_addsub;
  localparam int N = 8;
  logic [N-1:0] a, b, s;
  logic         m, c, v;
  int errors = 0, tests = 0;
  addsub #(.N(N)) dut (.*);

  task automatic check(input int ta, tb, input logic tm);
    int sa, sb, exact; logic exp_v; logic [N-1:0] exp_s;
    a = ta[N-1:0]; b = tb[N-1:0]; m = tm;
    #1;
    sa = int'($signed(a)); sb = int'($signed(b));        // the operands as signed numbers
    exact = tm ? sa - sb : sa + sb;                      // exact result in int
    exp_s = exact[N-1:0];                                // the N-bit result wraps
    exp_v = (exact > 127) || (exact < -128);             // overflow: outside -128..127
    tests++;
    if (s !== exp_s || v !== exp_v) begin
      if (errors < 5) $display("FAIL %0d %s %0d: s=%0d v=%b, expected s=%0d v=%b",
                               sa, tm ? "-" : "+", sb, $signed(s), v, $signed(exp_s), exp_v);
      errors++;
    end
  endtask

  initial begin
    for (int i = -128; i < 128; i++)                     // exhaustive: 2 x 65,536 cases
      for (int j = -128; j < 128; j++) begin
        check(i, j, 1'b0);
        check(i, j, 1'b1);
      end
    if (errors == 0) $display("PASS: %0d cases (all pairs, add and subtract)", tests);
    else             $display("FAILED: %0d of %0d", errors, tests);
    $finish;
  end
endmodule
