`timescale 1ns/1ps
module tb_prio_enc4;
  logic [3:0] d;
  logic [1:0] y, exp_y;
  logic       valid, exp_valid;
  int errors = 0;
  prio_enc4 dut (.*);
  initial begin
    for (int i = 0; i < 16; i++) begin
      d = i[3:0];
      #10;
      exp_y = 2'd0;  exp_valid = 1'b0;
      for (int k = 0; k < 4; k++)          // scan upward: the last active bit found wins
        if (d[k]) begin exp_y = k[1:0]; exp_valid = 1'b1; end
      if (y !== exp_y || valid !== exp_valid) begin
        $display("FAIL d=%b: y=%0d valid=%b, expected %0d %b", d, y, valid, exp_y, exp_valid);
        errors++;
      end
    end
    if (errors == 0) $display("PASS: all 16 inputs");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
