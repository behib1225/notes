`timescale 1ns/1ps
module abs_sat (input logic signed [7:0] x, output logic signed [7:0] y);
  always_comb begin
    if (x < 8'sd0) y = -x;
    else           y = x;
  end
endmodule
