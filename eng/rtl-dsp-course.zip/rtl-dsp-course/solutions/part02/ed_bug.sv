`timescale 1ns/1ps
// edge_detect.sv -- one-cycle pulse after each rising edge of an asynchronous input
module edge_detect (
  input  logic clk,
  input  logic rst,
  input  logic btn,        // asynchronous: may change at any time
  output logic pulse
);
  logic s1, s2, s3;        // s1, s2: two-flip-flop synchronizer; s3: previous value of s2

  always_ff @(posedge clk) begin
    if (rst) begin
      s1 <= 1'b0;  s2 <= 1'b0;  s3 <= 1'b0;
    end else begin
      s1 <= btn;           // may go metastable; never used directly
      s2 <= s1;            // safe, synchronized copy of btn
      s3 <= s2;            // the synchronized value one cycle ago
    end
  end

  assign pulse = s2;
endmodule
