`timescale 1ns/1ps
// updown_counter.sv -- W-bit counter with synchronous reset, load and up/down count
// Priority: reset, then load, then count (when en = 1). Wraps in both directions.
module updown_counter #(
  parameter int W = 8
) (
  input  logic         clk,
  input  logic         rst,
  input  logic         en,
  input  logic         up,        // 1 = count up, 0 = count down
  input  logic         load,
  input  logic [W-1:0] d,
  output logic [W-1:0] count
);
  always_ff @(posedge clk) begin
    if (rst)
      count <= '0;
    else if (load)
      count <= d;
    else if (en) begin
      if (up) count <= count + 1'b1;   // 255 + 1 wraps to 0: W-bit arithmetic
      else    count <= count - 1'b1;   // 0 - 1 wraps to 255
    end
  end
endmodule
