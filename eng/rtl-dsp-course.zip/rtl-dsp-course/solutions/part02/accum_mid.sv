`timescale 1ns/1ps
module accum #(
  parameter int W = 8
) (
  input  logic                clk, rst, en,
  input  logic [W-1:0]        x,      // signed sample -- but still declared unsigned (bug 3)
  output logic signed [W+3:0] acc
);
  always_ff @(posedge clk) begin
    if (rst) acc <= '0;
    else if (en) acc <= acc + x;
  end
endmodule
