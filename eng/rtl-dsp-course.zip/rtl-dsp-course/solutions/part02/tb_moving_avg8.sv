`timescale 1ns/1ps
module tb_moving_avg8;
  localparam int W = 16;
  logic clk = 1'b0, rst, in_valid, out_valid;
  logic signed [W-1:0] x, y;
  int hist [0:6];                    // x[n-1] .. x[n-7]
  int xi, exp_y = 0, errors = 0, checks = 0, n = 0;
  logic exp_valid = 1'b0;
  moving_avg8 #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  function automatic int pick(int n);
    if (n >= 500 && n < 540)  return -32768;           // a long run at negative full scale
    if (n >= 600 && n < 640)  return  32767;           // and at positive full scale
    return $signed(W'($urandom));
  endfunction

  initial begin
    rst = 1'b1; in_valid = 1'b0; x = '0;
    for (int k = 0; k < 7; k++) hist[k] = 0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (4000) begin
      if (y !== W'(exp_y) || out_valid !== exp_valid) begin
        if (errors < 5) $display("FAIL at %0d ns: y=%0d valid=%b, expected %0d %b", $time, y, out_valid, exp_y, exp_valid);
        errors++;
      end
      if (out_valid) checks++;
      in_valid = $urandom_range(0, 3) != 0;
      exp_valid = in_valid;
      if (in_valid) begin
        int s;
        xi = pick(n); n++;
        x = xi[W-1:0];
        s = xi;
        for (int k = 0; k < 7; k++) s += hist[k];
        exp_y = s >>> 3;                           // int arithmetic shift: same rounding as the RTL
        for (int k = 6; k > 0; k--) hist[k] = hist[k-1];
        hist[0] = xi;
      end else x = 'x;
      @(negedge clk);
    end
    if (errors == 0) $display("PASS: %0d outputs checked, including full-scale runs", checks);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
