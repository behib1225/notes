`timescale 1ns/1ps
// delay_line.sv -- y = x delayed by N samples (a sample is a cycle with en = 1)
module delay_line #(
  parameter int W = 16,
  parameter int N = 8              // N >= 1
) (
  input  logic         clk,
  input  logic         rst,
  input  logic         en,
  input  logic [W-1:0] x,
  output logic [W-1:0] y
);
  logic [W-1:0] taps [0:N-1];      // taps[k] = x delayed by k+1 samples

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else begin
      taps[0] <= x;
      for (int i = 1; i < N; i++) taps[i] <= taps[i-1];   // unrolled: N parallel registers
    end
  end

  assign y = taps[N-1];
endmodule
