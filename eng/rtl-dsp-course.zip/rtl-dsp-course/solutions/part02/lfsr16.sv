`timescale 1ns/1ps
// lfsr16.sv -- 16-bit Fibonacci LFSR, polynomial x^16 + x^14 + x^13 + x^11 + 1 (maximal length)
module lfsr16 (
  input  logic        clk,
  input  logic        rst,
  input  logic        en,
  output logic [15:0] s
);
  logic fb;
  assign fb = s[15] ^ s[13] ^ s[12] ^ s[10];     // taps 16, 14, 13, 11 (bits 15, 13, 12, 10)

  always_ff @(posedge clk) begin
    if (rst)     s <= 16'h0001;                   // any non-zero seed
    else if (en) s <= {s[14:0], fb};              // shift left, feedback into the LSB
  end
endmodule
