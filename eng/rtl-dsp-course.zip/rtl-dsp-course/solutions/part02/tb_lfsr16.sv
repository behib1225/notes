`timescale 1ns/1ps
module tb_lfsr16;
  logic clk = 1'b0, rst, en;
  logic [15:0] s;
  int steps = 0, zeros = 0, ones = 0;
  lfsr16 dut (.*);
  always #5 clk = ~clk;
  initial begin
    rst = 1'b1; en = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0; en = 1'b1;
    do begin
      @(negedge clk);
      steps++;
      if (s == 16'h0000) zeros++;
      ones += s[0];                               // count 1s in the output bit stream
    end while (s != 16'h0001 && steps < 70000);
    if (steps == 65535 && zeros == 0)
      $display("PASS: period %0d, state never zero, %0d ones and %0d zeros in the output bit", steps, ones, steps - ones);
    else
      $display("FAILED: period %0d, zero states %0d", steps, zeros);
    $finish;
  end
endmodule
