`timescale 1ns/1ps
// moving_avg8.sv -- y[n] = (x[n] + x[n-1] + ... + x[n-7]) / 8, by an arithmetic shift
// Output is registered; one cycle of latency; samples marked by in_valid.
module moving_avg8 #(
  parameter int W = 16
) (
  input  logic                clk,
  input  logic                rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,
  output logic                out_valid,
  output logic signed [W-1:0] y
);
  logic signed [W-1:0] d [1:7];                 // x[n-1] .. x[n-7]
  logic signed [W+2:0] sum;                     // W+3 bits: the sum of 8 values cannot overflow

  always_comb begin
    sum = (W+3)'(x);
    for (int k = 1; k <= 7; k++) sum += (W+3)'(d[k]);   // each operand sign-extended first
  end

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 1; k <= 7; k++) d[k] <= '0;
      y <= '0;
      out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d[1] <= x;
        for (int k = 2; k <= 7; k++) d[k] <= d[k-1];
        y <= W'(sum >>> 3);                     // divide by 8 (rounds toward minus infinity)
      end
    end
  end
endmodule
