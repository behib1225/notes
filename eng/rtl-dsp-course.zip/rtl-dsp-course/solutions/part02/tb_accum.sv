`timescale 1ns/1ps
module tb_accum;
  localparam int W = 8;
  logic clk = 1'b0, rst, en;
  logic [W-1:0] x;                              // driven as raw bits: works for both versions
  logic signed [W+3:0] acc;
  int model = 0, errors = 0;
  accum #(.W(W)) dut (.*);
  always #5 clk = ~clk;
  task automatic sample(input int v, input logic e);
    @(negedge clk);
    if (acc !== (W+4)'(model)) begin
      if (errors < 3) $display("FAIL at %0d ns: acc=%0d expected %0d", $time, acc, model);
      errors++;
    end
    x = v[W-1:0]; en = e;
    if (e) model += v;
  endtask
  initial begin
    rst = 1'b1; en = 1'b0; x = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (8) sample(-1, 1'b1);                // the test that exposes bug 3: expect -8
    sample(0, 1'b0);
    $display("after eight samples of -1: acc = %0d (expected -8)", acc);
    rst = 1'b1; @(negedge clk); rst = 1'b0; model = 0;
    repeat (16) sample(-128, 1'b1);             // the largest negative total: -2048
    repeat (16) sample(127, 1'b1);              // back up by 16 x 127
    repeat (500) begin                          // random, with a reset every 16 samples
      for (int k = 0; k < 15; k++) sample($urandom_range(0, 255) - 128, $urandom_range(0, 1));
      sample(0, 1'b0);
      rst = 1'b1; @(negedge clk); rst = 1'b0; model = 0;
    end
    sample(0, 1'b0);
    if (errors == 0) $display("PASS");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
