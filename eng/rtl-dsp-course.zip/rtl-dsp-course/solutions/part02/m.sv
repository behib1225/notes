module m; int a = -1; initial $display("-1 %% 256 in SystemVerilog = %0d", a % 256); endmodule
