`timescale 1ns/1ps
module tb_updown_counter;
  localparam int W = 8, MOD = 1 << W;
  logic clk = 1'b0, rst, en, up, load;
  logic [W-1:0] d, count;
  int model = 0, errors = 0, up_wraps = 0, down_wraps = 0;
  updown_counter #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  // apply one set of inputs at the falling edge, update the model for the next rising edge
  task automatic step(input logic ten, tup, tload, input int td);
    @(negedge clk);
    if (count !== model[W-1:0]) begin
      if (errors < 5) $display("FAIL at %0d ns: count=%0d expected %0d", $time, count, model);
      errors++;
    end
    en = ten; up = tup; load = tload; d = td[W-1:0];
    if (tload)    model = td % MOD;
    else if (ten) begin
      if (tup) begin model = model + 1; if (model == MOD) begin model = 0;       up_wraps++;   end end
      else     begin model = model - 1; if (model < 0)    begin model = MOD - 1; down_wraps++; end end
    end
  endtask

  initial begin
    rst = 1'b1; en = 0; up = 0; load = 0; d = 0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    // directed: both wrap-arounds
    step(0, 0, 1, 254);  step(1, 1, 0, 0);  step(1, 1, 0, 0);  step(1, 1, 0, 0);   // 254 255 0 1
    step(0, 0, 1, 1);    step(1, 0, 0, 0);  step(1, 0, 0, 0);  step(1, 0, 0, 0);   // 1 0 255 254
    step(1, 1, 1, 77);                                                            // load beats count
    // random
    repeat (5000) step($urandom_range(0, 1), $urandom_range(0, 1), $urandom_range(0, 19) == 0, $urandom_range(0, 255));
    step(0, 0, 0, 0);
    if (errors == 0) $display("PASS: %0d up-wraps and %0d down-wraps checked", up_wraps, down_wraps);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
