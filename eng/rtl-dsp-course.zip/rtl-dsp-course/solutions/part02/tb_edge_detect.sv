`timescale 1ns/1ps
module tb_edge_detect;
  logic clk = 1'b0, rst, btn, pulse;
  int pulses = 0, presses = 0, errors = 0;
  time t_rise, t_pulse;
  int edges_seen = 0;
  edge_detect dut (.*);
  always #5 clk = ~clk;                       // 10 ns clock

  // count pulses and check that each lasts exactly one cycle
  always @(posedge clk) if (!rst && pulse) begin
    pulses++;
    t_pulse = $time;
  end
  logic prev_pulse = 1'b0;
  always @(negedge clk) if (!rst) begin
    if (pulse && prev_pulse) begin $display("FAIL: pulse longer than one cycle at %0d ns", $time); errors++; end
    prev_pulse = pulse;
  end

  initial begin
    rst = 1'b1; btn = 1'b0;
    #23 rst = 1'b0;
    // press 1: rises off the clock grid, held for several cycles
    #37 btn = 1'b1; presses++; t_rise = $time;
    #200 btn = 1'b0;
    #63 btn = 1'b1; presses++;
    #91 btn = 1'b0;
    #47 btn = 1'b1; presses++;                // short press: 17 ns (longer than a clock period)
    #17 btn = 1'b0;
    #120;
    if (pulses == presses && errors == 0) $display("PASS: %0d presses, %0d pulses, each one cycle long", presses, pulses);
    else $display("FAILED: %0d presses, %0d pulses, %0d errors", presses, pulses, errors);
    $finish;
  end

  // latency of the first press: clock edges from btn rising until pulse rises
  initial begin
    wait (presses == 1);
    fork
      begin forever begin @(posedge clk); edges_seen++; end end
      begin @(posedge pulse); end
    join_any
    disable fork;
    $display("btn rose at %0d ns; pulse rose at %0d ns, after %0d rising clock edges", t_rise, $time, edges_seen);
  end
endmodule
