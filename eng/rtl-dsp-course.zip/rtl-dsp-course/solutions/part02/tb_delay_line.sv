`timescale 1ns/1ps
module tb_delay_line;
  localparam int W = 16;
  logic clk = 1'b0, rst, en;
  logic [W-1:0] x, y1, y2, y8;
  int hist [0:7];                  // model: hist[k] = input k+1 samples ago
  int errors = 0, samples = 0;
  delay_line #(.W(W), .N(1)) d1 (.clk(clk), .rst(rst), .en(en), .x(x), .y(y1));
  delay_line #(.W(W), .N(2)) d2 (.clk(clk), .rst(rst), .en(en), .x(x), .y(y2));
  delay_line #(.W(W), .N(8)) d8 (.clk(clk), .rst(rst), .en(en), .x(x), .y(y8));
  always #5 clk = ~clk;
  initial begin
    rst = 1'b1; en = 0; x = 0;
    for (int k = 0; k < 8; k++) hist[k] = 0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (3000) begin
      @(negedge clk);
      if (y1 !== W'(hist[0]) || y2 !== W'(hist[1]) || y8 !== W'(hist[7])) begin
        if (errors < 5) $display("FAIL at %0d ns: y1=%0d y2=%0d y8=%0d, expected %0d %0d %0d",
                                 $time, y1, y2, y8, hist[0], hist[1], hist[7]);
        errors++;
      end
      en = $urandom_range(0, 2) != 0;          // samples on about 2 cycles in 3
      x  = $urandom;
      if (en) begin                            // the model shifts only on samples
        for (int k = 7; k > 0; k--) hist[k] = hist[k-1];
        hist[0] = x;
        samples++;
      end
    end
    if (errors == 0) $display("PASS: N = 1, 2, 8 over %0d samples", samples);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
