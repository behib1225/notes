`timescale 1ns/1ps
// accum.sv -- running sum of signed W-bit samples, W+4 bits wide (up to 16 samples)
module accum #(
  parameter int W = 8
) (
  input  logic                clk, rst, en,
  input  logic signed [W-1:0] x,                // bug 3 fixed: the sample is SIGNED
  output logic signed [W+3:0] acc
);
  always_ff @(posedge clk) begin                // bug 1 fixed: edge-only sensitivity
    if (rst)     acc <= '0;                     // bug 2 fixed: non-blocking everywhere
    else if (en) acc <= acc + (W+4)'(x);        // sign-extend explicitly to the accumulator width
  end
endmodule
