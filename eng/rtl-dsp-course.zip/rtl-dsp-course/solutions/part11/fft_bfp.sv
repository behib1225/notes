`timescale 1ns/1ps
// fft_bfp.sv -- fft_n.sv with BLOCK FLOATING POINT: a stage is scaled by 1/2 only if some
// component entering it has magnitude >= T; the number of scaled stages is output as exp_o.
// True DFT = bins * 2**exp_o (in Q1.15 units). T = 0.375 guarantees that unscaled stages cannot
// overflow: an unscaled butterfly output is at most (1 + sqrt 2) times the largest component.
// Memory-based: LOAD N samples (written at bit-reversed addresses), COMPUTE log2(N) stages of
// N/2 butterflies with ONE butterfly unit (one butterfly per clock), UNLOAD N bins in order.
// A scaled butterfly computes (a +- b*w)/2, an unscaled one a +- b*w. Data and twiddles are Q1.15.
module fft_bfp #(
  parameter int N = 64, W = 16,
  parameter     TWR = "tw_re.hex", TWI = "tw_im.hex",       // twiddle files generated for this N
  parameter int T = 12288                                   // 0.375 in Q1.15
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  output logic                in_ready,
  input  logic signed [W-1:0] in_re, in_im,
  output logic                out_valid,
  output logic signed [W-1:0] out_re, out_im,
  output logic [$clog2($clog2(N)+1)-1:0] exp_o                // block exponent, valid with the bins
);
  localparam int L = $clog2(N);                  // 6 stages
  typedef enum logic [1:0] {S_LOAD, S_COMPUTE, S_UNLOAD} state_t;
  state_t state;

  logic signed [W-1:0] mem_re [0:N-1];           // the working memory, updated in place
  logic signed [W-1:0] mem_im [0:N-1];
  logic signed [W-1:0] tw_re  [0:N/2-1];         // twiddle ROM: exp(-j 2 pi k / N)
  logic signed [W-1:0] tw_im  [0:N/2-1];
  initial begin
    $readmemh(TWR, tw_re);
    $readmemh(TWI, tw_im);
  end

  logic [L-1:0]         cnt;                     // sample counter (LOAD, UNLOAD)
  logic [$clog2(L)-1:0] stage;                   // 0 .. L-1
  logic [L-2:0]         bfly;                    // butterfly within the stage, 0 .. N/2-1

  // bit reversal of the load address
  function automatic logic [L-1:0] rev(input logic [L-1:0] a);
    for (int b = 0; b < L; b++) rev[b] = a[L-1-b];
  endfunction

  logic [L-1:0] load_addr;
  assign load_addr = rev(cnt);                   // bit-reversed load address

  // ---- address generation for butterfly 'bfly' of stage 'stage' ----
  logic [L-1:0] ia, ja;                          // the two memory addresses
  logic [L-2:0] tk;                              // twiddle index
  always_comb begin
    logic [L-1:0] span, pos, grp;
    span = L'(1) << stage;
    pos  = L'(bfly) & (span - 1'b1);
    grp  = L'(bfly) >> stage;
    ia   = (grp << (stage + 1)) | pos;           // grp * 2 * span + pos
    ja   = ia | span;                            // ia + span
    tk   = (L-1)'(pos << (L - 1 - 32'(stage)));
  end

  // ---- the butterfly: (a +- b*w) / 2, exact products, one rounding each ----
  localparam int PW = 2 * W + 2;                 // product sum width with headroom
  logic signed [PW-1:0] tr, ti, ur, ui;
  logic signed [W-1:0]  yr0, yi0, yr1, yi1;
  logic                 ovf0, ovf1, ovf2, ovf3;   // unused overflow flags
  assign tr = PW'(mem_re[ja] * tw_re[tk]) - PW'(mem_im[ja] * tw_im[tk]);   // Q.30
  assign ti = PW'(mem_re[ja] * tw_im[tk]) + PW'(mem_im[ja] * tw_re[tk]);
  assign ur = PW'(mem_re[ia]) <<< (W - 1);                                  // a in Q.30
  assign ui = PW'(mem_im[ia]) <<< (W - 1);
  // dropping 16 fractional bits from Q.30 both returns to Q1.15 and divides by 2
  requant #(.IN_W(PW), .IN_F(2*W - 1), .OUT_W(W), .OUT_F(W - 1), .RND(1), .SAT(1'b1))
    q0 (.din(ur + tr), .dout(yr0), .ovf(ovf0)),
    q1 (.din(ui + ti), .dout(yi0), .ovf(ovf1)),
    q2 (.din(ur - tr), .dout(yr1), .ovf(ovf2)),
    q3 (.din(ui - ti), .dout(yi1), .ovf(ovf3));

  // the same sums rounded WITHOUT the halving: drop 15 bits instead of 16
  logic signed [W-1:0] zr0, zi0, zr1, zi1;
  logic                ovf4, ovf5, ovf6, ovf7;
  requant #(.IN_W(PW), .IN_F(2*W - 2), .OUT_W(W), .OUT_F(W - 1), .RND(1), .SAT(1'b1))
    p0 (.din(ur + tr), .dout(zr0), .ovf(ovf4)),
    p1 (.din(ui + ti), .dout(zi0), .ovf(ovf5)),
    p2 (.din(ur - tr), .dout(zr1), .ovf(ovf6)),
    p3 (.din(ui - ti), .dout(zi1), .ovf(ovf7));
  wire unused_ovf = ovf0 | ovf1 | ovf2 | ovf3 | ovf4 | ovf5 | ovf6 | ovf7;

  // block floating point: scale this stage? (decided from the values that entered it)
  logic scale, flag;                             // flag: some value written so far is >= T
  logic signed [W-1:0] br0, bi0, br1, bi1;       // the butterfly results actually written
  assign br0 = scale ? yr0 : zr0;  assign bi0 = scale ? yi0 : zi0;
  assign br1 = scale ? yr1 : zr1;  assign bi1 = scale ? yi1 : zi1;
  function automatic logic big(input logic signed [W-1:0] v);
    big = (v >= W'(T)) || (v <= -W'(T));
  endfunction

  assign in_ready = (state == S_LOAD);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_LOAD;  cnt <= '0;  stage <= '0;  bfly <= '0;  out_valid <= 1'b0;
      flag <= 1'b0;  scale <= 1'b0;  exp_o <= '0;
    end else begin
      out_valid <= 1'b0;
      case (state)
        S_LOAD: if (in_valid) begin
          mem_re[load_addr] <= in_re;              // bit-reversed write: input reordering is free
          mem_im[load_addr] <= in_im;
          cnt <= cnt + 1'b1;
          if (cnt == '0) exp_o <= '0;              // a new block: reset the exponent
          if (cnt == L'(N - 1)) begin              // the first stage is scaled if any input is big
            scale <= flag || big(in_re) || big(in_im);
            flag  <= 1'b0;
            state <= S_COMPUTE;
          end else begin
            flag  <= (cnt == '0 ? 1'b0 : flag) || big(in_re) || big(in_im);
          end
        end
        S_COMPUTE: begin                           // one butterfly per clock, in place
          mem_re[ia] <= br0;  mem_im[ia] <= bi0;
          mem_re[ja] <= br1;  mem_im[ja] <= bi1;
          bfly <= bfly + 1'b1;
          if (bfly == '1) begin                    // last butterfly of this stage
            exp_o <= exp_o + $bits(exp_o)'(scale);
            scale <= flag || big(br0) || big(bi0) || big(br1) || big(bi1);   // decides the next stage
            flag  <= 1'b0;
            if (stage == ($clog2(L))'(L - 1)) begin stage <= '0; state <= S_UNLOAD; end
            else stage <= stage + 1'b1;
          end else begin
            flag <= flag || big(br0) || big(bi0) || big(br1) || big(bi1);
          end
        end
        S_UNLOAD: begin                            // bins 0 .. N-1 in natural order
          out_valid <= 1'b1;
          out_re <= mem_re[cnt];  out_im <= mem_im[cnt];
          cnt <= cnt + 1'b1;
          if (cnt == L'(N - 1)) state <= S_LOAD;
        end
        default: state <= S_LOAD;
      endcase
    end
  end
endmodule
