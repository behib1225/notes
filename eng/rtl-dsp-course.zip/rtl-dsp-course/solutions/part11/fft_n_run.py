#!/usr/bin/env python3
"""fft_n_run.py -- twiddle files, test blocks and the bit-exact check for fft_n.sv at any N."""
import subprocess, sys
import numpy as np
from fft_model import fft_fixed, twiddles
from fixedpoint import quantize

def make_blocks(N, nblk, seed=1):
    rng = np.random.default_rng(seed); n = np.arange(N); out = []
    for b in range(nblk):
        kind = b % 4
        if kind == 0:   x = 0.7 * np.exp(2j * np.pi * (N // 8 + 1) * n / N)
        elif kind == 1: x = 0.5 * np.cos(2 * np.pi * (N / 6 + 0.5) * n / N) + 0.2j * np.sin(2 * np.pi * 3 * n / N)
        elif kind == 2: x = np.zeros(N, complex); x[0] = 0.99
        else:           x = rng.uniform(-0.5, 0.5, N) + 1j * rng.uniform(-0.5, 0.5, N)
        out.append((quantize(x.real, 16, 15), quantize(x.imag, 16, 15)))
    return out

def write_twiddles(N):
    wr, wi = twiddles(N)
    open("tw_re.hex", "w").write("\n".join(f"{int(v) & 0xffff:04x}" for v in wr) + "\n")
    open("tw_im.hex", "w").write("\n".join(f"{int(v) & 0xffff:04x}" for v in wi) + "\n")

def run(N, nblk=8, blocks=None):
    write_twiddles(N)
    blocks = blocks or make_blocks(N, nblk)
    nblk = len(blocks)
    with open("fft_in.txt", "w") as f:
        for xr, xi in blocks:
            for a, b in zip(xr, xi): f.write(f"{a} {b}\n")
    subprocess.run(["iverilog", "-g2012", "-Wall", f"-DNPT={N}", "-o", f"sim{N}", "fft_n.sv", "requant.sv", "tb_fft_n.sv"], check=True)
    r = subprocess.run(["vvp", "-n", f"sim{N}", f"+BLOCKS={nblk}"], capture_output=True, text=True, check=True)
    rtl = np.loadtxt("fft_out.txt", dtype=np.int64).reshape(nblk, N, 2)
    ok, err = True, 0.0
    for b, (xr, xi) in enumerate(blocks):
        mr, mi = fft_fixed(xr, xi, N)
        ok &= np.array_equal(rtl[b, :, 0], mr) and np.array_equal(rtl[b, :, 1], mi)
        ref = np.fft.fft((xr + 1j * xi) / 32768.0) / N
        err = max(err, np.max(np.abs((rtl[b, :, 0] + 1j * rtl[b, :, 1]) / 32768.0 - ref)) * 32768)
    return ok, err, r.stdout.strip(), blocks, rtl

if __name__ == "__main__":
    for N in [int(a) for a in sys.argv[1:]] or [8, 64, 256]:
        ok, err, msg, _, _ = run(N)
        print(f"N = {N:4d}: {'PASS' if ok else 'FAIL'} bit-exact, max error vs np.fft/N {err:.2f} LSB; {msg}")
