`timescale 1ns/1ps
// fft_bram.sv -- fft_n.sv restructured so its working memory maps onto block RAM:
// one memory of N words {re, im} with TWO ports, each doing one synchronous access per cycle.
// A butterfly takes two cycles: read a and b (ports A and B), then write both results.
// Bit-exact with fft_n.sv. Cycles per transform: N (load) + N*log2(N) (compute) + N (unload).
module fft_bram #(
  parameter int N = 64, W = 16,
  parameter     TWR = "tw_re.hex", TWI = "tw_im.hex"
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  output logic                in_ready,
  input  logic signed [W-1:0] in_re, in_im,
  output logic                out_valid,
  output logic signed [W-1:0] out_re, out_im
);
  localparam int L = $clog2(N);
  typedef enum logic [1:0] {S_LOAD, S_COMPUTE, S_UNLOAD} state_t;
  state_t state;

  logic [2*W-1:0]      mem [0:N-1];              // {re, im}: no reset, two ports -> block RAM
  logic signed [W-1:0] tw_re [0:N/2-1];
  logic signed [W-1:0] tw_im [0:N/2-1];
  initial begin
    $readmemh(TWR, tw_re);
    $readmemh(TWI, tw_im);
  end

  logic [L-1:0]         cnt;
  logic [$clog2(L)-1:0] stage;
  logic [L-2:0]         bfly;
  logic                 ph;                      // COMPUTE: 0 = read, 1 = write

  function automatic logic [L-1:0] rev(input logic [L-1:0] a);
    for (int b = 0; b < L; b++) rev[b] = a[L-1-b];
  endfunction
  logic [L-1:0] load_addr;
  assign load_addr = rev(cnt);

  logic [L-1:0] ia, ja;
  logic [L-2:0] tk;
  always_comb begin
    logic [L-1:0] span, pos, grp;
    span = L'(1) << stage;
    pos  = L'(bfly) & (span - 1'b1);
    grp  = L'(bfly) >> stage;
    ia   = (grp << (stage + 1)) | pos;
    ja   = ia | span;
    tk   = (L-1)'(pos << (L - 1 - 32'(stage)));
  end

  // ---- the two memory ports ----
  logic [L-1:0]   addr_a, addr_b;
  logic           we_a, we_b;
  logic [2*W-1:0] wd_a, wd_b, rd_a, rd_b;
  always_ff @(posedge clk) begin                 // port A
    if (we_a) mem[addr_a] <= wd_a;
    rd_a <= mem[addr_a];
  end
  always_ff @(posedge clk) begin                 // port B
    if (we_b) mem[addr_b] <= wd_b;
    rd_b <= mem[addr_b];
  end

  // ---- the butterfly, from the registered read data ----
  logic signed [W-1:0] ar, ai, br, bi;
  assign {ar, ai} = rd_a;
  assign {br, bi} = rd_b;
  localparam int PW = 2 * W + 2;
  logic signed [PW-1:0] tr, ti, ur, ui;
  logic signed [W-1:0]  yr0, yi0, yr1, yi1;
  logic                 ovf0, ovf1, ovf2, ovf3;
  assign tr = PW'(br * tw_re[tk]) - PW'(bi * tw_im[tk]);
  assign ti = PW'(br * tw_im[tk]) + PW'(bi * tw_re[tk]);
  assign ur = PW'(ar) <<< (W - 1);
  assign ui = PW'(ai) <<< (W - 1);
  requant #(.IN_W(PW), .IN_F(2*W - 1), .OUT_W(W), .OUT_F(W - 1), .RND(1), .SAT(1'b1))
    q0 (.din(ur + tr), .dout(yr0), .ovf(ovf0)),
    q1 (.din(ui + ti), .dout(yi0), .ovf(ovf1)),
    q2 (.din(ur - tr), .dout(yr1), .ovf(ovf2)),
    q3 (.din(ui - ti), .dout(yi1), .ovf(ovf3));
  wire unused_ovf = ovf0 | ovf1 | ovf2 | ovf3;

  // ---- port control ----
  always_comb begin
    addr_a = ia;  addr_b = ja;  we_a = 1'b0;  we_b = 1'b0;
    wd_a = {yr0, yi0};  wd_b = {yr1, yi1};
    case (state)
      S_LOAD:    begin addr_a = load_addr; wd_a = {in_re, in_im}; we_a = in_valid; end
      S_COMPUTE: begin we_a = ph; we_b = ph; end          // write both results in the second cycle
      S_UNLOAD:  addr_a = cnt;                             // read; the data arrives a cycle later
      default:   ;
    endcase
  end

  assign in_ready = (state == S_LOAD);
  assign {out_re, out_im} = rd_a;

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_LOAD;  cnt <= '0;  stage <= '0;  bfly <= '0;  ph <= 1'b0;  out_valid <= 1'b0;
    end else begin
      out_valid <= (state == S_UNLOAD);                    // rd_a now holds bin cnt-1
      case (state)
        S_LOAD: if (in_valid) begin
          cnt <= cnt + 1'b1;
          if (cnt == L'(N - 1)) state <= S_COMPUTE;
        end
        S_COMPUTE: begin
          ph <= ~ph;
          if (ph) begin                                    // a butterfly completes
            bfly <= bfly + 1'b1;
            if (bfly == '1) begin
              if (stage == ($clog2(L))'(L - 1)) begin stage <= '0; state <= S_UNLOAD; end
              else stage <= stage + 1'b1;
            end
          end
        end
        S_UNLOAD: begin
          cnt <= cnt + 1'b1;
          if (cnt == L'(N - 1)) state <= S_LOAD;
        end
        default: state <= S_LOAD;
      endcase
    end
  end
endmodule
