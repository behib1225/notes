`timescale 1ns/1ps
// tb_fft_n.sv -- tb_fft.sv for any N (-DNPT=...): blocks of N complex samples in, N bins out
`ifndef NPT
  `define NPT 64
`endif
module tb_fft_bfp;
  localparam int N = `NPT;
  logic clk = 1'b0, rst, in_valid, in_ready, out_valid;
  logic signed [15:0] in_re, in_im, out_re, out_im;
  logic [2:0] exp_o;
  int fi, fo, code = 2, rr, ri, got = 0, nblk = 1, cycles = 0;
  fft_bfp #(.N(N)) dut (.*);
  always #5 clk = ~clk;
  always @(posedge clk) cycles++;
  initial begin #500_000_000; $fatal(1, "TIMEOUT"); end
  initial begin
    void'($value$plusargs("BLOCKS=%d", nblk));
    fi = $fopen("fft_in.txt", "r"); fo = $fopen("fft_out.txt", "w");
    rst = 1'b1; in_valid = 1'b0; in_re = '0; in_im = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    while (code == 2) begin
      if (!in_valid && $urandom_range(0, 3) != 0) begin
        code = $fscanf(fi, "%d %d\n", rr, ri);
        in_valid = (code == 2); in_re = rr; in_im = ri;
      end
      @(posedge clk);
      if (in_valid && in_ready) begin @(negedge clk); in_valid = 1'b0; end
      else @(negedge clk);
    end
  end
  always @(negedge clk) if (!rst && out_valid) begin
    $fdisplay(fo, "%0d %0d %0d", out_re, out_im, exp_o);
    if (++got == N * nblk) begin
      $fclose(fo);
      $display("%0d bins from %0d blocks, %0d clock cycles", got, nblk, cycles);
      $finish;
    end
  end
endmodule
