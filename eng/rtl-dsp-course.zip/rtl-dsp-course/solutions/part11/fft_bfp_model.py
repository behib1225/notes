#!/usr/bin/env python3
"""fft_bfp_model.py -- bit-exact model of fft_bfp.sv: block floating point.
A stage is scaled by 1/2 only if some component entering it has magnitude >= T;
the number of scaled stages is the block exponent: true DFT/N ~ bins * 2**exp / N."""
import numpy as np
from fft_model import bit_reverse, twiddles
from fixedpoint import requant

def fft_bfp(xr, xi, N=64, T=12288):
    L = N.bit_length() - 1
    wr, wi = twiddles(N)
    ar = [int(xr[bit_reverse(i, L)]) for i in range(N)]
    ai = [int(xi[bit_reverse(i, L)]) for i in range(N)]
    big = lambda v: v >= T or v <= -T
    flag = any(big(v) for v in ar + ai)                  # checked while loading
    exp, nsat = 0, 0
    for s in range(L):
        scale, flag = flag, False
        F = 31 if scale else 30                          # 31: drop 16 bits = /2;  30: drop 15 bits
        def rq(v):
            nonlocal nsat
            r = int(requant(np.array([v]), F, 16, 15, "round", "wrap")[0])
            q = int(requant(np.array([v]), F, 16, 15, "round", "saturate")[0])
            nsat += (r != q)
            return q
        span = 1 << s
        for b in range(N // 2):
            grp, pos = b >> s, b & (span - 1)
            i = grp * 2 * span + pos; j = i + span; k = pos << (L - 1 - s)
            tr = ar[j] * int(wr[k]) - ai[j] * int(wi[k])
            ti = ar[j] * int(wi[k]) + ai[j] * int(wr[k])
            ur, ui = ar[i] << 15, ai[i] << 15
            ar[i], ai[i], ar[j], ai[j] = rq(ur + tr), rq(ui + ti), rq(ur - tr), rq(ui - ti)
            flag |= big(ar[i]) or big(ai[i]) or big(ar[j]) or big(ai[j])
        exp += scale
    return np.array(ar), np.array(ai), exp, nsat
