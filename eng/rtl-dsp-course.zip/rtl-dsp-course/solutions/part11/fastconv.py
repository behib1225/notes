#!/usr/bin/env python3
"""fastconv.py -- overlap-add fast convolution with fft_iter, and the multiplication count."""
import numpy as np
from scipy.signal import firwin
from fft_model import fft_iter

def ifft_iter(X):
    """Inverse FFT through the forward one: ifft(X) = conj(fft(conj(X))) / N."""
    return np.conj(fft_iter(np.conj(X))) / len(X)

def overlap_add(x, h, N=64):
    M = len(h); B = N - M + 1                        # block length: B + M - 1 = N, no wrap-around
    H = fft_iter(np.r_[h, np.zeros(N - M)])          # computed once
    y = np.zeros(len(x) + M - 1, dtype=complex)
    for start in range(0, len(x), B):
        blk = x[start:start + B]
        Y = ifft_iter(fft_iter(np.r_[blk, np.zeros(N - len(blk))]) * H)
        n = min(N, len(y) - start)
        y[start:start + n] += Y[:n]                  # the tails overlap and add
    return y.real

def cost_fft(M, N):
    """Real multiplications per output: two N-point FFTs ((N/2) log2 N complex products each)
    plus N spectrum products; 4 real multiplications per complex one."""
    B = N - M + 1
    return 4 * (N * np.log2(N) + N) / B

if __name__ == "__main__":
    h = firwin(32, 0.2)
    x = np.random.default_rng(3).standard_normal(5000)
    y = overlap_add(x, h, 64)
    ref = np.convolve(x, h)
    print(f"overlap-add (blocks of {64 - 32 + 1}, 64-point FFTs) vs np.convolve: max difference {np.max(np.abs(y - ref)):.2e}"
          f" (signal rms {np.sqrt(np.mean(ref**2)):.3f}), {int(np.ceil(5000/33))} blocks")
    for M in (32, 1000):
        rows = [(N, cost_fft(M, N)) for N in (2 ** k for k in range(int(np.ceil(np.log2(M + 1))), 17))]
        bestN, best = min(rows, key=lambda r: r[1])
        print(f"M = {M}: direct {M} per output; FFT: " + ", ".join(f"N={N}: {c:.1f}" for N, c in rows[:5]) + f"; best N = {bestN}: {best:.1f}")
    for M in range(8, 400):
        best = min(cost_fft(M, 2 ** k) for k in range(int(np.ceil(np.log2(M + 1))), 18))
        if best < M:
            print(f"crossover: the FFT method is cheaper from M = {M} taps ({best:.1f} vs {M} real multiplications per output)"); break
    for M in range(8, 400):     # with real-input savings (about half), for comparison
        best = min(cost_fft(M, 2 ** k) / 2 for k in range(int(np.ceil(np.log2(M + 1))), 18))
        if best < M:
            print(f"   (with real-signal FFT tricks, about half the work: from M = {M})"); break
