#!/usr/bin/env python3
"""fft_model.py -- DFT, radix-2 FFT in floating point, and the bit-exact fixed-point model of fft64.sv."""
import numpy as np
from fixedpoint import requant

def dft(x):
    """The definition: X[k] = sum_n x[n] exp(-j 2 pi k n / N). N*N complex multiplications."""
    x = np.asarray(x, dtype=complex); N = len(x); n = np.arange(N)
    return np.array([np.sum(x * np.exp(-2j * np.pi * k * n / N)) for k in range(N)])

def bit_reverse(i, bits):
    return int(f"{i:0{bits}b}"[::-1], 2)

def fft_iter(x):
    """Radix-2 decimation-in-time FFT, in place: bit-reversed input order, log2(N) stages."""
    x = np.asarray(x, dtype=complex); N = len(x); L = N.bit_length() - 1
    a = np.array([x[bit_reverse(i, L)] for i in range(N)])
    for s in range(L):
        span = 1 << s
        for b in range(N // 2):                       # N/2 butterflies per stage
            grp, pos = b >> s, b & (span - 1)
            i = grp * 2 * span + pos; j = i + span
            w = np.exp(-2j * np.pi * (pos << (L - 1 - s)) / N)
            t = a[j] * w
            a[i], a[j] = a[i] + t, a[i] - t           # the butterfly
    return a

# ---------------- fixed point (matches fft64.sv) ----------------
N_FFT, W, TW = 64, 16, 16                             # points, data bits (Q1.15), twiddle bits (Q1.15)

def twiddles(N=N_FFT, tw=TW):
    k = np.arange(N // 2); amp = (1 << (tw - 1)) - 1  # 32767: +1.0 is not representable
    return (np.round(amp * np.cos(2 * np.pi * k / N)).astype(np.int64),
            np.round(-amp * np.sin(2 * np.pi * k / N)).astype(np.int64))

def fft_fixed(xr, xi, N=N_FFT):
    """Bit-exact model: each butterfly computes (a + b*w)/2 and (a - b*w)/2 exactly,
    then rounds once to Q1.15 and saturates. Output = DFT / N."""
    L = N.bit_length() - 1
    wr, wi = twiddles(N)
    ar = [int(xr[bit_reverse(i, L)]) for i in range(N)]
    ai = [int(xi[bit_reverse(i, L)]) for i in range(N)]
    rq = lambda v: int(requant(np.array([v]), 31, W, 15, "round", "saturate")[0])  # Q?.30 sum /2 -> Q1.15
    for s in range(L):
        span = 1 << s
        for b in range(N // 2):
            grp, pos = b >> s, b & (span - 1)
            i = grp * 2 * span + pos; j = i + span; k = pos << (L - 1 - s)
            tr = ar[j] * int(wr[k]) - ai[j] * int(wi[k])          # Q2.30, exact
            ti = ar[j] * int(wi[k]) + ai[j] * int(wr[k])
            ur, ui = ar[i] << 15, ai[i] << 15                     # a in Q?.30
            ar[i], ai[i], ar[j], ai[j] = rq(ur + tr), rq(ui + ti), rq(ur - tr), rq(ui - ti)
    return np.array(ar), np.array(ai)
