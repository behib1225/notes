`timescale 1ns/1ps
// fft64.sv -- 64-point radix-2 decimation-in-time FFT processor.
// Memory-based: LOAD 64 samples (written at bit-reversed addresses), COMPUTE 6 stages of
// 32 butterflies with ONE butterfly unit (one butterfly per clock), UNLOAD 64 bins in order.
// Each butterfly scales by 1/2, so the output is DFT/64. Data and twiddles are Q1.15.
module fft64 #(
  parameter int N = 64, W = 16
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  output logic                in_ready,
  input  logic signed [W-1:0] in_re, in_im,
  output logic                out_valid,
  output logic signed [W-1:0] out_re, out_im
);
  localparam int L = $clog2(N);                  // 6 stages
  typedef enum logic [1:0] {S_LOAD, S_COMPUTE, S_UNLOAD} state_t;
  state_t state;

  logic signed [W-1:0] mem_re [0:N-1];           // the working memory, updated in place
  logic signed [W-1:0] mem_im [0:N-1];
  logic signed [W-1:0] tw_re  [0:N/2-1];         // twiddle ROM: exp(-j 2 pi k / N)
  logic signed [W-1:0] tw_im  [0:N/2-1];
  initial begin
    $readmemh("tw_re.hex", tw_re);
    $readmemh("tw_im.hex", tw_im);
  end

  logic [L-1:0]         cnt;                     // sample counter (LOAD, UNLOAD)
  logic [$clog2(L)-1:0] stage;                   // 0 .. L-1
  logic [L-2:0]         bfly;                    // butterfly within the stage, 0 .. N/2-1

  // bit reversal of the load address
  function automatic logic [L-1:0] rev(input logic [L-1:0] a);
    for (int b = 0; b < L; b++) rev[b] = a[L-1-b];
  endfunction

  logic [L-1:0] load_addr;
  assign load_addr = rev(cnt);                   // bit-reversed load address

  // ---- address generation for butterfly 'bfly' of stage 'stage' ----
  logic [L-1:0] ia, ja;                          // the two memory addresses
  logic [L-2:0] tk;                              // twiddle index
  always_comb begin
    logic [L-1:0] span, pos, grp;
    span = L'(1) << stage;
    pos  = L'(bfly) & (span - 1'b1);
    grp  = L'(bfly) >> stage;
    ia   = (grp << (stage + 1)) | pos;           // grp * 2 * span + pos
    ja   = ia | span;                            // ia + span
    tk   = (L-1)'(pos << (L - 1 - 32'(stage)));
  end

  // ---- the butterfly: (a +- b*w) / 2, exact products, one rounding each ----
  localparam int PW = 2 * W + 2;                 // product sum width with headroom
  logic signed [PW-1:0] tr, ti, ur, ui;
  logic signed [W-1:0]  yr0, yi0, yr1, yi1;
  logic                 ovf0, ovf1, ovf2, ovf3;   // unused overflow flags
  assign tr = PW'(mem_re[ja] * tw_re[tk]) - PW'(mem_im[ja] * tw_im[tk]);   // Q.30
  assign ti = PW'(mem_re[ja] * tw_im[tk]) + PW'(mem_im[ja] * tw_re[tk]);
  assign ur = PW'(mem_re[ia]) <<< (W - 1);                                  // a in Q.30
  assign ui = PW'(mem_im[ia]) <<< (W - 1);
  // dropping 16 fractional bits from Q.30 both returns to Q1.15 and divides by 2
  requant #(.IN_W(PW), .IN_F(2*W - 1), .OUT_W(W), .OUT_F(W - 1), .RND(1), .SAT(1'b1))
    q0 (.din(ur + tr), .dout(yr0), .ovf(ovf0)),
    q1 (.din(ui + ti), .dout(yi0), .ovf(ovf1)),
    q2 (.din(ur - tr), .dout(yr1), .ovf(ovf2)),
    q3 (.din(ui - ti), .dout(yi1), .ovf(ovf3));

  wire unused_ovf = ovf0 | ovf1 | ovf2 | ovf3;

  assign in_ready = (state == S_LOAD);

  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_LOAD;  cnt <= '0;  stage <= '0;  bfly <= '0;  out_valid <= 1'b0;
    end else begin
      out_valid <= 1'b0;
      case (state)
        S_LOAD: if (in_valid) begin
          mem_re[load_addr] <= in_re;              // bit-reversed write: input reordering is free
          mem_im[load_addr] <= in_im;
          cnt <= cnt + 1'b1;
          if (cnt == L'(N - 1)) state <= S_COMPUTE;
        end
        S_COMPUTE: begin                           // one butterfly per clock, in place
          mem_re[ia] <= yr0;  mem_im[ia] <= yi0;
          mem_re[ja] <= yr1;  mem_im[ja] <= yi1;
          bfly <= bfly + 1'b1;
          if (bfly == '1) begin                    // last butterfly of this stage
            if (stage == ($clog2(L))'(L - 1)) begin stage <= '0; state <= S_UNLOAD; end
            else stage <= stage + 1'b1;
          end
        end
        S_UNLOAD: begin                            // bins 0 .. N-1 in natural order
          out_valid <= 1'b1;
          out_re <= mem_re[cnt];  out_im <= mem_im[cnt];
          cnt <= cnt + 1'b1;
          if (cnt == L'(N - 1)) state <= S_LOAD;
        end
        default: state <= S_LOAD;
      endcase
    end
  end
endmodule
