#!/usr/bin/env python3
"""spectrum.py -- a calibrated spectrum analyzer built on fft_iter (Part 11), not np.fft."""
import numpy as np
from fft_model import fft_iter

def spectrum(x, fs=1.0, window="rect", full_scale=1.0):
    """Return (frequencies, magnitude in dBFS) for a real signal x (length a power of two).
    0 dBFS = a sine of amplitude full_scale exactly on a bin."""
    x = np.asarray(x, dtype=float); N = len(x)
    w = {"rect": np.ones(N),
         "hann": np.hanning(N + 1)[:-1],                                  # periodic Hann
         "blackmanharris": None}[window]
    if w is None:
        n = np.arange(N); a = [0.35875, 0.48829, 0.14128, 0.01168]
        w = a[0] - a[1]*np.cos(2*np.pi*n/N) + a[2]*np.cos(4*np.pi*n/N) - a[3]*np.cos(6*np.pi*n/N)
    cg = np.mean(w)                                                       # coherent gain
    X = fft_iter(x * w)[: N // 2 + 1]
    mag = 2 * np.abs(X) / (N * cg * full_scale)                           # amplitude of each sine
    mag[0] /= 2                                                           # DC has no mirror
    return np.arange(N // 2 + 1) * fs / N, 20 * np.log10(mag + 1e-300)

if __name__ == "__main__":
    N = 1024; n = np.arange(N)
    for win in ("rect", "hann", "blackmanharris"):
        f, db = spectrum(np.sin(2 * np.pi * 37 * n / N), window=win)
        w = {"rect": np.ones(N), "hann": np.hanning(N + 1)[:-1]}.get(win)
        print(f"{win:15s}: full-scale sine on bin 37 reads {db[37]:+.4f} dBFS")
    # agreement with np.fft
    from fft_model import fft_iter as fi
    x = np.random.default_rng(1).standard_normal(N)
    print("fft_iter vs np.fft max difference:", np.max(np.abs(fi(x) - np.fft.fft(x))))
