#!/usr/bin/env python3
"""check_fft.py -- make test blocks, or check fft_out.txt bit-exactly and against np.fft."""
import sys
import numpy as np
from fft_model import fft_fixed
from fixedpoint import quantize

def make_blocks(nblk, seed=1):
    rng = np.random.default_rng(seed); n = np.arange(64); blocks = []
    for b in range(nblk):
        kind = b % 4
        if kind == 0:   x = 0.7 * np.exp(2j * np.pi * 5 * n / 64)                     # one complex tone on bin 5
        elif kind == 1: x = 0.5 * np.cos(2 * np.pi * 10.5 * n / 64) + 0.2j * np.sin(2 * np.pi * 3 * n / 64)
        elif kind == 2: x = np.zeros(64, complex); x[0] = 0.99                         # impulse: flat spectrum
        else:           x = (rng.uniform(-0.5, 0.5, 64) + 1j * rng.uniform(-0.5, 0.5, 64))
        blocks.append((quantize(x.real, 16, 15), quantize(x.imag, 16, 15)))
    return blocks

if __name__ == "__main__":
    nblk = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    blocks = make_blocks(nblk)
    if sys.argv[1] == "make":
        with open("fft_in.txt", "w") as f:
            for xr, xi in blocks:
                for a, b in zip(xr, xi): f.write(f"{a} {b}\n")
        sys.exit(0)
    rtl = np.loadtxt("fft_out.txt", dtype=np.int64).reshape(nblk, 64, 2)
    ok = True; errs = []
    for b, (xr, xi) in enumerate(blocks):
        mr, mi = fft_fixed(xr, xi)
        ok &= np.array_equal(rtl[b, :, 0], mr) and np.array_equal(rtl[b, :, 1], mi)
        ref = np.fft.fft((xr + 1j * xi) / 32768.0) / 64                              # ideal, same input
        got = (rtl[b, :, 0] + 1j * rtl[b, :, 1]) / 32768.0
        errs.append(np.max(np.abs(got - ref)) * 32768)
    print(f"{'PASS' if ok else 'FAIL'}: {nblk} blocks bit-exact; max error vs np.fft/64: {max(errs):.2f} LSB")
    sys.exit(0 if ok else 1)
