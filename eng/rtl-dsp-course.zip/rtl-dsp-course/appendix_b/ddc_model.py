#!/usr/bin/env python3
"""ddc_model.py -- design and bit-exact model of the DDC:
real input (Q1.15, 20 MS/s) -> mixer (NCO at -f_LO) -> CIC R=8, N=5 on I and Q (2.5 MS/s)
-> compensating FIR, 32 taps, decimate by 2 on I and Q (1.25 MS/s complex output)."""
import argparse
import numpy as np
from scipy import signal
from fixedpoint import quantize, requant
from dds_model import nco, fcw_for
from decim_model import cic_decim_golden
import fir_model                               # reuse golden() and to_hex() from Part 7

FS_IN, R, N_CIC, M_FIR, N_TAPS = 20e6, 8, 5, 2, 31
F_PASS = 0.4e6                                 # passband edge of the complex output: +-0.4 MHz
FS_CIC = FS_IN / R                             # 2.5 MS/s between CIC and FIR

def cic_response(f_in):
    """CIC magnitude at f_in cycles per INPUT sample."""
    f = np.where(np.asarray(f_in, float) == 0, 1e-12, f_in)
    return np.abs(np.sin(np.pi * f * R) / (R * np.sin(np.pi * f))) ** N_CIC

def design_fir():
    """Compensation FIR at the CIC output rate, by least squares (scipy.signal.firls):
    the inverse of the CIC droop across the passband (piecewise linear), zero in the stopband."""
    fp = F_PASS / FS_CIC                       # 0.16 cycles/sample
    fs = (FS_CIC / M_FIR - F_PASS) / FS_CIC    # 0.34: first frequency that aliases into the passband
    edges = np.linspace(0, fp, 9)
    bands, desired = [], []
    for a, b in zip(edges[:-1], edges[1:]):    # 8 passband segments following 1/|H_cic|
        bands += [a, b]
        desired += [1 / cic_response(a / R), 1 / cic_response(b / R)]
    bands += [fs, 0.5]; desired += [0, 0]
    return signal.firls(N_TAPS, bands, desired, weight=[1] * 8 + [30], fs=1.0)

def coefficients():
    return quantize(design_fir(), 18, 17)       # Q1.17, as in Part 7

def golden(x, fcw):
    """Bit-exact model of ddc.sv, block by block, exactly as the RTL computes it."""
    x = np.asarray(x, dtype=np.int64)
    c, s = nco(fcw, len(x))                                      # Part 9 NCO
    i = requant(x * c, 30, 16, 15, "round", "saturate")         # Part 9 mixer
    q = requant(-(x * s), 30, 16, 15, "round", "saturate")
    i, q = cic_decim_golden(i, R, N_CIC), cic_decim_golden(q, R, N_CIC)   # Part 10 CIC
    hq = coefficients()
    fi = fir_model.golden(i, hq)[M_FIR - 1 :: M_FIR]           # Part 10 decimating FIR
    fq = fir_model.golden(q, hq)[M_FIR - 1 :: M_FIR]
    return fi, fq

F_LO, F_WANT, F_INTF1, F_INTF2 = 4.8e6, 5.0e6, 5.8e6, 7.05e6   # LO, wanted, two interferers

def stimulus(n, seed):
    rng = np.random.default_rng(seed); t = np.arange(n) / FS_IN
    x = (0.30 * np.cos(2 * np.pi * F_WANT * t)          # wanted: lands at +0.2 MHz
       + 0.30 * np.cos(2 * np.pi * F_INTF1 * t + 1.0)   # adjacent channel: +1.0 MHz, removed by the FIR
       + 0.30 * np.cos(2 * np.pi * F_INTF2 * t + 2.0)   # would alias to -0.25 MHz: removed by the CIC
       + rng.normal(0, 0.003, n))
    return quantize(x, 16, 15)

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--n", type=int, default=32768); p.add_argument("--seed", type=int, default=1)
    a = p.parse_args()
    fcw = fcw_for(F_LO / FS_IN)
    fir_model.write_coef_file(coefficients())
    t = open("fir_coefs.svh").read().replace("// firwin(32, 0.2) quantized", "// DDC compensation FIR (firls, 31 taps) quantized")
    open("fir_coefs.svh", "w").write(t)
    x = stimulus(a.n, a.seed)
    yi, yq = golden(x, fcw)
    open("x.hex", "w").write("\n".join(fir_model.to_hex(x, 16)) + "\n")
    with open("y_expected.txt", "w") as f:
        for u, v in zip(yi, yq): f.write(f"{u} {v}\n")
    print(f"{a.n} inputs -> {len(yi)} complex outputs; FCW = 0x{fcw:08x}")
