#!/usr/bin/env python3
"""blind_spot.py -- Appendix B: a mistake shared by the model and the RTL (wrong sign on Q) passes
the bit-exact test; a specification check (the tone must appear at +0.2 MHz) catches it."""
import subprocess, sys
import numpy as np
from fixedpoint import requant
from dds_model import nco
from decim_model import cic_decim_golden
import ddc_model, fir_model
from measure import level

def golden(x, fcw, q_sign):
    x = np.asarray(x, dtype=np.int64); c, s = nco(fcw, len(x))
    i = requant(x * c, 30, 16, 15, "round", "saturate"); q = requant(q_sign * (x * s), 30, 16, 15, "round", "saturate")
    i, q = cic_decim_golden(i, 8, 5), cic_decim_golden(q, 8, 5); hq = ddc_model.coefficients()
    return fir_model.golden(i, hq)[1::2], fir_model.golden(q, hq)[1::2]

x = ddc_model.stimulus(32768, 1); ok = True
for name, mixer, q_sign, should_meet_spec in [("correct design", "mixer.sv", -1, True), ("shared mistake", "mixer_wrong.sv", +1, False)]:
    yi, yq = golden(x, 0x3d70a3d7, q_sign)
    open("x.hex", "w").write("\n".join(fir_model.to_hex(x, 16)) + "\n")
    open("y_expected.txt", "w").write("\n".join(f"{u} {v}" for u, v in zip(yi, yq)) + "\n")
    subprocess.run(["iverilog", "-g2012", "-o", "sim_bs", "ddc.sv", mixer, "nco.sv", "cic_decim.sv", "fir_decim.sv", "mac.sv", "requant.sv", "tb_ddc.sv"], check=True)
    r = subprocess.run(["vvp", "-n", "sim_bs", "+GAP=5"], capture_output=True, text=True)
    rt = np.loadtxt("y_actual.txt", dtype=np.int64); z = (rt[:, 0] + 1j * rt[:, 1]) / 32768
    up, down = level(z, 0.2 / 1.25), level(z, -0.2 / 1.25)
    bit_exact = "PASS" in r.stdout; meets_spec = up > down + 60
    print(f"{name}: bit-exact {'PASS' if bit_exact else 'FAIL'}; tone +0.2 MHz {up:.1f} dBFS, -0.2 MHz {down:.1f} dBFS; spec {'met' if meets_spec else 'NOT met'}")
    ok &= bit_exact and (meets_spec == should_meet_spec)
print("demonstration reproduced" if ok else "UNEXPECTED RESULT"); sys.exit(0 if ok else 1)
