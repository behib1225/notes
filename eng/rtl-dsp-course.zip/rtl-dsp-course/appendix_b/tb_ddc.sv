`timescale 1ns/1ps
// tb_ddc.sv -- feeds x.hex with at least GAP clocks between samples, checks every output
module tb_ddc;
  logic clk = 1'b0, rst, in_valid, out_valid, overrun;
  logic signed [15:0] x, out_i, out_q;
  logic [31:0] fcw = 32'h3d70a3d7;              // 4.8 MHz at 20 MS/s
  logic [15:0] x_mem [0:65535];
  int n = 32768, gap = 5, sent = 0, got = 0, errors = 0, fe, fo, ei, eq, cycles = 0;
  ddc dut (.*);
  always #5 clk = ~clk;
  always @(posedge clk) cycles++;
  initial begin #100_000_000; $fatal(1, "TIMEOUT"); end
  initial begin
    void'($value$plusargs("N=%d", n));
    void'($value$plusargs("GAP=%d", gap));
    $readmemh("x.hex", x_mem, 0, n - 1);
    fe = $fopen("y_expected.txt", "r"); fo = $fopen("y_actual.txt", "w");
    rst = 1'b1; in_valid = 1'b0; x = '0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    while (sent < n) begin
      in_valid = 1'b1; x = x_mem[sent]; sent++;
      @(negedge clk);
      in_valid = 1'b0; x = 'x;
      repeat (gap - 1 + $urandom_range(0, 2)) @(negedge clk);   // GAP clocks or more per sample
    end
  end
  always @(negedge clk) if (!rst) begin
    assert (!overrun) else $fatal(1, "OVERRUN: a sample was lost between the CIC and the FIR");
    if (out_valid) begin
      void'($fscanf(fe, "%d %d\n", ei, eq));
      $fdisplay(fo, "%0d %0d", out_i, out_q);
      if (out_i !== 16'(ei) || out_q !== 16'(eq)) begin
        if (errors < 5) $display("FAIL output %0d: got %0d %0d, expected %0d %0d", got, out_i, out_q, ei, eq);
        errors++;
      end
      if (++got == n / 16) begin
        $fclose(fo);
        if (errors) $fatal(1, "FAILED: %0d of %0d outputs wrong", errors, got);
        $display("PASS: %0d complex outputs bit-exact, %0d clock cycles", got, cycles);
        $finish;
      end
    end
  end
endmodule
