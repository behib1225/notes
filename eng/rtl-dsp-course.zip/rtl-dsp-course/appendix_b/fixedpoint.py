"""fixedpoint.py -- bit-exact fixed-point helpers that match the hardware.

A signed fixed-point number has W bits in total, F of them fractional.
The stored integer q represents the real value q / 2**F.
"""
import numpy as np

def quantize(x, W, F, rnd="round", ovf="saturate"):
    """Real value(s) -> W-bit integer(s) with F fractional bits."""
    v = np.asarray(x, dtype=np.float64) * 2.0**F
    if rnd == "floor":                  # truncation: drop the bits below the LSB
        q = np.floor(v)
    elif rnd == "round":                # round half up: add 1/2 LSB, then floor
        q = np.floor(v + 0.5)
    elif rnd == "convergent":           # round half to even (NumPy's np.round)
        q = np.round(v)
    else:
        raise ValueError(rnd)
    return handle_overflow(q.astype(np.int64), W, ovf)

def handle_overflow(q, W, ovf="saturate"):
    lo, hi = -(1 << (W - 1)), (1 << (W - 1)) - 1
    q = np.asarray(q, dtype=np.int64)
    if ovf == "saturate":
        return np.clip(q, lo, hi)
    if ovf == "wrap":
        return ((q - lo) % (1 << W)) + lo
    raise ValueError(ovf)

def to_real(q, F):
    """Integer(s) with F fractional bits -> real value(s)."""
    return np.asarray(q, dtype=np.float64) / 2.0**F

def requant(q, F_in, W_out, F_out, rnd="round", ovf="saturate"):
    """Integer -> integer: drop (F_in - F_out) fractional bits, then fit W_out bits.
    Exactly what requant.sv does, using only integer operations."""
    q = np.asarray(q, dtype=np.int64)
    s = F_in - F_out
    assert s >= 1
    if rnd == "floor":
        r = q >> s                                   # arithmetic shift = floor
    elif rnd == "round":
        r = (q + (1 << (s - 1))) >> s                # add half an output LSB, then floor
    elif rnd == "convergent":
        r = q >> s
        rem = q - (r << s)                           # the dropped bits, 0 .. 2**s - 1
        half = 1 << (s - 1)
        r = r + ((rem > half) | ((rem == half) & (r & 1 == 1)))
    else:
        raise ValueError(rnd)
    return handle_overflow(r, W_out, ovf)
