`timescale 1ns/1ps
// cic_decim.sv -- CIC decimator: NS integrators at the input rate, decimate by R,
// NS combs at the output rate. No multipliers. All internal arithmetic WRAPS
// (W = XW + NS*log2(R) bits), which is correct for a CIC filter.
module cic_decim #(
  parameter int R  = 8,                         // decimation factor
  parameter int NS = 3,                         // number of integrator/comb stages
  parameter int XW = 16, XF = 15,
  parameter int W  = XW + NS * $clog2(R)        // 25 bits for R = 8, NS = 3
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  localparam int RW = (R > 1) ? $clog2(R) : 1;
  assign in_ready = 1'b1;

  logic signed [W-1:0] integ  [0:NS-1];         // integrators (input rate)
  logic signed [W-1:0] comb_d [0:NS-1];         // comb delay registers (output rate)
  logic signed [W-1:0] c      [0:NS];           // comb chain, combinational
  logic [RW-1:0]       cnt;
  logic                dec;                     // this input completes a group of R

  assign dec = in_valid && (cnt == RW'(R - 1));

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < NS; k++) begin integ[k] <= '0; comb_d[k] <= '0; end
      cnt <= '0;
    end else if (in_valid) begin
      // integrators: y[n] = y[n-1] + input; overflow wraps, by design
      integ[0] <= integ[0] + W'(x);
      for (int k = 1; k < NS; k++) integ[k] <= integ[k] + integ[k-1];
      cnt <= dec ? '0 : cnt + 1'b1;
      // combs: once per R inputs, y = input - input delayed by one output sample
      if (dec) for (int k = 0; k < NS; k++) comb_d[k] <= c[k];
    end
  end

  always_comb begin
    c[0] = integ[NS-1];
    for (int k = 0; k < NS; k++) c[k+1] = c[k] - comb_d[k];
  end

  // gain is R**NS = 2**(NS*log2 R): drop those bits with rounding, saturate to Q1.15
  logic signed [XW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(W), .IN_F(XF + NS * $clog2(R)), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1))
    u_rq (.din(c[NS]), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= dec;
    if (dec) y <= y_c;
  end
endmodule
