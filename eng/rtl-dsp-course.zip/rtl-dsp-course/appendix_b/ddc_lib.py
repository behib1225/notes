#!/usr/bin/env python3
"""ddc_lib.py -- generalized bit-exact DDC model: per-sample FCW, any NCO table size,
any power-of-two R with its own compensation FIR; plus the floating-point references."""
import numpy as np
from scipy import signal
from fixedpoint import quantize, requant
from dds_model import make_lut
from decim_model import cic_decim_golden
import fir_model

def nco_var(fcws, A=10):
    """Part 9 NCO with a per-sample FCW: output k uses the phase before the k-th increment."""
    fcws = np.asarray(fcws, dtype=np.int64)
    ph = np.concatenate([[0], np.cumsum(fcws[:-1])]) % (1 << 32)
    c, s = make_lut(A)
    return c[ph >> (32 - A)], s[ph >> (32 - A)], ph

def cic_resp(f_in, R):
    f = np.where(np.asarray(f_in, float) == 0, 1e-12, f_in)
    return np.abs(np.sin(np.pi * f * R) / (R * np.sin(np.pi * f))) ** 5

def design_fir(R=8):
    """Part 12's firls design for any R: edges 0.16 and 0.34 of the CIC output rate."""
    edges = np.linspace(0, 0.16, 9); bands, desired = [], []
    for a, b in zip(edges[:-1], edges[1:]):
        bands += [a, b]; desired += [1 / cic_resp(a / R, R), 1 / cic_resp(b / R, R)]
    bands += [0.34, 0.5]; desired += [0, 0]
    return signal.firls(31, bands, desired, weight=[1] * 8 + [30], fs=1.0)

def coefficients(R=8):
    return quantize(design_fir(R), 18, 17)

def golden(x, fcws, A=10, R=8):
    x = np.asarray(x, dtype=np.int64)
    if np.isscalar(fcws): fcws = np.full(len(x), fcws, dtype=np.int64)
    c, s, _ = nco_var(fcws, A)
    i = requant(x * c, 30, 16, 15, "round", "saturate")
    q = requant(-(x * s), 30, 16, 15, "round", "saturate")
    i, q = cic_decim_golden(i, R, 5), cic_decim_golden(q, R, 5)
    hq = coefficients(R)
    return fir_model.golden(i, hq)[1::2], fir_model.golden(q, hq)[1::2]

def sqnr(z, x, fcws, A=10, R=8, ideal=False, skip=100):
    """SQNR (dB) of the complex output z against the floating-point chain of Part 12, section 12.4:
    the same LO (the NCO's table values, or an ideal oscillator), boxcar^5 instead of the integer
    CIC, and the floating-point FIR. The decimation offset is found by search (2 for R = 8)."""
    xf = np.asarray(x) / 32768.0
    if np.isscalar(fcws): fcws = np.full(len(x), fcws, dtype=np.int64)
    c, s, ph = nco_var(fcws, A)
    lo = np.exp(-2j * np.pi * ph / 2 ** 32) if ideal else (c - 1j * s) / 32768.0
    h5 = np.ones(1)
    for _ in range(5): h5 = np.convolve(h5, np.ones(R))
    full = np.convolve(xf * lo, h5 / R ** 5)
    best = -1e9
    for d in range(R):
        v = full[d::R]
        y = np.convolve(v, design_fir(R))[: len(v)][1::2][: len(z)]
        if len(y) < len(z): continue
        e = z[skip:] - y[skip:]
        best = max(best, 10 * np.log10(np.mean(np.abs(y[skip:]) ** 2) / np.mean(np.abs(e) ** 2)))
    return best

def mirror_dbc(z, f_want=0.2e6, fs_out=1.25e6):
    """Level of the mirror image (at -f_want) relative to the wanted tone, Blackman-Harris window."""
    from scipy.signal.windows import blackmanharris
    w = blackmanharris(len(z)); Z = np.abs(np.fft.fft(z * w)); f = np.fft.fftfreq(len(z), 1 / fs_out)
    lvl = lambda f0: 20 * np.log10(Z[np.abs(f - f0) < 2 * fs_out / len(z)].max())
    return lvl(-f_want) - lvl(f_want)
