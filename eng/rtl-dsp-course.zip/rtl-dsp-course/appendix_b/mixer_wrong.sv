`timescale 1ns/1ps
// mixer.sv -- real-to-complex digital mixer: I = x*cos(w0 n), Q = -x*sin(w0 n).
// The NCO advances once per valid input sample. Latency: 2 cycles.
module mixer #(
  parameter int W = 16, ACC_W = 32
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,             // real input, Q1.15
  input  logic [ACC_W-1:0]    fcw,           // LO frequency
  output logic                out_valid,
  output logic signed [W-1:0] i_out, q_out   // complex output, Q1.15
);
  logic                lo_valid;
  logic signed [W-1:0] lo_cos, lo_sin, x_d;

  nco #(.ACC_W(ACC_W), .W(W)) u_nco (
    .clk(clk), .rst(rst), .en(in_valid), .fcw(fcw),
    .out_valid(lo_valid), .cos_o(lo_cos), .sin_o(lo_sin)
  );

  always_ff @(posedge clk) if (in_valid) x_d <= x;   // align x with the NCO's registered output

  logic signed [2*W-1:0] pi, pq;                     // Q2.30 products
  assign pi = x_d * lo_cos;
  assign pq = x_d * lo_sin;                           // SHARED MISTAKE: wrong sign on Q

  logic signed [W-1:0] i_c, q_c;
  logic                ovf_i_unused, ovf_q_unused;
  requant #(.IN_W(2*W), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_rqi (.din(pi), .dout(i_c), .ovf(ovf_i_unused));
  requant #(.IN_W(2*W), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_rqq (.din(pq), .dout(q_c), .ovf(ovf_q_unused));

  always_ff @(posedge clk) begin
    if (rst) out_valid <= 1'b0;
    else     out_valid <= lo_valid;
    if (lo_valid) begin
      i_out <= i_c;
      q_out <= q_c;
    end
  end
endmodule
