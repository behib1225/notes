`timescale 1ns/1ps
// requant.sv -- change a signed fixed-point value from (IN_W, IN_F) to (OUT_W, OUT_F):
// drop S = IN_F - OUT_F fractional bits with the chosen rounding, then fit OUT_W bits.
// Purely combinational; register its output in the surrounding design.
module requant #(
  parameter int IN_W  = 32,
  parameter int IN_F  = 30,
  parameter int OUT_W = 16,
  parameter int OUT_F = 15,
  parameter int RND   = 1,      // 0 = floor (truncate), 1 = round half up, 2 = convergent
  parameter bit SAT   = 1'b1    // 1 = saturate, 0 = wrap
) (
  input  logic signed [IN_W-1:0]  din,
  output logic signed [OUT_W-1:0] dout,
  output logic                    ovf     // 1 when the value did not fit (before saturation)
);
  localparam int S  = IN_F - OUT_F;            // fractional bits to drop, must be >= 1
  localparam int RW = IN_W + 1 - S;            // width after rounding: one extra bit for the carry
  localparam int CW = (RW > OUT_W) ? RW : OUT_W;   // width for the range comparisons

  logic signed [IN_W:0]   din_x;               // din with one extra (sign) bit
  logic signed [RW-1:0]   floor_v;             // floor(din / 2**S)
  logic        [S-1:0]    rem;                 // the dropped bits
  logic                   round_up;            // add 1 to floor_v?
  logic signed [RW-1:0]   rounded;
  logic signed [CW-1:0]   rounded_c, max_v, min_v;
  localparam logic [S-1:0] HALF = S'(1) << (S - 1);   // 100...0: exactly half an output LSB

  assign din_x   = (IN_W + 1)'(din);           // sign-extend by one bit
  assign floor_v = RW'(din_x >>> S);           // arithmetic shift = floor
  assign rem     = din[S-1:0];

  // Should we add 1 to the floored value?
  logic up_half, up_even;
  assign up_half = (rem >= HALF);                         // round half up: at or above 1/2
  /* verilator lint_off CMPCONST */                       // when S = 1, rem > HALF is never true: correct
  assign up_even = (rem > HALF) || (rem == HALF && floor_v[0]);   // convergent: ties to even
  /* verilator lint_on CMPCONST */
  assign round_up = (RND == 0) ? 1'b0 : (RND == 1) ? up_half : up_even;

  assign rounded = floor_v + RW'(round_up);
  assign rounded_c = CW'(rounded);             // sign-extend if the output is wider
  assign max_v     = CW'((64'sd1 <<< (OUT_W - 1)) - 1);
  assign min_v     = CW'(-(64'sd1 <<< (OUT_W - 1)));
  assign ovf       = (rounded_c > max_v) || (rounded_c < min_v);

  always_comb begin
    if (SAT && rounded_c > max_v)      dout = OUT_W'(max_v);
    else if (SAT && rounded_c < min_v) dout = OUT_W'(min_v);
    else                               dout = OUT_W'(rounded_c);  // wrap: keep the low bits
  end
endmodule
