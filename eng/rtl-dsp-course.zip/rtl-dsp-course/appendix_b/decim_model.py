#!/usr/bin/env python3
"""decim_model.py -- golden models and vectors for fir_decim.sv and cic_decim.sv."""
import argparse
import numpy as np
from fir_model import coefficients, golden as fir_golden, to_hex, stimulus
from fixedpoint import requant

def fir_decim_golden(x, M):
    """Keep outputs M-1, 2M-1, ...: those computed after each M-th input sample."""
    return fir_golden(x, coefficients())[M - 1 :: M]

CIC_N, CIC_W = 3, 16 + 3 * 3          # 3 stages; R = 8 -> growth 3*log2(8) = 9 bits

def cic_decim_golden(x, R=8, N=CIC_N, W=None):
    """Register-accurate model of cic_decim.sv, with W-bit wrap-around arithmetic."""
    W = W or 16 + N * int(np.log2(R))                    # register growth: N*log2(R) bits
    mask, half = (1 << W) - 1, 1 << (W - 1)
    wrap = lambda v: ((v + half) & mask) - half          # two's complement wrap to W bits
    integ = [0] * N                                       # integrator registers
    comb_d = [0] * N                                      # comb delay registers
    cnt, out = 0, []
    for v in np.asarray(x, dtype=np.int64).tolist():
        old = integ[:]                                    # all registers update together
        integ[0] = wrap(old[0] + v)
        for k in range(1, N):
            integ[k] = wrap(old[k] + old[k - 1])
        if cnt == R - 1:                                  # decimate: one comb update per R inputs
            c = old[N - 1]                                # the comb sees the register BEFORE this update
            for k in range(N):
                c, comb_d[k] = wrap(c - comb_d[k]), c
            out.append(c)
            cnt = 0
        else:
            cnt += 1
    gain_bits = N * int(np.log2(R))                       # gain R**N = 2**9
    return requant(np.array(out, dtype=np.int64), 15 + gain_bits, 16, 15, "round", "saturate")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--dut", default="fir_decim"); p.add_argument("--m", type=int, default=4)
    p.add_argument("--seed", type=int, default=1); p.add_argument("--n", type=int, default=4000)
    a = p.parse_args()
    x = stimulus(a.n, a.seed)
    y = fir_decim_golden(x, a.m) if a.dut == "fir_decim" else cic_decim_golden(x, a.m)
    open("x.hex", "w").write("\n".join(to_hex(x, 16)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(y, 16)) + "\n")
    print(f"{a.dut}: {a.n} inputs -> {len(y)} outputs (M = {a.m})")
