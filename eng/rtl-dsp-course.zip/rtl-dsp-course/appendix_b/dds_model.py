#!/usr/bin/env python3
"""dds_model.py -- bit-exact models for Part 9: NCO, CORDIC rotator, mixer."""
import numpy as np

# ---------------- NCO ----------------
ACC_W = 32          # phase accumulator width
LUT_A = 10          # LUT address bits (phase bits kept after truncation)
OUT_W = 16          # Q1.15 sine and cosine

def make_lut(addr_bits=LUT_A, w=OUT_W):
    """Full-wave cosine and sine tables, amplitude 2**(w-1) - 1, rounded."""
    k = np.arange(1 << addr_bits)
    amp = (1 << (w - 1)) - 1
    c = np.round(amp * np.cos(2 * np.pi * k / (1 << addr_bits))).astype(np.int64)
    s = np.round(amp * np.sin(2 * np.pi * k / (1 << addr_bits))).astype(np.int64)
    return c, s

def write_lut_files(addr_bits=LUT_A, w=OUT_W):
    c, s = make_lut(addr_bits, w)
    mask = (1 << w) - 1
    for name, t in (("cos_lut.hex", c), ("sin_lut.hex", s)):
        with open(name, "w") as f:
            f.write("\n".join(f"{int(v) & mask:04x}" for v in t) + "\n")

def nco(fcw, n, addr_bits=LUT_A, acc_w=ACC_W, phase0=0):
    """Output sample k uses the phase BEFORE the k-th increment: phase_k = phase0 + k*fcw."""
    c, s = make_lut(addr_bits)
    phase = (phase0 + np.arange(n, dtype=np.int64) * fcw) % (1 << acc_w)
    idx = phase >> (acc_w - addr_bits)
    return c[idx], s[idx]

def fcw_for(f_cycles_per_sample, acc_w=ACC_W):
    return int(round(f_cycles_per_sample * (1 << acc_w))) % (1 << acc_w)

# ---------------- CORDIC (rotation mode) ----------------
CW = 18             # x, y width inside the CORDIC (16-bit inputs + 2 guard bits)
ZW = 20             # angle width: full circle = 2**ZW
N_IT = 16           # iterations

def atan_table(n_it=N_IT, zw=ZW):
    return [int(round(np.arctan(2.0 ** -i) / (2 * np.pi) * (1 << zw))) for i in range(n_it)]

def cordic_gain(n_it=N_IT):
    return float(np.prod(np.sqrt(1 + 2.0 ** (-2 * np.arange(n_it)))))

def cordic_rotate(x, y, z, n_it=N_IT, zw=ZW):
    """Rotate (x, y) by angle z (binary angle units, full circle = 2**zw), as integers.
    Matches cordic.sv: quadrant pre-rotation, then n_it shift-and-add iterations.
    The result is scaled by the CORDIC gain (~1.647)."""
    x, y, z = int(x), int(y), int(z) % (1 << zw)
    if z >= (1 << zw) // 2:
        z -= 1 << zw                                   # to the range [-1/2, 1/2) of a turn
    q = 1 << (zw - 2)                                  # a quarter turn (90 degrees)
    if z > q:                                          # rotate by +90 first
        x, y, z = -y, x, z - q
    elif z < -q:                                       # rotate by -90 first
        x, y, z = y, -x, z + q
    for i, a in enumerate(atan_table(n_it, zw)):
        if z >= 0:
            x, y, z = x - (y >> i), y + (x >> i), z - a
        else:
            x, y, z = x + (y >> i), y - (x >> i), z + a
    return x, y
