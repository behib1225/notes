#!/usr/bin/env python3
"""measure.py -- the course's standard measurements, defined once.

Conventions (used by every function):
  * frequencies are in cycles per sample (0 .. 0.5 for real signals, -0.5 .. 0.5 for complex);
  * the window is Blackman-Harris (4-term), normalized by its coherent gain, so that a
    full-scale (amplitude 1) sine exactly on a bin reads 0 dBFS;
  * a "level at f" is the LARGEST bin within +-guard bins of f (guard = 2 by default), which
    makes a tone between bins read correctly within about 0.8 dB (the scalloping loss);
  * every result is returned together with the parameters that produced it.
"""
import numpy as np

def bh_window(n):
    k = np.arange(n); a = (0.35875, 0.48829, 0.14128, 0.01168)
    return a[0] - a[1]*np.cos(2*np.pi*k/n) + a[2]*np.cos(4*np.pi*k/n) - a[3]*np.cos(6*np.pi*k/n)

def spectrum(x, full_scale=1.0):
    """Return (freqs, dBFS). Real x: one-sided, 0 .. 0.5. Complex x: two-sided, -0.5 .. 0.5."""
    x = np.asarray(x); n = len(x); w = bh_window(n); cg = w.mean()
    X = np.fft.fft(x * w) / (n * cg * full_scale)
    if np.iscomplexobj(x):
        return np.fft.fftshift(np.fft.fftfreq(n)), 20*np.log10(np.abs(np.fft.fftshift(X)) + 1e-300)
    mag = 2*np.abs(X[: n//2 + 1]); mag[0] /= 2
    return np.arange(n//2 + 1) / n, 20*np.log10(mag + 1e-300)

def level(x, f, guard=2, full_scale=1.0):
    """Level (dBFS) of the component at f: the largest bin within +-guard bins."""
    fr, db = spectrum(x, full_scale)
    return float(db[np.abs(fr - f) <= (guard + 0.5) / len(x)].max())

def sfdr(x, exclude=8, dc=4):
    """Spurious-free dynamic range (dB) of a real single tone: carrier peak minus the largest
    other bin, excluding +-exclude bins around the carrier and the lowest dc bins."""
    fr, db = spectrum(x)
    k = int(np.argmax(db)); m = np.ones(len(db), bool)
    m[max(0, k - exclude): k + exclude + 1] = False; m[:dc] = False
    return float(db[k] - db[m].max()), float(fr[k])

def mirror_dbc(z, f, guard=2):
    """Level at -f relative to the level at +f (dB), for a complex signal z."""
    return level(z, -f, guard) - level(z, f, guard)

def sqnr_db(y, ref, skip=0):
    """10 log10(power of ref / power of (y - ref)), after dropping skip start-up samples."""
    y, ref = np.asarray(y)[skip:], np.asarray(ref)[skip:]
    return float(10*np.log10(np.mean(np.abs(ref)**2) / np.mean(np.abs(y - ref)**2)))

def gain(x, y, f):
    """Complex gain y/x at frequency f (cycles per sample), from the projections of x and y onto
    exp(j 2 pi f n). Use whole cycles of every tone present, or the result leaks (Part 5)."""
    n = np.arange(len(x)); e = np.exp(-2j*np.pi*f*n)
    return complex(np.sum(np.asarray(y)*e) / np.sum(np.asarray(x)*e))
