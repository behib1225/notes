#!/bin/sh
# regress.sh -- run every automated check in the course. Usage: ./regress.sh [step ...]
# With no arguments, runs all steps. Each step runs in its own directory; the run continues after
# a failure, and the exit status is non-zero if any step failed.
ROOT=$(cd "$(dirname "$0")" && pwd)
STEPS=${*:-"p04 p07 p08 p10 p10hb sol12 p13 p13cocotb p14 appA appB"}
pass=0; fail=0; failed=""
run() {  # run NAME DIR COMMAND...
  name=$1; dir=$2; shift 2
  printf "%-10s " "$name"
  if (cd "$ROOT/$dir" && "$@") > "$ROOT/regress_$name.log" 2>&1; then echo PASS; pass=$((pass+1))
  else echo "FAIL  (see regress_$name.log)"; fail=$((fail+1)); failed="$failed $name"; fi
}
for s in $STEPS; do
  case $s in
    p04)       run p04       course/part04 ./run_test.sh 1 ;;
    p07)       run p07       course/part07 sh -c 'for d in fir_direct fir_transposed fir_symmetric fir_serial; do ./run_fir.sh $d 1 || exit 1; done' ;;
    p08)       run p08       course/part08 ./run_iir.sh 1 ;;
    p10)       run p10       course/part10 sh -c './run_decim.sh fir_decim 4 1 && ./run_decim.sh cic_decim 8 1' ;;
    p10hb)     run p10hb     course/part10_halfband python3 check_halfband.py ;;
    sol12)     run sol12     solutions/part12 ./run_ddc.sh 2 5 ;;
    p13)       run p13       course/part13 ./run_part13.sh ;;
    p13cocotb) run p13cocotb course/part13/cocotb sh -c 'python3 run_cocotb.py > cocotb.log 2>&1; grep -q "FAIL=0" cocotb.log' ;;
    p14)       run p14       course/part14 python3 check_part14.py ;;
    appA)      run appA      appendix_a/constructs ./check_portable.sh ;;
    appB)      run appB      appendix_b python3 blind_spot.py ;;
    *)         echo "unknown step $s"; fail=$((fail+1)) ;;
  esac
done
echo "$pass passed, $fail failed${failed:+:$failed}"
[ $fail = 0 ]
