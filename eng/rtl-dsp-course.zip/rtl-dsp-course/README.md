# Verilog & RTL for DSP — course text and code

The course *Verilog & RTL for DSP*: its text (in `text/`, as Markdown) and its code: every design,
testbench, model and script of Parts 1 to 14, their worked solutions, and the appendices. Everything here was verified with the
toolchain pinned below; `regress.sh` re-runs the automated checks.

## Layout

| Folder | Contents |
| --- | --- |
| `text/` | The course text: the 14 parts, the 12 solution documents and the 3 appendices, as Markdown; start with `text/index.md` |
| `course/partNN/` | The designs, models, testbenches and run scripts of each part |
| `course/part04_memory/` | The four memory coding styles of Part 4, section 4.6 |
| `course/part10_halfband/` | The half-band decimator of Part 10, section 10.4 |
| `course/part13/` | Timing closure (the pipelined DDC `ddc_p2`), AXI4-Stream skid buffer, formal harness, async FIFO, reset synchronizer; `cocotb/` holds the cocotb coverage test |
| `course/part14/` | CSD and distributed-arithmetic FIR generators, Farrow interpolator, streaming FFT |
| `solutions/partNN/` | Worked solutions of each part's exercises (some parts in `exN/` subfolders) |
| `appendix_a/` | The portability test cases (`constructs/`) and the package/struct example (`packages/`) |
| `appendix_b/` | `measure.py` and the blind-spot demonstration |

## Toolchain

Verified with: Ubuntu 24.04, Icarus Verilog 12.0, Verilator 5.020, Yosys 0.33, z3 4.8.12,
Python 3.12 with the packages in `requirements.txt`. Newer versions of these tools accept more
SystemVerilog and give different synthesis and timing numbers; re-run the checks after upgrading.
The easiest way to get exactly this toolchain is the container:

```sh
docker build -t rtl-dsp .
docker run --rm rtl-dsp            # runs ./regress.sh
```

## Running the checks

```sh
./regress.sh                       # everything (several minutes)
./regress.sh p07 p14               # selected steps
```

Steps: `p04 p07 p08 p10 p10hb sol12 p13 p13cocotb p14 appA appB`. Each step's output goes to
`regress_<step>.log`. What they cover:

- **p04, p07, p08, p10, p10hb**: bit-exact simulation against the Python models (Parts 4, 7, 8, 10).
- **sol12**: the Part 12 DDC: bit-exact, an independent model check, and specification checks
  (tone position and level, mirror and interferer rejection), on two seeds.
- **p13**: the pipelined DDC, the skid buffer (simulation and formal proof, plus a broken copy that
  must fail), the async FIFO (five clock ratios; one-sided reset must fail), the reset synchronizer.
- **p13cocotb**: the cocotb test with functional coverage.
- **p14**: every Part 14 design, bit-exact, and lint.
- **appA**: every portable construct of Appendix A through all three tools.
- **appB**: the shared-mistake demonstration of Appendix B.

## About the text

The Markdown files are exports of the online course documents; each starts with a link to its
online version, which stays the reference. Diagrams and charts (35 in all) are not in the Markdown:
each is marked with its title and a link to the online page where it appears.

## What the regression does not cover

Not every exercise of Parts 1 to 12 has an automated script: many solutions were checked with
short Python commands that are described in the solution documents rather than saved as files.
Place and route (Part 13) is not part of the regression because it takes minutes per seed; run it
with `yowasp-nextpnr-ecp5` as described in Part 13. Resource and timing figures are tool
estimates (Yosys for the AMD 7-series, nextpnr for the Lattice ECP5); they were not cross-checked
with vendor tools, and no design has been run on an FPGA board.
