`timescale 1ns/1ps
module latch_fixed (
  input  logic       en,
  input  logic [3:0] d,
  output logic [3:0] q
);
  always_comb begin
    q = 4'd0;           // default assignment first...
    if (en) q = d;      // ...then override it
  end
endmodule
