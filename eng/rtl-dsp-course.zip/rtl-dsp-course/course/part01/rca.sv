`timescale 1ns/1ps
// rca.sv -- N-bit ripple-carry adder built from full adders
module rca #(
  parameter int N = 8                 // width; can be overridden per instance
) (
  input  logic [N-1:0] a, b,
  input  logic         cin,
  output logic [N-1:0] sum,
  output logic         cout
);
  logic [N:0] c;                      // carry chain: c[0] = cin, c[N] = cout
  assign c[0] = cin;

  genvar i;
  generate
    for (i = 0; i < N; i++) begin : g_bit
      full_adder fa (.a(a[i]), .b(b[i]), .cin(c[i]), .sum(sum[i]), .cout(c[i+1]));
    end
  endgenerate

  assign cout = c[N];
endmodule
