`timescale 1ns/1ps
// tb_rca.sv -- checks a 16-bit ripple-carry adder against the '+' operator
module tb_rca;
  localparam int N = 16;
  logic [N-1:0] a, b, sum;
  logic         cin, cout;
  logic [N:0]   expected;            // one bit wider than the inputs
  int errors = 0;

  rca #(.N(N)) dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

  task automatic check(input logic [N-1:0] ta, tb, input logic tcin);
    a = ta; b = tb; cin = tcin;
    #10;
    expected = a + b + cin;          // N+1-bit result, computed by the simulator
    if ({cout, sum} !== expected) begin
      $display("FAIL: %0d + %0d + %0d = %0d, expected %0d", a, b, cin, {cout, sum}, expected);
      errors++;
    end
  endtask

  initial begin
    // corner cases first: they find most bugs
    check(16'h0000, 16'h0000, 1'b0);
    check(16'hFFFF, 16'h0001, 1'b0);   // carry ripples through every bit
    check(16'hFFFF, 16'hFFFF, 1'b1);   // largest possible sum
    check(16'h8000, 16'h8000, 1'b0);
    // then 1000 random cases
    repeat (1000) check($urandom, $urandom, $urandom);
    if (errors == 0) $display("PASS: 1004 cases correct");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
