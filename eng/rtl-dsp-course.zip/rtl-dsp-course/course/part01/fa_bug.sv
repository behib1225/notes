`timescale 1ns/1ps
// full_adder.sv -- adds a, b and a carry-in
module full_adder (
  input  logic a,
  input  logic b,
  input  logic cin,
  output logic sum,
  output logic cout
);
  assign sum  = a ^ b ^ cin;
  assign cout = (a & b) | (a & cin);
endmodule
