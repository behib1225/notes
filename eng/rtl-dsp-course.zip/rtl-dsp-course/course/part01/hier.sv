module peek; initial begin #15; $display("bit3 sum via hierarchy = %b", tb_rca.dut.g_bit[3].fa.sum); end endmodule
