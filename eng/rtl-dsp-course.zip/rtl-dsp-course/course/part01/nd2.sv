`timescale 1ns/1ps
module numbers_demo;
  logic [7:0]         u8;
  logic signed [7:0]  s8;
  logic [3:0]         n4;
  logic signed [3:0]  sn4;
  logic [8:0]         u9;
  logic signed [15:0] s16;
  logic               x_demo;
  initial begin
    u8 = 8'b1010_0101;   $display("1. 8'b1010_0101 = %0d (dec) = %h (hex)", u8, u8);
    u8 = 8'hFF;          $display("   8'hFF        = %0d", u8);
    u8 = 8'hF0;  s8 = 8'hF0;
    $display("2. bits 11110000: unsigned = %0d, signed = %0d", u8, s8);
    n4 = 8'hAB;          $display("3. n4 = 8'hAB  -> n4 = %h (high bits lost)", n4);
    u8 = 8'd200;
    u9 = u8 + 8'd100;    $display("4. 200 + 100 into 9 bits = %0d", u9);
    u8 = u8 + 8'd100;    $display("   200 + 100 into 8 bits = %0d (wrapped mod 256)", u8);
    sn4 = -4'sd3;
    s16 = sn4;           $display("5. sn4 = %b (%0d) -> s16 = %b (%0d)", sn4, sn4, s16, s16);
    n4  = 4'd2;
    s16 = sn4 + n4;      $display("6. (-3) + 2 with an unsigned operand = %0d  (wrong!)", s16);
    s16 = sn4 + $signed({1'b0, n4});
                         $display("   (-3) + 2 with both signed        = %0d  (right)", s16);
    x_demo = 1'bx;
    $display("7. x & 0 = %b,  x & 1 = %b,  x | 1 = %b", x_demo & 1'b0, x_demo & 1'b1, x_demo | 1'b1);
    u8 = {4'hA, 4'h5};       $display("8. {4'hA, 4'h5} = %h", u8);
    u8 = {8{1'b1}};          $display("   {8{1'b1}}    = %b", u8);
    s16 = {{8{s8[7]}}, s8};  $display("   manual sign-extension of %0d = %0d", s8, s16);
  end
endmodule
