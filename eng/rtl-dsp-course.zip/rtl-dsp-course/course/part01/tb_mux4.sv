`timescale 1ns/1ps
module tb_mux4;
  logic [7:0] d0, d1, d2, d3, y_assign, y_if, y_case, expected;
  logic [1:0] sel;
  int errors = 0;
  mux4 dut (.*);   // .* connects every port to the signal with the same name
  initial begin
    d0 = 8'h11; d1 = 8'h22; d2 = 8'h33; d3 = 8'h44;
    for (int i = 0; i < 4; i++) begin
      sel = i[1:0];
      #10;
      case (sel) 0: expected = d0; 1: expected = d1; 2: expected = d2; default: expected = d3; endcase
      if (y_assign !== expected || y_if !== expected || y_case !== expected) begin
        $display("FAIL sel=%0d: %h %h %h (expected %h)", sel, y_assign, y_if, y_case, expected);
        errors++;
      end
    end
    if (errors == 0) $display("PASS: all select values correct");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
