// tb_full_adder.sv -- exhaustive, self-checking testbench
`timescale 1ns/1ps
module tb_full_adder;
  logic a, b, cin;          // drive these
  logic sum, cout;          // observe these
  int   errors = 0;

  // Device Under Test (DUT)
  full_adder_ha dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

  initial begin
    $dumpfile("full_adder.vcd");   // waveform file
    $dumpvars(0, tb_full_adder);

    for (int i = 0; i < 8; i++) begin
      {a, b, cin} = i[2:0];        // apply inputs
      #10;                         // let logic settle
      if ({cout, sum} !== a + b + cin) begin
        $display("FAIL: a=%b b=%b cin=%b -> cout=%b sum=%b", a, b, cin, cout, sum);
        errors++;
      end else begin
        $display("ok:   a=%b b=%b cin=%b -> cout=%b sum=%b", a, b, cin, cout, sum);
      end
    end

    if (errors == 0) $display("PASS: all 8 cases correct");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
