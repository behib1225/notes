`timescale 1ns/1ps
module latch_bad (
  input  logic       en,
  input  logic [3:0] d,
  output logic [3:0] q
);
  always_comb begin
    if (en) q = d;      // no else: what is q when en = 0?
  end
endmodule
