`timescale 1ns/1ps
module rca #(parameter int N = 8) (
  input  logic [N-1:0] a, b,
  input  logic         cin,
  output logic [N-1:0] sum,
  output logic         cout
);
  assign {cout, sum} = a + b + cin;
endmodule
