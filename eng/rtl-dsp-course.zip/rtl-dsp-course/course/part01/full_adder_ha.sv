`timescale 1ns/1ps
// full_adder_ha.sv -- a full adder built from two half adders (Mano, Fig. 4-8 style)
module full_adder_ha (
  input  logic a, b, cin,
  output logic sum, cout
);
  logic s1, c1, c2;   // internal wires between the two half adders

  half_adder ha1 (.a(a),  .b(b),   .sum(s1),  .carry(c1));
  half_adder ha2 (.a(s1), .b(cin), .sum(sum), .carry(c2));

  assign cout = c1 | c2;
endmodule
