`timescale 1ns/1ps
// tb_full_adder.sv -- exhaustive, self-checking testbench for full_adder
module tb_full_adder;
  logic       a, b, cin;     // inputs we drive
  logic       sum, cout;     // outputs we observe
  logic [1:0] expected;      // the right answer, 2 bits wide
  int         errors = 0;

  // Device Under Test (DUT)
  full_adder dut (.a(a), .b(b), .cin(cin), .sum(sum), .cout(cout));

  initial begin
    $dumpfile("full_adder.vcd");      // record waveforms to this file
    $dumpvars(0, tb_full_adder);      // ...for every signal in the testbench

    for (int i = 0; i < 8; i++) begin
      {a, b, cin} = i[2:0];           // apply all 8 input patterns
      #10;                            // wait 10 ns for the logic to settle
      expected = a + b + cin;         // the simulator does the math for us
      if ({cout, sum} !== expected) begin
        $display("FAIL: a=%b b=%b cin=%b -> cout=%b sum=%b (expected %b)",
                 a, b, cin, cout, sum, expected);
        errors++;
      end else begin
        $display("ok:   a=%b b=%b cin=%b -> cout=%b sum=%b", a, b, cin, cout, sum);
      end
    end

    if (errors == 0) $display("PASS: all 8 cases correct");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
