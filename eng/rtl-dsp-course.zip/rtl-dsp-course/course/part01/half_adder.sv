`timescale 1ns/1ps
// half_adder.sv -- adds two 1-bit numbers
module half_adder (
  input  logic a,
  input  logic b,
  output logic sum,
  output logic carry
);
  assign sum   = a ^ b;   // XOR
  assign carry = a & b;   // AND
endmodule
