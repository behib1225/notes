`timescale 1ns/1ps
// mux4.sv -- 4-to-1 multiplexer, 8-bit wide, written three ways
module mux4 (
  input  logic [7:0] d0, d1, d2, d3,
  input  logic [1:0] sel,
  output logic [7:0] y_assign,
  output logic [7:0] y_if,
  output logic [7:0] y_case
);
  // Style 1: continuous assignment with the conditional operator ?:
  assign y_assign = (sel == 2'd0) ? d0 :
                    (sel == 2'd1) ? d1 :
                    (sel == 2'd2) ? d2 : d3;

  // Style 2: procedural block with if/else
  always_comb begin
    if      (sel == 2'd0) y_if = d0;
    else if (sel == 2'd1) y_if = d1;
    else if (sel == 2'd2) y_if = d2;
    else                  y_if = d3;
  end

  // Style 3: procedural block with case
  always_comb begin
    case (sel)
      2'd0:    y_case = d0;
      2'd1:    y_case = d1;
      2'd2:    y_case = d2;
      default: y_case = d3;
    endcase
  end
endmodule
