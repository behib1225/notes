`timescale 1ns/1ps
// iir_biquad.sv -- one second-order section, direct form I:
//   y[n] = b0 x[n] + b1 x[n-1] + b2 x[n-2] - a1 y[n-1] - a2 y[n-2]
// Exact sum of the five products, ONE rounding to the internal format, saturation.
// One sample per clock at most: the feedback loop (multiply, add, round) must
// finish within one clock cycle, so it cannot be pipelined.
module iir_biquad #(
  parameter int SEC = 0,                        // which coefficient set (iir_coefs.svh)
  parameter int SW = 24, SF = 20,               // signal format: Q4.20
  parameter int CW = 18, CF = 16,               // coefficient format: Q2.16
  parameter int ACC_W = SW + CW + 3             // 45: five products, never overflows
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  input  logic signed [SW-1:0] x,
  output logic                 out_valid,
  output logic signed [SW-1:0] y
);
  `include "iir_coefs.svh"
  localparam logic signed [CW-1:0] B0 = iir_coef(SEC, 0), B1 = iir_coef(SEC, 1),
                                   B2 = iir_coef(SEC, 2), A1 = iir_coef(SEC, 3),
                                   A2 = iir_coef(SEC, 4);

  logic signed [SW-1:0]    x1, x2, y1, y2;      // the section's state
  logic signed [ACC_W-1:0] acc;
  logic signed [SW-1:0]    y0;
  logic                    unused_ovf;

  // the whole loop is combinational: from y1/y2 back to y1 in one clock
  assign acc = ACC_W'(B0 * x) + ACC_W'(B1 * x1) + ACC_W'(B2 * x2)
             - ACC_W'(A1 * y1) - ACC_W'(A2 * y2);

  requant #(.IN_W(ACC_W), .IN_F(SF + CF), .OUT_W(SW), .OUT_F(SF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(y0), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) begin
      {x1, x2, y1, y2} <= '0;                    // start at rest: the model assumes it
      out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        x2 <= x1;  x1 <= x;
        y2 <= y1;  y1 <= y0;
        y  <= y0;
      end
    end
  end
endmodule
