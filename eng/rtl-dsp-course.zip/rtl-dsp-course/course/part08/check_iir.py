#!/usr/bin/env python3
"""check_iir.py -- independent bit-exact check against iir_model.golden()."""
import sys
import numpy as np
from iir_model import coefficients, golden

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

x = from_hex("x.hex", 16)
y_rtl, y_ref = from_hex("y_actual.hex", 16), golden(x, coefficients())
ok = len(y_rtl) == len(y_ref) and np.all(y_rtl == y_ref)
print(f"PASS: {len(y_ref)} outputs bit-exact" if ok else "FAIL")
sys.exit(0 if ok else 1)
