#!/bin/sh
# run_iir.sh -- verify the IIR cascade.  Usage: ./run_iir.sh [seed] [n]
set -e
SEED=${1:-1}; N=${2:-3000}
python3 iir_model.py --seed "$SEED" --n "$N"
iverilog -g2012 -Wall -DDUT=iir_cascade -o sim_iir iir_cascade.sv iir_biquad.sv requant.sv tb_fir.sv
vvp -n sim_iir +N="$N" +SEED="$SEED"
python3 check_iir.py
