#!/usr/bin/env python3
"""measure_iir.py -- gain of the IIR RTL at 20 frequencies (each run also bit-exact checked)."""
import subprocess
import numpy as np
from scipy import signal
from iir_model import coefficients, golden, to_hex, design
from fixedpoint import quantize

N = 6000
subprocess.run(["iverilog", "-g2012", "-DDUT=iir_cascade", "-o", "msim", "iir_cascade.sv",
                "iir_biquad.sv", "requant.sv", "tb_fir.sv"], check=True)
def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)
def amplitude(y, f):
    n = np.arange(len(y)); return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))
cq = coefficients()
for f in np.round(np.arange(0.0125, 0.5, 0.025), 4):
    x = quantize(0.5 * np.cos(2 * np.pi * f * np.arange(N)), 16, 15)
    open("x.hex", "w").write("\n".join(to_hex(x, 16)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(golden(x, cq), 16)) + "\n")
    subprocess.run(["vvp", "-n", "msim", f"+N={N}"], check=True, capture_output=True)
    y = from_hex("y_actual.hex", 16)[1000:]                 # skip the slow start-up transient
    g = amplitude(y, f) / amplitude(x[1000:], f)
    _, H = signal.sosfreqz(design(), worN=[2 * np.pi * f])
    print(f"{f:.4f} {20*np.log10(g):8.2f} {20*np.log10(abs(H[0])):8.2f}")
