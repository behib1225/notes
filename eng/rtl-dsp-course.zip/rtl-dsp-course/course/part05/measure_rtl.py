#!/usr/bin/env python3
"""measure_rtl.py -- measure the moving_sum4 RTL's gain at several frequencies."""
import subprocess
import numpy as np

W, N, A = 16, 2000, 16000             # input width, samples, input amplitude

def to_hex(values, bits):
    mask = (1 << bits) - 1
    return [f"{int(v) & mask:0{(bits + 3) // 4}x}" for v in values]

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

def amplitude(y, f):
    """Amplitude of the component of y at f cycles/sample (projection onto a complex sinusoid)."""
    n = np.arange(len(y))
    return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))

subprocess.run(["iverilog", "-g2012", "-o", "sim", "moving_sum4.sv", "tb_moving_sum4_files.sv"], check=True)
for f in [0.0, 0.025, 0.05, 0.075, 0.1, 0.125, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45]:
    n = np.arange(N)
    x = np.round(A * np.cos(2 * np.pi * f * n)).astype(np.int64)
    y_ref = np.convolve(x, np.ones(4, dtype=np.int64))[:N]
    open("x.hex", "w").write("\n".join(to_hex(x, W)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(y_ref, W + 2)) + "\n")
    subprocess.run(["vvp", "-n", "sim", f"+N={N}"], check=True, capture_output=True)
    y = from_hex("y_actual.hex", W + 2)[100:]          # skip the start-up transient
    xs = x[100:]
    if f == 0.0:
        gain = np.mean(y) / (4 * np.mean(xs))
    else:
        gain = amplitude(y, f) / (4 * amplitude(xs, f))
    theory = 1.0 if f == 0 else abs(np.sin(4 * np.pi * f) / (4 * np.sin(np.pi * f)))
    print(f"f/fs={f:5.3f}  RTL gain={gain:.4f}  theory={theory:.4f}")
