`timescale 1ns/1ps
// tb_moving_sum4_files.sv -- file-driven testbench: Python makes the vectors,
// the testbench only moves numbers between the files and the design.
module tb_moving_sum4_files;
  localparam int W     = 16;
  localparam int MAX_N = 100_000;            // array capacity

  logic                clk = 1'b0, rst, in_valid, out_valid;
  logic signed [W-1:0] x;
  logic signed [W+1:0] y;

  logic [W-1:0] x_mem   [0:MAX_N-1];         // stimulus from Python
  logic [W+1:0] exp_mem [0:MAX_N-1];         // expected results from Python
  int n = 2000;                              // default; override with +N=...
  int sent = 0, got = 0, errors = 0, fd;
  int seed = 1;                              // override with +SEED=...

  moving_sum4 #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  initial begin #50_000_000; $fatal(1, "TIMEOUT"); end   // watchdog

  // ---- stimulus: one sample per in_valid cycle, with random idle gaps ----
  initial begin
    void'($value$plusargs("N=%d", n));       // read +N=1234 from the command line
    void'($value$plusargs("SEED=%d", seed)); // read +SEED=7
    void'($urandom(seed));                   // seed the testbench's random numbers
    $readmemh("x.hex", x_mem, 0, n - 1);          // load exactly n words
    $readmemh("y_expected.hex", exp_mem, 0, n - 1);
    fd = $fopen("y_actual.hex", "w");

    rst = 1'b1; in_valid = 1'b0; x = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;

    while (sent < n) begin
      in_valid = ($urandom_range(0, 3) != 0);
      x        = in_valid ? x_mem[sent] : 'x;  // x is undefined when not valid
      if (in_valid) sent++;
      @(negedge clk);
    end
    in_valid = 1'b0;
  end

  // ---- protocol check: out_valid must follow in_valid by exactly one cycle ----
  logic in_valid_d = 1'b0;
  always @(posedge clk) in_valid_d <= in_valid && !rst;
  always @(negedge clk) begin
    if (!rst)
      assert (out_valid === in_valid_d)
        else begin $error("out_valid=%b but in_valid one cycle earlier was %b", out_valid, in_valid_d); errors++; end
  end

  // ---- monitor: record and check every output the design marks valid ----
  always @(negedge clk) begin
    if (!rst && out_valid) begin
      assert (!$isunknown(y)) else $error("output %0d has unknown bits: %b", got, y);
      $fdisplay(fd, "%h", y);
      if (y !== exp_mem[got]) begin
        if (errors < 10)
          $display("FAIL sample %0d: got %0d, expected %0d", got, y, $signed(exp_mem[got]));
        errors++;
      end
      got++;
      if (got == n) begin
        $fclose(fd);
        if (errors == 0) $display("PASS: %0d samples match the Python model", n);
        else             $fatal(1, "FAILED: %0d of %0d samples wrong", errors, n);
        $finish;
      end
    end
  end
endmodule
