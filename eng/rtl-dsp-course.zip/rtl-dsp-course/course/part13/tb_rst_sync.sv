`timescale 1ns/1ps
module tb_rst_sync;
  logic clk = 1'b0, arst = 1'b0, rst;
  rst_sync dut (.*);
  always #5 clk = ~clk;                         // rising edges at 5, 15, 25, ... ns
  always @(rst) $display("%5.1f ns: rst = %b", $realtime, rst);
  initial begin
    #2   arst = 1'b1;                           // assert between clock edges
    #31  arst = 1'b0;                           // release at 33 ns, between edges
    #60  arst = 1'b1;  #1 arst = 1'b0;          // a 1 ns glitch at 93 ns
    #40  $finish;
  end
endmodule
