`timescale 1ns/1ps
// rst_sync.sv -- reset synchronizer: asserts asynchronously (at once, even without a clock),
// releases synchronously (two clock edges after the external reset ends), so that every
// flip-flop of the clock domain leaves reset on the same edge.
module rst_sync (
  input  logic clk,
  input  logic arst,          // external reset, asynchronous, active high
  output logic rst            // reset for the clk domain: async assert, sync release
);
  logic r1;
  always_ff @(posedge clk or posedge arst) begin
    if (arst) begin r1 <= 1'b1; rst <= 1'b1; end
    else      begin r1 <= 1'b0; rst <= r1;   end
  end
endmodule
