// axis_skid_formal.sv -- formal harness for axis_skid, using its ports only.
// The source sends a counting sequence (word i carries the value i); the harness checks that the
// output carries exactly the next expected count (no loss, no duplication, no reordering), that
// the output obeys AXI, and that at most two words are ever inside.
module axis_skid_formal (
  input logic clk,
  input logic rst,
  input logic s_tvalid, m_tready
);
  logic        s_tready, m_tvalid, m_tlast, s_tlast;
  logic [15:0] s_tdata, m_tdata;
  logic [15:0] n_in = '0, n_out = '0;         // words accepted, words delivered
  logic        f_skid_valid, f_skid_last;      // the formal-only ports of axis_skid
  logic [15:0] f_skid_data;
  axis_skid #(.W(16)) dut (.*);

  assign s_tdata = n_in;                       // word i carries i ...
  assign s_tlast = n_in[0];                    // ... and an alternating last flag

  logic init = 1'b1;
  always @(posedge clk) begin
    init <= 1'b0;
    if (rst) begin n_in <= '0; n_out <= '0; end
    else begin
      if (s_tvalid && s_tready) n_in  <= n_in + 1'b1;
      if (m_tvalid && m_tready) n_out <= n_out + 1'b1;
    end
  end
  always @(*) if (init) assume (rst);

  logic [15:0] inside;
  assign inside = n_in - n_out;
  always @(*) if (!init && !rst) begin
    assert (inside <= 16'd2);                  // never more than two words inside
    assert (m_tvalid == (inside != 16'd0));    // valid exactly when something is inside
    assert (s_tready == (inside != 16'd2));    // ready exactly when there is room
    if (m_tvalid) assert (m_tdata == n_out && m_tlast == n_out[0]);   // the right word, in order
    // internal invariant, needed for induction: the parked word is the one after the output word
    if (f_skid_valid) assert (f_skid_data == n_out + 16'd1 && f_skid_last == !n_out[0]);
  end
  // a valid source word is held until accepted (our source holds it by construction: s_tdata = n_in)
  always @(posedge clk) if (!init && !$past(rst) && $past(s_tvalid && !s_tready)) assume (s_tvalid);
  // the output obeys AXI: a valid word stays valid and unchanged until taken
  always @(posedge clk) if (!init && !$past(rst) && $past(m_tvalid && !m_tready))
    assert (m_tvalid && m_tdata == $past(m_tdata) && m_tlast == $past(m_tlast));
endmodule
