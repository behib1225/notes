`timescale 1ns/1ps
// tb_axis_skid.sv -- random valid on the input, random ready on the output; checks order,
// no loss, no duplication, and the AXI rule that a valid output holds until it is taken.
module tb_axis_skid;
  logic clk = 1'b0, rst, s_tvalid, s_tready, s_tlast, m_tvalid, m_tready, m_tlast;
  logic [15:0] s_tdata, m_tdata, prev_data;
  logic prev_stall = 1'b0;
  int sent = 0, got = 0, errors = 0, n = 20000, cycles = 0, busy = 0, ready_pct = 70;
  axis_skid dut (.*);
  always #5 clk = ~clk;
  initial begin #10_000_000; $fatal(1, "TIMEOUT"); end
  initial begin
    void'($value$plusargs("READY=%d", ready_pct));
    rst = 1'b1; s_tvalid = 1'b0; s_tdata = '0; s_tlast = 1'b0; m_tready = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
  end
  // source: offers word 'sent' and holds it until accepted (the AXI rule for a source)
  always @(negedge clk) if (!rst) begin
    if (!s_tvalid && sent < n && $urandom_range(0, 9) < 8) begin
      s_tvalid = 1'b1; s_tdata = 16'(sent); s_tlast = (sent % 16 == 15);
    end
    m_tready = ($urandom_range(0, 99) < ready_pct);
  end
  always @(posedge clk) if (!rst) begin
    cycles++;
    if (m_tvalid) busy++;
    // AXI rule on the output: once valid and not taken, it must stay valid with the same data
    if (prev_stall && !(m_tvalid && m_tdata == prev_data)) begin errors++; $display("FAIL: output changed while stalled"); end
    prev_stall = m_tvalid && !m_tready;  prev_data = m_tdata;
    if (m_tvalid && m_tready) begin
      if (m_tdata !== 16'(got) || m_tlast !== (got % 16 == 15)) begin
        if (errors < 5) $display("FAIL: got %0d (last %b), expected %0d", m_tdata, m_tlast, got); errors++;
      end
      got++;
    end
    if (s_tvalid && s_tready) begin sent++; #1 s_tvalid = 1'b0; end
    if (got == n) begin
      $display("%s: %0d words in order with ready %0d%%, %0d clock cycles, output valid %0d%% of the time",
               errors ? "FAILED" : "PASS", got, ready_pct, cycles, 100 * busy / cycles);
      $finish;
    end
  end
endmodule
