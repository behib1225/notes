`timescale 1ns/1ps
// axis_skid.sv -- AXI4-Stream register slice ("skid buffer"): registers the data path AND the
// ready path, at full throughput. When the output stalls, the one word already accepted
// (because s_tready was registered high) is held in the skid register instead of being lost.
module axis_skid #(
  parameter int W = 16
) (
  input  logic         clk, rst,
  // slave (input) side
  input  logic         s_tvalid,
  output logic         s_tready,
  input  logic [W-1:0] s_tdata,
  input  logic         s_tlast,
  // master (output) side
  output logic         m_tvalid,
  input  logic         m_tready,
  output logic [W-1:0] m_tdata,
  output logic         m_tlast
`ifdef FORMAL                                    // formal-only view of the skid register
  , output logic         f_skid_valid,
    output logic [W-1:0] f_skid_data,
    output logic         f_skid_last
`endif
);
  logic         skid_valid;
  logic [W-1:0] skid_data;
  logic         skid_last;

  assign s_tready = 1'b1;                          // BUG: accepts while stalled and full
`ifdef FORMAL
  assign f_skid_valid = skid_valid;  assign f_skid_data = skid_data;  assign f_skid_last = skid_last;
`endif

  always_ff @(posedge clk) begin
    if (rst) begin
      m_tvalid <= 1'b0;  skid_valid <= 1'b0;
    end else if (m_tready || !m_tvalid) begin    // the output register may load
      if (skid_valid) begin                      // the skid word goes first (keeps the order)
        m_tdata <= skid_data;  m_tlast <= skid_last;  m_tvalid <= 1'b1;  skid_valid <= 1'b0;
      end else if (s_tvalid) begin               // s_tready is 1 here
        m_tdata <= s_tdata;    m_tlast <= s_tlast;    m_tvalid <= 1'b1;
      end else begin
        m_tvalid <= 1'b0;
      end
    end else if (s_tvalid && s_tready) begin     // output stalled: park the accepted word
      skid_data <= s_tdata;  skid_last <= s_tlast;  skid_valid <= 1'b1;
    end
  end
endmodule
