`timescale 1ns/1ps
// tb_async_fifo.sv -- two unrelated clocks (+WP, +RP half-periods in ps), random writes and reads;
// checks order, no loss, no duplication, and that w_full / r_empty are respected.
module tb_async_fifo;
  logic wclk = 1'b0, rclk = 1'b0, wrst, rrst, w_en, r_en, w_full, r_empty;
  logic [15:0] w_data, r_data;
  int wp = 5000, rp = 3650, n = 20000, sent = 0, got = 0, errors = 0, maxfill = 0, wbias = 50, rbias = 50;
  async_fifo #(.W(16), .AW(4)) dut (.*);
  initial begin
    void'($value$plusargs("WP=%d", wp)); void'($value$plusargs("RP=%d", rp));
    void'($value$plusargs("WB=%d", wbias)); void'($value$plusargs("RB=%d", rbias));
  end
  always #(wp * 1ps) wclk = ~wclk;
  always #(rp * 1ps) rclk = ~rclk;
  initial begin #50_000_000; $fatal(1, "TIMEOUT"); end
  initial begin wrst = 1'b1; rrst = 1'b1; w_en = 0; r_en = 0; w_data = 0; #100ns; wrst = 1'b0; rrst = 1'b0; end

  // writer: on its own clock, writes the counting sequence when not full
  always @(posedge wclk) if (!wrst) begin
    if (w_en && !w_full) sent++;
    #1;
    w_en   = (sent < n) && ($urandom_range(0, 99) < wbias);
    w_data = 16'(sent);
  end
  // reader: on its own clock, checks every word it takes
  always @(posedge rclk) if (!rrst) begin
    if (r_en && !r_empty) begin
      if (r_data !== 16'(got)) begin if (errors < 5) $display("FAIL: read %0d, expected %0d", r_data, got); errors++; end
      got++;
    end
    if (16'(sent - got) > maxfill) maxfill = sent - got;
    #1;
    r_en = ($urandom_range(0, 99) < rbias);
    if (got == n) begin
      $display("%s: %0d words, write half-period %0d ps, read half-period %0d ps, at most %0d words in flight",
               errors ? "FAILED" : "PASS", got, wp, rp, maxfill);
      $finish;
    end
  end
endmodule
