#!/usr/bin/env python3
"""ddc_gen.py -- stimulus and expected outputs for tb_ddc2.sv (optionally with an FCW switch)."""
import argparse
import numpy as np
import ddc_model, fir_model
from ddc_lib import golden

p = argparse.ArgumentParser()
p.add_argument("--n", type=int, default=32768); p.add_argument("--seed", type=int, default=1)
p.add_argument("--switch", type=int, default=-1); p.add_argument("--fcw0", type=lambda s: int(s, 16), default=0x3d70a3d7)
p.add_argument("--fcw1", type=lambda s: int(s, 16), default=0x3d70a3d7); p.add_argument("--a", type=int, default=10)
a = p.parse_args()
x = ddc_model.stimulus(a.n, a.seed)
fcws = np.full(a.n, a.fcw0, dtype=np.int64)
if a.switch >= 0: fcws[a.switch:] = a.fcw1
yi, yq = golden(x, fcws, A=a.a)
open("x.hex", "w").write("\n".join(fir_model.to_hex(x, 16)) + "\n")
with open("y_expected.txt", "w") as f:
    for u, v in zip(yi, yq): f.write(f"{u} {v}\n")
np.save("fcws.npy", fcws)
print(f"seed {a.seed}: {a.n} inputs -> {len(yi)} outputs; FCW 0x{a.fcw0:08x}" + (f" -> 0x{a.fcw1:08x} at sample {a.switch}" if a.switch >= 0 else ""))
