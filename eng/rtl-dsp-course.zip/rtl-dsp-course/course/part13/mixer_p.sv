`timescale 1ns/1ps
// mixer_p.sv -- mixer.sv with two extra pipeline stages for timing closure:
// the LO values are registered after the table (the block RAM's output register), and the
// products are registered before the rounding. Same outputs as mixer.sv; latency 4 instead of 2.
module mixer_p #(
  parameter int W = 16, ACC_W = 32
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,
  input  logic [ACC_W-1:0]    fcw,
  output logic                out_valid,
  output logic signed [W-1:0] i_out, q_out
);
  logic                  lo_valid, v2, v3;
  logic signed [W-1:0]   lo_cos, lo_sin, x_d, lc, ls, x2;
  logic signed [2*W-1:0] pi_r, pq_r;

  nco #(.ACC_W(ACC_W), .W(W)) u_nco (
    .clk(clk), .rst(rst), .en(in_valid), .fcw(fcw),
    .out_valid(lo_valid), .cos_o(lo_cos), .sin_o(lo_sin)
  );

  always_ff @(posedge clk) begin
    if (rst) begin v2 <= 1'b0; v3 <= 1'b0; end
    else     begin v2 <= lo_valid; v3 <= v2; end
    if (in_valid) x_d <= x;
    // stage 2: table output register. The sine is negated HERE, not after the multiplier, to keep
    // the carry chain of the negation off the multiplier's path; exact, because the table's values
    // lie in -32767 .. 32767 (no -32768, whose negation would overflow).
    if (lo_valid) begin lc <= lo_cos; ls <= -lo_sin; x2 <= x_d; end
    if (v2) begin pi_r <= x2 * lc; pq_r <= x2 * ls; end               // stage 3: product register
  end

  logic signed [W-1:0] i_c, q_c;
  logic                ovf_i_unused, ovf_q_unused, v4;
  requant_p #(.IN_W(2*W), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_rqi (.clk(clk), .en(v3), .din(pi_r), .dout(i_c), .ovf(ovf_i_unused));
  requant_p #(.IN_W(2*W), .IN_F(2*W-2), .OUT_W(W), .OUT_F(W-1), .RND(1), .SAT(1'b1))
    u_rqq (.clk(clk), .en(v3), .din(pq_r), .dout(q_c), .ovf(ovf_q_unused));

  always_ff @(posedge clk) begin
    if (rst) begin v4 <= 1'b0; out_valid <= 1'b0; end
    else     begin v4 <= v3;   out_valid <= v4;   end
    if (v4) begin i_out <= i_c; q_out <= q_c; end                    // stage 5: saturation and output
  end
endmodule
