`timescale 1ns/1ps
// mac_p.sv -- mac.sv with the rounding split over two cycles (requant_p), for timing closure.
// Same results as mac.sv, one cycle later.
// Computes dot products: sum of a[i]*b[i] over a group of samples marked by first/last.
// Pipeline: input registers -> product register -> accumulator -> output register.
module mac_p #(
  parameter int A_W   = 16, A_F   = 15,      // a: Q1.15
  parameter int B_W   = 16, B_F   = 15,      // b: Q1.15
  parameter int ACC_W = 40,                  // accumulator: product width + 8 guard bits
  parameter int OUT_W = 16, OUT_F = 15       // result: Q1.15
) (
  input  logic                    clk,
  input  logic                    rst,
  input  logic                    in_valid,  // a, b, first, last are valid this cycle
  input  logic                    first,     // this product starts a new sum
  input  logic                    last,      // this product ends the sum: output it
  input  logic signed [A_W-1:0]   a,
  input  logic signed [B_W-1:0]   b,
  output logic                    out_valid,
  output logic signed [OUT_W-1:0] dout,
  output logic                    dout_ovf   // the result saturated
);
  localparam int P_W = A_W + B_W;            // full-precision product width
  localparam int P_F = A_F + B_F;            // and its fractional bits

  // ---- stage 1: input registers (map to the DSP block's A and B registers) ----
  logic signed [A_W-1:0] a_r;
  logic signed [B_W-1:0] b_r;
  logic                  v1, first1, last1;
  // ---- stage 2: product register (the DSP block's M register) ----
  logic signed [P_W-1:0] m_r;
  logic                  v2, first2, last2;
  // ---- stage 3: accumulator (the DSP block's P register) ----
  logic signed [ACC_W-1:0] acc;
  logic                    v3, last3;

  always_ff @(posedge clk) begin
    if (rst) begin
      v1 <= 1'b0;  v2 <= 1'b0;  v3 <= 1'b0;
    end else begin
      v1 <= in_valid;
      v2 <= v1;
      v3 <= v2;
    end
    // data registers need no reset: the valid bits say when they mean something
    a_r <= a;  b_r <= b;  first1 <= first;  last1 <= last;
    m_r <= a_r * b_r;     first2 <= first1; last2 <= last1;
    // (first ? 0 : acc) + product: the DSP block's Z multiplexer selects 0 or P
    if (v2) acc <= (first2 ? ACC_W'(0) : acc) + ACC_W'(m_r);
    last3 <= last2;
  end

  // ---- stages 4 and 5: round (registered inside requant_p), then saturate and register ----
  logic signed [OUT_W-1:0] rq;
  logic                    rq_ovf, v4;
  requant_p #(.IN_W(ACC_W), .IN_F(P_F), .OUT_W(OUT_W), .OUT_F(OUT_F), .RND(1), .SAT(1'b1))
    u_rq (.clk(clk), .en(v3 && last3), .din(acc), .dout(rq), .ovf(rq_ovf));

  always_ff @(posedge clk) begin
    if (rst) begin v4 <= 1'b0; out_valid <= 1'b0; end
    else     begin v4 <= v3 && last3; out_valid <= v4; end
    if (v4) begin
      dout     <= rq;
      dout_ovf <= rq_ovf;
    end
  end
endmodule
