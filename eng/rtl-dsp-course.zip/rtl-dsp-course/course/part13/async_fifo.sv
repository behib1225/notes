`timescale 1ns/1ps
// async_fifo.sv -- asynchronous FIFO for crossing between two unrelated clocks.
// Pointers are AW+1 bits (the extra bit tells "full" from "empty"); each pointer crosses to the
// other domain in GRAY code through a two-flip-flop synchronizer, so that at most one bit changes
// per step and a sample taken mid-change is either the old or the new value, never a third one.
module async_fifo #(
  parameter int W = 16, AW = 4                   // 2**AW words
) (
  // write side (wclk domain)
  input  logic         wclk, wrst,
  input  logic         w_en,
  input  logic [W-1:0] w_data,
  output logic         w_full,
  // read side (rclk domain)
  input  logic         rclk, rrst,
  input  logic         r_en,
  output logic [W-1:0] r_data,
  output logic         r_empty
);
  logic [W-1:0] mem [0:(1<<AW)-1];               // no reset: may become LUT RAM

  function automatic logic [AW:0] bin2gray(input logic [AW:0] b);
    bin2gray = b ^ (b >> 1);
  endfunction

  // ---- write domain ----
  logic [AW:0] wbin, wgray, rgray_w1, rgray_w2;
  logic [AW:0] wbin_next, wgray_next;
  assign wbin_next  = wbin + (AW+1)'(w_en && !w_full);
  assign wgray_next = bin2gray(wbin_next);
  always_ff @(posedge wclk) begin
    if (wrst) begin wbin <= '0; wgray <= '0; rgray_w1 <= '0; rgray_w2 <= '0; w_full <= 1'b0; end
    else begin
      if (w_en && !w_full) mem[wbin[AW-1:0]] <= w_data;
      wbin <= wbin_next;  wgray <= wgray_next;
      {rgray_w2, rgray_w1} <= {rgray_w1, rgray};               // synchronize the read pointer
      // full: the next write pointer equals the read pointer with the top two bits inverted
      w_full <= (wgray_next == {~rgray_w2[AW:AW-1], rgray_w2[AW-2:0]});
    end
  end

  // ---- read domain ----
  logic [AW:0] rbin, rgray, wgray_r1, wgray_r2;
  logic [AW:0] rbin_next, rgray_next;
  assign rbin_next  = rbin + (AW+1)'(r_en && !r_empty);
  assign rgray_next = bin2gray(rbin_next);
  always_ff @(posedge rclk) begin
    if (rrst) begin rbin <= '0; rgray <= '0; wgray_r1 <= '0; wgray_r2 <= '0; r_empty <= 1'b1; end
    else begin
      rbin <= rbin_next;  rgray <= rgray_next;
      {wgray_r2, wgray_r1} <= {wgray_r1, wgray};               // synchronize the write pointer
      r_empty <= (rgray_next == wgray_r2);
    end
  end
  assign r_data = mem[rbin[AW-1:0]];                           // first-word fall-through
endmodule
