`timescale 1ns/1ps
// ddc.sv -- digital down-converter: real Q1.15 input -> complex Q1.15 baseband, decimated by 16.
//   mixer (NCO + 2 multipliers) -> CIC (R = 8, N = 5) on I and Q -> FIR (31 taps, /2) on I and Q
// Rate constraint: input samples at least 4 clock cycles apart (see section 12.3).
module ddc_p2 #(
  parameter int W = 16
) (
  input  logic                clk, rst,
  input  logic                in_valid,
  input  logic signed [W-1:0] x,
  input  logic [31:0]         fcw,            // LO frequency control word
  output logic                out_valid,
  output logic signed [W-1:0] out_i, out_q,
  output logic                overrun          // sticky: a CIC output arrived while the FIR was busy
);
  // ---- stage 1: mixer ----
  logic                mix_valid;
  logic signed [W-1:0] mix_i, mix_q;
  mixer_p #(.W(W)) u_mix (
    .clk(clk), .rst(rst), .in_valid(in_valid), .x(x), .fcw(fcw),
    .out_valid(mix_valid), .i_out(mix_i), .q_out(mix_q)
  );

  // ---- stage 2: CIC decimators, one per channel, running in lockstep ----
  logic                cic_valid, cic_valid_q, cic_rdy_i, cic_rdy_q;
  logic signed [W-1:0] cic_i, cic_q;
  cic_decim_p #(.R(8), .NS(5)) u_cic_i (
    .clk(clk), .rst(rst), .in_valid(mix_valid), .in_ready(cic_rdy_i), .x(mix_i),
    .out_valid(cic_valid), .y(cic_i)
  );
  cic_decim_p #(.R(8), .NS(5)) u_cic_q (
    .clk(clk), .rst(rst), .in_valid(mix_valid), .in_ready(cic_rdy_q), .x(mix_q),
    .out_valid(cic_valid_q), .y(cic_q)
  );

  // ---- stage 3: compensating FIR decimators (serial, one MAC each) ----
  logic fir_rdy_i, fir_rdy_q, fir_valid_q;
  fir_decim_p #(.N(31), .M(2)) u_fir_i (
    .clk(clk), .rst(rst), .in_valid(cic_valid), .in_ready(fir_rdy_i), .x(cic_i),
    .out_valid(out_valid), .y(out_i)
  );
  fir_decim_p #(.N(31), .M(2)) u_fir_q (
    .clk(clk), .rst(rst), .in_valid(cic_valid), .in_ready(fir_rdy_q), .x(cic_q),
    .out_valid(fir_valid_q), .y(out_q)
  );

  // ---- a sample is lost if the CIC delivers one while the FIR is computing ----
  always_ff @(posedge clk) begin
    if (rst) overrun <= 1'b0;
    else if (cic_valid && !fir_rdy_i) overrun <= 1'b1;
  end

  // the Q-channel status signals duplicate the I channel's: tie them off for lint
  wire unused = cic_valid_q ^ cic_rdy_i ^ cic_rdy_q ^ fir_rdy_q ^ fir_valid_q;
endmodule
