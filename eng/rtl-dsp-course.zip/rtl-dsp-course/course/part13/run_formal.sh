#!/bin/sh
# run_formal.sh -- bounded model check and k-induction of a harness with yosys + yosys-smtbmc + z3
# Usage: ./run_formal.sh harness.sv design.sv top depth
set -e
H=$1; D=$2; TOP=$3; K=${4:-20}
yosys -q -p "read_verilog -sv -formal $D $H; prep -top $TOP; async2sync; dffunmap; write_smt2 -wires $TOP.smt2"
echo "-- bounded model check, $K cycles:"; yosys-smtbmc -s z3 -t "$K" "$TOP.smt2" | tail -1
echo "-- k-induction, $K cycles:";         yosys-smtbmc -s z3 -i -t "$K" "$TOP.smt2" | tail -1
