// async_fifo_formal.sv -- bounded formal check of async_fifo with two free-running, unrelated
// clocks. clk2fflogic turns both clocks into ordinary signals sampled by the formal global clock.
module async_fifo_formal (
  input logic wclk, rclk, w_en, r_en
);
  (* gclk *) logic gclk;                      // the formal global clock
  logic        wrst, rrst, w_full, r_empty;
  logic [15:0] w_data, r_data;
  logic [15:0] n_w = '0, n_r = '0;            // words written, words read
  logic [7:0]  step = '0;
  async_fifo #(.W(16), .AW(2)) dut (.*);     // 4 words: small, so the full condition is reached quickly

  assign w_data = n_w;                       // counting source
  always @(posedge gclk) if (step != 8'hff) step <= step + 1'b1;
  assign wrst = (step < 8'd8);               // both sides in reset for the first 8 steps ...
  assign rrst = (step < 8'd8);
  // ... with both clocks toggling at every step, so both sides really are reset (4 edges each)
  always @(*) if (step < 8'd8) assume (wclk == step[0] && rclk == step[0]);
  always @(posedge wclk) if (!wrst && w_en && !w_full) n_w <= n_w + 1'b1;
  always @(posedge rclk) if (!rrst && r_en && !r_empty) n_r <= n_r + 1'b1;
  always @(*) if (step > 8'd8) begin
    assert (16'(n_w - n_r) <= 16'd4);                    // never more words than places
    if (!r_empty) assert (r_data == n_r);                // the reader sees the next word, in order
  end
endmodule
