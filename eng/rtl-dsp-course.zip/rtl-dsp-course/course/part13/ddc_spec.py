#!/usr/bin/env python3
"""ddc_spec.py -- specification checks of the DDC output (Appendix B): they test what the design
is FOR, independently of the bit-exact model. Valid for the standard stimulus of ddc_model.py
(wanted tone 5.0 MHz, interferers 5.8 and 7.05 MHz, LO 4.8 MHz, output rate 1.25 MS/s)."""
import sys
import numpy as np
from measure import level

FS_OUT = 1.25e6
r = np.loadtxt("y_actual.txt", dtype=np.int64, ndmin=2)
z = (r[:, 0] + 1j * r[:, 1])[64:] / 32768.0                 # drop the filters' start-up
f = lambda hz: hz / FS_OUT
tone = level(z, f(0.2e6))
checks = [
    ("wanted tone at +0.2 MHz, -16.8 dBFS +- 1 dB", abs(tone - (-16.8)) <= 1.0, f"{tone:.1f} dBFS"),
    ("mirror at -0.2 MHz at least 60 dB down",      level(z, f(-0.2e6)) - tone <= -60, f"{level(z, f(-0.2e6)) - tone:.1f} dBc"),
    ("interferers near -0.25 MHz at least 60 dB down", level(z, f(-0.25e6)) - tone <= -60, f"{level(z, f(-0.25e6)) - tone:.1f} dBc"),
    ("nothing in the output band above the tone",     max(level(z, f(x)) for x in np.linspace(-0.6e6, 0.6e6, 49) if abs(x - 0.2e6) > 30e3) < tone, ""),
]
ok = True
for name, passed, value in checks:
    print(f"  spec {'PASS' if passed else 'FAIL'}: {name} {value}")
    ok &= passed
sys.exit(0 if ok else 1)
