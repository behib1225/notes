"""test_axis_skid.py -- cocotb test of axis_skid with a scoreboard and functional coverage.
A Python coroutine drives the AXI4-Stream source, another the sink; every cycle, a monitor checks
the data and counts which situations (coverage bins) have actually occurred."""
import os, random
import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ReadOnly, FallingEdge

BINS = ["empty (0 words inside)", "one word inside", "two words inside (skid used)",
        "input and output transfer in the same cycle", "source stalled (s_tvalid, !s_tready)",
        "output stalled 4+ cycles in a row", "tlast word held while stalled"]

async def run(dut, ready_pct, n=5000, seed=1):
    random.seed(seed)
    cocotb.start_soon(Clock(dut.clk, 10, unit="ns").start())
    dut.rst.value = 1; dut.s_tvalid.value = 0; dut.s_tdata.value = 0; dut.s_tlast.value = 0; dut.m_tready.value = 0
    for _ in range(3): await RisingEdge(dut.clk)
    dut.rst.value = 0
    hits = {b: 0 for b in BINS}
    sent = got = inside = stall_run = 0
    offering = False
    while got < n:
        await FallingEdge(dut.clk)                      # drive inputs between edges
        if not offering and sent < n and random.random() < 0.8:
            offering = True
            dut.s_tvalid.value = 1; dut.s_tdata.value = sent & 0xFFFF; dut.s_tlast.value = int(sent % 16 == 15)
        dut.m_tready.value = int(random.random() * 100 < ready_pct)
        await ReadOnly()                                # sample everything just before the edge
        sv, sr = int(dut.s_tvalid.value), int(dut.s_tready.value)
        mv, mr = int(dut.m_tvalid.value), int(dut.m_tready.value)
        s_xfer, m_xfer = sv and sr, mv and mr
        # coverage
        hits[BINS[min(inside, 2)]] += 1
        if s_xfer and m_xfer: hits[BINS[3]] += 1
        if sv and not sr:     hits[BINS[4]] += 1
        stall_run = stall_run + 1 if (mv and not mr) else 0
        if stall_run >= 4:    hits[BINS[5]] += 1
        if mv and not mr and int(dut.m_tlast.value): hits[BINS[6]] += 1
        # scoreboard
        if m_xfer:
            assert int(dut.m_tdata.value) == got & 0xFFFF, f"word {got}: got {int(dut.m_tdata.value)}"
            assert int(dut.m_tlast.value) == int(got % 16 == 15), f"word {got}: wrong tlast"
            got += 1
        if s_xfer: sent += 1
        inside += int(s_xfer) - int(m_xfer)
        assert 0 <= inside <= 2, f"{inside} words inside"
        await RisingEdge(dut.clk)
        if s_xfer:
            offering = False; dut.s_tvalid.value = 0
    missing = [b for b in BINS if hits[b] == 0]
    dut._log.info(f"m_tready {ready_pct}%: {n} words in order. Coverage:\n" +
                  "\n".join(f"    {'HIT ' if hits[b] else 'MISS'} {hits[b]:6d}  {b}" for b in BINS) +
                  f"\n  -> {len(BINS) - len(missing)} of {len(BINS)} bins covered")
    return missing

@cocotb.test()
async def always_ready(dut):
    """The output is always ready: passes, but leaves most of the design unexercised."""
    missing = await run(dut, ready_pct=100)
    dut._log.info(f"bins never reached: {missing}")

@cocotb.test()
async def backpressure(dut):
    """Random backpressure: must pass AND reach every coverage bin."""
    missing = await run(dut, ready_pct=50)
    assert not missing, f"coverage holes: {missing}"
