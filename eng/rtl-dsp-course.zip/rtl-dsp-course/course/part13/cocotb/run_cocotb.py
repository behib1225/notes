#!/usr/bin/env python3
"""run_cocotb.py -- build axis_skid with Icarus and run the cocotb tests."""
from cocotb_tools.runner import get_runner
r = get_runner("icarus")
r.build(sources=["axis_skid.sv"], hdl_toplevel="axis_skid", build_args=["-g2012"], always=True)
r.test(hdl_toplevel="axis_skid", test_module="test_axis_skid")
