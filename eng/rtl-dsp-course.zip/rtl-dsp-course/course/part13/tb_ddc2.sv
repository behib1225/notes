`timescale 1ns/1ps
// tb_ddc2.sv -- tb_ddc.sv hardened: I/Q lockstep assertions, an optional FCW change in the
// middle of the run (+SWITCH=k: from input sample k on, the FCW is +FCW1), seeded random gaps.
`ifndef DUT
  `define DUT ddc
`endif
module tb_ddc2;
  logic clk = 1'b0, rst, in_valid, out_valid, overrun;
  logic signed [15:0] x, out_i, out_q;
  logic [31:0] fcw = 32'h3d70a3d7, fcw1 = 32'h3d70a3d7;
  logic [1:0]  rsel = 2'd1;
  logic [15:0] x_mem [0:65535];
  int n = 32768, gap = 5, jit = 1, decim = 16, seed = 1, sw = -1, sent = 0, got = 0, errors = 0, fe, fo, ei, eq, cycles = 0;
  `DUT dut (.*);
  always #5 clk = ~clk;
  always @(posedge clk) cycles++;
  initial begin #200_000_000; $fatal(1, "TIMEOUT"); end

  // ---- the I and Q branches must stay in lockstep ----
  always @(negedge clk) if (!rst) begin
    assert (dut.cic_valid === dut.cic_valid_q) else $fatal(1, "I/Q CIC valid signals disagree");
    assert (dut.fir_rdy_i === dut.fir_rdy_q)   else $fatal(1, "I/Q FIR ready signals disagree");
    assert (dut.out_valid === dut.fir_valid_q) else $fatal(1, "I/Q output valid signals disagree");
    assert (!overrun) else $fatal(1, "OVERRUN: a sample was lost between the CIC and the FIR");
  end

  initial begin
    void'($value$plusargs("N=%d", n));
    void'($value$plusargs("GAP=%d", gap));
    void'($value$plusargs("SEED=%d", seed));
    void'($value$plusargs("JIT=%d", jit));           // 0: exactly GAP clocks per sample
    void'($value$plusargs("RSEL=%d", rsel));         // ddc_var only: R = 4, 8, 16
    decim = 8 << rsel;                               // outputs per input: 1 / (2R)
    void'($value$plusargs("SWITCH=%d", sw));
    void'($value$plusargs("FCW0=%h", fcw));
    void'($value$plusargs("FCW1=%h", fcw1));
    void'($urandom(seed));
    $readmemh("x.hex", x_mem, 0, n - 1);
    fe = $fopen("y_expected.txt", "r"); fo = $fopen("y_actual.txt", "w");
    if (fe == 0) $fatal(1, "y_expected.txt missing");
    rst = 1'b1; in_valid = 1'b0; x = '0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    while (sent < n) begin
      if (sent == sw) fcw = fcw1;                    // the NCO is phase-continuous (Part 9)
      in_valid = 1'b1; x = x_mem[sent]; sent++;
      @(negedge clk);
      in_valid = 1'b0; x = 'x;
      repeat (gap - 1 + (jit ? $urandom_range(0, 2) : 0)) @(negedge clk);
    end
  end

  always @(negedge clk) if (!rst && out_valid) begin
    void'($fscanf(fe, "%d %d\n", ei, eq));
    $fdisplay(fo, "%0d %0d", out_i, out_q);
    if (out_i !== 16'(ei) || out_q !== 16'(eq)) begin
      if (errors < 5) $display("FAIL output %0d: got %0d %0d, expected %0d %0d", got, out_i, out_q, ei, eq);
      errors++;
    end
    if (++got == n / decim) begin
      $fclose(fo);
      if (errors) $fatal(1, "FAILED: %0d of %0d outputs wrong", errors, got);
      $display("PASS: %0d complex outputs bit-exact, %0d clock cycles", got, cycles);
      $finish;
    end
  end
endmodule
