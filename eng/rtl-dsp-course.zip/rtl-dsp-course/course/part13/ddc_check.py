#!/usr/bin/env python3
"""ddc_check.py -- independent check: recompute the model from x.hex and fcws.npy, compare y_actual.txt."""
import sys
import numpy as np
from ddc_lib import golden
A = int(sys.argv[1]) if len(sys.argv) > 1 else 10
v = np.array([int(l, 16) for l in open("x.hex") if l.strip()], dtype=np.int64)
x = np.where(v >= 32768, v - 65536, v)
yi, yq = golden(x, np.load("fcws.npy"), A=A)
r = np.loadtxt("y_actual.txt", dtype=np.int64, ndmin=2)
ok = r.shape[0] == len(yi) and np.array_equal(r[:, 0], yi) and np.array_equal(r[:, 1], yq)
print(f"independent check: {'PASS' if ok else 'FAIL'} ({r.shape[0]} outputs)")
sys.exit(0 if ok else 1)
