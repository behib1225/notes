#!/bin/sh
# run_part13.sh -- re-verify everything in Part 13. Stops at the first failure.
set -e
echo "== 13.1 pipelined DDC (ddc_p2): bit-exact, independent check, specification checks"
SRC="ddc_p2.sv mixer_p.sv nco.sv cic_decim_p.sv fir_decim_p.sv mac_p.sv requant_p.sv"
iverilog -g2012 -Wall -DDUT=ddc_p2 -o sim_ddc_p2 $SRC tb_ddc2.sv
verilator --lint-only -Wall --top-module ddc_p2 $SRC
for SEED in 1 2; do
  rm -f x.hex y_expected.txt y_actual.txt fcws.npy
  python3 ddc_gen.py --seed $SEED
  vvp -n sim_ddc_p2 +SEED=$SEED +GAP=5 > sim.log 2>&1 || true; grep -E "PASS|FAIL|FATAL" sim.log; grep -q "^PASS" sim.log
  python3 ddc_check.py
  python3 ddc_spec.py
done
echo "== 13.2 skid buffer, random backpressure"
iverilog -g2012 -Wall -o sim_skid axis_skid.sv tb_axis_skid.sv
verilator --lint-only -Wall axis_skid.sv
for R in 100 50 30; do vvp -n sim_skid +READY=$R | grep -E "PASS|FAIL" | tee skid.log; grep -q PASS skid.log; done
echo "== 13.3 formal: skid buffer must pass, the broken copy must fail"
./run_formal.sh axis_skid_formal.sv axis_skid.sv axis_skid_formal 20 2>/dev/null | tee formal.log
[ "$(grep -c PASSED formal.log)" = 2 ]
./run_formal.sh axis_skid_formal.sv axis_skid_bug.sv axis_skid_formal 20 2>/dev/null | tee formal_bug.log
[ "$(grep -c FAILED formal_bug.log)" = 2 ]
echo "== 13.4 async FIFO: five clock ratios; reset of one side only must fail, of both must pass"
iverilog -g2012 -Wall -o sim_fifo async_fifo.sv tb_async_fifo.sv
verilator --lint-only -Wall async_fifo.sv
for A in "+WP=5000 +RP=3650" "+WP=3650 +RP=5000" "+WP=5000 +RP=11700 +WB=90 +RB=95" "+WP=11700 +RP=5000 +WB=95 +RB=90" "+WP=5000 +RP=5100 +WB=100 +RB=100"; do
  vvp -n sim_fifo $A | grep -E "PASS|FAIL" | tee fifo.log; grep -q PASS fifo.log
done
iverilog -g2012 -o sim_fifo_rst async_fifo.sv tb_async_fifo_rst.sv
vvp -n sim_fifo_rst +MODE=0 | grep -q "FAILED" && echo "one-side reset fails, as expected"
vvp -n sim_fifo_rst +MODE=1 | grep -q "PASS"   && echo "both-side reset passes"
echo "== 13.5 reset synchronizer"
iverilog -g2012 -Wall -o sim_rst rst_sync.sv tb_rst_sync.sv && vvp -n sim_rst | grep "rst ="
verilator --lint-only -Wall rst_sync.sv
echo "part 13: all checks passed"
