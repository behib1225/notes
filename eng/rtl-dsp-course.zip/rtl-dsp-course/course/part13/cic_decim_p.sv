`timescale 1ns/1ps
// cic_decim_p.sv -- cic_decim.sv with a PIPELINED comb section for timing closure: each comb
// stage is registered, triggered by a valid bit that travels with the data, and the rounding
// gets two stages of its own (requant_p). Same outputs as cic_decim.sv; NS + 2 more cycles of latency.
// Requires decimated samples at least NS + 2 clock cycles apart (always true for R >= NS + 2
// with one input per clock).
module cic_decim_p #(
  parameter int R  = 8,
  parameter int NS = 3,
  parameter int XW = 16, XF = 15,
  parameter int W  = XW + NS * $clog2(R)
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [XW-1:0] y
);
  localparam int RW = (R > 1) ? $clog2(R) : 1;
  assign in_ready = 1'b1;

  logic signed [W-1:0] integ  [0:NS-1];
  logic signed [W-1:0] comb_d [0:NS-1];          // comb delay registers
  logic signed [W-1:0] cs     [0:NS];            // registered comb stages: cs[0] = sampled integrator
  logic                cv     [0:NS];            // their valid bits
  logic [RW-1:0]       cnt;
  logic                dec;
  assign dec = in_valid && (cnt == RW'(R - 1));

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < NS; k++) begin integ[k] <= '0; comb_d[k] <= '0; end
      for (int k = 0; k <= NS; k++) cv[k] <= 1'b0;
      cnt <= '0;
    end else begin
      if (in_valid) begin
        integ[0] <= integ[0] + W'(x);
        for (int k = 1; k < NS; k++) integ[k] <= integ[k] + integ[k-1];
        cnt <= dec ? '0 : cnt + 1'b1;
      end
      // stage 0: sample the last integrator BEFORE this input's update (as cic_decim does)
      cv[0] <= dec;
      if (dec) cs[0] <= integ[NS-1];
      // comb stage k: one subtraction per clock, triggered by its valid bit
      for (int k = 0; k < NS; k++) begin
        cv[k+1] <= cv[k];
        if (cv[k]) begin
          cs[k+1]   <= cs[k] - comb_d[k];
          comb_d[k] <= cs[k];
        end
      end
    end
  end

  logic signed [XW-1:0] y_c;
  logic                 unused_ovf, rv;
  requant_p #(.IN_W(W), .IN_F(XF + NS * $clog2(R)), .OUT_W(XW), .OUT_F(XF), .RND(1), .SAT(1'b1))
    u_rq (.clk(clk), .en(cv[NS]), .din(cs[NS]), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) begin rv <= 1'b0; out_valid <= 1'b0; end
    else     begin rv <= cv[NS]; out_valid <= rv; end
    if (rv) y <= y_c;
  end
endmodule
