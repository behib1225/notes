`timescale 1ns/1ps
module tb_mod_counter;
  localparam int M = 10;
  logic clk = 1'b0, rst, en, tc;
  logic [$clog2(M)-1:0] count;
  int model = 0, errors = 0, wraps = 0;

  mod_counter #(.M(M)) dut (.clk(clk), .rst(rst), .en(en), .count(count), .tc(tc));
  always #5 clk = ~clk;

  initial begin
    rst = 1'b1; en = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    repeat (500) begin
      en = $urandom_range(0, 1);
      #1;                                         // let tc settle after en changes
      if (count !== model[$clog2(M)-1:0] || tc !== (en && model == M-1)) begin
        $display("FAIL at %0d ns: count=%0d tc=%b, expected %0d", $time, count, tc, model);
        errors++;
      end
      if (tc) wraps++;
      if (en) model = (model + 1) % M;            // value after the next rising edge
      @(negedge clk);
    end
    if (errors == 0) $display("PASS: 500 cycles, %0d wraps", wraps);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
