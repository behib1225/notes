`timescale 1ns/1ps
// reset_sync.sv -- asynchronous assert, synchronous de-assert
module reset_sync (
  input  logic clk,
  input  logic arst_n_in,   // raw reset from a button or another clock domain
  output logic arst_n_out   // safe to use as the async reset of this clock domain
);
  logic stage1;
  always_ff @(posedge clk or negedge arst_n_in) begin
    if (!arst_n_in) begin
      stage1     <= 1'b0;
      arst_n_out <= 1'b0;
    end else begin
      stage1     <= 1'b1;
      arst_n_out <= stage1;
    end
  end
endmodule
