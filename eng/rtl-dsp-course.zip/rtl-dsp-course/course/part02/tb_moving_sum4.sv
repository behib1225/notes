`timescale 1ns/1ps
// tb_moving_sum4.sv -- compares the hardware with a software model of the same filter
module tb_moving_sum4;
  localparam int W = 16;
  logic                clk = 1'b0, rst, in_valid, out_valid;
  logic signed [W-1:0] x;
  logic signed [W+1:0] y;
  int hist [0:2];                 // model's delay line: x[n-1], x[n-2], x[n-3]
  int exp_y, xi, errors = 0, checks = 0;
  logic exp_valid;

  moving_sum4 #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  // pick a test sample: mostly random, sometimes the extreme values
  function automatic int pick();
    case ($urandom_range(0, 9))
      0:       return -(2**(W-1));          // most negative: -32768
      1:       return  (2**(W-1)) - 1;      // most positive: +32767
      default: return $signed(W'($urandom));   // random W-bit value, read as signed
    endcase
  endfunction

  initial begin
    rst = 1'b1; in_valid = 1'b0; x = '0;
    hist[0] = 0;  hist[1] = 0;  hist[2] = 0;
    exp_y = 0;  exp_valid = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;

    repeat (2000) begin
      // 1. check the outputs produced by the previous rising edge
      if (y !== exp_y[W+1:0] || out_valid !== exp_valid) begin
        $display("FAIL at %0d ns: y=%0d valid=%b, expected %0d valid=%b",
                 $time, y, out_valid, exp_y, exp_valid);
        errors++;
      end
      if (out_valid) checks++;
      // 2. apply new inputs and predict the next outputs
      in_valid = $urandom_range(0, 3) != 0;   // a sample on about 3 cycles in 4
      xi = pick();
      x  = xi[W-1:0];
      exp_valid = in_valid;
      if (in_valid) begin
        exp_y   = xi + hist[0] + hist[1] + hist[2];
        hist[2] = hist[1];  hist[1] = hist[0];  hist[0] = xi;
      end
      @(negedge clk);
    end
    if (errors == 0) $display("PASS: %0d outputs checked", checks);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
