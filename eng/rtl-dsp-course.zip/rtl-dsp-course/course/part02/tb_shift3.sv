`timescale 1ns/1ps
module tb_shift3;
  logic clk = 1'b0, din;
  logic [2:0] q_nb, q_bl;
  shift3 dut (.*);
  always #5 clk = ~clk;
  initial begin
    din = 1'b0; repeat (3) @(negedge clk);   // flush with zeros
    din = 1'b1; @(negedge clk);              // a single 1 ...
    din = 1'b0;                              // ... then zeros again
    repeat (4) begin
      $display("q_nb = %b    q_bl = %b", q_nb, q_bl);
      @(negedge clk);
    end
    $finish;
  end
endmodule
