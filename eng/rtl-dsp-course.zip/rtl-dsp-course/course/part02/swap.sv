`timescale 1ns/1ps
// swap.sv -- the same intent written two ways
module swap (
  input  logic clk,
  input  logic load,
  output logic [3:0] a_nb, b_nb,     // swapped with non-blocking <=
  output logic [3:0] a_bl, b_bl      // "swapped" with blocking =
);
  always_ff @(posedge clk) begin
    if (load) begin a_nb <= 4'd1; b_nb <= 4'd2; end
    else      begin a_nb <= b_nb; b_nb <= a_nb; end
  end

  always_ff @(posedge clk) begin
    if (load) begin a_bl = 4'd1; b_bl = 4'd2; end
    else      begin a_bl = b_bl; b_bl = a_bl; end
  end
endmodule
