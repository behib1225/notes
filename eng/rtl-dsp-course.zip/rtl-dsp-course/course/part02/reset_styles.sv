`timescale 1ns/1ps
// reset_styles.sv -- the same 4-bit register with two kinds of reset
module reset_styles (
  input  logic       clk,
  input  logic       rst,     // synchronous reset, active-high
  input  logic       arst_n,  // asynchronous reset, active-low
  input  logic [3:0] d,
  output logic [3:0] q_sync,
  output logic [3:0] q_async
);
  // Synchronous: reset is just another input, sampled at the clock edge
  always_ff @(posedge clk) begin
    if (rst) q_sync <= '0;
    else     q_sync <= d;
  end

  // Asynchronous: the reset edge itself triggers the block, no clock needed
  always_ff @(posedge clk or negedge arst_n) begin
    if (!arst_n) q_async <= '0;
    else         q_async <= d;
  end
endmodule
