`timescale 1ns/1ps
// moving_sum4.sv -- y[n] = x[n] + x[n-1] + x[n-2] + x[n-3]
// One new sample per clock cycle in which in_valid = 1. Output is registered.
module moving_sum4 #(
  parameter int W = 16                          // input sample width (signed)
) (
  input  logic                clk,
  input  logic                rst,
  input  logic                in_valid,         // a new sample is on x this cycle
  input  logic signed [W-1:0] x,
  output logic                out_valid,        // y holds a new result this cycle
  output logic signed [W+1:0] y                 // W+2 bits: the sum of 4 values can't overflow
);
  logic signed [W-1:0] d1, d2, d3;              // x[n-1], x[n-2], x[n-3]: the delay line
  logic signed [W+1:0] sum;

  // Combinational adder: extend every operand to W+2 bits FIRST, then add
  assign sum = (W+2)'(x + d1 + d2 + d3);

  always_ff @(posedge clk) begin
    if (rst) begin
      d1 <= '0;  d2 <= '0;  d3 <= '0;
      y  <= '0;
      out_valid <= 1'b0;
    end else begin
      out_valid <= in_valid;
      if (in_valid) begin
        d1 <= x;                                // shift the delay line ...
        d2 <= d1;
        d3 <= d2;
        y  <= sum;                              // ... and register the result
      end
    end
  end
endmodule
