`timescale 1ns/1ps
module tb_swap;
  logic clk = 1'b0, load;
  logic [3:0] a_nb, b_nb, a_bl, b_bl;
  swap dut (.*);
  always #5 clk = ~clk;
  initial begin
    load = 1'b1; @(negedge clk);
    load = 1'b0;
    repeat (3) begin
      $display("non-blocking: a=%0d b=%0d    blocking: a=%0d b=%0d", a_nb, b_nb, a_bl, b_bl);
      @(negedge clk);
    end
    $finish;
  end
endmodule
