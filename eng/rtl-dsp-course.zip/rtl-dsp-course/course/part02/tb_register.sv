`timescale 1ns/1ps
// tb_register.sv -- clocked, self-checking testbench for register.sv
module tb_register;
  localparam int W = 8;
  logic         clk = 1'b0;
  logic         rst, en;
  logic [W-1:0] d, q;
  logic [W-1:0] model;             // what q should hold
  int           errors = 0;

  register #(.W(W)) dut (.clk(clk), .rst(rst), .en(en), .d(d), .q(q));

  always #5 clk = ~clk;            // 10 ns period: rising edges at 5, 15, 25, ...

  initial begin                    // watchdog: stop a simulation that hangs
    #100_000;
    $display("TIMEOUT");
    $finish;
  end

  initial begin
    $dumpfile("register.vcd");
    $dumpvars(0, tb_register);

    // reset for two cycles; inputs change only on the falling edge
    rst = 1'b1; en = 1'b0; d = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    model = '0;

    repeat (200) begin
      @(negedge clk);              // halfway between rising edges: everything is stable
      if (q !== model) begin
        $display("FAIL at %0d ns: q=%h expected %h", $time, q, model);
        errors++;
      end
      en = $urandom_range(0, 1);   // new random inputs for the next rising edge
      d  = $urandom;
      if (en) model = d;           // what q must hold after that edge
    end

    if (errors == 0) $display("PASS: 200 cycles correct");
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
