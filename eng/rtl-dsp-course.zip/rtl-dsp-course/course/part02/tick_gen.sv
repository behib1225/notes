`timescale 1ns/1ps
// tick_gen.sv -- a one-cycle pulse every DIV clock cycles (a clock ENABLE, not a clock)
module tick_gen #(
  parameter int DIV = 4                      // DIV >= 2
) (
  input  logic clk,
  input  logic rst,
  output logic tick
);
  logic [$clog2(DIV)-1:0] unused_count;

  mod_counter #(.M(DIV)) u_cnt (
    .clk(clk), .rst(rst), .en(1'b1), .count(unused_count), .tc(tick)
  );
endmodule
