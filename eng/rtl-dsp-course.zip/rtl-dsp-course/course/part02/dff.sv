`timescale 1ns/1ps
// dff.sv -- the simplest flip-flop: q takes the value of d at every rising clock edge
module dff (
  input  logic clk,
  input  logic d,
  output logic q
);
  always_ff @(posedge clk) begin
    q <= d;
  end
endmodule
