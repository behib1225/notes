`timescale 1ns/1ps
// mod_counter.sv -- counts 0, 1, ..., M-1, 0, 1, ... while en is high
module mod_counter #(
  parameter int M = 10,                      // modulus (number of states), M >= 2
  localparam int W = $clog2(M)               // bits needed to hold 0 .. M-1
) (
  input  logic         clk,
  input  logic         rst,                  // synchronous, active-high
  input  logic         en,                   // count enable
  output logic [W-1:0] count,
  output logic         tc                    // terminal count: high while count = M-1 and en = 1
);
  assign tc = en && (count == W'(M - 1));

  always_ff @(posedge clk) begin
    if (rst)
      count <= '0;
    else if (en) begin
      if (tc) count <= '0;                   // wrap from M-1 back to 0
      else    count <= count + 1'b1;
    end
  end
endmodule
