`timescale 1ns/1ps
// shift3.sv -- a 3-stage shift register, written right and wrong
module shift3 (
  input  logic clk,
  input  logic din,
  output logic [2:0] q_nb,   // correct: non-blocking
  output logic [2:0] q_bl    // wrong: blocking
);
  always_ff @(posedge clk) begin
    q_nb[0] <= din;
    q_nb[1] <= q_nb[0];
    q_nb[2] <= q_nb[1];
  end

  always_ff @(posedge clk) begin
    q_bl[0] = din;
    q_bl[1] = q_bl[0];   // reads the value JUST written above
    q_bl[2] = q_bl[1];
  end
endmodule
