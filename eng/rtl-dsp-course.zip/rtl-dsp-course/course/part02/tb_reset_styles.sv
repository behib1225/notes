`timescale 1ns/1ps
module tb_reset_styles;
  logic clk = 1'b0, rst = 1'b0, arst_n = 1'b1;
  logic [3:0] d = 4'hA, q_sync, q_async;
  reset_styles dut (.*);
  always #5 clk = ~clk;
  initial begin
    @(posedge clk); @(posedge clk);            // both registers now hold A
    #2;                                        // t = 17 ns, between edges
    rst = 1'b1; arst_n = 1'b0;                 // assert both resets
    #1 $display("t=%0d ns, 1 ns after reset asserted: q_sync=%h q_async=%h", $time, q_sync, q_async);
    @(posedge clk); #1;
    $display("t=%0d ns, just after the next edge:    q_sync=%h q_async=%h", $time, q_sync, q_async);
    $finish;
  end
endmodule
