`timescale 1ns/1ps
// register.sv -- W-bit register with synchronous reset and load enable
module register #(
  parameter int W = 8
) (
  input  logic         clk,
  input  logic         rst,    // synchronous, active-high
  input  logic         en,     // load enable
  input  logic [W-1:0] d,
  output logic [W-1:0] q
);
  always_ff @(posedge clk) begin
    if (rst)
      q <= '0;                 // '0 = all bits zero, whatever the width
    else if (en)
      q <= d;
    // no else: when en = 0, q keeps its value -- that is what a flip-flop does
  end
endmodule
