`timescale 1ns/1ps
// tb_mac.sv -- drives mac.sv from mac_in.txt with random gaps; writes mac_out.txt
module tb_mac;
  logic clk = 1'b0, rst, in_valid, first, last, out_valid, dout_ovf;
  logic signed [15:0] a, b, dout;
  int fd_in, fd_out, code, seed = 1, n_out = 0, n_ovf = 0;
  logic [15:0] ra, rb;
  int rf, rl;

  mac dut (.*);
  always #5 clk = ~clk;
  initial begin #20_000_000; $fatal(1, "TIMEOUT"); end

  initial begin
    void'($value$plusargs("SEED=%d", seed));
    void'($urandom(seed));
    fd_in  = $fopen("mac_in.txt", "r");
    fd_out = $fopen("mac_out.txt", "w");
    if (fd_in == 0 || fd_out == 0) $fatal(1, "cannot open files");
    rst = 1'b1; in_valid = 1'b0; a = '0; b = '0; first = 1'b0; last = 1'b0;
    repeat (3) @(negedge clk);
    rst = 1'b0;
    code = 4;
    while (code == 4) begin
      if ($urandom_range(0, 3) == 0) begin           // idle cycle about 1 time in 4
        in_valid = 1'b0; a = 'x; b = 'x; first = 1'bx; last = 1'bx;
      end else begin
        code = $fscanf(fd_in, "%h %h %d %d\n", ra, rb, rf, rl);   // 4 = one line read
        in_valid = (code == 4);
        a = ra; b = rb; first = rf[0]; last = rl[0];
      end
      @(negedge clk);
    end
    in_valid = 1'b0;
    repeat (10) @(negedge clk);                    // let the pipeline drain
    $fclose(fd_out);
    $display("%0d results, %0d saturated", n_out, n_ovf);
    $finish;
  end

  always @(negedge clk) if (!rst && out_valid) begin
    assert (!$isunknown(dout)) else $error("unknown output");
    $fdisplay(fd_out, "%0d", dout);
    n_out++;
    if (dout_ovf) n_ovf++;
  end
endmodule
