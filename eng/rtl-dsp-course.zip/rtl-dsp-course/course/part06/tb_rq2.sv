`timescale 1ns/1ps
// tb_requant.sv -- exhaustive: every 10-bit input through all six rounding/overflow variants
module tb_requant;
  localparam int IW = 10, IF = 6, OW = 12, OF = 5;
  logic signed [IW-1:0] din;
  logic signed [OW-1:0] d [0:5];
  logic                 o [0:5];
  int fd;

  // variant k: RND = k % 3, SAT = (k < 3)
  requant #(.IN_W(IW), .IN_F(IF), .OUT_W(OW), .OUT_F(OF), .RND(0), .SAT(1)) u0 (.din(din), .dout(d[0]), .ovf(o[0]));
  requant #(.IN_W(IW), .IN_F(IF), .OUT_W(OW), .OUT_F(OF), .RND(1), .SAT(1)) u1 (.din(din), .dout(d[1]), .ovf(o[1]));
  requant #(.IN_W(IW), .IN_F(IF), .OUT_W(OW), .OUT_F(OF), .RND(2), .SAT(1)) u2 (.din(din), .dout(d[2]), .ovf(o[2]));
  requant #(.IN_W(IW), .IN_F(IF), .OUT_W(OW), .OUT_F(OF), .RND(0), .SAT(0)) u3 (.din(din), .dout(d[3]), .ovf(o[3]));
  requant #(.IN_W(IW), .IN_F(IF), .OUT_W(OW), .OUT_F(OF), .RND(1), .SAT(0)) u4 (.din(din), .dout(d[4]), .ovf(o[4]));
  requant #(.IN_W(IW), .IN_F(IF), .OUT_W(OW), .OUT_F(OF), .RND(2), .SAT(0)) u5 (.din(din), .dout(d[5]), .ovf(o[5]));

  initial begin
    fd = $fopen("requant_out.txt", "w");
    for (int i = -(1 << (IW - 1)); i < (1 << (IW - 1)); i++) begin
      din = IW'(i);
      #1;
      $fdisplay(fd, "%0d %0d %0d %0d %0d %0d %0d", i, d[0], d[1], d[2], d[3], d[4], d[5]);
    end
    $fclose(fd);
    $display("wrote %0d input values", 1 << IW);
    $finish;
  end
endmodule
