module mul_demo;
  logic signed [15:0] a, b;        // Q1.15
  logic signed [31:0] p;           // Q2.30: full-precision product
  logic        [15:0] bu;          // the same bits, but declared unsigned
  logic signed [31:0] p_bad;
  logic signed [15:0] p_q15;       // product squeezed back into Q1.15
  initial begin
    a = 16'sh4000; b = 16'sh6000;            // 0.5 and 0.75
    p = a * b;
    $display("0.5 * 0.75: p = %h = %0d -> %f", p, p, $itor(p) / 2.0**30);
    a = 16'sh8000; b = 16'sh8000;            // -1 and -1
    p = a * b;
    $display("-1 * -1   : p = %h -> %f  (needs bit 30: Q2.30 has room)", p, $itor(p) / 2.0**30);
    p_q15 = p[30:15];                         // naive: keep Q1.15 bits
    $display("-1 * -1 kept as Q1.15 bits [30:15] = %h -> %f  (WRONG: +1 does not fit)", p_q15, $itor(p_q15) / 2.0**15);
    a = 16'shC000; bu = 16'h4000;            // -0.5 times +0.5, but b declared unsigned
    p_bad = a * bu;
    $display("-0.5 * 0.5 with an unsigned operand: %f (WRONG)", $itor(p_bad) / 2.0**30);
    p_bad = a * $signed(bu);
    $display("-0.5 * 0.5 with $signed           : %f", $itor(p_bad) / 2.0**30);
  end
endmodule
