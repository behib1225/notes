#!/usr/bin/env python3
"""check_requant.py -- compare every requant.sv output with fixedpoint.requant()."""
import sys
import numpy as np
from fixedpoint import requant

IF, OW, OF = 6, 6, 3
variants = [(r, o) for o in ("saturate", "wrap") for r in ("floor", "round", "convergent")]
data = np.loadtxt("requant_out.txt", dtype=np.int64)
x, rtl = data[:, 0], data[:, 1:]
bad = 0
for k, (rnd, ovf) in enumerate(variants):
    ref = requant(x, IF, OW, OF, rnd, ovf)
    n = int(np.sum(ref != rtl[:, k]))
    bad += n
    print(f"{rnd:10s} {ovf:8s}: {len(x)} inputs, {n} mismatches")
print("PASS" if bad == 0 else "FAIL")
sys.exit(1 if bad else 0)
