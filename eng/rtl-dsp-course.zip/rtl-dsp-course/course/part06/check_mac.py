#!/usr/bin/env python3
"""check_mac.py -- bit-exact check of mac.sv, plus its error against floating point."""
import sys
import numpy as np

exp = np.loadtxt("mac_expected.txt", dtype=np.int64, ndmin=1)
rtl = np.loadtxt("mac_out.txt", dtype=np.int64, ndmin=1)
ideal = np.load("mac_ideal.npy")
if len(rtl) != len(exp):
    print(f"FAIL: {len(rtl)} results, expected {len(exp)}"); sys.exit(1)
bad = np.flatnonzero(rtl != exp)
if bad.size:
    print(f"FAIL: {bad.size} mismatches, first at result {bad[0]}: rtl={rtl[bad[0]]} model={exp[bad[0]]}")
    sys.exit(1)
lsb = 2.0**-15
inside = np.abs(ideal) < 1 - lsb                 # results that did not need saturating
err = rtl[inside] * lsb - ideal[inside]
print(f"PASS: {len(rtl)} results bit-exact")
print(f"error vs floating point (unsaturated results): max {np.max(np.abs(err))/lsb:.3f} LSB, "
      f"mean {np.mean(err)/lsb:+.3f} LSB")
