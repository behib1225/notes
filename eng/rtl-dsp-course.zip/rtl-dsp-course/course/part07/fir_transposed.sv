`timescale 1ns/1ps
// fir_transposed.sv -- transposed-form FIR: every multiplier sees the same input sample,
// and a chain of registered partial sums replaces the delay line.
// Each stage: s[k] <= h[k]*x + s[k+1]. Critical path: one multiply + one add.
module fir_transposed #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int ACC_W = XW + CW + $clog2(N),
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  assign in_ready = 1'b1;

  logic signed [XW-1:0]    x_r;                     // registered input sample
  logic signed [ACC_W-1:0] s [1:N-1];               // registered partial sums
  logic signed [ACC_W-1:0] acc;                     // y before rounding
  logic                    v1, v2;

  always_ff @(posedge clk) begin
    if (in_valid) x_r <= x;
    if (rst) begin
      for (int k = 1; k < N; k++) s[k] <= '0;       // start at rest, like the model
    end else if (v1) begin
      // one new sample: every partial sum moves one step toward the output
      acc      <= ACC_W'(x_r * fir_coef(0)) + s[1];
      for (int k = 1; k < N - 1; k++)
        s[k]   <= ACC_W'(x_r * fir_coef(k)) + s[k+1];
      s[N-1]   <= ACC_W'(x_r * fir_coef(N - 1));     // the end of the chain adds nothing
    end
  end

  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) {v1, v2, out_valid} <= '0;
    else     {v1, v2, out_valid} <= {in_valid, v1, v2};
    if (v2) y <= y_c;
  end
endmodule
