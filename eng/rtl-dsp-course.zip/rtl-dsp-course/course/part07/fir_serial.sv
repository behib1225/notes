`timescale 1ns/1ps
// fir_serial.sv -- time-multiplexed FIR: one MAC (mac.sv, Part 6) reused N times per sample.
// Controller: accept a sample, then feed taps 0..N-1 to the MAC, one per clock.
// Throughput: one sample per N+1 clocks. Uses valid/ready on the input.
module fir_serial #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int KW = $clog2(N);

  typedef enum logic {S_IDLE, S_RUN} state_t;
  state_t               state;
  logic [KW-1:0]        k;                         // which tap the MAC gets this cycle
  logic signed [XW-1:0] taps [0:N-1];

  assign in_ready = (state == S_IDLE);

  // ---- controller + delay line ----
  always_ff @(posedge clk) begin
    if (rst) begin
      state <= S_IDLE;
      k     <= '0;
      for (int i = 0; i < N; i++) taps[i] <= '0;
    end else begin
      case (state)
        S_IDLE: if (in_valid) begin               // in_ready is 1 here: a transfer
          taps[0] <= x;
          for (int i = 1; i < N; i++) taps[i] <= taps[i-1];
          k     <= '0;
          state <= S_RUN;
        end
        S_RUN: begin
          k <= k + 1'b1;
          if (k == KW'(N - 1)) state <= S_IDLE;
        end
        default: state <= S_IDLE;
      endcase
    end
  end

  // ---- datapath: the Part 6 MAC, fed one tap per clock ----
  logic mac_ovf_unused;
  mac #(.A_W(XW), .A_F(XF), .B_W(CW), .B_F(CF), .ACC_W(XW + CW + KW + 1),
        .OUT_W(YW), .OUT_F(YF)) u_mac (
    .clk(clk), .rst(rst),
    .in_valid(state == S_RUN),
    .first(k == '0),
    .last(k == KW'(N - 1)),
    .a(taps[k]),
    .b(fir_coef(32'(k))),
    .out_valid(out_valid), .dout(y), .dout_ovf(mac_ovf_unused)
  );
endmodule
