#!/usr/bin/env python3
"""measure_fir.py -- measure an FIR RTL's gain in dB at many frequencies with sine inputs."""
import subprocess, sys
import numpy as np
from scipy.signal import firwin, freqz
from fir_model import coefficients, golden, to_hex
from fixedpoint import quantize

DUT = sys.argv[1] if len(sys.argv) > 1 else "fir_transposed"
N = 4000
subprocess.run(["iverilog", "-g2012", f"-DDUT={DUT}", "-o", "msim", f"{DUT}.sv",
                "requant.sv", "mac.sv", "tb_fir.sv"], check=True)

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

def amplitude(y, f):
    n = np.arange(len(y))
    return 2 * abs(np.mean(y * np.exp(-2j * np.pi * f * n)))

hq = coefficients()
for f in np.round(np.arange(0.0125, 0.5, 0.025), 4):
    x = quantize(0.9 * np.cos(2 * np.pi * f * np.arange(N)), 16, 15)
    open("x.hex", "w").write("\n".join(to_hex(x, 16)) + "\n")
    open("y_expected.hex", "w").write("\n".join(to_hex(golden(x, hq), 16)) + "\n")
    subprocess.run(["vvp", "-n", "msim", f"+N={N}"], check=True, capture_output=True)
    y = from_hex("y_actual.hex", 16)[200:]
    g = amplitude(y, f) / amplitude(x[200:], f)
    _, H = freqz(firwin(32, 0.2), worN=[2 * np.pi * f])
    print(f"{f:.4f} {20*np.log10(g):8.2f} {20*np.log10(abs(H[0])):8.2f}")
