#!/usr/bin/env python3
"""check_fir.py -- independent bit-exact check of y_actual.hex against the golden model."""
import sys
import numpy as np
from fir_model import coefficients, golden

def from_hex(path, bits):
    v = np.array([int(l, 16) for l in open(path) if l.strip()], dtype=np.int64)
    return np.where(v >= 1 << (bits - 1), v - (1 << bits), v)

x = from_hex("x.hex", 16)
y_rtl = from_hex("y_actual.hex", 16)
y_ref = golden(x, coefficients())
if len(y_rtl) != len(y_ref) or np.any(y_rtl != y_ref):
    print("FAIL"); sys.exit(1)
print(f"PASS: {len(y_ref)} outputs bit-exact")
