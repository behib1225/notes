`timescale 1ns/1ps
// fir_symmetric.sv -- direct form that exploits h[k] = h[N-1-k]:
// add the two samples that share a coefficient first, then multiply once.
// N/2 multipliers instead of N. Requires even N and symmetric coefficients.
module fir_symmetric #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int ACC_W = XW + CW + $clog2(N),
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  localparam int H = N / 2;                         // number of coefficient pairs
  assign in_ready = 1'b1;

  logic signed [XW-1:0]    taps [0:N-1];
  logic signed [XW:0]      pre  [0:H-1];            // x[n-k] + x[n-(N-1-k)]: one bit wider
  logic signed [XW+CW:0]   prod [0:H-1];
  logic signed [ACC_W-1:0] sum_c, acc;
  logic                    v1, v2, v3, v4;

  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < N; k++) taps[k] <= '0;
    end else if (in_valid) begin
      taps[0] <= x;
      for (int k = 1; k < N; k++) taps[k] <= taps[k-1];
    end
  end
  // stage 2: pre-adders (the DSP48E1's D + A pre-adder)
  always_ff @(posedge clk) begin
    for (int k = 0; k < H; k++) pre[k] <= (XW+1)'(taps[k]) + (XW+1)'(taps[N-1-k]);
  end
  // stage 3: half as many multipliers
  always_ff @(posedge clk) begin
    for (int k = 0; k < H; k++) prod[k] <= pre[k] * fir_coef(k);
  end
  // stage 4: sum
  always_comb begin
    sum_c = '0;
    for (int k = 0; k < H; k++) sum_c += ACC_W'(prod[k]);
  end
  always_ff @(posedge clk) acc <= sum_c;

  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) {v1, v2, v3, v4, out_valid} <= '0;
    else     {v1, v2, v3, v4, out_valid} <= {in_valid, v1, v2, v3, v4};
    if (v4) y <= y_c;
  end
endmodule
