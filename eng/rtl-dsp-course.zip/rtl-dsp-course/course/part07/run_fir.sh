#!/bin/sh
# run_fir.sh -- verify one FIR architecture.  Usage: ./run_fir.sh fir_direct [seed] [n]
set -e
DUT=$1; SEED=${2:-1}; N=${3:-3000}
python3 fir_model.py --seed "$SEED" --n "$N"
iverilog -g2012 -Wall -DDUT="$DUT" -o sim_$DUT "$DUT.sv" requant.sv mac.sv tb_fir.sv
vvp -n sim_$DUT +N="$N" +SEED="$SEED"
python3 check_fir.py
