`timescale 1ns/1ps
// fir_direct.sv -- direct-form FIR: delay line, N parallel multipliers, one big sum.
// Accepts one sample per clock. Latency: 4 cycles.
module fir_direct #(
  parameter int N = 32, XW = 16, XF = 15, CW = 18, CF = 17,
  parameter int ACC_W = XW + CW + $clog2(N),           // 39: exact sum, never overflows
  parameter int YW = 16, YF = 15
) (
  input  logic                 clk, rst,
  input  logic                 in_valid,
  output logic                 in_ready,
  input  logic signed [XW-1:0] x,
  output logic                 out_valid,
  output logic signed [YW-1:0] y
);
  `include "fir_coefs.svh"
  assign in_ready = 1'b1;                               // never stalls

  logic signed [XW-1:0]    taps [0:N-1];                // taps[k] = x[n-k]
  logic signed [XW+CW-1:0] prod [0:N-1];
  logic signed [ACC_W-1:0] sum_c, acc;
  logic                    v1, v2, v3;

  // stage 1: shift the new sample into the delay line
  // (reset to zero: the golden model assumes the filter starts at rest)
  always_ff @(posedge clk) begin
    if (rst) begin
      for (int k = 0; k < N; k++) taps[k] <= '0;
    end else if (in_valid) begin
      taps[0] <= x;
      for (int k = 1; k < N; k++) taps[k] <= taps[k-1];
    end
  end
  // stage 2: N products, each registered (maps to the DSP blocks' M registers)
  always_ff @(posedge clk) begin
    for (int k = 0; k < N; k++) prod[k] <= taps[k] * fir_coef(k);
  end
  // stage 3: one big sum of all N products
  always_comb begin
    sum_c = '0;
    for (int k = 0; k < N; k++) sum_c += ACC_W'(prod[k]);
  end
  always_ff @(posedge clk) acc <= sum_c;
  // stage 4: round and saturate once
  logic signed [YW-1:0] y_c;
  logic                 unused_ovf;
  requant #(.IN_W(ACC_W), .IN_F(XF + CF), .OUT_W(YW), .OUT_F(YF), .RND(1), .SAT(1'b1))
    u_rq (.din(acc), .dout(y_c), .ovf(unused_ovf));

  always_ff @(posedge clk) begin
    if (rst) {v1, v2, v3, out_valid} <= '0;
    else     {v1, v2, v3, out_valid} <= {in_valid, v1, v2, v3};
    if (v3) y <= y_c;
  end
endmodule
