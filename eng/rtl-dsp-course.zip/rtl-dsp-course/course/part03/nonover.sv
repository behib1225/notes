`timescale 1ns/1ps
// detect1011_moore.sv -- Moore FSM: found = 1 for one cycle after the input
// has shown the bits 1,0,1,1 (oldest first). Overlapping patterns count.
module detect1011_moore (
  input  logic clk,
  input  logic rst,        // synchronous, active-high
  input  logic din,        // one serial bit per clock cycle
  output logic found
);
  // 1. The states: one name per "how much of the pattern have I seen?"
  typedef enum logic [2:0] {
    S_IDLE,    // nothing useful seen yet
    S_1,       // seen "1"
    S_10,      // seen "10"
    S_101,     // seen "101"
    S_1011     // seen "1011": the pattern is complete
  } state_t;

  state_t state, next;

  // 2. The state register: the only flip-flops in the FSM
  always_ff @(posedge clk) begin
    if (rst) state <= S_IDLE;
    else     state <= next;
  end

  // 3. Next-state logic: combinational, a direct copy of the state diagram
  always_comb begin
    next = state;                          // default: stay
    case (state)
      S_IDLE: if (din) next = S_1;     else next = S_IDLE;
      S_1:    if (din) next = S_1;     else next = S_10;
      S_10:   if (din) next = S_101;   else next = S_IDLE;
      S_101:  if (din) next = S_1011;  else next = S_10;
      S_1011: if (din) next = S_1;     else next = S_IDLE;
      default: next = S_IDLE;              // unreachable codes 5..7: recover
    endcase
  end

  // 4. Output logic: Moore, so it depends on the state only
  assign found = (state == S_1011);
endmodule
