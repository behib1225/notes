`timescale 1ns/1ps
module pinok (input logic clk, rst, start, input logic [7:0] a, b, output logic done);
  logic busy;
  seq_mult u (.clk(clk), .rst(rst), .start(start), .a(a), .b(b), .busy(busy), .done(done), .product());
endmodule
