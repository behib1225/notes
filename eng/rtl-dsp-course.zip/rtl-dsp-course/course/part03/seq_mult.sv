`timescale 1ns/1ps
// seq_mult.sv -- top level: controller + datapath
module seq_mult #(
  parameter int W = 8
) (
  input  logic           clk,
  input  logic           rst,
  input  logic           start,
  input  logic [W-1:0]   a, b,
  output logic           busy,
  output logic           done,
  output logic [2*W-1:0] product
);
  logic load, step, last;   // the wires between the two halves

  mult_ctrl u_ctrl (
    .clk(clk), .rst(rst), .start(start), .last(last),
    .load(load), .step(step), .busy(busy), .done(done)
  );

  mult_datapath #(.W(W)) u_dp (
    .clk(clk), .load(load), .step(step), .a_in(a), .b_in(b),
    .last(last), .product(product)
  );
endmodule
