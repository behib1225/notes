module pinbad (input logic clk, rst, start, input logic [7:0] a, b, output logic done);
  logic busy; logic [15:0] product;
  seq_mult u (.clk(clk), .rst(rst), .start(start), .a(a), .b(b), .busy(busy), .done(done));
endmodule
