`timescale 1ns/1ps
// detect1011_mealy.sv -- Mealy FSM: found = 1 in the SAME cycle as the
// final 1 of the pattern 1,0,1,1. Overlapping patterns count.
module detect1011_mealy_reg (
  input  logic clk,
  input  logic rst,
  input  logic din,
  output logic found_r
);
  typedef enum logic [1:0] {S_IDLE, S_1, S_10, S_101} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_IDLE;
    else     state <= next;
  end

  always_comb begin
    next = state;
    case (state)
      S_IDLE: if (din) next = S_1;     else next = S_IDLE;
      S_1:    if (din) next = S_1;     else next = S_10;
      S_10:   if (din) next = S_101;   else next = S_IDLE;
      S_101:  if (din) next = S_1;     else next = S_10;     // after "1011", the last "1" may start a new match
      default: next = S_IDLE;
    endcase
  end

  // Registered Mealy output: same logic, stored in a flip-flop
  always_ff @(posedge clk) begin
    if (rst) found_r <= 1'b0;
    else     found_r <= (state == S_101) && din;
  end
endmodule
