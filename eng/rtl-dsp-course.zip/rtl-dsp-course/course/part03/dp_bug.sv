`timescale 1ns/1ps
// mult_datapath.sv -- registers and arithmetic for a W x W shift-and-add multiplier
// (after Mano's binary multiplier: accumulator A, multiplier Q, multiplicand B, counter P)
module mult_datapath #(
  parameter  int W  = 8,
  localparam int PW = $clog2(W)            // counter width: holds 0 .. W-1
) (
  input  logic           clk,
  input  logic           load,             // control: initialize for a new product
  input  logic           step,             // control: one add-and-shift step
  input  logic [W-1:0]   a_in, b_in,       // operands, sampled when load = 1
  output logic           last,             // status: this is the final step
  output logic [2*W-1:0] product           // valid after the final step
);
  logic [W-1:0]  A, B, Q;
  logic [PW-1:0] P;
  logic [W:0]    sum;                      // W+1 bits: carry out of A + B

  // Combinational: add B to A only if the current multiplier bit is 1
  assign sum  = Q[0] ? ({1'b0, A} + {1'b0, B}) : {1'b0, A};
  assign last = (P == '0);

  always_ff @(posedge clk) begin
    if (load) begin
      A <= '0;
      B <= b_in;                           // multiplicand
      Q <= a_in;                           // multiplier, consumed one bit per step
      P <= PW'(W - 2);                     // W steps: W-1 down to 0
    end else if (step) begin
      // add, then shift {carry, A, Q} right by one -- all in one clock edge:
      // the carry (sum[W]) lands in A's MSB, Q's LSB (already used) falls off
      {A, Q} <= {sum, Q[W-1:1]};
      P <= P - 1'b1;
    end
  end

  assign product = {A, Q};
endmodule
