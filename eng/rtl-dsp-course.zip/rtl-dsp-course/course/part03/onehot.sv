module onehot (input logic clk, rst, din, output logic found);
  typedef enum logic [4:0] {
    S_IDLE = 5'b00001, S_1 = 5'b00010, S_10 = 5'b00100, S_101 = 5'b01000, S_1011 = 5'b10000
  } state_t;
  state_t state, next;
  always_ff @(posedge clk) if (rst) state <= S_IDLE; else state <= next;
  always_comb begin
    next = state;
    case (state)
      S_IDLE: if (din) next = S_1;    else next = S_IDLE;
      S_1:    if (din) next = S_1;    else next = S_10;
      S_10:   if (din) next = S_101;  else next = S_IDLE;
      S_101:  if (din) next = S_1011; else next = S_10;
      S_1011: if (din) next = S_1;    else next = S_10;
      default: next = S_IDLE;
    endcase
  end
  assign found = (state == S_1011);
endmodule
