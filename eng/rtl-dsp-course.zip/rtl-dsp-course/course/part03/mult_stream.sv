`timescale 1ns/1ps
// mult_stream.sv -- seq_mult with a valid/ready input and a valid output
module mult_stream #(
  parameter int W = 8
) (
  input  logic           clk,
  input  logic           rst,
  input  logic           in_valid,     // source: a, b hold a new operand pair
  output logic           in_ready,     // this block: I can accept a pair now
  input  logic [W-1:0]   a, b,
  output logic           out_valid,    // one-cycle pulse: product is valid
  output logic [2*W-1:0] product
);
  logic busy, start;

  assign in_ready = !busy;                  // ready whenever the multiplier is idle
  assign start    = in_valid && in_ready;   // a transfer happens on this edge

  seq_mult #(.W(W)) u_mult (
    .clk(clk), .rst(rst), .start(start), .a(a), .b(b),
    .busy(busy), .done(out_valid), .product(product)
  );
endmodule
