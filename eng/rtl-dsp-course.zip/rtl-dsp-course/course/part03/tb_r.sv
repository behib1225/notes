`timescale 1ns/1ps
// tb_detect1011.sv -- runs both detectors on the same random bit stream
module tb_detect1011;
  logic clk = 1'b0, rst, din, found_moore, found_mealy;
  logic [3:0] last4;              // model: the last four bits, newest in bit 0
  logic exp_mealy, exp_moore;
  int errors = 0, hits = 0;

  detect1011_moore u_moore (.clk(clk), .rst(rst), .din(din), .found(found_moore));
  detect1011_mealy u_mealy (.clk(clk), .rst(rst), .din(din), .found(found_mealy));
  logic found_r;
  detect1011_mealy_reg u_r (.clk(clk), .rst(rst), .din(din), .found_r(found_r));

  always #5 clk = ~clk;

  initial begin
    rst = 1'b1; din = 1'b0; last4 = '0; exp_moore = 1'b0;
    repeat (2) @(negedge clk);
    rst = 1'b0;

    repeat (5000) begin
      din = $urandom_range(0, 1);
      // Mealy: found as soon as the 4th bit is on the input
      exp_mealy = ({last4[2:0], din} == 4'b1011);
      #1;
      if (found_mealy !== exp_mealy || found_moore !== exp_moore || found_r !== exp_moore) begin
        $display("FAIL at %0d ns: mealy=%b (exp %b) moore=%b (exp %b)",
                 $time, found_mealy, exp_mealy, found_moore, exp_moore);
        errors++;
      end
      if (exp_mealy) hits++;
      last4     = {last4[2:0], din};   // the DUTs take this bit at the next edge
      exp_moore = exp_mealy;           // Moore reports it one cycle later
      @(negedge clk);
    end
    if (errors == 0) $display("PASS: 5000 bits, %0d patterns found", hits);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
