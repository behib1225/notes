`timescale 1ns/1ps
module tbx; logic clk=0, rst=0, din=0, f; detect1011_moore u(.clk(clk),.rst(rst),.din(din),.found(f)); always #5 clk=~clk;
initial begin #1 $display("t=1  state=%b", u.state); #10 $display("t=11 state=%b (%s)", u.state, u.state.name()); $finish; end endmodule
