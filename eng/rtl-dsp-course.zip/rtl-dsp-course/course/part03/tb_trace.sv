`timescale 1ns/1ps
module tb_trace;
  logic clk = 1'b0, rst, din, fmo, fme;
  logic [0:9] bits = 10'b1011011010;
  detect1011_moore u1 (.clk(clk), .rst(rst), .din(din), .found(fmo));
  detect1011_mealy u2 (.clk(clk), .rst(rst), .din(din), .found(fme));
  always #5 clk = ~clk;
  initial begin
    rst = 1; din = 0; @(negedge clk); rst = 0;
    $display("cycle din  moore_state  found_moore found_mealy");
    for (int i = 0; i < 10; i++) begin
      din = bits[i]; #1;
      $display("%3d    %b    %-8s     %b           %b", i, din, u1.state.name(), fmo, fme);
      @(negedge clk);
    end
    $finish;
  end
endmodule
