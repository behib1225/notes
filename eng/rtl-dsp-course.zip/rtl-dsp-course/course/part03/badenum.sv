module badenum; typedef enum logic [1:0] {A, B, C, D, E} t; t s; endmodule
