`timescale 1ns/1ps
module tb_mult_stream;
  localparam int W = 8, N = 200;
  logic clk = 1'b0, rst, in_valid, in_ready, out_valid;
  logic [W-1:0] a, b;
  logic [2*W-1:0] product;
  logic [2*W-1:0] expected [$];        // queue of products in flight
  int sent = 0, received = 0, errors = 0;

  mult_stream #(.W(W)) dut (.*);
  always #5 clk = ~clk;
  initial begin #1_000_000; $display("TIMEOUT"); $finish; end

  // Source: offers a new pair whenever it likes; holds it until accepted
  initial begin
    rst = 1'b1; in_valid = 1'b0; a = '0; b = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;
    while (sent < N) begin
      if (!in_valid && $urandom_range(0, 1)) begin     // sometimes wait, sometimes offer
        in_valid = 1'b1; a = $urandom; b = $urandom;
      end
      @(posedge clk);
      if (in_valid && in_ready) begin                  // transfer happened at this edge
        expected.push_back(a * b);
        sent++;
        @(negedge clk);
        in_valid = 1'b0;
      end else @(negedge clk);
    end
  end

  // Sink: checks results in order
  always @(posedge clk) if (!rst && out_valid) begin
    if (product !== expected[0]) begin
      $display("FAIL: got %0d expected %0d", product, expected[0]);
      errors++;
    end
    void'(expected.pop_front());
    received++;
    if (received == N) begin
      if (errors == 0) $display("PASS: %0d products through valid/ready", N);
      else             $display("FAILED with %0d errors", errors);
      $finish;
    end
  end
endmodule
