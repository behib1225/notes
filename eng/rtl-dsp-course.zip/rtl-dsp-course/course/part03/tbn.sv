`timescale 1ns/1ps
module tbn; logic clk=0,rst,din,f; logic [0:6] bits = 7'b1011011; int n=0;
detect1011_moore u(.clk(clk),.rst(rst),.din(din),.found(f)); always #5 clk=~clk;
initial begin rst=1; din=0; @(negedge clk); rst=0;
 for (int i=0;i<7;i++) begin din=bits[i]; @(negedge clk); if (f) n++; end
 din=0; @(negedge clk); if (f) n++; $display("found %0d", n); $finish; end endmodule
