`timescale 1ns/1ps
// tb_seq_mult.sv -- checks every product and the latency of seq_mult
module tb_seq_mult;
  localparam int W = 8;
  logic           clk = 1'b0, rst, start, busy, done;
  logic [W-1:0]   a, b;
  logic [2*W-1:0] product;
  int errors = 0, tests = 0;

  seq_mult #(.W(W)) dut (.*);
  always #5 clk = ~clk;

  initial begin                              // watchdog
    #10_000_000;
    $display("TIMEOUT");
    $finish;
  end

  // Run one multiplication and check both the result and the latency
  task automatic multiply(input logic [W-1:0] ta, tb);
    int cycles;
    @(negedge clk);
    a = ta;  b = tb;  start = 1'b1;          // request, for exactly one cycle
    @(negedge clk);
    start = 1'b0;
    a = 'x;  b = 'x;                         // operands must not be needed any more
    cycles = 1;
    while (!done) begin
      @(negedge clk);
      cycles++;
    end
    tests++;
    if (product !== ta * tb || cycles != W + 1) begin
      $display("FAIL: %0d * %0d = %0d after %0d cycles (expected %0d after %0d)",
               ta, tb, product, cycles, ta * tb, W + 1);
      errors++;
    end
  endtask

  initial begin
    rst = 1'b1;  start = 1'b0;  a = '0;  b = '0;
    repeat (2) @(negedge clk);
    rst = 1'b0;

    multiply(0, 0);    multiply(1, 1);    multiply(255, 255);
    multiply(255, 1);  multiply(1, 255);  multiply(128, 2);
    repeat (1000) multiply($urandom, $urandom);

    if (errors == 0) $display("PASS: %0d products correct, %0d cycles each", tests, W + 1);
    else             $display("FAILED with %0d errors", errors);
    $finish;
  end
endmodule
