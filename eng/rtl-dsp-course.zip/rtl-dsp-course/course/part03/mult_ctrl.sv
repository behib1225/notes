`timescale 1ns/1ps
// mult_ctrl.sv -- controller FSM for the shift-and-add multiplier
module mult_ctrl (
  input  logic clk,
  input  logic rst,
  input  logic start,      // request: begin a multiplication
  input  logic last,       // status from the datapath
  output logic load,       // control to the datapath
  output logic step,       // control to the datapath
  output logic busy,       // a multiplication is in progress
  output logic done        // one-cycle pulse: product is ready
);
  typedef enum logic [1:0] {S_IDLE, S_RUN, S_DONE} state_t;
  state_t state, next;

  always_ff @(posedge clk) begin
    if (rst) state <= S_IDLE;
    else     state <= next;
  end

  // Next state AND outputs in one block, with defaults first
  always_comb begin
    next = state;
    load = 1'b0;
    step = 1'b0;
    done = 1'b0;
    case (state)
      S_IDLE: begin
        if (start) begin
          load = 1'b1;
          next = S_RUN;
        end
      end
      S_RUN: begin
        step = 1'b1;
        if (last) next = S_DONE;
      end
      S_DONE: begin
        done = 1'b1;
        next = S_IDLE;
      end
      default: next = S_IDLE;
    endcase
  end

  assign busy = (state != S_IDLE);
endmodule
