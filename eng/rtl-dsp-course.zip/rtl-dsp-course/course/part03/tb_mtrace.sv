`timescale 1ns/1ps
module tb_mtrace;
  logic clk=0, rst, start, busy, done; logic [7:0] a, b; logic [15:0] product;
  seq_mult #(.W(8)) dut (.*); always #5 clk = ~clk;
  initial begin
    rst=1; start=0; a=0; b=0; repeat(2) @(negedge clk); rst=0;
    a=8'd13; b=8'd11; start=1; @(negedge clk); start=0;
    $display("step state   Q(multiplier) A(accum)  P  {A,Q}");
    for (int i=0;i<10;i++) begin
      $display("%2d   %-6s  %b      %b  %0d  %0d", i, dut.u_ctrl.state.name(), dut.u_dp.Q, dut.u_dp.A, dut.u_dp.P, product);
      @(negedge clk);
    end
    $finish;
  end
endmodule
