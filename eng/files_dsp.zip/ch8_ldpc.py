"""
Chapter 8: a real LDPC code with a normalized min-sum decoder.

 * (3,6)-regular LDPC code, n = 1008, rate ~1/2, random construction without
   repeated edges (Gallager-style).
 * Systematic encoder from the parity-check matrix by GF(2) Gaussian elimination.
 * Normalized min-sum decoding (vectorised over many codewords), early stopping.
 * BPSK over AWGN: BER vs Eb/N0 compared with uncoded BPSK and the Shannon limit of a
   rate-1/2 binary-input AWGN channel (about 0.19 dB).
 * Pre-FEC vs post-FEC BER: the "threshold" behaviour of a soft-decision code.
Run:  python ch8_ldpc.py     (about 1 minute)
"""
import numpy as np
import optdsp as od

def make_regular_ldpc(n=1008, dv=3, dc=6, seed=1):
    m = n * dv // dc
    rng = np.random.default_rng(seed)
    while True:
        sockets = np.repeat(np.arange(n), dv)
        perm = rng.permutation(len(sockets))
        var_of_edge = sockets[perm].reshape(m, dc)             # row = check node
        if all(len(set(r)) == dc for r in var_of_edge):         # no repeated edges
            break
    H = np.zeros((m, n), np.uint8)
    for c in range(m):
        H[c, var_of_edge[c]] = 1
    return H, var_of_edge

def systematic_encoder(H):
    """
    GF(2) Gaussian elimination: find a column permutation so that H*P = [A | I].
    Then codewords (in permuted order) are [u, A u] and we undo the permutation.
    Returns (k, encode function, column order).
    """
    H = H.copy() % 2; m, n = H.shape
    cols = np.arange(n); row = 0; pivots = []
    for col in range(n - 1, -1, -1):                            # build identity on the right
        if row == m: break
        r = row + np.nonzero(H[row:, col])[0]
        if len(r) == 0: continue
        H[[row, r[0]]] = H[[r[0], row]]
        for rr in np.nonzero(H[:, col])[0]:
            if rr != row: H[rr] ^= H[row]
        pivots.append(col); row += 1
    rank = row
    H = H[:rank]
    info_cols = np.setdiff1d(np.arange(n), pivots)
    A = H[:, info_cols]                                          # parity p_row = A_row . u
    order = np.empty(n, int)
    k = len(info_cols)
    def encode(u):                                               # u: (B, k)
        c = np.zeros((u.shape[0], n), np.uint8)
        c[:, info_cols] = u
        c[:, pivots] = (u @ A.T) % 2
        return c
    return k, encode, info_cols

def min_sum_decode(llr, var_of_edge, n, max_iter=50, alpha=0.75):
    """
    Normalized min-sum. llr: (B, n) channel LLRs, positive = bit 0 more likely.
    var_of_edge: (m, dc) variable index of each edge, grouped by check node.
    Returns hard decisions (B, n) and the number of iterations used.
    """
    B = llr.shape[0]; m, dc = var_of_edge.shape
    ve = var_of_edge.ravel()
    r = np.zeros((B, m * dc))                                    # check -> variable messages
    for it in range(max_iter):
        total = llr + np.stack([np.bincount(ve, weights=r[b], minlength=n) for b in range(B)])
        q = (total[:, ve] - r).reshape(B, m, dc)                 # variable -> check (extrinsic)
        sgn = np.where(q < 0, -1.0, 1.0); mag = np.abs(q)
        prod = np.prod(sgn, axis=2, keepdims=True)
        srt = np.sort(mag, axis=2); min1, min2 = srt[:, :, :1], srt[:, :, 1:2]
        is_min = mag == min1
        r = (alpha * prod * sgn * np.where(is_min, min2, min1)).reshape(B, m * dc)
        total = llr + np.stack([np.bincount(ve, weights=r[b], minlength=n) for b in range(B)])
        hard = (total < 0).astype(np.uint8)
        syn = hard[:, var_of_edge].sum(axis=2) % 2               # parity of each check
        if not syn.any():
            break
    return hard, it + 1

if __name__ == "__main__":
    rng = np.random.default_rng(0)
    H, voe = make_regular_ldpc()
    n = H.shape[1]
    k, encode, info_cols = systematic_encoder(H)
    R = k / n
    print(f"(3,6)-regular LDPC: n = {n}, k = {k}, rate = {R:.3f}")
    u = rng.integers(0, 2, (5, k)).astype(np.uint8)
    assert not ((encode(u) @ H.T) % 2).any(), "encoder error"
    print("encoder check passed: H c^T = 0 for random codewords\n")
    print("Eb/N0(dB)  uncoded BER  pre-FEC BER  post-FEC BER   avg iters")
    for ebn0 in [0.5, 1.0, 1.5, 2.0, 2.5]:
        errs = bits = pre_err = 0; iters = []
        for _ in range(8):
            B = 50
            u = rng.integers(0, 2, (B, k)).astype(np.uint8)
            c = encode(u)
            esn0 = 10 ** (ebn0 / 10) * R                         # energy per CODED bit
            sigma = np.sqrt(1 / (2 * esn0))
            y = (1 - 2.0 * c) + sigma * rng.standard_normal(c.shape)
            llr = 2 * y / sigma ** 2
            hard, it = min_sum_decode(llr, voe, n)
            errs += np.sum(hard[:, info_cols] != u); bits += u.size
            pre_err += np.sum((y < 0) != c); iters.append(it)
        unc = od.qfunc(np.sqrt(2 * 10 ** (ebn0 / 10)))
        print(f"{ebn0:6.1f}      {unc:.2e}     {pre_err/c.size/8:.2e}     {errs/bits:.2e}      {np.mean(iters):5.1f}")
    print("\nShannon limit for rate-1/2 binary-input AWGN: Eb/N0 ~ 0.19 dB; "
          "for rate-1/2 with unconstrained (Gaussian) input: 0 dB.")
