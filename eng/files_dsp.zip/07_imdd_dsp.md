# Chapter 7 — DSP for Intensity-Modulation / Direct-Detection (IM/DD) Links

> **How to use this chapter.** §7.2–7.5 build the physical model and explain why IM/DD lives in the O-band; §7.6 compares the four standard receivers with one consistent simulator (`code/ch7_imdd.py`); §7.8 introduces self-coherent detection. Problems are rated ★ / ★★ / ★★★. The Hilbert transform and minimum-phase signals used in §7.8 are explained in `appendix_A_math_and_glossary.md` (A.3).

> **Learning objectives.** After this chapter you can (1) explain why data-centre links use IM/DD and PAM4, (2) model an IM/DD link including square-law detection, signal-dependent noise, bandwidth limits and chromatic-dispersion power fading, (3) derive the power-fading transfer function, (4) design and compare FFE, DFE, Volterra and MLSE equalizers and know their limits, (5) explain key IEEE metrics (KP4 FEC threshold, TDECQ), and (6) understand self-coherent alternatives such as the Kramers–Kronig receiver and where coherent "lite" takes over.

---

## 7.1 Why IM/DD still matters

Inside and between nearby data centres (hundreds of metres to ~10 km), billions of links are needed, and **cost, power and size** dominate. An IM/DD transceiver needs no local-oscillator laser, no 90° hybrid and only one photodiode per lane, so it is much cheaper and lower-power than coherent. The price is that the receiver only measures optical **power**: phase is lost, and only one real-valued dimension per lane is available.

Current landmarks:

- **100 Gb/s per lane**: PAM4 at 53.125 GBd (e.g. 400GBASE-DR4: four parallel fibers, 500 m; FR/LR variants use wavelength multiplexing over 2–10 km).
- **200 Gb/s per lane**: PAM4 at ≈113 GBd, specified in IEEE P802.3dj for 200G/400G/800G/1.6T Ethernet (targeted for completion in 2026; check the IEEE 802.3dj page for its final status). The higher baud rate brings stronger bandwidth limitations and a more elaborate FEC scheme.
- **Linear-drive and half-retimed optics** (LPO, LRO/RTLR): remove the DSP from the optical module entirely or partially and rely on the host switch SerDes for equalization, to save power (e.g. OIF's 112G RTLR implementation agreement, November 2025).
- Beyond ~10 km, or at the highest rates, **coherent** takes over (e.g. OIF's 800LR agreement, April 2025, for 10 km coherent links).

## 7.2 The IM/DD link model

```
bits → PAM4 mapper → TX DSP (pre-emphasis) → DAC → driver → laser/modulator (EML, DML, MZM)
     → fiber (O-band or C-band) → photodiode (PIN/APD) → TIA → ADC → RX DSP → decisions → FEC
```

**Transmitter.** The optical power $P(t)$ is modulated between a low level $P_0$ and a high level $P_3$. The **extinction ratio** $ER = P_3/P_0$ (typically 3.5–6 dB) is limited because lasers and modulators become nonlinear and slow near zero power. **Directly modulated lasers (DMLs)** also produce **chirp** — frequency modulation linked to intensity changes — which interacts badly with dispersion. **Electro-absorption modulated lasers (EMLs)** and MZMs have much lower chirp.

**Square-law detection.** The photocurrent is $i(t)=R\,|E(t)|^2 + n(t)$, with responsivity $R$ ≈ 0.7–0.9 A/W. Without dispersion, $|E|^2=P(t)$ and the data comes straight out.

**Noise.** Unlike coherent links (dominated by additive ASE), IM/DD noise is a mix of:
- **thermal noise** from the TIA — additive, usually dominant in unamplified links;
- **shot noise** and **RIN** — proportional to the signal, so the upper PAM4 levels are noisier;
- noise from **APDs** (avalanche gain improves sensitivity but adds excess noise).

Because noise is level-dependent, PAM4 transmitters sometimes use **unequal level spacing** and receivers can use **adapted thresholds**.

## 7.3 PAM4 in practice

Four levels (two bits, Gray-labelled: 00, 01, 11, 10) produce three stacked eyes. How does PAM4 compare with NRZ (two levels) carrying the **same bit rate** with the **same peak-to-peak swing**?

- Each PAM4 eye is one third as tall: the decision distance shrinks by $20\log_{10}3\approx9.5$ dB in electrical power terms.
- But PAM4 runs at **half the baud rate**, so the receiver's noise bandwidth — and, for white thermal noise, the noise power — is halved: +3 dB.
- Net: in a noise-limited link PAM4 needs roughly **6.5 dB more electrical SNR** than NRZ at the same bit rate. (The often-quoted "9.5 dB" compares the two at the same *baud* rate; in optical-power terms, since the photocurrent is proportional to optical power, the penalties are about half as many dB: ≈ 4.8 dB and ≈ 3.3 dB respectively.)
- In **bandwidth-limited** links the halved baud rate means far less ISI, and PAM4 usually wins overall. That is why it replaced NRZ above ~50 Gb/s per lane.

### Electrical SNR: a precise definition
Throughout this chapter,

$$\text{SNR}_{el} = \frac{\text{variance of the data (AC) part of the noise-free decision samples}}{\text{variance of the noise at the decision samples}}.$$

The DC part of the photocurrent (the average optical power) carries no information and is excluded. With equally spaced levels $\{-3,-1,1,3\}$ (variance 5) and Gaussian noise of variance $\sigma^2$, $\text{SNR}_{el}=5/\sigma^2$ and the decision distance is 1/σ in units of the half-spacing, so

$$\text{SER} = \frac32\,Q\!\left(\sqrt{\text{SNR}_{el}/5}\right),\qquad \text{BER}\approx\frac{\text{SER}}{2}\ \text{(Gray)}.$$

`code/ch7_imdd.py` adds noise exactly this way, and its back-to-back check reproduces the formula (e.g. SER 3.51×10⁻³ simulated versus 3.58×10⁻³ at 16 dB).

> **Correction note.** The first version of this chapter used an IM/DD simulation whose "SNR" was measured against the *total* photocurrent power (including DC) and then silently lost half the noise by taking the real part of complex noise. The trends were right but the SNR values were meaningless. Precise definitions are not pedantry: they are what makes numbers comparable.

For Gaussian noise of variance $\sigma^2$ and level spacing $d$ (distance between adjacent levels), the symbol error rate is

$$\text{SER} = 2\cdot\frac{M-1}{M}\,Q\!\left(\frac{d}{2\sigma}\right) = \frac32\,Q\!\left(\frac{d}{2\sigma}\right),\qquad \text{BER}\approx\frac{\text{SER}}{2}\ \text{(Gray)}.$$

### FEC threshold
IEEE Ethernet at 100 Gb/s per lane uses the **"KP4"** Reed–Solomon code RS(544,514) over GF(2¹⁰), about 5.8% overhead, which corrects a pre-FEC BER of about **2.4×10⁻⁴** to a post-FEC error rate below the Ethernet target. This threshold is much lower than coherent SD-FEC thresholds (~10⁻²) because RS codes are hard-decision and short (low latency and power). At 200 Gb/s per lane, P802.3dj adds more powerful concatenated coding for some interfaces.

### TDECQ
Real transmitter compliance is measured with **TDECQ** (Transmitter and Dispersion Eye Closure for PAM4). The transmitter's output is captured through a reference receiver that includes a standardised reference equalizer (a short T-spaced FFE, 5 taps in 802.3bs-era specifications). TDECQ reports, in dB, how much *less* added Gaussian noise the signal can tolerate than an ideal transmitter with the same outer levels, while still reaching the target symbol error ratio (4.8×10⁻⁴, the KP4 BER threshold ×2). In other words: the SNR penalty of this transmitter *after* the equalization a compliant receiver is guaranteed to have. The IEEE definition includes details we omit (reference-receiver bandwidth, two sampling instants, histogram-based computation).

`code/ch7_imdd.py` computes a **simplified TDECQ-like penalty**: an MMSE-optimal 5-tap FFE on the noise-free received signal, then the largest Gaussian noise (referred to the equalizer *input*, so the FFE's noise enhancement $\sum w_k^2$ counts) that still meets the SER target:

| Transmitter / channel | TDECQ-like penalty |
|---|---|
| ideal | 0.00 dB |
| bandwidth 0.5·R_s (4th-order Butterworth) | 0.31 dB |
| bandwidth 0.4·R_s | 3.81 dB |
| bandwidth 0.35·R_s | fails (eye stays closed after the 5-tap FFE) |
| 2 km C-band dispersion | 0.10 dB |

Note how steeply the penalty grows once the bandwidth drops below about half the baud rate — the reason component bandwidth is the central specification for 200G-per-lane optics.

## 7.4 Bandwidth limitations

At 53–113 GBd, the combined bandwidth of DAC, driver, modulator, photodiode, TIA and ADC is often only ~0.5–0.7× the baud rate. The resulting ISI is linear (on the intensity) and is handled by:
- **TX pre-emphasis** (an FIR in the TX DSP that boosts high frequencies);
- **RX equalizers** (Section 7.6).

## 7.5 Chromatic dispersion and power fading

### Derivation (small-signal, chirp-free)
Let the transmitted field be $E(t)=\sqrt{P_{avg}}\,(1+m\,u(t))$ with small modulation $m\,u(t)$ ($u$ real). After dispersion, $E_L = \sqrt{P_{avg}}\,(1 + m\,u\ast h_{CD})$, where $h_{CD}$ is the (complex) impulse response of $H_{CD}(\omega)=e^{-j\beta_2L\omega^2/2}$. The photocurrent to first order in $m$ is

$$|E_L|^2 \approx P_{avg}\left(1 + 2m\,\mathrm{Re}\{u\ast h_{CD}\}\right).$$

Because $u$ is real, $\mathrm{Re}\{u\ast h_{CD}\}$ is $u$ filtered by the *real, even* part of $H_{CD}$:

$$H_{IM}(\omega)=\tfrac12\left[H_{CD}(\omega)+H_{CD}^*(-\omega)\right] = \cos\!\left(\frac{\beta_2L\omega^2}{2}\right).$$

**Intuition.** The two sidebands at $\pm\omega$ each pick up a phase $-\beta_2L\omega^2/2$. The photodiode beats each sideband with the carrier; the two beat terms add with that phase difference, and when it reaches $\pi/2$ they cancel exactly — a **null**. The receiver has lost that frequency entirely.

Nulls occur at $\beta_2L\omega^2/2 = \pi/2 + k\pi$:

$$f_{null,k} = \sqrt{\frac{(2k+1)c}{2|D|L\lambda^2}}.$$

For SSMF at 1550 nm ($D$ = 17 ps/(nm·km)): 10 km → 19.2 GHz; 2 km → 43 GHz; 1 km → 61 GHz. A 56 GBd PAM4 signal (Nyquist frequency 28 GHz) survives 1–2 km in the C-band, but 10 km puts a null in the middle of the band.

### Why a linear equalizer cannot fix it
Inverting a null requires infinite gain, which infinitely amplifies noise (Problem 3.5). The simulation in §7.6 makes this concrete: at 5 km in the C-band (first null at 27 GHz, essentially at the 28 GHz Nyquist frequency of 56 GBd), every receiver fails, while 10 km in the O-band (D ≈ −2 ps/(nm·km)) performs like back-to-back.

**This is why data-centre IM/DD lives in the O-band**, and why C-band IM/DD beyond a few km needs something else: optical dispersion compensation, single-sideband or self-coherent formats (Section 7.8), or coherent detection.

(With a DML, chirp shifts the null frequencies — and can even improve reach for one sign of dispersion — but the fundamental limitation remains.)

## 7.6 Equalizers for IM/DD

### Feed-forward equalizer (FFE)
A real-valued FIR on the received samples, adapted by LMS (Chapter 2), usually at 1 sps (baud-spaced) or fractionally spaced. It fixes linear ISI but enhances noise where the channel is weak. Typical lengths: 10–50 taps.

```python
w = np.zeros(n_taps); w[n_taps // 2] = 1          # centre-spike init
for k in range(n_taps, len(r)):
    win = r[k - n_taps:k][::-1]
    y[k] = w @ win
    e = ref[k - n_taps//2 - 1] - y[k]            # training symbols, later decisions
    w += mu * e * win
```

### Decision-feedback equalizer (DFE)
Uses past *decisions* (noise-free, if correct) to cancel post-cursor ISI:

$$y[k] = \sum_i w_i\,r[k-i] - \sum_{j\ge1} b_j\,\hat d[k-j].$$

**Advantage:** cancels ISI without enhancing noise — it can handle deep notches much better than an FFE. **Disadvantages:** (1) **error propagation** — a wrong decision feeds back wrong ISI cancellation and can trigger bursts of errors, which hurt the RS FEC; (2) the decision must be made within one symbol period before the next can proceed, which is extremely hard at 100+ GBd in parallel hardware (look-ahead/unrolled structures are used for 1–2 taps). **Precoding** ($1+D$ or Tomlinson–Harashima) moves the feedback to the transmitter to avoid error propagation.

### Volterra (nonlinear) equalizers
Square-law detection, modulator nonlinearity and dispersion–chirp interaction produce **nonlinear** ISI. A Volterra equalizer adds products of samples:

$$y[k] = \sum_i w_i r[k-i] + \sum_{i\le j} w_{ij}\,r[k-i]r[k-j] + \dots$$

It can deliver 1–2 dB gains in impaired links, at a complexity that grows quickly with memory; pruned versions keep only the significant terms. Neural-network equalizers are a related, active research area; their gains over well-designed Volterra/MLSE should always be checked against complexity.

### Maximum-likelihood sequence estimation (MLSE)
Instead of deciding symbol by symbol, choose the most likely *sequence* given a model of the ISI channel, using the **Viterbi algorithm** on a trellis with $M^{L}$ states (memory $L$). MLSE handles severe ISI and spectral notches gracefully because it never tries to invert the channel. For PAM4 the state count grows as $4^L$, so practical implementations use short memory (a 1–2 tap "post-cursor" channel model) after an FFE that shapes the channel into that short response. FFE + short MLSE is a common architecture in 200G-per-lane DSPs.

### The four receivers compared
`code/ch7_imdd.py` implements all four with the same channel model and the SNR definition of §7.3 (56 GBd PAM4, ER = 6 dB, RRC shaping, SNR_el = 17 dB, 21-tap LMS equalizers trained on 10,000 known symbols then decision-directed; the DFE has 3 feedback taps; the MLSE uses a 4-state Viterbi detector for the target $y_k=a_k+\alpha a_{k-1}$, with α chosen on a separate training segment).

The DFE's core loop:
```python
past = dec[j - 1 - np.arange(n_fb)]                 # previous DECISIONS (noise-free if correct)
y[j] = w @ win - b @ past                            # feed-forward part minus post-cursor estimate
d_hat = LV[ref[j]] if training else LV[decide(y[j])]
dec[j] = d_hat;  e = d_hat - y[j]
w += mu * e * win;  b -= mu * e * past
```
The MLSE's core (Viterbi) step, for 4 states = the previous symbol:
```python
m = cost[:, None] + (y[k] - (LV[None, :] + alpha * LV[:, None]))**2   # metric[prev, cur]
back[k] = np.argmin(m, axis=0); cost = np.min(m, axis=0)             # survivor per state
```

Results (symbol error ratio; theory without ISI at 17 dB: 1.2×10⁻³):

| Channel | no EQ | FFE | FFE + DFE | FFE + MLSE (α) |
|---|---|---|---|---|
| back-to-back | 1.2e-3 | 1.4e-3 | 1.3e-3 | 1.1e-3 (0.0) |
| bandwidth 0.5·R_s | 6.2e-2 | 1.6e-3 | 1.5e-3 | 1.5e-3 (0.2) |
| bandwidth 0.4·R_s | 1.3e-1 | 6.7e-3 | 3.5e-3 | 2.4e-3 (0.6) |
| bandwidth 0.35·R_s | 2.4e-1 | 3.8e-2 | 1.3e-2 | 3.5e-3 (0.6) |
| C-band 2 km | 3.1e-3 | 1.6e-3 | 1.5e-3 | 1.4e-3 (0.0) |
| C-band 5 km | 2.7e-1 | 2.3e-1 | 1.4e-1 | 5.7e-2 (0.8) |
| O-band 10 km (D = −2) | 1.3e-3 | 1.4e-3 | 1.4e-3 | 1.2e-3 (0.0) |

How to read it:
- On benign channels all receivers equal the ISI-free theory (the FFE's small loss is LMS adaptation noise). The MLSE chooses α = 0 there, i.e. it reduces to symbol-by-symbol detection.
- As bandwidth shrinks, the **FFE** suffers noise enhancement; the **DFE** removes post-cursor ISI without enhancing noise; the **MLSE** does best because it never tries to invert the channel: at 0.35·R_s it is ≈ 10× better than the FFE.
- A spectral null (C-band 5 km) defeats all of them.
- An important lesson from building this simulator: an MLSE with a *fixed* partial-response target (α = 0.5) was *worse* than the FFE on good channels (4×10⁻³ vs 1.4×10⁻³ back-to-back), because the FFE was forced to create ISI and colour the noise. The target must be adapted to the channel.

![PAM4 decision-sample histograms](figures/ch7_pam4_histograms.png)

*Figure 7.1 — Histograms of PAM4 decision samples (SNR_el = 24 dB). Left: back-to-back, four clean levels. Middle: with a 0.4·R_s bandwidth limit, ISI smears the levels together. Right: the FFE restores four separated levels (a little wider than back-to-back: noise enhancement).*

### Clock recovery in IM/DD
Baud-rate timing detectors such as **Mueller–Müller** (which uses decisions and 1-sps samples) are common, because IM/DD DSPs aim to run at 1 sps to save power.

## 7.7 A worked design exercise: a 200G-per-lane link budget sketch

Suppose ~113 GBd PAM4, 2 km in the O-band, component bandwidth ~55 GHz, thermal-noise-limited receiver. A designer would ask: (1) What electrical SNR reaches the decision device after the FFE, and does it give BER < KP4-like thresholds (or the concatenated-FEC threshold)? (2) How much of the SNR penalty is due to bandwidth limitation (use Problem 7.3's approach)? (3) Is a DFE or MLSE worth the power? These are exactly the trade-offs made in real 200G-per-lane module DSPs.

## 7.8 Beyond plain IM/DD: self-coherent detection and the Kramers–Kronig receiver

The core problem of IM/DD is that the photodiode discards phase. **Self-coherent** schemes send a strong **carrier** along with the signal so that the phase can be recovered from intensity alone.

### The Kramers–Kronig (KK) receiver
Proposed by Mecozzi, Antonelli and Shtaif (2016). Transmit $E(t) = A + s(t)$, where $A$ is a CW carrier at the edge of the band and $s(t)$ is a **single-sideband** complex signal (spectrum on one side of the carrier only). If the carrier is strong enough that the field never encircles zero, $E(t)$ is a **minimum-phase** signal, and a classical result (the Kramers–Kronig relations) says its phase is the Hilbert transform of the log of its magnitude:

$$\phi(t) = \mathcal{H}\{\ln|E(t)|\},\qquad |E(t)|=\sqrt{I(t)}.$$

In code (with `scipy.signal.hilbert(u)` returning $u + j\mathcal{H}\{u\}$):

```python
E_rec = np.exp(hilbert(0.5 * np.log(I)))      # full complex field from ONE photodiode
E_rec = od.cd_channel(E_rec, fs, L, compensate=True)   # now CD can be undone digitally!
```

With the complex field recovered, the receiver can compensate chromatic dispersion digitally, like a coherent receiver. The naive alternative (take $\sqrt{I}$ and subtract the carrier) suffers from **signal–signal beat interference (SSBI)**, which the KK algorithm removes.

Our simulation (`code/ch7_kk_receiver.py`: SSB 16-QAM, 32 GBd, 80 km in the C-band, fixed total received power) shows the key trade-off as a function of carrier-to-signal power ratio (CSPR):

![KK receiver versus CSPR](figures/ch7_kk_cspr.png)

*Figure 7.2 — SNR versus carrier-to-signal power ratio for the Kramers–Kronig receiver and a naive single-sideband receiver.*


| CSPR (dB) | 4 | 6 | 8 | 10 | 12 | 14 | 16 |
|---|---|---|---|---|---|---|---|
| KK, no noise | 16.0 | 23.7 | 34.3 | 43.7 | 46.1 | 46.3 | 46.3 |
| naive SSB, no noise (SSBI-limited) | 10.1 | 12.9 | 15.3 | 17.5 | 19.6 | 21.7 | 23.7 |
| KK with thermal noise | 6.1 | 8.3 | 11.7 | 15.2 | 16.0 | 15.2 | 13.5 |

Reading the table: once CSPR exceeds ~10 dB the minimum-phase condition is (almost) always satisfied, and KK becomes essentially perfect; the naive receiver gains only 1 dB per dB of CSPR because SSBI shrinks slowly. But with a fixed received power and thermal noise, a stronger carrier steals power from the data, so there is an **optimum CSPR** (≈12 dB here). Practical notes: the log and square root broaden the spectrum, so KK needs oversampling (we used 6 sps; research has reduced this to ~2–3 sps); and the carrier wastes power and needs a transmitter able to generate SSB.

### Other options
Stokes-vector receivers (use polarization to carry a reference), carrier-assisted differential detection, and "coherent-lite" (coherent detection with simplified DSP, relaxed lasers, O-band operation) all target the region between IM/DD and full coherent. Which wins at 800G/1.6T for 2–40 km is an active industry question.

## 7.9 Common pitfalls

1. Treating IM/DD noise as purely additive and level-independent.
2. Forgetting that the measured quantity is power: a "field" equalizer on IM/DD samples is not physical.
3. Expecting an FFE to undo power-fading nulls.
4. Ignoring DFE error propagation when estimating post-FEC performance.
5. Simulating KK at too few samples per symbol.

## 7.10 Check your understanding

1. Why does PAM4 cost about 9.5 dB of SNR relative to NRZ at the same peak-to-peak swing?
2. What physical effect causes the power-fading nulls?
3. Why can a DFE handle a spectral notch that defeats an FFE?
4. What condition must hold for the KK receiver to work, and how is it enforced?

<details><summary>Answers</summary>

1. The eye opening (distance between adjacent levels) is one third of the full swing: $20\log_{10}3\approx9.5$ dB.
2. Destructive interference between the carrier–upper-sideband and carrier–lower-sideband beat terms, whose relative phase grows with $\beta_2L\omega^2$.
3. It cancels ISI by subtracting known (decided) interference instead of inverting the channel's frequency response, so it does not amplify noise at the notch.
4. The received field must be minimum-phase (it must not encircle zero in the complex plane); enforced by a sufficiently strong carrier (high CSPR) at the band edge with a single-sideband signal.
</details>

## 7.11 Problems

### Problem 7.1 ★ — Power-fading nulls
(a) Compute the first two null frequencies for 5 km and 20 km of SSMF at 1550 nm. (b) What is the longest C-band reach for which the first null stays above the Nyquist frequency of a 113 GBd PAM4 signal? (c) Repeat (b) in the O-band with |D| = 3 ps/(nm·km) at 1310 nm.

<details><summary>Solution</summary>

$f_{null,k}=\sqrt{(2k+1)c/(2|D|L\lambda^2)}$. With $c/(2|D|\lambda^2) = 3\times10^8/(2\cdot17\times10^{-6}\cdot2.4025\times10^{-12}) = 3.673\times10^{24}$ m/s² (units: Hz²·m):

(a) 5 km: $f_0=\sqrt{3.673\text{e}24/5000}=27.1$ GHz, $f_1=\sqrt3\,f_0=47.0$ GHz. 20 km: 13.6 and 23.5 GHz.

(b) Nyquist = 56.5 GHz. $L = 3.673\text{e}24/(56.5\text{e}9)^2 \approx 1.15$ km. So 113 GBd PAM4 in the C-band is essentially limited to ~1 km (in practice less, because the response is already weak well before the null).

(c) $c/(2|D|\lambda^2) = 3\text{e}8/(2\cdot3\text{e-}6\cdot1.716\text{e-}12)=2.914\times10^{25}$; $L = 2.914\text{e}25/(56.5\text{e}9)^2\approx9.1$ km. Near the zero-dispersion wavelength (|D| < 1), reach extends much further — this is why CWDM lanes near 1310 nm are chosen for 2–10 km links, with the outer lanes (larger |D|) being the hardest.
</details>

### Problem 7.2 ★★ — Reproduce and extend the receiver comparison (coding)
Run `code/ch7_imdd.py`. Then (a) for the 5 km C-band case, increase the FFE to 51 taps — does it help? (b) Plot the electrical spectrum (PSD of the noise-free photocurrent `I` returned by `imdd_channel(L_km=10)`) and identify the nulls. (c) Why does the DFE help at 5 km while the FFE barely does?

<details><summary>Solution</summary>

(a) `ffe(r, idx, n_taps=51)` leaves the SER essentially unchanged (≈ 0.2): the null sits at ≈ 27 GHz, at the band edge of 56 GBd, and no linear filter can create gain where the channel transfers no signal energy. (b) `scipy.signal.welch(I - I.mean(), fs=4*56e9)` shows deep dips near 19.2 GHz and 33.3 GHz ($=\sqrt3\times19.2$), matching $f_{null,k}$. (c) The DFE cancels post-cursor ISI by subtracting interference computed from past *decisions*; it does not invert the channel's frequency response, so it does not need infinite gain at the null. It still fails eventually because at 5 km the ISI is so strong that decision errors propagate through the feedback.
</details>

### Problem 7.3 ★★ — Receiver choice for a bandwidth-limited link (coding)
Using `run_case(label, bw=...)` from `code/ch7_imdd.py`, find the component bandwidth (as a fraction of R_s) at which each receiver reaches SER = 4.8×10⁻⁴ at SNR_el = 19 dB. Relate the ranking to the TDECQ-like penalty.

<details><summary>Solution</summary>

Sweep `bw` with `snr_db=19` (ISI-free SER at 19 dB: 5.0×10⁻⁵). One run gives:

| bandwidth / R_s | FFE | FFE + DFE | FFE + MLSE |
|---|---|---|---|
| 0.50 | 1.3e-4 ✓ | 1.3e-4 ✓ | 1.3e-4 ✓ |
| 0.45 | 1.5e-4 ✓ | 1.5e-4 ✓ | 7.5e-5 ✓ |
| 0.40 | 6.8e-4 ✗ | 3.3e-4 ✓ | 1.0e-4 ✓ |
| 0.35 | 1.3e-2 ✗ | 1.2e-3 ✗ | 4.8e-4 ✓ (just) |
| 0.30 | 1.1e-1 ✗ | 2.0e-2 ✗ | 4.0e-3 ✗ |

So the minimum bandwidth is ≈ 0.45·R_s for the FFE, ≈ 0.40·R_s for the DFE and ≈ 0.35·R_s for the MLSE — each more complex receiver buys roughly 0.05·R_s of bandwidth tolerance (≈ 3 GHz at 56 GBd, ≈ 6 GHz at 113 GBd). The TDECQ-like penalty (5-tap reference FFE) rises from 0.3 dB at 0.5·R_s to 3.8 dB at 0.4·R_s and fails at 0.35·R_s: a transmitter measured with a short reference FFE looks worse than it would with the receiver's full DSP, which is deliberate — compliance must hold for the *minimum* guaranteed receiver. (Exact crossing points depend on the random seed and adaptation settings; the ranking is robust.)
</details>

### Problem 7.4 ★★ — KK receiver trade-offs (coding)
Using `code/ch7_kk_receiver.py`: (a) reduce the oversampling from 6 to 3 and then 2 samples per symbol at CSPR = 12 dB with no noise; explain the result. (b) Replace the 80 km link with 0 km and explain why the naive receiver still suffers.

<details><summary>Solution</summary>

(a) Call `kk_link(12, sps=3, thermal_snr_db=200)` and `sps=2`. In our run the noise-free SNR falls from 46.1 dB (6 sps) to 29.6 dB (3 sps) and 9.2 dB (2 sps), because $\ln|E|$ and the exponential are nonlinear operations that broaden the spectrum well beyond the signal bandwidth; at low sps that broadened spectrum aliases. This motivates the upsampling-free KK variants in the literature.

(b) At 0 km the naive receiver gives 21.7 dB versus 19.6 dB at 80 km — only about 2 dB better, and still ~25 dB worse than KK. SSBI comes from the square-law beating of the signal with itself, $|s|^2$, which exists with or without dispersion (dispersion changes its details slightly, hence the 2 dB). Only the KK phase retrieval (or iterative SSBI cancellation) removes it.
</details>

### Problem 7.5 ★★★ — Design: NRZ or PAM4 for a 100 Gb/s lane?
Your components have 30 GHz of bandwidth (4th-order roll-off) and a thermal-noise-limited receiver. Would you carry 100 Gb/s as 100 GBd NRZ or 50 GBd PAM4? Argue quantitatively using §7.3 (noise) and §7.6 (bandwidth), and state what extra information you would want.

<details><summary>Solution</summary>

*Noise:* at equal swing, PAM4 needs ≈ 6.5 dB more electrical SNR than NRZ at the same bit rate (§7.3).

*Bandwidth:* for NRZ at 100 GBd, 30 GHz is 0.3·R_s — deeper than the 0.35·R_s case where even the MLSE struggled for PAM4 (and NRZ's eye closes similarly under such severe ISI: an NRZ receiver would need strong equalization, and noise enhancement would eat much of its 6.5 dB advantage). For PAM4 at 50 GBd, 30 GHz is 0.6·R_s — comfortably above 0.5·R_s, where an FFE is enough and the TDECQ-like penalty is ≈ 0.3 dB.

*Conclusion:* PAM4. This is precisely the industry's reasoning at 50–100 Gb/s per lane. *Extra information wanted:* the actual SNR budget (receiver sensitivity, link loss, ER), linearity of the driver/modulator (PAM4 needs good linearity), and the FEC threshold. The general principle: **when bandwidth, not noise, is the binding constraint, trade SNR for bandwidth with more levels.**
</details>

---

## Key takeaways

- IM/DD measures **power**, not field: cheap and low-power, but phase is lost and CD causes **power-fading nulls** at $f=\sqrt{(2k+1)c/(2|D|L\lambda^2)}$.
- Define **SNR_el** on the data (AC) part at the decision point; for PAM4, SER = 1.5·Q(√(SNR_el/5)).
- PAM4 vs NRZ at equal bit rate: ≈ 6.5 dB electrical-SNR penalty when noise-limited, but far more bandwidth-tolerant.
- **FFE** (noise enhancement) < **DFE** (error propagation, hard to parallelise) < **MLSE** (best, needs an adapted target) as ISI grows; none can cross a null.
- **TDECQ** measures a transmitter's penalty after a standard reference equalizer.
- **Kramers–Kronig** recovers the full field from one photodiode using a strong carrier (minimum phase), enabling digital CD compensation.

---

**Next:** Chapter 8 — forward error correction, soft information, GMI, probabilistic shaping and nonlinearity compensation: how a modern system turns an SNR into a guaranteed bit rate.
