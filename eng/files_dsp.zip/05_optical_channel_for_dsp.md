# Chapter 5 — The Optical Channel, Seen by a DSP Engineer

> **How to use this chapter.** You do not need to become a physicist: for each effect, focus on (1) the physical cause in one sentence, (2) the mathematical model the DSP sees, and (3) the size of the effect in numbers. Problems are rated ★ / ★★ / ★★★.

> **Learning objectives.** After this chapter you can (1) describe every component between the transmitter DSP and the receiver DSP and what it does to the signal, (2) derive and quantify chromatic dispersion and its memory in symbols, (3) model polarization rotation, PMD and PDL as 2×2 matrices, (4) explain the Kerr nonlinearity, the NLSE, the split-step method and the optimum launch power, (5) derive the outputs of a coherent receiver (90° hybrid + balanced detectors) and of a direct-detection receiver, and (6) build a physically correct channel model in Python.

---

## 5.1 The end-to-end picture

```mermaid
flowchart LR
  A[bits] --> B[TX DSP] --> C[DAC + drivers] --> D["IQ modulators<br/>(X and Y pol)"]
  L1[TX laser] --> D
  D --> F1[fiber span] --> E1[EDFA] --> F2["... more spans,<br/>ROADMs"]
  F2 --> H["90° hybrids<br/>(X and Y pol)"]
  L2[LO laser] --> H
  H --> P["balanced PDs + TIAs<br/>(band-limited)"] --> G[ADCs] --> R[RX DSP] --> Z[bits]
```

(If your viewer does not render Mermaid diagrams, read it left to right: bits → TX DSP → DAC/drivers → IQ modulators fed by the TX laser → fiber spans with amplifiers → 90° hybrids fed by the LO laser → balanced photodiodes and TIAs → ADCs → RX DSP → bits.)

Each block leaves a fingerprint that the DSP must remove or tolerate:

| Block | Impairment | Linear? | Time scale | DSP remedy (Chapter) |
|---|---|---|---|---|
| DAC, drivers, modulator | limited bandwidth, nonlinearity, IQ skew, IQ imbalance | mostly linear | static | TX pre-emphasis, RX equalizer (6) |
| TX laser + LO | phase noise, frequency offset | multiplicative | μs | FOE, CPR (6) |
| Fiber | chromatic dispersion | linear, all-pass | static | CD compensation (6) |
| Fiber | polarization rotation, PMD, PDL | linear, 2×2 | μs–ms | adaptive MIMO equalizer (6) |
| Fiber | Kerr nonlinearity | nonlinear | — | launch power optimisation, DBP (8) |
| EDFAs | ASE noise | additive | — | FEC (8) |
| Filters (ROADMs, WSS) | bandwidth narrowing | linear | static | equalizer (6) |
| Hybrid, PDs, TIAs, ADC | IQ imbalance, skew, bandwidth, quantization | mostly linear | static | front-end correction (6) |
| Clocks | sampling-frequency offset, jitter | — | μs | timing recovery (6) |

## 5.2 The transmitter

### Mach–Zehnder modulator (MZM)
An MZM splits light into two arms, changes the phase in each arm via the electro-optic effect, and recombines them. Driven in push-pull and **biased at the transmission null**, its field transfer function is

$$E_{out} = E_{in}\sin\left(\frac{\pi V(t)}{2V_\pi}\right),$$

where $V(t)$ is the drive voltage around the bias point and $V_\pi$ the voltage that produces a π phase difference between the arms. For small drive voltages $\sin(u)\approx u$, so the optical *field* is approximately proportional to the voltage and takes both positive and negative values — exactly what is needed for PAM/QAM in the field. Large drive swings reach the sine's curvature and the outer constellation points get compressed. This is a real trade-off between signal power (good for SNR) and nonlinear distortion.

### IQ modulator
Two MZMs (one for I, one for Q) in a "nested" structure, with a 90° phase shift on the Q arm, produce $E_{out}\propto x_I(t)+jx_Q(t)$. For dual polarization: split the laser, modulate each half with its own IQ modulator, rotate one by 90°, and combine with a polarization beam combiner. Imperfections: the 90° phase may not be exact (**quadrature error**), the I and Q gains may differ (**IQ imbalance**), and the electrical paths may differ in length (**IQ skew**, a few ps matter at 100+ GBd).

### DAC and drivers
High-speed DACs (well above 100 GSa/s today) have limited analog bandwidth and ENOB. The transmitter DSP pre-compensates the combined frequency response (digital **pre-emphasis**) and performs pulse shaping and sometimes nonlinear pre-distortion.

## 5.3 Fiber attenuation

Standard single-mode fiber (SSMF, ITU-T G.652) loses about 0.18–0.2 dB/km at 1550 nm (ultra-low-loss fibers ~0.15 dB/km) and ~0.33 dB/km at 1310 nm. The field decays as $e^{-\alpha z/2}$ with $\alpha$ the power attenuation in 1/m ($\alpha_{dB/km} = 4.343\,\alpha_{1/km}$). Loss is compensated by EDFAs (C-band ~1530–1565 nm; L-band ~1565–1625 nm), which add ASE noise (Chapter 3).

## 5.4 Chromatic dispersion (CD)

### Physical origin in words
The refractive index of glass (and the waveguide structure) depends on wavelength, so different frequency components of a pulse travel at different speeds. A short pulse contains a range of frequencies; after propagation they arrive at different times and the pulse spreads out. It is a **linear, deterministic, all-pass** effect — no energy is lost, only rearranged in time. That is why it can be undone perfectly in a coherent receiver that has access to the full field.

### Mathematics
Expand the propagation constant around the carrier $\omega_0$ (with $\omega$ now the baseband angular frequency offset):

$$\beta(\omega_0+\omega) = \beta_0 + \beta_1\omega + \frac{\beta_2}{2}\omega^2 + \frac{\beta_3}{6}\omega^3 + \dots$$

- $\beta_0$: a constant phase — irrelevant.
- $\beta_1 = 1/v_g$: the group delay per unit length — a common delay, irrelevant.
- $\beta_2$: **group-velocity dispersion** (s²/m) — the main effect.
- $\beta_3$: dispersion slope — matters for very wide bandwidths.

Keeping the $\beta_2$ term, the fiber acts on the complex envelope as (in this tutorial's convention)

$$\boxed{H_{CD}(\omega) = \exp\left(-j\frac{\beta_2L}{2}\omega^2\right)}$$

Engineers usually quote the **dispersion parameter** $D$ in ps/(nm·km):

$$D = -\frac{2\pi c}{\lambda^2}\beta_2 \qquad\Longleftrightarrow\qquad \beta_2 = -\frac{D\lambda^2}{2\pi c}.$$

For SSMF at 1550 nm, $D\approx17$ ps/(nm·km), so $\beta_2\approx-21.7$ ps²/km. At 1310 nm, $D\approx0$ (the zero-dispersion wavelength of G.652 fiber is between 1300 and 1324 nm). `od.beta2_from_D()` performs this conversion.

### Group delay picture
The group delay is $\tau(\omega) = -\frac{d\angle H}{d\omega} = \beta_2L\omega$: linear in frequency. The delay spread across a signal of bandwidth $B$ (Hz) is

$$\Delta\tau = |\beta_2|L\cdot2\pi B = |D|\,L\,\Delta\lambda,\qquad \Delta\lambda=\frac{\lambda^2}{c}B.$$

**Example.** 64 GBd signal ($B\approx64$ GHz, $\Delta\lambda\approx0.51$ nm) over 1000 km: $\Delta\tau = 17\times1000\times0.51\approx8.7$ ns ≈ **560 symbols** of memory. Over 80 km: ≈ 45 symbols. Accumulated dispersion is often quoted in ps/nm: 1000 km × 17 = 17,000 ps/nm.

The **dispersion length** $L_D = T^2/|\beta_2|$ is the distance over which a pulse of width $T$ spreads noticeably: for 64 GBd ($T=15.6$ ps), $L_D\approx11$ km. Memory grows **with the square of the symbol rate** — doubling the baud rate quadruples the CD filter length at fixed sps. (Problem 2.2 computed these tap counts.)

![Pulse broadening by chromatic dispersion](figures/ch5_cd_broadening.png)

*Figure 5.1 — A 10 ps Gaussian pulse after 0, 2, 5 and 10 km of SSMF at 1550 nm (computed with `od.cd_channel`). The energy is conserved but spread in time: at 64 GBd one symbol lasts 15.6 ps, so after only 10 km each pulse overlaps several neighbours.*

### Why IM/DD suffers more
A direct-detection receiver measures only $|E|^2$. The dispersed field's phase information, needed to undo the all-pass filter, is gone. Worse, the beating of spectral components produces **power fading**: frequency nulls in the detected electrical spectrum at

$$f_{null,k}=\sqrt{\frac{(2k+1)c}{2|D|L\lambda^2}},\qquad k=0,1,\dots$$

For 10 km at 1550 nm, the first null is at 19.2 GHz — inside the band of a 56 GBd PAM4 signal. That is why data-centre IM/DD links operate in the O-band near zero dispersion (Chapter 7).

![IM/DD power-fading transfer function](figures/ch5_power_fading.png)

*Figure 5.2 — Small-signal electrical response $|\cos(\beta_2L\omega^2/2)|$ of an IM/DD link in the C-band (derived in Chapter 7.5). Deep nulls move to lower frequency as the length grows; at 10 km the first null (19.2 GHz) lies inside a 56 GBd signal's band.*

## 5.5 Polarization effects

### Jones vectors and matrices
Single-mode fiber actually supports **two** orthogonal polarization modes. We write the field as a Jones vector $\mathbf{E}=[E_X,E_Y]^T$. Any lossless, frequency-flat polarization transformation is a $2\times2$ **unitary** matrix $\mathbf{J}$ ($\mathbf{J}^H\mathbf{J}=\mathbf{I}$), e.g.

$$\mathbf{J}=\begin{bmatrix}\cos\theta & -\sin\theta\\ \sin\theta & \cos\theta\end{bmatrix}\begin{bmatrix}e^{j\phi/2}&0\\0&e^{-j\phi/2}\end{bmatrix}.$$

Because of stress, bends and temperature, the state of polarization (SOP) at the output is random and changes with time. Typical rates are slow (ms–s), but mechanical disturbances and lightning strikes on aerial cables can cause SOP rotations of hundreds of krad/s up to Mrad/s. **The receiver must track them** — the adaptive equalizer's step size must be large enough (Chapter 6).

The receiver sees a *mixture*: port X receives $J_{11}E_X+J_{12}E_Y$. Undoing it requires the inverse, $\mathbf{J}^H$ — a 2×2 "butterfly".

### Polarization-mode dispersion (PMD)
Fiber is slightly birefringent: the two polarization modes travel at slightly different speeds. Over a short section, one principal state is delayed by the **differential group delay (DGD)** $\tau$ relative to the other:

$$\mathbf{H}_{PMD}(\omega) = \mathbf{R}_2\begin{bmatrix}e^{-j\omega\tau/2}&0\\0&e^{+j\omega\tau/2}\end{bmatrix}\mathbf{R}_1.$$

Over long fibers the birefringence axes change randomly along the length, so PMD is statistical: the mean DGD grows as $\langle\tau\rangle = \text{PMD}_{coef}\sqrt{L}$, with modern fibers around 0.04–0.1 ps/√km (older fibers can be much worse). For 1000 km at 0.1 ps/√km: $\langle\tau\rangle\approx3.2$ ps — a fraction of a symbol at 64 GBd, but not negligible at 200+ GBd. Since the matrix is frequency-dependent, the equalizer needs multiple taps per branch.

### Polarization-dependent loss (PDL)
Components (ROADMs, isolators, couplers) attenuate one polarization more than the other. PDL makes $\mathbf{J}$ non-unitary; it cannot be fully undone without enhancing noise, so it causes a real SNR penalty (often ~0.5–1 dB margin is allocated). DSP cannot remove it — only mitigate it.

## 5.6 Fiber nonlinearity

### The Kerr effect
Glass's refractive index increases slightly with optical intensity: $n = n_0 + n_2|E|^2/A_{eff}$. The signal therefore modulates its own phase (**self-phase modulation**, SPM), the phase of other WDM channels (**cross-phase modulation**, XPM), and creates new frequencies (**four-wave mixing**, FWM). Characterised by the nonlinear coefficient $\gamma = \frac{2\pi n_2}{\lambda A_{eff}}\approx1.3$ W⁻¹km⁻¹ for SSMF.

### The nonlinear Schrödinger equation (NLSE)
The scalar envelope obeys (this tutorial's sign convention; Agrawal's textbook form is the complex conjugate):

$$\frac{\partial A}{\partial z} = -\frac{\alpha}{2}A + j\frac{\beta_2}{2}\frac{\partial^2A}{\partial t^2} - j\gamma|A|^2A.$$

Three terms: loss, dispersion (linear, frequency domain), Kerr nonlinearity (instantaneous, time domain). For dual polarization with random birefringence, the averaged form is the **Manakov equation**, where $|A|^2$ becomes $\frac89(|A_X|^2+|A_Y|^2)$.

### Split-step Fourier method (SSFM)
No closed-form solution exists, but each term alone is easy: dispersion is a multiplication in the frequency domain, nonlinearity is a multiplication in the time domain. For a small step $\Delta z$, alternate them. The symmetric version (half linear – full nonlinear – half linear) is second-order accurate:

```python
def ssfm(x, fs, L_m, n_steps, alpha_db_km=0.2, D_ps_nm_km=17.0, gamma=1.3e-3):
    b2 = od.beta2_from_D(D_ps_nm_km); alpha = alpha_db_km/4.343/1e3
    dz = L_m/n_steps; w = 2*np.pi*np.fft.fftfreq(len(x), 1/fs)
    Hhalf = np.exp((-1j*b2*w**2/2 - alpha/2) * dz/2)
    leff = (1 - np.exp(-alpha*dz))/alpha * np.exp(alpha*dz/2)   # referenced to mid-step power
    A = x.astype(complex)
    for _ in range(n_steps):
        A = np.fft.ifft(np.fft.fft(A) * Hhalf)
        A = A * np.exp(-1j * gamma * np.abs(A)**2 * leff)
        A = np.fft.ifft(np.fft.fft(A) * Hhalf)
    return A
```

A subtle point we caught while testing: the nonlinear step is applied to the *mid-step* power (already attenuated by half a step), so its effective length must be referenced to that point. With a naive effective length, the accumulated nonlinear phase is ~2% low in the test. With the corrected one, the simulated SPM phase matches $\gamma P L_{eff}$ exactly (see `test_optdsp.py`). The step size must also be small enough; check convergence by halving it.

**Effective length.** Because power decays along a span, nonlinearity acts strongly only near the start. $L_{eff}=(1-e^{-\alpha L})/\alpha\approx21$ km for an 80 km span at 0.2 dB/km. The nonlinear phase per span is $\phi_{NL}=\gamma P L_{eff}$: 0.27 rad at 10 dBm.

### The optimum launch power and the GN model
In dispersion-unmanaged coherent links (no optical dispersion compensation, as all modern links are), dispersion spreads each pulse over hundreds of symbols, and the nonlinear distortion accumulates from so many independent contributions that it behaves like additional **Gaussian noise** whose power grows as $P^3$ — the essence of the **Gaussian-noise (GN) model** (Poggiolini, 2012):

$$\text{SNR} = \frac{P}{P_{ASE} + \eta P^3}.$$

Maximising over $P$: $\frac{d}{dP}\text{SNR}=0\Rightarrow P_{ASE}+\eta P^3 - 3\eta P^3=0$, so

$$P_{opt} = \left(\frac{P_{ASE}}{2\eta}\right)^{1/3},\qquad P_{NLI}(P_{opt}) = \tfrac12P_{ASE}.$$

At the optimum, nonlinear noise is exactly half the ASE noise, and the SNR is 1.76 dB below what ASE alone would give at that power. Below the optimum, SNR rises 1 dB per dB (linear regime); above, it falls 2 dB per dB (nonlinear regime).

Our split-step experiment (`code/ch5_launch_power_sweep.py`: single channel, 32 GBd, 10 × 80 km, NF = 5 dB) gives:

| Launch power (dBm) | −4 | −2 | 0 | 2 | 4 | 6 | 8 |
|---|---|---|---|---|---|---|---|
| SNR (dB), SSFM | 21.3 | 21.8 | 20.4 | 17.4 | 13.5 | 9.4 | 4.9 |
| SNR (dB), ASE only (γ = 0) | 22.0 | 24.0 | 26.0 | 28.0 | 30.0 | 32.0 | 34.0 |

![SNR versus launch power](figures/ch5_launch_power.png)

*Figure 5.3 — The launch-power trade-off. Below the optimum, more power means more SNR (+1 dB/dB, ASE-limited); above it, nonlinear interference grows as P³ and the SNR falls (−2 dB/dB).*

The ASE-only results match the analytic "58 dB rule" to within 0.1 dB. The optimum is near −2 dBm. A closed-form GN-model calculation for the same link predicts an optimum near −1 dBm with a peak about 1 dB higher; this level of agreement is typical because the simple GN formula assumes nonlinear noise adds incoherently from span to span, which is not exactly true for a single channel. In a fully loaded WDM system, XPM from neighbouring channels adds more NLI and the per-channel optimum typically drops to roughly 0–2 dBm.

DSP responses to nonlinearity: digital back-propagation (solving the NLSE backwards in the receiver), perturbation-based compensation, and machine-learning approaches (Chapter 8). In practice, gains of ~0.5–1 dB for single-channel compensation are common, which is why commercial systems mostly rely on optimal launch power plus modest nonlinear mitigation.

## 5.7 Lasers: phase noise and frequency offset

Chapter 3 modelled phase noise as a Wiener process. In addition, the TX laser and LO are separate free-running lasers, so their frequencies differ by a **frequency offset** $\Delta f$. With tunable lasers locked to the ITU grid, $|\Delta f|$ is typically up to a few GHz at start-up (frequency accuracy specifications of about ±1.5–2.5 GHz are common) and drifts slowly. The received signal is multiplied by $e^{j(2\pi\Delta f\,t+\phi(t))}$ — the constellation spins. This is called **intradyne** detection: the LO is *near* but not locked to the carrier, and DSP removes the residual offset.

## 5.8 The coherent receiver front end

### The 90° optical hybrid and balanced detection
The hybrid combines the received signal $E_s$ with the LO $E_{LO}$ into four outputs:

$$\tfrac12(E_s+E_{LO}),\quad\tfrac12(E_s-E_{LO}),\quad\tfrac12(E_s+jE_{LO}),\quad\tfrac12(E_s-jE_{LO}).$$

A photodiode measures power: $|E_s\pm E_{LO}|^2 = |E_s|^2+|E_{LO}|^2\pm2\mathrm{Re}\{E_sE_{LO}^*\}$. Subtracting the two photocurrents of a **balanced pair** cancels the unwanted $|E_s|^2$ and $|E_{LO}|^2$ terms:

$$i_I\propto\mathrm{Re}\{E_sE_{LO}^*\},\qquad i_Q\propto\mathrm{Im}\{E_sE_{LO}^*\}.$$

So $i_I+ji_Q\propto E_s\,E_{LO}^*$. With $E_{LO}=\sqrt{P_{LO}}e^{j(\omega_{LO}t+\phi_{LO})}$, the output is the signal's complex envelope, scaled by $\sqrt{P_{LO}}$ (the **LO gain**, which lifts the signal above the electronics noise), shifted by the frequency offset, and multiplied by the combined phase noise. Two such hybrids behind a polarization beam splitter (**polarization diversity**) give four real signals: $X_I, X_Q, Y_I, Y_Q$, digitised by four ADCs.

### Front-end imperfections
- **IQ imbalance / quadrature error** from the hybrid and unequal photodiode responsivities: fixed by Gram–Schmidt orthogonalisation (Chapter 6).
- **Skew** between the four lanes: a few ps of path mismatch rotates the constellation in a frequency-dependent way; fixed by per-lane fractional delays.
- **Limited bandwidth** of PDs/TIAs/ADCs: absorbed by the adaptive equalizer.
- **Imperfect common-mode rejection** of balanced detectors: residual $|E_s|^2$ terms (signal–signal beat), usually small with a strong LO.

## 5.9 The direct-detection receiver

A single photodiode measures $i(t)\propto|E(t)|^2$ (the **square-law**). For intensity modulation, $|E|^2$ carries the data, so without dispersion the data is recovered directly. With dispersion, the field's phase has been rearranged and squaring mixes spectral components nonlinearly, producing power fading. Remedies — O-band operation, dispersion-tolerant formats, self-coherent schemes such as the Kramers–Kronig receiver — are the subject of Chapter 7.

## 5.10 The complete channel model in code

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
rng = np.random.default_rng(0)
Rs, sps, M, L = 32e9, 4, 16, 800e3
s = np.vstack([od.bits_to_symbols(rng.integers(0, 2, 4*2**14), M) for _ in range(2)])
h = od.rrc_taps(0.1, sps, 64)
x = np.vstack([od.filter_same(od.upsample(s[p], sps), h) for p in range(2)])   # TX
x = od.cd_channel(x, sps*Rs, L)                                              # CD
x = od.random_unitary_2x2(rng) @ x                                           # SOP rotation
x = np.vstack([od.add_awgn(x[p], 18, sps=sps, rng=rng) for p in range(2)])   # ASE
n = np.arange(x.shape[1])
x = x * np.exp(1j*(2*np.pi*1e9*n/(sps*Rs) + od.laser_phase_noise(len(n), 200e3, sps*Rs, rng)))  # FO + PN
```

The capstone (`code/capstone_coherent_link.py`) uses a more complete version of this channel. It adds first-order PMD (`od.pmd_first_order`), a polarization rotation that changes in time (`od.sop_dynamic`), optional PDL (`od.pdl_element`), and — importantly — a model of the receiver's **analog front end and ADC**:

```python
from scipy.signal import firwin
g = firwin(129, 0.75*Rs / (sps*Rs/2))                   # band-limited PDs/TIAs: cutoff 0.75*Rs
x = np.vstack([od.filter_same(x[p], g) for p in range(2)])
rx = np.vstack([od.adc_sample(x[p], sps, 2, ppm=20, phase=0.6) for p in range(2)])  # free-running ADC
```

`od.adc_sample` samples the waveform at 2(1 + ppm·10⁻⁶) samples per symbol starting at an arbitrary fractional phase: the ADC clock is *not* synchronised to the transmitter, so the receiver must recover timing (Chapter 6.4). Chapter 6 builds the receiver that undoes each step.

## 5.11 Common pitfalls

1. Mixing sign conventions between the NLSE, the CD filter and the Fourier transform (the result: dispersion *doubles* instead of cancelling). Test with $L_{CD}$ followed by the compensator — you must get the input back.
2. Simulating nonlinear propagation at too few samples per symbol: the spectrum broadens and aliases. Use ≥ 4 sps (more for WDM).
2b. **Sampling a noisy signal at 2 sps without an anti-aliasing (front-end) filter.** White noise in the simulation extends over the whole simulation bandwidth (e.g. ±2R_s at 4 sps); decimating to 2 sps folds the out-of-band noise into the signal band and doubles it. In the capstone this costs ≈ 3 dB (8.6 dB → 6.1 dB for DP-QPSK at OSNR 13 dB). Real receivers are band-limited by their photodiodes, TIAs and ADC input, which acts as the anti-aliasing filter — so model it.
3. Too large a split-step size — always check convergence by halving the step.
4. Forgetting that PDL cannot be undone by a unitary equalizer.
5. Using the single-polarization OSNR/SNR relation for a dual-polarization simulation or vice versa.

## 5.12 Check your understanding

1. Why is chromatic dispersion perfectly reversible in a coherent receiver but not in a direct-detection receiver?
2. You double the symbol rate. By what factor does the CD memory (in symbols) change? And the number of CD filter taps at 2 sps?
3. What is the physical meaning of a unitary Jones matrix?
4. At the optimum launch power, what fraction of the total noise is nonlinear?

<details><summary>Answers</summary>

1. The coherent receiver has the full field (amplitude and phase), so it can apply the inverse all-pass filter. Direct detection keeps only $|E|^2$; the phase information needed for inversion is lost and the squaring mixes frequencies.
2. The delay spread in seconds doubles (twice the bandwidth), and the symbol period halves, so memory in symbols grows 4×; taps at 2 sps also grow 4×.
3. A lossless polarization transformation: it preserves total power and the orthogonality of the two polarization states.
4. One third ($P_{NLI}=P_{ASE}/2$, so $P_{NLI}/(P_{ASE}+P_{NLI})=1/3$).
</details>

## 5.13 Problems

### Problem 5.1 ★ — CD numbers
For a 130 GBd signal on SSMF (D = 17 ps/(nm·km), 1550 nm): (a) compute $\beta_2$; (b) the accumulated dispersion and the delay spread after 1500 km; (c) the memory in symbols.

<details><summary>Solution</summary>

(a) $\beta_2=-D\lambda^2/(2\pi c) = -17\times10^{-6}\cdot(1.55\times10^{-6})^2/(2\pi\cdot3\times10^8) = -2.17\times10^{-26}$ s²/m $=-21.7$ ps²/km.

(b) Accumulated: 17 × 1500 = 25,500 ps/nm. $\Delta\lambda = \lambda^2B/c = (1.55\text{e-}6)^2\cdot130\text{e}9/3\text{e}8 = 1.04$ nm. $\Delta\tau = 25{,}500\times1.04\approx26.5$ ns.

(c) $26.5\text{ ns}\times130$ GBd ≈ **3450 symbols**. That is why frequency-domain CD compensation is indispensable at modern baud rates.
</details>

### Problem 5.2 ★★ — Balanced detection derivation
Show that with an ideal 90° hybrid and two balanced pairs, $i_I+ji_Q = R\,E_sE_{LO}^*$ (with $R$ the responsivity), and that the terms $|E_s|^2$ and $|E_{LO}|^2$ cancel. What happens if one photodiode of the I pair has 5% lower responsivity?

<details><summary>Solution</summary>

Pair I: $R|\tfrac12(E_s+E_{LO})|^2 - R|\tfrac12(E_s-E_{LO})|^2 = \tfrac R4\left[4\mathrm{Re}\{E_sE_{LO}^*\}\right]=R\,\mathrm{Re}\{E_sE_{LO}^*\}$. Pair Q: $|E_s+jE_{LO}|^2-|E_s-jE_{LO}|^2 = 4\mathrm{Re}\{E_s(jE_{LO})^*\} = 4\mathrm{Re}\{-jE_sE_{LO}^*\} = 4\mathrm{Im}\{E_sE_{LO}^*\}$. So $i_I+ji_Q=R\,E_sE_{LO}^*$ (up to the factor convention). The direct-detection terms appear with equal weight in both diodes and cancel.

With a 5% responsivity mismatch, a fraction $0.05/4\cdot(|E_s|^2+|E_{LO}|^2)$ survives. The $|E_{LO}|^2$ part is a DC offset (easily removed); the $|E_s|^2$ part is a signal–signal beat interference term that adds distortion, and LO RIN leaks through. This is why balanced detectors specify a high common-mode rejection ratio (CMRR).
</details>

### Problem 5.3 ★★ — PMD as a 2×2 filter (coding)
Implement first-order PMD with DGD τ = 10 ps and random input/output rotations on a DP-QPSK signal at 64 GBd, 2 sps. Show that a single-tap 2×2 inverse (using the true rotation matrices at DC) is not sufficient, and that the full frequency-domain inverse restores the signal.

<details><summary>Solution</summary>

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
rng = np.random.default_rng(1); Rs, sps = 64e9, 2
s = np.vstack([od.bits_to_symbols(rng.integers(0, 2, 2*2**14), 4) for _ in range(2)])
h = od.rrc_taps(0.1, sps, 64)
x = np.vstack([od.filter_same(od.upsample(s[p], sps), h) for p in range(2)])
R1, R2 = od.random_unitary_2x2(rng), od.random_unitary_2x2(rng); tau = 10e-12
w = 2*np.pi*np.fft.fftfreq(x.shape[1], 1/(sps*Rs))
X = R1 @ np.fft.fft(x, axis=1)
X = np.vstack([X[0]*np.exp(-1j*w*tau/2), X[1]*np.exp(1j*w*tau/2)])
Y = R2 @ X                                   # channel output (frequency domain)
def snr_of(Yf):
    y = np.fft.ifft(Yf, axis=1)
    y = np.vstack([od.filter_same(y[p], h)[::sps] for p in range(2)])
    return [round(od.snr_estimate_db(y[p][200:-200], s[p][200:-200]), 1) for p in range(2)]
Hinv_dc = np.linalg.inv(R2 @ R1)             # single-tap inverse (ignores the DGD)
print("single-tap:", snr_of(Hinv_dc @ Y))
Z = R2.conj().T @ Y
Z = np.vstack([Z[0]*np.exp(1j*w*tau/2), Z[1]*np.exp(-1j*w*tau/2)])
print("full inverse:", snr_of(R1.conj().T @ Z))
```
With seed 1, the single-tap inverse gives only ≈ 4.4 dB: 10 ps of DGD is 0.64 symbol at 64 GBd, so the two principal states are badly misaligned in time and the DC-only inverse leaves heavy ISI and polarization crosstalk (the exact number depends on the random rotations). The frequency-dependent inverse gives ≈ 58.7 dB (the numerical limit set by filter truncation). A multi-tap adaptive butterfly (Chapter 6) learns this frequency-dependent inverse automatically.
</details>

### Problem 5.4 ★★★ — The launch-power optimum (coding assignment)
Run `code/ch5_launch_power_sweep.py`. (a) Verify the low-power SNR against the 58-dB rule (remember this is a *single-polarization* simulation with noise only in the signal polarization, so SNR = OSNR·2B_ref/R_s). (b) Estimate the optimum launch power and the SNR penalty relative to ASE-only at that power; compare with the GN-model prediction of 1.76 dB. (c) Double the number of spans. How much do the optimum power and optimum SNR change? Compare with the GN-model scaling.

<details><summary>Solution</summary>

(a) At −4 dBm: OSNR = 58 − 4 − 5 − 16 − 10 = 23 dB; SNR = 23 + 10log₁₀(25/32) = 21.9 dB. Setting γ = 0 in the script gives 22.0 dB. ✓.

(b) The peak is ≈ 21.8 dB near −2 dBm, where ASE-only would give 24.0 dB — a penalty of ≈ 2.2 dB, close to 1.76 dB given the 2 dB grid (the true optimum lies between −4 and −2 dBm; refine the grid to see it).

(c) GN theory: $P_{ASE}\propto N$ and $\eta\propto N$ (incoherent accumulation), so $P_{opt}=(P_{ASE}/2\eta)^{1/3}$ is unchanged and the optimum SNR drops by 3 dB. In simulation (`link_snr(P, n_spans=20)`, 1 dB grid), the peak drops from ≈ 21.8 dB to ≈ 18.4 dB (≈ 3.4 dB, slightly more than 3 dB) and the optimum moves from about −2.5 dBm to about −3 dBm, because NLI accumulates partly coherently across spans ($\eta\propto N^{1+\epsilon}$ with small ε > 0).
</details>

### Problem 5.5 ★★★ — Design: one carrier at 200 GBd, or two at 100 GBd?
A 1.6 Tb/s transceiver can be built as one DP-PCS-QAM carrier at ~200 GBd or two carriers at ~100 GBd. For a 3000 km link, compare: (a) the CD time-domain tap count per carrier at 2 sps and the frequency-domain cost per bit; (b) equalization-enhanced phase noise (EEPN) with a 100 kHz LO linewidth, using the approximate formula $\sigma^2_{EEPN}\approx\dfrac{\pi c D L\,\Delta\nu_{LO}}{2 f_0^2 T}$ (Shieh & Ho, 2008), with $T$ the symbol period and $f_0$ = 193.4 THz; (c) hardware aspects. Which would you choose for a long-haul product and which for a short-reach pluggable?

<details><summary>Solution</summary>

(a) Taps $\approx |D|\lambda^2Lf_s^2/c$: 200 GBd → ≈ 65,300 taps; 100 GBd → ≈ 16,300 taps per carrier (4× fewer, but two carriers). In the frequency domain the cost per sample grows only logarithmically, so per bit the two options differ by just a couple of multiplications per sample — CD complexity is **not** the deciding factor with FD compensation.

(b) $\sigma^2_{EEPN}$ ∝ symbol rate: 200 GBd → ≈ 0.0128 rad² (an SNR-equivalent limit ≈ 18.9 dB); 100 GBd → ≈ 0.0064 rad² (≈ 21.9 dB). For a PCS-64QAM signal needing ~15–17 dB, an 18.9 dB impairment is a significant penalty (inverse SNRs add!), so the single 200 GBd carrier needs a narrower-linewidth LO or EEPN mitigation for long haul.

(c) One carrier at 200 GBd needs ~100 GHz analog bandwidth in DAC, driver, modulator, PD and ADC — harder components — but only one set of optics and one laser pair, which lowers cost and power per bit. Two carriers need twice the optics or a more complex multi-carrier transmitter, but relaxed bandwidths.

Typical industry answer (2026): high-performance long-haul products push single-carrier baud rates up (~200 GBd with narrow-linewidth lasers and strong DSP), because fewer optics per bit wins economically when the components exist; digital-subcarrier designs split one optical carrier into several digital subcarriers to get EEPN and CD benefits without extra optics. There is no universally right answer — which is exactly why it is a design question.
</details>

---

## Key takeaways

- **CD**: $H(\omega)=e^{-j\beta_2L\omega^2/2}$, all-pass, memory ∝ $R_s^2L$; D = 17 ps/(nm·km) at 1550 nm, ≈ 0 at 1310 nm.
- **Polarization** is a 2×2 matrix problem: unitary rotation (tracked by the equalizer), frequency-dependent PMD (needs multiple taps), and PDL (not unitary — a real penalty).
- **Kerr nonlinearity**: NLSE; split-step simulation; in dispersion-unmanaged links it acts like noise ∝ P³, giving an **optimum launch power** where NLI = ASE/2.
- **Coherent front end**: $i_I+ji_Q\propto E_sE_{LO}^*$ — the complex envelope times frequency offset and phase noise.
- **Model the ADC honestly**: band-limited front end, free-running clock with ppm offset and unknown phase.

---

**Next:** Chapter 6 — the centrepiece: building the complete coherent receiver DSP chain.
