# Chapter 1 — Complex Baseband, Sampling and Spectra

> **How to use this chapter.** Read §1.1–1.3 in one sitting, then run the code in §1.4 and change its parameters until the figures make sense. Problems are rated ★ (check understanding), ★★ (apply and code), ★★★ (design/open-ended). Mathematical background you may need is in `appendix_A_math_and_glossary.md`.

> **Learning objectives.** After this chapter you can (1) explain why an optical signal at 193 THz can be processed by a chip running at a few GHz, (2) move between passband and complex-baseband descriptions, (3) state and apply the sampling theorem for complex signals, (4) compute a spectrum with the FFT and interpret the frequency axis, resolution, leakage and windowing correctly, and (5) avoid the classic circular-convolution trap.

---

## 1.1 The big picture: why "complex baseband"?

Light in a standard telecom fiber has a wavelength near 1550 nm, which corresponds to a carrier frequency

$$f_0 = \frac{c}{\lambda} = \frac{3\times10^8}{1.55\times10^{-6}} \approx 193.4\ \text{THz}.$$

No electronics can sample 193 THz. Fortunately we never need to. The *information* occupies only a narrow band around $f_0$ — for a 64 GBd signal, roughly 64–70 GHz of bandwidth. The carrier itself carries no information; it is just the "vehicle". So we describe the signal by its **complex envelope** (also called the complex baseband signal): a complex-valued function of time that captures how the amplitude and phase of the carrier are being modulated.

**The intuition.** Picture the optical field as a very fast spinning arrow (a phasor) rotating 193 trillion times per second. The modulator slowly (by comparison) changes the length and the angle of that arrow. If you stand on a merry-go-round that spins at exactly the carrier frequency, the fast rotation disappears, and you see only the slow changes in length and angle. That view from the merry-go-round is the complex baseband signal. In a coherent receiver, the **local oscillator (LO) laser** plays the role of the merry-go-round: mixing the received light with the LO removes the carrier and leaves the baseband signal.

### The mathematics

A real passband signal with carrier $f_0$ can always be written as

$$s(t) = \mathrm{Re}\{\,x(t)\,e^{j2\pi f_0 t}\,\} = x_I(t)\cos(2\pi f_0 t) - x_Q(t)\sin(2\pi f_0 t),$$

where $x(t) = x_I(t) + j\,x_Q(t)$ is the complex envelope. $x_I$ is the **in-phase** component and $x_Q$ the **quadrature** component. Writing $x(t)=a(t)e^{j\phi(t)}$, the amplitude is $a(t)$ and the phase is $\phi(t)$.

In the frequency domain, if $S(f)$ is the spectrum of $s(t)$ and $X(f)$ that of $x(t)$,

$$S(f) = \tfrac12 X(f-f_0) + \tfrac12 X^*(-f-f_0).$$

So the passband spectrum is just the baseband spectrum shifted up to $+f_0$ (plus its mirror image at $-f_0$, required because $s$ is real). **Key consequence:** $X(f)$ need not be symmetric. A complex baseband signal can have different content at positive and negative frequencies, because positive frequencies correspond to "above the carrier" and negative frequencies to "below the carrier".

### Why complex numbers are *natural*, not a trick

In an optical system the complex envelope is physically meaningful: the magnitude squared $|x(t)|^2$ is the instantaneous optical power, and the angle is the optical phase. A coherent receiver actually measures $x_I$ and $x_Q$ with two separate photodetector pairs (Chapter 5). A direct-detection receiver measures only $|x(t)|^2$ and throws the phase away — which is exactly why it cannot undo chromatic dispersion easily (Chapter 7).

---

## 1.2 Bandwidth of complex signals

For a real signal, we usually quote the one-sided bandwidth $B$ (content from $0$ to $B$). For a complex baseband signal, the spectrum occupies some band $[f_{\min}, f_{\max}]$ that can include negative frequencies. The **total (two-sided) width** $W = f_{\max}-f_{\min}$ is what matters.

Example: a QAM signal at symbol rate $R_s$ with root-raised-cosine shaping of roll-off $\beta$ occupies $[-\tfrac{(1+\beta)R_s}{2},\ +\tfrac{(1+\beta)R_s}{2}]$, so $W=(1+\beta)R_s$. For 64 GBd and $\beta=0.1$: $W = 70.4$ GHz. On the optical spectrum analyzer you would see a 70.4 GHz-wide signal centered at the carrier.

![Spectrum of a 32 GBd QPSK signal for two roll-off factors](figures/ch1_qam_spectrum.png)

*Figure 1.1 — Complex-baseband spectrum of 32 GBd QPSK (computed in `code/make_figures.py`). Both roll-offs are half-power at ±R_s/2 = ±16 GHz (dotted lines); the roll-off only changes the "skirt". Zero frequency is the optical carrier: negative frequencies are simply optical frequencies below it.*

---

## 1.3 Sampling

### Real signals (review)

A real signal band-limited to $|f|<B$ can be recovered from samples at $f_s > 2B$. Sampling creates spectral **replicas** at every multiple of $f_s$; if $f_s>2B$ they do not overlap.

### Complex signals

For a complex signal occupying a total width $W$, it is enough to have

$$f_s > W,$$

because each complex sample carries *two* real numbers (I and Q). Counting real numbers per second, $2f_s > 2W$ — the same rate a real signal of one-sided bandwidth $W$ would need. Equivalently: one complex sample per second per hertz of total bandwidth.

**Intuition.** The sampling theorem is really a statement about degrees of freedom. A signal of total width $W$ has $W$ complex degrees of freedom per second. A real signal of one-sided bandwidth $B$ has $2B$ real degrees of freedom per second. Either way, you need at least as many numbers as there are degrees of freedom.

### Samples per symbol

In optical DSP we usually count samples per symbol (sps) rather than hertz:

- **Simulations** commonly use 2 sps at the receiver (and 4–16 sps at the transmitter or inside the fiber model, to capture spectral broadening).
- **Commercial ASICs** run the ADC at a *fractional* oversampling such as about 1.1–1.25 sps, because every extra sample costs power. The DSP then resamples internally. This works because a signal of width $(1+\beta)R_s$ needs only $f_s > (1+\beta)R_s$, i.e. sps $>1+\beta$.

### Aliasing in practice

If $f_s$ is too low, the parts of the spectrum above $f_s/2$ fold back into the band. In a complex signal the fold goes "around the circle": frequency $f$ appears at $f - k f_s$ for the integer $k$ that brings it into $[-f_s/2, f_s/2)$. There is no mirror-image folding like with real signals; content at $+0.6 f_s$ shows up at $-0.4 f_s$.

---

## 1.4 From continuous to discrete: DTFT, DFT, FFT

### DTFT

For a sequence $x[n]$ sampled at $f_s$:

$$X(e^{j\Omega}) = \sum_{n=-\infty}^{\infty} x[n]\,e^{-j\Omega n}, \qquad \Omega = 2\pi f/f_s.$$

It is periodic in $\Omega$ with period $2\pi$ (i.e. in $f$ with period $f_s$) — that periodicity *is* the replicas created by sampling.

### DFT

We can only compute a finite number of frequencies from a finite record of $N$ samples:

$$X[k] = \sum_{n=0}^{N-1} x[n]\,e^{-j2\pi kn/N},\quad k=0,\dots,N-1, \qquad x[n]=\frac1N\sum_{k=0}^{N-1}X[k]e^{j2\pi kn/N}.$$

The DFT samples the DTFT at $N$ equally spaced frequencies $f_k = k f_s/N$. The **FFT** is simply a fast algorithm ($\mathcal{O}(N\log N)$ instead of $\mathcal{O}(N^2)$) that computes exactly the DFT.

### The frequency axis — get this right once and for all

Bin $k$ corresponds to frequency $k f_s/N$ for $k < N/2$, and to $(k-N)f_s/N$ (a *negative* frequency) for $k\ge N/2$. NumPy does this for you:

```python
import numpy as np
N, fs = 8, 8.0
print(np.fft.fftfreq(N, d=1/fs))
# [ 0.  1.  2.  3. -4. -3. -2. -1.]
print(np.fft.fftshift(np.fft.fftfreq(N, d=1/fs)))
# [-4. -3. -2. -1.  0.  1.  2.  3.]
```

Use `fftfreq` whenever you build a frequency-domain filter (like the dispersion filter in Chapter 5) and `fftshift` only when *plotting*.

### Resolution, leakage and windowing

Three separate ideas that beginners mix up:

1. **Bin spacing** $\Delta f = f_s/N$. This is how finely the DTFT is sampled.
2. **Resolution** — the ability to separate two nearby tones — is set by the *record length* $T_{rec}=N/f_s$: roughly $1/T_{rec}$. Zero-padding makes the plot smoother (smaller bin spacing) but does **not** improve resolution, because it adds no new information.
3. **Leakage.** A finite record is the true signal multiplied by a rectangular window. Multiplication in time is convolution in frequency, so every spectral line gets smeared by the window's transform (a sinc with high sidelobes, the first at −13 dB). A **window** (Hann, Blackman, Kaiser) tapers the edges and trades a wider main lobe for much lower sidelobes.

![Leakage with rectangular and Blackman windows](figures/ch1_leakage.png)

*Figure 1.2 — A strong tone at 10.3 Hz (not on a bin) and a tone 60 dB weaker at 25 Hz. With the rectangular window, the strong tone's sidelobes (≈ −42 dB at 25 Hz) bury the weak one; the Blackman window lowers the sidelobes enough to reveal it, at the cost of a wider main lobe.*

**Why this matters in optical DSP.** Frequency-offset estimation (Chapter 6) finds the peak of a spectrum; its accuracy is limited by bin spacing (fix: zero-padding or interpolation) and its robustness by leakage. Spectral monitoring of OSNR also depends on these effects.

```python
import numpy as np
fs, N = 100.0, 256
n = np.arange(N)
x = np.exp(2j*np.pi*10.3*n/fs) + 1e-3*np.exp(2j*np.pi*25*n/fs)  # strong tone + weak tone (-60 dB)
for name, w in [("rect", np.ones(N)), ("blackman", np.blackman(N))]:
    X = np.fft.fftshift(np.fft.fft(x*w, 8*N))
    f = np.fft.fftshift(np.fft.fftfreq(8*N, 1/fs))
    XdB = 20*np.log10(np.abs(X)/np.abs(X).max())
    print(name, "level near 25 Hz: %.1f dB" % XdB[np.argmin(abs(f-25))])
# With the rectangular window, leakage from the 10.3 Hz tone (about -40 dB here) buries
# the -60 dB tone; with Blackman the weak tone is visible near -60 dB.
```

### Parseval's theorem

$$\sum_{n=0}^{N-1}|x[n]|^2 = \frac1N\sum_{k=0}^{N-1}|X[k]|^2.$$

Use it to sanity-check power normalisation in your code.

---

## 1.5 Circular versus linear convolution

Multiplying two DFTs corresponds to **circular** convolution, not linear convolution. If you filter a signal by `ifft(fft(x) * H)`, the tail of the filter's response wraps around and contaminates the beginning of the block.

- In **simulations** of an entire signal record, this is usually acceptable if the signal is itself periodic (e.g. you generated a random sequence and treat it as one period) — the fiber channel in `optdsp.cd_channel` works this way.
- In **real-time receivers**, the signal is an endless stream. You must use **overlap-save** or **overlap-add** (Chapter 2) so that each block equals the correct linear convolution.

Rule of thumb: to get the linear convolution of length-$N_x$ and length-$N_h$ sequences with an FFT, zero-pad both to at least $N_x+N_h-1$.

---

## 1.6 Signal power, energy and decibels

- Average power of a sampled signal: $P = \frac1N\sum |x[n]|^2$ (`np.mean(np.abs(x)**2)`).
- dB for power ratios: $10\log_{10}(P_1/P_2)$. dBm: $10\log_{10}(P/1\,\text{mW})$. So 0 dBm = 1 mW, 10 dBm = 10 mW, −3 dBm ≈ 0.5 mW.
- Adding dB values multiplies ratios. A 20 dB loss followed by a 20 dB gain is 0 dB net. But adding two *powers* in dBm requires converting to linear first: 0 dBm + 0 dBm = 3 dBm, not 0.

---

## 1.7 Common pitfalls

1. Plotting `np.fft.fft(x)` without `fftshift` and thinking the negative frequencies are "high frequencies".
2. Building a frequency-domain filter with a frequency vector `np.linspace(-fs/2, fs/2, N)` and applying it to an **unshifted** FFT. Always use `fftfreq`.
3. Forgetting that zero-padding improves the *look* but not the *resolution*.
4. Using FFT filtering on a streaming signal without overlap-save.
5. Confusing dB and dBm arithmetic.

---

## 1.8 Check your understanding

1. A coherent receiver outputs I and Q at 128 GSa/s. What is the widest complex signal it can capture without aliasing?
2. Why can the spectrum of a complex baseband signal be asymmetric, while a real signal's cannot?
3. You have 1024 samples at 64 GSa/s. What is the bin spacing? What is the approximate resolution? If you zero-pad to 8192, which of these changes?
4. Two lasers differ by 1 GHz in frequency. After coherent detection, what do you see in the baseband signal?

<details><summary>Answers</summary>

1. Total width just under 128 GHz (from −64 to +64 GHz).
2. Because negative baseband frequencies correspond to optical frequencies below the carrier, and there is no requirement that content above and below the carrier be equal. For a real signal $X(-f)=X^*(f)$ forces symmetry of the magnitude.
3. Bin spacing $64\text{e}9/1024 = 62.5$ MHz; resolution ≈ $1/T_{rec}$ = 62.5 MHz. Zero-padding reduces bin spacing to 7.8 MHz but not the resolution.
4. The whole baseband signal is multiplied by $e^{j2\pi(1\,\text{GHz})t}$: the constellation rotates continuously at 1 GHz and the spectrum is shifted by 1 GHz. Removing this is the job of frequency-offset estimation (Chapter 6).
</details>

---

## 1.9 Problems

### Problem 1.1 ★ — Passband to baseband by hand
A passband signal is $s(t) = 3\cos(2\pi f_0 t + \pi/6)$. (a) Find its complex envelope $x(t)$. (b) Now let $s(t)=\cos(2\pi(f_0+\Delta)t)$. Find $x(t)$ and describe its spectrum.

<details><summary>Solution</summary>

(a) $3\cos(2\pi f_0 t+\pi/6) = \mathrm{Re}\{3e^{j\pi/6}e^{j2\pi f_0 t}\}$, so $x(t)=3e^{j\pi/6}$ — a constant (a single point in the IQ plane at radius 3 and angle 30°).

(b) $\cos(2\pi(f_0+\Delta)t)=\mathrm{Re}\{e^{j2\pi\Delta t}e^{j2\pi f_0 t}\}$, so $x(t)=e^{j2\pi\Delta t}$: a unit phasor rotating at $\Delta$ Hz. Its spectrum is a single line at $+\Delta$ (not at $\pm\Delta$). This is exactly what a frequency offset between the transmitter laser and the LO looks like.
</details>

### Problem 1.2 ★ — Complex aliasing
A complex signal $x(t)=e^{j2\pi (40\,\text{GHz})t}$ is sampled at 64 GSa/s. At what frequency does it appear in the DFT? What if the signal were the real $\cos(2\pi (40\,\text{GHz})t)$?

<details><summary>Solution</summary>

Complex: 40 GHz is outside $[-32, 32)$ GHz. Subtract $f_s$: $40-64=-24$ GHz. It appears at −24 GHz only.

Real: $\cos$ contains $\pm 40$ GHz. $+40\to-24$ GHz, $-40\to+24$ GHz. It appears at ±24 GHz (as a real 24 GHz cosine). The complex case has no mirror, which is why complex aliasing can silently put interference on one side of your signal only.
</details>

### Problem 1.3 ★★ — Numerical: spectrum of a QAM signal (coding)
Using `optdsp`, generate 2¹⁶ QPSK symbols at 32 GBd, shape them with an RRC filter (β = 0.1, 8 sps), and plot the power spectral density in dB versus frequency in GHz. Measure the −3 dB and −20 dB widths. Repeat for β = 0.5. (Hint: average the periodogram over blocks, or use `scipy.signal.welch(..., return_onesided=False)`.)

<details><summary>Solution</summary>

```python
import numpy as np, matplotlib.pyplot as plt
from scipy.signal import welch
import sys; sys.path.append("code"); import optdsp as od

Rs, sps = 32e9, 8
for beta in [0.1, 0.5]:
    s = od.bits_to_symbols(np.random.randint(0, 2, 2*2**16), 4)
    x = od.filter_same(od.upsample(s, sps), od.rrc_taps(beta, sps, 64))
    f, P = welch(x, fs=sps*Rs, nperseg=4096, return_onesided=False)
    f, P = np.fft.fftshift(f), np.fft.fftshift(P)
    PdB = 10*np.log10(P/P.max())
    w3 = np.ptp(f[PdB > -3]); w20 = np.ptp(f[PdB > -20])
    print(f"beta={beta}: -3 dB width = {w3/1e9:.1f} GHz, -20 dB width = {w20/1e9:.1f} GHz")
    plt.plot(f/1e9, PdB, label=f"beta={beta}")
plt.xlabel("Frequency (GHz)"); plt.ylabel("PSD (dB)"); plt.ylim(-60, 3); plt.legend(); plt.grid(); plt.show()
```

Expected (one run): β = 0.1 gives −3 dB ≈ 31.6 GHz and −20 dB ≈ 34.6 GHz; β = 0.5 gives −3 dB ≈ 30–31 GHz and −20 dB ≈ 45.7 GHz. In theory the −3 dB width is exactly $R_s$ = 32 GHz for **any** roll-off, because the PSD of an RRC-shaped signal is the raised-cosine spectrum, which is exactly half its peak value at $\pm R_s/2$. The measured value comes out a little smaller because the periodogram's random fluctuations push the estimated peak up (so "−3 dB below the peak" is slightly too low a threshold); the effect is larger for β = 0.5 because its gentle slope converts a small threshold error into a larger width error. Averaging more blocks shrinks the discrepancy. The −20 dB width, in contrast, grows clearly with β toward $(1+\beta)R_s$. Lesson: the symbol rate sets the "core" width; the roll-off sets the extra "skirt", which is why modern systems use small β (about 0.01–0.2) to pack channels tightly.
</details>

### Problem 1.4 ★ — Circular convolution trap
Let `x = np.ones(8)` and `h = np.array([1, 1, 1])`. Compute `np.fft.ifft(np.fft.fft(x) * np.fft.fft(h, 8)).real` and `np.convolve(x, h)`. Explain the difference and fix the FFT method.

<details><summary>Solution</summary>

The FFT result is `[3,3,3,3,3,3,3,3]`; the linear convolution is `[1,2,3,3,3,3,3,3,2,1]`. With an 8-point FFT, the two output samples that should extend beyond index 7 wrap around and add to indices 0 and 1 (1+2=3 and 2+1=3). Fix: zero-pad to at least 8+3−1 = 10 points: `np.fft.ifft(np.fft.fft(x,10)*np.fft.fft(h,10)).real`.
</details>

### Problem 1.5 ★★ — Frequency-offset estimation resolution (conceptual + numerical)
You want to estimate a 1.234 GHz tone from 4096 samples at 32 GSa/s by locating the FFT peak. (a) What is the worst-case error without zero-padding? (b) With 4× zero-padding? (c) Verify numerically with added noise.

<details><summary>Solution</summary>

(a) Bin spacing = 32e9/4096 = 7.81 MHz, so worst-case error is half a bin ≈ 3.9 MHz.
(b) 1.95 MHz spacing → about 1 MHz worst case.
(c)
```python
import numpy as np
fs, N, f0 = 32e9, 4096, 1.234e9
n = np.arange(N); x = np.exp(2j*np.pi*f0*n/fs) + 0.5*(np.random.randn(N)+1j*np.random.randn(N))
for pad in [1, 4, 16]:
    X = np.abs(np.fft.fft(x, pad*N)); f = np.fft.fftfreq(pad*N, 1/fs)
    print(pad, "x pad: error = %.2f MHz" % ((f[np.argmax(X)]-f0)/1e6))
```
The error shrinks with zero-padding until it reaches the noise-limited accuracy set by the record length and SNR. In Chapter 6 you will see that for laser frequency offsets of up to a few GHz, a residual error of a few MHz is easily absorbed by the carrier-phase recovery.
</details>

### Problem 1.6 ★★★ — Design: an ADC and FFT plan for a spectrum monitor
A line card must monitor a 96 GBd DP-16QAM signal (roll-off 0.1) and report (i) the carrier frequency offset to within ±5 MHz and (ii) the signal's −20 dB bandwidth. Choose the minimum complex sample rate, the FFT length and a window, and justify each choice. Assume you may average several FFT blocks.

<details><summary>Solution</summary>

*Sample rate.* The signal occupies $(1+\beta)R_s = 105.6$ GHz, plus a few GHz of frequency offset (say ±3 GHz): total ≈ 112 GHz. Complex sampling needs $f_s > W$, so ≈ 115–120 GSa/s is enough; a common choice is ~1.25 sps = 120 GSa/s, leaving margin for the anti-aliasing filter's transition band.

*FFT length.* The bin spacing must be well below the ±5 MHz requirement; with peak interpolation (or zero-padding) a bin of ~10 MHz can be interpolated to ±1–2 MHz at good SNR. Bin spacing $f_s/N \le 10$ MHz → $N \ge 12{,}000$ → choose $N = 16{,}384$ (7.3 MHz bins). The record length is then 137 ns, so the resolution (~7 MHz) is also adequate.

*Window.* For the −20 dB bandwidth, leakage from the flat top into the skirts matters little (20 dB is modest), but for the offset estimate the spectrum's centre of gravity or its symmetric edges are used, where leakage biases the edges. A Hann window (sidelobes −31 dB, fast decay) is a good compromise; Blackman if you also need deeper dynamic range.

*Averaging.* A single periodogram fluctuates strongly (Problem 1.3); averaging ~50–100 blocks (Welch) makes the −20 dB points stable to a fraction of a GHz. This is still only ~1–2 µs of data — negligible latency.
</details>

---

## Key takeaways

- The **complex envelope** removes the 193 THz carrier; its magnitude is the field amplitude, its angle the optical phase. Coherent receivers measure it; direct detection measures only $|x|^2$.
- A complex signal of total width $W$ needs $f_s > W$ complex samples per second; its spectrum can be asymmetric.
- **Bin spacing** = $f_s/N$; **resolution** ≈ 1/(record length); zero-padding smooths plots but adds no resolution; **windows** trade main-lobe width for low leakage.
- FFT-based filtering is **circular**; streaming signals need overlap-save/add.
- dB add for ratios; powers in dBm must be converted to linear before adding.

---

**Next:** Chapter 2 builds the filters — FIR, fast convolution and multirate processing — that every block of the transceiver uses.
