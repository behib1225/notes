"""
Chapter 7: IM/DD PAM4 link with a properly defined electrical SNR and four receivers:
no equalizer, FFE, FFE+DFE, and FFE + 2-state-memory MLSE (Viterbi); plus a simplified
TDECQ-like transmitter penalty.

Electrical SNR definition used throughout (see Chapter 7.3):
    SNR_el = variance of the DATA (AC) part of the decision samples, noise-free,
             / variance of the noise at the decision samples.
For ISI-free PAM4 with equally spaced levels this gives SER = 1.5 Q( sqrt(SNR_el / 5) ).
Run:  python ch7_imdd.py
"""
import numpy as np
from scipy.signal import butter, lfilter
import optdsp as od

LV = od.pam_levels(4)                       # -3, -1, 1, 3

def ser_theory(snr_db):
    return 1.5 * od.qfunc(np.sqrt(10 ** (snr_db / 10) / 5))

def imdd_channel(n_sym=60000, Rs=56e9, sps=4, L_km=0.0, D=17.0, lam=1550e-9,
                 bw=None, er_db=6.0, seed=0):
    """Return (noise-free received samples at sps, transmitted symbol indices, RRC taps)."""
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, 4, n_sym)
    a = LV[idx]
    er = 10 ** (er_db / 10)                                   # extinction ratio P3/P0
    p = 1 + (a / 3) * (er - 1) / (er + 1)                     # power levels, mean 1
    h = od.rrc_taps(0.2, sps, 32)
    P = od.filter_same(od.upsample(p - 1, sps), h * np.sqrt(sps)).real + 1   # band-limited power
    E = np.sqrt(np.clip(P, 1e-6, None))                       # chirp-free modulator field
    if L_km > 0:
        E = od.cd_channel(E, sps * Rs, L_km * 1e3, D, lam)
    I = np.abs(E) ** 2                                        # square-law photodiode
    if bw is not None:                                        # component bandwidth (4th-order Butterworth)
        b, aa = butter(4, bw * Rs / (sps * Rs / 2))
        I = lfilter(b, aa, I)
    return I, idx, h

def receive(I, idx, h, snr_db, sps=4, seed=1):
    """
    Add thermal noise so that SNR_el at the decision point equals snr_db (for the
    noise-free signal passed through the same matched filter), then matched-filter,
    pick the best sampling phase and integer delay, and normalise so that the
    ideal levels are -3, -1, 1, 3.
    """
    rng = np.random.default_rng(seed)
    clean = od.filter_same(I, h).real
    best = None
    for ph in range(sps):                                     # best sampling phase and delay
        r = clean[ph::sps][:len(idx)]
        for d in range(-3, 4):
            c = np.corrcoef(np.roll(r, -d)[100:-100], LV[idx][100:-100])[0, 1]
            if best is None or c > best[0]:
                best = (c, ph, d)
    _, ph, d = best
    r_clean = np.roll(clean[ph::sps][:len(idx)], -d)
    g = np.polyfit(LV[idx][100:-100], r_clean[100:-100], 1)   # gain and offset
    var_ac = np.var(r_clean - g[1])
    sigma2 = var_ac / 10 ** (snr_db / 10)                     # noise variance at decision point
    noise = od.filter_same(np.sqrt(sigma2) * rng.standard_normal(len(I)), h).real  # unit-energy MF keeps variance
    r = np.roll((clean + noise)[ph::sps][:len(idx)], -d)
    return (r - g[1]) / g[0]                                  # levels at -3,-1,1,3 (plus ISI/noise)

def decide(y):
    return np.argmin(np.abs(y[:, None] - LV[None, :]), axis=1)

def ffe(r, ref_idx, n_taps=21, mu=1e-4, n_train=10000, target=(1.0,)):
    """LMS FFE; trained on known symbols, then decision-directed. `target` shapes the
    response (e.g. (1, alpha) for a partial-response target used before MLSE)."""
    w = np.zeros(n_taps); w[n_taps // 2] = 1
    c = n_taps // 2; y = np.zeros(len(r)); tg = np.array(target)
    for k in range(n_taps, len(r)):
        win = r[k - n_taps + 1:k + 1][::-1]
        y[k] = w @ win
        j = k - c                                             # symbol aligned with centre tap
        if k < n_train:
            want = tg @ LV[ref_idx[j - np.arange(len(tg))]]
        else:
            want = y[k] if len(tg) > 1 else LV[decide(np.array([y[k]]))[0]]
            if len(tg) > 1:
                continue                                      # PR mode: freeze after training
        w += mu * (want - y[k]) * win
    return np.roll(y, -c), w

def dfe(r, ref_idx, n_ff=21, n_fb=3, mu=1e-4, n_train=10000):
    """FFE + decision feedback (post-cursor cancellation using past decisions)."""
    w = np.zeros(n_ff); w[n_ff // 2] = 1; b = np.zeros(n_fb)
    c = n_ff // 2; y = np.zeros(len(r)); dec = np.zeros(len(r))
    for k in range(n_ff, len(r)):
        j = k - c
        win = r[k - n_ff + 1:k + 1][::-1]
        past = dec[j - 1 - np.arange(n_fb)]
        y[j] = w @ win - b @ past
        d_hat = LV[ref_idx[j]] if k < n_train else LV[decide(np.array([y[j]]))[0]]
        dec[j] = d_hat
        e = d_hat - y[j]
        w += mu * e * win; b -= mu * e * past
    return y

def mlse_1tap(y, alpha):
    """Viterbi detection for the channel y_k = a_k + alpha * a_{k-1} + noise (4 states)."""
    n = len(y); cost = np.zeros(4); back = np.zeros((n, 4), int)
    for k in range(n):
        # metric[prev, cur]
        m = cost[:, None] + (y[k] - (LV[None, :] + alpha * LV[:, None])) ** 2
        back[k] = np.argmin(m, axis=0); cost = np.min(m, axis=0)
    s = np.zeros(n, int); s[-1] = np.argmin(cost)
    for k in range(n - 1, 0, -1):
        s[k - 1] = back[k, s[k]]
    return s

def run_case(label, snr_db=17.0, **ch):
    I, idx, h = imdd_channel(**ch)
    r = receive(I, idx, h, snr_db)
    sl = slice(20000, len(idx) - 200)
    s_none = np.mean(decide(r)[sl] != idx[sl])
    y_ffe, _ = ffe(r, idx)
    s_ffe = np.mean(decide(y_ffe)[sl] != idx[sl])
    y_dfe = dfe(r, idx)
    s_dfe = np.mean(decide(y_dfe)[sl] != idx[sl])
    # choose the partial-response target alpha on a TRAINING segment (known symbols),
    # then report the SER on the separate test segment `sl`
    best = None
    for alpha in [0.0, 0.2, 0.4, 0.6, 0.8]:
        y_pr, _ = ffe(r, idx, target=(1.0, alpha))
        dec = mlse_1tap(y_pr, alpha)
        s_train = np.mean(dec[12000:20000] != idx[12000:20000])
        if best is None or s_train < best[0]:
            best = (s_train, alpha, np.mean(dec[sl] != idx[sl]))
    s_mlse = best[2]
    print(f"{label:22s} none {s_none:8.2e}  FFE {s_ffe:8.2e}  DFE {s_dfe:8.2e}  "
          f"FFE+MLSE {s_mlse:8.2e} (alpha={best[1]:.1f})")
    return s_none, s_ffe, s_dfe, s_mlse

def tdecq_like(I, idx, h, sps=4, n_taps=5, ser_target=4.8e-4):
    """
    Simplified TDECQ-like penalty (the IEEE definition has more details: reference
    receiver bandwidth, two sampling instants, histogram method). Here:
      1. equalize the NOISE-FREE received signal with an MMSE-optimal T-spaced
         reference FFE of n_taps taps;
      2. find the largest Gaussian noise std sigma_tol, referred to the equalizer INPUT
         (so the FFE's noise enhancement sum(w^2) counts), at which the analytic SER of
         the equalized samples equals ser_target;
      3. penalty = 10*log10(sigma_ideal / sigma_tol), where sigma_ideal is the same
         quantity for an ideal ISI-free signal with the same outer levels.
    """
    r = receive(I, idx, h, snr_db=200.0)
    sl = slice(200, len(idx) - 200)
    X = np.array([np.roll(r, k - n_taps // 2) for k in range(n_taps)]).T[sl]
    w = np.linalg.lstsq(X, LV[idx[sl]], rcond=None)[0]
    y = X @ w; a = idx[sl]
    gain = np.sqrt(np.sum(w ** 2))
    def ser(sig):                                             # analytic SER for noise std sig at the input
        s_eff = sig * gain; th = np.array([-2.0, 0.0, 2.0])
        up = np.where(a < 3, od.qfunc((th[np.minimum(a, 2)] - y) / s_eff), 0)
        dn = np.where(a > 0, od.qfunc((y - th[np.maximum(a - 1, 0)]) / s_eff), 0)
        return np.mean(up + dn)
    if ser(1e-6) > ser_target:                                # ISI alone exceeds the target:
        return np.inf, w                                      # eye closed after the reference FFE
    lo, hi = 1e-6, 5.0
    for _ in range(60):                                       # bisection on sigma
        mid = np.sqrt(lo * hi)
        lo, hi = (mid, hi) if ser(mid) < ser_target else (lo, mid)
    sigma_tol = lo
    sigma_ideal = 1.0 / 3.414                                 # 1.5*Q(1/sigma)=4.8e-4 -> 1/sigma = 3.414
    return 10 * np.log10(sigma_ideal / sigma_tol), w

if __name__ == "__main__":
    print("Back-to-back check of the SNR definition (no ISI):")
    for snr in [14, 16, 18]:
        I, idx, h = imdd_channel()
        r = receive(I, idx, h, snr)
        print(f"   SNR_el {snr} dB: SER sim {np.mean(decide(r)[200:-200] != idx[200:-200]):.2e}, "
              f"theory {ser_theory(snr):.2e}")
    print("\n56 GBd PAM4, SNR_el = 17 dB (theory without ISI: %.1e)" % ser_theory(17))
    run_case("back-to-back")
    run_case("bandwidth 0.5 Rs", bw=0.5)
    run_case("bandwidth 0.4 Rs", bw=0.4)
    run_case("bandwidth 0.35 Rs", bw=0.35)
    run_case("C-band 2 km", L_km=2)
    run_case("C-band 5 km", L_km=5)
    run_case("O-band 10 km (D=-2)", L_km=10, D=-2.0, lam=1310e-9)
    fnull = np.sqrt(od.C_LIGHT / (2 * 17e-6 * 10e3 * (1550e-9) ** 2))
    print(f"\nfirst CD power-fading null, 10 km SSMF at 1550 nm: {fnull/1e9:.1f} GHz")
    print("\nSimplified TDECQ-like penalty (5-tap reference FFE, SER target 4.8e-4):")
    for lab, kw in [("ideal transmitter", {}), ("bandwidth 0.5 Rs", dict(bw=0.5)),
                    ("bandwidth 0.4 Rs", dict(bw=0.4)), ("bandwidth 0.35 Rs", dict(bw=0.35)),
                    ("C-band 2 km", dict(L_km=2))]:
        pen, w = tdecq_like(*imdd_channel(**kw))
        txt = "eye closed (fails)" if np.isinf(pen) else f"{pen:5.2f} dB"
        print(f"   {lab:20s}: {txt}   (FFE taps {np.round(w, 2)})")
