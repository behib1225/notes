"""
Chapter 8 solutions: GMI vs SNR, probabilistic constellation shaping (PCS) with a
Maxwell-Boltzmann distribution, hard- vs soft-decision decoding of a Hamming(7,4) code,
and digital back-propagation (DBP). Run: python ch8_fec_shaping.py   (~2 min)
"""
import numpy as np
import optdsp as od
rng = np.random.default_rng(11)

# ------------------------------------------------------------------
# 1. GMI of uniform QAM vs Shannon capacity
# ------------------------------------------------------------------
print("SNR(dB)  Shannon  GMI-QPSK  GMI-16QAM  GMI-64QAM   (bits / 2D symbol)")
for snr in [0, 5, 10, 15, 20, 25]:
    row = [np.log2(1 + 10**(snr/10))]
    for M in [4, 16, 64]:
        k = int(np.log2(M)); b = rng.integers(0, 2, (40000, k))
        s = od.bits_to_symbols(b.ravel(), M)
        row.append(od.gmi_awgn(od.add_awgn(s, snr, rng=rng), b, M, snr_db=snr))
    print(f"{snr:5d}   " + "   ".join(f"{v:6.3f}" for v in row))

# ------------------------------------------------------------------
# 2. Probabilistic shaping: Maxwell-Boltzmann 64-QAM
# ------------------------------------------------------------------
def mb_distribution(const, lam):
    p = np.exp(-lam * np.abs(const)**2); return p / p.sum()

def entropy(p):
    p = p[p > 0]; return -np.sum(p * np.log2(p))

def mi_shaped(const, p, snr_db, n=60000):
    """Symbol-wise mutual information I(X;Y) (bits/2D) for a constellation with
    probabilities p, normalised to unit energy, in AWGN at the given Es/N0."""
    const = const / np.sqrt(np.sum(p * np.abs(const)**2))
    idx = rng.choice(len(const), size=n, p=p)
    N0 = 10**(-snr_db / 10)
    y = const[idx] + np.sqrt(N0/2) * (rng.standard_normal(n) + 1j*rng.standard_normal(n))
    logq = -np.abs(y[:, None] - const[None, :])**2 / N0 + np.log(p)[None, :]   # log p(y|x)p(x) + c
    log_post = logq[np.arange(n), idx] - np.logaddexp.reduce(logq, axis=1)
    return entropy(p) + np.mean(log_post) / np.log(2)

const64, _ = od.qam_constellation(64)
print("\nPCS-64QAM: choose lambda so that MI is maximised at each SNR")
print("SNR(dB)  Shannon  uniform-64QAM MI   best MB-64QAM MI (entropy)")
for snr in [10, 14, 18]:
    uni = mi_shaped(const64, np.ones(64)/64, snr)
    best = max(((mi_shaped(const64, mb_distribution(const64, l), snr), entropy(mb_distribution(const64, l)))
                for l in np.linspace(0, 4, 17)), key=lambda t: t[0])
    print(f"{snr:5d}   {np.log2(1+10**(snr/10)):6.3f}     {uni:6.3f}            {best[0]:6.3f} ({best[1]:.2f} bits)")

# ------------------------------------------------------------------
# 3. Hamming(7,4): hard vs soft (ML) decoding with BPSK in AWGN
# ------------------------------------------------------------------
G = np.array([[1,0,0,0,1,1,0],[0,1,0,0,1,0,1],[0,0,1,0,0,1,1],[0,0,0,1,1,1,1]])
H = np.array([[1,1,0,1,1,0,0],[1,0,1,1,0,1,0],[0,1,1,1,0,0,1]])
msgs = ((np.arange(16)[:, None] >> np.arange(3, -1, -1)) & 1)
codebook = msgs @ G % 2
syn_table = {tuple(H[:, i]): i for i in range(7)}
print("\nHamming(7,4), BPSK, Eb/N0 counted per INFORMATION bit")
print("Eb/N0(dB)  uncoded BER   hard-decision   soft-decision (ML)")
for ebn0 in [4, 6, 8]:
    n_blk = 100000
    m = rng.integers(0, 16, n_blk); c = codebook[m]
    esn0 = 10**(ebn0/10) * 4/7                                   # energy per coded bit
    x = 1 - 2*c
    y = x + np.sqrt(1/(2*esn0)) * rng.standard_normal(x.shape)
    hard = (y < 0).astype(int)
    syn = hard @ H.T % 2
    for i in range(n_blk):
        t = tuple(syn[i])
        if any(t): hard[i, syn_table[t]] ^= 1
    ber_hard = np.mean(hard[:, :4] != msgs[m])
    corr = y @ (1 - 2*codebook).T                                # ML = max correlation
    ber_soft = np.mean(msgs[np.argmax(corr, axis=1)] != msgs[m])
    ub = np.mean((rng.standard_normal(400000) * np.sqrt(1/(2*10**(ebn0/10)))) < -1)
    print(f"{ebn0:6d}      {ub:.2e}      {ber_hard:.2e}        {ber_soft:.2e}")

# ------------------------------------------------------------------
# 4. Digital back-propagation (single channel, 10 x 80 km, 32 GBd QPSK)
# ------------------------------------------------------------------
h_planck, nu = 6.62607015e-34, 193.4e12
def link(P_dbm, dbp_steps=None, n_spans=10, L_span=80e3, alpha=0.2, NF_db=5.0, Rs=32e9, sps=4,
         n_sym=2**12, steps=80, seed=0, gamma=1.3e-3):
    r = np.random.default_rng(seed); fs = sps*Rs
    s = od.bits_to_symbols(r.integers(0, 2, 2*n_sym), 4); h = od.rrc_taps(0.1, sps, 64)
    x = od.filter_same(od.upsample(s, sps), h)
    x = x / np.sqrt(np.mean(abs(x)**2)) * np.sqrt(1e-3 * 10**(P_dbm/10))
    G = 10**(alpha*L_span/1e3/10); S = 10**(NF_db/10)/2*h_planck*nu*(G-1)
    for _ in range(n_spans):
        x = od.ssfm(x, fs, L_span, steps, alpha_db_km=alpha, gamma=gamma) * np.sqrt(G)
        x = x + np.sqrt(S*fs/2) * (r.standard_normal(len(x)) + 1j*r.standard_normal(len(x)))
    if dbp_steps is None:
        x = od.cd_channel(x, fs, n_spans*L_span, compensate=True)
    else:                                   # back-propagate: reverse each span with negated parameters
        for _ in range(n_spans):
            x = x / np.sqrt(G)
            x = od.ssfm(x, fs, L_span, dbp_steps, alpha_db_km=-alpha, D_ps_nm_km=-17.0, gamma=-gamma)
    y = od.filter_same(x, h)[::sps]; y = y * np.exp(-1j*np.angle(np.vdot(s, y)))
    return od.snr_estimate_db(y[100:-100], s[100:-100])

print("\nDigital back-propagation, single channel, 10 x 80 km")
print("P(dBm)  CD comp. only   DBP 1 step/span   DBP 10 steps/span")
for P in [-2, 0, 2, 4, 6]:
    print(f"{P:5d}     {link(P):6.2f}          {link(P, 1):6.2f}           {link(P, 10):6.2f}")
