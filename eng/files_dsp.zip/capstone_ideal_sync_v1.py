"""
Capstone: end-to-end dual-polarization coherent link with a full receiver DSP chain.

TX : bits -> Gray M-QAM (X and Y pol) -> RRC pulse shaping
CH : chromatic dispersion -> random polarization rotation -> ASE noise (set by OSNR)
     -> frequency offset + laser phase noise (TX laser and LO combined)
RX : ADC at 2 samples/symbol -> CD compensation -> 2x2 CMA butterfly (pol demux,
     residual ISI, down to 1 sample/symbol) -> 4th-power frequency-offset estimation
     -> carrier phase recovery (Viterbi-Viterbi for QPSK, blind phase search for 16QAM)
     -> resolve 90-degree ambiguity with a short known header -> BER / SNR / GMI

Run:  python capstone_coherent_link.py
"""
import numpy as np
import optdsp as od

def run_link(M=4, Rs=32e9, L_km=800, osnr_db=16.0, df_hz=1.2e9, linewidth_hz=100e3,
             n_sym=2**15, beta=0.1, seed=7, verbose=True):
    rng = np.random.default_rng(seed)
    k = int(np.log2(M))
    sps_tx, sps_rx = 4, 2
    fs_tx = sps_tx * Rs

    # ---------------- Transmitter ----------------
    bits = rng.integers(0, 2, (2, n_sym * k))
    sym = np.vstack([od.bits_to_symbols(bits[p], M) for p in range(2)])
    h = od.rrc_taps(beta, sps_tx, 64)
    tx = np.vstack([od.filter_same(od.upsample(sym[p], sps_tx), h) for p in range(2)])

    # ---------------- Channel ----------------
    ch = od.cd_channel(tx, fs_tx, L_km * 1e3)
    J = od.random_unitary_2x2(rng)
    ch = J @ ch
    # OSNR -> SNR (dual pol, ASE noise in both pols, Bref = 12.5 GHz)
    snr_db = osnr_db + 10 * np.log10(12.5e9 / Rs)
    ch = np.vstack([od.add_awgn(ch[p], snr_db, sps=sps_tx, rng=rng) for p in range(2)])
    n = np.arange(ch.shape[1])
    phase = 2 * np.pi * df_hz * n / fs_tx + od.laser_phase_noise(ch.shape[1], 2 * linewidth_hz, fs_tx, rng)
    ch = ch * np.exp(1j * phase)

    # ---------------- Receiver ----------------
    # Anti-alias (RRC matched filter doubles as front-end filter) then ADC at 2 sps
    rx = np.vstack([od.filter_same(ch[p], h) for p in range(2)])[:, ::sps_tx // sps_rx]
    rx = od.cd_channel(rx, sps_rx * Rs, L_km * 1e3, compensate=True)
    rx = rx / np.sqrt(np.mean(np.abs(rx) ** 2))
    R2 = np.mean(np.abs(sym[0]) ** 4) / np.mean(np.abs(sym[0]) ** 2)   # CMA radius
    y, taps = od.cma_butterfly(rx, n_taps=15, mu=1e-3, sps=2, R2=R2, n_iter=1)

    discard = 5000                               # let equaliser converge
    y = y[:, discard:]
    out = {}
    for p in range(2):
        df_est = od.foe_4th_power(y[p], Rs)
        z = y[p] * np.exp(-1j * 2 * np.pi * df_est * np.arange(len(y[p])) / Rs)
        z = z / np.sqrt(np.mean(np.abs(z) ** 2))
        if M == 4:
            z, _ = od.viterbi_viterbi(z, block=32)
        else:
            z, _ = od.blind_phase_search(z, M, n_test=32, block=32)
        # The equaliser may output X on either port and with an unknown delay:
        best = None
        for q in range(2):
            ref = od.align(z, sym[q])
            zz = od.resolve_ambiguity(z, ref)
            s_est = od.snr_estimate_db(zz[200:-200], ref[200:-200])
            if best is None or s_est > best[0]:
                best = (s_est, q, zz, ref)
        s_est, q, zz, ref = best
        ber = od.ber_count(zz[200:-200], ref[200:-200], M)
        out[p] = dict(df_est=df_est, snr_db=s_est, ber=ber, maps_to=q)
        if verbose:
            print(f"port {p} (carries TX pol {'XY'[q]}): FO est = {df_est/1e9:+.3f} GHz, "
                  f"SNR = {s_est:5.2f} dB, BER = {ber:.2e}")
    if verbose:
        print(f"Channel SNR set by OSNR: {snr_db:.2f} dB; theory BER at that SNR: "
              f"{od.ber_qam_theory(M, snr_db):.2e}")
    return out

if __name__ == "__main__":
    print("=== DP-QPSK, 32 GBd, 800 km, OSNR 13 dB ===")
    run_link(M=4, osnr_db=13.0)
    print("\n=== DP-16QAM, 32 GBd, 800 km, OSNR 20 dB ===")
    run_link(M=16, osnr_db=20.0)
