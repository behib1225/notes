"""Self-checks for optdsp.py. Run:  python test_optdsp.py"""
import numpy as np
import optdsp as od
rng = np.random.default_rng(1)

# 1) BER of QPSK/16QAM in AWGN vs theory (1 sample/symbol)
for M, snr in [(4, 8.0), (16, 15.0), (64, 21.0)]:
    k = int(np.log2(M)); N = 200_000
    b = rng.integers(0, 2, N * k)
    s = od.bits_to_symbols(b, M)
    r = od.add_awgn(s, snr, rng=rng)
    print(f"{M}-QAM Es/N0={snr} dB  BER sim={od.ber_count(r, s, M):.2e}  theory={od.ber_qam_theory(M, snr):.2e}"
          f"  SNR est={od.snr_estimate_db(r, s):.2f} dB  GMI={od.gmi_awgn(r, b.reshape(-1,k), M):.3f}")

# 2) RRC pulse shaping + matched filter gives zero ISI
sps, beta = 4, 0.1
h = od.rrc_taps(beta, sps, 64)
s = od.bits_to_symbols(rng.integers(0, 2, 2 * 5000), 4)
x = od.filter_same(od.upsample(s, sps), h)
y = od.filter_same(x, h)[::sps]
print("RRC+MF residual ISI SNR:", round(od.snr_estimate_db(y[100:-100], s[100:-100]), 1), "dB")

# 3) CD: 1000 km, 32 GBd, then compensate
fs = 64e9
xc = od.cd_channel(x, fs * 2, 1000e3)  # x is at 4 sps of 32 GBd -> fs=128 GHz
yc = od.cd_channel(xc, fs * 2, 1000e3, compensate=True)
print("CD uncompensated SNR:", round(od.snr_estimate_db(od.filter_same(xc, h)[::sps][100:-100], s[100:-100]), 1),
      "dB; compensated:", round(od.snr_estimate_db(od.filter_same(yc, h)[::sps][100:-100], s[100:-100]), 1), "dB")

# 4) Split-step: with D = 0 the nonlinear phase must equal gamma * P * L_eff
P = 10e-3; x0 = np.sqrt(P) * np.ones(1024, complex)
y0 = od.ssfm(x0, 64e9, 80e3, 100, D_ps_nm_km=0.0)
a = 0.2 / 4.343 / 1e3; Leff = (1 - np.exp(-a * 80e3)) / a
print(f"SSFM SPM phase: sim {-np.angle(y0[0]):.4f} rad, theory {1.3e-3 * P * Leff:.4f} rad")

# 5) Laser phase noise increment variance = 2*pi*linewidth/fs
ph = od.laser_phase_noise(200000, 100e3, 32e9, rng)
print(f"Phase-noise increment variance: sim {np.var(np.diff(ph)):.3e}, theory {2*np.pi*100e3/32e9:.3e}")

# 6) Quantiser: a full-scale uniform signal gives SQNR = 6.02*bits dB
u = rng.uniform(-1, 1, 200000)
for b in [4, 6, 8]:
    qd = od.quantize(u, b, clip_ratio=np.sqrt(3))            # full scale = max of the uniform signal
    print(f"Quantiser {b} bits: SQNR {10*np.log10(np.mean(u**2)/np.mean((qd-u)**2)):.2f} dB (theory {6.02*b:.2f})")

# 7) Closed-loop timing recovery: 50 ppm clock offset, random sampling phase
s2 = np.vstack([od.bits_to_symbols(rng.integers(0, 2, 2 * 20000), 4) for _ in range(2)])
hh = od.rrc_taps(0.1, 4, 64)
x2 = np.vstack([od.filter_same(od.upsample(s2[p], 4), hh) for p in range(2)])
r2 = np.vstack([od.adc_sample(x2[p], 4, 2, 50, 0.7) for p in range(2)])
r2 = np.vstack([od.filter_same(od.add_awgn(r2[p], 20, sps=2, rng=rng), od.rrc_taps(0.1, 2, 64)) for p in range(2)])
r2 /= np.sqrt(np.mean(np.abs(r2) ** 2))
y2, tr = od.gardner_timing_recovery(r2)
ref = od.align(y2[0, 0::2], s2[0])
print(f"Timing recovery (50 ppm): clock estimate {np.mean(tr[-5000:])*1e6:.1f} ppm, "
      f"SNR {od.snr_estimate_db(y2[0, 0::2][12000:-500], ref[12000:-500]):.2f} dB (channel 20 dB)")

# 8) Framing + pilot-aided CPR: no 90-degree ambiguity without using the data
d16 = od.bits_to_symbols(rng.integers(0, 2, 4 * 20000), 16)
fr, inf = od.build_frames(d16)
yy = od.add_awgn(fr, 18, rng=rng) * np.exp(1j * (np.pi / 2 + od.laser_phase_noise(len(fr), 1e6, 32e9, rng)))
d, pk = od.frame_sync(yy, inf)
z, _, _ = od.pilot_aided_cpr(yy, inf["ref_pos"], inf["ref_val"], 16)
print(f"Frame sync: delay {d}, peak {pk:.2f};  pilot-aided CPR with an extra 90-degree rotation: "
      f"SNR {od.snr_estimate_db(z[inf['data_pos']], fr[inf['data_pos']]):.2f} dB (channel 18 dB)")
