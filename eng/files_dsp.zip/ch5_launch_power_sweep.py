"""
Chapter 5 assignment solution: SNR versus launch power over a multi-span link.
Single channel, single polarization, 32 GBd QPSK, N spans of SSMF with EDFAs.
Shows the linear (ASE-limited) regime, the nonlinear regime and the optimum.
Run: python ch5_launch_power_sweep.py      (takes ~1 minute)
"""
import numpy as np
import optdsp as od

h_planck, nu = 6.62607015e-34, 193.4e12

def link_snr(P_dbm, n_spans=10, L_span=80e3, alpha=0.2, NF_db=5.0, Rs=32e9, sps=4,
             n_sym=2**12, steps=80, seed=0, gamma=1.3e-3):
    rng = np.random.default_rng(seed)
    fs = sps * Rs
    s = od.bits_to_symbols(rng.integers(0, 2, 2 * n_sym), 4)
    h = od.rrc_taps(0.1, sps, 64)
    x = od.filter_same(od.upsample(s, sps), h)
    x = x / np.sqrt(np.mean(np.abs(x)**2)) * np.sqrt(1e-3 * 10**(P_dbm / 10))   # field in sqrt(W)
    G = 10**(alpha * L_span / 1e3 / 10)
    nsp = 10**(NF_db / 10) / 2
    S_ase = nsp * h_planck * nu * (G - 1)          # W/Hz, in the signal's polarization
    for _ in range(n_spans):
        x = od.ssfm(x, fs, L_span, steps, alpha_db_km=alpha, gamma=gamma / 1e3 * 1e3)
        x = x * np.sqrt(G)
        sigma2 = S_ase * fs                         # complex noise variance per sample
        x = x + np.sqrt(sigma2 / 2) * (rng.standard_normal(len(x)) + 1j * rng.standard_normal(len(x)))
    x = od.cd_channel(x, fs, n_spans * L_span, compensate=True)
    y = od.filter_same(x, h)[::sps]
    # remove the average nonlinear phase rotation (a simple CPE)
    y = y * np.exp(-1j * np.angle(np.vdot(s, y)))
    return od.snr_estimate_db(y[100:-100], s[100:-100])

if __name__ == "__main__":
    print("P (dBm)  SNR (dB)   [10 x 80 km SSMF, 32 GBd, NF 5 dB]")
    for P in [-4, -2, 0, 2, 4, 6, 8, 10]:
        print(f"{P:6d}   {link_snr(P):6.2f}")
