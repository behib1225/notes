"""
Capstone: a realistic end-to-end dual-polarization coherent link.

TX : bits -> Gray M-QAM -> periodic frames (known header + 1 pilot per 32 symbols)
     -> RRC pulse shaping (4 samples/symbol)
CH : chromatic dispersion -> first-order PMD (DGD) -> time-varying polarization rotation
     -> polarization-dependent loss -> ASE noise (set by OSNR)
     -> frequency offset + laser phase noise (TX laser and LO)
RX : free-running ADC (2 samples/symbol, clock offset in ppm, random sampling phase)
     -> CD compensation (frequency domain) -> matched filter
     -> closed-loop Gardner timing recovery -> 2x2 CMA butterfly (-> 1 sample/symbol)
     -> 4th-power frequency-offset estimation -> frame synchronisation on the header
        (identifies which polarization each output carries, and the delay)
     -> pilot-aided carrier phase recovery (no 90-degree ambiguity, slips bounded)
     -> data extraction -> BER / SNR / GMI.
The transmitted data are used ONLY to measure performance, never to help the receiver.

Run:  python capstone_coherent_link.py
"""
import numpy as np
import optdsp as od

def run_link(M=4, Rs=32e9, L_km=800, osnr_db=16.0, df_hz=1.2e9, linewidth_hz=100e3,
             dgd_ps=10.0, sop_rate_rad_s=1e4, pdl_db=0.0, ppm=20.0, n_data=2**15,
             beta=0.1, mu_cma=1e-3, n_taps=15, seed=7, discard_sym=12000,
             frontend_lpf=True, cd_error_km=0.0, joint_timing=True, verbose=True):
    rng = np.random.default_rng(seed)
    k = int(np.log2(M)); sps_tx = 4; fs_tx = sps_tx * Rs

    # ---------------- Transmitter ----------------
    bits = rng.integers(0, 2, (2, n_data * k))
    data = [od.bits_to_symbols(bits[p], M) for p in range(2)]
    frames = [od.build_frames(data[p], pol=p) for p in range(2)]
    sym = np.vstack([f[0] for f in frames]); info = [f[1] for f in frames]
    h = od.rrc_taps(beta, sps_tx, 64)
    tx = np.vstack([od.filter_same(od.upsample(sym[p], sps_tx), h) for p in range(2)])

    # ---------------- Channel ----------------
    ch = od.cd_channel(tx, fs_tx, L_km * 1e3)
    if dgd_ps > 0:
        ch = od.pmd_first_order(ch, fs_tx, dgd_ps * 1e-12, rng)
    ch = od.sop_dynamic(ch, fs_tx, sop_rate_rad_s, rng)
    if pdl_db > 0:
        ch = od.pdl_element(ch, pdl_db, rng)
    snr_db = osnr_db + 10 * np.log10(12.5e9 / Rs)       # dual pol, Bref = 12.5 GHz
    P = np.mean(np.abs(ch) ** 2)                          # same noise in both pols
    N0 = P * sps_tx / 10 ** (snr_db / 10)
    ch = ch + np.sqrt(N0 / 2) * (rng.standard_normal(ch.shape) + 1j * rng.standard_normal(ch.shape))
    n = np.arange(ch.shape[1])
    ch = ch * np.exp(1j * (2 * np.pi * df_hz * n / fs_tx
                           + od.laser_phase_noise(len(n), 2 * linewidth_hz, fs_tx, rng)))

    # ---------------- Receiver ----------------
    # analog front end (photodiodes + TIAs + ADC input) is band-limited: model it as a
    # low-pass filter with cutoff 0.75*Rs. WITHOUT it, noise outside +-Rs aliases into
    # the band when sampling at 2 sps and costs ~3 dB (try frontend_lpf=False).
    if frontend_lpf:
        from scipy.signal import firwin
        g = firwin(129, 0.75 * Rs / (fs_tx / 2))
        ch = np.vstack([od.filter_same(ch[p], g) for p in range(2)])
    phase0 = rng.uniform(0, 2)
    rx = np.vstack([od.adc_sample(ch[p], sps_tx, 2, ppm, phase0) for p in range(2)])
    rx = od.cd_channel(rx, 2 * Rs, (L_km + cd_error_km) * 1e3, compensate=True)
    # coarse frequency-offset removal BEFORE the matched filter: otherwise a large offset
    # shifts the spectrum out of the (tight, beta = 0.1) matched filter and causes ISI
    df_coarse = od.foe_coarse_spectral(rx, 2 * Rs)
    rx = rx * np.exp(-2j * np.pi * df_coarse * np.arange(rx.shape[1]) / (2 * Rs))
    hm = od.rrc_taps(beta, 2, 64)
    rx = np.vstack([od.filter_same(rx[p], hm) for p in range(2)])
    rx = rx / np.sqrt(np.mean(np.abs(rx) ** 2))
    const, _ = od.qam_constellation(M)
    R2 = np.mean(np.abs(const) ** 4) / np.mean(np.abs(const) ** 2)
    if joint_timing:
        # timing recovery and equalizer in one loop: the equalizer's tap centroid steers
        # the clock, so the taps cannot walk off (Ch. 6.5)
        y, _ = od.timing_cma_joint(rx, n_taps=n_taps, mu=mu_cma, R2=R2)
    else:
        # separate loops (Gardner, then CMA with tap re-centering): simpler, but with PMD
        # the Gardner clock estimate can wander and the equalizer taps drift
        rx, _ = od.gardner_timing_recovery(rx)
        rx = rx / np.sqrt(np.mean(np.abs(rx) ** 2))
        y, _ = od.cma_butterfly(rx, n_taps=n_taps, mu=mu_cma, sps=2, R2=R2, recenter=True)

    results = []
    for port in range(2):
        yp = y[port]
        df_fine = od.foe_4th_power(yp[discard_sym:], Rs)       # residual after coarse removal
        yp = yp * np.exp(-2j * np.pi * df_fine * np.arange(len(yp)) / Rs)
        df_est = df_coarse + df_fine
        yp = yp / np.sqrt(np.mean(np.abs(yp[discard_sym:]) ** 2))
        # frame sync against BOTH polarizations' headers: the stronger one identifies the pol
        cands = [(od.frame_sync(yp, info[q], search_from=discard_sym), q) for q in range(2)]
        (d, peak), q = max(cands, key=lambda c: c[0][1])
        inf = info[q]
        # track the frame alignment frame by frame (absorbs equalizer re-centering jumps)
        dfr = od.frame_track(yp, inf, d)
        fidx = lambda pos: np.minimum(pos // inf["frame_len"], len(dfr) - 1)
        def rx_index(pos):
            dd = dfr[fidx(pos)]
            return np.where(np.isnan(dd), -1, pos + np.nan_to_num(dd)).astype(int)
        # all known symbols (headers + pilots) anchor the carrier phase
        pil = rx_index(inf["ref_pos"]); ok = (pil >= 0) & (pil < len(yp))
        pil, pv = pil[ok], inf["ref_val"][ok]
        _, u = np.unique(pil, return_index=True); pil, pv = pil[u], pv[u]
        z, _, _ = od.pilot_aided_cpr(yp, pil, pv, M, avg_pilots=5)
        dpos = rx_index(inf["data_pos"])
        keep = (dpos >= discard_sym) & (dpos < len(z) - 50)
        rxd = z[dpos[keep]]
        txd = sym[q][inf["data_pos"][keep]]
        # measurement only (data-aided): gain normalisation for SNR, and error counting
        a = np.vdot(txd, rxd) / np.vdot(txd, txd)
        rxd = rxd / a
        idx = inf["data_pos"][keep]                       # positions in the TX stream
        # map stream positions back to data-bit indices for GMI
        snr_meas = od.snr_estimate_db(rxd, txd)
        ber = od.ber_count(rxd, txd, M)
        results.append(dict(port=port, pol="XY"[q], df_est=df_est, sync_peak=peak, delay=d, eq_out=y[port],
                            snr_db=snr_meas, ber=ber, n_bits=len(rxd) * k, rx=rxd, tx=txd))
        if verbose:
            print(f"port {port}: carries TX pol {'XY'[q]} (header peak {peak:.2f}, delay {d:+d}), "
                  f"FO est {df_est/1e9:+.3f} GHz, SNR {snr_meas:5.2f} dB, BER {ber:.2e} "
                  f"({len(rxd)*k} bits)")
    if verbose:
        print(f"channel SNR from OSNR: {snr_db:.2f} dB -> theory BER {od.ber_qam_theory(M, snr_db):.2e}; "
              f"frame overhead {100*info[0]['overhead']:.1f}%")
    return results, snr_db

if __name__ == "__main__":
    print("=== DP-QPSK, 32 GBd, 800 km, OSNR 13 dB, 10 ps DGD, 10 krad/s SOP, 20 ppm clock ===")
    run_link(M=4, osnr_db=13.0)
    print("\n=== DP-16QAM, 32 GBd, 800 km, OSNR 20 dB, same impairments ===")
    run_link(M=16, osnr_db=20.0)
