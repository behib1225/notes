"""
Worked-solution code for the longer assignments (Chapters 2 and 6).
Run:  python solutions_extra.py
"""
import numpy as np
from scipy.signal import resample_poly
import optdsp as od

rng = np.random.default_rng(3)

# ---------------------------------------------------------------
# Ch.2  Overlap-save frequency-domain filtering of a long signal
# ---------------------------------------------------------------
def overlap_save(x, h, nfft):
    """Filter x with FIR h using FFT blocks of size nfft (nfft > len(h))."""
    L = len(h); step = nfft - (L - 1)
    H = np.fft.fft(h, nfft)
    xp = np.concatenate([np.zeros(L - 1, complex), x, np.zeros(nfft, complex)])
    out = []
    for start in range(0, len(x), step):
        blk = xp[start:start + nfft]
        yb = np.fft.ifft(np.fft.fft(blk) * H)
        out.append(yb[L - 1:])          # discard the first L-1 (circularly aliased) outputs
    return np.concatenate(out)[:len(x)]

x = rng.standard_normal(10_000) + 1j * rng.standard_normal(10_000)
h = rng.standard_normal(101) + 1j * rng.standard_normal(101)
err = np.max(np.abs(overlap_save(x, h, 512) - np.convolve(x, h)[:len(x)]))
print(f"[Ch2] overlap-save vs direct convolution, max error = {err:.1e}")

def cd_fir_taps(L_m, fs, D=17.0, lam=1550e-9):
    """
    Time-domain CD-compensating FIR (Savory, Opt. Express 2008):
        N = 2*floor(|D| lam^2 L / (2 c Ts^2)) + 1
        g[k] = sqrt(-j c Ts^2 / (D lam^2 L)) * exp(+j pi c Ts^2 k^2 / (D lam^2 L)),
        k = -(N-1)/2 ... (N-1)/2
    NOTE: this is the complex conjugate of the expression printed in Savory's paper,
    because this tutorial uses numpy's FFT sign convention with the channel
    H = exp(-j beta2 L w^2 / 2). Always verify signs numerically!
    """
    Dsi = D * 1e-6                       # ps/(nm km) -> s/m^2
    Ts = 1 / fs
    N = 2 * int(np.floor(abs(Dsi) * lam**2 * L_m / (2 * od.C_LIGHT * Ts**2))) + 1
    k = np.arange(-(N // 2), N // 2 + 1)
    g = np.sqrt(-1j * od.C_LIGHT * Ts**2 / (Dsi * lam**2 * L_m)) * \
        np.exp(+1j * np.pi * od.C_LIGHT * Ts**2 * k**2 / (Dsi * lam**2 * L_m))
    return N, g

# Check: the FIR undoes the channel's CD about as well as the ideal frequency-domain filter
sps_c, Rs_c, L_c = 2, 32e9, 200e3
hh = od.rrc_taps(0.1, sps_c, 64)
sc = od.bits_to_symbols(rng.integers(0, 2, 2 * 20000), 4)
xc = od.cd_channel(od.filter_same(od.upsample(sc, sps_c), hh), sps_c * Rs_c, L_c)
Nc, g = cd_fir_taps(L_c, sps_c * Rs_c)
yc = od.filter_same(od.filter_same(xc, g), hh)[::sps_c]
print(f"[Ch2] time-domain CD FIR ({Nc} taps, 200 km): SNR after compensation = "
      f"{od.snr_estimate_db(yc[500:-500], sc[500:-500]):.1f} dB")

for Lkm, Rs in [(100, 32e9), (1000, 32e9), (1000, 64e9)]:
    N, _ = cd_fir_taps(Lkm * 1e3, 2 * Rs)
    print(f"[Ch2] CD FIR taps for {Lkm} km at {Rs/1e9:.0f} GBd (2 sps): N = {N}")

# ---------------------------------------------------------------
# Ch.6  Gardner timing-error detector S-curve
# ---------------------------------------------------------------
sps, beta = 8, 0.3
hr = od.rrc_taps(beta, sps, 32)
s = od.bits_to_symbols(rng.integers(0, 2, 2 * 20000), 4)
y = od.filter_same(od.filter_same(od.upsample(s, sps), hr), hr)   # raised-cosine pulses
print("[Ch6] Gardner S-curve (timing offset in fraction of T -> mean error; positive tau = late):")
for off in [-3, -2, -1, 0, 1, 2, 3]:              # offset in samples of T/8
    # index 96 = 12*8 is a SYMBOL instant, so y2[0], y2[2], ... are symbol samples and
    # y2[1], y2[3], ... the mid-points. (Starting at a mid-point would silently swap the
    # roles and flip the sign of the S-curve -- a real bug caught while writing this.)
    y2 = y[96 + off::sps // 2][:30000]
    mid, prev, nxt = y2[1:-1:2], y2[0:-2:2], y2[2::2]
    e = np.real(mid * np.conj(prev - nxt))
    print(f"      tau = {off/8:+.3f} T  ->  e = {np.mean(e):+.4f}")

# ---------------------------------------------------------------
# Ch.6  IQ imbalance + Gram-Schmidt orthonormalisation (GSOP)
# ---------------------------------------------------------------
s16 = od.bits_to_symbols(rng.integers(0, 2, 4 * 20000), 16)
I, Q = s16.real, s16.imag
eps_amp, eps_ph = 0.2, np.deg2rad(8)             # 20% gain mismatch, 8 deg quadrature error
r = I + 1j * ((1 + eps_amp) * (Q * np.cos(eps_ph) + I * np.sin(eps_ph)))
r = od.add_awgn(r, 25, rng=rng)
def gsop(r):
    rI, rQ = r.real, r.imag
    I_o = rI / np.sqrt(np.mean(rI**2))
    Q_t = rQ - np.mean(rI * rQ) / np.mean(rI**2) * rI
    Q_o = Q_t / np.sqrt(np.mean(Q_t**2))
    return (I_o + 1j * Q_o) / np.sqrt(2) * np.sqrt(2 * np.mean(np.abs(s16)**2) / 2)
print(f"[Ch6] SNR with IQ imbalance: {od.snr_estimate_db(r, s16):.1f} dB, after GSOP: "
      f"{od.snr_estimate_db(gsop(r), s16):.1f} dB (channel 25 dB)")

# ---------------------------------------------------------------
# Ch.6  CMA pre-convergence followed by decision-directed LMS (16QAM)
# ---------------------------------------------------------------
def dd_lms_butterfly(x, h0, M, mu=1e-3, sps=2):
    """Continue from CMA taps h0; error = decision - output (needs phase-locked input)."""
    const, _ = od.qam_constellation(M)
    h = h0.copy(); n_taps = h.shape[2]
    n_out = (x.shape[1] - n_taps) // sps
    y = np.zeros((2, n_out), complex)
    for k in range(n_out):
        win = x[:, k*sps:k*sps + n_taps][:, ::-1]
        yk = np.sum(h * win[None], axis=(1, 2))
        d = const[np.argmin(np.abs(yk[:, None] - const[None, :]), axis=1)]
        e = d - yk
        h += mu * e[:, None, None] * np.conj(win)[None]
        y[:, k] = yk
    return y

# frequency/phase-locked 16QAM through a polarization rotation + small ISI + noise
M = 16; n = 40000
sym = np.vstack([od.bits_to_symbols(rng.integers(0, 2, 4*n), M) for _ in range(2)])
tx = np.vstack([od.filter_same(od.upsample(sym[p], 2), od.rrc_taps(0.1, 2, 32)) for p in range(2)])
J = od.random_unitary_2x2(rng)
isi = np.array([0.1, 1, 0.15])
rx = np.vstack([np.convolve(v, isi, 'same') for v in (J @ tx)])
rx = np.vstack([od.add_awgn(rx[p], 20, sps=2, rng=rng) for p in range(2)])
rx = np.vstack([od.filter_same(rx[p], od.rrc_taps(0.1, 2, 32)) for p in range(2)])
rx /= np.sqrt(np.mean(np.abs(rx)**2))
R2 = np.mean(np.abs(sym[0])**4) / np.mean(np.abs(sym[0])**2)
y_cma, h_cma = od.cma_butterfly(rx, 15, 1e-3, 2, R2)
# fix the (constant) phase rotation the unitary J left behind using a short header, then DD-LMS
def best_snr(yp):
    res = []
    for q in range(2):
        ref = od.align(yp, sym[q])
        a = np.vdot(ref, yp) / np.vdot(ref, ref)
        res.append(od.snr_estimate_db(yp[200:-200], ref[200:-200]))
    return max(res)
# rotate taps so that output phase matches (data-aided, header of 1000 symbols)
for p in range(2):
    for q in range(2):
        ref = od.align(y_cma[p], sym[q])
        a = np.vdot(ref[10000:11000], y_cma[p][10000:11000]) / np.vdot(ref[10000:11000], ref[10000:11000])
        if abs(a) > 0.5:
            h_cma[p] *= np.exp(-1j * np.angle(a)) / abs(a)
y_dd = dd_lms_butterfly(rx, h_cma, M, mu=5e-4)
print(f"[Ch6] 16QAM SNR after CMA only: {best_snr(y_cma[0][10000:]):.2f} dB, "
      f"after CMA->DD-LMS: {best_snr(y_dd[0][10000:]):.2f} dB (noise-limited SNR ~20 dB)")

# ---------------------------------------------------------------
# Ch.7  IM/DD PAM4: see ch7_imdd.py (properly defined electrical SNR, FFE, DFE, MLSE, TDECQ)
# ---------------------------------------------------------------
fnull = np.sqrt(od.C_LIGHT / (2 * 17e-6 * 10e3 * (1550e-9)**2))
print(f"[Ch7] first CD power-fading null for 10 km SSMF at 1550 nm: {fnull/1e9:.1f} GHz "
      "(full IM/DD simulations: run ch7_imdd.py)")
