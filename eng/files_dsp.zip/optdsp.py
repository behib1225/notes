"""
optdsp.py  --  A small, readable DSP library for the tutorial
"DSP for Optical Communications".

Everything here is written for CLARITY, not speed. Each function is
explained in the chapter where it is introduced. Conventions:

  * Complex baseband signals are 1-D numpy arrays (single polarization)
    or 2 x N arrays (dual polarization: row 0 = X, row 1 = Y).
  * Time-domain -> frequency-domain uses numpy's FFT convention:
        X[k] = sum_n x[n] exp(-j 2 pi k n / N).
  * Fiber chromatic dispersion (CD) is modelled as
        H_CD(w) = exp(-j * beta2 * L * w^2 / 2)
    and the compensator is its complex conjugate. (Sign conventions
    differ between textbooks; what matters is consistency.)
  * Power of a signal = mean(|x|^2). Constellations are normalised to
    unit average symbol energy (Es = 1).
"""
import numpy as np

C_LIGHT = 299_792_458.0  # m/s

# --------------------------------------------------------------------
# 1. Bits, symbols, Gray-coded QAM
# --------------------------------------------------------------------
def gray_code(n_bits):
    """Return the list of n_bits-bit Gray codes as integers."""
    return [i ^ (i >> 1) for i in range(2 ** n_bits)]

def pam_levels(M):
    """M-PAM levels  -(M-1), ..., -1, +1, ..., +(M-1)."""
    return np.arange(-(M - 1), M, 2, dtype=float)

def qam_constellation(M):
    """
    Square M-QAM (M = 4, 16, 64, 256...) with Gray labelling.
    Returns (const, bitmap):
        const[i]  : complex point with label i (unit average energy)
        bitmap[i] : array of log2(M) bits for label i (MSB first)
    The first half of the bits selects the I level, the second half Q.
    """
    k = int(np.log2(M)); kI = k // 2
    L = int(np.sqrt(M))
    levels = pam_levels(L)
    g = gray_code(kI)                 # g[pos] = label of level position pos
    const = np.zeros(M, complex)
    for lab_i in range(L):
        for lab_q in range(L):
            label = (lab_i << kI) | lab_q
            const[label] = levels[g.index(lab_i)] + 1j * levels[g.index(lab_q)]
    const /= np.sqrt(np.mean(np.abs(const) ** 2))
    bitmap = ((np.arange(M)[:, None] >> np.arange(k - 1, -1, -1)) & 1).astype(np.int8)
    return const, bitmap

def bits_to_symbols(bits, M):
    const, _ = qam_constellation(M)
    k = int(np.log2(M))
    bits = np.asarray(bits).reshape(-1, k)
    labels = bits.dot(1 << np.arange(k - 1, -1, -1))
    return const[labels]

def symbols_to_bits(sym_hat_labels, M):
    _, bitmap = qam_constellation(M)
    return bitmap[sym_hat_labels].ravel()

def hard_decision(y, M):
    """Minimum-Euclidean-distance decision. Returns labels (ints)."""
    const, _ = qam_constellation(M)
    return np.argmin(np.abs(y[:, None] - const[None, :]), axis=1)

# --------------------------------------------------------------------
# 2. Pulse shaping
# --------------------------------------------------------------------
def rrc_taps(beta, sps, span):
    """
    Root-raised-cosine FIR, unit energy.
    beta : roll-off (0 < beta <= 1); sps: samples per symbol;
    span : filter length in symbols (total taps = span*sps + 1).
    """
    t = np.arange(-span * sps / 2, span * sps / 2 + 1) / sps  # in symbols
    h = np.zeros_like(t)
    for i, ti in enumerate(t):
        if abs(ti) < 1e-12:
            h[i] = 1 - beta + 4 * beta / np.pi
        elif beta > 0 and abs(abs(ti) - 1 / (4 * beta)) < 1e-12:
            h[i] = (beta / np.sqrt(2)) * ((1 + 2 / np.pi) * np.sin(np.pi / (4 * beta))
                                          + (1 - 2 / np.pi) * np.cos(np.pi / (4 * beta)))
        else:
            h[i] = (np.sin(np.pi * ti * (1 - beta)) + 4 * beta * ti * np.cos(np.pi * ti * (1 + beta))) \
                   / (np.pi * ti * (1 - (4 * beta * ti) ** 2))
    return h / np.sqrt(np.sum(h ** 2))

def upsample(x, sps):
    y = np.zeros(len(x) * sps, dtype=complex)
    y[::sps] = x
    return y

def filter_same(x, h):
    """Linear convolution trimmed to the input length (zero group delay for symmetric h)."""
    return np.convolve(x, h, mode="same")

# --------------------------------------------------------------------
# 3. Noise
# --------------------------------------------------------------------
def add_awgn(x, snr_db, sps=1, rng=None):
    """
    Add complex AWGN so that Es/N0 = snr_db, where Es is the energy per
    SYMBOL. With sps samples per symbol the per-sample signal power is
    Es/sps when the pulse has unit energy... we measure it directly:
    noise variance per sample = P_signal * sps / SNR.
    """
    rng = np.random.default_rng() if rng is None else rng
    P = np.mean(np.abs(x) ** 2)
    N0 = P * sps / 10 ** (snr_db / 10)
    n = np.sqrt(N0 / 2) * (rng.standard_normal(x.shape) + 1j * rng.standard_normal(x.shape))
    return x + n

def laser_phase_noise(N, linewidth_hz, fs, rng=None):
    """Wiener phase noise: increments ~ N(0, 2*pi*linewidth/fs)."""
    rng = np.random.default_rng() if rng is None else rng
    var = 2 * np.pi * linewidth_hz / fs
    return np.cumsum(np.sqrt(var) * rng.standard_normal(N))

# --------------------------------------------------------------------
# 4. Fiber channel
# --------------------------------------------------------------------
def beta2_from_D(D_ps_nm_km=17.0, wavelength_m=1550e-9):
    """beta2 in s^2/m from D in ps/(nm km)."""
    D = D_ps_nm_km * 1e-6  # ps/(nm km) -> s/m^2
    return -D * wavelength_m ** 2 / (2 * np.pi * C_LIGHT)

def cd_channel(x, fs, L_m, D_ps_nm_km=17.0, wavelength_m=1550e-9, compensate=False):
    """Apply (or undo, compensate=True) chromatic dispersion in the frequency domain."""
    b2 = beta2_from_D(D_ps_nm_km, wavelength_m)
    w = 2 * np.pi * np.fft.fftfreq(x.shape[-1], 1 / fs)
    sign = +1 if compensate else -1
    H = np.exp(sign * 1j * b2 * L_m * w ** 2 / 2)
    return np.fft.ifft(np.fft.fft(x, axis=-1) * H, axis=-1)

def random_unitary_2x2(rng=None):
    """A random polarization rotation (SOP) as a 2x2 unitary Jones matrix."""
    rng = np.random.default_rng() if rng is None else rng
    theta, phi, psi = rng.uniform(0, 2 * np.pi, 3)
    R = np.array([[np.cos(theta), -np.sin(theta)], [np.sin(theta), np.cos(theta)]])
    P = np.diag([np.exp(1j * phi / 2), np.exp(-1j * phi / 2)])
    return np.exp(1j * psi) * (R @ P)

def ssfm(x, fs, L_m, n_steps, alpha_db_km=0.2, D_ps_nm_km=17.0, gamma=1.3e-3,
         wavelength_m=1550e-9):
    """
    Symmetric split-step Fourier method for the scalar NLSE (single pol),
    engineering sign convention:
        dA/dz = -alpha/2 A + j beta2/2 d^2A/dt^2 - j gamma |A|^2 A
    x is the optical field in sqrt(W); gamma in 1/(W m).
    """
    b2 = beta2_from_D(D_ps_nm_km, wavelength_m)
    alpha = alpha_db_km / (10 * np.log10(np.e)) / 1e3  # 1/m
    dz = L_m / n_steps
    w = 2 * np.pi * np.fft.fftfreq(len(x), 1 / fs)
    Hhalf = np.exp((-1j * b2 * w ** 2 / 2 - alpha / 2) * dz / 2)
    # effective length of one step, referenced to the MID-step power (where the
    # nonlinear operator is applied in the symmetric scheme)
    leff = (1 - np.exp(-alpha * dz)) / alpha * np.exp(alpha * dz / 2) if alpha > 0 else dz
    A = x.astype(complex)
    for _ in range(n_steps):
        A = np.fft.ifft(np.fft.fft(A) * Hhalf)
        A = A * np.exp(-1j * gamma * np.abs(A) ** 2 * leff)
        A = np.fft.ifft(np.fft.fft(A) * Hhalf)
    return A

# --------------------------------------------------------------------
# 5. Receiver DSP blocks
# --------------------------------------------------------------------
def cma_butterfly(x, n_taps=15, mu=1e-3, sps=2, R2=1.0, n_iter=1, centroid_trace=None,
                  recenter=False):
    """
    2x2 MIMO butterfly equaliser adapted with the constant-modulus
    algorithm. x : 2 x N array at `sps` samples/symbol (sps=2 typical).
    Output: 2 x (N//sps) array at 1 sample/symbol.
    Filter taps h[out, in, tap]. Centre-spike initialisation.
    Update: e = R2 - |y|^2,  h <- h + mu * e * y * conj(x_window)
    """
    N = x.shape[1]
    h = np.zeros((2, 2, n_taps), complex)
    h[0, 0, n_taps // 2] = 1; h[1, 1, n_taps // 2] = 1
    n_out = (N - n_taps) // sps
    y = np.zeros((2, n_out), complex)
    for _ in range(n_iter):
        for k in range(n_out):
            win = x[:, k * sps:k * sps + n_taps][:, ::-1]   # most recent sample first
            yk = np.sum(h * win[None, :, :], axis=(1, 2))
            e = R2 - np.abs(yk) ** 2
            h += mu * (e * yk)[:, None, None] * np.conj(win)[None, :, :]
            y[:, k] = yk
            if (centroid_trace is not None or recenter) and k % 500 == 0:
                p = np.sum(np.abs(h) ** 2, axis=(0, 1))
                c = np.sum(np.arange(n_taps) * p) / np.sum(p)
                if centroid_trace is not None:
                    centroid_trace.append(c)
                # Tap re-centering: if the energy centroid has drifted by more than
                # 1.5 samples, shift all taps by one SYMBOL (sps samples) back toward
                # the centre. The output then jumps by one symbol, which the receiver's
                # per-frame synchronisation absorbs.
                if recenter and abs(c - n_taps // 2) > 1.5:
                    s_ = sps if c > n_taps // 2 else -sps
                    h = np.roll(h, -s_, axis=2)
                    if s_ > 0: h[:, :, -s_:] = 0
                    else: h[:, :, :-s_] = 0
    return y, h

def foe_coarse_spectral(x, fs):
    """
    Coarse frequency-offset estimate from the centre of gravity of the power spectrum
    (both polarizations). Works at any oversampling, before the matched filter and the
    equalizer, over a range limited only by the sampling bandwidth; accuracy ~tens of MHz
    (limited by spectral asymmetry and noise). Used to remove most of a large offset so
    that the matched filter is not mis-centred; the fine 4th-power estimate follows.
    """
    x = np.atleast_2d(x)
    S = np.sum(np.abs(np.fft.fft(x, axis=-1)) ** 2, axis=0)
    f = np.fft.fftfreq(x.shape[-1], 1 / fs)
    S = S - np.median(S)                  # remove the (white) noise floor
    S[S < 0] = 0
    return np.sum(f * S) / np.sum(S)

def foe_4th_power(y, fs):
    """
    Frequency-offset estimate for QPSK-like signals (1 sample/symbol):
    raise to 4th power (removes modulation), find the spectral peak at 4*df.
    Unambiguous range: |df| < fs/8.
    """
    N = len(y)
    S = np.abs(np.fft.fft(y ** 4, n=4 * N))
    f = np.fft.fftfreq(4 * N, 1 / fs)
    return f[np.argmax(S)] / 4

def viterbi_viterbi(y, block=32):
    """
    Blind 4th-power phase estimation (QPSK). Sliding average of y^4 over
    `block` symbols, divide the angle by 4, unwrap across pi/2 jumps.
    Returns phase-corrected signal and the phase estimate.
    """
    z = y ** 4
    kern = np.ones(block)
    zs = np.convolve(z, kern, mode="same")
    phi = np.angle(-zs) / 4          # the -1 accounts for QPSK^4 = -1 (points at 45 deg)
    phi = np.unwrap(4 * phi) / 4     # remove pi/2 jumps (cycle slips still possible)
    return y * np.exp(-1j * phi), phi

def blind_phase_search(y, M, n_test=32, block=32):
    """
    Blind phase search (Pfau et al., 2009) for square M-QAM.
    Test angles in [-pi/4, pi/4); pick the one minimising the summed
    squared distance to the nearest constellation point over a block.
    """
    const, _ = qam_constellation(M)
    phis = (np.arange(n_test) / n_test - 0.5) * np.pi / 2
    dist = np.zeros((n_test, len(y)))
    for i, p in enumerate(phis):
        r = y * np.exp(-1j * p)
        d = np.min(np.abs(r[:, None] - const[None, :]) ** 2, axis=1)
        dist[i] = np.convolve(d, np.ones(block), mode="same")
    idx = np.argmin(dist, axis=0)
    phi = np.unwrap(4 * phis[idx]) / 4
    return y * np.exp(-1j * phi), phi

def resolve_ambiguity(y, ref):
    """Remove the unknown 90-degree rotation (and pick best) using known symbols."""
    best, best_err = None, np.inf
    for k in range(4):
        r = y * np.exp(1j * np.pi / 2 * k)
        err = np.mean(np.abs(r - ref) ** 2)
        if err < best_err:
            best, best_err = r, err
    return best

def align(rx, tx):
    """Find the integer delay of rx relative to tx by cross-correlation; return aligned tx."""
    n = len(rx)
    c = np.fft.ifft(np.fft.fft(rx, 2 * n) * np.conj(np.fft.fft(tx[:n], 2 * n)))
    d = np.argmax(np.abs(c))
    return np.roll(tx, d)[:n] if d < n else np.roll(tx, d - 2 * n)[:n]

# --------------------------------------------------------------------
# 6. Performance metrics
# --------------------------------------------------------------------
def ber_count(rx_sym, tx_sym, M):
    b_hat = symbols_to_bits(hard_decision(rx_sym, M), M)
    b = symbols_to_bits(hard_decision(tx_sym, M), M)
    return np.mean(b_hat != b)

def snr_estimate_db(rx_sym, tx_sym):
    """Data-aided SNR = |a|^2 / E|y - a x|^2 with optimal complex scaling a."""
    a = np.vdot(tx_sym, rx_sym) / np.vdot(tx_sym, tx_sym)
    e = rx_sym - a * tx_sym
    return 10 * np.log10(np.mean(np.abs(a * tx_sym) ** 2) / np.mean(np.abs(e) ** 2))

def evm_rms(rx_sym, tx_sym):
    return np.sqrt(np.mean(np.abs(rx_sym - tx_sym) ** 2) / np.mean(np.abs(tx_sym) ** 2))

def gmi_awgn(rx_sym, tx_bits, M, snr_db=None):
    """
    GMI (bits/2D-symbol) for bit-wise decoding with max-log-free exact
    LLRs under a Gaussian noise assumption.
    tx_bits : array of shape (N, log2 M).
    """
    const, bitmap = qam_constellation(M)
    k = int(np.log2(M))
    if snr_db is None:
        tx_sym = const[tx_bits.dot(1 << np.arange(k - 1, -1, -1))]
        snr_db = snr_estimate_db(rx_sym, tx_sym)
    N0 = 10 ** (-snr_db / 10)
    metric = -np.abs(rx_sym[:, None] - const[None, :]) ** 2 / N0  # log-likelihood (up to const)
    gmi = k
    for i in range(k):
        m1 = np.where(bitmap[:, i] == 1, metric, -np.inf)
        m0 = np.where(bitmap[:, i] == 0, metric, -np.inf)
        llr = np.logaddexp.reduce(m0, axis=1) - np.logaddexp.reduce(m1, axis=1)  # log P(b=0)/P(b=1)
        s = 1 - 2 * tx_bits[:, i]           # +1 for bit 0, -1 for bit 1
        gmi -= np.mean(np.logaddexp(0, -s * llr)) / np.log(2)
    return gmi

def qfunc(x):
    from scipy.special import erfc
    return 0.5 * erfc(x / np.sqrt(2))

def ber_qam_theory(M, esn0_db):
    """Approximate Gray-coded square M-QAM BER in AWGN (exact for QPSK)."""
    es = 10 ** (esn0_db / 10)
    k = np.log2(M)
    return 4 / k * (1 - 1 / np.sqrt(M)) * qfunc(np.sqrt(3 * es / (M - 1)))

# --------------------------------------------------------------------
# 7. Additions (revision 2): ADC model, timing recovery, dynamic channel,
#    pilots and frames, pilot-aided phase recovery, fixed point
# --------------------------------------------------------------------
def lagrange_cubic(x, n, mu):
    """
    Cubic Lagrange (Farrow) interpolation of x at fractional positions n+mu,
    0 <= mu < 1, using samples n-1, n, n+1, n+2. x: (..., N); n, mu: arrays.
    """
    xm1, x0, x1, x2 = x[..., n - 1], x[..., n], x[..., n + 1], x[..., n + 2]
    c1 = -xm1 / 3 - x0 / 2 + x1 - x2 / 6
    c2 = xm1 / 2 - x0 + x1 / 2
    c3 = -xm1 / 6 + x0 / 2 - x1 / 2 + x2 / 6
    return ((c3 * mu + c2) * mu + c1) * mu + x0

def sinc_interp(x, n, mu, half_len=8):
    """
    Windowed-sinc interpolation (2*half_len taps, Blackman window) of x at n+mu.
    More accurate than cubic Lagrange near the band edge, at higher cost.
    x: (..., N); n: int array; mu: float or array with same length as n.
    """
    k = np.arange(-half_len + 1, half_len + 1)                 # tap offsets relative to n
    mu = np.broadcast_to(np.asarray(mu, float), np.shape(n))
    d = k[None, :] - mu[:, None]                               # distance of each tap from target
    w = 0.42 + 0.5 * np.cos(np.pi * d / half_len) + 0.08 * np.cos(2 * np.pi * d / half_len)
    kern = np.sinc(d) * w
    idx = np.asarray(n)[:, None] + k[None, :]
    return np.sum(x[..., idx] * kern, axis=-1)

def adc_sample(x, sps_in, sps_out=2, ppm=0.0, phase=0.0):
    """
    Model a free-running ADC: sample the (oversampled, band-limited) signal x,
    given at sps_in samples/symbol, at sps_out*(1+ppm*1e-6) samples/symbol with an
    initial fractional phase `phase` (in output samples). The signal is first
    upsampled x2 so that cubic interpolation is accurate.
    """
    from scipy.signal import resample_poly
    xu = resample_poly(x, 2, 1, axis=-1)
    step = 2 * sps_in / (sps_out * (1 + ppm * 1e-6))      # input samples per output sample
    t0 = 4 * sps_in                                        # xu index of a symbol instant (x index 2*sps_in)
    n_out = int((xu.shape[-1] - t0 - 4 - phase * step) / step)
    t = t0 + phase * step + np.arange(n_out) * step
    n = np.floor(t).astype(int); mu = t - n
    return lagrange_cubic(xu, n, mu)

def gardner_timing_recovery(x, kp=3e-3, ki=1e-5, interp="sinc", n_acq=8000, gear=(4, 30)):
    """
    Closed-loop timing recovery for a (dual-pol) signal at ~2 samples/symbol:
        interpolator (windowed sinc, or cubic Farrow with interp="cubic")
        -> Gardner TED (summed over pols) -> PI loop filter -> NCO (fractional position t)
    Gardner error (Ch. 6): e = Re{ y_mid * conj(y_prev - y_next) }; e > 0 means 'early'
    (sampling before the ideal instant), so the loop moves the sampling time later.
    Loop filter: the integral branch estimates the clock-frequency offset and is applied
    to EVERY output sample; the proportional branch corrects the phase once per symbol.
    Gear shifting: wide bandwidth (kp, ki) for the first n_acq symbols to acquire fast,
    then kp /= gear[0], ki /= gear[1] for low jitter while tracking.
    Returns y (2 x K, exactly 2 samples/symbol, even indices = symbol instants) and the
    integrator trace (clock-frequency offset estimate, as a fraction of a sample per sample).
    """
    x = np.atleast_2d(x)
    N = x.shape[1]
    out, trace = [], []
    t, integ = 10.0, 0.0
    while t < N - 10:
        n = int(t); mu = t - n
        if interp == "sinc":
            out.append(sinc_interp(x, np.array([n]), mu)[:, 0])
        else:
            out.append(lagrange_cubic(x, np.array([n]), mu)[:, 0])
        if len(out) == 2 * n_acq:                          # gear shift: acquisition -> tracking
            kp, ki = kp / gear[0], ki / gear[1]
        prop = 0.0
        if len(out) >= 3 and len(out) % 2 == 1:           # just produced a symbol-instant sample
            prev, mid, nxt = out[-3], out[-2], out[-1]
            e = np.sum(np.real(mid * np.conj(prev - nxt)))
            integ += ki * e                                # clock-frequency estimate
            prop = kp * e                                  # timing-phase correction
            trace.append(integ)
        t += 1.0 + integ + prop                            # NCO
    return np.array(out).T, np.array(trace)

def sop_dynamic(x, fs, rate_rad_s, rng=None):
    """Polarization rotation whose angle grows at rate_rad_s (rad/s), between random unitaries."""
    rng = np.random.default_rng() if rng is None else rng
    U1, U2 = random_unitary_2x2(rng), random_unitary_2x2(rng)
    th = rng.uniform(0, 2 * np.pi) + rate_rad_s * np.arange(x.shape[1]) / fs
    y = U2 @ x
    y = np.vstack([np.cos(th) * y[0] - np.sin(th) * y[1], np.sin(th) * y[0] + np.cos(th) * y[1]])
    return U1 @ y

def pmd_first_order(x, fs, dgd_s, rng=None):
    """First-order PMD: random rotation, differential delay dgd_s between principal states, random rotation."""
    rng = np.random.default_rng() if rng is None else rng
    w = 2 * np.pi * np.fft.fftfreq(x.shape[1], 1 / fs)
    X = random_unitary_2x2(rng) @ np.fft.fft(x, axis=1)
    X = np.vstack([X[0] * np.exp(-1j * w * dgd_s / 2), X[1] * np.exp(1j * w * dgd_s / 2)])
    return random_unitary_2x2(rng) @ np.fft.ifft(X, axis=1)

def pdl_element(x, pdl_db, rng=None):
    """Polarization-dependent loss of pdl_db dB between random rotations (not unitary!)."""
    rng = np.random.default_rng() if rng is None else rng
    D = np.diag([1.0, 10 ** (-pdl_db / 20)])
    return random_unitary_2x2(rng) @ D @ random_unitary_2x2(rng) @ x

def build_frames(data_sym, frame_payload=2048, header_len=64, pilot_spacing=32, pol=0):
    """
    Periodic framing, as used (in far more elaborate form) by real coherent standards:
      frame = [known QPSK header] + [payload: one known QPSK pilot every `pilot_spacing`
      symbols, data elsewhere]. The same header repeats in every frame; X and Y use
      different header/pilot sequences so the receiver can tell the polarizations apart.
    Returns (tx_symbols, info) where info holds the header and, for the whole stream,
    the positions of headers, pilots (with values), all known reference symbols
    (ref_pos/ref_val = headers + pilots) and data symbols.
    """
    rng = np.random.default_rng(1000 + pol)
    qpsk = np.exp(1j * (np.pi / 4 + np.pi / 2 * np.arange(4)))
    header = qpsk[rng.integers(0, 4, header_len)]
    n_pil = int(np.ceil(frame_payload / pilot_spacing))
    n_data_per_frame = frame_payload - n_pil
    n_frames = int(np.ceil(len(data_sym) / n_data_per_frame))
    data = np.concatenate([data_sym, data_sym[:n_frames * n_data_per_frame - len(data_sym)]])
    frame_len = header_len + frame_payload
    out = np.zeros(n_frames * frame_len, complex)
    hdr_pos, pil_pos, pil_val, data_pos = [], [], [], []
    pil_local = np.arange(0, frame_payload, pilot_spacing)
    data_local = np.setdiff1d(np.arange(frame_payload), pil_local)
    for f in range(n_frames):
        base = f * frame_len
        out[base:base + header_len] = header
        pv = qpsk[rng.integers(0, 4, len(pil_local))]
        out[base + header_len + pil_local] = pv
        out[base + header_len + data_local] = data[f * n_data_per_frame:(f + 1) * n_data_per_frame]
        hdr_pos.append(base); pil_pos.append(base + header_len + pil_local); pil_val.append(pv)
        data_pos.append(base + header_len + data_local)
    ref_pos = np.concatenate([np.concatenate([np.arange(b, b + header_len) for b in hdr_pos]),
                              np.concatenate(pil_pos)])
    ref_val = np.concatenate([np.tile(header, n_frames), np.concatenate(pil_val)])
    o = np.argsort(ref_pos)
    info = dict(header=header, frame_len=frame_len, hdr_pos=np.array(hdr_pos),
                ref_pos=ref_pos[o], ref_val=ref_val[o],
                pil_pos=np.concatenate(pil_pos), pilots=np.concatenate(pil_val),
                data_pos=np.concatenate(data_pos), n_data=len(data_sym),
                overhead=(header_len + n_pil) / frame_len)
    return out, info

def frame_track(y, info, d0, search=3):
    """
    Per-frame synchronisation: starting from the delay d0 found by frame_sync, re-find
    the header of EVERY frame within +-search symbols of the previous delay. Returns
    an array with one delay per frame (NaN where the frame lies outside y). This
    absorbs one-symbol jumps caused by equalizer tap re-centering.
    """
    h = info["header"]; L = len(h); d = d0; out = []
    for hp in info["hdr_pos"]:
        best, bd = -1, d
        for dd in range(d - search, d + search + 1):
            k = hp + dd
            if 0 <= k and k + L <= len(y):
                c = np.abs(np.vdot(h, y[k:k + L]))
                if c > best: best, bd = c, dd
        if best < 0: out.append(np.nan); continue
        d = bd; out.append(d)
    return np.array(out, float)

def frame_sync(y, info, search_from=0):
    """
    Find the stream offset from the known repeating header: correlate, take the first
    strong peak after `search_from`, and return the offset d such that received index
    = transmitted index + d (d is small: filter and equalizer delays), plus the
    normalised correlation peak (close to 1 when the header is found cleanly).
    """
    h = info["header"]
    c = np.abs(np.correlate(y[search_from:], h, mode="valid")) / np.sum(np.abs(h) ** 2)
    c /= np.sqrt(np.mean(np.abs(y) ** 2))
    k = search_from + int(np.argmax(c[:info["frame_len"] + 1]))
    d_all = k - info["hdr_pos"]
    d = int(d_all[np.argmin(np.abs(d_all))])
    return d, float(np.max(c[:info["frame_len"] + 1]))

def pilot_aided_cpr(y, pil_pos, pilots, M, n_test=32, block=32, avg_pilots=3):
    """
    Pilot-aided carrier phase recovery that uses NO knowledge of the data:
      1. phase at each pilot = angle(y * conj(p)), smoothed over `avg_pilots`
         consecutive pilots, unwrapped (pilots are known, so no 90-degree ambiguity),
         and linearly interpolated to every symbol;
      2. blind phase search gives a finer but ambiguous (mod pi/2) estimate;
      3. each BPS estimate is shifted by the multiple of pi/2 that brings it closest
         to the pilot estimate: the ambiguity disappears, and a cycle slip can last
         at most until the next pilot.
    pil_pos: indices of the pilots in y; pilots: their known values.
    """
    ph = np.angle(np.convolve(y[pil_pos] * np.conj(pilots), np.ones(avg_pilots), mode="same"))
    phi_pilot = np.interp(np.arange(len(y)), pil_pos, np.unwrap(ph))
    _, phi_bps = blind_phase_search(y, M, n_test, block)
    k = np.round((phi_pilot - phi_bps) / (np.pi / 2))
    phi = phi_bps + k * np.pi / 2
    phi[pil_pos] = phi_pilot[pil_pos]          # at known symbols, trust the pilot estimate
    return y * np.exp(-1j * phi), phi, phi_pilot

def quantize(x, bits, clip_ratio=3.0):
    """
    Uniform mid-rise quantiser applied separately to real and imaginary parts.
    Full scale = clip_ratio * rms of each quadrature; values beyond are clipped.
    """
    def q(v):
        fs = clip_ratio * np.sqrt(np.mean(v ** 2))
        step = 2 * fs / 2 ** bits
        return np.clip((np.floor(v / step) + 0.5) * step, -fs + step / 2, fs - step / 2)
    return q(np.real(x)) + 1j * q(np.imag(x)) if np.iscomplexobj(x) else q(x)

def timing_cma_joint(x, n_taps=15, mu=1e-3, R2=1.0, kp=3e-3, ki=1e-5, n_acq=11000,
                     gear=(4, 30), kc_p=0.02, kc_f=2e-7, every=50, centroid_trace=None,
                     clock_trace=None):
    """
    Joint timing recovery + 2x2 CMA equalizer (input ~2 sps, output 1 sps).

    Why joint? With PMD and polarization mixing, the Gardner detector (computed BEFORE
    the equalizer) becomes weak and its clock estimate wanders; a fractionally spaced
    equalizer then silently absorbs the timing drift until its taps run off the end of
    the filter ("tap walk-off"). The remedy used in practice is to let the equalizer
    steer the clock: every `every` symbols the energy centroid c of the taps is measured
    and fed back into the NCO,
        phase:     t      -= kc_p * (c - centre)
        frequency: integ  -= kc_f * (c - centre)
    so the timing loop, not the equalizer, follows the clock. The Gardner detector is
    kept for fast initial acquisition.
    """
    x = np.atleast_2d(x); N = x.shape[1]
    h = np.zeros((2, 2, n_taps), complex); cen = n_taps // 2
    h[0, 0, cen] = h[1, 1, cen] = 1
    buf = []; out = []; t, integ = 10.0, 0.0; ns = 0
    while t < N - 10:
        n = int(t); mu_f = t - n
        buf.append(sinc_interp(x, np.array([n]), mu_f)[:, 0])
        ns += 1                                            # total samples produced
        if ns == 2 * n_acq:
            kp, ki = kp / gear[0], ki / gear[1]
        prop = 0.0
        if ns >= 3 and ns % 2 == 1:                        # symbol-instant sample just produced
            e = np.sum(np.real(buf[-2] * np.conj(buf[-3] - buf[-1])))
            integ += ki * e; prop = kp * e
            if ns >= n_taps:                               # run the equalizer once per symbol
                win = np.array(buf[-n_taps:]).T[:, ::-1]
                yk = np.sum(h * win[None], axis=(1, 2))
                ec = R2 - np.abs(yk) ** 2
                h += mu * (ec * yk)[:, None, None] * np.conj(win)[None]
                out.append(yk)
                if len(out) % every == 0:
                    p = np.sum(np.abs(h) ** 2, axis=(0, 1))
                    c = np.sum(np.arange(n_taps) * p) / np.sum(p)
                    t -= kc_p * (c - cen); integ -= kc_f * (c - cen)
                    if centroid_trace is not None: centroid_trace.append(c)
                    if clock_trace is not None: clock_trace.append(integ)
            if len(buf) > 4 * n_taps:
                del buf[:2 * n_taps]                       # bounded memory (even count)
        t += 1.0 + integ + prop
    return np.array(out).T, h
