# Chapter 6 — The Coherent Receiver DSP Chain

> **Learning objectives.** After this chapter you can explain, derive and implement every block of a digital coherent receiver: front-end correction (normalisation, deskew, Gram–Schmidt), CD estimation and compensation, timing recovery, the 2×2 MIMO adaptive equalizer (CMA, RDE, DD-LMS), frequency-offset estimation, carrier-phase recovery (Viterbi–Viterbi, blind phase search, pilot-aided), and performance monitoring. You will also understand *why* the blocks are in this order and how they are implemented in real ASICs.

This is the longest chapter. Budget two weeks for it.

> **Study plan.** Week 1: §6.1–6.5 (front end, CD, timing, equalizer). Week 2: §6.6–6.10 (frequency offset, carrier phase, framing, the complete receiver). After each block, run the corresponding code and look at the constellation (Figure 6.1) at that stage. Checkpoints: after §6.4 you should be able to explain Figure 6.3; after §6.8 you should be able to explain every line of the capstone output in §6.10. Problems are rated ★ / ★★ / ★★★. Wirtinger (complex) gradients used in §6.5 are explained in `appendix_A_math_and_glossary.md` (A.2).

---

## 6.1 The chain at a glance

```mermaid
flowchart TD
  A["ADC samples X_I, X_Q, Y_I, Y_Q<br/>(~1.1–2 sps, free-running clock)"] --> B["1. Front-end correction<br/>DC removal, normalisation, deskew, GSOP"]
  B --> C["2. Resampling to DSP rate (e.g. 2 sps)"]
  C --> D["3. CD compensation<br/>static FD filter; CD estimated at start-up"]
  D --> D2["3b. Coarse frequency-offset removal<br/>then matched filter"]
  D2 --> E["4. Timing recovery<br/>clock phase and frequency"]
  E --> F["5. 2×2 MIMO adaptive equalizer<br/>pol. demux, PMD, residual ISI → 1 sps<br/>(its taps also steer the clock)"]
  F --> G["6. Frequency-offset estimation"]
  G --> H["7. Frame synchronisation<br/>header correlation: delay and polarization identity"]
  H --> I["8. Carrier-phase recovery<br/>pilot-aided + blind phase search"]
  I --> J["9. Demapping → LLRs → FEC decoder"]
  J --> K["10. Monitoring: SNR, BER, GMI, CD, DGD, OSNR"]
```

(Text version: front-end correction → resampling → CD compensation → coarse frequency-offset removal and matched filter → timing recovery → 2×2 equalizer → frequency-offset estimation → frame synchronisation → carrier-phase recovery → demapping/FEC → monitoring.)

![Constellation after each receiver stage](figures/ch6_dsp_stages.png)

*Figure 6.1 — The X-output of our receiver after each stage, for DP-16QAM after 800 km (10 ps DGD, rotating SOP, 1.2 GHz frequency offset, 100 kHz linewidth per laser, 20 ppm ADC clock offset). Nothing is recognisable until CD compensation, timing recovery and polarization demultiplexing are done. After the CMA equalizer the three 16-QAM rings appear — the constellation is still spinning, and CMA does not care. Frequency-offset removal stops the spinning; the remaining smear is laser phase noise, removed by carrier-phase recovery. Learn to read this sequence: in the lab you will debug receivers exactly this way.*

### Why this order? The guiding principle
Each block is placed where its **assumptions are satisfied** and where it **does not disturb the blocks after it**:

- **Static before dynamic.** CD is huge (hundreds to thousands of symbols of memory) but constant; compensating it once with a large, cheap frequency-domain filter leaves the adaptive equalizer only a short, fast-changing residual to learn. An adaptive filter with thousands of taps would converge slowly and track poorly.
- **Timing recovery needs CD removed**, because CD destroys the clock tone that timing detectors rely on.
- **The equalizer before carrier recovery**, because a *blind* constant-modulus equalizer is insensitive to phase and frequency offset, while carrier recovery needs clean, ISI-free, polarization-separated symbols.
- **Frequency offset before phase recovery**, because phase estimators average over blocks during which the phase must be nearly constant; a GHz offset rotates the constellation by tens of degrees per symbol.

## 6.2 Front-end correction

### Normalisation and DC removal
Remove the mean of each of the four real lanes (DC offset from imperfect balanced detection) and scale each lane to unit power. Adaptive algorithms' step sizes assume a known input power.

### Deskew
A path-length difference of $\tau$ between the I and Q lanes of a polarization multiplies the Q component by $e^{-j\omega\tau}$ — a frequency-dependent error that the *complex* equalizer cannot fully undo, because it treats I and Q jointly as one complex signal. Skew values are calibrated at the factory (or estimated in the field) and removed with per-lane fractional delays (Chapter 2). At 130 GBd, even 1 ps of skew causes a measurable penalty.

### IQ orthogonalisation: Gram–Schmidt (GSOP)
Hybrid phase errors and responsivity mismatches make the received "Q" lane a mixture of the true Q and some I, with a different gain:

$$r_I = I,\qquad r_Q = g\,(Q\cos\epsilon + I\sin\epsilon).$$

The constellation becomes a squashed parallelogram. The **Gram–Schmidt orthogonalisation procedure** (Fatadin, Ives & Savory, 2008) makes the two lanes orthogonal and equal in power:

$$I_o = \frac{r_I}{\sqrt{\mathbb{E}\{r_I^2\}}},\qquad Q' = r_Q - \frac{\mathbb{E}\{r_Ir_Q\}}{\mathbb{E}\{r_I^2\}}r_I,\qquad Q_o = \frac{Q'}{\sqrt{\mathbb{E}\{Q'^2\}}}.$$

In words: remove from Q the part that is correlated with I, then normalise. (Since the true I and Q are uncorrelated, any correlation must be an impairment.) In `code/solutions_extra.py`, 20% gain mismatch and 8° quadrature error reduce a 25 dB signal to 17.8 dB; after GSOP it is back to 24.8 dB.

An alternative is to let a **4×4 real-valued MIMO** equalizer (or "widely linear" complex equalizer) learn IQ imbalance jointly with everything else, which also handles frequency-dependent imbalance and transmitter-side IQ skew; this is increasingly used at very high baud rates.

## 6.3 Chromatic-dispersion compensation

### Compensation
Multiply the spectrum by $G(\omega)=\exp(+j\beta_2L\omega^2/2)$ using overlap-save (Chapter 2). In `optdsp`, `cd_channel(x, fs, L, compensate=True)` does this on the whole block. The matched filter and any static TX/RX bandwidth correction can be folded into the same frequency-domain multiplication for free.

### Blind CD estimation
At start-up the receiver doesn't know the link length (it may be installed anywhere). It **scans** trial CD values, compensates each, and computes a metric that is optimised at the right value. Common metrics: the magnitude of the clock tone (Godard/timing metric), the constant-modulus cost, or an auto-correlation-based metric. Our simple example (`code/ch6_extra.py`) uses the fluctuation of $|y|^2$ at the best sampling phase for QPSK: for a true length of 1234 km, a coarse 50 km scan finds 1250 km and a fine 5 km scan finds 1235 km. Residual errors of a few km (tens of ps/nm) are absorbed by the adaptive equalizer.

## 6.4 Timing (clock) recovery

### The problem
The ADC samples with its own clock, which is not synchronised to the transmitter's symbol clock. There is an unknown **sampling phase** (where within the symbol we sample) and a small **sampling-frequency offset** (ppm level), so the ideal sampling instant drifts. The adaptive equalizer can absorb a fixed fractional delay, but not a continuously drifting one — its taps would "walk off" the end of the filter.

### The feedback loop
```mermaid
flowchart LR
  X[samples] --> I[interpolator] --> T[Gardner TED] --> L["PI loop filter"] --> N["NCO<br/>(fractional position)"]
  N --> I
  I --> O[to equalizer]
```
A **timing error detector (TED)** produces a signal whose average is proportional to the timing error; a proportional-integral loop filter smooths it; a numerically controlled oscillator (NCO) accumulates it into the fractional sampling position used by the interpolator. (In many ASICs the loop instead steers the ADC clock via a PLL; the principle is the same.)

### The Gardner TED
With 2 samples per symbol, let $y_k$ be the sample at the symbol instant and $y_{k-1/2}$ the one halfway between symbols:

$$e_k = \mathrm{Re}\left\{y_{k-1/2}\left(y_{k-1}^* - y_k^*\right)\right\}.$$

**Intuition.** Consider a transition from symbol $-1$ to $+1$. If we sample exactly on time, the midpoint sample sits on the zero crossing, so $e_k\approx0$. If we sample **early**, the "midpoint" sample is taken before the zero crossing, while the waveform still has the sign of the *previous* symbol ($-$); multiplied by $(y_{k-1}-y_k)=(-1-1)=-2$ this gives a **positive** error. Sampling **late** gives a negative error. Averaged over random data, the sign tells the loop which way to move. The TED is independent of carrier phase (the product of a sample with a conjugate difference removes a common rotation), which is why it can run before carrier recovery.

Our simulation of the average $e$ versus timing offset (the "S-curve"; QPSK, raised-cosine β = 0.3, `code/solutions_extra.py`) gives:

| τ / T (positive = late) | −0.375 | −0.25 | −0.125 | 0 | +0.125 | +0.25 | +0.375 |
|---|---|---|---|---|---|---|---|
| mean e | +0.104 | +0.147 | +0.104 | 0.000 | −0.104 | −0.147 | −0.104 |

![Gardner S-curve](figures/ch6_gardner_scurve.png)

*Figure 6.2 — Gardner S-curve. The error is positive when early and negative when late, so a loop that moves the sampling instant later when e > 0 settles at τ = 0. The curve is periodic in T; the zero crossing at ±T/2 has the opposite slope and is an unstable equilibrium ("hang-up" point) — a loop that starts there takes longer to acquire.*

The slope at zero (detector gain) shrinks as β shrinks, which is the quantitative reason small roll-offs make timing recovery harder; practical receivers then use modified TEDs or frequency-domain (Godard-type) detectors.

> **A bug worth learning from.** When first writing this tutorial, the S-curve simulation started at an index that happened to be a *mid-symbol* sample. The roles of "symbol" and "midpoint" samples were silently swapped and the S-curve came out with the opposite sign — still a clean zero crossing at τ = 0, so nothing looked wrong. The error only surfaced when the closed loop locked onto the wrong samples. Moral: test a loop *closed*, not just its detector.

### Closing the loop: interpolator, loop filter, gear shifting
`od.gardner_timing_recovery` implements the full loop at 2 sps (both polarizations' TED outputs are summed):

```python
t, integ = 10.0, 0.0                      # fractional read position (input samples), frequency estimate
while t < N - 10:
    n = int(t); mu = t - n
    out.append(sinc_interp(x, n, mu))     # interpolate at n + mu
    if len(out) == 2 * n_acq:             # gear shift after acquisition
        kp, ki = kp / 4, ki / 30
    prop = 0.0
    if len(out) >= 3 and len(out) % 2 == 1:           # a symbol-instant sample was just produced
        prev, mid, nxt = out[-3], out[-2], out[-1]
        e = np.sum(np.real(mid * np.conj(prev - nxt)))  # Gardner, summed over X and Y
        integ += ki * e                                  # integral branch = clock-frequency estimate
        prop = kp * e                                    # proportional branch = phase correction
    t += 1.0 + integ + prop                              # NCO: advance by one sample (+ corrections)
```

Four design points, each learned the hard way while building and testing this code:

1. **The frequency (integral) term must be applied on every output sample**, while the phase term is updated once per symbol. Applying the integral only on symbol samples makes the loop converge to *twice* the true clock offset (we measured 40.8 ppm for a true 20 ppm before fixing this).
2. **Interpolator accuracy matters at 2 sps.** A cubic Lagrange (Farrow) interpolator is cheap but, for a signal extending to 0.55·R_s at 2 sps, its error alone limits the SNR to ≈ 29.5 dB (noise-free test). A 16-tap windowed-sinc interpolator removes this floor. Real ASICs either oversample a little more, use longer polyphase interpolators, or place the interpolation where the signal is narrower.
3. **Acquisition versus jitter.** Large loop gains acquire fast but make the timing (and clock-frequency estimate) jittery; small gains are clean but slow. **Gear shifting** — wide bandwidth for the first few thousand symbols, then narrow — gets both.
4. **Hang-up.** Starting near the unstable ±T/2 point delays acquisition (Figure 6.2).

Measured performance (DP-QPSK, 2 sps, channel SNR 15 dB, `code/test_optdsp.py` and the chapter scripts), after acquisition:

| ADC clock offset | estimated offset | SNR after timing recovery |
|---|---|---|
| 0 ppm | 0.6 ppm | 14.98 dB |
| +20 ppm | 20.3 ppm | 14.91 dB |
| −100 ppm (started at the hang-up point) | −98.6 ppm | 14.65 dB |

Without timing recovery the same signals are unusable (a fixed half-sample error alone drops a 25 dB signal to ≈ 7 dB; a drifting clock sweeps through all phases).

### When two loops fight: tap walk-off and equalizer-aided timing
The measurements above were made without PMD. With the full capstone channel (10 ps DGD = 0.32 symbol, polarization mixing), a subtle failure appeared in one test case (seed 7, 3 GHz offset). It is worth studying because it happens in real receivers:

- The Gardner detector is computed *before* polarization demultiplexing. With DGD and mixing, the "clock tone" it relies on becomes weak, so the loop's clock-frequency estimate wanders (we measured 27 → 78 → −12 ppm around the true 20 ppm in a normal case, and a wrong 130–150 ppm in the failing one).
- The fractionally spaced equalizer can also shift timing (by moving energy between taps), so it silently absorbs the timing error. Its **tap-energy centroid** drifted from tap 7 to tap 9.9 over 35,000 symbols — exactly the rate of the uncorrected 20 ppm clock offset — until the taps began falling off the end of the 15-tap filter ("tap walk-off"). SNR: 2.8 / 7.8 dB instead of ≈ 16 dB.

Remedies, in increasing order of robustness:
1. **Tap re-centering**: shift the taps back by one symbol when the centroid drifts too far; the output jumps by one symbol, which per-frame synchronisation (§6.8) absorbs. This alone did not fix our failing case, because the clock error kept accumulating.
2. **Equalizer-aided timing** (`od.timing_cma_joint`, used by the capstone): run the interpolator, Gardner detector and CMA in one loop, and feed the tap centroid back into the NCO ($t \mathrel{-}= k_{c,p}(c-c_0)$, $\text{integ} \mathrel{-}= k_{c,f}(c-c_0)$). The equalizer then *steers* the clock instead of silently compensating it. Result for the failing case: 13.0 / 13.9 dB (from 2.8 / 7.8 dB); the normal cases are unchanged (e.g. 15.7 / 16.0 dB at 1.2 GHz; seeds 8–10 at 3 GHz ≈ 16 dB).
3. **Give acquisition enough time.** The remaining loss in the hard cases came from a subtler cause: the frequency offset shifts the effective sampling phase (via the CD-induced bulk delay described in §6.6) by about half a symbol — right onto the Gardner hang-up point — and with PMD weakening the detector, the loop had not finished acquiring when the gear shift narrowed its bandwidth after 8000 symbols. Keeping the wide acquisition bandwidth for 11,000 symbols brought the hard cases (seed 7 at +3 GHz, seed 8 at −3 GHz) to within ≈ 0–0.6 dB of the normal cases. Real receivers use a *lock detector* (e.g. the variance of the TED output, or the equalizer's convergence) to decide when to shift gear, instead of a fixed count — a good extension exercise.

The general lesson: **every adaptive block that can move the sampling instant (timing loop, fractionally spaced equalizer, CD filter delay) must have exactly one "owner" of the timing**, or they will drift against each other.

![Timing loop and pilot-aided phase](figures/ch6_timing_and_cpr.png)

*Figure 6.3 — Left: the loop's clock-frequency estimate converging to the true 20 ppm (dashed); after the gear shift (red dotted line) it becomes much quieter. Right: carrier-phase estimates (§6.7) — the pilot-based estimate (dashed) anchors the fine blind-phase-search estimate (solid) and removes its 90° ambiguity.*

### The Godard (frequency-domain) TED
Timing information lives in the spectrum near $\pm R_s/2$: the product $X(f)X^*(f-R_s)$ has a phase proportional to the timing offset. This can be computed cheaply inside the frequency-domain CD block and is widely used in real ASICs.

### Timing recovery and PMD
When the DGD is close to half a symbol and the power is split equally between principal states, the clock tone can vanish. Robust designs combine the TED with the equalizer (e.g. derive timing from the equalizer taps' centre of gravity) or use polarization-aware detectors.

## 6.5 The 2×2 MIMO adaptive equalizer

### What it must do
After CD compensation, the received dual-polarization signal is

$$\begin{bmatrix}r_X(\omega)\\r_Y(\omega)\end{bmatrix} = \mathbf{H}(\omega)\begin{bmatrix}s_X(\omega)\\s_Y(\omega)\end{bmatrix}+\text{noise},$$

where $\mathbf{H}(\omega)$ contains polarization rotation, PMD, PDL, residual CD, filter narrowing and front-end responses. The equalizer is a **butterfly** of four FIR filters:

$$y_X[k] = \mathbf{h}_{XX}^T\mathbf{r}_X[k] + \mathbf{h}_{XY}^T\mathbf{r}_Y[k],\qquad y_Y[k] = \mathbf{h}_{YX}^T\mathbf{r}_X[k] + \mathbf{h}_{YY}^T\mathbf{r}_Y[k],$$

operating at 2 sps input and producing 1 sps output. It approximates $\mathbf{H}^{-1}(\omega)$ (more precisely, the MMSE inverse). Typical lengths: 7–31 taps per filter, depending on residual memory.

### Constant modulus algorithm (CMA)
Why blind? At start-up, the receiver has no carrier lock, so the constellation spins and decisions are meaningless. We need a cost function that ignores the phase. For QPSK, every symbol has the same modulus. **Godard's CMA** (1980; applied to coherent optics by Savory, Kikuchi and others around 2008) minimises

$$J = \mathbb{E}\left\{\left(|y|^2 - R_2\right)^2\right\},\qquad R_2 = \frac{\mathbb{E}\{|s|^4\}}{\mathbb{E}\{|s|^2\}}.$$

Taking the stochastic gradient with respect to the taps (as in LMS, Chapter 2) gives the update

$$\boxed{\mathbf{h}_{XX}\leftarrow\mathbf{h}_{XX}+\mu\,e_X\,y_X\,\mathbf{r}_X^*,\quad \mathbf{h}_{XY}\leftarrow\mathbf{h}_{XY}+\mu\,e_X\,y_X\,\mathbf{r}_Y^*,\quad e_X = R_2-|y_X|^2}$$

and the same for the Y output. (Constant factors are absorbed into μ.) The cost depends only on $|y|$, so a common phase rotation — frequency offset or laser phase noise — doesn't disturb the adaptation.

Implementation (`od.cma_butterfly`, simplified):

```python
for k in range(n_out):
    win = x[:, k*sps : k*sps + n_taps][:, ::-1]        # 2 x n_taps input window (newest first)
    yk  = np.sum(h * win[None, :, :], axis=(1, 2))      # 2 outputs: X and Y
    e   = R2 - np.abs(yk)**2
    h  += mu * (e * yk)[:, None, None] * np.conj(win)[None, :, :]
```

Initialisation: a single "centre spike" (tap = 1 in the middle of $\mathbf{h}_{XX}$ and $\mathbf{h}_{YY}$), all else zero.

**CMA on 16-QAM.** 16-QAM has three different radii, so $|y|^2$ can never equal $R_2$ for all symbols. CMA still converges (the cost is minimised by the right inverse on average) but leaves **excess noise**. In our capstone simulation, CMA alone gives 16-QAM an SNR about 1.5 dB below the channel SNR, while QPSK loses only ~0.3 dB.

### Radius-directed equalizer (RDE) and multi-modulus variants
The RDE uses the *nearest* of the constellation's radii as the target: $e = R_{nearest}^2-|y|^2$. It removes most of CMA's excess noise for 16-QAM and higher, while remaining phase-blind. Multi-modulus algorithms (MMA) treat I and Q separately.

### Decision-directed LMS (DD-LMS)
Once the equalizer has converged and carrier recovery has locked, switch to

$$e = \hat{d} - y,\qquad \mathbf{h}\leftarrow\mathbf{h}+\mu\,e\,\mathbf{r}^*,$$

with $\hat d$ the nearest constellation point (after phase correction, which must be fed back into the error). This is the true MMSE solution. In `code/solutions_extra.py`, a phase-locked 16-QAM signal at 20 dB SNR has 17.5 dB after CMA and 19.7 dB after switching to DD-LMS — nearly all of CMA's penalty is recovered. **A standard practical sequence is CMA → (RDE) → DD-LMS**, or training-aided adaptation using known sequences in the frame (used in modern interoperable standards).

### The singularity problem
Nothing in the CMA cost forces the two outputs to be *different* polarizations. Occasionally both outputs converge to the same transmitted polarization. Remedies: (1) initialise the Y-branch from the X-branch using the unitary structure, $\mathbf{h}_{YY}=\mathbf{h}_{XX}^{*}$(time-reversed), $\mathbf{h}_{YX}=-\mathbf{h}_{XY}^{*}$(time-reversed), after the X branch has converged; (2) add a decorrelation term to the cost; (3) use training sequences.

### Step size, tracking and hardware latency
The step size μ balances convergence speed, SOP-tracking speed and excess noise (Chapter 2). Our capstone lets you measure this trade-off directly: the SOP rotates continuously at a chosen speed (`od.sop_dynamic`), and we record the SNR for several CMA step sizes (`code/capstone_answer_key.py`; DP-QPSK, OSNR 16 dB, channel SNR 11.92 dB):

| CMA step μ | 10⁴ rad/s | 10⁵ rad/s | 10⁶ rad/s | 3×10⁶ rad/s | 10⁷ rad/s |
|---|---|---|---|---|---|
| 1×10⁻³ | 11.66 | 11.67 | 11.64 | 11.32 | −0.9 (track lost) |
| 3×10⁻³ | 11.49 | 11.49 | 11.47 | 11.41 | 10.91 |
| 1×10⁻² | 10.27 | 10.27 | 10.24 | 10.24 | 10.15 |

(SNR in dB; channel SNR 11.92 dB.) The trade-off is textbook LMS behaviour: the smallest step gives the best SNR on a slowly varying channel but loses the polarization at 10 Mrad/s; the largest step tracks everything but pays ≈ 1.4 dB of excess noise all the time. A practical answer is an *adaptive* step size, or a moderate step (here 3×10⁻³) sized for the fastest transients the product must survive.

**Caution — simulation versus hardware.** Our equalizer updates its taps every symbol, so even 1 Mrad/s is easy. A hardware equalizer updates once per block of tens to hundreds of symbols and with a feedback delay of many clock cycles, which lowers the trackable rotation speed by one to two orders of magnitude. That is why SOP-tracking speed (often specified in the hundreds of krad/s to Mrad/s, motivated by lightning strikes on aerial fiber) is a demanding hardware specification. Modelling block updates and delay is a good extension exercise.

![SOP tracking versus step size](figures/ch6_sop_tracking.png)

*Figure 6.4 — SNR versus SOP rotation speed for three CMA step sizes. Small steps give the lowest noise when the channel is slow but lose track of fast rotations; large steps track faster at the price of more excess noise.* In hardware, the equalizer runs on ~100+ parallel samples per clock cycle and the tap update is computed from a *block* of errors with a feedback latency of many clock cycles; the effective update rate is therefore much lower than one per symbol, which limits the fastest SOP rotation that can be tracked (a key specification against lightning-induced transients, often quoted in krad/s to Mrad/s).

Many ASICs implement the butterfly in the **frequency domain** (overlap-save with block-wise gradient updates), which is cheaper for long filters.

### What the taps tell you
A converged equalizer is a channel monitor: the inverse of its frequency response estimates $\mathbf{H}(\omega)$, from which DGD, PDL and residual CD can be extracted — valuable network telemetry.

## 6.6 Frequency-offset estimation (FOE)

After the equalizer, each output is approximately $y[k] = s[k]\,e^{j(2\pi\Delta f kT+\phi[k])}+n[k]$.

### 4th-power spectral method (QPSK)
QPSK symbols are $e^{j(\pi/4+m\pi/2)}$; raising to the 4th power gives $s^4=e^{j\pi}=-1$ for all $m$ — the modulation disappears. So

$$y^4[k]\approx -e^{j4(2\pi\Delta f kT+\phi[k])}+\text{noise terms}.$$

That is a pure tone at $4\Delta f$. Find the peak of the FFT of $y^4$ (with zero-padding for resolution) and divide by 4. The unambiguous range is $|4\Delta f|<R_s/2$, i.e. $|\Delta f|<R_s/8$ (4 GHz at 32 GBd). For 16-QAM, the 4th power doesn't make every symbol identical, but the average of $s^4$ is non-zero (a negative real number), so the tone survives with more self-noise; many receivers use QPSK-like "class" partitioning, pilots or a coarse/fine two-stage approach.

### Differential (phase-increment) method
$y[k]y^*[k-1]\approx s[k]s^*[k-1]e^{j2\pi\Delta fT}$. Raising to the 4th power removes the QPSK modulation, so

$$\widehat{\Delta f} = \frac{1}{2\pi T}\cdot\frac14\arg\sum_k\left(y[k]y^*[k-1]\right)^4.$$

It needs no FFT and runs as a simple running average (easy to make a tracking loop).

In our test (32 GBd, Es/N0 = 10 dB, 200 kHz linewidth), true offsets of −3.00, +0.50 and +3.90 GHz are estimated as −3.000/+0.501/+3.899 GHz (FFT method) and −3.021/+0.497/+3.910 GHz (differential). Both work across the ±4 GHz range.

### Practical FOE: coarse before the matched filter, fine after the equalizer
**A bug that taught us something.** In the first version of our capstone, the RRC matched filter was applied *before* any frequency-offset removal. With roll-off 0.1 the matched filter is tight (±17.6 GHz at 32 GBd); a 3 GHz offset pushes the top 3 GHz of the signal out of it and lets noise in on the other side. No equalizer can restore spectrum that was filtered away, so ISI remained: 15.84 dB at 0 GHz fell to 15.39 dB at 1.2 GHz, although the (post-equalizer) frequency estimate was perfect; the 64 GBd run failed outright. Adding a **coarse frequency estimate before the matched filter** — here simply the centre of gravity of the power spectrum (`od.foe_coarse_spectral`, accurate to ~tens of MHz) — restored 15.8–16.1 dB at 1.2 GHz and fixed the 64 GBd case. (The 3 GHz case also failed at first, but the coarse estimate alone did not cure it: a second, independent problem in the timing loop was involved — see "When two loops fight" in §6.4. Real debugging often looks like this: two bugs with overlapping symptoms.) The fine 4th-power estimate after the equalizer removes the residual offset.

A related effect you may notice: because the offset is applied (by the LO) *after* the fiber dispersion, the receiver's CD compensator sees the signal shifted by Δf; expanding $(\omega_0+\Omega)^2$ in its quadratic phase gives an extra linear phase, i.e. a harmless **bulk delay** of $\beta_2 L\cdot2\pi\Delta f$ (≈ −330 ps ≈ −10.5 symbols for 800 km at 3 GHz). Frame synchronisation finds it automatically.

A second benefit of the coarse stage is **range**: the 4th-power estimator alone is limited to ±R_s/8 (±4 GHz at 32 GBd, Problem 6.2), but after coarse removal only a small residual remains. In the capstone answer key (Chapter 9, E3) the final receiver handles offsets from −5 to +4.5 GHz with no penalty. The combined estimate is also used to tune the LO laser.

## 6.7 Carrier-phase recovery (CPR)

After FOE, the residual phase $\phi[k]$ wanders slowly (laser phase noise, Chapter 3) plus any residual frequency error.

### Viterbi–Viterbi (4th-power) estimator for QPSK
Remove the modulation by raising to the 4th power, **average over a block** of $2N+1$ symbols to suppress noise, then take the angle:

$$\hat\phi[k] = \frac14\arg\left\{-\sum_{i=-N}^{N}y^4[k+i]\right\}.$$

(The minus sign accounts for $s^4=-1$.) The estimate is ambiguous modulo $\pi/2$; `np.unwrap(4*phi)/4` makes it continuous. The block length is a **noise-versus-tracking trade-off**: short blocks track phase noise well but are noisy; long blocks average noise but can't follow the phase. From `code/ch6_extra.py` (QPSK, Es/N0 = 10 dB, combined linewidth 2 MHz at 32 GBd):

| Block (symbols) | 1 | 4 | 16 | 32 | 64 | 256 | 1024 | no phase noise |
|---|---|---|---|---|---|---|---|---|
| BER | 0.48 | 0.41 | 1.0e-3 | 9.1e-4 | 8.9e-4 | 1.3e-3 | 0.25 | 7.8e-4 |

With blocks of 1–4 symbols the estimate is so noisy that the unwrapper keeps jumping by 90° — **cycle slips** — and every symbol after a slip is wrong (BER → 0.5). Around 32–64 symbols the BER is within ~15% of the phase-noise-free limit. At 1024 symbols the phase drifts too much within a block and slips return.

![VV block length trade-off](figures/ch6_vv_block.png)

*Figure 6.5 — Viterbi–Viterbi BER versus averaging block length: a clear optimum between "too noisy" (short blocks, cycle slips) and "too slow" (long blocks, phase drift).*

### Cycle slips
A cycle slip is a sudden, persistent π/2 error in the phase estimate. Without countermeasures it destroys all data until the next resynchronisation. Countermeasures: differential coding (a slip then causes only a short burst of errors), periodic **pilot symbols** that detect and correct slips, and slip-tolerant FEC design.

### Blind phase search (BPS) for M-QAM
The 4th-power trick fails for 16-QAM and above (the modulation isn't removed cleanly). **BPS** (Pfau, Hoffmann & Noé, 2009) is brute force made practical:

1. Rotate each received symbol by $B$ test angles $\phi_b$ uniformly spaced in $[-\pi/4,\pi/4)$.
2. For each angle, find the distance to the nearest constellation point: $d_b[k] = \min_a|y[k]e^{-j\phi_b}-a|^2$.
3. Sum the distances over a block of $2N+1$ symbols.
4. Pick the angle with the smallest sum; unwrap.

It works for any constellation, tolerates more phase noise than most alternatives, and parallelises beautifully (each test angle is independent) — which is why it (and its reduced-complexity variants) is the standard in commercial 16-QAM+ receivers. Typical parameters: $B$ = 16–64 test phases, $N$ ≈ 10–30. Pfau et al. report a tolerable linewidth–symbol-duration product on the order of $10^{-4}$ for 16-QAM (1 dB penalty). Implemented as `od.blind_phase_search`.

**Complexity-reducing variants:** two-stage BPS (coarse then fine angles), BPS combined with maximum-likelihood refinement, and pilot-aided phase estimation.

### Pilot-aided CPR
Insert known symbols periodically (e.g. 1 in 32). The phase at each pilot is estimated directly ($\arg(y\,p^*)$), smoothed over a few pilots, unwrapped and interpolated between pilots. Because the pilots are known, this estimate has **no 90° ambiguity** — but it is noisy and has gaps. Blind phase search gives a fine, gap-free estimate that is ambiguous modulo π/2. Combining them is simple and powerful:

$$\hat\phi = \hat\phi_{BPS} + \frac{\pi}{2}\,\mathrm{round}\!\left(\frac{\hat\phi_{pilot}-\hat\phi_{BPS}}{\pi/2}\right).$$

Each BPS estimate is moved by whichever multiple of 90° brings it closest to the pilot estimate. The ambiguity disappears, and a cycle slip can last at most until the next pilot. This is `od.pilot_aided_cpr`; it uses only the known pilots and headers, never the data. The test script adds a deliberate extra 90° rotation to a 16-QAM signal and pilot-aided CPR still returns 17.7 dB at an 18 dB channel. The overhead in our framing (below) is 6.1%; standards use smaller overheads (~1.5–3% for pilots).

### Decision-directed phase-locked loop
$\hat\phi[k+1]=\hat\phi[k]+\mu_\phi\,\mathrm{Im}\{y[k]e^{-j\hat\phi[k]}\hat d^*[k]\}$ — cheap, but its feedback latency in parallel hardware limits the linewidth it can track. Often used as a fine second stage.

## 6.8 Framing and synchronisation

After blind processing, three things are still unknown: (a) the **delay** through the receiver, (b) **which polarization** each equalizer output carries (the CMA may swap them), and (c) the **90° phase ambiguity**. Real systems resolve all three with a **frame structure** of known symbols. Our capstone uses a simple version (`od.build_frames`):

```
| header (64 known QPSK symbols) | payload: 2048 symbols, one known pilot every 32 | header | payload | ...
```

- **Frame synchronisation** (`od.frame_sync`): correlate the output with the known header; the correlation peak gives the delay. The header is phase-insensitive when correlated in magnitude, so this works before carrier recovery.
- **Polarization identity**: X and Y use *different* header sequences; each output port is correlated with both, and the stronger peak says which polarization it carries (the capstone prints e.g. "port 0 carries TX pol Y").
- **Phase ambiguity**: removed by the pilots and headers during carrier recovery (§6.7).

> **Honesty note.** The first version of this tutorial resolved delay, polarization and phase ambiguity by comparing with the *transmitted data* — convenient, but impossible in a real receiver, and it hid cycle slips. The current receiver uses only known header/pilot symbols; the transmitted data are used only to *measure* BER and SNR.

## 6.9 Performance monitoring

- **Data-aided SNR**: $\text{SNR}=|a|^2\mathbb{E}|s|^2/\mathbb{E}|y-as|^2$ with the optimal complex gain $a$ (`od.snr_estimate_db`). Industry calls this "effective SNR"; it is the single most useful number.
- **EVM** (error-vector magnitude): $\text{EVM}_{rms}=\sqrt{\mathbb{E}|y-s|^2/\mathbb{E}|s|^2}$; roughly $\text{SNR}\approx1/\text{EVM}^2$ when using data-aided references.
- **Pre-FEC BER** by error counting (need ~100 errors, Chapter 3).
- **GMI** — the achievable information rate for bit-wise decoding (Chapter 8); the modern performance metric.
- **Estimated link parameters** from the DSP: accumulated CD (from the CD scan), DGD and PDL (from the equalizer taps), frequency offset, OSNR estimates.

## 6.10 The complete receiver, working

`code/capstone_coherent_link.py` implements the complete chain: CD, 10 ps DGD, SOP rotating at 10 krad/s, ASE, 1.2 GHz frequency offset, 100 kHz linewidth per laser, and a free-running ADC with a 20 ppm clock offset and random sampling phase. The receiver uses no knowledge of the data. One run gives:

```
=== DP-QPSK, 32 GBd, 800 km, OSNR 13 dB, 10 ps DGD, 10 krad/s SOP, 20 ppm clock ===
port 0: carries TX pol X (header peak 0.95, delay -6), FO est +1.200 GHz, SNR  8.64 dB, BER 3.90e-03 (44816 bits)
port 1: carries TX pol Y (header peak 0.94, delay -7), FO est +1.200 GHz, SNR  8.67 dB, BER 3.66e-03 (44814 bits)
channel SNR from OSNR: 8.92 dB -> theory BER 2.62e-03; frame overhead 6.1%

=== DP-16QAM, 32 GBd, 800 km, OSNR 20 dB, same impairments ===
port 0: carries TX pol Y (header peak 1.04, delay -6), FO est +1.200 GHz, SNR 14.35 dB, BER 8.41e-03 (89632 bits)
port 1: carries TX pol X (header peak 0.99, delay -7), FO est +1.200 GHz, SNR 14.57 dB, BER 7.12e-03 (89632 bits)
channel SNR from OSNR: 15.92 dB -> theory BER 1.95e-03; frame overhead 6.1%
```

Read this output like an engineer:
- **Synchronisation worked**: header peaks ≈ 1, consistent delays, and both polarizations identified (in the 16-QAM run the equalizer swapped them — normal and harmless).
- **Frequency-offset estimation is exact** (coarse spectral estimate + fine 4th-power estimate).
- **DP-QPSK loses ≈ 0.27 dB of SNR** (8.64–8.67 dB measured vs 8.92 dB). Consistency check: inverting the AWGN BER formula, the measured BERs (3.7–3.9×10⁻³) correspond to 8.50–8.57 dB — close to the measured SNR, so the residual impairment behaves almost like Gaussian noise. (Always do this check: if the BER is much worse than the measured SNR predicts, look for non-Gaussian problems such as cycle slips or residual phase noise.)
- **DP-16QAM loses ≈ 1.5 dB** (14.35–14.57 dB vs 15.92 dB; its BERs likewise correspond to 14.16–14.40 dB), mostly the excess noise of the blind CMA on a three-ring constellation — which Assignment 6.5 addresses with decision-directed adaptation.
- The complete answer key for the capstone experiments (OSNR sweeps, tolerance to linewidth, frequency offset, residual CD and equalizer length, CMA step size, 64 GBd, SOP tracking) is in Chapter 9.

## 6.11 How real ASICs differ from our simulation

- **Parallelism**: processing is done on blocks of ~64–256 samples per clock cycle; every feedback loop (timing, equalizer update, PLL) has a latency of tens of clock cycles.
- **Fixed point**: signals use ~6–10 bits; every block is designed for finite precision.
- **Power**: the DSP dominates module power; algorithm choices are driven by energy per bit as much as by performance. Leading-edge coherent DSPs are built in 5 nm and 3 nm CMOS.
- **Fractional oversampling** (~1.1–1.25 sps) to save ADC and DSP power.
- **Frequency-domain everything**: CD, matched filtering, timing detection and even the MIMO equalizer are often merged in one FFT-based engine.
- **Framing and pilots** defined by standards (e.g. OIF 400ZR/800ZR/1600ZR) for interoperability between vendors.
- **Digital subcarrier multiplexing**: some transceivers split the channel into several lower-baud digital subcarriers, which relaxes EEPN and CD-related complexity and enables point-to-multipoint architectures.

## 6.12 Common pitfalls

1. Running carrier-phase recovery before FOE (phase estimator blocks see tens of degrees of rotation).
2. Using an equalizer step size tuned for unnormalised input.
3. Forgetting that the equalizer introduces a delay and possibly swaps polarizations when comparing with transmitted data.
4. Resolving the 90° ambiguity, the delay or the polarization swap by comparing with the *transmitted data* in simulation. It is impossible in a real receiver and hides cycle slips. Use known headers/pilots (§6.8), and use the data only to measure performance.
7. Omitting the band-limited analog front end before the ADC in simulation: out-of-band noise aliases and costs ≈ 3 dB (Chapter 5, pitfall 2b).
8. Testing a timing error detector (or any loop) only open-loop: a sign error can produce a perfect-looking S-curve and a loop that locks onto the wrong samples (§6.4).
5. Choosing the VV/BPS block length without considering the linewidth–symbol-duration product.
6. Interpreting CMA excess noise on 16-QAM as a channel penalty.

## 6.13 Check your understanding

1. Why is CD compensated with a static filter while polarization is handled by an adaptive one?
2. Why is CMA insensitive to frequency offset?
3. What limits the range of the 4th-power FOE?
4. Why do cycle slips occur more often with short averaging blocks?
5. What does it mean that the two outputs of the butterfly "converged to the same polarization", and how can it be prevented?

<details><summary>Answers</summary>

1. CD is large but constant (depends only on the fiber length), so it is estimated once and removed cheaply in the frequency domain. Polarization changes randomly over time and must be tracked.
2. The CMA error depends only on $|y|$, and a phase rotation $e^{j\theta}$ doesn't change $|y|$.
3. After the 4th power, the tone is at $4\Delta f$, which must lie within $\pm R_s/2$ (1 sps); hence $|\Delta f|<R_s/8$.
4. Noisy phase estimates occasionally cross the ±45° decision boundary of the unwrapper; the unwrapper then "decides" a 90° jump that didn't happen, which persists.
5. Both outputs extract the same transmitted signal, so the other one is lost. Prevention: initialising the second branch from the first using the unitary constraint, decorrelation terms, or training sequences.
</details>

## 6.14 Problems and assignments

### Problem 6.1 ★★ — CMA gradient
Derive the CMA update from $J=\mathbb{E}\{(|y|^2-R_2)^2\}$ with $y=\mathbf{h}^T\mathbf{r}$. Show where $R_2=\mathbb{E}|s|^4/\mathbb{E}|s|^2$ comes from.

<details><summary>Solution</summary>

$|y|^2 = y\,y^*$, with $\partial y/\partial\mathbf{h}^*=0$ and $\partial y^*/\partial\mathbf{h}^* = \mathbf{r}^*$ (Wirtinger calculus). Then $\nabla_{\mathbf{h}^*}J = \mathbb{E}\{2(|y|^2-R_2)\,y\,\mathbf{r}^*\}$. Gradient descent with the instantaneous estimate: $\mathbf{h}\leftarrow\mathbf{h}-\mu'(|y|^2-R_2)y\mathbf{r}^* = \mathbf{h}+\mu\,e\,y\,\mathbf{r}^*$ with $e=R_2-|y|^2$.

$R_2$: at the ideal solution $y=s$ (up to phase), the gradient must vanish on average: $\mathbb{E}\{(|s|^2-R_2)s\,\mathbf{r}^*\}=0$. Writing $\mathbf{r}$ in terms of $s$ and using independence of symbols, the condition reduces to $\mathbb{E}\{|s|^4\}-R_2\mathbb{E}\{|s|^2\}=0$, i.e. $R_2=\mathbb{E}|s|^4/\mathbb{E}|s|^2$. For normalised QPSK, $R_2=1$; for normalised 16-QAM, $R_2=1.32$.
</details>

### Problem 6.2 ★★ — FOE range (coding)
Using `od.foe_4th_power`, sweep the true frequency offset from −6 to +6 GHz for 32 GBd QPSK. Plot estimated vs true. Explain the shape and propose a fix for offsets beyond ±4 GHz.

<details><summary>Solution</summary>

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
Rs = 32e9; s = od.bits_to_symbols(np.random.randint(0, 2, 2*2**14), 4); n = np.arange(len(s))
for df in np.arange(-6e9, 6.01e9, 1e9):
    y = od.add_awgn(s, 12) * np.exp(2j*np.pi*df*n/Rs)
    print(f"{df/1e9:+.0f} -> {od.foe_4th_power(y, Rs)/1e9:+.2f} GHz")
```
Between −4 and +4 GHz the estimate follows the diagonal. Beyond, it wraps by $R_s/4$ = 8 GHz: in our run +5 GHz is estimated as −3.0 GHz, +6 GHz as −2.0 GHz and −6 GHz as +2.0 GHz (a sawtooth), because $4\Delta f$ aliases in the 1-sps spectrum. Fixes: estimate a coarse offset at 2 sps before the equalizer (e.g. from the power spectrum's centre of gravity), or apply the 4th-power method on a 2-sps signal to double the range, or use pilots.
</details>

### Problem 6.3 ★★ — Blind phase search tuning (coding)
For 16-QAM at Es/N0 = 17 dB with combined linewidth 1 MHz at 32 GBd, measure BER after `od.blind_phase_search` for (a) test phases B ∈ {4, 8, 16, 32, 64} with block 32, and (b) blocks N ∈ {4, 8, 16, 32, 64, 128} with B = 32. Explain both trends.

<details><summary>Solution</summary>

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
rng = np.random.default_rng(0); Rs = 32e9; N = 2**15
s = od.bits_to_symbols(rng.integers(0, 2, 4*N), 16)
y = od.add_awgn(s, 17, rng=rng) * np.exp(1j*od.laser_phase_noise(N, 1e6, Rs, rng))
for B in [4, 8, 16, 32, 64]:
    z, _ = od.blind_phase_search(y, 16, n_test=B, block=32); z = od.resolve_ambiguity(z, s)
    print("B =", B, od.ber_count(z[1000:-1000], s[1000:-1000], 16))
for blk in [4, 8, 16, 32, 64, 128]:
    z, _ = od.blind_phase_search(y, 16, n_test=32, block=blk); z = od.resolve_ambiguity(z, s)
    print("block =", blk, od.ber_count(z[1000:-1000], s[1000:-1000], 16))
print("no phase noise theory:", od.ber_qam_theory(16, 17))
```
Results from one run (seed 0; theoretical BER without phase noise ≈ 5.8×10⁻⁴):

| Test phases B (block 32) | 4 | 8 | 16 | 32 | 64 |
|---|---|---|---|---|---|
| BER | 5.5e-3 | 1.6e-3 | 9.5e-4 | 8.1e-4 | 7.6e-4 |

| Block (B = 32) | 4 | 8 | 16 | 32 | 64 | 128 |
|---|---|---|---|---|---|---|
| BER | 0.32 | 0.17 | 8.0e-4 | 8.1e-4 | 9.3e-4 | 1.2e-3 |

(a) The test angles are spaced by $\pi/(2B)$, so the chosen angle can be wrong by up to half a spacing, $\pi/(4B)$ — for B = 4 that is ±11°, which is large compared with the angular distance between the outer 16-QAM points. The BER improves rapidly with B and saturates around 16–32; beyond that, extra test phases only add hardware cost.

(b) The same noise-versus-tracking trade-off as Viterbi–Viterbi: blocks of 4–8 symbols give estimates so noisy that cycle slips occur and the BER collapses; 16–32 symbols is the optimum here; longer blocks slowly lose because the phase drifts within the block ($\Delta\nu T\approx3\times10^{-5}$). The best BER (≈ 8×10⁻⁴) is within ~40% of the phase-noise-free theory; the residual gap is phase-estimation noise. Your exact numbers will vary with the seed.
</details>

### Problem 6.4 ★ — Singularity (conceptual)
Why does the unitary structure $\mathbf{J}=\begin{bmatrix}a&-b^*\\b&a^*\end{bmatrix}$ of a lossless polarization rotation suggest initialising the Y branch as $h_{YY}=h_{XX}^*$ and $h_{YX}=-h_{XY}^*$ (single-tap case)? What goes wrong with this constraint when there is PDL?

<details><summary>Solution</summary>

The ideal equalizer is $\mathbf{J}^{-1}=\mathbf{J}^H=\begin{bmatrix}a^*&b^*\\-b&a\end{bmatrix}$. Its second row is determined by the first: if the X row is $[h_{XX},h_{XY}]=[a^*,b^*]$, the Y row is $[-b, a] = [-h_{XY}^*, h_{XX}^*]$. So once the X output has converged, this initialisation places the Y output on the orthogonal polarization — it cannot converge to the same one. For multi-tap filters, the conjugation comes with time reversal. With PDL, $\mathbf{J}$ is no longer unitary, so this is only an initial guess; the Y branch must then continue adapting freely.
</details>

### Assignment 6.5 ★★★ — Close the 16-QAM gap (coding, major)
*(The reference solution uses the simpler "ideal-sync" version of the channel — no timing offset, PMD or rotating SOP — so that the effect of the equalizer algorithm is isolated. Porting it to the full capstone receiver is a good extension.)*

Modify `capstone_coherent_link.py` so that the 16-QAM receiver runs CMA for the first 10,000 symbols and then switches to **decision-directed LMS with carrier-phase feedback**: at each symbol, (i) compute the equalizer output $y$, (ii) rotate it by the current BPS phase estimate $e^{-j\hat\phi}$, (iii) decide $\hat d$, (iv) compute the error in the *un-rotated* frame, $e=\hat d\,e^{j\hat\phi}-y$, and (v) update $\mathbf{h}\leftarrow\mathbf{h}+\mu\,e\,\mathbf{r}^*$. Use a running phase estimate (e.g. a first-order DD-PLL initialised by BPS). Target: reduce the ~1.5 dB penalty to below 1 dB at OSNR = 20 dB.

<details><summary>Solution and reference result</summary>

The key insight is step (iv): the equalizer operates *before* the carrier phase is removed, so the decision must be rotated back into the equalizer's frame before computing the error; otherwise the error contains the full phase noise and the taps chase it.

A second practical point: a first-order PLL cannot track a 1.2 GHz frequency offset without a large steady-state error. So the reference solution first runs blind CMA, estimates the frequency offset from its output with the 4th-power method, **removes the offset from the equalizer input** (at 2 sps), and then re-runs the butterfly with CMA for 10,000 symbols followed by DD-LMS with an in-loop DD-PLL:

```python
for k in range(n_out):
    win = x[:, 2*k : 2*k + n_taps][:, ::-1]
    y = np.sum(h * win[None], axis=(1, 2))                  # butterfly outputs
    if k < n_cma:                                            # blind pre-convergence
        h += mu_cma * ((R2 - abs(y)**2) * y)[:, None, None] * np.conj(win)[None]
    else:
        for p in range(2):
            z = y[p] * np.exp(-1j*phi[p])                    # de-rotate
            d = const[np.argmin(abs(z - const))]             # decide
            phi[p] += mu_phi * np.imag(z * np.conj(d))       # DD-PLL
            e = d*np.exp(1j*phi[p]) - y[p]                   # error in equalizer frame
            h[p] += mu_dd * e * np.conj(win)
```

The complete, tested script is `code/assignment_6_5_ddlms.py` (the PLL phases are initialised from a BPS estimate at the switch-over). Result for the capstone channel (32 GBd, 800 km, OSNR 20 dB, channel SNR 15.92 dB):

| Receiver | SNR (X / Y) | BER (X / Y) |
|---|---|---|
| CMA + FOE + BPS (capstone) | 14.36 / 14.45 dB | 7.9e-3 / 7.1e-3 |
| CMA → DD-LMS + in-loop PLL | 15.19 / 15.19 dB | 4.1e-3 / 4.1e-3 |

The penalty falls from ≈ 1.5 dB to ≈ 0.7 dB and the BER almost halves. Trying other step sizes (μ_DD from 1e-4 to 3e-4, μ_φ from 0.02 to 0.1) all land at 15.05–15.19 dB, so the remaining ~0.7 dB is not a tuning problem. It comes from the first-order PLL's phase-tracking noise (a BPS stage after the equalizer, or a second-order loop, helps), the finite 15-tap equalizer, and residual LMS misadjustment. Getting below 0.5 dB is a good open-ended extension: try an RDE stage between CMA and DD-LMS, pilot-aided phase estimation, or a smaller μ_DD with a longer run.
</details>

### Problem 6.6 ★★★ — Design: how sparse can the pilots be?
A 64 GBd DP-16QAM receiver uses pilot-aided CPR as in §6.7 (BPS for the fine phase, pilots only to resolve the 90° ambiguity), with 1 MHz combined linewidth and SNR = 15 dB. Pilot phases are averaged over 5 consecutive pilots. (a) Estimate the standard deviation of the pilot-based phase error for pilot spacings of 32, 256 and 1024 symbols. (b) How large may that error be before the ambiguity is resolved wrongly? (c) Choose the spacing, and verify by simulation.

<details><summary>Solution</summary>

(a) Three contributions (per-symbol Wiener variance $\sigma^2=2\pi\Delta\nu T=9.8\times10^{-5}$ rad²):
- *pilot noise*: one QPSK pilot at 15 dB gives a phase variance ≈ $1/(2\,\text{SNR}) = 0.0158$ rad²; averaging 5 pilots → 0.0032 rad²;
- *interpolation between pilots*: a Wiener process pinned at both ends has variance up to $\sigma^2P/4$ at the midpoint (P = spacing);
- *drift within the averaging window* of $5P$ symbols: roughly $\sigma^2\cdot5P/12$.

| spacing P | noise | interpolation | drift | total std |
|---|---|---|---|---|
| 32 | 0.0032 | 0.0008 | 0.0013 | ≈ 4.2° |
| 256 | 0.0032 | 0.0063 | 0.0105 | ≈ 8.0° |
| 1024 | 0.0032 | 0.025 | 0.042 | ≈ 15.2° |

(b) The pilot estimate only selects the multiple of 90° to add to the BPS estimate, so errors up to ±45° are harmless. With a Gaussian error of std σ_φ, the probability of exceeding 45° is $2Q(45°/σ_φ)$: at 8° that is ~2×10⁻⁸ per symbol (negligible); at 15° it is ~3×10⁻³ — every such event is a burst of errors until the next pilot.

(c) Spacing ≈ 256 is a good choice. Simulation (`od.build_frames(..., pilot_spacing=P)` + `od.pilot_aided_cpr`, 16-QAM at 15 dB):

| spacing | measured pilot-phase error std | BER |
|---|---|---|
| 32 | 3.8° | 5.5×10⁻³ |
| 128 | 5.1° | 5.5×10⁻³ |
| 256 | 6.8° | 5.4×10⁻³ |
| 1024 | 11.6° | 7.3×10⁻³ (ambiguity errors appear) |

(The theoretical BER without phase noise is 4.5×10⁻³; the gap is BPS noise, the same for all spacings.) The estimates in (a) are slightly pessimistic but predict the trend and the breaking point correctly. Trade-off to remember: sparser pilots cost less overhead (here the header already contributes 3%) but make cycle slips last longer and fail sooner at high linewidth or low SNR.
</details>

---

## Key takeaways

- **Order matters**: static before adaptive (CD before the equalizer), timing after CD, phase-blind equalization (CMA) before frequency and phase recovery.
- **CD**: frequency-domain filter, length estimated blindly at start-up.
- **Timing recovery** is a closed loop (interpolator → TED → PI filter → NCO); the integral branch learns the clock offset; gear shifting balances acquisition and jitter; interpolator accuracy matters at 2 sps.
- **2×2 butterfly**: CMA (blind, phase-insensitive) → DD-LMS (MMSE); the step size sets SOP-tracking speed versus excess noise.
- **FOE**: 4th power removes QPSK modulation; range ±R_s/8.
- **CPR**: Viterbi–Viterbi (QPSK) or BPS (QAM); block length trades noise against tracking; pilots remove the 90° ambiguity and bound cycle slips.
- **Framing** (headers, pilots) provides delay, polarization identity and phase reference — never use transmitted data inside the receiver.
- Check that the measured BER is consistent with the measured SNR; if not, look for non-Gaussian impairments.

---

**Next:** Chapter 7 covers direct-detection (IM/DD) links, where the physics — and therefore the DSP — are quite different.
