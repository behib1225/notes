"""
Answer key for the capstone experiments E1-E5 (Chapter 9) plus the SOP-tracking study
(Chapter 6). Prints tables and saves figures to ../figures/.
Run:  python capstone_answer_key.py     (about 5-8 minutes)
"""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import optdsp as od
from capstone_coherent_link import run_link

FIG = "../figures/"
def mean_res(res, key): return np.mean([r[key] for r in res])
def gmi_of(res, M):
    const, bitmap = od.qam_constellation(M); g = []
    for r in res:
        lab = od.hard_decision(r["tx"], M)
        g.append(od.gmi_awgn(r["rx"], bitmap[lab], M))
    return np.mean(g)

ideal = dict(L_km=0, dgd_ps=0, sop_rate_rad_s=0, df_hz=0, linewidth_hz=0, ppm=0)

# ---------------- E1: back-to-back -----------------
print("E1  back-to-back (no fiber impairments; timing/framing/CPR still active)")
for M, osnr in [(4, 13.0), (16, 20.0)]:
    res, snr = run_link(M=M, osnr_db=osnr, verbose=False, **ideal)
    print(f"    {M}-QAM OSNR {osnr}: channel SNR {snr:.2f} dB, measured {mean_res(res,'snr_db'):.2f} dB, "
          f"BER {mean_res(res,'ber'):.2e} (theory at channel SNR {od.ber_qam_theory(M, snr):.2e})")

# ---------------- E2: OSNR sweep -----------------
print("\nE2  OSNR sweep after 800 km with all impairments")
fig, ax = plt.subplots(1, 2, figsize=(10, 4))
e2 = {}
for M, osnrs in [(4, np.arange(10, 18.1, 1.0)), (16, np.arange(16, 25.1, 1.0))]:
    bers, gmis, snrs = [], [], []
    for o in osnrs:
        res, snr = run_link(M=M, osnr_db=o, verbose=False)
        bers.append(mean_res(res, "ber")); gmis.append(gmi_of(res, M)); snrs.append(mean_res(res, "snr_db"))
        print(f"    {M:2d}-QAM OSNR {o:4.1f} dB: SNR {snrs[-1]:5.2f} dB, BER {bers[-1]:.2e}, "
              f"GMI {gmis[-1]:.3f} b/sym/pol")
    th = od.ber_qam_theory(M, osnrs + 10 * np.log10(12.5 / 32))
    ax[0].semilogy(osnrs, bers, "o-", label=f"DP-{M}QAM simulated"); ax[0].semilogy(osnrs, th, "k--", lw=1)
    ax[1].plot(osnrs, gmis, "o-", label=f"DP-{M}QAM")
    e2[M] = (osnrs, np.array(bers), th)
    for target in [1e-3, 2e-2]:
        o_sim = np.interp(np.log10(target), np.log10(np.array(bers)[::-1] + 1e-12), osnrs[::-1])
        o_th = np.interp(np.log10(target), np.log10(th[::-1]), osnrs[::-1])
        print(f"        required OSNR at BER {target:.0e}: {o_sim:.2f} dB (theory {o_th:.2f} dB) "
              f"-> penalty {o_sim - o_th:.2f} dB")
ax[0].axhline(2e-2, color="r", lw=0.8); ax[0].text(10.2, 2.4e-2, "oFEC threshold", color="r")
ax[0].set_xlabel("OSNR (dB, 0.1 nm)"); ax[0].set_ylabel("pre-FEC BER"); ax[0].legend(); ax[0].grid(True, which="both", alpha=.3)
ax[0].set_title("E2: BER vs OSNR (dashed = AWGN theory)")
ax[1].set_xlabel("OSNR (dB)"); ax[1].set_ylabel("GMI (bits/symbol/pol)"); ax[1].legend(); ax[1].grid(alpha=.3)
ax[1].set_title("E2: GMI vs OSNR")
plt.tight_layout(); plt.savefig(FIG + "capstone_E2_osnr_sweep.png", dpi=110); plt.close()

# ---------------- E3: impairment tolerance (DP-16QAM, OSNR 22 dB) -----------------
print("\nE3  tolerance sweeps, DP-16QAM, OSNR 22 dB (channel SNR 17.92 dB)")
base = dict(M=16, osnr_db=22.0, verbose=False)
fig, ax = plt.subplots(1, 4, figsize=(15, 3.4))
sweeps = [("linewidth_hz", [1e4, 1e5, 3e5, 1e6, 2e6], "per-laser linewidth (Hz)", True),
          ("df_hz", [-5e9, -3e9, 0, 3e9, 3.9e9, 4.5e9], "frequency offset (Hz)", False),
          ("cd_error_km", [0, 2, 5, 10, 20, 40], "CD compensation error (km)", False),
          ("n_taps", [3, 5, 9, 15, 31], "equalizer taps", False)]
for i, (key, vals, lab, logx) in enumerate(sweeps):
    out = []
    for v in vals:
        res, snr = run_link(**base, **{key: v}); out.append(mean_res(res, "snr_db"))
        if key == "df_hz":                                   # offsets are seed-sensitive: also try seed 8
            res8, _ = run_link(**base, **{key: v}, seed=8); print(f"      (df {v/1e9:+.1f} GHz, seed 8: {mean_res(res8,'snr_db'):.2f} dB)")
    print(f"    {key:14s}: " + ", ".join(f"{v:g} -> {s:.2f} dB" for v, s in zip(vals, out)))
    ax[i].plot(vals, out, "o-"); ax[i].set_xlabel(lab); ax[i].set_ylabel("SNR (dB)")
    ax[i].axhline(17.92, color="k", ls="--", lw=0.8); ax[i].grid(alpha=.3)
    if logx: ax[i].set_xscale("log")
plt.suptitle("E3: impairment tolerance (dashed = channel SNR)"); plt.tight_layout()
plt.savefig(FIG + "capstone_E3_tolerance.png", dpi=110); plt.close()

# ---------------- E4: CMA convergence -----------------
print("\nE4  CMA convergence (DP-QPSK, OSNR 16 dB): smoothed |R2-|y|^2| vs symbol")
plt.figure(figsize=(6, 3.5))
for mu in [3e-4, 1e-3, 3e-3, 1e-2]:
    res, _ = run_link(M=4, osnr_db=16.0, mu_cma=mu, verbose=False)
    e = np.abs(1 - np.abs(res[0]["eq_out"]) ** 2)
    sm = np.convolve(e, np.ones(500) / 500, "valid")
    plt.semilogy(sm, label=f"mu={mu:g}")
    print(f"    mu={mu:g}: steady-state error {np.mean(e[-5000:]):.3f}, SNR {mean_res(res,'snr_db'):.2f} dB")
plt.xlabel("symbol index"); plt.ylabel("smoothed CMA error"); plt.legend(); plt.grid(alpha=.3)
plt.title("E4: CMA convergence vs step size"); plt.tight_layout()
plt.savefig(FIG + "capstone_E4_cma_convergence.png", dpi=110); plt.close()

# ---------------- E5: 64 GBd -----------------
print("\nE5  32 vs 64 GBd at the same OSNR (DP-16QAM, OSNR 22 dB)")
for Rs in [32e9, 64e9]:
    res, snr = run_link(M=16, Rs=Rs, osnr_db=22.0, verbose=False)
    print(f"    {Rs/1e9:.0f} GBd: channel SNR {snr:.2f} dB, measured {mean_res(res,'snr_db'):.2f} dB, "
          f"BER {mean_res(res,'ber'):.2e}")

# ---------------- SOP tracking study -----------------
print("\nSOP tracking (DP-QPSK, OSNR 16 dB, channel SNR 11.92 dB): SNR vs rotation speed and CMA mu")
rates = [1e4, 1e5, 1e6, 3e6, 1e7]
plt.figure(figsize=(6, 3.5))
for mu in [1e-3, 3e-3, 1e-2]:
    out = []
    for r_ in rates:
        res, _ = run_link(M=4, osnr_db=16.0, sop_rate_rad_s=r_, mu_cma=mu, verbose=False)
        out.append(mean_res(res, "snr_db"))
    print(f"    mu={mu:g}: " + ", ".join(f"{r_:.0e} rad/s -> {s:.2f} dB" for r_, s in zip(rates, out)))
    plt.semilogx(rates, out, "o-", label=f"mu={mu:g}")
plt.axhline(11.92, color="k", ls="--", lw=0.8)
plt.xlabel("SOP rotation speed (rad/s)"); plt.ylabel("SNR (dB)"); plt.legend(); plt.grid(alpha=.3)
plt.title("SOP tracking: faster rotation needs larger step size"); plt.tight_layout()
plt.savefig(FIG + "ch6_sop_tracking.png", dpi=110); plt.close()
print("\nfigures saved in ../figures/")
