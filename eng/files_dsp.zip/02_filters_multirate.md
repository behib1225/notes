# Chapter 2 — Digital Filters, Fast Convolution, Multirate Processing and Adaptive Filters

> **How to use this chapter.** Sections 2.1–2.6 are about fixed filters, 2.7 about changing the sample rate, and 2.8 about adaptive filters (the most important section for Chapters 6–7). Problems are rated ★ / ★★ / ★★★. Complex-gradient notation used in §2.8 is explained in `appendix_A_math_and_glossary.md` (A.2).

> **Learning objectives.** After this chapter you can (1) choose between FIR and IIR filters and explain why optical DSP is almost entirely FIR, (2) design FIR filters and read their frequency responses, (3) implement frequency-domain filtering with overlap-save and compute its complexity advantage, (4) change the sample rate by rational factors and apply fractional delays, and (5) derive and use the LMS adaptive filter — the ancestor of every equalizer in Chapters 6 and 7.

---

## 2.1 What a filter does, in words

A digital filter computes each output sample as a weighted combination of input samples (and, for IIR filters, of past outputs). An FIR (finite impulse response) filter is

$$y[n] = \sum_{k=0}^{N-1} h[k]\,x[n-k].$$

Think of it as a sliding "weighted average": a window of $N$ recent inputs, each multiplied by a tap weight $h[k]$, summed. In the frequency domain, the filter multiplies each frequency component by $H(e^{j\Omega}) = \sum_k h[k]e^{-j\Omega k}$: it changes the amplitude (magnitude response) and delays it (phase response).

In an optical transceiver, filters appear everywhere:

| Where | What the filter does |
|---|---|
| Transmitter | Pulse shaping (root-raised cosine), pre-emphasis of the DAC/driver/modulator bandwidth |
| Receiver front end | Anti-aliasing, matched filtering, resampling |
| CD compensation | An all-pass filter with a quadratic phase (thousands of taps) |
| Equalizer | Adaptive 2×2 MIMO FIR that undoes polarization rotation, PMD and residual ISI |
| Timing recovery | Interpolation filters that shift the signal by a fraction of a sample |

## 2.2 FIR versus IIR, and why optical DSP is (almost) all FIR

An IIR filter feeds back past outputs:

$$y[n] = \sum_{k=0}^{M} b_k x[n-k] - \sum_{k=1}^{P} a_k y[n-k].$$

IIR filters achieve sharp responses with few coefficients, but:

1. **Feedback kills parallelism.** A coherent ASIC processes, say, 128 samples in parallel per clock cycle, because the clock (~1 GHz) is much slower than the sample rate (>100 GSa/s). An FIR filter's outputs can all be computed independently and in parallel. An IIR output needs the previous output first — a sequential dependency that cannot keep up.
2. **FIR filters can have exactly linear phase** (symmetric taps), meaning all frequencies are delayed equally, so pulse shapes are preserved.
3. **FIR filters are always stable**, even when coefficients are adapted continuously.

IIR-like structures do appear in feedback *loops* that run at reduced rate (e.g. phase-locked loops in timing and carrier recovery), and decision-feedback equalizers (Chapter 7) have feedback that makes them hard to parallelize — which is exactly why they are used sparingly at high baud rates.

## 2.3 Linear phase and group delay

The group delay $\tau_g(\omega) = -\frac{d\,\angle H(e^{j\omega})}{d\omega}$ tells you how long a narrow band of frequencies around $\omega$ is delayed. If the phase is linear, $\angle H = -\omega D$, then $\tau_g = D$ for all frequencies — no distortion.

A real symmetric FIR of length $N$ ($h[k]=h[N-1-k]$) has linear phase with delay $(N-1)/2$ samples. That is why `optdsp.filter_same` (which trims `np.convolve(..., "same")`) gives zero net delay for symmetric filters like the RRC.

**Chromatic dispersion is the opposite**: its phase is *quadratic* in frequency, so its group delay is *linear* in frequency — different colours arrive at different times. The CD compensation filter has the opposite quadratic phase, which re-aligns them. We will build it in Section 2.6.

## 2.4 FIR design in practice

The most useful methods:

- **Window method** (`scipy.signal.firwin`): take the ideal (infinite, sinc-shaped) impulse response, truncate it and multiply by a window. The Kaiser window has a parameter β trading transition width for stopband attenuation.
- **Equiripple / Parks–McClellan** (`scipy.signal.remez`): minimises the maximum error; shortest filter for a given specification.
- **Least-squares** (`scipy.signal.firls`).
- **Frequency sampling**: specify $H$ on an FFT grid and inverse-FFT (then window). This is how CD and many "match this measured response" filters are built.

```python
import numpy as np
from scipy.signal import firwin, freqz
h = firwin(63, 0.25, window=("kaiser", 8.0))     # cutoff at 0.25 x Nyquist
w, H = freqz(h, worN=4096)
HdB = 20*np.log10(abs(H) + 1e-12)
print("worst stopband level beyond 0.35*pi rad/sample: %.1f dB" % HdB[w > 0.35*np.pi].max())
# about -81 dB with this Kaiser design
```

![Frequency response of a Kaiser-window low-pass FIR](figures/ch2_fir_response.png)

*Figure 2.1 — Magnitude response of the 63-tap Kaiser design above: flat passband, a transition band, and stopband sidelobes below −80 dB.*

**Trade-off to internalise:** length ↔ transition sharpness ↔ stopband attenuation. Halving the transition width roughly doubles the number of taps.

## 2.5 Fast convolution: overlap-save

A direct FIR costs $N$ complex multiplications per output sample. For CD compensation over 1000 km at 64 GBd, $N$ can exceed 2000 — far too expensive. The fix is to filter in the frequency domain, where convolution becomes multiplication.

### The idea in words
Chop the input into overlapping blocks of length $N_{FFT}$. Each block overlaps the previous one by $N-1$ samples (the filter memory). FFT the block, multiply by the filter's frequency response, inverse FFT. The first $N-1$ outputs of each block are corrupted by circular wrap-around (Chapter 1.5), so **throw them away** ("save" the rest). The kept $N_{FFT}-N+1$ outputs are exactly the linear convolution.

```python
def overlap_save(x, h, nfft):
    L = len(h); step = nfft - (L - 1)
    H = np.fft.fft(h, nfft)
    xp = np.concatenate([np.zeros(L - 1, complex), x, np.zeros(nfft, complex)])
    out = []
    for start in range(0, len(x), step):
        yb = np.fft.ifft(np.fft.fft(xp[start:start + nfft]) * H)
        out.append(yb[L - 1:])                 # discard the circularly aliased part
    return np.concatenate(out)[:len(x)]
```

(Full tested version in `code/solutions_extra.py`; it matches `np.convolve` to within $10^{-14}$.)

### Complexity
An $N_{FFT}$-point FFT costs about $\frac{N_{FFT}}{2}\log_2 N_{FFT}$ complex multiplications. Per block we do one FFT, one IFFT and $N_{FFT}$ multiplications by $H$, and we get $N_{FFT}-N+1$ outputs:

$$C_{FD} \approx \frac{N_{FFT}\log_2 N_{FFT} + N_{FFT}}{N_{FFT}-N+1}\ \text{mult./sample}, \qquad C_{TD} = N.$$

| CD taps $N$ | Direct (TD) | Best overlap-save (FD) |
|---|---|---|
| 55 (100 km, 32 GBd) | 55 | ≈ 11 ($N_{FFT}$=256) |
| 559 (1000 km, 32 GBd) | 559 | ≈ 15 ($N_{FFT}$=4096) |
| 2233 (1000 km, 64 GBd) | 2233 | ≈ 17 ($N_{FFT}$=16384) |

(Values computed with the formula above.) This is why essentially **all commercial coherent DSPs compensate CD in the frequency domain** (often merged with matched filtering and other static corrections in the same FFT engine). Choose $N_{FFT}$ several times larger than $N$ so the discarded overlap is a small fraction.

Overlap-add is the dual method (non-overlapping input blocks, overlapping output tails added together); the complexity is the same.

## 2.6 Designing the CD compensation filter

Chapter 5 derives the fiber's CD response $H_{CD}(\omega)=\exp(-j\beta_2 L\omega^2/2)$. The compensator is simply $G(\omega) = H_{CD}^*(\omega) = \exp(+j\beta_2 L\omega^2/2)$ — an all-pass filter, since $|G|=1$.

- **Frequency domain:** evaluate $G$ on the `fftfreq` grid and use overlap-save. This is essentially exact.
- **Time domain:** Savory (2008) derived a closed-form FIR by inverse-transforming the quadratic phase and truncating it to the length of the dispersion-induced spread:

$$N = 2\left\lfloor \frac{|D|\lambda^2 L}{2cT_s^2}\right\rfloor + 1,$$

where $D$ is the dispersion parameter (s/m²), $L$ the length, $T_s$ the sample period. **Intuition:** the dispersed pulse is spread over a time $\Delta\tau = |D|L\Delta\lambda$ with $\Delta\lambda = \lambda^2 f_s/c$; the filter must span that time, i.e. $\Delta\tau/T_s$ taps.

The taps (in this tutorial's sign convention; see `cd_fir_taps` in `code/solutions_extra.py`) are

$$g[k] = \sqrt{\frac{-jcT_s^2}{D\lambda^2L}}\exp\!\left(+j\frac{\pi c T_s^2}{D\lambda^2 L}k^2\right),\quad -\tfrac{N-1}{2}\le k\le\tfrac{N-1}{2}.$$

> **Sign warning.** This is the complex conjugate of the formula as printed in Savory's paper, because that paper uses the opposite Fourier/field sign convention. Our code verifies the sign numerically: with the correct sign the SNR after compensating 200 km is ≈ 22.6 dB (limited by truncation of the 111-tap filter); with the wrong sign it is ≈ −17 dB. **Always check signs by simulation.**

The truncated time-domain filter is not perfect because the true impulse response is infinitely long and the truncation causes spectral ripple and aliasing. The frequency-domain filter avoids this, another reason it is preferred.

## 2.7 Multirate processing

### Decimation and interpolation
- **Decimation by $D$** keeps every $D$th sample. First low-pass filter to $|f|<f_s/(2D)$, or aliasing occurs.
- **Interpolation by $U$** inserts $U-1$ zeros between samples (creating spectral images) and then low-pass filters to remove the images.
- **Rational resampling by $U/D$** combines both: interpolate by $U$, filter once, decimate by $D$.

### Polyphase implementation
Computing outputs that will be discarded is wasteful. A polyphase structure splits the filter into $U$ (or $D$) sub-filters so that only needed outputs are computed. `scipy.signal.resample_poly(x, up, down)` does exactly this.

### Why optical DSP needs it
The ADC in a commercial coherent receiver samples at a fractional rate such as ~1.25 sps, while many DSP algorithms (timing error detectors, the butterfly equalizer) prefer 2 sps or 1 sps. Resampling bridges them.

```python
from scipy.signal import resample_poly
import sys; sys.path.append("code"); import optdsp as od
rng = np.random.default_rng(0)
s  = od.bits_to_symbols(rng.integers(0, 2, 2*20000), 4)
x8 = od.filter_same(od.upsample(s, 8), od.rrc_taps(0.1, 8, 64))   # "analog" at 8 sps
x125 = resample_poly(x8, 5, 32)        # ADC at 1.25 sps  (8 * 5/32 = 1.25)
x2   = resample_poly(x125, 8, 5)       # DSP resamples to 2 sps (1.25 * 8/5 = 2)
y = od.filter_same(x2, od.rrc_taps(0.1, 2, 64))[::2]
print("SNR after 1.25 -> 2 sps: %.1f dB" % od.snr_estimate_db(y[200:-200], s[200:-200]))   # ~55 dB
```

The ~55 dB result shows that 1.25 sps loses essentially nothing for β = 0.1: the signal's width is $1.1R_s < 1.25R_s$.

### Fractional delay
Timing recovery must shift the signal by a *fraction* of a sample, continuously. Two standard ways:

1. **Frequency domain:** multiply the FFT by $e^{-j2\pi f\tau}$. Exact for signals that are periodic in the block; otherwise edge effects appear (a good exercise: try it on a tone that does not complete an integer number of cycles).
2. **Farrow structure:** a polynomial (e.g. cubic Lagrange) interpolator whose coefficients are fixed FIR filters, and whose output is a polynomial in the fractional delay $\mu\in[0,1)$. Changing $\mu$ costs nothing extra — ideal for a tracking loop.

```python
def lagrange_cubic(x, mu):
    """Interpolate between x[n] and x[n+1] at fractional position mu (0<=mu<1)."""
    xm1, x0, x1, x2 = x[:-3], x[1:-2], x[2:-1], x[3:]
    c0 = x0
    c1 = -xm1/3 - x0/2 + x1 - x2/6
    c2 =  xm1/2 - x0   + x1/2
    c3 = -xm1/6 + x0/2 - x1/2 + x2/6
    return ((c3*mu + c2)*mu + c1)*mu + c0     # Horner form = Farrow structure
```

For a cosine at 0.05 cycles/sample, the error is about $2\times10^{-4}$. Accuracy degrades as the signal approaches Nyquist, which is one reason receivers oversample slightly.

## 2.8 Adaptive filters: the Wiener solution and LMS

An optical channel changes: polarization can rotate at kilo- to mega-radians per second during mechanical disturbances, and components drift. The receiver cannot use fixed filters; it must *learn* them. This section derives the fundamental algorithm.

### The Wiener filter
We want filter taps $\mathbf{w}$ (a column vector) such that the output $y[n]=\mathbf{w}^H\mathbf{x}[n]$ is as close as possible to a desired signal $d[n]$ (e.g. the transmitted symbol), where $\mathbf{x}[n]=[x[n],x[n-1],\dots,x[n-N+1]]^T$. Minimise the mean-squared error

$$J(\mathbf{w}) = \mathbb{E}\{|d[n]-\mathbf{w}^H\mathbf{x}[n]|^2\} = \sigma_d^2 - \mathbf{w}^H\mathbf{p} - \mathbf{p}^H\mathbf{w} + \mathbf{w}^H\mathbf{R}\mathbf{w},$$

with $\mathbf{R}=\mathbb{E}\{\mathbf{x}\mathbf{x}^H\}$ (input autocorrelation matrix) and $\mathbf{p}=\mathbb{E}\{\mathbf{x}d^*\}$ (cross-correlation). $J$ is a quadratic "bowl" in $\mathbf{w}$; setting the gradient to zero gives the **Wiener–Hopf equation**

$$\mathbf{R}\,\mathbf{w}_{opt} = \mathbf{p} \quad\Rightarrow\quad \mathbf{w}_{opt}=\mathbf{R}^{-1}\mathbf{p}.$$

### LMS: walking down the bowl one sample at a time
We don't know $\mathbf{R}$ and $\mathbf{p}$, and inverting matrices in real time is costly. Instead, take small steps down the gradient, $\nabla_{\mathbf{w}^*}J = -\mathbf{p}+\mathbf{R}\mathbf{w}$, and replace the expectations by their instantaneous values ($\mathbf{x}d^*$ and $\mathbf{x}\mathbf{x}^H$). With error $e[n]=d[n]-y[n]$:

$$\boxed{\mathbf{w}[n+1] = \mathbf{w}[n] + \mu\, e^*[n]\,\mathbf{x}[n]}$$

This is the **least-mean-squares (LMS)** algorithm (Widrow and Hoff, 1960). Each update costs about $2N$ multiplications.

*Convention note:* with output $y=\mathbf{w}^H\mathbf{x}$ the update uses $e^*\mathbf{x}$. Many optical-DSP papers (and our code) write the output as $y = \sum h[k]x[n-k]$ without conjugating the taps; then the update becomes $\mathbf{h}\leftarrow\mathbf{h}+\mu\,e\,\mathbf{x}^*$. The two are the same algorithm with $\mathbf{h}=\mathbf{w}^*$.

### Step size: the central trade-off
- **Too large: the error variance grows without bound.** Two different stability notions exist, and beginners mix them up:
  - *Convergence of the mean* of the taps needs $0<\mu<2/\lambda_{max}(\mathbf{R})$. This is necessary but **not sufficient**: the average tap vector can converge while the error variance explodes.
  - *Mean-square stability* (bounded error variance) is the condition that matters. For white, real Gaussian input of power $P_x$ and $N$ taps it is exactly $\mu < \dfrac{2}{(N+2)P_x}$ (Feuer & Weinstein, 1985). A common rule of thumb for any input is $\mu \ll 2/(N P_x) = 2/\mathrm{tr}(\mathbf{R})$.
- **Large (but stable): fast convergence and fast tracking, but the taps "jitter" around the optimum**, adding **excess mean-squared error**. For the same white Gaussian case the misadjustment (excess MSE divided by the minimum MSE) is
$$\mathcal{M} = \frac{\mu N P_x/2}{1-\mu(N+2)P_x/2}\ \approx\ \frac{\mu N P_x}{2}\quad(\text{small }\mu),$$
  which grows without bound as μ approaches the stability limit.
- **Normalized LMS (NLMS)** divides the step by the current input energy, $\mu/(\epsilon+\|\mathbf{x}\|^2)$, which makes the step size independent of signal power; it is the usual practical choice when the input level is not controlled.
- Small: low excess error but slow convergence and poor tracking of fast polarization changes.

This trade-off reappears in every adaptive block in the receiver.

### Worked example: system identification

```python
rng = np.random.default_rng(0)
h_true = np.array([0.1, -0.3, 1.0, 0.5, -0.2])
x = rng.standard_normal(20000)
d = np.convolve(x, h_true)[:len(x)] + 0.01*rng.standard_normal(len(x))
N, mu = 5, 0.01
w = np.zeros(N)
for n in range(N, len(x)):
    xv = x[n-N+1:n+1][::-1]        # [x[n], x[n-1], ..., x[n-N+1]]
    e = d[n] - w @ xv
    w += mu * e * xv
print(np.round(w, 3))              # [ 0.099 -0.301  1.     0.499 -0.199]
```

### Blind adaptation
In a receiver we often *don't* know $d[n]$. Options: (1) a **training sequence** (known pilots), (2) **decision-directed** mode ($d[n]$ = the nearest constellation point, works once errors are rare), or (3) a **blind cost function** that uses only a known property of the signal, such as constant modulus. The constant modulus algorithm (CMA) in Chapter 6 is option 3.

## 2.9 Common pitfalls

1. Using `np.convolve(x, h, "same")` with an asymmetric filter and forgetting it introduces a delay.
2. Forgetting to discard the first $N-1$ samples of each overlap-save block.
3. Decimating without a low-pass filter.
4. Choosing an LMS step size without normalising the input power (always normalise the signal first!).
5. Copying a formula from a paper without checking its sign convention.

## 2.10 Check your understanding

1. Why can't a 1 GHz ASIC run a sample-by-sample IIR filter on a 128 GSa/s signal?
2. An overlap-save block has $N_{FFT}=1024$ and the filter has 257 taps. How many valid outputs per block?
3. Why does interpolation create spectral images?
4. In LMS, what happens to convergence speed and steady-state error if you double μ?

<details><summary>Answers</summary>

1. Each output depends on the previous output, which must be computed within one sample period (~8 ps). Hardware processes many samples in parallel per clock cycle; feedback prevents that.
2. $1024 - 257 + 1 = 768$.
3. Inserting zeros compresses the spectrum's period: the original spectrum repeats $U$ times within the new $[-f_s'/2,f_s'/2)$. The extra copies are images, removed by the low-pass filter.
4. Converges about twice as fast (and tracks faster), but the excess MSE (misadjustment) roughly doubles; too large a μ causes divergence.
</details>

## 2.11 Problems

### Problem 2.1 ★ — Linear phase
Show that a real FIR with symmetric taps $h[k]=h[N-1-k]$ has a frequency response $H(e^{j\omega}) = e^{-j\omega(N-1)/2}A(\omega)$ with $A$ real. What is the group delay?

<details><summary>Solution</summary>

Pair each tap with its mirror (take $N$ odd, $M=(N-1)/2$): $H = \sum_k h[k]e^{-j\omega k} = e^{-j\omega M}\left[h[M] + \sum_{m=1}^{M} h[M-m](e^{j\omega m}+e^{-j\omega m})\right] = e^{-j\omega M}\left[h[M]+2\sum_{m=1}^{M} h[M-m]\cos(\omega m)\right]$. The bracket is real. The phase is $-\omega M$ (plus jumps of π where $A<0$), so the group delay is $M=(N-1)/2$ samples at all frequencies. For even $N$ the same argument works with half-integer delay.
</details>

### Problem 2.2 ★★ — CD filter sizing
(a) Compute the number of time-domain taps needed to compensate 80 km, 2000 km and 6000 km of SSMF ($D$ = 17 ps/(nm·km), λ = 1550 nm) for a 96 GBd signal sampled at 2 sps. (b) For the 6000 km case, estimate the overlap-save cost per sample with $N_{FFT}=2^{17}$ and compare.

<details><summary>Solution</summary>

$N \approx |D|\lambda^2 L f_s^2 / c$ (+1). With $|D|\lambda^2/c = 17\times10^{-6}\cdot(1.55\times10^{-6})^2/3\times10^8 = 1.361\times10^{-25}$ s²/m, and $f_s = 192$ GHz, $f_s^2=3.686\times10^{22}$:
- 80 km: $1.361\text{e-}25\times 8\text{e}4\times 3.686\text{e}22 \approx 401$ taps.
- 2000 km: ≈ 10,045 taps.
- 6000 km: ≈ 30,133 taps.

(b) $C_{FD} = (2^{17}\cdot 17 + 2^{17})/(2^{17} - 30133 + 1) = 18\cdot 131072/100940 \approx 23$ multiplications per sample versus ~30,000. The frequency domain wins by three orders of magnitude.
</details>

### Problem 2.3 ★★ — Implement and verify overlap-add (coding)
Write `overlap_add(x, h, nfft)` and verify it against `np.convolve`. Then filter a 10⁶-sample signal with a 2001-tap filter using both overlap-add and direct convolution, and time them.

<details><summary>Solution</summary>

```python
import numpy as np, time
def overlap_add(x, h, nfft):
    L = len(h); step = nfft - L + 1
    H = np.fft.fft(h, nfft)
    y = np.zeros(len(x) + nfft, complex)
    for start in range(0, len(x), step):
        blk = x[start:start+step]
        yb = np.fft.ifft(np.fft.fft(blk, nfft) * H)   # zero-padded block: no wrap-around
        y[start:start+nfft] += yb                      # overlapping tails add up
    return y[:len(x) + L - 1]

x = np.random.randn(10**6) + 1j*np.random.randn(10**6)
h = np.random.randn(2001)
t = time.time(); y1 = overlap_add(x, h, 16384); t1 = time.time() - t
t = time.time(); y2 = np.convolve(x, h);        t2 = time.time() - t
print("max err", np.max(abs(y1 - y2)), " OLA %.2fs, direct %.2fs" % (t1, t2))
```
Typically overlap-add is 10–50× faster here (exact ratio depends on your machine and NumPy build). Key insight: because each input block is zero-padded to $N_{FFT}\ge$ step $+L-1$, its circular convolution equals its linear convolution, and the tails simply add.
</details>

### Problem 2.4 ★★ — LMS step-size experiment (coding)
Using the system-identification example, plot the squared error (smoothed) versus iteration for μ = 0.001, 0.01, 0.05 and 0.3. Explain the results using Section 2.8. Estimate the stability limit.

<details><summary>Solution</summary>

```python
import numpy as np, matplotlib.pyplot as plt
rng = np.random.default_rng(0)
h_true = np.array([0.1, -0.3, 1.0, 0.5, -0.2]); N = 5
x = rng.standard_normal(20000)
d = np.convolve(x, h_true)[:len(x)] + 0.01*rng.standard_normal(len(x))
for mu in [0.001, 0.01, 0.05, 0.3]:
    w = np.zeros(N); err = []
    for n in range(N, len(x)):
        xv = x[n-N+1:n+1][::-1]; e = d[n] - w @ xv; w += mu*e*xv; err.append(e**2)
        if not np.isfinite(e) or abs(e) > 1e6: break
    plt.semilogy(np.convolve(err, np.ones(200)/200, "valid"), label=f"mu={mu}")
plt.legend(); plt.xlabel("iteration"); plt.ylabel("smoothed e^2"); plt.show()
```
![LMS convergence for four step sizes](figures/ch2_lms_convergence.png)

*Figure 2.2 — Smoothed squared error of the LMS system-identification example.*

Here $N=5$, $P_x=1$ (white Gaussian), minimum MSE $=10^{-4}$ (the added noise).

| μ | predicted steady-state MSE $(1+\mathcal{M})\cdot10^{-4}$ | observed | comment |
|---|---|---|---|
| 0.001 | 1.003e-4 | ≈1.1e-4 (still converging) | slow: thousands of iterations |
| 0.01 | 1.03e-4 | ≈1.1e-4 | fast and accurate |
| 0.05 | 1.15e-4 | ≈1.2e-4 | faster, slightly more excess error |
| 0.3 | unstable | ≈0.2, bursty | just above the limit 2/((N+2)P_x) = 0.286 |
| 0.45 | unstable | diverges within a few hundred iterations | |

The theory predicts the observations well. Note that the *mean*-convergence condition ($\mu<2/\lambda_{max}=2$) would wrongly suggest μ = 0.45 is fine: the mean-square condition is the one that matters.
</details>

### Problem 2.5 ★★ — Fractional delay by FFT (coding)
Delay a tone by 0.3 samples using the FFT method, for $N=256$ and tone frequencies 10/256 and 12.8/256 cycles/sample. Compare the errors and explain.

<details><summary>Solution</summary>

```python
N = 256; t = np.arange(N); f = np.fft.fftfreq(N)
for f0 in [10/256, 12.8/256]:
    x = np.exp(2j*np.pi*f0*t)
    y = np.fft.ifft(np.fft.fft(x) * np.exp(-2j*np.pi*f*0.3))
    print(f0*256, np.max(abs(y - np.exp(2j*np.pi*f0*(t - 0.3)))))
```
For 10 cycles per block the error is ~1e-15: the tone is periodic in the block, so the DFT represents it exactly. For 12.8 cycles the error is ~0.3: the block has a discontinuity at its edges; the DFT treats the signal as periodic, and the delay "wraps" the discontinuity, spreading error. In practice, apply FFT-based delays with overlap-save (discarding edges) or use a Farrow interpolator.
</details>

### Problem 2.6 ★★★ — Design: choosing a CD-compensation architecture
A 130 GBd coherent receiver samples at 2 sps and must handle up to 3000 km of SSMF. (a) How many time-domain taps would be needed? (b) Choose an overlap-save FFT size that minimises multiplications per sample, considering $N_{FFT}\in\{2^{12},\dots,2^{17}\}$. (c) Besides multiplications, name two practical reasons a designer might choose a *smaller* FFT than the optimum from (b).

<details><summary>Solution</summary>

(a) $N \approx |D|\lambda^2 L f_s^2/c = 1.361\times10^{-25}\cdot3\times10^6\cdot(260\times10^9)^2 \approx 27{,}600$ taps.

(b) $C_{FD}=(N_{FFT}\log_2N_{FFT}+N_{FFT})/(N_{FFT}-N+1)$ is undefined for $N_{FFT}<N$. For $2^{15}=32{,}768$: $(32768\cdot16)/5{,}169\approx101$; $2^{16}$: $65536\cdot17/37{,}937\approx29.4$; $2^{17}$: $131072\cdot18/103{,}473\approx22.8$. So $2^{17}$ (≈23 multiplications/sample, versus ≈27,600 in the time domain); $2^{18}$ would be only slightly better (≈21).

(c) (1) **Latency and memory**: a $2^{17}$-point block must be buffered (≈0.5 µs at 260 GSa/s) and the FFT memory is large in silicon. (2) **Parallel hardware**: the FFT must be unrolled to process hundreds of samples per clock; very large FFTs are hard to pipeline. (3) **Adaptivity**: some designs merge CD compensation with an adaptive frequency-domain equalizer whose update rate is set by the block size — smaller blocks track faster. Real designs therefore often use a few thousand points and accept slightly more multiplications, or split long CD across stages.
</details>

---

## Key takeaways

- Optical DSP is almost entirely **FIR**: parallelisable, always stable, and linear-phase when symmetric.
- **Overlap-save** turns an $N$-tap filter into ~$\log_2 N_{FFT}$ multiplications per sample; CD compensation is always done this way.
- **Signs and conventions**: a formula copied from a paper may need conjugating; verify numerically.
- **Multirate** tools (polyphase resampling, Farrow/sinc interpolation) connect fractional-rate ADCs to algorithms that want 1 or 2 sps.
- **LMS** $\mathbf{w}\leftarrow\mathbf{w}+\mu e^*\mathbf{x}$ is the ancestor of every equalizer. The step size trades convergence/tracking speed against excess error; mean-square stability, not mean convergence, sets the limit.

---

**Next:** Chapter 3 gives you the statistical tools — noise, power spectral density, SNR and OSNR — needed to predict how well all these filters will work.
