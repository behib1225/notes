# Chapter 8 — FEC, Soft Information, GMI, Probabilistic Shaping, Nonlinearity Compensation and Implementation

> **How to use this chapter.** §8.1–8.5 are about turning noisy symbols into reliable bits and measuring how well that can work (GMI); §8.6 shaping; §8.7 nonlinearity; §8.9–8.10 the path from algorithm to silicon. Problems are rated ★ / ★★ / ★★★. Entropy and mutual information are reviewed in `appendix_A_math_and_glossary.md` (A.4).

> **Learning objectives.** After this chapter you can (1) explain how forward error correction turns a noisy channel into an error-free one, (2) compute log-likelihood ratios (LLRs) for QAM and explain why soft decisions matter, (3) evaluate a system with MI, GMI, NGMI and achievable information rate as industry does, (4) explain probabilistic constellation shaping and compute its rate, (5) explain digital back-propagation and the realistic value of nonlinearity compensation, and (6) appreciate the constraints of real DSP ASIC implementation.

---

## 8.1 Why FEC is the silent hero

Without FEC, a link needs a BER below ~10⁻¹² to 10⁻¹⁵ — requiring many dB more SNR than a link with FEC. With a modern soft-decision FEC, the receiver can operate at a **pre-FEC** BER of ~10⁻² and still deliver essentially error-free output. That difference — the **net coding gain**, often 10–12 dB — is larger than almost any other improvement in the system. Every DSP block you studied in Chapter 6 exists to hand the FEC decoder the best possible input.

Key vocabulary:
- **Code rate** $R_c = k/n$: $k$ information bits in each $n$-bit codeword. **Overhead** $= n/k-1$ (e.g. $R_c=0.8$ → 25% overhead).
- **Threshold**: the pre-FEC BER (or GMI/NGMI) at which the decoder output reaches the target (e.g. < 10⁻¹⁵).
- **Hard-decision (HD)** decoders receive bits; **soft-decision (SD)** decoders receive reliabilities (LLRs).
- **Net coding gain (NCG)**: the reduction in required $E_b/N_0$ (accounting for the rate loss) relative to uncoded transmission at the target BER.

## 8.2 A tiny code to build intuition: Hamming(7,4)

The Hamming(7,4) code adds 3 parity bits to 4 data bits so that every pair of codewords differs in at least 3 positions (minimum distance $d_{min}=3$). It can correct any single bit error.

**Hard decoding**: decide each bit, compute the syndrome $\mathbf{s}=\mathbf{H}\hat{\mathbf{c}}^T$; if it is non-zero, it identifies which bit to flip.

**Soft (maximum-likelihood) decoding**: compare the received *analog* values with all 16 codewords and pick the closest (for BPSK, the highest correlation). It uses the information "this bit was barely negative" that hard decoding throws away.

Our simulation (`code/ch8_fec_shaping.py`, BPSK in AWGN, $E_b/N_0$ counted per information bit):

| $E_b/N_0$ | uncoded BER | Hamming hard | Hamming soft (ML) |
|---|---|---|---|
| 4 dB | 1.3×10⁻² | 1.6×10⁻² | 5.3×10⁻³ |
| 6 dB | 2.4×10⁻³ | 2.2×10⁻³ | 3.5×10⁻⁴ |
| 8 dB | 2.3×10⁻⁴ | 8.3×10⁻⁵ | 2.5×10⁻⁶ |

Two lessons that generalise to every code: (1) **soft decoding gains about 2 dB** over hard decoding; (2) at low SNR a weak hard-decision code can be *worse* than no code, because the rate loss (4/7 of the energy per coded bit) outweighs its correction power. Modern codes are much longer and stronger, but these trends persist.

## 8.3 Log-likelihood ratios

For each bit $b_i$ of a symbol, the decoder wants

$$L_i = \ln\frac{P(b_i=0\mid y)}{P(b_i=1\mid y)} = \ln\frac{\sum_{a\in\mathcal{X}_i^0}e^{-|y-a|^2/N_0}}{\sum_{a\in\mathcal{X}_i^1}e^{-|y-a|^2/N_0}}$$

(assuming equiprobable symbols and Gaussian noise), where $\mathcal{X}_i^b$ is the set of constellation points whose $i$-th bit equals $b$. Sign = hard decision; magnitude = confidence.

**Max-log approximation** (used in hardware): $\ln\sum e^{x_j}\approx\max_j x_j$, so

$$L_i\approx\frac{1}{N_0}\left(\min_{a\in\mathcal{X}_i^1}|y-a|^2-\min_{a\in\mathcal{X}_i^0}|y-a|^2\right).$$

For Gray-coded QPSK the LLRs are exactly linear: $L_{I}=\frac{2\sqrt2}{N_0}\,\mathrm{Re}\{y\}$ (for $E_s=1$, with bit 0 mapped to positive I). `od.gmi_awgn` computes exact LLRs.

**Important:** LLRs are only as good as the noise model. If the DSP leaves non-Gaussian distortion (residual phase noise, nonlinear interference), mismatched LLRs cost performance — one reason the DSP's job is to make the residual noise as "AWGN-like" as possible.

## 8.4 FEC in optical communications

| Code family | Decoding | Typical use |
|---|---|---|
| Reed–Solomon, e.g. RS(255,239) (~6.7% OH) | hard | legacy OTN (ITU-T G.709) |
| "KP4" RS(544,514) (~5.8% OH) | hard | 100G/lane Ethernet IM/DD; threshold ≈ 2.4×10⁻⁴ |
| Staircase codes | hard (iterative) | high-throughput HD-FEC |
| CFEC (staircase outer + Hamming inner soft) (~14.8% OH) | soft inner | OIF 400ZR; threshold ≈ 1.22×10⁻² |
| oFEC (~15.3% OH) | soft (iterative, block-based) | OpenZR+, 800ZR; threshold ≈ 2.0×10⁻² |
| LDPC (often with an outer HD code), 15–27% OH | soft (iterative) | proprietary long-haul/submarine transceivers |
| "Classic" 7% HD-FEC benchmark | hard | the often-quoted threshold 3.8×10⁻³ |

Threshold values above are the commonly quoted pre-FEC BERs for a Gaussian channel; the specific standards documents define the exact codes and targets. Two engineering observations:

1. **Concatenation** is ubiquitous: a strong inner soft-decision code brings the BER down to ~10⁻⁵, and an outer hard-decision code "cleans up" the error floor cheaply.
2. **Pre-FEC BER is an imperfect predictor** for soft-decision codes, because two channels with the same BER can have different LLR distributions. That motivates information-theoretic metrics.

## 8.4b A real soft-decision code: LDPC with min-sum decoding

Hamming(7,4) shows the principle; modern optical FEC uses long **low-density parity-check (LDPC)** codes (often concatenated with an outer hard-decision code). `code/ch8_ldpc.py` builds one from scratch so you can see every step.

**The code.** A parity-check matrix $\mathbf{H}$ ($m\times n$) with very few ones: here each of the $n=1008$ bits takes part in 3 checks and each of the $m=504$ checks involves 6 bits (a "(3,6)-regular" code, rate $1-m/n=1/2$). A word $\mathbf{c}$ is a codeword if $\mathbf{H}\mathbf{c}^T=\mathbf{0}$ (every check has even parity). Draw it as a bipartite **Tanner graph**: variable nodes (bits) on one side, check nodes on the other, an edge for every 1 in $\mathbf{H}$.

**Encoding.** Gaussian elimination over GF(2) brings $\mathbf{H}$ to the form $[\mathbf{A}\,|\,\mathbf{I}]$ (after reordering columns); the parity bits are then $\mathbf{p}=\mathbf{A}\mathbf{u}$ for data bits $\mathbf{u}$. The script verifies $\mathbf{H}\mathbf{c}^T=\mathbf{0}$ for random data.

**Decoding by message passing (min-sum).** Each bit starts with its channel LLR $L_i$. Then iterate:
1. *Variable → check*: each bit tells each of its checks "my belief, excluding what you told me": $q_{i\to j}=L_i+\sum_{j'\ne j}r_{j'\to i}$.
2. *Check → variable*: each check tells each bit "given the other bits in my equation, here is what you should be": $r_{j\to i}=\alpha\prod_{i'\ne i}\mathrm{sign}(q_{i'\to j})\cdot\min_{i'\ne i}|q_{i'\to j}|$ (the exact rule uses a tanh product; the min is the standard hardware approximation and α ≈ 0.75 corrects its overconfidence).
3. *Decide*: total belief $L_i+\sum_j r_{j\to i}$; stop when all checks are satisfied.

```python
q = (total[:, ve] - r).reshape(B, m, dc)            # variable -> check (extrinsic)
sgn = np.where(q < 0, -1.0, 1.0); mag = np.abs(q)
srt = np.sort(mag, axis=2); min1, min2 = srt[:, :, :1], srt[:, :, 1:2]
r = alpha * np.prod(sgn, 2, keepdims=True) * sgn * np.where(mag == min1, min2, min1)
```

**Results** (BPSK in AWGN, 200,000 information bits per point):

| Eb/N0 (dB) | uncoded BER | pre-FEC BER | post-FEC BER | average iterations |
|---|---|---|---|---|
| 0.5 | 6.7e-2 | 1.45e-1 | 1.1e-1 | 50 (max) |
| 1.0 | 5.6e-2 | 1.31e-1 | 6.4e-2 | 50 |
| 1.5 | 4.6e-2 | 1.16e-1 | 1.7e-2 | 50 |
| 2.0 | 3.8e-2 | 1.04e-1 | 9.5e-4 | 42 |
| 2.5 | 3.0e-2 | 9.1e-2 | 0 errors | 15 |

![LDPC waterfall](figures/ch8_ldpc_waterfall.png)

*Figure 8.1 — The "waterfall": within about 1 dB, the decoded BER falls from useless to error-free. This short code sits about 2 dB from the Shannon limit of a rate-½ binary-input channel (0.19 dB); long optimised codes used in transceivers get within a few tenths of a dB.*

Three lessons: (1) a soft-decision code works with a **pre-FEC BER of ~10%** at rate ½ — compare the ~2% thresholds of the ~15%-overhead codes in §8.4: more overhead buys tolerance of worse channels; (2) the transition is abrupt, which is why system margins are specified relative to a threshold; (3) the decoder does *less* work on good channels (15 iterations at 2.5 dB versus the 50-iteration maximum near threshold) — decoder power depends on the operating point.

## 8.5 Mutual information, GMI, NGMI and achievable information rate

### Mutual information (MI)
$I(X;Y)$ is the maximum number of bits per symbol that can be reliably transmitted with a given input distribution, using an ideal decoder that looks at whole symbols. For uniform $M$-QAM it is at most $\log_2M$.

### Generalized mutual information (GMI)
Practical transceivers use **bit-interleaved coded modulation (BICM)**: the decoder works on bit LLRs, ignoring dependencies between bits of the same symbol. The achievable rate for this receiver is the GMI (Alvarado, Agrell and others established it as the right metric for optical systems):

$$\text{GMI} = \sum_{i=1}^{m}I(B_i;Y) \approx m - \frac{1}{N}\sum_{k=1}^N\sum_{i=1}^m\log_2\left(1+e^{-(-1)^{b_{k,i}}L_{k,i}}\right)$$

for uniform signalling, where $m=\log_2M$. The right-hand side is computed directly from transmitted bits and the receiver's LLRs — no FEC decoder needed. That is what `od.gmi_awgn` implements. **GMI ≤ MI**, with a small gap for Gray labelling.

### NGMI
$\text{NGMI}=\text{GMI}/m$ (for uniform signalling) — the GMI per bit. A given SD-FEC works if the NGMI exceeds its threshold. A code of rate $R_c$ can never work below NGMI = $R_c$, and practical codes need a little more; for example, BER = 2×10⁻² (the commonly quoted oFEC threshold, ≈15% overhead, $R_c\approx0.87$) corresponds to NGMI ≈ 0.92 for Gray-coded QPSK and 16-QAM in AWGN. The exact threshold is a property of each code. NGMI thresholds are more robust than BER thresholds across different channels and formats.

### Numbers to know (from `code/ch8_fec_shaping.py`, per polarization, bits per 2D symbol)

| SNR (dB) | Shannon | QPSK GMI | 16-QAM GMI | 64-QAM GMI |
|---|---|---|---|---|
| 0 | 1.00 | 0.97 | 0.92 | 0.86 |
| 5 | 2.06 | 1.72 | 1.93 | 1.80 |
| 10 | 3.46 | 1.99 | 3.16 | 3.16 |
| 15 | 5.03 | 2.00 | 3.93 | 4.68 |
| 20 | 6.66 | 2.00 | 4.00 | 5.81 |
| 25 | 8.31 | 2.00 | 4.00 | 6.00 |

Observe: each format tracks Shannon until it saturates at $\log_2M$; the gap to Shannon for a uniform square constellation is about 1.5 dB at medium SNR; and a *higher-order* format is not automatically better at low SNR (64-QAM's GMI at 5 dB is below 16-QAM's because bit-wise decoding of the densely packed labels loses information).

### Achievable information rate and net rate
A system's net bit rate is bounded by $R_{net}\le 2\cdot R_s\cdot\text{GMI}$ (dual polarization). Real FEC decoders fall short of this bound by a small "implementation gap" (for good modern codes, a few percent). System engineers therefore specify performance as "GMI (or SNR) margin above the FEC threshold".

## 8.6 Probabilistic constellation shaping (PCS)

### The idea
Shannon's capacity is achieved by a **Gaussian** input distribution. Uniform QAM puts equal probability on the high-energy outer points and the low-energy inner points, which wastes energy. **Probabilistic shaping** transmits low-energy points more often, following a **Maxwell–Boltzmann (MB)** distribution:

$$P(a) = \frac{e^{-\lambda|a|^2}}{\sum_{a'}e^{-\lambda|a'|^2}},\qquad \lambda\ge0.$$

$\lambda=0$ is uniform; larger λ concentrates probability near the centre. The **entropy** $H(X)=-\sum P(a)\log_2P(a)$ is the number of bits each symbol carries before FEC. Two benefits:

1. **Shaping gain**: up to 1.53 dB asymptotically (the ultimate gap between a uniform "cube" and a Gaussian); about 0.5–1 dB in practical systems.
2. **Rate adaptivity**: by tuning λ, the information rate can be set continuously (e.g. 3.2, 3.3, … bits/symbol) with a single constellation and FEC — the transceiver can fill exactly the capacity each link offers.

### Numbers (from `code/ch8_fec_shaping.py`; symbol-wise MI, λ optimised at each SNR)

| SNR (dB) | Shannon | uniform 64-QAM | MB-shaped 64-QAM |
|---|---|---|---|
| 10 | 3.46 | 3.26 | 3.46 |
| 14 | 4.71 | 4.39 | 4.62 |
| 18 | 6.00 | 5.46 | 5.55 |

![Maxwell-Boltzmann shaped 64-QAM](figures/ch8_pcs.png)

*Figure 8.2 — Maxwell–Boltzmann probabilities on 64-QAM (dot area ∝ probability). λ = 0 is uniform (6 bits); larger λ favours low-energy points and lowers the entropy. λ ≈ 2.26 gives the 5.2-bit distribution of Problem 8.4.*

Shaping nearly closes the gap to Shannon at 10–14 dB. At 18 dB its benefit shrinks because 64-QAM itself starts saturating (a larger base constellation such as 256-QAM would be shaped instead). (Monte-Carlo values vary by ±0.01 between runs.)

### How it is implemented: probabilistic amplitude shaping (PAS)
Böcherer, Steiner and Schulte (2015) proposed the architecture used in practice: a **distribution matcher** (e.g. constant-composition distribution matching) converts uniform data bits into a sequence of *amplitudes* with the desired MB distribution; a systematic FEC encoder adds parity bits, which — being approximately uniform — are used as the *signs* of the I/Q components (the MB distribution is symmetric). The receiver decodes, then inverts the matcher. The net information rate per 2D symbol for $M$-QAM with a rate-$R_c$ code is

$$R = H(X) - (1-R_c)\log_2M.$$

**Practical caveats**: shaped constellations have a higher peak-to-average power ratio (harder on DAC/driver linearity), can slightly increase nonlinear interference in fiber, and complicate blind DSP (e.g. CMA and BPS behave differently because most points are inner points). Commercial high-end transceivers now use PCS routinely.

## 8.7 Nonlinearity compensation

### Digital back-propagation (DBP)
Since the fiber's deterministic behaviour follows the NLSE, the receiver can solve it **backwards**: apply the split-step method with negated dispersion, nonlinearity and loss, span by span (Ip & Kahn, 2008). Our single-channel experiment (`code/ch8_fec_shaping.py`, 10 × 80 km, 32 GBd):

| Launch power (dBm) | −2 | 0 | 2 | 4 | 6 |
|---|---|---|---|---|---|
| CD compensation only | 21.8 | 20.4 | 17.4 | 13.5 | 9.4 |
| DBP, 1 step/span | 22.5 | 21.8 | 19.2 | 15.5 | 11.2 |
| DBP, 10 steps/span | 24.0 | 26.0 | 27.9 | 29.7 | 31.0 |

![Digital back-propagation results](figures/ch8_dbp.png)

*Figure 8.3 — Single-channel DBP. With 10 steps per span the SNR follows the ASE-only line: in this idealised simulation, nonlinearity is almost fully reversible.*

With enough steps, single-channel DBP removes almost all of the self-phase modulation: the SNR follows the ASE-only line (24, 26, 28, 30, 32 dB) closely, limited only by signal–ASE nonlinear interaction, which cannot be reversed. One step per span gives ~1–2 dB.

**Why real systems see much smaller gains:** in a WDM system, most of the nonlinear interference comes from *neighbouring* channels (XPM, FWM), which the receiver does not see; PMD scrambles the interaction in a way the receiver cannot model exactly; and DBP with many steps per span is extremely expensive in power. Reported practical gains for single-channel DBP in full WDM systems are typically of order 0.5–1 dB in SNR. Industry therefore uses low-complexity alternatives (perturbation-based compensation, filtered/"enhanced" DBP with few steps, and learned variants) where the power budget allows, and otherwise relies on launch-power optimisation.

**Teaching point:** a simulation that ignores WDM and PMD can wildly overstate the value of a nonlinearity-compensation algorithm. Always ask what the simulation leaves out.

## 8.8 Machine learning in optical DSP — an honest view

Neural networks and learned algorithms have been applied to equalization (especially IM/DD nonlinear ISI), nonlinearity compensation ("learned DBP", which unrolls DBP into a trainable network), performance monitoring, and end-to-end autoencoder-designed constellations. They can match or beat hand-designed algorithms in some regimes. The standard for a fair comparison is: **same complexity (multiplications per symbol), same training/test separation, and a strong conventional baseline** (e.g. Volterra, MLSE, well-tuned DBP). Many published gains shrink or vanish under these conditions, while some (e.g. learned DBP with few steps) are genuinely valuable. Expect this area to keep evolving; judge each claim on these criteria.

## 8.9 From algorithm to silicon

A DSP engineer in industry spends much of their time on questions that simulations like ours ignore:

- **Fixed-point arithmetic**: every signal gets a word length (often 5–10 bits); quantization noise and overflow must be analysed for every block. A typical workflow: floating-point Python/MATLAB model → bit-true fixed-point model → RTL (hardware description) → verification against the model.
- **Parallelism and latency**: at >100 GBd with a clock ~1 GHz, each block processes hundreds of samples per cycle; feedback loops become block-based and delayed, which changes their dynamics (e.g. equalizer tracking speed, PLL bandwidth).
- **Power**: the DSP ASIC is the dominant consumer in a coherent module. The design metric is energy per bit (pJ/bit). This drives choices like fractional oversampling, frequency-domain processing, reduced-complexity BPS, and FEC decoder iteration limits. Leading coherent DSPs are fabricated in 5 nm and 3 nm CMOS.
- **Interoperability**: standards like OIF 400ZR, 800ZR and 1600ZR fix the framing, FEC, pilots and modulation so that transceivers from different vendors can talk to each other — constraining algorithm freedom but creating huge markets.
- **Testing and calibration**: skew, IQ imbalance and frequency responses are calibrated in production; DSP firmware manages start-up (CD scan, acquisition) and monitoring.

## 8.9b Fixed point in practice: how many ADC bits?

A useful first fixed-point experiment is the ADC itself (`code/ch8_fixed_point.py`). A 32 GBd 16-QAM signal after 800 km (so the received waveform is Gaussian-like, with a high peak-to-average ratio) is quantized with $b$ bits per quadrature and a full scale of $k$ times the rms value; everything else is ideal. Channel SNR: 20 dB.

| bits | full scale 2× rms | 3× rms | 4× rms | 6× rms |
|---|---|---|---|---|
| 3 | 14.5 | 14.5 | 12.8 | 9.8 |
| 4 | 16.3 | 17.8 | 16.8 | 14.7 |
| 5 | 17.1 | 19.2 | 19.0 | 18.0 |
| 6 | 17.4 | 19.7 | 19.7 | 19.4 |
| 8 | 17.5 | 19.8 | 20.0 | 20.0 |

(SNR in dB after DSP; floating point gives 20.0 dB.)

![ADC resolution and clipping](figures/ch8_adc_bits.png)

*Figure 8.4 — Two noise sources compete. A small full scale (2× rms) clips the Gaussian-like peaks and creates a floor near 17.5 dB that no number of bits can fix. A large full scale (6× rms) wastes levels on rare peaks, increasing quantization noise. The optimum is ≈ 3–4× rms. With it, 6 bits cost ≈ 0.3 dB and 5 bits ≈ 0.8 dB at 20 dB SNR.*

This is exactly the kind of analysis done for every block of a DSP ASIC (equalizer taps, FFT internal word lengths, LLR bit widths), and it explains why receivers need automatic gain control: the optimal full scale is defined relative to the signal's rms value. Real 100+ GSa/s ADCs have an ENOB of roughly 5–6 bits at high frequencies, so this analysis shows a real, non-negligible penalty.

## 8.10 Common pitfalls

1. Comparing codes by BER thresholds when their soft information differs — use GMI/NGMI.
2. Forgetting the rate loss when comparing coded and uncoded systems (always use $E_b/N_0$ per information bit or net rate).
3. Computing LLRs with the wrong noise variance (LLR scaling matters for SD decoders).
4. Claiming shaping gain without accounting for the FEC and matcher rate.
5. Evaluating nonlinearity compensation in a single-channel, PMD-free simulation and extrapolating to real systems.

## 8.11 Check your understanding

1. Why can a soft-decision decoder beat a hard-decision decoder with the same code?
2. What does the GMI measure that the pre-FEC BER doesn't?
3. What is the net rate per 2D symbol for PCS-64QAM with $H(X)=5.2$ bits and a rate-0.8 code?
4. Why is DBP much more effective in a single-channel simulation than in a real WDM system?

<details><summary>Answers</summary>

1. It uses reliability information: bits that were received close to the threshold are treated as uncertain, so the decoder preferentially flips them.
2. The information content available to a bit-wise decoder, including the reliability distribution of the LLRs, not just the fraction of hard-decision errors.
3. $5.2-(1-0.8)\times6 = 5.2-1.2 = 4.0$ bits per 2D symbol (8 bits per dual-polarization symbol).
4. In WDM most nonlinear interference comes from other channels the receiver doesn't detect; PMD and signal–ASE interactions are not reversible; and full-accuracy DBP is too complex for real-time use.
</details>

## 8.12 Problems

### Problem 8.1 ★★ — LLRs for QPSK
Show that for Gray-coded QPSK with $E_s=1$ (points $(\pm1\pm j)/\sqrt2$, first bit mapped to the sign of I with bit 0 ↔ positive) the exact LLR of the first bit is $L=2\sqrt2\,\mathrm{Re}\{y\}/N_0$.

<details><summary>Solution</summary>

The first bit depends only on I. Write $y=y_I+jy_Q$. Points with bit 0 have I = $+1/\sqrt2$, bit 1 have I = $-1/\sqrt2$; in both sets, the Q values are the same ($\pm1/\sqrt2$), so the Q terms cancel in the ratio:

$L = \ln\frac{e^{-(y_I-1/\sqrt2)^2/N_0}}{e^{-(y_I+1/\sqrt2)^2/N_0}} = \frac{(y_I+1/\sqrt2)^2-(y_I-1/\sqrt2)^2}{N_0} = \frac{4y_I/\sqrt2}{N_0} = \frac{2\sqrt2\,y_I}{N_0}.$

For higher-order QAM the LLR is piecewise nonlinear, and max-log gives a piecewise-linear approximation.
</details>

### Problem 8.2 ★ — From SNR to net rate
A 130 GBd DP transceiver operates at SNR = 14 dB. (a) Using the GMI table, what is the approximate maximum net rate with uniform 16-QAM? (b) With PCS-64QAM (use the MI table as an optimistic estimate)? (c) If the FEC has a 5% implementation gap relative to GMI, what are realistic rates?

<details><summary>Solution</summary>

(a) 16-QAM GMI at 14 dB ≈ 3.85 bits (simulated: 3.852) → $2\times130\times3.85\approx1000$ Gb/s.
(b) PCS-64QAM ≈ 4.62 bits → $2\times130\times4.62\approx1200$ Gb/s.
(c) ×0.95 → ≈ 950 Gb/s and ≈ 1140 Gb/s. Shaping buys roughly 20% more capacity here — the reason high-end transceivers use PCS with 64-QAM or larger base constellations. (Also subtract pilot/framing overhead, a few percent.)
</details>

### Problem 8.3 ★★ — GMI versus BER (coding)
For 16-QAM, compute the pre-FEC BER and NGMI at SNRs from 10 to 16 dB. At what SNR is BER = 2×10⁻², and what is the NGMI there? Repeat for QPSK. Are the NGMIs at the same BER equal?

<details><summary>Solution</summary>

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
for M in [4, 16]:
    k = int(np.log2(M))
    for snr in np.arange(4, 16.1, 1.0):
        b = np.random.randint(0, 2, (100000, k)); s = od.bits_to_symbols(b.ravel(), M)
        y = od.add_awgn(s, snr)
        print(M, snr, "BER %.2e" % od.ber_count(y, s, M), "NGMI %.3f" % (od.gmi_awgn(y, b, M, snr)/k))
```
From Chapter 4, BER = 2×10⁻² occurs at ≈ 6.3 dB for QPSK and ≈ 12.7 dB for 16-QAM. In our run the NGMIs at those points are 0.923 (QPSK) and 0.925 (16-QAM): for Gray-coded square QAM in AWGN, BER and NGMI are almost interchangeable. They diverge for non-Gaussian distortions (residual phase noise, nonlinear interference), for non-Gray labellings and, above all, for probabilistically shaped constellations, where the BER of the shaped symbols says little about the decoder's success. That is why modern specifications move from BER thresholds to NGMI (or GMI) thresholds.
</details>

### Problem 8.4 ★★ — Designing a shaped constellation (coding)
Using `mb_distribution` and `entropy` from `code/ch8_fec_shaping.py`, find λ such that PCS-64QAM with a rate-0.8 code delivers a net rate of exactly 4.0 bits per 2D symbol. At what SNR does this configuration's MI reach the 4.0-bit net rate?

<details><summary>Solution</summary>

Net rate $R = H - (1-0.8)\cdot6 = H - 1.2$, so we need $H = 5.2$ bits. Scan λ (after normalising the constellation to unit energy, λ in `mb_distribution` acts on the unnormalised-by-p constellation from `qam_constellation`, which is fine) with a root finder:

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
from scipy.optimize import brentq
from ch8_fec_shaping import mb_distribution, entropy, mi_shaped
c, _ = od.qam_constellation(64)
lam = brentq(lambda l: entropy(mb_distribution(c, l)) - 5.2, 0.01, 5)
p = mb_distribution(c, lam); print("lambda =", lam)
for snr in np.arange(8, 14.1, 0.5):
    print(snr, mi_shaped(c, p, snr))
```
The root finder gives λ ≈ 2.26 (for the unit-energy uniform 64-QAM point set returned by `qam_constellation`). Averaging three Monte-Carlo runs of `mi_shaped`, the MI is 3.75 bits at 11 dB, 3.89 at 11.5 dB, 4.04 at 12 dB and 4.19 at 12.5 dB, so it crosses 4.0 bits at about **11.9 dB** — within ≈ 0.1–0.2 dB of the Shannon limit for 4 bits ($10\log_{10}(2^4-1) = 11.76$ dB). A real FEC adds its implementation gap on top (a few tenths of a dB). For comparison, uniform 16-QAM *cannot* carry 4.0 net bits at all (its GMI only approaches 4 asymptotically), and delivering, say, 3.47 net bits with a rate-0.87 code needs about 12.7 dB. This is the practical value of shaping: more rate at the same SNR, and any rate you like.
</details>

### Problem 8.5 ★★ — Digital back-propagation (coding)
Run the DBP section of `code/ch8_fec_shaping.py`. (a) Plot SNR versus launch power for the three cases and find the optimum launch power and peak SNR of each. (b) Try 2 and 4 steps per span. (c) Explain in a paragraph why your peak DBP gain is much larger than what is reported for real WDM systems.

<details><summary>Solution</summary>

(a) CD-only peaks ≈ 21.8 dB near −2 dBm; DBP with 1 step/span gives ≈ 22.5 dB at −2 dBm and ≈ 21.8 dB at 0 dBm, so its peak is near −1 to −2 dBm with a gain of ≈ 0.7–1 dB (refine the grid to pin it down); DBP with 10 steps/span is still rising at +6 dBm (≈ 31 dB) — a gain of ~9 dB in this idealised case. (b) 2 and 4 steps per span fall between these: gains increase steadily with steps, with diminishing returns once the step is shorter than the nonlinear/dispersion interplay length. (c) See Section 8.7: single-channel simulation with the exact fiber parameters, no PMD, no WDM neighbours and perfect knowledge of the link is the best case for DBP. Real systems have unknown inter-channel nonlinearity, PMD-induced decorrelation, parameter uncertainty and a strict power budget.
</details>

### Problem 8.6 ★★ — LDPC experiments (coding)
Using `code/ch8_ldpc.py`: (a) set the min-sum normalisation α = 1.0 (plain min-sum) and compare the post-FEC BER at 2.0 dB with α = 0.75; (b) limit the decoder to 10 iterations; (c) explain both results.

<details><summary>Solution</summary>

(a) Plain min-sum overestimates the reliability of check-to-variable messages (the minimum of several magnitudes is larger than what the exact tanh rule gives), so decisions become overconfident too early; α ≈ 0.7–0.8 compensates. Expect the post-FEC BER at 2.0 dB to be noticeably worse with α = 1 (typically several times higher). (b) With only 10 iterations, many codewords near threshold have not converged (the table shows ~42–50 iterations are used at 2 dB), so the waterfall shifts to the right. (c) Both effects matter in hardware: the normalisation is nearly free, while the iteration count sets throughput and power — decoders are often provisioned for a maximum iteration count and designed to stop early.
</details>

### Problem 8.7 ★★★ — Design: choosing the FEC rate from GMI
A 64 GBd DP-16QAM link operates at SNR = 13 dB at beginning of life, and the operator requires the link to keep working after a 2 dB SNR degradation (aging, repairs). A family of soft-decision codes is available with rates $R_c\in\{0.94, 0.89, 0.84, 0.80\}$; each needs NGMI ≥ $R_c$ + 0.03 (its implementation gap). Pilots/framing cost 3%. Measured NGMI for 16-QAM: 0.935 at 13 dB, 0.846 at 11 dB. (a) Which rate would you choose without margin, and with the required margin? (b) What are the two net rates? (c) What would a flexible transceiver with PCS do instead?

<details><summary>Solution</summary>

(a) At 13 dB: need $R_c\le0.935-0.03=0.905$ → **0.89**. With the margin (design at 11 dB): $R_c\le0.846-0.03=0.816$ → **0.80**.

(b) Line rate $64\times8=512$ Gb/s. Net: $512\times0.89\times0.97\approx442$ Gb/s without margin; $512\times0.80\times0.97\approx397$ Gb/s with margin — the familiar "400G" product.

(c) It would keep the FEC fixed and tune the shaping entropy (Chapter 8.6) in fine steps to use the actual SNR of each link, and could even raise the rate later when monitoring shows unused margin. GMI-based design makes this possible: you compute NGMI from measured LLRs and choose the rate, without ever running the decoder at threshold.
</details>

---

## Key takeaways

- FEC is worth 10+ dB: soft-decision codes operate at pre-FEC BERs of 10⁻² (≈15% overhead) to 10⁻¹ (rate ½).
- **LLRs** carry reliability; soft decoding gains ≈ 2 dB over hard decoding.
- **LDPC** decoding = message passing on the Tanner graph; min-sum with normalisation is the hardware workhorse; the BER falls in a steep waterfall.
- **GMI/NGMI** from LLRs predict what a bit-wise decoder can achieve — the modern way to specify thresholds and choose code rates.
- **PCS** (Maxwell–Boltzmann, PAS architecture) recovers most of the ≈ 1.5 dB shaping gap and makes the rate continuously tunable.
- **DBP** is spectacular in single-channel simulations but gives ~0.5–1 dB in real WDM systems.
- **Fixed point**: clipping versus quantization noise sets an optimum full scale (≈ 3–4× rms); ADC ENOB is a real penalty.

---

**Next:** Chapter 9 — the capstone project and a snapshot of today's industry.
