# Chapter 9 — Capstone Project and Industry Snapshot

> **Goal.** Build, from your own code, a complete simulated coherent transceiver link, characterise it the way an industry DSP team would, and extend it in at least one direction of your choice. Then place your work in the context of today's technology.

Budget 3–4 weeks. The reference implementation (`code/capstone_coherent_link.py` and the other scripts in `code/`) is there to check your results — **write your own version first**, then compare.

---

## 9.1 Project specification

### System
- Dual-polarization, Gray-coded QPSK and 16-QAM, root-raised-cosine shaping with β = 0.1, 32 GBd (then 64 GBd).
- **Framing**: a known 64-symbol QPSK header every 2112 symbols and one known pilot every 32 symbols (different sequences on X and Y); total overhead 6.1%.
- Transmitter at 4 samples/symbol. Receiver: band-limited analog front end (cutoff 0.75·R_s), then a free-running ADC at 2 samples/symbol with a 20 ppm clock offset and random sampling phase.
- Channel: chromatic dispersion (800 km SSMF, D = 17 ps/(nm·km)), first-order PMD (10 ps DGD), polarization rotation at 10 krad/s, ASE noise set by OSNR, frequency offset (default 1.2 GHz), laser phase noise (100 kHz per laser).

### Receiver DSP (all blocks your own)
1. CD compensation in the frequency domain.
2. Coarse frequency-offset removal (spectral centre of gravity) and matched filtering.
3. Timing recovery (Gardner detector, PI loop filter, interpolator), with the equalizer's tap centroid steering the clock.
4. 2×2 butterfly equalizer (CMA; decision-directed stage optional).
5. Fine frequency-offset estimation (4th power).
6. Frame synchronisation on the known headers (delay, polarization identity), tracked frame by frame.
7. Pilot-aided carrier-phase recovery combined with blind phase search.
8. Metrics: SNR (data-aided), BER (≥ 100 errors), GMI.

**Rule:** the receiver may use the known headers and pilots, but **never the transmitted data**; the data are used only to measure performance.

### Required experiments
- **E1 — Back-to-back sanity check** (no fiber, no FO/phase noise, no clock offset; framing, timing and CPR still active). Compare the measured SNR with the OSNR-derived SNR (Chapter 3) and explain any difference.
- **E2 — OSNR sweep.** BER and GMI versus OSNR for DP-QPSK and DP-16QAM after 800 km with all impairments. Plot against theory; report the **OSNR penalty** at BER = 10⁻³ and at 2×10⁻².
- **E3 — Impairment tolerance** (DP-16QAM, OSNR 22 dB): sweep (a) laser linewidth, (b) frequency offset (−5 to +5 GHz), (c) CD compensation error (0–40 km), (d) equalizer taps (3–31). Explain every trend.
- **E4 — CMA step size.** Plot convergence and final SNR for μ from 3×10⁻⁴ to 10⁻².
- **E5 — Scaling.** Repeat at 64 GBd with the same OSNR; explain the SNR difference.
- **E6 — SOP tracking.** SNR versus polarization rotation speed (10⁴–10⁷ rad/s) for three CMA step sizes.

### Deliverables
1. Code (clean, commented, runnable in one command, fixed random seeds).
2. A report (≤ 12 pages) with figures for E1–E6 and a one-page executive summary: "What OSNR does each format need after 800 km, and what dominates the implementation penalty?"
3. A "lessons learned" section: the bugs you hit and how you found them. (Chapter 6 lists several we hit ourselves: a timing-detector sign error, a matched filter mis-centred by a frequency offset, equalizer tap walk-off, noise aliasing without a front-end filter.)

## 9.2 Answer key (reference implementation)

All numbers below come from `code/capstone_answer_key.py` (single random seed unless noted; expect ±0.2 dB variation between seeds, more near failure points).

**E1 — back-to-back.** DP-QPSK at OSNR 13 dB: 8.79 dB measured versus 8.92 dB channel SNR. DP-16QAM at OSNR 20 dB: 14.66 dB versus 15.92 dB. *Explanation:* QPSK is within 0.13 dB (the receiver is nearly ideal); 16-QAM loses ≈ 1.3 dB even back-to-back, which isolates the cause: CMA's excess noise on a three-ring constellation, not the fiber.

**E2 — OSNR sweep (800 km, all impairments).**

![E2: BER and GMI versus OSNR](figures/capstone_E2_osnr_sweep.png)

| Format | required OSNR at BER 10⁻³ (theory) | penalty | at BER 2×10⁻² (theory) | penalty |
|---|---|---|---|---|
| DP-QPSK | 14.09 dB (13.87) | 0.22 dB | 10.82 dB (10.31) | 0.51 dB |
| DP-16QAM | 24.11 dB (20.60) | 3.51 dB | 18.14 dB (16.78) | 1.37 dB |

*Explanation:* at the FEC threshold (2×10⁻²) both formats are within ≈ 0.5 and 1.4 dB of theory. At BER 10⁻³, 16-QAM's penalty grows to 3.5 dB because its measured SNR flattens out at high OSNR (≈ 17.5 dB at OSNR 25 dB, where the channel SNR is 20.9 dB): an **implementation floor** from CMA excess noise and phase-estimation noise. A decision-directed equalizer stage (Assignment 6.5) lowers this floor. Always quote penalties at the operating point that matters (the FEC threshold).

**E3 — tolerance sweeps (DP-16QAM, OSNR 22 dB, channel SNR 17.92 dB).**

![E3: tolerance sweeps](figures/capstone_E3_tolerance.png)

| Sweep | results (measured SNR) | explanation |
|---|---|---|
| per-laser linewidth | 10 kHz: 16.14 · 100 kHz: 15.96 · 300 kHz: 15.60 · 1 MHz: 14.60 · 2 MHz: 13.21 dB | phase-estimation noise grows with Δν·T; at 2 MHz (combined 4 MHz, Δν·T = 1.25×10⁻⁴) the BPS/pilot CPR costs ≈ 3 dB — consistent with the ~10⁻⁴ tolerance quoted by Pfau et al. |
| frequency offset | −5 to +4.5 GHz: 16.0–16.1 dB (seed 7); 15.0–16.2 dB (seed 8) | flat: the coarse spectral estimate extends the range far beyond the ±R_s/8 = ±4 GHz of the 4th-power estimator alone |
| CD compensation error | 0: 15.96 · 10 km: 15.93 · 20 km: 15.81 · 40 km: 15.15 dB | the equalizer absorbs residual CD until it exceeds its span: 40 km × 17 ps/(nm·km) = 680 ps/nm spreads a 32 GBd signal (35.2 GHz wide) over ≈ 190 ps ≈ 6 symbols, comparable with the 15-tap (7.5-symbol) equalizer |
| equalizer taps | 3: 13.78 · 5: 16.91 · 9: 16.61 · 15: 15.96 · 31: 14.88 dB | too few taps cannot invert PMD and filtering; too many add adaptation noise (every tap jitters). The best length is the shortest that covers the channel memory — here ≈ 5–9 taps |

**E4 — CMA step size.** DP-QPSK at OSNR 16 dB (channel SNR 11.92 dB): μ = 3×10⁻⁴ → 10.75 dB; 1×10⁻³ → 11.66 dB; 3×10⁻³ → 11.49 dB; 1×10⁻² → 10.27 dB. *Explanation:* the smallest step has not fully converged by the end of the 12,000-symbol discard window (see the slow curve in the figure), and in a real receiver slow convergence also means slow recovery from transients; the largest step converges fastest but its excess noise costs ≈ 1.4 dB. μ ≈ 10⁻³ is the best compromise here. The absolute CMA error (≈ 0.28) is dominated by the channel noise and is not a good quality metric at this SNR — use the SNR.

![E4: CMA convergence](figures/capstone_E4_cma_convergence.png)

**E5 — 32 versus 64 GBd at OSNR 22 dB.** 32 GBd: channel SNR 17.92 dB, measured 15.96 dB (penalty 1.96 dB), BER 2.6×10⁻³. 64 GBd: channel SNR 14.91 dB, measured 12.35 dB (penalty 2.56 dB), BER 2.4×10⁻². *Explanation:* at the same OSNR, doubling the symbol rate doubles the noise bandwidth, so the channel SNR drops by 3 dB (Chapter 3.5) — this is the dominant effect. The implementation penalty also grows by ≈ 0.6 dB. Plausible contributors: the 10 ps DGD is now 0.64 symbol instead of 0.32, so the 15-tap equalizer has less margin, and the timing detector is weakened more by PMD. Quantifying which contributor dominates (e.g. by repeating with `dgd_ps=0` and with more taps) is a good exercise; we have not fully separated them.

**E6 — SOP tracking.** See the table and discussion in Chapter 6.5 (Figure 6.4): with μ = 10⁻³ the receiver loses the polarization at 10⁷ rad/s; μ = 3×10⁻³ tracks up to 10⁷ rad/s with ≈ 0.2 dB more noise at low speeds; μ = 10⁻² tracks everything but costs ≈ 1.4 dB. Remember that a block-updated hardware equalizer tracks far slower than our per-symbol simulation.

**Sanity checks that catch most bugs:**
- With γ = 0 and no impairments, SNR must equal the value you set, for every sps.
- CD channel followed by CD compensation must return the input to ~10⁻¹⁰ relative error.
- Plot the constellation after *each* DSP block (Figure 6.1).
- Check that the measured BER is consistent with the measured SNR (invert the AWGN formula).
- If BER ≈ 0.5, look first for: sign conventions, frame alignment, polarization swap, 90° ambiguity, cycle slips, equalizer tap walk-off.

## 9.3 Grading checklist (self-assessment)

| Item | Points |
|---|---|
| E1 back-to-back with a correct explanation of the 16-QAM gap | 10 |
| E2 OSNR sweep for both formats with theory curves and penalties at both BERs | 20 |
| E3 four tolerance sweeps with correct physical explanations | 20 |
| E4 + E6 step-size and SOP-tracking study | 15 |
| E5 64 GBd scaling with explanation | 5 |
| Receiver uses no transmitted data (framing/pilots only) | 10 |
| Code quality: modular, commented, reproducible | 10 |
| Report clarity and "lessons learned" | 10 |
| **Bonus** (any extension below, up to) | +20 |

## 9.4 Extensions (choose at least one)

1. **Decision-directed equalizer in the realistic receiver.** Port Assignment 6.5 (CMA → DD-LMS with in-loop phase tracking) into `capstone_coherent_link.py` and measure how much of 16-QAM's implementation floor (E1, E2) it removes.
2. **Lock detection and gear shifting.** Replace the fixed acquisition length of the timing loop with a lock detector (Chapter 6.4) and show that acquisition becomes both faster and more reliable across random seeds and frequency offsets.
3. **Front-end impairments.** Add IQ imbalance and 2 ps of IQ skew per polarization; implement deskew and GSOP (Chapter 6.2).
4. **Nonlinear channel.** Replace the linear fiber with the split-step model (`od.ssfm`, per span with EDFA noise, as in `code/ch5_launch_power_sweep.py`), find the optimum launch power, then add single-channel DBP (`code/ch8_fec_shaping.py`) and quantify its gain vs steps per span.
5. **WDM.** Simulate 3 or 5 channels at 50 GHz spacing through the SSFM (≥ 16 sps of the channel rate). Receive the centre channel and compare its optimum launch power and DBP gain with the single-channel case — this demonstrates why DBP gains shrink in real systems.
6. **Probabilistic shaping.** Transmit PCS-64QAM with a Maxwell–Boltzmann distribution; adapt CMA's radius and BPS as needed; compare GMI with uniform 16-QAM at the same net rate.
7. **Soft decisions and FEC.** Compute LLRs from the capstone output and decode with the LDPC decoder of `code/ch8_ldpc.py` (use a QPSK mapping so each LLR maps to one code bit); plot post-FEC BER versus OSNR and compare the threshold with the GMI prediction.
8. **Pilot overhead.** Reduce the header length and pilot density (Problem 6.6) and find the minimum overhead that keeps the E2 penalty within 0.1 dB at 1 MHz linewidth.

## 9.5 Industry snapshot (as of September 2026)

Facts below are from the organisations' own publications or reputable trade press; check the sources for later updates.

### Interoperable coherent standards (OIF)
| Agreement | Published | Signal | Target application |
|---|---|---|---|
| 400ZR | first version 2020 (latest revision Oct 2024) | DP-16QAM, 59.84375 GBd, CFEC | ~80–120 km DCI, pluggable |
| 800ZR | Oct 2024 | DP-16QAM, ≈118.2 GBd, oFEC | DCI up to ~120 km |
| 800LR | Apr 2025 | coherent, 800G | ~10 km (campus / "coherent-lite") |
| 1600ZR | Sept 2026 | DP-16QAM, ≈236 GBd class | single-span amplified DWDM up to 120 km |

OIF announced the 1600ZR implementation agreement on 9 September 2026 and planned multi-vendor interoperability demonstrations at ECOC 2026 (21–23 September). A 1600ZR+ project (longer reach) was started in 2024. Deployment of 1600ZR-class modules is expected to follow over the next year or so.

### Commercial and research frontier (coherent)
- Embedded high-performance DSPs (in 3 nm CMOS) deliver **1.6 Tb/s per wavelength** with symbol rates around **200 GBd**, using probabilistic shaping, and 800G over ultra-long-haul distances.
- Pluggable coherent modules reach **800G** (≈118–131 GBd), with **1.2T single-carrier** pluggables introduced.
- Research demonstrations have reported single-carrier transmission at ~**300 GBd** with net rates of 1.6 Tb/s over transoceanic distances and 2.4 Tb/s over ~1200 km (ECOC 2024).
- The trend: every generation roughly doubles the baud rate, moves the DSP to the next CMOS node, and shaves a fraction of a dB off the gap to Shannon.

### IM/DD
- 100G-per-lane PAM4 (53.125 GBd) is mainstream; **200G-per-lane PAM4** (≈113 GBd, IEEE P802.3dj, targeted for completion in 2026) powers 1.6T modules, with 3 nm PAM4 DSPs shipping.
- Power reduction is the dominant theme: linear-drive optics (LPO) and half-retimed optics (LRO/RTLR) remove all or part of the module DSP.
- The boundary between IM/DD and coherent keeps moving: coherent-lite for 2–40 km is actively debated.

### Other active topics you will encounter
Digital subcarrier multiplexing and point-to-multipoint coherent; C+L (and S) band ultra-wideband systems; hollow-core fiber (low latency and low nonlinearity); space-division multiplexing (multi-core/few-mode fiber, requiring large MIMO equalizers — a direct generalisation of the 2×2 butterfly); machine learning for DSP and network monitoring; and energy-per-bit reduction everywhere.

## 9.6 What employers expect from a junior optical DSP engineer

From the contents of this tutorial, you should now be able to:
- write a clean end-to-end link simulation from scratch and debug it systematically;
- explain every block of a coherent receiver, its assumptions, and its failure modes;
- convert between OSNR, SNR, BER, Q and GMI in your head (approximately) and in code (exactly);
- read an IEEE/Optica paper on coherent DSP and reproduce its main figure;
- reason about complexity (multiplications per symbol) and hardware constraints (parallelism, latency, fixed point).

Skills to develop next, depending on your direction: fixed-point modelling and hardware description languages (Verilog/SystemVerilog, high-level synthesis) for ASIC roles; lab skills (real-time oscilloscopes, optical spectrum analysers, BER testers) for systems roles; information theory and coding for FEC roles; optical networking (ROADMs, planning tools, GN-model-based design) for network roles.

---

**Next:** Chapter 10 — references and a reading plan to go deeper.
