# Chapter 3 — Random Processes, Noise, SNR and OSNR

> **How to use this chapter.** §3.2–3.4 are the statistical foundation (make sure you can reproduce the `add_awgn` scaling yourself); §3.5 (OSNR) and §3.8 (Q-factor) contain the numbers you will use daily in industry. Problems are rated ★ / ★★ / ★★★.

> **Learning objectives.** After this chapter you can (1) work with complex Gaussian noise and power spectral densities, (2) add noise at the right level in a simulation with any oversampling factor, (3) convert fluently between Es/N0, Eb/N0, SNR, OSNR, Q-factor and BER, (4) compute the OSNR of an amplified link from first principles, (5) model laser phase noise as a Wiener process, and (6) understand the other receiver noise sources (shot, thermal, quantization) and when each matters.

---

## 3.1 Why noise is the heart of the problem

Every design decision in an optical transceiver — modulation format, symbol rate, FEC overhead, launch power — is ultimately a battle against noise. The information-theoretic limit on how many bits per second a link can carry is set by the signal-to-noise ratio. DSP cannot remove noise that is already added to the signal; what it *can* do is (a) undo deterministic distortions without amplifying the noise too much, (b) track random but slow impairments like phase noise, and (c) make optimal decisions in the presence of what remains. To do any of that we need a precise language for randomness.

## 3.2 Complex Gaussian noise

A **circularly symmetric complex Gaussian** random variable $n = n_I + jn_Q$ has independent real and imaginary parts, each $\mathcal{N}(0,\sigma^2)$. Its total variance (power) is

$$\mathbb{E}\{|n|^2\} = 2\sigma^2 \equiv N_0 \quad(\text{per sample, at 1 sample per symbol}).$$

"Circular" means its statistics do not change if you rotate it by any angle: $e^{j\theta}n$ has the same distribution as $n$. That is why phase rotations in the receiver do not change the noise, and why the noise cloud around each constellation point looks like a round blob.

```python
N0 = 0.1
n = np.sqrt(N0/2) * (np.random.randn(10**6) + 1j*np.random.randn(10**6))
print(np.mean(abs(n)**2))    # ≈ 0.1
```

**The Q-function.** For a real Gaussian $X\sim\mathcal{N}(0,1)$, $Q(x) = P(X>x) = \tfrac12\mathrm{erfc}(x/\sqrt2)$. Almost every BER formula is built from it. Useful anchors: $Q(3)\approx1.3\times10^{-3}$, $Q(4)\approx3.2\times10^{-5}$, $Q(6)\approx10^{-9}$.

## 3.3 Random processes and power spectral density

A random process $x(t)$ is a random function of time. We assume **wide-sense stationarity**: the mean is constant and the autocorrelation $R_x(\tau)=\mathbb{E}\{x(t+\tau)x^*(t)\}$ depends only on the lag $\tau$.

The **power spectral density (PSD)** tells you how the power is distributed over frequency. By the **Wiener–Khinchin theorem** it is the Fourier transform of the autocorrelation:

$$S_x(f) = \int R_x(\tau)e^{-j2\pi f\tau}d\tau, \qquad P_x = R_x(0) = \int S_x(f)\,df.$$

**Intuition.** A process that changes slowly (strong correlation over long lags) has its power at low frequencies; a process that jumps around independently from instant to instant has a flat, "white" spectrum.

**Filtered noise.** Passing a process through an LTI filter $H(f)$ gives $S_y(f)=|H(f)|^2S_x(f)$. In discrete time, filtering white noise of variance $\sigma^2$ by taps $h[k]$ gives variance $\sigma^2\sum_k|h[k]|^2$. This is the root of **noise enhancement**: an equalizer that boosts some frequencies (to undo a channel that attenuated them) also boosts the noise at those frequencies.

**White noise** has $S(f)=N_0$ (two-sided, for complex baseband) over the band of interest. Physically nothing is white forever; "white" means "flat over the bandwidth we care about".

**Noise-equivalent bandwidth.** A filter's equivalent noise bandwidth is $B_{eq}=\int|H(f)|^2df/|H(0)|^2$: the width of an ideal brick-wall filter that would pass the same noise power.

## 3.4 Adding noise correctly in simulation

This trips up nearly every beginner, so let's be careful.

We define the SNR per symbol as $E_s/N_0$, where $E_s$ is the energy per symbol and $N_0$ the noise PSD. After an ideal matched filter sampled once per symbol, the sample noise variance is $N_0$ and the signal power is $E_s$, so the SNR of the samples equals $E_s/N_0$.

If instead the simulation holds the signal at `sps` samples per symbol, the sample rate is $f_s=\text{sps}\cdot R_s$. The clean way to see the scaling:

- The signal's average power is $P = E_s R_s$ (energy per symbol times symbols per second), and that is also the average power per sample, $P_{\text{sample}}$.
- White noise of two-sided PSD $N_0$ observed over the full simulation bandwidth $f_s$ has per-sample variance $N_0 f_s = N_0\,\text{sps}\,R_s$.
- So the per-sample SNR is $\frac{E_sR_s}{N_0\,\text{sps}\,R_s} = \frac{E_s/N_0}{\text{sps}}$: most of that noise lies outside the signal band and will later be removed by the matched filter.

Solving for the per-sample noise variance:

$$\sigma^2_{\text{sample}} = \frac{P_{\text{sample}}\cdot\text{sps}}{E_s/N_0}.$$

That is precisely what `optdsp.add_awgn(x, snr_db, sps)` does:

```python
P  = np.mean(np.abs(x)**2)
N0 = P * sps / 10**(snr_db/10)
x_noisy = x + np.sqrt(N0/2) * (randn + 1j*randn)
```

After the receiver's matched filter (which removes the out-of-band noise) and down-sampling, the measured SNR equals the requested $E_s/N_0$. The test script verifies this.

### Es/N0, Eb/N0 and SNR
- $E_b/N_0 = (E_s/N_0)/\log_2 M$ (energy per *information* bit; with FEC, divide further by the code rate).
- In optical communications, "SNR" almost always means $E_s/N_0$ measured on the symbols after DSP, including all impairments — sometimes called "effective SNR" or "electrical SNR".
- For a 16-QAM signal, $E_b/N_0 = E_s/N_0 - 6.02$ dB.

## 3.5 Optical noise: ASE and OSNR

### Where it comes from
Long-haul links use erbium-doped fiber amplifiers (EDFAs) every 50–100 km to compensate fiber loss (~0.16–0.2 dB/km). An amplifier cannot amplify without adding noise: spontaneously emitted photons get amplified along with the signal — **amplified spontaneous emission (ASE)**. Its PSD per polarization at the amplifier output is

$$S_{ASE} = n_{sp}\,h\nu\,(G-1) \approx \tfrac12 NF\cdot h\nu\cdot G,$$

where $G$ is the gain, $h\nu$ the photon energy (~1.28×10⁻¹⁹ J at 1550 nm), $n_{sp}\ge1$ the spontaneous emission factor and $NF\approx 2n_{sp}$ the noise figure (typically 4.5–6 dB). ASE is, to an excellent approximation, additive white Gaussian noise in the optical field — both polarizations, both quadratures. **This is why AWGN is the right starting model for coherent systems.**

### OSNR
Optical engineers measure noise on an optical spectrum analyzer and define

$$\text{OSNR} = \frac{P_{sig}}{N_{ASE}\ \text{in a reference bandwidth } B_{ref}=12.5\text{ GHz (0.1 nm at 1550 nm)}},$$

where the noise is counted in **both polarizations**. The reference bandwidth has nothing to do with the signal bandwidth — it is a measurement convention.

### OSNR of an amplified link
With $N$ identical spans, each with loss $L_{span}$ exactly compensated by an amplifier of gain $G=L_{span}$ and noise figure $NF$, and per-channel launch power $P_{ch}$:

$$\text{OSNR} = \frac{P_{ch}}{N\cdot NF\cdot h\nu\cdot G\cdot B_{ref}}.$$

Since $h\nu B_{ref} = 1.6\times10^{-9}$ W $= -58.0$ dBm at 1550 nm:

$$\boxed{\text{OSNR}_{dB} \approx 58 + P_{ch,dBm} - NF_{dB} - L_{span,dB} - 10\log_{10}N}$$

This "58 dB rule" is used daily by system engineers. Example: 0 dBm per channel, NF = 5 dB, 80 km spans at 0.2 dB/km (16 dB), 20 spans: OSNR = 58 + 0 − 5 − 16 − 13 = **24 dB**.

**Intuition:** doubling the number of spans costs 3 dB OSNR; each extra dB of span loss costs 1 dB. Raising launch power would help linearly — but fiber nonlinearity (Chapter 5) punishes high power, which creates an optimum.

### OSNR ↔ SNR
For a dual-polarization signal whose ASE noise is in both polarizations, and assuming the receiver's matched filter has noise bandwidth $R_s$:

$$\boxed{\text{SNR} = \text{OSNR}\cdot\frac{B_{ref}}{R_s}} \qquad\Longleftrightarrow\qquad \text{SNR}_{dB} = \text{OSNR}_{dB} + 10\log_{10}\frac{12.5\ \text{GHz}}{R_s}.$$

More generally (Essiambre et al., 2010): $\text{OSNR} = \frac{p R_s}{2B_{ref}}\text{SNR}$ with $p=2$ for dual polarization and $p=1$ for a single-polarization signal.

Example: OSNR = 24 dB at 64 GBd → SNR = 24 − 7.1 = **16.9 dB**. At 32 GBd → 19.9 dB. A faster signal occupies more bandwidth and therefore collects more noise.

## 3.6 Receiver noise: shot, thermal, RIN, quantization

- **Shot noise**: photocurrent is made of discrete electrons; variance $\sigma^2_{sh}=2qIB$. In a coherent receiver the strong local oscillator makes shot noise from the LO dominate the electronics noise (the "shot-noise-limited" regime), but in amplified systems ASE usually dominates both.
- **Thermal noise** of the transimpedance amplifier: $\sigma^2_{th}=4k_BTB/R$ (times a noise factor). Dominant in unamplified IM/DD links (Chapter 7).
- **Relative intensity noise (RIN)** of lasers: noise proportional to optical power; matters in IM/DD.
- **Quantization and ADC noise**: an ideal $b$-bit quantizer over a full-scale sine gives SQNR = $6.02b+1.76$ dB. Real 100+ GSa/s ADCs are characterised by an *effective number of bits* (ENOB), typically around 5–6 bits at high frequencies, i.e. roughly 32–38 dB. That becomes a real limit for high-order formats like 64-QAM, and it is why receivers use automatic gain control to fill the ADC range without clipping.
- **Transceiver noise floor**: the combination of DAC/ADC noise, driver nonlinearity, and so on. Engineers model it as a fixed "transceiver SNR" (e.g. 20–25 dB for a high-baud-rate pluggable) that adds harmonically: $1/\text{SNR}_{tot} = 1/\text{SNR}_{ASE} + 1/\text{SNR}_{TRx} + 1/\text{SNR}_{NLI} + \dots$ — noise powers add, so inverse SNRs add.

## 3.7 Laser phase noise

### The physics in one paragraph
A semiconductor laser's phase is continually kicked by spontaneous emission events. Each kick is small and independent, so the phase performs a **random walk**. The resulting optical spectrum is a Lorentzian whose full width at half maximum is the **linewidth** $\Delta\nu$. Typical values: external-cavity or narrow-linewidth tunable lasers used in coherent systems, ~10–300 kHz; DFB lasers, ~1–10 MHz.

### The DSP model: a Wiener process
In discrete time with sample period $T_s$,

$$\phi[n] = \phi[n-1] + \Delta[n], \qquad \Delta[n]\sim\mathcal{N}(0,\ 2\pi\Delta\nu T_s).$$

The received signal (after both transmitter laser and LO contribute) is multiplied by $e^{j\phi[n]}$, with $\Delta\nu$ the **sum** of both linewidths. Key properties:

- The phase variance grows linearly with time: $\mathrm{Var}\{\phi[n]-\phi[0]\}=2\pi\Delta\nu\,nT_s$. It is **not** stationary — it wanders without bound. That is why the receiver must *track* it, not just estimate it once.
- The figure of merit is the **linewidth–symbol-duration product** $\Delta\nu T$. For 100 kHz combined linewidth at 64 GBd, $\Delta\nu T \approx 1.6\times10^{-6}$ — very benign. Carrier-phase recovery algorithms for 16-QAM tolerate $\Delta\nu T$ on the order of $10^{-4}$ for a 1 dB penalty (Pfau et al., 2009); higher-order formats tolerate less.
- Higher baud rates *help* phase-noise tolerance (less phase drift per symbol).

`optdsp.laser_phase_noise(N, linewidth, fs)` implements this; the test script checks that the increment variance equals $2\pi\Delta\nu/f_s$.

![Wiener phase noise realisations and variance growth](figures/ch3_phase_noise.png)

*Figure 3.1 — Left: five realisations of laser phase noise (1 MHz combined linewidth, 32 GSa/s): the phase wanders without bound, so it must be tracked, not estimated once. Right: across 500 realisations the variance grows exactly linearly, as $2\pi\Delta\nu\,nT_s$.*

### Equalization-enhanced phase noise (preview)
When chromatic dispersion is compensated digitally *after* LO phase noise has been added, the LO's phase noise is spread in time by the CD filter and becomes an additional noise that carrier recovery cannot track. This "EEPN" matters for long links, high baud rates and wide LO linewidths (Shieh & Ho, 2008). It is one reason narrow-linewidth LOs are used in long-haul systems.

## 3.8 Q-factor and BER

For binary decisions on a signal with levels $\mu_1,\mu_0$ and Gaussian noise standard deviations $\sigma_1,\sigma_0$:

$$Q = \frac{\mu_1-\mu_0}{\sigma_1+\sigma_0},\qquad \text{BER}=Q_{func}(Q)=\tfrac12\mathrm{erfc}(Q/\sqrt2).$$

Industry commonly reports the Q-factor *derived from the measured BER*, in dB: $Q^2_{dB} = 20\log_{10}\left(\sqrt2\,\mathrm{erfc}^{-1}(2\,\text{BER})\right)$. Useful anchors:

| Pre-FEC BER | $Q^2$ (dB) | Typical meaning |
|---|---|---|
| 2.4×10⁻⁴ | 10.9 | KP4 RS-FEC threshold (IM/DD Ethernet) |
| 3.8×10⁻³ | 8.5 | classic 7%-overhead hard-decision FEC |
| 1.22×10⁻² | 7.0 | 400ZR concatenated FEC (CFEC) threshold |
| 2.0×10⁻² | 6.3 | oFEC threshold (≈15% overhead SD-FEC) |

(FEC details in Chapter 8.) $Q^2_{dB}$ is convenient because a margin of "1 dB of Q" is roughly 1 dB of SNR for QPSK.

## 3.9 How many errors do you need? Monte-Carlo accuracy

When you estimate BER by counting $k$ errors in $n$ bits, the estimate $\hat p=k/n$ has relative standard deviation ≈ $1/\sqrt{k}$ (Poisson statistics). **Rule of thumb: count at least 100 errors** for about ±20% accuracy (95% confidence). To measure a BER of $10^{-3}$ you need ~10⁵ bits; for $10^{-5}$, ~10⁷ bits. Below that, use analytic formulas or SNR/GMI-based estimates (Chapter 8) rather than brute-force counting.

## 3.10 Common pitfalls

1. Forgetting the `sps` factor when adding noise to an oversampled signal (you get the SNR wrong by $10\log_{10}\text{sps}$ dB).
2. Using OSNR and SNR interchangeably.
3. Measuring the SNR of a signal before the matched filter (you include out-of-band noise).
4. Using the single-laser linewidth instead of the combined (Tx + LO) linewidth.
5. Quoting a BER from 3 counted errors.
6. Adding SNRs in dB instead of adding inverse SNRs in linear units.

## 3.11 Check your understanding

1. An equalizer has taps [0.5, 1, 0.5]. By how much does it increase white-noise power?
2. Why is ASE noise modelled as additive and Gaussian in the optical field?
3. A system doubles its symbol rate from 64 to 128 GBd at the same OSNR. What happens to the SNR?
4. Two impairments each give an SNR of 20 dB on their own. What is the combined SNR?

<details><summary>Answers</summary>

1. $\sum|h|^2 = 0.25+1+0.25=1.5$ → +1.76 dB (compared with a single unit tap).
2. It is the sum of a huge number of independent spontaneous-emission events (central limit theorem), and it adds to the signal field rather than multiplying it.
3. The SNR drops by 3 dB (twice the noise bandwidth).
4. Inverse SNRs add: $0.01+0.01 = 0.02$ → 17 dB.
</details>

## 3.12 Problems

### Problem 3.1 ★★ — Link OSNR budget
A metro link has 8 spans of 100 km (0.2 dB/km, plus 1 dB connector loss per span), amplifiers with NF = 5.5 dB, and launches 1 dBm per channel. (a) Compute the OSNR. (b) The receiver is a 96 GBd DP-16QAM transceiver. Compute the SNR from ASE alone. (c) If the transceiver noise floor is SNR$_{TRx}$ = 21 dB, what is the total SNR?

<details><summary>Solution</summary>

(a) Span loss = 21 dB. OSNR = 58 + 1 − 5.5 − 21 − 10log₁₀8 = 58 + 1 − 5.5 − 21 − 9.03 = **23.5 dB**.

(b) SNR = 23.5 + 10log₁₀(12.5/96) = 23.5 − 8.85 = **14.6 dB**.

(c) Linear: 10^(−1.46) + 10^(−2.1) = 0.0347 + 0.0079 = 0.0426 → **13.7 dB**. The transceiver floor costs almost 1 dB. For 16-QAM at 13.7 dB, the theoretical pre-FEC BER is about $1.1\times10^{-2}$ — just below the oFEC threshold of $2\times10^{-2}$ (verify with `od.ber_qam_theory(16, 13.7)`), so this link would work, with little margin.
</details>

### Problem 3.2 ★★ — Verifying the noise-addition rule (coding)
Generate 16-QAM at 4 sps with RRC shaping, add noise with `od.add_awgn(x, 12, sps=4)`, apply the matched filter, downsample, and measure the SNR with `od.snr_estimate_db`. Then repeat but (wrongly) pass `sps=1`. Explain the 6 dB difference.

<details><summary>Solution</summary>

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
s = od.bits_to_symbols(np.random.randint(0, 2, 4*50000), 16)
h = od.rrc_taps(0.1, 4, 64)
x = od.filter_same(od.upsample(s, 4), h)
for sps_arg in [4, 1]:
    y = od.filter_same(od.add_awgn(x, 12, sps=sps_arg), h)[::4]
    print(sps_arg, od.snr_estimate_db(y[200:-200], s[200:-200]))
```
With `sps=4` you measure ≈ 12 dB. With `sps=1` you measure ≈ 18 dB: the noise was set relative to per-sample power as if each sample were a symbol, i.e. 4× (6 dB) too little noise per unit bandwidth. The matched filter rejects 3/4 of the simulation bandwidth, where most of the (wrongly scaled) noise lived.
</details>

### Problem 3.3 ★★ — Wiener phase noise statistics (coding)
Generate 1000 realisations of 10,000 samples of phase noise for Δν = 1 MHz at 32 GSa/s. Plot the variance of $\phi[n]$ across realisations versus $n$ and compare with the theory. What is the standard deviation after 1000 symbols (at 1 sps)? What does this imply for the averaging window of a phase estimator?

<details><summary>Solution</summary>

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
P = np.array([od.laser_phase_noise(10000, 1e6, 32e9) for _ in range(1000)])
n = np.arange(1, 10001)
print(np.var(P[:, 999]), 2*np.pi*1e6/32e9*1000)   # both ≈ 0.196 rad^2
```
Variance grows linearly: $2\pi\cdot10^6/3.2\times10^{10}\cdot1000 = 0.196$ rad², std ≈ 0.44 rad ≈ 25° after 1000 symbols. A phase estimator averaging over 1000 symbols would therefore be badly wrong at the edges of its window; the window must be short enough that the phase is nearly constant (tens of symbols), yet long enough to average out additive noise. This trade-off sets the optimum block length in Viterbi–Viterbi and BPS (Chapter 6).
</details>

### Problem 3.4 ★ — Q-factor and FEC margin
A receiver measures a pre-FEC BER of 4×10⁻³ and uses an FEC with threshold 1.22×10⁻². Compute the Q² margin in dB.

<details><summary>Solution</summary>

$Q^2_{dB}(4\times10^{-3}) = 20\log_{10}(\sqrt2\,\mathrm{erfc}^{-1}(8\times10^{-3})) \approx 8.4$ dB; threshold 7.05 dB. Margin ≈ **1.4 dB**. (Compute with `scipy.special.erfcinv`.) Operators typically require a few dB of end-of-life margin to cover aging, repairs and PDL.
</details>

### Problem 3.5 ★★ — Noise enhancement by a zero-forcing equalizer
A channel has response $C(z)=1+0.9z^{-1}$. (a) What is the zero-forcing equalizer $1/C(z)$? (b) Show that its noise enhancement is $1/(1-0.81)\approx 5.3$, i.e. 7.2 dB. (c) Why is this a warning for IM/DD links with spectral nulls (Chapter 7)?

<details><summary>Solution</summary>

(a) $1/(1+0.9z^{-1}) = \sum_{k\ge0}(-0.9)^kz^{-k}$ — an infinitely long (IIR) filter with slowly decaying taps.

(b) Noise gain $\sum_k|h_k|^2 = \sum_k 0.81^k = 1/(1-0.81) = 5.26$ → 7.2 dB.

(c) $C(e^{j\omega})$ at $\omega=\pi$ is $1-0.9=0.1$: a deep notch. Inverting it multiplies noise at that frequency by 100. If the channel had an exact null, the ZF equalizer would have infinite gain. In IM/DD with chromatic dispersion, power fading creates such nulls; linear equalizers fail and other techniques are needed. MMSE equalizers (Wiener solution, Chapter 2) avoid infinite gain by balancing ISI against noise.
</details>

### Problem 3.6 ★★★ — Design: how far can a transceiver reach?
A 96 GBd DP-16QAM transceiver needs an SNR of 12.7 dB at the FEC threshold, and the operator demands 2 dB of margin (so 14.7 dB). The link uses 80 km spans (0.2 dB/km), EDFAs with NF = 5 dB, and 1 dBm launch power per channel. Ignore fiber nonlinearity for now. (a) What is the maximum number of spans if the transceiver's own noise floor is SNR$_{TRx}$ = 20 dB? (b) If it is 17 dB? (c) What does this tell you about where engineering effort should go?

<details><summary>Solution</summary>

ASE-limited SNR with $N$ spans: OSNR = 58 + 1 − 5 − 16 − 10log₁₀N = 38 − 10log₁₀N dB, and SNR$_{ASE}$ = OSNR + 10log₁₀(12.5/96) = 29.15 − 10log₁₀N dB.

The total must satisfy $1/\text{SNR}_{tot} = 1/\text{SNR}_{ASE}+1/\text{SNR}_{TRx} \le 10^{-1.47}=0.0339$.

(a) SNR$_{TRx}$ = 20 dB: $1/\text{SNR}_{ASE}\le0.0339-0.0100=0.0239$ → SNR$_{ASE}\ge16.2$ dB → $10\log_{10}N\le12.95$ → $N\le19.7$: **19 spans ≈ 1520 km**.

(b) SNR$_{TRx}$ = 17 dB: $1/\text{SNR}_{ASE}\le0.0339-0.0200=0.0139$ → SNR$_{ASE}\ge18.6$ dB → $N\le11.4$: **11 spans ≈ 880 km**.

(c) A 3 dB worse transceiver floor cuts the reach almost in half. Once the line is good, the transceiver's implementation SNR (DAC/ADC ENOB, driver linearity, DSP penalties) dominates — which is why so much DSP effort goes into shaving tenths of a dB of implementation penalty. (Chapter 5 adds fiber nonlinearity, which lowers these numbers further.)
</details>

---

## Key takeaways

- ASE noise is additive circular complex Gaussian noise in the optical field — AWGN is the right starting model for coherent links.
- In simulation, per-sample noise variance = $P\cdot\text{sps}/(E_s/N_0)$; forget the sps factor and the SNR is wrong by $10\log_{10}$sps.
- **58-dB rule**: OSNR ≈ 58 + P_ch − NF − L_span − 10log₁₀N (dB); **SNR = OSNR + 10log₁₀(12.5 GHz/R_s)** for dual polarization.
- Independent noise sources add as **inverse SNRs** (linear units).
- Laser phase noise is a **Wiener process** (variance ∝ time); the key figure of merit is Δν·T.
- Count ≥100 errors for a trustworthy BER; below that, use SNR/GMI.

---

**Next:** Chapter 4 uses these noise models to design modulation formats, pulse shapes and optimal receivers, and to predict BER and capacity.
