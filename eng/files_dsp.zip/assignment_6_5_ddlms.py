"""
Assignment 6.5 reference solution: CMA pre-convergence, then decision-directed LMS
with a decision-directed PLL inside the loop (16-QAM, full channel of the capstone).

Strategy
 1. Run the capstone channel and front end (CD compensation).
 2. Blind CMA on the whole block -> estimate the frequency offset from its output.
 3. Remove that frequency offset from the equalizer INPUT (2 sps), so the in-loop PLL
    only has to track laser phase noise.
 4. Re-run the butterfly: CMA for the first n_cma symbols, then DD-LMS whose error is
    computed in the equalizer's (un-derotated) frame, with a 1st-order DD-PLL per output.
Run: python assignment_6_5_ddlms.py
"""
import numpy as np
import optdsp as od

def channel_and_frontend(M, Rs, L_km, osnr_db, df_hz, linewidth_hz, n_sym, seed):
    rng = np.random.default_rng(seed)
    k = int(np.log2(M)); sps_tx = 4
    bits = rng.integers(0, 2, (2, n_sym * k))
    sym = np.vstack([od.bits_to_symbols(bits[p], M) for p in range(2)])
    h = od.rrc_taps(0.1, sps_tx, 64)
    tx = np.vstack([od.filter_same(od.upsample(sym[p], sps_tx), h) for p in range(2)])
    ch = od.random_unitary_2x2(rng) @ od.cd_channel(tx, sps_tx * Rs, L_km * 1e3)
    snr_db = osnr_db + 10 * np.log10(12.5e9 / Rs)
    ch = np.vstack([od.add_awgn(ch[p], snr_db, sps=sps_tx, rng=rng) for p in range(2)])
    n = np.arange(ch.shape[1])
    ch = ch * np.exp(1j * (2*np.pi*df_hz*n/(sps_tx*Rs) + od.laser_phase_noise(len(n), 2*linewidth_hz, sps_tx*Rs, rng)))
    rx = np.vstack([od.filter_same(ch[p], h) for p in range(2)])[:, ::2]
    rx = od.cd_channel(rx, 2 * Rs, L_km * 1e3, compensate=True)
    return rx / np.sqrt(np.mean(np.abs(rx)**2)), sym, snr_db

def cma_then_ddlms(x, M, n_taps=15, mu_cma=1e-3, mu_dd=3e-4, mu_phi=0.05, n_cma=10000):
    const, _ = od.qam_constellation(M)
    R2 = np.mean(np.abs(const)**4) / np.mean(np.abs(const)**2)
    h = np.zeros((2, 2, n_taps), complex); h[0, 0, n_taps//2] = h[1, 1, n_taps//2] = 1
    n_out = (x.shape[1] - n_taps) // 2
    out = np.zeros((2, n_out), complex)
    phi = np.zeros(2)
    for k in range(n_out):
        win = x[:, 2*k:2*k + n_taps][:, ::-1]
        y = np.sum(h * win[None], axis=(1, 2))
        if k < n_cma:
            e = (R2 - np.abs(y)**2) * y
            h += mu_cma * e[:, None, None] * np.conj(win)[None]
            if k == n_cma - 1:        # initialise the PLL phases with a BPS estimate
                for p in range(2):
                    _, ph = od.blind_phase_search(out[p, k-500:k], M, 32, 64)
                    phi[p] = ph[-1]
            out[:, k] = y
        else:
            for p in range(2):
                z = y[p] * np.exp(-1j * phi[p])
                d = const[np.argmin(np.abs(z - const))]
                phi[p] += mu_phi * np.imag(z * np.conj(d))
                e = d * np.exp(1j * phi[p]) - y[p]           # error in the equalizer frame
                h[p] += mu_dd * e * np.conj(win)
                out[p, k] = z                                  # phase-corrected output
    return out

def evaluate(z, sym, M, label):
    res = []
    for p in range(2):
        best = None
        for q in range(2):
            ref = od.align(z[p], sym[q]); zz = od.resolve_ambiguity(z[p], ref)
            snr = od.snr_estimate_db(zz[200:-200], ref[200:-200])
            if best is None or snr > best[0]:
                best = (snr, od.ber_count(zz[200:-200], ref[200:-200], M))
        res.append(best)
    print(f"{label}: SNR = {res[0][0]:.2f} / {res[1][0]:.2f} dB, BER = {res[0][1]:.2e} / {res[1][1]:.2e}")

if __name__ == "__main__":
    M, Rs = 16, 32e9
    x, sym, snr_ch = channel_and_frontend(M, Rs, 800, 20.0, 1.2e9, 100e3, 2**15, seed=7)
    print(f"Channel SNR: {snr_ch:.2f} dB (theory BER {od.ber_qam_theory(M, snr_ch):.2e})")
    # Reference: CMA only + FOE + BPS (as in the capstone)
    y, _ = od.cma_butterfly(x, 15, 1e-3, 2, np.mean(np.abs(od.qam_constellation(M)[0])**4) /
                            np.mean(np.abs(od.qam_constellation(M)[0])**2))
    df = np.mean([od.foe_4th_power(y[p, 5000:], Rs) for p in range(2)])
    zc = []
    for p in range(2):
        z = y[p, 5000:] * np.exp(-2j*np.pi*df*np.arange(y.shape[1]-5000)/Rs)
        z, _ = od.blind_phase_search(z / np.sqrt(np.mean(abs(z)**2)), M, 32, 32); zc.append(z)
    evaluate(np.array(zc), sym, M, "CMA + BPS          ")
    # Improved: remove FO at the equalizer input, then CMA -> DD-LMS with in-loop PLL
    n = np.arange(x.shape[1])
    x_fo = x * np.exp(-2j*np.pi*df*n/(2*Rs))
    z = cma_then_ddlms(x_fo, M)[:, 12000:]
    evaluate(z, sym, M, "CMA -> DD-LMS + PLL")
