"""
Chapter 7: Kramers-Kronig (KK) self-coherent receiver (Mecozzi, Antonelli & Shtaif, 2016).

A single-sideband (SSB) 16-QAM signal s(t) occupying only POSITIVE frequencies is sent
together with a strong CW carrier A at the band edge:  E(t) = A + s(t).
If |s| < A (roughly: carrier-to-signal power ratio, CSPR, large enough), E(t) is a
minimum-phase signal, so its phase can be recovered from its intensity alone:
      E(t) = exp( hilbert( ln|E(t)| ) ) ,   with |E| = sqrt(I),
where scipy.signal.hilbert(u) = u + j*H{u} returns the analytic signal.
With the full field recovered from ONE photodiode, chromatic dispersion can be
compensated digitally -- impossible with plain IM/DD.
Run: python ch7_kk_receiver.py
"""
import numpy as np
from scipy.signal import hilbert
import optdsp as od

def kk_link(cspr_db, L_km=80, Rs=32e9, sps=6, thermal_snr_db=30.0, seed=0, use_kk=True):
    """
    Total received optical power is fixed (normalised to 1), so a stronger carrier
    leaves less power for the data. Thermal noise of fixed variance is added to the
    photocurrent: its level is set so that (received power)^2 / noise = thermal_snr_db.
    use_kk=False: naive SSB receiver, sqrt(I) - carrier, which is limited by
    signal-signal beat interference (SSBI).
    """
    rng = np.random.default_rng(seed)
    s_sym = od.bits_to_symbols(rng.integers(0, 2, 4 * 2**14), 16)
    h = od.rrc_taps(0.05, sps, 64)
    x = od.filter_same(od.upsample(s_sym, sps), h)
    fs = sps * Rs
    n = np.arange(len(x))
    fshift = 0.55 * Rs                                   # SSB: move the signal to positive frequencies
    x = x * np.exp(2j * np.pi * fshift * n / fs)
    c = 10**(cspr_db / 10)                               # carrier-to-signal power ratio
    x = x / np.sqrt(np.mean(np.abs(x)**2)) * np.sqrt(1 / (1 + c))
    A = np.sqrt(c / (1 + c))                             # carrier + signal power = 1
    E = od.cd_channel(A + x, fs, L_km * 1e3)             # CD acts on carrier + signal
    I = np.abs(E)**2                                     # single photodiode (square law)
    sigma2 = 10**(-thermal_snr_db / 10) * sps            # thermal noise per sample (full band)
    I = I + np.sqrt(sigma2) * rng.standard_normal(len(I))
    if use_kk:
        E_rec = np.exp(hilbert(0.5 * np.log(np.clip(I, 1e-9, None))))   # KK phase retrieval
    else:
        E_rec = np.sqrt(np.clip(I, 0, None)).astype(complex)            # naive SSB detection
    E_rec = od.cd_channel(E_rec, fs, L_km * 1e3, compensate=True)       # digital CD compensation
    y = E_rec - np.mean(E_rec)                                          # remove the carrier
    y = y * np.exp(-2j * np.pi * fshift * n / fs)
    y = od.filter_same(y, h)[::sps]
    y = y * np.exp(-1j * np.angle(np.vdot(s_sym, y)))                   # common phase
    return od.snr_estimate_db(y[200:-200], s_sym[200:-200])

if __name__ == "__main__":
    print("SSB 16-QAM, 32 GBd, 80 km SSMF at 1550 nm, one photodiode, fixed received power")
    print(" CSPR   KK (no noise)  naive SSB (no noise)   KK (thermal noise)")
    for cspr in [4, 6, 8, 10, 12, 14, 16]:
        print(f"  {cspr:2d} dB   {kk_link(cspr, thermal_snr_db=200):6.2f} dB      "
              f"{kk_link(cspr, thermal_snr_db=200, use_kk=False):6.2f} dB            "
              f"{kk_link(cspr):6.2f} dB")
