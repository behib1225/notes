# Chapter 10 — References and a Plan for Further Study

This list is deliberately selective: each entry is a primary source for something in this tutorial or the best next step for going deeper. Where a paper introduced an algorithm used here, the chapter is noted.

---

## 10.1 Textbooks

**Signal processing and communications**
- A. V. Oppenheim and R. W. Schafer, *Discrete-Time Signal Processing*, 3rd ed., Pearson, 2010. — The reference for Chapters 1–2 (sampling, DFT, filter design, multirate).
- J. G. Proakis and M. Salehi, *Digital Communications*, 5th ed., McGraw-Hill, 2008. — Modulation, matched filtering, detection, equalization, coding (Chapters 4, 7, 8).
- S. Haykin, *Adaptive Filter Theory*, 5th ed., Pearson, 2014. — Wiener filtering, LMS and its convergence (Chapters 2, 6).
- T. M. Cover and J. A. Thomas, *Elements of Information Theory*, 2nd ed., Wiley, 2006. — Mutual information and capacity (Chapters 4, 8).

**Optical communications**
- G. P. Agrawal, *Fiber-Optic Communication Systems*, 5th ed., Wiley, 2021. — Components, dispersion, noise, systems (Chapters 3, 5, 7).
- G. P. Agrawal, *Nonlinear Fiber Optics*, 6th ed., Academic Press, 2019. — The NLSE and split-step method (Chapter 5). Remember that its sign convention is the complex conjugate of this tutorial's.
- A. E. Willner (ed.), *Optical Fiber Telecommunications VII*, Academic Press, 2019. — Review chapters by leading researchers on coherent DSP, shaping, FEC, IM/DD and more.

## 10.2 Review papers (read these first after this tutorial)
- K. Kikuchi, "Fundamentals of coherent optical fiber communications," *J. Lightwave Technol.*, vol. 34, no. 1, pp. 157–179, 2016.
- S. J. Savory, "Digital coherent optical receivers: algorithms and subsystems," *IEEE J. Sel. Topics Quantum Electron.*, vol. 16, no. 5, pp. 1164–1179, 2010.
- M. S. Faruk and S. J. Savory, "Digital signal processing for coherent transceivers employing multilevel formats," *J. Lightwave Technol.*, vol. 35, no. 5, pp. 1125–1141, 2017.
- E. Ip, A. P. T. Lau, D. J. F. Barros and J. M. Kahn, "Coherent detection in optical fiber systems," *Opt. Express*, vol. 16, no. 2, pp. 753–791, 2008.
- K. Zhong et al., "Digital signal processing for short-reach optical communications: a review of current technologies and future trends," *J. Lightwave Technol.*, vol. 36, no. 2, pp. 377–400, 2018. (Chapter 7.)
- R.-J. Essiambre, G. Kramer, P. J. Winzer, G. J. Foschini and B. Goebel, "Capacity limits of optical fiber networks," *J. Lightwave Technol.*, vol. 28, no. 4, pp. 662–701, 2010. (OSNR–SNR relation, capacity; Chapters 3, 8.)
- P. J. Winzer, D. T. Neilson and A. R. Chraplyvy, "Fiber-optic transmission and networking: the previous 20 and the next 20 years," *Opt. Express*, vol. 26, no. 18, pp. 24190–24239, 2018. — Big-picture history and outlook.
- J. Cho and P. J. Winzer, "Probabilistic constellation shaping for optical fiber communications," *J. Lightwave Technol.*, vol. 37, no. 6, pp. 1590–1607, 2019. (Chapter 8.)

## 10.3 Primary sources for the algorithms in this tutorial
- **CD compensation filter (Ch. 2, 6):** S. J. Savory, "Digital filters for coherent optical receivers," *Opt. Express*, vol. 16, no. 2, pp. 804–817, 2008.
- **CMA (Ch. 6):** D. N. Godard, "Self-recovering equalization and carrier tracking in two-dimensional data communication systems," *IEEE Trans. Commun.*, vol. 28, no. 11, pp. 1867–1875, 1980.
- **LMS (Ch. 2):** B. Widrow and M. E. Hoff, "Adaptive switching circuits," *IRE WESCON Convention Record*, pt. 4, pp. 96–104, 1960.
- **LMS mean-square stability with Gaussian data (Ch. 2):** A. Feuer and E. Weinstein, "Convergence analysis of LMS filters with uncorrelated Gaussian data," *IEEE Trans. Acoust., Speech, Signal Process.*, vol. 33, no. 1, pp. 222–230, 1985.
- **Farrow interpolator (Ch. 2, 6):** C. W. Farrow, "A continuously variable digital delay element," *Proc. IEEE ISCAS*, 1988.
- **Mueller–Müller timing detector (Ch. 7):** K. H. Mueller and M. Müller, "Timing recovery in digital synchronous data receivers," *IEEE Trans. Commun.*, vol. 24, no. 5, pp. 516–531, 1976.
- **LDPC codes (Ch. 8):** R. G. Gallager, "Low-density parity-check codes," *IRE Trans. Inf. Theory*, vol. 8, no. 1, pp. 21–28, 1962; and the textbook T. Richardson and R. Urbanke, *Modern Coding Theory*, Cambridge University Press, 2008.
- **Gardner TED (Ch. 6):** F. M. Gardner, "A BPSK/QPSK timing-error detector for sampled receivers," *IEEE Trans. Commun.*, vol. 34, no. 5, pp. 423–429, 1986.
- **Viterbi–Viterbi (Ch. 6):** A. J. Viterbi and A. M. Viterbi, "Nonlinear estimation of PSK-modulated carrier phase with application to burst digital transmission," *IEEE Trans. Inf. Theory*, vol. 29, no. 4, pp. 543–551, 1983.
- **Blind phase search (Ch. 6):** T. Pfau, S. Hoffmann and R. Noé, "Hardware-efficient coherent digital receiver concept with feedforward carrier recovery for M-QAM constellations," *J. Lightwave Technol.*, vol. 27, no. 8, pp. 989–999, 2009.
- **GSOP (Ch. 6):** I. Fatadin, S. J. Savory and D. Ives, "Compensation of quadrature imbalance in an optical QPSK coherent receiver," *IEEE Photon. Technol. Lett.*, vol. 20, no. 20, pp. 1733–1735, 2008.
- **EEPN (Ch. 3):** W. Shieh and K.-P. Ho, "Equalization-enhanced phase noise for coherent-detection systems using electronic digital signal processing," *Opt. Express*, vol. 16, no. 20, pp. 15718–15727, 2008.
- **GN model (Ch. 5):** P. Poggiolini, "The GN model of non-linear propagation in uncompensated coherent optical systems," *J. Lightwave Technol.*, vol. 30, no. 24, pp. 3857–3879, 2012.
- **Digital back-propagation (Ch. 8):** E. Ip and J. M. Kahn, "Compensation of dispersion and nonlinear impairments using digital backpropagation," *J. Lightwave Technol.*, vol. 26, no. 20, pp. 3416–3425, 2008.
- **Kramers–Kronig receiver (Ch. 7):** A. Mecozzi, C. Antonelli and M. Shtaif, "Kramers–Kronig coherent receiver," *Optica*, vol. 3, no. 11, pp. 1220–1227, 2016.
- **Probabilistic amplitude shaping (Ch. 8):** G. Böcherer, F. Steiner and P. Schulte, "Bandwidth efficient and rate-matched low-density parity-check coded modulation," *IEEE Trans. Commun.*, vol. 63, no. 12, pp. 4651–4665, 2015.
- **GMI as the FEC metric (Ch. 8):** A. Alvarado, E. Agrell, D. Lavery, R. Maher and P. Bayvel, "Replacing the soft-decision FEC limit paradigm in the design of optical communication systems," *J. Lightwave Technol.*, vol. 33, no. 20, pp. 4338–4352, 2015.

## 10.4 Standards bodies (for up-to-date specifications)
- **OIF** (Optical Internetworking Forum) — implementation agreements for 400ZR, 800ZR, 800LR, 1600ZR, CEI electrical interfaces, energy-efficient interfaces: oiforum.com → Technical Work → Implementation Agreements.
- **IEEE 802.3** (Ethernet) — 802.3bs/cd/cu (100G/lane PAM4 optics), 802.3df (800G, 2024), P802.3dj (200G/lane, 1.6T): ieee802.org/3.
- **ITU-T Study Group 15** — G.652 (fiber), G.694.1 (DWDM grid), G.709 (OTN, FEC), G.698.2 (DWDM interfaces).
- **OpenROADM / OpenZR+ MSA** — oFEC and interoperable ZR+ modes.

## 10.5 Conferences and journals to follow
- Conferences: **OFC** (March, USA) and **ECOC** (September, Europe) — every important result appears here first. Post-deadline sessions show the state of the art.
- Journals: *Journal of Lightwave Technology*, *Optics Express*, *IEEE Photonics Technology Letters*, *Journal of Optical Communications and Networking*.

## 10.6 A suggested next-steps reading plan (8 weeks)

| Week | Read | Do |
|---|---|---|
| 1 | Kikuchi 2016 review | Map every section to the chapter of this tutorial it extends |
| 2 | Savory 2008 (filters) + Savory 2010 | Re-derive the CD tap count; implement the frequency-domain butterfly (Extension 7) |
| 3 | Pfau 2009 (BPS) + Faruk & Savory 2017 | Implement two-stage BPS; compare complexity |
| 4 | Essiambre 2010 (sections on capacity) + Poggiolini 2012 | Implement the GN model closed form; compare with your SSFM |
| 5 | Alvarado 2015 + Cho & Winzer 2019 | Add PCS to your capstone (Extension 6) |
| 6 | Ip & Kahn 2008 (DBP) | Complete Extensions 4 and 5 (nonlinear, WDM) |
| 7 | Zhong 2018 + Mecozzi 2016 | Build a 200G/lane PAM4 link model with FFE + MLSE |
| 8 | Latest OFC/ECOC post-deadline papers | Reproduce one figure from a recent paper |

## 10.7 A note on open-source tools
After writing your own simulator (which is the point of this tutorial), it is worth looking at established open-source Python packages for optical communications simulation, such as **OptiCommPy**, to compare implementations and conventions. Always check a package's sign conventions (Chapter 5.11) before trusting its dispersion or nonlinearity results alongside yours.

---

*You have reached the end of the tutorial. Go back to the capstone, finish an extension, and then read a recent ECOC paper — you will find you can now follow it.*
