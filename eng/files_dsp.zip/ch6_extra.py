"""
Chapter 6 extra solutions: differential FOE, blind CD estimation, VV block-length sweep.
Run: python ch6_extra.py
"""
import numpy as np
import optdsp as od
rng = np.random.default_rng(5)

# ---------- Differential (phase-increment) frequency-offset estimator ----------
def foe_differential(y, Rs):
    """QPSK: arg( sum (y[n] y*[n-1])^4 ) / 4 = 2*pi*df*T  (range |df| < Rs/8)."""
    z = (y[1:] * np.conj(y[:-1]))**4
    return np.angle(np.sum(z)) / 4 / (2 * np.pi) * Rs

Rs = 32e9
s = od.bits_to_symbols(rng.integers(0, 2, 2 * 2**14), 4)
for df in [-3e9, 0.5e9, 3.9e9]:
    n = np.arange(len(s))
    y = od.add_awgn(s, 10, rng=rng) * np.exp(1j * (2*np.pi*df*n/Rs + od.laser_phase_noise(len(s), 200e3, Rs, rng)))
    print(f"[FOE] true {df/1e9:+.2f} GHz  4th-power FFT: {od.foe_4th_power(y, Rs)/1e9:+.3f}  "
          f"differential: {foe_differential(y, Rs)/1e9:+.3f}   (range limit +-{Rs/8/1e9:.1f} GHz)")

# ---------- Blind CD estimation by scanning ----------
def cd_scan(x, fs, sps, L_grid):
    """
    For each trial length, compensate CD and compute a CD-sensitive blind metric:
    here the variance of |y|^2 at 1 sample/symbol after the matched filter
    (a correctly compensated QPSK signal has nearly constant modulus at the
    right sampling phase; residual CD makes the modulus fluctuate).
    We take the minimum over the sampling phases.
    """
    h = od.rrc_taps(0.1, sps, 64)
    metric = []
    for L in L_grid:
        y = od.filter_same(od.cd_channel(x, fs, L, compensate=True), h)
        metric.append(min(np.var(np.abs(y[ph::sps])**2) for ph in range(sps)))
    return np.array(metric)

sps = 2
xs = od.filter_same(od.upsample(s, sps), od.rrc_taps(0.1, sps, 64))
x_ch = od.add_awgn(od.cd_channel(xs, sps*Rs, 1234e3), 15, sps=sps, rng=rng)
grid = np.arange(0, 2001e3, 50e3)
m = cd_scan(x_ch, sps*Rs, sps, grid)
coarse = grid[np.argmin(m)]
fine_grid = np.arange(coarse - 50e3, coarse + 51e3, 5e3)
fine = fine_grid[np.argmin(cd_scan(x_ch, sps*Rs, sps, fine_grid))]
print(f"[CD scan] true 1234 km -> coarse {coarse/1e3:.0f} km, fine {fine/1e3:.0f} km")

# ---------- Viterbi-Viterbi block length sweep ----------
print("[VV] QPSK, Es/N0 = 10 dB, combined linewidth 2 MHz at 32 GBd (dnu*T = 6.25e-5):")
s2 = od.bits_to_symbols(rng.integers(0, 2, 2 * 2**16), 4)
n = np.arange(len(s2))
y2 = od.add_awgn(s2, 10, rng=rng) * np.exp(1j * od.laser_phase_noise(len(s2), 2e6, Rs, rng))
for B in [1, 4, 16, 32, 64, 256, 1024]:
    z, _ = od.viterbi_viterbi(y2, block=B)
    z = od.resolve_ambiguity(z, s2)
    print(f"     block {B:5d}: BER = {od.ber_count(z[2000:-2000], s2[2000:-2000], 4):.2e}")
print(f"     theory (no phase noise): {od.ber_qam_theory(4, 10):.2e}")
