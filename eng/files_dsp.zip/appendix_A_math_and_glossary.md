# Appendix A — Mathematical Background, Reference Numbers and Glossary

This appendix fills in the mathematics that the chapters use but that a typical Signals & Systems course does not cover. Read each section when a chapter points to it.

---

## A.1 Complex numbers as rotating arrows (review)

- $z = x + jy = r e^{j\theta}$, with $r=|z|=\sqrt{x^2+y^2}$ and $\theta=\arg z$. Euler: $e^{j\theta}=\cos\theta+j\sin\theta$.
- **Multiplying by $e^{j\phi}$ rotates** $z$ by φ without changing its length. A frequency offset multiplies the signal by $e^{j2\pi\Delta f t}$: a steady rotation. Phase noise multiplies by $e^{j\phi(t)}$: a random rotation.
- $z z^* = |z|^2$ is the power (always real, never negative). This is why power-based quantities (CMA's error, the photodiode's output) are insensitive to phase.
- $\mathrm{Re}\{z\} = (z+z^*)/2$, $\mathrm{Im}\{z\} = (z-z^*)/(2j)$.
- The angle of a product adds: $\arg(z_1z_2)=\arg z_1+\arg z_2$. That is why $\arg(y\,p^*)$ measures the phase of $y$ relative to a known pilot $p$.

## A.2 Derivatives with respect to complex variables (Wirtinger calculus)

**The problem.** Adaptive filters minimise real costs such as $J=|e|^2$ with respect to *complex* taps. A real function of a complex variable is not differentiable in the ordinary complex sense (it is not analytic), so we need a different tool.

**The trick.** Write $z = x+jy$ and treat $z$ and $z^*$ as if they were *independent* variables. Define

$$\frac{\partial}{\partial z^*} = \frac12\left(\frac{\partial}{\partial x}+j\frac{\partial}{\partial y}\right).$$

Two facts make this useful:
1. For a real cost $J$, the direction of steepest ascent in the complex plane is $\partial J/\partial z^*$. So **gradient descent is** $z \leftarrow z - \mu\,\partial J/\partial z^*$.
2. The rules are those of ordinary calculus, with $\partial z/\partial z^* = 0$ and $\partial z^*/\partial z^* = 1$.

**Example 1 — LMS.** Output $y=\mathbf{h}^T\mathbf{x}$ (no conjugation, as in our code), error $e=d-y$, cost $J=|e|^2=e\,e^*$.
$\partial e/\partial\mathbf{h}^* = 0$ (e depends on $\mathbf{h}$, not $\mathbf{h}^*$) and $\partial e^*/\partial\mathbf{h}^* = -\mathbf{x}^*$. Hence
$$\frac{\partial J}{\partial\mathbf{h}^*} = e\cdot(-\mathbf{x}^*) \quad\Rightarrow\quad \mathbf{h}\leftarrow\mathbf{h}+\mu\,e\,\mathbf{x}^*,$$
exactly the update in `optdsp` and Chapter 6 (constant factors are absorbed into μ).

**Example 2 — CMA.** $J=(|y|^2-R_2)^2$. With $|y|^2=yy^*$: $\partial|y|^2/\partial\mathbf{h}^* = y\,\mathbf{x}^*$. So $\partial J/\partial\mathbf{h}^* = 2(|y|^2-R_2)\,y\,\mathbf{x}^*$ and
$$\mathbf{h}\leftarrow\mathbf{h}+\mu\,(R_2-|y|^2)\,y\,\mathbf{x}^*.$$

**Convention warning.** If the output is written $y=\mathbf{w}^H\mathbf{x}$ (textbook convention, Chapter 2.8), the same derivation gives $\mathbf{w}\leftarrow\mathbf{w}+\mu\,e^*\mathbf{x}$. Both are the same algorithm with $\mathbf{h}=\mathbf{w}^*$.

## A.3 The Hilbert transform, analytic signals and minimum phase

**Hilbert transform.** The filter with frequency response $H(f)=-j\,\mathrm{sgn}(f)$: it shifts every positive-frequency component by −90° and every negative-frequency component by +90°. So $\mathcal{H}\{\cos\omega t\}=\sin\omega t$.

**Analytic signal.** For a real signal $u(t)$, $u_a(t)=u(t)+j\mathcal{H}\{u(t)\}$ has **only positive frequencies** (the negative ones cancel). `scipy.signal.hilbert(u)` returns $u_a$ (despite its name, not $\mathcal{H}\{u\}$ itself). Conversely, a complex signal with only positive frequencies has imaginary part equal to the Hilbert transform of its real part. That is the discrete core of the Kramers–Kronig relations.

**Products of one-sided signals are one-sided.** If $a(t)$ and $b(t)$ contain only non-negative frequencies, so does $a(t)b(t)$ (frequencies add). So do powers $a^n$ and any convergent power series in $a$.

**Minimum phase and the KK receiver (Chapter 7.8).** Let $E(t)=A+s(t)$ with $A>0$ a constant (the carrier, at frequency 0) and $s(t)$ a single-sideband signal (positive frequencies only). If $|s(t)|<A$ for all t, then
$$\ln E(t) = \ln A + \ln\left(1+\frac{s(t)}{A}\right) = \ln A + \sum_{n\ge1}\frac{(-1)^{n+1}}{n}\left(\frac{s(t)}{A}\right)^n$$
converges and contains only non-negative frequencies. Therefore its imaginary part is the Hilbert transform of its real part:
$$\ln E = \ln|E| + j\phi,\qquad \phi = \mathcal{H}\{\ln|E|\}.$$
A photodiode gives $|E|=\sqrt{I}$, so the full field is $E=\exp(\ln|E|+j\mathcal{H}\{\ln|E|\})$ — one line of code: `np.exp(hilbert(0.5*np.log(I)))`. Signals satisfying this condition are called **minimum-phase**; geometrically, $E(t)$ never encircles the origin of the complex plane. If the carrier is too weak, the series diverges, the phase retrieval fails, and that is exactly what Figure 7.2 shows at low CSPR.

## A.4 Information theory in one page

- **Entropy** of a discrete random variable: $H(X)=-\sum_x p(x)\log_2p(x)$ bits: the average information per symbol. Uniform over M values: $\log_2 M$. Maxwell–Boltzmann 64-QAM with λ = 2.26: 5.2 bits (Chapter 8).
- **Conditional entropy** $H(X|Y)$: remaining uncertainty about X after observing Y.
- **Mutual information** $I(X;Y)=H(X)-H(X|Y)$: how many bits per symbol Y reveals about X. It is the highest rate that can be transmitted reliably with input distribution $p(x)$ and an ideal decoder.
- **Capacity** $C=\max_{p(x)}I(X;Y)$. For the complex AWGN channel with average power constraint, the maximizing input is Gaussian and $C=\log_2(1+\text{SNR})$ bits per complex symbol. Uniform QAM falls short of this by up to ~1.53 dB of SNR at high SNR — the *shaping gap* that probabilistic shaping recovers.
- **GMI** (generalized mutual information): the rate achievable by a practical receiver that computes bit LLRs and decodes the bits independently (bit-interleaved coded modulation). $\text{GMI}=\sum_i I(B_i;Y)\le I(X;Y)$. Computed from LLRs as in Chapter 8.5.
- **Monte-Carlo estimation**: all of these are expectations and can be estimated by averaging over simulated or measured symbols — no FEC decoder required.

## A.5 Reference numbers and formulas

**Constants.** $c=2.998\times10^8$ m/s; $h=6.626\times10^{-34}$ J·s; $q=1.602\times10^{-19}$ C; $k_B=1.381\times10^{-23}$ J/K; photon energy at 1550 nm $h\nu=1.28\times10^{-19}$ J; $h\nu\cdot12.5\,\text{GHz}=-58.0$ dBm.

**Fiber (SSMF, G.652).** Loss 0.18–0.2 dB/km at 1550 nm, ≈0.33 dB/km at 1310 nm; $D$ = 17 ps/(nm·km) at 1550 nm (β₂ = −21.7 ps²/km), ≈0 near 1310 nm; γ ≈ 1.3 W⁻¹km⁻¹; PMD coefficient ≈ 0.04–0.1 ps/√km (modern fiber).

**Conversions.** 0.1 nm at 1550 nm = 12.5 GHz. $\Delta\lambda=\lambda^2\Delta f/c$. dBm = 10log₁₀(P/1 mW).

**Q-function.**

| x | 1 | 2 | 3 | 3.414 | 4 | 5 | 6 | 7 |
|---|---|---|---|---|---|---|---|---|
| Q(x) | 0.159 | 2.28e-2 | 1.35e-3 | 3.2e-4 | 3.17e-5 | 2.87e-7 | 9.9e-10 | 1.3e-12 |

**Key formulas.**
- OSNR ≈ 58 + P_ch − NF − L_span − 10log₁₀N (dB); SNR = OSNR + 10log₁₀(12.5 GHz/R_s) (dual pol).
- Square M-QAM BER ≈ (4/log₂M)(1 − 1/√M)·Q(√(3·SNR/(M−1))).
- PAM4 SER = 1.5·Q(√(SNR_el/5)).
- CD taps ≈ |D|λ²L f_s²/c; power-fading nulls $f_k=\sqrt{(2k+1)c/(2|D|L\lambda^2)}$.
- Wiener phase noise: increment variance $2\pi\Delta\nu T_s$.
- Optimum launch power (GN model): NLI = ASE/2, SNR 1.76 dB below ASE-only.

## A.6 Glossary

| Term | Meaning |
|---|---|
| ADC / DAC | Analog-to-digital / digital-to-analog converter |
| AIR | Achievable information rate |
| APD | Avalanche photodiode |
| ASE | Amplified spontaneous emission (optical amplifier noise) |
| ASIC | Application-specific integrated circuit (the DSP chip) |
| AWGN | Additive white Gaussian noise |
| Baud (Bd) | Symbols per second |
| BER / SER | Bit / symbol error ratio |
| BICM | Bit-interleaved coded modulation |
| BPS | Blind phase search (carrier-phase recovery for QAM) |
| CD | Chromatic dispersion |
| CFEC | Concatenated FEC of OIF 400ZR |
| CMA | Constant modulus algorithm |
| CPR | Carrier-phase recovery |
| CSPR | Carrier-to-signal power ratio |
| DBP | Digital back-propagation |
| DD-LMS | Decision-directed least mean squares |
| DFE | Decision-feedback equalizer |
| DGD | Differential group delay (PMD) |
| DML / EML | Directly modulated laser / electro-absorption modulated laser |
| DSP | Digital signal processing (or processor) |
| DWDM | Dense wavelength-division multiplexing |
| EDFA | Erbium-doped fiber amplifier |
| EEPN | Equalization-enhanced phase noise |
| ENOB | Effective number of bits |
| ER | Extinction ratio |
| EVM | Error-vector magnitude |
| FEC | Forward error correction |
| FFE | Feed-forward equalizer |
| FO / FOE | Frequency offset / frequency-offset estimation |
| GMI / NGMI | (Normalized) generalized mutual information |
| GN model | Gaussian-noise model of fiber nonlinear interference |
| GSOP | Gram–Schmidt orthogonalization procedure |
| IM/DD | Intensity modulation / direct detection |
| IQ | In-phase / quadrature |
| ISI | Inter-symbol interference |
| KK | Kramers–Kronig (receiver) |
| KP4 | RS(544,514) FEC used in Ethernet |
| LDPC | Low-density parity-check code |
| LLR | Log-likelihood ratio |
| LMS / NLMS | (Normalized) least mean squares |
| LO | Local oscillator (laser) |
| LPO / LRO | Linear-drive / linear-receive pluggable optics |
| MB | Maxwell–Boltzmann distribution |
| MI | Mutual information |
| MIMO | Multiple-input multiple-output |
| MLSE | Maximum-likelihood sequence estimation |
| MMSE | Minimum mean-squared error |
| MZM | Mach–Zehnder modulator |
| NCO | Numerically controlled oscillator |
| NF | Noise figure |
| NLI | Nonlinear interference |
| NLSE | Nonlinear Schrödinger equation |
| oFEC | Open FEC (OpenZR+, 800ZR) |
| OIF | Optical Internetworking Forum |
| OSNR | Optical signal-to-noise ratio (0.1 nm reference) |
| PAM4 | 4-level pulse-amplitude modulation |
| PAS | Probabilistic amplitude shaping |
| PCS | Probabilistic constellation shaping |
| PD / TIA | Photodiode / transimpedance amplifier |
| PDL | Polarization-dependent loss |
| PMD | Polarization-mode dispersion |
| ppm | Parts per million (clock-frequency offset) |
| QAM / QPSK | Quadrature amplitude modulation / quadrature phase-shift keying |
| RC / RRC | Raised cosine / root-raised cosine |
| RDE | Radius-directed equalizer |
| RIN | Relative intensity noise |
| ROADM | Reconfigurable optical add-drop multiplexer |
| RS | Reed–Solomon code |
| SE | Spectral efficiency |
| SOP | State of polarization |
| sps | Samples per symbol |
| SPM / XPM / FWM | Self-/cross-phase modulation, four-wave mixing |
| SSB / SSBI | Single sideband / signal–signal beat interference |
| SSFM | Split-step Fourier method |
| SSMF | Standard single-mode fiber (G.652) |
| TDECQ | Transmitter and dispersion eye closure quaternary |
| TED | Timing error detector |
| VV | Viterbi–Viterbi (4th-power) phase estimator |
| WDM | Wavelength-division multiplexing |
