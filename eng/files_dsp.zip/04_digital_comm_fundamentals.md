# Chapter 4 — Digital Communication Fundamentals: Modulation, Pulse Shaping, Detection, BER and Capacity

> **How to use this chapter.** If you already took a digital-communications course, skim §4.2–4.6 and focus on §4.7–4.9, which are specific to optical practice. Problems are rated ★ / ★★ / ★★★. Information-theory background (entropy, mutual information) is in `appendix_A_math_and_glossary.md` (A.4).

> **Learning objectives.** After this chapter you can (1) map bits to PAM/PSK/QAM symbols with Gray coding and compute line rates, (2) explain inter-symbol interference and the Nyquist criterion, and design raised-cosine/root-raised-cosine pulses, (3) derive the matched filter and explain why it is optimal, (4) compute BER for the main formats and required SNRs, (5) relate everything to Shannon capacity and spectral efficiency, and (6) read a constellation and an eye diagram like an engineer.

---

## 4.1 The transmitter in one sentence

Take bits, group them, map each group to a complex number (a **symbol**) from a fixed set (the **constellation**), and send one symbol every $T=1/R_s$ seconds by modulating a carefully chosen **pulse shape**:

$$x(t) = \sum_k a_k\,p(t-kT).$$

For dual-polarization transmission (standard in coherent optics) we do this twice, independently, on the X and Y polarizations of the same laser.

## 4.2 Constellations

| Format | Points | Bits/symbol (per pol.) | Where it is used |
|---|---|---|---|
| OOK / NRZ | 2 intensity levels | 1 | legacy IM/DD up to 25–50 Gb/s/lane |
| PAM4 | 4 intensity levels | 2 | today's data-centre IM/DD (100G and 200G per lane) |
| BPSK | ±1 | 1 | ultra-long-haul / submarine at low SNR |
| QPSK | 4 points on a circle | 2 | long-haul, first 100G coherent generation |
| 8-QAM | 8 | 3 | intermediate reach |
| 16-QAM | 16 on a 4×4 grid | 4 | 400ZR/800ZR/1600ZR, metro/regional |
| 64-QAM | 64 | 6 | short, high-SNR links |
| PCS-QAM | shaped (Ch. 8) | continuous (e.g. 3.2–5.6) | modern flexible transceivers |

**Gray coding.** Neighbouring points (those most likely to be confused by noise) differ in exactly one bit. Then a typical symbol error causes only one bit error, and $\text{BER}\approx\text{SER}/\log_2M$. For square QAM, Gray coding the I and Q axes independently achieves this (see `qam_constellation` in `optdsp.py`, which Gray-codes each axis).

![QPSK, 16-QAM and 64-QAM constellations with noise](figures/ch4_constellations.png)

*Figure 4.1 — Received constellations (red crosses: ideal points) at 12, 20 and 28 dB SNR. The 16-QAM labels show Gray coding: every horizontal or vertical neighbour differs in exactly one bit.*

**Energy normalisation.** We scale constellations to unit average energy $E_s=\mathbb{E}|a|^2=1$. For square $M$-QAM with levels $\{\pm1,\pm3,\dots\}$ on each axis, the unnormalised average energy is $2(M-1)/3$.

**Line rate.** For a dual-polarization $M$-QAM signal:

$$R_{\text{line}} = 2\cdot\log_2M\cdot R_s.$$

Example: 400ZR uses DP-16QAM at 59.84375 GBd → $2\times4\times59.84375 = 478.75$ Gb/s of line rate, which carries 400GbE plus FEC and framing overhead. 800ZR runs at ~118.2 GBd and 1600ZR at ~236 GBd, both DP-16QAM (OIF implementation agreements; see Chapter 9).

## 4.3 Inter-symbol interference and the Nyquist criterion

### The problem
If each pulse $p(t)$ is longer than $T$, neighbouring symbols overlap. At the sampling instant $t=nT$, the received value is

$$x(nT) = a_n\,p(0) + \sum_{k\ne n}a_k\,p((n-k)T).$$

The second term is **inter-symbol interference (ISI)**. Short rectangular pulses avoid overlap, but they have a sinc spectrum with enormous bandwidth — unacceptable when WDM channels are packed tightly.

### The Nyquist criterion
We don't need pulses that don't overlap; we need pulses whose overlap is *zero exactly at the sampling instants*:

$$p(nT) = \begin{cases}1 & n=0\\ 0 & n\neq0\end{cases}\quad\Longleftrightarrow\quad \sum_m P\!\left(f-\frac{m}{T}\right)=T\ \ (\text{constant}).$$

In words: if you copy the pulse spectrum at every multiple of $R_s$ and add the copies, you must get a flat line. The narrowest spectrum that can do this is a brick-wall of width $R_s$ (the sinc pulse) — the minimum bandwidth for zero ISI is $R_s$ (two-sided).

### Raised cosine

![Raised-cosine pulses and spectra](figures/ch4_raised_cosine.png)

*Figure 4.2 — Left: raised-cosine pulses are 1 at their own sampling instant and exactly 0 at all other symbol instants (black dots) — zero ISI even though the pulses overlap. Larger β makes the tails die faster. Right: the price is bandwidth, $(1+\beta)R_s$.*

The sinc pulse is impractical (it decays slowly, so any timing error causes huge ISI). The **raised-cosine** (RC) family softens the brick-wall's edges with a cosine roll-off of width controlled by $\beta\in[0,1]$:

- occupied bandwidth $(1+\beta)R_s$;
- impulse response decays as $1/t^3$ — much more forgiving of timing errors;
- $\beta=0$ is the sinc; typical optical values are $\beta\approx0.01$–$0.2$.

### Splitting between transmitter and receiver: root-raised cosine
For reasons explained in the next section, we put a **root-raised-cosine** (RRC) filter at the transmitter and an identical one at the receiver. Each has $|H(f)|=\sqrt{H_{RC}(f)}$; together they form an RC pulse and satisfy the Nyquist criterion. An RRC pulse alone does *not* satisfy it — the zero ISI appears only after the receive filter. The library function `od.rrc_taps(beta, sps, span)` implements the standard closed form, and the test script shows TX-RRC + RX-RRC gives about 60 dB of residual-ISI SNR (limited only by truncation).

## 4.4 The matched filter

### Derivation
The receiver sees $r(t) = a\,p(t) + n(t)$ with white noise of PSD $N_0$. It filters with $g(t)$ and samples at $t_0$. The output signal is $a\int p(\tau)g(t_0-\tau)d\tau$ and the output noise variance is $N_0\int|g|^2$. The SNR is

$$\text{SNR} = \frac{|a|^2\left|\int p(\tau)g(t_0-\tau)d\tau\right|^2}{N_0\int|g(\tau)|^2d\tau}\le\frac{|a|^2\int|p|^2}{N_0}$$

by the Cauchy–Schwarz inequality, with equality if and only if $g(t) = p^*(t_0-t)$: the receive filter is the **time-reversed conjugate of the pulse**. That is the matched filter, and the maximum SNR equals $E_s/N_0$.

### Intuition
The matched filter is a correlator: it asks "how much does the received waveform look like the pulse?". It weights each moment in time by how much signal is expected there, which is exactly optimal when noise is white.

### Why RRC + RRC
If the TX pulse is RRC (real and symmetric), the matched filter is the same RRC. The cascade is RC, which satisfies Nyquist. So RRC/RRC gives **both** maximal SNR and zero ISI. In an optical receiver, the "matched filter" is part of the DSP (often merged into the CD compensation filter in the frequency domain).

**What happens with the wrong filter?** In one run of the experiment below (QPSK, β = 0.1, Es/N0 = 10 dB), the RRC matched filter gives 10.0 dB; a sharp low-pass filter with cutoff exactly $R_s/2$ gives 9.9 dB (nearly matched, because for small β the RRC is nearly a brick-wall); a cutoff at $0.75R_s/2$ gives 3.7 dB (severe ISI); a cutoff of $1.5R_s/2$ gives 8.3 dB (too much noise let through).

## 4.5 Optimal detection

Given a received sample $y = a + n$ with Gaussian noise, the **maximum-likelihood (ML)** decision picks the constellation point with the highest likelihood $p(y|a)\propto\exp(-|y-a|^2/N_0)$ — i.e. the **nearest point in Euclidean distance**. Decision regions are the "Voronoi cells" around each point; for square QAM they are simply thresholds halfway between levels on each axis. With unequal prior probabilities (shaped constellations, Chapter 8) the MAP rule shifts the thresholds.

This is only optimal if the noise really is white and Gaussian and the symbols are independent after the matched filter. Much of the receiver DSP exists to make that true.

## 4.6 Error probability

Let $\gamma = E_s/N_0$.

- **BPSK:** $P_b = Q(\sqrt{2\gamma})$.
- **QPSK (Gray):** two independent BPSK signals on I and Q, each with half the energy: $P_b = Q(\sqrt{\gamma}) = Q(\sqrt{2E_b/N_0})$ — the same BER vs $E_b/N_0$ as BPSK, at twice the spectral efficiency.
- **M-PAM:** $P_s = 2\left(1-\frac1M\right)Q\left(\sqrt{\frac{6\gamma}{M^2-1}}\right)$ for real-valued (one-dimensional) signals with $\gamma$ the SNR per real symbol.
- **Square M-QAM (Gray), good approximation:**
$$P_b\approx\frac{4}{\log_2M}\left(1-\frac{1}{\sqrt M}\right)Q\left(\sqrt{\frac{3\gamma}{M-1}}\right).$$
This is `od.ber_qam_theory`; it is exact for QPSK and accurate for BER below ~$10^{-2}$ for higher orders. The test script confirms it against simulation.

![BER curves of QAM formats](figures/ch4_ber_curves.png)

*Figure 4.3 — Simulated (dots) and formula (lines) BER of Gray-coded QPSK, 16-QAM and 64-QAM in AWGN. Horizontal lines mark two common FEC thresholds. At low SNR the 64-QAM formula slightly underestimates the BER (see Problem 4.1).*

**Required SNR** (from the formula above, per polarization):

| Format | SNR for BER = 10⁻³ | SNR for BER = 2×10⁻² (oFEC-like threshold) | Shannon SNR for the same bits/symbol |
|---|---|---|---|
| QPSK | 9.8 dB | 6.3 dB | 4.8 dB |
| 16-QAM | 16.5 dB | 12.7 dB | 11.8 dB |
| 64-QAM | 22.6 dB | 18.4 dB | 18.0 dB |

**Rule of thumb:** each doubling of the constellation *side* (QPSK→16QAM→64QAM, +2 bits/symbol) costs about 6 dB of SNR. At a strong FEC's high threshold, a real system sits within ~1 dB of Shannon for these bits/symbol — which is why modern FEC plus shaping is so valuable. (Be careful: comparing a BER threshold with capacity is only indicative; Chapter 8 does it properly with GMI.)

## 4.7 Capacity and spectral efficiency

Shannon's formula for a complex AWGN channel of bandwidth $B$ is

$$C = B\log_2(1+\text{SNR})\ \text{bit/s}.$$

With Nyquist signalling, one complex symbol per second per hertz, so the capacity per symbol per polarization is $\log_2(1+\text{SNR})$ bits. With two polarizations it doubles. **Spectral efficiency (SE)** is the net bit rate divided by the occupied (or allocated) bandwidth, in b/s/Hz. Example: DP-16QAM at 60 GBd with a 75 GHz channel slot and ~20% overhead carries 400 Gb/s net: SE = 400/75 ≈ 5.3 b/s/Hz.

![GMI of QAM formats versus Shannon capacity](figures/ch4_gmi_capacity.png)

*Figure 4.4 — Each uniform QAM format follows the Shannon curve at low SNR and saturates at log₂M bits. The horizontal gap to Shannon at medium SNR (≈1.5 dB) is what probabilistic shaping recovers (Chapter 8).*

**Why Shannon matters in practice:** operators don't buy "16-QAM"; they buy "how many Tb/s per fiber at what reach". Every generation of transceiver is judged by how close it gets to capacity.

The capacity of a *specific* constellation (e.g. uniform 16-QAM) is lower than Shannon's, and is measured with **mutual information (MI)** or, for bit-wise decoders, **generalized mutual information (GMI)** — the metric the industry now uses in place of BER thresholds (Chapter 8). The test script computes GMI for QPSK/16/64-QAM; for example 16-QAM at 15 dB gives GMI ≈ 3.93 bits of the maximum 4.

## 4.8 Reading constellations and eye diagrams

**Constellation diagram** (the scatter of received symbols in the IQ plane) — an optical DSP engineer's primary diagnostic:

| What you see | Likely cause |
|---|---|
| Round, equal clouds | AWGN only — good |
| Clouds smeared along circles (arcs) | residual phase noise or nonlinear phase |
| Whole constellation rotating | frequency offset not removed |
| Squashed / parallelogram shape | IQ imbalance or quadrature error (Chapter 6) |
| Outer points compressed inward | modulator/driver nonlinearity (saturation) |
| Constellation "ring" or blob with no structure | equalizer not converged, or CD not compensated |
| Two superimposed constellations | polarization not demultiplexed |

**Eye diagram**: overlay many two-symbol-long segments of the waveform. The vertical opening at the sampling time measures noise+ISI margin; the horizontal opening measures timing tolerance. Eye diagrams are the primary diagnostic in IM/DD (Chapter 7) and in lab measurements of transmitters.

```python
import numpy as np, matplotlib.pyplot as plt, sys; sys.path.append("code"); import optdsp as od
sps = 16; s = od.pam_levels(4)[np.random.randint(0, 4, 2000)]
for beta in [0.1, 1.0]:
    h = od.rrc_taps(beta, sps, 32)
    y = od.filter_same(od.filter_same(od.upsample(s, sps), h), h).real   # RC pulses
    plt.figure()
    for k in range(100, 600):
        plt.plot(y[k*sps : k*sps + 2*sps + 1], "b", alpha=0.05)
    plt.title(f"PAM4 eye, RC beta={beta}"); plt.show()
```

![PAM4 eye diagrams for two roll-off factors](figures/ch4_eye_diagrams.png)

*Figure 4.5 — PAM4 eyes (sampling instants at 0.5 and 1.5 symbols on this axis). β = 0.1: open only near the sampling instant; β = 1: wide open horizontally.*

Notice that with β = 1 the eye is wide open horizontally; with β = 0.1 it is open only near the ideal sampling instant — small roll-off demands accurate timing recovery.

## 4.9 Differential coding and pilots (phase ambiguity)

A blind carrier-phase estimator for QAM can only determine the phase modulo 90°, because the constellation looks identical after a 90° rotation. Two remedies: **differential coding** (encode information in the *change* of quadrant, at the cost of roughly doubling bit errors) or **pilot symbols** inserted periodically (e.g. 1 in 32 or 1 in 64) that let the receiver resolve the ambiguity and detect cycle slips. Modern interoperable standards such as 400ZR/800ZR use pilot symbols and training sequences inside their frame structure.

## 4.10 Common pitfalls

1. Normalising the constellation to peak rather than average energy.
2. Believing an RRC pulse alone is ISI-free.
3. Using the M-QAM BER approximation at very high BER and trusting it to the third digit.
4. Quoting capacity per polarization and forgetting the factor 2 for dual polarization (or vice versa).
5. Confusing line rate, net rate and client rate.

## 4.11 Check your understanding

1. A DP-QPSK signal runs at 32 GBd. What is its line rate?
2. Why does a small roll-off make timing recovery harder?
3. What does the matched filter maximise, and under what noise assumption is it optimal?
4. From QPSK to 16-QAM at the same symbol rate, by how much does the line rate grow and roughly how much more SNR is needed?

<details><summary>Answers</summary>

1. $2\times2\times32 = 128$ Gb/s (this was the first-generation "100G" coherent format including overheads).
2. The pulse tails decay more slowly and the eye closes quickly away from the optimum sampling instant, so timing errors produce more ISI.
3. The output SNR at the sampling instant; optimal for additive white noise (Gaussian for optimal detection).
4. Line rate doubles; about 6–7 dB more SNR at a given BER.
</details>

## 4.12 Problems

### Problem 4.1 ★★ — BER curves (coding)
Simulate the BER of QPSK, 16-QAM and 64-QAM versus Es/N0 from 0 to 26 dB at 1 sps, and plot them against `od.ber_qam_theory`. At what BER does the approximation for 64-QAM visibly deviate?

<details><summary>Solution</summary>

```python
import numpy as np, matplotlib.pyplot as plt, sys; sys.path.append("code"); import optdsp as od
snrs = np.arange(0, 27, 1.0)
for M in [4, 16, 64]:
    k = int(np.log2(M)); sim = []
    for snr in snrs:
        b = np.random.randint(0, 2, k*100000); s = od.bits_to_symbols(b, M)
        sim.append(od.ber_count(od.add_awgn(s, snr), s, M))
    plt.semilogy(snrs, sim, "o", label=f"{M}-QAM sim")
    plt.semilogy(snrs, od.ber_qam_theory(M, snrs), "-", label=f"{M}-QAM theory")
plt.ylim(1e-5, 0.5); plt.xlabel("Es/N0 (dB)"); plt.ylabel("BER"); plt.legend(); plt.grid(); plt.show()
```
The approximation is excellent below about $10^{-2}$. At low SNR for 64-QAM it *underestimates* the BER (one run: at 4 dB, simulated 0.28 versus 0.21 from the formula; at 12 dB they agree, 0.115 vs 0.112), because the approximation assumes every symbol error goes to a nearest neighbour and costs exactly one bit, ignoring errors to farther points that flip several bits. Points where fewer than ~100 errors are counted (at high SNR) scatter — see Section 3.9.
</details>

### Problem 4.2 ★ — Line rate and net rate
A transceiver sends DP-16QAM at 130 GBd with a 25% overhead FEC (code rate 0.8) and 3% pilot/framing overhead. Compute (a) the line rate, (b) the net rate.

<details><summary>Solution</summary>

(a) $2\times4\times130 = 1040$ Gb/s. (b) $1040\times0.8\times0.97\approx 807$ Gb/s — an "800G" transceiver.
</details>

### Problem 4.3 ★★ — Matched vs mismatched receive filter (coding)
Reproduce the experiment of Section 4.4: QPSK, β = 0.1, 8 sps, Es/N0 = 10 dB. Compare the RRC matched filter with windowed-sinc low-pass filters (`scipy.signal.firwin(257, c/8)`) for cutoff factors c ∈ {0.5, 0.75, 1.0, 1.5}. Explain each result.

<details><summary>Solution</summary>

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
from scipy.signal import firwin
rng = np.random.default_rng(0); sps = 8
s = od.bits_to_symbols(rng.integers(0, 2, 2*50000), 4)
h = od.rrc_taps(0.1, sps, 64)
xn = od.add_awgn(od.filter_same(od.upsample(s, sps), h), 10, sps=sps, rng=rng)
print("RRC MF:", od.snr_estimate_db(od.filter_same(xn, h)[::sps][200:-200], s[200:-200]))
for c in [0.5, 0.75, 1.0, 1.5]:
    g = firwin(257, c/sps)                 # cutoff c*(Rs/2), since fs/2 = sps*Rs/2
    y = od.filter_same(xn, g)[::sps]
    print(c, od.snr_estimate_db(y[200:-200], s[200:-200]))
```
Results (≈): MF 10.0 dB; c = 0.5: ≈ −0.5 dB; 0.75: 3.7 dB; 1.0: 9.9 dB; 1.5: 8.3 dB. Too narrow removes signal energy and creates ISI (catastrophic); exactly $R_s/2$ is almost matched for a small roll-off; too wide admits extra noise (for c = 1.5 the noise bandwidth is 1.5× larger, i.e. up to 1.76 dB worse, and we lose ≈1.7 dB). The matched filter is the best compromise, by construction.
</details>

### Problem 4.4 ★★ — Gray vs natural labelling (coding)
Build a 16-QAM constellation with *natural binary* labels on each axis (00, 01, 10, 11 in level order) and compare its BER with Gray labelling at Es/N0 = 12 dB.

<details><summary>Solution</summary>

```python
import numpy as np, sys; sys.path.append("code"); import optdsp as od
lv = od.pam_levels(4); M = 16; N = 200000
def build(labels_axis):     # labels_axis[pos] = 2-bit label for level position pos
    const = np.zeros(16, complex)
    for i in range(4):
        for q in range(4):
            const[(labels_axis[i] << 2) | labels_axis[q]] = lv[i] + 1j*lv[q]
    return const / np.sqrt(np.mean(abs(const)**2))
bitmap = ((np.arange(16)[:, None] >> np.arange(3, -1, -1)) & 1)
for name, lab in [("Gray", [0, 1, 3, 2]), ("natural", [0, 1, 2, 3])]:
    const = build(lab)
    tx = np.random.randint(0, 16, N)
    y = od.add_awgn(const[tx], 12)
    rx = np.argmin(abs(y[:, None] - const[None, :]), axis=1)
    print(name, np.mean(bitmap[tx] != bitmap[rx]))
```
The SER is identical (same geometry), but the BER with natural labels is ≈ 1.3× higher (one run: 0.028 Gray vs 0.037 natural) because the step between levels 01 and 10 flips both bits. Gray labelling is free performance.
</details>

### Problem 4.5 ★★ — Capacity thinking
A link has SNR = 12 dB. (a) What is the Shannon capacity per symbol per polarization? (b) Is DP-16QAM (uniform) a sensible choice? DP-QPSK? (c) What does a flexible transceiver do instead?

<details><summary>Solution</summary>

(a) $\log_2(1+10^{1.2}) = \log_2(16.85) \approx 4.07$ bits. (b) 16-QAM carries at most 4 bits and would need a strong FEC with a pre-FEC BER near $2\times10^{-2}$ (the table shows 12.7 dB required at that BER, so 12 dB is slightly short). QPSK is safe but wastes about half the capacity. (c) It uses probabilistic constellation shaping and/or flexible FEC rates to set the information rate continuously (e.g. ~3.5 bits/symbol) to sit just below capacity with margin — Chapter 8.
</details>

### Problem 4.6 ★★★ — Design: choosing a format for 400G in a 75 GHz slot
You must carry 400 Gb/s of net traffic in a 75 GHz DWDM slot. The FEC adds ≈15% overhead (code rate 0.87) and framing/pilots another 3%. Pulses are RRC; the signal's occupied bandwidth $(1+\beta)R_s$ must leave at least 5 GHz of guard for filter roll-off. Compare DP-QPSK, DP-16QAM and DP-64QAM: required symbol rate, required roll-off, and required SNR at a 2×10⁻² BER threshold. Which do you choose, and why?

<details><summary>Solution</summary>

Line rate needed: $400/(0.87\times0.97)\approx474$ Gb/s.

| Format | bits/symbol (DP) | $R_s$ | max β for ≤ 70 GHz | SNR at 2×10⁻² |
|---|---|---|---|---|
| DP-QPSK | 4 | 118.5 GBd | impossible (> 70 GHz even at β = 0) | 6.3 dB |
| DP-16QAM | 8 | 59.3 GBd | ≤ 0.18 | 12.7 dB |
| DP-64QAM | 12 | 39.5 GBd | ≤ 0.77 | 18.4 dB |

DP-QPSK does not fit. DP-64QAM fits easily but needs ≈ 5.7 dB more SNR, which shortens reach dramatically (Problem 3.6 shows how quickly reach falls with required SNR) and demands better DAC/ADC ENOB and laser phase noise. **DP-16QAM at ≈ 60 GBd with β ≈ 0.1** is the balanced choice — and it is essentially what the OIF 400ZR standard chose (59.84375 GBd DP-16QAM). The design logic you just followed — spectral constraint → symbol rate → format → SNR → reach — is how every transceiver generation is specified.
</details>

---

## Key takeaways

- **Line rate** = 2·log₂M·R_s for dual polarization; net rate subtracts FEC and framing overhead.
- **Nyquist criterion**: zero ISI needs pulses that vanish at all other symbol instants; raised cosine achieves it in $(1+\beta)R_s$ of bandwidth.
- **RRC + RRC** gives both zero ISI and maximum SNR (matched filter).
- **ML detection** in Gaussian noise = nearest constellation point; **Gray labelling** makes BER ≈ SER/log₂M.
- Each step QPSK → 16-QAM → 64-QAM costs ≈ 6 dB of SNR; capacity and GMI tell you how close a format gets to Shannon.

---

**Next:** Chapter 5 turns to the physics: what the optical fiber, the lasers and the receivers do to the signal, in exactly the language needed to design DSP.
