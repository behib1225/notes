"""
Generate the figures embedded in the chapters (saved to ../figures/).
Most figures are computed here directly. A few slow simulations (split-step sweeps,
back-propagation, Kramers-Kronig CSPR sweep) are plotted from the verified outputs
of their own scripts, which are cited next to each such figure.
Run:  python make_figures.py    (about 2 minutes)
"""
import numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.signal import welch, firwin, freqz
import optdsp as od

FIG = "../figures/"
rng = np.random.default_rng(0)
def save(name):
    plt.tight_layout(); plt.savefig(FIG + name, dpi=110); plt.close(); print("saved", name)

# ======================= Chapter 1 =======================
Rs, sps = 32e9, 8
plt.figure(figsize=(6.5, 3.5))
for beta in [0.1, 0.5]:
    s = od.bits_to_symbols(rng.integers(0, 2, 2 * 2**16), 4)
    x = od.filter_same(od.upsample(s, sps), od.rrc_taps(beta, sps, 64))
    f, P = welch(x, fs=sps * Rs, nperseg=4096, return_onesided=False)
    f, P = np.fft.fftshift(f), np.fft.fftshift(P)
    plt.plot(f / 1e9, 10 * np.log10(P / P.max()), label=f"roll-off β = {beta}")
plt.axvline(-16, color="k", ls=":", lw=.8); plt.axvline(16, color="k", ls=":", lw=.8)
plt.text(17, -5, "±Rs/2", fontsize=8)
plt.xlim(-40, 40); plt.ylim(-60, 3); plt.xlabel("frequency relative to carrier (GHz)")
plt.ylabel("PSD (dB)"); plt.title("32 GBd QPSK: complex-baseband spectrum"); plt.legend(); plt.grid(alpha=.3)
save("ch1_qam_spectrum.png")

fs, N = 100.0, 256; n = np.arange(N)
x = np.exp(2j * np.pi * 10.3 * n / fs) + 1e-3 * np.exp(2j * np.pi * 25 * n / fs)
plt.figure(figsize=(6.5, 3.5))
for name, w in [("rectangular window", np.ones(N)), ("Blackman window", np.blackman(N))]:
    X = np.fft.fftshift(np.fft.fft(x * w, 8 * N)); f = np.fft.fftshift(np.fft.fftfreq(8 * N, 1 / fs))
    plt.plot(f, 20 * np.log10(np.abs(X) / np.abs(X).max() + 1e-12), label=name)
plt.annotate("weak tone (−60 dB)", xy=(25, -60), xytext=(28, -30), arrowprops=dict(arrowstyle="->"))
plt.xlim(0, 50); plt.ylim(-120, 5); plt.xlabel("frequency (Hz)"); plt.ylabel("dB")
plt.title("Leakage: the window decides whether the weak tone is visible"); plt.legend(); plt.grid(alpha=.3)
save("ch1_leakage.png")

# ======================= Chapter 2 =======================
h = firwin(63, 0.25, window=("kaiser", 8.0)); w, H = freqz(h, worN=4096)
plt.figure(figsize=(6.5, 3.2))
plt.plot(w / np.pi, 20 * np.log10(np.abs(H) + 1e-12)); plt.ylim(-120, 5)
plt.xlabel("normalised frequency (×π rad/sample)"); plt.ylabel("|H| (dB)")
plt.title("63-tap Kaiser low-pass FIR (cutoff 0.25π)"); plt.grid(alpha=.3)
save("ch2_fir_response.png")

h_true = np.array([0.1, -0.3, 1.0, 0.5, -0.2]); Nt = 5
xx = rng.standard_normal(20000); d = np.convolve(xx, h_true)[:len(xx)] + 0.01 * rng.standard_normal(len(xx))
plt.figure(figsize=(6.5, 3.5))
for mu in [0.001, 0.01, 0.05, 0.3]:
    ww = np.zeros(Nt); err = []
    for k in range(Nt, len(xx)):
        xv = xx[k - Nt + 1:k + 1][::-1]; e = d[k] - ww @ xv; ww += mu * e * xv; err.append(e ** 2)
    plt.semilogy(np.convolve(err, np.ones(200) / 200, "valid"), label=f"μ = {mu}")
plt.axhline(1e-4, color="k", ls="--", lw=.8); plt.text(15000, 1.3e-4, "noise floor", fontsize=8)
plt.xlabel("iteration"); plt.ylabel("smoothed squared error"); plt.legend(); plt.grid(alpha=.3)
plt.title("LMS: step size trades speed against steady-state error")
save("ch2_lms_convergence.png")

# ======================= Chapter 3 =======================
fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
t = np.arange(20000) / 32e9 * 1e6
for i in range(5):
    ax[0].plot(t, od.laser_phase_noise(20000, 1e6, 32e9, rng))
ax[0].set_xlabel("time (µs)"); ax[0].set_ylabel("phase (rad)"); ax[0].set_title("Wiener phase noise, Δν = 1 MHz")
P = np.array([od.laser_phase_noise(5000, 1e6, 32e9, rng) for _ in range(500)])
ax[1].plot(np.arange(5000), P.var(axis=0), label="simulated variance")
ax[1].plot(np.arange(5000), 2 * np.pi * 1e6 / 32e9 * np.arange(5000), "k--", label="2πΔν·n·Ts")
ax[1].set_xlabel("sample n"); ax[1].set_ylabel("Var{φ[n]} (rad²)"); ax[1].legend(); ax[1].set_title("variance grows linearly")
for a in ax: a.grid(alpha=.3)
save("ch3_phase_noise.png")

# ======================= Chapter 4 =======================
fig, ax = plt.subplots(1, 3, figsize=(11, 3.8))
for a, M in zip(ax, [4, 16, 64]):
    c, bm = od.qam_constellation(M)
    y = od.add_awgn(c[rng.integers(0, M, 3000)], {4: 12, 16: 20, 64: 28}[M])
    a.plot(y.real, y.imag, ".", ms=1, alpha=.4); a.plot(c.real, c.imag, "r+", ms=6)
    if M == 16:
        for i in range(16):
            a.text(c[i].real + .03, c[i].imag + .06, "".join(map(str, bm[i])), fontsize=7)
    a.set_aspect("equal"); a.set_title(f"{M}-QAM (Gray labels)" if M == 16 else f"{M}-QAM"); a.grid(alpha=.3)
save("ch4_constellations.png")

fig, ax = plt.subplots(1, 2, figsize=(10, 3.5))
tt = np.linspace(-6, 6, 2001)
for beta in [0.0, 0.35, 1.0]:
    with np.errstate(divide="ignore", invalid="ignore"):
        p = np.sinc(tt) * np.cos(np.pi * beta * tt) / (1 - (2 * beta * tt) ** 2)
    p[~np.isfinite(p)] = (np.pi / 4) * np.sinc(1 / (2 * beta)) if beta > 0 else 1
    ax[0].plot(tt, p, label=f"β = {beta}")
    ff = np.linspace(-1, 1, 1000)
    Hf = np.where(np.abs(ff) <= (1 - beta) / 2, 1.0,
                  np.where(np.abs(ff) <= (1 + beta) / 2,
                           0.5 * (1 + np.cos(np.pi / max(beta, 1e-9) * (np.abs(ff) - (1 - beta) / 2))), 0.0))
    ax[1].plot(ff, Hf, label=f"β = {beta}")
ax[0].plot(np.arange(-6, 7), np.r_[np.zeros(6), 1, np.zeros(6)], "ko", ms=4, label="sampling instants")
ax[0].set_xlabel("time (symbols)"); ax[0].set_title("raised-cosine pulses: zero at all other symbol instants")
ax[1].set_xlabel("frequency (× Rs)"); ax[1].set_title("raised-cosine spectra: width (1+β)Rs")
for a in ax: a.legend(fontsize=8); a.grid(alpha=.3)
save("ch4_raised_cosine.png")

fig, ax = plt.subplots(1, 2, figsize=(10, 3.5)); sp = 16
s4 = od.pam_levels(4)[rng.integers(0, 4, 2000)]
for a, beta in zip(ax, [0.1, 1.0]):
    hh = od.rrc_taps(beta, sp, 32)
    y = od.filter_same(od.filter_same(od.upsample(s4, sp), hh), hh).real * sp ** 0.5 / sp ** 0.5
    y = y / np.std(y[::sp]) * np.std(s4)
    for k in range(100, 500):
        a.plot(np.arange(2 * sp + 1) / sp, y[k * sp + sp // 2: k * sp + sp // 2 + 2 * sp + 1], "b", alpha=.05)
    a.set_title(f"PAM4 eye, raised cosine β = {beta}"); a.set_xlabel("time (symbols)"); a.grid(alpha=.3)
save("ch4_eye_diagrams.png")

snrs = np.arange(0, 27, 1.0); plt.figure(figsize=(6.5, 4))
for M in [4, 16, 64]:
    k = int(np.log2(M)); sim = []
    for snr in snrs:
        b = rng.integers(0, 2, k * 60000); s = od.bits_to_symbols(b, M)
        sim.append(od.ber_count(od.add_awgn(s, snr, rng=rng), s, M))
    plt.semilogy(snrs, sim, "o", ms=4, label=f"{M}-QAM simulated")
    plt.semilogy(snrs, od.ber_qam_theory(M, snrs), "-", label=f"{M}-QAM formula")
plt.axhline(2e-2, color="r", lw=.8); plt.text(0.5, 2.5e-2, "2×10⁻² (oFEC-like)", color="r", fontsize=8)
plt.axhline(3.8e-3, color="g", lw=.8); plt.text(0.5, 4.5e-3, "3.8×10⁻³ (7% HD-FEC)", color="g", fontsize=8)
plt.ylim(1e-5, .5); plt.xlabel("Es/N0 (dB)"); plt.ylabel("BER"); plt.grid(alpha=.3, which="both")
plt.legend(fontsize=8); plt.title("BER of Gray-coded square QAM in AWGN")
save("ch4_ber_curves.png")

snrs = np.arange(-2, 27, 1.0); plt.figure(figsize=(6.5, 4))
plt.plot(snrs, np.log2(1 + 10 ** (snrs / 10)), "k", lw=2, label="Shannon log₂(1+SNR)")
for M in [4, 16, 64]:
    k = int(np.log2(M)); g = []
    for snr in snrs:
        b = rng.integers(0, 2, (20000, k)); s = od.bits_to_symbols(b.ravel(), M)
        g.append(od.gmi_awgn(od.add_awgn(s, snr, rng=rng), b, M, snr))
    plt.plot(snrs, g, label=f"{M}-QAM GMI")
plt.xlabel("SNR (dB)"); plt.ylabel("bits per symbol per polarization"); plt.grid(alpha=.3); plt.legend()
plt.title("GMI of uniform QAM vs Shannon capacity")
save("ch4_gmi_capacity.png")

# ======================= Chapter 5 =======================
fsx = 32 * 64e9; tp = np.arange(-2048, 2048) / fsx
pulse = np.exp(-(tp / 10e-12) ** 2 / 2).astype(complex)
plt.figure(figsize=(6.5, 3.5))
for L in [0, 2, 5, 10]:
    y = od.cd_channel(pulse, fsx, L * 1e3)
    plt.plot(tp * 1e12, np.abs(y) ** 2, label=f"{L} km")
plt.xlim(-150, 150); plt.xlabel("time (ps)"); plt.ylabel("power (a.u.)")
plt.title("Chromatic dispersion spreads a 10-ps pulse (SSMF, 1550 nm)"); plt.legend(); plt.grid(alpha=.3)
save("ch5_cd_broadening.png")

f = np.linspace(0, 60e9, 2000); b2 = od.beta2_from_D()
plt.figure(figsize=(6.5, 3.5))
for L in [2, 5, 10]:
    Hh = np.abs(np.cos(b2 * L * 1e3 * (2 * np.pi * f) ** 2 / 2))
    plt.plot(f / 1e9, 20 * np.log10(Hh + 1e-6), label=f"{L} km")
plt.axvline(28, color="k", ls=":", lw=.8); plt.text(28.5, -35, "Nyquist of 56 GBd", fontsize=8)
plt.ylim(-40, 3); plt.xlabel("electrical frequency (GHz)"); plt.ylabel("|H_IM(f)| (dB)")
plt.title("IM/DD power fading: |cos(β₂Lω²/2)|, C-band SSMF"); plt.legend(); plt.grid(alpha=.3)
save("ch5_power_fading.png")

P = np.array([-4, -2, 0, 2, 4, 6, 8])            # from code/ch5_launch_power_sweep.py (verified run)
snr_ssfm = np.array([21.3, 21.8, 20.4, 17.4, 13.5, 9.4, 4.9]); snr_ase = 22.0 + 1.0 * (P + 4)
plt.figure(figsize=(6.5, 3.8))
plt.plot(P, snr_ase, "k--", label="ASE only (γ = 0)"); plt.plot(P, snr_ssfm, "o-", label="split-step (with Kerr)")
plt.annotate("optimum", xy=(-2, 21.8), xytext=(1, 25), arrowprops=dict(arrowstyle="->"))
plt.text(3.5, 29, "slope +1 dB/dB", fontsize=8); plt.text(5, 12, "slope −2 dB/dB", fontsize=8)
plt.xlabel("launch power per channel (dBm)"); plt.ylabel("SNR (dB)"); plt.grid(alpha=.3); plt.legend()
plt.title("10×80 km, 32 GBd single channel: the launch-power optimum")
save("ch5_launch_power.png")

# ======================= Chapter 6 =======================
from capstone_coherent_link import run_link
import capstone_coherent_link as cap
# constellation after each receiver stage (re-run the chain manually, DP-16QAM)
rng2 = np.random.default_rng(7); M = 16; Rs = 32e9; sps_tx = 4; fs_tx = 4 * Rs
data = [od.bits_to_symbols(rng2.integers(0, 2, 4 * 2**15), M) for _ in range(2)]
frames = [od.build_frames(data[p], pol=p) for p in range(2)]
sym = np.vstack([f[0] for f in frames]); info = [f[1] for f in frames]
hh = od.rrc_taps(0.1, 4, 64)
tx = np.vstack([od.filter_same(od.upsample(sym[p], 4), hh) for p in range(2)])
ch = od.sop_dynamic(od.pmd_first_order(od.cd_channel(tx, fs_tx, 800e3), fs_tx, 10e-12, rng2), fs_tx, 1e4, rng2)
ch = np.vstack([od.add_awgn(ch[p], 22 + 10 * np.log10(12.5 / 32), sps=4, rng=rng2) for p in range(2)])
nn = np.arange(ch.shape[1]); ch = ch * np.exp(1j * (2 * np.pi * 1.2e9 * nn / fs_tx + od.laser_phase_noise(len(nn), 2e5, fs_tx, rng2)))
g = firwin(129, 0.75 * Rs / (fs_tx / 2)); ch = np.vstack([od.filter_same(ch[p], g) for p in range(2)])
rx = np.vstack([od.adc_sample(ch[p], 4, 2, 20, 0.6) for p in range(2)])
st = {}
st["1. ADC samples"] = rx[0, ::2]
rx = od.cd_channel(rx, 2 * Rs, 800e3, compensate=True)
rx = np.vstack([od.filter_same(rx[p], od.rrc_taps(0.1, 2, 64)) for p in range(2)]); rx /= np.sqrt(np.mean(abs(rx) ** 2))
st["2. after CD compensation"] = rx[0, ::2]
rx, trace = od.gardner_timing_recovery(rx); rx /= np.sqrt(np.mean(abs(rx) ** 2))
st["3. after timing recovery"] = rx[0, ::2]
y, _ = od.cma_butterfly(rx, 15, 1e-3, 2, 1.32)
st["4. after 2×2 CMA"] = y[0]
dfe_ = od.foe_4th_power(y[0, 12000:], Rs); yp = y[0] * np.exp(-2j * np.pi * dfe_ * np.arange(y.shape[1]) / Rs)
st["5. after FOE"] = yp
yp /= np.sqrt(np.mean(abs(yp[12000:]) ** 2))
cands = [(od.frame_sync(yp, info[q], 12000), q) for q in range(2)]; (dd, pk), q = max(cands, key=lambda c: c[0][1])
pil = info[q]["ref_pos"] + dd; ok = (pil >= 0) & (pil < len(yp))
z, phi, phi_p = od.pilot_aided_cpr(yp, pil[ok], info[q]["ref_val"][ok], M, avg_pilots=5)
st["6. after pilot-aided CPR"] = z
fig, ax = plt.subplots(2, 3, figsize=(10, 6.6))
for a, (k_, v) in zip(ax.ravel(), st.items()):
    vv = v[14000:20000]; vv = vv / np.sqrt(np.mean(abs(vv) ** 2))
    a.plot(vv.real, vv.imag, ".", ms=1, alpha=.3); a.set_title(k_, fontsize=10)
    a.set_xlim(-2, 2); a.set_ylim(-2, 2); a.set_aspect("equal"); a.grid(alpha=.3)
plt.suptitle("DP-16QAM, 800 km: X-output constellation after each receiver stage")
save("ch6_dsp_stages.png")

fig, ax = plt.subplots(1, 2, figsize=(10, 3.4))
ax[0].plot(trace * 1e6); ax[0].axhline(20, color="k", ls="--", lw=.8); ax[0].axvline(8000, color="r", ls=":", lw=.8); ax[0].text(8300, 60, "gear shift", color="r", fontsize=8); ax[0].set_xlabel("symbol"); ax[0].set_ylabel("clock-offset estimate (ppm)")
ax[0].set_title("timing loop learns the 20 ppm clock offset"); ax[0].grid(alpha=.3)
seg = slice(12000, 14000)
ax[1].plot(np.arange(len(phi))[seg], phi[seg], label="final phase estimate")
ax[1].plot(np.arange(len(phi_p))[seg], phi_p[seg], "--", label="pilot-based estimate")
ax[1].set_xlabel("symbol"); ax[1].set_ylabel("phase (rad)"); ax[1].legend(); ax[1].grid(alpha=.3)
ax[1].set_title("pilot-aided CPR: BPS detail, pilot-anchored")
save("ch6_timing_and_cpr.png")

sps_g, beta_g = 8, 0.3; hr = od.rrc_taps(beta_g, sps_g, 32)
sg = od.bits_to_symbols(rng.integers(0, 2, 2 * 20000), 4)
yg = od.filter_same(od.filter_same(od.upsample(sg, sps_g), hr), hr)
offs = np.arange(-8, 9); ev = []
for off in offs:
    y2 = yg[96 + off::sps_g // 2][:30000]
    ev.append(np.mean(np.real(y2[1:-1:2] * np.conj(y2[0:-2:2] - y2[2::2]))))
plt.figure(figsize=(6, 3.3)); plt.plot(offs / 8, ev, "o-"); plt.axhline(0, color="k", lw=.6); plt.axvline(0, color="k", lw=.6)
plt.xlabel("sampling-time error τ / T (positive = late)"); plt.ylabel("mean Gardner error")
plt.title("Gardner S-curve (QPSK, β = 0.3): stable lock at τ = 0"); plt.grid(alpha=.3)
save("ch6_gardner_scurve.png")

B = [1, 4, 16, 32, 64, 256, 1024]                     # from code/ch6_extra.py (verified run)
ber = [0.48, 0.41, 1.0e-3, 9.1e-4, 8.9e-4, 1.3e-3, 0.25]
plt.figure(figsize=(6, 3.3)); plt.loglog(B, ber, "o-"); plt.axhline(7.8e-4, color="k", ls="--", lw=.8)
plt.text(1.2, 1e-3 * 0.6, "no phase noise", fontsize=8)
plt.xlabel("Viterbi–Viterbi block length (symbols)"); plt.ylabel("BER")
plt.title("QPSK, 10 dB, Δν·T = 6.25e-5: noise vs tracking"); plt.grid(alpha=.3, which="both")
save("ch6_vv_block.png")

# ======================= Chapter 7 =======================
import ch7_imdd as im
fig, ax = plt.subplots(1, 3, figsize=(11, 3.4))
for a, (lab, kw, eq) in zip(ax, [("back-to-back", {}, False), ("bandwidth 0.4·Rs, no EQ", dict(bw=0.4), False),
                                  ("bandwidth 0.4·Rs, after FFE", dict(bw=0.4), True)]):
    I, idx, h = im.imdd_channel(n_sym=20000, **kw)
    r = im.receive(I, idx, h, 24.0)
    if eq:
        r, _ = im.ffe(r, idx)
    a.hist(r[5000:-200], bins=200, orientation="horizontal", color="C0")
    a.set_ylim(-5, 5); a.set_title(lab, fontsize=10); a.set_xlabel("count"); a.grid(alpha=.3)
ax[0].set_ylabel("decision sample")
plt.suptitle("PAM4 decision-sample histograms (SNR_el = 24 dB): ISI smears the levels, the FFE restores them")
save("ch7_pam4_histograms.png")

cspr = [4, 6, 8, 10, 12, 14, 16]                      # from code/ch7_kk_receiver.py (verified run)
kk = [16.0, 23.7, 34.3, 43.7, 46.1, 46.3, 46.3]; naive = [10.1, 12.9, 15.3, 17.5, 19.6, 21.7, 23.7]
kkn = [6.1, 8.3, 11.7, 15.2, 16.0, 15.2, 13.5]
plt.figure(figsize=(6.5, 3.6))
plt.plot(cspr, kk, "o-", label="KK, no noise"); plt.plot(cspr, naive, "s-", label="naive SSB (SSBI-limited)")
plt.plot(cspr, kkn, "^-", label="KK, thermal noise, fixed power")
plt.xlabel("carrier-to-signal power ratio (dB)"); plt.ylabel("SNR (dB)"); plt.grid(alpha=.3); plt.legend(fontsize=8)
plt.title("Kramers–Kronig receiver, SSB 16-QAM, 80 km C-band")
save("ch7_kk_cspr.png")

# ======================= Chapter 8 =======================
ebn0 = [0.5, 1.0, 1.5, 2.0, 2.5]                      # from code/ch8_ldpc.py (verified run)
post = [1.09e-1, 6.42e-2, 1.73e-2, 9.52e-4, 1e-6]
unc = [od.qfunc(np.sqrt(2 * 10 ** (e / 10))) for e in np.linspace(0, 10, 50)]
plt.figure(figsize=(6.5, 3.8))
plt.semilogy(np.linspace(0, 10, 50), unc, "k", label="uncoded BPSK")
plt.semilogy(ebn0[:-1], post[:-1], "o-", label="(3,6) LDPC n=1008, min-sum")
plt.annotate("no errors in 2.5×10⁵ bits", xy=(2.5, 2e-6), xytext=(3.5, 1e-5), arrowprops=dict(arrowstyle="->"), fontsize=8)
plt.axvline(0.19, color="r", ls="--", lw=.8); plt.text(0.25, 1e-5, "Shannon limit\n(rate ½, BPSK)", color="r", fontsize=8)
plt.ylim(1e-6, 0.3); plt.xlim(0, 10); plt.xlabel("Eb/N0 (dB)"); plt.ylabel("BER after decoding")
plt.grid(alpha=.3, which="both"); plt.legend(); plt.title("The LDPC 'waterfall'")
save("ch8_ldpc_waterfall.png")

c64, _ = od.qam_constellation(64)
fig, ax = plt.subplots(1, 3, figsize=(10, 3.5))
for a, lam in zip(ax, [0.0, 1.0, 2.26]):
    p = np.exp(-lam * np.abs(c64) ** 2); p /= p.sum(); H = -np.sum(p * np.log2(p))
    a.scatter(c64.real, c64.imag, s=3000 * p, alpha=.7); a.set_aspect("equal")
    a.set_title(f"λ = {lam}: entropy {H:.2f} bits", fontsize=10); a.grid(alpha=.3)
plt.suptitle("Maxwell–Boltzmann shaping of 64-QAM (dot area ∝ probability)")
save("ch8_pcs.png")

Pd = [-2, 0, 2, 4, 6]                                 # from code/ch8_fec_shaping.py (verified run)
plt.figure(figsize=(6.5, 3.6))
plt.plot(Pd, [21.8, 20.4, 17.4, 13.5, 9.4], "o-", label="CD compensation only")
plt.plot(Pd, [22.5, 21.8, 19.2, 15.5, 11.2], "s-", label="DBP, 1 step/span")
plt.plot(Pd, [24.0, 26.0, 27.9, 29.7, 31.0], "^-", label="DBP, 10 steps/span")
plt.plot(Pd, [24, 26, 28, 30, 32], "k--", label="ASE only")
plt.xlabel("launch power (dBm)"); plt.ylabel("SNR (dB)"); plt.legend(fontsize=8); plt.grid(alpha=.3)
plt.title("Single-channel DBP (idealised: no WDM, no PMD)")
save("ch8_dbp.png")

import ch8_fixed_point as fx
bits = [3, 4, 5, 6, 8]; plt.figure(figsize=(6.5, 3.6))
for clip in [2, 3, 4, 6]:
    plt.plot(bits, [fx.adc_experiment(b, clip) for b in bits], "o-", label=f"full scale = {clip}× rms")
plt.axhline(20, color="k", ls="--", lw=.8); plt.xlabel("ADC bits"); plt.ylabel("SNR after DSP (dB)")
plt.legend(fontsize=8); plt.grid(alpha=.3); plt.title("ADC resolution and clipping (16-QAM, 800 km, 20 dB channel)")
save("ch8_adc_bits.png")
