"""
Chapter 8: fixed-point effects -- ADC resolution and clipping.
A 32 GBd single-polarization 16-QAM signal passes 800 km of fiber (so the received
waveform is Gaussian-like, with a high peak-to-average ratio) and ASE noise giving
20 dB SNR. The ADC quantises I and Q with `bits` bits and full scale = clip x rms.
The DSP (CD compensation + matched filter) is ideal floating point.
Run:  python ch8_fixed_point.py
"""
import numpy as np
import optdsp as od

def adc_experiment(bits, clip, snr_db=20.0, seed=0):
    rng = np.random.default_rng(seed)
    s = od.bits_to_symbols(rng.integers(0, 2, 4 * 2**14), 16)
    h = od.rrc_taps(0.1, 2, 64)
    x = od.filter_same(od.upsample(s, 2), h)
    x = od.cd_channel(x, 64e9, 800e3)
    x = od.add_awgn(x, snr_db, sps=2, rng=rng)
    if bits is not None:
        x = od.quantize(x, bits, clip)
    y = od.filter_same(od.cd_channel(x, 64e9, 800e3, compensate=True), h)[::2]
    return od.snr_estimate_db(y[200:-200], s[200:-200])

if __name__ == "__main__":
    print(f"floating point: {adc_experiment(None, None):.2f} dB (channel SNR 20 dB)")
    print("bits  clip=2   clip=3   clip=4   clip=6   (SNR in dB after DSP)")
    for b in [3, 4, 5, 6, 8]:
        print(f"{b:3d}  " + "  ".join(f"{adc_experiment(b, c):6.2f}" for c in [2, 3, 4, 6]))
