﻿# Chapter 8 · Sequential Decisions and Value-Based RL

2026-09-22 · @Behi

Everything so far assumed the data was given and the objective was to fit it. This chapter changes the setting: an agent acts, the world responds, and the agent's own choices determine what data it ever sees. That feedback loop is what separates reinforcement learning from supervised learning, and it is the mathematical core of agentic AI.

The chapter's spine is short: **a value function is a conditional expectation, the Bellman equation is the tower property, and every algorithm here is a way of solving that equation when you cannot write it down.**

## 8.1 The MDP formalism

### The five pieces

A **Markov decision process** is a tuple (S, A, P, R, gamma):

| Symbol | Name | Meaning |
| --- | --- | --- |
| S | state space | everything the agent can be in |
| A | action space | what the agent can do |
| P(s' \| s, a) | transition kernel | how the world responds |
| R(s, a) | reward function | the scalar signal being maximized |
| gamma in \[0,1\] | discount factor | how much the future counts |

The interaction loop: observe s\_t, choose a\_t, receive r\_t, land in s\_{t+1}, repeat.

```mermaid
flowchart LR
  A["Agent<br/>policy pi(a|s)"] -->|"action a_t"| E["Environment<br/>P(s'|s,a), R(s,a)"]
  E -->|"reward r_t"| A
  E -->|"next state s_t+1"| A
```

The loop is what makes this different from supervised learning: the arrow from the agent back into the environment means **the agent's own choices determine the data it will ever see.** Nothing in Chapters 3 and 4 assumed that, and it is the source of every difficulty listed at the end of this section.

### The Markov property, and what it really requires

$$
P(s_{t+1} \mid s_t, a_t, s_{t-1}, a_{t-1}, \ldots) = P(s_{t+1} \mid s_t, a_t)
$$

**The state contains everything relevant about the past.** This is not a restriction on the world; it is a requirement on your *definition of the state*. Any process can be made Markov by putting enough history into the state — the question is whether the resulting state is small enough to be useful.

That reframing is the important one and a good interview answer. Examples:

- A single video frame is not Markov for a game with moving objects (you cannot see velocity). Stack four frames and it becomes approximately Markov. This is exactly what the original DQN did, and the frame stack is a Markov-property fix, not an arbitrary implementation detail.
- A chess position plus whose turn it is, castling rights and the repetition count is Markov; the board alone is not.
- In an LLM agent, the conversation so far plus retrieved documents plus tool outputs is the state. It is Markov by construction because everything is in the context, which is a genuinely useful way to think about why agent frameworks look the way they do.

### When the state is hidden: POMDPs

A **partially observable MDP** adds an observation space and an observation model: the agent sees o\_t rather than s\_t. Now the optimal policy is generally **not** a function of the current observation, because the observation does not determine the situation.

The formally correct move is to act on the **belief state**, the posterior over true states given the whole history, which *is* Markov. The difficulty is that the belief state is a distribution, so the belief MDP is continuous and high-dimensional even when the original is small.

The practical move is to carry a learned summary of history: a recurrent state, a transformer over the observation history, or simply a long context window. **Every agentic system built on a language model is doing this** — the context window is an approximate belief state — which is why context management, summarization and retrieval are not engineering conveniences but attempts to maintain a sufficient statistic of history.

### Why rewards are scalar

Students reasonably object that real goals are multi-dimensional. The formal defence is the **reward hypothesis**: that goals and purposes can be represented as maximization of expected cumulative scalar reward. It is a hypothesis, not a theorem, and it is worth being able to argue both sides.

For it: any consistent preference ordering over outcomes satisfying certain axioms is representable by a scalar utility (von Neumann-Morgenstern), and comparing two trajectories ultimately requires a single ordering, so some scalarization is unavoidable.

Against it: the scalarization may be extremely hard to specify, multi-objective problems have Pareto fronts rather than single optima, and **reward misspecification is the dominant practical failure mode**. An agent maximizes what you wrote, not what you meant, which is the mechanism behind reward hacking. That is precisely why RLHF learns a reward model from comparisons rather than hand-specifying one, and why it needs a KL constraint (Chapter 5) to stop the policy exploiting that learned model's errors.

### The taxonomy, so the vocabulary is clear

| Axis | Options |
| --- | --- |
| Model | **model-based** (you know or learn P and R) vs **model-free** |
| What is learned | **value-based** (learn Q, act greedily) vs **policy-based** (learn pi directly) vs **actor-critic** (both) |
| Data source | **on-policy** (learn from your current policy's data) vs **off-policy** (learn from other data) |
| Horizon | **episodic** (terminates) vs **continuing** (infinite) |
| Spaces | discrete vs continuous, in states and in actions |

This chapter covers model-based dynamic programming and value-based model-free methods. Chapter 9 covers policy-based and actor-critic methods, which is where modern agentic AI lives.

### Why RL is harder than supervised learning

Four differences, all of which cause real difficulty:

1. **No labels, only evaluative feedback.** You learn that an action scored 3, not that a different action would have scored 7. This is bandit feedback, and it is strictly less informative than a label.
2. **Delayed consequences.** The reward may arrive a hundred steps after the decision that caused it — the **credit assignment** problem, and the reason value functions exist.
3. **The data distribution depends on the policy.** Change the policy and you change what you observe, so the i.i.d. assumption underlying Chapters 3 and 4 fails completely. This is why RL training is unstable in ways supervised learning is not.
4. **Exploration versus exploitation.** You must sometimes take actions you believe are worse in order to learn whether they are.

**Try it.** (a) Is a single frame of Pong a Markov state? What minimal change fixes it? (b) Give an example where reward misspecification would produce a technically optimal but useless policy. (c) Why does the dependence of the data distribution on the policy break the standard supervised learning analysis? Answers in 8.11.

## 8.2 Returns, discounting, value functions

### The return

The agent maximizes not the next reward but the **discounted cumulative return**:

$$
G_t = r_t + \gamma r_{t+1} + \gamma^2 r_{t+2} + \cdots = \sum_{k=0}^{\infty}\gamma^k r_{t+k}
$$

### Why discount, four reasons

This is a question interviewers ask precisely because most people give only the first answer.

1. **Mathematical convergence.** With bounded rewards, the geometric sum converges for gamma < 1 and may not otherwise. Without it, "infinite reward" comparisons are undefined.
2. **Uncertainty about the future.** Discounting by gamma is exactly equivalent to an undiscounted problem in which the episode terminates at each step with probability 1 - gamma. The geometric distribution is the memoryless one (Chapter 3), which is why a *constant* discount gives a *time-invariant* value function with no explicit time index.
3. **Preference for sooner rewards**, which matches both economics and most real objectives.
4. **Variance reduction.** A shorter effective horizon means fewer random terms in the sum, so estimates are less noisy. This is why practitioners sometimes use a gamma below the "true" one deliberately: it biases the objective but makes learning tractable.

**The effective horizon** is the number worth carrying:

$$
\text{horizon} \approx \frac{1}{1 - \gamma}
$$

gamma = 0.9 gives about 10 steps, 0.99 about 100, 0.999 about 1,000. **Gamma is not an arbitrary knob; it is a statement about how far ahead the agent plans.** If your task needs credit assigned over 500 steps, gamma = 0.99 cannot do it, and no amount of training will fix that.

The maximum possible value is also worth knowing, since it tells you the scale your network must represent: with rewards bounded by r\_max, values are bounded by r\_max/(1 - gamma). At gamma = 0.999 that is a thousandfold amplification, which is one reason reward scaling and value normalization matter in practice.

### Policies

A policy maps states to action distributions: pi(a | s). Deterministic policies are the special case with all mass on one action.

A fact worth stating: **for a fully observed MDP there is always an optimal policy that is deterministic and stationary.** Randomization buys nothing when you know the state. Stochastic policies are still essential in practice for three reasons: exploration, partial observability (where randomizing can genuinely help), and differentiability, which Chapter 9 depends on entirely.

### Value functions

$$
V^{\pi}(s) = \mathbb{E}_{\pi}\big[ G_t \mid s_t = s \big], \qquad Q^{\pi}(s,a) = \mathbb{E}_{\pi}\big[ G_t \mid s_t = s,\, a_t = a \big]
$$

**A value function is a conditional expectation.** That sentence connects this entire chapter to Chapter 3, and everything that follows is a consequence of the tower property.

The distinction between them is where all the algorithmic content lives. V tells you how good a state is; Q tells you how good each action is from that state. **Q is what you can act on without a model**, because acting greedily on Q requires only a maximization over actions, whereas acting greedily on V requires knowing where each action leads:

$$
\pi(s) = \arg\max_a Q(s,a) \qquad \text{versus} \qquad \pi(s) = \arg\max_a \mathbb{E}_{s'}\big[r + \gamma V(s')\big]
$$

The second needs P. **That is why model-free control learns Q rather than V**, and it is a clean, specific answer to "why Q-learning and not V-learning?"

They are related by

$$
V^{\pi}(s) = \sum_a \pi(a\mid s)\,Q^{\pi}(s,a) = \mathbb{E}_{a\sim\pi}\big[Q^{\pi}(s,a)\big]
$$

### The advantage function

$$
A^{\pi}(s,a) = Q^{\pi}(s,a) - V^{\pi}(s)
$$

**How much better than average is this action, from this state?** Its defining property is that its expectation under the policy is exactly zero, since V is the policy-weighted average of Q.

That zero-mean property is what makes the advantage the right quantity for policy gradients, and it is precisely the control-variate argument from Chapter 3: subtracting V(s) from Q(s,a) leaves the policy gradient unbiased (because the expected score function is zero) while removing the large state-dependent component of the variance. A state worth 100 and a state worth 1 both contribute advantages near zero for average actions, so the learning signal is about the *choice*, not about which state you happen to be in. Chapter 9 uses this constantly.

### An example worth working

Consider a two-state chain: state A gives reward 0 and moves to B; state B gives reward 1 and returns to A. With gamma = 0.9:

$$
V(A) = 0 + \gamma V(B), \qquad V(B) = 1 + \gamma V(A)
$$

Substituting, V(A) = gamma(1 + gamma V(A)), so V(A)(1 - gamma^2) = gamma, giving V(A) = 0.9/0.19 = 4.74 and V(B) = 1 + 0.9(4.74) = 5.26. Sanity checks: B is worth about 0.53 more than A, which is the immediate reward difference of 1 damped by the fact that you alternate; and the average value 5 matches the total discounted reward of a stream averaging 0.5 per step, namely 0.5/(1 - 0.9) = 5. **Always sanity-check values against r/(1-gamma)**; it catches sign errors and gamma mistakes immediately.

**Try it.** (a) What effective horizon does gamma = 0.95 give, and what does that mean for a task whose reward arrives after 200 steps? (b) Why can you act greedily with respect to Q without a model but not with respect to V? (c) Show that the expected advantage under the policy is zero. Answers in 8.11.

## 8.3 The Bellman equations

### The idea, in one sentence

The return from here equals the reward now plus the discounted return from wherever you land. That is all the Bellman equation says, and writing it down carefully turns an infinite sum into a finite recursion.

### Derivation from the tower property

Start from the definition and split off the first term:

$$
V^{\pi}(s) = \mathbb{E}\big[ r_t + \gamma r_{t+1} + \gamma^2 r_{t+2} + \cdots \mid s_t = s\big] = \mathbb{E}\big[ r_t + \gamma G_{t+1} \mid s_t = s \big]
$$

Now condition on the next state and apply the **tower property** from Chapter 3 — E\[X\] = E\[E\[X | Y\]\]:

$$
\mathbb{E}\big[G_{t+1} \mid s_t = s\big] = \mathbb{E}\Big[\, \mathbb{E}\big[G_{t+1} \mid s_{t+1}\big] \,\Big|\, s_t = s \Big] = \mathbb{E}\big[ V^{\pi}(s_{t+1}) \mid s_t = s \big]
$$

The inner expectation is exactly V(s\_{t+1}) by definition, and the Markov property is what licenses dropping the earlier history. Putting it together:

$$
V^{\pi}(s) = \sum_a \pi(a\mid s)\sum_{s'} P(s'\mid s,a)\Big[ R(s,a) + \gamma V^{\pi}(s') \Big]
$$

**The Bellman equation is the tower property plus the Markov property.** If you can say that and reproduce the two lines above, you understand it rather than remember it.

The Q version:

$$
Q^{\pi}(s,a) = R(s,a) + \gamma \sum_{s'} P(s'\mid s,a) \sum_{a'}\pi(a'\mid s')\,Q^{\pi}(s',a')
$$

### The optimality equations

For the optimal value function, replace the average over the policy's actions with a maximum:

$$
V^{*}(s) = \max_a \Big[ R(s,a) + \gamma\sum_{s'}P(s'\mid s,a)\,V^{*}(s') \Big]
$$

$$
Q^{*}(s,a) = R(s,a) + \gamma\sum_{s'}P(s'\mid s,a)\,\max_{a'}Q^{*}(s',a')
$$

**The max is the entire difference, and it changes everything.** Two consequences:

1. **The equations become nonlinear.** The expectation form is a linear system in V, solvable in closed form. The optimality form has a max in it, so it is not linear and there is no matrix inverse. This is exactly why policy evaluation is easy and control is hard.
2. **The optimality equation is off-policy by construction.** The max over a' does not reference the behaviour policy at all, which is why Q-learning can learn about the greedy policy from data generated by anything else (section 8.7).

The optimal policy is then greedy with respect to Q-star, and the **Bellman optimality principle** justifies it: an optimal policy has the property that whatever the first action, the remaining decisions must be optimal from the resulting state. That is why a one-step lookahead on the optimal value function gives the globally optimal action.

### Matrix form, for intuition

For a fixed policy the expectation equation is linear, and writing it in matrix form is clarifying:

$$
v = r + \gamma P v \quad \Longrightarrow \quad v = (I - \gamma P)^{-1} r
$$

with v and r vectors over states and P the state-to-state transition matrix induced by the policy. The inverse exists because P is a stochastic matrix, so its spectral radius is 1 and gamma P has spectral radius gamma < 1, which by Chapter 1's eigenvalue-shift reasoning means I - gamma P has no zero eigenvalue.

Expanding the inverse as a Neumann series makes the meaning plain:

$$
(I - \gamma P)^{-1} = I + \gamma P + \gamma^2 P^2 + \cdots
$$

**Value is a discounted sum over all future visits**, with gamma^k P^k giving the discounted probability of being in each state k steps from now. That is a genuinely useful picture and it connects directly to the matrix-powers discussion of eigenvalues in Chapter 1.

The practical caveat: this is O(|S|^3) and requires knowing P, so it is a conceptual tool rather than an algorithm for anything real.

### Bellman as an operator

Define the **Bellman optimality operator** T on value functions:

$$
(TV)(s) = \max_a \Big[ R(s,a) + \gamma \sum_{s'}P(s'\mid s,a)V(s') \Big]
$$

Then V-star is the **fixed point**: TV-star = V-star. Recasting the equation as a fixed-point problem is what makes the convergence theory of section 8.4 possible, and it is the framing that unifies value iteration, Q-learning and their deep variants. Every algorithm in this chapter is an attempt to find the fixed point of some Bellman operator.

**Try it.** (a) Derive the Bellman expectation equation for Q from the definition, using the tower property explicitly. (b) Why is the expectation equation linear but the optimality equation not? (c) A three-state MDP has deterministic transitions A to B to C to A with rewards 1, 2, 3 and gamma = 0.5. Solve for V at each state. Answers in 8.11.

## 8.4 Why it converges: the contraction argument

This is the theoretical backbone of the chapter, and it is short enough to reproduce completely. It is also a favourite of research interviews, because it separates people who have read the algorithms from people who understand them.

### Contraction mappings

An operator T on a metric space is a **gamma-contraction** if it shrinks distances by at least a factor gamma < 1:

$$
\lVert TV - TU \rVert \;\le\; \gamma\,\lVert V - U \rVert \quad \text{for all } V, U
$$

**The Banach fixed-point theorem** then gives three things at once, on a complete metric space:

1. A fixed point **exists**.
2. It is **unique**.
3. Iterating T from **any** starting point converges to it, geometrically at rate gamma.

That third clause is the practically important one: it means value iteration converges regardless of initialization, and it tells you the rate.

### The Bellman operator is a contraction

Use the sup norm, the largest absolute difference over all states:

$$
\lVert V - U \rVert_{\infty} = \max_s |V(s) - U(s)|
$$

**Claim:** the Bellman optimality operator T is a gamma-contraction in this norm.

*Proof.* Fix a state s. Using the fact that the difference of two maxima is at most the maximum of the differences,

$$
|(TV)(s) - (TU)(s)| \le \max_a \Big| \gamma \sum_{s'} P(s'\mid s,a)\big[V(s') - U(s')\big] \Big|
$$

The rewards cancel because they are identical in both. Now bound the inner sum: it is an average (the transition probabilities are nonnegative and sum to 1) of quantities each at most the sup-norm distance, so the average is at most that distance:

$$
\le \gamma \max_a \sum_{s'}P(s'\mid s,a)\,\lVert V - U\rVert_{\infty} = \gamma\,\lVert V - U \rVert_{\infty}
$$

Taking the maximum over s gives the result. **Two facts did all the work: the transition probabilities form a convex combination, and gamma is strictly less than 1.** That is the whole proof and it is worth being able to write out.

### What this buys you

- **Value iteration converges** from any initialization, to the unique V-star, at a geometric rate gamma per sweep.
- **The error bound is explicit:** after k iterations the error is at most gamma^k times the initial error. To reach accuracy epsilon you need about log(1/epsilon)/log(1/gamma) iterations. Note the dependence on gamma: at gamma = 0.99 the per-iteration contraction is only 1%, so you need roughly 100 times more sweeps than at gamma = 0.9. **Long horizons are expensive in a precise, quantifiable sense.**
- **A stopping criterion follows.** If successive iterates differ by less than epsilon in sup norm, then the distance to the true fixed point is at most epsilon\*gamma/(1 - gamma), by the triangle inequality and the geometric sum of remaining changes. That is a certificate, not a heuristic.
- **The policy evaluation operator is also a contraction**, by the same argument without the max, so policy evaluation converges too.

### Why the sup norm, and why it matters later

A detail that explains a great deal about deep RL. The contraction holds in the **sup norm**, not the L2 norm. That is fine for tabular methods, where you can represent every state's value independently.

But function approximation projects value functions onto a restricted family, and **that projection is a contraction in L2, not in sup norm.** Composing a sup-norm contraction with an L2 projection gives an operator that need not be a contraction in any norm — and consequently the convergence guarantee **evaporates**. This is not a technicality; it is the precise reason deep RL is unstable where tabular RL is provably convergent, and it is the formal content of the "deadly triad" in section 8.7.

There are known counterexamples (Baird's counterexample is the standard one) where linear function approximation with off-policy updates and bootstrapping diverges to infinity on a tiny MDP. Being able to say "the contraction is in sup norm, and function approximation projects in L2, so the composition is not guaranteed to contract" is a genuinely strong answer.

### Where else contraction arguments appear

Worth noting because the pattern recurs: the same fixed-point reasoning underlies the convergence of Gauss-Seidel and Jacobi iterations in numerical linear algebra, the existence-and-uniqueness theorem for ordinary differential equations (Picard iteration), and the analysis of deep equilibrium models, where a layer is defined as the fixed point of a contraction. If you recognize "contraction implies unique fixed point plus geometric convergence" as a single reusable tool, you will see it in many places.

**Try it.** (a) With gamma = 0.95, how many value-iteration sweeps are needed to reduce the error by a factor of 1000? (b) Reproduce the contraction proof, identifying exactly where the convex-combination property is used. (c) Explain in two sentences why the guarantee fails under function approximation. Answers in 8.11.

## 8.5 Dynamic programming

These methods assume you **know** P and R. That assumption is almost never satisfied, so their value is as the conceptual skeleton that every model-free method approximates. Each algorithm in sections 8.6 to 8.8 is one of these with the expectation replaced by a sample.

### Policy evaluation

Given a policy, compute its value function by iterating the Bellman expectation equation:

$$
V_{k+1}(s) \leftarrow \sum_a \pi(a\mid s)\sum_{s'}P(s'\mid s,a)\big[R(s,a) + \gamma V_k(s')\big]
$$

By section 8.4 this converges to V-pi from any initialization at rate gamma. You could instead solve the linear system exactly, but that is O(|S|^3) and iteration is usually cheaper.

### Policy improvement

Given V-pi, define a new policy that acts greedily:

$$
\pi'(s) = \arg\max_a \Big[ R(s,a) + \gamma\sum_{s'}P(s'\mid s,a)V^{\pi}(s') \Big] = \arg\max_a Q^{\pi}(s,a)
$$

> **Policy improvement theorem.** The new policy is at least as good as the old one in every state, and strictly better in at least one unless the old policy was already optimal.

*Proof sketch, worth knowing.* By construction Q-pi(s, pi'(s)) >= V-pi(s) for every s. Expand V-pi(s) using that inequality repeatedly, substituting the new policy's action at each step: each substitution can only increase the value, and unrolling gives V-pi'(s) >= V-pi(s). The telescoping argument is the standard one and it is the formal reason greedy improvement is safe.

**This theorem is why RL works at all.** It guarantees that "evaluate, then act greedily" never makes things worse, so alternating the two must improve monotonically.

### Policy iteration

Alternate the two steps:

1. Evaluate the current policy to convergence.
2. Improve greedily.
3. Stop when the policy stops changing.

Because the number of deterministic policies is finite and each iteration strictly improves, **policy iteration terminates at the exact optimum in a finite number of steps** — typically very few, often under ten even for large problems. That finite-termination property is a genuinely strong guarantee and distinguishes it from value iteration.

### Value iteration

Do not bother evaluating to convergence. Take one sweep of the Bellman **optimality** operator:

$$
V_{k+1}(s) \leftarrow \max_a \Big[ R(s,a) + \gamma\sum_{s'}P(s'\mid s,a)V_k(s')\Big]
$$

This is policy iteration with the evaluation truncated to a single step, and it converges geometrically by section 8.4. It reaches the optimum asymptotically rather than exactly, but each sweep is far cheaper.

|  | Policy iteration | Value iteration |
| --- | --- | --- |
| Per iteration | expensive (full evaluation) | cheap (one sweep) |
| Iterations needed | very few | many |
| Termination | exact, finite | asymptotic |
| In practice | often faster overall | simpler to implement |

**Generalized policy iteration** is the umbrella idea: any interleaving of partial evaluation and partial improvement converges, and essentially every RL algorithm is an instance. Policy iteration and value iteration are the two extremes of how much evaluation you do between improvements; SARSA, Q-learning and actor-critic all sit somewhere along that spectrum. This is the single most useful organizing frame in RL, and stating it is a strong answer to "how do all these algorithms relate?"

### The curse of dimensionality

Every sweep touches every state, so the cost is O(|S|^2 |A|) per iteration. That is fine for a gridworld and hopeless for anything real:

- Backgammon has about 10^20 states.
- Go has about 10^170.
- A continuous state space has infinitely many.
- An LLM agent's state — the full context — is astronomically large.

Two escapes, and they define the rest of RL:

1. **Sampling instead of enumerating.** Do not sweep all states; visit the ones your policy actually reaches. This gives Monte Carlo and temporal-difference methods (section 8.6).
2. **Function approximation instead of tables.** Represent V or Q with a parameterized function that generalizes across states (section 8.8).

Note that the two escapes together are exactly what breaks the convergence guarantees, which is the tension this chapter keeps returning to.

### Asynchronous and prioritized variants

You do not have to sweep states in order, and you do not have to update them equally often. **Asynchronous DP** updates states in any order, still converging provided every state is updated infinitely often. **Prioritized sweeping** orders updates by the magnitude of the Bellman error, focusing effort where the value function is most wrong. The same idea reappears as **prioritized experience replay** in deep RL, so recognizing the ancestry is useful.

**Try it.** (a) Run two sweeps of value iteration by hand on a three-state chain of your choosing and verify the values move toward the analytic answer. (b) Why does policy iteration terminate in finitely many steps while value iteration does not? (c) Why is a single sweep of value iteration equivalent to truncated policy iteration? Answers in 8.11.

## 8.6 Model-free prediction: Monte Carlo and TD

Now drop the model. You cannot compute the expectation in the Bellman equation, so you must estimate it from experience. There are exactly two ideas, and everything else interpolates between them.

### Monte Carlo

Wait until the episode ends, compute the actual return, and average:

$$
V(s_t) \leftarrow V(s_t) + \alpha\big[ G_t - V(s_t) \big]
$$

This is Chapter 3's Monte Carlo estimator applied to a conditional expectation, with the average implemented as an exponentially weighted running update.

**Properties:**

- **Unbiased**, since G\_t is by definition a sample of the quantity you want.
- **High variance**, because the return is a sum of many random rewards and random transitions over a whole episode.
- **No bootstrapping**: it never uses its own estimates, so it is immune to the instability of section 8.7.
- **Requires episodes to terminate**, so it cannot be used in continuing tasks.
- **Insensitive to violations of the Markov property**, since it never relies on the state being sufficient — a genuinely useful property in partially observed settings.

### Temporal difference

Do not wait. Use your own current estimate of the next state's value as a stand-in for the rest of the episode:

$$
V(s_t) \leftarrow V(s_t) + \alpha\underbrace{\big[ r_t + \gamma V(s_{t+1}) - V(s_t) \big]}_{\text{TD error } \delta_t}
$$

The bracketed quantity is the **TD error**, and it is the single most important object in value-based RL. It is the difference between a one-step-improved estimate and the current one — the sampled Bellman residual.

**Properties:**

- **Biased**, because V(s\_{t+1}) is wrong early on and you are learning from your own wrong guess. This is **bootstrapping**.
- **Much lower variance**, since only one reward and one transition enter each update rather than an entire episode.
- **Works online and in continuing tasks**; no need to wait for termination.
- **Exploits the Markov property**, converging faster when it holds and being misled when it does not.

### The comparison, and what each converges to

|  | Monte Carlo | TD |
| --- | --- | --- |
| Bias | none | biased while learning |
| Variance | high | low |
| Needs episode end | yes | no |
| Bootstraps | no | yes |
| Uses Markov property | no | yes |
| Converges to | the empirical mean return | the value under the maximum-likelihood MDP |

That last row is subtle and is a genuinely discriminating interview question. Given a finite batch of experience, **MC converges to the estimate that minimizes squared error on the observed returns; TD converges to the value function of the MDP that best explains the data** — the maximum-likelihood model built from the observed transition counts. TD is implicitly doing model-based reasoning without building a model, which is why it is usually more data-efficient when the Markov assumption holds.

The standard illustration is the classic "you have observed eight episodes" exercise, where the two methods give different answers for a state visited once, and TD's answer is the one that accounts for the transition structure.

### n-step returns and TD(lambda)

The two methods are endpoints of a spectrum. An **n-step return** bootstraps after n steps:

$$
G_t^{(n)} = r_t + \gamma r_{t+1} + \cdots + \gamma^{n-1}r_{t+n-1} + \gamma^n V(s_{t+n})
$$

n = 1 is TD, n = infinity is Monte Carlo, and intermediate n interpolates the bias-variance trade. Intermediate values typically work best, which is why **n-step returns are standard in modern implementations** (and why n-step returns appear in Rainbow and in most distributed RL systems).

**TD(lambda)** averages all n-step returns with geometrically decaying weights:

$$
G_t^{\lambda} = (1-\lambda)\sum_{n=1}^{\infty}\lambda^{n-1}G_t^{(n)}
$$

lambda = 0 recovers TD, lambda = 1 recovers Monte Carlo. The **eligibility trace** formulation implements this online with O(1) memory per state, by keeping a decaying record of recently visited states and applying each TD error to all of them in proportion.

This matters for Chapter 9, because **generalized advantage estimation (GAE)** is exactly TD(lambda) applied to advantages rather than values. Recognizing GAE as an old idea in new notation saves you a great deal of confusion.

### What the TD error means

Three readings, all useful:

1. **A sampled Bellman residual.** Its expectation is zero exactly when V satisfies the Bellman equation, so it measures how wrong your value function is.
2. **A prediction error**, which is why it is the standard model for dopamine signalling in neuroscience — a connection that is genuinely well supported and worth mentioning.
3. **An unbiased estimate of the advantage** when V is accurate, since E\[r + gamma V(s') - V(s)\] = Q(s,a) - V(s) = A(s,a). This is the identity that makes GAE work and is the bridge to Chapter 9.

**Try it.** (a) You observe the episode A (reward 0) then B (reward 1) then terminal, with all values initialized to 0, alpha = 0.5, gamma = 1. Compute the TD updates and the MC updates. (b) Why does TD have lower variance than MC? (c) Why does TD converge to the value function of the maximum-likelihood MDP rather than to the empirical mean return? Answers in 8.11.

## 8.7 Model-free control

### From prediction to control

Prediction estimates V for a fixed policy. **Control** finds a good policy. The move is to learn Q rather than V — because, as section 8.2 established, you can act greedily on Q without a model — and then apply generalized policy iteration: estimate Q, act nearly greedily, repeat.

"Nearly" greedily, because a purely greedy policy stops exploring and never discovers that an untried action is better. The standard fix is **epsilon-greedy**: take the greedy action with probability 1 - epsilon, otherwise act uniformly at random.

### SARSA (on-policy)

$$
Q(s_t,a_t) \leftarrow Q(s_t,a_t) + \alpha\big[ r_t + \gamma\,Q(s_{t+1},a_{t+1}) - Q(s_t,a_t) \big]
$$

The name is the tuple it uses: state, action, reward, state, action. The critical detail is that **a\_{t+1} is the action your policy actually took**, so SARSA learns the value of the policy it is following, exploration included.

### Q-learning (off-policy)

$$
Q(s_t,a_t) \leftarrow Q(s_t,a_t) + \alpha\big[ r_t + \gamma\,\max_{a'}Q(s_{t+1},a') - Q(s_t,a_t)\big]
$$

One symbol differs: a max instead of the sampled next action. That single change makes it learn about the **greedy** policy no matter what policy generated the data, which is exactly the off-policy property predicted by the Bellman optimality equation's structure in section 8.3.

### The cliff-walking distinction

The standard example, and the clearest way to see the difference. A gridworld with a cliff along the bottom: falling in gives a large negative reward. The shortest path runs right along the cliff edge.

- **Q-learning** learns the optimal path — along the edge — because its max assumes future actions will be greedy. But while *behaving* with epsilon-greedy exploration, it occasionally steps off and receives terrible returns during training.
- **SARSA** learns a safer path one row further from the edge, because its updates account for the fact that the actual policy sometimes explores and will sometimes fall.

**Q-learning learns the optimal policy; SARSA learns the optimal policy given that you will keep exploring.** If exploration is costly or dangerous in the real system, SARSA's answer is the more useful one. That contrast is a favourite interview question and the cliff example is the right way to answer it.

### On-policy versus off-policy

|  | On-policy | Off-policy |
| --- | --- | --- |
| Learns about | the policy generating the data | a different (usually greedy) policy |
| Can reuse old data | no, it goes stale | **yes** |
| Replay buffers | not directly | natural |
| Learning from demonstrations | no | yes |
| Stability | better | worse |
| Examples | SARSA, REINFORCE, A2C, PPO | Q-learning, DQN, DDPG, SAC |

**Off-policy learning is what makes sample efficiency possible**, because you can reuse every transition you have ever collected, learn from human demonstrations, and learn about many policies from one stream of data. It is also where the instability lives, which is the subject of the rest of this section.

Note that PPO is on-policy but uses importance sampling (Chapter 3) to squeeze several gradient steps out of each batch before the data goes stale. It sits slightly off the strict dichotomy, and Chapter 9 explains exactly how.

### Expected SARSA and the maximization bias

**Expected SARSA** replaces the sampled next action with its expectation under the policy:

$$
Q(s_t,a_t) \leftarrow Q(s_t,a_t) + \alpha\Big[ r_t + \gamma\sum_{a'}\pi(a'\mid s_{t+1})Q(s_{t+1},a') - Q(s_t,a_t)\Big]
$$

This is Rao-Blackwellization from Chapter 3: integrating out randomness analytically reduces variance at no cost in bias. It is strictly better than SARSA when computable, and Q-learning is its special case with a greedy target policy.

**Maximization bias** is a genuine and under-appreciated problem. Q-learning's target contains max over a' of Q(s', a'), and

$$
\mathbb{E}\big[\max_a \hat{Q}(s,a)\big] \;\ge\; \max_a \mathbb{E}\big[\hat{Q}(s,a)\big]
$$

by Jensen's inequality, since the maximum is convex. **Taking a max over noisy estimates systematically overestimates.** If all actions have true value 0 but your estimates have noise, the max of the estimates is positive in expectation, so Q-learning inflates its values, and the error compounds through bootstrapping.

**Double Q-learning** fixes it by decoupling selection from evaluation: use one estimator to choose the argmax and a second, independently trained one to evaluate it. The noise in the two is independent, so the selection bias does not transfer into the value. This is the idea behind Double DQN, and "decouple action selection from action evaluation" is the phrase to have ready.

### The deadly triad

The central instability result of value-based deep RL. Divergence can occur when all three of the following are present:

1. **Function approximation** (a neural network instead of a table)
2. **Bootstrapping** (TD targets instead of full returns)
3. **Off-policy learning** (training on data from a different policy)

**Any two are safe; all three can diverge.** The reason is section 8.4's: the Bellman operator contracts in sup norm, function approximation projects in L2, and the composition need not contract in any norm. Off-policy data makes the projection's weighting mismatched with the dynamics, which is what removes the last hope of stability. Baird's counterexample demonstrates divergence to infinity on a tiny MDP with linear function approximation.

How each combination is used in practice:

| Combination | Example | Status |
| --- | --- | --- |
| Approximation + bootstrapping, on-policy | SARSA with a network, A2C | stable in practice |
| Approximation + off-policy, no bootstrapping | Monte Carlo with importance sampling | stable, high variance |
| Bootstrapping + off-policy, tabular | tabular Q-learning | provably convergent |
| **All three** | **DQN and descendants** | works, with heavy engineering |

That last row is the interesting one: DQN uses all three and works anyway, because of a specific set of stabilizing tricks. Those tricks are section 8.8, and knowing that they exist *to counteract the deadly triad* is the framing that makes them memorable rather than arbitrary.

**Try it.** (a) In the cliff-walking task, which algorithm learns the safer path and why? (b) Prove that the expected maximum of noisy estimates exceeds the maximum of their expectations. (c) Name the three elements of the deadly triad and say which two DQN could drop, and at what cost. Answers in 8.11.

## 8.8 Deep Q-learning

### The setup

Replace the Q table with a network Q(s, a; theta) and fit it by regression toward the Bellman target:

$$
\mathcal{L}(\theta) = \mathbb{E}\left[ \Big( \underbrace{r + \gamma\max_{a'}Q(s',a';\theta^{-})}_{\text{target } y} - Q(s,a;\theta) \Big)^2 \right]
$$

This looks like supervised regression, and that resemblance is exactly what is misleading about it. Three things are different, and naming them is the substance of this section:

1. **The targets depend on the parameters being trained**, so you are chasing a moving goal.
2. **The data is not i.i.d.**; consecutive transitions are highly correlated and the distribution shifts as the policy improves.
3. **All three legs of the deadly triad are present.**

Every DQN innovation is a response to one of these.

### The two fixes that made it work

**Experience replay.** Store transitions in a large buffer and sample minibatches uniformly from it. This addresses the i.i.d. problem directly: consecutive samples in a trajectory are correlated, and training on them in order gives you a gradient estimate dominated by whatever the agent is doing this second. Sampling from a buffer of a million transitions decorrelates the batch and, as a bonus, reuses each transition many times, giving a large improvement in sample efficiency. This is only possible because Q-learning is off-policy.

**Target network.** Compute the target using a **separate, frozen copy** of the network, theta-minus, updated to match theta only every few thousand steps (or by a slow exponential average). Without it, every gradient step changes the target you are regressing toward, creating a feedback loop in which an overestimate raises the target, which raises the estimate, which raises the target. Freezing the target turns the problem into a sequence of ordinary supervised regressions, each with a fixed target. **The target network is what converts a fixed-point iteration into something a gradient method can handle.**

Note the connection to Chapter 2: the target is **detached**, meaning no gradient flows through it. That detachment is not an optimization; it is definitional. Differentiating through the target would change the objective into something that is not Q-learning at all and is known to be unstable.

### The subsequent fixes

| Fix | Problem addressed | Mechanism |
| --- | --- | --- |
| **Double DQN** | maximization bias | select the argmax with the online network, evaluate it with the target network |
| **Prioritized replay** | uniform sampling wastes effort | sample in proportion to TD error, with importance weights to correct the bias |
| **Dueling architecture** | Q values are dominated by V | separate streams for V(s) and A(s,a), recombined with the advantage mean subtracted |
| **Noisy nets** | epsilon-greedy explores crudely | learnable parametric noise in the weights, giving state-dependent exploration |
| **n-step returns** | one-step targets propagate slowly | bootstrap after n steps (section 8.6) |
| **Distributional (C51, QR-DQN)** | the mean discards information | learn the full return distribution rather than its expectation |
| **Rainbow** | — | combine all of the above; the ablations show each contributes |

Two of these deserve a sentence more.

**Dueling** exploits the observation that in many states the choice of action barely matters, so most of Q's magnitude is the state value. Estimating V and A separately lets the network learn state values from every transition regardless of which action was taken. The identity used is Q = V + A - mean(A), where subtracting the mean resolves the identifiability problem — without it, any constant could be shifted between V and A.

**Distributional RL** replaces the scalar Q with a distribution over returns and applies a distributional Bellman operator. Even when you only act on the mean, learning the full distribution gives a richer training signal and empirically improves performance substantially. It also connects to risk-sensitive control, where you may want a quantile rather than the mean.

### Continuous actions

Q-learning requires a max over actions, which is trivial for a handful of discrete actions and intractable for a continuous space. Two responses:

- **DDPG / TD3**: learn a deterministic actor that outputs the maximizing action, so the max becomes a function evaluation. TD3 adds the standard fixes — twin critics with a minimum (to combat overestimation), delayed policy updates, and target smoothing.
- **SAC**: the maximum-entropy formulation from Chapter 5, where the optimal policy is a softmax over Q divided by the temperature, learned as a stochastic actor. SAC is off-policy, sample-efficient, and robust to hyperparameters, and it is the standard choice for continuous control.

### An honest assessment for agentic AI

Value-based methods dominate discrete-action benchmarks and remain the right tool for many control problems. But for language-model agents they are largely **not** what is used, and it is worth saying why: the action space is the vocabulary (tens of thousands of discrete actions per step, with sequences of them), rewards are sparse and often only available at the end of a trajectory, and the deadly triad's instability is poorly tolerated when each training run is enormously expensive. Policy-gradient methods with a learned value baseline — PPO and its relatives — handle these conditions better, which is why Chapter 9 is where agentic AI actually lives. Value functions still appear there, but as **critics** providing baselines rather than as the policy itself.

**Try it.** (a) Explain precisely what goes wrong without a target network. (b) Why is experience replay only possible for off-policy algorithms? (c) In the dueling architecture, why must you subtract the mean advantage? Answers in 8.11.

## 8.9 Exploration

### The dilemma

You must choose between the action you currently believe is best (**exploit**) and one you are uncertain about (**explore**). Exploiting gets reward now; exploring gets information that may be worth far more later. The tension is unavoidable, because you only learn about actions you actually take.

This chapter treats exploration in MDPs; Chapter 9 treats the bandit case, where the theory is much sharper and gives optimal algorithms.

### The baseline methods

**Epsilon-greedy.** Act greedily with probability 1 - epsilon, uniformly at random otherwise. Usually annealed from about 1.0 to about 0.05 over training.

What it gets right: simple, and with a suitable annealing schedule it satisfies the conditions for tabular Q-learning's convergence (every state-action pair visited infinitely often).

What it gets wrong, and this is the substantive criticism: **it explores uniformly at random, ignoring everything it knows.** It is as likely to try an action it has tried a thousand times as one it has never tried, and it explores locally — a random action here and there rarely produces the *sequence* of coordinated novel actions needed to reach a distant unexplored region. The canonical failure case is Montezuma's Revenge, where reaching the first meaningful reward requires a long specific sequence that random perturbation will essentially never produce.

**Boltzmann / softmax exploration.** Sample actions with probability proportional to exp(Q/tau). Better than epsilon-greedy in that it explores promising actions more often than clearly bad ones. As Chapter 5 showed, this is not a heuristic: it is the exact optimum of the entropy-regularized objective, with tau the entropy weight. That is the principled version of the same idea, and it is what SAC and maximum-entropy RL implement.

### Optimism in the face of uncertainty

The principle that underlies the theoretically sound methods: **act as if the world is as good as it plausibly could be.** Then either you were right (and you get reward) or you were wrong (and you learn something). Either outcome is useful, which is what makes the principle work.

In the tabular case this is implemented with **optimistic initialization** (set all Q values high, so every untried action looks attractive until tried) or with **count-based bonuses**:

$$
r^{+}(s,a) = r(s,a) + \frac{\beta}{\sqrt{N(s,a)}}
$$

The bonus shrinks as the square root of the visit count, which is exactly the standard-error scaling from Chapter 3 — the bonus is proportional to your uncertainty about that state-action's value. Methods of this family (UCB-style, and model-based variants) have provable regret bounds in tabular MDPs.

### Exploration with function approximation

Counts do not survive contact with large state spaces: you never visit the same state twice. The modern approaches approximate the count or the novelty:

| Method | Idea |
| --- | --- |
| **Pseudo-counts** | derive an effective count from a learned density model's probability assignment |
| **Random network distillation (RND)** | predict the output of a fixed random network; prediction error is high on novel states |
| **Curiosity / forward-model error** | reward states where a learned dynamics model predicts badly |
| **Noisy nets** | parametric noise in the weights gives consistent, state-dependent exploratory behaviour |
| **Bootstrapped DQN** | an ensemble of Q heads; act greedily on a randomly chosen head per episode, giving deep exploration |
| **Thompson sampling** | sample from a posterior over values and act greedily (Chapter 9) |

**RND** is worth understanding because it is elegant and widely used. Fix a randomly initialized network; train a second network to predict its outputs on visited states. On states similar to those seen often, the predictor has learned to match; on novel states it has not, so the prediction error is large. Use that error as an intrinsic reward. The reason it uses a *random* target is to avoid the **noisy-TV problem**: an intrinsic reward based on predicting the environment's own dynamics is maximized by finding a source of irreducible randomness (a television showing static), which the agent will then watch forever. A deterministic random target has no irreducible noise, so novelty is the only thing that produces error.

**Bootstrapped DQN** illustrates the important idea of **deep exploration**: committing to an exploratory hypothesis for a whole episode rather than randomizing each step independently. Per-step randomization tends to cancel out; per-episode commitment produces the coordinated sequences that reach genuinely new regions.

### What this means for agentic systems

Exploration in LLM agents is a live and somewhat unsettled area, and it is worth being able to talk about it carefully. The action space is enormous, most actions are nonsense, and random exploration is therefore nearly useless. What substitutes for it in practice:

- **The pretrained prior** does the work that random exploration would otherwise do. The model's distribution over next actions already concentrates on sensible ones, so sampling from it is an informed exploration strategy rather than a uniform one.
- **Sampling temperature** controls the exploration-exploitation trade directly, and it is the same parameter as the entropy weight in section 5.8.
- **Best-of-n sampling and search** explore by generating several candidates and selecting among them with a verifier or reward model, which is exploration at inference time rather than during training.
- **The KL penalty in RLHF** (Chapter 5) acts as a constraint that keeps the policy inside the region where the pretrained prior — and therefore the reward model — remains reliable.

The honest summary: classical exploration theory is well developed for bandits and tabular MDPs, and its direct application to language agents is limited. The mechanisms that actually work there are prior-driven rather than uncertainty-driven, and that is an area where the theory has not caught up with practice.

**Try it.** (a) Why does epsilon-greedy fail on tasks needing a long specific action sequence? (b) Why does the count bonus scale as 1/sqrt(N)? (c) Explain the noisy-TV problem and how RND avoids it. Answers in 8.11.

## 8.10 Interview drill set

**1. What is the Markov property, and is it restrictive?** The next state depends only on the current state and action, not the earlier history. It is not a restriction on the world but a requirement on your state definition — any process can be made Markov by including enough history; the question is whether the state stays small enough to be useful.

**2. Why do we discount?** Convergence of the infinite sum; equivalence to a geometric termination probability, which makes the value function time-invariant; a genuine preference for sooner rewards; and variance reduction from a shorter effective horizon.

**3. What is the effective horizon?** About 1/(1 - gamma). At gamma = 0.99 that is 100 steps, so credit cannot be assigned over 500 steps at that discount no matter how long you train.

**4. Why learn Q rather than V?** Because acting greedily on Q needs only a max over actions, while acting greedily on V requires knowing where each action leads, which needs a model. Q is directly actionable model-free.

**5. Derive the Bellman equation.** Split the return into the first reward plus gamma times the remaining return, then apply the tower property conditioning on the next state, using the Markov property to drop the earlier history. The inner conditional expectation is the value of the next state by definition.

**6. Why is the Bellman optimality equation nonlinear?** Because of the max over actions. The expectation form for a fixed policy is a linear system solvable in closed form; the max removes linearity, which is why control is harder than evaluation.

**7. Why does value iteration converge?** The Bellman operator is a gamma-contraction in the sup norm, so by the Banach fixed-point theorem the fixed point exists, is unique, and is reached from any initialization at geometric rate gamma. The proof uses only that transition probabilities form a convex combination and gamma < 1.

**8. What is the advantage function and why use it?** Q minus V: how much better than average an action is. Its expectation under the policy is zero, which makes it the ideal control variate for policy gradients — unbiased, and it removes the large state-dependent variance component.

**9. Monte Carlo versus TD?** MC uses the actual return: unbiased, high variance, needs episodes to end, does not bootstrap, and is robust to non-Markov states. TD bootstraps from its own next-state estimate: biased, much lower variance, works online and in continuing tasks, and exploits the Markov property.

**10. What does TD converge to, given a finite batch?** The value function of the maximum-likelihood MDP built from the observed transitions, whereas MC converges to the estimate minimizing squared error on the observed returns. TD is doing implicit model-based reasoning.

**11. What is the TD error and what are its three readings?** r + gamma V(s') - V(s). It is a sampled Bellman residual whose expectation vanishes at the true value function; it is a prediction error, which is the standard model of dopamine signalling; and when V is accurate it is an unbiased estimate of the advantage, which is what GAE exploits.

**12. What is TD(lambda) and where does it reappear?** A geometrically weighted average of all n-step returns, interpolating from TD at lambda = 0 to Monte Carlo at lambda = 1. Generalized advantage estimation is exactly TD(lambda) applied to advantages.

**13. SARSA versus Q-learning?** SARSA uses the action actually taken, so it is on-policy and learns the value of the behaviour policy including its exploration. Q-learning uses the max, so it is off-policy and learns about the greedy policy regardless of how the data was generated.

**14. Which learns the safer path on cliff-walking, and why?** SARSA, because its updates account for the fact that the policy will keep exploring and sometimes step off the cliff. Q-learning learns the optimal edge-hugging path but performs worse during training under epsilon-greedy behaviour.

**15. What is maximization bias?** The expected max of noisy estimates exceeds the max of their expectations, by Jensen applied to the convex max. Q-learning's max over noisy Q values therefore systematically overestimates, and bootstrapping compounds the error.

**16. How does Double Q-learning fix it?** Decouple selection from evaluation: pick the argmax with one network and evaluate it with an independently trained one, so the selection noise does not carry into the value estimate.

**17. What is the deadly triad?** Function approximation, bootstrapping, and off-policy learning. Any two are safe; all three can diverge, because the Bellman contraction is in sup norm while function approximation projects in L2, so the composition need not contract in any norm.

**18. Why does DQN need a target network?** Without it, every gradient step moves the target you are regressing toward, producing a feedback loop where overestimates raise the target which raises the estimate. Freezing the target turns the problem into a sequence of ordinary supervised regressions.

**19. Why does DQN need experience replay?** Consecutive transitions are highly correlated, so training on them in order gives badly biased gradient estimates. Sampling from a large buffer decorrelates batches and reuses each transition many times. It is only possible because Q-learning is off-policy.

**20. Why is the TD target detached?** Because Q-learning is a fixed-point iteration, not gradient descent on a loss. Differentiating through the target changes the objective into something else, which is known to be unstable.

**21. What does the dueling architecture do?** Splits Q into a state-value stream and an advantage stream, so state values are learned from every transition regardless of the action taken. The mean advantage is subtracted to resolve the identifiability between the two streams.

**22. How do you handle continuous actions in a value-based method?** Either learn a deterministic actor that outputs the maximizing action (DDPG, TD3, with twin critics and delayed updates for stability), or use the maximum-entropy formulation where the optimal policy is a softmax over Q (SAC).

**23. Why is epsilon-greedy a weak exploration strategy?** It explores uniformly at random, ignoring what it already knows, and it randomizes per step, so the coordinated sequences of novel actions needed to reach distant regions essentially never occur.

**24. Why does a count-based exploration bonus scale as 1/sqrt(N)?** Because that is how the standard error of a mean estimate scales, so the bonus is proportional to your remaining uncertainty about that state-action's value.

**25. What is the noisy-TV problem?** An intrinsic reward based on prediction error of the environment's dynamics is maximized by irreducible randomness, so the agent finds a noise source and watches it forever. RND avoids it by predicting a fixed random network's output, which has no irreducible noise.

**26. What is generalized policy iteration?** Any interleaving of partial policy evaluation and partial policy improvement. Policy iteration and value iteration are the extremes, and essentially every RL algorithm is an instance, which is the cleanest way to see how they all relate.

**27. Why is RL harder than supervised learning?** Evaluative rather than instructive feedback, delayed consequences requiring credit assignment, a data distribution that depends on the policy (so the i.i.d. assumption fails), and the need to explore.

**28. Why are value-based methods not the main tool for LLM agents?** The action space is the vocabulary and sequences of it, rewards are sparse and terminal, and the deadly triad's instability is intolerable when runs are expensive. Policy-gradient methods with a value baseline handle those conditions better; value functions appear there as critics rather than as the policy.

## 8.11 Assignment and solutions

### Solutions to the in-text exercises

**8.1.** (a) No — a single frame gives positions but not velocities, so you cannot tell which way the ball is moving, and the optimal action depends on that. Stacking two frames suffices in principle; the original DQN stacked four for robustness. (b) A cleaning robot rewarded for the amount of mess it collects learns to create mess so it can collect it again; a boat-racing agent rewarded for intermediate checkpoints learns to loop through a scoring region forever instead of finishing. Both are optimal for the reward written and useless for the goal intended. (c) Because supervised learning assumes a fixed data distribution from which train and test are drawn i.i.d., which is what licenses the concentration bounds of Chapter 3 and the estimator analysis of Chapter 4. In RL the policy determines the distribution, so improving the policy changes the data, and the distribution you evaluated on is not the one you will next encounter — there is a feedback loop rather than a fixed target.

**8.2.** (a) 1/(1 - 0.95) = 20 steps. A reward arriving after 200 steps is discounted by 0.95^200 = about 3.5 x 10^-5, so it is effectively invisible to the agent: the learning signal for the action that caused it is swamped by noise. You would need a larger gamma, reward shaping, or a hierarchical decomposition. (b) Because the greedy action for Q is argmax over a of Q(s,a), which requires only evaluating a known function at each action. The greedy action for V is argmax over a of the expected value of the next state, which requires knowing the transition distribution P to compute that expectation. (c) E over a from pi of A(s,a) = E\[Q(s,a)\] - V(s), and E\[Q(s,a)\] under pi is exactly V(s) by definition, so the difference is zero.

**8.3.** (a) Q-pi(s,a) = E\[r\_t + gamma G\_{t+1} | s\_t = s, a\_t = a\]. Condition on (s\_{t+1}, a\_{t+1}) and apply the tower property: the inner expectation of G\_{t+1} given the next state and action is Q-pi(s', a'). Averaging over the transition and then over the policy's next action gives the stated equation. (b) Because a max is not a linear operator: max(x + y) is not max(x) + max(y). The expectation form averages with fixed policy weights, which is linear in V; the optimality form selects the best action, which depends on V in a non-differentiable, non-linear way. (c) V(A) = 1 + 0.5 V(B), V(B) = 2 + 0.5 V(C), V(C) = 3 + 0.5 V(A). Substituting: V(A) = 1 + 0.5(2 + 0.5(3 + 0.5 V(A))) = 1 + 1 + 0.75 + 0.125 V(A) = 2.75 + 0.125 V(A), so V(A) = 2.75/0.875 = 3.143. Then V(C) = 3 + 1.571 = 4.571 and V(B) = 2 + 2.286 = 4.286. Check: the average reward is 2, and 2/(1 - 0.5) = 4, which is about the average of the three values. Consistent.

**8.4.** (a) Need 0.95^k <= 0.001, so k >= log(0.001)/log(0.95) = -6.91/-0.0513 = about 135 sweeps. (b) The convex-combination property is used in the step where the sum over s' of P(s'|s,a) times the difference is bounded by the sup-norm distance: because the probabilities are nonnegative and sum to 1, the weighted average of quantities each at most D is itself at most D. If the weights did not sum to 1 the bound would fail. (c) The contraction guarantee is in the sup norm, but fitting a function approximator is a projection that contracts in a weighted L2 norm. A sup-norm contraction composed with an L2 projection is not guaranteed to be a contraction in either norm, so the fixed-point argument no longer applies and the iteration can diverge.

**8.5.** (a) Any consistent computation is acceptable; the check is that values move monotonically toward the analytic solution and that after k sweeps the error is at most gamma^k times the initial error. (b) Policy iteration searches over the finite set of deterministic policies, and each iteration strictly improves until optimal, so it cannot revisit a policy and must terminate. Value iteration searches over the continuous space of value functions and converges geometrically without ever exactly arriving. (c) Because one sweep of the optimality operator equals one greedy improvement followed by exactly one step of evaluation of the new policy, rather than evaluating it to convergence.

**8.6.** (a) TD with alpha = 0.5, gamma = 1: at A, target = 0 + V(B) = 0, so V(A) stays 0. At B, target = 1 + 0 (terminal), so V(B) goes from 0 to 0.5. MC: the return from A is 0 + 1 = 1, so V(A) goes to 0.5; the return from B is 1, so V(B) goes to 0.5. **The two disagree about A** — TD has not yet propagated the information back, while MC used the full return immediately. Over more episodes TD catches up and typically overtakes in efficiency. (b) Because the TD target contains one sampled reward and one sampled transition, while the MC return contains every reward and transition in the episode; variances of independent contributions add, so a longer sum has more variance. (c) Because TD's update is a stochastic approximation to the Bellman equation of the empirical transition model: it repeatedly enforces consistency between a state's value and its observed successors' values, which is exactly the fixed point of the MDP estimated from the observed transition counts. MC never enforces that consistency and just averages returns.

**8.7.** (a) SARSA, because its target uses the action the exploring policy actually takes, so the occasional random step off the cliff is incorporated into the value of edge states, making them look worse. Q-learning's max assumes optimal future behaviour and so undervalues the risk of its own exploration. (b) For any fixed a, max over a of Q-hat(s,a) >= Q-hat(s,a), so taking expectations gives E\[max\] >= E\[Q-hat(s,a)\] for every a, hence E\[max\] >= max over a of E\[Q-hat(s,a)\]. This is Jensen's inequality for the convex max function. (c) Function approximation, bootstrapping, off-policy learning. DQN could drop bootstrapping by using Monte Carlo returns, at the cost of much higher variance and no online learning; or drop off-policy learning by abandoning the replay buffer, at a large cost in sample efficiency and correlation. It keeps all three and compensates with target networks and replay.

**8.8.** (a) The regression target contains the network's own output, so each gradient step changes the target. An overestimate at s' raises the target for (s,a), which raises Q(s,a), which — through generalization in the network — may raise Q(s') further, giving a positive feedback loop that diverges. Freezing the target for thousands of steps breaks the loop. (b) Because replayed transitions were generated by older policies. An on-policy algorithm's update is only valid for data from the current policy, so old data is not merely stale but wrong; off-policy algorithms like Q-learning have targets that do not reference the behaviour policy at all. (c) Because Q = V + A is not identifiable: adding any constant c to V and subtracting it from A leaves Q unchanged, so the two streams are not separately determined and training is unstable. Subtracting the mean advantage forces the advantage stream to have zero mean, pinning down the decomposition.

**8.9.** (a) Because it randomizes independently at each step, so the probability of producing a specific sequence of k correct exploratory actions is roughly (epsilon/|A|)^k, which is astronomically small for k in the dozens. Exploration must be committed and coordinated, not per-step. (b) Because the standard error of an average of N samples falls as 1/sqrt(N) (Chapter 3), so that is the scale of your remaining uncertainty about the value, and an optimistic bonus should be proportional to it. (c) An agent rewarded for prediction error will seek out sources of irreducible randomness, since those produce permanently high error; a screen of static is maximally rewarding forever. RND predicts the output of a **fixed deterministic** random network, which is in principle perfectly predictable, so the only source of persistent error is having not visited similar states.

### Problem set

**P1 (Bellman by hand).** A two-state MDP: state A has actions "stay" (reward 1, stays) and "go" (reward 0, moves to B); state B has action "stay" (reward 2, stays). With gamma = 0.9, compute Q-star for every state-action pair and identify the optimal policy. Then redo with gamma = 0.5 and comment on why it changes.

**P2 (contraction).** Prove that the Bellman *expectation* operator for a fixed policy is a gamma-contraction in sup norm, and state the consequence for policy evaluation.

**P3 (value iteration).** Implement value iteration on a 4x4 gridworld with a goal, a pit, and a step cost. Plot the sup-norm error against iteration on a log scale and verify the slope equals log(gamma).

**P4 (MC versus TD).** Given a fixed batch of episodes, implement both batch MC and batch TD(0) and show they converge to different value functions. Explain the difference in terms of the maximum-likelihood MDP.

**P5 (SARSA versus Q-learning).** Implement cliff-walking and compare the learned policies and the online returns of the two algorithms. Then set epsilon to zero after training and compare the greedy policies' returns.

**P6 (maximization bias).** Construct a small MDP where Q-learning demonstrably overestimates, measure the bias empirically, and show Double Q-learning reduces it.

**P7 (n-step).** For a fixed environment, sweep n from 1 to 30 in n-step TD and plot the resulting error against n. Identify the bias-variance optimum and explain its position.

**P8 (deadly triad).** Implement Baird's counterexample and demonstrate divergence with linear function approximation, off-policy updates and bootstrapping. Then remove each element in turn and show stability returns.

**P9 (DQN).** Implement DQN on CartPole with and without a target network, and with and without replay. Report learning curves for all four combinations and explain each.

**P10 (synthesis).** Explain in one paragraph why these are all the same fact: the Bellman equation follows from the tower property; a value function is a conditional expectation; TD's target is a sampled Bellman residual; the advantage has zero mean under the policy; and the TD error is an unbiased advantage estimate when V is correct.

### Selected solutions

**P1.** With gamma = 0.9: staying in B forever gives V(B) = 2/(1 - 0.9) = 20. Staying in A forever gives 1/(1-0.9) = 10; going to A-then-B gives Q(A, go) = 0 + 0.9(20) = 18, while Q(A, stay) = 1 + 0.9 V(A). If "go" is optimal then V(A) = 18, and Q(A, stay) = 1 + 16.2 = 17.2 < 18, which is consistent. So the optimal policy is to go, and V(A) = 18. With gamma = 0.5: V(B) = 2/0.5 = 4; Q(A, go) = 0.5(4) = 2; if "stay" is optimal, V(A) = 1 + 0.5 V(A) so V(A) = 2, and Q(A, stay) = 2 which ties Q(A, go) = 2. At gamma slightly below 0.5 staying wins. **Lowering gamma makes the agent unwilling to sacrifice a present reward for a better future**, which is exactly the myopia the effective-horizon formula predicts.

**P2.** The same proof as section 8.4 without the max step. For a fixed policy, |(T-pi V)(s) - (T-pi U)(s)| equals gamma times the absolute value of a double average (over actions under pi, then over next states under P) of V(s') - U(s'). Both averages have nonnegative weights summing to 1, so the result is at most gamma times the sup-norm distance. The consequence: policy evaluation converges geometrically to the unique V-pi from any initialization, which is what licenses truncating it — and hence what makes generalized policy iteration valid.

**P4.** The standard demonstration uses eight episodes in which state A is visited once, transitioning to B with reward 0, and B is visited eight times with reward 1 in six of them. Batch MC sets V(A) = 0, because the single observed return from A was 0. Batch TD sets V(A) = 0 + V(B) = 0.75, because the observed transition structure says A always leads to B, and B is worth 0.75. **TD's answer uses the transition structure; MC's does not.** TD is computing the value function of the maximum-likelihood MDP estimated from the counts, which is usually the better generalization when the Markov property holds — and the worse one when it does not.

**P10.** All five follow from **V being defined as a conditional expectation of the return**. Because it is a conditional expectation, the tower property applies, and splitting the return into its first term plus the discounted remainder and conditioning on the next state gives exactly the Bellman equation — so the Bellman equation is not a separate principle but an instance of a probability identity. TD's target r + gamma V(s') is a single-sample estimate of the right-hand side of that identity, so the TD error is a sampled residual whose expectation is zero precisely when the identity holds, which is why driving it to zero finds the value function. The advantage Q - V has zero mean under the policy because V is by construction the policy-weighted average of Q, which is again the tower property, one level down. And when V is correct, E\[r + gamma V(s') | s, a\] = Q(s,a) by the same identity, so the TD error's conditional expectation is Q(s,a) - V(s) = A(s,a), making it an unbiased advantage estimate. One conditional expectation, five consequences — and the fifth is exactly what Chapter 9 builds policy gradients on.

**P3 (coding).** Value iteration on a 4x4 gridworld. Expected observations: the sup-norm error against the converged solution falls geometrically, so on a log scale it is a straight line whose slope is log(gamma) — that is the contraction theorem made visible, and it is worth plotting for two values of gamma to see the slope change. Values propagate outward from the goal one cell per sweep initially, because information travels one step per Bellman backup; this is why the number of sweeps needed scales with the diameter of the state space as well as with gamma.

**P5 (coding).** Cliff-walking. Expected results: Q-learning's greedy policy hugs the cliff edge (the optimal path); SARSA's runs one or two rows higher. During training with epsilon-greedy behaviour, SARSA accumulates **higher** online return because it falls off less often. After training, if you set epsilon to 0 and evaluate greedily, **Q-learning's policy is better** because it is genuinely optimal and there is no longer any exploration to fall victim to. That reversal is the whole lesson: SARSA optimizes the policy you are actually running, Q-learning optimizes the policy you will eventually run.

**P6 (coding).** Maximization bias. The standard construction: a start state A with two actions, one terminating with reward 0, the other moving to state B from which many actions all give rewards drawn from N(-0.1, 1). The optimal choice at A is to terminate, since B's true value is negative. But Q-learning's max over B's many noisy estimates is positive early on, so it prefers B — often taking thousands of episodes to correct, and the more actions B has, the worse the bias. Double Q-learning picks the argmax with one estimator and evaluates with the other; since their noise is independent, the selected action's evaluation is not inflated, and it prefers termination almost immediately. Plot the fraction of episodes taking the left action against episode number for both.

**P7 (coding).** n-step sweep. Expected shape: error falls as n increases from 1 (high bias from bootstrapping on a poor value estimate), reaches a minimum at intermediate n, then rises as n grows toward the episode length (high variance from long sampled returns). The optimum typically sits between 3 and 10 for common benchmarks. Its position moves right when the value function is poor (trust the samples more) and left when the value function is good (trust the bootstrap more) — which is exactly the interpretation of lambda in GAE, seen from the n-step side.

**P8 (coding).** Baird's counterexample. With linear function approximation, off-policy updates and TD bootstrapping all present, the weights diverge to infinity — the value estimates grow without bound even though the true values are finite and the reward is zero everywhere. Removing any one leg restores stability: switching the behaviour policy to match the target policy (on-policy) converges; replacing the TD target with a Monte Carlo return (no bootstrapping) converges; using a tabular representation (no function approximation) converges. **Running this once is the fastest way to stop thinking of the deadly triad as an abstraction.**

**P9 (coding).** DQN on CartPole, four configurations. Expected: **with both** target network and replay, stable learning to a solved policy. **Replay only, no target network**: learning starts, then the value estimates inflate and the policy collapses, often repeatedly — the classic moving-target oscillation. **Target network only, no replay**: very slow and noisy, because consecutive transitions within an episode are highly correlated so each gradient step is based on an unrepresentative sample. **Neither**: generally fails to learn at all. The ordering of the middle two varies with the seed, which is itself worth noticing — it means a single run of each is not enough to rank them, and you should use several seeds, exactly as Chapter 4 argued.
