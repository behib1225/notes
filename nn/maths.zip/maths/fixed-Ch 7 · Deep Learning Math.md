﻿# Chapter 7 · The Mathematics of Deep Networks

2026-09-22 · @Behi

The previous six chapters built general tools. This one applies them to the specific architectures you will be asked about, and it is where the payoff becomes concrete: initialization is a variance calculation, normalization is a Jacobian argument, the square root in attention is a second-moment computation, and residual connections are a statement about products of matrices.

Every result here is derived rather than asserted, because "why does this work" is exactly what interviews probe and what research requires.

## 7.1 Why depth

### Universal approximation, and why it explains less than you think

The classical theorem: a feedforward network with **one** hidden layer and a non-polynomial activation can approximate any continuous function on a compact set to arbitrary accuracy, given enough hidden units.

This is a good thing to be able to state and a better thing to be able to criticize, because it is often quoted as if it justified deep learning. It does not, for four reasons:

1. **It says nothing about how many units you need.** The required width can be exponential in the input dimension.
2. **It says nothing about learnability.** It asserts a network *exists*, not that gradient descent finds it.
3. **It says nothing about generalization.** Approximating the function on your training points is not the goal.
4. **It applies to shallow networks**, so it cannot explain why depth helps at all.

The requirement on the activation is worth noting: it must be **non-polynomial**. A polynomial activation of degree k gives a network that can only represent polynomials of degree at most k^L, a strictly limited class. Any non-polynomial continuous activation suffices, which is why the exact choice of nonlinearity matters far less for expressivity than for optimization.

### What depth actually buys: exponential efficiency

The sharper statement, and the one that justifies depth, concerns **efficiency** rather than possibility. There are functions computable by a deep network with polynomially many units that require exponentially many units in any shallow network.

A clean concrete example: consider a ReLU network on one input where each layer computes a "folding" map (like the absolute-value or triangle-wave map). Each layer doubles the number of linear pieces, so **L layers give on the order of 2^L pieces with O(L) parameters**, while a shallow network needs one unit per piece. Depth compounds multiplicatively; width accumulates additively.

The general count: a ReLU network partitions its input space into regions on which it is affine, and the number of such regions grows exponentially in depth but only polynomially in width. That is the cleanest available formal statement of "depth is more parameter-efficient than width", and it is a good interview answer.

### The compositional argument

The more intuitive story, and the one that connects to practice: real data has **compositional, hierarchical structure**. Edges compose into textures, textures into parts, parts into objects. Characters compose into words, words into phrases, phrases into meaning. A deep network's layered structure matches that structure, so it can reuse intermediate computations rather than rebuilding each concept from scratch.

This is an argument about a **match between the architecture's inductive bias and the data's structure**, not about raw expressivity — which is exactly why the same architecture that excels on images and language does not automatically excel on arbitrary tabular data, where gradient-boosted trees remain competitive. Being able to make that distinction is worth more than reciting the universal approximation theorem.

### Why depth is hard to use

Everything that makes depth powerful also makes it difficult, and Chapter 2 already gave the mechanism. The gradient reaching layer 1 is a product of L Jacobians:

$$
\frac{\partial \mathcal{L}}{\partial a^{(1)}} = J_L J_{L-1}\cdots J_2
$$

If the typical singular value of each factor is s, the product scales as s^{L-1}. For s = 0.9 and L = 50 that is 0.005; for s = 1.1 it is 117. **Depth amplifies any systematic bias in the Jacobians exponentially.** Sections 7.2, 7.3 and 7.4 are, respectively, three answers to this one problem:

- **Initialization** sets s near 1 at the start.
- **Normalization** keeps it near 1 as training proceeds.
- **Residual connections** change each Jacobian to I + J, so the product stays near the identity by construction.

That framing — three mechanisms, one problem — is the organizing idea of this chapter and a very clean thing to say out loud.

```mermaid
flowchart TD
  P["ONE PROBLEM<br/>gradient = product of L Jacobians<br/>so it scales as s^L"]
  P --> I["Initialization<br/>set s near 1 at step 0"]
  P --> N["Normalization<br/>keep s near 1 during training"]
  P --> R["Residual connections<br/>replace J by I + J<br/>so the product cannot decay"]
  I --> S7["Section 7.2"]
  N --> S3["Section 7.3"]
  R --> S4["Section 7.4"]
```

Keep this diagram in mind for the next three sections. They look like three unrelated engineering tricks and they are three answers to one question: **how do you stop a product of L matrices from exploding or vanishing?**

### The historical arc, briefly

Worth knowing because interviewers sometimes ask what changed.

Deep networks were known to be more expressive long before they were trainable. What made them trainable was a sequence of specific fixes to the product-of-Jacobians problem: ReLU (derivative exactly 1 on the active side, rather than at most 0.25 for sigmoid), principled initialization (section 7.2), normalization layers (7.3), residual connections (7.4), and adaptive optimizers (Chapter 6). None of these changed what networks could represent; all of them changed what gradient descent could find. **The bottleneck was optimization, not expressivity**, and that is the correct one-sentence history.

**Try it.** (a) A ReLU network with L layers and width w: roughly how does the number of affine regions scale in L and in w? (b) Why does the universal approximation theorem fail to justify deep learning? Give three reasons. (c) With per-layer Jacobian singular values averaging 0.95, what fraction of the gradient reaches layer 1 in a 100-layer network? Answers in 7.11.

## 7.2 Initialization

This section is a pure variance calculation, and it is one of the most satisfying derivations in deep learning: a few lines of Chapter 3 algebra produce the formulas every framework uses.

### Two things that definitely fail

**All zeros.** Every unit in a layer computes the same thing, receives the same gradient, and updates identically. The layer has the expressive power of one unit forever. This is the **symmetry-breaking** problem, and random initialization exists to solve it. It is one of the most commonly asked questions in the subject.

**Too large or too small.** Activations grow or shrink geometrically with depth, and by the product-of-Jacobians argument so do gradients. Section 7.1's exponent is what you are fighting.

### The variance calculation

Consider a linear layer z = Wx with W of shape (n\_out x n\_in), entries drawn i.i.d. with mean 0 and variance sigma\_w^2, and x with i.i.d. components of variance sigma\_x^2, independent of W. Then for a single output,

$$
z_i = \sum_{j=1}^{n_{\text{in}}} W_{ij}x_j \quad \Longrightarrow \quad \operatorname{Var}(z_i) = n_{\text{in}}\,\sigma_w^2\,\sigma_x^2
$$

The variances add because the terms are independent and mean-zero (Chapter 3), and each term has variance sigma\_w^2 sigma\_x^2 because the variance of a product of independent mean-zero variables is the product of their variances.

**To preserve variance across the layer, you need n\_in sigma\_w^2 = 1:**

$$
\sigma_w^2 = \frac{1}{n_{\text{in}}}
$$

That is the whole derivation. Everything else is a correction to it.

### Xavier / Glorot

The forward pass wants 1/n\_in. But the backward pass propagates gradients through W transpose, and the identical calculation there wants 1/n\_out. You cannot satisfy both unless the layer is square, so Glorot initialization takes the harmonic compromise:

$$
\sigma_w^2 = \frac{2}{n_{\text{in}} + n_{\text{out}}}
$$

This was derived for **symmetric activations around zero with derivative near 1 at the origin**, such as tanh, where the nonlinearity roughly preserves variance near the origin.

### He / Kaiming

ReLU breaks the assumption: it zeroes half the inputs. For a symmetric mean-zero pre-activation, ReLU keeps the positive half and discards the rest, and a short calculation gives

$$
\operatorname{Var}\big(\text{ReLU}(z)\big) = \tfrac{1}{2}\operatorname{Var}(z)
$$

**ReLU halves the variance**, so you must double the weight variance to compensate:

$$
\sigma_w^2 = \frac{2}{n_{\text{in}}}
$$

That factor of 2 is the entire difference between Xavier and He, and being able to say *where it comes from* — ReLU discarding half the mass — is exactly the level of understanding an interview is testing. Use He for ReLU and its relatives, Xavier for tanh, and note that the leaky-ReLU version generalizes the constant to 2/(1 + a^2).

### Other initializations worth knowing

| Scheme | Formula | Use |
| --- | --- | --- |
| He / Kaiming | variance 2/n\_in | ReLU, GELU, and relatives |
| Xavier / Glorot | variance 2/(n\_in + n\_out) | tanh, sigmoid |
| LeCun | variance 1/n\_in | SELU, self-normalizing networks |
| Orthogonal | a random orthogonal matrix, optionally scaled | RNNs and very deep nets; all singular values exactly 1 |
| Zero | exact zeros | **biases**, and the final layer of a residual block |
| Scaled residual | 1/sqrt(2L) times the standard scheme | deep transformers, to control residual-stream growth |

**Orthogonal initialization** deserves a note because it connects directly to Chapter 1: an orthogonal matrix has all singular values exactly 1, so it neither amplifies nor attenuates in any direction. That is the ideal starting point for the product-of-Jacobians problem, and it is why it helps most in the deepest networks.

**Zero-initializing the last layer of each residual block** is a widely used trick with a clean rationale: at initialization the block computes exactly the identity, so the network starts as a shallow model and learns to use its depth gradually. Variants of this idea appear throughout modern training recipes, and it is also why LoRA initializes one of its two factors to zero — the adapter starts as a no-op.

### What actually goes wrong

To make the stakes concrete: with a 50-layer network and a scheme that shrinks variance by 0.9 per layer, the final activations have variance 0.9^50, about 0.005 — a 200-fold attenuation. The gradients suffer the same fate. In the other direction, a factor of 1.1 per layer gives 117x amplification and immediate overflow. **The window of workable initializations is narrow and it closes exponentially fast with depth**, which is why this is not a detail you can hand-wave.

The diagnostic is simple and worth doing on any new architecture: run one forward pass on a batch and print the standard deviation of the activations at every layer. If it is drifting systematically up or down, your initialization or your normalization placement is wrong, and you will find out cheaply rather than after a failed training run.

### Why this matters less than it used to

An honest qualification. Normalization layers re-standardize activations at every block, so they substantially reduce sensitivity to initialization scale, and residual connections do the same for gradients. A modern transformer with pre-norm and residuals will train from a fairly wide range of initializations.

But initialization still matters for: networks without normalization, the very earliest steps of training (before normalization statistics settle), very deep models where the residual stream's variance growth accumulates, and any custom architecture where you cannot rely on standard defaults. And understanding the variance argument is what lets you reason about a new architecture at all.

**Try it.** (a) Derive that ReLU halves the variance of a symmetric mean-zero input. (b) A layer has n\_in = 512 and n\_out = 2048. Give the He and Xavier standard deviations. (c) Why is zero initialization fine for biases but fatal for weights? Answers in 7.11.

## 7.3 Normalization layers

### The common form

Every normalization layer does the same three things: subtract a mean, divide by a standard deviation, then apply a learned affine transform.

$$
\hat{x} = \frac{x - \mu}{\sqrt{\sigma^2 + \epsilon}}, \qquad y = \gamma \odot \hat{x} + \beta
$$

**The only thing that distinguishes them is which axes mu and sigma are computed over.** Get that straight and the whole family is clear.

| Layer | Statistics computed over | Shape of mu and sigma for input (B, T, C) |
| --- | --- | --- |
| **BatchNorm** | the batch (and spatial positions) | one value per channel: (C,) |
| **LayerNorm** | the feature dimension, per token | one value per token: (B, T) |
| **RMSNorm** | the feature dimension, no mean subtraction | one value per token |
| **GroupNorm** | groups of channels, per example | (B, groups) |
| **InstanceNorm** | spatial positions, per channel per example | (B, C) |

### Why the learned affine transform exists

A reasonable objection: if you just normalized the activations, why immediately add parameters that can un-normalize them? The answer is that **normalization without gamma and beta removes representational capacity**. A layer forced to have zero mean and unit variance cannot, for example, place its outputs in the saturating region of a sigmoid even when that is useful, and it cannot learn a preferred scale. The affine transform restores the ability to represent any mean and scale, while the *optimization* benefit of normalization comes from the fact that the scale is now controlled by a single well-conditioned parameter rather than emerging from a product of many weights.

### BatchNorm

Normalizes each channel across the batch. Its train/inference asymmetry is essential and is a very common interview question.

- **At training time** it uses the statistics of the current minibatch.
- **At inference time** it uses running averages accumulated during training, because you need a deterministic function of a single input. A model that behaves differently in train and eval mode almost always has BatchNorm (or dropout) as the culprit, and forgetting to switch modes is a classic bug.

Its problems, all of which follow from its dependence on the batch:

- **Small batches give noisy statistics**, so performance degrades badly at batch size 1 or 2.
- **It couples examples within a batch**, which breaks the usual assumption that each prediction depends only on its own input, and complicates distributed training (you either sync statistics across devices or accept per-device statistics).
- **It is awkward for variable-length sequences**, where padding pollutes the statistics.
- There is a train/test distribution mismatch whenever the running statistics do not match the deployment data.

These are exactly why transformers use LayerNorm instead.

**Why it helps.** The original explanation was "reducing internal covariate shift", and the honest position is that this has been substantially challenged: later work showed BatchNorm helps even when covariate shift is deliberately reintroduced, and argued instead that it smooths the loss landscape and improves conditioning. The safest accurate statement is that BatchNorm improves the conditioning of the optimization problem and allows larger learning rates, with the internal-covariate-shift story now regarded as at best incomplete. Saying that, rather than repeating the original explanation, is a genuine signal.

### LayerNorm

Normalizes across features within each token, independently for every example. It has no batch dependence at all, so it behaves identically in training and inference, works at batch size 1, and handles variable-length sequences cleanly. That is why it is the transformer default.

Its backward pass was derived in Chapter 2 and the geometric reading is worth repeating: **the incoming gradient has its mean removed and its component along the normalized activation removed, then is rescaled.** Those two subtractions enforce exactly the two invariances of the forward pass — shifting all features by a constant and scaling them all by a constant both leave the output unchanged, so the gradient can have no component along either direction.

### RMSNorm

Drop the mean subtraction entirely:

$$
y = \frac{x}{\sqrt{\frac{1}{d}\sum_i x_i^2 + \epsilon}} \odot \gamma
$$

The empirical finding is that the re-centering contributes little while the re-scaling does the work, so you can save the mean computation and the beta parameter. It is modestly faster and has become common in recent large language models. The mathematical content: it projects each token's representation onto a sphere of fixed radius, scaled per-dimension by gamma.

### The scale-invariance consequence

One mathematical fact with large practical consequences. For a linear layer followed by any of these normalizations,

$$
\text{Norm}\big((cW)x\big) = \text{Norm}(Wx) \quad \text{for any } c > 0
$$

**The function is completely invariant to the scale of the preceding weights.** Three consequences worth stating:

1. **Weight decay on those weights does not constrain the function class.** It only changes the weight norm, which in turn changes the effective learning rate — since the gradient with respect to a scale-invariant parameter is inversely proportional to its norm. This is why weight decay's role in normalized networks is partly an optimization effect rather than a capacity one (Chapter 4, section 4.7).
2. **The gradient is orthogonal to the weight vector.** A scale-invariant function has zero derivative along the radial direction, so weight norms grow only through the interaction of weight decay and the optimizer, producing the well-documented equilibrium weight-norm dynamics in normalized networks.
3. **Sharpness is not meaningful without care**, which is the point made in Chapter 6 about flat minima.

### Which to use

| Situation | Choice |
| --- | --- |
| Convolutional vision, large batches | BatchNorm |
| Transformers, sequences | LayerNorm or RMSNorm |
| Small or variable batch size | LayerNorm, GroupNorm |
| Style transfer, generative image models | InstanceNorm, or adaptive variants |
| Detection and segmentation with small batches | GroupNorm |

**Try it.** (a) For an input of shape (32, 128, 768), state the shape of the statistics computed by BatchNorm, LayerNorm and GroupNorm with 12 groups. (b) Why does BatchNorm need running statistics but LayerNorm does not? (c) Show that scaling a weight matrix before a LayerNorm leaves the output unchanged, and say what that implies for weight decay. Answers in 7.11.

## 7.4 Residual connections

### The construction

$$
y = x + F(x)
$$

Each block computes a **correction** to its input rather than a replacement. Two lines of algebra explain why this changes everything.

### The Jacobian argument

Differentiate the block:

$$
\frac{\partial y}{\partial x} = I + \frac{\partial F}{\partial x}
$$

Now the gradient through L blocks is a product of terms of the form (I + J\_l) rather than J\_l. Expanding:

$$
\prod_{l=1}^{L}(I + J_l) = I + \sum_l J_l + \sum_{l < m} J_m J_l + \cdots
$$

**The identity term survives no matter how deep the network is.** Even if every J\_l is tiny, the gradient reaching layer 1 still contains a clean copy of the gradient from the top. There is no exponential decay, because there is nothing to decay — the leading term is exactly 1.

Compare with a plain network, where the product of L Jacobians with typical singular value s scales as s^L and dies geometrically. **That contrast is the entire mathematical content of residual connections**, and it is the answer to give.

The expansion above also supports a useful alternative reading: the sum of products over subsets of blocks makes a residual network behave somewhat like an **ensemble of exponentially many paths of differing depth**, most of them short. That is an empirically supported interpretation and explains why deleting a single block from a trained residual network usually does little damage, whereas deleting a layer from a plain network is catastrophic.

### The learning argument

There is a second, independent reason. If the optimal transformation for a block is close to the identity — which it often is in a deep stack where each layer should refine rather than transform — then a plain block must *learn* to approximate the identity, which is a surprisingly hard thing for a randomly initialized layer to do. A residual block gets it for free by setting F to zero.

This reframes the degradation problem that motivated residual networks: deeper plain networks were observed to have *higher training error* than shallower ones, which cannot be an expressivity problem, since the deeper network can represent anything the shallower one can by making the extra layers identities. It was an optimization problem, and residual connections solved it by making the identity the default rather than something to be discovered.

### Pre-norm versus post-norm

Where you put the normalization relative to the residual matters, and this is a standard modern interview question.

$$
\text{Post-norm: } \; y = \text{LN}\big(x + F(x)\big) \qquad \text{Pre-norm: } \; y = x + F\big(\text{LN}(x)\big)
$$

|  | Post-norm (original transformer) | Pre-norm (modern default) |
| --- | --- | --- |
| Residual path | passes through LayerNorm each block | **completely clean** from input to output |
| Gradient flow | attenuated by each LN's Jacobian | direct; the identity path is unobstructed |
| Warmup | essentially required | helpful but less critical |
| Depth | harder to train very deep | trains reliably at large depth |
| Final quality | sometimes marginally better when it trains | slightly worse in some comparisons |
| Needs | careful tuning | a final LayerNorm before the output head |

The key structural point: **in pre-norm, there is an unbroken additive path from the embedding to the output**, so the identity term in the Jacobian product is never modified. In post-norm, every block's output passes through a normalization, so the clean path is interrupted L times. That is why pre-norm is the default in essentially all modern large language models, and why post-norm needed careful warmup to train at all.

A practical detail that follows: a pre-norm network needs a **final LayerNorm** before the output projection, because the residual stream's scale has been growing unchecked through the stack.

### The residual stream

The pre-norm structure supports a particular way of thinking about transformers that has become standard in interpretability work, and it is worth knowing because it reframes the architecture usefully.

View the residual path as a **shared communication channel** of dimension d that runs the full depth of the model. Every block **reads** from it (through its normalization and input projections), computes something, and **writes back additively**. Nothing is ever overwritten; contributions accumulate.

Consequences of this view:

- **Blocks communicate through subspaces.** A block writing into a particular subspace can be read by any later block that projects onto that subspace, whether adjacent or fifty layers later.
- **The output logits are a sum of contributions** from the embedding and from every block, which is what makes logit attribution possible: you can decompose a prediction into per-block contributions exactly, because the composition is additive.
- **Dimension d is a bandwidth constraint.** Everything every block wants to communicate must fit into d dimensions, which connects directly to the superposition idea from Chapter 3: with near-orthogonality in high dimensions, far more than d features can share the channel at the cost of small interference.

### Variance growth

A quantitative point worth knowing. If each block's output is roughly independent of the stream with comparable variance, the variance of the residual stream **grows linearly with depth**, so the standard deviation grows as sqrt(L). This is why deep transformers often scale the residual branch's output initialization by something like 1/sqrt(2L), and why a final normalization is needed. It is also relevant to numerical precision: a stream whose magnitude grows with depth interacts badly with low-precision formats.

**Try it.** (a) Write the Jacobian of a residual block and explain why the product over L blocks does not vanish. (b) Why did deeper plain networks have *higher training* error, and why is that an optimization rather than an expressivity statement? (c) State two concrete advantages of pre-norm over post-norm. Answers in 7.11.

## 7.5 Activation functions

### What actually matters

The properties that determine whether an activation trains well:

1. **Non-polynomial** — required for universal approximation (section 7.1). Every reasonable choice satisfies this, so it never discriminates between candidates.
2. **Derivative magnitude** — the direct input to the product-of-Jacobians problem. A derivative capped well below 1 kills deep networks.
3. **No saturating regions that trap you** — a region where the derivative is essentially zero and from which the unit cannot escape.
4. **Zero-centered output** — off-center outputs bias the gradients of the next layer's weights all in the same direction.
5. **Cheap to compute**, since it runs on every activation of every layer.

### The sigmoid family, and why they lost

$$
\sigma(x) = \frac{1}{1+e^{-x}}, \qquad \sigma'(x) = \sigma(x)\big(1 - \sigma(x)\big) \le \tfrac{1}{4}
$$

**The derivative never exceeds 0.25.** Across 10 layers that is a factor of at most 0.25^10, about 10^-6, and in practice worse because units sit away from the origin. That single number is the quantitative reason deep sigmoid networks were untrainable, and it is a good one to quote.

**tanh** fixes the centering (output in \[-1,1\], derivative up to 1 at the origin) and is genuinely better than sigmoid, which is why it survived longer in RNNs. It still saturates at both ends.

Sigmoid remains correct as an **output** activation for binary classification, where it is the inverse canonical link (Chapter 4) and its saturation is cancelled by the cross-entropy log.

### ReLU

$$
\text{ReLU}(x) = \max(0,x), \qquad \text{ReLU}'(x) = \mathbb{1}[x > 0]
$$

What it gets right: **the derivative is exactly 1 on the active side**, so there is no attenuation with depth; it is extremely cheap; and it induces sparsity, since roughly half the units are inactive for any input.

What it gets wrong: **dead units.** If a unit's pre-activation is negative for every input in the data — typically after a large gradient step pushes its bias very negative — then its derivative is 0, its gradient is 0, and it never recovers. A layer can lose a substantial fraction of its capacity this way, and a high learning rate makes it more likely. It is also not zero-centered and not differentiable at 0, though the latter is a non-issue (Chapter 2).

### The modern family

| Activation | Definition | Property that matters |
| --- | --- | --- |
| Leaky ReLU | x for x>0, ax otherwise | nonzero gradient everywhere; no dead units |
| PReLU | same with learned a | one extra parameter per channel |
| ELU | x for x>0, a(e^x - 1) otherwise | smooth, negative saturation, mean closer to zero |
| **GELU** | x times the standard normal CDF of x | smooth, small negative lobe; the transformer standard |
| SiLU / Swish | x times sigmoid(x) | very close to GELU, cheaper |
| Softplus | log(1 + e^x) | smooth ReLU; derivative is exactly sigmoid |
| **SwiGLU** | (Wx ⊙ SiLU(Vx)) | a gated variant used in many recent language models |

**GELU** deserves the detail because it is what transformers use. The definition multiplies the input by the probability that a standard normal is below it:

$$
\text{GELU}(x) = x\,\Phi(x)
$$

The probabilistic reading: it is the expected value of x times a Bernoulli gate whose probability of being open depends on how large x is. So instead of ReLU's hard gate, the input is scaled smoothly by how far above zero it sits. Its practical advantages: it is smooth (so the loss surface is smoother), it has a **small negative lobe** — the function dips slightly below zero for moderately negative inputs before returning to zero — which appears to help, and it has no dead-unit problem since its derivative is nonzero almost everywhere. The tanh-based approximation exists because the exact Phi is more expensive.

**Gated activations (GLU, SwiGLU, GeGLU)** are the notable recent development. The structure is

$$
\text{SwiGLU}(x) = \big(W_1 x\big) \odot \text{SiLU}\big(W_2 x\big)
$$

One projection produces a value and another produces a **gate** that modulates it multiplicatively. This is more expressive than an elementwise nonlinearity because it introduces a genuine multiplicative interaction between two learned projections. It costs a third weight matrix, so implementations typically shrink the hidden dimension to roughly two-thirds to keep the parameter count comparable. Several recent large language models use SwiGLU in their feedforward blocks.

### The honest summary

A good answer acknowledges that **the differences among modern activations are small.** ReLU, GELU, SiLU and their gated variants all train well, and the gains from switching are typically fractions of a percent. What matters enormously is the jump from saturating activations (sigmoid, tanh) to non-saturating ones; what matters little is the choice among the non-saturating family. Defaults: ReLU for convolutional networks, GELU or SwiGLU for transformers, and do not spend time tuning this before you have tuned the learning rate.

**Try it.** (a) Derive that the sigmoid derivative is at most 1/4 and identify where. (b) Explain the dead ReLU problem, including why a high learning rate makes it more likely, and give two fixes. (c) Show that the derivative of softplus is exactly the sigmoid, and say why that is a pleasing relationship. Answers in 7.11.

## 7.6 The transformer, in full

Every shape is annotated. Work through it with a pen once and you will never again be uncertain about a transformer's dimensions, which is a large fraction of what interviews on this topic actually test.

### Notation

| Symbol | Meaning | Typical value |
| --- | --- | --- |
| B | batch size | 8 to 2048 |
| T | sequence length | 512 to 128k |
| d | model dimension (the residual stream width) | 768 to 16384 |
| h | number of heads | 12 to 128 |
| d\_k | dimension per head, equal to d/h | 64 to 128 |
| d\_ff | feedforward hidden dimension, usually 4d | 3072 to 65536 |
| V | vocabulary size | 32k to 256k |
| L | number of layers | 12 to 120 |

### The forward pass

**Embedding.** Token ids of shape (B, T) index into an embedding matrix of shape (V, d), giving X of shape (B, T, d). As Chapter 1 noted, this is multiplication by a one-hot matrix, which is why it has a clean gradient: the gradient accumulates into the rows that were used.

**Attention, one head.**

$$
Q = XW_Q, \quad K = XW_K, \quad V = XW_V, \qquad W_\bullet \in \mathbb{R}^{d \times d_k}
$$

$$
S = \frac{QK^{\top}}{\sqrt{d_k}} \in \mathbb{R}^{T\times T}, \qquad A = \operatorname{softmax}_{\text{row}}(S + M), \qquad O = AV \in \mathbb{R}^{T \times d_k}
$$

M is the causal mask: zero where attention is allowed, negative infinity where it is not, so those entries receive exactly zero softmax weight.

**Reading the shapes is reading the semantics.** S is (T, T), so entry (i, j) is how much position i attends to position j. A's rows sum to 1, so each position forms a **convex combination of the value vectors** — attention is a weighted average, and the weights come from query-key alignment, which by Chapter 1 is what an inner product measures.

**Multi-head.** Run h of these in parallel with d\_k = d/h, concatenate the outputs to get (T, d), and project through W\_O of shape (d, d). In practice the h heads are computed as one batched matrix multiply by reshaping, not as a loop. The parameter count for the attention block is 4d^2, from the four projection matrices.

Why multiple heads: each head can attend on a different basis — one on syntactic adjacency, another on coreference, another on positional offset — and a single softmax must commit to one attention pattern. Splitting the dimension rather than adding capacity means multi-head attention costs the same as single-head attention with full width.

**Feedforward.**

$$
\text{FFN}(x) = W_2\,\phi(W_1 x + b_1) + b_2, \qquad W_1 \in \mathbb{R}^{d_{ff}\times d}, \; W_2 \in \mathbb{R}^{d \times d_{ff}}
$$

Applied identically and independently at every position. With d\_ff = 4d, this contributes 8d^2 parameters, so **the feedforward block holds twice the parameters of the attention block** — a fact people often get backwards.

The standard reading: attention **moves information between positions**; the feedforward network **processes information within a position**. A transformer block alternates the two, which is why removing either breaks the model in a different way.

**The block, pre-norm.**

$$
x \leftarrow x + \text{Attn}\big(\text{LN}(x)\big), \qquad x \leftarrow x + \text{FFN}\big(\text{LN}(x)\big)
$$

**Output.** A final LayerNorm, then a projection to (B, T, V), then softmax. The output projection is often **weight-tied** to the embedding matrix, which saves Vd parameters and reflects the idea that the same token-to-vector map should serve both directions.

### The backward pass

Every step uses only rules from Chapter 2. Given dL/dO:

$$
\frac{\partial L}{\partial V} = A^{\top}\frac{\partial L}{\partial O}, \qquad \frac{\partial L}{\partial A} = \frac{\partial L}{\partial O}V^{\top}
$$

Through the row-wise softmax, using the VJP form so you never build the Jacobian:

$$
\frac{\partial L}{\partial S_{i,:}} = A_{i,:} \odot \frac{\partial L}{\partial A_{i,:}} - A_{i,:}\left( A_{i,:}^{\top}\frac{\partial L}{\partial A_{i,:}} \right)
$$

Then through the scaled product:

$$
\frac{\partial L}{\partial Q} = \frac{1}{\sqrt{d_k}}\frac{\partial L}{\partial S}K, \qquad \frac{\partial L}{\partial K} = \frac{1}{\sqrt{d_k}}\left(\frac{\partial L}{\partial S}\right)^{\top}Q
$$

and finally through the projections with the linear-layer rule: dL/dW\_Q = X' (dL/dQ), and so on, with the three contributions to dL/dX summed because X feeds three places (Chapter 2's accumulation rule).

**Nothing here is new.** A transformer's backward pass is linear-layer rules, a softmax VJP, and elementwise chain rules, composed. That is the point worth making: complicated architectures do not have complicated derivatives.

### The square root, derived

The most-asked transformer question, with the calculation rather than the slogan.

Let q and k have i.i.d. entries with mean 0 and variance 1. Their inner product is a sum of d\_k independent products:

$$
\mathbb{E}[q^{\top}k] = 0, \qquad \operatorname{Var}(q^{\top}k) = \sum_{i=1}^{d_k}\operatorname{Var}(q_i k_i) = d_k
$$

So a typical logit has magnitude sqrt(d\_k): about 8 for d\_k = 64, about 11 for d\_k = 128.

Why that is bad: softmax over logits separated by more than roughly 10 is numerically one-hot, and by Chapter 5's result its Jacobian diag(p) - pp' then goes to zero. **Saturated attention has vanishing gradients**, so the attention weights stop learning. Dividing by sqrt(d\_k) makes the logit variance exactly 1 regardless of head dimension, keeping the softmax in its responsive range.

**Try it.** (a) For d = 768, h = 12, d\_ff = 3072, V = 50257, L = 12: compute the parameters in one attention block, one FFN block, all 12 layers, and the embedding. (b) Why is the attention matrix (T, T) and what does that imply for long sequences? (c) Derive the sqrt(d\_k) scaling from scratch. Answers in 7.11.

## 7.7 Embeddings and positional information

### Why position needs to be added at all

Attention is **permutation-equivariant**: permute the input tokens and the outputs are permuted identically, with no other change. The proof is immediate from the formulas in 7.6 — every operation treats the sequence dimension as a set, since QK' produces all pairwise scores and the softmax-weighted sum has no notion of order.

So a transformer without positional information cannot distinguish "dog bites man" from "man bites dog". Position must be injected explicitly, and how to do it is a live design question. This is the cleanest available statement of why positional encoding exists, and it is what an interviewer wants to hear.

### The options

| Scheme | How | Extrapolates beyond training length? |
| --- | --- | --- |
| Learned absolute | a trainable vector per position, added to the embedding | **no** — undefined past the trained maximum |
| Sinusoidal absolute | fixed sinusoids of varying frequency, added | in principle, poorly in practice |
| Relative (T5-style bias) | a learned bias added to attention logits, depending on i - j | reasonably, with bucketing |
| ALiBi | a linear penalty proportional to distance, added to logits | well, by construction |
| **RoPE** | rotate Q and K by an angle proportional to position | reasonably, and extendable by interpolation |
| NoPE | nothing, relying on the causal mask | surprisingly workable in decoder-only models |

### Sinusoidal encoding

$$
PE_{(pos, 2i)} = \sin\!\left(\frac{pos}{10000^{2i/d}}\right), \qquad PE_{(pos, 2i+1)} = \cos\!\left(\frac{pos}{10000^{2i/d}}\right)
$$

The design: different dimensions oscillate at **geometrically spaced frequencies**, from wavelength 2*pi at one end to about 10000*2\*pi at the other. Low-frequency dimensions distinguish coarse position, high-frequency dimensions distinguish adjacent tokens. It is essentially a positional analogue of a binary encoding, with each dimension acting as a bit of varying significance.

The property that motivated it: **PE(pos + k) is a fixed linear function of PE(pos)**, because a shift in a sine argument is a rotation in the (sin, cos) pair. So relative position is linearly accessible. In practice its extrapolation is weaker than that suggests, and learned absolute embeddings performed about as well, which is why the field moved on.

### RoPE, derived

Rotary position embedding is the current default in most large language models, and the derivation is short and elegant enough to be worth doing.

**The goal:** make the attention logit between positions m and n depend only on m - n, without adding anything to the representations.

**The construction.** Split the head dimension into pairs and treat each pair as a point in the plane. For a query at position m, rotate every pair by an angle m\*theta\_i, where theta\_i is a per-pair frequency using the same geometric spacing as the sinusoidal scheme:

$$
\tilde{q}_m = R(m\theta)\,q_m, \qquad \tilde{k}_n = R(n\theta)\,k_n
$$

with R a block-diagonal rotation matrix. Now compute the attention logit, using the fact from Chapter 1 that rotations preserve inner products and that R(a)' R(b) = R(b - a):

$$
\tilde{q}_m^{\top}\tilde{k}_n = q_m^{\top}R(m\theta)^{\top}R(n\theta)k_n = q_m^{\top}R\big((n-m)\theta\big)k_n
$$

**The logit depends on position only through n - m.** Absolute rotations applied separately to queries and keys produce an exactly relative interaction. That is the whole idea, and it rests on one property of orthogonal matrices from Chapter 1.

Why it is preferred:

- It is genuinely relative, with no learned positional parameters at all.
- It does not add to the residual stream, so it does not consume representational bandwidth.
- It is applied to Q and K only, leaving V untouched, so the values carry pure content.
- The rotation preserves norms, so it does not disturb the scale analysis of section 7.6.
- It is compatible with the KV cache, since a cached key's rotation is already baked in.

**Context extension.** Because RoPE's behaviour is governed by the frequencies theta\_i, you can extend the usable context by modifying them. **Position interpolation** scales positions down so that a longer sequence maps into the range seen during training. **NTK-aware scaling** and **YaRN** adjust frequencies non-uniformly, on the reasoning that high-frequency components carry local information that should be preserved while low-frequency components determine the long-range scale that needs stretching. These methods make it possible to extend a model's context with modest fine-tuning rather than retraining, and knowing that they are frequency manipulations rather than architectural changes is the substantive point.

### ALiBi

The simplest alternative: add a penalty to each attention logit proportional to the distance between positions, with a per-head slope.

$$
S_{ij} \leftarrow \frac{q_i^{\top}k_j}{\sqrt{d_k}} - m_h\,|i - j|
$$

No learned parameters, no embeddings, and it extrapolates naturally because the penalty is defined for any distance. Different heads get different slopes, so some attend locally and others globally. It is a good illustration that positional information can be a **bias on the attention pattern** rather than a modification of the representations.

### Tokenization, briefly

Worth a mention because it interacts with everything above. Subword tokenizers (BPE, WordPiece, Unigram) trade vocabulary size against sequence length: a larger vocabulary gives shorter sequences (cheaper attention, since cost is quadratic in T) but a larger embedding and output matrix, and it makes per-token perplexity incomparable across models (Chapter 5). Tokenization is also where a surprising number of model quirks originate — arithmetic difficulties, character-level tasks, and whitespace sensitivity all trace back to how the text was split.

**Try it.** (a) Prove that attention without positional information is permutation-equivariant. (b) Show that R(a)' R(b) = R(b - a) for 2D rotation matrices, and use it to derive RoPE's relative property. (c) Why can a learned absolute positional embedding not extrapolate beyond the training length, while ALiBi can? Answers in 7.11.

## 7.8 Attention complexity and its variants

### The cost, counted

For one head with sequence length T and head dimension d\_k:

| Operation | FLOPs | Memory |
| --- | --- | --- |
| Q, K, V projections | O(T d d\_k) each | O(T d\_k) |
| QK' | **O(T^2 d\_k)** | **O(T^2)** |
| softmax | O(T^2) | O(T^2) |
| AV | **O(T^2 d\_k)** | O(T d\_k) |

The quadratic terms dominate once T is large. Concretely at T = 32,768 the attention matrix alone has about 10^9 entries **per head per layer**, which at 2 bytes each is 2 GB. With 32 heads and 32 layers, materializing those matrices is impossible.

**Where the crossover actually is, computed rather than guessed.** Per layer and per token, the projections plus the feedforward block cost about 24d^2 multiply-adds (4d^2 for the four attention projections, 8d^2 for the feedforward, each counted twice for multiply and add). Attention's own quadratic work costs about 4Td per token (the QK' and AV products). Setting 4Td = 24d^2 gives

$$
T_{\text{crossover}} \approx 6d
$$

So for d = 768 the crossover is near 4,600 tokens; for d = 4096, near 24,600; for d = 16384, near 98,000. **Attention dominates only well beyond a sequence length equal to the model dimension**, and the larger the model, the later that happens. People routinely assert that attention is always the dominant cost; below roughly 6d tokens it is not, and knowing the factor of 6 is what makes the answer precise rather than vague.

### FlashAttention's insight

The key realization: **the bottleneck is memory bandwidth, not arithmetic.** GPUs have a small amount of very fast on-chip SRAM and a large amount of slower high-bandwidth memory. A naive implementation writes the whole (T, T) score matrix to HBM, reads it back for the softmax, writes it again, and reads it once more for the AV product. The arithmetic is cheap; the round trips are not.

FlashAttention **never materializes the attention matrix**. It tiles the computation, loading blocks of Q, K and V into SRAM, computing partial attention outputs, and combining them using an **online softmax** — a running-maximum and running-sum formulation that lets you compute a correct softmax incrementally without ever holding the full row. The mathematical content is that softmax can be computed in a streaming fashion with a rescaling correction whenever a new maximum appears, which is the log-sum-exp trick from Chapter 1 applied in blocks.

The result: memory goes from O(T^2) to **O(T)**, the computation is exact (not an approximation), and it is substantially faster in wall-clock terms because it does far less memory traffic. For the backward pass it recomputes the attention blocks rather than storing them, which is gradient checkpointing (Chapter 2) applied at the kernel level.

**The lesson worth extracting:** the same FLOPs with a different memory access pattern can be several times faster. Being aware that arithmetic intensity, not FLOP count, often determines performance is a genuinely valuable perspective.

### The KV cache, and its arithmetic

During autoregressive generation, each new token attends to all previous ones. Recomputing every key and value each step would be O(T^2) work per token. Instead you **cache** them, so each step costs O(T) and generating T tokens costs O(T^2) overall rather than O(T^3).

The cost is memory, and the formula is worth memorizing because it is asked constantly in systems interviews:

$$
\text{KV cache bytes} = 2 \times L \times T \times h \times d_k \times \text{bytes per element} \times \text{batch}
$$

The leading 2 counts keys and values. Note that h times d\_k equals d, so the expression simplifies to 2 L T d elements per sequence.

**A worked example**, since the numbers surprise people. Take L = 32, d = 4096, T = 8192, fp16 (2 bytes), batch size 1:

2 x 32 x 8192 x 4096 x 2 = about 4.3 GB — **for a single sequence.** At batch size 32 that is 137 GB, which exceeds any single accelerator's memory. This is why serving long-context models is a memory problem rather than a compute problem, and why the cache, not the weights, is usually what limits your batch size.

### MQA and GQA

The fix follows directly from the formula: shrink the number of key-value heads.

| Scheme | Query heads | KV heads | Cache size |
| --- | --- | --- | --- |
| Multi-head (MHA) | h | h | full |
| **Grouped-query (GQA)** | h | g, with 1 < g < h | h/g times smaller |
| **Multi-query (MQA)** | h | 1 | h times smaller |

All query heads share a smaller set of key-value heads. MQA gives the largest saving and costs some quality; GQA with g of 4 or 8 is the common compromise and is used in many recent models, giving most of the memory saving with little quality loss.

The reason this works at all is worth stating: the queries are what differentiate the heads' attention patterns, so you can share the keys and values across several queries without collapsing the heads into one behaviour.

**Multi-head latent attention (MLA)** is a further development, compressing keys and values into a low-rank latent that is cached instead, which is Chapter 1's low-rank factorization applied to the cache.

### Sub-quadratic alternatives

| Approach | Mechanism | Cost |
| --- | --- | --- |
| Sliding window | attend only within a fixed window | O(T w) |
| Dilated / strided | attend to a strided subset | O(T sqrt T) typical |
| Global-plus-local | a few global tokens plus local windows | O(T) |
| Low-rank (Linformer) | project keys and values to a smaller length | O(T k) |
| Kernel / linear attention | replace softmax with a feature map so the product reassociates | O(T) |
| State-space models (Mamba and relatives) | a recurrent state with selective updates | O(T) |

**Linear attention** is the mathematically prettiest: if you can write the similarity as a feature-map inner product, then by associativity you compute (phi(K)'V) first, which is (d\_k x d\_k), and multiply by phi(Q) after — the same reassociation trick from Chapter 6's chain-rule discussion. Cost becomes linear in T. The catch is that dropping the softmax removes the sharp, selective attention that appears to matter for quality, and linear-attention models have generally underperformed on tasks needing precise retrieval.

**The honest state of this area:** exact attention with FlashAttention remains dominant in practice, because the constant factors of efficient implementations beat the asymptotics of approximations at practical sequence lengths. State-space and hybrid architectures are an active and promising line rather than a settled replacement; check current results rather than relying on a summary.

**Try it.** (a) Compute the KV cache size for L = 80, d = 8192, T = 4096, fp16, batch 8. (b) At what sequence length does attention's quadratic cost exceed the projection cost for d = 4096? (c) Explain why FlashAttention is exact rather than approximate, and where its speedup comes from. Answers in 7.11.

## 7.9 The arithmetic of scale

This section is estimation practice. Being able to do these calculations in your head is genuinely useful, and it is a common interview exercise for anyone working near large models.

### Parameter count

Per transformer layer, with d\_ff = 4d:

| Component | Parameters |
| --- | --- |
| Attention (four d x d projections) | 4d^2 |
| Feedforward (d to 4d and back) | 8d^2 |
| LayerNorms and biases | negligible, O(d) |
| **Per layer total** | **12d^2** |

So the whole model is approximately

$$
N \approx 12\,L\,d^2 \;+\; V d \quad (\text{embedding, doubled if not weight-tied})
$$

**Check it on a known model.** For d = 4096, L = 32: 12 x 32 x 4096^2 = about 6.4 billion, and with a 32,000-token vocabulary the embedding adds 0.13 billion. That lands in the right neighbourhood for a 7-billion-parameter model, and the small remainder comes from the gated feedforward (which uses three matrices rather than two, adding roughly 4d^2 more per layer). **The 12Ld^2 rule reproduces real parameter counts to within about 20%**, which is exactly what you want from a mental model.

### FLOPs

The rules of thumb, which are worth memorizing outright:

$$
\text{Forward: } \approx 2N \text{ FLOPs per token} \qquad \text{Training: } \approx 6N \text{ FLOPs per token}
$$

The 2 comes from one multiply and one add per parameter. The 6 is the forward-to-backward ratio of 1:2 from Chapter 2, so forward plus backward is three times forward, hence 6N. Total training compute is therefore

$$
C \approx 6\,N\,D
$$

with D the number of training tokens. **This single formula lets you estimate the cost of any training run.** For a 70-billion-parameter model on 2 trillion tokens: 6 x 7x10^10 x 2x10^12 = 8.4x10^23 FLOPs. At an effective 4x10^14 FLOPs per second per accelerator (a plausible utilization figure), that is about 2x10^9 accelerator-seconds, roughly 24,000 accelerator-days, or about a month on a thousand of them. That estimate is within a small factor of published figures, which is all you need.

Note the caveat: the 6N rule ignores attention's quadratic term, which is fine while T is well below d and increasingly wrong beyond that.

### Memory during training

This is where people underestimate, and the breakdown is worth knowing:

| Item | Bytes per parameter (mixed precision, Adam) |
| --- | --- |
| Weights (bf16) | 2 |
| Gradients (bf16) | 2 |
| Adam first moment (fp32) | 4 |
| Adam second moment (fp32) | 4 |
| fp32 master weights | 4 |
| **Total** | **about 16** |

So a 7-billion-parameter model needs roughly 112 GB just for states, before any activations. **The optimizer state, not the weights, dominates** — Adam's two moments plus the master copy are 12 of the 16 bytes. This is the entire motivation for ZeRO-style sharding (splitting optimizer state, gradients and parameters across devices), for 8-bit optimizers, and for memory-efficient optimizer variants.

Activation memory adds on top and scales as batch times layers times sequence times width, which is what gradient checkpointing (Chapter 2) attacks.

For **inference** the picture is completely different: weights at 2 bytes each (or 1 or less when quantized), no optimizer state, no gradients, no stored activations — but a KV cache that grows with context and batch (section 7.8). That asymmetry is why a model that needs a large cluster to train can serve on a single accelerator, and why inference optimization is about memory bandwidth and cache management rather than FLOPs.

### Scaling laws

Empirically, loss follows a power law in each of model size, data and compute, with an irreducible term:

$$
L(N, D) \approx \frac{A}{N^{\alpha}} + \frac{B}{D^{\beta}} + L_{\infty}
$$

The constant L-infinity is the entropy of the data (Chapter 5) — the floor no model can pass.

The practically important finding is the **compute-optimal allocation** question: given a fixed compute budget C = 6ND, how should you split it between parameters and tokens? The Chinchilla analysis concluded that earlier large models were substantially **undertrained** — too many parameters for too few tokens — and that N and D should be scaled roughly in proportion, with a rule of thumb near 20 tokens per parameter. Two caveats worth stating: these exponents are empirical fits that depend on data, architecture and tokenizer, and the compute-optimal point ignores **inference** cost, which is why models intended for heavy serving are deliberately trained past that point on more tokens than compute-optimality would suggest, buying a smaller model that is cheaper to run.

### Width-invariant parameterization

One more idea worth knowing because it is both elegant and practically used. Under standard parameterization, the optimal learning rate shifts as you change model width, so hyperparameters tuned on a small model do not transfer to a large one — and tuning directly on the large one is prohibitively expensive.

**Maximal update parameterization (muP)** rescales initialization and per-layer learning rates so that, as width grows, activations, gradients and updates all stay of constant scale. The consequence is that **the optimal hyperparameters become approximately width-independent**, so you can tune on a small proxy model and transfer to the full-size one. That this works at all is a nontrivial consequence of the same variance-propagation analysis as section 7.2, applied in the infinite-width limit. It is used in practice for large training runs and is a strong thing to be able to explain.

**Try it.** (a) Estimate the parameters of a model with L = 48, d = 6144, V = 50k. (b) Estimate the training FLOPs for that model on 1 trillion tokens. (c) Estimate its training memory for weights, gradients and Adam state in mixed precision, and say which term dominates. Answers in 7.11.

## 7.10 Interview drill set

**1. What does the universal approximation theorem say, and why does it not justify deep learning?** One hidden layer with a non-polynomial activation can approximate any continuous function on a compact set. It says nothing about how many units, whether gradient descent finds them, or whether the result generalizes — and it is a statement about shallow networks, so it cannot explain depth.

**2. What does depth buy?** Exponential parameter efficiency. The number of affine regions a ReLU network can express grows exponentially in depth and only polynomially in width, and real data has compositional structure that a layered architecture matches.

**3. Why can you not initialize all weights to zero?** Every unit in a layer would compute the same thing and receive the same gradient, so they stay identical forever and the layer has the capacity of one unit. Random initialization breaks the symmetry.

**4. Derive He initialization.** For z = Wx with independent mean-zero entries, Var(z) = n\_in times sigma\_w^2 times Var(x), so variance preservation needs sigma\_w^2 = 1/n\_in. ReLU zeroes half the inputs and therefore halves the variance, so you double it: sigma\_w^2 = 2/n\_in.

**5. What is the difference between Xavier and He, and why?** The factor of 2. Xavier targets variance preservation in both directions for activations with derivative near 1 at the origin; He adds the factor of 2 to compensate for ReLU discarding half the variance.

**6. What is the difference between BatchNorm and LayerNorm?** The axes the statistics are computed over. BatchNorm normalizes each channel across the batch, so it needs running statistics at inference and degrades with small batches. LayerNorm normalizes across features within each token, so it is batch-independent and behaves identically in train and eval.

**7. Why do transformers use LayerNorm rather than BatchNorm?** Because sequences have variable length (padding pollutes batch statistics), batch sizes per device can be small, and batch coupling complicates distributed training and inference. LayerNorm has none of these problems.

**8. Why does BatchNorm help?** It improves the conditioning of the optimization problem and allows larger learning rates. The original internal-covariate-shift explanation has been substantially challenged and should not be given as settled.

**9. Why does normalization make a layer's weight scale irrelevant?** Scaling the weights before a normalization scales its input uniformly, which the normalization divides out. So the function is invariant to that scale, which means weight decay on those weights affects the effective learning rate rather than the function class.

**10. Why do residual connections help?** The block Jacobian becomes I + J, so the product across L blocks retains an identity term that cannot decay. There is no exponential attenuation. Separately, the identity is available for free rather than having to be learned.

**11. Pre-norm or post-norm, and why?** Pre-norm, because the residual path from input to output is completely unobstructed, so the identity term in the Jacobian product is never modified. Post-norm interrupts that path at every block and needs careful warmup. Pre-norm requires a final LayerNorm before the output head.

**12. What is the residual stream?** The shared additive channel of dimension d running the full depth. Each block reads from it, computes, and writes back additively; nothing is overwritten. Output logits are therefore an exact sum of per-block contributions, which is what makes logit attribution possible.

**13. Why did deep sigmoid networks fail to train?** The sigmoid derivative never exceeds 0.25, so the product of Jacobians attenuates by up to 0.25 per layer — about 10^-6 over ten layers. ReLU has derivative exactly 1 on the active side and removes that attenuation.

**14. What is the dead ReLU problem?** A unit whose pre-activation is negative for all inputs has zero derivative, hence zero gradient, and never recovers. A high learning rate can push a bias sufficiently negative to cause this. Leaky ReLU and GELU fix it by keeping the derivative nonzero.

**15. Why GELU over ReLU in transformers?** It is smooth, has a small negative lobe, and has no dead units. The empirical gains are small; the important distinction is between saturating and non-saturating activations, not among the non-saturating family.

**16. Why is attention permutation-equivariant, and what follows?** Every operation treats the sequence as a set: QK' gives all pairwise scores and the output is a weighted sum. Permuting inputs permutes outputs identically. Therefore positional information must be injected explicitly.

**17. Derive the sqrt(d\_k) scaling in attention.** With unit-variance entries, the dot product over d\_k terms has mean 0 and variance d\_k, so typical logits scale as sqrt(d\_k). Unscaled, softmax saturates as head dimension grows and its Jacobian goes to zero, so gradients vanish. Dividing restores unit-variance logits.

**18. How does RoPE make attention relative?** Rotate queries and keys by angles proportional to their absolute positions. Since rotations satisfy R(a)' R(b) = R(b - a), the inner product depends only on the difference of positions. No parameters, nothing added to the residual stream, and values are untouched.

**19. Which holds more parameters, attention or the feedforward block?** The feedforward block: 8d^2 against attention's 4d^2, with the standard 4x expansion. Two-thirds of a transformer's non-embedding parameters are in the feedforward layers.

**20. How many parameters does a transformer have?** Approximately 12Ld^2 plus the embedding Vd. For d = 4096 and L = 32 that is about 6.4 billion, which lands in the right range for a 7-billion model.

**21. How much compute does training take?** About 6ND FLOPs, where N is parameters and D is tokens. The 6 is 2 for forward multiply-add times the 1:2 forward-to-backward ratio.

**22. How much memory does training take?** Roughly 16 bytes per parameter with mixed precision and Adam: 2 for bf16 weights, 2 for gradients, 4 each for the two Adam moments, and 4 for fp32 master weights. The optimizer state dominates, which is why ZeRO sharding and 8-bit optimizers exist.

**23. What is the KV cache and how large is it?** Cached keys and values so each generated token costs O(T) rather than O(T^2). Size is 2 times L times T times d times bytes, per sequence. For L = 32, d = 4096, T = 8192 in fp16 that is about 4.3 GB for one sequence, which is why long-context serving is memory-bound.

**24. What do MQA and GQA do?** Share key-value heads across query heads, shrinking the KV cache by the sharing factor. MQA uses one KV head, GQA uses a few. Queries are what differentiate head behaviour, so sharing keys and values costs little quality.

**25. What makes FlashAttention fast?** It never materializes the (T, T) attention matrix. Tiling plus an online softmax lets it compute exact attention in SRAM, cutting memory traffic from O(T^2) to O(T). It is exact, not approximate, and the speedup is memory-bandwidth, not FLOPs.

**26. When does attention actually dominate a transformer's cost?** Only past a sequence length of roughly 6d. Per token per layer, projections plus feedforward cost about 24d^2 while attention costs about 4Td, so the crossover is T = 6d — about 24,600 tokens for d = 4096. Below that the feedforward and projections dominate, and widening the model pushes the crossover further out.

**27. What do scaling laws say, and what is the irreducible term?** Loss falls as a power law in parameters and data with an additive constant. That constant is the entropy of the data distribution — the floor no model can beat. Compute-optimal training scales parameters and tokens together, but heavy-inference deployments deliberately overtrain smaller models.

**28. What problem does muP solve?** Under standard parameterization the optimal learning rate shifts with model width, so small-scale tuning does not transfer. muP rescales initialization and per-layer learning rates so activations and updates stay scale-invariant with width, making hyperparameters transferable from a small proxy model.

**29. Why does a pre-norm transformer need a final LayerNorm?** Because the residual stream's variance grows roughly linearly with depth and is never renormalized on the clean path, so the output projection would otherwise receive inputs of uncontrolled scale.

**30. Name the three mechanisms that address the product-of-Jacobians problem.** Initialization sets the Jacobian singular values near 1 at the start; normalization keeps activation scales controlled during training; residual connections change each Jacobian to I + J so the product cannot decay. Three fixes, one underlying problem.

## 7.11 Assignment and solutions

### Solutions to the in-text exercises

**7.1.** (a) Exponential in L, polynomial in w — roughly on the order of w^(d L) regions for input dimension d, so depth compounds multiplicatively while width accumulates polynomially. (b) It bounds nothing about the number of units required (which can be exponential in input dimension); it is an existence result saying nothing about whether gradient descent finds the network; and it says nothing about generalization. A fourth: it concerns shallow networks, so it cannot explain depth. (c) 0.95^99 = about 0.0062, so roughly 0.6% of the gradient survives — a 160-fold attenuation from a per-layer factor that looks innocuous.

**7.2.** (a) For z symmetric about 0, ReLU(z) equals z when z > 0 and 0 otherwise, each with probability 1/2. E\[ReLU(z)^2\] = (1/2)E\[z^2 | z>0\] times... more directly: E\[ReLU(z)^2\] = E\[z^2 times the indicator z>0\] = (1/2)E\[z^2\] by symmetry, since z^2 has the same distribution on both halves. So the second moment halves, and since the mean is small relative to the scale, the variance roughly halves too. (b) He: sigma = sqrt(2/512) = 0.0625. Xavier: sigma = sqrt(2/2560) = 0.0280. Note the factor of more than two between them for this asymmetric layer. (c) A bias of zero breaks no symmetry, because the units are already distinguished by their random weight vectors; each unit still receives a different input and produces a different output. Zero weights make every unit's function identical, so nothing distinguishes them and the gradients are identical forever.

**7.3.** (a) BatchNorm over (B, T) leaves statistics of shape (768,) — one per channel. LayerNorm over the feature axis leaves (32, 128) — one per token. GroupNorm with 12 groups leaves (32, 12) per example per group, computed over the 64 channels in each group. (b) Because BatchNorm's statistics depend on the other examples in the batch, which is not available (or not meaningful) at inference when you may have a single input; running averages provide a fixed deterministic substitute. LayerNorm's statistics come from within a single token's own features, so the same computation is available at inference. (c) LN((cW)x) normalizes cWx, whose mean is c times the mean of Wx and whose standard deviation is c times that of Wx, so the ratio is unchanged and the output is identical. The implication: the L2 penalty on W does not restrict the set of functions representable, so its effect is on the optimization — controlling the weight norm, which controls the effective learning rate for a scale-invariant parameter.

**7.4.** (a) The Jacobian is I + dF/dx. The product over L blocks expands to I plus sums of products of the J terms, so the identity survives regardless of L; the gradient from the top reaches the bottom undiminished even if every J is tiny. (b) Higher training error cannot be an expressivity problem, because the deeper network can represent everything the shallower one can — set the extra blocks to the identity. So the deeper network's failure was that gradient descent could not find that solution. Residual connections make the identity the default, converting a hard search into a free starting point. (c) The residual path is unobstructed from input to output, so gradients flow directly; and it trains reliably at large depth without the careful warmup that post-norm requires.

**7.5.** (a) sigma' = sigma(1 - sigma). This is a downward parabola in sigma with maximum at sigma = 1/2, giving 1/4, which occurs at x = 0. (b) A unit whose pre-activation is negative for every training input has derivative 0 always, so its incoming weight gradient is zero and it never updates. A high learning rate makes it likely because one large step can drive the bias strongly negative, after which the unit is permanently off. Fixes: Leaky ReLU or GELU (nonzero derivative everywhere), a lower learning rate, and careful initialization; adding normalization also helps by keeping pre-activations centered. (c) d/dx log(1 + e^x) = e^x/(1 + e^x) = 1/(1 + e^{-x}) = sigmoid(x). It is pleasing because softplus is the smooth version of ReLU and sigmoid is the smooth version of the step function, which is ReLU's derivative — the smoothing commutes with differentiation.

**7.6.** (a) Attention: 4 x 768^2 = 2.36M. FFN: 2 x 768 x 3072 = 4.72M. Per layer about 7.08M; twelve layers about 85M. Embedding: 50257 x 768 = 38.6M. Total about 124M, which matches the well-known size of that configuration. Note the embedding is nearly a third of the model at this scale, and a much smaller fraction at large scale. (b) Because every position computes a score against every other position, so the matrix indexes pairs. It implies memory and compute quadratic in sequence length, which is the central obstacle to long context. (c) For q, k with i.i.d. mean-0 unit-variance entries, each product q\_i k\_i has mean 0 and variance 1, and there are d\_k independent terms, so the sum has variance d\_k and typical magnitude sqrt(d\_k). Large logits saturate the softmax, whose Jacobian diag(p) - pp' then vanishes, killing gradients. Dividing by sqrt(d\_k) fixes the variance at 1 for any head size.

**7.7.** (a) Let P be a permutation matrix acting on the sequence axis. Then Q, K, V all become PQ, PK, PV; the scores become PQ(PK)' = P(QK')P'; the row-wise softmax commutes with the row and column permutation; and the output is P(QK')P' PV = P(AV). So the output is exactly the permuted original. (b) R(a)'R(b) is a rotation by -a followed by b, which is R(b - a), since rotations compose additively and the transpose of a rotation is its inverse. Applying this to the rotated query and key gives q'R((n-m)theta)k, depending only on n - m. (c) A learned absolute embedding has a trained vector for each position up to the maximum seen; position 5000 in a model trained to 2048 simply has no vector, and any extrapolation is arbitrary. ALiBi's penalty is a formula in |i - j| that is defined for every distance, so it extends automatically — though its effective behaviour at distances far beyond training is still a matter of degree.

**7.8.** (a) 2 x 80 x 4096 x 8192 x 2 bytes x 8 = about 86 GB. Larger than a single accelerator's memory, which is why GQA and cache compression matter at this scale. (b) Per token per layer, projections plus feedforward cost about 24d^2 and attention about 4Td, so the crossover is T = 6d = **24,576 tokens** for d = 4096. Below that, attention is not the bottleneck. (c) Exact because it computes the same mathematical function: the online softmax formulation, which tracks a running maximum and running sum and rescales whenever a new maximum appears, produces the identical result to computing the full row at once. Its speedup comes from keeping tiles in SRAM and avoiding round trips to high-bandwidth memory, so it is a memory-traffic win, not a FLOP reduction.

**7.9.** (a) 12 x 48 x 6144^2 = 21.7 billion, plus embedding 50,000 x 6144 = 0.31 billion. About 22 billion. (b) 6 x 2.2x10^10 x 1x10^12 = 1.3x10^23 FLOPs. (c) 22 billion x 16 bytes = about 352 GB. The Adam moments and fp32 master copy account for 12 of the 16 bytes, so **optimizer state is about three-quarters of the total** — the weights themselves are only an eighth.

### Problem set

**P1 (initialization).** Derive the correct initialization variance for a layer followed by a leaky ReLU with negative slope a, and verify it reduces to He when a = 0 and to Xavier-like scaling when a = 1.

**P2 (variance propagation).** Simulate a 50-layer linear network with ReLU at three initialization scales (He, half He, twice He) and plot the activation standard deviation by layer. Explain the three curves.

**P3 (LayerNorm backward).** Derive the LayerNorm input gradient from scratch, and verify by finite differences. Confirm numerically that the resulting gradient sums to zero across features and is orthogonal to the normalized activation.

**P4 (residuals).** For a 100-layer network where each block's Jacobian has all singular values 0.9, compute the gradient attenuation at layer 1 with and without residual connections.

**P5 (attention shapes).** Write out every intermediate tensor shape for a forward pass with B = 4, T = 512, d = 768, h = 12, including the multi-head reshape and the merge. Then annotate the corresponding backward shapes.

**P6 (RoPE).** Implement RoPE for a 2-dimensional head and verify numerically that the attention logit between positions m and n depends only on n - m.

**P7 (scaling arithmetic).** A model has L = 32, d = 4096, V = 32000, trained on 2 trillion tokens. Compute parameters, training FLOPs, training memory, and KV cache at T = 4096 and batch 16. State which resource binds first.

**P8 (complexity).** Derive the crossover sequence length at which attention exceeds feedforward cost, as a function of d. Then evaluate it for d = 768, 4096 and 16384 and comment.

**P9 (coding).** Implement a minimal transformer block from scratch in numpy: multi-head attention with causal masking, pre-norm, residual, and a feedforward block. Verify all gradients against finite differences in float64.

**P10 (synthesis).** Explain in one paragraph why these are the same fact: vanishing gradients in deep sigmoid networks; He initialization's factor of 2; why normalization layers help; why residual connections enable 100-layer networks; and why attention divides by sqrt(d\_k).

### Selected solutions

**P1.** Leaky ReLU keeps the positive half unchanged and scales the negative half by a. For a symmetric mean-zero input, the second moment of the output is (1/2)E\[z^2\] + (1/2)a^2 E\[z^2\] = (1 + a^2)/2 times E\[z^2\]. To preserve variance you need n\_in sigma\_w^2 (1 + a^2)/2 = 1, giving sigma\_w^2 = 2/((1 + a^2) n\_in). At a = 0 this is 2/n\_in, He exactly. At a = 1 the activation is the identity and it gives 1/n\_in, which is the correct variance-preserving value for a linear layer and matches LeCun initialization.

**P4.** Without residuals: 0.9^99 = 0.0062, so 0.6% of the gradient survives. With residuals, each block Jacobian is I + J where J has singular values 0.9; the product retains an identity term, so the gradient reaching layer 1 is at least as large as the top gradient, and in fact the expansion's higher terms add to it. **From a 160-fold attenuation to no attenuation at all**, from one addition per block.

**P8.** Per layer and per token, the projections plus feedforward cost on the order of 12d^2 multiply-adds, while attention costs on the order of 2Td (the QK' and AV products, per token). Setting 2Td = 12d^2 gives T = 6d. So with d = 768 the crossover is around 4,600 tokens; with d = 4096 around 24,600; with d = 16384 around 98,000. **The larger the model, the later attention becomes the bottleneck** — which is a mildly counterintuitive and useful conclusion: widening a model pushes the quadratic-attention problem further out, and it explains why very large models can use long contexts more comfortably than their parameter count might suggest.

**P10.** All five are the product-of-Jacobians problem from Chapter 2, attacked from different angles. A deep network's gradient at the bottom is a product of per-layer Jacobians, so the *typical singular value* of those Jacobians raised to the depth decides whether any signal arrives. Sigmoid's derivative is capped at 0.25, so deep sigmoid networks attenuate by orders of magnitude and cannot train — the problem in its original form. He initialization's factor of 2 is a variance correction ensuring that, at initialization, ReLU layers neither shrink nor grow the signal: it sets that typical singular value to 1 at step zero. Normalization layers maintain the condition during training rather than only at initialization, by re-standardizing activations at every block so no layer's scale can drift. Residual connections attack the same quantity structurally, replacing each Jacobian J by I + J so the product cannot decay however small the J terms are — which is what makes 100-layer networks trainable. And the sqrt(d\_k) in attention is the same calculation in one specific place: without it, logits grow as sqrt(d\_k), the softmax saturates, and its Jacobian goes to zero, which is a vanishing gradient created by a scale mismatch rather than by depth. One quantity, five interventions.

**P2 (coding).** Expected curves for a 50-layer ReLU network. With He initialization (variance 2/n\_in), the activation standard deviation stays roughly flat across layers — small random fluctuation, no trend. With half the He standard deviation (so a quarter of the variance), each layer multiplies the variance by 0.5, so after 50 layers the standard deviation has fallen by 2^{-25}, about 3 times 10^{-8}: the signal is gone and on a log plot the curve is a straight line with a steep negative slope. With twice the He standard deviation, variance quadruples per layer and you overflow to infinity within about 30 layers. **Plot the standard deviation on a log axis and all three are straight lines whose slopes are log of the per-layer variance factor** — which is the clearest possible demonstration that initialization errors compound geometrically in depth.

**P3.** LayerNorm input gradient. With mu and s = sqrt(sigma^2 + eps) both functions of all of x, differentiate x-hat\_i = (x\_i - mu)/s with respect to x\_j. Three contributions: the direct term (delta\_ij)/s, the mean term -(1/d)/s, and the variance term -(x-hat\_i)(x-hat\_j)/(d s). Contracting with the upstream gradient g gives

$$
\frac{\partial L}{\partial x} = \frac{1}{s}\left(g - \overline{g} - \hat{x}\,\overline{(g\odot\hat{x})}\right)
$$

with overbars denoting means over the d features. **Numerical verification:** compute this analytically and compare with central differences in float64; expect agreement to 10^{-10} or better. Then check the two structural properties: summing the result over features gives mean(g) - mean(g) - mean(x-hat) times the third term, and mean(x-hat) = 0 by construction, so the sum is zero. Taking the inner product with x-hat gives mean(g times x-hat) - mean(g) times mean(x-hat) - mean(x-hat squared) times mean(g times x-hat), and since mean(x-hat squared) = 1 the first and third cancel, leaving zero. Both hold to machine precision, confirming the invariance argument of P5 in Chapter 2.

**P5.** Shapes for B = 4, T = 512, d = 768, h = 12, d\_k = 64.

| Tensor | Shape |
| --- | --- |
| input X | (4, 512, 768) |
| after W\_Q (768 x 768) | (4, 512, 768) |
| reshape to heads | (4, 512, 12, 64) |
| transpose for attention | (4, 12, 512, 64) |
| scores QK' | (4, 12, 512, 512) |
| attention weights A | (4, 12, 512, 512) |
| AV | (4, 12, 512, 64) |
| transpose back | (4, 512, 12, 64) |
| merge heads | (4, 512, 768) |
| after W\_O | (4, 512, 768) |

Backward shapes mirror these exactly: every gradient has the shape of the tensor it differentiates, so dL/dX is (4,512,768), dL/dA is (4,12,512,512), and dL/dW\_Q is (768,768) — **with the batch and sequence dimensions summed away**, because W\_Q is shared across all of them. Note that the (4,12,512,512) attention tensor holds 12.6 million entries; at 2 bytes that is 25 MB per layer, which is why FlashAttention matters.

**P6.** RoPE for a 2-dimensional head. Take q = (1, 0) at position m and k = (1, 0) at position n, with a single frequency theta. Rotating gives q-tilde = (cos(m theta), sin(m theta)) and k-tilde = (cos(n theta), sin(n theta)). Their inner product is cos(m theta)cos(n theta) + sin(m theta)sin(n theta) = cos((n - m)theta) by the cosine subtraction identity. **The result depends only on n - m**, exactly as claimed. Verify numerically for several (m, n) pairs with the same difference — for example (3, 5), (10, 12), (100, 102) — and all give the identical logit. That is the whole property, and the one-line trigonometric identity is the entire proof.

**P7.** Model with L = 32, d = 4096, V = 32000, D = 2 trillion tokens. **Parameters:** 12 times 32 times 4096^2 = 6.44 billion, plus embedding 32000 times 4096 = 0.13 billion, total about 6.6 billion. **Training FLOPs:** 6 times 6.6e9 times 2e12 = 7.9 times 10^22. **Training memory (states):** 6.6e9 times 16 bytes = 106 GB, of which 79 GB is optimizer state and master weights. **KV cache** at T = 4096, batch 16, fp16: 2 times 32 times 4096 times 4096 times 2 times 16 = 34 GB.

Which binds first depends on the phase, and that is the point of the exercise. **In training, memory binds**: 106 GB of states exceeds a single 80 GB accelerator before any activations, so you need sharding regardless of how much compute you have. **In inference, the KV cache binds**: 13 GB of weights fit easily, but 34 GB of cache at batch 16 does not leave room to grow the batch, so throughput is cache-limited rather than compute-limited. That asymmetry is why training and serving have completely different optimization problems.

**P9 (coding).** Expected outcome: with correct implementations, all gradients match central differences to a relative error below 10^{-9} in float64. The instructive bugs: forgetting the causal mask produces correct gradients but a model that trivially cheats, so check by confirming that position t's output is unchanged when you alter tokens after t; applying the mask after the softmax instead of before gives rows that no longer sum to 1; forgetting the 1/sqrt(d\_k) still trains but with visibly worse conditioning, which you can see by printing the standard deviation of the logits (it should be near 1 with the scaling and near 8 without it, at d\_k = 64).
