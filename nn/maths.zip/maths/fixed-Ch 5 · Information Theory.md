﻿# Chapter 5 · Information Theory

2026-09-22 · @Behi

Information theory is the shortest path to understanding why machine learning uses the objectives it uses. Cross-entropy, KL divergence, the ELBO, contrastive losses, perplexity, the KL penalty in RLHF, and distillation are all one small set of ideas applied repeatedly.

The chapter's spine: **entropy measures unavoidable surprise, cross-entropy measures the surprise you actually incur by using the wrong model, and KL divergence is the gap between them — which is exactly the thing training reduces.**

## 5.1 Surprise and entropy

### Building the definition instead of memorizing it

Start with **surprise**. How surprised should you be to see an event of probability p? Whatever the answer, it must satisfy three requirements:

1. A certain event (p = 1) carries zero surprise.
2. Rarer events are more surprising, so surprise decreases in p.
3. **Surprise from independent events adds.** Learning two unrelated facts should be twice the information of learning one.

That third requirement is the constraint that pins everything down. You need a function with S(pq) = S(p) + S(q), turning a product into a sum, and up to a constant multiple the only continuous solution is the logarithm:

$$
S(p) = -\log p = \log \frac{1}{p}
$$

**Be precise about what this argues.** Additivity plus continuity pins down surprise as a constant multiple of the logarithm — that part is a genuine derivation, and it is the answer to "why the log?". Pinning down **entropy** uniquely requires one further axiom, usually a grouping or recursivity condition saying that the uncertainty of a two-stage choice equals the first stage's uncertainty plus the expected uncertainty of the second. With that added, Shannon's uniqueness theorem gives the entropy formula up to the choice of base. So: the logarithm is forced by additivity; the full entropy formula needs additivity, continuity, and grouping. Stating it that way is both correct and more impressive than claiming more than the argument delivers.

**Entropy** is then simply average surprise:

$$
H(X) = \mathbb{E}\big[-\log p(X)\big] = -\sum_x p(x)\log p(x)
$$

Read it as: *how surprised will I be on average by a draw from this distribution?* Equivalently, how much uncertainty is in it, or how many yes/no questions I need on average to determine the outcome.

### Units

Log base 2 gives **bits**, natural log gives **nats**. One nat is about 1.44 bits. Theory papers use nats because calculus is cleaner; compression and language modeling often use bits. Converting is dividing by log 2, and getting this wrong is the usual cause of a perplexity number being off by a factor of 1.44.

### Properties, and what each one tells you

$$
0 \le H(X) \le \log |\mathcal{X}|
$$

- **H = 0** exactly when the outcome is deterministic. No surprise, no information.
- **H is maximized by the uniform distribution**, at log of the number of outcomes. Maximum uncertainty is knowing nothing about which outcome will occur. A fair coin has 1 bit; a fair 8-sided die has 3 bits; a uniform distribution over a 50,000-token vocabulary has about 15.6 bits.
- **Entropy is concave in p.** Mixing two distributions produces something at least as uncertain as the average of their uncertainties.
- **Entropy depends only on the probabilities, not the values.** A distribution over {1, 2, 3} and one over {cat, dog, fish} with the same probabilities have identical entropy. Entropy does not know about distance or similarity, which is a real limitation and the reason Wasserstein distance exists (section 5.6).

### The binary entropy function, worth knowing by shape

$$
H(p) = -p\log_2 p - (1-p)\log_2(1-p)
$$

It is 0 at p = 0 and p = 1, peaks at 1 bit at p = 0.5, and is symmetric. Its shape is flat near the top and steep near the ends: H(0.5) = 1, H(0.4) = 0.971, H(0.1) = 0.469, H(0.01) = 0.081.

Notice how little entropy is lost moving from 0.5 to 0.4 — barely 3%. That flatness is the information-theoretic mirror of the Fisher-information result in Chapter 4: near p = 0.5 the distribution is hard to pin down and each observation carries a full bit, while near the extremes each observation carries almost nothing but the parameter is easy to estimate. The two chapters are describing the same curvature from opposite directions.

### Differential entropy, and its pitfalls

For continuous variables:

$$
h(X) = -\int p(x)\log p(x)\,dx
$$

This is **not** a straightforward limit of the discrete case, and it misbehaves in ways worth knowing because they cause real confusion:

- **It can be negative.** A uniform distribution on \[0, 0.5\] has differential entropy log(0.5) = -0.69 nats. Since densities can exceed 1 (Chapter 3), their negative logs can be negative.
- **It is not invariant under reparameterization.** Rescaling X by a constant a shifts h by log|a|, because the density picks up a Jacobian factor. So the differential entropy of a length measured in meters differs from the same length in centimeters. There is no absolute zero of continuous entropy.
- **It is not the limit of discrete entropy**, which diverges as you refine the discretization; the divergent part is discarded in the definition.

The practical rule: **differences of differential entropies are meaningful, absolute values are not.** KL divergence and mutual information are differences, which is exactly why they remain well behaved and reparameterization-invariant in the continuous case while differential entropy alone does not. That is a genuinely useful thing to understand rather than memorize.

Two entropies worth knowing by heart:

$$
h\big(N(\mu, \sigma^2)\big) = \tfrac{1}{2}\log(2\pi e \sigma^2), \qquad h\big(N(\mu, \Sigma)\big) = \tfrac{1}{2}\log\big((2\pi e)^d |\Sigma|\big)
$$

The multivariate version says entropy grows with the log-determinant of the covariance, which is the log-volume of the uncertainty ellipsoid from Chapter 1. Entropy is log-volume of uncertainty; that is the cleanest geometric reading available.

### Why any of this shows up in ML

- **Entropy of a model's output distribution is a confidence measure.** Low entropy means a confident prediction. This is the basis of uncertainty-based active learning, of selective prediction, and of entropy-based routing decisions in agentic systems.
- **Entropy regularization in RL** adds a bonus for high-entropy policies to encourage exploration and prevent premature collapse onto one action. Section 5.8 shows this produces softmax policies, which is not a coincidence.
- **Decision trees split on information gain**, which is the reduction in entropy achieved by a split.
- **The entropy of the data distribution is the irreducible floor** on any model's cross-entropy loss. When a language model's loss plateaus, part of that floor is the genuine entropy of language, and no amount of scale removes it.

**Try it.** (a) Compute the entropy in bits of a distribution with probabilities (0.5, 0.25, 0.125, 0.125), and find a code achieving exactly that average length. (b) Show that entropy is maximized by the uniform distribution using Jensen's inequality. (c) Why can differential entropy be negative while discrete entropy cannot? Answers in 5.11.

## 5.2 The coding interpretation

This section gives entropy its physical meaning. It is the most useful mental model in the chapter, and it makes cross-entropy and KL obvious rather than abstract.

### Source coding

You want to transmit symbols drawn from a distribution p, using as few bits as possible on average. **Shannon's source coding theorem** says the minimum achievable average code length is exactly H(p) bits per symbol, and that you can get arbitrarily close.

The optimal code assigns each symbol a codeword of length

$$
\ell(x) = \log_2 \frac{1}{p(x)} \text{ bits}
$$

Common symbols get short codes, rare symbols long ones. That is the whole idea behind Morse code assigning a single dot to "e", and it is what Huffman coding and arithmetic coding actually implement.

**Entropy is the compression limit.** If a source has 3 bits of entropy per symbol, no scheme can average below 3 bits, and good schemes get close. This is why entropy is not merely a formula: it is a hard physical bound on a real task.

### Cross-entropy is what it costs to use the wrong code

Now suppose the true distribution is p but you built your code assuming q. You assign x a codeword of length log(1/q(x)), but x actually occurs with probability p(x). Your average message length is

$$
H(p, q) = -\sum_x p(x)\log q(x) = \mathbb{E}_{x \sim p}\big[-\log q(x)\big]
$$

**This is cross-entropy, and it is the average number of bits you actually spend when reality is p and you believe q.** It is always at least H(p), with equality only when q = p. Believing the wrong thing costs you bits, and it never saves you any.

The gap between them is the KL divergence:

$$
D_{KL}(p \,\|\, q) = H(p,q) - H(p) \;\ge\; 0
$$

**KL is the number of extra bits you waste by using the wrong model.** Every property of KL in section 5.3 becomes intuitive once you hold this reading: it is nonnegative because you cannot beat the optimal code; it is zero only when your model is exactly right; and it is asymmetric because the penalty depends on which distribution generates the data and which one built the codebook.

Three readings of the same quantity, all worth being able to give:

| Quantity | Coding | Statistics | ML |
| --- | --- | --- | --- |
| H(p) | optimal bits per symbol | irreducible uncertainty | the loss floor |
| H(p,q) | bits spent with the wrong codebook | negative log-likelihood | the training loss |
| KL(p‖q) | bits wasted | excess NLL | what training minimizes |

Since H(p) does not depend on your model, **minimizing cross-entropy and minimizing KL are the same optimization.** That identity ties this chapter to Chapter 4's result that maximum likelihood minimizes forward KL.

### Perplexity

Language modeling reports perplexity rather than cross-entropy:

$$
\text{PPL} = 2^{H(p,q)} \quad \text{(bits)} \qquad \text{or} \qquad e^{\mathcal{L}} \quad \text{(nats)}
$$

**Perplexity is the effective number of equally likely choices the model is deciding between at each step.** A perplexity of 20 means the model is about as uncertain as if it were picking uniformly among 20 options. That interpretation makes it far more intuitive than a loss in nats, which is why the field kept it.

Some calibration for the numbers, since interviewers do ask for a sense of scale: a uniform distribution over a 50,000-token vocabulary has perplexity 50,000. Early n-gram models reached the low hundreds. Modern large language models on general text are in the low single digits to low teens depending on tokenizer and corpus. Note the essential caveat: **perplexity is not comparable across tokenizers.** A model with a larger vocabulary predicts fewer, harder tokens, so its per-token perplexity is not comparable to a character-level model's. Comparing perplexities across papers with different tokenization is a common and serious error; bits-per-byte is the fix, because bytes are a tokenizer-independent unit.

### Bits per dimension

For images and other continuous data, generative models report **bits per dimension** — the negative log-likelihood converted to bits and divided by the number of dimensions (pixels times channels). It exists to solve two problems at once: it makes models with different input sizes comparable, and it anchors the log-density, which as Chapter 3 noted is not scale-invariant on its own. The discretization convention (treating 8-bit pixel values as bins of width 1/256) is what makes the number well defined and nonnegative in practice.

### Kolmogorov complexity, in one paragraph

Worth knowing about, because it is the conceptual backdrop for "compression is intelligence" arguments. The Kolmogorov complexity of a string is the length of the shortest program that outputs it. Where Shannon entropy is a property of a *distribution*, Kolmogorov complexity is a property of an *individual object*, and the expected Kolmogorov complexity of samples from a distribution is approximately its Shannon entropy. It is **uncomputable**, so it cannot be used directly, but it underlies minimum description length as a model-selection principle and the argument that a good language model is a good compressor. Say it is uncomputable if it comes up; that is the detail people miss.

**Try it.** (a) Symbols A, B, C, D have probabilities 0.5, 0.25, 0.125, 0.125. Construct the optimal code and verify that its average length equals the entropy. (b) Your model assigns them 0.25 each. Compute the cross-entropy and the KL, and say how many bits per symbol you waste. (c) A model has a validation loss of 2.5 nats per token. What is its perplexity, and what does that number mean in words? Answers in 5.11.

## 5.3 KL divergence and its asymmetry

### Definition and properties

$$
D_{KL}(p \,\|\, q) = \sum_x p(x)\log\frac{p(x)}{q(x)} = \mathbb{E}_{x \sim p}\left[\log\frac{p(x)}{q(x)}\right]
$$

| Property | Holds? | Consequence |
| --- | --- | --- |
| Nonnegative | yes | you cannot beat the true code |
| Zero iff p = q | yes | it detects exact equality |
| Symmetric | **no** | KL(p‖q) is not KL(q‖p) |
| Triangle inequality | **no** | it is not a metric, only a divergence |
| Invariant under reparameterization | yes | unlike differential entropy |

**Proof of nonnegativity**, which is short and worth knowing. Write the negative KL and apply Jensen's inequality to the concave log:

$$
-D_{KL}(p\|q) = \mathbb{E}_p\left[\log\frac{q}{p}\right] \le \log \mathbb{E}_p\left[\frac{q}{p}\right] = \log\sum_x q(x) = \log 1 = 0
$$

Equality in Jensen requires the ratio q/p to be constant, which given that both sum to 1 forces p = q. This result is often called **Gibbs' inequality**, and it is the reason cross-entropy is bounded below by entropy.

Note also that KL is **infinite** whenever q assigns zero probability to something p gives positive probability to. That is not a technicality — it is exactly why models trained by maximum likelihood refuse to assign zero probability to anything observed, and why a language model always keeps a little mass on every token.

### The asymmetry, which is the practically important part

This is one of the highest-value ideas in the chapter, because it predicts the qualitative behaviour of trained models.

**Forward KL, written KL(p‖q), with p the data and q the model: mass-covering.**

The expectation is over p. Wherever p has mass and q does not, the ratio p/q blows up and the penalty is enormous. Wherever p has no mass, the term is zero and q is unpenalized for putting mass there. So the model is punished severely for *missing* anything and barely punished for *hallucinating* extra mass.

Result: q spreads out to cover all of p's support. Fitting a unimodal q to a bimodal p gives a broad distribution straddling both modes, with substantial mass in the empty valley between them.

**Reverse KL, written KL(q‖p): mode-seeking.**

Now the expectation is over q. Wherever q has mass and p does not, the penalty is enormous. Wherever q has no mass, the term is zero, so q is unpunished for ignoring parts of p entirely. The model is punished for *hallucinating* and not for *missing*.

Result: q collapses onto one mode of p and fits it tightly, ignoring the rest.

|  | Forward KL(p‖q) | Reverse KL(q‖p) |
| --- | --- | --- |
| Expectation over | data p | model q |
| Behaviour | mass-covering, mean-seeking | mode-seeking, zero-forcing |
| Punishes | missing data modes | placing mass where data has none |
| Fitting unimodal to bimodal | broad, straddles both | narrow, picks one |
| Used by | maximum likelihood, most generative training | variational inference, some RL objectives |
| Symptom | blurry, over-general samples | sharp but low-diversity samples |

**Picture it.** Fit a single Gaussian q to a bimodal p. The two directions give visibly different answers, and the difference is not subtle:

```mermaid
flowchart TD
  P["Target p:<br/>two separated modes"]
  P --> F["Forward KL(p||q)<br/>expectation over p"]
  P --> R["Reverse KL(q||p)<br/>expectation over q"]
  F --> F2["q spreads to cover both<br/>peak sits in the empty valley<br/>MASS-COVERING"]
  R --> R2["q collapses onto one mode<br/>fits it tightly, ignores the other<br/>MODE-SEEKING"]
```

The mechanism in one line each. Forward KL integrates against p, so any region where p has mass and q does not contributes p times log(p/0), which diverges — missing a mode is catastrophic, covering empty space is nearly free. Reverse KL integrates against q, so any region where q has mass and p does not diverges instead — hallucinating is catastrophic, ignoring a mode is free.

**This one table explains a lot of observed model behaviour.** Maximum-likelihood generative models produce blurry images and bland text because forward KL forces them to cover everything, including the parts of the data distribution they cannot model well. Variational inference underestimates posterior variance because reverse KL rewards shrinking into a region where the posterior is confidently positive. And GANs, which optimize something closer to a symmetric or mode-seeking objective, produce sharper samples while suffering mode collapse — the failure mode reverse-KL-like objectives predict.

A practical note on why variational inference uses reverse KL despite the mode-seeking downside: forward KL requires expectations under the true posterior, which is exactly what you cannot sample from. Reverse KL requires expectations under q, which you chose and can sample from freely. The choice is driven by tractability, and its behavioral consequences are a cost you accept.

### The KL between Gaussians

You will use this constantly, so it is worth having:

$$
D_{KL}\big(N(\mu_1,\sigma_1^2) \,\|\, N(\mu_2,\sigma_2^2)\big) = \log\frac{\sigma_2}{\sigma_1} + \frac{\sigma_1^2 + (\mu_1-\mu_2)^2}{2\sigma_2^2} - \frac{1}{2}
$$

The special case against a standard normal is the VAE's regularizer, and it is one you should be able to write from memory:

$$
D_{KL}\big(N(\mu,\sigma^2) \,\|\, N(0,1)\big) = \tfrac{1}{2}\big(\mu^2 + \sigma^2 - \log\sigma^2 - 1\big)
$$

Check that it is zero at mu = 0 and sigma = 1, and that it grows if the mean drifts or the variance departs in either direction. In a VAE this term is computed analytically rather than sampled, which is Rao-Blackwellization (Chapter 3) and reduces gradient variance.

### KL as a local metric

For two nearby distributions, expand KL to second order in the parameter:

$$
D_{KL}(p_\theta \,\|\, p_{\theta + \delta}) \approx \tfrac{1}{2}\,\delta^{\top} I(\theta)\, \delta
$$

The first-order term vanishes because KL is minimized at delta = 0, and the second-order coefficient is exactly the **Fisher information matrix** from Chapter 4. So KL is locally a quadratic form with the Fisher as its metric, and this single fact connects three chapters: it is why natural gradient is reparameterization-invariant, why TRPO's KL constraint becomes a Fisher-norm trust region, and why the Fisher is the right notion of "distance moved" in parameter space.

Note that to second order KL is locally symmetric — the asymmetry is a large-deviation phenomenon. That reconciles the two facts that KL is badly asymmetric and yet induces a proper Riemannian metric.

**Try it.** (a) Compute KL(p‖q) and KL(q‖p) for p = (0.5, 0.5) and q = (0.9, 0.1), and confirm they differ. (b) What happens to KL(p‖q) if q assigns probability zero to an outcome p gives 0.1? What does that imply for training? (c) You fit a single Gaussian to a two-cluster dataset by maximum likelihood. Predict the result, and say what reverse KL would have given instead. Answers in 5.11.

## 5.4 Cross-entropy as the loss

### The full chain

Here is the complete argument, and being able to walk it end to end is a strong signal in an interview.

1. The data defines a distribution over labels given an input. For a single labeled example with a known class, that distribution is a **one-hot** vector y.
2. Your model outputs a distribution q over classes.
3. The natural measure of disagreement is the cross-entropy H(y, q) = -sum of y\_k log q\_k.
4. Because y is one-hot, every term vanishes except the true class, leaving **-log q\_c**.
5. That is exactly the negative log-likelihood of the observed label under the model.
6. Averaged over the dataset, minimizing it minimizes KL from the data distribution to the model, since the data's own entropy is a constant.

$$
\mathcal{L} = -\frac{1}{n}\sum_{i=1}^{n} \log q_\theta(y_i \mid x_i)
$$

So **cross-entropy, negative log-likelihood, and forward KL to the data distribution are the same objective viewed three ways.** Chapter 4 arrived here from likelihood; this chapter arrives from coding. The convergence is the point.

### Why the loss behaves as it does

The functional form -log q explains several observed behaviours that people often attribute to tuning.

- **The penalty for confident errors is unbounded.** Assign 0.001 to the true class and you pay 6.9 nats; assign 0 and you pay infinity. This is why numerical implementations clamp probabilities, and it is why a single mislabeled example with a confident prediction can dominate a batch's loss.
- **The gradient is bounded even though the loss is not.** From Chapter 2, the gradient with respect to the logits is p - y, whose entries lie in \[-1, 1\]. So a catastrophically wrong prediction produces a large loss but a bounded gradient step. That combination is what makes cross-entropy trainable where a loss with unbounded gradients would not be.
- **Correct-but-unconfident predictions still produce gradient.** Unlike accuracy, which is flat almost everywhere and has zero gradient, cross-entropy keeps pushing probability toward the right answer even after the argmax is correct. That is why you train on cross-entropy and report accuracy, and it is the second half of the answer to "why not optimize accuracy directly?" — the first half being that accuracy is not a proper scoring rule (Chapter 4).

### Cross-entropy versus MSE for classification

A standard interview question with a crisp answer. Suppose you used squared error on the sigmoid output instead. The gradient with respect to the logit picks up a factor of the sigmoid derivative:

$$
\frac{\partial}{\partial z}\tfrac{1}{2}(\sigma(z) - y)^2 = (\sigma(z) - y)\,\sigma'(z), \qquad \frac{\partial}{\partial z}\big[-\text{CE}\big] = \sigma(z) - y
$$

With MSE, when the model is **confidently wrong** (z very negative, y = 1), sigma'(z) is near zero, so the gradient vanishes precisely when you most need it to be large. The model gets stuck. Cross-entropy's sigmoid factor cancels against the log's derivative, leaving a clean p - y with no saturation.

So: **MSE on a saturating output has vanishing gradients exactly where learning is most needed; cross-entropy does not.** That cancellation is the canonical-link result from Chapter 4 showing up in the optimization behaviour.

### Label smoothing

Replace the one-hot target with a softened version:

$$
y^{\text{LS}}_k = (1-\epsilon)\,y_k + \frac{\epsilon}{K}
$$

with epsilon typically 0.1. In information-theoretic terms you are telling the model that the true conditional distribution is not one-hot, which is usually more honest: labels are noisy, some examples are genuinely ambiguous, and demanding infinite confidence is asking for something false.

What it does:

- **Improves calibration**, since the model stops being pushed toward extreme logits (Chapter 4, section 4.10).
- **Acts as a regularizer**, and it is straightforward to show it adds a term that penalizes the KL from the model's output to the uniform distribution, which is an entropy bonus.
- **Prevents logits from growing without bound**, since with a one-hot target the optimum is at infinite logit separation.

The honest caveats: label smoothing can degrade the quality of the learned representations for downstream transfer, and it can hurt knowledge distillation, because it collapses the fine structure in the logits that a student would otherwise learn from. Knowing the trade-off rather than just the technique is what distinguishes a considered answer.

### Weighted and focal variants

For imbalanced data, two modifications appear constantly:

**Class weighting** multiplies each class's loss term by a weight, typically inverse to its frequency. Information-theoretically this changes the effective data distribution you are fitting, so the model is calibrated for the reweighted distribution rather than the real one — which is a real cost if you need calibrated probabilities, and worth saying.

**Focal loss** multiplies the cross-entropy by (1 - p\_true)^gamma, down-weighting examples the model already gets right:

$$
\text{FL} = -(1 - p_c)^{\gamma}\log p_c
$$

With extreme imbalance, the easy negatives are so numerous that they dominate the summed gradient even though each is nearly correct. Focal loss suppresses them so the hard examples drive learning. It was introduced for dense object detection, where the imbalance is on the order of thousands to one, and it also tends to produce better-calibrated outputs than plain cross-entropy.

**Try it.** (a) Compute the cross-entropy loss for a 3-class problem where the model outputs (0.7, 0.2, 0.1) and the true class is the first, then the second. (b) Show that with label smoothing the loss equals the standard cross-entropy plus a term proportional to the KL from the model's output to the uniform distribution. (c) Explain in two sentences why MSE plus sigmoid has a vanishing-gradient problem that cross-entropy plus sigmoid does not. Answers in 5.11.

## 5.5 Mutual information

### Conditional entropy first

$$
H(Y \mid X) = \mathbb{E}_{x}\big[ H(Y \mid X = x) \big] = -\sum_{x,y} p(x,y)\log p(y \mid x)
$$

How uncertain you remain about Y after learning X. Note it is an average over x of the entropy of the conditional distribution — the tower property again (Chapter 3).

The **chain rule for entropy** follows directly:

$$
H(X, Y) = H(X) + H(Y \mid X) = H(Y) + H(X \mid Y)
$$

The joint uncertainty is the uncertainty in one plus the remaining uncertainty in the other. **Conditioning never increases entropy**, H(Y|X) <= H(Y), with equality exactly under independence. Information cannot hurt on average — though it can for a particular x, which is why the qualifier "on average" matters.

### Mutual information

$$
I(X;Y) = H(Y) - H(Y \mid X) = H(X) - H(X\mid Y) = D_{KL}\big(p(x,y) \,\|\, p(x)p(y)\big)
$$

**How much learning one variable reduces your uncertainty about the other**, equivalently how far the joint distribution is from what it would be if they were independent.

Properties, each carrying a lesson:

- **Symmetric.** I(X;Y) = I(Y;X). Information is mutual, which is why the name.
- **Nonnegative**, and zero exactly under independence, since it is a KL.
- **Not bounded by 1**; it is bounded by min(H(X), H(Y)).
- **Invariant under invertible transformations** of either variable. Rescale, rotate, or relabel and MI is unchanged. This is a genuine advantage over correlation, and it is why MI is the natural measure of statistical dependence: it detects any dependence, not merely linear dependence.

That last property is the headline. Correlation is blind to the relationship between X and X^2 (Chapter 3); mutual information sees it perfectly, because knowing X determines X^2 completely, so the conditional entropy is zero.

### The information diagram

Picture two overlapping circles. The left circle is H(X), the right is H(Y), the overlap is I(X;Y), the left-only region is H(X|Y), the right-only is H(Y|X), and the union is H(X,Y). Every identity in this section is reading that picture:

$$
I(X;Y) = H(X) + H(Y) - H(X,Y)
$$

The diagram is a reliable mnemonic for two variables. Be aware that it breaks for three or more: the triple "intersection" (the interaction information) **can be negative**, which no Venn diagram can represent. The standard example is X and Y independent coin flips with Z = X XOR Z — each pair is independent, but all three together are perfectly determined. That is the collider structure from Chapter 3 seen in information terms.

### Estimating mutual information is hard

Worth knowing, because it is where the practical difficulty lives and a good discriminating question.

For discrete variables with plenty of data, plug-in estimation from counts works, though it is **biased upward** with small samples — spurious dependence appears from noise, so MI estimated from few samples systematically overstates. For continuous variables, MI requires densities you do not have, and the standard estimators (k-nearest-neighbour methods such as KSG, kernel density approaches) degrade quickly with dimension.

The modern approach is **variational bounds**: MINE, InfoNCE, and related estimators train a critic network to give a lower bound on MI. The critical limitation, established in the literature and worth quoting, is that any such bound based on n samples cannot certify more than about log(n) nats of mutual information. So when you see a claim that a representation captures a large amount of mutual information, ask how many samples were used — if the number is near log(batch size), the estimator is saturated and the number is not meaningful.

### Where MI shows up

- **Feature selection.** Rank features by MI with the target. It captures nonlinear relevance that correlation misses. The weakness is that it is univariate: a feature useless alone but valuable in combination scores zero.
- **Decision trees.** Information gain is precisely I(Y; split), the reduction in label entropy achieved by the split.
- **Representation learning.** The InfoMax principle says a good representation maximizes MI with the input. Contrastive methods (section 5.9) optimize a lower bound on MI.
- **The information bottleneck.** Find a representation T maximizing I(T;Y) while minimizing I(T;X): keep what predicts the label, discard everything else. A clean statement of what a good representation is, though its status as an explanation of deep learning is contested rather than settled.
- **Evaluation.** Normalized mutual information is a standard clustering metric, because it is invariant to how the clusters are labeled.
- **Disentanglement and independence objectives**, where you penalize MI between latent dimensions to encourage factorized representations.

### Pointwise mutual information

A small but genuinely useful relative:

$$
\text{PMI}(x,y) = \log\frac{p(x,y)}{p(x)p(y)}
$$

MI is the expectation of PMI. Where MI is a property of two variables, PMI is a property of two specific outcomes, and it is positive when they co-occur more than chance. PMI underlies classic word-association statistics, and the connection worth knowing is that **word2vec's skip-gram with negative sampling has been shown to implicitly factorize a shifted PMI matrix** — which links modern embeddings directly to classical count-based methods and to the low-rank factorization ideas from Chapter 1.

**Try it.** (a) X is a fair coin and Y = X. Compute H(X), H(Y|X) and I(X;Y). (b) X is a fair coin, Y an independent fair coin. Same three quantities. (c) Explain why mutual information detects the dependence between X and X^2 while correlation does not. Answers in 5.11.

## 5.6 Beyond KL: other ways to compare distributions

KL has two defects that matter in practice: it is asymmetric, and it is infinite when the supports do not overlap. The second is fatal for generative modeling, and this section explains why and what replaced it.

### f-divergences

A whole family, parameterized by a convex function f with f(1) = 0:

$$
D_f(p \,\|\, q) = \int q(x)\, f\!\left( \frac{p(x)}{q(x)} \right) dx
$$

| Choice of f | Divergence |
| --- | --- |
| t log t | forward KL |
| -log t | reverse KL |
| (t-1)^2 | chi-squared |
| \|t-1\|/2 | total variation |
| (sqrt t - 1)^2 | squared Hellinger |

All share the essential properties (nonnegative, zero iff equal, invariant under reparameterization) and all share the essential defect: they compare densities **pointwise**, so they are blind to geometry. If two distributions have disjoint support, every f-divergence is at its maximum regardless of whether the supports are adjacent or a mile apart.

### Jensen-Shannon

$$
\text{JSD}(p \,\|\, q) = \tfrac{1}{2}D_{KL}(p \,\|\, m) + \tfrac{1}{2}D_{KL}(q \,\|\, m), \qquad m = \tfrac{1}{2}(p + q)
$$

Compare each to the mixture. This fixes two problems at once: it is **symmetric**, and it is **always finite** (bounded by log 2), because the mixture m has mass wherever either does. Its square root is a genuine metric.

JSD matters historically because **the original GAN objective, with an optimal discriminator, is equivalent to minimizing 2 JSD(p\_data ‖ p\_model) minus a constant.** That is a satisfying result — it says the adversarial game has a well-defined divergence underneath it.

### Why that was a problem, and what Wasserstein fixed

Here is the failure mode, and it is one of the most instructive examples in modern ML.

Consider two distributions in the plane: one concentrated on the vertical line x = 0, the other on x = theta. Their supports are disjoint for any nonzero theta.

- **JSD** is log 2 for every theta, dropping discontinuously to 0 at theta = 0. **Constant, therefore zero gradient.**
- **KL** is infinite for every nonzero theta.
- **Wasserstein distance** is |theta|. Smooth, informative, with a useful gradient everywhere.

And this is exactly the situation in image generation: natural images lie on a low-dimensional manifold in pixel space, the generator's output is another low-dimensional manifold, and two low-dimensional manifolds in a high-dimensional space generically do not overlap. So the f-divergence between them is constant and its gradient is uninformative — which is a precise diagnosis of why early GANs were so hard to train.

**Wasserstein distance** (earth mover's distance) measures the minimum cost of transporting mass from p to q, where cost is mass times distance moved:

$$
W_1(p,q) = \inf_{\gamma \in \Pi(p,q)} \mathbb{E}_{(x,y)\sim\gamma}\big[\, \lVert x - y \rVert \,\big]
$$

The infimum is over all couplings with the right marginals, that is, all transport plans. **Because it involves distance, it knows about geometry**, which is precisely what f-divergences lack. Two disjoint distributions that are close together have a small Wasserstein distance; far apart, a large one.

Computing it directly is an optimal-transport problem, which is expensive. The **Kantorovich-Rubinstein duality** turns it into a maximization over 1-Lipschitz functions:

$$
W_1(p,q) = \sup_{\lVert f \rVert_L \le 1} \; \mathbb{E}_p[f(x)] - \mathbb{E}_q[f(x)]
$$

That dual form is directly implementable: parameterize f by a neural network (the "critic") and enforce the Lipschitz constraint. WGAN's original weight clipping was a crude enforcement; **WGAN-GP's gradient penalty** and **spectral normalization** are the better ones, and spectral normalization is exactly bounding the largest singular value of each weight matrix — Chapter 1's spectral norm doing real work.

### MMD

Maximum mean discrepancy compares distributions through the difference of their mean embeddings in a reproducing-kernel Hilbert space:

$$
\text{MMD}^2(p,q) = \mathbb{E}\big[k(x,x')\big] + \mathbb{E}\big[k(y,y')\big] - 2\,\mathbb{E}\big[k(x,y)\big]
$$

with x, x' from p and y, y' from q. Its practical virtue is that it needs only **samples**, never densities, and it has an unbiased estimator computable in closed form from a batch. With a characteristic kernel such as the Gaussian, MMD is zero only when the distributions are identical.

This makes MMD the standard tool for **two-sample testing**, which in ML means detecting distribution shift: collect a batch from training and a batch from production, compute MMD, and test whether it is larger than chance. It is also used in MMD-GANs and in domain adaptation, where you minimize MMD between source and target feature distributions.

### Choosing one

| Need | Use |
| --- | --- |
| Maximum likelihood training | forward KL (it is what NLL is) |
| Variational inference | reverse KL (tractable expectations) |
| A symmetric, bounded comparison | JSD |
| Distributions on disjoint or near-disjoint supports | Wasserstein |
| Only samples available, no densities | MMD |
| Provable bounds on total error probability | total variation |

The unifying lesson is worth stating plainly: **your choice of divergence determines your failure mode.** Forward KL gives you blurry mass-covering, reverse KL gives you mode collapse, f-divergences give you vanishing gradients on disjoint supports, and Wasserstein trades those for the cost of enforcing a Lipschitz constraint. Objectives are not interchangeable, and the differences show up in the samples.

**Try it.** (a) Compute JSD between p = (1,0) and q = (0,1) and confirm it equals log 2. (b) For the two-parallel-lines example, sketch JSD and W1 as functions of theta, and say which is trainable by gradient descent. (c) Why does MMD need only samples while KL needs densities? Answers in 5.11.

## 5.7 The ELBO and variational inference

### The problem

You have a latent-variable model p(x, z) and you want the marginal likelihood of your data:

$$
p(x) = \int p(x \mid z)\,p(z)\,dz
$$

This integral is intractable for anything interesting, and so is the posterior p(z|x) that depends on it. **Variational inference's move: pick a tractable family q(z|x), and optimize within it to get as close to the true posterior as possible.** Inference becomes optimization, which is the whole idea.

### Derivation 1: Jensen

Introduce q and apply Jensen's inequality to the concave log:

$$
\log p(x) = \log \int q(z\mid x)\,\frac{p(x,z)}{q(z\mid x)}\,dz \;\ge\; \mathbb{E}_{q}\left[ \log \frac{p(x,z)}{q(z\mid x)} \right] \;=\; \mathcal{L}_{\text{ELBO}}
$$

Multiplying and dividing by q turns the integral into an expectation, and Jensen moves the log inside at the cost of an inequality. That is the whole derivation, and it takes thirty seconds at a whiteboard.

### Derivation 2: the exact decomposition, which is more informative

$$
\log p(x) = \mathcal{L}_{\text{ELBO}} + D_{KL}\big( q(z\mid x) \,\|\, p(z \mid x) \big)
$$

*Proof.* Start from the KL on the right, write it as an expectation over q of log q minus log p(z|x), replace p(z|x) with p(x,z)/p(x), and note that log p(x) does not depend on z so it comes out of the expectation. Rearranging gives the identity.

This version is worth the extra minute because it tells you three things Jensen's version hides:

1. **The gap is exactly the KL between your approximation and the true posterior.** The ELBO is not merely *a* lower bound; the slack has a precise identity.
2. **The bound is tight exactly when q equals the true posterior.**
3. Since log p(x) is fixed, **maximizing the ELBO is the same as minimizing KL(q ‖ p(z|x))** — and note the direction. This is *reverse* KL, so variational posteriors are mode-seeking and systematically **underestimate posterior variance**. That is section 5.3's asymmetry producing a concrete, well-known pathology, and being able to name it is a strong signal.

### The useful rearrangement

$$
\mathcal{L}_{\text{ELBO}} = \underbrace{\mathbb{E}_{q(z\mid x)}\big[ \log p(x \mid z) \big]}_{\text{reconstruction}} - \underbrace{D_{KL}\big( q(z\mid x) \,\|\, p(z) \big)}_{\text{regularizer}}
$$

This is the VAE loss, and each term has a clear job:

- **Reconstruction:** encode x to a latent, decode it, and measure how well you recovered x. For Gaussian likelihoods this is squared error; for Bernoulli it is binary cross-entropy.
- **KL to the prior:** keep the encoder's output distribution close to the prior, which both regularizes and ensures that sampling from the prior at generation time lands in a region the decoder understands.

The two terms are in genuine tension. Pure reconstruction wants each input mapped to a distinct, confident point; the KL term wants every input mapped to the same prior. The balance is what produces a usable latent space rather than a lookup table.

### How it is actually optimized

Two ingredients, both from Chapter 3:

1. **The reparameterization trick** for the reconstruction term. Sample z = mu + sigma \* epsilon with epsilon standard normal, so gradients flow into the encoder's parameters. Without this there is no gradient path through the sampling step.
2. **The analytic KL** for the regularizer, using the closed form from section 5.3. Computing it exactly rather than by sampling is Rao-Blackwellization and cuts gradient variance substantially.

### Posterior collapse

The characteristic VAE failure, and a good thing to be able to diagnose. If the decoder is powerful enough to model x on its own — an autoregressive decoder, for instance — the optimizer discovers that it can set q(z|x) equal to the prior, driving the KL term to zero at no cost in reconstruction. The latent code carries no information and is ignored entirely.

In information-theoretic terms, the KL term is an upper bound on the information the latent carries about the input, and the optimizer is minimizing it. If the decoder does not need that information, the cheapest solution is to transmit nothing.

The standard mitigations: **KL annealing** (ramp the KL weight up from zero so the model learns to use the latent before being penalized for it), **free bits** (do not penalize KL below a threshold per dimension), weakening the decoder, and **beta-VAE** with the KL weight as an explicit knob. beta > 1 pushes toward disentangled but less informative latents; beta < 1 toward better reconstruction.

### Where else the ELBO appears

- **EM algorithm.** The E-step sets q to the exact posterior, making the bound tight; the M-step maximizes over the model parameters. EM is coordinate ascent on the ELBO, which is the cleanest way to understand why it monotonically increases the likelihood.
- **Variational Bayes** for approximate posteriors over parameters, including Bayesian neural networks.
- **Diffusion models.** Their training objective is a specially structured ELBO over a fixed noising process, which simplifies to a weighted denoising regression. Knowing that the simple noise-prediction loss descends from an ELBO is a good detail to have.
- **Control as inference.** Several RL formulations cast optimal control as variational inference, with the ELBO producing the maximum-entropy objective of section 5.8.

**Try it.** (a) Derive the ELBO decomposition (derivation 2) yourself, without looking. (b) Compute the KL term for a VAE with a two-dimensional latent where the encoder outputs mu = (1, 0) and sigma = (0.5, 2). (c) Explain posterior collapse in terms of the two ELBO terms, and say why a weaker decoder helps. Answers in 5.11.

## 5.8 Maximum entropy

### The principle

When several distributions are consistent with what you know, **choose the one with maximum entropy.** Any other choice smuggles in structure you have no evidence for. This is the cleanest available justification for a large number of modelling defaults.

### The central result

Maximize entropy subject to moment constraints E\[T\_k(X)\] = c\_k. Form the Lagrangian, differentiate, and the solution is always the same shape:

$$
p(x) \;\propto\; \exp\!\left( \sum_k \lambda_k T_k(x) \right)
$$

**Maximum entropy subject to expectation constraints produces exactly an exponential family** (Chapter 4), with the sufficient statistics being the constrained quantities and the natural parameters being the Lagrange multipliers. The two chapters' central objects turn out to be the same thing approached from opposite ends, which is a genuinely elegant connection and a good one to be able to state.

The specific cases:

| What you constrain | Maximum-entropy distribution |
| --- | --- |
| support only, nothing else | **uniform** |
| mean, on the nonnegative reals | **exponential** |
| mean and variance, on the reals | **Gaussian** |
| mean, on the nonnegative integers | **geometric** |
| mean of log x and of x, on positives | **gamma** |

**So the Gaussian is the maximum-entropy distribution for a given mean and covariance.** That is the best available answer to "why assume a Gaussian?", and it is far stronger than an appeal to the CLT: it says that if you are only willing to specify two moments, the Gaussian is the least presumptuous completion of that specification. Every non-Gaussian distribution with the same mean and variance has strictly less entropy, meaning it encodes additional assumptions.

*Sketch of the Gaussian case.* Maximize -integral of p log p subject to normalization, a fixed mean, and a fixed second moment. Three multipliers give three constraints; the stationarity condition yields log p as a quadratic in x, so p is the exponential of a quadratic, which is a Gaussian. Matching the constraints fixes the parameters.

### Maximum-entropy RL

This is the section's main payoff for agentic AI, and it explains a piece of notation you will meet constantly in Chapter 9.

A standard RL objective maximizes expected return. The **maximum-entropy** objective adds a bonus for keeping the policy uncertain:

$$
J(\pi) = \mathbb{E}\left[ \sum_t r(s_t, a_t) + \alpha\, H\big(\pi(\cdot \mid s_t)\big) \right]
$$

Solve the one-step version — maximize expected reward plus alpha times entropy over distributions on actions — and the optimum is:

$$
\pi^*(a \mid s) \;=\; \frac{\exp\big(Q(s,a)/\alpha\big)}{\sum_{a'} \exp\big(Q(s,a')/\alpha\big)} \;=\; \operatorname{softmax}\big(Q(s,\cdot)/\alpha\big)
$$

**The softmax policy is not a heuristic; it is the exact solution to entropy-regularized reward maximization**, and the temperature alpha is exactly the entropy weight. That is the derivation behind Soft Actor-Critic and behind every "Boltzmann exploration" scheme, and it is one of the most satisfying results in this tutorial because it explains a ubiquitous design choice from first principles.

Why you would want it: it encourages exploration automatically, it keeps the policy from collapsing prematurely onto one action, it produces more robust policies (multiple good actions stay available if one becomes unavailable), and it makes the optimization better conditioned by smoothing the objective. As alpha goes to zero you recover the greedy argmax policy.

The same structure appears with a **KL penalty to a reference policy** instead of a raw entropy bonus, which is the RLHF setting:

$$
\pi^*(a\mid s) \;\propto\; \pi_{\text{ref}}(a \mid s)\,\exp\big(r(s,a)/\beta\big)
$$

The optimal KL-regularized policy is the reference policy **reweighted exponentially by reward**. This closed form is the starting point for **DPO**, which inverts it to express the reward in terms of the optimal and reference policies and thereby removes the need to train a separate reward model. If you can derive this expression, you can derive DPO, and Chapter 9 does exactly that.

### Other appearances

- **Maximum-entropy classifiers** are logistic and softmax regression under another name: maximize entropy subject to matching the empirical feature expectations, and you get exactly softmax regression. This was the standard framing in NLP before the neural era, and it is why the term "MaxEnt model" appears in older papers.
- **Boltzmann distributions** in statistical physics are maximum entropy subject to a fixed expected energy, with temperature as the Lagrange multiplier. The mathematical identity with softmax is complete, which is why the physics vocabulary (temperature, partition function, free energy) is used throughout ML.
- **Prior selection.** Maximum entropy is one principled way to choose a prior given partial information.
- **Sampling temperature** in language model decoding is the same parameter: dividing logits by T before the softmax interpolates between greedy (T to 0) and uniform (T large), and it is precisely the entropy-weight knob.

### The honest caveat

Maximum entropy is a principle, not a theorem about the world. It tells you what to assume given your constraints; it does not tell you that the world obeys your constraints. It also depends on the choice of base measure in the continuous case, which is the same reparameterization sensitivity that afflicts differential entropy (section 5.1). Being able to state the limitation alongside the principle is what makes the answer credible.

**Try it.** (a) Derive the maximum-entropy distribution on a finite set with no constraints, and confirm it is uniform. (b) Show that the entropy-regularized one-step RL objective is maximized by a softmax over Q values divided by alpha. (c) Explain why sampling temperature in a language model is the same parameter as alpha above. Answers in 5.11.

## 5.9 Information theory in modern ML

### Contrastive learning and InfoNCE

The dominant self-supervised objective. Given an anchor x, a positive x+ (an augmented view of the same thing), and N-1 negatives, the loss is

$$
\mathcal{L}_{\text{InfoNCE}} = -\log \frac{\exp\big(\text{sim}(x, x^{+})/\tau\big)}{\sum_{j=1}^{N}\exp\big(\text{sim}(x, x_j)/\tau\big)}
$$

This is **cross-entropy for an N-way classification problem whose task is "identify which of these N candidates is the true partner"**. Recognizing that is the whole trick: it is softmax classification with the classes constructed on the fly, which is why it trains with exactly the same machinery.

The information-theoretic content is that InfoNCE gives a **lower bound on mutual information** between the two views:

$$
I(x; x^{+}) \;\ge\; \log N - \mathcal{L}_{\text{InfoNCE}}
$$

Read the bound carefully, because its limitation is the interesting part. **The bound is capped at log N.** With a batch of 256 negatives you cannot certify more than about 5.5 nats of mutual information, no matter how good your representation is. This explains why contrastive methods are so sensitive to batch size, and why MoCo introduced a momentum-updated queue of negatives to decouple the number of negatives from the batch size. It also means you should be skeptical of any claim that a contrastive method "maximizes mutual information" — it maximizes a bound that saturates, and empirically tighter MI bounds do not always give better representations, which suggests the MI story is not the full explanation of why these methods work.

The temperature tau controls how sharply the loss focuses on the hardest negatives: small tau makes the softmax peaky so nearby negatives dominate the gradient. It is the same temperature parameter as everywhere else in this chapter.

### The information bottleneck

Find a representation T of the input X that is maximally informative about the label Y while being minimally informative about X:

$$
\min_T \; I(X; T) - \beta\, I(T; Y)
$$

The framing is appealing: **a good representation keeps the signal and throws away everything else**, and compression is not a side effect but the goal. It also gives a principled account of why representations should be lossy.

Be careful about the status of this idea as an explanation of deep learning. The proposal that training exhibits a distinct "compression phase" in which I(X;T) decreases has been actively disputed: subsequent work found the effect depends on the activation function and on how mutual information is estimated, and that it does not appear in all settings. The variational information bottleneck (VIB) as a *regularizer* is a real and usable technique; the information bottleneck as a *theory of why deep learning works* is contested. Presenting it that way is the accurate position.

### The KL penalty in RLHF

When fine-tuning a language model with reinforcement learning from human feedback, the objective is

$$
\max_\pi \; \mathbb{E}_{\pi}\big[ r(x,y) \big] \;-\; \beta\, D_{KL}\big( \pi \,\|\, \pi_{\text{ref}} \big)
$$

The KL term does real work and you should be able to say what:

- **It prevents reward hacking.** The reward model is a learned approximation, accurate near the distribution it was trained on and unreliable far from it. Without a constraint, the policy will find inputs where the reward model is wrong and exploit them, producing high reward and terrible outputs.
- **It preserves the capabilities of the base model**, which the reward signal alone would happily destroy.
- **It makes the problem a trust region**, keeping updates small enough that the learned reward remains approximately valid — the same logic as TRPO's constraint, and the same Fisher-metric picture from section 5.3.

As section 5.8 showed, the exact optimum of this objective is the reference policy reweighted by the exponentiated reward, and inverting that relation is how DPO eliminates the separate reward model.

The practical note: the KL is usually estimated per-token from sampled sequences, and low-variance estimators for it matter, since a naive single-sample estimate of KL is noisy and can even be negative.

### Knowledge distillation

Train a student to match a teacher's full output distribution rather than the hard labels:

$$
\mathcal{L} = \alpha\, \text{CE}(y, q_{\text{student}}) + (1-\alpha)\, T^2\, D_{KL}\big( p_{\text{teacher}}^{(T)} \,\|\, q_{\text{student}}^{(T)} \big)
$$

The information-theoretic reading is the useful one: **a one-hot label carries at most log K bits, while the teacher's full distribution carries much more.** Knowing that an image of a truck gets 0.1 probability on "car" and 10^-8 on "strawberry" tells the student about the similarity structure of the label space — the "dark knowledge" that hard labels discard. That is why distillation often beats training on the labels directly, and it is a much better explanation than "the teacher is a good regularizer".

The temperature T softens both distributions to expose that structure, since at T = 1 the teacher's non-target probabilities may be too small to contribute meaningful gradient. The T^2 factor compensates for the fact that softening scales the gradients down by 1/T^2, keeping the two loss terms comparable as T changes. Note also that this is a place where **label smoothing hurts**: it erases exactly the fine logit structure distillation depends on.

### Scaling laws and the entropy floor

Empirical scaling laws describe test loss as a power law in model size, data, and compute, typically with an additive irreducible constant:

$$
L(N) \approx \frac{A}{N^{\alpha}} + L_{\infty}
$$

That constant term is the information-theoretic floor: **the entropy of the data distribution itself.** Text is genuinely stochastic — many continuations are legitimately possible — so no model can drive cross-entropy below the conditional entropy of the next token. When a loss curve flattens, part of what you are seeing is the model approaching the entropy of language rather than a failure of optimization. Distinguishing "we have run out of model capacity" from "we have reached the entropy floor" is a real diagnostic question, and the information-theoretic framing is what makes it askable.

### A short list of other appearances

- **Minimum description length** as a model-selection principle: the best model minimizes the description length of the model plus the data given the model.
- **Compression-based evaluation** of language models, reported as bits per byte to be tokenizer-independent.
- **Rate-distortion theory** underlying lossy neural compression, where you trade bits against reconstruction error, and the VAE's two terms map directly onto rate and distortion.
- **Channel capacity** arguments in analyses of what a bottleneck layer can transmit.

**Try it.** (a) With a batch of 512 negatives, what is the maximum mutual information InfoNCE can certify, in nats and bits? (b) Explain why the RLHF KL penalty prevents reward hacking, in two sentences. (c) Why does distillation transfer more information per example than training on hard labels? Answers in 5.11.

## 5.10 Interview drill set

**1. Why is information defined with a logarithm?** Because information from independent events must add, which requires a function turning products into sums. Up to a constant, the logarithm is the only continuous solution.

**2. What does entropy measure, and when is it maximal?** Average surprise, equivalently the minimum average bits needed to encode samples. It is maximal for the uniform distribution and zero for a deterministic one.

**3. What is cross-entropy, in coding terms?** The average bits spent when the true distribution is p but your codebook was built for q. It is at least H(p), with equality only when q = p.

**4. What is KL divergence, in one sentence?** The extra bits wasted by using the wrong model: cross-entropy minus entropy. Nonnegative, zero only when the distributions match, and not symmetric.

**5. Prove that KL is nonnegative.** Apply Jensen to the concave log: the expectation under p of log(q/p) is at most the log of the expectation of q/p, which is log 1 = 0. Negating gives the result. Equality requires q/p constant, hence p = q.

**6. Explain forward versus reverse KL.** Forward KL(p‖q) takes the expectation under the data, so missing a mode is catastrophic and the model spreads out to cover everything — mass-covering, hence blurry. Reverse KL(q‖p) takes it under the model, so placing mass where the data has none is catastrophic and the model collapses onto one mode — mode-seeking, hence sharp but low-diversity.

**7. Which does maximum likelihood use, and what does that predict?** Forward. It predicts that maximum-likelihood generative models will cover the data broadly and produce over-smoothed, blurry or bland samples.

**8. Which does variational inference use, and why?** Reverse, because the expectations are then over q, which you can sample from, while forward KL would require sampling from the intractable true posterior. The cost is that variational posteriors systematically underestimate variance.

**9. Why is cross-entropy the loss for classification?** It is the negative log-likelihood of the label under the model, equivalently the KL from the one-hot label distribution to the model's output. Minimizing it is maximum likelihood.

**10. Why not use MSE for classification?** With a saturating output like a sigmoid, the MSE gradient carries a factor of the sigmoid derivative, which vanishes exactly when the model is confidently wrong. Cross-entropy's log cancels that factor, leaving p - y with no saturation.

**11. What is perplexity and what does it mean?** The exponential of the cross-entropy: the effective number of equally likely options the model is choosing among per token. It is not comparable across different tokenizers.

**12. What is mutual information and how does it differ from correlation?** The reduction in uncertainty about one variable from learning another, equivalently the KL from the joint to the product of marginals. It captures any dependence, not just linear, and is invariant under invertible transformations.

**13. Is mutual information easy to estimate?** No. Discrete plug-in estimates are biased upward on small samples; continuous estimation degrades badly with dimension. Variational bounds like InfoNCE cannot certify more than about log(number of samples) nats.

**14. Why did early GANs have vanishing gradients, in divergence terms?** The original objective corresponds to Jensen-Shannon, which is constant at log 2 whenever the supports are disjoint. Since real and generated data lie on non-overlapping low-dimensional manifolds, the divergence carries no gradient signal.

**15. How does Wasserstein distance fix that?** It measures the cost of transporting mass, so it depends on how far apart the distributions are rather than only whether they overlap. It varies smoothly and provides a useful gradient even with disjoint supports.

**16. Derive the ELBO.** Write log p(x) as the log of an expectation under q of p(x,z)/q(z|x) and apply Jensen. Better, use the exact identity log p(x) = ELBO + KL(q ‖ p(z|x)), which shows the gap is precisely the approximation error of the posterior.

**17. What are the two terms of the VAE loss doing?** Reconstruction, which wants the latent to carry enough information to rebuild the input, and KL to the prior, which regularizes and makes the latent space samplable. They are in tension, and the balance produces a usable latent space.

**18. What is posterior collapse?** When a sufficiently powerful decoder makes the latent unnecessary, the optimizer drives the KL term to zero by setting the approximate posterior equal to the prior. The latent carries no information. Mitigations include KL annealing, free bits, and weakening the decoder.

**19. Why is the Gaussian the default distributional assumption?** It is the maximum-entropy distribution given a mean and covariance, so it is the least presumptuous choice once you decide to specify only two moments. It is also closed under linear maps, marginalization and conditioning.

**20. Where does a softmax policy come from?** It is the exact optimum of entropy-regularized reward maximization: maximize expected Q plus alpha times entropy and you get softmax(Q/alpha). The temperature is the entropy weight.

**21. What is the optimal KL-regularized policy?** The reference policy reweighted by the exponentiated reward divided by beta. Inverting this relation to express reward in terms of policies is how DPO removes the separate reward model.

**22. Why does RLHF include a KL penalty?** To prevent the policy from exploiting errors in the learned reward model, to preserve the base model's capabilities, and to keep updates inside a trust region where the reward approximation remains valid.

**23. What is InfoNCE, really?** Cross-entropy over an N-way task of identifying the true positive among N candidates. It lower-bounds mutual information, but the bound saturates at log N, which is why batch size and negative-sampling schemes matter so much.

**24. Why does knowledge distillation work?** A hard label carries at most log K bits; the teacher's full distribution carries the similarity structure across classes. That extra signal per example is what the student learns from, and the temperature exposes it.

**25. Why can differential entropy be negative?** Because densities can exceed 1, so their negative logs can be negative. Differential entropy also shifts under rescaling, so only differences of differential entropies — KL, mutual information — are meaningful.

**26. What does the irreducible term in a scaling law represent?** The entropy of the data distribution itself. Language is genuinely stochastic, so no model can push cross-entropy below the true conditional entropy of the next token.

**27. What does label smoothing do, information-theoretically, and what does it cost?** It replaces an impossible one-hot target with a softer one, adding a term that pulls the output toward uniform. It improves calibration and bounds the logits, but it erases fine logit structure and can hurt distillation and transfer.

## 5.11 Assignment and solutions

### Solutions to the in-text exercises

**5.1.** (a) H = 0.5(1) + 0.25(2) + 0.125(3) + 0.125(3) = 1.75 bits. The code A = 0, B = 10, C = 110, D = 111 has lengths 1, 2, 3, 3 and average length 0.5 + 0.5 + 0.375 + 0.375 = 1.75 bits exactly. It achieves the bound because every probability is a power of 1/2, so the ideal lengths log(1/p) are all integers. (b) H(p) = E\[log(1/p)\] <= log E\[1/p\] by Jensen on the concave log, and E\_p\[1/p\] = sum over x of p(x)/p(x) = |X|, giving H <= log|X|. Equality requires 1/p constant, hence uniform. (c) Because a density is probability per unit volume and can exceed 1, so -log p can be negative; a probability mass is at most 1, so -log p is always nonnegative.

**5.2.** (a) Same as 5.1(a): 1.75 bits, code 0, 10, 110, 111. (b) Cross-entropy with q uniform is -sum p log(1/4) = 2 bits, since every codeword now has length 2. KL = 2 - 1.75 = 0.25 bits, so you waste a quarter bit per symbol. (c) PPL = e^2.5 = 12.2. The model is about as uncertain at each token as if it were choosing uniformly among roughly 12 options.

**5.3.** (a) KL(p‖q) = 0.5 log(0.5/0.9) + 0.5 log(0.5/0.1) = 0.5(-0.588) + 0.5(1.609) = 0.511 nats. KL(q‖p) = 0.9 log(0.9/0.5) + 0.1 log(0.1/0.5) = 0.9(0.588) + 0.1(-1.609) = 0.368 nats. Different, as promised. (b) KL becomes infinite. In training, this means a maximum-likelihood objective imposes an infinite penalty for assigning zero probability to something that occurred, which is why trained models always retain some mass on every possible outcome and why smoothing matters in count-based models. (c) Maximum likelihood minimizes forward KL, which is mass-covering, so you get a single wide Gaussian centered between the clusters, with its peak in the empty region where no data lives. Reverse KL would instead have picked one cluster and fit it tightly, ignoring the other.

**5.4.** (a) True class first: -log 0.7 = 0.357 nats. True class second: -log 0.2 = 1.609 nats. Being confidently wrong is much more expensive, and the ratio grows without bound as the assigned probability falls. (b) With the smoothed target, the loss is -(1-eps) log q\_c - (eps/K) sum over k of log q\_k. The first term is (1-eps) times the usual cross-entropy; the second is eps times the cross-entropy between the uniform distribution and q, which equals eps times \[KL(uniform ‖ q) + H(uniform)\], and the last piece is a constant. So the objective is the usual loss plus a term pulling q toward uniform. (c) With MSE the gradient with respect to the logit includes sigma'(z), which approaches zero as |z| grows; a confidently wrong prediction therefore produces almost no gradient and the model cannot correct itself. With cross-entropy the log's derivative cancels that factor exactly, leaving p - y, which is largest precisely when the model is most wrong.

**5.5.** (a) H(X) = 1 bit, H(Y|X) = 0 (knowing X determines Y), I = 1 bit. (b) H(X) = 1, H(Y|X) = H(Y) = 1, I = 0. (c) Correlation measures only the linear component of dependence, and by symmetry Cov(X, X^2) = E\[X^3\] = 0 for a symmetric X. Mutual information measures the full change in the distribution: knowing X determines X^2 exactly, so H(X^2 | X) = 0 and MI equals H(X^2), which is large.

**5.6.** (a) The mixture is m = (0.5, 0.5). KL(p‖m) = 1 log(1/0.5) = log 2, and likewise for q. So JSD = 0.5 log 2 + 0.5 log 2 = log 2, the maximum. (b) JSD is the constant log 2 for all nonzero theta with a discontinuous drop to 0 at the origin — flat, so its gradient is zero and gradient descent has no signal. W1 is |theta|, a V shape with constant-magnitude slope, so gradient descent moves theta toward 0 from anywhere. (c) Because MMD is defined through expectations of a kernel evaluated at sample pairs, and those expectations have unbiased estimators computed directly from samples. KL involves the ratio of densities pointwise, and you cannot evaluate a ratio of densities you do not have.

**5.7.** (a) See derivation 2 in the section; the key steps are substituting p(z|x) = p(x,z)/p(x) inside the KL and pulling log p(x) out of the expectation because it does not depend on z. (b) Using the per-dimension formula, dimension 1 contributes 0.5(1 + 0.25 - log 0.25 - 1) = 0.5(0.25 + 1.386) = 0.818; dimension 2 contributes 0.5(0 + 4 - log 4 - 1) = 0.5(3 - 1.386) = 0.807. Total about 1.625 nats. Note that both an over-small and an over-large variance are penalized. (c) A powerful decoder can model x without the latent, so the reconstruction term is already near its optimum regardless of z. The optimizer then gets the KL term for free by setting q(z|x) = p(z), which costs nothing in reconstruction and reduces the loss. A weaker decoder cannot reconstruct well without the latent, so the reconstruction term now genuinely rewards using z, and the equilibrium moves away from collapse.

**5.8.** (a) Maximize -sum p log p subject to sum p = 1. The Lagrangian gives -log p - 1 - lambda = 0 for every outcome, so p is the same constant everywhere, hence uniform. (b) Maximize sum over a of pi(a)Q(a) + alpha times (-sum pi log pi) subject to normalization. Stationarity gives Q(a) - alpha(log pi(a) + 1) - lambda = 0, so log pi(a) = Q(a)/alpha + constant, hence pi proportional to exp(Q(a)/alpha). Normalizing gives the softmax. (c) Because dividing logits by T before a softmax is identical in form to dividing Q by alpha: both interpolate between the greedy argmax and the uniform distribution, and both are the entropy weight in a maximum-entropy objective. A language model's logits play the role of Q.

**5.9.** (a) log 512 = 6.24 nats = 9 bits. That is the ceiling regardless of how good the representation is. (b) The reward model is a learned approximation that is only reliable near the distribution it was trained on; without a constraint the policy will drift to regions where the reward model is wrong and exploit its errors. The KL penalty keeps the policy near the reference, where the reward model's estimates remain approximately valid. (c) A one-hot label transmits at most log K bits and says nothing about how the wrong classes relate to each other. The teacher's full distribution encodes the similarity structure across all classes, so each example carries far more usable signal.

### Problem set

**P1 (entropy).** A biased coin has P(heads) = 0.9. (a) Compute its entropy in bits. (b) How many coin flips can you compress 1,000 such flips into, asymptotically? (c) Design a scheme that beats naive 1-bit-per-flip encoding, and explain why block coding is necessary to approach the bound.

**P2 (KL asymmetry).** Let p be an equal mixture of N(-3, 1) and N(3, 1). Find the single Gaussian minimizing forward KL, and describe the one minimizing reverse KL. Sketch both against p and explain the difference in one sentence each.

**P3 (cross-entropy).** Prove that cross-entropy H(p,q) is minimized over q at q = p, using only the nonnegativity of KL. Then explain why this justifies cross-entropy as a training objective.

**P4 (mutual information).** X is uniform on {1,2,3,4}. Y = 1 if X is even, 0 otherwise. Compute H(X), H(Y), H(X|Y), H(Y|X), I(X;Y), and verify every identity in the information diagram.

**P5 (Gaussian KL).** Derive the KL between two univariate Gaussians from the definition. Then specialize to the VAE case against a standard normal and confirm the formula in section 5.3.

**P6 (ELBO).** For a VAE with a one-dimensional latent, a standard normal prior, and an encoder outputting mu and sigma, write the full loss for a Bernoulli decoder. Identify which terms are computed analytically and which by sampling, and say why.

**P7 (maximum entropy).** Derive the maximum-entropy distribution on the nonnegative reals with a fixed mean, and confirm it is exponential. Then do the same on the reals with fixed mean and variance.

**P8 (divergence choice).** You are building a generative model of a dataset with several distinct clusters. Discuss what you would expect from forward KL, reverse KL, JSD and Wasserstein objectives respectively, and say which failure modes you would watch for in each case.

**P9 (coding).** (a) Implement Huffman coding and verify empirically that the average code length lies between H and H + 1 bits. (b) Fit a single Gaussian to a bimodal dataset by maximum likelihood and by minimizing reverse KL (via sampling), and plot both. (c) Compute InfoNCE loss for a toy embedding task at several batch sizes and confirm the log N ceiling on the implied MI bound.

**P10 (synthesis).** Explain in one paragraph why these are all the same idea: cross-entropy is the classification loss; maximum likelihood minimizes forward KL; maximum-likelihood generative models produce blurry samples; a language model never assigns zero probability to a token; and the irreducible term in a scaling law is the entropy of the data.

### Selected solutions

**P1.** (a) H = -0.9 log2 0.9 - 0.1 log2 0.1 = 0.137 + 0.332 = 0.469 bits. (b) About 469 bits, less than half the naive 1,000. (c) Single-symbol codes cannot help: any prefix code assigns at least 1 bit per symbol, so you are stuck at 1 bit per flip. You must encode **blocks** of flips, so that a very likely block (such as ten heads in a row, probability 0.35) gets a short codeword while rare blocks get long ones. The ideal length log(1/p) is fractional, and only by grouping symbols can you amortize fractions across a block — this is exactly why arithmetic coding, which effectively allows fractional code lengths, approaches the entropy bound more closely than Huffman on skewed distributions.

**P2.** Forward KL is mass-covering, so the optimizing Gaussian matches the mixture's mean and variance: mean 0 and variance 1 + 9 = 10, hence N(0, 10). It is broad, straddles both modes, and places its highest density at 0, where p has almost no mass — a vivid illustration of how a maximum-likelihood fit can put its mode where the data is not. Reverse KL is mode-seeking, so it collapses onto one of the two components, giving approximately N(3, 1) or N(-3, 1); both are local optima and which you get depends on initialization.

**P3.** H(p,q) = H(p) + KL(p‖q). The first term does not involve q, and the second is nonnegative and zero exactly when q = p. Therefore cross-entropy is minimized over q precisely at q = p, with minimum value H(p). This justifies cross-entropy as a training objective because it says the objective's unique optimum is the true conditional distribution — the loss is not merely a convenient surrogate, it is *strictly proper* in the sense of Chapter 4, and a model with unlimited capacity trained to the optimum recovers the truth.

**P4.** H(X) = 2 bits. Y is a fair coin so H(Y) = 1 bit. Given Y, X is uniform on two values, so H(X|Y) = 1 bit. H(Y|X) = 0, since X determines Y. I(X;Y) = H(Y) - H(Y|X) = 1 bit, and also H(X) - H(X|Y) = 2 - 1 = 1 bit, confirming symmetry. H(X,Y) = H(X) + H(Y|X) = 2 bits, and the diagram identity gives I = H(X) + H(Y) - H(X,Y) = 2 + 1 - 2 = 1. All consistent. Note that Y is a deterministic function of X, so all of Y's information is contained in X, but X retains 1 bit that Y does not capture.

**P10.** All five follow from **cross-entropy being the negative log-likelihood, hence forward KL from the data distribution to the model, up to the data's own constant entropy.** Cross-entropy is the classification loss because it is the NLL of the label. Minimizing it is minimizing forward KL, since the data's entropy does not depend on the parameters. Forward KL is mass-covering — it imposes an enormous penalty wherever the data has mass and the model does not — so a model with insufficient capacity to represent the data sharply will hedge, spreading probability over everything plausible, which is what blurriness and blandness are. The infinite-penalty property is why a trained language model always keeps some probability on every token: assigning exactly zero to something that occurs costs infinite loss. And since the objective equals the data's entropy plus a nonnegative KL, the loss can never go below that entropy, which is exactly the irreducible constant that appears in every empirical scaling law. One quantity, five consequences.

**P5.** KL between two univariate Gaussians, from the definition. KL = E\_p\[log p - log q\], where p is N(mu\_1, sigma\_1^2) and q is N(mu\_2, sigma\_2^2). Write out both log densities:

$$
\log\frac{p}{q} = \log\frac{\sigma_2}{\sigma_1} - \frac{(x-\mu_1)^2}{2\sigma_1^2} + \frac{(x-\mu_2)^2}{2\sigma_2^2}
$$

Now take the expectation under p, using E\[(x - mu\_1)^2\] = sigma\_1^2 and E\[(x - mu\_2)^2\] = sigma\_1^2 + (mu\_1 - mu\_2)^2 (variance plus squared mean shift). The middle term gives -1/2. The last gives (sigma\_1^2 + (mu\_1-mu\_2)^2)/(2 sigma\_2^2). Collecting:

$$
D_{KL} = \log\frac{\sigma_2}{\sigma_1} + \frac{\sigma_1^2 + (\mu_1-\mu_2)^2}{2\sigma_2^2} - \frac{1}{2}
$$

Setting mu\_2 = 0 and sigma\_2 = 1 gives -log sigma\_1 + (sigma\_1^2 + mu\_1^2)/2 - 1/2, which rearranges to 0.5(mu^2 + sigma^2 - log sigma^2 - 1), the VAE form. Check it vanishes at mu = 0, sigma = 1.

**P6.** VAE loss with a one-dimensional latent and Bernoulli decoder, for one data point x in {0,1}^D:

$$
\mathcal{L} = -\sum_{d=1}^{D}\Big[x_d\log \hat{x}_d + (1-x_d)\log(1-\hat{x}_d)\Big] + \tfrac{1}{2}\big(\mu^2 + \sigma^2 - \log\sigma^2 - 1\big)
$$

where x-hat = decoder(z) and z = mu + sigma epsilon with epsilon \~ N(0,1). **The reconstruction term is estimated by sampling** — usually a single epsilon per data point per step, which is a one-sample Monte Carlo estimate made differentiable by the reparameterization. **The KL term is computed analytically**, because a closed form exists. Doing so is Rao-Blackwellization (Chapter 3): integrating out randomness you can handle exactly strictly reduces variance at no cost in bias, so there is never a reason to sample the KL when the formula is available.

**P7.** Maximum entropy with a mean constraint on the nonnegative reals. Maximize the negative integral of p log p subject to the integral of p being 1 and the integral of x p being mu. The Lagrangian stationarity condition gives -log p - 1 - lambda\_0 - lambda\_1 x = 0, so p is proportional to exp(-lambda\_1 x) — an exponential family with a single sufficient statistic x. Normalizing on \[0, infinity) requires lambda\_1 > 0 and gives p(x) = lambda\_1 exp(-lambda\_1 x), and matching the mean gives lambda\_1 = 1/mu. So the **exponential distribution** is the maximum-entropy distribution for a fixed mean on the positive half-line.

On the whole real line with fixed mean and variance, two constraints give two multipliers, and stationarity yields log p linear in x and x^2, so p is the exponential of a quadratic — a **Gaussian**. Matching the two moments fixes its parameters. This is why the Gaussian assumption is the least presumptuous one once you commit to specifying only two moments.

**P8.** Divergence choice for multi-cluster data. **Forward KL** (maximum likelihood): the model covers all clusters but places mass in the gaps between them, so samples drawn from the gaps are incoherent — this is the blur. Watch for: good likelihood, poor sample quality. **Reverse KL**: the model locks onto a subset of clusters and produces clean samples from those while never generating the others — mode collapse. Watch for: sharp samples, low diversity, missing categories entirely. **JSD** (the original GAN objective): symmetric and bounded, but when the model's support and the data's support are nearly disjoint — which is the normal situation for low-dimensional manifolds in high-dimensional space — the divergence is essentially constant and its gradient is uninformative. Watch for: discriminator wins completely, generator loss flat, no learning. **Wasserstein**: provides a usable gradient even with disjoint supports because it measures transport distance, at the cost of needing to enforce a Lipschitz constraint on the critic. Watch for: the constraint being enforced badly (weight clipping is crude; gradient penalty and spectral normalization are better), which shows up as a critic that is either too weak to guide or unstable.

**P9 (coding).** Expected results. (a) Huffman on any distribution: the average code length always lands in \[H, H+1) bits, and the gap is largest when probabilities are far from powers of 1/2. On a highly skewed binary source (p = 0.9), Huffman on single symbols gives exactly 1 bit against an entropy of 0.469, so the gap is at its worst; block-coding pairs or triples closes most of it, which demonstrates why arithmetic coding, which effectively allows fractional lengths, dominates on skewed sources. (b) Fitting a Gaussian to a bimodal mixture: maximum likelihood gives a single wide Gaussian centred between the modes, with its peak where almost no data lies. Minimizing reverse KL by sampling gives a narrow Gaussian sitting on one mode, and which mode depends on initialization — run it from several starts and you will get both answers. Plot both against the target and the asymmetry of section 5.3 becomes visual rather than verbal. (c) InfoNCE: compute log N minus the loss for batch sizes 8, 64, 512. The implied MI bound is capped at log N (2.08, 4.16, 6.24 nats) regardless of how well the encoder performs, so a well-trained encoder saturates the bound at small batch sizes and the estimate stops being informative.
