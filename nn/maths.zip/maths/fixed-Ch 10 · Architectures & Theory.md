﻿# Chapter 10 · Architectures, Systems, and Theory

2026-09-22 · @Behi

Five topics that the first nine chapters referenced without developing. Each is standard interview material and each rests entirely on tools already built, which is why they belong together at the end rather than scattered through the earlier chapters.

Diffusion models are change of variables plus an ELBO. Mixture of experts is a routing problem with a load-balancing constraint. Distributed training is the memory arithmetic of Chapter 7 plus communication costs. Learning theory is the concentration inequalities of Chapter 3 applied to a hypothesis class. Kernels are Chapter 6's duality plus Chapter 1's PSD matrices.

## 10.1 Diffusion models

### The idea

Destroying structure is easy; creating it is hard. So define an easy forward process that gradually turns data into noise, then **learn to reverse it**. Sampling means starting from pure noise and running the learned reverse process.

```mermaid
flowchart LR
  X0["x_0<br/>data"] -->|"add noise"| X1["x_1"]
  X1 -->|"add noise"| XT["x_T<br/>pure Gaussian"]
  XT -->|"learned denoise"| X1b["x_1"]
  X1b -->|"learned denoise"| X0b["x_0<br/>sample"]
```

### The forward process

Add Gaussian noise on a fixed schedule:

$$
q(x_t \mid x_{t-1}) = N\big(\sqrt{1-\beta_t}\,x_{t-1},\; \beta_t I\big)
$$

The crucial algebraic fact, which is what makes training practical: **you can jump to any timestep in one step.** Define alpha\_t = 1 - beta\_t and alpha-bar\_t as the product of alpha\_s up to t. Then

$$
q(x_t\mid x_0) = N\big(\sqrt{\bar\alpha_t}\,x_0,\; (1-\bar\alpha_t)I\big) \quad\Longleftrightarrow\quad x_t = \sqrt{\bar\alpha_t}\,x_0 + \sqrt{1-\bar\alpha_t}\,\epsilon
$$

This follows from Chapter 3: a sum of independent Gaussians is Gaussian, and the variances accumulate exactly so that the total stays normalized. The consequence for training is decisive — **you never simulate the chain.** Sample a random t, jump straight to x\_t, and train. Without this the method would be hopeless.

Note the scaling: the coefficient on x\_0 shrinks while the noise coefficient grows, and they satisfy (alpha-bar) + (1 - alpha-bar) = 1, so the variance stays at 1 throughout. That is why x\_T is a clean standard Gaussian regardless of the data.

### The reverse process and the training objective

The reverse conditional q(x\_{t-1} | x\_t) is intractable, but **when additionally conditioned on x\_0 it is Gaussian with a closed form**, obtainable by Bayes' rule and completing the square (a Chapter 3 exercise in Gaussian algebra). So parameterize the learned reverse step as a Gaussian and fit its mean.

The objective is an ELBO exactly as in Chapter 5, with the latents being the whole noised sequence. Writing it out gives a sum of KL divergences between Gaussians — each computable in closed form by the formula in section 5.3. After simplification, and dropping weighting terms that were found to help empirically, the loss collapses to something startlingly simple:

$$
\mathcal{L} = \mathbb{E}_{t,\,x_0,\,\epsilon}\Big[\big\lVert \epsilon - \epsilon_\theta(x_t, t)\big\rVert^2\Big]
$$

**Predict the noise that was added, by squared error.** That is the entire training loop: sample an image, sample a timestep, sample noise, add it, and regress on the noise. The fact that a supervised regression descends from an ELBO is the single most useful thing to know here, and it is a common interview question.

### The score connection

The **score** of a distribution is the gradient of its log density with respect to the data (not the parameters — a different object from Chapter 4's score, and the clash of names is unfortunate). For the forward process,

$$
\nabla_{x_t}\log q(x_t\mid x_0) = -\frac{x_t - \sqrt{\bar\alpha_t}x_0}{1-\bar\alpha_t} = -\frac{\epsilon}{\sqrt{1-\bar\alpha_t}}
$$

**So predicting the noise is predicting the score, up to a known scale.** Denoising diffusion and score-based generative modelling are the same method in different notation, which is worth knowing because the literature uses both freely.

The score view also explains sampling: a Langevin step moves in the direction of increasing log density plus a noise kick, and the reverse diffusion step is a discretization of exactly that. In the continuous-time formulation the forward process is a stochastic differential equation and the reverse is another SDE requiring only the score — which is why an accompanying deterministic ODE (the probability-flow ODE) exists, and why **DDIM** can sample in far fewer steps by integrating that ODE with a coarser discretization.

### Why it works better than the alternatives

Compare with Chapter 5's divergence analysis. A GAN optimizes something JSD-like and suffers mode collapse and unstable adversarial dynamics. A VAE optimizes an ELBO with a single latent and produces blurry samples because a limited decoder plus a mass-covering objective forces hedging. Diffusion is also maximum-likelihood-flavoured and mass-covering, but it **breaks the generation problem into many small, easy steps**, each of which is a well-conditioned regression rather than a single leap from noise to image. There is no adversarial game, so training is stable. The cost is sampling: many network evaluations instead of one, which is why distillation and few-step samplers are an active area.

### Guidance

To condition on a prompt, the standard mechanism is **classifier-free guidance**: train the model both with and without the conditioning (dropping it randomly during training), then at sampling time extrapolate away from the unconditional prediction:

$$
\tilde\epsilon = \epsilon_\theta(x_t, \varnothing) + w\big[\epsilon_\theta(x_t, c) - \epsilon_\theta(x_t,\varnothing)\big]
$$

With w = 1 this is ordinary conditional sampling; w > 1 exaggerates the difference the condition makes. The trade is the familiar one: **higher guidance gives better prompt adherence and lower sample diversity**, which is the same sharpening-versus-coverage tension as temperature in a language model and as the KL weight in RLHF.

**Try it.** (a) Show that the one-step jump formula follows from composing two noising steps. (b) Why does predicting noise equal predicting the score? (c) Explain why diffusion avoids the mode collapse that GANs suffer, using Chapter 5's divergence language. Answers in 10.7.

## 10.2 Mixture of experts

### The decoupling

Chapter 7 established that a transformer's cost per token is about 2N FLOPs, where N is the parameter count. Mixture of experts breaks that link: **only a fraction of the parameters is used for any given token**, so you can grow capacity without growing per-token compute.

Replace the feedforward block with E separate expert feedforward blocks plus a **router** that selects k of them per token:

$$
y = \sum_{i \in \text{top-}k} g_i(x)\,E_i(x), \qquad g(x) = \operatorname{softmax}\big(W_r x\big)\ \text{restricted to the top } k
$$

With E = 64 experts and k = 2, the block holds 32 times the parameters of a dense block while doing twice the FLOPs. **Total parameters and active parameters become two different numbers**, and any claim about a model's size should say which one it means — a genuinely useful thing to ask about when reading a model card.

### Why it works

The premise is **specialization**: different tokens need different processing, and a dense network must use one set of weights for everything. Empirically the learned routing is less interpretable than "this expert handles code, that one handles French" — the specialization is real but often at the level of syntactic or positional features rather than human-legible topics, which is worth stating honestly rather than repeating the marketing version.

### The hard part: routing is discrete

The top-k selection is non-differentiable, which is Chapter 2's problem. The standard resolution is that **the gradient flows through the gate weights g\_i, not through the selection**. The chosen experts' gates are differentiable functions of the router logits, so the router learns from how useful its chosen experts turned out to be — a policy-gradient-flavoured signal delivered through a softmax weight.

### Load balancing

The failure mode that dominates practice. Routing is self-reinforcing: an expert that gets more tokens trains faster, becomes better, and is chosen more, while the rest starve. Left alone, most experts end up unused and you have paid for parameters you never train. **This is the same self-reinforcing collapse as premature policy convergence in Chapter 9**, and the remedies rhyme.

The standard fix is an **auxiliary load-balancing loss**. With f\_i the fraction of tokens routed to expert i and P\_i the mean router probability assigned to it:

$$
\mathcal{L}_{\text{aux}} = \alpha\,E\sum_{i=1}^{E} f_i\,P_i
$$

This is minimized when the load is uniform, and it is differentiable through P even though f is not. Typical alpha is around 0.01: large enough to balance, small enough not to dominate the real objective.

Other mechanisms worth knowing: a **capacity factor** caps how many tokens an expert may take per batch, with overflow tokens dropped or passed through the residual unchanged (dropping tokens is a real and slightly alarming implementation detail); **noisy routing** adds noise to the logits to encourage exploration; **expert choice** routing inverts the assignment so experts select tokens rather than the reverse, which balances by construction; and some recent designs use **shared experts** always active alongside routed ones, so common processing is not duplicated across specialists.

### The systems cost

MoE is a memory-and-communication trade, not a free lunch, and this is the part interviews probe.

- **All experts must be in memory**, even though only k are used per token. So MoE saves compute, not memory. A model with 8x the parameters needs 8x the weight storage.
- **Expert parallelism** places different experts on different devices, which means every MoE layer requires an **all-to-all** communication: tokens are dispatched to wherever their expert lives, then gathered back. This is the dominant cost in distributed MoE and is why interconnect bandwidth matters so much for these models.
- **Load imbalance becomes a stragglers problem** when experts are on separate devices: the slowest device sets the pace for the whole step.

So MoE is attractive when you are **compute-bound at training time and can afford the memory**, and less attractive for single-device inference where the full weight set must be resident anyway.

**Try it.** (a) A model has 64 experts with top-2 routing, feedforward dimension 4d, and otherwise standard blocks. What is the ratio of total to active parameters in an MoE layer? (b) Why can the router learn despite top-k being non-differentiable? (c) Why does MoE reduce FLOPs but not memory? Answers in 10.7.

## 10.3 Distributed training

### The problem

Chapter 7 computed that a 7-billion-parameter model needs about 112 GB of optimizer state alone, before activations. Anything larger does not fit on one device, and even when it fits you want more throughput. There are four ways to split the work, they are combined rather than chosen between, and knowing what each one costs in communication is the substance.

### Data parallelism

Replicate the model on every device, give each a different slice of the batch, and average the gradients.

- **Communication:** one all-reduce of the full gradient per step, so the volume is proportional to the parameter count and **independent of batch size**. This is why data parallelism scales well: doubling the batch doubles the compute but not the communication.
- **Memory:** every device holds a full copy of everything. This is the binding constraint.
- **The overlap trick worth knowing:** gradients for later layers are ready before the backward pass finishes, so you can start reducing them while still computing earlier ones. Bucketing gradients and overlapping communication with computation is standard and roughly hides the cost.

### ZeRO: sharding the redundancy

Data parallelism stores the same optimizer state on every device, which is pure waste. ZeRO removes it in three stages:

| Stage | Sharded across devices | Memory per device (of the 16 bytes/param) |
| --- | --- | --- |
| ZeRO-1 | optimizer state | 4 + 12/N |
| ZeRO-2 | plus gradients | 2 + 14/N |
| ZeRO-3 | plus parameters | 16/N |

ZeRO-3 (equivalently, fully sharded data parallelism) gives near-linear memory reduction in the number of devices. The cost is extra communication: parameters must be gathered before each layer's forward and backward and released afterwards, adding an all-gather per layer. Stages 1 and 2 are nearly free; stage 3 trades real bandwidth for memory.

### Tensor parallelism

Split individual matrices across devices. For a feedforward block, split the first weight matrix by **columns** and the second by **rows**; then each device computes a partial result and a single all-reduce at the end of the block combines them. The elegance is that the nonlinearity in between is elementwise, so no communication is needed there.

- **Communication:** proportional to **activations** (batch times sequence times hidden), and it happens twice per transformer block. This is a lot of traffic.
- **Therefore:** tensor parallelism is used **within a node**, across devices linked by high-bandwidth interconnect, and rarely across nodes.

### Pipeline parallelism

Assign different **layers** to different devices, so activations flow along the pipeline.

- **Communication:** only the activations at the stage boundaries, which is small — proportional to batch times sequence times hidden, once per boundary rather than per block.
- **The problem is the bubble.** With P stages, a naive schedule leaves each device idle for a fraction (P-1)/(M + P - 1) of the time, where M is the number of microbatches. With P = 4 and M = 4 that is 43% idle. **Splitting the batch into many microbatches is what shrinks the bubble**, and interleaved schedules shrink it further.

### Sequence and context parallelism

Split along the **sequence** dimension, which is the natural answer for long contexts where activation memory scales with T. Attention needs every position to see every other, so this requires communicating keys and values between devices; ring-style schemes pass them around in a rotation that overlaps with computation.

### Putting them together

The standard recipe for a large training run, sometimes called 3D (or 4D) parallelism:

```mermaid
flowchart TD
  A["Within a node:<br/>tensor parallel<br/>(high bandwidth needed)"]
  B["Across nodes:<br/>pipeline parallel<br/>(low bandwidth, watch the bubble)"]
  C["Across groups:<br/>data parallel + ZeRO<br/>(one all-reduce per step)"]
  D["For long context:<br/>sequence parallel"]
  A --> B --> C
  A --> D
```

The ordering is driven by communication volume: **put the chattiest partitioning where the bandwidth is highest.** That single principle explains the whole arrangement and is the right answer to "how would you shard a large model?"

### Two more memory levers

- **Gradient checkpointing** (Chapter 2) cuts activation memory from O(L) to O(sqrt L) for roughly one extra forward pass. It composes with every parallelism strategy above.
- **Gradient accumulation** simulates a larger batch by summing gradients over several microbatches before stepping. It costs nothing but time and is the standard way to reach a target batch size on limited memory. Note that it is exactly equivalent to the larger batch only if the loss normalization is handled correctly — dividing by the total number of examples, not per microbatch.

**Try it.** (a) For a 70-billion-parameter model in mixed precision with Adam, how much memory per device under ZeRO-3 with 64 devices, versus plain data parallelism? (b) Why is tensor parallelism confined within a node? (c) With 8 pipeline stages, how many microbatches do you need to keep the bubble below 10%? Answers in 10.7.

## 10.4 Statistical learning theory

### The question

You minimize training error. You care about test error. **What licenses the leap?** Chapter 3 gave the skeleton with Hoeffding plus a union bound; this section fills it in properly.

### The setup

True risk and empirical risk:

$$
R(h) = \mathbb{E}_{(x,y)\sim D}\big[\ell(h(x),y)\big], \qquad \hat{R}(h) = \frac{1}{n}\sum_{i=1}^{n}\ell(h(x_i),y_i)
$$

For a **fixed** h, Hoeffding says the two are within about sqrt(log(1/delta)/2n). The difficulty is that you did not fix h — you **chose** it by looking at the data, so the empirical risk of the chosen hypothesis is biased downward. Everything in learning theory is machinery for handling that selection.

### Finite classes, and why the bound generalizes

With |H| hypotheses, a union bound over all of them gives, with probability 1 - delta and simultaneously for every h:

$$
R(h) \le \hat{R}(h) + \sqrt{\frac{\log|H| + \log(2/\delta)}{2n}}
$$

**Generalization gap grows as the square root of complexity over sample size.** For infinite classes, log|H| must be replaced by something finite, and there are two standard replacements.

### VC dimension

A class **shatters** a set of points if it can realize every one of the 2^m labellings. The **VC dimension** is the size of the largest set it can shatter.

| Class | VC dimension |
| --- | --- |
| thresholds on the line | 1 |
| intervals on the line | 2 |
| linear separators in R^d | d + 1 |
| axis-aligned rectangles in R^2 | 4 |
| sine curves sin(wx) with w free | **infinite** |

That last row is the instructive one: a single real parameter gives infinite VC dimension, so **parameter count and capacity are not the same thing** — a point that matters enormously for the deep learning discussion below.

**Sauer's lemma** is the key technical step: a class of VC dimension d can produce at most O(m^d) labellings of m points, a polynomial rather than the 2^m it would need to shatter them. Substituting that growth function for |H| gives

$$
R(h) \;\le\; \hat{R}(h) + O\!\left(\sqrt{\frac{d_{VC}\log(n/d_{VC}) + \log(1/\delta)}{n}}\right)
$$

So learning is possible with roughly **n proportional to VC dimension** samples — the fundamental sample-complexity statement of classical learning theory.

### Rademacher complexity

VC dimension ignores the data distribution and the loss's scale, both of which matter. Rademacher complexity fixes this by asking: **how well can this class fit pure noise?**

$$
\hat{\mathfrak{R}}_S(H) = \mathbb{E}_{\sigma}\left[\sup_{h\in H}\frac{1}{n}\sum_{i=1}^{n}\sigma_i h(x_i)\right], \qquad \sigma_i = \pm 1 \text{ with equal probability}
$$

If the class can match random signs perfectly the supremum is 1; if it cannot fit noise at all it is near 0. The resulting bound has the same shape with Rademacher complexity in place of the square-root complexity term, and it is **data-dependent and computable in principle**, which VC dimension is not.

### Margin bounds, and why they matter here

The refinement that partially rescues the theory for modern models. For a linear classifier, the bound can be stated in terms of the **margin** and the **norm** of the weights rather than the dimension:

$$
R(h) \lesssim \hat{R}_{\gamma}(h) + O\!\left(\frac{\lVert w\rVert\,R_X}{\gamma\sqrt{n}}\right)
$$

where R-hat-gamma counts points classified correctly by less than margin gamma. **The dimension has disappeared.** A large-margin, small-norm classifier generalizes well even in very high dimension, which is the theoretical justification for SVMs and, more importantly here, the template for norm-based bounds on neural networks.

### Where this leaves deep learning

Be accurate about this, because it is a place where a confident wrong answer is common.

The classical bounds are **vacuous** for modern networks: a model with more parameters than training points has a capacity term that makes the bound exceed 1, which asserts nothing. The demonstration that settled the matter is that deep networks can fit **randomly labelled** training data perfectly — so their capacity genuinely is enormous by any counting measure — while still generalizing well on real labels. Uniform convergence over the full hypothesis class therefore cannot be the explanation.

The candidate explanations, none yet decisive:

- **Implicit regularization** from the optimizer: gradient descent finds a minimum-norm-like solution among the many that interpolate (Chapter 1's pseudoinverse result is the clean provable case).
- **Norm-based and margin-based bounds** that depend on the learned weights rather than the parameter count, which can be non-vacuous for some trained networks.
- **Algorithmic stability**: if swapping one training example barely changes the output, training error tracks test error (Chapter 3's McDiarmid argument).
- **PAC-Bayes bounds**, which have produced some of the few non-vacuous guarantees for real networks, by measuring complexity relative to a prior over parameters.
- **Data-dependent arguments** appealing to the structure of real data (the manifold hypothesis) rather than to worst-case classes.

The honest summary: **classical learning theory correctly describes when learning is guaranteed, and modern deep learning operates outside those guarantees while working anyway.** That gap is one of the genuinely open problems in the field, and saying so is better calibrated than either dismissing the theory or overclaiming its reach.

**Try it.** (a) What is the VC dimension of linear separators in R^10, and how many samples does the bound suggest for a gap of 0.1? (b) Why does a one-parameter sine family have infinite VC dimension, and what does that show? (c) Why did fitting random labels change how people think about generalization? Answers in 10.7.

## 10.5 Kernels and Gaussian processes

### The kernel trick, completed

Chapter 6 showed that the SVM dual depends on the data only through inner products. The kernel trick is the observation that follows: **replace every inner product with a function K(x, x') that computes an inner product in some other space, without ever visiting that space.**

$$
K(x,x') = \langle \phi(x), \phi(x')\rangle
$$

The polynomial kernel (1 + x'x')^2 in two dimensions corresponds to a six-dimensional feature map you could write down; the **Gaussian (RBF) kernel**

$$
K(x,x') = \exp\!\left(-\frac{\lVert x - x'\rVert^2}{2\sigma^2}\right)
$$

corresponds to an **infinite-dimensional** feature map. You could never compute phi explicitly, and you never need to.

### Mercer's condition

Which functions are valid kernels? Exactly those for which **the Gram matrix K with entries K(x\_i, x\_j) is positive semidefinite for every finite set of points.** This is Chapter 1's PSD condition doing load-bearing work: a PSD matrix is one of the form B'B, and that factorization is precisely the existence of a feature map.

This also gives you a construction kit. Kernels are closed under nonnegative sums, products (the Schur product theorem from Chapter 4's problem set), scaling by a positive constant, and composition with a feature map. So you can build valid kernels without ever exhibiting phi.

### The representer theorem

Why any of this is usable. For a regularized objective over a function in the kernel's space,

$$
\min_f \; \sum_i \ell\big(f(x_i), y_i\big) + \lambda\lVert f\rVert^2_{\mathcal{H}}
$$

the minimizer always has the form f(x) = sum of alpha\_i K(x\_i, x). **An infinite-dimensional optimization collapses to n coefficients.** That is the theorem that makes kernel methods finite, and it is worth knowing by name.

The cost is the flip side: those n coefficients require an n-by-n Gram matrix, so kernel methods are O(n^2) in memory and O(n^3) to solve exactly. **Kernels are elegant and do not scale**, which in one sentence is why deep learning displaced them for large datasets. Approximations exist (random Fourier features, Nystrom) and are essentially low-rank approximations of the Gram matrix — Chapter 1 again.

### Gaussian processes

A GP is a distribution over **functions**, defined so that any finite set of function values is jointly Gaussian:

$$
f \sim \mathcal{GP}\big(m(x),\, K(x,x')\big)
$$

The kernel is the covariance function: K(x, x') says how correlated f(x) and f(x') are, so it encodes your assumptions about smoothness, periodicity and length scale.

**Everything about GPs is Chapter 3, section 3.5.** Because all finite marginals are Gaussian, prediction is just Gaussian conditioning, and you can write the answer immediately:

$$
\mu_* = K_{*}^{\top}(K + \sigma^2 I)^{-1}y, \qquad \Sigma_* = K_{**} - K_*^{\top}(K+\sigma^2 I)^{-1}K_*
$$

Those are exactly the conditional mean and covariance formulas from section 3.5 with the blocks filled in. Three observations that follow directly:

- **The mean is linear in the observations**, which is why GP regression is a kernel method: it is a weighted combination of the training targets.
- **The predictive variance does not depend on the observed y values at all** — only on where you sampled. That is the Gaussian's unique property from Chapter 3, and it is the basis of **Bayesian optimization**: you can compute how much uncertainty a candidate measurement would remove *before* taking it, which is what acquisition functions exploit.
- **Marginalization is free**, so a GP over infinitely many inputs is manageable because you only ever handle the finite subset you touched.

### The connection to neural networks

Worth knowing because it comes up in research contexts. A single-layer network with random weights and infinite width converges to a Gaussian process, by the CLT applied over the hidden units. More recently, the **neural tangent kernel** shows that an infinitely wide network trained by gradient descent evolves as a *linear* model in a fixed kernel determined by the architecture and initialization. So infinite-width networks are kernel machines.

State the limitation alongside it: the NTK regime is a **lazy** regime in which features do not change during training, whereas the empirical advantage of real networks appears to come precisely from **learning features**. The NTK is therefore an illuminating solvable limit rather than a complete theory of why finite networks work, and finite networks generally outperform their NTK counterparts.

### When to use kernels today

Genuinely: small data (up to a few thousand points), where uncertainty estimates matter, where the input has structure a hand-designed kernel captures, and in Bayesian optimization for expensive black-box tuning. Not: large datasets, raw high-dimensional inputs like images or text, where learned representations win decisively.

**Try it.** (a) Show that K(x,x') = (x'x')^2 is a valid kernel in R^2 by exhibiting the feature map. (b) Why does GP predictive variance not depend on the observed targets, and what does that enable? (c) Why are kernel methods O(n^3), and what does that imply about their use? Answers in 10.7.

## 10.6 Interview drill set

**1. What does a diffusion model actually train on?** Sample a data point, a random timestep, and Gaussian noise; form the noised input using the one-step jump formula; regress the network's output on the noise that was added, with squared error. It is supervised regression, and it descends from an ELBO.

**2. Why can you jump to any timestep in one step?** Because composing Gaussian noising steps gives another Gaussian, with the accumulated coefficients working out so that x\_t equals sqrt(alpha-bar\_t) x\_0 plus sqrt(1 - alpha-bar\_t) times noise. Without that identity you would have to simulate the chain and training would be impractical.

**3. What is the relationship between denoising and score matching?** The score of the forward process is the negative added noise divided by its standard deviation, so predicting the noise is predicting the score up to a known scale. Denoising diffusion and score-based generative models are the same method in different notation.

**4. Why do diffusion models avoid mode collapse?** They optimize a likelihood-flavoured, mass-covering objective rather than an adversarial one, and they decompose generation into many small well-conditioned regressions instead of one leap. There is no minimax game to destabilize and no reverse-KL pressure to drop modes.

**5. What does classifier-free guidance trade?** Prompt adherence against diversity. Extrapolating away from the unconditional prediction sharpens conditioning at the cost of sample variety — the same tension as sampling temperature and as the RLHF KL weight.

**6. What does mixture of experts decouple?** Total parameters from per-token FLOPs. Only k of E experts run per token, so capacity grows without proportional compute. Always ask whether a quoted parameter count is total or active.

**7. How does the router learn if top-k is not differentiable?** Gradients flow through the gating weights of the selected experts, not through the selection itself. The router is updated according to how useful its chosen experts proved.

**8. Why is load balancing necessary?** Routing is self-reinforcing: a favoured expert improves and is favoured more while others starve. An auxiliary loss proportional to the product of load fraction and mean router probability is minimized at uniform load, and typically weighted around 0.01.

**9. Does MoE save memory?** No. All experts must be resident even though only k run per token, so it saves compute, not memory. It also adds an all-to-all communication per MoE layer under expert parallelism.

**10. Rank the parallelism strategies by communication volume.** Pipeline is cheapest (activations at stage boundaries only), then data parallel (one all-reduce of gradients per step, independent of batch size), then tensor parallel (activations, twice per block). Hence tensor parallel within a node, pipeline and data parallel across nodes.

**11. What do the ZeRO stages shard?** Stage 1 the optimizer state, stage 2 also the gradients, stage 3 also the parameters. Per-device memory goes from 16 bytes per parameter toward 16/N. Stage 3 costs extra all-gathers per layer.

**12. What is the pipeline bubble and how do you shrink it?** Idle time while the pipeline fills and drains, a fraction (P-1)/(M+P-1) with P stages and M microbatches. More microbatches shrink it; interleaved schedules shrink it further.

**13. Why is tensor parallelism kept within a node?** Its communication scales with activations and happens twice per transformer block, so it needs the highest available interconnect bandwidth. Crossing node boundaries with it is usually a bad trade.

**14. What does VC dimension measure, and give a surprising example.** The largest number of points the class can shatter, meaning realize all 2^m labellings. The family sin(wx) with one real parameter has infinite VC dimension, which shows parameter count and capacity are not the same thing.

**15. State the classical generalization bound and its shape.** With high probability, true risk is at most empirical risk plus a term of order the square root of (complexity plus log(1/delta)) over n. Complexity is log|H| for finite classes and VC dimension or Rademacher complexity otherwise.

**16. Why is Rademacher complexity preferable to VC dimension?** It is data-dependent and measures how well the class fits random signs on your actual sample, rather than a worst-case combinatorial quantity, so it can be far tighter and is computable in principle.

**17. What did fitting random labels demonstrate?** That deep networks have enough capacity to memorize arbitrary labellings, so uniform-convergence bounds over the full hypothesis class are vacuous and cannot explain why they generalize on real data.

**18. What are the candidate explanations for deep generalization?** Implicit regularization from the optimizer, norm- and margin-based bounds that depend on the learned weights rather than parameter count, algorithmic stability, PAC-Bayes bounds, and data-dependent arguments. None is decisive; this is an open problem.

**19. What makes a function a valid kernel?** Its Gram matrix must be positive semidefinite on every finite set of points. That is equivalent to the existence of a feature map, because a PSD matrix factors as B transpose B.

**20. What is the representer theorem and why does it matter?** The minimizer of a kernel-regularized objective is a finite combination of kernels centred at the training points. An infinite-dimensional problem collapses to n coefficients, which is what makes kernel methods computable.

**21. Why don't kernel methods scale?** The Gram matrix is n-by-n, so memory is quadratic and exact solution is cubic in the number of training points. Random features and Nystrom are low-rank approximations that partially recover scalability.

**22. Why is GP predictive variance independent of the observed values?** It is the Schur complement in the Gaussian conditioning formula, which involves only the covariance blocks, never the observations. This is the Gaussian's unique property and is what makes Bayesian optimization possible: you can evaluate how informative a candidate point would be before measuring it.

**23. What is the neural tangent kernel, and what is its limitation?** In the infinite-width limit, gradient descent makes the network evolve as a linear model in a fixed kernel set by architecture and initialization. The limitation is that this is a lazy regime where features do not change, whereas the practical advantage of finite networks appears to come from learning features.

## 10.7 Assignment, solutions, and a study plan

### Solutions to the in-text exercises

**10.1.** (a) Compose two steps: x\_t = sqrt(alpha\_t) x\_{t-1} + sqrt(1-alpha\_t) e\_1 and x\_{t-1} = sqrt(alpha\_{t-1}) x\_{t-2} + sqrt(1-alpha\_{t-1}) e\_2. Substituting gives x\_t = sqrt(alpha\_t alpha\_{t-1}) x\_{t-2} plus a sum of two independent Gaussian terms with variances alpha\_t(1 - alpha\_{t-1}) and (1 - alpha\_t). Those add to 1 - alpha\_t alpha\_{t-1}, so the pair collapses to a single Gaussian of that variance. Inducting gives the alpha-bar formula. **The variances conspire to keep the total at 1 minus the product**, which is the whole reason the shortcut exists. (b) The score is the gradient of log q(x\_t | x\_0), a Gaussian with mean sqrt(alpha-bar) x\_0 and variance 1 - alpha-bar. The gradient of a Gaussian log density is minus (x - mean)/variance, and x\_t - mean is exactly sqrt(1 - alpha-bar) times the noise, so the score is minus the noise divided by sqrt(1 - alpha-bar). Predicting one is predicting the other up to that known constant. (c) Mode collapse is characteristic of mode-seeking objectives, which punish placing mass where data has none but not missing modes entirely. Diffusion's objective descends from an ELBO, hence from a forward-KL-flavoured likelihood, which is mass-covering and punishes missing data heavily. It also has no adversarial minimax structure, so the training dynamics that let a GAN's generator and discriminator chase each other into a corner are simply absent.

**10.2.** (a) An MoE layer with E = 64 and k = 2 holds 64 expert feedforward blocks, of which 2 run. Each block has 8d^2 parameters, so total is 512d^2 and active is 16d^2 — a ratio of **32 to 1**. Adding the unchanged attention block (4d^2, always active) gives a layer that is 516d^2 total and 20d^2 active, about 26 to 1. (b) Because the gradient does not need to flow through the discrete argmax. The selected experts' gate values g\_i are smooth functions of the router logits, and they multiply the expert outputs, so raising a gate that led to a useful output reduces the loss and the router learns from that. The selection is a hard decision; the weighting is soft, and the soft part carries the learning signal. (c) Because compute is per-token and memory is not. Only k experts process a given token, so FLOPs scale with k; but all E experts must be stored, because the next token may route anywhere. Memory scales with E.

**10.3.** (a) Plain data parallelism: 70e9 times 16 bytes = 1,120 GB **per device**, which is impossible. ZeRO-3 with 64 devices: 1,120/64 = **17.5 GB per device** for states, which fits comfortably and leaves room for activations. That reduction is the entire reason large-model training is feasible on commodity accelerator counts. (b) Because its communication volume is proportional to activations and occurs twice per transformer block, so it is the most bandwidth-hungry strategy by a wide margin. Nodes are connected by interconnects an order of magnitude slower than within-node links, so crossing that boundary with tensor parallelism makes communication the bottleneck. (c) The bubble fraction is (P-1)/(M+P-1) = 7/(M+7). Setting that below 0.1 gives M + 7 > 70, so **M > 63 microbatches**. That is a demanding requirement, and it explains why pipeline parallelism needs large global batch sizes to be efficient.

**10.4.** (a) VC dimension of linear separators in R^10 is d + 1 = **11**. The bound's complexity term is roughly sqrt(d\_VC log(n/d\_VC)/n); setting that to 0.1 and solving gives n of order 10,000 to 15,000 depending on the constants and the log factor. The right takeaway is the scaling, not the exact number: **you need roughly the VC dimension times a factor of a thousand for a gap of 0.1**, since the bound goes as 1/sqrt(n). (b) Because sin(wx) with w free can, by choosing w enormous, oscillate fast enough to produce any labelling of any finite set of distinct points — you can always find a frequency that puts the curve above zero at the points you want positive and below at the others. So it shatters sets of every size. It shows that a single continuous parameter can carry unlimited capacity, and therefore that **counting parameters tells you nothing reliable about generalization**, which is precisely the lesson that returns for deep networks. (c) Because it separated capacity from generalization empirically. If a network can memorize random labels, its hypothesis class is large enough that no uniform bound over that class can be non-vacuous; yet the same architecture, same optimizer and same training procedure generalize well on real labels. So the explanation cannot live in the hypothesis class alone — it must involve the data, the optimizer, or both.

**10.5.** (a) In R^2, the square of the inner product expands as (x\_1 y\_1 + x\_2 y\_2)^2 = x\_1^2 y\_1^2 + 2 x\_1 x\_2 y\_1 y\_2 + x\_2^2 y\_2^2, which is exactly the inner product of the feature vectors phi(x) = (x\_1^2, sqrt2 x\_1 x\_2, x\_2^2) and phi(y). Since it is an explicit inner product of feature vectors, every Gram matrix is of the form B transpose B and therefore PSD, so it is a valid kernel. (b) Because the predictive covariance is a Schur complement built only from covariance blocks and the noise level — the observed targets y appear in the mean formula and nowhere in the covariance formula. This is the Gaussian's peculiar property from Chapter 3, section 3.5, and it is what makes Bayesian optimization work: an acquisition function can evaluate how much uncertainty a candidate point would remove before you spend anything measuring it. (c) Because the representer theorem makes the solution a combination of n kernel evaluations, requiring an n-by-n Gram matrix; solving that linear system exactly is cubic in n. The implication: exact kernel methods are practical up to a few thousand points and require low-rank approximations such as random Fourier features or Nystrom beyond that, which is a large part of why they lost ground to methods whose per-step cost is linear in the data.

### Problem set

**P1 (diffusion).** Derive q(x\_{t-1} | x\_t, x\_0) by Bayes' rule and completing the square, and identify its mean and variance. Then explain why conditioning on x\_0 makes it tractable when the unconditioned reverse is not.

**P2 (diffusion, coding).** Implement DDPM on two-dimensional toy data (two moons or a spiral). Train the noise-prediction network, then sample and plot the trajectory from noise to data. Vary the number of sampling steps and observe the quality trade.

**P3 (MoE).** A model has 32 layers, d = 4096, 8 experts with top-2 routing, feedforward dimension 4d. Compute total and active parameters, and the training FLOPs per token. Compare with a dense model of the same active parameter count and of the same total.

**P4 (MoE).** Show that the load-balancing loss is minimized at uniform routing. Then explain what goes wrong if you weight it far too heavily.

**P5 (distributed).** You have 128 devices with 80 GB each and want to train a 175-billion-parameter model. Work out a parallelism configuration, stating the memory per device and which communication pattern dominates.

**P6 (learning theory).** Prove the finite-class generalization bound from Hoeffding plus a union bound, and state precisely where the union bound is needed and what goes wrong without it.

**P7 (learning theory).** Compute the VC dimension of axis-aligned rectangles in R^2 by exhibiting a shattered set of size 4 and proving no set of size 5 can be shattered.

**P8 (kernels).** Prove that the sum and the product of two valid kernels are valid kernels. For the product, say which theorem you are invoking.

**P9 (GP, coding).** Implement GP regression with an RBF kernel on a one-dimensional function with five observations. Plot the posterior mean and a two-standard-deviation band. Vary the length scale and the noise level and describe the effect on each.

**P10 (synthesis).** Explain in one paragraph why these are all instances of ideas from earlier chapters: the diffusion training loss; the MoE load-balancing loss; ZeRO's memory arithmetic; the margin bound; and GP predictive variance.

### Selected solutions

**P1.** By Bayes, q(x\_{t-1}|x\_t, x\_0) is proportional to q(x\_t|x\_{t-1}) times q(x\_{t-1}|x\_0), both of which are known Gaussians. A product of two Gaussian densities in the same variable is an unnormalized Gaussian whose precision is the sum of the precisions and whose mean is the precision-weighted average — exactly the result from Chapter 3, section 3.5. Carrying out that algebra gives a Gaussian with variance beta-tilde\_t = beta\_t(1 - alpha-bar\_{t-1})/(1 - alpha-bar\_t) and a mean that is a specific linear combination of x\_t and x\_0. **Conditioning on x\_0 is what makes it tractable** because without it you would need q(x\_{t-1}), the marginal of the data distribution after t-1 noising steps, which involves an integral over the unknown data distribution. Knowing x\_0 replaces that intractable marginal with a known Gaussian.

**P3.** Per layer: attention 4d^2 = 67.1M; one expert 8d^2 = 134.2M; 8 experts = 1.07B. Total per layer = 1.14B; active per layer = 67.1M + 2(134.2M) = 335.5M. Over 32 layers: **total 36.5B, active 10.7B**. Training FLOPs per token use the active count: 6 times 10.7e9 = 6.4e10. Compare: a dense model with 10.7B parameters costs the same FLOPs but has one third the capacity; a dense model with 36.5B parameters has the same capacity but costs 3.4 times the FLOPs. **That ratio is the entire value proposition, and the price is holding 36.5B parameters in memory while only paying compute for 10.7B.**

**P5.** A workable configuration: **tensor parallel 8** within each node, **pipeline parallel 8** across nodes, **data parallel 2** with ZeRO-1 across the remaining dimension (8 times 8 times 2 = 128). Memory: 175e9 times 16 = 2,800 GB of states in total. Tensor parallelism divides parameters and their optimizer state by 8, pipeline by a further 8, so per device 2,800/64 = 43.75 GB, leaving roughly 36 GB for activations — which will require gradient checkpointing at any reasonable batch size. **The dominant communication is tensor-parallel all-reduces** (twice per block, on activations), which is why those groups must be within a node; pipeline sends only boundary activations, and the data-parallel all-reduce happens once per step.

**P7.** Axis-aligned rectangles in R^2 have VC dimension 4. **Shattering 4 points:** place them at the four compass extremes — topmost, bottommost, leftmost, rightmost, arranged as a diamond. For any subset, take the smallest rectangle containing exactly those points; because each point is extreme in its own direction, that rectangle excludes the others. All 16 labellings are achievable. **No set of 5 can be shattered:** given any 5 points, consider the topmost, bottommost, leftmost and rightmost (breaking ties arbitrarily); that is at most 4 points, so at least one point remains, and it lies within the bounding box of the others. Label the four extremes positive and the interior point negative: any rectangle containing all four extremes contains their bounding box, hence contains the fifth point too. That labelling is unachievable, so no 5-point set is shattered.

**P10.** Every one is an earlier chapter's tool in new clothing. **The diffusion loss** is an ELBO (Chapter 5) that simplifies to a squared-error regression because every KL in it is between Gaussians with the closed form of section 5.3, and predicting noise equals predicting a score. **The MoE load-balancing loss** addresses the same self-reinforcing collapse that entropy regularization prevents in policy gradients (Chapter 9), and it is minimized at the maximum-entropy routing distribution (Chapter 5). **ZeRO's arithmetic** is nothing but Chapter 7's 16-bytes-per-parameter accounting, with each term divided by the number of devices that shard it. **The margin bound** is Chapter 3's concentration machinery combined with the observation from Chapter 1 that what controls a linear map's behaviour is its norm and not its dimension. And **GP predictive variance** is literally the Gaussian conditioning formula of section 3.5, whose independence from the observed values is the same surprising property noted there. Ten chapters, and the tools have not multiplied — they have been reapplied.

### A study plan for the whole tutorial

If you are working through this alone, the sequence below is the one that builds correctly. Timings assume serious part-time study; halve them if you are full-time.

| Weeks | Chapters | Gate before moving on |
| --- | --- | --- |
| 1-2 | 1, 2 | Derive backprop for an MLP on paper and implement it in numpy with gradient checking passing |
| 3-4 | 3, 4 | Write the multivariate Gaussian conditioning formula from memory; derive MLE for a Gaussian and explain the n-versus-(n-1) issue |
| 5 | 5 | Explain forward versus reverse KL and predict what each does to a model fit to bimodal data |
| 6-7 | 6, 7 | Explain the maximum stable learning rate, and derive He initialization and the sqrt(d\_k) scaling unprompted |
| 8-9 | 8, 9 | Derive the policy gradient theorem and the DPO loss without looking |
| 10 | 10 | Explain the diffusion objective and sketch a parallelism plan for a named model size |

**How to use the drills.** Do not read them as prose. Cover the answers, ask the question aloud, answer aloud in full sentences, and only then check. Mark any question you could not answer cleanly and return to the *derivation* in the chapter, not to the drill's answer. The drills test whether you have understood; the derivations are where understanding comes from. A question you can answer by recognition but not by reconstruction is a question you will fail under pressure.

**How to use the problem sets.** Attempt everything before reading any solution, including the ones you think you can see through — the coding problems in particular teach things that reading cannot, and P8 in Chapter 8 (Baird's counterexample) and P2 in Chapter 7 (variance propagation) are worth doing for real rather than imagining.

**The six ideas to carry.** The SVD; the chain rule as a product of Jacobians; the conditional expectation; the score identity; KL divergence; and variance reduction by control variates. If you can state each one and name three places it appears across these ten chapters, you have what this was for.
