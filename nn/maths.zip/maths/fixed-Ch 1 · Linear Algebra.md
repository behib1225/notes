﻿# Chapter 1 · Linear Algebra for Machine Learning

2026-09-22 · @Behi

Almost every object in machine learning is a matrix, and almost every layer is a linear map followed by a nonlinearity — so linear algebra is not a prerequisite you pass through, it is the notation you will think in for the rest of your career. This chapter builds that picture from vectors up to the singular value decomposition, which is the single most useful theorem in applied linear algebra and the one interviews return to most often.

Read it with a pen. Every section ends with something to try, and the last two sections are a drill set and a full assignment with solutions — do them before you look.

## 1.1 Vectors and matrices as ML objects

A vector in ML is almost never an arrow in 3D space. It is a list of numbers describing one thing: one image, one sentence, one customer, one token. A matrix is almost never an abstract operator either. It is either a stack of such things, or a machine that turns one kind of thing into another.

Getting this reading reflexive is worth more than any single theorem in this chapter, because it lets you look at an unfamiliar equation in a paper and immediately ask the right question: what shape is this, and what does each axis mean?

### The two roles a matrix plays

**Role 1: a matrix is data.** The design matrix X holds n examples, each with d features, one example per row.

$$
X = \begin{bmatrix} \text{---} & x_1^{\top} & \text{---} \\ \text{---} & x_2^{\top} & \text{---} \\ & \vdots & \\ \text{---} & x_n^{\top} & \text{---} \end{bmatrix} \in \mathbb{R}^{n \times d}
$$

Each x\_i is a column vector in R^d, so x\_i transpose is a row. Row i is example i; column j is feature j measured across the whole dataset. Those are two completely different objects living in the same array, and confusing them is the most common source of shape bugs.

**Role 2: a matrix is a function.** A weight matrix W of shape (out x in) is a linear map: hand it a vector in R^in and it returns a vector in R^out. A neural network layer is exactly this, plus a bias and a nonlinearity.

$$
h = \sigma(Wx + b), \qquad W \in \mathbb{R}^{d_{\text{out}} \times d_{\text{in}}}, \quad x \in \mathbb{R}^{d_{\text{in}}}, \quad b \in \mathbb{R}^{d_{\text{out}}}
$$

Linear algebra as a subject is the study of Role 2. The reason it dominates ML is that Role 1 objects are the things Role 2 objects act on.

### The convention fight, and how to survive it

Textbooks write Wx with x as a column. Frameworks store a batch as rows and write XW. Both appear constantly, often in the same paper.

| Style | Data layout | Layer written as | Weight shape |
| --- | --- | --- | --- |
| Math / textbook | x is a column in R^d | Wx + b | out x in |
| Framework / batched | X is (batch x d), one example per row | XW + b | in x out, b broadcast over rows |

The rule that saves you: never reason about a formula until you have annotated every symbol with its shape. Do it in the margin. If the shapes compose, the formula is probably right; if they do not, no amount of algebra will rescue it. In an interview, saying "let me fix the shapes first" reads as competence, not hesitation.

One convention to fix now, because it decides the shape of every gradient later: a plain lowercase letter such as x is a **column** vector, and x transpose is a row. So x'y is a scalar (the inner product) while xy' is a d x d matrix (the outer product). Those two expressions differ only in where a superscript sits, and they are not remotely the same object.

### The four products you must read instantly

$$
\underbrace{x^{\top} y = \sum_{i=1}^{d} x_i y_i}_{\text{inner product, a scalar}} \qquad \underbrace{(x y^{\top})_{ij} = x_i y_j}_{\text{outer product, a rank-1 matrix}}
$$

$$
\underbrace{(Ax)_i = \sum_{j} A_{ij} x_j}_{\text{matrix-vector}} \qquad \underbrace{(AB)_{ij} = \sum_{k} A_{ik} B_{kj}}_{\text{matrix-matrix}}
$$

The index definitions are the least useful way to understand these. The readings that actually help are:

- **Ax is a linear combination of the columns of A**, with the entries of x as the coefficients. If A has columns a\_1 through a\_d, then Ax = x\_1 a\_1 + ... + x\_d a\_d. This is the most important sentence in the chapter; rank, column space and solvability all fall out of it.
- **x'A is a linear combination of the rows of A.** Same statement, other side.
- **AB, column by column:** column j of AB equals A times column j of B. B's columns get pushed through the map A one at a time.
- **AB as a sum of outer products:** AB = sum over k of (column k of A) times (row k of B). This view makes low-rank approximation and the SVD feel obvious later, so do not skip it.

### Why this matters right now

1. **A linear layer's expressiveness is bounded by the rank of its matrix.** A 4096 x 4096 weight matrix of rank 8 can only produce outputs inside an 8-dimensional subspace, whatever you feed it. That observation is exactly what LoRA exploits.
2. **An embedding table** is a matrix of shape (vocab x d). Looking up a token means multiplying by a one-hot vector, which by the combination-of-rows rule selects one row. Embedding lookup is matrix multiplication, which is why it has a clean gradient.
3. **Attention** computes QK', a matrix of all pairwise inner products between queries and keys. It is a single matrix product because inner products measure alignment, the subject of section 1.4.

**Try it.** Let A be 3 x 2 and B be 2 x 4. Without computing anything: what shape is AB, what is the largest rank AB could have, and could AB ever have rank 3? (Answers: 3 x 4; at most 2; no. Section 1.2 says why.)

## 1.2 Linear maps, span, basis, and rank

Rank is the single most useful number attached to a matrix, and most students leave a first linear algebra course able to compute it but unable to say what it means. The one-sentence answer: **rank is the number of genuinely independent directions the matrix can produce.** Everything below is an unpacking of that sentence.

### Linear maps

A function T from R^n to R^m is **linear** if it respects addition and scaling:

$$
T(u + v) = T(u) + T(v), \qquad T(\alpha u) = \alpha\, T(u) \quad \text{for all } u, v \in \mathbb{R}^n,\ \alpha \in \mathbb{R}
$$

Two consequences worth internalizing. First, every linear map sends the origin to the origin, so an affine layer x maps to Wx + b is **not** linear once b is nonzero (it is affine). Second, a linear map is completely determined by what it does to a basis: if you know T(e\_1) through T(e\_n), you know T everywhere, because any x is a combination of the e\_j and you can push the combination through. Stack those images as columns and you get the matrix of T. **Every linear map from R^n to R^m is a matrix, and every matrix is a linear map.** They are the same thing seen from two sides.

This is also why linear models are limited and why we add nonlinearities: a composition of linear maps is linear, so stacking affine layers without activations collapses to a single affine layer. W\_3 W\_2 W\_1 x + (stuff) is just W x + c. Depth buys nothing at all without a nonlinearity. That is a standard interview question and the answer is one line: composition of linear maps is linear.

### Span, linear independence, basis

- The **span** of a set of vectors is the set of all their linear combinations. Geometrically it is the flat subspace through the origin that they sweep out: a line, a plane, a hyperplane, or all of R^n.
- Vectors are **linearly independent** when the only combination equal to zero is the all-zeros combination. Equivalently, no vector in the set lies in the span of the others, so none is redundant.
- A **basis** of a subspace is an independent set that spans it. Every basis of a given subspace has the same number of vectors, and that number is the **dimension**.

The intuition to carry: a spanning set is big enough, an independent set is small enough, and a basis is exactly right. Coordinates are only meaningful relative to a basis, and choosing a good basis is what PCA, Fourier analysis and the SVD all do.

### Rank, four equivalent definitions

For A in R^{m x n}, all of the following are the same number:

1. The dimension of the **column space** of A, that is the span of A's columns. By the "Ax is a combination of columns" rule, the column space is exactly the set of achievable outputs.
2. The dimension of the **row space** of A, the span of A's rows.
3. The number of nonzero **singular values** of A (section 1.8). This is the definition that is numerically meaningful.
4. The smallest r such that A can be written as a sum of r rank-1 outer products, or equivalently as A = BC with B of shape (m x r) and C of shape (r x n).

That 1 and 2 agree is a genuinely surprising theorem, usually stated as **row rank equals column rank**. It says that the number of independent examples in your data matrix equals the number of independent features, which is not obvious at all. Definition 4 is the one that matters most in deep learning: it is the factorized, parameter-efficient view.

**Consequences you should be able to produce on demand:**

$$
\operatorname{rank}(A) \le \min(m, n), \qquad \operatorname{rank}(AB) \le \min\big(\operatorname{rank}(A), \operatorname{rank}(B)\big)
$$

$$
\operatorname{rank}(A + B) \le \operatorname{rank}(A) + \operatorname{rank}(B), \qquad \operatorname{rank}(A) = \operatorname{rank}(A^{\top}) = \operatorname{rank}(A^{\top}A)
$$

The product bound is why the 3 x 2 times 2 x 4 product from section 1.1 cannot reach rank 3: every column of AB is A acting on something, so every output lies in A's column space, which has dimension at most 2. Information has to pass through the narrow middle dimension, and it cannot widen again on the way out. That single picture, the **bottleneck**, explains autoencoders, LoRA adapters, low-rank attention, and grouped or factorized embedding layers all at once.

### The rank-nullity theorem

$$
\dim(\operatorname{null}(A)) + \operatorname{rank}(A) = n \qquad (n = \text{number of columns} = \text{input dimension})
$$

The **null space** (or kernel) of A is the set of x with Ax = 0, the directions the map annihilates. Read the theorem as a conservation law: the input has n dimensions, each one either survives into the output or gets crushed to zero, and nothing else can happen. Rank counts the survivors, nullity counts the casualties.

*Proof sketch.* Take a basis v\_1, ..., v\_k of the null space and extend it to a basis v\_1, ..., v\_n of R^n. Show that A v\_{k+1}, ..., A v\_n is a basis of the column space: they span it because the first k vectors contribute nothing, and they are independent because a vanishing combination of them would put the corresponding combination of v\_{k+1}, ..., v\_n in the null space, forcing all its coefficients to zero. Counting gives rank = n - k.

### Why ML people care

- **Collinear features.** If feature 3 is a copy of feature 1 plus twice feature 2, your design matrix X is rank-deficient, X'X is singular, and ordinary least squares has infinitely many solutions. Ridge regression fixes this, for reasons section 1.5 makes precise.
- **Effective dimensionality.** Real data matrices are rarely exactly low rank, but their singular values often decay fast, so they are *nearly* low rank. "Intrinsic dimension" is the practical version of rank.
- **Neural collapse and representation collapse.** If the activations of a layer occupy a subspace of dimension far below the layer width, the extra width is wasted. Monitoring the rank or the singular value spectrum of activation matrices is a real diagnostic.
- **LoRA.** Freeze W and learn a correction Delta W = BA with B of shape (d x r) and A of shape (r x d), r small. The update is constrained to rank r by definition 4, which is why the parameter count drops from d squared to 2dr.

**Try it.** (a) Give a 2 x 2 matrix of rank 1 whose null space is spanned by (1, 1). (b) True or false: if A has full column rank then Ax = b has at most one solution. (c) Why is rank(A'A) = rank(A) even though A'A is much smaller than A when n is small? Answers appear in section 1.12.

## 1.3 The four fundamental subspaces, and what Ax = b means

Every matrix A in R^{m x n} carries four subspaces with it. Learning them is not bookkeeping; it is the cleanest way to know in advance whether a system has no solution, one solution, or infinitely many, and it is the skeleton on which least squares in section 1.5 hangs.

| Subspace | Definition | Lives in | Dimension |
| --- | --- | --- | --- |
| Column space, col(A) | all Ax | R^m (output side) | r |
| Null space, null(A) | all x with Ax = 0 | R^n (input side) | n - r |
| Row space, col(A') | all A'y | R^n (input side) | r |
| Left null space, null(A') | all y with A'y = 0 | R^m (output side) | m - r |

Here r = rank(A). Notice that the two input-side dimensions add to n and the two output-side dimensions add to m. That is rank-nullity applied twice.

### The picture that makes it click

The input space R^n splits cleanly into two orthogonal pieces: the row space and the null space. The output space R^m splits the same way into the column space and the left null space. And the map A does something very specific:

- It takes the **row space** and maps it one-to-one and onto the **column space**. On this part, A is invertible.
- It takes the **null space** and crushes it to zero. This information is destroyed and cannot be recovered.
- Nothing ever lands in the **left null space**. Those output directions are unreachable.

So any input x decomposes as x = x\_row + x\_null, and Ax = A x\_row. The null component is invisible to the map. The formal statement behind the picture is:

The picture is worth drawing once and keeping. The input space splits into the row space and the null space; the output space splits into the column space and the left null space; and the map connects them in exactly one way.

```mermaid
flowchart LR
  subgraph IN["Input space R^n"]
    RS["Row space<br/>dim r"]
    NS["Null space<br/>dim n - r"]
  end
  subgraph OUT["Output space R^m"]
    CS["Column space<br/>dim r"]
    LN["Left null space<br/>dim m - r<br/>(unreachable)"]
  end
  Z["0"]
  RS -->|"one-to-one and onto"| CS
  NS -->|"crushed"| Z
```

Read it as: A is invertible on the row space, destroys the null space, and can never produce anything in the left null space. The two dimensions on the left add to n, the two on the right add to m.

$$
\operatorname{null}(A) = \operatorname{col}(A^{\top})^{\perp}, \qquad \operatorname{null}(A^{\top}) = \operatorname{col}(A)^{\perp}
$$

*Proof of the first, and it is a one-liner worth memorizing.* Ax = 0 says every row of A has inner product zero with x, which says exactly that x is orthogonal to every row, which says x is orthogonal to the span of the rows. Done. The second statement is the first applied to A transpose.

### Reading solvability off the subspaces

Given Ax = b:

1. **A solution exists if and only if b lies in col(A).** By the combination-of-columns rule, Ax ranges over exactly the column space and nothing more. If b sticks out of it, no x can reach b, and the honest response is to give up on exact solution and minimize the residual instead. That move is least squares.
2. **If a solution exists, it is unique if and only if null(A) = {0}.** If v is a nonzero null vector and x solves the system, so does x + v, and so does x + 100v. Uniqueness and full column rank are the same condition.
3. **The complete solution set** is one particular solution plus the whole null space: a point plus a flat subspace through the origin, shifted.

The four combinations, which is what an interviewer is usually probing:

| Case | Column space | Null space | Outcome |
| --- | --- | --- | --- |
| r = m = n | all of R^m | zero | exactly one solution, A invertible |
| r = n < m (tall, full column rank) | a proper subspace of R^m | zero | zero or one solution; generically none |
| r = m < n (wide, full row rank) | all of R^m | nonzero | always solvable, infinitely many solutions |
| r < m and r < n | proper subspace | nonzero | none or infinitely many |

### The ML translation

The tall case, n features and m examples with m much bigger than n, is ordinary supervised learning. Xw = y almost never has an exact solution because y has noise in it and therefore sticks out of the column space of X. We settle for the closest reachable point: least squares.

The wide case, more parameters than examples, is the **overparameterized** regime that every modern neural network lives in. There are infinitely many parameter settings that fit the training data exactly, differing by anything in the null space. Which one you land on is decided by the optimizer and the initialization, not by the loss. This is the precise linear-algebra statement of the implicit-bias question that underlies why large networks generalize at all: gradient descent started at zero converges to the minimum-norm solution, the one whose null-space component is zero. You will see that fall out of the pseudoinverse in section 1.8.

### Worked example

Let A have rows (1, 2, 3) and (2, 4, 6). The second row is twice the first, so r = 1.

- col(A) is the span of (1, 2) in R^2: a line, not the whole plane.
- null(A) is all x with x\_1 + 2x\_2 + 3x\_3 = 0: a plane in R^3, dimension 2, which checks out since n - r = 3 - 1 = 2.
- row space is the span of (1, 2, 3), dimension 1, and it is orthogonal to that plane, as promised.
- null(A') is all y with y\_1 + 2y\_2 = 0, the span of (2, -1) in R^2, dimension m - r = 1.

So Ax = b is solvable exactly when b is a multiple of (1, 2), and when it is solvable there is a whole plane of solutions.

**Try it.** A is 5 x 3 with rank 2. (a) What are the dimensions of all four subspaces? (b) Can Ax = b have exactly one solution for some b? (c) For how many b in R^5 is the system solvable, as a fraction of R^5? Worked answers in section 1.12.

## 1.4 Inner products, norms, orthogonality, projection

A vector space by itself has no notion of length or angle. The inner product is what installs geometry, and once geometry exists, almost every ML objective turns out to be a distance or an angle in disguise.

### The inner product and what it measures

$$
\langle x, y \rangle = x^{\top} y = \sum_{i=1}^{d} x_i y_i = \lVert x \rVert \, \lVert y \rVert \cos\theta
$$

The last equality is the one to keep. The inner product is large and positive when two vectors point the same way, zero when they are perpendicular, and negative when they oppose. **It measures alignment, scaled by both magnitudes.** Cosine similarity simply divides the magnitudes out:

$$
\cos\theta = \frac{x^{\top} y}{\lVert x \rVert \, \lVert y \rVert} \in [-1, 1]
$$

This is why embeddings are compared by cosine similarity rather than raw dot product: you usually care about *direction*, meaning, and not about how long a vector happens to be. It is also why attention logits are dot products. Query i attends to key j in proportion to how aligned they are.

### Norms

A norm assigns a length. The p-norms are the family you need:

$$
\lVert x \rVert_p = \Big( \sum_{i=1}^{d} |x_i|^p \Big)^{1/p}, \qquad \lVert x \rVert_{\infty} = \max_i |x_i|
$$

| Norm | Formula | Unit ball shape | Where it shows up |
| --- | --- | --- | --- |
| L1 | sum of absolute values | diamond, corners on the axes | Lasso, sparsity, L1 loss / MAE |
| L2 | square root of sum of squares | round ball | ridge, weight decay, MSE, Euclidean distance |
| L-infinity | largest absolute entry | cube | adversarial perturbation budgets, gradient clipping by max |
| L0 (not a real norm) | count of nonzeros | - | "how sparse is this", combinatorially hard |

**Why L1 gives sparsity, intuitively.** Picture minimizing a loss subject to a norm budget. The solution sits where a level set of the loss first touches the norm ball. The L1 ball has sharp corners, and the corners sit exactly on the coordinate axes, where some coordinates are zero. A randomly oriented level set is far more likely to first touch a corner than a flat face. The L2 ball is round and has no preferred directions, so it shrinks everything a bit and zeroes nothing. That picture is worth more in an interview than the subgradient argument, though the subgradient argument is the rigorous one: the derivative of the absolute value does not vanish as you approach zero, so there is a finite threshold below which the penalty wins outright.

Three properties define a norm: it is zero only at the zero vector, it scales as ||ax|| = |a| ||x||, and it satisfies the triangle inequality. The L2 norm additionally comes from an inner product, ||x||^2 = x'x, which is what lets you differentiate it easily and is a large part of why squared error is so popular.

**Cauchy-Schwarz**, which you should be able to state and use:

$$
|x^{\top} y| \le \lVert x \rVert_2 \, \lVert y \rVert_2, \quad \text{with equality exactly when } x \text{ and } y \text{ are parallel}
$$

It is the reason cosine similarity is bounded by 1, the reason correlation is bounded by 1, and the reason the steepest-ascent direction of a linear function is its gradient.

### Orthogonality

x and y are orthogonal when x'y = 0. A set of vectors is **orthonormal** when they are mutually orthogonal and each has unit length. Orthonormal bases are the best coordinate systems you can have, for a simple reason: coordinates become inner products. If q\_1, ..., q\_n is an orthonormal basis, then

$$
x = \sum_{i=1}^{n} (q_i^{\top} x)\, q_i
$$

No solving of linear systems, no matrix inversion: just take inner products. Compare this with a general basis, where finding coordinates means solving Bc = x.

A square matrix Q whose columns are orthonormal is called **orthogonal** and satisfies Q'Q = QQ' = I, so Q inverse equals Q transpose. These matrices are rotations and reflections, and they are exactly the linear maps that preserve all lengths and all angles:

$$
\lVert Qx \rVert_2 = \lVert x \rVert_2, \qquad (Qx)^{\top}(Qy) = x^{\top} y
$$

Both follow in one line from (Qx)'(Qy) = x'Q'Qy = x'y. Orthogonal matrices are numerically wonderful because they never amplify error: their condition number is exactly 1 (section 1.10). That is why QR is preferred over the normal equations, why orthogonal initialization is a real technique in deep nets, and why rotary position embeddings are built from rotations.

### Projection, the workhorse

Projecting b onto a line spanned by a unit vector u, and onto the column space of a matrix A:

$$
\operatorname{proj}_u(b) = (u^{\top} b)\, u, \qquad \operatorname{proj}_{\operatorname{col}(A)}(b) = A (A^{\top} A)^{-1} A^{\top} b
$$

The general formula looks intimidating but the derivation is short and you should be able to reproduce it. We want the point p = Ax-hat in the column space closest to b. The residual b - p must be orthogonal to the entire column space, so it must be orthogonal to every column of A:

$$
A^{\top}(b - A\hat{x}) = 0 \;\Longrightarrow\; A^{\top}A\hat{x} = A^{\top}b \;\Longrightarrow\; \hat{x} = (A^{\top}A)^{-1}A^{\top}b
$$

Those are the **normal equations**, and "normal" here means perpendicular. Substituting back gives the projection matrix P = A(A'A)^{-1}A'.

Every projection matrix satisfies two properties that characterize it completely: **P = P' (symmetric) and P^2 = P (idempotent).** Idempotence says projecting twice is the same as projecting once, which is geometrically obvious and algebraically useful. Its eigenvalues are therefore all 0 or 1, and its rank equals its trace, which equals the dimension of the space it projects onto.

### Gram-Schmidt and QR, briefly

Gram-Schmidt turns any basis into an orthonormal one: take each vector, subtract off its projections onto the ones already processed, and normalize what remains. Doing this to the columns of A and recording the bookkeeping gives the **QR decomposition** A = QR, with Q orthonormal columns and R upper triangular. It is the numerically stable way to solve least squares, since you avoid ever forming A'A, which squares the condition number. In practice libraries use Householder reflections rather than classical Gram-Schmidt, which loses orthogonality in floating point.

**Try it.** (a) Show that P = A(A'A)^{-1}A' is symmetric and idempotent. (b) If P projects onto a 3-dimensional subspace of R^10, what is trace(P), and what are its eigenvalues with multiplicities? (c) Two random vectors in R^d, drawn with independent standard normal entries, have cosine similarity concentrating near what value as d grows, and why does that matter for high-dimensional embeddings? Answers in section 1.12.

## 1.5 Least squares and the geometry of linear regression

Linear regression is the smallest complete example of a machine learning method, and essentially every idea in the field shows up in it: a model, a loss, a closed-form solution, a geometric interpretation, a regularizer, a numerical-stability problem, and a probabilistic story. It rewards being understood thoroughly.

### The problem

We have X in R^{n x d} with n examples as rows, and targets y in R^n. We want w in R^d minimizing squared error:

$$
\hat{w} = \arg\min_{w} \; \lVert Xw - y \rVert_2^2 = \arg\min_{w} \; \sum_{i=1}^{n} (x_i^{\top} w - y_i)^2
$$

There are three ways to solve this, and you should know all three because interviewers pick whichever one you did not mention.

### Solution 1: geometry

Xw ranges over col(X), a subspace of R^n of dimension at most d. Since n is much larger than d, y almost certainly does not lie in that subspace. So find the closest point in it, which means projecting y onto col(X). The residual must be orthogonal to col(X), giving X'(y - Xw) = 0, which is the normal equations again:

$$
X^{\top}X\hat{w} = X^{\top}y \quad \Longrightarrow \quad \hat{w} = (X^{\top}X)^{-1}X^{\top}y \quad \text{when } X^{\top}X \text{ is invertible}
$$

The fitted values are y-hat = Xw-hat = Py with P = X(X'X)^{-1}X', the projection matrix, and the residual r = y - y-hat = (I - P)y lives in the orthogonal complement. Notice that the residual is orthogonal to every feature. If it were not, there would be leftover linear signal you could still exploit, and you would not be at the optimum. This is a useful diagnostic: **plot residuals against each feature; a systematic pattern means your model class is wrong, not that your fit failed.**

### Solution 2: calculus

Expand the objective and differentiate. This is also your first real matrix-calculus exercise, which Chapter 2 develops properly.

$$
L(w) = \lVert Xw - y \rVert^2 = (Xw - y)^{\top}(Xw - y) = w^{\top}X^{\top}Xw - 2y^{\top}Xw + y^{\top}y
$$

$$
\nabla_w L = 2X^{\top}Xw - 2X^{\top}y = 0 \quad \Longrightarrow \quad X^{\top}Xw = X^{\top}y
$$

The Hessian is 2X'X, which is positive semidefinite (section 1.7), so L is convex and this stationary point is a global minimum. It is strictly convex, hence the minimum is unique, exactly when X has full column rank.

### Solution 3: probability

Assume y\_i = x\_i'w + e\_i with e\_i independent Gaussian noise of mean zero and variance sigma squared. The log-likelihood of the data is a negative constant times the sum of squared residuals, plus terms not involving w. **Maximizing Gaussian likelihood is minimizing squared error.** That equivalence is a favorite interview question, and Chapter 4 derives it in full. The same logic shows that Laplace noise gives L1 loss, which is why L1 regression is robust to outliers: a Laplace distribution has heavier tails, so a large residual is less surprising and gets pulled on less hard.

### Why X'X keeps appearing, and what it is

X'X is the d x d matrix whose (j, k) entry is the inner product of feature column j with feature column k. If the columns are centered, it is n times the empirical covariance matrix of the features. It is symmetric, always positive semidefinite, and positive definite exactly when X has full column rank. So X'X is simultaneously:

- the **Gram matrix** of the features (all pairwise inner products),
- the (unnormalized) **covariance** of the features,
- **half the Hessian** of the least-squares loss,
- the thing whose conditioning decides whether the problem is numerically well behaved.

That coincidence, that the covariance of the data equals the curvature of the loss, is why data preprocessing has such a direct effect on optimization speed. Poorly scaled features produce a badly conditioned Hessian, which produces slow gradient descent. Chapter 6 makes this quantitative; standardizing features is not superstition, it is Hessian conditioning.

### Ridge regression, three readings

$$
\hat{w}_{\text{ridge}} = \arg\min_w \; \lVert Xw - y \rVert^2 + \lambda \lVert w \rVert_2^2 = (X^{\top}X + \lambda I)^{-1}X^{\top}y
$$

1. **Algebraic:** adding lambda times the identity shifts every eigenvalue of X'X up by lambda, so the matrix becomes invertible even when X is rank-deficient, and its condition number improves. Ridge always has a unique solution; plain OLS may not.
2. **Geometric:** you are trading a little bias for a lot of variance reduction. In the SVD basis (section 1.9) ridge shrinks the coefficient along the direction with singular value s\_i by the factor s\_i^2 / (s\_i^2 + lambda). Directions the data explores strongly are barely touched; directions the data barely explores get crushed. Ridge is a smart, direction-aware shrinkage, not a blunt one.
3. **Probabilistic:** ridge is the MAP estimate under a Gaussian prior on w with variance sigma^2 / lambda. Lasso is the MAP estimate under a Laplace prior. Chapter 4 proves both.

And the deep-learning connection: **L2 regularization on the weights is weight decay**, up to the well-known subtlety that with adaptive optimizers the two differ, which is precisely the AdamW correction. Chapter 6 covers that.

### How to actually compute it

Never form X'X and invert it if you can avoid it, for two reasons. First, inversion is wasteful; solving a linear system is cheaper and more stable than inverting and multiplying. Second, forming X'X squares the condition number, so you lose roughly half your significant digits before you start. Use QR (solve Rw = Q'y by back-substitution) or, for rank-deficient or near-singular problems, the SVD-based pseudoinverse. In interviews, "I would use `lstsq`, which uses QR or SVD, rather than inverting the normal equations, because forming X'X squares the condition number" is a strong answer.

Costs, for orientation: normal equations are O(nd^2 + d^3), QR is O(nd^2), SVD is O(nd^2) with a larger constant. When d is large, you stop using closed forms entirely and run gradient descent, which is O(nd) per step.

**Try it.** (a) Show that the residual vector r = y - Xw-hat satisfies X'r = 0, and explain in words what that says about correlations. (b) Show that ridge with lambda > 0 always has a unique solution, even when n < d. (c) Suppose you duplicate a feature column. What happens to OLS, and what happens to ridge? Answers in section 1.12.

## 1.6 Eigenvalues, eigenvectors, and the spectral theorem

### What an eigenvector is, intuitively

A general matrix does something complicated to space: it rotates, stretches, shears. An eigenvector is a direction that escapes the complication. Along it, the matrix does nothing but scale.

$$
Av = \lambda v, \qquad v \neq 0
$$

If you can find enough such directions to form a basis, then in that basis the matrix is diagonal, and a diagonal matrix is trivial to understand: it scales each coordinate independently. **Eigendecomposition is the search for a coordinate system in which a complicated map becomes n independent one-dimensional scalings.**

That is also why eigenvalues govern repeated application. If A = V D V^{-1}, then

$$
A^k = V D^k V^{-1}
$$

so the k-th power just raises each eigenvalue to the k-th power. Directions with |lambda| > 1 blow up, directions with |lambda| < 1 die out, and the largest-magnitude eigenvalue dominates as k grows. This one fact explains PageRank, Markov chain convergence rates, the stability of recurrent networks, exploding and vanishing gradients, and the convergence rate of gradient descent. Keep it close.

### Computing them, and why you usually should not

Eigenvalues are the roots of the characteristic polynomial det(A - lambda I) = 0. This is fine for 2 x 2 by hand and a numerical disaster in general: polynomial roots are wildly sensitive to coefficient perturbations. Real algorithms use QR iteration or Krylov methods instead. Know the characteristic polynomial as a definition, not as a method.

Two identities that fall straight out of it, and which interviewers love because they take five seconds and reveal whether you understand the objects:

$$
\operatorname{tr}(A) = \sum_{i=1}^{n} \lambda_i, \qquad \det(A) = \prod_{i=1}^{n} \lambda_i
$$

So a singular matrix has a zero eigenvalue, and the trace is a cheap sanity check on a computed spectrum. Also useful: the eigenvalues of A + cI are those of A shifted by c, with identical eigenvectors. That is the entire mechanism behind ridge regression and behind damping in trust-region and Levenberg-Marquardt methods.

### The spectral theorem

Not every matrix is diagonalizable over the reals. A rotation in the plane has no real eigenvector, since nothing keeps its direction. A shear matrix with ones on the diagonal and a single one above it has a repeated eigenvalue but only a one-dimensional eigenspace, so it is defective. But **symmetric matrices are always as nice as possible**, and nearly every matrix that matters in ML is symmetric: covariance matrices, Hessians, Gram matrices, kernel matrices, graph Laplacians.

> **Spectral theorem.** If A in R^{n x n} is symmetric, then A has n real eigenvalues, and there is an orthonormal basis of R^n consisting of eigenvectors of A. Equivalently A = Q D Q' with Q orthogonal and D diagonal real.

Equivalently again, A is a sum of scaled orthogonal projections onto mutually perpendicular lines:

$$
A = \sum_{i=1}^{n} \lambda_i \, q_i q_i^{\top}
$$

Read that formula out loud: a symmetric matrix picks n perpendicular axes and stretches space by lambda\_i along axis i. That is all it does. There is no rotation, no shear, nothing else.

**Proof of the two key claims.** These are short enough to reproduce in an interview.

*Eigenvalues are real.* Let Av = lambda v with v possibly complex, and let v-star denote the conjugate transpose. Then v\* A v = lambda v\* v. Taking conjugate transposes of the left side and using A' = A and A real gives v\* A v = conj(lambda) v\* v. Since v\* v is a positive real number, lambda = conj(lambda), so lambda is real. Real eigenvalue plus real matrix then gives a real eigenvector from the real null space of A - lambda I.

*Eigenvectors for distinct eigenvalues are orthogonal.* Suppose Av = a v and Aw = b w with a not equal to b. Then a (w'v) = w'(Av) = (Aw)'v = b (w'v), using symmetry in the middle step. So (a - b)(w'v) = 0, and since a is not b, w'v = 0. For repeated eigenvalues the eigenspace has full dimension and you can pick an orthonormal basis inside it, which is where the full proof does its remaining work by induction on dimension.

### What it buys you in practice

- **Functions of matrices.** For symmetric A, define f(A) = Q f(D) Q', applying f to each eigenvalue. This gives matrix square roots (used for whitening data and for reparameterizing Gaussians), matrix inverses, matrix exponentials, and matrix logarithms.
- **Whitening.** Given covariance Sigma = Q D Q', the transform Sigma^{-1/2} = Q D^{-1/2} Q' turns correlated data into data with identity covariance. This is what batch normalization approximates, cheaply, using only the diagonal.
- **Reading a Hessian.** At a critical point of a loss, the Hessian is symmetric. Its eigenvalues tell you the shape: all positive means a local minimum in a bowl, mixed signs mean a saddle, and near-zero eigenvalues mean flat directions along which the loss barely changes. Deep network loss landscapes are dominated by saddles rather than local minima, and the spectral picture is how that was established.
- **Convergence rates.** Gradient descent on a quadratic with Hessian H converges at a rate governed by lambda\_max / lambda\_min. Chapter 6 derives the exact rate; the intuition is that you must take a step small enough not to diverge along the steepest direction, which then makes progress painfully slow along the flattest one.
- **Spectral norm and stability.** The largest eigenvalue magnitude of a recurrent update matrix decides whether repeated application explodes or vanishes. Spectral normalization in GANs directly constrains it.

### Diagonalizable versus not

A matrix is diagonalizable when it has n linearly independent eigenvectors. Sufficient conditions worth remembering: n distinct eigenvalues is enough; symmetric is enough and gives you orthogonality for free. When a matrix is not diagonalizable you fall back to the Jordan form, which is theoretically important and practically almost never used, because the SVD (section 1.8) exists for every matrix without exception and is numerically stable. **If you catch yourself reaching for eigendecomposition on a non-symmetric matrix, ask whether you actually wanted the SVD.** Usually you did.

**Try it.** (a) A is symmetric with eigenvalues 3, 1, and 0. What are rank(A), trace(A), det(A)? (b) Show that if A is symmetric and idempotent then every eigenvalue is 0 or 1. (c) Give a 2 x 2 real matrix with no real eigenvalues, and say what it does geometrically. Answers in section 1.12.

## 1.7 Quadratic forms and positive semidefinite matrices

### The object

A quadratic form is the scalar function

$$
q(x) = x^{\top} A x = \sum_{i}\sum_{j} A_{ij} x_i x_j
$$

Since x'Ax = x'A'x for any A, only the symmetric part of A affects the form, so **assume A symmetric without loss of generality.** Everyone does, and interviewers expect you to say it.

Quadratic forms are the second-order Taylor term of every smooth function, so understanding them is understanding curvature:

$$
f(x_0 + \delta) \approx f(x_0) + \nabla f(x_0)^{\top}\delta + \tfrac{1}{2}\,\delta^{\top} \nabla^2 f(x_0)\, \delta
$$

Near a critical point the gradient term vanishes and the quadratic form *is* the local picture of the loss.

### Definiteness

| Name | Condition on x'Ax | Eigenvalues | Shape of the surface |
| --- | --- | --- | --- |
| Positive definite (PD) | > 0 for all nonzero x | all > 0 | bowl, unique minimum |
| Positive semidefinite (PSD) | >= 0 for all x | all >= 0 | bowl with flat valley floors |
| Negative (semi)definite | <= 0, or < 0 | all <= 0, or < 0 | dome |
| Indefinite | both signs occur | mixed signs | saddle |

**Why the eigenvalue characterization is true, in one step.** Write A = QDQ' and substitute y = Q'x. Since Q is orthogonal, y ranges over all of R^n as x does, and

$$
x^{\top}Ax = x^{\top}QDQ^{\top}x = y^{\top}Dy = \sum_{i=1}^{n} \lambda_i y_i^2
$$

A weighted sum of squares is nonnegative for all y exactly when all the weights are nonnegative. That single substitution is the whole proof, and it also hands you the level sets: the set where x'Ax = 1 is an ellipsoid whose axes are the eigenvectors and whose semi-axis lengths are 1 over the square root of the eigenvalues. **Large eigenvalue means short axis means steep direction.**

### Where PSD matrices come from in ML

The two most important facts, both of which you should be able to prove in one line each:

**Any matrix of the form B'B is PSD.**

$$
x^{\top}B^{\top}Bx = (Bx)^{\top}(Bx) = \lVert Bx \rVert_2^2 \ge 0
$$

It is positive *definite* exactly when Bx is nonzero for every nonzero x, that is, when B has full column rank. This instantly covers X'X in least squares, the Gram matrix in kernel methods, and the Fisher information matrix.

**Any covariance matrix is PSD.** For Sigma = E\[(z - mu)(z - mu)'\],

$$
x^{\top}\Sigma x = \mathbb{E}\big[ x^{\top}(z-\mu)(z-\mu)^{\top}x \big] = \mathbb{E}\big[ (x^{\top}(z-\mu))^2 \big] = \operatorname{Var}(x^{\top}z) \ge 0
$$

This is a lovely identity in its own right: **x'Sigma x is the variance of the data projected onto direction x.** Variance cannot be negative, so covariance matrices cannot fail to be PSD. It also tells you what PCA is doing before you have seen PCA: maximizing x'Sigma x over unit x means finding the direction of greatest variance, and by the spectral theorem the answer is the top eigenvector. A covariance matrix is singular exactly when some direction has zero variance, meaning the data lies in a lower-dimensional affine subspace, meaning your features are exactly collinear.

Other PSD sightings: kernel matrices (PSD by Mercer's condition, which is what makes kernel methods work), the Hessian of any convex function, and the Fisher information matrix, which is a covariance of score functions.

### Tests for positive definiteness

1. All eigenvalues positive. Correct, expensive.
2. All **leading principal minors** positive (Sylvester's criterion). Good for small symbolic problems, useless numerically.
3. **Cholesky decomposition succeeds:** A = LL' with L lower triangular and positive diagonal exists precisely when A is PD. This is the practical test, it is about twice as fast as LU, and it fails gracefully by telling you the matrix is not PD. If a library tells you "Cholesky failed" or "matrix is not positive definite", it means a covariance matrix has gone singular or slightly negative from floating-point error. The standard fix is to add a small multiple of the identity, called jitter or a nugget, which shifts every eigenvalue up.
4. Diagonal entries positive is **necessary but not sufficient** (take e\_i'Ae\_i = A\_ii). A classic trap: a matrix with positive diagonal can still be indefinite if the off-diagonals are large.

### A useful ordering

Writing A >= B to mean A - B is PSD gives a partial order on symmetric matrices, the **Loewner order**. It is genuinely partial: two matrices need not be comparable. You will meet it in the Cramer-Rao bound, in analysis of variance reduction, and in trust-region and natural-gradient arguments.

### Why any of this matters for optimization

- A twice-differentiable f is **convex** exactly when its Hessian is PSD everywhere, and strictly convex when it is PD. Convexity is what guarantees a local minimum is global.
- At a critical point, the Hessian eigenvalues classify it: all positive is a minimum, all negative a maximum, mixed a saddle. In high dimensions, a random critical point is overwhelmingly likely to have at least one negative eigenvalue, which is why saddles, not local minima, are the real obstacle in deep learning.
- The **condition number** lambda\_max / lambda\_min of the Hessian controls gradient descent's speed. Elongated ellipsoidal level sets mean zigzagging. Preconditioning, feature standardization, normalization layers, and Adam's per-coordinate scaling are all attempts to make the effective Hessian closer to the identity.

**Try it.** (a) Is the 2 x 2 matrix with diagonal (1, 1) and off-diagonal 2 positive definite? Compute its eigenvalues and interpret. (b) Prove that if A is PSD then so is C'AC for any conformable C. (c) Show that the sum of two PSD matrices is PSD, and explain what that means for adding L2 regularization to a convex loss. Answers in section 1.12.

## 1.8 The singular value decomposition

If you remember one theorem from this chapter, remember this one. The SVD exists for **every** matrix, square or not, full rank or not, real or complex. Nothing else in linear algebra is that unconditional.

### Statement

$$
A = U \Sigma V^{\top}, \qquad A \in \mathbb{R}^{m \times n}, \; U \in \mathbb{R}^{m \times m}, \; \Sigma \in \mathbb{R}^{m \times n}, \; V \in \mathbb{R}^{n \times n}
$$

U and V are orthogonal; Sigma is "diagonal" with nonnegative entries s\_1 >= s\_2 >= ... >= 0 called the **singular values**. The columns of V are right singular vectors (input side), the columns of U are left singular vectors (output side). In the **thin** or **compact** form you keep only the r = rank(A) nonzero singular values, so U is m x r, Sigma is r x r, and V is n x r. In practice you almost always want the thin form.

The outer-product form is the one to think with:

$$
A = \sum_{i=1}^{r} s_i \, u_i v_i^{\top}
$$

**Every matrix is a weighted sum of rank-1 pieces, ordered from most important to least.** That sentence is the whole of sections 1.8 and 1.9.

### The geometric reading

Any linear map, no matter how messy, factors into exactly three steps: **rotate, stretch along axes, rotate again.** V' rotates the input so that the special input directions line up with the coordinate axes; Sigma stretches axis i by s\_i (and pads or truncates dimensions); U rotates the result into place in the output space.

So the image of the unit sphere under any linear map is an ellipsoid. The singular values are the lengths of its semi-axes and the left singular vectors are their directions. s\_1 is the largest amount A can stretch any unit vector, and it is achieved on v\_1:

$$
s_1 = \max_{\lVert x \rVert_2 = 1} \lVert Ax \rVert_2 = \lVert A \rVert_2 \quad \text{(the spectral norm)}
$$

### Where it comes from: the spectral theorem

You do not have to take the SVD on faith. It follows from section 1.6 in a few lines, and being able to produce this derivation is a strong interview signal.

A'A is symmetric and PSD (section 1.7), so the spectral theorem gives A'A = V D V' with V orthonormal and D diagonal with entries d\_i >= 0. Define s\_i as the square root of d\_i, and for each s\_i > 0 define

$$
u_i = \frac{1}{s_i} A v_i
$$

These u\_i are orthonormal, because

$$
u_i^{\top}u_j = \frac{1}{s_i s_j} v_i^{\top} A^{\top} A v_j = \frac{d_j}{s_i s_j} v_i^{\top} v_j = \frac{s_j}{s_i}\,\delta_{ij} = \delta_{ij}
$$

By construction A v\_i = s\_i u\_i for every i, which is exactly AV = U Sigma, and multiplying on the right by V' gives A = U Sigma V'. Extend U to a full orthonormal basis of R^m if you want the full form.

This derivation also hands you the relationships you must know cold:

| Object | Eigen-relationship |
| --- | --- |
| right singular vectors v\_i | eigenvectors of A'A, eigenvalue s\_i squared |
| left singular vectors u\_i | eigenvectors of AA', eigenvalue s\_i squared |
| singular values s\_i | square roots of the eigenvalues of A'A |
| symmetric PSD A | SVD equals eigendecomposition; s\_i = lambda\_i |
| symmetric indefinite A | s\_i = |

### SVD versus eigendecomposition

|  | Eigendecomposition | SVD |
| --- | --- | --- |
| Exists for | square, diagonalizable matrices | every matrix |
| Bases | one basis, generally not orthogonal | two bases, both orthonormal |
| Values | can be negative or complex | always real and nonnegative |
| Numerics | can be badly conditioned | backward stable |
| Best mental model | repeated application, dynamics | geometry, approximation, compression |

Rule of thumb: **use eigendecomposition when you will apply the matrix many times (dynamics, powers, Markov chains); use the SVD when you want to understand, approximate, or invert the matrix.**

### Reading the four subspaces off the SVD

This is the payoff for section 1.3. With singular values ordered and r nonzero ones:

- col(A) = span of u\_1, ..., u\_r
- null(A') = span of u\_{r+1}, ..., u\_m
- row space = span of v\_1, ..., v\_r
- null(A) = span of v\_{r+1}, ..., v\_n

The SVD hands you orthonormal bases for all four subspaces at once, which no other decomposition does. Every claim about orthogonal complements from section 1.3 becomes visually obvious here.

### The pseudoinverse

When A is not invertible, the **Moore-Penrose pseudoinverse** is the best available substitute:

$$
A^{+} = V \Sigma^{+} U^{\top}, \qquad \Sigma^{+} = \operatorname{diag}(1/s_1, \ldots, 1/s_r, 0, \ldots, 0)
$$

Invert the nonzero singular values, leave the zeros alone, and transpose the shape. What it computes is exactly what you want:

- If A has full column rank, A+ = (A'A)^{-1}A' and A+b is the least-squares solution.
- If A has full row rank, A+ = A'(AA')^{-1} and A+b is the **minimum-norm** solution among the infinitely many exact solutions.
- In general, A+b is the minimum-norm least-squares solution: among all w minimizing ||Aw - b||, it returns the one with smallest ||w||.

That last property is the linear-algebra shadow of a central deep-learning phenomenon. In the overparameterized regime there are infinitely many interpolating solutions, and gradient descent from zero initialization converges to the minimum-norm one, which is the pseudoinverse solution. The optimizer, not the loss, picks the solution, and it picks the simplest one in the L2 sense. That is one concrete, provable instance of implicit regularization.

Note that A+ **does not depend continuously on A** near a rank change: nudging a zero singular value to 10^{-12} sends 1/s to 10^{12}. This is why numerical routines use a tolerance and treat tiny singular values as zero. Truncating them is the same operation as ridge regularization in spirit, and both are ways of refusing to trust directions the data barely determines.

### Costs and practice

A full SVD of an m x n matrix costs O(min(m,n)^2 max(m,n)), which is prohibitive at scale. For the top-k singular triplets, use truncated or randomized SVD, or Lanczos-type iterative methods; randomized SVD gets you an excellent rank-k approximation in roughly O(mnk) time and is what most large-scale pipelines actually run.

**Try it.** (a) Write the SVD of a 2 x 2 diagonal matrix with entries 3 and -1, being careful about signs. (b) If A is orthogonal, what are its singular values, and what is its spectral norm? (c) Show that ||A||\_2 = s\_1 and ||A||\_F^2 = sum of s\_i squared. Answers in section 1.12.

## 1.9 Low-rank approximation, PCA, and modern uses

### Eckart-Young: truncating the SVD is optimal

Take the SVD and throw away everything after the k-th term:

$$
A_k = \sum_{i=1}^{k} s_i \, u_i v_i^{\top}
$$

> **Eckart-Young-Mirsky theorem.** A\_k is the best rank-k approximation to A, in the Frobenius norm and in the spectral norm (indeed in every unitarily invariant norm). The errors are exactly

$$
\lVert A - A_k \rVert_2 = s_{k+1}, \qquad \lVert A - A_k \rVert_F^2 = \sum_{i=k+1}^{r} s_i^2
$$

This is a remarkable statement. Over the enormous, non-convex set of all rank-k matrices, the optimum is not merely computable, it has a closed form you get by reading off the top of a decomposition you already had. Almost no other constrained matrix problem is that kind.

*Why it is plausible.* Singular values are the only intrinsic "sizes" in the matrix, and unitarily invariant norms depend on the matrix only through them. The best you can do with a rank budget of k is to keep the k largest sizes, and the leftover error is made of the ones you discarded. The formal proof of the spectral-norm case is a short dimension-counting argument: any rank-k matrix B has a null space of dimension at least n - k, which must intersect the (k+1)-dimensional span of v\_1, ..., v\_{k+1} nontrivially; on a unit vector x in that intersection, (A - B)x = Ax, and ||Ax|| is at least s\_{k+1}.

**What the singular value spectrum tells you.** Plot s\_i against i on a log scale. Fast decay means the matrix is effectively low rank, so compression is nearly lossless and there is real structure. Slow decay means the information is genuinely spread out and compression will hurt. This plot is a cheap and underused diagnostic for embedding tables, attention maps and activation matrices.

### PCA, derived

Center the data so the columns of X have mean zero. The empirical covariance is

$$
\Sigma = \frac{1}{n} X^{\top} X \in \mathbb{R}^{d \times d}
$$

PCA asks for the unit direction w maximizing the variance of the projected data, which by section 1.7 is w'Sigma w:

$$
w_1 = \arg\max_{\lVert w \rVert = 1} w^{\top} \Sigma w
$$

By the spectral theorem, write w in the eigenbasis: w = sum of c\_i q\_i with sum of c\_i squared equal to 1. Then w'Sigma w = sum of lambda\_i c\_i squared, a weighted average of the eigenvalues with weights summing to 1. An average cannot exceed the largest element, and it equals it exactly when all weight sits on the top eigenvector. **So the first principal component is the top eigenvector of the covariance matrix, and the variance it captures is the top eigenvalue.** Subsequent components are the same argument restricted to the orthogonal complement.

And via the SVD of the centered X = U Sigma\_svd V':

- **principal directions** are the columns of V, the right singular vectors,
- **eigenvalues of the covariance** are s\_i squared over n,
- **projected coordinates (scores)** are XV = U Sigma\_svd,
- **explained variance ratio** for component i is s\_i squared divided by the sum of all s\_j squared.

Compute PCA from the SVD of the centered data matrix, not from an explicit covariance matrix. Forming X'X squares the condition number for no benefit, exactly as in least squares.

There is a second, equivalent characterization worth knowing because it connects to autoencoders: PCA finds the k-dimensional linear subspace minimizing the total squared reconstruction error. Maximizing captured variance and minimizing discarded variance are the same problem, since total variance is fixed. That is why **a linear autoencoder with a bottleneck of size k, trained with squared error, recovers the PCA subspace** (it recovers the subspace, not necessarily the individual axes, since any invertible mixing inside the bottleneck gives the same loss).

**Practical cautions.** PCA is not scale-invariant, so standardize features when their units differ, or one feature measured in millimeters will dominate one measured in kilometers. PCA is unsupervised, so the top variance directions need not be the directions that predict your label. And PCA is linear, so it cannot unfold curved structure; that is what kernel PCA, t-SNE, UMAP and autoencoders are for.

### Where low rank shows up in deep learning

- **LoRA and parameter-efficient fine-tuning.** Freeze W and learn W + BA with B of shape (d x r), A of shape (r x d), r typically 4 to 64. Parameter count drops from d squared to 2dr. The bet is that the *update* needed to adapt a pretrained model has low intrinsic rank, even though W itself does not. Section 1.2's definition 4 is exactly the constraint being imposed.
- **Embedding factorization.** ALBERT factorized a (vocab x hidden) embedding into (vocab x e) times (e x hidden), cutting parameters sharply with little loss, precisely because embedding tables have fast-decaying spectra.
- **Low-rank and linear attention.** Full attention costs O(n squared) in sequence length. Methods like Linformer project keys and values to a lower dimension, motivated by the empirical observation that attention matrices are approximately low rank.
- **Model compression.** Replacing a weight matrix by its rank-k truncation is one of the oldest compression methods, and still a baseline. It is usually weaker than quantization or distillation, but it is the easiest to reason about.
- **Recommender systems.** Matrix factorization for collaborative filtering is low-rank approximation of a partially observed matrix; the latent factors are singular-vector-like directions. The observation pattern makes it non-convex and Eckart-Young no longer applies directly, which is why you see alternating least squares and SGD there rather than a closed form.
- **Spectral diagnostics.** Rank collapse of attention maps, dimensional collapse in self-supervised learning, effective rank of representations: all measured with singular value spectra.

### Worked example: image compression, and the arithmetic that convinces

A 1000 x 1000 grayscale image is a matrix with 1,000,000 entries. Keeping k = 50 singular triplets costs 50 times (1000 + 1000 + 1) entries, about 100,050 numbers, a tenfold reduction. Natural images have rapidly decaying spectra, so the result usually looks nearly identical. Run this once in numpy and watch the image reappear as you add terms; it makes the outer-product view of section 1.1 permanent.

**Try it.** (a) A has singular values 10, 5, 1, 0.1. What fraction of the Frobenius norm squared does the best rank-2 approximation capture? (b) Why must you center your data before PCA, and what direction do you get if you forget? (c) You apply LoRA with r = 4 to a 1024 x 1024 layer. How many trainable parameters, and what fraction of the original? Answers in section 1.12.

## 1.10 Matrix norms, condition number, numerical stability

### Matrix norms

| Norm | Definition | In terms of singular values | Meaning |
| --- | --- | --- | --- |
| Frobenius | square root of the sum of all entries squared | square root of sum of s\_i squared | treat the matrix as a long vector |
| Spectral (operator 2-norm) | max over unit x of |  | Ax |
| Nuclear (trace norm) | - | sum of all s\_i | convex surrogate for rank |
| Induced 1-norm | max over unit x of |  | Ax |
| Induced infinity-norm | max over unit x of |  | Ax |

The useful chain of inequalities, true for any A of rank r:

$$
\lVert A \rVert_2 \;\le\; \lVert A \rVert_F \;\le\; \lVert A \rVert_{*} \;\le\; \sqrt{r}\,\lVert A \rVert_F \;\le\; r\,\lVert A \rVert_2
$$

Every link is Cauchy-Schwarz applied to the vector of singular values: the max is at most the root-sum-of-squares, which is at most the plain sum, and going back the other way costs a factor of the square root of the number of terms each time. Check it on diag(1, 0.01): the four quantities are 1, 1.0000, 1.01, 1.414, 2. Note in particular that the nuclear norm sits **between** the Frobenius norm and the scaled bounds, not above them all.

**Where each one shows up.** Frobenius is what weight decay penalizes, and what you compute when you report a gradient norm. Spectral is what controls Lipschitz constants, so spectral normalization in GANs and Lipschitz-constrained networks are about bounding s\_1. Nuclear is the convex relaxation of rank, exactly as L1 is the convex relaxation of L0, which is why nuclear-norm minimization is the standard approach to matrix completion.

An **induced** norm is one defined by how much the matrix can stretch a vector; induced norms are automatically submultiplicative (||AB|| <= ||A|| ||B||), because stretching twice compounds. Frobenius is not induced but happens to be submultiplicative too. Submultiplicativity is what lets you bound the Lipschitz constant of a deep network by the product of its layers' spectral norms, a bound which is correct but usually so loose as to be useless in practice.

### Condition number

$$
\kappa(A) = \frac{s_{\max}}{s_{\min}} \quad \text{(for invertible } A \text{, using the 2-norm)}
$$

The condition number answers: **if I perturb the input slightly, how much can the output of solving with this matrix change?** The governing bound for Ax = b is

$$
\frac{\lVert \delta x \rVert}{\lVert x \rVert} \;\le\; \kappa(A) \, \frac{\lVert \delta b \rVert}{\lVert b \rVert}
$$

The practical rule of thumb: you lose roughly log base 10 of kappa decimal digits of accuracy. Double precision gives you about 16 digits, so a condition number of 10^8 leaves about 8 good digits and a condition number of 10^16 leaves you with noise. Orthogonal matrices have kappa = 1, the best possible, which is the numerical reason to prefer QR and SVD over anything that forms a normal-equations matrix.

**The fact to carry into every interview:** kappa(A'A) = kappa(A) squared. So forming the normal equations throws away half your significant digits before you have done any arithmetic on them. This is the entire argument for QR-based least squares.

Ill-conditioning is not a numerical curiosity, it is a statement about your data. A large condition number in X means some direction in feature space is barely explored, so the coefficient along it is barely determined and tiny changes in the data swing it wildly. High variance in the statistical sense and ill-conditioning in the numerical sense are the same phenomenon viewed through two lenses. Ridge fixes both at once, and now you can see why: it adds lambda to every eigenvalue of X'X, so the condition number goes from s\_max squared over s\_min squared to (s\_max squared + lambda) over (s\_min squared + lambda), which is much smaller.

### Floating point, briefly but seriously

- Machine epsilon is about 1.1 x 10^-16 in float64, about 1.2 x 10^-7 in float32, and about 10^-3 in bfloat16. Bfloat16 keeps float32's exponent range but has only 8 bits of mantissa, which is why it trains stably despite its low precision: overflow is what kills training, not rounding.
- **Catastrophic cancellation:** subtracting nearly equal numbers destroys relative precision. This is why you never compute variance as E\[X^2\] - (E\[X\])^2 on real data, and why the log-sum-exp trick exists.
- **The log-sum-exp trick**, which you will implement or explain at some point:

$$
\log \sum_i e^{x_i} = c + \log \sum_i e^{x_i - c}, \qquad c = \max_i x_i
$$

Subtracting the max makes the largest exponent exactly zero, so nothing overflows and the dominant term is computed exactly. Every softmax and cross-entropy implementation does this, which is why libraries expose a fused `log_softmax` and a cross-entropy that takes raw logits rather than probabilities. Feeding softmax probabilities into a log yourself is a real bug with real consequences.

- Floating point addition is **not associative**, so results differ with thread count, batch size, and hardware. This is a normal fact of life, not a sign that something is broken, and it is one reason exact reproducibility across machines is hard.

### Conditioning and deep learning

The same ideas reappear, renamed:

- **Exploding and vanishing gradients** are conditioning across depth. Backpropagation multiplies Jacobians; if their singular values are systematically above or below 1, the product explodes or dies exponentially in depth. Careful initialization (Chapter 7) is chosen precisely to keep these singular values near 1.
- **Gradient clipping** bounds the update norm, which is a crude but effective guard against the rare huge step that a badly conditioned region produces.
- **Normalization layers** re-center and re-scale activations, which improves the conditioning of the effective Hessian and is a large part of why they speed up training.
- **Adam** applies a per-coordinate rescaling, which is a diagonal preconditioner. It cannot fix correlations between coordinates, only their individual scales, which is exactly why it helps a lot and does not help completely.

**Try it.** (a) X has singular values 100 and 0.01. What is kappa(X), kappa(X'X), and roughly how many digits survive in float32? (b) Why does ridge with lambda = 1 dramatically improve conditioning here? (c) Explain the log-sum-exp trick to someone who has just seen their loss become NaN. Answers in section 1.12.

## 1.11 Interview drill set

These are short-answer questions of the kind actually asked in ML and research interviews. Cover the answers, give yourself sixty seconds each, say the answer **out loud** as you would to an interviewer, then check. Fluency is the goal, not recognition.

**1. Why do neural networks need nonlinear activations?** A composition of linear maps is linear, so any stack of affine layers collapses to a single affine layer. Depth buys no expressiveness without a nonlinearity.

**2. What does the rank of a matrix mean?** The dimension of its column space: the number of independent directions the map can produce. Equivalently the number of nonzero singular values, or the minimum r for which it factors as (m x r) times (r x n).

**3. Why does rank(AB) <= min(rank A, rank B)?** Every column of AB is A applied to something, so the output lies in col(A). And the columns of AB are combinations of columns of A using B's entries, so the row space is constrained by B. Information passes through the narrow middle dimension and cannot widen again.

**4. When does Ax = b have no solution / one / infinitely many?** None when b is outside col(A). One when b is in col(A) and null(A) is trivial. Infinitely many when b is in col(A) and null(A) is nontrivial; the solution set is one particular solution plus the null space.

**5. Why is the least-squares residual orthogonal to the columns of X?** Because the fit is the orthogonal projection of y onto col(X). If the residual had a component along a feature, there would be remaining linear signal and you would not be at the minimum. Algebraically this is X'(y - Xw) = 0.

**6. Why not just invert X'X?** Forming X'X squares the condition number, costing you about half your significant digits, and inversion is more expensive and less stable than solving. Use QR, or SVD if the matrix may be rank-deficient.

**7. State the spectral theorem and why you care.** A real symmetric matrix has real eigenvalues and an orthonormal eigenbasis, so A = QDQ'. You care because covariance matrices, Hessians, Gram matrices and kernel matrices are all symmetric, and it lets you define matrix square roots, read off definiteness, and see PCA immediately.

**8. Prove that eigenvectors of a symmetric matrix for distinct eigenvalues are orthogonal.** Av = av, Aw = bw. Then a(w'v) = w'Av = (Aw)'v = b(w'v), so (a - b)(w'v) = 0, and a is not b, so w'v = 0.

**9. What is a positive semidefinite matrix and where do they come from?** Symmetric with x'Ax >= 0 for all x, equivalently all eigenvalues nonnegative. They arise as B'B (norm squared of Bx), as covariance matrices (variance of a projection), as Hessians of convex functions, and as kernel matrices.

**10. Prove a covariance matrix is PSD.** x'Sigma x = E\[(x'(z - mu))^2\] = Var(x'z) >= 0. It is the variance of the data projected onto x, and variances are nonnegative.

**11. SVD versus eigendecomposition: when do you use which?** Eigendecomposition needs a square diagonalizable matrix and gives one possibly non-orthogonal basis; SVD exists for every matrix and gives two orthonormal bases with real nonnegative singular values. Use eigen for dynamics and repeated application, SVD for approximation, inversion and understanding structure. For symmetric PSD matrices they coincide.

**12. What are the singular values of A in terms of A'A?** The square roots of the eigenvalues of A'A, whose eigenvectors are the right singular vectors.

**13. What is the best rank-k approximation of a matrix?** The truncated SVD, by Eckart-Young, optimal in Frobenius and spectral norm. The spectral-norm error is exactly s\_{k+1}.

**14. Derive PCA in three sentences.** The variance of the data projected onto unit w is w'Sigma w. Writing w in the eigenbasis of Sigma makes this a weighted average of eigenvalues with weights summing to one, so it is maximized by putting all weight on the top eigenvector. Hence principal components are the eigenvectors of the covariance matrix, equivalently the right singular vectors of the centered data matrix.

**15. Why center the data before PCA?** Without centering, the first component chases the mean vector rather than the direction of greatest variation, because the quadratic form you maximize is then the second moment rather than the variance.

**16. Why does L1 give sparsity and L2 does not?** The L1 ball has corners on the coordinate axes, and a level set of the loss generically touches a corner first, which puts coordinates exactly at zero. The L2 ball is round with no preferred directions, so it shrinks everything a little and zeroes nothing. Rigorously, the absolute value has a non-vanishing subgradient at zero, so there is a finite threshold below which the penalty dominates.

**17. What does the condition number tell you, and what is kappa(A'A)?** How much a relative perturbation of the input can be amplified in the solution; you lose about log-10-kappa digits. kappa(A'A) = kappa(A) squared.

**18. What is the pseudoinverse and what does it compute?** A+ = V Sigma+ U', inverting the nonzero singular values. A+b is the minimum-norm least-squares solution: closest fit, and among tied solutions the one with smallest norm.

**19. What is the connection between the pseudoinverse and overparameterized deep learning?** With more parameters than data, infinitely many solutions interpolate. Gradient descent from zero converges to the minimum-norm solution, which is the pseudoinverse solution. The optimizer, not the loss, selects the solution; this is implicit regularization in its cleanest provable form.

**20. Why is the Hessian's condition number relevant to training speed?** Gradient descent's step size is limited by the largest curvature direction to avoid divergence, but progress along the smallest curvature direction is proportional to that same small step times a small gradient. The convergence rate degrades with the ratio, which is why standardization, normalization layers and preconditioners help.

**21. What does LoRA assume, mathematically?** That the fine-tuning update Delta W has low intrinsic rank, so it can be written BA with inner dimension r much smaller than d. This is the factorized definition of rank, imposed as a constraint.

**22. Why is the softmax computed with a max subtracted?** Exponentials overflow. Subtracting the max is exactly invariant for softmax and makes the largest exponent zero, so nothing overflows and precision is preserved. This is the log-sum-exp trick, and it is why you should pass logits to a cross-entropy function rather than probabilities.

**23. Two random high-dimensional vectors are almost orthogonal. Why, and so what?** For independent standard normal entries, the expected cosine similarity is zero and its standard deviation is about 1 over the square root of d, so it concentrates tightly at zero. Consequence: in high dimensions you can pack an enormous number of nearly-orthogonal directions, which is why wide embedding spaces can represent many near-independent concepts, and also why raw distance-based intuitions fail.

**24. What is the trace trick, and why is it useful?** trace(AB) = trace(BA) whenever both products are defined. It lets you move a scalar quadratic form x'Ax into trace(Axx'), which is how you pull expectations inside and derive covariance identities and many gradient formulas.

**25. Given a matrix, how would you check numerically whether it is positive definite?** Attempt a Cholesky decomposition. If it succeeds, the matrix is PD; if it fails, it is not. This is faster than computing eigenvalues and is the standard library behavior. The usual fix for a matrix that is PSD in theory but slightly indefinite in floating point is to add a small multiple of the identity.

## 1.12 Assignment and solutions

Attempt everything before reading the solutions. The in-text "Try it" answers come first, then a longer problem set.

### Solutions to the in-text exercises

**1.1.** AB is 3 x 4. Maximum rank 2, since rank(AB) <= min(rank A, rank B) <= 2. It can never have rank 3: every column of AB lies in col(A), which has dimension at most 2.

**1.2.** (a) Rank 1 with null space spanned by (1,1) means every row is orthogonal to (1,1) and the rows are proportional. Rows (1,-1) and (2,-2) work. (b) True. Full column rank means null(A) = {0}, so if Ax = Ay then A(x - y) = 0 forces x = y; there may still be no solution. (c) Because null(A'A) = null(A): if A'Ax = 0 then x'A'Ax = ||Ax||^2 = 0 so Ax = 0, and the converse is immediate. Equal null spaces plus rank-nullity on the same number of columns gives equal ranks.

**1.3.** (a) col(A) has dim 2 in R^5; null(A') has dim 3; row space has dim 2 in R^3; null(A) has dim 1. (b) No: null(A) is nontrivial, so whenever a solution exists there is a whole line of them. (c) Solvable exactly for b in a 2-dimensional subspace of R^5, which has measure zero. A random b is essentially never exactly solvable, which is why we do least squares.

**1.4.** (a) P' = (A(A'A)^{-1}A')' = A((A'A)^{-1})'A' = A(A'A)^{-1}A' = P, using that A'A is symmetric so its inverse is too. And P^2 = A(A'A)^{-1}(A'A)(A'A)^{-1}A' = A(A'A)^{-1}A' = P. (b) trace(P) = 3 = the rank. Eigenvalues: 1 with multiplicity 3, 0 with multiplicity 7. (c) It concentrates at 0, with standard deviation of order 1 over the square root of d. High-dimensional random vectors are nearly orthogonal, so you can pack exponentially many nearly-orthogonal directions into R^d, which is the capacity argument behind wide embedding spaces.

**1.5.** (a) The normal equations are literally X'(y - Xw) = 0, that is X'r = 0. In words: the residual has zero correlation with every feature, so no remaining linear signal is being left on the table. (b) The ridge objective's Hessian is 2(X'X + lambda I), and X'X is PSD so its eigenvalues are >= 0; adding lambda > 0 makes them all >= lambda > 0, hence PD, hence strictly convex with a unique minimizer, regardless of n versus d. (c) OLS becomes degenerate: X'X is singular, and the two duplicated coefficients are determined only in their sum, so there are infinitely many solutions. Ridge stays unique and splits the coefficient evenly between the duplicates, because among all splits with a fixed sum, the equal split minimizes the sum of squares.

**1.6.** (a) rank 2, trace 4, determinant 0. (b) Av = lambda v and A^2 = A give lambda^2 v = A^2 v = Av = lambda v, so lambda^2 = lambda and lambda is 0 or 1. (c) The rotation by 90 degrees, with first column (0,1) and second column (-1,0). It has no real eigenvector because no direction is preserved; its complex eigenvalues are i and -i.

**1.7.** (a) Eigenvalues are 1 + 2 = 3 and 1 - 2 = -1, so the matrix is indefinite: a saddle, despite both diagonal entries being positive. This is the standard counterexample to "positive diagonal implies PD". (b) x'(C'AC)x = (Cx)'A(Cx) >= 0 since A is PSD. (c) x'(A + B)x = x'Ax + x'Bx >= 0. Consequence: adding lambda||w||^2 to a convex loss keeps it convex and in fact makes it strictly convex, which is why ridge and weight decay never introduce new local minima in a convex problem.

**1.8.** (a) The matrix diag(3, -1) has singular values 3 and 1. One valid SVD is U = I, Sigma = diag(3,1), V = diag(1,-1); the sign is absorbed into V. Singular values are never negative. (b) All singular values are 1, so the spectral norm is 1 and kappa = 1: orthogonal maps preserve length exactly. (c) ||A||\_2 = max over unit x of ||Ax||; writing x in the v-basis gives ||Ax||^2 = sum of s\_i^2 c\_i^2 with weights summing to 1, maximized at s\_1. For Frobenius, use ||A||\_F^2 = trace(A'A) = trace(V Sigma^2 V') = trace(Sigma^2) = sum of s\_i^2, using the trace trick.

**1.9.** (a) Sum of squares is 100 + 25 + 1 + 0.01 = 126.01; the top two give 125, so about 99.2 percent. (b) Centering makes the quadratic form you maximize the variance rather than the raw second moment. Without it, the first component points essentially along the mean vector, which usually carries no information about the variation you wanted. (c) 2 x 1024 x 4 = 8192 parameters versus 1024^2 = 1,048,576, so about 0.78 percent.

**1.10.** (a) kappa(X) = 10^4, kappa(X'X) = 10^8. Float32 has about 7 digits, so solving the normal equations in float32 here is hopeless; the QR route with kappa = 10^4 leaves about 3 digits. (b) Ridge replaces the singular values s by (s^2 + lambda)/s in effect; concretely the eigenvalues of X'X are 10^4 and 10^-4, and adding 1 makes them 10001 and about 1, so kappa drops from 10^8 to about 10^4. (c) "Your logits got large, exp overflowed to infinity, and infinity over infinity is NaN. Subtract the row max from the logits before exponentiating: the softmax is unchanged, the largest exponent becomes exactly 1, and nothing overflows. Better still, use the library's fused cross-entropy on raw logits, which does this internally."

### Problem set

**P1 (subspaces).** Let A be the 3 x 3 matrix with rows (1,1,0), (0,1,1), (1,2,1). Find the rank, a basis for each of the four fundamental subspaces, and verify that the two input-side dimensions sum to 3 and that the row space is orthogonal to the null space.

**P2 (projection).** Let a = (1,1,1)' and b = (1,2,3)'. Compute the projection of b onto the line through a, the residual, and verify orthogonality. Then compute the projection matrix onto that line and check it is symmetric, idempotent, of trace 1.

**P3 (least squares by hand).** Fit y = w\_0 + w\_1 x to the three points (0,1), (1,2), (2,2) by forming the design matrix with a column of ones, writing the normal equations, and solving. Then compute the residual vector and verify it is orthogonal to both columns of X.

**P4 (ridge shrinkage).** Suppose X has orthonormal columns, so X'X = I. Show that the ridge solution is the OLS solution scaled by 1/(1 + lambda). Then repeat with a general SVD of X and show the coefficient along v\_i is shrunk by s\_i^2/(s\_i^2 + lambda). Comment on which directions are affected most.

**P5 (spectral theorem in practice).** Let Sigma have diagonal (4, 4) and off-diagonal 2. Find its eigenvalues and an orthonormal eigenbasis. Write Sigma^{1/2} and Sigma^{-1/2}. Describe in words what the whitening transform does to data with this covariance.

**P6 (PSD closure).** Prove or disprove each: (a) the product of two PSD matrices is PSD; (b) the entrywise (Hadamard) product of two PSD matrices is PSD; (c) if A is PSD then every principal submatrix is PSD; (d) if A is PSD then A + A' is PSD.

**P7 (SVD by hand).** Let A be the 2 x 2 matrix with rows (1,1) and (0,1). Compute A'A, its eigenvalues and eigenvectors, and hence the full SVD. Verify that the product reconstructs A and that the singular values give the spectral and Frobenius norms.

**P8 (low rank).** Let A = uv' with u and v nonzero. What is rank(A)? What are its singular values and singular vectors? What is its best rank-1 approximation? What is ||A||\_F in terms of u and v?

**P9 (coding).** In numpy, generate X of shape (200, 50) with correlated columns (for instance, X = Z W where Z is (200, 5) standard normal and W is (5, 50) random). Compute the singular values and plot them on a log scale. Estimate the numerical rank. Then fit least squares to a noisy linear target using (a) `np.linalg.inv(X.T @ X) @ X.T @ y`, (b) `np.linalg.lstsq`, and (c) ridge. Compare the coefficient norms and test errors and explain the differences in terms of conditioning.

**P10 (synthesis).** Explain, in a paragraph an interviewer would be happy with, the chain that connects these five facts: covariance matrices are PSD; PCA maximizes a quadratic form; the SVD of centered data gives the principal directions; the pseudoinverse gives minimum-norm solutions; gradient descent on an overparameterized linear model finds the minimum-norm interpolant.

### Selected solutions

**P1.** Row 3 is row 1 plus row 2, so rank is 2. Row space basis: (1,1,0) and (0,1,1). Null space: solve x\_1 + x\_2 = 0 and x\_2 + x\_3 = 0, giving the span of (1,-1,1), dimension 1. Check 2 + 1 = 3. Column space: first two columns (1,0,1) and (1,1,2) are independent, so they form a basis. Left null space: y with y'A = 0 gives the span of (1,1,-1), dimension 1. Orthogonality check: (1,1,0) dot (1,-1,1) = 0 and (0,1,1) dot (1,-1,1) = 0.

**P2.** a'b = 6, a'a = 3, so the projection is 2a = (2,2,2)' and the residual is (-1,0,1)'. The residual dotted with a is -1 + 0 + 1 = 0. The projection matrix is aa'/3, every entry 1/3; it is visibly symmetric, its square is itself since (aa')(aa') = a(a'a)a' = 3aa', and trace = 1, matching rank 1.

**P3.** X has rows (1,0), (1,1), (1,2) and y = (1,2,2)'. Then X'X has rows (3,3) and (3,5), and X'y = (5, 6)'. Solving 3w\_0 + 3w\_1 = 5 and 3w\_0 + 5w\_1 = 6 gives w\_1 = 1/2 and w\_0 = 7/6. Fitted values (7/6, 5/3, 13/6), residual (-1/6, 1/3, -1/6). Sum of residuals is 0 (orthogonal to the ones column) and residual dotted with (0,1,2) is 0 + 1/3 - 1/3 = 0.

**P4.** With X'X = I, the ridge solution is (I + lambda I)^{-1}X'y = X'y/(1 + lambda), which is the OLS solution divided by 1 + lambda. In general, substitute X = U S V': X'X + lambda I = V(S^2 + lambda I)V' and X'y = V S U'y, so the ridge solution is V diag(s\_i/(s\_i^2 + lambda)) U'y while OLS is V diag(1/s\_i) U'y. The ratio along v\_i is s\_i^2/(s\_i^2 + lambda). Directions with large s\_i (well-determined by the data) are barely shrunk; directions with small s\_i (barely explored) are heavily shrunk. Ridge is a direction-aware shrinkage, which is exactly why it fixes both the variance problem and the conditioning problem at once.

**P6.** (a) **False** in general: the product of two symmetric matrices need not even be symmetric, so it usually fails to be PSD as normally defined. (Its eigenvalues are nonetheless nonnegative when both factors are PSD, which is a genuinely different claim.) (b) **True**, this is the Schur product theorem; it is why products of kernels are kernels. (c) **True**: restrict the quadratic form to vectors supported on the chosen index set. (d) **True** and trivial, since a PSD matrix is symmetric by convention so A + A' = 2A.

**P7.** A'A has rows (1,1) and (1,2). Its eigenvalues solve lambda^2 - 3 lambda + 1 = 0, giving lambda = (3 plus or minus the square root of 5)/2, approximately 2.618 and 0.382. The singular values are the square roots, about 1.618 and 0.618 (the golden ratio and its reciprocal, a pleasant accident). The right singular vectors are the unit eigenvectors of A'A, and u\_i = Av\_i/s\_i. Check: the product of the singular values is 1, matching |det A| = 1; the sum of their squares is 3, matching ||A||\_F^2 = 1 + 1 + 0 + 1 = 3.

**P8.** rank 1. The only nonzero singular value is ||u|| times ||v||, with left singular vector u/||u|| and right singular vector v/||v||. Its best rank-1 approximation is itself. ||A||\_F = ||u|| times ||v||, which you can see from ||A||\_F^2 = trace(A'A) = trace(v u' u v') = ||u||^2 ||v||^2.

**P10.** Sketch of the paragraph you want: the covariance Sigma = X'X/n is PSD because x'Sigma x is the variance of the data projected on x, which cannot be negative. PCA maximizes exactly that quadratic form over unit vectors, and by the spectral theorem the maximum is the top eigenvalue, attained at the top eigenvector; so principal directions are eigenvectors of Sigma, which are the right singular vectors of the centered X, since X = U S V' gives X'X = V S^2 V'. The same decomposition defines the pseudoinverse A+ = V S+ U', which returns the least-squares solution and, when solutions are non-unique, the one of smallest norm, because it puts zero weight on the null-space directions. Finally, gradient descent on an overparameterized linear model started at zero only ever moves within the row space of X (each gradient is X' times something), so it can never acquire a null-space component, and therefore converges to precisely the minimum-norm interpolant, the pseudoinverse solution. One decomposition, the SVD, underlies all five statements.

**P5.** Sigma has diagonal (4,4) and off-diagonal 2. For a symmetric 2x2 with equal diagonals, the eigenvectors are always (1,1)/sqrt2 and (1,-1)/sqrt2. Eigenvalues are 4+2 = 6 and 4-2 = 2. So Sigma = Q diag(6,2) Q'. Then Sigma^{1/2} = Q diag(sqrt6, sqrt2) Q', which has diagonal entries (sqrt6 + sqrt2)/2 = 1.932 and off-diagonal (sqrt6 - sqrt2)/2 = 0.518. Similarly Sigma^{-1/2} = Q diag(1/sqrt6, 1/sqrt2) Q', with diagonal 0.6082 and off-diagonal -0.1457. In words: the data forms an ellipse stretched along the (1,1) direction (variance 6) and compressed along (1,-1) (variance 2). The whitening transform Sigma^{-1/2} rotates into those axes, divides each by its standard deviation so both become 1, and rotates back — turning the ellipse into a circle. Verify by computing Sigma^{-1/2} Sigma Sigma^{-1/2} = I.

**P9 (coding).** What you should observe. (a) With X = ZW for Z of shape (200,5), the true rank is 5, so exactly 5 singular values are large and the remaining 45 are at machine-precision level — on a log plot you see a cliff, not a decay. The numerical rank is 5. (b) The three fits: `inv(X.T @ X) @ X.T @ y` will either raise a singular-matrix error or return wildly large coefficients, because X'X is singular (rank 5, size 50x50). `lstsq` returns the minimum-norm least-squares solution via SVD and behaves gracefully, giving a coefficient vector with small norm. Ridge with any lambda > 0 also behaves, with coefficient norm decreasing as lambda grows. (c) Test errors: the inverse-based solution is catastrophic; lstsq and ridge are comparable, with ridge slightly better if there is noise. The explanation is conditioning: kappa(X) is effectively infinite here, kappa(X'X) is its square, and only the methods that avoid forming or inverting X'X survive. This is section 1.10's argument demonstrated rather than asserted.
