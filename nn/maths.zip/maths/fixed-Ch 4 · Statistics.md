﻿# Chapter 4 · Statistics and Inference

2026-09-22 · @Behi

Probability asks: given a model, what data would I see? Statistics asks the inverse and harder question: given data, what model should I believe? Every training run you will ever launch is an answer to the second question, which is why this chapter is where machine learning stops being applied linear algebra and starts being inference.

The organizing claim, which this chapter earns rather than asserts: **your loss function is a likelihood, your regularizer is a prior, and your validation procedure is an estimator whose bias and variance you should be able to reason about.**

## 4.1 Estimators and how to judge them

### The setup

There is a true parameter theta that you cannot see. You observe data D generated from a distribution depending on theta. An **estimator** is any function of the data that produces a guess:

$$
\hat{\theta} = \hat{\theta}(D)
$$

The crucial move, and the one students skip: **an estimator is a random variable.** Its randomness comes from the data, not from theta (in the frequentist framing theta is fixed). So an estimator has a distribution, called its **sampling distribution**, and every property below is a property of that distribution.

This framing pays off immediately in ML. A trained model is an estimator: run training on a different sample of data and you get a different model. When you ask "how much would my results change with a different train/test split?", you are asking about a sampling distribution. When you report a single validation number without a confidence interval, you are reporting one draw from a distribution and pretending it is the distribution.

### The four criteria

**Bias:** how far off you are on average.

$$
\operatorname{Bias}(\hat{\theta}) = \mathbb{E}[\hat{\theta}] - \theta
$$

**Variance:** how much the estimate moves across datasets.

$$
\operatorname{Var}(\hat{\theta}) = \mathbb{E}\big[(\hat{\theta} - \mathbb{E}[\hat{\theta}])^2\big]
$$

**Mean squared error**, which combines them:

$$
\operatorname{MSE}(\hat{\theta}) = \mathbb{E}\big[(\hat{\theta} - \theta)^2\big] = \operatorname{Bias}^2 + \operatorname{Var}
$$

*Proof, which is one line and worth doing.* Add and subtract E\[theta-hat\] inside the square, expand, and observe that the cross term is 2(E\[theta-hat\] - theta) times E\[theta-hat - E\[theta-hat\]\], whose second factor is zero by definition. So the cross term vanishes and you are left with the squared bias plus the variance. This decomposition is exact, requires no assumptions, and is the skeleton of section 4.2.

**Consistency:** the estimate converges to the truth as data grows.

$$
\hat{\theta}_n \;\xrightarrow{\;p\;}\; \theta \quad \text{as } n \to \infty
$$

Note that consistency and unbiasedness are independent properties. An estimator can be biased at every finite n yet consistent (the MLE for a Gaussian variance, which divides by n); and it can be unbiased yet inconsistent (using only the first observation as your estimate of the mean — unbiased forever, never improving).

**Efficiency:** among estimators in some class, having the smallest variance. Section 4.5 makes "smallest possible" precise via the Cramer-Rao bound.

### Unbiasedness is overrated

This is the section's most important point, and it is a strong interview answer because most candidates treat unbiasedness as an unalloyed good.

**A biased estimator can have much lower MSE.** Ridge regression is biased and routinely beats unbiased OLS in out-of-sample error, because the variance reduction dominates the squared bias it introduces. Shrinking a noisy estimate toward zero or toward a group mean trades a little accuracy on average for a lot of stability.

The canonical demonstration is **Stein's paradox**: for estimating the mean of a d-dimensional Gaussian with d >= 3, the obvious estimator (the sample mean, which is the MLE and is unbiased) is **inadmissible** — the James-Stein estimator, which shrinks it toward an arbitrary point, has strictly lower MSE for every true mean. This is genuinely counterintuitive, since the coordinates are independent and shrinking toward an arbitrary origin should not help. It does, and the mechanism is that in three or more dimensions you can borrow strength across coordinates: the squared norm of the estimate is systematically too large, and shrinking corrects for that. Stein's paradox is the theoretical ancestor of shrinkage, regularization, and hierarchical models, and it is why "regularization helps" is a mathematical fact and not merely an empirical habit.

Other reasons not to worship unbiasedness:

- **It is not preserved under transformation.** If theta-hat is unbiased for theta, then g(theta-hat) is generally biased for g(theta), by Jensen. An unbiased variance estimate has a biased standard deviation.
- **Unbiased estimators sometimes do not exist**, or are absurd. There are textbook cases where the unique unbiased estimator of a probability takes negative values.
- **You usually care about prediction error, not parameter recovery.** MSE on the quantity you care about is the criterion; bias is only an ingredient.

### Estimators you already use

| Estimator | Bias | Note |
| --- | --- | --- |
| sample mean | unbiased | also the MLE for a Gaussian mean |
| sample variance with n - 1 | unbiased | the MLE divides by n and is biased low |
| sample standard deviation | **biased** even with n - 1 | the square root is concave; Jensen |
| training error as an estimate of test error | **biased low** | you optimized on it |
| cross-validation error | slightly biased | trains on less data, so it is pessimistic |
| best-of-k validation score | **biased high** | you took a maximum over noisy estimates |

The last two rows deserve emphasis because they cause real damage. Cross-validation is *pessimistically* biased: each fold trains on (k-1)/k of the data, so it estimates the performance of a model trained on less data than you will actually use. And selecting the best of many configurations by validation score gives an optimistically biased estimate of that configuration's true performance, because the maximum of noisy estimates exceeds the maximum of the true values. **This is why you need a test set you have never selected on**, and it is why leaderboard results drift upward over time without any real progress. That phenomenon has a name — adaptive overfitting — and it is a perfectly good thing to raise in an interview about evaluation.

### Standard errors, and the habit worth forming

The **standard error** is the standard deviation of the sampling distribution. Reporting an estimate without one is reporting half the answer. For a proportion such as accuracy:

$$
\text{SE} = \sqrt{\frac{\hat{p}(1-\hat{p})}{n}}
$$

At 90% accuracy on 1,000 examples, that is about 0.95%, so the 95% interval spans roughly plus or minus 1.9 points. **Two models differing by one point on a 1,000-example test set are not distinguishable**, unless you use a paired test that cancels the shared example difficulty. Forming the habit of computing this takes ten seconds and prevents a large class of wrong conclusions.

**Try it.** (a) Show that the sample mean is unbiased for any distribution with a finite mean, with no other assumptions. (b) You pick the best of 20 hyperparameter configurations by validation accuracy. Is that accuracy an unbiased estimate of the chosen configuration's true accuracy? Explain. (c) Give an estimator that is unbiased but inconsistent, and one that is biased but consistent. Answers in 4.12.

## 4.2 The bias-variance decomposition

### The statement

Suppose y = f(x) + epsilon with noise of mean zero and variance sigma^2, and you fit a model f-hat on a random training set D. Fix a test point x. The expected squared error, averaged over both the noise and the draw of D, decomposes:

$$
\mathbb{E}\big[(y - \hat{f}(x))^2\big] = \underbrace{\sigma^2}_{\text{noise}} + \underbrace{\big(\mathbb{E}[\hat{f}(x)] - f(x)\big)^2}_{\text{bias}^2} + \underbrace{\mathbb{E}\big[(\hat{f}(x) - \mathbb{E}[\hat{f}(x)])^2\big]}_{\text{variance}}
$$

**Derivation.** Write the error as (y - f) + (f - E\[f-hat\]) + (E\[f-hat\] - f-hat). Expand the square. The noise term is independent of everything else, so its cross terms vanish. The remaining cross term contains E\[E\[f-hat\] - f-hat\], which is zero by definition. Three squared terms survive. This is the same algebra as the MSE decomposition in 4.1, with an extra independent noise term bolted on.

### Reading the three terms

| Term | Source | Reducible? | How to reduce |
| --- | --- | --- | --- |
| Noise sigma^2 | inherent randomness in y given x | **no** | nothing; it is the Bayes error |
| Bias^2 | model class too restrictive to represent f | yes | bigger/more flexible model, better features |
| Variance | sensitivity to which training set you drew | yes | more data, regularization, ensembling |

The noise term is the floor. No model, no matter how good, can beat it. When someone reports beating the Bayes error, they have leakage.

The intuition worth carrying: **bias is being consistently wrong, variance is being inconsistently wrong.** A linear model fitting a curve is biased — it misses the same way every time. A deep decision tree is high-variance — it fits each training set faithfully and differently.

### The classical U-curve, and its limits

The traditional picture: as model complexity increases, bias falls and variance rises, so test error is U-shaped with a sweet spot in the middle. This is genuinely true for many classical model families and it explains a great deal — why unpruned trees overfit, why high-degree polynomial fits oscillate, why k in k-NN trades the two off (small k is low-bias high-variance, large k the reverse).

But you should know where the picture is incomplete, because it is a frequent and discriminating interview topic.

**Double descent.** Plot test error against model size past the point where the model can interpolate the training data exactly. Classical theory predicts it keeps getting worse. Empirically, error rises to a peak at the **interpolation threshold** (where parameters roughly equal the number of training examples) and then *descends again*, often to below the classical sweet spot. The same shape appears as a function of data size and of training time.

The standard explanation, which is consistent with Chapter 1: at the interpolation threshold there is essentially one way to fit the data exactly, and it is a terrible, wildly oscillating solution. Beyond that threshold there are infinitely many interpolating solutions, and the optimizer's implicit bias selects a well-behaved one — the minimum-norm solution, which is the pseudoinverse solution. **Overparameterization gives the optimizer room to choose a simple interpolant.** Capacity in the classical counting sense stops being the right measure of complexity; the relevant measure is something like the norm of the solution the optimizer actually finds.

So the honest position, and the one to state: the bias-variance decomposition is an *exact identity* and remains true; what fails is the *heuristic* that parameter count is a proxy for the variance term. Say it that way and you will be right.

### Where each term comes from in practice

**Diagnosing which one you have** is one of the most practically useful skills in applied ML, and the diagnostic is simple: compare training error with validation error.

| Training error | Validation error | Diagnosis | Action |
| --- | --- | --- | --- |
| high | high, similar | underfitting, high bias | bigger model, better features, train longer, lower regularization |
| low | much higher | overfitting, high variance | more data, regularization, augmentation, early stopping, smaller model |
| low | low | fine | ship it |
| high | lower than training | a bug, or heavy train-time regularization (dropout) | check the evaluation pipeline |

The fourth row is worth flagging because it confuses people: with dropout or strong augmentation active at training time and disabled at evaluation, training loss can legitimately exceed validation loss. If that is not the explanation, you have a leak or an evaluation bug.

**Learning curves** (error against training-set size, for both train and validation) distinguish the cases even more reliably. If the two curves have converged and both are high, more data will not help — you have a bias problem. If there is a persistent gap that is still narrowing, more data will help. This is how you decide whether to spend money on labeling or on modeling, which is a genuinely consequential decision and a great answer to "how would you approach improving this model?"

### The variance-reduction toolkit

- **More data.** Variance typically falls as 1/n; bias does not move.
- **Regularization** (L2, L1, dropout, early stopping) deliberately adds bias to cut variance.
- **Bagging and ensembling.** Averaging k models with pairwise correlation rho gives variance (sigma^2/k)(1 + (k-1)rho), so it drives variance toward rho sigma^2. **Decorrelation matters more than count**, which is why random forests subsample features as well as rows, and why ensembling models with different architectures or seeds beats ensembling near-identical ones.
- **Boosting** does the opposite: it reduces bias by sequentially fitting residuals, which is why boosted stumps work despite each stump being nearly useless alone.

### The decomposition does not generalize cleanly

A caveat worth knowing because it catches people out: the clean three-way split relies on squared error. For **0-1 loss** there is no equally clean decomposition — several competing versions exist, and bias and variance can interact rather than add. For cross-entropy there are related decompositions but they are not the familiar sum. So use the decomposition as a conceptual lens for classification, and as an exact identity only for squared error.

**Try it.** (a) For k-nearest neighbours, say what happens to bias and variance as k increases from 1 to n, and identify the two extremes. (b) Your training accuracy is 99% and validation is 78%. Name three interventions, in the order you would try them, and say what you would expect each to do to the two terms. (c) You average 10 models with pairwise correlation 0.9. What fraction of the single-model variance remains, and what does that tell you about ensembling checkpoints from one training run? Answers in 4.12.

## 4.3 Maximum likelihood

### The principle

Choose the parameter that makes the observed data most probable:

$$
\hat{\theta}_{\text{MLE}} = \arg\max_\theta \; p(D \mid \theta) = \arg\max_\theta \; \prod_{i=1}^{n} p(x_i \mid \theta)
$$

In practice you always maximize the log, for three reasons: products underflow, sums differentiate cleanly, and the log is monotonic so the maximizer is unchanged.

$$
\ell(\theta) = \sum_{i=1}^{n} \log p(x_i \mid \theta)
$$

**The likelihood is not a probability distribution over theta.** It is a function of theta for fixed data, and it does not integrate to 1 over theta. Saying "the probability that theta equals 0.7 is high" is a Bayesian statement requiring a prior; the likelihood alone does not license it. This distinction is the cleanest dividing line between the two frameworks and a good thing to state precisely.

### Worked example: the Gaussian

$$
\ell(\mu, \sigma^2) = -\frac{n}{2}\log(2\pi\sigma^2) - \frac{1}{2\sigma^2}\sum_{i=1}^{n}(x_i - \mu)^2
$$

Differentiate with respect to mu: the first term does not involve mu, and the second gives (1/sigma^2) times the sum of (x\_i - mu). Setting it to zero gives the sample mean. Differentiate with respect to sigma^2 and set to zero:

$$
\hat{\mu} = \frac{1}{n}\sum_i x_i, \qquad \hat{\sigma}^2 = \frac{1}{n}\sum_i (x_i - \hat{\mu})^2
$$

The variance MLE divides by **n**, not n - 1, so it is biased low by a factor (n-1)/n. Maximum likelihood does not correct for the degree of freedom spent estimating the mean. This is the standard demonstration that **MLE is not generally unbiased**, and it is a common interview question.

### Every loss function you use is a negative log-likelihood

This is the payoff of the section, and it is worth being able to produce the whole table on demand.

| Assumed noise / output distribution | Negative log-likelihood becomes | Familiar name |
| --- | --- | --- |
| Gaussian, fixed variance | sum of squared residuals | **MSE / L2 loss** |
| Laplace | sum of absolute residuals | **MAE / L1 loss** |
| Bernoulli | -\[y log p + (1-y) log(1-p)\] | **binary cross-entropy** |
| Categorical | -log p of the true class | **cross-entropy** |
| Poisson | lambda - y log lambda | Poisson regression loss |
| Gaussian, learned variance | weighted error plus half log variance | heteroscedastic regression |

The derivations are all the same two lines. For the Gaussian: the log density is a constant minus (residual squared)/(2 sigma^2), so the negative log-likelihood is a constant plus a constant times the sum of squared residuals. For the Bernoulli: p(y|p) = p^y (1-p)^{1-y}, so the log is y log p + (1-y) log(1-p), and the negative of that is binary cross-entropy exactly.

Three consequences worth stating out loud:

1. **Choosing a loss is choosing a noise model.** If you use MSE you have assumed Gaussian homoscedastic noise, whether you meant to or not. If your residuals have outliers, that assumption is wrong and MAE or Huber is the principled fix, not a heuristic one.
2. **Learned-variance regression** falls out immediately: if the model predicts both mu and sigma, the loss is the squared error divided by 2 sigma^2 plus half the log of sigma^2. The first term down-weights examples the model says are noisy; the second stops it from declaring everything noisy. That is how you get a model that reports its own aleatoric uncertainty, and the log term's role is a nice thing to be able to explain.
3. **The clean gradient p - y** from Chapter 2 is not a softmax coincidence. It is the general property of an exponential family with its canonical link, which section 4.4 proves.

### MLE is minimizing KL divergence

A reframing that connects to Chapter 5 and that senior interviewers like:

$$
\arg\max_\theta \frac{1}{n}\sum_i \log p_\theta(x_i) \;\approx\; \arg\max_\theta \; \mathbb{E}_{p_{\text{data}}}[\log p_\theta(x)] \;=\; \arg\min_\theta \; D_{KL}(p_{\text{data}} \,\|\, p_\theta)
$$

The middle step is the law of large numbers; the last holds because the KL equals the cross-entropy minus the data's own entropy, and the latter does not involve theta. So **maximum likelihood is fitting your model to the data distribution in KL, in the forward direction.** That direction is *mass-covering*: the KL blows up wherever the data has mass and the model does not, so an MLE-trained model is heavily penalized for assigning near-zero probability to anything that actually occurred, and consequently prefers to spread mass broadly. This is a direct explanation of why maximum-likelihood generative models produce blurry samples, and why reverse-KL objectives (as in some variational and RL-fine-tuning settings) produce mode-seeking behavior instead. Chapter 5 develops the asymmetry.

### Properties of the MLE

| Property | Holds? | Note |
| --- | --- | --- |
| Consistent | yes, under regularity conditions | converges to the truth |
| Unbiased | **no**, in general | Gaussian variance is the standard counterexample |
| Asymptotically normal | yes | with covariance the inverse Fisher information (4.5) |
| Asymptotically efficient | yes | attains the Cramer-Rao bound in the limit |
| **Invariant under reparameterization** | yes | the MLE of g(theta) is g of the MLE |

That last property is genuinely useful and distinguishes MLE from MAP: if you want the MLE of the standard deviation, take the square root of the MLE of the variance. No such rule holds for MAP estimates, because a prior that is flat in one parameterization is not flat in another, so the MAP estimate moves when you reparameterize. That is a sharp, specific critique of MAP and a strong point to make in an interview.

### When MLE fails

- **Small samples.** Asymptotic guarantees are asymptotic. With few data points the MLE can be wild, and regularization (that is, a prior) is what saves you.
- **Unbounded likelihood.** In a Gaussian mixture, placing one component on a single data point and shrinking its variance to zero sends the likelihood to infinity. The MLE does not exist; you need a prior, a variance floor, or a constraint.
- **Separable data in logistic regression.** If a hyperplane separates the classes perfectly, the likelihood increases without bound as the weights grow, so the MLE is infinite. This is not a bug in your optimizer — it is the correct behavior of an ill-posed problem, and any L2 penalty fixes it. Worth knowing because it explains real "my logistic regression coefficients exploded" incidents.
- **Model misspecification.** If the true distribution is not in your family, the MLE converges to the member of your family closest in KL. That is often a reasonable thing to converge to, but the usual standard errors are then wrong, which is what sandwich or robust covariance estimators exist to fix.

**Try it.** (a) Derive the MLE for the parameter of a Bernoulli from n trials, and confirm it is the sample proportion. (b) Derive the MLE for the rate of an exponential distribution. (c) Show that if the noise is Laplace rather than Gaussian, maximum likelihood gives L1 regression, and explain in one sentence why that makes it robust to outliers. Answers in 4.12.

## 4.4 Exponential families, sufficiency, and GLMs

This section explains *why* the loss table in 4.3 is a table and not a list of coincidences. It is more theoretical than most of this tutorial, and it is worth the effort: it unifies linear regression, logistic regression, softmax classification and Poisson regression into one construction, and it is exactly the kind of structural understanding that separates a strong research candidate from a competent practitioner.

### The form

$$
p(x \mid \eta) = h(x)\,\exp\!\big(\eta^{\top}T(x) - A(\eta)\big)
$$

- **eta** is the **natural parameter**.
- **T(x)** is the **sufficient statistic**.
- **A(eta)** is the **log-partition function**, whose job is normalization: it is the log of the integral of everything else.
- **h(x)** is a base measure you can usually ignore.

The defining structural feature is that x and eta interact **only** through the inner product eta'T(x). Everything else factorizes. That single restriction is what produces all the nice properties below.

### Examples, worked

**Bernoulli.** p(x|p) = p^x (1-p)^{1-x}. Take logs and rearrange:

$$
p^x(1-p)^{1-x} = \exp\!\left( x \log\frac{p}{1-p} + \log(1-p) \right)
$$

So T(x) = x, the natural parameter is eta = log(p/(1-p)) — **the log-odds, which is the logit** — and A(eta) = log(1 + e^eta) = softplus(eta). The logit is not an arbitrary choice of squashing function; it is the natural parameter of the Bernoulli family, and softplus is its log-partition function.

**Gaussian with known variance.** T(x) = x, eta = mu/sigma^2, A(eta) = sigma^2 eta^2/2. With unknown variance, T(x) = (x, x^2), giving two sufficient statistics — the sum and the sum of squares, which is exactly what you needed for the MLE in 4.3.

**Categorical.** T(x) is the one-hot vector, eta is the vector of log-probabilities up to a constant, and **A(eta) = log-sum-exp(eta)**. So softmax being the gradient of log-sum-exp (Chapter 2) is an instance of the general fact below, not a special trick.

Also in the family: Poisson, exponential, gamma, beta, Dirichlet, chi-squared, geometric. Notably **not** in it: the Student-t, the uniform with unknown bounds, and mixtures.

### The three properties that matter

**1. Derivatives of A generate moments.**

$$
\nabla_\eta A(\eta) = \mathbb{E}[T(X)], \qquad \nabla^2_\eta A(\eta) = \operatorname{Cov}(T(X))
$$

*Proof of the first.* A is the log of the integral of h(x) exp(eta'T(x)). Differentiating, the gradient is the integral of T(x) h(x) exp(eta'T(x)) divided by that same integral, which is exactly the expectation of T under the density. The second follows by differentiating again.

Two immediate corollaries. The Hessian of A is a covariance matrix, hence PSD, so **A is always convex**, so the log-likelihood in the natural parameter is always concave and maximum likelihood is a convex problem. And you can read off means and variances by differentiating one function: for the Bernoulli, the derivative of softplus is the sigmoid, recovering E\[x\] = p; differentiate again to get p(1-p), the variance. That is a satisfying two-line derivation of facts you already knew.

**2. Sufficiency: T(x) is all you need.** The likelihood depends on the data only through the sum of T(x\_i). To fit a Gaussian to a billion points you need two numbers. This is the **Fisher-Neyman factorization theorem** in action, and it is why exponential families support constant-memory online updates and why their conjugate priors exist at all.

The converse is a nontrivial theorem (Pitman-Koopman-Darmois): among families with fixed support, **only** exponential families admit a sufficient statistic of fixed dimension. Everything else requires you to keep the whole dataset. That is a strong structural statement and it explains why these families are so over-represented in classical statistics.

**3. Conjugate priors exist and are easy.** Every exponential-family likelihood has a conjugate prior in a matching exponential form, so the posterior stays in the family and updating means adding to the sufficient statistics. Section 4.6 uses this.

### Maximum likelihood in an exponential family

Setting the gradient of the log-likelihood to zero gives something clean:

$$
\nabla_\eta \ell = \sum_i T(x_i) - n\,\nabla A(\eta) = 0 \quad \Longrightarrow \quad \mathbb{E}_{\hat{\eta}}[T(X)] = \frac{1}{n}\sum_i T(x_i)
$$

**Moment matching.** The MLE is the parameter whose model expectation of the sufficient statistic equals the empirical average of it. For a Gaussian, that says match the sample mean and sample second moment. For a categorical, match the empirical class frequencies. This one equation reproduces almost every MLE you have derived by hand, and it is worth recognizing when it appears in a paper's derivation.

### Generalized linear models

Now the construction that ties everything together. A GLM has three ingredients:

1. A **random component**: the response follows some exponential-family distribution.
2. A **linear predictor**: eta\_i = w'x\_i.
3. A **link function** g connecting the mean to the linear predictor: g(mu\_i) = w'x\_i.

When you set the linear predictor equal to the *natural* parameter, you are using the **canonical link**, and that is where the magic happens.

| Model | Distribution | Canonical link | Inverse link | Loss |
| --- | --- | --- | --- | --- |
| Linear regression | Gaussian | identity | identity | squared error |
| Logistic regression | Bernoulli | logit | **sigmoid** | binary cross-entropy |
| Softmax regression | Categorical | log | **softmax** | cross-entropy |
| Poisson regression | Poisson | log | exp | Poisson deviance |

So the sigmoid and the softmax are not chosen because they look like nice squashing functions. **They are the inverse canonical links of the Bernoulli and categorical families**, which is a far better answer to "why sigmoid?" than anything about smoothness or range.

**And the gradient is always the same.** With a canonical link, the gradient of the negative log-likelihood is

$$
\nabla_w \ell = \sum_i \big( \mu_i - y_i \big)\, x_i = X^{\top}(\hat{y} - y)
$$

**Prediction minus target, times the input.** Identical in form for linear, logistic, softmax and Poisson regression. The p - y result from Chapter 2 is this theorem's special case. If an interviewer asks why softmax-with-cross-entropy has such a clean gradient, "canonical link of an exponential family" is the complete answer.

The final connection: **a neural network with a softmax output trained with cross-entropy is a GLM whose features are learned rather than hand-specified.** The last layer is exactly softmax regression; everything before it is learned feature extraction. That framing makes several practices obvious — why you can swap the head for a different task, why linear probing on frozen features is a meaningful diagnostic, and why the final layer's gradient has such a simple form.

**Try it.** (a) Write the Poisson distribution in exponential-family form and identify eta, T, and A. (b) Verify that the derivative of A for the Poisson gives the mean lambda. (c) Explain in two sentences why logistic regression's loss is convex in w, using the properties above. Answers in 4.12.

## 4.5 Fisher information and the Cramer-Rao bound

### The score

The **score** is the gradient of the log-likelihood with respect to the parameter:

$$
s(\theta) = \nabla_\theta \log p(x \mid \theta)
$$

Its first property is the one everything else rests on:

$$
\mathbb{E}_{x \sim p_\theta}\big[ s(\theta) \big] = 0
$$

*Proof, three lines and worth memorizing.* The expected score is the integral of p times the gradient of log p, which by the log-derivative identity equals the integral of the gradient of p, which equals the gradient of the integral of p (swapping derivative and integral, which the regularity conditions permit), which is the gradient of 1, which is 0.

**This identity is load-bearing across the rest of the tutorial.** It is why the REINFORCE estimator is unbiased, why subtracting a baseline from a policy gradient changes nothing in expectation (Chapter 3, section 3.10), and why the Fisher information can be written two different ways below. Being able to produce the three-line proof on demand is genuinely worth the memorization.

### Fisher information

$$
I(\theta) = \mathbb{E}\big[ s(\theta)\,s(\theta)^{\top} \big] = -\,\mathbb{E}\big[ \nabla^2_\theta \log p(x \mid \theta) \big]
$$

Since the score has mean zero, the first expression is its **covariance**. The equality of the two forms (the *information matrix equality*) is a short calculation using the same differentiate-under-the-integral move, and it holds only when the model is correctly specified — which is exactly why the two forms disagree under misspecification, and why the "sandwich" covariance estimator combines both.

**What it means, intuitively.** Fisher information measures **how sharply the likelihood peaks around the true parameter**. A sharply curved log-likelihood means the data strongly discriminates between nearby parameter values, so you can estimate precisely; a flat log-likelihood means many parameter values explain the data about equally well, so you cannot. High curvature equals high information equals low achievable variance. The second form makes this literal: it is the expected negative curvature.

For n i.i.d. observations, information adds: I\_n(theta) = n I\_1(theta). More data, proportionally more information, hence variance falling as 1/n. That is the origin of the 1/sqrt(n) rate seen everywhere in Chapter 3.

### The Cramer-Rao bound

$$
\operatorname{Var}(\hat{\theta}) \;\ge\; \frac{1}{I(\theta)} \qquad \text{(matrix form: } \operatorname{Cov}(\hat{\theta}) \succeq I(\theta)^{-1}\text{)}
$$

for any **unbiased** estimator. This is a fundamental limit: no unbiased estimator, however clever, can beat it. An estimator attaining it is called **efficient**.

*Proof sketch, which is elegant enough to be worth knowing.* Unbiasedness means E\[theta-hat\] = theta; differentiate both sides with respect to theta and move the derivative inside the integral to obtain E\[theta-hat times score\] = 1. Since the score has mean zero, that says Cov(theta-hat, score) = 1. Now apply Cauchy-Schwarz: 1 = Cov(theta-hat, s)^2 <= Var(theta-hat) Var(s) = Var(theta-hat) I(theta). Rearrange. The whole bound is Cauchy-Schwarz applied to the score, which is a nice example of Chapter 1's geometry doing real work in statistics.

The qualification matters: the bound applies to **unbiased** estimators only. Biased estimators can and do have lower MSE, which is section 4.1's point and the reason regularization is not cheating.

### Asymptotic normality of the MLE

The central asymptotic result of classical statistics:

$$
\sqrt{n}\,(\hat{\theta}_{\text{MLE}} - \theta) \;\xrightarrow{\;d\;}\; N\big(0,\; I_1(\theta)^{-1}\big)
$$

So the MLE is asymptotically unbiased, asymptotically normal, and **asymptotically efficient** — it attains the Cramer-Rao bound in the limit. That is a powerful justification for maximum likelihood, and it is the reason standard errors reported by statistical software are typically square roots of the diagonal of the inverse observed information.

The practical recipe that follows: after fitting by maximum likelihood, estimate the Hessian of the negative log-likelihood at the optimum, invert it, and read off standard errors from its diagonal. **The curvature of your loss at the optimum is your uncertainty.** That is a sentence worth internalizing, and it also explains the **Laplace approximation**: approximating the posterior by a Gaussian centered at the mode with covariance the inverse Hessian is exactly this idea used in a Bayesian framing.

### Where this reappears in deep learning

This is not merely classical theory; it shows up in modern work under other names.

- **Natural gradient.** As stated in Chapter 2, preconditioning by the inverse Fisher gives the steepest-descent direction in distribution space rather than parameter space, hence invariance to reparameterization. K-FAC is a tractable approximation. The Fisher is also, for canonical-link losses, exactly the Gauss-Newton matrix, so "natural gradient" and "Gauss-Newton" coincide in the common case.
- **The KL connection.** The Fisher is the Hessian of the KL divergence between p\_theta and p\_{theta + delta}, evaluated at delta = 0. In other words, **the Fisher is the local metric that KL induces on parameter space.** Second-order Taylor expansion of KL gives one half delta' I delta. This is the reason TRPO's KL constraint becomes a Fisher-norm trust region, and it is the single most useful fact linking Chapters 4, 5 and 9.
- **Elastic weight consolidation** for continual learning penalizes changes to parameters weighted by their Fisher information: parameters the old task's likelihood was sensitive to get protected, and flat ones are free to move. That is a direct application of "Fisher measures how much a parameter matters".
- **Influence functions** and data-attribution methods use the inverse Hessian (equivalently the inverse Fisher) to estimate how much a training point affected the final parameters.
- **Pruning criteria.** Some structured pruning methods rank parameters by a Fisher-derived saliency, for the same reason: low information means the loss barely notices if the parameter changes.

### A worked example

For a Bernoulli with parameter p, the log-likelihood of one observation is x log p + (1-x) log(1-p). The score is x/p - (1-x)/(1-p). Differentiating again and taking the negative expectation:

$$
I(p) = \frac{1}{p(1-p)}
$$

So the variance of any unbiased estimator of p is at least p(1-p)/n, and the sample proportion achieves exactly that — the sample mean is efficient. Notice that the information is *smallest* at p = 0.5 and blows up near 0 or 1: **extreme probabilities are easy to pin down, middling ones are hard.** That is a nice intuition, and it is why estimating a click-through rate near 50% takes far more data than confirming that something essentially never happens.

**Try it.** (a) Compute the Fisher information for the mean of a Gaussian with known variance, and confirm the sample mean is efficient. (b) Compute it for the rate of an exponential distribution. (c) Explain in two sentences why the Fisher information being the Hessian of KL makes natural gradient descent reparameterization-invariant. Answers in 4.12.

## 4.6 Bayesian inference

### The move

Treat the parameter as a random variable with a distribution, and use Bayes' rule to update it:

$$
p(\theta \mid D) \;\propto\; p(D \mid \theta)\,p(\theta)
$$

The output is not a point estimate but a whole distribution, which is the entire advantage: **you get uncertainty for free, in the right units, automatically.** A frequentist confidence interval requires extra machinery and has a famously awkward interpretation; a Bayesian credible interval says exactly what everyone wishes a confidence interval said.

|  | Confidence interval (95%) | Credible interval (95%) |
| --- | --- | --- |
| Statement | over repeated experiments, 95% of such intervals contain theta | given this data and prior, there is 95% probability theta is in here |
| theta is | fixed | random |
| The interval is | random | fixed once the data is in |

People routinely interpret confidence intervals as credible intervals. That interpretation is wrong for confidence intervals and correct for credible intervals, and knowing the difference precisely is a standard interview discriminator.

### Conjugacy, and why it is worth knowing

A prior is **conjugate** to a likelihood if the posterior lands in the same family. Then updating is arithmetic on parameters rather than integration.

| Likelihood | Conjugate prior | Posterior update |
| --- | --- | --- |
| Bernoulli / Binomial | Beta(a, b) | Beta(a + successes, b + failures) |
| Categorical / Multinomial | Dirichlet(alpha) | Dirichlet(alpha + counts) |
| Poisson | Gamma(a, b) | Gamma(a + sum of counts, b + n) |
| Gaussian, known variance | Gaussian | precision-weighted average (Chapter 3) |
| Gaussian, unknown variance | Normal-Inverse-Gamma | update all four hyperparameters |

**The Beta-Bernoulli case is worth doing in full**, because it is the engine of Thompson sampling in Chapter 9. Prior Beta(a,b), likelihood p^s (1-p)^f for s successes and f failures. The posterior is proportional to p^{a-1+s}(1-p)^{b-1+f}, which is Beta(a+s, b+f) by inspection. Updating means incrementing two counters, and the prior parameters act as **pseudo-counts**: Beta(1,1) is uniform and represents no prior data, Beta(10,10) represents a fairly confident belief centered at 0.5.

The posterior mean is a weighted average of the prior mean and the empirical rate:

$$
\mathbb{E}[p \mid D] = \frac{a + s}{a + b + n}
$$

With no data it is the prior mean; with lots of data it converges to s/n. **Shrinkage toward the prior, with weight determined by how much data you have**, and this pattern — data overwhelming the prior at rate 1/n — recurs in every conjugate model.

A very practical use: this is exactly how you should rank items by click-through rate when counts are small. An item with 1 click out of 1 impression has an empirical rate of 100%, which is nonsense. The posterior mean under a sensible Beta prior handles it correctly and automatically, and "use a Beta posterior mean instead of the raw ratio" is a good, concrete answer to a ranking-design question.

### Choosing a prior

- **Informative priors** encode real knowledge. Use them when you have it; they are strictly better than pretending you do not.
- **Weakly informative priors** rule out the absurd without committing to much. A Normal(0, 10^2) on a coefficient measured in ordinary units says "probably not a million", which is usually true and helpful. This is the modern default recommendation.
- **Uninformative / flat priors** are a trap. Flatness is not parameterization-invariant: uniform on sigma is not uniform on sigma^2. **Jeffreys priors** (proportional to the square root of the Fisher information determinant) are constructed precisely to be invariant, which is a satisfying use of section 4.5. Flat priors can also be improper (not integrable), which sometimes still yields a proper posterior and sometimes silently does not.
- **Hierarchical priors** put priors on the prior's parameters, letting the data determine how much shrinkage to apply. This is the principled version of Stein's paradox: borrowing strength across related groups. If you have many related small datasets (per-user, per-region, per-item), a hierarchical model is usually the right answer and a strong thing to propose.

The honest framing for a skeptical interviewer: **the prior is not the arbitrary part.** The likelihood — your choice of model family — is a far stronger and less examined assumption, and nobody objects to that one. The prior is simply the assumption that is written down explicitly.

### The posterior predictive

For prediction, do not plug in a point estimate. Average over the posterior:

$$
p(x_{\text{new}} \mid D) = \int p(x_{\text{new}} \mid \theta)\,p(\theta \mid D)\,d\theta
$$

This is the properly Bayesian prediction, and it is **wider** than the plug-in prediction because it accounts for uncertainty about theta as well as noise in the new observation. Plugging in the MAP or MLE and ignoring the integral is exactly how models end up overconfident.

This integral is also the conceptual justification for **ensembles and MC dropout**: averaging predictions over several plausible parameter settings is a crude Monte Carlo approximation to the posterior predictive. Deep ensembles are frequently the best-performing uncertainty method in practice, and this is the framing that explains why.

### When you cannot compute the posterior

The denominator is an integral over all parameters, which is intractable for anything interesting. The options, in order of cost:

| Method | What it gives | Cost |
| --- | --- | --- |
| Conjugacy | exact posterior | free, but rarely available |
| MAP | the mode only, no uncertainty | one optimization |
| Laplace approximation | Gaussian at the mode, covariance from the inverse Hessian | one optimization plus curvature |
| Variational inference | best fit within a tractable family | optimization; biased |
| MCMC | asymptotically exact samples | expensive; correlated samples |
| Deep ensembles | a crude sample of modes | k full training runs |

For deep networks, exact Bayesian inference is hopeless, and the practical landscape is ensembles, MC dropout, Laplace approximations on the last layer, and stochastic-gradient MCMC variants. The honest summary to give in an interview: **deep ensembles are simple, embarrassingly parallel, and remain a strong baseline that more sophisticated approximate-inference methods often fail to beat.**

### MAP, and its defect

$$
\hat{\theta}_{\text{MAP}} = \arg\max_\theta \; \big[ \log p(D \mid \theta) + \log p(\theta) \big]
$$

MAP is the posterior mode: a point estimate that keeps the prior but discards the uncertainty. It is cheap and it is what regularized training computes (section 4.7). Its defect is worth knowing precisely: **the mode is not parameterization-invariant.** Reparameterize and the density picks up a Jacobian factor (Chapter 3, section 3.6), which moves the mode. The MLE does not suffer this, and neither does the posterior *mean*. So MAP is a useful computational device rather than a principled summary, and saying so is a sign you understand what you are doing.

In high dimensions there is a further issue, and it connects directly to Chapter 3's geometry: the mode is not where the mass is. A high-dimensional posterior concentrates on a thin shell, so the MAP point can be wildly unrepresentative of typical posterior draws. This is the same Gaussian-annulus phenomenon, and it is why MAP-based reasoning about high-dimensional posteriors should be treated with suspicion.

**Try it.** (a) You observe 3 heads in 10 flips with a Beta(2,2) prior. Give the posterior, its mean, and compare with the MLE. (b) Why is the posterior predictive wider than plugging in the posterior mean? (c) Give a concrete case where the MAP estimate is a bad summary of the posterior. Answers in 4.12.

## 4.7 MAP as regularization

This short section is the payoff of the chapter for a practitioner: it shows that the regularizers you already use are priors, and that their hyperparameters have meanings rather than being knobs.

### The general correspondence

$$
\hat{\theta}_{\text{MAP}} = \arg\min_\theta \; \underbrace{\big[-\log p(D \mid \theta)\big]}_{\text{loss}} \; + \; \underbrace{\big[-\log p(\theta)\big]}_{\text{regularizer}}
$$

**Negative log-prior is the penalty.** That is the whole correspondence, and every case below is one substitution away.

### Ridge is a Gaussian prior

Put a Gaussian prior on the weights, w \~ N(0, tau^2 I). Then

$$
-\log p(w) = \frac{1}{2\tau^2}\lVert w \rVert_2^2 + \text{const}
$$

So the MAP objective is the squared-error loss plus lambda times the squared L2 norm, with

$$
\lambda = \frac{\sigma^2}{\tau^2}
$$

The regularization strength is **the ratio of noise variance to prior variance**. That is not a metaphor; it is the exact relationship. Read what it says: if the data is noisy (large sigma^2), regularize more; if you genuinely believe the weights could be large (large tau^2), regularize less. The hyperparameter you tune by cross-validation has a precise meaning, and if you happen to know the noise level and a plausible weight scale, you can set it directly.

### Lasso is a Laplace prior

A Laplace prior, p(w) proportional to exp(-|w|/b), gives

$$
-\log p(w) = \frac{1}{b}\sum_j |w_j| + \text{const}
$$

which is L1. The sparsity follows from the shape of the prior: a Laplace density has a sharp peak at zero with a non-vanishing derivative, so the penalty keeps pulling until a coefficient hits exactly zero, while a Gaussian's derivative goes to zero at the origin and so releases its grip. This is the analytic version of the corner-of-the-L1-ball picture in Chapter 1, and quoting both pictures is a strong answer.

One honest caveat: the *Bayesian posterior* under a Laplace prior is not sparse — its mode is, but samples from it are not, since a continuous posterior assigns zero probability to any coefficient being exactly zero. Lasso's sparsity is a property of the MAP point, not of Bayesian inference with that prior. The genuinely Bayesian sparsity-inducing priors are spike-and-slab and the horseshoe. This is a point that distinguishes people who have read carefully.

### The rest of the correspondence

| Regularizer | Equivalent prior | Note |
| --- | --- | --- |
| L2 / weight decay | Gaussian, zero mean | lambda = sigma^2/tau^2 |
| L1 / lasso | Laplace | MAP-sparse only |
| Elastic net | Gaussian-Laplace mixture |  |
| Early stopping | approximately a Gaussian prior | provably equivalent for linear models with gradient descent |
| Data augmentation | a prior encoding invariances | the most informative prior most people use |
| Dropout | approximately Bayesian model averaging | under specific assumptions |
| Max-norm constraint | a uniform prior on a ball | a hard constraint rather than a penalty |

**Early stopping** deserves a note. For a linear model trained by gradient descent from zero, stopping early is equivalent to an L2 penalty whose strength decreases with the number of steps taken: gradient descent fits high-curvature directions first and low-curvature ones later, so stopping early means the poorly determined directions are still near zero. That is exactly what ridge does (section 1.5's SVD analysis), and the equivalence is a genuinely satisfying result to be able to state.

**Data augmentation** is the one to emphasize in an applied interview, because it is a prior and nobody calls it one. Augmenting with rotations says "I believe the label is invariant to rotation", which is a strong and usually correct statement about the world. It is generally more valuable than any norm penalty, because it encodes real structure rather than a generic preference for small numbers.

### Weight decay in deep learning: three caveats

The correspondence is clean for linear models. In deep networks there are wrinkles worth knowing, and they come up in practical interviews.

1. **AdamW exists for a reason.** L2 penalty and weight decay are the same thing for plain SGD, but not for adaptive optimizers. Adding a penalty to the loss means the gradient of that penalty gets divided by the adaptive per-coordinate scale, so parameters with large gradient history get *less* decay — the opposite of what you want. Decoupled weight decay applies the shrinkage directly to the parameters instead. This is the single most commonly asked optimizer-detail question.
2. **Normalization layers break the interpretation.** If a layer is followed by BatchNorm or LayerNorm, scaling its weights up leaves the function unchanged, so the L2 penalty on those weights is not penalizing function complexity at all — it is changing the effective learning rate by controlling the weight norm. This is why weight decay on normalization parameters and biases is usually excluded, and why the effect of weight decay in modern networks is partly an optimization effect rather than a capacity effect.
3. **A zero-mean Gaussian prior on a deep network's weights is not an obviously sensible belief.** It is a mathematically convenient default whose success is largely empirical. Being willing to say that, rather than over-claiming a Bayesian justification, is the intellectually honest position.

### The summary worth memorizing

**Loss = negative log-likelihood. Regularizer = negative log-prior. Training = MAP estimation. Ensembling = approximating the posterior predictive.** Four sentences that organize most of supervised learning, and any one of them is a good thing to have ready when an interviewer asks what regularization "really" is.

**Try it.** (a) You believe your weights are around 0.1 in magnitude and your noise standard deviation is about 0.5. What lambda does the correspondence suggest for ridge? (b) Explain why L2 regularization on a layer followed by BatchNorm does not constrain the function class. (c) Why does AdamW decouple weight decay, and what goes wrong if you do not? Answers in 4.12.

## 4.8 Hypothesis testing, honestly

Most ML practitioners meet hypothesis testing only when a reviewer asks whether an improvement is significant. That is a low bar to clear and most people clear it badly. This section is aimed at clearing it properly.

### The machinery

- **Null hypothesis H0:** the boring explanation, typically "no difference".
- **Test statistic:** a number summarizing the data whose distribution under H0 you know.
- **p-value:** the probability, **if H0 were true**, of seeing a test statistic at least as extreme as the one observed.
- **Significance level alpha:** the false-positive rate you are willing to accept, conventionally 0.05 for no defensible reason.
- **Power:** the probability of detecting a real effect of a given size. Usually ignored, and usually the thing that actually matters.

|  | H0 true | H0 false |
| --- | --- | --- |
| Reject H0 | **Type I error** (false positive), rate alpha | correct detection, rate = power |
| Fail to reject | correct | **Type II error** (false negative), rate beta |

### What a p-value is not

This list is worth memorizing, because every item is a mistake that appears in published papers.

- **It is not the probability that H0 is true.** That is a posterior and requires a prior. p is computed *assuming* H0.
- **It is not the probability that your result was a fluke.**
- **It is not a measure of effect size.** With a large enough n, a completely trivial difference is highly significant. Statistical significance and practical significance are different questions.
- **1 - p is not the probability the alternative is true.**
- **A non-significant result is not evidence of no effect.** It is failure to detect one, which may just mean insufficient power.

The single best habit: **report effect sizes with confidence intervals, not just p-values.** "Accuracy improved by 1.2 points, 95% CI \[0.3, 2.1\]" tells the reader everything the p-value would and more.

### Multiple comparisons, which is the ML-relevant part

Run 20 independent tests at alpha = 0.05 with no real effects anywhere, and the probability of at least one "significant" result is 1 - 0.95^20, about 64%. Run 100 and you will almost certainly find several.

This is exactly what hyperparameter search does. **Trying 50 configurations and reporting the best validation score is running 50 tests and reporting the winner.** The reported score is biased upward, and the amount of bias grows with the number of configurations tried. The same applies to trying many random seeds, many architectures, or many prompt variants.

Corrections, in order of conservatism:

- **Bonferroni:** test at alpha/m. Controls the probability of *any* false positive, and is very conservative when the tests are correlated.
- **Benjamini-Hochberg:** controls the **false discovery rate**, the expected fraction of your discoveries that are false. Much more powerful, and usually the right choice when you are screening many candidates.
- **A held-out test set touched once.** For ML this is the real answer. All selection happens on validation; the test set is used exactly once, at the end. If you look at the test set and then change something, it is no longer a test set.

### Tests you will actually want

| Situation | Test |
| --- | --- |
| Two models, same test set, per-example outcomes | **paired** test: McNemar for classification, paired t-test or bootstrap for continuous metrics |
| Two independent samples, means | two-sample t-test, or Mann-Whitney without normality |
| Comparing several models across several datasets | Friedman test, then post-hoc pairwise with correction |
| Proportions from independent samples | two-proportion z-test or chi-squared |
| Anything awkward | **bootstrap the difference** and read off the interval |

**Always pair when you can.** Comparing two models on the same test set means each example contributes to both, so the difference has far lower variance than the two accuracies separately — the shared difficulty cancels, exactly the common-random-numbers argument from Chapter 3. **McNemar's test** is the right paired test for classification: it looks only at examples where the two models disagree, and asks whether the disagreements split evenly. Examples both models get right or both get wrong carry no information about which is better, so discarding them is not a loss.

And when a test's assumptions are awkward or you cannot find the right one, **bootstrap**. Resample the test set with replacement a few thousand times, recompute the difference in metric each time, and take the 2.5th and 97.5th percentiles. It handles any metric, including non-differentiable ranking metrics that have no analytic standard error, and requires almost no assumptions. Section 4.9 covers it properly.

### The practical checklist for evaluating a model change

1. Decide the metric and the minimum improvement that would matter **before** looking.
2. Compute the power: given the test-set size and metric variance, could you even detect that improvement? If not, get more data or stop.
3. Use a paired comparison on identical data, with several seeds if training is stochastic.
4. Report the effect size with a confidence interval, not a p-value alone.
5. Report how many configurations you tried. That number is part of the result.
6. Confirm on a test set that has not been used for any selection.

Step 5 is the one almost nobody does and the one that most improves the trustworthiness of a result.

### Seeds, and a common mistake

If training is stochastic, a single run is a single draw. Comparing one run of A with one run of B tells you very little when seed-to-seed variance is comparable to the effect. **Run several seeds and compare distributions**, and report the variability. If seed variance exceeds your claimed improvement, you have not demonstrated anything — and noticing that about your own result before a reviewer does is a genuinely valuable habit.

**Try it.** (a) You try 30 hyperparameter configurations and the best has validation accuracy 2 points above the second best. What is your concern, and how would you check it? (b) Model A and Model B each get 91% on a 2,000-example test set but disagree on 120 examples, with A correct on 70 of those. Apply McNemar's reasoning informally: is A better? (c) Why is a paired test more powerful than an unpaired one here? Answers in 4.12.

## 4.9 Bootstrap, cross-validation, model selection

### The bootstrap

You want the sampling distribution of an estimator but you have only one dataset. The bootstrap's idea is audacious and it works: **treat your sample as if it were the population, and resample from it.**

The procedure: draw n points with replacement from your n data points, recompute the statistic, repeat B times (1,000 to 10,000), and use the spread of those B values as the sampling distribution. A 95% interval is the 2.5th and 97.5th percentiles of the bootstrap values (the percentile method; more refined variants exist, such as BCa, which corrects for bias and skewness).

**Why it works, intuitively.** The relationship between your sample and the resamples mimics the relationship between the population and your sample. If resampling perturbs the statistic a lot, then drawing a new dataset would too.

Its virtues for ML evaluation are substantial:

- It works for **any** statistic — medians, correlations, AUC, BLEU, F1, nDCG — including ones with no closed-form standard error at all. That alone makes it the default tool.
- It requires no distributional assumptions.
- It is trivially parallel, and cheap if the statistic is cheap to recompute.

Where it fails, and you should know these: extremes (the maximum of a distribution — resampling can never produce a value larger than your observed maximum), heavy-tailed data with infinite variance, very small samples, and dependent data such as time series, where you need a block bootstrap that resamples contiguous blocks to preserve the correlation structure.

Note that each bootstrap resample omits about 1/e, roughly 37%, of the original points, since the probability of a given point never being drawn in n tries is (1 - 1/n)^n. Those left-out points form the **out-of-bag** sample, which is what random forests use for free validation without a held-out set.

### Cross-validation

**k-fold:** split into k parts, train on k-1 and evaluate on the held-out one, rotate, average.

| Choice | Trade-off |
| --- | --- |
| k = 5 or 10 | the standard compromise; usually the right default |
| k = n (leave-one-out) | nearly unbiased but high variance and expensive; the models are highly correlated |
| small k | cheaper, but each model trains on much less data, so more pessimistic bias |

The bias here is **pessimistic**: every fold's model trains on less data than your final model will, so CV systematically underestimates the performance of the model you actually ship. This matters most when the learning curve is still steep, that is, when data is scarce.

**The ways people get CV wrong**, which are what interviews actually probe:

1. **Preprocessing outside the loop.** Fitting a scaler, imputer, feature selector or PCA on the full dataset before splitting leaks test information into training. Everything data-dependent must be fit inside each fold. This is the most common evaluation bug in real projects.
2. **Ignoring group structure.** If the same patient, user, or document appears in multiple rows, random splitting puts correlated rows on both sides and the estimate is wildly optimistic. Use grouped splits.
3. **Random splits on time series.** Training on the future to predict the past is not a thing you can do at deployment. Use forward-chaining splits where each fold trains only on data preceding its validation window.
4. **Selecting and evaluating on the same folds.** If you use CV to choose hyperparameters, the resulting CV score is optimistically biased for the chosen configuration. **Nested cross-validation** fixes this: an inner loop selects, an outer loop evaluates. It is expensive and it is the correct thing to do when you must report an honest number from limited data.
5. **Not stratifying.** With imbalanced classes, random folds can have very different class ratios. Stratify.

### Model selection criteria

When you want to compare models without a validation set, or want a principled penalty for complexity:

$$
\text{AIC} = -2\ell + 2k, \qquad \text{BIC} = -2\ell + k\log n
$$

with ell the maximized log-likelihood and k the number of parameters. Lower is better in both.

|  | AIC | BIC |
| --- | --- | --- |
| Derived from | expected out-of-sample KL (asymptotically equals leave-one-out CV) | an approximation to the log marginal likelihood |
| Goal | best **prediction** | identifying the **true** model, if it is in the set |
| Penalty | 2 per parameter | log(n) per parameter, so harsher for n > 7 |
| Tends to | select larger models | select smaller models |

Both are essentially useless for deep networks, and it is worth saying why rather than just noting it: the parameter count k bears no relation to effective complexity in an overparameterized model, and the asymptotic derivations assume the number of parameters is fixed while n grows, which is precisely the opposite of the modern regime. Use held-out validation instead.

### The marginal likelihood

The Bayesian model-comparison quantity:

$$
p(D \mid M) = \int p(D \mid \theta, M)\,p(\theta \mid M)\,d\theta
$$

The ratio of two of these is a **Bayes factor**. What makes the marginal likelihood interesting is that it **automatically penalizes complexity** without any explicit penalty term. A flexible model spreads its prior predictive mass over many possible datasets, so it assigns less mass to the one you actually saw; a simple model concentrates its mass, so if the data falls in that concentrated region it wins. This is often called the Bayesian Occam's razor, and it is an elegant argument worth being able to give.

In practice the integral is intractable, it is far more sensitive to the prior than the posterior is (a prior that barely changes your posterior can change your marginal likelihood by orders of magnitude), and for deep networks it is hopeless. Know the concept, do not reach for it operationally.

### Which to use, practically

- **Plenty of data:** a single train/validation/test split is fine and far cheaper.
- **Limited data:** k-fold CV, nested if you are selecting and must report honestly.
- **Uncertainty on a metric:** bootstrap the test set.
- **Comparing two models:** paired comparison on identical data, plus a bootstrap or McNemar interval on the difference.
- **Time series:** forward-chaining splits, always.
- **Deep learning:** a fixed validation set, several seeds, and a test set you touch once.

**Try it.** (a) You fit a StandardScaler on the whole dataset, then run 5-fold CV. What exactly leaked, and will the effect be large or small? (b) Why does leave-one-out CV have high variance despite low bias? (c) You have 500 labeled examples and need to both tune and report. Describe your procedure precisely. Answers in 4.12.

## 4.10 Calibration and proper scoring rules

A model that outputs 0.9 should be right about 90% of the time when it says 0.9. If it is not, its probabilities are decorative. This matters enormously for anything where a downstream decision depends on the confidence — selective prediction, routing between a small and a large model, human handoff, risk-sensitive decisions, and agentic systems that must decide whether to act or to ask.

### Definition

A model is **calibrated** if

$$
P\big(y = 1 \;\big|\; \hat{p}(x) = q\big) = q \quad \text{for all } q \in [0,1]
$$

Among all examples where the model said 0.7, exactly 70% should be positive.

**Calibration is not accuracy, and neither implies the other.** A model that always outputs the base rate is perfectly calibrated and useless. A model that is always right but outputs 0.51 is perfectly accurate and badly calibrated. What you want is **sharpness subject to calibration**: confident predictions that are also correct.

### Measuring it

**Reliability diagram.** Bin predictions by confidence, plot the mean confidence in each bin against the observed accuracy in that bin. Perfect calibration is the diagonal. Above the diagonal is underconfidence; below is overconfidence.

**Expected calibration error (ECE):** the weighted average gap between confidence and accuracy across bins.

$$
\text{ECE} = \sum_{b=1}^{B} \frac{n_b}{n} \left| \text{acc}(b) - \text{conf}(b) \right|
$$

Be aware of ECE's flaws, since they are a good sign of careful thinking: it depends on the binning scheme, it can be zero for a model that is miscalibrated in ways that cancel across bins, and it is a biased estimate with finite samples. Report a reliability diagram alongside it rather than a single number.

### Proper scoring rules

A scoring rule is **proper** if it is optimized by reporting your true beliefs, and **strictly proper** if truth-telling is the unique optimum. This is the key concept, because it tells you which losses you can trust to produce honest probabilities.

| Rule | Formula | Proper? |
| --- | --- | --- |
| Log loss / cross-entropy | -log p(true class) | **strictly proper** |
| Brier score | squared difference between predicted probability and outcome | **strictly proper** |
| Accuracy | fraction correct | **not proper** |
| MAE on probabilities | absolute difference | **not proper** |

**Why accuracy is improper, and why it matters.** If your true belief is 0.6, you maximize expected accuracy by predicting 1.0 with full confidence, since accuracy only looks at the argmax. So a model trained or selected on accuracy has no incentive to report honest probabilities. This is a clean, concrete reason to train with cross-entropy even when accuracy is the metric you report, and it is a good answer to "why not just optimize accuracy directly?" alongside the differentiability answer.

The **Brier score decomposes** in a way that makes the tension explicit: it splits into uncertainty (irreducible), minus resolution (how much your predictions vary with the outcome, which you want large), plus reliability (miscalibration, which you want zero). This is the formal version of "sharpness subject to calibration".

### Why modern networks are miscalibrated

The empirical finding, well established since around 2017, is that modern deep networks are **overconfident** — more so than the smaller, shallower networks that preceded them, despite being more accurate. The contributing factors:

- Training to near-zero loss pushes the softmax toward one-hot outputs long after the classification decisions have stopped changing.
- Capacity and modern regularization choices (less weight decay, batch norm) correlate with worse calibration.
- Cross-entropy on hard one-hot labels asks the model to be infinitely confident, and the model obliges as far as it can.

### Fixing it

**Temperature scaling** is the first thing to try and usually the best value for the effort. Divide the logits by a single scalar T fit on a validation set to minimize NLL:

$$
\hat{p} = \operatorname{softmax}(z / T)
$$

T > 1 softens the distribution and reduces overconfidence. It has **one parameter**, it is fit post-hoc in seconds, and crucially **it cannot change the argmax**, so accuracy is exactly preserved. There is almost never a reason not to do it.

Other options: **Platt scaling** (a logistic regression on the scores) and **isotonic regression** (a nonparametric monotone fit, more flexible but prone to overfitting with little data) for binary problems; **label smoothing** during training, which replaces hard targets with slightly softened ones and improves calibration though it can hurt the usefulness of the resulting features; **ensembles**, which improve calibration substantially and essentially for free if you were going to train several models anyway; and **focal loss**, which has been observed to produce better-calibrated models than cross-entropy in some settings.

**Always fit calibration on held-out data.** Fitting temperature on the training set is pointless, since the model is already overfit there and the fitted temperature will be near 1.

### Distribution shift

The uncomfortable fact worth stating: **calibration does not survive distribution shift.** A model calibrated on its validation distribution becomes overconfident on out-of-distribution inputs, and temperature scaling does not fix this, because the single temperature was fit for the old distribution. Detecting shift and handling it is a separate problem from calibration, and conflating them is a common error. For agentic systems this is the crux — a model that is well calibrated on benchmark distributions may be confidently wrong on the inputs your deployment actually produces, which is precisely when you most need its confidence to be trustworthy.

**Try it.** (a) A model outputs 0.9 on 1,000 examples and is correct on 700 of them. Is it over- or underconfident, and what is the contribution to ECE from this bin? (b) Show that predicting the base rate always is perfectly calibrated, and say why it is useless. (c) Explain why temperature scaling cannot change accuracy. Answers in 4.12.

## 4.11 Interview drill set

**1. What is an estimator, and why is it a random variable?** A function of the data producing a guess at a parameter. It is random because the data is random; its distribution is the sampling distribution, and bias, variance and standard error are all properties of it.

**2. Decompose MSE.** MSE equals squared bias plus variance. The cross term vanishes because the deviation of an estimator from its own mean has expectation zero.

**3. Is an unbiased estimator always preferable?** No. A biased estimator can have much lower MSE, which is exactly what ridge exploits. Stein's paradox shows the sample mean is inadmissible in three or more dimensions: shrinking it strictly improves MSE.

**4. State the bias-variance decomposition of prediction error.** Expected squared error equals irreducible noise plus squared bias plus variance. Noise is the Bayes floor; bias comes from a model class that cannot express the truth; variance from sensitivity to the training sample.

**5. Does bias-variance explain deep learning?** The identity is exact and still holds. What fails is the heuristic that parameter count tracks variance: past the interpolation threshold, test error descends again, because the optimizer's implicit bias selects a well-behaved interpolant among the infinitely many available.

**6. How do you tell overfitting from underfitting?** Compare train and validation error. Both high and similar means high bias. Train low, validation much higher means high variance. Learning curves as a function of training-set size tell you whether more data would help.

**7. Derive MLE for a Gaussian and comment on the variance.** The mean MLE is the sample mean. The variance MLE divides by n, not n - 1, so it is biased low: MLE does not account for the degree of freedom spent estimating the mean.

**8. Why is MSE the loss for regression and cross-entropy for classification?** Both are negative log-likelihoods: Gaussian noise gives squared error, Bernoulli or categorical outputs give cross-entropy. Choosing a loss is choosing a noise model.

**9. What loss should you use if the residuals have outliers?** L1 or Huber, which correspond to Laplace or a Gaussian-Laplace hybrid noise model. A heavier-tailed likelihood makes large residuals less surprising, so they pull less on the fit.

**10. What is maximum likelihood minimizing, in divergence terms?** Forward KL from the data distribution to the model. That direction is mass-covering, which is why maximum-likelihood generative models spread probability broadly and produce blurry samples.

**11. What is an exponential family and why care?** Densities of the form h(x) exp(eta'T(x) - A(eta)). Derivatives of A give the mean and covariance of T; A is convex so MLE is a convex problem; sufficient statistics of fixed size exist; and conjugate priors are available.

**12. Why sigmoid for binary and softmax for multiclass?** They are the inverse canonical links of the Bernoulli and categorical families. That is also why the gradient is prediction minus target in both cases.

**13. What is a sufficient statistic?** A function of the data carrying all information about the parameter; the likelihood factors through it. For a Gaussian it is the sum and the sum of squares, so a billion points compress to two numbers.

**14. What is the score and what is its expectation?** The gradient of the log-likelihood with respect to the parameter. Its expectation under the model is zero, which is why REINFORCE is unbiased and why baselines do not bias policy gradients.

**15. What is Fisher information, intuitively?** The curvature of the expected log-likelihood, equivalently the covariance of the score. It measures how sharply the data distinguishes nearby parameter values, and more information means a lower achievable variance.

**16. State the Cramer-Rao bound and its limitation.** Any unbiased estimator has variance at least the inverse Fisher information. The limitation is the word unbiased: biased estimators can beat it in MSE.

**17. What is the asymptotic distribution of the MLE?** Normal, centered at the truth, with covariance the inverse Fisher information over n. So the MLE is asymptotically efficient, and standard errors come from the inverse Hessian at the optimum.

**18. How do Fisher information and KL relate?** The Fisher is the Hessian of KL between the model at theta and at a nearby theta. So it is the local metric KL induces on parameter space, which is why natural gradient is reparameterization-invariant and why TRPO's KL constraint is a Fisher trust region.

**19. Confidence interval versus credible interval?** A confidence interval is random and 95% of such intervals would cover the fixed parameter over repeated experiments. A credible interval is fixed given the data and contains the parameter with 95% posterior probability. People routinely give the second interpretation to the first.

**20. Show that ridge is MAP with a Gaussian prior.** Negative log-prior for a zero-mean Gaussian is the squared L2 norm over twice the prior variance, so the MAP objective is squared error plus lambda times squared norm with lambda equal to the noise variance over the prior variance.

**21. Why is lasso sparse and ridge not?** Laplace prior versus Gaussian. The absolute value's derivative does not vanish at zero, so the penalty keeps pulling until coefficients hit exactly zero; the Gaussian's does vanish, so it merely shrinks. Geometrically, the L1 ball's corners lie on the axes.

**22. Why does AdamW decouple weight decay?** Because an L2 term added to the loss gets divided by Adam's per-coordinate scaling, so parameters with large gradient history receive less decay than intended. Decoupling applies the shrinkage directly to the parameters.

**23. What is a p-value, and three things it is not?** The probability of data at least this extreme under the null. It is not the probability the null is true, not the probability the result is a fluke, and not a measure of effect size.

**24. You tried 50 hyperparameter configurations. What is wrong with reporting the best validation score?** It is the maximum of 50 noisy estimates, so it is optimistically biased for the chosen configuration's true performance. You need a test set not used for selection, and you should report how many configurations you tried.

**25. How do you compare two models on the same test set?** A paired test, because the shared example difficulty cancels and the variance of the difference drops sharply. McNemar for classification, or bootstrap the paired difference for any metric.

**26. What is the bootstrap and when does it fail?** Resample your data with replacement and use the spread of the recomputed statistic as its sampling distribution. It fails for extremes such as the maximum, for infinite-variance data, for very small samples, and for dependent data unless you use a block bootstrap.

**27. Name three ways cross-validation is commonly done wrong.** Fitting preprocessing outside the fold loop; random splits when rows are grouped by user or patient; random splits on time series; and using the same folds to select and to report.

**28. What is calibration, and how is it different from accuracy?** A calibrated model's stated confidence matches its empirical accuracy at that confidence. Neither implies the other: always predicting the base rate is calibrated and useless; always correct at 0.51 is accurate and miscalibrated.

**29. What is a proper scoring rule, and is accuracy one?** A rule maximized by reporting your true beliefs. Log loss and Brier are strictly proper; accuracy is not, since with a true belief of 0.6 you maximize expected accuracy by claiming certainty.

**30. How do you fix an overconfident classifier?** Temperature scaling: divide the logits by a scalar fit on held-out data to minimize NLL. One parameter, seconds to fit, and it cannot change the argmax so accuracy is preserved. Note that it does not survive distribution shift.

## 4.12 Assignment and solutions

### Solutions to the in-text exercises

**4.1.** (a) E\[sample mean\] = (1/n) times the sum of E\[x\_i\] = (1/n)(n mu) = mu. Only linearity of expectation and a finite mean are used; no independence, no distributional assumption. (b) No, it is optimistically biased. You selected the maximum over 20 noisy estimates, and E\[max of noisy estimates\] exceeds the max of the true values. The gap grows with the number of configurations and with the noise level. Fix it by evaluating the selected configuration on a fresh held-out set. (c) Unbiased but inconsistent: use x\_1 alone as the estimate of the mean — unbiased for every n, but its variance never shrinks. Biased but consistent: the MLE of a Gaussian variance, which is biased by the factor (n-1)/n but converges to the truth.

**4.2.** (a) k = 1 is maximum variance and minimum bias: it fits every training point exactly and changes completely with a new sample. k = n predicts the global mean for every input: zero variance, maximum bias. Bias rises and variance falls monotonically in k. (b) Likely order: (i) add regularization or augmentation, which raises bias and cuts variance; (ii) get more data, which cuts variance without touching bias; (iii) reduce model size or use early stopping, same trade as (i). All three target the variance term, which is what a 21-point gap indicates. (c) Variance is (sigma^2/10)(1 + 9 x 0.9) = sigma^2(9.1/10) = 0.91 sigma^2. Only 9% of the variance is removed. **Ensembling checkpoints from a single run buys you very little**, because those models are highly correlated; ensembling independent runs with different seeds and initializations buys much more.

**4.3.** (a) The log-likelihood is s log p + (n - s) log(1 - p) for s successes. Differentiating gives s/p - (n-s)/(1-p) = 0, hence p = s/n. (b) For Exponential(lambda), the log-likelihood is n log lambda - lambda times the sum of x\_i; differentiating gives n/lambda - sum = 0, so lambda-hat = 1/x-bar, the reciprocal of the sample mean. (c) The Laplace log density is a constant minus |x - mu|/b, so the negative log-likelihood is proportional to the sum of absolute residuals. It is robust because a Laplace distribution has exponentially rather than Gaussian-decaying tails, so a residual of size 10 is far less surprising and contributes a gradient of constant magnitude rather than one proportional to the residual.

**4.4.** (a) Poisson(lambda) has pmf lambda^x e^{-lambda}/x!, which is (1/x!) exp(x log lambda - lambda). So T(x) = x, eta = log lambda, A(eta) = lambda = e^eta, h(x) = 1/x!. Note that the natural parameter is the log of the rate, which is exactly why Poisson regression uses a log link. (b) The derivative of A = e^eta is e^eta = lambda, which is indeed E\[X\]. Differentiating again also gives lambda, recovering the Poisson's variance-equals-mean property in one step. (c) The negative log-likelihood in the natural parameter is a linear term minus A(eta), and A is convex because its Hessian is a covariance matrix; the natural parameter is itself linear in w, and composing a convex function with a linear map preserves convexity. Hence the loss is convex in w.

**4.5.** (a) The log-likelihood for one observation is a constant minus (x - mu)^2/(2 sigma^2). The second derivative with respect to mu is -1/sigma^2, so I(mu) = 1/sigma^2 and for n observations n/sigma^2. The Cramer-Rao bound is therefore sigma^2/n, which the sample mean attains exactly. It is efficient at every n, not just asymptotically. (b) For Exponential(lambda), the log density is log lambda - lambda x; the second derivative is -1/lambda^2, so I(lambda) = 1/lambda^2. (c) Natural gradient takes the steepest step measured by KL, and KL between two distributions is a property of the distributions themselves, not of the coordinates you used to name them. Since the Fisher is the local quadratic form of KL, preconditioning by its inverse cancels exactly the distortion that a change of parameterization introduces.

**4.6.** (a) Posterior is Beta(2 + 3, 2 + 7) = Beta(5, 9). Its mean is 5/14 = 0.357, versus the MLE of 0.3. The prior pulls the estimate toward 0.5, and with only 10 observations it still has noticeable influence. (b) Because it integrates over the posterior rather than conditioning on a single theta, so it includes parameter uncertainty in addition to observation noise. Plugging in a point estimate discards the first source entirely and produces intervals that are too narrow. (c) A bimodal posterior with a narrow tall spike and a broad short bump: the MAP sits on the spike even if the bump holds most of the probability mass. More generally, in high dimensions the mode is not where the mass is, by the Gaussian-annulus argument of Chapter 3.

**4.7.** (a) lambda = sigma^2/tau^2 = 0.25/0.01 = 25. Notice how strong the implied regularization is when you genuinely believe weights are small relative to the noise. (b) Because BatchNorm normalizes its input, scaling the preceding weight matrix by any positive constant leaves the layer's output unchanged. The function computed is invariant to the weight norm, so penalizing the norm does not restrict the set of functions representable — it only changes the optimization dynamics by controlling the effective learning rate. (c) Adam divides each coordinate's update by the square root of its running second moment. An L2 term inside the loss gets divided by that same quantity, so coordinates with historically large gradients receive proportionally less decay, which is backwards. AdamW applies the decay directly to the parameters after the adaptive step, restoring the intended uniform shrinkage.

**4.8.** (a) The concern is selection bias: the best of 30 noisy validation scores is optimistically biased, and a 2-point gap over the runner-up may be noise if the validation standard error is around a point. Check by re-evaluating the top few configurations on a fresh split or with several seeds, and compare the gap with the seed-to-seed spread. (b) Discordant pairs: A right and B wrong on 70, B right and A wrong on 50. Under the null of equal skill, these 120 should split evenly, so 70 versus 50 is 10 above the expected 60, with standard deviation sqrt(120 x 0.25) = 5.48. That is about 1.8 standard deviations, roughly p = 0.07 — suggestive, not conclusive. (c) Because the two models are evaluated on identical examples, so the shared difficulty of those examples is differenced away. The variance of the difference is Var(A) + Var(B) - 2Cov(A,B), and the covariance is large and positive.

**4.9.** (a) The scaler's mean and standard deviation were computed using the validation fold's data, so each fold's model saw summary information about its own validation set. The effect is usually small for simple scaling on large datasets and can be severe for feature selection, target encoding or imputation, where far more information leaks. The rule is the same regardless: fit inside the loop. (b) The n models differ by only one training point each, so their predictions are highly correlated, and averaging highly correlated quantities removes little variance — the same mechanism as the ensembling calculation in 4.2(c). (c) Nested cross-validation: an outer 5-fold loop for reporting; inside each outer training portion, an inner 5-fold loop to select hyperparameters; then refit on the full outer training portion with the selected hyperparameters and evaluate on the outer test fold. Report the mean and spread of the five outer scores, and state the procedure explicitly.

**4.10.** (a) It claimed 0.9 and delivered 0.7, so it is overconfident by 0.2. If this bin holds all 1,000 examples, its contribution to ECE is 1.0 x 0.2 = 0.2, which is very poor calibration. (b) Predicting the base rate q for every example means that among all examples where the model says q, the empirical rate is exactly the base rate q, satisfying the definition. It is useless because it has zero resolution: its predictions do not vary with the input, so they carry no information for any decision. (c) Because dividing all logits by a positive constant is a monotone transformation that preserves their ordering, and the argmax depends only on the ordering.

### Problem set

**P1 (estimator properties).** For n i.i.d. Uniform(0, theta) observations, consider two estimators: twice the sample mean, and the sample maximum. (a) Show the first is unbiased. (b) Find the bias of the second and correct it. (c) Compare their variances for large n and say which you would use and why.

**P2 (MLE).** Derive the MLE for logistic regression's weights, show that no closed form exists, and identify the resulting optimization problem. State why it is convex and what happens when the classes are perfectly separable.

**P3 (exponential family).** Write the Gaussian with unknown mean and variance in exponential-family form. Identify the natural parameters and sufficient statistics, and verify that the derivative of A recovers the mean and second moment.

**P4 (Fisher).** Compute the Fisher information matrix for a Gaussian with both mean and variance unknown. Comment on whether it is diagonal and what that implies about the two estimates.

**P5 (Bayes).** A/B test: 120 conversions from 1,000 for A, 150 from 1,000 for B. Using Beta(1,1) priors, give both posteriors, and estimate the probability that B beats A. Describe how you would compute this exactly and how you would approximate it.

**P6 (MAP).** Show that MAP with a Gaussian prior on the weights of a linear model with Gaussian noise gives exactly ridge regression, deriving the correspondence between the prior variance and the penalty coefficient.

**P7 (evaluation design).** You must decide whether a new model is better than the current production model. Write a full evaluation protocol: metric, test-set size justification via a power calculation, comparison method, number of seeds, and what you would report.

**P8 (bootstrap).** Explain precisely how to compute a 95% confidence interval for the difference in F1 between two models on the same test set. Say why bootstrapping the *difference* is different from bootstrapping each F1 separately.

**P9 (coding).** (a) Simulate the bias of the MLE variance estimator for n = 5, 10, 100 and confirm the (n-1)/n factor. (b) Demonstrate double descent on a small random-feature regression by sweeping the number of features across the interpolation threshold. (c) Fit temperature scaling on a deliberately overconfident classifier and plot before-and-after reliability diagrams.

**P10 (synthesis).** Explain in one paragraph why these are the same idea: the MSE decomposition; the bias-variance decomposition; ridge regression beating OLS; Stein's paradox; and a prior improving an estimate.

### Selected solutions

**P1.** (a) E\[x\_i\] = theta/2, so twice the sample mean has expectation theta. (b) The maximum M has CDF (m/theta)^n on \[0, theta\], hence density n m^{n-1}/theta^n and mean n theta/(n+1). It is biased low, which is obvious since the maximum can never exceed theta. The corrected estimator is (n+1)/n times M, which is unbiased. (c) Var of the moment estimator is theta^2/(3n), falling as 1/n. Var of the corrected maximum is of order theta^2/n^2, falling as 1/n^2. **The maximum is dramatically better**, which is a surprise if you expect the sample mean to be the natural estimator. The reason is that the maximum is a sufficient statistic for this family while the mean is not, and the uniform's boundary carries far more information about theta than its center does. Note that this family is *not* an exponential family — its support depends on the parameter — which is exactly why the usual asymptotics do not apply here.

**P2.** The log-likelihood is the sum of y\_i log sigma(w'x\_i) + (1-y\_i) log(1 - sigma(w'x\_i)). By the canonical-link result in section 4.4, the gradient is X'(sigma(Xw) - y), which is a transcendental equation with no closed-form root. It is convex because the Hessian is X' diag(p(1-p)) X, a congruence of a PSD diagonal matrix, hence PSD by the Chapter 1 result. Solve by gradient descent, Newton (which here is iteratively reweighted least squares), or L-BFGS. Under perfect separation, scaling any separating w upward drives every predicted probability toward the correct extreme and the likelihood toward its supremum without attaining it, so the MLE is infinite. Any L2 penalty makes the objective strictly convex and coercive, restoring a finite unique solution.

**P4.** For a Gaussian with parameters (mu, sigma^2), the Fisher matrix is diagonal with entries 1/sigma^2 and 1/(2 sigma^4). **It is diagonal**, which means the MLEs of the mean and the variance are asymptotically uncorrelated: an error in estimating the mean does not systematically distort the variance estimate. This orthogonality is a special and convenient property, and it is why you can quote separate standard errors for the two without worrying about their interaction. It also explains why the natural parameterization matters: the same model in a different parameterization generally has a non-diagonal Fisher.

**P5.** Posteriors are Beta(121, 881) for A and Beta(151, 851) for B, with means 0.1207 and 0.1507. The exact probability that B beats A is a double integral with a closed form as a sum of Beta functions, but the practical approach is Monte Carlo: draw 100,000 samples from each posterior and compute the fraction where B's draw exceeds A's. The posterior standard deviations are about 0.0103 and 0.0113, so the difference of 0.03 is roughly two combined standard deviations, giving a probability around 0.97 that B is better. Report that number rather than a p-value, because "97% probability B is better" is what the decision-maker actually wants and is a legitimate Bayesian statement.

**P10.** All five are the statement that **accepting some bias to reduce variance can lower total error, because error is squared bias plus variance and the two are tradeable.** The MSE decomposition is the identity itself; the bias-variance decomposition is the same identity applied to prediction error with an extra irreducible noise term; ridge introduces deliberate bias by shrinking coefficients, and when the variance reduction exceeds the squared bias it wins out of sample; Stein's paradox is the striking demonstration that this is available *for free* in three or more dimensions, since shrinkage improves MSE for every true parameter value; and a prior is simply the principled, explicit way of specifying what to shrink toward and how hard. Regularization is not a hack bolted onto estimation. It is what optimal estimation looks like once you stop insisting on unbiasedness.

**P3.** The Gaussian in exponential-family form with both parameters unknown. Expand the log density:

$$
\log p(x) = -\frac{x^2}{2\sigma^2} + \frac{\mu x}{\sigma^2} - \frac{\mu^2}{2\sigma^2} - \tfrac{1}{2}\log(2\pi\sigma^2)
$$

So T(x) = (x, x^2), the natural parameters are eta = (mu/sigma^2, -1/(2 sigma^2)), the base measure h(x) = 1, and

$$
A(\eta) = \frac{\mu^2}{2\sigma^2} + \tfrac{1}{2}\log(2\pi\sigma^2) = -\frac{\eta_1^2}{4\eta_2} - \tfrac{1}{2}\log(-2\eta_2) + \tfrac{1}{2}\log(2\pi)
$$

Differentiating A with respect to eta\_1 gives -eta\_1/(2 eta\_2) = mu, which is E\[X\]. Differentiating with respect to eta\_2 gives eta\_1^2/(4 eta\_2^2) - 1/(2 eta\_2) = mu^2 + sigma^2, which is E\[X^2\]. Both match the general theorem that the gradient of A is E\[T(X)\], and the fact that the two sufficient statistics are the sum and the sum of squares is exactly why those two numbers suffice to fit a Gaussian to any amount of data.

**P6.** MAP with a Gaussian prior. Take y = Xw + noise with noise variance sigma^2, and prior w \~ N(0, tau^2 I). The log posterior is the log likelihood plus the log prior, up to a constant:

$$
\log p(w\mid D) = -\frac{1}{2\sigma^2}\lVert Xw - y\rVert^2 - \frac{1}{2\tau^2}\lVert w\rVert^2 + \text{const}
$$

Maximizing is minimizing the negative, and multiplying through by 2 sigma^2 (which does not change the argmin) gives

$$
\lVert Xw - y\rVert^2 + \frac{\sigma^2}{\tau^2}\lVert w \rVert^2
$$

which is ridge with lambda = sigma^2/tau^2. Setting the gradient to zero gives (X'X + lambda I)w = X'y. **The correspondence is exact, and lambda is the noise-to-prior variance ratio** — not a metaphor but the literal identity.

**P7.** A full evaluation protocol. (i) **Metric and threshold first**: decide, before looking at anything, which metric matters and what improvement would change your decision — say 0.5 points of accuracy. (ii) **Power calculation**: the standard error of a paired difference in accuracy on n examples is roughly sqrt(2 p(1-p)(1-rho)/n) where rho is the correlation between the models' correctness. For two similar models rho is high (often 0.8 or more), which helps a great deal; at p = 0.9, rho = 0.8 and n = 5,000, the standard error is about 0.38 points, so a 0.5-point difference is barely detectable and you should get more test data or accept that you cannot resolve it. (iii) **Paired comparison** on identical examples, using McNemar or a paired bootstrap. (iv) **Several seeds**, at least 3 to 5, comparing distributions rather than point estimates; if the seed spread exceeds your claimed improvement, you have not demonstrated anything. (v) **Report**: effect size with a confidence interval, the number of configurations tried, the number of seeds, and confirmation on a test set never used for selection.

**P8.** Bootstrapping the difference in F1. Resample **example indices** once per bootstrap iteration, and use that same index set to compute F1 for both models. Recompute the difference, repeat 10,000 times, and take the 2.5th and 97.5th percentiles of the differences.

Why this differs from bootstrapping each F1 separately: if you resample independently for each model, you destroy the pairing, and the variance of the difference becomes Var(A) + Var(B) instead of Var(A) + Var(B) - 2Cov(A,B). Since the two models succeed and fail on largely the same examples, that covariance is large and positive, so the paired interval is much narrower. **Independent resampling can easily double the width of your interval and turn a real difference into a non-result.** This is the common-random-numbers principle from Chapter 3, and F1 is a case where it matters especially, because F1 has no closed-form standard error at all.

**P9 (coding).** Expected observations. (a) The MLE variance estimator's mean over many simulations should sit at (n-1)/n times the true variance: 0.8 at n = 5, 0.9 at n = 10, 0.99 at n = 100 — a clear, systematic, shrinking bias. (b) Double descent: sweep the number of random features from well below to well above the number of training points. Test error falls, then rises to a sharp peak exactly where features equal examples, then falls again, often below the first minimum. Add small ridge regularization and the peak flattens substantially — which is the tell that the peak is a conditioning phenomenon, not a mystery. (c) Temperature scaling: the before-diagram shows points below the diagonal (overconfident); after fitting T on held-out data, the points lie close to the diagonal and the fitted T exceeds 1. Confirm that accuracy is bit-for-bit identical before and after, since a monotone transform of the logits cannot change the argmax.
