﻿# Chapter 3 · Probability

2026-09-22 · @Behi

Machine learning is applied probability wearing a linear algebra costume. A loss is a negative log-likelihood, a regularizer is a prior, a model output is a distribution, and generalization is a statement about what happens when you average over data you have not seen. This chapter builds the probability you need to read that sentence and agree with it.

You already know basic probability, so this chapter moves fast through the definitions and spends its time on the parts that stay hard: the multivariate Gaussian, change of variables, concentration, and what high dimensions actually do to your intuition.

## 3.1 The three objects you actually use

Probability has a reputation for being conceptually slippery, and the reason is usually that three different objects get called by the same letter. Separate them once and most confusion goes away.

### Sample space, random variable, distribution

1. The **sample space** is the set of things that could happen. Call it Omega. You will almost never mention it again, but knowing it exists resolves questions like "what does it mean for two random variables to be dependent?" (they are functions on the same Omega).
2. A **random variable** is a *function* from Omega to numbers. X is not a number and it is not a distribution; it is a rule assigning a number to each outcome. This is why X + Y makes sense (add the outputs pointwise) and why X and Y can be dependent (they read the same underlying outcome).
3. A **distribution** is the induced assignment of probability to values of X. It is what you actually compute with: a PMF for discrete X, a PDF for continuous X, or a CDF for either.

The notation X \~ N(0, 1) says "X is a random variable whose distribution is standard normal". Two different random variables can have the same distribution while being completely different functions: if X \~ N(0,1) then -X \~ N(0,1) too, but X and -X are perfectly anti-correlated. Conflating a variable with its distribution is the root of a surprising share of student errors, and it matters in ML whenever you care about *coupling* between samples (shared randomness, common random numbers, antithetic variates).

### The measure-theoretic bit, stated without the machinery

You do not need measure theory for ML, but you need the two facts it exists to fix.

**Fact 1: a density is not a probability.** For continuous X, P(X = x) = 0 for every single x. The density p(x) is not a probability, it is a probability *per unit volume*, and it can exceed 1. A Gaussian with standard deviation 0.01 has a peak density of about 40. Probabilities come from integrating:

$$
P(a \le X \le b) = \int_a^b p(x)\,dx, \qquad P(X \in A) = \int_A p(x)\,dx
$$

This matters practically. When you report a "log likelihood" of a continuous model, you are reporting a log density, which is why it can be positive, why it changes if you rescale your units, and why comparing log likelihoods across different data preprocessing is meaningless. Bits-per-dimension in image modeling exists precisely to make these numbers comparable.

**Fact 2: densities do not transform like functions.** If y = g(x), the density of Y is not p(g^{-1}(y)); it picks up a Jacobian factor, because volumes get stretched. Section 3.6 develops this; it is the single most useful "advanced" fact in this chapter and underlies normalizing flows.

The general framing that unifies discrete and continuous: a distribution assigns a number to *sets*, not to points, and an expectation is an integral against that assignment. When you see the notation E\[f(X)\] without a sum or integral sign, read it as "average f over the distribution", and you will never need to ask whether the case is discrete or continuous.

### CDFs, and the one trick they give you

$$
F_X(x) = P(X \le x), \qquad p(x) = \frac{dF}{dx}
$$

The CDF is defined for every random variable, discrete or continuous, and it is non-decreasing from 0 to 1. Its practical payoff is the **inverse transform sampling** method: if U is uniform on \[0,1\], then F^{-1}(U) has distribution F. This is how many samplers are built, and it is worth being able to state.

The companion fact, the **probability integral transform**, is that F(X) is uniform on \[0,1\] when F is continuous. That is the basis of p-values, of QQ plots, and of copula methods.

### Two interpretations, and why ML uses both

|  | Frequentist | Bayesian |
| --- | --- | --- |
| Probability means | long-run frequency | degree of belief |
| Parameters are | fixed but unknown | random variables with distributions |
| You compute | estimators, confidence intervals | posteriors, credible intervals |
| ML example | ERM, MLE, cross-validation | MAP, Bayesian neural nets, Thompson sampling |

This is not a war you need to take sides in. The practically useful position is that they are two toolkits, and the right question is which one answers your question. Chapter 4 shows that many standard methods have both readings: ridge regression is simultaneously a penalized least-squares estimator and a MAP estimate under a Gaussian prior. Being able to move between the two framings fluently is a research-level skill and a common interview probe.

One place the distinction genuinely bites in agentic AI: Thompson sampling (Chapter 9) is Bayesian in an essential way. It samples from a posterior over reward parameters and acts greedily with respect to the sample. There is no frequentist restatement that keeps the algorithm the same, and the exploration behavior falls out of the posterior's uncertainty.

**Try it.** (a) Can a probability density exceed 1? Give an example, and explain why it does not contradict anything. (b) If X \~ Uniform(0,1), what is the distribution of -log X? (c) X and -X have the same distribution but correlation -1. Explain, in terms of the definitions above, why that is not a contradiction. Answers in 3.12.

## 3.2 Joint, conditional, independence, Bayes

### The three distributions and how they relate

$$
p(x, y) = p(x \mid y)\,p(y) = p(y \mid x)\,p(x), \qquad p(x) = \int p(x,y)\,dy
$$

**Marginalizing** means integrating out a variable you do not care about; **conditioning** means restricting to a slice and renormalizing. Those two operations are the entirety of probabilistic inference. Every algorithm in graphical models, variational inference, and probabilistic programming is a scheme for doing one or both of them efficiently when the integral is intractable.

The **chain rule of probability** generalizes this to any number of variables and any ordering:

$$
p(x_1, \ldots, x_n) = \prod_{i=1}^{n} p(x_i \mid x_1, \ldots, x_{i-1})
$$

This identity is exact, requires no assumptions, and is the entire mathematical basis of autoregressive language models. A transformer models p(token\_i | previous tokens), and multiplying those conditionals reconstructs the joint distribution over sequences exactly. When you hear "next-token prediction is enough to model language", this factorization is the reason it is not obviously false.

### Independence, and the subtler conditional version

**Independent:** p(x, y) = p(x)p(y), equivalently p(x|y) = p(x). Knowing y tells you nothing about x.

**Conditionally independent given z:** p(x, y | z) = p(x|z) p(y|z). Knowing y tells you nothing *extra* about x once you already know z.

Neither implies the other, and both directions of failure have memorable examples.

- **Independent but not conditionally independent.** Two independent coin flips X and Y, and Z = X XOR Y. Given Z, knowing X determines Y exactly. Conditioning *created* dependence. This is the "explaining away" pattern: a common effect couples its causes.
- **Conditionally independent but not independent.** Height and vocabulary size in children are strongly correlated, but given age they are nearly independent. The correlation was entirely mediated by a common cause.

That second pattern is the whole reason naive Bayes works at all despite its assumption being false, and the first is why you must be careful about what you condition on: **conditioning on a collider induces spurious correlation.** This is selection bias in its cleanest form, and it explains a large class of real failures, from "why do hospital patients show a negative correlation between two unrelated diseases" to why filtering your training data on an outcome variable can manufacture associations that are not in the world.

### Bayes' rule, and how to actually think about it

$$
p(\theta \mid D) = \frac{p(D \mid \theta)\, p(\theta)}{p(D)}, \qquad p(D) = \int p(D \mid \theta)\,p(\theta)\,d\theta
$$

| Term | Name | Role |
| --- | --- | --- |
| p(theta \| D) | posterior | belief after seeing data |
| p(D \| theta) | likelihood | how well each theta explains the data |
| p(theta) | prior | belief before |
| p(D) | evidence / marginal likelihood | normalizer; also the model-comparison score |

The useful mental compression: **posterior is proportional to likelihood times prior.** The denominator is just whatever makes it integrate to 1, and you can often ignore it — which is exactly what MCMC and MAP estimation do. When you cannot ignore it (model comparison, or the ELBO in variational inference) it is usually the hard part of the whole problem.

**The base rate example, because it is asked constantly.** A test is 99% sensitive and 99% specific; the disease affects 1 in 10,000. You test positive. What is the probability you have it?

$$
P(D \mid +) = \frac{0.99 \times 0.0001}{0.99 \times 0.0001 + 0.01 \times 0.9999} \approx \frac{0.000099}{0.010098} \approx 0.0098
$$

About 1%. The intuition that makes it obvious without arithmetic: out of a million people, 100 have the disease and about 99 test positive; 999,900 do not and about 9,999 of them test positive anyway. The false positives outnumber the true positives 100 to 1 because the healthy group is enormous. **Always convert to counts out of a large population; base-rate problems become trivial.**

The ML lesson generalizes: with a rare positive class, a classifier's precision is dominated by the false-positive rate on the huge negative class, which is why accuracy is a useless metric on imbalanced data and why precision-recall curves are preferred to ROC curves there.

### Odds form, which is often cleaner

$$
\underbrace{\frac{p(\theta_1 \mid D)}{p(\theta_2 \mid D)}}_{\text{posterior odds}} = \underbrace{\frac{p(D \mid \theta_1)}{p(D \mid \theta_2)}}_{\text{likelihood ratio}} \times \underbrace{\frac{p(\theta_1)}{p(\theta_2)}}_{\text{prior odds}}
$$

The evidence cancels. In log form this becomes addition, so **each piece of evidence adds a fixed number of "log-odds" (its log likelihood ratio) to your belief.** This is why logistic regression's output is a log-odds, why its coefficients add, and why the logit is the natural scale for combining independent evidence.

### Graphical model reading, in brief

Three-node patterns you should be able to identify on sight, because they determine what conditioning does:

| Structure | Shape | Are the ends independent? | Given the middle? |
| --- | --- | --- | --- |
| Chain | X to Z to Y | no | **yes** |
| Fork (common cause) | X from Z to Y | no | **yes** |
| Collider (common effect) | X to Z from Y | **yes** | no |

The collider row is the one people get wrong. Conditioning on a common effect, or on any of its descendants, creates dependence between its causes. If you remember one thing from this section, remember that conditioning is not always "more information is better" — it changes the dependency structure, sometimes for the worse.

**Try it.** (a) Give a concrete example where X and Y are dependent but conditionally independent given Z, drawn from ML rather than genetics. (b) A spam filter uses naive Bayes. State the independence assumption precisely and say why it is false but useful. (c) A test has 99% sensitivity and specificity, and the base rate is 50%. Redo the calculation and explain why the answer changes so dramatically. Answers in 3.12.

## 3.3 Expectation, variance, covariance

This section is a toolkit. The identities look boring written down, but you will use them dozens of times in Chapters 4 through 9, and fluency here is the difference between deriving something in two minutes and being stuck for twenty.

### Expectation

$$
\mathbb{E}[X] = \sum_x x\,p(x) \quad \text{or} \quad \int x\,p(x)\,dx, \qquad \mathbb{E}[g(X)] = \int g(x)\,p(x)\,dx
$$

The second form is worth naming: it is sometimes called the **law of the unconscious statistician**, and it says you can compute the expectation of g(X) without ever finding the distribution of g(X). That is a large convenience and it is used constantly.

**Linearity is the workhorse, and it needs no independence whatsoever:**

$$
\mathbb{E}[aX + bY + c] = a\,\mathbb{E}[X] + b\,\mathbb{E}[Y] + c
$$

This holds for dependent, correlated, adversarially coupled variables. It is the reason indicator-variable arguments are so powerful: to count expected occurrences of something, write the count as a sum of indicators and add their probabilities, ignoring all the horrible dependence between them. That single trick solves an entire genre of interview problems.

**Independence buys you products:** if X and Y are independent, E\[XY\] = E\[X\]E\[Y\]. The converse is false, and that failure is the content of the correlation-versus-dependence distinction below.

### Variance and covariance

$$
\operatorname{Var}(X) = \mathbb{E}[(X - \mu)^2] = \mathbb{E}[X^2] - (\mathbb{E}[X])^2
$$

$$
\operatorname{Cov}(X,Y) = \mathbb{E}[(X-\mu_X)(Y-\mu_Y)] = \mathbb{E}[XY] - \mathbb{E}[X]\mathbb{E}[Y]
$$

The identities to have memorized:

| Identity | Note |
| --- | --- |
| Var(aX + b) = a^2 Var(X) | shifts do not matter, scales square |
| Var(X + Y) = Var(X) + Var(Y) + 2Cov(X,Y) | the cross term is the whole story |
| Var(sum of independent X\_i) = sum of Var(X\_i) | **variances add for independent variables, standard deviations do not** |
| Cov(X, X) = Var(X) |  |
| Corr(X,Y) = Cov(X,Y) / (sd\_X sd\_Y), in \[-1,1\] | bounded by Cauchy-Schwarz (section 1.4) |
| Var(a'X) = a' Sigma a for a random vector X | the PSD identity from section 1.7 |

The third row is the most-used fact in all of applied statistics. Averaging n independent samples gives variance sigma^2/n, hence standard error sigma/sqrt(n). **The square root is why halving your error costs four times the data**, and why large-batch training gives diminishing returns on gradient-noise reduction, and why Monte Carlo is slow but dimension-independent.

Note also the computational warning from section 1.10: do not compute variance as E\[X^2\] - (E\[X\])^2 on real data. For large means the two terms nearly cancel and you lose precision, sometimes producing a negative variance. Use Welford's online algorithm or a two-pass method.

### Correlation is not dependence

Zero correlation means no *linear* relationship. Let X \~ N(0,1) and Y = X^2. Then Cov(X, Y) = E\[X^3\] = 0 by symmetry, so they are uncorrelated, while Y is a deterministic function of X. Complete dependence, zero correlation.

For **jointly Gaussian** variables, and only then among the common cases, uncorrelated does imply independent. This exception is worth remembering precisely because it is an exception, and because it is why PCA (which only decorrelates) is equivalent to independence-seeking for Gaussian data but not in general — which is exactly the gap that ICA exists to fill.

### Conditional expectation, and the two laws

E\[X | Y\] is a **random variable**, not a number: it is a function of Y, and Y is random. Once you accept that, the two laws below are natural.

**Tower property (law of total expectation):**

$$
\mathbb{E}[X] = \mathbb{E}\big[\, \mathbb{E}[X \mid Y] \,\big]
$$

Average within groups, then average the group averages, weighted by group size. This is the identity behind almost every proof in reinforcement learning, because a value function *is* a conditional expectation and the Bellman equation *is* the tower property.

**Law of total variance:**

$$
\operatorname{Var}(X) = \underbrace{\mathbb{E}\big[\operatorname{Var}(X \mid Y)\big]}_{\text{unexplained}} + \underbrace{\operatorname{Var}\big(\mathbb{E}[X \mid Y]\big)}_{\text{explained}}
$$

Total variation splits into within-group variation and between-group variation. This decomposition is the skeleton of the **bias-variance decomposition** in Chapter 4, of ANOVA, and of the distinction between aleatoric uncertainty (irreducible noise in X given Y) and epistemic uncertainty (variation in what you believe). If a model can reduce its error by learning more, that error is in the second term; if not, it is in the first.

A useful corollary: E\[X | Y\] is the function of Y that minimizes expected squared error in predicting X. **The conditional expectation is the best possible regression function**, and everything a supervised learner does with squared loss is an attempt to approximate it. That is worth stating in an interview, because it explains *why* squared loss targets the mean while absolute loss targets the median.

### Random vectors

For X a random vector with mean mu:

$$
\Sigma = \mathbb{E}[(X-\mu)(X-\mu)^{\top}], \qquad \operatorname{Cov}(AX + b) = A\Sigma A^{\top}
$$

That transformation rule is used constantly: it is how you propagate uncertainty through a linear layer, how Kalman filters update, and how the reparameterization trick produces a target covariance from standard noise (section 3.6). Sigma is symmetric PSD, by the one-line proof in section 1.7.

### The estimators you will write

$$
\hat{\mu} = \frac{1}{n}\sum_i x_i, \qquad \hat{\sigma}^2_{\text{unbiased}} = \frac{1}{n-1}\sum_i (x_i - \hat{\mu})^2
$$

**Why n - 1?** Because you estimated the mean from the same data, so the deviations are measured from a point chosen to minimize them, making them systematically too small. You have spent one degree of freedom. Dividing by n - 1 corrects exactly for this in expectation. If the true mean were known and used, you would divide by n.

The honest caveat, which is a nice thing to know: the n - 1 estimator is unbiased for the *variance*, but its square root is still biased for the standard deviation, because the square root is concave and Jensen's inequality (below) bites. Unbiasedness does not survive nonlinear transformations.

### Jensen's inequality

$$
\mathbb{E}[g(X)] \ge g(\mathbb{E}[X]) \quad \text{for convex } g, \qquad \le \text{ for concave } g
$$

The picture: a chord of a convex function lies above the function, and an expectation is a weighted average, that is, a point on a chord. Uses you will meet: E\[X^2\] >= (E\[X\])^2, which is just Var >= 0; the derivation of the **ELBO** in variational inference, which is Jensen applied to a log; the nonnegativity of KL divergence in Chapter 5; and the reason log E\[...\] and E\[log ...\] differ, which is a distinction that matters a great deal in RL objectives and in evaluating language models.

**Try it.** (a) In a random permutation of n items, how many are in their original position, in expectation? Use indicators. (b) You average k independent model predictions, each with variance sigma^2 and pairwise correlation rho. What is the variance of the average, and what happens as k grows? This is the mathematics of ensembling, so do it carefully. (c) Use the law of total variance to explain the difference between aleatoric and epistemic uncertainty in one sentence each. Answers in 3.12.

## 3.4 The distributions worth knowing

Do not memorize formulas. Memorize **what situation each distribution is the answer to**, and the formula can be looked up or reconstructed. Interviewers ask "what distribution would you model this with?", never "what is the normalizing constant of a Beta?".

### Discrete

| Distribution | The question it answers | Mean | Variance |
| --- | --- | --- | --- |
| Bernoulli(p) | one yes/no trial | p | p(1-p) |
| Binomial(n, p) | how many successes in n independent trials | np | np(1-p) |
| Categorical(p) | which of K outcomes | - | - |
| Multinomial(n, p) | counts across K outcomes in n trials | np\_k | np\_k(1-p\_k) |
| Geometric(p) | how many trials until the first success | 1/p | (1-p)/p^2 |
| Poisson(lambda) | how many rare events in a fixed interval | lambda | lambda |

**Bernoulli** is the output distribution of binary classification, and its negative log-likelihood *is* binary cross-entropy. **Categorical** is the output distribution of every language model, and its negative log-likelihood *is* cross-entropy. If you internalize only one thing from this section: the loss you use is determined by the distribution you assume over the label.

**Poisson** deserves a word because it is where it comes from that matters: it is the limit of Binomial(n, p) as n grows and p shrinks with np fixed. Many rare chances, so the count is Poisson. Its defining oddity, mean equal to variance, is also its main practical weakness: real count data is usually **overdispersed** (variance exceeds mean), which is why negative binomial models exist.

### Continuous

| Distribution | The question it answers | Mean | Variance |
| --- | --- | --- | --- |
| Uniform(a,b) | no information beyond a range | (a+b)/2 | (b-a)^2/12 |
| Normal(mu, sigma^2) | a sum of many small independent effects | mu | sigma^2 |
| Exponential(lambda) | waiting time until a memoryless event | 1/lambda | 1/lambda^2 |
| Gamma(k, theta) | waiting time for the k-th event; positive quantities | k\*theta | k\*theta^2 |
| Beta(a, b) | a probability, or a proportion, in \[0,1\] | a/(a+b) | see below |
| Laplace(mu, b) | heavy-tailed noise; the prior behind Lasso | mu | 2b^2 |
| Student-t(nu) | a mean with unknown variance; robust modeling | 0 for nu>1 | nu/(nu-2) for nu>2 |
| Dirichlet(alpha) | a whole probability vector | alpha\_k / sum | - |

A few of these deserve more than a table row.

**Exponential is memoryless**, and it is the only continuous distribution that is: P(X > s + t | X > s) = P(X > t). Having waited an hour tells you nothing about the remaining wait. This is exactly the assumption embedded in **discounting** in reinforcement learning: a discount factor gamma corresponds to a geometric (discrete memoryless) horizon, which is why the value function has no time index in an infinite-horizon problem.

**Beta is the conjugate prior for Bernoulli**, which makes it the workhorse of Thompson sampling. The interpretation is beautifully concrete: Beta(a, b) behaves like having already seen a - 1 successes and b - 1 failures. Observing a success takes you from Beta(a, b) to Beta(a + 1, b). Updating a posterior is literally incrementing a counter, which is why Thompson sampling for Bernoulli bandits is about five lines of code. Chapter 9 uses this.

**Dirichlet is the multi-outcome version of Beta**, conjugate to the categorical, and is what topic models and any "distribution over distributions" is built from.

**Student-t** is what you get when you put a prior on a Gaussian's variance and marginalize it out. Its heavier tails make it the standard robust alternative to the Gaussian: an outlier is less surprising under a t, so it exerts less pull on the fit. As nu grows it converges to the Gaussian.

**Laplace** has a peak at its mode with a discontinuous derivative, which is precisely why using it as a prior gives sparsity: the MAP objective picks up an L1 penalty (Chapter 4).

### The exponential family, briefly

Most of the above belong to one family:

$$
p(x \mid \eta) = h(x)\exp\!\big(\eta^{\top}T(x) - A(\eta)\big)
$$

with eta the natural parameters, T(x) the sufficient statistics, and A the log-partition function. Three facts make this worth knowing rather than skipping:

1. **Derivatives of A give moments:** the gradient of A is E\[T(X)\] and its Hessian is Cov(T(X)). So the log-partition function is a moment-generating machine, and its Hessian being a covariance proves A is convex.
2. **Sufficient statistics compress the data losslessly** for inference purposes: to fit a Gaussian you need only the sum and the sum of squares, no matter how many points you have.
3. **Generalized linear models** are exactly "put a linear function into the natural parameter of an exponential family". Linear regression, logistic regression and Poisson regression are the Gaussian, Bernoulli and Poisson cases of one construction, and the clean gradient p - y from Chapter 2 is a general property of the canonical link, not a coincidence of softmax.

Chapter 4 develops all three properly.

### The relationships worth drawing

- Bernoulli summed n times gives Binomial.
- Binomial with large n and small p tends to Poisson.
- Binomial with large n and moderate p tends to Normal (this is the CLT).
- Exponential is Gamma with k = 1; a sum of k exponentials is Gamma(k).
- The square of a standard normal is chi-squared with 1 degree of freedom; a sum of k such squares is chi-squared with k.
- A normal divided by the square root of a scaled chi-squared is Student-t. This is why the t-test has its form.
- Beta is the two-category case of Dirichlet.

These are not trivia; they are how you recognize a distribution when it appears in a derivation without being named. A quadratic form of Gaussians showing up as chi-squared is the single most common instance in statistics.

### Choosing one in practice

The diagnostic questions, in order: Is it discrete or continuous? Bounded, positive, or unbounded? Is it a count, a duration, a proportion, or a magnitude? Are extreme values plausible? Answering those four picks the distribution nearly every time. If extreme values matter and you chose a Gaussian, reconsider — most real-world quantities that can be large have heavier tails than a Gaussian, and Gaussian assumptions fail loudly and specifically there.

**Try it.** (a) You model the number of requests per second to a server. Which distribution, and what would make you abandon it? (b) You model a click-through rate you want to put a prior on. Which distribution, and what do its parameters mean concretely? (c) Show that the sum of two independent Poisson variables is Poisson, and say why that is intuitively obvious. Answers in 3.12.

## 3.5 The multivariate Gaussian, in depth

This is the most important distribution in machine learning and it rewards detailed study. Nearly every closed-form result in ML that is not linear algebra is a Gaussian computation.

### The density, and how to read it

$$
p(x) = \frac{1}{(2\pi)^{d/2}\,|\Sigma|^{1/2}} \exp\!\left( -\tfrac{1}{2}(x-\mu)^{\top}\Sigma^{-1}(x-\mu) \right)
$$

Ignore the constant in front; it is only there to make the integral 1. Everything meaningful is in the exponent, and it is a quadratic form, which you already understand from section 1.7. Define the **Mahalanobis distance**:

$$
d_M(x)^2 = (x-\mu)^{\top}\Sigma^{-1}(x-\mu)
$$

This is Euclidean distance corrected for the shape of the data: a step in a high-variance direction counts for less, a step in a low-variance direction counts for more. A Gaussian is simply **exp of minus half the squared Mahalanobis distance**. Contours of constant density are contours of constant Mahalanobis distance, which are **ellipsoids whose axes are the eigenvectors of Sigma and whose semi-axis lengths are proportional to the square roots of the eigenvalues.** That last sentence is the geometric content of the entire distribution, and it should be the picture in your head.

The determinant term is a volume: |Sigma|^{1/2} is the volume scale of the ellipsoid, so the normalizing constant is exactly what is needed to make total probability 1 no matter how the ellipsoid is stretched.

### The log-density is what you actually use

$$
\log p(x) = -\tfrac{1}{2}(x-\mu)^{\top}\Sigma^{-1}(x-\mu) - \tfrac{1}{2}\log|\Sigma| - \tfrac{d}{2}\log 2\pi
$$

Read off the consequences:

- With Sigma fixed, **maximizing Gaussian log-likelihood is minimizing squared Mahalanobis error**, and with Sigma = sigma^2 I it is plain least squares. That is the formal version of the claim in section 1.5.
- The log|Sigma| term is a penalty on spreading out. In models that learn their own variance, it is what stops the variance from growing without bound to make everything "likely". This term is why heteroscedastic regression works and why a model that predicts its own uncertainty is trained with a loss that has both a weighted-error term and a log-variance term.
- You need the gradients from Chapter 2, section 2.4: the derivative of log|Sigma| is Sigma^{-1}, and the derivative of the inverse brings the sandwich term. That exercise was preparation for exactly this.

### Generating one, and why it matters

If z \~ N(0, I) then

$$
x = \mu + L z \;\sim\; N(\mu, LL^{\top})
$$

So to sample from N(mu, Sigma), take the **Cholesky factor** L with LL' = Sigma and transform standard noise. The covariance rule Cov(Az) = A Cov(z) A' from section 3.3 is all the proof you need.

This is the **reparameterization trick**. Writing the sample as a deterministic function of the parameters and of *external* noise makes it differentiable with respect to mu and L, which is exactly what a VAE needs. If instead you sampled directly from N(mu, Sigma), there would be no gradient path to mu at all. Section 3.6 and Chapter 5 develop this.

### The four properties that make Gaussians special

These are the reasons Gaussians dominate, and you should be able to list them.

**1. Closed under linear transformation.**

$$
x \sim N(\mu, \Sigma) \;\Longrightarrow\; Ax + b \sim N(A\mu + b,\; A\Sigma A^{\top})
$$

Push a Gaussian through a linear layer and it stays Gaussian. Nothing else convenient survives this.

**2. Closed under marginalization, and marginalizing is trivial.** Partition x into blocks x\_1 and x\_2 with mean blocks mu\_1, mu\_2 and covariance blocks Sigma\_11, Sigma\_12, Sigma\_21, Sigma\_22. Then

$$
x_1 \sim N(\mu_1, \Sigma_{11})
$$

**You just read off the relevant block and delete everything else.** No integration. This is why Gaussian processes are usable at all: a GP is defined by consistency of all its finite marginals, and marginalizing away the infinitely many points you did not observe costs nothing.

**3. Closed under conditioning, with a formula worth memorizing.**

$$
x_1 \mid x_2 \;\sim\; N\!\left( \mu_1 + \Sigma_{12}\Sigma_{22}^{-1}(x_2 - \mu_2), \;\; \Sigma_{11} - \Sigma_{12}\Sigma_{22}^{-1}\Sigma_{21} \right)
$$

This is the single most useful formula in this chapter. Read it carefully:

- **The conditional mean is linear in the observation.** That is why linear regression is optimal for jointly Gaussian data, and it is the reason Kalman filters are linear.
- The term Sigma\_12 Sigma\_22^{-1} is exactly a regression coefficient matrix. Conditioning *is* regression.
- **The conditional covariance does not depend on the observed value x\_2 at all.** Your uncertainty shrinks by a fixed amount regardless of what you observe. This is a genuinely surprising property, unique to the Gaussian, and it is why Gaussian process posteriors have variance you can compute before collecting any data (used in Bayesian optimization to decide where to sample next).
- The subtracted term is the **Schur complement**, and it is always PSD, so conditioning never increases variance. Information cannot hurt.

**4. Maximum entropy.** Among all distributions on R^d with a given mean and covariance, the Gaussian has the highest entropy (Chapter 5 proves it). So assuming a Gaussian is the *least* committal assumption you can make once you have decided to specify only first and second moments. This is the principled defense of Gaussian assumptions, and it is a much better interview answer than "the CLT".

### Precision versus covariance

The inverse Lambda = Sigma^{-1} is the **precision matrix**, and its zeros mean something different from the covariance's zeros:

| Matrix | A zero entry (i,j) means |
| --- | --- |
| Covariance Sigma | X\_i and X\_j are **marginally** independent |
| Precision Lambda | X\_i and X\_j are **conditionally** independent given all others |

That second row is the foundation of Gaussian graphical models: the sparsity pattern of the precision matrix *is* the graph. It is also why some algorithms are naturally written in precision form — combining independent Gaussian information sources is addition in precision space, which is why the Kalman filter's information form exists, and why "precision-weighted average" is the right way to merge two noisy estimates.

### Products of Gaussians

Multiply two Gaussian densities in x and you get an unnormalized Gaussian, with

$$
\Lambda_{\text{post}} = \Lambda_1 + \Lambda_2, \qquad \Lambda_{\text{post}}\mu_{\text{post}} = \Lambda_1\mu_1 + \Lambda_2\mu_2
$$

**Precisions add; means combine weighted by precision.** This is Bayesian updating with a Gaussian prior and Gaussian likelihood in one line, and it makes the behavior obvious: the posterior is always more precise than either input, and it sits nearer whichever source was more confident. The whole Kalman filter is this identity plus the linear-transformation rule, applied alternately.

### Where the Gaussian fails you

Worth saying plainly, because over-applying Gaussians is a real failure mode:

- **Tails are far too light.** A five-sigma event has probability about 3 in 10 million under a Gaussian. Financial returns, network latencies, and loss spikes during training are all far more extreme than that. If you model them as Gaussian you will be surprised regularly.
- **It is unimodal and symmetric.** Multimodal data needs a mixture.
- **It is unbounded**, so it is wrong for durations, counts and probabilities. Model the log, or use a distribution with the right support.
- **Covariance only captures linear structure.** Uncorrelated Gaussian components are independent, but real data that is uncorrelated need not be.

**Try it.** (a) Given a 2D Gaussian with variances 4 and 1 and covariance 1, find the conditional distribution of X\_1 given X\_2 = 3, taking both means to be 0. (b) Show that the conditional variance you computed is smaller than the marginal, and say by how much. (c) Two sensors report estimates 10 and 12 with variances 4 and 1. What is the fused estimate and its variance? Do it with the precision formula. Answers in 3.12.

## 3.6 Transformations and change of variables

### The one-dimensional case, and why the absolute value is there

If Y = g(X) with g monotonic and differentiable,

$$
p_Y(y) = p_X(g^{-1}(y)) \left| \frac{d}{dy} g^{-1}(y) \right| = \frac{p_X(x)}{|g'(x)|} \bigg|_{x = g^{-1}(y)}
$$

**Why the derivative factor exists.** Probability mass is conserved, not density. A small interval dx maps to an interval dy = |g'(x)| dx. The same probability now occupies a different amount of space, so the density must change to compensate: stretch the axis and the density thins out; compress it and the density piles up. The absolute value is there because density is nonnegative while g' may be negative for a decreasing map.

The common student error is to write p\_Y(y) = p\_X(g^{-1}(y)) and stop. That is what you do for a *function*, not for a *density*. This is Fact 2 from section 3.1, and it is worth over-learning.

### The multivariate case

$$
p_Y(y) = p_X(x)\,\left| \det J_{g^{-1}}(y) \right| = \frac{p_X(x)}{\left| \det J_g(x) \right|}, \qquad x = g^{-1}(y)
$$

The Jacobian determinant is the local volume scaling factor, exactly as described in section 2.1. A cube of volume dV at x maps to a region of volume |det J| dV at y, so the density divides by that factor. One dimension is the special case where the determinant of a 1 x 1 matrix is the number itself.

In log form, which is how it is always implemented:

$$
\log p_Y(y) = \log p_X(x) - \log\left| \det J_g(x) \right|
$$

### Normalizing flows, which are this formula and nothing else

A normalizing flow builds an expressive density by pushing a simple one (usually a standard Gaussian) through a chain of invertible maps. The log-density of the result is the base log-density minus a sum of log-determinants, one per layer. Training is maximum likelihood on that expression.

The entire engineering problem is: **make the maps expressive, invertible, and cheap to take a determinant of.** A general d x d determinant costs O(d^3), which is fatal. The standard solutions all engineer the Jacobian into a shape with a cheap determinant:

| Design | Jacobian shape | Determinant cost |
| --- | --- | --- |
| Elementwise (planar, radial) | diagonal-ish | O(d) |
| Coupling layers (RealNVP, Glow) | triangular | O(d), product of diagonal |
| Autoregressive (MAF, IAF) | triangular | O(d) |
| Residual flows | requires spectral constraints | estimated |

Coupling layers are the cleanest illustration: split the input in half, leave the first half unchanged, and transform the second half using a function of the first. The Jacobian is block triangular, so its determinant is the product of the diagonal blocks, and the untouched block contributes 1. Invertibility is immediate because you can recover the first half directly and then undo the second. If you understand why that Jacobian is triangular, you understand normalizing flows.

### The reparameterization trick, stated properly

You want the gradient of an expectation with respect to the parameters of the distribution being averaged over:

$$
\nabla_\theta\, \mathbb{E}_{z \sim q_\theta}\left[ f(z) \right]
$$

The problem: theta is in the distribution, not in the function, so you cannot simply push the gradient inside. Two solutions, and knowing both plus when to use each is a standard interview question.

**Reparameterization (pathwise) estimator.** Write z as a deterministic transform of parameter-free noise, z = g(theta, epsilon) with epsilon \~ p(epsilon). Then the randomness no longer depends on theta and the gradient moves inside:

$$
\nabla_\theta\, \mathbb{E}_{\epsilon}\left[ f(g(\theta, \epsilon)) \right] = \mathbb{E}_{\epsilon}\left[ \nabla_\theta f(g(\theta,\epsilon)) \right]
$$

For a Gaussian, z = mu + sigma \* epsilon with epsilon \~ N(0, I). The gradient flows through mu and sigma directly, using f's own derivative, which is why this estimator has **low variance**. It requires f to be differentiable and the distribution to be reparameterizable, which rules out discrete z.

**Score-function (REINFORCE, likelihood-ratio) estimator.** Use the identity

$$
\nabla_\theta\, \mathbb{E}_{q_\theta}[f(z)] = \mathbb{E}_{q_\theta}\left[ f(z)\, \nabla_\theta \log q_\theta(z) \right]
$$

*Proof, which takes three lines and which you should be able to do.* Write the expectation as an integral, differentiate under the integral sign to get the integral of f times the gradient of q, then multiply and divide by q and use that the gradient of log q equals the gradient of q divided by q. The result is an expectation again.

This works for **any** f, including non-differentiable ones and black-box simulators, and for discrete z. Its cost is **high variance**, because it only uses f as a scalar weight and never looks at its derivative. That is exactly the estimator behind policy gradients in Chapter 9, and essentially all of the machinery there (baselines, advantage estimation, control variates) exists to reduce its variance.

|  | Reparameterization | Score function |
| --- | --- | --- |
| Needs f differentiable | yes | no |
| Works for discrete z | no | yes |
| Variance | low | high |
| Used in | VAEs, continuous-action policies | REINFORCE, discrete latent variables |

### Two more transformations worth knowing

**Sums are convolutions.** If X and Y are independent, the density of X + Y is the convolution of their densities. This is why sums of Gaussians are Gaussian (a convolution of Gaussians is Gaussian), why sums of Poissons are Poisson, and why characteristic functions and MGFs are so useful: convolution becomes multiplication in the transform domain (section 3.7).

**Order statistics.** The maximum of n i.i.d. variables has CDF F(x)^n, since all n must be below x. The minimum has CDF 1 - (1 - F(x))^n. This little pair explains why the maximum of n samples grows with n, and it is the basis of extreme-value reasoning, of the Gumbel-max trick for sampling from a categorical distribution, and hence of the Gumbel-softmax relaxation.

**Try it.** (a) X \~ Uniform(0,1). Find the density of Y = X^2, and check it integrates to 1. (b) X \~ N(0,1). Find the density of Y = e^X, the lognormal, and explain why its mean is not e^0. (c) Write the reparameterized sample for a diagonal Gaussian and identify exactly which quantities the gradient flows through. Answers in 3.12.

## 3.7 Sums, the law of large numbers, and the CLT

### Moment generating and characteristic functions

$$
M_X(t) = \mathbb{E}[e^{tX}], \qquad \varphi_X(t) = \mathbb{E}[e^{itX}]
$$

Two properties make these worth the trouble. First, **they turn sums into products**: for independent X and Y, M\_{X+Y} = M\_X M\_Y. Convolution in density space is multiplication in transform space. Second, **they generate moments**: the k-th derivative of M at 0 is E\[X^k\]. The characteristic function is the more robust tool because it always exists, while the MGF can fail for heavy-tailed distributions (the Cauchy has no MGF, and no mean either).

The practical payoff: proving that a sum of independent Gaussians is Gaussian is one line with MGFs, and the same technique gives the Poisson and Gamma additivity results. Chernoff bounds in section 3.8 are also MGF arguments in disguise.

### Modes of convergence, briefly but correctly

This distinction is worth thirty seconds because the LLN and CLT are statements about different modes, and interviewers do occasionally probe it.

| Mode | Meaning | Used in |
| --- | --- | --- |
| In probability | P(\|X\_n - X\| > eps) tends to 0 | weak LLN |
| Almost surely | the sequence converges for almost every outcome | strong LLN |
| In distribution | CDFs converge | CLT |
| In mean square | E\[(X\_n - X)^2\] tends to 0 | many ML convergence results |

Almost sure is stronger than in probability, which is stronger than in distribution. Convergence in distribution says nothing about the variables being close; it only says their distributions look alike.

### The law of large numbers

$$
\bar{X}_n = \frac{1}{n}\sum_{i=1}^{n} X_i \;\longrightarrow\; \mu \quad \text{as } n \to \infty
$$

The **weak** LLN gives convergence in probability, the **strong** LLN gives almost sure convergence. Both need the mean to exist; neither needs the variance to exist, though assuming finite variance makes the weak version a two-line proof from Chebyshev's inequality (section 3.8).

What the LLN justifies in ML: that a sample average of the loss approximates the expected loss, which is the entire premise of **empirical risk minimization**; that a minibatch gradient is a usable estimate of the full gradient; that Monte Carlo estimates converge.

What it does **not** say: nothing about how fast. That is the CLT's job, and the difference matters because "it converges eventually" is useless for deciding a sample size.

### The central limit theorem

$$
\sqrt{n}\,\frac{\bar{X}_n - \mu}{\sigma} \;\xrightarrow{\;d\;}\; N(0,1)
$$

Equivalently, the sample mean is approximately N(mu, sigma^2/n) for large n. State it with care, because the loose version causes real errors:

- The requirements are **i.i.d.** (or a suitable weakening), **finite mean**, and **finite variance**. Nothing else. The X\_i can be arbitrarily non-Gaussian, discrete, skewed, bounded.
- It is a statement about the **sample mean**, not about the data. Your data does not become Gaussian; the average of it does.
- It is **asymptotic**. "n = 30 is enough" is a rule of thumb, not a theorem, and it fails badly for skewed or heavy-tailed data. Berry-Esseen gives the actual rate: the error in the CDF is bounded by roughly the third absolute moment divided by sigma^3 sqrt(n), so convergence is O(1/sqrt n) and skewness is what slows it.
- It **fails when the variance is infinite.** The average of Cauchy variables has exactly the same Cauchy distribution as one sample, no matter how many you take. Averaging buys you nothing at all there, which is a striking and useful counterexample.

**Why it is true, in one intuitive sentence.** Adding independent variables convolves their densities, and repeated convolution smooths away every feature of the original shape except its mean and variance; the Gaussian is the fixed point of that smoothing. The MGF proof makes this precise: expand the MGF of the standardized sum to second order, and the higher terms vanish at rate 1/sqrt n, leaving exactly the Gaussian MGF exp(t^2/2).

### What the CLT buys you in ML

- **Standard errors.** The standard error of a mean is sigma/sqrt(n), so a 95% confidence interval is roughly the estimate plus or minus 1.96 standard errors. This is how you report a model's accuracy honestly, and failing to do so is a common review criticism.
- **A/B tests and evaluation.** The difference of two sample means is approximately Gaussian, which is the basis of the standard two-sample test.
- **Minibatch gradient noise.** The minibatch gradient is a sample mean of per-example gradients, so by the CLT its noise is approximately Gaussian with covariance scaling as 1/batch size. This is the assumption underlying the stochastic differential equation view of SGD and the **linear scaling rule** heuristic (multiply the learning rate by k when you multiply the batch by k, so the noise scale stays comparable). Chapter 6 develops this.
- **Why bigger batches have diminishing returns.** Noise falls as 1/sqrt(batch), so doubling the batch reduces gradient noise by only about 30% while doubling the compute per step.

### The delta method, a small tool with large reach

If an estimator is asymptotically normal, so is a smooth function of it:

$$
\sqrt{n}(\hat{\theta} - \theta) \to N(0, \sigma^2) \;\Longrightarrow\; \sqrt{n}\big(g(\hat{\theta}) - g(\theta)\big) \to N\big(0, \, g'(\theta)^2 \sigma^2\big)
$$

This is just a first-order Taylor expansion plus the CLT, and it is how you get standard errors for derived quantities such as ratios, odds ratios, or a metric computed from estimated components. It also tells you when *not* to trust the result: if g' is near zero or the function is sharply curved at theta, the linearization is poor and you should bootstrap instead.

**Try it.** (a) You estimate accuracy as 0.83 on a test set of 1000. Give a 95% confidence interval, and state the assumptions. (b) How many test examples do you need to distinguish 90% from 91% accuracy with reasonable confidence? Work it out roughly and be alarmed. (c) Why does averaging not help for Cauchy data, and what does that tell you about loss spikes in training? Answers in 3.12.

## 3.8 Concentration inequalities

The CLT tells you what happens asymptotically. Concentration inequalities give you **non-asymptotic, finite-sample guarantees**: statements true for every n, not just large n. They are the mathematical content of statistical learning theory, and they are what a research interview means when it asks how you would prove something generalizes.

The common shape of all of them: *an average of independent bounded things is exponentially unlikely to be far from its mean.*

### Markov: the seed of everything

For a **nonnegative** random variable X and any a > 0:

$$
P(X \ge a) \;\le\; \frac{\mathbb{E}[X]}{a}
$$

*Proof, one line.* E\[X\] >= E\[X times the indicator that X >= a\] >= a P(X >= a). Nonnegativity is what makes the first step valid, and it is the only assumption.

This bound is extremely weak but extraordinarily general, and **every other inequality in this section is Markov applied to a cleverly chosen function of X.** If you remember that, you can reconstruct the rest.

### Chebyshev: apply Markov to the squared deviation

$$
P(|X - \mu| \ge k\sigma) \;\le\; \frac{1}{k^2}
$$

Apply Markov to (X - mu)^2 with threshold k^2 sigma^2. So at most 25% of any distribution's mass is more than two standard deviations from the mean, and at most 1/9 beyond three. No assumptions at all beyond a finite variance, which is why the bound is loose: for a Gaussian the true tail beyond three sigma is about 0.0027, not 0.111.

Chebyshev immediately proves the weak law of large numbers: the sample mean has variance sigma^2/n, so the probability of being more than epsilon away is at most sigma^2/(n epsilon^2), which goes to zero.

### Hoeffding: the one you will actually use

For independent X\_i bounded in \[a\_i, b\_i\], with sample mean X-bar:

$$
P\big( |\bar{X} - \mathbb{E}[\bar{X}]| \ge t \big) \;\le\; 2\exp\!\left( \frac{-2n^2t^2}{\sum_i (b_i - a_i)^2} \right)
$$

For variables in \[0,1\], this simplifies to the form worth memorizing:

$$
P\big( |\bar{X} - \mu| \ge t \big) \;\le\; 2e^{-2nt^2}
$$

Note the improvement: Chebyshev decays **polynomially** in t, Hoeffding **exponentially**. Boundedness buys you an enormous amount. The proof is a Chernoff argument: apply Markov to exp(lambda X), bound the MGF using Hoeffding's lemma, then optimize over lambda. Knowing that the recipe is "Markov on the exponential, then optimize the free parameter" is enough for most interviews.

**Inverting it is the practically useful move.** Setting the right side to delta and solving for t:

$$
t = \sqrt{\frac{\log(2/\delta)}{2n}}
$$

So with probability at least 1 - delta, your estimate is within that distance of the truth. **Concrete: to estimate an accuracy to within 1% with 95% confidence, you need about n = 18,500 examples.** That number is worth carrying around, because it explains why small test sets cannot distinguish models that differ by a point of accuracy, and it is a genuinely useful thing to say in a design discussion.

### Bernstein: when the variance is small

$$
P(|\bar{X} - \mu| \ge t) \;\le\; 2\exp\!\left( \frac{-nt^2}{2\sigma^2 + \tfrac{2}{3}Mt} \right)
$$

where sigma^2 is the variance and M bounds the range. Hoeffding only uses the range; Bernstein uses the variance too, and when the variance is much smaller than the range squared, Bernstein is much tighter. This matters in practice: for a classifier with 99% accuracy, the per-example loss is bounded in \[0,1\] but has variance around 0.01, so Bernstein gives a far better bound than Hoeffding. **When your quantity is bounded but usually near one end, reach for Bernstein.**

### McDiarmid: beyond averages

If changing any single input changes a function by at most c\_i:

$$
P\big( |f(X_1,\ldots,X_n) - \mathbb{E}[f]| \ge t \big) \;\le\; 2\exp\!\left( \frac{-2t^2}{\sum_i c_i^2} \right)
$$

This is the bounded-differences inequality, and it generalizes Hoeffding to any function with limited sensitivity to each input, not just averages. It is the tool behind **algorithmic stability** bounds: if your learning algorithm's output barely changes when you swap one training example, then its training error is close to its test error. That is one of the cleanest routes to a generalization bound, and it is the reason regularization and early stopping have theoretical justifications and not just empirical ones.

### Why any of this matters: the generalization bound

Here is the skeleton, and it is worth being able to sketch.

Fix one hypothesis h. Its training error is an average of n independent bounded terms, so Hoeffding says the training error is within roughly sqrt(log(1/delta)/2n) of the true error, with probability 1 - delta.

But you did not fix one hypothesis; you **chose** the one with the lowest training error, so the bound must hold for all of them simultaneously. Take a union bound over a hypothesis class of size H:

$$
P(\exists h: |\hat{R}(h) - R(h)| > t) \;\le\; 2|H| e^{-2nt^2} \quad \Longrightarrow \quad t = \sqrt{\frac{\log|H| + \log(2/\delta)}{2n}}
$$

Read the result: **generalization error grows like the square root of (model complexity over sample size).** More data helps as 1/sqrt(n); more hypotheses hurt as sqrt(log |H|). For infinite classes, |H| is replaced by a capacity measure such as VC dimension or Rademacher complexity, but the shape stays the same.

Be honest about the limitation, because it is a good thing to raise unprompted: these bounds are **vacuous for modern deep networks**. A network with more parameters than data points has a capacity term that makes the bound exceed 1, which says nothing. Explaining why overparameterized networks generalize anyway is an open research problem, with candidate explanations including implicit regularization from the optimizer (the minimum-norm story from Chapter 1), margin-based bounds, and compression arguments. Saying "classical uniform-convergence bounds are vacuous here and this is an active area" is the correct, current answer.

**Try it.** (a) Use Hoeffding to find the test-set size needed to estimate accuracy within 2% at 99% confidence. (b) A model has 99.5% accuracy. Compare the Hoeffding and Bernstein bound widths at n = 1000 and explain the gap. (c) Why does the union bound over |H| hypotheses appear, and what goes wrong if you ignore it? Answers in 3.12.

## 3.9 High-dimensional probability

Your geometric intuition was trained in two and three dimensions and it is actively misleading in 768. This section is short but it changes how you think, and several of its facts are standard interview material.

### Everything is at the same distance from everything else

Take two independent draws from a d-dimensional distribution with independent coordinates. Their squared distance is a sum of d independent terms, so by the CLT it concentrates: the mean grows like d and the standard deviation grows like sqrt(d). The **relative** spread therefore shrinks like 1/sqrt(d).

$$
\frac{\text{sd of pairwise distance}}{\text{mean pairwise distance}} \;\sim\; \frac{1}{\sqrt{d}} \;\longrightarrow\; 0
$$

So in high dimensions **all pairwise distances become nearly equal**. The nearest neighbor is barely nearer than the farthest. This is the precise statement of the curse of dimensionality for distance-based methods, and it is why k-NN degrades in high dimensions, why raw-pixel distance is a useless image similarity metric, and why learned representations exist: the point of an embedding is to produce a space where distance means something again.

### Gaussians live on a thin shell

For z \~ N(0, I\_d), the squared norm is a sum of d squared standard normals, so it is chi-squared with d degrees of freedom, with mean d and variance 2d. Hence

$$
\lVert z \rVert \approx \sqrt{d} \; \pm \; O(1)
$$

**The mass of a high-dimensional Gaussian is concentrated in a thin annulus of radius sqrt(d), not near the origin.** The mode is at the origin, and the origin is where the density is highest, but almost no probability mass is there, because there is almost no *volume* there. This is the **Gaussian annulus theorem**, and it is the crispest example of density and mass being different things.

Practical consequences you will actually run into:

- **Typical latent vectors in a VAE or diffusion model have norm about sqrt(d)**, so "sample the mode" is not the same as "sample a typical point". Interpolating linearly between two latent samples passes through the low-density interior, which is why **spherical interpolation (slerp)** produces better results than linear interpolation in generative models. That is a concrete, well-known practitioner consequence of this one theorem.
- Initialization scales are chosen with this in mind: a weight matrix with i.i.d. entries has predictable operator-norm behavior driven by the same concentration.

### Random vectors are nearly orthogonal

For independent x and y with i.i.d. standard normal entries, the cosine similarity has mean 0 and standard deviation about 1/sqrt(d). In 768 dimensions, that is about 0.036. Two random directions are almost certainly nearly perpendicular.

The constructive consequence is more interesting than the warning. By the **Johnson-Lindenstrauss lemma**, you can pack exponentially many *approximately* orthogonal directions into R^d: for any epsilon, there are exp(c epsilon^2 d) unit vectors with pairwise inner products below epsilon. So a 768-dimensional embedding space can hold vastly more than 768 near-independent concepts. This is the mathematical basis of the **superposition** hypothesis in interpretability, which holds that networks represent more features than they have neurons by tolerating small interference.

Johnson-Lindenstrauss also gives a practical result: a random linear projection to O(log(n)/epsilon^2) dimensions preserves all pairwise distances among n points to within a factor of 1 plus epsilon. Note what the target dimension depends on — the **number of points**, not the original dimension. That is why random projection is a legitimate dimensionality-reduction technique and why locality-sensitive hashing works.

### Volume concentrates near the surface

The volume of a d-dimensional ball of radius r scales as r^d. So the fraction of the volume within the inner 90% of the radius is 0.9^d, which for d = 100 is about 0.0027. **Essentially all of the volume of a high-dimensional ball is in a thin shell near its surface**, and essentially all the volume of a cube is in its corners, which is why a ball inscribed in a cube occupies a vanishing fraction of it as d grows.

This is why rejection sampling fails catastrophically in high dimensions, why grid search is hopeless beyond a few dimensions (a grid with k points per axis needs k^d points), and why random search beats grid search for hyperparameters: if only a few dimensions actually matter, random search explores more distinct values along those dimensions for the same budget.

### Why anything works at all

Given all this, it is fair to ask why high-dimensional learning is possible. Two answers, and both are worth being able to give:

1. **The manifold hypothesis.** Real data does not fill its ambient space. Natural images live on a set of far lower intrinsic dimension than the pixel count, because the pixel values are heavily constrained by physics and structure. The curse applies to the ambient dimension; learning operates on the intrinsic one.
2. **Concentration cuts both ways.** The same phenomenon that makes distances uninformative makes averages extremely reliable: sums of many independent contributions barely fluctuate. This is why stochastic gradients are usable estimates, why high-dimensional random matrices have predictable spectra, and why large models behave more smoothly and predictably than small ones rather than less.

**Try it.** (a) In d = 1000, what is the expected norm of a standard Gaussian sample, and roughly how much does it vary? (b) You have 10,000 points and want to preserve pairwise distances within 10%. Roughly what target dimension does Johnson-Lindenstrauss suggest? (c) Explain to a colleague why linear interpolation between two latent codes gives blurry results and what to do instead. Answers in 3.12.

## 3.10 Monte Carlo, importance sampling, variance reduction

Most quantities you care about in ML are expectations you cannot compute: an expected loss over the data distribution, an expected return over trajectories, a marginal likelihood over latents. The universal fallback is to sample and average. This section is the toolkit, and it is the direct mathematical prerequisite for policy gradients in Chapter 9.

### The basic estimator

$$
\mathbb{E}_{p}[f(X)] \;\approx\; \hat{\mu}_n = \frac{1}{n}\sum_{i=1}^{n} f(x_i), \qquad x_i \sim p
$$

It is **unbiased** (its expectation is the target exactly), and its variance is Var(f(X))/n, so its error falls as 1/sqrt(n).

The remarkable property: **that rate does not depend on the dimension.** Numerical quadrature in d dimensions needs k^d grid points for a given per-axis resolution, which is hopeless past a handful of dimensions; Monte Carlo needs n samples for accuracy 1/sqrt(n) no matter what d is. This is why Monte Carlo is the only viable option in high dimensions, and it is a good thing to be able to say crisply.

The catch is the constant: the variance of f can be enormous, and 1/sqrt(n) is a slow rate. Everything below is about shrinking that constant.

### Importance sampling

When you cannot sample from p, or when sampling from p is wasteful, sample from a proposal q instead and reweight:

$$
\mathbb{E}_{p}[f(X)] = \mathbb{E}_{q}\left[ f(X)\,\frac{p(X)}{q(X)} \right] \;\approx\; \frac{1}{n}\sum_i f(x_i)\,w_i, \qquad w_i = \frac{p(x_i)}{q(x_i)}, \; x_i \sim q
$$

The derivation is one line: multiply and divide by q inside the integral. The estimator is unbiased provided **q has support everywhere p does** — if q can never produce a region where p puts mass and f is large, you will never see it and your estimate is silently and badly wrong. This is the failure mode to watch for, and it is not detectable from the estimate itself.

The variance depends critically on the weights. If p and q are far apart, a few samples get enormous weights and dominate the sum, so the **effective sample size** collapses:

$$
\text{ESS} = \frac{\left(\sum_i w_i\right)^2}{\sum_i w_i^2}
$$

If you draw 1000 samples and the ESS is 5, you have five samples' worth of information. Monitoring ESS is standard practice and a good thing to mention.

**Where this shows up in ML:**

- **Off-policy RL.** You have data from an old policy and want the expected return under a new one. The importance ratio is the policy ratio, and this is exactly the term PPO clips. PPO's clipping is best understood as *refusing to trust importance weights that stray too far from 1*, which is a variance-control decision, not an arbitrary heuristic.
- **Off-policy evaluation** in bandits and recommendation, where you must estimate a new policy's value from logged data.
- **Counterfactual estimation** more generally, including inverse propensity weighting in causal inference.

**Self-normalized importance sampling** divides by the sum of the weights rather than by n. That makes it slightly biased but usually much lower variance, and it works when p is known only up to a constant, which is the common case. The bias-variance trade here is worth understanding: unbiasedness is not sacred, and an estimator with small bias and much smaller variance is often the better tool.

### Variance reduction

**Control variates.** If you know E\[g(X)\] exactly and g correlates with f, use

$$
\hat{\mu} = \frac{1}{n}\sum_i \Big( f(x_i) - c\big(g(x_i) - \mathbb{E}[g]\big) \Big)
$$

This is unbiased for any c, and the optimal c is Cov(f,g)/Var(g), giving a variance reduction of a factor (1 - rho^2) where rho is the correlation. **Perfect correlation would eliminate the variance entirely.**

This is the single most important variance-reduction idea for this tutorial's purposes, because the **baseline in policy gradients is exactly a control variate.** Subtracting a state-dependent baseline b(s) from the return leaves the gradient unbiased, because the expected score function is zero, while sharply reducing variance. The best practical baseline is the value function, which turns the return into the advantage. When Chapter 9 introduces advantage estimation, it will be this formula wearing different notation.

**Antithetic variates.** Use pairs of negatively correlated samples, such as epsilon and -epsilon for a symmetric distribution. The negative correlation cancels part of the variance in the average. This is cheap and effective for Gaussian noise, and it shows up in gradient estimation for evolution strategies.

**Common random numbers.** When comparing two configurations, use the same random seed for both. The difference then has much lower variance because the shared noise cancels. This is why you should evaluate two models on the *same* test set and the same data order, and it is a free improvement most people forget.

**Rao-Blackwellization.** If you can integrate out part of the randomness analytically, do so: conditioning can only reduce variance, by the law of total variance from section 3.3. Concretely, if E\[f(X,Y)|X\] has a closed form, average that instead of f itself. This is why you compute the exact expected value over actions where you can rather than sampling actions, and why the analytic KL term in a VAE's ELBO is preferred to a sampled one.

### Sampling methods, in one paragraph each

- **Inverse transform:** apply F^{-1} to a uniform sample. Exact and cheap when F^{-1} is available.
- **Rejection sampling:** sample from an easy q that upper-bounds p after scaling, accept with probability p/(Mq). Exact, but the acceptance rate decays exponentially with dimension, so it is a low-dimensional tool only.
- **MCMC** (Metropolis-Hastings, Gibbs, Hamiltonian Monte Carlo): build a Markov chain whose stationary distribution is p. Works in high dimensions and needs p only up to a constant, which is why it dominates Bayesian inference. The costs are correlated samples (so the effective sample size is below n), an unclear burn-in period, and no reliable convergence diagnostic. HMC and its adaptive variant NUTS use gradient information to propose distant, high-acceptance moves, which is why they scale far better than random-walk proposals.
- **Variational inference:** give up on exactness and optimize over a tractable family to minimize KL to the posterior. Fast and scalable, systematically biased, and the basis of VAEs. Chapter 5 develops the ELBO properly.

**Try it.** (a) Show that subtracting a constant baseline from the score-function estimator leaves it unbiased. This is the key step in policy gradients, so do it carefully. (b) You importance-sample with weights whose values are 100 for one sample and about 1 for 999 others. Compute the ESS and say what it means. (c) Why does using the same test set to compare two models reduce the variance of the estimated difference? Answers in 3.12.

## 3.11 Interview drill set

**1. Can a probability density be greater than 1?** Yes. A density is probability per unit volume, not a probability. A uniform distribution on \[0, 0.1\] has density 10 everywhere on that interval. Only the integral must be 1.

**2. State Bayes' rule and name every term.** Posterior equals likelihood times prior over evidence. The evidence is the normalizer, obtained by marginalizing the numerator over the parameter, and it is also the model-comparison score.

**3. The base-rate problem.** *(99% accurate test, 1 in 10,000 disease, you test positive.)* About 1%. Out of a million people, 100 are sick and 99 test positive; 999,900 are healthy and about 9,999 test positive anyway. False positives swamp true positives because the healthy population is enormous.

**4. Does zero correlation imply independence?** No. X \~ N(0,1) and Y = X^2 are uncorrelated by symmetry and completely dependent. The converse does hold: independence implies zero correlation. For jointly Gaussian variables, uncorrelated does imply independent.

**5. Give an example where conditioning creates dependence.** X and Y independent coin flips, Z = X XOR Y. Given Z, X determines Y. This is a collider, and it is why conditioning on a common effect induces correlation between its causes. Selection bias is this phenomenon.

**6. State the CLT precisely, including the assumptions.** For i.i.d. variables with finite mean and finite variance, the standardized sample mean converges in distribution to a standard normal. It is asymptotic, it concerns the mean rather than the data, and it fails for infinite-variance distributions like the Cauchy.

**7. Why do we divide by n - 1 in the sample variance?** The deviations are measured from the sample mean, which was chosen to minimize them, so they are systematically too small. One degree of freedom was spent estimating the mean, and dividing by n - 1 corrects the bias exactly.

**8. Write the multivariate Gaussian density and explain each piece.** A normalizing constant involving the determinant of the covariance, times exp of minus half the squared Mahalanobis distance. The quadratic form gives ellipsoidal contours with axes along the eigenvectors of Sigma and lengths proportional to the square roots of its eigenvalues.

**9. What is the conditional distribution of a Gaussian given part of it?** Gaussian, with mean mu\_1 + Sigma\_12 Sigma\_22^{-1}(x\_2 - mu\_2) and covariance Sigma\_11 - Sigma\_12 Sigma\_22^{-1} Sigma\_21. The mean is linear in the observation, and the covariance does not depend on the observed value at all.

**10. Why is the Gaussian so ubiquitous? Give the best answer, not the CLT one.** It is the maximum-entropy distribution for a given mean and covariance, so it is the least committal choice once you specify only two moments. It is also closed under linear maps, marginalization and conditioning, and it is the only distribution for which all of those are trivial.

**11. What does a zero in the precision matrix mean?** Conditional independence given all other variables. A zero in the covariance means marginal independence. The precision matrix's sparsity pattern is the graph of a Gaussian graphical model.

**12. How do you sample from N(mu, Sigma)?** Cholesky-factor Sigma as LL', draw standard normal z, return mu + Lz. The covariance rule Cov(Az) = A Cov(z) A' gives the proof.

**13. What is the reparameterization trick and why is it needed?** Write a sample as a deterministic function of parameters and parameter-free noise, so gradients can flow into the parameters. Without it there is no gradient path from a loss through a sampling operation to the distribution's parameters.

**14. Compare the reparameterization and score-function estimators.** Reparameterization uses the derivative of f and has low variance, but needs f differentiable and a reparameterizable distribution. The score function works for any f, including black-box and discrete cases, but has high variance. Policy gradients use the latter, VAEs the former.

**15. Why does the density of a transformed variable pick up a Jacobian determinant?** Probability mass is conserved, not density. A transform stretches volumes by |det J|, so the same mass occupies more or less space and the density must divide by that factor.

**16. State Markov's inequality and derive Chebyshev from it.** For nonnegative X, P(X >= a) <= E\[X\]/a. Apply it to (X - mu)^2 with threshold k^2 sigma^2 to get P(|X - mu| >= k sigma) <= 1/k^2.

**17. How large a test set do you need to estimate accuracy within 1% at 95% confidence?** By Hoeffding, t = sqrt(log(2/delta)/(2n)); solving for t = 0.01 and delta = 0.05 gives about 18,500 examples. This is why small test sets cannot resolve one-point accuracy differences.

**18. What is the law of total variance and what is it good for?** Var(X) = E\[Var(X|Y)\] + Var(E\[X|Y\]): within-group plus between-group variation. It underlies the bias-variance decomposition and the split between aleatoric and epistemic uncertainty.

**19. What is the best predictor of X given Y under squared loss?** E\[X | Y\], the conditional expectation. Under absolute loss it is the conditional median instead, which is why L1 regression estimates medians.

**20. Why are all points roughly equidistant in high dimensions?** Squared distance is a sum of d independent terms, so its mean grows like d while its standard deviation grows like sqrt(d), making the relative spread shrink like 1/sqrt(d). Nearest-neighbour methods degrade accordingly.

**21. Where does the mass of a high-dimensional Gaussian live?** On a thin shell of radius about sqrt(d). The density peaks at the origin but there is almost no volume there. This is why spherical interpolation beats linear interpolation between latent codes.

**22. What does Johnson-Lindenstrauss say and why does it matter?** A random projection into O(log(n)/epsilon^2) dimensions preserves all pairwise distances among n points to within a factor 1 plus epsilon. The target dimension depends on the number of points, not the source dimension. It is the basis of random projection and of the superposition hypothesis.

**23. What is importance sampling and when does it fail?** Reweight samples from a proposal q by p/q to estimate expectations under p. It fails when q has little mass where p and f are large: a few huge weights dominate, the effective sample size collapses, and the failure is invisible in the estimate itself.

**24. What is a control variate, and give an ML example.** Subtract a correlated quantity with known mean to reduce variance without adding bias. The baseline in policy gradients is exactly this: subtracting V(s) from the return leaves the gradient unbiased, since the expected score is zero, while cutting variance substantially.

**25. Why is Monte Carlo the method of choice in high dimensions?** Its error falls as 1/sqrt(n) regardless of dimension, whereas grid-based quadrature needs exponentially many points. The rate is slow, but it is the only rate that does not degrade with d.

**26. Sensitivity, specificity, precision: which depends on the base rate?** Precision. Sensitivity and specificity are properties of the test conditioned on the true state; precision is a posterior and therefore depends on the prevalence. This is why precision-recall curves are preferred on imbalanced data and ROC curves can look deceptively good.

## 3.12 Assignment and solutions

### Solutions to the in-text exercises

**3.1.** (a) Yes. Uniform on \[0, 0.1\] has density 10. No contradiction, because the density integrates to 1 over an interval of length 0.1. (b) Exponential with rate 1. P(-log X > t) = P(X < e^{-t}) = e^{-t}, which is the exponential survival function. This is inverse transform sampling in action. (c) X is a *function* on the sample space; -X is a different function with the same induced distribution. Distribution is a property of one variable; correlation is a property of the pair, and it depends on how they co-vary on the same outcomes.

**3.2.** (a) Two features extracted from the same image, such as "contains fur texture" and "contains a tail shape": correlated in the data, but nearly independent given the label "cat". This is exactly naive Bayes' assumption and why it is often approximately reasonable. (b) The assumption is that word occurrences are conditionally independent given the class: p(words | spam) is the product of p(word | spam). It is false, since words are strongly correlated, but the resulting classifier often ranks correctly even with badly calibrated probabilities, because the errors in the product tend to affect both classes similarly. (c) P = 0.99 x 0.5 / (0.99 x 0.5 + 0.01 x 0.5) = 0.99. With a 50% base rate the two populations are the same size, so the true positives are no longer swamped. The base rate, not the test, drove the earlier answer.

**3.3.** (a) Let I\_i indicate that item i is fixed. E\[I\_i\] = 1/n, so by linearity the expected number of fixed points is n times 1/n = 1, for every n. The dependence between the indicators is severe and completely irrelevant. (b) Var = (sigma^2/k)(1 + (k-1)rho), which tends to rho sigma^2 as k grows. **Ensembling reduces variance only down to the correlation floor**, which is precisely why diversity between ensemble members matters more than the number of members, and why bagging perturbs the data to decorrelate the trees. (c) Aleatoric is E\[Var(X|Y)\], the noise that remains even with perfect knowledge of Y, irreducible by more data. Epistemic is Var(E\[X|Y\]), variation in what you would predict, reducible by learning more.

**3.4.** (a) Poisson, because requests arrive as many independent rare chances. Abandon it if the variance exceeds the mean (overdispersion, from bursty or correlated traffic), in which case use a negative binomial. (b) Beta, because the quantity is a proportion in \[0,1\]. Beta(a,b) acts like a pseudo-count of a - 1 prior successes and b - 1 prior failures, so Beta(1,1) is uniform and Beta(20,80) encodes a fairly confident belief near 20%. (c) Use MGFs: the MGF of a Poisson is exp(lambda(e^t - 1)), and the product of two such is exp((lambda\_1 + lambda\_2)(e^t - 1)), which is Poisson. Intuitively obvious because merging two independent streams of rare events gives another stream of rare events with the added rate.

**3.5.** (a) Conditional mean = Sigma\_12/Sigma\_22 times x\_2 = (1/1)(3) = 3; conditional variance = 4 - (1)(1)(1) = 3. So N(3, 3). (b) Marginal variance was 4, conditional is 3, a reduction of 1 = Sigma\_12^2/Sigma\_22. Observing a correlated variable always reduces variance by the squared covariance over the observed variance. (c) Precisions are 1/4 and 1. Posterior precision is 1.25 so posterior variance is 0.8; posterior mean is (0.25 x 10 + 1 x 12)/1.25 = 14.5/1.25 = 11.6. The estimate sits much closer to the more precise sensor, and the fused variance is smaller than either input's.

**3.6.** (a) y = x^2, so x = sqrt(y) and dx/dy = 1/(2 sqrt y). Density is 1/(2 sqrt y) on (0,1), which integrates to \[sqrt y\] from 0 to 1 = 1. Note that it diverges at 0 while remaining integrable. (b) Lognormal: p(y) = (1/y) times the standard normal density of log y, for y > 0. Its mean is e^{1/2}, not 1, because E\[e^X\] > e^{E\[X\]} by Jensen — the exponential is convex. This is exactly why average log-returns and log average-returns differ in finance. (c) z = mu + sigma \* epsilon with epsilon \~ N(0,I) detached. The gradient flows through mu directly and through sigma multiplied by the sampled epsilon; nothing flows through epsilon itself.

**3.7.** (a) Standard error = sqrt(0.83 x 0.17/1000) = 0.0119, so the interval is roughly 0.83 plus or minus 0.023, that is (0.807, 0.853). Assumes the test examples are i.i.d. draws from the deployment distribution, which is usually the assumption that actually fails. (b) The standard error of a difference of two proportions near 0.9 with n each is about sqrt(2 x 0.9 x 0.1/n). For the difference 0.01 to exceed two standard errors you need n of roughly 7,200 per model, and more if the comparison is unpaired. The alarming version: most published one-point improvements on test sets of a few thousand are not statistically distinguishable unless the evaluation is paired. Use the same test set and a paired test, which removes the shared difficulty variance and helps a great deal. (c) The Cauchy has no finite mean or variance, so the CLT does not apply, and the average of n Cauchy samples is exactly Cauchy again. The lesson for training: if your per-step loss has very heavy tails, averaging over a batch does not tame the outliers the way your intuition expects, which is part of why gradient clipping is effective where simply increasing batch size is not.

**3.8.** (a) t = 0.02, delta = 0.01: n = log(2/0.01)/(2 x 0.0004) = 5.30/0.0008, about 6,600 examples. (b) Hoeffding gives t = sqrt(log(40)/2000) = sqrt(0.00184) = 0.043. Bernstein with sigma^2 = 0.005 x 0.995 = 0.005 gives a far tighter width, roughly 0.007. The gap is nearly sixfold, because Hoeffding only knows the loss is in \[0,1\] while Bernstein knows it is almost always 0. (c) Because you selected the hypothesis using the same data you are evaluating on, so you need the bound to hold simultaneously for every candidate; otherwise you are reporting the minimum of many noisy estimates, which is biased downward. Ignoring it is exactly the mechanism behind overfitting to a validation set through repeated model selection.

**3.9.** (a) About sqrt(1000) = 31.6, with standard deviation of the norm around 1/sqrt(2), so roughly 0.7. Extremely concentrated. (b) d ≈ 8 log(10000)/0.01 ≈ 8 x 9.2/0.01, on the order of 7,400 dimensions; the constants in JL are famously pessimistic and in practice far fewer suffice, but the log(n) scaling is the structural point. (c) Because the straight line between two typical latent vectors passes near the origin, where the model has seen essentially no training mass, so the decoder is out of distribution there. Slerp keeps the interpolation on the sphere of radius sqrt(d) where the mass actually lives.

**3.10.** (a) E\_q\[b times the gradient of log q\] = b times the integral of the gradient of q, which is b times the gradient of the integral of q, which is b times the gradient of 1, which is zero. So subtracting any constant (or any function of variables the distribution is conditioned on, such as the state) leaves the expectation unchanged. (b) Sum of weights = 100 + 999 = 1099; sum of squares = 10000 + 999 = 10999. ESS = 1099^2/10999 = 109.8. So 1000 samples carry about 110 samples' worth of information, and one sample supplies roughly 9% of the total weight. (c) Because the two accuracies share the same test-set difficulty noise, and the variance of a difference is Var(A) + Var(B) - 2Cov(A,B). Positive correlation from the shared examples subtracts, often dramatically. This is the common-random-numbers idea.

### Problem set

**P1 (conditioning).** Three prisoners, one pardoned at random. Prisoner A asks the guard to name one of B or C who will be executed; the guard names B. Compute A's posterior probability of pardon, stating the guard's protocol explicitly, and explain why the answer changes if the guard's tie-breaking rule changes.

**P2 (expectation).** A coupon collector draws uniformly at random from n coupon types with replacement. Find the expected number of draws to collect all n, using indicators and the geometric distribution. Give the asymptotic form.

**P3 (variance algebra).** Prove the law of total variance from the definitions. Then apply it to the bias-variance decomposition of squared prediction error.

**P4 (Gaussian).** Let X and Y be jointly Gaussian with zero means, unit variances, and correlation rho. (a) Find E\[Y|X\]. (b) Find Var(Y|X). (c) Show that X and Y - rho X are independent, and explain what that construction is doing geometrically.

**P5 (change of variables).** Let z \~ N(0, I\_2) and let x = Az for an invertible A. Derive the density of x directly from the change-of-variables formula and confirm it matches the multivariate Gaussian with covariance AA'.

**P6 (MLE preview).** You observe n i.i.d. draws from N(mu, sigma^2). Write the log-likelihood, maximize it over mu and sigma^2, and show that the MLE for the variance divides by n rather than n - 1. Explain the resulting bias.

**P7 (concentration).** You want to be 99% sure that your estimate of a model's accuracy is within 0.5%. How many test examples do you need under Hoeffding? Under Bernstein if the model is 95% accurate? Comment on the practical difference.

**P8 (estimator design).** You want to estimate E\[f(X)\] where f is expensive and X \~ N(0,1). You also know E\[X^2\] = 1 exactly, and you suspect f correlates with X^2. Design a control-variate estimator, derive the optimal coefficient, and state the variance reduction achieved.

**P9 (coding).** Simulate: (a) verify the CLT by averaging n samples from a heavily skewed distribution for several n and plotting histograms; (b) verify the Gaussian annulus theorem by histogramming the norms of standard Gaussian samples in d = 2, 10, 100, 1000; (c) verify that ensembling variance bottoms out at rho sigma^2 using correlated predictors.

**P10 (synthesis).** Explain in one paragraph why each of these is the same underlying fact: variances add for independent variables; the standard error is sigma/sqrt(n); Monte Carlo error falls as 1/sqrt(n); doubling the batch size reduces gradient noise by only 30%; and you need roughly 18,000 test examples to resolve 1% of accuracy.

### Selected solutions

**P1.** State the protocol: the guard always names a prisoner other than A who will be executed, choosing uniformly at random when both B and C qualify. Then P(guard says B | A pardoned) = 1/2, P(guard says B | B pardoned) = 0, P(guard says B | C pardoned) = 1. With equal priors of 1/3, the posterior for A is (1/3)(1/2) divided by (1/3)(1/2) + 0 + (1/3)(1), which is (1/6)/(1/2) = 1/3. A's chance is unchanged, while C's rises to 2/3. If instead the guard always prefers to name B when both qualify, then P(says B | A pardoned) = 1 and A's posterior becomes 1/2. **The answer depends on the protocol, not just the observation**, which is the entire lesson and the same one behind the Monty Hall problem.

**P2.** After collecting k distinct coupons, the probability that a new draw is novel is (n-k)/n, so the wait is geometric with mean n/(n-k). Summing over k from 0 to n-1 gives n times the harmonic number H\_n, which is approximately n(log n + gamma). So collecting all n takes about n log n draws, not n. This is the standard "why does the tail of a vocabulary take so long to cover" result, and it explains a great deal about rare-token behavior in language data.

**P3.** Start from Var(X) = E\[X^2\] - (E\[X\])^2. Apply the tower property to both: E\[X^2\] = E\[E\[X^2|Y\]\] = E\[Var(X|Y) + (E\[X|Y\])^2\]. Substituting, Var(X) = E\[Var(X|Y)\] + E\[(E\[X|Y\])^2\] - (E\[E\[X|Y\]\])^2, and the last two terms are precisely Var(E\[X|Y\]). For the bias-variance decomposition, condition on the training set: expected squared error decomposes into irreducible noise, the squared bias of the average prediction, and the variance of the prediction across training sets.

**P4.** (a) By the conditional formula, E\[Y|X\] = rho X. (b) Var(Y|X) = 1 - rho^2, independent of X. (c) Cov(X, Y - rho X) = rho - rho = 0, and both are jointly Gaussian, so zero covariance gives independence. Geometrically this is Gram-Schmidt: you are projecting Y onto X and keeping the orthogonal residual. The residual carries variance 1 - rho^2, which is exactly the conditional variance from (b), and "regression is projection" (section 1.5) and "conditioning is regression" (section 3.5) are the same statement seen twice.

**P6.** The log-likelihood is -(n/2)log(2 pi sigma^2) - (1/(2 sigma^2)) times the sum of squared deviations. Differentiating with respect to mu gives the sample mean. Differentiating with respect to sigma^2 and setting to zero gives sigma^2 = (1/n) times the sum of squared deviations from the sample mean. It divides by n, so it is biased low by a factor (n-1)/n. The reason is the one from section 3.3: the deviations are taken from the fitted mean rather than the true mean, so they understate the true spread, and maximum likelihood does not correct for that. **MLE is not in general unbiased**, which is a point Chapter 4 develops.

**P7.** Hoeffding: n = log(2/0.01)/(2 x 0.005^2) = 5.30/0.00005 = 106,000 examples. Bernstein with sigma^2 = 0.95 x 0.05 = 0.0475: the dominant term gives roughly n = 2 sigma^2 log(2/delta)/t^2 = 2(0.0475)(5.30)/0.000025, about 20,000. So the variance-aware bound cuts the requirement by a factor of five. The practical point: when a model is accurate, the loss has far less variance than its range suggests, and using the range-only bound overstates the data you need substantially.

**P10.** All five are the statement that **independent errors add in variance, hence in quadrature, so averaging n of them shrinks the standard deviation by sqrt(n) and not by n**. The standard error is that statement for a sample mean; Monte Carlo error is that statement for an estimator; a minibatch gradient is a sample mean of per-example gradients, so its noise falls as 1/sqrt(batch), and doubling the batch multiplies the noise by 1/sqrt(2), about 0.71, hence a 30% reduction for double the compute; and the test-set size needed for a given precision goes as 1/t^2, which is why resolving 1% requires tens of thousands of examples while resolving 5% requires only hundreds. One square root, five consequences.

**P5.** Change of variables in two dimensions. With x = Az and z standard normal in R^2, the inverse is z = A^{-1}x and the Jacobian of that inverse map is A^{-1}, whose determinant is 1/det(A). So

$$
p_x(x) = p_z(A^{-1}x)\,\big|\det A^{-1}\big| = \frac{1}{2\pi}\exp\!\left(-\tfrac{1}{2}(A^{-1}x)^{\top}(A^{-1}x)\right)\frac{1}{|\det A|}
$$

The exponent is -0.5 x' A^{-T} A^{-1} x = -0.5 x' (AA')^{-1} x, using that the inverse of a product reverses order. Setting Sigma = AA', the exponent is the Mahalanobis form and the constant is 1/(2 pi |det A|) = 1/(2 pi |Sigma|^{1/2}), since det(AA') = (det A)^2. That is exactly the bivariate Gaussian density with covariance AA', confirming the transformation rule from section 3.5 by an independent route.

**P7.** Cost against the false-positive requirement. Hoeffding with t = 0.005 and delta = 0.01: n = log(2/0.01)/(2 times 0.005^2) = 5.298/0.00005 = **105,966 examples**. Bernstein with sigma^2 = 0.95 times 0.05 = 0.0475: the variance-dominated term gives n = 2 sigma^2 log(2/delta)/t^2 = 2(0.0475)(5.298)/0.000025 = **20,133 examples**. The practical difference is a factor of about 5.3, which is the difference between a feasible and an infeasible labelling budget. The lesson: when a model is accurate, its per-example loss is almost always 0 and only occasionally 1, so its variance (0.0475) is far below the worst case its range allows (0.25). Hoeffding only knows the range; Bernstein knows the variance. **Use the variance-aware bound whenever your quantity is bounded but concentrated near one end**, which describes essentially every accuracy measurement on a good model.

**P8.** Control variate with g(X) = X^2 and known E\[g\] = 1. The estimator is the average of f(x\_i) - c(x\_i^2 - 1). It is unbiased for any c because the subtracted term has mean zero. Its variance is

$$
\operatorname{Var}(f) - 2c\operatorname{Cov}(f, g) + c^2\operatorname{Var}(g)
$$

Minimizing over c (differentiate, set to zero) gives c\* = Cov(f,g)/Var(g), and substituting back gives the minimum variance as Var(f)(1 - rho^2) with rho the correlation between f and g. For a standard normal, Var(X^2) = 2, so c\* = Cov(f, X^2)/2. **If f correlates with X^2 at rho = 0.9, you remove 81% of the variance**, equivalent to a fivefold increase in sample size for free. In practice c is estimated from the same samples, which introduces a small bias; using a held-out subset to estimate c removes it.

**P9 (coding).** What you should see. (a) Averaging n draws from, say, an exponential or lognormal: at n = 1 the histogram is visibly skewed; by n = 5 it is noticeably more symmetric; by n = 30 it is close to Gaussian but with a detectable right tail; by n = 100 the deviation is hard to see by eye. Plot a normal QQ plot alongside, and the tail departure is far more visible than in the histogram — that is the point of QQ plots. (b) Norms of standard Gaussian samples: at d = 2 the distribution of the norm is broad and includes values near zero; at d = 10 it is centred near 3.16 with visible spread; at d = 100 it is tightly centred near 10; at d = 1000 near 31.6 with a standard deviation of about 0.7, so the relative spread is about 2%. **The mode of the density is at the origin at every d, yet the probability of landing near the origin goes to zero** — density and mass diverging, exactly as section 3.9 claims. (c) Ensemble variance: plotting variance against k for several rho values shows each curve flattening at rho sigma^2 rather than approaching zero, confirming that decorrelation, not count, is the binding constraint.
