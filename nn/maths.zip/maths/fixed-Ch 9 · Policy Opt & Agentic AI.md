﻿# Chapter 9 · Policy Optimization and Agentic AI

2026-09-22 · @Behi

This is where the tutorial arrives. Every tool built so far — the log-derivative trick from Chapter 3, KL divergence and its asymmetry from Chapter 5, trust regions and the Fisher metric from Chapter 6, conditional expectations and the advantage from Chapter 8 — combines here into the methods that actually train modern agents.

The chapter's spine: **you cannot differentiate through a sampling step, so you use the score-function estimator; its variance is enormous, so you subtract a baseline; the resulting updates are unreliable far from the current policy, so you constrain them with a KL trust region. Everything from REINFORCE to PPO to DPO is a point on that path.**

## 9.1 Why optimize the policy directly

### The change of target

Chapter 8 learned a value function and derived a policy from it. Here we parameterize the policy itself, pi(a | s; theta), and do gradient ascent on the objective:

$$
J(\theta) = \mathbb{E}_{\tau \sim \pi_\theta}\big[ R(\tau) \big]
$$

where tau is a trajectory. This is the most direct thing you could do: **optimize what you actually care about, with respect to the thing you actually control.**

### When this is the right choice

| Situation | Why policy gradients win |
| --- | --- |
| **Continuous action spaces** | no max over actions is needed; output the parameters of a distribution |
| **Large or structured action spaces** | a language model's action space is the vocabulary, and sequences of it |
| **Stochastic optimal policies** | in partially observed settings randomization can be genuinely optimal, and a greedy value method cannot represent it |
| **Smooth improvement** | small parameter changes give small policy changes, whereas an argmax over Q can flip discontinuously on a tiny value change |
| **Natural to fine-tune a pretrained model** | you already have a policy; you do not have a value function |

That last row is the decisive one for agentic AI. **A pretrained language model is already a policy** — it maps contexts to distributions over next tokens. Fine-tuning it with a policy gradient is a natural continuation of what it already does; constructing a value-based controller over a 100,000-action space with sequence-level rewards is not.

The smoothness point deserves a sentence too. In value-based control, a small change in Q can flip the argmax and change behaviour completely. In policy-based methods, a small parameter change produces a small change in action probabilities. That continuity is what makes trust regions meaningful and what makes the methods in sections 9.5 and 9.6 possible at all.

### The costs

Be honest about these, because they define the rest of the chapter:

- **High variance.** The score-function estimator (Chapter 3) does not use the reward's derivative, only its value, so it is a much noisier estimator than a pathwise one. Essentially every technique in sections 9.3 to 9.6 exists to reduce this variance.
- **On-policy by default.** The gradient is an expectation under the current policy, so data goes stale as soon as you update. That is a serious sample-efficiency cost, and importance sampling (section 9.5) is the partial remedy.
- **Local convergence only.** You get a stationary point of a non-convex objective, with no global guarantee.
- **Sensitive to step size in an unusual way.** A too-large step can collapse the policy irrecoverably, because the policy determines the data it will next see. In supervised learning a bad step is corrected by the next batch; in RL a bad step changes which batches exist.

### The obstacle, stated precisely

You want the gradient of an expectation whose *distribution* depends on theta:

$$
\nabla_\theta\, \mathbb{E}_{\tau\sim\pi_\theta}\big[R(\tau)\big]
$$

You cannot simply move the gradient inside, because theta is not in R — it is in the sampling distribution. And you cannot use the reparameterization trick in general, because the trajectory involves discrete actions and unknown environment dynamics, so there is no differentiable path from theta to the reward.

Chapter 3 gave the two estimators for exactly this situation, and this is the case where only one of them applies. **The score-function estimator is the tool**, and section 9.2 derives what it gives you here.

### Policy parameterizations

Worth having the standard choices at hand:

- **Discrete actions:** a softmax over logits produced by the network. As Chapter 5 showed, this is also the exact solution to entropy-regularized reward maximization, so it is principled and not merely convenient.
- **Continuous actions:** a Gaussian with network-predicted mean and (usually state-independent) log standard deviation. Bounded action spaces use a squashed variant, typically a tanh-transformed Gaussian, which requires a change-of-variables correction (Chapter 3) to its log-probability.
- **Language models:** a softmax over the vocabulary at each position. A whole response is a trajectory, and its log-probability is the sum of per-token log-probabilities — which is the chain rule of probability from Chapter 3, and it is why sequence-level policy gradients decompose into per-token terms.

**Try it.** (a) Why can you not use the reparameterization trick for a standard RL trajectory? (b) Give two concrete reasons a language model is more naturally fine-tuned by policy gradient than by Q-learning. (c) Why does a too-large policy update cause a problem that a too-large supervised update does not? Answers in 9.12.

## 9.2 The policy gradient theorem

### The derivation

This derivation is four lines and you should be able to produce it on demand. It is the most commonly asked derivation in RL interviews.

Start with the objective as an integral over trajectories:

$$
J(\theta) = \int p_\theta(\tau)R(\tau)\,d\tau \quad \Longrightarrow \quad \nabla_\theta J = \int \nabla_\theta p_\theta(\tau)\,R(\tau)\,d\tau
$$

Now apply the **log-derivative trick** — multiply and divide by p, and recognize the result:

$$
\nabla_\theta p_\theta(\tau) = p_\theta(\tau)\,\frac{\nabla_\theta p_\theta(\tau)}{p_\theta(\tau)} = p_\theta(\tau)\,\nabla_\theta \log p_\theta(\tau)
$$

Substituting turns the integral back into an expectation, which is the whole point — now it can be estimated from samples:

$$
\nabla_\theta J = \mathbb{E}_{\tau\sim\pi_\theta}\big[ R(\tau)\,\nabla_\theta \log p_\theta(\tau) \big]
$$

### The step that makes it usable

The trajectory probability factors into environment dynamics and policy terms:

$$
p_\theta(\tau) = p(s_0)\prod_t P(s_{t+1}\mid s_t,a_t)\,\pi_\theta(a_t\mid s_t)
$$

Taking logs turns the product into a sum, and **every term that does not involve theta differentiates to zero** — which means the initial-state distribution and the entire transition model vanish:

$$
\nabla_\theta \log p_\theta(\tau) = \sum_t \nabla_\theta \log \pi_\theta(a_t \mid s_t)
$$

**This is the crucial observation. The gradient does not require knowing the dynamics.** You never need P, you never need to differentiate through the environment, and the whole method is therefore model-free. If you take one thing from this section, take that.

The result:

$$
\nabla_\theta J = \mathbb{E}\left[ \left(\sum_t \nabla_\theta \log \pi_\theta(a_t\mid s_t)\right) R(\tau) \right]
$$

### What it means

Read the formula as an instruction: **increase the log-probability of actions that appeared in high-return trajectories, decrease it for low-return ones, in proportion to the return.** It is trial and error, formalized and made differentiable.

The practical implementation is a pleasant surprise: define a **surrogate loss** whose gradient equals the policy gradient, and hand it to your autodiff framework.

$$
\mathcal{L}^{\text{surr}} = -\frac{1}{N}\sum_{i}\sum_t \log\pi_\theta(a_t^i\mid s_t^i)\,\hat{A}_t^i
$$

This looks exactly like a weighted cross-entropy loss — because it is one. **Policy gradient is supervised learning on your own actions, weighted by how good they turned out to be.** The advantage (or return) is a *coefficient*, so it must be detached (Chapter 2); differentiating through it would compute something else entirely. Saying "it's weighted cross-entropy with detached weights" is a strong, concrete answer.

### Two refinements that come free

**Causality (reward-to-go).** An action at time t cannot affect rewards received before t, so multiplying its score by the full trajectory return adds pure noise. Replace R(tau) with the return from t onward:

$$
\nabla_\theta J = \mathbb{E}\left[\sum_t \nabla_\theta\log\pi_\theta(a_t\mid s_t)\;\underbrace{\sum_{t'\ge t}\gamma^{t'-t}r_{t'}}_{\text{reward-to-go}}\right]
$$

This is unbiased — the dropped terms have zero expectation, because past rewards are independent of the current action's score — and strictly lower variance.

**Baselines.** Subtract any function of the state:

$$
\nabla_\theta J = \mathbb{E}\big[\nabla_\theta\log\pi_\theta(a_t\mid s_t)\,\big(G_t - b(s_t)\big)\big]
$$

This remains unbiased, and the proof is the score-function identity from Chapter 4: the expected score is zero, so E\[b(s) times the score\] = b(s) times E\[score\] = 0. Section 9.3 develops why this matters so much.

### The general form

The policy gradient theorem in its standard statement:

$$
\nabla_\theta J(\theta) \;\propto\; \mathbb{E}_{s\sim d^{\pi},\,a\sim\pi}\big[ \nabla_\theta\log\pi_\theta(a\mid s)\,Q^{\pi}(s,a) \big]
$$

where d-pi is the discounted state-visitation distribution under the policy. Note the subtlety, which is worth flagging because most implementations quietly ignore it: **the state distribution also depends on theta**, and the theorem's achievement is showing that you do not need to differentiate through it — the gradient of the state distribution contributes nothing to the final expression. That is the non-obvious content of the theorem, beyond the log-derivative manipulation.

In practice implementations also drop the gamma^t weighting that the discounted-visitation measure formally requires, making them biased with respect to the discounted objective. This is universal, well known, and empirically harmless, and knowing it is a mark of having read carefully.

**Try it.** (a) Reproduce the four-line derivation without looking. (b) Prove that subtracting a state-dependent baseline leaves the estimator unbiased. (c) Why does the transition model disappear from the gradient, and why does that matter? Answers in 9.12.

## 9.3 REINFORCE and the variance problem

### The algorithm

1. Run the current policy to collect trajectories.
2. Compute the reward-to-go at each step.
3. Take a gradient step on the surrogate loss.
4. Throw the data away (it is now off-policy) and repeat.

That is the whole algorithm, and it is both correct and nearly unusable in its raw form.

### Why the variance is so bad

Three compounding sources:

1. **The return is a sum over the whole episode.** Variances of independent contributions add (Chapter 3), so a 1,000-step episode has roughly 1,000 times the variance of a single step.
2. **The score function has no bound.** Rare actions have large negative log-probabilities, so their scores are large, and they appear precisely where estimates are least reliable.
3. **The estimator never uses the reward's derivative.** It only uses its *value* as a scalar weight, which is the defining weakness of the score-function estimator (Chapter 3). A pathwise estimator would know which direction to move; this one only knows whether the outcome was good.

The consequence is stark: **plain REINFORCE can need orders of magnitude more samples than a variance-reduced variant to reach the same performance.** Every technique below is a variance-reduction method, and that framing — variance reduction is the entire field — is the right way to organize this material.

### Baselines, properly understood

Subtracting a state-dependent baseline is unbiased (section 9.2), and the natural question is which baseline minimizes variance. The answer connects to Chapter 3's control variates.

**The right baseline is (approximately) the value function.** Then

$$
G_t - V(s_t) \;\approx\; A(s_t, a_t)
$$

and you are weighting each action's score by **how much better than average** it was, rather than by how good the outcome was in absolute terms.

Why that matters enormously, with a concrete example. Suppose every action in a state yields a return between 1,000 and 1,010. Without a baseline, every action gets a large positive weight and every action's probability is pushed up — the differences that actually matter are a 1% ripple on a huge common signal. Subtract V(s) ≈ 1,005 and the weights become roughly -5 to +5, centred on zero: **good actions go up, bad actions go down, and the common component is gone.**

This is exactly the control-variate calculation from Chapter 3, where the variance reduction factor is (1 - rho^2) and rho is the correlation between the return and the baseline. A good value function is highly correlated with the return, so the reduction is large.

The practically used baselines, in increasing sophistication:

| Baseline | Notes |
| --- | --- |
| Batch mean return | free, no learning, surprisingly effective |
| Learned V(s) | the standard actor-critic choice |
| Mean over a group of samples for the same prompt | the GRPO approach (section 9.8) |
| Time-dependent or per-state variants | occasionally used |

### Why the baseline must not depend on the action

A common and instructive mistake. The unbiasedness proof requires E\[b times the score\] = 0, which uses b coming out of the expectation over actions. If b depends on a, it does not come out, and **the estimator becomes biased.** That is why the baseline is V(s), a function of state only, and why using Q(s,a) as a baseline would be wrong. (Action-dependent baselines can be made unbiased with additional correction terms, which is a real line of research, but the naive version is simply wrong.)

### Entropy regularization

Add a bonus for policy entropy:

$$
\mathcal{L} = \mathcal{L}^{\text{PG}} - \beta\,\mathbb{E}\big[H(\pi(\cdot\mid s))\big]
$$

The motivation is **premature convergence**: policy gradients have a self-reinforcing failure mode where an action that happens to get sampled and rewarded early gets higher probability, hence gets sampled more, hence dominates — and the policy collapses onto it before alternatives are ever tried. Since the policy generates its own data, that collapse is self-sealing.

The entropy bonus resists this, and by Chapter 5 it is not a heuristic: it makes the objective the maximum-entropy one whose exact optimum is a softmax over Q divided by the entropy weight. In language-model fine-tuning the same role is usually played by the **KL penalty to the reference model**, which additionally anchors the policy to a sensible prior rather than merely to uniformity.

### Other variance reduction that carries over

Everything from Chapter 3, section 3.10 applies directly:

- **Reward normalization.** Standardizing advantages within a batch (subtract mean, divide by standard deviation) is near-universal. It changes the effective step size rather than the direction, and it makes learning rates transfer across tasks with different reward scales.
- **Common random numbers** when comparing configurations.
- **Rao-Blackwellization:** compute exactly whatever you can, such as summing over actions analytically in small discrete spaces instead of sampling one.
- **More samples**, which reduces variance as 1/sqrt(N) and is the brute-force option that distributed RL systems exploit.

**Try it.** (a) In a state where all returns lie in \[1000, 1010\], compare the gradient weights with and without a baseline. (b) Show that an action-dependent baseline breaks unbiasedness, identifying exactly which step of the proof fails. (c) Why does entropy regularization prevent premature collapse, and what plays that role in RLHF? Answers in 9.12.

## 9.4 Actor-critic and GAE

### The structure

Train two things together:

- **The actor**, pi(a | s; theta), which chooses actions.
- **The critic**, V(s; phi), which estimates state values and serves as the baseline.

$$
\text{Actor: } \; \nabla_\theta \mathcal{L} = -\mathbb{E}\big[\nabla_\theta\log\pi_\theta(a\mid s)\,\hat{A}\big], \qquad \text{Critic: } \; \mathcal{L}(\phi) = \mathbb{E}\big[(V_\phi(s) - \hat{R})^2\big]
$$

The critic is trained by ordinary regression toward a return target; the actor uses the critic's output only as a detached coefficient.

This is generalized policy iteration from Chapter 8, with both pieces approximated: the critic performs approximate policy evaluation, the actor performs approximate policy improvement, and they interleave continuously rather than in discrete phases.

**Why the critic changes the bias-variance trade.** REINFORCE uses the full Monte Carlo return: unbiased, very high variance. A one-step actor-critic target r + gamma V(s') is biased (because V is wrong) but has far lower variance. This is exactly the MC-versus-TD trade from Chapter 8, now appearing inside the advantage estimate.

### Generalized advantage estimation

GAE interpolates between the two extremes, and it is what essentially every modern implementation uses.

Start with the TD error, which Chapter 8 established is an unbiased advantage estimate when V is correct:

$$
\delta_t = r_t + \gamma V(s_{t+1}) - V(s_t)
$$

Then define the GAE advantage as an exponentially weighted sum of future TD errors:

$$
\hat{A}_t^{\text{GAE}(\gamma,\lambda)} = \sum_{l=0}^{\infty}(\gamma\lambda)^l\,\delta_{t+l}
$$

**This is TD(lambda) applied to advantages.** The endpoints:

| lambda | Estimate | Character |
| --- | --- | --- |
| 0 | delta\_t alone | maximum bias, minimum variance |
| 1 | the full return minus V(s\_t) | unbiased, maximum variance |
| 0.95 | the usual choice | a good practical compromise |

The two knobs do different jobs, and conflating them is a common confusion:

- **gamma** sets how far into the future rewards matter — it defines the objective.
- **lambda** sets how much you trust the critic versus the observed rewards — it is purely a bias-variance knob on the estimator, not part of the objective.

Typical values are gamma = 0.99 and lambda = 0.95, and the implementation is a simple backward recursion:

$$
\hat{A}_t = \delta_t + \gamma\lambda\,\hat{A}_{t+1}
$$

computed from the end of the trajectory backwards, which takes about three lines of code.

### Critic training details that matter

- **The target.** Regress V toward the GAE-based return estimate, that is A-hat + V(s\_t), rather than toward the raw Monte Carlo return. This is more stable and is what standard implementations do.
- **Shared or separate networks.** Sharing a trunk between actor and critic saves computation and can help representation learning, but it couples the two losses and requires balancing their scales. For language models the critic is usually a separate head on the same backbone, or dispensed with entirely (section 9.8).
- **Value loss clipping.** Some implementations clip the value function update in a manner analogous to PPO's policy clipping; its benefit is debated.
- **Normalization.** Normalizing returns or value targets matters, because reward scales vary by orders of magnitude across tasks and an unnormalized critic loss can dominate or be dominated by the policy loss.

### The family

| Method | Distinguishing feature |
| --- | --- |
| A2C | synchronous parallel environments, shared parameters |
| A3C | asynchronous workers with a shared parameter server (largely superseded) |
| **PPO** | clipped surrogate objective with multiple epochs per batch (section 9.6) |
| TRPO | explicit KL constraint solved with conjugate gradient (section 9.5) |
| SAC | off-policy, maximum-entropy, twin critics; standard for continuous control |
| IMPALA | distributed, with V-trace importance correction for lagging actors |

### Why this is the shape of modern agentic training

The actor-critic structure is what RLHF uses, and the correspondence is worth stating explicitly: the **actor** is the language model being fine-tuned; the **critic** is a value head estimating the expected reward of a partial response; the **advantage** measures whether a particular generated continuation was better than that model expected; and the **reward** comes from a learned reward model rather than the environment. Sections 9.7 and 9.8 fill that in, and the fact that the machinery is unchanged is the point — RLHF is actor-critic RL with a learned reward.

**Try it.** (a) Write the GAE recursion and explain why it is computed backwards. (b) What do gamma and lambda each control, and why is it wrong to think of them as the same kind of knob? (c) Why is the advantage detached in the actor's loss? Answers in 9.12.

## 9.5 Trust regions and TRPO

### The problem being solved

Policy gradient gives a direction but no reliable step size, and the consequence of a bad step is worse in RL than anywhere else. **The policy determines the data it will next collect.** A step that degrades the policy produces worse data, which produces a worse gradient, which produces a worse policy. Supervised learning has no equivalent of this failure mode, because the data is fixed.

So you want a step that is **guaranteed not to make things worse**, or at least is constrained to a region where your estimates remain trustworthy.

### The surrogate objective

Start by asking how much better a new policy is than the old one. The policy improvement identity:

$$
J(\pi') - J(\pi) = \mathbb{E}_{\tau\sim\pi'}\left[\sum_t \gamma^t A^{\pi}(s_t,a_t)\right]
$$

**The improvement equals the expected advantage of the new policy's actions, measured under the old policy's advantage function.** This is an exact identity, not an approximation, and it is a lovely result: it says you can evaluate a new policy using the old policy's advantages, provided you can sample states from the new policy.

That proviso is the whole difficulty — you cannot sample from the new policy without deploying it. So approximate by keeping the old policy's state distribution and correcting the action distribution with importance sampling (Chapter 3):

$$
L^{\pi}(\pi') = \mathbb{E}_{s\sim d^{\pi},\,a\sim\pi}\left[ \frac{\pi'(a\mid s)}{\pi(a\mid s)}\,A^{\pi}(s,a) \right]
$$

**This surrogate is accurate when the two policies are close and unreliable when they are not** — precisely because the importance weights blow up, exactly as Chapter 3's effective-sample-size analysis predicts. Hence: constrain the policies to stay close.

### The monotonic improvement bound

The theoretical result that motivates everything:

$$
J(\pi') \;\ge\; L^{\pi}(\pi') - C\cdot \max_s D_{KL}\big(\pi(\cdot\mid s)\,\|\,\pi'(\cdot\mid s)\big)
$$

with C a constant involving gamma and the maximum advantage. Read it: **the true improvement is at least the surrogate minus a penalty for how far you moved.** So if you maximize the right-hand side, you are guaranteed not to make the true objective worse. That is a genuine monotonic improvement guarantee, and it is the reason this line of work exists.

The practical problem is that the theoretically correct C is far too conservative — following it gives steps so small that training would take forever. TRPO therefore converts the penalty into a **constraint** with a tunable radius:

$$
\max_{\theta} \; L(\theta) \quad \text{subject to} \quad \mathbb{E}_s\big[D_{KL}(\pi_{\theta_{\text{old}}} \,\|\, \pi_\theta)\big] \le \delta
$$

This is a constrained optimization problem of exactly the kind Chapter 6 covered, and by the Lagrangian correspondence the constrained and penalized forms are equivalent for some multiplier.

### Solving it, and where the Fisher appears

TRPO solves the constrained problem by expanding both parts to appropriate order: the objective linearly, the KL constraint quadratically. From Chapter 5, the second-order expansion of KL is the Fisher information:

$$
D_{KL} \approx \tfrac{1}{2}(\theta - \theta_{\text{old}})^{\top} F\,(\theta-\theta_{\text{old}})
$$

So the problem becomes: maximize a linear function subject to a quadratic (ellipsoidal) constraint. That has a closed-form solution:

$$
\Delta\theta \;=\; \sqrt{\frac{2\delta}{g^{\top}F^{-1}g}}\; F^{-1}g
$$

**This is the natural gradient** from Chapters 2 and 4, with the step length set by the KL budget rather than by a learning rate. Three chapters converge here, and being able to state that chain — KL constraint, second-order expansion, Fisher metric, natural gradient — is a genuinely strong research-interview answer.

The implementation never forms F. It computes F-inverse times g by **conjugate gradient using Fisher-vector products**, which are computed exactly like the Hessian-vector products of Chapter 2. A final **backtracking line search** verifies that the true KL constraint and a true improvement actually hold, since the quadratic approximation may be inaccurate.

### Why TRPO is not what people use

It works and it has the cleanest theory in the chapter, but:

- Conjugate gradient with Fisher-vector products is complicated to implement correctly.
- Each update requires multiple passes for the CG iterations plus a line search.
- It does not accommodate parameter sharing between actor and critic gracefully, nor architectures with dropout or other stochastic components.
- The theoretical guarantee is lost anyway once you use the tunable delta rather than the conservative C.

PPO achieves most of the benefit with a fraction of the complexity, which is why it won. **But TRPO is the derivation that explains why PPO's objective has the shape it does**, and understanding it in this order is what makes PPO comprehensible rather than arbitrary.

**Try it.** (a) Why is the surrogate objective only trustworthy for nearby policies? Answer in terms of importance weights. (b) Where does the Fisher information enter TRPO, and from which chapter's result? (c) What exactly does the monotonic improvement bound guarantee, and why is it not used directly? Answers in 9.12.

## 9.6 PPO

### The objective

Define the probability ratio between new and old policies:

$$
r_t(\theta) = \frac{\pi_\theta(a_t\mid s_t)}{\pi_{\theta_{\text{old}}}(a_t\mid s_t)}
$$

The clipped surrogate objective:

$$
L^{\text{CLIP}}(\theta) = \mathbb{E}_t\Big[ \min\big( r_t(\theta)\hat{A}_t, \; \operatorname{clip}(r_t(\theta), 1-\epsilon, 1+\epsilon)\,\hat{A}_t \big) \Big]
$$

with epsilon typically 0.2.

### Reading it carefully

The minimum of the clipped and unclipped terms does something specific, and it is worth working through both cases because interviewers ask exactly this.

**When the advantage is positive** (the action was better than expected, so you want to increase its probability): the objective increases with r, but the clip caps it at 1 + epsilon. **Beyond that point there is no further gain**, so the gradient is zero and the optimizer stops pushing. You are prevented from over-committing to an action on the basis of one noisy advantage estimate.

**When the advantage is negative** (you want to decrease the probability): the objective is maximized by making r small, but the clip floors the benefit at 1 - epsilon. Below that, no further gain, so again the gradient vanishes.

**And the asymmetry created by the min is the clever part.** The min ensures the objective is a **pessimistic lower bound** on the unclipped one. The practical effect is that clipping removes the incentive to move further in the direction the update already favours, but it does *not* remove the incentive to come back if the ratio has drifted too far in the harmful direction. So a policy that has strayed can still be pulled back, while one that is straying is stopped. That is why the min is there and not just the clip.

**The clip as a decision table.** Four cases, and the gradient is zero in exactly two of them:

| Advantage | Ratio r | Objective selected by the min | Gradient |
| --- | --- | --- | --- |
| A > 0 | r < 1 + eps | unclipped, r·A | **active** — push probability up |
| A > 0 | r > 1 + eps | clipped, (1+eps)·A | **zero** — stop pushing up |
| A < 0 | r > 1 - eps | unclipped, r·A | **active** — push probability down |
| A < 0 | r < 1 - eps | clipped, (1-eps)·A | **zero** — stop pushing down |

Now the asymmetry the min creates. Suppose A > 0 but the ratio has somehow drifted to 0.5 (the policy moved the *wrong* way). The unclipped term is 0.5A, the clipped term is 0.8A; the min picks 0.5A, which is **not** flat, so the gradient still pulls the ratio back up toward 1. **Clipping stops you going further in the direction you are already favouring; it does not stop you coming back.** Had the objective been the clipped term alone, that recovery gradient would have been destroyed too.

**What PPO is approximating:** TRPO's KL-constrained problem. The clip is a cheap, first-order, per-sample surrogate for "do not let the policy move too far". It abandons TRPO's guarantee and keeps its intent, trading theoretical cleanliness for an objective you can hand to Adam.

### Why this enables multiple epochs

The practical payoff. Vanilla policy gradient must throw away each batch after one step, because the data is off-policy immediately. PPO's importance ratio explicitly accounts for the mismatch, and the clip bounds how much you can exploit stale data. So you can take **several gradient epochs on the same batch**, typically 3 to 10, which improves sample efficiency several-fold.

This is the reason PPO sits awkwardly in the on-policy/off-policy dichotomy: it is on-policy in that data is collected fresh each iteration, but it uses off-policy correction within an iteration.

### The full loss

$$
L = \mathbb{E}\Big[ L^{\text{CLIP}} - c_1 (V_\phi(s) - V^{\text{targ}})^2 + c_2\,H(\pi_\theta(\cdot\mid s)) \Big]
$$

Policy term, value regression, entropy bonus. With c\_1 around 0.5 and c\_2 around 0 to 0.01.

### The implementation details that actually matter

This is worth emphasizing because there is a well-known body of work showing that **much of PPO's advantage over earlier methods comes from implementation choices rather than from the clipped objective itself.** Being able to say that, and name the choices, is a strong signal of practical experience.

| Detail | Why it matters |
| --- | --- |
| **Advantage normalization** per batch | equalizes scale across tasks; arguably the single most important detail |
| **Observation and reward normalization** with running statistics | keeps the value function's targets in a trainable range |
| **Orthogonal initialization**, with a small gain on the policy head | starts the policy near-uniform, avoiding early collapse |
| **Gradient clipping** at global norm 0.5 | guards against the occasional enormous update |
| **Learning-rate annealing** | standard, and matters more here than in supervised learning |
| **Correct handling of episode boundaries** in GAE | a classic silent bug: bootstrapping across a terminal state corrupts advantages |
| **Separate value network** or careful loss weighting | prevents the value loss from dominating the policy loss |
| **Early stopping on KL** | abort the epoch loop if the measured KL exceeds a threshold |

That last one is worth its own sentence: many implementations monitor the empirical KL between old and new policies each epoch and stop early if it exceeds a target. **That is TRPO's constraint reintroduced as a safety check**, which is a nice illustration that the trust-region idea never really went away.

### Failure modes

- **Entropy collapse.** The policy becomes deterministic, exploration stops, and learning stalls. Monitor entropy; it is the most informative diagnostic in a PPO run.
- **Value function divergence.** If value targets are unnormalized and rewards are large, the critic loss dominates and the policy stops improving.
- **KL spikes.** A batch with unusual advantages can push the policy far in one update despite clipping.
- **Reward hacking.** With a learned reward model, the policy finds its errors. Section 9.7.

**Monitor these four quantities**: policy entropy, empirical KL from the old policy, explained variance of the value function, and the fraction of samples being clipped. Together they diagnose nearly every PPO failure, and listing them is a good answer to "how would you debug an RL run?"

### PPO for language models

The adaptation is mostly bookkeeping, but the specifics are worth knowing:

- A **state** is the prompt plus tokens generated so far; an **action** is the next token; an **episode** is one response.
- The reward is typically **terminal** — a single scalar from a reward model for the whole response — so the per-token advantage comes almost entirely from the value function's estimates. This makes the critic unusually important.
- A **per-token KL penalty to the reference model** is subtracted from the reward, which is section 9.7's mechanism.
- Generation dominates the compute. A PPO step requires sampling full responses, which is inference, and inference is slower than the gradient step. This is why efficient rollout infrastructure matters more than optimizer choice in these systems.

**Try it.** (a) Work through what the clipped objective's gradient does when the advantage is positive and r has reached 1.3 with epsilon = 0.2. (b) Why does the min, rather than the clip alone, matter? (c) Name the four quantities you would monitor during a PPO run and what each tells you. Answers in 9.12.

## 9.7 RLHF

### The problem it solves

You cannot write down a reward function for "be helpful and accurate". But people can reliably say which of two responses is better. RLHF's move is to **learn the reward from comparisons** and then optimize it with the machinery of the preceding sections.

### Stage 1: supervised fine-tuning

Train on demonstrations of the desired behaviour with ordinary next-token cross-entropy. In RL terms this is **behaviour cloning**: imitate the demonstrator without any notion of reward. It gets the model into the right region of policy space so that subsequent sampling produces reasonable candidates — which, as section 9.1 noted, is what substitutes for random exploration here.

### Stage 2: reward modelling

Collect comparisons: given a prompt, a human ranks two responses. Then fit a reward model under the **Bradley-Terry** model of preferences, which assumes the probability of preferring y\_w over y\_l is a logistic function of their reward difference:

$$
P(y_w \succ y_l \mid x) = \sigma\big(r_\phi(x,y_w) - r_\phi(x,y_l)\big)
$$

Maximum likelihood under this model gives the loss:

$$
\mathcal{L}(\phi) = -\mathbb{E}\big[\log\sigma\big(r_\phi(x,y_w) - r_\phi(x,y_l)\big)\big]
$$

This is **binary logistic regression on reward differences**, and by Chapter 4 the sigmoid is the inverse canonical link of the Bernoulli family — so the whole stage is a GLM, and the entire machinery of Chapter 4 applies to it.

Two structural facts worth knowing. First, **the reward is only identified up to an additive constant per prompt**, since only differences enter the likelihood. That is harmless for optimization but means absolute reward values are not meaningful across prompts. Second, the reward model is typically the language model itself with a scalar head replacing the output layer, so it inherits the base model's understanding.

### Stage 3: policy optimization

Run PPO with the learned reward, and the objective is the KL-regularized one from Chapter 5:

$$
\max_\pi \; \mathbb{E}_{x, y\sim\pi}\big[ r_\phi(x,y) \big] - \beta\,D_{KL}\big(\pi \,\|\, \pi_{\text{ref}}\big)
$$

Implemented as a per-token modification of the reward:

$$
r_t = \underbrace{r_\phi(x,y)\cdot\mathbb{1}[t = T]}_{\text{terminal}} \; - \; \beta\log\frac{\pi_\theta(y_t\mid \cdot)}{\pi_{\text{ref}}(y_t\mid\cdot)}
$$

**Why the KL term is not optional**, and this is the most important thing to be able to explain about RLHF:

1. **The reward model is a learned approximation valid only near its training distribution.** Push the policy far from that distribution and the reward model's outputs become meaningless — it will confidently score nonsense highly, because nothing in its training taught it otherwise.
2. **Without the constraint, the policy will find those errors.** This is reward hacking, and it is not a hypothetical: unconstrained RLHF reliably produces degenerate outputs that score extremely well and are useless. The optimizer is doing its job; the reward is wrong.
3. **It is a trust region in disguise**, the same idea as section 9.5, now measured against the reference model rather than the previous iterate.
4. **It preserves the base model's capabilities**, which pure reward maximization would happily destroy.

This is Goodhart's law with a precise mathematical statement: **optimizing a proxy hard enough breaks its correlation with the target.** The KL budget is how much optimization pressure you can safely apply, and the empirical relationship between KL distance and true quality — rising, then falling — is the shape you should expect.

### The full pipeline

| Stage | Objective | Data |
| --- | --- | --- |
| Pretraining | next-token cross-entropy | web-scale text |
| SFT | next-token cross-entropy | demonstrations |
| Reward modelling | Bradley-Terry logistic loss | comparisons |
| RL | KL-regularized reward maximization | model's own samples |

Four components are live during the RL stage: the policy being trained, a frozen reference copy for the KL, the reward model, and a value model. **That is up to four model copies in memory**, which is a large part of why RLHF is expensive and why the methods in section 9.8 that eliminate some of them are attractive.

### Known difficulties

Worth being able to list, since "what are the problems with RLHF?" is a standard question:

- **Reward hacking**, as above.
- **Length bias.** Human raters and therefore reward models tend to prefer longer responses, so policies get verbose. This is well documented and usually needs an explicit correction.
- **Sycophancy.** Optimizing for rated approval encourages agreeing with the user rather than being correct.
- **Preference data is noisy and inconsistent**, both within and between annotators, so there is a ceiling on reward model quality.
- **Distribution shift during training.** The policy moves away from the reward model's training distribution, so the reward model degrades exactly as it is being relied on more. Iterated collection of fresh comparisons is the standard remedy.
- **Mode collapse and diversity loss.** RLHF-tuned models generate less varied text than their base models — consistent with the mode-seeking behaviour of a KL-regularized objective, and a real cost.

### Variants worth knowing

- **RLAIF / Constitutional AI**: use an AI model, guided by a written set of principles, to generate the preference labels, reducing the human annotation bottleneck.
- **Process supervision**: reward intermediate reasoning steps rather than only the final answer, which gives denser signal and has been found more effective for reasoning tasks than outcome-only rewards.
- **Rule-based and verifiable rewards**: where correctness can be checked programmatically (code that passes tests, math with a known answer), use that instead of a learned model. This removes reward hacking at a stroke and is why RL on verifiable domains has been so productive.

**Try it.** (a) Derive the Bradley-Terry loss from the assumption that preference probability is logistic in the reward difference. (b) Explain precisely why RLHF needs a KL penalty, in terms of the reward model's validity. (c) Why is the reward identified only up to a per-prompt constant, and does it matter? Answers in 9.12.

## 9.8 DPO and its relatives

### The idea

RLHF is three stages, four models in memory, and an RL loop that is notoriously fiddly. DPO asks: **can we skip the reward model and the RL entirely, and optimize preferences directly with a supervised loss?**

The answer is yes, and the derivation is one of the most elegant results in recent ML. It rests entirely on the closed-form optimum from Chapter 5.

### The derivation

**Step 1.** From Chapter 5, section 5.8, the exact optimum of the KL-regularized objective is:

$$
\pi^{*}(y\mid x) = \frac{1}{Z(x)}\,\pi_{\text{ref}}(y\mid x)\,\exp\!\left(\frac{r(x,y)}{\beta}\right)
$$

The reference policy reweighted by the exponentiated reward, with Z(x) the normalizer.

**Step 2, the key move: invert it.** Solve for the reward in terms of the optimal policy:

$$
r(x,y) = \beta\log\frac{\pi^{*}(y\mid x)}{\pi_{\text{ref}}(y\mid x)} + \beta\log Z(x)
$$

**Any reward function corresponds to some optimal policy, and vice versa.** The reward and the policy are two parameterizations of the same object.

**Step 3.** Substitute this into the Bradley-Terry likelihood. Because the preference model depends only on the **difference** of rewards for two responses to the *same* prompt, the intractable log Z(x) term — which depends on x but not y — **cancels exactly**:

$$
\mathcal{L}_{\text{DPO}} = -\mathbb{E}\left[\log\sigma\left( \beta\log\frac{\pi_\theta(y_w\mid x)}{\pi_{\text{ref}}(y_w\mid x)} - \beta\log\frac{\pi_\theta(y_l\mid x)}{\pi_{\text{ref}}(y_l\mid x)} \right)\right]
$$

**That is DPO.** No reward model, no sampling, no RL loop — a supervised loss on preference pairs that you train with ordinary gradient descent.

The cancellation of Z(x) is the crux, and it is worth pausing on: the partition function is exactly the intractable quantity that forces you into RL in the first place, and the Bradley-Terry difference structure removes it for free. That is why the result feels like a trick and is in fact a theorem.

### Reading the loss

Define the **implicit reward** as beta times the log-ratio of the policy to the reference. Then DPO is just logistic regression on implicit rewards. Its gradient is informative:

$$
\nabla_\theta \mathcal{L} \propto -\sigma\big(\hat{r}_l - \hat{r}_w\big)\Big[\nabla\log\pi_\theta(y_w) - \nabla\log\pi_\theta(y_l)\Big]
$$

**Increase the log-probability of the preferred response, decrease that of the rejected one, weighted by how wrong the model currently is.** The weight is large when the model currently prefers the rejected response and small when it already gets it right — an automatic hard-example weighting that falls out of the sigmoid.

### The trade-offs

|  | PPO-based RLHF | DPO |
| --- | --- | --- |
| Models in memory | policy, reference, reward, value | policy, reference |
| Sampling during training | required (expensive) | none |
| Stability | fiddly | supervised-level |
| Uses on-policy data | yes | no — fixed preference dataset |
| Can exceed the data's quality | yes, by exploring | limited to what the pairs express |
| Reward hacking | a live risk | no separate reward to hack |

The honest assessment: **DPO is far simpler and often matches PPO-based RLHF; but it is offline, so it cannot discover behaviours not represented in the preference data.** Online RL can sample new responses, get them evaluated, and improve beyond its dataset — which matters most when a verifiable reward is available. Reported comparisons vary with setup, data quality and tuning, and this remains actively debated; treat claims that one strictly dominates with caution and check the current literature.

Note also that DPO's implicit reward can drift: the loss can be reduced by lowering the probability of the rejected response without raising the preferred one, so both can fall. Variants exist to address this, and monitoring the absolute log-probabilities rather than only the margin is the practical check.

### The wider family

| Method | Distinguishing idea |
| --- | --- |
| **DPO** | the derivation above |
| **IPO** | replaces the logistic loss to avoid over-fitting to deterministic preferences |
| **KTO** | uses individual good/bad labels rather than pairs, drawing on prospect theory |
| **ORPO** | combines SFT and preference optimization in one stage, dropping the reference model |
| **SimPO** | uses length-normalized log-probability as the implicit reward, with no reference model |
| **GRPO** | online, but replaces the value network with a group-relative baseline |

**GRPO deserves detail** because it is the one most relevant to recent reasoning models. The observation is that in the language setting the critic is expensive (another full model) and hard to train (the reward is terminal, so the value head has little signal). Instead: for each prompt, sample a **group** of G responses, score them all, and use the group's statistics as the baseline:

$$
\hat{A}_i = \frac{r_i - \operatorname{mean}(r_1,\ldots,r_G)}{\operatorname{std}(r_1,\ldots,r_G)}
$$

**The baseline is the group mean, which is exactly the simplest control variate from Chapter 3** — and it is valid for the same reason any state-dependent baseline is: it does not depend on the individual action. You drop the value network entirely, cutting memory substantially, and keep the online, on-policy character that DPO gives up. This approach has been central to recent work on RL for reasoning, where rewards are verifiable (a math answer is right or wrong) and therefore not hackable.

The broader point worth carrying: **the recent direction in this area has been toward simpler objectives with fewer moving parts** — dropping the reward model (DPO), dropping the value model (GRPO), dropping the reference model (some variants) — while retaining the KL-regularized structure that makes the whole thing work. Each is a different answer to the question of which components you can remove without losing the constraint that keeps optimization honest.

**Try it.** (a) Derive DPO from the KL-regularized optimum, showing exactly where Z(x) cancels and why. (b) What is the implicit reward in DPO, and what does its gradient weighting do? (c) Why can GRPO drop the value network, and what plays the baseline's role? Answers in 9.12.

## 9.9 Bandits

### The simplest interesting problem

A **multi-armed bandit** is an MDP with one state. You repeatedly choose among K arms, each with an unknown reward distribution, and you want to maximize total reward. There is no credit assignment and no state transition — only the exploration-exploitation trade, in isolation.

That isolation is why bandits matter: **it is the one setting where exploration theory is sharp and gives provably optimal algorithms.** Everything in Chapter 8's exploration section was heuristic; here the answers are theorems.

### Regret

The standard measure is the shortfall against always playing the best arm:

$$
\text{Regret}(T) = T\mu^{*} - \mathbb{E}\left[\sum_{t=1}^{T} r_t\right]
$$

You want **sublinear** regret, meaning the per-step regret tends to zero and you eventually play optimally almost always. A policy with linear regret never learns.

**The Lai-Robbins lower bound** says no algorithm can do better than logarithmic regret:

$$
\text{Regret}(T) = \Omega(\log T)
$$

That is a genuinely strong statement: you *must* pay a logarithmically growing price for not knowing the arms in advance, and algorithms achieving O(log T) are optimal up to constants.

### Why epsilon-greedy is not optimal

With fixed epsilon you explore a constant fraction of the time forever, so regret grows **linearly** — you keep paying for exploration long after you know the answer. Annealing epsilon as 1/t recovers logarithmic regret, but with worse constants than the methods below, and it still explores uniformly at random rather than in proportion to uncertainty.

### UCB

Optimism in the face of uncertainty, made precise:

$$
a_t = \arg\max_a \left[ \hat{\mu}_a + \sqrt{\frac{2\log t}{N_a}} \right]
$$

Play the arm with the highest **plausible** mean, not the highest estimated mean. The bonus is a confidence-interval width: it shrinks as 1/sqrt(N\_a) (Chapter 3's standard error) and grows slowly with t so that arms untried for a long time eventually get revisited.

**Why this works, in one sentence:** if you play an arm because its upper bound is high, then either its true mean is high (you gain reward) or your estimate was too optimistic (you gain information and the bound tightens). Either way the play is not wasted, and that dichotomy is exactly what the regret proof formalizes.

UCB achieves O(log T) regret, matching the lower bound in order. The derivation of the bonus term comes from **Hoeffding's inequality** (Chapter 3): it is the confidence-interval half-width at a confidence level chosen to shrink appropriately with t. Being able to point at Hoeffding as the source of the square root is a good detail.

### Thompson sampling

The Bayesian approach, and often the best-performing in practice:

1. Maintain a posterior over each arm's mean.
2. **Sample** one value from each posterior.
3. Play the arm whose sample is highest.
4. Update that arm's posterior with the observed reward.

For Bernoulli rewards with Beta priors this is trivially implementable, because of Chapter 4's conjugacy: the posterior after s successes and f failures is Beta(a + s, b + f), so the whole algorithm is two counters per arm and one Beta sample.

**Why it explores correctly:** an arm with a wide posterior sometimes produces a high sample and gets played; an arm with a narrow posterior centred low essentially never does. **Exploration is automatic and proportional to uncertainty**, with no bonus term to tune. It also achieves optimal regret, and empirically often beats UCB.

Note that this is a genuinely Bayesian algorithm in an essential way (Chapter 3, section 3.1): its behaviour comes from sampling a posterior, and there is no frequentist restatement that preserves the algorithm.

### Contextual bandits

Add a context x observed before choosing. Now you learn a mapping from contexts to good actions — which is supervised learning with **bandit feedback**: you see the reward only for the arm you chose, never for the others.

This is the model for a great deal of real deployment: recommendation, ad selection, which model variant to route a query to, and in agentic systems which tool to call. **LinUCB** and **Thompson sampling with a linear or neural model** are the standard approaches.

The practically important idea here is **off-policy evaluation**: using logged data from an old policy to estimate a new policy's value, via importance weighting (Chapter 3). The propensity — the probability the logging policy assigned to the action it took — must be recorded at logging time, and forgetting to log it makes unbiased off-policy evaluation impossible afterwards. That is a concrete, consequential engineering point.

### Where this connects to agentic AI

- **Best-of-n sampling** is a bandit problem: generate n candidates, and a verifier or reward model chooses. The exploration-exploitation framing tells you how to think about n.
- **Routing** between models or tools of different cost and quality is a contextual bandit.
- **A/B testing with adaptive allocation** uses exactly these algorithms to shift traffic toward better variants while still gathering evidence.
- **Prompt or strategy selection** under feedback is a bandit, and Thompson sampling is a strong default for it.

**Try it.** (a) Why does fixed-epsilon exploration give linear regret? (b) Where does UCB's square-root bonus come from? Name the inequality. (c) Implement Thompson sampling for three Bernoulli arms with Beta(1,1) priors and describe what happens over the first twenty rounds. Answers in 9.12.

## 9.10 Search and test-time compute

### The idea

Everything so far spends compute at **training** time to produce a policy that acts in one shot. Search spends compute at **inference** time: consider several possible continuations, evaluate them, and pick. A weak policy plus substantial search can outperform a strong policy acting greedily, which is the oldest lesson in game AI and has become central again for reasoning models.

### Monte Carlo tree search

MCTS builds a search tree incrementally, concentrating effort on promising branches. Four phases per simulation:

1. **Selection.** From the root, descend the existing tree by repeatedly choosing children according to a bandit rule.
2. **Expansion.** At a leaf, add one or more children.
3. **Simulation.** Estimate the value of the new node — classically by a random rollout to the end, in modern systems by a learned value network.
4. **Backpropagation.** Propagate the result up the path, updating visit counts and value estimates.

**The selection rule is where the bandit theory enters.** UCT applies UCB to each node:

$$
a = \arg\max_a \left[ \bar{Q}(s,a) + c\sqrt{\frac{\ln N(s)}{N(s,a)}} \right]
$$

Exactly section 9.9's UCB, applied at every internal node. **Tree search is a bandit problem at each node**, and that is the cleanest way to explain why MCTS looks the way it does.

The AlphaZero variant replaces the exploration term with one guided by a learned policy prior:

$$
a = \arg\max_a \left[ Q(s,a) + c\,P(a\mid s)\,\frac{\sqrt{N(s)}}{1 + N(s,a)} \right]
$$

The policy network's prior focuses the search on plausible moves, and the value network replaces random rollouts. The resulting improved action distribution — the visit counts at the root — is then **distilled back into the policy network** as a training target. That loop is the essential idea: **search improves the policy, and the improved policy makes search better.** It is policy iteration (Chapter 8) with search as the improvement operator.

### Why search helps, stated precisely

Search is a **policy improvement operator**. Given any policy and any value estimate, looking ahead and backing up produces a better action distribution than acting on the policy directly, for exactly the reason the policy improvement theorem of Chapter 8 gives. Deeper search yields a stronger improvement operator. And because the improved distribution can be distilled back, training and inference compute become interchangeable to some degree — a point that has shaped a great deal of recent work.

### Test-time compute for language models

The same principle, adapted to a setting with no game tree:

| Method | Mechanism |
| --- | --- |
| **Best-of-n** | sample n responses, pick the highest-scoring under a reward model or verifier |
| **Majority voting / self-consistency** | sample n reasoning chains, take the most common final answer |
| **Beam search over reasoning steps** | maintain several partial solutions, extend and prune by a process reward model |
| **Tree-of-thought** | explicit branching and backtracking over intermediate states |
| **Extended chain-of-thought** | the model spends more tokens reasoning before answering; the search is implicit in the generation |
| **Verifier-guided search** | a learned or programmatic checker scores partial or complete solutions |

The unifying analysis is worth stating: **more samples raise the probability that at least one is correct, and the selection mechanism determines how much of that you capture.** If the per-sample success probability is p, the chance that at least one of n succeeds is 1 - (1-p)^n, which rises quickly. Whether you realize that gain depends entirely on being able to *identify* the correct one — which is why a good verifier is worth more than more samples, and why **verifiable domains (code with tests, math with checkable answers) have seen the largest gains.** Where verification is unreliable, best-of-n degenerates into optimizing the verifier's errors, which is reward hacking again in a different costume.

Majority voting is the special case where the verifier is agreement among samples. It works when errors are diverse and independent-ish, and fails when the model is confidently and consistently wrong — the failure mode is systematic rather than random error, which averaging cannot fix.

### The honest summary

Test-time compute is an active area with rapid movement. The defensible claims: search is a policy improvement operator with a firm theoretical basis; the gains are largest where solutions can be verified; and there is a real trade between training compute and inference compute that can be spent either way. Specific scaling relationships and the best methods are moving quickly, so check current literature rather than relying on a summary.

**Try it.** (a) Explain UCT's selection rule in terms of the bandit theory of section 9.9. (b) With a per-sample success rate of 30%, what is the chance at least one of 10 samples is correct, and what must be true for you to benefit? (c) Why is search a policy improvement operator, and which Chapter 8 theorem justifies that? Answers in 9.12.

## 9.11 Interview drill set

**1. Derive the policy gradient theorem.** Write the objective as an integral over trajectories, differentiate, apply the log-derivative trick to turn the gradient of the density into the density times the gradient of its log, and recognize the result as an expectation. Then factor the trajectory probability: everything not involving theta differentiates away, leaving a sum of policy score terms.

**2. Why does the transition model disappear?** Because log p(tau) is a sum of log dynamics terms and log policy terms, and the dynamics do not depend on theta. That is what makes policy gradients model-free.

**3. What is the surrogate loss in practice?** Negative log-probability of the taken actions weighted by the advantage — weighted cross-entropy on your own actions. The advantage is a detached coefficient; differentiating through it would compute a different objective.

**4. Why is REINFORCE so high-variance?** The return sums over a whole episode so variances add; the score function is unbounded; and the estimator uses only the reward's value, never its derivative, which is the defining weakness of the score-function estimator.

**5. Why does a baseline reduce variance without adding bias?** Unbiased because the expected score is zero, so any state-dependent term multiplied by the score has zero expectation. Variance falls because you weight actions by how much better than average they were, removing the large common component of the return.

**6. Why must the baseline not depend on the action?** The unbiasedness proof needs the baseline to come out of the expectation over actions. If it depends on the action it cannot, and the estimator becomes biased.

**7. What is the advantage function and why is it the ideal weight?** Q minus V. Its expectation under the policy is zero, so it is the maximally variance-reducing state-dependent control variate, and it makes the update about the choice of action rather than about which state you happened to be in.

**8. What is GAE?** An exponentially weighted sum of future TD errors with decay gamma-lambda — TD(lambda) applied to advantages. Lambda trades bias against variance in the advantage estimate; gamma defines the objective. They are different kinds of knob.

**9. What is the TRPO surrogate objective?** The importance-weighted advantage under the old policy's state distribution. It is accurate only when the policies are close, because the importance weights blow up otherwise, which is why a KL constraint accompanies it.

**10. Where does the Fisher information come into TRPO?** The KL constraint expanded to second order is a quadratic form with the Fisher as its matrix. Maximizing a linear objective under a quadratic constraint gives a closed form that is the natural gradient, with step length set by the KL budget.

**11. Explain PPO's clipped objective.** Clip the probability ratio to within 1 plus or minus epsilon and take the minimum of the clipped and unclipped terms. Once the ratio moves too far in the favoured direction the gradient vanishes, so the update cannot over-commit; the min makes it a pessimistic bound, so a policy that has strayed can still be pulled back.

**12. Why can PPO take multiple epochs on one batch?** The importance ratio explicitly corrects for the growing mismatch between the data-collecting policy and the current one, and the clip bounds how far that correction is trusted. Vanilla policy gradient has no such correction and must discard data after one step.

**13. How much of PPO's benefit comes from the clipping?** Less than people assume. Careful studies attribute much of the gain to implementation details: advantage normalization, observation and reward normalization, orthogonal initialization with small policy-head gain, gradient clipping, learning-rate annealing, and correct handling of episode boundaries in GAE.

**14. What do you monitor in a PPO run?** Policy entropy (collapse), empirical KL from the old policy (step size), value-function explained variance (critic quality), and the fraction of samples being clipped (how hard the constraint is binding).

**15. Describe the RLHF pipeline.** Supervised fine-tuning on demonstrations; a reward model fit to pairwise comparisons under a Bradley-Terry likelihood; then KL-regularized policy optimization against that reward, usually with PPO.

**16. Derive the reward-model loss.** Assume the probability of preferring one response is a logistic function of the reward difference. Maximum likelihood then gives negative log sigmoid of the reward difference — binary logistic regression on differences, which is a GLM with the canonical link.

**17. Why does RLHF need the KL penalty?** The reward model is only valid near its training distribution. Without a constraint the policy drifts to where the reward model is wrong and exploits those errors. The KL term is a trust region against the reference model, preserves base capabilities, and bounds how much optimization pressure is applied to a proxy.

**18. What is the exact optimum of the KL-regularized objective?** The reference policy reweighted by the exponentiated reward over beta, normalized. This closed form is the starting point for DPO.

**19. Derive DPO.** Invert the closed-form optimum to express the reward as beta times the log-ratio of optimal to reference policy, plus a log partition term. Substitute into the Bradley-Terry likelihood; since only reward differences for the same prompt appear, the partition term cancels exactly, leaving a supervised logistic loss on policy log-ratios.

**20. What are DPO's limitations?** It is offline, so it cannot discover behaviour absent from the preference data, whereas online RL can sample, evaluate and improve beyond its dataset. Its implicit reward can also drift downward for both responses while the margin improves, so monitor absolute log-probabilities.

**21. What is GRPO and why does it exist?** Online policy optimization that replaces the value network with a group-relative baseline: sample several responses per prompt and standardize their rewards within the group. It drops a whole model from memory and is valid because the group mean does not depend on the individual action — the simplest control variate.

**22. Why is epsilon-greedy suboptimal for bandits?** Fixed epsilon explores a constant fraction forever, giving linear regret. The optimal rate is logarithmic, achieved by UCB and Thompson sampling, which explore in proportion to uncertainty rather than uniformly.

**23. Explain UCB's bonus term.** It is a confidence-interval half-width from Hoeffding's inequality, shrinking as one over the square root of the visit count and growing slowly with time so long-neglected arms are revisited. Playing an optimistic arm either earns reward or tightens its bound.

**24. How does Thompson sampling work and why is it good?** Sample a value from each arm's posterior and play the argmax. Exploration is automatic and proportional to uncertainty, with no bonus to tune. With Beta-Bernoulli conjugacy it is two counters and a sample per arm, and it achieves optimal regret.

**25. What must you log for off-policy evaluation to be possible?** The propensity — the probability the logging policy assigned to the action it chose. Without it you cannot form importance weights, and no amount of later analysis recovers unbiasedness.

**26. How does MCTS relate to bandits?** The selection rule is UCB applied at every internal node: tree search is a bandit problem per node. AlphaZero replaces the exploration term with a policy prior and the rollout with a value network, then distills the improved root distribution back into the policy.

**27. Why does search improve a policy?** Because lookahead followed by backup is a policy improvement operator, justified by the policy improvement theorem: acting greedily with respect to a better value estimate is never worse. Distilling the result back makes it policy iteration with search as the improvement step.

**28. When does test-time compute help most?** When solutions can be verified. More samples raise the chance one is correct, but you only capture that gain if you can identify which. With an unreliable verifier, best-of-n optimizes the verifier's errors, which is reward hacking again.

**29. Why do language-model agents use policy gradients rather than Q-learning?** A pretrained model is already a policy; the action space is the vocabulary and sequences of it, so a max over actions is impractical; rewards are terminal and sparse; and the deadly triad's instability is intolerable at that training cost.

**30. What is the single thread connecting REINFORCE, PPO, RLHF and DPO?** You cannot differentiate through sampling, so you use the score-function estimator; its variance is enormous, so you subtract a baseline; the resulting updates are only trustworthy near the current policy, so you impose a KL trust region. PPO approximates that constraint by clipping, RLHF applies it against a reference model, and DPO solves the constrained problem in closed form and turns it into a supervised loss.

## 9.12 Assignment, solutions, and where to go next

### Solutions to the in-text exercises

**9.1.** (a) Because the trajectory involves discrete action sampling and an unknown environment transition, so there is no differentiable path from theta to the reward: you cannot write the reward as a deterministic differentiable function of theta and parameter-free noise. (b) The model is already a policy over tokens, so fine-tuning continues what it does; and the action space is a vocabulary of tens of thousands with sequence-level structure, making a max over actions and a Q function over state-action pairs impractical. (c) Because the policy determines the distribution of data you will next collect. A bad supervised step is corrected by the next batch, drawn from the same fixed distribution; a bad policy step changes which batches exist, so errors compound through a feedback loop.

**9.2.** (a) See the derivation in the section; the four steps are differentiate the integral, apply the log-derivative identity, recognize the expectation, and factor the trajectory density so the dynamics terms vanish. (b) E over a from pi of \[b(s) times the gradient of log pi(a|s)\] = b(s) times E\[score\] = b(s) times 0 = 0, using the score-function identity from Chapter 4. The baseline can be pulled out of the expectation precisely because it does not depend on a. (c) Because log p(tau) is a sum in which the dynamics and initial-state terms contain no theta and therefore differentiate to zero. It matters because it makes the method entirely model-free: you never need to know or differentiate through the environment.

**9.3.** (a) Without a baseline the weights are all between 1000 and 1010, so every action's log-probability is pushed strongly up and the differences that carry the actual signal are a 1% perturbation on a huge common term. With a baseline of 1005 the weights span -5 to +5 centred on zero: good actions are pushed up and bad ones down, and the common component is gone. The gradient direction is far better conditioned. (b) The failing step is E\[b(s,a) times score\] = b times E\[score\]: this requires b to be constant with respect to the expectation over a. If b depends on a it stays inside the sum, and the result is generally nonzero, so a bias is introduced. (c) Because the bonus resists the self-reinforcing loop in which an early-rewarded action gets more probability, gets sampled more, and dominates before alternatives are tried — a collapse that is self-sealing because the policy generates its own data. In RLHF the KL penalty to the reference model plays this role, additionally anchoring to a sensible prior rather than to uniformity.

**9.4.** (a) A-hat\_t = delta\_t + gamma lambda A-hat\_{t+1}, computed backwards from the end because each advantage depends on all later TD errors; a backward pass computes the whole discounted sum in one linear sweep. (b) gamma defines the objective — how much future reward counts — while lambda controls how much you trust the critic versus the observed rewards in forming the advantage estimate. Changing gamma changes what you are optimizing; changing lambda changes only the estimator's bias-variance balance. (c) Because it is a coefficient, not a function of the policy parameters you are differentiating. Differentiating through it would add a term that does not belong to the policy gradient and would optimize a different objective entirely.

**9.5.** (a) Because the surrogate corrects the action distribution by importance weights pi'/pi, and when the policies differ substantially these weights have huge variance: a few samples dominate, the effective sample size collapses (Chapter 3), and the estimate is unreliable even though it remains unbiased in principle. (b) In the second-order expansion of the KL constraint, which is a quadratic form with the Fisher as its matrix — Chapter 5's result that the Fisher is the Hessian of KL. (c) It guarantees the true objective improves monotonically if you maximize the surrogate minus the KL penalty with the theoretically prescribed constant. It is not used directly because that constant is far too conservative, giving steps so small that training would be impractically slow; the tunable constraint radius abandons the guarantee in exchange for usable step sizes.

**9.6.** (a) With a positive advantage and r = 1.3 > 1.2, the clipped term equals 1.2 times A, which is constant in theta, and it is smaller than the unclipped 1.3 A. The min therefore selects the clipped term, whose gradient with respect to theta is zero. The optimizer receives no signal to push this action's probability higher. (b) Because the clip alone would also flatten the gradient when the ratio has drifted too far in the *harmful* direction, leaving no incentive to come back. The min makes the objective a pessimistic lower bound, which stops further movement in the favoured direction but preserves the pull back when the policy has strayed the wrong way. (c) Policy entropy (detects collapse), empirical KL from the old policy (detects steps that are too large), value-function explained variance (detects a failing critic, which corrupts all advantages), and clip fraction (tells you how hard the constraint is binding — near zero means the clip is inactive, very high means you are taking excessive steps).

**9.7.** (a) If P(prefer y\_w) = sigma(r\_w - r\_l), the log-likelihood of an observed preference is log sigma(r\_w - r\_l), so the negative log-likelihood averaged over the dataset is the stated loss. It is the Bernoulli negative log-likelihood with the reward difference as the logit, hence logistic regression with the canonical link. (b) Because the reward model is fitted on responses from a particular distribution and is only accurate there. Optimization pressure will find inputs where its estimate is high and wrong, since nothing constrains its behaviour off-distribution. The KL penalty bounds how far the policy can move from the region where the reward model's judgements remain meaningful. (c) Because the likelihood depends only on differences of rewards within a prompt, so adding any function of x to all rewards for that prompt leaves the loss unchanged. It does not matter for optimization, since the policy objective also depends on differences, but it means absolute reward values are not comparable across prompts and should not be interpreted as a quality scale.

**9.8.** (a) Substituting r = beta log(pi/pi\_ref) + beta log Z(x) into the difference r(x,y\_w) - r(x,y\_l) gives beta times the difference of the two log-ratios plus beta log Z(x) - beta log Z(x). The partition terms are identical because both responses share the same prompt x, so they cancel exactly. This matters because Z(x) is the intractable normalizer whose presence is what forces you into sampling-based RL. (b) The implicit reward is beta times log(pi\_theta/pi\_ref) for a response. The gradient is weighted by sigma(implicit reward of the rejected minus that of the preferred), which is large when the model currently prefers the rejected response and near zero when it already ranks them correctly — automatic hard-example weighting. (c) Because the baseline only needs to be independent of the individual action taken, not of the state. Averaging the rewards of a group of responses to the same prompt gives a valid state-dependent baseline, so the group mean replaces V(s) and the value network is unnecessary.

**9.9.** (a) Because a fixed fraction epsilon of plays are random forever, so the expected shortfall per step never falls below a constant, and total regret grows linearly in T. (b) Hoeffding's inequality (Chapter 3): the bonus is the confidence-interval half-width for a bounded-mean estimate at a confidence level chosen so the total failure probability is controlled, which produces the square root of log t over N. (c) Beta(1,1) is uniform, so early samples are spread over \[0,1\] and the arms are tried roughly equally. As evidence accumulates, the posteriors of clearly bad arms concentrate low and they are rarely sampled highest, while arms that are good or still uncertain continue to be played. Within twenty rounds you typically see the best arm's play count pulling ahead, with occasional exploratory plays of arms whose posteriors remain wide.

**9.10.** (a) Each internal node faces a bandit problem: choose among children, balancing the estimated value of each against how little it has been tried. UCT applies the UCB rule at each node, with the visit counts playing the role of arm pulls. (b) 1 - 0.7^10 = 1 - 0.028 = 97.2%. To benefit you must be able to *identify* the correct sample; without a reliable verifier you cannot capture the gain, and with an unreliable one you select for its errors. (c) Because lookahead plus backup produces an action distribution at least as good as acting on the current policy, which is the policy improvement theorem of Chapter 8 applied with a better value estimate than the policy's own.

### Problem set

**P1 (policy gradient).** Derive the policy gradient for a Gaussian policy with mean mu(s; theta) and fixed standard deviation sigma. Show that the score is (a - mu)/sigma^2 times the gradient of mu, and interpret what the update does for a positive advantage.

**P2 (baselines).** For a one-state, two-action bandit with rewards 100 and 101, compute the variance of the REINFORCE gradient estimate with and without the mean baseline, and quantify the improvement.

**P3 (GAE).** Given a five-step trajectory with specified rewards and value estimates, compute the advantages for lambda = 0, 0.95 and 1, and comment on the differences.

**P4 (TRPO).** Starting from the KL constraint, derive the natural-gradient step formula including the step-size coefficient, and explain each factor.

**P5 (PPO).** Plot the clipped objective as a function of the ratio r for a positive and a negative advantage, mark where the gradient is zero, and explain the asymmetry created by the min.

**P6 (RLHF).** Derive the gradient of the Bradley-Terry reward-model loss with respect to the reward parameters, and show that it moves the two rewards apart in proportion to how wrong the current ranking is.

**P7 (DPO).** Carry out the full DPO derivation yourself, then verify that at beta approaching infinity the loss becomes uninformative and explain why.

**P8 (bandits).** Simulate three Bernoulli arms with means 0.3, 0.5 and 0.55 for 10,000 rounds. Compare cumulative regret for epsilon-greedy (fixed and annealed), UCB, and Thompson sampling. Plot regret against log T and comment on the slopes.

**P9 (coding).** Implement REINFORCE with a baseline, then A2C, then PPO on CartPole. Report learning curves and sample counts for each, and ablate PPO's implementation details one at a time.

**P10 (synthesis).** Explain in one paragraph why these are all the same idea: the score-function estimator; REINFORCE's baseline; GAE; PPO's clipping; the RLHF KL penalty; and DPO's closed form.

### Selected solutions

**P1.** For a Gaussian policy, log pi(a|s) = -(a - mu)^2/(2 sigma^2) plus a constant, so the gradient with respect to theta is ((a - mu)/sigma^2) times the gradient of mu. The update therefore moves mu **toward** the sampled action when the advantage is positive and **away** from it when negative, with a step proportional to how far the action was from the mean and inversely proportional to the variance. That is a satisfyingly intuitive reading: the policy chases actions that turned out well. Note also the 1/sigma^2 factor, which explains why very small policy variance produces enormous gradients and is a common source of instability in continuous control.

**P2.** Set it up concretely. One state, two actions, a softmax on a single logit theta so that p\_1 = sigma(theta) and p\_2 = 1 - p\_1. The scores are then

$$
\nabla_\theta \log p_1 = 1 - p_1 = p_2, \qquad \nabla_\theta\log p_2 = -p_1
$$

Take theta = 0, so p\_1 = p\_2 = 0.5 and the two scores are +0.5 and -0.5. The single-sample estimator is (reward minus baseline) times the score of the action drawn.

**Without a baseline.** Action 1 is drawn with probability 0.5 and gives 100 x 0.5 = 50; action 2 gives 101 x (-0.5) = -50.5. The mean is -0.25 and the second moment is (50^2 + 50.5^2)/2 = 2525.125, so

$$
\operatorname{Var} = 2525.125 - (-0.25)^2 = 2525.06
$$

**With the mean baseline** b = 100.5. Action 1 gives (100 - 100.5) x 0.5 = -0.25; action 2 gives (101 - 100.5) x (-0.5) = -0.25. **Both outcomes give exactly the same value**, so the estimator is deterministic and its variance is **exactly zero** — while its mean, -0.25, is unchanged and still equals the true gradient.

From variance 2525 to variance 0, by subtracting a constant. The mean is identical in both cases, confirming unbiasedness. This is the extreme case of the control-variate result from Chapter 3: the variance falls by the factor (1 - rho^2), and here the constant baseline is perfectly correlated with the reward's variation across the two actions, so rho = 1 and the reduction is total. Real problems are not this favourable, but the mechanism is the same one, and the direction of the effect never reverses.

**Sanity check on the sign:** the gradient is negative, so theta decreases, so p\_1 decreases and p\_2 increases — the policy shifts toward action 2, which has the higher reward of 101. Correct.

**P6.** Let d = r(y\_w) - r(y\_l). The loss is -log sigma(d), whose derivative with respect to d is -(1 - sigma(d)) = sigma(-d). By the chain rule the gradient with respect to the parameters is sigma(-d) times (gradient of r(y\_l) minus gradient of r(y\_w)), so the update raises the preferred response's reward and lowers the rejected one's, scaled by sigma(-d). When the model already ranks them correctly with a large margin, sigma(-d) is near zero and the update is small; when it has them backwards, sigma(-d) is near 1 and the update is large. This is the same automatic hard-example weighting that appears in DPO, which is no coincidence, since DPO is this loss with the reward re-expressed through the policy.

**P7.** The derivation is in section 9.8. As beta grows, the implicit reward beta log(pi/pi\_ref) is multiplied by a large constant, so the sigmoid saturates and its gradient vanishes for all but the closest pairs — equivalently, a very large beta corresponds to a very tight KL constraint, meaning the optimal policy barely moves from the reference. The loss becomes uninformative because you have told the optimizer it may not change anything. The opposite limit, beta near zero, removes the constraint and the loss pushes the log-ratios apart without bound, which is the DPO analogue of reward hacking.

**P10.** All six are steps along one line of reasoning. **The score-function estimator** exists because you cannot differentiate through a sampling step, so you convert the gradient of an expectation into an expectation of a gradient using the log-derivative identity — at the cost of an estimator that uses only the reward's value, and therefore has very high variance. **The baseline** is the standard remedy, a control variate that is unbiased because the expected score is zero and that removes the large common component of the return, leaving only the part that distinguishes actions. **GAE** is the same variance-reduction pressure applied to the advantage itself, trading a little bias from the critic for a large variance reduction, with lambda as the dial. But reducing variance is not enough, because the estimator is only valid near the policy that generated the data: the importance weights that correct for any mismatch blow up as the policies separate, so the objective becomes untrustworthy exactly where you might be tempted to take a large step. **PPO's clipping** is a cheap per-sample enforcement of that locality, and **RLHF's KL penalty** is the same constraint measured against a reference model rather than the previous iterate, protecting a learned reward that is only valid near its own training distribution. **DPO** closes the loop: it observes that the constrained problem has an exact closed-form solution, inverts it to express reward in terms of policy, and thereby eliminates both the reward model and the sampling — turning the whole pipeline into a supervised loss. One estimator, one variance problem, one trust region, and a sequence of increasingly clever ways to satisfy all three.

### A closing note

That is the whole tutorial. Nine chapters, from vectors to DPO, and the thing worth noticing at the end is how few distinct ideas carried the weight.

A handful of results did most of the work. **The SVD** organized Chapter 1 and reappeared in conditioning, PCA, and low-rank adaptation. **The chain rule as a product of Jacobians** explained backpropagation, vanishing gradients, initialization, normalization and residual connections. **The conditional expectation** gave the Bellman equation, the advantage, and the tower-property arguments throughout RL. **The score-function identity** gave REINFORCE, baselines, and the Fisher information. **KL divergence** gave cross-entropy, the ELBO, natural gradient, TRPO, RLHF and DPO. **Variance reduction** — control variates, in particular — appeared as baselines, as GAE, and as GRPO's group mean.

If you can move fluently between those six and the places they surface, you have what this tutorial was for. The drill sets are the fastest way to find out whether you can: work through them out loud, and where an answer does not come easily, return to the derivation rather than the summary.

Where to go next, depending on your direction: for depth on the classical material, Sutton and Barto for RL and Boyd and Vandenberghe for optimization remain the standard references; for current practice, read the papers behind whatever you are building, since this field's half-life is short and any summary — including this one — dates quickly. Check current literature for anything where this tutorial flagged an area as active or contested, because several of them will have moved.

**P3.** GAE on a five-step trajectory. Take rewards r = (1, 1, 1, 1, 10) with the last step terminal, gamma = 0.99, and value estimates V = (5, 5, 5, 5, 5) with V(terminal) = 0. The TD errors are delta\_t = r\_t + gamma V(s\_{t+1}) - V(s\_t):

delta\_0 = 1 + 4.95 - 5 = 0.95; delta\_1 = 0.95; delta\_2 = 0.95; delta\_3 = 0.95; delta\_4 = 10 + 0 - 5 = 5.

At **lambda = 0**, A\_t = delta\_t, so A = (0.95, 0.95, 0.95, 0.95, 5). The large terminal reward is invisible to the early steps — the critic's flat estimate is trusted completely, and the only step credited with the big payoff is the last one.

At **lambda = 1**, the backward recursion A\_t = delta\_t + gamma A\_{t+1} gives A\_4 = 5, A\_3 = 0.95 + 4.95 = 5.90, A\_2 = 0.95 + 5.84 = 6.79, A\_1 = 7.67, A\_0 = 8.54. **Now every step gets credit for the eventual payoff**, but any error in the sampled rewards propagates back too.

At **lambda = 0.95**, the factor is gamma lambda = 0.9405: A\_4 = 5, A\_3 = 0.95 + 4.70 = 5.65, A\_2 = 0.95 + 5.32 = 6.27, A\_1 = 6.85, A\_0 = 7.39. Between the two, closer to the Monte Carlo end. The comparison makes the trade concrete: **lambda controls how far backwards credit for the terminal reward travels.** When the critic is poor — as here, since a flat value of 5 badly misprices the final state — a high lambda is what rescues the early steps.

**P4.** TRPO's step from the KL constraint. Expand the surrogate to first order and the constraint to second:

$$
\max_{\Delta\theta} \; g^{\top}\Delta\theta \quad \text{subject to} \quad \tfrac{1}{2}\Delta\theta^{\top}F\Delta\theta \le \delta
$$

Form the Lagrangian g'd - (lambda/2)(d'Fd - 2delta) and set the gradient to zero: g = lambda F d, so d = F^{-1}g/lambda. The direction is fixed; lambda sets the length. Substitute into the active constraint (it binds, since the objective is linear and increasing along the direction):

$$
\tfrac{1}{2}\frac{g^{\top}F^{-1}g}{\lambda^2} = \delta \quad\Longrightarrow\quad \lambda = \sqrt{\frac{g^{\top}F^{-1}g}{2\delta}}
$$

Hence the step. Reading the factors: **F^{-1}g** is the natural-gradient direction, invariant to reparameterization; the scalar **sqrt(2 delta / (g'F^{-1}g))** is the largest multiple of that direction whose KL cost stays within budget; and g'F^{-1}g is twice the predicted improvement, so the step is large when the surrogate promises a lot per unit of KL and small when it does not.

**P5.** Plotting the clipped objective against r. For **A > 0**: the unclipped line r A rises with slope A; the clipped version rises identically until r = 1 + eps and is flat thereafter; the min of the two is the rising line up to 1 + eps then flat. Gradient is A below 1 + eps and zero above. For **A < 0**: the unclipped line falls with slope A (negative); the clipped version is flat below r = 1 - eps; the min of the two is now the *unclipped* line below 1 - eps, because with A negative the unclipped term r A is the smaller one there. So the objective keeps falling as r decreases, and the gradient stays active. The asymmetry: for positive A the objective flattens on the **right**, for negative A it flattens on the **left**, and in each case the direction that remains active is the one that pulls the ratio back toward 1.

**P8 (coding).** Three Bernoulli arms at 0.3, 0.5, 0.55 over 10,000 rounds. Expected cumulative regret: **fixed epsilon = 0.1** grows linearly, with slope roughly epsilon times the average gap times (K-1)/K — by 10,000 rounds it is in the hundreds and still climbing at a constant rate. **Annealed epsilon (1/t)** grows logarithmically, but with worse constants than the others. **UCB** grows logarithmically and is competitive. **Thompson sampling** is usually the best, often by a clear margin on this problem, because the two good arms are close together (0.5 versus 0.55) and Thompson's posterior sampling allocates its exploration between them efficiently rather than by a uniform bonus. Plot regret against log T: the sublinear methods appear as roughly straight lines, fixed-epsilon as an exponential curve. **Run at least 100 independent simulations and plot the mean**, because single runs are extremely noisy and can easily reverse the ordering.

**P9 (coding).** REINFORCE, A2C and PPO on CartPole. Expected sample counts to reach a solved policy: REINFORCE with a baseline needs on the order of hundreds of thousands of steps and shows very noisy learning curves; A2C is several times faster and smoother; PPO is faster again and markedly more stable across seeds. The ablations are the instructive part: **removing advantage normalization** produces the largest single degradation, often more than removing clipping; **removing the clip entirely** (plain importance-weighted policy gradient with multiple epochs) causes occasional catastrophic collapses when a batch produces extreme ratios; **increasing epochs per batch from 4 to 30** without early stopping on KL degrades performance, because the data becomes badly off-policy. That first result is the one worth sitting with: it is the empirical basis for the claim in section 9.6 that implementation details carry much of PPO's advantage.
