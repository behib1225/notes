﻿# Chapter 2 · Matrix Calculus and Backpropagation

2026-09-22 · @Behi

Training a neural network is one idea repeated: compute a scalar loss, find its gradient with respect to every parameter, take a step. This chapter is about the middle step, which is where nearly all the notation, all the transpose bugs, and a large share of interview questions live.

The promise by the end: you can differentiate any layer you meet by hand, derive backpropagation from first principles rather than recalling it, explain why reverse mode is the right choice for deep learning, and debug a gradient that is silently wrong.

## 2.1 What a derivative is when the inputs are not scalars

Most confusion in matrix calculus comes from one unasked question: **what shape is the answer supposed to be?** Fix that and the rest is bookkeeping.

### The right definition to carry

Forget difference quotients. The definition that generalizes cleanly is: **the derivative at a point is the best linear approximation to the function near that point.**

$$
f(x + \delta) = f(x) + Df(x)[\delta] + o(\lVert \delta \rVert)
$$

Df(x) is a *linear map* taking a perturbation of the input to the resulting perturbation of the output. Whatever kind of object the input perturbation is, and whatever kind the output perturbation is, the derivative is the linear machine connecting them. Once you ask "what linear map sends a small change in the input to the change in the output?", the shape of the answer is forced.

This is also the practical recipe used throughout this chapter, the **differential method**: perturb, expand, discard second-order terms, and read off the linear map.

### The type table

Memorize this. It resolves most shape questions on sight.

| Input | Output | Derivative object | Shape | Name |
| --- | --- | --- | --- | --- |
| scalar | scalar | scalar | 1 | ordinary derivative |
| vector in R^n | scalar | vector | n | **gradient** |
| scalar | vector in R^m | vector | m | velocity / tangent |
| vector in R^n | vector in R^m | matrix | m x n | **Jacobian** |
| matrix in R^{m x n} | scalar | matrix | m x n | gradient w.r.t. a matrix |
| vector in R^n | scalar, twice | matrix | n x n | **Hessian** |
| matrix | matrix | 4-index tensor | m x n x p x q | rarely written explicitly |

Two observations that save enormous effort:

1. **The gradient has the same shape as the thing you differentiate with respect to.** Always. The gradient of a scalar loss with respect to a 768 x 3072 weight matrix is a 768 x 3072 matrix. This is not a convention you could have chosen differently in practice, because the optimizer does `W = W - lr * grad`, and that requires matching shapes. If your derivation produces a transposed shape, you have made an error, and you have just caught it for free.
2. **You will almost never construct that 4-index tensor.** In deep learning the final output is a scalar loss, so the only objects that ever get materialized are gradients, which have the shape of the parameters. That is the whole reason reverse-mode autodiff exists, and section 2.3 makes it precise.

### Gradient, defined properly

For f from R^n to R, the gradient is the vector of partial derivatives:

$$
\nabla f(x) = \begin{bmatrix} \partial f / \partial x_1 \\ \vdots \\ \partial f / \partial x_n \end{bmatrix}, \qquad f(x + \delta) \approx f(x) + \nabla f(x)^{\top}\delta
$$

The second expression is the one to think with. It says the gradient is the vector whose inner product with a perturbation gives the change in f. From it, three standard facts follow immediately:

- **The gradient points in the direction of steepest ascent.** By Cauchy-Schwarz, the inner product of the gradient with a unit vector is largest when that unit vector is parallel to the gradient. That is the entire proof, and it is a common interview question.
- **Its magnitude is the rate of change in that steepest direction.**
- **The gradient is orthogonal to level sets.** Move along a contour and f does not change, so the inner product of the gradient with that direction is zero.

The directional derivative along a unit vector u is just the projection:

$$
D_u f(x) = \nabla f(x)^{\top} u
$$

A caution worth absorbing early: **the gradient is only "the steepest direction" with respect to the Euclidean norm you implicitly chose.** Under a different metric, the steepest direction is different, which is exactly the observation behind natural gradient methods, mirror descent, and a good part of why Adam behaves differently from SGD. Section 2.8 returns to this.

### Jacobian, defined properly

For f from R^n to R^m, stack the gradients of each output component as rows:

$$
J_{ij} = \frac{\partial f_i}{\partial x_j}, \qquad J \in \mathbb{R}^{m \times n}, \qquad f(x + \delta) \approx f(x) + J\delta
$$

Row i is the gradient of output i. Column j says how all outputs respond to input j. Note that the gradient is the special case m = 1, up to a transpose: the Jacobian is then a 1 x n row vector while we conventionally write the gradient as a column. That single transpose is the source of an astonishing amount of confusion, and section 2.2 pins it down.

Geometrically, the Jacobian is the local linear map: near x, the function stretches, rotates and shears space exactly as J does. Its determinant is the local volume scaling factor, which is the change-of-variables formula in probability (Chapter 3) and the mechanism behind normalizing flows. Its singular values are the local amplification factors in each direction, which is what "exploding gradients" and Lipschitz bounds are about.

### A first example, done the slow way and the fast way

Take f(x) = x'Ax with A symmetric, from R^n to R.

*Index way.* f = sum over i and j of A\_ij x\_i x\_j. Differentiate with respect to x\_k: terms where i = k give sum over j of A\_kj x\_j, terms where j = k give sum over i of A\_ik x\_i, and these are equal by symmetry. So the k-th partial is 2 times (Ax)\_k, hence the gradient is 2Ax.

*Differential way.* Perturb:

$$
f(x + \delta) = (x+\delta)^{\top}A(x+\delta) = x^{\top}Ax + \delta^{\top}Ax + x^{\top}A\delta + \delta^{\top}A\delta
$$

The two middle terms are scalars and transposes of each other, so they are equal; with A symmetric they sum to 2x'A delta. The last term is second order, so discard it. What multiplies delta linearly is (2Ax)', so the gradient is 2Ax.

The second method takes ten seconds, generalizes to matrices where indices become unmanageable, and is what you should use from here on. **Perturb, expand, drop second-order terms, read off the coefficient of the perturbation.** If A is not symmetric the same computation gives (A + A')x, which specializes correctly.

**Try it.** Using the differential method, find the gradient of (a) f(x) = a'x, (b) f(x) = ||x||^2, (c) f(x) = ||Ax - b||^2. Check the shapes against the type table before you check the answers in section 2.11.

## 2.2 Layout conventions, and the rule that makes them harmless

### The problem

For f from R^n to R, is the derivative a column vector of length n or a row vector of length n? Both conventions are in print, both are self-consistent, and formulas differ by transposes between them.

| Convention | Derivative of scalar w.r.t. vector | Jacobian of R^n to R^m | Chain rule reads |
| --- | --- | --- | --- |
| **Denominator layout** (gradient layout) | column, n x 1 | n x m | right to left |
| **Numerator layout** (Jacobian layout) | row, 1 x n | m x n | left to right |

Most ML writing uses a hybrid, and honestly so does this tutorial, because it is the hybrid that everyone actually uses in practice: **gradients are shaped like the variable, and Jacobians are (outputs x inputs).** That is mildly inconsistent as pure notation and completely standard in practice.

### The rule that makes the whole issue go away

You do not need to memorize either convention if you adopt one discipline:

> **Write the shape of every object next to it, then assemble the product so the shapes compose. There is usually exactly one way to do it.**

Example. In a layer h = Wx with W of shape (m x n), x of shape (n,), and a scalar loss L, suppose you know dL/dh, which has shape (m,) because gradients match their variable. You want dL/dW, which must be (m x n). The only way to build an (m x n) object from an (m,) and an (n,) is the outer product:

$$
\frac{\partial L}{\partial W} = \frac{\partial L}{\partial h}\, x^{\top} \qquad (m \times 1)(1 \times n) = (m \times n) \;\checkmark
$$

And dL/dx must be (n,), built from W of shape (m x n) and dL/dh of shape (m,). The only composition that works is

$$
\frac{\partial L}{\partial x} = W^{\top}\frac{\partial L}{\partial h} \qquad (n \times m)(m \times 1) = (n \times 1) \;\checkmark
$$

You have just derived the two backward rules for a linear layer without doing any calculus, purely from shapes. This is not a trick, it is the reliable method, and it is what an interviewer wants to see you do at the whiteboard. **When in doubt, count shapes.**

### Denominator layout, stated once for reference

With gradients shaped like their variable, these hold:

$$
\nabla_x (a^{\top}x) = a, \qquad \nabla_x (x^{\top}Ax) = (A + A^{\top})x, \qquad \nabla_x \lVert x \rVert_2^2 = 2x
$$

And for a composition L = g(f(x)) with f from R^n to R^m:

$$
\nabla_x L = J_f^{\top}\, \nabla_f L, \qquad J_f \in \mathbb{R}^{m \times n}
$$

That transposed Jacobian times an upstream gradient is the **vector-Jacobian product**, and it is the single operation that backpropagation is made of. Section 2.3 explains why that particular form is what you want.

### The Hessian

$$
H_{ij} = \frac{\partial^2 f}{\partial x_i \partial x_j}, \qquad H = \nabla^2 f(x) \in \mathbb{R}^{n \times n}
$$

The Hessian is the Jacobian of the gradient map. It is symmetric whenever the second partials are continuous, which is **Clairaut's or Schwarz's theorem**, and that symmetry is why everything in section 1.6 and 1.7 applies to it: real eigenvalues, orthonormal eigenbasis, definiteness classifying critical points.

Second-order Taylor expansion, which you will use constantly in Chapter 6:

$$
f(x + \delta) \approx f(x) + \nabla f(x)^{\top}\delta + \tfrac{1}{2}\delta^{\top}H\delta
$$

For a network with even 10^9 parameters the Hessian has 10^18 entries and cannot be stored, let alone inverted. Everything practical in second-order optimization is about accessing the Hessian without forming it, which section 2.8 covers.

### Quick reference: shapes in a transformer block

Annotating shapes is a habit, so here is a worked instance you can check yourself against. Let B be batch, T sequence length, d model dimension, h heads, d\_k = d/h.

| Object | Shape |
| --- | --- |
| input X | B x T x d |
| W\_Q, W\_K, W\_V | d x d |
| Q, K, V after projection and head split | B x h x T x d\_k |
| attention logits QK' | B x h x T x T |
| attention weights after softmax | B x h x T x T |
| attention output (weights times V) | B x h x T x d\_k |
| after merging heads and W\_O | B x T x d |
| gradient w.r.t. W\_Q | d x d, same as W\_Q |

The last row is the point: no matter how many batch and head dimensions the forward pass carries, **the gradient of a scalar loss with respect to a parameter has exactly the parameter's shape.** Batch dimensions get summed over, because the loss sums over the batch. If you ever see a parameter gradient with a leftover batch dimension, you forgot a sum.

**Try it.** A layer computes y = xW with x of shape (B x n) and W of shape (n x m), a batched layout. Given dL/dy of shape (B x m), use only shape-counting to determine dL/dW and dL/dx. Which one involves a sum over the batch, and why? Answers in 2.11.

## 2.3 The chain rule, forward mode, and why reverse mode wins

### The chain rule is matrix multiplication

If z = g(y) and y = f(x), then the derivative of the composition is the product of the derivatives:

$$
J_{g \circ f}(x) = J_g(f(x)) \, J_f(x)
$$

That is the entire theorem, and it is obvious once you hold the "derivative is the best linear approximation" definition from 2.1: composing two functions locally composes their linear approximations, and composing linear maps is multiplying matrices.

For a deep network with L layers, the loss is a composition of L functions, so the Jacobian of the whole thing is a product of L Jacobians:

$$
\frac{\partial L}{\partial x} = J_L \, J_{L-1} \cdots J_2 \, J_1
$$

**Everything about deep learning optimization follows from this product.** Gradients explode if the Jacobians typically stretch, vanish if they typically shrink, and behave if their singular values sit near 1. Residual connections work partly because they make each Jacobian I plus something small, and a product of such matrices stays near the identity instead of decaying geometrically. That is one of the most useful sentences in this tutorial, and it is worth pausing on.

### Association is everything

Matrix multiplication is associative, so you may evaluate that product in any order, and the orders differ enormously in cost. Consider Jacobians of shapes (1 x 1000), (1000 x 1000) and (1000 x 1000) for a three-stage composition ending in a scalar loss.

- **Right to left** (start from the input): (1000 x 1000) times (1000 x 1000) is a matrix-matrix product costing about 10^9 operations, and you do it twice.
- **Left to right** (start from the loss): (1 x 1000) times (1000 x 1000) is a vector-matrix product costing about 10^6 operations, and you do it twice.

Same answer, a thousandfold difference. **Forward mode is right-to-left; reverse mode is left-to-right.** That single observation is the whole reason backpropagation exists.

### Forward and reverse, precisely

**Forward mode** propagates a *directional derivative* forward alongside the function. You pick an input direction v and carry the Jacobian-vector product

$$
\text{JVP: } \; J v \qquad \text{(how the outputs move when the input moves along } v\text{)}
$$

Each forward-mode pass gives you one *column* of the Jacobian, that is, the effect of perturbing one input direction. Cost is roughly one function evaluation per pass. To get a full Jacobian you need n passes, one per input dimension.

**Reverse mode** propagates a *sensitivity* backward. You pick an output direction u (for a scalar loss, u = 1) and carry the vector-Jacobian product

$$
\text{VJP: } \; u^{\top} J \qquad \text{(which inputs the chosen output is sensitive to)}
$$

Each reverse pass gives you one *row* of the Jacobian. To get a full Jacobian you need m passes, one per output dimension.

|  | Forward mode | Reverse mode |
| --- | --- | --- |
| Primitive | JVP, J times v | VJP, u transpose times J |
| Yields | one column of J per pass | one row of J per pass |
| Passes for full Jacobian | n (input dimension) | m (output dimension) |
| Memory | O(1) extra; no tape | must store intermediate activations |
| Best when | few inputs, many outputs | **few outputs, many inputs** |
| Used for | JVPs, some sensitivity analysis, forward-over-reverse tricks | **training every neural network** |

Deep learning has one scalar output (the loss) and up to trillions of inputs (the parameters). That is the maximally reverse-favorable case: **one** reverse pass gives the gradient with respect to **all** parameters. If you can explain that asymmetry crisply, you have answered one of the most common ML-engineering interview questions.

### The cost of backprop, stated exactly

The **cheap gradient principle** (Baur-Strassen) says: computing the gradient of a scalar function costs no more than a small constant times the cost of evaluating the function, independent of the number of inputs. In practice the backward pass costs roughly twice the forward pass, so training a step costs about three forward passes' worth of compute. That rule of thumb, forward : backward : total of about 1 : 2 : 3, is worth having memorized because it underlies every training-cost estimate you will be asked to make.

The price is memory. Reverse mode must remember the intermediate activations from the forward pass to use them in the backward pass, so activation memory grows with depth and batch size. That trade is what motivates **gradient checkpointing**: store only some activations, recompute the rest during the backward pass, buying roughly a square-root reduction in memory for about one extra forward pass of compute. Section 2.7 goes further.

### Why VJPs are the right abstraction

A modern autodiff framework does not store Jacobians. For each primitive operation it stores a *function* that applies the transposed Jacobian to a vector. You never materialize a (1000 x 1000) Jacobian for a linear layer; you store the rule "given g, return W transpose times g". This is why autodiff has the same asymptotic cost as the forward pass, and why adding a custom operation to a framework means supplying its VJP, not its Jacobian.

This also explains an initially puzzling API detail: `backward()` on a non-scalar tensor requires you to supply a vector. You are choosing the u in u-transpose-J. For a scalar loss the framework fills in u = 1 for you, which is why `loss.backward()` needs no argument.

### A tiny worked example

Let L = (w x - y)^2 as a chain: a = wx, b = a - y, L = b^2.

Forward: a = wx, b = a - y, L = b squared. Backward, starting from dL/dL = 1:

$$
\frac{\partial L}{\partial b} = 2b, \qquad \frac{\partial L}{\partial a} = \frac{\partial L}{\partial b}\cdot 1 = 2b, \qquad \frac{\partial L}{\partial w} = \frac{\partial L}{\partial a}\cdot x = 2bx = 2(wx-y)x
$$

Notice the pattern that generalizes to every network: each node takes the gradient handed to it from above, multiplies by its **local** derivative, and passes the result down. No node needs global knowledge. That locality is the reason backprop can be implemented once per operation and composed automatically, forever.

**Try it.** (a) You have a function from R^1000 to R^1000 and want the full Jacobian. Which mode, and how many passes? (b) You want only the trace of that Jacobian; can you do better? (c) Why does `loss.backward()` need no argument but `y.backward()` on a vector y does? Answers in 2.11.

## 2.4 The identity toolbox

These are the derivatives you should be able to write without hesitation. Do not memorize them as a list; memorize the *method* from section 2.1 and re-derive any you forget. The derivations here are short on purpose so you can check yourself.

### Scalar output, vector input

| Function | Gradient | Derivation |
| --- | --- | --- |
| a'x | a | perturb: a'(x+d) - a'x = a'd, so the coefficient of d is a' |
| x'x = |  | x |
| x'Ax | (A + A')x, or 2Ax for symmetric A | section 2.1 |
|  |  | Ax - b |
| log(sum of exp(x\_i)) | softmax(x) | see below, it is worth doing |
| x'y w.r.t. x | y | linear in x |

**The log-sum-exp gradient**, because it is the backbone of every classifier. Let S = log sum\_j exp(x\_j). Then

$$
\frac{\partial S}{\partial x_i} = \frac{e^{x_i}}{\sum_j e^{x_j}} = \operatorname{softmax}(x)_i
$$

So **softmax is the gradient of log-sum-exp**, which is a genuinely useful thing to know: it tells you log-sum-exp is convex (its Hessian is the softmax Jacobian, which is PSD), it explains why log-sum-exp is the "soft maximum", and it is why the cross-entropy gradient comes out so clean in 2.5.

### Scalar output, matrix input

These are the workhorses. Remember the shape rule: the answer has the shape of the matrix you differentiate by.

| Function of X | Gradient w.r.t. X | Note |
| --- | --- | --- |
| trace(AX) | A' |  |
| trace(X'A) | A |  |
| trace(X'AX) | (A + A')X |  |
| a'Xb | ab' | an outer product, check the shape |
|  |  | X |
| log det(X) | X^{-T} | for invertible X; X^{-1} if symmetric |
| trace(X^{-1}A) | -X^{-T}A'X^{-T} | via the inverse differential below |

**The two differentials to remember**, from which several of the above follow:

$$
d(X^{-1}) = -X^{-1}(dX)X^{-1}, \qquad d(\log\det X) = \operatorname{trace}(X^{-1} dX)
$$

The first comes from differentiating X X^{-1} = I with the product rule: (dX)X^{-1} + X d(X^{-1}) = 0, then solve. It is the matrix version of the fact that the derivative of 1/x is -1/x^2, and the two X^{-1} factors sandwich dX because matrices do not commute. The second is the reason log-determinants appear all over Gaussian likelihoods and normalizing flows.

**The trace trick**, which converts any scalar into a trace so you can cycle factors:

$$
\operatorname{trace}(ABC) = \operatorname{trace}(BCA) = \operatorname{trace}(CAB), \qquad x^{\top}Ax = \operatorname{trace}(Axx^{\top})
$$

The standard recipe for a matrix gradient: write the differential dL, use the trace trick to massage it into the form trace(G' dX), and then G is the gradient. This is mechanical and it always works, which is why it is worth practicing until it is boring.

### Elementwise functions

For y = f(x) applied elementwise, the Jacobian is diagonal, so the VJP is an elementwise multiply:

$$
J = \operatorname{diag}(f'(x_1), \ldots, f'(x_n)), \qquad \frac{\partial L}{\partial x} = \frac{\partial L}{\partial y} \odot f'(x)
$$

That circle-dot is the Hadamard (elementwise) product. **Never materialize a diagonal Jacobian**; it is the single most common beginner inefficiency.

| Activation | f(x) | f'(x) | Notes |
| --- | --- | --- | --- |
| sigmoid | 1/(1 + e^{-x}) | s(x)(1 - s(x)) | max slope 0.25, so gradients shrink; saturates both ends |
| tanh | tanh x | 1 - tanh^2 x | zero-centered, max slope 1, still saturates |
| ReLU | max(0, x) | 1 if x > 0 else 0 | no saturation for positive x; dead units for negative |
| Leaky ReLU | x if x>0 else ax | 1 or a | fixes dead units |
| GELU | x \* Phi(x) | Phi(x) + x\*phi(x) | smooth, standard in transformers |
| softplus | log(1 + e^x) | sigmoid(x) | smooth ReLU; a nice identity to know |

The sigmoid derivative identity s' = s(1 - s) is worth deriving once: write s = (1 + e^{-x})^{-1}, differentiate to get e^{-x}/(1+e^{-x})^2, then note e^{-x}/(1+e^{-x}) = 1 - s. It is asked in interviews because it takes thirty seconds and shows whether you can manipulate rather than recall. Its maximum value of 0.25 at x = 0 is the quantitative reason deep sigmoid networks suffered vanishing gradients: multiply numbers at most 0.25 across many layers and you get nothing.

### Softmax Jacobian

For p = softmax(z), the Jacobian is

$$
\frac{\partial p_i}{\partial z_j} = p_i(\delta_{ij} - p_j), \qquad J = \operatorname{diag}(p) - pp^{\top}
$$

*Derivation.* p\_i = e^{z\_i} / S with S the sum of exponentials. For i = j, the quotient rule gives (e^{z\_i} S - e^{z\_i} e^{z\_i})/S^2 = p\_i - p\_i^2. For i not equal to j, only the denominator depends on z\_j, giving -e^{z\_i}e^{z\_j}/S^2 = -p\_i p\_j. Combine.

Read the result: it is a **covariance matrix** of the indicator random variable that picks class i with probability p, so it is symmetric and PSD, and it is singular (the all-ones vector is in its null space) because softmax is invariant to adding a constant to all logits. That invariance is exactly why you may subtract the max for numerical stability without changing anything.

In practice you never build this matrix. The VJP is

$$
J^{\top}g = p \odot g - p\,(p^{\top}g)
$$

which costs O(n) rather than O(n^2), and this is what frameworks implement.

### Broadcasting and sums

Two rules that resolve most remaining shape puzzles:

- **Summing in the forward pass means broadcasting in the backward pass.** If y = sum of x over some axis, then dL/dx is dL/dy broadcast back along that axis.
- **Broadcasting in the forward pass means summing in the backward pass.** If a bias vector b is added to every row of a batch, then dL/db is the sum of dL/dy over the batch dimension.

These are duals of each other, and they are the reason a bias gradient is a sum over the batch while a weight gradient is a sum of outer products over the batch.

**Try it.** Derive, using differentials: (a) the gradient of trace(X'AX) with respect to X; (b) the gradient of log det(Sigma) with respect to Sigma for symmetric positive definite Sigma; (c) the gradient of -0.5 \* x' Sigma^{-1} x with respect to x, and then with respect to Sigma. The last one is the Gaussian log-density and you will need it in Chapter 3. Answers in 2.11.

## 2.5 Worked derivations for real layers

These five are the ones interviewers actually ask for, roughly in order of frequency. Work each one on paper before reading.

### Linear layer

Forward, batched: Y = XW + b, with X of shape (B x n), W of shape (n x m), b of shape (m,), Y of shape (B x m). Given G = dL/dY of shape (B x m):

$$
\frac{\partial L}{\partial W} = X^{\top}G \;\;(n \times m), \qquad \frac{\partial L}{\partial X} = G W^{\top} \;\;(B \times n), \qquad \frac{\partial L}{\partial b} = \sum_{i=1}^{B} G_{i,:} \;\;(m,)
$$

Every one of these is forced by shape-counting alone (section 2.2). The bias gradient sums over the batch because b was broadcast over the batch in the forward pass. Notice the elegant symmetry: **the forward pass multiplies by W, the backward pass multiplies by W transpose.** A linear layer's backward pass is another linear layer with the transposed weights, which is why the backward pass costs about the same as the forward pass.

### Mean squared error

$$
L = \frac{1}{B}\sum_{i=1}^{B} (\hat{y}_i - y_i)^2 \quad \Longrightarrow \quad \frac{\partial L}{\partial \hat{y}_i} = \frac{2}{B}(\hat{y}_i - y_i)
$$

The gradient is proportional to the error itself. Large errors produce large gradients, which is intuitive but also the source of MSE's sensitivity to outliers: one badly mislabeled example with error 100 contributes a hundred times the gradient of an example with error 1. Huber loss exists to cap this, behaving like MSE for small residuals and like MAE beyond a threshold, so its gradient saturates.

### Softmax with cross-entropy: the beautiful one

This derivation is worth knowing cold, because the result is startlingly simple and interviewers use it to check whether you have actually done the algebra.

Setup: logits z in R^K, probabilities p = softmax(z), true label a one-hot vector y, and

$$
L = -\sum_{k=1}^{K} y_k \log p_k = -\log p_c \quad \text{where } c \text{ is the true class}
$$

*Derivation.* Write L = -z\_c + log sum\_j exp(z\_j), using log p\_c = z\_c - logsumexp(z). Now differentiate with respect to z\_i. The first term contributes -1 when i = c and 0 otherwise, that is, -y\_i. The second term contributes softmax(z)\_i = p\_i, by the log-sum-exp gradient from 2.4. So

$$
\boxed{\;\frac{\partial L}{\partial z} = p - y\;}
$$

**The gradient is the predicted distribution minus the true distribution.** Nothing else. Three things follow, all of which are good things to say out loud:

1. **It is why you must pass logits, not probabilities, to a cross-entropy function.** Fusing softmax and cross-entropy lets the library compute p - y directly, skipping the softmax Jacobian entirely, and lets it use the log-sum-exp trick. Applying softmax yourself and then a log-loss is both slower and numerically worse.
2. **There is no vanishing-gradient problem at the output layer**, unlike sigmoid with squared error, where the sigmoid derivative factor s(1-s) multiplies in and kills the gradient exactly when the model is confidently wrong. This pairing of loss and output nonlinearity is not a coincidence; it is what happens whenever you use the canonical link function of an exponential family (Chapter 4).
3. **The gradient is bounded**, with each component in \[-1, 1\], which is part of why classification training is more stable than regression on unbounded targets.

The same result holds for binary cross-entropy with a sigmoid: dL/dz = sigmoid(z) - y.

### LayerNorm

Forward, over a feature vector x in R^d:

$$
\mu = \frac{1}{d}\sum_i x_i, \qquad \sigma^2 = \frac{1}{d}\sum_i (x_i - \mu)^2, \qquad \hat{x} = \frac{x - \mu}{\sqrt{\sigma^2 + \epsilon}}, \qquad y = \gamma \odot \hat{x} + \beta
$$

The subtlety, and the reason this is an interview favorite: **mu and sigma depend on every x\_i**, so the Jacobian is not diagonal. Every output depends on every input. Naive elementwise differentiation is wrong.

The parameter gradients are easy, summing over whatever batch and sequence dimensions exist:

$$
\frac{\partial L}{\partial \gamma} = \sum \frac{\partial L}{\partial y} \odot \hat{x}, \qquad \frac{\partial L}{\partial \beta} = \sum \frac{\partial L}{\partial y}
$$

For the input, let g = dL/dx-hat = dL/dy times gamma, and let s = sqrt(sigma^2 + eps). Then

$$
\frac{\partial L}{\partial x} = \frac{1}{s}\left( g - \underbrace{\overline{g}}_{\text{mean of } g} - \hat{x}\,\underbrace{\overline{(g \odot \hat{x})}}_{\text{mean of } g \odot \hat{x}} \right)
$$

where the overbars denote means over the d features. Read it geometrically, which is the point of the formula: the incoming gradient gets its mean removed, and its component along x-hat removed, then is rescaled by 1/s. **LayerNorm's backward pass projects the gradient orthogonally to the directions that normalization made irrelevant.** Shifting all inputs by a constant does not change the output, so the gradient cannot have a component along the all-ones direction; scaling all inputs does not change the output either, so it cannot have a component along x-hat. The two subtractions enforce exactly those two invariances.

That also explains a practical fact: normalization layers make the loss surface invariant to the scale of the preceding weights, so weight decay interacts with them in non-obvious ways, and the effective learning rate on pre-norm weights depends on their norm.

### Attention

Forward, for one head:

$$
S = \frac{QK^{\top}}{\sqrt{d_k}}, \qquad A = \operatorname{softmax}(S) \text{ row-wise}, \qquad O = AV
$$

Backward, given dL/dO:

$$
\frac{\partial L}{\partial V} = A^{\top}\frac{\partial L}{\partial O}, \qquad \frac{\partial L}{\partial A} = \frac{\partial L}{\partial O}V^{\top}
$$

Push dL/dA through the row-wise softmax using the VJP from 2.4, applied per row, to get dL/dS. Then, since S is a scaled product:

$$
\frac{\partial L}{\partial Q} = \frac{1}{\sqrt{d_k}}\frac{\partial L}{\partial S}K, \qquad \frac{\partial L}{\partial K} = \frac{1}{\sqrt{d_k}}\left(\frac{\partial L}{\partial S}\right)^{\top}Q
$$

Every step is either a linear layer rule or the softmax VJP. Nothing new is required, which is the real lesson: **complicated architectures have no complicated derivatives, only compositions of simple ones.**

**Why divide by the square root of d\_k.** If the entries of q and k are independent with mean 0 and variance 1, then their inner product over d\_k terms has mean 0 and variance d\_k, so a typical logit is of size sqrt(d\_k). Without scaling, logits grow with head dimension, softmax saturates, and its Jacobian diag(p) - pp' goes to zero because p becomes nearly one-hot. Gradients then vanish. Dividing by sqrt(d\_k) restores unit-scale logits regardless of d\_k. This is one of the most frequently asked transformer questions, and the correct answer is a variance calculation, not a vague appeal to stability.

**Try it.** (a) Show that adding a constant c to every logit leaves softmax and hence the cross-entropy gradient unchanged. (b) Verify by summation that the components of p - y sum to zero, and explain what that means. (c) In the LayerNorm backward formula, confirm that the gradient sums to zero across features and has zero inner product with x-hat. Answers in 2.11.

## 2.6 Backpropagation, derived from scratch

Backpropagation is not an algorithm you should memorize. It is the chain rule applied to a computational graph, evaluated in the order that costs least. If you can derive it, you can debug it, extend it, and answer any question about it.

### Setup

An L-layer MLP, one example at a time for clarity (batching just adds a leading index and a sum):

$$
a^{(0)} = x, \qquad z^{(l)} = W^{(l)}a^{(l-1)} + b^{(l)}, \qquad a^{(l)} = \sigma(z^{(l)}), \qquad L = \ell(a^{(L)}, y)
$$

Each W is (n\_l x n\_{l-1}). Define the **error signal** at layer l, the quantity that makes everything else fall out:

$$
\delta^{(l)} = \frac{\partial L}{\partial z^{(l)}} \in \mathbb{R}^{n_l}
$$

This is the sensitivity of the loss to the pre-activations at layer l. The entire derivation is: find delta at the top, find a recursion for delta going down, and read parameter gradients off delta.

### The four equations

**1. The output layer.** Differentiate the loss with respect to z at the top, through the activation:

$$
\delta^{(L)} = \nabla_{a^{(L)}}\ell \;\odot\; \sigma'(z^{(L)})
$$

For the softmax-with-cross-entropy pairing this collapses to delta = p - y with no elementwise factor at all, because the softmax Jacobian and the cross-entropy gradient cancel (section 2.5). That cancellation is why the pairing is standard.

**2. The recursion.** This is the one to understand rather than memorize:

$$
\delta^{(l)} = \left( W^{(l+1)\top}\delta^{(l+1)} \right) \odot \sigma'(z^{(l)})
$$

*Why.* The pre-activation z at layer l affects the loss only through a at layer l, which affects z at layer l+1, which affects the loss. So apply the chain rule in two steps: pass the upstream error back through the linear map (transposed Jacobian, hence W transpose) and then through the elementwise activation (a Hadamard multiply by the local derivative). Two operations, one per forward operation, in reverse order.

**3 and 4. The parameter gradients.**

$$
\frac{\partial L}{\partial W^{(l)}} = \delta^{(l)} \, a^{(l-1)\top}, \qquad \frac{\partial L}{\partial b^{(l)}} = \delta^{(l)}
$$

The weight gradient is an outer product of the error at this layer with the activation coming in. Shape check: (n\_l x 1)(1 x n\_{l-1}) = (n\_l x n\_{l-1}), matching W. And note what it says: **a weight's gradient is large when the incoming activation is large and the outgoing error is large.** A weight receiving near-zero input barely learns, which is a large part of why input scaling and normalization matter so much.

### The algorithm in full

1. **Forward pass.** Compute and *store* every z and a. The storage is the memory cost of training.
2. **Initialize** delta at the output layer from the loss.
3. **Backward pass.** For l from L down to 1: record the gradients for W and b using delta and the stored activation, then propagate delta down through W transpose and the activation derivative.
4. **Update.** Apply the optimizer step to every parameter.

Batched, every formula gains a sum over examples: the weight gradient becomes a matrix product (a sum of outer products, exactly as in section 1.1) and the bias gradient becomes a column sum.

### What the equations tell you about training

This is the part that pays off in interviews and in practice.

- **Vanishing and exploding gradients.** Unrolling the recursion, delta at layer 1 is a product of L terms of the form W transpose times a diagonal of activation derivatives. If the typical singular value of those terms is below 1, the product decays geometrically in depth; above 1, it explodes. With sigmoid, the derivative is at most 0.25, so a 10-layer sigmoid network attenuates by up to 0.25^10, about 10^-6. That is the quantitative version of "deep sigmoid nets do not train", and it is why ReLU (derivative exactly 1 on the active side) plus careful initialization changed what was trainable.
- **Why residual connections help.** With a = f(z) + z, the local Jacobian is J + I. A product of terms near the identity does not decay, so gradients reach early layers essentially intact. The often-repeated "gradient highway" phrase is exactly this algebra.
- **Dead ReLUs.** If z is negative for every input in the data, the derivative is 0, delta is 0, the weight gradient is 0, and the unit never recovers. Leaky ReLU and GELU exist to keep a nonzero derivative everywhere.
- **Why you cannot initialize all weights to zero.** If every weight in a layer is identical, then every unit receives the same input, produces the same activation, and receives the same delta, so all units get identical gradients and remain identical forever. The layer has the expressive power of a single unit. Random initialization exists to break this symmetry, and this is one of the most common interview questions in the whole subject.
- **Where the memory goes.** You must keep every a for the backward pass, so activation memory scales as batch size times total activation width times depth. This, not parameter count, is usually what makes a large model fail to fit in memory during training, and it is why the memory cost of training is several times the memory cost of inference.

### Backprop is not the brain, and other clarifications

Two things worth having straight, because they come up. Backprop requires a symmetric backward pass using the transposed forward weights, which has no clean biological analogue, and it requires storing activations; this is the "weight transport problem" and is why biologically plausible alternatives (feedback alignment, predictive coding, target propagation) are studied. Separately, backprop computes gradients exactly, up to floating point; it is not an approximation. Any inaccuracy in your training comes from the stochastic gradient estimate (sampling a minibatch), not from backprop itself.

**Try it.** (a) Write out the four equations for a 2-layer network with ReLU hidden and softmax output, batched, with all shapes annotated. (b) Suppose layer 3's activations are all exactly zero. What do the gradients for layers 1 and 2 become, and why? (c) Explain in three sentences why backprop costs roughly the same as the forward pass. Answers in 2.11.

## 2.7 How automatic differentiation actually works

Students often assume frameworks do symbolic differentiation or numerical differences. They do neither, and knowing the difference is a standard interview question.

### Four ways to get a derivative

| Method | What it does | Problem |
| --- | --- | --- |
| Manual | you derive and code it | error-prone, does not scale |
| Numerical (finite differences) | (f(x+h) - f(x))/h | O(n) function evaluations, and a truncation-versus-rounding tradeoff that limits accuracy to about the square root of machine epsilon |
| Symbolic | algebraic manipulation, as in a computer algebra system | expression swell: derivatives of deep compositions blow up in size, and shared subexpressions get recomputed |
| **Automatic (autodiff)** | apply the chain rule numerically to a graph of primitives | needs a VJP per primitive; memory for the tape |

Autodiff is **exact** (to floating point) like symbolic differentiation, and **cheap** (one pass) like nothing else. It is neither symbolic nor numerical, and calling it "numerical differentiation" in an interview is a red flag. The key insight is that you do not differentiate the *expression*, you differentiate the *program*: every program is a composition of primitives, each of which has a known derivative rule.

### The computational graph

Every operation creates a node recording what op it was, what its inputs were, and what it produced. A forward pass builds a DAG; a backward pass walks it in reverse topological order, applying each node's VJP and accumulating gradients into each input.

**Accumulation matters.** If a tensor feeds into several downstream operations, its gradient is the *sum* of the contributions from each path. This is the multivariable chain rule: total derivative = sum over paths. It is why gradients accumulate rather than overwrite, and why you must zero gradients between steps in frameworks that accumulate by default. It is also exactly what makes gradient accumulation across microbatches work: summing gradients from several small batches is identical to one large batch, up to how you normalize.

### Define-by-run versus define-and-run

- **Define-by-run (eager, dynamic):** the graph is built as the code executes, so control flow, loops and recursion are handled naturally and the debugger works. PyTorch's default, and JAX's eager path.
- **Define-and-run (static, compiled):** the graph is built once, then optimized (fusing kernels, eliminating dead code, planning memory) and executed many times. Faster, but data-dependent control flow needs special handling. This is `torch.compile`, `jax.jit`, and XLA.

Tracing-based compilation has a consequence worth knowing: a traced function bakes in the concrete control-flow path taken during tracing, so a Python `if` on tensor values becomes a fixed branch. Frameworks provide structured primitives (`jax.lax.cond`, `torch.cond`) precisely to express data-dependent branching in a traceable way.

### Memory and checkpointing, quantitatively

Activation memory for a plain transformer scales roughly as

$$
\text{activations} \;\sim\; O(\text{batch} \times \text{layers} \times \text{sequence} \times \text{width})
$$

**Gradient checkpointing** (also called activation recomputation) stores activations only at selected boundaries and recomputes the rest during the backward pass. With checkpoints every sqrt(L) layers, memory drops from O(L) to O(sqrt L) at the cost of roughly one extra forward pass, so about 1.3x the compute. This is standard practice in large-model training and a frequent systems interview topic.

Other memory facts that follow directly from the mechanics:

- Inference needs no activation storage, which is why the same model trains at a far smaller batch size than it serves.
- `torch.no_grad()` or equivalent stops graph construction entirely, which is why evaluation loops should use it.
- Mixed precision keeps activations in bf16 or fp16 (halving activation memory) while keeping a master copy of the weights and the optimizer state in fp32, because accumulating tiny updates in low precision loses them to rounding. With fp16 you also need loss scaling, multiplying the loss by a large constant so small gradients do not underflow to zero, then unscaling before the optimizer step. With bf16 loss scaling is usually unnecessary, because bf16 has the same exponent range as fp32.

### Higher-order derivatives

Since autodiff differentiates programs, and the backward pass is itself a program, you can differentiate it again. Composing modes gives different costs:

- **Reverse-over-reverse** gives Hessian-vector products but keeps a second tape.
- **Forward-over-reverse** is the efficient standard for Hessian-vector products: take a JVP of the gradient function. Cost is a small constant times one gradient evaluation, and it never materializes the Hessian.

This is what makes second-order methods, influence functions, meta-learning (MAML), and gradient penalties computationally feasible. Section 2.8 uses it.

### Custom gradients, and why you would want one

You supply a custom VJP when: the automatic one is numerically unstable (the classic example being a `log(1 + exp(x))` written naively), when a closed form is far cheaper than differentiating through an iterative solver, or when you deliberately want a *different* gradient than the true one, as in straight-through estimators (section 2.9). The **implicit function theorem** is the tool for the second case: if your forward pass solves g(z, theta) = 0 for z, you can get dz/dtheta from derivatives of g at the solution without differentiating through the solver's iterations. That is the basis of deep equilibrium models and differentiable optimization layers.

**Try it.** (a) Why is finite differencing accurate to only about 10^-8 in double precision, even though machine epsilon is 10^-16? (b) A tensor is used in three places in the forward pass. How many gradient contributions does it receive, and what is done with them? (c) Estimate the activation memory saving from checkpointing every 4th layer of a 32-layer model, and the compute cost. Answers in 2.11.

## 2.8 Second-order information without building a Hessian

You will never store the Hessian of a real model. You can still use it, and the tricks for doing so come up in research interviews and in any conversation about optimizer design.

### Hessian-vector products, the central trick

The key identity is that a Hessian times a vector is the gradient of a directional derivative:

$$
Hv = \nabla_x \left( \nabla f(x)^{\top} v \right)
$$

Because v is held constant, the inner expression is a scalar function of x, and you can differentiate it with one more backward pass. So **an HVP costs about two gradient evaluations and stores nothing quadratic.** This is the Pearlmutter trick, and it is what makes conjugate gradient, truncated Newton, Hessian-free optimization, influence functions, and curvature diagnostics feasible at scale. In JAX it is `jvp` of `grad`; in PyTorch it is a `grad` call with `create_graph=True` followed by another.

With HVPs you can do a surprising amount without the matrix: solve H d = -g approximately by conjugate gradient (each iteration needs only one HVP), estimate the top eigenvalue by power iteration, or estimate the whole spectrum by stochastic Lanczos quadrature. Estimating the trace uses **Hutchinson's estimator**:

$$
\operatorname{trace}(H) = \mathbb{E}_{v}\left[ v^{\top} H v \right] \quad \text{for } v \text{ with mean 0 and identity covariance}
$$

Random probes (Rademacher vectors are the usual choice) give an unbiased trace estimate from a handful of HVPs.

### Newton's method, and why nobody uses it directly

$$
x_{t+1} = x_t - H^{-1}\nabla f(x_t)
$$

The motivation: minimize the second-order Taylor model exactly instead of taking a fixed step along the gradient. The payoff is quadratic convergence near a minimum and complete invariance to how you scale or linearly reparameterize your variables, which is exactly the problem that plagues gradient descent (section 1.10). The obstacles in deep learning:

1. **Cost.** Storing H is O(n^2) and inverting it O(n^3), for n in the billions.
2. **Indefiniteness.** Away from a minimum, H has negative eigenvalues, and Newton's step then moves *toward* a saddle rather than away, because it solves for a stationary point, not a minimum.
3. **Stochasticity.** Minibatch curvature estimates are noisy, and inverting a noisy matrix amplifies the noise in exactly the small-eigenvalue directions you care about.

Hence the practical family: quasi-Newton methods (L-BFGS builds a low-rank inverse-Hessian approximation from gradient differences, and works well in full-batch settings but poorly with minibatch noise), trust regions and damping (add lambda I to make the model reliable within a radius), and diagonal preconditioners (Adam, RMSProp: cheap, per-coordinate, and ignoring all correlations).

### Gauss-Newton and Fisher, the practical curvature matrices

For a loss of the form L = sum of l(f(x; theta)), split the Hessian using the chain rule:

$$
H = \underbrace{J_f^{\top} \, (\nabla^2 \ell) \, J_f}_{\text{Gauss-Newton}} \;+\; \underbrace{\sum_k (\nabla_f \ell)_k \, \nabla^2 f_k}_{\text{dropped}}
$$

The **Gauss-Newton** matrix is the first term. It is always PSD when the loss is convex in the model output, which every standard loss is, so it gives a well-posed quadratic model even where the true Hessian is indefinite. The dropped term is small near a good fit, because it is weighted by the residuals. This is why Gauss-Newton is a better practical curvature proxy than the Hessian itself.

The **Fisher information matrix** is

$$
F = \mathbb{E}_{x, y \sim p_\theta}\left[ \nabla_\theta \log p_\theta(y|x) \, \nabla_\theta \log p_\theta(y|x)^{\top} \right]
$$

For losses that are negative log-likelihoods with the canonical link, **the Fisher and the Gauss-Newton matrix coincide**. This is a genuinely useful fact and a favorite of research interviews.

Natural gradient descent preconditions by the Fisher:

$$
\theta_{t+1} = \theta_t - \eta \, F^{-1}\nabla_\theta L
$$

The interpretation is worth stating carefully. Ordinary gradient descent takes the steepest step in *parameter* space under the Euclidean norm, which is an arbitrary choice: reparameterize the model and the trajectory changes. Natural gradient takes the steepest step in *distribution* space, measured by KL divergence, which does not depend on the parameterization. That invariance is the entire point, and the connection between the Fisher and the local curvature of KL is proved in Chapter 5.

This is also where trust-region policy methods come from. TRPO constrains the KL between successive policies, which to second order is a quadratic form in the Fisher, so it is natural gradient with a step size chosen by a KL budget. PPO replaces that machinery with a clipped surrogate objective that approximates the same constraint far more cheaply. Chapter 9 develops both.

Practical approximations, since F is also too big: **K-FAC** approximates it as a Kronecker product of two much smaller factors per layer, exploiting the fact that a layer's gradient is an outer product of an input activation and an output error (section 2.6), so its second moment factorizes approximately. Adam's diagonal is the crudest member of the same family: it uses only the diagonal of the empirical second moment of gradients, which is why it is cheap and why it cannot fix correlated directions.

### What the Hessian spectrum of a neural network looks like

Empirically, the Hessian spectrum of a trained deep network has a large bulk concentrated near zero and a small number of large outlier eigenvalues, often roughly as many as there are classes. The practical readings: most directions are nearly flat, so minima are better described as wide basins than isolated points; a few directions are very sharp and dominate the stable learning rate; and the ratio of the two is why learning-rate tuning matters so much. The relationship between the sharpness of a minimum and how well it generalizes is an active research area rather than a settled fact, so state it as a hypothesis rather than a law.

**Try it.** (a) Write the two-line recipe for computing an HVP with autodiff, and state its cost relative to a gradient. (b) Explain why Gauss-Newton is PSD but the Hessian need not be. (c) Why is natural gradient invariant to reparameterization while ordinary gradient descent is not? Answers in 2.11.

## 2.9 Gotchas, edge cases, and how to check a gradient

### Non-differentiable points

ReLU is not differentiable at zero. Neither is the absolute value, max pooling at a tie, or the L1 norm. In practice this is a non-issue for three reasons, and being able to give all three is a good sign of maturity:

1. Hitting exactly zero has probability zero in floating point.
2. Frameworks pick a **subgradient**, conventionally 0 for ReLU at 0, which is a valid choice from the subdifferential \[0, 1\].
3. **Subgradient descent** has a genuine convergence theory for convex problems, so this is a principled fallback rather than a hack.

A subgradient of a convex f at x is any g with f(y) >= f(x) + g'(y - x) for all y; at a kink there is a set of them, and any element works. Max pooling routes the gradient entirely to the argmax, and ties are broken arbitrarily.

### Stop-gradient, and where it is load-bearing

`detach()` or `stop_gradient` says: treat this tensor as a constant during backprop. It is not a hack; several methods are *defined* by it.

- **Target networks in DQN.** The TD target r + gamma max Q(s', a') is detached. If you did not detach it, you would be differentiating through the target, which changes the objective into something that chases a moving goal and is known to be unstable. The clean framing: Q-learning is a fixed-point iteration, not gradient descent on a loss, and the detach is what enforces the fixed-point semantics.
- **VAEs and the reparameterization trick.** You sample z = mu + sigma \* epsilon with epsilon detached, which is what allows the gradient to flow into mu and sigma at all.
- **Self-supervised methods** such as BYOL and SimSiam depend on a stop-gradient on one branch to prevent representational collapse.
- **Policy gradients.** The advantage estimate is detached; it is a coefficient, not a function of the policy parameters you are differentiating.

If an interviewer asks why a detach is there, the answer is always: because the objective you intend is not the objective you would get by differentiating everything.

### The straight-through estimator

For a genuinely non-differentiable operation like `round`, `argmax`, or vector quantization, the forward pass uses the hard operation and the backward pass pretends it was the identity:

$$
y = x + \operatorname{stopgrad}(\text{hard}(x) - x)
$$

Forward, y equals hard(x) exactly. Backward, dy/dx = 1. This is a **biased** gradient estimator, and it is used anyway because it works well enough in practice; VQ-VAE and quantization-aware training both rely on it. Gumbel-softmax is the related continuous-relaxation approach, where the bias is controlled by a temperature you can anneal.

### Common bugs, and the symptom each produces

| Bug | Symptom |
| --- | --- |
| forgot to zero gradients | loss decreases then diverges; effective learning rate grows every step |
| applied softmax then used a loss expecting logits | NaNs, or a suspiciously slow-learning classifier |
| in-place operation on a tensor needed for backward | a runtime error about a version counter, or worse, a silently wrong gradient |
| used `.item()` or `.numpy()` mid-graph | gradient is None; the graph was severed |
| detached where you did not mean to | some parameters never update |
| learning rate too high for the sharpest Hessian direction | loss oscillates or becomes NaN within a few steps |
| missing sum over the batch for a bias | shape error, or silent broadcasting that trains badly |

**The diagnostic habit:** print the norm of each parameter's gradient after the first backward pass. Zeros mean a severed graph or a dead unit; NaNs mean an overflow, usually in an exponential or a division; enormous values mean an initialization or learning-rate problem. This single check catches most of the table above in under a minute.

### Numerical gradient checking

When you write a custom layer, verify it. Use the **central difference**, not the forward difference:

$$
\frac{\partial f}{\partial x_i} \approx \frac{f(x + h e_i) - f(x - h e_i)}{2h}
$$

Central differences have error O(h^2) rather than O(h), so with h around 10^-5 in float64 you can expect agreement to roughly 10^-7 or better. Compare with the **relative** error, since absolute error is meaningless at different scales:

$$
\text{rel err} = \frac{|g_{\text{analytic}} - g_{\text{numeric}}|}{\max(|g_{\text{analytic}}|, |g_{\text{numeric}}|, \varepsilon)}
$$

Rules of thumb: below 10^-7 is fine, around 10^-4 is suspicious unless there are kinks, and above 10^-2 means a bug. Check in double precision, not float32, or you will be measuring rounding noise. Avoid checking at points near a kink (ReLU at zero) because the two sides genuinely disagree there and the test will fail for a legitimate reason. Frameworks provide this: `torch.autograd.gradcheck` and `jax.test_util.check_grads`.

### Why your finite-difference check cannot be more accurate than about 10^-8

Worth understanding rather than memorizing. Truncation error falls as h shrinks, but cancellation error grows as h shrinks, because you are subtracting two nearly equal numbers and dividing by a tiny one. The optimum for a forward difference is near the square root of machine epsilon, about 10^-8 in double precision; for a central difference it is near the cube root, about 10^-5, with error around 10^-11. This is a concrete instance of the catastrophic cancellation discussed in section 1.10, and it is the reason autodiff is preferred rather than merely convenient.

**Try it.** (a) You add a `.detach()` to the target in a regression loss by accident. What happens to training? (b) Write the straight-through estimator for rounding to the nearest integer and confirm the forward and backward behavior. (c) Your gradient check gives a relative error of 0.3 for one coordinate and 10^-9 for all others. What is the most likely explanation? Answers in 2.11.

## 2.10 Interview drill set

Same protocol as Chapter 1: cover the answers, sixty seconds each, say it out loud.

**1. What shape is the gradient of a scalar loss with respect to a weight matrix?** The shape of the weight matrix. Always. The optimizer subtracts it from the weights, so it could not be otherwise.

**2. Derive the gradient of the linear layer.** For Y = XW, dL/dW = X' G and dL/dX = G W', with G = dL/dY. Both are forced by shape-counting: those are the only compositions that produce the right dimensions.

**3. Why is reverse-mode autodiff used for neural networks rather than forward mode?** The chain rule is a product of Jacobians and matrix products are associative, so the evaluation order is free. With one scalar output and many inputs, evaluating left to right keeps every intermediate a vector rather than a matrix, so a single pass gives all parameter gradients. Forward mode would need one pass per parameter.

**4. What is a VJP and why is it the right primitive?** A vector-Jacobian product, u transpose times J, computed without ever forming J. It is the primitive because each backward step only ever needs the Jacobian applied to the upstream gradient, and storing a rule is far cheaper than storing a matrix.

**5. Derive the gradient of softmax with cross-entropy.** Write the loss as -z\_c + logsumexp(z). The first term gives -y, the second gives softmax(z) = p, since softmax is the gradient of logsumexp. So dL/dz = p - y.

**6. Why pass logits rather than probabilities to a cross-entropy loss?** The fused implementation computes p - y directly, skipping the softmax Jacobian, and applies the log-sum-exp trick so nothing overflows. Doing softmax then log yourself is slower and numerically fragile.

**7. What is the Jacobian of softmax?** diag(p) - pp'. It is symmetric PSD, and singular because the all-ones direction is in its null space, which is the algebraic statement of softmax's shift invariance.

**8. Why does attention divide by the square root of d\_k?** With unit-variance entries, a dot product over d\_k terms has variance d\_k, so logits scale as sqrt(d\_k). Unscaled, softmax saturates as head dimension grows, its Jacobian goes to zero, and gradients vanish. Dividing restores unit-scale logits.

**9. Why can you not initialize all weights to zero?** All units in a layer would compute identical activations and receive identical gradients, so they stay identical forever and the layer has the capacity of one unit. Random initialization breaks the symmetry.

**10. Explain vanishing gradients in terms of the chain rule.** The gradient at an early layer is a product of many Jacobians. If their typical singular values are below 1, the product decays geometrically with depth. Sigmoid's derivative peaks at 0.25, so ten layers attenuate by up to 10^-6.

**11. How do residual connections help, mathematically?** The local Jacobian becomes I + J instead of J, so the product across layers stays near the identity rather than shrinking geometrically. The gradient reaches early layers roughly intact.

**12. What does gradient checkpointing trade?** Memory for compute. Store activations at selected boundaries and recompute the rest during the backward pass. With checkpoints every sqrt(L) layers, memory goes from O(L) to O(sqrt L) for roughly one extra forward pass.

**13. Roughly how does the cost of a backward pass compare with a forward pass?** About twice, so a training step is about three forward passes' worth of compute. This follows from the cheap-gradient principle: gradient cost is a constant multiple of function cost regardless of parameter count.

**14. What is a Hessian-vector product and how do you compute it cheaply?** Hv is the gradient of the scalar (gradient dotted with v), holding v fixed. Two backward passes, no quadratic storage. It underlies conjugate gradient, power iteration on curvature, and influence functions.

**15. Why is Newton's method impractical for deep learning?** O(n^2) storage and O(n^3) inversion at billions of parameters, an indefinite Hessian away from minima so the step can move toward saddles, and noisy minibatch curvature that inversion amplifies.

**16. What is the difference between Gauss-Newton and the Hessian?** Gauss-Newton is J' (Hessian of the loss w.r.t. outputs) J, dropping the term weighted by residuals. It is always PSD for a convex loss, so it gives a well-posed quadratic model even where the true Hessian is indefinite.

**17. What is the natural gradient and why is it "natural"?** The gradient preconditioned by the inverse Fisher. It is the steepest direction in distribution space under KL rather than in parameter space under the Euclidean norm, so it is invariant to reparameterization. Ordinary gradient descent is not.

**18. Why do gradients accumulate rather than overwrite?** Because the multivariable chain rule sums over paths: a tensor used in several places receives a contribution from each. This is also why gradient accumulation across microbatches is equivalent to a larger batch.

**19. ReLU is not differentiable at zero. Why is that fine?** The event has probability zero in floating point, frameworks use a valid subgradient (conventionally 0), and subgradient descent has a real convergence theory for convex problems.

**20. What is a straight-through estimator and when would you use one?** Forward uses the hard non-differentiable operation, backward pretends it was the identity. Biased, but it lets you train through rounding, argmax or quantization; used in VQ-VAE and quantization-aware training.

**21. Why do we detach the TD target in Q-learning?** Because Q-learning is a fixed-point iteration, not gradient descent on a loss. Differentiating through the target changes the objective and destabilizes training.

**22. How do you check a custom gradient?** Central finite differences in double precision with h around 10^-5, compared by relative error. Below 10^-7 is fine, above 10^-2 is a bug. Avoid points near kinks.

**23. What is the gradient of log det(X)?** X inverse transpose, or X inverse for symmetric X. It appears in every Gaussian log-likelihood and in normalizing flows.

**24. LayerNorm's Jacobian is not diagonal. Why, and what does its backward pass do?** Because the mean and variance depend on every feature, so every output depends on every input. The backward pass removes the gradient's mean and its component along the normalized activation, then rescales, enforcing the shift and scale invariances of the forward pass.

**25. Given a mysteriously untrained parameter, how do you debug it?** Check its gradient after one backward pass. None means the graph was severed, by a detach, an `.item()`, a numpy conversion or a no-grad context. Exactly zero means a dead unit, a zero incoming activation, or a masked path. NaN means an overflow upstream, usually in an exponential or a division.

## 2.11 Assignment and solutions

### Solutions to the in-text exercises

**2.1.** (a) a'(x + d) - a'x = a'd, so the gradient is a. (b) 2x. (c) Let r = Ax - b. Then ||A(x+d) - b||^2 = ||r + Ad||^2 = ||r||^2 + 2r'Ad + O(d^2), so the coefficient of d is 2(A'r)' and the gradient is 2A'(Ax - b). Shapes: A' is (n x m), r is (m,), product is (n,), matching x. Correct.

**2.2.** dL/dW must be (n x m), built from x of shape (B x n) and dL/dy of shape (B x m); the only working composition is x' times dL/dy, which contracts over the batch index, so **the weight gradient sums over the batch**. dL/dx must be (B x n), built from dL/dy of shape (B x m) and W of shape (n x m), giving dL/dy times W'. The batch index survives here because each example has its own input gradient, whereas the weight is shared across the batch and therefore accumulates contributions from all of it.

**2.3.** (a) Either mode needs 1000 passes; they cost the same here, which is exactly the case where the asymmetry disappears. (b) Yes, dramatically: use Hutchinson's estimator with a handful of JVPs or VJPs against random probes, giving an unbiased trace estimate without the full Jacobian. (c) Because backward computes u transpose times J, and u must be specified. For a scalar output the only sensible u is 1, so the framework supplies it; for a vector output you are asking for a particular linear combination of rows and must say which.

**2.4.** (a) d\[trace(X'AX)\] = trace(dX' AX) + trace(X'A dX) = trace((AX)' dX) + trace((A'X)' dX), so the gradient is (A + A')X. (b) From d log det Sigma = trace(Sigma^{-1} dSigma), the gradient is Sigma^{-1} (transposed, but Sigma is symmetric). (c) For the first, d\[-0.5 x'Sigma^{-1}x\] = -Sigma^{-1}x dx, so the gradient with respect to x is -Sigma^{-1}x. For the second, use d(Sigma^{-1}) = -Sigma^{-1}(dSigma)Sigma^{-1}, giving 0.5 Sigma^{-1}xx'Sigma^{-1}. Combined with (b), the gradient of the Gaussian log-likelihood with respect to Sigma is 0.5(Sigma^{-1}xx'Sigma^{-1} - Sigma^{-1}), which vanishes when Sigma = xx', the one-sample maximum likelihood estimate. That is a satisfying check.

**2.5.** (a) Adding c multiplies every exponential by e^c, which cancels between numerator and denominator, so p is unchanged and hence so is p - y. (b) The components of p sum to 1 and those of y sum to 1, so the difference sums to 0. It means the gradient lies in the subspace orthogonal to the all-ones direction, which is the softmax shift-invariance expressed on the gradient side: there is no gradient signal along the direction that does not change the prediction. (c) Summing the bracket over features: the mean of g minus the mean of g minus (mean of x-hat) times (mean of g times x-hat), and the mean of x-hat is zero, so the total is zero. For the inner product with x-hat, use that the mean of x-hat squared is 1 by construction, and the cross terms cancel identically.

**2.6.** (a) With z1 = W1 x + b1, a1 = ReLU(z1), z2 = W2 a1 + b2, p = softmax(z2): delta2 = p - y of shape (B x K); dL/dW2 = a1' delta2 of shape (h x K); dL/db2 = column sum of delta2; delta1 = (delta2 W2') times the indicator that z1 > 0, of shape (B x h); dL/dW1 = x' delta1; dL/db1 = column sum of delta1. (b) All zero. The weight gradient at layer 3 is an outer product with the incoming activation, and the delta propagated below is scaled by whatever the layer produced; with zero activations the layers below receive no signal. This is the dead-unit failure mode at scale. (c) The backward pass does one transposed-matrix multiply and one elementwise multiply per forward operation, and a transposed matrix multiply costs the same as the original. So the cost is a small constant times the forward pass, independent of parameter count.

**2.7.** (a) Because the error has two competing parts: truncation error of order h, and cancellation error of order eps/h from subtracting nearly equal numbers. Their sum is minimized near h = sqrt(eps), giving total error around sqrt(eps), about 10^-8. (b) Three contributions, summed, because the total derivative is the sum over paths. (c) Checkpointing every 4th layer of 32 stores 8 checkpoints instead of 32 layers of activations, roughly a 4x reduction in stored activations, at the cost of recomputing at most 3 layers per segment during the backward pass, roughly one extra forward pass overall, so about 1.3x total compute.

**2.8.** (a) `hvp(f, x, v) = jvp(grad(f), x, v)`, or in PyTorch, compute `g = grad(f, x, create_graph=True)` then `grad(g @ v, x)`. Cost is about two gradient evaluations. (b) Gauss-Newton is J' (Hessian of loss w.r.t. outputs) J, a congruence of a PSD matrix, and by Chapter 1's result C'AC is PSD when A is; the true Hessian additionally contains a term weighted by the residual gradients times the model's own second derivatives, which carries no sign constraint. (c) Because the Fisher is the metric induced by KL on the distribution the model represents, and KL between two distributions does not depend on how you parameterized them. Euclidean distance in parameter space does: rescale a parameter and gradient descent behaves differently even though the model family is the same.

**2.9.** (a) Nothing changes. The target is data and has no gradient path anyway; the detach is a no-op. This is worth knowing so you do not chase a phantom bug. (b) `y = x + stopgrad(round(x) - x)`. Forward, x cancels and y = round(x). Backward, the stopgrad term contributes nothing, so dy/dx = 1. (c) That coordinate is almost certainly at or near a kink, for example a ReLU whose pre-activation is very close to zero. Perturbing by h crosses the kink, so the finite difference averages two different one-sided derivatives. Re-run the check at a different random point.

### Problem set

**P1 (differentials).** Using the differential method, find the gradient with respect to x of: (a) ||x||\_2, not squared, being careful at the origin; (b) log(1 + exp(a'x)); (c) sigmoid(a'x), expressed in terms of the output.

**P2 (matrix gradient).** Find the gradient with respect to W of L = ||XW - Y||\_F^2, with X of shape (n x d), W of shape (d x k), Y of shape (n x k). Verify shapes. Then set the gradient to zero and recover the multi-output normal equations.

**P3 (backprop by hand).** For a 2-layer network with a single hidden unit, tanh activation, scalar output and squared loss, write out every partial derivative symbolically and compute them numerically at x = 1, w1 = 0.5, b1 = 0, w2 = 2, b2 = -1, y = 1.

**P4 (softmax).** Prove that the softmax Jacobian diag(p) - pp' is PSD, and find its null space. Then show that the largest eigenvalue is at most 1/2 and interpret what that implies about gradient magnitudes when the model is confident.

**P5 (LayerNorm invariances).** Show directly from the forward formula that LayerNorm's output is unchanged if you replace x by ax + c for any a > 0 and any scalar c. Then explain why that forces the input gradient to be orthogonal to both the all-ones vector and to x-hat.

**P6 (attention scaling).** Let q and k be independent with i.i.d. entries of mean 0 and variance 1 in R^{d\_k}. Compute the mean and variance of q'k. Then argue quantitatively what happens to the softmax Jacobian as d\_k grows without the 1/sqrt(d\_k) scaling.

**P7 (HVP).** Let f(x) = 0.5 x'Ax with A symmetric. Verify by hand that the identity Hv = grad(grad f dotted with v) gives Av. Then explain why the trick needs the second differentiation to treat v as a constant.

**P8 (implementation).** Implement a two-layer MLP forward and backward pass in numpy with no autodiff. Verify every gradient against central finite differences in float64 to a relative error below 10^-7. Then train it on a small synthetic classification problem and confirm the loss decreases.

**P9 (debugging).** You train a network and the loss is exactly constant from step one. List five distinct causes, and for each give the single check that would confirm or eliminate it.

**P10 (synthesis).** Explain in one paragraph why the following are all the same idea: the chain rule is a product of Jacobians; deep sigmoid networks do not train; residual connections help; and orthogonal initialization is a reasonable thing to try.

### Selected solutions

**P1.** (a) d||x|| = (x'dx)/||x||, so the gradient is x/||x||, the unit vector in the direction of x. It is undefined at the origin, where the norm has a cone point; the subdifferential there is the whole closed unit ball. (b) By the chain rule, sigmoid(a'x) times a. (c) If s = sigmoid(a'x), the gradient is s(1 - s)a, using the sigmoid derivative identity.

**P2.** Write R = XW - Y. Then L = trace(R'R) and dL = 2 trace(R' X dW), so the gradient is 2X'(XW - Y), of shape (d x k), matching W. Setting it to zero gives X'XW = X'Y, the normal equations with multiple right-hand sides: each output column is fit independently, which is why multi-output linear regression is just k separate regressions sharing one factorization of X'X.

**P4.** For any v, v'(diag(p) - pp')v = sum of p\_i v\_i^2 minus (sum of p\_i v\_i)^2, which is E\[V^2\] - (E\[V\])^2 = Var(V) for the random variable V taking value v\_i with probability p\_i. Variance is nonnegative, so the matrix is PSD. It is zero exactly when V is constant, that is when v is a multiple of the all-ones vector (restricted to coordinates with p\_i > 0), so that is the null space. For the bound: the largest eigenvalue is at most the largest variance achievable by a unit vector; taking v as a difference of two basis vectors and optimizing gives a maximum of 1/2, attained when two classes each have probability 1/2. The implication is that a confident model (p near one-hot) has a near-zero softmax Jacobian, so if the confidence is *wrong*, gradients through the softmax are tiny. This is exactly the problem that the fused softmax-with-cross-entropy avoids, since the p - y form never multiplies by this Jacobian at all.

**P6.** q'k is a sum of d\_k independent products, each with mean 0 (independence) and variance 1 (since the variance of a product of independent mean-zero unit-variance variables is 1). So the mean is 0 and the variance is d\_k, giving a typical magnitude of sqrt(d\_k). With d\_k = 64, logits of size 8 are typical; with d\_k = 128, about 11. Since softmax over logits separated by more than roughly 10 is numerically one-hot, its Jacobian diag(p) - pp' goes to zero, and by P4 that means the gradient through the attention weights vanishes. Dividing by sqrt(d\_k) makes the logit variance 1 independent of head dimension, which is the entire point.

**P9.** Five causes and their checks: (i) learning rate is zero or the optimizer never steps, check the optimizer's parameter groups and whether `step()` is called; (ii) the graph is severed so all gradients are None, check gradient norms after one backward; (iii) parameters were not passed to the optimizer, compare the optimizer's parameter list against the model's; (iv) the output is detached from the parameters, for example the loss is computed on a numpy copy, check that the loss tensor has a grad function; (v) all activations are dead (for example every ReLU is off due to a bad initialization or an enormous negative bias), check the fraction of positive pre-activations per layer.

**P10.** Sketch: the gradient at an early layer is a product of per-layer Jacobians, so the *typical singular value* of those Jacobians raised to the depth decides whether any signal reaches the bottom. With sigmoid activations the local derivative is at most 0.25, so the product decays geometrically and deep sigmoid networks receive essentially no gradient at their early layers. Residual connections change each local Jacobian from J to I + J, and a product of matrices near the identity neither decays nor explodes, so the gradient survives arbitrary depth. Orthogonal initialization is the same thought applied to the weights themselves: orthogonal matrices have all singular values exactly 1, so they neither amplify nor attenuate, making the product well behaved at initialization. All four statements are one statement about the singular values of a long matrix product.

**P3.** Forward: z1 = w1 x + b1 = 0.5(1) + 0 = 0.5; a1 = tanh(0.5) = 0.4621; z2 = w2 a1 + b2 = 2(0.4621) - 1 = -0.0758; L = (z2 - y)^2 = (-0.0758 - 1)^2 = 1.1580.

Backward: dL/dz2 = 2(z2 - y) = 2(-1.0758) = -2.1516. Then dL/dw2 = dL/dz2 times a1 = -2.1516(0.4621) = -0.9943; dL/db2 = -2.1516. Propagating down: dL/da1 = dL/dz2 times w2 = -4.3032; dL/dz1 = dL/da1 times (1 - tanh^2(0.5)) = -4.3032(1 - 0.2135) = -3.3845; dL/dw1 = dL/dz1 times x = -3.3845; dL/db1 = -3.3845.

Sanity checks worth doing: all gradients are negative, meaning every parameter should increase, which is right because the prediction -0.076 is far below the target 1. And the tanh derivative factor 0.7865 attenuates the signal reaching the lower layer — one layer costs 21% of the gradient here, which is the vanishing-gradient mechanism visible in miniature.

**P5.** Let s = sqrt(sigma^2 + eps) and write the forward pass as x-hat = (x - mu)/s. Now replace x by ax + c with a > 0. The new mean is a mu + c, so the numerator becomes a(x - mu); the new variance is a^2 sigma^2, so the new denominator is a s. The ratio is a(x - mu)/(a s) = (x - mu)/s, exactly unchanged.

Why that forces orthogonality of the gradient: if a function is invariant along a direction, its directional derivative along that direction is zero. Shift invariance is movement along the all-ones vector, so the gradient must have zero inner product with it — equivalently, its components sum to zero. Scale invariance is movement along x itself (equivalently along x-hat after normalization), so the gradient must have zero inner product with x-hat. Those are exactly the two subtractions in the backward formula: removing the mean enforces the first, removing the x-hat component enforces the second. **The backward pass is a projection onto the subspace orthogonal to the invariances.**

**P7.** f(x) = 0.5 x'Ax has gradient Ax. So grad f dotted with v is x'Av, a scalar function of x. Its gradient with respect to x is A'v = Av (A symmetric). And the Hessian of f is A, so Hv = Av. The identity checks out.

Why v must be held constant: the identity is Hv = grad\_x(grad f(x) · v) **with v treated as a constant**. If the autodiff system were allowed to differentiate through v, the inner expression would be a function of both x and v and the outer gradient would pick up spurious terms. In practice this is automatic — v is a tensor you supply, not a function of x — but it is why the trick is written as a JVP of the gradient function rather than as a second derivative of something involving v.

**P8 (coding).** Expected outcome: with a correct implementation, every gradient should match central finite differences to a relative error below about 10^-9 in float64. Common bugs and their signatures: a missing transpose gives errors of order 1 on the weight gradients but correct bias gradients; a missing sum over the batch gives a bias gradient that is off by exactly the batch size; using the wrong activation derivative gives errors that grow with depth; forgetting the 1/B in the loss gives every gradient off by the same factor B, which is easy to spot because the *relative* error is identical across all parameters. That last diagnostic is genuinely useful: **a uniform relative error across all parameters means a scalar factor is wrong, not the structure.**

**P9.** Five causes and their checks: (i) learning rate is zero or `step()` is never called — print the optimizer's `param_groups` learning rate and add a counter to confirm steps happen; (ii) all gradients are None — print gradient norms after one backward pass; (iii) the parameters were never given to the optimizer — compare `len(list(model.parameters()))` against the optimizer's parameter count; (iv) the loss is computed on a detached tensor — check `loss.requires_grad` and `loss.grad_fn`; (v) all activations are dead, for example every ReLU off due to a large negative bias — print the fraction of positive pre-activations per layer. Note that (ii) and (v) look identical from the loss curve alone but differ sharply in the per-layer diagnostics, which is why the gradient-norm check is the right first move.
