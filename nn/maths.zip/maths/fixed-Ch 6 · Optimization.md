﻿# Chapter 6 · Optimization

2026-09-22 · @Behi

Everything so far has been about writing down an objective. This chapter is about minimizing it, which in deep learning is not a solved problem but a collection of well-understood heuristics resting on a theory that mostly assumes conditions deep networks violate.

The honest framing, which this chapter maintains throughout: **the convex theory is where the intuition comes from, and it is genuinely predictive about step sizes, conditioning and momentum; the non-convex reality is where you actually work, and there the guidance is empirical.** Knowing which claims rest on which footing is the difference between understanding optimization and reciting it.

## 6.1 The problem and what makes it hard

### The setup

$$
\min_{\theta \in \mathbb{R}^d} \; \mathcal{L}(\theta) = \frac{1}{n}\sum_{i=1}^{n} \ell(f_\theta(x_i), y_i) \; + \; \Omega(\theta)
$$

By Chapter 4 the first term is a negative log-likelihood and the second is a negative log-prior, so this is MAP estimation. By Chapter 2 you can compute the gradient at the cost of about two forward passes. The question is what to do with it.

Four features of this problem drive every design decision that follows:

1. **d is enormous** — up to 10^12. Anything requiring d-by-d storage is out.
2. **n is enormous**, so even one exact gradient is expensive. You will use noisy estimates.
3. **The objective is non-convex**, so there are no global guarantees.
4. **You do not actually want the minimum.** You want good test error, and the training minimum is a proxy that can be actively misleading. Optimization and generalization are different goals that happen to be pursued with the same procedure.

That fourth point is worth dwelling on, because it makes deep learning optimization genuinely different from classical optimization. Early stopping deliberately fails to minimize. SGD noise is not merely a cost to be tolerated but plausibly part of why the solutions generalize. **A better optimizer is not automatically a better training procedure**, and several methods that minimize training loss faster produce worse models. Say that in an interview and you will sound like someone who has actually trained things.

### Obstacle 1: conditioning

This is the most important one, and it is entirely explained by Chapter 1.

Near a minimum the loss looks like a quadratic form with the Hessian as its matrix. The level sets are ellipsoids whose axes are the Hessian's eigenvectors and whose widths go as one over the square root of the eigenvalues. The **condition number** is

$$
\kappa = \frac{\lambda_{\max}}{\lambda_{\min}}
$$

When kappa is large, the bowl is a long narrow valley. Gradient descent must use a step small enough not to diverge along the steep direction, but that same small step makes progress along the flat direction glacial. The gradient points mostly across the valley rather than along it, so the iterates **zigzag**: they bounce between the steep walls while creeping toward the minimum.

This single picture explains a remarkable amount of practice:

- **Feature standardization** makes X'X closer to the identity, which by Chapter 1's identity is the Hessian of least squares. Preprocessing is Hessian conditioning.
- **Normalization layers** keep activations at comparable scales, which keeps the effective curvature comparable across directions.
- **Momentum** damps the oscillation across the valley while accumulating progress along it.
- **Adam** rescales per coordinate, which fixes the part of the conditioning that is a per-coordinate scale mismatch.
- **Careful initialization** starts you where the curvature is not already pathological.

### Obstacle 2: non-convexity

The classical worry was local minima. The modern understanding is different and more interesting.

In high dimensions, a critical point is a minimum only if **every one** of the d Hessian eigenvalues is positive. If eigenvalue signs were even roughly independent, that becomes vanishingly unlikely as d grows. The overwhelming majority of critical points are **saddles**, and the theoretical and empirical work on this since around 2014 supports that picture.

Saddles are a milder problem than local minima, because a descent direction still exists — you are not trapped, only slowed. Gradient descent can stall near a saddle for a long time because the gradient is small there, which is one thing momentum and noise help escape.

The further empirical finding is that the minima that are found tend to have **similar loss values**, and that they are often connected: mode connectivity results show that two independently trained solutions can be joined by a path of near-constant low loss. So the landscape is less a collection of isolated pits and more a broad connected basin with a great deal of flat structure. That is a description supported by evidence rather than a theorem, and it should be stated as such.

### Obstacle 3: stochasticity

Computing the full gradient costs a pass over the whole dataset. Instead you use a minibatch:

$$
g_t = \frac{1}{B}\sum_{i \in \mathcal{B}_t} \nabla \ell_i(\theta_t), \qquad \mathbb{E}[g_t] = \nabla \mathcal{L}(\theta_t)
$$

The estimate is **unbiased**, and by Chapter 3 its covariance scales as 1/B. So noise falls as 1/sqrt(B) while cost rises linearly — the diminishing return that makes very large batches inefficient without other changes.

The noise is not purely a cost. It helps escape saddles and sharp narrow minima, and it is one leading explanation for why SGD solutions generalize. But it also means you can never converge exactly: with a constant learning rate, SGD reaches a **noise ball** around the optimum whose radius scales with the learning rate, and it bounces around there forever. That is precisely why learning-rate decay exists — shrinking the step shrinks the ball.

### What theory gives you, and where it stops

| Regime | Guarantee available |
| --- | --- |
| Convex and smooth | global minimum, known rate |
| Strongly convex | linear (geometric) convergence, unique minimum |
| Non-convex, smooth | convergence to a stationary point only |
| Non-convex, stochastic | convergence to a stationary point in expectation, under conditions |
| Deep networks in practice | no useful guarantee; empirical tuning |

The useful attitude: **convex theory tells you the right shape of the answer** — how step size should relate to curvature, why momentum helps, why conditioning matters, what decay schedules do — even though its hypotheses fail. Treat it as a source of correct intuitions rather than binding promises.

**Try it.** (a) For a quadratic with Hessian eigenvalues 100 and 1, what is the largest stable step size for gradient descent, and how many steps to reduce the error along the flat direction by a factor of e? (b) Why does the fraction of critical points that are minima fall with dimension? (c) You double the batch size. What happens to gradient noise, and to cost per step? Answers in 6.12.

## 6.2 Convexity

### The definitions

A set is **convex** if the segment between any two of its points stays inside it. A function is **convex** if its graph lies below every chord:

$$
f\big(\lambda x + (1-\lambda)y\big) \;\le\; \lambda f(x) + (1-\lambda)f(y) \quad \text{for all } \lambda \in [0,1]
$$

Three equivalent characterizations for differentiable functions, each useful in a different situation:

| Order | Condition | Reading |
| --- | --- | --- |
| Zeroth | chord above graph | the definition |
| First | f(y) >= f(x) + grad f(x)'(y - x) | **the tangent plane is a global underestimator** |
| Second | Hessian is PSD everywhere | curvature never bends downward |

The **first-order** condition is the one that does the most work. It says a local linear approximation never overestimates the function, which is exactly why a zero gradient implies a global minimum: if the gradient vanishes at x, the inequality reads f(y) >= f(x) for every y. That is a one-line proof of the central fact about convex optimization, and you should be able to produce it.

### What convexity buys

1. **Every local minimum is global.** No bad basins.
2. **The set of minimizers is convex**, so minima form a connected set, never isolated competing pits.
3. **A vanishing gradient certifies optimality.** You can *know* you are done, which you never can in the non-convex case.
4. **Convergence rates are provable** and depend only on a few constants.
5. **Duality works**, giving certified bounds on how far you are from optimal (section 6.7).

**Strong convexity** strengthens this: f minus (mu/2) times the squared norm is still convex, equivalently the Hessian's eigenvalues are all at least mu. This gives a **unique** minimizer and geometric convergence. **Smoothness** (L-Lipschitz gradient, equivalently Hessian eigenvalues at most L) bounds curvature above. Together they sandwich the function between two quadratics, and the ratio L/mu is the condition number that governs everything in section 6.3.

### How to recognize convexity

Rather than checking Hessians, learn the **calculus of convexity** — build convex functions from known ones.

Atoms: linear and affine functions (convex and concave), any norm, the exponential, the negative logarithm, x log x, the max of a set, log-sum-exp, and x'Ax for PSD A.

Operations that **preserve** convexity:

- **Nonnegative weighted sums.** Sum of convex is convex, which is why adding L2 regularization to a convex loss keeps it convex.
- **Composition with an affine map:** f(Ax + b) is convex if f is. This is the big one for ML — it is why a linear model with a convex loss is convex in the parameters.
- **Pointwise maximum** of convex functions, even infinitely many. This is why hinge loss and the max in a support vector machine are convex, and why a supremum over a family (as in duality) is convex.
- **Composition rules:** g(f(x)) is convex if g is convex and non-decreasing and f is convex.

**The rule that decides most ML cases:** a convex loss composed with a linear model is convex. Linear regression, ridge, lasso, logistic regression, softmax regression, and SVMs are all convex for exactly this reason. Chapter 4 gave the deeper reason for the GLM family: the log-partition function is convex because its Hessian is a covariance.

**And why deep networks are not convex:** a composition of convex functions is *not* generally convex, and more concretely, the parameters enter multiplicatively across layers. Even the two-parameter function (w\_1 w\_2 - 1)^2 is non-convex. There is also an inescapable structural reason: **permutation symmetry.** Swap two hidden units and you get an identical function at a different parameter point, so any minimum comes with an exponentially large family of equivalent minima, and a convex function cannot have disconnected minimizers. Giving that symmetry argument is a much sharper answer than "because of the nonlinearities".

### Convex functions you meet constantly

| Function | Convex? | Note |
| --- | --- | --- |
| squared error in w | yes | Hessian 2X'X is PSD |
| logistic loss in w | yes | Hessian is X' diag(p(1-p)) X |
| hinge loss | yes | max of two affine functions |
| any norm, including L1 | yes | but non-differentiable at 0 |
| log-sum-exp | yes | Hessian is the softmax Jacobian, a covariance |
| negative log-likelihood of an exponential family in the natural parameter | yes | Chapter 4 |
| 0-1 loss | **no** | which is why we use surrogates |
| a deep network's loss in its weights | **no** | multiplicative parameters, permutation symmetry |

The 0-1 loss row is worth a sentence: it is non-convex, discontinuous, and has zero gradient almost everywhere, so it is unusable directly. Cross-entropy and hinge loss are **convex surrogates** that upper-bound it, which is the real reason you train on them.

### Why it still matters for deep learning

You might reasonably ask why any of this is worth learning if deep networks violate all of it. Four reasons:

- **The final layer is usually convex given the features.** Linear probing, last-layer fine-tuning, and calibration fitting are convex problems solved exactly.
- **Many components remain convex**, and classical models remain competitive on tabular data.
- **The intuitions transfer.** Step-size limits, conditioning effects and momentum's benefit are all first understood here and observed in practice there.
- **Local behaviour near a minimum is convex**, since the Hessian is PSD at a local minimum. The convex analysis is the correct description of the endgame.

**Try it.** (a) Prove that if the gradient of a convex differentiable function vanishes at x, then x is a global minimum. (b) Show that the max of two convex functions is convex directly from the definition. (c) Give the permutation-symmetry argument for why a two-hidden-unit network's loss cannot be convex. Answers in 6.12.

## 6.3 Gradient descent and its rates

### The method, and why it is the method

$$
\theta_{t+1} = \theta_t - \eta\,\nabla \mathcal{L}(\theta_t)
$$

The standard justification: the gradient is the steepest-ascent direction (Chapter 2), so its negative is steepest descent. The better justification, because it generalizes, is that gradient descent **minimizes a local model**. Take the first-order Taylor expansion plus a quadratic penalty for moving far:

$$
\theta_{t+1} = \arg\min_{\theta} \; \Big[ \mathcal{L}(\theta_t) + \nabla\mathcal{L}(\theta_t)^{\top}(\theta - \theta_t) + \frac{1}{2\eta}\lVert \theta - \theta_t \rVert^2 \Big]
$$

Differentiate and solve: you get exactly the gradient step. So **the learning rate is a trust-region radius**: it encodes how far you trust the linear approximation. This framing is worth holding because changing the penalty term changes the algorithm — use a Fisher-norm penalty and you get natural gradient, use a KL penalty and you get TRPO, use a per-coordinate weighted norm and you get Adam-like methods. Every optimizer in this chapter is a choice of local model plus a choice of what "far" means.

### The step-size limit

For a quadratic with Hessian H, the update in the eigenbasis decouples completely: along the eigenvector with eigenvalue lambda, the error is multiplied by (1 - eta lambda) each step. So you need

$$
|1 - \eta\lambda| < 1 \quad \text{for every } \lambda \quad \Longleftrightarrow \quad \eta < \frac{2}{\lambda_{\max}}
$$

**The largest curvature sets the maximum stable step size.** Exceed 2/lambda\_max and the iterates oscillate with growing amplitude and the loss diverges. This is the precise statement behind "the learning rate was too high" and it is a genuinely predictive piece of theory: the divergence threshold depends on the sharpest direction alone, not on the average curvature.

The optimal constant step for a quadratic balances the two extremes:

$$
\eta^* = \frac{2}{\lambda_{\max} + \lambda_{\min}}, \qquad \text{contraction factor} = \frac{\kappa - 1}{\kappa + 1}
$$

For kappa = 100 the factor is 0.980, so each step removes 2% of the error and you need about 230 steps per factor of e. For kappa = 10,000, about 23,000 steps. **The iteration count scales linearly with the condition number**, which is why conditioning is the dominant practical concern.

### The three convergence rates

| Assumptions | Rate | Steps for accuracy epsilon |
| --- | --- | --- |
| convex, L-smooth | O(1/t) | O(1/epsilon) |
| strongly convex, L-smooth | O((1 - mu/L)^t), **linear** | O(kappa log(1/epsilon)) |
| non-convex, L-smooth | min gradient norm squared is O(1/t) | O(1/epsilon^2) to a stationary point |

Only the strongly convex case gives **linear convergence** — error shrinking by a constant factor each step, so the number of steps grows only logarithmically in the accuracy you want. Note the unfortunate terminology: "linear convergence" means geometric decay, and "sublinear" O(1/t) is slower. This trips people up.

**The one-step descent lemma**, which is the engine of all these proofs and short enough to reproduce. L-smoothness gives a quadratic upper bound:

$$
\mathcal{L}(\theta_{t+1}) \le \mathcal{L}(\theta_t) + \nabla\mathcal{L}(\theta_t)^{\top}(\theta_{t+1} - \theta_t) + \frac{L}{2}\lVert \theta_{t+1} - \theta_t \rVert^2
$$

Substitute the gradient step:

$$
\mathcal{L}(\theta_{t+1}) \le \mathcal{L}(\theta_t) - \eta\Big(1 - \frac{L\eta}{2}\Big)\lVert \nabla\mathcal{L}(\theta_t)\rVert^2
$$

With eta = 1/L the bracket is 1/2, giving a guaranteed decrease of ||grad||^2/(2L) per step. **Every step strictly decreases the loss by an amount proportional to the squared gradient norm.** Summing this telescoping inequality gives the non-convex O(1/t) result immediately, and adding convexity or strong convexity upgrades it to the other two rows. If you can state the descent lemma and explain that summing it gives the rate, you have the core of convex optimization theory.

### Lower bounds, and why acceleration exists

A striking result: for the class of convex L-smooth problems, **no** first-order method (any method whose iterates lie in the span of the gradients seen so far) can beat O(1/t^2). Gradient descent achieves only O(1/t), so it is **not optimal**. For strongly convex problems the lower bound involves sqrt(kappa) rather than kappa.

That gap between what gradient descent achieves and what is information-theoretically possible is precisely the gap that momentum closes, which is the subject of section 6.4. Knowing that acceleration is not a trick but the attainment of a known lower bound is the right way to understand it.

### Line search, and why deep learning does not use it

Classical optimization picks the step size adaptively: **exact line search** minimizes along the ray, and **backtracking with the Armijo condition** shrinks the step until a sufficient-decrease test passes. Both are standard and both are well understood.

Deep learning uses neither, and the reasons are worth knowing: each trial evaluation costs a full forward pass, the stochastic loss is noisy so the test is unreliable, and — most importantly — **you do not actually want to minimize the training loss as fast as possible**. A schedule that maintains a larger step than a line search would choose tends to generalize better. This is one of the clearest cases where the classical objective and the deep learning objective genuinely differ.

### Subgradients

For non-differentiable convex functions such as the L1 norm or hinge loss, a **subgradient** is any g with

$$
f(y) \ge f(x) + g^{\top}(y - x) \quad \text{for all } y
$$

At a kink there is a whole set of them (for |x| at zero, the interval \[-1, 1\]). Subgradient descent converges but slowly, at O(1/sqrt(t)) even for strongly convex problems, and the loss is **not** monotonically decreasing. For structured problems there is a better tool: **proximal methods**, where the L1 case gives a closed-form soft-thresholding step, which is what makes ISTA and coordinate descent for lasso efficient. In deep learning, frameworks just pick a subgradient (0 for ReLU at 0) and this is fine for the reasons given in Chapter 2.

**Try it.** (a) For a quadratic with eigenvalues 1 and 100, compute the maximum stable learning rate, the optimal one, and the contraction factor. (b) Derive the descent lemma's consequence for eta = 1/L. (c) Why is "linear convergence" faster than "sublinear" convergence, despite how the names sound? Answers in 6.12.

## 6.4 Momentum and acceleration

### The method

$$
v_{t+1} = \beta v_t + \nabla\mathcal{L}(\theta_t), \qquad \theta_{t+1} = \theta_t - \eta\, v_{t+1}
$$

with beta typically 0.9. Instead of stepping along the current gradient, step along an exponentially weighted average of all past gradients.

### Three ways to see why it helps

**1. The physical picture.** A ball rolling down a valley with friction. Components of the gradient that keep pointing the same way accumulate; components that flip sign every step cancel. In a narrow valley, the across-valley component oscillates and cancels while the along-valley component persists and builds. **Momentum damps the zigzag and amplifies the consistent drift** — exactly the two things the conditioning problem needs.

**2. The algebraic picture.** Unroll the recursion:

$$
v_t = \sum_{k=0}^{t} \beta^{k}\,\nabla\mathcal{L}(\theta_{t-k})
$$

This is an exponential moving average with decay beta. Its weights sum to 1/(1 - beta), so the **effective step size is amplified by that factor**: beta = 0.9 gives a 10x amplification, beta = 0.99 gives 100x. That is why increasing momentum without decreasing the learning rate often causes divergence, and it is the quantitative answer to "why did raising momentum blow up my run?"

The averaging window is roughly 1/(1 - beta) steps: 10 steps at 0.9, 100 at 0.99.

**3. The rate.** For a quadratic, the right combination of eta and beta gives a contraction factor of

$$
\frac{\sqrt{\kappa}-1}{\sqrt{\kappa}+1} \quad \text{instead of} \quad \frac{\kappa-1}{\kappa+1}
$$

**The condition number is replaced by its square root.** For kappa = 10,000 that is the difference between roughly 23,000 steps per factor of e and roughly 230 — a hundredfold improvement from two lines of code. This is the single strongest quantitative argument for momentum and the one to quote.

### Nesterov's variant

$$
v_{t+1} = \beta v_t + \nabla\mathcal{L}(\theta_t - \eta\beta v_t), \qquad \theta_{t+1} = \theta_t - \eta v_{t+1}
$$

Evaluate the gradient at the **look-ahead** point, where momentum is about to carry you, rather than where you currently are. The intuition: you know you are going to move by the momentum term regardless, so you may as well measure the slope at the destination. If the loss is about to start rising there, Nesterov sees it a step earlier and brakes; classical momentum overshoots and only corrects afterwards.

Nesterov's accelerated gradient attains the **optimal** O(1/t^2) rate for smooth convex problems, matching the lower bound from section 6.3. That is a theorem, and it is what makes acceleration a principled method rather than a heuristic.

In deep learning the practical difference between classical and Nesterov momentum is usually small, and both are standard options in every framework.

### Why acceleration is genuinely strange

Worth flagging, because it is a good discussion point. Nesterov's method is **not monotonic** — the loss can increase on individual steps — and the classical proof is an algebraic verification that offers little insight. The physical analogy is suggestive but not a proof. There is a body of work interpreting acceleration through continuous-time differential equations, through a linear-coupling view of gradient and mirror descent, and through Chebyshev polynomial approximations, but no single explanation has the clarity of, say, the descent lemma. Saying "acceleration works and is optimal, but the intuition for *why* is genuinely subtle" is the accurate and honest statement.

### In practice

| Setting | Guidance |
| --- | --- |
| beta = 0.9 | the standard default; averages roughly 10 steps |
| beta = 0.99 or higher | for very noisy gradients; reduce the learning rate correspondingly |
| beta and eta interact | increasing beta increases the effective step by 1/(1-beta) |
| SGD with momentum | still the strongest choice for convolutional vision models |
| Adam | already contains momentum as its first-moment term |

A useful related technique: **exponential moving averages of the weights themselves** (Polyak averaging, and EMA of model weights in modern training). This is different from momentum — it averages the *iterates* rather than the gradients — and it reduces the noise-ball effect from section 6.5, often giving a meaningful improvement at essentially no cost. Stochastic weight averaging is the same idea applied over a schedule, and EMA of weights is standard practice in diffusion model training.

**Try it.** (a) With beta = 0.9, what is the effective step-size multiplier, and roughly how many past gradients contribute meaningfully? (b) For kappa = 400, compare the contraction factors of plain gradient descent and momentum, and the step counts implied. (c) Explain in two sentences why Nesterov's look-ahead helps at the bottom of a valley. Answers in 6.12.

## 6.5 Stochastic gradient descent

### Why noise is worth it

A full-batch gradient costs n example-gradients. A minibatch of size B costs B and gives an unbiased estimate. Since accuracy is not what limits early progress — you only need a direction that is roughly downhill — **it is far better to take many noisy steps than one exact step.** With n = 10^6 and B = 256, you take about 4,000 steps per epoch instead of one. SGD wins overwhelmingly on wall-clock progress, and that is the entire justification.

### The noise ball

With a constant learning rate, SGD does not converge to a point. It reaches a stationary distribution around the minimum whose spread satisfies, approximately,

$$
\mathbb{E}\big[\lVert \theta - \theta^* \rVert^2\big] \;\sim\; \frac{\eta\,\sigma^2}{B}
$$

**The noise-ball radius grows with the learning rate and shrinks with the batch size.** Two immediate consequences: the loss curve plateaus at a level set by eta and B rather than at the true minimum, and **decaying the learning rate shrinks the ball**, which is exactly why a decay produces that characteristic sudden drop in the loss curve. When you see a step-function improvement at a scheduled decay, you are watching the noise ball contract.

The classical convergence conditions (Robbins-Monro) are that the step sizes sum to infinity but their squares sum to something finite — large enough to travel any distance, small enough for the noise to die out. Schedules like 1/t satisfy this. In practice nobody uses 1/t, because it decays too fast early on.

### Noise as a feature, not only a bug

Three ways noise helps, all empirically supported though not all fully theoretically settled:

- **Escaping saddles.** Near a saddle the gradient is small, but noise supplies a random kick that can find the descent direction. There are results showing perturbed gradient descent escapes strict saddles in polynomial time.
- **Avoiding sharp minima.** A narrow minimum cannot hold an iterate that is being jostled; a wide flat one can. SGD noise therefore acts as a filter preferring flat regions. The link between flatness and generalization is a plausible and widely held hypothesis rather than an established theorem, and it is worth stating with that hedge.
- **Implicit regularization.** SGD's trajectory-dependent bias is one of the main candidate explanations for why overparameterized networks generalize, connecting to the minimum-norm result in Chapter 1.

### Batch size

| Small batch | Large batch |
| --- | --- |
| noisier gradients | cleaner gradients |
| more steps per epoch | fewer steps per epoch |
| better GPU utilization at the low end | saturates hardware, better throughput |
| often generalizes better with default settings | needs tuning to match |

The **linear scaling rule** is the standard heuristic: if you multiply the batch size by k, multiply the learning rate by k. The reasoning is that k steps of small-batch SGD approximately equal one step of k-times-larger batch at k times the step size, so the total distance travelled per example is preserved. It works well over a substantial range and breaks at very large batches, where **warmup** becomes necessary — starting from a small learning rate and ramping up over a few thousand steps — because the large-step regime is unstable early in training when the curvature is changing fast.

There is also a **critical batch size** beyond which increasing B buys almost nothing: once the gradient noise is small compared to the curvature-limited step, more samples do not let you take bigger steps. The empirical work on gradient noise scale formalizes this, and the practical upshot is that there is a data-and-model-dependent point past which scaling the batch stops converting into faster training.

### Learning-rate schedules

This is one of the highest-leverage hyperparameter choices, and the options have converged to a small set.

| Schedule | Shape | Notes |
| --- | --- | --- |
| Constant | flat | simple; plateaus at the noise ball |
| Step decay | drop by 10x at milestones | classic for vision; visible loss steps |
| **Cosine** | smooth decay to near zero | the current default for most large training runs |
| Linear decay to zero | straight line | common for language model training |
| Inverse square root | 1/sqrt(t) | the original transformer schedule |
| Warmup then decay | ramp up, then any of the above | essentially mandatory for transformers and large batches |
| Cyclical / warm restarts | repeated decay cycles | useful for ensembling snapshots |

**Why warmup is needed**, since this comes up constantly: early in training the parameters are random, the gradients are large and poorly aligned, and adaptive optimizers have unreliable second-moment estimates based on very few samples. Taking full-size steps in that regime can push the model into a bad region it never recovers from. Warmup lets the statistics settle and the curvature stabilize before you commit to large steps. For Adam specifically, the second-moment estimate is high-variance in the first few steps, which is one concrete mechanism.

**Why decay to (nearly) zero at the end:** the noise ball. A late-training run at a high learning rate cannot settle; shrinking eta shrinks the ball and lets the iterate land. Cosine and linear-to-zero both do this smoothly.

### Variance reduction, and why it did not take over

Methods like SVRG and SAG use control variates (Chapter 3) to reduce gradient variance, achieving linear convergence for strongly convex finite-sum problems — a genuinely better rate than SGD's. They are important theoretically and rarely used in deep learning, for reasons worth knowing: they require storing or periodically recomputing full gradients, the memory cost is prohibitive at scale, the theory assumes convexity, and critically, **reducing the noise removes a mechanism that may be helping generalization.** This is a good concrete example of the chapter's theme that faster training-loss minimization is not automatically better.

**Try it.** (a) You increase the batch size from 64 to 512 and keep the learning rate fixed. What happens to the noise-ball radius, and what should you do about it? (b) Why does a loss curve show a sharp drop exactly when a step decay fires? (c) Give two distinct reasons warmup is needed for transformer training. Answers in 6.12.

## 6.6 Adaptive methods

### The idea

Plain SGD uses one learning rate for every parameter. But parameters differ enormously in gradient scale — an embedding row for a rare token receives gradient on a tiny fraction of steps, while a first-layer weight receives it every step. **Adaptive methods give each coordinate its own effective step size, derived from the history of its gradients.**

In the language of section 6.3, they change the trust-region penalty from a plain Euclidean norm to a diagonally weighted one. They are **diagonal preconditioners**, and that is the cleanest way to describe them.

### AdaGrad

$$
G_t = G_{t-1} + g_t^2 \;\text{(elementwise)}, \qquad \theta_{t+1} = \theta_t - \frac{\eta}{\sqrt{G_t} + \epsilon}\, g_t
$$

Accumulate the sum of squared gradients per coordinate and divide by its square root. Coordinates with historically large gradients get small steps; rarely updated ones keep large steps. This works beautifully for sparse features and has genuine regret guarantees for convex problems.

Its fatal flaw: **G only ever grows**, so the effective learning rate decays monotonically to zero. In a long non-convex run the optimizer stops making progress long before it should. Everything that follows is a fix for this.

### RMSProp

$$
v_t = \beta_2 v_{t-1} + (1-\beta_2) g_t^2, \qquad \theta_{t+1} = \theta_t - \frac{\eta}{\sqrt{v_t} + \epsilon} g_t
$$

Replace the sum with an exponential moving average. Now old gradients are forgotten, the denominator tracks the *recent* gradient scale rather than all of history, and the learning rate no longer decays to zero.

### Adam

RMSProp plus momentum, plus a bias correction:

$$
m_t = \beta_1 m_{t-1} + (1-\beta_1)g_t, \qquad v_t = \beta_2 v_{t-1} + (1-\beta_2)g_t^2
$$

$$
\hat{m}_t = \frac{m_t}{1-\beta_1^t}, \qquad \hat{v}_t = \frac{v_t}{1-\beta_2^t}, \qquad \theta_{t+1} = \theta_t - \frac{\eta\,\hat{m}_t}{\sqrt{\hat{v}_t} + \epsilon}
$$

Defaults: beta\_1 = 0.9, beta\_2 = 0.999, epsilon = 10^-8.

**Why bias correction exists**, which is a good interview question. Both moving averages start at zero, so early estimates are biased toward zero: after one step, m\_1 = (1 - beta\_1) g\_1, which is only 10% of the gradient. Dividing by (1 - beta\_1^t) exactly undoes this. It matters most for v, where beta\_2 = 0.999 means the raw estimate takes thousands of steps to warm up, and an under-estimated denominator produces enormous early steps. Without bias correction, Adam's first few hundred updates are badly mis-scaled — which is also part of why warmup helps.

**The right way to read the update:** m/sqrt(v) is approximately a **signal-to-noise ratio**. If a coordinate's gradient is consistent, the mean is large relative to the root-mean-square and the ratio approaches 1. If it is noisy and sign-flipping, the mean is small relative to the RMS and the ratio approaches 0. So Adam takes confident steps in consistent directions and small steps in noisy ones, and the update magnitude per coordinate is bounded by roughly eta. **That bounded step size is why Adam is so robust to learning-rate choice** compared with SGD, and it is the best one-sentence explanation of its popularity.

### AdamW

The decoupled-weight-decay fix from Chapter 4, restated here because it is an optimization fact:

$$
\theta_{t+1} = \theta_t - \eta\left( \frac{\hat{m}_t}{\sqrt{\hat{v}_t}+\epsilon} + \lambda\,\theta_t \right)
$$

If you instead add lambda||theta||^2 to the loss, its gradient lambda\*theta passes through the adaptive scaling and gets divided by sqrt(v). Parameters with large gradient history then receive **less** decay, which is backwards. AdamW applies the shrinkage directly. This is why AdamW, not Adam, is the standard for transformer training, and the mechanism is a standard interview question with a precise answer.

### The honest current picture

This is where a well-informed answer differs from a textbook one.

- **Adam/AdamW dominates language models and transformers.** The gradient scales across a transformer's parameter groups vary by orders of magnitude, and per-coordinate scaling handles that automatically. Attempts to train large language models with plain SGD at competitive cost have generally not succeeded.
- **SGD with momentum remains competitive or better for convolutional vision models**, often generalizing slightly better with a well-tuned schedule. The gap has narrowed but the folklore has a real basis.
- **Adam's original convergence proof was wrong.** A 2018 paper exhibited a convex counterexample where Adam fails to converge, and proposed AMSGrad as a fix. In practice AMSGrad is rarely used and Adam works fine, which is itself an instructive commentary on the relationship between convex theory and deep learning practice.
- **Epsilon is not just a numerical guard.** It sets a floor on the denominator, so it controls how much adaptivity you actually get. Raising it from 10^-8 to 10^-4 moves the optimizer measurably toward plain SGD behaviour, and it is a real (if rarely tuned) knob.
- **beta\_2 controls the memory of the scale estimate.** Lowering it to 0.95 is common in large language model training, making the optimizer more responsive to changing gradient scales.
- **Newer optimizers** aiming to beat AdamW — including matrix-preconditioned methods such as Shampoo and, more recently, Muon, which orthogonalizes the momentum update for matrix-shaped parameters — have shown genuine wall-clock improvements in several reported settings. This is an actively moving area; the defensible statement is that AdamW remains the safe default while matrix-aware preconditioners are a serious and promising line of work rather than a settled replacement. If it matters for your work, check the current literature rather than relying on any summary.

### Practical defaults

| Setting | Value |
| --- | --- |
| Optimizer | AdamW for transformers; SGD + momentum 0.9 for convolutional vision |
| Learning rate | 1e-3 to 3e-4 for Adam on small models; 1e-4 or lower for large transformers |
| beta\_1, beta\_2 | 0.9, 0.999 (or 0.95 for large-scale language training) |
| Weight decay | 0.01 to 0.1 with AdamW; exclude biases and normalization parameters |
| Schedule | linear or cosine warmup over a few thousand steps, then cosine or linear decay |
| Gradient clipping | global norm 1.0 is a common and cheap safeguard |

**Try it.** (a) After 1 step with beta\_2 = 0.999, what fraction of the true second moment does the uncorrected v represent, and what does that do to the step size? (b) Explain why m/sqrt(v) behaves like a signal-to-noise ratio. (c) Why does adding L2 to the loss give different behaviour from AdamW's decoupled decay? Answers in 6.12.

## 6.7 Constrained optimization, duality, KKT

### The problem

$$
\min_x \; f(x) \quad \text{subject to} \quad g_i(x) \le 0, \qquad h_j(x) = 0
$$

### The Lagrangian

Fold the constraints into the objective with multipliers:

$$
\mathcal{L}(x, \lambda, \nu) = f(x) + \sum_i \lambda_i g_i(x) + \sum_j \nu_j h_j(x), \qquad \lambda_i \ge 0
$$

The multipliers are **prices**: lambda\_i is what you pay per unit of violation of constraint i. The nonnegativity on lambda is essential and one-sided because inequality constraints only bind from one direction — you are not rewarded for being well inside the feasible region.

The key observation that makes duality work: for any **feasible** x, the sup over lambda >= 0 and free nu of the Lagrangian equals f(x), because the best you can do is set the multipliers to zero on satisfied constraints. For an infeasible x the sup is infinity. So

$$
\min_x \max_{\lambda \ge 0, \nu} \mathcal{L} \quad \text{is exactly the original constrained problem}
$$

### The dual

Swap the order. Define the dual function by minimizing over x:

$$
d(\lambda, \nu) = \inf_x \mathcal{L}(x, \lambda, \nu), \qquad \text{dual problem:} \quad \max_{\lambda \ge 0, \nu} d(\lambda,\nu)
$$

Two facts worth having:

1. **The dual function is always concave**, regardless of whether f and g are convex, because it is a pointwise infimum of functions that are affine in (lambda, nu). So the dual problem is always a concave maximization, hence tractable. That is a genuinely remarkable structural fact.
2. **Weak duality always holds:** d(lambda, nu) <= p\*, the primal optimum. Every feasible dual point is a **certificate** of a lower bound on the primal optimum, which is what branch-and-bound methods exploit.

**Strong duality** — the two optima being equal — holds for convex problems under a constraint qualification, the usual one being **Slater's condition**: there exists a strictly feasible point. Under strong duality, solving either problem solves the other, and you may pick whichever is easier.

### KKT conditions

For convex problems with strong duality, these are **necessary and sufficient** for optimality:

| Condition | Statement | Meaning |
| --- | --- | --- |
| Stationarity | gradient of the Lagrangian in x is zero | no improving direction |
| Primal feasibility | g\_i(x) <= 0, h\_j(x) = 0 | the solution is legal |
| Dual feasibility | lambda\_i >= 0 | prices are one-sided |
| **Complementary slackness** | lambda\_i g\_i(x) = 0 for every i | each constraint is either tight or free |

**Complementary slackness is the one that carries the content.** For each constraint, either it is active (g\_i = 0, and the multiplier may be positive) or it is slack (g\_i < 0, and the multiplier must be zero). A constraint you are not pressing against has zero price. The picture at the optimum: the objective's gradient is a nonnegative combination of the active constraints' gradients — you cannot improve without pushing into a wall.

### Why an ML student should care

**Support vector machines** are the textbook application, and the argument is genuinely elegant. The primal minimizes half the squared norm subject to margin constraints. The dual is a quadratic program in the multipliers, and three things fall out:

- **Complementary slackness identifies the support vectors.** Only points on the margin have nonzero multipliers; all other training points can be deleted without changing the solution. The sparsity of the solution is a KKT consequence, not a design choice.
- **The dual depends on the data only through inner products** x\_i'x\_j. Replace them with a kernel and you get nonlinear classification without ever computing the feature map. **The kernel trick is a consequence of taking the dual**, which is the real reason duality is taught in an ML course.
- The dual has one variable per data point rather than per feature, so it is preferable when features vastly outnumber examples.

Other appearances worth knowing:

- **Constrained policy optimization.** TRPO maximizes a surrogate subject to a KL constraint; the Lagrangian view turns the constraint into a penalty, and PPO's clipped objective is a cheap approximation to the same intent. Chapter 9 develops this.
- **Lagrangian methods for constrained RL**, where a safety cost has a budget and the multiplier is learned alongside the policy, automatically increasing the penalty when the constraint is violated.
- **Maximum entropy derivations** (Chapter 5) are Lagrangian: the natural parameters of an exponential family *are* the multipliers on the moment constraints.
- **Regularization as constraint.** Minimizing loss plus lambda times a penalty is the Lagrangian form of minimizing loss subject to a bound on the penalty. Every lambda corresponds to some radius, which is why the penalized and constrained formulations of ridge and lasso give the same solution paths.
- **Optimal transport** (Chapter 5) has a linear-programming dual, which is exactly the Kantorovich-Rubinstein formula that makes WGAN implementable.

### Projected gradient, an alternative

When the feasible set is simple, you can skip duality: take a gradient step and project back:

$$
\theta_{t+1} = \Pi_{\mathcal{C}}\big( \theta_t - \eta\nabla f(\theta_t) \big)
$$

Projection onto an L2 ball is a rescaling; onto a box is clipping; onto the probability simplex there is a known O(d log d) algorithm. This is how adversarial examples are generated under an L-infinity budget (projected gradient descent, the standard attack and the basis of adversarial training), and how norm-constrained training is implemented.

**Try it.** (a) Minimize x^2 + y^2 subject to x + y = 1 using a Lagrange multiplier, and interpret the multiplier's value. (b) In an SVM, explain why a training point far from the boundary has zero dual multiplier. (c) Explain why the kernel trick requires the dual formulation. Answers in 6.12.

## 6.8 Second-order and preconditioned methods

### The unifying view

Every method in this chapter has the form

$$
\theta_{t+1} = \theta_t - \eta\, P^{-1} g_t
$$

and differs only in the choice of preconditioner P:

| Method | P |
| --- | --- |
| SGD | identity |
| Adam / RMSProp | diagonal, from the gradient second moment |
| Newton | the Hessian |
| Gauss-Newton | J' (loss Hessian) J |
| Natural gradient | the Fisher information |
| K-FAC | a Kronecker-factored approximation to the Fisher |
| Shampoo, and related matrix methods | per-tensor matrix preconditioners from gradient covariances |

**Preconditioning is a change of coordinates in which the problem is better conditioned.** That single sentence organizes the whole zoo, and it is the right answer to "what is the relationship between Adam and Newton's method?" — Adam is a cheap diagonal approximation to a curvature-aware method, and its adaptivity is preconditioning, not a separate idea.

### Newton's method

$$
\theta_{t+1} = \theta_t - H^{-1}\nabla\mathcal{L}(\theta_t)
$$

Minimize the local quadratic model exactly instead of the local linear model with a step penalty. Two genuinely valuable properties: **quadratic convergence** near a minimum (the number of correct digits doubles each step), and **affine invariance** — rescale or linearly reparameterize your variables and Newton's trajectory is unchanged. Gradient descent has neither, and affine invariance is precisely the property that would make the conditioning problem of section 6.1 disappear.

The obstacles in deep learning, restated from Chapter 2 because this is where they belong:

1. **Storage and inversion.** O(d^2) and O(d^3) with d in the billions.
2. **Indefiniteness.** Away from a minimum the Hessian has negative eigenvalues, and Newton's step then moves toward a saddle rather than away from it — it solves for a stationary point, not a minimum.
3. **Stochastic noise.** Minibatch curvature estimates are noisy, and inverting a noisy matrix amplifies error exactly in the small-eigenvalue directions you care most about.

### The practical family

**Damping and trust regions.** Add lambda I to the Hessian before inverting. This makes it positive definite, bounds the step, and interpolates between Newton (lambda small) and gradient descent (lambda large). Levenberg-Marquardt is this idea with an adaptive lambda, and it is the standard approach in nonlinear least squares.

**Hessian-free / truncated Newton.** Solve H d = -g approximately by conjugate gradient, which needs only Hessian-vector products (Chapter 2, section 2.8). No matrix is ever formed. A few CG iterations give a useful direction, and truncating early is itself a form of regularization.

**Quasi-Newton (BFGS, L-BFGS).** Build an approximate inverse Hessian from successive gradient differences, using the secant condition. **L-BFGS** keeps only the last m updates (typically 5 to 20), so memory is O(md). It is excellent for smooth deterministic problems and is the default in classical optimization packages.

Why L-BFGS is not used for deep learning: the curvature approximation relies on gradient differences being meaningful, and with different minibatches at each step the differences are dominated by sampling noise rather than curvature. It also requires a line search, which is expensive and unreliable on a stochastic objective. It remains a good choice for full-batch problems, small models, and classical convex fitting.

**Natural gradient and K-FAC.** Precondition by the Fisher, giving steepest descent in distribution space and invariance to reparameterization (Chapters 2, 4 and 5). K-FAC exploits the structure from Chapter 2: a layer's gradient is an outer product of input activation and output error, so its second moment approximately factorizes as a Kronecker product of two much smaller matrices, each of which can be inverted cheaply.

**Matrix-aware preconditioners.** Methods such as Shampoo maintain preconditioners for each tensor dimension rather than per scalar coordinate, capturing correlations that a diagonal method cannot. More recent work in this line — Muon being the prominent recent example, which orthogonalizes the momentum matrix before stepping — has reported meaningful wall-clock gains on language model training. This is an active area as of this writing, and the honest position is that matrix-aware preconditioning is a promising direction with real reported results rather than a settled replacement for AdamW; check the current literature before making claims about it.

### When second-order methods genuinely win

Be specific, because "second-order methods are impractical" is too blunt:

- **Small-to-medium full-batch problems.** L-BFGS is often far faster than any first-order method.
- **Ill-conditioned problems** where the condition number is the binding constraint.
- **Physics-informed and scientific ML**, where high precision on a smooth objective is required.
- **Final-layer or calibration fitting**, which is convex and small.
- **Problems needing high accuracy**, since first-order methods stall at moderate precision while Newton-type methods keep converging.

And where they lose: large stochastic deep learning, where the noise, the memory, and the fact that you do not want the exact minimum all argue against them.

**Try it.** (a) Express SGD, Adam, and Newton in the common preconditioner form and identify P for each. (b) Why does Newton's method move toward a saddle if the Hessian is indefinite? (c) Why does L-BFGS work poorly with minibatch gradients? Answers in 6.12.

## 6.9 The deep learning loss landscape

This section is more empirical than the rest of the chapter, and it is flagged as such. These are findings and working hypotheses, not theorems, and being able to distinguish the two is the point.

### Saddles, not local minima

The old worry was getting stuck in a bad local minimum. The modern view: in high dimensions, a critical point is a minimum only if all d Hessian eigenvalues are positive, which becomes exponentially unlikely as d grows. Critical points are overwhelmingly **saddles**, and the empirical Hessian spectra of trained networks are consistent with this.

Saddles slow you down rather than trap you, because a descent direction still exists. Momentum and gradient noise both help escape them. The practical implication is that **you should not spend time worrying about local minima in a large network**; the real failure modes are instability, poor conditioning, and bad initialization.

### The Hessian spectrum

Empirically, a trained deep network's Hessian has a characteristic shape: a large **bulk** of eigenvalues concentrated near zero, plus a small number of large **outliers**, often roughly as many as there are classes. Reading it:

- Most directions are nearly flat, so the minimum is better described as a broad basin than a point.
- A handful of sharp directions dominate the stable learning rate, since the limit is 2/lambda\_max.
- This is why loss curves are so sensitive to the learning rate: you are riding a constraint set by a few outlier directions while most of the parameter space is doing nothing much.

### Flat versus sharp minima

The hypothesis: flat minima generalize better, because a flat region means the loss is insensitive to parameter perturbation, and a small shift between the training and test loss surfaces therefore costs little. It also connects to minimum-description-length arguments — a flat minimum requires fewer bits to specify.

The evidence is genuinely mixed and you should say so. Large-batch training tends to find sharper minima and often generalizes slightly worse, which supports the hypothesis. But **sharpness is not reparameterization-invariant**: you can rescale weights in a ReLU network (or exploit a normalization layer's scale invariance) to make a minimum arbitrarily sharp or flat without changing the function at all. So naive sharpness measures cannot be the whole story. Scale-invariant sharpness measures have been proposed to address this. **SAM** (sharpness-aware minimization) explicitly optimizes for flatness by minimizing the worst-case loss in a neighbourhood, and it does improve generalization in many settings, which is suggestive evidence for the hypothesis even if the theory is unsettled.

### Edge of stability

A genuinely surprising empirical finding worth knowing, because it directly contradicts the classical theory in section 6.3.

Classical theory says you need eta < 2/lambda\_max for stability. What is observed in full-batch deep learning is that the sharpness lambda\_max **rises during training until it reaches exactly 2/eta, and then hovers there**, with the loss decreasing non-monotonically rather than diverging. The optimizer sits at the edge of the stable regime instead of respecting it.

So the network appears to adapt its own curvature to the learning rate rather than the other way round, and progress continues in a regime the classical analysis forbids. This is a real and reproducible phenomenon, not fully explained, and a good example of deep learning behaving differently from the theory that motivates its tools. Mentioning it signals that you read current work.

### Mode connectivity and the lottery ticket

Two more empirical findings that shape how people think about the landscape:

- **Mode connectivity.** Two independently trained solutions can typically be joined by a curved path along which the loss stays low, even though the straight line between them passes through high loss. Minima are not isolated pits but connected regions of a larger basin. Accounting for permutation symmetry (matching the units of one network to the other) can even make the *linear* path low-loss, which suggests much of the apparent separation is symmetry rather than genuine landscape structure.
- **The lottery ticket hypothesis.** Dense networks contain sparse subnetworks that, trained from the original initialization, match the full network's performance. This says something about the interaction between initialization and the landscape, though the mechanism remains debated and the result is harder to reproduce at large scale.

### Why warmup, revisited

With the landscape picture in hand, warmup has a clearer story: early in training the sharpness is changing rapidly and the loss surface is not yet well behaved, so a large step can push the model into a region from which it does not recover. Warmup lets the curvature settle. For adaptive optimizers there is the additional mechanism from section 6.6 — the second-moment estimate is high-variance for the first few hundred steps, so the effective step size is unreliable until it warms up.

### The honest summary

What is reasonably established: critical points are mostly saddles; the Hessian has a bulk-plus-outliers spectrum; the stable learning rate is governed by the largest eigenvalue; minima found by SGD are connected in a broad basin; and gradient noise and step size jointly determine what kind of solution you land in.

What is not established: that flatness causes generalization, that SGD's implicit bias has a single clean characterization, or that any current theory predicts the right learning rate for a new architecture. **Deep learning optimization is an empirical discipline with a well-developed intuition borrowed from convex theory**, and stating that clearly is more impressive in an interview than overclaiming.

**Try it.** (a) Why does the fraction of critical points that are local minima decrease with dimension? (b) Explain why sharpness is not invariant to rescaling weights in a ReLU network. (c) What does the edge-of-stability observation say about the classical step-size bound? Answers in 6.12.

## 6.10 A practical recipe

This section is deliberately prescriptive. Interviews often ask "how would you debug a training run?", and a structured answer is worth more than a list of tricks.

### Order of operations

1. **Overfit a tiny subset first.** Take 10 examples and drive the loss to near zero. If you cannot, you have a bug — not a tuning problem. This single check catches label misalignment, broken masking, a frozen parameter group, and a severed gradient graph, and it takes two minutes.
2. **Pick the optimizer by domain.** AdamW for transformers and anything with heterogeneous gradient scales; SGD with momentum 0.9 for convolutional vision if you intend to tune carefully.
3. **Find the learning rate before anything else.** It is the hyperparameter that matters most, by a wide margin. The **learning-rate range test** is cheap and effective: run a few hundred steps with the rate rising exponentially, plot loss against rate, and choose roughly an order of magnitude below where the loss starts to diverge.
4. **Add warmup and a decay schedule.** Linear warmup over a few hundred to a few thousand steps, then cosine or linear decay to near zero. This is close to universal for transformer training.
5. **Set the batch size by hardware**, then scale the learning rate roughly linearly if you change it, re-tuning if the change is large.
6. **Add gradient clipping** at global norm 1.0. It is cheap insurance against the occasional enormous batch, and it costs nothing when nothing goes wrong.
7. **Tune weight decay last**, and exclude biases and normalization parameters from it (section 4.7 explains why they are different).

### Diagnosing from the loss curve

| Symptom | Likely cause | Action |
| --- | --- | --- |
| Loss is NaN within a few steps | learning rate far too high; overflow in an exp or a division | reduce the rate 10x; check for log-sum-exp issues; use bf16 rather than fp16 |
| Loss oscillates wildly | learning rate slightly too high, or batch too small | reduce the rate, or increase batch, or add momentum |
| Loss decreases then diverges | too high a rate combined with rising sharpness; no warmup | add warmup; decay sooner |
| Loss is flat from step 1 | no gradient reaching parameters; rate too low; dead activations | check gradient norms per parameter; check the optimizer's parameter list |
| Loss plateaus above a reasonable value | underfitting, or noise ball | bigger model or longer training; or decay the learning rate and see if it drops |
| Loss drops sharply at a scheduled decay | normal — the noise ball contracted | nothing; it confirms the schedule is doing work |
| Training loss good, validation bad | overfitting | regularization, augmentation, more data, early stopping |
| Loss spikes intermittently | a few bad batches, or fp16 instability | clip gradients; inspect the offending batches; switch to bf16 |

**The single most valuable diagnostic** is to log the **gradient norm** per parameter group alongside the loss. Zeros mean a severed graph; enormous values mean instability ahead; a sudden change tells you when things went wrong. It costs almost nothing and it converts most of the table above from guesswork into observation.

### Hyperparameter search

- **Random search beats grid search.** With d hyperparameters of which only a few matter, a grid wastes its budget on redundant values of the irrelevant ones, while random search explores more distinct values of the ones that matter. This is a direct consequence of the high-dimensional volume argument in Chapter 3.
- **Search on a log scale** for learning rate, weight decay and epsilon. These are scale parameters and the meaningful differences are multiplicative.
- **Bayesian optimization** is worth it when each run is very expensive, and not worth the complexity otherwise.
- **Report how many configurations you tried** (Chapter 4, section 4.8). The best of many noisy validation scores is optimistically biased.

### Numerical hygiene

- **Prefer bf16 to fp16** for training. It has the same exponent range as fp32, so overflow is not an issue and loss scaling is usually unnecessary. With fp16 you need loss scaling to keep small gradients from underflowing.
- **Keep a fp32 master copy of weights and optimizer state** in mixed-precision training; accumulating tiny updates in low precision loses them to rounding.
- **Never write your own softmax followed by a log.** Use the fused cross-entropy on raw logits (Chapters 1 and 2).
- **Expect non-determinism.** Floating-point addition is not associative, so results vary with thread count and hardware. This is normal.

### What to do when nothing works

In order: verify the data pipeline by inspecting actual batches; overfit 10 examples; check gradient norms; drop the learning rate by 10x and see whether the behaviour changes qualitatively; remove all regularization and confirm you can overfit; simplify the architecture until something trains; then add complexity back one piece at a time. **Almost every "the model will not train" problem is a bug, not a hyperparameter**, and the discipline of bisecting rather than tuning is what finds it.

**Try it.** (a) Your loss goes to NaN at step 300 of a transformer run. List the four things you would check, in order. (b) Why does random search beat grid search when only two of ten hyperparameters matter? (c) You cannot overfit 10 examples. Name three candidate bugs. Answers in 6.12.

## 6.11 Interview drill set

**1. What is the maximum stable learning rate for gradient descent on a quadratic?** Two over the largest Hessian eigenvalue. Beyond it the iterates oscillate with growing amplitude along the sharpest direction and the loss diverges.

**2. Why does conditioning matter?** The step size is limited by the largest curvature, but progress along the flattest direction is proportional to that same small step. The iteration count scales linearly with the condition number, and the iterates zigzag across a narrow valley.

**3. Name four things that improve conditioning.** Feature standardization, normalization layers, careful initialization, and preconditioning (Adam's per-coordinate scaling, or a proper second-order preconditioner). Momentum mitigates the symptom without changing the conditioning.

**4. Why is every local minimum global for a convex function?** The first-order condition says the tangent plane is a global underestimator: f(y) >= f(x) + grad f(x)'(y-x). If the gradient is zero at x, this reads f(y) >= f(x) for all y.

**5. Why is a deep network's loss non-convex?** Parameters enter multiplicatively across layers, and more fundamentally, permutation symmetry means every minimum has an exponentially large family of equivalent copies at different parameter points. A convex function cannot have disconnected minimizers.

**6. State the convergence rates for gradient descent.** O(1/t) for convex smooth; linear, that is O((1 - mu/L)^t), for strongly convex; and O(1/t) on the squared gradient norm for non-convex smooth, giving only a stationary point.

**7. What is the descent lemma and why does it matter?** Smoothness gives a quadratic upper bound on the loss; substituting the gradient step with eta = 1/L shows each step decreases the loss by at least the squared gradient norm over 2L. Summing that telescoping inequality gives the convergence rates.

**8. Why does momentum help?** Oscillating components cancel in the exponential average while consistent components accumulate, so it damps the zigzag and amplifies the drift along the valley. Quantitatively it replaces the condition number with its square root in the contraction factor.

**9. What is the effective step-size multiplier from momentum?** One over one minus beta. At beta = 0.9 that is 10x, which is why raising momentum without lowering the learning rate often diverges.

**10. What does Nesterov momentum change?** The gradient is evaluated at the look-ahead point where momentum is about to carry you, so the method brakes a step earlier when the loss starts rising. It attains the optimal O(1/t^2) rate for smooth convex problems.

**11. Why use SGD instead of full-batch gradient descent?** Because you only need a roughly downhill direction, and many cheap noisy steps make far more progress per unit compute than one exact step. The estimate is unbiased with variance scaling as 1/B.

**12. What is the noise ball?** With a constant learning rate, SGD does not converge to a point but to a stationary distribution whose spread scales with eta/B. Decaying the learning rate shrinks it, which is why loss curves drop sharply at a scheduled decay.

**13. Why does warmup help?** Early gradients are large and poorly aligned and the curvature is changing fast, so a full-size step can push the model somewhere it cannot recover from. For adaptive optimizers the second-moment estimate is also high-variance in the first few hundred steps.

**14. What is the linear scaling rule and where does it break?** Multiply the learning rate by k when you multiply the batch by k, preserving distance travelled per example. It breaks at very large batches, where warmup becomes necessary and where a critical batch size makes further scaling unproductive.

**15. Explain Adam in one breath.** Momentum on the gradient, an exponential moving average of the squared gradient, bias correction for both, and a step proportional to the ratio. The ratio behaves like a signal-to-noise ratio, and the per-coordinate step is bounded by roughly eta, which is why Adam is robust to learning-rate choice.

**16. Why does Adam need bias correction?** Both moving averages start at zero, so early estimates are biased low; dividing by one minus beta to the t exactly corrects it. It matters most for the second moment, where beta\_2 = 0.999 would otherwise leave the denominator far too small and the early steps far too large.

**17. What is the difference between Adam and AdamW?** Adam with an L2 term in the loss divides that term by the adaptive scaling, so parameters with large gradient history get less decay — backwards. AdamW applies the decay directly to the parameters, decoupled from the adaptive step.

**18. When would you use SGD over Adam?** Convolutional vision models, where well-tuned SGD with momentum often generalizes slightly better. Adam dominates for transformers because gradient scales across parameter groups vary by orders of magnitude.

**19. What is a preconditioner, and what is Adam's?** A matrix P applied as P inverse times the gradient, changing coordinates so the problem is better conditioned. Adam's is diagonal, built from the gradient second moment; Newton's is the Hessian; natural gradient's is the Fisher.

**20. Why not use Newton's method in deep learning?** Quadratic storage and cubic inversion at billions of parameters, an indefinite Hessian away from minima so the step can move toward saddles, and noisy minibatch curvature that inversion amplifies.

**21. Why is L-BFGS unsuitable for minibatch training?** Its curvature approximation comes from differences of successive gradients, which under minibatch sampling are dominated by noise rather than curvature. It also wants a line search, which is expensive and unreliable on a stochastic objective.

**22. State the KKT conditions.** Stationarity of the Lagrangian, primal feasibility, dual feasibility (nonnegative multipliers), and complementary slackness — each constraint is either active with a possibly positive multiplier, or slack with a zero multiplier.

**23. Why does the SVM dual give the kernel trick?** The dual depends on the data only through inner products between training points, so replacing those inner products with a kernel gives nonlinear classification without ever forming the feature map.

**24. What identifies the support vectors?** Complementary slackness: only points with active margin constraints can have nonzero multipliers, so all other training points can be removed without changing the solution.

**25. Are local minima the main problem in deep learning?** No. In high dimensions almost all critical points are saddles, since a minimum requires every eigenvalue to be positive. Saddles slow progress rather than trapping you, and momentum and noise help escape them.

**26. What does the Hessian spectrum of a trained network look like?** A large bulk near zero plus a few large outliers. Most directions are nearly flat; the outliers set the stable learning rate.

**27. What is the edge-of-stability phenomenon?** Sharpness rises during training until it reaches exactly two over the learning rate and then hovers there, with the loss still decreasing non-monotonically rather than diverging. It contradicts the naive reading of the classical stability bound and is not fully explained.

**28. Do flat minima generalize better?** It is a plausible and widely held hypothesis with supporting evidence, and SAM exploits it successfully. But naive sharpness is not reparameterization-invariant, since rescaling weights in a ReLU network changes it without changing the function, so it cannot be the complete story.

**29. How would you debug a run that will not learn?** Overfit 10 examples first. Then check gradient norms per parameter group, check the optimizer actually received the parameters, drop the learning rate tenfold, remove regularization, and simplify until something trains. Most such problems are bugs rather than hyperparameters.

**30. Why does random search beat grid search for hyperparameters?** When only a few hyperparameters matter, a grid repeats the same values of those few while varying irrelevant ones, whereas random search tries a distinct value of every hyperparameter in every run.

## 6.12 Assignment and solutions

### Solutions to the in-text exercises

**6.1.** (a) Maximum stable step is 2/100 = 0.02. With eta just under that, the flat direction contracts by |1 - 0.02(1)| = 0.98 per step, so reducing its error by a factor of e takes about 1/0.0202 ≈ 50 steps. With the optimal eta = 2/101 the contraction is (100-1)/(100+1) = 0.980, giving about the same. The point is that the sharp direction dictates the step and the flat direction pays for it. (b) A critical point is a minimum only if all d eigenvalues are positive. If eigenvalue signs behaved like independent coin flips, that probability would be 2^-d; the real distribution is not independent, but the qualitative conclusion — minima become exponentially rare relative to saddles — survives. (c) Gradient-noise variance halves, so the noise standard deviation falls by a factor of sqrt(2), about 29%. Cost per step doubles. That asymmetry is exactly why very large batches give diminishing returns.

**6.2.** (a) Convexity gives f(y) >= f(x) + grad f(x)'(y - x) for all y. With grad f(x) = 0 the inequality reads f(y) >= f(x) for every y, so x is a global minimum. (b) Let h = max(f, g). For any x, y and lambda: h(lambda x + (1-lambda)y) is either f or g evaluated there, and whichever it is, it is at most lambda f(x) + (1-lambda)f(y) or the same with g, each of which is at most lambda h(x) + (1-lambda)h(y). (c) Given any parameter setting theta achieving loss L, swapping hidden units 1 and 2 (together with their incoming and outgoing weights) gives a different point theta' computing the identical function, hence the same loss. If the loss were convex, the midpoint of theta and theta' would have loss at most L; but the set of minimizers of a convex function is convex, so a convex loss cannot have two isolated equally-good minima separated by higher loss, which is what is generically observed.

**6.3.** (a) Maximum stable eta = 2/100 = 0.02. Optimal eta = 2/(100+1) = 0.0198. Contraction factor = (100-1)/(100+1) = 0.9802, so about 50 steps per factor of e. (b) The descent lemma gives L(next) <= L - eta(1 - L eta/2)||g||^2. At eta = 1/L the bracket is 1 - 1/2 = 1/2, so the decrease is at least ||g||^2/(2L). (c) "Linear" refers to the error at step t+1 being a constant fraction of the error at step t — geometric decay, so the error falls like rho^t and the step count to reach epsilon is logarithmic in 1/epsilon. "Sublinear" O(1/t) needs 1/epsilon steps, which is vastly more. The names describe the recurrence, not the decay curve.

**6.4.** (a) Multiplier 1/(1 - 0.9) = 10. The weights beta^k fall below 1% of the leading weight after about 44 steps, so roughly the last 10 to 40 gradients matter, with the effective window about 1/(1-beta) = 10. (b) Plain GD: (400-1)/(400+1) = 0.99501, about 200 steps per factor of e. Momentum: (20-1)/(20+1) = 0.9048, about 10 steps. A twentyfold improvement, matching the sqrt(kappa) prediction. (c) At the bottom of a valley the momentum term carries you past the minimum and up the far side. Nesterov evaluates the gradient at that far-side point, where it already points backwards, so the correction is applied in the same step rather than one step later — the method decelerates as it arrives instead of after it overshoots.

**6.5.** (a) The noise-ball radius squared scales as eta/B, so increasing B eightfold shrinks it eightfold in squared terms. You should increase the learning rate — roughly eightfold under the linear scaling rule — to keep the effective noise and the distance travelled per example comparable, adding warmup if the resulting rate is large. (b) Because the plateau level is set by the noise ball, whose size scales with eta. Dropping eta by 10x contracts the ball immediately, so the iterate settles into a lower-loss region and the measured loss falls sharply before flattening again at the new level. (c) First, early gradients are large and the curvature is changing rapidly, so a full-size step risks an unrecoverable region. Second, Adam's second-moment estimate is based on very few samples in the first hundreds of steps, so the denominator is unreliable and the effective step size is badly mis-scaled without warmup.

**6.6.** (a) After one step with constant gradient g: m\_1 = 0.1g and v\_1 = 0.001 g^2. **Both are biased low, and you must account for both.** The uncorrected step is m\_1/sqrt(v\_1) = 0.1g/(0.0316|g|) = 3.16 times the sign of g, whereas the correct step for a constant gradient is exactly 1. So the uncorrected first step is about **3.2 times too large**, not 30 — the numerator's tenfold under-estimate partly cancels the denominator's thirtyfold one. Bias correction divides m by (1 - 0.9) = 0.1 and v by (1 - 0.999) = 0.001, giving m-hat = g and v-hat = g^2 and a step of exactly 1. (b) m estimates the mean of the gradient and sqrt(v) estimates its root-mean-square. If the gradient is consistent, the mean and RMS are close and the ratio approaches 1; if the gradient fluctuates around zero, the mean nearly cancels while the RMS does not, and the ratio approaches 0. So the update size reflects how reliable the direction is. (c) The L2 penalty contributes a gradient of lambda times theta, which enters the numerator and is then divided by sqrt(v). A parameter with a large historical gradient has a large denominator and therefore receives a **smaller** shrinkage, which inverts the intended uniform decay. AdamW adds the lambda-times-theta term outside the adaptive scaling, so every parameter shrinks by the same relative amount per step.

**6.7.** (a) Lagrangian x^2 + y^2 + nu(x + y - 1). Stationarity gives 2x + nu = 0 and 2y + nu = 0, so x = y, and the constraint gives x = y = 1/2 with nu = -1. The objective value is 1/2. The multiplier is the sensitivity of the optimum to the constraint: relaxing the constraint to x + y = 1 + delta changes the optimum by -nu delta = delta, and indeed the optimum (1+delta)^2/2 has derivative 1 at delta = 0. **Multipliers are shadow prices.** (b) Such a point satisfies its margin constraint strictly, so the constraint is slack; complementary slackness then forces its multiplier to zero, and since the solution is a combination of the data weighted by multipliers, the point contributes nothing. (c) The primal objective involves w, which lives in feature space and may be infinite-dimensional under a feature map. The dual eliminates w and leaves an objective depending only on inner products between training points, so you can substitute a kernel — which computes those inner products implicitly — without ever representing w or the feature map.

**6.8.** (a) SGD: P = I. Adam: P = diag(sqrt(v) + epsilon), so the step is that inverse diagonal times the momentum-averaged gradient. Newton: P = H. (b) Newton solves for a point where the gradient of the quadratic model vanishes. Along an eigendirection with negative eigenvalue lambda, the step is -g/lambda, which has the same sign as g — it moves *uphill* along that direction toward the model's stationary point. So it converges to the saddle rather than escaping it. (c) Because the secant condition infers curvature from the change in gradient between successive iterates. With different minibatches, that change reflects the difference between two random samples far more than it reflects curvature, so the inferred Hessian approximation is essentially noise.

**6.9.** (a) Because being a local minimum requires all d Hessian eigenvalues to be positive simultaneously; adding dimensions adds more conditions that must all hold, so the measure of critical points satisfying all of them shrinks rapidly. (b) In a ReLU network you can multiply one layer's weights by c > 0 and divide the next layer's by c, leaving the function exactly unchanged. The Hessian's eigenvalues are not invariant to this, so you can make the same function correspond to an arbitrarily sharp or flat parameter point. Therefore sharpness as usually measured is a property of the parameterization, not of the function. (c) It says the bound is not a hard ceiling in practice: rather than the trajectory diverging when sharpness exceeds 2/eta, the sharpness stabilizes at exactly that level and training continues non-monotonically. The classical analysis assumes fixed curvature; in a deep network the curvature responds to the optimizer.

**6.10.** (a) Whether the loss was already trending badly before the NaN (suggesting rate too high); whether it is fp16 without loss scaling (switch to bf16); whether a specific batch is responsible (log batch indices and inspect); and whether any log, division or exp can overflow, especially a hand-written softmax. (b) With ten hyperparameters and a grid of k values each, a grid tries only k distinct values of the two that matter, repeating each k^8 times. Random search with the same budget tries a distinct value of those two in every run, so it explores the relevant subspace far more finely. (c) Labels misaligned with inputs; a parameter group missing from the optimizer; the loss computed on a detached tensor; an activation or normalization saturating; or a learning rate so small nothing moves.

### Problem set

**P1 (quadratic analysis).** Let f(x) = 0.5 x'Ax with A diagonal with entries 1 and 100. (a) Write the gradient descent iteration in closed form for each coordinate. (b) Find the eta minimizing the worst-case contraction. (c) Simulate 100 steps from (1,1) at three learning rates and describe the behaviour.

**P2 (convexity).** Determine whether each is convex, with justification: (a) log-sum-exp; (b) the maximum eigenvalue of a symmetric matrix as a function of that matrix; (c) x^3 on the reals; (d) the logistic loss as a function of the weights; (e) the 0-1 loss.

**P3 (descent lemma).** Prove the descent lemma from L-smoothness, then use it to show that gradient descent on a non-convex L-smooth function drives the minimum gradient norm over t steps to zero at rate O(1/sqrt t).

**P4 (momentum).** Derive the contraction factor for heavy-ball momentum on a one-dimensional quadratic by analyzing the two-by-two iteration matrix, and find the beta minimizing the spectral radius.

**P5 (SGD noise).** For a one-dimensional quadratic with gradient noise of variance sigma^2, derive the stationary variance of the SGD iterate under a constant learning rate, and confirm it scales as eta sigma^2.

**P6 (Adam).** Work through three Adam steps by hand for a single parameter with gradients 1, 1, 1, using the default hyperparameters, with and without bias correction. Comment on the difference.

**P7 (duality).** Derive the SVM dual from the primal. Identify the KKT conditions, show that only margin points have nonzero multipliers, and point out exactly where the kernel could be substituted.

**P8 (schedules).** You have a budget of 100,000 steps. Compare constant, step-decay, and cosine schedules analytically in terms of the noise ball, and say what you would expect the loss curves to look like.

**P9 (coding).** (a) Implement gradient descent, momentum and Adam from scratch and compare them on the Rosenbrock function. (b) Reproduce the zigzag on an ill-conditioned quadratic and show momentum fixing it. (c) Run a learning-rate range test on a small network and identify the divergence point.

**P10 (synthesis).** Explain in one paragraph why these are all the same fact: feature standardization speeds up training; normalization layers help; Adam works well on transformers; momentum replaces kappa with sqrt(kappa); and the maximum learning rate is 2/lambda\_max.

### Selected solutions

**P2.** (a) Convex: its Hessian is diag(p) - pp', the softmax Jacobian, which Chapter 5 showed is a covariance matrix and therefore PSD. (b) Convex: the maximum eigenvalue is the supremum over unit vectors of x'Ax, which is a pointwise supremum of functions linear in A, and a supremum of affine functions is convex. (c) Not convex on the reals — its second derivative 6x is negative for x < 0 — though it is convex on the nonnegative half-line. (d) Convex: its Hessian is X' diag(p(1-p)) X, a congruence C'DC of a PSD diagonal matrix, hence PSD by Chapter 1. (e) Not convex, and additionally discontinuous with zero gradient almost everywhere, which is precisely why convex surrogates like hinge and cross-entropy exist.

**P3.** L-smoothness gives L(y) <= L(x) + grad L(x)'(y - x) + (L/2)||y - x||^2. Substituting y = x - eta grad L(x) gives L(next) <= L(x) - eta(1 - L eta/2)||grad L(x)||^2. With eta = 1/L the coefficient is 1/(2L). Summing from 0 to T-1 and telescoping gives (1/(2L)) times the sum of squared gradient norms <= L(theta\_0) - L(theta\_T) <= L(theta\_0) - L\*. Hence the minimum squared gradient norm over T steps is at most 2L(L(theta\_0) - L\*)/T, so the minimum gradient norm is O(1/sqrt T). Note what this does and does not give: convergence to a **stationary point**, with no claim that it is a minimum.

**P5.** With f = (a/2)x^2 and noisy gradient a x + xi, the update is x\_{t+1} = (1 - eta a)x\_t - eta xi\_t. Taking variances and using independence: V\_{t+1} = (1 - eta a)^2 V\_t + eta^2 sigma^2. At stationarity V = eta^2 sigma^2 / (1 - (1 - eta a)^2) = eta^2 sigma^2/(2 eta a - eta^2 a^2), which for small eta is approximately eta sigma^2/(2a). **The stationary variance is proportional to eta and inversely proportional to the curvature.** Two readings: halving the learning rate halves the noise ball, and flat directions (small a) have larger stationary spread than sharp ones — SGD wanders further along flat directions, which is the mechanism behind the claim that it explores flat regions.

**P6.** With g = 1 throughout: m\_1 = 0.1, v\_1 = 0.001. Uncorrected step = 0.1/sqrt(0.001) = 3.16, times eta. Corrected: m-hat = 0.1/0.1 = 1, v-hat = 0.001/0.001 = 1, step = 1, times eta. Step two: m\_2 = 0.19, v\_2 = 0.001999; uncorrected 0.19/0.0447 = 4.25; corrected m-hat = 0.19/0.19 = 1, v-hat = 1, step = 1. **With bias correction the step is exactly eta from the first iteration, as it should be for a constant gradient; without it the step is wrong by a factor of three or more early on, and in the wrong direction of error — too large.** This is precisely why bias correction exists and why its absence would make warmup even more essential.

**P10.** All five are consequences of **the loss surface being locally a quadratic whose Hessian eigenvalue spread determines both the maximum stable step and the rate of progress**. The maximum learning rate is 2/lambda\_max because that is the stability threshold along the sharpest eigendirection. Since progress along the flattest direction is proportional to eta lambda\_min, the iteration count scales with kappa = lambda\_max/lambda\_min. Feature standardization makes X'X — which *is* the Hessian for least squares — closer to a multiple of the identity, shrinking kappa directly. Normalization layers do the analogous thing for the effective curvature of intermediate layers, keeping activation scales comparable so no direction becomes pathologically sharp. Adam applies a diagonal preconditioner that removes per-coordinate scale mismatch, which is exactly the component of kappa that a diagonal correction can fix, and transformers need this because their parameter groups differ in gradient scale by orders of magnitude. And momentum attacks the same quantity from the algorithmic side, replacing kappa by its square root in the contraction factor without changing the problem at all. One eigenvalue ratio, five interventions.

**P1.** Quadratic with A = diag(1, 100). (a) The gradient is (x\_1, 100 x\_2), so the update decouples: x\_1 gets multiplied by (1 - eta) and x\_2 by (1 - 100 eta) each step. Closed form: x\_1(t) = (1-eta)^t x\_1(0) and x\_2(t) = (1-100eta)^t x\_2(0). (b) The worst-case contraction is max(|1-eta|, |1-100eta|), minimized where the two are equal and opposite: 1 - eta = 100eta - 1, giving eta = 2/101 = 0.0198 and a contraction factor of 99/101 = 0.9802. (c) At eta = 0.0198 (optimal) you see slow, smooth convergence dominated by the x\_1 direction, with x\_2 oscillating in sign but shrinking. At eta = 0.005 (too small) both directions converge monotonically but x\_1 barely moves — after 100 steps it has shrunk only to 0.61. At eta = 0.021 (just above 2/100 = 0.02) the x\_2 component grows by a factor of 1.1 per step and the iterate diverges within 100 steps, while x\_1 is still converging happily. **That last case is the one to internalize: divergence in one direction while another is still making progress, which is exactly what an ill-conditioned problem looks like from the inside.**

**P4.** Heavy-ball on a one-dimensional quadratic f(x) = (a/2)x^2. The iteration is v\_{t+1} = beta v\_t + a x\_t and x\_{t+1} = x\_t - eta v\_{t+1}. Write the state (x\_t, v\_t) and the update is linear, with matrix

$$
M = \begin{bmatrix} 1 - \eta a & -\eta\beta \\ a & \beta \end{bmatrix}
$$

Convergence rate is governed by the spectral radius of M. Its characteristic polynomial is lambda^2 - (1 + beta - eta a)lambda + beta = 0. The product of the roots is beta, so when the roots are complex (the useful regime) each has modulus sqrt(beta), and **the contraction rate is sqrt(beta) independent of a**. The roots become complex when the discriminant is negative, that is when (1 + beta - eta a)^2 < 4 beta. Requiring this to hold for every eigenvalue a in \[mu, L\] and choosing beta as small as possible gives beta = ((sqrt(L) - sqrt(mu))/(sqrt(L) + sqrt(mu)))^2, whose square root is the advertised (sqrt(kappa)-1)/(sqrt(kappa)+1). **That is where the square root on the condition number comes from: a two-term recurrence has a characteristic polynomial of degree two, and complex roots of a quadratic with product beta both have modulus sqrt(beta).**

**P7.** Deriving the SVM dual. Primal: minimize 0.5||w||^2 subject to y\_i(w'x\_i + b) >= 1 for all i. Lagrangian:

$$
\mathcal{L} = \tfrac{1}{2}\lVert w\rVert^2 - \sum_i \alpha_i\big[y_i(w^{\top}x_i + b) - 1\big], \qquad \alpha_i \ge 0
$$

Stationarity in w gives w = sum of alpha\_i y\_i x\_i; stationarity in b gives sum of alpha\_i y\_i = 0. Substituting both back eliminates w and b entirely and gives the dual:

$$
\max_{\alpha \ge 0} \; \sum_i \alpha_i - \tfrac{1}{2}\sum_{i,j}\alpha_i\alpha_j y_i y_j\,(x_i^{\top}x_j) \quad \text{s.t.}\quad \sum_i \alpha_i y_i = 0
$$

KKT: stationarity (above), primal feasibility (the margin constraints), dual feasibility (alpha >= 0), and complementary slackness alpha\_i\[y\_i(w'x\_i + b) - 1\] = 0. **Complementary slackness is what creates sparsity**: if a point is strictly inside its margin the bracket is positive, forcing alpha\_i = 0, so it contributes nothing to w. Only points exactly on the margin can have alpha\_i > 0 — the support vectors. **The kernel goes exactly where x\_i'x\_j appears**, and nowhere else; that inner product is the only way the data enters, so replacing it with K(x\_i, x\_j) gives nonlinear classification with no other change.

**P8.** Schedules under a 100,000-step budget, analyzed through the noise ball. **Constant eta**: the loss falls until it reaches the noise-ball floor set by eta and B, then plateaus and stays there for the remaining steps — you waste most of the budget bouncing. **Step decay** (say 10x drops at 50k and 80k): a plateau, then a sharp drop as the ball contracts, then a new plateau, then another drop — the characteristic staircase. Each drop is real progress, but between drops you are again idling at the new floor. **Cosine**: eta decreases smoothly throughout, so the noise-ball radius contracts continuously and the loss decreases continuously, never sitting at a floor. Expect cosine to reach the lowest final loss of the three, with step decay close behind and constant clearly worst. The theoretical reason is that the stationary variance scales with eta (Chapter 6, P5), so a schedule that drives eta to zero drives the variance to zero, while one that does not leaves an irreducible noise floor.

**P9 (coding).** Expected observations. (a) On Rosenbrock from (-1.2, 1): plain gradient descent zigzags along the curved valley floor and needs thousands of iterations; momentum follows the valley much more directly and converges several times faster; Adam is fast initially but can overshoot near the minimum unless the learning rate is annealed — a good illustration that adaptivity helps most when the scales differ and least when the difficulty is curvature of the valley itself. (b) On a quadratic with eigenvalues (1, 100), plot the iterate path in 2D: gradient descent produces the classic zigzag between the steep walls, momentum produces a visibly smoother arc. Overlay both and the picture makes the sqrt(kappa) result intuitive. (c) The learning-rate range test shows loss roughly flat at very small rates, then falling steeply, reaching a minimum, then rising sharply and going to NaN. The recommended rate is roughly an order of magnitude below the divergence point, near the steepest part of the descent, not at the minimum of the curve.
