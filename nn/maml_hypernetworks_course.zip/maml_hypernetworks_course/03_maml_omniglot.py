# %% [markdown]
# # Project 2 - Few-shot Omniglot classification with MAML (CPU edition)
#
# 5-way 1-shot: each task shows ONE image of each of 5 new characters, then asks
# the model to classify new drawings of those characters.
# Also trains two strong baselines on the SAME test tasks:
#   - Prototypical Networks (metric-based meta-learning, Snell et al. 2017)
#   - Pre-trained embedding + nearest-centroid classifier (transfer learning)
#
# Run: `python 03_maml_omniglot.py`           (about 35 min on one CPU core)
#      `QUICK=1 python 03_maml_omniglot.py`   (smoke test, about 3 min incl. download)
# The first run downloads Omniglot (~9 MB) with torchvision and caches a 28x28 tensor.

# %%
import os, time, math, random
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.func import functional_call

QUICK = os.environ.get("QUICK") == "1"
os.makedirs("outputs", exist_ok=True)
os.makedirs("data", exist_ok=True)
torch.manual_seed(0)

CFG = dict(
    n_way=5, k_shot=1,
    q_train=5,          # query images per class while meta-training (smaller = faster)
    q_test=15,          # query images per class at evaluation (standard: 15)
    meta_batch=8,       # tasks per outer step (paper: 32; 8 keeps CPU time low)
    inner_lr=0.4,       # alpha (paper, Omniglot 5-way: 0.4)
    inner_steps_train=1,
    inner_steps_test=3, # paper evaluates with 3 steps
    outer_lr=1e-3,
    hidden=32,          # conv channels (paper: 64); 32 keeps CPU time reasonable
    first_order=False,
    iters=200 if QUICK else 3000,
    eval_every=100 if QUICK else 500,
    eval_tasks=100 if QUICK else 600,
)
print(CFG)

# %% [markdown]
# ## Step 1 - Load Omniglot into memory as a (classes, 20, 1, 28, 28) tensor

# %%
def load_split(background: bool):
    cache = f"data/omniglot_{'bg' if background else 'eval'}_28.pt"
    if os.path.exists(cache):
        return torch.load(cache)
    from torchvision.datasets import Omniglot
    from torchvision import transforms as T
    tf = T.Compose([T.Resize(28, antialias=True), T.ToTensor()])
    ds = Omniglot("data", background=background, download=True, transform=tf)
    by_class = {}
    for img, label in ds:                      # img: (1, 28, 28), strokes dark on white
        by_class.setdefault(label, []).append(1.0 - img)   # invert: strokes = 1
    data = torch.stack([torch.stack(by_class[c][:20]) for c in sorted(by_class)])
    torch.save(data, cache)
    return data

t0 = time.time()
bg = load_split(True)      # 964 characters, 30 alphabets ("background" set)
ev = load_split(False)     # 659 characters, 20 other alphabets ("evaluation" set)
print(f"background {tuple(bg.shape)}, evaluation {tuple(ev.shape)}  ({time.time()-t0:.0f}s)")

# Alphabet-disjoint class splits (NOTE: the MAML paper used a different split,
# 1,200 training characters drawn from all alphabets; see the course doc).
train_data = bg[:-100]     # 864 characters for meta-training
val_data = bg[-100:]       # 100 held-out characters for validation
test_data = ev             # 659 characters for the final test

# %% [markdown]
# ## Step 2 - The episode sampler
# Every call takes its OWN random generators (rng, gen). Never reseed the global
# RNG inside evaluation code: an earlier version of this course did, and every
# validation call silently made training replay the same tasks.

# %%
def sample_tasks(data, n_tasks, n_way, k_shot, q, rng, gen, augment=False):
    """Returns xs (T, N*K, 1, 28, 28), ys (T, N*K), xq (T, N*Q, ...), yq (T, N*Q)."""
    C, S = data.shape[:2]
    xs, ys, xq, yq = [], [], [], []
    for _ in range(n_tasks):
        # >>> SOLUTION: pick n_way classes, k_shot + q images each, labels 0..n_way-1 per episode
        classes = rng.sample(range(C), n_way)
        s_imgs, q_imgs = [], []
        for label, c in enumerate(classes):        # label = position: shuffled per episode
            idx = torch.randperm(S, generator=gen)[: k_shot + q]
            imgs = data[c, idx]
            if augment:                            # rotated characters act as new classes
                imgs = torch.rot90(imgs, k=rng.randint(0, 3), dims=(2, 3))
            s_imgs.append(imgs[:k_shot]); q_imgs.append(imgs[k_shot:])
        xs.append(torch.cat(s_imgs)); xq.append(torch.cat(q_imgs))
        ys.append(torch.arange(n_way).repeat_interleave(k_shot))
        yq.append(torch.arange(n_way).repeat_interleave(q))
        # <<< SOLUTION
    return torch.stack(xs), torch.stack(ys), torch.stack(xq), torch.stack(yq)

# Check: shapes, labels, and that the sampler does not touch the global RNG.
state = random.getstate()
xs, ys, xq, yq = sample_tasks(train_data, 2, 5, 1, 15, random.Random(0), torch.Generator().manual_seed(0))
assert xs.shape == (2, 5, 1, 28, 28) and xq.shape == (2, 75, 1, 28, 28)
assert ys[0].tolist() == [0, 1, 2, 3, 4] and yq.shape == (2, 75)
assert random.getstate() == state, "sample_tasks must not use the global random module"
print("sampler check passed")

# %% [markdown]
# ## Step 3 - The 4-layer convolutional network used throughout few-shot learning
# BatchNorm uses track_running_stats=False: statistics always come from the
# current batch (transductive, like the original MAML code). This also makes
# the module purely functional (no buffers to update).
# (The MAML paper used strided convolutions for Omniglot; max-pooling is the
# more common modern choice.)

# %%
def conv_block(cin, cout):
    return nn.Sequential(nn.Conv2d(cin, cout, 3, padding=1),
                         nn.BatchNorm2d(cout, track_running_stats=False),
                         nn.ReLU(), nn.MaxPool2d(2))

def make_net(n_out=CFG["n_way"], hidden=CFG["hidden"]):
    return nn.Sequential(conv_block(1, hidden), conv_block(hidden, hidden),
                         conv_block(hidden, hidden), conv_block(hidden, hidden),
                         nn.Flatten(), nn.Linear(hidden, n_out))   # 28->14->7->3->1

def embed(net, x):
    return net[:5](x)          # everything except the final linear layer: (B, hidden)

net = make_net()
print("parameters:", sum(p.numel() for p in net.parameters()))

# %% [markdown]
# ## Step 4 - MAML outer loss (one task at a time)
# On a CPU, a plain loop over tasks is faster than torch.func.vmap for
# convolutions (vmap turns per-task conv weights into grouped convolutions).
# `inner_keys` chooses which parameters adapt in the inner loop
# (all of them = MAML; only the head = ANIL).

# %%
def maml_outer(net, xs, ys, xq, yq, lr, steps, first_order, inner_keys=None, params=None):
    params = params if params is not None else dict(net.named_parameters())
    inner_keys = inner_keys or list(params)
    losses, accs = [], []
    for i in range(xs.shape[0]):
        # >>> SOLUTION: adapt `fast` on the support set, then score the query set
        fast = {k: params[k] for k in inner_keys}                 # adapted in the inner loop
        slow = {k: v for k, v in params.items() if k not in inner_keys}
        for _ in range(steps):
            logits = functional_call(net, {**slow, **fast}, (xs[i],))
            loss = F.cross_entropy(logits, ys[i])
            grads = torch.autograd.grad(loss, list(fast.values()), create_graph=not first_order)
            fast = {k: v - lr * g for (k, v), g in zip(fast.items(), grads)}
        logits = functional_call(net, {**slow, **fast}, (xq[i],))
        # <<< SOLUTION
        losses.append(F.cross_entropy(logits, yq[i]))
        accs.append((logits.argmax(-1) == yq[i]).float().mean().detach())
    return torch.stack(losses).mean(), torch.stack(accs)

# Check: one inner step must change the query loss, and the meta-gradient must reach every layer.
_net = make_net(); _b = sample_tasks(train_data, 2, 5, 1, 5, random.Random(1), torch.Generator().manual_seed(1))
l0, _ = maml_outer(_net, *_b, 0.4, 0, False)
l1, _ = maml_outer(_net, *_b, 0.4, 1, False)
l1.backward()
assert not torch.isclose(l0, l1), "the inner step had no effect"
assert all(p.grad is not None and p.grad.abs().sum() > 0 for p in _net.parameters())
print("MAML outer-loss check passed")

# %% [markdown]
# ## Step 5 - Evaluation: mean accuracy and 95% confidence interval on new tasks
# Every method is scored on exactly the same seeded tasks.

# %%
def test_tasks(data, n_tasks, k_shot, seed):
    rng, gen = random.Random(seed), torch.Generator().manual_seed(seed)
    return [sample_tasks(data, min(20, n_tasks - s), CFG["n_way"], k_shot, CFG["q_test"], rng, gen)
            for s in range(0, n_tasks, 20)]

def summarize(accs):
    accs = torch.cat(accs)
    return accs.mean().item(), 1.96 * accs.std().item() / math.sqrt(len(accs))

def evaluate_maml(net, data, n_tasks, k_shot=CFG["k_shot"], steps=CFG["inner_steps_test"], inner_keys=None, seed=0):
    frozen = {k: v.detach().requires_grad_() for k, v in net.named_parameters()}  # cut the outer graph
    accs = [maml_outer(net, *b, CFG["inner_lr"], steps, True, inner_keys, params=frozen)[1]
            for b in test_tasks(data, n_tasks, k_shot, seed)]
    return summarize(accs)

# %% [markdown]
# ## Step 6 - Meta-training loop (MAML or ANIL)

# %%
def meta_train(cfg=CFG, inner_keys=None, tag="MAML", seed=0):
    torch.manual_seed(seed)
    rng, gen = random.Random(seed), torch.Generator().manual_seed(seed)   # training's own RNG
    net = make_net()
    opt = torch.optim.Adam(net.parameters(), lr=cfg["outer_lr"])
    best, best_state, t0 = -1, None, time.time()
    for it in range(1, cfg["iters"] + 1):
        xs, ys, xq, yq = sample_tasks(train_data, cfg["meta_batch"], cfg["n_way"],
                                      cfg["k_shot"], cfg["q_train"], rng, gen, augment=True)
        loss, acc = maml_outer(net, xs, ys, xq, yq, cfg["inner_lr"],
                               cfg["inner_steps_train"], cfg["first_order"], inner_keys)
        opt.zero_grad(); loss.backward(); opt.step()
        if it % cfg["eval_every"] == 0:
            va, _ = evaluate_maml(net, val_data, 200, inner_keys=inner_keys, seed=1)
            if va > best:
                best, best_state = va, {k: v.detach().clone() for k, v in net.state_dict().items()}
            print(f"[{tag}] iter {it:5d}  train-query acc {acc.mean():.3f}  val acc {va:.3f}  ({time.time()-t0:.0f}s)")
    net.load_state_dict(best_state)          # keep the checkpoint with the best validation accuracy
    return net

maml_net = meta_train()

# %% [markdown]
# ## Step 7 - Final test on 659 never-seen characters from 20 never-seen alphabets

# %%
results = {}
results["MAML 1-shot"] = evaluate_maml(maml_net, test_data, CFG["eval_tasks"], k_shot=1)
results["MAML 5-shot"] = evaluate_maml(maml_net, test_data, CFG["eval_tasks"], k_shot=5)
results["MAML 0 steps"] = evaluate_maml(maml_net, test_data, CFG["eval_tasks"], k_shot=1, steps=0)
for k, (a, c) in results.items():
    print(f"{k:14s} {100*a:5.1f}% +/- {100*c:.1f}")

# %% [markdown]
# ## Step 8 - Baseline A: Prototypical Networks
# Embed support and query images; each class prototype is the mean of its support
# embeddings; classify a query by (negative squared) distance to each prototype.
# No inner loop and no second derivatives: training is plain backpropagation.

# %%
def proto_logits(net, xs, ys, xq, n_way):
    # >>> SOLUTION: prototypes = class means of support embeddings; logits = -squared distance
    z = embed(net, torch.cat([xs, xq]))                    # one batch: same BN statistics
    zs, zq = z[: len(xs)], z[len(xs):]
    protos = torch.stack([zs[ys == c].mean(0) for c in range(n_way)])
    return -torch.cdist(zq, protos) ** 2
    # <<< SOLUTION

def train_protonet(cfg=CFG, seed=0):
    torch.manual_seed(seed)
    rng, gen = random.Random(seed), torch.Generator().manual_seed(seed)
    net = make_net(); opt = torch.optim.Adam(net.parameters(), lr=1e-3); t0 = time.time()
    for it in range(1, cfg["iters"] + 1):
        xs, ys, xq, yq = sample_tasks(train_data, cfg["meta_batch"], cfg["n_way"], cfg["k_shot"],
                                      cfg["q_train"], rng, gen, augment=True)
        loss = torch.stack([F.cross_entropy(proto_logits(net, xs[i], ys[i], xq[i], cfg["n_way"]), yq[i])
                            for i in range(len(xs))]).mean()
        opt.zero_grad(); loss.backward(); opt.step()
    print(f"[ProtoNet] trained {cfg['iters']} iterations ({time.time()-t0:.0f}s)")
    return net

@torch.no_grad()
def evaluate_proto(net, data, n_tasks, k_shot, seed=0, normalize=False):
    accs = []
    for xs, ys, xq, yq in test_tasks(data, n_tasks, k_shot, seed):
        for i in range(len(xs)):
            z = embed(net, torch.cat([xs[i], xq[i]]))
            if normalize:
                z = F.normalize(z, dim=-1)
            zs, zq = z[: len(xs[i])], z[len(xs[i]):]
            protos = torch.stack([zs[ys[i] == c].mean(0) for c in range(CFG["n_way"])])
            pred = (-torch.cdist(zq, protos)).argmax(-1)
            accs.append((pred == yq[i]).float().mean().view(1))
    return summarize(accs)

proto_net = train_protonet()
results["ProtoNet 1-shot"] = evaluate_proto(proto_net, test_data, CFG["eval_tasks"], 1)
results["ProtoNet 5-shot"] = evaluate_proto(proto_net, test_data, CFG["eval_tasks"], 5)

# %% [markdown]
# ## Step 9 - Baseline B: pre-trained embedding + nearest-centroid classifier
# Ordinary classification over all 864 training characters, no episodes at all.
# At test time, drop the 864-way head and classify by the nearest class mean of
# L2-normalised features (a simple variant of the baselines of Chen et al. 2019
# and Tian et al. 2020).

# %%
def pretrain(epochs=1 if QUICK else 6, seed=0):
    torch.manual_seed(seed)
    C = train_data.shape[0]
    x = train_data.reshape(-1, 1, 28, 28); y = torch.arange(C).repeat_interleave(20)
    net = make_net(n_out=C); opt = torch.optim.Adam(net.parameters(), lr=1e-3); t0 = time.time()
    g = torch.Generator().manual_seed(seed)
    for ep in range(epochs):
        perm = torch.randperm(len(x), generator=g)
        for s in range(0, len(x), 128):
            b = perm[s:s + 128]
            loss = F.cross_entropy(net(x[b]), y[b])
            opt.zero_grad(); loss.backward(); opt.step()
    print(f"[Pretrained] {epochs} epochs over {len(x)} images ({time.time()-t0:.0f}s)")
    return net

pre_net = pretrain()
results["Pretrained 1-shot"] = evaluate_proto(pre_net, test_data, CFG["eval_tasks"], 1, normalize=True)
results["Pretrained 5-shot"] = evaluate_proto(pre_net, test_data, CFG["eval_tasks"], 5, normalize=True)

print(f"\nAll methods, same {CFG['eval_tasks']} test tasks (5-way, 15 queries per class):")
for k, (a, c) in results.items():
    print(f"  {k:18s} {100*a:5.1f}% +/- {100*c:.1f}")

# %% [markdown]
# ## Exercise solutions

# %%
# Ex P2.1 - Accuracy as a function of test-time inner steps.
for s in (0, 1, 3, 5, 10):
    a, c = evaluate_maml(maml_net, test_data, 200 if not QUICK else 40, steps=s)
    print(f"Ex P2.1  {s:2d} inner steps at test: {100*a:.1f}% +/- {100*c:.1f}")

# Ex P2.2 - A random, un-meta-trained network adapted with the same 3 steps.
torch.manual_seed(123)
a, c = evaluate_maml(make_net(), test_data, 200 if not QUICK else 40)
print(f"Ex P2.2  random init + 3 steps: {100*a:.1f}% +/- {100*c:.1f}")

# Ex P2.3 - ANIL: adapt only the final linear layer, SAME training budget as MAML.
head = ["5.weight", "5.bias"]
t0 = time.time()
anil_net = meta_train(inner_keys=head, tag="ANIL")
a, c = evaluate_maml(anil_net, test_data, CFG["eval_tasks"], inner_keys=head)
print(f"Ex P2.3  ANIL 5-way 1-shot: {100*a:.1f}% +/- {100*c:.1f}  ({time.time()-t0:.0f}s incl. validation)")
