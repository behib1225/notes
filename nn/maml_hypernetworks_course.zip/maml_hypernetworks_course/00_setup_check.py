# %% [markdown]
# # 00 - Setup check
# Run: `python 00_setup_check.py`. Every line should end in OK.

# %%
import sys
import platform

print(f"Python      {sys.version.split()[0]}  ({platform.system()})")
assert sys.version_info >= (3, 11), "Use Python 3.11 or newer: PyTorch 2.15 (October 2026) has no Python 3.10 wheels."

import torch
import numpy as np
import matplotlib

print(f"PyTorch     {torch.__version__}")
print(f"NumPy       {np.__version__}")
print(f"Matplotlib  {matplotlib.__version__}")
try:
    import torchvision
    print(f"torchvision {torchvision.__version__}")
except ImportError:
    print("torchvision missing: needed only for Project 2 (Omniglot).")

# %% torch.func is available (PyTorch >= 2.0)
from torch.func import functional_call, grad, vmap

model = torch.nn.Linear(3, 1)
params = {k: v.detach().clone() for k, v in model.named_parameters()}
out = functional_call(model, params, (torch.ones(2, 3),))
assert out.shape == (2, 1)
print("torch.func.functional_call ... OK")

# %% Second-order gradients: d/dw (d/dw w^3) = 6w
w = torch.tensor(2.0, requires_grad=True)
(g,) = torch.autograd.grad(w ** 3, w, create_graph=True)   # 3w^2 = 12
(gg,) = torch.autograd.grad(g, w)                          # 6w = 12
assert torch.isclose(g, torch.tensor(12.0)) and torch.isclose(gg, torch.tensor(12.0))
print("second-order autograd ........ OK")

print(f"CPU threads used by PyTorch: {torch.get_num_threads()}")
print("All checks passed. You are ready.")
