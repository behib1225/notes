# %% [markdown]
# # Project 3 - Building HyperNetworks
#
# Part A: a STATIC hypernetwork (Ha, Dai & Le, 2016) that generates every hidden
#         layer of a deep MLP from small layer embeddings -> fewer trainable numbers.
# Part B: a TASK-CONDITIONED hypernetwork that maps a task description
#         (amplitude, phase) to all weights of a sine-regression network.
# Part C: why hypernetwork initialisation matters, and a variance-matched fix
#         in the spirit of Chang, Flokas & Lipson (ICLR 2020).
#
# Run: `python 04_hypernetworks.py`  (about 3 min on one CPU core)
#      `QUICK=1 python 04_hypernetworks.py`

# %%
import os, math, time
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.func import functional_call, vmap
import sys
import matplotlib
if "ipykernel" not in sys.modules:
    matplotlib.use("Agg")   # script: save figures to files; notebook: also show them inline
import matplotlib.pyplot as plt

QUICK = os.environ.get("QUICK") == "1"
os.makedirs("outputs", exist_ok=True)
torch.manual_seed(0)

def n_params(m):
    return sum(p.numel() for p in m.parameters() if p.requires_grad)

# %% [markdown]
# ## Part A - Static hypernetwork on the two-spirals problem
# ### Step A1 - Data: two interleaved spirals (hard for shallow nets)

# %%
def two_spirals(n, noise=0.15, seed=0):
    g = torch.Generator().manual_seed(seed)
    t = torch.sqrt(torch.rand(n, generator=g)) * 3 * math.pi
    x1 = torch.stack([t * torch.cos(t), t * torch.sin(t)], 1)
    x = torch.cat([x1, -x1]) / (3 * math.pi) + noise * torch.randn(2 * n, 2, generator=g) / 3
    y = torch.cat([torch.zeros(n), torch.ones(n)])
    return x, y

x_tr, y_tr = two_spirals(1000, seed=0)
x_te, y_te = two_spirals(1000, seed=1)

# %% [markdown]
# ### Step A2 - The ordinary ("direct") network: 2 -> 64 -> 8 residual [64x64] blocks -> 1
# Residual connections (h = h + relu(W h + b)) keep the signal alive through
# 8 layers. Without them the hypernetwork version gets stuck at chance (Ex P3.4).

# %%
WIDTH, DEPTH = 64, 8

class DirectMLP(nn.Module):
    def __init__(self, width=WIDTH):
        super().__init__()
        self.inp = nn.Linear(2, width)
        self.hidden = nn.ModuleList([nn.Linear(width, width) for _ in range(DEPTH)])
        self.out = nn.Linear(width, 1)

    def forward(self, x):
        h = F.relu(self.inp(x))
        for layer in self.hidden:
            h = h + F.relu(layer(h))          # residual block
        return self.out(h).squeeze(-1)

# %% [markdown]
# ### Step A3 - The static hypernetwork version
# Each hidden weight matrix W_l (64 x 64) is built row by row. Row r of layer l
# is generated from its own small embedding z_{l,r} (dimension 4) by ONE shared
# generator g: R^4 -> R^64. Only the embeddings and g are trained; the 64x64
# matrices are outputs, not parameters. (Ha et al. generate conv kernels from
# per-layer embeddings with a shared two-layer generator in the same way.)

# %%
class StaticHyperMLP(nn.Module):
    def __init__(self, z_dim=4, gen_hidden=32):
        super().__init__()
        self.inp = nn.Linear(2, WIDTH)
        self.out = nn.Linear(WIDTH, 1)
        self.z = nn.Parameter(torch.randn(DEPTH, WIDTH, z_dim))          # embeddings
        self.hidden_bias = nn.Parameter(torch.zeros(DEPTH, WIDTH))
        self.gen = nn.Sequential(nn.Linear(z_dim, gen_hidden), nn.ReLU(),
                                 nn.Linear(gen_hidden, WIDTH))          # shared generator
        with torch.no_grad():                                           # see Part C
            self.gen[2].bias.zero_()
            self.gen[2].weight.mul_(math.sqrt(2.0 / WIDTH) / self._gen_std())

    def _gen_std(self):
        return self.gen(self.z).std()

    def weights(self):
        return self.gen(self.z)                       # (DEPTH, 64 rows, 64 cols)

    def forward(self, x):
        # TODO: generate the 8 hidden matrices, then run the same residual MLP as DirectMLP
        raise NotImplementedError("TODO: generate the 8 hidden matrices, then run the same residual MLP as DirectMLP")

# Check: the hypernetwork version has exactly 5,089 trainable numbers and the right output shape.
assert n_params(StaticHyperMLP()) == 5089, n_params(StaticHyperMLP())
assert StaticHyperMLP()(x_tr[:7]).shape == (7,)
print("static hypernetwork check passed")

# %% [markdown]
# ### Step A4 - Train both and compare

# %%
def train_classifier(model, steps=500 if QUICK else 3000, lr=1e-3, clip=1.0):
    opt = torch.optim.Adam(model.parameters(), lr=lr)
    for s in range(steps):
        loss = F.binary_cross_entropy_with_logits(model(x_tr), y_tr)
        opt.zero_grad(); loss.backward()
        if clip is not None:
            # Without clipping, the hypernetwork's loss spikes and can collapse to
            # chance late in training (Ex P3.4). Both models get the same clipping.
            torch.nn.utils.clip_grad_norm_(model.parameters(), clip)
        opt.step()
    with torch.no_grad():
        acc = ((model(x_te) > 0).float() == y_te).float().mean().item()
    return loss.item(), acc

# Three models, three seeds each. The SIZE-MATCHED direct network (width 22,
# 4,137 parameters) is the comparison that matters: a compression claim means
# nothing unless an ordinary network of similar size does worse.
SEEDS_A = [0] if QUICK else [0, 1, 2]
models_A = {
    "direct, width 64": lambda: DirectMLP(64),
    "direct, width 22 (size-matched)": lambda: DirectMLP(22),
    "static hypernet": lambda: StaticHyperMLP(),
}
results_A = {}
for name, make in models_A.items():
    accs = []
    for seed in SEEDS_A:
        torch.manual_seed(seed); m = make()
        _, acc = train_classifier(m)
        accs.append(acc)
    results_A[name] = accs
    t = torch.tensor(accs)
    print(f"{name:32s} params={n_params(m):6d}  test acc {100*t.mean():.2f}% "
          f"(min {100*t.min():.2f}, max {100*t.max():.2f}, seeds={len(accs)})")

# %% [markdown]
# ## Part B - Task-conditioned hypernetwork for sine regression
# ### Step B1 - Target network and its parameter "shapes"

# %%
target = nn.Sequential(nn.Linear(1, 40), nn.ReLU(), nn.Linear(40, 40), nn.ReLU(), nn.Linear(40, 1))
shapes = {k: v.shape for k, v in target.named_parameters()}
sizes = {k: v.numel() for k, v in target.named_parameters()}
fan_in = {k: (v.shape[1] if v.dim() == 2 else shapes[k.replace("bias", "weight")][1]) for k, v in target.named_parameters()}
N_TARGET = sum(sizes.values())
print("target network parameters to generate:", N_TARGET)   # 1761

def unflatten(flat):
    """flat: (P,) -> dict of tensors with the target's shapes (works inside vmap)."""
    # TODO: cut the flat vector into consecutive slices, one per parameter, and reshape
    raise NotImplementedError("TODO: cut the flat vector into consecutive slices, one per parameter, and reshape")

# Check: flattening the target's own weights and unflattening them reproduces the target.
_flat = torch.cat([v.detach().flatten() for v in target.parameters()])
_x = torch.randn(5, 1)
assert torch.allclose(functional_call(target, unflatten(_flat), (_x,)), target(_x))
print("unflatten check passed")

def target_forward(flat_w, x):
    return functional_call(target, unflatten(flat_w), (x,))

batched_forward = vmap(target_forward)       # different weights for every task in the batch

# %% [markdown]
# ### Step B2 - The hypernetwork: descriptor (A, sin phase, cos phase) -> 1761 weights

# %%
def describe(a, p):
    return torch.stack([a / 5.0, torch.sin(p), torch.cos(p)], -1)   # scaled, smooth in phase

class TaskHyperNet(nn.Module):
    def __init__(self, d_in=3, hidden=128, init="variance_matched"):
        super().__init__()
        self.body = nn.Sequential(nn.Linear(d_in, hidden), nn.ReLU(),
                                  nn.Linear(hidden, hidden), nn.ReLU())
        self.head = nn.Linear(hidden, N_TARGET)
        if init == "variance_matched":
            self.variance_matched_init(hidden)

    @torch.no_grad()
    def variance_matched_init(self, hidden):
        # Goal: at initialisation, each generated weight has the variance a good
        # direct init would give it (He: 2/fan_in for ReLU layers, 1/fan_in for the
        # output layer), and generated biases start at zero.
        a = torch.rand(4096) * 4.9 + 0.1; p = torch.rand(4096) * math.pi
        h = self.body(describe(a, p))
        h2 = (h ** 2).mean().item()                 # E[h_k^2] of the head's input
        i = 0
        for k in shapes:
            rows = slice(i, i + sizes[k]); i += sizes[k]
            if k.endswith("bias"):
                self.head.weight[rows].zero_()
            else:
                gain = 1.0 if k.startswith("4.") else 2.0
                std = math.sqrt(gain / fan_in[k] / (hidden * h2))
                self.head.weight[rows].normal_(0, std)
        self.head.bias.zero_()

    def forward(self, desc):
        return self.head(self.body(desc))           # (T, 1761)

# %% [markdown]
# ### Step B3 - Train: sample tasks, generate weights, regress the sine

# %%
def sample(n, k, amp=(0.1, 5.0), gen=None):
    a = torch.empty(n).uniform_(*amp, generator=gen); p = torch.empty(n).uniform_(0, math.pi, generator=gen)
    x = torch.empty(n, k, 1).uniform_(-5, 5, generator=gen)
    return a, p, x, a.view(-1, 1, 1) * torch.sin(x - p.view(-1, 1, 1))

def train_task_hyper(init, steps=1000 if QUICK else 6000, seed=0):
    torch.manual_seed(seed)
    hn = TaskHyperNet(init=init)
    opt = torch.optim.Adam(hn.parameters(), lr=1e-3)
    curve = []
    for s in range(steps):
        a, p, x, y = sample(32, 20)
        pred = batched_forward(hn(describe(a, p)), x)
        loss = F.mse_loss(pred, y)
        opt.zero_grad(); loss.backward(); opt.step()
        curve.append(loss.item())
    return hn, curve

@torch.no_grad()
def test_task_hyper(hn, amp=(0.1, 5.0)):
    g = torch.Generator().manual_seed(2026)
    a, p, x, y = sample(500, 100, amp, gen=g)
    return F.mse_loss(batched_forward(hn(describe(a, p)), x), y).item()

SEEDS_B = [0] if QUICK else [0, 1, 2]
mse_B = {"variance_matched": [], "default": []}
for seed in SEEDS_B:
    for init in mse_B:
        hn, curve = train_task_hyper(init, seed=seed)
        mse_B[init].append(test_task_hyper(hn))
        if seed == 0 and init == "variance_matched": hn_vm, curve_vm = hn, curve
        if seed == 0 and init == "default": hn_def, curve_def = hn, curve
for init, v in mse_B.items():
    print(f"task-conditioned hypernet, {init:17s} init: test MSE per seed "
          + ", ".join(f"{x:.4f}" for x in v))

# %% [markdown]
# ## Part C - Look inside: generated weight scales at initialisation

# %%
@torch.no_grad()
def generated_stats(hn):
    a = torch.rand(256) * 4.9 + 0.1; p = torch.rand(256) * math.pi
    flat = hn(describe(a, p))                     # (256 tasks, 1761)
    stats, i = {}, 0
    for k in shapes:                              # slice out each target tensor
        if k.endswith("weight"):
            stats[k] = flat[:, i:i + sizes[k]].std().item()
        i += sizes[k]
    x = torch.linspace(-5, 5, 50).view(1, -1, 1).expand(256, 50, 1)
    out = batched_forward(flat, x)
    return stats, out.std().item()

for init in ("default", "variance_matched"):
    torch.manual_seed(0)
    stats, out_std = generated_stats(TaskHyperNet(init=init))
    pretty = ", ".join(f"{k}: {v:.3f}" for k, v in stats.items())
    print(f"{init:17s} generated weight std -> {pretty} | target output std {out_std:.3f}")
print("He-init reference std ->", ", ".join(
    f"{k}: {math.sqrt((1.0 if k.startswith('4.') else 2.0)/fan_in[k]):.3f}" for k in shapes if k.endswith("weight")))

plt.figure(figsize=(6, 4))
def smooth(c, w=50): return torch.tensor(c).unfold(0, w, 1).mean(1).numpy()
plt.plot(smooth(curve_def), label="default init"); plt.plot(smooth(curve_vm), label="variance-matched init")
plt.yscale("log"); plt.xlabel("training step"); plt.ylabel("train MSE"); plt.legend()
plt.title("Task-conditioned hypernetwork training"); plt.tight_layout()
plt.savefig("outputs/p3_init_curves.png", dpi=120)

# %% [markdown]
# ## Exercise solutions

# %%
# Ex P3.1 - Parameter counts by hand (check):
# direct 64: inp 2*64+64=192, hidden 8*(64*64+64)=33280, out 65 -> 33537
# direct 22: inp 66, hidden 8*(22*22+22)=4048, out 23 -> 4137
# hyper    : inp 192, out 65, z 8*64*4=2048, hidden_bias 512, gen 4*32+32 + 32*64+64 = 2272 -> 5089
print("Ex P3.1", n_params(DirectMLP(64)), n_params(DirectMLP(22)), n_params(StaticHyperMLP()))

# Ex P3.2 - Interpolation vs extrapolation: amplitudes outside training range.
print(f"Ex P3.2  test MSE, A in [5, 10] (never seen): {test_task_hyper(hn_vm, amp=(5.0, 10.0)):.3f}")

# Ex P3.3 - FiLM: a hypernetwork that only generates per-unit scale and shift
# (gamma, beta) for the two hidden layers of a SHARED base network.
class FiLMNet(nn.Module):
    def __init__(self):
        super().__init__()
        self.l1, self.l2, self.l3 = nn.Linear(1, 40), nn.Linear(40, 40), nn.Linear(40, 1)
        self.film = nn.Sequential(nn.Linear(3, 128), nn.ReLU(), nn.Linear(128, 4 * 40))
        nn.init.zeros_(self.film[2].weight); nn.init.zeros_(self.film[2].bias)  # start as identity

    def forward(self, desc, x):                     # desc (T,3), x (T,N,1)
        g1, b1, g2, b2 = self.film(desc).unsqueeze(1).chunk(4, -1)
        h = F.relu((1 + g1) * self.l1(x) + b1)
        h = F.relu((1 + g2) * self.l2(h) + b2)
        return self.l3(h)

film_mse = []
for seed in SEEDS_B:
    torch.manual_seed(seed); film = FiLMNet(); opt = torch.optim.Adam(film.parameters(), lr=1e-3)
    for s in range(1000 if QUICK else 6000):
        a, p, x, y = sample(32, 20)
        loss = F.mse_loss(film(describe(a, p), x), y); opt.zero_grad(); loss.backward(); opt.step()
    with torch.no_grad():
        g = torch.Generator().manual_seed(2026); a, p, x, y = sample(500, 100, gen=g)
        film_mse.append(F.mse_loss(film(describe(a, p), x), y).item())
print(f"Ex P3.3  FiLM test MSE per seed " + ", ".join(f"{v:.4f}" for v in film_mse)
      + f"  with {n_params(film)} params (full hypernet: {n_params(hn_vm)})")

# Ex P3.4 - The same static hypernetwork trained WITHOUT gradient clipping.
torch.manual_seed(0); hyper_noclip = StaticHyperMLP()
loss, acc = train_classifier(hyper_noclip, clip=None)
print(f"Ex P3.4  static hypernet without clipping: train loss {loss:.3f}, test acc {acc:.3f}")
