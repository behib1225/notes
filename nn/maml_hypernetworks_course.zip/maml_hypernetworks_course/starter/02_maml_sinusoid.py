# %% [markdown]
# # Project 1 - MAML from scratch on few-shot sinusoid regression
#
# Reproduces the regression experiment of Finn, Abbeel & Levine (ICML 2017),
# sized for a CPU. Each task: y = A sin(x - phase), A ~ U[0.1, 5], phase ~ U[0, pi],
# x ~ U[-5, 5]. The learner sees K = 10 points and must predict the whole curve.
#
# Run: `python 02_maml_sinusoid.py`          (full run, about 10-15 min on a laptop CPU)
#      `QUICK=1 python 02_maml_sinusoid.py`  (smoke test, under 1 min)
# Figures are written to ./outputs/

# %%
import os, math, time, copy
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.func import functional_call, grad, vmap
import sys
import matplotlib
if "ipykernel" not in sys.modules:
    matplotlib.use("Agg")   # script: save figures to files; notebook: also show them inline
import matplotlib.pyplot as plt

QUICK = os.environ.get("QUICK") == "1"
os.makedirs("outputs", exist_ok=True)
torch.manual_seed(0)

CFG = dict(
    K=10,              # support points per task (K-shot)
    Q=10,              # query points per task during meta-training
    meta_batch=25,     # tasks per outer step (paper: 25)
    inner_lr=0.01,     # alpha (paper: 0.01)
    inner_steps=1,     # inner gradient steps during meta-training (paper: 1)
    outer_lr=1e-3,     # beta, Adam (paper: 0.001)
    iters=300 if QUICK else 70000,   # same as the paper; about 4 min per method on one CPU core
    eval_tasks=100 if QUICK else 500,
    eval_steps=10,     # fine-tuning steps at test time (paper: up to 10)
)
print(CFG)

# %% [markdown]
# ## Step 1 - The task distribution

# %%
class SinusoidTasks:
    def __init__(self, amp=(0.1, 5.0), phase=(0.0, math.pi), x_range=(-5.0, 5.0)):
        self.amp, self.phase, self.x_range = amp, phase, x_range

    def sample_params(self, n, generator=None):
        a = torch.empty(n).uniform_(*self.amp, generator=generator)
        p = torch.empty(n).uniform_(*self.phase, generator=generator)
        return a, p

    def sample_x(self, n_tasks, n_points, generator=None):
        return torch.empty(n_tasks, n_points, 1).uniform_(*self.x_range, generator=generator)

    @staticmethod
    def f(x, a, p):
        # x: (T, N, 1); a, p: (T,)
        return a.view(-1, 1, 1) * torch.sin(x - p.view(-1, 1, 1))

    def sample_batch(self, n_tasks, k, q, generator=None):
        a, p = self.sample_params(n_tasks, generator)
        xs, xq = self.sample_x(n_tasks, k, generator), self.sample_x(n_tasks, q, generator)
        return xs, self.f(xs, a, p), xq, self.f(xq, a, p), a, p

tasks = SinusoidTasks()
xs, ys, xq, yq, a, p = tasks.sample_batch(3, CFG["K"], CFG["Q"])
print("support x:", xs.shape, " support y:", ys.shape)   # (3, 10, 1)

# %% [markdown]
# ## Step 2 - The model (same as the paper: 1-40-40-1, ReLU)

# %%
def make_model():
    return nn.Sequential(nn.Linear(1, 40), nn.ReLU(),
                         nn.Linear(40, 40), nn.ReLU(),
                         nn.Linear(40, 1))

model = make_model()
print("parameters:", sum(p.numel() for p in model.parameters()))   # 1761

# %% [markdown]
# ## Step 3 - The inner loop (adaptation on the support set)

# %%
def loss_fn(params, x, y, net):
    return F.mse_loss(functional_call(net, params, (x,)), y)

def adapt(params, x, y, net, lr, steps, first_order=False):
    """Return task-adapted parameters phi. Differentiable w.r.t. params unless first_order."""
    # TODO: repeat `steps` times: support loss, gradients (create_graph unless first_order), SGD update
    raise NotImplementedError("TODO: repeat `steps` times: support loss, gradients (create_graph unless first_order), SGD update")

# Check against Module 0, Exercise 0.3: two steps on a 1-parameter model.
class _Scalar(nn.Module):
    def __init__(self):
        super().__init__(); self.w = nn.Parameter(torch.zeros(1))
    def forward(self, x):
        return self.w * x
_m = _Scalar()
_x, _y = torch.ones(1, 1), torch.ones(1, 1)                    # support loss (w - 1)^2
_phi = adapt(dict(_m.named_parameters()), _x, _y, _m, 0.1, 2)
(_mg,) = torch.autograd.grad((_phi["w"] - 3) ** 2, _m.w)        # query loss (w'' - 3)^2
assert torch.allclose(_phi["w"], torch.tensor([0.36])) and torch.allclose(_mg, torch.tensor([-3.3792]))
print("adapt() check passed (matches the hand-derived meta-gradient)")

# %% [markdown]
# ## Step 4 - The outer objective, written as a plain loop (clear, slower)

# %%
def maml_loss_loop(net, xs, ys, xq, yq, lr, steps, first_order=False):
    params = dict(net.named_parameters())
    losses = []
    for i in range(xs.shape[0]):                       # one task at a time
        # TODO: adapt on task i's support set, then append its query loss
        raise NotImplementedError("TODO: adapt on task i's support set, then append its query loss")
    return torch.stack(losses).mean()

# %% [markdown]
# ## Step 5 - The same objective, vectorised over tasks with torch.func (fast)

# %%
def maml_loss_vmap(net, xs, ys, xq, yq, lr, steps, first_order=False):
    params = dict(net.named_parameters())

    def task_loss(params, x, y):
        return F.mse_loss(functional_call(net, params, (x,)), y)

    def one_task(params, xs, ys, xq, yq):
        phi = params
        for _ in range(steps):
            g = grad(task_loss)(phi, xs, ys)
            if first_order:
                g = {k: v.detach() for k, v in g.items()}
            phi = {k: phi[k] - lr * g[k] for k in phi}
        return task_loss(phi, xq, yq)

    return vmap(one_task, in_dims=(None, 0, 0, 0, 0))(params, xs, ys, xq, yq).mean()

# Check: both implementations give the same loss and the same meta-gradient.
xs, ys, xq, yq, _, _ = tasks.sample_batch(5, 10, 10)
for fo in (False, True):
    m = make_model()
    l1 = maml_loss_loop(m, xs, ys, xq, yq, 0.01, 2, fo); g1 = torch.autograd.grad(l1, list(m.parameters()))
    l2 = maml_loss_vmap(m, xs, ys, xq, yq, 0.01, 2, fo); g2 = torch.autograd.grad(l2, list(m.parameters()))
    assert torch.allclose(l1, l2, atol=1e-6)
    assert all(torch.allclose(u, v, atol=1e-5) for u, v in zip(g1, g2))
print("loop and vmap implementations agree (second- and first-order)")

# %% [markdown]
# ## Step 6 - Meta-training

# %%
def meta_train(first_order=False, seed=0, cfg=CFG, log_every=10000):
    torch.manual_seed(seed)
    net = make_model()
    opt = torch.optim.Adam(net.parameters(), lr=cfg["outer_lr"])
    history, t0 = [], time.time()
    for it in range(1, cfg["iters"] + 1):
        xs, ys, xq, yq, _, _ = tasks.sample_batch(cfg["meta_batch"], cfg["K"], cfg["Q"])
        loss = maml_loss_vmap(net, xs, ys, xq, yq, cfg["inner_lr"], cfg["inner_steps"], first_order)
        opt.zero_grad()
        loss.backward()
        opt.step()
        history.append(loss.item())
        if it % log_every == 0 or it == cfg["iters"]:
            recent = sum(history[-log_every:]) / len(history[-log_every:])
            print(f"[{'FOMAML' if first_order else 'MAML'}] iter {it:6d}  query MSE {recent:.3f}  ({time.time()-t0:.0f}s)")
    return net, history

maml_net, maml_hist = meta_train(first_order=False)
fomaml_net, fomaml_hist = meta_train(first_order=True)

# %% [markdown]
# ## Step 7 - Baselines
# (a) "pretrained": ordinary regression on points from many random tasks (the paper's baseline).
# (b) "scratch": a randomly initialised network.

# %%
def pretrain(cfg=CFG, seed=0):
    torch.manual_seed(seed)
    net = make_model()
    opt = torch.optim.Adam(net.parameters(), lr=cfg["outer_lr"])
    for it in range(cfg["iters"]):
        xs, ys, _, _, _, _ = tasks.sample_batch(cfg["meta_batch"], cfg["K"], 1)
        loss = F.mse_loss(net(xs.reshape(-1, 1)), ys.reshape(-1, 1))
        opt.zero_grad(); loss.backward(); opt.step()
    return net

pre_net = pretrain()
torch.manual_seed(123)
scratch_net = make_model()

# %% [markdown]
# ## Step 8 - Evaluation on NEW tasks: query MSE after 0..10 SGD steps on K points

# %%
def evaluate(net, k=CFG["K"], n_tasks=CFG["eval_tasks"], steps=CFG["eval_steps"], lr=CFG["inner_lr"],
             seed=2026, sampler=None):
    sampler = sampler or tasks
    g = torch.Generator().manual_seed(seed)                   # same test tasks for every model
    xs, ys, xq, yq, _, _ = sampler.sample_batch(n_tasks, k, 100, generator=g)
    params = {n: p.detach() for n, p in net.named_parameters()}
    curve = torch.zeros(steps + 1)
    for i in range(n_tasks):
        phi = {n: p.clone().requires_grad_() for n, p in params.items()}
        for s in range(steps + 1):
            with torch.no_grad():
                curve[s] += loss_fn(phi, xq[i], yq[i], net).item()
            if s < steps:
                l = loss_fn(phi, xs[i], ys[i], net)
                gr = torch.autograd.grad(l, list(phi.values()))
                phi = {n: (v - lr * gg).detach().requires_grad_() for (n, v), gg in zip(phi.items(), gr)}
    return curve / n_tasks

results = {name: evaluate(net) for name, net in
           [("MAML", maml_net), ("FOMAML", fomaml_net), ("pretrained", pre_net), ("scratch", scratch_net)]}
print(f"\n{'model':12s} {'0 steps':>9s} {'1 step':>9s} {'10 steps':>9s}   (query MSE, K={CFG['K']})")
for name, c in results.items():
    print(f"{name:12s} {c[0]:9.3f} {c[1]:9.3f} {c[10]:9.3f}")

plt.figure(figsize=(6, 4))
for name, c in results.items():
    plt.plot(range(len(c)), c.numpy(), marker="o", label=name)
plt.xlabel("gradient steps at test time"); plt.ylabel("query MSE"); plt.yscale("log")
plt.title(f"Few-shot sinusoid regression, K={CFG['K']}"); plt.legend(); plt.tight_layout()
plt.savefig("outputs/p1_learning_curves.png", dpi=120)

# %% [markdown]
# ## Step 9 - Look at one task

# %%
def show_task(nets, k=CFG["K"], seed=7, steps=(0, 1, 10)):
    g = torch.Generator().manual_seed(seed)
    xs, ys, _, _, a, p = tasks.sample_batch(1, k, 1, generator=g)
    xg = torch.linspace(-5, 5, 200).view(1, -1, 1)
    fig, axes = plt.subplots(1, len(nets), figsize=(5 * len(nets), 3.5), sharey=True)
    for ax, (name, net) in zip(axes, nets):
        ax.plot(xg[0, :, 0], tasks.f(xg, a, p)[0, :, 0], "k-", lw=2, label="true")
        ax.scatter(xs[0, :, 0], ys[0, :, 0], c="red", zorder=5, label=f"{k} support pts")
        phi = {n: v.detach().clone().requires_grad_() for n, v in net.named_parameters()}
        for s in range(max(steps) + 1):
            if s in steps:
                with torch.no_grad():
                    ax.plot(xg[0, :, 0], functional_call(net, phi, (xg[0],))[:, 0], "--", label=f"{s} steps")
            l = loss_fn(phi, xs[0], ys[0], net)
            gr = torch.autograd.grad(l, list(phi.values()))
            phi = {n: (v - CFG["inner_lr"] * gg).detach().requires_grad_() for (n, v), gg in zip(phi.items(), gr)}
        ax.set_title(name)
    axes[0].legend(fontsize=8); plt.tight_layout()
    plt.savefig("outputs/p1_example_fits.png", dpi=120)

show_task([("MAML", maml_net), ("pretrained", pre_net)])
torch.save(maml_net.state_dict(), "outputs/maml_sinusoid.pt")   # reused in your own experiments
print("Figures saved in outputs/")

# %% [markdown]
# ## Exercise solutions

# %%
# Ex P1.1 - K=5 instead of 10: evaluate the K=10-trained MAML model with only 5 support points.
c5 = evaluate(maml_net, k=5)
print(f"Ex P1.1  MAML (trained K=10) tested with K=5: 0 steps {c5[0]:.3f}, 10 steps {c5[10]:.3f}")

# Ex P1.2 - Out-of-distribution amplitudes: A in [5, 10] instead of [0.1, 5].
ood = SinusoidTasks(amp=(5.0, 10.0))
c_ood = evaluate(maml_net, sampler=ood)                 # same alpha = 0.01 as in training
c_ood_small = evaluate(maml_net, lr=0.002, sampler=ood) # 5x smaller test-time step size
print(f"Ex P1.2  MAML on A in [5,10], alpha=0.01 : 0 steps {c_ood[0]:.3f}, 1 step {c_ood[1]:.3f}, 10 steps {c_ood[10]:.3f}")
print(f"Ex P1.2  MAML on A in [5,10], alpha=0.002: 0 steps {c_ood_small[0]:.3f}, 1 step {c_ood_small[1]:.3f}, 10 steps {c_ood_small[10]:.3f}")
# Larger amplitudes -> larger gradients -> alpha=0.01 overshoots and some tasks diverge
# (a single diverging task turns the mean into nan). See Module 2, Exercise 2.3.

# Ex P1.3 - Wall-clock cost of second-order vs first-order outer step.
xs, ys, xq, yq, _, _ = tasks.sample_batch(25, 10, 10)
for fo in (False, True):
    m = make_model(); t0 = time.time()
    for _ in range(50):
        l = maml_loss_vmap(m, xs, ys, xq, yq, 0.01, 5, fo); l.backward()
    print(f"Ex P1.3  5 inner steps, {'first' if fo else 'second'}-order: {(time.time()-t0)/50*1000:.1f} ms per outer step")
