<!-- Exported from the course doc on 12 November 2026. Formulas use $$...$$ display math (rendered by GitHub, JupyterLab and VS Code). Figures are in reference_figures/; COURSE.pdf has the same text with the diagrams drawn. -->

# MAML and HyperNetworks: A Project-Based Course

Nov 12, 2026 · @Behi

## How to use this course

By the end of this course you will have implemented MAML (Model-Agnostic Meta-Learning) and HyperNetworks from scratch in plain PyTorch, run them on a CPU laptop, and understood when each one is the right tool. Every concept is explained from first principles, every step has a worked solution, and every module ends with exercises and their answers.

### Who this is for

You are a newly graduated engineer. You can write Python, you have used PyTorch to train at least one small network (you know `nn.Module`, `loss.backward()`, and an optimizer step), and you remember basic calculus (the chain rule) and linear algebra (matrix multiplication). You do not need to know anything about meta-learning, few-shot learning or hypernetworks. Where the course uses a mathematical idea beyond that, it explains it on the spot.

### What you will be able to do

1. Explain what meta-learning is, and define tasks, episodes, support and query sets, and N-way K-shot problems.
2. Derive the MAML update, including the second-order term, and explain why first-order MAML and Reptile are cheaper approximations.
3. Write a model as a pure function of its parameters with `torch.func.functional_call`, and differentiate through an inner optimisation loop with `create_graph=True`.
4. Train MAML on few-shot sinusoid regression and on few-shot Omniglot character classification.
5. Explain what a hypernetwork is, build static and task-conditioned hypernetworks, and initialise them so they train.
6. Build an amortised meta-learner (a hypernetwork that reads a support set and writes a network's weights) and compare it fairly against MAML.
7. Place both ideas in the 2026 landscape: foundation models, in-context learning, parameter-efficient fine-tuning, and agents that must adapt quickly.

### Course map

| Part | Type | What you build or learn | Code file | Time (h) |
| --- | --- | --- | --- | --- |
| Module 0 | Foundations | Models as functions of their weights; gradients of gradients | `01_functional_pytorch.py` | 3 |
| Module 1 | Concepts | Meta-learning vocabulary and the episode | none | 2 |
| Module 2 | Theory | MAML derivation, FOMAML, Reptile | none | 4 |
| Project 1 | Project | MAML on sinusoid regression | `02_maml_sinusoid.py` | 5 |
| Module 3 | Theory | Making MAML work: MAML++, Meta-SGD, ANIL, iMAML | none | 3 |
| Project 2 | Project | Few-shot Omniglot with MAML | `03_maml_omniglot.py` | 6 |
| Module 4 | Theory | HyperNetworks | none | 3 |
| Project 3 | Project | Static and task-conditioned hypernetworks | `04_hypernetworks.py` | 5 |
| Project 4 | Capstone | MAML vs hypernetwork vs hybrid | `05_capstone.py` | 6 |
| Module 5 | Landscape | The field in 2026 and agentic AI | none | 2 |
| Final | Assessment | Exam with answer key | none | 2 |

At about 8 hours a week, the course takes 5 to 6 weeks. All projects are sized to finish on a laptop CPU. Measured on one CPU core, a full script takes about 15 minutes (Project 1), 40 minutes (Project 2, including two baselines and the exercises), 5 minutes (Project 3) and 11 minutes (Project 4); multi-core laptops are usually faster, and every script has a quick mode that runs in 1 to 3 minutes.

### The files

The course ships with runnable Python files. Each `.py` file uses `# %%` cell markers, so it runs top to bottom as a script and also opens as a notebook in VS Code, PyCharm or JupyterLab (with the Jupytext extension). A matching `.ipynb` notebook is provided for each file as well. The scripts contain the complete solutions; the doc shows you each step first as a task, then its solution, so try every task before reading on.

- `00_setup_check.py`: checks your Python and PyTorch install.
- `01_functional_pytorch.py` to `05_capstone.py`: one file per module or project, as in the course map. These are the full solutions.
- `starter/`: the same project files (02 to 05) with every key function replaced by a `TODO` that raises `NotImplementedError`. Each function is followed by an automatic check (an `assert`) that tells you whether your version is correct. **Work in these first.** `make_starters.py` regenerates them.
- `requirements.txt` (minimum versions) and `requirements-lock.txt` (the exact versions behind every number in this doc).
- `reference_figures/`: the figures from the course's own runs, for comparison.

To run any project as a short smoke test, set `QUICK=1`: `QUICK=1 python 02_maml_sinusoid.py` on macOS or Linux; `set "QUICK=1" && python 02_maml_sinusoid.py` in Windows Command Prompt (without the quotes, Command Prompt stores "1 " with a trailing space and quick mode silently does not switch on); `$env:QUICK = "1"; python 02_maml_sinusoid.py` in PowerShell. In a notebook, change the `QUICK = ...` line to `QUICK = True`.

**A note on the answers in this doc.** Exercise answers sit directly under each question so the doc stays self-contained. Cover them before reading, or work from the starter files, which contain no solutions.

### Setup

1. Install Python 3.11 or newer. PyTorch 2.15 (October 2026) no longer ships Python 3.10 wheels. The course code was tested with Python 3.12, PyTorch 2.15.0 and torchvision 0.29 on a CPU, and needs at least PyTorch 2.1 because it uses `torch.func`.
2. Create a virtual environment: `python -m venv maml-env`, then activate it (`source maml-env/bin/activate` on macOS/Linux, `maml-env\Scripts\activate` on Windows).
3. Install packages: `pip install -r requirements.txt`. This installs PyTorch, torchvision (for the Omniglot dataset), matplotlib and numpy. To reproduce this doc's numbers as closely as possible, use `pip install -r requirements-lock.txt` instead, which pins the exact tested versions.
4. Run `python 00_setup_check.py`. It prints your versions and confirms that `torch.func` and second-order gradients work.

### Conventions used in this doc

- **Task boxes** start with *Task*. Stop and attempt them.
- **Solutions** follow each task and match the code files.
- **Exercises** at the end of each module come with answers directly underneath. Cover the answer, try, then check.
- Mathematics is written in display blocks. Greek letters: θ (theta) are model weights, φ (phi) are adapted weights, α (alpha) is the inner learning rate, β (beta) is the outer learning rate, ∇ (nabla) means gradient.
- When the doc states a hyperparameter from a paper, it names the paper. When it gives a result you will reproduce, the number is what the course code produced on a CPU, and your number will differ slightly because of random seeds.

## Module 0: Models as functions of their weights

Both MAML and HyperNetworks need one skill you may not have used yet: running a network with weights that are *not* stored inside the `nn.Module`. MAML needs it because adapted weights φ = θ − α∇L are new tensors computed from θ. HyperNetworks need it because another network outputs the weights. PyTorch's `torch.func` module (built in since PyTorch 2.0) provides exactly this. Code: `01_functional_pytorch.py`.

### 0.1 Why `optimizer.step()` is not enough

In normal training, `optimizer.step()` overwrites the weights in place and forgets how they were computed. MAML needs the query loss of the *updated* weights to be differentiable with respect to the *original* weights. In-place updates destroy that link. So we keep θ untouched, compute φ as an ordinary tensor expression, and run the network with φ.

### 0.2 Step 1: the parameter dictionary

*Task.* Build a 1-40-1 MLP and print each parameter's name and shape.

*Solution.*

```python
model = nn.Sequential(nn.Linear(1, 40), nn.ReLU(), nn.Linear(40, 1))
params = dict(model.named_parameters())
# 0.weight (40, 1)   0.bias (40,)   2.weight (1, 40)   2.bias (1,)
```

The names come from the position of each layer in the `Sequential` (index 0 and 2; the ReLU at index 1 has no parameters). These names are the keys you will use everywhere.

### 0.3 Step 2: `functional_call`

*Task.* Run the model with all-zero weights without changing the model.

*Solution.*

```python
from torch.func import functional_call
zero_params = {k: torch.zeros_like(v) for k, v in params.items()}
y_zero = functional_call(model, zero_params, (x,))   # all outputs are 0
```

`functional_call(module, params_dict, args)` temporarily swaps the given tensors into the module, runs `forward`, and swaps the originals back. The module keeps its own weights. Gradients flow into whatever tensors you passed, which is the property MAML and HyperNetworks rely on.

### 0.4 Step 3: one gradient step by hand

*Task.* Compute φ = θ − 0.01 ∇L for an MSE loss on sin(x), without an optimizer, and check the loss drops.

*Solution.*

```python
def mse_with(params, x, y):
    return F.mse_loss(functional_call(model, params, (x,)), y)

loss = mse_with(params, x, y)
grads = torch.autograd.grad(loss, list(params.values()))
adapted = {k: p - 0.01 * g for (k, p), g in zip(params.items(), grads)}
```

`torch.autograd.grad` returns gradients as new tensors instead of storing them in `.grad`. In the course run the loss fell from 1.24 to 0.63.

### 0.5 Step 4: gradients of gradients

By default, the gradient returned by autograd is a plain tensor with no history. Passing `create_graph=True` records how the gradient itself was computed, so it can be differentiated again.

```python
w = torch.tensor(2.0, requires_grad=True)
(df,) = torch.autograd.grad(w ** 3, w, create_graph=True)   # 3w^2 = 12
(d2f,) = torch.autograd.grad(df, w)                          # 6w = 12
```

### 0.6 Step 5: differentiate through a gradient step

This is MAML in one dimension. The support loss is (w − a)², the query loss is (w′ − b)², and w′ = w − α · 2(w − a). By the chain rule, dL\_out/dw = 2(w′ − b)(1 − 2α).

*Task.* With a = 1, b = 3, α = 0.1, w = 0, compute the meta-gradient with autograd, by hand, and with the first-order shortcut.

*Solution.* w′ = 0 − 0.1 · 2 · (0 − 1) = 0.2. Full: 2(0.2 − 3)(1 − 0.2) = −4.48. First-order (drop the (1 − 2α) factor): 2(0.2 − 3) = −5.6. The script prints −4.4800 from autograd, matching the hand calculation exactly.

### 0.7 Step 6: Hessian-vector products

For a real network, the factor (1 − 2α) becomes the matrix (I − αH), where H is the Hessian of the support loss. Autograd never builds H. Differentiating `g @ v` (the gradient dotted with a fixed vector v) gives H·v directly, for the cost of about two backward passes. The script checks this against the explicit Hessian of a tiny linear model; they agree to 5 decimal places.

### 0.8 Step 7: `grad` and `vmap` for many tasks at once

`torch.func.grad(f)` returns a new function that computes the gradient of f with respect to its first argument. `torch.func.vmap(f)` runs f over a leading batch dimension as if in a loop, but vectorised. Together they let you adapt a whole meta-batch of tasks in one call:

```python
def task_loss(params, x, y):
    return F.mse_loss(functional_call(model, params, (x,)), y)

def query_loss_after_adapt(params, xs, ys, xq, yq, alpha=0.01):
    g = grad(task_loss)(params, xs, ys)
    phi = {k: params[k] - alpha * g[k] for k in params}
    return task_loss(phi, xq, yq)

losses = vmap(query_loss_after_adapt, in_dims=(None, 0, 0, 0, 0))(params, xs, ys, xq, yq)
losses.mean().backward()     # full second-order meta-gradient into model's .grad
```

`in_dims=(None, 0, 0, 0, 0)` means: share `params` across tasks, and split every data tensor along dimension 0 (one slice per task). You have just written the core of MAML.

### Module 0 exercises

**Exercise 0.1.** Prove with code that `functional_call` leaves the module's stored weights unchanged.

*Answer.* Clone a weight, call `functional_call` with other parameters, and assert the stored weight still equals the clone (`torch.equal`). See the bottom of `01_functional_pytorch.py`.

**Exercise 0.2.** What is `requires_grad` on a gradient computed *without* `create_graph=True`, and why does that break MAML?

*Answer.* It is `False`. The gradient is a constant with no history, so φ = θ − αg depends on θ only through the identity term. The outer gradient then lacks the Hessian term: you have accidentally implemented first-order MAML.

**Exercise 0.3.** Extend Step 5 to two inner steps. Derive dw″/dw and verify with autograd.

*Answer.* Each step maps the error e = w − a to (1 − 2α)e, so dw″/dw = (1 − 2α)² = 0.64. From w = 0: w″ = 1 + (0 − 1)(0.64) = 0.36. The meta-gradient is 2(0.36 − 3)(0.64) = −3.3792; the script's autograd value matches.

**Exercise 0.4.** How many parameters does the 1-40-1 MLP have?

*Answer.* First layer 40 weights + 40 biases, second layer 40 weights + 1 bias: 121.

**Exercise 0.5 (think).** `vmap` with `in_dims=(None, 0, ...)` shares one set of parameters across tasks. What `in_dims` would you use if every task had its *own* weights, as when a hypernetwork generates them?

*Answer.* `in_dims=(0, 0, ...)`: split the weights along the task dimension too. Project 3 uses exactly this to run a different generated network per task.

## Module 1: What meta-learning is

Meta-learning means training a system on many related tasks so that it learns a *new* task from very little data. Ordinary learning improves at one task as it sees more examples; meta-learning improves at *learning itself* as it sees more tasks. The idea goes back to Jürgen Schmidhuber's 1987 diploma thesis and Thrun and Pratt's 1998 book *Learning to Learn*; MAML (2017) made it practical for deep networks.

### 1.1 An everyday picture

A person who has learned five programming languages picks up a sixth in a weekend. They did not memorise the sixth language in advance. They learned *how languages tend to work*: variables, loops, scoping, type systems. That reusable prior knowledge is what a meta-learner tries to acquire from data.

In deep learning terms, a network trained from scratch on 5 images of a new bird species will badly overfit. A meta-learned network, having practised "learn a new class from 5 images" thousands of times on other species, can do it well.

### 1.2 Tasks and the task distribution

A **task** T is one learning problem: a dataset plus a loss. Examples: "fit this particular sine wave", "tell apart these 5 handwritten characters", "steer this robot with a heavier arm".

We assume tasks are drawn from a **task distribution** p(T). Meta-learning only helps if new tasks come from the same distribution as training tasks. A model meta-trained on handwritten characters will not adapt quickly to medical X-rays. This is the single most important assumption in the field, and the first thing to check when a meta-learning system fails.

### 1.3 Support set and query set

Each task's data is split in two:

- The **support set** (also called the task's training set, D^tr) is the handful of labelled examples the learner may use to adapt.
- The **query set** (also called the task's test set, D^ts) is held-out data from the *same task* that measures how well the adaptation worked.

The query set is what makes meta-learning honest. During meta-training, the learner is rewarded only for doing well on query examples it did not adapt on. That forces it to learn to *generalise* from the support set, not to memorise it.

### 1.4 N-way K-shot classification

Few-shot classification uses a standard shorthand:

- **N-way**: each task has N classes to tell apart.
- **K-shot**: the support set has K labelled examples per class, so N × K support examples in total.
- The query set usually has Q examples per class (often 15), so N × Q query examples.

So "5-way 1-shot" means: here are 5 classes, one example of each; now classify new images into those 5 classes. Chance accuracy is 1/N, which is 20% for 5-way.

Two rules make the benchmark meaningful:

1. **Disjoint class splits.** The classes used at meta-test time never appear during meta-training. Otherwise the model can simply memorise those classes, which is ordinary classification, not learning to learn.
2. **Per-episode label shuffling.** In every task, the N chosen classes are randomly assigned labels 0 to N−1. The "0" class in one episode is a different character than the "0" class in the next. The model therefore cannot store "label 3 means the letter Bet"; it must read the support set to find out.

### 1.5 Episodes and the two loops

Training is organised in **episodes**: one episode is one sampled task with its support and query sets. Most methods have two nested loops:

- The **inner loop** (adaptation) uses the support set of a single task to produce a task-specific model.
- The **outer loop** (meta-update) looks at how well those adapted models did on their query sets, across a batch of tasks, and improves the shared, task-independent knowledge.

The batch of tasks used in one outer step is the **meta-batch**. The data splits are three levels deep, which confuses everyone at first:

| Level | Contains | Used for |
| --- | --- | --- |
| Meta-train split | Many classes (e.g. 1,200 Omniglot characters) | Sampling training tasks |
| Meta-validation split | Different classes | Choosing hyperparameters and checkpoints |
| Meta-test split | Yet different classes | The final reported accuracy |
| Inside each task: support set | N × K examples | Inner-loop adaptation |
| Inside each task: query set | N × Q examples | Measuring adaptation (outer loss, or test score) |

### 1.6 The three families of meta-learning methods

| Family | Core idea | Classic examples | How adaptation happens |
| --- | --- | --- | --- |
| Optimisation-based | Learn an initialisation (and maybe step sizes) that gradient descent can adapt fast | MAML (2017), Reptile (2018), Meta-SGD (2017), iMAML (2019) | A few gradient steps on the support set |
| Metric-based | Learn an embedding where a simple distance rule classifies | Matching Networks (2016), Prototypical Networks (2017) | Compare query embeddings with support embeddings |
| Model-based (black-box, amortised) | A network reads the support set and directly outputs predictions or weights | Memory-augmented networks (2016), SNAIL (2018), hypernetwork-based learners, in-context learning in large language models | One forward pass, no gradient steps at test time |

This course covers the first family (MAML) and a key tool of the third family (HyperNetworks), then combines them in the capstone.

### 1.7 How meta-learning differs from neighbouring ideas

- **Transfer learning** (pre-train on big data, then fine-tune): the pre-training objective is not "be easy to fine-tune from few examples"; it just happens to help. Meta-learning optimises adaptability directly.
- **Multi-task learning**: trains one model to do a fixed set of known tasks well. Meta-learning trains for *unseen* tasks.
- **Continual learning**: learns tasks one after another without forgetting old ones. It can use meta-learning, but its central problem is forgetting, not fast adaptation.
- **In-context learning** in large language models: the model adapts to examples in its prompt without weight updates. Researchers widely describe this as an emergent form of model-based meta-learning, and Module 5 returns to it.

### 1.8 Standard benchmarks you will meet

- **Sinusoid regression** (introduced in the MAML paper): each task is a sine wave with random amplitude and phase; fit it from 5 or 10 points. Cheap and visual, ideal for a CPU.
- **Omniglot** (Lake, Salakhutdinov and Tenenbaum, 2015): 1,623 handwritten characters from 50 alphabets, each drawn by 20 different people. Called the "transpose of MNIST": many classes, few examples each.
- **miniImageNet** (Vinyals et al., 2016): 100 ImageNet classes with 600 images each, split 64/16/20 for train/validation/test (the split by Ravi and Larochelle, 2017, is the standard). Too heavy for this course's CPU budget, but you will see it in every paper.

### Module 1 exercises

**Exercise 1.1.** In a 5-way 1-shot task with 15 query examples per class, how many support and query examples are there, and what is chance accuracy?

*Answer.* Support: 5 × 1 = 5. Query: 5 × 15 = 75. Chance accuracy: 1/5 = 20%.

**Exercise 1.2.** A colleague reports 99% accuracy on 20-way 1-shot Omniglot, but their meta-test tasks were sampled from the same characters used in meta-training. What is wrong?

*Answer.* The model may have memorised those characters during meta-training, so the test measures recognition of known classes, not learning new ones. Meta-test classes must be disjoint from meta-train classes.

**Exercise 1.3.** Why are labels reshuffled in every episode? What would a model learn if label 0 always meant the same character?

*Answer.* Without reshuffling, the model can learn a fixed mapping from image to label and ignore the support set entirely. That is standard classification. Reshuffling makes the support set the only source of the label meaning, which forces adaptation.

**Exercise 1.4.** Classify each method into a family: (a) fine-tune the last layer with 5 SGD steps from a learned initialisation; (b) average each class's support embeddings and pick the nearest average; (c) a transformer reads the support pairs and the query, then outputs the label.

*Answer.* (a) Optimisation-based. (b) Metric-based (this is Prototypical Networks). (c) Model-based, or black-box.

**Exercise 1.5.** You meta-train a regression model on sine waves with amplitudes in \[0.1, 5.0\]. At test time, a user gives you a sine wave with amplitude 20. Predict what happens and explain why.

*Answer.* Performance will likely be poor. Amplitude 20 lies outside the task distribution p(T) seen in meta-training, so the learned prior (initialisation or weight generator) does not cover it. Meta-learning generalises across tasks from the same distribution, not to arbitrary new ones.

**Exercise 1.6.** Is "pre-train a vision model on ImageNet, then fine-tune on 10 images" meta-learning? Argue both sides.

*Answer.* Strictly, no: the pre-training loss never asks the model to be good after fine-tuning on 10 images, and there is no task distribution or query-set objective. Loosely, it serves the same purpose and often works as well. Chen et al. (2019) and Tian et al. (2020) showed that a strong pre-trained embedding plus a simple classifier rivals many meta-learning methods on standard benchmarks. A good engineer always includes this baseline.

**Exercise 1.7 (design).** An agent must learn each new customer's preferred email tone from 3 example emails. Define the task, support set, query set and task distribution.

*Answer.* Task: generate or score emails in one customer's tone. Support set: the 3 example emails from that customer. Query set: further emails from the same customer, held out, used to evaluate the adapted model. Task distribution: the population of customers, so meta-training needs many customers, each with more than 3 emails so a query set exists.

## Module 2: MAML theory

MAML learns a starting point θ for a network such that one or a few gradient steps on any new task's support set give low loss on that task's query set. It was introduced by Chelsea Finn, Pieter Abbeel and Sergey Levine at ICML 2017. "Model-agnostic" means it works with any model trained by gradient descent: regressors, classifiers, or reinforcement-learning policies.

### 2.1 Intuition

Picture every task's ideal weights as a point in weight space. Ordinary pre-training finds the weights that are best *on average* over tasks. MAML instead looks for weights from which every task's ideal point is *a short gradient step away*. Those are different goals. The average of many sine waves is a flat line near zero, a useless starting point. A MAML initialisation is not a good sine wave itself, but it is primed so that 10 points and one step bend it into the right sine wave.

### 2.2 The objective

For a task T\_i, write L\_i^s for the loss on its support set and L\_i^q for the loss on its query set. One inner step with learning rate α gives adapted weights φ\_i. MAML minimises the query loss *after* adaptation, averaged over tasks:

$$
\phi_i = \theta - \alpha \, \nabla_\theta L_i^{s}(\theta)
\qquad\qquad
\min_\theta \; \mathbb{E}_{T_i \sim p(T)} \big[ L_i^{q}(\phi_i) \big]
$$

The outer (meta) update uses a separate learning rate β, usually with Adam:

$$
\theta \leftarrow \theta - \beta \, \nabla_\theta \frac{1}{B} \sum_{i=1}^{B} L_i^{q}\big(\theta - \alpha \nabla_\theta L_i^{s}(\theta)\big)
$$

B is the meta-batch size. The key detail: the outer gradient is taken with respect to θ, *through* the inner step.

### 2.3 The algorithm

1. Initialise θ randomly.
2. Repeat until done:
   1. Sample a meta-batch of B tasks from p(T).
   2. For each task i: compute the support loss L\_i^s(θ), take one or more gradient steps to get φ\_i, keeping the computation graph, then compute the query loss L\_i^q(φ\_i).
   3. Average the query losses over the meta-batch and backpropagate to θ.
   4. Update θ with the outer optimiser (learning rate β).
3. At test time, for a new task: start from θ, take the same kind of gradient steps on its support set, and predict.

```text
MAML's two loops (the drawing is in COURSE.pdf, page 13–14)

[Meta-parameters θ] --> [Inner loop: φᵢ = θ − α∇L(support), for each task i] --> [Query loss of φᵢ on the task's query set] --> [Meta-update: θ ← θ − β∇ mean loss, via the inner step]
        ^                                                                                                                                    |
        +---------------------------------------- outer loop: repeat with a new meta-batch of tasks -----------------------------------------+
```

Read the diagram left to right for one meta-batch: each task adapts θ on its support set, the adapted weights are scored on that task's query set, and the averaged query loss updates θ through the inner step; then the outer loop starts again.

### 2.4 Deriving the meta-gradient

Apply the chain rule to the query loss through φ\_i. The Jacobian of φ\_i with respect to θ involves the Hessian (the matrix of second derivatives) of the support loss, H\_i:

$$
\frac{\partial \phi_i}{\partial \theta} = I - \alpha \, H_i ,
\qquad H_i = \nabla^2_\theta L_i^{s}(\theta)
$$

$$
\nabla_\theta L_i^{q}(\phi_i) = \big( I - \alpha H_i \big) \, \nabla_\phi L_i^{q}(\phi_i)
$$

Read it in two parts. The second factor, the query gradient at the adapted weights, says which way to move. The first factor corrects that direction for the fact that moving θ also changes where the inner step lands. The Hessian is symmetric, so no transpose is needed. With m inner steps, the Jacobian becomes a product of m such factors, one per step, each with the Hessian at that step's weights.

$$
\nabla_\theta L_i^{q}(\phi_i^{(m)}) = \big( I - \alpha H_i^{(0)} \big)\big( I - \alpha H_i^{(1)} \big)\cdots\big( I - \alpha H_i^{(m-1)} \big)\, \nabla_\phi L_i^{q}(\phi_i^{(m)})
$$

Here H\_i^(j) is the Hessian of the support loss at the weights after j steps, with H\_i^(0) taken at θ. The order matters: matrices do not commute in general. The chain rule gives dφ^(m)/dθ = J\_(m−1) ⋯ J\_1 J\_0 with J\_j = I − αH\_i^(j), and the gradient uses its transpose, J\_0ᵀ J\_1ᵀ ⋯ J\_(m−1)ᵀ. Each J\_j is symmetric, so the factor for the *first* step stands on the left. Backpropagation applies these factors right to left, from the last step back to the first.

### 2.5 What it costs

A network with a million weights has a Hessian with 10^12 entries, so nobody builds it. MAML only needs the Hessian *times a vector*, which autograd computes by differentiating the gradient a second time (`create_graph=True`). The price is roughly one extra backward pass per inner step in compute, and memory that grows linearly with the number of inner steps, because every intermediate φ and its activations must be kept for the backward pass. This is why MAML on large models usually uses 1 to 5 inner steps.

### 2.6 First-order MAML (FOMAML)

Drop the second-order term: pretend the Jacobian is the identity.

$$
\nabla_\theta L_i^{q}(\phi_i) \approx \nabla_\phi L_i^{q}(\phi_i)
$$

In code, compute the inner gradient without `create_graph=True` (or call `.detach()` on it). FOMAML still evaluates the query gradient at the *adapted* weights, so it keeps most of the benefit. Finn et al. reported nearly the same miniImageNet accuracy with the first-order version and about a 33% speed-up. Why the approximation works so well is not fully settled. Finn et al. suggested that ReLU networks are locally almost linear, so second derivatives may be small; treat that as a hypothesis, not a fact. ReLU networks are piecewise linear in their *inputs*, but the Hessian of the loss with respect to the *weights* is generally not zero: for squared error it contains the Gauss–Newton term JᵀJ (J being the Jacobian of the outputs with respect to the weights), which is positive semi-definite and usually substantial.

### 2.7 Reptile

Reptile (Nichol, Achiam and Schulman, 2018) is even simpler. For each task, run k steps of SGD from θ to get φ, then move θ a fraction ε toward φ:

$$
\theta \leftarrow \theta + \epsilon \, (\phi - \theta)
$$

It needs no support/query split and no second derivatives. With k = 1, Reptile reduces to ordinary SGD on the average task loss, which is just joint pre-training. With k > 1, a Taylor expansion shows its update contains a term that increases the inner product between gradients from different mini-batches of the same task. That term rewards weights where learning from one part of a task also helps on the rest of it, which is the same goal as MAML.

### 2.8 Two useful views of MAML

- **Learned initialisation as a prior.** Grant et al. (2018) showed MAML can be read as approximate inference in a hierarchical Bayesian model: θ plays the role of a prior shared across tasks, and the inner steps compute a task-specific estimate. Early stopping of gradient descent acts like a Gaussian prior centred on θ.
- **Feature reuse versus rapid learning.** Raghu et al. (ICLR 2020) found that in trained MAML networks the inner loop barely changes the body of the network; most change happens in the final layer. Module 3 covers the consequence, the ANIL algorithm.

### Module 2 exercises

**Exercise 2.1 (worked).** One-dimensional tasks have support loss ½(θ − a)² and query loss ½(θ − b)². Write φ, the MAML gradient, and the FOMAML gradient.

*Answer.* The support gradient is (θ − a), so φ = θ − α(θ − a) and dφ/dθ = 1 − α. The MAML gradient is (1 − α)(φ − b). The FOMAML gradient is (φ − b). Here the Hessian is the constant 1, so FOMAML just rescales the gradient by 1/(1 − α); same direction, different size. In a network the Hessian varies, so the directions differ too. `01_functional_pytorch.py` (Step 5) checks this kind of formula with autograd.

**Exercise 2.2.** Using the losses of 2.1 with a = b = c, where c is drawn at random per task. What θ does MAML converge to? What happens when α = 1?

*Answer.* The objective is E\[½(1 − α)²(θ − c)²\], minimised at θ = E\[c\]. When α = 1 the inner step jumps straight to c from anywhere, so every θ is optimal and the meta-gradient is zero. This shows that α and θ interact: a large enough α can make the initialisation irrelevant on easy tasks.

**Exercise 2.3.** For linear regression with support loss (1/2n)‖Xw − y‖², what is the Hessian, and when does the inner step diverge?

*Answer.* H = XᵀX / n, constant in w. One gradient step multiplies the error along each eigenvector of H by (1 − αλ). If αλ\_max > 2, that factor has magnitude above 1 and repeated steps diverge. A too-large α is a common reason MAML training produces NaN losses.

**Exercise 2.4.** You switch from 1 to 5 inner steps. Roughly how do compute and memory per outer step change for second-order MAML, and for FOMAML?

*Answer.* Second-order: both compute and memory grow about 5×, because each step's graph is stored and differentiated twice. FOMAML: compute grows about 5× but memory for the meta-gradient stays roughly constant, because only the final adapted weights enter the outer gradient. Exercise P1.3 in Project 1 measures this on your CPU.

**Exercise 2.5.** Show that Reptile with k = 1 is joint training.

*Answer.* With one step, φ − θ = −α∇L\_i(θ), so the update is θ ← θ − εα∇L\_i(θ). Averaged over tasks this is SGD on E\[L\_i(θ)\], exactly the pre-training baseline.

**Exercise 2.6.** What does MAML become if α = 0?

*Answer.* φ = θ, so MAML minimises the average query loss of θ itself: ordinary multi-task pre-training. This makes α = 0 a useful sanity check in code: your MAML loss should then match a plain pre-training loss.

**Exercise 2.7.** Why use different learning rates α (inner) and β (outer)?

*Answer.* They do different jobs. α is part of the learned algorithm: it is used at test time on a handful of examples and must make a big, useful step in one go (0.01 for sinusoids, 0.4 for Omniglot in the paper). β is an ordinary optimiser setting for slowly improving θ over thousands of meta-batches (0.001 with Adam).

## Project 1: MAML from scratch on few-shot sine regression

You will reproduce the regression experiment of the original MAML paper on a laptop CPU. The result to beat: after a single gradient step on 10 points, the course's MAML model reached a query MSE of 0.345 on new sine waves, against 2.559 for a conventionally pre-trained network. Code: `02_maml_sinusoid.py`. Full run: about 15 minutes on one CPU core; `QUICK=1` runs a 1-minute smoke test.

### The problem

Each task is a sine wave y = A·sin(x − p) with amplitude A drawn uniformly from \[0.1, 5.0\] and phase p from \[0, π\]. Inputs x are drawn uniformly from \[−5, 5\]. The learner sees K = 10 points from one wave (the support set) and must predict the wave everywhere (the query set). From 10 points alone, a network trained from scratch cannot do this; a network that has learned "what sine waves look like" can.

### Step 1: the task sampler

*Task.* Write a class that samples a batch of tasks and returns support and query tensors of shape (tasks, points, 1).

*Solution.*

```python
class SinusoidTasks:
    def __init__(self, amp=(0.1, 5.0), phase=(0.0, math.pi), x_range=(-5.0, 5.0)):
        self.amp, self.phase, self.x_range = amp, phase, x_range

    @staticmethod
    def f(x, a, p):                       # x: (T, N, 1); a, p: (T,)
        return a.view(-1, 1, 1) * torch.sin(x - p.view(-1, 1, 1))

    def sample_batch(self, n_tasks, k, q, generator=None):
        a = torch.empty(n_tasks).uniform_(*self.amp, generator=generator)
        p = torch.empty(n_tasks).uniform_(*self.phase, generator=generator)
        xs = torch.empty(n_tasks, k, 1).uniform_(*self.x_range, generator=generator)
        xq = torch.empty(n_tasks, q, 1).uniform_(*self.x_range, generator=generator)
        return xs, self.f(xs, a, p), xq, self.f(xq, a, p), a, p
```

The optional `generator` makes the test tasks identical for every model you evaluate, so comparisons are fair.

### Step 2: the model

The paper's network: 1 input, two hidden layers of 40 ReLU units, 1 output. It has 1,761 parameters (2 × 40 + 40 × 40 + 40 + 40 + 1).

### Step 3: the inner loop

*Task.* Write `adapt(params, x, y, net, lr, steps, first_order)` that returns adapted weights φ and keeps them differentiable with respect to the input weights unless `first_order=True`.

*Solution.*

```python
def loss_fn(params, x, y, net):
    return F.mse_loss(functional_call(net, params, (x,)), y)

def adapt(params, x, y, net, lr, steps, first_order=False):
    phi = dict(params)
    for _ in range(steps):
        loss = loss_fn(phi, x, y, net)
        grads = torch.autograd.grad(loss, list(phi.values()), create_graph=not first_order)
        phi = {k: v - lr * g for (k, v), g in zip(phi.items(), grads)}
    return phi
```

### Step 4: the outer loss as a plain loop

*Task.* For a batch of tasks, adapt on each support set and return the mean query loss.

*Solution.*

```python
def maml_loss_loop(net, xs, ys, xq, yq, lr, steps, first_order=False):
    params = dict(net.named_parameters())
    losses = []
    for i in range(xs.shape[0]):
        phi = adapt(params, xs[i], ys[i], net, lr, steps, first_order)
        losses.append(loss_fn(phi, xq[i], yq[i], net))
    return torch.stack(losses).mean()
```

Calling `.backward()` on this loss puts the full MAML meta-gradient into each parameter's `.grad`.

### Step 5: the same loss, vectorised

The file also contains `maml_loss_vmap`, which uses `torch.func.grad` and `vmap` (Module 0.8) to process all 25 tasks at once. The script then checks that both versions give the same loss *and* the same gradients, for first- and second-order MAML, to within 10⁻⁵. Always build a slow, obviously correct version first and test the fast one against it.

### Step 6: meta-training

| Setting | Paper (Finn et al., 2017) | This course |
| --- | --- | --- |
| Support points K | 10 (also 5 and 20) | 10 |
| Meta-batch | 25 tasks | 25 tasks |
| Inner steps, inner rate α | 1 step, 0.01 | 1 step, 0.01 |
| Outer optimiser β | Adam, 0.001 | Adam, 0.001 |
| Outer iterations | 70,000 | 70,000 |
| Time on one CPU core | not reported | about 8 min (MAML), 4 min (FOMAML) |

The training loop is ordinary PyTorch: sample a batch, compute `maml_loss_vmap`, `zero_grad`, `backward`, `step`. The script trains MAML and first-order MAML (FOMAML) with the same seed. The post-adaptation query MSE during training fell from 0.87 at 10,000 iterations to 0.36 at 70,000 for MAML.

### Step 7: baselines

- **Pre-trained**: the same network trained with Adam to regress points from random tasks, with no inner loop. This is the paper's baseline.
- **Scratch**: a randomly initialised network.

Every model is then adapted the same way at test time: plain SGD with α = 0.01 on the 10 support points.

### Step 8: results on 500 new tasks

Query MSE on 100 evenly spread query points per task, after 0, 1 and 10 test-time gradient steps (lower is better):

| Model | 0 steps | 1 step | 10 steps |
| --- | --- | --- | --- |
| MAML | 3.157 | 0.345 | 0.153 |
| FOMAML | 3.385 | 0.385 | 0.104 |
| Pre-trained | 3.149 | 2.559 | 1.536 |
| Scratch | 4.597 | 4.332 | 4.193 |

The key line is the first column versus the second. Before adaptation, MAML is no better than the pre-trained model (3.16 vs 3.15): both are useless as predictors of a random sine wave. After one step on 10 points, MAML is 7 times better. MAML did not learn a good function; it learned a good *starting point for learning*.

The script saves `outputs/p1_learning_curves.png` (MSE against number of steps) and `outputs/p1_example_fits.png` (one task, the true curve, the 10 support points, and each model's prediction after 0, 1 and 10 steps). In the course run's example plot, MAML's prediction before adaptation is a rough, wrong-phase wave; after one step it lies almost on the true curve. The pre-trained model's prediction keeps nearly the same shape and phase after 1 and even 10 steps.

![One test task from the course run: MAML (left) and the pre-trained model (right), predictions after 0, 1 and 10 gradient steps on the 10 red support points](reference_figures/p1_example_fits.png)

*Figure P1. One unseen sine task from the course run. Black: the true wave; red: the 10 support points; dashed: each model's prediction after 0, 1 and 10 steps. MAML (left) lands on the wave after one step; the pre-trained model (right) keeps its average-wave shape.*

### Discussion questions

**Why does the pre-trained model barely adapt?** Trained on all tasks at once, it learns the best single prediction: the *average* wave. Because phases only span \[0, π\], that average is not zero but E\[A\]·(−2/π)·cos x ≈ −1.62·cos x, the wave you see in its plot. Its weights sit at a point where 10 small gradient steps on 10 points barely change the function's phase. Exercise: derive the average yourself from ∫ sin(x − p) dp over \[0, π\] = −2 cos x.

**Why is MAML's curve not perfectly decreasing?** In the course run MAML's MSE rose slightly between 2 and 4 steps before falling again. It was meta-trained for exactly *one* step, so nothing in training controlled what further steps do. MAML++'s multi-step loss (Module 3.2) addresses exactly this.

**Why did FOMAML beat MAML after 10 steps here?** This is one run with one seed, and both models were trained for one-step adaptation, so their behaviour after 10 steps is a side effect. Differences of this size between related methods need several seeds before you trust them. That FOMAML is close to MAML at all agrees with the paper's finding (Module 2.6).

### Project 1 exercises

**Exercise P1.1.** Test the K = 10 model with only K = 5 support points. Predict the result first.

*Answer.* Worse, but still far better than the pre-trained model: the course run gave a query MSE of 0.390 after 10 steps, against 0.153 with K = 10. Five points leave more sine waves consistent with the data, and the model was meta-trained for 10.

**Exercise P1.2.** Test on amplitudes from \[5, 10\], outside the training range.

*Answer.* With the training step size α = 0.01, the course run gave a query MSE of 23.68 before adaptation, 6.58 after one step, and NaN after 10 steps. One step still helps a lot: gradient descent pulls the model toward the data even for unfamiliar tasks. But larger amplitudes mean larger errors and gradients, so the same α now overshoots (Exercise 2.3). A single diverging task turns the average into NaN. The script also re-evaluates with a five-times-smaller step size, α = 0.002: then nothing diverges, and the MSE falls from 23.68 to 14.48 after one step and 5.08 after 10. So the divergence is a step-size effect, and the price of the safer step is a smaller gain per step. Lesson: hyperparameters of the inner loop are part of what MAML learns to work with, and they too are tuned only for the training task distribution.

**Exercise P1.3.** Time one outer step with 5 inner steps for second-order and first-order MAML.

*Answer.* On the course machine (one CPU core): 12 to 14 ms second-order versus 7 to 8 ms first-order per outer step of 25 tasks, across two runs. Second-order costs about 1.7 to 1.8 times as much; with large convolutional networks the memory difference matters even more.

**Exercise P1.4.** Set `inner_lr=0` and train for 2,000 iterations. What should the "MAML" model's 0-step and 10-step test MSE look like, and why?

*Answer.* With α = 0 there is no adaptation in training, so MAML reduces to pre-training (Exercise 2.6). Its test results should resemble the pre-trained baseline. This is a quick correctness check for any MAML implementation.

**Exercise P1.5.** Turn the script into Meta-SGD (Exercise 3.1) and compare 1-step MSE with MAML.

*Answer.* Add a learnable step-size tensor per parameter to the optimiser and use it in `maml_loss_vmap`'s inner update. Meta-SGD typically reaches a lower 1-step error than MAML on this problem because it can enlarge the steps of the parameters that matter most. Measure it on the same seeded test tasks before drawing conclusions.

**Exercise P1.6.** Train with `inner_steps=5` and compare the 10-step curve with the 1-step-trained model.

*Answer.* Training through 5 steps makes the meta-objective care about where 5 steps land, so the curve should decrease more smoothly beyond step 1, at about 5 times the training cost. Check whether its 1-step MSE gets worse: the model is now optimised for a different budget.

## Module 3: Making MAML work in practice

Plain MAML works, but it is unstable, slow and sensitive to hyperparameters; a handful of well-known fixes address each weakness. Read this module after Project 1 and before Project 2: you will meet several of these issues on real images.

### 3.1 The known problems

Antreas Antoniou, Harrison Edwards and Amos Storkey catalogued MAML's failure modes in *How to train your MAML* (ICLR 2019):

- **Training instability.** Gradients pass through every inner step, so they can explode or vanish, much like in a deep or recurrent network. Training curves often spike.
- **Second-order cost.** Memory and compute grow with the number of inner steps (Module 2.5).
- **Batch normalisation.** The original code normalises with the current batch's statistics only and shares one set of BN parameters across all inner steps.
- **One fixed inner learning rate.** A single α for every layer and every step is rarely ideal and must be tuned by hand.
- **Fixed outer learning rate.** No schedule for β.

### 3.2 MAML++: five fixes

| Fix | What it does | Problem it addresses |
| --- | --- | --- |
| Multi-step loss (MSL) | Adds the query loss after *every* inner step, with weights that anneal toward the final step | Gradient flow and stability |
| Derivative-order annealing (DA) | First-order gradients early in training, second-order later | Cost and early instability |
| Per-step BN statistics and parameters (BNRS, BNWB) | Separate running statistics, scales and shifts for each inner step | Batch-norm mismatch across steps |
| Learned per-layer, per-step learning rates (LSLR) | Makes α a learnable value for each layer and each step | Hand-tuning α |
| Cosine annealing of β (CA) | Cosine schedule for the outer learning rate | Better final convergence |

Together these made MAML train reliably and improved its Omniglot and miniImageNet results.

### 3.3 Meta-SGD: learn the step sizes too

Meta-SGD (Li, Zhou, Chen and Li, 2017) replaces the scalar α with a vector the same shape as θ and meta-learns it alongside θ. The symbol ∘ means element-wise multiplication:

$$
\phi_i = \theta - \boldsymbol{\alpha} \circ \nabla_\theta L_i^{s}(\theta)
$$

Because each weight gets its own rate, which may even be negative, Meta-SGD learns both the size and the direction of the update. The cost is twice the meta-parameters.

### 3.4 ANIL: adapt only the head

Aniruddh Raghu, Maithra Raghu, Samy Bengio and Oriol Vinyals asked in *Rapid Learning or Feature Reuse?* (ICLR 2020) what MAML's inner loop actually changes. In trained networks, the convolutional body's representations barely move during adaptation; the final layer does the adapting. Their **ANIL** (Almost No Inner Loop) algorithm runs the inner loop on the head only, matches MAML's accuracy on standard benchmarks, and is much cheaper because second derivatives flow through only a few thousand head weights. A later paper, **BOIL** (Oh et al., ICLR 2021), argued the opposite design (adapt the body, freeze the head) can help under domain shift, so this is a live design choice. Exercise P2.3 has you run ANIL.

### 3.5 iMAML: implicit gradients

iMAML (Rajeswaran, Finn, Kakade and Levine, NeurIPS 2019) defines the adapted weights as the solution of a regularised inner problem, rather than as the result of a fixed number of steps:

$$
\phi_i^{*}(\theta) = \arg\min_{\phi} \; L_i^{s}(\phi) + \frac{\lambda}{2} \lVert \phi - \theta \rVert^2
$$

The implicit function theorem then gives the meta-gradient without storing the inner trajectory:

$$
\nabla_\theta L_i^{q}(\phi_i^{*}) = \Big( I + \tfrac{1}{\lambda} H_i \Big)^{-1} \nabla_\phi L_i^{q}(\phi_i^{*}),
\qquad H_i = \nabla^2_\phi L_i^{s}(\phi_i^{*})
$$

The inverse is never formed; a few conjugate-gradient iterations solve the linear system using Hessian-vector products. Memory no longer grows with inner steps, so the inner loop can run as long as needed.

Two tools in that sentence deserve a definition.

- **The implicit function theorem.** Suppose an equation F(φ, θ) = 0 pins down φ as a function of θ, here the optimality condition ∇L^s(φ) + λ(φ − θ) = 0. If the matrix ∂F/∂φ is invertible, then dφ/dθ = −(∂F/∂φ)⁻¹ ∂F/∂θ. You never need to know *how* φ was found, only that the equation holds at the solution. Exercise 3.3 applies it.
- **Conjugate gradient (CG).** An iterative method for solving a linear system Mx = b when M is symmetric and positive definite. Each iteration needs only one product M·p, never M itself. Here M = I + H/λ, and M·p costs one Hessian-vector product (Module 0.7). In exact arithmetic CG finishes in at most n iterations for n unknowns, but a handful of iterations usually gives a good enough approximation. M is positive definite as long as λ outweighs any negative curvature, one reason λ must not be too small.

### 3.6 CAVIA and LEO: adapt a small vector instead

- **CAVIA** (Zintgraf et al., ICML 2019) adds a small "context" input vector to the network and adapts *only* that vector in the inner loop. The rest of the network is shared. Fewer adapted numbers means less overfitting to tiny support sets.
- **LEO**, Latent Embedding Optimisation (Rusu et al., ICLR 2019), encodes the support set into a low-dimensional latent code, runs the inner loop on that code, and *decodes* it into classifier weights. That decoder is a hypernetwork. LEO is the bridge between this module and Module 4, and the capstone's hybrid model follows the same idea.

### 3.7 Batch normalisation: a quiet source of bugs

With `track_running_stats=False`, BatchNorm normalises with the statistics of whatever batch it receives. At test time the query set is passed as one batch, so the prediction for one query image depends on the other query images. This is called **transductive** evaluation. It is how the original MAML code worked, and Project 2 follows it, but it is not the same as classifying images one at a time. Options for strictly inductive evaluation include per-step running statistics (MAML++) and TaskNorm (Bronskill et al., ICML 2020).

### 3.8 Meta-overfitting and memorisation

If training tasks are not mutually exclusive, a meta-learner can solve them all without reading the support set. Example: if label 0 always meant the same class, the network learns the classes and ignores adaptation. Yin et al. called this the memorisation problem (*Meta-Learning without Memorization*, ICLR 2020). Per-episode label shuffling prevents it in classification. In regression the risk is subtler, for instance when task identity can be inferred from the inputs alone.

### 3.9 Know your baselines

A fair comparison includes simple transfer learning. *A Closer Look at Few-shot Classification* (Chen et al., ICLR 2019) and *Rethinking Few-Shot Image Classification: a Good Embedding Is All You Need?* (Tian et al., ECCV 2020) showed that a network pre-trained on all training classes, then given a simple linear classifier on the new classes, matches or beats many meta-learning methods on standard benchmarks. The broader Meta-Dataset benchmark (Triantafillou et al., ICLR 2020) tests across ten diverse image datasets and makes these comparisons more realistic.

### 3.10 Practical checklist

1. Sanity-check with α = 0: the loss must equal plain multi-task training.
2. Overfit a single task first: the post-adaptation query loss should go to near zero.
3. Log the query loss *before* and *after* adaptation. The gap is the benefit of adaptation; if it is zero, the inner loop does nothing.
4. Clip outer gradients (for example to norm 10) if losses spike.
5. If you see NaNs, lower α first (Exercise 2.3).
6. Select checkpoints on meta-validation tasks, never on test tasks.
7. Report the mean accuracy over at least 600 test tasks with a 95% confidence interval (1.96 × standard deviation ÷ √number of tasks), and evaluate all methods on the same seeded tasks.

### Module 3 exercises

**Exercise 3.1.** Turn the Project 1 inner loop into Meta-SGD. What lines change?

*Answer.* Create one learnable step-size tensor per parameter and give it to the optimiser, then use it in the inner step:

```python
alpha = {k: torch.full_like(v, 0.01, requires_grad=True)
         for k, v in net.named_parameters()}
opt = torch.optim.Adam(list(net.parameters()) + list(alpha.values()), lr=1e-3)
# inside the inner loop:
phi = {k: phi[k] - alpha[k] * g[k] for k in phi}
```

Nothing else changes: the outer `loss.backward()` now also produces gradients for `alpha`. The paper learns α directly; storing log α and using its exponential is a common variant that keeps rates positive.

**Exercise 3.2.** Why does the multi-step loss of MAML++ stabilise training?

*Answer.* With only the final-step loss, gradients for θ must travel back through every inner step. Adding the loss after each step gives θ short, direct gradient paths as well, much like deep supervision in very deep networks. Annealing the weights toward the last step keeps the final objective unchanged by the end of training.

**Exercise 3.3.** Derive iMAML's Jacobian dφ\*/dθ from the optimality condition.

*Answer.* At the optimum, ∇L^s(φ\*) + λ(φ\* − θ) = 0. Differentiate both sides with respect to θ: H · dφ\*/dθ + λ(dφ\*/dθ − I) = 0. Solve: (H + λI) dφ\*/dθ = λI, so dφ\*/dθ = (I + H/λ)^(−1). Multiply by the query gradient to get the formula in 3.5.

**Exercise 3.4.** In Project 2 you evaluate query images one at a time instead of as a batch of 75. With batch-statistics BatchNorm, what happens?

*Answer.* Each image is normalised by its own statistics only, which differ from the statistics the network saw during training (computed over 25 to 75 images). Accuracy usually drops. Either evaluate the whole query set together and state that the evaluation is transductive, or switch to an inductive normalisation scheme.

**Exercise 3.5.** Why is ANIL's meta-gradient cheaper to compute than MAML's?

*Answer.* Second-order terms involve only the parameters adapted in the inner loop. In ANIL that is the final layer, a few hundred weights for a 5-way head on 32 features (32 × 5 + 5 = 165 in Project 2). The body receives a first-order gradient through the head's adapted weights. Hessian-vector products over 165 numbers are almost free.

**Exercise 3.6.** A teammate's MAML reaches the same post-adaptation query loss as a pre-trained baseline after 10 test steps, but is much better after 1 step. Is MAML useless here?

*Answer.* Not necessarily. MAML optimises fast adaptation, and that is exactly what it delivers: good results with 1 step. If your deployment allows 10 steps and plenty of time, the baseline may be enough. If adaptation must be fast, for example on-device or inside an agent's loop, MAML's advantage matters. Choose by your actual constraint.

## Project 2: Few-shot Omniglot classification with MAML

You will meta-train a small convolutional network that learns to recognise a handwritten character from a single example, then test it against two strong baselines on exactly the same tasks. In the course run, 14 minutes of MAML training on one CPU core gave 95.2% ± 0.4 accuracy on 5-way 1-shot tasks built from 659 characters in 20 alphabets the model never saw. Prototypical Networks reached the same accuracy, 95.5% ± 0.4, with about half the training time and no second derivatives. Code: `03_maml_omniglot.py`, about 40 minutes for everything including the exercises. The first run downloads Omniglot (about 9 MB) through torchvision.

### Step 1: load the data into memory

*Task.* Load both Omniglot splits, resize each 105 × 105 image to 28 × 28, invert it so strokes are 1 and background 0, and store a tensor of shape (characters, 20, 1, 28, 28). Cache it to disk.

*Solution.* torchvision's `Omniglot(root, background=True)` gives the 964-character "background" set (30 alphabets); `background=False` gives the 659-character "evaluation" set (20 different alphabets). Group images by label, stack them, and `torch.save` the result so later runs start in seconds. See `load_split` in the script.

The class splits:

| Split | Characters | Source | Used for |
| --- | --- | --- | --- |
| Meta-train | 864 | Background set, all but the last 100 | Sampling training tasks |
| Meta-validation | 100 | Last 100 background characters | Picking the best checkpoint |
| Meta-test | 659 | Evaluation set, unseen alphabets | Final accuracy |

### Step 2: the episode sampler

*Task.* Write `sample_tasks(data, n_tasks, n_way, k_shot, q, augment)` returning support and query images and labels, with labels 0 to N−1 assigned fresh in each task.

*Solution.*

```python
def sample_tasks(data, n_tasks, n_way, k_shot, q, rng, gen, augment=False):
    for _ in range(n_tasks):
        classes = rng.sample(range(C), n_way)
        for label, c in enumerate(classes):          # label = position in this episode
            idx = torch.randperm(20, generator=gen)[: k_shot + q]
            imgs = data[c, idx]
            if augment:                              # a rotated character counts as a new class
                imgs = torch.rot90(imgs, k=rng.randint(0, 3), dims=(2, 3))
            support.append(imgs[:k_shot]); query.append(imgs[k_shot:])
```

Note the two arguments `rng` (a `random.Random`) and `gen` (a `torch.Generator`). Every caller passes its *own* random generators: training uses one pair, each evaluation creates a fresh, seeded pair. **This is not a style choice.** An earlier version of this course reseeded the *global* random state inside the evaluation function. Because validation ran every 500 iterations, training resumed from the identical random state after every validation, so each 500-iteration block replayed exactly the same tasks: the model saw about 1,000 distinct meta-batches instead of 3,000. Nothing crashed and accuracy still looked good, which is what makes this class of bug dangerous. The script now includes an automatic check that the sampler leaves the global random state untouched.

Rotating characters by multiples of 90° to create extra classes is the augmentation used by Santoro et al. (2016) and by the MAML paper. It applies only to meta-training.

### Step 3: the network

The standard few-shot backbone: four blocks of 3 × 3 convolution, BatchNorm, ReLU and 2 × 2 max-pooling, then a linear layer to N outputs. The image shrinks 28 → 14 → 7 → 3 → 1, so the final feature vector has as many numbers as there are channels. The MAML paper used 64 channels and, for Omniglot specifically, strided convolutions instead of max-pooling; the course uses 32 channels with max-pooling to keep CPU time down, giving 28,485 parameters. BatchNorm uses `track_running_stats=False`, so it always normalises with the current batch's statistics (Module 3.7). All methods in this project share this backbone, so their comparison is fair.

### Step 4: the MAML outer loss

*Task.* Adapt `maml_loss_loop` from Project 1 to classification, and let the caller choose which parameters adapt.

*Solution.* The structure is the same as Project 1; only the loss (`F.cross_entropy`) and a parameter split change:

```python
fast = {k: params[k] for k in inner_keys}                 # adapted in the inner loop
slow = {k: v for k, v in params.items() if k not in inner_keys}
for _ in range(steps):
    logits = functional_call(net, {**slow, **fast}, (xs[i],))
    grads = torch.autograd.grad(F.cross_entropy(logits, ys[i]), list(fast.values()),
                                create_graph=not first_order)
    fast = {k: v - lr * g for (k, v), g in zip(fast.items(), grads)}
```

With `inner_keys` covering every parameter this is MAML; with only the last layer it is ANIL (Exercise P2.3).

A practical finding: for convolutions on a CPU, this plain loop over tasks was about 1.4 times faster than the `vmap` version, because `vmap` turns per-task convolution weights into grouped convolutions. Always measure before assuming vectorisation helps.

### Step 5: evaluation with confidence intervals

*Task.* Write `evaluate(net, data, n_tasks)` returning mean accuracy and a 95% confidence interval.

*Solution.* Generate the test tasks once from a fixed seed and score *every* method on exactly the same tasks. For MAML, adapt with first-order steps (no meta-gradient is needed at test time) and detach θ first, so no graph back to the meta-parameters is built; in the course run, keeping that graph made evaluation run out of memory in 4 GB of RAM. The 95% interval is 1.96 × standard deviation ÷ √(number of tasks). It measures uncertainty from the *test tasks* only; it says nothing about how much the result would change with another training seed.

### Step 6: meta-training

| Setting | Paper (Omniglot, 5-way) | This course |
| --- | --- | --- |
| Conv channels | 64 | 32 |
| Meta-batch | 32 tasks | 8 tasks |
| Query images per class (training) | 15 | 5 |
| Inner steps and α (training) | 1 step, 0.4 | 1 step, 0.4 |
| Inner steps (testing) | 3 | 3 |
| Outer optimiser | Adam, 0.001 | Adam, 0.001 |
| Outer iterations | far more than 3,000 | 3,000 (about 12 min on one core) |

Every 500 iterations the script measures accuracy on 200 validation tasks and keeps the best checkpoint. In the course run, validation accuracy rose from 86.1% at iteration 500 to 91.0% at 1,000, 94.4% at 2,000 and 95.1% at 3,000. Training took 830 seconds including validation.

### Step 7: results on unseen alphabets

600 test tasks, 15 query images per class, the same tasks for every method. Each method was trained once (one seed); the ± is the 95% interval over test tasks.

| Method | 5-way 1-shot | 5-way 5-shot | Training time (one core) |
| --- | --- | --- | --- |
| MAML (3 test steps) | 95.2% ± 0.4 | 98.6% ± 0.3 | 830 s |
| Prototypical Networks | 95.5% ± 0.4 | 98.9% ± 0.1 | 447 s |
| Pre-trained embedding + nearest centroid | 92.5% ± 0.5 | 97.9% ± 0.2 | 60 s |
| MAML model, no adaptation steps | 19.4% (chance is 20%) | not measured | not applicable |

All three trained models used the 1-shot setting for meta-training where applicable; the 5-shot column reuses the same models. The pre-trained model never saw an episode: it was trained as an ordinary 864-way classifier.

The MAML paper reports 98.7% ± 0.4 for 5-way 1-shot, but the numbers are not directly comparable. The paper used 64 channels, strided convolutions, a meta-batch of 32 and far longer training, and it followed the split of Vinyals et al.: 1,200 training characters drawn from all alphabets, with rotated characters added as extra classes. This course tests on 20 alphabets never seen in training, a harder and arguably more honest setting.

The third row is the most instructive. Without adaptation the meta-learned network is exactly at chance. That is expected, not a bug: labels are reshuffled in every episode, so the unadapted network *cannot* know which output means which character. Everything it achieves comes from one to three gradient steps on five images.

### Step 8: the baselines, and what they teach

*Task.* Implement the Prototypical Networks classifier: embed support and query images with the backbone (without its final layer), average each class's support embeddings into a prototype, and score each query by its negative squared distance to every prototype.

*Solution.*

```python
def proto_logits(net, xs, ys, xq, n_way):
    z = embed(net, torch.cat([xs, xq]))                    # one batch: same BN statistics
    zs, zq = z[: len(xs)], z[len(xs):]
    protos = torch.stack([zs[ys == c].mean(0) for c in range(n_way)])
    return -torch.cdist(zq, protos) ** 2
```

Training is ordinary backpropagation of the cross-entropy of these logits over episodes: no inner loop, no second derivatives. The pre-trained baseline is even simpler: train the backbone with an 864-way head on all training images for 6 epochs, drop the head, and classify by the nearest class mean of L2-normalised features.

Three lessons:

1. **A metric-based method matched MAML** on this benchmark (95.5% against 95.2%; the intervals overlap, so treat them as equal) while training in about half the time. Snell et al. reported the same pattern in 2017. Choose MAML when you need to adapt a model's *weights* (regression, reinforcement learning, a new output space), not by default for classification.
2. **Plain transfer learning came close.** Without a single episode, 60 seconds of ordinary training reached 92.5% (1-shot) and 97.9% (5-shot). That is the Chen et al. (2019) and Tian et al. (2020) finding from Module 3.9, reproduced on your laptop. Any meta-learning result you report should include this baseline.
3. **One seed is not enough to rank close methods.** Each method here was trained once. The 95% intervals cover only test-task sampling; a different training seed could move each number by more than the gap between MAML and ProtoNets.

### Project 2 exercises

**Exercise P2.1.** How does test accuracy depend on the number of test-time inner steps (0, 1, 3, 5, 10)?

*Answer.* Course run, 200 tasks each: 19.1%, 94.6%, 95.0%, 95.0%, 95.3%. Almost all the gain comes from the first step, the one the model was meta-trained for. Extra steps help slightly and, unlike sine regression, did not destabilise here, because cross-entropy gradients shrink as predictions become confident.

**Exercise P2.2.** What accuracy does a randomly initialised network reach with the same 3 steps and α = 0.4?

*Answer.* 37.5% ± 1.7, not far above chance. The same adaptation procedure from a meta-learned start gives 95.2%. The initialisation makes the whole difference.

**Exercise P2.3.** Run ANIL: adapt only the final linear layer (`inner_keys=["5.weight", "5.bias"]`).

*Answer.* With the same 3,000-iteration budget and the same test tasks, ANIL reached 93.0% ± 0.9, against MAML's 95.2% ± 0.4, and trained in 573 seconds instead of 830, because second derivatives flow only through the 165 head parameters. Here ANIL was about 2 points behind, while Raghu et al. found ANIL on par with MAML on standard benchmarks with their larger setup. One seed and a small 32-channel backbone may explain the gap: a weaker body leaves more for the inner loop to do, and ANIL cannot adapt the body. Run more seeds before concluding either way.

**Exercise P2.4.** Switch to first-order MAML (`first_order=True`) and compare accuracy and time per iteration.

*Answer.* In the course's timing benchmark with a meta-batch of 16, first-order was about 35% faster per iteration (0.31 s against 0.47 s on one core). Expect a similar or slightly lower accuracy; the MAML paper reported nearly identical first-order results on its image benchmarks. Use the same seeds and number of iterations to compare.

**Exercise P2.5.** Run 20-way 1-shot. What do you change, and what do you expect?

*Answer.* Set `n_way=20`; the final layer then has 20 outputs. The paper used α = 0.1 and 5 test steps for 20-way. Chance falls to 5% and the task is much harder, so expect a clearly lower accuracy than 5-way with the same budget, and longer iterations because each task has 4 times as many images.

**Exercise P2.6.** Evaluate the trained model on query images one at a time instead of all 75 together. What happens and why?

*Answer.* With batch-statistics BatchNorm, each image is normalised only by its own statistics, unlike in training, so accuracy usually falls. This is the transductive-evaluation issue of Module 3.7; report which protocol you used.

## Module 4: HyperNetworks

A hypernetwork is a neural network whose output is the weights of another neural network. Training it end-to-end turns "choose the weights" into a learned function, which gives you weight sharing, conditioning on tasks or inputs, and adaptation in a single forward pass. The modern form was introduced by David Ha, Andrew Dai and Quoc Le in *HyperNetworks* (arXiv 2016, ICLR 2017); the idea of one network writing another's weights goes back to Schmidhuber's "fast weights" (1992) and to indirect encodings such as HyperNEAT (Stanley et al., 2009).

### 4.1 The definition

The **target** (or main) network f computes predictions with weights θ. The **hypernetwork** H, with its own trainable parameters ψ, produces θ from some input z:

$$
\theta = H_\psi(z), \qquad \hat{y} = f_\theta(x), \qquad \min_{\psi} \; L\big(f_{H_\psi(z)}(x), \, y\big)
$$

Only ψ (and any learned embeddings z) are trained. θ is never a parameter: it is an intermediate tensor, recomputed on every forward pass. Backpropagation simply continues from θ into H:

$$
\frac{\partial L}{\partial \psi} = \Big(\frac{\partial \theta}{\partial \psi}\Big)^{\!\top} \frac{\partial L}{\partial \theta}
$$

In PyTorch you run f with `functional_call(target, unflatten(theta), (x,))` exactly as in Module 0, and `loss.backward()` does the rest.

```text
Hypernetwork data flow (the drawing is in COURSE.pdf, page 33–34)

[Input z: task ID, description, or a support set] --> [Hypernetwork H_ψ: the only trained weights ψ] --> [Generated θ = H_ψ(z): an output, not trained] --> [Target network: prediction f_θ(x), loss against label y]
                                                               ^                                                                                                        |
                                                               +- - - - - - - - - - training: gradients flow from the loss through θ into ψ - - - - - - - - - - - - - - +
```

The forward pass runs left to right; during training, the dashed path carries gradients from the target network's loss back through the generated weights θ into the hypernetwork's own weights ψ.

### 4.2 What the hypernetwork reads, and what it writes

The input z decides what the hypernetwork is *for*:

| Input z | Name | What it gives you | Example |
| --- | --- | --- | --- |
| A learned embedding per layer | Static hypernetwork | Weight sharing and compression across layers | Ha et al. (2016) for CNNs; Project 3 Part A |
| A task ID or task description | Task-conditioned hypernetwork | One model, many tasks; new tasks from new descriptions | Continual learning (von Oswald et al., 2020); Text-to-LoRA (2025); Project 3 Part B |
| The current input or hidden state | Dynamic hypernetwork | Weights that change per example or per time step | HyperLSTM (Ha et al., 2016) |
| A support set of examples | Amortised meta-learner | Few-shot adaptation in one forward pass | Learnet (Bertinetto et al., 2016); LEO (2019); Project 4 |
| A document or context | Context-to-weights | Knowledge stored in weights instead of the prompt | Doc-to-LoRA, SHINE (2026) |

The output can be all of θ or a cheaper part of it:

- **All weights** of a small network (Project 3 Part B, 1,761 weights).
- **Chunks**: the target is cut into fixed-size pieces, and one generator produces every piece from its own small chunk embedding (von Oswald et al., ICLR 2020).
- **Low-rank factors**: generate matrices A and B whose product A·B is a weight update, which is exactly a LoRA adapter.
- **Per-unit scale and shift** (FiLM, Perez et al., AAAI 2018): generate one multiplier and one offset per hidden unit. Exercise P3.3 builds this.

### 4.3 The static hypernetwork of Ha et al.

For a convolutional network, Ha et al. gave each layer j a small learned embedding z\_j and produced the layer's kernel with a two-layer *linear* generator shared by all layers. The first layer maps z\_j to several intermediate vectors a\_i, and the second maps each a\_i to one slice of the kernel. Because the generator is shared and the embeddings are small, the whole network needs far fewer trainable numbers than its weights. On CIFAR-10 wide residual networks they reported large parameter reductions for a modest accuracy cost. Project 3 Part A uses the same recipe for a deep MLP: each row of each 64×64 hidden matrix is produced from a 4-number embedding by one shared generator.

The same paper's *dynamic* HyperLSTM uses a small LSTM to emit scaling vectors that modulate a larger LSTM's weights at every time step. It was evaluated on character-level language modelling and handwriting generation.

### 4.4 Three ways to see why hypernetworks help

1. **Compression through structure.** Neighbouring layers or rows often need related weights. A shared generator encodes that relationship once.
2. **Multiplicative conditioning.** Concatenating a task vector to the input only shifts the first layer's pre-activations. Generating weights lets the condition *multiply* every layer, a far richer way for the task to change the function.
3. **Amortisation.** Instead of solving an optimisation problem for every new task (fine-tuning), you train a network once to approximate the solution map from task to weights. At test time a forward pass replaces the optimiser.

### 4.5 The output-size problem and its fixes

A hypernetwork's last layer has (hidden size) × (number of generated weights) parameters. Generating a 25-million-weight ResNet-50 directly from a 128-dimensional hidden layer would need about 3.3 billion parameters. Practical systems therefore generate less: chunks with a shared generator, low-rank factors, only adapters or the last layer, or one generator reused across layers with a layer-index embedding as input (the design used by Text-to-LoRA).

### 4.6 Initialisation matters more than usual

With ordinary initialisation of the hypernetwork, the *generated* weights usually have the wrong scale. Their variance depends on the hypernetwork's hidden size and activations, not on the target layer's fan-in. Activations in the target network can then explode or vanish, and training stalls. Oscar Chang, Lampros Flokas and Hod Lipson derived corrected schemes, *hyperfan-in* and *hyperfan-out*, in *Principled Weight Initialization for Hypernetworks* (ICLR 2020).

The core calculation is short. Suppose a generated weight is w = Σ\_k H\_k h\_k, where h is the hypernetwork's last hidden layer (size d\_k) and the H\_k are independent, zero-mean output weights. Then:

$$
\mathrm{Var}(w) = d_k \, \mathrm{Var}(H) \, \mathbb{E}[h^2]
\qquad\Rightarrow\qquad
\mathrm{Var}(H) = \frac{\text{gain}}{\text{fan\_in} \cdot d_k \cdot \mathbb{E}[h^2]}
$$

Choosing gain = 2 for ReLU layers gives generated weights the He-initialisation variance 2/fan\_in that the target layer would get from good direct initialisation. Project 3 implements this "variance-matched" initialisation (a simplified version in the spirit of hyperfan-in) and measures its effect.

Chang et al. also point out why badly initialised hypernetworks often train anyway: the Adam optimiser rescales each gradient by its own running magnitude, so it compensates for badly scaled gradients, at the price of noisier training. With plain SGD, or a target network deep enough for wrong scales to overflow, correct initialisation matters much more. Project 3 Part C shows the Adam case.

### 4.7 Hypernetworks and MAML compared

| Property | MAML | Amortised hypernetwork |
| --- | --- | --- |
| How it adapts | Gradient steps on the support set | One forward pass over the support set |
| Adaptation cost | Several forward and backward passes | One forward pass |
| More support data or more steps | Keeps improving | Gains little beyond the set sizes it was trained on; untrained extra steps can even hurt |
| Tasks outside the training distribution | Degrades sharply; gradient steps help only if α is small enough not to overshoot | Also degrades sharply; fine-tuning its outputs can diverge, since it was never trained to be fine-tuned |
| Meta-training memory | Grows with inner steps | Constant, but the output layer can be huge |
| Flexibility of the adapted model | Any network trainable by gradient descent | The generator must be designed for the target's size |

Project 4 measures every row of this table. Hybrids such as LEO (Module 3.6) and the capstone's "Hybrid" model generate a task-specific starting point, then refine it with gradient steps, aiming for the best of both.

### 4.8 Where hypernetworks are used

- **Continual learning.** von Oswald et al. (ICLR 2020) condition a hypernetwork on a task embedding and regularise its outputs for old embeddings, so earlier tasks are not forgotten.
- **Architecture and hyperparameter search.** SMASH (Brock et al., ICLR 2018) and Graph HyperNetworks (Zhang et al., ICLR 2019) generate weights for candidate architectures to rank them quickly; Self-Tuning Networks (MacKay et al., ICLR 2019) generate weights as a function of hyperparameters.
- **Image generation and editing.** HyperStyle (Alaluf et al., CVPR 2022) predicts weight offsets for StyleGAN to edit real photos; HyperDreamBooth (Ruiz et al., CVPR 2024) predicts personalisation weights for a text-to-image model from one face photo.
- **Multi-task language models.** HyperFormer (Karimi Mahabadi et al., ACL 2021) generates adapter weights per task; HyperTuning (Phang et al., ICML 2023) generates adapters from few-shot examples.
- **Instant adaptation of large language models.** Text-to-LoRA (Charakorn et al., ICML 2025) generates LoRA adapters from a plain-language task description. Doc-to-LoRA (February 2026) and SHINE (February 2026) map whole documents or contexts to adapters in one pass, and Code2LoRA (June 2026) does the same for code repositories. Module 5 discusses why this matters for agents.
- **Fast weights and attention.** Schlag, Irie and Schmidhuber (ICML 2021) showed that linear attention in transformers is formally a fast-weight programmer: the model writes a temporary weight matrix from its context. This links hypernetworks to in-context learning.

A readable overview is *A Brief Review of Hypernetworks in Deep Learning* (Chauhan et al., Artificial Intelligence Review, 2024).

### 4.9 Primer: LoRA, attention and the Perceiver

Module 5 and several examples above rely on three ideas from large-model engineering. This primer gives you what you need to follow them.

**LoRA (Low-Rank Adaptation; Hu et al., ICLR 2022).** To specialise a big pre-trained layer with weight matrix W₀ (size d\_out × d\_in) without retraining it, LoRA freezes W₀ and learns a *low-rank* update ΔW = B·A, where B is d\_out × r, A is r × d\_in, and the rank r is small (often 4 to 64). The layer computes:

$$
h = W_0 x + \frac{\alpha}{r} \, B A x
$$

α is a fixed scaling constant. B starts at zero, so the update is exactly zero at the start and training begins from the pre-trained behaviour. After training, B·A can be added into W₀, so serving costs nothing extra. In PyTorch:

```python
class LoRALinear(nn.Module):
    """y = W0 x + (alpha / r) * B A x, with W0 frozen and only A, B trained."""
    def __init__(self, base: nn.Linear, r=8, alpha=16):
        super().__init__()
        self.base = base
        for p in self.base.parameters():
            p.requires_grad_(False)                                  # W0 stays frozen
        self.A = nn.Parameter(torch.randn(r, base.in_features) * 0.01)
        self.B = nn.Parameter(torch.zeros(base.out_features, r))     # B = 0: the update starts at zero
        self.scale = alpha / r

    def forward(self, x):
        return self.base(x) + self.scale * (x @ self.A.T @ self.B.T)
```

For a 4,096 × 4,096 layer with r = 8, LoRA trains 65,536 numbers instead of 16,777,216: 0.39% (this snippet was run to check that count and that the layer's output is unchanged at initialisation). That smallness is exactly why hypernetworks generate LoRAs rather than full weights (Exercise 4.1, Q11 in the final assessment).

**Attention.** Attention lets each element of a sequence gather information from other elements. Each element is turned, by three learned linear maps, into a query q, a key k and a value v. For a matrix of queries Q, keys K and values V, with d the key size:

$$
\mathrm{Attention}(Q, K, V) = \mathrm{softmax}\!\Big(\frac{Q K^{\top}}{\sqrt{d}}\Big) V
$$

Each output is a weighted average of values, weighted by how well its query matches each key. In **self-attention**, Q, K and V all come from the same sequence; in **cross-attention**, the queries come from one set and the keys and values from another. A **transformer** stacks blocks of self-attention and a small MLP, each wrapped in a residual connection and normalisation. Self-attention compares every element with every other, so its cost grows with the square of the sequence length.

**The Perceiver (Jaegle et al., 2021).** A fixed number of learned "latent" vectors cross-attend to an input of any length. The output always has the same size, however long the input. That is why Doc-to-LoRA uses a Perceiver: documents vary in length, but a LoRA adapter must have a fixed shape. The DeepSets mean in Project 4 plays the same role in a simpler form.

**Linear attention as fast weights.** If the softmax is removed, the output for query q becomes (Σᵢ vᵢ kᵢᵀ) q: the sequence writes a matrix, the sum of outer products vᵢkᵢᵀ, which is then applied to q like a weight matrix. A network writing a weight matrix from its input is a dynamic hypernetwork, which is the observation of Schlag, Irie and Schmidhuber (2021) in Module 4.8.

**Exercise 4.8.** How many trainable numbers does a rank-16 LoRA add to one 1,024 × 4,096 layer, and what fraction of the layer is that?

*Answer.* r(d\_in + d\_out) = 16 × (4,096 + 1,024) = 81,920, against 4,194,304 weights in the layer: about 1.95%.

**Exercise 4.9.** Why is B initialised to zero rather than A?

*Answer.* Either choice makes B·A zero at the start, but gradients behave differently. With B = 0 and A random, the gradient for B is non-zero immediately (it depends on A·x), so training starts at once. If both were zero, both gradients would be zero and nothing would ever change. If A were zero and B random, A would get gradients, so that works too; zero-B with random A is the convention of the LoRA paper.

### Module 4 exercises

**Exercise 4.1.** A hypernetwork has a 128-unit last hidden layer and generates all 1,761 weights of the 1-40-40-1 sine network. How many parameters does its output layer have?

*Answer.* 128 × 1,761 weights plus 1,761 biases = 225,408 + 1,761 = 227,169. The generator's head is 129 times larger than the network it generates. That is fine for a small target, and the reason chunking exists for big ones.

**Exercise 4.2.** You chunk a 1,000,000-weight target into 1,000 chunks of 1,000 weights, with 16-dimensional chunk embeddings and a shared generator 16 → 64 → 1,000. Count the trainable parameters.

*Answer.* Embeddings: 1,000 × 16 = 16,000. Generator: (16 × 64 + 64) + (64 × 1,000 + 1,000) = 1,088 + 65,000 = 66,088. Total 82,088, about 12× fewer than the target. Whether that small model can express good weights is an empirical question, as Project 3 Part A shows.

**Exercise 4.3.** Derive the variance-matched initialisation formula of 4.6 and state its assumptions.

*Answer.* For w = Σ\_k H\_k h\_k with H\_k independent of h, zero mean, and identically distributed: Var(w) = Σ\_k Var(H\_k) E\[h\_k²\] = d\_k Var(H) E\[h²\]. Setting Var(w) = gain/fan\_in and solving gives the formula. The assumptions are independence and zero-mean output weights; E\[h²\] is estimated empirically by passing a batch of typical inputs through the hypernetwork at initialisation.

**Exercise 4.4.** Show that FiLM is a restricted hypernetwork.

*Answer.* A FiLM layer computes (1 + γ) ∘ (Wx + b) + β, where γ and β come from the conditioning network. That equals diag(1 + γ)W x + ((1 + γ) ∘ b + β): an effective weight matrix diag(1 + γ)W and bias generated from the condition. The hypernetwork generates only a diagonal multiplier and a shift, not the whole matrix.

**Exercise 4.5.** Classify: (a) HyperLSTM; (b) Text-to-LoRA; (c) Learnet, which predicts a classifier's parameters from one example image; (d) Project 3 Part A.

*Answer.* (a) Dynamic: its weights change with every time step's input. (b) Task-conditioned, by a text description. (c) Support-set-conditioned, an amortised one-shot learner. (d) Static: fixed learned layer embeddings.

**Exercise 4.6.** Why can a hypernetwork conditioned on a one-hot task ID not generalise to a brand-new task, while one conditioned on a task description can?

*Answer.* A new task has no ID the network has seen, and one-hot codes carry no notion of similarity between tasks. A descriptor such as an amplitude and phase, a text embedding, or an encoded support set places tasks in a continuous space, so a new task lands near related training tasks and the hypernetwork can interpolate. It still cannot extrapolate far beyond them (Exercise P3.2).

**Exercise 4.7.** For a linear hypernetwork θ = Ψz, write ∂L/∂Ψ and ∂L/∂z.

*Answer.* With g = ∂L/∂θ: ∂L/∂Ψ = g zᵀ (an outer product) and ∂L/∂z = Ψᵀ g. Each training example therefore updates Ψ with a rank-one matrix, and the embedding moves along the directions in which the generated weights matter for the loss.

## Project 3: Building hypernetworks

You will build two hypernetworks and learn two lessons about evaluating them. A static hypernetwork classified a hard 2-D problem as well as an ordinary deep network, but so did an ordinary network of the *same small size*, so this problem demonstrates no compression benefit. A task-conditioned hypernetwork learned to write all 1,761 weights of a sine regressor from three numbers describing the wave. All results are averaged over 3 random seeds. Code: `04_hypernetworks.py`, about 5 minutes on one core.

### Part A: a static hypernetwork

**The problem.** Two interleaved spirals in 2-D, 1,000 points per class, labelled 0 and 1. Separating them needs a deep, flexible decision boundary.

**Step A1: the direct network.** Input layer 2 → 64, then 8 residual blocks h ← h + ReLU(W\_l h + b\_l) with 64 × 64 matrices, then 64 → 1. It has 33,537 parameters, of which 33,280 sit in the 8 hidden blocks.

**Step A2: the hypernetwork version.**

*Task.* Replace the 8 hidden weight matrices with outputs of a hypernetwork: every *row* of every matrix is generated from its own 4-number embedding by one shared generator g: ℝ⁴ → ℝ⁶⁴ (4 → 32 → ReLU → 64).

*Solution.*

```python
class StaticHyperMLP(nn.Module):
    def __init__(self, z_dim=4, gen_hidden=32):
        super().__init__()
        self.inp, self.out = nn.Linear(2, 64), nn.Linear(64, 1)
        self.z = nn.Parameter(torch.randn(8, 64, z_dim))          # one embedding per row
        self.hidden_bias = nn.Parameter(torch.zeros(8, 64))
        self.gen = nn.Sequential(nn.Linear(z_dim, gen_hidden), nn.ReLU(),
                                 nn.Linear(gen_hidden, 64))       # shared generator
        with torch.no_grad():                                     # match He-init scale
            self.gen[2].bias.zero_()
            self.gen[2].weight.mul_(math.sqrt(2 / 64) / self.gen(self.z).std())

    def forward(self, x):
        W = self.gen(self.z)                                      # (8, 64, 64), generated
        h = F.relu(self.inp(x))
        for l in range(8):
            h = h + F.relu(h @ W[l].T + self.hidden_bias[l])
        return self.out(h).squeeze(-1)
```

Count the trainable numbers: input and output layers 257, embeddings 8 × 64 × 4 = 2,048, hidden biases 512, generator 4 × 32 + 32 + 32 × 64 + 64 = 2,272. Total 5,089, against 33,537. The 8 matrices themselves are never stored as parameters.

**Step A3: train three models, three seeds each.** The full-width direct network (33,537 parameters), a *size-matched* direct network of width 22 (4,137 parameters), and the static hypernetwork (5,089). Adam, learning rate 0.001, 3,000 full-batch steps, gradient norm clipped to 1.0 for every model. The size-matched network is the comparison that matters: a compression claim means nothing unless an ordinary network of similar size does worse.

**Results** (test accuracy, mean over 3 seeds, with the range):

| Model | Trainable parameters | Test accuracy |
| --- | --- | --- |
| Direct, width 64 | 33,537 | 99.73% (99.65 to 99.80) |
| Direct, width 22 (size-matched) | 4,137 | 99.70% (99.60 to 99.75) |
| Static hypernetwork | 5,089 | 99.68% (99.60 to 99.80) |

The three are indistinguishable: their ranges overlap almost completely. The spirals are simply too easy to reveal a capacity difference, so the hypernetwork's 6.6-fold reduction relative to the wide network is not evidence of compression; a plain small network achieves the same. An earlier version of this course claimed a compression benefit from the first two rows alone. That is the mistake this step teaches you to avoid. To see a real effect you need a task where the small direct network clearly fails and the hypernetwork does not; Ha et al. demonstrated this on CIFAR-10 image classification, far beyond a CPU-sized project.

**Two failures on the way, and why they matter.** The first version had no residual connections; the hypernetwork version then stayed at chance (loss 0.693 = ln 2) whatever the learning rate. The second version trained, but its loss spiked repeatedly and, in one 3,000-step run, collapsed back to 63.7% accuracy just before the end. Clipping the gradient norm to 1.0 removed the collapse. Hypernetworks are known to be harder to optimise than the networks they generate: every generated weight depends on the same shared generator, so one bad update moves all of them at once. Residual connections and gradient clipping are standard defences.

### Part B: a task-conditioned hypernetwork

**The problem.** The sine tasks of Project 1. This time the network is *told* each task's amplitude A and phase p. That is easier than few-shot learning, and isolates the hypernetwork's job: map a task description to weights.

**Step B1: flatten and unflatten.** The target network is Project 1's 1-40-40-1 MLP. Record each parameter's name, shape and size, so a flat vector of 1,761 numbers can be cut back into a parameter dictionary:

```python
def unflatten(flat):
    out, i = {}, 0
    for k, shp in shapes.items():
        out[k] = flat[i:i + sizes[k]].view(shp); i += sizes[k]
    return out

def target_forward(flat_w, x):
    return functional_call(target, unflatten(flat_w), (x,))

batched_forward = vmap(target_forward)       # different weights for every task
```

`vmap` with default `in_dims=0` splits both the weights and the inputs by task, the answer to Exercise 0.5.

**Step B2: the hypernetwork.** Input: the descriptor (A/5, sin p, cos p). Encoding the phase as sine and cosine makes nearby phases look similar to the network. Body: 3 → 128 → 128 with ReLU. Head: a linear layer 128 → 1,761. Total 244,193 parameters: the hypernetwork is 139 times larger than the network it writes, because of the output-size problem of Module 4.5.

**Step B3: train.** Each step: sample 32 tasks with 20 points each, generate 32 weight vectors, run the 32 target networks with `batched_forward`, take the MSE, backpropagate into the hypernetwork. 6,000 steps with Adam at 0.001.

**Results.** On 500 new tasks with 100 points each, the test MSE over 3 seeds was 0.0049 on average (0.0034, 0.0026 and 0.0087) with the initialisation of Part C, and 0.0020 (0.0038, 0.0013 and 0.0008) with PyTorch's default initialisation. The hypernetwork has learned the map from task description to function. Do not compare these numbers with Project 1's MAML results: the test tasks differ, and here the network is *given* the amplitude and phase that MAML has to infer from 10 points.

### Part C: does initialisation matter here?

The script builds the hypernetwork in two ways and inspects the weights it generates before any training:

| Generated weights at initialisation | Layer 0 (fan-in 1) | Layer 2 (fan-in 40) | Layer 4 (fan-in 40) | Target output std |
| --- | --- | --- | --- | --- |
| Default PyTorch init of the hypernetwork | 0.098 | 0.107 | 0.099 | 0.091 |
| Variance-matched init (Module 4.6) | 1.254 | 0.227 | 0.153 | 2.150 |
| He-initialisation reference | 1.414 | 0.224 | 0.158 | not applicable |

With default initialisation, every generated layer gets roughly the same standard deviation, about 0.1, whatever its fan-in, so the first layer's weights are 14 times smaller than a good direct initialisation. Variance matching puts each layer close to the He reference, as designed.

Did the "correct" scale help training? **No, it hurt here.** Over 3 seeds, the default initialisation reached a lower average test MSE (0.0020) than variance matching (0.0049), and variance matching had the single worst seed (0.0087). In the 1,000-step quick run it was the other way round (0.019 against 0.036), so early in training the comparison can flip. Two likely reasons. First, Adam rescales every gradient by its own running size, which compensates for badly scaled hypernetwork outputs; Chang et al. themselves note that ad-hoc initialisations often work for this reason. Second, He scaling on a first layer with fan-in 1 multiplies inputs as large as ±5 by weights of standard deviation 1.4, so the variance-matched network starts with large outputs (standard deviation 2.15) and a high initial loss. The lesson is not that initialisation never matters: Chang et al. report more stable target weights, lower training loss and faster convergence with their principled schemes, and the effect grows when the optimiser cannot compensate. The lesson is to measure your own case, with several seeds, before believing any recipe, including this course's.

### Project 3 exercises

**Exercise P3.1.** Verify the parameter counts 33,537 and 5,089 by hand.

*Answer.* Direct, width 64: input 2 × 64 + 64 = 192; hidden 8 × (64 × 64 + 64) = 33,280; output 65; total 33,537. Direct, width 22: 66 + 8 × (22 × 22 + 22) + 23 = 4,137. Hypernetwork: 192 + 65 + 2,048 + 512 + 2,272 = 5,089. The script prints all three, and an automatic check confirms 5,089.

**Exercise P3.2.** Evaluate the task-conditioned hypernetwork on amplitudes from \[5, 10\], never seen in training. Predict first.

*Answer.* Course run: test MSE 0.835, about 250 times worse than in-distribution. The descriptor A/5 now lies in \[1, 2\], outside the training range \[0.02, 1\], and the hypernetwork has no way to correct itself: it has no data from the task, only the description. Compare Exercise 4.6.

**Exercise P3.3.** Replace full weight generation with FiLM: a shared 1-40-40-1 network whose two hidden layers are scaled and shifted per unit, (1 + γ)·h + β, with γ and β generated from the descriptor.

*Answer.* The script's `FiLMNet` does this, initialising the FiLM head to zero so it starts as the plain network. Course run, 3 seeds: test MSE 0.0011 on average (0.0012, 0.0015 and 0.0005) with 22,913 parameters, against 0.0020 to 0.0049 with 244,193 parameters for full weight generation. Generating less was better here: the shared network carries what all tasks have in common, and the hypernetwork only has to express how tasks differ. This is the same reasoning behind generating LoRA adapters rather than full weights (Module 4.9).

**Exercise P3.4.** Train the static hypernetwork without gradient clipping and plot the loss every 300 steps.

*Answer.* In the course investigation the loss went 2.35, 0.07, 0.03, then spiked to 0.56, recovered to 0.007, and spiked again to 0.66 at the end, leaving 63.7% test accuracy. With clipping at norm 1.0: steady decline to 0.006 and 99.7% accuracy. The script prints the unclipped result at the bottom.

**Exercise P3.5.** Make the static hypernetwork's generator *linear* (remove the ReLU), as in Ha et al. What does that imply mathematically for the rank of each generated 64 × 64 matrix?

*Answer.* Each row is then an affine function of a 4-dimensional embedding, so every generated matrix has rank at most 5 (4 from the embedding plus 1 from the generator's bias). That is a strong constraint for a 64 × 64 layer, and a good example of how a hypernetwork's architecture decides which weights it *can* express. With the ReLU, rank is limited by the 32 hidden units instead: rank at most 33.

## Project 4 (capstone): MAML vs amortised hypernetwork vs hybrid

You will pit three ways of adapting to a new sine task against each other under one training budget, with 3 random seeds per method. Averaged over seeds, a hypernetwork that reads the 10 support points and writes the regressor's weights in one forward pass reached a query MSE of 0.028 ± 0.004, about 4.6 times lower than MAML after 10 gradient steps (0.130 ± 0.010), and adapted 15 times faster. A hybrid that generates a starting point and then takes MAML-style steps was best, at 0.008 ± 0.002. All three methods failed badly outside the training distribution. Code: `05_capstone.py`, about 11 minutes on one core.

### The three contestants

1. **MAML**: a learned initialisation θ, then SGD steps on the support set. Exactly Project 1.
2. **HyperNet (amortised)**: a set encoder reads the support set, and a hypernetwork outputs all 1,761 weights of the regressor. No gradient steps during training; at test time, one forward pass.
3. **Hybrid**: the same encoder and hypernetwork, but its output is used as a task-specific *starting point* for one MAML-style SGD step during meta-training, with gradients flowing through that step. This is the idea behind LEO (Module 3.6).

All three use the same target network (1-40-40-1), the same kind of episodes (K = 10 support and 10 query points, meta-batch 25), the same inner step size α = 0.01, and 10,000 outer updates with Adam at 0.001. Each method is trained with seeds 0, 1 and 2, and every number below is the mean (± standard deviation) over those 3 seeds.

### Step 1: shared pieces

The sampler, `unflatten` and the target network come from Projects 1 and 3. One new helper runs differentiable SGD for any parameter dictionary, and works inside `vmap`:

```python
def sgd_steps(params, x, y, steps, lr):
    for _ in range(steps):
        g = grad(mse)(params, x, y)
        params = {k: params[k] - lr * g[k] for k in params}
    return params
```

### Step 2: the set encoder and hypernetwork

*Task.* Build a network that takes a support set of any size K and returns 1,761 weights, and whose output does not depend on the order of the support points.

*Solution.* A DeepSets encoder (Zaheer et al., 2017): embed each (x, y) pair with a small network φ, average the embeddings, and transform the average with a second network ρ. Averaging makes the result order-independent and accepts any K.

```python
class SetHyperNet(nn.Module):
    def __init__(self, hidden=128):
        super().__init__()
        self.phi = nn.Sequential(nn.Linear(2, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())
        self.rho = nn.Sequential(nn.Linear(hidden, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())
        self.head = nn.Linear(hidden, N_TARGET)
        base = make_target()                     # a fresh, seeded initialisation
        self.base = nn.Parameter(torch.cat([v.detach().flatten() for v in base.parameters()]))
        nn.init.zeros_(self.head.bias)
        with torch.no_grad():
            self.head.weight.mul_(0.1)        # start as small deltas around a learned base

    def forward(self, xs, ys):
        pairs = torch.cat([xs / 5.0, ys / 5.0], -1)
        r = self.rho(self.phi(pairs).mean(1))
        return self.base + self.head(r)       # (tasks, 1761)
```

The output is a learned base weight vector plus a task-specific delta. Scaling the head down at initialisation keeps the first generated networks well-behaved: a cheap alternative to the variance matching of Project 3.

### Step 3: three outer losses

*Task.* Write the meta-training loss of each method as a function of a batch of tasks.

*Solution.* MAML adapts shared θ; the hypernetwork methods adapt generated weights, with 0 steps (HyperNet) or 1 step (Hybrid):

```python
def loss_maml(model, xs, ys, xq, yq, steps):
    theta = dict(model.named_parameters())
    one = lambda th, xs, ys, xq, yq: mse(sgd_steps(th, xs, ys, steps, 0.01), xq, yq)
    return vmap(one, in_dims=(None, 0, 0, 0, 0))(theta, xs, ys, xq, yq).mean()

def loss_hyper(hn, xs, ys, xq, yq, steps=0):
    flat = hn(xs, ys)                                     # one weight vector per task
    one = lambda w, xs, ys, xq, yq: mse(sgd_steps(unflatten(w), xs, ys, steps, 0.01), xq, yq)
    return vmap(one)(flat, xs, ys, xq, yq).mean()
```

Note the `in_dims`: MAML shares θ across tasks (`None`), the hypernetwork methods split their per-task weights (`0`).

### Step 4: evaluation scenarios

Every method is tested on the same 500 seeded tasks, with 100 query points each, after 0, 1 and 10 test-time SGD steps:

- **In-distribution, K = 10**: the training setting.
- **In-distribution, K = 5**: less data than in training.
- **More data, K = 40**: does the method use extra evidence?
- **Out of distribution**: amplitudes from \[5, 10\], with α = 0.01 and with a safer α = 0.002.

### Step 5: results

Query MSE after 0 / 1 / 10 test-time steps, mean over 3 seeds (lower is better). "Diverged" means the error exploded to NaN or above 1,000:

| Scenario | MAML | HyperNet | Hybrid |
| --- | --- | --- | --- |
| In-distribution, K = 10 | 3.163 / 0.460 / 0.130 | 0.028 / 0.024 / 0.044 | 0.060 / 0.019 / 0.008 |
| In-distribution, K = 5 | 3.141 / 0.782 / 1 of 3 seeds diverged (others 0.382, 0.343) | 0.081 / 0.076 / 0.118 | 0.140 / 0.065 / 0.044 |
| More data, K = 40 | 3.148 / 0.239 / 0.040 | 0.015 / 0.010 / 0.015 | 0.033 / 0.007 / 0.002 |
| Out of distribution, α = 0.01 | 23.573 / 7.562 / all 3 diverged | 3.184 / 6.444 / all 3 diverged | 4.016 / 4.920 / all 3 diverged |
| Out of distribution, α = 0.002 | 23.573 / 15.328 / 5.611 | 3.184 / 2.250 / 1.143 | 4.016 / 2.458 / 0.888 |

| Cost | MAML | HyperNet | Hybrid |
| --- | --- | --- | --- |
| Trainable parameters | 1,761 | 278,850 | 278,850 |
| Time to adapt one task (one core) | 3.07 ms (10 steps) | 0.20 ms (forward pass) | 3.34 ms (forward pass + 10 steps) |

The script also saves `outputs/p4_comparison.png`, one panel per scenario.

![Capstone results, mean over 3 seeds: query MSE against test-time SGD steps for MAML, HyperNet and Hybrid in five scenarios, log scale](reference_figures/p4_comparison.png)

*Figure P4. Query MSE (log scale) against test-time SGD steps, mean over 3 seeds; points where the mean exploded are not drawn. Panels left to right: in-distribution K = 10, K = 5, K = 40, out of distribution with α = 0.01, and out of distribution with α = 0.002. Blue: MAML; orange: HyperNet; green: Hybrid.*

### Step 6: what the results say

1. **On this problem, amortisation wins in-distribution.** With no gradient steps, HyperNet's error (0.028 ± 0.004) was about 4.6 times lower than MAML's after 10 steps (0.130 ± 0.010), at one-fifteenth of the adaptation time, and the gap held in every seed. Keep the scope in mind: every sine task is described by just two numbers, amplitude and phase, which is the ideal case for learning a direct map from data to weights, and the hypernetwork has 158 times more parameters.
2. **Untrained steps can hurt.** HyperNet was never trained to be fine-tuned. On average, 10 SGD steps on its output *raised* its in-distribution error from 0.028 to 0.044, with a large spread between seeds (± 0.018). The Hybrid behaves the opposite way: its 0-step error (0.060) is worse than HyperNet's, but each step improves it, down to 0.008. It learned to produce a good *starting point*, not a final answer. Only behaviour optimised during meta-training is reliable at test time.
3. **Gradient-based methods use extra data; the amortised one barely does.** From K = 10 to K = 40, MAML's 10-step error fell from 0.130 to 0.040 and the Hybrid's from 0.008 to 0.002, but HyperNet's 0-step error only from 0.028 to 0.015: its mean-pooled encoder was trained only on sets of 10. With fewer points (K = 5), one of MAML's three seeds diverged during 10 test steps, a reminder that a fixed α can fail on individual tasks even in-distribution.
4. **Nobody extrapolates.** On amplitudes from \[5, 10\], errors were tens to hundreds of times their in-distribution values. With α = 0.01, every seed of every method diverged by step 10. After a single step, MAML improved (23.6 to 7.6) while both hypernetwork methods got *worse* (3.18 to 6.44 and 4.02 to 4.92): the one place where MAML's purely gradient-based adaptation behaved more sensibly. With the safer α = 0.002, all three improved steadily, and the hypernetwork methods stayed far ahead (1.14 and 0.89 against 5.61). Outside the task distribution no meta-learner is safe, and the step size is a hidden part of every method.
5. **The hybrid is the practical sweet spot.** It was best after 10 steps in every in-distribution scenario, at about MAML's test-time cost. This is why systems such as LEO combine a generated starting point with a few gradient steps.

### How fair is this comparison?

Three caveats remain. First, the hypernetwork methods have 158 times more parameters than MAML (Exercise P4.3 addresses this). Second, three seeds are the minimum for a claim, not a guarantee: they caught a rare MAML divergence at K = 5 that a single run would have missed, and an earlier, single-run version of this project reported out-of-distribution step-by-step behaviour that did not hold up across seeds. Third, the encoder only ever saw K = 10 during training (Exercise P4.2).

### Project 4 exercises

**Exercise P4.1 (reproducibility).** Increase the number of seeds from 3 to 5 and report each number as mean ± standard deviation. Which conclusions change?

*Answer.* The script already seeds everything (the target template, each method's initialisation, and its training tasks) and runs seeds 0, 1 and 2. Extending `CFG["seeds"]` to 5 costs about 7 more minutes. Expect the in-distribution ranking (Hybrid after 10 steps, then HyperNet without steps, then MAML after 10 steps) to stay the same, since it held in all three seeds with wide margins. Expect rare events, like MAML's divergence at K = 5, to need many more seeds before you can say how often they happen. Never base a conclusion on one run when a second run can reverse it.

**Exercise P4.2.** Train the hypernetwork methods with K drawn at random from 5 to 40 in each meta-batch. What do you expect at K = 40?

*Answer.* The encoder learns that larger sets carry more reliable information, so HyperNet's K = 40 error should fall further toward the Hybrid's. Matching the training distribution of set sizes to the test distribution is the same principle as matching the task distribution (Module 1.2).

**Exercise P4.3.** Give MAML a comparable parameter budget: a 1-128-128-1 target (about 16,900 parameters) or 1-256-256-1 (about 66,600). Does the gap close?

*Answer.* Larger targets make MAML's inner steps more expressive and usually reduce its error, but MAML still has to discover each task's function by gradient descent from 10 points, while the hypernetwork *recognises* it. Expect the gap to narrow but not vanish on this problem. Report results with the same seeded test tasks.

**Exercise P4.4.** Replace mean pooling in the encoder with attention pooling: a learned query vector attends over the per-point embeddings.

*Answer.* Attention lets the encoder weight informative points (for example peaks of the wave) more heavily. It tends to help most when K varies widely or the support set is noisy. This is the same move from DeepSets to Perceiver-style encoders made by Doc-to-LoRA (Module 5.3).

**Exercise P4.5.** Use a learned per-parameter step size (Meta-SGD) in the Hybrid's inner step. Which failure from Step 6 could it reduce?

*Answer.* A learned step size per weight lets meta-training shrink steps for weights whose gradients are large or unreliable. That can reduce divergence when the hypernetwork's starting point lies in a sharply curved region. It does not solve extrapolation: the learned rates are still tuned only for the training task distribution.

**Exercise P4.6 (design memo).** Your team builds an agent that must adapt to each new customer from a few examples. Using this project's evidence, write a three-sentence recommendation.

*Answer.* For customers resembling the training population, generate adapters with a support-set-conditioned hypernetwork: it is the most accurate and by far the fastest. Meta-train it *through* a few gradient steps (the hybrid), so that when a customer provides more examples or the generated adapter is off, fine-tuning reliably improves it. Detect out-of-distribution customers, fall back to smaller, validated step sizes or human review, and evaluate on held-out customers with several seeds.

## Module 5: The field in November 2026, and why agents need it

The few-shot benchmark race of 2017 to 2021 has largely ended, but its two central ideas are now everywhere: learning to adapt across a distribution of tasks (MAML's idea) and generating weights with a network (the hypernetwork idea). Today they appear as in-context learning in foundation models, as test-time training, and as hypernetworks that write adapters for large language models.

### 5.1 In-context learning is meta-learning at scale

A language model pre-trained on billions of documents has, in effect, been meta-trained on an enormous task distribution: every document is a small "task" whose earlier part works like a support set for predicting the later part. At inference, the examples in your prompt are a support set and the model adapts without any weight update. That is model-based meta-learning (Module 1.6).

This is not just an analogy. Garg et al. (NeurIPS 2022) trained transformers on prompts of (x, y) pairs from random linear functions and found they learn to do regression in context, close to least squares. von Oswald et al. (ICML 2023) showed that a linear self-attention layer can implement a step of gradient descent on the in-context examples, so in-context learning and MAML-style adaptation can be mathematically related.

The clearest production example is **TabPFN** (Hollmann et al., *Nature*, January 2025). A transformer is meta-trained on millions of *synthetic* tabular datasets. On a new real dataset it reads the training rows and predicts the test rows in one forward pass, with no gradient steps, and the authors report that it beats tuned gradient-boosted trees on datasets of up to 10,000 samples. Prior Labs released version 2.5 in November 2025. This is the episode structure you built in Module 1, scaled up.

### 5.2 Gradient-based adaptation is alive and well

Fine-tuning with gradients never went away; it got cheaper. LoRA (Hu et al., ICLR 2022) trains small low-rank updates instead of all weights, and is the default way to specialise large models. Test-time training takes MAML's inner loop into deployment: Akyürek et al. (November 2024, revised March 2025) showed that briefly fine-tuning a language model on each test problem's own demonstration examples improves few-shot reasoning substantially: on the ARC benchmark, up to 6 times the accuracy of their fine-tuned baselines, reaching 53.0% on the public validation set with an 8-billion-parameter model. MAML's lesson still applies: an initialisation that has been *trained to be adapted* adapts better than one that merely performs well on average.

### 5.3 Hypernetworks that write adapters

The most direct descendants of this course's two topics are hypernetworks that output LoRA adapters for a frozen language model:

- **Text-to-LoRA** (Charakorn, Cetin, Tang and Lange, Sakana AI; ICML 2025) reads a natural-language task description and generates a task-specific LoRA in one forward pass. Trained on a library of existing adapters, it can reproduce them and produce adapters for unseen tasks.
- **Doc-to-LoRA** (Sakana AI, February 2026) meta-learns a hypernetwork, built on the Perceiver architecture so it accepts inputs of any length, that turns a document into an adapter. Later questions can then be answered without the document in the prompt, which saves context-window space and latency.
- **SHINE** (Liu et al., February 2026) scales a context-to-LoRA hypernetwork with a pre-training and instruction-tuning pipeline.
- **Code2LoRA** (June 2026) generates repository-specific adapters for code models and tracks a repository as it evolves.

These systems are amortised meta-learners exactly like your capstone "HyperNet" model, with a text or document encoder in place of the DeepSets encoder and a LoRA in place of a 1-40-40-1 network. They also inherit its weakness. An April 2026 analysis of Doc-to-LoRA-style methods ("The Override Gap") found that generated adapters struggle to override facts the base model learned strongly during pre-training: their effect has a roughly fixed size, while pre-trained beliefs vary in strength. That is a large-scale version of what you will measure in Project 4: amortised adaptation is fast but bounded by what the generator learned.

### 5.3b Fast weights inside the architecture

A third line of work builds the "network writes weights at test time" idea into the model itself. **TTT layers** (Sun et al., *Learning to (Learn at Test Time): RNNs with Expressive Hidden States*, July 2024) make a sequence layer's hidden state a small model, a linear map (TTT-Linear) or a two-layer MLP (TTT-MLP), and update it with a gradient step of a self-supervised loss on each new token. Reading a sequence is literally training an inner model on it: MAML's inner loop, running inside every forward pass. In their experiments at 125 million to 1.3 billion parameters, both variants matched or beat a strong Transformer and the Mamba recurrent model, and, unlike Mamba, kept improving with context beyond 16,000 tokens. **Titans** (Behrouz, Zhong and Mirrokni, Google Research, December 2024) add a neural long-term memory module that learns to memorise context into its parameters at test time, alongside attention for the current context, and the authors report scaling beyond 2 million tokens of context.

The link to this course is direct. These layers are *meta-learned* learners: the outer training loop learns how the inner, test-time update should work, exactly as MAML learns an initialisation for its inner loop and a hypernetwork learns how to map data to weights.

### 5.4 What this means for agentic systems

An agent is a model that acts in a loop: it plans, calls tools, reads results and continues. Agents constantly meet new tasks: a new user's preferences, a new codebase, an unfamiliar API, a new environment. Every adaptation mechanism in this course is an option for them, with a different cost profile:

| Mechanism | How the agent adapts | Latency | Data needed | Persists across sessions | Course link |
| --- | --- | --- | --- | --- | --- |
| In-context learning | Put examples, instructions or retrieved notes in the prompt | None beyond reading | A few examples | No, unless stored in external memory | Module 1.7, 5.1 |
| Amortised weight generation | A hypernetwork turns a description, document or examples into an adapter | One forward pass | A description or a document | Yes, the adapter can be cached | Module 4, Project 4 |
| Gradient adaptation from a meta-learned start | A few fine-tuning steps from an initialisation trained for adaptability | Seconds to minutes | Tens of labelled examples | Yes | Modules 2 and 3, Projects 1 and 2 |
| Full fine-tuning | Ordinary training on a task dataset | Hours | Hundreds or more examples | Yes | Exercise 1.6 baseline |

Three engineering lessons from the course carry over directly:

1. **Define the task distribution, then hold some of it out.** An agent's adapter generator must be evaluated on users, repositories or tools it never saw in meta-training, the equivalent of disjoint class splits.
2. **Measure adaptation, not just performance.** Log quality before and after adaptation (Module 3.10, item 3). If adaptation adds nothing, you are paying for an inner loop that does nothing.
3. **Expect amortised methods to fail outside their training distribution.** Keep a gradient-based or retrieval fallback for unusual tasks, which is the logic of the capstone's hybrid model.

One security note: a hypernetwork that turns documents into weights turns *untrusted text* into *model behaviour*. Treat generated adapters from external content with the same caution as untrusted prompt content, and evaluate them before deployment.

### Module 5 exercises

**Exercise 5.1.** Map these in-context-learning terms to meta-learning terms: the examples in a prompt; the user's actual question; pre-training on many documents.

*Answer.* Prompt examples are the support set. The question is a query example. Pre-training across documents is meta-training over a task distribution.

**Exercise 5.2.** Choose an adaptation mechanism for each case and justify it. (a) A coding agent joins a new repository and must follow its conventions in every future session. (b) A support agent must adopt a customer's tone after seeing 3 emails, within one conversation. (c) A robot must handle a new gripper weight with 50 trial grasps.

*Answer.* (a) A persistent adapter: generated from the repository by a Code2LoRA-style hypernetwork if one exists, otherwise LoRA fine-tuning, with retrieval over the codebase alongside. (b) In-context learning: 3 examples, one session, no need to persist. (c) Gradient adaptation from a meta-learned initialisation: there is a little real data, the change is physical and continuous, and meta-learned dynamics adaptation has been demonstrated on real robots (Nagabandi et al., ICLR 2019, who adapted a legged robot to new terrain and leg damage). Note that MAML's own reinforcement-learning experiments changed the task's goal, such as target velocity or direction, not the robot's dynamics.

**Exercise 5.3.** Design an evaluation protocol for a Doc-to-LoRA-style system that will help an agent answer questions about internal company documents.

*Answer.* Split documents by source or team into meta-train, meta-validation and meta-test sets, so test documents come from teams the generator never saw. For each test document, write held-out questions (the query set). Compare four conditions on the same questions: no document; document in the prompt; generated adapter; adapter plus document. Report accuracy with confidence intervals, plus latency and memory. Include questions whose answers contradict common knowledge, to test the override gap.

**Exercise 5.4.** Why might TabPFN fail on a dataset with 1,000,000 rows, even though it works on 10,000?

*Answer.* It was meta-trained on a task distribution of small and medium datasets, and its forward pass must read every training row as context. A million rows is outside the training distribution (Exercise 1.5 again) and also expensive in compute and memory. Gradient-boosted trees, trained conventionally, remain a strong choice there.

## Final assessment

Fifteen questions covering the whole course, with a full answer key after them. Allow about 2 hours, work without the doc open, and score yourself: 13 or more correct means you have mastered the material; 9 to 12 means revisit the modules named in the key; fewer than 9 means redo the projects.

### Questions

**Q1.** Define the support set and the query set, and explain why meta-training computes its loss on the query set.

**Q2.** A 20-way 5-shot task has 5 query images per class. How many support images, how many query images, and what is chance accuracy?

**Q3.** Write the MAML meta-gradient for two inner steps in terms of the Hessians at θ and at the first adapted weights φ¹.

**Q4.** A one-dimensional task has support loss ½k(θ − a)² and query loss ½(θ − b)², where k is the curvature. Derive the MAML gradient. What happens when αk = 1, and what does that tell you about choosing α?

**Q5.** A student writes this inner loop. Which algorithm did they implement?

```python
grads = torch.autograd.grad(loss, list(params.values()))
phi = {k: v - lr * g for (k, v), g in zip(params.items(), grads)}
```

**Q6.** Another student adapts with `inner_opt = torch.optim.SGD(model.parameters(), lr=0.01)` and `inner_opt.step()`, then computes the query loss with `model(xq)`. What goes wrong?

**Q7.** Over 600 test tasks, per-task accuracies have mean 0.912 and standard deviation 0.08. Report the result with a 95% confidence interval.

**Q8.** When would you choose ANIL over MAML, and when not?

**Q9.** Write the Reptile update for one task with k inner steps, and explain why k = 1 is not meta-learning.

**Q10.** Why does iMAML's memory not grow with the number of inner steps?

**Q11.** A hypernetwork with a 256-unit hidden layer generates a rank-8 LoRA (matrices A of 8 × 4096 and B of 4096 × 8) for one 4096 × 4096 layer. How many parameters does its output layer need? How does Text-to-LoRA avoid multiplying that by every layer of the model?

**Q12.** Compute the variance-matched initialisation standard deviation for a hypernetwork head generating a ReLU layer with fan-in 40, from a 128-unit hidden layer with E\[h²\] = 0.5.

**Q13.** In Project 4, ten test-time SGD steps on the plain HyperNet's generated weights *raised* its average in-distribution error from 0.028 to 0.044, while the Hybrid, which starts worse (0.060), improved with every step to 0.008. Explain both observations.

**Q14.** You must personalise a speech recogniser to a new speaker from 30 seconds of audio, on-device, in under one second. Sketch a meta-learning design and its training and evaluation protocol.

**Q15.** True or false, with one line of justification each. (a) FOMAML ignores the adapted weights entirely. (b) A hypernetwork's generated weights are trainable parameters. (c) Meta-test classes may overlap meta-train classes as long as the images differ. (d) BatchNorm with batch statistics makes evaluation transductive. (e) A FiLM layer is a restricted hypernetwork.

### Answer key

**A1.** The support set is the few labelled examples used to adapt to a task; the query set is held-out data from the same task used to judge the adapted model. Using the query loss rewards *generalisation* from the support set. A loss on the support set itself would reward memorising it. (Module 1.3)

**A2.** Support: 20 × 5 = 100. Query: 20 × 5 = 100. Chance: 1/20 = 5%. (Module 1.4)

**A3.** With φ¹ = θ − α∇L^s(θ) and φ² = φ¹ − α∇L^s(φ¹):

$$
\nabla_\theta L^{q}(\phi^2) = \big(I - \alpha H(\theta)\big)\big(I - \alpha H(\phi^1)\big)\, \nabla_\phi L^{q}(\phi^2)
$$

The Hessians are symmetric, so the order shown is the one autograd computes when it backpropagates from the last step to the first. (Module 2.4)

**A4.** φ = θ − αk(θ − a), so dφ/dθ = 1 − αk, and the MAML gradient is (1 − αk)(φ − b). When αk = 1 one step lands exactly on a regardless of θ, so the meta-gradient is zero and θ cannot learn anything. A good α depends on the curvature of the task losses; too large (αk > 2) diverges. This is one motivation for learning α per layer (MAML++) or per parameter (Meta-SGD). (Modules 2 and 3)

**A5.** First-order MAML. Without `create_graph=True` the gradients are constants, so the second-order term disappears. If the student wanted full MAML, this is a bug. (Module 0, Exercise 0.2)

**A6.** `inner_opt.step()` overwrites θ in place. The query loss then depends on the new weights with no record of how they came from θ, so the outer gradient ignores the adaptation step entirely, and θ itself has been changed by an inner step. Use `functional_call` with a new dictionary φ instead. (Module 0.1)

**A7.** 1.96 × 0.08 / √600 = 0.0064. Report 91.2% ± 0.6%. (Module 3.10)

**A8.** Choose ANIL when compute or memory is tight and the backbone's features transfer well across tasks; it is much cheaper and usually matches MAML on standard benchmarks. Avoid it when new tasks need different *features*, for example a large domain shift, where adapting the body (MAML, or BOIL's body-only adaptation) helps. (Module 3.4)

**A9.** Run k SGD steps from θ on the task to get φ, then θ ← θ + ε(φ − θ). With k = 1 this equals a plain SGD step on the task loss, which averaged over tasks is joint pre-training; the meta-learning effect comes from the gradient-alignment terms that appear only with k > 1. (Module 2.7)

**A10.** iMAML defines φ\* as the solution of a regularised inner problem and gets dφ\*/dθ from the implicit function theorem, which needs only φ\* itself and Hessian-vector products at φ\*, not the path the optimiser took. So intermediate steps need not be stored. (Module 3.5)

**A11.** Generated numbers: 8 × 4096 + 4096 × 8 = 65,536. Output layer: 256 × 65,536 + 65,536 = 16,842,752 parameters, about 16.8 million. Text-to-LoRA feeds a layer-index embedding and a module-type embedding into the hypernetwork together with the task embedding, so *one* head serves all layers and modules. (Module 4.5, 5.3)

**A12.** Var(H) = 2 / (40 × 128 × 0.5) = 2 / 2,560 = 0.00078125, so the standard deviation is √0.00078125 ≈ 0.028. (Module 4.6)

**A13.** The plain HyperNet was meta-trained with zero inner steps, so nothing in training made its outputs a good *starting point* for SGD; its generated weights can sit where the loss is sharply curved, and a step of α = 0.01 can overshoot before it helps. The Hybrid was meta-trained *through* an SGD step, MAML-style, so its generator learned to output weights from which gradient steps reliably improve the fit, even at the cost of a worse 0-step answer. General rule: only behaviour optimised during meta-training is dependable at test time. (Project 4, Step 6)

**A14.** Task: one speaker. Support set: the 30-second clip. Query set: further utterances from the same speaker. Model: a frozen recogniser plus small per-speaker adapters (FiLM or low-rank). Adaptation: an amortised hypernetwork with an attention or mean-pooling encoder over audio frames that outputs the adapter in one forward pass, which meets the one-second budget. Optionally refine with one or two gradient steps if compute allows (the hybrid). Meta-train episodically over thousands of speakers; hold out entire speakers, and ideally accents or recording conditions, for meta-validation and meta-test. Report word error rate before and after adaptation with confidence intervals, plus latency on the target device. (Modules 1, 4, 5)

**A15.** (a) False: FOMAML evaluates the query gradient *at* the adapted weights; it only drops the Hessian term. (b) False: they are outputs; the trainable parameters are the hypernetwork's weights and embeddings. (c) False: classes must be disjoint, or the test measures memorised classes. (d) True: one query example's prediction depends on the others in the batch. (e) True: it generates a diagonal scaling and a shift of each layer's weights.

## References and further reading

Papers are grouped by course module. Links go to the arXiv abstract page unless stated otherwise. Links for work from 2024 onward, for Chang et al. and for the tools were checked against the source pages in November 2026; the remaining arXiv identifiers are standard, widely cited ones that were not individually re-opened.

### Where to go next

- [Stanford CS330: Deep Multi-Task and Meta Learning](https://cs330.stanford.edu), Chelsea Finn's course: lectures and assignments that extend this course to meta-reinforcement learning and Bayesian meta-learning.
- Hospedales, Antoniou, Micaelli and Storkey, [Meta-Learning in Neural Networks: A Survey](https://arxiv.org/abs/2004.05439), IEEE TPAMI 2021.
- Chauhan et al., [A Brief Review of Hypernetworks in Deep Learning](https://arxiv.org/abs/2306.06955), Artificial Intelligence Review 2024.

### Tools (Module 0)

- [torch.func.functional\_call documentation](https://docs.pytorch.org/docs/main/generated/torch.func.functional_call.html), PyTorch.
- [PyTorch 2.15 release notes](https://github.com/pytorch/pytorch/releases/tag/v2.15.0), October 2026; Python 3.10 wheels were dropped from this release.
- [learn2learn](https://github.com/learnables/learn2learn): a meta-learning library with ready-made MAML, ANIL and Meta-SGD wrappers and datasets. Development has slowed, which is why the course uses `torch.func` directly.

### Meta-learning foundations (Module 1)

- Lake, Salakhutdinov and Tenenbaum, [Human-level concept learning through probabilistic program induction](https://doi.org/10.1126/science.aab3050), Science 2015 (Omniglot).
- Vinyals et al., [Matching Networks for One Shot Learning](https://arxiv.org/abs/1606.04080), NeurIPS 2016 (episodic training, miniImageNet).
- Snell, Swersky and Zemel, [Prototypical Networks for Few-shot Learning](https://arxiv.org/abs/1703.05175), NeurIPS 2017.
- Ravi and Larochelle, Optimization as a Model for Few-Shot Learning, ICLR 2017 (the standard miniImageNet split).

### MAML and its family (Modules 2 and 3)

- Finn, Abbeel and Levine, [Model-Agnostic Meta-Learning for Fast Adaptation of Deep Networks](https://arxiv.org/abs/1703.03400), ICML 2017.
- Nichol, Achiam and Schulman, [On First-Order Meta-Learning Algorithms](https://arxiv.org/abs/1803.02999), 2018 (Reptile).
- Li, Zhou, Chen and Li, [Meta-SGD: Learning to Learn Quickly for Few-Shot Learning](https://arxiv.org/abs/1707.09835), 2017.
- Grant et al., [Recasting Gradient-Based Meta-Learning as Hierarchical Bayes](https://arxiv.org/abs/1801.08930), ICLR 2018.
- Antoniou, Edwards and Storkey, [How to train your MAML](https://arxiv.org/abs/1810.09502), ICLR 2019 (MAML++).
- Nagabandi et al., [Learning to Adapt in Dynamic, Real-World Environments Through Meta-Reinforcement Learning](https://arxiv.org/abs/1803.11347), ICLR 2019.
- Zintgraf et al., [Fast Context Adaptation via Meta-Learning](https://arxiv.org/abs/1810.03642), ICML 2019 (CAVIA).
- Rusu et al., [Meta-Learning with Latent Embedding Optimization](https://arxiv.org/abs/1807.05960), ICLR 2019 (LEO).
- Rajeswaran, Finn, Kakade and Levine, [Meta-Learning with Implicit Gradients](https://arxiv.org/abs/1909.04630), NeurIPS 2019 (iMAML).
- Raghu, Raghu, Bengio and Vinyals, [Rapid Learning or Feature Reuse?](https://arxiv.org/abs/1909.09157), ICLR 2020 (ANIL).
- Oh, Yoo, Kim and Yun, [BOIL: Towards Representation Change for Few-shot Learning](https://arxiv.org/abs/2008.08882), ICLR 2021.
- Yin et al., [Meta-Learning without Memorization](https://arxiv.org/abs/1912.03820), ICLR 2020.
- Bronskill et al., [TaskNorm: Rethinking Batch Normalization for Meta-Learning](https://arxiv.org/abs/2003.03284), ICML 2020.
- Chen et al., [A Closer Look at Few-shot Classification](https://arxiv.org/abs/1904.04232), ICLR 2019.
- Tian et al., [Rethinking Few-Shot Image Classification: a Good Embedding Is All You Need?](https://arxiv.org/abs/2003.11539), ECCV 2020.
- Triantafillou et al., [Meta-Dataset](https://arxiv.org/abs/1903.03096), ICLR 2020.

### HyperNetworks (Module 4)

- Ha, Dai and Le, [HyperNetworks](https://arxiv.org/abs/1609.09106), ICLR 2017.
- Bertinetto et al., [Learning feed-forward one-shot learners](https://arxiv.org/abs/1606.05233), NeurIPS 2016 (learnet).
- Zaheer et al., [Deep Sets](https://arxiv.org/abs/1703.06114), NeurIPS 2017 (the set encoder in Project 4).
- Perez et al., [FiLM: Visual Reasoning with a General Conditioning Layer](https://arxiv.org/abs/1709.07871), AAAI 2018.
- Brock et al., [SMASH: One-Shot Model Architecture Search through HyperNetworks](https://arxiv.org/abs/1708.05344), ICLR 2018.
- Zhang, Ren and Urtasun, [Graph HyperNetworks for Neural Architecture Search](https://arxiv.org/abs/1810.05749), ICLR 2019.
- MacKay et al., [Self-Tuning Networks](https://arxiv.org/abs/1903.03088), ICLR 2019.
- von Oswald et al., [Continual learning with hypernetworks](https://arxiv.org/abs/1906.00695), ICLR 2020.
- Chang, Flokas and Lipson, [Principled Weight Initialization for Hypernetworks](https://arxiv.org/abs/2312.08399), ICLR 2020 (posted to arXiv in December 2023).
- Jaegle et al., [Perceiver: General Perception with Iterative Attention](https://arxiv.org/abs/2103.03206), ICML 2021.
- Karimi Mahabadi et al., [Parameter-efficient Multi-task Fine-tuning for Transformers via Shared Hypernetworks](https://arxiv.org/abs/2106.04489), ACL 2021 (HyperFormer).
- Alaluf et al., [HyperStyle](https://arxiv.org/abs/2111.15666), CVPR 2022.
- Phang et al., [HyperTuning: Toward Adapting Large Language Models without Back-propagation](https://arxiv.org/abs/2211.12485), ICML 2023.
- Ruiz et al., [HyperDreamBooth](https://arxiv.org/abs/2307.06949), CVPR 2024.
- Schlag, Irie and Schmidhuber, [Linear Transformers Are Secretly Fast Weight Programmers](https://arxiv.org/abs/2102.11174), ICML 2021.

### The 2025 to 2026 landscape (Module 5)

- Hu et al., [LoRA: Low-Rank Adaptation of Large Language Models](https://arxiv.org/abs/2106.09685), ICLR 2022.
- Garg et al., [What Can Transformers Learn In-Context?](https://arxiv.org/abs/2208.01066), NeurIPS 2022.
- von Oswald et al., [Transformers learn in-context by gradient descent](https://arxiv.org/abs/2212.07677), ICML 2023.
- Sun et al., [Learning to (Learn at Test Time): RNNs with Expressive Hidden States](https://arxiv.org/abs/2407.04620), July 2024 (TTT layers).
- Akyürek et al., [The Surprising Effectiveness of Test-Time Training for Few-Shot Learning](https://arxiv.org/abs/2411.07279), November 2024, revised March 2025.
- Behrouz, Zhong and Mirrokni, [Titans: Learning to Memorize at Test Time](https://arxiv.org/abs/2501.00663), December 2024.
- Hollmann et al., [Accurate predictions on small data with a tabular foundation model](https://pubmed.ncbi.nlm.nih.gov/39780007/), Nature 637, 319–326, January 2025 (TabPFN).
- Charakorn, Cetin, Tang and Lange, [Text-to-LoRA: Instant Transformer Adaption](https://arxiv.org/abs/2506.06105v2), ICML 2025; [project page](https://sakana.ai/text-to-lora).
- Charakorn et al., [Doc-to-LoRA: Learning to Instantly Internalize Contexts](https://www.arxiv.org/pdf/2602.15902), February 2026.
- Liu et al., [SHINE: A Scalable In-Context Hypernetwork for Mapping Context to LoRA in a Single Pass](https://arxiv.org/abs/2602.06358), February 2026.
- [Code2LoRA: Hypernetwork-Generated Adapters for Code Language Models under Software Evolution](https://huggingface.co/papers/2606.06492.md), June 2026.
- [The Override Gap: A Magnitude Account of Knowledge Conflict Failure in Hypernetwork-Based Instant LLM Adaptation](https://www.emergentmind.com/papers/2604.23750), April 2026.
