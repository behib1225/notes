# MAML and HyperNetworks: course code

Runnable companion code for the course document "MAML and HyperNetworks: A Project-Based Course".

The course text itself is included in two forms:

- `COURSE.md`: the full text as Markdown. Formulas are `$$...$$` display math (rendered by GitHub,
  JupyterLab and VS Code); figures link to `reference_figures/`; the two diagrams appear as text sketches.
- `COURSE.pdf` (63 pages, A4): the same text with the figures and diagrams drawn. In this PDF the
  formulas appear as LaTeX source, so read the formulas in `COURSE.md` if you prefer rendered math.
Everything runs on a laptop CPU. Every result in the course was produced with the exact
versions in `requirements-lock.txt` (Python 3.12, PyTorch 2.15.0, torchvision 0.29.2), November 2026.

## Setup

    python -m venv maml-env
    source maml-env/bin/activate          # Windows: maml-env\Scripts\activate
    pip install -r requirements.txt       # or requirements-lock.txt for the exact tested versions
    python 00_setup_check.py

PyTorch 2.15 needs Python 3.11 or newer. The code itself needs PyTorch >= 2.1 (torch.func).

## How to work through the projects

1. Open the STARTER version of a project (`starter/02_maml_sinusoid.py` or its notebook).
   Each key function contains a `TODO` and raises `NotImplementedError`.
2. Fill in the TODO. Right after each function there is a check (an `assert`) that
   tells you whether your implementation is correct.
3. Only then compare with the full solution in the top-level file of the same name.

To regenerate the starter files after editing a solution: `python make_starters.py`.

## Files

| File | Course part | Full run (1 CPU core) |
| --- | --- | --- |
| 00_setup_check.py | Setup | seconds |
| 01_functional_pytorch.py | Module 0: functional PyTorch, gradients of gradients | seconds |
| 02_maml_sinusoid.py | Project 1: MAML on sine regression | ~15 min |
| 03_maml_omniglot.py | Project 2: MAML, ANIL, ProtoNets and a pre-trained baseline on Omniglot (downloads ~9 MB) | ~40 min |
| 04_hypernetworks.py | Project 3: static and task-conditioned hypernetworks (3 seeds) | ~5 min |
| 05_capstone.py | Project 4: MAML vs hypernetwork vs hybrid (3 seeds) | ~11 min |

Each .py file has a matching .ipynb notebook with the same cells; the `starter/` folder has
both formats too. Laptops with several cores are usually faster than the times above.

## Quick mode

Set QUICK=1 to run a short smoke test of any project:

    QUICK=1 python 03_maml_omniglot.py                 # macOS / Linux
    set "QUICK=1" && python 03_maml_omniglot.py        # Windows Command Prompt
    $env:QUICK = "1"; python 03_maml_omniglot.py       # Windows PowerShell

(In Command Prompt the quotes matter: `set QUICK=1 && ...` stores "1 " with a trailing space.)
In a notebook, change the line `QUICK = os.environ.get("QUICK") == "1"` to `QUICK = True`.

Figures go to ./outputs/, Omniglot data to ./data/.

## Reference figures

`reference_figures/` holds the figures from the course's own runs, so you can compare
your results. Your numbers will differ somewhat (random seeds, hardware, thread counts).
