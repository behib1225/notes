"""Create starter versions of the project scripts: every block between
'# >>> SOLUTION: <hint>' and '# <<< SOLUTION' is replaced by a TODO.
Run: python make_starters.py   (writes starter/*.py)"""
import os, re, sys

os.makedirs("starter", exist_ok=True)
for name in sorted(os.listdir(".")):
    if not re.match(r"0[2-5]_.*\.py$", name):
        continue
    out, skipping, n = [], False, 0
    for line in open(name):
        m = re.match(r"(\s*)# >>> SOLUTION:?\s*(.*)", line)
        if m:
            indent, hint = m.groups()
            out.append(f"{indent}# TODO: {hint}\n")
            out.append(f'{indent}raise NotImplementedError("TODO: {hint}")\n')
            skipping, n = True, n + 1
            continue
        if re.match(r"\s*# <<< SOLUTION", line):
            skipping = False
            continue
        if not skipping:
            out.append(line)
    open(os.path.join("starter", name), "w").writelines(out)
    print(f"starter/{name}: {n} TODO blocks")
