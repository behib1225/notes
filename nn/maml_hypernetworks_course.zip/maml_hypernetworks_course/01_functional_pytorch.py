# %% [markdown]
# # Module 0 - Models as functions of their weights
#
# MAML and HyperNetworks both need one skill: running a network with weights
# that are NOT stored inside the nn.Module. MAML needs it because adapted
# weights phi = theta - alpha * grad are new tensors computed from theta.
# HyperNetworks need it because another network outputs the weights.
#
# Run top to bottom: `python 01_functional_pytorch.py`

# %%
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.func import functional_call, grad, vmap

torch.manual_seed(0)

# %% [markdown]
# ## Step 1 - A module and its parameter dictionary

# %%
model = nn.Sequential(nn.Linear(1, 40), nn.ReLU(), nn.Linear(40, 1))
params = dict(model.named_parameters())
for name, p in params.items():
    print(f"{name:10s} shape={tuple(p.shape)}")
# 0.weight (40, 1)   0.bias (40,)   2.weight (1, 40)   2.bias (1,)

# %% [markdown]
# ## Step 2 - functional_call: run the module with other weights

# %%
x = torch.linspace(-5, 5, 7).unsqueeze(1)          # shape (7, 1)
zero_params = {k: torch.zeros_like(v) for k, v in params.items()}

y_stored = model(x)                                  # uses stored weights
y_zero = functional_call(model, zero_params, (x,))   # uses zeros instead
print("stored weights :", y_stored.squeeze().detach())
print("all-zero params:", y_zero.squeeze())          # all zeros
# The module itself is unchanged:
assert torch.allclose(model(x), y_stored)

# %% [markdown]
# ## Step 3 - One SGD step written by hand, without an optimizer
# phi = theta - alpha * dL/dtheta. The result is a NEW dict; the model keeps theta.

# %%
def mse_with(params, x, y):
    return F.mse_loss(functional_call(model, params, (x,)), y)

y = torch.sin(x)
alpha = 0.01
loss = mse_with(params, x, y)
grads = torch.autograd.grad(loss, list(params.values()))
adapted = {k: p - alpha * g for (k, p), g in zip(params.items(), grads)}
print(f"loss before: {loss.item():.4f}  after one step: {mse_with(adapted, x, y).item():.4f}")

# %% [markdown]
# ## Step 4 - Gradients of gradients (create_graph=True)
# By default autograd.grad returns plain numbers with no history.
# create_graph=True records how the gradient was computed, so we can
# differentiate it again. MAML needs exactly this.

# %%
w = torch.tensor(2.0, requires_grad=True)
f = w ** 3
(df,) = torch.autograd.grad(f, w, create_graph=True)   # 3 w^2 = 12, has history
(d2f,) = torch.autograd.grad(df, w)                     # 6 w   = 12
print(f"f'(2) = {df.item()},  f''(2) = {d2f.item()}")

# %% [markdown]
# ## Step 5 - Differentiate THROUGH a gradient step (MAML in one dimension)
# Inner loss  L_in(w)  = (w - a)^2       (support set "wants" w = a)
# Inner step  w'       = w - alpha * 2 (w - a)
# Outer loss  L_out(w') = (w' - b)^2     (query set "wants" w' = b)
# Chain rule: dL_out/dw = 2 (w' - b) * dw'/dw = 2 (w' - b) * (1 - 2 alpha)

# %%
a, b, alpha = 1.0, 3.0, 0.1
w = torch.tensor(0.0, requires_grad=True)

L_in = (w - a) ** 2
(g_in,) = torch.autograd.grad(L_in, w, create_graph=True)
w_adapted = w - alpha * g_in
L_out = (w_adapted - b) ** 2
(meta_grad,) = torch.autograd.grad(L_out, w)

w_prime = 0.0 - alpha * 2 * (0.0 - a)                    # = 0.2
analytic = 2 * (w_prime - b) * (1 - 2 * alpha)          # = -4.48
first_order = 2 * (w_prime - b)                          # = -5.6 (ignores dw'/dw)
print(f"autograd meta-gradient : {meta_grad.item():.4f}")
print(f"analytic (full MAML)   : {analytic:.4f}")
print(f"first-order (FOMAML)   : {first_order:.4f}")
assert abs(meta_grad.item() - analytic) < 1e-5

# %% [markdown]
# ## Step 6 - Hessian-vector products (what the second-order term really is)
# For a network, dphi/dtheta = I - alpha * H, where H is the Hessian of the
# inner loss. MAML never builds H. It only needs H @ v for one vector v,
# which double-backward computes at about the cost of two backward passes.

# %%
lin = nn.Linear(3, 1)
p = dict(lin.named_parameters())
xb, yb = torch.randn(8, 3), torch.randn(8, 1)

def loss_flat(flat):
    w_ = flat[:3].view(1, 3); b_ = flat[3:]
    return F.mse_loss(F.linear(xb, w_, b_), yb)

flat = torch.cat([p["weight"].detach().flatten(), p["bias"].detach()]).requires_grad_()
v = torch.randn(4)

(g,) = torch.autograd.grad(loss_flat(flat), flat, create_graph=True)
(hvp,) = torch.autograd.grad(g @ v, flat)                # H v via double backward
H = torch.autograd.functional.hessian(loss_flat, flat)   # full 4x4 Hessian (small only!)
print("double-backward H v :", hvp)
print("explicit        H v :", H @ v)
assert torch.allclose(hvp, H @ v, atol=1e-5)

# %% [markdown]
# ## Step 7 - torch.func.grad and vmap: many tasks at once
# torch.func.grad(f) returns a function computing df/dargs[0].
# vmap(f) maps f over a leading batch dimension, like a fast for-loop.

# %%
def task_loss(params, x, y):
    return F.mse_loss(functional_call(model, params, (x,)), y)

def adapt_one(params, x, y, alpha=0.01):
    g = grad(task_loss)(params, x, y)
    return {k: params[k] - alpha * g[k] for k in params}

def query_loss_after_adapt(params, xs, ys, xq, yq):
    return task_loss(adapt_one(params, xs, ys), xq, yq)

T = 4  # four tasks, each with 10 support and 10 query points
xs, xq = torch.rand(T, 10, 1) * 10 - 5, torch.rand(T, 10, 1) * 10 - 5
amp = torch.rand(T, 1, 1) * 4.9 + 0.1
ys, yq = amp * torch.sin(xs), amp * torch.sin(xq)

losses = vmap(query_loss_after_adapt, in_dims=(None, 0, 0, 0, 0))(params, xs, ys, xq, yq)
print("per-task query losses:", losses.detach())
losses.mean().backward()                                  # full second-order meta-gradient
print("meta-gradient norm on 0.weight:", model[0].weight.grad.norm().item())

# %% [markdown]
# ## Exercise solutions (see the course doc for the questions)

# %%
# Exercise 0.1: functional_call does not modify the module.
before = model[0].weight.detach().clone()
_ = functional_call(model, zero_params, (x,))
assert torch.equal(before, model[0].weight.detach())
print("Ex 0.1 OK: stored weights untouched")

# Exercise 0.2: what happens without create_graph=True?
w = torch.tensor(2.0, requires_grad=True)
(df_plain,) = torch.autograd.grad(w ** 3, w)              # no create_graph
print("Ex 0.2: requires_grad of plain gradient =", df_plain.requires_grad)  # False

# Exercise 0.3: two inner steps in 1-D. dw''/dw = (1 - 2 alpha)^2
a, b, alpha = 1.0, 3.0, 0.1
w = torch.tensor(0.0, requires_grad=True)
w1 = w - alpha * torch.autograd.grad((w - a) ** 2, w, create_graph=True)[0]
w2 = w1 - alpha * torch.autograd.grad((w1 - a) ** 2, w1, create_graph=True)[0]
(mg,) = torch.autograd.grad((w2 - b) ** 2, w)
w2_val = a + (0.0 - a) * (1 - 2 * alpha) ** 2            # closed form = 0.36
print(f"Ex 0.3: autograd {mg.item():.4f}  analytic {2*(w2_val-b)*(1-2*alpha)**2:.4f}")

# Exercise 0.4: count parameters of the Step-1 model.
n = sum(p.numel() for p in model.parameters())
print("Ex 0.4: parameters =", n)                          # 40 + 40 + 40 + 1 = 121
