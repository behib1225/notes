# %% [markdown]
# # Project 4 (capstone) - MAML vs amortised hypernetwork vs hybrid
#
# Three ways to turn K support points of a new sine task into a regressor:
#   1. MAML        : learned init theta, then SGD steps on the support set.
#   2. HyperNet    : a set encoder reads the support set, a hypernetwork outputs
#                    ALL weights of the regressor in one forward pass (no gradients
#                    at test time). This is "amortised" meta-learning.
#   3. Hybrid      : the hypernetwork outputs a task-specific INITIALISATION, then
#                    MAML-style SGD steps refine it (trained end-to-end through the steps).
# Same target network, same episodes, same number of outer updates.
# Every method is trained with 3 random seeds; results are mean +/- std over seeds.
#
# Run: `python 05_capstone.py`          (about 11 min on one CPU core)
#      `QUICK=1 python 05_capstone.py`  (1 seed, short training)

# %%
import os, sys, math, time
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.func import functional_call, grad, vmap
import matplotlib
if "ipykernel" not in sys.modules:
    matplotlib.use("Agg")   # script: save figures to files; notebook: also show them inline
import matplotlib.pyplot as plt

QUICK = os.environ.get("QUICK") == "1"
os.makedirs("outputs", exist_ok=True)
torch.manual_seed(0)

CFG = dict(K=10, Q=10, meta_batch=25, inner_lr=0.01, inner_steps=1, outer_lr=1e-3,
           iters=300 if QUICK else 10000, eval_tasks=100 if QUICK else 500, eval_steps=10,
           seeds=[0] if QUICK else [0, 1, 2])
print(CFG)

# %% [markdown]
# ## Step 1 - Shared pieces: tasks and the target network

# %%
def sample(n, k, q, amp=(0.1, 5.0), gen=None):
    a = torch.empty(n).uniform_(*amp, generator=gen)
    p = torch.empty(n).uniform_(0, math.pi, generator=gen)
    xs = torch.empty(n, k, 1).uniform_(-5, 5, generator=gen)
    xq = torch.empty(n, q, 1).uniform_(-5, 5, generator=gen)
    f = lambda x: a.view(-1, 1, 1) * torch.sin(x - p.view(-1, 1, 1))
    return xs, f(xs), xq, f(xq)

def make_target():
    return nn.Sequential(nn.Linear(1, 40), nn.ReLU(), nn.Linear(40, 40), nn.ReLU(), nn.Linear(40, 1))

target = make_target()       # used only as a "shape template" for functional_call
shapes = {k: v.shape for k, v in target.named_parameters()}
sizes = {k: v.numel() for k, v in target.named_parameters()}
N_TARGET = sum(sizes.values())

def unflatten(flat):
    out, i = {}, 0
    for k, s in shapes.items():
        out[k] = flat[i:i + sizes[k]].view(s); i += sizes[k]
    return out

def mse(params, x, y):
    return F.mse_loss(functional_call(target, params, (x,)), y)

def sgd_steps(params, x, y, steps, lr):
    """Differentiable SGD on one task (works inside vmap)."""
    for _ in range(steps):
        g = grad(mse)(params, x, y)
        params = {k: params[k] - lr * g[k] for k in params}
    return params

# %% [markdown]
# ## Step 2 - The set encoder + hypernetwork
# Set encoder (DeepSets, Zaheer et al. 2017): r = rho( mean_i phi([x_i, y_i]) ).
# The mean makes the output independent of the ORDER of support points and
# lets the same network accept any K.

# %%
class SetHyperNet(nn.Module):
    def __init__(self, hidden=128):
        super().__init__()
        self.phi = nn.Sequential(nn.Linear(2, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())
        self.rho = nn.Sequential(nn.Linear(hidden, hidden), nn.ReLU(), nn.Linear(hidden, hidden), nn.ReLU())
        self.head = nn.Linear(hidden, N_TARGET)
        base = make_target()                         # a fresh, seeded initialisation
        self.base = nn.Parameter(torch.cat([v.detach().flatten() for v in base.parameters()]))
        nn.init.zeros_(self.head.bias)
        with torch.no_grad():
            self.head.weight.mul_(0.1)  # small task-specific deltas around a learned base at the start

    def forward(self, xs, ys):                      # xs, ys: (T, K, 1)
        # >>> SOLUTION: embed each (x, y) pair, average over points, map to base + delta
        pairs = torch.cat([xs / 5.0, ys / 5.0], -1)  # scale inputs to about [-1, 1]
        r = self.rho(self.phi(pairs).mean(1))      # (T, hidden)
        return self.base + self.head(r)             # (T, 1761) flat weights per task
        # <<< SOLUTION

# Check: the output must not depend on the order of the support points.
_hn = SetHyperNet(); _xs, _ys, _, _ = sample(3, 10, 1)
_perm = torch.randperm(10)
assert _hn(_xs, _ys).shape == (3, N_TARGET)
assert torch.allclose(_hn(_xs, _ys), _hn(_xs[:, _perm], _ys[:, _perm]), atol=1e-5)
print("permutation-invariance check passed")

# %% [markdown]
# ## Step 3 - The three outer losses (all vectorised over tasks)

# %%
def loss_maml(model, xs, ys, xq, yq, steps):
    theta = dict(model.named_parameters())
    def one(theta, xs, ys, xq, yq):
        return mse(sgd_steps(theta, xs, ys, steps, CFG["inner_lr"]), xq, yq)
    return vmap(one, in_dims=(None, 0, 0, 0, 0))(theta, xs, ys, xq, yq).mean()

def loss_hyper(hn, xs, ys, xq, yq, steps=0):
    # >>> SOLUTION: generate one weight vector per task, optionally refine with SGD, score the query set
    flat = hn(xs, ys)
    def one(w, xs, ys, xq, yq):
        return mse(sgd_steps(unflatten(w), xs, ys, steps, CFG["inner_lr"]), xq, yq)
    return vmap(one)(flat, xs, ys, xq, yq).mean()
    # <<< SOLUTION

METHODS = {
    "MAML":     dict(make=make_target, loss=lambda m, b: loss_maml(m, *b, CFG["inner_steps"])),
    "HyperNet": dict(make=SetHyperNet, loss=lambda m, b: loss_hyper(m, *b, steps=0)),
    "Hybrid":   dict(make=SetHyperNet, loss=lambda m, b: loss_hyper(m, *b, steps=CFG["inner_steps"])),
}

# %% [markdown]
# ## Step 4 - Training and evaluation helpers

# %%
def train(name, seed):
    torch.manual_seed(seed)
    model = METHODS[name]["make"]()
    opt = torch.optim.Adam(model.parameters(), lr=CFG["outer_lr"])
    g = torch.Generator().manual_seed(1000 + seed)            # training tasks
    for it in range(CFG["iters"]):
        loss = METHODS[name]["loss"](model, sample(CFG["meta_batch"], CFG["K"], CFG["Q"], gen=g))
        opt.zero_grad(); loss.backward(); opt.step()
    return model

def init_weights(name, model, xs, ys):
    if name == "MAML":
        flat = torch.cat([p.detach().flatten() for p in model.parameters()])
        return flat.expand(xs.shape[0], -1)
    with torch.no_grad():
        return model(xs, ys)

def evaluate(name, model, k=CFG["K"], amp=(0.1, 5.0), steps=CFG["eval_steps"], lr=CFG["inner_lr"], seed=2026):
    g = torch.Generator().manual_seed(seed)                   # identical test tasks for everyone
    xs, ys, xq, yq = sample(CFG["eval_tasks"], k, 100, amp, gen=g)
    w0 = init_weights(name, model, xs, ys)
    curve = []
    for s in range(steps + 1):
        f = lambda w, xs, ys, xq, yq: mse(sgd_steps(unflatten(w), xs, ys, s, lr), xq, yq)
        curve.append(vmap(f)(w0, xs, ys, xq, yq).mean().item())
    return curve

scenarios = {
    "in-distribution, K=10": dict(k=10),
    "in-distribution, K=5": dict(k=5),
    "more data, K=40": dict(k=40),
    "out-of-distribution A in [5,10], alpha=0.01": dict(k=10, amp=(5.0, 10.0)),
    "out-of-distribution A in [5,10], alpha=0.002": dict(k=10, amp=(5.0, 10.0), lr=0.002),
}

# %% [markdown]
# ## Step 5 - Run every method with every seed

# %%
curves = {sc: {n: [] for n in METHODS} for sc in scenarios}
trained = {}
t_start = time.time()
for seed in CFG["seeds"]:
    for name in METHODS:
        t0 = time.time()
        model = train(name, seed)
        trained[name] = model                                  # keep the last seed for Step 7
        for sc, kw in scenarios.items():
            curves[sc][name].append(evaluate(name, model, **kw))
        print(f"seed {seed}  {name:8s} trained + evaluated in {time.time()-t0:.0f}s")
print(f"total {time.time()-t_start:.0f}s")

# %% [markdown]
# ## Step 6 - Results: mean +/- std over seeds; 'k/3 diverged' = k seeds blew up (NaN or > 1e3)

# %%
def fmt(vals):
    t = torch.tensor(vals)
    bad = int((~torch.isfinite(t) | (t > 1e3)).sum())          # > 1e3: blew up, even if still finite
    if bad:
        return f"{f'{bad}/{len(t)} diverged':>15s}"
    return f"{t.mean():7.3f} +/- {t.std(unbiased=True) if len(t) > 1 else 0.0:5.3f}"

for sc in scenarios:
    print(f"\n{sc}: query MSE after 0 / 1 / 10 test-time steps (n_seeds={len(CFG['seeds'])})")
    for n in METHODS:
        c = curves[sc][n]
        print(f"  {n:8s}" + "".join(f"  {fmt([run[s] for run in c])}" for s in (0, 1, 10)))
    for n in METHODS:
        per_seed = ", ".join(f"{run[10]:.3f}" for run in curves[sc][n])
        print(f"    {n:8s} 10-step MSE per seed: {per_seed}")

# %% [markdown]
# ## Step 7 - Adaptation speed (one task, wall clock, last seed's models)

# %%
xs, ys, xq, yq = sample(1, 10, 100)
for n, m in trained.items():
    steps = 0 if n == "HyperNet" else 10
    t0 = time.perf_counter()
    for _ in range(50):
        w = init_weights(n, m, xs, ys)
        p = {k: v.detach().clone().requires_grad_() for k, v in unflatten(w[0]).items()}
        for _ in range(steps):
            gr = torch.autograd.grad(mse(p, xs[0], ys[0]), list(p.values()))
            p = {k: (v - CFG["inner_lr"] * g_).detach().requires_grad_() for (k, v), g_ in zip(p.items(), gr)}
    print(f"{n:8s} adapt with {steps:2d} SGD steps: {(time.perf_counter()-t0)/50*1000:.2f} ms per task")
for n, m in trained.items():
    print(f"{n:8s} trainable parameters: {sum(p.numel() for p in m.parameters())}")

# %% [markdown]
# ## Step 8 - Plot (mean over seeds; diverged curves are cut where they leave the plot)

# %%
fig, axes = plt.subplots(1, len(scenarios), figsize=(4.2 * len(scenarios), 3.6))
for ax, sc in zip(axes, scenarios):
    for n in METHODS:
        m = torch.tensor(curves[sc][n]).mean(0)
        m[~torch.isfinite(m) | (m > 1e3)] = float("nan")
        ax.plot(range(len(m)), m.numpy(), marker="o", ms=3, label=n)
    ax.set_title(sc, fontsize=8); ax.set_xlabel("test-time SGD steps"); ax.set_yscale("log")
axes[0].set_ylabel("query MSE (mean over seeds)"); axes[0].legend(); plt.tight_layout()
plt.savefig("outputs/p4_comparison.png", dpi=120)
print("saved outputs/p4_comparison.png")
