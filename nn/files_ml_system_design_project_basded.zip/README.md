# ML System Design course repository (v2, November 2026)

Three production-style ML systems (fraud detection, recommendations, search) plus MLOps,
monitoring, A/B testing and an ML coding round. Tested with Python 3.12 and the pins in
`requirements-dev.txt`.

## Quickstart
    python3.12 -m venv .venv && source .venv/bin/activate
    pip install -r requirements-dev.txt && pip install -e .
    cd fraud && python generate_data.py && python train.py && python -m pytest -q tests

## Two versions
* `mlsd-course` (solution): everything implemented; all tests pass.
* `mlsd-course-starter`: built with `python tools/make_starter.py ../mlsd-course-starter`.
  Every `TODO(student)` block raises `NotImplementedError`; the tests are your autograder.

## Layout
    fraud/        Weeks 1-2: point-in-time features, label delay, cost-based policy, API, Redis store
    recsys/       Week 3: two-stage retrieval + ranking
    search/       Week 4: hybrid retrieval, learning to rank from biased clicks, spelling correction
    monitoring/   Week 5: PSI and a drift simulation        experiments/  Week 5: A/B testing toolkit
    interview/    Week 6: ML coding round                   mlsd_common/  bootstrap confidence intervals
    .github/      CI (tests, quality gate, image build) and a weekly retraining workflow

## Not verified by the course author
Docker builds, docker-compose.yml, GitHub Actions runs and Render/Codespaces deployment could not be
executed in the author's environment. They follow current documentation; see the course's
troubleshooting appendix if something fails.
