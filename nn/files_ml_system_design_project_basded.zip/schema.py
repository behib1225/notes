"""Data validation: reject a broken batch BEFORE it trains or scores anything."""
import pandera.pandas as pa

TRANSACTIONS = pa.DataFrameSchema({
    "txn_id": pa.Column(int, unique=True),
    "user_id": pa.Column(int, pa.Check.ge(0)),
    "ts": pa.Column("datetime64[ns]", nullable=False),
    "amount": pa.Column(float, [pa.Check.gt(0), pa.Check.lt(1_000_000)]),
    "merchant_id": pa.Column(int, pa.Check.ge(0)),
    "country": pa.Column(str, pa.Check.str_length(2, 2)),
    "home_country": pa.Column(str, pa.Check.str_length(2, 2)),
    "category": pa.Column(str),
    "is_fraud": pa.Column(int, pa.Check.isin([0, 1])),
    "label_ts": pa.Column("datetime64[ns]"),
}, checks=pa.Check(lambda df: (df.label_ts >= df.ts).all(), error="label before transaction"), strict=False)

if __name__ == "__main__":
    import pandas as pd
    TRANSACTIONS.validate(pd.read_parquet("data/transactions.parquet"), lazy=True)
    print("data/transactions.parquet passes the schema")
