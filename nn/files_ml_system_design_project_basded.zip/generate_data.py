"""Synthetic card payments with realistic, OVERLAPPING fraud and legitimate behaviour (seed 42).
Legitimate users sometimes travel, make bursts of small purchases and buy something big;
half of the fraud imitates the cardholder's normal spending. Run: python generate_data.py
"""
from pathlib import Path

import numpy as np
import pandas as pd

RNG = np.random.default_rng(42)
N_USERS, N_MERCHANTS, N_DAYS = 3_000, 400, 90
START = pd.Timestamp("2026-01-01")
CATEGORIES = ["grocery", "restaurant", "fuel", "electronics", "travel", "digital_goods", "fashion"]
COUNTRIES = ["CA", "US", "GB", "FR", "BR", "NG", "IN"]


def make_merchants() -> pd.DataFrame:
    cat = RNG.choice(CATEGORIES, N_MERCHANTS, p=[0.25, 0.25, 0.12, 0.1, 0.08, 0.1, 0.1])
    risky = (RNG.random(N_MERCHANTS) < 0.08) | (np.isin(cat, ["electronics", "digital_goods"])
                                                 & (RNG.random(N_MERCHANTS) < 0.4))
    return pd.DataFrame({"merchant_id": np.arange(N_MERCHANTS), "category": cat, "risky": risky})


def make_users() -> pd.DataFrame:
    return pd.DataFrame({
        "user_id": np.arange(N_USERS),
        "home_country": RNG.choice(COUNTRIES[:3], N_USERS, p=[0.6, 0.3, 0.1]),
        "log_amount_mu": RNG.normal(3.3, 0.6, N_USERS),            # typical spend ~ e^3.3 = $27
        "txn_per_day": RNG.gamma(2.0, 0.6, N_USERS) + 0.2,
        "bursty": RNG.random(N_USERS) < 0.10,                      # transit, coffee, app stores
        "favorites": [RNG.choice(N_MERCHANTS, 8, replace=False) for _ in range(N_USERS)],
    })


def legit_transactions(users) -> pd.DataFrame:
    rows = []
    for u in users.itertuples():
        n = RNG.poisson(u.txn_per_day * N_DAYS)
        if n == 0:
            continue
        day = RNG.uniform(0, N_DAYS, n)
        hour = np.clip(RNG.normal(14, 4, n), 0, 23.99)
        ts = np.sort((START + pd.to_timedelta(np.floor(day), "D") + pd.to_timedelta(hour, "h")).to_numpy())
        if u.bursty:                                                # some purchases come minutes apart
            k = np.flatnonzero(RNG.random(n) < 0.25)
            k = k[k > 0]
            ts[k] = ts[k - 1] + pd.to_timedelta(RNG.uniform(1, 20, len(k)), "min").to_numpy()
        merchant = np.where(RNG.random(n) < 0.8, RNG.choice(u.favorites, n), RNG.integers(0, N_MERCHANTS, n))
        country = np.where(RNG.random(n) < 0.04, RNG.choice(COUNTRIES, n), u.home_country)
        amount = np.exp(RNG.normal(u.log_amount_mu, 0.7, n))
        amount = np.where(RNG.random(n) < 0.02, amount * RNG.uniform(5, 15, n), amount)   # big purchases
        rows.append(pd.DataFrame({"user_id": u.user_id, "ts": ts, "amount": np.round(amount, 2),
                                  "merchant_id": merchant, "country": country, "is_fraud": 0}))
    return pd.concat(rows, ignore_index=True)


def fraud_transactions(users, merchants) -> pd.DataFrame:
    risky_ids = merchants.loc[merchants.risky, "merchant_id"].to_numpy()
    victims = RNG.choice(users.user_id, size=int(0.2 * N_USERS), replace=False)
    rows = []
    for uid in victims:
        u = users.loc[uid]
        start = START + pd.Timedelta(days=RNG.uniform(1, N_DAYS - 1))
        if RNG.random() < 0.5:     # card testing: a few small charges, then larger ones, within 6 hours
            k = int(RNG.integers(2, 7))
            offsets = np.sort(RNG.uniform(0, 360, k))
            amount = np.where(np.arange(k) < k // 2, RNG.uniform(1, 10, k),
                              np.exp(RNG.normal(u.log_amount_mu + 1.0, 0.6, k)))
        else:                      # account takeover: 1-2 charges that look like the user's normal spend
            k = int(RNG.integers(1, 3))
            offsets = np.sort(RNG.uniform(0, 600, k))
            amount = np.exp(RNG.normal(u.log_amount_mu, 0.7, k)) * RNG.uniform(1, 3, k)
        ts = start + pd.to_timedelta(offsets, "min")
        r = RNG.random(k)
        merchant = np.where(r < 0.4, RNG.choice(risky_ids, k),
                            np.where(r < 0.65, RNG.choice(u.favorites, k), RNG.integers(0, N_MERCHANTS, k)))
        country = np.where(RNG.random(k) < 0.35, RNG.choice(COUNTRIES[3:], k), u.home_country)
        rows.append(pd.DataFrame({"user_id": uid, "ts": ts, "amount": np.round(amount, 2),
                                  "merchant_id": merchant, "country": country, "is_fraud": 1}))
    return pd.concat(rows, ignore_index=True)


def main(out_dir: str = "data") -> pd.DataFrame:
    merchants, users = make_merchants(), make_users()
    df = pd.concat([legit_transactions(users), fraud_transactions(users, merchants)], ignore_index=True)
    df = df.merge(merchants[["merchant_id", "category"]], on="merchant_id")
    df = df.merge(users[["user_id", "home_country"]], on="user_id")
    # Label delay: fraud is confirmed only when the cardholder disputes it (a chargeback).
    delay_days = np.clip(RNG.lognormal(np.log(7), 0.8, len(df)), 0.5, 60)
    df["label_ts"] = df["ts"] + pd.to_timedelta(delay_days, "D")
    df = df.sort_values("ts", kind="mergesort").reset_index(drop=True)
    df.insert(0, "txn_id", np.arange(len(df)))
    Path(out_dir).mkdir(exist_ok=True)
    df.to_parquet(f"{out_dir}/transactions.parquet", index=False)
    print(f"{len(df):,} transactions, fraud rate {df.is_fraud.mean():.3%}")
    return df


if __name__ == "__main__":
    main()
