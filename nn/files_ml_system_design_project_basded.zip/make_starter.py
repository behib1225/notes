"""Build the STARTER repository from this solution repository. Every block between
'# >>> SOLUTION' and '# <<< SOLUTION' becomes `raise NotImplementedError` (the TODO comment above
stays), and generated data, artifacts and MLflow files are left out. The tests are the autograder.
Usage (from the repo root): python tools/make_starter.py ../mlsd-course-starter"""
import shutil
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent.parent
SKIP = {"data", "artifacts", "artifacts_leaky", "mlruns", ".pytest_cache", "__pycache__", ".git",
        "mlsd_common.egg-info", "mlflow.db", "predictions.jsonl"}


def strip(text: str) -> tuple[str, int]:
    out, skipping, n = [], False, 0
    for line in text.splitlines(keepends=True):
        s = line.strip()
        if s == "# >>> SOLUTION":
            indent = line[: len(line) - len(line.lstrip())]
            out.append(f'{indent}raise NotImplementedError("TODO(student): see the comment above")\n')
            skipping, n = True, n + 1
        elif s == "# <<< SOLUTION":
            skipping = False
        elif not skipping:
            out.append(line)
    return "".join(out), n


def main(dest: str):
    dest = Path(dest).resolve()
    if dest.exists():
        shutil.rmtree(dest)
    total = 0
    for p in SRC.rglob("*"):
        rel = p.relative_to(SRC)
        if any(part in SKIP for part in rel.parts) or p.is_dir():
            continue
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        if p.suffix == ".py" and p.name != "make_starter.py":
            text, n = strip(p.read_text())
            target.write_text(text)
            total += n
        else:
            shutil.copy2(p, target)
    print(f"starter written to {dest} with {total} TODO blocks")


if __name__ == "__main__":
    main(sys.argv[1])
