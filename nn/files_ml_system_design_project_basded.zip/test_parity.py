"""Training/serving skew test: replay payments through the ONLINE code (both store backends)
and check every feature equals the OFFLINE value used for training."""
import fakeredis
import numpy as np
import pandas as pd
import pytest

from features import FEATURES, build_offline_features, merchant_rate_table, online_features
from store import InMemoryStore, RedisStore


def replay(store, sub, table):
    for d in range(table.shape[1]):
        store.put_snapshot(d, {m: table[m, d] for m in range(table.shape[0])})
    rows = []
    for r in sub.itertuples():
        f, _ = online_features(store, r.user_id, r.ts, r.amount, r.country, r.home_country, r.category, r.merchant_id)
        rows.append(f)
        store.append(r.user_id, r.ts.value / 1e9, r.amount, r.merchant_id, r.txn_id)
    return pd.DataFrame(rows)


@pytest.mark.parametrize("backend,n_users", [("memory", 60), ("redis", 15)])
def test_online_matches_offline(backend, n_users):
    df = pd.read_parquet("data/transactions.parquet")
    table = merchant_rate_table(df, int(df.merchant_id.max()) + 1)       # the nightly job's output
    users = df.user_id.drop_duplicates().sample(n_users, random_state=1)
    sub = df[df.user_id.isin(users)].sort_values(["ts", "txn_id"]).reset_index(drop=True)
    off = build_offline_features(sub, rate_table=table)
    store = InMemoryStore() if backend == "memory" else RedisStore(client=fakeredis.FakeRedis(decode_responses=True))
    on = replay(store, sub, table)
    for f in FEATURES:
        np.testing.assert_allclose(on[f].to_numpy(float), off[f].to_numpy(float), rtol=1e-6, atol=1e-3, err_msg=f)
