"""Train, record the run in MLflow, and register the model version.
Run: python train_mlflow.py     Browse: mlflow ui --backend-store-uri sqlite:///mlflow.db"""
import json

import lightgbm as lgb
import mlflow
import numpy as np
from mlflow.models import infer_signature

import train

mlflow.set_tracking_uri("sqlite:///mlflow.db")          # a team would use a shared tracking server
mlflow.set_experiment("fraud-detection")

with mlflow.start_run(run_name="lgbm") as run:
    report = train.main(out="artifacts")
    meta = json.load(open("artifacts/meta.json"))
    mlflow.log_params({"n_features": len(meta["features"]), "best_iteration": meta["best_iteration"],
                       "threshold_challenge": meta["thresholds"]["challenge"],
                       "threshold_decline": meta["thresholds"]["decline"], **meta["cost_assumptions"]})
    mlflow.log_metrics({f"val_{k}": v for k, v in report["validation"].items() if isinstance(v, (int, float))})
    mlflow.log_artifacts("artifacts", artifact_path="bundle")          # exactly what serving loads
    booster = lgb.Booster(model_file="artifacts/model.txt")
    example = np.zeros((1, len(meta["features"])))
    mlflow.lightgbm.log_model(booster, name="model", registered_model_name="fraud-detector",
                              signature=infer_signature(example, booster.predict(example)))
    print("run_id:", run.info.run_id)
