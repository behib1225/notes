"""ML coding round practice: classic algorithms with NumPy only. Tests compare against scikit-learn.
Typical interview time: 20-30 minutes per function, talking through complexity and edge cases."""
import numpy as np


def roc_auc(y_true, scores):
    """P(random positive scores above random negative); ties count 1/2. O(n log n)."""
    # TODO(student): use average ranks of the scores (Mann-Whitney U statistic).
    # >>> SOLUTION
    y, s = np.asarray(y_true), np.asarray(scores, float)
    _, inv, counts = np.unique(s, return_inverse=True, return_counts=True)
    ends = np.cumsum(counts)
    ranks = ((ends - counts + 1 + ends) / 2.0)[inv]                  # 1-based average ranks
    n_pos = y.sum()
    n_neg = len(y) - n_pos
    return float((ranks[y == 1].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg))
    # <<< SOLUTION


def average_precision(y_true, scores):
    """Sum over distinct thresholds of (recall_n - recall_{n-1}) * precision_n (scikit-learn's definition)."""
    # TODO(student): sort by score descending, evaluate precision/recall at each distinct score.
    # >>> SOLUTION
    y, s = np.asarray(y_true), np.asarray(scores, float)
    order = np.argsort(-s, kind="mergesort")
    y_sorted, s_sorted = y[order], s[order]
    last = np.r_[np.flatnonzero(np.diff(s_sorted)), len(s) - 1]       # last index of each distinct score
    tp = np.cumsum(y_sorted)[last]
    precision = tp / (last + 1)
    recall = tp / y.sum()
    return float(np.sum(np.diff(np.r_[0.0, recall]) * precision))
    # <<< SOLUTION


def ndcg_at_k(relevance, scores, k):
    """NDCG@k for one query with linear gains and log2 discounts (matches sklearn.metrics.ndcg_score)."""
    # TODO(student): DCG of the top-k by score divided by DCG of the ideal top-k.
    # >>> SOLUTION
    rel, s = np.asarray(relevance, float), np.asarray(scores, float)
    discounts = 1 / np.log2(np.arange(2, k + 2))
    dcg = (rel[np.argsort(-s, kind="mergesort")][:k] * discounts[: min(k, len(rel))]).sum()
    idcg = (np.sort(rel)[::-1][:k] * discounts[: min(k, len(rel))]).sum()
    return float(dcg / idcg) if idcg > 0 else 0.0
    # <<< SOLUTION


def kmeans(X, k, n_iter=100, seed=0):
    """k-means++ initialisation, then Lloyd iterations. Returns (centers, labels, inertia)."""
    # TODO(student): k-means++ seeding, then alternate assignment and centroid update until stable.
    # >>> SOLUTION
    X = np.asarray(X, float)
    rng = np.random.default_rng(seed)
    centers = [X[rng.integers(len(X))]]
    for _ in range(1, k):                                            # k-means++: far points more likely
        d2 = ((X[:, None, :] - np.array(centers)[None]) ** 2).sum(-1).min(1)
        centers.append(X[rng.choice(len(X), p=d2 / d2.sum())])
    centers = np.array(centers)
    for _ in range(n_iter):
        labels = ((X[:, None, :] - centers[None]) ** 2).sum(-1).argmin(1)
        new = np.array([X[labels == j].mean(0) if np.any(labels == j) else centers[j] for j in range(k)])
        if np.allclose(new, centers):
            break
        centers = new
    labels = ((X[:, None, :] - centers[None]) ** 2).sum(-1).argmin(1)
    return centers, labels, float(((X - centers[labels]) ** 2).sum())
    # <<< SOLUTION


def logistic_regression(X, y, lr=0.1, n_iter=3000, l2=1e-3):
    """Batch gradient descent on mean log loss + L2. Returns (weights, bias)."""
    # TODO(student): gradient of the log loss is X.T @ (sigmoid(Xw + b) - y) / n.
    # >>> SOLUTION
    X, y = np.asarray(X, float), np.asarray(y, float)
    w, b = np.zeros(X.shape[1]), 0.0
    for _ in range(n_iter):
        p = 1 / (1 + np.exp(-(X @ w + b)))
        w -= lr * (X.T @ (p - y) / len(y) + l2 * w)
        b -= lr * (p - y).mean()
    return w, b
    # <<< SOLUTION
