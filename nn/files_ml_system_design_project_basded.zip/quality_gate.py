"""CI quality gate. It uses ONLY validation metrics (data before training day), never the backtest."""
import json
import sys

m = json.load(open("artifacts/meta.json"))
v = m["validation"]
checks = {
    "validation PR-AUC >= 0.15 (labels as known on training day)": v["pr_auc"] >= 0.15,
    "validation cost <= 80% of approving everything": v["cost_per_1k"] <= 0.8 * m["validation_no_model_cost_per_1k"],
    "validation cost below the rules engine": v["cost_per_1k"] < m["validation_rules"]["cost_per_1k"],
    "challenged + declined <= 2% of payments": v["challenge_rate"] + v["decline_rate"] <= 0.02,
    "declined <= 0.5% of payments": v["decline_rate"] <= 0.005,
}
for name, ok in checks.items():
    print(("PASS " if ok else "FAIL ") + name)
sys.exit(0 if all(checks.values()) else 1)
