"""Replay 8,000 March payments through the real fraud service in three scenarios and monitor the
prediction logs: a COLD online store (no backfill), NORMAL traffic, and DRIFTED traffic
(prices +60%, 15% of payments moved abroad). Run from the repo root: python monitoring/simulate_drift.py"""
import json
import os
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path[:0] = [str(ROOT / "fraud"), str(ROOT / "monitoring")]
os.chdir(ROOT / "fraud")
os.environ.setdefault("API_KEY", "sim-key")
os.environ.pop("REDIS_URL", None)
from fastapi.testclient import TestClient   # noqa: E402

import app as service                        # noqa: E402
from features import FEATURES, build_offline_features, merchant_rate_table   # noqa: E402
from psi import psi                          # noqa: E402
from refresh_snapshot import snapshots       # noqa: E402

raw = pd.read_parquet("data/transactions.parquet")
offline = build_offline_features(raw, rate_table=merchant_rate_table(raw, int(raw.merchant_id.max()) + 1))
reference = offline[(offline.ts >= "2026-01-31") & (offline.ts < "2026-02-23")]   # last 3 weeks before training day
march = raw[raw.ts >= "2026-03-02"].head(8000)
headers = {"X-API-Key": os.environ["API_KEY"]}


def replay(df, backfill=True):
    service.PRED_LOG = tempfile.mktemp(suffix=".jsonl")
    with TestClient(service.app) as c:
        store = service.state["store"]
        for d, rates in snapshots(60, 89):                              # the nightly batch job
            store.put_snapshot(d, rates)
        if backfill:                                                    # load history before serving
            for r in raw[raw.ts < "2026-03-02"].itertuples():
                store.append(r.user_id, r.ts.value / 1e9, r.amount, r.merchant_id, r.txn_id)
        for r in df.itertuples():
            c.post("/v1/score", headers=headers, json={
                "txn_id": str(r.txn_id), "user_id": int(r.user_id), "ts": r.ts.isoformat(), "amount": float(r.amount),
                "merchant_id": int(r.merchant_id), "merchant_category": r.category, "country": r.country,
                "user_home_country": r.home_country})
    return pd.DataFrame([json.loads(line) for line in open(service.PRED_LOG)])


rng = np.random.default_rng(0)
drifted = march.copy()
drifted["amount"] = (drifted.amount * 1.6).round(2)
drifted.loc[rng.random(len(drifted)) < 0.15, "country"] = "FR"

report = {}
for name, df, backfill in [("cold_store", march, False), ("normal", march, True), ("drifted", drifted, True)]:
    log = replay(df, backfill)
    feats = pd.DataFrame(list(log.features))
    report[name] = {f: round(psi(reference[f], feats[f]), 3) for f in FEATURES}
    report[name]["flagged_share"] = round(float((log.decision != "approve").mean()), 4)
    report[name]["p99_latency_ms"] = round(float(np.percentile(log.latency_ms, 99)), 2)
table = pd.DataFrame(report)
print(table.to_string())
for scenario in ["cold_store", "drifted"]:
    alerts = table.loc[FEATURES, scenario][lambda s: s > 0.25]
    print(f"ALERTS {scenario} (PSI > 0.25):", ", ".join(alerts.index) or "none")
