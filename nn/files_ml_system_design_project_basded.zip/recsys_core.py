"""Shared two-stage recommender logic, used by offline training AND online serving.
Stage 1 (retrieval): embedding nearest neighbours (FAISS) + trending items  -> ~300 candidates
Stage 2 (ranking):  LightGBM LambdaRank over ~10 features                   -> top-k
"""
from dataclasses import dataclass

import faiss
import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.decomposition import TruncatedSVD

N_RETRIEVE, N_TRENDING, HISTORY_LEN = 200, 100, 50
RANK_FEATURES = ["emb_score", "emb_rank", "from_emb", "from_trending", "trend_7d", "item_total",
                 "item_age", "genre_affinity", "user_n_events", "user_days_since_last"]


def train_item_embeddings(events: pd.DataFrame, n_users: int, n_items: int, dim: int = 32, seed: int = 0):
    """Matrix factorisation via truncated SVD of the (user x item) interaction matrix.
    Items with no interactions get a zero vector: that is the item cold-start problem."""
    x = csr_matrix((np.ones(len(events), np.float32), (events.user_id, events.item_id)), shape=(n_users, n_items))
    x.data[:] = 1.0                                              # duplicates -> binary
    svd = TruncatedSVD(n_components=dim, random_state=seed).fit(x)
    v = svd.components_.T.astype(np.float32)                     # (n_items, dim)
    return np.ascontiguousarray(v)


def build_index(item_vecs: np.ndarray) -> faiss.Index:
    index = faiss.IndexFlatIP(item_vecs.shape[1])                # exact inner-product search
    index.add(item_vecs)
    return index


@dataclass
class Snapshot:
    """Everything stage 1 and 2 need, computed from events strictly before `now` (point-in-time)."""
    now: float
    item_vecs: np.ndarray
    index: faiss.Index
    items: pd.DataFrame          # item_id, genre, release_day
    trend_7d: np.ndarray         # per item: events in [now-7, now)
    item_total: np.ndarray       # per item: events before now
    trending: np.ndarray         # top item ids by trend_7d


def make_snapshot(events, items, now, item_vecs) -> Snapshot:
    past = events[events.day < now]
    n = len(items)
    trend = np.bincount(past[past.day >= now - 7].item_id, minlength=n).astype(float)
    total = np.bincount(past.item_id, minlength=n).astype(float)
    released = (items.release_day.to_numpy() < now)
    trending = np.argsort(-np.where(released, trend, -1))[:N_TRENDING]
    return Snapshot(now, item_vecs, build_index(item_vecs), items, trend, total, trending)


def user_vector(snap: Snapshot, hist_items):
    """Query vector = mean of the vectors of the user's last 50 titles. This is item-to-item retrieval
    ("more like what you watched"), not a learned user embedding; it updates instantly with new plays."""
    if len(hist_items) == 0:
        return None
    # TODO(student): average the item vectors of the last HISTORY_LEN items; None if all-zero.
    # >>> SOLUTION
    v = snap.item_vecs[np.asarray(hist_items[-HISTORY_LEN:])].mean(0)
    return v if np.linalg.norm(v) > 0 else None
    # <<< SOLUTION


def candidates_and_features(snap: Snapshot, hist_items, hist_days) -> pd.DataFrame:
    """Stage 1 + feature assembly for ONE user. Returns one row per candidate."""
    seen = set(int(i) for i in hist_items)
    released = snap.items.release_day.to_numpy() < snap.now
    cands = {}
    uv = user_vector(snap, hist_items)
    if uv is not None:
        scores, ids = snap.index.search(uv[None, :].astype(np.float32), N_RETRIEVE + len(seen))
        r = 0
        for s, i in zip(scores[0], ids[0]):
            if i >= 0 and i not in seen and released[i]:
                cands[int(i)] = {"emb_score": float(s), "emb_rank": r, "from_emb": 1, "from_trending": 0}
                r += 1
                if r >= N_RETRIEVE:
                    break
    for i in snap.trending:
        i = int(i)
        if i in seen:
            continue
        c = cands.setdefault(i, {"emb_score": float(snap.item_vecs[i] @ uv) if uv is not None else 0.0,
                                 "emb_rank": N_RETRIEVE, "from_emb": 0, "from_trending": 0})
        c["from_trending"] = 1
    if not cands:
        return pd.DataFrame(columns=["item_id"] + RANK_FEATURES)
    df = pd.DataFrame.from_dict(cands, orient="index")
    df.index.name = "item_id"
    df = df.reset_index()
    ids = df.item_id.to_numpy()
    genres = snap.items.genre.to_numpy()
    hist_genres = pd.Series(genres[np.asarray(hist_items, dtype=int)]) if len(hist_items) else pd.Series([], dtype=object)
    share = hist_genres.value_counts(normalize=True)
    df["trend_7d"] = snap.trend_7d[ids]
    df["item_total"] = snap.item_total[ids]
    df["item_age"] = snap.now - snap.items.release_day.to_numpy()[ids]
    df["genre_affinity"] = [float(share.get(g, 0.0)) for g in genres[ids]]
    df["user_n_events"] = float(len(hist_items))
    df["user_days_since_last"] = float(snap.now - hist_days[-1]) if len(hist_days) else 999.0
    return df
