"""Learning to rank from position-biased clicks. Evaluated two ways on 1,000 held-out queries:
NDCG@10 against adjudicated relevance judgments, and simulated purchases per search (the business
metric). Run: python train.py   (about 3 minutes)"""
import json
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd

from generate_data import CLICK_IF_SEEN, EXAMINE, RATER_ERROR, purchase_prob, relevance
from mlsd_common.stats import paired_bootstrap_diff
from search_core import LTR_FEATURES, SearchIndex, rrf

K = 10
PARAMS = dict(n_estimators=300, learning_rate=0.05, num_leaves=31, min_child_samples=50, random_state=0, verbose=-1)


def ndcg_at_k(ranked_ids, rel_all, k=K):
    gains = 2.0 ** rel_all[np.asarray(ranked_ids[:k], dtype=int)] - 1
    dcg = (gains / np.log2(np.arange(2, len(gains) + 2))).sum()
    ideal = np.sort(2.0 ** rel_all - 1)[::-1][:k]
    idcg = (ideal / np.log2(np.arange(2, len(ideal) + 2))).sum()
    return dcg / idcg if idcg > 0 else 0.0


def purchases_at_k(ranked_ids, rel_all, quality, k=K):
    """Expected purchases per search under the simulator's user model (a stand-in for an A/B test)."""
    ids = np.asarray(ranked_ids[:k], dtype=int)
    rel, q = rel_all[ids], quality[ids]
    p_click = np.vectorize(CLICK_IF_SEEN.get)(rel) * q
    return float((EXAMINE[: len(ids)] * p_click * purchase_prob(rel, q)).sum())


def click_training_set(idx, sessions):
    parts = []
    for sid, g in sessions.groupby("session_id", sort=False):
        c = idx.candidates(g["query"].iat[0]).merge(g[["product_id", "position", "click"]], on="product_id")
        c["session_id"] = sid
        parts.append(c)
    return pd.concat(parts, ignore_index=True)


def estimate_propensity(sessions):
    """Randomised traffic: CTR(slot)/CTR(slot 1) estimates P(slot examined); fit p(k) = 1 / k**eta."""
    ctr = sessions[sessions.randomized].groupby("position").click.mean().to_numpy()
    k = np.arange(1, len(ctr) + 1)
    # TODO(student): fit eta by least squares on log(ctr / ctr[0]) = -eta * log(k).
    # >>> SOLUTION
    eta = -np.polyfit(np.log(k), np.log(ctr / ctr[0]), 1)[0]
    # <<< SOLUTION
    return 1.0 / k ** eta, ctr / ctr[0], eta


def fit_lambdarank(df, label):
    df = df.sort_values("session_id", kind="mergesort")
    m = lgb.LGBMRanker(objective="lambdarank", **PARAMS)
    m.fit(df[LTR_FEATURES], df[label], group=df.groupby("session_id", sort=False).size().to_numpy())
    return m


def main():
    products = pd.read_parquet("data/products.parquet")
    sessions = pd.read_parquet("data/sessions.parquet")
    evalq = pd.read_parquet("data/eval_queries.parquet")
    judged = pd.read_parquet("data/judged_queries.parquet")
    quality = pd.read_parquet("data/hidden_quality.parquet").quality.to_numpy()
    idx = SearchIndex(products)
    rng = np.random.default_rng(5)

    train = click_training_set(idx, sessions[~sessions.randomized])
    prop, raw, eta = estimate_propensity(sessions)
    print("raw CTR ratio by slot:", np.round(raw, 2).tolist(), f"| fitted eta = {eta:.2f}")
    train["click_ipw"] = train.click / prop[train.position]            # E[click / p] = P(click | seen)
    jparts = []
    for it in judged.to_dict("records"):                               # one rater per query: noisy grades
        c = idx.candidates(it["query"])
        true = relevance(products, it)[c.product_id.to_numpy()]
        noise = np.where(rng.random(len(c)) < RATER_ERROR, rng.choice([-1, 1], len(c)), 0)
        c["label"], c["session_id"] = np.clip(true + noise, 0, 3), it["qid"]
        jparts.append(c)
    models = {
        "ltr_clicks": fit_lambdarank(train, "click"),
        "pointwise_clicks_naive": lgb.LGBMRegressor(**PARAMS).fit(train[LTR_FEATURES], train.click),
        "pointwise_clicks_ipw": lgb.LGBMRegressor(**PARAMS).fit(train[LTR_FEATURES], train.click_ipw),
        "ltr_noisy_human_labels": fit_lambdarank(pd.concat(jparts, ignore_index=True), "label"),
    }

    rows = []
    for it in evalq.to_dict("records"):
        rel = relevance(products, it)                                  # adjudicated gold judgments
        q = it["query"]
        bm = list(idx.bm25_top(q, 50))
        sem = list(np.argsort(-idx.semantic_scores(q), kind="stable")[:50])
        ranked = {"bm25": bm, "semantic": sem, "hybrid_rrf": rrf([bm, sem])}
        cand = idx.candidates(q)
        for name, m in models.items():
            ranked[name] = cand.product_id.to_numpy()[np.argsort(-m.predict(cand[LTR_FEATURES]), kind="stable")]
        fixed = idx.candidates(idx.correct(q))
        ranked["ltr_clicks+spelling (shipped)"] = fixed.product_id.to_numpy()[
            np.argsort(-models["ltr_clicks"].predict(fixed[LTR_FEATURES]), kind="stable")]
        r = {"synonym": it["synonym"], "typo": it["typo"]}
        for name, lst in ranked.items():
            r[f"ndcg|{name}"], r[f"buy|{name}"] = ndcg_at_k(lst, rel), purchases_at_k(lst, rel, quality)
        rows.append(r)
    res = pd.DataFrame(rows)
    names = list(ranked)
    table = pd.DataFrame({
        "ndcg_all": [res[f"ndcg|{n}"].mean() for n in names],
        "ndcg_synonym": [res[~res.typo & res.synonym][f"ndcg|{n}"].mean() for n in names],
        "ndcg_exact": [res[~res.typo & ~res.synonym][f"ndcg|{n}"].mean() for n in names],
        "ndcg_typo": [res[res.typo][f"ndcg|{n}"].mean() for n in names],
        "purchases_per_100_searches": [100 * res[f"buy|{n}"].mean() for n in names]}, index=names).round(4)
    print(table.to_string())
    shipped = "ltr_clicks+spelling (shipped)"
    diffs = {
        "ndcg: ltr_clicks - hybrid_rrf": paired_bootstrap_diff(res["ndcg|ltr_clicks"], res["ndcg|hybrid_rrf"]),
        "purchases/100: ltr_clicks - hybrid_rrf": paired_bootstrap_diff(100 * res["buy|ltr_clicks"], 100 * res["buy|hybrid_rrf"]),
        "ndcg: shipped - ltr_clicks": paired_bootstrap_diff(res[f"ndcg|{shipped}"], res["ndcg|ltr_clicks"]),
        "ndcg: pointwise ipw - naive": paired_bootstrap_diff(res["ndcg|pointwise_clicks_ipw"], res["ndcg|pointwise_clicks_naive"]),
        "purchases/100: human labels - ltr_clicks": paired_bootstrap_diff(100 * res["buy|ltr_noisy_human_labels"], 100 * res["buy|ltr_clicks"]),
    }
    for k, (d, lo, hi) in diffs.items():
        print(f"{k:45s} {d:+.4f}  95% CI [{lo:+.4f}, {hi:+.4f}]")
    out = Path("artifacts")
    out.mkdir(exist_ok=True)
    models["ltr_clicks"].booster_.save_model(out / "ranker.txt")
    products.to_parquet(out / "products.parquet", index=False)
    (out / "meta.json").write_text(json.dumps({"version": "search-ltr-v2", "features": LTR_FEATURES,
                                               "eta": eta, "metrics": table.loc[shipped].to_dict()}, indent=2))


if __name__ == "__main__":
    main()
