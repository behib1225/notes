import pytest
from fastapi.testclient import TestClient

from app import app

KEY = {"X-API-Key": "test-key"}


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-key")
    with TestClient(app) as c:
        yield c


def test_auth_and_validation(client):
    assert client.get("/v1/search", params={"q": "tee"}).status_code == 401
    assert client.get("/v1/search", params={"q": ""}, headers=KEY).status_code == 422


def test_exact_query(client):
    top = client.get("/v1/search", params={"q": "volt wireless headphones"}, headers=KEY).json()["results"][0]
    assert "headphones" in top["title"] and "volt" in top["title"]


def test_synonym_query(client):
    titles = [x["title"] for x in client.get("/v1/search", params={"q": "black sneakers"}, headers=KEY).json()["results"]]
    assert sum("running shoes" in t for t in titles) >= 8


def test_typo_query_is_corrected(client):
    r = client.get("/v1/search", params={"q": "blak snekers"}, headers=KEY).json()
    assert r["corrected_query"] == "black sneakers"
    assert sum("running shoes" in x["title"] for x in r["results"]) >= 8
