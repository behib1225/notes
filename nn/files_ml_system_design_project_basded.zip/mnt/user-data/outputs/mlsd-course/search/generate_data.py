"""Synthetic product catalog + search logs with POSITION BIAS and QUALITY-dependent clicks.
Run: python generate_data.py -> data/{products,sessions,eval_queries,judged_queries,hidden_quality}.parquet
"""
from pathlib import Path

import numpy as np
import pandas as pd

RNG = np.random.default_rng(11)
TYPES = {  # canonical name -> (synonyms, adjectives)
    "running shoes": (["sneakers", "trainers"], ["lightweight", "waterproof", "trail"]),
    "t-shirt": (["tee", "tshirt"], ["cotton", "slim", "oversized"]),
    "jeans": (["denim"], ["slim", "relaxed", "stretch"]),
    "jacket": (["coat", "parka"], ["waterproof", "insulated", "lightweight"]),
    "backpack": (["rucksack", "daypack"], ["waterproof", "laptop", "travel"]),
    "headphones": (["earphones", "headset"], ["wireless", "noise cancelling", "sport"]),
    "laptop": (["notebook"], ["gaming", "ultralight", "business"]),
    "phone case": (["phone cover"], ["slim", "rugged", "clear"]),
    "water bottle": (["flask"], ["insulated", "sport", "glass"]),
    "desk lamp": (["reading light"], ["led", "dimmable", "clip"]),
}
BRANDS = ["acme", "nordic", "zenith", "volt", "peak", "urban", "orbit", "lumen", "terra", "nova", "apex", "kite"]
COLORS = ["black", "white", "blue", "red", "green", "grey"]
EXAMINE = np.array([1.0, 0.62, 0.47, 0.37, 0.30, 0.25, 0.21, 0.18, 0.16, 0.14])   # P(user looks at slot k)
CLICK_IF_SEEN = {0: 0.03, 1: 0.15, 2: 0.45, 3: 0.85}                             # by true relevance
RATER_ERROR = 0.25        # a single human rater is off by one grade 25% of the time


def hidden_quality(products: pd.DataFrame) -> np.ndarray:
    """How appealing a product is beyond matching the query (rating, price for its type). Users react
    to it; it is NOT in the data a ranker sees, only its observable proxies (rating, relative price)."""
    rel_price = products.price / products.groupby("ptype").price.transform("median")
    return np.clip(0.55 + 0.25 * (products.rating - 4.1) - 0.2 * np.log(rel_price), 0.15, 1.0).to_numpy()


def purchase_prob(rel, quality):
    """P(purchase | click): only good matches convert, and better products convert more."""
    return np.where(rel >= 2, 0.35 * quality, 0.02)


def make_products(n=3000):
    rows = []
    for pid in range(n):
        t = RNG.choice(list(TYPES))
        syns, adjs = TYPES[t]
        b, c, a = RNG.choice(BRANDS), RNG.choice(COLORS), RNG.choice(adjs)
        title = f"{b} {a} {t} {c}"
        syn = RNG.choice(syns)
        desc = f"{c} {a} {syn} from {b}. a great {t} and {syn} for every day."
        rows.append((pid, title, desc, t, b, c, a, round(float(np.exp(RNG.normal(3.5, 0.6))), 2),
                     int(np.exp(RNG.normal(3, 1.2))), round(float(np.clip(RNG.normal(4.1, 0.5), 1, 5)), 1)))
    return pd.DataFrame(rows, columns=["product_id", "title", "description", "ptype", "brand", "color", "adj",
                                       "price", "sales_30d", "rating"])


def make_intent():
    t = RNG.choice(list(TYPES))
    syns, adjs = TYPES[t]
    intent = {"ptype": t, "brand": RNG.choice(BRANDS) if RNG.random() < 0.3 else None,
              "color": RNG.choice(COLORS) if RNG.random() < 0.5 else None,
              "adj": RNG.choice(adjs) if RNG.random() < 0.25 else None}
    intent["synonym"] = bool(RNG.random() >= 0.5)                 # half the queries use a synonym
    noun = RNG.choice(syns) if intent["synonym"] else t
    words = [w for w in (intent["brand"], intent["adj"], intent["color"]) if w] + [noun]
    q = " ".join(words)
    intent["typo"] = bool(RNG.random() < 0.1)                      # 10% contain a typo
    if intent["typo"]:
        i = RNG.integers(0, len(q))
        q = q[:i] + q[i + 1:]
    intent["query"] = q
    return intent


def relevance(products: pd.DataFrame, intent) -> np.ndarray:
    """Graded truth 0-3, what a human rater would assign."""
    rel = (products.ptype.to_numpy() == intent["ptype"]).astype(int)
    for f in ("brand", "color", "adj"):
        if intent[f] is not None:
            rel += rel.astype(bool) & (products[f].to_numpy() == intent[f])
    return np.minimum(rel, 3)


def main(out="data", n_sessions=20_000, n_eval=1_000, n_judged=2_000):
    from search_core import SearchIndex    # the OLD production ranker = hybrid retrieval + RRF
    products = make_products()
    quality = hidden_quality(products)
    idx = SearchIndex(products)
    sess = []
    for s in range(n_sessions):
        it = make_intent()
        shown = idx.hybrid_top(it["query"], 10)
        randomized = RNG.random() < 0.05                            # 5% of traffic: shuffled top 10
        if randomized:
            shown = RNG.permutation(shown)
        rel, q = relevance(products, it)[shown], quality[shown]
        seen = RNG.random(10) < EXAMINE[: len(shown)]
        click = seen & (RNG.random(10) < np.vectorize(CLICK_IF_SEEN.get)(rel) * q)
        buy = click & (RNG.random(10) < purchase_prob(rel, q))
        for pos, (pid, c, b) in enumerate(zip(shown, click, buy)):
            sess.append((s, it["query"], int(pid), pos, int(c), int(b), randomized))
    sessions = pd.DataFrame(sess, columns=["session_id", "query", "product_id", "position", "click", "purchase",
                                           "randomized"])
    ev = [{"qid": q, **make_intent()} for q in range(n_eval)]
    judged = [{"qid": q, **make_intent()} for q in range(n_judged)]   # queries rated by ONE human each
    Path(out).mkdir(exist_ok=True)
    products.to_parquet(f"{out}/products.parquet", index=False)
    sessions.to_parquet(f"{out}/sessions.parquet", index=False)
    pd.DataFrame(ev).to_parquet(f"{out}/eval_queries.parquet", index=False)
    pd.DataFrame(judged).to_parquet(f"{out}/judged_queries.parquet", index=False)
    pd.DataFrame({"product_id": products.product_id, "quality": quality}).to_parquet(
        f"{out}/hidden_quality.parquet", index=False)          # simulator-only: used to score purchases
    print(f"{len(products):,} products, {n_sessions:,} sessions, CTR {sessions.click.mean():.3f}, "
          f"{n_eval} eval queries")


if __name__ == "__main__":
    main()
