"""Product search service.   Run: API_KEY=dev-key uvicorn app:app --port 8002"""
import json
import os
import secrets
import time
from contextlib import asynccontextmanager

import lightgbm as lgb
import pandas as pd
from fastapi import Depends, FastAPI, Header, HTTPException, Query

from search_core import LTR_FEATURES, SearchIndex

ART = os.getenv("ARTIFACTS_DIR", "artifacts")
state = {}


@asynccontextmanager
async def lifespan(app: FastAPI):
    state["meta"] = json.loads(open(f"{ART}/meta.json").read())
    state["ranker"] = lgb.Booster(model_file=f"{ART}/ranker.txt")
    state["idx"] = SearchIndex(pd.read_parquet(f"{ART}/products.parquet"))     # read-only after startup
    yield


app = FastAPI(title="Product search", lifespan=lifespan)


def require_api_key(x_api_key: str | None = Header(default=None)):
    expected = os.getenv("API_KEY")
    if not expected:
        raise HTTPException(503, "server misconfigured: set API_KEY")
    if x_api_key is None or not secrets.compare_digest(x_api_key, expected):
        raise HTTPException(401, "invalid or missing X-API-Key header")


@app.get("/healthz")
def healthz():
    return {"status": "ok", "ready": "idx" in state}


@app.get("/v1/search", dependencies=[Depends(require_api_key)])
def search(q: str = Query(min_length=1, max_length=200), k: int = Query(10, ge=1, le=50)):
    t0 = time.perf_counter()
    idx = state["idx"]
    corrected = idx.correct(q)                       # query understanding: spelling correction
    cand = idx.candidates(corrected)
    cand["score"] = state["ranker"].predict(cand[LTR_FEATURES].to_numpy(float))
    top = cand.nlargest(k, "score")
    p = idx.p.set_index("product_id").loc[top.product_id]
    return {"query": q, "corrected_query": corrected if corrected != q.lower().strip() else None,
            "model_version": state["meta"]["version"],
            "results": [{"product_id": int(i), "title": t, "price": float(pr)} for i, t, pr in zip(p.index, p.title, p.price)],
            "latency_ms": round((time.perf_counter() - t0) * 1000, 2)}
