import pytest
from fastapi.testclient import TestClient

from app import app, state

KEY = {"X-API-Key": "test-key"}


@pytest.fixture
def client(monkeypatch):
    monkeypatch.setenv("API_KEY", "test-key")
    with TestClient(app) as c:
        yield c


def test_auth_required(client):
    assert client.get("/v1/recommend/10").status_code == 401


def test_known_user_gets_k_unseen_items(client):
    r = client.get("/v1/recommend/10?k=10", headers=KEY).json()
    ids = [x["item_id"] for x in r["items"]]
    assert r["strategy"] == "two_stage" and len(set(ids)) == 10
    assert not set(ids) & set(state["hist"][10][0])          # never recommend what was watched


def test_cold_start_user_gets_trending(client):
    r = client.get("/v1/recommend/999999", headers=KEY).json()
    assert r["strategy"] == "trending_fallback" and len(r["items"]) == 10


def test_new_event_changes_recommendations(client):
    before = [x["item_id"] for x in client.get("/v1/recommend/123456", headers=KEY).json()["items"]]
    for item in (5, 6, 7):
        assert client.post("/v1/events", json={"user_id": 123456, "item_id": item}, headers=KEY).status_code == 200
    after = client.get("/v1/recommend/123456", headers=KEY).json()
    assert after["strategy"] == "two_stage" and [x["item_id"] for x in after["items"]] != before
