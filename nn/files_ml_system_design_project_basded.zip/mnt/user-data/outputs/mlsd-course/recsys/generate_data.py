"""Synthetic streaming-service interactions with real-world structure:
taste clusters (genres), a long-tailed popularity curve, and new releases every week.
Run:  python generate_data.py  -> data/items.parquet, data/events.parquet  (seed 7)
"""
from pathlib import Path

import numpy as np
import pandas as pd

RNG = np.random.default_rng(7)
N_USERS, N_ITEMS, N_GENRES, DIM, N_DAYS = 5_000, 2_000, 10, 16, 120
GENRES = ["action", "comedy", "drama", "horror", "romance", "scifi", "documentary", "kids", "thriller", "anime"]


def main(out="data"):
    centers = RNG.normal(0, 1, (N_GENRES, DIM))
    genre = RNG.integers(0, N_GENRES, N_ITEMS)
    item_vec = centers[genre] + RNG.normal(0, 0.6, (N_ITEMS, DIM))
    pop_bias = RNG.gumbel(0, 1.0, N_ITEMS)                       # long tail: a few hits
    # 75% of the catalog exists before day 0; 25% is released during the 120 days.
    release = np.where(RNG.random(N_ITEMS) < 0.75, -RNG.uniform(30, 1000, N_ITEMS), RNG.uniform(0, N_DAYS, N_ITEMS))
    items = pd.DataFrame({"item_id": np.arange(N_ITEMS), "genre": np.array(GENRES)[genre],
                          "release_day": release.round(2)})

    rows = []
    for u in range(N_USERS):
        favs = RNG.choice(N_GENRES, RNG.integers(1, 3), replace=False)
        u_vec = centers[favs].mean(0) + RNG.normal(0, 0.5, DIM)
        base = 0.35 * item_vec @ u_vec + pop_bias
        n = RNG.poisson(RNG.gamma(1.5, 0.25) * N_DAYS)
        seen = np.zeros(N_ITEMS, bool)
        for t in np.sort(RNG.uniform(0, N_DAYS, n)):
            age = t - release
            logit = base + 2.0 * np.exp(-np.clip(age, 0, None) / 10.0)   # new releases get buzz
            logit[(age < 0) | seen] = -np.inf
            p = np.exp(logit - logit.max())
            i = RNG.choice(N_ITEMS, p=p / p.sum())
            seen[i] = True
            rows.append((u, i, t))
    ev = pd.DataFrame(rows, columns=["user_id", "item_id", "day"]).sort_values("day", kind="mergesort")
    Path(out).mkdir(exist_ok=True)
    items.to_parquet(f"{out}/items.parquet", index=False)
    ev.to_parquet(f"{out}/events.parquet", index=False)
    print(f"{len(ev):,} events, {ev.user_id.nunique():,} users, {ev.item_id.nunique():,} items with events")


if __name__ == "__main__":
    main()
