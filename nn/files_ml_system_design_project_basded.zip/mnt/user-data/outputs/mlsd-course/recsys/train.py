"""Train and evaluate the two-stage recommender with a time-based protocol and confidence intervals.
  days   0-89   history for embeddings + features      days  90-104  ranker labels
  days   0-104  history for testing                    days 105-119  test labels
Run: python train.py   (about 1 to 2 minutes)
"""
import json
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd

from mlsd_common.stats import bootstrap_ci, paired_bootstrap_diff
from recsys_core import RANK_FEATURES, candidates_and_features, make_snapshot, train_item_embeddings

K = 10


def histories(events, now):
    past = events[events.day < now]
    return {u: (g.item_id.to_numpy(), g.day.to_numpy()) for u, g in past.groupby("user_id")}


def build_set(events, items, n_users, now, horizon, max_users=None, seed=0):
    """Candidates + features as of `now`; label = the user plays the item in [now, now + horizon)."""
    vecs = train_item_embeddings(events[events.day < now], n_users, len(items))
    snap = make_snapshot(events, items, now, vecs)
    hist = histories(events, now)
    fut = events[(events.day >= now) & (events.day < now + horizon)]
    truth = fut.groupby("user_id").item_id.apply(set).to_dict()
    users = [u for u in truth if u in hist]
    n_cold = len(truth) - len(users)                 # active in the window but no history: not evaluated here
    if max_users:
        users = list(np.random.default_rng(seed).choice(users, min(max_users, len(users)), replace=False))
    parts = []
    for u in users:
        df = candidates_and_features(snap, *hist[u])
        df["user_id"] = u
        df["label"] = df.item_id.isin(truth[u]).astype(int)
        parts.append(df)
    return pd.concat(parts, ignore_index=True), truth, snap, hist, n_cold


def per_user_metrics(ranked: dict, truth: dict, k=K):
    """Recall@k = hits / min(|truth|, k) and binary NDCG@k, one value per user."""
    rec, ndcg = [], []
    for u, items in ranked.items():
        t = truth[u]
        # TODO(student): compute this user's recall@k and NDCG@k (log2 discounts) and append them.
        # >>> SOLUTION
        hits = [1.0 if i in t else 0.0 for i in items[:k]]
        rec.append(sum(hits) / min(len(t), k))
        dcg = sum(h / np.log2(r + 2) for r, h in enumerate(hits))
        idcg = sum(1 / np.log2(r + 2) for r in range(min(len(t), k)))
        ndcg.append(dcg / idcg)
        # <<< SOLUTION
    return np.array(rec), np.array(ndcg)


def summary(rec, ndcg):
    r, n = bootstrap_ci(np.mean, (rec,)), bootstrap_ci(np.mean, (ndcg,))
    return {"recall@10": [round(x, 4) for x in r], "ndcg@10": [round(x, 4) for x in n]}   # [point, lo, hi]


def main():
    items = pd.read_parquet("data/items.parquet")
    events = pd.read_parquet("data/events.parquet")
    n_users = int(events.user_id.max()) + 1

    tr, _, _, _, _ = build_set(events, items, n_users, now=90, horizon=15, max_users=3000)
    tr = tr.sort_values("user_id", kind="mergesort")
    print(f"ranker train: {len(tr):,} rows, positive rate {tr.label.mean():.3%}")
    ranker = lgb.LGBMRanker(objective="lambdarank", n_estimators=300, learning_rate=0.05,
                            num_leaves=31, min_child_samples=50, random_state=0, verbose=-1)
    ranker.fit(tr[RANK_FEATURES], tr.label, group=tr.groupby("user_id", sort=False).size().to_numpy())

    te, truth, snap, hist, n_cold = build_set(events, items, n_users, now=105, horizon=15)
    te["score"] = ranker.predict(te[RANK_FEATURES])
    users = te.user_id.unique()
    by_user = {u: g for u, g in te.groupby("user_id")}
    trending = [int(i) for i in snap.trending]
    systems = {
        "popularity": per_user_metrics({u: [i for i in trending if i not in set(hist[u][0])][:K] for u in users}, truth),
        "embedding_only": per_user_metrics(
            {u: g[g.from_emb == 1].sort_values("emb_rank").item_id.tolist() for u, g in by_user.items()}, truth),
        "two_stage": per_user_metrics(
            {u: g.sort_values("score", ascending=False).item_id.tolist() for u, g in by_user.items()}, truth),
    }
    results = {"test_users": int(len(users)), "cold_users_not_evaluated": int(n_cold),
               "candidate_recall": round(float(te.groupby("user_id").label.sum().sum()
                                              / sum(len(truth[u]) for u in users)), 4),
               **{name: summary(*m) for name, m in systems.items()},
               "two_stage_minus_embedding_ndcg": [round(x, 4) for x in paired_bootstrap_diff(
                   systems["two_stage"][1], systems["embedding_only"][1])]}
    print(json.dumps(results, indent=2))

    # Serving bundle (no pickle): embeddings retrained on all data up to day 120.
    out = Path("artifacts")
    out.mkdir(exist_ok=True)
    ranker.booster_.save_model(out / "ranker.txt")
    np.save(out / "item_vecs.npy", train_item_embeddings(events, n_users, len(items)))
    items.to_parquet(out / "items.parquet", index=False)
    events[["user_id", "item_id", "day"]].to_parquet(out / "events.parquet", index=False)  # seeds the online store
    (out / "meta.json").write_text(json.dumps({"version": "recsys-v2", "now": 120.0, "features": RANK_FEATURES,
                                               "metrics": results}, indent=2))


if __name__ == "__main__":
    main()
