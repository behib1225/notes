"""Two-stage recommendation service.   Run: API_KEY=dev-key uvicorn app:app --port 8001"""
import json
import os
import secrets
import threading
import time
from contextlib import asynccontextmanager

import lightgbm as lgb
import numpy as np
import pandas as pd
from fastapi import Depends, FastAPI, Header, HTTPException
from pydantic import BaseModel

from recsys_core import RANK_FEATURES, candidates_and_features, make_snapshot

ART = os.getenv("ARTIFACTS_DIR", "artifacts")
state = {}
_lock = threading.Lock()          # user histories are written and read from FastAPI's thread pool


@asynccontextmanager
async def lifespan(app: FastAPI):
    meta = json.loads(open(f"{ART}/meta.json").read())
    events = pd.read_parquet(f"{ART}/events.parquet")
    state["meta"], state["ranker"] = meta, lgb.Booster(model_file=f"{ART}/ranker.txt")
    state["snap"] = make_snapshot(events, pd.read_parquet(f"{ART}/items.parquet"), meta["now"],
                                  np.load(f"{ART}/item_vecs.npy"))
    # Online store of user histories (in production: Redis or Cassandra keyed by user_id).
    state["hist"] = {u: (list(g.item_id), list(g.day)) for u, g in events.groupby("user_id")}
    yield


app = FastAPI(title="Recommendations", lifespan=lifespan)


def require_api_key(x_api_key: str | None = Header(default=None)):
    expected = os.getenv("API_KEY")
    if not expected:
        raise HTTPException(503, "server misconfigured: set API_KEY")
    if x_api_key is None or not secrets.compare_digest(x_api_key, expected):
        raise HTTPException(401, "invalid or missing X-API-Key header")


class Event(BaseModel):
    user_id: int
    item_id: int


@app.get("/healthz")
def healthz():
    return {"status": "ok", "ready": "snap" in state}


@app.post("/v1/events", dependencies=[Depends(require_api_key)])
def add_event(e: Event):
    """Real-time signal: the next request already reflects what the user just watched."""
    snap = state["snap"]
    if not 0 <= e.item_id < len(snap.items):
        raise HTTPException(404, "unknown item")
    with _lock:
        items, days = state["hist"].setdefault(e.user_id, ([], []))
        items.append(e.item_id)
        days.append(snap.now)
        n = len(items)
    return {"ok": True, "history_len": n}


@app.get("/v1/recommend/{user_id}", dependencies=[Depends(require_api_key)])
def recommend(user_id: int, k: int = 10):
    t0 = time.perf_counter()
    snap, meta = state["snap"], state["meta"]
    with _lock:                                    # copy under the lock, compute outside it
        items, days = (list(x) for x in state["hist"].get(user_id, ([], [])))
    if not items:                                  # cold-start user -> trending fallback
        recs, strategy = [int(i) for i in snap.trending[:k]], "trending_fallback"
    else:
        df = candidates_and_features(snap, np.array(items), np.array(days))
        df["score"] = state["ranker"].predict(df[RANK_FEATURES].to_numpy(float))
        recs, strategy = df.nlargest(k, "score").item_id.astype(int).tolist(), "two_stage"
    genres = snap.items.genre.to_numpy()
    return {"user_id": user_id, "strategy": strategy, "model_version": meta["version"],
            "items": [{"item_id": i, "genre": str(genres[i])} for i in recs],
            "latency_ms": round((time.perf_counter() - t0) * 1000, 2)}


@app.get("/v1/similar/{item_id}", dependencies=[Depends(require_api_key)])
def similar(item_id: int, k: int = 10):
    snap = state["snap"]
    if not 0 <= item_id < len(snap.items):
        raise HTTPException(404, "unknown item")
    v = snap.item_vecs[item_id:item_id + 1]
    if not np.any(v):
        return {"item_id": item_id, "similar": [], "note": "no embedding yet (cold-start item)"}
    _, ids = snap.index.search(v, k + 1)
    return {"item_id": item_id, "similar": [int(i) for i in ids[0] if i != item_id][:k]}
