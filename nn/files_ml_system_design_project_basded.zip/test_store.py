import os
import threading

import fakeredis
import pytest

from store import InMemoryStore, RedisStore


def stores():
    out = [InMemoryStore(), RedisStore(client=fakeredis.FakeRedis(decode_responses=True))]
    if os.getenv("REDIS_URL"):                       # also test a real Redis when one is available (CI)
        real = RedisStore(os.environ["REDIS_URL"], timeout=2.0)
        real.r.flushdb()
        out.append(real)
    return out


@pytest.mark.parametrize("store", stores())
def test_window_and_snapshot_semantics(store):
    for i, t in enumerate([100.0, 200.0, 300.0]):
        store.append("u1", t, 10.0 * (i + 1), i, f"t{i}")
    assert [e[0] for e in store.recent("u1", 150.0, 300.0)] == [200.0]          # [since, until)
    store.put_snapshot(5, {1: 0.01})
    store.put_snapshot(7, {1: 0.02})
    assert store.get_rate(1, 6, 0.005) == (0.01, 5)                             # newest snapshot <= day
    assert store.get_rate(1, 9, 0.005) == (0.02, 7)
    assert store.get_rate(1, 4, 0.005) == (0.005, None)


def test_in_memory_store_is_thread_safe():
    """8 threads write and read the same user at once, as FastAPI's thread pool can."""
    store, errors = InMemoryStore(window_secs=1e12), []

    def work(k):
        try:
            for i in range(500):
                store.append("hot-user", float(k * 1000 + i), 1.0, 0)
                store.recent("hot-user", 0.0, 1e9)
        except Exception as e:      # without the lock: "deque mutated during iteration"
            errors.append(e)
    threads = [threading.Thread(target=work, args=(k,)) for k in range(8)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()
    assert not errors and len(store.recent("hot-user", 0.0, 1e9)) == 4000
