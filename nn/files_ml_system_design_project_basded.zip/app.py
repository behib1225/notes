"""Real-time fraud scoring service.
Run locally:  API_KEY=dev-key uvicorn app:app --port 8000      (add REDIS_URL=redis://localhost:6379/0
for the shared store). Without REDIS_URL it uses a process-local store (fine for one replica)."""
import json
import os
import secrets
import threading
import time
from contextlib import asynccontextmanager
from datetime import datetime

import lightgbm as lgb
import numpy as np
import pandas as pd
from fastapi import Depends, FastAPI, Header, HTTPException, Response
from prometheus_client import CONTENT_TYPE_LATEST, Counter, Gauge, Histogram, generate_latest
from pydantic import BaseModel, Field

from features import day_index, online_features
from rules import request_only_flag
from store import StoreUnavailable, make_store

ARTIFACTS = os.getenv("ARTIFACTS_DIR", "artifacts")
PRED_LOG = os.getenv("PRED_LOG", "predictions.jsonl")
DECISIONS = Counter("fraud_decisions_total", "Decisions returned", ["decision", "source"])
LATENCY = Histogram("fraud_score_latency_seconds", "Time spent in /v1/score",
                    buckets=(0.001, 0.0025, 0.005, 0.01, 0.025, 0.05, 0.1, 0.25, 1.0))
SNAPSHOT_AGE = Gauge("fraud_merchant_snapshot_age_days", "Age of the merchant snapshot used by the last request")
state = {}
_log_lock = threading.Lock()


@asynccontextmanager
async def lifespan(app: FastAPI):
    meta = json.loads(open(f"{ARTIFACTS}/meta.json").read())
    state["meta"], state["booster"] = meta, lgb.Booster(model_file=f"{ARTIFACTS}/model.txt")
    store = make_store(os.getenv("REDIS_URL"))
    snap = json.loads(open(f"{ARTIFACTS}/merchant_snapshot.json").read())
    if store.get_rate(0, snap["day"], -1.0)[1] is None:      # seed the store if no snapshot exists yet
        store.put_snapshot(snap["day"], snap["rates"])
    state["store"] = store
    yield


app = FastAPI(title="Fraud scoring", lifespan=lifespan)


def require_api_key(x_api_key: str | None = Header(default=None)):
    expected = os.getenv("API_KEY")
    if not expected:
        if os.getenv("ALLOW_NO_AUTH") == "1":               # local experiments only
            return
        raise HTTPException(503, "server misconfigured: set API_KEY")
    if x_api_key is None or not secrets.compare_digest(x_api_key, expected):
        raise HTTPException(401, "invalid or missing X-API-Key header")


class Transaction(BaseModel):
    txn_id: str = Field(min_length=1, max_length=64)
    user_id: int
    ts: datetime
    amount: float = Field(gt=0, lt=1_000_000)
    merchant_id: int = Field(ge=0)
    merchant_category: str = Field(max_length=32)
    country: str = Field(min_length=2, max_length=2)
    user_home_country: str = Field(min_length=2, max_length=2)   # enriched by the gateway from the profile


class Decision(BaseModel):
    txn_id: str
    decision: str                 # approve | challenge | decline
    score: float | None           # None when the rules fallback decided
    reasons: list[str]
    source: str                   # model | rules_fallback
    model_version: str
    latency_ms: float


@app.get("/healthz")
def healthz():
    return {"status": "ok", "model_loaded": "booster" in state}


@app.get("/metrics")
def metrics():
    """Prometheus scrape endpoint. Expose it only on the internal network in production."""
    return Response(generate_latest(), media_type=CONTENT_TYPE_LATEST)


@app.post("/v1/score", response_model=Decision, dependencies=[Depends(require_api_key)])
def score(txn: Transaction):
    # Plain `def`: FastAPI runs it in a thread pool, so shared state must be thread-safe (see store.py).
    t0 = time.perf_counter()
    meta, booster, store = state["meta"], state["booster"], state["store"]
    ts = pd.Timestamp(txn.ts)
    ts = ts.tz_convert("UTC").tz_localize(None) if ts.tzinfo else ts
    try:
        feats, snap_day = online_features(store, txn.user_id, ts, txn.amount, txn.country,
                                          txn.user_home_country, txn.merchant_category, txn.merchant_id)
        x = np.array([[feats[f] for f in meta["features"]]])
        p = float(booster.predict(x)[0])
        th = meta["thresholds"]
        decision = "decline" if p >= th["decline"] else "challenge" if p >= th["challenge"] else "approve"
        contrib = booster.predict(x, pred_contrib=True)[0][:-1]           # per-feature SHAP values (log-odds)
        reasons = [meta["features"][i] for i in np.argsort(-contrib)[:3] if contrib[i] > 0]
        source = "model"
        if snap_day is not None:
            SNAPSHOT_AGE.set(day_index(ts) - snap_day)
        store.append(txn.user_id, ts.value / 1e9, txn.amount, txn.merchant_id, txn.txn_id)
    except StoreUnavailable:
        feats, p, source = None, None, "rules_fallback"
        decision = "challenge" if request_only_flag(txn.amount, txn.country, txn.user_home_country) else "approve"
        reasons = ["feature_store_unavailable"]
    latency = time.perf_counter() - t0
    LATENCY.observe(latency)
    DECISIONS.labels(decision=decision, source=source).inc()
    # Prediction log: monitoring input and future training data. No user_id: keep personal data out of
    # logs you do not need it in, and set a retention period.
    record = {"txn_id": txn.txn_id, "ts": ts.isoformat(), "score": p, "decision": decision, "source": source,
              "model_version": meta["version"], "features": feats, "latency_ms": round(latency * 1000, 3)}
    with _log_lock:
        with open(PRED_LOG, "a") as f:
            f.write(json.dumps(record) + "\n")
    return Decision(txn_id=txn.txn_id, decision=decision, score=None if p is None else round(p, 6),
                    reasons=reasons, source=source, model_version=meta["version"],
                    latency_ms=round(latency * 1000, 2))
