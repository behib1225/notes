"""Search: hybrid retrieval (BM25 + semantic vectors) and learning-to-rank features.
Shared by training and serving."""
import difflib
import re

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.decomposition import TruncatedSVD
from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer

LTR_FEATURES = ["bm25", "semantic", "char_sim", "title_overlap", "brand_match", "color_match",
                "in_bm25", "in_semantic", "log_sales", "rating", "log_price", "log_price_vs_type", "query_len"]


def tokenize(text: str):
    return re.findall(r"[a-z0-9]+", text.lower())


class BM25:
    """Okapi BM25 over a sparse term matrix (what Elasticsearch/OpenSearch/Lucene compute by default)."""
    def __init__(self, docs, k1=1.2, b=0.75):
        self.vec = CountVectorizer(tokenizer=tokenize, token_pattern=None, lowercase=False)
        tf = self.vec.fit_transform(docs).tocsc().astype(np.float32)
        n, dl = tf.shape[0], np.asarray(tf.sum(1)).ravel()
        df = np.diff(tf.indptr)
        self.idf = np.log(1 + (n - df + 0.5) / (df + 0.5)).astype(np.float32)
        tf = tf.tocoo()
        denom = tf.data + k1 * (1 - b + b * dl[tf.row] / dl.mean())
        w = tf.data * (k1 + 1) / denom * self.idf[tf.col]
        self.w = csr_matrix((w, (tf.row, tf.col)), shape=tf.shape).tocsc()

    def scores(self, query: str) -> np.ndarray:
        # TODO(student): BM25 score of every document = sum of the precomputed weights of the query's terms.
        # >>> SOLUTION
        ids = [self.vec.vocabulary_[t] for t in tokenize(query) if t in self.vec.vocabulary_]
        if not ids:
            return np.zeros(self.w.shape[0], np.float32)
        return np.asarray(self.w[:, ids].sum(1)).ravel()
        # <<< SOLUTION


def rrf(rank_lists, k=60):
    """Reciprocal rank fusion: a strong, parameter-light way to merge ranked lists."""
    scores = {}
    # TODO(student): add 1 / (k + rank) for every list an item appears in (rank starts at 1), sort descending.
    # >>> SOLUTION
    for lst in rank_lists:
        for r, d in enumerate(lst):
            scores[d] = scores.get(d, 0.0) + 1.0 / (k + r + 1)
    # <<< SOLUTION
    return sorted(scores, key=lambda d: -scores[d])


class SearchIndex:
    def __init__(self, products: pd.DataFrame, dim=24):
        self.p = products.reset_index(drop=True)
        text = (self.p.title + " " + self.p.description).tolist()
        self.bm25 = BM25(text)                                       # lexical: exact words
        # Semantic: LSA = TF-IDF + SVD. Words that co-occur ("sneakers" with "running shoes")
        # end up close, so synonyms match; exact attributes (brand, colour) get blurred.
        self.tfidf = TfidfVectorizer(tokenizer=tokenize, token_pattern=None, lowercase=False, sublinear_tf=True)
        x = self.tfidf.fit_transform(text)
        self.svd = TruncatedSVD(n_components=dim, random_state=0).fit(x)
        self.doc_vecs = self._norm(self.svd.transform(x))
        # Character 3-grams of titles: robust to typos ("snekers" shares most 3-grams with "sneakers").
        self.chars = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 3))
        self.title_chars = self.chars.fit_transform(self.p.title.tolist())
        self.vocab = sorted(self.bm25.vec.vocabulary_)
        self.log_price_vs_type = np.log(self.p.price / self.p.groupby("ptype").price.transform("median")).to_numpy()

    def correct(self, q: str) -> str:
        """Query understanding: replace each unknown word by its closest catalog word (spelling fix)."""
        known = self.bm25.vec.vocabulary_
        return " ".join(w if w in known else (difflib.get_close_matches(w, self.vocab, n=1, cutoff=0.75) or [w])[0]
                        for w in tokenize(q))

    @staticmethod
    def _norm(v):
        return v / np.maximum(np.linalg.norm(v, axis=1, keepdims=True), 1e-9)

    def bm25_top(self, q, k):
        return np.argsort(-self.bm25.scores(q), kind="stable")[:k]

    def semantic_scores(self, q):
        return self.doc_vecs @ self._norm(self.svd.transform(self.tfidf.transform([q])))[0]

    def hybrid_top(self, q, k, k_each=50):
        """The production ranker BEFORE learning to rank: reciprocal rank fusion of both lists."""
        bm = list(self.bm25_top(q, k_each))
        sem = list(np.argsort(-self.semantic_scores(q), kind="stable")[:k_each])
        return np.array(rrf([bm, sem])[:k])

    def candidates(self, q, k_each=50):
        """Hybrid retrieval: union of lexical and semantic top-k, with LTR features."""
        bm, sem = self.bm25.scores(q), self.semantic_scores(q)
        top_bm = np.argsort(-bm, kind="stable")[:k_each]
        top_sem = np.argsort(-sem, kind="stable")[:k_each]
        ids = np.union1d(top_bm, top_sem)
        qt = set(tokenize(q))
        p = self.p.iloc[ids]
        return pd.DataFrame({
            "product_id": p.product_id.to_numpy(),
            "bm25": bm[ids], "semantic": sem[ids],
            "char_sim": (self.title_chars[ids] @ self.chars.transform([q]).T).toarray().ravel(),
            "title_overlap": [len(qt & set(tokenize(t))) / max(len(qt), 1) for t in p.title],
            "brand_match": p.brand.isin(qt).astype(int).to_numpy(),
            "color_match": p.color.isin(qt).astype(int).to_numpy(),
            "in_bm25": np.isin(ids, top_bm).astype(int), "in_semantic": np.isin(ids, top_sem).astype(int),
            "log_sales": np.log1p(p.sales_30d.to_numpy()), "rating": p.rating.to_numpy(),
            "log_price": np.log(p.price.to_numpy()), "log_price_vs_type": self.log_price_vs_type[ids],
            "query_len": len(qt),
        })
