"""Population Stability Index: how far has a feature's distribution moved since training?
Rule of thumb: < 0.1 stable, 0.1-0.25 investigate, > 0.25 act. Always look at the distributions
before acting: PSI is inflated when current data falls into few bins (each empty bin adds ~0.69)."""
import numpy as np


def psi(reference, current, bins=10, eps=1e-4):
    reference, current = np.asarray(reference, float), np.asarray(current, float)
    if len(np.unique(reference)) <= 20:                       # low-cardinality: compare value frequencies
        values = np.union1d(np.unique(reference), np.unique(current))
        r = np.array([(reference == v).mean() for v in values])
        c = np.array([(current == v).mean() for v in values])
    else:                                                     # continuous: quantile bins of the reference
        edges = np.unique(np.quantile(reference, np.linspace(0, 1, bins + 1)))
        edges[0], edges[-1] = -np.inf, np.inf
        r = np.histogram(reference, edges)[0] / len(reference)
        c = np.histogram(current, edges)[0] / len(current)
    # TODO(student): clip both distributions at eps and return sum((c - r) * ln(c / r)).
    # >>> SOLUTION
    r, c = np.clip(r, eps, None), np.clip(c, eps, None)
    return float(np.sum((c - r) * np.log(c / r)))
    # <<< SOLUTION
