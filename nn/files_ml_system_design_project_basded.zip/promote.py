"""Champion/challenger promotion. Both models are scored on the SAME recent window, using only the
labels known today (the challenger's validation window), so the comparison is fair and uses no
future data. A promoted model should still run in shadow mode before it takes real decisions."""
import json
import shutil

import lightgbm as lgb
import mlflow
import pandas as pd
from mlflow import MlflowClient

from features import build_offline_features, merchant_rate_table
from train import T, day, policy_cost

NAME = "fraud-detector"
mlflow.set_tracking_uri("sqlite:///mlflow.db")
client = MlflowClient()


def load(version):
    run_id = client.get_model_version(NAME, version).run_id
    path = mlflow.artifacts.download_artifacts(run_id=run_id, artifact_path="bundle")
    return path, lgb.Booster(model_file=f"{path}/model.txt"), json.load(open(f"{path}/meta.json"))


challenger = max(client.search_model_versions(f"name='{NAME}'"), key=lambda v: int(v.version))
ch_path, ch_model, ch_meta = load(challenger.version)
try:
    champion = client.get_model_version_by_alias(NAME, "champion")
except mlflow.exceptions.MlflowException:
    champion = None

if champion is None:
    promote = True
    print(f"no champion yet: v{challenger.version} becomes champion")
else:
    _, cp_model, cp_meta = load(champion.version)
    raw = pd.read_parquet("data/transactions.parquet")
    feats = build_offline_features(raw, rate_table=merchant_rate_table(raw, int(raw.merchant_id.max()) + 1))
    win = feats[(feats.ts >= day(45)) & (feats.ts < day(53))]
    y = ((win.is_fraud == 1) & (win.label_ts <= day(T))).astype(int)

    def cost(model, meta):
        p = model.predict(win[meta["features"]].to_numpy())
        return policy_cost(y, win.amount, p, meta["thresholds"]["challenge"], meta["thresholds"]["decline"])
    c_new, c_old = cost(ch_model, ch_meta), cost(cp_model, cp_meta)
    promote = c_new <= 0.98 * c_old                     # demand a real improvement, not noise
    print(f"same window: champion v{champion.version} ${c_old:,.0f} vs challenger v{challenger.version} ${c_new:,.0f}")

if promote:
    client.set_registered_model_alias(NAME, "champion", challenger.version)
    for f in ["model.txt", "meta.json", "merchant_snapshot.json"]:
        shutil.copy(f"{ch_path}/{f}", f"artifacts/{f}")
    print(f"promoted v{challenger.version}; bundle exported to artifacts/ (commit it to deploy)")
else:
    print("challenger rejected; champion unchanged")
