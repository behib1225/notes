"""Send N March payments to a running service and report latency percentiles.
Usage: API_KEY=dev-key python load_test.py http://localhost:8000 500"""
import os
import sys
import time

import httpx
import numpy as np
import pandas as pd

url, n = sys.argv[1].rstrip("/"), int(sys.argv[2]) if len(sys.argv) > 2 else 300
headers = {"X-API-Key": os.environ["API_KEY"]}
df = pd.read_parquet("data/transactions.parquet").query("ts >= '2026-03-02'").head(n)
lat, decisions = [], {}
with httpx.Client(timeout=90, headers=headers) as c:
    c.get(f"{url}/healthz")                     # wake the service (cold start) before timing
    for r in df.itertuples():
        body = {"txn_id": str(r.txn_id), "user_id": int(r.user_id), "ts": r.ts.isoformat(),
                "amount": float(r.amount), "merchant_id": int(r.merchant_id), "merchant_category": r.category,
                "country": r.country, "user_home_country": r.home_country}
        t = time.perf_counter()
        d = c.post(f"{url}/v1/score", json=body).json()
        lat.append((time.perf_counter() - t) * 1000)
        decisions[d["decision"]] = decisions.get(d["decision"], 0) + 1
p50, p95, p99 = np.percentile(lat, [50, 95, 99])
print(f"{n} requests  p50={p50:.1f} ms  p95={p95:.1f} ms  p99={p99:.1f} ms  decisions={decisions}")
