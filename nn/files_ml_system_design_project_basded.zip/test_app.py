import pytest
from fastapi.testclient import TestClient

import app as service
from store import StoreUnavailable

KEY = {"X-API-Key": "test-key"}
TXN = {"txn_id": "t1", "user_id": 42, "ts": "2026-03-05T12:00:00", "amount": 25.0, "merchant_id": 3,
       "merchant_category": "grocery", "country": "CA", "user_home_country": "CA"}


@pytest.fixture
def client(monkeypatch, tmp_path):
    monkeypatch.setenv("API_KEY", "test-key")
    monkeypatch.delenv("REDIS_URL", raising=False)
    monkeypatch.setattr(service, "PRED_LOG", str(tmp_path / "log.jsonl"))
    with TestClient(service.app) as c:
        yield c


def test_auth_is_required(client):
    assert client.post("/v1/score", json=TXN).status_code == 401
    assert client.post("/v1/score", json=TXN, headers={"X-API-Key": "wrong"}).status_code == 401


def test_score_returns_decision_and_reasons(client):
    body = client.post("/v1/score", json=TXN, headers=KEY).json()
    assert body["source"] == "model" and 0.0 <= body["score"] <= 1.0
    assert body["decision"] in {"approve", "challenge", "decline"}
    assert isinstance(body["reasons"], list)


def test_card_testing_burst_raises_score(client):
    base = client.post("/v1/score", json={**TXN, "txn_id": "a", "user_id": 777}, headers=KEY).json()["score"]
    for i in range(6):
        last = client.post("/v1/score", headers=KEY, json={
            **TXN, "txn_id": f"b{i}", "user_id": 777, "ts": f"2026-03-05T12:0{i + 1}:00",
            "amount": 3.0 if i < 3 else 400.0, "merchant_id": 50 + i, "merchant_category": "electronics",
            "country": "NG"}).json()
    assert last["score"] > base and last["decision"] != "approve"


def test_falls_back_to_rules_when_store_is_down(client, monkeypatch):
    def broken(*args, **kwargs):
        raise StoreUnavailable("redis timeout")
    monkeypatch.setattr(service.state["store"], "recent", broken)
    body = client.post("/v1/score", json={**TXN, "amount": 500.0, "country": "FR"}, headers=KEY).json()
    assert body["source"] == "rules_fallback" and body["decision"] == "challenge"


def test_metrics_and_validation(client):
    client.post("/v1/score", json=TXN, headers=KEY)
    text = client.get("/metrics").text
    assert "fraud_decisions_total" in text and "fraud_score_latency_seconds_bucket" in text
    assert client.post("/v1/score", json={**TXN, "amount": -5}, headers=KEY).status_code == 422
