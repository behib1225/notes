"""The nightly batch job: compute the merchant snapshot for day(s) d and write it to the online store.
Usage: python refresh_snapshot.py --redis-url redis://localhost:6379/0 --first-day 60 --last-day 89"""
import argparse

import pandas as pd

from features import merchant_rate_table
from store import RedisStore


def snapshots(first_day, last_day, path="data/transactions.parquet"):
    raw = pd.read_parquet(path)
    table = merchant_rate_table(raw, int(raw.merchant_id.max()) + 1)
    for d in range(first_day, last_day + 1):
        yield d, {m: float(table[m, d]) for m in range(table.shape[0])}


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--redis-url", required=True)
    ap.add_argument("--first-day", type=int, required=True)
    ap.add_argument("--last-day", type=int, required=True)
    a = ap.parse_args()
    store = RedisStore(a.redis_url, timeout=2.0)
    for d, rates in snapshots(a.first_day, a.last_day):
        store.put_snapshot(d, rates)
    print(f"wrote snapshots for days {a.first_day}-{a.last_day}")
