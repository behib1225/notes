"""Uncertainty for offline evaluation: bootstrap confidence intervals.

A metric computed once on one test set is an estimate. Before claiming "model B beats model A",
check that the interval of the difference excludes zero."""
import numpy as np


def bootstrap_ci(stat, arrays, groups=None, n_boot=300, alpha=0.05, seed=0):
    """Point estimate and (1 - alpha) percentile interval of stat(*arrays).

    groups: resample whole groups (for example users) instead of rows. Rows from the same user
    are correlated (a fraud burst is several rows), so row-level resampling gives intervals
    that are too narrow."""
    arrays = [np.asarray(a) for a in arrays]
    point = float(stat(*arrays))
    rng = np.random.default_rng(seed)
    n = len(arrays[0])
    index_sets = None
    if groups is not None:
        groups = np.asarray(groups)
        order = np.argsort(groups, kind="stable")
        _, starts = np.unique(groups[order], return_index=True)
        index_sets = np.split(order, starts[1:])
    stats = []
    for _ in range(n_boot):
        # TODO(student): draw a bootstrap sample (rows, or whole groups when index_sets is set),
        # evaluate stat on it and append the result to `stats`.
        # >>> SOLUTION
        if index_sets is None:
            idx = rng.integers(0, n, n)
        else:
            picks = rng.integers(0, len(index_sets), len(index_sets))
            idx = np.concatenate([index_sets[i] for i in picks])
        stats.append(stat(*[a[idx] for a in arrays]))
        # <<< SOLUTION
    lo, hi = np.quantile(stats, [alpha / 2, 1 - alpha / 2])
    return point, float(lo), float(hi)


def paired_bootstrap_diff(a, b, n_boot=2000, alpha=0.05, seed=0):
    """Mean of (a - b) with a percentile interval, for per-unit metrics measured on the SAME
    units (the same users or queries). Pairing removes the unit-to-unit variance."""
    d = np.asarray(a, float) - np.asarray(b, float)
    rng = np.random.default_rng(seed)
    means = [d[rng.integers(0, len(d), len(d))].mean() for _ in range(n_boot)]
    lo, hi = np.quantile(means, [alpha / 2, 1 - alpha / 2])
    return float(d.mean()), float(lo), float(hi)
