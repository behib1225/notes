"""A/B testing toolkit: sample size, sample-ratio-mismatch check, and the two-proportion z-test."""
import numpy as np
from scipy import stats


def sample_size_per_arm(p_base, rel_lift, alpha=0.05, power=0.8):
    p_new = p_base * (1 + rel_lift)
    z_a, z_b = stats.norm.ppf(1 - alpha / 2), stats.norm.ppf(power)
    var = p_base * (1 - p_base) + p_new * (1 - p_new)
    return int(np.ceil((z_a + z_b) ** 2 * var / (p_new - p_base) ** 2))


def srm_pvalue(n_control, n_treatment, expected_share=0.5):
    """Sample ratio mismatch: did the split itself go wrong? p < 0.001 -> do not trust the test."""
    total = n_control + n_treatment
    return stats.chisquare([n_control, n_treatment], [total * (1 - expected_share), total * expected_share]).pvalue


def two_proportion_test(x_c, n_c, x_t, n_t, alpha=0.05):
    p_c, p_t = x_c / n_c, x_t / n_t
    p_pool = (x_c + x_t) / (n_c + n_t)
    se_pool = np.sqrt(p_pool * (1 - p_pool) * (1 / n_c + 1 / n_t))
    z = (p_t - p_c) / se_pool
    se = np.sqrt(p_c * (1 - p_c) / n_c + p_t * (1 - p_t) / n_t)
    half = stats.norm.ppf(1 - alpha / 2) * se
    return {"control": round(p_c, 5), "treatment": round(p_t, 5), "abs_lift": round(p_t - p_c, 5),
            "rel_lift": round((p_t - p_c) / p_c, 4), "ci95_abs": (round(float(p_t - p_c - half), 5), round(float(p_t - p_c + half), 5)),
            "p_value": round(float(2 * (1 - stats.norm.cdf(abs(z)))), 5)}


if __name__ == "__main__":
    n = sample_size_per_arm(0.05, 0.02)
    print(f"baseline CTR 5%, detect +2% relative: {n:,} users per arm")
    print(f"baseline CTR 5%, detect +5% relative: {sample_size_per_arm(0.05, 0.05):,} users per arm")
    rng = np.random.default_rng(1)
    n_c, n_t = 200_000, 200_000
    x_c, x_t = rng.binomial(n_c, 0.050), rng.binomial(n_t, 0.0525)       # true lift +5%
    print("SRM p-value:", round(srm_pvalue(n_c, n_t), 3))
    print(two_proportion_test(x_c, n_c, x_t, n_t))
