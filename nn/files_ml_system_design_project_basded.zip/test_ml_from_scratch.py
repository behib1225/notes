import numpy as np
from sklearn.cluster import KMeans
from sklearn.datasets import load_breast_cancer, make_blobs
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import average_precision_score, ndcg_score, roc_auc_score
from sklearn.preprocessing import StandardScaler

from ml_from_scratch import average_precision, kmeans, logistic_regression, ndcg_at_k, roc_auc

rng = np.random.default_rng(0)
y = rng.integers(0, 2, 500)
s = np.round(y * 0.5 + rng.random(500), 1)          # rounded on purpose: creates ties


def test_roc_auc_and_average_precision_match_sklearn():
    assert np.isclose(roc_auc(y, s), roc_auc_score(y, s))
    assert np.isclose(average_precision(y, s), average_precision_score(y, s))


def test_ndcg_matches_sklearn():
    rel, sc = rng.integers(0, 4, 30), rng.random(30)
    assert np.isclose(ndcg_at_k(rel, sc, 10), ndcg_score([rel], [sc], k=10))


def test_kmeans_close_to_sklearn():
    X, _ = make_blobs(600, centers=4, random_state=0)
    _, _, inertia = kmeans(X, 4)
    assert inertia <= 1.05 * KMeans(4, n_init=10, random_state=0).fit(X).inertia_


def test_logistic_regression_close_to_sklearn():
    X, y2 = load_breast_cancer(return_X_y=True)
    X = StandardScaler().fit_transform(X)
    w, b = logistic_regression(X, y2)
    acc = ((X @ w + b > 0) == y2).mean()
    assert acc >= 0.95 and abs(acc - LogisticRegression(max_iter=1000).fit(X, y2).score(X, y2)) <= 0.03
