from rerank import genre_cap


def test_genre_cap_keeps_order_and_limits_each_genre():
    genres = {i: ("a" if i < 6 else "b" if i < 9 else "c") for i in range(12)}
    out = genre_cap(list(range(12)), genres, k=6, max_per_genre=3)
    assert out == [0, 1, 2, 6, 7, 8]
