"""Diversity re-ranking (Week 3, Exercise 3.3)."""


def genre_cap(ranked_items, genres, k=10, max_per_genre=3):
    """Greedy re-ranking: walk down the ranked list, skip an item if its genre is already full."""
    out, count = [], {}
    # TODO(student): keep at most max_per_genre items per genre, in ranked order, until k items are chosen.
    # >>> SOLUTION
    for i in ranked_items:
        g = genres[i]
        if count.get(g, 0) < max_per_genre:
            out.append(i)
            count[g] = count.get(g, 0) + 1
            if len(out) == k:
                break
    # <<< SOLUTION
    return out
