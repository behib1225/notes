"""Train the fraud model on what is known on training day, then evaluate it honestly.

Timeline (day 0 = 2026-01-01; training day T = day 60 = 2026-03-02):
  train       days  0-44  labels as known on day T
  validation  days 45-52  labels as known on day T -> early stopping, thresholds, QUALITY GATE
  gap         days 53-59  dropped: labels least mature
  backtest    days 60-89  final labels -> for teaching ONLY. On day T this is the future, so it is
                          never used to choose, gate or promote a model (that would be test-set reuse).
Run: python train.py            (add --leaky for Exercise 1.4)
"""
import argparse
import json
from pathlib import Path

import lightgbm as lgb
import numpy as np
import pandas as pd
import sklearn
from sklearn.metrics import average_precision_score

from features import DAY0, FEATURES, build_offline_features, merchant_rate_table
from mlsd_common.stats import bootstrap_ci
from rules import rules_flag

T = 60
LEAKY_FEATURES = FEATURES + ["user_fraud_reports"]
# Business assumptions. They decide the thresholds, so replace them with your company's numbers.
COST = {"decline_legit": 25.0,          # lost margin on a good sale + chance the customer leaves
        "challenge_legit": 2.0,         # friction and some abandoned checkouts
        "challenge_fraud_pass": 0.15}   # share of challenged fraudsters who pass step-up authentication


def day(n):
    return DAY0 + pd.Timedelta(days=n)


def policy_cost(y, amount, p, t_challenge, t_decline):
    """Expected $ cost of: approve if p < t_challenge, decline if p >= t_decline, else challenge."""
    # TODO(student): implement the cost of each of the six (outcome x action) cells using COST.
    # >>> SOLUTION
    y, amount, p = np.asarray(y), np.asarray(amount), np.asarray(p)
    decline = p >= t_decline
    challenge = (p >= t_challenge) & ~decline
    approve = ~(decline | challenge)
    fraud = y == 1
    return float((amount * (fraud & approve)).sum()
                 + (COST["challenge_fraud_pass"] * amount * (fraud & challenge)).sum()
                 + COST["challenge_legit"] * (~fraud & challenge).sum()
                 + COST["decline_legit"] * (~fraud & decline).sum())
    # <<< SOLUTION


def pick_thresholds(y, amount, p):
    """Grid search over (challenge, decline) thresholds; decline may be disabled (inf)."""
    grid = np.unique(np.quantile(p, 1 - np.geomspace(0.05, 0.00005, 50)))
    best = (np.inf, None, None)
    for i, tc in enumerate(grid):
        for td in list(grid[i:]) + [np.inf]:
            c = policy_cost(y, amount, p, tc, td)
            if c < best[0]:
                best = (c, float(tc), float(td))
    return best[1], best[2]


def evaluate(y, amount, p, users, tc, td, ci=False):
    y, amount, p = np.asarray(y), np.asarray(amount), np.asarray(p, float)
    flagged = p >= tc
    m = {"n": int(len(y)), "frauds": int(y.sum()),
         "pr_auc": round(float(average_precision_score(y, p)), 4) if len(np.unique(p)) > 2 else None,
         "recall": round(float(flagged[y == 1].mean()), 4),
         "precision": round(float(y[flagged].mean()), 4) if flagged.any() else 0.0,
         "challenge_rate": round(float((flagged & (p < td)).mean()), 5),
         "decline_rate": round(float((p >= td).mean()), 5),
         "cost_per_1k": round(policy_cost(y, amount, p, tc, td) / len(y) * 1000, 2)}
    if ci:
        if m["pr_auc"] is not None:
            m["pr_auc_ci95"] = [round(v, 4) for v in bootstrap_ci(average_precision_score, (y, p), groups=users)[1:]]
        cost = lambda yy, aa, pp: policy_cost(yy, aa, pp, tc, td) / len(yy) * 1000   # noqa: E731
        m["cost_per_1k_ci95"] = [round(v, 2) for v in bootstrap_ci(cost, (y, amount, p), groups=users)[1:]]
    return m


def main(leaky=False, out="artifacts"):
    cols = LEAKY_FEATURES if leaky else FEATURES
    raw = pd.read_parquet("data/transactions.parquet")
    table = merchant_rate_table(raw, int(raw.merchant_id.max()) + 1)
    feats = build_offline_features(raw, rate_table=table, leaky=leaky)
    feats["y_known"] = ((feats.is_fraud == 1) & (feats.label_ts <= day(T))).astype(int)
    tr = feats[feats.ts < day(45)]
    va = feats[(feats.ts >= day(45)) & (feats.ts < day(53))]
    bt = feats[feats.ts >= day(T)]
    print(f"train {len(tr):,} rows ({tr.y_known.sum()} known frauds) | validation {len(va):,} "
          f"({va.y_known.sum()} of {va.is_fraud.sum()} frauds reported by day {T}) | backtest {len(bt):,}")

    model = lgb.LGBMClassifier(n_estimators=2000, learning_rate=0.03, num_leaves=31, min_child_samples=50,
                               subsample=0.8, subsample_freq=1, colsample_bytree=0.8, random_state=0, verbose=-1)
    model.fit(tr[cols], tr.y_known, eval_set=[(va[cols], va.y_known)], eval_metric="average_precision",
              callbacks=[lgb.early_stopping(100, verbose=False)])
    p_va = model.predict_proba(va[cols])[:, 1]
    tc, td = pick_thresholds(va.y_known, va.amount, p_va)

    rules_va = rules_flag(va).to_numpy().astype(float)
    report = {
        "thresholds": {"challenge": tc, "decline": td},
        "validation": evaluate(va.y_known, va.amount, p_va, va.user_id, tc, td, ci=True),
        "validation_rules": evaluate(va.y_known, va.amount, rules_va, va.user_id, 0.5, np.inf),
        "validation_no_model_cost_per_1k": round(policy_cost(va.y_known, va.amount, np.zeros(len(va)), 1, 1) / len(va) * 1000, 2),
    }
    p_bt = model.predict_proba(bt[cols])[:, 1]
    report["backtest"] = evaluate(bt.is_fraud, bt.amount, p_bt, bt.user_id, tc, td, ci=True)
    report["backtest_rules"] = evaluate(bt.is_fraud, bt.amount, rules_flag(bt).to_numpy().astype(float),
                                        bt.user_id, 0.5, np.inf)
    report["backtest_no_model_cost_per_1k"] = round(policy_cost(bt.is_fraud, bt.amount, np.zeros(len(bt)), 1, 1) / len(bt) * 1000, 2)
    if leaky:      # what production would see: the leaky feature can only be computed point-in-time
        honest = build_offline_features(raw, rate_table=table, leaky=False)
        p_prod = model.predict_proba(honest[honest.ts >= day(T)][cols])[:, 1]
        report["backtest_pr_auc_with_production_features"] = round(float(average_precision_score(bt.is_fraud, p_prod)), 4)
    print(json.dumps(report, indent=2))

    Path(out).mkdir(exist_ok=True)
    model.booster_.save_model(f"{out}/model.txt", num_iteration=model.best_iteration_)   # text format, no pickle
    meta = {"version": "fraud-lgbm-v2", "train_day": T, "features": cols, "cost_assumptions": COST,
            "best_iteration": int(model.best_iteration_), **report,
            "libraries": {"lightgbm": lgb.__version__, "numpy": np.__version__, "pandas": pd.__version__,
                          "scikit-learn": sklearn.__version__}}
    Path(f"{out}/meta.json").write_text(json.dumps(meta, indent=2))
    Path(f"{out}/merchant_snapshot.json").write_text(json.dumps(
        {"day": T, "rates": {str(m): float(table[m, T]) for m in range(table.shape[0])}}))
    return report


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--leaky", action="store_true")
    a = ap.parse_args()
    main(leaky=a.leaky, out="artifacts_leaky" if a.leaky else "artifacts")
