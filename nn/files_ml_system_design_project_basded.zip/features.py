"""Fraud features: ONE set of definitions for training (offline, pandas) and serving (online).
tests/test_parity.py proves both paths give identical values, including the daily batch feature.
"""
import numpy as np
import pandas as pd

DAY0 = pd.Timestamp("2026-01-01")
N_SNAPSHOT_DAYS = 120
CATEGORIES = ["grocery", "restaurant", "fuel", "electronics", "travel", "digital_goods", "fashion"]
FEATURES = [
    "amount", "log_amount", "hour", "is_foreign", "category_code",
    "user_cnt_1h", "user_cnt_24h", "user_sum_1h", "secs_since_last",
    "user_avg_amt_30d", "amt_to_avg_ratio", "new_merchant_30d", "merchant_fraud_rate",
]
WINDOW_SECS = 30 * 86_400.0
NO_HISTORY_SECS = WINDOW_SECS          # "no payment in the last 30 days"
PRIOR_RATE, PRIOR_WEIGHT = 0.005, 50.0
MERCHANT_WINDOW_DAYS = 30   # trailing window keeps the feature stationary (an all-time rate drifts)


def category_code(cat):
    return CATEGORIES.index(cat) if cat in CATEGORIES else -1


def day_index(ts) -> int:
    return int((pd.Timestamp(ts) - DAY0) // pd.Timedelta("1D"))


def merchant_rate_table(df: pd.DataFrame, n_merchants: int, n_days: int = N_SNAPSHOT_DAYS,
                        window_days: int = MERCHANT_WINDOW_DAYS) -> np.ndarray:
    """rate[m, d] = smoothed chargeback rate of merchant m as a nightly batch job computes it at 00:00
    of day d: chargebacks RECEIVED in the 30 days before day d / payments MADE in those 30 days.
    Training uses rate[m, day(ts)] and serving reads the same nightly snapshot, so they agree."""
    seen = np.zeros((n_merchants, n_days + 1))
    fraud = np.zeros_like(seen)
    d_txn = ((df.ts - DAY0) // pd.Timedelta("1D")).to_numpy() + 1     # counts from the next midnight
    ok = d_txn <= n_days
    np.add.at(seen, (df.merchant_id.to_numpy()[ok], d_txn[ok]), 1)
    f = df[df.is_fraud == 1]
    d_lab = ((f.label_ts - DAY0) // pd.Timedelta("1D")).to_numpy() + 1
    ok = d_lab <= n_days
    np.add.at(fraud, (f.merchant_id.to_numpy()[ok], d_lab[ok]), 1)
    s_cum, f_cum = seen.cumsum(1), fraud.cumsum(1)
    s_lag, f_lag = np.zeros_like(s_cum), np.zeros_like(f_cum)
    s_lag[:, window_days:], f_lag[:, window_days:] = s_cum[:, :-window_days], f_cum[:, :-window_days]
    return (f_cum - f_lag + PRIOR_RATE * PRIOR_WEIGHT) / (s_cum - s_lag + PRIOR_WEIGHT)


def user_fraud_reports_leaky(df: pd.DataFrame) -> pd.Series:
    """WRONG on purpose (Exercise 1.4): all of the user's fraud, including this row and the future."""
    return df.groupby("user_id")["is_fraud"].transform("sum").astype(float)


def user_fraud_reports_pit(df: pd.DataFrame) -> pd.Series:
    """What production can know: chargebacks on this user received before ts."""
    q = pd.DataFrame({"user_id": df.user_id, "t": df.ts, "kind": 1, "f": 0, "idx": df.index})
    lab = pd.DataFrame({"user_id": df.user_id, "t": df.label_ts, "kind": 0, "f": df.is_fraud, "idx": -1})
    ev = pd.concat([lab, q]).sort_values(["user_id", "t", "kind"], kind="mergesort")
    ev["f_cum"] = ev.groupby("user_id")["f"].cumsum()
    return ev[ev.kind == 1].set_index("idx")["f_cum"].reindex(df.index).astype(float)


def build_offline_features(df: pd.DataFrame, rate_table=None, leaky: bool = False) -> pd.DataFrame:
    df = df.sort_values(["ts", "txn_id"]).reset_index(drop=True)
    if rate_table is None:
        rate_table = merchant_rate_table(df, int(df.merchant_id.max()) + 1)
    out = pd.DataFrame(index=df.index)
    out["amount"] = df.amount
    out["log_amount"] = np.log1p(df.amount)
    out["hour"] = df.ts.dt.hour + df.ts.dt.minute / 60
    out["is_foreign"] = (df.country != df.home_country).astype(int)
    out["category_code"] = df.category.map(category_code)

    # TODO(student): velocity features over windows [ts - w, ts) that EXCLUDE the current payment:
    # user_cnt_1h, user_cnt_24h (counts), user_sum_1h (sum), user_avg_amt_30d (mean, -1 if none).
    # >>> SOLUTION
    g = df.set_index("ts").groupby("user_id")["amount"]
    order = df.sort_values(["user_id", "ts"], kind="mergesort").index     # groupby-rolling row order
    for name, window, how in [("user_cnt_1h", "1h", "count"), ("user_cnt_24h", "24h", "count"),
                              ("user_sum_1h", "1h", "sum"), ("user_avg_amt_30d", "30D", "mean")]:
        r = getattr(g.rolling(window, closed="left"), how)()
        out.loc[order, name] = r.reset_index(level=0, drop=True).to_numpy()
    out[["user_cnt_1h", "user_cnt_24h", "user_sum_1h"]] = out[["user_cnt_1h", "user_cnt_24h", "user_sum_1h"]].fillna(0)
    out["user_avg_amt_30d"] = out["user_avg_amt_30d"].fillna(-1.0)
    # <<< SOLUTION
    prev_ts = df.groupby("user_id")["ts"].shift(1)
    out["secs_since_last"] = (df.ts - prev_ts).dt.total_seconds().fillna(NO_HISTORY_SECS).clip(upper=NO_HISTORY_SECS)
    out["amt_to_avg_ratio"] = np.where(out.user_avg_amt_30d > 0, df.amount / out.user_avg_amt_30d, -1.0)
    g2 = df.set_index("ts").groupby(["user_id", "merchant_id"])["amount"]
    prior = g2.rolling("30D", closed="left").count().reset_index(level=[0, 1], drop=True).to_numpy()
    order2 = df.sort_values(["user_id", "merchant_id", "ts"], kind="mergesort").index
    out.loc[order2, "new_merchant_30d"] = (np.nan_to_num(prior) == 0).astype(int)
    out["merchant_fraud_rate"] = rate_table[df.merchant_id.to_numpy(), (df.ts - DAY0).dt.days.to_numpy()]
    out["user_fraud_reports"] = user_fraud_reports_leaky(df) if leaky else user_fraud_reports_pit(df)
    for c in ["txn_id", "user_id", "ts", "is_fraud", "label_ts"]:
        out[c] = df[c]
    return out


def online_features(store, user_id, ts: pd.Timestamp, amount, country, home_country, category, merchant_id):
    """Features for ONE payment from the online store. Returns (features, snapshot_day)."""
    t = ts.value / 1e9
    past = store.recent(user_id, t - WINDOW_SECS, t)                    # oldest first, excludes t
    # TODO(student): compute the same velocity features as the offline code from `past`.
    # >>> SOLUTION
    in_1h = [a for s, a, _ in past if s >= t - 3600]
    in_24h = [a for s, a, _ in past if s >= t - 86_400]
    avg30 = float(np.mean([a for _, a, _ in past])) if past else -1.0
    # <<< SOLUTION
    rate, snap_day = store.get_rate(merchant_id, day_index(ts), PRIOR_RATE)
    feats = {
        "amount": float(amount), "log_amount": float(np.log1p(amount)),
        "hour": ts.hour + ts.minute / 60, "is_foreign": int(country != home_country),
        "category_code": category_code(category),
        "user_cnt_1h": float(len(in_1h)), "user_cnt_24h": float(len(in_24h)), "user_sum_1h": float(sum(in_1h)),
        "secs_since_last": min(t - past[-1][0], NO_HISTORY_SECS) if past else NO_HISTORY_SECS,
        "user_avg_amt_30d": avg30, "amt_to_avg_ratio": amount / avg30 if avg30 > 0 else -1.0,
        "new_merchant_30d": int(all(m != merchant_id for _, _, m in past)),
        "merchant_fraud_rate": rate,
    }
    return feats, snap_day
