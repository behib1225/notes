"""Online feature store backends with ONE interface. The service picks one from REDIS_URL.

InMemoryStore: one process only; a lock makes it safe under FastAPI's thread pool, but every
replica has its own copy and a restart empties it. RedisStore: shared by all replicas and
survives restarts; this is the production pattern (Redis, DynamoDB, Cassandra, or a feature
store such as Feast backed by one of them)."""
import threading
from collections import deque


class StoreUnavailable(Exception):
    """Raised when the backend cannot answer; the service then falls back to rules."""


class InMemoryStore:
    def __init__(self, window_secs: float = 30 * 86_400):
        self.window = window_secs
        self._lock = threading.Lock()
        self._hist: dict = {}
        self._snap: dict = {}

    def recent(self, user_id, since: float, until: float):
        """Events (t, amount, merchant_id) with since <= t < until, oldest first."""
        with self._lock:
            return sorted(e for e in self._hist.get(user_id, ()) if since <= e[0] < until)

    def append(self, user_id, t: float, amount: float, merchant_id: int, txn_id=None):
        with self._lock:
            h = self._hist.setdefault(user_id, deque())
            h.append((t, float(amount), int(merchant_id)))
            while h and h[0][0] < t - self.window:
                h.popleft()

    def put_snapshot(self, day: int, rates: dict):
        with self._lock:
            self._snap[int(day)] = {int(k): float(v) for k, v in rates.items()}

    def get_rate(self, merchant_id: int, day: int, default: float):
        """Value from the newest snapshot computed on or before `day`, and that snapshot's day."""
        with self._lock:
            days = [d for d in self._snap if d <= day]
            if not days:
                return default, None
            d = max(days)
            return self._snap[d].get(int(merchant_id), default), d


class RedisStore:
    """One sorted set per user (score = event time in epoch seconds), one hash per daily snapshot."""

    def __init__(self, url: str = "", window_secs: float = 30 * 86_400, timeout: float = 0.05, client=None):
        import redis
        self._errors = (redis.exceptions.RedisError, OSError)
        self.r = client or redis.Redis.from_url(url, decode_responses=True, socket_timeout=timeout,
                                                socket_connect_timeout=timeout)
        self.window = window_secs

    def _call(self, fn):
        try:
            return fn()
        except self._errors as e:
            raise StoreUnavailable(str(e)) from e

    def recent(self, user_id, since: float, until: float):
        rows = self._call(lambda: self.r.zrangebyscore(f"hist:{user_id}", since, f"({until!r}", withscores=True))
        out = []
        for member, score in rows:
            _, amount, merchant = member.split("|")
            out.append((float(score), float(amount), int(merchant)))
        return out

    def append(self, user_id, t: float, amount: float, merchant_id: int, txn_id=None):
        key = f"hist:{user_id}"

        def op():
            p = self.r.pipeline()
            p.zadd(key, {f"{txn_id}|{float(amount)!r}|{int(merchant_id)}": t})
            p.zremrangebyscore(key, "-inf", f"({t - self.window!r}")
            p.expire(key, int(self.window) + 86_400)      # inactive users disappear
            p.execute()
        self._call(op)

    def put_snapshot(self, day: int, rates: dict):
        def op():
            p = self.r.pipeline()
            p.delete(f"mrate:{day}")
            p.hset(f"mrate:{day}", mapping={str(k): repr(float(v)) for k, v in rates.items()})
            p.zadd("mrate:days", {str(day): day})
            p.execute()
        self._call(op)

    def get_rate(self, merchant_id: int, day: int, default: float):
        days = self._call(lambda: self.r.zrevrangebyscore("mrate:days", day, "-inf", start=0, num=1))
        if not days:
            return default, None
        v = self._call(lambda: self.r.hget(f"mrate:{days[0]}", str(merchant_id)))
        return (float(v) if v is not None else default), int(days[0])


def make_store(redis_url: str | None):
    return RedisStore(redis_url) if redis_url else InMemoryStore()
