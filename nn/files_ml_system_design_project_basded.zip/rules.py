"""Rules engine: the pre-ML baseline AND the fallback when the model or feature store fails."""


def rules_flag(f):
    """Challenge if 3+ payments in the last hour, or a foreign payment above $200.
    Works on a dict (one payment) or a DataFrame (vectorised)."""
    return (f["user_cnt_1h"] >= 3) | ((f["is_foreign"] == 1) & (f["amount"] > 200))


def request_only_flag(amount: float, country: str, home_country: str) -> bool:
    """When velocity features are unavailable, only the request itself is known."""
    return country != home_country and amount > 200
