import pandas as pd
import pandera.errors
import pytest

from schema import TRANSACTIONS


def test_real_data_passes_and_broken_rows_fail():
    df = pd.read_parquet("data/transactions.parquet").head(1000)
    TRANSACTIONS.validate(df)
    bad = df.copy()
    bad.loc[0, "amount"] = -1.0
    with pytest.raises(pandera.errors.SchemaError):
        TRANSACTIONS.validate(bad)
