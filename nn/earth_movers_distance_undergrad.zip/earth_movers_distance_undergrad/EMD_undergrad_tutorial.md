# Earth Mover's Distance: A Tutorial for Undergraduate Engineers

Revised edition, November 2026

## 0. How to use this tutorial

The Earth Mover's Distance (EMD) measures how different two probability distributions are by computing the cheapest way to move the probability "mass" of one onto the other. Mathematicians call the same quantity the **Wasserstein-1 distance**, written W₁. This tutorial teaches it from first principles, then shows how it is computed and how it is used in modern deep learning.

**Who it is for.** Undergraduate engineering students who know:

- single-variable calculus (derivatives, integrals);
- elementary probability (probabilities, PMFs and PDFs, expectation, variance, joint and marginal distributions);
- the vector and matrix basics of a first linear algebra course (matrix–vector products, the trace of a matrix);
- basic Python with NumPy;
- what a multilayer perceptron (MLP) is and that it is trained by gradient descent.

Nothing else is assumed. The matrix square root (one formula in Section 8.3) is explained where it appears. The code in Section 10.3 uses PyTorch's automatic differentiation; the lines that need it are explained in a short box, and nothing later depends on them. Every other idea (KL divergence, CDFs and quantiles, linear programs, Lipschitz functions, GANs, flow matching) is explained from scratch, with an example, right before it is first used. A small number of facts are stated without proof because their proofs need graduate mathematics; each is marked **(stated without proof)** so you know exactly what you are taking on trust.

**What you will be able to do.**

1. Explain in one sentence and in one formula what EMD measures, and why it beats KL or JS divergence when two distributions do not overlap.
2. Write the EMD between two discrete distributions as a linear program and solve small problems by hand.
3. Compute EMD in one dimension instantly by sorting, and use the formula for two Gaussians.
4. Explain the "critic" form of EMD and how it becomes the loss of a Wasserstein GAN.
5. Compute exact EMD, Sinkhorn (approximate) EMD and sliced Wasserstein distance in Python, and choose between them.
6. Recognise which EMD variant a paper uses in GANs, flow matching, domain adaptation or 3D point clouds.

**Roadmap.**

| Part           | Sections | What you get                                                                                   |
|----------------|----------|------------------------------------------------------------------------------------------------|
| Foundations    | 1–3      | The language of distributions, why existing measures fail, and the earth-moving idea           |
| The definition | 4–6      | EMD as an optimisation problem, how to solve it, Wasserstein distances and their properties    |
| Closed forms   | 7–8      | Instant formulas in 1D and for Gaussians                                                       |
| Deep learning  | 9–12     | The critic view, Wasserstein GANs, fast approximations, applications                           |
| Practice       | 13–16    | Code recipes, mistakes to avoid, interview questions, 24 exercises with solutions, cheat sheet |

**How to study.** Read with a pencil. Each section ends with **Check yourself** questions; answer them before reading the answers below them. Section 15 has longer exam-style exercises, with all solutions grouped at the end so you are not tempted to peek. Run the companion notebook `emd_undergrad.ipynb` alongside: it reproduces every worked example and draws every figure. Its three PyTorch cells (Sections 10, 11.2 and 12.6) store their outputs, so you can read them without a GPU or a PyTorch installation.

**Notation.** The symbols you will meet:

| Symbol                       | Meaning                                                                    |
|------------------------------|----------------------------------------------------------------------------|
| P, Q                         | The two distributions being compared                                       |
| x₁,…,xₙ and y₁,…,yₘ          | Locations of the mass of P and of Q                                        |
| a = (a₁,…,aₙ), b = (b₁,…,bₘ) | How much mass sits at each location (non-negative, each vector sums to 1)  |
| Cᵢⱼ                          | Cost of moving one unit of mass from xᵢ to yⱼ (usually their distance)     |
| γᵢⱼ (gamma)                  | Amount of mass moved from xᵢ to yⱼ; the matrix γ is the **transport plan** |
| W₁, W₂                       | Wasserstein distances; EMD = W₁                                            |
| fᵢ, gⱼ                       | Dual potentials: one number per pile and per hole (Section 5); f is also the **critic** of Section 9 |
| uᵢ, vⱼ                       | Sinkhorn scaling factors (Section 11); uᵢ = e^{fᵢ/ε}, vⱼ = e^{gⱼ/ε}       |
| δₓ                           | All the mass at the single point x (Section 1)                             |
| F, G                         | CDFs of P and Q (Section 1)                                                |
| Pr(·)                        | Probability of an event, as in Pr(X ≤ 3)                                   |
| \|z\|, ‖v‖                    | Absolute value of a number; length (Euclidean norm) of a vector            |

**What is left out.** Section 16.2 lists the topics that need graduate mathematics (measure theory, Brenier's theorem, Gromov–Wasserstein, Schrödinger bridges) and points to where to learn them.

## 1. Warm-up: distributions as piles of mass

Think of a probability distribution as a fixed amount of sand (total 1) spread along a line or over a plane: more sand where values are more likely. This picture is the whole idea behind EMD.

### 1.1 Discrete distributions and Dirac masses

A **discrete distribution** puts probability weights on a finite set of points. We write it as a weighted sum of **Dirac masses**: δₓ means "all the mass sits at the single point x". For example

$$
P = 0.2\,\delta_0 + 0.5\,\delta_1 + 0.3\,\delta_2
$$

means Pr(X = 0) = 0.2, Pr(X = 1) = 0.5 and Pr(X = 2) = 0.3: three piles of sand of sizes 0.2, 0.5 and 0.3 at positions 0, 1 and 2. The **expectation** of a function f is the weighted average E f(X) = 0.2 f(0) + 0.5 f(1) + 0.3 f(2). A **histogram** is the same object: each bin is a pile located at the bin centre.

For a continuous distribution with density p(x), sums become integrals: E f(X) = ∫ f(x) p(x) dx. Sand is then spread smoothly instead of in piles.

### 1.2 Data sets are distributions too

A data set x₁, …, xₙ (for example n measurements, or n images) is turned into a distribution by putting mass 1/n on each data point. This is the **empirical distribution**. Example: the samples 2, 2, 5 give mass ⅔ at 2 and ⅓ at 5. When we "compute the EMD between two data sets", we compute it between their empirical distributions. The samples are usually assumed **i.i.d.**: independent, and all drawn from the same underlying distribution.

### 1.3 Joint and marginal distributions (reminder)

A **joint distribution** of a pair (X, Y) gives the probability of each pair of values, for example as a table with one row per value of X and one column per value of Y. Summing a row gives Pr(X = x): the **marginal** distribution of X. Summing a column gives the marginal of Y. X and Y are **independent** when every table entry equals the product of its row and column marginals. Section 4 will reinterpret such tables as plans for moving sand.

### 1.4 The CDF and the quantile function

The **cumulative distribution function (CDF)** of a real random variable is F(x) = Pr(X ≤ x): the amount of sand at or to the left of x. For the P above, F = 0 for x \< 0, F = 0.2 on \[0, 1), F = 0.7 on \[1, 2), and F = 1 for x ≥ 2. It is a staircase that climbs from 0 to 1.

The **quantile function** F⁻¹ answers the reverse question: for a level t between 0 and 1, F⁻¹(t) is the smallest x with F(x) ≥ t, that is, the position where the running total of sand first reaches t. For our P: F⁻¹(t) = 0 for t ≤ 0.2, 1 for 0.2 \< t ≤ 0.7, and 2 for t \> 0.7. The median is F⁻¹(0.5). For a smooth, strictly increasing CDF, F⁻¹ is the ordinary inverse function; for the standard normal distribution the CDF is written Φ and Φ⁻¹(0.975) ≈ 1.96.

**A useful fact.** If U is uniform on (0, 1), then F⁻¹(U) has CDF F. This is how computers draw samples from any distribution ("inverse-transform sampling"). Reason: F⁻¹(U) ≤ x happens exactly when U ≤ F(x), which has probability F(x).

### Check yourself (Section 1)

1. Write the empirical distribution of the samples 3, 1, 2, 2 as a sum of Dirac masses.
2. For that distribution, find F(1.5), F(2), F⁻¹(0.5) and F⁻¹(0.9).
3. For P = 0.2δ₀ + 0.5δ₁ + 0.3δ₂, compute E X and E X².
4. In a joint table with rows x ∈ {0, 1} and columns y ∈ {0, 1}, the entries are 0.1, 0.3 (first row) and 0.2, 0.4 (second row). Give both marginals. Are X and Y independent?

**Answers.** (1) ¼δ₁ + ½δ₂ + ¼δ₃. (2) F(1.5) = 0.25, F(2) = 0.75, F⁻¹(0.5) = 2 (the first point where F ≥ 0.5) and F⁻¹(0.9) = 3. (3) E X = 0.5 + 0.6 = 1.1 and E X² = 0.5 + 1.2 = 1.7. (4) X: (0.4, 0.6); Y: (0.3, 0.7). Not independent: 0.4 × 0.3 = 0.12 ≠ 0.1.

## 2. Why we need EMD

The standard ways of comparing distributions look at each location separately and never ask how far apart the locations are. That makes them blind to small shifts and useless as training losses when distributions do not overlap. EMD fixes both problems.

### 2.1 Three standard measures, defined from scratch

Let a and b be two probability vectors over the same points (two histograms with the same bins).

$$
\mathrm{TV}(a,b)=\tfrac12\sum_k |a_k-b_k|, \qquad \mathrm{KL}(a\,\|\,b)=\sum_k a_k\log\frac{a_k}{b_k}, \qquad \mathrm{JS}(a,b)=\tfrac12\mathrm{KL}(a\,\|\,m)+\tfrac12\mathrm{KL}(b\,\|\,m),\;\; m=\tfrac12(a+b).
$$

- **Total variation (TV)** is half the total absolute difference in mass. It lies between 0 and 1.
- **Kullback–Leibler divergence (KL)** uses the natural log, with the conventions 0·log 0 = 0 and KL = +∞ if some aₖ \> 0 where bₖ = 0. It is ≥ 0, equals 0 only when a = b, and is **not symmetric**.
- **Jensen–Shannon divergence (JS)** compares both vectors with their average m. It is symmetric, always finite, and never exceeds log 2 ≈ 0.693.

**Worked example.** a = (0.5, 0.5, 0) and b = (0.25, 0.25, 0.5).

1. TV = ½(0.25 + 0.25 + 0.5) = **0.5**.
2. KL(a ‖ b) = 0.5 log 2 + 0.5 log 2 + 0 = **log 2 ≈ 0.693**.
3. KL(b ‖ a) = **+∞**, because b puts mass on the third point where a has none.
4. m = (0.375, 0.375, 0.25), KL(a ‖ m) = log(4/3) ≈ 0.288, KL(b ‖ m) = ½ log(4/3) ≈ 0.144, so JS ≈ **0.216**.

**You already use KL.** The cross-entropy loss of an MLP classifier is −Σₖ aₖ log bₖ, with a the one-hot true label and b the softmax output. Since −Σₖ aₖ log bₖ = KL(a ‖ b) − Σₖ aₖ log aₖ, and the last sum is 0 for a one-hot vector, cross-entropy training minimises KL. Example: true class 2, prediction (0.2, 0.7, 0.1), loss −log 0.7 ≈ 0.357.

### 2.2 Problem 1: blind to distance

Three histograms over grey levels 1 to 10, each with all its mass in one bin: A in bin 1, B in bin 2, C in bin 10. B is clearly closer to A than C is. Yet TV(A, B) = TV(A, C) = 1, KL(A ‖ B) = KL(A ‖ C) = +∞, and JS(A, B) = JS(A, C) = log 2. These measures only check whether mass is at the **same** location, never how far it is from where it should be.

EMD asks how much work it takes to move the mass: moving one unit of mass from bin 1 to bin 2 costs 1 × 1 = **1**, and from bin 1 to bin 10 costs 1 × 9 = **9**. That matches our intuition.

### 2.3 Problem 2: useless gradients when distributions do not overlap

Let P = δ₀ (all mass at 0) and Q_θ = δ_θ (all mass at θ). Think of P as real data and Q_θ as the output of a model with a single parameter θ that we want to train. For θ ≠ 0:

| Measure     | Value for θ ≠ 0 | Value at θ = 0 | Gradient with respect to θ        |
|-------------|-----------------|----------------|-----------------------------------|
| KL(P ‖ Q_θ) | +∞              | 0              | none (infinite)                   |
| JS(P, Q_θ)  | log 2 ≈ 0.693   | 0              | 0 (constant)                      |
| TV(P, Q_θ)  | 1               | 0              | 0 (constant)                      |
| EMD = W₁    | \|θ\|          | 0              | sign(θ): descent moves θ toward 0 |

**Derivations.** KL is infinite because P puts mass at 0 where Q_θ has none. For JS, the average is m = ½δ₀ + ½δ_θ, so KL(P ‖ m) = 1·log(1/½) = log 2 and likewise KL(Q_θ ‖ m) = log 2, giving JS = log 2. TV = ½(1 + 1) = 1. EMD: all the mass must travel distance |θ|.

![Figure 1: W1, JS and TV as a function of the shift θ](figures/fig1_disjoint.png)

*Figure 1. As soon as θ ≠ 0, JS and TV jump to a constant and their gradient is zero, so gradient descent gets no signal. W₁ = |θ| keeps decreasing as θ approaches 0.*

**Why this matters for deep learning.** A generative network (Section 10) produces samples, and in high dimensions its samples and the real data typically occupy thin, non-overlapping regions, just like δ₀ and δ_θ here. A loss based on JS (the original GAN) then gives the generator little useful gradient. A loss based on EMD does. This observation, made precise by Arjovsky, Chintala and Bottou (2017), made EMD a standard training loss in deep learning. (EMD losses for networks are a little older: Frogner et al. (2015) trained classifiers with an EMD loss between predicted and true label distributions.)

### 2.4 Two more advantages of EMD

1. **It has physical units.** If positions are in metres, EMD is in metres: it is the average distance a unit of mass must travel. Change metres to centimetres and EMD is multiplied by 100; KL and JS do not change at all, because they ignore positions.
2. **It changes gradually.** Shift every point of a distribution by a small distance ε and EMD changes by at most ε (Exercise 15.24). KL, JS and TV can jump from 0 to their maximum under an arbitrarily small shift.
3. **It is continuous in the model's parameters.** Suppose a model produces samples g_θ(z) from noise z, and g_θ(z) depends continuously on the parameters θ (true of every MLP). Then W₁(P_r, P_θ) is a continuous function of θ, and under a mild extra condition it is differentiable for almost every θ (Arjovsky et al. 2017, Theorem 1; stated without proof). JS, KL and TV are *not* continuous in θ in general: the example of 2.3 is a one-parameter model where they jump. This theorem is the formal reason EMD is a usable loss.

The price: EMD is defined by an optimisation problem, so it is more expensive to compute. Much of this tutorial is about computing it efficiently.

### Check yourself (Section 2)

1. For a = (0.2, 0.8) and b = (0.5, 0.5), compute TV(a, b) and KL(a ‖ b).
2. Histograms on bins 1 to 100: A has all mass in bin 30, B all mass in bin 31. What are TV and EMD (bin spacing 1)?
3. JS(P, Q_θ) = log 2 is finite. Why is it still useless for training θ?

**Answers.** (1) TV = ½(0.3 + 0.3) = 0.3; KL = 0.2 log 0.4 + 0.8 log 1.6 ≈ −0.183 + 0.376 = 0.193. (2) TV = 1; EMD = 1. (3) It is constant for every θ ≠ 0, so its derivative is 0 and gradient descent does not know which way to move.

## 3. The idea: moving earth

EMD is the minimum total work, measured as mass × distance, needed to reshape one pile of earth into another, when you are free to decide which shovelful goes where.

### 3.1 Piles and holes

Picture P as piles of earth: pile i sits at position xᵢ and contains aᵢ units (total 1). Picture Q as holes: hole j sits at yⱼ and needs exactly bⱼ units (total 1). Moving one unit from xᵢ to yⱼ costs Cᵢⱼ, normally the distance between them. You must empty every pile and fill every hole, and you may split a pile among several holes. **EMD is the cost of the cheapest way to do it.**

The French engineer Gaspard Monge posed this problem in 1781 for moving soil dug from fortifications. Leonid Kantorovich gave its modern form in 1942 (he later won a Nobel Prize in economics, partly for this work). The field is called **optimal transport (OT)**.

### 3.2 Worked example: finding the cheapest plan by hand

On the real line, P has mass 0.5 at x = 0 and 0.5 at x = 2. Q has mass 0.25 at y = 1 and 0.75 at y = 3. Cost = distance, |x − y|.

**Step 1: list the costs.**

| From \\ To      | y = 1 (needs 0.25) | y = 3 (needs 0.75) |
|-----------------|--------------------|--------------------|
| x = 0 (has 0.5) | 1                  | 3                  |
| x = 2 (has 0.5) | 1                  | 1                  |

**Step 2: describe every valid plan with one number.** Let α be the mass moved from 0 to 1. Everything else is then forced:

- from 0 to 3: 0.5 − α (the pile at 0 must be emptied);
- from 2 to 1: 0.25 − α (the hole at 1 must receive exactly 0.25);
- from 2 to 3: 0.5 − (0.25 − α) = 0.25 + α.

All amounts must be non-negative, so 0 ≤ α ≤ 0.25.

**Step 3: total cost as a function of α.**

$$
\text{cost}(\alpha) = 1\cdot\alpha + 3\,(0.5-\alpha) + 1\cdot(0.25-\alpha) + 1\cdot(0.25+\alpha) = 2 - 2\alpha .
$$

**Step 4: minimise.** The cost decreases as α grows, so take α = 0.25: move 0.25 from 0 to 1, 0.25 from 0 to 3, and 0.5 from 2 to 3. The minimum cost is **EMD = 2 − 0.5 = 1.5**.

![Figure 2: the optimal plan of Example 3.2 drawn as arrows](figures/fig2_transport.png)

*Figure 2. The optimal plan: piles of P on top, holes of Q below, arrow width proportional to the mass carried. The pile at 0 is split, and no two arrows cross.*

**Three lessons.** (i) The cost is a linear function of the plan, so the best plan sits at an end of the allowed range (in bigger problems, at a "corner"). (ii) The best plan is **monotone**: the leftmost mass goes to the leftmost hole first and arrows never cross; Section 7 shows that this is always true in 1D. (iii) The worst plan (α = 0) costs 2.0, so careless plans can be far from optimal.

### 3.3 Worked example: shifting a whole distribution

Let Q be P shifted by a fixed vector v: if X has distribution P, then X + v has distribution Q. Moving every point x to x + v costs ‖v‖ per unit of mass, so EMD ≤ ‖v‖. In fact EMD = ‖v‖ exactly (Exercise 15.7). So **the EMD of a translation is the length of the translation**, whatever the shape of P. Compare KL between N(0, σ²) and N(v, σ²), which is v²/(2σ²): it depends on the width σ and explodes as σ → 0, while the EMD stays |v|.

### 3.4 Worked example: two equal-size point sets

Let P put mass ⅓ on each of the points 0, 4, 10 and Q mass ⅓ on each of 1, 5, 6. When both sides have the same number of points with equal masses, an optimal plan can always be chosen as a **one-to-one matching** (Section 5.3). Matching sorted to sorted, 0→1, 4→5, 10→6, costs (1 + 1 + 4)/3 = 2. A crossing matching such as 0→5, 4→1, 10→6 costs (5 + 3 + 4)/3 = 4. Sorted matching is optimal in 1D (Section 7), so **EMD = 2**.

### Check yourself (Section 3)

1. P = δ₀ and Q = ½δ₋₁ + ½δ₁. Compute the EMD.
2. In Example 3.2, which plan does α = 0 correspond to, and why does it cost more?
3. Positions are re-measured in centimetres instead of metres. What happens to the EMD of Example 3.2?

**Answers.** (1) The single pile must split in half: 0.5 × 1 + 0.5 × 1 = **1**. (2) It sends all of pile 0 to hole 3 (a long trip of length 3) and part of pile 2 back to hole 1. The extra 0.25 units on the long trip cost 0.5 more in total. (3) It is multiplied by 100 (it has units of length): 150 centimetres instead of 1.5 metres.

## 4. The definition: transport plans and a linear program

For discrete distributions, EMD is the smallest value of a linear cost over all **transport plans**: tables of non-negative numbers whose rows add up to the piles and whose columns add up to the holes.

### 4.1 A two-minute introduction to linear programs

A **linear program (LP)** minimises a linear function subject to linear equations and inequalities. Tiny example: minimise x + 2y subject to x + y = 1, x ≥ 0, y ≥ 0. The allowed points form the segment from (1, 0) to (0, 1). The objective equals 1 at (1, 0) and 2 at (0, 1), and is linear in between, so the minimum is **1 at the corner (1, 0)**. This is true of every LP: the allowed region is a flat-sided shape (a polytope), and a linear function is smallest at one of its corners. Solvers for LPs are standard in Python (`scipy.optimize.linprog`).

### 4.2 The transport plan

Let P have masses a₁,…,aₙ at x₁,…,xₙ and Q have masses b₁,…,bₘ at y₁,…,yₘ, with Σaᵢ = Σbⱼ = 1. A **transport plan** is an n × m table γ, where γᵢⱼ is the amount of mass moved from xᵢ to yⱼ. It must satisfy

$$
\gamma_{ij} \ge 0, \qquad \sum_{j=1}^{m}\gamma_{ij} = a_i \;\;(\text{row } i \text{ empties pile } i), \qquad \sum_{i=1}^{n}\gamma_{ij} = b_j \;\;(\text{column } j \text{ fills hole } j).
$$

The total cost of the plan is Σᵢ Σⱼ γᵢⱼ Cᵢⱼ (amount × price, summed over all routes), and

$$
\mathrm{EMD}(P,Q) \;=\; \min_{\gamma}\; \sum_{i=1}^{n}\sum_{j=1}^{m} \gamma_{ij}\,C_{ij} \qquad \text{over all valid plans } \gamma, \text{ with } C_{ij} = \text{distance}(x_i, y_j).
$$

The objective and all constraints are linear in the numbers γᵢⱼ, so this is an LP with nm unknowns.

### 4.3 A plan is a joint distribution

The entries of γ are non-negative and add up to 1, so γ is a **joint distribution** of a pair (X, Y) (Section 1.3): Pr(X = xᵢ, Y = yⱼ) = γᵢⱼ. The row constraints say the marginal of X is P; the column constraints say the marginal of Y is Q. A valid plan is therefore any way of pairing X ~ P with Y ~ Q, and

$$
\mathrm{EMD}(P,Q) = \min_{(X,Y):\;X\sim P,\;Y\sim Q}\;\mathbb{E}\big[\,\text{distance}(X,Y)\,\big].
$$

Papers call such a joint distribution a **coupling**, write the set of all couplings as Π(P, Q), and write the formula as "min over γ ∈ Π(P, Q) of E\_{(x,y)~γ}‖x − y‖". It is the same thing.

**A free upper bound.** The independent plan γᵢⱼ = aᵢbⱼ is always valid (row i sums to aᵢ·Σⱼbⱼ = aᵢ). So EMD ≤ E\[distance(X, Y)\] with X and Y drawn independently. For P = Q this bound is usually not 0, which shows why we must optimise: the best plan for P = Q keeps every grain where it is, with cost 0.

### 4.4 Worked example: three warehouses, three stores

Three warehouses hold fractions a = (0.3, 0.3, 0.4) of a product; three stores need b = (0.1, 0.4, 0.5). Shipping costs per unit:

| From \\ To   | S1 (needs 0.1) | S2 (needs 0.4) | S3 (needs 0.5) |
|--------------|----------------|----------------|----------------|
| W1 (has 0.3) | 6              | 6              | 3              |
| W2 (has 0.3) | 1              | 2              | 2              |
| W3 (has 0.4) | 1              | 3              | 7              |

The LP has 9 unknowns γ₁₁,…,γ₃₃ ≥ 0 and 6 equations: three rows (γ₁₁ + γ₁₂ + γ₁₃ = 0.3, and so on) and three columns (γ₁₁ + γ₂₁ + γ₃₁ = 0.1, and so on). Section 5 solves it: the optimum is **2.5**.

**Does a best plan always exist?** Yes. The independent plan shows at least one valid plan exists; every γᵢⱼ lies between 0 and 1, so the set of plans is bounded; and it is defined by equations and non-strict inequalities, so it includes its boundary. A continuous (here linear) function on such a set attains its minimum, by the multivariable version of the extreme value theorem from calculus.

### 4.5 Choosing the cost

| Cost Cᵢⱼ                      | Result           | Typical use                                              |
|-------------------------------|------------------|----------------------------------------------------------|
| ‖xᵢ − yⱼ‖ (distance)          | EMD = W₁         | Histograms, images, WGANs, point clouds                  |
| ‖xᵢ − yⱼ‖² (squared distance) | W₂² (Section 6)  | Flow matching, Gaussians, FID                            |
| \|i − j\| for bin indices    | 1D histogram EMD | Grey-level histograms, ordered class labels              |
| 0 if i = j, 1 otherwise       | Total variation  | Shows TV is EMD that cannot see distance (Exercise 15.6) |

**Unequal total mass.** The definition above needs both sides to have the same total. The original computer-vision EMD (Rubner, Tomasi and Guibas, 2000) also allowed unequal totals by matching only part of the larger side, but then it is no longer a true distance. In deep learning, normalise both sides to total 1 and use the definition above.

### Check yourself (Section 4)

1. If P is a single pile (n = 1), what are the valid plans, and what is the EMD?
2. Check that the independent plan aᵢbⱼ satisfies the column constraints.
3. How many unknowns and equations does the LP have for n = m = 1000?

**Answers.** (1) Only one plan: the pile is split exactly as Q requires, γ₁ⱼ = bⱼ. EMD = Σⱼ bⱼ·distance(x₁, yⱼ), the average distance from x₁ to Q. (2) Column j sums to Σᵢ aᵢbⱼ = bⱼ Σᵢ aᵢ = bⱼ. (3) 1 000 000 unknowns and 2000 equations; this is why fast special-purpose solvers matter (Section 5.4).

## 5. Solving small problems, and proving a plan is optimal

Quick rules of thumb give valid plans but not the cheapest one; a solver finds the optimum, and a set of "prices" called potentials lets you **prove** a plan is optimal without trying all the others. We solve the warehouse problem of 4.4 (EMD = 2.5).

### 5.1 Two quick plans, and why they are not enough

**North-west corner rule.** Start at the top-left cell, ship as much as possible, move right when the column is full or down when the row is empty, and repeat. It ignores costs.

| North-west plan | S1  | S2  | S3  |
|-----------------|-----|-----|-----|
| W1              | 0.1 | 0.2 | 0   |
| W2              | 0   | 0.2 | 0.1 |
| W3              | 0   | 0   | 0.4 |

Cost = 0.1·6 + 0.2·6 + 0.2·2 + 0.1·2 + 0.4·7 = **5.2**.

**Greedy rule.** Repeatedly pick the cheapest remaining cell and ship as much as possible through it.

| Greedy plan | S1  | S2  | S3  |
|-------------|-----|-----|-----|
| W1          | 0   | 0   | 0.3 |
| W2          | 0.1 | 0.2 | 0   |
| W3          | 0   | 0.2 | 0.2 |

Trace: (W2,S1) at cost 1 takes 0.1 and fills S1; (W2,S2) at cost 2 takes 0.2 and empties W2; (W1,S3) at cost 3 takes 0.3; (W3,S2) at cost 3 takes 0.2; finally (W3,S3) is forced to take the last 0.2 at cost 7. Total **3.4**. Early cheap choices forced an expensive route at the end, so greedy is not optimal in general.

### 5.2 The optimum, and a certificate that proves it

An LP solver (Section 13) returns this plan:

| Optimal plan | S1  | S2  | S3  | Row sum |
|--------------|-----|-----|-----|---------|
| W1           | 0   | 0   | 0.3 | 0.3     |
| W2           | 0   | 0.1 | 0.2 | 0.3     |
| W3           | 0.1 | 0.3 | 0   | 0.4     |
| Column sum   | 0.1 | 0.4 | 0.5 | 1       |

Cost = 0.9 + 0.2 + 0.4 + 0.1 + 0.9 = **2.5**. How can we be sure no plan is cheaper?

![Figure 3: the north-west, greedy and optimal plans as 3 × 3 tables](figures/fig3_plans.png)

*Figure 3. The three plans of the warehouse problem drawn as tables (darker = more mass; the unit cost of each route is in brackets). The optimal plan uses only 5 of the 9 routes.*

**The certificate.** Find numbers f₁, f₂, f₃ (one per warehouse) and g₁, g₂, g₃ (one per store), called **dual potentials**, such that

$$
f_i + g_j \le C_{ij} \;\;\text{for every route } (i,j), \qquad f_i + g_j = C_{ij} \;\;\text{on every route the plan uses}.
$$

**Lemma (weak duality).** If a valid plan γ\* and potentials f, g satisfy both conditions, then γ\* is optimal and its cost equals Σᵢ aᵢfᵢ + Σⱼ bⱼgⱼ.

**Proof.** Take any valid plan γ. Every γᵢⱼ ≥ 0 and Cᵢⱼ ≥ fᵢ + gⱼ, so

$$
\sum_{i,j}\gamma_{ij}C_{ij} \;\ge\; \sum_{i,j}\gamma_{ij}(f_i+g_j) \;=\; \sum_i f_i\sum_j\gamma_{ij} + \sum_j g_j\sum_i\gamma_{ij} \;=\; \sum_i a_if_i + \sum_j b_jg_j .
$$

The right side does not depend on γ, so it is a lower bound for every plan. For γ\* the inequality is an equality, because every route it uses has Cᵢⱼ = fᵢ + gⱼ. So γ\* reaches the lower bound and no plan can be cheaper. ∎

**The dual linear program.** The lemma says that *any* f, g with fᵢ + gⱼ ≤ Cᵢⱼ everywhere give a lower bound Σaᵢfᵢ + Σbⱼgⱼ on the EMD. Finding the best lower bound is itself an LP, called the **dual** of the transport problem:

$$
\max_{f,\,g}\; \sum_i a_i f_i + \sum_j b_j g_j \qquad \text{subject to}\qquad f_i + g_j \le C_{ij}\;\;\text{for all } i, j .
$$

**Strong duality (stated without proof).** The maximum of the dual equals the minimum of the original ("primal") problem. So optimal potentials always exist, and a solver returns them together with the plan (`ot.emd(..., log=True)` gives them as `log["u"]` and `log["v"]`). The sign pattern to remember: the plan is the *minimum* of a cost, the potentials are the *maximum* of a bound, and the two numbers coincide. Papers write the potentials as f, g or φ, ψ, call them "Kantorovich potentials", and call the condition fᵢ + gⱼ = Cᵢⱼ on used routes "complementary slackness". Exercise 15.22 solves a dual LP by hand.

**Finding the potentials.** Use the 5 routes of the optimal plan, fᵢ + gⱼ = Cᵢⱼ, and fix f₂ = 0 (potentials are only determined up to adding a constant to all f and subtracting it from all g):

- (W2,S2): g₂ = 2; (W2,S3): g₃ = 2; (W1,S3): f₁ = 3 − 2 = 1; (W3,S2): f₃ = 3 − 2 = 1; (W3,S1): g₁ = 1 − 1 = 0.

Check the unused routes: f₁ + g₁ = 1 ≤ 6, f₁ + g₂ = 3 ≤ 6, f₂ + g₁ = 0 ≤ 1, f₃ + g₃ = 3 ≤ 7. All hold, so the plan is optimal. The lower bound is Σaᵢfᵢ + Σbⱼgⱼ = (0.3 + 0 + 0.4) + (0 + 0.8 + 1.0) = **2.5**, equal to the cost.

**Economic reading.** Think of fᵢ as a fee for picking up a unit at warehouse i and gⱼ as a fee for delivering a unit at store j. If a competing shipper's combined fee never exceeds your cost on any route, their total revenue is a lower bound on any plan's cost. When your plan only uses routes where their fee equals your cost, you cannot be beaten.

**How a solver improves a bad plan.** Compute potentials from the routes a plan uses, then look at the **reduced cost** Cᵢⱼ − fᵢ − gⱼ of each unused route. A negative value means the plan can be improved. For the greedy plan, the potentials are f = (−3, 0, 1) and g = (1, 2, 6); route (W2,S3) has reduced cost 2 − 0 − 6 = −4. Sending mass along the loop (W2,S3) +, (W3,S3) −, (W3,S2) +, (W2,S2) − keeps every row and column sum unchanged and saves 4 per unit; 0.2 units can be shifted, bringing the cost from 3.4 to 2.6. One more such step reaches 2.5. This repeated improvement is the idea behind the network-simplex solver used by the POT library.

### 5.3 Two facts about optimal plans

1. **Optimal plans are sparse.** Some optimal plan uses at most n + m − 1 routes, out of n × m possible. Reason: if the used routes contained a loop like the one above, you could push mass around the loop in one of the two directions without increasing the cost, until one route empties. For n = m = 1000, that is under 2000 routes out of a million.
2. **Equal-size point sets need only a matching.** If P and Q each have n points with mass 1/n, some optimal plan is a one-to-one matching: each point of P sends all its mass to exactly one point of Q (the Birkhoff–von Neumann theorem; stated without proof). Then EMD is the average distance of the best matching, and `scipy.optimize.linear_sum_assignment` finds it in O(n³) time.

### 5.4 Algorithms and their cost

| Method                      | What it solves                    | Time for n points per side        | Where                                         |
|-----------------------------|-----------------------------------|-----------------------------------|-----------------------------------------------|
| General LP solver           | Any LP                            | Slow; fine for tiny problems      | `scipy.optimize.linprog`                      |
| Network simplex             | Exact EMD                         | Roughly cubic in n                | `ot.emd`, `ot.emd2` (POT)                     |
| Assignment (Hungarian-type) | Equal-size, equal-mass point sets | O(n³)                             | `scipy.optimize.linear_sum_assignment`        |
| Sorting                     | Exact EMD in 1D                   | O(n log n)                        | Section 7; `scipy.stats.wasserstein_distance` |
| Sinkhorn                    | Approximate EMD                   | O(n²) per iteration, GPU-friendly | Section 11                                    |
| Sliced Wasserstein          | 1D slices averaged                | O(L·n log n) for L slices         | Section 11                                    |

Memory is often the real limit: the cost matrix has n × m entries, 7.2 GB for n = m = 30 000 in 64-bit floats (9 × 10⁸ entries × 8 bytes).

### Check yourself (Section 5)

1. Why may we fix f₂ = 0 when computing potentials?
2. Add the same constant k to every cost Cᵢⱼ. How do the optimal plan and the EMD change?
3. P = {(0, 0), (1, 0)} and Q = {(0, 1), (1, 1)}, each point with mass ½. Compute the EMD.

**Answers.** (1) Adding t to every fᵢ and subtracting t from every gⱼ leaves every fᵢ + gⱼ unchanged and the dual objective unchanged (because Σaᵢ = Σbⱼ), so one potential can be chosen freely. (2) Every plan's cost rises by exactly k (the plan's entries sum to 1), so the optimal plan is unchanged and EMD increases by k. (3) Match straight up: each point moves distance 1, so EMD = 1. The crossed matching costs √2 per point.

## 6. Wasserstein distances and their properties

The same idea works for any distributions, discrete or continuous: the p-Wasserstein distance is the smallest possible average of distanceᵖ over all ways of pairing X ~ P with Y ~ Q, then raised to the power 1/p. EMD is the case p = 1, and W₂ (p = 2) is the other one you will meet constantly.

### 6.1 Definition

For p ≥ 1,

$$
W_p(P,Q) \;=\; \Big( \min_{(X,Y):\;X\sim P,\;Y\sim Q} \; \mathbb{E}\big[\,\|X-Y\|^p\,\big] \Big)^{1/p}.
$$

The minimum is over all couplings, exactly as in Section 4.3. W₁ is the EMD. For W₂ the cost is the squared distance, and the square root is taken at the end so that W₂ is again a distance in the units of the data. (For general distributions the minimum is called an infimum in papers; for everything in this tutorial it is attained.) We require E‖X‖ᵖ \< ∞, so that the averages are finite.

### 6.2 Maps versus plans

Monge looked for a **map**: send each point x to one destination T(x). Kantorovich allowed **plans**, which may split a point's mass among several destinations. Maps are not always enough: from P = δ₀ to Q = ½δ₋₁ + ½δ₁ no map works, because the single point 0 must be split in half. Plans always work, and the problem becomes the linear program of Section 4. When an optimal map does exist, the two problems give the same answer.

### 6.3 Properties to know by heart

**W_p is a true distance (a metric) between distributions** (stated without full proof here; Section 7.2 proves all three axioms for W₁ in 1D):

1. W_p(P, Q) ≥ 0, and W_p(P, Q) = 0 exactly when P = Q.
2. Symmetry: W_p(P, Q) = W_p(Q, P), because a plan can be run backwards.
3. Triangle inequality: W_p(P, R) ≤ W_p(P, Q) + W_p(Q, R). Intuition: moving earth from P to R via an intermediate arrangement Q cannot be cheaper than the cheapest direct way.

| Property                | Statement                                                   | Why                                    |
|-------------------------|-------------------------------------------------------------|----------------------------------------|
| Two single points       | W_p(δₓ, δ_y) = ‖x − y‖                                      | Only one plan exists                   |
| A point versus anything | W₁(δₓ, Q) = E_Q‖x − Y‖                                      | Only one plan: send x everywhere       |
| Ordering                | W₁ ≤ W₂                                                     | (E D)² ≤ E D², because variance is ≥ 0 |
| Translation             | Shifting by v gives W_p = ‖v‖                               | Section 3.3, Exercise 15.7             |
| Scaling                 | Multiplying all data by s multiplies W_p by \|s\|          | Every distance is multiplied by \|s\| |
| Means                   | W₁(P, Q) ≥ ‖mean(P) − mean(Q)‖                              | ‖E(X − Y)‖ ≤ E‖X − Y‖ for every plan   |
| W₂ splits               | W₂² = ‖mean difference‖² + W₂² of the centred distributions | Exercise 15.9                          |

### 6.4 Sensitivity to far-away mass

Let Pₖ = (1 − 1/k)δ₀ + (1/k)δₖ: almost all mass at 0, plus a tiny amount 1/k far away at position k. As k grows, Pₖ looks more and more like δ₀ in the sense that Pr(X ≠ 0) = 1/k → 0. Yet W₁(Pₖ, δ₀) = (1/k)·k = 1 for every k: the tiny mass travels so far that the work never shrinks. EMD notices outliers. That is useful (it detects them) and a weakness (one outlier can dominate the value).

### 6.5 Computing W from samples: two cautions

In practice P and Q are known only through samples, and we compute W between the two empirical distributions (Section 1.2).

1. **The estimate is biased upward.** Even when P = Q, two independent samples differ, so their EMD is positive. For example, if X and Y are single draws from N(0, 1), the EMD between them is |X − Y|, whose average is 2/√π ≈ 1.13 although the true EMD is 0 (Exercise 15.13). The bias shrinks as the sample size grows, but slowly. Always compare EMD values computed with the **same** sample size, and report a "noise floor": the EMD between two independent samples of the reference data.
2. **High dimensions need many samples.** For data in d dimensions, the average EMD between an n-sample empirical distribution and the true distribution shrinks like n^{−1/d} for d ≥ 3 (like n^{−1/2} in 1D, and n^{−1/2} up to a logarithm in 2D; stated without proof, Dudley 1969). Intuition: n points spread through a d-dimensional region sit about n^{−1/d} apart, and no sample can describe the distribution better than its own spacing. In d = 10, halving the error needs 2¹⁰ ≈ 1000 times more samples. The notebook shows it: with n = 100 versus n = 1000 points from the same Gaussian, the sample EMD falls from 0.20 to 0.07 in 1D but only from 2.6 to 2.0 in d = 10. This is one reason the approximations of Section 11 are popular: the Sinkhorn divergence and sliced Wasserstein distance can be estimated from far fewer samples (stated without proof).

### Check yourself (Section 6)

1. Compute W₂(δ₀, ½δ₋₁ + ½δ₁) and compare with W₁.
2. Pₖ = (1 − 1/k)δ₀ + (1/k)δ\_{√k}. Does W₁(Pₖ, δ₀) go to 0? Does W₂?
3. Why can't a map turn δ₀ into ½δ₋₁ + ½δ₁?

**Answers.** (1) W₂ = √(½·1² + ½·1²) = 1 = W₁, because every unit travels exactly distance 1. (2) W₁ = (1/k)·√k = 1/√k → 0. W₂² = (1/k)·k = 1, so W₂ = 1 for every k and does not go to 0: higher p is more sensitive to far-away mass. (3) A map sends the point 0 to a single destination, so the result is again a single point mass; splitting is impossible.

## 7. One dimension: sort and match

On the real line, the optimal plan simply matches quantiles: smallest to smallest, next to next, and so on. So EMD is the area between the two CDFs, and every W_p can be computed exactly by sorting, in O(n log n) time.

### 7.1 The formulas

Let F, G be the CDFs and F⁻¹, G⁻¹ the quantile functions of P and Q (Section 1.4). Then

$$
W_1(P,Q) = \int_{-\infty}^{\infty} \big| F(x) - G(x) \big| \, dx, \qquad W_p^p(P,Q) = \int_0^1 \big| F^{-1}(t) - G^{-1}(t) \big|^p \, dt .
$$

For two samples of the same size n, with sorted values x₍₁₎ ≤ … ≤ x₍ₙ₎ and y₍₁₎ ≤ … ≤ y₍ₙ₎, the second formula becomes

$$
W_p^p = \frac{1}{n}\sum_{i=1}^{n} \big| x_{(i)} - y_{(i)} \big|^p .
$$

The picture to remember: **EMD in 1D is the area between the two CDF curves.**

![Figure 4: the area between the two CDFs of Example 3.2](figures/fig4_cdf_area.png)

*Figure 4. The CDFs of Example 3.2. The shaded area between them is exactly W₁ = 1.5.*

### 7.2 Why sorting is optimal: the uncrossing argument

A function h is **convex** if the chord between any two points of its graph lies on or above the graph: h(λu + (1 − λ)w) ≤ λh(u) + (1 − λ)h(w) for 0 ≤ λ ≤ 1. Examples: |z|, z², and |z|ᵖ for p ≥ 1.

**Lemma (uncrossing).** Let h be convex, x₁ ≤ x₂ and y₁ ≤ y₂. Then

$$
h(x_1-y_1) + h(x_2-y_2) \;\le\; h(x_1-y_2) + h(x_2-y_1).
$$

In words: matching small to small and large to large never costs more than the crossed matching.

**Proof.** Put A = x₁ − y₂, B₁ = x₁ − y₁, B₂ = x₂ − y₂, D = x₂ − y₁. Then A ≤ B₁ ≤ D, A ≤ B₂ ≤ D, and B₁ + B₂ = A + D. If A = D, all four are equal and there is nothing to prove. Otherwise write B₁ = λA + (1 − λ)D for some λ ∈ \[0, 1\]; then B₂ = A + D − B₁ = (1 − λ)A + λD. Convexity gives h(B₁) ≤ λh(A) + (1 − λ)h(D) and h(B₂) ≤ (1 − λ)h(A) + λh(D). Adding the two inequalities gives the claim. ∎

**Theorem (sort and match).** For two samples of the same size with equal weights and cost |x − y|ᵖ, p ≥ 1, the sorted matching is optimal.

**Proof.** By Section 5.3 an optimal plan can be taken to be a matching. If it is not the sorted matching, two of its pairs cross. Swapping their partners does not increase the cost (Lemma) and reduces the number of crossing pairs. Repeating, we reach the sorted matching without ever increasing the cost, so the sorted matching is optimal. ∎

The same reasoning extends to unequal sample sizes and weights, and to continuous distributions, giving the quantile formula of 7.1 (stated without proof). The CDF formula for W₁ is the same area seen sideways: the region between the graphs of F⁻¹ and G⁻¹ on \[0, 1\] is the region between the graphs of F and G, reflected across the diagonal.

**Warning.** The Lemma needs a convex cost. With the concave cost |x − y|^(1/2), crossing can be cheaper (Exercise 15.5), and sorting is not optimal.

**The metric axioms, proved in 1D.** Section 6.3 stated without proof that W₁ is a distance. In 1D the CDF formula makes this elementary. Symmetry: |F − G| = |G − F|. Triangle inequality: for a third distribution R with CDF H, |F(x) − H(x)| ≤ |F(x) − G(x)| + |G(x) − H(x)| at every x; integrate both sides to get W₁(P, R) ≤ W₁(P, Q) + W₁(Q, R). Identity: if ∫|F − G| dx = 0 then F = G except possibly on a set of isolated points; but CDFs are right-continuous (F(x) = lim of F(x + h) as h ↓ 0), so F = G everywhere, which means P = Q. Exercise 15.24 asks you to write this out and to use it.

### 7.3 Worked examples

**Example 7.A (Example 3.2 via CDFs).** P = ½δ₀ + ½δ₂, Q = ¼δ₁ + ¾δ₃.

| Interval | F(x) | G(x) | \|F − G\| | Length | Area |
|----------|------|------|------------|--------|------|
| \[0, 1)  | 0.5  | 0    | 0.5        | 1      | 0.5  |
| \[1, 2)  | 0.5  | 0.25 | 0.25       | 1      | 0.25 |
| \[2, 3)  | 1    | 0.25 | 0.75       | 1      | 0.75 |

W₁ = 0.5 + 0.25 + 0.75 = **1.5**, the same as the hand-solved plan in Section 3.2.

**Example 7.B (samples).** x = \[6, 1, 3\], y = \[9, 2, 2\]. Sorted: \[1, 3, 6\] and \[2, 2, 9\]. W₁ = (1 + 1 + 3)/3 = **5/3 ≈ 1.667**; W₂ = √((1 + 1 + 9)/3) = √(11/3) ≈ **1.915**.

**Example 7.C (two uniform distributions).** P = Uniform\[0, 1\], Q = Uniform\[0, 2\]. Quantiles: F⁻¹(t) = t and G⁻¹(t) = 2t, so W₁ = ∫₀¹ t dt = **1/2** and W₂² = ∫₀¹ t² dt = 1/3, W₂ = 1/√3 ≈ **0.577**. Check with CDFs: ∫₀¹ (x − x/2) dx + ∫₁² (1 − x/2) dx = 1/4 + 1/4 = 1/2.

**Example 7.D (two exponential distributions).** P = Exp(λ), Q = Exp(μ), with rates λ and μ. Quantiles F⁻¹(t) = −ln(1 − t)/λ, so the difference of quantiles is (1/λ − 1/μ)·(−ln(1 − t)). Using ∫₀¹ −ln(1 − t) dt = 1 (the mean of Exp(1)): W₁ = **|1/λ − 1/μ|**, the difference of the means.

### 7.4 Code

```python
import numpy as np

def wp_1d_equal(x, y, p=1):
    """Exact W_p between two equal-size, equally weighted 1D samples."""
    x, y = np.sort(x), np.sort(y)
    return np.mean(np.abs(x - y) ** p) ** (1 / p)

def w1_1d_weighted(x, y, a, b):
    """Exact W_1 for weighted 1D points, via the area between the CDFs."""
    pts = np.concatenate([x, y])
    w = np.concatenate([a, -np.asarray(b)])      # +mass for P, -mass for Q
    order = np.argsort(pts)
    gaps = np.diff(pts[order])                    # widths of the intervals
    cdf_diff = np.cumsum(w[order])[:-1]           # F - G on each interval
    return np.sum(np.abs(cdf_diff) * gaps)

print(wp_1d_equal([6, 1, 3], [9, 2, 2]))                     # 1.6667
print(w1_1d_weighted(np.array([0., 2.]), np.array([1., 3.]),
                     np.array([.5, .5]), np.array([.25, .75])))  # 1.5
```

In practice, use `scipy.stats.wasserstein_distance(u_values, v_values, u_weights, v_weights)`. Its first two arguments are **positions**, not histograms: for two histograms, pass the bin centres as positions and the counts as weights.

### 7.5 Three ways to compare two CDFs: KS, EMD and Cramér

You may already know the **Kolmogorov–Smirnov statistic** from a statistics course. It is the *largest* vertical gap between two CDFs; EMD is the *area* between them; a third option, the **Cramér distance**, is the root-mean-square gap:

| Name                          | Formula                              | Example 3.2 | Sensitive to                                      |
|-------------------------------|--------------------------------------|-------------|---------------------------------------------------|
| Kolmogorov–Smirnov (KS)       | sup over x of \|F(x) − G(x)\|          | 0.75        | the single worst location; blind to how wide the gap is |
| EMD = W₁                      | ∫ \|F(x) − G(x)\| dx                  | 1.5         | gap × width: how much mass must move how far       |
| Cramér distance               | (∫ (F(x) − G(x))² dx)^{1/2}          | ≈ 0.935     | like EMD, but large gaps count more, small ones less |

(Example 3.2: the gaps are 0.5, 0.25, 0.75 on three unit intervals, so KS = 0.75, EMD = 0.5 + 0.25 + 0.75 = 1.5 and Cramér = √(0.25 + 0.0625 + 0.5625) ≈ 0.935.) KS and Cramér have units of probability; only EMD has the units of x. When a paper says "EMD loss between CDFs" check which of the three it actually computes: the NIMA image-quality model (Section 12.3), for example, uses the Cramér form.

![Figure 5: KS versus EMD for Example 3.2](figures/fig5_ks_vs_emd.png)

*Figure 5. |F − G| for Example 3.2. KS reads off the highest point (dashed line, 0.75); EMD is the shaded area (1.5).*

### 7.6 Beyond the line: angles and other circular data

For data on a circle (angles, hues, times of day) there is no leftmost point, so "sort and match" must be adapted. Example: all mass at 0.05 and all mass at 0.95 on a circle of circumference 1 have EMD 0.9 on the line but only **0.1** on the circle, the short way round. POT computes the circular version with `ot.wasserstein_circle`.

### Check yourself (Section 7)

1. Compute W₁ between Uniform\[0, 1\] and δ₀.₅ with the CDF formula.
2. Why doesn't "sort and match" work in two dimensions?
3. P has 1000 samples and Q has 1500. Can you compute W₁ exactly in 1D?
4. For P = δ₀ and Q = δ_θ, compute KS and EMD as functions of θ. Which one would you use as a training loss?

**Answers.** (1) F(x) = x on \[0, 1\], and G jumps from 0 to 1 at 0.5. ∫₀^0.5 x dx + ∫\_0.5^1 (1 − x) dx = 1/8 + 1/8 = **1/4**. (2) Points in the plane cannot be sorted in a way that respects distance, so there is no natural "smallest to smallest". In 2D and higher you need the LP of Section 4, or the slicing trick of Section 11. (3) Yes: give each sample of P weight 1/1000 and each sample of Q weight 1/1500 and use the CDF formula; `scipy.stats.wasserstein_distance` does this automatically. (4) KS = 1 for every θ ≠ 0 (the CDFs differ by 1 between 0 and θ), while EMD = |θ|. KS behaves like TV in Section 2.3 and gives no gradient; EMD does.

## 8. Gaussians, and why FID is a Wasserstein distance

Between two Gaussians, W₂² is the squared difference of the means plus the squared difference of the standard deviations (coordinate by coordinate when coordinates are independent). The Fréchet Inception Distance (FID), the standard score for image generators, is the general version of this formula.

### 8.1 One dimension

**Theorem.** For X with mean m₁ and standard deviation σ₁, and Y with mean m₂ and standard deviation σ₂ (any distributions), every coupling satisfies

$$
\mathbb{E}(X-Y)^2 \;=\; (m_1-m_2)^2 + \sigma_1^2 + \sigma_2^2 - 2\,\mathrm{Cov}(X,Y) \;\ge\; (m_1-m_2)^2 + (\sigma_1-\sigma_2)^2 .
$$

For two Gaussians, equality is reached, so W₂² = (m₁ − m₂)² + (σ₁ − σ₂)².

**Proof.** The equality is the expansion of E\[(X − m₁) − (Y − m₂) + (m₁ − m₂)\]², using E(X − m₁) = E(Y − m₂) = 0. The inequality holds because a correlation never exceeds 1, so Cov(X, Y) ≤ σ₁σ₂, and σ₁² + σ₂² − 2σ₁σ₂ = (σ₁ − σ₂)². For Gaussians, the coupling Y = m₂ + (σ₂/σ₁)(X − m₁) turns X ~ N(m₁, σ₁²) into exactly N(m₂, σ₂²) and has correlation 1, so it reaches the bound. (It is the quantile matching of Section 7.) ∎

**Common mistake.** W₁ between two Gaussians is **not** |m₁ − m₂| unless σ₁ = σ₂. With the same quantile matching, W₁ is the average of |(m₁ − m₂) + (σ₁ − σ₂)Z| with Z ~ N(0, 1), which is larger.

**Example.** N(0, 1) versus N(3, 4): the standard deviations are 1 and 2, so W₂² = 9 + 1 = 10 and W₂ = √10 ≈ 3.16.

### 8.2 Several dimensions with independent coordinates

If P = N(m₁, diag(σ₁₁², …, σ₁d²)) and Q = N(m₂, diag(σ₂₁², …, σ₂d²)), with independent coordinates, then

$$
W_2^2(P,Q) = \|m_1-m_2\|^2 + \sum_{k=1}^{d} (\sigma_{1k}-\sigma_{2k})^2 .
$$

**Proof.** For any coupling, E‖X − Y‖² = Σₖ E(Xₖ − Yₖ)², and each term is at least the 1D bound of 8.1 for coordinate k, since (Xₖ, Yₖ) is a coupling of the k-th coordinates. Applying the 1D matching to each coordinate separately produces a Y whose coordinates are independent Gaussians with the right means and variances, that is Y ~ Q, and it reaches every bound at once. ∎

**Example.** m₁ = (0, 0) with standard deviations (1, 2); m₂ = (1, 1) with standard deviations (2, 1). W₂² = (1 + 1) + ((1 − 2)² + (2 − 1)²) = 4, so W₂ = 2.

### 8.3 The general formula and FID

For Gaussians with full covariance matrices Σ₁ and Σ₂ (correlated coordinates), the formula is (stated without proof)

$$
W_2^2 = \|m_1-m_2\|^2 + \operatorname{tr}\!\Big(\Sigma_1 + \Sigma_2 - 2\big(\Sigma_2^{1/2}\Sigma_1\Sigma_2^{1/2}\big)^{1/2}\Big),
$$

where tr is the trace (the sum of the diagonal entries) and S^{1/2} is a matrix square root: the symmetric matrix whose square is S, computed with `scipy.linalg.sqrtm`. When both covariances are diagonal it reduces to the formula of 8.2.

**FID.** The Fréchet Inception Distance (Heusel et al., 2017) passes real and generated images through a pretrained image network (Inception-v3), computes the mean and covariance of the 2048-dimensional features of each set, and reports exactly this W₂² between the two fitted Gaussians ("Fréchet distance" is another name for W₂). Lower is better. Things to know: FID needs many thousands of images to be reliable and is biased for small sets; it depends on the chosen network; and it only sees means and covariances of the features. Recent papers therefore also report the same Fréchet distance computed in other feature spaces (for example DINOv2 features) or kernel-based alternatives such as CMMD.

### Check yourself (Section 8)

1. Compute W₂ between N(2, 9) and N(−1, 1).
2. Two 3D Gaussians share the same covariance and their means differ by (1, 2, 2). What is W₂?
3. Two 1D distributions both have mean 0 and variance 1. Must their W₂ be 0?

**Answers.** (1) Means differ by 3; standard deviations are 3 and 1. W₂² = 9 + 4 = 13, W₂ = √13 ≈ 3.61. (2) Only the means differ, so W₂ = ‖(1, 2, 2)‖ = 3 (a translation, Section 3.3). (3) No. Uniform\[−√3, √3\] and N(0, 1) both have mean 0 and variance 1, but their quantile functions differ, so W₂ \> 0. For two Gaussians it would be 0.

## 9. The critic view: EMD as a best scoring function

EMD can also be computed as a **maximisation over scoring functions** f whose slope is at most 1: W₁(P, Q) is the largest possible gap E_P f(X) − E_Q f(Y). This is the Kantorovich–Rubinstein duality, and it is what lets a neural network estimate EMD in a Wasserstein GAN.

### 9.1 Lipschitz functions: functions with bounded slope

A function f is **K-Lipschitz** if |f(x) − f(y)| ≤ K·‖x − y‖ for all x and y: its output never changes faster than K times the change of its input. For a differentiable function of one variable, the best K is the largest value of |f′|.

- |x|, ReLU(x) and sin(x) are 1-Lipschitz; 3x is 3-Lipschitz.
- x² is not Lipschitz on the whole line, because its slope 2x is unbounded.
- Composing functions multiplies their constants: if f is K₁-Lipschitz and g is K₂-Lipschitz, f(g(x)) is K₁K₂-Lipschitz. So an MLP with ReLU activations has a Lipschitz constant at most the product of what its layers allow.

### 9.2 The statement

**Kantorovich–Rubinstein duality.**

$$
W_1(P,Q) \;=\; \max_{f \text{ 1-Lipschitz}} \; \Big( \mathbb{E}_{X\sim P}\big[f(X)\big] - \mathbb{E}_{Y\sim Q}\big[f(Y)\big] \Big).
$$

Think of f as a **critic** that scores points: high scores where P has more mass, low scores where Q has more. Without a limit on its slope the critic could make the gap as large as it likes; with slope at most 1, the best gap it can achieve is exactly the EMD.

**Proof that the gap never exceeds W₁ (any dimension).** Take any 1-Lipschitz f and any coupling (X, Y) of P and Q. Then

$$
\mathbb{E}_P f - \mathbb{E}_Q f = \mathbb{E}\big[f(X)-f(Y)\big] \le \mathbb{E}\,\big|f(X)-f(Y)\big| \le \mathbb{E}\,\|X-Y\| .
$$

This holds for every coupling, in particular the optimal one, so every critic's gap is at most W₁. ∎

**Proof that the best critic reaches W₁ (in 1D).** Suppose both distributions live in an interval \[L, U\] and f is differentiable. Writing f(x) = f(L) + ∫\_L^x f′(s) ds and taking expectations gives E f(X) = f(L) + ∫\_L^U f′(s) Pr(X \> s) ds. Since Pr(X \> s) = 1 − F(s), subtracting the same formula for Y gives

$$
\mathbb{E}_P f - \mathbb{E}_Q f = \int_L^U f'(s)\,\big(G(s) - F(s)\big)\, ds .
$$

With |f′| ≤ 1, this is largest when f′(s) = +1 wherever G(s) \> F(s) and f′(s) = −1 wherever F(s) \> G(s). Then the integrand is |F(s) − G(s)|, and the gap equals ∫ |F − G| ds = W₁ by Section 7. ∎ (In higher dimensions the equality also holds; stated without proof. It is the continuous version of the dual LP of Section 5.2: for a distance cost the optimal potentials can be chosen with g = −f, the constraint fᵢ + gⱼ ≤ Cᵢⱼ becomes f(x) − f(y) ≤ ‖x − y‖, that is "f is 1-Lipschitz", and the dual objective Σaᵢfᵢ + Σbⱼgⱼ becomes E_P f − E_Q f. So the best critic *is* the optimal dual potential f. The notebook builds the critic from the potentials returned by the solver on a random 2D problem and checks that its gap equals W₁ to six decimals.)

### 9.3 Worked examples

**Example 9.A (Example 3.2 again).** P = ½δ₀ + ½δ₂ and Q = ¼δ₁ + ¾δ₃. From Example 7.A, F \> G on \[0, 3), so choose f′ = −1 there: f(x) = −x. Then E_P f = −(0 + 2)/2 = −1, E_Q f = −(0.25·1 + 0.75·3) = −2.5, and the gap is −1 − (−2.5) = **1.5** = W₁. The critic gives higher scores on the left, where P has more mass than Q.

**Example 9.B (two single points).** P = δ₀ and Q = δ_θ with θ \> 0. Take f(x) = −x: the gap is 0 − (−θ) = θ = W₁. A critic with slope at most 1 can separate two points by at most their distance, so its value grows smoothly with θ. Compare JS, which jumps to log 2 and stays there (Section 2.3).

**Example 9.C (where the critic is free).** P = ½δ₀ + ½δ₄ and Q = ½δ₁ + ½δ₂. Here F \> G on \[0, 1), F = G on \[1, 2) and F \< G on \[2, 4), so the best critic must fall at slope 1, may do anything with slope at most 1, then must rise at slope 1. Every f(x) = |x − c| with 1 ≤ c ≤ 2 works and reaches the gap W₁ = 1.5 (Exercise 15.10 does the arithmetic).

![Figure 6: three optimal critics for Example 9.C](figures/fig6_critic.png)

*Figure 6. Left: the CDFs of Example 9.C and the area between them. Right: three different 1-Lipschitz critics, all reaching the same gap 1.5. The critic is pinned down only where F ≠ G.*

### 9.4 Two remarks you will need

1. **Adding a constant does nothing.** f and f + c give the same gap, so the best critic is never unique. Different critics can also agree on the data and differ elsewhere (Exercise 15.10).
2. **Scaling the slope scales the answer.** If f is only required to be K-Lipschitz, the maximum gap becomes K·W₁. For training a generator this is harmless: the loss is rescaled but its minimiser does not move.

Only W₁ has this simple single-critic form. For W₂ the corresponding "dual" problem needs two functions and is not used in this tutorial.

### Check yourself (Section 9)

1. Use the critic f(x) = x to show that W₁(P, Q) ≥ |mean(P) − mean(Q)| in 1D.
2. Why can't f(x) = x² be used as a critic on the whole line?
3. A critic achieves a gap of 2.7 and is known to be 1-Lipschitz. What do you know about W₁?

**Answers.** (1) Both f(x) = x and f(x) = −x are 1-Lipschitz; their gaps are mean(P) − mean(Q) and its negative, and both are ≤ W₁. (2) Its slope is unbounded, so it is not Lipschitz. (3) W₁ ≥ 2.7: any 1-Lipschitz critic gives a lower bound.

## 10. Wasserstein GANs: EMD as a training loss

A Wasserstein GAN trains a generator network to make its samples close to real data in EMD, using a second network, the critic, as the scoring function of Section 9; the critic's slope is kept near 1 by a gradient penalty.

### 10.1 Generative models and GANs in one page

A **generative model** learns to produce new samples that look like the training data (images, sounds, sensor traces). A common design feeds random noise z ~ N(0, I) into an MLP or CNN g_θ, the **generator**, whose output g_θ(z) is a fake sample. The fake samples have some distribution P_θ (θ = the generator's weights), and training should make P_θ close to the real data distribution P_r.

The original **GAN** (Goodfellow et al., 2014) trains a second network, the **discriminator** D, as an ordinary binary classifier: output near 1 for real samples and near 0 for fakes. The generator is trained to fool it. The two networks are updated in turn, a "min-max game":

$$
\min_\theta \max_D \; \mathbb{E}_{x\sim P_r}\big[\log D(x)\big] + \mathbb{E}_{z}\big[\log\big(1-D(g_\theta(z))\big)\big].
$$

With a perfect discriminator this objective equals 2·JS(P_r, P_θ) − log 4 (stated without proof), so the generator is effectively minimising JS. Section 2.3 showed the problem: when real and fake samples do not overlap, JS is stuck at log 2 and gives almost no gradient. In practice GANs use a modified "non-saturating" generator loss, −log D(g_θ(z)), which helps early training but remains unstable and prone to **mode collapse** (the generator produces only a few kinds of samples).

### 10.2 The Wasserstein GAN

Arjovsky, Chintala and Bottou (2017) replaced JS by W₁, using the critic form of Section 9. The critic f_w is an MLP with a **linear output** (no sigmoid), and training alternates between two losses estimated on mini-batches:

| Network       | Loss to minimise                | Intuition                                        |
|---------------|---------------------------------|--------------------------------------------------|
| Critic f_w    | mean f_w(fake) − mean f_w(real) | Score real samples high and fakes low            |
| Generator g_θ | −mean f_w(g_θ(z))               | Move fakes toward regions the critic scores high |

If the critic is the best 1-Lipschitz function, minus the critic loss equals W₁(P_r, P_θ), and the generator's gradient step is a step downhill on W₁. Property 3 of Section 2.4 is what makes this meaningful: W₁(P_r, P_θ) is a continuous, almost-everywhere differentiable function of the generator's weights, which JS is not. The critic must be kept (approximately) Lipschitz, otherwise it can blow up the gap. The original paper did this by **weight clipping**: after every critic update, every weight is clipped to \[−c, c\] with c = 0.01. Default hyperparameters were 5 critic updates per generator update, the RMSProp optimiser (gradient descent with per-weight step sizes) and learning rate 5×10⁻⁵.

Clipping is crude: it limits the critic's slope to some unknown, often tiny constant (Exercise 15.14 finds a bound of about 0.023 for a small MLP), wastes the critic's capacity, and is sensitive to c.

### 10.3 WGAN-GP: the gradient penalty

Gulrajani et al. (2017) replaced clipping with a penalty that pushes the critic's gradient norm toward 1.

**Why norm 1?** By Section 9.2, the best critic achieves f(x) − f(y) = ‖x − y‖ for real points x and fake points y that the optimal plan pairs together (on average the gap equals the average distance, and it can never exceed it). A function with slope at most 1 that climbs by exactly ‖x − y‖ between x and y must climb at full slope 1 along the whole segment between them. So the best critic has gradient norm exactly 1 on segments joining paired real and fake points.

**The penalty.** Pick random points x̂ = εx + (1 − ε)x̃ on segments between a real sample x and a fake sample x̃ (ε uniform in \[0, 1\]), and add to the critic loss

$$
\lambda\; \mathbb{E}_{\hat x}\Big[\big(\|\nabla_{\hat x} f_w(\hat x)\| - 1\big)^2\Big], \qquad \lambda = 10 .
$$

Default settings: λ = 10, 5 critic updates per generator update, the Adam optimiser with learning rate 10⁻⁴ and betas (0, 0.9). Random real–fake pairs stand in for the unknown optimal pairing.

```python
import torch

def gradient_penalty(critic, real, fake):
    eps = torch.rand(real.size(0), *([1] * (real.dim() - 1)), device=real.device)
    x_hat = (eps * real + (1 - eps) * fake).requires_grad_(True)
    scores = critic(x_hat)
    # gradient of the scores with respect to the INPUT points; create_graph=True
    # keeps it differentiable so the penalty can itself be backpropagated
    grads = torch.autograd.grad(scores.sum(), x_hat, create_graph=True)[0]
    return ((grads.flatten(1).norm(2, dim=1) - 1) ** 2).mean()

# critic step: .detach() stops gradients from flowing into the generator
loss_c = critic(fake.detach()).mean() - critic(real).mean() \
         + 10.0 * gradient_penalty(critic, real, fake.detach())
# generator step
loss_g = -critic(generator(z)).mean()
```

**Reading the PyTorch code (if you have not used autograd before).** `requires_grad_(True)` tells PyTorch to track every operation applied to `x_hat`. `torch.autograd.grad(scores.sum(), x_hat)` returns ∂(sum of scores)/∂x_hat, which is the input-gradient ∇f_w(x̂) for every point in the batch at once (summing is harmless because each score depends only on its own point). `create_graph=True` records that computation too, so that the penalty, which depends on the gradient, can itself be differentiated when `loss_c.backward()` runs. `.detach()` cuts a tensor off from the computation that produced it, so no gradient flows back through it. `.flatten(1).norm(2, dim=1)` is the Euclidean norm per sample.

**Two practical rules.** (1) Do not use batch normalisation in the critic: it normalises each sample using statistics of the whole mini-batch, which makes one sample's score depend on the others and breaks the per-sample penalty. Use layer normalisation (which uses each sample's own statistics) or none. (2) The penalty needs a gradient of a gradient ("double backpropagation"), which `create_graph=True` provides.

**A variant.** The constraint is really "slope at most 1", so Petzka et al. (2018) penalise only slopes above 1: λ·E\[max(0, ‖∇f‖ − 1)²\] (WGAN-LP). Both forms are in use.

### 10.4 Monitoring, and honest caveats

- **A useful training curve.** Minus the critic loss (without the penalty), mean f_w(real) − mean f_w(fake), estimates W₁ between real and generated data and usually falls as samples improve, unlike the original GAN loss, which carries no such meaning.
- **Not an accurate measurement.** The companion notebook trains a WGAN-GP on a 2D toy problem (eight small Gaussians on a circle) and, every 500 iterations, compares the critic's estimate with the *exact* W₁ between 1000 real and 1000 generated samples:

| Iteration | Critic estimate of W₁ | Exact sample W₁ |
|-----------|-----------------------|-----------------|
| 0         | 0.03                  | 1.97            |
| 500       | 0.35                  | 1.54            |
| 1000      | 0.29                  | 0.42            |
| 2000      | 0.28                  | 0.34            |
| 3000      | 0.24                  | 0.27            |

  The noise floor (exact W₁ between two sets of 1000 *real* samples) is 0.10, so the generator is not finished at iteration 3000. Two effects pull the critic's value in opposite directions. **Downward:** the critic is a finite network trained for only five steps between generator updates, so it is never the best 1-Lipschitz function, and by Section 9.2 any 1-Lipschitz critic gives a lower bound; when the generator is changing quickly (early training) the critic lags far behind, by a factor of four at iteration 500. **Upward:** the penalty is soft, so the critic can exceed slope 1 and overshoot (Exercise 15.18 quantifies this in a toy: by a fraction θ/(4λ) of W₁). In this run, as in most, the downward effect dominated throughout. The curve is useful because it moves in the right direction and flattens when training stalls, not because its value is W₁.

![Figure 7: real and generated samples after 3000 iterations](figures/fig7_wgan.png)

*Figure 7. The toy WGAN-GP after 3000 iterations: all eight modes are covered, but the generated points are still more spread out than the real ones, consistent with W₁ = 0.27 against a floor of 0.10.*
- **Other ways to limit the slope.** Spectral normalisation (Miyato et al., 2018) divides each weight matrix by its largest stretching factor so that every layer is 1-Lipschitz.
- **Context in 2026.** Diffusion and flow-matching models (Section 12.6) now dominate high-quality image generation. Adversarial losses, often with gradient penalties descended from WGAN-GP, remain common in fast one-step generators, super-resolution, neural audio vocoders and image tokenisers. The WGAN ideas (critic, Lipschitz constraint, gradient penalty) keep reappearing.

### Check yourself (Section 10)

1. Why does the WGAN critic have no sigmoid at its output?
2. Why are the fake samples detached in the critic step?
3. You accidentally train a critic that is 5-Lipschitz. What happens?
4. Why is the penalty evaluated at points between real and fake samples?

**Answers.** (1) It estimates the unbounded gap E_P f − E_Q f; a sigmoid would squash it into (0, 1) and bring back saturation. (2) Only the critic should be updated in the critic step; detaching stops gradients from reaching the generator. (3) The gap becomes about 5·W₁: the loss is rescaled, but the generator's target is unchanged (only the effective learning rate changes). (4) The best critic has slope exactly 1 on segments between paired real and fake points, so that is where the constraint matters.

## 11. Fast approximations: Sinkhorn and sliced Wasserstein

Exact EMD is too slow for large data sets and awkward to put inside a neural network. Two approximations dominate practice: **Sinkhorn**, which blurs the plan slightly and then solves the problem by repeatedly rescaling rows and columns, and **sliced Wasserstein**, which averages cheap 1D EMDs over random directions.

### 11.1 Sinkhorn: add a little blur

Define the **entropy** of a plan as H(γ) = −Σᵢⱼ γᵢⱼ(log γᵢⱼ − 1). It is large when mass is spread over many routes and small when it is concentrated. For a small number ε \> 0, entropic OT (Cuturi, 2013) solves

$$
\min_{\gamma \text{ valid plan}} \; \sum_{i,j}\gamma_{ij}C_{ij} \;-\; \varepsilon\, H(\gamma).
$$

The entropy term rewards spreading mass a little. Small ε gives a plan close to the exact one; large ε gives a blurry plan, and as ε → ∞ the plan becomes the independent plan aᵢbⱼ of Section 4.3.

**The shape of the solution.** Using Lagrange multipliers (stated without proof), the solution always has the form

$$
\gamma_{ij} = u_i\,K_{ij}\,v_j, \qquad K_{ij} = e^{-C_{ij}/\varepsilon},
$$

for some positive numbers u₁,…,uₙ and v₁,…,vₘ. K is a fixed matrix: cheap routes get large entries, expensive routes tiny ones. We only need to find u and v so that the rows sum to a and the columns sum to b.

**Connection to Section 5.** Write uᵢ = e^{fᵢ/ε} and vⱼ = e^{gⱼ/ε}. Then γᵢⱼ = exp((fᵢ + gⱼ − Cᵢⱼ)/ε): mass is large exactly where fᵢ + gⱼ is close to Cᵢⱼ, and tiny where fᵢ + gⱼ is far below Cᵢⱼ. So f and g are a smoothed version of the dual potentials of Section 5.2, and as ε → 0 they converge to them (stated without proof). The letters are chosen on purpose: u, v are multiplicative scalings, f, g are additive potentials; the log-domain solver of 11.2 works with f and g directly.

**The Sinkhorn algorithm.** Start with v = (1, …, 1) and alternate:

1. Rescale rows: uᵢ = aᵢ / Σⱼ Kᵢⱼvⱼ. Now every row sums exactly to aᵢ.
2. Rescale columns: vⱼ = bⱼ / Σᵢ Kᵢⱼuᵢ. Now every column sums exactly to bⱼ, and the rows are slightly off again.

Repeat until the row sums are within a tolerance of a. Each step is a matrix–vector product, cost O(nm), which is fast on GPUs and differentiable, so it can sit inside a neural network. The number of iterations grows as ε shrinks: in the notebook, the warehouse problem needs 14 iterations at ε = 3 and about 120 at ε = 0.03 for the same tolerance; in the worst case the count grows roughly in proportion to 1/ε (stated without proof). Accuracy costs both blur and time.

```python
import numpy as np

def sinkhorn(a, b, C, eps, n_iter=1000, tol=1e-9):
    K = np.exp(-C / eps)
    v = np.ones_like(b)
    for _ in range(n_iter):
        u = a / (K @ v)
        v = b / (K.T @ u)
        if np.abs(u * (K @ v) - a).sum() < tol:   # row-sum error
            break
    G = u[:, None] * K * v[None, :]
    return G, np.sum(G * C)          # the plan and its transport cost
```

**Worked example (2 × 2, exact answer 0).** a = b = (½, ½) and C = \[\[0, 1\], \[1, 0\]\]: the exact plan keeps everything in place, at cost 0. Here K = \[\[1, e^(−1/ε)\], \[e^(−1/ε), 1\]\]. By symmetry u = v = (c, c), so γ = c²K. Total mass 1 gives c² = 1/(2(1 + e^(−1/ε))), and the transport cost is

$$
\gamma_{12} + \gamma_{21} = \frac{1}{e^{1/\varepsilon} + 1}.
$$

For ε = 1 this is 1/(e + 1) ≈ **0.269** instead of 0; for ε = 0.5 it is ≈ 0.119; for ε = 0.1 it is ≈ 0.000045. The error shrinks very fast as ε → 0, but it is never exactly zero: entropic OT **blurs** the plan.

**Worked example (the warehouses of 4.4, exact answer 2.5).**

| ε   | Transport cost of the Sinkhorn plan          |
|-----|----------------------------------------------|
| 10  | 3.597 (close to the independent plan's 3.84) |
| 3   | 3.117                                        |
| 1   | 2.578                                        |
| 0.3 | 2.501                                        |
| 0.1 | 2.500                                        |

![Figure 8: exact and Sinkhorn transport plans for increasing ε](figures/fig8_sinkhorn_blur.png)

*Figure 8. Plans between two 1D distributions (each pixel is a route; bright = much mass). The exact plan is a thin curve; as ε grows, Sinkhorn spreads the mass over more routes.*

### 11.2 Sinkhorn in practice: three pitfalls

1. **Underflow.** For small ε, exp(−C/ε) can be smaller than the smallest number the computer can store and becomes exactly 0. In 64-bit floats e^{−x} loses precision below about x ≈ 708 and is exactly 0 beyond x ≈ 745; in 32-bit floats (PyTorch's default) it loses precision already beyond x ≈ 87 and is 0 beyond x ≈ 103. Then the divisions produce infinity or NaN, or, worse, a silently wrong number. In the notebook's test (costs up to about 62, ε = 0.1, so C/ε up to 620), POT's default solver in float32 returned 0.0003 instead of about 8.6. The fix is the **log-domain** version (`method="sinkhorn_log"` in POT), which iterates on the potentials f = ε log u and g = ε log v with the numerically safe `logsumexp` function; the two update formulas are fᵢ = ε log aᵢ − ε logsumexpⱼ((gⱼ − Cᵢⱼ)/ε) and the same with the roles swapped. Exercise 15.23 asks you to implement it.
2. **Choose ε relative to the costs.** Rescale C (for example divide by its maximum) so that ε has a clear meaning, then try values like 0.01 to 0.1. Smaller ε means more accuracy and more iterations.
3. **It is biased.** The blurred plan between P and itself is not "stay in place", so the regularised value for P versus P is not 0. The **Sinkhorn divergence** subtracts the self-terms, S_ε(P, Q) = OT_ε(P, Q) − ½OT_ε(P, P) − ½OT_ε(Q, Q), and is 0 exactly when P = Q for the usual costs ‖x − y‖ and ‖x − y‖² (Genevay et al., 2018; Feydy et al., 2019). The GeomLoss library computes it on GPU for large point clouds.

Sinkhorn layers appear inside networks, for example to compute soft keypoint matches in the SuperGlue image matcher (2020) and to make balanced cluster assignments in SwAV-style self-supervised learning.

### 11.3 Sliced Wasserstein: many cheap 1D problems

In 1D, EMD is just sorting (Section 7). The **sliced Wasserstein distance** exploits this: project both point clouds onto a random direction θ (a unit vector), compute the 1D Wasserstein distance of the projected values by sorting, and average over many random directions:

$$
SW_p^p(P,Q) = \text{average over random unit vectors } \theta \text{ of } W_p^p\big(\text{projections } \langle\theta,X\rangle,\; \langle\theta,Y\rangle\big).
$$

```python
def sliced_wasserstein(X, Y, L=200, p=2, seed=0):
    """X, Y: (n, d) arrays with the same n and equal weights."""
    rng = np.random.default_rng(seed)
    theta = rng.standard_normal((L, X.shape[1]))
    theta /= np.linalg.norm(theta, axis=1, keepdims=True)   # L random unit directions
    xp = np.sort(X @ theta.T, axis=0)                         # sorted projections
    yp = np.sort(Y @ theta.T, axis=0)
    return np.mean(np.abs(xp - yp) ** p) ** (1 / p)
```

Normalising a vector of independent N(0, 1) numbers gives a direction that is equally likely to point anywhere. The cost is O(L·n log n) for L directions, far cheaper than exact OT, and the same code in PyTorch is differentiable.

**SW never exceeds W.** Projecting onto a unit vector can only shrink distances: |⟨θ, x − y⟩| ≤ ‖x − y‖. So any plan for P and Q gives a plan for the projections that is no more expensive, and averaging keeps the inequality: SW_p ≤ W_p. It is also a true distance between distributions (stated without proof).

![Figure 9: one random slice of two 2D clouds](figures/fig9_sliced.png)

*Figure 9. One slice: two 2D clouds and a random unit direction θ (left); the two projected samples ⟨θ, X⟩ and ⟨θ, Y⟩ on that line (right), between which the 1D problem is solved by sorting. Sliced Wasserstein averages this over many θ.*

**But it can be much smaller in high dimensions.** For a translation by v in d dimensions, W₂ = ‖v‖ while SW₂ = ‖v‖/√d. Proof: the projections of δ₀ and δ_v are δ₀ and δ_{⟨θ,v⟩}, so the 1D W₂² is ⟨θ, v⟩², and its average over uniformly random unit vectors θ is ‖v‖²/d, because by symmetry each of the d coordinates of θ contributes the same share of E‖θ‖² = 1. (In 2D with p = 1, Exercise 15.12 computes SW₁ = (2/π)‖v‖ ≈ 0.64‖v‖ by the same method.) Most random directions are nearly perpendicular to the direction in which the distributions differ. Variants such as max-sliced Wasserstein (use the most informative direction) address this.

### Check yourself (Section 11)

1. Why is every entry of the Sinkhorn plan positive?
2. Your Sinkhorn code returns NaN for ε = 0.001 and costs around 100. Why, and what are two fixes?
3. Two image data sets give SW = 0.01 and EMD = 3.2. Is that a contradiction?

**Answers.** (1) γᵢⱼ = uᵢKᵢⱼvⱼ with Kᵢⱼ = e^(−Cᵢⱼ/ε) \> 0 and positive u, v. (2) e^(−100/0.001) underflows to 0, so the division a/(Kv) blows up. Use the log-domain solver, or rescale the costs (or increase ε). (3) No: SW ≤ W and can be far smaller in high dimensions; the two numbers are on different scales.

## 12. Applications

EMD appears in three roles: as a **loss** between distributions (WGANs, ordinal labels, point clouds), as a **pairing rule** that decides which samples go together (domain adaptation, flow matching), and as an **evaluation score** (FID, drift monitoring). For each paper you read, ask: what is being compared, with which cost, and with which solver?

### 12.1 Images and histograms

- **Image retrieval.** Rubner, Tomasi and Guibas (2000) compared colour and texture histograms of images with EMD to find similar pictures; this is where the name comes from.
- **Histogram matching is 1D optimal transport.** To make an image's grey-level distribution (CDF F) match a target distribution (CDF G), map every grey level x to G⁻¹(F(x)). This is exactly the sorted matching of Section 7. Histogram equalisation is the special case where G is uniform.
- **Colour transfer.** Transporting the 3D colour distribution of one photo onto another (exactly on a subsample, with Sinkhorn, or slice by slice) recolours it in the style of the other.

### 12.2 Drift monitoring

To detect when sensor readings or model inputs change over time, compute the 1D EMD (`scipy.stats.wasserstein_distance`) between a reference window and the current window, feature by feature. Divide by the feature's typical spread (for example its standard deviation in the reference window) so features are comparable, compute the same score between two reference windows to get a noise floor, and raise an alert when the score is clearly above it. Because EMD has the units of the feature, an alert such as "temperature distribution shifted by 1.8 °C" is easy to explain.

### 12.3 Ordered class labels

When classes are ordered (ratings 1–5, age groups, severity levels), cross-entropy treats "predicted 4, true 5" as badly as "predicted 1, true 5". The EMD between the predicted distribution and the one-hot target, computed on the class index with the CDF formula, penalises far misses more. Example (Exercise 15.21): true class 5; prediction A = (0.1, 0, 0, 0.8, 0.1) and prediction B = (0.8, 0, 0, 0.1, 0.1) have the same cross-entropy, −log 0.1 ≈ 2.30, but EMD 1.2 for A and 3.3 for B. The image-quality model NIMA (Talebi and Milanfar, 2018) trains with a closely related loss that it calls "EMD loss" but which is the root-mean-square of the CDF differences, the Cramér form of Section 7.5, not EMD itself. This is a good example of why 7.5 matters when reading papers.

### 12.4 3D point clouds: EMD versus Chamfer distance

A 3D shape from a LiDAR or depth camera is an unordered set of points, and networks that predict shapes need a loss between two point sets X and Y. Fan, Su and Guibas (2017) popularised two:

$$
d_{\text{EMD}}(X,Y) = \min_{\text{one-to-one matchings } \sigma} \frac{1}{|X|}\sum_{x\in X}\|x-\sigma(x)\|, \qquad d_{\text{CD}}(X,Y) = \frac{1}{|X|}\sum_{x\in X}\min_{y\in Y}\|x-y\|^2 + \frac{1}{|Y|}\sum_{y\in Y}\min_{x\in X}\|x-y\|^2 .
$$

d_EMD is W₁ between equal-size point sets (Section 5.3). The **Chamfer distance** d_CD only asks every point to have some nearby partner, so several points may share one partner.

**Worked example: Chamfer ignores density.** X = {(0,0), (0,0), (0,0), (1,0)}: three points at the origin, one at (1, 0). Y = {(0,0), (1,0), (1,0), (1,0)}. Every point has an exact copy in the other set, so d_CD = 0. EMD needs a one-to-one matching: only one point of X is at (1, 0) while three are needed there, so two points must travel distance 1, and d_EMD = 2/4 = **0.5**.

Exact EMD is too slow for clouds of thousands of points at every training step, so libraries use fast approximations (auction algorithms or Sinkhorn). Papers differ in details (squared distances, sums instead of averages), so check the exact definition in each paper.

### 12.5 Domain adaptation

**The problem.** A classifier is trained on labelled data from a **source** domain (for example synthetic images) and used on a **target** domain (real images) where no labels are available. Accuracy drops because the input distributions differ.

**Why EMD helps.** Theory (Redko, Habrard and Sebban, 2017; Shen et al., 2018; stated without proof) says roughly: if the classifier's loss changes smoothly (in a Lipschitz way) with the input features, then the target error is at most the source error plus a multiple of W₁ between the source and target feature distributions, plus a term that is small when one classifier can do well on both domains. So making W₁ small helps.

**Three method families.**

1. **Move the source data** (Courty et al., 2017). Solve OT between source and target samples. Move each source sample xᵢ to the average of the places its mass is sent, T(xᵢ) = (Σⱼ γᵢⱼ yⱼ)/aᵢ (the **barycentric map**), and train the classifier on the moved samples with their original labels. In the notebook's 2D example this raises target accuracy from 0.50 to 0.995.
2. **Match features and labels together** (DeepJDOT, Damodaran et al., 2018). On each mini-batch, solve OT with a cost that combines feature distance and label disagreement, then update the network with the plan fixed.
3. **Adversarial alignment** (WDGRL, Shen et al., 2018). A WGAN-style critic estimates W₁ between source and target features, and the feature network is trained to reduce it.

### 12.6 Flow matching: OT makes generation faster

**Flow matching in one paragraph.** Instead of producing a sample in one step like a GAN generator, a flow-matching model moves a noise sample gradually toward data. A network v_θ(t, x) (an MLP whose inputs are the current point x and a time t ∈ \[0, 1\]) outputs a **velocity**, and a sample follows dx/dt = v_θ(t, x) from noise at t = 0 to data at t = 1. In practice the path is computed with **Euler steps**, x ← x + Δt·v_θ(t, x); each step costs one network evaluation. Example: for dx/dt = −x from x = 1, the exact value at t = 1 is e^−1 ≈ 0.368, one Euler step gives 0, four give 0.316, and 100 give 0.366. Curved paths need many steps; a straight path at constant speed is exact in one.

**Training.** Pick a noise vector x₀ and a data point x₁, a random time t, the point xₜ = (1 − t)x₀ + t·x₁ on the straight line between them, and train the network to output that line's velocity:

$$
\text{loss} = \text{average of } \big\|\,v_\theta\big(t,\,(1-t)x_0 + t x_1\big) - (x_1 - x_0)\big\|^2 .
$$

**Where OT enters: which noise goes with which data point.** If x₀ and x₁ are paired at random, many straight lines cross. At a crossing the network sees conflicting targets and learns their average, so the flow it learns is curved and needs many steps. **OT-CFM** (Tong et al., 2024) and multisample flow matching (Pooladian et al., 2023) instead pair the noise and data within each mini-batch with an exact W₂ assignment (Section 5.3). Optimal pairs do not cross, so the learned flow is much straighter.

```python
import torch
from scipy.optimize import linear_sum_assignment

def ot_pair(x0, x1):
    """Reorder the batch so that (x0[i], x1[i]) is the optimal W2 pairing."""
    C = torch.cdist(x0, x1).pow(2).cpu().numpy()     # B x B squared distances
    rows, cols = linear_sum_assignment(C)
    return x0[rows], x1[cols]
```

![Figure 10: sampling paths with random pairs versus OT pairs](figures/fig10_cfm.png)

*Figure 10. Paths from noise (blue) to generated samples (orange) on a 2D toy problem. Left: random pairs, curved paths (average path length 1.67 times the straight-line distance). Right: OT pairs, nearly straight paths (1.006 times).*

**What the toy actually shows.** The notebook measures W₂ between 1000 generated and 1000 real points after 1, 2, 5 and 20 Euler steps. With OT pairs: 0.40, 0.41, 0.44, 0.44. With random pairs: 1.84, 0.85, 0.41, 0.41. The noise floor (W₂ between two sets of real samples) is 0.35. So OT pairing reaches the floor in **one** step where random pairing needs about **five**; with enough steps both end at the same quality. The gain is in speed (5× fewer network evaluations), not in final quality, and it comes from straighter paths.

**Caveats and the state of the art (2026).** The toy overstates the gain. For image-scale models, mini-batch OT helps much less: an optimal pairing inside a batch of a few hundred points is a poor approximation of the best pairing between the two full distributions (the sample-size issue of Section 6.5 again), and the Sinkhorn or assignment solve at every step is expensive for large batches. A 2026 line of work instead solves the transport problem between the noise distribution and the **whole** training set once in advance, then looks up each noise sample's partner during training (semidiscrete flow matching, Mousavi-Hosseini et al., ICLR 2026). When you read such a paper, ask which pairing is used and what it costs per training step.

### 12.7 Other uses

- **Text.** The Word Mover's Distance (Kusner et al., 2015) compares two documents as distributions of word vectors, with EMD.
- **Classification with a semantic cost.** Frogner et al. (NeurIPS 2015) trained image taggers with an EMD loss between the predicted label distribution and the true one, using a cost matrix that says how different two labels are (for example from word embeddings), so predicting "cat" for "kitten" is cheaper than predicting "truck". Section 13.4 explains how such a loss is differentiated.
- **Language models.** When a teacher and a student language model use different vocabularies, token-by-token KL cannot be computed; the Universal Logit Distillation loss (Boizard et al., TMLR 2025) sorts both probability vectors and compares them with an OT loss. It uses a cost of 1 between any two different ranks, so it is really the TV-like variant of Exercise 15.6 applied to sorted vectors, not a geometric EMD; read it with Section 14.2 in mind.
- **Reinforcement learning.** Distributional RL algorithms, which predict the whole distribution of future reward instead of its mean, are analysed with W₁, and one family (quantile regression DQN, Dabney et al., 2018) fits quantiles of that distribution, that is, the 1D quantile formula of Section 7. You need a reinforcement-learning course to go further.
- **Biology.** Waddington-OT (Schiebinger et al., 2019) uses a variant of OT to infer how cells develop between measurements taken on different days.

### 12.8 Which variant where

| Application                       | Quantity                       | Cost                         | Solver                            |
|-----------------------------------|--------------------------------|------------------------------|-----------------------------------|
| WGAN / WGAN-GP                    | W₁ (critic form)               | Distance                     | Neural critic + gradient penalty  |
| Flow matching (OT-CFM)            | W₂ pairing in each batch       | Squared distance             | Assignment                        |
| Domain adaptation                 | OT plan or W₁ between features | Squared distance or distance | Exact, Sinkhorn, or critic        |
| Point-cloud loss                  | W₁ with one-to-one matching    | Distance                     | Approximate (auction or Sinkhorn) |
| FID                               | W₂² between Gaussian fits      | Squared distance             | Closed form (Section 8)           |
| Histograms, drift, ordinal labels | W₁ in 1D                       | \|x − y\|                   | Sorting / CDF formula             |
| Large-scale cheap comparisons     | Sliced W                       | Distance                     | Random projections + sorting      |

### Check yourself (Section 12)

1. In OT-CFM, what is computed with optimal transport, and what does the network learn?
2. Give two different point sets with Chamfer distance 0 but positive EMD.
3. Why does a smaller number of Euler steps make a generator faster?

**Answers.** (1) OT pairs noise samples with data samples inside each mini-batch; the network learns the velocity field that follows the straight lines between those pairs. (2) X = {a, a, b} and Y = {a, b, b} for two different points a and b: Chamfer is 0, EMD is distance(a, b)/3. (3) Each step is one evaluation of the network, which is the expensive part; one step instead of 50 is a 50× speed-up.

## 13. Implementation guide in Python

Use SciPy for 1D problems and matchings, and the POT library (`pip install pot`) for everything else. Remember three traps: `ot.dist` uses **squared** distance unless told otherwise, `ot.wasserstein_1d` returns **W_pᵖ** (not W_p), and Sinkhorn in 32-bit floats needs the log-domain solver.

Every snippet was tested in November 2026 with POT 0.9.7.post1 and PyTorch 2.14.1 (CPU), on NumPy 2.4–2.5 and SciPy 1.17–1.18.

### 13.1 Which function does what

| Task                          | Function                                                            | Returns                            | Watch out for                                                  |
|-------------------------------|---------------------------------------------------------------------|------------------------------------|----------------------------------------------------------------|
| EMD in 1D                     | `scipy.stats.wasserstein_distance(u, v, u_weights, v_weights)`      | W₁                                 | Arguments are positions; histograms go in the weights          |
| W_p in 1D                     | `ot.wasserstein_1d(u, v, u_weights, v_weights, p=p)`                | **W_pᵖ**                           | Take the p-th root yourself                                    |
| Cost matrix                   | `ot.dist(X, Y, metric=...)`                                         | n × m matrix                       | **Default is 'sqeuclidean'**; use `metric='euclidean'` for EMD |
| Exact plan / exact value      | `ot.emd(a, b, M)` / `ot.emd2(a, b, M)`                              | plan / Σγᵢⱼ Mᵢⱼ                    | a and b must have the same sum                                 |
| Equal-size point sets         | `scipy.optimize.linear_sum_assignment(M)`                           | matched indices                    | Average M\[rows, cols\] to get the EMD                         |
| Sinkhorn                      | `ot.sinkhorn2(a, b, M, reg, method='sinkhorn_log')`                 | transport cost of the blurred plan | `reg` is ε; choose it relative to M                            |
| Sliced Wasserstein            | `ot.sliced_wasserstein_distance(X, Y, n_projections=..., seed=...)` | SW₂ (random estimate)              | Fix the seed for reproducible numbers                          |
| Small problems, any dimension | `scipy.stats.wasserstein_distance_nd(u, v)`                         | W₁                                 | Uses a general LP; slow beyond a few hundred points            |

### 13.2 Recipe: EMD between two sets of samples

```python
import numpy as np, ot

X = np.random.randn(500, 3)            # samples from P
Y = np.random.randn(400, 3) + 1.0      # samples from Q
a = np.full(len(X), 1 / len(X))        # equal weights
b = np.full(len(Y), 1 / len(Y))

emd = ot.emd2(a, b, ot.dist(X, Y, metric="euclidean"))   # W1 = EMD
w2 = np.sqrt(ot.emd2(a, b, ot.dist(X, Y)))               # default squared cost gives W2^2
print(emd, w2)
```

### 13.3 Recipe: EMD between two grey-level histograms

```python
from scipy.stats import wasserstein_distance
levels = np.arange(256)                        # bin centres = positions
h1 = np.histogram(img1, bins=256, range=(0, 256))[0]
h2 = np.histogram(img2, bins=256, range=(0, 256))[0]
emd = wasserstein_distance(levels, levels, h1, h2)   # counts go in the weights
```

### 13.4 Recipe: an EMD loss inside a PyTorch model

POT functions accept PyTorch tensors and return values you can call `.backward()` on.

```python
import torch, ot

X = torch.randn(64, 2, requires_grad=True)     # e.g. a generator's output
Y = torch.randn(64, 2) + 2                      # a batch of target data
a = torch.full((64,), 1 / 64); b = torch.full((64,), 1 / 64)

loss = ot.emd2(a, b, ot.dist(X, Y, metric="euclidean"))     # exact EMD
# alternatives: ot.sinkhorn2(a, b, ot.dist(X, Y), reg=0.1, method="sinkhorn_log")
#               ot.sliced_wasserstein_distance(X, Y, n_projections=128, seed=0)
loss.backward()        # X.grad now holds the gradient
```

For the exact EMD, the gradient with respect to the **positions** moves each point toward the points its mass is sent to by the optimal plan. When two plans are equally good (for example two points that could swap partners), the loss has a kink and the gradient jumps; the smooth Sinkhorn version avoids this. One practical trap: with `metric="euclidean"` the cost is a square root, whose derivative is infinite at distance 0, so if a point of X can coincide with a point of Y you will see NaN gradients; use the squared cost or add a tiny constant inside the square root.

**Gradient with respect to the weights.** Sometimes the network outputs a *histogram* rather than positions: a softmax over ordered classes (Section 12.3), or over labels with a semantic cost matrix (Frogner et al., 2015). Then the loss is EMD(a_θ, b) with the positions fixed and the weights a_θ depending on the network, and we need ∂EMD/∂aᵢ. The answer is the dual potential: **∂EMD/∂aᵢ = fᵢ** wherever EMD is differentiable in a (stated without proof; it follows from strong duality in Section 5.2, because EMD = Σaᵢfᵢ + Σbⱼgⱼ with f, g optimal, and the optimal potentials do not change under a small change of a. Like the loss in the positions, EMD is piecewise linear in a, so at a kink the potentials are not unique and any of them is a valid subgradient). Since potentials are defined only up to a shared constant, only differences fᵢ − fₖ are meaningful, and those are exactly what a softmax gradient uses (moving mass from bin k to bin i changes the loss by fᵢ − fₖ per unit). The notebook checks this by finite differences on the warehouse problem. POT's `ot.emd2` implements it, so `loss.backward()` works whether X or a carries the gradient.

### 13.5 Which method should I use?

| Situation                                               | Use                               | Why             |
|---------------------------------------------------------|-----------------------------------|-----------------|
| 1D data, any size                                       | Sorting / `wasserstein_distance`  | Exact and fast  |
| Up to a few thousand points, exact value or plan needed | `ot.emd`, `ot.emd2`               | Exact           |
| Equal-size batches (flow matching, point clouds)        | `linear_sum_assignment`           | Exact matching  |
| Tens of thousands of points, GPU, gradients             | Sinkhorn (log domain) or GeomLoss | Fast and smooth |
| Very many points or high dimension, cheap loss          | Sliced Wasserstein                | O(L·n log n)    |
| Gaussian fits (FID-style)                               | Closed form, Section 8            | One formula     |

### 13.6 Debugging checklist

1. Do the weight vectors a and b each sum to 1? (`ot.emd` raises an error if their sums differ.)
2. Is the cost squared or not, and are you reporting W₂² or W₂, W_pᵖ or W_p?
3. Sinkhorn: does the returned plan have the right row and column sums? Is ε sensible relative to the costs? Are you in float32 without the log domain?
4. Are you comparing EMD values computed from different sample sizes? Use the same size and report a noise floor (Section 6.5).
5. Did `ot.emd` print `numItermax reached before optimality`? Then the returned plan is **not** optimal; raise `numItermax` (default 100 000) or reduce the problem size. The warning is easy to miss in a long log.
6. If you built your own CDF-based loss: is it the area (EMD), the largest gap (KS) or the root-mean-square gap (Cramér)? They are different numbers with different units (Section 7.5).

## 14. Common mistakes and interview questions

Most mistakes come from mixing up variants (W₁ versus W₂², exact versus Sinkhorn versus sliced) or from forgetting that values computed from samples are biased.

### 14.1 Ten common mistakes

| Mistake                                                         | Correct statement                                            |
|-----------------------------------------------------------------|--------------------------------------------------------------|
| Calling `ot.emd2(a, b, ot.dist(X, Y))` the EMD                  | That is W₂²; EMD needs `metric='euclidean'`                  |
| Treating W_pᵖ as W_p                                            | Take the p-th root before comparing or reporting             |
| Passing histogram counts as positions to `wasserstein_distance` | Positions are bin centres; counts are weights                |
| Assuming W₁ between Gaussians is \|m₁ − m₂\|                   | True only for equal standard deviations (Section 8.1)        |
| Comparing EMD values from different sample sizes                | Sample EMD is biased upward and the bias depends on the size |
| Believing the Sinkhorn value for P versus P is 0                | It is not; use the Sinkhorn divergence if you need that      |
| Comparing sliced W with full W                                  | SW ≤ W and can be much smaller in high dimensions            |
| Reporting the WGAN critic value as "the" W₁                     | It is a lagging lower bound in practice (Section 10.4), fine for monitoring only |
| Calling every CDF-based loss "EMD"                              | Area = EMD, largest gap = KS, RMS gap = Cramér (Section 7.5) |
| Using batch normalisation in a WGAN-GP critic                   | Use layer normalisation or none (Section 10.3)               |
| Running Sinkhorn in float32 with small ε without the log domain | Underflow can give silently wrong answers                    |

### 14.2 Reading a paper: four questions

1. **What is compared?** Real versus generated data, source versus target features, noise versus data in a batch, two point clouds, two histograms?
2. **Which cost?** Distance (W₁), squared distance (W₂²), something else?
3. **Which solver?** Exact LP or matching, Sinkhorn (which ε?), a neural critic, random projections, a closed form?
4. **What is used: the value, the plan, or the critic?** Losses use the value; flow matching and domain adaptation use the plan; WGANs use the critic.

Notation you will see: Π(P, Q) is the set of plans (couplings); γ or π is a plan; W_p or 𝒲_p is the Wasserstein distance; "‖f‖\_L ≤ 1" means f is 1-Lipschitz; OT_ε or "Sinkhorn distance" is the blurred version.

### 14.3 Interview questions with model answers

**Q1. What is EMD, in one sentence and one formula?** The minimum total work (mass × distance) to turn one distribution into the other: W₁(P, Q) = min over couplings of E‖X − Y‖.

**Q2. Why did WGAN replace JS with EMD?** When real and generated samples do not overlap, JS is constant (log 2) and gives no gradient, while EMD grows with the distance between them and gives a useful gradient.

**Q3. How do you compute EMD in 1D?** Sort both samples and average the absolute differences of matched values (equal sizes), or integrate the absolute difference of the CDFs. O(n log n).

**Q4. How expensive is exact EMD, and what are the alternatives?** Roughly cubic in the number of points and quadratic in memory. Alternatives: Sinkhorn (O(n²) per iteration, approximate, GPU), sliced Wasserstein, closed forms (1D, Gaussians), neural critics.

**Q5. What does the entropy term in Sinkhorn buy, and cost?** A fast, simple, differentiable algorithm with a smooth unique solution. The price is a blurred plan and a biased value, plus numerical issues for small ε.

**Q6. State the critic (dual) form of EMD.** W₁(P, Q) = max over 1-Lipschitz f of E_P f − E_Q f.

**Q7. How do you keep a critic Lipschitz?** Weight clipping (simple but crude), gradient penalty (effective, needs double backpropagation, no batch norm), spectral normalisation (cheap per-layer limit).

**Q8. W₁ or W₂?** W₁ for robustness and the critic form (GANs, drift, histograms); W₂ for straight-line geometry and closed forms (flow matching, Gaussians, FID).

**Q9. Why use OT pairing in flow matching?** Optimal pairs of noise and data do not cross, so the learned paths are straighter and fewer integration steps are needed.

**Q10. EMD or Chamfer for point clouds?** Chamfer is cheap but ignores how many points are where; EMD captures density but is expensive and usually approximated.

**Q11. How is FID related to EMD?** FID is W₂² between Gaussians fitted to network features of real and generated images.

**Q12. How would you detect data drift with EMD?** Per-feature 1D EMD between a reference window and the current window, normalised by the feature's spread, compared against a reference-versus-reference noise floor.

**Q13. Monge versus Kantorovich?** Monge asks for a map sending each point to one destination; Kantorovich allows plans that split mass. Plans always exist and make the problem a linear program; a map need not exist (δ₀ to ½δ₋₁ + ½δ₁).

**Q14. What are dual potentials and what are they good for?** One number per source point and per target point with fᵢ + gⱼ ≤ Cᵢⱼ; their weighted sum is a lower bound on the EMD, equal to it at the optimum. They certify optimality, give the gradient of EMD with respect to the weights, and the optimal f is the WGAN critic.

**Q15. How many samples does an EMD estimate need?** The error of the sample EMD shrinks like n^{−1/d} in d dimensions, so estimates from samples are only reliable in low dimension or with a noise floor; Sinkhorn divergence and sliced Wasserstein need fewer samples.

## 15. Exercises with full solutions

Twenty-four exercises, ordered by section and marked by difficulty: ★ routine, ★★ exam level, ★★★ for students who want to be stretched (nothing beyond the prerequisites is needed, but the steps are not spelled out). Statements come first; solutions are grouped in 15.S. Exercises marked \[NB\] have a numerical check in the notebook.

### Exercise statements

**15.1 ★ (four measures on one example) \[NB\].** Histograms on bins 1, 2, 3, 4, 5: A = (0.5, 0.5, 0, 0, 0) and B = (0, 0, 0, 0.5, 0.5). Compute TV(A, B), KL(A ‖ B), JS(A, B) and the EMD (bin spacing 1). Which of the four reflects how far apart the histograms are?

**15.2 ★ (1D, CDF and quantiles) \[NB\].** P and Q live on {0, 1, 2} with weights a = (0.2, 0.5, 0.3) and b = (0.5, 0.1, 0.4). Compute W₁ with the CDF formula, compute W₂, and describe an optimal plan.

**15.3 ★★ (a small LP and its certificate) \[NB\].** a = (0.6, 0.4), b = (0.2, 0.3, 0.5), costs C = \[\[4, 2, 5\], \[3, 6, 1\]\]. (a) Find the north-west corner plan and the greedy plan with their costs. (b) Prove one of them is optimal using potentials. (c) Is the optimum unique?

**15.4 ★ (a point versus a spread) \[NB\].** Compute W₁ and W₂ between δ₀ and Uniform\[−1, 1\].

**15.5 ★★ (when uncrossing works, and when it fails).** (a) For x₁ ≤ x₂ and y₁ ≤ y₂, prove (x₁ − y₁)² + (x₂ − y₂)² ≤ (x₁ − y₂)² + (x₂ − y₁)² by expanding. (b) With cost |x − y|^(1/2), show that the sorted matching of x = {0, 1} to y = {1, 2} is not optimal.

**15.6 ★★ (total variation is EMD that cannot see distance).** For two distributions a, b on the same points with cost 1 between different points and 0 for the same point, prove that the optimal cost is 1 − Σₖ min(aₖ, bₖ) = ½Σₖ |aₖ − bₖ|.

**15.7 ★★ (translation).** Let Q be P shifted by a vector v. Prove W₁(P, Q) = ‖v‖, using a plan for the upper bound and a critic (Section 9) for the lower bound.

**15.8 ★ (two uniforms) \[NB\].** Compute W₂²(Uniform\[0, 1\], Uniform\[a, a + s\]) for s \> 0 with the quantile formula, and evaluate it for a = 1, s = 3.

**15.9 ★★ (W₂ separates position and shape).** P has mean m_P, Q has mean m_Q. Prove that W₂²(P, Q) = ‖m_P − m_Q‖² + W₂²(P̃, Q̃), where P̃ and Q̃ are P and Q shifted to have mean 0.

**15.10 ★★ (find the best critic) \[NB\].** P = ½δ₀ + ½δ₄ and Q = ½δ₁ + ½δ₂. (a) Compute W₁. (b) Find a 1-Lipschitz critic that reaches it. (c) Is the critic unique (apart from adding a constant)?

**15.11 ★★ (Sinkhorn by hand) \[NB\].** a = (0.5, 0.5), b = (0.25, 0.75), C = \[\[1, 3\], \[1, 1\]\] (Example 3.2, exact EMD 1.5). (a) With ε = 1 and starting v = (1, 1), do one full Sinkhorn iteration (u, then v). Give the plan, its row and column sums, and its cost. (b) Explain why the plan approaches the independent plan aᵢbⱼ as ε → ∞.

**15.12 ★ (sliced EMD of a shift, by calculus) \[NB\].** In 2D, P = δ₀ and Q = δ_v with v = (1, 0). A random direction is θ = (cos φ, sin φ) with φ uniform on \[0, 2π). Compute SW₁ = average over φ of |⟨θ, v⟩| and compare with W₁.

**15.13 ★★ (EMD from samples is biased) \[NB\].** X and Y are independent single draws from N(0, 1), so P = Q but each "data set" has one point. (a) Show that the EMD between the two one-point data sets has average 2/√π ≈ 1.13. (b) The notebook repeats this with n points per set and finds average EMDs of about 1.14, 0.93, 0.51 and 0.18 for n = 1, 2, 10, 100. What do you conclude?

**15.14 ★★ (what weight clipping really enforces) \[NB\].** A critic MLP 2 → 128 → 128 → 1 with ReLU activations has every weight clipped to \[−0.01, 0.01\] (ignore biases). Bound its Lipschitz constant, using the fact that a layer x ↦ Wx is at most √(Σᵢⱼ Wᵢⱼ²)-Lipschitz. What does this say about the WGAN critic's estimate?

**15.15 ★ (coding) \[NB\].** Write `emd_hist(h1, h2)` returning the EMD between two 256-bin histograms (bin width 1, any non-negative counts) using only NumPy.

**15.16 ★★ (reading papers).** Name the quantity, cost and solver: (a) a point-cloud paper averages distances between points matched one-to-one by an auction algorithm; (b) a paper uses a loss with ε = 0.05 that subtracts half of each distribution's self-term; (c) a domain-adaptation paper trains a critic with a gradient penalty on source and target features; (d) a flow-matching paper pairs noise and data in each batch by minimising the sum of squared distances.

**15.17 ★ (true or false, with a one-line reason).**

1. EMD(P, Q) = 0 implies P = Q.
2. If KL(P ‖ Q) = ∞ then EMD(P, Q) = ∞.
3. The Sinkhorn plan has many zero entries.
4. W₂ ≥ W₁ always.
5. For equal-size point sets with equal weights, some optimal plan is a one-to-one matching.
6. In 1D, sorted matching is optimal for the cost |x − y|^(1/2).
7. A WGAN critic's output must lie in \[0, 1\].
8. FID is W₂ between the distributions of real and generated images.

**15.18 ★★ (the gradient penalty is soft) \[NB\].** Real data P = δ₀, fake data Q = δ_θ with θ \> 0. Restrict the critic to f(x) = −s·x with slope s ≥ 0 and maximise J(s) = E_P f − E_Q f − λ(s − 1)². (a) Find the best s and J. (b) Evaluate for λ = 10 with θ = 1 and θ = 10. (c) What does this say about reading the critic value as W₁?

**15.19 ★★ (why pairing matters in flow matching) \[NB\].** Noise P = ½δ₀ + ½δ₂, data Q = ½δ₁ + ½δ₃ on the line. (a) With random (independent) pairing, the velocity learned at a starting point is the average of x₁ − x₀ over the pairs that start there. Compute it at 0 and at 2, take one Euler step of size 1, and compute W₂ between the result and Q. (b) Repeat with the OT pairing.

**15.20 ★★ (moving source data in domain adaptation) \[NB\].** Source points {0, 1}, each with weight ½; target points {2, 4, 6}, each with weight ⅓; cost (x − y)². (a) Find the optimal plan. (b) Compute the barycentric map T(0), T(1). (c) Compare the spread of the moved points with the spread of the target points, and explain.

**15.21 ★ (ordered labels) \[NB\].** Classes 1–5 with true class 5. Prediction A = (0.1, 0, 0, 0.8, 0.1), prediction B = (0.8, 0, 0, 0.1, 0.1). Compute the cross-entropy and the EMD (on the class index) of each. Which loss prefers A, and why is that sensible?

**15.22 ★★★ (the dual LP by hand) \[NB\].** Take Example 3.2: a = (½, ½) at x = 0, 2; b = (¼, ¾) at y = 1, 3; C = \[\[1, 3\], \[1, 1\]\]; optimal plan 0→1 (0.25), 0→3 (0.25), 2→3 (0.5); EMD 1.5. (a) Write out the dual LP of Section 5.2 (objective and all four constraints). (b) Impose equality on the three routes the plan uses, fix f₂ = 0, and solve for f₁, g₁, g₂. (c) Check the unused route and evaluate the dual objective. What have you proved? (d) Let φ(x) = 2 − x, the critic of Example 9.A shifted by a constant. Verify fᵢ = φ(xᵢ) and gⱼ = −φ(yⱼ), and explain why the four dual constraints are exactly "φ is 1-Lipschitz on these four points".

**15.23 ★★★ (coding: log-domain Sinkhorn) \[NB\].** Write `sinkhorn_log(a, b, C, eps)` that iterates the two potential updates of Section 11.2, fᵢ = ε log aᵢ − ε logsumexpⱼ((gⱼ − Cᵢⱼ)/ε) and gⱼ = ε log bⱼ − ε logsumexpᵢ((fᵢ − Cᵢⱼ)/ε), using `scipy.special.logsumexp`, and returns the plan exp((fᵢ + gⱼ − Cᵢⱼ)/ε) and its cost. Test it on the warehouse problem with ε = 0.002, where the plain algorithm of 11.1 returns NaN. Then explain in two sentences why `logsumexp` cannot underflow or overflow.

**15.24 ★★★ (the metric axioms in 1D, and stability).** (a) Using W₁ = ∫ |F − G| dx, prove the triangle inequality W₁(P, R) ≤ W₁(P, Q) + W₁(Q, R). (b) Prove that W₁(P, Q) = 0 implies P = Q. (Hint: a CDF is right-continuous, so if F(x₀) ≠ G(x₀) they also differ on a small interval \[x₀, x₀ + h).) (c) Let P′ be obtained from P by moving every unit of mass by at most ε (not necessarily all in the same direction). Prove |W₁(P′, Q) − W₁(P, Q)| ≤ ε. (d) Which sentence of Section 2.4 did you just prove?

### 15.S Solutions

**Solution 15.1.** TV = ½(0.5 + 0.5 + 0.5 + 0.5) = **1**. KL(A ‖ B) = **+∞**, because A has mass in bins 1 and 2 where B has none. The average is m = (0.25, 0.25, 0, 0.25, 0.25), so KL(A ‖ m) = 2·0.5·log(0.5/0.25) = log 2, likewise KL(B ‖ m) = log 2, and JS = **log 2**. For the EMD, the CDFs at bins 1 to 4 are F = (0.5, 1, 1, 1) and G = (0, 0, 0, 0.5), so the area is 0.5 + 1 + 1 + 0.5 = **3** (equivalently, move 0.5 from 1 to 4 and 0.5 from 2 to 5, each a distance of 3). Only EMD reflects distance: TV, KL and JS would be identical if B sat in bins 3 and 4, or in bins 99 and 100.

**Solution 15.2.** CDFs at 0, 1, 2: F = (0.2, 0.7, 1) and G = (0.5, 0.6, 1). |F − G| is 0.3 on \[0, 1) and 0.1 on \[1, 2), so **W₁ = 0.4**. Quantiles: P's is 0 on t ∈ \[0, 0.2), 1 on \[0.2, 0.7), 2 on \[0.7, 1); Q's is 0 on \[0, 0.5), 1 on \[0.5, 0.6), 2 on \[0.6, 1). They differ by 1 on \[0.2, 0.5) and \[0.6, 0.7), total length 0.4, so W₂² = 0.4 and **W₂ = √0.4 ≈ 0.632**. Optimal plan: keep 0.2 at 0, 0.1 at 1 and 0.3 at 2; move 0.3 from 1 to 0 and 0.1 from 1 to 2.

**Solution 15.3.** (a) North-west: γ₁₁ = 0.2, γ₁₂ = 0.3, γ₁₃ = 0.1, γ₂₃ = 0.4, cost 0.8 + 0.6 + 0.5 + 0.4 = **2.3**. Greedy: (2,3) at cost 1 takes 0.4; (1,2) at cost 2 takes 0.3; (1,1) at cost 4 takes 0.2; (1,3) at cost 5 takes 0.1. Same plan, cost 2.3. (b) Used routes (1,1), (1,2), (1,3), (2,3). With f₁ = 0: g₁ = 4, g₂ = 2, g₃ = 5, f₂ = 1 − 5 = −4. Unused routes: f₂ + g₁ = 0 ≤ 3 and f₂ + g₂ = −2 ≤ 6. Both conditions hold, so the plan is optimal; check Σaᵢfᵢ + Σbⱼgⱼ = −1.6 + (0.8 + 0.6 + 2.5) = 2.3. (c) Yes: both unused routes have strictly positive reduced cost (3 and 8), so using either would raise the cost.

**Solution 15.4.** There is only one plan: the single pile at 0 is spread over \[−1, 1\]. W₁ = E |Y| = ∫₀¹ y dy = **1/2**. W₂ = √(E Y²) = √(∫₀¹ y² dy) = **1/√3 ≈ 0.577**. As expected, W₁ ≤ W₂.

**Solution 15.5.** (a) Expanding, the squares x₁², x₂², y₁², y₂² appear on both sides and cancel, leaving

$$
\text{left} - \text{right} = -2x_1y_1 - 2x_2y_2 + 2x_1y_2 + 2x_2y_1 = -2\,(x_2-x_1)(y_2-y_1) \le 0 .
$$

\(b\) Sorted matching 0→1, 1→2 costs 1 + 1 = 2. Crossed matching 0→2, 1→1 costs √2 + 0 ≈ 1.414, which is cheaper. With a concave cost, one long trip plus leaving mass in place beats two medium trips, so sorting needs p ≥ 1.

**Solution 15.6.** For any plan (a coupling X, Y), the cost is Pr(X ≠ Y) = 1 − Σₖ Pr(X = Y = k). Since Pr(X = Y = k) can be at most min(aₖ, bₖ), every plan costs at least 1 − Σₖ min(aₖ, bₖ). This is achieved by keeping min(aₖ, bₖ) in place at every point and moving the leftovers anywhere (each leftover unit costs 1). Finally min(α, β) = (α + β − |α − β|)/2, so 1 − Σₖ min(aₖ, bₖ) = ½Σₖ |aₖ − bₖ|. ∎

**Solution 15.7.** Upper bound: moving every point x to x + v costs ‖v‖ per unit, so W₁ ≤ ‖v‖. Lower bound: let e = v/‖v‖ and f(z) = −⟨z, e⟩. It is 1-Lipschitz, since |⟨z − z′, e⟩| ≤ ‖z − z′‖·‖e‖ = ‖z − z′‖. Its gap is E_P f − E_Q f = −E⟨X, e⟩ + E⟨X + v, e⟩ = ⟨v, e⟩ = ‖v‖, so W₁ ≥ ‖v‖ by Section 9.2. Hence W₁ = ‖v‖. ∎ (The same map shows W_p ≤ ‖v‖, and W_p ≥ W₁, so every W_p equals ‖v‖.)

**Solution 15.8.** The quantiles are t and a + st, which differ by a + (s − 1)t, so

$$
W_2^2 = \int_0^1 \big(a + (s-1)t\big)^2\,dt = a^2 + a(s-1) + \frac{(s-1)^2}{3}.
$$

For a = 1, s = 3: 1 + 2 + 4/3 = **13/3 ≈ 4.33**.

**Solution 15.9.** For any coupling, write X − Y = (m_P − m_Q) + (X̃ − Ỹ), where X̃ = X − m_P and Ỹ = Y − m_Q have mean 0. Expanding the square, the cross term is 2⟨m_P − m_Q, E\[X̃ − Ỹ\]⟩ = 0, so E‖X − Y‖² = ‖m_P − m_Q‖² + E‖X̃ − Ỹ‖². The first term is the same for every coupling, and shifting a coupling of P and Q by the means gives a coupling of P̃ and Q̃ (and back). Minimising over couplings gives the claim. ∎

**Solution 15.10.** (a) Sorted matching 0→1, 4→2: W₁ = (1 + 2)/2 = **1.5**. (b) By Section 9.2, take slope −1 where F \> G (on \[0, 1)) and +1 where F \< G (on \[2, 4)); on \[1, 2), where F = G, any slope between −1 and 1 is allowed. For example f(x) = |x − 1.5|: E_P f = (1.5 + 2.5)/2 = 2, E_Q f = (0.5 + 0.5)/2 = 0.5, gap **1.5**. (c) No: f(x) = |x − c| works for every c in \[1, 2\], because the critic is only pinned down where F ≠ G.

**Solution 15.11.** (a) K = e^(−C) ≈ \[\[0.368, 0.050\], \[0.368, 0.368\]\].

1. Kv = (0.418, 0.736), so u = a/(Kv) = (1.197, 0.680).
2. Kᵀu = (0.690, 0.310), so v = b/(Kᵀu) = (0.362, 2.422).
3. Plan γᵢⱼ = uᵢKᵢⱼvⱼ ≈ \[\[0.159, 0.144\], \[0.091, 0.606\]\].

Column sums are (0.25, 0.75), exactly b; row sums are (0.304, 0.696), not yet a. The cost is 0.159 + 3·0.144 + 0.091 + 0.606 ≈ **1.289**, below the true 1.5. That is not a contradiction, because the plan is not yet valid: never read a Sinkhorn cost without checking the row and column sums. At convergence the cost is about 1.587, slightly above 1.5 because of the blur.

\(b\) As ε → ∞, every entry e^(−Cᵢⱼ/ε) → 1, so the plan becomes γᵢⱼ = uᵢvⱼ. The row sums give uᵢ·(Σⱼvⱼ) = aᵢ and the column sums vⱼ·(Σᵢuᵢ) = bⱼ, so γᵢⱼ = aᵢbⱼ/(Σᵢuᵢ·Σⱼvⱼ), and since all entries add up to 1 the denominator is 1: γᵢⱼ = aᵢbⱼ, the independent plan.

**Solution 15.12.** The projections of 0 and v onto θ are 0 and ⟨θ, v⟩ = cos φ, so the 1D EMD for direction φ is |cos φ|. Averaging over φ:

$$
SW_1 = \frac{1}{2\pi}\int_0^{2\pi} |\cos\varphi|\,d\varphi = \frac{1}{2\pi}\cdot 4 = \frac{2}{\pi} \approx 0.637,
$$

since ∫ |cos φ| dφ over one full period is 4 times ∫₀^{π/2} cos φ dφ = 4. W₁ = ‖v‖ = 1, so the sliced value is about 36% smaller, as Section 11.3 predicts.

**Solution 15.13.** (a) With one point per set, the only plan moves X to Y, so the EMD is |X − Y|. X − Y is normal with mean 0 and variance 2. For Z ~ N(0, 1), E |Z| = 2∫₀^∞ z·e^(−z²/2)/√(2π) dz = 2/√(2π) = √(2/π), so E |X − Y| = √2·√(2/π) = **2/√π ≈ 1.128**, although the true EMD between P and Q = P is 0. (b) The sample EMD is always positive here and shrinks only slowly as n grows (1.14, 0.93, 0.51, 0.18). So never compare EMD values computed from different sample sizes, and always report a noise floor computed from two samples of the same distribution.

**Solution 15.14.** With all entries at most 0.01 in absolute value, each layer's bound is 0.01·√(number of entries): layer 1 (128 × 2): 0.01·√256 = 0.16; layer 2 (128 × 128): 0.01·128 = 1.28; layer 3 (1 × 128): 0.01·√128 ≈ 0.113. ReLU is 1-Lipschitz and constants multiply under composition (Section 9.1), so the critic is at most **0.16 × 1.28 × 0.113 ≈ 0.023**-Lipschitz. Its best possible gap is therefore at most about 0.023·W₁: a tiny signal, scaled by an unknown factor that changes during training. This is why clipping was replaced by the gradient penalty.

**Solution 15.15.**

```python
import numpy as np

def emd_hist(h1, h2):
    p = np.asarray(h1, float); q = np.asarray(h2, float)
    p, q = p / p.sum(), q / q.sum()          # normalise to total mass 1
    return np.abs(np.cumsum(p - q)).sum()    # area between the CDFs, bin width 1
```

The cumulative sum of p − q is F − G on each unit-width interval between consecutive bins, so summing its absolute values is the CDF area of Section 7.1. The last cumulative sum is 0 (both total 1), so including it does no harm.

**Solution 15.16.** (a) EMD = W₁ between equal-size point sets, distance cost, approximate matching (auction). (b) The Sinkhorn divergence (debiased entropic OT), usually with squared distance, computed with log-domain Sinkhorn. (c) W₁ between feature distributions through the critic form, distance cost, neural critic (WDGRL-style). (d) A mini-batch W₂² pairing (OT-CFM), squared distance, exact assignment.

**Solution 15.17.** (1) True: EMD is a distance between distributions. (2) False: δ₀ versus δ_θ has KL = ∞ but EMD = |θ|. (3) False: every entry is positive (the plan is blurred). (4) True: (E D)² ≤ E D². (5) True (Section 5.3). (6) False: the cost is concave (Exercise 15.5). (7) False: the critic's output is unbounded; a sigmoid would bring back saturation. (8) False: FID is W₂² between Gaussians fitted to network features of the images.

**Solution 15.18.** (a) J(s) = 0 − (−sθ) − λ(s − 1)² = sθ − λ(s − 1)². Setting J′(s) = θ − 2λ(s − 1) = 0 gives **s = 1 + θ/(2λ)** and **J = θ + θ²/(4λ)**. (b) λ = 10, θ = 1: s = 1.05, J = 1.025, which is 2.5% above W₁ = 1. λ = 10, θ = 10: s = 1.5, J = 12.5, which is 25% above W₁ = 10. (c) The penalty does not force slope 1; the critic steepens when that increases its score, so its value overestimates W₁ when the distributions are far apart relative to λ, typically early in training. The direction of the generator's update is still right; only its size is inflated. Use the critic value for monitoring, not as a measurement.

**Solution 15.19.** (a) Random pairs (0,1), (0,3), (2,1), (2,3) each have probability ¼, with velocities x₁ − x₀ = 1, 3, −1, 1. At 0 the average is (1 + 3)/2 = 2; at 2 it is (−1 + 1)/2 = 0. One Euler step sends 0 → 2 and 2 → 2: all the mass ends at 2. W₂(δ₂, ½δ₁ + ½δ₃) = √(½·1 + ½·1) = **1**. (b) The OT pairing is 0→1 and 2→3, both with velocity 1; one step lands exactly on Q, so **W₂ = 0**. Random pairs cross, so the averaged velocity points in a compromise direction and one step fails; OT pairs do not cross and one step is exact.

**Solution 15.20.** (a) In 1D with a convex cost the sorted plan is optimal: source 0 sends ⅓ to 2 and ⅙ to 4; source 1 sends ⅙ to 4 and ⅓ to 6. (b) T(0) = (⅓·2 + ⅙·4)/½ = **8/3 ≈ 2.67** and T(1) = (⅙·4 + ⅓·6)/½ = **16/3 ≈ 5.33**. (c) The moved points have mean 4, like the target, but variance ((8/3 − 4)² + (16/3 − 4)²)/2 = 16/9 ≈ 1.78, smaller than the target's (4 + 0 + 4)/3 = 8/3 ≈ 2.67. Each source point's mass is split between several destinations, and the barycentric map replaces that split by its average, which removes the spread within each split (here 8/9; indeed 16/9 + 8/9 = 8/3). So moved source data are slightly too concentrated compared with the target, and blurrier Sinkhorn plans make this worse.

**Solution 15.21.** Cross-entropy depends only on the probability of the true class: both predictions give −log 0.1 ≈ **2.30**. EMD on the class index: for A, mass 0.1 at class 1 moves 4 and mass 0.8 at class 4 moves 1, so EMD = 0.4 + 0.8 = **1.2**; for B, mass 0.8 at class 1 moves 4 and 0.1 at class 4 moves 1, so EMD = 3.2 + 0.1 = **3.3**. EMD prefers A, which is sensible: A's mistakes are near misses (4 instead of 5), while B is confidently far off.

**Solution 15.22.** (a) Maximise ½f₁ + ½f₂ + ¼g₁ + ¾g₂ subject to f₁ + g₁ ≤ 1, f₁ + g₂ ≤ 3, f₂ + g₁ ≤ 1, f₂ + g₂ ≤ 1. (b) With f₂ = 0: route (2,2) gives g₂ = 1; route (1,2) gives f₁ = 3 − 1 = 2; route (1,1) gives g₁ = 1 − 2 = −1. So **f = (2, 0), g = (−1, 1)**. (c) The unused route (2,1): f₂ + g₁ = −1 ≤ 1, fine. Dual objective: ½·2 + ½·0 + ¼·(−1) + ¾·1 = **1.5** = the plan's cost. By the Lemma of 5.2 the plan is optimal, and you have verified strong duality on this example: the best lower bound equals the best plan. (d) φ(0) = 2 = f₁, φ(2) = 0 = f₂; −φ(1) = −1 = g₁, −φ(3) = 1 = g₂. With gⱼ = −φ(yⱼ) the constraint fᵢ + gⱼ ≤ Cᵢⱼ reads φ(xᵢ) − φ(yⱼ) ≤ |xᵢ − yⱼ|, which is the 1-Lipschitz condition between each pile and each hole, and the dual objective becomes Σaᵢφ(xᵢ) − Σbⱼφ(yⱼ) = E_P φ − E_Q φ. The dual LP *is* the critic problem of Section 9, restricted to the points that carry mass.

**Solution 15.23.**

```python
import numpy as np
from scipy.special import logsumexp

def sinkhorn_log(a, b, C, eps, n_iter=20000, tol=1e-12):
    f, g = np.zeros_like(a), np.zeros_like(b)
    for _ in range(n_iter):
        f = eps * np.log(a) - eps * logsumexp((g[None, :] - C) / eps, axis=1)   # rows now sum to a
        g = eps * np.log(b) - eps * logsumexp((f[:, None] - C) / eps, axis=0)   # columns now sum to b
        G = np.exp((f[:, None] + g[None, :] - C) / eps)
        if np.abs(G.sum(1) - a).sum() < tol:
            break
    return G, np.sum(G * C)
```

On the warehouse problem with ε = 0.002 it returns cost 2.5000 with row sums (0.3, 0.3, 0.4) and column sums (0.1, 0.4, 0.5). Why it is safe: `logsumexp(z)` computes m + log Σ e^{zₖ − m} with m = max z, so the largest exponential is e⁰ = 1 and the others are at most 1; nothing can overflow, and the dominant term can never underflow to 0. The plan is formed only at the end, as exp of a number that is ≤ 0 on every route that matters, so entries that do underflow are genuinely negligible.

**Solution 15.24.** (a) For every x, |F(x) − H(x)| ≤ |F(x) − G(x)| + |G(x) − H(x)| (triangle inequality for numbers). Integrating over x gives W₁(P, R) ≤ W₁(P, Q) + W₁(Q, R). (b) Suppose F(x₀) ≠ G(x₀), say |F(x₀) − G(x₀)| = δ \> 0. CDFs are right-continuous, so there is h \> 0 with |F(x) − G(x)| \> δ/2 for all x in \[x₀, x₀ + h). Then ∫|F − G| dx ≥ hδ/2 \> 0, a contradiction. So F = G everywhere, and two distributions with the same CDF are the same. (c) The plan "send each unit of mass of P to where it went" is a valid plan between P and P′ that moves every unit at most ε, so W₁(P, P′) ≤ ε. By (a), W₁(P′, Q) ≤ W₁(P′, P) + W₁(P, Q) ≤ ε + W₁(P, Q), and swapping the roles of P and P′, W₁(P, Q) ≤ ε + W₁(P′, Q). Together: |W₁(P′, Q) − W₁(P, Q)| ≤ ε. (d) Property 2 of Section 2.4 ("shift every point by at most ε and EMD changes by at most ε"). The argument in (c) uses only the triangle inequality, so it holds in any dimension once the triangle inequality is granted (Section 6.3).

## 16. Cheat sheet, where to go next, and references

### 16.1 Cheat sheet

**Definition (discrete).** Plans γᵢⱼ ≥ 0 with row sums a and column sums b:

$$
\mathrm{EMD} = W_1 = \min_{\gamma}\sum_{i,j}\gamma_{ij}\,\|x_i-y_j\|, \qquad W_p = \Big(\min_{\gamma}\sum_{i,j}\gamma_{ij}\,\|x_i-y_j\|^p\Big)^{1/p}.
$$

**1D closed forms** (CDFs F, G; quantiles F⁻¹, G⁻¹; equal-size samples: sort and match):

$$
W_1 = \int |F(x)-G(x)|\,dx, \qquad W_p^p = \int_0^1 |F^{-1}(t)-G^{-1}(t)|^p\,dt, \qquad W_p^p = \frac1n\sum_i |x_{(i)}-y_{(i)}|^p .
$$

**Gaussians:** in 1D, W₂² = (m₁ − m₂)² + (σ₁ − σ₂)²; with independent coordinates, add up over coordinates; FID is the general formula.

**Critic form:** W₁(P, Q) = max over 1-Lipschitz f of E_P f − E_Q f.

**Sinkhorn:** γᵢⱼ = uᵢ e^(−Cᵢⱼ/ε) vⱼ with uᵢ = e^{fᵢ/ε}, vⱼ = e^{gⱼ/ε}; alternate u = a/(Kv) and v = b/(Kᵀu), or in the log domain f = ε log a − ε logsumexp((g − C)/ε) and likewise for g; use the log domain for small ε.

**Sliced:** project onto random directions, sort, average; SW ≤ W.

**WGAN-GP critic loss:** mean f(fake) − mean f(real) + 10·mean (‖∇f(x̂)‖ − 1)² at random points x̂ between real and fake samples.

| Fact                                                                                               | Section    |
|----------------------------------------------------------------------------------------------------|------------|
| EMD of a shift by v is ‖v‖; KL, JS and TV saturate when supports do not overlap                    | 2.3, 3.3   |
| Dual LP: max Σaᵢfᵢ + Σbⱼgⱼ subject to fᵢ + gⱼ ≤ Cᵢⱼ; its maximum equals the EMD, and the optimal f, g certify a plan (equality on used routes) | 5.2        |
| ∂EMD/∂aᵢ = fᵢ: the potential is the gradient with respect to the weights                          | 13.4       |
| In 1D: KS = largest CDF gap, EMD = area, Cramér = root-mean-square gap; only EMD has units of x   | 7.5        |
| Optimal plans use at most n + m − 1 routes; equal-size point sets need only a matching             | 5.3        |
| W₁ ≤ W₂; EMD notices far-away mass                                                                 | 6.3, 6.4   |
| Sample EMD is biased upward: compare at equal sample size and report a noise floor                 | 6.5        |
| In 1D: sort and match, O(n log n)                                                                  | 7          |
| Sinkhorn is fast and smooth but blurred; it can underflow in float32; iterations grow as ε shrinks  | 11.1, 11.2 |
| Sample EMD error shrinks like n^{−1/d}; the WGAN critic value is a lagging lower bound              | 6.5, 10.4  |
| OT pairing straightens flow-matching paths                                                         | 12.6       |

### 16.2 Where to go next

These topics were left out because they need graduate-level mathematics. Peyré and Cuturi's book (below) covers each of them.

- **Measure-theoretic foundations:** existence of optimal plans and maps for general distributions, convergence of distributions.
- **Brenier's theorem:** the optimal W₂ map is the gradient of a convex function; the basis of neural OT maps.
- **Full duality theory:** the dual linear program and its proof, gradients of OT with respect to data.
- **Gaussians with full covariances:** derivation of the matrix-square-root formula behind FID.
- **Barycenters:** "averages" of distributions.
- **Unbalanced and partial OT:** unequal masses and robustness to outliers.
- **Gromov–Wasserstein distance:** comparing data that live in different spaces, such as two graphs.
- **Schrödinger bridges:** the link between Sinkhorn and diffusion models.
- **Semi-discrete OT and neural OT maps**, including the 2026 flow-matching method mentioned in 12.6.
- **Sample complexity proofs:** why the rate n^{−1/d} of Section 6.5 holds, and why Sinkhorn divergence and sliced Wasserstein escape it.

The best next step for self-study is G. Peyré and M. Cuturi, *Computational Optimal Transport* (free on arXiv).

### 16.3 References

| Topic                      | Reference                                                                                                                                                                                                                                        |
|----------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Textbook                   | G. Peyré, M. Cuturi, [Computational Optimal Transport](https://arxiv.org/abs/1803.00567), 2019                                                                                                                                                   |
| Original EMD               | Y. Rubner, C. Tomasi, L. Guibas, "The Earth Mover's Distance as a Metric for Image Retrieval", IJCV, 2000                                                                                                                                        |
| GAN                        | I. Goodfellow et al., "Generative Adversarial Nets", NeurIPS 2014                                                                                                                                                                                |
| WGAN                       | M. Arjovsky, S. Chintala, L. Bottou, [Wasserstein GAN](https://arxiv.org/abs/1701.07875), ICML 2017                                                                                                                                              |
| WGAN-GP                    | I. Gulrajani et al., [Improved Training of Wasserstein GANs](https://arxiv.org/abs/1704.00028), NeurIPS 2017                                                                                                                                     |
| Spectral normalisation     | T. Miyato et al., [Spectral Normalization for GANs](https://arxiv.org/abs/1802.05957), ICLR 2018                                                                                                                                                 |
| Sinkhorn                   | M. Cuturi, [Sinkhorn Distances](https://arxiv.org/abs/1306.0895), NeurIPS 2013                                                                                                                                                                   |
| Sinkhorn divergence        | J. Feydy et al., [Interpolating between OT and MMD using Sinkhorn Divergences](https://arxiv.org/abs/1810.08278), AISTATS 2019                                                                                                                   |
| FID                        | M. Heusel et al., [GANs Trained by a Two Time-Scale Update Rule](https://arxiv.org/abs/1706.08500), NeurIPS 2017                                                                                                                                 |
| Flow matching              | Y. Lipman et al., [Flow Matching for Generative Modeling](https://arxiv.org/abs/2210.02747), ICLR 2023                                                                                                                                           |
| OT-CFM                     | A. Tong et al., [Improving and Generalizing Flow-Based Generative Models with Minibatch Optimal Transport](https://arxiv.org/abs/2302.00482), TMLR 2024                                                                                          |
| Semidiscrete flow matching | A. Mousavi-Hosseini et al., [Flow Matching with Semidiscrete Couplings](https://arxiv.org/abs/2509.25519), ICLR 2026                                                                                                                             |
| Domain adaptation          | N. Courty et al., [Optimal Transport for Domain Adaptation](https://arxiv.org/abs/1507.00504), TPAMI 2017; B. B. Damodaran et al., [DeepJDOT](https://arxiv.org/abs/1803.10081), ECCV 2018                                                       |
| Point clouds               | H. Fan, H. Su, L. Guibas, [A Point Set Generation Network](https://arxiv.org/abs/1612.00603), CVPR 2017                                                                                                                                          |
| EMD loss for classifiers   | C. Frogner et al., [Learning with a Wasserstein Loss](https://arxiv.org/abs/1506.05439), NeurIPS 2015                                                                                                                                             |
| Multisample flow matching  | A.-A. Pooladian et al., [Multisample Flow Matching](https://arxiv.org/abs/2304.14772), ICML 2023                                                                                                                                                   |
| WGAN-LP                    | H. Petzka, A. Fischer, D. Lukovnikov, [On the Regularization of Wasserstein GANs](https://arxiv.org/abs/1709.08894), ICLR 2018                                                                                                                     |
| Sinkhorn divergence (GANs) | A. Genevay, G. Peyré, M. Cuturi, [Learning Generative Models with Sinkhorn Divergences](https://arxiv.org/abs/1706.00292), AISTATS 2018                                                                                                            |
| Domain adaptation theory   | I. Redko, A. Habrard, M. Sebban, [Theoretical Analysis of Domain Adaptation with Optimal Transport](https://arxiv.org/abs/1610.04420), ECML 2017; J. Shen et al., [Wasserstein Distance Guided Representation Learning](https://arxiv.org/abs/1707.01217), AAAI 2018 |
| NIMA (Cramér-type loss)    | H. Talebi, P. Milanfar, [NIMA: Neural Image Assessment](https://arxiv.org/abs/1709.05424), IEEE TIP 2018                                                                                                                                           |
| Word Mover's Distance      | M. Kusner et al., "From Word Embeddings to Document Distances", ICML 2015                                                                                                                                                                           |
| Cross-tokenizer distillation | N. Boizard et al., [Towards Cross-Tokenizer Distillation: the Universal Logit Distillation Loss](https://arxiv.org/abs/2402.12030), TMLR 2025                                                                                                   |
| Distributional RL          | W. Dabney et al., [Distributional RL with Quantile Regression](https://arxiv.org/abs/1710.10044), AAAI 2018                                                                                                                                        |
| FID alternatives           | G. Stein et al., [Exposing Flaws of Generative Model Evaluation Metrics](https://arxiv.org/abs/2306.04675), NeurIPS 2023; S. Jayasumana et al., [Rethinking FID (CMMD)](https://arxiv.org/abs/2401.09603), CVPR 2024                              |
| Sample complexity          | R. M. Dudley, "The Speed of Mean Glivenko–Cantelli Convergence", Ann. Math. Statist. 40, 1969                                                                                                                                                      |
| Software                   | [POT: Python Optimal Transport](https://pythonot.github.io/); [SciPy `wasserstein_distance`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.wasserstein_distance.html); [GeomLoss](https://www.kernel-operations.io/geomloss/) |

## Appendix: what changed in the November 2026 revision

For readers of the first edition. Corrections: Section 10.4 now reports the companion notebook's full WGAN-GP log (the critic *under*estimates W₁ by up to 4× during training; the first edition quoted only the final iteration); the flow-matching caption (12.6) now states the measured numbers and the noise floor; NIMA's loss (12.3) is identified as the Cramér form, not EMD; the dual potentials are now written f, g throughout and the Sinkhorn scalings u, v, with the relation u = e^{f/ε} made explicit; the memory estimate in 5.4 and the float32 thresholds in 11.2 were corrected; uncited 2025–26 claims were removed. Additions: the dual linear program and strong duality (5.2), the continuity theorem behind WGAN (2.4), the n^{−1/d} sample-complexity rate (6.5), the metric axioms proved in 1D (7.2), the KS/EMD/Cramér comparison (7.5), a one-line proof of SW₂ = ‖v‖/√d (11.3), gradients with respect to weights (13.4), two debugging items (13.6), three interview questions, three ★★★ exercises (15.22–15.24) with solutions, five new figures, and a longer reference list. Linear algebra was added to the prerequisites, which the first edition used without saying so.
