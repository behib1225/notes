# Earth Mover's Distance (Wasserstein Distance): A Complete Tutorial

November 2026, revised edition

**What changed in this edition.** The mathematics of the first edition survived a line-by-line check; this revision corrects a handful of imprecise statements (RMSProp, polytope vs polyhedron, the worst-case cost of network simplex, the scope of "Fréchet distance", moment hypotheses in Brenier's theorem), explains why three different solvers return three different sets of dual potentials, adds the material undergraduates most often meet next (Kolmogorov–Smirnov versus W₁ versus Cramér–von Mises, W₁ as an integral probability metric, distributional reinforcement learning, Sinkhorn's cost and ε-scaling, Arjovsky's continuity theorem), splits the tutorial into three tracks so that a first course can stop after the core, adds three exercises of a new kind (spot the bug, a dual solved by hand, weighted 1D Wₚ), and ships its figures with the text so that it is self-contained.

**Files in this bundle.** `EMD_tutorial.md` (this document), `emd_tutorial.ipynb` (the companion notebook, which regenerates every figure and every number), `figures/` (the eight figures referenced below, so the document renders without running the notebook) and `requirements.txt`.

## Table of contents

- [0. How to use this tutorial](#0-how-to-use-this-tutorial), including the **three tracks**
- [Primer P1–P11](#primer-the-background-you-need)
- [1. Motivation](#1-motivation-why-we-need-a-geometry-aware-distance-between-distributions) · [2. Intuition](#2-intuition-piles-of-earth-and-holes) · [3. Discrete EMD as an LP](#3-discrete-emd-as-a-linear-program) · [4. Solving the LP](#4-solving-the-transportation-lp)
- [5. Wasserstein-p](#5-the-general-wasserstein-p-distance) · [6. One dimension](#6-one-dimension-closed-forms-and-a-sorting-algorithm) · [7. Gaussians and FID](#7-gaussians-a-closed-form-for-w₂-and-why-fid-is-a-wasserstein-distance)
- [8. Duality](#8-kantorovichrubinstein-duality) · [9. WGAN](#9-wasserstein-gans-emd-as-a-training-loss) · [10. Sinkhorn](#10-entropic-ot-and-the-sinkhorn-algorithm) · [11. Sliced Wasserstein](#11-sliced-wasserstein-distance)
- [12. Modern applications](#12-modern-applications) · [13. Implementation guide](#13-implementation-guide-in-python) · [14. Pitfalls, papers, interviews](#14-pitfalls-reading-papers-and-interview-questions)
- [15. Exercises with solutions](#15-exercises-with-full-solutions) · [16. Cheat sheet, references, index](#16-cheat-sheet-and-references)

## 0. How to use this tutorial

The Earth Mover's Distance (EMD) measures how different two probability distributions are by computing the cheapest way to move the probability mass of one onto the other. Mathematicians call the same quantity the **Wasserstein-1 distance**, W₁; in this tutorial the two names mean the same thing unless stated otherwise. By the end you will be able to define it, compute it by hand and in code, prove its key properties, and recognise it in GANs, flow matching, domain adaptation and 3D point-cloud papers.

**Prerequisites.** Single-variable calculus (integrals, derivatives), elementary probability (PMF, PDF, CDF, expectation, joint and marginal distributions), basic Python with NumPy, and a rough idea of what a multilayer perceptron (MLP) is and how gradient descent trains it. Nothing else is assumed. The Primer right after this section teaches, with worked examples, every further concept the tutorial uses (KL and JS divergences, quantiles, covariance matrices, Lipschitz functions, linear programs, GANs, flow matching and more), and its last table shows where each one is first needed.

**Learning goals.** After working through every section and exercise you should be able to:

1. Explain in one sentence, and then in one equation, what EMD measures and why it is better than KL or JS divergence for distributions that do not overlap.
2. Write the discrete EMD as a linear program and solve small instances by hand.
3. Derive and use the 1D closed forms (CDF formula and quantile/sorting formula), and the closed form for Gaussians.
4. State and derive the Kantorovich–Rubinstein duality and explain how it turns into the WGAN critic loss.
5. Implement exact EMD, Sinkhorn (entropic) OT and sliced Wasserstein in Python, and know when to use each.
6. Read a modern paper that uses optimal transport (OT-CFM, DeepJDOT, point-cloud EMD loss) and know exactly which variant of the distance it is using.

**Roadmap.** The Primer (P1–P11) supplies the background. Sections 1–2 build intuition. Sections 3–4 give the discrete definition and how to solve it. Section 5 generalises to arbitrary distributions and proves EMD is a true metric. Sections 6–7 give closed forms you will use constantly. Section 8 is duality, the bridge to deep learning. Sections 9–12 are the deep learning applications and fast approximations; 12.7 surveys the extensions you will meet in current papers (barycenters, unbalanced OT, Gromov–Wasserstein, Schrödinger bridges, semi-discrete OT, neural OT maps). Section 13 is the implementation guide. Sections 14–16 are interview prep, exercises with full solutions, and a one-page cheat sheet.

**Three tracks.** The tutorial is long because it has to serve three purposes: a first course, applied deep learning, and reading current papers. Do not read it linearly on a first pass. Choose a track:

| Track | Who it is for | Read | Exercises |
| --- | --- | --- | --- |
| **Core** (a one-semester undergraduate module) | Anyone meeting EMD for the first time | P1–P3, P7 (LP part), P8; Sections 1, 2, 3, 4.1–4.5, 5.1–5.5, 6, 8.1–8.5, 8.7, 9.1–9.3, 13.1–13.2, 13.6, 14.1 | 15.1–15.9, 15.14, 15.16, 15.17, 15.23–15.25 |
| **Applied** (using OT as a loss or a metric in deep learning) | Core, plus anyone training generative models or comparing data sets | add 4.6, 5.6–5.7, 7, 8.6, 9.4–9.5, 10, 11, 12.1–12.6, 13.3–13.5, 14.2–14.3 | add 15.10–15.13, 15.15, 15.18–15.21 |
| **Research** (reading 2025–26 papers) | Applied, plus anyone who needs barycenters, unbalanced OT, Gromov–Wasserstein, bridges, neural OT | add 12.7, the 2025–26 survey in 12.1, P11, and the boxed proofs in 4.2, 4.3, 6.3–6.4, 7.3 | add 15.22 |

Proofs marked **(optional proof)** can be skipped on the Core track without losing anything used later. Exam-style questions for the Core track never need the optional proofs.

**How to study.** Each section ends with **Check yourself** questions; answer them before reading the answers right below. Section 15 holds the longer exam-style exercises. Run the companion Jupyter notebook (`emd_tutorial.ipynb`) side by side: it reproduces every worked example and every numerical exercise answer in this document and draws all of its figures, so you can verify each number yourself and then change the inputs. Cells marked "Your turn" ask you to write code before revealing a solution.

**Notation used throughout.**

| Symbol | Meaning |
| --- | --- |
| P, Q (or μ, ν) | Two probability distributions to compare |
| x₁,…,xₙ and y₁,…,yₘ | Support points (locations) of discrete P and Q |
| a = (a₁,…,aₙ), b = (b₁,…,bₘ) | Probability weights at those points; aᵢ ≥ 0, Σaᵢ = 1, same for b |
| C, with entries Cᵢⱼ = c(xᵢ, yⱼ) | Cost matrix: cost to move one unit of mass from xᵢ to yⱼ (usually a distance d(xᵢ, yⱼ) or its p-th power) |
| γ (gamma), with entries γᵢⱼ | Transport plan (coupling): mass moved from xᵢ to yⱼ |
| Π(a, b) or Π(P, Q) | Set of all valid transport plans (couplings) with marginals a and b |
| ⟨γ, C⟩ = Σᵢ Σⱼ γᵢⱼ Cᵢⱼ | Total transport cost of plan γ |
| Wₚ(P, Q) | p-Wasserstein distance; EMD = W₁ |
| F, G and F⁻¹, G⁻¹ | CDFs of P and Q and their quantile functions (1D only) |
| δₓ | Dirac mass: all probability at the single point x |
| ‖·‖ | Euclidean norm unless stated otherwise |
| 𝟙 | Vector of ones |

**Plain-text conventions.** Display formulas use standard notation. Inside running text and tables, abs(z) means the absolute value |z|, and Pr(·) means the probability of an event, as in Pr(X ≠ Y). The letters P and Q always denote distributions; P(A) is the mass that distribution P gives to a set A.

**A note on names.** The phrase "earth mover's distance" comes from computer vision (Rubner, Tomasi and Guibas, 1998–2000). "Wasserstein distance", "Kantorovich–Rubinstein distance" and "optimal transport (OT) cost" come from mathematics and are older. Papers mix them freely, so learn to translate: EMD = W₁ = optimal transport cost with ground cost equal to a distance.

## Primer: the background you need

This primer is a compact reference for every concept the tutorial uses beyond basic probability and the MLP, each with one worked example. It is not a substitute for a course: if P5–P7 or P9–P10 are new to you, expect to consult a probability or deep-learning textbook alongside them. Read P1–P3 and P7–P8 before Section 1; read the others when a section points to them. P11 lists notions that appear only in proofs and remarks, and can be skipped on the Core track.

### P1. Distributions as weights on points; Dirac masses; samples

A **discrete distribution** puts probability weights on a finite set of points. We write it as a weighted sum of **Dirac masses**: δₓ is the distribution that puts all its probability on the single point x. For example

$$
P = 0.2\,\delta_0 + 0.5\,\delta_1 + 0.3\,\delta_2
$$

means Pr(X = 0) = 0.2, Pr(X = 1) = 0.5, Pr(X = 2) = 0.3. The weights are non-negative and sum to 1. The expectation of a function f under P is the weighted sum E\_P f(X) = 0.2 f(0) + 0.5 f(1) + 0.3 f(2).

**Samples and empirical distributions.** Data sets are samples x₁, …, xₙ drawn **i.i.d.** (independently, each from the same distribution P). The **empirical distribution** puts weight 1/n on each sample: P̂ₙ = (1/n)Σᵢ δ\_{xᵢ}. Example: samples 2, 2, 5 give P̂₃ = ⅔δ₂ + ⅓δ₅. A histogram of the data is the same object with points grouped into bins. When we "compute EMD between two data sets", we compute it between their empirical distributions.

**Joint distributions and marginals (reminder).** A joint distribution of a pair (X, Y) assigns a probability to each pair of values. Summing it over y gives the marginal distribution of X; summing over x gives the marginal of Y. X and Y are independent when the joint probability is the product of the marginals. Section 3 uses exactly these three ideas.

For continuous distributions, sums become integrals of a density p(x): E\_P f(X) = ∫ f(x)p(x) dx.

### P2. CDFs and quantile functions

The **cumulative distribution function** of a real random variable is F(x) = Pr(X ≤ x). For the P above, F jumps by 0.2 at 0, by 0.5 at 1 and by 0.3 at 2: F = 0 for x < 0, 0.2 on \[0, 1), 0.7 on \[1, 2), and 1 for x ≥ 2.

The **quantile function** answers the reverse question: for a probability level t between 0 and 1, which value x has a fraction t of the mass at or below it? Formally F⁻¹(t) is the smallest x with F(x) ≥ t. For our P: F⁻¹(t) = 0 for t ≤ 0.2, 1 for 0.2 < t ≤ 0.7, and 2 for t > 0.7. For a continuous, strictly increasing F it is the ordinary inverse function; for example, the median is F⁻¹(0.5). For a standard normal, the CDF is written Φ and its quantile function Φ⁻¹, so Φ⁻¹(0.975) ≈ 1.96.

Useful fact (proved in Section 6.2): if U is uniform on (0, 1), then F⁻¹(U) has CDF F. This is how computers turn uniform random numbers into samples of any distribution ("inverse-transform sampling").

### P3. Comparing distributions bin by bin: total variation, KL, JS, entropy

Let a and b be two probability vectors on the same points (two histograms with the same bins). Three standard ways to compare them, all of which reappear in Section 1, are:

$$
\mathrm{TV}(a,b)=\tfrac12\sum_k |a_k-b_k|, \qquad \mathrm{KL}(a\,\|\,b)=\sum_k a_k\log\frac{a_k}{b_k}, \qquad \mathrm{JS}(a,b)=\tfrac12\mathrm{KL}(a\,\|\,m)+\tfrac12\mathrm{KL}(b\,\|\,m),\;\; m=\tfrac12(a+b).
$$

- **Total variation (TV)** is half the total absolute difference of the weights. It equals the largest possible difference P(A) − Q(A) over sets A of points, and lies in \[0, 1\].
- **Kullback–Leibler divergence (KL)** uses natural logs, with the conventions 0·log 0 = 0 and KL = +∞ if some aₖ > 0 where bₖ = 0. It is ≥ 0, equals 0 only when a = b, and is **not symmetric**: KL(a ‖ b) ≠ KL(b ‖ a) in general.
- **Jensen–Shannon divergence (JS)** compares both distributions with their average m. It is symmetric, always finite, and at most log 2 ≈ 0.693.

**Worked example.** a = (0.5, 0.5, 0), b = (0.25, 0.25, 0.5).

1. TV = ½(0.25 + 0.25 + 0.5) = **0.5**.
2. KL(a ‖ b) = 0.5 log(0.5/0.25) + 0.5 log(0.5/0.25) + 0 = **log 2 ≈ 0.693**.
3. KL(b ‖ a) = **+∞**, because b puts mass 0.5 on the third point, where a has none.
4. m = (0.375, 0.375, 0.25); KL(a ‖ m) = log(4/3) ≈ 0.288 and KL(b ‖ m) = ½ log(4/3) ≈ 0.144, so JS ≈ **0.216**.

**Entropy and cross-entropy (the link to your MLP).** The entropy H(a) = −Σₖ aₖ log aₖ measures how spread out a is (0 for a single point, log K for uniform on K points). The cross-entropy is H(a, b) = −Σₖ aₖ log bₖ, and a one-line calculation gives H(a, b) = H(a) + KL(a ‖ b). The cross-entropy loss you used to train an MLP classifier is exactly this with a = the one-hot true label and b = the softmax output. For a true class 2 and prediction (0.2, 0.7, 0.1), the loss is −log 0.7 ≈ 0.357. Since H(one-hot) = 0, minimising cross-entropy is minimising KL from the true label distribution to the prediction.

**The key limitation.** All three measures compare a and b point by point. They never use **how far apart** the points are, so moving mass to a neighbouring bin and moving it to the opposite end look equally bad. Section 1 shows why this is a serious problem, and the rest of the tutorial fixes it.

### P4. Vectors, matrices and multivariate Gaussians

**Norms.** For a vector v, ‖v‖ = √(Σₖ vₖ²) is its Euclidean length, and ⟨u, v⟩ = Σₖ uₖvₖ is the dot product. For a matrix W there are two common sizes. The **Frobenius norm** ‖W‖\_F = √(Σᵢⱼ Wᵢⱼ²) treats W as one long vector. The **spectral norm** ‖W‖₂ is the largest factor by which W can stretch a vector, max ‖Wv‖/‖v‖ (its largest singular value). Always ‖W‖₂ ≤ ‖W‖\_F. Example: W = \[\[1, 2\], \[2, 1\]\] has ‖W‖\_F = √10 ≈ 3.16 and ‖W‖₂ = 3, since W(1, 1) = (3, 3).

**Trace and eigenvalues.** The trace tr(A) is the sum of the diagonal entries of a square matrix, and equals the sum of its eigenvalues. A symmetric matrix can be written A = UΛUᵀ, where the columns of U are orthonormal eigenvectors and Λ is the diagonal matrix of eigenvalues.

**Mean vector and covariance matrix.** For a random vector X in ℝᵈ, the mean is m = E X and the covariance matrix is Σ = E\[(X − m)(X − m)ᵀ\]. Entry Σᵢⱼ is Cov(Xᵢ, Xⱼ), and the diagonal holds the variances. Σ is symmetric and **positive semi-definite (PSD)**: vᵀΣv = Var(vᵀX) ≥ 0 for every v, so all its eigenvalues are ≥ 0.

**Multivariate Gaussian.** N(m, Σ) is the bell-shaped distribution on ℝᵈ with mean m and covariance Σ. Its density contours are ellipses whose axes are the eigenvectors of Σ, with lengths proportional to the square roots of the eigenvalues. Example: N((0, 0), diag(1, 4)) has independent coordinates with standard deviations 1 and 2. Any linear projection ⟨θ, X⟩ of a Gaussian is a 1D Gaussian with variance θᵀΣθ.

**Matrix square root.** For a PSD matrix S = UΛUᵀ, the square root is S^{1/2} = UΛ^{1/2}Uᵀ: take square roots of the eigenvalues. It is the unique PSD matrix with S^{1/2}S^{1/2} = S. Example: diag(4, 9)^{1/2} = diag(2, 3). For S = \[\[2, 1\], \[1, 2\]\] (eigenvalues 3 and 1, eigenvectors (1, 1)/√2 and (1, −1)/√2), S^{1/2} = ½\[\[√3 + 1, √3 − 1\], \[√3 − 1, √3 + 1\]\] ≈ \[\[1.366, 0.366\], \[0.366, 1.366\]\]. In code: `scipy.linalg.sqrtm`. Two matrices **commute** if AB = BA; diagonal matrices always commute, and that case makes Section 7's formula much simpler.

### P5. Four inequalities used in the proofs

1. **Cauchy–Schwarz.** abs(⟨u, v⟩) ≤ ‖u‖·‖v‖. For random variables: abs(Cov(X, Y)) ≤ σ\_X·σ\_Y, so correlations lie in \[−1, 1\].
2. **Jensen.** If φ is convex (P7), then φ(E X) ≤ E φ(X). Example with φ(x) = x²: (E X)² ≤ E X², which says variance is non-negative. A consequence used in Section 5: the "average size" (E Dᵖ)^{1/p} of a non-negative quantity D can only grow as p grows.
3. **Minkowski.** (E abs(U + V)ᵖ)^{1/p} ≤ (E abs(U)ᵖ)^{1/p} + (E abs(V)ᵖ)^{1/p} for p ≥ 1: the triangle inequality for this way of measuring the size of a random variable. For p = 1 it follows from abs(U + V) ≤ abs(U) + abs(V).
4. **Law of total variance.** Var(Y) = Var(E\[Y | X\]) + E\[Var(Y | X)\]: total spread = spread of the group means + average spread within groups. Example: flip a fair coin X; if heads, Y is 0 or 2 with equal chance; if tails, Y is 4 or 6. Var(Y) = 5 = Var of the group means {1, 5} (which is 4) + average within-group variance (which is 1).

### P6. When do distributions get close? Convergence in distribution

A sequence of distributions Pₙ **converges in distribution** (also called **weak convergence**) to P if the CDFs satisfy Fₙ(x) → F(x) at every point x where F is continuous. Equivalently, E f(Xₙ) → E f(X) for every bounded continuous function f. You have met one instance already: the central limit theorem. Two more:

- δ\_{1/n} → δ₀: a point mass sliding toward 0 converges to the point mass at 0. (Fₙ(0) = 0 for all n while F(0) = 1, but 0 is a jump point of F, so it is excluded.)
- Empirical distributions converge to the true one: P̂ₙ → P as n → ∞ (with probability 1).

Notice that convergence in distribution allows a tiny amount of mass to sit very far away, since that tiny mass barely changes any probability. Section 5.5 shows that EMD reacts to such far-away mass, and so is a stricter notion of closeness. "With probability 1" and **almost surely** mean the same thing: the statement can fail only on an event of probability zero.

### P7. Convexity, linear programs and the envelope theorem

**Convex functions.** f is convex if the chord between any two points of its graph lies on or above the graph: f(λx + (1 − λ)y) ≤ λf(x) + (1 − λ)f(y) for λ ∈ \[0, 1\]. Examples: x², abs(x), any linear function, and the maximum of several convex functions. f is **concave** if −f is convex; the minimum of several linear (or concave) functions is concave. A convex function's local minimum is a global minimum, which is why convex problems are "easy".

**Linear programs (LPs).** An LP minimises a linear function subject to linear equality and inequality constraints. Tiny example: minimise x + 2y subject to x + y = 1, x ≥ 0, y ≥ 0. The feasible set is the segment from (1, 0) to (0, 1); the objective is 1 at (1, 0) and 2 at (0, 1), so the minimum is **1 at the corner (1, 0)**. This is general: the feasible set of an LP is a **polyhedron** (a flat-sided region, possibly unbounded); when it is bounded it is called a **polytope**, and a linear function on a polytope attains its minimum at a corner (vertex). (On an unbounded polyhedron the minimum may not exist at all, for example minimise x subject to x ≤ 0.) The transportation polytope of Section 3 is bounded, so the vertex rule applies to it. Discrete EMD is an LP (Section 3); Section 4 shows how to solve it, and Sections 4.4 and 8.1 introduce **duality**, a second LP whose optimal value equals the first.

**Lagrange multipliers in one line.** To minimise g(x) subject to h(x) = c, add a multiplier λ and work with g(x) + λ(c − h(x)). The multiplier is the "price" of the constraint: how much the optimal value changes per unit change of c. Section 8.1 uses exactly this idea.

**The envelope theorem.** Suppose V(θ) = min over x of g(x, θ), with a unique minimiser x\*(θ). Then

$$
V'(\theta) = \frac{\partial g}{\partial \theta}\big(x^*(\theta),\theta\big),
$$

that is, you may differentiate as if the minimiser were frozen. The reason: at the minimiser ∂g/∂x = 0, so a small shift of x\* has no first-order effect. Example: g(x, θ) = (x − θ)² + x² has minimiser x\* = θ/2 and V(θ) = θ²/2, so V′(θ) = θ. The envelope formula gives ∂g/∂θ = −2(x\* − θ) = −2(θ/2 − θ) = θ, the same answer. Sections 8.6 and 9.2 use this to differentiate EMD and the WGAN loss.

### P8. Lipschitz functions: functions with bounded slope

f is **K-Lipschitz** if abs(f(x) − f(y)) ≤ K·‖x − y‖ for all x, y: its output never changes faster than K times the input change. For differentiable f, the best K is the largest slope, max abs(f′) in 1D or max ‖∇f‖ in several dimensions.

- abs(x), ReLU(x) and sin(x) are 1-Lipschitz; 3x is 3-Lipschitz.
- x² is not Lipschitz on all of ℝ, because its slope 2x is unbounded.
- A linear layer x ↦ Wx is ‖W‖₂-Lipschitz (P4).
- Compositions multiply constants: if f is K₁-Lipschitz and g is K₂-Lipschitz, then f∘g is K₁K₂-Lipschitz. So an MLP with ReLU activations is Lipschitz with constant at most the product of its layers' spectral norms.

Sections 8 and 9 show that EMD is the largest gap E\_P f − E\_Q f achievable by a 1-Lipschitz "scoring" function f, which is why controlling the Lipschitz constant of a neural network matters for WGANs.

### P9. Neural-network tools beyond the MLP

- **Mini-batches and optimisers.** Training estimates the loss on a random mini-batch and takes a gradient step. **RMSProp** divides each parameter's step by the square root of a running average of its recent squared gradients, so parameters with large, noisy gradients take smaller steps. **Adam** adds momentum (a running average of the gradients themselves); its two "beta" hyperparameters set how fast those averages forget.
- **Autograd.** PyTorch records the operations that produce a loss and computes all gradients with `loss.backward()`. `x.detach()` cuts the record, so no gradient flows back through x. `torch.autograd.grad(..., create_graph=True)` returns a gradient that is itself differentiable, so a loss can depend on a gradient ("double backpropagation"); the WGAN-GP penalty in Section 9.4 needs this.
- **Normalisation layers.** **Batch normalisation** standardises each feature using the mean and variance of the current mini-batch, so one sample's output depends on the other samples. **Layer normalisation** uses the statistics of each sample on its own.
- **Pretrained feature extractors.** A network trained on a large dataset (for example Inception-v3 trained on ImageNet) produces intermediate activations that work as general-purpose image descriptors. FID (Section 7.5) compares images through such features.
- **Spectral normalisation and weight clipping.** Two ways of limiting a network's Lipschitz constant (P8): divide each weight matrix by its spectral norm, or force every weight into a small interval \[−c, c\].
- **Floating-point limits.** In float32 (PyTorch's default), numbers below about 1.2 × 10⁻³⁸ ≈ e^−87 lose precision, and nothing below about 1.4 × 10⁻⁴⁵ ≈ e^−103 can be stored at all. The corresponding limits for float64 are about e^−708 and e^−744. Smaller values **underflow** to 0, which matters for Sinkhorn in Section 10.

### P10. Generative models and other ML settings, from scratch

A **generative model** learns to produce new samples that look like the training data. Most deep generative models start from random noise z \~ N(0, I) and transform it with a neural network. The distribution of the outputs is called P\_θ (θ = the network's weights), and training tries to make P\_θ close to the data distribution. That is exactly where a distance between distributions such as EMD is needed.

**GANs (generative adversarial networks).** Two MLPs (or CNNs) are trained against each other. The **generator** g\_θ maps noise z to a fake sample g\_θ(z). The **discriminator** D outputs the probability that its input is real; it is trained as an ordinary binary classifier (real = 1, fake = 0), while the generator is trained to make D output "real" on its fakes. Training alternates between the two networks, which is called a min-max game. Section 9 shows why the original loss can stall and how EMD (the Wasserstein GAN) fixes it.

**Flow matching and diffusion models.** Instead of jumping from noise to data in one network evaluation, these models move a sample gradually. A network v\_θ(t, x), an MLP taking the current point x and the time t ∈ \[0, 1\], outputs a **velocity**, and samples follow the ordinary differential equation (ODE) dx/dt = v\_θ(t, x) from noise at t = 0 to data at t = 1. In practice the ODE is solved with **Euler steps**: x ← x + Δt·v\_θ(t, x), and each step costs one network evaluation. Fewer steps means faster generation, but only if the paths are nearly straight. Example: for dx/dt = −x starting at x = 1, the exact value at t = 1 is e^−1 ≈ 0.368; one Euler step gives 0, four steps give 0.316, and 100 steps give 0.366. A curved path needs many steps; a straight path with constant velocity is exact in one step. Section 12.1 shows how optimal transport makes the paths straighter. **Diffusion models** follow the same idea with added randomness, and **normalising flows** use invertible networks whose likelihood can be computed exactly.

**Domain adaptation.** A classifier is trained on labelled data from one distribution (the **source**, for example synthetic images) and deployed on another (the **target**, real images) for which no labels are available. Performance drops because the input distributions differ. Section 12.2 uses EMD to measure and reduce that difference.

**Point clouds.** A 3D shape scanned by a LiDAR or depth camera is stored as an unordered set of points (x, y, z). Networks that predict shapes output such sets, so their loss must compare two sets of points, which is again a distance between (empirical) distributions (Section 12.3).

### P11. Optional advanced notions (only in proofs and remarks)

You can skip these on a first reading; each appears only where noted.

- **Push-forward (5.1, 11).** T#P is the distribution of T(X) when X \~ P. Example: X \~ Uniform\[0, 1\] and T(x) = 2x give T#P = Uniform\[0, 2\].
- **Radon–Nikodym derivative (1.3).** The density of one distribution relative to another, dP/dM. If both have densities p and m it is simply p(x)/m(x); for discrete distributions it is the ratio of probabilities.
- **Essential supremum (5.4).** The largest value a random variable takes with positive probability, ignoring events of probability zero.
- **Characteristic function and the Cramér–Wold theorem (11.2).** The characteristic function E\[exp(i⟨u, X⟩)\] determines a distribution completely. Cramér–Wold: a distribution on ℝᵈ is determined by the distributions of all its 1D projections ⟨θ, X⟩. This is why comparing projections (sliced Wasserstein) can detect any difference.
- **Kernels and MMD (10.7).** A kernel k(x, y) is a similarity score, for example k(x, y) = exp(−‖x − y‖²/(2s²)). The maximum mean discrepancy compares distributions through average similarities: MMD² = E k(X, X′) + E k(Y, Y′) − 2E k(X, Y), with X, X′ \~ P and Y, Y′ \~ Q independent.
- **Brownian motion (12.7).** A continuous-time random walk: over any time interval of length Δt it moves by an independent N(0, σ²Δt) step. It is the "pure noise" process behind diffusion models.
- **Complete separable metric spaces (5.2).** A technical condition under which the theorems hold. ℝᵈ satisfies it; you can read the phrase as "ℝᵈ or a similarly well-behaved space".

### Where each concept is first used

| Concept | Primer | First used in |
| --- | --- | --- |
| Dirac masses, empirical distributions, i.i.d. samples | P1 | Notation table, 1.3, 5.6 |
| CDF, quantile function | P2 | 6 |
| Total variation, KL, JS | P3 | 1 |
| Entropy, cross-entropy | P3 | 10 |
| Norms, trace, PSD matrices, matrix square root, multivariate Gaussians | P4 | 7, 11.3 |
| Cauchy–Schwarz, Jensen, Minkowski | P5 | 5.3, 5.4, 7.2 |
| Law of total variance | P5 | 15.21 |
| Convergence in distribution, "almost surely" | P6 | 5.5, 15.12 |
| Convexity, linear programs | P7 | 2.2, 3, 4 |
| Lagrange multipliers, duality | P7 | 4.4, 8.1 |
| Envelope theorem | P7 | 8.6, 9.2 |
| Lipschitz functions | P8 | 8, 9 |
| Adam, RMSProp, autograd, normalisation layers, pretrained features | P9 | 7.5, 9 |
| Floating-point underflow | P9 | 10.6, 13.4 |
| GANs (generator, discriminator) | P10 | 1.3, 9 |
| Flow matching, ODEs, Euler steps, diffusion models | P10 | 9.5, 12.1 |
| Domain adaptation, point clouds | P10 | 12.2, 12.3 |
| Push-forward, Radon–Nikodym, essential supremum, Cramér–Wold, MMD, Brownian motion | P11 | 1.3, 5, 10.7, 11.2, 12.7 |

### Check yourself (Primer)

1. For a = (0.2, 0.8) and b = (0.5, 0.5), compute TV(a, b) and KL(a ‖ b).
2. Samples 3, 1, 2, 2. Write the empirical distribution and find its quantiles F⁻¹(0.5) and F⁻¹(0.9).
3. What is the Lipschitz constant of f(x) = 3·ReLU(2x − 1)?
4. Σ = diag(4, 1). Give tr(Σ) and Σ^{1/2}.
5. Starting at x = 0, a velocity field is constant, v(t, x) = 2. How many Euler steps are needed to reach the exact value at t = 1?

**Answers.** (1) TV = ½(0.3 + 0.3) = 0.3; KL = 0.2 log(0.4) + 0.8 log(1.6) ≈ −0.183 + 0.376 = **0.193**. (2) P̂ = ¼δ₁ + ½δ₂ + ¼δ₃, so F = 0.25, 0.75, 1 at 1, 2, 3; F⁻¹(0.5) = **2** (the first point where F ≥ 0.5) and F⁻¹(0.9) = **3**. (3) **6**: the inner map has slope 2, ReLU has slope at most 1, and the outer factor is 3. (4) tr(Σ) = 5 and Σ^{1/2} = diag(2, 1). (5) **One**: with constant velocity the path is a straight line, and a single step x ← 0 + 1·2 = 2 is exact.

## 1. Motivation: why we need a geometry-aware distance between distributions

The usual ways of comparing two distributions (KL divergence, Jensen–Shannon divergence and total variation, all defined in Primer P3) compare them **point by point** and ignore how far apart the points are; EMD compares them **through the geometry of the space**, so it still gives a useful, smooth answer when the distributions do not overlap.

### 1.1 Where comparing distributions shows up

Engineers compare distributions all the time: a histogram of pixel colours in two images, the distribution of sensor readings this week versus last month (drift detection), the distribution of real images versus images produced by a generator, features from a training domain versus a deployment domain. In each case we want a single number that is small when the two are "similar" and large when they are "different", and, in deep learning, we often want to differentiate that number with respect to network parameters.

### 1.2 The bin-by-bin problem: a histogram example

Consider three histograms over 10 bins labelled 1 to 10 (think of them as grey-level histograms of three tiny images). Each puts all its mass in one bin:

- A: all mass in bin 1.
- B: all mass in bin 2.
- C: all mass in bin 10.

Intuitively, B is very close to A (shift by one grey level) and C is far from A. Now compute a bin-by-bin distance such as the L1 distance Σₖ |Aₖ − Bₖ|: it equals 2 for A vs B and also 2 for A vs C. KL divergence is +∞ in both cases (A puts mass where B and C have zero). Bin-by-bin measures cannot tell "slightly shifted" from "completely different", because they never ask **how far** mass has to move.

EMD asks exactly that: the cheapest cost to move A's mass to B's location is 1 unit of mass × distance 1 = **1**; to C's location it is 1 × 9 = **9**. That is the answer our intuition wanted.

### 1.3 The disjoint-support problem: the classic WGAN example

This example (from Arjovsky, Chintala and Bottou, 2017) is asked in interviews constantly. Let Z \~ Uniform\[0, 1\]. Define two distributions on the plane:

- P₀: the distribution of (0, Z), a vertical line segment at x = 0.
- P\_θ: the distribution of (θ, Z), the same segment shifted to x = θ.

For θ ≠ 0 the two segments never overlap. Compute four quantities (all logs natural):

| Measure | Value when θ ≠ 0 | Value when θ = 0 | Useful gradient in θ? |
| --- | --- | --- | --- |
| KL(P₀ ‖ P\_θ) | +∞ | 0 | No (infinite) |
| JS(P₀, P\_θ) | log 2 ≈ 0.693 | 0 | No (constant, gradient 0) |
| Total variation | 1 | 0 | No (constant, gradient 0) |
| W₁ = EMD | abs(θ) | 0 | Yes: derivative sign(θ); the descent direction −sign(θ) points toward 0 |

![](figures/fig1_disjoint.png)

*Figure 1. The three measures for the shifted segments. JS and TV jump to a constant as soon as θ ≠ 0, so their gradient is zero; W₁ = abs(θ) grows with the shift and always points back toward θ = 0.*

**Derivation of each value.** Recall from Primer P3 that JS(P, Q) = ½ KL(P ‖ M) + ½ KL(Q ‖ M) with M = ½(P + Q). When P and Q are disjoint, M gives every subset of P's support exactly half the mass P gives it, so the density of P with respect to M (the Radon–Nikodym derivative dP/dM, Primer P11) equals 2 there, and KL(P ‖ M) = E\_P\[log(dP/dM)\] = log 2; likewise KL(Q ‖ M) = log 2, giving JS = log 2. Total variation sup over events A of abs(P(A) − Q(A)) equals 1 by taking A = the support of P. KL(P₀ ‖ P\_θ) is infinite because P₀ assigns positive probability to a region where P\_θ is zero. For EMD: moving every point (0, z) horizontally to (θ, z) costs abs(θ) per unit mass, so the total is abs(θ); no plan can do better, because every unit of mass must travel at least horizontal distance abs(θ) (Exercise 15.6 turns this into a formal proof using the duality of Section 8).

**Why this matters for learning.** Suppose a generator (a network that turns random noise into samples, Primer P10) with parameter θ produces P\_θ and we train it by gradient descent on a loss L(θ). With JS or TV the loss is flat for every θ ≠ 0, so the gradient is zero and learning stalls. With KL the loss is infinite. With EMD the loss is abs(θ), whose gradient always points toward the target. In high dimensions, real images lie near a thin low-dimensional surface and so do generated images; such surfaces generically do not overlap, so this toy picture is the typical situation, not a corner case. This is the core motivation of Wasserstein GANs (Section 9).

### 1.4 Three properties that make EMD attractive

1. **It uses the ground distance.** You choose what "far" means: Euclidean distance between pixels, distance between colours in a perceptual colour space, distance between word embeddings, and so on.
2. **It is a true metric** on distributions (Section 5): non-negative, zero only for identical distributions, symmetric, and satisfies the triangle inequality.
3. **It is continuous under small shifts.** If you move all mass by a distance ε, EMD changes by at most ε. KL and JS can jump from 0 to their maximum under an arbitrarily small shift.

The price is computation: EMD is the solution of an optimisation problem, not a closed-form sum. Much of this tutorial is about computing it efficiently.

### Check yourself (Section 1)

1. Two histograms on bins 1..100: A has all mass in bin 30, B all mass in bin 31. What are the L1 bin distance and the EMD (bin spacing 1)?
2. Why is JS = log 2 a problem for gradient-based training, even though it is finite?
3. Give a real engineering situation where two distributions you want to compare have (almost) disjoint supports.

**Answers.** (1) L1 distance = 2 (abs(1 − 0) + abs(0 − 1)); EMD = 1. (2) Because it is constant in θ for every θ ≠ 0, so its derivative is 0 and gives no direction to move. (3) Examples: generated vs real images early in GAN training; spectra of two narrowband signals at different centre frequencies; grey-level histograms of the same scene under two very different exposures.

## 2. Intuition: piles of earth and holes

EMD is the minimum total work (mass × distance) needed to reshape one pile of earth into another, where you are free to decide which shovelful goes where.

### 2.1 The picture

Imagine distribution P as piles of earth sitting at locations x₁,…,xₙ, with pile i containing aᵢ units of earth (total 1). Distribution Q is a set of holes at locations y₁,…,yₘ, with hole j able to take exactly bⱼ units (total 1). Moving one unit of earth from xᵢ to yⱼ costs c(xᵢ, yⱼ), typically the distance between them. A **transport plan** says how much earth γᵢⱼ goes from pile i to hole j. EMD is the cost of the cheapest plan that empties every pile and fills every hole exactly.

The problem was posed by the French engineer Gaspard Monge in 1781 (moving soil dug out for fortifications into embankments), and solved in its modern form by Leonid Kantorovich in 1942, who used it for economic planning. That is why the field is called **optimal transport (OT)**.

Two observations that you should keep in mind:

- **Units.** If locations are in metres and c is distance, EMD is in metres: it is "the average distance a unit of mass must travel". KL and JS have no such physical unit.
- **Mass may be split.** A single pile can be divided among several holes. This flexibility (Kantorovich's relaxation) is what makes the problem a well-behaved linear program.

### 2.2 Worked example: one-parameter family of plans

On the real line, let P put mass 0.5 at x = 0 and 0.5 at x = 2. Let Q put mass 0.25 at y = 1 and 0.75 at y = 3. Cost = distance, c(x, y) = abs(x − y).

**Step 1: list the costs.**

| From \\ To | y = 1 (needs 0.25) | y = 3 (needs 0.75) |
| --- | --- | --- |
| x = 0 (has 0.5) | 1 | 3 |
| x = 2 (has 0.5) | 1 | 1 |

**Step 2: describe every valid plan.** Let α = mass moved from 0 to 1. The constraints force the other three entries:

- from 0 to 3: 0.5 − α (pile at 0 must be emptied);
- from 2 to 1: 0.25 − α (hole at 1 must receive exactly 0.25);
- from 2 to 3: 0.5 − (0.25 − α) = 0.25 + α.

All entries must be non-negative, so 0 ≤ α ≤ 0.25.

**Step 3: total cost as a function of α.**

$$
\text{cost}(\alpha) = 1\cdot\alpha + 3(0.5-\alpha) + 1\cdot(0.25-\alpha) + 1\cdot(0.25+\alpha) = 2 - 2\alpha
$$

**Step 4: minimise.** The cost decreases in α, so the best choice is α = 0.25: move 0.25 from 0 to 1, 0.25 from 0 to 3, and 0.5 from 2 to 3. The minimum cost is **EMD = 2 − 0.5 = 1.5**.

**What to learn from this.** (i) The cost is linear in the plan, and the feasible plans form a segment (in general a polytope), so the optimum sits at an end point (in general a vertex). (ii) The optimal plan is **monotone**: mass from the leftmost pile goes to the leftmost hole first, and arrows never cross. Section 6 proves that in 1D this always works, which leads to a sorting algorithm. (iii) The worst plan (α = 0) costs 2.0; a careless plan can be far from optimal.

![](figures/fig2_transport.png)

*Figure 2. The optimal plan of Example 2.2: piles of P on top, holes of Q below, arrow width proportional to the mass carried. The pile at 0 splits, and no two arrows cross.*

### 2.3 Worked example: shifting a whole distribution

Let P be any distribution on ℝᵈ and let Q be P shifted by a fixed vector v (if X \~ P then X + v \~ Q). The plan "move every point x to x + v" costs ‖v‖ per unit of mass, so EMD(P, Q) ≤ ‖v‖. Exercise 15.6 proves it is in fact equal to ‖v‖, using the duality of Section 8. So **EMD of a translation equals the length of the translation**, whatever the shape of P. Compare: KL between N(0, σ²) and N(v, σ²) is v²/(2σ²), which depends on σ and blows up as σ → 0, while EMD stays abs(v).

### 2.4 Worked example: equal-size point clouds

Let P be uniform on three points and Q uniform on three points (each point has mass 1/3). An optimal plan can then be chosen to be a **one-to-one matching** (a permutation): send each point of P to exactly one point of Q (Section 4.3 proves why). Take P on {0, 4, 10} and Q on {1, 5, 6} on the real line. Matching sorted to sorted, 0→1, 4→5, 10→6, costs (1 + 1 + 4)/3 = 2. A crossing matching such as 0→5, 4→1, 10→6 costs (5 + 3 + 4)/3 = 4. Matching sorted order is optimal (Section 6), so **EMD = 2**.

### Check yourself (Section 2)

1. In Example 2.2, what plan does α = 0 correspond to, and why is it worse?
2. P = δ₀ (all mass at 0) and Q = ½δ₋₁ + ½δ₁. Compute EMD with cost abs(x − y).
3. If you measure positions in centimetres instead of metres, how does EMD change? How does KL change?
4. Why is a plan with crossing arrows in 1D never better than the non-crossing one, for cost abs(x − y)?

**Answers.** (1) α = 0 sends all of pile 0 to hole 3 (distance 3) and splits pile 2 between holes 1 and 3; the long trip 0→3 carries 0.5 instead of 0.25, which wastes 2 × 0.25 = 0.5 of cost. (2) The pile at 0 must split in half: 0.5 × 1 + 0.5 × 1 = **1**. (3) EMD is multiplied by 100 (it has units of length). KL is unchanged (it is invariant to invertible reparametrisation of the space). (4) If x₁ < x₂ and y₁ < y₂, then abs(x₁ − y₁) + abs(x₂ − y₂) ≤ abs(x₁ − y₂) + abs(x₂ − y₁); uncrossing two arrows never increases cost. Exercise 15.4 asks you to prove this inequality.

## 3. Discrete EMD as a linear program

For discrete distributions, EMD is the optimal value of a linear program (LP) whose variable is the transport plan γ, an n × m matrix whose row sums are a and column sums are b.

### 3.1 Formal definition (balanced case)

Let P = Σᵢ aᵢ δ\_{xᵢ} and Q = Σⱼ bⱼ δ\_{yⱼ} with aᵢ, bⱼ ≥ 0 and Σᵢ aᵢ = Σⱼ bⱼ = 1. Let Cᵢⱼ = c(xᵢ, yⱼ) be the ground cost. Define the set of **transport plans** (also called **couplings**):

$$
\Pi(a,b) = \left\{ \gamma \in \mathbb{R}^{n\times m} \;:\; \gamma_{ij} \ge 0,\;\; \sum_{j=1}^{m} \gamma_{ij} = a_i \;\forall i,\;\; \sum_{i=1}^{n} \gamma_{ij} = b_j \;\forall j \right\}
$$

In matrix form the constraints read γ𝟙ₘ = a (row sums) and γᵀ𝟙ₙ = b (column sums). The optimal transport cost is

$$
\mathrm{OT}_C(a,b) \;=\; \min_{\gamma \in \Pi(a,b)} \; \langle \gamma, C \rangle \;=\; \min_{\gamma \in \Pi(a,b)} \sum_{i=1}^{n}\sum_{j=1}^{m} \gamma_{ij}\, C_{ij}
$$

When the ground cost is a distance, Cᵢⱼ = d(xᵢ, yⱼ), this value is the **EMD**, also written W₁(P, Q). When Cᵢⱼ = d(xᵢ, yⱼ)ᵖ with p ≥ 1, the value is Wₚ(P, Q)ᵖ, and its p-th root is the p-Wasserstein distance (Section 5).

**Read each piece aloud.** "Row i of γ lists where pile i's earth goes, so it must add up to the size of pile i. Column j lists where hole j's earth comes from, so it must add up to the size of hole j. Every entry is non-negative because you cannot move negative earth. The cost is the sum over all routes of amount × price."

### 3.2 Probabilistic reading: couplings

Because γᵢⱼ ≥ 0 and Σᵢⱼ γᵢⱼ = Σᵢ aᵢ = 1, a plan γ is a **joint PMF** of a pair of random variables (X, Y) taking values X = xᵢ, Y = yⱼ with probability γᵢⱼ. The row-sum constraint says the marginal of X is P; the column-sum constraint says the marginal of Y is Q. So:

$$
\mathrm{OT}_c(P,Q) \;=\; \min_{(X,Y)\,:\; X\sim P,\; Y\sim Q} \; \mathbb{E}\left[c(X,Y)\right]
$$

The minimum is over all ways to make X and Y dependent while keeping their marginals fixed. This is the form you will see in papers, often written with π or γ ∈ Π(P, Q) and E\_{(x,y)\~γ}\[c(x, y)\].

**A free upper bound.** The independent coupling γ = abᵀ (that is, γᵢⱼ = aᵢbⱼ) is always feasible: its row sums are aᵢ Σⱼ bⱼ = aᵢ. Hence OT\_c(P, Q) ≤ E\[c(X, Y)\] with X and Y independent. For P = Q this bound is generally not zero (independent copies of X are rarely equal), which shows why the optimisation matters: the optimal coupling for P = Q is the "diagonal" one, X = Y, with cost 0.

### 3.3 Worked example: three warehouses, three stores

Three warehouses hold fractions a = (0.3, 0.3, 0.4) of a product; three stores need b = (0.1, 0.4, 0.5). Shipping cost per unit:

| From \\ To | S1 (needs 0.1) | S2 (needs 0.4) | S3 (needs 0.5) |
| --- | --- | --- | --- |
| W1 (has 0.3) | 6 | 6 | 3 |
| W2 (has 0.3) | 1 | 2 | 2 |
| W3 (has 0.4) | 1 | 3 | 7 |

The LP has 9 variables γ₁₁,…,γ₃₃ and 6 equality constraints:

$$
\begin{aligned}
&\gamma_{11}+\gamma_{12}+\gamma_{13}=0.3, \quad \gamma_{21}+\gamma_{22}+\gamma_{23}=0.3, \quad \gamma_{31}+\gamma_{32}+\gamma_{33}=0.4,\\
&\gamma_{11}+\gamma_{21}+\gamma_{31}=0.1, \quad \gamma_{12}+\gamma_{22}+\gamma_{32}=0.4, \quad \gamma_{13}+\gamma_{23}+\gamma_{33}=0.5,\\
&\gamma_{ij}\ge 0 .
\end{aligned}
$$

Section 4 solves it: the optimum is **2.5**. Keep this example in mind; we will reuse it for duality.

### 3.4 The minimum always exists

**Claim.** For any a, b with equal total mass and any finite cost matrix C, the minimum in 3.1 is attained.

**Proof.** (i) Π(a, b) is non-empty because abᵀ belongs to it. (ii) It is closed, being defined by finitely many linear equalities and non-strict inequalities. (iii) It is bounded: 0 ≤ γᵢⱼ ≤ min(aᵢ, bⱼ) ≤ 1. So Π(a, b) is a compact subset of ℝⁿˣᵐ. The objective ⟨γ, C⟩ is linear, hence continuous, so by the extreme value (Weierstrass) theorem it attains its minimum. ∎

Geometrically, Π(a, b) is a convex polytope called the **transportation polytope**. A linear function over a polytope is minimised at a vertex, a fact we exploit in Section 4.

### 3.5 Counting variables and constraints

There are nm variables and n + m equality constraints, but the constraints are not independent: summing all row constraints gives Σᵢⱼ γᵢⱼ = Σᵢ aᵢ, and summing all column constraints gives the same left side with Σⱼ bⱼ. Since Σa = Σb, one constraint is redundant, so the constraint matrix has rank n + m − 1. This number matters: it bounds how many routes an optimal vertex plan uses (Section 4.2).

### 3.6 Choosing the ground cost

| Ground cost Cᵢⱼ | Name of the result | Typical use |
| --- | --- | --- |
| ‖xᵢ − yⱼ‖ (a metric d) | EMD = W₁ | Histogram and image retrieval, WGAN, point clouds |
| ‖xᵢ − yⱼ‖² | W₂² (squared 2-Wasserstein) | Flow matching, Gaussians, barycenters, colour transfer |
| abs(i − j) for bin indices i, j | 1D histogram EMD | Grey-level histograms, ordinal labels |
| 1 if i ≠ j, 0 otherwise | Total variation distance | Shows TV is a special case of OT with a "blind" cost |
| ‖xᵢ − yⱼ‖ between word embeddings (Euclidean, as in the original Word Mover's Distance; some later variants use 1 − cosine similarity) | Word Mover's Distance | Comparing documents as bags of word vectors |

The 0–1 cost row is worth remembering: with that cost, OT equals the total variation distance ½Σₖ abs(aₖ − bₖ) for distributions on the same points (Exercise 15.5). So total variation is "EMD that cannot see distance", which is exactly why it fails in Section 1.

### 3.7 Unequal total mass: Rubner's EMD and its modern successors

The original computer-vision EMD (Rubner, Tomasi, Guibas, 2000) compared **signatures**: clusters with centres and weights that need not sum to the same total. With supplies wᵢ (total W) and demands uⱼ (total U), it solves

$$
\min_{f\ge 0} \sum_{i,j} f_{ij}\, d_{ij} \quad \text{s.t.}\quad \sum_j f_{ij} \le w_i,\;\; \sum_i f_{ij} \le u_j,\;\; \sum_{i,j} f_{ij} = \min(W,U)
$$

and defines EMD = (Σ fᵢⱼ dᵢⱼ) / (Σ fᵢⱼ), the cost normalised by the total flow. When W = U = 1 this reduces exactly to W₁. When W ≠ U it performs **partial matching**: the smaller signature is matched into part of the larger one. Caution: with unequal masses this quantity is **not a metric** in general (for example, a signature that is a subset of another can be at distance 0 from it). Modern alternatives you will meet in papers are **partial OT** (transport a fixed fraction of mass), **unbalanced OT** (replace hard marginal constraints by KL penalties, Chizat et al. 2018), and Pele–Werman's EMD-hat (adds a penalty proportional to the mass difference). In deep learning you almost always normalise both sides to probability vectors and use the balanced definition 3.1.

### Check yourself (Section 3)

1. Write Π(a, b) for a = (1) (a single point) and arbitrary b. What is the unique plan, and what is the EMD?
2. Verify that γ = abᵀ satisfies the column constraints.
3. In the warehouse example, why must the optimal plan use at most 5 routes (nonzero entries) at a vertex?
4. A paper writes "W(P, Q) = inf over γ ∈ Π(P, Q) of E\_{(x,y)\~γ} ‖x − y‖". Which of our quantities is this?

**Answers.** (1) With n = 1, the only plan is γ₁ⱼ = bⱼ: the single pile is split among all holes. EMD = Σⱼ bⱼ c(x₁, yⱼ), the expected cost under Q. (2) Column j sums to Σᵢ aᵢbⱼ = bⱼ Σᵢ aᵢ = bⱼ. (3) A vertex of an LP in standard form has at most rank-many nonzero (basic) variables, here n + m − 1 = 5 (proved in 4.2). (4) It is W₁, the EMD, written for general distributions (inf instead of min; Section 5 explains why).

## 4. Solving the transportation LP

An optimal plan can always be found at a vertex of the transportation polytope; such a vertex uses at most n + m − 1 routes arranged as a tree, and its optimality can be certified by "potentials" u, v. We solve the warehouse example of 3.3 by hand: EMD = 2.5.

### 4.1 Two quick starting plans (and why they are not enough)

**North-west corner rule.** Start at the top-left cell, ship as much as possible, move right if the row's supply is used up or down if the column's demand is met; repeat. It ignores costs completely.

| North-west plan | S1 | S2 | S3 |
| --- | --- | --- | --- |
| W1 | 0.1 | 0.2 | 0 |
| W2 | 0 | 0.2 | 0.1 |
| W3 | 0 | 0 | 0.4 |

Cost = 0.1·6 + 0.2·6 + 0.2·2 + 0.1·2 + 0.4·7 = **5.2**.

**Greedy least-cost rule.** Repeatedly pick the cheapest remaining cell and ship as much as possible through it (ties broken by row order).

| Greedy plan | S1 | S2 | S3 |
| --- | --- | --- | --- |
| W1 | 0 | 0 | 0.3 |
| W2 | 0.1 | 0.2 | 0 |
| W3 | 0 | 0.2 | 0.2 |

Trace: cell (W2,S1) cost 1 takes 0.1 (S1 full); (W3,S1) cost 1 is useless now; (W2,S2) cost 2 takes 0.2 (W2 empty); (W1,S3) cost 3 takes 0.3 (W1 empty); (W3,S2) cost 3 takes 0.2 (S2 full); finally (W3,S3) cost 7 takes the remaining 0.2. Cost = 0.1 + 0.4 + 0.9 + 0.6 + 1.4 = **3.4**. Better, but greedy choices made early force an expensive route (cost 7) at the end. Greedy is **not** optimal in general.

### 4.2 Vertices are trees: at most n + m − 1 routes

Draw a bipartite graph with one node per pile and one per hole, and an edge (i, j) whenever γᵢⱼ > 0. Call it the **support graph** of γ.

**Theorem.** If γ is a vertex (extreme point) of Π(a, b), its support graph has no cycle. Consequently γ has at most n + m − 1 nonzero entries.

![](figures/fig8_support_tree.png)

*Figure 8. The support graph of the optimal warehouse plan of Section 4.5: five routes connecting the three warehouses and three stores, forming a tree (no cycle). Adding any sixth route would close a cycle, along which mass could be pushed in either direction, so the plan would not be a vertex.*

**Proof (optional proof).** Suppose the support graph contains a cycle. In a bipartite graph a cycle alternates pile, hole, pile, hole, so it has even length: (i₁, j₁), (i₂, j₁), (i₂, j₂), …, (i₁, j\_k). Build a matrix D that is +1 on the 1st, 3rd, 5th, … edges of the cycle, −1 on the 2nd, 4th, … edges, and 0 elsewhere. Every row and column touched by the cycle contains exactly one +1 and one −1, so D has zero row sums and zero column sums. Let ε > 0 be smaller than every γᵢⱼ on the cycle. Then γ + εD and γ − εD are both non-negative and have the same marginals as γ, so both lie in Π(a, b), and γ = ½(γ + εD) + ½(γ − εD). A point that is the midpoint of two distinct feasible points is not a vertex, a contradiction. So the support graph is a forest, and a forest on n + m nodes has at most n + m − 1 edges. ∎

**Consequences.** (i) Optimal plans can be chosen **sparse**: out of nm possible routes, at most n + m − 1 are used. For n = m = 1000 that is under 2000 of 10⁶ entries. (ii) Exact OT never "blurs" mass more than necessary; this is a key difference from entropic OT (Section 10), whose plan is fully dense.

### 4.3 Equal-size uniform point clouds: OT becomes assignment

**Theorem (Birkhoff–von Neumann, in OT form).** If n = m and aᵢ = bⱼ = 1/n, every vertex of Π(a, b) is (1/n)·(a permutation matrix). Hence

$$
W_1(P,Q) = \min_{\sigma \in S_n} \frac{1}{n}\sum_{i=1}^{n} d\!\left(x_i, y_{\sigma(i)}\right)
$$

where S\_n is the set of permutations of {1, …, n}.

**Proof (optional proof).** Let γ be a vertex. Every row has at least one nonzero entry (row sum 1/n > 0), so every pile node has degree ≥ 1, and likewise every hole node. By 4.2 the support graph is a forest; a forest with at least one edge has a leaf (a node of degree 1). Say the leaf is pile i with single edge to hole j. Then γᵢⱼ = aᵢ = 1/n, which equals bⱼ, so column j has no other nonzero entry. Remove row i and column j. The remaining entries form a plan between n − 1 piles and n − 1 holes, each of mass 1/n, and its support is still acyclic (a subgraph of a forest). The argument above used only these two properties, an acyclic support and all marginals equal to 1/n, so it applies again. By induction on n, every row is matched to exactly one column with mass 1/n. A leaf that is a hole is handled symmetrically. ∎

This is why the 3-point example in 2.4 could use a matching, and why the "EMD loss" for point clouds of equal size (Section 12) is computed with an assignment solver: `scipy.optimize.linear_sum_assignment` implements an O(n³) algorithm (a Hungarian-type shortest-augmenting-path method).

### 4.4 Certifying optimality with potentials

How do you **prove** a plan is optimal without trying every plan? Find numbers u₁,…,uₙ (one per pile) and v₁,…,vₘ (one per hole), called **potentials** or **dual variables**, such that

$$
u_i + v_j \le C_{ij} \;\;\text{for all } i,j, \qquad\text{and}\qquad u_i + v_j = C_{ij} \;\;\text{whenever } \gamma^*_{ij} > 0 .
$$

**Lemma (optimality certificate).** If a feasible γ\* and potentials u, v satisfy both conditions, then γ\* is optimal and OT = Σᵢ aᵢuᵢ + Σⱼ bⱼvⱼ.

**Proof.** Take any feasible γ. Since γᵢⱼ ≥ 0 and Cᵢⱼ ≥ uᵢ + vⱼ,

$$
\langle \gamma, C\rangle \;\ge\; \sum_{i,j}\gamma_{ij}(u_i+v_j) \;=\; \sum_i u_i \sum_j \gamma_{ij} + \sum_j v_j \sum_i \gamma_{ij} \;=\; \sum_i a_i u_i + \sum_j b_j v_j .
$$

For the plan γ\*, the inequality is an equality, because every term with γ\*ᵢⱼ > 0 has Cᵢⱼ = uᵢ + vⱼ. So the cost of γ\* equals a lower bound that is valid for every plan. ∎

**Economic reading.** Think of uᵢ as a fee a competitor charges for picking up one unit at pile i, and vⱼ as a fee for dropping one unit at hole j. If the competitor's combined fee uᵢ + vⱼ never exceeds your cost Cᵢⱼ on any route, their total revenue Σaᵢuᵢ + Σbⱼvⱼ is a lower bound on the cost of any plan. When your plan only uses routes where their fee equals your cost, the two numbers meet and neither side can improve. Section 8 turns this lemma into the Kantorovich–Rubinstein duality behind WGAN.

### 4.5 Worked example: transportation simplex from the greedy plan

The transportation simplex method repeats three steps: compute potentials from the current tree, find a route with negative **reduced cost** C̄ᵢⱼ = Cᵢⱼ − uᵢ − vⱼ, and push mass around the cycle that route creates.

**Iteration 1 (start: greedy plan, cost 3.4).** Basic cells: (2,1), (2,2), (1,3), (3,2), (3,3). Solve uᵢ + vⱼ = Cᵢⱼ on them, fixing u₂ = 0 (potentials are only defined up to adding t to all u and subtracting t from all v):

- (2,1): v₁ = 1; (2,2): v₂ = 2; (3,2): u₃ = 3 − 2 = 1; (3,3): v₃ = 7 − 1 = 6; (1,3): u₁ = 3 − 6 = −3.

Reduced costs on the non-basic cells: C̄₁₁ = 6 + 3 − 1 = 8, C̄₁₂ = 6 + 3 − 2 = 7, C̄₂₃ = 2 − 0 − 6 = **−4**, C̄₃₁ = 1 − 1 − 1 = −1. A negative value means the plan can be improved. Enter the most negative, (2,3). Adding (2,3) to the tree closes the cycle (2,3)+ → (2,2)− → (3,2)+ → (3,3)−. Per unit of mass pushed, cost changes by 2 − 2 + 3 − 7 = −4 (equal to the reduced cost, as it must). The amount θ we can push is the smallest entry on a "−" cell: min(γ₂₂, γ₃₃) = min(0.2, 0.2) = 0.2. New cost 3.4 − 4 × 0.2 = **2.6**. (Both minus cells hit zero: a degenerate step. We keep (2,2) in the tree with value 0 and drop (3,3).)

**Iteration 2 (cost 2.6).** Plan: γ₁₃ = 0.3, γ₂₁ = 0.1, γ₂₂ = 0 (basic), γ₂₃ = 0.2, γ₃₂ = 0.4. Potentials with u₂ = 0: v₁ = 1, v₂ = 2, v₃ = 2, u₁ = 3 − 2 = 1, u₃ = 3 − 2 = 1. Reduced costs: C̄₁₁ = 4, C̄₁₂ = 3, C̄₃₁ = 1 − 1 − 1 = **−1**, C̄₃₃ = 4. Enter (3,1). Cycle: (3,1)+ → (2,1)− → (2,2)+ → (3,2)−, per-unit change 1 − 1 + 2 − 3 = −1. θ = min(γ₂₁, γ₃₂) = min(0.1, 0.4) = 0.1. New cost 2.6 − 0.1 = **2.5**.

**Iteration 3 (cost 2.5).** Plan:

| Optimal plan γ\* | S1 | S2 | S3 | Row sum |
| --- | --- | --- | --- | --- |
| W1 | 0 | 0 | 0.3 | 0.3 |
| W2 | 0 | 0.1 | 0.2 | 0.3 |
| W3 | 0.1 | 0.3 | 0 | 0.4 |
| Column sum | 0.1 | 0.4 | 0.5 | 1 |

Potentials with u₂ = 0: v₂ = 2, v₃ = 2, u₁ = 1, u₃ = 1, v₁ = 0. Reduced costs on unused cells: C̄₁₁ = 5, C̄₁₂ = 3, C̄₂₁ = 1, C̄₃₃ = 4, all non-negative, so by the lemma the plan is optimal. Check the dual value: Σaᵢuᵢ + Σbⱼvⱼ = (0.3·1 + 0.3·0 + 0.4·1) + (0.1·0 + 0.4·2 + 0.5·2) = 0.7 + 1.8 = **2.5** = primal cost 0.9 + 0.2 + 0.4 + 0.1 + 0.9 = 2.5. The plan uses exactly n + m − 1 = 5 routes, as 4.2 predicts. Because every reduced cost is strictly positive, this optimum is unique.

**Potentials are unique only up to a shift, and every solver picks its own.** We fixed u₂ = 0 and got u = (1, 0, 1), v = (0, 2, 2). The notebook solves the same LP three ways and prints three different answers: `scipy.optimize.linprog` reports the equality-constraint marginals u = (3, 2, 3), v = (−2, 0, 0); POT's `ot.emd(..., log=True)` returns u = (1.55, 0.55, 1.55), v = (−0.55, 1.45, 1.45). All three are the same solution: (3, 2, 3) = (1, 0, 1) + 2 and (−2, 0, 0) = (0, 2, 2) − 2 is the shift t = 2; POT's version is the shift t = 0.55, chosen by its `center_ot_dual` routine so that Σᵢ aᵢuᵢ = Σⱼ bⱼvⱼ (both equal 1.25). Every uᵢ + vⱼ, every reduced cost, and the dual value Σaᵢuᵢ + Σbⱼvⱼ = 2.5 are identical across the three. When you compare potentials from two sources, compare uᵢ + vⱼ, not u and v separately. Section 8.6 explains why this shift is harmless when potentials are used as gradients with respect to the weights.

### 4.6 Algorithms and their cost

| Method | Problem it solves | Time (n points per side) | Notes |
| --- | --- | --- | --- |
| General LP solver (e.g. `scipy.optimize.linprog` with HiGHS) | Any LP | Polynomial, slow in practice | Good for learning and checking tiny cases |
| Network simplex | Exact discrete OT | Exponential worst case with the usual pivot rules (only Orlin's variant is polynomial); roughly cubic in practice | Used by `ot.emd` in POT; exact, sparse plan |
| Hungarian / shortest augmenting path | Assignment (uniform, n = m) | O(n³) | `scipy.optimize.linear_sum_assignment` |
| Sorting (Section 6) | Exact OT in 1D, any p ≥ 1 | O(n log n) | `scipy.stats.wasserstein_distance` |
| Sinkhorn (Section 10) | Entropic OT, approximation | O(n²) per iteration, GPU-friendly | Differentiable; dense plan |
| Sliced Wasserstein (Section 11) | Average of 1D OT over projections | O(L·n log n) for L directions | Cheap, differentiable, a different (but related) metric |

Memory is often the real bottleneck: the cost matrix alone has n·m entries, 8 GB for n = m = 30 000 in float64. That is why exact OT is used on mini-batches or small problems, and approximations elsewhere.

### Check yourself (Section 4)

1. Why can reduced costs be computed from any choice of u₂ (not only u₂ = 0)?
2. Show that if all costs Cᵢⱼ are increased by the same constant k, the optimal plan does not change and OT increases by k.
3. For n = m = 2 with uniform weights, how many vertices does Π(a, b) have, and what are they?
4. Points P = {(0,0), (1,0)} and Q = {(0,1), (1,1)}, uniform. Compute W₁ with Euclidean cost.

**Answers.** (1) Changing u → u + t and v → v − t leaves every uᵢ + vⱼ, hence every reduced cost, unchanged. (2) For every feasible γ, ⟨γ, C + k𝟙𝟙ᵀ⟩ = ⟨γ, C⟩ + kΣᵢⱼγᵢⱼ = ⟨γ, C⟩ + k, so all plans shift by the same k. (3) Two: ½I and ½ times the anti-diagonal swap matrix. (4) Straight up matching: (0,0)→(0,1) and (1,0)→(1,1), each distance 1, so W₁ = 1. The crossed matching costs √2 per pair.

## 5. The general Wasserstein-p distance

For arbitrary distributions (discrete, continuous or mixed) the p-Wasserstein distance is the p-th root of the smallest expected p-th power of distance over all couplings; it is a true metric, and W₁ is the EMD.

### 5.1 Monge's problem: transport maps

Monge looked for a **map** T that sends each point x to a single destination T(x). The constraint is that if X \~ P then T(X) \~ Q, written T#P = Q ("the push-forward of P by T is Q"); formally (T#P)(A) = P(T⁻¹(A)) for every set A. Monge's problem is

$$
\inf_{T:\; T_{\#}P = Q} \; \mathbb{E}_{X\sim P}\big[c(X, T(X))\big]
$$

Two difficulties: (i) the constraint T#P = Q is highly nonlinear in T, and (ii) there may be **no** feasible map at all. Example: P = δ₀ and Q = ½δ₋₁ + ½δ₁. Any map sends the single point 0 to a single point, so T#P is a Dirac mass and never equals Q. Mass must be **split**, which maps cannot do.

### 5.2 Kantorovich's relaxation: couplings

Kantorovich replaced maps by couplings, exactly as in Section 3.2. A coupling of P and Q is a joint distribution γ of (X, Y) with X \~ P and Y \~ Q; Π(P, Q) is the set of all couplings. For p ≥ 1 and distributions with finite p-th moment (E d(x₀, X)ᵖ < ∞ for some x₀), define

$$
W_p(P,Q) \;=\; \left( \inf_{\gamma \in \Pi(P,Q)} \; \mathbb{E}_{(X,Y)\sim\gamma}\big[ d(X,Y)^p \big] \right)^{1/p}
$$

**EMD = W₁.** The infimum is in fact attained (it is a minimum) when the space is a complete separable metric space such as ℝᵈ; we state this without proof. Every map T gives the coupling (X, T(X)), so the Kantorovich value is never larger than Monge's, and when an optimal map exists the two coincide.

**Brenier's theorem (statement only).** On ℝᵈ with cost ‖x − y‖², if P and Q have finite second moments and P has a density (more generally, gives zero mass to every set of dimension d − 1), then there is a unique optimal coupling, it is given by a map, and that map is the gradient of a convex function: T = ∇φ. Conversely, any map of the form T = ∇φ with φ convex that pushes P to Q is optimal (Knott–Smith and Rüschendorf); Section 7.3 uses this direction. In 1D the optimal map is the monotone rearrangement of Section 6. This theorem is the reason W₂ is the natural distance behind flow matching and diffusion-model theory (Section 12).

### 5.3 Theorem: Wₚ is a metric

For distributions with finite p-th moments, Wₚ satisfies:

1. **Non-negativity:** Wₚ(P, Q) ≥ 0. Immediate, since d ≥ 0.
2. **Symmetry:** Wₚ(P, Q) = Wₚ(Q, P). If (X, Y) is a coupling of P and Q, then (Y, X) is a coupling of Q and P with the same cost, since d is symmetric.
3. **Identity of indiscernibles:** Wₚ(P, Q) = 0 if and only if P = Q.
4. **Triangle inequality:** Wₚ(P, R) ≤ Wₚ(P, Q) + Wₚ(Q, R).

**Proof of 3.** If P = Q, the coupling X = Y (draw X \~ P and set Y = X) costs 0. Conversely, if Wₚ(P, Q) = 0, an optimal coupling has E d(X, Y)ᵖ = 0, so d(X, Y) = 0 with probability 1, so X = Y almost surely, and X and Y have the same distribution: P = Q. ∎

**Proof of 4 (discrete case, fully rigorous).** Let P, Q, R have weights a, b, c on points xᵢ, yⱼ, zₖ. Let γ¹ be an optimal plan between a and b, and γ² an optimal plan between b and c. **Glue** them: define a three-index array

$$
\Gamma_{ijk} = \frac{\gamma^1_{ij}\,\gamma^2_{jk}}{b_j} \qquad (\text{only for } b_j > 0)
$$

Summing over k gives Σₖ Γᵢⱼₖ = γ¹ᵢⱼ · (Σₖ γ²ⱼₖ)/bⱼ = γ¹ᵢⱼ; summing over i gives γ²ⱼₖ. So Γ is the joint PMF of a triple (X, Y, Z) with (X, Y) \~ γ¹ and (Y, Z) \~ γ². In particular (X, Z) is a coupling of P and R. Therefore

$$
\begin{aligned}
W_p(P,R) &\le \big(\mathbb{E}\, d(X,Z)^p\big)^{1/p} &&\text{(any coupling gives an upper bound)}\\
&\le \big(\mathbb{E}\,(d(X,Y)+d(Y,Z))^p\big)^{1/p} &&\text{(triangle inequality for } d)\\
&\le \big(\mathbb{E}\, d(X,Y)^p\big)^{1/p} + \big(\mathbb{E}\, d(Y,Z)^p\big)^{1/p} &&\text{(Minkowski inequality)}\\
&= W_p(P,Q) + W_p(Q,R). &&\text{(optimality of } \gamma^1,\gamma^2)
\end{aligned}
$$

The general case uses the same idea with conditional distributions (the "gluing lemma"). ∎

The Minkowski inequality used above (Primer P5) is the triangle inequality for the norm (E abs(U)ᵖ)^{1/p} of random variables; for p = 1 it is just linearity of expectation.

### 5.4 Properties you should know by heart

| Property | Statement | One-line reason |
| --- | --- | --- |
| Diracs | Wₚ(δₓ, δ\_y) = d(x, y) | Only one coupling exists |
| Dirac vs anything | Wₚ(δₓ, Q) = (E\_{Y\~Q} d(x, Y)ᵖ)^{1/p} | Only one coupling: send x everywhere |
| Monotone in p | p ≤ q implies Wₚ ≤ W\_q | (E Dᵖ)^{1/p} is non-decreasing in p (Jensen) |
| Translation | Wₚ(law of X, law of X + v) = ‖v‖ | Upper bound by the map x ↦ x + v; lower bound via W₁ duality (Exercise 15.6) |
| Scaling | Wₚ(law of sX, law of sY) = abs(s)·Wₚ(law of X, law of Y) | d(sx, sy) = abs(s)·d(x, y) for a norm |
| Mean bound | W₁(P, Q) ≥ ‖E\_P X − E\_Q Y‖ | ‖E(X − Y)‖ ≤ E‖X − Y‖ for every coupling |
| W₂ splits mean and shape | W₂² = ‖m\_P − m\_Q‖² + W₂²(centred P, centred Q) | Cross term vanishes (Exercise 15.8) |
| Convexity | Wₚᵖ is jointly convex in (P, Q) | Mixtures of couplings are couplings of mixtures |
| Bounded space | Wₚ ≤ diameter of the space | d ≤ diameter for every pair |

**The limit p → ∞.** W\_∞(P, Q) is the smallest possible value, over couplings, of the largest distance any unit of mass travels (the essential supremum of d(X, Y)). It bounds every Wₚ from above and is used in robustness analysis, where it measures the worst-case displacement rather than the average. Exercise 15.3 computes it in a simple case.

### 5.5 Wasserstein convergence and the "mass escaping to infinity" example

On a bounded space, Wₚ(Pₖ, P) → 0 is equivalent to weak convergence (convergence in distribution, Primer P6). On unbounded spaces, Wₚ convergence is equivalent to weak convergence **plus** convergence of the p-th moments. Example: Pₖ = (1 − 1/k)δ₀ + (1/k)δₖ. In distribution Pₖ → δ₀ (the bad mass has probability 1/k → 0). But W₁(Pₖ, δ₀) = (1/k)·k = 1 for every k: the small mass travels so far that the transport work never shrinks. This sensitivity to far-away mass is a feature (it notices outliers) and a weakness (it is not robust to them).

### 5.6 Estimating Wₚ from samples: the curse of dimensionality

In practice P is known only through n samples, so we compute Wₚ between empirical distributions P̂ₙ = (1/n)Σᵢ δ\_{Xᵢ}. For P with bounded support on ℝᵈ, E W₁(P̂ₙ, P) shrinks like n^(−1/2) for d = 1, like n^(−1/2)·log n for d = 2, and like n^(−1/d) for d ≥ 3 (Fournier and Guillin, 2015, and earlier results by Dudley). The exponent depends on p as well: the critical dimension is d = 2p (so n^(−1/2) for d < 2p, n^(−1/2)·log n at d = 2p, n^(−p/d) above it, for E Wₚᵖ), and these are upper bounds that are not always tight. In the plane with p = 2, for instance, the sharp rate for the uniform distribution on a square is E W₂²(P̂ₙ, P) ≍ (log n)/n (Ajtai, Komlós and Tusnády, 1984; Ambrosio, Stra and Trevisan, 2019), with one more logarithmic factor for a Gaussian (Ledoux, 2017), so W₂ itself shrinks like n^(−1/2) up to logarithms, not like n^(−1/4) as a naive reading of the bound would suggest; Exercise 15.12 observes exactly this. So in d = 100 you would need astronomically many samples for an accurate estimate. Two consequences you will see in papers: mini-batch Wasserstein is **biased** upward in expectation: Exercise 15.12 proves E\[Wₚᵖ(P̂ₙ, Q̂ₙ)\] ≥ Wₚᵖ(P, Q), which covers W₁ and the squared W₂² used in practice (for the root Wₚ with p > 1 no general inequality follows). Sliced and entropic variants (Sections 10–11) are popular partly because their sample complexity behaves better: sliced W inherits the 1D rate, and entropic OT converges like n^(−1/2), but with constants that grow quickly as ε shrinks or d grows (Genevay et al., 2019). The curse is softened, not removed.

### 5.7 Displacement interpolation (preview of flow matching)

If (X, Y) is an optimal W₂ coupling of P and Q, the law of Xₜ = (1 − t)X + tY for t ∈ \[0, 1\] traces a **geodesic** (shortest path) between P and Q in the Wasserstein space: W₂(P, Pₜ) = t·W₂(P, Q). Mass travels in straight lines at constant speed and paths do not cross. Compare with the mixture (1 − t)P + tQ, which makes mass fade out and fade in rather than move. This straight-line picture is exactly what OT flow matching tries to imitate (Section 12.1).

### Check yourself (Section 5)

1. Why does Monge's problem have no solution for P = δ₀, Q = ½δ₋₁ + ½δ₁, while Kantorovich's does? What is W₁?
2. Compute W₂(δ₀, ½δ₋₁ + ½δ₁) and compare with W₁.
3. In the gluing proof, why do we need to divide by bⱼ?
4. Pₖ = (1 − 1/k)δ₀ + (1/k)δ\_{√k}. Does W₁(Pₖ, δ₀) → 0? Does W₂?

**Answers.** (1) No map can split a Dirac mass; a coupling can send half to −1 and half to +1. W₁ = ½·1 + ½·1 = 1. (2) W₂ = (½·1² + ½·1²)^{1/2} = 1, equal to W₁ here because every unit travels the same distance. (3) Without it, summing γ¹ᵢⱼγ²ⱼₖ over k would give γ¹ᵢⱼbⱼ, not γ¹ᵢⱼ; dividing makes Z depend on X only through Y (conditional independence). (4) W₁ = (1/k)·√k = 1/√k → 0. W₂² = (1/k)·k = 1, so W₂ = 1 for all k and does not converge: higher p is more sensitive to far-away mass.

## 6. One dimension: closed forms and a sorting algorithm

On the real line the optimal plan is "match quantiles": W₁ is the area between the two CDFs, and Wₚ for every p ≥ 1 is computed exactly by sorting, in O(n log n) time.

### 6.1 The two formulas

Let P and Q be distributions on ℝ with CDFs F and G, and quantile functions (generalised inverses, Primer P2)

$$
F^{-1}(t) = \inf\{x \in \mathbb{R} : F(x) \ge t\}, \qquad t \in (0,1).
$$

Then, for every p ≥ 1 (for distributions with finite p-th moments, so that both sides are finite),

$$
W_p^p(P,Q) = \int_0^1 \big| F^{-1}(t) - G^{-1}(t) \big|^p \, dt \qquad\text{and in particular}\qquad W_1(P,Q) = \int_{-\infty}^{\infty} \big| F(x) - G(x) \big| \, dx .
$$

The W₁ formula is the one to picture: **EMD in 1D is the area between the two CDF curves.**

### 6.2 Proof, step 1: the quantile coupling is a coupling

**Lemma A (the "Galois" inequality).** For t ∈ (0, 1) and x ∈ ℝ: F⁻¹(t) ≤ x if and only if t ≤ F(x).

**Proof.** If t ≤ F(x), then x belongs to the set {x : F(x) ≥ t}, so its infimum F⁻¹(t) ≤ x. Conversely, a CDF is right-continuous, so the infimum is attained: F(F⁻¹(t)) ≥ t. If F⁻¹(t) ≤ x, monotonicity gives F(x) ≥ F(F⁻¹(t)) ≥ t. ∎

**Corollary (inverse-transform sampling).** If U \~ Uniform(0, 1), then Pr(F⁻¹(U) ≤ x) = Pr(U ≤ F(x)) = F(x), so F⁻¹(U) \~ P. Hence (X, Y) = (F⁻¹(U), G⁻¹(U)), driven by the **same** U, is a coupling of P and Q, called the **quantile** (or comonotone) coupling. Its cost is ∫₀¹ abs(F⁻¹(t) − G⁻¹(t))ᵖ dt, so this integral is an upper bound on Wₚᵖ.

### 6.3 Proof, step 2: the quantile coupling is optimal

**Lemma B (uncrossing).** Let h be a convex function and x₁ ≤ x₂, y₁ ≤ y₂. Then

$$
h(x_1-y_1) + h(x_2-y_2) \;\le\; h(x_1-y_2) + h(x_2-y_1).
$$

**Proof.** Put A = x₁ − y₂, B₁ = x₁ − y₁, B₂ = x₂ − y₂, D = x₂ − y₁. Then A ≤ B₁ ≤ D and A ≤ B₂ ≤ D, and B₁ + B₂ = A + D. If A = D all four are equal and there is nothing to prove. Otherwise write B₁ = λA + (1 − λ)D with λ ∈ \[0, 1\]; then B₂ = A + D − B₁ = (1 − λ)A + λD. Convexity gives h(B₁) ≤ λh(A) + (1 − λ)h(D) and h(B₂) ≤ (1 − λ)h(A) + λh(D). Adding the two inequalities proves the claim. ∎

With h(z) = abs(z)ᵖ (convex for p ≥ 1), Lemma B says: **uncrossing two arrows never increases cost.**

**Theorem (sorted matching).** Let P and Q be uniform on n points each, with sorted values x₍₁₎ ≤ … ≤ x₍ₙ₎ and y₍₁₎ ≤ … ≤ y₍ₙ₎. Then

$$
W_p^p(P,Q) = \frac{1}{n}\sum_{i=1}^{n} \big| x_{(i)} - y_{(i)} \big|^p .
$$

**Proof (optional proof).** By Section 4.3 an optimal plan is a matching σ. If σ is not the sorted matching, there are two pairs that cross: x₍ᵢ₎ < x₍ₖ₎ matched to y's in the opposite order. Swapping their partners does not increase cost (Lemma B) and strictly reduces the number of crossing pairs. Repeating, we reach the sorted matching with cost no larger than σ's. So the sorted matching is optimal. ∎

The sorted matching is exactly the quantile coupling for these empirical distributions. For general P, Q one approximates them by empirical distributions and passes to the limit (a standard continuity argument; we state this extension without proof). A similar uncrossing argument, which we also state without proof, shows that for discrete P and Q with **unequal** weights, the **north-west corner rule applied to sorted supports** produces an optimal plan in 1D. Section 4 showed the north-west rule is terrible in general; in 1D, with sorted points, it is optimal.

### 6.4 Proof, step 3: the CDF formula for W₁ (optional proof)

For real numbers α, β we have abs(α − β) = ∫ abs(𝟙\[α ≤ x\] − 𝟙\[β ≤ x\]) dx over ℝ, because the integrand is 1 exactly for x between α and β. Apply this with α = F⁻¹(t), β = G⁻¹(t) and integrate over t:

$$
\int_0^1 |F^{-1}(t)-G^{-1}(t)|\,dt \;=\; \int_0^1\!\!\int_{\mathbb{R}} \big|\mathbb{1}[F^{-1}(t)\le x]-\mathbb{1}[G^{-1}(t)\le x]\big|\,dx\,dt \;=\; \int_{\mathbb{R}}\!\int_0^1 \big|\mathbb{1}[t\le F(x)]-\mathbb{1}[t\le G(x)]\big|\,dt\,dx .
$$

The second equality uses Lemma A and swaps the order of integration (allowed for non-negative integrands, Tonelli's theorem). For fixed x, the inner integrand is 1 exactly when t lies between F(x) and G(x), so the inner integral equals abs(F(x) − G(x)). This proves W₁ = ∫ abs(F − G) dx. ∎

Geometric picture: the region between the graphs of F⁻¹ and G⁻¹ on \[0, 1\] is the region between the graphs of F and G, reflected across the diagonal, so the two areas are equal.

### 6.5 Worked examples

**Example 6.A (Example 2.2 again, via CDFs).** P = ½δ₀ + ½δ₂, Q = ¼δ₁ + ¾δ₃. The CDFs are piecewise constant:

| Interval | F(x) | G(x) | abs(F − G) | Length | Contribution |
| --- | --- | --- | --- | --- | --- |
| \[0, 1) | 0.5 | 0 | 0.5 | 1 | 0.5 |
| \[1, 2) | 0.5 | 0.25 | 0.25 | 1 | 0.25 |
| \[2, 3) | 1 | 0.25 | 0.75 | 1 | 0.75 |

W₁ = 0.5 + 0.25 + 0.75 = **1.5**, matching the LP solution of Section 2.

![](figures/fig3_cdf_area.png)

*Figure 3. Example 6.A: the shaded area between the step CDFs F and G is exactly W₁ = 1.5.*

**Example 6.B (two uniforms).** P = Uniform\[0, 1\], Q = Uniform\[0, 2\]. Quantiles: F⁻¹(t) = t, G⁻¹(t) = 2t. Then W₁ = ∫₀¹ t dt = **1/2** and W₂² = ∫₀¹ t² dt = 1/3, so W₂ = 1/√3 ≈ **0.577**. Check W₁ with CDFs: ∫₀¹ (x − x/2) dx + ∫₁² (1 − x/2) dx = 1/4 + 1/4 = 1/2.

**Example 6.C (two exponentials).** P = Exp(λ), Q = Exp(μ) (rates). Quantiles F⁻¹(t) = −ln(1 − t)/λ, so F⁻¹(t) − G⁻¹(t) = (1/λ − 1/μ)·(−ln(1 − t)). Using ∫₀¹ −ln(1 − t) dt = 1 and ∫₀¹ ln²(1 − t) dt = 2 (the first two moments of Exp(1)): W₁ = abs(1/λ − 1/μ) and W₂ = √2·abs(1/λ − 1/μ).

**Example 6.D (two Gaussians in 1D).** For N(m₁, σ₁²) and N(m₂, σ₂²), F⁻¹(t) = mₖ + σₖΦ⁻¹(t), with Φ the standard normal CDF. The difference is Δm + Δσ·Φ⁻¹(t), with Δm = m₁ − m₂ and Δσ = σ₁ − σ₂. Since Φ⁻¹(U) \~ N(0, 1) has mean 0 and variance 1, W₂² = Δm² + Δσ². For W₁ you get E abs(Δm + Δσ·Z) with Z \~ N(0, 1), which is **not** simply abs(Δm) unless σ₁ = σ₂. Common mistake: assuming W₁ between Gaussians only depends on the means.

**Example 6.E (samples).** x = \[6, 1, 3\], y = \[9, 2, 2\]. Sort: \[1, 3, 6\] and \[2, 2, 9\]. W₁ = (1 + 1 + 3)/3 = **5/3 ≈ 1.667**; W₂ = √((1 + 1 + 9)/3) = √(11/3) ≈ **1.915**.

### 6.6 The algorithm

```python
import numpy as np

def w_p_1d_equal(x, y, p=1):
    """Exact W_p between two equal-size, equally weighted 1D samples."""
    x, y = np.sort(x), np.sort(y)
    return np.mean(np.abs(x - y) ** p) ** (1 / p)

def w1_1d_weighted(x, y, a, b):
    """Exact W_1 via the CDF formula for weighted 1D discrete distributions."""
    pts = np.concatenate([x, y])
    w = np.concatenate([a, -np.asarray(b)])   # +mass for P, -mass for Q
    order = np.argsort(pts)
    pts, w = pts[order], w[order]
    cdf_diff = np.cumsum(w)[:-1]              # F - G on each gap
    gaps = np.diff(pts)
    return np.sum(np.abs(cdf_diff) * gaps)

print(w_p_1d_equal([6, 1, 3], [9, 2, 2]))                 # 1.6667
print(w1_1d_weighted(np.array([0., 2.]), np.array([1., 3.]),
                     np.array([.5, .5]), np.array([.25, .75])))  # 1.5
```

`w1_1d_weighted` handles unequal weights but only p = 1. For general p with unequal weights, merge the two sorted supports and integrate the quantile difference piece by piece; Exercise 15.25 asks you to write this (the solution is a ten-line function, and `ot.wasserstein_1d` does the same thing). In practice use `scipy.stats.wasserstein_distance(u_values, v_values, u_weights=None, v_weights=None)` for W₁ in 1D. Its arguments are **sample values** (locations), with optional weights. A frequent bug is passing two histograms of counts as `u_values` and `v_values`; the correct call passes the bin centres as values and the counts as weights.

### 6.7 Beyond the line: distributions on a circle

Angles, hues and times of day live on a circle, where "sort and match" fails because there is no starting point. For W₁ on a circle of circumference 1, with CDFs F and G measured from any chosen origin, the cure is to allow a constant shift of the CDF difference:

$$
W_1^{\text{circle}}(P,Q) = \min_{\alpha\in\mathbb{R}} \int_0^1 \big|F(\theta)-G(\theta)-\alpha\big|\,d\theta ,
$$

and the minimising α is a median of F − G. Example: all mass at 0.05 versus all mass at 0.95 gives 0.9 on the line but **0.1** on the circle, because the short way round crosses the origin. POT computes this with `ot.wasserstein_circle`.

### 6.8 Three ways to compare two CDFs: Kolmogorov–Smirnov, W₁ and Cramér–von Mises

You already know one distance between CDFs from statistics: the **Kolmogorov–Smirnov** statistic KS = sup\_x abs(F(x) − G(x)), the largest vertical gap. Section 6.4 showed that W₁ = ∫ abs(F − G) dx is the **area** between the same two curves, and a third classic, the **Cramér–von Mises** (or Cramér, or energy) distance, is CvM² = ∫ (F − G)² dx. Same two curves, three ways of measuring the gap:

| Quantity | Formula | Units | Reacts to how *far* mass moved? | Bounded? |
| --- | --- | --- | --- | --- |
| Kolmogorov–Smirnov | sup\_x abs(F − G) | none | No: a shift of δ₀ to δ_θ gives KS = 1 for every θ ≠ 0 | Yes, ≤ 1 |
| W₁ = EMD | ∫ abs(F − G) dx | length | Yes: the same shift gives W₁ = abs(θ) | No |
| Cramér–von Mises | (∫ (F − G)² dx)^{1/2} | length^{1/2} | Yes: the same shift gives abs(θ)^{1/2} | No |

![](figures/fig7_cdf_metrics.png)

*Figure 7. The three CDF distances between N(0, 1) and N(θ, 1) as θ grows. KS saturates at 1 (it behaves like total variation in Section 1.3), W₁ grows linearly (it equals abs(θ), the translation property), and the Cramér–von Mises distance grows like √θ.*

KS is the right tool for a hypothesis test (it is distribution-free under the null); W₁ is the right tool when you want a *size* of the discrepancy in the data's own units, or a loss with useful gradients. The Cramér distance sits in between and has one property W₁ lacks: its square is an unbiased-estimable quantity (it is an MMD with kernel −abs(x − y), Primer P11), which is why Bellemare et al. (2017) proposed it for training. The 1D Cramér distance squared also equals the energy distance of Székely and Rizzo up to a factor 2.

**Where this appears in deep learning: distributional reinforcement learning.** Instead of learning the expected return Q(s, a), distributional RL learns the whole distribution of returns. C51 (Bellemare, Dabney and Munos, 2017) motivated its algorithm by showing the distributional Bellman operator is a contraction in W_p, then had to fall back on a KL projection; QR-DQN (Dabney et al., 2018) fixed this by representing the return distribution by N quantiles and minimising the **quantile regression (pinball) loss**, whose minimiser is exactly the quantile function, so the network minimises W₁ to the Bellman target through the quantile formula of 6.1. This is the cleanest large-scale use of the 1D closed form you will meet; the quantile-Huber variant is standard in modern agents.

### Check yourself (Section 6)

1. Compute W₁ between Uniform\[0, 1\] and δ₀.5 (all mass at 0.5) using the CDF formula.
2. Why does the 1D sorting algorithm not generalise directly to ℝ²?
3. P is the empirical distribution of 1000 samples and Q of 1500 samples. Can you still compute W₁ exactly in 1D? How?
4. True or false: in 1D, W₂ between two distributions with equal means and equal variances is always 0.
5. P = δ₀ and Q = ½δ₋₁ + ½δ₁. Compute KS, W₁ and the Cramér–von Mises distance.

**Answers.** (1) F(x) = x on \[0, 1\]; G jumps from 0 to 1 at 0.5. ∫₀^0.5 x dx + ∫\_0.5^1 (1 − x) dx = 1/8 + 1/8 = **1/4**. (2) There is no total order on ℝ² compatible with distance, so "sort and match" has no meaning; in ℝᵈ one needs the LP, or one projects onto lines (sliced Wasserstein, Section 11). (3) Yes: use the weighted CDF formula (weights 1/1000 and 1/1500), or `scipy.stats.wasserstein_distance`, which handles different sizes. (4) False: Uniform\[−√3, √3\] and N(0, 1) both have mean 0 and variance 1 but different quantile functions, so W₂ > 0. For two Gaussians it would be true (Example 6.D). (5) F − G equals −½ on \[−1, 0) and +½ on \[0, 1), zero elsewhere. KS = **½**, W₁ = ∫ abs(F − G) = **1** (as in Section 2), CvM = (∫ (F − G)²)^{1/2} = (2·¼)^{1/2} = **1/√2 ≈ 0.707**.

## 7. Gaussians: a closed form for W₂ (and why FID is a Wasserstein distance)

Between two Gaussians, W₂² equals the squared distance between the means plus a "Bures" term comparing the covariance matrices; the Fréchet Inception Distance (FID) used to evaluate image generators is exactly this formula.

### 7.1 The formula

For P = N(m₁, Σ₁) and Q = N(m₂, Σ₂) on ℝᵈ (Σ₁, Σ₂ symmetric positive semi-definite covariance matrices; see Primer P4),

$$
W_2^2(P,Q) \;=\; \|m_1-m_2\|^2 \;+\; \operatorname{tr}\!\Big(\Sigma_1 + \Sigma_2 - 2\big(\Sigma_2^{1/2}\,\Sigma_1\,\Sigma_2^{1/2}\big)^{1/2}\Big).
$$

Here S^{1/2} denotes the unique symmetric positive semi-definite square root of a PSD matrix S. The trace term is called the (squared) **Bures distance** between covariances.

**Special cases.**

- d = 1: W₂² = (m₁ − m₂)² + (σ₁ − σ₂)², matching Example 6.D.
- Commuting covariances (for example both diagonal): the trace term becomes ‖Σ₁^{1/2} − Σ₂^{1/2}‖\_F² (Frobenius norm), that is, Σₖ (σ₁ₖ − σ₂ₖ)² over the standard deviations along shared eigen-directions.
- Same covariance (Σ₁ = Σ₂): W₂ = ‖m₁ − m₂‖, consistent with the translation property.

### 7.2 Proof in 1D, and a lower bound valid for all distributions

Let X and Y have means m₁, m₂, variances σ₁², σ₂² and **any** distributions. For any coupling,

$$
\mathbb{E}(X-Y)^2 = (m_1-m_2)^2 + \sigma_1^2 + \sigma_2^2 - 2\,\mathrm{Cov}(X,Y) \;\ge\; (m_1-m_2)^2 + (\sigma_1-\sigma_2)^2 ,
$$

because Cov(X, Y) ≤ σ₁σ₂ by the Cauchy–Schwarz inequality. So W₂² ≥ (m₁ − m₂)² + (σ₁ − σ₂)² for **all** distributions with those moments. For Gaussians the quantile coupling Y = m₂ + (σ₂/σ₁)(X − m₁) has correlation 1, so the bound is attained. ∎

The multivariate version of this bound (Gelbrich's bound) also holds: for any P and Q with means mₖ and covariances Σₖ, W₂²(P, Q) is at least the Gaussian formula of 7.1, with equality when both are Gaussian.

### 7.3 The optimal map (multivariate) (optional proof)

The optimal coupling between the Gaussians is the affine map

$$
T(x) = m_2 + A(x-m_1), \qquad A = \Sigma_1^{-1/2}\big(\Sigma_1^{1/2}\Sigma_2\Sigma_1^{1/2}\big)^{1/2}\Sigma_1^{-1/2} \quad(\Sigma_1 \text{ invertible}).
$$

**Why it is a valid transport map.** T(X) is Gaussian with mean m₂ and covariance AΣ₁A. Writing M = (Σ₁^{1/2}Σ₂Σ₁^{1/2})^{1/2}, we get AΣ₁A = Σ₁^{-1/2}MΣ₁^{-1/2}Σ₁Σ₁^{-1/2}MΣ₁^{-1/2} = Σ₁^{-1/2}M²Σ₁^{-1/2} = Σ₂. So T#P = Q.

**Why it is optimal.** A is symmetric positive semi-definite, so T is the gradient of the convex function φ(x) = m₂ᵀx + ½(x − m₁)ᵀA(x − m₁); by the converse part of Brenier's theorem stated in 5.2 (Knott–Smith, Rüschendorf), a gradient of a convex function that pushes P to Q is an optimal map; since Σ₁ is invertible, P has a density and this map is the unique optimum.

**Its cost.** E‖X − T(X)‖² = ‖m₁ − m₂‖² + tr((I − A)Σ₁(I − A)) = ‖m₁ − m₂‖² + tr Σ₁ − 2 tr(AΣ₁) + tr Σ₂, and tr(AΣ₁) = tr(Σ₁^{-1/2}MΣ₁^{1/2}) = tr M. Finally tr M = tr((Σ₂^{1/2}Σ₁Σ₂^{1/2})^{1/2}), because with B = Σ₂^{1/2}Σ₁^{1/2} the matrices BᵀB and BBᵀ have the same eigenvalues. This reproduces 7.1.

### 7.4 Worked examples

**Example 7.A (diagonal).** m₁ = (0, 0), Σ₁ = diag(1, 4); m₂ = (1, 1), Σ₂ = diag(4, 1). Mean term: 1² + 1² = 2. Standard deviations (1, 2) and (2, 1), so the Bures term is (1 − 2)² + (2 − 1)² = 2. W₂² = **4**, W₂ = **2**.

**Example 7.B (one isotropic covariance).** m₁ = m₂ = 0, Σ₁ = I, Σ₂ = \[\[2, 1\], \[1, 2\]\]. Since I commutes with everything, the trace term is tr(I + Σ₂ − 2Σ₂^{1/2}). Σ₂ has eigenvalues 3 and 1, so tr Σ₂^{1/2} = √3 + 1. W₂² = 2 + 4 − 2(√3 + 1) = 4 − 2√3 ≈ **0.536**.

### 7.5 FID is a W₂² between Gaussian fits

The Fréchet Inception Distance (Heusel et al., 2017) passes real and generated images through a pretrained Inception-v3 network (Primer P9), fits a Gaussian (mean and covariance) to each set of 2048-dimensional features, and reports

$$
\mathrm{FID} = \|\mu_r-\mu_g\|^2 + \operatorname{tr}\!\Big(\Sigma_r + \Sigma_g - 2(\Sigma_r\Sigma_g)^{1/2}\Big).
$$

The matrix (Σ\_rΣ\_g)^{1/2} is not symmetric, but its trace equals tr((Σ\_r^{1/2}Σ\_gΣ\_r^{1/2})^{1/2}), so FID is exactly the W₂² of 7.1 between the two Gaussian fits (the W₂ distance between two Gaussians is also called the Fréchet distance, after Dowson and Landau, 1982; the name is specific to the Gaussian case). Practical consequences you should be able to explain: FID is biased for small sample sizes (it needs many thousands of images), depends on the feature network, and only sees the first two moments of the features. Recent work therefore also reports Fréchet distances in other feature spaces (for example DINOv2 features) or kernel-based alternatives such as CMMD; the Gaussian W₂ formula underneath is the same.

### Check yourself (Section 7)

1. Compute W₂ between N(0, 1) and N(3, 4) in 1D.
2. Why can FID be negative in numerical implementations, even though W₂² ≥ 0?
3. For d-dimensional isotropic Gaussians N(m₁, s₁²I) and N(m₂, s₂²I), give W₂².

**Answers.** (1) Variances 1 and 4 mean σ = 1 and 2. W₂² = 9 + 1 = 10, W₂ = √10 ≈ 3.162. (2) The matrix square root is computed numerically (for example `scipy.linalg.sqrtm`) and can return small imaginary parts or round-off errors; implementations take the real part, and tiny negative values can appear when the two sets are almost identical. (3) ‖m₁ − m₂‖² + d(s₁ − s₂)².

## 8. Kantorovich–Rubinstein duality

EMD can be computed as a maximisation over a single function f with slope at most 1: W₁(P, Q) = sup over 1-Lipschitz f of E\_P\[f(X)\] − E\_Q\[f(Y)\]. This turns a problem about couplings into a problem a neural network can solve.

### 8.1 The dual LP of discrete OT

Start from the primal LP of 3.1 and attach a multiplier uᵢ to each row constraint and vⱼ to each column constraint. The **Lagrangian** is

$$
L(\gamma,u,v) = \langle \gamma, C\rangle + \sum_i u_i\Big(a_i - \sum_j\gamma_{ij}\Big) + \sum_j v_j\Big(b_j - \sum_i \gamma_{ij}\Big) = \sum_i a_iu_i + \sum_j b_jv_j + \sum_{i,j}\gamma_{ij}\big(C_{ij}-u_i-v_j\big).
$$

Minimising over γ ≥ 0: if some Cᵢⱼ − uᵢ − vⱼ < 0, sending γᵢⱼ → ∞ drives L to −∞; otherwise the minimum is at γ = 0 and equals Σaᵢuᵢ + Σbⱼvⱼ. Maximising this lower bound over (u, v) gives the **dual problem**:

$$
\max_{u\in\mathbb{R}^n,\; v\in\mathbb{R}^m} \;\sum_i a_iu_i + \sum_j b_jv_j \quad\text{s.t.}\quad u_i + v_j \le C_{ij}\;\;\forall i,j .
$$

- **Weak duality** (dual ≤ primal) is the lemma of 4.4.
- **Strong duality** (dual = primal) holds by the LP strong duality theorem, since the primal is feasible and bounded. We use it without proof; any LP textbook proves it.
- **Complementary slackness:** at optimality, γᵢⱼ > 0 implies uᵢ + vⱼ = Cᵢⱼ. This is exactly the certificate we used to verify the warehouse solution (u = (1, 0, 1), v = (0, 2, 2), value 2.5).

### 8.2 The c-transform: one potential is enough

For fixed u, the best v satisfies vⱼ ≤ Cᵢⱼ − uᵢ for every i and is as large as possible, so vⱼ = minᵢ (Cᵢⱼ − uᵢ). This is called the **c-transform** of u. The dual therefore depends only on one vector (or one function). Semi-dual OT solvers and many neural OT methods optimise over u alone using this trick.

### 8.3 The theorem for W₁

A function f is **1-Lipschitz** if abs(f(z) − f(z′)) ≤ d(z, z′) for all z, z′; for differentiable f on ℝᵈ this is equivalent to ‖∇f(z)‖ ≤ 1 everywhere.

**Theorem (Kantorovich–Rubinstein).** For P, Q with finite first moments,

$$
W_1(P,Q) \;=\; \sup_{\|f\|_{L}\le 1}\; \mathbb{E}_{X\sim P}\big[f(X)\big] - \mathbb{E}_{Y\sim Q}\big[f(Y)\big].
$$

**Proof that the right side is ≤ W₁ (any distributions).** Fix a 1-Lipschitz f and any coupling (X, Y). Then E\_P f − E\_Q f = E\[f(X) − f(Y)\] ≤ E abs(f(X) − f(Y)) ≤ E d(X, Y). Taking the infimum over couplings on the right and the supremum over f on the left gives sup ≤ W₁.

**Proof that the right side is ≥ W₁ (discrete P, Q in a common metric space).** Let (u, v) be an optimal dual solution for the cost Cᵢⱼ = d(xᵢ, yⱼ), so Σaᵢuᵢ + Σbⱼvⱼ = W₁ by strong duality. Define, for every point z of the space,

$$
f(z) = \min_j \big( d(z, y_j) - v_j \big).
$$

(i) f is 1-Lipschitz, because each z ↦ d(z, yⱼ) − vⱼ is 1-Lipschitz (triangle inequality) and a minimum of 1-Lipschitz functions is 1-Lipschitz. (ii) f(xᵢ) ≥ uᵢ, because the dual constraint gives uᵢ ≤ d(xᵢ, yⱼ) − vⱼ for every j. (iii) f(yⱼ) ≤ d(yⱼ, yⱼ) − vⱼ = −vⱼ. Therefore

$$
\mathbb{E}_P f - \mathbb{E}_Q f = \sum_i a_i f(x_i) - \sum_j b_j f(y_j) \;\ge\; \sum_i a_iu_i + \sum_j b_jv_j = W_1(P,Q).
$$

Combined with the first part, the supremum equals W₁ and is attained by this f. The general case follows by approximating P and Q with discrete distributions. ∎

Two remarks. (1) The key step is that for a metric cost, the two potentials collapse into one: at the optimum, v = −f on the support of Q and u = f on the support of P. (2) For p > 1 the dual of Wₚᵖ still has two potentials φ(x) + ψ(y) ≤ d(x, y)ᵖ and does **not** reduce to a Lipschitz constraint. Only W₁ has the clean single-critic form.

### 8.4 What the dual means in 1D

On ℝ, integrate by parts (boundary terms vanish for distributions with finite mean and bounded f′):

$$
\mathbb{E}_P f - \mathbb{E}_Q f = \int f(x)\, d\big(F-G\big)(x) = -\int f'(x)\,\big(F(x)-G(x)\big)\,dx .
$$

With the constraint abs(f′) ≤ 1, the best choice is f′(x) = −sign(F(x) − G(x)), which yields ∫ abs(F − G) dx, exactly the CDF formula of Section 6. Duality and the CDF formula are two views of the same fact.

**Example 8.A (Example 2.2 again).** P = ½δ₀ + ½δ₂, Q = ¼δ₁ + ¾δ₃. We found F > G on \[0, 3), so take f′ = −1 there: f(x) = −x. Then E\_P f = −(0 + 2)/2 = −1, E\_Q f = −(0.25·1 + 0.75·3) = −2.5, and the difference is **1.5** = W₁. The critic gives high scores to the region where P has "too much" mass compared with Q and low scores where Q has more.

**Example 8.B (Diracs, the WGAN toy).** P = δ₀, Q = δ\_θ with θ > 0. Take f(x) = −x: E\_P f − E\_Q f = 0 − (−θ) = θ = W₁. A 1-Lipschitz function can separate the two points by at most their distance, which is why the critic's value never saturates the way the JS-based GAN discriminator does.

### 8.5 Reading the dual as a critic

Think of f as a **critic** that scores samples: high for samples from P (real data), low for samples from Q (generated). Without a constraint, the critic could make the gap arbitrarily large by scaling up. The Lipschitz constraint caps its slope, so the best achievable gap measures how far apart the distributions really are. If f is only constrained to be K-Lipschitz, the supremum is K·W₁: scaling is harmless for training because it only rescales the loss. This is precisely the starting point of Wasserstein GANs in the next section.

### 8.6 Gradients of OT with respect to the data

To use OT as a loss you need its derivative with respect to point positions and weights; the answer is "freeze the optimal plan and differentiate the cost" (positions) and "read off the dual potentials" (weights).

**Positions.** Write OT(X) = min over γ ∈ Π(a, b) of Σᵢⱼ γᵢⱼ C(xᵢ, yⱼ). If the optimal plan γ\* is unique, the envelope (Danskin) theorem (Primer P7) says the derivative of the minimum equals the derivative of the objective with γ fixed at γ\*. For the squared cost C(x, y) = ‖x − y‖² this gives

$$
\nabla_{x_i} W_2^2 = 2\sum_j \gamma^*_{ij}\,(x_i - y_j) = 2\,a_i\,\big(x_i - \bar T(x_i)\big), \qquad \bar T(x_i) = \frac{1}{a_i}\sum_j \gamma^*_{ij}\, y_j ,
$$

where T̄(xᵢ) is the **barycentric projection**: the average destination of the mass at xᵢ. A gradient step therefore moves every point straight toward where its mass is being sent. For the cost ‖x − y‖ (EMD), each term is γᵢⱼ(xᵢ − yⱼ)/‖xᵢ − yⱼ‖, a sum of unit vectors weighted by the transported mass (undefined when xᵢ = yⱼ, where a subgradient is used).

**Weights.** By LP sensitivity, ∂OT/∂aᵢ = uᵢ and ∂OT/∂bⱼ = vⱼ, the optimal dual potentials. Because potentials are defined only up to adding t to u and subtracting t from v, these "gradients" are defined up to the same shift, which is harmless when weights must keep summing to 1. POT returns centred potentials.

**When the plan is not unique, OT is not differentiable.** Example: P = ½δ\_{x₁} + ½δ\_{x₂} and Q = ½δ₀ + ½δ₄ on ℝ. For x₁ < x₂ the sorted plan gives W₂² = ½x₁² + ½(x₂ − 4)², so ∂/∂x₁ = x₁, matching the formula 2·½·(x₁ − 0). When x₁ crosses x₂ the matching swaps and the derivative jumps to x₁ − 4. At x₁ = x₂ both plans are optimal and only one-sided derivatives exist. Autograd then silently returns the gradient for whichever plan the solver picked. Entropic OT does not have this problem: its plan is always unique and smooth in the data, which is one reason Sinkhorn losses train more smoothly. These formulas are exactly what `.backward()` computes in the POT recipes of Section 13.4.

### 8.7 W₁ is an integral probability metric; KL is not

Kantorovich–Rubinstein puts W₁ in a family you should recognise. An **integral probability metric (IPM)** is any quantity of the form

$$
d_{\mathcal F}(P,Q) = \sup_{f\in\mathcal F}\; \mathbb{E}_P f - \mathbb{E}_Q f
$$

for a class of test functions 𝓕 that is symmetric (f ∈ 𝓕 ⇒ −f ∈ 𝓕). Different classes give the distances you have met:

| Class 𝓕 | IPM | Where it appeared |
| --- | --- | --- |
| 1-Lipschitz functions | W₁ (Section 8.3) | WGAN critic |
| Indicators of sets (functions with values in \[−1, 1\] give 2·TV) | Total variation (P3) | Section 1.3 |
| Unit ball of a reproducing-kernel Hilbert space | Maximum mean discrepancy, MMD (P11) | Sinkhorn divergence limit ε → ∞ (10.7) |
| Functions with ‖f‖\_∞ + Lip(f) ≤ 1 | Dudley (bounded-Lipschitz) metric | Metrises weak convergence (P6) |

Two facts follow immediately. First, a **smaller class gives a smaller distance**: indicators are 1-Lipschitz only on discrete spaces, so in general W₁ and TV are not ordered, but on a space of diameter D one has W₁ ≤ D·TV (Exercise 15.17), and the Dudley metric is at most W₁ and at most 2·TV. Second, the **neural-network view of every IPM is the same**: parametrise f by a network, constrain it to lie in 𝓕, and maximise the gap. WGAN does this for Lipschitz functions; MMD-GANs do it with kernels; the original GAN discriminator does *not* fit this template.

KL, JS, and all **f-divergences** ∫ φ(dP/dQ) dQ belong to a different family: they compare densities pointwise through a ratio, never through a test function that sees the geometry. This is the one-sentence answer to "why is W₁ an IPM and KL not, and why does that matter for GANs?": an IPM with a geometry-aware test class varies smoothly as the distributions move; a density-ratio divergence cannot see motion that does not change the overlap. The two families meet only at total variation, which is both an IPM (bounded functions) and an f-divergence (φ(t) = ½ abs(t − 1)). See Sriperumbudur et al. (2012) for the full comparison.

### Check yourself (Section 8)

1. Use the dual with f(x) = ⟨x, e⟩ for a unit vector e to prove W₁(P, Q) ≥ ⟨E\_P X − E\_Q Y, e⟩, and deduce the mean bound of 5.4.
2. Show that if f is 1-Lipschitz then so is f + c for any constant c, and that adding c does not change E\_P f − E\_Q f. What does this say about uniqueness of the optimal critic?
3. Why can't you plug f(x) = x² into the KR formula?
4. In 8.1, why is the dual variable unconstrained in sign?
5. Is the Sinkhorn divergence of Section 10.7 an IPM? Is KL between two Gaussians an IPM?

**Answers.** (1) z ↦ ⟨z, e⟩ is 1-Lipschitz by Cauchy–Schwarz, so W₁ ≥ E⟨X, e⟩ − E⟨Y, e⟩ = ⟨m\_P − m\_Q, e⟩. Choosing e = (m\_P − m\_Q)/‖m\_P − m\_Q‖ gives W₁ ≥ ‖m\_P − m\_Q‖. (2) abs((f + c)(z) − (f + c)(z′)) = abs(f(z) − f(z′)); the constant cancels between the two expectations. The optimal critic is at best unique up to an additive constant (and is generally not unique away from the supports). (3) Its derivative 2x is unbounded, so it is not Lipschitz on ℝ. (4) The primal constraints are equalities; multipliers of equality constraints are free in sign. (5) Neither. S\_ε is a divergence that interpolates between two IPMs (W and MMD) but is not itself a supremum over a fixed function class. KL is an f-divergence; the fact that it has a closed form for Gaussians does not make it an IPM.

## 9. Wasserstein GANs: EMD as a training loss

A Wasserstein GAN trains a generator to minimise W₁ between real and generated data, using a neural-network critic that approximates the optimal 1-Lipschitz function from Kantorovich–Rubinstein duality; the Lipschitz constraint is enforced by weight clipping (WGAN) or by a gradient penalty (WGAN-GP).

### 9.1 The problem with the original GAN loss

The original GAN (Goodfellow et al., 2014; Primer P10 introduces GANs from scratch) plays a min-max game between a generator g\_θ and a discriminator D with output in (0, 1):

$$
\min_\theta \max_D \; \mathbb{E}_{x\sim P_r}\big[\log D(x)\big] + \mathbb{E}_{z\sim p(z)}\big[\log\big(1-D(g_\theta(z))\big)\big].
$$

For the optimal discriminator, the value equals 2·JS(P\_r, P\_θ) − log 4. Section 1 showed that JS is constant (log 2) whenever the supports are disjoint, which is the typical situation early in training. A near-perfect discriminator then provides vanishing gradients to the generator. In practice this showed up as unstable training and mode collapse. Two honest caveats: practical GANs usually train the generator with the non-saturating loss −log D(g\_θ(z)) instead of log(1 − D(g\_θ(z))), which avoids vanishing gradients early in training but is less principled and still unstable; and noise injection or gradient penalties on the discriminator also help. W₁ is a principled fix, not the only one.

### 9.2 The WGAN objective

Arjovsky, Chintala and Bottou (2017) replaced JS by W₁ and used the dual form of Section 8 with a neural-network critic f\_w (an MLP or CNN with a **linear** output, no sigmoid):

$$
\min_\theta \;\max_{w:\; f_w \text{ is } K\text{-Lipschitz}} \; \mathbb{E}_{x\sim P_r}\big[f_w(x)\big] - \mathbb{E}_{z\sim p(z)}\big[f_w(g_\theta(z))\big].
$$

The inner maximum equals K·W₁(P\_r, P\_θ). In code you minimise two losses, each estimated on a mini-batch:

| Network | Loss to minimise | Intuition |
| --- | --- | --- |
| Critic f\_w | L\_critic = mean f\_w(fake) − mean f\_w(real) | Push real scores up, fake scores down |
| Generator g\_θ | L\_gen = − mean f\_w(g\_θ(z)) | Move fakes toward regions the critic scores highly |

**Why the generator gradient is correct.** Write V(θ) = max\_f \[E\_r f(x) − E\_z f(g\_θ(z))\] and let f\* be the maximiser at the current θ. Under mild regularity (Arjovsky et al., Theorem 3, an envelope/Danskin argument), the derivative of the max equals the derivative of the objective with f held fixed at f\*:

$$
\nabla_\theta W_1(P_r, P_\theta) = -\,\mathbb{E}_{z\sim p(z)}\big[\nabla_\theta f^*\big(g_\theta(z)\big)\big].
$$

So training the critic well first and then taking a generator step is principled: it is gradient descent on W₁.

**Why W₁ is a sensible loss in the first place (Arjovsky et al., Theorem 1, sketch).** Suppose the generator g\_θ(z) is continuous in θ for every z, and locally Lipschitz in θ with a constant L(z) that satisfies E\_z L(z) < ∞ (true for any MLP or CNN with the usual activations). Then θ ↦ W₁(P\_r, P\_θ) is continuous and differentiable almost everywhere, whereas JS and TV need not be continuous at all (Section 1.3 is the counter-example). The proof is two lines of what you already know. Couple P\_θ and P\_θ′ through the **same** noise: (g\_θ(Z), g\_θ′(Z)) is a coupling, so W₁(P\_θ, P\_θ′) ≤ E\_z‖g\_θ(z) − g\_θ′(z)‖ ≤ E\_z L(z)·‖θ − θ′‖ → 0 as θ′ → θ. Then the triangle inequality for the metric W₁ gives abs(W₁(P\_r, P\_θ) − W₁(P\_r, P\_θ′)) ≤ W₁(P\_θ, P\_θ′). Continuity of the loss in the parameters is the minimum one should ask of a training objective, and the metric property of W₁ delivers it for free.

### 9.3 Algorithm (original WGAN, weight clipping)

1. Repeat until convergence:
   1. For t = 1, …, n\_critic (default 5): sample a real batch and a noise batch; compute L\_critic; update w with RMSProp (an adaptive gradient method, Primer P9; learning rate 5×10⁻⁵); clip every weight to \[−c, c\] with c = 0.01.
   2. Sample a noise batch; compute L\_gen; update θ with RMSProp.

Clipping makes the weights bounded, so f\_w is K-Lipschitz for some K that depends on the architecture. Its weaknesses: with c too small gradients vanish, with c too large training is slow and unstable, and the critic tends to learn overly simple functions (clipped weights push toward extreme values).

### 9.4 WGAN-GP: the gradient penalty

Gulrajani et al. (2017) noticed a structural property of the optimal critic and turned it into a soft constraint.

**Proposition.** Let f\* be an optimal 1-Lipschitz critic and (X, Y) an optimal coupling of P\_r and P\_θ. Then with probability 1, f\*(X) − f\*(Y) = ‖X − Y‖, and if f\* is differentiable at a point xₜ = tX + (1 − t)Y on the segment, ‖∇f\*(xₜ)‖ = 1.

**Proof.** By duality, E\[f\*(X) − f\*(Y)\] = W₁ = E‖X − Y‖. Since f\* is 1-Lipschitz, f\*(X) − f\*(Y) ≤ ‖X − Y‖ pointwise. A non-negative random variable (‖X − Y‖ − (f\*(X) − f\*(Y))) with zero mean is zero almost surely, giving the first claim. Now let e = (X − Y)/‖X − Y‖. Along the segment, the function s ↦ f\*(Y + s·e) goes up by exactly ‖X − Y‖ over a distance ‖X − Y‖ while having slope at most 1, so its slope is exactly 1 everywhere on the segment. Hence the directional derivative ⟨∇f\*(xₜ), e⟩ = 1, and since ‖∇f\*‖ ≤ 1, Cauchy–Schwarz forces ∇f\*(xₜ) = e and ‖∇f\*(xₜ)‖ = 1. ∎

**The WGAN-GP critic loss.** Penalise deviations of the gradient norm from 1 at random points between real and fake samples:

$$
L_{\text{critic}} = \mathbb{E}\big[f_w(\tilde x)\big] - \mathbb{E}\big[f_w(x)\big] + \lambda\,\mathbb{E}_{\hat x}\Big[\big(\|\nabla_{\hat x} f_w(\hat x)\|_2 - 1\big)^2\Big], \qquad \hat x = \epsilon x + (1-\epsilon)\tilde x,\;\; \epsilon\sim U[0,1],
$$

with x real, x̃ = g\_θ(z) fake, and default hyperparameters λ = 10, n\_critic = 5, Adam with learning rate 10⁻⁴ and (β₁, β₂) = (0, 0.9). Pairing real and fake samples at random is a cheap stand-in for the unknown optimal coupling. Two practical rules follow from the per-sample nature of the penalty: do **not** use batch normalisation in the critic (it couples samples in a batch; use layer normalisation or none; see Primer P9), and the penalty requires a second-order backward pass (`create_graph=True` in PyTorch).

**A refinement: the one-sided penalty.** Petzka, Fischer and Lukovnikov (ICLR 2018) observed that the constraint is ‖∇f‖ ≤ 1, so gradients smaller than 1 should not be penalised. Their WGAN-LP replaces the penalty by λ·E\[max(0, ‖∇f(x̂)‖ − 1)²\]. Both versions are in use; the two-sided form is the WGAN-GP default. Either way the penalty is soft: the critic may exceed slope 1 where that increases the objective, which biases its value upward (Exercise 15.20), while limited capacity and training time bias it downward. Which effect dominates depends on the problem.

```python
import torch

def gradient_penalty(critic, real, fake):
    eps = torch.rand(real.size(0), *([1] * (real.dim() - 1)), device=real.device)
    x_hat = (eps * real + (1 - eps) * fake).requires_grad_(True)
    scores = critic(x_hat)
    grads = torch.autograd.grad(outputs=scores.sum(), inputs=x_hat,
                                create_graph=True)[0]
    grad_norm = grads.flatten(1).norm(2, dim=1)
    return ((grad_norm - 1) ** 2).mean()

# critic step
loss_c = critic(fake.detach()).mean() - critic(real).mean() \
         + 10.0 * gradient_penalty(critic, real, fake.detach())
# generator step
loss_g = -critic(generator(z)).mean()
```

The companion notebook trains a complete WGAN-GP with small MLPs on a 2D mixture of Gaussians and plots the critic's estimate of W₁ during training.

### 9.5 Monitoring and honest caveats

- **The critic loss is a useful training curve.** −L\_critic (without the penalty term) estimates K·W₁ between real and generated data and usually decreases as samples improve, unlike the original GAN loss.
- **It is not an accurate W₁ estimate.** Studies such as Mallasto et al. (2019) and Stanczuk et al. (2021, "Wasserstein GANs work because they fail (to approximate the Wasserstein distance)") found that trained critics can be far from the true W₁, and that WGANs work largely because of the regularised, smooth critic they learn. Do not report the critic value as "the" Wasserstein distance between datasets.
- **Other ways to enforce Lipschitz-ness:** spectral normalisation (Miyato et al., 2018) divides each weight matrix by its largest singular value, so each layer, and hence the network with 1-Lipschitz activations, is 1-Lipschitz.
- **Context in 2026.** Diffusion and flow-matching models now dominate high-quality image generation, and they use optimal transport in a different way (Section 12.1). Adversarial losses, often with gradient penalties descended from WGAN-GP, remain common in fast one-step generators and distillation, super-resolution, neural audio vocoders and image tokenisers. WGAN is essential knowledge because its ideas (critic, Lipschitz constraint, gradient penalty) recur everywhere.

### Check yourself (Section 9)

1. Why does the WGAN critic have no sigmoid at its output?
2. If you accidentally use a critic that is 5-Lipschitz instead of 1-Lipschitz, what happens to the loss and to training?
3. Why do we detach the fake samples in the critic step?
4. Why is the gradient penalty evaluated at interpolates x̂ rather than only at real or only at fake points?

**Answers.** (1) The critic estimates the unbounded quantity f in E\_P f − E\_Q f; a sigmoid would squash it to (0, 1) and reintroduce saturation. (2) The supremum becomes 5·W₁: the loss is rescaled but its minimiser in θ is unchanged; only the effective learning rate changes. (3) In the critic step only w should be updated; detaching stops gradients from flowing into the generator (and saves computation). (4) The proposition says the optimal critic has unit gradient on segments between coupled real and fake points, so those segments are where the constraint matters most; constraining the gradient everywhere would be intractable.

## 10. Entropic OT and the Sinkhorn algorithm

Adding a small entropy bonus to the transport problem makes the optimal plan unique, dense and of the closed form γ = diag(u)·K·diag(v) with K = exp(−C/ε); the Sinkhorn algorithm finds u and v by alternately rescaling rows and columns, using only matrix–vector products that run fast on GPUs and are differentiable.

### 10.1 The regularised problem

Define the entropy (Primer P3) of a plan H(γ) = −Σᵢⱼ γᵢⱼ(log γᵢⱼ − 1). For a regularisation strength ε > 0, entropic OT (Cuturi, 2013) solves

$$
\mathrm{OT}_\varepsilon(a,b) = \min_{\gamma\in\Pi(a,b)} \; \langle \gamma, C\rangle - \varepsilon H(\gamma).
$$

The entropy term rewards spread-out plans. Since −H is strictly convex, the problem has a **unique** solution γ\_ε. As ε → 0, γ\_ε converges to an optimal plan of the original problem (the one with maximal entropy among optimal plans). As ε → ∞, γ\_ε → abᵀ, the independent coupling. An equivalent formulation used in many papers replaces −εH(γ) by +ε·KL(γ ‖ abᵀ); because Σγᵢⱼ log(aᵢbⱼ) is the same constant for every γ ∈ Π(a, b), both formulations have the same optimal plan.

### 10.2 Derivation of the solution's form

Ignore γ ≥ 0 for now (we will see it holds automatically) and introduce multipliers fᵢ, gⱼ for the marginal constraints:

$$
\mathcal{L} = \sum_{i,j}\gamma_{ij}C_{ij} + \varepsilon\sum_{i,j}\gamma_{ij}(\log\gamma_{ij}-1) - \sum_i f_i\Big(\sum_j\gamma_{ij}-a_i\Big) - \sum_j g_j\Big(\sum_i\gamma_{ij}-b_j\Big).
$$

Setting ∂L/∂γᵢⱼ = Cᵢⱼ + ε log γᵢⱼ − fᵢ − gⱼ = 0 gives

$$
\gamma_{ij} = e^{f_i/\varepsilon}\; e^{-C_{ij}/\varepsilon}\; e^{g_j/\varepsilon} = u_i\,K_{ij}\,v_j, \qquad K = e^{-C/\varepsilon}\;(\text{entrywise}),\;\; u = e^{f/\varepsilon},\;\; v = e^{g/\varepsilon}.
$$

Every entry is strictly positive (exponentials), so the constraint γ ≥ 0 was never active, and the plan is **dense**: every route carries some mass, unlike the sparse exact plan of 4.2. K is called the **Gibbs kernel**.

### 10.3 The Sinkhorn iterations

We need u, v such that diag(u)K diag(v) has row sums a and column sums b, that is, u ⊙ (Kv) = a and v ⊙ (Kᵀu) = b (⊙ = entrywise product). Solve each equation for one unknown while freezing the other, and alternate:

$$
u^{(\ell+1)} = \frac{a}{K v^{(\ell)}}, \qquad v^{(\ell+1)} = \frac{b}{K^{\top} u^{(\ell+1)}} \qquad(\text{entrywise division}),\quad v^{(0)} = \mathbb{1}.
$$

The u-update makes the row sums exactly a; the v-update then makes the column sums exactly b (and slightly breaks the rows). This is the Sinkhorn–Knopp matrix-scaling algorithm (1967). It converges linearly, and each iteration costs two matrix–vector products, O(nm) operations. Stop when the row-sum error ‖u ⊙ Kv − a‖₁ falls below a tolerance.

```python
import numpy as np

def sinkhorn(a, b, C, eps, n_iter=1000, tol=1e-9):
    K = np.exp(-C / eps)
    v = np.ones_like(b)
    for _ in range(n_iter):
        u = a / (K @ v)
        v = b / (K.T @ u)
        if np.abs(u * (K @ v) - a).sum() < tol:
            break
    G = u[:, None] * K * v[None, :]
    return G, np.sum(G * C)          # plan and its transport cost <G, C>
```

### 10.4 Worked example: a 2 × 2 closed form

a = b = (½, ½), C = \[\[0, 1\], \[1, 0\]\] (the exact OT is 0: keep everything in place). K = \[\[1, e^(−1/ε)\], \[e^(−1/ε), 1\]\]. By symmetry u = v = c𝟙 for some c > 0, so γ = c²K, and total mass 1 gives c² = 1/(2(1 + e^(−1/ε))). The off-diagonal entry is

$$
\gamma_{12} = \frac{e^{-1/\varepsilon}}{2\,(1+e^{-1/\varepsilon})} = \frac{1}{2\,(e^{1/\varepsilon}+1)}, \qquad \langle\gamma_\varepsilon, C\rangle = 2\gamma_{12} = \frac{1}{e^{1/\varepsilon}+1}.
$$

For ε = 1 the transport cost is 1/(e + 1) ≈ **0.269**, though the true OT is 0; for ε = 0.5 it is ≈ 0.119; for ε = 0.1 it is ≈ 4.5 × 10⁻⁵. The error shrinks exponentially fast as ε → 0, but it is never zero: entropic OT **blurs** the plan.

### 10.5 Worked example: the warehouse problem

Running Sinkhorn on the 3 × 3 problem of Section 3.3 (exact OT = 2.5) shows the effect of ε on the transport cost ⟨γ\_ε, C⟩:

| ε | ⟨γ\_ε, C⟩ | Comment |
| --- | --- | --- |
| 10 | 3.597 | Close to the independent coupling (cost 3.84) |
| 3 | 3.117 | Very blurry plan |
| 1 | 2.578 | Plan already concentrated on the 5 optimal routes |
| 0.3 | 2.501 | Nearly exact |
| 0.1 | 2.500 | Indistinguishable from exact to 3 decimals |

And the first iterations at ε = 1 (after each full u, v update the column sums are exact; the row sums converge to a = (0.3, 0.3, 0.4)):

| Iteration | Row sums | ⟨γ, C⟩ |
| --- | --- | --- |
| 1 | (0.451, 0.330, 0.219) | 2.650 |
| 2 | (0.402, 0.290, 0.309) | 2.619 |
| 3 | (0.359, 0.301, 0.340) | 2.585 |
| 5 | (0.322, 0.304, 0.374) | 2.572 |
| converged | (0.300, 0.300, 0.400) | 2.578 |

![](figures/fig4_sinkhorn_blur.png)

*Figure 4. Transport plans between two 1D mixtures (squared cost on \[0, 1\]): exact OT concentrates on a thin monotone curve; as ε grows the Sinkhorn plan blurs, and for large ε it approaches the independent coupling.*

### 10.6 Numerical stability: the log domain

For small ε, K = exp(−C/ε) underflows to 0 (for example exp(−1000) in float64), and the divisions blow up. The fix is to iterate on the log-potentials f = ε log u and g = ε log v using the log-sum-exp trick:

$$
f_i \leftarrow \varepsilon\log a_i - \varepsilon \log\sum_j \exp\!\Big(\frac{g_j - C_{ij}}{\varepsilon}\Big), \qquad g_j \leftarrow \varepsilon\log b_j - \varepsilon \log\sum_i \exp\!\Big(\frac{f_i - C_{ij}}{\varepsilon}\Big).
$$

```python
from scipy.special import logsumexp

def sinkhorn_log(a, b, C, eps, n_iter=1000):
    f, g = np.zeros_like(a), np.zeros_like(b)
    for _ in range(n_iter):
        f = eps * np.log(a) - eps * logsumexp((g[None, :] - C) / eps, axis=1)
        g = eps * np.log(b) - eps * logsumexp((f[:, None] - C) / eps, axis=0)
    G = np.exp((f[:, None] + g[None, :] - C) / eps)
    return G, np.sum(G * C)
```

Practical rules: rescale C (for example divide by its maximum or median) so that ε has an interpretable size; use the log domain whenever ε is below roughly 1% of the typical cost; expect the number of iterations to grow as ε shrinks.

### 10.7 Bias and the Sinkhorn divergence

Entropic OT is not a distance: OT\_ε(P, P) ≠ 0 in general, because the regularised plan between P and itself is blurred. The **Sinkhorn divergence** (Genevay, Peyré, Cuturi, 2018; Feydy et al., 2019) removes this bias:

$$
S_\varepsilon(P,Q) = \mathrm{OT}_\varepsilon(P,Q) - \tfrac12\,\mathrm{OT}_\varepsilon(P,P) - \tfrac12\,\mathrm{OT}_\varepsilon(Q,Q).
$$

For the costs C = ‖x − y‖ and C = ‖x − y‖² (more generally, whenever exp(−C/ε) is a positive definite universal kernel), S\_ε is non-negative, equals 0 exactly when P = Q, and interpolates between OT (as ε → 0) and a kernel maximum mean discrepancy (MMD, Primer P11; as ε → ∞). Here OT\_ε means the full regularised objective (including the entropy or KL term); constant terms depending only on the marginals cancel in the combination, so the entropy and KL conventions give the same S\_ε. They do differ for OT\_ε itself. With +ε·KL(γ ‖ abᵀ) the value is at least ⟨γ\_ε, C⟩ ≥ 0, so OT\_ε(P, P) > 0. With −ε·H(γ) the same value is shifted by −ε(H(a) + H(b) + 1), where H(a) = −Σᵢ aᵢ log aᵢ, and is often negative: the notebook prints OT\_ε(P, P) ≈ −0.67 for 100 uniform points and ε = 0.1. Always check which convention a paper or library uses. GeomLoss, for instance, uses the cost ½‖x − y‖² when p = 2. The GeomLoss library (`SamplesLoss("sinkhorn", p=2, blur=...)`) computes S\_ε on GPU for large point clouds.

### 10.8 Where Sinkhorn appears in deep learning

Sinkhorn is attractive because every step is a differentiable tensor operation, so a network can contain an OT layer and train end to end. Examples: the SuperGlue feature matcher (2020) computes soft keypoint assignments with Sinkhorn iterations (its successor LightGlue replaced them with a cheaper double-softmax); SwAV-style self-supervised learning uses Sinkhorn–Knopp to assign images to prototype clusters with balanced cluster sizes; domain adaptation and point-cloud losses use it as a fast approximation to EMD (Section 12).

### 10.9 How expensive is Sinkhorn, and how practitioners run it

- **Per iteration:** two matrix–vector products, O(nm) time, and the n × m kernel in memory (or recomputed on the fly: GeomLoss and OTT-JAX never store it, which is how they handle 10⁵–10⁶ points on a GPU).
- **Number of iterations:** the theoretical bound grows like ‖C‖\_∞/ε (times a log factor); in practice the growth is usually far slower (on the warehouse problem the notebook needs 48, 81 and 146 iterations for ε = 1, 0.1 and 0.02 to reach a marginal error of 10⁻⁹), but it does grow, and it grows faster on larger problems with more nearly-optimal routes. The theoretical guarantee (Altschuler, Weed and Rigollet, 2017; sharpened by Dvurechensky, Gasnikov and Kroshnin, 2018) is that Sinkhorn with a suitable ε returns a plan whose cost is within δ of the exact OT value in Õ(n² ‖C‖\_∞² / δ²) arithmetic operations, against roughly n³ for exact solvers. For a fixed small ε the dependence is often quoted as O(n²/ε²), which is why the flow-matching papers of Section 12.1 call large-batch Sinkhorn couplings expensive.
- **ε-scaling (annealing).** Start with a large ε (fast, blurry), divide ε by a constant (2 to 10), **warm-start** the potentials f, g from the previous level, and repeat down to the target ε. Be honest about what it buys: on a small dense problem solved in the log domain it saves little or nothing (the notebook shows 264 iterations with scaling against 146 without, for the same plan to 10⁻⁹). Its real value (Schmitzer, 2019) comes in large-scale solvers that combine it with **kernel truncation** (dropping entries of e^{−C/ε} below a threshold, which is only safe when the potentials are already close) and **multi-scale grids**; there a cold start at the target ε is not even feasible, and warm-started annealing is what makes small ε reachable at all.
- **Stopping rule.** Monitor the marginal error ‖γ𝟙 − a‖₁ (or the change in the potentials), not the change in the cost ⟨γ, C⟩, which can look converged while the plan is still infeasible (Exercise 15.10 shows a cost *below* the exact OT value after one iteration).

### Check yourself (Section 10)

1. Why is the Sinkhorn plan always strictly positive?
2. What does the Sinkhorn plan converge to as ε → ∞, and what transport cost does that give in the warehouse example?
3. Your Sinkhorn code returns NaN for ε = 0.001 with costs around 100. Why, and what are two fixes?
4. Is OT\_ε(P, Q) itself a metric? What is?

**Answers.** (1) γᵢⱼ = uᵢKᵢⱼvⱼ with Kᵢⱼ = exp(−Cᵢⱼ/ε) > 0 and positive scalings. (2) The independent coupling abᵀ; its cost Σᵢⱼ aᵢbⱼCᵢⱼ = 1.35 + 0.57 + 1.92 = 3.84. (3) exp(−100/0.001) underflows to 0, so Kv = 0 and a/0 is infinite. Fixes: log-domain iterations, and rescaling C (or increasing ε). (4) No, because OT\_ε(P, P) ≠ 0; the debiased Sinkhorn divergence S\_ε is a valid discrepancy (zero iff P = Q); its square root is not guaranteed to be a metric, so call it a divergence.

## 11. Sliced Wasserstein distance

The sliced Wasserstein distance projects both distributions onto many random lines, computes the cheap 1D Wasserstein distance on each line by sorting, and averages; it is a true metric, never larger than Wₚ, and costs O(L·n log n) for L directions.

### 11.1 Definition

For a unit vector θ ∈ S^{d−1} (the unit sphere in ℝᵈ), let θ#P denote the distribution of the projection ⟨θ, X⟩ when X \~ P. The sliced p-Wasserstein distance is

$$
SW_p^p(P,Q) = \int_{S^{d-1}} W_p^p\big(\theta_{\#}P,\; \theta_{\#}Q\big)\, d\sigma(\theta) \;=\; \mathbb{E}_{\theta\sim\mathrm{Unif}(S^{d-1})}\Big[ W_p^p\big(\theta_{\#}P,\theta_{\#}Q\big)\Big].
$$

Each inner term is a 1D problem solved exactly by sorting (Section 6). The expectation is estimated by Monte Carlo with L random directions; a uniform direction is obtained by normalising a standard Gaussian vector.

```python
import numpy as np

def sliced_wasserstein(X, Y, L=200, p=2, seed=0):
    """X, Y: (n, d) arrays with the same n and uniform weights."""
    rng = np.random.default_rng(seed)
    theta = rng.standard_normal((L, X.shape[1]))
    theta /= np.linalg.norm(theta, axis=1, keepdims=True)   # L unit directions
    xp = np.sort(X @ theta.T, axis=0)                         # (n, L) sorted projections
    yp = np.sort(Y @ theta.T, axis=0)
    return np.mean(np.abs(xp - yp) ** p) ** (1 / p)
```

In PyTorch the same code is differentiable (`torch.sort` passes gradients to the sorted values), which makes SW a popular loss for generative models, texture synthesis and point clouds. POT provides `ot.sliced_wasserstein_distance(X, Y, n_projections=...)`, which also handles unequal sizes and weights.

### 11.2 Properties with proofs

**SWₚ ≤ Wₚ.** Let (X, Y) be an optimal coupling for Wₚ(P, Q). For each θ, (⟨θ, X⟩, ⟨θ, Y⟩) is a coupling of θ#P and θ#Q, and abs(⟨θ, X − Y⟩) ≤ ‖X − Y‖ by Cauchy–Schwarz. So Wₚᵖ(θ#P, θ#Q) ≤ E‖X − Y‖ᵖ = Wₚᵖ(P, Q) for every θ, and averaging over θ preserves the inequality. ∎

**SWₚ is a metric.** Symmetry and non-negativity are inherited from Wₚ. The triangle inequality follows from the triangle inequality of Wₚ on each line plus Minkowski's inequality for the average over θ. If SWₚ(P, Q) = 0, then θ#P = θ#Q for almost every θ, and by continuity of characteristic functions for every θ; by the Cramér–Wold theorem (a distribution is determined by all its 1D projections; Primer P11), P = Q. ∎

**Cost and sample complexity.** Computing SW with L directions and n points costs O(L·n·d) for the projections plus O(L·n log n) for sorting, versus about O(n³) for exact OT. Its statistical error with n samples does not suffer the n^(−1/d) curse of Section 5.6, because each slice is a 1D problem.

### 11.3 Worked example: how much smaller can SW be?

Let P = δ₀ and Q = δ\_v in ℝᵈ (a translation by v). Each projection is a 1D translation by ⟨θ, v⟩, so W₂²(θ#P, θ#Q) = ⟨θ, v⟩². For θ uniform on the sphere, symmetry gives E θₖ² = 1/d for every coordinate k (the d values are equal and sum to E‖θ‖² = 1), so E⟨θ, v⟩² = ‖v‖²/d. Hence

$$
SW_2(P,Q) = \frac{\|v\|}{\sqrt d} \qquad\text{while}\qquad W_2(P,Q) = \|v\| .
$$

In d = 2 with p = 1, writing θ = (cos φ, sin φ) and v along the first axis, SW₁ = ‖v‖·E abs(cos φ) = (2/π)‖v‖ ≈ 0.637‖v‖. Lesson: SW is a **weaker** (smaller) discrepancy in high dimension; most random directions are nearly orthogonal to the direction in which the distributions differ. This motivates variants such as **max-sliced** Wasserstein (use the single most discriminative direction; Deshpande et al., 2019), learned or non-linear projections (generalised sliced Wasserstein; Kolouri et al., 2019), and importance-weighted choices of directions.

### Check yourself (Section 11)

1. Why is it enough to sample θ from a standard Gaussian and normalise?
2. Two image datasets give SW = 0.01 and W₁ (on mini-batches) = 3.2. Is this contradictory?
3. Why is SW differentiable with respect to the input points even though sorting is a discrete operation?

**Answers.** (1) The standard Gaussian in ℝᵈ is rotation-invariant, so its direction is uniform on the sphere. (2) No: SW ≤ W, and in high dimension SW can be much smaller (scaling like 1/√d for a shift); the two numbers are on different scales and should not be compared directly. (3) For fixed (almost everywhere) sorted order, the sorted values are a permutation of the inputs, a linear function of them, so gradients flow to the inputs through that permutation; the permutation changes only on a set of measure zero.

## 12. Modern applications

Optimal transport appears in modern deep learning in three roles: as a **loss** between distributions (WGAN, point clouds, ordinal labels), as a **coupling** that decides which samples to pair (flow matching, domain adaptation), and as an **evaluation metric** (FID, point-cloud metrics). For each paper you read, ask: which cost, which p, exact or approximate solver, and what is being coupled?

### 12.1 Optimal transport in flow matching

**Flow matching in one paragraph.** A flow-matching model (Primer P10) learns a velocity field v\_θ(t, x) so that integrating the ODE dx/dt = v\_θ(t, x) from t = 0 to 1 turns noise samples x₀ \~ p₀ into data samples x₁ \~ p₁. Training is a regression: pick a pair (x₀, x₁), a time t \~ U\[0, 1\], the point xₜ = (1 − t)x₀ + t·x₁ on the straight line between them, and fit the line's velocity:

$$
\mathcal{L}(\theta) = \mathbb{E}_{t,\;(x_0,x_1)\sim\pi}\Big[\big\|\,v_\theta\big(t,\,(1-t)x_0 + t x_1\big) - (x_1 - x_0)\big\|^2\Big].
$$

**Where OT enters: the coupling π.** The basic recipe pairs x₀ and x₁ independently (π = p₀ ⊗ p₁, often called I-CFM; it is also the first round of rectified flow). Independent pairs produce straight lines that cross each other; the network can only learn their average, so the learned trajectories are curved and many ODE steps are needed at sampling time. **OT-CFM** (Tong et al., TMLR 2024) and multisample flow matching (Pooladian et al., ICML 2023) instead draw a mini-batch of B noise vectors and B data points, solve the exact W₂² assignment between them (Section 4.3), and train on the matched pairs. Optimal pairs do not cross (Section 5.7), so the learned flow is straighter and can be sampled with fewer steps. When the full OT plan is used, the learned flow approximates the **dynamic OT** of Benamou and Brenier, which writes W₂ as the least kinetic energy needed to move P to Q:

$$
W_2^2(P,Q) = \min_{(\rho_t, v_t)} \int_0^1 \!\!\int \|v_t(x)\|^2 \rho_t(x)\, dx\, dt \quad\text{s.t.}\quad \partial_t\rho_t + \nabla\!\cdot(\rho_t v_t) = 0,\;\; \rho_0 = P,\; \rho_1 = Q.
$$

```python
import numpy as np, torch
from scipy.optimize import linear_sum_assignment

def ot_pair(x0, x1):
    """Re-order a noise batch x0 so that (x0[i], x1[i]) is the minibatch W2 assignment."""
    C = torch.cdist(x0, x1).pow(2).cpu().numpy()   # B x B squared distances
    rows, cols = linear_sum_assignment(C)
    return x0[rows], x1[cols]

# training step (sketch)
# x1 = data batch, x0 = torch.randn_like(x1)
# x0, x1 = ot_pair(x0, x1)
# t = torch.rand(len(x1), 1); xt = (1 - t) * x0 + t * x1
# loss = ((model(t, xt) - (x1 - x0)) ** 2).mean()
```

![](figures/fig5_cfm.png)

*Figure 5. Trajectories from noise (blue) to generated samples (orange) for flow matching trained with independent pairs (left) and mini-batch OT pairs (right). OT pairs give nearly straight paths (mean path length / straight-line distance 1.006 versus 1.666), which is why few Euler steps suffice in this 2D toy.*

**Caveats.** Mini-batch OT is only an approximation of the global plan, and the approximation degrades in high dimension with small batches. Exact assignment costs O(B³) per batch, and class-conditional models should match pairs within each class. Zhang et al. (2025) found that OT-FM pays off mainly with very large batches, which require multi-GPU Sinkhorn whose cost grows quickly as ε shrinks. So for image-scale models, plain mini-batch OT pairing gives far smaller gains than the 2D toy in the notebook suggests.

**Where the field went in 2025–26.** The coupling π has become a design choice in its own right. Five directions you will meet:

1. **Semidiscrete couplings** (SD-FM; Mousavi-Hosseini, Zhang, Klein and Cuturi, ICLR 2026). A training set is a finite discrete distribution, so solve semidiscrete OT from the continuous noise distribution to the **whole dataset** once, by learning one dual potential per data point with SGD (Section 12.7). During training, each fresh noise vector is paired with a data point by a maximum-inner-product search. This removes the batch-size bottleneck, and the authors report gains over both independent and mini-batch OT couplings.
2. **Model-aware couplings.** Model-Aligned Coupling (Lin, Yao and Liu, 2025) chooses, within a batch, the pairing the current network fits best rather than the cheapest one; cluster-wise OT (COT-FM, CVPR 2026) and couplings distilled from pretrained normalising flows (2026) are further variants.
3. **Designing the prior.** OT Flow Matching by Design (Malnick et al., 2026) chooses a prior, a low-frequency projection of the image plus noise, whose identity coupling with the data is already near-optimal, and reports more than 2× lower trajectory curvature.
4. **Cheaper reweighting.** Weighted CFM (Calvo-Ordoñez et al., 2025) keeps independent pairs but weights them with entropic-OT-style Gibbs factors instead of solving a batch OT problem.
5. **Theory.** Fukumizu et al. (2026) show OT-CFM is exactly a proximal method built on an extended Brenier potential, without requiring the target to have a density.

When you read a flow-matching paper, the key questions are: which coupling π, how is it computed, and at what cost per training step. The companion notebook trains I-CFM and OT-CFM on a 2D toy problem and shows the straighter OT trajectories.

### 12.2 Domain adaptation

**Setting.** Labelled source data (for example synthetic images) and unlabelled target data (real images) have different feature distributions. A classifier trained on the source performs worse on the target.

**Why W₁ is the right quantity.** Bounds of Redko, Habrard and Sebban (2017), in the Lipschitz form used by Shen et al. (2018), state, informally: if the loss of a hypothesis is K-Lipschitz in the input features, then the target error is at most the source error plus 2K·W₁(source features, target features) plus the error of the best joint hypothesis. The proof is Kantorovich–Rubinstein duality: the difference between expected losses under two distributions is E\_P f − E\_Q f for a Lipschitz f, which is at most K·W₁. So reducing W₁ between feature distributions reduces a bound on target error.

**Three method families.**

1. **OT mapping** (Courty, Flamary, Tuia, Rakotomamonjy, TPAMI 2017): solve (often regularised) OT between source and target samples, move each source sample to the **barycentric projection** x̂ᵢ = (Σⱼ γᵢⱼ yⱼ)/aᵢ, and train the classifier on the transported source samples with their labels. A class-based regulariser discourages mixing classes in the plan.
2. **Joint distribution OT, DeepJDOT** (Damodaran et al., ECCV 2018): on each mini-batch, solve OT with a cost combining feature distance and label disagreement, Cᵢⱼ = α‖g(xᵢˢ) − g(xⱼᵗ)‖² + λ·loss(yᵢˢ, h(g(xⱼᵗ))), where g is the feature extractor and h the classifier; then update g and h with the plan fixed, and repeat.
3. **Adversarial W₁ alignment, WDGRL** (Shen et al., AAAI 2018): a WGAN-GP-style critic estimates W₁ between source and target features, and the feature extractor is trained to minimise it alongside the source classification loss.

POT implements the first family in `ot.da` (for example `ot.da.SinkhornTransport`, `ot.da.EMDTransport`).

### 12.3 Point clouds: EMD versus Chamfer distance

Fan, Su and Guibas (CVPR 2017) introduced two losses for comparing a predicted point set X with a ground-truth set Y, both now standard:

$$
d_{\text{EMD}}(X,Y) = \min_{\sigma:\,X\to Y \text{ bijection}} \frac{1}{|X|}\sum_{x\in X}\|x-\sigma(x)\|, \qquad d_{\text{CD}}(X,Y) = \frac{1}{|X|}\sum_{x\in X}\min_{y\in Y}\|x-y\|^2 + \frac{1}{|Y|}\sum_{y\in Y}\min_{x\in X}\|x-y\|^2 .
$$

d\_EMD is W₁ between the uniform empirical distributions (Section 4.3 justifies the bijection). Chamfer distance only asks every point to have **some** nearby partner, so it allows many-to-one matches.

**Worked example: Chamfer is blind to density.** X = {(0,0), (0,0), (0,0), (1,0)}: three points at the origin, one at (1,0). Y = {(0,0), (1,0), (1,0), (1,0)}. Every point of X has an exact copy in Y and vice versa, so d\_CD = 0. But EMD needs a bijection: only one point of X sits at (1,0) while three are needed there, so two points must travel distance 1: d\_EMD = 2/4 = **0.5**. EMD detects that the predicted cloud has the right shape but the wrong distribution of points.

**Practice.** Exact EMD costs O(n³) per pair, too much for clouds of 2048+ points in every training step, so libraries use approximations: auction-algorithm CUDA kernels (for example the one released with MSN, Liu et al., 2020) or Sinkhorn. Some papers define "EMD" with squared distances or without the 1/n factor. Point-cloud generation metrics such as MMD-EMD, COV-EMD and 1-NNA-EMD (popularised by PointFlow, Yang et al., 2019) use EMD as the base distance between shapes. Always check the exact definition in the paper's appendix.

### 12.4 Images and signals: the classic engineering uses

- **Histogram specification is 1D optimal transport.** Mapping a grey level x through G⁻¹(F(x)), where F is the image's CDF and G the target CDF, is exactly the monotone optimal map of Section 6. Histogram equalisation is the special case G = uniform.
- **Colour transfer.** Transporting the 3D colour distribution of one image onto another (exactly on a subsample, with Sinkhorn, or slice by slice with sliced OT) recolours a photograph in the style of another.
- **Image retrieval.** Rubner et al. (2000) compared colour and texture signatures with EMD, the origin of the name.
- **Drift monitoring.** Comparing this week's sensor or feature values with a reference window using the 1D W₁ (`scipy.stats.wasserstein_distance`) gives a drift score in the same units as the measurement, easier to interpret than a p-value.

### 12.5 Text, labels and other domains

- **Word Mover's Distance** (Kusner et al., 2015): a document is a normalised bag of words, each word is a point in word-embedding space, and the distance between documents is the EMD with Euclidean cost between embeddings. Later evaluation metrics such as MoverScore (Zhao et al., 2019) apply the same idea to contextual embeddings.
- **Ordinal labels.** When classes are ordered (ratings 1–10, age groups), cross-entropy treats "predicted 9, true 10" as badly as "predicted 1, true 10". The EMD loss on the class index fixes this. NIMA (Talebi and Milanfar, 2018) uses the normalised form EMD = ((1/N) Σₖ abs(CDF\_p(k) − CDF\_q(k))^r)^{1/r} with r = 2, which is a CDF-based formula from Section 6.
- **Cross-tokenizer knowledge distillation.** When a teacher and a student LLM use different vocabularies, token-by-token KL is undefined; the Universal Logit Distillation (ULD) loss (Boizard et al., TMLR 2025) replaces KL with a Wasserstein-type loss that, under simplifying assumptions on the cost, reduces to summing absolute differences between the sorted teacher and student probability vectors.
- **Biology.** Waddington-OT (Schiebinger et al., Cell 2019) couples single-cell measurements taken at consecutive time points with unbalanced entropic OT to infer how cells develop; OT-CFM (12.1) was also evaluated on single-cell trajectory inference.
- **Robust optimisation.** Wasserstein distributionally robust optimisation trains a model to perform well on every distribution within a W-ball around the training distribution.
- **Distributional reinforcement learning.** QR-DQN and its successors learn return distributions by quantile regression, which minimises the 1D W₁ of Section 6 (details in 6.8); C51 is motivated by W\_p contraction and trained with a Cramér-like projection.
- **Multi-label and structured prediction.** Frogner et al. (NeurIPS 2015, "Learning with a Wasserstein loss") were the first to train a network with a Sinkhorn loss between predicted and target label histograms, using a label-similarity ground cost; the NIMA ordinal loss above is its 1D special case.
- **Wasserstein autoencoders** (Tolstikhin et al., ICLR 2018) minimise an OT cost between data and decoder outputs, with the coupling constraint relaxed into a penalty on the latent distribution; VAEs and GAN-like penalties appear as special cases.
- **Model fusion and alignment.** OT fusion (Singh and Jaggi, NeurIPS 2020) aligns neurons of two trained networks with an OT plan before averaging their weights, the idea behind many later model-merging methods. Sinkformers (Sander et al., AISTATS 2022) replace the row-softmax of attention by Sinkhorn so that attention matrices are doubly stochastic.

### 12.6 Choosing a variant: summary table

| Application | Quantity | Cost | Typical solver |
| --- | --- | --- | --- |
| WGAN / WGAN-GP | W₁ via its dual | Euclidean | Neural critic + gradient penalty |
| OT flow matching | Mini-batch W₂² coupling | Squared Euclidean | Assignment (Hungarian) per batch |
| Domain adaptation (OT mapping, DeepJDOT) | OT plan between domains | Squared Euclidean in features (+ label term) | Exact on mini-batches or Sinkhorn |
| Domain adaptation (WDGRL) | W₁ between features | Euclidean | Neural critic |
| Point-cloud loss | W₁ with bijection | Euclidean (sometimes squared) | Auction approximation or Sinkhorn |
| FID | W₂² between Gaussian fits | Squared Euclidean | Closed form (Section 7) |
| Histograms, drift, ordinal losses | W₁ in 1D | abs(x − y) | Sorting / CDF formula |
| Fast large-scale comparisons, generative losses | Sliced W | Euclidean | Random projections + sorting |

### 12.7 Further topics you will meet in papers

Six extensions of the basic problem appear constantly in 2026 papers; each is one idea on top of what you already know.

**Wasserstein barycenters (averaging distributions).** Given ν₁,…,ν\_K and weights λₖ summing to 1, the barycenter is the μ minimising Σₖ λₖ W₂²(μ, νₖ) (Agueh and Carlier, 2011). In 1D it averages quantile functions: F\_μ⁻¹ = Σₖ λₖ Fₖ⁻¹. Example: the equal-weight barycenter of N(0, 1) and N(4, 9) is N(2, 4), a single bump halfway between, whereas the mixture ½N(0, 1) + ½N(4, 9) is a two-humped average (Exercise 15.22). Barycenters are used to average shapes, histograms and images, and to fuse data sources. POT: `ot.lp.free_support_barycenter` (exact, small problems), `ot.barycenter` (entropic, fixed grid; Cuturi and Doucet, 2014), `ot.gaussian.bures_wasserstein_barycenter`.

![](figures/fig6_barycenter.png)

*Figure 6. Two ways to average N(0, 1) and N(4, 9). The mixture (green) superimposes them: a sharp peak at 0 and a low hump near 4. The W₂ barycenter (red) moves mass to the single intermediate shape N(2, 4).*

**Unbalanced and partial OT.** Replace the hard marginal constraints by penalties, so mass can be created or destroyed at a price τ (Chizat, Peyré, Schmitzer and Vialard, 2018):

$$
\min_{\gamma\ge 0}\; \langle\gamma, C\rangle + \tau\,\mathrm{KL}(\gamma\mathbb{1}\,\|\,a) + \tau\,\mathrm{KL}(\gamma^{\top}\mathbb{1}\,\|\,b) \;\;(+\,\varepsilon\text{-entropy}).
$$

As τ → ∞ the balanced problem returns. This handles unequal total mass and makes OT robust to outliers, which far-away mass would otherwise dominate (Section 5.5). Partial OT instead transports exactly a chosen fraction of the mass. POT: `ot.unbalanced.sinkhorn_unbalanced`, `ot.partial.partial_wasserstein`. Uses: cell growth and death in Waddington-OT, point clouds with outliers, partial domain adaptation.

**Gromov–Wasserstein (GW): OT across different spaces.** If P and Q live in different spaces (two graphs, a shape in two poses, embeddings from two models), there is no cross-cost C(x, y). GW compares distances **within** each space and couples points so that pairwise distances are preserved:

$$
\mathrm{GW}(P,Q) = \min_{\gamma\in\Pi(a,b)} \sum_{i,j,k,l} \big(D^1_{ik} - D^2_{jl}\big)^2\, \gamma_{ij}\,\gamma_{kl}.
$$

This is a non-convex quadratic program, solved in practice by repeatedly linearising it and solving an OT problem (Peyré, Cuturi and Solomon, 2016; theory by Mémoli, 2011). Fused GW combines a feature cost with the structure cost. POT: `ot.gromov.gromov_wasserstein`. Uses: graph matching, aligning single-cell measurements from different technologies, unsupervised alignment of embedding spaces.

**Schrödinger bridges: the dynamic view of entropic OT.** Among all random processes that start at P and end at Q, find the one closest (in KL) to Brownian motion (Primer P11). Its start–end coupling is exactly the entropic OT plan of Section 10 for cost ‖x − y‖² with ε = 2σ², where σ² is the variance per unit time of the reference Brownian motion; as σ → 0 it reduces to dynamic OT (12.1). Diffusion Schrödinger bridges (De Bortoli et al., 2021) and simulation-free bridges trained with score and flow matching (\[SF\]²M; Tong et al., 2024) learn such processes with neural networks. This is the bridge from Sinkhorn to diffusion models.

**Semi-discrete OT.** From a continuous P to a discrete Q = Σⱼ bⱼδ\_{yⱼ}, the optimal map sends x to the yⱼ minimising c(x, yⱼ) − vⱼ, which partitions space into cells, one per target point (Laguerre cells for squared cost). The dual is a concave problem in the finite vector v, solvable by stochastic gradient ascent using samples of P (Genevay, Cuturi, Peyré and Bach, 2016). This is the engine of SD-FM (12.1).

**Neural OT maps.** To get a map you can apply to new points, parametrise the Brenier potential φ with an input-convex neural network, so T = ∇φ is a gradient of a convex function by construction (Makkuva et al., 2020), or train any network with a "Monge gap" regulariser (Uscidda and Cuturi, 2023). OTT-JAX implements these; uses include predicting how cells respond to a drug from unpaired before/after measurements.

### Check yourself (Section 12)

1. In OT-CFM, what exactly is solved with optimal transport, and what is learned by the network?
2. Give an example where Chamfer distance is 0 but the clouds differ (different from the one above).
3. Why does the domain-adaptation bound use W₁ and not W₂?

**Answers.** (1) OT pairs noise samples with data samples inside each mini-batch (a W₂² assignment); the network learns the velocity field that regresses onto the straight-line velocities of those pairs. (2) X = {a, a, b}, Y = {a, b, b} for any two distinct points a and b: every point has an exact partner, so Chamfer = 0, but EMD = d(a, b)/3. (3) The step "E\_P f − E\_Q f ≤ K·W₁" is Kantorovich–Rubinstein duality, which holds for W₁ and Lipschitz functions; W₁ ≤ W₂, so a W₂ version also holds but is looser.

## 13. Implementation guide in Python

Use SciPy for 1D and small assignment problems, POT for everything else (exact, Sinkhorn, sliced, Gaussian, domain adaptation), and keep three facts in mind: `ot.dist` defaults to **squared** Euclidean cost, `ot.wasserstein_1d` returns **Wₚᵖ**, and Sinkhorn in float32 needs the log domain or a rescaled cost.

Versions used to test every snippet in this tutorial and the notebook (November 2026): NumPy 2.5.4, SciPy 1.18.1, POT 0.9.7.post1, PyTorch 2.15.0 (CPU); the first edition was tested with PyTorch 2.14.1 and the numbers quoted in 13.7 come from the PyTorch 2.15 run. The bundle's `requirements.txt` pins these versions.

### 13.1 Library map

| Task | Function | Returns | Watch out for |
| --- | --- | --- | --- |
| W₁ in 1D (samples or weighted points) | `scipy.stats.wasserstein_distance(u_values, v_values, u_weights, v_weights)` | W₁ | Arguments are locations; histograms go in the weights |
| Wₚ in 1D | `ot.wasserstein_1d(u, v, u_weights, v_weights, p=p)` | **Wₚᵖ** | Take the p-th root yourself |
| Small exact problems in any dimension | `scipy.stats.wasserstein_distance_nd(u_values, v_values, ...)` (SciPy ≥ 1.13) | W₁ (Euclidean) | Solves a generic LP: fine for hundreds of points, slow beyond |
| Cost matrix | `ot.dist(X, Y, metric=...)` | n × m matrix | **Default metric is 'sqeuclidean'**; pass `metric='euclidean'` for EMD |
| Exact plan / exact cost | `ot.emd(a, b, M)` / `ot.emd2(a, b, M)` | plan γ / ⟨γ, M⟩ | a and b must have equal sums; `log=True` returns potentials u, v |
| Equal-size uniform clouds | `scipy.optimize.linear_sum_assignment(M)` | row and column indices | Average M\[rows, cols\] to get the OT cost |
| Entropic OT | `ot.sinkhorn(a, b, M, reg)` / `ot.sinkhorn2(...)` | plan / ⟨γ\_ε, M⟩ (no entropy term) | Use `method='sinkhorn_log'` for small reg or float32 |
| Sliced Wasserstein | `ot.sliced_wasserstein_distance(X, Y, a, b, n_projections, p, seed)` | SWₚ (Monte Carlo) | Random; fix `seed` for reproducibility |
| Gaussians | `ot.gaussian.bures_wasserstein_distance(ms, mt, Cs, Ct)` | W₂ | Inputs are means and covariances |
| Domain adaptation | `ot.da.EMDTransport`, `ot.da.SinkhornTransport` | fitted transport objects | `.fit(Xs=..., Xt=...)`, then `.transform(Xs=...)` |
| Large GPU point clouds | GeomLoss `SamplesLoss("sinkhorn", p=..., blur=...)` | Sinkhorn divergence | `blur` ≈ ε^(1/p): the length scale below which detail is ignored |

### 13.2 Recipe: EMD between two sets of samples

```python
import numpy as np, ot

X = np.random.randn(500, 3)            # samples from P
Y = np.random.randn(400, 3) + 1.0      # samples from Q
a = np.full(len(X), 1 / len(X))       # uniform weights
b = np.full(len(Y), 1 / len(Y))

M = ot.dist(X, Y, metric="euclidean")   # ground cost d(x, y)
emd = ot.emd2(a, b, M)                   # W1 = EMD
w2 = np.sqrt(ot.emd2(a, b, ot.dist(X, Y)))   # default sqeuclidean -> W2^2, so take sqrt
print(emd, w2)
```

### 13.3 Recipe: EMD between two grey-scale images

Treat each image as a distribution over pixel locations: weights are normalised intensities, locations are pixel coordinates, and the ground cost is the distance between pixels.

```python
def image_emd(img1, img2):
    h, w = img1.shape
    yy, xx = np.mgrid[0:h, 0:w]
    pos = np.stack([yy.ravel(), xx.ravel()], 1).astype(float)
    a = img1.ravel() / img1.sum()
    b = img2.ravel() / img2.sum()
    M = ot.dist(pos, pos, metric="euclidean")      # (h*w) x (h*w): keep images small (e.g. 28 x 28)
    return ot.emd2(a, b, M)
```

For a 28 × 28 image the cost matrix has 784² ≈ 615 000 entries, which is fine; for 256 × 256 it would have 4.3 × 10⁹ entries, so use Sinkhorn on a down-sampled image, sliced OT, or a separable/convolutional Sinkhorn (`ot.bregman.convolutional_barycenter2d` uses this trick).

### 13.4 Recipe: a differentiable OT loss in PyTorch

POT functions accept PyTorch tensors and return tensors that support `.backward()`. For `ot.emd2`, the gradient flows through the cost matrix with the optimal plan held fixed (the envelope theorem), and through the weights via the dual potentials.

```python
import torch, ot

X = torch.randn(64, 2, requires_grad=True)      # e.g. generator output
Y = torch.randn(64, 2) + 2                       # target batch
a = torch.full((64,), 1 / 64); b = torch.full((64,), 1 / 64)

loss_exact = ot.emd2(a, b, ot.dist(X, Y, metric="euclidean"))            # exact W1
loss_sink = ot.sinkhorn2(a, b, ot.dist(X, Y), reg=0.1, method="sinkhorn_log")  # entropic, squared cost
loss_sliced = ot.sliced_wasserstein_distance(X, Y, n_projections=128, seed=0)
(loss_exact + loss_sink + loss_sliced).backward()   # gradients now in X.grad
```

**A real pitfall we hit while testing.** With float32 tensors (PyTorch's default), squared costs up to about 58 and `reg=0.1`, the default (non-log) `ot.sinkhorn2` returned 0.0003 instead of the correct ≈ 8.4, printing only a numerical warning. The reason: exp(−58/0.1) underflows in float32 (whose smallest normal number is about e^−87). `method="sinkhorn_log"` returned 8.40 in the same setting. Always use the log domain (or divide M by M.max() and scale ε accordingly) when training in float32.

### 13.5 Which method should I use?

| Situation | Recommended | Why |
| --- | --- | --- |
| 1D data (any size) | Sorting / CDF formula | Exact and O(n log n) |
| Up to a few thousand points, need the exact value or a sparse plan | `ot.emd` / `ot.emd2` | Exact; network simplex |
| Equal-size uniform batches (flow matching, point clouds) | `linear_sum_assignment` | Exact; gives a matching directly |
| Tens of thousands of points, GPU, need gradients | Sinkhorn divergence (GeomLoss or POT, log domain) | O(n²) per iteration, parallel, smooth |
| Very large n or high dimension, cheap loss | Sliced Wasserstein | O(L·n log n), dimension-free sample complexity |
| Gaussian approximations (FID-style metrics) | Closed form (Section 7) | Exact for Gaussians, one matrix square root |
| Want W₁ in high dimension via a network | WGAN-GP-style critic | Scales to images, but only an approximate, biased estimate |

### 13.6 Debugging checklist

1. Do a and b each sum to 1 (or at least to the same total)? `ot.emd` raises an error when they do not.
2. Is the cost squared or not? Are you reporting W₂² or W₂, Wₚᵖ or Wₚ?
3. Is everything float64 for exact solvers? POT converts, but your own code may not.
4. Did the solver converge? `ot.emd` warns when it hits `numItermax`; Sinkhorn returns whatever it has after `numItermax` iterations, so check the marginals of the returned plan.
5. Is ε meaningful relative to the costs? Compare `reg` with `M.max()` or `np.median(M)`.
6. Are you comparing numbers computed on samples of different sizes? Empirical Wasserstein distances are biased upward and the bias depends on n (Section 5.6, Exercise 15.12). Report a "noise floor" (distance between two independent samples of the reference distribution) next to your number; the notebook does this for the WGAN and flow-matching experiments.

### 13.7 What the companion notebook shows

The notebook reproduces every example. Highlights from its run (PyTorch 2.15, seed 0): the WGAN-GP critic's estimate tracks the exact sample W₁ but stays below it (0.20 versus 0.26 after 3000 iterations, with a real-versus-real noise floor of about 0.10); in the flow-matching experiment, OT-CFM reaches the data distribution with a **single** Euler step (W₂ = 0.40, noise floor ≈ 0.35) while I-CFM needs about 5 steps (W₂ = 1.84 with 1 step, 0.41 with 5), and OT-CFM trajectories are almost perfectly straight (mean path length / straight-line distance = 1.006, versus 1.67 for I-CFM). Exact numbers vary slightly with random seeds and library versions (re-running the first edition's notebook under PyTorch 2.15 instead of 2.14 changed the WGAN numbers in the second decimal and left the flow-matching numbers unchanged). In the domain-adaptation cell the class regulariser raises the fraction of transported mass that stays within a class from 0.76 (exact OT) to 0.86, although accuracy is already saturated at 0.995 on that easy toy. These are 2D toy problems: in high-dimensional image generation the gains from mini-batch OT pairing are much smaller (Section 12.1 explains why and what replaced it).

## 14. Pitfalls, reading papers, and interview questions

Most mistakes with EMD come from mixing up variants (W₁ vs W₂², exact vs entropic vs sliced, balanced vs unbalanced) or from forgetting that sample-based estimates are biased; the checklists below catch them.

### 14.1 Twelve common mistakes

| Mistake | Correct statement |
| --- | --- |
| Reporting `ot.emd2(a, b, ot.dist(X, Y))` as the EMD | That is W₂² (squared cost). EMD needs `metric='euclidean'` |
| Treating Wₚᵖ as Wₚ | `ot.wasserstein_1d` and `ot.emd2` with squared cost return Wₚᵖ; take the root before comparing or reporting distances |
| Passing histogram counts as values to `scipy.stats.wasserstein_distance` | Values are bin centres; counts go in `u_weights`, `v_weights` |
| Assuming W₁ between Gaussians is abs(m₁ − m₂) | True only for equal variances; W₂² = Δm² + Δσ² in 1D, and W₁ is a folded-normal mean |
| Calling Rubner's EMD for unequal masses a metric | With partial matching the triangle inequality and identity can fail; normalise or use unbalanced OT |
| Believing OT\_ε(P, P) = 0 | Entropic OT is biased; use the Sinkhorn divergence for a discrepancy that vanishes at P = Q |
| Comparing W values computed with different sample sizes | Empirical W is biased upward and the bias shrinks with n; report a real-vs-real noise floor |
| Comparing sliced W with full W | SW ≤ W and can be smaller by a factor about √d; they are different scales |
| Reading the WGAN critic loss as the true W₁ between datasets | It is a biased, regularised estimate useful for monitoring only |
| Using batch normalisation in a WGAN-GP critic | The per-sample gradient penalty is invalid with batch statistics; use layer normalisation or none |
| Running Sinkhorn in float32 with small ε and the default (non-log) solver | Underflow can return silently wrong values; use the log domain or rescale the cost |
| Assuming an optimal transport **map** always exists | Only couplings always exist; maps exist under conditions (e.g. P has a density, Brenier) |

### 14.2 How to read OT in a paper: six questions

1. **What are P and Q?** Data vs model, source vs target features, noise vs data within a mini-batch, two point clouds, two histograms?
2. **What is the ground cost?** Euclidean, squared Euclidean, cosine, a learned cost, a cost with a label term (DeepJDOT)?
3. **Which quantity?** W₁, W₂, W₂², entropic OT\_ε, Sinkhorn divergence S\_ε, sliced or max-sliced, unbalanced or partial OT, a closed form (Gaussian, 1D)?
4. **Which solver?** Exact LP or assignment, Sinkhorn (ε value, number of iterations, log domain?), neural dual (critic), random projections?
5. **What is used: the value, the plan, or the potentials?** A loss uses the value; flow matching and domain adaptation use the plan; WGAN and OT maps use the potentials.
6. **On what sample size?** Mini-batch OT on 256 points is very different from OT between full datasets.

**Notation translator.**

| You may see | It means |
| --- | --- |
| Π(μ, ν), Γ(μ, ν), 𝒰(a, b), C(μ, ν) | Set of couplings / transport plans |
| π, γ, P (matrix), T (matrix) | A transport plan |
| T#μ = ν, T\_♯μ, push-forward | The map T moves μ onto ν (Monge) |
| W\_c(μ, ν), 𝒯\_c(μ, ν), OT(μ, ν), L\_C(a, b) | Optimal transport cost with cost c (no root taken) |
| 𝒲ₚ, Wₚ, dₚ | p-Wasserstein distance (root taken) |
| ‖f‖\_L ≤ 1, Lip(f) ≤ 1 | 1-Lipschitz constraint from Kantorovich–Rubinstein duality |
| OT\_ε, W\_ε, "Sinkhorn distance" | Entropic OT (biased) |
| S\_ε, "Sinkhorn divergence", "debiased Sinkhorn" | Bias-corrected entropic OT |
| φ, ψ, f, g, (u, v), "Kantorovich potentials" | Dual variables |
| φ^c, f^c, "c-transform" | Best second potential given the first |
| "EMD" in a point-cloud paper | Usually W₁ with a bijection, often computed approximately |

### 14.3 Interview questions with model answers

**Q1. Define EMD in one sentence, then in one equation.** The minimum total work (mass × distance) needed to move one distribution onto another. W₁(P, Q) = min over couplings γ ∈ Π(P, Q) of E\_{(x,y)\~γ}‖x − y‖.

**Q2. Why did WGAN replace JS divergence with W₁?** Real and generated distributions typically live on low-dimensional, non-overlapping sets. There JS is constant (log 2) and gives zero gradients, while W₁ varies smoothly with the distance between the sets and gives useful gradients. W₁ is also continuous in the generator's parameters under mild conditions.

**Q3. Is EMD a metric?** Yes, for distributions with equal total mass and finite first moment, when the ground cost is a metric. Not for Rubner's partial-matching version with unequal masses.

**Q4. How do you compute EMD in 1D?** Sort both samples and average the absolute differences of matched order statistics (equal sizes), or integrate abs(F − G) using the CDFs (general case). O(n log n).

**Q5. What does exact OT cost computationally, and what are the alternatives?** Network simplex scales roughly cubically in n in practice and needs O(n²) memory for the cost matrix. Alternatives: Sinkhorn (O(n²) per iteration, GPU, approximate), sliced W (O(L·n log n)), closed forms (1D, Gaussians), neural critics.

**Q6. What does entropic regularisation buy you, and what does it cost?** A unique, smooth, dense solution computable by simple, differentiable matrix scaling (Sinkhorn), and better sample complexity. The cost is bias: blurred plans and OT\_ε(P, P) ≠ 0, fixed by the Sinkhorn divergence, plus numerical issues for small ε (fixed by log-domain iterations).

**Q7. State Kantorovich–Rubinstein duality. Why is it special to W₁?** W₁(P, Q) = sup over 1-Lipschitz f of E\_P f − E\_Q f. For a metric cost, the two dual potentials collapse into a single Lipschitz function (v = −u); for Wₚᵖ with p > 1 two potentials with a coupled constraint remain.

**Q8. How can you enforce the Lipschitz constraint on a critic network, and what are the trade-offs?** Weight clipping (simple, but capacity loss and sensitive to the clip value), gradient penalty (soft, effective, needs double backprop and no batch norm), spectral normalisation (cheap per-layer bound, can be loose), Lipschitz-by-design architectures.

**Q9. Why is the WGAN-GP penalty applied at interpolates between real and fake points?** The optimal critic has unit gradient norm on segments joining points paired by the optimal coupling, so those are the points where the constraint should be tight; random real–fake pairs are a cheap proxy.

**Q10. W₁ or W₂: when would you use each?** W₁ when you want robustness to outliers and the dual critic (GANs, drift scores, histogram comparison). W₂ when you want the geometry of straight-line interpolation, closed forms for Gaussians, Brenier maps and connections to flows (flow matching, barycenters, FID).

**Q11. Monge versus Kantorovich?** Monge seeks a deterministic map x ↦ T(x); it can fail to exist (cannot split a Dirac). Kantorovich seeks a coupling (mass may split); it always has a solution and is a linear program.

**Q12. How does optimal transport improve flow matching?** Pairing noise and data samples with a mini-batch OT plan instead of at random produces non-crossing, nearly straight conditional paths, so the learned velocity field is simpler and can be integrated with far fewer steps. Mini-batch OT helps little at image scale, so 2025–26 methods obtain better couplings differently, for example semidiscrete OT against the whole dataset or model-aware pairings (Section 12.1).

**Q13. EMD or Chamfer for point clouds?** Chamfer is cheap and allows many-to-one matches, so it ignores point density (can be 0 for different clouds). EMD enforces a bijection and captures density, but is expensive and is usually approximated.

**Q14. Why is estimating W from samples hard in high dimension?** The empirical estimate of W₁ converges like n^(−1/d) for d ≥ 3 (curse of dimensionality) and is biased upward. Sliced Wasserstein keeps the 1D rate in n, and entropic OT converges like n^(−1/2), but in both cases the constants grow with d (exponentially in d/ε for entropic OT), so the curse is softened, not removed; and both estimate a different quantity from W₁.

**Q15. How is FID related to the Wasserstein distance?** FID is W₂² between Gaussians fitted (mean and covariance) to Inception features of real and generated images, computed with the Gaussian closed form.

**Q16. How would you build a drift monitor with EMD?** For each numeric feature compute the 1D W₁ between a reference window and the current window (`scipy.stats.wasserstein_distance`), normalise by the feature's reference spread (e.g. its interquartile range or standard deviation) so features are comparable, establish a baseline by computing the same score between two reference windows, and alert when the score exceeds that baseline by a chosen margin. W₁ is in the feature's own units, which makes alerts easy to explain.

**Q17. Can EMD be used as a classification loss?** Yes, when classes are ordered: compute W₁ (or its CDF-based squared variant) between the predicted and target distributions over class indices, so near-misses are penalised less than far misses.

## 15. Exercises with full solutions

Twenty-five exam-style exercises, ordered roughly by section and marked by difficulty (★ routine, ★★ exam level, ★★★ challenge). All statements come first; solutions follow in 15.S so you are not tempted to peek. Exercises marked \[NB\] have a numerical check in the notebook.

### Exercise statements

**15.1 ★ (1D, CDF and quantiles) \[NB\].** P and Q live on the points {0, 1, 2} with weights a = (0.2, 0.5, 0.3) and b = (0.5, 0.1, 0.4). Compute W₁ with the CDF formula, compute W₂, and describe an optimal plan.

**15.2 ★★ (transportation LP and a certificate) \[NB\].** a = (0.6, 0.4), b = (0.2, 0.3, 0.5), C = \[\[4, 2, 5\], \[3, 6, 1\]\]. (a) Find the north-west corner plan and the greedy plan with their costs. (b) Prove that one of them is optimal using potentials. (c) Is the optimum unique?

**15.3 ★ (Dirac versus spread) \[NB\].** Compute Wₚ(δ₀, Uniform\[−1, 1\]) for every p ≥ 1. Evaluate p = 1, 2 and the limit p → ∞.

**15.4 ★★ (when uncrossing works, and when it fails).** (a) For x₁ ≤ x₂ and y₁ ≤ y₂, prove (x₁ − y₁)² + (x₂ − y₂)² ≤ (x₁ − y₂)² + (x₂ − y₁)² by direct expansion. (b) Show that with the concave cost c(x, y) = abs(x − y)^(1/2) the sorted (non-crossing) matching can be strictly worse. Use x = {0, 1}, y = {1, 2}.

**15.5 ★★ (total variation is OT with a blind cost).** For distributions a, b on the same finite set, with cost Cᵢⱼ = 1 if i ≠ j and 0 if i = j, prove that OT = 1 − Σₖ min(aₖ, bₖ) = ½Σₖ abs(aₖ − bₖ).

**15.6 ★★ (translation).** Let X have finite p-th moment, P its law and Q the law of X + v. Prove Wₚ(P, Q) = ‖v‖ for every p ≥ 1.

**15.7 ★ (two uniforms) \[NB\].** Compute W₂²(Uniform\[0, 1\], Uniform\[a, a + s\]) for s > 0, first by quantiles and then using the decomposition of Exercise 15.8. Evaluate for a = 1, s = 3.

**15.8 ★★ (W₂ separates mean and shape).** Let P, Q on ℝᵈ have means m\_P, m\_Q and finite second moments; let P̃, Q̃ be their centred versions (laws of X − m\_P and Y − m\_Q). Prove W₂²(P, Q) = ‖m\_P − m\_Q‖² + W₂²(P̃, Q̃).

**15.9 ★★ (find the optimal critic) \[NB\].** P = ½δ₀ + ½δ₄ and Q = ½δ₁ + ½δ₂ on ℝ. (a) Compute W₁. (b) Find an optimal 1-Lipschitz critic f and verify the duality. (c) Is f unique up to a constant?

**15.10 ★★ (Sinkhorn by hand) \[NB\].** Use Example 2.2: a = (0.5, 0.5), b = (0.25, 0.75), C = \[\[1, 3\], \[1, 1\]\] (exact OT = 1.5). (a) With ε = 1 and v⁽⁰⁾ = (1, 1), carry out one full Sinkhorn iteration (u then v). Give the plan, its marginals and its cost. (b) Prove that as ε → ∞ the entropic plan tends to abᵀ.

**15.11 ★★ (sliced versus full W₂ for Gaussians) \[NB\].** P = N(0, I\_d), Q = N(0, s²I\_d) with s > 0. Compute SW₂(P, Q) and W₂(P, Q). What happens as d grows?

**15.12 ★★★ (mini-batch Wasserstein is biased upward) \[NB\].** Let P̂ₙ and Q̂ₙ be empirical distributions of n i.i.d. samples from P and Q (independent of each other). (a) Prove E\[Wₚᵖ(P̂ₙ, Q̂ₙ)\] ≥ Wₚᵖ(P, Q). (b) Show the inequality is strict when P = Q is continuous. (c) Interpret the notebook numbers for P = Q = N(0, I₂).

**15.13 ★★ (what weight clipping really enforces) \[NB\].** A WGAN critic is an MLP 2 → 128 → 128 → 1 with ReLU activations and every weight clipped to \[−0.01, 0.01\] (ignore biases). (a) Give an upper bound on its Lipschitz constant. (b) What does this imply about the quantity the critic estimates?

**15.14 ★ (coding: histogram EMD without libraries) \[NB\].** Write `emd_hist(h1, h2)` that returns W₁ between two 256-bin grey-level histograms (bin width 1, arbitrary non-negative counts) using only NumPy, and explain why it works.

**15.15 ★★ (reading papers).** For each description, name the OT quantity, the ground cost and the solver. (a) A point-cloud completion paper minimises the average distance between matched points, the matching being a bijection found by an auction algorithm. (b) A generative-model paper uses a loss with ε = 0.05 that subtracts half of each distribution's self-transport term. (c) A domain-adaptation paper trains a critic with a gradient penalty on source and target features and minimises its output gap. (d) A flow-matching paper draws pairs (x₀, x₁) from the plan minimising Σ‖x₀ − x₁‖² within each batch. (e) A flow-matching paper learns one dual potential per training image and pairs each noise sample with the image maximising an inner product minus that potential.

**15.16 ★ (true or false, with a one-line reason).**

1. W₁(P, Q) = 0 implies P = Q.
2. If KL(P ‖ Q) = ∞ then W₁(P, Q) = ∞.
3. The Sinkhorn plan has at most n + m − 1 nonzero entries.
4. W₂ ≥ W₁ for all P, Q.
5. For uniform clouds of equal size, some optimal plan is a permutation.
6. In 1D, the quantile coupling is optimal for the cost abs(x − y)^(1/2).
7. In d = 1, SWₚ = Wₚ.
8. A WGAN critic's output must lie in \[0, 1\].
9. FID equals W₂ between the real and generated image distributions.
10. As ε → ∞ the entropic plan tends to the independent coupling.

**15.17 ★★★ (EMD versus total variation).** Let P, Q be discrete on a finite set of points whose pairwise distances lie between d\_min > 0 and D (the diameter). Prove d\_min·TV(P, Q) ≤ W₁(P, Q) ≤ D·TV(P, Q), where TV = ½Σₖ abs(aₖ − bₖ). Interpret for histograms with unit bin spacing.

**15.18 ★★ (gradients and kinks) \[NB\].** P = ½δ\_{x₁} + ½δ\_{x₂} and Q = ½δ₀ + ½δ₄ on ℝ, cost (x − y)². (a) For x₁ < x₂, compute ∂W₂²/∂x₁ and ∂W₂²/∂x₂ with the formula of 8.6 and check by differentiating the closed form. (b) Fix x₂ = 2 and describe W₂² as a function of x₁ ∈ ℝ. Where is it not differentiable, and what kind of kink is it?

**15.19 ★★ (why couplings matter in flow matching) \[NB\].** Source P = ½δ₀ + ½δ₂, target Q = ½δ₁ + ½δ₃ on ℝ, straight-line interpolation xₜ = (1 − t)x₀ + t·x₁. (a) With the independent coupling, compute the ideal velocity at t = 0 at x = 0 and at x = 2 (the average of x₁ − x₀ given x₀), take a single Euler step of size 1, and compute W₂ between the result and Q. (b) Repeat with the OT coupling.

**15.20 ★★ (the gradient penalty is a soft constraint) \[NB\].** Real P = δ₀, fake Q = δ\_θ with θ > 0. Restrict the critic to f(x) = −s·x with s ≥ 0, so its gradient norm is s everywhere, and maximise the WGAN-GP critic objective J(s) = E\_P f − E\_Q f − λ(s − 1)². (a) Find s\* and J\*. (b) Evaluate for λ = 10 and θ = 1, 10. (c) What does this say about reading the critic value as W₁?

**15.21 ★★ (barycentric mapping in domain adaptation) \[NB\].** Source points {0, 1} with weights (½, ½); target points {2, 4, 6} with weights (⅓, ⅓, ⅓); cost (x − y)². (a) Find the optimal plan. (b) Compute the barycentric projections T̄(0), T̄(1). (c) Compare the variance of the mapped source points with the target variance and explain the difference.

**15.22 ★★ (Wasserstein barycenter versus mixture) \[NB\].** (a) Show that the equal-weight W₂ barycenter of N(0, 1) and N(4, 9) is N(2, 4). (b) Compute its W₂ distance to each input. (c) Compute the mean and variance of the mixture ½N(0, 1) + ½N(4, 9) and describe how the two "averages" differ.

**15.23 ★ (spot the bug) \[NB\].** Each snippet is meant to compute the EMD (W₁) and contains one mistake. Find it and state what the code actually computes.

```python
# (a) two 1D samples x, y
d = scipy.stats.wasserstein_distance(np.histogram(x, bins=50)[0], np.histogram(y, bins=50)[0])
# (b) two point clouds X (n x d), Y (m x d), uniform weights a, b
d = ot.emd2(a, b, ot.dist(X, Y))
# (c) same inputs
d = ot.sinkhorn2(a, b, ot.dist(X, Y, metric="euclidean"), reg=1e-3)
# (d) two weighted 1D distributions on points x, y with weights a, b
d = ot.wasserstein_1d(x, y, a, b, p=2)
# (e) W1 between a batch of generated images and a batch of real images, 64 each, reported next to a
#     number from another paper that used batches of 4096
```

**15.24 ★★ (solve a dual by hand).** Take Example 2.2: a = (0.5, 0.5) on x = (0, 2), b = (0.25, 0.75) on y = (1, 3), C = \[\[1, 3\], \[1, 1\]\]. (a) Write the dual LP (two variables u₁, u₂ and two variables v₁, v₂, four constraints). (b) Use complementary slackness with the optimal plan found in Section 2.2 (routes (1,1), (1,2), (2,2) used) to solve for the potentials up to the usual shift, and verify that the unused route (2,1) satisfies its constraint. (c) Verify the dual value equals 1.5. (d) Write the 1-Lipschitz critic f(z) = minⱼ(abs(z − yⱼ) − vⱼ) of Section 8.3 and check that E\_P f − E\_Q f = 1.5.

**15.25 ★★ (weighted 1D Wₚ for any p) \[NB\].** Write `w_p_1d_weighted(x, y, a, b, p)` returning Wₚ between Σᵢ aᵢδ\_{xᵢ} and Σⱼ bⱼδ\_{yⱼ} for any p ≥ 1, using the quantile formula of 6.1, in O((n + m) log(n + m)) time. Test it on Example 6.A (W₁ = 1.5, W₂² = 3) and against `ot.wasserstein_1d`.

### 15.S Solutions

**Solution 15.1.** CDFs: F = 0.2, 0.7, 1 and G = 0.5, 0.6, 1 at x = 0, 1, 2. On \[0, 1), abs(F − G) = 0.3; on \[1, 2), abs(F − G) = 0.1; beyond 2 both equal 1. So **W₁ = 0.3 + 0.1 = 0.4**.

For W₂ use quantile functions. P's quantile is 0 on t ∈ \[0, 0.2), 1 on \[0.2, 0.7), 2 on \[0.7, 1). Q's is 0 on \[0, 0.5), 1 on \[0.5, 0.6), 2 on \[0.6, 1). They differ by 1 on \[0.2, 0.5) (length 0.3) and on \[0.6, 0.7) (length 0.1), and agree elsewhere. So W₂² = 0.3·1² + 0.1·1² = 0.4 and **W₂ = √0.4 ≈ 0.632**. W₁ and W₂² coincide here because every moved unit travels exactly distance 1. Optimal plan: keep 0.2 at 0, 0.1 at 1 and 0.3 at 2 in place; move 0.3 from 1 to 0 and 0.1 from 1 to 2.

**Solution 15.2.** (a) North-west: γ₁₁ = 0.2, γ₁₂ = 0.3, γ₁₃ = 0.1, γ₂₃ = 0.4, cost 0.8 + 0.6 + 0.5 + 0.4 = **2.3**. Greedy: cheapest cell (2,3) cost 1 takes 0.4 (row 2 done); (1,2) cost 2 takes 0.3; (1,1) cost 4 takes 0.2; (1,3) cost 5 takes 0.1. Same plan, cost 2.3.

(b) Basic cells (1,1), (1,2), (1,3), (2,3), that is 4 = n + m − 1 routes. Set u₁ = 0: v₁ = 4, v₂ = 2, v₃ = 5, and u₂ = 1 − 5 = −4. Reduced costs on unused cells: C̄₂₁ = 3 + 4 − 4 = 3 ≥ 0 and C̄₂₂ = 6 + 4 − 2 = 8 ≥ 0, so by the lemma of 4.4 the plan is optimal. Check: Σaᵢuᵢ + Σbⱼvⱼ = (0 − 1.6) + (0.8 + 0.6 + 2.5) = 2.3.

(c) Yes: every non-basic reduced cost is strictly positive, so any plan using cell (2,1) or (2,2) costs strictly more.

**Solution 15.3.** Only one coupling exists: X = 0, Y \~ Uniform\[−1, 1\]. So Wₚᵖ = E abs(Y)ᵖ = ∫₀¹ yᵖ dy = 1/(p + 1), and **Wₚ = (p + 1)^(−1/p)**. W₁ = 1/2, W₂ = 1/√3 ≈ 0.577, and Wₚ → 1 as p → ∞, since (p + 1)^(1/p) → 1. The limit W\_∞ = 1 is the largest distance any unit of mass must travel (5.4). This illustrates Wₚ ≤ W\_q for p ≤ q.

**Solution 15.4.** (a) Expand both sides. The squares x₁², x₂², y₁², y₂² appear on both sides and cancel, leaving

$$
\text{LHS}-\text{RHS} = -2x_1y_1 - 2x_2y_2 + 2x_1y_2 + 2x_2y_1 = -2\,(x_2-x_1)(y_2-y_1) \le 0 .
$$

(b) Sorted matching 0→1, 1→2 costs 1 + 1 = 2. Crossing matching 0→2, 1→1 costs √2 + 0 ≈ 1.414 < 2. With concave costs it is cheaper to make one long trip and leave other mass in place, so optimal plans can cross. This is why Section 6's sorting algorithm requires p ≥ 1 (a convex cost).

**Solution 15.5.** For any coupling (X, Y), the cost is E\[𝟙(X ≠ Y)\] = Pr(X ≠ Y) = 1 − Σₖ Pr(X = Y = k). Since Pr(X = Y = k) ≤ min(Pr(X = k), Pr(Y = k)) = min(aₖ, bₖ), every coupling costs at least 1 − Σₖ min(aₖ, bₖ). The bound is attained: put γₖₖ = min(aₖ, bₖ) on the diagonal. The leftover masses aₖ − min(aₖ, bₖ) (rows) and bₖ − min(aₖ, bₖ) (columns) have equal totals and are never both positive at the same index k, so they can be coupled off the diagonal (for example by the north-west rule), each unit costing 1. Finally min(α, β) = (α + β − abs(α − β))/2, so Σₖ min(aₖ, bₖ) = 1 − ½Σₖ abs(aₖ − bₖ). ∎

**Solution 15.6.** Upper bound: the coupling (X, X + v) has d(X, X + v) = ‖v‖ surely, so Wₚ ≤ ‖v‖. Lower bound: for v ≠ 0 let e = v/‖v‖ and f(z) = ⟨z, e⟩, which is 1-Lipschitz by Cauchy–Schwarz. By Kantorovich–Rubinstein and symmetry of W₁, W₁(P, Q) ≥ E\_Q f − E\_P f = E⟨X + v, e⟩ − E⟨X, e⟩ = ⟨v, e⟩ = ‖v‖. Since Wₚ ≥ W₁ (monotonicity in p), Wₚ ≥ ‖v‖. ∎

**Solution 15.7.** Quantiles t and a + st, difference a + (s − 1)t:

$$
W_2^2 = \int_0^1 \big(a+(s-1)t\big)^2\,dt = a^2 + a(s-1) + \frac{(s-1)^2}{3}.
$$

Check with means and shapes: the means are 1/2 and a + s/2, which differ by a + (s − 1)/2; the standard deviations are 1/√12 and s/√12. For two members of the same location-scale family, W₂² = (difference of means)² + (difference of standard deviations)², because the quantile functions are affine in each other. This gives (a + (s − 1)/2)² + (s − 1)²/12, which expands to the same expression. For a = 1, s = 3: 1 + 2 + 4/3 = **13/3 ≈ 4.333**.

**Solution 15.8.** Couplings of (P, Q) and of (P̃, Q̃) correspond one to one by shifting: (X, Y) ↦ (X − m\_P, Y − m\_Q). For a coupling, write X − Y = (m\_P − m\_Q) + (X̃ − Ỹ) with X̃ = X − m\_P and Ỹ = Y − m\_Q. Then

$$
\mathbb{E}\|X-Y\|^2 = \|m_P-m_Q\|^2 + 2\,\big\langle m_P-m_Q,\; \mathbb{E}[\tilde X-\tilde Y]\big\rangle + \mathbb{E}\|\tilde X-\tilde Y\|^2 = \|m_P-m_Q\|^2 + \mathbb{E}\|\tilde X-\tilde Y\|^2 ,
$$

because E X̃ = E Ỹ = 0. The first term does not depend on the coupling, so minimising over couplings gives the claim. ∎ W₁ has no such clean split, which is one reason W₂ is preferred when means and covariances matter, as in FID.

**Solution 15.9.** (a) Sorted matching 0→1, 4→2: W₁ = (1 + 2)/2 = **1.5**. CDF check: abs(F − G) = 0.5 on \[0, 1), 0 on \[1, 2), 0.5 on \[2, 4); total 0.5 + 0 + 1 = 1.5.

(b) By 8.4 choose f′ = −sign(F − G): f′ = −1 on \[0, 1) where F > G, f′ = +1 on \[2, 4) where F < G, and anything with abs(f′) ≤ 1 on \[1, 2). For example f(x) = abs(x − 1.5). Then E\_P f = (1.5 + 2.5)/2 = 2, E\_Q f = (0.5 + 0.5)/2 = 0.5, and E\_P f − E\_Q f = **1.5** = W₁.

(c) No. Every f(x) = abs(x − c) with c ∈ \[1, 2\] works: E\_P f = (c + 4 − c)/2 = 2 and E\_Q f = ((c − 1) + (2 − c))/2 = 0.5. The critic is pinned down only where F ≠ G; in a WGAN this non-uniqueness is one reason the critic is only loosely determined away from the data.

**Solution 15.10.** (a) K = exp(−C) = \[\[e⁻¹, e⁻³\], \[e⁻¹, e⁻¹\]\] ≈ \[\[0.3679, 0.0498\], \[0.3679, 0.3679\]\].

1. Kv = (0.3679 + 0.0498, 0.3679 + 0.3679) = (0.4177, 0.7358), so u = a/(Kv) = (1.1971, 0.6796).
2. Kᵀu = (0.3679·(1.1971 + 0.6796), 0.0498·1.1971 + 0.3679·0.6796) = (0.6904, 0.3096), so v = b/(Kᵀu) = (0.3621, 2.4225).
3. Plan γ = diag(u)·K·diag(v) ≈ \[\[0.159, 0.144\], \[0.091, 0.606\]\].

Column sums are exactly (0.25, 0.75), as the v-step guarantees; row sums are (0.304, 0.696), still far from a. The cost ⟨γ, C⟩ ≈ 0.159 + 3·0.144 + 0.091 + 0.606 ≈ **1.289**, below the exact OT of 1.5. That is not a contradiction: the plan is not yet feasible. Lesson: never read a Sinkhorn cost without checking the marginals. At convergence the cost is ≈ 1.587, above 1.5 as entropic blurring predicts.

(b) As ε → ∞, K = exp(−C/ε) → 𝟙𝟙ᵀ entrywise. For K = 𝟙𝟙ᵀ every scaled plan has the form γᵢⱼ = uᵢvⱼ. The row constraint gives uᵢ(Σⱼvⱼ) = aᵢ and the column constraint vⱼ(Σᵢuᵢ) = bⱼ, so γᵢⱼ = aᵢbⱼ/(Σᵢuᵢ·Σⱼvⱼ), and summing all entries shows the denominator is 1. Hence γ = abᵀ. The entropic plan is the unique minimiser of a strictly convex problem and depends continuously on K, which justifies passing to the limit. ∎

**Solution 15.11.** For a unit θ, ⟨θ, X⟩ \~ N(0, 1) under P and N(0, s²) under Q, so W₂(θ#P, θ#Q) = abs(1 − s) for every θ (Example 6.D). Hence **SW₂ = abs(1 − s)**, independent of d. The covariances commute, so Section 7 gives W₂² = Σₖ(1 − s)² = d(1 − s)², that is **W₂ = √d·abs(1 − s)**. The ratio SW₂/W₂ = 1/√d shrinks with dimension, the same factor as for translations (11.3). For d = 5 and s = 2 the notebook estimates SW₂ ≈ 0.99 (exact 1). Exact OT between 2000-point samples gives ≈ 2.46 against the true √5 ≈ 2.24, a visible example of the upward sample bias of Exercise 15.12.

**Solution 15.12.** (a) For each realisation ω of the samples, let γ\_ω be an optimal coupling of P̂ₙ(ω) and Q̂ₙ(ω), and define the averaged coupling γ̄ = E\_ω\[γ\_ω\], a mixture of couplings. Its first marginal is E\_ω\[P̂ₙ\] = P, because for every set A, E\[P̂ₙ(A)\] = (1/n)Σᵢ Pr(Xᵢ ∈ A) = P(A); likewise its second marginal is Q. So γ̄ ∈ Π(P, Q) and

$$
W_p^p(P,Q) \;\le\; \int d^p\, d\bar\gamma \;=\; \mathbb{E}_\omega\Big[\int d^p\, d\gamma_\omega\Big] \;=\; \mathbb{E}\big[W_p^p(\hat P_n,\hat Q_n)\big]. \;\;\blacksquare
$$

(b) If P = Q is continuous, two independent samples share no point with probability 1, so P̂ₙ ≠ Q̂ₙ and Wₚ(P̂ₙ, Q̂ₙ) > 0 almost surely, while Wₚ(P, Q) = 0.

(c) The notebook finds mean W₂ ≈ 0.95, 0.58, 0.34 and 0.20 for n = 16, 64, 256 and 1024, although the true value is 0. Each fourfold increase in n shrinks the bias by a factor of about 0.6, roughly the n^(−1/2) rate up to logarithmic factors expected in d = 2; in higher dimension it shrinks far more slowly. Practical rule: compare mini-batch OT values only at the same batch size, and report a noise floor.

**Solution 15.13.** (a) ReLU is 1-Lipschitz, a linear layer W is ‖W‖₂-Lipschitz (spectral norm), and Lipschitz constants multiply under composition, so K ≤ Π ‖W\_l‖₂ ≤ Π ‖W\_l‖\_F. With entries bounded by c = 0.01, ‖W‖\_F ≤ c·√(number of entries): layer 1 (128 × 2) gives 0.01·√256 = 0.16; layer 2 (128 × 128) gives 0.01·128 = 1.28; layer 3 (1 × 128) gives 0.01·√128 ≈ 0.113. So **K ≤ 0.16 × 1.28 × 0.113 ≈ 0.023**. (b) The critic's objective is at most K·W₁ ≈ 0.023·W₁: a tiny signal easily drowned by optimisation noise, with an unknown K that changes during training. This is a concrete reason why clipping is fragile and why gradient penalties and spectral normalisation replaced it.

**Solution 15.14.**

```python
import numpy as np

def emd_hist(h1, h2):
    p = np.asarray(h1, float); q = np.asarray(h2, float)
    p, q = p / p.sum(), q / q.sum()          # normalise to probability vectors
    return np.abs(np.cumsum(p - q)).sum()    # sum of |F - G| over unit-width gaps
```

By Section 6, W₁ = ∫ abs(F − G) dx. For histograms on integer grey levels, F − G is constant between consecutive levels k and k + 1 and equals the cumulative sum of p − q up to k, so the integral is a sum of abs(cumsum) times the gap 1. The last cumulative sum is 0 because both vectors sum to 1, so including it is harmless. It runs in O(256) and agrees with `scipy.stats.wasserstein_distance(np.arange(256), np.arange(256), h1, h2)`.

**Solution 15.15.** (a) EMD = W₁ with Euclidean cost between uniform point sets (a bijection suffices by 4.3), solved approximately with an auction algorithm. (b) The Sinkhorn divergence S\_ε (debiased entropic OT), typically with squared Euclidean cost, solved by log-domain Sinkhorn. (c) W₁ in feature space through Kantorovich–Rubinstein duality, Euclidean cost, neural critic (WDGRL-style). (d) A mini-batch W₂² coupling (OT-CFM), squared Euclidean cost, exact assignment per batch. (e) A semidiscrete OT coupling between the continuous noise distribution and the whole dataset (SD-FM): the potentials are the semi-dual variables of 12.7, learned by SGD; an inner-product cost (equivalent to squared Euclidean up to terms that depend on one point only) and a maximum-inner-product search replace a batch solver.

**Solution 15.16.** (1) True: W₁ is a metric. (2) False: δ₀ versus δ\_θ has KL = ∞ but W₁ = abs(θ). (3) False: every entry is positive, so the plan is dense. (4) True: Wₚ is non-decreasing in p (Jensen). (5) True: Birkhoff–von Neumann (4.3). (6) False: the cost is concave; see 15.4(b). (7) True: the only directions are ±1, and reflecting both distributions does not change Wₚ. (8) False: the critic's range is unconstrained; a sigmoid would reintroduce saturation. (9) False: FID is W₂² between Gaussian fits to Inception features, not W₂ between the image distributions. (10) True: Exercise 15.10(b).

**Solution 15.17.** Lower bound: for any coupling, d(X, Y) ≥ d\_min·𝟙(X ≠ Y), so E d(X, Y) ≥ d\_min·Pr(X ≠ Y) ≥ d\_min·TV by Exercise 15.5; minimise over couplings. Upper bound: take the coupling from Exercise 15.5 that achieves Pr(X ≠ Y) = TV. Since d(X, Y) ≤ D always and d(X, Y) = 0 when X = Y, its cost is at most D·TV, and W₁ is no larger. ∎ For a 256-bin histogram (d\_min = 1, D = 255), W₁ lies between TV and 255·TV: both agree on whether histograms differ, but EMD can weigh the same mismatch up to 255 times more when the mass must move far, exactly the information bin-by-bin measures discard (Section 1.2).

**Solution 15.18.** (a) For x₁ < x₂ the sorted plan sends x₁ → 0 and x₂ → 4, each with mass ½, so W₂² = ½x₁² + ½(x₂ − 4)², giving ∂/∂x₁ = x₁ and ∂/∂x₂ = x₂ − 4. The formula of 8.6 gives the same: 2aᵢ(xᵢ − T̄(xᵢ)) = 2·½·(x₁ − 0) = x₁ and 2·½·(x₂ − 4) = x₂ − 4. (The notebook's autograd check at (x₁, x₂) = (0.3, 2.0) returns (0.3, −2.0).)

(b) With x₂ = 2: for x₁ < 2 the cost is ½x₁² + 2; for x₁ > 2 the matching swaps (x₁ → 4, 2 → 0) and the cost is ½(x₁ − 4)² + 2. W₂² is the **minimum** of these two parabolas (each is the cost of one plan, and OT takes the cheaper one). Both equal 4 at x₁ = 2, where the left derivative is +2 and the right derivative is −2: a concave kink, here a local maximum. Because OT is a minimum over plans of functions that are smooth in the data, its kinks are always concave. Gradient descent is pushed away from them, so they rarely trap training, but autograd silently returns one of the one-sided derivatives there.

**Solution 15.19.** (a) Independent pairs (0,1), (0,3), (2,1), (2,3), each with probability ¼, have velocities x₁ − x₀ = 1, 3, −1, 1. At t = 0, xₜ = x₀, so the ideal velocity at x is the average of x₁ − x₀ given x₀ = x: at 0 it is (1 + 3)/2 = 2, at 2 it is (−1 + 1)/2 = 0. One Euler step sends 0 → 2 and 2 → 2, so all mass lands at 2. W₂(δ₂, ½δ₁ + ½δ₃) = √(½·1 + ½·1) = **1**. (b) The OT coupling pairs 0 → 1 and 2 → 3, both with velocity 1. One step lands exactly on Q: **W₂ = 0**. With independent pairs the conditional paths cross, so the averaged velocity field is curved and needs many small steps. With OT pairs the paths do not cross, the field is constant along each path, and a single step is exact. This is the 1D essence of the notebook's 2D experiment.

**Solution 15.20.** (a) J(s) = E\_P f − E\_Q f − λ(s − 1)² = 0 − (−sθ) − λ(s − 1)² = sθ − λ(s − 1)². Setting J′(s) = θ − 2λ(s − 1) = 0 gives **s\* = 1 + θ/(2λ)** and **J\* = θ + θ²/(4λ)**. (b) With λ = 10: θ = 1 gives s\* = 1.05 and J\* = 1.025, which is 2.5% above W₁ = 1; θ = 10 gives s\* = 1.5 and J\* = 12.5, which is 25% above W₁ = 10. (c) The penalty is a soft constraint: when the distributions are far apart relative to λ (typically early in training), the critic steepens beyond slope 1 and its value overestimates W₁. As they get closer, θ²/(4λ) vanishes and the estimate tightens. The sign of the generator's gradient remains correct; only its scale is inflated. In real networks, limited capacity pulls in the opposite direction (the notebook's critic underestimates), so the critic value is a monitoring signal, not a measurement.

**Solution 15.21.** (a) In 1D with a convex cost the monotone plan is optimal: γ = \[\[⅓, ⅙, 0\], \[0, ⅙, ⅓\]\] (source 0 sends ⅓ to 2 and ⅙ to 4; source 1 sends ⅙ to 4 and ⅓ to 6). (b) T̄(0) = (⅓·2 + ⅙·4)/(½) = **8/3 ≈ 2.667** and T̄(1) = (⅙·4 + ⅓·6)/(½) = **16/3 ≈ 5.333**. (c) The mapped points have mean 4, equal to the target mean, but variance ((8/3 − 4)² + (16/3 − 4)²)/2 = 16/9 ≈ 1.78, smaller than the target variance (4 + 0 + 4)/3 = 8/3 ≈ 2.67. The law of total variance explains the gap exactly: target variance = variance of the conditional means (16/9, which is what T̄ keeps) + average conditional variance (each source's mass is split between destinations with variance 8/9). The barycentric map replaces each split by its average, so it shrinks spread, and entropic plans, which split more, shrink it further. In domain adaptation this means transported source samples are slightly "over-concentrated" relative to the target.

**Solution 15.22.** (a) In 1D the W₂ barycenter averages quantile functions: ½Φ⁻¹(t) + ½(4 + 3Φ⁻¹(t)) = 2 + 2Φ⁻¹(t), which is the quantile function of N(2, 4). (b) By the 1D Gaussian formula, W₂²(N(2, 4), N(0, 1)) = (2 − 0)² + (2 − 1)² = 5 and W₂²(N(2, 4), N(4, 9)) = (2 − 4)² + (2 − 3)² = 5, so the barycenter is at distance **√5 ≈ 2.236** from each, as expected for equal weights. (c) The mixture has mean 2 (the same) but variance ½(1 + 9) + ½((0 − 2)² + (4 − 2)²) = 5 + 4 = **9**, and its density has two humps: a sharp peak near 0 and a low, broad hump near 4. The barycenter **moves** mass to an intermediate shape (it is the displacement interpolation of 5.7 at t = ½), while the mixture **superimposes** the two inputs. This is why barycenters are used to average shapes and histograms.

**Solution 15.23.** (a) Histogram *counts* are passed as values: the call computes W₁ between the two sets of 50 count values, a meaningless number. Pass the bin centres as values and the counts as weights, or pass the raw samples x and y. (b) `ot.dist` defaults to squared Euclidean, so this is W₂², not W₁; add `metric="euclidean"`. (c) Two problems: with reg = 10⁻³ and unscaled distances the default solver underflows (`method="sinkhorn_log"` or rescale M), and even when it converges the result is the entropic cost ⟨γ\_ε, C⟩, a biased estimate of W₁, not W₁ itself. (d) `ot.wasserstein_1d` returns Wₚᵖ; with p = 2 this is W₂², and in any case not W₁: use p = 1, or take the square root and call it W₂. (e) Empirical Wasserstein distances are biased upward and the bias shrinks with the sample size (Exercise 15.12), so the two numbers are not comparable; recompute at the same batch size and report a real-versus-real noise floor.

**Solution 15.24.** (a) Maximise 0.5u₁ + 0.5u₂ + 0.25v₁ + 0.75v₂ subject to u₁ + v₁ ≤ 1, u₁ + v₂ ≤ 3, u₂ + v₁ ≤ 1, u₂ + v₂ ≤ 1. (b) Equalities on the three used routes: u₁ + v₁ = 1, u₁ + v₂ = 3, u₂ + v₂ = 1. Fix u₁ = 0: v₁ = 1, v₂ = 3, u₂ = −2. Unused route: u₂ + v₁ = −1 ≤ 1, satisfied with slack 2, which is exactly the reduced cost of route (2,1). (c) Dual value 0 − 1 + 0.25 + 2.25 = **1.5** = primal. (d) f(z) = min(abs(z − 1) − 1, abs(z − 3) − 3). At the support points: f(0) = min(0, 0) = 0, f(2) = min(0, −2) = −2, f(1) = min(−1, −1) = −1, f(3) = min(1, −3) = −3. E\_P f = ½·0 + ½·(−2) = −1; E\_Q f = ¼·(−1) + ¾·(−3) = −2.5; the gap is **1.5** = W₁. Note f(xᵢ) = uᵢ and f(yⱼ) = −vⱼ here, as the proof in 8.3 predicts, and that f is 1-Lipschitz as a minimum of two 1-Lipschitz functions.

**Solution 15.25.**

```python
import numpy as np

def w_p_1d_weighted(x, y, a, b, p=1):
    """Exact W_p between sum_i a_i delta_{x_i} and sum_j b_j delta_{y_j} on the line."""
    x, y = np.asarray(x, float), np.asarray(y, float)
    a, b = np.asarray(a, float) / np.sum(a), np.asarray(b, float) / np.sum(b)
    ix, iy = np.argsort(x), np.argsort(y)
    x, a, y, b = x[ix], a[ix], y[iy], b[iy]
    Fa, Fb = np.cumsum(a), np.cumsum(b)                    # CDF values just after each atom
    t = np.unique(np.concatenate([[0.0], Fa, Fb]))         # all probability levels where a quantile can jump
    t = np.clip(t, 0, 1)
    mid = (t[:-1] + t[1:]) / 2                              # one representative level per piece
    qx = x[np.minimum(np.searchsorted(Fa, mid), len(x) - 1)]   # F^{-1}(t): smallest x with F(x) >= t
    qy = y[np.minimum(np.searchsorted(Fb, mid), len(y) - 1)]
    return (np.sum(np.diff(t) * np.abs(qx - qy) ** p)) ** (1 / p)

x, y, a, b = [0., 2.], [1., 3.], [.5, .5], [.25, .75]
print(w_p_1d_weighted(x, y, a, b, 1), w_p_1d_weighted(x, y, a, b, 2) ** 2)   # 1.5 and 3.0
```

Why it works: both quantile functions are step functions of t that can only jump at the cumulative weights Fa and Fb. Between two consecutive such levels both are constant, so ∫₀¹ abs(F⁻¹ − G⁻¹)ᵖ dt is a finite sum of (piece length) × (constant difference)ᵖ. Sorting costs O((n + m) log(n + m)); the rest is linear. For p = 1 the answer agrees with `w1_1d_weighted` of Section 6.6 (the same sum organised by x instead of by t), and for equal uniform weights it reduces to sort-and-match.

## 16. Cheat sheet and references

Everything on one page: if you can derive each line below and say when to use it, you know EMD at exam and interview level.

### 16.1 Formulas

**Definition (discrete and general).** EMD = W₁; Wₚ for p ≥ 1:

$$
\mathrm{OT}_C(a,b)=\min_{\gamma\ge 0,\;\gamma\mathbb{1}=a,\;\gamma^{\top}\mathbb{1}=b}\langle\gamma,C\rangle, \qquad W_p(P,Q)=\Big(\inf_{\gamma\in\Pi(P,Q)}\mathbb{E}_{\gamma}\,d(X,Y)^p\Big)^{1/p}
$$

**Dual (LP) and Kantorovich–Rubinstein.**

$$
\mathrm{OT}_C(a,b)=\max_{u_i+v_j\le C_{ij}}\;\langle a,u\rangle+\langle b,v\rangle, \qquad W_1(P,Q)=\sup_{\|f\|_L\le 1}\;\mathbb{E}_P f-\mathbb{E}_Q f
$$

**1D closed forms** (F, G CDFs; F⁻¹, G⁻¹ quantiles; equal-size samples: sort and match):

$$
W_1=\int_{\mathbb{R}}|F(x)-G(x)|\,dx, \qquad W_p^p=\int_0^1|F^{-1}(t)-G^{-1}(t)|^p\,dt, \qquad W_p^p=\frac1n\sum_{i=1}^n|x_{(i)}-y_{(i)}|^p
$$

**Gaussians (also FID):**

$$
W_2^2\big(\mathcal N(m_1,\Sigma_1),\mathcal N(m_2,\Sigma_2)\big)=\|m_1-m_2\|^2+\operatorname{tr}\!\Big(\Sigma_1+\Sigma_2-2\big(\Sigma_2^{1/2}\Sigma_1\Sigma_2^{1/2}\big)^{1/2}\Big)
$$

**Entropic OT and Sinkhorn:**

$$
\gamma_\varepsilon=\operatorname{diag}(u)\,K\,\operatorname{diag}(v),\;\; K=e^{-C/\varepsilon}; \qquad u\leftarrow a\oslash Kv,\;\; v\leftarrow b\oslash K^{\top}u; \qquad S_\varepsilon=\mathrm{OT}_\varepsilon(P,Q)-\tfrac12\mathrm{OT}_\varepsilon(P,P)-\tfrac12\mathrm{OT}_\varepsilon(Q,Q)
$$

**Sliced Wasserstein and WGAN-GP:**

$$
SW_p^p=\mathbb{E}_{\theta\sim\mathrm{Unif}(S^{d-1})}\,W_p^p(\theta_\#P,\theta_\#Q), \qquad L_{\text{critic}}=\mathbb{E}f(\tilde x)-\mathbb{E}f(x)+\lambda\,\mathbb{E}\big(\|\nabla f(\hat x)\|_2-1\big)^2
$$

### 16.2 Facts to remember

| Fact | Where |
| --- | --- |
| EMD of a translation by v is ‖v‖; KL/JS/TV saturate on disjoint supports | 1.3, 15.6 |
| An optimal vertex plan uses at most n + m − 1 routes (a forest) | 4.2 |
| Uniform clouds of equal size: OT = assignment (permutation) | 4.3 |
| Optimality certificate: uᵢ + vⱼ ≤ Cᵢⱼ, equality on the support | 4.4 |
| Wₚ is a metric; W₁ ≤ W₂ ≤ … ≤ W\_∞; W₁ ≥ ‖m\_P − m\_Q‖ | 5.3, 5.4 |
| W₂² = ‖Δm‖² + W₂²(centred) | 15.8 |
| Empirical W converges like n^(−1/d); E Wₚᵖ on samples is biased upward | 5.6, 15.12 |
| On a circle, W₁ = min over α of ∫ abs(F − G − α) | 6.7 |
| Gradient: ∇ W₂² at xᵢ = 2aᵢ(xᵢ − T̄(xᵢ)); OT has concave kinks where the plan is not unique | 8.6, 15.18 |
| Optimal WGAN critic has unit gradient on transport segments; the gradient penalty is soft and can overestimate W₁ | 9.4, 15.20 |
| Entropic plan is dense; OT\_ε(P, P) ≠ 0 (sign depends on convention); use log domain for small ε or float32 | 10, 13.4 |
| S\_ε is a valid divergence for costs ‖x − y‖ and ‖x − y‖² | 10.7 |
| SW ≤ W, and SW/W can be about 1/√d | 11.3, 15.11 |
| Coupling choice drives few-step flow matching; 2025–26 methods go beyond mini-batch OT | 12.1, 15.19 |
| 1D W₂ barycenter averages quantile functions; it moves mass, a mixture superimposes it | 12.7, 15.22 |
| TV is OT with the 0–1 cost; d\_min·TV ≤ W₁ ≤ D·TV | 15.5, 15.17 |
| In 1D: KS = sup abs(F − G), W₁ = ∫ abs(F − G), Cramér–von Mises² = ∫ (F − G)²; quantile regression minimises W₁ | 6.8 |
| W₁, TV, MMD and Dudley are IPMs (sup over a function class); KL and JS are f-divergences (density ratios) | 8.7 |
| Potentials are defined up to (u + t, v − t); compare uᵢ + vⱼ across solvers, not u and v | 4.5 |
| Sinkhorn: iterations bounded by ∝ ‖C‖/ε, slower growth in practice; Õ(n²/δ²) total; ε-scaling pays off with truncated kernels | 10.9 |

### 16.3 Library one-liners

- 1D W₁: `scipy.stats.wasserstein_distance(x, y, wx, wy)`.
- Exact EMD: `ot.emd2(a, b, ot.dist(X, Y, metric="euclidean"))`; W₂: `sqrt(ot.emd2(a, b, ot.dist(X, Y)))`.
- Matching: `scipy.optimize.linear_sum_assignment(C)`.
- Sinkhorn: `ot.sinkhorn2(a, b, M, reg, method="sinkhorn_log")`.
- Sliced: `ot.sliced_wasserstein_distance(X, Y, n_projections=..., seed=...)`.
- Gaussian W₂: `ot.gaussian.bures_wasserstein_distance(m1, m2, S1, S2)`.

### 16.4 References

Textbooks and surveys (start here): G. Peyré and M. Cuturi, [Computational Optimal Transport](https://arxiv.org/abs/1803.00567), Foundations and Trends in ML, 2019 (the best computational reference, free on arXiv); F. Santambrogio, Optimal Transport for Applied Mathematicians, Birkhäuser, 2015; C. Villani, Optimal Transport: Old and New, Springer, 2009 (advanced).

Papers cited in this tutorial:

| Topic | Reference |
| --- | --- |
| Original EMD in vision | Y. Rubner, C. Tomasi, L. Guibas, "The Earth Mover's Distance as a Metric for Image Retrieval", IJCV, 2000 |
| WGAN | M. Arjovsky, S. Chintala, L. Bottou, [Wasserstein GAN](https://arxiv.org/abs/1701.07875), ICML 2017 |
| WGAN-GP | I. Gulrajani et al., [Improved Training of Wasserstein GANs](https://arxiv.org/abs/1704.00028), NeurIPS 2017 |
| One-sided penalty (WGAN-LP) | H. Petzka, A. Fischer, D. Lukovnikov, "On the Regularization of Wasserstein GANs", ICLR 2018 |
| Spectral normalisation | T. Miyato et al., [Spectral Normalization for GANs](https://arxiv.org/abs/1802.05957), ICLR 2018 |
| Sinkhorn | M. Cuturi, [Sinkhorn Distances: Lightspeed Computation of Optimal Transport](https://arxiv.org/abs/1306.0895), NeurIPS 2013 |
| Sinkhorn divergences | A. Genevay, G. Peyré, M. Cuturi, [Learning Generative Models with Sinkhorn Divergences](https://arxiv.org/abs/1706.00292), AISTATS 2018; J. Feydy et al., [Interpolating between OT and MMD using Sinkhorn Divergences](https://arxiv.org/abs/1810.08278), AISTATS 2019; A. Genevay et al., "Sample Complexity of Sinkhorn Divergences", AISTATS 2019 |
| FID | M. Heusel et al., [GANs Trained by a Two Time-Scale Update Rule Converge to a Local Nash Equilibrium](https://arxiv.org/abs/1706.08500), NeurIPS 2017 |
| Sample complexity | N. Fournier, A. Guillin, "On the rate of convergence in Wasserstein distance of the empirical measure", PTRF, 2015; M. Ajtai, J. Komlós, G. Tusnády, "On optimal matchings", Combinatorica, 1984 |
| Sinkhorn complexity and ε-scaling | J. Altschuler, J. Weed, P. Rigollet, [Near-linear time approximation algorithms for optimal transport via Sinkhorn iteration](https://arxiv.org/abs/1705.09634), NeurIPS 2017; P. Dvurechensky, A. Gasnikov, A. Kroshnin, ICML 2018; B. Schmitzer, "Stabilized sparse scaling algorithms for entropy regularized transport problems", SIAM J. Sci. Comput., 2019 |
| Integral probability metrics | A. Müller, "Integral probability metrics and their generating classes of functions", Adv. Appl. Prob., 1997; B. Sriperumbudur et al., "On the empirical estimation of integral probability metrics", Electron. J. Stat., 2012 |
| Distributional RL | M. Bellemare, W. Dabney, R. Munos, [A Distributional Perspective on Reinforcement Learning](https://arxiv.org/abs/1707.06887), ICML 2017 (C51); W. Dabney et al., [Distributional RL with Quantile Regression](https://arxiv.org/abs/1710.10044), AAAI 2018 (QR-DQN); M. Bellemare et al., "The Cramer Distance as a Solution to Biased Wasserstein Gradients", 2017 |
| Wasserstein loss, WAE, OT fusion, Sinkformers | C. Frogner et al., "Learning with a Wasserstein Loss", NeurIPS 2015; I. Tolstikhin et al., "Wasserstein Auto-Encoders", ICLR 2018; S. P. Singh, M. Jaggi, "Model Fusion via Optimal Transport", NeurIPS 2020; M. Sander et al., "Sinkformers", AISTATS 2022 |
| Fréchet distance between Gaussians | D. C. Dowson, B. V. Landau, "The Fréchet distance between multivariate normal distributions", J. Multivariate Anal., 1982 |
| Flow matching | Y. Lipman et al., [Flow Matching for Generative Modeling](https://arxiv.org/abs/2210.02747), ICLR 2023 |
| OT-CFM | A. Tong et al., [Improving and Generalizing Flow-Based Generative Models with Minibatch Optimal Transport](https://arxiv.org/abs/2302.00482), TMLR 2024 |
| Large Sinkhorn couplings | S. Zhang et al., "On Fitting Flow Models with Large Sinkhorn Couplings", 2025 |
| Semidiscrete couplings (SD-FM) | A. Mousavi-Hosseini, S. Y. Zhang, M. Klein, M. Cuturi, [Flow Matching with Semidiscrete Couplings](https://arxiv.org/abs/2509.25519), ICLR 2026 |
| Model-aligned coupling | Y. Lin, Y. Yao, T. Liu, [Beyond Optimal Transport: Model-Aligned Coupling for Flow Matching](https://arxiv.org/abs/2505.23346), 2025 |
| Cluster-wise OT flow matching | C. Chiang, K.-H. Tu, J.-W. Liao, C.-F. Chou, T.-W. Ke, [COT-FM: Cluster-wise Optimal Transport Flow Matching](https://arxiv.org/abs/2603.13395), CVPR 2026 |
| OT flow matching by design | S. Malnick, M. Rusanovsky, O. Fried, S. Avidan, [Optimal Transport Flow Matching by Design](https://arxiv.org/abs/2606.04092), 2026 |
| Proximal view of OT-CFM | K. Fukumizu et al., [Flow Matching from Viewpoint of Proximal Operators](https://arxiv.org/abs/2602.12683), 2026 |
| Weighted CFM | S. Calvo-Ordoñez et al., [Weighted Conditional Flow Matching](https://arxiv.org/abs/2507.22270), 2025 |
| OT domain adaptation | N. Courty et al., [Optimal Transport for Domain Adaptation](https://arxiv.org/abs/1507.00504), TPAMI 2017; I. Redko, A. Habrard, M. Sebban, ECML-PKDD 2017; J. Shen et al. (WDGRL), AAAI 2018 |
| DeepJDOT | B. B. Damodaran et al., [DeepJDOT](https://arxiv.org/abs/1803.10081), ECCV 2018 |
| Point-cloud EMD and Chamfer | H. Fan, H. Su, L. Guibas, [A Point Set Generation Network for 3D Object Reconstruction from a Single Image](https://arxiv.org/abs/1612.00603), CVPR 2017 |
| Cross-tokenizer distillation | N. Boizard et al., [Towards Cross-Tokenizer Distillation: the Universal Logit Distillation Loss for LLMs](https://arxiv.org/abs/2402.12030), TMLR 2025 |
| Extensions (12.7) | Barycenters: Agueh and Carlier (2011), Cuturi and Doucet (ICML 2014). Unbalanced OT: Chizat, Peyré, Schmitzer, Vialard (2018). Gromov–Wasserstein: Mémoli (2011), Peyré, Cuturi, Solomon (ICML 2016). Schrödinger bridges: De Bortoli et al. (NeurIPS 2021), Tong et al. \[SF\]²M (AISTATS 2024). Semi-discrete OT: Genevay, Cuturi, Peyré, Bach (NeurIPS 2016). Neural OT maps: Makkuva et al. (ICML 2020), Uscidda and Cuturi (ICML 2023) |

Software: [POT documentation](https://pythonot.github.io/) and [POT on PyPI](https://pypi.org/project/pot/) (0.9.7.post1, July 2026); [GeomLoss](https://www.kernel-operations.io/geomloss/); [SciPy `wasserstein_distance`](https://docs.scipy.org/doc/scipy/reference/generated/scipy.stats.wasserstein_distance.html); OTT-JAX (neural OT, semidiscrete OT) at [github.com/ott-jax/ott](https://github.com/ott-jax/ott); OT-CFM reference code at [github.com/atong01/conditional-flow-matching](https://github.com/atong01/conditional-flow-matching).

Other works mentioned in the text (Mallasto et al. and Stanczuk et al. on WGAN critics, max-sliced and generalised sliced Wasserstein, Word Mover's Distance, MoverScore, NIMA, SuperGlue, SwAV, Waddington-OT, PointFlow, MSN, multisample flow matching, couplings distilled from normalising flows) are easy to find by author and title; read their method sections with the six questions of 14.2 in mind.

### 16.5 Index of named objects

| Name | Meaning | Defined in |
| --- | --- | --- |
| Barycentric projection T̄ | Average destination of the mass at a point under a plan | 8.6, 12.2, 15.21 |
| Benamou–Brenier formula | W₂² as minimal kinetic energy of a flow | 12.1 |
| Birkhoff–von Neumann | Vertices of the uniform transport polytope are permutations | 4.3 |
| Brenier map / Brenier potential | Optimal W₂ map is the gradient of a convex function | 5.2, 7.3, 12.7 |
| Bures distance | Covariance term of the Gaussian W₂ formula | 7.1 |
| c-transform | Best second potential given the first | 8.2 |
| Chamfer distance | Nearest-neighbour point-cloud loss, not an OT quantity | 12.3 |
| Complementary slackness | uᵢ + vⱼ = Cᵢⱼ wherever γᵢⱼ > 0 | 4.4, 8.1 |
| Coupling / transport plan γ | Joint distribution with prescribed marginals | 3.1, 5.2 |
| Cramér–von Mises / energy distance | ∫(F − G)² in 1D | 6.8 |
| Displacement interpolation | Geodesic in W₂ space | 5.7 |
| Dual potentials (Kantorovich potentials) u, v | Multipliers of the marginal constraints | 4.4, 8.1 |
| Entropic OT, Gibbs kernel K = e^{−C/ε} | Regularised problem and its kernel | 10.1–10.2 |
| ε-scaling | Annealing ε with warm starts | 10.9 |
| FID | W₂² between Gaussian fits of Inception features | 7.5 |
| Gelbrich bound | Gaussian formula is a lower bound for all distributions | 7.2 |
| Gluing lemma | Composition of couplings, used for the triangle inequality | 5.3 |
| Gromov–Wasserstein | OT across different metric spaces | 12.7 |
| Integral probability metric (IPM) | sup over a function class of E\_P f − E\_Q f | 8.7 |
| Kantorovich–Rubinstein duality | W₁ = sup over 1-Lipschitz f | 8.3 |
| Kolmogorov–Smirnov | sup abs(F − G) | 6.8 |
| Lipschitz constant | Bound on a function's slope | P8 |
| Monge map, push-forward T#P | Deterministic transport | 5.1, P11 |
| Network simplex, transportation simplex | Exact LP solvers | 4.5, 4.6 |
| North-west corner rule | Cost-blind starting plan (optimal in 1D on sorted supports) | 4.1, 6.3 |
| Quantile coupling (comonotone coupling) | Match F⁻¹(U) with G⁻¹(U) | 6.2 |
| Quantile regression / pinball loss | Minimises 1D W₁; used in QR-DQN | 6.8 |
| Reduced cost | Cᵢⱼ − uᵢ − vⱼ | 4.5 |
| Schrödinger bridge | Dynamic form of entropic OT | 12.7 |
| Semi-discrete OT, Laguerre cells | Continuous source to discrete target | 12.7, 12.1 |
| Sinkhorn divergence S\_ε | Debiased entropic OT | 10.7 |
| Sliced / max-sliced Wasserstein | Average or maximum of 1D OT over projections | 11 |
| Support graph | Bipartite graph of used routes; a forest at a vertex | 4.2 |
| Transportation polytope Π(a, b) | Feasible set of the discrete problem | 3.1, 3.4 |
| Unbalanced / partial OT | Soft or partial marginal constraints | 3.7, 12.7 |
| Wasserstein barycenter | Fréchet mean in W₂ | 12.7 |
| WGAN critic, gradient penalty, weight clipping, spectral normalisation | Neural approximations of the KR dual | 9 |
